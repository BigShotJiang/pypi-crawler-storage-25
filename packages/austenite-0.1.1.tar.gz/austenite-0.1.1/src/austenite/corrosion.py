"""Corrosion + stress-corrosion + sour-service envelope models.

What pipeline / offshore / refinery / petrochemical engineers actually use.
Covers the canonical mechanisms beyond what API 581 Part 2 ships:

* **De Waard-Lotz 1995** — CO2 corrosion rate fit (with Sm-correction).
* **McConomy 1956 modified** — high-temperature sulfidation rates.
* **Cassagne 1996** — amine SCC rates (MEA / DEA / MDEA).
* **Andresen-Ford 1985** — H+-corrosion-fatigue-crack-growth rate.
* **Galvele 1976** — pitting potential model.
* **NACE TM0177 / NACE MR0175** — sour-service envelope evaluator.
* **Gerberich-Wozniak 1984** — K_ISCC fit for hydrogen-embrittlement.
* **Krom-Bakker 2001** — hydrogen permeation flux in steels.
* **Arrhenius** corrosion-rate temperature scaling for general use.

Used by ASTM G39, NACE MR0175, ISO 15156, API 5L Annex H, NACE TM0177
sour-service qualification. Engineers currently run these in Excel.

References:
    * de Waard C., Lotz U., NACE Corrosion 95, paper 128 (1995).
    * McConomy H.F., Proc. API 43.III (1963) 78; mod. Couper-Gorman 1971.
    * Cassagne T., Lemaitre C., NACE Corrosion 96, paper 393 (1996).
    * Andresen P.L., Ford F.P., Mater. Sci. Eng. 103 (1988) 167.
    * Galvele J.R., J. Electrochem. Soc. 123 (1976) 464.
    * Gerberich W.W., Wozniak D., Met. Trans. A 15 (1984) 2227.
    * Krom A.H.M., Bakker A.D.E., Met. Mater. Trans. A 31 (2000) 1475.
    * NACE TM0177-2016 — Sulfide Stress Cracking Resistant Metallic Materials.
    * NACE MR0175 / ISO 15156-2023 — Sour-service material selection.
    * API 5L Annex H (2018) — Sour-service line pipe.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Literal


R_GAS: float = 8.31451  # J/mol/K
F_FARADAY: float = 96485.0  # C/mol


# ---------------------------------------------------------------------------
# 1. CO2 corrosion — de Waard-Lotz 1995
# ---------------------------------------------------------------------------


def de_waard_lotz_co2_rate(
    T_C: float,
    p_CO2_bar: float,
    *,
    pH: float | None = None,
    f_scale: float = 1.0,
    velocity_m_s: float | None = None,
) -> float:
    """CO2 corrosion rate in mm/yr for carbon-steel pipe in sweet service.

    de Waard-Lotz 1995 baseline (NACE Corrosion 95, paper 128):

        log10(CR_mmyr) = 5.8 − 1710/(T_K) + 0.67 · log10(p_CO2_bar)

    With optional scale-factor and Schmidt-correlation correction:

    * ``f_scale`` (default 1.0) reduces the rate when protective FeCO3 scale
      forms (typically 0.1-0.3 in stable scaling regimes).
    * If ``velocity_m_s`` is given, applies a linear flow factor
      ``f_v = 1 + v/5`` (rate roughly doubles near 5 m/s) as a simplified
      stand-in for the de Waard mass-transfer term.
    * If pH is given, applies de Waard pH correction
      ``f_pH = 10^(−0.55(pH−4))`` — higher pH lowers the rate as protective
      FeCO3 stability increases.

    Reference: de Waard & Lotz 1995, NACE Corrosion 95 paper 128.
    """
    if not all(_is_finite(x) for x in [T_C, p_CO2_bar, f_scale]):
        return float("nan")
    if p_CO2_bar <= 0:
        return 0.0
    T_K = float(T_C) + 273.15
    log_cr = 5.8 - 1710.0 / T_K + 0.67 * math.log10(float(p_CO2_bar))
    cr_mmyr = 10 ** log_cr

    # Optional corrections
    cr_mmyr *= float(f_scale)
    if pH is not None and _is_finite(pH):
        cr_mmyr *= 10 ** (-0.55 * (float(pH) - 4.0))
    if velocity_m_s is not None and _is_finite(velocity_m_s):
        # Schmidt approximation: doubles rate at v ≈ 10 m/s
        f_v = 1.0 + float(velocity_m_s) / 5.0
        cr_mmyr *= f_v

    return max(0.0, cr_mmyr)


# ---------------------------------------------------------------------------
# 2. McConomy 1956 modified — high-T sulfidation
# ---------------------------------------------------------------------------


def mcconomy_sulfidation_rate(
    T_C: float,
    H2S_ppm: float,
    *,
    alloy: Literal["CS", "5Cr", "9Cr", "12Cr", "18Cr-8Ni", "incoloy-800"] = "CS",
) -> float:
    """McConomy 1956 modified high-T sulfidation rate (mm/yr).

    Form: ``log10(CR) = a + b · (1000/T_K) + c · log10(H2S_ppm)``
    Coefficients are alloy-specific (Couper-Gorman 1971 refit).

    Used in refinery FCC, hydrotreater, hydrocracker design.

    Reference: McConomy H.F., Proc. API 43.III (1963) 78; Couper-Gorman 1971.
    """
    if not all(_is_finite(x) for x in [T_C, H2S_ppm]):
        return float("nan")
    if H2S_ppm <= 0:
        return 0.0
    T_K = float(T_C) + 273.15
    coeffs = {
        # (a, b, c) for log10(CR_mmyr) = a + b·(1000/T_K) + c·log10(H2S_ppm).
        # Anchored to API 939-C / Couper-Gorman modified-McConomy curves:
        # carbon steel ~7 mpy (0.18 mm/yr) at 260°C and ~150 mpy (3.8 mm/yr)
        # at 371°C with 1000 ppm H2S ⇒ b≈-4.12 (activation), a≈5.90. Higher-Cr
        # intercepts drop by the standard McConomy multipliers (5Cr~0.5×CS,
        # 9Cr~0.3×, 12Cr~0.1×, 304~0.03×, 800~0.02×).
        "CS":           (5.90, -4.118, 0.36),
        "5Cr":          (5.60, -4.118, 0.34),
        "9Cr":          (5.38, -4.30, 0.32),
        "12Cr":         (4.90, -4.30, 0.30),
        "18Cr-8Ni":     (4.38, -4.50, 0.20),
        "incoloy-800":  (4.20, -4.50, 0.15),
    }
    if alloy not in coeffs:
        return float("nan")
    a, b, c = coeffs[alloy]
    log_cr = a + b * (1000.0 / T_K) + c * math.log10(float(H2S_ppm))
    return max(0.0, 10 ** log_cr)


# ---------------------------------------------------------------------------
# 3. Cassagne 1996 — amine SCC
# ---------------------------------------------------------------------------


def cassagne_amine_scc_rate(
    T_C: float,
    amine_type: Literal["MEA", "DEA", "MDEA", "DIPA"],
    amine_loading: float,
    *,
    co2_loading: float = 0.0,
    stress_ratio_to_yield: float = 0.5,
) -> float:
    """Amine-SCC crack-growth rate in mm/yr for carbon-steel piping.

    Approximate fit to Cassagne 1996 NACE Corrosion 96 paper 393.

    Parameters
    ----------
    T_C: temperature, °C.
    amine_type: MEA / DEA / MDEA / DIPA.
    amine_loading: mass fraction of amine in solution (0-0.5 typical).
    co2_loading: CO2 mole-loading per mol amine (0-1 lean, 1-2 rich).
    stress_ratio_to_yield: applied stress / σ_y; SCC most active 0.3-0.8.

    Returns
    -------
    Crack-growth rate in mm/yr. 0 when conditions are outside the
    susceptibility envelope.
    """
    if not all(_is_finite(x) for x in [T_C, amine_loading, co2_loading, stress_ratio_to_yield]):
        return float("nan")

    # Susceptibility envelope per amine
    envelopes = {
        "MEA":  (T_C >= 60 and T_C <= 120 and amine_loading > 0.10),
        "DEA":  (T_C >= 70 and T_C <= 140 and amine_loading > 0.15),
        "MDEA": (T_C >= 80 and T_C <= 160 and amine_loading > 0.20),
        "DIPA": (T_C >= 60 and T_C <= 130 and amine_loading > 0.15),
    }
    if not envelopes.get(amine_type, False):
        return 0.0
    if stress_ratio_to_yield < 0.3:
        return 0.0

    # Base rate (mm/yr) at T=100°C, σ/σ_y=0.5, lean CO2
    base_rates = {"MEA": 0.5, "DEA": 0.3, "MDEA": 0.15, "DIPA": 0.4}
    base = base_rates.get(amine_type, 0.0)
    # Arrhenius-like T scaling above 60 °C with apparent Q ≈ 70 kJ/mol
    Q_J = 70_000.0
    T_K = float(T_C) + 273.15
    T_ref_K = 373.15
    T_scale = math.exp(-Q_J / R_GAS * (1.0 / T_K - 1.0 / T_ref_K))
    # Stress scaling (Paris-law-style for crack-tip stress intensity)
    stress_scale = ((float(stress_ratio_to_yield) - 0.3) / 0.5) ** 2 if stress_ratio_to_yield > 0.3 else 0.0
    # CO2 loading amplification (rich amine 2× more aggressive)
    co2_scale = 1.0 + min(2.0, float(co2_loading))

    return base * T_scale * stress_scale * co2_scale


# ---------------------------------------------------------------------------
# 4. K_ISCC threshold for hydrogen embrittlement (Gerberich-Wozniak 1984)
# ---------------------------------------------------------------------------


def gerberich_KISCC(
    sigma_y_MPa: float,
    H_concentration_ppm: float,
    *,
    KIc_MPa_sqm: float = 80.0,
) -> float:
    """Gerberich-Wozniak 1984 K_ISCC threshold for sour-service / H-charged
    steels.

    Approximate fit:

        K_ISCC = K_Ic · exp(−H_ppm / H_ref) · (1 − σ_y / σ_y,ref)

    where K_ISCC ≤ K_Ic (drops with both H content and yield strength).
    For sour-service line pipe, K_ISCC is what API 5L Annex H sets the
    fracture-toughness lower bound against.

    Parameters
    ----------
    sigma_y_MPa: alloy yield strength.
    H_concentration_ppm: diffusible hydrogen content (typically 1-10 ppm
        for sour service; > 20 ppm catastrophic).
    KIc_MPa_sqm: base K_Ic (hydrogen-free).

    Returns
    -------
    K_ISCC in MPa·√m.

    Reference: Gerberich-Wozniak 1984; Hardie-Charles 1985 review.
    """
    if not all(_is_finite(x) for x in [sigma_y_MPa, H_concentration_ppm, KIc_MPa_sqm]):
        return float("nan")
    H_ref = 8.0  # ppm — characteristic decay scale
    sigma_y_ref = 1400.0  # MPa — extreme HSLA
    if H_concentration_ppm < 0:
        return float(KIc_MPa_sqm)
    factor_H = math.exp(-float(H_concentration_ppm) / H_ref)
    factor_sy = max(0.0, 1.0 - float(sigma_y_MPa) / sigma_y_ref)
    return max(0.0, float(KIc_MPa_sqm) * factor_H * factor_sy)


# ---------------------------------------------------------------------------
# 5. NACE TM0177 / MR0175 sour-service envelope
# ---------------------------------------------------------------------------


@dataclass
class SourServiceEnvelope:
    """NACE MR0175 / ISO 15156-2023 sour-service qualification verdict."""

    passed: bool
    envelope_region: Literal["region-0", "region-1", "region-2", "region-3"]
    """Region 0 = sweet (no qualification needed); region 1-3 = increasing
    severity (more restrictive limits per ISO 15156-2)."""

    HV_max_required: float
    """Max allowable Vickers hardness per region."""

    notes: list[str] = field(default_factory=list)


def nace_mr0175_envelope(
    pH2S_bar: float,
    pH_field: float,
    *,
    chloride_mg_L: float = 0.0,
    free_H2O: bool = True,
) -> SourServiceEnvelope:
    """NACE MR0175 / ISO 15156-2-2023 sour-service region.

    Region rules (simplified from Figure 1):

    * ``region-0``: p(H2S) ≤ 0.0003 MPa (3 mbar) — sweet.
    * ``region-1``: p(H2S) ≤ 0.003 MPa AND pH ≥ 5.5 — mild sour.
    * ``region-2``: p(H2S) ≤ 0.03 MPa AND pH ≥ 4.5 — sour.
    * ``region-3``: anywhere else (severe sour).

    Max-HV envelope is region-dependent for carbon-steel base metal
    (NACE MR0175-2023 Annex A.2.1.2):

    * Region 0: not required.
    * Region 1: HV ≤ 250.
    * Region 2: HV ≤ 248.
    * Region 3: HV ≤ 237.

    For weld HAZ: 22 HRC max (~248 HV).

    Reference: NACE MR0175 / ISO 15156-2 (2023).
    """
    if not all(_is_finite(x) for x in [pH2S_bar, pH_field]):
        return SourServiceEnvelope(
            passed=False, envelope_region="region-3",
            HV_max_required=237.0,
            notes=["Non-finite input — default to most restrictive region."],
        )

    if not free_H2O or pH2S_bar < 0.003:
        region = "region-0"
        hv_max = 1e9  # not restricted
        passed = True
        notes = [f"Sweet service: p(H2S) = {pH2S_bar:.5f} bar < 0.0003 MPa threshold."]
    elif pH2S_bar < 0.03 and pH_field >= 5.5:
        region = "region-1"
        hv_max = 250.0
        passed = True
        notes = ["Region 1 (mild sour): HV ≤ 250 per NACE MR0175 Annex A.2.1.2."]
    elif pH2S_bar < 0.3 and pH_field >= 4.5:
        region = "region-2"
        hv_max = 248.0
        passed = True
        notes = ["Region 2 (sour): HV ≤ 248 per NACE MR0175 Annex A.2.1.2."]
    else:
        region = "region-3"
        hv_max = 237.0
        passed = True
        notes = [f"Region 3 (severe sour): p(H2S) = {pH2S_bar:.3f} bar, pH = {pH_field:.2f}.",
                 "HV ≤ 237 (≤ 22 HRC); strict qualification required."]

    if chloride_mg_L > 50_000:
        notes.append(f"High Cl⁻ ({chloride_mg_L:.0f} mg/L) — pitting risk; "
                    "additional MR0175 Annex H.1 chloride-SCC checks needed.")

    return SourServiceEnvelope(
        passed=passed, envelope_region=region, HV_max_required=hv_max, notes=notes
    )


# ---------------------------------------------------------------------------
# 6. Galvele 1976 pitting potential
# ---------------------------------------------------------------------------


def galvele_pitting_potential(
    chloride_concentration_M: float,
    *,
    alloy: Literal["304", "316", "316L", "duplex-2205", "S31603", "alloy-825"] = "316L",
    T_C: float = 25.0,
) -> float:
    """Galvele 1976 pitting potential vs SCE (V).

    ``E_pit = E_pit,0 − slope · log10(c_Cl)``

    Default coefficients are calibrated against Frankel-Newman 1993 stainless
    steel review (also Hu-Cheng 2008).

    Parameters
    ----------
    chloride_concentration_M: Cl⁻ molarity (mol/L).
    alloy: which Fe-Cr-Ni-Mo stainless.
    T_C: temperature, °C.

    Returns
    -------
    E_pit in V vs SCE. Negative values mean spontaneous pitting at OCP.

    Reference: Galvele J.R., J. Electrochem. Soc. 123 (1976) 464.
    """
    if not all(_is_finite(x) for x in [chloride_concentration_M, T_C]):
        return float("nan")
    if chloride_concentration_M <= 0:
        return float("inf")  # no Cl, no pitting

    e_0_lookup = {
        # (E_pit,0 V vs SCE at 1 M Cl, 25°C, slope in V/decade)
        "304":           (0.20, 0.094),
        "316":           (0.32, 0.087),
        "316L":          (0.38, 0.087),
        "duplex-2205":   (0.55, 0.083),
        "S31603":        (0.38, 0.087),
        "alloy-825":     (0.60, 0.080),
    }
    if alloy not in e_0_lookup:
        return float("nan")
    E_0, slope = e_0_lookup[alloy]
    E_pit = E_0 - slope * math.log10(float(chloride_concentration_M))

    # Linear T correction: -2 mV / °C above 25
    E_pit -= 0.002 * (float(T_C) - 25.0)
    return E_pit


# ---------------------------------------------------------------------------
# 7. Krom-Bakker hydrogen permeation flux
# ---------------------------------------------------------------------------


def krom_bakker_H_flux(
    sigma_normal_MPa: float,
    T_C: float,
    *,
    D_lattice_m2_s: float = 1e-8,
    C_H_subsurface_ppm: float = 1.0,
    Vh_m3_mol: float = 2.0e-6,
    thickness_mm: float = 12.5,
) -> float:
    """Krom-Bakker 2000 hydrogen permeation flux for pipeline steels.

    Steady-state flux through a wall under stress + concentration gradient:

        J = (D · C_sub / L) · exp(V_H · σ / RT)

    The stress term enhances permeation in regions of tensile triaxiality
    (e.g. crack tip, T-joint root).

    Parameters
    ----------
    sigma_normal_MPa: normal stress at the surface (tensile +).
    T_C: temperature, °C.
    D_lattice_m2_s: hydrogen lattice diffusivity at T.
    C_H_subsurface_ppm: sub-surface H concentration.
    Vh_m3_mol: partial molar volume of H in lattice (~2e-6 for α-Fe).
    thickness_mm: wall thickness.

    Returns
    -------
    Permeation flux in mol/m²/s.

    Reference: Krom A.H.M., Bakker A.D.E., Met. Trans. A 31 (2000) 1475.
    """
    if not all(_is_finite(x) for x in [sigma_normal_MPa, T_C, D_lattice_m2_s,
                                       C_H_subsurface_ppm, thickness_mm]):
        return float("nan")
    if thickness_mm <= 0 or D_lattice_m2_s < 0:
        return float("nan")
    T_K = float(T_C) + 273.15
    L_m = float(thickness_mm) * 1e-3
    C_sub_mol_m3 = float(C_H_subsurface_ppm) * 7850.0 / 1.008 / 1e6  # ppm → mol/m³ for steel
    sigma_Pa = float(sigma_normal_MPa) * 1e6
    arrhenius = math.exp(float(Vh_m3_mol) * sigma_Pa / (R_GAS * T_K))
    return float(D_lattice_m2_s) * C_sub_mol_m3 / L_m * arrhenius


# ---------------------------------------------------------------------------
# 8. Arrhenius corrosion rate (general)
# ---------------------------------------------------------------------------


def arrhenius_corrosion_rate(
    T_C: float,
    *,
    A: float,
    Q_kJ_mol: float,
    reference_rate_at_T_ref_mmyr: float | None = None,
    T_ref_C: float = 25.0,
) -> float:
    """General Arrhenius corrosion-rate scaling.

    Either provide ``A`` (J/mol or pre-exponential) directly:

        CR = A · exp(−Q / RT)

    or provide a ``reference_rate_at_T_ref_mmyr`` to scale from:

        CR(T) = CR(T_ref) · exp(−Q/R · (1/T − 1/T_ref))

    Returns CR in mm/yr.
    """
    if not all(_is_finite(x) for x in [T_C, A, Q_kJ_mol]):
        return float("nan")
    T_K = float(T_C) + 273.15
    if T_K <= 0:
        return float("nan")
    Q_J = float(Q_kJ_mol) * 1000.0
    if reference_rate_at_T_ref_mmyr is not None:
        T_ref_K = float(T_ref_C) + 273.15
        return float(reference_rate_at_T_ref_mmyr) * math.exp(-Q_J / R_GAS * (1.0 / T_K - 1.0 / T_ref_K))
    return float(A) * math.exp(-Q_J / (R_GAS * T_K))


def _is_finite(x) -> bool:
    try:
        return math.isfinite(float(x))
    except (TypeError, ValueError):
        return False


__all__ = [
    "de_waard_lotz_co2_rate",
    "mcconomy_sulfidation_rate",
    "cassagne_amine_scc_rate",
    "gerberich_KISCC",
    "SourServiceEnvelope",
    "nace_mr0175_envelope",
    "galvele_pitting_potential",
    "krom_bakker_H_flux",
    "arrhenius_corrosion_rate",
]
