"""CALPHAD equilibrium and ternary-diagram queries.

This module is the public surface for ``au.calphad.equilibrium`` and
``au.calphad.ternary``. By default each call goes over HTTP to the
Austenite engine. When the environment variable ``AUSTENITE_OFFLINE=1`` is
set (or when the HTTP call fails for any reason) the native pure-Python
solver in :mod:`austenite._calphad_native` is used instead, so the
package can be evaluated entirely offline.

The native solver implements the Hillert-Staffansson 1970 / Sundman-Ågren
1981 compound-energy formalism with Redlich-Kister excess, Inden-Hillert-
Jarl 1978 magnetic ordering, and a scipy common-tangent polish; see the
module docstring there for the full reference list.
"""

from __future__ import annotations

import os
from typing import Any, Mapping, Optional

from ._client import get_default_client
from ._exceptions import AusteniteError
from ._models import (
    CalphadEquilibriumInput,
    CalphadEquilibriumResult,
    CalphadTernaryInput,
    CalphadTernaryResult,
    PhaseFraction,
)

# Native solver — kept as a separate import so it can be re-exported.
from . import _calphad_native as native
from ._calphad_native import (  # noqa: F401 — re-exported for offline users
    NativeEquilibriumResult,
    NativePhase,
    equilibrium_native,
)

# Extended line-compound + alloy-system registry (Fe-C, Al-Cu, Ni-Al, Ti-Al)
from ._calphad_extended import (  # noqa: F401
    ALLOY_SYSTEMS,
    LINE_COMPOUND_LIBRARY,
    LineCompound,
    identify_system,
    line_compound_g,
    predict_precipitates,
)


def precipitates(
    composition: Mapping[str, float],
    T_K: float,
) -> dict:
    """First-pass screen: which line compounds are thermodynamically
    stable for ``composition`` at temperature ``T_K``?

    Fast offline call — does not run the full equilibrium solver, only
    checks the line-compound Gibbs energy vs the weighted pure-element
    reference (the "stability test").

    Supported alloy systems: Fe-C, Fe-Cr-C, Fe-Cr-Mo-C (steels);
    Al-Cu, Al-Mg, Al-Cu-Mg (Al alloys); Ni-Al (Ni superalloys);
    Ti-Al (titanium aluminides).

    Examples
    --------
    >>> import austenite as au
    >>> r = au.calphad.precipitates(
    ...     composition={"Fe": 0.97, "Cr": 0.01, "Mo": 0.002, "C": 0.018},
    ...     T_K=873,
    ... )
    >>> r["system"]
    'fe-cr-mo-c'
    >>> [c["name"] for c in r["stable_compounds"]]
    ['M23C6', 'CEMENTITE']

    See ``au.calphad.ALLOY_SYSTEMS`` for the full registry and
    ``au.calphad.LINE_COMPOUND_LIBRARY`` for individual compound data.
    """
    # Use the native pure_g function for elements covered by the existing
    # native solver (Fe, Cr, Ni) so the stability test integrates both data
    # sources seamlessly.
    return predict_precipitates(
        composition=composition,
        T_K=T_K,
        pure_g_func=native.pure_g,
    )


def _offline_requested() -> bool:
    """``AUSTENITE_OFFLINE=1`` (or any truthy value) skips the HTTP path."""

    val = os.environ.get("AUSTENITE_OFFLINE", "").strip().lower()
    return val in {"1", "true", "yes", "on"}


def _native_result_to_model(
    res: NativeEquilibriumResult,
) -> CalphadEquilibriumResult:
    """Wrap a :class:`NativeEquilibriumResult` in the Pydantic output model.

    The result is forward-compatible with the HTTP response — extra
    fields (``G``, ``activities``, ``method``, ``backend=native``) are
    carried via the model's ``extra="allow"`` config so callers see the
    same shape on either path.
    """

    return CalphadEquilibriumResult.model_validate(
        {
            "T_K": res.T_K,
            "phases": [
                {
                    "phase": ph.phase,
                    "fraction": ph.fraction,
                    "composition": ph.composition,
                }
                for ph in res.phases
            ],
            "citations": [
                {
                    "source": "Hillert & Staffansson, Acta Chem. Scand. 24 (1970) 3618",
                    "note": "Compound-energy formalism (regular-solution sublattice model)",
                },
                {
                    "source": "Sundman & Ågren, J. Phys. Chem. Solids 42 (1981) 297",
                    "note": "Multi-sublattice CEF computer implementation",
                },
                {
                    "source": "Hillert & Jarl, CALPHAD 2 (1978) 227",
                    "note": "Magnetic ordering Gibbs-energy contribution",
                },
                {
                    "source": "Andersson, CALPHAD 11 (1987) 83",
                    "note": "Fe-Cr binary assessment (Andersson 1985 Fe-Cr)",
                },
            ],
            "G": res.G,
            "activities": res.activities,
            "method": res.method,
            "polished": res.polished,
            "grid_points": res.grid_points,
            "backend": "native",
        }
    )


def equilibrium(
    *,
    composition: Mapping[str, float],
    T_K: float,
    P_Pa: float = 101_325.0,
    database: Optional[str] = None,
    backend: Optional[str] = None,
    **kwargs: Any,
) -> CalphadEquilibriumResult:
    """Compute the equilibrium phase assemblage at (T, P, composition).

    Args:
        composition: Mole-fraction composition map (element → fraction).
            Pass ``composition_basis="wt"`` via ``kwargs`` to interpret as
            weight percent (consumed by the native fallback only).
        T_K: Temperature in kelvin.
        P_Pa: Pressure in pascals (default 1 atm). The native solver
            ignores pressure (condensed-phase only).
        database: Optional CALPHAD database identifier (e.g. ``"TCFE12"``).
        backend: One of ``"http"`` (force HTTP), ``"native"`` (force
            offline solver), or ``None`` (default: HTTP first, native
            fallback on error, native if ``AUSTENITE_OFFLINE`` is set).

    Returns:
        :class:`CalphadEquilibriumResult` with phase fractions, per-phase
        compositions, and (native backend only) total Gibbs energy and
        per-element activities.
    """

    composition_basis = kwargs.pop("composition_basis", "mole")
    use_native = backend == "native" or (backend is None and _offline_requested())

    if not use_native:
        try:
            payload = CalphadEquilibriumInput(
                composition=composition,
                T_K=T_K,
                P_Pa=P_Pa,
                database=database,
                **kwargs,
            )
            client = get_default_client()
            response = client.post(
                "/v1/calphad/equilibrium",
                json=payload.model_dump(exclude_none=True),
            )
            return CalphadEquilibriumResult.model_validate(response.json())
        except AusteniteError:
            if backend == "http":
                raise
            # silent fallback to native — keeps offline workflows alive

    res = equilibrium_native(
        composition=composition,
        T_K=T_K,
        composition_basis=composition_basis,
    )
    return _native_result_to_model(res)


def ternary(
    *,
    elements: list[str],
    T_K: float,
    n_grid: int = 50,
    database: Optional[str] = None,
    backend: Optional[str] = None,
    **kwargs: Any,
) -> CalphadTernaryResult:
    """Return a sampled ternary isothermal section.

    Args:
        elements: Exactly 3 element symbols (e.g. ``["Fe", "Cr", "Ni"]``).
        T_K: Temperature in kelvin.
        n_grid: Resolution along each side of the simplex.
        database: Optional database identifier.
        backend: ``"http"``, ``"native"``, or ``None`` (HTTP first, native
            fallback). The native ternary scan calls
            :func:`equilibrium_native` at each grid node — slow for fine
            grids but exact under the engine's model.
    """

    if len(elements) != 3:
        raise ValueError(f"ternary() requires exactly 3 elements, got {len(elements)}")

    use_native = backend == "native" or (backend is None and _offline_requested())

    if not use_native:
        try:
            payload = CalphadTernaryInput(
                elements=elements,
                T_K=T_K,
                n_grid=n_grid,
                database=database,
                **kwargs,
            )
            client = get_default_client()
            response = client.post(
                "/v1/calphad/ternary",
                json=payload.model_dump(exclude_none=True),
            )
            return CalphadTernaryResult.model_validate(response.json())
        except AusteniteError:
            if backend == "http":
                raise

    # Native ternary: scan the simplex calling equilibrium_native per node.
    els = [e.upper() for e in elements]
    grid: list[dict[str, Any]] = []
    div = max(2, int(n_grid))
    for i in range(div + 1):
        for j in range(div + 1 - i):
            k = div - i - j
            x1, x2, x3 = i / div, j / div, k / div
            comp = {els[0]: x1, els[1]: x2, els[2]: x3}
            if any(v <= 0 for v in comp.values()):
                # avoid log singularities; nudge with a small floor
                comp = {e: max(v, 1e-6) for e, v in comp.items()}
                s = sum(comp.values())
                comp = {e: v / s for e, v in comp.items()}
            try:
                res = equilibrium_native(composition=comp, T_K=T_K)
                phases = [
                    {"phase": p.phase, "fraction": p.fraction} for p in res.phases
                ]
            except Exception:
                phases = []
            grid.append(
                {
                    "x": {els[0]: x1, els[1]: x2, els[2]: x3},
                    "phases": phases,
                }
            )
    return CalphadTernaryResult.model_validate(
        {
            "elements": els,
            "T_K": T_K,
            "grid": grid,
            "backend": "native",
        }
    )


__all__ = [
    "equilibrium",
    "ternary",
    "equilibrium_native",
    "NativePhase",
    "NativeEquilibriumResult",
    "native",
]
