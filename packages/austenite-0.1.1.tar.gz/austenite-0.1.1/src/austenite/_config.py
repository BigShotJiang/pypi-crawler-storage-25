"""Global configuration for the austenite client.

Users can override defaults via :func:`austenite.set_api_url`,
:func:`austenite.set_timeout`, and :func:`austenite.set_api_key`.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


DEFAULT_API_URL = "https://api.austenite.org"
DEFAULT_TIMEOUT_SECONDS = 60.0
DEFAULT_MAX_RETRIES = 3
DEFAULT_BACKOFF_FACTOR = 0.5  # exponential: 0.5s, 1s, 2s
DEFAULT_USER_AGENT_TEMPLATE = "austenite-py/0.1.0 python/{py_version}"


@dataclass
class ClientConfig:
    """Mutable configuration shared by the default client."""

    api_url: str = DEFAULT_API_URL
    timeout: float = DEFAULT_TIMEOUT_SECONDS
    max_retries: int = DEFAULT_MAX_RETRIES
    backoff_factor: float = DEFAULT_BACKOFF_FACTOR
    api_key: Optional[str] = None
    extra_headers: dict[str, str] = field(default_factory=dict)


# Module-level singleton — mutated by the public setter functions.
_config = ClientConfig()


def get_config() -> ClientConfig:
    """Return the active configuration (mutable singleton)."""

    return _config
