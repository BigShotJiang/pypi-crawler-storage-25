"""Typed exceptions raised by the austenite client.

The exception hierarchy mirrors the categories of error a caller is likely to
want to handle differently:

* :class:`ValidationError` — server rejected the input (HTTP 4xx other than 429).
* :class:`RateLimitError` — HTTP 429; caller should back off.
* :class:`EngineError` — HTTP 5xx; the engine itself failed.
* :class:`NetworkError` — transport-level failure (timeout, DNS, connection).
"""

from __future__ import annotations

from typing import Any, Optional


class AusteniteError(Exception):
    """Base class for all austenite client errors."""

    def __init__(
        self,
        message: str,
        *,
        status_code: Optional[int] = None,
        response_body: Optional[Any] = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.response_body = response_body

    def __str__(self) -> str:  # pragma: no cover - trivial
        if self.status_code is not None:
            return f"[{self.status_code}] {self.message}"
        return self.message


class ValidationError(AusteniteError):
    """Server returned 4xx (other than 429) — typically a bad payload."""


class RateLimitError(AusteniteError):
    """Server returned HTTP 429 Too Many Requests."""


class EngineError(AusteniteError):
    """Server returned 5xx — the engine itself failed."""


class NetworkError(AusteniteError):
    """Transport-level failure (timeout, DNS error, connection reset)."""
