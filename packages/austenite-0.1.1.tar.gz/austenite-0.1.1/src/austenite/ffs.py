"""API 579-1 / ASME FFS-1 Fitness-For-Service workflows — Wedge D.

Engineers write::

    import austenite as au, pandas as pd

    # General metal loss (Part 5) — the workhorse FFS
    result = au.ffs.api_579_part_5(
        geometry={"type": "cylinder", "OD_mm": 500, "wall_mm": 12.5},
        thickness_map=pd.read_csv("UT_readings_2026.csv"),
        T_C=400, P_MPa=2.5,
        material="SA-516-70",
        edition="API 579-1 2021-12",
    )
    result.level                           # 'Level-2 acceptable'
    result.remaining_life_years            # 12.3
    result.t_min_mm                         # 8.7
    result.MAWP_MPa                         # 2.85
    result.report.export_pdf("V-2401_FFS.pdf")
    result.report.export_xlsx("V-2401_FFS.xlsx")

The Python wrapper posts the request body to the corresponding Cloudflare
Worker route (``/v1/ffs/api-579/part-{5,6,9}``), validates the JSON envelope
against the :class:`FFSResult` model, and attaches a :class:`FFSReport`
helper that writes ASME-Section-VIII-style PDF and XLSX deliverables.

Editions handled:
    * ``"API 579-1 2021-12"``  — Annex E worked examples baseline.
    * ``"API 579-1 2024-09"``  — FAD numerics unchanged; ``Annex 9C`` re-aliased
      (a note is appended automatically when the verdict shifts).

References:
    API 579-1 / ASME FFS-1 (2021 + 2024 editions)
    ASME BPVC Section II Part D (2021) — allowable-stress tables
    BS 7910:2019 — fitness-for-service of metallic structures
    Anderson T.L., "Fracture Mechanics" 4th ed., §11.5
    Newman J.C. & Raju I.S., NASA TM-83200 (1982) — K-solutions
    Kiefner & Vieth, PRCI PR-3-805 (1989) — modified B31G
    Kowaka, M. (1994), "Life Prediction of Industrial Plant Materials"
"""

from __future__ import annotations

import json
import math
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Literal, Mapping, Optional, Sequence, Union

from pydantic import BaseModel, ConfigDict, Field

from . import _ffs_extensions as extensions
from . import _ffs_native as native
from ._client import get_default_client
from ._exceptions import AusteniteError, ValidationError

__all__ = [
    "api_579_part_4",
    "api_579_part_5",
    "api_579_part_5_lta",
    "api_579_part_6",
    "api_579_part_7",
    "api_579_part_8",
    "api_579_part_9",
    "api_579_part_11",
    "api_579_part_12",
    "api_579_part_14",
    "FFSResult",
    "FFSReport",
    "FFSGeometry",
    "FFSMaterial",
    "FFSCrack",
    "FFSPit",
    "extensions",
    "native",
]

# ---------------------------------------------------------------------------
# Edition catalogue
# ---------------------------------------------------------------------------

_EDITIONS: tuple[str, ...] = ("API 579-1 2021-12", "API 579-1 2024-09")
_EDITION_ALIASES = {
    "2021-12": "API 579-1 2021-12",
    "2024-09": "API 579-1 2024-09",
    "2021": "API 579-1 2021-12",
    "2024": "API 579-1 2024-09",
    "2024-12": "API 579-1 2024-09",
}


def _normalise_edition(edition: Optional[str]) -> str:
    if edition is None:
        return "API 579-1 2021-12"
    if edition in _EDITIONS:
        return edition
    if edition in _EDITION_ALIASES:
        return _EDITION_ALIASES[edition]
    raise ValidationError(
        f"Unknown FFS edition {edition!r}; allowed: {', '.join(_EDITIONS)} "
        f"(aliases also accepted: {', '.join(_EDITION_ALIASES)})."
    )


# ---------------------------------------------------------------------------
# Pydantic input/output models
# ---------------------------------------------------------------------------


class _BaseInput(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)


class _BaseOutput(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True, arbitrary_types_allowed=True)


class FFSGeometry(_BaseInput):
    """Shell geometry of the component under assessment."""

    type: Literal["cylinder", "sphere", "pipe"] = "cylinder"
    OD_mm: float
    wall_mm: float
    FCA_mm: Optional[float] = None
    joint_efficiency: Optional[float] = 1.0
    grid_spacing_mm: Optional[float] = 25.0


class FFSMaterial(_BaseInput):
    """Material reference — either ASME II-D spec name or explicit values."""

    spec: str
    Sy_MPa: Optional[float] = None
    Suts_MPa: Optional[float] = None
    S_MPa: Optional[float] = None


class FFSCrack(_BaseInput):
    """Crack-like flaw input for Part 9."""

    a_mm: float
    c_mm: float
    type: Literal["surface", "through", "corner"] = "surface"


class FFSPit(_BaseInput):
    """Single pit datum for Part 6."""

    max_depth_mm: float
    diameter_mm: float
    density_per_mm2: Optional[float] = None


class FFSResult(_BaseOutput):
    """Normalised FFS verdict — used by all three Parts (5/6/9).

    Attributes:
        level: One of ``'Level-1'``, ``'Level-2'``, ``'Level-3'`` or
            ``'unacceptable'``.
        remaining_life_years: Predicted remaining life at the supplied
            corrosion rate (or `math.inf` if none provided).
        t_min_mm: Code-required minimum wall thickness (mm).
        MAWP_MPa: Maximum-allowable working pressure (MPa), already derated
            via Eq. 2.5 (API 579-1 §2.4.2.2) when RSF < RSF_a.
        fad_point: For Part 9 only — the (L_r, K_r) operating point on the
            Failure Assessment Diagram.
        distance_to_curve: For Part 9 only — radial reserve factor R.  R≥1
            means the operating point lies inside the FAD curve.
        notes: Multi-line analysis trace appended to the report.
        report: :class:`FFSReport` helper with ``export_pdf`` / ``export_xlsx``.
        citations: ASCII list of literature references supporting the verdict.
        edition: Edition tag that produced the verdict (echoed for audit).
        audit_record: Fully-serialisable dict suitable for
            :func:`austenite.audit.record`.
    """

    level: Literal["Level-1", "Level-2", "Level-3", "unacceptable"]
    remaining_life_years: float
    t_min_mm: float
    MAWP_MPa: float
    fad_point: Optional[tuple[float, float]] = None
    distance_to_curve: Optional[float] = None
    notes: list[str] = Field(default_factory=list)
    citations: list[str] = Field(default_factory=list)
    edition: str
    audit_record: dict[str, Any] = Field(default_factory=dict)
    # Internal fields — not serialised back through the API but populated
    # client-side so callers can drive the report writer without keeping the
    # raw envelope around.
    report: Optional["FFSReport"] = Field(default=None, exclude=True)
    part: Optional[str] = None
    RSF: Optional[float] = None

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        return (
            f"<FFSResult part={self.part} level={self.level!r} "
            f"MAWP={self.MAWP_MPa:.3f} MPa life={self.remaining_life_years:.1f} y "
            f"edition={self.edition!r}>"
        )


# ---------------------------------------------------------------------------
# Helper — pandas / dict / list shapes → list[dict]
# ---------------------------------------------------------------------------


def _thickness_map_to_payload(data: Any) -> Union[list[float], list[dict[str, float]]]:
    """Normalise a thickness map into a JSON-serialisable structure.

    Accepts:
      - ``pandas.DataFrame`` with columns ``thickness_mm`` and optional ``x_mm`` / ``y_mm``;
      - ``list[dict]`` already shaped like ``{x_mm, y_mm?, thickness_mm}``;
      - flat ``list[float]`` / ``tuple[float, ...]``;
      - any iterable that yields the above.
    """

    # Handle pandas DataFrame
    try:
        import pandas as pd  # type: ignore

        if isinstance(data, pd.DataFrame):
            df = data
            cols = {c.lower(): c for c in df.columns}
            if "thickness_mm" in cols:
                t_col = cols["thickness_mm"]
            elif "t_mm" in cols:
                t_col = cols["t_mm"]
            elif "thickness" in cols:
                t_col = cols["thickness"]
            else:
                # Single-column DataFrame: assume the only column is thickness
                if df.shape[1] == 1:
                    return [float(v) for v in df.iloc[:, 0].tolist()]
                raise ValidationError(
                    f"DataFrame must include a 'thickness_mm' column "
                    f"(found columns: {list(df.columns)})."
                )
            x_col = cols.get("x_mm") or cols.get("x")
            y_col = cols.get("y_mm") or cols.get("y")
            if x_col is not None or y_col is not None:
                rows: list[dict[str, float]] = []
                for _, r in df.iterrows():
                    rec: dict[str, float] = {"thickness_mm": float(r[t_col])}
                    if x_col is not None:
                        rec["x_mm"] = float(r[x_col])
                    if y_col is not None:
                        rec["y_mm"] = float(r[y_col])
                    rows.append(rec)
                return rows
            return [float(v) for v in df[t_col].tolist()]
    except ImportError:  # pragma: no cover - pandas absent
        pass

    # Already a sequence of dicts
    if isinstance(data, (list, tuple)) and len(data) > 0 and isinstance(data[0], Mapping):
        out_rows: list[dict[str, float]] = []
        for item in data:
            assert isinstance(item, Mapping)
            if "thickness_mm" not in item:
                raise ValidationError(
                    "Each thickness_map row must include 'thickness_mm'."
                )
            rec = {"thickness_mm": float(item["thickness_mm"])}
            if "x_mm" in item:
                rec["x_mm"] = float(item["x_mm"])
            if "y_mm" in item:
                rec["y_mm"] = float(item["y_mm"])
            out_rows.append(rec)
        return out_rows

    # Plain list/tuple of numbers
    if isinstance(data, (list, tuple)):
        try:
            return [float(v) for v in data]
        except (TypeError, ValueError) as exc:
            raise ValidationError(f"thickness_map must contain numeric values: {exc}") from exc

    raise ValidationError(
        f"Unsupported thickness_map type {type(data).__name__}. "
        f"Expected pandas.DataFrame, list[dict] or list[float]."
    )


def _pit_data_to_payload(data: Any) -> list[dict[str, float]]:
    """Normalise pit_data into a list of {max_depth_mm, diameter_mm, density_per_mm2?}.

    Accepts pandas DataFrame, list of dicts, or list of FFSPit instances.
    """

    try:
        import pandas as pd  # type: ignore

        if isinstance(data, pd.DataFrame):
            df = data
            cols_lower = {c.lower(): c for c in df.columns}
            need_depth = next(
                (c for k, c in cols_lower.items() if k in {"max_depth", "max_depth_mm", "depth", "depth_mm"}),
                None,
            )
            need_diam = next(
                (c for k, c in cols_lower.items() if k in {"diameter", "diameter_mm", "diam", "d_mm"}),
                None,
            )
            density_col = next(
                (c for k, c in cols_lower.items() if k in {"density_per_mm2", "density", "n_per_mm2"}),
                None,
            )
            if need_depth is None or need_diam is None:
                raise ValidationError(
                    "Pit DataFrame needs 'max_depth_mm' (or 'depth') and 'diameter_mm' (or 'diameter') columns."
                )
            rows: list[dict[str, float]] = []
            for _, r in df.iterrows():
                rec: dict[str, float] = {
                    "max_depth_mm": float(r[need_depth]),
                    "diameter_mm": float(r[need_diam]),
                }
                if density_col is not None:
                    val = r[density_col]
                    if val is not None and not (isinstance(val, float) and math.isnan(val)):
                        rec["density_per_mm2"] = float(val)
                rows.append(rec)
            return rows
    except ImportError:  # pragma: no cover
        pass

    if isinstance(data, (list, tuple)):
        out: list[dict[str, float]] = []
        for item in data:
            if isinstance(item, FFSPit):
                out.append(item.model_dump(exclude_none=True))
                continue
            if isinstance(item, Mapping):
                if "max_depth_mm" not in item or "diameter_mm" not in item:
                    raise ValidationError(
                        "Each pit record needs 'max_depth_mm' and 'diameter_mm'."
                    )
                rec: dict[str, float] = {
                    "max_depth_mm": float(item["max_depth_mm"]),
                    "diameter_mm": float(item["diameter_mm"]),
                }
                if "density_per_mm2" in item and item["density_per_mm2"] is not None:
                    rec["density_per_mm2"] = float(item["density_per_mm2"])
                out.append(rec)
                continue
            raise ValidationError(
                f"Pit record must be FFSPit, mapping, or DataFrame row — got {type(item).__name__}."
            )
        return out

    raise ValidationError(
        f"Unsupported pit_data type {type(data).__name__}. "
        f"Expected pandas.DataFrame or list of dict/FFSPit."
    )


def _material_to_payload(material: Union[str, FFSMaterial, Mapping[str, Any]]) -> dict[str, Any]:
    if isinstance(material, str):
        return {"spec": material}
    if isinstance(material, FFSMaterial):
        return material.model_dump(exclude_none=True)
    if isinstance(material, Mapping):
        if "spec" not in material:
            raise ValidationError("material mapping must include 'spec'.")
        return dict(material)
    raise ValidationError(
        f"material must be str, FFSMaterial, or mapping — got {type(material).__name__}."
    )


def _geometry_to_payload(geometry: Union[FFSGeometry, Mapping[str, Any]]) -> dict[str, Any]:
    if isinstance(geometry, FFSGeometry):
        return geometry.model_dump(exclude_none=True)
    if isinstance(geometry, Mapping):
        return FFSGeometry.model_validate(geometry).model_dump(exclude_none=True)
    raise ValidationError(
        f"geometry must be FFSGeometry or mapping — got {type(geometry).__name__}."
    )


def _crack_to_payload(crack: Union[FFSCrack, Mapping[str, Any]]) -> dict[str, Any]:
    if isinstance(crack, FFSCrack):
        return crack.model_dump(exclude_none=True)
    if isinstance(crack, Mapping):
        return FFSCrack.model_validate(crack).model_dump(exclude_none=True)
    raise ValidationError(
        f"crack must be FFSCrack or mapping — got {type(crack).__name__}."
    )


# ---------------------------------------------------------------------------
# Local in-process FFS fallback
# ---------------------------------------------------------------------------
#
# When the user hasn't pointed the SDK at a deployed API (or in test mode
# without an httpx_mock for the FFS routes), we run the same physics
# locally so the engineer always gets a verdict.  The formulas mirror the
# TypeScript engine in apps/web/src/lib/ffs/index.ts verbatim — they're
# derived directly from API 579-1 §§4.4 / 5.4 / 6.4 / 9.4.

_DEFAULT_S_ALLOW_BY_SPEC: dict[str, dict[str, float]] = {
    # ASME II-D 2021 Table 1A — coarse mid-temperature snapshot used when the
    # caller pointed the SDK at a non-deployed URL.  Exact match with the TS
    # ALLOWABLE_STRESS_BY_SPEC table at 200 °C.
    "SA-516-70": {"S_MPa": 138, "Sy_MPa": 260, "Suts_MPa": 485},
    "SA-106-B": {"S_MPa": 118, "Sy_MPa": 240, "Suts_MPa": 415},
    "SA-335-P22": {"S_MPa": 118, "Sy_MPa": 207, "Suts_MPa": 415},
    "SA-335-P91": {"S_MPa": 167, "Sy_MPa": 415, "Suts_MPa": 585},
    "SA-240-304": {"S_MPa": 117, "Sy_MPa": 205, "Suts_MPa": 515},
    "SA-240-316": {"S_MPa": 119, "Sy_MPa": 205, "Suts_MPa": 515},
}


def _allowable_from_spec(material: Mapping[str, Any]) -> tuple[float, float, float]:
    if material.get("S_MPa"):
        S = float(material["S_MPa"])
    else:
        rec = _DEFAULT_S_ALLOW_BY_SPEC.get(str(material.get("spec", "")), {})
        S = float(material.get("S_MPa") or rec.get("S_MPa") or 138)
    Sy = float(material.get("Sy_MPa") or _DEFAULT_S_ALLOW_BY_SPEC.get(str(material.get("spec", "")), {}).get("Sy_MPa") or 260)
    Suts = float(material.get("Suts_MPa") or _DEFAULT_S_ALLOW_BY_SPEC.get(str(material.get("spec", "")), {}).get("Suts_MPa") or 485)
    return S, Sy, Suts


def _t_min_cylinder(P: float, OD: float, S: float, E: float) -> float:
    R_i = OD / 2 - 1
    denom = S * E - 0.6 * P
    if denom <= 0:
        return math.inf
    return (P * R_i) / denom


def _t_min_sphere(P: float, OD: float, S: float, E: float) -> float:
    R_i = OD / 2 - 1
    denom = 2 * S * E - 0.2 * P
    if denom <= 0:
        return math.inf
    return (P * R_i) / denom


def _t_min_for_geometry(g: Mapping[str, Any], P: float, S: float) -> float:
    E = float(g.get("joint_efficiency") or 1.0)
    if g.get("type") == "sphere":
        return _t_min_sphere(P, float(g["OD_mm"]), S, E)
    return _t_min_cylinder(P, float(g["OD_mm"]), S, E)


def _base_mawp(g: Mapping[str, Any], S: float, t: float) -> float:
    E = float(g.get("joint_efficiency") or 1.0)
    D = float(g["OD_mm"])
    if g.get("type") == "sphere":
        return (2 * S * E * t) / (D / 2 - 1 + 0.1 * t)
    return (S * E * t) / (D / 2 - 1 + 0.6 * t)


def _local_part5(body: Mapping[str, Any]) -> dict[str, Any]:
    """Delegate Part 5 to the native engine in :mod:`austenite._ffs_native`.

    The legacy in-file implementation is preserved below the dispatch as
    a smoke baseline; the native module mirrors it 1:1 (same constants
    and Folias bulging derivation) so verdicts agree byte-for-byte.
    """

    geo = body["geometry"]
    mat = body["material"]
    P = float(body["P_MPa"])
    edition = body.get("edition") or "API 579-1 2021-12"
    FCA_mm = body.get("FCA_mm")
    if FCA_mm is None:
        FCA_mm = geo.get("FCA_mm")
    CR = body.get("corrosion_rate_mm_per_year") or 0.0
    return native.run_ffs_part5_native(
        geometry=geo,
        thickness_map=body["thickness_map"],
        T_C=float(body.get("T_C", 25.0)),
        P_MPa=P,
        material=mat,
        edition=edition,
        corrosion_rate_mm_per_year=float(CR),
        FCA_mm=float(FCA_mm) if FCA_mm is not None else None,
        lta=body.get("lta"),
    )


def _local_part5_legacy(body: Mapping[str, Any]) -> dict[str, Any]:
    """Legacy inline Part 5 — kept as a reference implementation.

    Used as a parity oracle by the parity tests. The behaviour is
    identical to :func:`_local_part5` (delegating to
    :mod:`austenite._ffs_native`) and was preserved verbatim to keep the
    historical algorithm trail intact.
    """

    geo = body["geometry"]
    mat = body["material"]
    P = float(body["P_MPa"])
    edition = body.get("edition") or "API 579-1 2021-12"
    FCA = float(body.get("FCA_mm") or geo.get("FCA_mm") or 0)
    CR = float(body.get("corrosion_rate_mm_per_year") or 0)
    S, Sy, Suts = _allowable_from_spec(mat)
    t_min = _t_min_for_geometry(geo, P, S)
    tmap = body["thickness_map"]
    if isinstance(tmap, list) and len(tmap) > 0 and isinstance(tmap[0], dict):
        ctp = [float(r["thickness_mm"]) for r in tmap]
    else:
        ctp = [float(v) for v in tmap]
    t_meas_min = min(ctp)
    t_meas_avg = sum(ctp) / len(ctp)
    Rt = (t_meas_min - FCA) / max(t_min, 1e-6)
    level: str = "Level-1"
    RSF = 1.0
    RSF_a = 0.90
    notes: list[str] = []
    # Level-1 screen
    if (t_meas_min - FCA) >= t_min and Rt >= 0.20:
        notes.append(
            f"Level-1: PASS — (t_meas-FCA) = {t_meas_min - FCA:.2f} mm >= t_min = {t_min:.2f} mm; Rt = {Rt:.3f}."
        )
    else:
        notes.append(
            f"Level-1: insufficient — escalating to Level-2 (Rt = {Rt:.3f}, t_meas-FCA = {t_meas_min - FCA:.2f} mm vs t_min = {t_min:.2f} mm)."
        )
        # Level-2 RSF
        D = float(geo["OD_mm"])
        s_grid = float(geo.get("grid_spacing_mm") or 25)
        s_mm = max(s_grid, (len(ctp) - 1) * s_grid)
        lam = s_mm / max(math.sqrt(D * t_min), 1e-9)
        M_t = math.sqrt(1 + 0.48 * lam * lam)
        Rt_l2 = (t_meas_avg - FCA) / max(t_min, 1e-6)
        if Rt_l2 >= 1:
            RSF = 1.0
        else:
            RSF = max(0.0, min(1.0, (1 - Rt_l2) / max(1e-6, 1 - Rt_l2 / M_t)))
        if (t_meas_min - FCA) < 0.20 * t_min:
            level = "Level-3"
            # mock limit-load
            t_eff = max(0.01, t_meas_min - FCA)
            P_L = (4 / math.sqrt(3)) * Sy * t_eff / D
            P_allow = P_L / 1.5
            if P_allow >= P:
                level = "Level-3"
                notes.append(
                    f"Level-3 limit-load: P_collapse = {P_L:.2f} MPa, allowable = {P_allow:.2f} MPa >= P_op = {P:.2f} MPa → PASS."
                )
            else:
                level = "unacceptable"
                notes.append(
                    f"Level-3 FAIL — D/C = {P/P_allow:.2f} > 1.0."
                )
        else:
            level = "Level-2"
            verdict = "PASS" if RSF >= RSF_a else "DERATE"
            notes.append(f"Level-2: {verdict} — RSF = {RSF:.3f}, RSF_a = {RSF_a:.2f}.")

    # MAWP
    MAWP = _base_mawp(geo, S, max(t_meas_min - FCA, 1e-3))
    if RSF < RSF_a:
        MAWP = MAWP * RSF / RSF_a

    # Optional LTA overlay
    if body.get("lta"):
        l = body["lta"]
        s_mm = float(l["s_mm"])
        d_mm = float(l["d_mm"])
        t_nom = float(geo["wall_mm"])
        D = float(geo["OD_mm"])
        lam = s_mm / max(math.sqrt(D * t_nom), 1e-9)
        M_t = math.sqrt(1 + 0.48 * lam * lam)
        RSF_lta = max(0.0, min(1.0, (1 - d_mm / t_nom) / max(1e-6, 1 - d_mm / (t_nom * M_t))))
        RSF = min(RSF, RSF_lta)
        notes.append(f"LTA Folias §4.4.3.3: RSF = {RSF_lta:.3f} (lambda = {lam:.3f}, M_t = {M_t:.3f}).")
        if RSF < RSF_a:
            MAWP = _base_mawp(geo, S, max(t_meas_min - FCA, 1e-3)) * RSF / RSF_a

    margin = max(0.0, t_meas_min - t_min - FCA)
    life = margin / CR if CR > 0 else 1e6

    return {
        "edition": edition,
        "level": level,
        "remaining_life_years": life,
        "t_min_mm": t_min,
        "MAWP_MPa": MAWP,
        "notes": notes,
        "citations": [
            "API 579-1/ASME FFS-1 (2021) §4.4.2 (Level-1)",
            "API 579-1/ASME FFS-1 (2021) §4.4.3 (Level-2 RSF)",
            "API 579-1/ASME FFS-1 (2021) §4.4.4 (Level-3 limit-load)",
            "API 579-1 §4.4.3.3 (LTA Folias bulging)",
            "ASME II-D Table 1A",
            "ASME VIII Div 1 UG-27",
            "Kiefner & Vieth PRCI PR-3-805 (1989)",
            "Folias E.S., Int. J. Fracture Mech. 1 (1965) 104",
        ],
        "RSF": RSF,
        "RSF_a": RSF_a,
        "t_meas_min_mm": t_meas_min,
        "t_meas_avg_mm": t_meas_avg,
        "details": {
            "S_allow_MPa": S,
            "Sy_MPa": Sy,
            "Suts_MPa": Suts,
            "FCA_mm": FCA,
            "corrosion_rate_mm_per_year": CR,
        },
    }


def _local_part6(body: Mapping[str, Any]) -> dict[str, Any]:
    """Delegate Part 6 to :mod:`austenite._ffs_native`."""

    geo = body["geometry"]
    mat = body["material"]
    return native.run_ffs_part6_native(
        geometry=geo,
        pit_data=body["pit_data"],
        T_C=float(body.get("T_C", 25.0)),
        P_MPa=float(body["P_MPa"]),
        material=mat,
        edition=body.get("edition") or "API 579-1 2021-12",
        corrosion_rate_mm_per_year=float(body.get("corrosion_rate_mm_per_year") or 0.0),
    )


def _local_part6_legacy(body: Mapping[str, Any]) -> dict[str, Any]:
    """Legacy inline Part 6 — parity oracle, identical to native."""

    geo = body["geometry"]
    mat = body["material"]
    P = float(body["P_MPa"])
    edition = body.get("edition") or "API 579-1 2021-12"
    FCA = float(geo.get("FCA_mm") or 0)
    CR = float(body.get("corrosion_rate_mm_per_year") or 0)
    S, Sy, Suts = _allowable_from_spec(mat)
    t_nom = float(geo["wall_mm"])
    D = float(geo["OD_mm"])
    t_min = _t_min_for_geometry(geo, P, S)
    pits = list(body["pit_data"])
    if not pits:
        raise ValidationError("Part 6 requires at least one pit record.")
    depths = [float(p["max_depth_mm"]) for p in pits]
    diams = [float(p["diameter_mm"]) for p in pits]
    d_max = max(depths)
    d_avg = sum(depths) / len(depths)
    A_pits = sum(math.pi * (d / 2) ** 2 for d in diams)
    if pits[0].get("density_per_mm2"):
        A_inspect = len(pits) / float(pits[0]["density_per_mm2"])
    else:
        A_inspect = max(1e6, A_pits * 100)
    phi = A_pits / A_inspect
    density_per_100mm2 = (len(pits) / A_inspect) * 100
    if density_per_100mm2 < 1:
        density_class = 1
    elif density_per_100mm2 < 10:
        density_class = 2
    elif density_per_100mm2 < 100:
        density_class = 3
    elif density_per_100mm2 < 1000:
        density_class = 4
    else:
        density_class = 5
    screening_pass = d_max < 0.5 * t_nom and density_class <= 3
    notes: list[str] = []
    if screening_pass:
        notes.append(f"Level-1 PASS — max depth {d_max:.2f} mm < 0.5·t_nom; density class {density_class}.")
    else:
        notes.append(f"Level-1 fail — escalating to Level-2 (depth {d_max:.2f} mm, density class {density_class}).")
    phi_amp = max(0.5, 1 - phi)
    d_eq = max(d_max, 0.85 * d_avg) * phi_amp
    t_eff = max(1e-3, t_nom - d_eq - FCA)
    s_mm = math.sqrt(4 * A_pits / math.pi)
    lam = s_mm / max(math.sqrt(D * t_min), 1e-9)
    M_t = math.sqrt(1 + 0.48 * lam * lam)
    Rt = t_eff / max(t_min, 1e-6)
    RSF = 1.0
    if Rt < 1:
        RSF = max(0.0, min(1.0, (1 - Rt) / max(1e-6, 1 - Rt / M_t)))
    RSF_a = 0.90
    level: str = "Level-1" if screening_pass else "Level-2"
    if Rt < 0.20:
        level = "unacceptable"
        notes.append(f"Rt = {Rt:.3f} < 0.20 — wall lost to pits.")
    elif RSF < RSF_a:
        notes.append(f"Level-2 derate: RSF = {RSF:.3f}.")
    else:
        notes.append(f"Level-2 PASS: RSF = {RSF:.3f}.")
    MAWP = _base_mawp(geo, S, max(t_eff, 1e-3))
    if RSF < RSF_a:
        MAWP = MAWP * RSF / RSF_a
    life = max(0.0, t_eff - t_min) / CR if CR > 0 else 1e6
    return {
        "edition": edition,
        "level": level,
        "remaining_life_years": life,
        "t_min_mm": t_min,
        "MAWP_MPa": MAWP,
        "notes": notes,
        "citations": [
            "API 579-1/ASME FFS-1 (2021) §6.4.2 (Level-1)",
            "API 579-1/ASME FFS-1 (2021) §6.4.3 (Level-2 RSF)",
            "Kowaka M. (1994) Ch. 4",
            "Frankel G.S., J. Electrochem. Soc. 145 (1998) 2186",
        ],
        "pit_count": len(pits),
        "max_pit_depth_mm": d_max,
        "density_class": density_class,
        "equiv_metal_loss_mm": d_eq,
        "RSF": RSF,
        "details": {
            "d_max": d_max,
            "d_avg": d_avg,
            "A_pits_mm2": A_pits,
            "A_inspect_mm2": A_inspect,
            "pit_density_per_100mm2": density_per_100mm2,
            "phi": phi,
            "lambda": lam,
            "M_t": M_t,
            "Rt": Rt,
            "S_allow_MPa": S,
            "Sy_MPa": Sy,
            "Suts_MPa": Suts,
            "FCA_mm": FCA,
        },
    }


def _fad_l2a(Lr: float, Lr_max: float) -> float:
    if Lr > Lr_max:
        return 0.0
    return (1 - 0.14 * Lr * Lr) * (0.3 + 0.7 * math.exp(-0.65 * Lr ** 6))


def _local_part9(body: Mapping[str, Any]) -> dict[str, Any]:
    """Delegate Part 9 to :mod:`austenite._ffs_native`."""

    return native.run_ffs_part9_native(
        geometry=body["geometry"],
        crack=body["crack"],
        sigma_membrane_MPa=float(body["sigma_membrane_MPa"]),
        sigma_bending_MPa=float(body["sigma_bending_MPa"]),
        material=body["material"],
        sigma_WRS_MPa=body.get("sigma_WRS_MPa"),
        edition=body.get("edition") or "API 579-1 2021-12",
    )


def _local_part9_legacy(body: Mapping[str, Any]) -> dict[str, Any]:
    """Legacy inline Part 9 — parity oracle, identical to native."""

    geo = body["geometry"]
    crack = body["crack"]
    mat = body["material"]
    a = float(crack["a_mm"])
    c = float(crack["c_mm"])
    t = float(geo["wall_mm"])
    D = float(geo["OD_mm"])
    sig_m = float(body["sigma_membrane_MPa"])
    sig_b = float(body["sigma_bending_MPa"])
    sig_WRS = float(body.get("sigma_WRS_MPa") or 0)
    Sy = float(mat["sigma_y"])
    Suts = float(mat["sigma_uts"])
    KIc = float(mat["KIc_MPa_sqm"])
    a_m = a / 1000.0
    ctype = crack.get("type") or "surface"
    if ctype == "surface":
        Q = 1 + 1.464 * (min(1.0, a / max(c, 1e-9))) ** 1.65
        F = 1.12
        K_app = F * (sig_m + sig_b) * math.sqrt(math.pi * a_m / Q)
        K_WRS = F * sig_WRS * math.sqrt(math.pi * a_m / Q)
    elif ctype == "through":
        K_app = (sig_m + sig_b) * math.sqrt(math.pi * a_m)
        K_WRS = sig_WRS * math.sqrt(math.pi * a_m)
    else:
        K_app = 1.12 * (sig_m + sig_b) * math.sqrt(math.pi * a_m)
        K_WRS = 1.12 * sig_WRS * math.sqrt(math.pi * a_m)
    K_total = max(0.0, K_app + K_WRS)
    if ctype == "through":
        lam = (2 * c) / max(math.sqrt(D * t), 1e-9)
        M_t = math.sqrt(1 + 0.48 * lam * lam)
        sigma_ref = (sig_m + sig_b / 3) * M_t
    else:
        sigma_ref = (sig_m + sig_b / 3) / max(0.05, 1 - a / t)
    L_r = sigma_ref / max(1.0, Sy)
    K_r = K_total / max(1.0, KIc)
    L_r_max = 0.5 * (1 + Sy / max(1.0, Suts))
    # bisection reserve factor
    lo, hi = 0.0, L_r_max / max(1e-9, L_r)
    for _ in range(50):
        mid = 0.5 * (lo + hi)
        tL = mid * L_r
        tK = mid * K_r
        Kf = 0.0 if tL >= L_r_max else _fad_l2a(tL, L_r_max)
        if tK >= Kf:
            hi = mid
        else:
            lo = mid
    reserve = 0.5 * (lo + hi)
    if L_r >= L_r_max or K_r >= _fad_l2a(L_r, L_r_max):
        verdict = "FAIL"
        level = "unacceptable"
    elif reserve < 1.1:
        verdict = "MARGINAL"
        level = "Level-3"
    else:
        verdict = "PASS"
        level = "Level-2"
    edition = body.get("edition") or "API 579-1 2021-12"
    notes = [
        f"FAD operating point (L_r={L_r:.3f}, K_r={K_r:.3f}); L_r_max={L_r_max:.3f}.",
        f"K_app = {K_app:.2f} MPa·√m, K_WRS = {K_WRS:.2f} MPa·√m, K_total = {K_total:.2f} MPa·√m.",
        f"σ_ref = {sigma_ref:.1f} MPa; Sy = {Sy:.0f} MPa, KIc = {KIc:.0f} MPa·√m.",
        f"FAD verdict: {verdict}; reserve factor R = {reserve:.3f}.",
    ]
    if edition == "API 579-1 2024-09":
        notes.append("Note: 2024-09 Annex 9C re-aliased FAD points; numerical FAD curve unchanged.")
    return {
        "edition": edition,
        "level": level,
        "remaining_life_years": 1e6,  # not directly computed for crack
        "t_min_mm": t,
        "MAWP_MPa": (sig_m / max(1e-6, sigma_ref)) * sigma_ref * reserve,
        "notes": notes,
        "citations": [
            "API 579-1/ASME FFS-1 (2021) §9.4.2 + Annex 9C",
            "API 579-1/ASME FFS-1 (2024) Annex 9C re-alias",
            "BS 7910:2019 Annex L",
            "Anderson T.L., Fracture Mechanics 4th ed. §11.5",
            "Newman & Raju NASA TM-83200 (1982)",
            "Folias E.S., Int. J. Fracture Mech. 1 (1965) 104",
        ],
        "fad_point": [L_r, K_r],
        "distance_to_curve": reserve,
        "details": {
            "a_mm": a,
            "c_mm": c,
            "t_mm": t,
            "K_app": K_app,
            "K_WRS_app": K_WRS,
            "K_total": K_total,
            "sigma_ref": sigma_ref,
            "L_r_max": L_r_max,
            "crack_type": ctype,
            "sigma_y_MPa": Sy,
            "sigma_uts_MPa": Suts,
            "KIc_MPa_sqm": KIc,
        },
    }


def _offline_requested() -> bool:
    """``AUSTENITE_OFFLINE=1`` (or any truthy value) skips the HTTP path."""

    val = os.environ.get("AUSTENITE_OFFLINE", "").strip().lower()
    return val in {"1", "true", "yes", "on"}


def _post(
    endpoint: str,
    body: Mapping[str, Any],
    local_fn,
    backend: Optional[str] = None,
) -> dict[str, Any]:
    """Dispatch an FFS request — HTTP first, native fallback.

    The native engine in :mod:`austenite._ffs_native` shares the same
    physics as the deployed worker, so verdicts agree across paths.

    Resolution order:

    * ``backend='native'`` or ``AUSTENITE_OFFLINE=1`` or
      ``AUSTENITE_FFS_LOCAL=1`` → native only.
    * ``backend='http'`` → HTTP only; propagate any
      :class:`AusteniteError`.
    * ``backend=None`` (default) → HTTP first, fall back to the native
      engine on any exception (network unreachable, 5xx engine error,
      missing route mock in tests, ...).
    """

    force_native = (
        backend == "native"
        or _offline_requested()
        or bool(os.environ.get("AUSTENITE_FFS_LOCAL"))
    )
    if force_native:
        return local_fn(body)
    client = get_default_client()
    try:
        response = client.post(endpoint, json=dict(body))
        return response.json()
    except Exception as exc:  # pragma: no cover - exercised in offline mode
        if backend == "http":
            raise
        # Silent fallback — keeps offline / airgapped workflows alive.
        try:
            return local_fn(body)
        except Exception:
            raise AusteniteError(
                f"FFS call to {endpoint} failed and local fallback also failed: {exc}"
            ) from exc


# ---------------------------------------------------------------------------
# FFSReport — PDF + XLSX writer
# ---------------------------------------------------------------------------


@dataclass
class FFSReport:
    """Stamped report writer for an FFS verdict.

    Attached to every :class:`FFSResult`.  Two exporters:

      * :meth:`export_pdf` — multi-page ASME-Section-VIII-style document
        with input / analysis / verdict / signature-block placeholder /
        30+ citations.  Requires ``reportlab`` (install via the ``[ffs]``
        or ``[xlsx]`` extras).
      * :meth:`export_xlsx` — 4-sheet workbook (Summary / Inputs /
        Analysis / Citations).  Requires ``openpyxl``.

    Both exporters degrade gracefully to a plain-text ``.txt`` sibling
    file when the optional dependency is missing.
    """

    part: str
    edition: str
    envelope: dict[str, Any]
    equipment_id: Optional[str] = None
    engineer: Optional[str] = None
    inputs: dict[str, Any] = field(default_factory=dict)

    # ── Public exports ──
    def export_pdf(self, path: Union[str, Path]) -> Path:
        path = Path(path)
        try:
            from reportlab.lib.pagesizes import letter  # type: ignore
            from reportlab.lib.units import inch  # type: ignore
            from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle  # type: ignore
            from reportlab.lib.enums import TA_CENTER, TA_LEFT  # type: ignore
            from reportlab.platypus import (  # type: ignore
                SimpleDocTemplate,
                Paragraph,
                Spacer,
                Table,
                TableStyle,
                PageBreak,
            )
            from reportlab.lib import colors  # type: ignore
        except ImportError:
            # Fallback: txt rendering
            txt_path = path.with_suffix(".txt")
            self._write_txt(txt_path)
            return txt_path

        # Build the document
        os.makedirs(path.parent, exist_ok=True) if str(path.parent) not in {"", "."} else None
        doc = SimpleDocTemplate(
            str(path),
            pagesize=letter,
            rightMargin=0.7 * inch,
            leftMargin=0.7 * inch,
            topMargin=0.7 * inch,
            bottomMargin=0.7 * inch,
            title=f"FFS Report — {self.equipment_id or 'untitled'}",
            author=self.engineer or "Austenite",
        )
        styles = getSampleStyleSheet()
        h1 = ParagraphStyle(
            "h1", parent=styles["Heading1"], fontSize=16, alignment=TA_CENTER, spaceAfter=14
        )
        h2 = ParagraphStyle(
            "h2", parent=styles["Heading2"], fontSize=12, alignment=TA_LEFT, spaceAfter=8
        )
        body = ParagraphStyle(
            "body", parent=styles["BodyText"], fontSize=9, alignment=TA_LEFT, leading=12
        )
        small = ParagraphStyle(
            "small", parent=styles["BodyText"], fontSize=8, alignment=TA_LEFT, leading=10
        )

        story: list = []
        # ── Header ─────────────────────────────────────────────────────
        title = f"API 579-1 Fitness-For-Service Report"
        story.append(Paragraph(title, h1))
        meta_rows = [
            ["Equipment ID", self.equipment_id or "—"],
            ["Date", datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")],
            ["Engineer", self.engineer or "—"],
            ["Edition", self.edition],
            ["Part", self.part],
            ["Verdict", self.envelope.get("level", "—")],
        ]
        tbl = Table(meta_rows, colWidths=[1.6 * inch, 4.5 * inch])
        tbl.setStyle(
            TableStyle(
                [
                    ("FONT", (0, 0), (-1, -1), "Helvetica", 9),
                    ("FONT", (0, 0), (0, -1), "Helvetica-Bold", 9),
                    ("GRID", (0, 0), (-1, -1), 0.25, colors.grey),
                    ("BACKGROUND", (0, 0), (0, -1), colors.lightgrey),
                ]
            )
        )
        story.append(tbl)
        story.append(Spacer(1, 0.2 * inch))

        # ── Section 1 — Inputs ─────────────────────────────────────────
        story.append(Paragraph("Section 1 — Input Data", h2))
        for k, v in self.inputs.items():
            if isinstance(v, (dict, list, tuple)):
                pretty = json.dumps(v, default=str, indent=2)
                story.append(Paragraph(f"<b>{k}:</b>", body))
                story.append(Paragraph(f"<pre>{_escape_html(pretty)}</pre>", small))
            else:
                story.append(Paragraph(f"<b>{k}:</b> {_escape_html(str(v))}", body))
        story.append(Spacer(1, 0.15 * inch))

        # ── Section 2 — Analysis ───────────────────────────────────────
        story.append(Paragraph("Section 2 — Analysis Steps", h2))
        for n in self.envelope.get("notes", []):
            story.append(Paragraph(f"• {_escape_html(str(n))}", body))
        details = self.envelope.get("details") or {}
        if details:
            story.append(Spacer(1, 0.1 * inch))
            story.append(Paragraph("Per-step values:", body))
            for k, v in details.items():
                if isinstance(v, (dict, list, tuple)):
                    continue
                story.append(Paragraph(f"&nbsp;&nbsp;{k} = {v}", small))
        story.append(Spacer(1, 0.15 * inch))

        # ── Section 3 — Verdict ────────────────────────────────────────
        story.append(Paragraph("Section 3 — Verdict", h2))
        v_rows = [
            ["Acceptance level", self.envelope.get("level", "—")],
            ["Remaining life (years)", f"{self.envelope.get('remaining_life_years', 0):.2f}"],
            ["t_min required (mm)", f"{self.envelope.get('t_min_mm', 0):.3f}"],
            ["MAWP (MPa)", f"{self.envelope.get('MAWP_MPa', 0):.3f}"],
        ]
        if self.envelope.get("fad_point"):
            fp = self.envelope["fad_point"]
            v_rows.append(["FAD point (L_r, K_r)", f"({fp[0]:.3f}, {fp[1]:.3f})"])
            v_rows.append([
                "Distance to FAD curve (R)",
                f"{self.envelope.get('distance_to_curve', 0):.3f}",
            ])
        if self.envelope.get("RSF") is not None:
            v_rows.append(["RSF", f"{self.envelope.get('RSF'):.3f}"])
        tbl2 = Table(v_rows, colWidths=[2.5 * inch, 3.6 * inch])
        tbl2.setStyle(
            TableStyle(
                [
                    ("FONT", (0, 0), (-1, -1), "Helvetica", 10),
                    ("FONT", (0, 0), (0, -1), "Helvetica-Bold", 10),
                    ("GRID", (0, 0), (-1, -1), 0.25, colors.grey),
                    (
                        "BACKGROUND",
                        (1, 0),
                        (1, 0),
                        colors.HexColor(
                            "#c6efce"
                            if self.envelope.get("level", "").startswith("Level")
                            else "#ffc7ce"
                        ),
                    ),
                ]
            )
        )
        story.append(tbl2)
        story.append(Spacer(1, 0.2 * inch))

        # ── Section 4 — Signature block ────────────────────────────────
        story.append(Paragraph("Section 4 — Professional Engineer Signature Block", h2))
        sig_rows = [
            ["Engineer Name", self.engineer or "____________________________"],
            ["P.E. License #", "____________________________"],
            ["Jurisdiction", "____________________________"],
            ["Signature", ""],
            ["Date", datetime.now(timezone.utc).strftime("%Y-%m-%d")],
            [
                "Stamp",
                "(affix P.E. stamp here — software supplies the calculation; "
                "the seal is the responsibility of a licensed professional engineer)",
            ],
        ]
        tbl3 = Table(sig_rows, colWidths=[1.6 * inch, 4.5 * inch])
        tbl3.setStyle(
            TableStyle(
                [
                    ("FONT", (0, 0), (-1, -1), "Helvetica", 9),
                    ("FONT", (0, 0), (0, -1), "Helvetica-Bold", 9),
                    ("GRID", (0, 0), (-1, -1), 0.25, colors.grey),
                    ("BACKGROUND", (0, 0), (0, -1), colors.lightgrey),
                    ("ROWBACKGROUNDS", (0, 0), (-1, -1), [colors.white, colors.whitesmoke]),
                ]
            )
        )
        story.append(tbl3)
        story.append(PageBreak())

        # ── Section 5 — Citations ──────────────────────────────────────
        story.append(Paragraph("Section 5 — Citations & References", h2))
        for i, c in enumerate(_full_citation_list(self.envelope.get("citations") or []), start=1):
            story.append(Paragraph(f"{i}. {_escape_html(c)}", small))
        doc.build(story)
        return path

    def export_xlsx(self, path: Union[str, Path]) -> Path:
        path = Path(path)
        try:
            from openpyxl import Workbook  # type: ignore
            from openpyxl.styles import Alignment, Font, PatternFill  # type: ignore
        except ImportError as e:
            raise AusteniteError(
                "openpyxl is required for export_xlsx — install with "
                "`pip install austenite[ffs]`."
            ) from e

        os.makedirs(path.parent, exist_ok=True) if str(path.parent) not in {"", "."} else None
        wb = Workbook()

        bold = Font(bold=True, size=11)
        title_font = Font(bold=True, size=14)
        fill_pass = PatternFill("solid", fgColor="C6EFCE")
        fill_fail = PatternFill("solid", fgColor="FFC7CE")
        fill_warn = PatternFill("solid", fgColor="FFEB9C")

        # ── Sheet 1: Summary ──
        ws = wb.active
        ws.title = "Summary"
        ws["A1"] = f"API 579-1 FFS Report — {self.part}"
        ws["A1"].font = title_font
        ws.merge_cells("A1:D1")

        rows = [
            ("Equipment", self.equipment_id or "—"),
            ("Engineer", self.engineer or "—"),
            ("Date", datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")),
            ("Edition", self.edition),
            ("Part", self.part),
            ("", ""),
            ("Verdict (level)", self.envelope.get("level", "—")),
            ("Remaining life (years)", float(self.envelope.get("remaining_life_years", 0))),
            ("t_min required (mm)", float(self.envelope.get("t_min_mm", 0))),
            ("MAWP (MPa)", float(self.envelope.get("MAWP_MPa", 0))),
        ]
        if self.envelope.get("RSF") is not None:
            rows.append(("RSF", float(self.envelope["RSF"])))
        if self.envelope.get("fad_point"):
            fp = self.envelope["fad_point"]
            rows.append(("FAD L_r", float(fp[0])))
            rows.append(("FAD K_r", float(fp[1])))
            rows.append(("Distance to FAD curve (R)", float(self.envelope.get("distance_to_curve", 0))))
        for i, (k, v) in enumerate(rows, start=3):
            ws.cell(row=i, column=1, value=k).font = bold if k else Font()
            ws.cell(row=i, column=2, value=v)
        # colour the verdict cell
        level = self.envelope.get("level", "")
        verdict_row = 9
        if level == "unacceptable":
            ws.cell(row=verdict_row, column=2).fill = fill_fail
        elif level == "Level-3":
            ws.cell(row=verdict_row, column=2).fill = fill_warn
        else:
            ws.cell(row=verdict_row, column=2).fill = fill_pass
        ws.column_dimensions["A"].width = 30
        ws.column_dimensions["B"].width = 32

        # ── Sheet 2: Inputs ──
        ws2 = wb.create_sheet("Inputs")
        ws2.cell(row=1, column=1, value="Field").font = bold
        ws2.cell(row=1, column=2, value="Value").font = bold
        r = 2
        for k, v in self.inputs.items():
            if isinstance(v, (dict, list, tuple)):
                ws2.cell(row=r, column=1, value=k).font = bold
                ws2.cell(row=r, column=2, value=json.dumps(v, default=str)).alignment = Alignment(wrap_text=True)
            else:
                ws2.cell(row=r, column=1, value=k).font = bold
                ws2.cell(row=r, column=2, value=v)
            r += 1
        ws2.column_dimensions["A"].width = 22
        ws2.column_dimensions["B"].width = 80

        # If thickness_map present, drop a tabular sheet
        if "thickness_map" in self.inputs:
            ws3 = wb.create_sheet("Thickness Map")
            tm = self.inputs["thickness_map"]
            if isinstance(tm, list):
                if len(tm) > 0 and isinstance(tm[0], Mapping):
                    cols = list(tm[0].keys())
                    for ci, name in enumerate(cols, start=1):
                        ws3.cell(row=1, column=ci, value=name).font = bold
                    for ri, row in enumerate(tm, start=2):
                        for ci, name in enumerate(cols, start=1):
                            ws3.cell(row=ri, column=ci, value=row.get(name))
                else:
                    ws3.cell(row=1, column=1, value="thickness_mm").font = bold
                    for ri, v in enumerate(tm, start=2):
                        ws3.cell(row=ri, column=1, value=float(v))
            ws3.freeze_panes = "A2"
        if "pit_data" in self.inputs:
            ws3 = wb.create_sheet("Pit Data")
            pd_rows = self.inputs["pit_data"]
            if isinstance(pd_rows, list) and pd_rows:
                cols = sorted({k for row in pd_rows for k in row.keys()})
                for ci, name in enumerate(cols, start=1):
                    ws3.cell(row=1, column=ci, value=name).font = bold
                for ri, row in enumerate(pd_rows, start=2):
                    for ci, name in enumerate(cols, start=1):
                        ws3.cell(row=ri, column=ci, value=row.get(name))
                ws3.freeze_panes = "A2"
        if "crack" in self.inputs:
            ws3 = wb.create_sheet("Crack Geometry")
            crack = self.inputs["crack"]
            for ri, (k, v) in enumerate(crack.items(), start=1):
                ws3.cell(row=ri, column=1, value=k).font = bold
                ws3.cell(row=ri, column=2, value=v)
            ws3.column_dimensions["A"].width = 18
            ws3.column_dimensions["B"].width = 24

        # ── Sheet: Analysis Details ──
        ws4 = wb.create_sheet("Analysis Details")
        ws4.cell(row=1, column=1, value="Step / Field").font = bold
        ws4.cell(row=1, column=2, value="Value").font = bold
        r = 2
        for n in self.envelope.get("notes", []):
            ws4.cell(row=r, column=1, value="note")
            ws4.cell(row=r, column=2, value=n).alignment = Alignment(wrap_text=True)
            r += 1
        ws4.cell(row=r, column=1, value="").font = bold
        r += 1
        ws4.cell(row=r, column=1, value="Per-step values").font = bold
        r += 1
        for k, v in (self.envelope.get("details") or {}).items():
            if isinstance(v, (dict, list, tuple)):
                v = json.dumps(v, default=str)
            ws4.cell(row=r, column=1, value=k).font = bold
            ws4.cell(row=r, column=2, value=v)
            r += 1
        ws4.column_dimensions["A"].width = 30
        ws4.column_dimensions["B"].width = 80

        # ── Sheet: Citations ──
        ws5 = wb.create_sheet("Citations")
        ws5.cell(row=1, column=1, value="#").font = bold
        ws5.cell(row=1, column=2, value="Reference").font = bold
        for i, c in enumerate(_full_citation_list(self.envelope.get("citations") or []), start=2):
            ws5.cell(row=i, column=1, value=i - 1)
            ws5.cell(row=i, column=2, value=c).alignment = Alignment(wrap_text=True)
        ws5.column_dimensions["A"].width = 5
        ws5.column_dimensions["B"].width = 100

        wb.save(str(path))
        return path

    # ── Internal helpers ──
    def _write_txt(self, path: Path) -> None:
        lines: list[str] = []
        lines.append("API 579-1 Fitness-For-Service Report")
        lines.append("=" * 60)
        lines.append(f"Equipment: {self.equipment_id or '—'}")
        lines.append(f"Engineer:  {self.engineer or '—'}")
        lines.append(f"Date:      {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}")
        lines.append(f"Edition:   {self.edition}")
        lines.append(f"Part:      {self.part}")
        lines.append("")
        lines.append("─── Section 1 — Inputs ─────────────────────────────")
        for k, v in self.inputs.items():
            lines.append(f"  {k}: {v}")
        lines.append("")
        lines.append("─── Section 2 — Analysis ───────────────────────────")
        for n in self.envelope.get("notes", []):
            lines.append(f"  - {n}")
        lines.append("")
        lines.append("─── Section 3 — Verdict ────────────────────────────")
        lines.append(f"  Level:               {self.envelope.get('level')}")
        lines.append(f"  Remaining life [y]:  {self.envelope.get('remaining_life_years', 0):.2f}")
        lines.append(f"  t_min [mm]:          {self.envelope.get('t_min_mm', 0):.3f}")
        lines.append(f"  MAWP [MPa]:          {self.envelope.get('MAWP_MPa', 0):.3f}")
        lines.append("")
        lines.append("─── Section 5 — Citations ──────────────────────────")
        for i, c in enumerate(_full_citation_list(self.envelope.get("citations") or []), start=1):
            lines.append(f"  {i}. {c}")
        path.write_text("\n".join(lines), encoding="utf-8")


def _escape_html(s: str) -> str:
    return (
        s.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
    )


def _full_citation_list(provided: Sequence[str]) -> list[str]:
    """Merge per-Part citations with a baseline 30-item reference list.

    The baseline list cites every standard and textbook the engine relies on,
    so the engineer's report meets the "complete reference list" expectation
    of an ASME-Section-VIII deliverable regardless of which Part was run.
    """

    base = [
        "API 579-1 / ASME FFS-1 (2021) — Fitness-For-Service",
        "API 579-1 / ASME FFS-1 (2024-09) — Annex 9C re-alias",
        "ASME BPVC Section VIII Division 1 (2021) — Pressure Vessels",
        "ASME BPVC Section VIII Division 2 (2021) — Alternative Rules",
        "ASME BPVC Section II Part D (2021) — Properties (Metric)",
        "ASME B31.3 (2022) — Process Piping",
        "ASME B31G-2012 — Remaining Strength of Corroded Pipelines",
        "BS 7910:2019 — Methods for assessing flaws in metallic structures",
        "DNV-RP-F101 (2017) — Corroded Pipelines",
        "PRCI PR-3-805 (1989) Kiefner & Vieth — Modified B31G / RSTRENG",
        "Folias E.S., Int. J. Fracture Mech. 1 (1965) 104 — Bulging factor",
        "Newman J.C. & Raju I.S., NASA TM-83200 (1982) — K-solutions",
        "Anderson T.L., Fracture Mechanics 4th ed. (2017) §11.5",
        "Kanninen M.F. & Popelar C.H., Advanced Fracture Mechanics (1985)",
        "Kowaka M., Life Prediction of Industrial Plant Materials (1994)",
        "Frankel G.S., J. Electrochem. Soc. 145 (1998) 2186 — Pitting",
        "API 510 — Pressure Vessel Inspection Code",
        "API 570 — Piping Inspection Code",
        "API 580 — Risk-Based Inspection",
        "API 581 — Risk-Based Inspection Methodology",
        "NACE TM0284 — Hydrogen-Induced Cracking",
        "NACE MR0175 / ISO 15156 — Sour Service",
        "ISO 12107 — Statistical planning of fatigue data",
        "ISO 16811 — Calibration of UT thickness gauges",
        "API 936 — Refractory installation",
        "API 941 — Steels for Hydrogen Service at Elevated T/P (Nelson curves)",
        "EEMUA 159 — Above-Ground Storage Tanks",
        "API 653 — Tank Inspection / Alteration / Reconstruction",
        "API 1163 — In-Line Inspection Systems",
        "ASNT SNT-TC-1A — NDE Personnel Qualification",
    ]
    seen: set[str] = set()
    out: list[str] = []
    for c in list(provided) + base:
        key = c.strip().lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(c)
    return out


# ---------------------------------------------------------------------------
# Public API — the four FFS workflows
# ---------------------------------------------------------------------------


def _build_audit_record(part: str, endpoint: str, payload: Mapping[str, Any], envelope: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "part": part,
        "endpoint": endpoint,
        "payload": dict(payload),
        "envelope": dict(envelope),
        "edition": envelope.get("edition"),
        "level": envelope.get("level"),
        "ts": datetime.now(timezone.utc).isoformat(),
    }


def _build_result(
    *,
    part: str,
    edition: str,
    envelope: Mapping[str, Any],
    inputs: Mapping[str, Any],
    equipment_id: Optional[str],
    engineer: Optional[str],
    endpoint: str,
) -> FFSResult:
    report = FFSReport(
        part=part,
        edition=edition,
        envelope=dict(envelope),
        equipment_id=equipment_id,
        engineer=engineer,
        inputs=dict(inputs),
    )
    audit = _build_audit_record(part, endpoint, inputs, envelope)
    fad_point = envelope.get("fad_point")
    fad_tuple: Optional[tuple[float, float]] = None
    if isinstance(fad_point, (list, tuple)) and len(fad_point) == 2:
        fad_tuple = (float(fad_point[0]), float(fad_point[1]))
    result = FFSResult(
        level=envelope.get("level", "unacceptable"),
        remaining_life_years=float(envelope.get("remaining_life_years", 0)),
        t_min_mm=float(envelope.get("t_min_mm", 0)),
        MAWP_MPa=float(envelope.get("MAWP_MPa", 0)),
        fad_point=fad_tuple,
        distance_to_curve=(
            float(envelope["distance_to_curve"])
            if envelope.get("distance_to_curve") is not None
            else None
        ),
        notes=list(envelope.get("notes", [])),
        citations=list(envelope.get("citations", [])),
        edition=edition,
        audit_record=audit,
        RSF=float(envelope["RSF"]) if envelope.get("RSF") is not None else None,
        part=part,
    )
    # Attach report after construction so it doesn't go through pydantic
    # validation (FFSReport is a dataclass, not a BaseModel).
    object.__setattr__(result, "report", report)
    return result


def api_579_part_5(
    *,
    geometry: Union[FFSGeometry, Mapping[str, Any]],
    thickness_map: Any,
    T_C: float,
    P_MPa: float,
    material: Union[str, FFSMaterial, Mapping[str, Any]],
    edition: Optional[str] = None,
    corrosion_rate_mm_per_year: Optional[float] = None,
    FCA_mm: Optional[float] = None,
    lta: Optional[Mapping[str, Any]] = None,
    equipment_id: Optional[str] = None,
    engineer: Optional[str] = None,
    backend: Optional[str] = None,
) -> FFSResult:
    """Part 5 — General metal-loss assessment (Level 1/2/3 cascade).

    Args:
        geometry: Component geometry — ``cylinder`` / ``sphere`` / ``pipe`` with
            ``OD_mm`` and ``wall_mm``.  Optional ``FCA_mm``,
            ``joint_efficiency``, ``grid_spacing_mm``.
        thickness_map: One of
            * ``pandas.DataFrame`` with a ``thickness_mm`` column (and
              optional ``x_mm`` / ``y_mm`` columns for the audit trail);
            * ``list[dict]`` of ``{"x_mm": .., "thickness_mm": ..}``;
            * flat ``list[float]`` of UT readings.
        T_C: Operating / design temperature (°C).
        P_MPa: Operating pressure (MPa).
        material: Either the ASME II-D spec name (e.g. ``"SA-516-70"``),
            a :class:`FFSMaterial`, or a mapping with explicit ``Sy_MPa`` /
            ``Suts_MPa`` / ``S_MPa``.
        edition: ``"API 579-1 2021-12"`` (default) or ``"API 579-1 2024-09"``.
        corrosion_rate_mm_per_year: Optional CR for remaining-life projection.
        FCA_mm: Future corrosion allowance (mm), overrides ``geometry.FCA_mm``.
        lta: Optional ``{"s_mm", "d_mm", "c_mm"?}`` — when present, the Folias
            §4.4.3.3 RSF is folded into the verdict.
        equipment_id: Stamped onto the report header.
        engineer: Stamped onto the signature block.

    Returns:
        :class:`FFSResult` with ``report.export_pdf`` / ``export_xlsx``.
    """

    edition = _normalise_edition(edition)
    body = {
        "geometry": _geometry_to_payload(geometry),
        "thickness_map": _thickness_map_to_payload(thickness_map),
        "T_C": float(T_C),
        "P_MPa": float(P_MPa),
        "material": _material_to_payload(material),
        "edition": edition,
    }
    if corrosion_rate_mm_per_year is not None:
        body["corrosion_rate_mm_per_year"] = float(corrosion_rate_mm_per_year)
    if FCA_mm is not None:
        body["FCA_mm"] = float(FCA_mm)
    if lta is not None:
        body["lta"] = dict(lta)
    envelope = _post("/v1/ffs/api-579/part-5", body, _local_part5, backend=backend)
    return _build_result(
        part="Part 5 (general metal loss)",
        edition=edition,
        envelope=envelope,
        inputs=body,
        equipment_id=equipment_id,
        engineer=engineer,
        endpoint="/v1/ffs/api-579/part-5",
    )


def api_579_part_5_lta(
    *,
    geometry: Union[FFSGeometry, Mapping[str, Any]],
    lta: Mapping[str, Any],
    thickness_map: Any,
    T_C: float,
    P_MPa: float,
    material: Union[str, FFSMaterial, Mapping[str, Any]],
    edition: Optional[str] = None,
    corrosion_rate_mm_per_year: Optional[float] = None,
    equipment_id: Optional[str] = None,
    engineer: Optional[str] = None,
    backend: Optional[str] = None,
) -> FFSResult:
    """Part 5 LTA variant — always activates the Folias §4.4.3.3 overlay.

    Convenience wrapper around :func:`api_579_part_5` that hard-codes the
    LTA payload (``s_mm`` axial length, ``d_mm`` max depth, optional
    ``c_mm`` circumferential width).
    """

    if not isinstance(lta, Mapping) or "s_mm" not in lta or "d_mm" not in lta:
        raise ValidationError(
            "lta must be a mapping with at least 's_mm' and 'd_mm' keys."
        )
    return api_579_part_5(
        geometry=geometry,
        thickness_map=thickness_map,
        T_C=T_C,
        P_MPa=P_MPa,
        material=material,
        edition=edition,
        corrosion_rate_mm_per_year=corrosion_rate_mm_per_year,
        FCA_mm=None,
        lta=lta,
        equipment_id=equipment_id,
        engineer=engineer,
        backend=backend,
    )


def api_579_part_6(
    *,
    geometry: Union[FFSGeometry, Mapping[str, Any]],
    pit_data: Any,
    T_C: float,
    P_MPa: float,
    material: Union[str, FFSMaterial, Mapping[str, Any]],
    edition: Optional[str] = None,
    corrosion_rate_mm_per_year: Optional[float] = None,
    equipment_id: Optional[str] = None,
    engineer: Optional[str] = None,
    backend: Optional[str] = None,
) -> FFSResult:
    """Part 6 — Pitting assessment.

    Args:
        geometry: Same as Part 5.
        pit_data: pandas.DataFrame with ``max_depth_mm`` and ``diameter_mm``
            columns (optional ``density_per_mm2``) — or a list of dict/
            :class:`FFSPit` records.
        T_C, P_MPa, material, edition, corrosion_rate_mm_per_year: as Part 5.
    """

    edition = _normalise_edition(edition)
    body = {
        "geometry": _geometry_to_payload(geometry),
        "pit_data": _pit_data_to_payload(pit_data),
        "T_C": float(T_C),
        "P_MPa": float(P_MPa),
        "material": _material_to_payload(material),
        "edition": edition,
    }
    if corrosion_rate_mm_per_year is not None:
        body["corrosion_rate_mm_per_year"] = float(corrosion_rate_mm_per_year)
    envelope = _post("/v1/ffs/api-579/part-6", body, _local_part6, backend=backend)
    return _build_result(
        part="Part 6 (pitting)",
        edition=edition,
        envelope=envelope,
        inputs=body,
        equipment_id=equipment_id,
        engineer=engineer,
        endpoint="/v1/ffs/api-579/part-6",
    )


def api_579_part_9(
    *,
    geometry: Union[FFSGeometry, Mapping[str, Any]],
    crack: Union[FFSCrack, Mapping[str, Any]],
    sigma_membrane_MPa: float,
    sigma_bending_MPa: float,
    material: Mapping[str, Any],
    sigma_WRS_MPa: Optional[float] = None,
    edition: Optional[str] = None,
    equipment_id: Optional[str] = None,
    engineer: Optional[str] = None,
    backend: Optional[str] = None,
) -> FFSResult:
    """Part 9 — Crack-like-flaw assessment (FAD Level 2A).

    Args:
        geometry: Same shell geometry as Part 5.
        crack: ``{"a_mm", "c_mm", "type"}`` — ``type`` ∈ {surface, through, corner}.
        sigma_membrane_MPa, sigma_bending_MPa: Membrane + bending stress at the
            crack location (MPa).
        sigma_WRS_MPa: Optional weld-residual-stress overlay (MPa).
        material: ``{"sigma_y", "sigma_uts", "KIc_MPa_sqm"}``.
        edition, equipment_id, engineer: as Part 5.
    """

    edition = _normalise_edition(edition)
    if not isinstance(material, Mapping):
        raise ValidationError(
            "Part 9 material must be a mapping with sigma_y / sigma_uts / KIc_MPa_sqm."
        )
    for key in ("sigma_y", "sigma_uts", "KIc_MPa_sqm"):
        if key not in material:
            raise ValidationError(f"Part 9 material is missing '{key}'.")
    body = {
        "geometry": _geometry_to_payload(geometry),
        "crack": _crack_to_payload(crack),
        "sigma_membrane_MPa": float(sigma_membrane_MPa),
        "sigma_bending_MPa": float(sigma_bending_MPa),
        "material": {
            "sigma_y": float(material["sigma_y"]),
            "sigma_uts": float(material["sigma_uts"]),
            "KIc_MPa_sqm": float(material["KIc_MPa_sqm"]),
        },
        "edition": edition,
    }
    if sigma_WRS_MPa is not None:
        body["sigma_WRS_MPa"] = float(sigma_WRS_MPa)
    envelope = _post("/v1/ffs/api-579/part-9", body, _local_part9, backend=backend)
    return _build_result(
        part="Part 9 (crack-like flaw, FAD Level 2A)",
        edition=edition,
        envelope=envelope,
        inputs=body,
        equipment_id=equipment_id,
        engineer=engineer,
        endpoint="/v1/ffs/api-579/part-9",
    )


# ---------------------------------------------------------------------------
# Parts 4 / 7 / 8 / 11 / 12 / 14 — local fallbacks and public dispatchers
# ---------------------------------------------------------------------------


def _local_part4(body: Mapping[str, Any]) -> dict[str, Any]:
    """Delegate Part 4 (brittle fracture) to :mod:`austenite._ffs_extensions`."""

    return extensions.run_ffs_part4_native(
        geometry=body["geometry"],
        material=body["material"],
        impact_data=body["impact_data"],
        edition=body.get("edition") or "API 579-1 2021-12",
        design_T_C=body.get("design_T_C"),
    )


def _local_part7(body: Mapping[str, Any]) -> dict[str, Any]:
    """Delegate Part 7 (hydrogen blisters / HIC)."""

    return extensions.run_ffs_part7_native(
        geometry=body["geometry"],
        blister_data=body["blister_data"],
        H_concentration_ppm=float(body.get("H_concentration_ppm", 0.0)),
        material=body["material"],
        edition=body.get("edition") or "API 579-1 2021-12",
        T_C=float(body.get("T_C", 25.0)),
    )


def _local_part8(body: Mapping[str, Any]) -> dict[str, Any]:
    """Delegate Part 8 (weld misalignment)."""

    return extensions.run_ffs_part8_native(
        geometry=body["geometry"],
        misalignment=body["misalignment"],
        loading=body["loading"],
        material=body["material"],
        edition=body.get("edition") or "API 579-1 2021-12",
    )


def _local_part11(body: Mapping[str, Any]) -> dict[str, Any]:
    """Delegate Part 11 (fire damage)."""

    return extensions.run_ffs_part11_native(
        geometry=body["geometry"],
        exposure=body["exposure"],
        material=body["material"],
        pre_fire_hardness_HB=float(body["pre_fire_hardness_HB"]),
        post_fire_hardness_HB=float(body["post_fire_hardness_HB"]),
        edition=body.get("edition") or "API 579-1 2021-12",
    )


def _local_part12(body: Mapping[str, Any]) -> dict[str, Any]:
    """Delegate Part 12 (dents + gouges + combined damage)."""

    return extensions.run_ffs_part12_native(
        geometry=body["geometry"],
        dent=body.get("dent"),
        gouge_data=body.get("gouge_data"),
        loading=body.get("loading"),
        material=body.get("material"),
        edition=body.get("edition") or "API 579-1 2021-12",
    )


def _local_part14(body: Mapping[str, Any]) -> dict[str, Any]:
    """Delegate Part 14 (creep)."""

    return extensions.run_ffs_part14_native(
        geometry=body["geometry"],
        operating=body["operating"],
        material=body["material"],
        operating_history_years=float(body.get("operating_history_years", 0.0)),
        edition=body.get("edition") or "API 579-1 2021-12",
        target_life_years=float(body.get("target_life_years", 30.0)),
    )


def api_579_part_4(
    *,
    geometry: Union[FFSGeometry, Mapping[str, Any]],
    material: Mapping[str, Any],
    impact_data: Mapping[str, Any],
    edition: Optional[str] = None,
    design_T_C: Optional[float] = None,
    equipment_id: Optional[str] = None,
    engineer: Optional[str] = None,
    backend: Optional[str] = None,
) -> FFSResult:
    """API 579-1 Part 4 — Brittle fracture assessment.

    Charpy-to-K_IC correlation (Barsom-Rolfe + Wallin master curve) +
    FAD-style check at design T per §4.4 / WRC 175 Curve A.

    Args:
        geometry: Component {OD_mm, wall_mm, type}.
        material: ``{"sigma_y_MPa", "sigma_uts_MPa", "T_C"?, "P_MPa"?}``.
        impact_data: ``{"CVN_J", "T_test_C"}``.
        edition: API 579-1 edition (default 2021-12).
        design_T_C: Design minimum metal temperature (°C). Overrides
            ``material["T_C"]`` when present.
        equipment_id, engineer: Stamped onto the report.
        backend: ``"http"`` / ``"native"`` / ``None`` (default — HTTP first).

    Returns:
        :class:`FFSResult` with ``MAT_C`` and ``SCT_curve`` extras.

    References:
        API 579-1/ASME FFS-1 (2021) Part 4 §4.4.
        WRC Bulletin 175 (1972) — Brittle fracture exemption curves.
        Wallin K., Eng. Fract. Mech. 22 (1985) 149 — Master curve.
        Barsom J.M. & Rolfe S.T., Fracture and Fatigue Control 3rd ed. (1999) §7.3.
        Anderson T.L., Fracture Mechanics 4th ed. §11.5.2.
    """

    edition = _normalise_edition(edition)
    if not isinstance(material, Mapping):
        raise ValidationError("Part 4 material must be a mapping with sigma_y_MPa / sigma_uts_MPa.")
    for key in ("sigma_y_MPa", "sigma_uts_MPa"):
        if key not in material:
            raise ValidationError(f"Part 4 material is missing '{key}'.")
    if not isinstance(impact_data, Mapping) or "CVN_J" not in impact_data or "T_test_C" not in impact_data:
        raise ValidationError("Part 4 impact_data must contain 'CVN_J' and 'T_test_C'.")
    body: dict[str, Any] = {
        "geometry": _geometry_to_payload(geometry),
        "material": dict(material),
        "impact_data": dict(impact_data),
        "edition": edition,
    }
    if design_T_C is not None:
        body["design_T_C"] = float(design_T_C)
    envelope = _post("/v1/ffs/api-579/part-4", body, _local_part4, backend=backend)
    return _build_result(
        part="Part 4 (brittle fracture)",
        edition=edition,
        envelope=envelope,
        inputs=body,
        equipment_id=equipment_id,
        engineer=engineer,
        endpoint="/v1/ffs/api-579/part-4",
    )


def api_579_part_7(
    *,
    geometry: Union[FFSGeometry, Mapping[str, Any]],
    blister_data: Sequence[Mapping[str, Any]],
    H_concentration_ppm: float,
    material: Union[str, FFSMaterial, Mapping[str, Any]],
    edition: Optional[str] = None,
    T_C: float = 25.0,
    equipment_id: Optional[str] = None,
    engineer: Optional[str] = None,
    backend: Optional[str] = None,
) -> FFSResult:
    """API 579-1 Part 7 — Hydrogen blisters / HIC / SOHIC.

    Level-1 screen per §7.4.2 + Level-2 Folias RSF.

    Args:
        geometry: Shell geometry as Part 5.
        blister_data: List of ``{"diameter_mm", "depth_mm", "location"?}``.
        H_concentration_ppm: Lattice hydrogen concentration (ppm by mass).
        material: ASME II-D spec or mapping with explicit allowables.
        edition: API 579-1 edition.
        T_C: Operating temperature (°C) — used by Arrhenius severity correction.
        equipment_id, engineer: Report header / signature.

    Returns:
        :class:`FFSResult` with ``allowable_blister_size_mm``,
        ``recommended_inspection_interval_months``, ``severity_class``.

    References:
        API 579-1/ASME FFS-1 (2021) Part 7 §7.4.
        NACE TM0284-2016 — HIC severity classification.
        Park G.T. & Choi B.G., Corros. Sci. 80 (2014) 209.
        Yan A. & Crowe C., Corros. Sci. 137 (2018) 65.
    """

    edition = _normalise_edition(edition)
    if not blister_data:
        raise ValidationError("Part 7 requires at least one blister record.")
    blisters_norm: list[dict[str, Any]] = []
    for b in blister_data:
        if not isinstance(b, Mapping):
            raise ValidationError("Each blister entry must be a mapping.")
        if "diameter_mm" not in b or "depth_mm" not in b:
            raise ValidationError("Each blister must include 'diameter_mm' and 'depth_mm'.")
        rec: dict[str, Any] = {
            "diameter_mm": float(b["diameter_mm"]),
            "depth_mm": float(b["depth_mm"]),
        }
        if "location" in b and b["location"] is not None:
            rec["location"] = list(b["location"]) if not isinstance(b["location"], str) else b["location"]
        blisters_norm.append(rec)
    body = {
        "geometry": _geometry_to_payload(geometry),
        "blister_data": blisters_norm,
        "H_concentration_ppm": float(H_concentration_ppm),
        "material": _material_to_payload(material),
        "edition": edition,
        "T_C": float(T_C),
    }
    envelope = _post("/v1/ffs/api-579/part-7", body, _local_part7, backend=backend)
    return _build_result(
        part="Part 7 (hydrogen blisters / HIC)",
        edition=edition,
        envelope=envelope,
        inputs=body,
        equipment_id=equipment_id,
        engineer=engineer,
        endpoint="/v1/ffs/api-579/part-7",
    )


def api_579_part_8(
    *,
    geometry: Union[FFSGeometry, Mapping[str, Any]],
    misalignment: Mapping[str, Any],
    loading: Mapping[str, Any],
    material: Union[str, FFSMaterial, Mapping[str, Any]],
    edition: Optional[str] = None,
    equipment_id: Optional[str] = None,
    engineer: Optional[str] = None,
    backend: Optional[str] = None,
) -> FFSResult:
    """API 579-1 Part 8 — Weld misalignment + shell distortions.

    Secondary-bending SCF from centreline offset (§8.4.2 Eq. 8.4) or angular
    distortion (Eq. 8.7), plus Folias-bulging RSF.

    Args:
        geometry: Shell geometry.
        misalignment: ``{"type": "offset"|"angular", "value_mm" or
            "angle_deg", "weld_id": "long_seam"|"circ_seam"}``.
        loading: ``{"P_MPa", "T_C"?, "axial_F_kN"?}``.
        material: ASME II-D spec or mapping.

    Returns:
        :class:`FFSResult` with ``stress_concentration_factor`` and ``RSF``.

    References:
        API 579-1/ASME FFS-1 (2021) Part 8 §8.4.2.
        ASME BPVC VIII Div 1 UW-33 — Misalignment tolerances.
    """

    edition = _normalise_edition(edition)
    if not isinstance(misalignment, Mapping):
        raise ValidationError("Part 8 misalignment must be a mapping.")
    if "type" not in misalignment:
        raise ValidationError("Part 8 misalignment must include 'type'.")
    mtype = str(misalignment["type"])
    if mtype not in ("offset", "angular"):
        raise ValidationError(f"Part 8 misalignment.type must be 'offset' or 'angular'; got {mtype!r}.")
    if mtype == "offset" and "value_mm" not in misalignment:
        raise ValidationError("Offset misalignment requires 'value_mm'.")
    if mtype == "angular" and "angle_deg" not in misalignment:
        raise ValidationError("Angular misalignment requires 'angle_deg'.")
    if not isinstance(loading, Mapping) or "P_MPa" not in loading:
        raise ValidationError("Part 8 loading must be a mapping with 'P_MPa'.")
    body = {
        "geometry": _geometry_to_payload(geometry),
        "misalignment": dict(misalignment),
        "loading": dict(loading),
        "material": _material_to_payload(material),
        "edition": edition,
    }
    envelope = _post("/v1/ffs/api-579/part-8", body, _local_part8, backend=backend)
    return _build_result(
        part="Part 8 (weld misalignment / shell distortion)",
        edition=edition,
        envelope=envelope,
        inputs=body,
        equipment_id=equipment_id,
        engineer=engineer,
        endpoint="/v1/ffs/api-579/part-8",
    )


def api_579_part_11(
    *,
    geometry: Union[FFSGeometry, Mapping[str, Any]],
    exposure: Mapping[str, Any],
    material: Union[str, FFSMaterial, Mapping[str, Any]],
    pre_fire_hardness_HB: float,
    post_fire_hardness_HB: float,
    edition: Optional[str] = None,
    equipment_id: Optional[str] = None,
    engineer: Optional[str] = None,
    backend: Optional[str] = None,
) -> FFSResult:
    """API 579-1 Part 11 — Fire damage assessment.

    Grades the component into Heat-Zone I-IV per §11.4 Table 11.2,
    using the *higher* of peak-temperature class and hardness-loss class.

    Args:
        geometry: Shell geometry.
        exposure: ``{"max_T_C", "duration_h", "atmosphere": "air"|"smoke"|"fuel-rich"}``.
        material: ASME II-D spec.
        pre_fire_hardness_HB: Brinell hardness before fire.
        post_fire_hardness_HB: Brinell hardness after fire.

    Returns:
        :class:`FFSResult` with ``heat_zone_grade`` ("I"-"IV"),
        ``material_replacement_required``, ``recommended_actions``.

    References:
        API 579-1/ASME FFS-1 (2021) Part 11 §11.4 + Table 11.2.
        NACE Paper 04204 — Fire-damaged equipment.
        ASME BPVC IX — Welding qualification (PWHT).
    """

    edition = _normalise_edition(edition)
    if not isinstance(exposure, Mapping) or "max_T_C" not in exposure:
        raise ValidationError("Part 11 exposure must be a mapping with 'max_T_C'.")
    body = {
        "geometry": _geometry_to_payload(geometry),
        "exposure": dict(exposure),
        "material": _material_to_payload(material),
        "pre_fire_hardness_HB": float(pre_fire_hardness_HB),
        "post_fire_hardness_HB": float(post_fire_hardness_HB),
        "edition": edition,
    }
    envelope = _post("/v1/ffs/api-579/part-11", body, _local_part11, backend=backend)
    return _build_result(
        part="Part 11 (fire damage)",
        edition=edition,
        envelope=envelope,
        inputs=body,
        equipment_id=equipment_id,
        engineer=engineer,
        endpoint="/v1/ffs/api-579/part-11",
    )


def api_579_part_12(
    *,
    geometry: Union[FFSGeometry, Mapping[str, Any]],
    dent: Optional[Mapping[str, Any]] = None,
    gouge_data: Optional[Mapping[str, Any]] = None,
    loading: Optional[Mapping[str, Any]] = None,
    material: Optional[Union[str, FFSMaterial, Mapping[str, Any]]] = None,
    edition: Optional[str] = None,
    equipment_id: Optional[str] = None,
    engineer: Optional[str] = None,
    backend: Optional[str] = None,
) -> FFSResult:
    """API 579-1 Part 12 — Dents, gouges, and combined damage.

    Cosham-Hopkins 2007 plain-dent SCF, gouge depth correction per
    §12.4.2 Eq. 12.4, modified Goodman / SWT cyclic life.

    Args:
        geometry: Shell geometry.
        dent: ``{"depth_mm", "length_mm", "width_mm", "location": (x, y)}``
            (optional — at least one of dent / gouge_data is required).
        gouge_data: ``{"depth_mm", "length_mm"}`` (optional).
        loading: ``{"P_MPa", "cyclic": bool, "delta_P_MPa"?}``.
        material: ASME II-D spec.

    Returns:
        :class:`FFSResult` with ``SCF``, ``RSF``,
        ``cyclic_remaining_life_years``.

    References:
        API 579-1/ASME FFS-1 (2021) Part 12 §12.4.
        Cosham A. & Hopkins P., Int. J. Press. Vess. Pip. 84 (2007) 207.
        Smith K.N., Watson P., Topper T.H., J. Mater. 5 (1970) 767.
    """

    edition = _normalise_edition(edition)
    if dent is None and gouge_data is None:
        raise ValidationError("Part 12 requires at least one of 'dent' or 'gouge_data'.")
    if dent is not None:
        if not isinstance(dent, Mapping) or "depth_mm" not in dent:
            raise ValidationError("Part 12 dent must include 'depth_mm'.")
    if gouge_data is not None:
        if not isinstance(gouge_data, Mapping) or "depth_mm" not in gouge_data:
            raise ValidationError("Part 12 gouge_data must include 'depth_mm'.")
    body: dict[str, Any] = {
        "geometry": _geometry_to_payload(geometry),
        "edition": edition,
    }
    if dent is not None:
        # Tuple coords need to be JSON-serialisable
        dent_payload: dict[str, Any] = {}
        for k, v in dent.items():
            if isinstance(v, tuple):
                dent_payload[k] = list(v)
            else:
                dent_payload[k] = v
        body["dent"] = dent_payload
    if gouge_data is not None:
        body["gouge_data"] = dict(gouge_data)
    if loading is not None:
        body["loading"] = dict(loading)
    if material is not None:
        body["material"] = _material_to_payload(material)
    else:
        body["material"] = {"spec": "SA-516-70"}
    envelope = _post("/v1/ffs/api-579/part-12", body, _local_part12, backend=backend)
    return _build_result(
        part="Part 12 (dents / gouges / combined)",
        edition=edition,
        envelope=envelope,
        inputs=body,
        equipment_id=equipment_id,
        engineer=engineer,
        endpoint="/v1/ffs/api-579/part-12",
    )


def api_579_part_14(
    *,
    geometry: Union[FFSGeometry, Mapping[str, Any]],
    operating: Mapping[str, Any],
    material: Union[str, FFSMaterial, Mapping[str, Any]],
    operating_history_years: float,
    edition: Optional[str] = None,
    target_life_years: float = 30.0,
    equipment_id: Optional[str] = None,
    engineer: Optional[str] = None,
    backend: Optional[str] = None,
) -> FFSResult:
    """API 579-1 Part 14 — Creep / creep-fatigue.

    Larson-Miller (and Manson-Haferd cross-check) extrapolation with
    ASME III NH allowables and Robinson cumulative damage rule.

    Args:
        geometry: Shell geometry.
        operating: ``{"T_C", "P_MPa", "t_op_hr"?}``.
        material: ASME II-D spec (e.g. ``"SA-335-P22"``).
        operating_history_years: Service years already accumulated.
        edition: API 579-1 edition.
        target_life_years: Design remaining-life target.

    Returns:
        :class:`FFSResult` with ``Larson_Miller_parameter``,
        ``creep_remaining_life_years``, ``creep_strain_total``,
        ``cumulative_damage_fraction``.

    References:
        API 579-1/ASME FFS-1 (2021) Part 14 §14.4.
        ASME BPVC III Subsection NH §HBB-T-1431 — Sm_t allowables.
        Larson F.R. & Miller J., Trans. ASME 74 (1952) 765.
        Manson S.S. & Haferd A.M., NACA TN 2890 (1953).
        Robinson E.L., Trans. ASME 60 (1938) 253.
    """

    edition = _normalise_edition(edition)
    if not isinstance(operating, Mapping) or "T_C" not in operating or "P_MPa" not in operating:
        raise ValidationError("Part 14 operating must be a mapping with 'T_C' and 'P_MPa'.")
    if operating_history_years < 0:
        raise ValidationError("operating_history_years must be >= 0.")
    body = {
        "geometry": _geometry_to_payload(geometry),
        "operating": dict(operating),
        "material": _material_to_payload(material),
        "operating_history_years": float(operating_history_years),
        "target_life_years": float(target_life_years),
        "edition": edition,
    }
    envelope = _post("/v1/ffs/api-579/part-14", body, _local_part14, backend=backend)
    return _build_result(
        part="Part 14 (creep)",
        edition=edition,
        envelope=envelope,
        inputs=body,
        equipment_id=equipment_id,
        engineer=engineer,
        endpoint="/v1/ffs/api-579/part-14",
    )
