"""Thermomechanical processing: rolling flow stress + forging + dynamic recovery.

Used in every hot-rolling, forging, extrusion, ring-rolling, seamless-tube
mill workflow. Engineers use these to size mills + predict load + DRX
fraction during hot deformation.

* **Misaka 1980 flow-stress model** for C-Mn steels.
* **Hodgson-Gibbs 1992 modified Misaka** for Nb-microalloyed.
* **Kocks-Mecking strain-hardening** + dynamic recovery.
* **Prasad-Gegel power-dissipation efficiency** for processing maps.
* **Shida 1969 high-T flow-stress fit** for steels at 900-1200°C.

References:
    * Misaka Y., Yoshimoto T., J. Jpn. Soc. Tech. Plast. 8 (1967) 414.
    * Hodgson P.D., Gibbs R.K., ISIJ Int. 32 (1992) 1329.
    * Kocks U.F., Mecking H., Prog. Mater. Sci. 48 (2003) 171.
    * Prasad Y.V.R.K., Gegel H.L., Met. Trans. A 15 (1984) 1883.
    * Shida S., J. Iron Steel Inst. Jpn. 55 (1969) 1307.
"""

from __future__ import annotations

import math


# ---------------------------------------------------------------------------
# 1. MISAKA FLOW STRESS (C-Mn steel)
# ---------------------------------------------------------------------------


def misaka_flow_stress_MPa(
    eps: float, eps_dot_per_s: float, T_K: float,
    *, C_wt_pct: float = 0.15, Mn_wt_pct: float = 0.8,
) -> float:
    """Misaka 1967 flow-stress model for plain C-Mn steel during hot rolling:

    σ = exp[(0.126 − 1.75·C + 0.594·C²) + (2851 + 2968·C − 1120·C²) / T_K]
        · ε^0.21 · ε̇^0.13

    where ε is true strain, ε̇ is strain rate in /s, T in K.

    Reference: Misaka Y., Yoshimoto T., J. Jpn. Soc. Tech. Plast. 8 (1967) 414;
    Yada H., ISIJ Int. 28 (1988) 1078 (review).
    """
    if not all(_is_finite(x) for x in [eps, eps_dot_per_s, T_K, C_wt_pct]):
        return float("nan")
    if T_K <= 0 or eps_dot_per_s <= 0:
        return float("nan")
    C = float(C_wt_pct)
    A = 0.126 - 1.75 * C + 0.594 * C ** 2
    B = 2851.0 + 2968.0 * C - 1120.0 * C ** 2
    pre = math.exp(A + B / float(T_K))
    eps_safe = max(1e-4, float(eps))
    # Misaka original formula returns flow stress in kgf/mm². Convert to MPa
    # via 1 kgf/mm² = 9.80665 MPa.
    sigma_kgf_mm2 = pre * (eps_safe ** 0.21) * (float(eps_dot_per_s) ** 0.13)
    return sigma_kgf_mm2 * 9.80665


def hodgson_gibbs_flow_stress_MPa(
    eps: float, eps_dot_per_s: float, T_K: float,
    *, C_wt_pct: float = 0.15, Nb_wt_pct: float = 0.04,
) -> float:
    """Hodgson-Gibbs 1992 extension for Nb-microalloyed HSLA steels:

    σ = misaka · (1 + 0.7 · Nb_wt_pct · exp(−10000/T))

    The Nb correction accounts for solute drag on dynamic recrystallisation.
    """
    sigma_misaka = misaka_flow_stress_MPa(eps, eps_dot_per_s, T_K, C_wt_pct=C_wt_pct)
    if not _is_finite(sigma_misaka):
        return float("nan")
    if T_K <= 0:
        return float("nan")
    nb_factor = 1.0 + 0.7 * float(Nb_wt_pct) * math.exp(-10000.0 / float(T_K))
    return sigma_misaka * nb_factor


# ---------------------------------------------------------------------------
# 2. KOCKS-MECKING STRAIN-HARDENING + DYNAMIC RECOVERY
# ---------------------------------------------------------------------------


def kocks_mecking_flow_stress(
    eps: float, *, sigma_y_MPa: float, theta_0_MPa: float, sigma_v_MPa: float,
) -> float:
    """Kocks-Mecking model: dσ/dε = θ_0 · (1 − σ/σ_v).

    Solution: ``σ(ε) = σ_v − (σ_v − σ_y) · exp(−θ_0 · ε / σ_v)``

    where θ_0 is initial work-hardening rate (typically 0.05·μ ~ 4 GPa for
    Cu, 2 GPa for Al), σ_v is the saturation stress.

    Reference: Kocks U.F., Mecking H., Prog. Mater. Sci. 48 (2003) 171.
    """
    if not all(_is_finite(x) for x in [eps, sigma_y_MPa, theta_0_MPa, sigma_v_MPa]):
        return float("nan")
    if sigma_v_MPa <= 0:
        return float("nan")
    try:
        decay = math.exp(-float(theta_0_MPa) * float(eps) / float(sigma_v_MPa))
    except OverflowError:
        decay = 0.0
    return float(sigma_v_MPa) - (float(sigma_v_MPa) - float(sigma_y_MPa)) * decay


# ---------------------------------------------------------------------------
# 3. PRASAD-GEGEL PROCESSING-MAP EFFICIENCY
# ---------------------------------------------------------------------------


def prasad_power_dissipation_efficiency(
    m_strain_rate_sensitivity: float,
) -> float:
    """Prasad-Gegel 1984 dissipation efficiency:

    η = 2 · m / (m + 1)

    Where m = ∂(ln σ) / ∂(ln ε̇) is the strain-rate sensitivity. Used to
    locate safe processing windows on a (T, ε̇) map:

    * η > 0.30: DRX regime (safe)
    * 0.20 < η < 0.30: DRV regime (transitional)
    * η < 0.20: flow instability — adiabatic shear / cracking

    Reference: Prasad Y.V.R.K., Gegel H.L., Met. Trans. A 15 (1984) 1883.
    """
    if not _is_finite(m_strain_rate_sensitivity):
        return float("nan")
    m = float(m_strain_rate_sensitivity)
    if m <= -1:
        return float("nan")
    return 2.0 * m / (m + 1.0)


def prasad_instability_parameter(
    m: float, dm_d_ln_eps_dot: float = 0.0,
) -> float:
    """Prasad instability ξ(m, ε̇) for processing maps:

    ξ = ∂(ln(m/(m+1))) / ∂(ln ε̇) + m

    Negative ξ ⇒ flow instability (avoid this regime).

    Simplified to ``ξ ≈ m + dm/d(ln ε̇) · (m+1)/m`` for empirical use.
    """
    if not all(_is_finite(x) for x in [m, dm_d_ln_eps_dot]):
        return float("nan")
    if abs(m) < 1e-9:
        return float("nan")
    return float(m) + float(dm_d_ln_eps_dot) * (float(m) + 1.0) / float(m)


# ---------------------------------------------------------------------------
# 4. SHIDA 1969 FLOW STRESS (steel hot rolling)
# ---------------------------------------------------------------------------


def shida_flow_stress_MPa(
    eps: float, eps_dot_per_s: float, T_C: float,
    *, sigma_0_MPa: float = 130.0,
) -> float:
    """Shida 1969 power-law flow stress for steel:

    σ = σ_0 · (1273/T)^4 · ε^n · (ε̇/10)^m

    where T in K, n ≈ 0.21 + 0.27·C, m ≈ 0.13.

    Used in 4-high mill load calculation.
    """
    if not all(_is_finite(x) for x in [eps, eps_dot_per_s, T_C]):
        return float("nan")
    if T_C < -273.15 or eps_dot_per_s <= 0:
        return float("nan")
    T_K = float(T_C) + 273.15
    n = 0.21
    m = 0.13
    eps_safe = max(1e-4, float(eps))
    pre = float(sigma_0_MPa) * (1273.0 / T_K) ** 4
    return pre * (eps_safe ** n) * ((float(eps_dot_per_s) / 10.0) ** m)


def _is_finite(x) -> bool:
    try:
        return math.isfinite(float(x))
    except (TypeError, ValueError):
        return False


__all__ = [
    "misaka_flow_stress_MPa", "hodgson_gibbs_flow_stress_MPa",
    "kocks_mecking_flow_stress",
    "prasad_power_dissipation_efficiency", "prasad_instability_parameter",
    "shida_flow_stress_MPa",
]
