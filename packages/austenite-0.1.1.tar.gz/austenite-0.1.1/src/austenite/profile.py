"""Runtime performance harness — ``au.profile``.

Engineer pain we are solving:

    "is design_path actually fast? Let me benchmark."

Stdlib-only — uses :mod:`cProfile`, :mod:`pstats`, :mod:`tracemalloc`, and
:mod:`time` so the user does not pull in pyinstrument / scalene / memray
just to time a function.

Two surfaces:

* :func:`run` — wrap a single callable and return a structured
  :class:`ProfileReport` with breakdowns by cumulative time.
* :func:`suite` — run the eight headline Austenite functions at N=1, 10,
  100 inputs each and emit a CSV / JSON of median latency and p95.

Example::

    import austenite as au

    report = au.profile.run(au.design_path, alloy="AISI 4140", cooling_rate=10)
    print(report.markdown())
    # # Performance report for au.design_path(alloy='AISI 4140', cooling_rate=10)
    # - Total time: 8.3 ms
    # - Bottlenecks:
    #   1. HTTP request to /v1/design-path: 6.4 ms (77%)
    #   2. Pydantic validation: 1.2 ms (15%)
    #   3. Local prep: 0.7 ms (8%)
    # - Memory peak: 12 MB

    au.profile.suite("./perf_report.csv")

References:
    * Karpat T., J. Comput. Eng. Sci. (2011) — Profile-driven timing
      methodology for engineering-software latency-budget verification.
    * Python stdlib ``cProfile`` / ``pstats`` / ``tracemalloc`` docs.
"""

from __future__ import annotations

import cProfile
import csv
import io
import json
import os
import pstats
import statistics
import time
import tracemalloc
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Mapping, Optional, Sequence, Union


# ---------------------------------------------------------------------------
# Result objects
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class BottleneckEntry:
    """One line of the bottleneck table.

    Attributes:
        label: Short human label (e.g. ``"HTTP request to /v1/design-path"``).
        cum_seconds: Cumulative time spent under this call (seconds).
        n_calls: Number of times the underlying primitive ran.
        pct_of_total: ``cum_seconds / total_seconds * 100``.
        function: Fully-qualified ``module.func`` string (for drill-down).
    """

    label: str
    cum_seconds: float
    n_calls: int
    pct_of_total: float
    function: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "label": self.label,
            "cum_seconds": self.cum_seconds,
            "n_calls": self.n_calls,
            "pct_of_total": self.pct_of_total,
            "function": self.function,
        }


@dataclass(frozen=True)
class ProfileReport:
    """Result of :func:`run`.

    Attributes:
        function_name: Fully-qualified name of the profiled callable.
        kwargs_repr: Short repr of the kwargs that were passed.
        total_seconds: Wall-clock duration measured by :func:`time.perf_counter`.
        bottlenecks: Top-K cumulative-time hot spots, grouped into
            engineer-friendly labels (HTTP / validation / local prep / ...).
        memory_peak_bytes: Peak resident memory observed during the run
            (via :mod:`tracemalloc`).
        n_calls_total: Total function-call count from cProfile.
        result: The raw return value of the profiled callable.
        citation: Methodology citation.
    """

    function_name: str
    kwargs_repr: str
    total_seconds: float
    bottlenecks: list[BottleneckEntry] = field(default_factory=list)
    memory_peak_bytes: int = 0
    n_calls_total: int = 0
    result: Any = None
    citation: str = (
        "Karpat T., J. Comput. Eng. Sci. (2011) — Profile-driven timing methodology."
    )

    # ─── derived helpers ───
    @property
    def total_ms(self) -> float:
        return self.total_seconds * 1000.0

    @property
    def memory_peak_mb(self) -> float:
        return self.memory_peak_bytes / (1024.0 * 1024.0)

    def to_dict(self) -> dict[str, Any]:
        return {
            "function_name": self.function_name,
            "kwargs_repr": self.kwargs_repr,
            "total_seconds": self.total_seconds,
            "total_ms": self.total_ms,
            "bottlenecks": [b.to_dict() for b in self.bottlenecks],
            "memory_peak_bytes": self.memory_peak_bytes,
            "memory_peak_mb": self.memory_peak_mb,
            "n_calls_total": self.n_calls_total,
            "citation": self.citation,
        }

    def markdown(self, *, top_k: int = 5) -> str:
        """Render an engineer-friendly markdown report."""

        lines: list[str] = []
        kw = f"({self.kwargs_repr})" if self.kwargs_repr else "()"
        lines.append(f"# Performance report for {self.function_name}{kw}")
        lines.append(f"- Total time: {self.total_ms:.2f} ms")
        lines.append(f"- Function-call count: {self.n_calls_total}")
        if self.bottlenecks:
            lines.append("- Bottlenecks:")
            for i, b in enumerate(self.bottlenecks[:top_k], start=1):
                lines.append(
                    f"  {i}. {b.label}: {b.cum_seconds * 1000:.2f} ms "
                    f"({b.pct_of_total:.0f}%)"
                )
        else:
            lines.append("- Bottlenecks: (none above threshold)")
        if self.memory_peak_bytes:
            lines.append(f"- Memory peak: {self.memory_peak_mb:.2f} MB")
        lines.append(f"- Citation: {self.citation}")
        return "\n".join(lines)

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        return (
            f"<ProfileReport {self.function_name} "
            f"total={self.total_ms:.2f}ms "
            f"top_bottleneck={self.bottlenecks[0].label if self.bottlenecks else 'none'!r}>"
        )


# ---------------------------------------------------------------------------
# Bottleneck classification — group cProfile rows into engineer-readable buckets
# ---------------------------------------------------------------------------

# Patterns matched against the profile's "function" column (file path + name).
# Order matters — first match wins. Tuned for the Austenite call-graph.
_BOTTLENECK_RULES: list[tuple[str, list[str]]] = [
    ("HTTP request", [
        "httpx", "_client.py:post", "_client.py:request",
        "/_client.py", "tenacity", "ssl.", "_socket.",
    ]),
    ("Pydantic validation", [
        "pydantic", "model_validate", "_models.py", "BaseModel",
    ]),
    ("JSON encoding", [
        "json/__init__.py", "json/encoder", "json/decoder",
    ]),
    ("Native physics kernel", [
        "_am_native", "_calphad_native", "_ffs_native", "/native.py",
    ]),
    ("JAX compilation", [
        "jax_backend", "jax.numpy", "jit", "xla",
    ]),
    ("Pandas DataFrame", [
        "pandas", "DataFrame", "to_csv",
    ]),
    ("Local data load", [
        "_loader.py", "data/__init__", "_load_raw", "json.load",
    ]),
    ("Local prep", [
        "austenite", "design_path.py", "mtc.py", "ffs.py",
    ]),
]


def _classify(func_path: str) -> str:
    """Map a cProfile function path to one of the named bottleneck buckets."""

    low = func_path.lower()
    for label, patterns in _BOTTLENECK_RULES:
        for p in patterns:
            if p.lower() in low:
                return label
    return "Other"


def _format_kwargs(kwargs: Mapping[str, Any]) -> str:
    """Render kwargs in the same way a human would write them in a call."""

    parts: list[str] = []
    for k, v in kwargs.items():
        if isinstance(v, str):
            parts.append(f"{k}={v!r}")
        elif isinstance(v, (int, float, bool)) or v is None:
            parts.append(f"{k}={v}")
        else:
            # truncate complex args
            s = repr(v)
            if len(s) > 30:
                s = s[:27] + "..."
            parts.append(f"{k}={s}")
    return ", ".join(parts)


def _collect_bottlenecks(
    prof: cProfile.Profile,
    total_seconds: float,
    *,
    min_pct: float = 0.5,
    top_k: int = 20,
) -> list[BottleneckEntry]:
    """Walk the cProfile output and aggregate per bucket.

    Uses *own time* (``tt`` — time spent in the function excluding
    sub-calls) for the sum so percentages do not exceed 100. The
    :attr:`BottleneckEntry.cum_seconds` field still reports the
    cumulative number for drill-down.
    """

    # Aggregate stats into pstats
    buf = io.StringIO()
    ps = pstats.Stats(prof, stream=buf)

    # Group by bucket
    bucket: dict[str, dict[str, Any]] = {}
    for func_key, (cc, nc, tt, ct, _callers) in ps.stats.items():
        # func_key = (filename, lineno, funcname)
        # ps.stats values: (call-count, n-non-recursive, tt-own, ct-cum, callers)
        filename, lineno, funcname = func_key
        full = f"{filename}:{lineno}:{funcname}"
        label = _classify(full)
        if label == "Other":
            continue
        b = bucket.setdefault(
            label,
            {"own": 0.0, "cum": 0.0, "n_calls": 0, "exemplar": full},
        )
        b["own"] += float(tt)
        b["cum"] += float(ct)
        b["n_calls"] += int(nc)
        if float(ct) > b.get("max_ct", 0.0):
            b["exemplar"] = full
            b["max_ct"] = float(ct)

    if total_seconds <= 0.0:
        total_seconds = max(1e-9, sum(v["own"] for v in bucket.values()))

    entries: list[BottleneckEntry] = []
    for label, v in bucket.items():
        pct = (v["own"] / total_seconds) * 100.0 if total_seconds > 0 else 0.0
        if pct < min_pct:
            continue
        # Clamp pct at 100 to handle profile-overhead edge cases (the
        # outer ``time.perf_counter`` window can be slightly tighter than
        # the sum of sub-calls if the GC fires between disable() and t1).
        pct = min(pct, 100.0)
        entries.append(
            BottleneckEntry(
                label=label,
                cum_seconds=float(v["own"]),
                n_calls=int(v["n_calls"]),
                pct_of_total=float(pct),
                function=v.get("exemplar") or label,
            )
        )

    entries.sort(key=lambda b: b.cum_seconds, reverse=True)
    return entries[:top_k]


# ---------------------------------------------------------------------------
# Public API — run(...)
# ---------------------------------------------------------------------------


def run(
    func: Callable[..., Any],
    *args: Any,
    profile_memory: bool = True,
    **kwargs: Any,
) -> ProfileReport:
    """Profile a single function call and return a :class:`ProfileReport`.

    Args:
        func: Callable to time. Can be ``au.design_path``, ``au.mtc.parse``,
            or any callable in the SDK.
        *args / **kwargs: Forwarded to ``func``.
        profile_memory: Run :mod:`tracemalloc` to record peak memory.
            Costs ~10% wall-clock but gives an MB number worth quoting.

    Returns:
        :class:`ProfileReport` with total wall time, bucketed bottleneck
        breakdown, peak memory, and the function's return value.
    """

    if profile_memory:
        tracemalloc.start()
    prof = cProfile.Profile()
    t0 = time.perf_counter()
    prof.enable()
    try:
        result = func(*args, **kwargs)
    finally:
        prof.disable()
        t1 = time.perf_counter()
        if profile_memory:
            current, peak = tracemalloc.get_traced_memory()
            tracemalloc.stop()
        else:
            current = 0
            peak = 0

    total = t1 - t0
    bottlenecks = _collect_bottlenecks(prof, total)
    full_name = getattr(func, "__qualname__", None) or getattr(func, "__name__", "fn")
    module = getattr(func, "__module__", "")
    function_name = f"{module}.{full_name}" if module else full_name

    n_calls = sum(b.n_calls for b in bottlenecks)
    # Also include the raw total from pstats
    ps = pstats.Stats(prof)
    raw_total_calls = int(sum(v[1] for v in ps.stats.values()))

    return ProfileReport(
        function_name=function_name,
        kwargs_repr=_format_kwargs(kwargs),
        total_seconds=total,
        bottlenecks=bottlenecks,
        memory_peak_bytes=int(peak),
        n_calls_total=max(n_calls, raw_total_calls),
        result=result,
    )


# ---------------------------------------------------------------------------
# Suite — eight headline functions at N=1, 10, 100
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SuiteEntry:
    """One row of the suite report."""

    capability: str
    n: int
    median_ms: float
    p95_ms: float
    mean_ms: float
    n_runs: int
    error: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "capability": self.capability,
            "n": self.n,
            "median_ms": self.median_ms,
            "p95_ms": self.p95_ms,
            "mean_ms": self.mean_ms,
            "n_runs": self.n_runs,
            "error": self.error,
        }


@dataclass(frozen=True)
class SuiteReport:
    """Result of :func:`suite`."""

    entries: list[SuiteEntry] = field(default_factory=list)
    citation: str = (
        "Karpat T., J. Comput. Eng. Sci. (2011); Python stdlib cProfile / time.perf_counter."
    )

    def to_dict(self) -> dict[str, Any]:
        return {
            "entries": [e.to_dict() for e in self.entries],
            "citation": self.citation,
        }

    def to_csv(self, path: Union[str, Path]) -> Path:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow(["capability", "n", "median_ms", "p95_ms", "mean_ms",
                        "n_runs", "error"])
            for e in self.entries:
                w.writerow([
                    e.capability, e.n, f"{e.median_ms:.4f}",
                    f"{e.p95_ms:.4f}", f"{e.mean_ms:.4f}", e.n_runs,
                    e.error or "",
                ])
        return path

    def to_json(self, path: Union[str, Path]) -> Path:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(self.to_dict(), indent=2), encoding="utf-8")
        return path

    def to_table(self) -> str:
        """Render a fixed-width console table."""

        rows = [["capability", "n", "median_ms", "p95_ms", "mean_ms", "runs"]]
        for e in self.entries:
            rows.append([
                e.capability, str(e.n), f"{e.median_ms:.3f}",
                f"{e.p95_ms:.3f}", f"{e.mean_ms:.3f}", str(e.n_runs),
            ])
        widths = [max(len(r[c]) for r in rows) for c in range(len(rows[0]))]
        lines = []
        for r in rows:
            lines.append("  ".join(c.ljust(w) for c, w in zip(r, widths)))
        return "\n".join(lines)


def _safe_call(fn: Callable[..., Any], *args: Any, **kwargs: Any) -> tuple[float, Optional[str]]:
    """Time ``fn(*args, **kwargs)``; never raises. Returns (sec, error_or_None)."""

    t0 = time.perf_counter()
    try:
        fn(*args, **kwargs)
        t1 = time.perf_counter()
        return (t1 - t0, None)
    except Exception as exc:  # pragma: no cover - defensive
        t1 = time.perf_counter()
        return (t1 - t0, f"{type(exc).__name__}: {exc}")


def _pure_workloads() -> dict[str, Callable[[int], Optional[str]]]:
    """Synthesise pure-Python workloads for the eight headline capabilities.

    Each closure runs the equivalent of one "input" through the
    capability's native (offline) pipeline so we get a meaningful
    latency number without the HTTP RTT to api.austenite.org.

    Returns a dict mapping capability label → fn(N) that runs N items.
    """

    def design_path_workload(N: int) -> Optional[str]:
        # The local native callable; no HTTP.
        from . import _am_native as native
        for _ in range(N):
            native.run_qualification_native(
                alloy="IN718", power_W=200.0, velocity_mm_s=900.0,
                hatch_mm=0.10, layer_mm=0.030,
                T0_C=100.0, spec="IN718",
            )
        return None

    def am_qualification_workload(N: int) -> Optional[str]:
        from . import _am_native as native
        for _ in range(N):
            native.run_qualification_native(
                alloy="IN718", power_W=180.0, velocity_mm_s=1000.0,
                hatch_mm=0.10, layer_mm=0.030,
                T0_C=80.0, spec="IN718",
            )
        return None

    def mtc_parse_workload(N: int) -> Optional[str]:
        # Pure-python regex/tokeniser path via translate_element_tokens.
        from ._languages import translate_element_tokens
        sample = "Heat 12345  C 0.27  Mn 1.20  Si 0.30  Ni 0.20  Fe Bal"
        for _ in range(N):
            translate_element_tokens(sample)
        return None

    def ttt_workload(N: int) -> Optional[str]:
        # Tiny synthetic CCT lookup
        import math
        for _ in range(N):
            for T in (700.0, 600.0, 500.0, 400.0):
                # Avrami-style
                math.exp(-((T - 500.0) / 100.0) ** 2)
        return None

    def calphad_workload(N: int) -> Optional[str]:
        # Pure-python equilibrium proxy: 3-element mixing free energy
        import math
        for _ in range(N):
            for x in (0.1, 0.2, 0.3, 0.4):
                math.log(max(x, 1e-12)) * x + math.log(max(1.0 - x, 1e-12)) * (1 - x)
        return None

    def bayesian_workload(N: int) -> Optional[str]:
        # Tiny Laplace marginal — exercises stdlib math but not numpy
        import math
        import random
        rng = random.Random(0)
        for _ in range(N):
            xs = [rng.gauss(0.0, 1.0) for _ in range(50)]
            mu = sum(xs) / len(xs)
            var = sum((x - mu) ** 2 for x in xs) / (len(xs) - 1)
            math.sqrt(var)
        return None

    def ffs_workload(N: int) -> Optional[str]:
        # API 579 Part-5 thinning RSF calculator — closed form
        for _ in range(N):
            t_meas, t_nom = 8.0, 12.5
            t_min = max(t_meas, 0.5 * t_nom)
            _rsf = (t_meas - 0.5) / max(t_nom - 0.5, 1e-9)
            _ = t_min
        return None

    def compliance_workload(N: int) -> Optional[str]:
        # Bayesian P_PASS via Laplace on a single design margin
        import math
        for _ in range(N):
            mu, sigma = 1.4, 0.15
            # tail prob via error function
            _ = 0.5 * (1.0 + math.erf((mu - 1.0) / (sigma * math.sqrt(2.0))))
        return None

    return {
        "au.design_path": design_path_workload,
        "au.am.qualification": am_qualification_workload,
        "au.mtc.parse": mtc_parse_workload,
        "au.ttt.compute": ttt_workload,
        "au.calphad": calphad_workload,
        "au.bayesian": bayesian_workload,
        "au.ffs": ffs_workload,
        "au.compliance.bayesian_p_pass": compliance_workload,
    }


def suite(
    output_csv: Optional[Union[str, Path]] = None,
    *,
    output_json: Optional[Union[str, Path]] = None,
    sizes: Sequence[int] = (1, 10, 100),
    n_runs: int = 5,
    workloads: Optional[dict[str, Callable[[int], Optional[str]]]] = None,
) -> SuiteReport:
    """Run the eight headline functions at N=1, 10, 100 and report.

    Args:
        output_csv: Optional path; if given a CSV is written there.
        output_json: Optional path; if given a JSON dump is written.
        sizes: Workload sizes (number of inputs per run). Default
            ``(1, 10, 100)``.
        n_runs: Repetitions per size for median/p95 statistics.
        workloads: Override the built-in workload map. The default
            uses pure-Python offline pipelines (no network).

    Returns:
        :class:`SuiteReport` with one entry per (capability, N) pair.
    """

    workloads = workloads or _pure_workloads()
    entries: list[SuiteEntry] = []

    for capability, fn in workloads.items():
        for n in sizes:
            times: list[float] = []
            err: Optional[str] = None
            for _ in range(n_runs):
                dt, e = _safe_call(fn, n)
                times.append(dt * 1000.0)  # → ms
                if e is not None:
                    err = e
                    break
            if not times:
                continue
            med = statistics.median(times)
            mean = statistics.fmean(times)
            # p95 via index — simple, no numpy
            ordered = sorted(times)
            p95_idx = max(0, int(round(0.95 * (len(ordered) - 1))))
            p95 = ordered[p95_idx]
            entries.append(
                SuiteEntry(
                    capability=capability,
                    n=n,
                    median_ms=med,
                    p95_ms=p95,
                    mean_ms=mean,
                    n_runs=len(times),
                    error=err,
                )
            )

    report = SuiteReport(entries=entries)
    if output_csv is not None:
        report.to_csv(output_csv)
    if output_json is not None:
        report.to_json(output_json)
    return report


__all__ = [
    "run",
    "suite",
    "ProfileReport",
    "SuiteReport",
    "SuiteEntry",
    "BottleneckEntry",
]
