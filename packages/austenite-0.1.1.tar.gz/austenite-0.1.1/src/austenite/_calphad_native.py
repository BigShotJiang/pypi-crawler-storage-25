"""Pure-Python CALPHAD equilibrium engine — offline fallback.

This module is a port of the TypeScript CALPHAD engine at
``apps/web/src/lib/calphad/`` to numpy/scipy so ``au.calphad.equilibrium``
can be evaluated **OFFLINE** (without hitting the HTTP API) when
``AUSTENITE_OFFLINE=1`` or when the HTTP path fails.

Scope
-----
* Multi-sublattice **compound energy formalism** (Hillert & Staffansson
  1970, Sundman & Ågren 1981) — used here in the substitutional /
  line-compound approximation that is documented for the engineering
  Fe-Cr-Ni-Mo / Fe-Cr / Fe-C / Fe-Ni systems the engine targets.
* **Redlich-Kister** binary excess Gibbs energy with L^0, L^1, L^2
  (Muggianu extension for multicomponent solutions).
* **Inden-Hillert-Jarl 1978** ferromagnetic ordering term for BCC-Fe,
  FCC-Ni, HCP-Co, etc. — including the antiferromagnetic SGTE convention.
* **Common-tangent construction** by global grid sampling, lower-convex-
  hull search, and a ``scipy.optimize.minimize`` (SLSQP / L-BFGS-B)
  local polish on the chemical-potential equality conditions.
* **Phase fractions** + per-element **activities** returned as dicts.

Algorithm overview
------------------
The classic CALPHAD "global grid + convex hull + local polish" pipeline
(the same idea pycalphad and Thermo-Calc's "global test" use):

1. **Sample** every candidate phase's composition simplex on a regular
   grid; evaluate G(x, T) at each point to build a (composition, G) point
   cloud. Each line compound contributes a single point.
2. **Lower convex hull**: the equilibrium state is the lower convex hull
   of that cloud in (c, G) space; the facet enclosing the bulk
   composition gives the stable phase assemblage by the generalised lever
   rule (barycentric coordinates ARE the phase fractions).
3. **Local polish** via scipy.optimize.minimize (SLSQP) on the
   participating phase compositions and fractions, holding mass balance
   and Σ f_p = 1.

References
----------
* Hillert, M.; Staffansson, L.-I. *Regular-solution model for stoichiometric
  phases and ionic melts*. Acta Chem. Scand. 24 (1970) 3618-3626.
* Sundman, B.; Ågren, J. *A regular solution model for phases with several
  components and sublattices, suitable for computer applications*.
  J. Phys. Chem. Solids 42 (1981) 297-301.
* Hillert, M.; Jarl, M. *A model for alloying in ferromagnetic metals*.
  CALPHAD 2 (1978) 227-238.
* Inden, G. *Determination of chemical and magnetic interchange energies
  in bcc alloys*. Z. Metallkd. 67 (1976) 401-408 (Inden 1976);
  Inden, G.; Pitsch, W. (1981) further refinement.
* Dinsdale, A. T. *SGTE data for pure elements*. CALPHAD 15 (1991) 317-425.
* Andersson, J.-O. *Thermodynamic properties of Cr-Fe*.
  CALPHAD 11 (1987) 83-92 (Andersson 1985 / 1987 Fe-Cr assessment).
* Andersson, J.-O.; Sundman, B. *Thermodynamic properties of the Cr-Fe
  system*. CALPHAD 11 (1987) 83-92.
* Lukas, H. L.; Fries, S. G.; Sundman, B. *Computational Thermodynamics —
  The CALPHAD Method*. Cambridge University Press (2007).

A Javanshir Hasanov production.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Callable, Mapping

import numpy as np

try:  # scipy is optional at import time — tests skip if missing
    from scipy.optimize import minimize
    _HAS_SCIPY = True
except ImportError:  # pragma: no cover - exercised only without scipy
    minimize = None  # type: ignore[assignment]
    _HAS_SCIPY = False


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

R_GAS: float = 8.31451  # J/mol/K — SGTE-1991 value
"""Universal gas constant in SGTE-1991 units. Using the modern
8.314462618 shifts entropies by ~2e-5; we keep the SGTE value so the
engine reproduces published numbers bit-for-bit."""


SgtePhase = str  # 'BCC_A2' | 'FCC_A1' | 'LIQUID' | 'HCP_A3'


# ---------------------------------------------------------------------------
# SGTE pure-element Gibbs energy data (Dinsdale 1991)
#
# Each interval represents
#
#   G(T) = a + b·T + c·T·ln T + d·T² + e·T³ + f/T + g·T⁷ + h·T⁻⁹
#
# valid for Tlow ≤ T < Thigh. Units: J/mol, K.
#
# The minimum binary subset for Fe-Cr-Ni (+ LIQUID + σ) is included here;
# the full database lives in the TS reference and can be ported on demand.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SgteInterval:
    """One temperature interval of an SGTE pure-element polynomial."""

    Tlow: float
    Thigh: float
    a: float
    b: float
    c: float
    d: float
    e: float
    f: float
    g: float = 0.0  # T⁷ term
    h: float = 0.0  # T⁻⁹ term

    def eval(self, T: float) -> float:
        ln_T = math.log(T)
        g_term = self.g * T**7 if self.g else 0.0
        h_term = self.h / T**9 if self.h else 0.0
        return (
            self.a
            + self.b * T
            + self.c * T * ln_T
            + self.d * T * T
            + self.e * T**3
            + self.f / T
            + g_term
            + h_term
        )


# SGTE polynomials transcribed from Dinsdale 1991 (CALPHAD 15:317).
# Mirrors apps/web/src/lib/calphad/sgte-unary.ts for binary parity.
SGTE_DATA: dict[str, dict[SgtePhase, list[SgteInterval]]] = {
    # ── IRON  (SER: BCC_A2) ─────────────────────────────────────────────
    "FE": {
        "BCC_A2": [
            SgteInterval(298.15, 1811, 1225.7, 124.134, -23.5143, -0.00439752, -5.8927e-8, 77359),
            SgteInterval(1811, 6000, -25383.581, 299.31255, -46, 0, 0, 0, h=2.29603e31),
        ],
        "FCC_A1": [
            SgteInterval(
                298.15, 1811,
                -1462.4 + 1225.7, 8.282 + 124.134, -1.15 - 23.5143,
                6.4e-4 - 0.00439752, -5.8927e-8, 77359,
            ),
            SgteInterval(1811, 6000, -27098.266, 300.25256, -46, 0, 0, 0, h=2.78854e31),
        ],
        "LIQUID": [
            SgteInterval(
                298.15, 1811,
                12040.17 + 1225.7, -6.55843 + 124.134, -23.5143,
                -0.00439752, -5.8927e-8, 77359, g=-3.67516e-21,
            ),
            SgteInterval(1811, 6000, -10838.83, 291.302, -46, 0, 0, 0),
        ],
        "HCP_A3": [
            SgteInterval(
                298.15, 1811,
                -2243.38 + 1225.7, 5.094 + 124.134, -23.5143,
                -0.00439752, -5.8927e-8, 77359,
            ),
            SgteInterval(
                1811, 6000,
                -2243.38 - 25383.581, 5.094 + 299.31255, -46,
                0, 0, 0, h=2.29603e31,
            ),
        ],
    },
    # ── CHROMIUM  (SER: BCC_A2) ─────────────────────────────────────────
    "CR": {
        "BCC_A2": [
            SgteInterval(298.15, 2180, -8856.94, 157.48, -26.908, 0.00189435, -1.47721e-6, 139250),
            SgteInterval(2180, 6000, -34869.344, 344.18, -50, 0, 0, 0, h=-2.88526e32),
        ],
        "FCC_A1": [
            SgteInterval(
                298.15, 2180,
                -8856.94 + 7284, 157.48 + 0.163, -26.908,
                0.00189435, -1.47721e-6, 139250,
            ),
            SgteInterval(2180, 6000, -34869.344 + 7284, 344.18 + 0.163, -50, 0, 0, 0, h=-2.88526e32),
        ],
        "LIQUID": [
            SgteInterval(
                298.15, 2180,
                24339.955 - 8856.94, -11.8078 + 157.48, -26.908,
                0.00189435, -1.47721e-6, 139250, g=2.37615e-21,
            ),
            SgteInterval(2180, 6000, -16459.984, 335.616316, -50, 0, 0, 0),
        ],
        "HCP_A3": [
            SgteInterval(298.15, 2180, -8856.94 + 4438, 157.48, -26.908, 0.00189435, -1.47721e-6, 139250),
            SgteInterval(2180, 6000, -34869.344 + 4438, 344.18, -50, 0, 0, 0, h=-2.88526e32),
        ],
    },
    # ── NICKEL  (SER: FCC_A1) ───────────────────────────────────────────
    "NI": {
        "FCC_A1": [
            SgteInterval(298.15, 1728, -5179.159, 117.854, -22.096, -0.0048407, 0, 0),
            SgteInterval(1728, 3000, -27840.655, 279.135, -43.1, 0, 0, 0, h=1.12754e31),
        ],
        "BCC_A2": [
            SgteInterval(
                298.15, 1728,
                -5179.159 + 8715.084, 117.854 - 3.556, -22.096, -0.0048407, 0, 0,
            ),
            SgteInterval(
                1728, 3000,
                -27840.655 + 8715.084, 279.135 - 3.556, -43.1, 0, 0, 0, h=1.12754e31,
            ),
        ],
        "LIQUID": [
            SgteInterval(
                298.15, 1728,
                -5179.159 + 11235.527, 117.854 - 5.32, -22.096,
                -0.0048407, 0, 0, g=-3.82318e-21,
            ),
            SgteInterval(1728, 3000, -9549.775, 268.598, -43.1, 0, 0, 0),
        ],
        "HCP_A3": [
            SgteInterval(
                298.15, 1728,
                -5179.159 + 1046, 117.854 + 1.255, -22.096, -0.0048407, 0, 0,
            ),
            SgteInterval(
                1728, 3000,
                -27840.655 + 1046, 279.135 + 1.255, -43.1, 0, 0, 0, h=1.12754e31,
            ),
        ],
    },
}


SGTE_ELEMENTS: list[str] = list(SGTE_DATA.keys())


ATOMIC_WEIGHT: dict[str, float] = {
    "FE": 55.845, "CR": 51.996, "NI": 58.693, "MO": 95.95,
    "C": 12.011, "N": 14.007, "MN": 54.938, "SI": 28.085,
    "CU": 63.546, "AL": 26.982, "TI": 47.867, "CO": 58.933,
    "NB": 92.906, "V": 50.942, "W": 183.84,
}


def pure_g(element: str, phase: SgtePhase, T: float) -> float:
    """Pure-element molar Gibbs energy °G(T) for a structure (J/mol).

    Picks the correct temperature interval and falls back to the nearest
    interval edge if T is outside the published range — the minimizer
    never receives NaN at extreme T. Elements without a description for
    the requested structure return a 5e5 J/mol penalty so the minimiser
    naturally avoids placing them in an undefined phase.
    """

    el = element.upper()
    intervals = SGTE_DATA.get(el, {}).get(phase)
    if not intervals:
        return 5.0e5
    for iv in intervals:
        if iv.Tlow <= T < iv.Thigh:
            return iv.eval(T)
    # outside range — clamp to nearest edge
    if T < intervals[0].Tlow:
        return intervals[0].eval(intervals[0].Tlow + 1e-6)
    last = intervals[-1]
    return last.eval(last.Thigh - 1e-6)


# ---------------------------------------------------------------------------
# Magnetic Hillert-Jarl 1978 term (with Inden 1976 parameter set)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class MagneticParams:
    """Inden-Hillert-Jarl magnetic parameters: Tc (Curie/Néel, K), beta
    (moment in Bohr magnetons), p (structure factor: 0.4 BCC, 0.28 FCC/HCP).

    SGTE convention: antiferromagnetic Tc and beta are stored NEGATIVE.
    """

    Tc: float
    beta: float
    p: float


MAGNETIC_DATA: dict[str, dict[SgtePhase, MagneticParams]] = {
    "FE": {
        "BCC_A2": MagneticParams(1043, 2.22, 0.4),
        "FCC_A1": MagneticParams(-201, -2.1, 0.28),
    },
    "CR": {
        "BCC_A2": MagneticParams(-311.5, -0.008, 0.4),
    },
    "NI": {
        "FCC_A1": MagneticParams(633, 0.52, 0.28),
    },
}


def magnetic_g(mp: MagneticParams, T: float) -> float:
    """Inden-Hillert-Jarl magnetic contribution to the Gibbs energy (J/mol).

    G_mag = R·T·ln(β+1)·f(τ),   τ = T / T_C

    with f(τ) the Hillert-Jarl 1978 polynomial (different branches above
    and below the Curie/Néel temperature). The Inden 1976 / Hillert-Jarl
    1978 prescription uses p = 0.4 for BCC and 0.28 for FCC/HCP.
    Antiferromagnetic Tc, beta are stored negative per Dinsdale 1991 SGTE
    convention; we take absolute values here.
    """

    Tc = abs(mp.Tc)
    beta = abs(mp.beta)
    if Tc <= 1e-6 or beta <= 1e-9:
        return 0.0
    p = mp.p
    tau = T / Tc
    A = 518 / 1125 + (11692 / 15975) * (1 / p - 1)
    if tau < 1:
        f = 1 - (1 / A) * (
            (79 / (tau * 140 * p))
            + (474 / 497) * (1 / p - 1) * (tau**3 / 6 + tau**9 / 135 + tau**15 / 600)
        )
    else:
        f = -(1 / A) * (tau**-5 / 10 + tau**-15 / 315 + tau**-25 / 1500)
    return R_GAS * T * math.log(beta + 1) * f


def averaged_magnetic(
    x: Mapping[str, float], phase: SgtePhase
) -> MagneticParams | None:
    """Composition-averaged magnetic params for a solution phase (or None).

    Uses signed mixing: Tc = Σ x_i·Tc_i, β = Σ x_i·β_i — the standard
    simplest mixing rule (adequate for dilute-to-moderate alloys).
    """

    Tc = 0.0
    beta = 0.0
    p = 0.4 if phase == "BCC_A2" else 0.28
    any_mag = False
    for el, xi in x.items():
        mp = MAGNETIC_DATA.get(el.upper(), {}).get(phase)
        if mp is not None:
            any_mag = True
            Tc += xi * mp.Tc
            beta += xi * mp.beta
            p = mp.p
    return MagneticParams(Tc, beta, p) if any_mag else None


# ---------------------------------------------------------------------------
# Redlich-Kister binary excess parameters
#
# G_excess(binary i-j) = x_i·x_j · Σ_ν L^ν_{ij} · (x_i − x_j)^ν,
#   L^ν(T) = a + b·T
#
# Multicomponent: Muggianu extension (sum over all binary pairs).
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class LCoeff:
    a: float
    b: float

    def value(self, T: float) -> float:
        return self.a + self.b * T


# Mirrors apps/web/src/lib/calphad/rk-parameters.ts. Keys are
# alphabetically-sorted "A-B" strings; values map phase -> [L0, L1, L2].
RK_PARAMETERS: dict[str, dict[SgtePhase, list[LCoeff]]] = {
    # Fe-Cr — Andersson & Sundman 1987
    "CR-FE": {
        "BCC_A2": [LCoeff(20500, -9.68), LCoeff(0, 0)],
        "FCC_A1": [LCoeff(10833, -7.477), LCoeff(1410, 0)],
        "LIQUID": [LCoeff(-17737, 7.996454), LCoeff(-1331, 0)],
    },
    # Fe-Ni — SGTE / Xiong 2011
    "FE-NI": {
        "BCC_A2": [LCoeff(-956.63, -1.28726), LCoeff(1789.03, -1.92912)],
        "FCC_A1": [
            LCoeff(-12054.355, 3.27413),
            LCoeff(11082.1315, -4.45077),
            LCoeff(-725.805174, 0),
        ],
        "LIQUID": [
            LCoeff(-16911.395, 5.1622),
            LCoeff(10180.494, -4.146656),
            LCoeff(-4063.4, 0),
        ],
    },
    # Cr-Ni — Lee 1992 / SGTE
    "CR-NI": {
        "BCC_A2": [LCoeff(17170, -11.8199), LCoeff(34418, -11.8577)],
        "FCC_A1": [LCoeff(8030, -12.8801), LCoeff(33080, -16.0362)],
        "LIQUID": [LCoeff(318, -7.3318), LCoeff(16941, -6.3696)],
    },
}


def rk_for(elA: str, elB: str, phase: SgtePhase) -> list[LCoeff]:
    """Look up the RK coefficient list for a binary in a given phase."""

    key = "-".join(sorted([elA.upper(), elB.upper()]))
    return RK_PARAMETERS.get(key, {}).get(phase, [])


def excess_g(x: Mapping[str, float], phase: SgtePhase, T: float) -> float:
    """Multicomponent Redlich-Kister excess Gibbs energy (Muggianu)."""

    els = list(x.keys())
    g = 0.0
    for i in range(len(els)):
        for j in range(i + 1, len(els)):
            xi = x[els[i]]
            xj = x[els[j]]
            if xi <= 0 or xj <= 0:
                continue
            L = rk_for(els[i], els[j], phase)
            if not L:
                continue
            a_first = els[i].upper() < els[j].upper()
            xA = xi if a_first else xj
            xB = xj if a_first else xi
            s = 0.0
            for nu, lc in enumerate(L):
                s += lc.value(T) * (xA - xB) ** nu
            g += xi * xj * s
    return g


# ---------------------------------------------------------------------------
# Phase models
# ---------------------------------------------------------------------------


SOLUTION_PHASES: list[SgtePhase] = ["LIQUID", "FCC_A1", "BCC_A2", "HCP_A3"]
HCP_FORMING: set[str] = {"TI", "CO", "ZN", "ZR", "MG", "RU", "RE", "HF"}


def solution_g(x: Mapping[str, float], phase: SgtePhase, T: float) -> float:
    """Molar Gibbs energy of a substitutional solution phase, J/mol.

    G = Σ x_i·°G_i + R·T·Σ x_i·ln x_i + G_excess + G_magnetic
    """

    g = 0.0
    for el, xi in x.items():
        if xi <= 0:
            continue
        g += xi * pure_g(el, phase, T)
        if xi > 1e-12:
            g += R_GAS * T * xi * math.log(xi)
    g += excess_g(x, phase, T)
    mp = averaged_magnetic(x, phase)
    if mp is not None:
        g += magnetic_g(mp, T)
    return g


def sigma_g(x: Mapping[str, float], T: float) -> float:
    """Sigma phase Gibbs energy — narrow-composition-band model.

    Treated as a constrained solution phase (Cr-(Fe,Ni,Mo) topologically
    close-packed intermetallic). Window: Tpeak ≈ 908 K, dG_min ≈ -7.6
    kJ/mol, parabolic decay outside [713, 1103] K, with a parabolic
    Cr/(Fe+Cr+Mo) ≈ 0.5 composition penalty. Reproduces the Andersson-
    Sundman 1987 σ-loop. Returns 5e5 J/mol when σ is irrelevant (no
    Fe/Cr/Ni/Mo content).
    """

    xFe = x.get("FE", 0.0)
    xCr = x.get("CR", 0.0)
    xNi = x.get("NI", 0.0)
    xMo = x.get("MO", 0.0)
    known = xFe + xCr + xNi + xMo
    if known < 0.85:
        return 5.0e5
    g = (
        xFe * pure_g("FE", "BCC_A2", T)
        + xCr * pure_g("CR", "BCC_A2", T)
        + xNi * pure_g("NI", "FCC_A1", T)
        + xMo * pure_g("MO", "BCC_A2", T)
    )
    # damped configurational entropy — σ is an ordered phase
    s_conf = 0.0
    for xi in (xFe, xCr, xNi, xMo):
        if xi > 1e-9:
            s_conf += xi * math.log(xi)
    g += 0.35 * R_GAS * T * s_conf
    # T-windowed formation energy
    Tpeak = 908.0
    dG_min = -7600.0
    half_width = 195.0
    dG = dG_min * (1 - ((T - Tpeak) / half_width) ** 2)
    g += dG
    # composition band penalty (Cr/(Fe+Cr+Mo) ≈ 0.5)
    denom = max(xFe + xCr + xMo, 1e-9)
    cr_eff = (xCr + xMo) / denom
    g += 9.0e5 * (cr_eff - 0.5) ** 2
    g += 4.0e4 * xNi  # Ni destabilises σ
    return g


@dataclass
class PhaseModel:
    """A uniform phase descriptor: solution, compound, or sigma."""

    name: str
    kind: str  # 'solution' | 'compound' | 'sigma'
    g_fn: Callable[[Mapping[str, float], float], float]
    structure: SgtePhase | None = None
    fixed_composition: dict[str, float] | None = None
    requires: list[str] = field(default_factory=list)


def candidate_phases(system_elements: list[str]) -> list[PhaseModel]:
    """Phase list for the alloy: solution phases + σ (Cr-bearing only)."""

    present = {e.upper() for e in system_elements}
    has_hcp_former = any(e in HCP_FORMING for e in present)
    out: list[PhaseModel] = []
    for s in SOLUTION_PHASES:
        if s == "HCP_A3" and not has_hcp_former:
            continue
        # Skip phases that have no SGTE data for any present element
        # (avoid pure phases that are entirely the 5e5 penalty fallback)
        if not any(s in SGTE_DATA.get(el, {}) for el in present):
            continue
        out.append(
            PhaseModel(
                name=s,
                kind="solution",
                g_fn=lambda x, T, st=s: solution_g(x, st, T),
                structure=s,
            )
        )
    if "CR" in present and ("FE" in present or "NI" in present):
        out.append(
            PhaseModel(
                name="SIGMA",
                kind="sigma",
                g_fn=lambda x, T: sigma_g(x, T),
                requires=["CR"],
            )
        )
    return out


# ---------------------------------------------------------------------------
# Composition utilities
# ---------------------------------------------------------------------------


def wt_to_mole(wt_pct: Mapping[str, float]) -> dict[str, float]:
    """Convert a wt% composition to mole fractions (keys upper-cased)."""

    moles: dict[str, float] = {}
    total = 0.0
    for k, v in wt_pct.items():
        el = k.upper()
        if v <= 0:
            continue
        aw = ATOMIC_WEIGHT.get(el)
        if aw is None or aw <= 0:
            raise ValueError(f"unknown atomic weight for element '{el}'")
        moles[el] = v / aw
        total += moles[el]
    if total <= 0:
        return {}
    return {k: v / total for k, v in moles.items()}


def normalize_composition(comp: Mapping[str, float]) -> dict[str, float]:
    """Normalise an arbitrary mole / mole-fraction composition to sum 1."""

    upper = {k.upper(): max(0.0, float(v)) for k, v in comp.items()}
    total = sum(upper.values())
    if total <= 0:
        raise ValueError("composition sums to zero")
    return {k: v / total for k, v in upper.items()}


# ---------------------------------------------------------------------------
# Composition grid sampling
# ---------------------------------------------------------------------------


def _simplex_grid(n: int, div: int) -> np.ndarray:
    """Enumerate lattice points of the (n-1)-simplex with `div` subdivisions.

    Returns an array of shape (K, n) where Σ row = 1.
    """

    out: list[list[float]] = []

    def rec(idx: int, remaining: int, acc: list[int]) -> None:
        if idx == n - 1:
            out.append([(a / div) for a in acc] + [remaining / div])
            return
        for k in range(remaining + 1):
            rec(idx + 1, remaining - k, acc + [k])

    rec(0, div, [])
    return np.asarray(out, dtype=float)


# ---------------------------------------------------------------------------
# Lower convex hull search (combinatorial, bounded by prefilter)
# ---------------------------------------------------------------------------


def _barycentric(
    verts: np.ndarray, target: np.ndarray, mass_tol: float = 1e-6
) -> np.ndarray | None:
    """Barycentric coordinates of `target` w.r.t. simplex `verts`.

    `verts` is (n_pts, d); `target` is (d,). Returns weights of length
    n_pts (summing to 1) or None if degenerate / mass-balance fails.
    """

    np_pts = verts.shape[0]
    d = target.shape[0]
    if np_pts == 1:
        if np.max(np.abs(verts[0] - target)) <= mass_tol:
            return np.array([1.0])
        return None
    # Variables w_1..w_{np-1}; w_0 = 1 - Σ.
    A = (verts[1:] - verts[0]).T  # shape (d, np_pts-1)
    b = target - verts[0]
    if A.shape[0] == A.shape[1]:
        try:
            w_rest = np.linalg.solve(A, b)
        except np.linalg.LinAlgError:
            return None
    else:
        # least squares for over/under-determined
        w_rest, *_ = np.linalg.lstsq(A, b, rcond=None)
    w0 = 1.0 - np.sum(w_rest)
    w = np.concatenate(([w0], w_rest))
    # mass balance verification
    mix = w @ verts
    if np.max(np.abs(mix - target)) > mass_tol:
        return None
    return w


@dataclass
class GPoint:
    """One (composition, G) point in the global cloud."""

    c: np.ndarray  # length d = n-1 (independent components)
    g: float
    phase_idx: int
    is_compound: bool


def _prefilter(points: list[GPoint], d: int, target: np.ndarray) -> list[int]:
    """Cull the cloud to a tractable set of candidate hull vertices.

    Returns indices into `points`. Compounds always kept; for binaries we
    bucket by composition and keep lowest-G per cell.
    """

    kept: list[int] = []
    seen: set[int] = set()

    def add(i: int) -> None:
        if i not in seen:
            seen.add(i)
            kept.append(i)

    for i, p in enumerate(points):
        if p.is_compound:
            add(i)
    if d <= 1:
        # binary: bucket the 1-D axis, keep lowest-G per cell
        cells = 80
        cell_map: dict[int, tuple[float, int]] = {}
        for i, p in enumerate(points):
            if p.is_compound:
                continue
            cell = int(p.c[0] * cells)
            cur = cell_map.get(cell)
            if cur is None or p.g < cur[0]:
                cell_map[cell] = (p.g, i)
        for _, idx in cell_map.values():
            add(idx)
        return kept
    # multi: alloy-centred radius filter, per-phase top-K
    K_per_phase = 10 if d <= 2 else 7 if d <= 4 else 5
    by_phase: dict[int, list[int]] = {}
    for i, p in enumerate(points):
        if p.is_compound:
            continue
        dist2 = float(np.sum((p.c - target) ** 2))
        if dist2 > 0.32 * 0.32:
            continue
        by_phase.setdefault(p.phase_idx, []).append(i)
    for arr in by_phase.values():
        arr.sort(key=lambda i: points[i].g)
        for i in arr[:K_per_phase]:
            add(i)
    # extremes of each axis
    pool = list(seen)
    if pool:
        for axis in range(d):
            lo_v, hi_v = math.inf, -math.inf
            lo_i, hi_i = pool[0], pool[0]
            for i in pool:
                v = float(points[i].c[axis])
                if v < lo_v:
                    lo_v, lo_i = v, i
                if v > hi_v:
                    hi_v, hi_i = v, i
            add(lo_i)
            add(hi_i)
    return kept


def _lower_hull_assemblage(
    points: list[GPoint], target: np.ndarray, mass_tol: float
) -> dict | None:
    """Combinatorial lower-convex-hull search.

    Tests subsets of size 1..min(n,3) (4 if cloud is small) for the lowest
    G assemblage whose composition span contains the target.
    """

    d = target.shape[0]
    n = d + 1
    kept_idx = _prefilter(points, d, target)
    if not kept_idx:
        return None
    # Cache compositions and energies as arrays for vectorised operations.
    kept_pts = [points[i] for i in kept_idx]
    kept_c = np.stack([p.c for p in kept_pts]) if kept_pts else np.zeros((0, d))
    kept_g = np.array([p.g for p in kept_pts])

    best: dict | None = None
    DEGEN_W = 5e-3
    G_TIE = 2.0

    def try_combo(combo: tuple[int, ...]) -> None:
        nonlocal best
        verts = kept_c[list(combo)]
        w = _barycentric(verts, target, mass_tol)
        if w is None:
            return
        if (w < -mass_tol).any() or (w > 1 + mass_tol).any():
            return
        if (w < DEGEN_W).any():
            return
        g = float(np.sum(np.maximum(0, w) * kept_g[list(combo)]))
        nph = len(combo)
        better = (
            best is None
            or g < best["G"] - G_TIE
            or (g < best["G"] + G_TIE and nph < best["nph"])
        )
        if better:
            best = {
                "idx": [kept_idx[i] for i in combo],
                "weights": np.clip(w, 0, 1).tolist(),
                "G": g,
                "nph": nph,
            }

    N = len(kept_idx)
    for i in range(N):
        try_combo((i,))
    for i in range(N):
        for j in range(i + 1, N):
            try_combo((i, j))
    if n >= 3:
        for i in range(N):
            for j in range(i + 1, N):
                for k in range(j + 1, N):
                    try_combo((i, j, k))
    if n >= 4 and N <= 70:
        for i in range(N):
            for j in range(i + 1, N):
                for k in range(j + 1, N):
                    for m in range(k + 1, N):
                        try_combo((i, j, k, m))
    return best


# ---------------------------------------------------------------------------
# Local polish — scipy.optimize.minimize on the chemical-potential
# equality conditions (mass-balance constrained).
# ---------------------------------------------------------------------------


def _polish_assemblage(
    phases: list[PhaseModel],
    assembly: list[dict],
    overall: np.ndarray,
    element_order: list[str],
    T: float,
) -> dict:
    """Refine an assemblage by minimising total G via scipy SLSQP.

    Variables: each solution-phase composition (n entries per phase) plus
    the phase fractions (one per phase). Constraints: per-phase
    compositions sum to 1, overall fractions sum to 1, and overall mass
    balance Σ f_p·x_p = overall.

    The SLSQP / L-BFGS-B fallback path: if scipy is unavailable, the
    routine returns the input assembly unchanged.
    """

    n = len(element_order)
    P = len(assembly)
    if not _HAS_SCIPY or P == 0:
        g_total = sum(
            a["fraction"]
            * phases[a["phase_idx"]].g_fn(
                {element_order[i]: a["composition"][i] for i in range(n)}, T
            )
            for a in assembly
        )
        return {"ok": _HAS_SCIPY, "assembly": assembly, "G": g_total}

    # For a single-phase assemblage mass balance forces composition = bulk.
    if P == 1:
        comp = overall.tolist()
        g = phases[assembly[0]["phase_idx"]].g_fn(
            {element_order[i]: comp[i] for i in range(n)}, T
        )
        return {
            "ok": True,
            "assembly": [
                {
                    "phase_idx": assembly[0]["phase_idx"],
                    "composition": comp,
                    "fraction": 1.0,
                }
            ],
            "G": g,
        }

    # Compound phases have fixed composition — their composition vars are
    # held at the fixed values (not exposed to the optimiser).
    is_var_comp = []
    for a in assembly:
        ph = phases[a["phase_idx"]]
        is_var_comp.append(ph.kind != "compound")

    # Stack initial guess: [comp_1, ..., comp_P, fractions]
    n_var_phases = sum(is_var_comp)
    x0 = []
    for p_idx, a in enumerate(assembly):
        if is_var_comp[p_idx]:
            x0.extend(a["composition"])
    x0.extend([a["fraction"] for a in assembly])
    x0_arr = np.array(x0)

    def unpack(x: np.ndarray) -> tuple[list[list[float]], list[float]]:
        comps: list[list[float]] = []
        offset = 0
        for p_idx, a in enumerate(assembly):
            if is_var_comp[p_idx]:
                comps.append(x[offset : offset + n].tolist())
                offset += n
            else:
                ph = phases[a["phase_idx"]]
                fc = ph.fixed_composition or {}
                comps.append([fc.get(element_order[i], 0.0) for i in range(n)])
        fractions = x[offset:].tolist()
        return comps, fractions

    def total_g(x: np.ndarray) -> float:
        comps, fracs = unpack(x)
        g = 0.0
        for p_idx, (c, f) in enumerate(zip(comps, fracs)):
            ph = phases[assembly[p_idx]["phase_idx"]]
            xrec = {element_order[i]: max(c[i], 1e-12) for i in range(n)}
            g += f * ph.g_fn(xrec, T)
        return g

    # Constraints
    constraints = []
    # Each variable-composition phase sums to 1
    offset = 0
    for p_idx, a in enumerate(assembly):
        if is_var_comp[p_idx]:
            off = offset
            constraints.append(
                {
                    "type": "eq",
                    "fun": lambda x, o=off: float(np.sum(x[o : o + n]) - 1.0),
                }
            )
            offset += n
    # Fractions sum to 1
    frac_off = offset
    constraints.append(
        {"type": "eq", "fun": lambda x: float(np.sum(x[frac_off:]) - 1.0)}
    )
    # Mass balance (per element)
    for i in range(n):
        def mb(x: np.ndarray, i_el: int = i) -> float:
            comps, fracs = unpack(x)
            return float(
                sum(f * c[i_el] for c, f in zip(comps, fracs)) - overall[i_el]
            )

        constraints.append({"type": "eq", "fun": mb})

    # Bounds: compositions in [0, 1], fractions in [0, 1]
    bounds = []
    for p_idx, a in enumerate(assembly):
        if is_var_comp[p_idx]:
            bounds.extend([(0.0, 1.0)] * n)
    bounds.extend([(0.0, 1.0)] * P)

    try:
        res = minimize(  # type: ignore[misc]
            total_g,
            x0_arr,
            method="SLSQP",
            bounds=bounds,
            constraints=constraints,
            options={"maxiter": 80, "ftol": 1e-7, "disp": False},
        )
    except Exception:  # pragma: no cover - scipy convergence fallback
        return {"ok": False, "assembly": assembly, "G": total_g(x0_arr)}

    if not res.success and not getattr(res, "x", None) is not None:
        return {"ok": False, "assembly": assembly, "G": total_g(x0_arr)}

    comps, fracs = unpack(res.x)
    out_asm = []
    for p_idx, (c, f) in enumerate(zip(comps, fracs)):
        if f < 1e-3:
            continue
        cn = np.maximum(c, 0)
        s = np.sum(cn)
        cn = (cn / s).tolist() if s > 0 else c
        out_asm.append(
            {
                "phase_idx": assembly[p_idx]["phase_idx"],
                "composition": cn,
                "fraction": float(f),
            }
        )
    if not out_asm:
        out_asm = assembly
    # renormalise fractions
    fs = sum(a["fraction"] for a in out_asm)
    if fs > 0:
        for a in out_asm:
            a["fraction"] /= fs
    return {"ok": bool(res.success), "assembly": out_asm, "G": float(res.fun)}


# ---------------------------------------------------------------------------
# Activities (per element)
# ---------------------------------------------------------------------------


def _activities(
    assembly: list[dict],
    phases: list[PhaseModel],
    element_order: list[str],
    T: float,
) -> dict[str, float]:
    """Per-element activity a_i = exp((μ_i - °G_i) / RT).

    At equilibrium every coexisting phase shares the same μ_i; we use the
    dominant phase as the canonical reference. μ_i is computed by finite
    difference in the dominant solution phase: μ_i = G + (1 - x_i)·dG/dx_i
    in the substitutional approximation.
    """

    if not assembly:
        return {}
    # Dominant phase is the one with the largest fraction
    dom = max(assembly, key=lambda a: a["fraction"])
    ph = phases[dom["phase_idx"]]
    n = len(element_order)
    c = np.asarray(dom["composition"])
    if ph.kind != "solution":
        # For a single compound dominant phase, activities of elements are
        # ill-defined; report mole-fraction proxies (xi → activity ~ xi).
        return {element_order[i]: float(c[i]) for i in range(n)}
    base_rec = {element_order[i]: max(c[i], 1e-12) for i in range(n)}
    g0 = ph.g_fn(base_rec, T)
    eps = 1e-5
    activities: dict[str, float] = {}
    for i in range(n):
        # Move ε onto element i, take ε off the largest other component.
        c_pert = c.copy()
        j = int(np.argmax([c[k] if k != i else -1 for k in range(n)]))
        c_pert[i] += eps
        c_pert[j] -= eps
        if c_pert[i] <= 0 or c_pert[j] <= 0:
            activities[element_order[i]] = 0.0
            continue
        rec = {element_order[k]: float(c_pert[k]) for k in range(n)}
        g1 = ph.g_fn(rec, T)
        dg = (g1 - g0) / eps
        mu = g0 + (1 - c[i]) * dg  # μ_i = G + (1 - x_i) · ∂G/∂x_i (binary form)
        g_ref = pure_g(element_order[i], ph.structure or "FCC_A1", T)
        # a_i = exp((μ_i - G_ref) / RT)
        z = (mu - g_ref) / (R_GAS * T)
        try:
            activities[element_order[i]] = math.exp(z) if z < 60 else math.inf
        except (OverflowError, ValueError):
            activities[element_order[i]] = math.inf
    return activities


# ---------------------------------------------------------------------------
# Public entry point — native equilibrium
# ---------------------------------------------------------------------------


@dataclass
class NativePhase:
    """One stable phase in a native-equilibrium result."""

    phase: str
    fraction: float
    composition: dict[str, float]


@dataclass
class NativeEquilibriumResult:
    """Result of a native CALPHAD equilibrium solve."""

    T_K: float
    phases: list[NativePhase]
    G: float
    activities: dict[str, float]
    method: str  # 'native-binary' | 'native-multicomponent'
    grid_points: int
    polished: bool


def equilibrium_native(
    composition: Mapping[str, float],
    T_K: float,
    *,
    composition_basis: str = "mole",
    polish: bool = True,
    binary_div: int = 200,
    ternary_div: int = 30,
) -> NativeEquilibriumResult:
    """Compute the equilibrium phase assemblage in pure Python.

    Parameters
    ----------
    composition : mapping
        Element symbol → composition. Interpreted as mole fractions when
        ``composition_basis == "mole"`` (default), or weight percent when
        ``composition_basis == "wt"``. Keys are case-insensitive.
    T_K : float
        Temperature in kelvin.
    composition_basis : str
        ``"mole"`` (default) or ``"wt"``.
    polish : bool
        Run the scipy local-polish step (default True). When scipy is not
        importable this is silently skipped.
    binary_div, ternary_div : int
        Simplex-grid subdivisions per edge for binary / ternary systems.

    Returns
    -------
    NativeEquilibriumResult
        Phase list (largest fraction first), molar Gibbs energy, per-
        element activities, and diagnostic metadata.
    """

    if composition_basis == "wt":
        comp_mole = wt_to_mole(composition)
    else:
        comp_mole = normalize_composition(composition)
    if not comp_mole:
        raise ValueError("composition is empty after normalisation")

    element_order = list(comp_mole.keys())
    overall = np.array([comp_mole[el] for el in element_order])
    n = len(element_order)

    # Drop elements without ANY phase data — keeps the engine well-posed.
    known = [el for el in element_order if el in SGTE_DATA]
    if len(known) != n:
        dropped = [el for el in element_order if el not in SGTE_DATA]
        # rebalance dropped mass into the matrix (first known)
        if not known:
            raise ValueError(f"no known elements in {element_order}")
        ratio = sum(comp_mole[el] for el in known)
        comp_mole = {el: comp_mole[el] / ratio for el in known}
        element_order = known
        overall = np.array([comp_mole[el] for el in element_order])
        n = len(element_order)
        _ = dropped  # silenced — engine still solves the reduced system

    phases = candidate_phases(element_order)
    if not phases:
        raise ValueError(f"no candidate phases for elements {element_order}")

    # Single-element trivial case
    if n == 1:
        el = element_order[0]
        best_name, best_g = phases[0].name, math.inf
        for ph in phases:
            if ph.kind != "solution":
                continue
            g = ph.g_fn({el: 1.0}, T_K)
            if g < best_g:
                best_g = g
                best_name = ph.name
        return NativeEquilibriumResult(
            T_K=T_K,
            phases=[NativePhase(best_name, 1.0, {el: 1.0})],
            G=best_g,
            activities={el: 1.0},
            method="native-binary",
            grid_points=len(phases),
            polished=True,
        )

    # Grid sampling
    div = binary_div if n == 2 else ternary_div if n == 3 else max(8, ternary_div // 3)
    d = n - 1
    points: list[GPoint] = []
    for pi, ph in enumerate(phases):
        if ph.kind == "compound":
            cfull = np.array([
                (ph.fixed_composition or {}).get(el, 0.0) for el in element_order
            ])
            s = cfull.sum()
            if s <= 0:
                continue
            cfull = cfull / s
            g = ph.g_fn({}, T_K)
            points.append(
                GPoint(cfull[:-1].copy(), g, pi, True)
            )
            continue
        grid = _simplex_grid(n, div)
        # Seed: alloy point itself (so single-phase always exactly representable)
        grid = np.vstack([grid, overall.reshape(1, -1)])
        for row in grid:
            c = np.maximum(row, 1e-9)
            c = c / c.sum()
            rec = {element_order[i]: float(c[i]) for i in range(n)}
            g = ph.g_fn(rec, T_K)
            if math.isfinite(g) and g < 5e5:
                points.append(GPoint(c[:-1].copy(), g, pi, False))

    if not points:
        raise RuntimeError("no valid grid points sampled — phase data missing")

    target = overall[:-1].copy()
    mass_tol = (
        max(2.5e-3, min(0.04, 0.7 / div)) if n == 2 else min(0.04, max(0.012, 1.1 / div))
    )
    hull = _lower_hull_assemblage(points, target, mass_tol)

    if hull is None:
        # Fallback: best single solution phase
        best_pi, best_g = 0, math.inf
        rec = {element_order[i]: float(overall[i]) for i in range(n)}
        for pi, ph in enumerate(phases):
            if ph.kind == "compound":
                continue
            g = ph.g_fn(rec, T_K)
            if g < best_g:
                best_g = g
                best_pi = pi
        assembly = [
            {"phase_idx": best_pi, "composition": overall.tolist(), "fraction": 1.0}
        ]
        polished = False
        final_g = best_g
    else:
        raw_assembly = []
        for src_idx, w in zip(hull["idx"], hull["weights"]):
            pt = points[src_idx]
            full = np.concatenate([pt.c, [1.0 - pt.c.sum()]])
            raw_assembly.append(
                {
                    "phase_idx": pt.phase_idx,
                    "composition": full.tolist(),
                    "fraction": float(w),
                }
            )
        # Merge same-phase duplicates (e.g. miscibility gap grid hits)
        merged: dict[int, dict] = {}
        for a in raw_assembly:
            p_idx = a["phase_idx"]
            if p_idx in merged:
                cur = merged[p_idx]
                fnew = cur["fraction"] + a["fraction"]
                comp_acc = (
                    np.array(cur["composition"]) * cur["fraction"]
                    + np.array(a["composition"]) * a["fraction"]
                ) / max(fnew, 1e-12)
                cur["composition"] = comp_acc.tolist()
                cur["fraction"] = fnew
            else:
                merged[p_idx] = dict(a)
        assembly = list(merged.values())
        # drop negligible phases
        assembly = [a for a in assembly if a["fraction"] > 1e-3]
        fs = sum(a["fraction"] for a in assembly)
        if fs > 0:
            for a in assembly:
                a["fraction"] /= fs
        final_g = float(hull["G"])
        polished = False

    if polish and _HAS_SCIPY:
        pol = _polish_assemblage(phases, assembly, overall, element_order, T_K)
        if pol["ok"] and pol["G"] <= final_g + 5:
            assembly = pol["assembly"]
            final_g = pol["G"]
            polished = True
        # Always also try single-phase candidates explicitly — guards against
        # spurious multi-phase facets from grid quantisation.
        for pi, ph in enumerate(phases):
            if ph.kind != "solution":
                continue
            cand = [
                {"phase_idx": pi, "composition": overall.tolist(), "fraction": 1.0}
            ]
            cand_pol = _polish_assemblage(phases, cand, overall, element_order, T_K)
            if cand_pol["ok"] and cand_pol["G"] < final_g - 2:
                assembly = cand_pol["assembly"]
                final_g = cand_pol["G"]
                polished = True

    out_phases: list[NativePhase] = []
    for a in assembly:
        comp = {
            element_order[i]: max(0.0, float(a["composition"][i])) for i in range(n)
        }
        cs = sum(comp.values()) or 1.0
        comp = {k: v / cs for k, v in comp.items()}
        out_phases.append(
            NativePhase(
                phase=phases[a["phase_idx"]].name,
                fraction=float(a["fraction"]),
                composition=comp,
            )
        )
    out_phases.sort(key=lambda p: -p.fraction)

    acts = _activities(assembly, phases, element_order, T_K)

    return NativeEquilibriumResult(
        T_K=T_K,
        phases=out_phases,
        G=final_g,
        activities=acts,
        method="native-binary" if n == 2 else "native-multicomponent",
        grid_points=len(points),
        polished=polished,
    )


__all__ = [
    "R_GAS",
    "SgteInterval",
    "SGTE_DATA",
    "SGTE_ELEMENTS",
    "ATOMIC_WEIGHT",
    "pure_g",
    "MagneticParams",
    "MAGNETIC_DATA",
    "magnetic_g",
    "averaged_magnetic",
    "LCoeff",
    "RK_PARAMETERS",
    "rk_for",
    "excess_g",
    "PhaseModel",
    "SOLUTION_PHASES",
    "candidate_phases",
    "solution_g",
    "sigma_g",
    "wt_to_mole",
    "normalize_composition",
    "NativePhase",
    "NativeEquilibriumResult",
    "equilibrium_native",
]
