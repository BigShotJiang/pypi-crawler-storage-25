"""Bundled spec-edition diff corpus.

JSON files in this directory hold hand-curated edition-delta entries for
major materials / FFS / RBI specs:

  * ``api_579_1.json``    — API 579-1/ASME FFS-1 (2021-12, 2022-06, 2024-09)
  * ``api_581.json``      — API 581 RBI (2008, 2016, 2020)
  * ``asme_ii_d.json``    — ASME BPVC II-D (2021, 2023, 2025)
  * ``nace_mr0175.json``  — NACE MR0175 / ISO 15156 (2009, 2015, 2021, 2023)
  * ``astm_a29.json``     — ASTM A29 (2020a, 2022, 2024)

Each file follows the schema::

    {
      "spec":      str,
      "title":     str,
      "publisher": str,
      "editions": [
        {
          "id":        str,           # e.g. "2024-09"
          "published": str,           # ISO date
          "label":     str,
          "changes": [
            {
              "section":        str,
              "kind":           "formula" | "parameter" | "method" |
                                "scope" | "editorial",
              "summary":        str,
              "primary_paper":  str   # optional
            }
          ]
        }
      ]
    }

Add new specs via PR; the loader is corpus-driven, no code change needed.
"""
