"""Tribology — wear, friction, lubrication models.

Used in every gear, bearing, slider, seal, brake, and clutch design.
Open-source materials libraries don't ship these, so engineers run them
in Excel or write ad-hoc scripts. This module gives them the canonical
models with cited material constants.

* **Archard 1953 adhesive wear**: ``V = k · L · s / H``.
* **Plastic plowing** (Lim-Ashby 1987): asperity-based abrasive wear.
* **Coulomb static + kinetic friction** with material pair table.
* **Stribeck 1902 curve**: ``μ(λ)`` lubrication regime map (boundary /
  mixed / EHL / HL).
* **Hamrock-Dowson 1981 EHL film thickness** for point contact.
* **Hertzian contact stress** (line + point contact).
* **PV limit** (pressure-velocity envelope) for polymer bearings.
* **Holm 1958 contact-resistance** for electrical contacts (not strictly
  tribology but adjacent — used in connector design).

References:
    * Archard J.F., J. Appl. Phys. 24 (1953) 981.
    * Lim S.C., Ashby M.F., Acta Metall. 35 (1987) 1.
    * Greenwood J.A., Williamson J.B.P., Proc. R. Soc. London A 295
      (1966) 300.
    * Stribeck R., Z. VDI 46 (1902) 1341.
    * Hamrock B.J., Dowson D., "Ball Bearing Lubrication," Wiley (1981).
    * Hertz H., J. Reine Angew. Math. 92 (1882) 156.
    * Holm R., "Electric Contacts," Springer (1958).
    * Rabinowicz E., "Friction and Wear of Materials" 2nd ed., Wiley (1995).
    * Bhushan B., "Modern Tribology Handbook" Vols I-II, CRC (2001).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Literal


# ---------------------------------------------------------------------------
# 1. ARCHARD WEAR LAW
# ---------------------------------------------------------------------------


def archard_wear_volume(
    normal_load_N: float,
    sliding_distance_m: float,
    hardness_HV: float,
    wear_coefficient_k: float,
) -> float:
    """Archard 1953 adhesive wear volume:

    ``V = k · L · s / H``

    Parameters
    ----------
    normal_load_N: applied normal load.
    sliding_distance_m: total sliding distance.
    hardness_HV: Vickers hardness of the softer surface (HV).
    wear_coefficient_k: dimensionless k (typical: 1e-7 for steel-on-steel
        lubricated; 1e-4 for steel-on-steel dry; 1e-2 for severe galling).

    Returns
    -------
    Worn volume in mm³.

    Reference: Archard J.F., J. Appl. Phys. 24 (1953) 981.
    """
    if not all(_is_finite(x) for x in [normal_load_N, sliding_distance_m, hardness_HV, wear_coefficient_k]):
        return float("nan")
    if hardness_HV <= 0:
        return float("nan")
    # HV in MPa, convert to N/mm² (1 HV ≈ 9.81 N/mm²)
    H_MPa = float(hardness_HV) * 9.81
    H_N_per_mm2 = H_MPa
    V_mm3 = (float(wear_coefficient_k) * float(normal_load_N)
             * float(sliding_distance_m) * 1000.0) / H_N_per_mm2
    return max(0.0, V_mm3)


def archard_wear_depth(
    contact_area_mm2: float, **kwargs
) -> float:
    """Convenience: convert Archard volume to mean wear depth."""
    V = archard_wear_volume(**kwargs)
    if not _is_finite(V) or contact_area_mm2 <= 0:
        return float("nan")
    return V / float(contact_area_mm2)


# Typical Archard k coefficients per material pair (Rabinowicz 1995 Table 6.3)
ARCHARD_K_TABLE: dict[str, dict] = {
    "steel-on-steel-dry":            {"k": 1.5e-4, "note": "mild adhesive wear"},
    "steel-on-steel-lubricated":     {"k": 1.0e-7, "note": "EHL hydrodynamic lubrication"},
    "steel-on-bronze-dry":           {"k": 1.0e-4, "note": "Cu-Sn bushings"},
    "steel-on-bronze-lubricated":    {"k": 1.0e-8, "note": "marine prop bearings"},
    "steel-on-PTFE-dry":             {"k": 4.0e-5, "note": "polymer sliding"},
    "steel-on-cast-iron-dry":        {"k": 1.0e-4, "note": "engine cylinder/piston"},
    "steel-on-nylon-dry":            {"k": 2.0e-4, "note": "general-purpose plastic"},
    "ceramic-on-ceramic-dry":        {"k": 1.0e-5, "note": "alumina-on-alumina seals"},
    "WC-on-steel":                   {"k": 3.0e-6, "note": "cemented-carbide tools"},
    "diamond-on-steel":              {"k": 1.0e-7, "note": "PCD cutting tools"},
    "severe-galling":                {"k": 5.0e-2, "note": "scuffing / seizure"},
}


# ---------------------------------------------------------------------------
# 2. LIM-ASHBY ABRASIVE / PLOWING WEAR
# ---------------------------------------------------------------------------


def lim_ashby_plowing_wear(
    normal_load_N: float,
    sliding_distance_m: float,
    *,
    hardness_HV: float,
    asperity_angle_deg: float = 30.0,
) -> float:
    """Lim-Ashby 1987 plastic-plowing wear volume.

    Single-asperity model:  ``V = (2/π) · tan(θ) · L · s / H``

    Parameters
    ----------
    normal_load_N, sliding_distance_m, hardness_HV: same as Archard.
    asperity_angle_deg: average asperity attack angle (typically 15-45°).

    Reference: Lim S.C., Ashby M.F., Acta Metall. 35 (1987) 1.
    """
    if not all(_is_finite(x) for x in [normal_load_N, sliding_distance_m, hardness_HV, asperity_angle_deg]):
        return float("nan")
    if hardness_HV <= 0:
        return float("nan")
    H_N_per_mm2 = float(hardness_HV) * 9.81
    tan_theta = math.tan(math.radians(float(asperity_angle_deg)))
    return max(0.0, (2.0 / math.pi) * tan_theta * float(normal_load_N)
               * float(sliding_distance_m) * 1000.0 / H_N_per_mm2)


# ---------------------------------------------------------------------------
# 3. COULOMB FRICTION COEFFICIENTS
# ---------------------------------------------------------------------------


# Static + kinetic friction coefficient table (Rabinowicz 1995 Table 4.1;
# Bhushan 2001 Vol I §4)
FRICTION_COEFFICIENTS: dict[str, dict] = {
    "steel-on-steel-dry":         {"mu_s": 0.74, "mu_k": 0.57},
    "steel-on-steel-grease":      {"mu_s": 0.16, "mu_k": 0.06},
    "steel-on-bronze-dry":        {"mu_s": 0.50, "mu_k": 0.34},
    "steel-on-bronze-oiled":      {"mu_s": 0.18, "mu_k": 0.07},
    "steel-on-aluminum-dry":      {"mu_s": 0.61, "mu_k": 0.47},
    "steel-on-cast-iron-dry":     {"mu_s": 0.40, "mu_k": 0.23},
    "steel-on-graphite-dry":      {"mu_s": 0.10, "mu_k": 0.10},
    "steel-on-PTFE-dry":          {"mu_s": 0.04, "mu_k": 0.04},
    "steel-on-nylon-dry":         {"mu_s": 0.35, "mu_k": 0.30},
    "rubber-on-concrete-dry":     {"mu_s": 1.00, "mu_k": 0.80},
    "rubber-on-concrete-wet":     {"mu_s": 0.60, "mu_k": 0.50},
    "ice-on-steel":               {"mu_s": 0.10, "mu_k": 0.05},
    "WC-on-WC":                   {"mu_s": 0.20, "mu_k": 0.15},
    "alumina-on-alumina-dry":     {"mu_s": 0.40, "mu_k": 0.30},
    "alumina-on-alumina-water":   {"mu_s": 0.30, "mu_k": 0.20},
}


def friction_coefficient(pair: str, *, kinetic: bool = True) -> float:
    """Look up Coulomb friction coefficient for a material pair.

    Pass the pair key (see ``FRICTION_COEFFICIENTS`` for available pairs).
    ``kinetic=True`` returns μ_k; ``kinetic=False`` returns μ_s (static).
    """
    entry = FRICTION_COEFFICIENTS.get(pair)
    if entry is None:
        return float("nan")
    return float(entry["mu_k"] if kinetic else entry["mu_s"])


# ---------------------------------------------------------------------------
# 4. STRIBECK CURVE — lubrication regime
# ---------------------------------------------------------------------------


def stribeck_curve(
    eta_viscosity_Pa_s: float,
    speed_m_s: float,
    pressure_MPa: float,
    *,
    h_min_um: float | None = None,
    Ra_um: float = 0.5,
) -> dict:
    """Stribeck 1902 lubrication-regime classifier.

    Stribeck number ``ζ = η · v / p``. Regime depends on ratio of EHL film
    thickness to surface roughness λ = h_min / Ra.

    Parameters
    ----------
    eta_viscosity_Pa_s: oil dynamic viscosity at operating T.
    speed_m_s: relative sliding velocity.
    pressure_MPa: nominal contact pressure.
    h_min_um: minimum EHL film thickness (optional; if not given, uses
        Stribeck number alone).
    Ra_um: combined surface roughness ``Ra = sqrt(Ra_1² + Ra_2²)``.

    Returns
    -------
    {
        "regime": "boundary" | "mixed" | "EHL" | "HL",
        "stribeck_number": η·v/p (Pa·s · m/s / Pa = m),
        "lambda": h_min / Ra (if both given),
        "mu_estimate": float,
    }

    Reference: Stribeck R., Z. VDI 46 (1902) 1341; Hamrock-Dowson 1981.
    """
    if not all(_is_finite(x) for x in [eta_viscosity_Pa_s, speed_m_s, pressure_MPa]):
        return {"regime": "indeterminate", "stribeck_number": float("nan"),
                "lambda": float("nan"), "mu_estimate": float("nan")}

    p_Pa = float(pressure_MPa) * 1e6
    if p_Pa <= 0:
        return {"regime": "indeterminate", "stribeck_number": float("inf"),
                "lambda": float("inf"), "mu_estimate": 0.01}

    stribeck = float(eta_viscosity_Pa_s) * float(speed_m_s) / p_Pa  # meters

    lambda_ratio = float("nan")
    regime = "boundary"
    mu = 0.10  # boundary lubrication μ default

    if h_min_um is not None and _is_finite(h_min_um) and Ra_um > 0:
        lambda_ratio = float(h_min_um) / float(Ra_um)
        if lambda_ratio < 1:
            regime = "boundary"
            mu = 0.10
        elif lambda_ratio < 3:
            regime = "mixed"
            mu = 0.05
        elif lambda_ratio < 10:
            regime = "EHL"
            mu = 0.01
        else:
            regime = "HL"   # full hydrodynamic
            mu = 0.005
    else:
        # Use only Stribeck number with rough thresholds (Bhushan 2001)
        if stribeck < 1e-9:
            regime = "boundary"
            mu = 0.10
        elif stribeck < 1e-7:
            regime = "mixed"
            mu = 0.05
        else:
            regime = "HL"
            mu = 0.005

    return {
        "regime": regime,
        "stribeck_number": stribeck,
        "lambda": lambda_ratio,
        "mu_estimate": mu,
    }


# ---------------------------------------------------------------------------
# 5. HAMROCK-DOWSON EHL FILM THICKNESS
# ---------------------------------------------------------------------------


def hamrock_dowson_film_thickness_point(
    eta_0_Pa_s: float,
    speed_m_s: float,
    E_prime_Pa: float,
    R_prime_m: float,
    W_N: float,
    alpha_pressure_per_Pa: float = 2.0e-8,
    ellipticity_k: float = 1.0,
) -> float:
    """Hamrock-Dowson 1981 minimum elastohydrodynamic film thickness for
    point contact (ball-on-flat, gears, rolling bearings).

    Dimensionless form:

        H_min = 3.63 · U^0.68 · G^0.49 · W^(−0.073) · (1 − exp(−0.68·k))

    where:
        U = η_0 · v / (E' · R')        speed parameter
        G = α · E'                      material parameter
        W = w / (E' · R'²)             load parameter

    Returns minimum film thickness in meters.

    Reference: Hamrock B.J., Dowson D., "Ball Bearing Lubrication," Wiley (1981).
    """
    if not all(_is_finite(x) for x in [eta_0_Pa_s, speed_m_s, E_prime_Pa, R_prime_m, W_N,
                                       alpha_pressure_per_Pa, ellipticity_k]):
        return float("nan")
    if R_prime_m <= 0 or E_prime_Pa <= 0:
        return float("nan")
    U = float(eta_0_Pa_s) * float(speed_m_s) / (float(E_prime_Pa) * float(R_prime_m))
    G = float(alpha_pressure_per_Pa) * float(E_prime_Pa)
    W = float(W_N) / (float(E_prime_Pa) * (float(R_prime_m) ** 2))
    if U <= 0 or G <= 0 or W <= 0:
        return 0.0
    H_min = 3.63 * (U ** 0.68) * (G ** 0.49) * (W ** -0.073) * (1.0 - math.exp(-0.68 * float(ellipticity_k)))
    h_min_m = H_min * float(R_prime_m)
    return max(0.0, h_min_m)


# ---------------------------------------------------------------------------
# 6. HERTZIAN CONTACT STRESS
# ---------------------------------------------------------------------------


def hertz_point_contact_max_pressure(
    F_N: float, R1_m: float, R2_m: float,
    E1_GPa: float, nu1: float, E2_GPa: float, nu2: float,
) -> dict:
    """Hertz 1882 contact stress for two spheres / sphere-on-flat (R2=∞).

    Returns:
    * ``p_max_MPa`` — peak contact pressure.
    * ``a_mm`` — contact-circle radius.
    * ``E_prime_GPa`` — reduced Young's modulus E' = ((1-ν₁²)/E₁ + (1-ν₂²)/E₂)⁻¹.

    R2_m may be ``float('inf')`` for sphere-on-flat geometry.

    Reference: Hertz H., J. Reine Angew. Math. 92 (1882) 156.
    """
    # Note: R2_m = inf is allowed (sphere-on-flat); the rest must be finite.
    if not all(_is_finite(x) for x in [F_N, R1_m, E1_GPa, nu1, E2_GPa, nu2]):
        return {"p_max_MPa": float("nan"), "a_mm": float("nan"), "E_prime_GPa": float("nan")}
    if R1_m <= 0 or R2_m == 0 or E1_GPa <= 0 or E2_GPa <= 0:
        return {"p_max_MPa": float("nan"), "a_mm": float("nan"), "E_prime_GPa": float("nan")}

    R_inv = 1.0 / R1_m + (1.0 / R2_m if (math.isfinite(R2_m) and R2_m != 0) else 0.0)
    R_prime = 1.0 / R_inv if R_inv > 0 else float("inf")
    E1 = E1_GPa * 1e9
    E2 = E2_GPa * 1e9
    E_prime = 1.0 / ((1 - nu1 ** 2) / E1 + (1 - nu2 ** 2) / E2)
    a = (3.0 * F_N * R_prime / (4.0 * E_prime)) ** (1.0 / 3.0)
    p_max = (3.0 * F_N) / (2.0 * math.pi * a ** 2)
    return {
        "p_max_MPa": p_max / 1e6,
        "a_mm": a * 1000.0,
        "E_prime_GPa": E_prime / 1e9,
    }


def hertz_line_contact_max_pressure(
    F_per_length_N_per_m: float, R_m: float,
    E1_GPa: float, nu1: float, E2_GPa: float, nu2: float,
) -> dict:
    """Hertz line contact (cylinder-on-flat, two parallel cylinders, gear
    teeth, roller bearings).

    Returns ``p_max_MPa``, ``b_mm`` (half-contact-width), and ``E_prime_GPa``.
    """
    if not all(_is_finite(x) for x in [F_per_length_N_per_m, R_m, E1_GPa, nu1, E2_GPa, nu2]):
        return {"p_max_MPa": float("nan"), "b_mm": float("nan"), "E_prime_GPa": float("nan")}
    if R_m <= 0:
        return {"p_max_MPa": float("nan"), "b_mm": float("nan"), "E_prime_GPa": float("nan")}
    E1 = E1_GPa * 1e9
    E2 = E2_GPa * 1e9
    E_prime = 1.0 / ((1 - nu1 ** 2) / E1 + (1 - nu2 ** 2) / E2)
    b = math.sqrt(4.0 * F_per_length_N_per_m * R_m / (math.pi * E_prime))
    p_max = math.sqrt(F_per_length_N_per_m * E_prime / (math.pi * R_m))
    return {
        "p_max_MPa": p_max / 1e6,
        "b_mm": b * 1000.0,
        "E_prime_GPa": E_prime / 1e9,
    }


# ---------------------------------------------------------------------------
# 7. PV LIMIT for polymer bearings
# ---------------------------------------------------------------------------


# PV limit table (Ashby-Bhushan): pressure × velocity ≤ limit (MPa·m/s)
PV_LIMITS: dict[str, float] = {
    "PTFE":      0.06,
    "PTFE-filled": 0.5,
    "nylon":     0.10,
    "POM":       0.10,
    "PEEK":      1.0,
    "polyimide": 4.0,
    "phenolic-fabric": 1.5,
    "graphite-bronze": 4.5,
    "rulon":     0.6,
}


def pv_limit_check(
    pressure_MPa: float, velocity_m_s: float, polymer: str,
) -> dict:
    """Polymer-bearing PV-limit envelope check.

    Returns {"passed": bool, "PV": p·v, "limit": PV_limit, "safety_factor": ...}.
    """
    if not all(_is_finite(x) for x in [pressure_MPa, velocity_m_s]):
        return {"passed": False, "PV": float("nan"), "limit": float("nan"),
                "safety_factor": float("nan"), "error": "non-finite input"}
    # Try exact match first, then case-insensitive
    limit = PV_LIMITS.get(polymer)
    if limit is None:
        for k, v in PV_LIMITS.items():
            if k.lower() == polymer.lower():
                limit = v
                break
    if limit is None:
        return {"passed": False, "PV": float("nan"), "limit": float("nan"),
                "error": f"unknown polymer '{polymer}'; available: {list(PV_LIMITS)}"}
    pv = float(pressure_MPa) * float(velocity_m_s)
    sf = limit / pv if pv > 0 else float("inf")
    return {
        "passed": pv <= limit,
        "PV": pv,
        "limit_MPa_m_s": limit,
        "safety_factor": sf,
        "polymer": polymer,
    }


def _is_finite(x) -> bool:
    try:
        return math.isfinite(float(x))
    except (TypeError, ValueError):
        return False


__all__ = [
    "archard_wear_volume",
    "archard_wear_depth",
    "ARCHARD_K_TABLE",
    "lim_ashby_plowing_wear",
    "FRICTION_COEFFICIENTS",
    "friction_coefficient",
    "stribeck_curve",
    "hamrock_dowson_film_thickness_point",
    "hertz_point_contact_max_pressure",
    "hertz_line_contact_max_pressure",
    "PV_LIMITS",
    "pv_limit_check",
]
