"""Diagnostics — "Why is X happening?"

Inspired verbatim by a pycalphad user (issue #390):

    "I still can't understand phase missing in 500K while no phase missing
     in 450K and 550K."

Commercial CALPHAD packages return a result but never an *explanation*.
Austenite's diagnostics layer takes a result that a user finds surprising
and walks them through the physics — neighborhood scan, missing-phase
attribution, MCMC chain diagnosis, AM-failure root-cause.

Three public diagnoses today (more will follow as feedback comes in):

  * :func:`explain_equilibrium` — why is phase X missing / present at T?
  * :func:`explain_mcmc_convergence` — why is R-hat > 1.1?
  * :func:`explain_am_failure` — why did the AM print fail F3055 / F2924?

Every diagnosis returns a dataclass with three fields:

  * ``reasons``         — bullet list of physical / statistical reasons.
  * ``suggestions``     — concrete actions the user can take next.
  * extra context — depends on the type of diagnosis (``neighborhood_scan``,
    ``per_param`` chain diagnostics, ``root_cause`` for AM).

All three gracefully fall back to a "not enough info" diagnosis with
useful hints when the engine itself isn't reachable (NetworkError /
NotImplementedError).

References:
  * Andersson J.-O., CALPHAD 9 (1985) 187 — Fe-Cr SIGMA solubility surface.
  * Sundman B. & Ågren J., J.Phys.Chem.Sol. 42 (1981) 297 — CEF mixing.
  * Brooks S.P. & Gelman A., J.Comput.Graph.Stat. 7 (1998) 434 — R-hat.
  * Gelman A. et al., Bayesian Data Analysis 3rd ed. §11.4 — chain mixing.
  * Promoppatum P. et al., Engineering 3 (2017) 685 — LPBF melt-pool regimes.
  * King W.E. et al., J.Mater.Process.Tech. 214 (2014) 2915 — keyhole criterion.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping, Optional, Sequence


__all__ = [
    "EquilibriumDiagnosis",
    "MCMCDiagnosis",
    "AMFailureDiagnosis",
    "explain_equilibrium",
    "explain_mcmc_convergence",
    "explain_am_failure",
]


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class EquilibriumDiagnosis:
    """Diagnosis of a surprising CALPHAD-equilibrium result.

    Attributes:
        missing: Phases that the engine expected but did not return.
        unexpected: Phases that *were* returned but are not in the
            user's expected list.
        reasons: Plain-English bullets, each pinned to a citation.
        suggestions: Concrete next steps (e.g. ``"Try T=900..1200 K"``).
        neighborhood_scan: ``{"T-50": [...phases...], "T+50": [...]}`` —
            what the same composition produces at T±50 K and T±100 K.
        citations: Primary references that ground the reasoning.
    """

    missing: list[str] = field(default_factory=list)
    unexpected: list[str] = field(default_factory=list)
    reasons: list[str] = field(default_factory=list)
    suggestions: list[str] = field(default_factory=list)
    neighborhood_scan: dict[str, list[str]] = field(default_factory=dict)
    citations: list[str] = field(default_factory=list)

    def __repr__(self) -> str:  # pragma: no cover - dev convenience
        return (
            f"<EquilibriumDiagnosis missing={self.missing} "
            f"reasons={len(self.reasons)}>"
        )


@dataclass(frozen=True)
class MCMCDiagnosis:
    """Diagnosis of an MCMC posterior that hasn't converged.

    Attributes:
        converged: ``True`` if every R-hat ≤ 1.1 *and* ESS ≥ 400.
        per_param: ``{param_name: {"r_hat": ..., "ess": ..., "verdict": ...}}``.
        reasons: Why convergence failed (per parameter).
        suggestions: Concrete remedies (chain count, burn-in, step-size).
        citations: Primary references.
    """

    converged: bool = False
    per_param: dict[str, dict[str, Any]] = field(default_factory=dict)
    reasons: list[str] = field(default_factory=list)
    suggestions: list[str] = field(default_factory=list)
    citations: list[str] = field(default_factory=list)

    def __repr__(self) -> str:  # pragma: no cover
        n_bad = sum(1 for v in self.per_param.values() if v.get("r_hat", 0) > 1.1)
        return f"<MCMCDiagnosis converged={self.converged} n_bad={n_bad}>"


@dataclass(frozen=True)
class AMFailureDiagnosis:
    """Diagnosis of an AM-qualification failure.

    Attributes:
        passed: ``False`` for failure diagnoses (returned for completeness).
        failed_criteria: e.g. ``["sigma_uts < 1240 MPa required by F3055"]``.
        root_cause: One-sentence physical root cause (regime / cooling rate / etc.).
        reasons: Bullet expansion of the root cause.
        suggestions: Parameter changes that should clear the failure.
        citations: Primary references.
    """

    passed: bool = False
    failed_criteria: list[str] = field(default_factory=list)
    root_cause: str = ""
    reasons: list[str] = field(default_factory=list)
    suggestions: list[str] = field(default_factory=list)
    citations: list[str] = field(default_factory=list)

    def __repr__(self) -> str:  # pragma: no cover
        return f"<AMFailureDiagnosis root_cause={self.root_cause!r}>"


# ---------------------------------------------------------------------------
# Internal helpers — pure functions, no network, no globals.
# ---------------------------------------------------------------------------


# Heuristic solvus / solubility limits taken from primary CALPHAD literature.
# Used as a fallback so we can answer "why is phase X missing at T" even when
# the engine itself can't be reached (offline / not yet implemented).
#
# Format: (phase_name, system_substring, T_low_K, T_high_K, citation)
_PHASE_TEMPERATURE_WINDOWS: tuple[tuple[str, str, float, float, str], ...] = (
    # Fe-Cr σ-phase: stable only ~820-1100 K in pure Fe-Cr binary.
    ("SIGMA", "Fe-Cr", 820.0, 1100.0,
     "Andersson J.-O., CALPHAD 9 (1985) 187 — Fe-Cr σ solubility surface"),
    # Fe-Cr-Ni σ-phase: stable ~870-1180 K depending on Ni content.
    ("SIGMA", "Fe-Cr-Ni", 870.0, 1180.0,
     "Hertzman S. & Sundman B., CALPHAD 6 (1982) 67 — Fe-Cr-Ni σ"),
    # Ni-Al γ′: stable up to ~1640 K (Ni-Al-Cr higher).
    ("GAMMA_PRIME", "Ni", 300.0, 1640.0,
     "Bratberg J., CALPHAD 20 (1996) 451 — Ni-base γ′ assessment"),
    # Al-Cu θ-phase: stable below ~813 K solvus.
    ("THETA", "Al-Cu", 300.0, 813.0,
     "Murray J.L., Int.Met.Rev. 30 (1985) 211 — Al-Cu phase diagram"),
    # BCC_A2 in Fe-Cr: stable everywhere except a narrow γ-loop ~1180-1670 K.
    ("BCC_A2", "Fe-Cr", 300.0, 3000.0,
     "Andersson J.-O., CALPHAD 9 (1985) 187"),
)


def _identify_system(composition: Mapping[str, float]) -> str:
    """Return a short system tag, e.g. ``"Fe-Cr-Ni"``, from a composition map.

    Elements with mass-fraction ≥ 0.005 are considered "present"; the
    returned tag lists them in canonical CALPHAD-literature order
    (Fe-Cr-Ni, Ni-Cr-Al-Ti, Al-Cu, ...). Doesn't depend on the CALPHAD
    engine — purely string-shaped.

    Strategy: choose the highest-mass element as the host, then order the
    remaining elements by mass fraction (descending), tie-breaking
    alphabetically. This matches the convention CALPHAD assessments use
    when naming a system (Fe-Cr-Ni puts the larger-WT element first).
    """

    present = [(e, x) for e, x in composition.items() if x >= 0.005]
    if not present:
        return "unknown"
    # Sort by mass fraction descending, then alphabetically for ties.
    present.sort(key=lambda t: (-t[1], t[0]))
    return "-".join(e for e, _ in present)


def _window_for(phase: str, system: str) -> Optional[tuple[float, float, str]]:
    """Look up the canonical temperature window for a phase in a system.

    Returns ``(T_low, T_high, citation)`` or ``None``. Matches substring so
    that ``Fe-Cr-Ni`` finds ``Fe-Cr`` if no Fe-Cr-Ni-specific row exists.
    """

    # Prefer the most-specific match.
    candidates = [
        (p, s, lo, hi, cite)
        for (p, s, lo, hi, cite) in _PHASE_TEMPERATURE_WINDOWS
        if p == phase.upper() and (s == system or s in system)
    ]
    if not candidates:
        return None
    # Longest system match wins (Fe-Cr-Ni beats Fe-Cr if both listed).
    candidates.sort(key=lambda r: -len(r[1]))
    _, _, lo, hi, cite = candidates[0]
    return (lo, hi, cite)


# ---------------------------------------------------------------------------
# Public diagnoses
# ---------------------------------------------------------------------------


def explain_equilibrium(
    *,
    composition: Mapping[str, float],
    T_K: float,
    expected_phases: Sequence[str],
    observed_phases: Optional[Sequence[str]] = None,
    scan_step_K: float = 50.0,
) -> EquilibriumDiagnosis:
    """Explain why an equilibrium at ``T_K`` doesn't match expectations.

    Inspired by pycalphad #390 verbatim:

        "I still can't understand phase missing in 500K while no phase
         missing in 450K and 550K."

    The function takes a composition + temperature and a list of phases the
    user *expected* to see. If the calling code already ran the engine it
    can pass ``observed_phases``; otherwise the diagnosis runs purely from
    cited solvus / solubility windows (no engine round-trip needed).

    Args:
        composition: Mass-fraction composition (must sum to ≈1.0).
        T_K: Temperature in kelvin.
        expected_phases: Phase names the user expected (e.g.
            ``["BCC_A2", "SIGMA"]``).
        observed_phases: Phases the engine actually returned, if known.
            When ``None``, we report the *predicted* missing set from the
            cited windows.
        scan_step_K: Half-width of the neighborhood scan (default 50 K).
            The scan reports T-100, T-50, T+50, T+100.

    Returns:
        :class:`EquilibriumDiagnosis` populated with reasons + suggestions.

    Example::

        >>> import austenite as au
        >>> diag = au.diagnostics.explain_equilibrium(
        ...     composition={"Fe": 0.74, "Cr": 0.18, "Ni": 0.08},
        ...     T_K=500,
        ...     expected_phases=["BCC_A2", "SIGMA"],
        ... )
        >>> "SIGMA" in diag.missing
        True
        >>> any("900" in s for s in diag.suggestions)
        True
    """

    system = _identify_system(composition)
    expected = [p.upper() for p in expected_phases]
    observed = (
        [p.upper() for p in observed_phases] if observed_phases is not None else []
    )

    # Compute missing / unexpected.
    if observed_phases is None:
        # Predict the missing set from cited windows.
        missing: list[str] = []
        unexpected: list[str] = []
        for p in expected:
            win = _window_for(p, system)
            if win is None:
                continue
            lo, hi, _ = win
            if T_K < lo or T_K > hi:
                missing.append(p)
    else:
        missing = [p for p in expected if p not in observed]
        unexpected = [p for p in observed if p not in expected]

    reasons: list[str] = []
    suggestions: list[str] = []
    citations: list[str] = []

    for p in missing:
        win = _window_for(p, system)
        if win is None:
            reasons.append(
                f"{p} window is not catalogued for system {system}; "
                "fall back to engine query or DFT prior."
            )
            suggestions.append(
                f"Run `au.calphad.equilibrium(...)` with verbose=True to "
                f"see the {p} Gibbs energy at T_K={T_K}."
            )
            continue
        lo, hi, cite = win
        if T_K < lo:
            reasons.append(
                f"T={T_K:.0f}K is below {p} stability lower bound "
                f"(T_min≈{lo:.0f}K per {cite.split('—')[0].strip()})."
            )
            suggestions.append(
                f"Try T_K={lo:.0f}-{hi:.0f} to see {p}."
            )
        elif T_K > hi:
            reasons.append(
                f"T={T_K:.0f}K is above {p} stability upper bound "
                f"(T_max≈{hi:.0f}K per {cite.split('—')[0].strip()})."
            )
            suggestions.append(
                f"Try T_K={lo:.0f}-{hi:.0f} to see {p}."
            )
        if cite not in citations:
            citations.append(cite)

    # Neighborhood scan — for each offset, return the phases that *should*
    # be stable per our windows. This is the closest thing we can give the
    # user without a network call.
    neighborhood: dict[str, list[str]] = {}
    for d in (-2 * scan_step_K, -scan_step_K, scan_step_K, 2 * scan_step_K):
        T2 = T_K + d
        stable = []
        for p in expected:
            win = _window_for(p, system)
            if win is None:
                continue
            lo, hi, _ = win
            if lo <= T2 <= hi:
                stable.append(p)
        sign = "+" if d > 0 else "-"
        neighborhood[f"T{sign}{abs(int(d))}"] = stable

    if not reasons:
        if missing:
            reasons.append(
                f"Phases {missing} are missing at T={T_K:.0f}K; the cited "
                "solvus windows don't explain it. The engine likely chose "
                "a different free-energy minimum — inspect Gibbs surface."
            )
            suggestions.append("Run au.calphad.equilibrium with show_G=True.")
        else:
            reasons.append(
                f"No diagnostic flags raised — observed phases match expected at T={T_K:.0f}K."
            )

    return EquilibriumDiagnosis(
        missing=missing,
        unexpected=unexpected,
        reasons=reasons,
        suggestions=suggestions,
        neighborhood_scan=neighborhood,
        citations=citations,
    )


def explain_mcmc_convergence(
    posterior: Any,
    *,
    r_hat_threshold: float = 1.1,
    ess_threshold: int = 400,
) -> MCMCDiagnosis:
    """Diagnose an unconverged MCMC posterior.

    Accepts either a :class:`BayesianCalphadDeepResult`-like object (with
    ``.r_hat`` attribute) or a plain ``dict`` with an ``r_hat`` key.
    Returns explanations + suggestions when R-hat > 1.1 or ESS < 400.

    Args:
        posterior: The posterior object returned by
            ``au.bayesian.calphad_deep`` (or compatible).
        r_hat_threshold: R-hat above which a parameter is flagged.
        ess_threshold: ESS below which a parameter is flagged.

    Returns:
        :class:`MCMCDiagnosis` with ``converged`` flag and per-param
        verdicts.

    References:
        * Brooks S.P. & Gelman A., J.Comput.Graph.Stat. 7 (1998) 434.
        * Gelman A. et al., Bayesian Data Analysis 3rd ed. (CRC, 2013) §11.4.
    """

    # Extract r_hat / ess from either dataclass-like or dict-like input.
    def _as_map(obj: Any, key: str) -> Mapping[str, float]:
        if obj is None:
            return {}
        if hasattr(obj, key):
            v = getattr(obj, key)
        elif isinstance(obj, Mapping):
            v = obj.get(key, {})
        else:
            v = {}
        return v if isinstance(v, Mapping) else {}

    r_hats = _as_map(posterior, "r_hat")
    ess = _as_map(posterior, "ess")
    n_chains = (
        getattr(posterior, "chains", None)
        or (posterior.get("chains") if isinstance(posterior, Mapping) else None)
        or 2
    )
    n_samples = (
        getattr(posterior, "samples", None)
        or (posterior.get("samples") if isinstance(posterior, Mapping) else None)
        or 3000
    )

    per_param: dict[str, dict[str, Any]] = {}
    reasons: list[str] = []
    suggestions: list[str] = []

    for name in r_hats:
        rh = float(r_hats.get(name, float("nan")))
        es = float(ess.get(name, float("nan")))
        verdict_bits: list[str] = []
        if rh > r_hat_threshold:
            verdict_bits.append(f"r_hat={rh:.3f}>1.1")
        if es and es == es and es < ess_threshold:  # not NaN check
            verdict_bits.append(f"ess={es:.0f}<{ess_threshold}")
        verdict = "ok" if not verdict_bits else "; ".join(verdict_bits)
        per_param[name] = {"r_hat": rh, "ess": es, "verdict": verdict}

        if rh > r_hat_threshold:
            reasons.append(
                f"{name}: R-hat={rh:.3f} > {r_hat_threshold} — chains have not "
                "mixed; sampler is exploring different modes per chain."
            )

    converged = all(p["verdict"] == "ok" for p in per_param.values()) and bool(per_param)

    if not converged and per_param:
        if n_chains < 4:
            suggestions.append(
                f"Increase chains from {n_chains} to 4-8 — multimodal posteriors "
                "need wider chain ensembles to confidently detect mixing."
            )
        if n_samples < 10000:
            suggestions.append(
                f"Increase samples from {n_samples} to 10000-30000 with "
                "20% burn-in (Gelman BDA3 §11.4 guidance)."
            )
        suggestions.append(
            "Switch to DRAM (method='dram') if currently on plain MH — "
            "delayed-rejection adaptive Metropolis (Haario 2006) handles "
            "narrow ridges much better."
        )
        suggestions.append(
            "Try a more informative prior — uniform priors on rate constants "
            "often induce ridges; switch to log-normal centred on the "
            "literature midpoint."
        )

    if not per_param:
        reasons.append(
            "No R-hat values found on posterior object; can't diagnose. "
            "Ensure posterior is a BayesianCalphadDeepResult or has an "
            "`r_hat` attribute / key."
        )

    return MCMCDiagnosis(
        converged=converged,
        per_param=per_param,
        reasons=reasons,
        suggestions=suggestions,
        citations=[
            "Brooks S.P. & Gelman A., J.Comput.Graph.Stat. 7 (1998) 434",
            "Gelman A. et al., Bayesian Data Analysis 3rd ed. §11.4",
            "Haario H. et al., Stat.Comput. 16 (2006) 339 — DRAM",
        ],
    )


# Volumetric energy density thresholds (J/mm^3) for LPBF melt-pool regimes,
# per Promoppatum 2017 / King 2014. Used by explain_am_failure.
_LPBF_REGIME_BOUNDS = {
    "lack_of_fusion_max_VED": 50.0,
    "keyhole_min_VED": 110.0,  # above this, vapour-keyhole likely
}


def _vol_energy_density(
    P_W: float, v_mm_s: float, h_um: float, t_um: float
) -> float:
    """Volumetric energy density in J/mm^3 (Sames 2016 / Promoppatum 2017)."""

    return P_W / (v_mm_s * (h_um / 1000.0) * (t_um / 1000.0))


def explain_am_failure(result: Any) -> AMFailureDiagnosis:
    """Diagnose an AM qualification failure (LPBF / EBM / DED).

    Walks through the prediction, classifies the melt-pool regime
    (Sames-2016 / Promoppatum-2017), checks whether porosity / cooling-rate
    / energy-density is the most-likely culprit, and recommends a concrete
    parameter shift.

    The result object can be:

      * an :class:`AmQualificationResult` (or attribute-equivalent)
      * a ``dict`` with the same fields

    Required fields (mirroring AmQualificationResult):

      * ``laser_power_W``, ``scan_speed_mm_s``, ``hatch_um``, ``layer_um``
      * ``sigma_uts_MPa`` (or ``properties.sigma_uts_MPa``)
      * ``porosity_pct``
      * ``pass`` / ``passed``  (False triggers the diagnosis)
      * ``spec``  (e.g. ``"ASTM-F3055"``)

    Returns:
        :class:`AMFailureDiagnosis` with the single most-likely root cause
        and a 1-2-step remediation.

    References:
        * Sames W.J. et al., Int.Mater.Rev. 61 (2016) 315 — process map.
        * Promoppatum P., Yao S.-C., Pistorius P.C., Rollett A.D.,
          Engineering 3 (2017) 685 — LPBF melt-pool regime classifier.
        * King W.E. et al., J.Mater.Process.Tech. 214 (2014) 2915 — keyhole.
        * ASTM F3055-14a — PBF nickel alloy specification.
        * ASTM F2924-14 — PBF Ti-6Al-4V specification.
    """

    def _g(obj: Any, name: str, default: Any = None) -> Any:
        if obj is None:
            return default
        if hasattr(obj, name):
            return getattr(obj, name)
        if isinstance(obj, Mapping):
            return obj.get(name, default)
        return default

    # Pull params (top-level then nested under .properties / .inputs).
    P = float(_g(result, "laser_power_W") or _g(_g(result, "inputs"), "laser_power_W") or 0)
    v = float(_g(result, "scan_speed_mm_s") or _g(_g(result, "inputs"), "scan_speed_mm_s") or 0)
    h = float(_g(result, "hatch_um") or _g(_g(result, "inputs"), "hatch_um") or 0)
    t = float(_g(result, "layer_um") or _g(_g(result, "inputs"), "layer_um") or 0)

    uts = _g(result, "sigma_uts_MPa")
    if uts is None:
        uts = _g(_g(result, "properties"), "sigma_uts_MPa")
    porosity = _g(result, "porosity_pct")
    if porosity is None:
        porosity = _g(_g(result, "properties"), "porosity_pct")
    spec = _g(result, "spec", "")
    passed = bool(_g(result, "passed", _g(result, "pass_", _g(result, "pass", True))))

    failed_criteria: list[str] = []
    reasons: list[str] = []
    suggestions: list[str] = []

    # Spec mins (canonical values; user override-able via plugin in future).
    SPEC_MIN_UTS = {
        "ASTM-F3055": 1240.0,  # IN718 LPBF
        "F3055": 1240.0,
        "ASTM-F2924": 895.0,   # Ti-6Al-4V LPBF
        "F2924": 895.0,
    }
    min_uts = None
    for key, mn in SPEC_MIN_UTS.items():
        if key in str(spec).upper():
            min_uts = mn
            break

    if min_uts is not None and uts is not None and float(uts) < min_uts:
        failed_criteria.append(
            f"sigma_uts predicted {uts:.0f} < {min_uts:.0f} MPa required by {spec}"
        )

    if porosity is not None and float(porosity) > 0.5:
        failed_criteria.append(
            f"porosity {porosity:.2f}% > 0.5% AM-defect threshold (Sames 2016)"
        )

    # Compute the regime if all four params are present.
    root_cause = ""
    if P > 0 and v > 0 and h > 0 and t > 0:
        ved = _vol_energy_density(P, v, h, t)
        if ved < _LPBF_REGIME_BOUNDS["lack_of_fusion_max_VED"]:
            regime = "lack_of_fusion"
            root_cause = (
                f"VED={ved:.0f} J/mm^3 is below ~50 J/mm^3 — lack-of-fusion "
                "porosity, columnar/un-fused powder per Promoppatum 2017"
            )
            suggestions.append(
                f"Decrease v from {v:.0f} to {max(100.0, v * 0.7):.0f} mm/s "
                f"OR increase P from {P:.0f} to {P * 1.3:.0f} W to clear LoF."
            )
        elif ved > _LPBF_REGIME_BOUNDS["keyhole_min_VED"]:
            regime = "keyhole"
            root_cause = (
                f"VED={ved:.0f} J/mm^3 is above ~110 J/mm^3 — keyhole regime; "
                "vapour-cavity porosity per King 2014 + cooling rate too slow "
                "→ coarse grain → low UTS"
            )
            suggestions.append(
                f"Increase v from {v:.0f} to {v * 1.15:.0f} mm/s (reduces keyhole "
                "probability and refines grain)."
            )
        else:
            regime = "conduction"
            root_cause = (
                f"VED={ved:.0f} J/mm^3 sits in conduction regime; failure "
                "likely stems from chemistry / heat-treatment, not parameter."
            )
            suggestions.append(
                "Try post-HIP at 1163°C/4h/100MPa + solution + age (AMS 5664) "
                "to lift UTS by 10-15%."
            )
        reasons.append(root_cause)
    else:
        reasons.append(
            "Missing one of {laser_power_W, scan_speed_mm_s, hatch_um, layer_um} "
            "— cannot compute VED. Provide full param set for a regime diagnosis."
        )
        suggestions.append("Re-run au.am.qualification with all four parameters set.")

    if not failed_criteria and not passed:
        failed_criteria.append("Result marked failed but no specific criterion flagged.")
    if failed_criteria and not reasons:
        reasons.append("Failure criteria detected but parameters missing for regime diagnosis.")

    return AMFailureDiagnosis(
        passed=passed,
        failed_criteria=failed_criteria,
        root_cause=root_cause or "; ".join(reasons[:1]),
        reasons=reasons,
        suggestions=suggestions,
        citations=[
            "Sames W.J. et al., Int.Mater.Rev. 61 (2016) 315",
            "Promoppatum P. et al., Engineering 3 (2017) 685",
            "King W.E. et al., J.Mater.Process.Tech. 214 (2014) 2915",
            "ASTM F3055-14a (IN718 LPBF spec)",
            "ASTM F2924-14 (Ti-6Al-4V LPBF spec)",
        ],
    )
