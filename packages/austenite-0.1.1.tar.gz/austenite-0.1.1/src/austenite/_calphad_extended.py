"""Native CALPHAD extension data for line compounds + more alloy systems.

Augments ``_calphad_native.py`` with:

* **Fe-C steels** — cementite Fe3C line compound, M23C6 carbide, additional
  R-K parameters for Fe-C, Cr-C, Mo-C.
* **Al alloys** — Al-Cu (θ-Al2Cu), Al-Mg (β-Al3Mg2), Al-Cu-Mg (S-Al2CuMg)
  line compounds + binary R-K data.
* **Ni superalloys** — γ′-Ni3Al (L1_2 ordered) line compound + Ni-Al R-K.
* **Ti α/β** — HCP_A3 phase SGTE data for Ti.

Citations are inline next to each parameter block.

A line compound G is taken as G_compound(T) = a + b·T (linear in T), with
``a`` (J/mol of formula unit) and ``b`` (J/mol/K) calibrated against
either Andersson 1985 / Hillert 1985 / Saunders-Miodownik 1998 / Dupin
2001 / Murray 1985 published assessments.

References:
    * Andersson J.-O., CALPHAD 11 (1987) 83 — Fe-Cr.
    * Hillert M., Sundman B., CALPHAD 14 (1990) 111 — Fe-C.
    * Murray J.L., Bull. Alloy Phase Diagrams 6 (1985) 121 — Al-Cu.
    * Murray J.L., Bull. Alloy Phase Diagrams 7 (1986) 245 — Al-Mg.
    * Saunders N., COST 507 Round-robin (1998) — Al-Cu-Mg.
    * Dupin N., Ansara I., Sundman B., CALPHAD 25 (2001) 279 — Ni-Al.
    * Saunders N., Miodownik A.P., "CALPHAD" Pergamon (1998) — book.
    * Dinsdale A.T., CALPHAD 15 (1991) 317 — SGTE pure elements.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Mapping

R_GAS: float = 8.31451  # J/mol/K — match _calphad_native.py


# ---------------------------------------------------------------------------
# 1. ADDITIONAL SGTE PURE ELEMENTS (Dinsdale 1991)
# ---------------------------------------------------------------------------
#
# For each element, the SGTE expression is:
#     G(T) − H_SER(298.15) = a + b·T + c·T·ln T + d·T² + e·T³ + f/T
# where H_SER is the enthalpy of the standard element reference (SER) state
# at 298.15 K and 1 atm.
#
# We only include the temperature range that pressure-vessel / structural
# / aerospace engineers care about, typically 298-2500 K.
#
# All values from Dinsdale 1991 (CALPHAD 15:317).


@dataclass(frozen=True)
class SgteCoeff:
    """One SGTE polynomial coefficient set for one (element, phase, T-range)."""

    Tlow: float
    Thigh: float
    a: float
    b: float
    c: float
    d: float
    e: float = 0.0
    f: float = 0.0


# Carbon: graphite is SER. (Reaches the integration range needed for steels.)
SGTE_C_GRAPHITE = [
    SgteCoeff(Tlow=298.15, Thigh=6000.0,
              a=-17368.441, b=170.73, c=-24.3,
              d=-4.723e-4, e=2562600.0, f=2.643e8),
]


# Aluminum: FCC_A1 stable at all engineering T below T_m=933 K, then liquid.
SGTE_AL_FCC = [
    SgteCoeff(Tlow=298.15, Thigh=700.0,
              a=-7976.15, b=137.093038, c=-24.3671976,
              d=-1.884662e-3, e=-0.877664e-6, f=74092.0),
    SgteCoeff(Tlow=700.0, Thigh=933.473,
              a=-11276.24, b=223.048446, c=-38.5844296,
              d=18.531982e-3, e=-5.764227e-6, f=74092.0),
    SgteCoeff(Tlow=933.473, Thigh=2900.0,
              a=-11278.378, b=188.684153, c=-31.748192,
              d=0.0, e=0.0, f=-1.231e28),
]


SGTE_AL_LIQUID = [
    SgteCoeff(Tlow=298.15, Thigh=933.473,
              a=11005.029, b=-11.841867, c=7.934,
              d=-7.34e-7, e=0.0, f=0.0),
    SgteCoeff(Tlow=933.473, Thigh=2900.0,
              a=10482.382, b=-11.253974, c=7.934,
              d=0.0, e=0.0, f=0.0),
]


SGTE_AL_BCC = [
    # Metastable BCC-Al, kept for system completeness
    SgteCoeff(Tlow=298.15, Thigh=2900.0,
              a=10083.0, b=-4.813, c=0.0, d=0.0),
]


# Copper: FCC_A1 stable everywhere below T_m=1357.77 K
SGTE_CU_FCC = [
    SgteCoeff(Tlow=298.15, Thigh=1357.77,
              a=-7770.458, b=130.485235, c=-24.112392,
              d=-2.65684e-3, e=0.129223e-6, f=52478.0),
    SgteCoeff(Tlow=1357.77, Thigh=3200.0,
              a=-13542.026, b=183.803828, c=-31.38,
              d=0.0, e=0.0, f=3.642e29),
]


# Magnesium: HCP_A3 below T_m=923 K
SGTE_MG_HCP = [
    SgteCoeff(Tlow=298.15, Thigh=923.0,
              a=-8367.34, b=143.675547, c=-26.1849782,
              d=0.4858e-3, e=-1.39307e-6, f=78950.0),
    SgteCoeff(Tlow=923.0, Thigh=3000.0,
              a=-14130.185, b=204.716215, c=-34.3088,
              d=0.0, e=0.0, f=1.038e28),
]


# Titanium: HCP_A3 below 1155 K (α-Ti), BCC_A2 above (β-Ti)
SGTE_TI_HCP = [
    SgteCoeff(Tlow=298.15, Thigh=900.0,
              a=-8059.921, b=133.615208, c=-23.9933,
              d=-4.777975e-3, e=0.106716e-6, f=72636.0),
    SgteCoeff(Tlow=900.0, Thigh=1155.0,
              a=-7811.815, b=132.988068, c=-23.9887,
              d=-4.2033e-3, e=-9e-9, f=42680.0),
    SgteCoeff(Tlow=1155.0, Thigh=1941.0,
              a=908.837, b=66.976538, c=-14.9466,
              d=-0.0081465, e=0.20133e-6, f=-1477660.0),
    SgteCoeff(Tlow=1941.0, Thigh=4000.0,
              a=-124526.786, b=638.806871, c=-87.1834,
              d=0.0, e=0.0, f=0.0),
]


SGTE_TI_BCC = [
    SgteCoeff(Tlow=298.15, Thigh=1155.0,
              a=-1272.064, b=134.71418, c=-25.5768,
              d=-0.663845e-3, e=-0.278803e-6, f=7208.0),
    SgteCoeff(Tlow=1155.0, Thigh=1941.0,
              a=6667.385, b=105.366379, c=-22.3771,
              d=0.0, e=0.0, f=2002750.0),
]


# Vanadium: BCC_A2 stable everywhere
SGTE_V_BCC = [
    SgteCoeff(Tlow=298.15, Thigh=790.0,
              a=-7967.842, b=143.291093, c=-25.9,
              d=0.255575e-3, e=-0.687e-6, f=9.522e4),
    SgteCoeff(Tlow=790.0, Thigh=2183.0,
              a=-7967.842, b=143.291093, c=-25.9,
              d=0.255575e-3, e=-0.687e-6, f=9.522e4),
]


# Molybdenum: BCC_A2 stable below T_m=2895 K
SGTE_MO_BCC = [
    SgteCoeff(Tlow=298.15, Thigh=2896.0,
              a=-7746.302, b=131.9197, c=-23.56414,
              d=-3.443e-3, e=0.566e-6, f=65812.0),
]


# Manganese: complex magnetic phases; use BCC_A2 as approx for binary work
SGTE_MN_BCC = [
    SgteCoeff(Tlow=298.15, Thigh=1519.0,
              a=-3439.301, b=131.884712, c=-24.5177,
              d=-6e-3, e=0.69e-6, f=69827.0),
]


# Silicon: diamond cubic SER; used in steels as substitutional
SGTE_SI_DIAMOND = [
    SgteCoeff(Tlow=298.15, Thigh=1687.0,
              a=-8162.609, b=137.236859, c=-22.8317533,
              d=-1.912904e-3, e=-0.003552e-6, f=176667.0),
    SgteCoeff(Tlow=1687.0, Thigh=3600.0,
              a=-9457.642, b=167.281367, c=-27.196,
              d=0.0, e=0.0, f=-4.20369e30),
]


def _sgte_eval(coeff: SgteCoeff, T: float) -> float:
    """Evaluate one SGTE interval polynomial at T (K)."""
    if T < coeff.Tlow - 0.1 or T > coeff.Thigh + 0.1:
        return float("nan")
    try:
        return (coeff.a + coeff.b * T + coeff.c * T * math.log(T)
                + coeff.d * T * T + coeff.e * T * T * T
                + (coeff.f / T if coeff.f and T > 0 else 0.0))
    except (ValueError, OverflowError, ZeroDivisionError):
        return float("nan")


def pure_g_extended(element: str, phase: str, T: float) -> float:
    """Return SGTE pure-element Gibbs energy (J/mol) for elements not
    covered by ``_calphad_native.pure_g``. Returns NaN if unknown."""
    e = element.upper()
    p = phase.upper()
    lookup = {
        ("C", "GRAPHITE"): SGTE_C_GRAPHITE,
        ("C", "BCC_A2"): SGTE_C_GRAPHITE,  # not stable; falls back to graphite
        ("C", "FCC_A1"): SGTE_C_GRAPHITE,
        ("AL", "FCC_A1"): SGTE_AL_FCC,
        ("AL", "LIQUID"): SGTE_AL_LIQUID,
        ("AL", "BCC_A2"): SGTE_AL_BCC,
        ("CU", "FCC_A1"): SGTE_CU_FCC,
        ("MG", "HCP_A3"): SGTE_MG_HCP,
        ("TI", "HCP_A3"): SGTE_TI_HCP,
        ("TI", "BCC_A2"): SGTE_TI_BCC,
        ("V", "BCC_A2"): SGTE_V_BCC,
        ("MO", "BCC_A2"): SGTE_MO_BCC,
        ("MN", "BCC_A2"): SGTE_MN_BCC,
        ("SI", "DIAMOND_A4"): SGTE_SI_DIAMOND,
        ("SI", "FCC_A1"): SGTE_SI_DIAMOND,
    }
    intervals = lookup.get((e, p))
    if intervals is None:
        return float("nan")

    # Choose interval that contains T
    for interval in intervals:
        if interval.Tlow - 0.1 <= T <= interval.Thigh + 0.1:
            return _sgte_eval(interval, T)
    # Out of all intervals — use closest
    if T < intervals[0].Tlow:
        return _sgte_eval(intervals[0], intervals[0].Tlow)
    return _sgte_eval(intervals[-1], intervals[-1].Thigh)


# ---------------------------------------------------------------------------
# 2. LINE-COMPOUND GIBBS ENERGIES (per mole of formula unit)
# ---------------------------------------------------------------------------
#
# G_compound(T) = a + b·T   (linear-T fit per Andersson / Hillert / Murray /
# Dupin assessments; valid for ~298-1500 K which covers all engineering use).
#
# Each compound's reference state is the pure-element SER (BCC, FCC, HCP,
# GRAPHITE) — i.e. you write the formation reaction relative to the
# stable phase of each pure element at 298.15 K.


@dataclass(frozen=True)
class LineCompound:
    """One stoichiometric line compound with linear-T Gibbs energy."""

    name: str
    """Display name (e.g. 'CEMENTITE')."""

    stoichiometry: dict[str, float]
    """Element fractions in the formula unit (must sum to 1.0)."""

    a: float
    """Constant term in J/mol of formula unit."""

    b: float
    """T coefficient in J/mol/K."""

    citation: str
    """Primary reference."""

    structure: str = ""
    """Crystal structure name (e.g. 'orthorhombic Pnma', 'L1_2', 'D0_19')."""


# Fe-C steel system
CEMENTITE = LineCompound(
    name="CEMENTITE",
    stoichiometry={"FE": 0.75, "C": 0.25},  # Fe3C
    a=11369.94 - 5.642 * 1000,   # adjusted Hillert-Sundman 1990 reference
    b=-9.0,
    citation="Hillert M., Sundman B., CALPHAD 14 (1990) 111; SGTE Fe-C assessment.",
    structure="orthorhombic Pnma",
)


# M23C6 (Cr-rich carbide); approx as (Cr23C6) for binary Fe-Cr-C systems
M23C6 = LineCompound(
    name="M23C6",
    stoichiometry={"CR": 23.0 / 29.0, "C": 6.0 / 29.0},
    a=-25540.0,
    b=-7.5,
    citation="Andersson J.-O., Met. Trans. A 19 (1988) 627 - Fe-Cr-C.",
    structure="cubic FCC variant",
)


# Al-Cu (θ-Al2Cu)
THETA_AL2CU = LineCompound(
    name="THETA_AL2CU",
    stoichiometry={"AL": 2.0 / 3.0, "CU": 1.0 / 3.0},
    a=-14620.0,
    b=2.30,
    citation="Murray J.L., Bull. Alloy Phase Diagrams 6 (1985) 121.",
    structure="tetragonal C16",
)


# Al-Mg (β-Al3Mg2, ~38 wt% Mg)
BETA_AL3MG2 = LineCompound(
    name="BETA_AL3MG2",
    stoichiometry={"AL": 0.60, "MG": 0.40},
    a=-3970.0,
    b=-0.81,
    citation="Murray J.L., Bull. Alloy Phase Diagrams 7 (1986) 245.",
    structure="cubic complex (β-phase)",
)


# Al-Cu-Mg ternary S-phase (Al2CuMg)
S_PHASE_AL2CUMG = LineCompound(
    name="S_PHASE_AL2CUMG",
    stoichiometry={"AL": 0.50, "CU": 0.25, "MG": 0.25},
    a=-23800.0,
    b=-3.0,
    citation="Saunders N., COST 507 Vol. II (1998); Chen et al., J. Phase Equilib. 22 (2001) 524.",
    structure="orthorhombic Cmcm",
)


# Ni-Al gamma-prime (γ′-Ni3Al, L1_2 ordered)
GAMMA_PRIME_NI3AL = LineCompound(
    name="GAMMA_PRIME_NI3AL",
    stoichiometry={"NI": 0.75, "AL": 0.25},
    a=-37100.0,
    b=-4.4,
    citation="Dupin N., Ansara I., Sundman B., CALPHAD 25 (2001) 279; "
             "Ansara I., Dupin N., Lukas H., J. Alloys Compd. 247 (1997) 20.",
    structure="L1_2 (ordered FCC)",
)


# Ti-Al α2-Ti3Al (D0_19)
ALPHA2_TI3AL = LineCompound(
    name="ALPHA2_TI3AL",
    stoichiometry={"TI": 0.75, "AL": 0.25},
    a=-32800.0,
    b=-3.7,
    citation="Saunders N., 'Titanium and Titanium Alloys' (2003) p. 116 - calphad assessment.",
    structure="D0_19 (ordered HCP)",
)


# Ti-Al γ-TiAl (L1_0)
GAMMA_TIAL = LineCompound(
    name="GAMMA_TIAL",
    stoichiometry={"TI": 0.50, "AL": 0.50},
    a=-37300.0,
    b=-1.9,
    citation="Saunders N., 'Titanium and Titanium Alloys' (2003) p. 118.",
    structure="L1_0 (ordered face-centred tetragonal)",
)


# Tabulate all line compounds known to the extended engine
LINE_COMPOUND_LIBRARY: dict[str, LineCompound] = {
    "CEMENTITE": CEMENTITE,
    "M23C6": M23C6,
    "THETA_AL2CU": THETA_AL2CU,
    "BETA_AL3MG2": BETA_AL3MG2,
    "S_PHASE_AL2CUMG": S_PHASE_AL2CUMG,
    "GAMMA_PRIME_NI3AL": GAMMA_PRIME_NI3AL,
    "ALPHA2_TI3AL": ALPHA2_TI3AL,
    "GAMMA_TIAL": GAMMA_TIAL,
}


def line_compound_g(compound_name: str, T: float) -> float:
    """Return absolute Gibbs energy of one line compound at temperature T.

    Returns ``a + b·T`` in J/mol of formula unit; NaN if compound unknown.
    """
    lc = LINE_COMPOUND_LIBRARY.get(compound_name.upper())
    if lc is None:
        return float("nan")
    try:
        return float(lc.a + lc.b * float(T))
    except (TypeError, ValueError):
        return float("nan")


def compound_stable_at(
    compound_name: str,
    T: float,
    bulk_x: Mapping[str, float],
    pure_g_func,
    tol: float = 100.0,
) -> bool:
    """Heuristic stability check: a line compound is stable in equilibrium
    if its Gibbs energy is below the linear-combination of the pure elements
    that compose it (weighted by stoichiometry) by at least ``tol`` J/mol.

    Used as a fast filter before adding a compound to the candidate-phase
    set in the full equilibrium solver.
    """
    lc = LINE_COMPOUND_LIBRARY.get(compound_name.upper())
    if lc is None:
        return False
    g_compound = line_compound_g(compound_name, T)
    if not math.isfinite(g_compound):
        return False
    # Reference: weighted sum of pure-element G (in their SER state)
    g_ref = 0.0
    for el, frac in lc.stoichiometry.items():
        # Try each common phase
        g_el = float("nan")
        for ph in ["BCC_A2", "FCC_A1", "HCP_A3", "GRAPHITE", "LIQUID"]:
            g_el = pure_g_extended(el, ph, T)
            if math.isfinite(g_el):
                break
        if not math.isfinite(g_el):
            # Try the existing _calphad_native lookup
            try:
                g_el = pure_g_func(el, "BCC_A2", T)
            except (KeyError, ValueError, TypeError):
                pass
        if not math.isfinite(g_el):
            return False
        g_ref += float(frac) * g_el
    return g_compound + tol < g_ref


# ---------------------------------------------------------------------------
# 3. ALLOY SYSTEM REGISTRY
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class AlloySystem:
    """Catalogues which line compounds are relevant for an alloy system."""

    name: str
    elements: tuple[str, ...]
    line_compounds: tuple[str, ...]
    citation: str


ALLOY_SYSTEMS: dict[str, AlloySystem] = {
    "fe-c": AlloySystem(
        name="Fe-C (plain-carbon steels)",
        elements=("FE", "C"),
        line_compounds=("CEMENTITE",),
        citation="Hillert M., Sundman B., CALPHAD 14 (1990) 111.",
    ),
    "fe-cr-c": AlloySystem(
        name="Fe-Cr-C (chrome alloy steels: 4140, 4340, 52100)",
        elements=("FE", "CR", "C"),
        line_compounds=("CEMENTITE", "M23C6"),
        citation="Andersson J.-O., Met. Trans. A 19 (1988) 627.",
    ),
    "fe-cr-mo-c": AlloySystem(
        name="Fe-Cr-Mo-C (Cr-Mo creep steels: P11, P22, P91, 2.25Cr-1Mo)",
        elements=("FE", "CR", "MO", "C"),
        line_compounds=("CEMENTITE", "M23C6"),
        citation="Andersson J.-O. and Sundman B., CALPHAD 11 (1987) 83.",
    ),
    "al-cu": AlloySystem(
        name="Al-Cu (precipitation-hardenable Al alloys: 2024, 2014, 2090)",
        elements=("AL", "CU"),
        line_compounds=("THETA_AL2CU",),
        citation="Murray J.L., Bull. Alloy Phase Diagrams 6 (1985) 121.",
    ),
    "al-mg": AlloySystem(
        name="Al-Mg (5xxx work-hardenable Al alloys: 5052, 5083, 5086, 5454)",
        elements=("AL", "MG"),
        line_compounds=("BETA_AL3MG2",),
        citation="Murray J.L., Bull. Alloy Phase Diagrams 7 (1986) 245.",
    ),
    "al-cu-mg": AlloySystem(
        name="Al-Cu-Mg (2xxx aerospace Al alloys: 2024, 2014, 2618)",
        elements=("AL", "CU", "MG"),
        line_compounds=("THETA_AL2CU", "BETA_AL3MG2", "S_PHASE_AL2CUMG"),
        citation="Saunders N., COST 507 (1998); Chen J. Phase Equilib. 22 (2001) 524.",
    ),
    "ni-al": AlloySystem(
        name="Ni-Al (γ/γ′-strengthened Ni superalloys: IN718, Waspaloy, Rene)",
        elements=("NI", "AL"),
        line_compounds=("GAMMA_PRIME_NI3AL",),
        citation="Dupin N., Ansara I., Sundman B., CALPHAD 25 (2001) 279.",
    ),
    "ti-al": AlloySystem(
        name="Ti-Al (α2/γ titanium aluminides: gamma-TiAl, Ti-48-2-2)",
        elements=("TI", "AL"),
        line_compounds=("ALPHA2_TI3AL", "GAMMA_TIAL"),
        citation="Saunders N., 'Titanium and Titanium Alloys' (2003) p. 116-118.",
    ),
}


def identify_system(elements: list[str]) -> str | None:
    """Pick the most-specific alloy system from ALLOY_SYSTEMS that covers
    the given element list. Returns the key (e.g. 'fe-cr-mo-c') or None.

    The most-specific match (longest element-tuple intersection) wins.
    """
    elements_upper = {e.upper() for e in elements}
    best_key: str | None = None
    best_match = -1
    for key, sys_ in ALLOY_SYSTEMS.items():
        sys_elements = set(sys_.elements)
        if sys_elements.issubset(elements_upper) and len(sys_elements) > best_match:
            best_match = len(sys_elements)
            best_key = key
    return best_key


def get_line_compounds_for_system(system_key: str) -> list[LineCompound]:
    """Return the list of line compounds associated with one alloy system."""
    sys_ = ALLOY_SYSTEMS.get(system_key)
    if sys_ is None:
        return []
    return [LINE_COMPOUND_LIBRARY[lc] for lc in sys_.line_compounds
            if lc in LINE_COMPOUND_LIBRARY]


# ---------------------------------------------------------------------------
# 4. PUBLIC HELPER — predict simple precipitation
# ---------------------------------------------------------------------------


def predict_precipitates(
    composition: Mapping[str, float],
    T_K: float,
    *,
    pure_g_func=None,
) -> dict:
    """Return a list of line compounds that are thermodynamically stable
    for the given composition at temperature T.

    This is a fast first-pass screen — does NOT do a full equilibrium
    calculation but answers "what precipitates can form?" which is what
    engineers want for alloy design / heat-treatment scoping.

    Parameters
    ----------
    composition: dict mapping element symbol → mole fraction (need not sum
        to exactly 1; will be normalised).
    T_K: temperature in Kelvin.
    pure_g_func: optional pure-element G function (typically
        ``_calphad_native.pure_g``). If None, only the extended SGTE data
        in this module is used (so Fe is unsupported — use the upstream
        function for ferrous).

    Returns
    -------
    {
        "system": str,                      # e.g. 'fe-cr-mo-c'
        "stable_compounds": [               # in order of driving force
            {"name": ..., "G_J_mol": ..., "structure": ..., "citation": ...}
        ],
        "T_K": float,
        "composition_normalised": {...},
    }
    """
    elements_present = [e.upper() for e, v in composition.items()
                        if isinstance(v, (int, float)) and v > 0]
    system = identify_system(elements_present)
    if system is None:
        return {
            "system": None,
            "stable_compounds": [],
            "T_K": float(T_K),
            "composition_normalised": dict(composition),
            "notes": [f"No registered alloy system covers {elements_present}; "
                     f"available systems: {list(ALLOY_SYSTEMS.keys())}"],
        }

    if pure_g_func is None:
        def pure_g_func(el, ph, T):
            return pure_g_extended(el, ph, T)

    candidates = get_line_compounds_for_system(system)
    stable: list[dict] = []
    for lc in candidates:
        if compound_stable_at(lc.name, T_K, composition, pure_g_func):
            stable.append({
                "name": lc.name,
                "G_J_mol": line_compound_g(lc.name, T_K),
                "structure": lc.structure,
                "citation": lc.citation,
                "stoichiometry": dict(lc.stoichiometry),
            })

    # Sort by driving force (most-negative G first)
    stable.sort(key=lambda d: d["G_J_mol"])

    total = sum(v for v in composition.values() if isinstance(v, (int, float)) and v > 0)
    normalised = {k.upper(): float(v) / total
                  for k, v in composition.items()
                  if isinstance(v, (int, float)) and v > 0 and total > 0}

    return {
        "system": system,
        "system_name": ALLOY_SYSTEMS[system].name,
        "stable_compounds": stable,
        "T_K": float(T_K),
        "composition_normalised": normalised,
        "n_candidates_considered": len(candidates),
    }


__all__ = [
    "R_GAS",
    "SgteCoeff",
    "pure_g_extended",
    "LineCompound",
    "LINE_COMPOUND_LIBRARY",
    "CEMENTITE", "M23C6",
    "THETA_AL2CU", "BETA_AL3MG2", "S_PHASE_AL2CUMG",
    "GAMMA_PRIME_NI3AL",
    "ALPHA2_TI3AL", "GAMMA_TIAL",
    "line_compound_g",
    "compound_stable_at",
    "AlloySystem",
    "ALLOY_SYSTEMS",
    "identify_system",
    "get_line_compounds_for_system",
    "predict_precipitates",
]
