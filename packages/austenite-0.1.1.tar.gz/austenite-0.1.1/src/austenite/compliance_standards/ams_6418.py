"""AMS 6418 (AISI 4340 modified aerospace forging) compliance checker.

Verifies composition + Q&T mechanicals for vacuum-consumable-electrode
remelted AISI 4340 modified forging. Optional heat-treatment block can
be passed in to check austenitize + temper temperatures.

Example::

    from austenite.compliance_standards import ams_6418
    v = ams_6418.check(
        composition={"C": 0.40, "Mn": 0.75, "Si": 0.25, "P": 0.005, "S": 0.003,
                     "Cr": 0.85, "Ni": 1.80, "Mo": 0.25},
        mechanical={"sigma_y_MPa": 1280, "sigma_uts_MPa": 1450,
                    "elongation_pct": 11, "hardness_HRC": 45,
                    "K_IC_MPa_sqrt_m": 65},
        heat_treatment={"austenitize_C": 845, "temper_C": 260},
    )
"""

from __future__ import annotations

from typing import Any, Mapping, Optional

from . import StandardVerdict, _load_data, _run_envelope


_DATA: Optional[dict[str, Any]] = None


def _data() -> dict[str, Any]:
    global _DATA
    if _DATA is None:
        _DATA = _load_data("ams_6418.json")
    return _DATA


def _check_range(label: str, value: float, lo: float, hi: float) -> tuple[bool, str]:
    if value < lo:
        return False, f"{label} = {value} below min {lo} [approx]"
    if value > hi:
        return False, f"{label} = {value} above max {hi} [approx]"
    return True, f"{label} = {value} within {lo}-{hi} [approx]"


def check(
    composition: Optional[Mapping[str, float]] = None,
    mechanical: Optional[Mapping[str, float]] = None,
    *,
    heat_treatment: Optional[Mapping[str, Any]] = None,
    **_: Any,
) -> StandardVerdict:
    """Return a :class:`StandardVerdict` for AMS 6418.

    Args:
        composition: wt% per element. Recognised: C, Mn, Si, P, S, Cr, Ni,
            Mo, Cu, V, B.
        mechanical: ``sigma_y_MPa``, ``sigma_uts_MPa``, ``elongation_pct``,
            ``reduction_of_area_pct``, ``hardness_HRC``, ``CVN_J_at_-54C``,
            ``K_IC_MPa_sqrt_m``.
        heat_treatment: optional ``{austenitize_C, temper_C}``.
    """

    extras: list[tuple[bool, str]] = []

    if heat_treatment:
        ht_spec = _data().get("heat_treatment") or {}
        aus_range = ht_spec.get("austenitize_C") or []
        tmp_range = ht_spec.get("temper_C") or []
        if "austenitize_C" in heat_treatment and len(aus_range) == 2:
            extras.append(
                _check_range(
                    "austenitize_C",
                    float(heat_treatment["austenitize_C"]),
                    float(aus_range[0]),
                    float(aus_range[1]),
                )
            )
        if "temper_C" in heat_treatment and len(tmp_range) == 2:
            extras.append(
                _check_range(
                    "temper_C",
                    float(heat_treatment["temper_C"]),
                    float(tmp_range[0]),
                    float(tmp_range[1]),
                )
            )

    return _run_envelope(
        data=_data(),
        composition=composition,
        mechanical=mechanical,
        extras=extras,
    )


__all__ = ["check"]
