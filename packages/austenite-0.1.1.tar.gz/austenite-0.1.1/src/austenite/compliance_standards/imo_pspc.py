"""IMO MSC.215(82) PSPC compliance checker.

The Performance Standard for Protective Coatings is a procedure /
application-quality standard rather than a material composition spec —
this checker therefore looks at the *coating system* (DFT, stripe coats,
surface prep, climate conditions) rather than steel composition.

The ``mechanical`` argument is overloaded here as the coating system
properties; ``composition`` is ignored.

Example::

    from austenite.compliance_standards import imo_pspc
    v = imo_pspc.check(
        mechanical={
            "DFT_nominal_um": 320,
            "DFT_min_um": 330,
            "stripe_coat_count": 2,
            "main_coat_count": 2,
            "surface_prep_Sa": 2.5,
            "salt_content_mg_per_m2": 30,
        }
    )
"""

from __future__ import annotations

from typing import Any, Mapping, Optional

from . import StandardVerdict, _load_data, _run_envelope


_DATA: Optional[dict[str, Any]] = None


def _data() -> dict[str, Any]:
    global _DATA
    if _DATA is None:
        _DATA = _load_data("imo_pspc.json")
    return _DATA


def check(
    composition: Optional[Mapping[str, float]] = None,
    mechanical: Optional[Mapping[str, float]] = None,
    **_: Any,
) -> StandardVerdict:
    """Return a :class:`StandardVerdict` for IMO PSPC (MSC.215(82)).

    Args:
        composition: ignored (PSPC is not a chemistry spec).
        mechanical: Coating-system attributes. See ``_data/imo_pspc.json``
            for the full list of fields and their envelopes.
    """

    extras: list[tuple[bool, str]] = []
    if composition:
        extras.append((
            True,
            "composition: ignored — PSPC is a coating-system standard, not a chemistry spec",
        ))
    return _run_envelope(
        data=_data(),
        composition=None,
        mechanical=mechanical,
        extras=extras,
    )


__all__ = ["check"]
