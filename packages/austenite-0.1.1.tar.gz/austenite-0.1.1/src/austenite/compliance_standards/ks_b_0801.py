"""KS B 0801 (Korean tensile test method) procedure-compliance checker.

This is a *test-procedure* standard, not a material spec. The checker
takes a ``mechanical`` block that describes how a tensile test was set
up (gauge length, strain rate, machine class, etc.) and reports whether
the procedure complies with KS B 0801.

Example::

    from austenite.compliance_standards import ks_b_0801
    v = ks_b_0801.check(
        mechanical={
            "gauge_length_mm": 50,
            "parallel_length_mm": 60,
            "test_temperature_C": 22,
            "strain_rate_per_s": 0.0008,
            "specimen_diameter_mm": 10,
            "calibration_class_iso_7500_1": 1.0,
        },
        fracture_inside_gauge=True,
        specimen_geometry="No.4",
    )
"""

from __future__ import annotations

from typing import Any, Mapping, Optional

from . import StandardVerdict, _load_data, _run_envelope


_DATA: Optional[dict[str, Any]] = None


def _data() -> dict[str, Any]:
    global _DATA
    if _DATA is None:
        _DATA = _load_data("ks_b_0801.json")
    return _DATA


def check(
    composition: Optional[Mapping[str, float]] = None,
    mechanical: Optional[Mapping[str, float]] = None,
    *,
    specimen_geometry: Optional[str] = None,
    fracture_inside_gauge: Optional[bool] = None,
    **_: Any,
) -> StandardVerdict:
    """Return a :class:`StandardVerdict` for KS B 0801 procedure compliance.

    Args:
        composition: ignored (test-procedure standard).
        mechanical: Procedure attributes — see ``_data/ks_b_0801.json``.
        specimen_geometry: Optional KS B 0801 specimen-type id
            (``"No.2" | "No.4" | "No.5" | ...``).
        fracture_inside_gauge: Optional — if False, the test is invalid
            per §10 (fracture outside parallel length).
    """

    procedure_checks = (_data().get("procedure_checks") or {})
    valid_specimens = procedure_checks.get("specimen_geometries") or []
    require_inside_gauge = bool(procedure_checks.get("fracture_location_must_be_inside_gauge"))

    extras: list[tuple[bool, str]] = []
    if specimen_geometry is not None:
        ok = specimen_geometry in valid_specimens
        extras.append((
            ok,
            (
                f"specimen_geometry = '{specimen_geometry}' is a recognised KS B 0801 form"
                if ok
                else f"specimen_geometry = '{specimen_geometry}' not in valid set {valid_specimens}"
            ),
        ))
    if fracture_inside_gauge is not None and require_inside_gauge:
        extras.append((
            bool(fracture_inside_gauge),
            (
                "fracture inside gauge length — test valid per §10"
                if fracture_inside_gauge
                else "fracture outside parallel length — test invalid per §10"
            ),
        ))
    if composition:
        extras.append((
            True,
            "composition: ignored — KS B 0801 is a tensile-test procedure standard",
        ))

    return _run_envelope(
        data=_data(),
        composition=None,
        mechanical=mechanical,
        extras=extras,
    )


__all__ = ["check"]
