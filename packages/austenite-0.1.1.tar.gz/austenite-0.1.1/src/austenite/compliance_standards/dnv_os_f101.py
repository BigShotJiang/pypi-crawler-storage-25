"""DNV-OS-F101 (Submarine pipeline systems) compliance checker.

Verifies that a line-pipe steel composition + mechanical envelope meet
the DNV pipe-material qualification criteria — C/CE_IIW/Pcm limits,
yield + UTS range, ductility and Charpy at -30 °C.

Example::

    from austenite.compliance_standards import dnv_os_f101
    v = dnv_os_f101.check(
        composition={"C": 0.14, "Mn": 1.30, "P": 0.012, "S": 0.005},
        mechanical={"sigma_y_MPa": 450, "sigma_uts_MPa": 540,
                    "elongation_pct": 24, "CVN_J_at_-30C": 60},
    )
"""

from __future__ import annotations

from typing import Any, Mapping, Optional

from . import StandardVerdict, _load_data, _run_envelope


_DATA: Optional[dict[str, Any]] = None


def _data() -> dict[str, Any]:
    global _DATA
    if _DATA is None:
        _DATA = _load_data("dnv_os_f101.json")
    return _DATA


def check(
    composition: Optional[Mapping[str, float]] = None,
    mechanical: Optional[Mapping[str, float]] = None,
    **_: Any,
) -> StandardVerdict:
    """Return a :class:`StandardVerdict` for DNV-OS-F101.

    Args:
        composition: wt% per element. Recognised: C, Si, Mn, P, S, Cu, Ni,
            Cr, Mo, V, Nb, Ti, B. CE_IIW + Pcm derived if not supplied.
        mechanical: ``sigma_y_MPa``, ``sigma_uts_MPa``, ``elongation_pct``,
            ``CVN_J_at_-30C``, ``hardness_HV``.
    """

    return _run_envelope(
        data=_data(),
        composition=composition,
        mechanical=mechanical,
    )


__all__ = ["check"]
