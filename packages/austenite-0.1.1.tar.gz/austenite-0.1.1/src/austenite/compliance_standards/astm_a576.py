"""ASTM A576 (Carbon steel bar, hot-wrought) compliance checker.

Verifies composition + mechanicals against one of the SAE-grade carbon
steel bars — 1018, 1045, 1095. Default grade is 1045.

Example::

    from austenite.compliance_standards import astm_a576
    v = astm_a576.check(
        composition={"C": 0.46, "Mn": 0.75, "P": 0.025, "S": 0.030},
        mechanical={"sigma_y_MPa": 460, "sigma_uts_MPa": 600,
                    "elongation_pct": 17, "hardness_HB": 180},
        grade="1045",
    )
"""

from __future__ import annotations

from typing import Any, Mapping, Optional

from . import StandardVerdict, _grade_data, _load_data, _run_envelope


_DATA: Optional[dict[str, Any]] = None


def _data() -> dict[str, Any]:
    global _DATA
    if _DATA is None:
        _DATA = _load_data("astm_a576.json")
    return _DATA


def check(
    composition: Optional[Mapping[str, float]] = None,
    mechanical: Optional[Mapping[str, float]] = None,
    *,
    grade: Optional[str] = None,
    **_: Any,
) -> StandardVerdict:
    """Return a :class:`StandardVerdict` for ASTM A576.

    Args:
        composition: wt% per element.
        mechanical: ``sigma_y_MPa``, ``sigma_uts_MPa``, ``elongation_pct``,
            ``hardness_HB``.
        grade: One of ``"1018" | "1045" | "1095"``. Default ``"1045"``.
    """

    synth, _ = _grade_data(_data(), grade)
    return _run_envelope(
        data=synth,
        composition=composition,
        mechanical=mechanical,
    )


def list_grades() -> list[str]:
    return sorted((_data().get("grades") or {}).keys())


__all__ = ["check", "list_grades"]
