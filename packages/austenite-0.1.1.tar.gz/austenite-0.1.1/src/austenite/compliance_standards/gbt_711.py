"""GB/T 711 (Chinese hot-rolled carbon structural steel) compliance checker.

Verifies composition + mechanicals against one of the Q-series grades —
Q235B, Q345B, Q420C.

Example::

    from austenite.compliance_standards import gbt_711
    v = gbt_711.check(
        composition={"C": 0.16, "Si": 0.30, "Mn": 1.20, "P": 0.020, "S": 0.015},
        mechanical={"sigma_y_MPa": 360, "sigma_uts_MPa": 520,
                    "elongation_pct": 24, "CVN_J_at_+20C": 50},
        grade="Q345B",
    )
"""

from __future__ import annotations

from typing import Any, Mapping, Optional

from . import StandardVerdict, _grade_data, _load_data, _run_envelope


_DATA: Optional[dict[str, Any]] = None


def _data() -> dict[str, Any]:
    global _DATA
    if _DATA is None:
        _DATA = _load_data("gbt_711.json")
    return _DATA


def check(
    composition: Optional[Mapping[str, float]] = None,
    mechanical: Optional[Mapping[str, float]] = None,
    *,
    grade: Optional[str] = None,
    **_: Any,
) -> StandardVerdict:
    """Return a :class:`StandardVerdict` for GB/T 711.

    Args:
        composition: wt% per element. CE_IIW derived if not supplied.
        mechanical: ``sigma_y_MPa``, ``sigma_uts_MPa``, ``elongation_pct``,
            ``CVN_J_at_+20C`` / ``CVN_J_at_0C``.
        grade: One of ``"Q235B" | "Q345B" | "Q420C"``. Default ``"Q345B"``.
    """

    synth, _ = _grade_data(_data(), grade)
    return _run_envelope(
        data=synth,
        composition=composition,
        mechanical=mechanical,
    )


def list_grades() -> list[str]:
    return sorted((_data().get("grades") or {}).keys())


__all__ = ["check", "list_grades"]
