"""ASTM A574 (Alloy steel socket-head cap screws) compliance checker.

Verifies composition + mechanical envelope for Q&T alloy-steel socket
head cap screws. Mechanical envelope is size-class aware — three
classes are bundled (≤5/8", >5/8" to 1", >1" to 1-1/2").

Example::

    from austenite.compliance_standards import astm_a574
    v = astm_a574.check(
        composition={"C": 0.40, "Mn": 0.85, "Si": 0.25, "P": 0.020, "S": 0.025,
                     "Cr": 0.95, "Mo": 0.20},
        mechanical={"sigma_uts_MPa": 1350, "sigma_y_MPa": 1200,
                    "elongation_pct": 12, "hardness_HRC": 41,
                    "reduction_of_area_pct": 40},
        size_class="screw_size_le_5_8_in",
    )
"""

from __future__ import annotations

from typing import Any, Mapping, Optional

from . import StandardVerdict, _load_data, _run_envelope


_DATA: Optional[dict[str, Any]] = None


def _data() -> dict[str, Any]:
    global _DATA
    if _DATA is None:
        _DATA = _load_data("astm_a574.json")
    return _DATA


def check(
    composition: Optional[Mapping[str, float]] = None,
    mechanical: Optional[Mapping[str, float]] = None,
    *,
    size_class: Optional[str] = None,
    **_: Any,
) -> StandardVerdict:
    """Return a :class:`StandardVerdict` for ASTM A574.

    Args:
        composition: wt% per element.
        mechanical: ``sigma_uts_MPa``, ``sigma_y_MPa``, ``elongation_pct``,
            ``reduction_of_area_pct``, ``hardness_HRC``, plus optional
            ``axial_tension_load_kN_M10x1_5``, ``torsion_to_failure_Nm_M10x1_5``.
        size_class: Optional — one of
            ``"screw_size_le_5_8_in" | "screw_size_gt_5_8_to_1_in" |
            "screw_size_gt_1_to_1_1_2_in"``. Defaults to the loosest
            envelope (the >1\" set).
    """

    data = _data()
    if size_class is not None:
        size_block = (data.get("size_classes") or {}).get(size_class)
        if size_block is None:
            valid = sorted((data.get("size_classes") or {}).keys())
            raise ValueError(
                f"ASTM A574: size_class '{size_class}' unknown; valid: {valid}"
            )
        # Override the mechanical envelope with the size-specific one but keep composition.
        synth = dict(data)
        synth["limits"] = {
            "composition_wt_pct": (data.get("limits") or {}).get("composition_wt_pct") or {},
            "mechanical": dict(size_block.get("mechanical") or {}),
        }
        base_cit = data.get("citation") or ""
        if base_cit:
            synth["citation"] = f"{base_cit} — size class {size_class}"
        return _run_envelope(
            data=synth,
            composition=composition,
            mechanical=mechanical,
        )
    return _run_envelope(
        data=data,
        composition=composition,
        mechanical=mechanical,
    )


def list_size_classes() -> list[str]:
    return sorted((_data().get("size_classes") or {}).keys())


__all__ = ["check", "list_size_classes"]
