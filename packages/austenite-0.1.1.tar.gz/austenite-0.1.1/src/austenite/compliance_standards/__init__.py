"""Per-standard compliance checkers — composition + mechanical envelope.

Each module under this package exposes a ``check(composition, mechanical=None)``
function that returns a :class:`StandardVerdict` describing whether the
material falls within the limits published in the named standard.

The 10 standards bundled here are:

  * ``dnv_os_f101``   — DNV-OS-F101 Submarine pipeline systems
  * ``imo_pspc``      — IMO MSC.215(82) Performance Standard for Protective Coatings
  * ``jis_g3106``     — JIS G3106 Rolled steels for welded structure (SM490 etc.)
  * ``gbt_711``       — GB/T 711 Hot-rolled carbon steel (Q235/Q345/Q420)
  * ``ks_b_0801``     — KS B 0801 Korean tensile-test method procedure
  * ``ams_6517``      — AMS 6517 Cr-Mo-V aerospace alloy steel
  * ``ams_6418``      — AMS 6418 AISI 4340 aerospace forging
  * ``mil_s_46100``   — MIL-S-46100 Armor steel (ballistic + chemistry)
  * ``astm_a576``     — ASTM A576 Carbon steel bar
  * ``astm_a574``     — ASTM A574 Alloy steel socket-head cap screws

Data are loaded from ``_data/<name>.json``. Where the published numbers are
not in the public domain at line-item resolution, industry-typical values
are used and flagged with ``[approx]`` in the corresponding note.

Public entry-points::

    import austenite as au

    # Per-standard
    verdict = au.compliance.check_standard(
        "DNV-OS-F101",
        composition={"C": 0.14, "Mn": 1.20, "P": 0.012, "S": 0.005, "CE_IIW": 0.42},
        mechanical={"sigma_y_MPa": 450, "sigma_uts_MPa": 540, "elongation_pct": 24},
    )
    verdict.passed          # True
    verdict.failed_items    # []
    verdict.notes           # ['CE_IIW = 0.42 within 0.43 max', ...]
    verdict.citation        # 'DNV-OS-F101 (2013-08) Submarine pipeline systems'

    # Introspect
    au.compliance.list_standards()
    # → ['AMS 6418', 'AMS 6517', 'ASTM A574', 'ASTM A576', 'ASTM A29',
    #    'API 579-1', 'API 581', 'ASME II-D', 'DNV-OS-F101', 'GB/T 711',
    #    'IMO PSPC (MSC.215(82))', 'JIS G3106', 'KS B 0801', 'MIL-S-46100',
    #    'NACE MR0175']
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from importlib import resources
from typing import Any, Callable, Iterable, Mapping, Optional


# ---------------------------------------------------------------------------
# Verdict dataclass — distinct from the server-side ComplianceBayesianPPassResult
# so as not to muddle the two contracts (one is FORM/MC, this is envelope check).
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class StandardVerdict:
    """Result of a per-standard envelope compliance check.

    Attributes:
        spec_id: Canonical id of the standard checked (e.g. ``"DNV-OS-F101"``).
        passed: ``True`` iff every checked item is within published limits.
        failed_items: List of one-line failure descriptions
            (e.g. ``["C = 0.18 wt% exceeds max 0.16"]``).
        notes: Human-readable notes about every check performed
            (passing items get a note too, so a passing verdict still
            shows what was verified).
        citation: Short citation string with edition.
        title: Spec title.
        edition: Edition id.
        url: Optional standard-info URL.
        value: Optional headline numeric output (back-compat — used by
            plugin-contributed verdicts that boil down to one number).
        unit: Unit of ``value``.
        threshold: The pass/fail cutoff (back-compat).
    """

    spec_id: str
    passed: bool
    failed_items: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    citation: str = ""
    title: str = ""
    edition: str = ""
    url: Optional[str] = None
    value: Optional[float] = None
    unit: Optional[str] = None
    threshold: Optional[float] = None

    # Back-compat alias — earlier versions of the API used ``passes``.
    @property
    def passes(self) -> bool:
        return bool(self.passed)

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "spec_id": self.spec_id,
            "passed": self.passed,
            "passes": self.passed,  # back-compat
            "failed_items": list(self.failed_items),
            "notes": list(self.notes),
            "citation": self.citation,
            "title": self.title,
            "edition": self.edition,
            "url": self.url,
        }
        if self.value is not None:
            out["value"] = float(self.value)
        if self.unit is not None:
            out["unit"] = self.unit
        if self.threshold is not None:
            out["threshold"] = float(self.threshold)
        return out


# ---------------------------------------------------------------------------
# Data loader
# ---------------------------------------------------------------------------


def _load_data(filename: str) -> dict[str, Any]:
    """Load a JSON limits file from ``compliance_standards/_data/``."""

    pkg = resources.files("austenite.compliance_standards._data")
    text = (pkg / filename).read_text(encoding="utf-8")
    return json.loads(text)


# ---------------------------------------------------------------------------
# Generic envelope-check helpers — used by ~all standards
# ---------------------------------------------------------------------------


def _check_min_max(
    *,
    label: str,
    value: Optional[float],
    bounds: Mapping[str, Any],
    unit: str = "",
    approx: bool = False,
) -> tuple[bool, str]:
    """Apply ``min``/``max`` from a bounds dict to a numeric value.

    Returns ``(ok, note)``. If ``value is None`` the field is treated as
    not-supplied and skipped (returns ``(True, '<skipped>')``).
    """

    if value is None:
        return True, f"{label}: not supplied — skipped"
    lo = bounds.get("min")
    hi = bounds.get("max")
    approx_tag = " [approx]" if approx else ""
    if lo is not None and value < lo:
        return (
            False,
            f"{label} = {value}{(' ' + unit) if unit else ''} below min {lo}{approx_tag}",
        )
    if hi is not None and value > hi:
        return (
            False,
            f"{label} = {value}{(' ' + unit) if unit else ''} exceeds max {hi}{approx_tag}",
        )
    range_str = ""
    if lo is not None and hi is not None:
        range_str = f"{lo}-{hi}"
    elif lo is not None:
        range_str = f"≥{lo}"
    elif hi is not None:
        range_str = f"≤{hi}"
    return (
        True,
        f"{label} = {value}{(' ' + unit) if unit else ''} within {range_str}{approx_tag}",
    )


def _carbon_equivalent_iiw(comp: Mapping[str, float]) -> Optional[float]:
    """IIW carbon-equivalent (a.k.a. CE_IIW)::

        CE = C + Mn/6 + (Cr + Mo + V)/5 + (Ni + Cu)/15
    """

    try:
        c = float(comp.get("C", 0.0))
        mn = float(comp.get("Mn", 0.0))
        cr = float(comp.get("Cr", 0.0))
        mo = float(comp.get("Mo", 0.0))
        v = float(comp.get("V", 0.0))
        ni = float(comp.get("Ni", 0.0))
        cu = float(comp.get("Cu", 0.0))
    except (TypeError, ValueError):
        return None
    return c + mn / 6.0 + (cr + mo + v) / 5.0 + (ni + cu) / 15.0


def _pcm(comp: Mapping[str, float]) -> Optional[float]:
    """Ito-Bessyo Pcm crack-susceptibility parameter::

        Pcm = C + Si/30 + (Mn+Cu+Cr)/20 + Ni/60 + Mo/15 + V/10 + 5B
    """

    try:
        c = float(comp.get("C", 0.0))
        si = float(comp.get("Si", 0.0))
        mn = float(comp.get("Mn", 0.0))
        cu = float(comp.get("Cu", 0.0))
        cr = float(comp.get("Cr", 0.0))
        ni = float(comp.get("Ni", 0.0))
        mo = float(comp.get("Mo", 0.0))
        v = float(comp.get("V", 0.0))
        b = float(comp.get("B", 0.0))
    except (TypeError, ValueError):
        return None
    return (
        c
        + si / 30.0
        + (mn + cu + cr) / 20.0
        + ni / 60.0
        + mo / 15.0
        + v / 10.0
        + 5.0 * b
    )


def _run_envelope(
    *,
    data: Mapping[str, Any],
    composition: Optional[Mapping[str, float]] = None,
    mechanical: Optional[Mapping[str, float]] = None,
    extras: Optional[Iterable[tuple[bool, str]]] = None,
) -> StandardVerdict:
    """Apply the limits in ``data['limits']`` to the supplied measurements.

    The data file is expected to follow the schema described in this
    package's docstring. Specifically it must contain a top-level
    ``limits.composition_wt_pct`` and/or ``limits.mechanical`` block.

    Composition-derived equivalents recognised: ``CE_IIW`` (Mn-base IIW
    equivalent), ``Pcm`` (Ito-Bessyo). If a limit on one of those is
    specified but the value is not in the user's input, it is computed
    from the supplied composition.
    """

    notes: list[str] = []
    failed: list[str] = []
    approx_flag = bool(data.get("approx_data"))

    # --- composition ------------------------------------------------------
    comp_limits = (data.get("limits") or {}).get("composition_wt_pct") or {}
    comp = dict(composition or {})
    for element, bounds in comp_limits.items():
        if element in ("CE_IIW", "Pcm") and element not in comp:
            if element == "CE_IIW":
                derived = _carbon_equivalent_iiw(comp)
            else:
                derived = _pcm(comp)
            if derived is None:
                notes.append(f"{element}: cannot derive from supplied composition — skipped")
                continue
            value = round(derived, 4)
        else:
            value = comp.get(element)
        ok, note = _check_min_max(
            label=element,
            value=value if value is not None else None,
            bounds=bounds,
            unit="wt%" if element not in ("CE_IIW", "Pcm") else "",
            approx=approx_flag,
        )
        notes.append(note)
        if not ok:
            failed.append(note)

    # --- mechanical -------------------------------------------------------
    mech_limits = (data.get("limits") or {}).get("mechanical") or {}
    mech = dict(mechanical or {})
    for prop, bounds in mech_limits.items():
        unit = ""
        if prop.endswith("_MPa"):
            unit = "MPa"
        elif prop.endswith("_pct"):
            unit = "%"
        elif "_J" in prop:
            unit = "J"
        elif prop.endswith("_HV") or prop.endswith("_HB") or prop.endswith("_HRC"):
            unit = prop.rsplit("_", 1)[-1]
        ok, note = _check_min_max(
            label=prop,
            value=mech.get(prop),
            bounds=bounds,
            unit=unit,
            approx=approx_flag,
        )
        notes.append(note)
        if not ok:
            failed.append(note)

    # --- caller-supplied extras (boolean + note) --------------------------
    if extras:
        for ok, note in extras:
            notes.append(note)
            if not ok:
                failed.append(note)

    citation = data.get("citation") or (
        f"{data.get('id', '<unknown>')} ({data.get('edition', '')}) "
        f"{data.get('title', '')}"
    ).strip()

    return StandardVerdict(
        spec_id=data.get("id", "<unknown>"),
        passed=not failed,
        failed_items=failed,
        notes=notes,
        citation=citation,
        title=str(data.get("title", "")),
        edition=str(data.get("edition", "")),
        url=data.get("url"),
    )


# ---------------------------------------------------------------------------
# Dispatcher — id → checker function
# ---------------------------------------------------------------------------


def _import_checker(modname: str) -> Callable[..., StandardVerdict]:
    from importlib import import_module

    mod = import_module(f"austenite.compliance_standards.{modname}")
    return getattr(mod, "check")


# Canonical-id → submodule mapping
_STANDARD_MODULES: dict[str, str] = {
    "DNV-OS-F101": "dnv_os_f101",
    "IMO PSPC (MSC.215(82))": "imo_pspc",
    "JIS G3106": "jis_g3106",
    "GB/T 711": "gbt_711",
    "KS B 0801": "ks_b_0801",
    "AMS 6517": "ams_6517",
    "AMS 6418": "ams_6418",
    "MIL-S-46100": "mil_s_46100",
    "ASTM A576": "astm_a576",
    "ASTM A574": "astm_a574",
}

# Loose aliases
_STANDARD_ALIASES: dict[str, str] = {
    "dnvosf101": "DNV-OS-F101",
    "dnvf101": "DNV-OS-F101",
    "dnv": "DNV-OS-F101",
    "imopspc": "IMO PSPC (MSC.215(82))",
    "pspc": "IMO PSPC (MSC.215(82))",
    "msc21582": "IMO PSPC (MSC.215(82))",
    "lloydspspc": "IMO PSPC (MSC.215(82))",
    "jisg3106": "JIS G3106",
    "g3106": "JIS G3106",
    "sm490": "JIS G3106",
    "gbt711": "GB/T 711",
    "gb711": "GB/T 711",
    "q235": "GB/T 711",
    "q345": "GB/T 711",
    "ksb0801": "KS B 0801",
    "ks0801": "KS B 0801",
    "ams6517": "AMS 6517",
    "ams6418": "AMS 6418",
    "mils46100": "MIL-S-46100",
    "mils46100j": "MIL-S-46100",
    "astma576": "ASTM A576",
    "a576": "ASTM A576",
    "astma574": "ASTM A574",
    "a574": "ASTM A574",
}


def _normalize_standard_id(spec_id: str) -> str:
    if spec_id in _STANDARD_MODULES:
        return spec_id
    key = "".join(ch.lower() for ch in spec_id if ch.isalnum())
    if key in _STANDARD_ALIASES:
        return _STANDARD_ALIASES[key]
    for canonical in _STANDARD_MODULES:
        if canonical.lower() == spec_id.lower():
            return canonical
    raise ValueError(
        f"Unknown standard '{spec_id}'. Known: {sorted(_STANDARD_MODULES.keys())}"
    )


def check_standard(
    spec_id: str,
    *,
    composition: Optional[Mapping[str, float]] = None,
    mechanical: Optional[Mapping[str, float]] = None,
    plugin: Optional[str] = None,
    **kwargs: Any,
) -> Any:
    """Dispatch a per-standard compliance check.

    Resolution order:

      1. If ``spec_id`` matches one of the 10 envelope checkers bundled in
         this package (DNV-OS-F101, JIS G3106, GB/T 711, AMS 6517 …),
         run the envelope check and return a :class:`StandardVerdict`.
      2. Else if ``spec_id`` is in the edition-tracked corpus (API 579-1,
         API 581, ASME II-D, NACE MR0175, ASTM A29), return a stub
         describing the editions — callers should call
         :func:`austenite.compliance.bayesian_p_pass` for a real P(PASS).
      3. Else dispatch to plugins via the ``custom_compliance_check`` hook.
         If ``plugin`` is given, only that plugin is queried.

    Args:
        spec_id: Standard id (e.g. ``"DNV-OS-F101"``, ``"JIS G3106"``).
            Loose aliases (``"sm490"``, ``"pspc"``, ``"q345"`` …) work too.
        composition: Mapping of element → wt%. Optional.
        mechanical: Mapping of property → value. Optional.
        plugin: For plugin dispatch only. Specifies which named plugin
            should answer the check.
        **kwargs: Standard-specific extras (``grade="SM490YA"``,
            ``ballistic={...}``, ``size_class="..."``) forwarded to the
            per-standard checker or plugin hook.

    Returns:
        :class:`StandardVerdict` for envelope-checker hits; a dict
        ``{spec, editions, note}`` for edition-corpus hits; or whatever
        the plugin hook returns.
    """

    # 1. Envelope-checker hit?
    try:
        canonical = _normalize_standard_id(spec_id)
    except ValueError:
        canonical = None

    if canonical is not None:
        checker = _import_checker(_STANDARD_MODULES[canonical])
        return checker(composition=composition, mechanical=mechanical, **kwargs)

    # 2. Edition-corpus hit?
    try:
        from .compliance_editions import list_editions as _list_editions  # type: ignore[import]
    except ImportError:
        # Different import root when imported as a sub-module of austenite
        from austenite.compliance_editions import list_editions as _list_editions  # type: ignore
    try:
        editions = _list_editions(spec_id)
    except Exception:
        editions = []
    if editions:
        return {
            "spec": spec_id,
            "editions": editions,
            "note": (
                "Spec is in the core edition corpus. Use "
                "au.compliance.bayesian_p_pass(...) for an actual P(PASS)."
            ),
        }

    # 3. Plugin fallback
    try:
        from austenite import plugins as _plugins  # type: ignore
    except ImportError:
        return None
    return _plugins.call_hook(plugin, "custom_compliance_check", spec_id, **kwargs)


def list_standards() -> list[str]:
    """Return every spec id this package can answer for, *plus* the ids
    contributed by installed plugins.

    Union of:
      * the 10 envelope-checker ids bundled here, and
      * the 5 edition-tracked ids from ``compliance_editions``, and
      * any spec ids advertised by plugins via the
        ``custom_compliance_check`` hook's ``__compliance_standards__``
        attribute.
    """

    out: set[str] = set(_STANDARD_MODULES.keys())
    try:
        from .compliance_editions import list_specs as _list_specs  # type: ignore[import]
    except ImportError:
        try:
            from austenite.compliance_editions import list_specs as _list_specs  # type: ignore
        except ImportError:
            _list_specs = None  # type: ignore[assignment]
    if _list_specs is not None:
        try:
            out.update(_list_specs())
        except Exception:
            pass
    try:
        from austenite import plugins as _plugins  # type: ignore
        for _name, fn in _plugins.iter_hooks("custom_compliance_check"):
            listed = getattr(fn, "__compliance_standards__", None)
            if listed:
                out.update(listed)
    except Exception:
        pass
    return sorted(out)


def _grade_data(
    data: Mapping[str, Any],
    grade: Optional[str],
) -> tuple[dict[str, Any], str]:
    """Resolve a grade-aware data file into a single ``limits`` block.

    JIS G3106 / GB/T 711 / ASTM A576 all ship a ``grades`` map; the
    per-standard checker picks one grade, copies that grade's
    ``composition_wt_pct`` and ``mechanical`` blocks into a synthesised
    ``limits`` dict, and returns that for ``_run_envelope``.

    Returns ``(synthesised_data, resolved_grade_id)``.
    """

    grades = data.get("grades") or {}
    chosen = grade or data.get("default_grade")
    if not grades:
        return dict(data), str(chosen or "")
    if chosen is None:
        raise ValueError(
            f"{data.get('id', '<unknown>')}: grade is required; one of {sorted(grades)}"
        )
    if chosen not in grades:
        # Try case-insensitive
        lower_map = {k.lower(): k for k in grades}
        canonical = lower_map.get(str(chosen).lower())
        if canonical is None:
            raise ValueError(
                f"{data.get('id', '<unknown>')}: grade '{chosen}' unknown; "
                f"valid grades: {sorted(grades)}"
            )
        chosen = canonical
    block = grades[chosen]
    synth = dict(data)
    synth["limits"] = {
        "composition_wt_pct": dict(block.get("composition_wt_pct") or {}),
        "mechanical": dict(block.get("mechanical") or {}),
    }
    base_cit = data.get("citation") or ""
    if base_cit:
        synth["citation"] = f"{base_cit} — grade {chosen}"
    return synth, str(chosen)


__all__ = [
    "StandardVerdict",
    "check_standard",
    "list_standards",
    "_load_data",
    "_run_envelope",
    "_check_min_max",
    "_carbon_equivalent_iiw",
    "_pcm",
    "_grade_data",
]
