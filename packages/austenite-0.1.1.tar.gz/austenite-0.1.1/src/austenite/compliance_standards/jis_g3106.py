"""JIS G3106 (Rolled steels for welded structure) compliance checker.

Verifies composition + mechanicals against one of the SM-series grades —
SM400A, SM490A, SM490YA, SM520B, SM570.

Example::

    from austenite.compliance_standards import jis_g3106
    v = jis_g3106.check(
        composition={"C": 0.18, "Si": 0.35, "Mn": 1.20, "P": 0.020, "S": 0.015},
        mechanical={"sigma_y_MPa": 360, "sigma_uts_MPa": 530,
                    "elongation_pct": 25, "CVN_J_at_0C": 50},
        grade="SM490A",
    )
"""

from __future__ import annotations

from typing import Any, Mapping, Optional

from . import StandardVerdict, _grade_data, _load_data, _run_envelope


_DATA: Optional[dict[str, Any]] = None


def _data() -> dict[str, Any]:
    global _DATA
    if _DATA is None:
        _DATA = _load_data("jis_g3106.json")
    return _DATA


def check(
    composition: Optional[Mapping[str, float]] = None,
    mechanical: Optional[Mapping[str, float]] = None,
    *,
    grade: Optional[str] = None,
    **_: Any,
) -> StandardVerdict:
    """Return a :class:`StandardVerdict` for JIS G3106.

    Args:
        composition: wt% per element.
        mechanical: ``sigma_y_MPa``, ``sigma_uts_MPa``, ``elongation_pct``,
            ``CVN_J_at_0C`` / ``CVN_J_at_-5C`` etc.
        grade: One of ``"SM400A" | "SM490A" | "SM490YA" | "SM520B" | "SM570"``.
            Default ``"SM490A"``.
    """

    synth, _ = _grade_data(_data(), grade)
    return _run_envelope(
        data=synth,
        composition=composition,
        mechanical=mechanical,
    )


def list_grades() -> list[str]:
    return sorted((_data().get("grades") or {}).keys())


__all__ = ["check", "list_grades"]
