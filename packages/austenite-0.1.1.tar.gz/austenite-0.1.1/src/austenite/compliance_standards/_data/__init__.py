"""Bundled per-standard limits JSON files.

Each JSON file under this directory follows the schema:

    {
      "id":     str,        # Canonical standard id
      "title":  str,
      "publisher": str,
      "edition":   str,
      "scope":     str,
      "limits": {
        "composition_wt_pct": {
          "<Element>": {"min": float?, "max": float?},
          ...
          # Composition-derived keys: "CE_IIW", "Pcm"
        },
        "mechanical": {
          "<property>": {"min": float?, "max": float?},
          ...
        }
      },
      "primary_paper": str,
      "url":   str,
      "citation": str?,
      "approx_data": bool?    # True when values are industry-typical, not
                              # quoted verbatim from the standard.
    }

When ``approx_data`` is true, every per-item note from the envelope
checker is tagged ``[approx]`` so downstream stamp/audit consumers know
the limits are placeholders and should be replaced with copies of the
purchased official standard before sign-off.
"""
