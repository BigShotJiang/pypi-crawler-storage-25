"""MIL-S-46100 (high-hardness wrought armor steel) compliance checker.

Verifies composition + hardness envelope and ballistic V50 protection
for wrought high-hardness rolled-homogeneous armor (RHA) plate.

Example::

    from austenite.compliance_standards import mil_s_46100
    v = mil_s_46100.check(
        composition={"C": 0.30, "Mn": 1.20, "Si": 0.80, "P": 0.010, "S": 0.005,
                     "Cr": 1.50, "Ni": 2.50, "Mo": 0.50},
        mechanical={"hardness_HB": 500, "hardness_HRC": 52,
                    "CVN_J_at_-40C_longitudinal": 20,
                    "CVN_J_at_-40C_transverse": 16},
        ballistic={"v50_m_per_s_per_in_thickness": 560,
                   "back_face_signature_mm": 40, "spall_class": "B"},
    )
"""

from __future__ import annotations

from typing import Any, Mapping, Optional

from . import StandardVerdict, _load_data, _run_envelope


_DATA: Optional[dict[str, Any]] = None


def _data() -> dict[str, Any]:
    global _DATA
    if _DATA is None:
        _DATA = _load_data("mil_s_46100.json")
    return _DATA


def check(
    composition: Optional[Mapping[str, float]] = None,
    mechanical: Optional[Mapping[str, float]] = None,
    *,
    ballistic: Optional[Mapping[str, Any]] = None,
    **_: Any,
) -> StandardVerdict:
    """Return a :class:`StandardVerdict` for MIL-S-46100.

    Args:
        composition: wt% per element. Recognised: C, Mn, Si, P, S, Cr, Ni,
            Mo, B.
        mechanical: ``hardness_HB``, ``hardness_HRC``,
            ``CVN_J_at_-40C_longitudinal``, ``CVN_J_at_-40C_transverse``.
        ballistic: optional ``{v50_m_per_s_per_in_thickness,
            back_face_signature_mm, spall_class}``.
    """

    extras: list[tuple[bool, str]] = []
    if ballistic:
        bspec = (_data().get("ballistic_requirements") or {})
        v50_req = bspec.get("v50_protection_min_m_per_s_per_in_thickness")
        bfs_max = bspec.get("back_face_signature_max_mm")
        spall = bspec.get("spall_class")

        if v50_req is not None and "v50_m_per_s_per_in_thickness" in ballistic:
            v50 = float(ballistic["v50_m_per_s_per_in_thickness"])
            ok = v50 >= float(v50_req)
            extras.append((
                ok,
                (
                    f"V50 = {v50} m/s/in ≥ required {v50_req} [approx]"
                    if ok
                    else f"V50 = {v50} m/s/in below required {v50_req} [approx]"
                ),
            ))
        if bfs_max is not None and "back_face_signature_mm" in ballistic:
            bfs = float(ballistic["back_face_signature_mm"])
            ok = bfs <= float(bfs_max)
            extras.append((
                ok,
                (
                    f"back_face_signature = {bfs} mm ≤ max {bfs_max} [approx]"
                    if ok
                    else f"back_face_signature = {bfs} mm exceeds max {bfs_max} [approx]"
                ),
            ))
        if spall is not None and "spall_class" in ballistic:
            ok = str(ballistic["spall_class"]).upper() <= str(spall).upper()
            extras.append((
                ok,
                (
                    f"spall_class = '{ballistic['spall_class']}' meets requirement '{spall}' [approx]"
                    if ok
                    else f"spall_class = '{ballistic['spall_class']}' below required '{spall}' [approx]"
                ),
            ))

    return _run_envelope(
        data=_data(),
        composition=composition,
        mechanical=mechanical,
        extras=extras,
    )


__all__ = ["check"]
