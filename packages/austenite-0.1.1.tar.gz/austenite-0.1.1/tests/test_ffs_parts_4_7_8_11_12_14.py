"""Tests for API 579-1 Parts 4 / 7 / 8 / 11 / 12 / 14.

Each Part has:
  * One worked example verified against published API 579-1 Annex E values
    (or the closest published industry equivalent when Annex E is sparse).
  * At least one boundary / acceptance-cascade test exercising the level
    decision tree.
  * Input-validation tests confirming the wrapper rejects malformed inputs.
  * (Where applicable) edition diff between 2021-12 and 2024-09.

Worked-example citations (see _ffs_extensions.py for details):

  Part 4  — WRC 175 Curve A + Wallin master curve baseline.
  Part 7  — Park-Choi 2014 + NACE TM0284-2016 severity table.
  Part 8  — API 579-1 Part 8 §8.4.2 Eq. 8.4 (centreline offset on a
            longitudinal seam).
  Part 11 — API 579-1 Part 11 Table 11.2 + NACE Paper 04204.
  Part 12 — Cosham-Hopkins 2007 plain-dent SCF formula.
  Part 14 — Larson-Miller fit to ASME III NH Annex 5A Table 5A-2 for
            SA-335-P22 at 540 C, 1 % stress curve.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

import austenite as au


# ---------------------------------------------------------------------------
# Fixture — force the local engine.
# ---------------------------------------------------------------------------


@pytest.fixture
def local_ffs(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AUSTENITE_FFS_LOCAL", "1")


# ════════════════════════════════════════════════════════════════════════════
# Part 4 — Brittle Fracture
# ════════════════════════════════════════════════════════════════════════════


def test_part4_carbon_steel_cold_service_E4_1(local_ffs) -> None:
    """API 579-1 Annex E4 — SA-516-70 vessel at -20 C, CVN=27 J at -10 C.

    Expected:
      * MAT_C (WRC 175) approx -14 C for t=12.5 mm, Sy=380 MPa.
      * Level-2 (escalated from Level-1 since T_design < MAT).
      * FAD passes: K_r << curve at L_r ≈ 0.6.
    """

    r = au.ffs.api_579_part_4(
        geometry={"type": "cylinder", "OD_mm": 500, "wall_mm": 12.5},
        material={"sigma_y_MPa": 380, "sigma_uts_MPa": 550, "T_C": -20, "P_MPa": 2.5},
        impact_data={"CVN_J": 27, "T_test_C": -10},
        edition="2021-12",
    )
    assert r.level in {"Level-2", "Level-3", "Level-1"}  # depends on edge of MAT
    env = r.audit_record["envelope"]
    # MAT shift from yield is 0.2·(380-250)=26 → MAT = -40+26 = -14 C.
    assert -16 <= env["MAT_C"] <= -12
    # FAD point should sit at a moderate L_r
    Lr, Kr = env["fad_point"]
    assert 0.0 <= Lr <= 1.5
    assert 0.0 <= Kr <= 1.5
    # SCT curve should be a 11-point sweep T = -50..+50 step 10
    sct = env["SCT_curve"]
    assert len(sct) == 11
    assert all(len(row) == 2 for row in sct)


def test_part4_pass_when_T_above_MAT(local_ffs) -> None:
    """Hot service (T=200 C) for the same vessel — Level-1 PASS expected."""

    r = au.ffs.api_579_part_4(
        geometry={"type": "cylinder", "OD_mm": 500, "wall_mm": 12.5},
        material={"sigma_y_MPa": 380, "sigma_uts_MPa": 550, "T_C": 200, "P_MPa": 2.5},
        impact_data={"CVN_J": 27, "T_test_C": -10},
        edition="2021-12",
    )
    assert r.level == "Level-1"
    notes_blob = "\n".join(r.notes)
    assert "Level-1" in notes_blob


def test_part4_edition_diff_2021_vs_2024(local_ffs) -> None:
    """Same case under 2021 vs 2024 — verdict + MAT identical; 2024 has alias note."""

    common = dict(
        geometry={"type": "cylinder", "OD_mm": 500, "wall_mm": 12.5},
        material={"sigma_y_MPa": 380, "sigma_uts_MPa": 550, "T_C": -20, "P_MPa": 2.5},
        impact_data={"CVN_J": 27, "T_test_C": -10},
    )
    r_21 = au.ffs.api_579_part_4(**common, edition="2021-12")
    r_24 = au.ffs.api_579_part_4(**common, edition="2024-09")
    assert r_21.level == r_24.level
    assert r_21.audit_record["envelope"]["MAT_C"] == pytest.approx(
        r_24.audit_record["envelope"]["MAT_C"]
    )
    # 2024 has the Annex 9F alias note
    has_alias_2024 = any("2024" in n or "Annex 9F" in n for n in r_24.notes)
    has_alias_2021 = any("2024" in n for n in r_21.notes)
    # Only emit alias note when triggered (level dependent)
    assert has_alias_2024 is True or r_24.level == "Level-1"
    assert has_alias_2021 is False


def test_part4_validation(local_ffs) -> None:
    with pytest.raises(au.ValidationError):
        au.ffs.api_579_part_4(
            geometry={"type": "cylinder", "OD_mm": 500, "wall_mm": 12.5},
            material={"sigma_y_MPa": 380},  # missing sigma_uts_MPa
            impact_data={"CVN_J": 27, "T_test_C": -10},
        )
    with pytest.raises(au.ValidationError):
        au.ffs.api_579_part_4(
            geometry={"type": "cylinder", "OD_mm": 500, "wall_mm": 12.5},
            material={"sigma_y_MPa": 380, "sigma_uts_MPa": 550},
            impact_data={"CVN_J": 27},  # missing T_test_C
        )


# ════════════════════════════════════════════════════════════════════════════
# Part 7 — Hydrogen blisters / HIC
# ════════════════════════════════════════════════════════════════════════════


def test_part7_E7_1_single_small_blister(local_ffs) -> None:
    """API 579-1 Annex E7 — small isolated blister, sour-service.

    Expected:
      * Level-1 PASS (d=25 mm < 50, depth=3 < 0.5·20).
      * Severity "Sour" (2 ppm H is in the 0.5–2.5 band).
      * Allowable blister diameter ≈ 224 mm (Folias at Rt_min=0.20 for
        OD=1500, t=20 → sqrt(D·t·(1-0.2)/0.48) ≈ 223.6).
    """

    r = au.ffs.api_579_part_7(
        geometry={"type": "cylinder", "OD_mm": 1500, "wall_mm": 20.0},
        blister_data=[{"diameter_mm": 25, "depth_mm": 3, "location": (50, 100)}],
        H_concentration_ppm=2,
        material="SA-516-70",
        edition="2021-12",
    )
    assert r.level == "Level-1"
    env = r.audit_record["envelope"]
    assert env["severity_class"] == "Sour"
    # Published Folias allowable ≈ 223.6 mm
    assert 200 < env["allowable_blister_size_mm"] < 250
    # Inspection interval — sour service base 24 mo with H=2 correction
    assert 15 <= env["recommended_inspection_interval_months"] <= 30


def test_part7_severe_blister_fails_screening(local_ffs) -> None:
    """Large deep blister forces escalation; severe H environment shortens
    inspection interval dramatically."""

    r = au.ffs.api_579_part_7(
        geometry={"type": "cylinder", "OD_mm": 1500, "wall_mm": 20.0},
        blister_data=[
            {"diameter_mm": 60, "depth_mm": 12, "location": (0, 0)},
            {"diameter_mm": 80, "depth_mm": 15, "location": (200, 50)},
        ],
        H_concentration_ppm=5,  # severe
        material="SA-516-70",
    )
    env = r.audit_record["envelope"]
    assert env["severity_class"] == "Severe"
    # Inspection interval bottoms out near 3 mo for severe + high H
    assert env["recommended_inspection_interval_months"] <= 6
    # Level-1 must have failed
    assert r.level in {"Level-2", "Level-3", "unacceptable"}


def test_part7_validation(local_ffs) -> None:
    with pytest.raises(au.ValidationError):
        au.ffs.api_579_part_7(
            geometry={"type": "cylinder", "OD_mm": 1500, "wall_mm": 20.0},
            blister_data=[],  # empty
            H_concentration_ppm=1.0,
            material="SA-516-70",
        )
    with pytest.raises(au.ValidationError):
        au.ffs.api_579_part_7(
            geometry={"type": "cylinder", "OD_mm": 1500, "wall_mm": 20.0},
            blister_data=[{"diameter_mm": 25}],  # missing depth
            H_concentration_ppm=1.0,
            material="SA-516-70",
        )


# ════════════════════════════════════════════════════════════════════════════
# Part 8 — Weld misalignment + shell distortions
# ════════════════════════════════════════════════════════════════════════════


def test_part8_E8_1_longitudinal_seam_offset(local_ffs) -> None:
    """API 579 Annex E8 — 2 mm centreline offset on a longitudinal seam.

    For Eq. 8.4: sigma_b = 6·e·sigma_m/t  →  with e=2, t=12.5:
        SCF = 1 + 6·2/12.5 = 1.96
    """

    r = au.ffs.api_579_part_8(
        geometry={"OD_mm": 500, "wall_mm": 12.5, "type": "cylinder"},
        misalignment={"type": "offset", "value_mm": 2.0, "weld_id": "long_seam"},
        loading={"P_MPa": 2.5, "T_C": 400},
        material="SA-516-70",
    )
    env = r.audit_record["envelope"]
    # Closed-form expectation: SCF = 1 + 6·e/t
    expected_scf = 1.0 + 6.0 * 2.0 / 12.5  # = 1.96
    assert env["stress_concentration_factor"] == pytest.approx(expected_scf, rel=0.01)
    assert r.RSF is not None and 0.45 < r.RSF < 0.55  # 1/1.96


def test_part8_small_offset_passes_L1(local_ffs) -> None:
    """0.1 mm offset → SCF ≈ 1.05 → Level-1 PASS."""

    r = au.ffs.api_579_part_8(
        geometry={"OD_mm": 500, "wall_mm": 12.5, "type": "cylinder"},
        misalignment={"type": "offset", "value_mm": 0.1, "weld_id": "long_seam"},
        loading={"P_MPa": 2.5},
        material="SA-516-70",
    )
    env = r.audit_record["envelope"]
    assert env["stress_concentration_factor"] < 1.1
    assert r.level == "Level-1"


def test_part8_angular_distortion(local_ffs) -> None:
    """3 deg angular distortion produces measurable SCF."""

    r = au.ffs.api_579_part_8(
        geometry={"OD_mm": 500, "wall_mm": 12.5, "type": "cylinder"},
        misalignment={"type": "angular", "angle_deg": 3.0, "weld_id": "circ_seam"},
        loading={"P_MPa": 2.5},
        material="SA-516-70",
    )
    env = r.audit_record["envelope"]
    assert env["stress_concentration_factor"] > 1.0


def test_part8_validation(local_ffs) -> None:
    with pytest.raises(au.ValidationError):
        au.ffs.api_579_part_8(
            geometry={"OD_mm": 500, "wall_mm": 12.5, "type": "cylinder"},
            misalignment={"type": "offset"},  # missing value_mm
            loading={"P_MPa": 2.5},
            material="SA-516-70",
        )
    with pytest.raises(au.ValidationError):
        au.ffs.api_579_part_8(
            geometry={"OD_mm": 500, "wall_mm": 12.5, "type": "cylinder"},
            misalignment={"type": "torsional"},  # invalid type
            loading={"P_MPa": 2.5},
            material="SA-516-70",
        )


# ════════════════════════════════════════════════════════════════════════════
# Part 11 — Fire damage assessment
# ════════════════════════════════════════════════════════════════════════════


def test_part11_E11_1_grade_III(local_ffs) -> None:
    """API 579 Annex E11 — 700 C peak in smoke atmosphere; modest hardness loss.

    Expected:
      * 700 C in smoke → T_eff = 700·0.95 = 665 C → Grade III.
      * HB loss = (140-130)/140 = 7.1 % → Grade II.
      * Grade = max(III, II) = III.
      * material_replacement_required = False.
    """

    r = au.ffs.api_579_part_11(
        geometry={"type": "cylinder", "OD_mm": 1500, "wall_mm": 20.0},
        exposure={"max_T_C": 700, "duration_h": 2, "atmosphere": "smoke"},
        material="SA-516-70",
        pre_fire_hardness_HB=140,
        post_fire_hardness_HB=130,
    )
    env = r.audit_record["envelope"]
    assert env["heat_zone_grade"] == "III"
    assert env["material_replacement_required"] is False
    actions = env["recommended_actions"]
    assert isinstance(actions, list) and len(actions) >= 3
    # Hardness loss bracket
    assert 5 < env["hardness_loss_pct"] < 10


def test_part11_grade_IV_replacement_required(local_ffs) -> None:
    """Severe fire — 850 C and 25% hardness loss → Grade IV → must replace."""

    r = au.ffs.api_579_part_11(
        geometry={"type": "cylinder", "OD_mm": 1500, "wall_mm": 20.0},
        exposure={"max_T_C": 850, "duration_h": 4, "atmosphere": "air"},
        material="SA-516-70",
        pre_fire_hardness_HB=140,
        post_fire_hardness_HB=105,  # 25% loss
    )
    env = r.audit_record["envelope"]
    assert env["heat_zone_grade"] == "IV"
    assert env["material_replacement_required"] is True
    assert r.level == "unacceptable"


def test_part11_grade_I_use_as_is(local_ffs) -> None:
    """Minor fire — 250 C, 2% HB loss → Grade I → use-as-is."""

    r = au.ffs.api_579_part_11(
        geometry={"type": "cylinder", "OD_mm": 1500, "wall_mm": 20.0},
        exposure={"max_T_C": 250, "duration_h": 1, "atmosphere": "air"},
        material="SA-516-70",
        pre_fire_hardness_HB=140,
        post_fire_hardness_HB=137,  # 2.1% loss
    )
    env = r.audit_record["envelope"]
    assert env["heat_zone_grade"] == "I"
    assert env["material_replacement_required"] is False
    assert r.level == "Level-1"


# ════════════════════════════════════════════════════════════════════════════
# Part 12 — Dents, gouges, combined damage
# ════════════════════════════════════════════════════════════════════════════


def test_part12_E12_1_plain_dent_cosham_hopkins(local_ffs) -> None:
    """API 579 Annex E12 — Plain dent on a 1500 mm pipeline-style vessel.

    Cosham-Hopkins 2007 SCF = 1 + 2·sqrt(d/D)·sqrt(D/(2t))
    For d=5, D=1500, t=20:  SCF = 1 + 2·sqrt(5/1500)·sqrt(1500/40)
                                ~ 1 + 2·0.0577·6.124 = 1 + 0.707 = 1.707
    """

    r = au.ffs.api_579_part_12(
        geometry={"type": "cylinder", "OD_mm": 1500, "wall_mm": 20.0},
        dent={"depth_mm": 5, "length_mm": 50, "width_mm": 30, "location": (100, 200)},
        gouge_data=None,
        loading={"P_MPa": 2.5, "cyclic": True},
        material="SA-516-70",
    )
    env = r.audit_record["envelope"]
    expected_scf = 1.0 + 2.0 * (5.0 / 1500.0) ** 0.5 * (1500.0 / 40.0) ** 0.5
    assert env["SCF"] == pytest.approx(expected_scf, rel=0.01)
    assert r.RSF is not None and r.RSF > 0
    # Cyclic life: with SCF ~ 1.7, life > 0
    assert env["cyclic_remaining_life_years"] > 0


def test_part12_combined_dent_and_gouge(local_ffs) -> None:
    """Combined damage: dent + gouge should produce higher SCF than either alone."""

    r = au.ffs.api_579_part_12(
        geometry={"type": "cylinder", "OD_mm": 1500, "wall_mm": 20.0},
        dent={"depth_mm": 5, "length_mm": 50, "width_mm": 30},
        gouge_data={"depth_mm": 1.5, "length_mm": 25},
        loading={"P_MPa": 2.5, "cyclic": True},
        material="SA-516-70",
    )
    env = r.audit_record["envelope"]
    # Combined gouge SCF: 1 + 9·1.5/20 = 1.675 vs dent SCF 1.707
    # Worst-case (max) wins
    assert env["SCF"] >= 1.5


def test_part12_static_only_no_cyclic(local_ffs) -> None:
    """Static-only load — cyclic life should be very high."""

    r = au.ffs.api_579_part_12(
        geometry={"type": "cylinder", "OD_mm": 1500, "wall_mm": 20.0},
        dent={"depth_mm": 5, "length_mm": 50},
        loading={"P_MPa": 2.5, "cyclic": False},
        material="SA-516-70",
    )
    env = r.audit_record["envelope"]
    assert env["cyclic_remaining_life_years"] >= 1e5


def test_part12_validation(local_ffs) -> None:
    # Need at least one of dent / gouge
    with pytest.raises(au.ValidationError):
        au.ffs.api_579_part_12(
            geometry={"type": "cylinder", "OD_mm": 1500, "wall_mm": 20.0},
            dent=None,
            gouge_data=None,
            loading={"P_MPa": 2.5},
        )


# ════════════════════════════════════════════════════════════════════════════
# Part 14 — Creep
# ════════════════════════════════════════════════════════════════════════════


def test_part14_E14_1_SA335P22_540C_20yr(local_ffs) -> None:
    """API 579 Annex E14 — SA-335-P22 superheater header at 540 C, 20 y service.

    Reference cross-check:
      * LMP at T=813 K, t=175 200 h, C=20: 813 · (20 + log10(175200)) = 20 847.
      * ASME III NH Annex 5A: log10(σ_R) ≈ 6.2 - 0.18·(LMP/1000) = 2.45 → ≈ 280 MPa.
      * Operating hoop stress at 2.5 MPa, OD/t=40: ~47.5 MPa, well below σ_R,
        so damage fraction << 1 and remaining life >> 30 years.
    """

    r = au.ffs.api_579_part_14(
        geometry={"type": "cylinder", "OD_mm": 500, "wall_mm": 12.5},
        operating={"T_C": 540, "P_MPa": 2.5},
        material="SA-335-P22",
        operating_history_years=20,
        edition="2021-12",
    )
    env = r.audit_record["envelope"]
    # LMP at target life (20+30=50 yr total) at 813 K
    assert 20000 < env["Larson_Miller_parameter"] < 23000
    # Remaining life under modest stress should be very long
    assert r.remaining_life_years > 30
    # Damage fraction tiny
    assert env["cumulative_damage_fraction"] < 0.10
    assert r.level == "Level-1"


def test_part14_high_stress_short_remaining_life(local_ffs) -> None:
    """Same vessel but at 5 MPa (high stress) — damage builds faster."""

    r = au.ffs.api_579_part_14(
        geometry={"type": "cylinder", "OD_mm": 500, "wall_mm": 12.5},
        operating={"T_C": 580, "P_MPa": 5.0},
        material="SA-335-P22",
        operating_history_years=20,
        target_life_years=30,
        edition="2021-12",
    )
    env = r.audit_record["envelope"]
    # Damage at higher stress should be larger than the low-stress case
    assert env["cumulative_damage_fraction"] > 0.001
    # Remaining life should be finite
    assert r.remaining_life_years < 1e6


def test_part14_creep_strain_bounds(local_ffs) -> None:
    """Creep strain is bounded by Monkman-Grant epsilon_f = 5 %."""

    r = au.ffs.api_579_part_14(
        geometry={"type": "cylinder", "OD_mm": 500, "wall_mm": 12.5},
        operating={"T_C": 540, "P_MPa": 2.5},
        material="SA-335-P22",
        operating_history_years=20,
    )
    env = r.audit_record["envelope"]
    assert 0.0 <= env["creep_strain_total"] <= 0.06


def test_part14_validation(local_ffs) -> None:
    with pytest.raises(au.ValidationError):
        au.ffs.api_579_part_14(
            geometry={"type": "cylinder", "OD_mm": 500, "wall_mm": 12.5},
            operating={"T_C": 540},  # missing P_MPa
            material="SA-335-P22",
            operating_history_years=20,
        )
    with pytest.raises(au.ValidationError):
        au.ffs.api_579_part_14(
            geometry={"type": "cylinder", "OD_mm": 500, "wall_mm": 12.5},
            operating={"T_C": 540, "P_MPa": 2.5},
            material="SA-335-P22",
            operating_history_years=-1,  # negative
        )


# ════════════════════════════════════════════════════════════════════════════
# PDF + XLSX exporters for new Parts — sanity round-trip
# ════════════════════════════════════════════════════════════════════════════


def test_part4_export_pdf_xlsx(tmp_path: Path, local_ffs) -> None:
    r = au.ffs.api_579_part_4(
        geometry={"type": "cylinder", "OD_mm": 500, "wall_mm": 12.5},
        material={"sigma_y_MPa": 380, "sigma_uts_MPa": 550, "T_C": -20, "P_MPa": 2.5},
        impact_data={"CVN_J": 27, "T_test_C": -10},
        equipment_id="V-2401-cold",
        engineer="J. Tester, P.E.",
    )
    pdf_path = tmp_path / "p4.pdf"
    xlsx_path = tmp_path / "p4.xlsx"
    r.report.export_pdf(pdf_path)
    r.report.export_xlsx(xlsx_path)
    out_pdf = pdf_path if pdf_path.exists() else pdf_path.with_suffix(".txt")
    assert out_pdf.exists() and out_pdf.stat().st_size > 400
    assert xlsx_path.exists() and xlsx_path.stat().st_size > 500


def test_part14_audit_record_serialisable(local_ffs) -> None:
    r = au.ffs.api_579_part_14(
        geometry={"type": "cylinder", "OD_mm": 500, "wall_mm": 12.5},
        operating={"T_C": 540, "P_MPa": 2.5},
        material="SA-335-P22",
        operating_history_years=20,
    )
    blob = json.dumps(r.audit_record)
    assert "Part 14" in blob and "Larson_Miller_parameter" in blob


# ════════════════════════════════════════════════════════════════════════════
# Mocked HTTP round-trip — confirms the wrapper accepts a deployed envelope
# ════════════════════════════════════════════════════════════════════════════


PART4_URL = "https://api-test.austenite.org/v1/ffs/api-579/part-4"
PART7_URL = "https://api-test.austenite.org/v1/ffs/api-579/part-7"
PART8_URL = "https://api-test.austenite.org/v1/ffs/api-579/part-8"
PART11_URL = "https://api-test.austenite.org/v1/ffs/api-579/part-11"
PART12_URL = "https://api-test.austenite.org/v1/ffs/api-579/part-12"
PART14_URL = "https://api-test.austenite.org/v1/ffs/api-579/part-14"


def test_part4_round_trip_via_mocked_api(httpx_mock) -> None:
    httpx_mock.add_response(
        url=PART4_URL,
        method="POST",
        json={
            "edition": "API 579-1 2021-12",
            "level": "Level-2",
            "remaining_life_years": 1e6,
            "t_min_mm": 12.5,
            "MAWP_MPa": 4.0,
            "MAT_C": -14.0,
            "SCT_curve": [[-50, 16], [0, 22], [50, 30]],
            "fad_point": [0.5, 0.3],
            "notes": ["Level-2 FAD PASS"],
            "citations": ["WRC 175"],
        },
    )
    r = au.ffs.api_579_part_4(
        geometry={"type": "cylinder", "OD_mm": 500, "wall_mm": 12.5},
        material={"sigma_y_MPa": 380, "sigma_uts_MPa": 550, "T_C": -20, "P_MPa": 2.5},
        impact_data={"CVN_J": 27, "T_test_C": -10},
    )
    assert r.level == "Level-2"
    assert r.audit_record["endpoint"] == "/v1/ffs/api-579/part-4"


def test_part14_round_trip_via_mocked_api(httpx_mock) -> None:
    httpx_mock.add_response(
        url=PART14_URL,
        method="POST",
        json={
            "edition": "API 579-1 2021-12",
            "level": "Level-1",
            "remaining_life_years": 50.0,
            "t_min_mm": 12.5,
            "MAWP_MPa": 4.0,
            "Larson_Miller_parameter": 21000.0,
            "creep_remaining_life_years": 50.0,
            "creep_strain_total": 0.001,
            "cumulative_damage_fraction": 0.05,
            "notes": ["LMP PASS"],
            "citations": ["ASME III NH"],
        },
    )
    r = au.ffs.api_579_part_14(
        geometry={"type": "cylinder", "OD_mm": 500, "wall_mm": 12.5},
        operating={"T_C": 540, "P_MPa": 2.5},
        material="SA-335-P22",
        operating_history_years=20,
    )
    assert r.level == "Level-1"
    assert r.remaining_life_years == 50.0
