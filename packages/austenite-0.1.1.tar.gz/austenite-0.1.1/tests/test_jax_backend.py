"""Tests for the JAX-differentiable backend.

These tests skip cleanly if JAX is not installed -- the optional-extra
guard in ``austenite.jax_backend.__init__`` raises ``ImportError`` with
a clear hint and the test module simply ``pytest.skip``s.
"""

from __future__ import annotations

import math

import pytest


jax = pytest.importorskip("jax")
jnp = pytest.importorskip("jax.numpy")
import austenite as au  # noqa: E402


# ---------------------------------------------------------------------------
# AISI 4140-like composition fixture
# ---------------------------------------------------------------------------

# C, Mn, Cr, Mo, Ni, Si, V  -- midpoint of the 4140 spec band
COMP_4140 = jnp.array([0.40, 0.85, 0.95, 0.20, 0.0, 0.25, 0.0], dtype=jnp.float32)
COMP_4140_SHORT = jnp.array([0.40, 0.85, 0.95, 0.20, 0.0], dtype=jnp.float32)


# ---------------------------------------------------------------------------
# 1. Importability + happy-path
# ---------------------------------------------------------------------------


def test_jax_backend_imports_top_level() -> None:
    """``au.jax_backend`` is reachable via the public namespace."""

    backend = au.jax_backend  # type: ignore[attr-defined]
    assert hasattr(backend, "design_path_jax")
    assert hasattr(backend, "maynier_hv30")
    assert hasattr(backend, "design_jax")


def test_design_path_jax_returns_pytree() -> None:
    r = au.design_path_jax(COMP_4140, cooling_rate=10.0, sigma_app_MPa=500.0)
    # All fields are JAX arrays
    assert isinstance(r.hv30, jnp.ndarray)
    assert isinstance(r.sigma_y_MPa, jnp.ndarray)
    assert isinstance(r.sigma_uts_MPa, jnp.ndarray)
    assert isinstance(r.KIc_MPa_sqm, jnp.ndarray)
    assert isinstance(r.sigma_endurance_MPa, jnp.ndarray)
    assert isinstance(r.fatigue.utilisation_pct, jnp.ndarray)
    assert isinstance(r.fatigue.Nf_cycles, jnp.ndarray)
    # Sanity ranges
    assert 100.0 < float(r.hv30) < 800.0
    assert 0.0 < float(r.sigma_y_MPa) < 3000.0
    assert 0.0 < float(r.sigma_uts_MPa) < 3000.0
    assert 0.0 < float(r.KIc_MPa_sqm) < 2000.0


def test_design_path_jax_accepts_short_composition() -> None:
    """Short vectors are zero-padded."""

    r_full = au.design_path_jax(COMP_4140, cooling_rate=10.0)
    r_short = au.design_path_jax(COMP_4140_SHORT, cooling_rate=10.0)
    # Si=0.25 in COMP_4140 changes HV; this is just a presence check
    # that the short call did not crash.
    assert math.isfinite(float(r_short.hv30))
    assert math.isfinite(float(r_full.hv30))


# ---------------------------------------------------------------------------
# 2. Gradient: finiteness + sign
# ---------------------------------------------------------------------------


def test_grad_design_path_finite() -> None:
    """``jax.grad`` returns a finite gradient over the chain."""

    def obj(c):
        return au.design_path_jax(c, cooling_rate=10.0, sigma_app_MPa=500.0).fatigue.utilisation_pct

    g = jax.grad(obj)(COMP_4140_SHORT)
    assert g.shape == COMP_4140_SHORT.shape
    assert bool(jnp.all(jnp.isfinite(g)))
    assert float(jnp.linalg.norm(g)) > 0.0


def test_grad_sigma_y_positive_in_C_for_4140() -> None:
    """For 4140 chemistry, increasing C must increase sigma_y -> dSy/dC > 0."""

    def obj(c):
        return au.design_path_jax(c, cooling_rate=10.0, sigma_app_MPa=500.0).sigma_y_MPa

    g = jax.grad(obj)(COMP_4140_SHORT)
    # Carbon is index 0
    assert float(g[0]) > 0.0, f"expected dSy/dC > 0, got {float(g[0])}"


def test_grad_utilisation_negative_in_C_for_4140() -> None:
    """Raising C strengthens the steel -> lowers fatigue utilisation."""

    def obj(c):
        return au.design_path_jax(c, cooling_rate=10.0, sigma_app_MPa=500.0).fatigue.utilisation_pct

    g = jax.grad(obj)(COMP_4140_SHORT)
    assert float(g[0]) < 0.0, f"expected dUtil/dC < 0, got {float(g[0])}"


# ---------------------------------------------------------------------------
# 3. Chain-rule consistency: small perturbation matches gradient*delta
# ---------------------------------------------------------------------------


def test_chain_rule_finite_difference_matches_grad() -> None:
    """For a small composition perturbation, the linearised prediction
    g.dx should match the actual delta in sigma_y within 5 %."""

    def obj(c):
        return au.design_path_jax(c, cooling_rate=10.0, sigma_app_MPa=500.0).sigma_y_MPa

    grad_fn = jax.grad(obj)
    g = grad_fn(COMP_4140_SHORT)
    # 1 % step in carbon (~0.004 wt%)
    delta = jnp.array([0.004, 0.0, 0.0, 0.0, 0.0], dtype=jnp.float32)
    f0 = float(obj(COMP_4140_SHORT))
    f1 = float(obj(COMP_4140_SHORT + delta))
    fd = f1 - f0
    linear = float(jnp.dot(g, delta))
    rel_err = abs(fd - linear) / max(abs(fd), 1e-9)
    assert rel_err < 0.05, (
        f"finite-diff {fd:.4f} vs grad-dot {linear:.4f} differ by {rel_err:.2%}"
    )


# ---------------------------------------------------------------------------
# 4. JIT equivalence -- jitted and non-jitted versions agree
# ---------------------------------------------------------------------------


def test_jit_matches_eager() -> None:
    """The function is already JIT-decorated; calling it explicitly
    through jax.jit (which is a no-op for an already-jitted callable)
    must produce the same numbers."""

    eager = au.design_path_jax(COMP_4140, cooling_rate=10.0, sigma_app_MPa=500.0)
    fn = jax.jit(au.design_path_jax)
    jitted = fn(COMP_4140, jnp.float32(10.0), jnp.float32(500.0))
    # Tolerance: float32 round-trip
    for k in ("hv30", "sigma_y_MPa", "sigma_uts_MPa", "KIc_MPa_sqm", "sigma_endurance_MPa"):
        a = float(getattr(eager, k))
        b = float(getattr(jitted, k))
        assert abs(a - b) <= max(1e-3, 1e-4 * abs(a)), f"{k}: eager {a} vs jit {b}"


# ---------------------------------------------------------------------------
# 5. vmap -- batch of 100 compositions runs without error
# ---------------------------------------------------------------------------


def test_vmap_over_batch_of_100() -> None:
    key = jax.random.PRNGKey(0)
    # 100 random 4140-like comps with small noise around the centre
    noise = 0.05 * jax.random.normal(key, (100, 7))
    batch = jnp.clip(jnp.tile(COMP_4140, (100, 1)) + noise, 0.0, 2.0)

    fn = jax.vmap(
        lambda c: au.design_path_jax(c, cooling_rate=jnp.float32(10.0)),
        in_axes=0,
    )
    out = fn(batch)
    assert out.hv30.shape == (100,)
    assert out.sigma_y_MPa.shape == (100,)
    assert bool(jnp.all(jnp.isfinite(out.hv30)))
    assert bool(jnp.all(jnp.isfinite(out.sigma_y_MPa)))


# ---------------------------------------------------------------------------
# 6. NaN safety -- random comp in [0, 0.05] (trace ranges) is finite
# ---------------------------------------------------------------------------


def test_nan_free_on_trace_element_compositions() -> None:
    """Trace-element compositions (every wt% in [0, 0.05]) must
    produce finite outputs and gradients."""

    key = jax.random.PRNGKey(42)
    samples = 0.05 * jax.random.uniform(key, (32, 7))

    fn = jax.vmap(lambda c: au.design_path_jax(c, cooling_rate=jnp.float32(10.0)))
    out = fn(samples)
    assert bool(jnp.all(jnp.isfinite(out.hv30)))
    assert bool(jnp.all(jnp.isfinite(out.sigma_y_MPa)))
    assert bool(jnp.all(jnp.isfinite(out.KIc_MPa_sqm)))
    assert bool(jnp.all(jnp.isfinite(out.fatigue.utilisation_pct)))

    # Also gradients
    def obj(c):
        return au.design_path_jax(c, cooling_rate=jnp.float32(10.0)).sigma_y_MPa

    g_fn = jax.vmap(jax.grad(obj))
    g = g_fn(samples)
    assert bool(jnp.all(jnp.isfinite(g)))


# ---------------------------------------------------------------------------
# 7. Individual engines
# ---------------------------------------------------------------------------


def test_pavlina_tyne_matches_reference() -> None:
    """sigma_y = 2.876 * 400 - 90.7 = 1059.7 MPa."""

    from austenite.jax_backend import pavlina_tyne_sigma_y

    assert float(pavlina_tyne_sigma_y(jnp.float32(400.0))) == pytest.approx(1059.7, rel=1e-3)


def test_barsom_rolfe_matches_reference() -> None:
    """For E=207 GPa and CVN=100 J: KIc = sqrt(5*207000*100/1000) ~= 321.7 MPa sqrt(m)."""

    from austenite.jax_backend import barsom_rolfe_KIc

    kic = float(barsom_rolfe_KIc(jnp.float32(100.0)))
    assert kic == pytest.approx(math.sqrt(5 * 207_000 * 100 / 1000), rel=1e-3)


def test_hall_petch_matches_reference() -> None:
    """sigma_y = 150 + 600/sqrt(25) = 150 + 120 = 270 MPa for 25 um grains."""

    from austenite.jax_backend import hall_petch_sigma_y

    val = float(hall_petch_sigma_y(jnp.float32(25.0)))
    assert val == pytest.approx(150 + 600 / 5.0, rel=1e-3)


def test_hall_petch_grad_negative_in_d() -> None:
    """Bigger grains -> lower yield. dSy/dd should be < 0."""

    from austenite.jax_backend import hall_petch_sigma_y

    g = jax.grad(hall_petch_sigma_y)(jnp.float32(25.0))
    assert float(g) < 0


def test_goodman_utilisation_at_endurance_line() -> None:
    """At sigma_a == sigma_e and sigma_m == 0, utilisation == 1.0."""

    from austenite.jax_backend import goodman_utilisation

    u = float(
        goodman_utilisation(
            jnp.float32(300.0), jnp.float32(0.0), jnp.float32(300.0), jnp.float32(1000.0)
        )
    )
    assert u == pytest.approx(1.0, rel=1e-3)


def test_goodman_utilisation_increases_with_mean_stress() -> None:
    """dU/d(sigma_m) > 0."""

    from austenite.jax_backend import goodman_utilisation

    g = jax.grad(goodman_utilisation, argnums=1)(
        jnp.float32(200.0), jnp.float32(100.0), jnp.float32(300.0), jnp.float32(1000.0)
    )
    assert float(g) > 0


# ---------------------------------------------------------------------------
# 8. design_jax inverse-design wrapper
# ---------------------------------------------------------------------------


def test_design_jax_gradient_descent_runs() -> None:
    """Gradient descent reduces the objective."""

    from austenite.jax_backend import design_jax

    def obj(c):
        return au.design_path_jax(c, cooling_rate=jnp.float32(10.0)).fatigue.utilisation_pct

    x0 = COMP_4140_SHORT
    res = design_jax(
        obj,
        x0,
        bounds=[(0.05, 0.6), (0.3, 1.6), (0.0, 2.0), (0.0, 0.5), (0.0, 2.0)],
        n_iter=15,
        learning_rate=1e-5,
    )
    assert res.trajectory[-1] <= res.trajectory[0]
    assert bool(jnp.all(jnp.isfinite(res.x)))


# ---------------------------------------------------------------------------
# 9. am_qualification_jax round-trips
# ---------------------------------------------------------------------------


def test_am_qualification_jax_runs() -> None:
    from austenite.jax_backend import am_qualification_jax

    r = am_qualification_jax(
        COMP_4140,
        laser_power_W=jnp.float32(200.0),
        scan_speed_mm_s=jnp.float32(800.0),
    )
    assert math.isfinite(float(r.hv30))
    assert math.isfinite(float(r.sigma_y_MPa))


def test_am_qualification_jax_is_differentiable() -> None:
    from austenite.jax_backend import am_qualification_jax

    def obj(power):
        return am_qualification_jax(
            COMP_4140,
            laser_power_W=power,
            scan_speed_mm_s=jnp.float32(800.0),
        ).sigma_y_MPa

    g = jax.grad(obj)(jnp.float32(200.0))
    assert math.isfinite(float(g))


# ---------------------------------------------------------------------------
# 10. Backend selector smoke
# ---------------------------------------------------------------------------


def test_set_jax_backend_default() -> None:
    from austenite.jax_backend import get_active_backend, set_jax_backend

    set_jax_backend("jax")
    assert get_active_backend() == "jax"
    with pytest.raises(ValueError):
        set_jax_backend("torch")
