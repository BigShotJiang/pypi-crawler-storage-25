"""Physics-accuracy audit: creep / tribology / thermophysics / liquid-metal.

Each test reproduces a textbook hand-calculation and asserts the library
function returns the expected value within an explicit tolerance.

Audited modules:
  * austenite.creep_pinn   (Larson-Miller, Wilshire 2008)
  * austenite.tribology    (Archard, Lim-Ashby, Stribeck, Hamrock-Dowson, Hertz)
  * austenite.thermophysics(Bloch-Grueneisen, Wiedemann-Franz, Neumann-Kopp,
                            CTE, Curie-Weiss, Stoner-Wohlfarth, Matthiessen)
  * austenite.liquid_metal (Iida-Guthrie surface tension, Andrade viscosity,
                            Riboud slag, Sieverts H solubility)

References used for the hand calculations:
  * Johnson K.L., "Contact Mechanics", CUP (1985) — Hertz contact.
  * Frost H.J., Ashby M.F., "Deformation-Mechanism Maps", Pergamon (1982).
  * Iida T., Guthrie R.I.L., "Physical Properties of Liquid Metals", OUP (1988).
  * Hamrock B.J., Dowson D., "Ball Bearing Lubrication", Wiley (1981).
  * Weinstein M., Elliott J.F., Trans. TMS-AIME 227 (1963) 382 — H in liquid Fe.
  * Ashby/Sommerfeld: Wiedemann-Franz Lorenz number L0 = 2.44e-8 W.ohm/K^2.

GENUINE LIBRARY INACCURACIES found during an earlier audit have since been
FIXED in source (Andrade viscosity B-coefficients re-fitted to melting-point
literature, Sieverts H solubility switched to Weinstein-Elliott, and the
Bloch-Grueneisen low-T branch replaced with a proper finite-limit Debye
integral). The ``TestFixedLibraryBehaviour`` class at the bottom now pins the
CORRECT physical values these functions return.
"""
from __future__ import annotations

import math

import pytest

from austenite import creep_pinn as cp
from austenite import liquid_metal as lm
from austenite import thermophysics as tp
from austenite import tribology as tr


# ===========================================================================
# TRIBOLOGY
# ===========================================================================


class TestArchard:
    def test_archard_volume_hand_calc(self):
        """V = k*L*s/H. k=1e-4, L=100 N, s=1000 m, H=200 HV.

        H = 200 * 9.81 = 1962 N/mm^2.
        V = 1e-4 * 100 * 1000 * 1000 (mm/m) / 1962 = 5.097 mm^3.
        """
        V = tr.archard_wear_volume(
            normal_load_N=100.0, sliding_distance_m=1000.0,
            hardness_HV=200.0, wear_coefficient_k=1e-4,
        )
        expected = 1e-4 * 100.0 * 1000.0 * 1000.0 / (200.0 * 9.81)
        assert V == pytest.approx(expected, rel=1e-9)
        assert V == pytest.approx(5.097, rel=1e-3)

    def test_archard_linear_in_load_and_distance(self):
        base = tr.archard_wear_volume(normal_load_N=100.0, sliding_distance_m=1000.0,
                                      hardness_HV=200.0, wear_coefficient_k=1e-4)
        dbl = tr.archard_wear_volume(normal_load_N=200.0, sliding_distance_m=1000.0,
                                     hardness_HV=200.0, wear_coefficient_k=1e-4)
        assert dbl == pytest.approx(2.0 * base, rel=1e-9)

    def test_archard_inverse_in_hardness(self):
        soft = tr.archard_wear_volume(normal_load_N=100.0, sliding_distance_m=1000.0,
                                      hardness_HV=100.0, wear_coefficient_k=1e-4)
        hard = tr.archard_wear_volume(normal_load_N=100.0, sliding_distance_m=1000.0,
                                      hardness_HV=400.0, wear_coefficient_k=1e-4)
        assert soft == pytest.approx(4.0 * hard, rel=1e-9)


class TestLimAshby:
    def test_lim_ashby_plowing_hand_calc(self):
        """V = (2/pi)*tan(theta)*L*s/H. theta=45 deg -> tan=1."""
        V = tr.lim_ashby_plowing_wear(100.0, 1000.0, hardness_HV=200.0,
                                      asperity_angle_deg=45.0)
        expected = (2.0 / math.pi) * 1.0 * 100.0 * 1000.0 * 1000.0 / (200.0 * 9.81)
        assert V == pytest.approx(expected, rel=1e-9)

    def test_lim_ashby_steeper_asperity_more_wear(self):
        shallow = tr.lim_ashby_plowing_wear(100.0, 1000.0, hardness_HV=200.0,
                                            asperity_angle_deg=15.0)
        steep = tr.lim_ashby_plowing_wear(100.0, 1000.0, hardness_HV=200.0,
                                          asperity_angle_deg=45.0)
        assert steep > shallow


class TestHertzPointContact:
    def test_hertz_point_steel_sphere_on_flat(self):
        """Johnson, Contact Mechanics. Steel sphere R=10 mm on steel flat, F=100 N.

        E* = E/(2(1-nu^2)) = 210e9/(2*0.91) = 115.38 GPa.
        a = (3 F R / 4 E*)^(1/3); p_max = 3F/(2 pi a^2).
        Closed form p_max = (6 F E*^2 / (pi^3 R^2))^(1/3).
        """
        res = tr.hertz_point_contact_max_pressure(
            100.0, 0.010, float("inf"), 210.0, 0.3, 210.0, 0.3)
        E = 210e9
        Estar = 1.0 / (2.0 * (1 - 0.3 ** 2) / E)
        Rp = 0.010
        a = (3.0 * 100.0 * Rp / (4.0 * Estar)) ** (1.0 / 3.0)
        pmax = 3.0 * 100.0 / (2.0 * math.pi * a ** 2)
        assert res["E_prime_GPa"] == pytest.approx(Estar / 1e9, rel=1e-6)
        assert res["a_mm"] == pytest.approx(a * 1000.0, rel=1e-6)
        assert res["p_max_MPa"] == pytest.approx(pmax / 1e6, rel=1e-6)
        # Sanity vs absolute expected value
        assert res["p_max_MPa"] == pytest.approx(1371.0, rel=1e-3)

    def test_hertz_point_pmax_closed_form(self):
        res = tr.hertz_point_contact_max_pressure(
            100.0, 0.010, float("inf"), 210.0, 0.3, 210.0, 0.3)
        Estar = 1.0 / (2.0 * (1 - 0.3 ** 2) / 210e9)
        pmax_closed = (6.0 * 100.0 * Estar ** 2 / (math.pi ** 3 * 0.010 ** 2)) ** (1.0 / 3.0)
        assert res["p_max_MPa"] == pytest.approx(pmax_closed / 1e6, rel=1e-6)

    def test_hertz_two_equal_spheres_reduced_radius(self):
        """Two equal spheres R=10 mm -> R' = 5 mm (1/R' = 1/R1 + 1/R2)."""
        res = tr.hertz_point_contact_max_pressure(
            100.0, 0.010, 0.010, 210.0, 0.3, 210.0, 0.3)
        Estar = 1.0 / (2.0 * (1 - 0.3 ** 2) / 210e9)
        Rp = 0.005
        pmax = (6.0 * 100.0 * Estar ** 2 / (math.pi ** 3 * Rp ** 2)) ** (1.0 / 3.0)
        assert res["p_max_MPa"] == pytest.approx(pmax / 1e6, rel=1e-6)


class TestHertzLineContact:
    def test_hertz_line_cylinder_on_flat(self):
        """Johnson line contact: p_max = sqrt(w' E* / (pi R)),
        b = sqrt(4 w' R / (pi E*)). Steel cylinder R=10 mm, w'=1000 N/m."""
        res = tr.hertz_line_contact_max_pressure(1000.0, 0.010, 210.0, 0.3, 210.0, 0.3)
        Estar = 1.0 / (2.0 * (1 - 0.3 ** 2) / 210e9)
        pmax = math.sqrt(1000.0 * Estar / (math.pi * 0.010))
        b = math.sqrt(4.0 * 1000.0 * 0.010 / (math.pi * Estar))
        assert res["p_max_MPa"] == pytest.approx(pmax / 1e6, rel=1e-6)
        assert res["b_mm"] == pytest.approx(b * 1000.0, rel=1e-6)

    def test_hertz_line_pmax_scales_sqrt_load(self):
        r1 = tr.hertz_line_contact_max_pressure(1000.0, 0.010, 210.0, 0.3, 210.0, 0.3)
        r4 = tr.hertz_line_contact_max_pressure(4000.0, 0.010, 210.0, 0.3, 210.0, 0.3)
        assert r4["p_max_MPa"] == pytest.approx(2.0 * r1["p_max_MPa"], rel=1e-6)


class TestHamrockDowson:
    def test_hd_film_thickness_hand_calc(self):
        """H_min = 3.63 U^0.68 G^0.49 W^-0.073 (1-exp(-0.68 k)); h = H_min*R'."""
        eta0, v, Ep, Rp, w, alpha, k = 0.04, 1.0, 226e9, 0.01, 100.0, 2e-8, 1.0
        h = tr.hamrock_dowson_film_thickness_point(eta0, v, Ep, Rp, w, alpha, k)
        U = eta0 * v / (Ep * Rp)
        G = alpha * Ep
        W = w / (Ep * Rp ** 2)
        Hmin = 3.63 * U ** 0.68 * G ** 0.49 * W ** -0.073 * (1 - math.exp(-0.68 * k))
        assert h == pytest.approx(Hmin * Rp, rel=1e-9)
        # Plausible EHL film: order 0.1 micron for these inputs
        assert 0.01e-6 < h < 5e-6

    def test_hd_film_increases_with_speed(self):
        slow = tr.hamrock_dowson_film_thickness_point(0.04, 0.1, 226e9, 0.01, 100.0)
        fast = tr.hamrock_dowson_film_thickness_point(0.04, 10.0, 226e9, 0.01, 100.0)
        assert fast > slow


class TestStribeck:
    def test_stribeck_number_definition(self):
        """zeta = eta * v / p (SI, metres)."""
        r = tr.stribeck_curve(0.05, 1.0, 10.0)  # eta Pa.s, v m/s, p MPa
        assert r["stribeck_number"] == pytest.approx(0.05 * 1.0 / (10.0e6), rel=1e-9)

    def test_stribeck_lambda_regimes(self):
        boundary = tr.stribeck_curve(0.05, 1.0, 10.0, h_min_um=0.2, Ra_um=0.5)
        ehl = tr.stribeck_curve(0.05, 1.0, 10.0, h_min_um=2.5, Ra_um=0.5)
        full = tr.stribeck_curve(0.05, 1.0, 10.0, h_min_um=10.0, Ra_um=0.5)
        assert boundary["regime"] == "boundary"
        assert ehl["regime"] == "EHL"
        assert full["regime"] == "HL"
        # mu decreases as film thickens
        assert boundary["mu_estimate"] > ehl["mu_estimate"] > full["mu_estimate"]


class TestPVlimit:
    def test_pv_limit_pass_and_fail(self):
        ok = tr.pv_limit_check(0.5, 0.05, "PTFE")   # PV=0.025 < 0.06
        bad = tr.pv_limit_check(1.0, 1.0, "PTFE")    # PV=1.0 > 0.06
        assert ok["passed"] is True
        assert bad["passed"] is False
        assert ok["PV"] == pytest.approx(0.025, rel=1e-9)


class TestFrictionTable:
    def test_friction_static_ge_kinetic(self):
        for pair in tr.FRICTION_COEFFICIENTS:
            mu_s = tr.friction_coefficient(pair, kinetic=False)
            mu_k = tr.friction_coefficient(pair, kinetic=True)
            assert mu_s >= mu_k - 1e-9, f"{pair}: mu_s < mu_k"

    def test_steel_on_steel_dry_value(self):
        # Rabinowicz: steel-on-steel dry mu_s ~ 0.74
        assert tr.friction_coefficient("steel-on-steel-dry", kinetic=False) == pytest.approx(0.74)


# ===========================================================================
# THERMOPHYSICS
# ===========================================================================


class TestWiedemannFranz:
    def test_wf_copper_room_temp(self):
        """k = L*T/rho. Cu rho=1.7 uohm.cm, T=300 K, L=2.44e-8.
        k = 2.44e-8 * 300 / 1.7e-8 = 430.6 W/m.K (Cu actual ~400)."""
        k = tp.wiedemann_franz_thermal_conductivity(1.7, 300.0)
        expected = 2.44e-8 * 300.0 / 1.7e-8
        assert k == pytest.approx(expected, rel=1e-9)
        assert k == pytest.approx(400.0, rel=0.10)  # within 10% of real Cu

    def test_wf_lorenz_default(self):
        """At rho such that L*T/rho == 1, recover L from inversion."""
        k = tp.wiedemann_franz_thermal_conductivity(1.0, 1.0)  # rho=1 uohm.cm=1e-8 ohm.m
        # k = L*1/1e-8 = L*1e8 = 2.44e-8*1e8 = 2.44
        assert k == pytest.approx(2.44, rel=1e-9)


class TestMatthiessen:
    def test_matthiessen_cu_plus_nickel(self):
        """rho = rho_pure + sum c_i k_i. Cu(1.7) + 1 wt% Ni(1.13) = 2.83."""
        rho = tp.matthiessen_resistivity(
            1.7, {"Ni": 1.0},
            resistivity_coefficients_uohm_cm_per_wt_pct=tp.MATTHIESSEN_COEFFICIENTS["Cu"])
        assert rho == pytest.approx(2.83, rel=1e-6)

    def test_matthiessen_additive(self):
        rho = tp.matthiessen_resistivity(
            1.7, {"Ni": 1.0, "Zn": 2.0},
            resistivity_coefficients_uohm_cm_per_wt_pct=tp.MATTHIESSEN_COEFFICIENTS["Cu"])
        assert rho == pytest.approx(1.7 + 1.13 + 2.0 * 0.30, rel=1e-6)


class TestBlochGruneisen:
    def test_bg_high_temperature_linear(self):
        """For T >> theta_D, rho -> rho_res + A*(T/theta_D), approaching the
        linear asymptote from below as the finite Debye integral saturates.

        Fixed function numerically integrates the Debye integral, so at
        T=600 K (=2*theta_D) the value is ~1.2% below the naive linear
        asymptote 0.5 + A*(T/theta) = 4.5, and converges to it as T grows.
        """
        r1 = tp.bloch_gruneisen_resistivity(600.0, rho_residual_uohm_cm=0.5,
                                            theta_D_K=300.0, A_uohm_cm=2.0)
        # Exact value from the fixed finite-limit integral.
        assert r1 == pytest.approx(4.4449612, rel=1e-5)
        # Approaches the linear asymptote from below within a few percent.
        linear = 0.5 + 2.0 * (600.0 / 300.0)
        assert r1 == pytest.approx(linear, rel=0.02)
        assert r1 < linear
        # And convergence improves at higher T.
        r_far = tp.bloch_gruneisen_resistivity(3000.0, rho_residual_uohm_cm=0.5,
                                               theta_D_K=300.0, A_uohm_cm=2.0)
        assert r_far == pytest.approx(0.5 + 2.0 * (3000.0 / 300.0), rel=1e-3)

    def test_bg_high_temp_doubling(self):
        """Above theta_D the resistivity is asymptotically linear in T, so
        doubling T (residual=0) roughly doubles rho, exactly in the high-T
        limit. At T=400/800 K (theta_D=300) the ratio is slightly above 2
        because the lower point has not fully reached the linear regime.
        """
        a = tp.bloch_gruneisen_resistivity(400.0, rho_residual_uohm_cm=0.0,
                                           theta_D_K=300.0, A_uohm_cm=2.0)
        b = tp.bloch_gruneisen_resistivity(800.0, rho_residual_uohm_cm=0.0,
                                           theta_D_K=300.0, A_uohm_cm=2.0)
        assert b == pytest.approx(2.0 * a, rel=0.05)
        # Deep in the linear regime the doubling is essentially exact.
        c = tp.bloch_gruneisen_resistivity(3000.0, rho_residual_uohm_cm=0.0,
                                           theta_D_K=300.0, A_uohm_cm=2.0)
        d = tp.bloch_gruneisen_resistivity(6000.0, rho_residual_uohm_cm=0.0,
                                           theta_D_K=300.0, A_uohm_cm=2.0)
        assert d == pytest.approx(2.0 * c, rel=1e-3)


class TestNeumannKopp:
    def test_nk_pure_element_recovers_cp(self):
        cp_fe = tp.neumann_kopp_specific_heat({"Fe": 100.0}, Cp_pure_J_kgK=tp.CP_PURE_298K)
        assert cp_fe == pytest.approx(tp.CP_PURE_298K["Fe"], rel=1e-9)

    def test_nk_mass_weighted_304ss(self):
        """304 SS ~ Fe-18Cr-8Ni. Mass-weighted Cp from element values."""
        comp = {"Fe": 74.0, "Cr": 18.0, "Ni": 8.0}
        expected = (74.0 * 449 + 18.0 * 449 + 8.0 * 444) / 100.0
        cp_ss = tp.neumann_kopp_specific_heat(comp, Cp_pure_J_kgK=tp.CP_PURE_298K)
        assert cp_ss == pytest.approx(expected, rel=1e-6)


class TestCTE:
    def test_cte_pure_aluminium(self):
        assert tp.cte_rule_of_mixtures({"Al": 100.0}) == pytest.approx(23.1, rel=1e-9)

    def test_cte_rule_of_mixtures_weighting(self):
        comp = {"Fe": 50.0, "Ni": 50.0}
        expected = 0.5 * 11.8 + 0.5 * 13.4
        assert tp.cte_rule_of_mixtures(comp) == pytest.approx(expected, rel=1e-6)


class TestCurieWeiss:
    def test_curie_weiss_iron(self):
        """chi = C/(T - Tc). Fe Tc=1043 K, at 1100 K: 1/(57) = 0.01754."""
        chi = tp.curie_weiss_susceptibility(1100.0, Curie_temperature_K=1043.0,
                                            C_curie_constant=1.0)
        assert chi == pytest.approx(1.0 / 57.0, rel=1e-6)

    def test_curie_weiss_diverges_at_tc(self):
        chi = tp.curie_weiss_susceptibility(1043.0, Curie_temperature_K=1043.0)
        assert math.isinf(chi)


class TestStonerWohlfarth:
    def test_sw_easy_axis_equals_HK(self):
        """theta=0 -> H_switch = H_K."""
        assert tp.stoner_wohlfarth_switching_field(1.0, 0.0) == pytest.approx(1.0, rel=1e-6)

    def test_sw_45deg_is_half(self):
        """theta=45 deg -> H_switch = 0.5 H_K (classic SW minimum)."""
        assert tp.stoner_wohlfarth_switching_field(1.0, 45.0) == pytest.approx(0.5, rel=1e-6)

    def test_sw_hard_axis_equals_HK(self):
        """theta=90 deg -> H_switch = H_K again (astroid symmetry)."""
        assert tp.stoner_wohlfarth_switching_field(1.0, 90.0) == pytest.approx(1.0, rel=1e-6)


class TestSteinmetz:
    def test_steinmetz_hysteresis_loss(self):
        """P_h = eta * f * B^n. eta=30, f=50 Hz, B=1.5 T, n=1.6."""
        P = tp.kersten_hysteresis_loss(1.5, 50.0, eta_hysteresis_J_kg_T2=30.0,
                                       n_steinmetz=1.6)
        assert P == pytest.approx(30.0 * 50.0 * 1.5 ** 1.6, rel=1e-9)


# ===========================================================================
# LIQUID METAL
# ===========================================================================


class TestSurfaceTension:
    def test_iida_guthrie_fe_at_tm(self):
        """sigma(T_m) = sigma_0. Fe = 1865 mN/m."""
        assert lm.iida_guthrie_surface_tension("Fe", 1811.0) == pytest.approx(1865.0)

    def test_iida_guthrie_fe_superheat(self):
        """sigma(T) = sigma_0 + (dsigma/dT)(T - T_m). Fe at 1873 K."""
        s = lm.iida_guthrie_surface_tension("Fe", 1873.0)
        assert s == pytest.approx(1865.0 - 0.43 * (1873.0 - 1811.0), rel=1e-6)
        # Liquid Fe surface tension ~1.83 N/m at 1873 K (Mills) -> within 10%
        assert s == pytest.approx(1830.0, rel=0.05)

    def test_iida_guthrie_copper_in_range(self):
        s = lm.iida_guthrie_surface_tension("Cu", 1358.0)
        assert s == pytest.approx(1304.0)
        # Literature Cu ~1.30-1.34 N/m at T_m
        assert 1250.0 < s < 1360.0

    def test_marangoni_negative_for_clean_metals(self):
        for el in ["Fe", "Ni", "Cu", "Al", "Ti"]:
            assert lm.marangoni_dsigma_dT(el) < 0.0


class TestAndradeViscosityForm:
    def test_andrade_functional_form(self):
        """eta(T) = A * exp(B/T) (form correctness, independent of constants)."""
        entry = lm.LIQUID_METAL_VISCOSITY["Al"]
        T = 1000.0
        expected = entry["A"] * math.exp(entry["B"] / T)
        assert lm.andrade_viscosity("Al", T) == pytest.approx(expected, rel=1e-9)

    def test_andrade_decreases_with_temperature(self):
        """Viscosity must drop as T rises (B>0)."""
        lo = lm.andrade_viscosity("Al", 950.0)
        hi = lm.andrade_viscosity("Al", 1300.0)
        assert hi < lo

    def test_andrade_aluminium_magnitude(self):
        """Al uses Mills-2002 constants and is physically correct:
        eta(T_m=933) ~ 1.26 mPa.s vs literature ~1.3 mPa.s."""
        eta = lm.andrade_viscosity("Al", 933.0)
        assert eta == pytest.approx(1.3, rel=0.10)


class TestRiboudSlag:
    def test_riboud_form_and_monotonicity(self):
        """log10(eta) = A + B/T -> eta drops as T rises for B>0."""
        lo = lm.riboud_slag_viscosity(X_CaO=0.40, X_SiO2=0.45, X_Al2O3=0.15, T_K=1573)
        hi = lm.riboud_slag_viscosity(X_CaO=0.40, X_SiO2=0.45, X_Al2O3=0.15, T_K=1873)
        assert hi < lo
        assert lo > 0.0

    def test_riboud_mold_flux_order_of_magnitude(self):
        """A typical CaO-SiO2-Al2O3-CaF2 mold flux: eta ~0.05-2 Pa.s @1573 K."""
        eta = lm.riboud_slag_viscosity(X_CaO=0.40, X_SiO2=0.40, X_Al2O3=0.05,
                                       X_MgO=0.05, X_CaF2=0.10, T_K=1573)
        assert 0.01 < eta < 5.0


# ===========================================================================
# CREEP
# ===========================================================================


class TestLarsonMiller:
    def test_lmp_inversion_roundtrip(self):
        """LMP = T*(C + log10 t)  =>  t = 10^(LMP/T - C)."""
        t = cp._lmp_to_life_hours(20575.0, 823.15, 20.0)
        log_t = 20575.0 / 823.15 - 20.0
        assert t == pytest.approx(10 ** log_t, rel=1e-9)

    def test_grade91_anchor_consistency(self):
        """The (LMP=20575, sigma=100 MPa) anchor for Gr.91 was set as
        '100 MPa @ 550C / 100000 h'. Inverting at 550C must give ~1e5 h."""
        lmp = cp._interp_lmp_sigma("Grade91_9Cr1Mo", 100.0)
        assert lmp == pytest.approx(20575.0, rel=1e-6)
        t = cp._lmp_to_life_hours(lmp, 550.0 + 273.15, 20.0)
        assert t == pytest.approx(1e5, rel=0.05)

    def test_grade91_predict_uses_lmp(self):
        r = cp.predict_creep_life("Grade91_9Cr1Mo", 100.0, 550.0)
        assert r.method == "Wilshire+LMP-anchor"
        assert r.rupture_hours_pinn == pytest.approx(1e5, rel=0.05)

    def test_creep_life_decreases_with_stress(self):
        """Higher stress -> shorter life (monotonic)."""
        lo = cp.predict_creep_life("Grade91_9Cr1Mo", 80.0, 600.0).rupture_hours_pinn
        hi = cp.predict_creep_life("Grade91_9Cr1Mo", 150.0, 600.0).rupture_hours_pinn
        assert hi < lo

    def test_creep_life_decreases_with_temperature(self):
        """Same stress, higher T -> shorter life."""
        cool = cp.predict_creep_life("Grade91_9Cr1Mo", 100.0, 550.0).rupture_hours_pinn
        hot = cp.predict_creep_life("Grade91_9Cr1Mo", 100.0, 650.0).rupture_hours_pinn
        assert hot < cool


class TestWilshire:
    def test_wilshire_form(self):
        """t_r = (-ln(sigma/sigma_UTS)/k)^(1/u) * exp(Q/RT)."""
        sigma, T_K, uts, Q = 200.0, 873.15, 540.0, 290.0
        k, u = 35.0, 0.22
        R = 8.314e-3
        ratio = sigma / uts
        expected = (-math.log(ratio) / k) ** (1.0 / u) * math.exp(Q / (R * T_K))
        got = cp._wilshire_life_hours(sigma, T_K, uts, Q, k=k, u=u)
        assert got == pytest.approx(expected, rel=1e-9)

    def test_wilshire_zero_life_above_uts(self):
        assert cp._wilshire_life_hours(600.0, 873.15, 540.0, 290.0) == 0.0


# ===========================================================================
# FIXED LIBRARY BEHAVIOUR  (formerly TestDocumentedLibraryBugs). These pin the
# CORRECT physical values now that the source defects have been fixed:
#   * Andrade viscosity B-coefficients re-fitted to melting-point literature,
#   * Sieverts H solubility switched to Weinstein-Elliott K_S=10^(2.423-1900/T),
#   * Bloch-Grueneisen replaced with a continuous finite-limit Debye integral.
# ===========================================================================


class TestFixedLibraryBehaviour:
    def test_andrade_iron_viscosity_matches_literature(self):
        """liquid_metal.py LIQUID_METAL_VISCOSITY['Fe'] B re-fitted.

        eta(Fe, T_m=1811 K) ~ 5.5 mPa.s (Iida-Guthrie 1988), not the old
        ~36.9 mPa.s. Physical liquid Fe viscosity at T_m is ~5.5-7 mPa.s.
        """
        eta = lm.andrade_viscosity("Fe", 1811.0)
        assert eta == pytest.approx(5.5, rel=0.05)
        assert eta < 10.0  # physical for liquid Fe

    def test_andrade_lead_viscosity_matches_literature(self):
        """liquid_metal.py Pb coefficients re-fitted.

        eta(Pb, T_m=600 K) ~ 2.6 mPa.s (literature), not the old ~55.9 mPa.s.
        """
        eta = lm.andrade_viscosity("Pb", 600.0)
        assert eta == pytest.approx(2.6, rel=0.05)

    def test_andrade_refitted_metals_at_melting_point(self):
        """All re-fitted metals reproduce their melting-point viscosities."""
        targets_mPa_s = {
            ("Fe", 1811.0): 5.5, ("Ni", 1728.0): 4.9, ("Cu", 1358.0): 4.0,
            ("Pb", 600.0): 2.6, ("Au", 1337.0): 5.0, ("Sn", 505.0): 2.0,
            ("Ag", 1235.0): 3.9, ("Zn", 693.0): 3.85,
        }
        for (el, T_m), expected in targets_mPa_s.items():
            assert lm.andrade_viscosity(el, T_m) == pytest.approx(expected, rel=0.03), el

    def test_sieverts_hydrogen_solubility_weinstein_elliott(self):
        """liquid_metal.py sieverts_H_solubility_in_Fe uses Weinstein-Elliott
        K_S = 10^(2.423 - 1900/T): [H] @1873 K, 1 bar ~ 25.6 ppm (was ~9.9).
        """
        h = lm.sieverts_H_solubility_in_Fe(1.0, 1873.0)
        correct = 10 ** (-1900.0 / 1873.0 + 2.423)
        assert correct == pytest.approx(25.6, rel=0.02)  # Weinstein-Elliott target
        assert h == pytest.approx(25.6, rel=0.02)
        assert h == pytest.approx(correct, rel=1e-3)

    def test_bloch_gruneisen_continuous_across_theta_D(self):
        """thermophysics.py bloch_gruneisen_resistivity now integrates the
        Debye integral with upper limit theta_D/T, so rho(T) is continuous at
        T = theta_D (no ~124x jump between the old low-/high-T branches).
        """
        tD, A = 343.0, 2.0
        just_below = tp.bloch_gruneisen_resistivity(tD - 1.0, rho_residual_uohm_cm=0.0,
                                                    theta_D_K=tD, A_uohm_cm=A)
        at_tD = tp.bloch_gruneisen_resistivity(tD, rho_residual_uohm_cm=0.0,
                                               theta_D_K=tD, A_uohm_cm=A)
        just_above = tp.bloch_gruneisen_resistivity(tD + 1.0, rho_residual_uohm_cm=0.0,
                                                    theta_D_K=tD, A_uohm_cm=A)
        # Continuous: values either side of theta_D agree to well within 20%.
        assert just_above == pytest.approx(at_tD, rel=0.20)
        assert just_below == pytest.approx(at_tD, rel=0.20)
        assert abs(just_above / just_below - 1.0) < 0.05
        # All on the order of A, not the old ~124*A spike.
        assert at_tD < 5.0 * A
