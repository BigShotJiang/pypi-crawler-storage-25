"""Audit-2: statistical / numerical correctness of the reliability stack.

Each test validates ONE formula against a textbook reference, with an
explicit numerical tolerance. These are *oracle* tests: the expected value
is computed independently (closed form or analytic root) rather than read
back from the implementation.

Scope notes
-----------
* ``au.reliability.*`` — Weibull MLE fit/CDF/reliability, B-life, MTTF,
  Cox proportional hazards (Breslow), Arrhenius ALT, system RBD. All pure
  Python, fully offline. This is the bulk of the audit.
* ``au.bayesian.*`` — the headline statistics (Brooks-Gelman R-hat,
  Chen-Shao HPD, posterior-predictive calibration) are computed
  SERVER-SIDE; ``au.bayesian.calphad`` / ``calphad_deep`` only POST to a
  remote route (see ``test_bayesian.py``, which mocks HTTP). The sole
  offline code is the hierarchical-dataset registry + its Redlich-Kister
  data generator, validated here for its deterministic polynomial.
* ``austenite._calphad_native`` — a couple of high-value numerical
  helpers (normal-CDF used by Cox p-values, magnetic term continuity,
  wt%→mole) are spot-checked.

References
----------
* Weibull W., J. Appl. Mech. 18 (1951) 293.
* Abernethy R.B., *The New Weibull Handbook*, 5th ed. (2006).
* Rinne H., *The Weibull Distribution: A Handbook*, CRC (2008) §13.6.
* Cox D.R., J. Roy. Stat. Soc. B 34 (1972) 187 (partial likelihood).
* Nelson W., *Accelerated Testing*, Wiley (1990) §2 (Arrhenius ALT).
* Hoyland-Rausand, *System Reliability Theory*, 2nd ed. Wiley (2003).
"""

from __future__ import annotations

import math

import pytest

import austenite as au
from austenite import reliability as rel


# ===========================================================================
# Helpers
# ===========================================================================


def _synthetic_weibull(beta: float, eta: float, n: int) -> list[float]:
    """Noiseless Weibull order statistics via median-rank plotting positions.

    t_i = eta * (-ln(1 - F_i))^(1/beta), F_i = Bernard's median rank.
    """

    return [
        eta * (-math.log(max(1e-12, 1 - (i + 1 - 0.3) / (n + 0.4)))) ** (1.0 / beta)
        for i in range(n)
    ]


def _weibull_hazard(beta: float, eta: float, t: float) -> float:
    """Closed-form Weibull hazard h(t) = (beta/eta) * (t/eta)^(beta-1)."""

    return (beta / eta) * (t / eta) ** (beta - 1.0)


# ===========================================================================
# 1. WEIBULL — CDF / reliability invariants (independent of beta)
# ===========================================================================


def test_weibull_cdf_at_eta_is_one_minus_inv_e() -> None:
    """F(eta) = 1 - exp(-1) = 0.63212..., for ANY beta (Abernethy ch.2)."""

    for beta in (0.5, 1.0, 2.0, 3.5, 7.0):
        wf = rel.WeibullFit(
            beta=beta, eta=137.0, MTTF=0, B10=0, B50=0, R2=0,
            n_failures=1, n_censored=0, converged=True,
        )
        assert wf.cdf(137.0) == pytest.approx(1.0 - math.exp(-1.0), abs=1e-12)


def test_weibull_reliability_complements_cdf() -> None:
    """R(t) = 1 - F(t); R(eta) = exp(-1) = 0.36787944."""

    wf = rel.WeibullFit(
        beta=2.3, eta=500.0, MTTF=0, B10=0, B50=0, R2=0,
        n_failures=1, n_censored=0, converged=True,
    )
    for t in (10.0, 250.0, 500.0, 900.0):
        assert wf.reliability(t) == pytest.approx(1.0 - wf.cdf(t), abs=1e-12)
    assert wf.reliability(500.0) == pytest.approx(math.exp(-1.0), abs=1e-12)


def test_weibull_cdf_closed_form_general_point() -> None:
    """F(t) = 1 - exp(-(t/eta)^beta) at an arbitrary (t, beta, eta)."""

    wf = rel.WeibullFit(
        beta=1.8, eta=220.0, MTTF=0, B10=0, B50=0, R2=0,
        n_failures=1, n_censored=0, converged=True,
    )
    t = 310.0
    expected = 1.0 - math.exp(-((t / 220.0) ** 1.8))
    assert wf.cdf(t) == pytest.approx(expected, rel=1e-12)


# ===========================================================================
# 2. WEIBULL — hazard monotonicity (beta>1 wear-out, beta<1 infant)
# ===========================================================================


def test_weibull_hazard_increasing_for_beta_gt_1() -> None:
    """Wear-out region: h(t) strictly increasing when beta > 1."""

    h = [_weibull_hazard(2.5, 100.0, t) for t in (10, 30, 60, 95)]
    assert all(h[i] < h[i + 1] for i in range(len(h) - 1))


def test_weibull_hazard_decreasing_for_beta_lt_1() -> None:
    """Infant-mortality region: h(t) strictly decreasing when beta < 1."""

    h = [_weibull_hazard(0.5, 100.0, t) for t in (10, 30, 60, 95)]
    assert all(h[i] > h[i + 1] for i in range(len(h) - 1))


def test_weibull_hazard_constant_for_beta_1() -> None:
    """Exponential special case: beta == 1 -> constant hazard = 1/eta."""

    eta = 250.0
    for t in (5.0, 80.0, 400.0):
        assert _weibull_hazard(1.0, eta, t) == pytest.approx(1.0 / eta, rel=1e-12)


# ===========================================================================
# 3. WEIBULL — B-life and MTTF closed forms (recovered from a clean fit)
# ===========================================================================


def test_weibull_B10_closed_form() -> None:
    """B10 = eta * (-ln 0.9)^(1/beta)  (Abernethy 'B-life')."""

    fit = rel.weibull_fit(_synthetic_weibull(2.5, 100.0, 40))
    expected = fit.eta * (-math.log(0.9)) ** (1.0 / fit.beta)
    assert fit.B10 == pytest.approx(expected, rel=1e-9)
    # cross-check: F(B10) == 0.10 exactly
    assert fit.cdf(fit.B10) == pytest.approx(0.10, abs=1e-9)


def test_weibull_B50_is_median() -> None:
    """B50 = eta * (ln 2)^(1/beta); F(B50) == 0.50."""

    fit = rel.weibull_fit(_synthetic_weibull(2.5, 100.0, 40))
    expected = fit.eta * (math.log(2.0)) ** (1.0 / fit.beta)
    assert fit.B50 == pytest.approx(expected, rel=1e-9)
    assert fit.cdf(fit.B50) == pytest.approx(0.50, abs=1e-9)


def test_weibull_MTTF_is_eta_times_gamma() -> None:
    """MTTF = eta * Gamma(1 + 1/beta)  (mean of the Weibull)."""

    fit = rel.weibull_fit(_synthetic_weibull(2.5, 100.0, 40))
    expected = fit.eta * math.gamma(1.0 + 1.0 / fit.beta)
    assert fit.MTTF == pytest.approx(expected, rel=1e-9)


def test_weibull_life_ordering() -> None:
    """B10 < B50 < eta < ... and MTTF near eta*0.886 for beta~2.5."""

    fit = rel.weibull_fit(_synthetic_weibull(2.5, 100.0, 40))
    assert fit.B10 < fit.B50 < fit.eta
    # For beta=2.5, Gamma(1.4)=0.88726 -> MTTF ~ 0.887*eta < eta
    assert fit.MTTF == pytest.approx(0.88726 * fit.eta, rel=2e-3)


# ===========================================================================
# 4. WEIBULL — MLE recovery + profile-likelihood self-consistency
# ===========================================================================


def test_weibull_mle_recovers_parameters() -> None:
    """Clean Weibull(2.5, 100) sample -> beta within 0.2, eta within 2%.

    Plotting-position MLE is mildly biased high in beta (~+0.1 here) for
    median-rank synthetic data; that is expected, not a defect.
    """

    fit = rel.weibull_fit(_synthetic_weibull(2.5, 100.0, 40))
    assert fit.converged
    assert fit.beta == pytest.approx(2.5, abs=0.2)
    assert fit.eta == pytest.approx(100.0, rel=0.02)
    assert fit.R2 > 0.999


def test_weibull_eta_hat_matches_profile_formula() -> None:
    """eta_hat = (sum t_i^beta / r)^(1/beta) at the converged beta (complete data)."""

    data = _synthetic_weibull(3.0, 75.0, 30)
    fit = rel.weibull_fit(data)
    r = fit.n_failures
    s0 = sum(t ** fit.beta for t in data)
    expected_eta = (s0 / r) ** (1.0 / fit.beta)
    assert fit.eta == pytest.approx(expected_eta, rel=1e-9)


def test_weibull_censoring_reduces_failures_and_still_fits() -> None:
    """Right-censoring is bookkept and MLE still recovers beta within 0.5."""

    data = _synthetic_weibull(2.0, 80.0, 25)
    censored = [t > 80.0 for t in data]
    obs = [80.0 if c else t for t, c in zip(data, censored)]
    fit = rel.weibull_fit(obs, censored)
    assert fit.converged
    assert fit.n_censored > 0
    assert fit.n_failures == 25 - fit.n_censored
    assert fit.beta == pytest.approx(2.0, abs=0.5)


def test_weibull_too_few_points_degenerate() -> None:
    """< 3 data points -> degenerate fit, converged False, zeros."""

    fit = rel.weibull_fit([10.0, 20.0])
    assert not fit.converged
    assert fit.beta == 0.0 and fit.eta == 0.0


# ===========================================================================
# 5. COX PROPORTIONAL HAZARDS — analytic-root oracle
# ===========================================================================


def _cox_single_cov_data() -> list[dict[str, float]]:
    """4 subjects, all events, alternating covariate -> finite MLE exists."""

    return [
        {"time": 1, "event": 1, "x": 1},
        {"time": 2, "event": 1, "x": 0},
        {"time": 3, "event": 1, "x": 1},
        {"time": 4, "event": 1, "x": 0},
    ]


def _cox_score(b: float) -> float:
    """Breslow partial-likelihood score U(beta) for the 4-subject case."""

    def xb(x: float) -> float:
        return math.exp(b * x)

    u = 0.0
    # t=1, risk {1,2,3,4} x=(1,0,1,0), event x=1
    s = 2 * xb(1) + 2 * xb(0)
    u += 1 - (2 * xb(1)) / s
    # t=2, risk {2,3,4} x=(0,1,0), event x=0
    s = xb(1) + 2 * xb(0)
    u += 0 - (xb(1)) / s
    # t=3, risk {3,4} x=(1,0), event x=1
    s = xb(1) + xb(0)
    u += 1 - (xb(1)) / s
    # t=4, risk {4} x=0, event x=0
    u += 0.0
    return u


def test_cox_beta_matches_analytic_score_root() -> None:
    """Cox MLE beta solves U(beta)=0; compare to a bisection root oracle."""

    lo, hi = -10.0, 10.0
    for _ in range(200):
        mid = 0.5 * (lo + hi)
        if _cox_score(lo) * _cox_score(mid) <= 0:
            hi = mid
        else:
            lo = mid
    oracle = 0.5 * (lo + hi)

    fit = rel.cox_ph(_cox_single_cov_data(), covariates=["x"])
    assert fit.converged
    assert fit.coefficients["x"] == pytest.approx(oracle, abs=1e-6)


def test_cox_hazard_ratio_is_exp_beta() -> None:
    """HR_k = exp(beta_k) by definition of the proportional-hazards model."""

    fit = rel.cox_ph(_cox_single_cov_data(), covariates=["x"])
    assert fit.hazard_ratios["x"] == pytest.approx(
        math.exp(fit.coefficients["x"]), rel=1e-12
    )


def test_cox_null_loglik_is_sum_minus_log_risk_set_sizes() -> None:
    """ell(0) = -sum_events ln |R(t_i)|  (all weights exp(0)=1)."""

    fit = rel.cox_ph(_cox_single_cov_data(), covariates=["x"])
    # risk-set sizes at the 4 ordered event times: 4,3,2,1
    expected = -(math.log(4) + math.log(3) + math.log(2) + math.log(1))
    assert fit.loglik_null == pytest.approx(expected, abs=1e-12)


def test_cox_LR_statistic_is_twice_loglik_gap() -> None:
    """LR = 2*(ell_max - ell_null) >= 0 and equals the reported field."""

    fit = rel.cox_ph(_cox_single_cov_data(), covariates=["x"])
    assert fit.LR_statistic == pytest.approx(
        2.0 * (fit.loglik - fit.loglik_null), abs=1e-12
    )
    assert fit.LR_statistic >= 0.0


def test_cox_monotone_separation_diverges_and_flags_nonconvergence() -> None:
    """Perfect separation -> beta -> +inf, converged False (no finite MLE).

    Documents correct behaviour: with both x=1 subjects failing before both
    x=0 subjects, the partial likelihood has no interior maximum.
    """

    data = [
        {"time": 1, "event": 1, "x": 1},
        {"time": 2, "event": 1, "x": 1},
        {"time": 3, "event": 1, "x": 0},
        {"time": 4, "event": 1, "x": 0},
    ]
    fit = rel.cox_ph(data, covariates=["x"])
    assert not fit.converged
    assert fit.coefficients["x"] > 5.0  # blown up toward +inf


def test_cox_too_few_data_returns_empty() -> None:
    """< 3 usable rows -> empty fit, converged False."""

    fit = rel.cox_ph([{"time": 10, "event": 1, "x": 1}], covariates=["x"])
    assert not fit.converged
    assert fit.coefficients == {}


# ===========================================================================
# 6. NORMAL CDF / INVERSE — drive Cox Wald p-values
# ===========================================================================


def test_phi_cdf_reference_points() -> None:
    """A&S 7.1.26 normal CDF accurate to ~1e-7 at standard quantiles."""

    assert rel._phi_cdf(0.0) == pytest.approx(0.5, abs=1e-7)
    assert rel._phi_cdf(1.96) == pytest.approx(0.9750021, abs=1e-6)
    assert rel._phi_cdf(-1.96) == pytest.approx(0.0249979, abs=1e-6)
    assert rel._phi_cdf(2.5758) == pytest.approx(0.995, abs=1e-4)


def test_phi_inv_reference_points_and_roundtrip() -> None:
    """Beasley-Springer-Moro inverse-CDF; round-trips with the CDF."""

    assert rel._phi_inv(0.975) == pytest.approx(1.959964, abs=1e-4)
    assert rel._phi_inv(0.5) == pytest.approx(0.0, abs=1e-9)
    for p in (0.1, 0.25, 0.5, 0.8, 0.975):
        assert rel._phi_cdf(rel._phi_inv(p)) == pytest.approx(p, abs=1e-4)


def test_cox_p_values_in_unit_interval() -> None:
    """Wald two-sided p = 2*(1 - Phi(|z|)) lies in [0, 1]."""

    fit = rel.cox_ph(_cox_single_cov_data(), covariates=["x"])
    for p in fit.p_values.values():
        assert 0.0 <= p <= 1.0


# ===========================================================================
# 7. ARRHENIUS ACCELERATED-LIFE TESTING
# ===========================================================================


def test_arrhenius_recovers_activation_energy() -> None:
    """ln t50 = ln A + (Ea/kB)(1/T): recover Ea=0.7 eV from a clean line."""

    kB = 8.617333262e-5
    Ea, A = 0.7, 1e-6
    matrix = [
        {"T_K": T, "t50_h": A * math.exp(Ea / kB / T)}
        for T in (350, 375, 400, 425, 450)
    ]
    fit = rel.arrhenius_alt(matrix, use_T_K=300.0)
    assert fit.E_a_eV == pytest.approx(0.7, abs=1e-6)
    assert fit.R2 == pytest.approx(1.0, abs=1e-9)


def test_arrhenius_extrapolates_t50_at_use_temperature() -> None:
    """Predicted t50 at use T equals the closed-form A*exp(Ea/kB/T_use)."""

    kB = 8.617333262e-5
    Ea, A = 0.7, 1e-6
    matrix = [
        {"T_K": T, "t50_h": A * math.exp(Ea / kB / T)}
        for T in (350, 375, 400, 425, 450)
    ]
    fit = rel.arrhenius_alt(matrix, use_T_K=300.0)
    expected = A * math.exp(Ea / kB / 300.0)
    assert fit.t50_at_use_T == pytest.approx(expected, rel=1e-6)


def test_arrhenius_acceleration_factor_gt_one_for_cooler_use_temp() -> None:
    """Cooler use temp than every test cell -> AF = t50_use / min(t50_test) > 1."""

    kB = 8.617333262e-5
    Ea, A = 0.7, 1e-6
    matrix = [
        {"T_K": T, "t50_h": A * math.exp(Ea / kB / T)}
        for T in (350, 375, 400, 425, 450)
    ]
    fit = rel.arrhenius_alt(matrix, use_T_K=300.0)
    t50_min = min(c["t50_h"] for c in matrix)
    assert fit.acceleration_factor == pytest.approx(fit.t50_at_use_T / t50_min, rel=1e-9)
    assert fit.acceleration_factor > 1.0


def test_arrhenius_too_few_cells_degenerate() -> None:
    """< 2 cells -> degenerate zero fit (cannot fit a line)."""

    fit = rel.arrhenius_alt([{"T_K": 400, "t50_h": 100}], use_T_K=300.0)
    assert fit.E_a_eV == 0.0


# ===========================================================================
# 8. SYSTEM RELIABILITY — series / parallel / k-of-n
# ===========================================================================


def test_system_series_is_product() -> None:
    """Series block: R = prod R_i."""

    s = rel.system("A -> B -> C", {"A": 0.9, "B": 0.8, "C": 0.95})
    assert s.R_system == pytest.approx(0.9 * 0.8 * 0.95, rel=1e-12)


def test_system_parallel_is_one_minus_product_of_unreliabilities() -> None:
    """Parallel block: R = 1 - prod(1 - R_i)."""

    p = rel.system("(A || B)", {"A": 0.9, "B": 0.8})
    assert p.R_system == pytest.approx(1.0 - (1 - 0.9) * (1 - 0.8), rel=1e-12)
    assert p.R_system == pytest.approx(0.98, rel=1e-12)


def test_system_k_of_n_exact_binomial() -> None:
    """2-of-3 identical R=0.9: R = C(3,2) R^2 (1-R) + R^3 = 0.972."""

    out = rel.system("kof3(D,E,F)", {"D": 0.9, "E": 0.9, "F": 0.9}, k=2)
    expected = 3 * 0.9**2 * 0.1 + 0.9**3
    assert out.R_system == pytest.approx(expected, rel=1e-12)
    assert out.R_system == pytest.approx(0.972, rel=1e-12)


def test_system_k_equals_n_reduces_to_all_series() -> None:
    """kofN token with k=N (no override) -> all must work -> prod R_i."""

    out = rel.system("kof3(D,E,F)", {"D": 0.9, "E": 0.9, "F": 0.9})
    assert out.R_system == pytest.approx(0.9**3, rel=1e-12)


def test_system_weakest_link_identified() -> None:
    """evaluate() reports the lowest-R block id as the weakest link."""

    s = rel.system("A -> B -> C", {"A": 0.99, "B": 0.70, "C": 0.95})
    assert s.weakest_R == pytest.approx(0.70, rel=1e-12)
    assert s.weakest_id == "B"


def test_rbd_builder_matches_topology_parser() -> None:
    """RBD builder API and the topology string give the same R_system."""

    rbd = rel.RBD()
    rbd.add("A", R=0.95)
    rbd.add_parallel(["B", "C"], R=[0.92, 0.92])
    built = rbd.evaluate()
    expected = 0.95 * (1.0 - (1 - 0.92) ** 2)
    assert built.R_system == pytest.approx(expected, rel=1e-12)


def test_kofn_reliability_helper_matches_binomial_for_identical_R() -> None:
    """_k_of_n_reliability(identical R) equals the binomial upper tail."""

    R = 0.85
    rs = [R] * 5
    k = 3
    expected = sum(
        math.comb(5, i) * R**i * (1 - R) ** (5 - i) for i in range(k, 6)
    )
    assert rel._k_of_n_reliability(rs, k) == pytest.approx(expected, rel=1e-12)


# ===========================================================================
# 9. BAYESIAN — offline registry only (statistics are remote; see module docstring)
# ===========================================================================


def test_bayesian_rk_dataset_polynomial_is_exact() -> None:
    """The offline RK generator reproduces G = x(1-x)[L0+L1(1-2x)+L2(1-2x)^2]
    + (T-Tref)*slope exactly for the Hammar 1979 dataset."""

    from austenite import bayesian as bay

    d = bay.HIERARCHICAL_DATASETS["hammar-1979-sigma"]
    L0, L1, L2 = -15000.0, 2500.0, -800.0
    T_ref, slope = 1023.0, 0.05
    for pt in d["datapoints"]:
        x, T = pt["x"], pt["T_K"]
        g = x * (1 - x) * (L0 + L1 * (1 - 2 * x) + L2 * (1 - 2 * x) ** 2)
        g += (T - T_ref) * slope
        assert pt["G_obs"] == pytest.approx(g, rel=1e-12)


def test_bayesian_registry_shape_and_lookup() -> None:
    """All six cited datasets present; nAlloys*nTemperatures == #datapoints."""

    from austenite import bayesian as bay

    assert len(bay.HIERARCHICAL_DATASETS) >= 6
    for did, d in bay.HIERARCHICAL_DATASETS.items():
        assert d["nAlloys"] * d["nTemperatures"] == len(d["datapoints"])
        assert len(d["priorMean"]) == 3 and len(d["priorCov"]) == 3
        assert all(v > 0 for v in d["priorCov"])  # variances positive
    assert bay.find_hierarchical_dataset("does-not-exist") is None
    assert len(bay.datasets_by_family("iron-base")) == 3


# ===========================================================================
# 10. _calphad_native — numerical helper spot checks (reliability is rich,
#     so just a couple of high-value sanity checks per the task brief)
# ===========================================================================


def test_calphad_wt_to_mole_conserves_and_normalises() -> None:
    """wt%->mole fraction: Fe-18Cr -> n_i = w_i/M_i normalised; sums to 1."""

    cn = pytest.importorskip("austenite._calphad_native")
    m = cn.wt_to_mole({"Fe": 82.0, "Cr": 18.0})
    nFe = 82.0 / 55.845
    nCr = 18.0 / 51.996
    tot = nFe + nCr
    assert m["FE"] == pytest.approx(nFe / tot, rel=1e-9)
    assert m["CR"] == pytest.approx(nCr / tot, rel=1e-9)
    assert sum(m.values()) == pytest.approx(1.0, abs=1e-12)


def test_calphad_magnetic_term_finite_and_signed() -> None:
    """Inden-Hillert-Jarl G_mag: finite everywhere, negative (stabilising),
    and larger in magnitude below Tc than above (ferromagnetic ordering)."""

    cn = pytest.importorskip("austenite._calphad_native")
    mp = cn.MagneticParams(1043.0, 2.22, 0.4)  # BCC-Fe
    g_below = cn.magnetic_g(mp, 500.0)
    g_at = cn.magnetic_g(mp, 1043.0)
    g_above = cn.magnetic_g(mp, 1500.0)
    for g in (g_below, g_at, g_above):
        assert math.isfinite(g)
        assert g <= 0.0
    assert abs(g_below) > abs(g_above)


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(pytest.main([__file__, "-q"]))
