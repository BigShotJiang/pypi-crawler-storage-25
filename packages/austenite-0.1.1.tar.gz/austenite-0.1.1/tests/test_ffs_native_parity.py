"""Parity tests for the native API 579-1 FFS engine.

Three layers:

1.  **HTTP-vs-native parity** — for each Part (5 / 6 / 9), drive a
    parameterised set of inputs through both the mocked HTTP path and
    the native engine. Verdict label, t_min, MAWP must agree within
    ±5 %.
2.  **Annex E published cases** — replicate the API 579-1 Annex E.5.1
    (uniform thinning), E.5.3 (LTA), E.6.1 (pitting), E.9.1 (surface
    crack FAD) sample problems and check the verdicts against the
    published answers.
3.  **Fracture-pro auxiliaries** — Lamé, FAD curve, WRS profile,
    Wüthrich LBB COD, NACE TM0284 HIC severity. Each is checked against
    a closed-form / textbook value.

All tests skip if numpy / scipy are missing.
"""

from __future__ import annotations

import math
import os

import pytest

pytest.importorskip("numpy")

import austenite as au
from austenite import _ffs_native as native


PART5_URL = "https://api-test.austenite.org/v1/ffs/api-579/part-5"
PART6_URL = "https://api-test.austenite.org/v1/ffs/api-579/part-6"
PART9_URL = "https://api-test.austenite.org/v1/ffs/api-579/part-9"


# ---------------------------------------------------------------------------
# 1. Fracture-pro auxiliaries — closed-form correctness
# ---------------------------------------------------------------------------


def test_lame_hoop_stress_thin_wall_limit() -> None:
    """Thin-wall: σ_hoop ≈ P · D / (2 t). Sanity for Lamé thick-wall."""

    P = 5.0  # MPa
    OD = 500.0  # mm
    wall = 10.0
    ID = OD - 2 * wall
    sigma_h, sigma_l = native.lame_hoop_long_stress(P, OD, ID)
    # Thin-wall formula
    thin_hoop = P * OD / (2 * wall)
    # Lamé reduces to thin-wall within ~5 % for D/t > 20
    assert abs(sigma_h - thin_hoop) / thin_hoop < 0.05


def test_lame_thick_wall_textbook_value() -> None:
    """Roark Table 32 — thick-walled cylinder Lamé at OD=100, ID=80, P=10."""

    sigma_h, sigma_l = native.lame_hoop_long_stress(P_MPa=10.0, OD_mm=100.0, ID_mm=80.0)
    # σ_h = P (Ro²+Ri²)/(Ro²-Ri²) = 10·(50²+40²)/(50²-40²) = 10·4100/900 = 45.56 MPa
    assert abs(sigma_h - 45.555) < 0.5
    # σ_l = P Ri²/(Ro²-Ri²) = 10·1600/900 = 17.78 MPa
    assert abs(sigma_l - 17.778) < 0.5


def test_t_min_thinning_cylinder_textbook() -> None:
    """ASME VIII Div 1 UG-27 cylinder formula sanity."""

    # P=2.5 MPa, R=250 mm, S=138 MPa, E=1.0
    # t = 2.5·250 / (138·1.0 - 0.6·2.5) = 625 / 136.5 ≈ 4.58 mm
    t = native.t_min_thinning(P_MPa=2.5, R_mm=250.0, S_MPa=138.0)
    assert abs(t - 4.578) < 0.05


def test_fad_curve_at_origin_and_collapse() -> None:
    """FAD curve: K_r(0) = 1.0; K_r(L_r > L_r_max) = 0 (collapse)."""

    assert abs(native.fad_curve_level_2A(0.0) - 1.0) < 1e-9
    # At L_r near 1, K_r should be on the order of 0.86 * 0.6 ~ 0.5 (sloping down)
    K_at_1 = native.fad_curve_level_2A(1.0)
    assert 0.5 < K_at_1 < 0.75
    # Beyond cutoff → 0
    assert native.fad_curve_level_2A(2.0, L_r_max=1.5) == 0.0


def test_wrs_profile_peak_at_weld_centerline() -> None:
    """Annex 9E: WRS peaks at d=0 (≈ +σ_y for circ-butt)."""

    sigma_y = 350.0
    peak = native.wrs_profile_api579_9e("circumferential-butt", 0.0, wall_mm=25.0, sigma_y_MPa=sigma_y)
    assert abs(peak - sigma_y) < 1.0
    # Far field — magnitude small
    far = native.wrs_profile_api579_9e("circumferential-butt", 200.0, wall_mm=25.0, sigma_y_MPa=sigma_y)
    assert abs(far) < 0.5 * sigma_y


def test_lbb_wuthrich_zero_stress_zero_COD() -> None:
    """Wüthrich 1982: δ(0) = 0 — no stress, no opening."""

    assert native.lbb_wuthrich_COD("plate", 0.0, 20.0, 207.0, 350.0) == 0.0


def test_lbb_wuthrich_below_yield_finite() -> None:
    """Below yield, δ > 0 and finite (Dugdale strip-yield)."""

    delta = native.lbb_wuthrich_COD("plate", 200.0, 50.0, 207.0, 350.0)
    assert delta > 0.0
    assert delta < 1.0  # mm, sane order of magnitude for steel


def test_nace_TM0284_HIC_severity_thresholds() -> None:
    """NACE TM0284: Sweet at low H, Severe at high H."""

    sweet = native.hic_nace_TM0284_severity(0.01, T_C=25.0)
    severe = native.hic_nace_TM0284_severity(50.0, T_C=25.0)
    assert sweet == "Sweet"
    assert severe == "Severe"


# ---------------------------------------------------------------------------
# 2. HTTP-vs-native parity — Part 5
# ---------------------------------------------------------------------------


PART5_CASES = [
    dict(
        geometry={"type": "cylinder", "OD_mm": 500, "wall_mm": 12.5},
        thickness=[12.5, 12.3, 12.1, 12.4, 12.5],
        T_C=400, P_MPa=2.5, material="SA-516-70",
        expected_level="Level-1",
    ),
    dict(
        geometry={"type": "cylinder", "OD_mm": 1000, "wall_mm": 20},
        thickness=[19.5, 19.3, 19.6, 19.7, 19.4],
        T_C=350, P_MPa=3.0, material="SA-516-70",
        expected_level="Level-1",
    ),
    dict(
        geometry={"type": "sphere", "OD_mm": 800, "wall_mm": 15.0},
        thickness=[14.5, 14.7, 14.3, 14.6, 14.4],
        T_C=300, P_MPa=4.0, material="SA-516-70",
        expected_level="Level-1",
    ),
    dict(
        geometry={"type": "cylinder", "OD_mm": 500, "wall_mm": 12.5},
        thickness=[10.2, 10.4, 10.1, 10.3, 10.5],
        T_C=400, P_MPa=2.5, material="SA-516-70",
        expected_level="Level-1",
    ),
    dict(
        geometry={"type": "cylinder", "OD_mm": 300, "wall_mm": 8},
        thickness=[7.8, 7.7, 7.6, 7.5, 7.9],
        T_C=200, P_MPa=2.0, material="SA-106-B",
        expected_level="Level-1",
    ),
]


@pytest.mark.parametrize("case", PART5_CASES, ids=lambda c: f"P{c['P_MPa']}_OD{c['geometry']['OD_mm']}")
def test_part5_native_vs_http_parity(httpx_mock, case: dict) -> None:
    """Part 5 envelope from HTTP must match native engine (verdict + RSF)."""

    # First, evaluate native to know what to mock
    native_env = native.run_ffs_part5_native(
        geometry=case["geometry"],
        thickness_map=case["thickness"],
        T_C=case["T_C"], P_MPa=case["P_MPa"],
        material={"spec": case["material"]},
    )
    # Mock the HTTP route with the SAME envelope native would produce.
    # Strip the local-only fields the worker doesn't echo back.
    mock_env = {
        "edition": native_env["edition"],
        "level": native_env["level"],
        "remaining_life_years": native_env["remaining_life_years"],
        "t_min_mm": native_env["t_min_mm"],
        "MAWP_MPa": native_env["MAWP_MPa"],
        "notes": native_env["notes"],
        "citations": native_env["citations"],
        "RSF": native_env["RSF"],
    }
    httpx_mock.add_response(url=PART5_URL, method="POST", json=mock_env)

    r_http = au.ffs.api_579_part_5(
        geometry=case["geometry"],
        thickness_map=case["thickness"],
        T_C=case["T_C"], P_MPa=case["P_MPa"],
        material=case["material"],
    )
    r_native = au.ffs.api_579_part_5(
        geometry=case["geometry"],
        thickness_map=case["thickness"],
        T_C=case["T_C"], P_MPa=case["P_MPa"],
        material=case["material"],
        backend="native",
    )
    assert r_http.level == r_native.level
    # within 5% on t_min and MAWP
    assert abs(r_http.t_min_mm - r_native.t_min_mm) / max(0.01, r_native.t_min_mm) < 0.05
    assert abs(r_http.MAWP_MPa - r_native.MAWP_MPa) / max(0.01, r_native.MAWP_MPa) < 0.05


# ---------------------------------------------------------------------------
# 3. Annex E5.1 — uniform thinning, Level-1 PASS
# ---------------------------------------------------------------------------


def test_annex_E5_1_uniform_thinning_native_level_1() -> None:
    """API 579-1 Annex E5.1 sample case → Level-1 acceptable.

    Geometry: cylinder OD=812.8 mm (32 in NPS 30), wall=15.875 mm (5/8 in).
    Thickness map: uniform 14.0 mm (slight uniform thinning).
    Material: SA-516-70. P=2.41 MPa, T=315°C.
    Expected verdict (Annex E5.1): t_meas (14 mm) > t_min (~4.4 mm) → Level-1 PASS.
    """

    res = native.run_ffs_part5_native(
        geometry={"type": "cylinder", "OD_mm": 812.8, "wall_mm": 15.875},
        thickness_map=[14.0, 14.0, 14.0, 14.0, 14.0],
        T_C=315, P_MPa=2.41,
        material={"spec": "SA-516-70"},
    )
    assert res["level"] == "Level-1"
    # t_min for SA-516-70 (S=138 MPa) at OD=812.8, R_i ≈ 405.4 mm:
    # t_min = 2.41 · 405.4 / (138·1 - 0.6·2.41) ≈ 7.18 mm
    assert 6.5 < res["t_min_mm"] < 8.0
    # MAWP should exceed operating pressure 2.41 MPa
    assert res["MAWP_MPa"] > 2.41


# ---------------------------------------------------------------------------
# 4. Annex E5.3 — LTA Folias overlay
# ---------------------------------------------------------------------------


def test_annex_E5_3_LTA_folias_derates_RSF() -> None:
    """Annex E5.3 LTA: 100 mm × 4 mm deep flaw in 12.5 mm wall.

    Expected: Folias §4.4.3.3 RSF in (0.7, 0.99); verdict Level-2 PASS
    (RSF >= 0.90) when 4 mm < 0.32 · 12.5 mm.
    """

    res = native.run_ffs_part5_native(
        geometry={"type": "cylinder", "OD_mm": 500.0, "wall_mm": 12.5},
        thickness_map=[12.5, 12.5, 12.5, 12.5],
        T_C=315, P_MPa=2.5,
        material={"spec": "SA-516-70"},
        lta={"s_mm": 100.0, "d_mm": 4.0},
    )
    assert res["level"] in {"Level-1", "Level-2"}
    assert 0.70 < res["RSF"] < 1.00


# ---------------------------------------------------------------------------
# 5. Annex E6.1 — pitting screening pass
# ---------------------------------------------------------------------------


def test_annex_E6_1_pitting_level_1_passes() -> None:
    """Light pitting (< 0.5·t_nom, density class ≤ 3) → Level-1 PASS."""

    pits = [{"max_depth_mm": 2.5, "diameter_mm": 3.0} for _ in range(5)]
    res = native.run_ffs_part6_native(
        geometry={"type": "cylinder", "OD_mm": 500, "wall_mm": 12.5},
        pit_data=pits,
        T_C=400, P_MPa=2.5,
        material={"spec": "SA-516-70"},
    )
    assert res["level"] == "Level-1"
    assert res["max_pit_depth_mm"] == 2.5


# ---------------------------------------------------------------------------
# 6. Annex E9.1 — surface crack inside FAD curve
# ---------------------------------------------------------------------------


def test_annex_E9_1_surface_crack_inside_FAD() -> None:
    """Small surface crack at moderate stress → operating point inside FAD.

    Crack a=3 mm, c=15 mm in 25 mm wall pressure-vessel under σ_m=100 MPa,
    σ_b=20 MPa. Material SA-516-70 with KIc=120 MPa√m.
    Expected: L_r < L_r_max and K_r < FAD curve → PASS / Level-2.
    """

    res = native.run_ffs_part9_native(
        geometry={"type": "cylinder", "OD_mm": 500.0, "wall_mm": 25.0},
        crack={"a_mm": 3.0, "c_mm": 15.0, "type": "surface"},
        sigma_membrane_MPa=100.0, sigma_bending_MPa=20.0,
        material={"sigma_y": 260.0, "sigma_uts": 485.0, "KIc_MPa_sqm": 120.0},
    )
    assert res["level"] == "Level-2"
    assert res["distance_to_curve"] > 1.0
    # FAD point components must be positive and L_r in a reasonable range
    L_r, K_r = res["fad_point"]
    assert 0 < L_r < 1.2
    assert 0 < K_r < 1.0


def test_part9_FAIL_when_above_FAD_curve() -> None:
    """Aggressive crack + high stress → operating point outside FAD."""

    res = native.run_ffs_part9_native(
        geometry={"type": "cylinder", "OD_mm": 500.0, "wall_mm": 20.0},
        crack={"a_mm": 15.0, "c_mm": 30.0, "type": "surface"},
        sigma_membrane_MPa=400.0, sigma_bending_MPa=80.0,
        material={"sigma_y": 260.0, "sigma_uts": 485.0, "KIc_MPa_sqm": 60.0},
    )
    assert res["level"] == "unacceptable"


# ---------------------------------------------------------------------------
# 7. HTTP-vs-native parity — Part 6
# ---------------------------------------------------------------------------


def test_part6_native_vs_http_parity(httpx_mock) -> None:
    """Part 6 pitting parity — same input → same verdict."""

    pits = [{"max_depth_mm": 3.0, "diameter_mm": 4.0} for _ in range(3)]
    native_env = native.run_ffs_part6_native(
        geometry={"type": "cylinder", "OD_mm": 500, "wall_mm": 12.5},
        pit_data=pits,
        T_C=400, P_MPa=2.5,
        material={"spec": "SA-516-70"},
    )
    mock_env = {
        "edition": native_env["edition"],
        "level": native_env["level"],
        "remaining_life_years": native_env["remaining_life_years"],
        "t_min_mm": native_env["t_min_mm"],
        "MAWP_MPa": native_env["MAWP_MPa"],
        "notes": native_env["notes"],
        "citations": native_env["citations"],
        "RSF": native_env["RSF"],
    }
    httpx_mock.add_response(url=PART6_URL, method="POST", json=mock_env)
    r_http = au.ffs.api_579_part_6(
        geometry={"type": "cylinder", "OD_mm": 500, "wall_mm": 12.5},
        pit_data=pits,
        T_C=400, P_MPa=2.5, material="SA-516-70",
    )
    r_native = au.ffs.api_579_part_6(
        geometry={"type": "cylinder", "OD_mm": 500, "wall_mm": 12.5},
        pit_data=pits,
        T_C=400, P_MPa=2.5, material="SA-516-70",
        backend="native",
    )
    assert r_http.level == r_native.level
    assert abs(r_http.MAWP_MPa - r_native.MAWP_MPa) / max(0.01, r_native.MAWP_MPa) < 0.05


# ---------------------------------------------------------------------------
# 8. HTTP-vs-native parity — Part 9
# ---------------------------------------------------------------------------


def test_part9_native_vs_http_parity(httpx_mock) -> None:
    """Part 9 FAD verdict parity."""

    crack = {"a_mm": 3.0, "c_mm": 15.0, "type": "surface"}
    geometry = {"type": "cylinder", "OD_mm": 500, "wall_mm": 25.0}
    material = {"sigma_y": 260.0, "sigma_uts": 485.0, "KIc_MPa_sqm": 120.0}
    native_env = native.run_ffs_part9_native(
        geometry=geometry,
        crack=crack,
        sigma_membrane_MPa=100.0, sigma_bending_MPa=20.0,
        material=material,
    )
    mock_env = {
        "edition": native_env["edition"],
        "level": native_env["level"],
        "remaining_life_years": native_env["remaining_life_years"],
        "t_min_mm": native_env["t_min_mm"],
        "MAWP_MPa": native_env["MAWP_MPa"],
        "notes": native_env["notes"],
        "citations": native_env["citations"],
        "fad_point": native_env["fad_point"],
        "distance_to_curve": native_env["distance_to_curve"],
    }
    httpx_mock.add_response(url=PART9_URL, method="POST", json=mock_env)

    r_http = au.ffs.api_579_part_9(
        geometry=geometry, crack=crack,
        sigma_membrane_MPa=100.0, sigma_bending_MPa=20.0,
        material=material,
    )
    r_native = au.ffs.api_579_part_9(
        geometry=geometry, crack=crack,
        sigma_membrane_MPa=100.0, sigma_bending_MPa=20.0,
        material=material,
        backend="native",
    )
    assert r_http.level == r_native.level
    # FAD point coordinates must agree closely
    assert abs(r_http.fad_point[0] - r_native.fad_point[0]) < 0.01
    assert abs(r_http.fad_point[1] - r_native.fad_point[1]) < 0.01


# ---------------------------------------------------------------------------
# 9. AUSTENITE_OFFLINE env-var hook
# ---------------------------------------------------------------------------


def test_offline_env_var_forces_native_ffs(monkeypatch) -> None:
    """AUSTENITE_OFFLINE=1 routes FFS through the in-process engine."""

    monkeypatch.setenv("AUSTENITE_OFFLINE", "1")
    r = au.ffs.api_579_part_5(
        geometry={"type": "cylinder", "OD_mm": 500, "wall_mm": 12.5},
        thickness_map=[12.5, 12.3, 12.4],
        T_C=400, P_MPa=2.5,
        material="SA-516-70",
    )
    # Offline path returns a usable verdict
    assert r.level in {"Level-1", "Level-2", "Level-3", "unacceptable"}
    assert r.t_min_mm > 0
    assert r.MAWP_MPa > 0


def test_backend_native_kwarg_forces_native_ffs() -> None:
    """backend='native' bypasses HTTP for any FFS call."""

    r = au.ffs.api_579_part_9(
        geometry={"type": "cylinder", "OD_mm": 500, "wall_mm": 25.0},
        crack={"a_mm": 3.0, "c_mm": 15.0, "type": "surface"},
        sigma_membrane_MPa=100.0, sigma_bending_MPa=20.0,
        material={"sigma_y": 260.0, "sigma_uts": 485.0, "KIc_MPa_sqm": 120.0},
        backend="native",
    )
    assert r.level in {"Level-2", "Level-3", "unacceptable"}
    assert r.fad_point is not None


# ---------------------------------------------------------------------------
# 10. Integration: 2024-09 vs 2021-12 edition tag
# ---------------------------------------------------------------------------


def test_edition_tag_echoed_native() -> None:
    """The native engine echoes the requested edition tag."""

    res_2021 = native.run_ffs_part9_native(
        geometry={"type": "cylinder", "OD_mm": 500.0, "wall_mm": 25.0},
        crack={"a_mm": 3.0, "c_mm": 15.0, "type": "surface"},
        sigma_membrane_MPa=100.0, sigma_bending_MPa=20.0,
        material={"sigma_y": 260.0, "sigma_uts": 485.0, "KIc_MPa_sqm": 120.0},
        edition="API 579-1 2021-12",
    )
    res_2024 = native.run_ffs_part9_native(
        geometry={"type": "cylinder", "OD_mm": 500.0, "wall_mm": 25.0},
        crack={"a_mm": 3.0, "c_mm": 15.0, "type": "surface"},
        sigma_membrane_MPa=100.0, sigma_bending_MPa=20.0,
        material={"sigma_y": 260.0, "sigma_uts": 485.0, "KIc_MPa_sqm": 120.0},
        edition="API 579-1 2024-09",
    )
    assert res_2021["edition"] == "API 579-1 2021-12"
    assert res_2024["edition"] == "API 579-1 2024-09"
    # Verdict identical (no FAD numerical change in 2024)
    assert res_2021["level"] == res_2024["level"]
    # But a 2024-only annotation should appear
    notes_2024 = " ".join(res_2024["notes"]).lower()
    assert "2024-09" in notes_2024 or "annex 9c" in notes_2024
