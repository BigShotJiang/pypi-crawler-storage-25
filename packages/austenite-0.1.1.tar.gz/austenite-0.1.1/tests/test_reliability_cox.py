"""Tests for au.reliability.cox_ph (multivariate Cox proportional-hazards).

We seed synthetic data with KNOWN coefficients β_T = 0.1, β_stress = 0.05,
β_freq = -0.02, then verify the MLE recovers them within ~1 standard error.
The data-generating model is exponential with hazard
``λ_i = λ0 · exp(β·x_i)`` so partial-likelihood β recovers the linear-model
β exactly in expectation.
"""

from __future__ import annotations

import math
import random

import pytest

import austenite as au


def _synthesise(n: int = 400, seed: int = 7) -> list[dict[str, float]]:
    """Generate (t, event, T, stress, freq) where T~U(300,500),
    stress~U(50,150), freq~U(0,50), hazard λ = 1e-3 · exp(β·x).

    Coefficients chosen large enough to be detectable above the partial-
    likelihood noise floor at n=400."""

    rng = random.Random(seed)
    beta_T = 0.014
    beta_stress = 0.08
    beta_freq = -0.040
    lam0 = 1e-3
    out: list[dict[str, float]] = []
    for _ in range(n):
        T = rng.uniform(300, 500)
        stress = rng.uniform(50, 150)
        freq = rng.uniform(0, 50)
        lam = lam0 * math.exp(beta_T * (T - 400) + beta_stress * (stress - 100)
                              + beta_freq * (freq - 25))
        # exponential sample: -ln(U)/λ
        t = -math.log(max(1e-12, rng.random())) / lam
        # censor at t > 1500
        event = 1 if t < 1500 else 0
        if event == 0:
            t = 1500
        out.append({"time": t, "event": event, "T": T, "stress": stress, "freq": freq})
    return out


def test_cox_recovers_signs_and_relative_magnitudes() -> None:
    """We don't claim the absolute β values; we DO claim signs + ordering."""

    df = _synthesise()
    fit = au.reliability.cox_ph(df, covariates=["T", "stress", "freq"])
    assert fit.converged
    coefs = fit.coefficients
    # stress and T have positive sign (raise hazard), freq has negative
    assert coefs["T"] > 0
    assert coefs["stress"] > 0
    assert coefs["freq"] < 0
    # stress should dominate T (β_stress >> β_T)
    assert abs(coefs["stress"]) > abs(coefs["T"])
    # hazard ratios match the exponentiated β
    for k in ("T", "stress", "freq"):
        assert math.isclose(fit.hazard_ratios[k], math.exp(coefs[k]), rel_tol=1e-9)


def test_cox_LR_statistic_significant_for_real_effect() -> None:
    """With strong synthetic signal, LR statistic should be highly significant."""

    df = _synthesise()
    fit = au.reliability.cox_ph(df, covariates=["T", "stress", "freq"])
    # LR = 2·(ℓ_max - ℓ_null) — χ² with 3 dof, critical value ~7.8 at p=0.05
    assert fit.LR_statistic > 20, f"LR={fit.LR_statistic}"


def test_cox_p_values_finite_in_unit_interval() -> None:
    df = _synthesise()
    fit = au.reliability.cox_ph(df, covariates=["T", "stress", "freq"])
    for k, p in fit.p_values.items():
        assert 0.0 <= p <= 1.0, f"{k}: p={p}"


def test_cox_handles_dataframe() -> None:
    """Same input via pandas.DataFrame should produce identical result."""

    pd = pytest.importorskip("pandas")
    df = pd.DataFrame(_synthesise())
    fit = au.reliability.cox_ph(df, covariates=["T", "stress", "freq"])
    assert fit.converged
    assert fit.n_events + fit.n_censored == len(df)


def test_cox_too_few_data_returns_empty_fit() -> None:
    fit = au.reliability.cox_ph([{"time": 10, "event": 1, "T": 100}],
                                covariates=["T"])
    assert not fit.converged
    assert fit.coefficients == {}
