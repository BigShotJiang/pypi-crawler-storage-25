"""Tests for the 3-D EBSD reconstruction + 5-DOF GB property graph.

Covers the synthesise → reconstruct → GB-graph → texture pipeline,
including:

* GB count consistency between the voxel volume and the graph.
* Partition of grain IDs across the GB pair set.
* Σ3 (FCC coherent twin) detection on a deliberately twinned pair.
* R-bar (Lankford average) in the expected range for cube-textured FCC.
* ODF max-intensity scales with the spread of an injected component.
* IPF stereographic projection coordinates lie inside the FCC
  standard triangle.
* CSL classifier is consistent with the Brandon 1966 criterion.
* Cubic symmetry: 24 distinct operators returned by the symmetry
  generator.
"""

from __future__ import annotations

import math

import numpy as np
import pytest


import austenite as au


# ---------------------------------------------------------------------------
# Synthesise + GB graph round-trip
# ---------------------------------------------------------------------------


def test_synthesize_returns_well_formed_mesh() -> None:
    mesh = au.ebsd_3d.synthesize(n_grains=30, shape=(12, 12, 12), seed=1)
    assert mesh.shape == (12, 12, 12)
    assert mesh.n_grains == 30
    assert mesh.orientations_bunge.shape == (30, 3)
    # Every Bunge triple is in the canonical range
    assert (0.0 <= mesh.orientations_bunge[:, 0]).all() and (mesh.orientations_bunge[:, 0] < 2.0 * math.pi + 1e-6).all()
    assert (0.0 <= mesh.orientations_bunge[:, 1]).all() and (mesh.orientations_bunge[:, 1] <= math.pi + 1e-6).all()
    assert (0.0 <= mesh.orientations_bunge[:, 2]).all() and (mesh.orientations_bunge[:, 2] < 2.0 * math.pi + 1e-6).all()


def test_synthesize_then_gb_graph_counts_consistent() -> None:
    """GB count from the voxel-face walk equals the per-pair sum."""

    mesh = au.ebsd_3d.synthesize(n_grains=20, shape=(12, 12, 12), seed=2)
    network = au.ebsd_3d.gb_property_graph(mesh)
    assert isinstance(network, au.ebsd_3d.GBNetwork)
    # Sum n_voxels over all segments == total differing voxel faces
    total_segment_voxels = sum(seg.n_voxels for seg in network.segments)
    # Independent count: walk axis-aligned faces
    v = mesh.voxels
    diff_x = (v[:, :, :-1] != v[:, :, 1:]).sum()
    diff_y = (v[:, :-1, :] != v[:, 1:, :]).sum()
    diff_z = (v[:-1, :, :] != v[1:, :, :]).sum()
    expected = int(diff_x + diff_y + diff_z)
    assert total_segment_voxels == expected


def test_gb_graph_records_5_dof_per_segment() -> None:
    """Every segment carries 3 misorientation Eulers + 2 inclination angles."""

    mesh = au.ebsd_3d.synthesize(n_grains=20, shape=(12, 12, 12), seed=3)
    network = au.ebsd_3d.gb_property_graph(mesh)
    assert len(network.segments) > 0
    for seg in network.segments:
        assert seg.misorientation_bunge_rad.shape == (3,)
        assert math.isfinite(seg.misorientation_angle_rad)
        assert 0.0 <= seg.misorientation_angle_rad <= math.pi
        assert math.isfinite(seg.inclination_theta_rad)
        assert math.isfinite(seg.inclination_phi_rad)
        # GB energy is non-negative and below the high-angle plateau
        assert 0.0 <= seg.gb_energy_J_m2 <= 1.0


# ---------------------------------------------------------------------------
# Σ3 (FCC coherent twin) detection
# ---------------------------------------------------------------------------


def test_sigma3_detected_on_injected_twin() -> None:
    """A pair of grains separated by an exact 60° rotation about <111>
    must be classified as Σ3 by the Brandon 1966 criterion."""

    # Build a 2-grain volume: left half = grain 0 at identity, right
    # half = grain 1 at exact 60°<111> rotation of grain 0.
    voxels = np.zeros((4, 4, 8), dtype=np.int32)
    voxels[:, :, 4:] = 1
    # Bunge for identity:
    ori0 = np.array([0.0, 0.0, 0.0])
    # Bunge for 60°<111> rotation: convert axis-angle to matrix → Bunge
    axis = np.array([1.0, 1.0, 1.0]) / math.sqrt(3.0)
    theta = math.radians(60.0)
    c, s = math.cos(theta), math.sin(theta)
    K = np.array([[0, -axis[2], axis[1]], [axis[2], 0, -axis[0]], [-axis[1], axis[0], 0]])
    R = np.eye(3) * c + (1.0 - c) * np.outer(axis, axis) + s * K
    from austenite.ebsd_3d import _matrix_to_bunge

    ori1 = np.array(_matrix_to_bunge(R))
    orientations = np.stack([ori0, ori1], axis=0)

    mesh = au.ebsd_3d.Ebsd3DMesh(
        voxels=voxels,
        grain_ids=np.array([0, 1]),
        orientations_bunge=orientations,
        voxel_size_um=0.5,
    )
    network = au.ebsd_3d.gb_property_graph(mesh)
    assert len(network.segments) == 1
    seg = network.segments[0]
    assert seg.sigma == 3
    # Σ3 GB energy is set to 0.04 J/m² in our Morawiec fit
    assert math.isclose(seg.gb_energy_J_m2, 0.04, rel_tol=1e-6)
    # Twin fraction reads correctly from network summary
    assert network.twin_fraction > 0.99


def test_low_angle_boundary_detected() -> None:
    """A 5° rotation about <001> is well inside the Read-Shockley regime."""

    voxels = np.zeros((4, 4, 8), dtype=np.int32)
    voxels[:, :, 4:] = 1
    axis = np.array([0.0, 0.0, 1.0])
    theta = math.radians(5.0)
    c, s = math.cos(theta), math.sin(theta)
    K = np.array([[0, -axis[2], axis[1]], [axis[2], 0, -axis[0]], [-axis[1], axis[0], 0]])
    R = np.eye(3) * c + (1.0 - c) * np.outer(axis, axis) + s * K
    from austenite.ebsd_3d import _matrix_to_bunge

    ori1 = np.array(_matrix_to_bunge(R))
    orientations = np.stack([np.zeros(3), ori1], axis=0)
    mesh = au.ebsd_3d.Ebsd3DMesh(
        voxels=voxels,
        grain_ids=np.array([0, 1]),
        orientations_bunge=orientations,
        voxel_size_um=0.5,
    )
    network = au.ebsd_3d.gb_property_graph(mesh)
    seg = network.segments[0]
    assert seg.sigma == -1, f"expected low-angle (-1); got {seg.sigma}"
    # Read-Shockley energy is below the high-angle plateau
    assert seg.gb_energy_J_m2 < 0.7
    # And below the 15° saturation
    assert math.degrees(seg.misorientation_angle_rad) <= 6.0


# ---------------------------------------------------------------------------
# Texture
# ---------------------------------------------------------------------------


def test_bunge_odf_returns_finite_metrics() -> None:
    mesh = au.ebsd_3d.synthesize(n_grains=40, shape=(12, 12, 12), seed=4)
    texture = au.ebsd_3d.bunge_odf(mesh)
    assert isinstance(texture, au.ebsd_3d.TextureODF)
    assert math.isfinite(texture.max_intensity_x_random)
    assert texture.max_intensity_x_random > 0.0
    # r-bar is in [0, 1] for FCC (textbook range under uniaxial tension)
    assert 0.0 <= texture.r_bar <= 1.0
    assert texture.n_grains_used == 40


def test_bunge_odf_sharper_texture_higher_intensity() -> None:
    """Tight component spread → higher ODF peak."""

    mesh_tight = au.ebsd_3d.synthesize(
        n_grains=80,
        shape=(12, 12, 12),
        texture_components=[("cube", 1.0)],
        spread_deg=2.0,
        seed=11,
    )
    mesh_loose = au.ebsd_3d.synthesize(
        n_grains=80,
        shape=(12, 12, 12),
        texture_components=[("cube", 1.0)],
        spread_deg=20.0,
        seed=11,
    )
    tex_tight = au.ebsd_3d.bunge_odf(mesh_tight)
    tex_loose = au.ebsd_3d.bunge_odf(mesh_loose)
    assert tex_tight.max_intensity_x_random > tex_loose.max_intensity_x_random


def test_inverse_pole_figure_inside_standard_triangle() -> None:
    """All stereographic points lie inside the FCC standard triangle.

    The standard cubic triangle has 0 ≤ x ≤ y ≤ 0.5 in our projection
    convention (after sorting components by |v_i|).
    """

    mesh = au.ebsd_3d.synthesize(n_grains=30, shape=(12, 12, 12), seed=5)
    ipf = au.ebsd_3d.inverse_pole_figure(mesh, "z")
    assert ipf.stereographic_xy.shape == (30, 2)
    x = ipf.stereographic_xy[:, 0]
    y = ipf.stereographic_xy[:, 1]
    assert (x >= -1e-9).all()
    assert (y >= -1e-9).all()
    # After sorting |v| ascending the projection lies inside the cube
    # standard triangle (a subregion of the unit disc).
    assert (x <= y + 1e-9).all(), f"x > y: {x[x > y + 1e-9]}, {y[x > y + 1e-9]}"
    assert math.isfinite(ipf.max_density)


# ---------------------------------------------------------------------------
# Cubic symmetry
# ---------------------------------------------------------------------------


def test_cubic_symmetry_has_24_operators() -> None:
    """The cubic proper-rotation point group is order 24."""

    from austenite.ebsd_3d import _get_cubic_ops

    ops = _get_cubic_ops()
    assert ops.shape == (24, 3, 3)
    # Every operator is a rotation: det == +1 and R R^T == I
    for R in ops:
        assert math.isclose(float(np.linalg.det(R)), 1.0, abs_tol=1e-6)
        assert np.allclose(R @ R.T, np.eye(3), atol=1e-6)


# ---------------------------------------------------------------------------
# Reconstruct from slices
# ---------------------------------------------------------------------------


def test_reconstruct_from_numpy_slices() -> None:
    """Build a 3-D volume from a list of 2-D numpy slices."""

    rng = np.random.default_rng(7)
    n_grains = 12
    slice0 = rng.integers(0, n_grains, size=(8, 8)).astype(np.int32)
    slice1 = rng.integers(0, n_grains, size=(8, 8)).astype(np.int32)
    slice2 = rng.integers(0, n_grains, size=(8, 8)).astype(np.int32)
    ori = np.zeros((n_grains, 3))
    ori[:, 0] = np.linspace(0.0, math.pi, n_grains)
    mesh = au.ebsd_3d.reconstruct(
        [slice0, slice1, slice2],
        stack_axis="z",
        voxel_size_um=1.0,
        orientations_bunge=ori,
    )
    assert mesh.shape == (3, 8, 8)
    assert mesh.orientations_bunge.shape[0] >= n_grains
    # GB graph runs without exception on a stacked volume
    gb = au.ebsd_3d.gb_property_graph(mesh)
    assert len(gb.segments) > 0


def test_reconstruct_rejects_invalid_stack_axis() -> None:
    with pytest.raises(ValueError):
        au.ebsd_3d.reconstruct([np.zeros((4, 4), dtype=np.int32)], stack_axis="q")
