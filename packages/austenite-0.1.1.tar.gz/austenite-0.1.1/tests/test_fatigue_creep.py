"""Tests for au.fatigue.creep_fatigue — LMP + Wilshire + Robinson + ASME III NH-T1100."""
from __future__ import annotations

import math
import pytest

from austenite.fatigue.creep_fatigue import (
    CreepBlock,
    CreepFatigueResult,
    ECCC_LMP_LIBRARY,
    creep_fatigue_interaction,
    eccc_LMP_lookup,
    larson_miller_parameter,
    manson_haferd_parameter,
    norton_bailey_strain_rate,
    robinson_damage,
    time_from_LMP,
    wilshire_rupture_life_hours,
)


# ---------------------------------------------------------------------------
# Larson-Miller
# ---------------------------------------------------------------------------


def test_larson_miller_basic():
    # 2.25Cr-1Mo at 540°C (813 K) ruptures at ~10,000 h at LMP=32500
    # LMP = T·(C + log10(t)) = 813 · (20 + 4) = 19512  (not quite reaching 32500)
    # Just verify the formula:
    lmp = larson_miller_parameter(T_K=813, t_rupture_hours=10000, C=20)
    expected = 813 * (20 + 4)
    assert math.isclose(lmp, expected, rel_tol=1e-3)


def test_larson_miller_inverse():
    """time_from_LMP should be the inverse of larson_miller_parameter."""
    lmp = larson_miller_parameter(T_K=813, t_rupture_hours=10000, C=20)
    t = time_from_LMP(lmp, T_K=813, C=20)
    assert math.isclose(t, 10000, rel_tol=1e-3)


def test_larson_miller_nan_input():
    assert math.isnan(larson_miller_parameter(T_K=float("nan"), t_rupture_hours=1000, C=20))


def test_larson_miller_negative_time_returns_nan():
    assert math.isnan(larson_miller_parameter(T_K=813, t_rupture_hours=-1, C=20))


# ---------------------------------------------------------------------------
# Manson-Haferd
# ---------------------------------------------------------------------------


def test_manson_haferd_basic():
    mhp = manson_haferd_parameter(T_K=813, t_rupture_hours=10000)
    assert math.isfinite(mhp)


# ---------------------------------------------------------------------------
# Wilshire theta-projection
# ---------------------------------------------------------------------------


def test_wilshire_returns_finite_rupture_life():
    # 9Cr-1Mo at 873 K, 100 MPa
    t_r = wilshire_rupture_life_hours(
        sigma_MPa=100, T_K=873,
        sigma_uts_at_T_MPa=400, Q_kJ_mol=350, k_constant=26.0e-3, u_exponent=7.2,
    )
    assert math.isfinite(t_r)
    assert t_r > 0


def test_wilshire_lower_stress_longer_life():
    """Same alloy at lower stress should give longer rupture life."""
    t_high = wilshire_rupture_life_hours(
        sigma_MPa=150, T_K=873,
        sigma_uts_at_T_MPa=400, Q_kJ_mol=350, k_constant=26.0e-3, u_exponent=7.2,
    )
    t_low = wilshire_rupture_life_hours(
        sigma_MPa=80, T_K=873,
        sigma_uts_at_T_MPa=400, Q_kJ_mol=350, k_constant=26.0e-3, u_exponent=7.2,
    )
    assert t_low > t_high


# ---------------------------------------------------------------------------
# Robinson life-fraction
# ---------------------------------------------------------------------------


def test_robinson_damage_basic():
    """Use ECCC library to compute rupture life."""

    blocks = [
        CreepBlock(stress_MPa=100, temperature_K=813, duration_hours=2000),
        CreepBlock(stress_MPa=80, temperature_K=813, duration_hours=5000),
    ]
    lookup = lambda s: eccc_LMP_lookup("2.25Cr-1Mo", s)
    r = robinson_damage(blocks, sigma_LMP_lookup=lookup)
    assert "damage" in r and "passed" in r
    assert math.isfinite(r["damage"]) or math.isinf(r["damage"])
    assert len(r["blocks"]) == 2


def test_robinson_damage_zero_blocks():
    r = robinson_damage([], sigma_LMP_lookup=lambda s: 30000)
    assert r["damage"] == 0
    assert r["passed"] is True


# ---------------------------------------------------------------------------
# ASME III NH-T1100 creep-fatigue interaction
# ---------------------------------------------------------------------------


def test_creep_fatigue_safe_point_passes():
    """(D_creep, D_fatigue) = (0.05, 0.05) is well inside the austenitic envelope."""
    r = creep_fatigue_interaction(D_fatigue=0.05, D_creep=0.05, envelope="austenitic")
    assert isinstance(r, CreepFatigueResult)
    assert r.passed
    assert r.envelope_value < 0


def test_creep_fatigue_at_envelope_corner_marginal():
    """Pure-fatigue intercept (0.0, 1.0) lies on the bilinear boundary."""
    r = creep_fatigue_interaction(D_fatigue=1.0, D_creep=0.0, envelope="austenitic")
    assert math.isclose(r.envelope_value, 0.0, abs_tol=0.01)


def test_creep_fatigue_knee_point_on_boundary():
    """The knee (0.3, 0.3) is exactly on the austenitic boundary."""
    r = creep_fatigue_interaction(D_fatigue=0.30, D_creep=0.30, envelope="austenitic")
    assert math.isclose(r.envelope_value, 0.0, abs_tol=0.02)
    assert r.passed


def test_creep_fatigue_quarter_quarter_passes_austenitic():
    """(0.25, 0.25) is inside the austenitic envelope (a single-line
    D_c+D_f<=0.3 rule would wrongly reject it)."""
    r = creep_fatigue_interaction(D_fatigue=0.25, D_creep=0.25, envelope="austenitic")
    assert r.passed
    assert r.envelope_value < 0


def test_creep_fatigue_outside_envelope_fails():
    # D_creep=0.5 is past the knee; allowable D_f ~0.214, so D_f=0.8 fails.
    r = creep_fatigue_interaction(D_fatigue=0.80, D_creep=0.50, envelope="austenitic")
    assert not r.passed
    assert r.envelope_value > 0


def test_creep_fatigue_ferritic_more_restrictive():
    """Same point: passes in austenitic envelope but fails in ferritic."""
    point = dict(D_fatigue=0.15, D_creep=0.05)
    r_aust = creep_fatigue_interaction(**point, envelope="austenitic")
    r_ferr = creep_fatigue_interaction(**point, envelope="ferritic")
    assert r_aust.envelope_value < r_ferr.envelope_value


# ---------------------------------------------------------------------------
# Norton-Bailey strain rate
# ---------------------------------------------------------------------------


def test_norton_bailey_basic():
    eps_dot = norton_bailey_strain_rate(
        sigma_MPa=100, T_K=813,
        A=1.5e-10, n=5.0, Q_kJ_mol=350,
    )
    assert math.isfinite(eps_dot)
    assert eps_dot >= 0


def test_norton_bailey_higher_T_higher_strain_rate():
    eps_low = norton_bailey_strain_rate(sigma_MPa=100, T_K=773, A=1.5e-10, n=5, Q_kJ_mol=350)
    eps_high = norton_bailey_strain_rate(sigma_MPa=100, T_K=873, A=1.5e-10, n=5, Q_kJ_mol=350)
    assert eps_high > eps_low


def test_norton_bailey_higher_stress_higher_strain_rate():
    eps_low = norton_bailey_strain_rate(sigma_MPa=50, T_K=813, A=1.5e-10, n=5, Q_kJ_mol=350)
    eps_high = norton_bailey_strain_rate(sigma_MPa=200, T_K=813, A=1.5e-10, n=5, Q_kJ_mol=350)
    assert eps_high > eps_low


def test_norton_bailey_nan_input():
    assert math.isnan(norton_bailey_strain_rate(sigma_MPa=float("nan"), T_K=813, A=1, n=1, Q_kJ_mol=1))


# ---------------------------------------------------------------------------
# ECCC library
# ---------------------------------------------------------------------------


def test_eccc_library_has_4_alloys():
    assert "2.25Cr-1Mo" in ECCC_LMP_LIBRARY
    assert "9Cr-1Mo" in ECCC_LMP_LIBRARY
    assert "316H" in ECCC_LMP_LIBRARY
    assert "Inconel 617" in ECCC_LMP_LIBRARY


def test_eccc_library_all_have_citations():
    for alloy, data in ECCC_LMP_LIBRARY.items():
        assert "citation" in data and len(data["citation"]) > 0


def test_eccc_lookup_unknown_alloy_returns_nan():
    assert math.isnan(eccc_LMP_lookup("UnknownAlloy", 100))


def test_eccc_lookup_higher_stress_lower_LMP():
    """Higher applied stress → shorter rupture life → lower LMP."""
    lmp_low = eccc_LMP_lookup("2.25Cr-1Mo", 50)
    lmp_high = eccc_LMP_lookup("2.25Cr-1Mo", 150)
    assert lmp_low > lmp_high
