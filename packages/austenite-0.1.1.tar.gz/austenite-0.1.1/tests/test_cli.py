"""Tests for the ``austenite`` CLI.

Uses :class:`click.testing.CliRunner` so the CLI is invoked in-process
(no subprocess); HTTP is mocked via ``pytest-httpx`` exactly as the other
test modules.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from click.testing import CliRunner

import austenite as au
from austenite.cli import cli, EXIT_OK, EXIT_ERROR, EXIT_VALIDATION


BASE = "https://api-test.austenite.org"


# ---------------------------------------------------------------------------
# Plumbing: version, --help, --no-color
# ---------------------------------------------------------------------------


def test_version_command_prints_semver() -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["version"])
    assert result.exit_code == EXIT_OK
    assert "austenite" in result.output
    assert au.__version__ in result.output


def test_top_level_help_lists_subcommands() -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["--help"])
    assert result.exit_code == EXIT_OK
    for cmd in ("design-path", "am", "mtc", "ttt", "calphad", "bayesian",
                "ffs", "benchmark", "plugins", "version"):
        assert cmd in result.output


def test_nested_help_works_at_every_level() -> None:
    runner = CliRunner()
    for group in ("am", "mtc", "ttt", "calphad", "bayesian", "ffs", "benchmark", "plugins"):
        result = runner.invoke(cli, [group, "--help"])
        assert result.exit_code == EXIT_OK, f"{group} --help failed"
        assert group in result.output.lower() or "Commands:" in result.output


def test_version_option_flag() -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["--version"])
    assert result.exit_code == EXIT_OK
    assert au.__version__ in result.output


# ---------------------------------------------------------------------------
# design-path
# ---------------------------------------------------------------------------


def test_design_path_writes_json_file(tmp_path: Path, httpx_mock) -> None:
    httpx_mock.add_response(
        url=f"{BASE}/v1/design-path",
        method="POST",
        status_code=200,
        json={"properties": {"sigma_y_MPa": 1535, "sigma_uts_MPa": 1700,
                             "elongation_pct": 11.2}},
    )
    out = tmp_path / "result.json"
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["design-path", "--alloy", "AISI 4140", "--cooling", "10",
         "--json", str(out)],
    )
    assert result.exit_code == EXIT_OK, result.output
    payload = json.loads(out.read_text(encoding="utf-8"))
    assert payload["properties"]["sigma_y_MPa"] == 1535


def test_design_path_validation_error_without_alloy_or_composition() -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["design-path", "--cooling", "10"])
    assert result.exit_code == EXIT_VALIDATION
    assert "supply either --alloy or --composition" in result.output


def test_design_path_parses_composition_eq_syntax(tmp_path: Path, httpx_mock) -> None:
    httpx_mock.add_response(
        url=f"{BASE}/v1/design-path",
        method="POST", status_code=200,
        json={"properties": {"sigma_y_MPa": 700}},
    )
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["design-path", "--composition", "Fe=0.97,Cr=0.011,Mn=0.008",
         "--cooling", "10"],
    )
    assert result.exit_code == EXIT_OK, result.output
    request = httpx_mock.get_requests()[-1]
    body = request.read().decode("utf-8")
    assert "0.97" in body
    assert "0.011" in body


def test_design_path_parses_composition_json_syntax(httpx_mock) -> None:
    httpx_mock.add_response(
        url=f"{BASE}/v1/design-path",
        method="POST", status_code=200,
        json={"properties": {"sigma_y_MPa": 700}},
    )
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["design-path", "--composition", '{"Fe":0.97,"Cr":0.011}',
         "--cooling", "10"],
    )
    assert result.exit_code == EXIT_OK, result.output


def test_design_path_bad_composition_returns_validation_code() -> None:
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["design-path", "--composition", "junk-no-equals", "--cooling", "10"],
    )
    # Either Click usage error (2) or our explicit EXIT_VALIDATION (2) — both same.
    assert result.exit_code == EXIT_VALIDATION
    assert "junk-no-equals" in result.output or "bad" in result.output.lower()


# ---------------------------------------------------------------------------
# am
# ---------------------------------------------------------------------------


def test_am_qualification_happy_path(httpx_mock) -> None:
    httpx_mock.add_response(
        url=f"{BASE}/v1/am/qualification",
        method="POST", status_code=200,
        json={
            "energy_density_J_mm3": 67.3,
            "melt_pool_regime": "keyhole",
            "porosity_pct": 0.4,
            "properties": {"sigma_y_MPa": 1080},
            "citations": [],
        },
    )
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["am", "qualification",
         "--alloy", "IN718",
         "-P", "285", "-v", "960", "-h", "110", "-t", "40"],
    )
    assert result.exit_code == EXIT_OK, result.output
    assert "1080" in result.output


def test_am_qualification_help_lists_required_flags() -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["am", "qualification", "--help"])
    assert result.exit_code == EXIT_OK
    assert "--alloy" in result.output


# ---------------------------------------------------------------------------
# ttt
# ---------------------------------------------------------------------------


def test_ttt_cct_sweep_parses_rates(httpx_mock) -> None:
    httpx_mock.add_response(
        url=f"{BASE}/v1/ttt/cct-sweep",
        method="POST", status_code=200,
        json={
            "curves": [],
            "final_microstructure": [
                {"V": 1.0, "HV30": 240},
                {"V": 10.0, "HV30": 480},
                {"V": 100.0, "HV30": 650},
            ],
        },
    )
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["ttt", "cct-sweep",
         "--composition", "C=0.41,Mn=0.85,Cr=0.95,Mo=0.20",
         "--rates", "1,10,100"],
    )
    assert result.exit_code == EXIT_OK, result.output
    request = httpx_mock.get_requests()[-1]
    body = json.loads(request.read().decode("utf-8"))
    assert body["cooling_rates_C_s"] == [1.0, 10.0, 100.0]


def test_ttt_cct_sweep_validation_without_alloy_or_composition() -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["ttt", "cct-sweep", "--rates", "10"])
    assert result.exit_code == EXIT_VALIDATION


# ---------------------------------------------------------------------------
# calphad
# ---------------------------------------------------------------------------


def test_calphad_equilibrium_offline(monkeypatch) -> None:
    """With AUSTENITE_OFFLINE=1 the native solver runs without any HTTP."""

    monkeypatch.setenv("AUSTENITE_OFFLINE", "1")
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["calphad", "equilibrium",
         "--composition", "Fe=0.74,Cr=0.18,Ni=0.08",
         "--T", "1273",
         "--backend", "native"],
    )
    assert result.exit_code == EXIT_OK, result.output
    payload = json.loads(result.output)
    assert "phases" in payload


def test_calphad_equilibrium_empty_composition_validation() -> None:
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["calphad", "equilibrium", "--composition", "", "--T", "1273", "--backend", "native"],
    )
    # empty composition string fails our _parse_composition path
    assert result.exit_code == EXIT_VALIDATION


# ---------------------------------------------------------------------------
# plugins
# ---------------------------------------------------------------------------


def test_plugins_list_handles_no_plugins() -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["plugins", "list"])
    assert result.exit_code == EXIT_OK
    # Either '(no plugins installed)' or a list of plugin names.
    assert result.output


def test_plugins_list_json_output(tmp_path: Path) -> None:
    out = tmp_path / "plugins.json"
    runner = CliRunner()
    result = runner.invoke(cli, ["plugins", "list", "--json", str(out)])
    assert result.exit_code == EXIT_OK, result.output
    payload = json.loads(out.read_text(encoding="utf-8"))
    assert "plugins" in payload
    assert isinstance(payload["plugins"], list)


# ---------------------------------------------------------------------------
# benchmark
# ---------------------------------------------------------------------------


def test_benchmark_run_all_smoke() -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["benchmark", "run-all"])
    # The benchmark suite returns SKIP for network-bound cases — exit
    # code may be 0 if no failures. We just verify it runs and prints.
    assert "benchmark:" in result.output
    assert result.exit_code in (EXIT_OK, EXIT_ERROR)


# ---------------------------------------------------------------------------
# --quiet / --verbose / --no-color smoke test
# ---------------------------------------------------------------------------


def test_quiet_flag_suppresses_wrote_message(tmp_path: Path, httpx_mock) -> None:
    httpx_mock.add_response(
        url=f"{BASE}/v1/design-path",
        method="POST", status_code=200,
        json={"properties": {"sigma_y_MPa": 1500}},
    )
    out = tmp_path / "r.json"
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["--quiet", "design-path", "--alloy", "AISI 4140", "--cooling", "10",
         "--json", str(out)],
    )
    assert result.exit_code == EXIT_OK, result.output
    assert "wrote" not in result.output
    assert out.exists()


def test_no_color_flag_disables_ansi() -> None:
    runner = CliRunner()
    # Cause a known error path
    result = runner.invoke(cli, ["--no-color", "design-path", "--cooling", "10"])
    assert result.exit_code == EXIT_VALIDATION
    # No ANSI escapes
    assert "\x1b[" not in result.output


# ---------------------------------------------------------------------------
# Engine error → exit 1
# ---------------------------------------------------------------------------


def test_design_path_engine_error_returns_exit_1(httpx_mock) -> None:
    # Client retries 5xx (max_retries=2 in conftest). Register optional
    # extras so pytest-httpx tolerates 1-2 retry attempts.
    httpx_mock.add_response(
        url=f"{BASE}/v1/design-path",
        method="POST", status_code=500,
        json={"error": "boom"},
    )
    httpx_mock.add_response(
        url=f"{BASE}/v1/design-path",
        method="POST", status_code=500,
        json={"error": "boom"},
        is_optional=True,
    )
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["design-path", "--alloy", "AISI 4140", "--cooling", "10"],
    )
    assert result.exit_code == EXIT_ERROR
    assert "failed" in result.output.lower() or "error" in result.output.lower()
