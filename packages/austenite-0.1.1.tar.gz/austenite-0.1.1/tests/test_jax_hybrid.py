"""Tests for the hybrid NSGA-II + JAX-gradient au.design() optimiser.

Covers the in-house NSGA-II (non-dominated sort, crowding distance,
hypervolume / IGD diagnostics) plus the L-BFGS polishing step.
"""

from __future__ import annotations

import math

import numpy as np
import pytest


jax = pytest.importorskip("jax")
jnp = pytest.importorskip("jax.numpy")


# ---------------------------------------------------------------------------
# 1. Sanity: design_hybrid returns a polished Pareto front
# ---------------------------------------------------------------------------


def test_design_hybrid_runs_on_toy_objective() -> None:
    """Hybrid optimiser solves a classic 2-obj convex toy problem (ZDT1-style).

    f1(x) = x[0]
    f2(x) = 1 - sqrt(x[0])
    Pareto front is the convex curve x[0] in [0, 1].
    """

    from austenite.jax_backend import design_hybrid, HybridDesignResult

    def obj(x):
        return np.array([x[0], 1.0 - math.sqrt(max(x[0], 0.0))])

    r = design_hybrid(
        objective_fn=obj,
        bounds=[(0.0, 1.0)],
        n_population=20,
        n_generations=5,
        polish_iter=5,
        seed=0,
    )
    assert isinstance(r, HybridDesignResult)
    assert r.pareto_front_x.ndim == 2
    assert r.pareto_front_f.ndim == 2
    assert r.pareto_front_x.shape[1] == 1
    assert r.pareto_front_f.shape[1] == 2
    assert r.n_evaluations > 0
    assert r.n_generations == 5


def test_design_hybrid_pareto_front_non_dominated() -> None:
    """Every member of the polished Pareto front must be non-dominated by
    every other member.
    """

    from austenite.jax_backend import design_hybrid

    def obj(x):
        return np.array([x[0], 1.0 - math.sqrt(max(x[0], 0.0))])

    r = design_hybrid(
        objective_fn=obj,
        bounds=[(0.0, 1.0)],
        n_population=20, n_generations=5, polish_iter=0,
        seed=0,
    )
    F = r.pareto_front_f
    for i in range(F.shape[0]):
        for j in range(F.shape[0]):
            if i == j:
                continue
            # j dominates i iff all(F[j] <= F[i]) and any(F[j] < F[i]) AND
            # they differ — if both lie on the curve they only "weakly"
            # dominate each other.
            le = np.all(F[j] <= F[i])
            lt = np.any(F[j] < F[i] - 1e-9)
            assert not (le and lt), (
                f"member {i} dominated by {j}: {F[i]} vs {F[j]}"
            )


def test_design_hybrid_hypervolume_finite() -> None:
    """Hypervolume of the toy problem is positive and finite."""

    from austenite.jax_backend import design_hybrid

    def obj(x):
        return np.array([x[0], 1.0 - math.sqrt(max(x[0], 0.0))])

    r = design_hybrid(
        objective_fn=obj,
        bounds=[(0.0, 1.0)],
        n_population=20, n_generations=10, polish_iter=0, seed=0,
    )
    assert math.isfinite(r.hypervolume)
    assert r.hypervolume > 0


# ---------------------------------------------------------------------------
# 2. au.design() facade
# ---------------------------------------------------------------------------


def test_design_facade_runs() -> None:
    """High-level au.design facade dispatches to the hybrid optimiser."""

    from austenite.jax_backend import design

    r = design(
        objective="maximize_KIc_sigma_y_per_density",
        constraints={"density": (None, 8.0), "$/kg": (None, 5.0)},
        composition_bounds={
            "C": (0.2, 0.6), "Mn": (0.3, 1.5),
            "Cr": (0.0, 2.0), "Mo": (0.0, 0.5),
        },
        method="hybrid",
        n_population=20, n_generations=5, polish_iter=3, seed=0,
    )
    assert r.pareto_front_x.shape[0] >= 1
    # First 4 columns are the composition variables, 5th is density.
    assert r.pareto_front_x.shape[1] == 5
    # Composition members within bounds
    for x in r.pareto_front_x:
        assert 0.2 <= x[0] <= 0.6  # C
        assert 0.3 <= x[1] <= 1.5  # Mn
        assert 0.0 <= x[2] <= 2.0  # Cr
        assert 0.0 <= x[3] <= 0.5  # Mo
    assert math.isfinite(r.hypervolume)


def test_design_facade_rejects_unknown_objective() -> None:
    from austenite.jax_backend import design

    with pytest.raises(ValueError):
        design(
            objective="minimize_corrosion",  # not shipped
            composition_bounds={"C": (0.2, 0.6), "Mn": (0.3, 1.5),
                                "Cr": (0.0, 2.0), "Mo": (0.0, 0.5)},
        )


def test_design_facade_rejects_unknown_method() -> None:
    from austenite.jax_backend import design

    with pytest.raises(ValueError):
        design(
            objective="maximize_KIc_sigma_y_per_density",
            method="not-a-method",
            composition_bounds={"C": (0.2, 0.6), "Mn": (0.3, 1.5),
                                "Cr": (0.0, 2.0), "Mo": (0.0, 0.5)},
        )


# ---------------------------------------------------------------------------
# 3. NSGA-II internals
# ---------------------------------------------------------------------------


def test_non_dominated_sort_separates_pareto_layers() -> None:
    """Classic ZDT1 sample: 5 dominated + 5 Pareto-front members."""

    from austenite.jax_backend._optimizers import _non_dominated_sort

    # 5 points on the Pareto curve x + y = 1 + 5 dominated points.
    F = np.array([
        [0.1, 0.9], [0.3, 0.7], [0.5, 0.5], [0.7, 0.3], [0.9, 0.1],  # front
        [0.5, 0.8], [0.6, 0.7], [0.7, 0.6], [0.8, 0.5], [0.9, 0.4],  # dominated
    ])
    fronts = _non_dominated_sort(F)
    assert len(fronts[0]) == 5
    # Front-0 must be the first five
    assert set(fronts[0]) == {0, 1, 2, 3, 4}


def test_crowding_distance_endpoints_infinite() -> None:
    from austenite.jax_backend._optimizers import _crowding_distance

    F = np.array([[0.0, 1.0], [0.5, 0.5], [1.0, 0.0]])
    d = _crowding_distance(F, [0, 1, 2])
    assert math.isinf(d[0]) and math.isinf(d[2])
    assert d[1] > 0
