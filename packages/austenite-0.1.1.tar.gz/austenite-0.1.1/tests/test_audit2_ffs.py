"""Physics-accuracy audit of the FFS / fracture-mechanics modules.

Audit scope (offline native engines only):
    * ``austenite/_ffs_native.py``       — Parts 5 / 6 / 9 + auxiliaries
    * ``austenite/_ffs_extensions.py``   — Parts 4 / 7 / 8 / 11 / 12 / 14

Each test checks one public formula against an independently hand-worked
literature value (API 579-1:2021, BS 7910:2019, Anderson "Fracture
Mechanics" 4th ed., Lamé 1852, ASME VIII UG-27, Larson-Miller 1952) with
an explicit tolerance. We exercise the deterministic ``native`` /
``extensions`` engines directly so nothing routes to the remote HTTP API.

Run:  python -m pytest tests/test_audit2_ffs.py -q
"""

from __future__ import annotations

import math

import pytest

import austenite as au

native = au.ffs.native
ext = au.ffs.extensions


# ---------------------------------------------------------------------------
# 1. FAD Level-2A curve — API 579-1 §9.4 / R6 Option 1 / BS 7910 Annex L
#    Kr = (1 - 0.14 Lr^2)(0.3 + 0.7 exp(-0.65 Lr^6))
# ---------------------------------------------------------------------------


def test_fad_cutoff_at_origin_is_unity():
    # At Lr = 0 the assessment line must start exactly at Kr = 1.0.
    assert native.fad_curve_level_2A(0.0) == pytest.approx(1.0, abs=1e-12)


def test_fad_curve_matches_closed_form():
    # Independent evaluation of the canonical Level-2A expression.
    for Lr in (0.25, 0.5, 0.8, 1.0, 1.2):
        expected = (1.0 - 0.14 * Lr * Lr) * (0.3 + 0.7 * math.exp(-0.65 * Lr ** 6))
        assert native.fad_curve_level_2A(Lr) == pytest.approx(expected, rel=1e-9)


def test_fad_value_at_Lr_unity():
    # Well-known reference point: Kr(Lr=1) = 0.572 (R6 / API 579 Fig. 9.20).
    assert native.fad_curve_level_2A(1.0) == pytest.approx(0.5723, abs=2e-3)


def test_fad_cutoff_beyond_Lr_max_is_zero():
    assert native.fad_curve_level_2A(2.0, L_r_max=1.5) == 0.0


# ---------------------------------------------------------------------------
# 2. Lamé 1852 thick-walled cylinder
#    sigma_hoop(Ri) = P (Ro^2 + Ri^2)/(Ro^2 - Ri^2)
#    sigma_long     = P Ri^2 /(Ro^2 - Ri^2)
# ---------------------------------------------------------------------------


def test_lame_hoop_and_longitudinal_stress():
    P, OD, ID = 10.0, 200.0, 100.0  # Ro=100, Ri=50
    sh, sl = native.lame_hoop_long_stress(P, OD, ID)
    Ro, Ri = OD / 2.0, ID / 2.0
    assert sh == pytest.approx(P * (Ro ** 2 + Ri ** 2) / (Ro ** 2 - Ri ** 2), rel=1e-9)
    assert sl == pytest.approx(P * Ri ** 2 / (Ro ** 2 - Ri ** 2), rel=1e-9)
    # Hoop must always exceed longitudinal for internal pressure.
    assert sh > sl


def test_lame_thin_wall_limit_approaches_PR_over_t():
    # Thin shell: hoop -> P R / t (PD/2t).  OD=1010, ID=990 -> t=10, Rm=500.
    sh, _ = native.lame_hoop_long_stress(1.0, 1010.0, 990.0)
    thin = 1.0 * 500.0 / 10.0
    assert sh == pytest.approx(thin, rel=0.02)


# ---------------------------------------------------------------------------
# 3. ASME VIII Div 1 UG-27 minimum wall
#    cylinder: t = P R /(S E - 0.6 P);  sphere: t = P R /(2 S E - 0.2 P)
# ---------------------------------------------------------------------------


def test_t_min_cylinder_ug27():
    P, R, S = 2.0, 500.0, 138.0
    t = native.t_min_thinning(P, R, S)
    assert t == pytest.approx(P * R / (S - 0.6 * P), rel=1e-9)


def test_t_min_sphere_ug27():
    P, R, S = 2.0, 500.0, 138.0
    t = native.t_min_thinning(P, R, S, geom="sphere")
    assert t == pytest.approx(P * R / (2.0 * S - 0.2 * P), rel=1e-9)


def test_t_min_joint_efficiency_scales_denominator():
    P, R, S, E = 2.0, 500.0, 138.0, 0.85
    t = native.t_min_thinning(P, R, S, joint_efficiency=E)
    assert t == pytest.approx(P * R / (S * E - 0.6 * P), rel=1e-9)


# ---------------------------------------------------------------------------
# 4. K_I solutions — Part 9 (Anderson Ch. 9, Newman-Raju 1982)
# ---------------------------------------------------------------------------


def _part9(crack, sm, sb=0.0, KIc=100.0, Sy=350.0, Suts=500.0,
           OD=1000.0, wall=20.0, wrs=None):
    return native.run_ffs_part9_native(
        geometry={"OD_mm": OD, "wall_mm": wall},
        crack=crack,
        sigma_membrane_MPa=sm,
        sigma_bending_MPa=sb,
        material={"sigma_y": Sy, "sigma_uts": Suts, "KIc_MPa_sqm": KIc},
        sigma_WRS_MPa=wrs,
    )


def test_KI_through_thickness_crack():
    # Through crack: K = sigma sqrt(pi a), Y = 1.  sigma=100 MPa, a=5 mm.
    sigma, a_mm = 100.0, 5.0
    res = _part9({"a_mm": a_mm, "c_mm": a_mm, "type": "through"}, sigma)
    expected = sigma * math.sqrt(math.pi * a_mm / 1000.0)
    assert res["details"]["K_app"] == pytest.approx(expected, rel=1e-9)


def test_KI_surface_crack_newman_raju_shape_factor():
    # Semi-elliptical surface crack a/c=1: Q = 1 + 1.464(a/c)^1.65 = 2.464,
    # deepest point free-surface factor 1.12.  K = 1.12 sigma sqrt(pi a / Q).
    sigma, a_mm, c_mm = 100.0, 5.0, 5.0
    res = _part9({"a_mm": a_mm, "c_mm": c_mm, "type": "surface"}, sigma)
    Q = 1.0 + 1.464 * (a_mm / c_mm) ** 1.65
    expected = 1.12 * sigma * math.sqrt(math.pi * (a_mm / 1000.0) / Q)
    assert res["details"]["K_app"] == pytest.approx(expected, rel=1e-9)
    assert Q == pytest.approx(2.464, abs=1e-3)


def test_KI_scales_with_sqrt_of_crack_depth():
    # Doubling crack depth scales K by sqrt(2) for a through crack.
    k1 = _part9({"a_mm": 4.0, "c_mm": 4.0, "type": "through"}, 120.0)["details"]["K_app"]
    k2 = _part9({"a_mm": 8.0, "c_mm": 8.0, "type": "through"}, 120.0)["details"]["K_app"]
    assert k2 / k1 == pytest.approx(math.sqrt(2.0), rel=1e-9)


# ---------------------------------------------------------------------------
# 5. Reference stress / Lr = sigma_ref / Sy  (BS 7910:2019 §7.3)
# ---------------------------------------------------------------------------


def test_reference_stress_surface_net_section_and_Lr():
    # Surface flaw: sigma_ref = sigma_m / (1 - a/t); Lr = sigma_ref / Sy.
    sm, Sy, a_mm, wall = 100.0, 350.0, 5.0, 20.0
    res = _part9({"a_mm": a_mm, "c_mm": a_mm, "type": "surface"}, sm, Sy=Sy, wall=wall)
    sigma_ref_expected = sm / (1.0 - a_mm / wall)
    assert res["details"]["sigma_ref"] == pytest.approx(sigma_ref_expected, rel=1e-9)
    assert res["fad_point"][0] == pytest.approx(sigma_ref_expected / Sy, rel=1e-9)


def test_Kr_equals_K_total_over_KIc():
    sm, KIc = 100.0, 100.0
    res = _part9({"a_mm": 5.0, "c_mm": 5.0, "type": "through"}, sm, KIc=KIc)
    assert res["fad_point"][1] == pytest.approx(res["details"]["K_total"] / KIc, rel=1e-9)


def test_Lr_max_plastic_collapse_cutoff():
    # Lr_max = 0.5 (1 + Sy/Suts) = flow-stress collapse limit (API 579 §9.4).
    Sy, Suts = 350.0, 500.0
    res = _part9({"a_mm": 5.0, "c_mm": 5.0, "type": "surface"}, 100.0, Sy=Sy, Suts=Suts)
    assert res["details"]["L_r_max"] == pytest.approx(0.5 * (1.0 + Sy / Suts), rel=1e-9)


def test_part9_large_flaw_is_unacceptable():
    # Deep flaw under high stress with low toughness must fail the FAD.
    res = _part9(
        {"a_mm": 18.0, "c_mm": 50.0, "type": "surface"},
        sm=300.0, sb=50.0, KIc=60.0, OD=500.0, wall=20.0,
    )
    assert res["level"] == "unacceptable"
    assert res["distance_to_curve"] < 1.0


def test_part9_wrs_increases_total_K():
    base = _part9({"a_mm": 5.0, "c_mm": 5.0, "type": "surface"}, 100.0)
    with_wrs = _part9({"a_mm": 5.0, "c_mm": 5.0, "type": "surface"}, 100.0, wrs=150.0)
    assert with_wrs["details"]["K_total"] > base["details"]["K_total"]


# ---------------------------------------------------------------------------
# 6. Part 5 — general metal loss: RSF acceptance + MAWP derate
#    Acceptance RSF_a = 0.90; MAWP_reduced = MAWP * RSF / RSF_a when RSF<0.90
#    (API 579-1 §2.4.2.2 Eq. 2.5)
# ---------------------------------------------------------------------------


def _part5(thk, P=2.5, OD=500.0, wall=12.5, spec="SA-516-70", **kw):
    return native.run_ffs_part5_native(
        geometry={"type": "cylinder", "OD_mm": OD, "wall_mm": wall,
                  "joint_efficiency": 1.0, "grid_spacing_mm": 25.0},
        thickness_map=list(thk),
        T_C=200.0, P_MPa=P, material={"spec": spec}, **kw,
    )


def test_part5_level1_pass_when_thick():
    res = _part5([10.0, 10.1, 9.9, 10.2])
    assert res["level"] == "Level-1"
    assert res["RSF"] == pytest.approx(1.0)


def test_part5_rsf_acceptance_threshold_is_0p90():
    assert native.run_ffs_part5_native.__defaults__ is not None  # smoke
    res = _part5([10.0, 10.1, 9.9, 10.2])
    assert res["RSF_a"] == pytest.approx(0.90)


def test_part5_mawp_derate_eq_2_5():
    # Heavy localized thinning -> RSF < 0.90; check MAWP = base * RSF/0.90.
    # CTP average (~8 mm) sits well below t_min (~15 mm) so the Folias RSF
    # (RSF = Rt/(1-(1-Rt)/M_t)) lands below the 0.90 acceptance threshold.
    P = 8.0
    res = _part5([8.0, 8.2, 7.9, 8.1, 7.8, 8.0], P=P, wall=20.0)
    assert res["RSF"] < 0.90
    base = native._base_mawp(
        {"type": "cylinder", "OD_mm": 500.0, "joint_efficiency": 1.0},
        res["details"]["S_allow_MPa"],
        res["t_meas_min_mm"] - res["details"]["FCA_mm"],
    )
    assert res["MAWP_MPa"] == pytest.approx(base * res["RSF"] / 0.90, rel=1e-6)


def test_part5_tmin_uses_ug27_cylinder():
    P, OD, S = 2.5, 500.0, 138.0
    res = _part5([10.0], P=P, OD=OD)
    R_i = OD / 2.0 - 1.0
    assert res["t_min_mm"] == pytest.approx(P * R_i / (S - 0.6 * P), rel=1e-9)


def test_part5_remaining_life_from_corrosion_rate():
    # life = (t_meas_min - t_min - FCA) / CR.
    res = _part5([10.0, 10.0], P=2.5, corrosion_rate_mm_per_year=0.2)
    margin = 10.0 - res["t_min_mm"]
    assert res["remaining_life_years"] == pytest.approx(margin / 0.2, rel=1e-6)


# ---------------------------------------------------------------------------
# 7. Folias bulging factor — M_t = sqrt(1 + 0.48 lambda^2) (Folias 1965)
# ---------------------------------------------------------------------------


def test_folias_bulging_in_lta_overlay():
    # Supply an explicit LTA so M_t is reported, then verify the formula.
    res = _part5(
        [11.0, 11.0], P=2.5, wall=12.5,
        lta={"s_mm": 100.0, "d_mm": 4.0},
    )
    D, t_nom, s = 500.0, 12.5, 100.0
    lam = s / math.sqrt(D * t_nom)
    M_t = math.sqrt(1.0 + 0.48 * lam * lam)
    # The note records M_t to 3 dp; recompute RSF_lta and compare to library.
    RSF_lta = (1 - 4.0 / t_nom) / (1 - 4.0 / (t_nom * M_t))
    assert res["RSF"] == pytest.approx(min(1.0, RSF_lta), rel=1e-6)


# ---------------------------------------------------------------------------
# 8. Part 6 — pitting
# ---------------------------------------------------------------------------


def test_part6_screening_pass_shallow_sparse_pits():
    res = native.run_ffs_part6_native(
        geometry={"type": "cylinder", "OD_mm": 500.0, "wall_mm": 12.5,
                  "joint_efficiency": 1.0},
        pit_data=[{"max_depth_mm": 1.0, "diameter_mm": 3.0},
                  {"max_depth_mm": 1.2, "diameter_mm": 2.5}],
        T_C=200.0, P_MPa=2.0, material={"spec": "SA-516-70"},
    )
    assert res["level"] == "Level-1"
    assert res["max_pit_depth_mm"] == pytest.approx(1.2)
    assert res["density_class"] == 1


def test_part6_pit_area_sum_of_circles():
    pits = [{"max_depth_mm": 1.0, "diameter_mm": 4.0},
            {"max_depth_mm": 1.0, "diameter_mm": 6.0}]
    res = native.run_ffs_part6_native(
        geometry={"type": "cylinder", "OD_mm": 500.0, "wall_mm": 12.5},
        pit_data=pits, T_C=200.0, P_MPa=2.0, material={"spec": "SA-516-70"},
    )
    expected = math.pi * 2.0 ** 2 + math.pi * 3.0 ** 2
    assert res["details"]["A_pits_mm2"] == pytest.approx(expected, rel=1e-9)


# ---------------------------------------------------------------------------
# 9. Part 4 — brittle fracture (Barsom-Rolfe CVN->KIC, WRC 175 MAT)
# ---------------------------------------------------------------------------


def test_cvn_to_kic_barsom_rolfe_lower_shelf():
    # Lower-shelf SI fit: K_IC = 12.5 sqrt(CVN). At 40 J the Rolfe-Novak
    # yield-corrected branch dominates for Sy=350, so check it is consistent
    # with the larger of the two estimates and exceeds the direct branch.
    K = ext.cvn_to_kic_barsom_rolfe(40.0, 350.0)
    assert K >= 12.5 * math.sqrt(40.0) - 1e-9


def test_cvn_to_kic_monotonic_in_energy():
    assert ext.cvn_to_kic_barsom_rolfe(80.0, 350.0) > ext.cvn_to_kic_barsom_rolfe(20.0, 350.0)


def test_wrc175_mat_curve_thin_carbon_steel():
    # t < 25 mm, Sy <= 250 -> MAT = -40 C (WRC 175 Curve A baseline).
    assert ext.mat_curve_wrc_175(20.0, 250.0) == pytest.approx(-40.0, abs=1e-9)


def test_part4_warm_design_passes_screen():
    res = ext.run_ffs_part4_native(
        geometry={"OD_mm": 1000.0, "wall_mm": 25.0, "type": "cylinder"},
        material={"sigma_y_MPa": 260.0, "sigma_uts_MPa": 485.0, "P_MPa": 2.0},
        impact_data={"CVN_J": 40.0, "T_test_C": -20.0},
        design_T_C=50.0,
    )
    assert res["level"] == "Level-1"


# ---------------------------------------------------------------------------
# 10. Part 14 — creep (Larson-Miller 1952)
#     LMP = T_K (C + log10 t_hr)
# ---------------------------------------------------------------------------


def test_larson_miller_parameter_textbook_value():
    # T = 538 C = 811.15 K, t = 1e5 h, C = 20 -> LMP = 811.15*25 = 20278.75.
    lmp = ext.larson_miller_parameter(811.15, 1.0e5, 20.0)
    assert lmp == pytest.approx(811.15 * (20.0 + 5.0), rel=1e-9)


def test_larson_miller_increases_with_time_and_temperature():
    base = ext.larson_miller_parameter(800.0, 1.0e4, 20.0)
    assert ext.larson_miller_parameter(800.0, 1.0e5, 20.0) > base
    assert ext.larson_miller_parameter(900.0, 1.0e4, 20.0) > base


def test_creep_rupture_stress_decreases_with_temperature():
    s_low = ext.creep_rupture_stress_lmp("SA-335-P22", 500.0, 1.0e5)
    s_high = ext.creep_rupture_stress_lmp("SA-335-P22", 600.0, 1.0e5)
    assert s_high < s_low


# ---------------------------------------------------------------------------
# 11. Public dispatch via backend="native" (no HTTP)
# ---------------------------------------------------------------------------


def test_public_part5_native_backend_matches_engine():
    result = au.ffs.api_579_part_5(
        geometry={"type": "cylinder", "OD_mm": 500.0, "wall_mm": 12.5},
        thickness_map=[10.0, 10.1, 9.9, 10.2],
        T_C=200.0, P_MPa=2.5, material="SA-516-70",
        backend="native",
    )
    assert result.level == "Level-1"
    assert result.t_min_mm == pytest.approx(2.5 * (250.0 - 1.0) / (138.0 - 0.6 * 2.5), rel=1e-6)
