"""Tests for ``au.profile`` — runtime performance harness.

Verifies that :func:`profile.run` returns finite, well-formed
:class:`ProfileReport` values and that :func:`profile.suite` writes a
CSV + JSON matching the documented schema.

References:
    * Karpat T., J. Comput. Eng. Sci. (2011) — Profile-driven timing.
    * Python stdlib cProfile / pstats / tracemalloc.
"""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import pytest

import austenite as au
from austenite.profile import (
    BottleneckEntry,
    ProfileReport,
    SuiteEntry,
    SuiteReport,
)


# ---------------------------------------------------------------------------
# Sample workloads used in tests — kept tiny so the suite stays fast
# ---------------------------------------------------------------------------


def _tiny_workload(n: int = 1000) -> float:
    """Pure-Python loop to give cProfile something to count."""

    s = 0.0
    for i in range(n):
        s += math.sin(i) * math.cos(i / 2.0)
    return s


def _failing_workload() -> None:
    raise RuntimeError("intentional test failure")


# ---------------------------------------------------------------------------
# Tests — au.profile.run
# ---------------------------------------------------------------------------


def test_profile_run_returns_profile_report() -> None:
    rep = au.profile.run(_tiny_workload, n=500)
    assert isinstance(rep, ProfileReport)
    assert rep.total_seconds >= 0.0
    assert math.isfinite(rep.total_seconds)
    assert math.isfinite(rep.total_ms)
    assert rep.total_ms == pytest.approx(rep.total_seconds * 1000.0)


def test_profile_run_total_time_is_finite_and_positive() -> None:
    rep = au.profile.run(_tiny_workload, n=2000)
    assert rep.total_seconds > 0
    assert rep.total_ms > 0
    assert math.isfinite(rep.total_ms)


def test_profile_run_n_calls_total_is_positive_integer() -> None:
    rep = au.profile.run(_tiny_workload, n=300)
    assert isinstance(rep.n_calls_total, int)
    assert rep.n_calls_total >= 1


def test_profile_run_bottleneck_pct_never_exceeds_100() -> None:
    """Own-time aggregation should never push a bucket above 100% of wall."""

    rep = au.profile.run(_tiny_workload, n=5000)
    for b in rep.bottlenecks:
        assert isinstance(b, BottleneckEntry)
        assert 0.0 <= b.pct_of_total <= 100.0, (
            f"bucket {b.label!r} pct={b.pct_of_total}% out of [0, 100]"
        )
        assert b.cum_seconds >= 0.0
        assert b.n_calls >= 0


def test_profile_run_markdown_includes_total_time_and_citation() -> None:
    rep = au.profile.run(_tiny_workload, n=500)
    md = rep.markdown()
    assert "Performance report" in md
    assert "Total time" in md
    assert "Karpat" in md or "Citation" in md
    assert "ms" in md


def test_profile_run_memory_peak_is_nonnegative() -> None:
    rep = au.profile.run(_tiny_workload, n=1000)
    assert rep.memory_peak_bytes >= 0
    assert rep.memory_peak_mb >= 0.0
    assert math.isfinite(rep.memory_peak_mb)


def test_profile_run_passes_args_and_kwargs_through() -> None:
    """The returned `.result` should be exactly what the function returned."""

    rep = au.profile.run(_tiny_workload, n=10)
    expected = _tiny_workload(10)
    assert rep.result == pytest.approx(expected)


def test_profile_run_to_dict_has_documented_keys() -> None:
    rep = au.profile.run(_tiny_workload, n=200)
    d = rep.to_dict()
    for key in (
        "function_name", "kwargs_repr", "total_seconds", "total_ms",
        "bottlenecks", "memory_peak_bytes", "memory_peak_mb",
        "n_calls_total", "citation",
    ):
        assert key in d, f"missing key {key!r}"
    # Each bottleneck round-trips through to_dict
    for b in d["bottlenecks"]:
        for k in ("label", "cum_seconds", "n_calls", "pct_of_total", "function"):
            assert k in b


def test_profile_run_records_function_name() -> None:
    rep = au.profile.run(_tiny_workload, n=100)
    assert "_tiny_workload" in rep.function_name


def test_profile_run_propagates_exception() -> None:
    with pytest.raises(RuntimeError, match="intentional"):
        au.profile.run(_failing_workload)


# ---------------------------------------------------------------------------
# Tests — au.profile.suite
# ---------------------------------------------------------------------------


def test_profile_suite_returns_suite_report_with_entries() -> None:
    rep = au.profile.suite(sizes=(1, 3), n_runs=2)
    assert isinstance(rep, SuiteReport)
    # Eight headline capabilities × 2 sizes = 16 entries
    assert len(rep.entries) == 8 * 2
    for entry in rep.entries:
        assert isinstance(entry, SuiteEntry)
        assert entry.median_ms >= 0
        assert entry.p95_ms >= entry.median_ms - 1e-9  # p95 >= median
        assert entry.n_runs == 2
        assert math.isfinite(entry.mean_ms)


def test_profile_suite_writes_csv(tmp_path: Path) -> None:
    out = tmp_path / "perf.csv"
    rep = au.profile.suite(out, sizes=(1,), n_runs=2)
    assert out.exists()
    with open(out, encoding="utf-8") as fh:
        reader = csv.reader(fh)
        rows = list(reader)
    header = rows[0]
    for col in ("capability", "n", "median_ms", "p95_ms", "mean_ms", "n_runs"):
        assert col in header
    # One row per capability at N=1
    assert len(rows) == 1 + 8


def test_profile_suite_writes_json(tmp_path: Path) -> None:
    out_csv = tmp_path / "perf.csv"
    out_json = tmp_path / "perf.json"
    au.profile.suite(out_csv, output_json=out_json, sizes=(1,), n_runs=2)
    assert out_json.exists()
    data = json.loads(out_json.read_text(encoding="utf-8"))
    assert "entries" in data and "citation" in data
    assert len(data["entries"]) == 8
    for e in data["entries"]:
        for k in ("capability", "n", "median_ms", "p95_ms", "mean_ms", "n_runs"):
            assert k in e


def test_profile_suite_table_renders_as_string() -> None:
    rep = au.profile.suite(sizes=(1,), n_runs=2)
    text = rep.to_table()
    assert "capability" in text and "median_ms" in text
    # All eight capabilities should appear
    for cap in (
        "au.design_path", "au.am.qualification", "au.mtc.parse",
        "au.ttt.compute", "au.calphad", "au.bayesian", "au.ffs",
        "au.compliance.bayesian_p_pass",
    ):
        assert cap in text, f"missing {cap} in table"


def test_profile_suite_p95_is_at_least_median() -> None:
    rep = au.profile.suite(sizes=(1, 5, 10), n_runs=3)
    for e in rep.entries:
        assert e.p95_ms >= e.median_ms - 1e-9


def test_profile_suite_accepts_custom_workloads() -> None:
    """User can plug in their own workloads instead of the eight headline ones."""

    calls = {"n": 0}

    def my_workload(N: int) -> None:
        calls["n"] += 1
        for _ in range(N):
            math.sqrt(2.0)

    rep = au.profile.suite(
        sizes=(1, 2),
        n_runs=2,
        workloads={"my.fn": my_workload},
    )
    assert len(rep.entries) == 2  # 1 capability × 2 sizes
    assert all(e.capability == "my.fn" for e in rep.entries)
    assert calls["n"] >= 2  # called at least once per (size, run)
