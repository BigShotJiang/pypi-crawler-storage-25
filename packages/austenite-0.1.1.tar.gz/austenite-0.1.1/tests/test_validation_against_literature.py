"""Validation tests: strengthened modules against published literature.

Each test compares a module prediction to a published data point with
explicit < tolerance assertion. Not a unit test of internal logic — these
test whether the model agrees with the real world.
"""

from __future__ import annotations

import math


# ---------------------------------------------------------------------------
# CREEP — LMP anchors validated against NIMS / ECCC
# ---------------------------------------------------------------------------


def test_creep_pinn_gr91_at_550C_100MPa_within_50pct() -> None:
    """NIMS Creep Data Sheet 43 (Gr.91) — t_r at 550°C / 100 MPa ≈ 100 000 h."""

    from austenite.creep_pinn import predict_creep_life

    r = predict_creep_life("Grade91_9Cr1Mo", 100, 550)
    # Published: ~100 000 h. Accept band 30 000 – 300 000 h (3× both directions)
    assert 30_000 <= r.rupture_hours_pinn <= 300_000, (
        f"Predicted {r.rupture_hours_pinn:.0f} h, expected 1e5"
    )


def test_creep_pinn_in718_high_T_short_life() -> None:
    """IN718 at 750°C / 200 MPa — life should be shorter than at 600°C / 200 MPa."""

    from austenite.creep_pinn import predict_creep_life

    r_hot = predict_creep_life("Inconel_718", 200, 750)
    r_cool = predict_creep_life("Inconel_718", 200, 600)
    assert r_hot.rupture_hours_pinn < r_cool.rupture_hours_pinn


def test_creep_pinn_316H_at_625C_89MPa() -> None:
    """ECCC 316H Vol 5: LMP ≈ 18 000 at σ=89 MPa.

    At T=625°C (T_K=898), LMP = 18 000 ⇒ log10 t = 18000/898 - C(=17) = 3.04 ⇒
    t ≈ 1100 h. Accept 200–10000 h.
    """

    from austenite.creep_pinn import predict_creep_life

    r = predict_creep_life("316H_SS", 89, 625)
    assert 200 <= r.rupture_hours_pinn <= 10_000


# ---------------------------------------------------------------------------
# AM PLANNER — Khairallah keyhole + Tang LoF
# ---------------------------------------------------------------------------


def test_am_planner_in718_baseline_recipe_keyhole_low() -> None:
    """King 2014 IN718 recipe: 250 W, 1200 mm/s, 30 µm → should NOT be keyhole.

    From Levine 2020 NIST AM-Bench Cell 4. β should be well below the 30
    keyhole threshold and keyhole probability low.
    """

    from austenite.am_planner import AlloyProperties, MachineSpec, plan_build

    a = AlloyProperties("IN718", k_W_mK=10.5, Cp_J_kgK=525, rho_kg_m3=8200,
                        T_solidus_K=1500, T_liquidus_K=1610, alpha_um_m_K=13)
    m = MachineSpec(laser_power_W=250, scan_speed_mm_s=1200, spot_diameter_um=80,
                    layer_thickness_um=30, hatch_spacing_um=100, absorptivity=0.4)
    p = plan_build(n_layers=10, machine=m, alloy=a)
    # Recipe is below keyhole — verify
    max_beta = max(L.normalized_enthalpy for L in p.layers)
    assert max_beta < 30, f"β={max_beta} should be < 30 for conduction mode"
    max_keyhole = max(L.p_keyhole for L in p.layers)
    assert max_keyhole < 0.5


def test_am_planner_high_power_low_speed_keyhole() -> None:
    """Khairallah 2016: 500 W at 200 mm/s → strongly keyhole regime, β >> 30."""

    from austenite.am_planner import AlloyProperties, MachineSpec, plan_build

    a = AlloyProperties("IN718", 10.5, 525, 8200, 1500, 1610, 13)
    m = MachineSpec(laser_power_W=500, scan_speed_mm_s=200, spot_diameter_um=80,
                    layer_thickness_um=30, hatch_spacing_um=100, absorptivity=0.4)
    p = plan_build(n_layers=3, machine=m, alloy=a)
    # β should exceed 30 (keyhole regime)
    assert any(L.normalized_enthalpy > 30 for L in p.layers)
    # And keyhole probability should be high
    assert max(L.p_keyhole for L in p.layers) > 0.5


def test_am_planner_low_power_high_speed_LoF() -> None:
    """Tang 2017: too-low energy → melt pool fails to penetrate, LoF."""

    from austenite.am_planner import AlloyProperties, MachineSpec, plan_build

    a = AlloyProperties("IN718", 10.5, 525, 8200, 1500, 1610, 13)
    m = MachineSpec(laser_power_W=80, scan_speed_mm_s=2000, spot_diameter_um=80,
                    layer_thickness_um=60, hatch_spacing_um=120, absorptivity=0.4)
    p = plan_build(n_layers=3, machine=m, alloy=a)
    # LoF probability should be high (depth < 1.5×t)
    assert max(L.p_lack_of_fusion for L in p.layers) > 0.4


# ---------------------------------------------------------------------------
# NACE — boundary curve validation
# ---------------------------------------------------------------------------


def test_nace_316SS_in_typical_offshore_R2() -> None:
    """Typical North Sea condition: pH₂S = 2 kPa, pH = 5.0 → Region 2.

    316SS T_max in R2 is 60°C. T = 80°C should fail.
    """

    from austenite.nace_mr0175 import BOMComponent, check_component

    c = BOMComponent("V1", "316SS", service_T_C=80, pH2S_kPa=2.0, pH=5.0)
    r = check_component(c)
    assert r.region == "Region 2"
    assert not r.compliant


def test_nace_316SS_below_threshold_R0() -> None:
    """pH₂S = 0.1 kPa → below sour threshold, Region 0."""

    from austenite.nace_mr0175 import BOMComponent, check_component

    c = BOMComponent("V1", "316SS", service_T_C=50, pH2S_kPa=0.1, pH=7.0)
    r = check_component(c)
    assert r.region == "Region 0 (sweet / mild sour)"


def test_nace_severe_sour_blocks_316() -> None:
    """ pH₂S=50 kPa → Region 3. 316SS not permitted in R3."""

    from austenite.nace_mr0175 import BOMComponent, check_component

    c = BOMComponent("V1", "316SS", service_T_C=40, pH2S_kPa=50, pH=4.0)
    r = check_component(c)
    assert r.region == "Region 3 (severe sour)"
    assert not r.compliant


def test_nace_carbon_steel_hardness_HRC_cap() -> None:
    """Carbon steel with HRC 25 in R1 — should fail (HRC max = 22)."""

    from austenite.nace_mr0175 import BOMComponent, check_component

    c = BOMComponent("V1", "ASTM A516-70", service_T_C=80, pH2S_kPa=0.5,
                     pH=5.5, hardness_HRC=25)
    r = check_component(c)
    assert not r.compliant
    assert any("HRC" in f for f in r.failures)


# ---------------------------------------------------------------------------
# LCA — IPCC AR6 GWP100 + EOL credit
# ---------------------------------------------------------------------------


def test_lca_gwp_methane_close_to_30() -> None:
    """IPCC AR6 GWP100 for fossil-CH4 should be near 29.8."""

    from austenite.lca import process_emissions_CO2eq

    co2eq = process_emissions_CO2eq({"CH4_fossil": 1.0})
    assert 25 <= co2eq <= 35


def test_lca_eol_credit_reduces_gwp() -> None:
    """Steel with 85% recycling should have ~50% net GWP reduction."""

    from austenite.lca import assess

    r = assess("Carbon_Steel", mass_kg=1000)
    assert r.net_gwp_with_eol < r.total_gwp_kg_CO2eq
    # Reduction should be at least 30%
    pct = 1 - r.net_gwp_with_eol / r.total_gwp_kg_CO2eq
    assert pct > 0.3


def test_lca_nickel_alloy_high_water() -> None:
    """IN718 cradle-to-gate water > Carbon-steel cradle-to-gate water."""

    from austenite.lca import assess

    r_in = assess("Inconel_718", mass_kg=1)
    r_cs = assess("Carbon_Steel", mass_kg=1)
    assert r_in.water_consumption_m3_per_kg > r_cs.water_consumption_m3_per_kg


# ---------------------------------------------------------------------------
# BUSBAR — Onderdonk validation
# ---------------------------------------------------------------------------


def test_busbar_onderdonk_cu_1000mm2() -> None:
    """Onderdonk for Cu 1000 mm² @ 1 s, 90→175°C.

    Pure adiabatic limit gives ~100 kA. The IEEE 80-2013 engineering
    formula `I≈143·A/√t` for Cu gives ~143 kA at full 0→250°C rise.
    Accept band 50–150 kA for ΔT=85°C.
    """

    from austenite.busbar_designer import onderdonk_short_circuit_rating_kA

    I_kA = onderdonk_short_circuit_rating_kA(1000, "Cu_C11000",
                                             theta_initial_C=90, theta_final_C=175,
                                             duration_s=1.0)
    assert 50 <= I_kA <= 150


def test_busbar_onderdonk_scales_with_sqrt_duration() -> None:
    """Onderdonk: I ∝ 1/sqrt(t). Doubling t should reduce I by sqrt(2)."""

    from austenite.busbar_designer import onderdonk_short_circuit_rating_kA

    I1 = onderdonk_short_circuit_rating_kA(500, "Cu_C11000", duration_s=1.0)
    I2 = onderdonk_short_circuit_rating_kA(500, "Cu_C11000", duration_s=2.0)
    assert abs(I1 / I2 - math.sqrt(2)) < 0.05


def test_busbar_skin_effect_dc_returns_1() -> None:
    """DC (freq=0) skin factor must be exactly 1.0."""

    from austenite.busbar_designer import skin_effect_factor

    sk = skin_effect_factor(100, "Cu_C11000", freq_Hz=0.0)
    assert sk == 1.0


def test_busbar_skin_effect_60Hz_modest() -> None:
    """At 60 Hz and 1000 mm² Cu bar, skin factor 1.0-1.5."""

    from austenite.busbar_designer import skin_effect_factor

    sk = skin_effect_factor(1000, "Cu_C11000", freq_Hz=60.0)
    assert 1.0 <= sk <= 2.0


def test_busbar_design_2000A_cu_sane() -> None:
    """2000 A on Cu bar at 30°C ambient should produce ≥ 500 mm²."""

    from austenite.busbar_designer import design_busbar

    b = design_busbar(2000, material="Cu_C11000", length_m=1.0)
    assert b.cross_section_mm2 >= 300
    assert b.short_circuit_rating_kA_1s > 10


# ---------------------------------------------------------------------------
# PHASE-FIELD GRAIN — Hillert validation
# ---------------------------------------------------------------------------


def test_phase_field_grain_growth_returns_positive_d() -> None:
    """Mean grain diameter must be > 0 after simulation."""

    from austenite.phase_field_grain import simulate_grain_growth

    r = simulate_grain_growth(
        grid_size=16, n_grains_initial=8, time_steps=10, dt_s=0.01,
        dx_um=1.0, kappa=1.0, mobility=10.0, m=1.0, seed=42,
    )
    assert r.mean_grain_diameter_um > 0
    assert r.initial_mean_diameter_um > 0


def test_phase_field_boundary_energy_positive() -> None:
    """γ_GB must be positive for any (κ, m) > 0."""

    from austenite.phase_field_grain import boundary_energy_from_PF_params

    g = boundary_energy_from_PF_params(kappa=1.0, m=1.0)
    assert g > 0


def test_phase_field_grain_growth_keeps_field_finite() -> None:
    """No NaN/inf in eta field after evolution (regression test)."""

    import math

    from austenite.phase_field_grain import simulate_grain_growth

    r = simulate_grain_growth(grid_size=8, n_grains_initial=4, time_steps=20,
                              dt_s=0.5, dx_um=1.0, mobility=5.0)
    for row in r.eta_field_final:
        for cell in row:
            for v in cell:
                assert math.isfinite(v), f"Non-finite eta: {v}"


# ---------------------------------------------------------------------------
# AM enthalpy normalized formula validation
# ---------------------------------------------------------------------------


def test_am_normalized_enthalpy_uses_alloy_k() -> None:
    """When k_W_mK supplied, β should differ from default 5e-6 α assumption."""

    from austenite.am_planner import normalized_enthalpy

    # IN718: k=10.5 W/mK, ρ=8200, Cp=525 → α = 2.44e-6 m²/s (lower than default 5e-6)
    beta_default = normalized_enthalpy(250, 1200, 80, 8200, 525, 1610)
    beta_explicit = normalized_enthalpy(250, 1200, 80, 8200, 525, 1610, k_W_mK=10.5)
    # Different α gives different β
    assert abs(beta_default - beta_explicit) > 0.1
