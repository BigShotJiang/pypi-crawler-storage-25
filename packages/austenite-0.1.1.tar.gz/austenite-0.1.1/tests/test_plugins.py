"""Tests for the plugin registry (austenite.plugins).

Covers:
  * In-process register / unregister / discover round-trip.
  * Hook lookup and dispatch.
  * End-to-end ingestion when one of the three reference plugins is
    installed via ``pip install -e packages/austenite-extras-<name>``.
    These tests are skipped when the plugin is not on PYTHONPATH.
"""

from __future__ import annotations

import importlib
from typing import Any

import pytest

import austenite as au
from austenite.plugins import (
    KNOWN_HOOKS,
    PluginManifest,
    clear,
    discover,
    get_hook,
    iter_hooks,
    list_installed,
    load,
    register,
    unregister,
)


# ---------------------------------------------------------------------------
# In-process registration / lookup
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _preserve_registry():
    """Re-discover real plugins after every test so unrelated tests
    don't see a wiped registry."""

    yield
    clear(rediscover=True)
    discover()


def test_register_and_load_round_trip():
    clear()

    def stub_alloys() -> dict:
        return {"FAKE-X1": {"name": "Fake-X1", "Sy_MPa": 500}}

    m = PluginManifest(
        name="testplugin",
        version="0.0.1",
        hooks={"custom_alloy_spec": stub_alloys},
        description="in-process test plugin",
        citation="test fixture",
    )
    register(m)
    assert "testplugin" in list_installed()
    loaded = load("testplugin")
    assert loaded.name == "testplugin"
    assert loaded.version == "0.0.1"
    assert loaded.hooks["custom_alloy_spec"] is stub_alloys


def test_register_unknown_hook_raises():
    with pytest.raises(ValueError, match="unknown hooks"):
        PluginManifest(
            name="badhooks",
            version="0",
            hooks={"this_hook_doesnt_exist": lambda: None},  # type: ignore[arg-type]
        )


def test_register_duplicate_refuses_without_replace():
    clear()
    m1 = PluginManifest(name="dupe", version="1")
    m2 = PluginManifest(name="dupe", version="2")
    register(m1)
    with pytest.raises(ValueError, match="already registered"):
        register(m2)
    register(m2, replace=True)
    assert load("dupe").version == "2"


def test_load_missing_plugin_raises_helpful_message():
    clear()
    with pytest.raises(KeyError, match="not installed"):
        load("nonexistent-plugin")


def test_get_hook_validates_hook_name():
    clear()
    m = PluginManifest(name="x", version="0", hooks={})
    register(m)
    with pytest.raises(ValueError, match="Unknown hook name"):
        get_hook("x", "totally-fake-hook")


def test_iter_hooks_returns_only_implementers():
    clear()
    register(
        PluginManifest(
            name="a", version="0", hooks={"custom_kic_database": lambda: {"x": []}},
        ),
    )
    register(PluginManifest(name="b", version="0", hooks={}))
    impls = list(iter_hooks("custom_kic_database"))
    impl_names = [name for name, _ in impls]
    assert impl_names == ["a"]


def test_known_hooks_constant_is_frozen():
    assert isinstance(KNOWN_HOOKS, frozenset)
    assert "custom_alloy_spec" in KNOWN_HOOKS
    assert "custom_fatigue_curves" in KNOWN_HOOKS
    assert "custom_kic_database" in KNOWN_HOOKS
    assert "custom_compliance_check" in KNOWN_HOOKS


def test_unregister_removes_plugin():
    clear()
    register(PluginManifest(name="bye", version="0", hooks={}))
    assert "bye" in list_installed()
    unregister("bye")
    assert "bye" not in list_installed()


# ---------------------------------------------------------------------------
# Data-loader integration (in-process plugin)
# ---------------------------------------------------------------------------


def test_data_alloys_plugin_kwarg_merges_rows():
    clear()
    register(
        PluginManifest(
            name="probe",
            version="0",
            hooks={
                "custom_alloy_spec": lambda: {
                    "TEST-ALLOY-XYZ": {
                        "name": "Test Alloy XYZ",
                        "family": "Test Family",
                        "Sy_MPa": 999,
                        "citation": "test",
                    },
                },
            },
        ),
    )
    rows = au.data.alloys(plugin="probe")
    try:
        import pandas as pd  # noqa: F401
        names = rows["name"].tolist()
    except ImportError:
        names = [r["name"] for r in rows]
    assert "Test Alloy XYZ" in names


def test_data_fatigue_curves_plugin_kwarg_filters_to_alloy():
    clear()
    register(
        PluginManifest(
            name="snprobe",
            version="0",
            hooks={
                "custom_fatigue_curves": lambda: {
                    "FakeAlloy-9000": [
                        {
                            "condition": "test condition",
                            "R_ratio": -1, "temperature_C": 25,
                            "sigma_f_MPa": 1234, "b": -0.1,
                            "Se_MPa": 100, "Ne_cycles": 1e7,
                            "citation": "test",
                        },
                    ],
                },
            },
        ),
    )
    rows = au.data.fatigue_curves("FakeAlloy", plugin="snprobe")
    try:
        import pandas as pd  # noqa: F401
        assert len(rows) == 1
        assert rows["sigma_f_MPa"].iloc[0] == 1234
    except ImportError:
        assert len(rows) == 1
        assert rows[0]["sigma_f_MPa"] == 1234


def test_data_kic_database_plugin_kwarg_merges_rows():
    clear()
    register(
        PluginManifest(
            name="kicprobe",
            version="0",
            hooks={
                "custom_kic_database": lambda: {
                    "TestSteel-X": [
                        {
                            "condition": "annealed",
                            "temperature_C": 25,
                            "K_IC_MPa_sqrt_m": 88,
                            "orientation": "L-T",
                            "thickness_mm": 25,
                            "citation": "test",
                        },
                    ],
                },
            },
        ),
    )
    rows = au.data.kic_database("TestSteel", plugin="kicprobe")
    try:
        import pandas as pd  # noqa: F401
        assert len(rows) == 1
        assert rows["K_IC_MPa_sqrt_m"].iloc[0] == 88
    except ImportError:
        assert len(rows) == 1
        assert rows[0]["K_IC_MPa_sqrt_m"] == 88


def test_compliance_check_standard_dispatches_to_plugin():
    clear()
    sentinel = object()

    def custom_check(spec_id: str, **kwargs: Any) -> Any:
        if spec_id == "test-spec":
            return sentinel
        return None

    register(
        PluginManifest(
            name="testchecker",
            version="0",
            hooks={"custom_compliance_check": custom_check},
        ),
    )
    result = au.compliance.check_standard(
        "test-spec", plugin="testchecker", x=1, y=2,
    )
    assert result is sentinel


def test_compliance_check_standard_fanout_when_no_plugin_named():
    clear()

    def good_check(spec_id: str, **kwargs: Any) -> Any:
        if spec_id == "my-spec":
            return {"matched": "by-fanout"}
        return None

    def silent_check(spec_id: str, **kwargs: Any) -> Any:
        return None

    register(
        PluginManifest(
            name="silent",
            version="0",
            hooks={"custom_compliance_check": silent_check},
        ),
    )
    register(
        PluginManifest(
            name="good",
            version="0",
            hooks={"custom_compliance_check": good_check},
        ),
    )
    result = au.compliance.check_standard("my-spec")
    assert result == {"matched": "by-fanout"}


# ---------------------------------------------------------------------------
# End-to-end with real installed reference plugins
#
# These tests skip cleanly when the plugin isn't installed.
# ---------------------------------------------------------------------------


def _have(modname: str) -> bool:
    try:
        importlib.import_module(modname)
        return True
    except ImportError:
        return False


@pytest.mark.skipif(
    not _have("austenite_extras_mil5j"),
    reason="austenite-extras-mil5j not installed",
)
def test_mil5j_discovers_via_entry_points():
    # Reset and re-scan to pick up the installed plugin.
    clear()
    discover()
    installed = au.plugins.list_installed()
    assert "mil5j" in installed
    m = au.plugins.load("mil5j")
    assert m.name == "mil5j"
    assert "MIL-HDBK-5J" in m.citation


@pytest.mark.skipif(
    not _have("austenite_extras_mil5j"),
    reason="austenite-extras-mil5j not installed",
)
def test_mil5j_alloy_data_merges_via_au_data_alloys():
    clear()
    discover()
    rows = au.data.alloys(plugin="mil5j")
    try:
        import pandas as pd  # noqa: F401
        names = rows["name"].tolist()
    except ImportError:
        names = [r["name"] for r in rows]
    assert any("Ti-6Al-4V" in n for n in names)
    assert any("Inconel 718" in n or "Inconel-718" in n for n in names)


@pytest.mark.skipif(
    not _have("austenite_extras_mil5j"),
    reason="austenite-extras-mil5j not installed",
)
def test_mil5j_fatigue_curves_filter_by_alloy():
    clear()
    discover()
    rows = au.data.fatigue_curves("Ti-6Al-4V", plugin="mil5j")
    try:
        import pandas as pd  # noqa: F401
        assert len(rows) >= 3
        assert any("MIL-HDBK-5J" in c for c in rows["citation"])
    except ImportError:
        assert len(rows) >= 3


@pytest.mark.skipif(
    not _have("austenite_extras_sandia_mms"),
    reason="austenite-extras-sandia-mms not installed",
)
def test_sandia_mms_discovers_via_entry_points():
    clear()
    discover()
    assert "sandia-mms" in au.plugins.list_installed()


@pytest.mark.skipif(
    not _have("austenite_extras_sandia_mms"),
    reason="austenite-extras-sandia-mms not installed",
)
def test_sandia_mms_kic_data_filters_to_alloy():
    clear(rediscover=True)
    discover()
    # When plugin is requested, plugin rows are merged with core rows then
    # filtered by alloy substring. At least some rows from the plugin must
    # show up (recognisable by their SAND citation).
    rows = au.data.kic_database("Ti-6Al-4V", plugin="sandia-mms")
    try:
        import pandas as pd  # noqa: F401
        assert len(rows) >= 3
        cits = rows["citation"].tolist()
    except ImportError:
        assert len(rows) >= 3
        cits = [r["citation"] for r in rows]
    sand_rows = [c for c in cits if "SAND" in c]
    assert len(sand_rows) >= 3, f"expected SAND citations among {cits}"


@pytest.mark.skipif(
    not _have("austenite_extras_corro_rates"),
    reason="austenite-extras-corro-rates not installed",
)
def test_corro_rates_discovers_via_entry_points():
    clear()
    discover()
    assert "corro-rates" in au.plugins.list_installed()


@pytest.mark.skipif(
    not _have("austenite_extras_corro_rates"),
    reason="austenite-extras-corro-rates not installed",
)
def test_corro_rates_dewaard_check_standard_dispatch():
    clear()
    discover()
    verdict = au.compliance.check_standard(
        "de-waard-1995-CO2",
        plugin="corro-rates",
        T_C=80, p_CO2_bar=2.0, pH=4.5, threshold_mmyr=0.1,
    )
    # Plugin returns a StandardVerdict-like object
    assert getattr(verdict, "spec_id", None) == "de-waard-1995-CO2"
    assert verdict.value > 0


@pytest.mark.skipif(
    not _have("austenite_extras_corro_rates"),
    reason="austenite-extras-corro-rates not installed",
)
def test_corro_rates_standards_listed_in_list_standards():
    clear()
    discover()
    standards = au.compliance.list_standards()
    assert "de-waard-1995-CO2" in standards
    assert "mcconomy-1956-sulfidation" in standards
    assert "cassagne-1996-amine-SCC" in standards
