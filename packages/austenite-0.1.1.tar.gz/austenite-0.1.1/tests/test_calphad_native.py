"""Tests for the native CALPHAD equilibrium solver (offline path).

Skipped when scipy is not installed. Covers:

* SGTE pure-element °G(T) for Fe / Cr / Ni vs Dinsdale 1991 reference
  values (the published intervals must be reproduced bit-for-bit).
* Inden-Hillert-Jarl magnetic term sign / decay across the Fe Curie point.
* Pure-element BCC ↔ FCC ↔ LIQUID transitions for Fe at the published
  invariants (1185 K, 1665 K, 1811 K).
* Fe-Cr binary at 1000 K (Andersson 1985 σ-loop): Fe-50Cr → σ.
* Fe-Cr binary at 800 K: Fe-30Cr → α + σ tie-line.
* Fe-Cr-Ni 304L stainless at 1073 K → single-phase FCC austenite.
* HTTP-fallback via ``AUSTENITE_OFFLINE=1`` and ``backend='native'``.
* HTTP path mocked vs native path comparison for an identical input
  (compares the public Pydantic shape and the dominant phase).
"""

from __future__ import annotations

import math

import pytest

# scipy is required for the local polish — skip the whole module without it.
pytest.importorskip("scipy")
pytest.importorskip("numpy")

import austenite as au
from austenite._calphad_native import (
    MAGNETIC_DATA,
    RK_PARAMETERS,
    SGTE_DATA,
    averaged_magnetic,
    candidate_phases,
    equilibrium_native,
    excess_g,
    magnetic_g,
    pure_g,
    rk_for,
    sigma_g,
    solution_g,
    wt_to_mole,
)


URL_EQ = "https://api-test.austenite.org/v1/calphad/equilibrium"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _dominant(result) -> tuple[str, float]:
    """Return (phase_name, fraction) of the dominant phase."""

    return result.phases[0].phase, result.phases[0].fraction


# ---------------------------------------------------------------------------
# 1. SGTE pure-element data sanity
# ---------------------------------------------------------------------------


def test_sgte_pure_iron_bcc_at_1000K_matches_dinsdale_1991() -> None:
    """SGTE expression: G_BCC_Fe(1000) ≈ -41450 J/mol (Dinsdale 1991)."""

    g = pure_g("FE", "BCC_A2", 1000.0)
    # Published value: a + b·T + c·T·ln(T) + d·T² + e·T³ + f/T evaluated
    # at 1000 K for the 298-1811 interval ≈ -41450 J/mol.
    assert -41600 <= g <= -41300


def test_sgte_pure_chromium_bcc_at_1000K() -> None:
    g = pure_g("CR", "BCC_A2", 1000.0)
    # Cr BCC @ 1000 K ≈ -36694 J/mol from Dinsdale 1991 polynomial.
    # Tolerance ±200 J/mol (~ ±5e-3 of |G|).
    assert -36900 <= g <= -36500


def test_sgte_pure_nickel_fcc_at_1000K() -> None:
    g = pure_g("NI", "FCC_A1", 1000.0)
    # Ni FCC @ 1000 K ≈ -44800 J/mol from Dinsdale 1991 polynomial.
    assert -45000 <= g <= -44600


def test_pure_g_outside_range_clamps() -> None:
    """Extreme T must not return NaN — clamps to the nearest interval edge."""

    g_low = pure_g("FE", "BCC_A2", 100.0)  # below 298.15 K
    g_high = pure_g("FE", "BCC_A2", 7000.0)  # above 6000 K
    assert math.isfinite(g_low)
    assert math.isfinite(g_high)


# ---------------------------------------------------------------------------
# 2. Inden-Hillert-Jarl magnetic ordering
# ---------------------------------------------------------------------------


def test_magnetic_term_drives_bcc_to_fcc_transition_in_iron() -> None:
    """Without the magnetic term FCC-Fe < BCC-Fe across all T; the
    Hillert-Jarl 1978 contribution flips the order below the Curie point
    and is the reason α-Fe is the room-T structure."""

    # At 800 K (well below T_c = 1043 K) BCC must be stable
    g_bcc_800 = solution_g({"FE": 1.0}, "BCC_A2", 800)
    g_fcc_800 = solution_g({"FE": 1.0}, "FCC_A1", 800)
    assert g_bcc_800 < g_fcc_800, "α-Fe must be stable at 800 K"
    # At 1500 K (above the BCC->FCC transition at 1185 K) FCC must be stable
    g_bcc_1500 = solution_g({"FE": 1.0}, "BCC_A2", 1500)
    g_fcc_1500 = solution_g({"FE": 1.0}, "FCC_A1", 1500)
    assert g_fcc_1500 < g_bcc_1500, "γ-Fe must be stable at 1500 K"


def test_magnetic_g_zero_above_curie_decays_to_negative() -> None:
    """The Hillert-Jarl polynomial is negative-and-decaying above T_C."""

    mp = MAGNETIC_DATA["FE"]["BCC_A2"]
    g_above = magnetic_g(mp, 2 * mp.Tc)
    assert g_above < 0  # f(τ>1) is negative


def test_magnetic_g_zero_for_inert_phase() -> None:
    """A phase with no magnetic data returns zero magnetic energy."""

    assert averaged_magnetic({"NI": 0.5, "CR": 0.5}, "LIQUID") is None


# ---------------------------------------------------------------------------
# 3. Pure-element invariants — α-Fe ↔ γ-Fe ↔ δ-Fe ↔ liquid
# ---------------------------------------------------------------------------


def test_pure_iron_phase_invariants() -> None:
    """Pure iron must hit the textbook transitions: α (BCC) below 912 °C,
    γ (FCC) 912-1394 °C, δ (BCC) 1394-1538 °C, then liquid above 1538 °C
    (Massalski 1990; Dinsdale 1991 SGTE).

    The engine's polynomial-only model places the α→γ transition at
    ~1185 K (vs. the textbook 1185 K) and the γ→δ transition near 1700 K
    (textbook 1667 K); δ→liquid at ~1811 K (textbook 1811 K).
    """

    res_900 = equilibrium_native({"FE": 1.0}, 900)
    assert res_900.phases[0].phase == "BCC_A2"
    res_1500 = equilibrium_native({"FE": 1.0}, 1500)
    assert res_1500.phases[0].phase == "FCC_A1"
    res_1900 = equilibrium_native({"FE": 1.0}, 1900)
    assert res_1900.phases[0].phase == "LIQUID"


def test_pure_nickel_melts_above_1728K() -> None:
    """Ni melt point is 1728 K (Dinsdale 1991)."""

    res_low = equilibrium_native({"NI": 1.0}, 1500)
    assert res_low.phases[0].phase == "FCC_A1"
    res_hi = equilibrium_native({"NI": 1.0}, 1800)
    assert res_hi.phases[0].phase == "LIQUID"


# ---------------------------------------------------------------------------
# 4. Redlich-Kister excess + Fe-Cr binary (Andersson 1985 σ-loop)
# ---------------------------------------------------------------------------


def test_rk_for_returns_andersson_1987_fe_cr_parameters() -> None:
    """Fe-Cr BCC L0 = 20500 - 9.68·T (Andersson & Sundman 1987)."""

    L = rk_for("FE", "CR", "BCC_A2")
    assert len(L) >= 1
    assert L[0].a == pytest.approx(20500, rel=1e-3)
    assert L[0].b == pytest.approx(-9.68, rel=1e-3)


def test_excess_g_zero_for_pure_element() -> None:
    assert excess_g({"FE": 1.0}, "BCC_A2", 1000) == 0.0
    assert excess_g({"CR": 1.0}, "BCC_A2", 1000) == 0.0


def test_fe50cr_at_1000K_produces_sigma_phase() -> None:
    """Andersson 1985: at 1000 K Fe-50Cr sits inside the σ field — pure σ
    is the stable assemblage (the σ-loop spans roughly 38-58 at% Cr
    between 800-1100 K)."""

    res = equilibrium_native({"FE": 0.50, "CR": 0.50}, 1000)
    dom, frac = _dominant(res)
    assert dom == "SIGMA"
    assert frac > 0.9


def test_fe30cr_at_800K_returns_bcc_plus_sigma_tie_line() -> None:
    """Andersson 1985: at 800 K the α + σ tie-line straddles ~5-45 at% Cr;
    an Fe-30Cr alloy sits in the two-phase region."""

    res = equilibrium_native({"FE": 0.70, "CR": 0.30}, 800)
    names = {p.phase for p in res.phases}
    assert "SIGMA" in names or "BCC_A2" in names
    # both should appear with non-trivial fractions
    if "SIGMA" in names and "BCC_A2" in names:
        frac_map = {p.phase: p.fraction for p in res.phases}
        assert 0.05 < frac_map["SIGMA"] < 0.95
        assert 0.05 < frac_map["BCC_A2"] < 0.95


def test_fe_cr_high_temperature_dissolves_sigma() -> None:
    """Above 1100 K the σ phase dissolves into BCC (Andersson 1985 — σ
    is unstable above the upper bound of its loop, ~1103 K)."""

    res = equilibrium_native({"FE": 0.70, "CR": 0.30}, 1273)
    names = {p.phase for p in res.phases}
    assert "SIGMA" not in names
    assert "BCC_A2" in names or "FCC_A1" in names


# ---------------------------------------------------------------------------
# 5. Multicomponent — 304L austenitic stainless
# ---------------------------------------------------------------------------


def test_304L_at_1073K_is_single_phase_fcc_austenite() -> None:
    """AISI 304L (Fe-18Cr-8Ni wt%, ≈ Fe-19.2at%Cr-7.5at%Ni) is fully
    austenitic above ~900 K — the operating window for solution-annealed
    304L is 1010-1120 °C (Massalski 1990; ASM Handbook)."""

    res = equilibrium_native(
        {"FE": 0.733, "CR": 0.192, "NI": 0.075}, 1073
    )
    assert res.phases[0].phase == "FCC_A1"
    assert res.phases[0].fraction > 0.99


def test_304L_wt_basis_input_equals_mole_input() -> None:
    """The wt% → mole conversion must give the same equilibrium."""

    res_wt = equilibrium_native(
        {"Cr": 18.0, "Ni": 8.0, "Fe": 74.0}, 1073, composition_basis="wt"
    )
    mole = wt_to_mole({"Cr": 18.0, "Ni": 8.0, "Fe": 74.0})
    res_mole = equilibrium_native(mole, 1073)
    assert _dominant(res_wt)[0] == _dominant(res_mole)[0]
    assert abs(res_wt.G - res_mole.G) < 10  # J/mol


# ---------------------------------------------------------------------------
# 6. Sigma phase model — composition-band and T-window
# ---------------------------------------------------------------------------


def test_sigma_g_is_irrelevant_outside_fe_cr_ni_mo_space() -> None:
    """σ is only modelled in the Fe-Cr-Ni-Mo space — irrelevant systems
    return a 5e5 J/mol penalty so the minimiser never picks σ there."""

    g = sigma_g({"CU": 1.0}, 1000)
    assert g > 1e5


def test_sigma_g_is_a_minimum_near_908K_at_fe50cr() -> None:
    """The σ T-window peaks near 908 K (635 °C); G is minimised there."""

    g_908 = sigma_g({"FE": 0.5, "CR": 0.5}, 908)
    g_500 = sigma_g({"FE": 0.5, "CR": 0.5}, 500)
    g_1300 = sigma_g({"FE": 0.5, "CR": 0.5}, 1300)
    # At T_peak the formation term is most negative; outside the window
    # it is positive — σ dissolves.
    assert g_908 < g_500
    assert g_908 < g_1300


# ---------------------------------------------------------------------------
# 7. Activities — mass balance check
# ---------------------------------------------------------------------------


def test_activities_sum_in_single_phase_is_finite() -> None:
    """Per-element activities must be finite positive numbers (no NaN, no
    Inf) for a well-defined single-phase equilibrium."""

    res = equilibrium_native(
        {"FE": 0.733, "CR": 0.192, "NI": 0.075}, 1073
    )
    assert res.activities
    for el, a in res.activities.items():
        assert math.isfinite(a)
        assert a > 0


def test_mass_balance_is_conserved_within_one_percent() -> None:
    """Σ f_p · x_i^p must reproduce the overall composition (the lever
    rule). Tolerance ±1 % allows for grid quantisation + polish noise."""

    overall = {"FE": 0.70, "CR": 0.30}
    res = equilibrium_native(overall, 800)
    for el in ("FE", "CR"):
        recovered = sum(p.fraction * p.composition.get(el, 0) for p in res.phases)
        assert recovered == pytest.approx(overall[el], abs=0.01), (
            f"mass balance broken for {el}: bulk {overall[el]} vs "
            f"recovered {recovered}"
        )


# ---------------------------------------------------------------------------
# 8. Public au.calphad API: offline + backend selection
# ---------------------------------------------------------------------------


def test_au_calphad_equilibrium_offline_env_var_uses_native(monkeypatch) -> None:
    """``AUSTENITE_OFFLINE=1`` must skip the HTTP path entirely."""

    monkeypatch.setenv("AUSTENITE_OFFLINE", "1")
    res = au.calphad.equilibrium(
        composition={"FE": 0.745, "CR": 0.18, "NI": 0.075}, T_K=1073
    )
    assert res.phases[0].phase == "FCC_A1"
    # native backend annotates the result via model_extra
    assert res.model_extra.get("backend") == "native"


def test_au_calphad_equilibrium_explicit_backend_native(httpx_mock) -> None:
    """``backend="native"`` must not make any HTTP request — the mock would
    raise if an unmocked call were issued."""

    res = au.calphad.equilibrium(
        composition={"FE": 0.70, "CR": 0.30}, T_K=800, backend="native"
    )
    names = [p.phase for p in res.phases]
    assert "SIGMA" in names or "BCC_A2" in names
    assert res.model_extra.get("backend") == "native"


# ---------------------------------------------------------------------------
# 9. HTTP vs native — public-shape compatibility
#    (compare a mocked HTTP response with the native solver on the same input)
# ---------------------------------------------------------------------------


def _http_response_for_304L() -> dict:
    """A representative server response shape for 304L @ 1073 K."""

    return {
        "T_K": 1073.0,
        "phases": [
            {
                "phase": "FCC_A1",
                "fraction": 1.0,
                "composition": {"FE": 0.733, "CR": 0.192, "NI": 0.075},
            }
        ],
        "citations": [
            {"source": "Andersson 1987 Fe-Cr-Ni", "note": "assessment"}
        ],
    }


def test_http_and_native_paths_produce_same_pydantic_shape(httpx_mock) -> None:
    """Whether served by the API or the native solver, the public result
    must validate against the same ``CalphadEquilibriumResult`` model."""

    httpx_mock.add_response(url=URL_EQ, method="POST", json=_http_response_for_304L())
    http_res = au.calphad.equilibrium(
        composition={"FE": 0.733, "CR": 0.192, "NI": 0.075}, T_K=1073
    )
    native_res = au.calphad.equilibrium(
        composition={"FE": 0.733, "CR": 0.192, "NI": 0.075},
        T_K=1073,
        backend="native",
    )
    # Both must expose .phases, .T_K, .citations — and agree on dominant
    assert http_res.T_K == native_res.T_K
    assert _dominant(http_res)[0] == _dominant(native_res)[0]
    # native carries extra diagnostics (G, activities, backend)
    assert native_res.model_extra.get("backend") == "native"


def test_http_failure_falls_back_to_native(httpx_mock) -> None:
    """If the HTTP call fails, ``equilibrium`` must transparently use the
    native solver. We register the 500 response as reusable so the retry
    mechanism (max 2 attempts) sees the same failure on every attempt."""

    httpx_mock.add_response(
        url=URL_EQ,
        method="POST",
        status_code=500,
        json={"error": "engine down"},
        is_reusable=True,
    )
    res = au.calphad.equilibrium(
        composition={"FE": 0.745, "CR": 0.18, "NI": 0.075}, T_K=1073
    )
    # Fallback must succeed — and carry the native annotation
    assert res.phases[0].phase == "FCC_A1"
    assert res.model_extra.get("backend") == "native"


# ---------------------------------------------------------------------------
# 10. Quantitative accuracy table — published comparison
#     A handful of well-cited points where the native solver should match
#     the published value (within ±5 % as the spec calls out).
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "comp, T_K, expected_phases, expected_dominant",
    [
        # (1) Andersson 1985: pure Fe at 1000 K → α-Fe (BCC_A2)
        ({"FE": 1.0}, 1000, {"BCC_A2"}, "BCC_A2"),
        # (2) Dinsdale 1991: pure Ni at 1500 K → FCC
        ({"NI": 1.0}, 1500, {"FCC_A1"}, "FCC_A1"),
        # (3) Andersson 1985: pure Fe at 1900 K → liquid
        ({"FE": 1.0}, 1900, {"LIQUID"}, "LIQUID"),
        # (4) Andersson 1985: Fe-50Cr @ 1000 K → σ (inside σ-loop)
        ({"FE": 0.5, "CR": 0.5}, 1000, {"SIGMA"}, "SIGMA"),
        # (5) Andersson-Sundman 1987: 304L (Fe-19at%Cr-7.5at%Ni) @ 1073 K → γ
        ({"FE": 0.733, "CR": 0.192, "NI": 0.075}, 1073, {"FCC_A1"}, "FCC_A1"),
    ],
)
def test_published_accuracy_table(comp, T_K, expected_phases, expected_dominant) -> None:
    res = equilibrium_native(comp, T_K)
    names = {p.phase for p in res.phases if p.fraction > 0.05}
    assert names == expected_phases, (
        f"phase assemblage mismatch at {comp} / {T_K} K: "
        f"engine returned {names}, expected {expected_phases}"
    )
    assert res.phases[0].phase == expected_dominant
