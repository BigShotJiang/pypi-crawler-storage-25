"""Physics-accuracy audit of the fatigue package.

Each test below works a concrete numerical example by hand from the cited
fatigue/fracture literature (Dowling "Mechanical Behavior of Materials";
Bannantine/Comer/Handrock "Fundamentals of Metal Fatigue Analysis"; Socie &
Marquis "Multiaxial Fatigue"; ASME B&PV Section III Subsection NH / Code Case
N-47) and asserts the public ``austenite`` function reproduces it within an
explicit tolerance.

NOTE: there is no ``fracture.py`` module in this package (verified with Glob),
so the "fracture" half of the audit has nothing to test. All tests target
``au.fatigue.*``.

Two genuine physics inaccuracies were found in the library and have since been
fixed in the source: (1) the spurious factor-of-2 on the notch-root strain
amplitude in ``neuber_rule`` / ``glinka_rule``, and (2) the over-conservative
single-line creep-fatigue envelope, now the correct ASME-III NH bilinear curve.
The tests below assert the CORRECTED behaviour against the cited literature.
"""
from __future__ import annotations

import math

import pytest

import austenite as au
from austenite.fatigue.creep_fatigue import (
    creep_fatigue_interaction,
    eccc_LMP_lookup,
    larson_miller_parameter,
    manson_haferd_parameter,
    norton_bailey_strain_rate,
    robinson_damage,
    time_from_LMP,
    wilshire_rupture_life_hours,
)
from austenite.fatigue.creep_fatigue import CreepBlock
from austenite.fatigue.multiaxial import (
    LoadBlock,
    brown_miller_critical_plane,
    crossland_criterion,
    dang_van_criterion,
    findley_critical_plane,
    mean_stress_correction,
    miner_damage,
)
from austenite.fatigue.notched import (
    glinka_rule,
    kf_from_kt,
    neuber_rule,
    topper_rule,
)

# Common cyclic / strain-life property set (SAE-1045-like, Dowling Table 14.1).
E_GPA = 200.0
E_MPA = E_GPA * 1000.0
KPRIME = 1258.0
NPRIME = 0.208
SIG_F = 948.0
B = -0.092
EPS_F = 0.26
C = -0.445


# ===========================================================================
# 1. MEAN-STRESS CORRECTIONS  (Goodman / Soderberg / Gerber / Morrow / SWT / Walker)
# ===========================================================================


def test_goodman_dowling_example():
    # Goodman: sigma_ar = sigma_a / (1 - sigma_m/su).
    # sigma_a=200, sigma_m=100, su=500 -> 200/(1-0.2) = 250 MPa.
    got = mean_stress_correction(200, 100, method="goodman", sigma_uts_MPa=500)
    assert got == pytest.approx(250.0, rel=1e-6)


def test_soderberg_yield_based():
    # Soderberg uses yield: 200/(1 - 100/400) = 266.67 MPa.
    got = mean_stress_correction(
        200, 100, method="soderberg", sigma_uts_MPa=500, sigma_y_MPa=400
    )
    assert got == pytest.approx(800.0 / 3.0, rel=1e-6)


def test_gerber_parabolic():
    # Gerber: 200 / (1 - (100/500)^2) = 200/0.96 = 208.33 MPa.
    got = mean_stress_correction(200, 100, method="gerber", sigma_uts_MPa=500)
    assert got == pytest.approx(208.3333, rel=1e-5)


def test_morrow_true_fracture_stress():
    # Morrow: sigma_a / (1 - sigma_m/sigma_f'). sigma_f'=600 -> 200/(1-100/600)=240.
    got = mean_stress_correction(
        200, 100, method="morrow", sigma_fracture_MPa=600
    )
    assert got == pytest.approx(240.0, rel=1e-6)


def test_swt_equivalent_amplitude():
    # SWT amplitude = sqrt(sigma_max * sigma_a) = sqrt(300*200) = 244.95 MPa.
    got = mean_stress_correction(200, 100, method="swt")
    assert got == pytest.approx(math.sqrt(300.0 * 200.0), rel=1e-9)


def test_walker_gamma_half_reduces_to_swt():
    # Walker with gamma=0.5 is identical to SWT amplitude form.
    got = mean_stress_correction(200, 100, method="walker", walker_gamma=0.5)
    assert got == pytest.approx(math.sqrt(300.0 * 200.0), rel=1e-9)


def test_walker_gamma_tunable():
    # Walker: sigma_max^(1-g) * sigma_a^g.  g=0.7 -> 300^0.3 * 200^0.7.
    got = mean_stress_correction(200, 100, method="walker", walker_gamma=0.7)
    assert got == pytest.approx(300 ** 0.3 * 200 ** 0.7, rel=1e-9)


def test_goodman_compressive_mean_no_penalty():
    # Compressive mean stress gives no Goodman benefit/penalty: returns amplitude.
    got = mean_stress_correction(200, -100, method="goodman", sigma_uts_MPa=500)
    assert got == pytest.approx(200.0, rel=1e-9)


# ===========================================================================
# 2. CRITICAL-PLANE CRITERIA  (Findley / Brown-Miller)
# ===========================================================================


def test_findley_uniaxial_closed_form():
    # Socie & Marquis: under uniaxial sigma_a, the Findley parameter maximises
    # to sigma_a * (sqrt(1+k^2) + k) / 2 on a plane at theta = 0.5*atan(1/k)
    # measured appropriately. For sigma_a=100, k=0.3: 67.20.
    r = findley_critical_plane(100.0, 0.0, 0.0, findley_k=0.3)
    expected = 100.0 * (math.sqrt(1 + 0.3 ** 2) + 0.3) / 2.0
    assert r.damage_parameter == pytest.approx(expected, rel=1e-3)
    assert r.method == "findley"


def test_findley_pure_torsion_closed_form():
    # Pure torsion tau_a: max Findley parameter = tau_a*sqrt(1+k^2) at the
    # critical plane near theta = 0.5*atan(k).  tau_a=100, k=0.3 -> 104.40.
    r = findley_critical_plane(0.0, 0.0, 100.0, findley_k=0.3)
    assert r.damage_parameter == pytest.approx(100.0 * math.sqrt(1.09), rel=1e-3)
    assert r.theta_deg == pytest.approx(0.5 * math.degrees(math.atan(0.3)), abs=1.0)


def test_brown_miller_uniaxial_normal_strain_plane():
    # Brown-Miller parameter = gamma_max + s*eps_n.  As a monotonicity / sanity
    # check, larger normal strain on the critical plane must raise the parameter.
    low = brown_miller_critical_plane(0.002, 0.001, s=1.65)
    high = brown_miller_critical_plane(0.004, 0.001, s=1.65)
    assert high.damage_parameter > low.damage_parameter
    assert math.isfinite(low.damage_parameter)


# ===========================================================================
# 3. STRESS-INVARIANT CRITERIA  (Crossland / Dang Van)
# ===========================================================================


def test_crossland_alpha_zero_when_te_is_se_over_sqrt3():
    # alpha = (3*te - sqrt(3)*se)/se. If te = se/sqrt(3), alpha = 0 exactly.
    se = 300.0
    c = crossland_criterion(
        100, 50, sigma_endurance_MPa=se, torsion_endurance_MPa=se / math.sqrt(3)
    )
    assert c["alpha"] == pytest.approx(0.0, abs=1e-9)


def test_crossland_equivalent_stress_uniaxial():
    # For uniaxial fully-reversed sigma_a: sqrt(J2_a)=sigma_a/sqrt(3),
    # sigma_h,max=sigma_a/3.  With se=300, te=180:
    #   alpha = (3*180 - sqrt(3)*300)/300 = 0.06795
    #   sigma_eq = 100/sqrt(3) + alpha*100/3 = 60.0 MPa.
    se, te, sa = 300.0, 180.0, 100.0
    c = crossland_criterion(
        sa / math.sqrt(3), sa / 3.0, sigma_endurance_MPa=se, torsion_endurance_MPa=te
    )
    alpha = (3 * te - math.sqrt(3) * se) / se
    assert c["alpha"] == pytest.approx(alpha, rel=1e-9)
    assert c["sigma_eq_MPa"] == pytest.approx(
        sa / math.sqrt(3) + alpha * sa / 3.0, rel=1e-6
    )


def test_dang_van_alpha_published_form():
    # Dang Van: alpha_DV = 3*te/se - 1.5.  se=300, te=se/sqrt(3) -> 0.2320508.
    se = 300.0
    d = dang_van_criterion(
        [100.0, 80.0], [50.0, 40.0],
        sigma_endurance_MPa=se, torsion_endurance_MPa=se / math.sqrt(3),
    )
    assert d["alpha_DV"] == pytest.approx(3 * (se / math.sqrt(3)) / se - 1.5, rel=1e-9)


def test_dang_van_max_over_cycle():
    # max(tau + alpha*sigma_h) is taken over the series. With alpha=0.232 and
    # the (100,50) point dominating: 100 + 0.232*50 = 111.6.
    se = 300.0
    alpha = 3 * (se / math.sqrt(3)) / se - 1.5
    d = dang_van_criterion(
        [100.0, 80.0], [50.0, 40.0],
        sigma_endurance_MPa=se, torsion_endurance_MPa=se / math.sqrt(3),
    )
    assert d["max_dv_param"] == pytest.approx(100.0 + alpha * 50.0, rel=1e-6)


# ===========================================================================
# 4. PALMGREN-MINER + BASQUIN
# ===========================================================================


def test_basquin_life_and_miner_damage():
    # Basquin (amplitude form): N_f = 0.5 * (sigma_a/sigma_f')^(1/b).
    # sigma_a=300, sigma_f'=900, b=-0.1 -> N_f = 0.5*(1/3)^-10 = 29524.5.
    # One block of 10000 cycles -> D = 10000/29524.5 = 0.3387.
    blk = LoadBlock(sigma_amplitude_MPa=300, sigma_mean_MPa=0, n_cycles=10000)
    res = miner_damage(
        [blk], basquin_sigma_f_prime_MPa=900, basquin_b=-0.1, sigma_uts_MPa=1000
    )
    nf_expected = 0.5 * (300.0 / 900.0) ** (1.0 / -0.1)
    assert res["blocks"][0]["N_f"] == pytest.approx(nf_expected, rel=1e-6)
    assert res["damage"] == pytest.approx(10000.0 / nf_expected, rel=1e-6)


def test_miner_damage_accumulates_linearly():
    # Two identical blocks -> exactly double the damage of one.
    blk = LoadBlock(sigma_amplitude_MPa=300, sigma_mean_MPa=0, n_cycles=5000)
    one = miner_damage([blk], basquin_sigma_f_prime_MPa=900, basquin_b=-0.1)
    two = miner_damage([blk, blk], basquin_sigma_f_prime_MPa=900, basquin_b=-0.1)
    assert two["damage"] == pytest.approx(2.0 * one["damage"], rel=1e-9)


# ===========================================================================
# 5. NOTCHED STRAIN-LIFE  (Neuber / Glinka / Topper / Kf)
# ===========================================================================


def test_neuber_solves_correct_local_stress():
    # Neuber product (Kt*Sa)^2/E = sigma_max*eps_max on the cyclic R-O curve.
    # Kt=2, Sa=100, E=200 GPa, K'=1258, n'=0.208 -> sigma_max = 189.22 MPa.
    # (This part of the implementation is correct.)
    r = neuber_rule(
        100, 0, K_t=2.0, E_GPa=E_GPA,
        cyclic_K_prime_MPa=KPRIME, cyclic_n_prime=NPRIME,
        sigma_f_prime_MPa=SIG_F, basquin_b=B,
        epsilon_f_prime=EPS_F, coffin_manson_c=C,
    )
    assert r.sigma_local_max_MPa == pytest.approx(189.22, rel=5e-3)


def test_topper_rule_elastic_local_strain():
    # Topper uses Kf directly: eps_a = Kf*Sa/E. Kf=2, Sa=100, E=200 GPa -> 0.001.
    t = topper_rule(
        100, 0, K_f=2.0, E_GPa=E_GPA,
        sigma_f_prime_MPa=SIG_F, basquin_b=B,
        epsilon_f_prime=EPS_F, coffin_manson_c=C,
    )
    assert t.epsilon_local_amplitude == pytest.approx(2.0 * 100.0 / E_MPA, rel=1e-6)
    assert math.isfinite(t.N_f) and t.N_f > 0


def test_kf_from_kt_peterson_bannantine():
    # Peterson constant a = 0.0254*(2070/su)^1.8 mm  ==  (300/Su_ksi)^1.8 * 1e-3 in.
    # su=1035 MPa (150 ksi): a=0.0885 mm; r=1 mm -> q=0.9187; Kt=3 -> Kf=2.837.
    kf = kf_from_kt(3.0, 1.0, 1035.0, method="peterson")
    a = 0.0254 * (2070.0 / 1035.0) ** 1.8
    q = 1.0 / (1.0 + a / 1.0)
    assert kf == pytest.approx(1.0 + q * (3.0 - 1.0), rel=1e-6)


def test_kf_neuber_notch_method():
    # Neuber notch-radius rule q = 1/(1+sqrt(rho/r)) with rho=0.04*(1450/su)^1.8.
    kf = kf_from_kt(2.5, 2.0, 1000.0, method="neuber-notch")
    rho = 0.04 * (1450.0 / 1000.0) ** 1.8
    q = 1.0 / (1.0 + math.sqrt(rho / 2.0))
    assert kf == pytest.approx(1.0 + q * (2.5 - 1.0), rel=1e-6)


def test_kf_bounded_between_one_and_kt():
    # q in [0,1] => Kf in [1, Kt] always.
    for r_mm in (0.1, 1.0, 5.0):
        kf = kf_from_kt(3.0, r_mm, 800.0, method="peterson")
        assert 1.0 <= kf <= 3.0 + 1e-9


# ===========================================================================
# 6. CREEP: time-temperature parameters + Norton-Bailey + Wilshire
# ===========================================================================


def test_larson_miller_classic_point():
    # LMP = T*(C + log10 t_r). T=811 K, t_r=1e4 h, C=20 -> 811*24 = 19464.
    assert larson_miller_parameter(811.0, 1e4, C=20.0) == pytest.approx(19464.0, rel=1e-9)


def test_larson_miller_round_trip():
    lmp = larson_miller_parameter(811.0, 1e4, C=20.0)
    assert time_from_LMP(lmp, 811.0, C=20.0) == pytest.approx(1e4, rel=1e-6)


def test_manson_haferd_parameter():
    # MHP = (log10 t_r - log_t_a)/(T - T_a). t_r=1e4, T=811, T_a=311, log_t_a=20.
    mh = manson_haferd_parameter(811.0, 1e4, T_a_K=311.0, log_t_a=20.0)
    assert mh == pytest.approx((4.0 - 20.0) / (811.0 - 311.0), rel=1e-9)


def test_norton_bailey_arrhenius():
    # eps_dot = A*sigma^n*exp(-Q/RT).  A=1.5e-10, n=5, Q=350 kJ/mol, sigma=100, T=811.
    got = norton_bailey_strain_rate(100.0, 811.0, A=1.5e-10, n=5.0, Q_kJ_mol=350.0)
    expected = 1.5e-10 * 100.0 ** 5 * math.exp(-350000.0 / (8.314 * 811.0))
    assert got == pytest.approx(expected, rel=1e-9)


def test_norton_bailey_doubling_stress_scales_by_2n():
    # Doubling stress multiplies rate by 2^n (n=5 -> x32).
    lo = norton_bailey_strain_rate(50.0, 811.0, A=1e-10, n=5.0, Q_kJ_mol=350.0)
    hi = norton_bailey_strain_rate(100.0, 811.0, A=1e-10, n=5.0, Q_kJ_mol=350.0)
    assert hi / lo == pytest.approx(2.0 ** 5, rel=1e-9)


def test_wilshire_self_consistent_inversion():
    # The implemented form solves t_r from
    #   sigma/sigma_UTS = exp[-k*(t_r*exp(-Q/RT))^u].
    # Verify the returned t_r reproduces the input stress ratio.
    sig, uts, Q, k, u, T = 100.0, 500.0, 410.0, 31.5e-3, 5.0, 811.0
    tr = wilshire_rupture_life_hours(
        sig, T, sigma_uts_at_T_MPa=uts, Q_kJ_mol=Q, k_constant=k, u_exponent=u
    )
    R = 8.314
    recovered = math.exp(-k * (tr * math.exp(-Q * 1000.0 / (R * T))) ** u)
    assert recovered == pytest.approx(sig / uts, rel=1e-6)


def test_wilshire_higher_stress_shorter_life():
    # Monotonicity: higher stress -> shorter rupture life.
    kw = dict(sigma_uts_at_T_MPa=500.0, Q_kJ_mol=410.0, k_constant=31.5e-3, u_exponent=5.0)
    t_low = wilshire_rupture_life_hours(100.0, 811.0, **kw)
    t_high = wilshire_rupture_life_hours(200.0, 811.0, **kw)
    assert t_high < t_low


# ===========================================================================
# 7. ECCC LMP library + Robinson life-fraction
# ===========================================================================


def test_eccc_lmp_lookup_loglinear():
    # 2.25Cr-1Mo fit: log10(sigma) = a - b*(LMP/1000), a=5.0, b=0.16.
    # sigma=100 -> LMP = 1000*(5 - 2)/0.16 = 18750.
    lmp = eccc_LMP_lookup("2.25Cr-1Mo", 100.0)
    assert lmp == pytest.approx(1000.0 * (5.0 - math.log10(100.0)) / 0.16, rel=1e-6)


def test_robinson_life_fraction_rule():
    # D_creep = sum(t_i / t_r,i). Build a single block at 100 MPa / 811 K for
    # a duration equal to half the computed rupture life -> D = 0.5.
    lmp = eccc_LMP_lookup("2.25Cr-1Mo", 100.0)
    t_r = time_from_LMP(lmp, 811.0, C=20.0)
    blk = CreepBlock(stress_MPa=100.0, temperature_K=811.0, duration_hours=0.5 * t_r)
    res = robinson_damage([blk], sigma_LMP_lookup=lambda s: eccc_LMP_lookup("2.25Cr-1Mo", s))
    assert res["damage"] == pytest.approx(0.5, rel=1e-6)
    assert res["passed"] is True


# ===========================================================================
# 8. CREEP-FATIGUE INTERACTION  (ASME III NH)
# ===========================================================================


def test_creep_fatigue_inside_envelope_passes():
    # ASME-III NH bilinear austenitic envelope: (1.0,0) -> knee (0.3,0.3) -> (0,1.0).
    # At D_creep=0.10 (<= knee 0.3) the allowable D_fatigue lies on the
    # (0,1.0)->(0.3,0.3) leg: df_limit = 1.0 + 0.10*(0.3-1.0)/0.3 = 0.7667.
    # envelope_value = D_f/df_limit - 1 = 0.05/0.7667 - 1 = -0.9348 -> well inside.
    r = creep_fatigue_interaction(D_fatigue=0.05, D_creep=0.10, envelope="austenitic")
    assert r.passed is True
    df_limit = 1.0 + 0.10 * (0.3 - 1.0) / 0.3
    assert r.envelope_value == pytest.approx(0.05 / df_limit - 1.0, rel=1e-6)
    assert r.envelope_value < 0.0


def test_creep_fatigue_ferritic_more_restrictive():
    # Ferritic vertices (0.1,0.0)&(0.0,0.1): the same damage point is much
    # closer to / outside the envelope than for austenitic.
    aust = creep_fatigue_interaction(0.05, 0.05, envelope="austenitic")
    ferr = creep_fatigue_interaction(0.05, 0.05, envelope="ferritic")
    assert ferr.envelope_value > aust.envelope_value


# ===========================================================================
# PREVIOUSLY-BUGGY BEHAVIOUR, NOW FIXED  (assert the corrected literature value)
# ===========================================================================


def test_neuber_strain_amplitude_matches_literature():
    """neuber_rule returns the correct local strain amplitude (no spurious /2).

    The Neuber product sigma*eps = (Kt*Sa)^2/E already uses the stress
    AMPLITUDE Sa, so its solution eps_max IS the strain amplitude (Dowling
    "Mechanical Behavior of Materials" 4th ed., Eq. 14.55-14.58; equivalently
    Bannantine via the Massing-doubled curve gives the identical result).

    For Kt=2, Sa=100 MPa, E=200 GPa, K'=1258 MPa, n'=0.208 the correct local
    strain amplitude is eps_a = 1.057e-3.  An earlier version halved this to
    5.285e-4 (non-conservative); the fix removes the ``/2.0``, so life N_f is
    now ~2e7 cycles rather than the ~1e10 "infinite-life" cap.
    """
    r = neuber_rule(
        100, 0, K_t=2.0, E_GPa=E_GPA,
        cyclic_K_prime_MPa=KPRIME, cyclic_n_prime=NPRIME,
        sigma_f_prime_MPa=SIG_F, basquin_b=B,
        epsilon_f_prime=EPS_F, coffin_manson_c=C,
    )
    # Closed-form strain amplitude on the cyclic R-O curve at sigma_max:
    eps_max = 189.2232516800761 / E_MPA + (189.2232516800761 / KPRIME) ** (1.0 / NPRIME)
    assert eps_max == pytest.approx(1.057e-3, rel=1e-2)
    # Library now returns the full (un-halved) amplitude:
    assert r.epsilon_local_amplitude == pytest.approx(1.057e-3, rel=1e-2)
    assert r.epsilon_local_amplitude == pytest.approx(eps_max, rel=1e-3)
    # Life is now in the finite high-cycle regime, not the ~1e10 cap:
    assert 1e6 < r.N_f < 1e8


def test_glinka_strain_amplitude_matches_literature():
    """glinka_rule returns the correct strain amplitude (identical /2 fix).

    As with Neuber, the strain solved from the amplitude-based SED target is
    already the local strain AMPLITUDE, so it is no longer divided by 2. For
    this property set Glinka tracks Neuber closely, giving eps_a ~ 1.1e-3
    (vs the literature ~1.057e-3 from Neuber), not the old ~5.5e-4.
    """
    g = glinka_rule(
        100, 0, K_t=2.0, E_GPa=E_GPA,
        cyclic_K_prime_MPa=KPRIME, cyclic_n_prime=NPRIME,
        sigma_f_prime_MPa=SIG_F, basquin_b=B,
        epsilon_f_prime=EPS_F, coffin_manson_c=C,
    )
    # Full (un-halved) Glinka amplitude, close to the Neuber ~1.06e-3:
    assert g.epsilon_local_amplitude == pytest.approx(1.108e-3, rel=2e-2)
    assert g.epsilon_local_amplitude > 1.0e-3


def test_creep_fatigue_austenitic_envelope_is_bilinear():
    """ASME-III NH austenitic creep-fatigue envelope is the correct bilinear curve.

    ASME B&PV Section III Subsection NH / Code Case N-47: the austenitic
    (304/316) interaction diagram is BILINEAR with vertices
    (1.0, 0) -> knee (0.3, 0.3) -> (0, 1.0).  Each of D_fatigue and D_creep is
    independently allowed up to 1.0; only the (0.3, 0.3) knee restricts the
    interaction.

    An earlier version used a single straight line ``D_c + D_f <= 0.3`` which
    wrongly rejected acceptable high-temperature designs. The fix implements
    the bilinear boundary, so the points below now PASS.
    """
    # (0.25, 0.25): both below the 0.3 knee -> inside the (1.0,0)->(0.3,0.3)
    # leg -> PASS. df_limit at D_creep=0.25 = 1.0 + 0.25*(0.3-1.0)/0.3 = 0.4167.
    r1 = creep_fatigue_interaction(D_fatigue=0.25, D_creep=0.25, envelope="austenitic")
    assert r1.passed is True
    df_limit1 = 1.0 + 0.25 * (0.3 - 1.0) / 0.3
    assert r1.envelope_value == pytest.approx(0.25 / df_limit1 - 1.0, rel=1e-6)
    assert r1.envelope_value < 0.0

    # (0.50, 0.20): on the (1.0,0)->(0.3,0.3) leg the allowable D_f at
    # D_creep=0.50 = 0.3 + (0.5-0.3)*(0-0.3)/(1-0.3) = 0.2143 > 0.20 -> PASS.
    r2 = creep_fatigue_interaction(D_fatigue=0.20, D_creep=0.50, envelope="austenitic")
    assert r2.passed is True
    df_limit2 = 0.3 + (0.5 - 0.3) * (0.0 - 0.3) / (1.0 - 0.3)
    assert r2.envelope_value == pytest.approx(0.20 / df_limit2 - 1.0, rel=1e-6)

    # The (0.3, 0.3) knee sits exactly on the boundary (envelope_value ~ 0).
    knee = creep_fatigue_interaction(D_fatigue=0.3, D_creep=0.3, envelope="austenitic")
    assert knee.envelope_value == pytest.approx(0.0, abs=1e-9)
    assert knee.passed is True

    # Pure-fatigue intercept is now (0, 1.0): D_fatigue=1.0 at D_creep=0 is
    # exactly on the boundary.
    pure = creep_fatigue_interaction(D_fatigue=1.0, D_creep=0.0, envelope="austenitic")
    assert pure.envelope_value == pytest.approx(0.0, abs=1e-9)
    assert pure.passed is True
