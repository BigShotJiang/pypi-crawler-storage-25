"""Tests for the 8 named AMS heat-treat routes."""

from __future__ import annotations

import pytest

from austenite.ams_heat_treat import (
    AMS_QQ_A_225_5, AMS_QQ_A_250_12, AMS4928, AMS5599, AMS5613, AMS5662,
    AMS5704, AMS6322, available_routes, get_route,
)


def test_ams5662_in718_returns_3_steps() -> None:
    s = AMS5662()
    assert s.alloy_uns == "N07718"
    assert len(s.steps) == 3
    assert s.expected_sigma_y_MPa == 1034
    assert "AMS5662" in s.ams_spec


def test_ams5662_solution_above_delta_solvus() -> None:
    """δ solvus ~ 1010°C — solution T must exceed it."""

    s = AMS5662()
    solution = next(step for step in s.steps if "solution" in step["step"])
    assert solution["T_C"] >= 1010


def test_ams5704_625_anneal() -> None:
    s = AMS5704()
    assert s.alloy_uns == "N06625"
    assert len(s.steps) == 1
    assert s.steps[0]["medium"] == "water"


def test_ams5613_h900_strongest() -> None:
    h900 = AMS5613("H900")
    h1075 = AMS5613("H1075")
    assert h900.expected_sigma_y_MPa > h1075.expected_sigma_y_MPa
    assert h900.expected_HV_min > h1075.expected_HV_max


def test_ams5613_invalid_condition() -> None:
    with pytest.raises(ValueError):
        AMS5613("H1234")


def test_ams5599_hastelloy_low_strength_high_elong() -> None:
    s = AMS5599()
    assert s.expected_sigma_y_MPa < 350
    assert s.expected_elong_pct_min >= 40


def test_ams4928_titanium_default_single_step() -> None:
    s = AMS4928()
    assert len(s.steps) == 1
    s_double = AMS4928(double_anneal=True)
    assert len(s_double.steps) == 2


def test_ams_qq_a_225_5_2024_t3_natural_age() -> None:
    s = AMS_QQ_A_225_5()
    age = next(step for step in s.steps if step["step"] == "natural_age")
    assert age["T_C"] == 25
    assert age["t_h"] >= 96


def test_ams_qq_a_250_12_7075_t6() -> None:
    s = AMS_QQ_A_250_12()
    assert s.alloy_uns == "A97075"
    assert s.expected_sigma_y_MPa == 503


def test_ams6322_temper_inverse_strength() -> None:
    """Higher temper T → lower hardness (Hollomon-Jaffe)."""

    s_low = AMS6322("tempered_200C")
    s_high = AMS6322("tempered_650C")
    assert s_low.expected_HV_min > s_high.expected_HV_max
    assert s_low.expected_sigma_y_MPa > s_high.expected_sigma_y_MPa


def test_registry_lookup() -> None:
    """get_route() resolves all 13 named entries."""

    routes = available_routes()
    assert len(routes) == 13
    for name in routes:
        s = get_route(name)
        assert s.ams_spec
        assert s.alloy_uns
        assert s.steps


def test_registry_unknown_raises() -> None:
    with pytest.raises(KeyError):
        get_route("AMS_UNKNOWN")


def test_every_route_carries_citation() -> None:
    for name in available_routes():
        s = get_route(name)
        assert s.citation, f"{name} missing citation"
        assert len(s.citation) > 10


def test_every_route_has_property_guarantees() -> None:
    for name in available_routes():
        s = get_route(name)
        assert s.expected_sigma_y_MPa > 0, f"{name} σ_y missing"
        assert s.expected_sigma_uts_MPa >= s.expected_sigma_y_MPa
        assert s.expected_HV_min < s.expected_HV_max
