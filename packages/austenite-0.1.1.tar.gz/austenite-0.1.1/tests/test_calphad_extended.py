"""Tests for au._calphad_extended — line compounds + extra alloy systems."""
from __future__ import annotations

import math
import pytest

from austenite._calphad_extended import (
    ALLOY_SYSTEMS,
    CEMENTITE,
    GAMMA_PRIME_NI3AL,
    LINE_COMPOUND_LIBRARY,
    LineCompound,
    M23C6,
    SgteCoeff,
    THETA_AL2CU,
    compound_stable_at,
    get_line_compounds_for_system,
    identify_system,
    line_compound_g,
    predict_precipitates,
    pure_g_extended,
)


# ---------------------------------------------------------------------------
# SGTE pure-element extension
# ---------------------------------------------------------------------------


def test_sgte_extended_al_fcc_finite_in_range():
    g = pure_g_extended("AL", "FCC_A1", 500.0)
    assert math.isfinite(g)


def test_sgte_extended_carbon_graphite_at_1000K():
    g = pure_g_extended("C", "GRAPHITE", 1000.0)
    assert math.isfinite(g)


def test_sgte_extended_titanium_hcp_at_700K():
    g = pure_g_extended("TI", "HCP_A3", 700.0)
    assert math.isfinite(g)


def test_sgte_extended_titanium_bcc_at_1300K():
    """Above β-transus (1155 K) BCC should be defined."""
    g = pure_g_extended("TI", "BCC_A2", 1300.0)
    assert math.isfinite(g)


def test_sgte_extended_unknown_element_returns_nan():
    g = pure_g_extended("XX", "FCC_A1", 500.0)
    assert math.isnan(g)


def test_sgte_extended_below_lowest_T_returns_finite():
    """Below the lowest interval, we extrapolate at the boundary."""
    g = pure_g_extended("AL", "FCC_A1", 250.0)  # below 298 K
    assert math.isfinite(g)


# ---------------------------------------------------------------------------
# Line compounds
# ---------------------------------------------------------------------------


def test_cementite_returns_finite_g():
    g = line_compound_g("CEMENTITE", 1000.0)
    assert math.isfinite(g)


def test_cementite_g_increases_negative_with_T_for_cementite():
    """Cementite has b < 0, so G should DECREASE with T."""
    g_low = line_compound_g("CEMENTITE", 600.0)
    g_high = line_compound_g("CEMENTITE", 1200.0)
    assert g_high < g_low


def test_unknown_compound_returns_nan():
    assert math.isnan(line_compound_g("UNICORN_PHASE", 1000.0))


def test_all_compounds_have_valid_stoichiometry():
    """Every line compound's stoichiometry must sum to ~1.0."""
    for name, lc in LINE_COMPOUND_LIBRARY.items():
        total = sum(lc.stoichiometry.values())
        assert math.isclose(total, 1.0, rel_tol=1e-3), \
            f"{name} stoichiometry sums to {total}, not 1.0"


def test_all_compounds_have_citations():
    for name, lc in LINE_COMPOUND_LIBRARY.items():
        assert lc.citation and len(lc.citation) > 10, \
            f"{name} missing citation"


def test_all_compounds_have_structure_field():
    for name, lc in LINE_COMPOUND_LIBRARY.items():
        # Structure field optional but should be set for all we shipped
        assert isinstance(lc.structure, str)


# ---------------------------------------------------------------------------
# Compound stability heuristic
# ---------------------------------------------------------------------------


def test_compound_stable_at_with_dummy_pure_g():
    """Use a dummy pure_g that always returns 0, so compounds with
    negative G (cementite at any T) are 'stable'."""
    dummy = lambda el, ph, T: 0.0
    # Cementite: a=11369.94-5642=5728, b=-9. At T=1000, G = 5728 - 9000 = -3272.
    # That's negative, so stable vs pure-elements (all 0).
    assert compound_stable_at("CEMENTITE", 1000.0, {"FE": 0.75, "C": 0.25}, dummy)


def test_compound_stable_at_unknown_compound_returns_false():
    """Unknown compound name should return False, not raise."""
    dummy = lambda el, ph, T: 0.0
    assert not compound_stable_at("UNICORN_PHASE", 1000.0, {"FE": 1.0}, dummy)


# ---------------------------------------------------------------------------
# Alloy system identification
# ---------------------------------------------------------------------------


def test_identify_system_picks_fe_c_for_fe_c():
    assert identify_system(["Fe", "C"]) == "fe-c"


def test_identify_system_picks_fe_cr_c_for_4140():
    """4140 = Fe-Cr-Mo-C: should pick fe-cr-mo-c (most specific)."""
    assert identify_system(["Fe", "Cr", "Mo", "C"]) == "fe-cr-mo-c"


def test_identify_system_picks_al_cu_mg_for_2024():
    """AA2024 = Al-Cu-Mg."""
    assert identify_system(["Al", "Cu", "Mg"]) == "al-cu-mg"


def test_identify_system_picks_ni_al_for_inconel():
    """IN718 ~ Ni-Cr-Fe-Al-Ti-Mo-Nb; the only Ni-Al system match."""
    assert identify_system(["Ni", "Cr", "Fe", "Al"]) == "ni-al"


def test_identify_system_unknown_returns_none():
    """Cu-Zn brass isn't in our registry."""
    assert identify_system(["Cu", "Zn"]) is None


def test_get_line_compounds_for_fe_cr_mo_c():
    lcs = get_line_compounds_for_system("fe-cr-mo-c")
    assert len(lcs) == 2  # CEMENTITE, M23C6
    names = {lc.name for lc in lcs}
    assert "CEMENTITE" in names
    assert "M23C6" in names


def test_get_line_compounds_for_unknown_returns_empty():
    assert get_line_compounds_for_system("doesnt-exist") == []


def test_alloy_systems_all_have_citations():
    for key, sys_ in ALLOY_SYSTEMS.items():
        assert sys_.citation and len(sys_.citation) > 10, f"{key} missing citation"
        assert sys_.name and len(sys_.name) > 0


def test_alloy_systems_all_compounds_resolvable():
    """Every line_compound name listed in an AlloySystem must exist in
    LINE_COMPOUND_LIBRARY."""
    for key, sys_ in ALLOY_SYSTEMS.items():
        for lc_name in sys_.line_compounds:
            assert lc_name in LINE_COMPOUND_LIBRARY, \
                f"AlloySystem '{key}' references unknown compound '{lc_name}'"


# ---------------------------------------------------------------------------
# Precipitate prediction
# ---------------------------------------------------------------------------


def test_predict_precipitates_fe_cr_mo_c_returns_carbides():
    """For 4140-like steel chemistry at 600°C tempering, expect cementite."""
    r = predict_precipitates(
        composition={"FE": 0.97, "CR": 0.01, "MO": 0.002, "C": 0.018},
        T_K=873,  # 600°C
    )
    assert r["system"] == "fe-cr-mo-c"
    # At this T, at least one carbide should be flagged stable
    assert isinstance(r["stable_compounds"], list)


def test_predict_precipitates_unsupported_system_returns_empty():
    """For a system we don't cover, return empty stable_compounds."""
    r = predict_precipitates(
        composition={"CU": 0.7, "ZN": 0.3},
        T_K=600,
    )
    assert r["system"] is None
    assert r["stable_compounds"] == []
    assert any("No registered alloy system" in note for note in r.get("notes", []))


def test_predict_precipitates_with_in718_like_chemistry():
    """IN718-like chemistry should match the ni-al system (Ni3Al stable)."""
    r = predict_precipitates(
        composition={"NI": 0.55, "CR": 0.18, "FE": 0.18, "AL": 0.005,
                     "TI": 0.01, "NB": 0.05, "MO": 0.03},
        T_K=973,  # 700°C
    )
    assert r["system"] == "ni-al"  # most specific match
    assert r["T_K"] == 973.0
    assert "system_name" in r


def test_predict_precipitates_composition_normalises():
    """Composition need not sum to 1; should normalise."""
    r = predict_precipitates(
        composition={"AL": 95, "CU": 4, "MG": 1},  # weight-percent style
        T_K=773,
    )
    total = sum(r["composition_normalised"].values())
    assert math.isclose(total, 1.0, rel_tol=1e-3)
