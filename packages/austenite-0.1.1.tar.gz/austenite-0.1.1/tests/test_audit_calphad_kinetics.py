"""Physics-accuracy audit of the CALPHAD + KINETICS modules.

Each test below pins ONE formula against a hand-worked numerical example
taken from the cited literature and asserts agreement within an explicit
tolerance (5-10 % per the audit spec, tighter where the closed form is
exact). This file is purely additive: it does not modify any library code.

Audited surface
---------------
* ``austenite._calphad_native``      — SGTE °G(T), Inden-Hillert-Jarl 1978
  magnetic term, Redlich-Kister excess, native equilibrium assemblage.
* ``austenite._calphad_extended``    — line-compound Gibbs energies,
  precipitate prediction.
* ``austenite.kinetics.jmak``        — Johnson-Mehl-Avrami-Kolmogorov 1939.
* ``austenite.kinetics.grain_growth``— Burke-Turnbull 1952, Zener 1948.
* ``austenite.kinetics.kwn``         — LSW coarsening, classical nucleation,
  Becker-Markvardsen growth.
* ``austenite.kinetics.recrystallization`` — Sellars-Whiteman 1979,
  Zener-Hollomon 1944.

References
----------
* Lukas, Fries, Sundman, "Computational Thermodynamics — The CALPHAD
  Method", CUP 2007.
* Porter & Easterling, "Phase Transformations in Metals and Alloys",
  2nd ed., Chapman & Hall 1992.
* Dinsdale A.T., CALPHAD 15 (1991) 317 — SGTE pure-element data.
* Hillert M., Jarl M., CALPHAD 2 (1978) 227 — magnetic ordering.
* Christian J.W., "Theory of Transformations in Metals and Alloys", 3rd
  ed., Pergamon 2002.
* Lifshitz-Slyozov, J. Phys. Chem. Solids 19 (1961) 35; Wagner 1961.
* Zener C., Hollomon J.H., J. Appl. Phys. 15 (1944) 22.
* Smith C.S. (Zener), Trans. AIME 175 (1948) 15.
"""

from __future__ import annotations

import math

import pytest

# numpy + scipy back the native equilibrium solver / polish.
np = pytest.importorskip("numpy")
pytest.importorskip("scipy")

from austenite._calphad_native import (  # noqa: E402
    R_GAS,
    MagneticParams,
    equilibrium_native,
    excess_g,
    magnetic_g,
    pure_g,
    rk_for,
    solution_g,
    wt_to_mole,
)
from austenite._calphad_extended import (  # noqa: E402
    CEMENTITE,
    GAMMA_PRIME_NI3AL,
    M23C6,
    line_compound_g,
    predict_precipitates,
)
from austenite import _calphad_native as _native  # noqa: E402

from austenite.kinetics.jmak import (  # noqa: E402
    avrami_classical_exponents,
    fit_jmak_avrami_exponent,
    fraction_transformed,
    fraction_transformed_non_isothermal,
)
from austenite.kinetics.grain_growth import (  # noqa: E402
    burke_turnbull,
    grain_growth_with_temperature,
    zener_pinning_radius,
)
from austenite.kinetics.kwn import (  # noqa: E402
    K_B,
    bm_growth_rate,
    lsw_coarsening,
    nucleation_rate_classical,
)
from austenite.kinetics.recrystallization import (  # noqa: E402
    Xrex_kinetics,
    sellars_whiteman_peak_strain,
    zener_hollomon_parameter,
)


# ===========================================================================
# CALPHAD — SGTE pure-element Gibbs energy (Dinsdale 1991)
# ===========================================================================


def _ghserfe(T: float) -> float:
    """Canonical SGTE GHSERFE (Dinsdale 1991), 298.15-1811 K interval.

    G - H_SER = 1225.7 + 124.134 T - 23.5143 T ln T - 0.00439752 T^2
                - 5.89269e-8 T^3 + 77358.5 / T   (J/mol).
    """
    return (
        1225.7
        + 124.134 * T
        - 23.5143 * T * math.log(T)
        - 0.00439752 * T * T
        - 5.89269e-8 * T**3
        + 77358.5 / T
    )


def test_sgte_iron_bcc_matches_dinsdale_polynomial_1000K():
    """pure_g(FE, BCC_A2) must reproduce GHSERFE(1000) ~ -41450 J/mol."""
    g = pure_g("FE", "BCC_A2", 1000.0)
    assert g == pytest.approx(_ghserfe(1000.0), rel=1e-4)
    assert g == pytest.approx(-41450.0, abs=5.0)


def test_sgte_iron_bcc_ser_value_298K():
    """At the SER point GHSERFE(298.15) is the published lattice stability
    ~ -1841 J/mol (NOT zero — the magnetic enthalpy is stored separately)."""
    g = pure_g("FE", "BCC_A2", 298.15)
    assert g == pytest.approx(_ghserfe(298.15), rel=1e-4)
    assert g == pytest.approx(-1841.4, abs=2.0)


def test_sgte_nickel_fcc_1000K():
    """SGTE GHSERNI(1000) ~ -44800 J/mol (Dinsdale 1991)."""
    g = pure_g("NI", "FCC_A1", 1000.0)
    assert g == pytest.approx(-44800.0, abs=10.0)


# ===========================================================================
# CALPHAD — Inden-Hillert-Jarl 1978 magnetic ordering
# ===========================================================================


def _ihj_f(tau: float, p: float) -> float:
    """Hand-coded Hillert-Jarl 1978 f(tau) polynomial for cross-check."""
    A = 518.0 / 1125.0 + (11692.0 / 15975.0) * (1.0 / p - 1.0)
    if tau < 1.0:
        return 1.0 - (1.0 / A) * (
            79.0 / (tau * 140.0 * p)
            + (474.0 / 497.0)
            * (1.0 / p - 1.0)
            * (tau**3 / 6.0 + tau**9 / 135.0 + tau**15 / 600.0)
        )
    return -(1.0 / A) * (tau**-5 / 10.0 + tau**-15 / 315.0 + tau**-25 / 1500.0)


def test_magnetic_normalization_constant_A_for_bcc():
    """A(p=0.4) = 518/1125 + (11692/15975)(1/p - 1) = 1.55828..."""
    A = 518.0 / 1125.0 + (11692.0 / 15975.0) * (1.0 / 0.4 - 1.0)
    assert A == pytest.approx(1.5582848, abs=1e-6)


def test_magnetic_f_polynomial_continuous_at_curie_point():
    """The below-Tc and above-Tc branches of f(tau) must agree at tau=1
    (Hillert-Jarl 1978) — a discontinuity here would be a sign/coeff bug."""
    below = _ihj_f(0.999999, 0.4)
    above = _ihj_f(1.000001, 0.4)
    assert below == pytest.approx(above, abs=1e-4)


def test_magnetic_g_matches_RTln_beta_times_f():
    """G_mag = R T ln(beta+1) f(tau); verify against the closed form for
    BCC Fe (Tc=1043 K, beta=2.22, p=0.4) at T=900 K (tau<1)."""
    mp = MagneticParams(1043.0, 2.22, 0.4)
    T = 900.0
    tau = T / 1043.0
    expected = R_GAS * T * math.log(2.22 + 1.0) * _ihj_f(tau, 0.4)
    assert magnetic_g(mp, T) == pytest.approx(expected, rel=1e-9)


def test_magnetic_g_sign_below_and_above_curie():
    """f(tau) (and hence G_mag, since ln(beta+1)>0) is negative on both
    sides of Tc for ferromagnetic Fe, and decays in magnitude above Tc."""
    mp = MagneticParams(1043.0, 2.22, 0.4)
    g_below = magnetic_g(mp, 800.0)
    g_above_near = magnetic_g(mp, 1200.0)
    g_above_far = magnetic_g(mp, 2086.0)  # tau = 2
    assert g_below < 0.0
    assert g_above_near < 0.0
    assert abs(g_above_far) < abs(g_above_near)  # decays above Tc


def test_magnetic_term_makes_alpha_iron_stable_at_room_T():
    """The magnetic stabilization of BCC Fe is the textbook reason alpha-Fe
    (not gamma-Fe) is stable at low T (Porter & Easterling Fig. 1.x)."""
    g_bcc = solution_g({"FE": 1.0}, "BCC_A2", 600.0)
    g_fcc = solution_g({"FE": 1.0}, "FCC_A1", 600.0)
    assert g_bcc < g_fcc


# ===========================================================================
# CALPHAD — Redlich-Kister excess (Andersson & Sundman 1987 Fe-Cr)
# ===========================================================================


def test_rk_fe_cr_bcc_L0_andersson_sundman_1987():
    """Fe-Cr BCC L0 = 20500 - 9.68 T (Andersson & Sundman, CALPHAD 1987)."""
    L = rk_for("FE", "CR", "BCC_A2")
    assert L[0].a == pytest.approx(20500.0, rel=1e-6)
    assert L[0].b == pytest.approx(-9.68, rel=1e-6)


def test_rk_excess_equals_regular_solution_form_at_equiatomic():
    """For an equiatomic binary (x_A=x_B=0.5), only the L0 term survives the
    R-K sum [G_ex = x_A x_B (L0 + L1 (x_A-x_B) + ...)] because (x_A-x_B)=0,
    so G_ex = 0.25 * L0(T). Check against the Fe-Cr BCC L0 at 1000 K."""
    T = 1000.0
    L0 = 20500.0 - 9.68 * T
    expected = 0.25 * L0
    got = excess_g({"FE": 0.5, "CR": 0.5}, "BCC_A2", T)
    assert got == pytest.approx(expected, rel=1e-9)


def test_rk_excess_zero_for_pure_element():
    """Excess Gibbs energy vanishes for a pure element (x_i=1)."""
    assert excess_g({"FE": 1.0}, "BCC_A2", 1000.0) == 0.0


# ===========================================================================
# CALPHAD — native equilibrium assemblage (Andersson 1985 Fe-Cr sigma loop)
# ===========================================================================


def test_equilibrium_fe50cr_1000K_is_sigma():
    """Fe-50Cr at 1000 K sits inside the sigma loop (Andersson 1985)."""
    res = equilibrium_native({"FE": 0.5, "CR": 0.5}, 1000.0)
    assert res.phases[0].phase == "SIGMA"
    assert res.phases[0].fraction > 0.9


def test_equilibrium_304L_1073K_is_fcc_austenite():
    """Solution-annealed 304L (Fe-19.2Cr-7.5Ni at%) is single-phase FCC
    austenite at 1073 K (ASM Handbook; Massalski 1990)."""
    res = equilibrium_native({"FE": 0.733, "CR": 0.192, "NI": 0.075}, 1073.0)
    assert res.phases[0].phase == "FCC_A1"
    assert res.phases[0].fraction > 0.99


def test_equilibrium_mass_balance_lever_rule():
    """Sum_p f_p * x_i^p must recover the bulk composition (lever rule)
    to within grid+polish noise (<1 at%)."""
    bulk = {"FE": 0.70, "CR": 0.30}
    res = equilibrium_native(bulk, 800.0)
    for el in bulk:
        recovered = sum(p.fraction * p.composition.get(el, 0.0) for p in res.phases)
        assert recovered == pytest.approx(bulk[el], abs=0.01)


def test_equilibrium_wt_basis_matches_mole_basis():
    """wt% input must convert to the same equilibrium as the mole input."""
    res_wt = equilibrium_native(
        {"Fe": 74.0, "Cr": 18.0, "Ni": 8.0}, 1073.0, composition_basis="wt"
    )
    res_mole = equilibrium_native(wt_to_mole({"Fe": 74.0, "Cr": 18.0, "Ni": 8.0}), 1073.0)
    assert res_wt.phases[0].phase == res_mole.phases[0].phase
    assert res_wt.G == pytest.approx(res_mole.G, abs=10.0)


# ===========================================================================
# CALPHAD — extended line compounds (Hillert-Sundman / Dupin assessments)
# ===========================================================================


def test_line_compound_cementite_linear_in_T():
    """CEMENTITE G = a + b T with a = 11369.94 - 5642 = 5727.94, b = -9.0
    (adjusted Hillert-Sundman 1990 reference). Check the closed form."""
    assert CEMENTITE.a == pytest.approx(5727.94, abs=1e-6)
    g = line_compound_g("CEMENTITE", 800.0)
    assert g == pytest.approx(5727.94 - 9.0 * 800.0, rel=1e-9)


def test_line_compound_ni3al_gamma_prime():
    """gamma'-Ni3Al: a=-37100, b=-4.4 (Dupin 2001). G(1000) = -41500 J/mol."""
    assert GAMMA_PRIME_NI3AL.stoichiometry == {"NI": 0.75, "AL": 0.25}
    assert line_compound_g("GAMMA_PRIME_NI3AL", 1000.0) == pytest.approx(-41500.0, rel=1e-9)


def test_line_compound_stoichiometries_sum_to_one():
    """Every line compound's formula-unit fractions must sum to 1.0."""
    for lc in (CEMENTITE, M23C6, GAMMA_PRIME_NI3AL):
        assert sum(lc.stoichiometry.values()) == pytest.approx(1.0, abs=1e-9)


def test_predict_precipitates_crmo_steel():
    """A 2.25Cr-1Mo-style steel at 873 K should screen the fe-cr-mo-c
    system and flag M23C6 + cementite as stable carbides (Andersson 1988)."""
    r = predict_precipitates(
        {"FE": 0.97, "CR": 0.01, "MO": 0.002, "C": 0.018},
        873.0,
        pure_g_func=_native.pure_g,
    )
    assert r["system"] == "fe-cr-mo-c"
    names = {c["name"] for c in r["stable_compounds"]}
    assert "M23C6" in names
    assert "CEMENTITE" in names


# ===========================================================================
# KINETICS — JMAK / Avrami 1939
# ===========================================================================


def test_jmak_characteristic_time_gives_1_minus_1_over_e():
    """At t = tau (the characteristic time where k*tau^n = 1) the JMAK
    fraction is 1 - 1/e = 0.6321 (Christian 2002; the defining property of
    the Avrami equation)."""
    k, n = 1e-4, 2.5
    tau = (1.0 / k) ** (1.0 / n)
    assert fraction_transformed(tau, k, n) == pytest.approx(1.0 - 1.0 / math.e, rel=1e-6)


def test_jmak_half_transformation_time():
    """X = 0.5 when k t^n = ln 2; check the closed-form t_50."""
    k, n = 1e-4, 2.5
    t50 = (math.log(2.0) / k) ** (1.0 / n)
    assert fraction_transformed(t50, k, n) == pytest.approx(0.5, rel=1e-6)


def test_jmak_avrami_plot_recovers_n_and_k():
    """Fitting log(-log(1-X)) vs log(t) must recover the generating
    (n, k) = (2.5, 1e-4) within a few percent."""
    times = [10, 30, 50, 100, 200, 400, 800]
    X = [fraction_transformed(t, 1e-4, 2.5) for t in times]
    n_fit, k_fit = fit_jmak_avrami_exponent(times, X)
    assert n_fit == pytest.approx(2.5, rel=0.05)
    assert k_fit == pytest.approx(1e-4, rel=0.10)


def test_jmak_non_isothermal_isothermal_consistency():
    """Christian's additivity reduces to the isothermal form for constant
    T. Phi = k^(1/n) * t so X = 1 - exp(-(Phi)^n) = 1 - exp(-k t^n)."""
    T = 950.0
    k0, Q_kJ, n = 1e8, 250.0, 2.5
    t_end = 20.0
    Ts = [T] * 5
    ts = [0.0, 5.0, 10.0, 15.0, 20.0]
    X_ni = fraction_transformed_non_isothermal(
        Ts, ts, k_arrhenius_prefactor=k0, activation_energy_kJ_mol=Q_kJ, n=n
    )
    k_T = k0 * math.exp(-Q_kJ * 1000.0 / (8.314 * T))
    X_iso = fraction_transformed(t_end, k_T, n)
    assert X_ni == pytest.approx(X_iso, rel=1e-6)


def test_avrami_classical_exponents_textbook_values():
    """Christian 2002 Ch.12: site-saturation 3D = 3, constant-nucleation
    3D = 4, diffusion-controlled 3D = 1.5, GB-pearlite = 2."""
    d = avrami_classical_exponents()
    assert d["site-saturation-3D"] == 3.0
    assert d["constant-nucleation-3D"] == 4.0
    assert d["diffusion-controlled-3D"] == 1.5
    assert d["pearlite-2D-GB-nucleated"] == 2.0


# ===========================================================================
# KINETICS — grain growth (Burke-Turnbull 1952, Zener 1948)
# ===========================================================================


def test_burke_turnbull_parabolic_law():
    """D^2 - D0^2 = K t (Burke-Turnbull 1952; Porter & Easterling eq. 3.x).
    For D0=10 um, K=2 um^2/s, t=3600 s: D^2-D0^2 must equal 7200."""
    d = burke_turnbull(d0_um=10.0, t_s=3600.0, K_um2_per_s=2.0)
    assert d**2 - 10.0**2 == pytest.approx(2.0 * 3600.0, rel=1e-9)
    assert d == pytest.approx(math.sqrt(100.0 + 7200.0), rel=1e-9)


def test_burke_turnbull_zero_time_is_initial_size():
    assert burke_turnbull(d0_um=25.0, t_s=0.0, K_um2_per_s=5.0) == pytest.approx(25.0, rel=1e-12)


def test_zener_smith_limiting_grain_size():
    """Zener-Smith 1948: D_lim = (4/3) r / f. For r=0.1 um, f=0.05:
    D_lim = (4/3)(0.1)/0.05 = 2.667 um."""
    d_lim = zener_pinning_radius(particle_radius_um=0.1, volume_fraction=0.05)
    assert d_lim == pytest.approx(4.0 / 3.0 * 0.1 / 0.05, rel=1e-9)
    assert d_lim == pytest.approx(2.6667, abs=1e-3)


def test_grain_growth_isothermal_integral_matches_burke_turnbull():
    """Integrating K(T)=K0 exp(-Q/RT) over constant T must equal a direct
    Burke-Turnbull call with that K (consistency of the additivity path)."""
    T_K, K0, Q = 1273.0, 1.6e10, 350.0
    K_T = K0 * math.exp(-Q * 1000.0 / (8.314 * T_K))
    d_int = grain_growth_with_temperature(
        d0_um=20.0,
        T_history_K=[T_K, T_K],
        t_history_s=[0.0, 100.0],
        K_0_um2_per_s=K0,
        activation_energy_kJ_mol=Q,
    )
    d_bt = burke_turnbull(d0_um=20.0, t_s=100.0, K_um2_per_s=K_T)
    assert d_int == pytest.approx(d_bt, rel=1e-6)


# ===========================================================================
# KINETICS — KWN precipitation (LSW 1961, Becker-Doring 1935)
# ===========================================================================


def test_lsw_coarsening_rate_constant():
    """LSW: r^3 - r0^3 = K t with K = (8/9) gamma Vm^2 c_eq D / (R T).
    Verify the full closed form for gamma'-Ni3Al-like inputs."""
    gamma, Vm_cm3, c_eq, D, T = 0.2, 7.1, 0.01, 1e-19, 973.0
    r0, t = 5.0, 3600.0
    Vm = Vm_cm3 * 1e-6  # cm^3/mol -> m^3/mol
    K = (8.0 / 9.0) * gamma * Vm**2 * c_eq * D / (R_GAS * T)  # m^3/s
    K_nm3 = K * 1e27  # m^3 -> nm^3
    expected = (r0**3 + K_nm3 * t) ** (1.0 / 3.0)
    got = lsw_coarsening(
        r0_nm=r0,
        t_s=t,
        gamma_J_m2=gamma,
        V_m_cm3=Vm_cm3,
        c_eq_at_frac=c_eq,
        D_m2_per_s=D,
        T_K=T,
    )
    assert got == pytest.approx(expected, rel=1e-9)


def test_lsw_cube_law_scaling():
    """For r0 ~ 0 the LSW law gives r proportional to t^(1/3): doubling
    by a factor of 8 in time should ~double the radius."""
    kw = dict(
        gamma_J_m2=0.5, V_m_cm3=7.7, c_eq_at_frac=0.02, D_m2_per_s=1e-17, T_K=973.0
    )
    r1 = lsw_coarsening(r0_nm=0.01, t_s=1000.0, **kw)
    r8 = lsw_coarsening(r0_nm=0.01, t_s=8000.0, **kw)
    assert r8 / r1 == pytest.approx(2.0, rel=0.02)


def test_classical_nucleation_barrier_and_rate():
    """ΔG* = (16π/3) γ^3 / ΔG_v^2 (Becker-Döring 1935) and
    J* = N_v Z β* exp(-ΔG*/kT). Verify both against the closed form."""
    gamma, dGv, T = 0.1, -3e8, 1000.0
    dG_star = (16.0 * math.pi / 3.0) * gamma**3 / dGv**2
    N_v, Z, beta = 1e29, 0.01, 1e13
    expected = N_v * Z * beta * math.exp(-dG_star / (K_B * T))
    got = nucleation_rate_classical(
        T_K=T,
        delta_G_v_J_m3=dGv,
        interfacial_energy_J_m2=gamma,
        site_density_per_m3=N_v,
        attachment_freq_per_s=beta,
        zeldovich_factor=Z,
    )
    assert got == pytest.approx(expected, rel=1e-9)


def test_nucleation_rate_rises_with_driving_force():
    """Larger |ΔG_v| -> smaller barrier -> higher J* (monotone)."""
    base = dict(T_K=1000.0, interfacial_energy_J_m2=0.1)
    j_small = nucleation_rate_classical(delta_G_v_J_m3=-2e8, **base)
    j_large = nucleation_rate_classical(delta_G_v_J_m3=-4e8, **base)
    assert j_large > j_small


def test_bm_growth_rate_units_and_sign():
    """Becker-Markvardsen: dr/dt = (D/r)(c_bar - c_eq(r))/(c_p - c_eq(r)),
    with c_eq(r)=c_eq(inf)(1+l_c/r). Verify the value (nm/s) and that a
    supersaturated matrix gives positive growth."""
    D, r = 1e-19, 10.0
    lc = 0.5
    c_eq_r = 0.02 * (1.0 + lc / r)
    driving = (0.05 - c_eq_r) / (0.25 - c_eq_r)
    expected = (D * 1e18) * driving / r  # nm/s
    got = bm_growth_rate(
        r_nm=r,
        c_bulk_at_frac=0.05,
        c_eq_inf_at_frac=0.02,
        c_precipitate_at_frac=0.25,
        D_m2_per_s=D,
    )
    assert got == pytest.approx(expected, rel=1e-9)
    assert got > 0.0


def test_bm_growth_rate_dissolves_when_undersaturated():
    """c_bar < c_eq(r) -> negative rate (dissolution)."""
    rate = bm_growth_rate(
        r_nm=10.0,
        c_bulk_at_frac=0.01,
        c_eq_inf_at_frac=0.02,
        c_precipitate_at_frac=0.25,
        D_m2_per_s=1e-19,
    )
    assert rate < 0.0


# ===========================================================================
# KINETICS — recrystallization (Sellars-Whiteman 1979, Zener-Hollomon 1944)
# ===========================================================================


def test_zener_hollomon_closed_form():
    """Z = eps_dot exp(Q_def / R T) (Zener-Hollomon 1944). Verify against
    the exponential for eps_dot=1 s^-1, Q=300 kJ/mol, T=1273 K."""
    expected = 1.0 * math.exp(300_000.0 / (R_GAS * 1273.0))
    got = zener_hollomon_parameter(strain_rate_per_s=1.0, T_K=1273.0, Q_def_kJ_mol=300.0)
    assert got == pytest.approx(expected, rel=1e-9)


def test_zener_hollomon_temperature_and_rate_trends():
    """Z increases with strain rate and decreases with temperature."""
    z_slow = zener_hollomon_parameter(0.1, 1273.0, 300.0)
    z_fast = zener_hollomon_parameter(10.0, 1273.0, 300.0)
    z_hot = zener_hollomon_parameter(1.0, 1473.0, 300.0)
    z_cold = zener_hollomon_parameter(1.0, 1073.0, 300.0)
    assert z_fast > z_slow
    assert z_cold > z_hot


def test_sellars_whiteman_peak_strain_power_law():
    """eps_peak = A d0^alpha Z^beta (Sellars-Whiteman 1979). Verify the
    closed form for 304L (A=4.9e-4, alpha=0.30, beta=0.15)."""
    A, alpha, beta = 4.9e-4, 0.30, 0.15
    d0, Z = 100.0, 1e12
    expected = A * d0**alpha * Z**beta
    got = sellars_whiteman_peak_strain(d0_um=d0, Z_per_s=Z, alloy="304L")
    assert got == pytest.approx(expected, rel=1e-9)
    assert 0.0 < got < 5.0  # physical range for hot-deformation peak strain


def test_xrex_reaches_half_at_tau50():
    """X_rex = 1 - exp(-0.693 (t/tau50)^n). At t=tau50 the prefactor 0.693
    ~ ln 2 forces X=0.5 (the definition of tau50). Compute tau50 for 304L
    (A50=1.06, p=1.5, q=0.30) at d0=100 um, Z=1e12 and check."""
    A50, p50, q50 = 1.06, 1.5, 0.30
    d0, Z = 100.0, 1e12
    tau50 = A50 * d0**p50 * Z ** (-q50)
    X = Xrex_kinetics(
        eps_applied=1.0, eps_peak=0.5, t_s=tau50, alloy="304L", d0_um=d0, Z_per_s=Z
    )
    assert X == pytest.approx(0.5, abs=0.01)


def test_xrex_zero_below_critical_strain():
    """No DRX initiates below the critical strain (~0.8 eps_peak)."""
    X = Xrex_kinetics(eps_applied=0.1, eps_peak=0.5, t_s=100.0, alloy="304L")
    assert X == 0.0
