"""Tests for the GB/T 711 (Chinese Q-grade structural steel) checker."""

from __future__ import annotations

import pytest

import austenite as au
from austenite.compliance_standards import StandardVerdict, gbt_711


def test_gbt_711_pass_q345b_default() -> None:
    v = gbt_711.check(
        composition={"C": 0.16, "Si": 0.30, "Mn": 1.20, "P": 0.020, "S": 0.015,
                     "V": 0.05, "Nb": 0.04},
        mechanical={"sigma_y_MPa": 360, "sigma_uts_MPa": 520,
                    "elongation_pct": 24, "CVN_J_at_+20C": 50},
    )
    assert isinstance(v, StandardVerdict)
    assert v.passed is True
    assert v.spec_id == "GB/T 711"
    assert "Q345B" in v.citation


def test_gbt_711_pass_q235b_grade() -> None:
    v = gbt_711.check(
        composition={"C": 0.18, "Si": 0.30, "Mn": 1.00, "P": 0.030, "S": 0.030},
        mechanical={"sigma_y_MPa": 250, "sigma_uts_MPa": 400,
                    "elongation_pct": 30, "CVN_J_at_+20C": 35},
        grade="Q235B",
    )
    assert v.passed is True


def test_gbt_711_fail_yield_too_low_q420c() -> None:
    v = gbt_711.check(
        composition={"C": 0.18, "Mn": 1.30, "P": 0.020, "S": 0.020,
                     "Al": 0.025},
        mechanical={"sigma_y_MPa": 400, "sigma_uts_MPa": 540,
                    "elongation_pct": 20, "CVN_J_at_0C": 40},
        grade="Q420C",
    )
    assert v.passed is False
    assert any("sigma_y_MPa" in f and "below min 420" in f for f in v.failed_items)


def test_gbt_711_q345b_ce_iiw_derivation() -> None:
    """CE_IIW should be derived from composition and checked vs the 0.45 max."""

    v = gbt_711.check(
        composition={"C": 0.18, "Mn": 1.50, "Cr": 0.20, "Mo": 0.05,
                     "P": 0.020, "S": 0.015, "Ni": 0.10},
        grade="Q345B",
    )
    # CE_IIW = 0.18 + 1.50/6 + 0.25/5 + 0.10/15 = 0.18 + 0.25 + 0.05 + 0.0067 ≈ 0.487 > 0.45
    assert any("CE_IIW" in f for f in v.failed_items)
