"""Physics-accuracy audit (wave 2): design-code modules.

Each test works a concrete numerical example by hand from the cited code
edition and asserts the library result against it with an explicit
tolerance / boolean assert.

Modules audited:
  * ``austenite.asme_iii``       — ASME BPVC III NB-3221/3222 stress limits,
    NB-3220 cumulative fatigue usage (log-log design-curve interp), and the
    Subsection HBB (Div 5) creep-fatigue bilinear damage envelope.
  * ``austenite.api581_scenarios`` — API RP 581 3rd Ed. RBI: Normal-CDF POF(t),
    expected risk cost, and cost-optimal (interval, method) selection.
  * ``austenite.wps_generator``  — AWS D1.1:2020 / ASME IX WPS: IIW carbon
    equivalent, preheat by CE category + thickness, PWHT by P-number +
    thickness, process heat-input window, NDE selection.

Where the audit found a genuine modelling limitation (see the module-level
notes below) the assertion checks the *documented formula* is reproduced
self-consistently; the limitation is written up in the audit report and is
NOT fixed in the library source.

Run:  python -m pytest tests/test_audit2_codes.py -q
"""
from __future__ import annotations

import math

import pytest

from austenite import api581_scenarios as rbi
from austenite import asme_iii as a3
from austenite import wps_generator as wps


def _phi(z: float) -> float:
    """Standard normal CDF, independent reimplementation for the oracle."""
    return 0.5 * (1.0 + math.erf(z / math.sqrt(2.0)))


# ===========================================================================
# ASME III NB-3221 — primary membrane / membrane+bending stress limits
# ===========================================================================


def test_nb3221_membrane_pass_and_margin():
    """NB-3221.1: P_m <= S_m. Margin = S_m - P_m."""
    ok, margin = a3.primary_membrane_check(130.0, 138.0)
    assert ok is True
    assert margin == pytest.approx(8.0, abs=1e-9)


def test_nb3221_membrane_fail_when_over_sm():
    ok, margin = a3.primary_membrane_check(140.0, 138.0)
    assert ok is False
    assert margin == pytest.approx(-2.0, abs=1e-9)


def test_nb3221_membrane_at_limit_passes():
    """Equality P_m == S_m must pass (<=), margin zero."""
    ok, margin = a3.primary_membrane_check(138.0, 138.0)
    assert ok is True
    assert margin == pytest.approx(0.0, abs=1e-9)


def test_nb3221_bending_uses_1p5_sm_shape_factor():
    """NB-3221.3: P_m + P_b <= 1.5 S_m (default shape factor 1.5)."""
    Sm = 138.0
    ok, margin = a3.primary_bending_check(130.0, 70.0, Sm)
    # limit = 1.5*138 = 207 ; total = 200 ; margin = 7
    assert ok is True
    assert margin == pytest.approx(207.0 - 200.0, abs=1e-9)


def test_nb3221_bending_fails_above_1p5_sm():
    ok, margin = a3.primary_bending_check(130.0, 90.0, 138.0)
    # 220 > 207
    assert ok is False
    assert margin == pytest.approx(207.0 - 220.0, abs=1e-9)


def test_nb3221_bending_custom_shape_factor():
    """A non-default shape factor must scale the allowable linearly."""
    Sm = 100.0
    ok, margin = a3.primary_bending_check(100.0, 20.0, Sm, shape_factor=1.2)
    # limit = 1.2*100 = 120 ; total = 120 ; margin 0 ; passes at equality
    assert ok is True
    assert margin == pytest.approx(0.0, abs=1e-9)


# ===========================================================================
# ASME III NB-3222 — secondary (P + Q) <= 3 S_m
# ===========================================================================


def test_nb3222_secondary_pass_3sm():
    Sm = 138.0
    ok, margin = a3.secondary_stress_check(130.0, 70.0, 200.0, Sm)
    # limit = 3*138 = 414 ; total = 400 ; margin 14
    assert ok is True
    assert margin == pytest.approx(414.0 - 400.0, abs=1e-9)


def test_nb3222_secondary_fail_above_3sm():
    ok, margin = a3.secondary_stress_check(130.0, 70.0, 250.0, 138.0)
    # 450 > 414
    assert ok is False
    assert margin == pytest.approx(414.0 - 450.0, abs=1e-9)


def test_assess_nb_class1_governing_margin_is_min():
    """assess_nb_class1 reports governing margin = min(membrane,bending,P+Q)."""
    Sm = 138.0
    sl = a3.StressLinearization(P_m_MPa=130.0, P_b_MPa=70.0, Q_MPa=200.0, F_MPa=0.0)
    r = a3.assess_nb_class1(sl, Sm)
    assert r.passes_NB3221_membrane is True
    assert r.passes_NB3221_bending is True
    assert r.passes_NB3222_secondary is True
    # margins: 138-130=8 ; 207-200=7 ; 414-400=14 -> min = 7
    assert r.governing_margin == pytest.approx(7.0, abs=1e-9)
    assert r.failures == []


def test_assess_nb_class1_collects_failures_and_citations():
    """A grossly overstressed section trips all three checks with citations."""
    Sm = 100.0
    sl = a3.StressLinearization(P_m_MPa=150.0, P_b_MPa=120.0, Q_MPa=200.0, F_MPa=0.0)
    r = a3.assess_nb_class1(sl, Sm)
    assert r.passes_NB3221_membrane is False  # 150 > 100
    assert r.passes_NB3221_bending is False   # 270 > 150
    assert r.passes_NB3222_secondary is False  # 470 > 300
    assert len(r.failures) == 3
    assert "ASME III NB-3221.1" in r.citations
    assert "ASME III NB-3221.3" in r.citations
    assert "ASME III NB-3222" in r.citations


# ===========================================================================
# ASME III NB-3220 — cumulative fatigue usage with log-log curve interp
# ===========================================================================


def test_design_fatigue_curve_is_monotonic_decreasing():
    """Higher alternating stress S_a must map to fewer allowable cycles N."""
    curve = a3.asme_design_fatigue_curve_carbon_steel()
    # As listed, S_a decreases while N increases.
    s_vals = [s for s, _ in curve]
    n_vals = [n for _, n in curve]
    assert s_vals == sorted(s_vals, reverse=True)
    assert n_vals == sorted(n_vals)


def test_interp_logN_matches_hand_loglog():
    """Log-log interp at S_a=500 between (379,1000) and (689,200)."""
    curve = sorted(a3.asme_design_fatigue_curve_carbon_steel())
    lnN = math.log(1000) + (math.log(500) - math.log(379)) * (
        math.log(200) - math.log(1000)
    ) / (math.log(689) - math.log(379))
    expected = math.exp(lnN)
    assert a3._interp_logN(500.0, curve) == pytest.approx(expected, rel=1e-9)
    # ~474 cycles
    assert a3._interp_logN(500.0, curve) == pytest.approx(474.23, abs=0.5)


def test_interp_logN_clamps_below_endurance_to_max_life():
    """Below the lowest S_a anchor -> highest N (endurance, conservative cap)."""
    curve = sorted(a3.asme_design_fatigue_curve_carbon_steel())
    # lowest S_a anchor is 114 MPa -> 1e6 cycles
    assert a3._interp_logN(50.0, curve) == pytest.approx(1_000_000, abs=1e-6)


def test_interp_logN_clamps_above_top_anchor():
    """Above the highest S_a anchor -> smallest N (10 cycles)."""
    curve = sorted(a3.asme_design_fatigue_curve_carbon_steel())
    assert a3._interp_logN(9999.0, curve) == pytest.approx(10, abs=1e-6)


def test_interp_logN_returns_inf_for_nonpositive_stress():
    curve = sorted(a3.asme_design_fatigue_curve_carbon_steel())
    assert a3._interp_logN(0.0, curve) == float("inf")
    assert a3._interp_logN(-10.0, curve) == float("inf")


def test_fatigue_usage_factor_miner_sum():
    """U = sum n_i / N_i over events (NB-3222 cumulative damage)."""
    curve = a3.asme_design_fatigue_curve_carbon_steel()
    # event A: S_a=500 -> N~474 (loglog) ; 100 cycles
    # event B: S_a=240 -> N=5000 (exact anchor) ; 500 cycles
    n_a = a3._interp_logN(500.0, sorted(curve))
    expected = 100.0 / n_a + 500.0 / 5000.0
    U = a3.fatigue_usage_factor([(500.0, 100), (240.0, 500)], curve)
    assert U == pytest.approx(expected, rel=1e-9)


def test_fatigue_usage_at_exact_anchor_is_exact_ratio():
    """An event sitting exactly on an anchor uses that anchor's N directly."""
    curve = a3.asme_design_fatigue_curve_carbon_steel()
    # S_a = 172 -> N = 20000 exactly ; 2000 cycles -> U = 0.1
    U = a3.fatigue_usage_factor([(172.0, 2000)], curve)
    assert U == pytest.approx(0.1, rel=1e-9)


# ===========================================================================
# ASME III Subsection HBB (Div 5) — creep-fatigue bilinear envelope
# Austenitic SS D-diagram: (0,1) -> (0.3,0.3) -> (1,0)
# ===========================================================================


def test_creep_fatigue_envelope_endpoints():
    """Pure-fatigue and pure-creep endpoints of the bilinear D-diagram."""
    # uf=0 -> allowable creep damage = 1.0
    ok0, m0 = a3.creep_fatigue_NH_T1432(0.0, 0.0)
    assert ok0 is True
    assert m0 == pytest.approx(1.0, abs=1e-9)   # max_creep at uf=0
    # uf=1 -> allowable creep damage = 0.0
    ok1, m1 = a3.creep_fatigue_NH_T1432(1.0, 0.0)
    assert ok1 is True
    assert m1 == pytest.approx(0.0, abs=1e-9)


def test_creep_fatigue_knee_continuous_at_0p3():
    """Both segments meet at the knee (0.3, 0.3)."""
    # At uf=0.3 the allowable creep damage is 0.3 (margin at Dc=0 -> 0.3)
    _, m = a3.creep_fatigue_NH_T1432(0.3, 0.0)
    assert m == pytest.approx(0.3, abs=1e-9)


def test_creep_fatigue_segment1_slope():
    """Segment 1 (uf<=0.3): allowable creep = 1 - (7/3) uf. Check uf=0.15."""
    _, m = a3.creep_fatigue_NH_T1432(0.15, 0.0)
    assert m == pytest.approx(1.0 - (7.0 / 3.0) * 0.15, abs=1e-9)
    assert m == pytest.approx(0.65, abs=1e-9)


def test_creep_fatigue_segment2_slope():
    """Segment 2 (uf>0.3): allowable creep = 0.3 (1-uf)/0.7. Check uf=0.65."""
    _, m = a3.creep_fatigue_NH_T1432(0.65, 0.0)
    assert m == pytest.approx(0.3 * (1.0 - 0.65) / 0.7, abs=1e-9)
    assert m == pytest.approx(0.15, abs=1e-9)


def test_creep_fatigue_point_inside_envelope_passes():
    """A point under the envelope passes with positive margin."""
    ok, m = a3.creep_fatigue_NH_T1432(0.2, 0.2)
    # allowable at uf=0.2 = 1 - (7/3)*0.2 = 0.5333 ; Dc=0.2 -> margin 0.3333
    assert ok is True
    assert m == pytest.approx(0.5333333333 - 0.2, abs=1e-6)


def test_creep_fatigue_point_outside_envelope_fails():
    """A point above the envelope fails with negative margin."""
    ok, m = a3.creep_fatigue_NH_T1432(0.5, 0.5)
    # allowable at uf=0.5 = 0.3*(0.5)/0.7 = 0.2143 ; Dc=0.5 -> fail
    assert ok is False
    assert m < 0.0


# ===========================================================================
# API RP 581 — POF(t) via Normal CDF
# ===========================================================================


def test_pof_zero_at_nonpositive_time():
    st = rbi.DamageState("thinning", 5.0, 0.5, 0.1, 12.0)
    assert rbi.pof_at_year(st, 0.0) == 0.0
    assert rbi.pof_at_year(st, -3.0) == 0.0


def test_pof_matches_normal_cdf_formula():
    """POF(t) = Phi((m0 + rate*t - crit)/(sigma*t))."""
    st = rbi.DamageState("thinning", 5.0, 0.5, 0.1, 12.0)
    t = 10.0
    mu = 5.0 + 0.5 * t
    sigma = 0.1 * t
    z = (mu - 12.0) / sigma  # = -2.0
    assert rbi.pof_at_year(st, t) == pytest.approx(_phi(z), rel=1e-9)
    assert rbi.pof_at_year(st, t) == pytest.approx(0.0227501, abs=1e-6)


def test_pof_is_half_when_mean_equals_critical():
    """When mean cumulative damage reaches the threshold, POF = 0.5."""
    st = rbi.DamageState("thinning", 5.0, 0.5, 0.1, 12.0)
    # mean reaches 12 at t = (12-5)/0.5 = 14 y
    assert rbi.pof_at_year(st, 14.0) == pytest.approx(0.5, abs=1e-9)


def test_pof_monotonic_increasing_in_time():
    """POF must rise with exposure time for a corroding component."""
    st = rbi.DamageState("thinning", 5.0, 0.5, 0.1, 12.0)
    ts = [1, 5, 10, 14, 18, 25]
    pofs = [rbi.pof_at_year(st, t) for t in ts]
    assert all(b >= a for a, b in zip(pofs, pofs[1:]))
    assert pofs[0] < pofs[-1]


def test_expected_risk_cost_is_pof_times_consequence():
    st = rbi.DamageState("thinning", 5.0, 0.5, 0.1, 12.0)
    c = 1_000_000.0
    assert rbi.expected_risk_cost(st, 10.0, c) == pytest.approx(
        rbi.pof_at_year(st, 10.0) * c, rel=1e-12
    )


# ===========================================================================
# API RP 581 — cost-optimal inspection selection
# total = inspection$ + (1 - POD) * POF * consequence
# ===========================================================================


def test_select_plan_matches_bruteforce_minimum():
    st = rbi.DamageState("thinning", 8.0, 0.6, 0.15, 12.0)
    cands = rbi.default_inspection_catalogue()
    intervals = (1.0, 2.0, 3.0, 5.0, 7.0, 10.0)
    consequence = 50_000_000.0
    plan = rbi.select_inspection_plan(
        st, cands, consequence_usd=consequence,
        interval_candidates_years=intervals,
    )
    best = None
    for t in intervals:
        for opt in cands:
            risk = rbi.expected_risk_cost(st, t, consequence)
            tot = opt.cost_usd + (1.0 - opt.pod_at_critical) * risk
            if best is None or tot < best[0]:
                best = (tot, t, opt.method, (1.0 - opt.pod_at_critical) * risk)
    assert plan.expected_total_cost_usd == pytest.approx(best[0], rel=1e-9)
    assert plan.when_years == best[1]
    assert plan.chosen_method == best[2]
    # expected_risk_usd field is the *residual* (post-inspection) risk.
    assert plan.expected_risk_usd == pytest.approx(best[3], rel=1e-9)


def test_select_plan_total_cost_decomposition():
    """Returned total == inspection_cost + residual risk (self-consistent)."""
    st = rbi.DamageState("thinning", 8.0, 0.6, 0.15, 12.0)
    cands = rbi.default_inspection_catalogue()
    plan = rbi.select_inspection_plan(
        st, cands, consequence_usd=20_000_000.0,
    )
    assert plan.expected_total_cost_usd == pytest.approx(
        plan.inspection_cost_usd + plan.expected_risk_usd, rel=1e-9
    )


def test_select_plan_higher_pod_wins_when_risk_dominates():
    """When risk dwarfs inspection cost at every interval, a high-POD method
    must beat plain VT.

    We restrict the interval set to ages where POF is already appreciable so
    the residual-risk term governs the optimum (this isolates the POD effect
    from the trivial 'inspect at t=1 when POF~=0' corner)."""
    st = rbi.DamageState("thinning", 11.0, 0.6, 0.2, 12.0)
    cands = rbi.default_inspection_catalogue()
    plan = rbi.select_inspection_plan(
        st, cands, consequence_usd=500_000_000.0,
        interval_candidates_years=(3.0, 5.0, 7.0, 10.0),
    )
    chosen = next(c for c in cands if c.method == plan.chosen_method)
    # The cheapest, lowest-POD option (VT, 0.20) must NOT win here.
    assert chosen.pod_at_critical >= 0.85
    assert plan.chosen_method != "VT"


def test_select_plan_low_pod_note_emitted():
    """A chosen method with POD < 0.7 must raise an advisory note."""
    # Cheap option with low POD wins when consequence is tiny.
    st = rbi.DamageState("thinning", 8.0, 0.6, 0.15, 12.0)
    cands = [rbi.InspectionOption("VT", 500.0, 0.20)]
    plan = rbi.select_inspection_plan(st, cands, consequence_usd=1_000.0)
    assert plan.chosen_method == "VT"
    assert any("POD" in n for n in plan.notes)


# ===========================================================================
# WPS generator — IIW carbon equivalent
# ===========================================================================


def test_ce_iiw_formula_from_composition():
    """CE_IIW = C + Mn/6 + (Cr+Mo+V)/5 + (Cu+Ni)/15 (note appears as 'CE_IIW=')."""
    comp = {"C": 0.18, "Mn": 1.2, "Cr": 0.3, "Mo": 0.1, "V": 0.0,
            "Cu": 0.2, "Ni": 0.4}
    expected = 0.18 + 1.2 / 6 + (0.3 + 0.1 + 0.0) / 5 + (0.2 + 0.4) / 15
    r = wps.recommend_wps("A516-70", "E7018", 12.0, composition=comp)
    note_ce = float(r.notes[0].split("=")[1].split("→")[0].strip()
                    .replace("→", "").split()[0])
    assert note_ce == pytest.approx(expected, abs=5e-4)


# ===========================================================================
# WPS generator — preheat by CE category + thickness
# ===========================================================================


def test_preheat_low_ce_thin_is_zero():
    r = wps.recommend_wps("A36", "E7018", 10.0,
                          composition={"C": 0.15, "Mn": 0.8})
    # CE = 0.283 -> 'low' ; thickness <20 -> 0 C
    assert r.preheat_C == pytest.approx(0.0, abs=1e-9)


def test_preheat_increases_with_thickness_same_ce():
    """Thicker plate at fixed composition -> higher (or equal) preheat."""
    comp = {"C": 0.20, "Mn": 1.2}  # CE ~ 0.40 -> 'med'
    p_thin = wps.recommend_wps("A516", "E7018", 10.0, composition=comp).preheat_C
    p_mid = wps.recommend_wps("A516", "E7018", 30.0, composition=comp).preheat_C
    p_thick = wps.recommend_wps("A516", "E7018", 80.0, composition=comp).preheat_C
    assert p_thin <= p_mid <= p_thick
    assert p_thick > p_thin


def test_preheat_increases_with_ce_same_thickness():
    """Higher carbon equivalent -> higher (or equal) preheat at fixed t."""
    t = 50.0
    p_low = wps.recommend_wps("A36", "E7018", t,
                              composition={"C": 0.12, "Mn": 0.6}).preheat_C
    p_med = wps.recommend_wps("A516", "E7018", t,
                              composition={"C": 0.20, "Mn": 1.2}).preheat_C
    p_high = wps.recommend_wps("4140", "E11018", t,
                               composition={"C": 0.40, "Mn": 0.9,
                                            "Cr": 1.0, "Mo": 0.2}).preheat_C
    assert p_low <= p_med <= p_high
    assert p_high > p_low


def test_preheat_high_ce_thick_table_value():
    """High CE + >65 mm -> 200 C per the AWS D1.1 Table 3.3 excerpt."""
    r = wps.recommend_wps("4140", "E11018", 80.0,
                          composition={"C": 0.40, "Mn": 0.9, "Cr": 1.0,
                                       "Mo": 0.2})
    # CE well above 0.45 -> 'high'; t>65 -> 200
    assert r.preheat_C == pytest.approx(200.0, abs=1e-9)


# ===========================================================================
# WPS generator — PWHT by P-number + thickness
# ===========================================================================


def test_pwht_p1_below_threshold_not_required():
    r = wps.recommend_wps("A516-70", "E7018", 15.0, p_number=1)
    assert r.pwht_required is False
    assert r.pwht_T_C is None
    assert r.pwht_t_h is None


def test_pwht_p1_above_threshold_temp_and_soak():
    """P-No 1 over 19 mm -> 593 C, soak = 1 h per 25 mm."""
    r = wps.recommend_wps("A516-70", "E7018", 30.0, p_number=1)
    assert r.pwht_required is True
    assert r.pwht_T_C == pytest.approx(593.0, abs=1e-9)
    # 30 mm -> 30/25 = 1.2 h
    assert r.pwht_t_h == pytest.approx(1.2, abs=1e-9)


def test_pwht_soak_floor_one_hour():
    """Thin section above threshold still soaks >= 1 h (max(1, t/25))."""
    # P-No 4 threshold is 13 mm; at 20 mm -> 20/25 = 0.8 -> floored to 1.0 h
    r = wps.recommend_wps("2.25Cr-1Mo", "E9018-B3", 20.0, p_number=4)
    assert r.pwht_required is True
    assert r.pwht_t_h == pytest.approx(1.0, abs=1e-9)


def test_pwht_higher_temp_for_cr_mo_grades():
    """PWHT soak temperature increases with alloying (P1<P3<P4<P5)."""
    t = 40.0
    T1 = wps.recommend_wps("A516", "E7018", t, p_number=1).pwht_T_C
    T3 = wps.recommend_wps("1.25Cr", "E8018-B2", t, p_number=3).pwht_T_C
    T4 = wps.recommend_wps("2.25Cr", "E9018-B3", t, p_number=4).pwht_T_C
    T5 = wps.recommend_wps("Gr91", "E9015-B9", t, p_number=5).pwht_T_C
    assert T1 < T3 < T4 < T5
    assert (T1, T3, T4, T5) == (593, 660, 690, 760)


def test_pwht_austenitic_p8_never_required():
    """P-No 8 austenitic SS: no PWHT even for very thick sections."""
    r = wps.recommend_wps("SS304", "E308", 80.0, p_number=8)
    assert r.pwht_required is False
    assert r.pwht_T_C is None


def test_p8_interpass_capped_for_sensitization():
    """Austenitic SS interpass capped at 175 C to limit sensitization."""
    r = wps.recommend_wps("SS316", "E316", 25.0, p_number=8)
    assert r.interpass_max_C == pytest.approx(175.0, abs=1e-9)
    assert any("sensitization" in n.lower() for n in r.notes)


# ===========================================================================
# WPS generator — heat-input window (process-specific)
# ===========================================================================


@pytest.mark.parametrize(
    "process,lo,hi",
    [
        ("SMAW", 0.8, 2.5),
        ("GMAW", 0.5, 1.8),
        ("GTAW", 0.3, 1.2),
        ("SAW", 2.0, 6.0),
        ("FCAW", 0.8, 3.0),
    ],
)
def test_heat_input_window_by_process(process, lo, hi):
    r = wps.recommend_wps("A516", "E7018", 20.0, process=process)
    assert r.heat_input_kJ_mm_min == pytest.approx(lo, abs=1e-9)
    assert r.heat_input_kJ_mm_max == pytest.approx(hi, abs=1e-9)
    assert r.heat_input_kJ_mm_min < r.heat_input_kJ_mm_max


def test_heat_input_window_unknown_process_default():
    r = wps.recommend_wps("A516", "E7018", 20.0, process="LASER")
    assert (r.heat_input_kJ_mm_min, r.heat_input_kJ_mm_max) == (0.5, 2.5)


# ===========================================================================
# WPS generator — NDE selection + inspection extent
# ===========================================================================


def test_nde_escalates_with_thickness():
    """Thicker plate adds MT then UT+RT and bumps extent to 100%."""
    thin = wps.recommend_wps("A516", "E7018", 5.0, p_number=1)
    mid = wps.recommend_wps("A516", "E7018", 10.0, p_number=1)
    thick = wps.recommend_wps("A516", "E7018", 25.0, p_number=1)
    assert thin.nde_methods == ["VT"]
    assert "MT" in mid.nde_methods and "UT" not in mid.nde_methods
    assert {"VT", "MT", "UT", "RT"}.issubset(set(thick.nde_methods))
    assert mid.inspection_extent_pct == pytest.approx(20.0)
    assert thick.inspection_extent_pct == pytest.approx(100.0)


def test_nde_extent_full_for_high_pnumber():
    """Cr-Mo (P>=4) gets 100% extent even for thinner sections."""
    r = wps.recommend_wps("2.25Cr", "E9018-B3", 12.0, p_number=4)
    assert r.inspection_extent_pct == pytest.approx(100.0)


# ===========================================================================
# WPS generator — interpass lower bound
# ===========================================================================


def test_interpass_floor_175_when_preheat_low():
    """Interpass = min(315, max(preheat+50, 175)) -> >=175 C."""
    r = wps.recommend_wps("A36", "E7018", 10.0,
                          composition={"C": 0.15, "Mn": 0.8})
    # preheat 0 -> max(50,175)=175
    assert r.interpass_max_C == pytest.approx(175.0, abs=1e-9)


def test_interpass_cap_315():
    """Very high preheat is capped at 315 C interpass."""
    # high CE + thick -> preheat 200 -> 200+50=250 (below cap) ; push higher:
    # there is no >200 preheat in the table, so verify the cap arithmetic via
    # the documented formula at preheat=200 -> 250.
    r = wps.recommend_wps("4140", "E11018", 80.0,
                          composition={"C": 0.40, "Mn": 0.9, "Cr": 1.0,
                                       "Mo": 0.2})
    assert r.preheat_C == pytest.approx(200.0)
    assert r.interpass_max_C == pytest.approx(min(315, max(250, 175)), abs=1e-9)
    assert r.interpass_max_C <= 315.0
