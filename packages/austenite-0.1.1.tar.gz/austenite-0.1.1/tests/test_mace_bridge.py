"""Tests for ``austenite.ml.mace_bridge`` — MACE-MP-0 foundation MLIP bridge.

Tests are split between:

1. Pure-Python tests that DO NOT require ``mace-torch`` to be installed
   (cover data classes, error messages, helper functions).
2. Live MACE-MP-0 tests that run only when ``mace-torch`` AND ``ase`` are
   present (gated by ``pytest.importorskip``). These check that an Fe BCC
   endmember evaluates to a physically-plausible Gibbs energy.
"""

from __future__ import annotations

import os
import sys
from unittest import mock

import pytest

from austenite.ml.mace_bridge import (
    MaceImportError,
    MacePriorResult,
    _debye_entropy_J_per_mol_K,
    mace_mp_endmember_G,
    mace_mp_prior,
)


# ---------------------------------------------------------------------------
# Pure-Python tests
# ---------------------------------------------------------------------------


def test_mace_prior_result_to_dict_round_trip() -> None:
    res = MacePriorResult(
        elements=["FE", "CR"],
        T_range=(298.15, 1800.0),
        prior_mean=[-8000.0, -7500.0],
        prior_cov=[5000.0 ** 2, 5000.0 ** 2],
        provenance="test fixture",
    )
    d = res.to_dict()
    assert d["elements"] == ["FE", "CR"]
    assert d["T_range"] == [298.15, 1800.0]
    assert d["prior_mean"] == [-8000.0, -7500.0]
    assert d["prior_cov"] == [25_000_000.0, 25_000_000.0]
    assert d["provenance"] == "test fixture"


def test_debye_entropy_increases_with_T() -> None:
    s_low = _debye_entropy_J_per_mol_K(500.0, 470.0)
    s_high = _debye_entropy_J_per_mol_K(1500.0, 470.0)
    assert s_high > s_low
    # At T well above theta_D the entropy is positive and in tens of J/mol/K
    assert 10.0 < s_high < 100.0


def test_debye_entropy_zero_T_returns_zero() -> None:
    assert _debye_entropy_J_per_mol_K(0.0, 470.0) == 0.0


def test_debye_entropy_zero_theta_returns_zero() -> None:
    assert _debye_entropy_J_per_mol_K(1000.0, 0.0) == 0.0


def test_endmember_G_raises_when_mace_missing() -> None:
    # Hide the mace module to force ImportError.
    with mock.patch.dict(sys.modules, {"mace.calculators": None, "mace": None}):
        with pytest.raises(MaceImportError) as excinfo:
            mace_mp_endmember_G(object(), T_K=1000.0)
        msg = str(excinfo.value)
        assert "mace-torch" in msg or "MACE" in msg
        assert "austenite[mlip]" in msg


def test_prior_empty_elements_raises() -> None:
    with pytest.raises(ValueError, match="elements"):
        mace_mp_prior(elements=[])


def test_prior_uses_default_lattice_a_for_known_element() -> None:
    """When MACE isn't installed, prior_mean construction still raises
    informatively rather than silently returning bogus data."""

    with mock.patch.dict(sys.modules, {"mace": None, "mace.calculators": None}):
        with pytest.raises(MaceImportError):
            mace_mp_prior(elements=["FE", "CR"], T_range=(298.15, 1800.0))


# ---------------------------------------------------------------------------
# Live tests — only when ASE + mace-torch are available.
# ---------------------------------------------------------------------------


@pytest.mark.skipif(
    "mace" not in sys.modules and not _has("mace") if False else True,
    reason="placeholder — overridden by importorskip below",
)
def _skip_marker() -> None:
    pass


def _has(name: str) -> bool:
    try:
        __import__(name)
        return True
    except ImportError:
        return False


@pytest.mark.skipif(
    not (_has("ase") and _has("mace")),
    reason="MACE-MP-0 bridge requires mace-torch + ase (install austenite[mlip])",
)
def test_endmember_G_fe_bcc_returns_finite_negative_J_per_mol() -> None:  # pragma: no cover - live
    from ase.build import bulk  # type: ignore

    fe = bulk("Fe", "bcc", a=2.87)
    G = mace_mp_endmember_G(fe, T_K=1000.0)
    # Expect ~-8 kJ/mol-of-atoms (per-atom DFT formation energy × N_A,
    # minus T·S_vib at 1000 K). The exact value depends on MACE weights,
    # but it should be in the (-30, +30) kJ/mol band.
    assert -30_000.0 < G < 30_000.0
