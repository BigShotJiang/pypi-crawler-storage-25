"""Tests for au.cross_database — multi-database CALPHAD comparison."""

from __future__ import annotations

import pytest

import austenite as au
from austenite.cross_database import (
    AVAILABLE_DATABASES,
    ComparisonReport,
    DatabaseRow,
    compare_equilibrium,
    list_databases,
)


# ---------------------------------------------------------------------------
# list_databases
# ---------------------------------------------------------------------------


def test_list_databases_returns_four_with_metadata():
    """The Phase-0 ship includes austenite-native + 3 synthetic proxies."""

    dbs = list_databases()
    assert len(dbs) == 4
    ids = {d["id"] for d in dbs}
    assert "austenite-sgte-2024" in ids
    assert "synthetic-pandat-2024" in ids
    assert "synthetic-tcfe-2024" in ids
    # Each row carries label, kind, citation.
    for d in dbs:
        assert "label" in d and "kind" in d and "citation" in d


# ---------------------------------------------------------------------------
# compare_equilibrium happy path
# ---------------------------------------------------------------------------


def test_compare_equilibrium_fe_cr_returns_one_row_per_database():
    report = compare_equilibrium(
        composition={"Fe": 0.74, "Cr": 0.26},
        T_K=1000,
    )
    assert isinstance(report, ComparisonReport)
    assert len(report.rows) == 4
    for r in report.rows:
        assert isinstance(r, DatabaseRow)
        # phase fractions should sum to ~1
        s = sum(r.phase_fractions.values())
        assert 0.99 <= s <= 1.01


def test_compare_equilibrium_synthetic_proxies_show_small_disagreement():
    """The 3 synthetic proxies perturb 1.5-3% — should agree within 5%."""

    report = compare_equilibrium(
        composition={"Fe": 0.74, "Cr": 0.26},
        T_K=1000,
    )
    # Most phases agree (≥80%).
    assert report.agreement_pct >= 0.6


def test_compare_equilibrium_subset_of_databases():
    """Specifying a subset of databases returns only those rows."""

    report = compare_equilibrium(
        composition={"Fe": 0.95, "C": 0.005},
        T_K=900,
        databases=["austenite-sgte-2024", "synthetic-tcfe-2024"],
    )
    assert len(report.rows) == 2
    db_ids = {r.database for r in report.rows}
    assert db_ids == {"austenite-sgte-2024", "synthetic-tcfe-2024"}


def test_compare_equilibrium_unknown_database_raises_notimplemented():
    with pytest.raises(NotImplementedError, match="not available"):
        compare_equilibrium(
            composition={"Fe": 0.95},
            T_K=800,
            databases=["nonexistent-db-xyz"],
        )


def test_compare_equilibrium_empty_databases_raises():
    with pytest.raises(ValueError):
        compare_equilibrium(
            composition={"Fe": 0.95},
            T_K=800,
            databases=[],
        )


# ---------------------------------------------------------------------------
# ComparisonReport.to_dataframe
# ---------------------------------------------------------------------------


def test_comparison_report_to_dataframe_has_one_row_per_database():
    pd = pytest.importorskip("pandas")
    report = compare_equilibrium(
        composition={"Fe": 0.74, "Cr": 0.26},
        T_K=1000,
    )
    df = report.to_dataframe()
    assert isinstance(df, pd.DataFrame)
    assert len(df) == 4
    assert "database" in df.columns
    assert "G_kJ_mol" in df.columns


# ---------------------------------------------------------------------------
# Determinism
# ---------------------------------------------------------------------------


def test_compare_equilibrium_is_deterministic():
    """Two identical calls must return identical numbers (hash-seeded)."""

    a = compare_equilibrium(
        composition={"Fe": 0.74, "Cr": 0.26}, T_K=1000)
    b = compare_equilibrium(
        composition={"Fe": 0.74, "Cr": 0.26}, T_K=1000)
    for ra, rb in zip(a.rows, b.rows):
        assert ra.database == rb.database
        for p in ra.phase_fractions:
            assert abs(ra.phase_fractions[p] - rb.phase_fractions[p]) < 1e-12


# ---------------------------------------------------------------------------
# Lazy load via au.* namespace
# ---------------------------------------------------------------------------


def test_lazy_namespace():
    assert hasattr(au, "cross_database")
    assert callable(au.cross_database.compare_equilibrium)
