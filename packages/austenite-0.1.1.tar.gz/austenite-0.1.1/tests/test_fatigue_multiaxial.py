"""Tests for au.fatigue.multiaxial — critical-plane + mean-stress methods."""
from __future__ import annotations

import math
import pytest

from austenite.fatigue.multiaxial import (
    CriticalPlaneResult,
    LoadBlock,
    brown_miller_critical_plane,
    crossland_criterion,
    dang_van_criterion,
    findley_critical_plane,
    mean_stress_correction,
    miner_damage,
    wang_brown_path_factor,
)


# ---------------------------------------------------------------------------
# Mean-stress corrections
# ---------------------------------------------------------------------------


def test_mean_stress_goodman_zero_mean_equals_amplitude():
    sa = mean_stress_correction(120, 0, method="goodman", sigma_uts_MPa=800)
    assert math.isclose(sa, 120.0, rel_tol=1e-6)


def test_mean_stress_goodman_positive_mean_increases_equivalent():
    sa_no_mean = mean_stress_correction(120, 0, method="goodman", sigma_uts_MPa=800)
    sa_with_mean = mean_stress_correction(120, 200, method="goodman", sigma_uts_MPa=800)
    assert sa_with_mean > sa_no_mean
    # Goodman: σ_a / (1 − 200/800) = 120 / 0.75 = 160
    assert math.isclose(sa_with_mean, 160.0, rel_tol=1e-3)


def test_mean_stress_compressive_mean_no_penalty():
    sa = mean_stress_correction(120, -100, method="goodman", sigma_uts_MPa=800)
    assert math.isclose(sa, 120.0, rel_tol=1e-6)


def test_mean_stress_soderberg_more_conservative_than_goodman():
    sa_god = mean_stress_correction(120, 200, method="goodman", sigma_uts_MPa=800)
    sa_sod = mean_stress_correction(120, 200, method="soderberg", sigma_uts_MPa=800, sigma_y_MPa=500)
    assert sa_sod > sa_god


def test_mean_stress_gerber_less_conservative_than_goodman():
    sa_god = mean_stress_correction(120, 200, method="goodman", sigma_uts_MPa=800)
    sa_gerber = mean_stress_correction(120, 200, method="gerber", sigma_uts_MPa=800)
    assert sa_gerber < sa_god


def test_mean_stress_swt_zero_mean_equals_amplitude():
    sa = mean_stress_correction(120, 0, method="swt")
    assert math.isclose(sa, 120.0, rel_tol=1e-3)


def test_mean_stress_walker_with_explicit_gamma():
    sa = mean_stress_correction(120, 80, method="walker", walker_gamma=0.5)
    # Walker: σ_eq = σ_max^(1-γ) · σ_a^γ = 200^0.5 · 120^0.5 = sqrt(200·120) ≈ 154.9
    assert math.isclose(sa, math.sqrt(200 * 120), rel_tol=1e-3)


def test_mean_stress_nan_input_returns_nan():
    assert math.isnan(mean_stress_correction(float("nan"), 0, method="goodman", sigma_uts_MPa=800))


# ---------------------------------------------------------------------------
# Critical-plane: Findley
# ---------------------------------------------------------------------------


def test_findley_returns_critical_plane_result():
    r = findley_critical_plane(
        sigma_xx_amplitude_MPa=120, sigma_xx_mean_MPa=80,
        tau_xy_amplitude_MPa=60, findley_k=0.3,
    )
    assert isinstance(r, CriticalPlaneResult)
    assert r.method == "findley"
    assert 0 <= r.theta_deg <= 180
    assert math.isfinite(r.damage_parameter)
    assert r.damage_parameter > 0


def test_findley_pure_uniaxial_finds_45_deg_plane():
    """For pure σ_xx loading, max shear is on a 45° plane."""
    r = findley_critical_plane(
        sigma_xx_amplitude_MPa=200, sigma_xx_mean_MPa=0,
        tau_xy_amplitude_MPa=0, findley_k=0.0,
    )
    # k=0 means only shear matters; max shear at 45°
    # Allow ±10° because of grid spacing (1°)
    assert 35 <= r.theta_deg <= 55


def test_findley_pure_shear_finds_zero_deg_plane():
    """For pure τ_xy loading, max shear is on the reference plane (0°)."""
    r = findley_critical_plane(
        sigma_xx_amplitude_MPa=0, sigma_xx_mean_MPa=0,
        tau_xy_amplitude_MPa=100, findley_k=0.0,
    )
    # Pure shear: τ_a is maximised at 0° (and 90°). k=0 means damage = τ_a
    # so the result could be 0° or 90°. Allow both
    assert r.theta_deg <= 5 or r.theta_deg >= 85


# ---------------------------------------------------------------------------
# Critical-plane: Brown-Miller
# ---------------------------------------------------------------------------


def test_brown_miller_returns_valid_result():
    r = brown_miller_critical_plane(
        epsilon_xx_amplitude=0.001, gamma_xy_amplitude=0.0005,
        nu_e=0.3, s=1.65,
    )
    assert r.method == "brown-miller"
    assert math.isfinite(r.damage_parameter)


# ---------------------------------------------------------------------------
# Non-proportionality factor
# ---------------------------------------------------------------------------


def test_wang_brown_proportional_returns_1():
    # In-phase sine waves with same amplitude
    n = 36
    sigma = [100 * math.sin(2 * math.pi * i / n) for i in range(n)]
    tau = [50 * math.sin(2 * math.pi * i / n) for i in range(n)]
    f_np = wang_brown_path_factor(sigma, tau)
    # Proportional should give F_NP close to 1.0
    assert 0.95 <= f_np <= 1.05


def test_wang_brown_out_of_phase_amplifies():
    n = 36
    sigma = [100 * math.sin(2 * math.pi * i / n) for i in range(n)]
    tau = [50 * math.cos(2 * math.pi * i / n) for i in range(n)]  # 90° out
    f_np = wang_brown_path_factor(sigma, tau)
    assert f_np > 1.1  # significant non-proportionality penalty


# ---------------------------------------------------------------------------
# Stress-invariant: Crossland
# ---------------------------------------------------------------------------


def test_crossland_returns_alpha_and_safety_factor():
    r = crossland_criterion(J2_a_MPa=100, sigma_h_max_MPa=50, sigma_endurance_MPa=250)
    assert "alpha" in r and "sigma_eq_MPa" in r and "safety_factor" in r
    assert math.isfinite(r["alpha"])
    assert r["passed"] in (True, False)


def test_crossland_pure_amplitude_no_hydrostatic_passes_at_safe_amplitude():
    r = crossland_criterion(J2_a_MPa=100, sigma_h_max_MPa=0, sigma_endurance_MPa=250)
    assert r["passed"]


# ---------------------------------------------------------------------------
# Stress-invariant: Dang-Van
# ---------------------------------------------------------------------------


def test_dang_van_returns_max_param():
    tau = [50, 80, 100, 70, 30]
    sh = [20, 30, 40, 25, 10]
    r = dang_van_criterion(tau, sh, sigma_endurance_MPa=250)
    assert "max_dv_param" in r and "alpha_DV" in r and "safety_factor" in r


def test_dang_van_empty_series_returns_error():
    r = dang_van_criterion([], [], sigma_endurance_MPa=250)
    assert "error" in r


# ---------------------------------------------------------------------------
# Palmgren-Miner damage
# ---------------------------------------------------------------------------


def test_miner_damage_single_block_at_safe_amplitude_passes():
    blocks = [LoadBlock(sigma_amplitude_MPa=100, sigma_mean_MPa=0, n_cycles=1000)]
    r = miner_damage(
        blocks,
        basquin_sigma_f_prime_MPa=1100, basquin_b=-0.085,
        sigma_uts_MPa=800,
    )
    assert "damage" in r and "passed" in r
    assert r["damage"] >= 0


def test_miner_damage_accumulates_across_blocks():
    blocks = [
        LoadBlock(sigma_amplitude_MPa=150, sigma_mean_MPa=50, n_cycles=10_000),
        LoadBlock(sigma_amplitude_MPa=200, sigma_mean_MPa=100, n_cycles=5_000),
    ]
    r = miner_damage(
        blocks,
        basquin_sigma_f_prime_MPa=1100, basquin_b=-0.085,
        sigma_uts_MPa=800, sigma_y_MPa=500,
    )
    assert r["damage"] > 0
    assert len(r["blocks"]) == 2
    # Both blocks contribute positively
    assert r["blocks"][0]["damage"] > 0
    assert r["blocks"][1]["damage"] > 0


def test_miner_damage_marks_overall_failure_when_d_exceeds_1():
    blocks = [LoadBlock(sigma_amplitude_MPa=400, sigma_mean_MPa=200, n_cycles=10_000_000)]
    r = miner_damage(
        blocks,
        basquin_sigma_f_prime_MPa=1100, basquin_b=-0.085,
        sigma_uts_MPa=800,
    )
    # With high amplitude + lots of cycles, D should exceed 1
    assert r["damage"] >= 0  # at least defined; could be inf
