"""Tests for au.explain — natural-language calculation walkthroughs."""

from __future__ import annotations

import pytest

import austenite as au
from austenite.explain import (
    Step,
    Walkthrough,
    am_qualification,
    bayesian,
    design_path,
    ffs,
    mtc,
)


# ---------------------------------------------------------------------------
# design_path walkthrough
# ---------------------------------------------------------------------------


def test_design_path_walkthrough_has_4_steps_and_cites_pavlina():
    """The composition→σ_y chain must have the 4 named steps + Pavlina cite."""

    fake_result = type(
        "FakeResult", (), {
            "properties": type("P", (), {"sigma_y_MPa": 1535, "HV30": 565})(),
            "inputs": {"alloy": "AISI 4140", "cooling_rate": 10.0, "T0_C": 850.0},
        }
    )()
    wt = design_path(fake_result)
    assert isinstance(wt, Walkthrough)
    assert len(wt.steps) == 4
    md = wt.markdown()
    # Step titles should be present.
    assert "CALPHAD equilibrium" in md
    assert "TTT/CCT" in md
    assert "HV30" in md
    assert "Pavlina" in md
    assert "Pavlina" in " ".join(wt.citations)


def test_design_path_walkthrough_markdown_includes_citations_section():
    fake_result = {
        "properties": {"sigma_y_MPa": 1535, "HV30": 565},
        "inputs": {"alloy": "AISI 4140", "cooling_rate": 10.0},
    }
    wt = design_path(fake_result)
    md = wt.markdown()
    assert "## Citations" in md
    # Each step should have a Result line for numeric output.
    assert md.count("**Result:**") >= 2


def test_design_path_walkthrough_html_renders_without_braces():
    """HTML output should not contain raw f-string placeholders or unsafe HTML."""

    fake_result = {"properties": {"sigma_y_MPa": 1535}}
    wt = design_path(fake_result)
    html = wt.html()
    assert "<h1>" in html
    assert "<h2>" in html
    assert "{" not in html
    assert "}" not in html


# ---------------------------------------------------------------------------
# am_qualification walkthrough
# ---------------------------------------------------------------------------


def test_am_qualification_walkthrough_includes_VED_and_regime():
    """AM walkthrough must compute VED + name the regime."""

    fake = {
        "inputs": {"alloy": "IN718", "spec": "ASTM-F3055"},
        "laser_power_W": 250,
        "scan_speed_mm_s": 960,
        "hatch_um": 110,
        "layer_um": 30,
        "properties": {"sigma_uts_MPa": 1300, "porosity_pct": 0.08},
    }
    wt = am_qualification(fake)
    md = wt.markdown()
    assert "VED" in md or "energy density" in md.lower()
    assert any(r in md.lower() for r in ("keyhole", "conduction", "lack-of-fusion"))
    # Should reference Sames + Promoppatum.
    cits_blob = " ".join(wt.citations)
    assert "Sames" in cits_blob


def test_am_qualification_walkthrough_includes_F3055_verdict_step():
    """A spec_id of F3055 → spec-comparison step must appear."""

    fake = {
        "inputs": {"alloy": "IN718", "spec": "ASTM-F3055"},
        "laser_power_W": 250,
        "scan_speed_mm_s": 960,
        "hatch_um": 110,
        "layer_um": 30,
        "properties": {"sigma_uts_MPa": 1300, "porosity_pct": 0.08},
    }
    wt = am_qualification(fake)
    # A verdict step must be in the steps array.
    titles = [s.title for s in wt.steps]
    assert any("F3055" in t for t in titles)


# ---------------------------------------------------------------------------
# mtc walkthrough
# ---------------------------------------------------------------------------


def test_mtc_walkthrough_cites_en_10204():
    """MTC walkthrough must mention EN 10204 (the spec it's parsing)."""

    fake_report = {
        "grade": "SA-516-70",
        "composition": {"C": 0.2, "Mn": 0.85, "Si": 0.3},
        "spec": "ASME II-D SA-516-70",
        "passed": True,
    }
    wt = mtc(fake_report)
    md = wt.markdown()
    assert "EN 10204" in md or "EN 10204" in " ".join(wt.citations)


# ---------------------------------------------------------------------------
# bayesian walkthrough
# ---------------------------------------------------------------------------


def test_bayesian_walkthrough_cites_dram_and_brooks_gelman():
    """The Bayesian walkthrough must cite DRAM (Haario) + R-hat (Brooks-Gelman)."""

    fake_result = {
        "dataset": "hammar-1979-sigma",
        "chains": 4,
        "samples": 10000,
        "r_hat": {"G0": 1.02},
        "hpd_95": {"G0": (0.1, 0.5)},
        "posterior_predictive": {"calibration_score": 0.94},
    }
    wt = bayesian(fake_result)
    cits = " ".join(wt.citations)
    assert "Haario" in cits  # DRAM citation
    assert "Brooks" in cits or "Gelman" in cits  # R-hat citation


# ---------------------------------------------------------------------------
# ffs walkthrough
# ---------------------------------------------------------------------------


def test_ffs_walkthrough_includes_t_min_and_MAWP_and_remaining_life():
    """An FFS walkthrough must show t_min + MAWP + remaining life."""

    fake = {
        "geometry": {"OD_mm": 500, "wall_mm": 12.5},
        "material": "SA-516-70",
        "T_C": 400.0,
        "P_MPa": 2.5,
        "edition": "API 579-1 2021-12",
        "t_min_mm": 8.7,
        "MAWP_MPa": 2.85,
        "remaining_life_years": 12.3,
        "level": "Level-2 acceptable",
    }
    wt = ffs(fake)
    md = wt.markdown()
    assert "t_min" in md.lower() or "8.7" in md
    assert "MAWP" in md
    assert "remaining life" in md.lower() or "12.3" in md


# ---------------------------------------------------------------------------
# Step / Walkthrough basics
# ---------------------------------------------------------------------------


def test_step_dataclass_is_frozen():
    s = Step(title="foo", body="bar", value=1.0, unit="MPa", citations=["X"])
    with pytest.raises((AttributeError, Exception)):
        s.title = "baz"  # type: ignore[misc]


def test_walkthrough_to_dict_is_json_safe():
    """to_dict() must be plain JSON-serializable (no dataclass / numpy)."""

    import json
    wt = Walkthrough(
        title="t",
        steps=[Step(title="s1", body="b", value=1.0, unit="MPa")],
        citations=["c"],
    )
    blob = json.dumps(wt.to_dict())
    assert "s1" in blob


# ---------------------------------------------------------------------------
# Lazy load via au.* namespace
# ---------------------------------------------------------------------------


def test_lazy_namespace():
    assert hasattr(au, "explain")
    assert callable(au.explain.design_path)
