"""Tests for compliance.diff_edition / recheck_edition (moat 5).

Validates:
  * Every shipped JSON corpus loads and passes schema validation.
  * diff_edition returns the expected set of changes for 5 spec/version
    pairs (one per spec).
  * Spec id normalization (aliases) works.
  * recheck_edition correctly classifies PASS / FAIL / changed_margin
    transitions on a synthetic batch.
"""

from __future__ import annotations

import json
from importlib import resources
from pathlib import Path

import pytest

import austenite as au
from austenite.compliance_editions import (
    DiffReport,
    EditionChange,
    RecheckDetail,
    RecheckReport,
    _SPEC_FILES,
    _validate_corpus_schema,
)


# ---------------------------------------------------------------------------
# 1. Corpus shape: every bundled JSON file loads and validates
# ---------------------------------------------------------------------------


def test_all_bundled_corpora_load_and_validate() -> None:
    pkg = resources.files("austenite._editions")
    for canonical, filename in _SPEC_FILES.items():
        text = (pkg / filename).read_text(encoding="utf-8")
        data = json.loads(text)
        _validate_corpus_schema(data, source=filename)
        # spec field must match the canonical id
        assert data["spec"] == canonical, (
            f"{filename}: data['spec']={data['spec']!r} doesn't match "
            f"canonical id {canonical!r}"
        )
        # At least one edition shipped
        assert len(data["editions"]) >= 1


def test_list_specs_returns_five_canonical_ids() -> None:
    specs = au.compliance.list_specs()
    assert "API 579-1" in specs
    assert "API 581" in specs
    assert "ASME II-D" in specs
    assert "NACE MR0175" in specs
    assert "ASTM A29" in specs
    assert len(specs) >= 5


def test_list_editions_returns_published_metadata() -> None:
    eds = au.compliance.list_editions("API 579-1")
    assert isinstance(eds, list)
    assert len(eds) >= 3
    # Sorted by published date — first is the earliest
    assert eds[0]["id"] == "2021-12"
    assert eds[-1]["id"] == "2024-09"
    # Each entry carries id/published/label
    for ed in eds:
        assert {"id", "published", "label"} <= set(ed.keys())


# ---------------------------------------------------------------------------
# 2. Spec id normalization — common aliases
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "alias,canonical",
    [
        ("API 579-1", "API 579-1"),
        ("API 579", "API 579-1"),
        ("api 579", "API 579-1"),
        ("api-579-ffs-1", "API 579-1"),
        ("ASME FFS-1", "API 579-1"),
        ("API 581", "API 581"),
        ("ASME II-D", "ASME II-D"),
        ("ASME 2-D", "ASME II-D"),
        ("BPVC II-D", "ASME II-D"),
        ("NACE MR0175", "NACE MR0175"),
        ("ISO 15156", "NACE MR0175"),
        ("ASTM A29", "ASTM A29"),
        ("A29", "ASTM A29"),
        ("astm-a29/a29m", "ASTM A29"),
    ],
)
def test_diff_edition_accepts_spec_aliases(alias: str, canonical: str) -> None:
    eds = au.compliance.list_editions(canonical)
    # Take first 2 editions of the canonical spec, then verify the alias
    # resolves to the same spec for diff_edition.
    diff = au.compliance.diff_edition(alias, eds[0]["id"], eds[-1]["id"])
    assert diff.spec == canonical


def test_diff_edition_unknown_spec_raises() -> None:
    with pytest.raises(au.ValidationError):
        au.compliance.diff_edition("API 9999", "v1", "v2")


def test_diff_edition_unknown_edition_raises() -> None:
    with pytest.raises(au.ValidationError):
        au.compliance.diff_edition("API 579-1", "1999-01", "2024-09")


# ---------------------------------------------------------------------------
# 3. The five hand-curated diff cases — one per spec
# ---------------------------------------------------------------------------


def test_diff_edition_api_579_1_2021_to_2024() -> None:
    diff = au.compliance.diff_edition("API 579-1", "2021-12", "2024-09")
    assert isinstance(diff, DiffReport)
    assert diff.spec == "API 579-1"
    assert diff.publisher == "American Petroleum Institute"
    # Corpus expanded — assert presence-based rather than fixed counts.
    # 2022-06 + 2023-03 + 2024-09 collectively contribute the diff set.
    assert len(diff) >= 7
    # Newman-Raju formula change is in the diff
    assert any("Newman-Raju" in c.summary for c in diff.changes)
    # Sections sorted within edition
    kinds = {c.kind for c in diff.changes}
    assert "formula" in kinds
    assert "parameter" in kinds
    assert "scope" in kinds


def test_diff_edition_api_581_2008_to_2020() -> None:
    diff = au.compliance.diff_edition("API 581", "2008", "2020")
    # Corpus expanded with 2016/2020 Addenda detail
    assert len(diff) >= 5
    assert any("Brittle Fracture" in c.summary for c in diff.changes)


def test_diff_edition_asme_ii_d_2021_to_2025() -> None:
    diff = au.compliance.diff_edition("ASME II-D", "2021", "2025")
    # Corpus expanded with full 2023+2025 Table 1A/1B/2A deltas
    assert len(diff) >= 5
    # Alloy 740H scope expansion present
    assert any("740H" in c.summary for c in diff.changes)


def test_diff_edition_nace_mr0175_2009_to_2023() -> None:
    diff = au.compliance.diff_edition("NACE MR0175", "2009", "2023")
    # 2015 + 2021 + 2023 changes
    assert len(diff) >= 6
    # Hardness ceiling change present
    assert any("42 HRC" in c.summary or "0.45" in c.summary for c in diff.changes)


def test_diff_edition_astm_a29_2020a_to_2024() -> None:
    diff = au.compliance.diff_edition("ASTM A29", "2020a", "2024")
    # Corpus expanded with 2022/2024 detail
    assert len(diff) >= 5
    # Restricted-residual variant present
    assert any("restricted-residual" in c.summary.lower() or "4140R" in c.summary
               for c in diff.changes)


# ---------------------------------------------------------------------------
# 4. Direction agnostic — swapping from/to still gives the forward diff
# ---------------------------------------------------------------------------


def test_diff_edition_swapped_ids_still_works() -> None:
    forward = au.compliance.diff_edition("API 579-1", "2021-12", "2024-09")
    reverse = au.compliance.diff_edition("API 579-1", "2024-09", "2021-12")
    assert len(forward) == len(reverse)
    # Same content
    forward_summaries = {c.summary for c in forward.changes}
    reverse_summaries = {c.summary for c in reverse.changes}
    assert forward_summaries == reverse_summaries


# ---------------------------------------------------------------------------
# 5. Kind filter
# ---------------------------------------------------------------------------


def test_diff_edition_kind_filter_formulas_only() -> None:
    diff = au.compliance.diff_edition(
        "API 579-1", "2021-12", "2024-09", kinds=["formula"]
    )
    assert all(c.kind == "formula" for c in diff.changes)
    assert len(diff) >= 1


def test_diff_edition_kind_filter_excludes_others() -> None:
    diff_all = au.compliance.diff_edition("API 579-1", "2021-12", "2024-09")
    diff_formula = au.compliance.diff_edition(
        "API 579-1", "2021-12", "2024-09", kinds=["formula"]
    )
    assert len(diff_formula) < len(diff_all)


# ---------------------------------------------------------------------------
# 6. Legacy v1/v2 keyword path still works
# ---------------------------------------------------------------------------


def test_diff_edition_legacy_v1_v2_keywords_work() -> None:
    diff = au.compliance.diff_edition("API 581", v1="2008", v2="2020")
    assert isinstance(diff, DiffReport)
    assert diff.from_ == "2008"
    assert diff.to_ == "2020"


def test_diff_edition_missing_both_versions_raises() -> None:
    with pytest.raises(ValueError):
        au.compliance.diff_edition("API 579-1")


# ---------------------------------------------------------------------------
# 7. recheck_edition
# ---------------------------------------------------------------------------


def _synthetic_batch():
    """Three records — one with no impactful change, one PASS, one MARGINAL."""

    return [
        # Record from 2021-12 against 2024-09 → has Newman-Raju formula change
        {
            "asset_id": "V-2401",
            "spec": "API 579-1",
            "edition": "2021-12",
            "verdict": "PASS",
            "p_pass": 0.97,
        },
        # Edition pair with no changes between them — should be still_pass
        {
            "asset_id": "V-2402",
            "spec": "API 581",
            "edition": "2020",
            "verdict": "PASS",
            "p_pass": 0.99,
        },
        # MARGINAL → likely FAIL after impactful changes
        {
            "asset_id": "V-2403",
            "spec": "ASME II-D",
            "edition": "2021",
            "verdict": "MARGINAL",
            "p_pass": 0.55,
        },
    ]


def test_recheck_edition_reports_changes() -> None:
    report = au.compliance.recheck_edition(
        records=_synthetic_batch(),
        edition="2024-09",
    )
    assert isinstance(report, RecheckReport)
    # Two records targeted at 2024-09: V-2401 (API 579-1) and the third
    # one has spec "ASME II-D" so it won't find a 2024-09 edition.
    # Verify we got 3 detail rows back regardless
    assert len(report.details) == 3
    # V-2401 should change at least the margin
    v2401 = next(d for d in report.details if d.asset_id == "V-2401")
    assert v2401.old_verdict == "PASS"
    assert v2401.old_p_pass == 0.97


def test_recheck_edition_handles_record_without_spec() -> None:
    report = au.compliance.recheck_edition(
        records=[{"asset_id": "X", "verdict": "PASS"}],
        edition="2024-09",
    )
    assert len(report.details) == 1
    assert "no 'spec'" in (report.details[0].note or "")


def test_recheck_edition_uses_default_spec() -> None:
    # If global spec is provided and records don't have one, use it
    report = au.compliance.recheck_edition(
        records=[
            {"asset_id": "X", "verdict": "PASS", "edition": "2021-12", "p_pass": 0.99}
        ],
        edition="2024-09",
        spec="API 579-1",
    )
    assert len(report.details) == 1
    # The record now has an inferred spec from the global, so should not
    # complain about missing 'spec'.
    assert "no 'spec'" not in (report.details[0].note or "")


def test_recheck_edition_compliance_nested_verdict() -> None:
    """Accepts records with a nested compliance.verdict block."""

    rec = {
        "asset_id": "Y-7",
        "spec": "API 579-1",
        "edition": "2021-12",
        "compliance": {"verdict": "PASS", "p_pass": 0.96},
    }
    report = au.compliance.recheck_edition(records=[rec], edition="2024-09")
    assert report.details[0].old_verdict == "PASS"


def test_recheck_edition_no_changes_keeps_pass() -> None:
    """When from==to the diff is empty and records remain PASS."""

    report = au.compliance.recheck_edition(
        records=[
            {
                "asset_id": "Z-1",
                "spec": "API 579-1",
                "edition": "2024-09",
                "verdict": "PASS",
                "p_pass": 0.99,
            }
        ],
        edition="2024-09",
    )
    assert report.still_pass == 1
    assert report.now_fail == 0
    assert report.changed_margin == 0


# ---------------------------------------------------------------------------
# 8. DiffReport / EditionChange / RecheckReport are JSON-serializable
# ---------------------------------------------------------------------------


def test_diff_report_to_dict_serializable() -> None:
    diff = au.compliance.diff_edition("API 579-1", "2021-12", "2024-09")
    d = diff.to_dict()
    s = json.dumps(d)
    rt = json.loads(s)
    assert rt["spec"] == "API 579-1"
    # Corpus expanded — assert presence rather than fixed count
    assert len(rt["changes"]) >= 7


def test_recheck_report_to_dict_serializable() -> None:
    report = au.compliance.recheck_edition(
        records=_synthetic_batch(), edition="2024-09",
    )
    d = report.to_dict()
    s = json.dumps(d)
    assert "details" in s


# ---------------------------------------------------------------------------
# 9. Edition-change kind validation in corpus
# ---------------------------------------------------------------------------


def test_invalid_kind_in_corpus_raises_value_error() -> None:
    bad = {
        "spec": "TEST",
        "editions": [
            {
                "id": "v1",
                "published": "2020-01",
                "changes": [
                    {
                        "section": "1",
                        "kind": "not_a_real_kind",
                        "summary": "bad",
                    }
                ],
            }
        ],
    }
    with pytest.raises(ValueError, match="invalid"):
        _validate_corpus_schema(bad, source="<test>")
