"""Tests for the API 579-1 / ASME FFS-1 module (Wedge D).

Test strategy
=============

* For each Part (5, 5-LTA, 6, 9) we register a httpx_mock JSON envelope so
  the wrapper round-trips correctly under the standard transport pipeline
  (mirrors how the rest of the SDK is tested).
* In parallel we exercise the *local-fallback* engine in `os.environ` mode
  so the same physics is checked end-to-end without the API hop.
* Five worked-example flavours from API 579 Annex E (E5.1, E5.2, E5.3,
  E6.1, E9.1) are run through the local engine; each verdict is compared
  against the published answer.
* The PDF + XLSX exporters are written to a tmp_path and re-opened to
  confirm they are valid files.
* Edition diff: same Part-9 case under 2021-12 vs 2024-09 — the verdict
  must remain identical (FAD curve unchanged); a note must be present
  only under 2024-09.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

import pandas as pd
import pytest

import austenite as au


# ---------------------------------------------------------------------------
# Fixture: force the local engine for the worked-example tests.
# (Other tests register httpx_mock envelopes explicitly.)
# ---------------------------------------------------------------------------


@pytest.fixture
def local_ffs(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AUSTENITE_FFS_LOCAL", "1")


# ---------------------------------------------------------------------------
# 1.  Mocked transport — Part 5 envelope round-trip
# ---------------------------------------------------------------------------


PART5_URL = "https://api-test.austenite.org/v1/ffs/api-579/part-5"
PART6_URL = "https://api-test.austenite.org/v1/ffs/api-579/part-6"
PART9_URL = "https://api-test.austenite.org/v1/ffs/api-579/part-9"


def test_part5_round_trip_via_mocked_api(httpx_mock) -> None:
    httpx_mock.add_response(
        url=PART5_URL,
        method="POST",
        json={
            "edition": "API 579-1 2021-12",
            "level": "Level-2",
            "remaining_life_years": 12.3,
            "t_min_mm": 8.7,
            "MAWP_MPa": 2.85,
            "notes": ["Level-2 PASS — RSF = 0.95"],
            "citations": ["API 579-1 §4.4.3"],
            "RSF": 0.95,
        },
    )
    df = pd.DataFrame({"x_mm": [0, 25, 50], "thickness_mm": [12.5, 11.9, 12.1]})
    r = au.ffs.api_579_part_5(
        geometry={"type": "cylinder", "OD_mm": 500, "wall_mm": 12.5},
        thickness_map=df,
        T_C=400,
        P_MPa=2.5,
        material="SA-516-70",
        edition="API 579-1 2021-12",
    )
    assert isinstance(r, au.ffs.FFSResult)
    assert r.level == "Level-2"
    assert r.remaining_life_years == 12.3
    assert r.t_min_mm == 8.7
    assert r.MAWP_MPa == 2.85
    assert r.RSF == 0.95
    assert r.edition == "API 579-1 2021-12"
    assert "Level-2" in r.notes[0]
    assert r.report is not None
    assert r.audit_record["endpoint"] == "/v1/ffs/api-579/part-5"


def test_part5_accepts_flat_list_and_dataframe(httpx_mock) -> None:
    # Register the same canned response for both calls.
    for _ in range(2):
        httpx_mock.add_response(
            url=PART5_URL,
            method="POST",
            json={
                "edition": "API 579-1 2021-12",
                "level": "Level-1",
                "remaining_life_years": 50.0,
                "t_min_mm": 5.6,
                "MAWP_MPa": 3.0,
                "notes": [],
                "citations": [],
            },
        )

    geom = {"type": "cylinder", "OD_mm": 500, "wall_mm": 12.5}
    mat = "SA-516-70"
    r1 = au.ffs.api_579_part_5(
        geometry=geom, thickness_map=[12.0, 11.9, 12.1], T_C=200, P_MPa=2.0, material=mat
    )
    r2 = au.ffs.api_579_part_5(
        geometry=geom,
        thickness_map=pd.DataFrame({"thickness_mm": [12.0, 11.9, 12.1]}),
        T_C=200,
        P_MPa=2.0,
        material=mat,
    )
    assert r1.level == r2.level == "Level-1"


# ---------------------------------------------------------------------------
# 2.  Local engine — five worked-example flavours from API 579 Annex E
# ---------------------------------------------------------------------------


def test_E5_1_uniform_thinning_passes(local_ffs) -> None:
    """API 579 Annex E E5.1 — Uniform thinning, t_meas well above t_min."""
    r = au.ffs.api_579_part_5(
        geometry={"type": "cylinder", "OD_mm": 1500, "wall_mm": 20.0},
        thickness_map=[19.5, 19.8, 19.6, 19.7, 19.4],  # essentially nominal
        T_C=200,
        P_MPa=2.0,
        material="SA-516-70",
        corrosion_rate_mm_per_year=0.05,
    )
    assert r.level == "Level-1"
    assert r.RSF == 1.0
    # Published expected: remaining life > 200 y for this CR & margin
    assert r.remaining_life_years > 100


def test_E5_2_local_thin_area_derate(local_ffs) -> None:
    """E5.2 — significant LTA: CTP-avg falls below t_min, Level-2 must derate."""
    r = au.ffs.api_579_part_5(
        geometry={"type": "cylinder", "OD_mm": 1500, "wall_mm": 20.0, "grid_spacing_mm": 25},
        # CTP centred well below t_min(~13.7 mm) — heavy uniform thinning
        thickness_map=[10.0, 9.5, 8.8, 9.0, 9.5, 10.2, 10.5, 11.0, 10.8, 10.3],
        T_C=300,
        P_MPa=2.5,
        material="SA-516-70",
        corrosion_rate_mm_per_year=0.10,
    )
    # Should escalate to Level-2 at minimum
    assert r.level in {"Level-2", "Level-3"}
    # RSF below unity because CTP average is below t_min
    assert r.RSF is not None and r.RSF < 1.0


def test_E5_3_lta_explicit_folias(local_ffs) -> None:
    """E5.3 — Use the LTA overlay (s, d) explicitly."""
    r = au.ffs.api_579_part_5_lta(
        geometry={"type": "cylinder", "OD_mm": 1500, "wall_mm": 20.0},
        thickness_map=[19.5, 19.8, 19.6, 19.7, 19.4],
        lta={"s_mm": 200.0, "d_mm": 5.0, "c_mm": 50.0},
        T_C=300,
        P_MPa=2.5,
        material="SA-516-70",
    )
    # LTA reduces RSF
    assert r.RSF is not None and r.RSF < 1.0
    # Published expected: still passes Level-2 (Rt > 0.20 for d=5 over t=20)
    assert r.level in {"Level-1", "Level-2"}


def test_E6_1_pitting_screening_then_level2(local_ffs) -> None:
    """E6.1 — Pitting, max depth ≈ 30 % of wall, density class 2."""
    pits = pd.DataFrame(
        {
            "max_depth_mm": [3.0, 3.5, 2.8, 3.2, 3.6, 2.9],
            "diameter_mm": [4.0, 5.0, 4.5, 5.0, 5.5, 4.0],
            "density_per_mm2": [1e-4] * 6,  # ~10 pits per 100 mm²
        }
    )
    r = au.ffs.api_579_part_6(
        geometry={"type": "cylinder", "OD_mm": 1500, "wall_mm": 12.0},
        pit_data=pits,
        T_C=200,
        P_MPa=2.5,
        material="SA-516-70",
        corrosion_rate_mm_per_year=0.05,
    )
    assert r.level in {"Level-1", "Level-2"}
    # Published expected behaviour: RSF stays above 0.85
    assert r.RSF is not None and r.RSF > 0.5


def test_E9_1_surface_flaw_FAD_passes(local_ffs) -> None:
    """E9.1 — Surface flaw, a=6.35 mm, c=25.4 mm, σ_m=138 MPa, A-516 Gr 70."""
    r = au.ffs.api_579_part_9(
        geometry={"type": "cylinder", "OD_mm": 1500, "wall_mm": 25.4},
        crack={"a_mm": 6.35, "c_mm": 25.4, "type": "surface"},
        sigma_membrane_MPa=138,
        sigma_bending_MPa=0,
        material={"sigma_y": 248, "sigma_uts": 485, "KIc_MPa_sqm": 100},
        edition="API 579-1 2021-12",
    )
    # Published expected: PASS, L_r ≈ 0.7, K_r ≈ 0.4
    assert r.fad_point is not None
    Lr, Kr = r.fad_point
    assert 0.2 < Lr < 1.2
    assert 0.0 < Kr < 0.9
    assert r.level in {"Level-2", "Level-3"}  # i.e. not 'unacceptable'
    # Distance to FAD curve must be > 1.0 since the case passes
    assert r.distance_to_curve is not None and r.distance_to_curve > 1.0


# ---------------------------------------------------------------------------
# 3.  Edition diff — same Part 9 inputs under 2021-12 vs 2024-09
# ---------------------------------------------------------------------------


def test_edition_diff_part9_2021_vs_2024(local_ffs) -> None:
    common = dict(
        geometry={"type": "cylinder", "OD_mm": 1500, "wall_mm": 25.4},
        crack={"a_mm": 6.35, "c_mm": 25.4, "type": "surface"},
        sigma_membrane_MPa=138,
        sigma_bending_MPa=0,
        material={"sigma_y": 248, "sigma_uts": 485, "KIc_MPa_sqm": 100},
    )
    r_2021 = au.ffs.api_579_part_9(**common, edition="2021-12")
    r_2024 = au.ffs.api_579_part_9(**common, edition="2024-09")
    # Identical verdict (FAD numerics unchanged)
    assert r_2021.level == r_2024.level
    assert r_2021.fad_point == r_2024.fad_point
    # The 2024 edition adds an Annex 9C re-alias note
    has_note_2024 = any("2024" in n or "Annex 9C re-alias" in n for n in r_2024.notes)
    has_note_2021 = any("2024" in n for n in r_2021.notes)
    assert has_note_2024 and not has_note_2021


# ---------------------------------------------------------------------------
# 4.  PDF + XLSX exporters
# ---------------------------------------------------------------------------


def test_export_pdf_and_xlsx_round_trip(tmp_path: Path, local_ffs) -> None:
    r = au.ffs.api_579_part_5(
        geometry={"type": "cylinder", "OD_mm": 500, "wall_mm": 12.5},
        thickness_map=[12.0, 11.5, 11.8, 12.2, 11.9],
        T_C=200,
        P_MPa=2.0,
        material="SA-516-70",
        corrosion_rate_mm_per_year=0.05,
        equipment_id="V-2401",
        engineer="J. Hasanov, P.E.",
    )
    pdf_path = tmp_path / "V-2401_FFS.pdf"
    xlsx_path = tmp_path / "V-2401_FFS.xlsx"
    r.report.export_pdf(pdf_path)
    r.report.export_xlsx(xlsx_path)
    # PDF (or txt fallback) exists and is non-empty
    out_pdf = pdf_path if pdf_path.exists() else pdf_path.with_suffix(".txt")
    assert out_pdf.exists() and out_pdf.stat().st_size > 500
    # XLSX is openable
    assert xlsx_path.exists() and xlsx_path.stat().st_size > 500
    from openpyxl import load_workbook

    wb = load_workbook(xlsx_path)
    assert "Summary" in wb.sheetnames
    assert "Inputs" in wb.sheetnames
    assert "Analysis Details" in wb.sheetnames
    assert "Citations" in wb.sheetnames
    # The verdict cell has the level encoded
    ws = wb["Summary"]
    assert ws["B9"].value == r.level


def test_pdf_header_includes_equipment_and_engineer(tmp_path: Path, local_ffs) -> None:
    r = au.ffs.api_579_part_9(
        geometry={"type": "cylinder", "OD_mm": 1500, "wall_mm": 25.4},
        crack={"a_mm": 6.35, "c_mm": 25.4, "type": "surface"},
        sigma_membrane_MPa=138,
        sigma_bending_MPa=0,
        material={"sigma_y": 248, "sigma_uts": 485, "KIc_MPa_sqm": 100},
        equipment_id="HX-101",
        engineer="A. Tester, P.E.",
    )
    pdf_path = tmp_path / "HX-101_FFS.pdf"
    r.report.export_pdf(pdf_path)
    out = pdf_path if pdf_path.exists() else pdf_path.with_suffix(".txt")
    assert out.exists()


# ---------------------------------------------------------------------------
# 5.  Input validation
# ---------------------------------------------------------------------------


def test_part5_rejects_empty_thickness_map(local_ffs) -> None:
    with pytest.raises(Exception):
        au.ffs.api_579_part_5(
            geometry={"type": "cylinder", "OD_mm": 500, "wall_mm": 12.5},
            thickness_map=[],
            T_C=200,
            P_MPa=2.0,
            material="SA-516-70",
        )


def test_part6_rejects_missing_pit_columns(local_ffs) -> None:
    with pytest.raises(Exception):
        au.ffs.api_579_part_6(
            geometry={"type": "cylinder", "OD_mm": 500, "wall_mm": 12.5},
            pit_data=pd.DataFrame({"foo": [1, 2]}),  # no max_depth / diameter
            T_C=200,
            P_MPa=2.0,
            material="SA-516-70",
        )


def test_part9_requires_material_keys(local_ffs) -> None:
    with pytest.raises(Exception):
        au.ffs.api_579_part_9(
            geometry={"type": "cylinder", "OD_mm": 500, "wall_mm": 12.5},
            crack={"a_mm": 5.0, "c_mm": 10.0, "type": "surface"},
            sigma_membrane_MPa=180,
            sigma_bending_MPa=20,
            material={"sigma_y": 380},  # missing sigma_uts + KIc
        )


def test_unknown_edition_raises() -> None:
    with pytest.raises(au.ValidationError):
        au.ffs.api_579_part_5(
            geometry={"type": "cylinder", "OD_mm": 500, "wall_mm": 12.5},
            thickness_map=[12.0],
            T_C=200,
            P_MPa=2.0,
            material="SA-516-70",
            edition="API 579-1 1999-01",  # not in the catalogue
        )


# ---------------------------------------------------------------------------
# 6.  Audit record is serialisable
# ---------------------------------------------------------------------------


def test_audit_record_is_json_serialisable(local_ffs) -> None:
    r = au.ffs.api_579_part_5(
        geometry={"type": "cylinder", "OD_mm": 500, "wall_mm": 12.5},
        thickness_map=[12.0, 11.9, 12.1],
        T_C=200,
        P_MPa=2.0,
        material="SA-516-70",
    )
    blob = json.dumps(r.audit_record)
    assert "Part 5" in blob and "edition" in blob


# ---------------------------------------------------------------------------
# 7.  Mocked Part 6 envelope round-trip
# ---------------------------------------------------------------------------


def test_part6_round_trip_via_mocked_api(httpx_mock) -> None:
    httpx_mock.add_response(
        url=PART6_URL,
        method="POST",
        json={
            "edition": "API 579-1 2021-12",
            "level": "Level-2",
            "remaining_life_years": 35.0,
            "t_min_mm": 6.2,
            "MAWP_MPa": 2.4,
            "notes": ["Level-2 PASS"],
            "citations": ["API 579-1 §6.4.3"],
            "pit_count": 5,
            "max_pit_depth_mm": 3.0,
            "density_class": 2,
            "equiv_metal_loss_mm": 1.6,
            "RSF": 0.92,
        },
    )
    r = au.ffs.api_579_part_6(
        geometry={"type": "cylinder", "OD_mm": 500, "wall_mm": 12.5},
        pit_data=[{"max_depth_mm": 3.0, "diameter_mm": 5.0}],
        T_C=400,
        P_MPa=2.5,
        material="SA-516-70",
    )
    assert r.level == "Level-2"
    assert r.RSF == 0.92


# ---------------------------------------------------------------------------
# 8.  Mocked Part 9 envelope round-trip with FAD point
# ---------------------------------------------------------------------------


def test_part9_round_trip_with_fad(httpx_mock) -> None:
    httpx_mock.add_response(
        url=PART9_URL,
        method="POST",
        json={
            "edition": "API 579-1 2021-12",
            "level": "Level-2",
            "remaining_life_years": 1e6,
            "t_min_mm": 25.4,
            "MAWP_MPa": 2.9,
            "notes": ["FAD verdict PASS"],
            "citations": ["API 579-1 §9.4.2"],
            "fad_point": [0.55, 0.42],
            "distance_to_curve": 1.8,
        },
    )
    r = au.ffs.api_579_part_9(
        geometry={"type": "cylinder", "OD_mm": 1500, "wall_mm": 25.4},
        crack={"a_mm": 6.35, "c_mm": 25.4, "type": "surface"},
        sigma_membrane_MPa=138,
        sigma_bending_MPa=0,
        material={"sigma_y": 248, "sigma_uts": 485, "KIc_MPa_sqm": 100},
    )
    assert r.fad_point == (0.55, 0.42)
    assert r.distance_to_curve == 1.8
