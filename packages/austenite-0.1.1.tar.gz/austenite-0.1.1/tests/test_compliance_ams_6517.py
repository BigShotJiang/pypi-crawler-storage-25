"""Tests for the AMS 6517 (HY-Tuf aerospace Cr-Mo-V) checker."""

from __future__ import annotations

import pytest

import austenite as au
from austenite.compliance_standards import StandardVerdict, ams_6517


def test_ams_6517_pass_typical_q_and_t() -> None:
    v = ams_6517.check(
        composition={"C": 0.25, "Mn": 1.30, "Si": 1.50,
                     "P": 0.005, "S": 0.003,
                     "Cr": 0.50, "Ni": 1.80, "Mo": 0.40, "V": 0.10},
        mechanical={"sigma_y_MPa": 1400, "sigma_uts_MPa": 1650,
                    "elongation_pct": 14, "hardness_HRC": 50,
                    "K_IC_MPa_sqrt_m": 95},
        heat_treatment={"austenitize_C": 885, "temper_C": 220},
    )
    assert isinstance(v, StandardVerdict)
    assert v.passed is True
    assert v.spec_id == "AMS 6517"


def test_ams_6517_fail_low_K_IC() -> None:
    v = ams_6517.check(
        composition={"C": 0.25, "Mn": 1.30, "Si": 1.50,
                     "P": 0.005, "S": 0.003,
                     "Cr": 0.50, "Ni": 1.80, "Mo": 0.40, "V": 0.10},
        mechanical={"sigma_y_MPa": 1400, "sigma_uts_MPa": 1650,
                    "elongation_pct": 14, "hardness_HRC": 50,
                    "K_IC_MPa_sqrt_m": 40},
    )
    assert v.passed is False
    assert any("K_IC_MPa_sqrt_m" in f and "below min 88" in f for f in v.failed_items)


def test_ams_6517_fail_temper_too_high() -> None:
    v = ams_6517.check(
        composition={"C": 0.25, "Mn": 1.30, "Si": 1.50,
                     "P": 0.005, "S": 0.003,
                     "Cr": 0.50, "Ni": 1.80, "Mo": 0.40, "V": 0.10},
        heat_treatment={"austenitize_C": 885, "temper_C": 400},  # too high
    )
    assert v.passed is False
    assert any("temper_C" in f and "above max 230" in f for f in v.failed_items)


def test_ams_6517_fail_phosphorus_above_limit() -> None:
    v = ams_6517.check(
        composition={"C": 0.25, "Mn": 1.30, "Si": 1.50,
                     "P": 0.020, "S": 0.003,
                     "Cr": 0.50, "Ni": 1.80, "Mo": 0.40, "V": 0.10},
    )
    assert v.passed is False
    assert any("P =" in f and "exceeds max 0.01" in f for f in v.failed_items)
