"""Physics-accuracy audit #2: inverse-heat-treat / active-learning / ICME-MC / busbar.

Each test works a concrete numerical example by hand from a cited reference and
asserts the library reproduces it within an explicit tolerance. References inline.

Sources used for hand calculations:
    * Hollomon J.H., Jaffe L.D., Trans. AIME 162 (1945) 223 — HJP = T_K*(C + log10 t).
    * Pavlina E.J., Van Tyne C.J., J. Mater. Eng. Perform. 17 (2008) 888 —
      sigma_y(MPa) = 2.876*HV - 90.7.
    * Hall E.O., Proc. Phys. Soc. B 64 (1951) 747; Petch — sigma_y = sigma_0 + k/sqrt(d).
    * MacKay D.J.C., Neural Comp. 4 (1992) 590 — BALD = 0.5*log(var_pred/var_obs).
    * Settles B., "Active Learning Literature Survey" (2009) — QBC committee variance.
    * Orowan — Delta_sigma = 2*G*b/lambda, lambda = r*sqrt(pi/(2 f_v)).
    * Basquin — N_f = 0.5*(sigma_a/sigma_f)^(1/b), b < 0.
    * Goodman — sigma_a_allow = sigma_e*(1 - sigma_m/sigma_UTS).
    * Onderdonk I.M., Electric J. Sept 1944; IEEE 80-2013 sec 11.3.5 — adiabatic SCC.
    * Wheeler H.A., Proc. IRE 35 (1947) 412 — skin effect.

Library issues found during this audit:
    1. busbar_designer.design_busbar used A = (I/K)**2, inflating the first-pass
       cross-section by orders of magnitude (2000 A -> ~2e6 mm2). FIXED: step-1
       area now uses the IEC ampacity power law A=(I/K)^(1/0.6); the test below
       (test_design_busbar_cross_section_is_physical) now asserts physical sizing.
    2. onderdonk_short_circuit_rating_kA docstring claims "~40 kA" for the default
       90->175 C, A=1000 mm2, 1 s case; the (correct) formula returns ~104 kA.
       Still documented as a strict-xfail at the bottom (source NOT modified).
"""

from __future__ import annotations

import math

import pytest

import austenite as au

iht = au.inverse_heat_treat
al = au.active_learning
icme = au.icme_monte_carlo
bb = au.busbar_designer


# ===========================================================================
# inverse_heat_treat — Pavlina-Tyne, Hollomon-Jaffe, Hall-Petch, quench HV
# ===========================================================================

def test_pavlina_tyne_hv400_is_1060():
    # Pavlina-Tyne: HV=400 -> 2.876*400 - 90.7 = 1059.7 MPa ~ 1060.
    sy = iht.predict_sigma_y_from_HV(400.0)
    assert sy == pytest.approx(1059.7, abs=0.5)


def test_pavlina_tyne_slope_and_intercept():
    # Slope is 2.876 MPa per HV; intercept -90.7. Check two points.
    s300 = iht.predict_sigma_y_from_HV(300.0)
    s301 = iht.predict_sigma_y_from_HV(301.0)
    assert (s301 - s300) == pytest.approx(2.876, abs=1e-6)
    assert s300 == pytest.approx(2.876 * 300 - 90.7, abs=1e-6)


def test_pavlina_tyne_clamped_nonnegative():
    # Very low HV would give negative MPa; function clamps at 0.
    assert iht.predict_sigma_y_from_HV(10.0) == 0.0


def test_hollomon_jaffe_formula_value():
    # HJP = (500+273.15)*(20 + log10 1) = 773.15*20 = 15463.
    assert iht.hollomon_jaffe_parameter(500.0, 1.0, C=20.0) == pytest.approx(15463.0, abs=0.5)


def test_hollomon_jaffe_time_term():
    # Doubling-to-quadrupling time: log10(4)=0.602. HJP(500,4)=773.15*(20.602)=15928.5.
    assert iht.hollomon_jaffe_parameter(500.0, 4.0, C=20.0) == pytest.approx(15928.48, abs=0.5)


def test_hollomon_jaffe_higher_T_higher_HJP():
    # Higher temper T -> higher HJP (monotonic).
    lo = iht.hollomon_jaffe_parameter(500.0, 1.0)
    hi = iht.hollomon_jaffe_parameter(600.0, 1.0)
    assert hi > lo


def test_hollomon_jaffe_longer_t_higher_HJP():
    lo = iht.hollomon_jaffe_parameter(500.0, 1.0)
    hi = iht.hollomon_jaffe_parameter(500.0, 4.0)
    assert hi > lo


def test_higher_temper_gives_lower_hardness():
    # Higher temper T (above the 17000 HJP threshold) -> more softening -> lower HV.
    hv_low_T = iht.predict_HV_after_temper(600.0, 500.0, 1.0)
    hv_high_T = iht.predict_HV_after_temper(600.0, 650.0, 1.0)
    assert hv_high_T < hv_low_T


def test_longer_temper_time_gives_lower_hardness():
    hv_1h = iht.predict_HV_after_temper(600.0, 600.0, 1.0)
    hv_4h = iht.predict_HV_after_temper(600.0, 600.0, 4.0)
    assert hv_4h < hv_1h


def test_hall_petch_value():
    # sigma_0=100 MPa, k=0.6 MPa*sqrt(m), d=100 um=1e-4 m:
    # 100 + 0.6/sqrt(1e-4) = 100 + 60 = 160 MPa.
    sy = iht.hall_petch_sigma_y(100.0, 0.6, 100.0)
    assert sy == pytest.approx(160.0, abs=1e-6)


def test_hall_petch_smaller_grain_higher_strength():
    coarse = iht.hall_petch_sigma_y(100.0, 0.6, 100.0)
    fine = iht.hall_petch_sigma_y(100.0, 0.6, 10.0)
    assert fine > coarse


def test_quench_water_harder_than_air():
    # Higher quench severity -> more martensite -> higher as-quenched HV.
    comp = {"C": 0.4, "Mn": 0.875, "Si": 0.25, "Cr": 0.95, "Mo": 0.20}
    hv_water = iht.quench_HV_estimate(comp, 870.0, "water")
    hv_air = iht.quench_HV_estimate(comp, 870.0, "air")
    assert hv_water > hv_air


def test_design_heat_treat_inverts_pavlina_tyne_target():
    # Targeting sigma_y=1000 MPa -> target HV=(1000+90.7)/2.876=379.2.
    # Returned schedule's predicted sigma_y should be reasonably close.
    comp = {"C": 0.4, "Mn": 0.875, "Si": 0.25, "Cr": 0.95, "Mo": 0.20}
    sch = iht.design_heat_treat(comp, target_sigma_y_MPa=1000.0)
    assert sch.predicted_sigma_y_MPa == pytest.approx(1000.0, abs=120.0)
    # sigma_y must be consistent with predicted_HV via Pavlina-Tyne.
    assert sch.predicted_sigma_y_MPa == pytest.approx(
        iht.predict_sigma_y_from_HV(sch.predicted_HV), abs=1e-6
    )


# ===========================================================================
# active_learning — BALD, ALM, QBC
# ===========================================================================

def test_bald_value_gaussian():
    # BALD = 0.5*log(var_pred/var_obs); var_pred=var_post+noise.
    # var_post=2.0, noise=1.0 -> var_pred=3.0 -> 0.5*log(3)=0.5493.
    score = al.bald_score(2.0, 3.0)
    assert score == pytest.approx(0.5 * math.log(3.0), abs=1e-9)
    assert score == pytest.approx(0.5493, abs=1e-3)


def test_bald_increases_with_epistemic_variance():
    # Higher posterior (epistemic) variance at fixed noise -> higher BALD.
    lo = al.bald_score(0.1, 0.1 + 1.0)
    hi = al.bald_score(2.0, 2.0 + 1.0)
    assert hi > lo


def test_bald_zero_when_predictive_below_posterior():
    # Inconsistent inputs (var_pred < var_post) are guarded to 0.
    assert al.bald_score(2.0, 1.0) == 0.0


def test_bald_nonnegative_for_valid_inputs():
    # For valid var_pred >= var_post the score is finite and >= 0.
    score = al.bald_score(1.0, 2.0)
    assert score >= 0.0
    assert math.isfinite(score)


def test_alm_returns_variance():
    # ALM score is just the posterior variance.
    assert al.alm_score(2.5) == pytest.approx(2.5, abs=1e-12)


def test_alm_nonpositive_returns_zero():
    assert al.alm_score(-1.0) == 0.0


def test_qbc_population_variance():
    # Committee predictions [1,2,3]: population variance = (1+0+1)/3 = 0.6667.
    assert al.query_by_committee_disagreement([1.0, 2.0, 3.0]) == pytest.approx(2.0 / 3.0, abs=1e-9)


def test_rank_candidates_orders_high_variance_first():
    # Candidate(inputs, mean, variance) — variance is the 3rd field.
    cands = [
        al.Candidate({"x": 1}, 0.0, 0.1),
        al.Candidate({"x": 2}, 0.0, 5.0),
    ]
    ranked = al.rank_candidates(cands, noise_variance=1.0, method="BALD")
    assert ranked[0].candidate.variance == pytest.approx(5.0)
    # And the ALM method picks the same top candidate.
    ranked_alm = al.rank_candidates(cands, noise_variance=1.0, method="ALM")
    assert ranked_alm[0].candidate.variance == pytest.approx(5.0)


# ===========================================================================
# icme_monte_carlo — gamma', Orowan, Goodman, Basquin, end-to-end MC
# ===========================================================================

def test_orowan_delta_sigma_value():
    # lambda = r*sqrt(pi/(2 f_v)); r=10nm, f_v=0.2 -> sqrt(pi/0.4)=2.8025,
    # lambda=2.8025e-8 m. Delta_sigma = 2*80e9*2.5e-10/lambda = 1427.3 MPa.
    ds = icme._stage_orowan_delta_sigma(10e-9, 0.2)
    lam = 10e-9 * math.sqrt(math.pi / (2 * 0.2))
    expect = 2.0 * 80e9 * 2.5e-10 / lam / 1e6
    assert ds == pytest.approx(expect, rel=1e-9)
    assert ds == pytest.approx(1427.3, abs=1.0)


def test_orowan_smaller_radius_stronger():
    # Finer precipitates (smaller r) -> smaller spacing -> larger Delta_sigma.
    fine = icme._stage_orowan_delta_sigma(10e-9, 0.2)
    coarse = icme._stage_orowan_delta_sigma(50e-9, 0.2)
    assert fine > coarse


def test_goodman_amplitude_value():
    # sigma_e=0.5*UTS; sigma_a_allow=0.5*1240*(1-300/1240)=470 MPa.
    ga = icme._stage_goodman_amplitude(0.0, 300.0, 1240.0)
    assert ga == pytest.approx(470.0, abs=1e-6)


def test_goodman_zero_mean_gives_endurance_limit():
    # sigma_m=0 -> sigma_a_allow = sigma_e = 0.5*UTS.
    ga = icme._stage_goodman_amplitude(0.0, 0.0, 1240.0)
    assert ga == pytest.approx(620.0, abs=1e-6)


def test_basquin_value():
    # N_f = 0.5*(200/1860)^(1/-0.085).
    nf = icme._stage_basquin_nf(200.0, 1860.0, -0.085)
    expect = 0.5 * (200.0 / 1860.0) ** (1.0 / -0.085)
    assert nf == pytest.approx(expect, rel=1e-9)


def test_basquin_higher_stress_fewer_cycles():
    nf_lo = icme._stage_basquin_nf(200.0, 1860.0, -0.085)
    nf_hi = icme._stage_basquin_nf(400.0, 1860.0, -0.085)
    assert nf_hi < nf_lo


def test_basquin_positive_b_returns_inf():
    # Physically b must be negative; guard returns inf for b>=0.
    assert icme._stage_basquin_nf(200.0, 1860.0, 0.085) == float("inf")


def test_gamma_prime_increases_with_al_ti():
    lo = icme._stage_calphad_gamma_prime(0.5, 0.9, 973.0)
    hi = icme._stage_calphad_gamma_prime(1.5, 3.0, 973.0)
    assert hi > lo


def test_icme_zero_composition_sigma_gives_no_spread():
    # Deterministic composition -> identical samples -> zero sigma_y spread.
    comp = [
        icme.CompositionUncertainty("Al", 0.5, 0.0),
        icme.CompositionUncertainty("Ti", 0.9, 0.0),
    ]
    r = icme.run_probabilistic_icme(comp, n_samples=1000, seed=1)
    assert r.sigma_sigma_y_MPa == pytest.approx(0.0, abs=1e-9)


def test_icme_nonzero_sigma_gives_spread():
    comp = [
        icme.CompositionUncertainty("Al", 0.5, 0.1),
        icme.CompositionUncertainty("Ti", 0.9, 0.15),
    ]
    r = icme.run_probabilistic_icme(comp, n_samples=2000, seed=1)
    assert r.sigma_sigma_y_MPa > 1.0


def test_icme_p_survives_in_unit_interval():
    comp = [
        icme.CompositionUncertainty("Al", 0.5, 0.1),
        icme.CompositionUncertainty("Ti", 0.9, 0.15),
    ]
    r = icme.run_probabilistic_icme(comp, n_samples=1000, seed=7)
    assert 0.0 <= r.p_survives_target_cycles <= 1.0


# ===========================================================================
# busbar_designer — Onderdonk, Wheeler skin effect, resistivity(T)
# ===========================================================================

def test_resistivity_increases_with_temperature():
    # rho(T)=rho20*(1+alpha*(T-20)); Cu 75 C: 1.72*(1+0.00393*55)=2.0918 uohm-cm.
    r20 = bb.resistivity_at_T("Cu_C11000", 20.0)
    r75 = bb.resistivity_at_T("Cu_C11000", 75.0)
    assert r20 == pytest.approx(1.72, abs=1e-9)
    assert r75 == pytest.approx(1.72 * (1 + 0.00393 * 55), abs=1e-6)
    assert r75 > r20


def test_onderdonk_current_proportional_to_area():
    # I scales linearly with cross-section A at fixed t and temperature window.
    i1 = bb.onderdonk_short_circuit_rating_kA(1000.0, "Cu_C11000", duration_s=1.0)
    i2 = bb.onderdonk_short_circuit_rating_kA(2000.0, "Cu_C11000", duration_s=1.0)
    assert i2 / i1 == pytest.approx(2.0, abs=1e-6)


def test_onderdonk_current_inverse_sqrt_time():
    # Doubling fault time reduces allowable current by sqrt(2).
    i1 = bb.onderdonk_short_circuit_rating_kA(1000.0, "Cu_C11000", duration_s=1.0)
    i2 = bb.onderdonk_short_circuit_rating_kA(1000.0, "Cu_C11000", duration_s=2.0)
    assert i1 / i2 == pytest.approx(math.sqrt(2.0), abs=1e-6)


def test_onderdonk_cu_density_against_iec_ruleofthumb():
    # Cu, 30->300 C, 1 s, A=1000 mm2 -> ~181 A/mm2 (CDA/IEC rule ~ 180-226).
    i = bb.onderdonk_short_circuit_rating_kA(
        1000.0, "Cu_C11000", theta_initial_C=30.0, theta_final_C=300.0, duration_s=1.0
    )
    assert i == pytest.approx(181.5, abs=5.0)


def test_onderdonk_cu_higher_than_al():
    # Copper carries ~1.5x the Aluminium short-circuit density (same window).
    i_cu = bb.onderdonk_short_circuit_rating_kA(
        1000.0, "Cu_C11000", theta_initial_C=30.0, theta_final_C=300.0, duration_s=1.0
    )
    i_al = bb.onderdonk_short_circuit_rating_kA(
        1000.0, "Al_1350", theta_initial_C=30.0, theta_final_C=300.0, duration_s=1.0
    )
    assert (i_cu / i_al) == pytest.approx(1.53, abs=0.1)


def test_skin_effect_dc_is_unity():
    assert bb.skin_effect_factor(2000.0, "Cu_C11000", 0.0) == 1.0


def test_skin_effect_increases_with_frequency():
    s60 = bb.skin_effect_factor(2000.0, "Cu_C11000", 60.0)
    s400 = bb.skin_effect_factor(2000.0, "Cu_C11000", 400.0)
    assert s400 > s60 >= 1.0


# ===========================================================================
# Documented library inaccuracies (source NOT modified) — xfail.
# ===========================================================================

def test_design_busbar_cross_section_is_physical():
    # FIXED: step-1 area now uses the IEC ampacity power law A=(I/K)^(1/0.6),
    # K~29 (Cu). A 2000 A continuous Cu busbar is on the order of 1e2-1e3 mm2.
    # Measured: ~1160 mm2 -> current density ~1.7 A/mm2 (physical, ~0.5-6 range).
    d = bb.design_busbar(2000.0, material="Cu_C11000", length_m=1.0)
    assert 500.0 <= d.cross_section_mm2 <= 3000.0
    current_density = 2000.0 / d.cross_section_mm2
    assert 0.5 <= current_density <= 6.0


@pytest.mark.xfail(
    reason="Docstring claims ~40 kA for default 90->175 C, A=1000 mm2, 1 s; the "
    "(correct) adiabatic formula returns ~104 kA for that small 85 C window.",
    strict=True,
)
def test_onderdonk_docstring_40kA_default_case():
    # Docstring assertion under test (NOT the formula, which is correct).
    i = bb.onderdonk_short_circuit_rating_kA(
        1000.0, "Cu_C11000", theta_initial_C=90.0, theta_final_C=175.0, duration_s=1.0
    )
    assert i == pytest.approx(40.0, abs=5.0)
