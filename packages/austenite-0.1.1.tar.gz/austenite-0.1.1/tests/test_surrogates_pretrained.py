"""Tests for the bundled pre-trained ML surrogates.

The .pkl artefacts are generated offline by
``scripts/train_pretrained_surrogates.py`` and shipped via
``[tool.setuptools.package-data]``. These tests verify that

  * the registry (``list_pretrained``) finds every shipped surrogate;
  * ``load_pretrained`` returns a usable :class:`Surrogate`;
  * single-row and batch predictions return finite values;
  * the held-out R² is at least 0.95 — the launch-grade bar;
  * single-row inference takes < 5 ms (sub-millisecond on most boxes).

These tests do NOT require XGBoost / LightGBM — they pin behaviour
against the ``model="linear"`` polynomial-ridge baseline that ships in
every wheel.
"""

from __future__ import annotations

import math
import time

import pytest

import austenite as au
from austenite.surrogates import Surrogate, list_pretrained, load_pretrained


# Catalogue of bundled surrogates and the expected target unit / range.
# The numeric "plausible_range" is a sanity envelope, not a unit-test
# acceptance criterion — the R² check below is the real gate.
_BUNDLED = {
    "design-path-sigma-y-v0.1": ("sigma_y_MPa", "MPa", (200.0, 3000.0)),
    "design-path-sigma-uts-v0.1": ("sigma_uts_MPa", "MPa", (200.0, 3500.0)),
    "design-path-KIc-v0.1": ("KIc_MPa_sqm", "MPa*sqrt(m)", (10.0, 600.0)),
    "design-path-HV30-v0.1": ("HV30", "HV", (100.0, 900.0)),
    "design-path-fatigue-util-v0.1": ("fatigue_utilisation_pct", "%", (0.0, 200.0)),
}


# Mid-range AISI 4140-ish row used for plausibility checks.
_AISI_4140_ROW = {
    "C": 0.40, "Mn": 0.85, "Cr": 0.95, "Mo": 0.20,
    "Ni": 0.0, "Si": 0.25, "V": 0.0,
    "cooling_rate": 10.0, "sigma_app_MPa": 500.0,
}


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------


def test_list_pretrained_returns_every_bundled_surrogate():
    names = set(list_pretrained())
    for expected in _BUNDLED:
        assert expected in names, f"missing bundled surrogate: {expected}"


def test_list_pretrained_is_a_list_of_strings():
    names = list_pretrained()
    assert isinstance(names, list)
    for n in names:
        assert isinstance(n, str) and n


def test_load_pretrained_unknown_name_raises_filenotfound():
    with pytest.raises(FileNotFoundError):
        load_pretrained("does-not-exist-v999")


def test_load_pretrained_empty_name_raises_valueerror():
    with pytest.raises(ValueError):
        load_pretrained("")


# ---------------------------------------------------------------------------
# load_pretrained returns a valid Surrogate
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("name", list(_BUNDLED))
def test_load_pretrained_returns_valid_surrogate(name):
    s = load_pretrained(name)
    assert isinstance(s, Surrogate)
    assert s.target == _BUNDLED[name][0]
    assert s.target_unit == _BUNDLED[name][1]
    assert s.feature_names  # non-empty
    assert s.n_train > 0
    assert s.r2_test >= 0.95, (
        f"{name} R²={s.r2_test:.3f} below launch-grade bar (0.95)"
    )


# ---------------------------------------------------------------------------
# predict — single row
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("name", list(_BUNDLED))
def test_predict_returns_finite_scalar(name):
    s = load_pretrained(name)
    y = s.predict(_AISI_4140_ROW)
    assert math.isfinite(y), f"{name} returned non-finite value: {y!r}"
    lo, hi = _BUNDLED[name][2]
    assert lo <= y <= hi, f"{name} predicted {y:.2f} outside plausible {lo, hi}"


def test_predict_handles_missing_features_gracefully():
    """Missing features are zero-padded — predict still returns finite."""

    s = load_pretrained("design-path-sigma-y-v0.1")
    y = s.predict({"C": 0.40, "Mn": 0.85, "Cr": 0.95})
    assert math.isfinite(y)


# ---------------------------------------------------------------------------
# predict_batch
# ---------------------------------------------------------------------------


def test_predict_batch_matches_single_predict_on_first_row():
    pd = pytest.importorskip("pandas")
    s = load_pretrained("design-path-sigma-y-v0.1")
    df = pd.DataFrame([
        _AISI_4140_ROW,
        {**_AISI_4140_ROW, "C": 0.42, "Cr": 1.85, "Ni": 1.85},
    ])
    batch = s.predict_batch(df)
    single = s.predict(_AISI_4140_ROW)
    assert len(batch) == 2
    # Floating-point exact agreement between predict() and predict_batch()[0].
    assert abs(batch[0] - single) < 1e-6


def test_predict_batch_accepts_list_of_dicts():
    s = load_pretrained("design-path-sigma-y-v0.1")
    rows = [_AISI_4140_ROW, {**_AISI_4140_ROW, "C": 0.20}]
    preds = s.predict_batch(rows)
    assert len(preds) == 2
    assert all(math.isfinite(p) for p in preds)


def test_predict_batch_100_random_rows_all_finite():
    pd = pytest.importorskip("pandas")
    import random

    random.seed(0)
    rows = []
    for _ in range(100):
        rows.append({
            "C": random.uniform(0.1, 0.5),
            "Mn": random.uniform(0.3, 1.2),
            "Cr": random.uniform(0.1, 1.5),
            "Mo": random.uniform(0.05, 0.4),
            "Ni": random.uniform(0.0, 1.0),
            "Si": random.uniform(0.1, 0.4),
            "V": random.uniform(0.0, 0.1),
            "cooling_rate": random.uniform(1.0, 100.0),
            "sigma_app_MPa": random.uniform(200.0, 700.0),
        })
    df = pd.DataFrame(rows)
    s = load_pretrained("design-path-sigma-y-v0.1")
    preds = s.predict_batch(df)
    assert len(preds) == 100
    assert all(math.isfinite(p) for p in preds)
    # All within the plausible σ_y envelope for low-alloy steels.
    assert all(200.0 < p < 3000.0 for p in preds)


# ---------------------------------------------------------------------------
# Performance — single-row inference should be sub-millisecond
# ---------------------------------------------------------------------------


def test_predict_is_sub_5ms_per_call():
    s = load_pretrained("design-path-sigma-y-v0.1")
    N = 200
    # Warm-up.
    for _ in range(5):
        s.predict(_AISI_4140_ROW)
    t0 = time.time()
    for _ in range(N):
        s.predict(_AISI_4140_ROW)
    dt_ms = (time.time() - t0) * 1000.0 / N
    # Linear-ridge polynomial-deg-2 surrogate should be well under 5 ms.
    assert dt_ms < 5.0, f"predict averaged {dt_ms:.2f} ms — too slow"


# ---------------------------------------------------------------------------
# Lazy namespace
# ---------------------------------------------------------------------------


def test_surrogates_accessible_via_au_namespace():
    assert hasattr(au, "surrogates")
    assert callable(au.surrogates.load_pretrained)
    assert callable(au.surrogates.list_pretrained)
