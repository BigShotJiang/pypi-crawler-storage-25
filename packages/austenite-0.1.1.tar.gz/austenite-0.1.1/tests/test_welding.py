"""Tests for au.welding — carbon equivalents, heat input, Rosenthal, t_8/5,
preheat, HAZ width."""
from __future__ import annotations

import math
import pytest

from austenite.welding import (
    ARC_EFFICIENCY,
    cet_duren,
    ce_iiw,
    ce_yurioka,
    cooling_time_t85,
    dilution_pct,
    haz_width_mm,
    heat_input_kJ_per_mm,
    mixed_zone_composition,
    pcm_ito_bessyo,
    rosenthal_2d_temperature,
    rosenthal_3d_temperature,
    yurioka_preheat_C,
)


# ---------------------------------------------------------------------------
# Carbon equivalents
# ---------------------------------------------------------------------------


def test_ce_iiw_aisi_4140():
    """AISI 4140: 0.4C, 0.85Mn, 0.95Cr, 0.20Mo, 0.30Si."""
    ce = ce_iiw({"C": 0.40, "Mn": 0.85, "Cr": 0.95, "Mo": 0.20, "Si": 0.30})
    # CE_IIW = 0.40 + 0.85/6 + (0.95+0.20+0)/5 + 0 = 0.40 + 0.142 + 0.23 = 0.772
    assert math.isclose(ce, 0.772, rel_tol=1e-2)


def test_ce_iiw_low_carbon_low_alloy():
    """A36-like: 0.15C, 0.80Mn, no other alloy."""
    ce = ce_iiw({"C": 0.15, "Mn": 0.80})
    # 0.15 + 0.80/6 = 0.283
    assert math.isclose(ce, 0.283, rel_tol=1e-2)


def test_ce_yurioka_returns_higher_for_high_carbon():
    ce_lo = ce_yurioka({"C": 0.10, "Mn": 1.0})
    ce_hi = ce_yurioka({"C": 0.40, "Mn": 1.0})
    assert ce_hi > ce_lo


def test_pcm_ito_bessyo_basic():
    pcm = pcm_ito_bessyo({"C": 0.10, "Mn": 1.5, "Si": 0.3})
    assert math.isfinite(pcm)
    assert pcm > 0.10


def test_cet_duren_basic():
    cet = cet_duren({"C": 0.12, "Mn": 1.5, "Mo": 0.3, "Cr": 0.5, "Ni": 0.5})
    assert math.isfinite(cet)


def test_ce_iiw_empty_composition_zero():
    """No elements → CE = 0."""
    assert ce_iiw({}) == 0.0


# ---------------------------------------------------------------------------
# Heat input
# ---------------------------------------------------------------------------


def test_heat_input_basic():
    H = heat_input_kJ_per_mm(voltage_V=30, current_A=200, travel_speed_mm_s=5, process="SAW")
    # η=0.95: H = 0.95 × 30 × 200 / (5×1000) = 1.14 kJ/mm
    assert math.isclose(H, 1.14, rel_tol=1e-3)


def test_heat_input_faster_travel_lower_H():
    H_slow = heat_input_kJ_per_mm(30, 200, 2)
    H_fast = heat_input_kJ_per_mm(30, 200, 10)
    assert H_slow > H_fast


def test_heat_input_zero_speed_returns_inf():
    H = heat_input_kJ_per_mm(30, 200, 0)
    assert math.isinf(H)


def test_arc_efficiency_table_ordering():
    """SAW most efficient, GTAW lowest among arc."""
    assert ARC_EFFICIENCY["SAW"] > ARC_EFFICIENCY["GMAW"] > ARC_EFFICIENCY["GTAW"]


# ---------------------------------------------------------------------------
# Dilution + mixed-zone
# ---------------------------------------------------------------------------


def test_dilution_basic():
    """If A_base = A_filler, dilution = 50%."""
    D = dilution_pct(A_filler_mm2=30, A_base_mm2=30)
    assert math.isclose(D, 50.0, rel_tol=1e-9)


def test_dilution_no_base_zero():
    D = dilution_pct(A_filler_mm2=30, A_base_mm2=0)
    assert math.isclose(D, 0.0, rel_tol=1e-9)


def test_mixed_zone_composition_50_50():
    """50% dilution of pure-Ni filler (75% Ni) onto C-steel base (0.1% C)."""
    weld = mixed_zone_composition(
        composition_filler={"Ni": 0.75, "Cr": 0.20, "Mo": 0.05},
        composition_base={"Fe": 0.98, "C": 0.10, "Mn": 0.80},
        dilution_pct_value=50.0,
    )
    # 50% dilution: weld = 0.5·filler + 0.5·base
    assert math.isclose(weld["Ni"], 0.375, rel_tol=1e-3)
    assert math.isclose(weld["C"], 0.05, rel_tol=1e-3)


# ---------------------------------------------------------------------------
# Rosenthal heat-source temperature
# ---------------------------------------------------------------------------


def test_rosenthal_2d_returns_finite_at_typical_point():
    T = rosenthal_2d_temperature(
        Q_W=3000, v_mm_s=5, T_0_C=25,
        x_mm=10, r_perp_mm=5,
        thickness_mm=10, k_W_mK=50, alpha_mm2_s=5,
    )
    assert math.isfinite(T)


def test_rosenthal_2d_at_source_infinite():
    """At R=0 the point-source temperature diverges (mathematical limit)."""
    T = rosenthal_2d_temperature(
        Q_W=3000, v_mm_s=5, T_0_C=25, x_mm=0, r_perp_mm=0,
    )
    assert math.isinf(T)


def test_rosenthal_3d_decay_with_distance():
    T_near = rosenthal_3d_temperature(Q_W=3000, v_mm_s=5, T_0_C=25, x_mm=5, r_mm=2)
    T_far = rosenthal_3d_temperature(Q_W=3000, v_mm_s=5, T_0_C=25, x_mm=50, r_mm=20)
    assert T_near > T_far


# ---------------------------------------------------------------------------
# Cooling time t_8/5
# ---------------------------------------------------------------------------


def test_t85_basic():
    """1.5 kJ/mm, RT preheat → t_85 in typical 10-25 s range for thin plate."""
    t = cooling_time_t85(Q_kJ_mm=1.5, T_0_C=25, thickness_mm=12, geometry="thin")
    assert math.isfinite(t)
    assert t > 0


def test_t85_higher_heat_input_longer_cooling():
    t_lo = cooling_time_t85(Q_kJ_mm=0.5, T_0_C=25, thickness_mm=12)
    t_hi = cooling_time_t85(Q_kJ_mm=2.5, T_0_C=25, thickness_mm=12)
    assert t_hi > t_lo


def test_t85_higher_preheat_longer_cooling():
    """Preheat reduces ΔT, slowing the cooling cycle."""
    t_no_preheat = cooling_time_t85(Q_kJ_mm=1.5, T_0_C=25, thickness_mm=12)
    t_preheat = cooling_time_t85(Q_kJ_mm=1.5, T_0_C=150, thickness_mm=12)
    assert t_preheat > t_no_preheat


def test_t85_thick_geometry():
    t_thick = cooling_time_t85(Q_kJ_mm=1.5, T_0_C=25, thickness_mm=50, geometry="thick")
    assert math.isfinite(t_thick)


# ---------------------------------------------------------------------------
# Yurioka preheat
# ---------------------------------------------------------------------------


def test_yurioka_preheat_AISI_4140_high():
    """4140 high-CE → significant preheat needed."""
    ce = ce_yurioka({"C": 0.40, "Mn": 0.85, "Cr": 0.95, "Mo": 0.20, "Si": 0.30})
    T_pre = yurioka_preheat_C(ce, hydrogen_ppm=5.0, thickness_mm=25)
    assert math.isfinite(T_pre)
    # 4140 in 25 mm needs ≥150 °C preheat per Yurioka chart
    assert T_pre > 50.0


def test_yurioka_preheat_low_CE_no_preheat():
    """A36-like low-CE: minimal preheat required."""
    ce = ce_yurioka({"C": 0.12, "Mn": 1.0})
    T_pre = yurioka_preheat_C(ce, hydrogen_ppm=2.0, thickness_mm=10)
    # Low-CE structural steel can be welded room-temperature
    assert T_pre >= 0.0
    assert T_pre < 100.0


def test_yurioka_preheat_higher_H_higher_preheat():
    """More diffusible H → cold-crack risk up → preheat up."""
    # Use a CE that doesn't saturate at the 350 °C cap
    ce = 0.32
    T_low_H = yurioka_preheat_C(ce, hydrogen_ppm=1.0, thickness_mm=15)
    T_high_H = yurioka_preheat_C(ce, hydrogen_ppm=15.0, thickness_mm=15)
    assert T_high_H > T_low_H


def test_yurioka_preheat_capped_at_350():
    """Maximum preheat is bounded to 350 °C."""
    T_pre = yurioka_preheat_C(ce_yurioka_value=0.85, hydrogen_ppm=20, thickness_mm=100)
    assert T_pre <= 350.0


# ---------------------------------------------------------------------------
# HAZ width
# ---------------------------------------------------------------------------


def test_haz_width_basic():
    """1.5 kJ/mm, AC3=850°C, RT preheat, 12 mm plate."""
    b = haz_width_mm(Q_kJ_mm=1.5, T_peak_C=850, T_0_C=25, thickness_mm=12)
    assert math.isfinite(b)
    assert b > 0
    # Typical HAZ widths for this case: 2-6 mm
    assert 1.0 < b < 10.0


def test_haz_width_lower_isotherm_wider():
    """Lower peak T isotherm → wider HAZ (extends further from FZ)."""
    b_850 = haz_width_mm(Q_kJ_mm=1.5, T_peak_C=850, T_0_C=25, thickness_mm=12)
    b_500 = haz_width_mm(Q_kJ_mm=1.5, T_peak_C=500, T_0_C=25, thickness_mm=12)
    assert b_500 > b_850


def test_haz_width_higher_Q_wider():
    """Higher heat input → wider HAZ."""
    b_low = haz_width_mm(Q_kJ_mm=0.5, T_peak_C=850, T_0_C=25, thickness_mm=12)
    b_high = haz_width_mm(Q_kJ_mm=2.5, T_peak_C=850, T_0_C=25, thickness_mm=12)
    assert b_high > b_low
