"""Tests for the design_path endpoint."""

from __future__ import annotations

import pytest

import austenite as au


URL = "https://api-test.austenite.org/v1/design-path"


def test_design_path_happy_path(httpx_mock) -> None:
    httpx_mock.add_response(
        url=URL,
        method="POST",
        status_code=200,
        json={
            "properties": {
                "sigma_y_MPa": 1535,
                "sigma_uts_MPa": 1700,
                "elongation_pct": 11.2,
            },
            "compliance": {"spec": "ASME-VIII-Div2", "pass": True, "margin": 1.4},
            "citations": [
                {"source": "Krauss, Steels (2005)", "page": "317"},
            ],
            "trace_id": "abc123",
        },
    )

    result = au.design_path(alloy="AISI 4140", cooling_rate=10)
    assert result.properties.sigma_y_MPa == 1535
    assert result.compliance is not None
    assert result.compliance.pass_ is True
    assert len(result.citations) == 1
    assert result.trace_id == "abc123"


def test_design_path_sends_correct_payload(httpx_mock) -> None:
    httpx_mock.add_response(url=URL, method="POST", json={"properties": {}})
    au.design_path(
        alloy="AISI 4140",
        cooling_rate=20,
        T0_C=900,
        grain_size_ASTM=8,
        posterior=True,
    )
    request = httpx_mock.get_requests()[-1]
    body = request.read().decode("utf-8")
    assert "AISI 4140" in body
    assert "posterior" in body


def test_design_path_400_raises_validation(httpx_mock) -> None:
    httpx_mock.add_response(
        url=URL, method="POST", status_code=400, json={"error": "alloy required"}
    )
    with pytest.raises(au.ValidationError):
        au.design_path(cooling_rate=10)


def test_design_path_with_posterior(httpx_mock) -> None:
    httpx_mock.add_response(
        url=URL,
        method="POST",
        status_code=200,
        json={
            "properties": {"sigma_y_MPa": 1535},
            "posterior": {
                "sigma_y_MPa": {"mean": 1535, "p05": 1500, "p95": 1570, "stdev": 18}
            },
        },
    )
    result = au.design_path(alloy="AISI 4140", posterior=True)
    assert result.posterior is not None
    assert result.posterior["sigma_y_MPa"].p95 == 1570


def test_design_path_allows_extra_response_fields(httpx_mock) -> None:
    """Server-side schema additions should not break old clients."""

    httpx_mock.add_response(
        url=URL,
        method="POST",
        json={
            "properties": {"sigma_y_MPa": 1535},
            "future_field": "anything",
            "another_future_field": [1, 2, 3],
        },
    )
    result = au.design_path(alloy="AISI 4140")
    assert result.properties.sigma_y_MPa == 1535
