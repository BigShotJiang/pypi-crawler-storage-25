"""Physics-accuracy audit: AM / forming / casting / cyclic-plasticity / TMP / TTT-CCT.

Each test works a concrete numerical example by hand from a cited textbook or
the original paper and asserts the library reproduces it within an explicit
tolerance. References are given inline per test.

Sources used for hand calculations:
    * Krauss G., "Steels: Processing, Structure, and Performance" (ASM, 2005).
    * Honeycombe & Bhadeshia, "Steels: Microstructure and Properties".
    * Hosford & Caddell, "Metal Forming: Mechanics and Metallurgy".
    * Campbell J., "Complete Casting Handbook" 2nd ed. (2015).
    * Andrews K.W., JISI 203 (1965) 721.
    * Steven W., Haynes A.G., JISI 183 (1956) 349.
    * King W.E. et al., JMPT 214 (2014) 2915 (LPBF melt pool).

Three previously-documented library inaccuracies (Andrews Ae3 Cu/W coefficient,
Chaboche back-stress convention, Barlat YLD89 exponent/coefficient overloading)
have since been FIXED in source; the tests at the bottom now assert the corrected
behavior.
"""

from __future__ import annotations

import math

import pytest

from austenite import casting, cyclic_plasticity, forming, tmp, ttt_cct
from austenite import am_planner, pbf_screening


# ===========================================================================
# TTT / CCT  — critical temperatures from composition
# ===========================================================================

# AISI 4140: 0.40 C, 0.875 Mn, 0.25 Si, 0.95 Cr, 0.20 Mo (mid-range AISI).
C4140 = {"C": 0.40, "Mn": 0.875, "Si": 0.25, "Cr": 0.95, "Mo": 0.20}
# AISI 1045 plain carbon.
C1045 = {"C": 0.45, "Mn": 0.75, "Si": 0.25}


def test_steven_haynes_ms_4140():
    # Krauss / Steven-Haynes: 4140 Ms ~ 320-345 C. Brief target ~320 C.
    ms = ttt_cct.steven_haynes_Ms(C4140)
    assert ms == pytest.approx(322.2, abs=10.0)


def test_steven_haynes_ms_pure_iron_carbon():
    # Steven-Haynes: Ms = 561 - 474 C - 33 Mn - 17 Ni - 17 Cr - 21 Mo.
    # 0.20 C, all else zero -> 561 - 94.8 = 466.2 C.
    ms = ttt_cct.steven_haynes_Ms({"C": 0.20, "Mn": 0.0})
    assert ms == pytest.approx(466.2, abs=0.5)


def test_andrews_ae1_eutectoid_is_727():
    # Andrews Ae1 base constant is the eutectoid 727 C with no alloying.
    ae1 = ttt_cct.andrews_Ae1({"C": 0.8, "Mn": 0.0, "Si": 0.0})
    assert ae1 == pytest.approx(727.0, abs=0.5)


def test_andrews_ae1_4140_band():
    # Si and Cr raise Ae1, Mn/Ni lower it; 4140 ~ 735-745 C.
    ae1 = ttt_cct.andrews_Ae1(C4140)
    assert 730.0 <= ae1 <= 750.0


def test_andrews_ae3_4140_band():
    # Andrews Ae3 for medium-C low-alloy steel falls ~755-810 C.
    ae3 = ttt_cct.andrews_Ae3(C4140)
    assert 750.0 <= ae3 <= 815.0


def test_andrews_ae3_decreases_with_carbon():
    # -203*sqrt(C): Ae3 must drop monotonically as C rises.
    lo = ttt_cct.andrews_Ae3({"C": 0.10})
    hi = ttt_cct.andrews_Ae3({"C": 0.60})
    assert lo > hi


def test_lee_bs_4140_band():
    # Lee 1999 Bs for 4140 ~ 550-590 C.
    bs = ttt_cct.lee_Bs(C4140)
    assert 545.0 <= bs <= 595.0


def test_compute_ttt_temperature_ordering():
    # Physical ordering: Ae3 > Ae1 > Bs > Ms > Mf for a hardenable steel.
    r = ttt_cct.compute_ttt(C4140)
    assert r.Ae3_C > r.Ae1_C > r.Bs_C > r.Ms_C > r.Mf_C
    # Mf is defined as Ms - 215 C.
    assert r.Mf_C == pytest.approx(r.Ms_C - 215.0, abs=0.5)


def test_compute_ttt_noses_finite_positive():
    r = ttt_cct.compute_ttt(C1045)
    for t in (r.tnose_ferrite_s, r.tnose_pearlite_s, r.tnose_bainite_s):
        assert math.isfinite(t) and t > 0.0


# ===========================================================================
# CASTING  — Chvorinov / Niyama / hot tearing / feeder sizing
# ===========================================================================


def test_chvorinov_cube():
    # Cube 10 cm side: V=1000 cm3, A=600 cm2, V/A=1.6667, K=1 -> t = 2.778 min.
    t = casting.chvorinov_solidification_time(1000.0, 600.0, K_min_per_cm2=1.0)
    assert t == pytest.approx(2.7778, rel=1e-3)


def test_chvorinov_scales_with_modulus_squared():
    # Doubling V/A quadruples solidification time (t ∝ (V/A)^2).
    t1 = casting.chvorinov_solidification_time(1000.0, 600.0)
    t2 = casting.chvorinov_solidification_time(2000.0, 600.0)
    assert t2 / t1 == pytest.approx(4.0, rel=1e-6)


def test_chvorinov_sphere_slower_than_cube_same_volume():
    # Classic result: for equal volume the sphere (lowest A) solidifies slowest.
    V = 1000.0
    r = (V * 3.0 / (4.0 * math.pi)) ** (1.0 / 3.0)
    A_sphere = 4.0 * math.pi * r ** 2
    t_sphere = casting.chvorinov_solidification_time(V, A_sphere)
    t_cube = casting.chvorinov_solidification_time(V, 600.0)
    assert t_sphere > t_cube


def test_niyama_value():
    # Ny = G / sqrt(|dT/dt|). G=1 K/mm, cooling 4 K/s -> 1/2 = 0.5.
    assert casting.niyama_value(1.0, 4.0) == pytest.approx(0.5, rel=1e-9)


def test_niyama_verdict_threshold_steel():
    # Steel threshold Ny=1.0: below => porosity risk, above => pass.
    assert casting.niyama_porosity_verdict(0.5, alloy_family="steel")["passed"] is False
    assert casting.niyama_porosity_verdict(1.5, alloy_family="steel")["passed"] is True


def test_clyne_davies_csc():
    # CSC = (t99 - t90) / (t90 - t40) = (100-80)/(80-30) = 0.4.
    assert casting.clyne_davies_csc(100.0, 80.0, 30.0) == pytest.approx(0.4, rel=1e-9)


def test_pellini_hot_tearing_threshold():
    # Strain above critical 0.5% => susceptible; below => not.
    assert casting.pellini_hot_tearing(0.01)["susceptible"] is True
    assert casting.pellini_hot_tearing(0.001)["susceptible"] is False


def test_feurer_feeding_index():
    # ratio = v_shrink / v_feed = 2/1 = 2 > 1 => tear-likely.
    out = casting.feurer_feeding_index(2e-4, 1e-4)
    assert out["ratio"] == pytest.approx(2.0, rel=1e-9)
    assert out["verdict"] == "tear-likely"


def test_feeder_modulus_method():
    # Heine-Loper-Rosenthal: M_casting = 1000/600 = 1.6667 cm,
    # M_feeder = 1.2 * 1.6667 = 2.0 cm; D = 4.5*M = 9.0 cm.
    out = casting.feeder_modulus_method(1000.0, 600.0)
    assert out["M_casting_cm"] == pytest.approx(1.6667, rel=1e-3)
    assert out["M_feeder_required_cm"] == pytest.approx(2.0, rel=1e-3)
    assert out["feeder_diameter_min_cm"] == pytest.approx(9.0, rel=1e-3)


def test_rdg_pressure_drop_monotonic_in_strain_rate():
    # Δp is linear in strain rate; doubling ε̇ doubles Δp.
    p1 = casting.rdg_mushy_zone_pressure_drop(1e-3, 1e-3, 0.01)
    p2 = casting.rdg_mushy_zone_pressure_drop(1e-3, 2e-3, 0.01)
    assert p2 / p1 == pytest.approx(2.0, rel=1e-6)


# ===========================================================================
# FORMING  — yield criteria / FLD / instability / springback
# ===========================================================================


def test_hill48_reduces_to_von_mises_uniaxial():
    # r=1 isotropic, uniaxial 200 -> equivalent stress 200.
    s = forming.hill_48_yield_function(200.0, 0.0, 0.0, r_0=1, r_45=1, r_90=1)
    assert s == pytest.approx(200.0, rel=1e-9)


def test_hill48_reduces_to_von_mises_equibiaxial():
    s = forming.hill_48_yield_function(200.0, 200.0, 0.0, r_0=1, r_45=1, r_90=1)
    assert s == pytest.approx(200.0, rel=1e-9)


def test_hill48_pure_shear_isotropic():
    # Isotropic pure shear tau=100 -> sigma_eq = sqrt(3)*100 = 173.2.
    s = forming.hill_48_yield_function(0.0, 0.0, 100.0, r_0=1, r_45=1, r_90=1)
    assert s == pytest.approx(173.205, rel=1e-4)


def test_hill48_equibiaxial_high_r():
    # Normal anisotropy r=2, equibiaxial: sigma_eq = 200*sqrt(2/3) = 163.3.
    s = forming.hill_48_yield_function(200.0, 200.0, 0.0, r_0=2, r_45=2, r_90=2)
    assert s == pytest.approx(163.30, rel=1e-3)


def test_hosford_reduces_to_von_mises_a2():
    # a=2, r=1 -> von Mises. Uniaxial 200 -> 200.
    s = forming.hosford_yield_function(200.0, 0.0, r_bar=1, a=2)
    assert s == pytest.approx(200.0, rel=1e-9)


def test_hosford_a2_equibiaxial():
    s = forming.hosford_yield_function(200.0, 200.0, r_bar=1, a=2)
    assert s == pytest.approx(200.0, rel=1e-9)


def test_lankford_r_bar():
    # r̄ = (r0 + 2 r45 + r90)/4 = (1.8 + 3.0 + 2.2)/4 = 1.75.
    assert forming.lankford_r_bar(1.8, 1.5, 2.2) == pytest.approx(1.75, rel=1e-9)


def test_lankford_delta_r():
    # Δr = (r0 - 2 r45 + r90)/2 = (1.8 - 3.0 + 2.2)/2 = 0.5.
    assert forming.lankford_delta_r(1.8, 1.5, 2.2) == pytest.approx(0.5, rel=1e-9)


def test_considere_instability_strain():
    # Diffuse necking at ε = n (Considère).
    assert forming.considere_instability_strain(0.22) == pytest.approx(0.22, rel=1e-12)


def test_hill_localised_neck_plane_strain():
    # Hill 1952 plane-strain localised neck at ε = 2n.
    assert forming.hill_localised_neck_strain(0.22) == pytest.approx(0.44, rel=1e-12)


def test_fld0_keeler_structure():
    # Keeler-Brazier: FLD0(%) = (23.3 + 14.13 t)*(n/0.21). t=1, n=0.21 -> 37.43% = 0.3743.
    # Code clamps n to [0.10,0.30]; at n=0.21 it should match the canonical value.
    f = forming.fld0_keeler(1.0, 0.21)
    assert f == pytest.approx(0.3743, rel=1e-3)


def test_fld0_keeler_aluminum_half_of_steel():
    f_steel = forming.fld0_keeler(1.0, 0.21, alloy_family="steel")
    f_al = forming.fld0_keeler(1.0, 0.21, alloy_family="aluminum")
    assert f_al == pytest.approx(0.5 * f_steel, rel=1e-6)


def test_springback_angle():
    # Δθ = (3 σ_y / E)(R/t). σ_y=350 MPa, E=200 GPa, R/t=10
    # -> 3*350/200000*10 = 0.0525 rad = 3.008 deg.
    deg = forming.springback_angle_degrees(10.0, 1.0, 350.0, 200.0)
    assert deg == pytest.approx(3.008, rel=1e-2)


# ===========================================================================
# CYCLIC PLASTICITY  — Chaboche / Drucker-Prager / Cam-Clay
# ===========================================================================


def test_chaboche_saturated_back_stress():
    # α_sat = C/γ = 150000/1000 = 150 MPa.
    assert cyclic_plasticity.chaboche_saturated_back_stress(150000.0, 1000.0) == pytest.approx(150.0)


def test_chaboche_evolve_first_increment():
    # Uniaxial convention: Δα = C dε_p - γ α dp = (150000)(0.001) - 0 = 150 MPa.
    a = cyclic_plasticity.chaboche_evolve_back_stress(0.0, 0.001, 0.001, 150000.0, 1000.0)
    assert a == pytest.approx(150.0, rel=1e-9)


def test_chaboche_evolve_approaches_saturation():
    # The uniaxial evolution law dα = C dε_p - γ α dp saturates the back-stress
    # at α_sat = C/γ = 150000/1000 = 150 MPa under monotonic tension,
    # consistent with chaboche_saturated_back_stress.
    bs = [cyclic_plasticity.ChabocheBackStress(C=150000.0, gamma=1000.0)]
    eps = [i * 0.001 for i in range(300)]  # to ε_p = 0.3
    out = cyclic_plasticity.chaboche_uniaxial_simulation(eps, bs, sigma_y_0_MPa=180.0)
    assert out["alpha_total_MPa"][-1] == pytest.approx(150.0, rel=0.02)


def test_drucker_prager_hydrostatic():
    # f = α I1 + sqrt(J2) - k. At σ=0: f = -k.
    f = cyclic_plasticity.drucker_prager_yield_function(0, 0, 0, alpha=0.2309, k=12.0)
    assert f == pytest.approx(-12.0, rel=1e-6)


def test_mohr_coulomb_to_drucker_prager():
    # c=10 MPa, φ=30°: α = 2 sin30 /(√3 (3-sin30)) = 0.23094;
    # k = 6 c cos30 /(√3 (3-sin30)) = 12.0.
    out = cyclic_plasticity.mohr_coulomb_to_drucker_prager(10.0, 30.0)
    assert out["alpha"] == pytest.approx(0.23094, rel=1e-4)
    assert out["k_MPa"] == pytest.approx(12.0, rel=1e-3)


def test_cam_clay_on_critical_state_line():
    # Modified Cam-Clay: f = q^2 + M^2 p (p - p_c). On CSL at p=p_c/2, q=M p
    # => f = (M p)^2 + M^2 p (p - 2p) = M^2 p^2 - M^2 p^2 = 0.
    f = cyclic_plasticity.cam_clay_yield_function(50.0, 50.0, M=1.0, p_c_MPa=100.0)
    assert f == pytest.approx(0.0, abs=1e-6)


def test_cam_clay_inside_yield_negative():
    # Stress state inside the cap gives f < 0.
    f = cyclic_plasticity.cam_clay_yield_function(50.0, 0.0, M=1.0, p_c_MPa=100.0)
    assert f < 0.0


# ===========================================================================
# TMP  — flow stress models
# ===========================================================================


def test_misaka_low_carbon_hot_rolling_band():
    # 0.15 C steel at 1000 C (1273 K), ε=0.3, ε̇=10/s -> ~100-150 MPa
    # (typical hot-strip flow stress; Misaka returns kgf/mm² -> MPa).
    s = tmp.misaka_flow_stress_MPa(0.3, 10.0, 1273.0, C_wt_pct=0.15)
    assert 90.0 <= s <= 160.0


def test_misaka_increases_with_strain_rate():
    # σ ∝ ε̇^0.13; faster -> higher flow stress.
    lo = tmp.misaka_flow_stress_MPa(0.3, 1.0, 1273.0)
    hi = tmp.misaka_flow_stress_MPa(0.3, 100.0, 1273.0)
    # ratio = (100/1)^0.13 = 1.349.
    assert hi / lo == pytest.approx(100.0 ** 0.13, rel=1e-3)


def test_misaka_decreases_with_temperature():
    hot = tmp.misaka_flow_stress_MPa(0.3, 10.0, 1473.0)
    cool = tmp.misaka_flow_stress_MPa(0.3, 10.0, 1173.0)
    assert cool > hot


def test_hodgson_gibbs_adds_nb_drag():
    # Nb correction multiplies Misaka by (1 + 0.7 Nb exp(-10000/T)) >= base.
    base = tmp.misaka_flow_stress_MPa(0.3, 10.0, 1273.0, C_wt_pct=0.08)
    hg = tmp.hodgson_gibbs_flow_stress_MPa(0.3, 10.0, 1273.0, C_wt_pct=0.08, Nb_wt_pct=0.04)
    assert hg >= base


def test_kocks_mecking_limits():
    # σ(0) = σ_y ; σ(ε→∞) -> σ_v (saturation).
    assert tmp.kocks_mecking_flow_stress(0.0, sigma_y_MPa=100, theta_0_MPa=2000, sigma_v_MPa=300) == pytest.approx(100.0)
    assert tmp.kocks_mecking_flow_stress(10.0, sigma_y_MPa=100, theta_0_MPa=2000, sigma_v_MPa=300) == pytest.approx(300.0, rel=1e-3)


def test_prasad_efficiency():
    # η = 2m/(m+1). m=0.2 -> 0.3333 ; m=1 (Newtonian) -> 1.0.
    assert tmp.prasad_power_dissipation_efficiency(0.2) == pytest.approx(0.33333, rel=1e-4)
    assert tmp.prasad_power_dissipation_efficiency(1.0) == pytest.approx(1.0, rel=1e-9)


def test_shida_temperature_power_law():
    # σ ∝ (1273/T)^4. T=1000 C=1273.15 K -> factor ~1, σ ~ σ_0 * ε^n * (ε̇/10)^m.
    s = tmp.shida_flow_stress_MPa(0.3, 10.0, 1000.0)
    # σ_0=130, (1273/1273.15)^4≈1, 0.3^0.21≈0.776, (10/10)^0.13=1 -> ~100.9 MPa.
    assert s == pytest.approx(100.9, rel=0.05)


# ===========================================================================
# AM  — Rosenthal melt pool / normalized enthalpy / keyhole / VED
# ===========================================================================

# IN718 thermo-physical: k=11 W/mK, Cp=435 J/kgK, rho=8190 kg/m3,
# T_solidus=1533 K, T_liquidus=1609 K, alpha=13 um/m/K.
IN718 = am_planner.AlloyProperties(
    name="IN718", k_W_mK=11.0, Cp_J_kgK=435.0, rho_kg_m3=8190.0,
    T_solidus_K=1533.0, T_liquidus_K=1609.0, alpha_um_m_K=13.0,
)


def test_rosenthal_depth_in718_calibrated():
    # Docstring/King-2014 calibration: 250 W / 1200 mm/s -> ~97 um (within 10%).
    d = am_planner.rosenthal_melt_pool_depth_um(
        250.0, 1200.0, 13.0, 11.0, 1609.0, T_preheat_K=313, absorptivity=0.4,
    )
    assert d == pytest.approx(97.0, rel=0.10)


def test_rosenthal_depth_scales_with_power():
    # Depth ∝ P (linear) at fixed v.
    d1 = am_planner.rosenthal_melt_pool_depth_um(200.0, 1000.0, 13.0, 11.0, 1609.0)
    d2 = am_planner.rosenthal_melt_pool_depth_um(400.0, 1000.0, 13.0, 11.0, 1609.0)
    assert d2 / d1 == pytest.approx(2.0, rel=1e-6)


def test_rosenthal_depth_inverse_speed():
    # Depth ∝ 1/v at fixed P.
    d1 = am_planner.rosenthal_melt_pool_depth_um(250.0, 1000.0, 13.0, 11.0, 1609.0)
    d2 = am_planner.rosenthal_melt_pool_depth_um(250.0, 2000.0, 13.0, 11.0, 1609.0)
    assert d1 / d2 == pytest.approx(2.0, rel=1e-6)


def test_normalized_enthalpy_dimensionless_and_grows_with_power():
    # β rises with power, falls with speed (keyhole onset driver).
    b_lo = am_planner.normalized_enthalpy(200.0, 1200.0, 80.0, 8190.0, 435.0, 1609.0, k_W_mK=11.0)
    b_hi = am_planner.normalized_enthalpy(370.0, 600.0, 80.0, 8190.0, 435.0, 1609.0, k_W_mK=11.0)
    assert b_hi > b_lo > 0.0


def test_keyhole_probability_sigmoid_centre():
    # Sigmoid centred at β=30 -> p=0.5; far below -> ~0; far above -> ~1.
    assert am_planner.keyhole_probability(30.0) == pytest.approx(0.5, abs=1e-6)
    assert am_planner.keyhole_probability(5.0) < 0.01
    assert am_planner.keyhole_probability(60.0) > 0.99


def test_lack_of_fusion_ample_vs_deficient_depth():
    # Deep pool relative to layer -> low LoF; shallow -> high LoF.
    p_deep = am_planner.lack_of_fusion_probability(120.0, 30.0, 100.0, 80.0, melt_width_um=180.0)
    p_shallow = am_planner.lack_of_fusion_probability(15.0, 30.0, 100.0, 80.0, melt_width_um=30.0)
    assert p_deep < 0.1
    assert p_shallow > 0.9


def test_volumetric_energy_density():
    # VED = P/(v t h). 250 W / (1200 mm/s * 0.03 mm * 0.1 mm) = 69.44 J/mm3.
    ved = pbf_screening.volumetric_energy_density(250.0, 1200.0, 30.0, 100.0)
    assert ved == pytest.approx(69.44, rel=1e-3)


def test_inherent_strain_residual_stress_capped():
    # Residual stress capped at the yield cap (plastic flow cannot exceed yield).
    s = am_planner.inherent_strain_residual_stress_MPa(
        13.0, 1533.0, 313.0, E_GPa=200.0, sigma_y_cap_MPa=1000.0,
    )
    assert 0.0 < s <= 1000.0


def test_plan_build_runs_and_flags():
    # End-to-end: a coarse recipe produces per-layer predictions + a verdict.
    machine = am_planner.MachineSpec(
        laser_power_W=250.0, scan_speed_mm_s=1200.0, spot_diameter_um=80.0,
        layer_thickness_um=30.0, hatch_spacing_um=100.0, absorptivity=0.4,
    )
    plan = am_planner.plan_build(20, machine, IN718)
    assert plan.n_layers == 20
    assert len(plan.layers) == 20
    assert 0.0 <= plan.overall_pof <= 1.0


# ===========================================================================
# PREVIOUSLY-DOCUMENTED INACCURACIES — NOW FIXED IN SOURCE
# ===========================================================================


def test_andrews_ae3_cu_and_w_coefficients():
    # Canonical Andrews 1965: the +13.1 coefficient belongs to W (tungsten),
    # while Cu carries only its -20 term.
    base = ttt_cct.andrews_Ae3({"C": 0.40, "Mn": 0.8, "Si": 0.25})
    # +0.5 Cu (W-free): shift = -20 * 0.5 = -10.0 C.
    cu = ttt_cct.andrews_Ae3({"C": 0.40, "Mn": 0.8, "Si": 0.25, "Cu": 0.5})
    assert (cu - base) == pytest.approx(-10.0, abs=1e-6)
    # +0.5 W (Cu-free): shift = +13.1 * 0.5 = +6.55 C.
    w = ttt_cct.andrews_Ae3({"C": 0.40, "Mn": 0.8, "Si": 0.25, "W": 0.5})
    assert (w - base) == pytest.approx(6.55, abs=1e-6)


def test_chaboche_saturation_helper_matches_integration():
    # The uniaxial evolution law and chaboche_saturated_back_stress now share the
    # C/γ convention: the integrated α plateau equals the helper value (both 150).
    bs = [cyclic_plasticity.ChabocheBackStress(C=150000.0, gamma=1000.0)]
    eps = [i * 0.001 for i in range(300)]
    out = cyclic_plasticity.chaboche_uniaxial_simulation(eps, bs, sigma_y_0_MPa=180.0)
    helper = cyclic_plasticity.chaboche_saturated_back_stress(150000.0, 1000.0)
    assert out["alpha_total_MPa"][-1] == pytest.approx(helper, rel=0.02)


def test_barlat_yld89_normalised_to_yield():
    # A correctly-normalised plane-stress yield function returns the uniaxial
    # stress itself for a uniaxial state (isotropic a=c=1, h=1). The exponent is
    # now the distinct parameter m (8 for FCC); coefficients a,c obey a+c=2.
    s = forming.barlat_89_yield_function(200.0, 0.0, m=8.0, a=1.0, c=1.0, h=1.0)
    assert s == pytest.approx(200.0, rel=0.02)
