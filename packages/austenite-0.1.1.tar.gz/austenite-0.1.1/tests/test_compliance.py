"""Tests for the compliance.bayesian_p_pass endpoint.

Covers SA-516-70 at 400 °C, state-coercion from a deep posterior, FAIL
verdicts, and the diff_edition stub shape.
"""

from __future__ import annotations

import pytest

import austenite as au


URL_PPASS = "https://api-test.austenite.org/v1/compliance-bayesian-p-pass"


# ---------------------------------------------------------------------------
# SA-516-70 at 400 °C — a posterior comfortably above the target should PASS
# ---------------------------------------------------------------------------


def _pass_payload() -> dict:
    return {
        "spec": "SA-516-70",
        "original_spec": "ASME II-D SA-516-70",
        "T_C": 400,
        "S_allow_MPa": 109.0,
        "target_sigma_y_MPa": 380.0,
        "safety_factor": 1.5,
        "posteriorMean_MPa": 420.0,
        "posteriorStd_MPa": 18.0,
        "p_pass": 0.987,
        "margin": 2.22,
        "verdict": "PASS",
        "notes": [
            "Allowable S = 109.0 MPa @ 400 °C per ASME II-D 2021 Table 1A for SA-516-70.",
            "P(PASS) computed by Gaussian tail integral, z = 2.222.",
        ],
        "citations": [
            {
                "source": "ASME BPVC Section II Part D, 2021 Edition, Table 1A",
                "note": "Allowable stress lookup for SA-516-70",
            },
        ],
    }


def test_bayesian_p_pass_happy_path_sa_516_70_at_400C(httpx_mock) -> None:
    httpx_mock.add_response(url=URL_PPASS, method="POST", json=_pass_payload())
    verdict = au.compliance.bayesian_p_pass(
        state={"posteriorMean": 420.0, "posteriorStd": 18.0},
        spec="ASME II-D SA-516-70",
        T_C=400,
        target_sigma_y_MPa=380,
    )
    assert verdict.p_pass == 0.987
    assert verdict.verdict == "PASS"
    assert verdict.S_allow_MPa == 109.0
    assert any("Allowable S = 109.0 MPa @ 400" in n for n in verdict.notes)
    assert any("ASME" in (c.source or "") for c in verdict.citations)


# ---------------------------------------------------------------------------
# FAIL verdict when the posterior is below the target
# ---------------------------------------------------------------------------


def test_bayesian_p_pass_fail_verdict(httpx_mock) -> None:
    payload = _pass_payload()
    payload.update({
        "posteriorMean_MPa": 320.0,
        "p_pass": 0.001,
        "verdict": "FAIL",
        "margin": -3.3,
    })
    httpx_mock.add_response(url=URL_PPASS, method="POST", json=payload)
    verdict = au.compliance.bayesian_p_pass(
        state={"posteriorMean": 320.0, "posteriorStd": 18.0},
        spec="SA-516-70",
        T_C=400,
        target_sigma_y_MPa=380,
    )
    assert verdict.p_pass < 0.5
    assert verdict.verdict == "FAIL"


# ---------------------------------------------------------------------------
# MARGINAL verdict for in-between P(PASS)
# ---------------------------------------------------------------------------


def test_bayesian_p_pass_marginal_verdict(httpx_mock) -> None:
    payload = _pass_payload()
    payload.update({"p_pass": 0.72, "verdict": "MARGINAL"})
    httpx_mock.add_response(url=URL_PPASS, method="POST", json=payload)
    v = au.compliance.bayesian_p_pass(
        state={"posteriorMean": 380.0, "posteriorStd": 30.0},
        spec="SA-516-70",
        T_C=400,
        target_sigma_y_MPa=380,
    )
    assert v.verdict == "MARGINAL"
    assert 0.5 <= v.p_pass < 0.95


# ---------------------------------------------------------------------------
# State can be coerced from a deep posterior model
# ---------------------------------------------------------------------------


def test_bayesian_p_pass_accepts_deep_posterior_state(httpx_mock) -> None:
    httpx_mock.add_response(url=URL_PPASS, method="POST", json=_pass_payload())
    post = au.BayesianCalphadDeepResult(
        dataset="Hammar 1979",
        posteriorMean=[420.0, 2500.0, -800.0],
        posteriorStd=[18.0, 410.0, 310.0],
    )
    verdict = au.compliance.bayesian_p_pass(
        state=post,
        spec="SA-516-70",
        T_C=400,
        target_sigma_y_MPa=380,
    )
    assert verdict.p_pass == 0.987
    req = httpx_mock.get_requests()[-1]
    body = req.read().decode("utf-8")
    # First param's mean (420.0) is what should be sent through
    assert "420.0" in body


# ---------------------------------------------------------------------------
# State can be a raw samples list
# ---------------------------------------------------------------------------


def test_bayesian_p_pass_accepts_samples_state(httpx_mock) -> None:
    httpx_mock.add_response(url=URL_PPASS, method="POST", json=_pass_payload())
    samples = [410.0, 420.0, 425.0, 430.0, 415.0]
    verdict = au.compliance.bayesian_p_pass(
        state={"samples": samples},
        spec="SA-516-70",
        T_C=400,
        target_sigma_y_MPa=380,
    )
    assert verdict.verdict == "PASS"
    req = httpx_mock.get_requests()[-1]
    body = req.read().decode("utf-8")
    assert "samples" in body


# ---------------------------------------------------------------------------
# 400 -> ValidationError (bad spec)
# ---------------------------------------------------------------------------


def test_bayesian_p_pass_unknown_spec_raises(httpx_mock) -> None:
    httpx_mock.add_response(
        url=URL_PPASS, method="POST", status_code=400,
        json={"error": "unknown_or_out_of_range_spec", "message": "spec='SA-1234' unknown"},
    )
    with pytest.raises(au.ValidationError):
        au.compliance.bayesian_p_pass(
            state={"posteriorMean": 420.0, "posteriorStd": 18.0},
            spec="SA-1234",
            T_C=400,
            target_sigma_y_MPa=380,
        )


# ---------------------------------------------------------------------------
# Convenience `check()` returns bool
# ---------------------------------------------------------------------------


def test_compliance_check_returns_bool(httpx_mock) -> None:
    httpx_mock.add_response(url=URL_PPASS, method="POST", json=_pass_payload())
    ok = au.compliance.check(
        state={"posteriorMean": 420.0, "posteriorStd": 18.0},
        spec="SA-516-70",
        T_C=400,
        target_sigma_y_MPa=380,
    )
    assert ok is True


def test_compliance_check_threshold(httpx_mock) -> None:
    """Custom threshold gets enforced — p_pass=0.72 fails threshold=0.95 but passes 0.5."""

    payload = _pass_payload()
    payload.update({"p_pass": 0.72, "verdict": "MARGINAL"})
    httpx_mock.add_response(url=URL_PPASS, method="POST", json=payload)
    payload2 = dict(payload)
    httpx_mock.add_response(url=URL_PPASS, method="POST", json=payload2)
    high = au.compliance.check(
        state={"posteriorMean": 380.0, "posteriorStd": 30.0},
        spec="SA-516-70",
        T_C=400,
        target_sigma_y_MPa=380,
    )
    low = au.compliance.check(
        state={"posteriorMean": 380.0, "posteriorStd": 30.0},
        spec="SA-516-70",
        T_C=400,
        target_sigma_y_MPa=380,
        threshold=0.5,
    )
    assert high is False
    assert low is True


# ---------------------------------------------------------------------------
# diff_edition: live local-corpus implementation (moat 5)
# ---------------------------------------------------------------------------


def test_diff_edition_live_returns_diff_report() -> None:
    diff = au.compliance.diff_edition("ASME II-D", "2021", "2025")
    assert isinstance(diff, au.compliance.DiffReport)
    assert diff.spec == "ASME II-D"
    assert diff.from_ == "2021"
    assert diff.to_ == "2025"
    # 2023 brought 2 changes + 2025 brought 3 changes = 5 total
    assert len(diff) >= 5
    # 2021 (the baseline) is excluded
    assert all(ch.kind in {"formula", "parameter", "method", "scope", "editorial"}
               for ch in diff.changes)
