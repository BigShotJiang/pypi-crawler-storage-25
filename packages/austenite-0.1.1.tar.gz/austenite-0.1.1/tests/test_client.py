"""Tests for the low-level Client + retry / exception translation."""

from __future__ import annotations

import httpx
import pytest

import austenite as au
from austenite._client import Client


def _endpoint(path: str = "/v1/design-path") -> str:
    return f"https://api-test.austenite.org{path}"


# ---------------------------------------------------------------------------
# Happy path: 200 returns parsed body.
# ---------------------------------------------------------------------------


def test_post_returns_response_on_200(httpx_mock) -> None:
    httpx_mock.add_response(
        url=_endpoint(),
        method="POST",
        json={"properties": {"sigma_y_MPa": 1535}},
        status_code=200,
    )
    client = Client()
    resp = client.post("/v1/design-path", json={"alloy": "AISI 4140"})
    assert resp.status_code == 200
    assert resp.json()["properties"]["sigma_y_MPa"] == 1535


# ---------------------------------------------------------------------------
# 400 -> ValidationError (NOT retried)
# ---------------------------------------------------------------------------


def test_400_raises_validation_error(httpx_mock) -> None:
    httpx_mock.add_response(
        url=_endpoint(),
        method="POST",
        json={"error": "bad composition"},
        status_code=400,
    )
    client = Client()
    with pytest.raises(au.ValidationError) as exc_info:
        client.post("/v1/design-path", json={})
    assert exc_info.value.status_code == 400
    assert "bad composition" in str(exc_info.value)


# ---------------------------------------------------------------------------
# 429 -> RateLimitError
# ---------------------------------------------------------------------------


def test_429_raises_rate_limit_error(httpx_mock) -> None:
    httpx_mock.add_response(
        url=_endpoint(),
        method="POST",
        json={"error": "slow down"},
        status_code=429,
    )
    client = Client()
    with pytest.raises(au.RateLimitError):
        client.post("/v1/design-path", json={})


# ---------------------------------------------------------------------------
# 500 -> EngineError + retry until exhausted
# ---------------------------------------------------------------------------


def test_500_retries_and_raises_engine_error(httpx_mock) -> None:
    # Two retries (the autouse fixture sets max_retries=2). Both must fail
    # to trigger the final exception.
    for _ in range(2):
        httpx_mock.add_response(
            url=_endpoint(),
            method="POST",
            json={"error": "engine boom"},
            status_code=500,
        )
    client = Client(backoff_factor=0.0)  # no real wait in tests
    with pytest.raises(au.EngineError):
        client.post("/v1/design-path", json={})


def test_500_then_200_succeeds_after_retry(httpx_mock) -> None:
    httpx_mock.add_response(
        url=_endpoint(),
        method="POST",
        status_code=500,
        json={"error": "transient"},
    )
    httpx_mock.add_response(
        url=_endpoint(),
        method="POST",
        status_code=200,
        json={"properties": {"sigma_y_MPa": 1500}},
    )
    client = Client(backoff_factor=0.0)
    resp = client.post("/v1/design-path", json={})
    assert resp.status_code == 200


# ---------------------------------------------------------------------------
# Network timeout -> NetworkError
# ---------------------------------------------------------------------------


def test_network_timeout_raises_network_error(httpx_mock) -> None:
    httpx_mock.add_exception(httpx.ConnectTimeout("timed out"))
    httpx_mock.add_exception(httpx.ConnectTimeout("timed out"))
    client = Client(backoff_factor=0.0)
    with pytest.raises(au.NetworkError):
        client.post("/v1/design-path", json={})


# ---------------------------------------------------------------------------
# Headers: User-Agent + Idempotency-Key are attached
# ---------------------------------------------------------------------------


def test_headers_include_user_agent_and_idempotency_key(httpx_mock) -> None:
    httpx_mock.add_response(
        url=_endpoint(),
        method="POST",
        json={"properties": {}},
        status_code=200,
    )
    client = Client()
    client.post("/v1/design-path", json={})

    request = httpx_mock.get_requests()[-1]
    ua = request.headers.get("User-Agent", "")
    assert ua.startswith("austenite-py/0.1.0")
    assert "Idempotency-Key" in request.headers


def test_api_key_attached_as_bearer(httpx_mock) -> None:
    au.set_api_key("sk-test-123")
    httpx_mock.add_response(
        url=_endpoint(),
        method="POST",
        json={"properties": {}},
        status_code=200,
    )
    client = Client()
    client.post("/v1/design-path", json={})
    request = httpx_mock.get_requests()[-1]
    assert request.headers.get("Authorization") == "Bearer sk-test-123"


# ---------------------------------------------------------------------------
# Async client
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_async_client_happy_path(httpx_mock) -> None:
    httpx_mock.add_response(
        url=_endpoint(),
        method="POST",
        json={"properties": {"sigma_y_MPa": 1500}},
        status_code=200,
    )
    async with au.AsyncClient() as client:
        resp = await client.post("/v1/design-path", json={"alloy": "AISI 4140"})
    assert resp.status_code == 200
    assert resp.json()["properties"]["sigma_y_MPa"] == 1500


@pytest.mark.asyncio
async def test_async_client_translates_400(httpx_mock) -> None:
    httpx_mock.add_response(
        url=_endpoint(),
        method="POST",
        json={"error": "bad"},
        status_code=400,
    )
    async with au.AsyncClient() as client:
        with pytest.raises(au.ValidationError):
            await client.post("/v1/design-path", json={})


# ---------------------------------------------------------------------------
# Config setters wire through.
# ---------------------------------------------------------------------------


def test_set_api_url_takes_effect() -> None:
    au.set_api_url("https://custom.example.com/")
    assert au.get_default_client()._api_url == "https://custom.example.com"


def test_set_max_retries_rejects_zero() -> None:
    with pytest.raises(ValueError):
        au.set_max_retries(0)
