"""Tests for the JIS G3106 (SM490 etc.) compliance checker."""

from __future__ import annotations

import pytest

import austenite as au
from austenite.compliance_standards import StandardVerdict, jis_g3106


def test_jis_g3106_pass_default_grade_sm490a() -> None:
    v = jis_g3106.check(
        composition={"C": 0.18, "Si": 0.35, "Mn": 1.20, "P": 0.020, "S": 0.015},
        mechanical={"sigma_y_MPa": 360, "sigma_uts_MPa": 530,
                    "elongation_pct": 25, "CVN_J_at_0C": 50},
    )
    assert isinstance(v, StandardVerdict)
    assert v.passed is True
    assert v.spec_id == "JIS G3106"
    assert "SM490A" in v.citation


def test_jis_g3106_fail_uts_too_low_sm490a() -> None:
    v = jis_g3106.check(
        composition={"C": 0.18, "Mn": 1.20, "P": 0.020, "S": 0.015},
        mechanical={"sigma_y_MPa": 360, "sigma_uts_MPa": 450,
                    "elongation_pct": 25, "CVN_J_at_0C": 50},
        grade="SM490A",
    )
    assert v.passed is False
    assert any("sigma_uts_MPa" in f and "below min 490" in f for f in v.failed_items)


def test_jis_g3106_pass_sm570_grade() -> None:
    v = jis_g3106.check(
        composition={"C": 0.16, "Si": 0.35, "Mn": 1.40, "P": 0.020, "S": 0.010},
        mechanical={"sigma_y_MPa": 480, "sigma_uts_MPa": 600,
                    "elongation_pct": 21, "CVN_J_at_-5C": 50},
        grade="SM570",
    )
    assert v.passed is True
    assert "SM570" in v.citation


def test_jis_g3106_unknown_grade_raises() -> None:
    with pytest.raises(ValueError, match="grade 'SM999' unknown"):
        jis_g3106.check(grade="SM999")


def test_jis_g3106_list_grades_has_all_five() -> None:
    grades = set(jis_g3106.list_grades())
    assert {"SM400A", "SM490A", "SM490YA", "SM520B", "SM570"}.issubset(grades)
