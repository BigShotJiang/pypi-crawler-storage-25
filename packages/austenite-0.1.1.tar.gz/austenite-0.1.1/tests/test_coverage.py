"""Tests for au.coverage — alloy / system / temperature coverage queries."""

from __future__ import annotations

import pytest

import austenite as au
from austenite.coverage import (
    CoverageReport,
    SystemRange,
    check_alloy,
    list_supported_alloys,
    system_temperature_range,
)


# ---------------------------------------------------------------------------
# check_alloy
# ---------------------------------------------------------------------------


def test_check_alloy_inconel_718_supports_calphad_and_kinetics():
    """Inconel 718 should resolve to the Ni-Cr-Al-Ti system."""

    r = check_alloy("Inconel 718")
    assert isinstance(r, CoverageReport)
    assert r.calphad is True
    assert r.kinetics is True
    # citation field set when CALPHAD support is present
    assert r.citation


def test_check_alloy_returns_report_for_unknown_alloy():
    """Unknown alloy should still produce a report (not raise)."""

    r = check_alloy("UnknownAlloyXYZ")
    assert isinstance(r, CoverageReport)
    # Unknown alloy — most checks fail, but doesn't crash.
    assert r.calphad is False
    # Should be honest about the gap.
    assert any("not yet catalogued" in g.lower() or "no " in g.lower() for g in r.gaps)


def test_check_alloy_markdown_renders_yes_or_no_table():
    r = check_alloy("AISI 4140")
    md = r.markdown()
    assert "Coverage for" in md
    assert "| Aspect |" in md
    # Either 'yes' or 'no' rows must appear.
    assert "yes" in md.lower() or "no" in md.lower()


def test_check_alloy_to_dict_round_trip_json():
    import json
    r = check_alloy("Ti-6Al-4V")
    d = r.to_dict()
    blob = json.dumps(d)
    assert "Ti-6Al-4V" in blob


# ---------------------------------------------------------------------------
# system_temperature_range
# ---------------------------------------------------------------------------


def test_system_temperature_range_fe_cr_ni():
    rng = system_temperature_range("Fe-Cr-Ni")
    assert isinstance(rng, SystemRange)
    # bounded between ASME II-D-relevant temperatures.
    assert 273 <= rng.T_min_K <= 500
    assert 1700 <= rng.T_max_K <= 2000
    assert rng.citation


def test_system_temperature_range_unpacks_as_tuple():
    """The dataclass should iter so users can write ``lo, hi = ...``."""

    T_lo, T_hi = system_temperature_range("Al-Cu")
    assert T_lo < T_hi
    assert T_lo > 0


def test_system_temperature_range_unknown_raises():
    with pytest.raises(NotImplementedError):
        system_temperature_range("Ru-Os-Ir")


def test_system_temperature_range_case_insensitive():
    """fe-cr-ni and Fe-Cr-Ni should give the same answer."""

    a = system_temperature_range("fe-cr-ni")
    b = system_temperature_range("Fe-Cr-Ni")
    assert a.T_min_K == b.T_min_K and a.T_max_K == b.T_max_K


# ---------------------------------------------------------------------------
# list_supported_alloys
# ---------------------------------------------------------------------------


def test_list_supported_alloys_returns_a_nonempty_list():
    names = list_supported_alloys()
    assert isinstance(names, list)
    # alloys.json ships ≥1 alloy
    assert len(names) >= 1


# ---------------------------------------------------------------------------
# Lazy load via au.* namespace
# ---------------------------------------------------------------------------


def test_lazy_namespace():
    assert hasattr(au, "coverage")
    assert callable(au.coverage.check_alloy)
