"""Tests for au.multi_nozzle_vessel — WRC 107/297 + linear superposition."""

from __future__ import annotations

import pytest

import austenite as au
from austenite.multi_nozzle_vessel import (
    MultiNozzleResult,
    NozzleStress,
    analyze,
)


# ---------------------------------------------------------------------------
# Standard 3-nozzle case (closely follows the prompt example)
# ---------------------------------------------------------------------------


def _three_nozzle_input():
    return {
        "vessel": {
            "type": "cylinder",
            "OD_mm": 2000,
            "wall_mm": 25,
            "material": "SA-516-70",
        },
        "nozzles": [
            {"id": "N1", "x_mm": 0, "y_mm": 0, "OD_mm": 100, "wall_mm": 10,
             "loads": {"F_radial": 50, "M_long": 3000}},
            {"id": "N2", "x_mm": 800, "y_mm": 0, "OD_mm": 80, "wall_mm": 8,
             "loads": {"F_radial": 30, "M_long": 2000}},
            {"id": "N3", "x_mm": 0, "y_mm": 500, "OD_mm": 60, "wall_mm": 6,
             "loads": {"F_radial": 20, "M_long": 1500}},
        ],
        "T_C": 400.0,
        "P_MPa": 2.5,
    }


def test_analyze_returns_one_nozzlestress_per_input():
    out = analyze(**_three_nozzle_input())
    assert isinstance(out, MultiNozzleResult)
    assert set(out.per_nozzle_stresses.keys()) == {"N1", "N2", "N3"}
    for ns in out.per_nozzle_stresses.values():
        assert isinstance(ns, NozzleStress)
        assert ns.membrane_MPa >= 0
        assert ns.bending_MPa >= 0
        assert ns.peak_MPa >= ns.membrane_MPa


def test_analyze_interaction_matrix_is_NxN_symmetric_shape():
    """Interaction matrix should be n_nozzles × n_nozzles."""

    out = analyze(**_three_nozzle_input())
    n = len(out.per_nozzle_stresses)
    assert len(out.interaction_factors) == n
    for row in out.interaction_factors:
        assert len(row) == n
    # Diagonal is 0 (a nozzle doesn't add to itself).
    for i in range(n):
        assert out.interaction_factors[i][i] == 0.0


def test_analyze_superposition_peak_dominates_base_peak():
    """Final superposed peak ≥ base peak (we're adding contributions)."""

    out = analyze(**_three_nozzle_input())
    for nid, ns in out.per_nozzle_stresses.items():
        assert out.superposition_peak_MPa[nid] >= ns.peak_MPa - 1e-9


def test_analyze_warns_on_close_pitched_nozzles():
    """Two nozzles 200 mm apart on a 2000 OD × 25 wall vessel:
    influence radius = 2.5·√(R·t) = 2.5·√(987.5*25) ≈ 393 mm
    → 200 < 393 → warning."""

    inp = _three_nozzle_input()
    inp["nozzles"] = [
        {"id": "A", "x_mm": 0, "y_mm": 0, "OD_mm": 80, "wall_mm": 8,
         "loads": {"F_radial": 30, "M_long": 2000}},
        {"id": "B", "x_mm": 200, "y_mm": 0, "OD_mm": 80, "wall_mm": 8,
         "loads": {"F_radial": 30, "M_long": 2000}},
    ]
    out = analyze(**inp)
    blob = " ".join(out.warnings).lower()
    assert "fem" in blob or "conservative" in blob


def test_analyze_wrc_check_pass_or_fail_for_each_nozzle():
    out = analyze(**_three_nozzle_input())
    for nid in out.per_nozzle_stresses:
        assert out.WRC_check[nid] in ("PASS", "FAIL")


def test_analyze_recommends_pad_for_failing_nozzle():
    """Crank loads way up so peak exceeds 3·S → pad recommended."""

    inp = _three_nozzle_input()
    for n in inp["nozzles"]:
        n["loads"] = {"F_radial": 5_000_000, "M_long": 500_000_000}
    inp["P_MPa"] = 30.0
    out = analyze(**inp)
    # At least one nozzle should fail and get a pad recommendation.
    assert any(v == "FAIL" for v in out.WRC_check.values())
    assert len(out.recommended_pad_sizes) >= 1
    rec = out.recommended_pad_sizes[0]
    assert "pad_OD_mm" in rec
    assert "pad_thickness_mm" in rec


def test_analyze_unknown_vessel_type_raises_not_implemented():
    inp = _three_nozzle_input()
    inp["vessel"]["type"] = "sphere"
    with pytest.raises(NotImplementedError):
        analyze(**inp)


def test_analyze_empty_nozzles_raises():
    with pytest.raises(ValueError):
        analyze(
            vessel={"type": "cylinder", "OD_mm": 2000, "wall_mm": 25,
                    "material": "SA-516-70"},
            nozzles=[],
        )


# ---------------------------------------------------------------------------
# DataFrame export
# ---------------------------------------------------------------------------


def test_to_dataframe_returns_pd_dataframe_when_pandas_installed():
    pd = pytest.importorskip("pandas")
    out = analyze(**_three_nozzle_input())
    df = out.to_dataframe()
    assert isinstance(df, pd.DataFrame)
    assert len(df) == 3
    for col in ("nozzle_id", "membrane_MPa", "bending_MPa", "peak_MPa", "check"):
        assert col in df.columns


# ---------------------------------------------------------------------------
# Citations
# ---------------------------------------------------------------------------


def test_citations_include_wrc_107_and_bijlaard():
    out = analyze(**_three_nozzle_input())
    cits = " ".join(out.citations)
    assert "WRC Bulletin 107" in cits
    assert "Bijlaard" in cits


# ---------------------------------------------------------------------------
# Lazy load via au.* namespace
# ---------------------------------------------------------------------------


def test_lazy_namespace():
    assert hasattr(au, "multi_nozzle_vessel")
    assert callable(au.multi_nozzle_vessel.analyze)
