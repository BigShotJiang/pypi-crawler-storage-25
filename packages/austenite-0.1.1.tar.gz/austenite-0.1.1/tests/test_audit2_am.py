"""Physics-accuracy audit of the AM qualification engine (audit pass 2).

Target modules
--------------
* ``src/austenite/am.py``           — public ``au.am.qualification`` surface
* ``src/austenite/_am_native.py``   — offline pure-Python physics pipeline

Every test exercises the **native** pipeline (``backend="native"`` or a
direct ``austenite._am_native`` call) so nothing hits the remote HTTP API
and the suite runs fully offline.

Each test validates one formula against its cited reference and a
hand-worked numerical example, with an explicit tolerance (AM correlations
are noisy, so 5-15% is used for the empirical fits).

An earlier audit pass (audit 2) flagged five confirmed inaccuracies; four
of them have since been FIXED in ``_am_native.py``. The tests below now
assert the CORRECTED behaviour and all pass. The notes record what changed
so the history is auditable. Per the audit brief the source is NOT modified
by this test file.

Fixed inaccuracies (file:line — what changed)
---------------------------------------------
1.  ``_am_native.py:717`` — King-Khairallah normalised enthalpy is now the
    dimensionally-correct Rubenchik/King 2014 form
    ``ΔH/h_s = ηP / (ρCp Tm · √(π α v r³))``. For the IN718 285 W / 960 mm/s
    baseline it gives ~17 (below the 30 keyhole threshold), so good prints
    are no longer mislabelled "keyhole". (Previously ``ηP/(π r² v √(α/v))``
    was 1/√m-dimensioned and fired the keyhole branch unconditionally.)
2.  ``_am_native.py:836`` — ``hv_to_hrc`` is refit to ASTM E140 anchors
    (HV240→20.3, HV400→39.8, HV600→56.2, HV800→64.0); the low branch
    (HV<240) now uses ``(HV−100)/7.0`` (≈20 HRC at HV240, continuous).
3.  ``_am_native.py:651-661`` — Rosenthal cooling rate is now the analytic
    centreline result ``Ṫ = 2πk v (T_melt−T0)² / (ηP)``: it FALLS with laser
    power (larger pool ⇒ slower quench) and RISES with travel speed.
4.  ``_am_native.py:861`` — Pavlina-Van Tyne σ_UTS now uses the published
    2008 fit ``σ_UTS = −99.8 + 3.734·HV`` (HV400 → 1394 MPa); the prior
    ``3.0·HV`` approximation ran ~10-15 % low.
5.  ``_am_native.py:530-532`` — Goldak/Eagar-Tsai distributed sources are
    under-scaled: at standard LPBF power the peak T stays below T_melt so
    they predict ZERO melt pool (only ``model="rosenthal"`` melts). The
    Goldak halves also sum to ``2·η`` total power (front ``f`` + rear
    ``2−f``); that 2× is the documented Goldak fraction convention but the
    base single-ellipsoid prefactor is too small to compensate.
"""

from __future__ import annotations

import math

import pytest

pytest.importorskip("numpy")

from austenite import _am_native as nat


# ===========================================================================
# 1. Volumetric Energy Density  VED = P / (v·h·t)
# ===========================================================================


def test_ved_closed_form_and_scaling() -> None:
    """VED = P/(v·h·t) J/mm³ — exact, and scales ∝P, ∝1/v, ∝1/h, ∝1/t."""
    # IN718 baseline: 285 W, 960 mm/s, 0.11 mm hatch, 0.04 mm layer.
    got = nat.volumetric_energy_density(285.0, 960.0, 0.11, 0.04)
    assert math.isclose(got, 285.0 / (960.0 * 0.11 * 0.04), rel_tol=1e-12)
    assert math.isclose(got, 67.472, abs_tol=0.01)
    # Doubling power doubles VED; doubling speed halves it.
    assert math.isclose(
        nat.volumetric_energy_density(570, 960, 0.11, 0.04), 2 * got, rel_tol=1e-12
    )
    assert math.isclose(
        nat.volumetric_energy_density(285, 1920, 0.11, 0.04), got / 2, rel_tol=1e-12
    )


def test_ved_guards_nonpositive_denominator() -> None:
    """Zero/negative speed → 0 (no divide-by-zero blow-up)."""
    assert nat.volumetric_energy_density(285.0, 0.0, 0.11, 0.04) == 0.0
    assert nat.volumetric_energy_density(285.0, -5.0, 0.11, 0.04) == 0.0


# ===========================================================================
# 2. Rosenthal 1946 moving point source  ΔT = ηP/(2πkR)·exp(−v(R+ξ)/2α)
# ===========================================================================


def _in718_rosenthal_kwargs() -> dict:
    # IN718 thermophysics from the alloy library.
    return dict(
        alpha_m2_s=30.0 / (8190.0 * 540.0),
        k_W_mK=30.0,
        T_m_C=1336.0,
        T_0_C=80.0,
        eta=0.40,
        spot_mm=0.080,
    )


def test_rosenthal_decays_to_T0_far_field() -> None:
    """ΔT(R→∞)→0: a moving point source decays exponentially to the bed T."""
    p = nat.AMProcessInput(
        P=285, v=960, eta=0.4, T0=80, Tmelt=1336, k=30, rho=8190, Cp=540, spotMm=0.08
    )
    assert abs(nat.rosenthal_T(p, 5e-3, 5e-3, 5e-3) - p.T0) < 1.0


def test_rosenthal_singularity_is_clipped() -> None:
    """At R→0 the 1/R singularity is clamped to T_melt + 200 °C."""
    p = nat.AMProcessInput(
        P=285, v=960, eta=0.4, T0=80, Tmelt=1336, k=30, rho=8190, Cp=540, spotMm=0.08
    )
    assert math.isclose(nat.rosenthal_T(p, 0.0, 0.0, 0.0), 1336.0 + 200.0, abs_tol=1e-6)


def test_rosenthal_meltpool_length_scales_up_with_power() -> None:
    """Melt-pool length ∝ P (Rosenthal ΔT ∝ P at a fixed point)."""
    kw = _in718_rosenthal_kwargs()
    L_lo = nat.meltpool_rosenthal(P_W=200, v_mm_s=960, **kw)["L_mm"]
    L_hi = nat.meltpool_rosenthal(P_W=400, v_mm_s=960, **kw)["L_mm"]
    assert L_hi > L_lo
    # Doubling P roughly doubles L for the point source (within 15%).
    assert math.isclose(L_hi, 2.0 * L_lo, rel_tol=0.15)


def test_rosenthal_meltpool_length_scales_down_with_speed() -> None:
    """Melt-pool length decreases as scan speed rises (faster → less heat in)."""
    kw = _in718_rosenthal_kwargs()
    L_slow = nat.meltpool_rosenthal(P_W=285, v_mm_s=600, **kw)["L_mm"]
    L_fast = nat.meltpool_rosenthal(P_W=285, v_mm_s=1500, **kw)["L_mm"]
    assert L_fast < L_slow


def test_rosenthal_promoppatum_2017_in718_length() -> None:
    """IN718 @285 W / 960 mm/s → L ≈ 0.45 mm (Promoppatum 2017, ±15%)."""
    L = nat.meltpool_rosenthal(P_W=285, v_mm_s=960, **_in718_rosenthal_kwargs())["L_mm"]
    assert math.isclose(L, 0.45, rel_tol=0.15), f"L={L:.3f} mm vs 0.45 mm"


def test_cooling_rate_increases_with_scan_speed() -> None:
    """Cooling rate rises with v (Ṫ ∝ v·(T−T0)²/P) — sign is correct in v."""
    kw = _in718_rosenthal_kwargs()
    cr_slow = nat.meltpool_rosenthal(P_W=285, v_mm_s=600, **kw)["coolingRate_Ks"]
    cr_fast = nat.meltpool_rosenthal(P_W=285, v_mm_s=1500, **kw)["coolingRate_Ks"]
    assert cr_fast > cr_slow


def test_cooling_rate_falls_with_power() -> None:
    """Cooling rate FALLS as power rises: the analytic centreline rate is
    Ṫ = 2πk·v·(T_melt−T0)²/(ηP), so doubling η·P halves Ṫ (larger melt pool
    ⇒ slower quench).

    Analytic rates for IN718 @960 mm/s, ΔT = T_melt−T0 = 1256 K, η=0.40:
        P=200 → 3.57e6,  P=400 → 1.78e6 K/s (monotonic ↓, exact factor 2).
    """
    kw = _in718_rosenthal_kwargs()
    cr_200 = nat.meltpool_rosenthal(P_W=200, v_mm_s=960, **kw)["coolingRate_Ks"]
    cr_400 = nat.meltpool_rosenthal(P_W=400, v_mm_s=960, **kw)["coolingRate_Ks"]
    assert cr_400 < cr_200
    # Ṫ ∝ 1/P, so halving the inverse: cr_400 ≈ cr_200 / 2.
    assert math.isclose(cr_400, cr_200 / 2.0, rel_tol=1e-9)


# ===========================================================================
# 3. King-Khairallah keyhole / process-window classifier
# ===========================================================================


def test_normalized_enthalpy_is_physical_below_keyhole_threshold() -> None:
    """The ΔH/h_s formula is now the dimensionally-correct Rubenchik/King 2014
    form ``ΔH/h_s = η·P / (ρ·Cp·Tm · √(π·α·v·r³))``, which is dimensionless
    and ~O(1-30) for realistic LPBF, instead of the old 1/√m-dimensioned
    ``ηP/(π r² v √(α/v))`` that was ~50-80× too large.

    For the IN718 285 W / 960 mm/s baseline it evaluates to ~17 — physical
    and below the keyhole threshold of 30 — so good prints are no longer
    mislabelled 'keyhole' (verified in the next test).
    """
    lib = nat.AM_ALLOY_LIBRARY["IN718"]
    p = nat.AMProcessInput(
        P=285, v=960, eta=lib["defaultEta"], T0=100,
        Tmelt=lib["Tmelt"], k=lib["k"], rho=lib["rho"], Cp=lib["Cp"], spotMm=0.08,
    )
    r_m = (p.spotMm / 2.0) * 1e-3
    v_ms = p.v * 1e-3
    a = p.alpha()
    denom = (p.rho * p.Cp * p.Tmelt) * math.sqrt(math.pi * a * v_ms * r_m ** 3)
    norm = (p.eta * p.P) / denom
    # Corrected ΔH/h_s is physical: O(1-30), and well below the old ~1500.
    assert norm < 100.0, f"normEnthalpy={norm:.1f} — keyhole formula scale changed"
    assert 1.0 < norm < 30.0, f"normEnthalpy={norm:.1f} outside the good-print band"


def test_optimal_lpbf_not_misclassified_as_keyhole() -> None:
    """With the corrected normalised-enthalpy formula, standard good IN718
    LPBF prints no longer classify as 'keyhole'.

    The Promoppatum 2017 IN718 baseline (285 W, 960 mm/s, VED≈67 J/mm³ —
    squarely inside the accepted 30-120 window) is a known *good* print and
    should fall in conduction / optimal / lack-of-fusion, never 'keyhole'.
    """
    res = nat.run_qualification_native(
        alloy="IN718", power_W=285, velocity_mm_s=960, hatch_mm=0.11, layer_mm=0.04
    )
    region = res["meltpool"]["region"]
    assert region != "keyhole"
    assert region in {"conduction", "optimal", "lack-of-fusion"}


def test_classifier_returns_valid_label() -> None:
    """Whatever the verdict, it is one of the five documented regions."""
    res = nat.run_qualification_native(
        alloy="SS316L", power_W=195, velocity_mm_s=800, hatch_mm=0.12, layer_mm=0.03
    )
    assert res["meltpool"]["region"] in {
        "keyhole", "lack-of-fusion", "balling", "conduction", "optimal",
    }


# ===========================================================================
# 4. Kurz-Fisher 1998 G/V_s solidification-morphology classifier
# ===========================================================================


def test_kurz_fisher_morphology_boundaries() -> None:
    """G/V_s thresholds: >100 planar, 1-100 cellular, 0.01-1 columnar, <0.01 equiaxed."""
    assert nat.kurz_fisher_solidification(1000, 5) == "planar"          # 200
    assert nat.kurz_fisher_solidification(100, 5) == "cellular"         # 20
    assert nat.kurz_fisher_solidification(10, 100) == "columnar-dendritic"   # 0.1
    assert nat.kurz_fisher_solidification(0.001, 100) == "equiaxed-dendritic"  # 1e-5


def test_kurz_fisher_higher_GV_is_finer_morphology() -> None:
    """Increasing G/V_s walks the map toward planar (finer/more stable front)."""
    order = ["equiaxed-dendritic", "columnar-dendritic", "cellular", "planar"]
    labels = [
        nat.kurz_fisher_solidification(g, 100)
        for g in (0.001, 10.0, 500.0, 50000.0)
    ]
    assert labels == order


# NOTE: this module exposes only the Kurz-Fisher G/V_s *morphology* classifier.
# There is NO secondary-dendrite-arm-spacing (SDAS) λ = a·CR^(-1/3) function in
# _am_native.py, so the "λ decreases with cooling rate" check from the brief
# cannot be exercised against the library — recorded as a coverage gap.


# ===========================================================================
# 5. Maynier-Dollet 1978 ferrous hardness HV30
# ===========================================================================


def test_maynier_martensite_aisi4140() -> None:
    """Maynier-Dollet martensite HV for AISI 4140 ≈ 581 HV @100 °C/s.

    HV_M = 127 + 949·C + 27·Si + 11·Mn + 8·Ni + 16·Cr + 21·log10(Vr)
         = 127 + 379.6 + 6.75 + 9.35 + 0.4 + 16 + 42 = 581.1 HV
    (Bain & Paxton report ~600 HV for fully-martensitic 4140.)
    """
    comp = {"C": 0.40, "Mn": 0.85, "Si": 0.25, "Ni": 0.05, "Cr": 1.00, "Mo": 0.20}
    HV = nat.maynier_dollet_HV30("AISI-4140", comp, cooling_rate=100.0, phase="martensite")
    assert math.isclose(HV, 581.1, abs_tol=2.0)


def test_maynier_hardness_increases_with_cooling_rate() -> None:
    """HV rises with cooling rate via the +21·log10(Vr) martensite term."""
    comp = {"C": 0.40, "Mn": 0.85, "Si": 0.25, "Ni": 0.05, "Cr": 1.00, "Mo": 0.20}
    hv = [nat.maynier_dollet_HV30("x", comp, cr, "martensite") for cr in (1, 10, 100, 1000)]
    assert hv == sorted(hv)
    # one decade of cooling rate adds exactly 21 HV.
    assert math.isclose(hv[2] - hv[1], 21.0, abs_tol=0.5)


def test_maynier_more_carbon_raises_martensite_hardness() -> None:
    """The 949·C term dominates: +0.2 wt% C ⇒ +~190 HV in martensite."""
    base = {"C": 0.20, "Mn": 0.8, "Si": 0.25, "Ni": 0.0, "Cr": 0.0, "Mo": 0.0}
    high = dict(base, C=0.40)
    dHV = (
        nat.maynier_dollet_HV30("x", high, 100, "martensite")
        - nat.maynier_dollet_HV30("x", base, 100, "martensite")
    )
    assert math.isclose(dHV, 949.0 * 0.20, abs_tol=1.0)


def test_maynier_nonferrous_hallpetch_surrogate() -> None:
    """Non-ferrous (no C): HV = HV₀ + min(60, 6·log10(Vr)); rises with Vr."""
    lo = nat.maynier_dollet_HV30("Ti-6Al-4V", None, cooling_rate=10.0)
    hi = nat.maynier_dollet_HV30("Ti-6Al-4V", None, cooling_rate=1000.0)
    assert hi > lo
    # base 340 + 6·log10(10)=346; base + 6·log10(1000)=358.
    assert math.isclose(lo, 346.0, abs_tol=0.5)
    assert math.isclose(hi, 358.0, abs_tol=0.5)


# ===========================================================================
# 6. Pavlina-Van Tyne 2008 strength-from-hardness
# ===========================================================================


def test_pavlina_sigma_y_linear_fit() -> None:
    """σ_y = 2.876·HV − 90.7 MPa (matches the published 2008 fit)."""
    assert math.isclose(nat.pavlina_tyne_sigma_y(200), 484.5, abs_tol=0.5)
    assert math.isclose(nat.pavlina_tyne_sigma_y(500), 1347.3, abs_tol=0.5)


def test_pavlina_sigma_uts_published_fit() -> None:
    """σ_UTS now uses the published Pavlina-Van Tyne 2008 fit
    σ_UTS = −99.8 + 3.734·HV (Mater. Sci. Eng. A 480 (2008) 132), replacing
    the prior 3.0·HV approximation that ran ~10-15% low.

    HV400 → −99.8 + 3.734·400 = 1393.8 ≈ 1394 MPa.
    """
    assert math.isclose(nat.pavlina_tyne_sigma_uts(400), -99.8 + 3.734 * 400, rel_tol=1e-9)
    assert math.isclose(nat.pavlina_tyne_sigma_uts(400), 1394.0, abs_tol=1.0)
    # IN718-like HV424 lands on the published value, not the old 3.0·HV=1272.
    assert math.isclose(nat.pavlina_tyne_sigma_uts(424), -99.8 + 3.734 * 424, rel_tol=1e-9)


# ===========================================================================
# 7. Barsom-Rolfe K_Ic from CVN  (K_Ic² = 5·E·CVN / 1000, SI)
# ===========================================================================


def test_barsom_rolfe_kic_self_consistent() -> None:
    """K_Ic = √(5·E_MPa·CVN/1000) — internal closed form is exact."""
    KIc = nat.barsom_rolfe_KIc(E_GPa=207.0, CVN_J=20.0)
    assert math.isclose(KIc, math.sqrt(5.0 * 207_000.0 * 20.0 / 1000.0), rel_tol=1e-9)
    assert math.isclose(KIc, 143.87, abs_tol=0.1)


def test_barsom_rolfe_monotone_in_cvn() -> None:
    """Tougher (higher CVN) ⇒ higher K_Ic, ∝ √CVN."""
    k1 = nat.barsom_rolfe_KIc(207.0, 10.0)
    k2 = nat.barsom_rolfe_KIc(207.0, 40.0)
    assert k2 > k1
    assert math.isclose(k2 / k1, 2.0, rel_tol=1e-6)  # √(40/10) = 2


def test_cvn_from_hv_decreases_with_hardness() -> None:
    """Lower-shelf CVN ≈ 290·exp(−HV/280), floored at 2 J; falls as HV rises."""
    assert nat.cvn_from_HV(200) > nat.cvn_from_HV(500)
    assert math.isclose(nat.cvn_from_HV(200), 290.0 * math.exp(-200.0 / 280.0), rel_tol=1e-9)
    assert nat.cvn_from_HV(2000) == 2.0  # floor


# ===========================================================================
# 8. HV → HRC conversion (ASTM E140)
# ===========================================================================


def test_hv_to_hrc_matches_astm_e140() -> None:
    """HV→HRC is refit to ASTM E140 Table 3 anchors: HV240→20.3, HV400→39.8,
    HV600→56.2, HV800→64.0 (the prior mis-fit cubic saturated near ~22-26 for
    HV 400-600). Tolerance ±2 HRC.
    """
    assert math.isclose(nat.hv_to_hrc(400), 39.8, abs_tol=2.0)
    assert math.isclose(nat.hv_to_hrc(600), 56.2, abs_tol=2.0)
    assert math.isclose(nat.hv_to_hrc(800), 64.0, abs_tol=2.0)
    # Physical and monotone: HRC rises ~16 points over HV 400→600.
    assert (nat.hv_to_hrc(600) - nat.hv_to_hrc(400)) > 12.0


def test_hv_to_hrc_low_branch_linear() -> None:
    """Below HV 240 the soft-material linear fallback is now (HV−100)/7.0
    (≈20 HRC at HV240, continuous with the upper ASTM E140 branch)."""
    assert math.isclose(nat.hv_to_hrc(193), (193 - 100) / 7.0, rel_tol=1e-9)


# ===========================================================================
# 9. Auxiliary property correlations
# ===========================================================================


def test_endurance_half_uts_capped() -> None:
    """σ_e ≈ 0.5·σ_UTS, capped at 700 MPa (steel knock-down rule)."""
    assert math.isclose(nat.endurance_from_uts(900), 450.0, abs_tol=1e-9)
    assert nat.endurance_from_uts(1600) == 700.0  # cap


def test_elongation_decreases_with_hardness() -> None:
    """Ductility falls with hardness: 40% at HV200 → 14% at HV600, clip [2,40]."""
    assert math.isclose(nat.elongation_from_HV(200), 40.0, abs_tol=1e-9)
    assert math.isclose(nat.elongation_from_HV(600), 14.0, abs_tol=1e-9)
    assert nat.elongation_from_HV(50) == 40.0   # upper clip
    assert nat.elongation_from_HV(900) == 2.0   # lower clip


# ===========================================================================
# 10. ASTM F-spec compliance gate
# ===========================================================================


def test_astm_gate_pass_and_fail_ti6al4v() -> None:
    """ASTM F3001 Ti-6Al-4V σ_y minimum is 795 MPa; gate fires correctly."""
    ok = nat.astm_compliance_check(
        {"sigma_y_MPa": 900, "sigma_uts_MPa": 990, "elongation_pct": 12},
        spec_id="Ti-6Al-4V", region="optimal",
    )
    assert ok["spec"] == "ASTM F3001"
    assert ok["overall_pass"]

    bad = nat.astm_compliance_check(
        {"sigma_y_MPa": 700, "sigma_uts_MPa": 900, "elongation_pct": 12},
        spec_id="Ti-6Al-4V", region="optimal",
    )
    assert not bad["sigma_y_pass"]
    assert not bad["overall_pass"]


def test_astm_gate_requires_optimal_region() -> None:
    """Even with passing properties, a non-'optimal' region fails the overall
    gate (off-window prints are not qualifiable)."""
    res = nat.astm_compliance_check(
        {"sigma_y_MPa": 900, "sigma_uts_MPa": 1300, "elongation_pct": 15},
        spec_id="IN718", region="keyhole",
    )
    assert res["sigma_y_pass"] and res["sigma_uts_pass"]
    assert not res["overall_pass"]  # region gate vetoes it


def test_astm_unknown_spec_returns_none_with_note() -> None:
    """Unknown alloy ⇒ no spec, surrogate note, gate left permissive."""
    res = nat.astm_compliance_check(
        {"sigma_y_MPa": 100, "sigma_uts_MPa": 200, "elongation_pct": 5},
        spec_id="NOT-A-REAL-ALLOY", region="optimal",
    )
    assert res["spec"] is None
    assert any("No built-in ASTM spec" in n for n in res["notes"])
