"""Batch MTC parse tests — folder of synthetic PDFs → DataFrame.

We don't ship real PDFs (would slow CI). Instead we drop tiny text files
into a tmp folder; the local extractor falls through to UTF-8 decode for
non-PDF blobs, which exercises the same translate + dispatch path.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

import austenite as au


BATCH_URL = "https://api-test.austenite.org/v1/mtc-batch-parse"


def _write_text(folder: Path, name: str, contents: str) -> None:
    p = folder / name
    p.write_text(contents, encoding="utf-8")


def test_batch_parse_returns_dataframe(httpx_mock, tmp_path: Path) -> None:
    pd = pytest.importorskip("pandas")

    # 5 synthetic certs (3 English, 1 German, 1 Japanese).
    _write_text(tmp_path, "cert_01.pdf", "Heat: H1001\nGrade 4140\nC 0.41 Mn 0.85 Cr 1.02 Mo 0.20")
    _write_text(tmp_path, "cert_02.pdf", "Heat: H1002\nGrade 4140\nC 0.40 Mn 0.86 Cr 0.99 Mo 0.21")
    _write_text(tmp_path, "cert_03.pdf", "Heat: H1003\nGrade 4140\nC 0.42 Mn 0.84 Cr 1.05 Mo 0.18")
    _write_text(
        tmp_path,
        "cert_04.pdf",
        "Werkstoff 42CrMo4 Schmelze H1004\nKohlenstoff 0.40 Mangan 0.85 Chrom 1.02 Molybdän 0.20",
    )
    _write_text(
        tmp_path,
        "cert_05.pdf",
        "材料: SCM440 ヒート H1005\n炭素 0.39 マンガン 0.82 クロム 1.04 モリブデン 0.19",
    )

    # Mock the batch endpoint — server returns one parsed result per item,
    # in order.
    httpx_mock.add_response(
        url=BATCH_URL,
        method="POST",
        json={
            "count": 5,
            "results": [
                {
                    "filename": "cert_01.pdf",
                    "parsed": {
                        "chemistry": {"C": 0.41, "Mn": 0.85, "Cr": 1.02, "Mo": 0.20},
                        "metadata": {"heat": "H1001", "grade": "4140"},
                        "unparsed": [],
                    },
                    "detected_grade": "AISI 4140",
                    "confidence": 0.95,
                },
                {
                    "filename": "cert_02.pdf",
                    "parsed": {
                        "chemistry": {"C": 0.40, "Mn": 0.86, "Cr": 0.99, "Mo": 0.21},
                        "metadata": {"heat": "H1002", "grade": "4140"},
                        "unparsed": [],
                    },
                    "detected_grade": "AISI 4140",
                    "confidence": 0.95,
                },
                {
                    "filename": "cert_03.pdf",
                    "parsed": {
                        "chemistry": {"C": 0.42, "Mn": 0.84, "Cr": 1.05, "Mo": 0.18},
                        "metadata": {"heat": "H1003", "grade": "4140"},
                        "unparsed": [],
                    },
                    "detected_grade": "AISI 4140",
                    "confidence": 0.96,
                },
                {
                    "filename": "cert_04.pdf",
                    "parsed": {
                        "chemistry": {"C": 0.40, "Mn": 0.85, "Cr": 1.02, "Mo": 0.20},
                        "metadata": {"heat": "H1004", "grade": "42CrMo4"},
                        "unparsed": [],
                    },
                    "detected_grade": "42CrMo4 / AISI 4140",
                    "confidence": 0.90,
                },
                {
                    "filename": "cert_05.pdf",
                    "parsed": {
                        "chemistry": {"C": 0.39, "Mn": 0.82, "Cr": 1.04, "Mo": 0.19},
                        "metadata": {"heat": "H1005", "grade": "SCM440"},
                        "unparsed": [],
                    },
                    "detected_grade": "SCM440",
                    "confidence": 0.88,
                },
            ],
        },
    )

    df = au.mtc.batch_parse(folder=tmp_path, workers=5, batch_size=50)

    assert isinstance(df, pd.DataFrame)
    assert len(df) == 5
    # core columns are always there
    for col in ("file", "heat", "grade", "C", "Mn", "Cr", "Mo", "language"):
        assert col in df.columns, f"missing column: {col}"
    # row-level checks
    row = df[df["file"] == "cert_01.pdf"].iloc[0]
    assert row["heat"] == "H1001"
    assert row["C"] == pytest.approx(0.41)
    # language detection
    de_row = df[df["file"] == "cert_04.pdf"].iloc[0]
    assert de_row["language"] == "de"
    ja_row = df[df["file"] == "cert_05.pdf"].iloc[0]
    assert ja_row["language"] == "ja"


def test_batch_parse_request_body_translates_languages(httpx_mock, tmp_path: Path) -> None:
    """The batch POST must send English-symbol text for non-English certs."""
    _write_text(
        tmp_path,
        "de.pdf",
        "Werkstoff 42CrMo4\nKohlenstoff 0.40 Mangan 0.85 Chrom 1.02",
    )

    httpx_mock.add_response(
        url=BATCH_URL,
        method="POST",
        json={
            "count": 1,
            "results": [
                {
                    "filename": "de.pdf",
                    "parsed": {
                        "chemistry": {"C": 0.40, "Mn": 0.85, "Cr": 1.02},
                        "metadata": {"grade": "42CrMo4"},
                        "unparsed": [],
                    },
                    "detected_grade": "42CrMo4",
                    "confidence": 0.91,
                }
            ],
        },
    )

    au.mtc.batch_parse(folder=tmp_path, workers=2)

    body = json.loads(httpx_mock.get_requests()[-1].read().decode("utf-8"))
    assert body["items"][0]["filename"] == "de.pdf"
    text = body["items"][0]["text"]
    # Translation happened — server sees ASCII symbols
    assert " C " in text
    assert " Mn " in text
    assert " Cr " in text


def test_batch_parse_handles_empty_folder(tmp_path: Path) -> None:
    pd = pytest.importorskip("pandas")
    df = au.mtc.batch_parse(folder=tmp_path)
    assert isinstance(df, pd.DataFrame)
    assert len(df) == 0


def test_batch_parse_chunks_into_multiple_batches(httpx_mock, tmp_path: Path) -> None:
    """120 certs at batch_size=50 → 3 POSTs (50 + 50 + 20)."""
    pd = pytest.importorskip("pandas")
    for i in range(120):
        _write_text(tmp_path, f"c{i:03d}.pdf", f"Heat H{i}\nC 0.4 Mn 0.85")

    # Mock 3 responses (one per chunk) — order doesn't matter, all match URL.
    def mock_response(n: int, start: int):
        return {
            "count": n,
            "results": [
                {
                    "filename": f"c{start + j:03d}.pdf",
                    "parsed": {
                        "chemistry": {"C": 0.4, "Mn": 0.85},
                        "metadata": {"heat": f"H{start + j}"},
                        "unparsed": [],
                    },
                    "detected_grade": None,
                    "confidence": 0.8,
                }
                for j in range(n)
            ],
        }

    httpx_mock.add_response(url=BATCH_URL, method="POST", json=mock_response(50, 0))
    httpx_mock.add_response(url=BATCH_URL, method="POST", json=mock_response(50, 50))
    httpx_mock.add_response(url=BATCH_URL, method="POST", json=mock_response(20, 100))

    df = au.mtc.batch_parse(folder=tmp_path, workers=10, batch_size=50)
    assert len(df) == 120
    # all 3 batch endpoints hit
    assert sum(1 for r in httpx_mock.get_requests() if r.url.path == "/v1/mtc-batch-parse") == 3
