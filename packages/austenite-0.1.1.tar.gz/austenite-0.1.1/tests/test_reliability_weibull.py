"""Tests for au.reliability.weibull_fit.

Synthetic data is drawn from a known Weibull(β=2.5, η=100) and the MLE
fit is required to recover those parameters within tight tolerances.
Right-censoring is tested separately by truncating part of the sample.
"""

from __future__ import annotations

import math

import pytest

import austenite as au


# Pre-computed Weibull(β=2.5, η=100) quantiles: t_i = η · (−ln(1 − F_i))^(1/β)
# where F_i is the median-rank of i in n=30 (uses Bernard's approximation).
def _synthetic_weibull(beta: float, eta: float, n: int) -> list[float]:
    return [eta * (-math.log(max(1e-12, 1 - (i + 1 - 0.3) / (n + 0.4)))) ** (1.0 / beta)
            for i in range(n)]


def test_weibull_fit_recovers_beta_and_eta_complete_data() -> None:
    """30-sample noiseless Weibull(2.5, 100) → β within 0.15, η within 5%."""

    data = _synthetic_weibull(2.5, 100.0, 30)
    fit = au.reliability.weibull_fit(data)
    assert fit.converged
    assert abs(fit.beta - 2.5) < 0.2, f"β={fit.beta}"
    assert abs(fit.eta - 100.0) / 100.0 < 0.05, f"η={fit.eta}"
    assert fit.R2 > 0.99


def test_weibull_fit_B10_and_MTTF_consistent() -> None:
    """Sanity: B10 / B50 / MTTF should be in the expected ordering and ratio."""

    fit = au.reliability.weibull_fit(_synthetic_weibull(2.5, 100, 30))
    assert fit.B10 < fit.B50 < fit.MTTF * 1.1  # MTTF ≈ η Γ(1+1/β) ≈ 88.7 → close to B63
    # For β=2.5, η=100: B10 ≈ 39.5, B50 ≈ 88.5, MTTF ≈ 88.7
    assert 30 < fit.B10 < 50
    assert 80 < fit.B50 < 100


def test_weibull_fit_handles_right_censoring() -> None:
    """Right-censoring: truncate observations above 100; MLE should still recover β."""

    data = _synthetic_weibull(2.0, 80, 25)
    censored = [t > 80 for t in data]
    # Replace censored values with the censoring threshold (80)
    obs = [80 if c else t for t, c in zip(data, censored)]
    fit = au.reliability.weibull_fit(obs, censored)
    assert fit.converged
    # β within 0.5 (censoring loses information)
    assert abs(fit.beta - 2.0) < 0.5, f"censored β={fit.beta}"
    assert fit.n_censored > 0
    assert fit.n_failures == 25 - fit.n_censored


def test_weibull_fit_reliability_function() -> None:
    """R(η) ≈ exp(-1) ≈ 0.368 — the 63.2 % characteristic-life definition."""

    fit = au.reliability.weibull_fit(_synthetic_weibull(2.5, 100, 30))
    R_at_eta = fit.reliability(fit.eta)
    assert abs(R_at_eta - math.exp(-1)) < 0.01


def test_weibull_fit_too_few_data_returns_zero() -> None:
    """< 3 datapoints → degenerate fit with converged=False."""

    fit = au.reliability.weibull_fit([10, 20])
    assert not fit.converged
    assert fit.beta == 0
    assert fit.eta == 0
