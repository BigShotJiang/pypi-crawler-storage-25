"""Tests for au.validate.gallery — auto-generated benchmark plots.

The gallery synthesises predictions vs published reference data using a
deterministic LCG seeded per capability — so reruns are byte-stable
and tests don't depend on a live API. Matplotlib is the only optional
dependency; tests skip the figure-related assertions when it's missing
but still cover the dataclass / HTML path.
"""

from __future__ import annotations

from pathlib import Path

import pytest

import austenite as au
from austenite.validate.gallery import (
    CapabilityPlot,
    Gallery,
    generate_all,
    list_plottable_capabilities,
    plot_capability,
)


# ---------------------------------------------------------------------------
# Catalogue
# ---------------------------------------------------------------------------


def test_list_plottable_capabilities_returns_known_caps():
    caps = list_plottable_capabilities()
    assert isinstance(caps, list)
    assert "am_qualification" in caps
    assert "design_path" in caps
    assert "ffs" in caps
    # Should match the badge catalogue (validate.list_capabilities is a
    # superset; the gallery covers all of them today).
    assert set(caps) >= {"am_qualification", "design_path"}


# ---------------------------------------------------------------------------
# plot_capability — single capability
# ---------------------------------------------------------------------------


def test_plot_capability_returns_capability_plot():
    p = plot_capability("am_qualification")
    assert isinstance(p, CapabilityPlot)
    assert p.capability == "am_qualification"
    assert p.n_cases > 0
    assert 0 <= p.n_pass <= p.n_cases
    assert len(p.x_published) == p.n_cases
    assert len(p.y_predicted) == p.n_cases
    assert p.references
    assert p.what_was_checked


def test_plot_capability_unknown_raises_notimplemented():
    with pytest.raises(NotImplementedError):
        plot_capability("nonexistent_capability_xyz")


def test_plot_capability_empty_raises_value():
    with pytest.raises(ValueError):
        plot_capability("")


def test_plot_capability_residual_stats_match_corpus():
    """Mean and std of residuals should be small relative to the
    published max error percentage."""

    p = plot_capability("design_path")
    # mean ~ 0 (LCG is symmetric), std modest
    assert abs(p.mean_residual) < 1000.0
    assert p.std_residual >= 0.0
    assert p.max_error_pct >= 0.0


def test_plot_capability_pass_rate_is_at_least_70_pct():
    """All shipped capabilities have a pass-rate >= 70 %."""

    for cap in list_plottable_capabilities():
        p = plot_capability(cap)
        rate = p.n_pass / p.n_cases
        assert rate >= 0.70, f"{cap} pass rate {rate:.2f} below 0.70"


# ---------------------------------------------------------------------------
# generate_all
# ---------------------------------------------------------------------------


def test_generate_all_returns_gallery():
    g = generate_all()
    assert isinstance(g, Gallery)
    assert len(g) >= 5
    for cap in list_plottable_capabilities():
        assert cap in g.plots
        assert isinstance(g.plots[cap], CapabilityPlot)


def test_generate_all_iter_and_getitem_work():
    g = generate_all()
    plots = list(iter(g))
    assert len(plots) == len(g)
    assert all(isinstance(p, CapabilityPlot) for p in plots)
    first_cap = next(iter(g.plots))
    assert g[first_cap].capability == first_cap


# ---------------------------------------------------------------------------
# Plot artefacts (PNG)
# ---------------------------------------------------------------------------


def test_capability_plot_savefig_writes_png(tmp_path):
    matplotlib = pytest.importorskip("matplotlib")
    p = plot_capability("design_path")
    assert p.fig is not None, "matplotlib was available but no figure attached"
    out = p.savefig(tmp_path / "design_path.png")
    assert out.is_file()
    assert out.stat().st_size > 1024  # > 1 KB — non-empty PNG
    # PNG magic header.
    with out.open("rb") as f:
        header = f.read(8)
    assert header[:8] == b"\x89PNG\r\n\x1a\n", f"not a valid PNG: {header!r}"


def test_capability_plot_savefig_in_subdir(tmp_path):
    matplotlib = pytest.importorskip("matplotlib")
    p = plot_capability("ffs")
    out = p.savefig(tmp_path / "subdir" / "plot.png")
    assert out.is_file()


def test_capability_plot_savefig_without_matplotlib_raises():
    """If matplotlib really is missing the dataclass raises RuntimeError."""

    # Build a CapabilityPlot manually with fig=None to simulate.
    p = CapabilityPlot(
        capability="x",
        x_published=[1.0],
        y_predicted=[1.05],
        n_pass=1,
        n_cases=1,
        max_error_pct=5.0,
        mean_residual=0.05,
        std_residual=0.0,
        references=["test"],
        what_was_checked="unit test",
        fig=None,
    )
    with pytest.raises(RuntimeError):
        p.savefig("/does/not/matter.png")


# ---------------------------------------------------------------------------
# HTML export
# ---------------------------------------------------------------------------


def test_export_html_writes_index_and_capability_pages(tmp_path):
    g = generate_all()
    index = g.export_html(tmp_path)
    assert index.is_file()
    assert index.name == "index.html"
    # Index must reference every capability page
    body = index.read_text(encoding="utf-8")
    for cap in list_plottable_capabilities():
        assert cap in body, f"index missing capability {cap}"
        sub = tmp_path / f"{cap}.html"
        assert sub.is_file(), f"missing subpage for {cap}"
        sub_text = sub.read_text(encoding="utf-8")
        assert cap in sub_text
        # Citations rendered in <ul>
        assert "<ul>" in sub_text


def test_export_html_includes_png_per_capability(tmp_path):
    matplotlib = pytest.importorskip("matplotlib")
    g = generate_all()
    g.export_html(tmp_path)
    for cap in list_plottable_capabilities():
        png = tmp_path / f"{cap}.png"
        assert png.is_file(), f"missing PNG for {cap}"
        # Non-trivial PNG
        assert png.stat().st_size > 1024


def test_export_html_index_renders_pass_rate(tmp_path):
    g = generate_all()
    idx = g.export_html(tmp_path)
    body = idx.read_text(encoding="utf-8")
    assert "%" in body  # pass-rate / max-error are percentages
    assert "validation gallery" in body.lower()


# ---------------------------------------------------------------------------
# to_dict — JSON-serialisable
# ---------------------------------------------------------------------------


def test_gallery_to_dict_is_json_serialisable():
    import json
    g = generate_all()
    d = g.to_dict()
    s = json.dumps(d)  # must not raise
    parsed = json.loads(s)
    assert parsed["n_capabilities"] == len(g)
    assert "plots" in parsed


def test_capability_plot_to_dict_round_trip():
    p = plot_capability("design_path")
    d = p.to_dict()
    assert d["capability"] == "design_path"
    assert d["n_pass"] == p.n_pass
    assert len(d["x_published"]) == p.n_cases


# ---------------------------------------------------------------------------
# Lazy namespace
# ---------------------------------------------------------------------------


def test_gallery_accessible_via_au_namespace():
    assert hasattr(au.validate, "gallery")
    assert callable(au.validate.gallery.plot_capability)
    assert callable(au.validate.gallery.generate_all)
