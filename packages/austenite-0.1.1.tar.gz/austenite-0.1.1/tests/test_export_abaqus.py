"""Tests for ``au.export.abaqus_inp`` — Abaqus standard ``.inp`` deck writer.

Abaqus ``.inp`` is keyword-driven, ASCII, with ``*KEYWORD`` lines and
data rows beneath. Our in-test parser validates keyword presence,
node-count consistency, element-block structure, and that
boundary-condition blocks reference declared NSETs/ELSETs.

References:
    * Abaqus Analysis User's Manual §1 — Keyword reference.
    * Abaqus Keywords Reference — `*NODE`, `*ELEMENT`, `*MATERIAL`,
      `*STEP`, `*BOUNDARY`, `*DSLOAD`.
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest

import austenite as au


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _split_keyword_blocks(text: str) -> list[tuple[str, list[str]]]:
    """Split an Abaqus deck into ``[(keyword_line, data_lines), ...]``.

    Each ``*KEYWORD`` (line starting with a single ``*``, not a comment
    ``**``) starts a new block; everything between it and the next
    keyword is data.
    """

    blocks: list[tuple[str, list[str]]] = []
    current_kw: str | None = None
    current_data: list[str] = []
    for raw in text.splitlines():
        line = raw.rstrip()
        if line.startswith("**"):
            continue  # comment
        if line.startswith("*"):
            if current_kw is not None:
                blocks.append((current_kw, current_data))
            current_kw = line
            current_data = []
        else:
            if current_kw is not None and line.strip():
                current_data.append(line)
    if current_kw is not None:
        blocks.append((current_kw, current_data))
    return blocks


def _keyword_names(blocks: list[tuple[str, list[str]]]) -> list[str]:
    """Extract just the keyword (e.g. ``*NODE``, ``*ELEMENT``) names."""

    out: list[str] = []
    for kw, _ in blocks:
        # Keyword is the first comma-separated token
        first = kw.split(",")[0].strip()
        out.append(first)
    return out


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_abaqus_writes_canonical_keyword_sequence(tmp_path: Path) -> None:
    out = tmp_path / "model.inp"
    res = au.export.abaqus_inp(
        geometry={"type": "cylinder", "OD_mm": 500, "L_mm": 1000, "wall_mm": 12.5,
                  "n_theta": 8, "n_r": 2, "n_x": 4},
        material="SA-516-70",
        physics="static",
        boundary_conditions={"LEFT": "fixed", "INNER": "P_MPa=2.5"},
        output_path=out,
    )
    assert out.exists()
    blocks = _split_keyword_blocks(out.read_text(encoding="utf-8"))
    names = _keyword_names(blocks)
    # Canonical block sequence for a static deck
    for kw in ("*HEADING", "*NODE", "*ELEMENT", "*MATERIAL", "*ELASTIC",
               "*DENSITY", "*SOLID SECTION", "*STEP", "*STATIC",
               "*BOUNDARY", "*END STEP"):
        assert kw in names, f"missing keyword {kw}; saw {names}"
    assert res["n_elements"] > 0
    assert res["elem_type"] == "C3D8"


def test_abaqus_node_block_has_n_nodes_lines(tmp_path: Path) -> None:
    out = tmp_path / "node_count.inp"
    res = au.export.abaqus_inp(
        geometry={"type": "block", "Lx_mm": 50, "Ly_mm": 50, "Lz_mm": 50,
                  "nx": 3, "ny": 3, "nz": 3},
        material="304L",
        physics="static",
        boundary_conditions={"LEFT": "fixed", "RIGHT": "Ux_mm=0.5"},
        output_path=out,
    )
    # 4 x 4 x 4 = 64 nodes for a 3x3x3 element grid
    assert res["n_nodes"] == 64
    assert res["n_elements"] == 27

    blocks = _split_keyword_blocks(out.read_text(encoding="utf-8"))
    node_blocks = [(kw, data) for kw, data in blocks if kw.strip() == "*NODE"]
    assert len(node_blocks) == 1
    _, data = node_blocks[0]
    assert len(data) == 64
    # Every row: "id, x, y, z" — 4 comma-separated tokens
    for row in data:
        toks = [t.strip() for t in row.split(",")]
        assert len(toks) == 4
        int(toks[0])  # node id parses as int
        float(toks[1]); float(toks[2]); float(toks[3])


def test_abaqus_element_block_has_correct_element_count_and_8_nodes_per_hex(tmp_path: Path) -> None:
    out = tmp_path / "ele.inp"
    au.export.abaqus_inp(
        geometry={"type": "block", "Lx_mm": 50, "Ly_mm": 50, "Lz_mm": 50,
                  "nx": 4, "ny": 4, "nz": 4},
        material="304L",
        physics="static",
        boundary_conditions={"LEFT": "fixed"},
        output_path=out,
    )
    blocks = _split_keyword_blocks(out.read_text(encoding="utf-8"))
    # Filter to the element-definition block (TYPE=...) — not *ELEMENT OUTPUT
    elem_blocks = [
        (kw, data) for kw, data in blocks
        if kw.strip().startswith("*ELEMENT,") and "TYPE=" in kw
    ]
    assert len(elem_blocks) == 1
    kw, data = elem_blocks[0]
    assert "TYPE=C3D8" in kw
    assert len(data) == 4 * 4 * 4  # 64 hex elements
    # Each row: id + 8 node ids → 9 tokens
    for row in data:
        toks = [t.strip() for t in row.split(",")]
        assert len(toks) == 9


def test_abaqus_material_block_writes_youngs_modulus_in_pascals(tmp_path: Path) -> None:
    out = tmp_path / "mat.inp"
    au.export.abaqus_inp(
        geometry={"type": "cylinder", "OD_mm": 100, "L_mm": 200, "wall_mm": 5.0,
                  "n_theta": 6, "n_r": 1, "n_x": 3},
        material="IN718",
        physics="static",
        boundary_conditions={"LEFT": "fixed"},
        output_path=out,
    )
    text = out.read_text(encoding="utf-8")
    # IN718 E = 200 GPa = 2.0e11 Pa
    assert "2.000e+11" in text, text
    # Poisson's ratio 0.29
    assert "0.290" in text
    # Density 8190 kg/m^3
    assert "8190" in text


def test_abaqus_pressure_bc_emits_dsload_keyword(tmp_path: Path) -> None:
    out = tmp_path / "p.inp"
    au.export.abaqus_inp(
        geometry={"type": "cylinder", "OD_mm": 500, "L_mm": 1000, "wall_mm": 12.5,
                  "n_theta": 8, "n_r": 2, "n_x": 4},
        material="SA-516-70",
        physics="static",
        boundary_conditions={"LEFT": "fixed", "INNER": "P_MPa=3.5"},
        output_path=out,
    )
    text = out.read_text(encoding="utf-8")
    assert "*DSLOAD" in text
    # 3.5 MPa = 3.5e6 Pa, named on INNER
    assert re.search(r"INNER,\s*P,\s*3\.500e\+0?6", text), text


def test_abaqus_fixed_bc_emits_dirichlet_zero_on_dofs_1_to_3(tmp_path: Path) -> None:
    out = tmp_path / "fixed.inp"
    au.export.abaqus_inp(
        geometry={"type": "block", "Lx_mm": 100, "Ly_mm": 100, "Lz_mm": 100,
                  "nx": 2, "ny": 2, "nz": 2},
        material="304L",
        physics="static",
        boundary_conditions={"LEFT": "fixed"},
        output_path=out,
    )
    text = out.read_text(encoding="utf-8")
    assert re.search(r"LEFT,\s*1,\s*3,\s*0\.0", text), text


def test_abaqus_unknown_alloy_falls_back_with_note(tmp_path: Path) -> None:
    out = tmp_path / "fallback.inp"
    res = au.export.abaqus_inp(
        geometry={"type": "block", "Lx_mm": 50, "Ly_mm": 50, "Lz_mm": 50,
                  "nx": 2, "ny": 2, "nz": 2},
        material="MysteryAlloy-2026",
        physics="static",
        boundary_conditions={"LEFT": "fixed"},
        output_path=out,
    )
    # Falls back to SA-516-70 but keeps the original name in the canonical
    assert "fallback" in res["material"].lower() or "SA-516-70" in res["material"]


def test_abaqus_geometry_types_supported(tmp_path: Path) -> None:
    """All three geometry primitives should write a deck without raising."""

    for kind, geo in [
        ("cylinder", {"type": "cylinder", "OD_mm": 100, "L_mm": 200, "wall_mm": 5,
                      "n_theta": 6, "n_r": 1, "n_x": 2}),
        ("plate", {"type": "plate", "Lx_mm": 100, "Ly_mm": 100, "thickness_mm": 5,
                   "nx": 4, "ny": 4, "nz": 1}),
        ("block", {"type": "block", "Lx_mm": 50, "Ly_mm": 50, "Lz_mm": 50,
                   "nx": 3, "ny": 3, "nz": 3}),
    ]:
        out = tmp_path / f"{kind}.inp"
        res = au.export.abaqus_inp(
            geometry=geo,
            material="SA-516-70",
            physics="static",
            boundary_conditions={"LEFT": "fixed"},
            output_path=out,
        )
        assert res["geom_kind"] == kind
        assert out.exists() and len(out.read_text(encoding="utf-8")) > 1000


def test_abaqus_invalid_geometry_type_raises_valueerror(tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="Unsupported"):
        au.export.abaqus_inp(
            geometry={"type": "thingamajig"},
            material="SA-516-70",
            physics="static",
            output_path=tmp_path / "bad.inp",
        )
