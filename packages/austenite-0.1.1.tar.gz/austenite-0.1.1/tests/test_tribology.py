"""Tests for au.tribology — Archard + Lim-Ashby + Stribeck + Hertz + PV."""
from __future__ import annotations

import math
import pytest

from austenite.tribology import (
    ARCHARD_K_TABLE,
    FRICTION_COEFFICIENTS,
    PV_LIMITS,
    archard_wear_depth,
    archard_wear_volume,
    friction_coefficient,
    hamrock_dowson_film_thickness_point,
    hertz_line_contact_max_pressure,
    hertz_point_contact_max_pressure,
    lim_ashby_plowing_wear,
    pv_limit_check,
    stribeck_curve,
)


# ---------------------------------------------------------------------------
# Archard wear
# ---------------------------------------------------------------------------


def test_archard_volume_basic():
    V = archard_wear_volume(normal_load_N=100, sliding_distance_m=1000,
                             hardness_HV=200, wear_coefficient_k=1e-7)
    assert math.isfinite(V)
    assert V > 0


def test_archard_volume_higher_k_higher_wear():
    V_low = archard_wear_volume(normal_load_N=100, sliding_distance_m=1000,
                                  hardness_HV=200, wear_coefficient_k=1e-8)
    V_high = archard_wear_volume(normal_load_N=100, sliding_distance_m=1000,
                                   hardness_HV=200, wear_coefficient_k=1e-4)
    assert V_high > V_low


def test_archard_volume_harder_surface_less_wear():
    V_soft = archard_wear_volume(normal_load_N=100, sliding_distance_m=1000,
                                   hardness_HV=100, wear_coefficient_k=1e-7)
    V_hard = archard_wear_volume(normal_load_N=100, sliding_distance_m=1000,
                                   hardness_HV=800, wear_coefficient_k=1e-7)
    assert V_hard < V_soft


def test_archard_k_table_has_canonical_entries():
    assert "steel-on-steel-dry" in ARCHARD_K_TABLE
    assert "steel-on-steel-lubricated" in ARCHARD_K_TABLE
    assert "severe-galling" in ARCHARD_K_TABLE
    # Lubricated should have much lower k than dry
    assert (ARCHARD_K_TABLE["steel-on-steel-lubricated"]["k"]
            < ARCHARD_K_TABLE["steel-on-steel-dry"]["k"])


def test_archard_depth_from_volume_and_area():
    d = archard_wear_depth(contact_area_mm2=10.0,
                            normal_load_N=100, sliding_distance_m=1000,
                            hardness_HV=200, wear_coefficient_k=1e-7)
    assert math.isfinite(d)


def test_archard_zero_hardness_returns_nan():
    assert math.isnan(archard_wear_volume(100, 1000, 0, 1e-7))


# ---------------------------------------------------------------------------
# Lim-Ashby plowing
# ---------------------------------------------------------------------------


def test_lim_ashby_basic():
    V = lim_ashby_plowing_wear(normal_load_N=100, sliding_distance_m=1000,
                                hardness_HV=200, asperity_angle_deg=30)
    assert math.isfinite(V)
    assert V > 0


def test_lim_ashby_sharper_asperity_more_wear():
    V_blunt = lim_ashby_plowing_wear(normal_load_N=100, sliding_distance_m=1000,
                                      hardness_HV=200, asperity_angle_deg=15)
    V_sharp = lim_ashby_plowing_wear(normal_load_N=100, sliding_distance_m=1000,
                                      hardness_HV=200, asperity_angle_deg=45)
    assert V_sharp > V_blunt


# ---------------------------------------------------------------------------
# Friction
# ---------------------------------------------------------------------------


def test_friction_steel_on_steel_dry_high():
    mu = friction_coefficient("steel-on-steel-dry", kinetic=True)
    assert 0.4 <= mu <= 0.8


def test_friction_steel_on_steel_grease_low():
    mu = friction_coefficient("steel-on-steel-grease", kinetic=True)
    assert 0.0 <= mu <= 0.20


def test_friction_static_greater_than_kinetic():
    """For most pairs, μ_s > μ_k."""
    pair = "steel-on-steel-dry"
    mu_s = friction_coefficient(pair, kinetic=False)
    mu_k = friction_coefficient(pair, kinetic=True)
    assert mu_s > mu_k


def test_friction_unknown_pair_returns_nan():
    assert math.isnan(friction_coefficient("nonexistent-pair"))


def test_friction_coefficients_table_has_key_pairs():
    for key in ["steel-on-steel-dry", "steel-on-PTFE-dry", "rubber-on-concrete-dry"]:
        assert key in FRICTION_COEFFICIENTS


# ---------------------------------------------------------------------------
# Stribeck curve
# ---------------------------------------------------------------------------


def test_stribeck_boundary_at_low_speed():
    """Low speed → boundary regime."""
    r = stribeck_curve(eta_viscosity_Pa_s=0.01, speed_m_s=1e-6, pressure_MPa=50)
    assert r["regime"] == "boundary"
    assert r["mu_estimate"] > 0.05


def test_stribeck_HL_at_high_speed():
    """High speed × high viscosity → hydrodynamic regime."""
    r = stribeck_curve(eta_viscosity_Pa_s=0.1, speed_m_s=10.0, pressure_MPa=1)
    assert r["regime"] == "HL"
    assert r["mu_estimate"] < 0.02


def test_stribeck_with_lambda_classification():
    """Pass h_min and Ra explicitly."""
    r = stribeck_curve(eta_viscosity_Pa_s=0.01, speed_m_s=1.0, pressure_MPa=50,
                       h_min_um=2.0, Ra_um=0.5)
    assert math.isclose(r["lambda"], 4.0, rel_tol=1e-3)
    # λ = 4 means EHL regime
    assert r["regime"] == "EHL"


# ---------------------------------------------------------------------------
# Hamrock-Dowson EHL film
# ---------------------------------------------------------------------------


def test_hamrock_dowson_basic():
    h = hamrock_dowson_film_thickness_point(
        eta_0_Pa_s=0.05, speed_m_s=2.0,
        E_prime_Pa=2.3e11, R_prime_m=0.01, W_N=1000,
    )
    assert math.isfinite(h)
    assert h > 0


def test_hamrock_dowson_higher_speed_thicker_film():
    h_slow = hamrock_dowson_film_thickness_point(
        eta_0_Pa_s=0.05, speed_m_s=0.5,
        E_prime_Pa=2.3e11, R_prime_m=0.01, W_N=1000,
    )
    h_fast = hamrock_dowson_film_thickness_point(
        eta_0_Pa_s=0.05, speed_m_s=10.0,
        E_prime_Pa=2.3e11, R_prime_m=0.01, W_N=1000,
    )
    assert h_fast > h_slow


# ---------------------------------------------------------------------------
# Hertz contact
# ---------------------------------------------------------------------------


def test_hertz_point_steel_ball_on_flat():
    """1 kN load, 10 mm steel ball on steel flat — published case."""
    r = hertz_point_contact_max_pressure(
        F_N=1000, R1_m=0.01, R2_m=float("inf"),
        E1_GPa=200, nu1=0.30, E2_GPa=200, nu2=0.30,
    )
    assert math.isfinite(r["p_max_MPa"])
    assert math.isfinite(r["a_mm"])
    # For this case, p_max ≈ 2.5-3.0 GPa, a ≈ 0.4 mm (Johnson 1985 Table 3.1)
    assert 2000 <= r["p_max_MPa"] <= 3500
    assert 0.3 <= r["a_mm"] <= 0.6


def test_hertz_point_higher_load_higher_pressure():
    r_low = hertz_point_contact_max_pressure(
        F_N=100, R1_m=0.01, R2_m=float("inf"),
        E1_GPa=200, nu1=0.30, E2_GPa=200, nu2=0.30,
    )
    r_hi = hertz_point_contact_max_pressure(
        F_N=10000, R1_m=0.01, R2_m=float("inf"),
        E1_GPa=200, nu1=0.30, E2_GPa=200, nu2=0.30,
    )
    assert r_hi["p_max_MPa"] > r_low["p_max_MPa"]


def test_hertz_line_basic():
    r = hertz_line_contact_max_pressure(
        F_per_length_N_per_m=100_000, R_m=0.01,
        E1_GPa=200, nu1=0.30, E2_GPa=200, nu2=0.30,
    )
    assert math.isfinite(r["p_max_MPa"])
    assert math.isfinite(r["b_mm"])


# ---------------------------------------------------------------------------
# PV limit
# ---------------------------------------------------------------------------


def test_pv_limit_PTFE_pass_at_low_PV():
    r = pv_limit_check(pressure_MPa=0.01, velocity_m_s=1.0, polymer="PTFE")
    assert r["passed"] is True


def test_pv_limit_PTFE_fail_at_high_PV():
    r = pv_limit_check(pressure_MPa=1.0, velocity_m_s=1.0, polymer="PTFE")
    assert r["passed"] is False


def test_pv_limit_PEEK_higher_than_PTFE():
    """PEEK PV limit > PTFE PV limit."""
    assert PV_LIMITS["PEEK"] > PV_LIMITS["PTFE"]


def test_pv_limit_unknown_polymer_error():
    r = pv_limit_check(pressure_MPa=0.1, velocity_m_s=1.0, polymer="nonexistent")
    assert "error" in r
