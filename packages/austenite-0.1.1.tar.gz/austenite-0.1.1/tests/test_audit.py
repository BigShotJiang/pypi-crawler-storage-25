"""Tests for au.audit — local record / save / load / replay / verify (moat 6).

Covers:
  * Round-trip record → save → load → verify.
  * Canonical-form invariance — 1e-12 perturbation gives same hash.
  * engine_version mismatch raises ReplayMismatchError.
  * Deterministic flag exports the seed env var.
  * Legacy server-side audit API still works.
"""

from __future__ import annotations

import json
import math
import os
from pathlib import Path

import pytest

import austenite as au
from austenite import _audit_hash
from austenite.audit import (
    ReplayMismatchError,
    VerifyReport,
    _ENDPOINT_REPLAYERS,
)


# ---------------------------------------------------------------------------
# Canonical-form + hash tests
# ---------------------------------------------------------------------------


def test_canonicalize_sorts_dict_keys() -> None:
    a = {"b": 1, "a": 2, "c": 3}
    b = {"c": 3, "a": 2, "b": 1}
    assert _audit_hash.canonical_json(a) == _audit_hash.canonical_json(b)


def test_canonicalize_rounds_to_12_sig_figs() -> None:
    # Two values differing only in the 13th sig fig should hash identically
    x = 1.234567890123456
    y = 1.234567890123457  # 13th digit differs
    assert _audit_hash.hash_record({"v": x}) == _audit_hash.hash_record({"v": y})


def test_canonicalize_zero_is_zero() -> None:
    assert _audit_hash.canonicalize(0.0) == 0.0
    assert _audit_hash.canonicalize(-0.0) == -0.0


def test_canonicalize_handles_nan_and_inf() -> None:
    # NaN and Inf get sentinel strings — not allowed in raw JSON
    canon = _audit_hash.canonicalize(
        {"a": float("nan"), "b": float("inf"), "c": float("-inf")}
    )
    assert canon == {"a": "NaN", "b": "Infinity", "c": "-Infinity"}


def test_canonicalize_handles_nested_structures() -> None:
    data = {
        "outer": {"x": [1.0, 2.0, {"y": 3.0}]},
        "list": [{"b": 1}, {"a": 2}],
    }
    canon = _audit_hash.canonical_json(data)
    rt = json.loads(canon)
    # Outer keys are sorted
    assert list(rt.keys()) == ["list", "outer"]


def test_hash_record_deterministic_across_calls() -> None:
    rec = {"sigma_y": 1535.123, "verdict": "PASS", "samples": [1.0, 2.0, 3.0]}
    h1 = _audit_hash.hash_record(rec)
    h2 = _audit_hash.hash_record(rec)
    assert h1 == h2
    assert len(h1) == 64  # sha256 hex


def test_hash_record_tuple_vs_list_equivalent() -> None:
    """Tuples in source data should canonicalize to lists."""

    a = {"x": (1, 2, 3)}
    b = {"x": [1, 2, 3]}
    assert _audit_hash.hash_record(a) == _audit_hash.hash_record(b)


def test_canonicalize_handles_bools_vs_ints() -> None:
    """Booleans must stay bool — Python's bool is int subclass."""

    a = _audit_hash.canonicalize({"v": True})
    b = _audit_hash.canonicalize({"v": 1})
    # Hashes should DIFFER because JSON true ≠ JSON 1.
    assert _audit_hash.canonical_json(a) != _audit_hash.canonical_json(b)


# ---------------------------------------------------------------------------
# record() basic shape
# ---------------------------------------------------------------------------


def test_record_basic_extraction_from_dict() -> None:
    fake_result = {
        "properties": {"sigma_y_MPa": 1535},
        "compliance": {"pass": True, "p_pass": 0.97},
    }
    rec = au.audit.record(fake_result, endpoint="/v1/design-path")
    assert rec["endpoint"] == "/v1/design-path"
    assert "engine_version" in rec
    assert "result_hash" in rec
    assert len(rec["result_hash"]) == 64  # sha256
    assert rec["original_result"]["properties"]["sigma_y_MPa"] == 1535
    assert rec["deterministic"] is False
    assert rec["rng_seed"] == 0


def test_record_with_deterministic_seed() -> None:
    rec = au.audit.record(
        {"properties": {"sigma_y_MPa": 1535}},
        endpoint="/v1/design-path",
        deterministic_seed=42,
    )
    assert rec["deterministic"] is True
    assert rec["rng_seed"] == 42


def test_record_pydantic_model_round_trip() -> None:
    """record() accepts Pydantic result models."""

    from austenite._models import DesignPathResult, Properties

    result = DesignPathResult(
        properties=Properties(sigma_y_MPa=1535, sigma_uts_MPa=1700),
        trace_id="t-123",
    )
    rec = au.audit.record(result)
    # Endpoint inferred from class name
    assert rec["endpoint"] == "/v1/design-path"
    assert rec["original_result"]["properties"]["sigma_y_MPa"] == 1535


def test_record_records_payload_when_provided() -> None:
    rec = au.audit.record(
        {"properties": {"sigma_y_MPa": 1535}},
        endpoint="/v1/design-path",
        payload={"alloy": "AISI 4140", "cooling_rate": 10},
    )
    assert rec["input"]["alloy"] == "AISI 4140"
    assert rec["input"]["cooling_rate"] == 10


def test_record_with_no_args_raises() -> None:
    with pytest.raises(TypeError):
        au.audit.record()


# ---------------------------------------------------------------------------
# save() / load() round-trip
# ---------------------------------------------------------------------------


def test_save_and_load_round_trip(tmp_path: Path) -> None:
    rec = au.audit.record(
        {"properties": {"sigma_y_MPa": 1535.123}},
        endpoint="/v1/design-path",
    )
    path = tmp_path / "calc.json"
    au.audit.save(rec, path)
    assert path.exists()

    loaded = au.audit.load(path)
    # Both have the same hash (canonical save is lossless w.r.t. sig figs)
    assert loaded["result_hash"] == rec["result_hash"]
    assert loaded["original_result"]["properties"]["sigma_y_MPa"] == 1535.123
    assert loaded["endpoint"] == "/v1/design-path"


def test_save_uses_canonical_form_byte_identical(tmp_path: Path) -> None:
    """Two records with same content produce byte-identical files."""

    rec_a = au.audit.record({"a": 1.0, "b": 2.0}, endpoint="x")
    rec_b = au.audit.record({"b": 2.0, "a": 1.0}, endpoint="x")
    # Strip timestamps so content compare is well-defined
    rec_a["timestamp"] = "2026-05-19T00:00:00Z"
    rec_b["timestamp"] = "2026-05-19T00:00:00Z"
    path_a = tmp_path / "a.json"
    path_b = tmp_path / "b.json"
    au.audit.save(rec_a, path_a)
    au.audit.save(rec_b, path_b)
    assert path_a.read_bytes() == path_b.read_bytes()


def test_save_creates_parent_dirs(tmp_path: Path) -> None:
    nested = tmp_path / "deep" / "nested" / "calc.json"
    rec = au.audit.record({"v": 1}, endpoint="x")
    au.audit.save(rec, nested)
    assert nested.exists()


# ---------------------------------------------------------------------------
# verify()
# ---------------------------------------------------------------------------


def test_verify_passes_on_intact_record() -> None:
    rec = au.audit.record(
        {"properties": {"sigma_y_MPa": 1535}}, endpoint="/v1/design-path"
    )
    report = au.audit.verify(rec)
    assert isinstance(report, VerifyReport)
    assert report.hash_matches is True
    assert report.engine_version_matches is True
    assert report.stored_hash == report.computed_hash


def test_verify_fails_on_tampered_record() -> None:
    rec = au.audit.record(
        {"properties": {"sigma_y_MPa": 1535}}, endpoint="/v1/design-path"
    )
    # Tamper
    rec["original_result"]["properties"]["sigma_y_MPa"] = 9999
    report = au.audit.verify(rec)
    assert report.hash_matches is False
    assert any("Hash mismatch" in n for n in report.notes)


def test_verify_engine_version_mismatch_is_informational() -> None:
    rec = au.audit.record(
        {"properties": {"sigma_y_MPa": 1535}}, endpoint="/v1/design-path"
    )
    rec["engine_version"] = "0.0.999"
    report = au.audit.verify(rec)
    # Hash still matches because original_result was unchanged
    assert report.hash_matches is True
    assert report.engine_version_matches is False


def test_verify_requires_result_hash_field() -> None:
    with pytest.raises(ValueError, match="no 'result_hash'"):
        au.audit.verify({"endpoint": "x", "original_result": {}})


# ---------------------------------------------------------------------------
# replay() local — bit-exact reproduction guarantee
# ---------------------------------------------------------------------------


def test_replay_engine_version_pin_mismatch_raises() -> None:
    rec = au.audit.record({"properties": {"sigma_y_MPa": 1535}},
                          endpoint="/v1/design-path")
    rec["engine_version"] = "0.0.999"  # not current
    with pytest.raises(ReplayMismatchError, match="engine_version pin mismatch"):
        au.audit.replay(rec, engine_version="0.1.0")


def test_replay_unknown_endpoint_raises() -> None:
    rec = au.audit.record({"x": 1}, endpoint="/v1/does-not-exist")
    with pytest.raises(ReplayMismatchError, match="No local replayer"):
        au.audit.replay(rec)


def test_replay_design_path_round_trip(httpx_mock) -> None:
    """End-to-end: design_path → record → save → load → replay → verify hash."""

    URL = "https://api-test.austenite.org/v1/design-path"
    body = {
        "properties": {"sigma_y_MPa": 1535.0, "sigma_uts_MPa": 1700.0},
        "compliance": {"spec": "ASME-VIII-Div2", "pass": True, "margin": 1.4},
        "citations": [],
        "trace_id": "abc",
    }
    # First call to record the result
    httpx_mock.add_response(url=URL, method="POST", json=body)
    result = au.design_path(alloy="AISI 4140", cooling_rate=10)
    rec = au.audit.record(
        result,
        endpoint="/v1/design-path",
        payload={"alloy": "AISI 4140", "cooling_rate": 10},
    )
    assert rec["input"]["alloy"] == "AISI 4140"

    # Second call: re-run via replay() — server returns same body, hash matches
    httpx_mock.add_response(url=URL, method="POST", json=body)
    replayed = au.audit.replay(rec)
    assert "_audit_replay" in replayed
    # Hashes should match because canonical body is identical
    assert (
        replayed["_audit_replay"]["result_hash_now"]
        == rec["result_hash"]
    )


def test_replay_deterministic_sets_env_var(httpx_mock) -> None:
    URL = "https://api-test.austenite.org/v1/design-path"
    # Build record manually so we don't need an HTTP call during the
    # recording phase — only one request happens during replay.
    rec = au.audit.record(
        {"properties": {"sigma_y_MPa": 1535}}, endpoint="/v1/design-path",
        payload={"alloy": "AISI 4140"},
        deterministic_seed=42,
    )
    os.environ.pop("AUSTENITE_DETERMINISTIC_SEED", None)
    httpx_mock.add_response(
        url=URL, method="POST", json={"properties": {"sigma_y_MPa": 1535.0}},
    )
    au.audit.replay(rec, deterministic=True)
    assert os.environ.get("AUSTENITE_DETERMINISTIC_SEED") == "42"
    # Cleanup
    os.environ.pop("AUSTENITE_DETERMINISTIC_SEED", None)


def test_replay_with_string_audit_id_falls_back_to_server(httpx_mock) -> None:
    """A bare string audit_id triggers the legacy server-replay path."""

    URL = "https://api-test.austenite.org/v1/audit/replay"
    httpx_mock.add_response(
        url=URL,
        method="POST",
        json={
            "audit_id": "abc",
            "endpoint": "/v1/design-path",
            "payload": {},
            "original_result": {},
            "replay_result": {},
            "matches": True,
        },
    )
    res = au.audit.replay("abc")
    assert res.audit_id == "abc"


def test_replay_with_no_args_raises() -> None:
    with pytest.raises(TypeError):
        au.audit.replay()


# ---------------------------------------------------------------------------
# Legacy compatibility — server-side record/replay still work
# ---------------------------------------------------------------------------


def test_legacy_record_posts_to_server(httpx_mock) -> None:
    URL = "https://api-test.austenite.org/v1/audit/record"
    httpx_mock.add_response(
        url=URL,
        method="POST",
        json={"audit_id": "a-123", "timestamp": "2026-05-19T00:00:00Z"},
    )
    res = au.audit.record(
        call_id="vessel-V-2401",
        endpoint="/v1/design-path",
        payload={"alloy": "AISI 4140"},
        result={"sigma_y": 1535},
    )
    # Legacy mode returns AuditRecordResult
    assert res.audit_id == "a-123"


def test_legacy_replay_keyword_works(httpx_mock) -> None:
    URL = "https://api-test.austenite.org/v1/audit/replay"
    httpx_mock.add_response(
        url=URL,
        method="POST",
        json={
            "audit_id": "abc",
            "endpoint": "/v1/design-path",
            "payload": {},
            "original_result": {},
            "replay_result": {},
            "matches": True,
        },
    )
    res = au.audit.replay(audit_id="abc")
    assert res.matches is True


# ---------------------------------------------------------------------------
# Endpoint inference
# ---------------------------------------------------------------------------


def test_endpoint_inferred_from_pydantic_class_name() -> None:
    from austenite._models import (
        AmQualificationResult,
        ComplianceBayesianPPassResult,
    )

    am = AmQualificationResult(energy_density_J_mm3=80.0)
    rec = au.audit.record(am)
    assert rec["endpoint"] == "/v1/am-qualification"

    cbp = ComplianceBayesianPPassResult(
        spec="SA-516-70", T_C=400, S_allow_MPa=109,
        target_sigma_y_MPa=380, posteriorMean_MPa=420,
        posteriorStd_MPa=18, p_pass=0.987, verdict="PASS",
    )
    rec2 = au.audit.record(cbp)
    assert rec2["endpoint"] == "/v1/compliance-bayesian-p-pass"


def test_endpoint_replayers_registered() -> None:
    """The two seeded endpoints are present so the replay path is callable."""

    assert "/v1/design-path" in _ENDPOINT_REPLAYERS
    assert "/v1/compliance-bayesian-p-pass" in _ENDPOINT_REPLAYERS
