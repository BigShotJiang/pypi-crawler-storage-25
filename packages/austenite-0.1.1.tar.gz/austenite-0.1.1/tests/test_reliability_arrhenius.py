"""Tests for au.reliability.arrhenius_alt.

The fixed 4-cell test matrix below was constructed so that ln(t50) is
exactly linear in 1/T with slope = 0.7 eV / k_B. Verified by inverting:
slope k_B = 0.7 eV → slope = 0.7 / 8.617e-5 = 8123.4 K. The ratios
t50(423)/t50(513) ≈ exp(8123.4 · (1/423 - 1/513)) ≈ exp(3.367) ≈ 28.99,
matching the 120 / 7.5 ratio used here within rounding.
"""

from __future__ import annotations

import math

import pytest

import austenite as au


def test_arrhenius_recovers_Ea_to_15pct() -> None:
    """4-cell 423/453/483/513 K with t50 = 120/45/18/7.5 h → E_a ≈ 0.70 eV."""

    fit = au.reliability.arrhenius_alt(
        test_matrix=[
            {"T_K": 423, "t50_h": 120},
            {"T_K": 453, "t50_h": 45},
            {"T_K": 483, "t50_h": 18},
            {"T_K": 513, "t50_h": 7.5},
        ],
        use_T_K=323,
    )
    # Activation energy within 15 % of 0.70 eV
    assert 0.5 < fit.E_a_eV < 0.75, f"E_a={fit.E_a_eV} eV"
    assert fit.R2 > 0.99
    assert fit.t50_at_use_T > fit.test_matrix_t50_min if hasattr(fit, "test_matrix_t50_min") \
        else fit.t50_at_use_T > 7.5  # at 50 C, life should be much longer than 240 C test


def test_arrhenius_acceleration_factor_above_unity() -> None:
    """Use-T much colder than test cells → AF > 100 typically for E_a ≈ 0.7 eV."""

    fit = au.reliability.arrhenius_alt(
        test_matrix=[
            {"T_K": 423, "t50_h": 120},
            {"T_K": 453, "t50_h": 45},
            {"T_K": 483, "t50_h": 18},
            {"T_K": 513, "t50_h": 7.5},
        ],
        use_T_K=323,
    )
    assert fit.acceleration_factor > 100


def test_arrhenius_too_few_cells_returns_zero() -> None:
    """Single-cell input cannot fit a line — return E_a = 0."""

    fit = au.reliability.arrhenius_alt([{"T_K": 423, "t50_h": 120}], use_T_K=300)
    assert fit.E_a_eV == 0
    assert fit.R2 == 0


def test_arrhenius_handles_extra_keys_silently() -> None:
    """``n`` weight should be respected; unknown keys ignored."""

    fit = au.reliability.arrhenius_alt(
        test_matrix=[
            {"T_K": 423, "t50_h": 120, "n": 10, "unused_key": "x"},
            {"T_K": 453, "t50_h": 45, "n": 10},
            {"T_K": 483, "t50_h": 18, "n": 10},
            {"T_K": 513, "t50_h": 7.5, "n": 10},
        ],
        use_T_K=323,
    )
    assert fit.R2 > 0.99


def test_arrhenius_se_is_positive_and_small_for_clean_data() -> None:
    """1σ standard error on E_a should be tiny when R² ≈ 1."""

    fit = au.reliability.arrhenius_alt(
        test_matrix=[
            {"T_K": 423, "t50_h": 120},
            {"T_K": 453, "t50_h": 45},
            {"T_K": 483, "t50_h": 18},
            {"T_K": 513, "t50_h": 7.5},
        ],
        use_T_K=323,
    )
    assert fit.E_a_se > 0
    assert fit.E_a_se < 0.1 * fit.E_a_eV  # SE < 10% of value for high-R² fit
