"""Tests for the AM endpoints."""

from __future__ import annotations

import pytest

import austenite as au


QUAL_URL = "https://api-test.austenite.org/v1/am/qualification"
SWEEP_URL = "https://api-test.austenite.org/v1/am/sweep"


def test_qualification_happy_path(httpx_mock) -> None:
    httpx_mock.add_response(
        url=QUAL_URL,
        method="POST",
        json={
            "energy_density_J_mm3": 62.5,
            "melt_pool_regime": "conduction",
            "porosity_pct": 0.05,
            "properties": {"sigma_y_MPa": 1100, "sigma_uts_MPa": 1330},
            "compliance": {"spec": "ASTM-F3055", "pass": True},
        },
    )
    r = au.am.qualification(
        alloy="IN718",
        laser_power_W=250,
        scan_speed_mm_s=800,
        hatch_um=110,
        layer_um=40,
    )
    assert r.energy_density_J_mm3 == 62.5
    assert r.properties is not None
    assert r.properties.sigma_y_MPa == 1100


def test_qualification_500_retries_with_backend_http_propagates(httpx_mock) -> None:
    """``backend='http'`` must propagate engine errors (no native fallback)."""

    httpx_mock.add_response(url=QUAL_URL, method="POST", status_code=500, json={}, is_reusable=True)
    with pytest.raises(au.EngineError):
        au.am.qualification(
            alloy="IN718",
            laser_power_W=250,
            scan_speed_mm_s=800,
            hatch_um=110,
            layer_um=40,
            backend="http",
        )


def test_qualification_500_falls_back_to_native(httpx_mock) -> None:
    """Default backend=None falls back to the native pipeline on AusteniteError.

    Mirrors the calphad pattern — the engine returning 500 must not break
    the user's offline experience.
    """

    pytest.importorskip("numpy")
    httpx_mock.add_response(url=QUAL_URL, method="POST", status_code=500, json={}, is_reusable=True)
    r = au.am.qualification(
        alloy="IN718",
        laser_power_W=250,
        scan_speed_mm_s=800,
        hatch_um=110,
        layer_um=40,
    )
    # Native pipeline succeeded — VED must be finite and the result must
    # carry the native annotation in its extra fields.
    assert r.energy_density_J_mm3 > 0
    assert r.model_extra.get("backend") == "native"


def test_sweep_happy_path(httpx_mock) -> None:
    httpx_mock.add_response(
        url=SWEEP_URL,
        method="POST",
        json={
            "points": [
                {
                    "laser_power_W": 200,
                    "scan_speed_mm_s": 700,
                    "energy_density_J_mm3": 65.0,
                    "regime": "conduction",
                },
                {
                    "laser_power_W": 300,
                    "scan_speed_mm_s": 900,
                    "energy_density_J_mm3": 75.5,
                    "regime": "keyhole",
                },
            ],
            "process_window": {"power_min_W": 220, "power_max_W": 280},
        },
    )
    r = au.am.sweep(
        alloy="IN718",
        laser_power_W=[200, 300],
        scan_speed_mm_s=[700, 900],
        hatch_um=110,
        layer_um=40,
    )
    assert len(r.points) == 2
    assert r.points[1].regime == "keyhole"
    assert r.process_window is not None
