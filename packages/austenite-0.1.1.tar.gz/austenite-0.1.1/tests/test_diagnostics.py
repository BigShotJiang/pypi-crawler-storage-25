"""Tests for au.diagnostics — "Why is X happening?".

Covers the three diagnoses:

  * explain_equilibrium  — phase missing / present at T
  * explain_mcmc_convergence — R-hat / ESS triage
  * explain_am_failure — LPBF parameter root-cause
"""

from __future__ import annotations

import pytest

import austenite as au
from austenite.diagnostics import (
    AMFailureDiagnosis,
    EquilibriumDiagnosis,
    MCMCDiagnosis,
    explain_am_failure,
    explain_equilibrium,
    explain_mcmc_convergence,
)


# ---------------------------------------------------------------------------
# explain_equilibrium
# ---------------------------------------------------------------------------


def test_explain_equilibrium_sigma_below_window_is_diagnosed():
    """The verbatim pycalphad #390 case — σ missing at 500 K with Fe-Cr-Ni.

    The Fe-Cr-Ni σ stability window per Hertzman-Sundman 1982 is roughly
    870-1180 K. At 500 K the user should be told it's below the window
    and offered a higher-T retry suggestion.
    """

    diag = explain_equilibrium(
        composition={"Fe": 0.74, "Cr": 0.18, "Ni": 0.08},
        T_K=500,
        expected_phases=["BCC_A2", "SIGMA"],
    )
    assert isinstance(diag, EquilibriumDiagnosis)
    assert "SIGMA" in diag.missing
    assert any("below" in r.lower() for r in diag.reasons)
    # Should suggest a higher-temperature retry.
    assert any("870" in s or "900" in s or "1000" in s or "1100" in s
               or "1180" in s for s in diag.suggestions)
    # Should have a citation to Hertzman or Andersson.
    assert any(("Hertzman" in c) or ("Andersson" in c) for c in diag.citations)


def test_explain_equilibrium_neighborhood_scan_shows_recovery_at_higher_T():
    """At 800 K, SIGMA is still below the Fe-Cr-Ni window, but T+200 reaches it."""

    diag = explain_equilibrium(
        composition={"Fe": 0.74, "Cr": 0.18, "Ni": 0.08},
        T_K=800,
        expected_phases=["BCC_A2", "SIGMA"],
        scan_step_K=100.0,
    )
    # T+100 = 900, T+200 = 1000 — both inside the σ window for Fe-Cr-Ni.
    assert any("SIGMA" in v for k, v in diag.neighborhood_scan.items() if "+" in k)


def test_explain_equilibrium_with_observed_phases_pinpoints_missing():
    """When user passes observed_phases, missing set = expected - observed."""

    diag = explain_equilibrium(
        composition={"Fe": 0.74, "Cr": 0.18, "Ni": 0.08},
        T_K=1000,
        expected_phases=["BCC_A2", "SIGMA", "FCC_A1"],
        observed_phases=["BCC_A2", "FCC_A1"],
    )
    assert "SIGMA" in diag.missing
    # BCC_A2 was observed → not in missing
    assert "BCC_A2" not in diag.missing
    # No "unexpected" since observed ⊆ expected
    assert diag.unexpected == []


def test_explain_equilibrium_handles_unknown_phase_gracefully():
    """A phase the diagnostics module has no catalogue entry for shouldn't crash."""

    diag = explain_equilibrium(
        composition={"Fe": 0.95, "C": 0.005},
        T_K=400,
        expected_phases=["MYSTERY_PHASE_X"],
    )
    # No catalogue entry → diagnostics returns the empty-missing case.
    assert isinstance(diag, EquilibriumDiagnosis)


# ---------------------------------------------------------------------------
# explain_mcmc_convergence
# ---------------------------------------------------------------------------


def test_explain_mcmc_converged_when_all_r_hat_below_threshold():
    """Three params with R-hat < 1.1 → converged."""

    fake_posterior = type(
        "FakePost", (), {
            "r_hat": {"G0": 1.01, "G1": 1.03, "G2": 1.02},
            "ess": {"G0": 800, "G1": 750, "G2": 900},
            "chains": 4,
            "samples": 10000,
        }
    )()
    diag = explain_mcmc_convergence(fake_posterior)
    assert isinstance(diag, MCMCDiagnosis)
    assert diag.converged is True
    assert len(diag.per_param) == 3


def test_explain_mcmc_unconverged_suggests_more_chains_and_burn_in():
    """R-hat = 1.4 → multimodal; expect chain-count + DRAM suggestions."""

    fake = {
        "r_hat": {"G0": 1.4, "G1": 1.03},
        "ess": {"G0": 200, "G1": 800},
        "chains": 2,
        "samples": 3000,
    }
    diag = explain_mcmc_convergence(fake)
    assert diag.converged is False
    assert any("G0" in r for r in diag.reasons)
    # Should suggest more chains (currently 2) and more samples (currently 3000).
    suggestions_blob = " ".join(diag.suggestions)
    assert "chains" in suggestions_blob.lower()
    assert "dram" in suggestions_blob.lower() or "samples" in suggestions_blob.lower()


def test_explain_mcmc_empty_posterior_reports_no_diagnosis():
    """A bare object without r_hat → reports the failure mode, doesn't crash."""

    diag = explain_mcmc_convergence({})
    assert diag.converged is False
    assert diag.per_param == {}
    assert len(diag.reasons) >= 1
    assert any("R-hat" in r for r in diag.reasons)


# ---------------------------------------------------------------------------
# explain_am_failure
# ---------------------------------------------------------------------------


def test_explain_am_failure_keyhole_regime_recommends_higher_v():
    """High VED (keyhole) — suggest increasing v."""

    # P=250, v=600, h=110, t=30 → VED = 250 / (600*0.11*0.03) ≈ 126 J/mm^3
    result = {
        "laser_power_W": 250,
        "scan_speed_mm_s": 600,
        "hatch_um": 110,
        "layer_um": 30,
        "sigma_uts_MPa": 1140,
        "porosity_pct": 0.1,
        "spec": "ASTM-F3055",
        "passed": False,
    }
    diag = explain_am_failure(result)
    assert isinstance(diag, AMFailureDiagnosis)
    assert "keyhole" in diag.root_cause.lower()
    # Suggestion should mention increasing v.
    assert any("increase v" in s.lower() for s in diag.suggestions)
    # And cite Promoppatum or King.
    assert any(("Promoppatum" in c) or ("King" in c) for c in diag.citations)


def test_explain_am_failure_lack_of_fusion_recommends_lower_v_or_higher_P():
    """Low VED (LoF) — suggest decreasing v or raising P."""

    # P=100, v=1800, h=110, t=30 → VED = 100 / (1800*0.11*0.03) ≈ 16.8
    result = {
        "laser_power_W": 100,
        "scan_speed_mm_s": 1800,
        "hatch_um": 110,
        "layer_um": 30,
        "sigma_uts_MPa": 1000,
        "porosity_pct": 1.2,
        "spec": "ASTM-F3055",
        "passed": False,
    }
    diag = explain_am_failure(result)
    assert "lack" in diag.root_cause.lower() or "fusion" in diag.root_cause.lower()
    blob = " ".join(diag.suggestions).lower()
    assert ("decrease v" in blob) or ("increase p" in blob)


def test_explain_am_failure_f3055_min_uts_flagged():
    """UTS = 1140 MPa fails F3055 (≥1240 MPa); diagnosis must flag it."""

    result = {
        "laser_power_W": 250,
        "scan_speed_mm_s": 960,
        "hatch_um": 110,
        "layer_um": 30,
        "sigma_uts_MPa": 1140,
        "porosity_pct": 0.1,
        "spec": "ASTM-F3055",
        "passed": False,
    }
    diag = explain_am_failure(result)
    assert any("1240" in c for c in diag.failed_criteria)
    assert "F3055" in " ".join(diag.failed_criteria)


# ---------------------------------------------------------------------------
# Lazy-load via au namespace
# ---------------------------------------------------------------------------


def test_lazy_namespace():
    """au.diagnostics resolves via __getattr__ in the package init."""

    assert hasattr(au, "diagnostics")
    assert callable(au.diagnostics.explain_equilibrium)
