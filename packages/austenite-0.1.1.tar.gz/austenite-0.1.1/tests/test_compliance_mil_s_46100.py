"""Tests for the MIL-S-46100 (armor steel) checker."""

from __future__ import annotations

import pytest

import austenite as au
from austenite.compliance_standards import StandardVerdict, mil_s_46100


def test_mil_s_46100_pass_typical_rha() -> None:
    v = mil_s_46100.check(
        composition={"C": 0.30, "Mn": 1.20, "Si": 0.80,
                     "P": 0.010, "S": 0.005,
                     "Cr": 1.50, "Ni": 2.50, "Mo": 0.50},
        mechanical={"hardness_HB": 500, "hardness_HRC": 52,
                    "CVN_J_at_-40C_longitudinal": 20,
                    "CVN_J_at_-40C_transverse": 16},
        ballistic={"v50_m_per_s_per_in_thickness": 560,
                   "back_face_signature_mm": 40, "spall_class": "B"},
    )
    assert isinstance(v, StandardVerdict)
    assert v.passed is True
    assert v.spec_id == "MIL-S-46100"


def test_mil_s_46100_fail_hardness_too_low() -> None:
    v = mil_s_46100.check(
        composition={"C": 0.30, "Mn": 1.20, "Si": 0.80, "P": 0.010, "S": 0.005,
                     "Cr": 1.50, "Ni": 2.50, "Mo": 0.50},
        mechanical={"hardness_HB": 400, "hardness_HRC": 40,
                    "CVN_J_at_-40C_longitudinal": 20,
                    "CVN_J_at_-40C_transverse": 16},
    )
    assert v.passed is False
    # Both HB and HRC should fail
    assert any("hardness_HB" in f and "below min 477" in f for f in v.failed_items)
    assert any("hardness_HRC" in f and "below min 50" in f for f in v.failed_items)


def test_mil_s_46100_fail_ballistic_v50_below_requirement() -> None:
    v = mil_s_46100.check(
        composition={"C": 0.30, "Mn": 1.20, "Si": 0.80, "P": 0.010, "S": 0.005,
                     "Cr": 1.50, "Ni": 2.50, "Mo": 0.50},
        mechanical={"hardness_HB": 500, "hardness_HRC": 52,
                    "CVN_J_at_-40C_longitudinal": 20,
                    "CVN_J_at_-40C_transverse": 16},
        ballistic={"v50_m_per_s_per_in_thickness": 450,  # below 533
                   "back_face_signature_mm": 40},
    )
    assert v.passed is False
    assert any("V50" in f and "below required" in f for f in v.failed_items)


def test_mil_s_46100_fail_carbon_above_envelope() -> None:
    """Excess carbon (≥ 0.40 boundary) trends toward brittleness — fails at C > 0.40."""

    v = mil_s_46100.check(
        composition={"C": 0.50, "Mn": 1.20, "Si": 0.80,
                     "P": 0.010, "S": 0.005,
                     "Cr": 1.50, "Ni": 2.50, "Mo": 0.50},
    )
    assert v.passed is False
    assert any("C =" in f and "exceeds max 0.4" in f for f in v.failed_items)
