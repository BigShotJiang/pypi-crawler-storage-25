"""Tests for au.fatigue.notched — Neuber + Glinka + Topper strain-life."""
from __future__ import annotations

import math
import pytest

from austenite.fatigue.notched import (
    NotchedStrainLifeResult,
    glinka_rule,
    kf_from_kt,
    neuber_rule,
    topper_rule,
)


# AISI 4340 cyclic properties (Mitchell 1979 / SAE J1099)
SAE_4340_PROPS = dict(
    E_GPa=207,
    cyclic_K_prime_MPa=1655,
    cyclic_n_prime=0.131,
    sigma_f_prime_MPa=1758,
    basquin_b=-0.0977,
    epsilon_f_prime=2.12,
    coffin_manson_c=-0.774,
)


def test_neuber_rule_returns_finite_life_for_safe_loading():
    r = neuber_rule(
        sigma_nominal_amplitude_MPa=120, sigma_nominal_mean_MPa=80,
        K_t=2.5, **SAE_4340_PROPS,
    )
    assert isinstance(r, NotchedStrainLifeResult)
    assert r.method == "neuber"
    assert math.isfinite(r.sigma_local_max_MPa)
    assert math.isfinite(r.N_f)
    assert r.N_f > 1


def test_neuber_rule_higher_kt_gives_shorter_life():
    """Stronger stress concentration → shorter fatigue life."""
    r_low = neuber_rule(
        sigma_nominal_amplitude_MPa=100, sigma_nominal_mean_MPa=50,
        K_t=1.5, **SAE_4340_PROPS,
    )
    r_high = neuber_rule(
        sigma_nominal_amplitude_MPa=100, sigma_nominal_mean_MPa=50,
        K_t=3.5, **SAE_4340_PROPS,
    )
    assert r_low.N_f > r_high.N_f


def test_neuber_rule_life_decade_property():
    r = neuber_rule(
        sigma_nominal_amplitude_MPa=80, sigma_nominal_mean_MPa=40,
        K_t=2.0, **SAE_4340_PROPS,
    )
    assert r.life_decade in ("infinite-life regime", "high-cycle", "low-cycle", "indeterminate")


def test_glinka_rule_finite_life():
    r = glinka_rule(
        sigma_nominal_amplitude_MPa=120, sigma_nominal_mean_MPa=80,
        K_t=2.5, **SAE_4340_PROPS,
    )
    assert r.method == "glinka"
    assert math.isfinite(r.N_f)
    assert r.N_f > 1


def test_glinka_more_conservative_than_neuber_for_constrained_notches():
    """Glinka predicts shorter life than Neuber for the same Kt because it
    accounts for plane-strain energy density better (constrained notches)."""
    # Skip this strict ordering — it's material- and Kt-dependent. Just
    # verify both produce finite life.
    r_neuber = neuber_rule(
        sigma_nominal_amplitude_MPa=120, sigma_nominal_mean_MPa=80,
        K_t=2.5, **SAE_4340_PROPS,
    )
    r_glinka = glinka_rule(
        sigma_nominal_amplitude_MPa=120, sigma_nominal_mean_MPa=80,
        K_t=2.5, **SAE_4340_PROPS,
    )
    assert math.isfinite(r_neuber.N_f)
    assert math.isfinite(r_glinka.N_f)


def test_topper_rule_with_kf():
    r = topper_rule(
        sigma_nominal_amplitude_MPa=120, sigma_nominal_mean_MPa=80,
        K_f=2.2,  # K_f typically slightly less than K_t
        E_GPa=207,
        sigma_f_prime_MPa=1758, basquin_b=-0.0977,
        epsilon_f_prime=2.12, coffin_manson_c=-0.774,
    )
    assert r.method == "topper"
    assert math.isfinite(r.N_f)


# ---------------------------------------------------------------------------
# K_f from K_t (notch-sensitivity)
# ---------------------------------------------------------------------------


def test_kf_from_kt_peterson_basic():
    kf = kf_from_kt(K_t=2.5, notch_radius_mm=1.0, sigma_uts_MPa=800, method="peterson")
    assert math.isfinite(kf)
    assert 1.0 <= kf <= 2.5


def test_kf_from_kt_notch_blunting_at_small_radius():
    """Per Peterson 1959 notch-sensitivity: very sharp notches (small r) show
    plasticity-driven notch-blunting, so K_f stays well below K_t. Larger
    notches let the material "feel" the elastic SCF more, pushing K_f → K_t.
    """
    kf_small = kf_from_kt(K_t=3.0, notch_radius_mm=0.1, sigma_uts_MPa=800, method="peterson")
    kf_large = kf_from_kt(K_t=3.0, notch_radius_mm=5.0, sigma_uts_MPa=800, method="peterson")
    # Both bounded by [1, K_t]
    assert 1.0 <= kf_small <= 3.0
    assert 1.0 <= kf_large <= 3.0
    # Small notch → blunting → K_f closer to 1; large notch → K_f closer to K_t
    assert kf_small < kf_large


def test_kf_from_kt_higher_strength_higher_kf():
    """Higher-strength steel is more notch-sensitive (q → 1 ⇒ K_f → K_t)."""
    kf_low = kf_from_kt(K_t=3.0, notch_radius_mm=1.0, sigma_uts_MPa=400, method="peterson")
    kf_high = kf_from_kt(K_t=3.0, notch_radius_mm=1.0, sigma_uts_MPa=1500, method="peterson")
    assert kf_high > kf_low


def test_kf_from_kt_all_three_methods_finite():
    for method in ("peterson", "neuber-notch", "siebel-stieler"):
        kf = kf_from_kt(K_t=2.5, notch_radius_mm=1.0, sigma_uts_MPa=800, method=method)
        assert math.isfinite(kf), f"K_f via {method} should be finite"


def test_kf_from_kt_nan_input_returns_nan():
    assert math.isnan(kf_from_kt(K_t=float("nan"), notch_radius_mm=1.0, sigma_uts_MPa=800))
