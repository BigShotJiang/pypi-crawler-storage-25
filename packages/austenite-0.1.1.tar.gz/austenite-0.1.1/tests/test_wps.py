"""Tests for the ASME IX Weld Procedure Specification module.

Covers:
  * Free-text parsing round-trip
  * QW-200 / QW-251 / QW-461 validation
  * Revision tracking (history, supersede, current)
  * Sign + status transitions
  * Export PDF / XML round-trip
  * PQR-WPS qualification matching (QW-200)
  * Backend selection (json + sqlite)
"""

from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

import austenite as au
from austenite.wps import (
    WPS,
    PQR,
    BaseMetals,
    FillerMetals,
    Position,
    PreheatPostheat,
    Gases,
    ElectricalCharacteristics,
    JointDesign,
)


SAMPLE_WPS_TEXT = """
ABC Welding Corp.

Weld Procedure Specification per ASME BPVC Section IX
WPS-A001 Revision 3
Process: GTAW
Base Metal: P-Number 1, Group 2, SA-516 Gr.70
Thickness range: 6 to 25 mm
Filler: F-Number 6, A-Number 1, AWS A5.18 ER70S-6
Size: 2.4 mm
Joint Type: Butt joint, Single-V groove, Backing: yes
Root opening: 2 mm, Included angle: 60 deg
Positions qualified: 1G, 2G, 3G uphill
Electrical: DCEP, Amperage 90 to 130 A, Voltage 9 to 12 V
Heat input: 1.5 kJ/mm
Preheat: 100 C min, Interpass: 200 C max
PWHT: 595 C, hold 1.5 h
Shielding gas: Ar+2%CO2, Flow: 15 L/min
Multipass weave
UTS: 540 MPa, CVN: 47 J
Supporting PQR: PQR-A001
"""

SAMPLE_PQR_TEXT = """
Procedure Qualification Record per ASME IX QW-483
PQR-A001
Process: GTAW
Base Metal: P-Number 1 SA-516 Gr.70
Coupon thickness: 12 mm
Filler: F-Number 6, A-Number 1
Position: 3G
UTS: 540 MPa
Bend test: Pass
CVN: 47 J
"""


# ---------------------------------------------------------------------------
# Fixture: temp backend per test
# ---------------------------------------------------------------------------


@pytest.fixture()
def temp_backend(tmp_path: Path):
    backend = au.wps.backend("json", path=str(tmp_path / "wps_store"))
    yield backend
    # Reset module-level backend after test
    au.wps._BACKEND = None


@pytest.fixture()
def temp_sqlite_backend(tmp_path: Path):
    backend = au.wps.backend("sqlite", path=str(tmp_path / "wps.db"))
    yield backend
    au.wps._BACKEND = None


# ---------------------------------------------------------------------------
# 1. Parsing
# ---------------------------------------------------------------------------


def test_wps_parse_text_extracts_all_qw482_fields() -> None:
    """Parsed WPS round-trips every required QW-482 field."""

    wps = au.wps.parse(text=SAMPLE_WPS_TEXT)

    assert wps.weld_id == "WPS-A001"
    assert wps.revision == 3
    assert wps.process == "GTAW"

    # QW-403 base metal
    assert wps.base_metal.p_number == "1"
    assert "SA-516" in (wps.base_metal.spec or "")
    assert wps.base_metal.thickness_range_mm == (6.0, 25.0)

    # QW-404 filler
    assert wps.filler.f_number == "6"
    assert wps.filler.a_number == "1"
    assert "A5.18" in (wps.filler.aws_spec or "")

    # QW-405 / QW-461 positions
    assert set(wps.position.groove) == {"1G", "2G", "3G"}
    assert wps.position.progression == "uphill"

    # QW-409 electrical
    assert wps.electrical.current_type == "DCEP"
    assert wps.electrical.amperage_range_A == (90.0, 130.0)

    # QW-406 / QW-407 preheat / PWHT
    assert wps.preheat_postheat.preheat_C_min == 100.0
    assert wps.preheat_postheat.pwht_C == 595.0
    assert wps.preheat_postheat.pwht_hold_h == 1.5

    # QW-408 shielding gas
    assert "Ar" in (wps.gases.shielding or "")

    # QW-200 supporting PQR
    assert "PQR-A001" in wps.pqr_refs


def test_wps_parse_from_path(tmp_path: Path) -> None:
    """Parse handles a filesystem path."""

    f = tmp_path / "WPS-A001-Rev3.txt"
    f.write_text(SAMPLE_WPS_TEXT, encoding="utf-8")
    wps = au.wps.parse(f)
    assert wps.weld_id == "WPS-A001"
    assert wps.revision == 3


def test_wps_parse_missing_file_returns_stub() -> None:
    """A non-existent path is treated as inline text (no exception)."""

    wps = au.wps.parse("not_a_real_file_anywhere.pdf")
    # Should not crash — returns a (mostly-empty) stub WPS
    assert isinstance(wps, WPS)


def test_wps_parse_graceful_without_pypdf() -> None:
    """Parsing a PDF-magic byte string without pypdf installed should not raise."""

    # Build a tiny stub: %PDF header then garbage. With or without pypdf
    # installed, parse should return a WPS (possibly empty) — no crash.
    raw = b"%PDF-1.4\n%garbage bytes\n"
    wps = au.wps.parse(raw)
    assert isinstance(wps, WPS)


# ---------------------------------------------------------------------------
# 2. Validation (ASME IX QW-200 / QW-251 / QW-461 / QW-482)
# ---------------------------------------------------------------------------


def test_wps_validate_full_pass() -> None:
    """A fully-populated WPS validates clean."""

    wps = au.wps.parse(text=SAMPLE_WPS_TEXT)
    verdict = au.wps.validate(wps)
    assert verdict.passed, f"Expected pass; failed_items: {verdict.failed_items}"
    assert "ASME BPVC Section IX" in verdict.citation


def test_wps_validate_missing_process_fails() -> None:
    """A missing process is flagged per QW-251."""

    wps = au.wps.parse(text=SAMPLE_WPS_TEXT)
    wps.process = None
    verdict = au.wps.validate(wps)
    assert not verdict.passed
    assert any("Process" in f for f in verdict.failed_items)


def test_wps_validate_invalid_position_fails() -> None:
    """A non-QW-461 position (e.g. '7G') is flagged."""

    wps = au.wps.parse(text=SAMPLE_WPS_TEXT)
    wps.position.groove = ["7G"]
    verdict = au.wps.validate(wps)
    assert not verdict.passed
    assert any("'7G'" in f or "7G" in f for f in verdict.failed_items)


def test_wps_validate_missing_pqr_fails_qw200() -> None:
    """A WPS without any PQR reference fails QW-200."""

    wps = au.wps.parse(text=SAMPLE_WPS_TEXT)
    wps.pqr_refs = []
    verdict = au.wps.validate(wps)
    assert not verdict.passed
    assert any("PQR" in f and "QW-200" in f for f in verdict.failed_items)


def test_wps_validate_gtaw_requires_gas() -> None:
    """GTAW/GMAW/FCAW WPS without shielding gas (QW-408) fails."""

    wps = au.wps.parse(text=SAMPLE_WPS_TEXT)
    wps.gases.shielding = None
    verdict = au.wps.validate(wps)
    assert not verdict.passed
    assert any("QW-408" in f for f in verdict.failed_items)


# ---------------------------------------------------------------------------
# 3. Revision tracking + storage
# ---------------------------------------------------------------------------


def test_wps_history_and_supersede_sequence(temp_backend) -> None:
    """Sequence: save rev 1 → 2 → 3, supersede 2 with 3, check history."""

    base = au.wps.parse(text=SAMPLE_WPS_TEXT)
    for rev in (1, 2, 3):
        base.revision = rev
        base.status = "DRAFT"
        au.wps.save(base, reason=f"draft rev {rev}")

    hist = au.wps.history("WPS-A001")
    assert len(hist) == 3
    assert [r.revision for r in hist] == [1, 2, 3]
    assert all(r.status == "DRAFT" for r in hist)

    # Now supersede rev 2 with rev 3
    new_rev = au.wps.supersede(
        "WPS-A001", from_rev=2, to_rev=3,
        reason="Updated joint geometry per ECN-1234",
    )
    assert new_rev.status == "AUTHORIZED"

    # Refresh history — rev 2 is now SUPERSEDED, rev 3 AUTHORIZED
    hist2 = au.wps.history("WPS-A001")
    statuses = {r.revision: r.status for r in hist2}
    assert statuses[2] == "SUPERSEDED"
    assert statuses[3] == "AUTHORIZED"

    # current() returns the authorized one
    current = au.wps.current("WPS-A001")
    assert current.revision == 3
    assert current.status == "AUTHORIZED"


def test_wps_sign_and_audit_trail(temp_backend) -> None:
    """sign() flips status to AUTHORIZED and stamps signer + timestamp."""

    wps = au.wps.parse(text=SAMPLE_WPS_TEXT)
    au.wps.save(wps)
    au.wps.sign(wps, signer="J. Smith, P.E.", signature_method="digital")

    loaded = au.wps.load("WPS-A001")
    assert loaded.status == "AUTHORIZED"
    assert loaded.signed_by == "J. Smith, P.E."
    assert loaded.signature_method == "digital"
    assert loaded.signed_at is not None and "T" in loaded.signed_at  # ISO format


def test_wps_fingerprint_stable_across_round_trip(temp_backend) -> None:
    """The SHA-256 fingerprint is reproducible after JSON round-trip."""

    wps = au.wps.parse(text=SAMPLE_WPS_TEXT)
    fp1 = wps.fingerprint
    d = wps.to_dict()
    wps2 = WPS.from_dict(d)
    fp2 = wps2.fingerprint
    assert fp1 == fp2


# ---------------------------------------------------------------------------
# 4. Export round-trip (PDF / XML)
# ---------------------------------------------------------------------------


def test_wps_export_xml_round_trip(tmp_path: Path) -> None:
    """Exported XML re-parses to the same WPS."""

    wps = au.wps.parse(text=SAMPLE_WPS_TEXT)
    out = tmp_path / "WPS-A001.xml"
    au.wps.export_xml(wps, out)
    assert out.exists() and out.stat().st_size > 0

    reparsed = au.wps.parse(out)
    assert reparsed.weld_id == wps.weld_id
    assert reparsed.revision == wps.revision
    assert reparsed.process == wps.process
    assert reparsed.base_metal.p_number == wps.base_metal.p_number


def test_wps_export_pdf_writes_some_file(tmp_path: Path) -> None:
    """Export to PDF (or txt fallback if reportlab missing) writes a file."""

    wps = au.wps.parse(text=SAMPLE_WPS_TEXT)
    out = tmp_path / "WPS-A001.pdf"
    written = au.wps.export_pdf(wps, out)
    assert written.exists()
    assert written.stat().st_size > 100  # non-empty


# ---------------------------------------------------------------------------
# 5. PQR + qualification matching (QW-200 / QW-451)
# ---------------------------------------------------------------------------


def test_pqr_parse_text() -> None:
    """PQR free-text parser pulls out QW-483 fields."""

    pqr = au.wps.pqr.parse(text=SAMPLE_PQR_TEXT)
    assert pqr.pqr_id == "PQR-A001"
    assert pqr.process == "GTAW"
    assert pqr.base_metal_p_number == "1"
    assert pqr.base_metal_thickness_mm == 12.0
    assert pqr.filler_f_number == "6"
    assert pqr.mechanical.bend_test == "Pass"


def test_find_qualifying_pqrs(temp_backend) -> None:
    """find_qualifying_pqrs returns only PQRs that satisfy QW-200 + QW-451."""

    # Use a PQR whose coupon thickness (15 mm) qualifies 7.5-30 mm per
    # QW-451, covering the WPS thickness range of 6-25 mm.
    matching = au.wps.pqr.parse(text=SAMPLE_PQR_TEXT)
    matching.base_metal_thickness_mm = 15.0
    au.wps.pqr.save(matching)

    mismatch = PQR(
        pqr_id="PQR-X001",
        process="SMAW",  # different process
        base_metal_p_number="1",
        filler_f_number="4",  # different F-No
        base_metal_thickness_mm=15.0,
    )
    au.wps.pqr.save(mismatch)

    wps = au.wps.parse(text=SAMPLE_WPS_TEXT)
    # WPS thickness range = (6, 25) mm; bring it inside the QW-451 envelope
    # (PQR coupon 15 mm → allows 7.5 to 30 mm).
    wps.base_metal.thickness_range_mm = (8.0, 25.0)
    out = au.wps.find_qualifying_pqrs(wps)
    out_ids = {p.pqr_id for p in out}
    assert "PQR-A001" in out_ids
    assert "PQR-X001" not in out_ids


def test_find_qualifying_pqrs_thickness_outside_qw451_range(temp_backend) -> None:
    """A WPS that requests thickness above 2t-of-PQR is not qualified."""

    pqr = PQR(
        pqr_id="PQR-T001",
        process="GTAW",
        base_metal_p_number="1",
        filler_f_number="6",
        base_metal_thickness_mm=10.0,  # → qualifies 5 to 20 mm per QW-451.1
    )
    au.wps.pqr.save(pqr)

    wps = au.wps.parse(text=SAMPLE_WPS_TEXT)
    # SAMPLE WPS says thickness range 6 to 25 mm — 25 > 2*10 = 20, so PQR-T001 shouldn't qualify
    out = au.wps.find_qualifying_pqrs(wps)
    assert all(p.pqr_id != "PQR-T001" for p in out)


# ---------------------------------------------------------------------------
# 6. SQLite backend
# ---------------------------------------------------------------------------


def test_wps_sqlite_backend_round_trip(temp_sqlite_backend) -> None:
    """SQLite backend persists and loads correctly."""

    wps = au.wps.parse(text=SAMPLE_WPS_TEXT)
    au.wps.save(wps, reason="initial")
    loaded = au.wps.load("WPS-A001")
    assert loaded.weld_id == wps.weld_id
    assert loaded.process == wps.process

    listed = au.wps.list_wps()
    assert "WPS-A001" in listed


def test_wps_backend_invalid_kind() -> None:
    """Unknown backend kind raises ValueError."""

    with pytest.raises(ValueError):
        au.wps.backend("redis", path="./redis_store")


# ---------------------------------------------------------------------------
# 7. Edge cases
# ---------------------------------------------------------------------------


def test_wps_parse_empty_text_returns_stub() -> None:
    """An empty text string produces an empty (default-id) WPS."""

    wps = au.wps.parse(text="")
    assert isinstance(wps, WPS)
    assert wps.weld_id == "WPS-UNKNOWN"


def test_wps_validate_unrecognised_process() -> None:
    """A made-up process is flagged."""

    wps = au.wps.parse(text=SAMPLE_WPS_TEXT)
    wps.process = "FAKEWELD"
    verdict = au.wps.validate(wps)
    assert not verdict.passed


def test_wps_load_with_specific_revision(temp_backend) -> None:
    """load() with revision= returns that revision specifically."""

    wps = au.wps.parse(text=SAMPLE_WPS_TEXT)
    wps.revision = 1
    au.wps.save(wps)
    wps.revision = 2
    wps.process = "SMAW"
    au.wps.save(wps)

    r1 = au.wps.load("WPS-A001", revision=1)
    r2 = au.wps.load("WPS-A001", revision=2)
    assert r1.process == "GTAW"
    assert r2.process == "SMAW"
    # default → latest
    latest = au.wps.load("WPS-A001")
    assert latest.revision == 2
