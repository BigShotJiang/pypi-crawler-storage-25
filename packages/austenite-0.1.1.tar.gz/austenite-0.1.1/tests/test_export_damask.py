"""Tests for ``au.export.damask`` — DAMASK 3.x input-deck generator.

Verifies the four-file output is syntactically valid: ``material.yaml``
parses as YAML and contains the expected phenopowerlaw block,
``load.yaml`` carries the load-step / solver keys, ``geom.vti`` is
well-formed XML with the right voxel count, and ``run.sh`` invokes the
DAMASK_grid binary.

DAMASK is not installed in CI — we use a tiny in-test mock parser that
validates the file shape (key presence, count consistency, numeric
ranges).

References:
    * Roters F. et al., Acta Mater. 58 (2010) 1152.
    * Roters F. et al., Comput. Mater. Sci. 158 (2019) 420.
"""

from __future__ import annotations

import re
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path

import pytest

import austenite as au


# ---------------------------------------------------------------------------
# Helpers — tiny mock DAMASK parsers
# ---------------------------------------------------------------------------


def _parse_yaml_simple(text: str) -> dict:
    """Minimal block-style YAML parser for the bits we emit.

    Sufficient for verifying top-level keys exist and aren't garbage. We
    do NOT take a hard dep on PyYAML to keep the test suite stdlib-only.
    """

    keys: dict[str, str] = {}
    current_top: str | None = None
    for line in text.splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        # Top-level key (no leading whitespace, ends with `:`)
        if not line.startswith(" ") and line.rstrip().endswith(":"):
            current_top = line.rstrip().rstrip(":")
            keys[current_top] = ""
        elif current_top is not None:
            keys[current_top] += line + "\n"
    return keys


def _count_voxels_in_vti(text: str) -> int:
    """Parse the VTI XML and count DataArray entries."""

    root = ET.fromstring(text)
    arr = root.find(".//DataArray")
    assert arr is not None and arr.text is not None
    tokens = arr.text.split()
    return len(tokens)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_damask_writes_four_files(tmp_path: Path) -> None:
    res = au.export.damask(
        microstructure={"voxels": (8, 8, 8), "grains": 16},
        alloy="IN718",
        loading={"strain_rate_per_s": 1e-3, "strain_max": 0.05, "direction": "z"},
        output_dir=tmp_path,
    )
    expected = {"material.yaml", "load.yaml", "geom.vti", "run.sh"}
    assert set(res["files"]) == expected
    for fname in expected:
        assert (tmp_path / fname).exists(), f"missing {fname}"
    assert res["n_grains"] == 16
    assert res["shape"] == (8, 8, 8)
    assert "Roters" in res["citation"]


def test_damask_material_yaml_has_phenopowerlaw(tmp_path: Path) -> None:
    """material.yaml must declare a phenopowerlaw plastic law."""

    au.export.damask(
        microstructure={"voxels": (4, 4, 4), "grains": 8},
        alloy="IN718",
        loading={"strain_rate_per_s": 1e-3, "strain_max": 0.02, "direction": "x"},
        output_dir=tmp_path,
    )
    text = (tmp_path / "material.yaml").read_text(encoding="utf-8")
    keys = _parse_yaml_simple(text)
    # Top-level keys DAMASK 3 expects
    for k in ("homogenization", "phase", "material"):
        assert k in keys, f"missing top-level key {k} in material.yaml"
    # Phenopowerlaw plastic block
    assert "phenopowerlaw" in keys["phase"], "expected plastic.type: phenopowerlaw"
    assert "elastic:" in keys["phase"]
    assert "lattice:" in keys["phase"]
    # FCC IN718 should have C_11 / C_12 / C_44 elastic constants
    for cij in ("C_11", "C_12", "C_44"):
        assert cij in keys["phase"], f"missing elastic constant {cij}"


def test_damask_load_yaml_has_solver_and_loadstep(tmp_path: Path) -> None:
    au.export.damask(
        microstructure=(4, 4, 4),
        alloy="IN718",
        loading={"strain_rate_per_s": 5e-4, "strain_max": 0.10, "direction": "y",
                 "n_increments": 50},
        output_dir=tmp_path,
    )
    text = (tmp_path / "load.yaml").read_text(encoding="utf-8")
    keys = _parse_yaml_simple(text)
    assert "solver" in keys
    assert "loadstep" in keys
    # The strain rate appears in the body
    assert "5.000e-04" in text
    # N increments
    assert "N: 50" in text


def test_damask_geom_vti_is_valid_xml_with_correct_voxel_count(tmp_path: Path) -> None:
    """The VTI file must parse as XML and contain nx*ny*nz cell values."""

    nx, ny, nz = 5, 6, 7
    au.export.damask(
        microstructure={"voxels": (nx, ny, nz), "grains": 4},
        alloy="IN718",
        loading={"strain_rate_per_s": 1e-3, "strain_max": 0.05, "direction": "z"},
        output_dir=tmp_path,
    )
    text = (tmp_path / "geom.vti").read_text(encoding="utf-8")
    root = ET.fromstring(text)
    assert root.tag == "VTKFile"
    assert root.get("type") == "ImageData"
    n = _count_voxels_in_vti(text)
    assert n == nx * ny * nz, f"VTI voxel count {n} != expected {nx*ny*nz}"


def test_damask_run_sh_invokes_damask_grid_binary(tmp_path: Path) -> None:
    """run.sh must shell out to ``DAMASK_grid`` with the three deck files."""

    au.export.damask(
        microstructure=(4, 4, 4),
        alloy="IN718",
        loading={"strain_rate_per_s": 1e-3, "strain_max": 0.05, "direction": "z"},
        output_dir=tmp_path,
    )
    text = (tmp_path / "run.sh").read_text(encoding="utf-8")
    assert text.startswith("#!"), "run.sh must have a shebang"
    assert "DAMASK_grid" in text
    for flag in ("--load load.yaml", "--material material.yaml", "--geom geom.vti"):
        assert flag in text, f"run.sh missing {flag!r}"


def test_damask_alloy_fallback_records_citation_note(tmp_path: Path) -> None:
    """Unknown alloy → FALLBACK note in the citation, not a hard error."""

    res = au.export.damask(
        microstructure=(4, 4, 4),
        alloy="UNKNOWN-ALLOY-42",
        loading={"strain_rate_per_s": 1e-3, "strain_max": 0.05, "direction": "z"},
        output_dir=tmp_path,
    )
    assert "FALLBACK" in res["citation"] or "fallback" in res["citation"].lower()
    text = (tmp_path / "material.yaml").read_text(encoding="utf-8")
    assert "UNKNOWN-ALLOY-42" in text


def test_damask_known_alloys_ti6al4v_uses_hcp_lattice(tmp_path: Path) -> None:
    """Ti-6Al-4V should emit an HCP (hP) lattice card with C_33."""

    au.export.damask(
        microstructure=(4, 4, 4),
        alloy="Ti-6Al-4V",
        loading={"strain_rate_per_s": 1e-3, "strain_max": 0.05, "direction": "z"},
        output_dir=tmp_path,
    )
    text = (tmp_path / "material.yaml").read_text(encoding="utf-8")
    assert "lattice: hP" in text
    assert "C_33" in text  # HCP has 5 independent elastic constants


def test_damask_constitutive_overrides_take_effect(tmp_path: Path) -> None:
    au.export.damask(
        microstructure=(4, 4, 4),
        alloy="IN718",
        loading={"strain_rate_per_s": 1e-3, "strain_max": 0.05, "direction": "z"},
        output_dir=tmp_path,
        constitutive_overrides={"tau0_MPa": 1234.0, "n_exp": 33.0},
    )
    text = (tmp_path / "material.yaml").read_text(encoding="utf-8")
    # 1234 MPa = 1.234e9 Pa
    assert "1.234e+09" in text
    assert "n_sl: 33.000" in text or "n_sl: 33" in text
