"""Tests for heat-batch-aware Bayesian S-N fitter.

Covers:
  * Synthesised heats with known Basquin parameters → Bayesian recovery.
  * Shrinkage behaviour: small-data heats pulled toward MMPDS prior;
    big-data heats close to their own data.
  * Posterior-predictive calibration via N quantile prediction.
  * Save / load round-trip.
  * R-hat convergence.
  * Discrepancy computation.
"""

from __future__ import annotations

import math
import random
from pathlib import Path

import pytest

import austenite as au
from austenite.fatigue import (
    BasquinCurve,
    HeatSpecificSNFit,
    MMPDSPrior,
    heat_specific_sn_fit,
    list_pretrained_priors,
)


# ---------------------------------------------------------------------------
# Helpers — synth datasets with known true parameters
# ---------------------------------------------------------------------------


def _synth_heat(
    *,
    heat_id: str,
    sigma_f_true: float,
    b_true: float,
    n_points: int,
    seed: int,
    noise_log_N: float = 0.2,
    sigma_a_range: tuple[float, float] = (400.0, 800.0),
) -> list[dict[str, float]]:
    """Generate ``n_points`` synthetic (sigma_a, N) for a heat with known Basquin."""

    rng = random.Random(seed)
    out: list[dict[str, float]] = []
    for _ in range(n_points):
        sa = rng.uniform(*sigma_a_range)
        log_N_pred = math.log(0.5) + (1.0 / b_true) * math.log(sa / sigma_f_true)
        N = math.exp(log_N_pred + rng.gauss(0.0, noise_log_N))
        if N < 1:
            N = 1.0
        out.append({"heat_id": heat_id, "sigma_alt_MPa": sa, "N_cycles": N})
    return out


# ---------------------------------------------------------------------------
# 1. Pretrained-prior registry
# ---------------------------------------------------------------------------


def test_list_pretrained_priors_includes_4140_baseline() -> None:
    ids = list_pretrained_priors()
    assert "austenite/4140-MMPDS-baseline" in ids
    # All ids have citations
    for pid in ids:
        prior = au.fatigue.heat_specific.MMPDSPrior  # type alias
        # Actually load each
        from austenite.fatigue.heat_specific import _resolve_prior

        p = _resolve_prior(pid)
        assert p.citation
        assert p.b_mean < 0  # Basquin exponents are negative
        assert p.log_sigma_f_mean > 0


# ---------------------------------------------------------------------------
# 2. Bayesian recovery: synthesised heats, posterior recovers true sigma_f
# ---------------------------------------------------------------------------


def test_hierarchical_recovery_5_heats_30_points_each() -> None:
    """5 heats × 30 points → posterior recovers each heat's sigma_f to <8% error."""

    true_sigma_f = {
        "H1": 1900.0,
        "H2": 1750.0,
        "H3": 1850.0,
        "H4": 1950.0,
        "H5": 1700.0,
    }
    true_b = -0.085
    rows: list[dict[str, float]] = []
    for i, (h, sf) in enumerate(true_sigma_f.items()):
        rows.extend(
            _synth_heat(
                heat_id=h, sigma_f_true=sf, b_true=true_b,
                n_points=30, seed=42 + i, noise_log_N=0.15,
            )
        )

    fit = heat_specific_sn_fit(
        rows,
        pretrained_prior="austenite/4140-MMPDS-baseline",
        method="DRAM", chains=2, samples=2000, burn=500, seed=1,
    )
    assert isinstance(fit, HeatSpecificSNFit)
    assert set(fit.heat_specific_curves.keys()) == set(true_sigma_f.keys())

    for h, sf_true in true_sigma_f.items():
        post = fit.heat_specific_curves[h].sigma_f_mean_MPa
        err = abs(post - sf_true) / sf_true
        assert err < 0.10, (
            f"Heat {h}: posterior sigma_f={post:.0f}, true={sf_true:.0f}, "
            f"err={err:.2%} > 10%"
        )


def test_global_posterior_close_to_average_of_heats() -> None:
    """The pooled / global posterior sits near the mean of per-heat truths."""

    true_sigma_f = {"H1": 1900.0, "H2": 1750.0, "H3": 1850.0}
    true_b = -0.085
    rows: list[dict[str, float]] = []
    for i, (h, sf) in enumerate(true_sigma_f.items()):
        rows.extend(
            _synth_heat(
                heat_id=h, sigma_f_true=sf, b_true=true_b,
                n_points=30, seed=11 + i,
            )
        )

    fit = heat_specific_sn_fit(
        rows,
        pretrained_prior="austenite/4140-MMPDS-baseline",
        method="DRAM", chains=2, samples=2000, burn=500, seed=2,
    )
    mean_truth = sum(true_sigma_f.values()) / len(true_sigma_f)
    err = abs(fit.global_posterior.sigma_f_mean_MPa - mean_truth) / mean_truth
    assert err < 0.12, (
        f"Global sigma_f={fit.global_posterior.sigma_f_mean_MPa:.0f}, "
        f"mean truth={mean_truth:.0f}, err={err:.2%}"
    )


# ---------------------------------------------------------------------------
# 3. Shrinkage: heat with few points pulled toward MMPDS prior
# ---------------------------------------------------------------------------


def test_shrinkage_small_data_heat_pulled_toward_prior() -> None:
    """A heat with 3 points + a true σ_f far from the MMPDS prior should
    have its posterior shrunk *toward* the prior — i.e. posterior σ_f is
    closer to the MMPDS mean than its own MLE would be."""

    # MMPDS baseline for 4140 is sigma_f ≈ 1810. Pick a "true" sigma_f
    # well above (2200) and give the heat only 3 noisy points.
    sparse = _synth_heat(
        heat_id="SPARSE",
        sigma_f_true=2200.0,
        b_true=-0.085,
        n_points=3,
        seed=99,
        noise_log_N=0.25,
    )
    # And one well-sampled heat to anchor the global means
    rich = _synth_heat(
        heat_id="RICH",
        sigma_f_true=1850.0,
        b_true=-0.085,
        n_points=50,
        seed=88,
        noise_log_N=0.15,
    )
    rows = sparse + rich

    fit = heat_specific_sn_fit(
        rows,
        pretrained_prior="austenite/4140-MMPDS-baseline",
        method="DRAM", chains=2, samples=2000, burn=500, seed=3,
    )
    mmpds_mean = math.exp(fit.prior.log_sigma_f_mean)  # ≈ 1810
    sparse_post = fit.heat_specific_curves["SPARSE"].sigma_f_mean_MPa
    # Posterior should be < the noisy MLE (≈2200) — i.e. shrunk toward prior.
    # A robust assertion: posterior is meaningfully below the "true" value of 2200.
    assert sparse_post < 2200.0, (
        f"SPARSE posterior {sparse_post:.0f} should be < 2200 due to shrinkage"
    )
    # And it shouldn't fall below the MMPDS prior mean either (data still pulls up)
    assert sparse_post > 0.7 * mmpds_mean


def test_shrinkage_large_data_heat_close_to_own_truth() -> None:
    """With 200 datapoints, the posterior should track the heat's own
    truth — NOT the MMPDS prior."""

    # Pick a true sigma_f far from MMPDS (1810): use 2100.
    rows = _synth_heat(
        heat_id="BIGDATA",
        sigma_f_true=2100.0,
        b_true=-0.085,
        n_points=200,
        seed=7,
        noise_log_N=0.15,
    )
    fit = heat_specific_sn_fit(
        rows,
        pretrained_prior="austenite/4140-MMPDS-baseline",
        method="DRAM", chains=2, samples=2000, burn=500, seed=4,
    )
    post = fit.heat_specific_curves["BIGDATA"].sigma_f_mean_MPa
    # With 200 points the posterior should be much closer to 2100 than to MMPDS 1810.
    mmpds = math.exp(fit.prior.log_sigma_f_mean)
    assert abs(post - 2100.0) < abs(post - mmpds), (
        f"With 200 points posterior {post:.0f} should be closer to truth 2100 "
        f"than to MMPDS prior {mmpds:.0f}"
    )


# ---------------------------------------------------------------------------
# 4. Posterior-predictive: N quantile prediction is calibrated
# ---------------------------------------------------------------------------


def test_predict_returns_finite_cycles_at_5pct_p_failure() -> None:
    """The 5 % failure quantile is finite and below the median (50 %)."""

    rows = _synth_heat(
        heat_id="P1",
        sigma_f_true=1850.0,
        b_true=-0.085,
        n_points=30,
        seed=10,
    )
    fit = heat_specific_sn_fit(
        rows,
        pretrained_prior="austenite/4140-MMPDS-baseline",
        method="DRAM", chains=2, samples=1500, burn=400, seed=5,
    )
    curve = fit.heat_specific_curves["P1"]
    n05 = curve.predict(sigma_amplitude_MPa=600.0, R=-1.0, target_p_failure=0.05)
    n50 = curve.predict(sigma_amplitude_MPa=600.0, R=-1.0, target_p_failure=0.50)
    assert math.isfinite(n05) and math.isfinite(n50)
    assert n05 > 0 and n50 > 0
    assert n05 < n50, "5% quantile should be less than 50% quantile (lower bound)"


def test_predict_goodman_correction_reduces_life_at_positive_R() -> None:
    """R > -1 (tensile mean stress) should lower predicted N versus R = -1."""

    rows = _synth_heat(
        heat_id="GMN",
        sigma_f_true=1850.0,
        b_true=-0.085,
        n_points=30,
        seed=20,
    )
    fit = heat_specific_sn_fit(
        rows,
        pretrained_prior="austenite/4140-MMPDS-baseline",
        method="DRAM", chains=2, samples=1500, burn=400, seed=6,
    )
    curve = fit.heat_specific_curves["GMN"]
    n_reversed = curve.predict(sigma_amplitude_MPa=400.0, R=-1.0, target_p_failure=0.5)
    n_pulse = curve.predict(sigma_amplitude_MPa=400.0, R=0.1, target_p_failure=0.5)
    assert n_pulse < n_reversed, (
        f"Goodman: positive R should shorten life. R=-1: {n_reversed:.0f}, "
        f"R=0.1: {n_pulse:.0f}"
    )


# ---------------------------------------------------------------------------
# 5. R-hat convergence
# ---------------------------------------------------------------------------


def test_r_hat_finite_for_all_parameters() -> None:
    """Every parameter's R-hat is finite (not necessarily < 1.1 with short
    chains, but never NaN / inf)."""

    rows = _synth_heat(
        heat_id="R1",
        sigma_f_true=1850.0,
        b_true=-0.085,
        n_points=30,
        seed=33,
    )
    fit = heat_specific_sn_fit(
        rows,
        pretrained_prior="austenite/4140-MMPDS-baseline",
        method="DRAM", chains=3, samples=1000, burn=300, seed=8,
    )
    for k, v in fit.r_hat.items():
        assert math.isfinite(v), f"r_hat[{k}] = {v} not finite"
        assert v >= 1.0 or math.isclose(v, 1.0, abs_tol=1e-9)


# ---------------------------------------------------------------------------
# 6. Save / load round-trip
# ---------------------------------------------------------------------------


def test_save_and_load_pickle_round_trip(tmp_path: Path) -> None:
    rows = _synth_heat(
        heat_id="SL",
        sigma_f_true=1850.0,
        b_true=-0.085,
        n_points=20,
        seed=44,
    )
    fit = heat_specific_sn_fit(
        rows,
        pretrained_prior="austenite/4140-MMPDS-baseline",
        method="MH", chains=2, samples=800, burn=200, seed=9,
    )
    p = tmp_path / "fit.pkl"
    fit.save(p)
    loaded = HeatSpecificSNFit.load(p)
    assert loaded.method == "MH"
    assert set(loaded.heat_specific_curves) == set(fit.heat_specific_curves)
    # And the sigma_f mean round-trips exactly
    orig = list(fit.heat_specific_curves.values())[0]
    rt = list(loaded.heat_specific_curves.values())[0]
    assert orig.sigma_f_mean_MPa == rt.sigma_f_mean_MPa


def test_to_json_dumps_summary(tmp_path: Path) -> None:
    rows = _synth_heat(
        heat_id="J1",
        sigma_f_true=1850.0,
        b_true=-0.085,
        n_points=20,
        seed=55,
    )
    fit = heat_specific_sn_fit(
        rows,
        pretrained_prior="austenite/4140-MMPDS-baseline",
        method="MH", chains=2, samples=800, burn=200, seed=10,
    )
    p = tmp_path / "fit.json"
    fit.to_json(p)
    assert p.exists() and p.stat().st_size > 0
    import json
    data = json.loads(p.read_text(encoding="utf-8"))
    assert "global_posterior" in data
    assert "heat_specific_curves" in data
    assert "J1" in data["heat_specific_curves"]


# ---------------------------------------------------------------------------
# 7. Discrepancy from MMPDS prior is meaningful
# ---------------------------------------------------------------------------


def test_discrepancy_positive_for_stronger_than_prior_heat() -> None:
    """A heat with true sigma_f well above the MMPDS prior gives positive discrepancy."""

    rows = _synth_heat(
        heat_id="STRONG",
        sigma_f_true=2200.0,  # Much higher than MMPDS 1810
        b_true=-0.085,
        n_points=50,
        seed=66,
    )
    fit = heat_specific_sn_fit(
        rows,
        pretrained_prior="austenite/4140-MMPDS-baseline",
        method="DRAM", chains=2, samples=1500, burn=400, seed=11,
    )
    d = fit.discrepancy["STRONG"]
    assert d > 0, (
        f"Heat is stronger than MMPDS prior, expected positive discrepancy, got {d:+.3f}"
    )


# ---------------------------------------------------------------------------
# 8. Input validation
# ---------------------------------------------------------------------------


def test_unknown_prior_raises() -> None:
    rows = _synth_heat(
        heat_id="U",
        sigma_f_true=1800.0, b_true=-0.085,
        n_points=10, seed=77,
    )
    with pytest.raises(KeyError):
        heat_specific_sn_fit(rows, pretrained_prior="austenite/no-such-prior")


def test_unknown_method_raises() -> None:
    rows = _synth_heat(
        heat_id="U",
        sigma_f_true=1800.0, b_true=-0.085,
        n_points=10, seed=78,
    )
    with pytest.raises(ValueError):
        heat_specific_sn_fit(
            rows,
            pretrained_prior="austenite/4140-MMPDS-baseline",
            method="NUTS",  # not supported
        )


def test_empty_input_raises() -> None:
    with pytest.raises(ValueError):
        heat_specific_sn_fit(
            [],
            pretrained_prior="austenite/4140-MMPDS-baseline",
        )


def test_invalid_rows_filtered_silently() -> None:
    """Negative N / NaN values are filtered, finite ones are kept."""

    rows = [
        {"heat_id": "F1", "sigma_alt_MPa": 500.0, "N_cycles": 100000.0},
        {"heat_id": "F1", "sigma_alt_MPa": -100.0, "N_cycles": 100.0},  # negative sigma → drop
        {"heat_id": "F1", "sigma_alt_MPa": 500.0, "N_cycles": float("nan")},  # NaN → drop
        {"heat_id": "F1", "sigma_alt_MPa": 600.0, "N_cycles": 50000.0},
    ] + _synth_heat(
        heat_id="F1", sigma_f_true=1800.0, b_true=-0.085,
        n_points=20, seed=99,
    )
    fit = heat_specific_sn_fit(
        rows,
        pretrained_prior="austenite/4140-MMPDS-baseline",
        method="MH", chains=2, samples=500, burn=100, seed=12,
    )
    # Just confirm we got a fit back; bad rows didn't crash
    assert "F1" in fit.heat_specific_curves
