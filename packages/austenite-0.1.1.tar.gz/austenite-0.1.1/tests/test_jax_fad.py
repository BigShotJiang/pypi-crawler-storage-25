"""Tests for the JAX-traceable Level 2A FAD analysis.

API 579 Part 9 Annex 9C — covers each of the four crack geometries,
finite-difference vs autodiff consistency, and the sign convention of
the signed distance-to-curve metric.
"""

from __future__ import annotations

import math

import pytest


jax = pytest.importorskip("jax")
jnp = pytest.importorskip("jax.numpy")


# ---------------------------------------------------------------------------
# 1. API smoke
# ---------------------------------------------------------------------------


def test_fad_2a_runs_edge_crack() -> None:
    from austenite.jax_backend import fad_2a_jax, FadResult

    r = fad_2a_jax(
        a_mm=5.0, sigma=200.0,
        sigma_y=380.0, sigma_uts=550.0, KIc=80.0,
        geometry="edge-crack",
    )
    assert isinstance(r, FadResult)
    assert math.isfinite(float(r.distance_to_curve))
    assert math.isfinite(float(r.Lr))
    assert math.isfinite(float(r.Kr))


@pytest.mark.parametrize("geom", ["edge-crack", "surface-flaw", "through-wall", "center-crack"])
def test_fad_2a_all_geometries(geom) -> None:
    """All four geometries must return finite values."""

    from austenite.jax_backend import fad_2a_jax

    r = fad_2a_jax(
        a_mm=5.0, sigma=200.0,
        sigma_y=380.0, sigma_uts=550.0, KIc=80.0,
        geometry=geom,
    )
    assert math.isfinite(float(r.K_I_MPa_sqm))
    assert float(r.K_I_MPa_sqm) > 0


def test_fad_2a_rejects_unknown_geometry() -> None:
    from austenite.jax_backend import fad_2a_jax

    with pytest.raises(ValueError):
        fad_2a_jax(a_mm=5.0, sigma=200.0,
                   sigma_y=380.0, sigma_uts=550.0, KIc=80.0,
                   geometry="nope")


# ---------------------------------------------------------------------------
# 2. Sign of signed distance: small crack at low stress → inside
# ---------------------------------------------------------------------------


def test_fad_2a_inside_curve_when_safe() -> None:
    """Small crack at low stress is inside the FAD envelope -> distance > 0."""

    from austenite.jax_backend import fad_2a_jax

    r = fad_2a_jax(a_mm=1.0, sigma=80.0,
                   sigma_y=380.0, sigma_uts=550.0, KIc=120.0,
                   geometry="edge-crack")
    assert float(r.distance_to_curve) > 0
    assert float(r.acceptable) > 0.5


def test_fad_2a_outside_curve_when_unsafe() -> None:
    """Large crack at high stress -> outside the curve, negative distance."""

    from austenite.jax_backend import fad_2a_jax

    r = fad_2a_jax(a_mm=40.0, sigma=350.0,
                   sigma_y=380.0, sigma_uts=550.0, KIc=30.0,
                   geometry="edge-crack")
    assert float(r.distance_to_curve) < 0
    assert float(r.acceptable) < 0.5


# ---------------------------------------------------------------------------
# 3. Gradient finiteness + signs
# ---------------------------------------------------------------------------


def test_fad_2a_grad_a_negative_for_safe_point() -> None:
    """Increasing crack size should decrease distance-to-curve."""

    from austenite.jax_backend import fad_2a_jax

    def signed_dist(a, s):
        r = fad_2a_jax(a_mm=a, sigma=s,
                       sigma_y=380.0, sigma_uts=550.0, KIc=80.0,
                       geometry="edge-crack")
        return r.distance_to_curve

    g_a, g_s = jax.grad(signed_dist, argnums=(0, 1))(jnp.float32(5.0), jnp.float32(200.0))
    assert math.isfinite(float(g_a))
    assert math.isfinite(float(g_s))
    # d(dist)/da < 0 — bigger crack hurts the margin
    assert float(g_a) < 0
    # d(dist)/dσ < 0 — higher stress hurts the margin
    assert float(g_s) < 0


def test_fad_2a_grad_matches_finite_difference() -> None:
    """Central finite-difference and autodiff agree within 5 %."""

    from austenite.jax_backend import fad_2a_jax

    def signed_dist(a):
        return fad_2a_jax(a_mm=a, sigma=jnp.float32(200.0),
                          sigma_y=380.0, sigma_uts=550.0, KIc=80.0,
                          geometry="edge-crack").distance_to_curve

    a0 = jnp.float32(5.0)
    g_ad = float(jax.grad(signed_dist)(a0))
    eps = 1e-2
    fd = (float(signed_dist(a0 + eps)) - float(signed_dist(a0 - eps))) / (2 * eps)
    rel = abs(fd - g_ad) / max(abs(fd), 1e-6)
    assert rel < 0.05, f"FD={fd:.6f} vs AD={g_ad:.6f}; rel={rel:.2%}"


# ---------------------------------------------------------------------------
# 4. Sanity: Lr_max ≈ (σy+σuts)/(2σy) for ductile alloys
# ---------------------------------------------------------------------------


def test_fad_2a_Lr_max_matches_formula() -> None:
    from austenite.jax_backend import fad_2a_jax

    r = fad_2a_jax(a_mm=5.0, sigma=200.0,
                   sigma_y=400.0, sigma_uts=600.0, KIc=80.0,
                   geometry="edge-crack")
    expected = (400.0 + 600.0) / (2 * 400.0)  # = 1.25
    assert abs(float(r.Lr_max) - expected) < 1e-3
