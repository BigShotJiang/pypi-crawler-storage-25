"""Audit-lot tests — 50 synthetic heats → AuditReport → xlsx."""

from __future__ import annotations

import random
from pathlib import Path

import pytest

import austenite as au


AUDIT_URL = "https://api-test.austenite.org/v1/mtc-audit-lot"


def _make_mock_response(n_pass: int, n_warn: int, n_fail: int, *, spec: str) -> dict:
    """Build a mock /v1/mtc-audit-lot response with N heats."""
    total = n_pass + n_warn + n_fail
    per_heat = []
    flagged = []
    for i in range(n_pass):
        per_heat.append(
            {
                "index": i,
                "filename": f"cert_{i:03d}.pdf",
                "heat": f"H{i:05d}",
                "grade": "AISI 4140",
                "status": "pass",
                "n_fail": 0,
                "n_warn": 0,
                "checks": [
                    {"symbol": "C", "measured": 0.41, "min": 0.38, "max": 0.43,
                     "pass": True, "deviation_pct": 1.2, "reason": "within spec"},
                    {"symbol": "Mn", "measured": 0.85, "min": 0.75, "max": 1.00,
                     "pass": True, "deviation_pct": -2.9, "reason": "within spec"},
                ],
            }
        )
    for i in range(n_warn):
        idx = n_pass + i
        h = {
            "index": idx,
            "filename": f"cert_{idx:03d}.pdf",
            "heat": f"H{idx:05d}",
            "grade": "AISI 4140",
            "status": "near-boundary",
            "n_fail": 0,
            "n_warn": 1,
            "checks": [
                {"symbol": "C", "measured": 0.425, "min": 0.38, "max": 0.43,
                 "pass": True, "deviation_pct": 5.0, "reason": "within spec (near boundary)"},
            ],
        }
        per_heat.append(h)
        flagged.append(h)
    for i in range(n_fail):
        idx = n_pass + n_warn + i
        h = {
            "index": idx,
            "filename": f"cert_{idx:03d}.pdf",
            "heat": f"H{idx:05d}",
            "grade": "AISI 4140",
            "status": "fail",
            "n_fail": 1,
            "n_warn": 0,
            "checks": [
                {"symbol": "C", "measured": 0.50, "min": 0.38, "max": 0.43,
                 "pass": False, "deviation_pct": 23.0,
                 "reason": "> spec max (0.50 > 0.43)"},
            ],
        }
        per_heat.append(h)
        flagged.append(h)
    return {
        "summary": {
            "spec": spec,
            "spec_source": "ASTM A29 / SAE J404",
            "period": "2026-Q2",
            "total": total,
            "pass": n_pass,
            "near_boundary": n_warn,
            "fail": n_fail,
        },
        "per_heat": per_heat,
        "flagged": flagged,
    }


def test_audit_lot_from_dict_list(httpx_mock) -> None:
    httpx_mock.add_response(
        url=AUDIT_URL,
        method="POST",
        json=_make_mock_response(45, 2, 3, spec="AISI 4140 (UNS G41400)"),
    )

    parsed = [
        {"heat": f"H{i:05d}", "chemistry": {"C": 0.41, "Mn": 0.85}}
        for i in range(50)
    ]
    audit = au.mtc.audit_lot(parsed, spec="AISI 4140", period="2026-Q2")

    assert isinstance(audit, au.AuditReport)
    assert audit.summary["total"] == 50
    assert audit.summary["pass"] == 45
    assert audit.summary["near_boundary"] == 2
    assert audit.summary["fail"] == 3
    assert len(audit.flagged) == 5


def test_audit_lot_export_xlsx_writes_three_sheets(httpx_mock, tmp_path: Path) -> None:
    pytest.importorskip("openpyxl")

    httpx_mock.add_response(
        url=AUDIT_URL,
        method="POST",
        json=_make_mock_response(45, 2, 3, spec="AISI 4140 (UNS G41400)"),
    )

    parsed = [
        {"heat": f"H{i:05d}", "chemistry": {"C": 0.41, "Mn": 0.85}}
        for i in range(50)
    ]
    audit = au.mtc.audit_lot(parsed, spec="AISI 4140", period="2026-Q2")

    out = tmp_path / "audit_q2.xlsx"
    audit.export_xlsx(out)
    assert out.exists()

    from openpyxl import load_workbook

    wb = load_workbook(out)
    assert set(wb.sheetnames) == {"Summary", "Compliance", "Flagged"}

    summary = wb["Summary"]
    # Title cell
    assert summary["A1"].value == "MTC Lot Audit Report"
    # The "Total heats" / "Pass" / etc rows exist (rows 5-10ish)
    found_total = False
    found_fail = False
    for r in range(1, 20):
        v = summary.cell(row=r, column=1).value
        if v == "Total heats" and summary.cell(row=r, column=2).value == 50:
            found_total = True
        if v == "Fail" and summary.cell(row=r, column=2).value == 3:
            found_fail = True
    assert found_total
    assert found_fail

    compliance = wb["Compliance"]
    # header row + 50 data rows
    assert compliance.max_row >= 51

    flagged = wb["Flagged"]
    # header + 5 flagged rows
    assert flagged.max_row >= 6


def test_audit_lot_accepts_dataframe(httpx_mock) -> None:
    pd = pytest.importorskip("pandas")

    httpx_mock.add_response(
        url=AUDIT_URL,
        method="POST",
        json=_make_mock_response(2, 0, 0, spec="AISI 4140"),
    )
    df = pd.DataFrame(
        [
            {"file": "a.pdf", "heat": "H1", "grade": "4140", "C": 0.41, "Mn": 0.85},
            {"file": "b.pdf", "heat": "H2", "grade": "4140", "C": 0.40, "Mn": 0.86},
        ]
    )
    audit = au.mtc.audit_lot(df, spec="AISI 4140")
    assert audit.summary["total"] == 2


def test_audit_lot_unknown_spec_raises(httpx_mock) -> None:
    httpx_mock.add_response(
        url=AUDIT_URL,
        method="POST",
        status_code=400,
        json={"error": "unknown_spec", "spec": "XYZ", "hint": "no match"},
    )
    parsed = [{"heat": "H1", "chemistry": {"C": 0.4}}]
    with pytest.raises(au.ValidationError):
        au.mtc.audit_lot(parsed, spec="XYZ_no_such_spec")


def test_compare_diff_below_threshold(httpx_mock) -> None:
    a = {"composition": {"C": 0.41, "Mn": 0.85, "Cr": 1.02}}
    b = {"composition": {"C": 0.42, "Mn": 0.84, "Cr": 1.03}}
    diff = au.mtc.compare(a, b)
    # All deltas < 0.05 wt% → no flags
    assert diff["n_diff"] == 0


def test_compare_diff_above_threshold(httpx_mock) -> None:
    a = {"composition": {"C": 0.41, "Mn": 0.85, "Cr": 1.02}}
    b = {"composition": {"C": 0.55, "Mn": 0.85, "Cr": 1.02}}  # C up by 0.14
    diff = au.mtc.compare(a, b)
    assert diff["n_diff"] == 1
    assert diff["max_delta_element"] == "C"
    assert diff["elements"]["C"]["flag"] is True


def test_compare_missing_element_flagged(httpx_mock) -> None:
    a = {"composition": {"C": 0.41, "Mn": 0.85}}
    b = {"composition": {"C": 0.41}}
    diff = au.mtc.compare(a, b)
    assert diff["elements"]["Mn"]["flag"] is True
