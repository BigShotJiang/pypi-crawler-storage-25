"""Tests for the Bayesian-CALPHAD deep endpoint.

Covers named-dataset selection, R-hat convergence reporting, HPD interval
extraction, and posterior-predictive calibration score parsing.
"""

from __future__ import annotations

import pytest

import austenite as au


URL_DEEP = "https://api-test.austenite.org/v1/bayesian-calphad-deep"


def _mock_payload(dataset: str = "Hammar 1979 — Fe-Cr σ-phase") -> dict:
    """A realistic server response shape for a 3-parameter RK posterior."""

    return {
        "dataset": dataset,
        "datasetId": "hammar-1979-sigma",
        "family": "iron-base",
        "citation": "Hammar O., Met.Sci. 13 (1979) 17 — Fe-Cr σ-phase atom-probe + XRD assessment.",
        "paramNames": ["L_FCC_FeCr", "L_SIGMA_FeCr_1", "L_SIGMA_FeCr_2"],
        "nChains": 4,
        "nSamplesPerChain": 8000,
        "sampler": "dram",
        "acceptanceRate": 0.31,
        "posteriorMean": [-14953.0, 2487.5, -812.4],
        "posteriorStd": [615.2, 410.1, 312.7],
        "posteriorQuantiles": {
            "q05": [-15970.0, 1820.0, -1310.0],
            "q50": [-14955.0, 2490.0, -810.0],
            "q95": [-13930.0, 3170.0, -300.0],
        },
        "MAP": [-14960.0, 2495.0, -815.0],
        "rHat": [1.003, 1.011, 1.007],
        "r_hat": {
            "L_FCC_FeCr": 1.003,
            "L_SIGMA_FeCr_1": 1.011,
            "L_SIGMA_FeCr_2": 1.007,
        },
        "hpd50": [{"prob": 0.5, "lo": -15300.0, "hi": -14600.0}] * 3,
        "hpd80": [{"prob": 0.8, "lo": -15600.0, "hi": -14300.0}] * 3,
        "hpd95": [
            {"prob": 0.95, "lo": -16200.0, "hi": -13700.0},
            {"prob": 0.95, "lo": 1700.0, "hi": 3280.0},
            {"prob": 0.95, "lo": -1430.0, "hi": -190.0},
        ],
        "hpd_95": {
            "L_FCC_FeCr": {"prob": 0.95, "lo": -16200.0, "hi": -13700.0},
            "L_SIGMA_FeCr_1": {"prob": 0.95, "lo": 1700.0, "hi": 3280.0},
            "L_SIGMA_FeCr_2": {"prob": 0.95, "lo": -1430.0, "hi": -190.0},
        },
        "posteriorPredictive": {
            "calibrationScore": 0.946,
            "xs": [0.25, 0.30, 0.45],
            "median": [-1230.0, -1310.0, -1420.0],
            "lo95": [-1310.0, -1390.0, -1500.0],
            "hi95": [-1150.0, -1230.0, -1340.0],
            "obs": [{"x": 0.25, "y": -1232.0}],
        },
    }


# ---------------------------------------------------------------------------
# Basic happy-path
# ---------------------------------------------------------------------------


def test_calphad_deep_happy_path(httpx_mock) -> None:
    httpx_mock.add_response(url=URL_DEEP, method="POST", json=_mock_payload())
    post = au.bayesian.calphad_deep(
        composition={"Fe": 0.74, "Cr": 0.18, "Ni": 0.08},
        T_K=1273,
        dataset="hammar-1979-sigma",
        chains=4,
        samples=10_000,
        burn=2_000,
        method="dram",
    )
    assert post.dataset == "Hammar 1979 — Fe-Cr σ-phase"
    assert post.family == "iron-base"
    assert post.sampler == "dram"
    assert post.nChains == 4
    assert post.acceptanceRate == 0.31


# ---------------------------------------------------------------------------
# R-hat is returned as both list and ergonomic dict
# ---------------------------------------------------------------------------


def test_calphad_deep_r_hat_converged(httpx_mock) -> None:
    httpx_mock.add_response(url=URL_DEEP, method="POST", json=_mock_payload())
    post = au.bayesian.calphad_deep(dataset="hammar-1979-sigma")
    # All three R-hat values should be ≤ 1.1 (standard convergence check)
    for rhat in post.rHat:
        assert rhat <= 1.1, f"R-hat = {rhat}; expected ≤ 1.1"
    assert post.r_hat["L_FCC_FeCr"] == 1.003
    assert post.r_hat["L_SIGMA_FeCr_1"] == 1.011


# ---------------------------------------------------------------------------
# HPD intervals are present and ordered
# ---------------------------------------------------------------------------


def test_calphad_deep_hpd95(httpx_mock) -> None:
    httpx_mock.add_response(url=URL_DEEP, method="POST", json=_mock_payload())
    post = au.bayesian.calphad_deep(dataset="hammar-1979-sigma")
    assert len(post.hpd95) == 3
    for hpd in post.hpd95:
        assert hpd.lo < hpd.hi
    # ergonomic dict
    assert post.hpd_95["L_FCC_FeCr"].lo == -16200.0
    assert post.hpd_95["L_FCC_FeCr"].hi == -13700.0


# ---------------------------------------------------------------------------
# Posterior predictive calibration score is parsed
# ---------------------------------------------------------------------------


def test_calphad_deep_posterior_predictive_calibration(httpx_mock) -> None:
    httpx_mock.add_response(url=URL_DEEP, method="POST", json=_mock_payload())
    post = au.bayesian.calphad_deep(dataset="hammar-1979-sigma")
    assert post.posterior_predictive is not None
    score = post.posterior_predictive.calibration_score
    # Well-calibrated model should be near 0.95
    assert 0.80 <= score <= 1.0


# ---------------------------------------------------------------------------
# Each cited dataset can be selected
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "dataset_id,family",
    [
        ("hammar-1979-sigma", "iron-base"),
        ("bratberg-1996-in718-gamma-prime", "nickel-base"),
        ("hu-2009-al-cu", "aluminum-base"),
        ("andersson-1985-fe-cr-ni", "iron-base"),
        ("lu-2005-fe-c", "iron-base"),
        ("saunders-2003-ti-al", "titanium-base"),
    ],
)
def test_calphad_deep_dataset_selection(httpx_mock, dataset_id, family) -> None:
    payload = _mock_payload()
    payload["datasetId"] = dataset_id
    payload["family"] = family
    httpx_mock.add_response(url=URL_DEEP, method="POST", json=payload)
    post = au.bayesian.calphad_deep(dataset=dataset_id)
    assert post.datasetId == dataset_id
    assert post.family == family


# ---------------------------------------------------------------------------
# Hierarchical-dataset registry: the 3 new datasets are wired in correctly
# ---------------------------------------------------------------------------


def test_hierarchical_dataset_registry_contains_all_six() -> None:
    """All six hierarchical datasets are present in the Python registry."""

    from austenite.bayesian import HIERARCHICAL_DATASETS

    expected = {
        "hammar-1979-sigma",
        "bratberg-1996-in718-gamma-prime",
        "hu-2009-al-cu",
        "andersson-1985-fe-cr-ni",
        "lu-2005-fe-c",
        "saunders-2003-ti-al",
    }
    assert expected.issubset(set(HIERARCHICAL_DATASETS.keys()))


@pytest.mark.parametrize(
    "dataset_id,expected_family,expected_n_points",
    [
        ("andersson-1985-fe-cr-ni", "iron-base", 16),
        ("lu-2005-fe-c", "iron-base", 12),
        ("saunders-2003-ti-al", "titanium-base", 16),
    ],
)
def test_hierarchical_dataset_shape(dataset_id, expected_family, expected_n_points) -> None:
    """Each new dataset has the expected family and number of datapoints."""

    from austenite.bayesian import HIERARCHICAL_DATASETS

    d = HIERARCHICAL_DATASETS[dataset_id]
    assert d["family"] == expected_family
    assert len(d["datapoints"]) == expected_n_points
    assert d["nAlloys"] * d["nTemperatures"] == expected_n_points
    # Prior should have 3 RK parameters
    assert len(d["priorMean"]) == 3
    assert len(d["priorCov"]) == 3
    # Sanity-check the prior cov is positive
    for v in d["priorCov"]:
        assert v > 0


@pytest.mark.parametrize(
    "dataset_id",
    ["andersson-1985-fe-cr-ni", "lu-2005-fe-c", "saunders-2003-ti-al"],
)
def test_new_datasets_mcmc_converged(httpx_mock, dataset_id) -> None:
    """R-hat for each new dataset should be < 1.1 after MCMC.

    The server returns a payload with rHat = [1.003, 1.011, 1.007] in
    the mock; all values must satisfy the Brooks-Gelman convergence
    criterion (R-hat <= 1.1).
    """

    payload = _mock_payload()
    payload["datasetId"] = dataset_id
    httpx_mock.add_response(url=URL_DEEP, method="POST", json=payload)
    post = au.bayesian.calphad_deep(dataset=dataset_id, chains=4, samples=8000)
    for rhat in post.rHat:
        assert rhat <= 1.1, (
            f"dataset {dataset_id}: R-hat = {rhat}; expected ≤ 1.1"
        )


# ---------------------------------------------------------------------------
# 400 -> ValidationError
# ---------------------------------------------------------------------------


def test_calphad_deep_400_raises_validation(httpx_mock) -> None:
    httpx_mock.add_response(
        url=URL_DEEP, method="POST", status_code=400,
        json={"error": "unknown_dataset", "dataset": "nope"},
    )
    with pytest.raises(au.ValidationError):
        au.bayesian.calphad_deep(dataset="nope")


# ---------------------------------------------------------------------------
# Sends the correct payload shape
# ---------------------------------------------------------------------------


def test_calphad_deep_sends_correct_payload(httpx_mock) -> None:
    httpx_mock.add_response(url=URL_DEEP, method="POST", json=_mock_payload())
    au.bayesian.calphad_deep(
        composition={"Fe": 0.74, "Cr": 0.18, "Ni": 0.08},
        T_K=1273,
        dataset="hammar-1979-sigma",
        chains=4,
        samples=5000,
        burn=1000,
        method="dram",
        seed=7,
    )
    req = httpx_mock.get_requests()[-1]
    body = req.read().decode("utf-8")
    assert "hammar-1979-sigma" in body
    assert "dram" in body
    assert "5000" in body
    assert "\"chains\":4" in body
    assert "\"seed\":7" in body


# ---------------------------------------------------------------------------
# Tolerates extra forward-compatible fields
# ---------------------------------------------------------------------------


def test_calphad_deep_extra_response_fields(httpx_mock) -> None:
    payload = _mock_payload()
    payload["future_diagnostic"] = "anything"
    httpx_mock.add_response(url=URL_DEEP, method="POST", json=payload)
    post = au.bayesian.calphad_deep(dataset="hammar-1979-sigma")
    # New field is preserved as an extra attribute (extra="allow")
    assert post.posteriorMean == [-14953.0, 2487.5, -812.4]
