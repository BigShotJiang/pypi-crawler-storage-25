"""Tests for the ASTM A574 (alloy steel socket-head cap screws) checker."""

from __future__ import annotations

import pytest

import austenite as au
from austenite.compliance_standards import StandardVerdict, astm_a574


def test_astm_a574_pass_small_screw() -> None:
    v = astm_a574.check(
        composition={"C": 0.40, "Mn": 0.85, "Si": 0.25,
                     "P": 0.020, "S": 0.025,
                     "Cr": 0.95, "Mo": 0.20},
        mechanical={"sigma_uts_MPa": 1350, "sigma_y_MPa": 1200,
                    "elongation_pct": 12, "hardness_HRC": 41,
                    "reduction_of_area_pct": 40},
        size_class="screw_size_le_5_8_in",
    )
    assert isinstance(v, StandardVerdict)
    assert v.passed is True
    assert v.spec_id == "ASTM A574"
    assert "screw_size_le_5_8_in" in v.citation


def test_astm_a574_fail_uts_below_class_requirement() -> None:
    """≤5/8" class wants UTS ≥ 1310 MPa — 1200 fails."""

    v = astm_a574.check(
        composition={"C": 0.40, "Mn": 0.85, "P": 0.020, "S": 0.025,
                     "Cr": 0.95, "Mo": 0.20},
        mechanical={"sigma_uts_MPa": 1200, "sigma_y_MPa": 1100,
                    "elongation_pct": 12, "hardness_HRC": 39,
                    "reduction_of_area_pct": 40},
        size_class="screw_size_le_5_8_in",
    )
    assert v.passed is False
    assert any("sigma_uts_MPa" in f and "below min 1310" in f for f in v.failed_items)


def test_astm_a574_fail_hardness_above_class_max() -> None:
    """1-1/2" class caps HRC at 43; 48 fails."""

    v = astm_a574.check(
        composition={"C": 0.40, "Mn": 0.85, "P": 0.020, "S": 0.025,
                     "Cr": 0.95, "Mo": 0.20},
        mechanical={"sigma_uts_MPa": 1200, "sigma_y_MPa": 1100,
                    "elongation_pct": 12, "hardness_HRC": 48,
                    "reduction_of_area_pct": 40},
        size_class="screw_size_gt_1_to_1_1_2_in",
    )
    assert v.passed is False
    assert any("hardness_HRC" in f and "exceeds max 43" in f for f in v.failed_items)


def test_astm_a574_unknown_size_class_raises() -> None:
    with pytest.raises(ValueError, match="size_class 'huge' unknown"):
        astm_a574.check(composition={"C": 0.40}, size_class="huge")


def test_astm_a574_list_size_classes_complete() -> None:
    classes = set(astm_a574.list_size_classes())
    assert classes == {
        "screw_size_le_5_8_in",
        "screw_size_gt_5_8_to_1_in",
        "screw_size_gt_1_to_1_1_2_in",
    }
