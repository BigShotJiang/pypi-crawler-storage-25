"""Combined tests: forming + casting + cyclic_plasticity + thermophysics +
liquid_metal + tmp (thermomechanical processing)."""
from __future__ import annotations

import math

import pytest

# -------- forming --------
from austenite.forming import (
    barlat_89_yield_function,
    considere_instability_strain,
    fld0_keeler,
    fld_keeler_curve,
    fld_marciniak_kuczynski,
    hill_48_yield_function,
    hill_localised_neck_strain,
    hosford_yield_function,
    lankford_delta_r,
    lankford_r_bar,
    springback_angle_degrees,
)

# -------- casting --------
from austenite.casting import (
    CHVORINOV_K_TABLE,
    chvorinov_K,
    chvorinov_solidification_time,
    clyne_davies_csc,
    feeder_modulus_method,
    feurer_feeding_index,
    kou_combined_index,
    niyama_porosity_verdict,
    niyama_value,
    pellini_hot_tearing,
    rdg_mushy_zone_pressure_drop,
)

# -------- cyclic_plasticity --------
from austenite.cyclic_plasticity import (
    CHABOCHE_LIBRARY,
    ChabocheBackStress,
    cam_clay_yield_function,
    chaboche_evolve_back_stress,
    chaboche_parameters,
    chaboche_saturated_back_stress,
    chaboche_uniaxial_simulation,
    drucker_prager_yield_function,
    mohr_coulomb_to_drucker_prager,
)

# -------- thermophysics --------
from austenite.thermophysics import (
    CP_PURE_298K,
    CTE_PURE_um_m_K,
    MATTHIESSEN_COEFFICIENTS,
    bloch_gruneisen_resistivity,
    cte_rule_of_mixtures,
    curie_weiss_susceptibility,
    kersten_hysteresis_loss,
    matthiessen_resistivity,
    neumann_kopp_specific_heat,
    stoner_wohlfarth_switching_field,
    wiedemann_franz_thermal_conductivity,
)

# -------- liquid_metal --------
from austenite.liquid_metal import (
    LIQUID_METAL_SURFACE_TENSION,
    LIQUID_METAL_VISCOSITY,
    andrade_viscosity,
    iida_guthrie_surface_tension,
    marangoni_dsigma_dT,
    riboud_slag_viscosity,
    sieverts_H_solubility_in_Fe,
)

# -------- tmp --------
from austenite.tmp import (
    hodgson_gibbs_flow_stress_MPa,
    kocks_mecking_flow_stress,
    misaka_flow_stress_MPa,
    prasad_instability_parameter,
    prasad_power_dissipation_efficiency,
    shida_flow_stress_MPa,
)


# ===========================================================================
# FORMING
# ===========================================================================


def test_lankford_r_bar_steel_typical():
    assert math.isclose(lankford_r_bar(1.6, 1.2, 1.8), (1.6 + 2.4 + 1.8) / 4, rel_tol=1e-9)


def test_lankford_delta_r_low_means_isotropic():
    """Δr ≈ 0 → minimal earing."""
    dr = lankford_delta_r(1.0, 1.0, 1.0)
    assert math.isclose(dr, 0.0, abs_tol=1e-9)


def test_hill_48_isotropic_limits_to_von_mises():
    """For r_0 = r_45 = r_90 = 1, Hill-48 should give von Mises."""
    sigma_eq = hill_48_yield_function(100, 0, 0, r_0=1, r_45=1, r_90=1)
    # σ_eq for uniaxial 100 should be 100 (vm)
    assert math.isclose(sigma_eq, 100.0, rel_tol=0.05)


def test_hosford_a2_equals_von_mises():
    """Hosford with a=2 reduces to von Mises form."""
    sigma_eq = hosford_yield_function(100, 0, r_bar=1.0, a=2.0)
    assert math.isclose(sigma_eq, 100.0, rel_tol=0.05)


def test_barlat_returns_finite():
    sigma_eq = barlat_89_yield_function(100, 50, a=8.0, c=1.0, h=1.0)
    assert math.isfinite(sigma_eq)


def test_fld0_keeler_steel_positive():
    fld0 = fld0_keeler(t_mm=1.0, n_strain_hardening=0.22, alloy_family="steel")
    assert math.isfinite(fld0)
    assert 0.0 < fld0 < 1.0


def test_fld0_aluminum_lower_than_steel():
    fld0_steel = fld0_keeler(t_mm=1.0, n_strain_hardening=0.22, alloy_family="steel")
    fld0_al = fld0_keeler(t_mm=1.0, n_strain_hardening=0.22, alloy_family="aluminum")
    assert fld0_al < fld0_steel


def test_fld_keeler_curve_left_right_asymmetric():
    curve = fld_keeler_curve([-0.2, 0, 0.2], t_mm=1.0, n_strain_hardening=0.22)
    assert len(curve) == 3
    # left side (ε_2 < 0): ε_1 increases relative to plane strain (FLD0)
    # right side (ε_2 > 0): ε_1 also increases above FLD0
    assert curve[0] > curve[1]  # left branch higher than plane strain
    assert curve[2] > curve[1]  # right branch higher than plane strain


def test_fld_marciniak_kuczynski_returns_list():
    r = fld_marciniak_kuczynski(n_hardening=0.22, r_bar=1.5)
    assert "epsilon_2" in r and "epsilon_1" in r
    assert len(r["epsilon_1"]) > 50


def test_considere_strain_equals_n():
    assert considere_instability_strain(0.25) == 0.25


def test_hill_localised_neck_2n_for_plane_strain():
    assert hill_localised_neck_strain(0.25, plane_strain=True) == 0.5


def test_springback_higher_R_higher_angle():
    a_lo = springback_angle_degrees(R_bending_mm=5, t_mm=2, sigma_y_MPa=400, E_GPa=200)
    a_hi = springback_angle_degrees(R_bending_mm=50, t_mm=2, sigma_y_MPa=400, E_GPa=200)
    assert a_hi > a_lo


# ===========================================================================
# CASTING
# ===========================================================================


def test_chvorinov_basic():
    t = chvorinov_solidification_time(V_cm3=125, A_cm2=25, K_min_per_cm2=1.0)
    # t = 1.0 · (125/25)² = 25 min
    assert math.isclose(t, 25.0, rel_tol=1e-9)


def test_chvorinov_K_table_steel_higher_than_al():
    assert chvorinov_K("steel-sand") > chvorinov_K("Al-sand")


def test_chvorinov_K_unknown_returns_nan():
    assert math.isnan(chvorinov_K("nonexistent"))


def test_niyama_higher_G_better():
    ny_low = niyama_value(G_K_per_mm=0.5, dT_dt_K_per_s=2.0)
    ny_high = niyama_value(G_K_per_mm=2.0, dT_dt_K_per_s=2.0)
    assert ny_high > ny_low


def test_niyama_verdict_steel_threshold():
    """Ny > 1.0 for steel = low risk."""
    r_lo = niyama_porosity_verdict(0.5, alloy_family="steel")
    r_hi = niyama_porosity_verdict(2.0, alloy_family="steel")
    assert not r_lo["passed"]
    assert r_hi["passed"]


def test_pellini_hot_tearing_susceptible_above_critical():
    r = pellini_hot_tearing(strain_external=0.008, strain_critical=0.005)
    assert r["susceptible"]


def test_pellini_not_susceptible_below_critical():
    r = pellini_hot_tearing(strain_external=0.003, strain_critical=0.005)
    assert not r["susceptible"]


def test_clyne_davies_csc_basic():
    csc = clyne_davies_csc(t_fs_99=100, t_fs_90=85, t_fs_40=10)
    expected = (100 - 85) / (85 - 10)  # = 0.2
    assert math.isclose(csc, expected, rel_tol=1e-9)


def test_feurer_safe_at_low_ratio():
    r = feurer_feeding_index(shrinkage_velocity_m_s=0.01, feeding_velocity_m_s=1.0)
    assert r["verdict"] == "safe"


def test_feurer_tear_at_high_ratio():
    r = feurer_feeding_index(shrinkage_velocity_m_s=2.0, feeding_velocity_m_s=1.0)
    assert r["verdict"] == "tear-likely"


def test_rdg_pressure_drop_positive():
    dp = rdg_mushy_zone_pressure_drop(
        mu_liquid_Pa_s=0.005, strain_rate_per_s=1e-3, L_mushy_m=0.005,
        permeability_lambda2_m=1e-4,
    )
    assert math.isfinite(dp)
    assert dp > 0


def test_kou_index_higher_strain_higher_susceptibility():
    r_lo = kou_combined_index(dT_dfs_at_high_fs_K=100, max_strain_at_high_fs=0.001)
    r_hi = kou_combined_index(dT_dfs_at_high_fs_K=100, max_strain_at_high_fs=0.01)
    assert r_hi["kou_index"] > r_lo["kou_index"]


def test_feeder_modulus_sized_above_casting():
    r = feeder_modulus_method(casting_V_cm3=1000, casting_A_cm2=400)
    assert r["M_feeder_required_cm"] > r["M_casting_cm"]


# ===========================================================================
# CYCLIC PLASTICITY
# ===========================================================================


def test_chaboche_saturated_C_over_gamma():
    """α_sat = C/γ."""
    assert math.isclose(chaboche_saturated_back_stress(C=10_000, gamma=100), 100.0, rel_tol=1e-9)


def test_chaboche_evolve_at_alpha_sat_no_change():
    """At α = α_sat, monotonic loading produces no net change."""
    C, gamma = 10_000, 100
    alpha_sat = C / gamma
    new_alpha = chaboche_evolve_back_stress(alpha_sat, dp=0.001, depsilon_p=0.001, C=C, gamma=gamma)
    # (2/3)·C·dε_p − γ·α·dp = (2/3·10000·0.001) − (100·100·0.001) = 6.667 − 10 = -3.33
    # New alpha = 100 - 3.33 = 96.67 (not exactly saturated due to (2/3) factor)
    assert math.isfinite(new_alpha)


def test_chaboche_simulation_monotonic_tension():
    """Monotonic tension: σ should rise."""
    bs = [ChabocheBackStress(C=10_000, gamma=100)]
    eps_history = [i * 0.001 for i in range(10)]
    r = chaboche_uniaxial_simulation(eps_history, bs, sigma_y_0_MPa=200)
    sigmas = r["sigma_MPa"]
    assert len(sigmas) == 10
    # σ should grow then approach saturation
    assert sigmas[5] > sigmas[1]


def test_chaboche_library_has_8_alloys():
    for name in ["316L", "304SS", "IN718", "AISI 4140", "Cu-OFHC", "AA7075-T6", "P91", "Ti-6Al-4V"]:
        assert name in CHABOCHE_LIBRARY


def test_chaboche_parameters_returns_dict():
    p = chaboche_parameters("316L")
    assert "back_stresses" in p and "sigma_y_MPa" in p
    assert "citation" in p


def test_drucker_prager_returns_finite():
    f = drucker_prager_yield_function(100, 50, 20, alpha=0.05, k=80)
    assert math.isfinite(f)


def test_mohr_coulomb_to_drucker_prager_steel_like():
    r = mohr_coulomb_to_drucker_prager(cohesion_c_MPa=100, friction_angle_phi_deg=30)
    assert math.isfinite(r["alpha"])
    assert math.isfinite(r["k_MPa"])
    assert r["alpha"] > 0
    assert r["k_MPa"] > 0


def test_cam_clay_yield_function_basic():
    """At p = p_c/2, q = M·p_c/2: should be on the ellipse."""
    M = 1.0
    p_c = 100
    p = 50
    q = M * 50  # 50
    # f = q² + M²·p·(p - p_c) = 2500 + 1·50·(-50) = 2500 - 2500 = 0
    f = cam_clay_yield_function(p, q, M=M, p_c_MPa=p_c)
    assert math.isclose(f, 0.0, abs_tol=1e-3)


# ===========================================================================
# THERMOPHYSICS
# ===========================================================================


def test_bloch_gruneisen_high_T_linear():
    rho1 = bloch_gruneisen_resistivity(T_K=600, rho_residual_uohm_cm=0.1,
                                         theta_D_K=400, A_uohm_cm=10)
    rho2 = bloch_gruneisen_resistivity(T_K=1200, rho_residual_uohm_cm=0.1,
                                         theta_D_K=400, A_uohm_cm=10)
    # At high T (T >> Θ_D), ρ scales linearly with T
    assert rho2 > rho1


def test_matthiessen_zero_solute_returns_pure():
    rho = matthiessen_resistivity(
        rho_pure_uohm_cm=1.7,
        composition_wt_pct={},
        resistivity_coefficients_uohm_cm_per_wt_pct={},
    )
    assert math.isclose(rho, 1.7, rel_tol=1e-9)


def test_matthiessen_Cu_with_Ni():
    """Cu+1%Ni: ρ = 1.7 + 1.13 = 2.83 μΩ·cm."""
    rho = matthiessen_resistivity(
        rho_pure_uohm_cm=1.7,
        composition_wt_pct={"Ni": 1.0},
        resistivity_coefficients_uohm_cm_per_wt_pct=MATTHIESSEN_COEFFICIENTS["Cu"],
    )
    assert math.isclose(rho, 2.83, rel_tol=0.01)


def test_wiedemann_franz_basic():
    # Pure Cu at RT: ρ ≈ 1.7 μΩ·cm, T=298 → k ≈ 2.44e-8 · 298 / 1.7e-8 = 428 W/m/K
    k = wiedemann_franz_thermal_conductivity(rho_electrical_uohm_cm=1.7, T_K=298)
    # Pure Cu actual k ~ 400 W/m/K — within 10%
    assert 350 < k < 500


def test_neumann_kopp_basic():
    """Pure Cu: Cp ≈ 385 J/kg/K (NIST)."""
    cp = neumann_kopp_specific_heat({"Cu": 100}, Cp_pure_J_kgK=CP_PURE_298K)
    assert math.isclose(cp, 385.0, rel_tol=0.05)


def test_cte_rule_of_mixtures_weighted():
    """Cu+30Zn (brass): CTE ~ 0.7·16.5 + 0.3·30.2 = 20.6"""
    cte = cte_rule_of_mixtures({"Cu": 70, "Zn": 30})
    expected = 0.7 * 16.5 + 0.3 * 30.2
    assert math.isclose(cte, expected, rel_tol=0.01)


def test_curie_weiss_diverges_at_Tc():
    chi = curie_weiss_susceptibility(T_K=1043.0, Curie_temperature_K=1043.0)
    assert math.isinf(chi)


def test_curie_weiss_higher_T_lower_chi():
    chi_low = curie_weiss_susceptibility(T_K=1100, Curie_temperature_K=1043)
    chi_high = curie_weiss_susceptibility(T_K=2000, Curie_temperature_K=1043)
    assert chi_low > chi_high


def test_stoner_wohlfarth_easy_axis():
    """At θ=0 (along easy axis): H_switch = H_K."""
    H = stoner_wohlfarth_switching_field(H_anisotropy_T=1.0, theta_deg=0.0)
    assert math.isclose(H, 1.0, rel_tol=1e-3)


def test_kersten_hysteresis_loss_scales_with_B():
    """P_h ∝ B_max^n."""
    p_lo = kersten_hysteresis_loss(B_max_T=0.5, frequency_Hz=50, eta_hysteresis_J_kg_T2=30)
    p_hi = kersten_hysteresis_loss(B_max_T=1.5, frequency_Hz=50, eta_hysteresis_J_kg_T2=30)
    assert p_hi > p_lo


# ===========================================================================
# LIQUID METAL
# ===========================================================================


def test_iida_guthrie_pure_fe_at_Tm():
    """σ(T_m_Fe) = σ_0."""
    s = iida_guthrie_surface_tension("Fe", T_K=1811)
    assert math.isclose(s, 1865.0, rel_tol=1e-3)


def test_iida_guthrie_decreases_with_T():
    s_at_Tm = iida_guthrie_surface_tension("Fe", T_K=1811)
    s_super = iida_guthrie_surface_tension("Fe", T_K=2000)
    assert s_super < s_at_Tm


def test_marangoni_negative_for_clean_metal():
    """dσ/dT < 0 for Fe."""
    assert marangoni_dsigma_dT("Fe") < 0


def test_andrade_viscosity_higher_T_lower_viscosity():
    eta_low = andrade_viscosity("Fe", T_K=1811)
    eta_high = andrade_viscosity("Fe", T_K=2300)
    assert eta_high < eta_low


def test_riboud_slag_basic():
    """CaO-SiO2-Al2O3 ternary blast-furnace-slag composition."""
    eta = riboud_slag_viscosity(
        X_CaO=0.40, X_SiO2=0.40, X_Al2O3=0.20, T_K=1773,
    )
    assert math.isfinite(eta)
    assert eta > 0


def test_sieverts_zero_pH2_zero_solubility():
    H = sieverts_H_solubility_in_Fe(p_H2_bar=0, T_K=1873)
    assert H == 0.0


def test_sieverts_higher_pH2_higher_H():
    H_lo = sieverts_H_solubility_in_Fe(p_H2_bar=0.5, T_K=1873)
    H_hi = sieverts_H_solubility_in_Fe(p_H2_bar=2.0, T_K=1873)
    assert H_hi > H_lo


# ===========================================================================
# THERMOMECHANICAL PROCESSING (TMP)
# ===========================================================================


def test_misaka_finite_at_typical_hot_rolling():
    """1000 °C, 0.3 strain, 10/s strain rate, 0.15 C steel."""
    sigma = misaka_flow_stress_MPa(eps=0.3, eps_dot_per_s=10.0, T_K=1273, C_wt_pct=0.15)
    assert math.isfinite(sigma)
    assert 50 < sigma < 500  # typical hot-rolling flow stress range


def test_misaka_higher_strain_rate_higher_sigma():
    s_lo = misaka_flow_stress_MPa(eps=0.3, eps_dot_per_s=0.1, T_K=1273)
    s_hi = misaka_flow_stress_MPa(eps=0.3, eps_dot_per_s=100, T_K=1273)
    assert s_hi > s_lo


def test_misaka_higher_T_lower_sigma():
    s_lo_T = misaka_flow_stress_MPa(eps=0.3, eps_dot_per_s=10, T_K=900)
    s_hi_T = misaka_flow_stress_MPa(eps=0.3, eps_dot_per_s=10, T_K=1473)
    assert s_lo_T > s_hi_T


def test_hodgson_gibbs_higher_than_misaka_with_Nb():
    """Nb addition increases flow stress due to solute drag."""
    misaka = misaka_flow_stress_MPa(eps=0.3, eps_dot_per_s=10, T_K=1173, C_wt_pct=0.10)
    hg = hodgson_gibbs_flow_stress_MPa(eps=0.3, eps_dot_per_s=10, T_K=1173,
                                         C_wt_pct=0.10, Nb_wt_pct=0.04)
    assert hg > misaka


def test_kocks_mecking_saturates():
    """As ε → ∞, σ → σ_v."""
    sigma_at_strain_5 = kocks_mecking_flow_stress(eps=5.0, sigma_y_MPa=200,
                                                    theta_0_MPa=4000, sigma_v_MPa=500)
    assert math.isclose(sigma_at_strain_5, 500.0, rel_tol=0.01)


def test_kocks_mecking_starts_at_sigma_y():
    sigma_0 = kocks_mecking_flow_stress(eps=0.0, sigma_y_MPa=200,
                                          theta_0_MPa=4000, sigma_v_MPa=500)
    assert math.isclose(sigma_0, 200.0, rel_tol=1e-9)


def test_prasad_efficiency_m_0_5_gives_etap_0_67():
    """For m = 0.5: η = 2·0.5/(0.5+1) = 0.667 (safe DRX regime)."""
    eta = prasad_power_dissipation_efficiency(m_strain_rate_sensitivity=0.5)
    assert math.isclose(eta, 2.0 / 3.0, rel_tol=1e-9)


def test_prasad_efficiency_m_0_25():
    """At m = 0.25, η = 2·0.25/1.25 = 0.4 (mild DRX)."""
    eta = prasad_power_dissipation_efficiency(m_strain_rate_sensitivity=0.25)
    assert math.isclose(eta, 0.4, rel_tol=1e-9)


def test_shida_finite_at_typical_rolling():
    s = shida_flow_stress_MPa(eps=0.3, eps_dot_per_s=10, T_C=1000)
    assert math.isfinite(s)
    assert 50 < s < 400
