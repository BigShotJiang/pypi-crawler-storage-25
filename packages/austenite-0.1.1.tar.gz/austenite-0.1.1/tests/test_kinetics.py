"""Tests for au.kinetics — JMAK, grain growth, KWN, recrystallization."""
from __future__ import annotations

import math
import pytest

from austenite.kinetics import (
    Xrex_kinetics,
    avrami_classical_exponents,
    bm_growth_rate,
    burke_turnbull,
    critical_strain,
    fit_jmak_avrami_exponent,
    fraction_transformed,
    fraction_transformed_non_isothermal,
    grain_growth_with_temperature,
    hillert,
    lsw_coarsening,
    nucleation_rate_classical,
    sellars_whiteman_peak_strain,
    zener_hollomon_parameter,
    zener_pinning_radius,
)


# ---------------------------------------------------------------------------
# JMAK
# ---------------------------------------------------------------------------


def test_jmak_zero_time_returns_zero():
    assert fraction_transformed(0.0, k=1e-4, n=2.5) == 0.0


def test_jmak_negative_time_returns_zero():
    assert fraction_transformed(-1.0, k=1e-4, n=2.5) == 0.0


def test_jmak_long_time_saturates_at_one():
    X = fraction_transformed(1e10, k=1e-4, n=2.5)
    assert math.isclose(X, 1.0, rel_tol=1e-9)


def test_jmak_returns_in_unit_interval():
    for t in [10, 100, 1000, 10000]:
        X = fraction_transformed(t, k=1e-4, n=2.5)
        assert 0.0 <= X <= 1.0


def test_jmak_50_percent_consistency():
    """Test that the formulation gives ~50% at the expected t_50."""
    # X = 0.5 means exp(-k·t^n) = 0.5, so k·t^n = ln(2) = 0.693
    # For k=1e-4, n=2.5: t_50 = (0.693 / 1e-4)^(1/2.5)
    t_50 = (math.log(2.0) / 1e-4) ** (1.0 / 2.5)
    X_at_t50 = fraction_transformed(t_50, k=1e-4, n=2.5)
    assert math.isclose(X_at_t50, 0.5, rel_tol=1e-3)


def test_jmak_fit_recovers_known_params():
    """Generate synthetic data with n=2.5, k=1e-4 and fit it back."""
    times = [10, 30, 50, 100, 200, 400, 800]
    X = [fraction_transformed(t, k=1e-4, n=2.5) for t in times]
    n_fit, k_fit = fit_jmak_avrami_exponent(times, X)
    # Should recover within 5% relative
    assert math.isclose(n_fit, 2.5, rel_tol=0.05)
    assert math.isclose(k_fit, 1e-4, rel_tol=0.1)


def test_jmak_non_isothermal_constant_T_matches_isothermal():
    """Non-isothermal with constant T should give same result as isothermal."""
    T = 1000.0  # K
    # k(T) = 1e10 · exp(-Q/RT) with Q=200 kJ/mol
    # at T=1000: k ≈ 1e10 · exp(-24.06) ≈ 3.55e-1 s^(-2.5)
    # Pick t=10 s: should give X ≈ 1.0 since k·t^n is huge
    Ts = [T, T, T]
    ts = [0.0, 5.0, 10.0]
    X = fraction_transformed_non_isothermal(
        Ts, ts, k_arrhenius_prefactor=1e10, activation_energy_kJ_mol=200, n=2.5,
    )
    # Should give finite result in [0, 1]
    assert 0.0 <= X <= 1.0


def test_avrami_classical_returns_expected_values():
    d = avrami_classical_exponents()
    assert d["site-saturation-3D"] == 3.0
    assert d["constant-nucleation-3D"] == 4.0
    assert d["pearlite-2D-GB-nucleated"] == 2.0


# ---------------------------------------------------------------------------
# Grain growth
# ---------------------------------------------------------------------------


def test_burke_turnbull_zero_time_returns_initial():
    d = burke_turnbull(d0_um=20, t_s=0, K_um2_per_s=1.5)
    assert math.isclose(d, 20.0, rel_tol=1e-9)


def test_burke_turnbull_grows_with_time():
    d_1h = burke_turnbull(d0_um=20, t_s=3600, K_um2_per_s=1.5)
    d_2h = burke_turnbull(d0_um=20, t_s=7200, K_um2_per_s=1.5)
    assert d_2h > d_1h


def test_burke_turnbull_default_n2_parabolic():
    """For n=2: d² = d₀² + K·t."""
    d = burke_turnbull(d0_um=20, t_s=1000, K_um2_per_s=1.5)
    expected = math.sqrt(400 + 1.5 * 1000)
    assert math.isclose(d, expected, rel_tol=1e-9)


def test_burke_turnbull_n_4_slower_growth():
    """Higher n exponent → slower growth."""
    d_n2 = burke_turnbull(d0_um=20, t_s=10000, K_um2_per_s=1.5, n=2.0)
    d_n4 = burke_turnbull(d0_um=20, t_s=10000, K_um2_per_s=1.5, n=4.0)
    assert d_n4 < d_n2


def test_hillert_without_pinning_same_as_burke_turnbull():
    d_bt = burke_turnbull(d0_um=20, t_s=3600, K_um2_per_s=1.5)
    d_h = hillert(d0_um=20, t_s=3600, K_um2_per_s=1.5, zener_pinning_radius_um=None)
    assert math.isclose(d_bt, d_h, rel_tol=1e-9)


def test_hillert_with_pinning_caps_growth():
    """Zener pinning should limit final grain size to alpha·r."""
    d_pinned = hillert(d0_um=20, t_s=1e8, K_um2_per_s=1.5, zener_pinning_radius_um=15)
    assert d_pinned <= 1.5 * 15 + 1e-6


def test_zener_pinning_radius_basic():
    D_lim = zener_pinning_radius(particle_radius_um=10, volume_fraction=0.01)
    # D_lim = 4/3 · 10 / 0.01 = 1333 μm
    assert math.isclose(D_lim, 4.0 / 3.0 * 1000, rel_tol=1e-9)


def test_zener_pinning_higher_volume_fraction_smaller_grain():
    D1 = zener_pinning_radius(particle_radius_um=10, volume_fraction=0.001)
    D2 = zener_pinning_radius(particle_radius_um=10, volume_fraction=0.01)
    assert D2 < D1


def test_grain_growth_with_temperature_isothermal_matches_burke_turnbull():
    """Constant T should give same result as direct Burke-Turnbull with
    K = K_0·exp(-Q/RT)."""
    T_K = 1273  # 1000°C
    K_0 = 1.6e10
    Q = 350
    R = 8.314
    K_T = K_0 * math.exp(-Q * 1000 / (R * T_K))

    d_const_T = grain_growth_with_temperature(
        d0_um=20, T_history_K=[T_K, T_K], t_history_s=[0, 100],
        K_0_um2_per_s=K_0, activation_energy_kJ_mol=Q,
    )
    d_bt = burke_turnbull(d0_um=20, t_s=100, K_um2_per_s=K_T)
    assert math.isclose(d_const_T, d_bt, rel_tol=1e-3)


# ---------------------------------------------------------------------------
# KWN precipitation
# ---------------------------------------------------------------------------


def test_lsw_coarsening_grows_with_time():
    """t=0 → r₀; t=∞ → grows."""
    r0 = 5.0
    r_short = lsw_coarsening(r0_nm=r0, t_s=10,
                              gamma_J_m2=0.2, V_m_cm3=7.1, c_eq_at_frac=0.01,
                              D_m2_per_s=1e-19, T_K=973)
    r_long = lsw_coarsening(r0_nm=r0, t_s=10000,
                             gamma_J_m2=0.2, V_m_cm3=7.1, c_eq_at_frac=0.01,
                             D_m2_per_s=1e-19, T_K=973)
    assert r_long > r_short
    assert r_long >= r0


def test_lsw_higher_temperature_faster_coarsening():
    """Same time, higher T → larger r (because D and diffusivity increase)."""
    r_lo = lsw_coarsening(r0_nm=5, t_s=1000,
                           gamma_J_m2=0.2, V_m_cm3=7.1, c_eq_at_frac=0.01,
                           D_m2_per_s=1e-19, T_K=873)
    r_hi = lsw_coarsening(r0_nm=5, t_s=1000,
                           gamma_J_m2=0.2, V_m_cm3=7.1, c_eq_at_frac=0.01,
                           D_m2_per_s=1e-17, T_K=973)
    assert r_hi > r_lo


def test_bm_growth_rate_positive_when_supersaturated():
    """When c̄ > c_eq, growth rate should be positive."""
    rate = bm_growth_rate(
        r_nm=10, c_bulk_at_frac=0.05, c_eq_inf_at_frac=0.02,
        c_precipitate_at_frac=0.25, D_m2_per_s=1e-19,
    )
    assert math.isfinite(rate)
    assert rate > 0


def test_bm_growth_rate_negative_when_undersaturated():
    """When c̄ < c_eq, growth rate should be negative (dissolution)."""
    rate = bm_growth_rate(
        r_nm=10, c_bulk_at_frac=0.01, c_eq_inf_at_frac=0.02,
        c_precipitate_at_frac=0.25, D_m2_per_s=1e-19,
    )
    assert math.isfinite(rate)
    assert rate < 0


def test_nucleation_rate_basic():
    """Should return finite positive rate for reasonable inputs."""
    J = nucleation_rate_classical(
        T_K=973, delta_G_v_J_m3=-1e8, interfacial_energy_J_m2=0.2,
    )
    assert math.isfinite(J)
    assert J >= 0


def test_nucleation_rate_higher_T_higher_rate():
    """For fixed ΔG_v, higher T → more thermal kicks over barrier.
    Use realistic γ′-Ni3Al-style coherent precipitate values (γ ≈ 0.02 J/m²,
    ΔG_v large negative) so the barrier is in the right range for nucleation."""
    J_lo = nucleation_rate_classical(
        T_K=773, delta_G_v_J_m3=-2e9, interfacial_energy_J_m2=0.02,
    )
    J_hi = nucleation_rate_classical(
        T_K=1273, delta_G_v_J_m3=-2e9, interfacial_energy_J_m2=0.02,
    )
    # Both should be > 0 and J_hi > J_lo
    assert J_lo >= 0 and J_hi >= 0
    assert J_hi > J_lo


# ---------------------------------------------------------------------------
# Recrystallization
# ---------------------------------------------------------------------------


def test_zener_hollomon_basic():
    Z = zener_hollomon_parameter(strain_rate_per_s=1.0, T_K=1273, Q_def_kJ_mol=290)
    assert math.isfinite(Z)
    assert Z > 0


def test_zener_hollomon_higher_strain_rate_higher_Z():
    Z_lo = zener_hollomon_parameter(strain_rate_per_s=0.1, T_K=1273, Q_def_kJ_mol=290)
    Z_hi = zener_hollomon_parameter(strain_rate_per_s=10.0, T_K=1273, Q_def_kJ_mol=290)
    assert Z_hi > Z_lo


def test_zener_hollomon_lower_T_higher_Z():
    Z_low_T = zener_hollomon_parameter(strain_rate_per_s=1.0, T_K=1073, Q_def_kJ_mol=290)
    Z_high_T = zener_hollomon_parameter(strain_rate_per_s=1.0, T_K=1273, Q_def_kJ_mol=290)
    assert Z_low_T > Z_high_T


def test_sellars_peak_strain_304L():
    eps_peak = sellars_whiteman_peak_strain(d0_um=100, Z_per_s=1e12, alloy="304L")
    assert math.isfinite(eps_peak)
    assert 0.0 < eps_peak < 5.0  # typical range for hot deformation


def test_sellars_peak_strain_larger_grain_higher_peak():
    """Larger initial grain size → higher peak strain (Sellars-Whiteman)."""
    eps_small = sellars_whiteman_peak_strain(d0_um=50, Z_per_s=1e12, alloy="304L")
    eps_large = sellars_whiteman_peak_strain(d0_um=500, Z_per_s=1e12, alloy="304L")
    assert eps_large > eps_small


def test_critical_strain_default_ratio():
    eps_c = critical_strain(peak_strain=0.5)
    assert math.isclose(eps_c, 0.4, rel_tol=1e-3)


def test_Xrex_below_critical_strain_returns_zero():
    """Applied strain < ε_critical → no DRX → X_rex = 0."""
    X = Xrex_kinetics(eps_applied=0.1, eps_peak=0.5, t_s=100, alloy="304L")
    assert X == 0.0


def test_Xrex_above_critical_strain_grows_with_time():
    """ε_applied > ε_critical → X_rex grows with t."""
    X_short = Xrex_kinetics(eps_applied=0.7, eps_peak=0.5, t_s=1, alloy="304L")
    X_long = Xrex_kinetics(eps_applied=0.7, eps_peak=0.5, t_s=1000, alloy="304L")
    assert X_long >= X_short
    assert 0.0 <= X_long <= 1.0
