"""Tests for ``au.export.moose_input`` — MOOSE input-file generator.

MOOSE input syntax is GetPot — hierarchical brackets with key = value
lines. We don't install MOOSE in CI, so we implement a minimal parser
in-test that validates structural correctness of the deck.

References:
    * Permann C.J. et al., SoftwareX 11 (2020) 100430 — MOOSE multiphysics.
    * https://mooseframework.inl.gov/syntax/index.html
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest

import austenite as au


# ---------------------------------------------------------------------------
# Minimal MOOSE GetPot parser — only what we need for these tests
# ---------------------------------------------------------------------------


def _parse_moose_blocks(text: str) -> dict[str, str]:
    """Extract top-level ``[Block] ... []`` chunks from MOOSE input.

    Returns ``{block_name: body_text}``. Only handles top-level blocks.
    """

    blocks: dict[str, str] = {}
    pattern = re.compile(r"^\[(\w+)\]\s*$(.*?)^\[\]\s*$", re.MULTILINE | re.DOTALL)
    for m in pattern.finditer(text):
        name = m.group(1)
        body = m.group(2)
        blocks[name] = body
    return blocks


def _parse_subblocks(body: str) -> dict[str, str]:
    """Extract ``[name] ... []`` sub-blocks inside a top-level body."""

    sub: dict[str, str] = {}
    pattern = re.compile(r"^\s+\[(\w+)\]\s*$(.*?)^\s+\[\]\s*$", re.MULTILINE | re.DOTALL)
    for m in pattern.finditer(body):
        sub[m.group(1)] = m.group(2)
    return sub


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_moose_writes_file_with_canonical_block_sequence(tmp_path: Path) -> None:
    out = tmp_path / "pressure_vessel.i"
    res = au.export.moose_input(
        geometry={"type": "cylinder", "OD_mm": 500, "L_mm": 1000, "wall_mm": 12.5},
        physics=["solid_mechanics"],
        material="SA-516-70",
        boundary_conditions={"left": "fixed", "right": "P_MPa=2.5"},
        output_path=out,
    )
    assert out.exists()
    text = out.read_text(encoding="utf-8")
    blocks = _parse_moose_blocks(text)
    # Canonical MOOSE deck has these top-level blocks
    for k in ("Mesh", "Variables", "Kernels", "Materials", "BCs",
              "Executioner", "Outputs"):
        assert k in blocks, f"missing top-level block [{k}]"
    assert res["material"] == "SA-516-70"


def test_moose_solid_mechanics_emits_disp_xyz_variables(tmp_path: Path) -> None:
    out = tmp_path / "mech.i"
    au.export.moose_input(
        geometry={"type": "block", "Lx_mm": 100, "Ly_mm": 100, "Lz_mm": 100},
        physics=["solid_mechanics"],
        material="304L",
        boundary_conditions={"left": "fixed", "right": "P_MPa=1.0"},
        output_path=out,
    )
    text = out.read_text(encoding="utf-8")
    blocks = _parse_moose_blocks(text)
    var_subs = _parse_subblocks(blocks["Variables"])
    assert {"disp_x", "disp_y", "disp_z"}.issubset(set(var_subs.keys()))


def test_moose_heat_conduction_emits_T_variable_and_hc_kernel(tmp_path: Path) -> None:
    out = tmp_path / "thermal.i"
    au.export.moose_input(
        geometry={"type": "plate", "Lx_mm": 100, "Ly_mm": 100, "thickness_mm": 5},
        physics=["heat_conduction"],
        material="IN718",
        boundary_conditions={"left": "T_K=600", "right": "T_K=293"},
        output_path=out,
    )
    text = out.read_text(encoding="utf-8")
    blocks = _parse_moose_blocks(text)
    var_subs = _parse_subblocks(blocks["Variables"])
    assert "T" in var_subs
    ker_subs = _parse_subblocks(blocks["Kernels"])
    assert "hc" in ker_subs
    assert "HeatConduction" in blocks["Kernels"]


def test_moose_coupled_th_emits_both_disp_and_temperature(tmp_path: Path) -> None:
    out = tmp_path / "th.i"
    au.export.moose_input(
        geometry={"type": "cylinder", "OD_mm": 200, "L_mm": 500, "wall_mm": 8.0},
        physics=["coupled_th"],
        material="IN718",
        boundary_conditions={"left": "fixed", "inner": "T_K=750"},
        output_path=out,
    )
    text = out.read_text(encoding="utf-8")
    blocks = _parse_moose_blocks(text)
    var_subs = _parse_subblocks(blocks["Variables"])
    assert {"disp_x", "disp_y", "disp_z", "T"}.issubset(set(var_subs.keys()))
    # transient executioner — heat conduction is implicit transient
    assert "type = Transient" in blocks["Executioner"]


def test_moose_pressure_bc_converts_mpa_to_pascals(tmp_path: Path) -> None:
    out = tmp_path / "p.i"
    au.export.moose_input(
        geometry={"type": "cylinder", "OD_mm": 500, "L_mm": 1000, "wall_mm": 12.5},
        physics=["solid_mechanics"],
        material="SA-516-70",
        boundary_conditions={"left": "fixed", "right": "P_MPa=2.5"},
        output_path=out,
    )
    text = out.read_text(encoding="utf-8")
    # 2.5 MPa = 2.5e6 Pa
    assert re.search(r"factor\s*=\s*2\.500e\+0?6", text), text


def test_moose_material_aliases_resolve(tmp_path: Path) -> None:
    """Different spellings of the same alloy should resolve to one canonical entry."""

    for spec in ("SA-516-70", "sa-516 gr 70", "A516", "sa516"):
        out = tmp_path / f"{spec.replace(' ', '_')}.i"
        res = au.export.moose_input(
            geometry={"type": "block", "Lx_mm": 100, "Ly_mm": 100, "Lz_mm": 100},
            physics=["solid_mechanics"],
            material=spec,
            boundary_conditions={"left": "fixed"},
            output_path=out,
        )
        assert res["material"] == "SA-516-70", f"alias {spec!r} did not resolve"


def test_moose_unknown_boundary_emitted_as_warning_comment(tmp_path: Path) -> None:
    out = tmp_path / "warn.i"
    au.export.moose_input(
        geometry={"type": "block", "Lx_mm": 100, "Ly_mm": 100, "Lz_mm": 100},
        physics=["solid_mechanics"],
        material="304L",
        boundary_conditions={"left": "fixed", "totally-not-a-real-face": "P_MPa=1.0"},
        output_path=out,
    )
    text = out.read_text(encoding="utf-8")
    assert "WARNING" in text and "totally-not-a-real-face" in text


def test_moose_returns_material_and_physics_metadata(tmp_path: Path) -> None:
    res = au.export.moose_input(
        geometry={"type": "cylinder", "OD_mm": 100, "L_mm": 200, "wall_mm": 5.0},
        physics=["solid_mechanics", "heat_conduction"],
        material="Ti-6Al-4V",
        boundary_conditions={"left": "fixed", "right": "T_K=700"},
        output_path=tmp_path / "out.i",
    )
    assert res["material"] == "Ti-6Al-4V"
    assert "solid_mechanics" in res["physics"] and "heat_conduction" in res["physics"]
    assert set(res["valid_boundaries"]) >= {"left", "right", "inner", "outer"}
