"""Tests for au.reliability.system + RBD builder + k-of-n primitive."""

from __future__ import annotations

import math

import pytest

import austenite as au


# ---------------------------------------------------------------------------
# Simple series: R_sys = Π R_i
# ---------------------------------------------------------------------------


def test_pure_series_two_components() -> None:
    sys = au.reliability.system("A -> B", {"A": 0.9, "B": 0.8})
    assert math.isclose(sys.R_system, 0.9 * 0.8, rel_tol=1e-9)
    assert sys.weakest_id == "B"


# ---------------------------------------------------------------------------
# Pure parallel: R_sys = 1 - Π(1 - R_i)
# ---------------------------------------------------------------------------


def test_pure_parallel_two_components() -> None:
    sys = au.reliability.system("(A || B)", {"A": 0.8, "B": 0.7})
    expected = 1 - (1 - 0.8) * (1 - 0.7)  # = 0.94
    assert math.isclose(sys.R_system, expected, rel_tol=1e-9)


def test_pure_parallel_three_components() -> None:
    sys = au.reliability.system("(A || B || C)", {"A": 0.5, "B": 0.5, "C": 0.5})
    expected = 1 - (0.5) ** 3   # = 0.875
    assert math.isclose(sys.R_system, expected, rel_tol=1e-9)


# ---------------------------------------------------------------------------
# k-of-n
# ---------------------------------------------------------------------------


def test_2of3_with_identical_R_matches_binomial() -> None:
    sys = au.reliability.system("kof2(A,B,C)", {"A": 0.9, "B": 0.9, "C": 0.9})
    expected = 3 * (0.9 ** 2) * 0.1 + (0.9 ** 3)
    assert math.isclose(sys.R_system, expected, rel_tol=1e-9)


def test_3of3_equals_pure_series_for_identical_R() -> None:
    """3-of-3 with identical R is exactly series Π R_i."""

    sys = au.reliability.system("kof3(A,B,C)", {"A": 0.95, "B": 0.95, "C": 0.95})
    assert math.isclose(sys.R_system, 0.95 ** 3, rel_tol=1e-9)


def test_1of3_equals_pure_parallel() -> None:
    """1-of-3 with identical R is exactly parallel 1 − (1 − R)³."""

    sys = au.reliability.system("kof1(A,B,C)", {"A": 0.7, "B": 0.7, "C": 0.7})
    expected = 1 - 0.3 ** 3
    assert math.isclose(sys.R_system, expected, rel_tol=1e-9)


# ---------------------------------------------------------------------------
# Composed series + parallel + k-of-n (matches the task spec example)
# ---------------------------------------------------------------------------


def test_complex_topology_A_then_BC_then_2of3() -> None:
    sys = au.reliability.system(
        topology="A -> (B || C) -> kof3(D,E,F)",
        components={"A": 0.95, "B": 0.92, "C": 0.92,
                    "D": 0.88, "E": 0.88, "F": 0.88},
        k=2,
    )
    R_parallel = 1 - (1 - 0.92) ** 2   # = 0.9936
    R_kof2_3 = 3 * (0.88 ** 2) * 0.12 + (0.88 ** 3)
    expected = 0.95 * R_parallel * R_kof2_3
    assert math.isclose(sys.R_system, expected, rel_tol=1e-6)
    assert sys.weakest_id == "A"   # A=0.95 is the smallest top-level R


# ---------------------------------------------------------------------------
# RBD builder
# ---------------------------------------------------------------------------


def test_rbd_builder_matches_textual_topology() -> None:
    """Builder result should equal :func:`system` for the same logical network."""

    rbd = au.reliability.RBD()
    rbd.add("A", R=0.95)
    rbd.add_parallel(["B", "C"], R=[0.92, 0.92])
    rbd.add_kof3(["D", "E", "F"], R=[0.88, 0.88, 0.88], k=2)
    result = rbd.evaluate()
    text = au.reliability.system(
        topology="A -> (B || C) -> kof3(D,E,F)",
        components={"A": 0.95, "B": 0.92, "C": 0.92,
                    "D": 0.88, "E": 0.88, "F": 0.88},
        k=2,
    )
    assert math.isclose(result.R_system, text.R_system, rel_tol=1e-9)
