"""Tests for the AMS 6418 (AISI 4340 modified aerospace forging) checker."""

from __future__ import annotations

import pytest

import austenite as au
from austenite.compliance_standards import StandardVerdict, ams_6418


def test_ams_6418_pass_typical_4340_q_and_t() -> None:
    v = ams_6418.check(
        composition={"C": 0.40, "Mn": 0.75, "Si": 0.25,
                     "P": 0.005, "S": 0.003,
                     "Cr": 0.85, "Ni": 1.80, "Mo": 0.25},
        mechanical={"sigma_y_MPa": 1280, "sigma_uts_MPa": 1450,
                    "elongation_pct": 11, "hardness_HRC": 45,
                    "K_IC_MPa_sqrt_m": 65},
        heat_treatment={"austenitize_C": 845, "temper_C": 260},
    )
    assert isinstance(v, StandardVerdict)
    assert v.passed is True
    assert v.spec_id == "AMS 6418"


def test_ams_6418_fail_carbon_too_low() -> None:
    v = ams_6418.check(composition={"C": 0.30, "Mn": 0.75, "Cr": 0.85,
                                    "Ni": 1.80, "Mo": 0.25})
    assert v.passed is False
    assert any("C =" in f and "below min 0.38" in f for f in v.failed_items)


def test_ams_6418_fail_uts_above_envelope() -> None:
    """4340 modified must not over-shoot UTS (brittleness risk)."""

    v = ams_6418.check(
        composition={"C": 0.40, "Mn": 0.75, "Si": 0.25, "P": 0.005, "S": 0.003,
                     "Cr": 0.85, "Ni": 1.80, "Mo": 0.25},
        mechanical={"sigma_y_MPa": 1280, "sigma_uts_MPa": 1750,  # too high
                    "elongation_pct": 11, "hardness_HRC": 45},
    )
    assert v.passed is False
    assert any("sigma_uts_MPa" in f and "exceeds max 1620" in f for f in v.failed_items)


def test_ams_6418_fail_austenitize_too_low() -> None:
    v = ams_6418.check(
        composition={"C": 0.40, "Mn": 0.75, "Si": 0.25, "P": 0.005, "S": 0.003,
                     "Cr": 0.85, "Ni": 1.80, "Mo": 0.25},
        heat_treatment={"austenitize_C": 780, "temper_C": 260},
    )
    assert v.passed is False
    assert any("austenitize_C" in f and "below min 830" in f for f in v.failed_items)
