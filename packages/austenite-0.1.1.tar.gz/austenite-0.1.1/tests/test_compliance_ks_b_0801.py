"""Tests for the KS B 0801 (Korean tensile-test method) procedure checker."""

from __future__ import annotations

import pytest

import austenite as au
from austenite.compliance_standards import StandardVerdict, ks_b_0801


def test_ks_b_0801_pass_typical_procedure() -> None:
    v = ks_b_0801.check(
        mechanical={
            "gauge_length_mm": 50,
            "parallel_length_mm": 60,
            "test_temperature_C": 22,
            "strain_rate_per_s": 0.0008,
            "specimen_diameter_mm": 10,
            "calibration_class_iso_7500_1": 1.0,
        },
        specimen_geometry="No.4",
        fracture_inside_gauge=True,
    )
    assert isinstance(v, StandardVerdict)
    assert v.passed is True
    assert v.spec_id == "KS B 0801"


def test_ks_b_0801_fail_strain_rate_out_of_range() -> None:
    v = ks_b_0801.check(
        mechanical={
            "gauge_length_mm": 50,
            "parallel_length_mm": 60,
            "test_temperature_C": 22,
            "strain_rate_per_s": 0.01,  # too fast
            "specimen_diameter_mm": 10,
        },
    )
    assert v.passed is False
    assert any("strain_rate_per_s" in f and "exceeds max" in f for f in v.failed_items)


def test_ks_b_0801_fail_fracture_outside_gauge() -> None:
    v = ks_b_0801.check(
        mechanical={"gauge_length_mm": 50, "parallel_length_mm": 60,
                    "test_temperature_C": 22, "strain_rate_per_s": 0.0008,
                    "specimen_diameter_mm": 10},
        specimen_geometry="No.4",
        fracture_inside_gauge=False,
    )
    assert v.passed is False
    assert any("fracture outside parallel length" in f for f in v.failed_items)


def test_ks_b_0801_unknown_geometry_fails() -> None:
    v = ks_b_0801.check(
        mechanical={"gauge_length_mm": 50, "parallel_length_mm": 60,
                    "test_temperature_C": 22, "strain_rate_per_s": 0.0008,
                    "specimen_diameter_mm": 10},
        specimen_geometry="No.99",
        fracture_inside_gauge=True,
    )
    assert v.passed is False
    assert any("specimen_geometry" in f and "not in valid set" in f for f in v.failed_items)
