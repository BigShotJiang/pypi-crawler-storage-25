"""Tests for the calibrate / ShopPrior workflow.

Covers happy-path posterior return, CSV / JSON loading, .save / .load
round-trip via pickle, and the JSON serialisation path.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

import austenite as au


URL = "https://api-test.austenite.org/v1/calibrate"


def _mock_payload() -> dict:
    return {
        "id": "shop-prior-test-uuid",
        "pretrained": "austenite/4140-baseline-v0.1",
        "pretrained_description": "AISI 4140 σ_y baseline",
        "n_observations": 5,
        "obs_mean_MPa": 1520.0,
        "obs_std_MPa": 22.5,
        "prior_mean_MPa": 1535.0,
        "prior_std_MPa": 90.0,
        "obs_noise_MPa": 25.0,
        "posteriorMean_MPa": 1522.4,
        "posteriorStd_MPa": 11.7,
        "posteriorQuantiles": {"q05": 1502.5, "q50": 1522.3, "q95": 1542.0},
        "hpd_95": {"prob": 0.95, "lo": 1500.0, "hi": 1545.0},
        "rHat": 1.007,
        "acceptanceRate": 0.34,
        "nChains": 2,
        "nSamplesPerChain": 2400,
        "sampler": "dram",
        "citations": [
            {"source": "Krauss G., Steels (ASM 2005), Ch. 9", "note": "Pretrained prior"},
        ],
    }


# ---------------------------------------------------------------------------
# Happy path — list of floats as observations
# ---------------------------------------------------------------------------


def test_calibrate_happy_path_list(httpx_mock) -> None:
    httpx_mock.add_response(url=URL, method="POST", json=_mock_payload())
    shop = au.calibrate(
        pretrained="austenite/4140-baseline-v0.1",
        observations=[1500.0, 1520.0, 1530.0, 1515.0, 1535.0],
        method="dram",
    )
    assert isinstance(shop, au.ShopPrior)
    assert shop.id == "shop-prior-test-uuid"
    assert shop.pretrained == "austenite/4140-baseline-v0.1"
    assert shop.n_observations == 5
    assert shop.posterior_mean_MPa == 1522.4
    assert shop.r_hat == 1.007


# ---------------------------------------------------------------------------
# Observations from CSV
# ---------------------------------------------------------------------------


def test_calibrate_from_csv(httpx_mock, tmp_path) -> None:
    csv_path = tmp_path / "mill.csv"
    csv_path.write_text("sigma_y_MPa\n1500\n1520\n1530\n1515\n1535\n", encoding="utf-8")
    httpx_mock.add_response(url=URL, method="POST", json=_mock_payload())
    shop = au.calibrate(
        pretrained="austenite/4140-baseline-v0.1",
        observations=csv_path,
        method="dram",
    )
    req = httpx_mock.get_requests()[-1]
    body = req.read().decode("utf-8")
    assert "1500" in body and "1535" in body
    assert shop.n_observations == 5


def test_calibrate_from_csv_no_header(httpx_mock, tmp_path) -> None:
    csv_path = tmp_path / "mill.csv"
    csv_path.write_text("1500\n1520\n1530\n", encoding="utf-8")
    httpx_mock.add_response(url=URL, method="POST", json=_mock_payload())
    shop = au.calibrate(
        pretrained="austenite/4140-baseline-v0.1",
        observations=csv_path,
    )
    req = httpx_mock.get_requests()[-1]
    body = req.read().decode("utf-8")
    assert "1500" in body and "1520" in body and "1530" in body
    assert isinstance(shop, au.ShopPrior)


# ---------------------------------------------------------------------------
# Observations from JSON file
# ---------------------------------------------------------------------------


def test_calibrate_from_json(httpx_mock, tmp_path) -> None:
    json_path = tmp_path / "mill.json"
    json_path.write_text(
        json.dumps({"sigma_y_MPa": [1500, 1520, 1530, 1515, 1535]}),
        encoding="utf-8",
    )
    httpx_mock.add_response(url=URL, method="POST", json=_mock_payload())
    shop = au.calibrate(
        pretrained="austenite/4140-baseline-v0.1",
        observations=json_path,
    )
    assert shop.n_observations == 5


def test_calibrate_from_json_array_form(httpx_mock, tmp_path) -> None:
    json_path = tmp_path / "mill.json"
    json_path.write_text(json.dumps([1500, 1520, 1530, 1515, 1535]), encoding="utf-8")
    httpx_mock.add_response(url=URL, method="POST", json=_mock_payload())
    shop = au.calibrate(
        pretrained="austenite/4140-baseline-v0.1",
        observations=json_path,
    )
    req = httpx_mock.get_requests()[-1]
    body = req.read().decode("utf-8")
    assert "1500" in body
    assert isinstance(shop, au.ShopPrior)


# ---------------------------------------------------------------------------
# .save / .load round-trip via pickle
# ---------------------------------------------------------------------------


def test_shop_prior_pickle_round_trip(httpx_mock, tmp_path) -> None:
    httpx_mock.add_response(url=URL, method="POST", json=_mock_payload())
    shop = au.calibrate(
        pretrained="austenite/4140-baseline-v0.1",
        observations=[1500.0, 1520.0, 1530.0, 1515.0, 1535.0],
    )
    p = tmp_path / "mill-X-prior.pkl"
    shop.save(p)
    assert p.exists()

    restored = au.ShopPrior.load(p)
    assert restored.id == shop.id
    assert restored.pretrained == shop.pretrained
    assert restored.n_observations == shop.n_observations
    assert restored.posterior_mean_MPa == shop.posterior_mean_MPa
    assert restored.r_hat == shop.r_hat


# ---------------------------------------------------------------------------
# .to_json / .from_json round-trip (pickle-free)
# ---------------------------------------------------------------------------


def test_shop_prior_json_round_trip(httpx_mock, tmp_path) -> None:
    httpx_mock.add_response(url=URL, method="POST", json=_mock_payload())
    shop = au.calibrate(
        pretrained="austenite/4140-baseline-v0.1",
        observations=[1500.0, 1520.0, 1530.0, 1515.0, 1535.0],
    )
    p = tmp_path / "mill-X-prior.json"
    shop.to_json(p)
    assert p.exists()
    data = json.loads(p.read_text(encoding="utf-8"))
    assert data["id"] == shop.id

    restored = au.ShopPrior.from_json(p)
    assert restored.id == shop.id
    assert restored.posterior_mean_MPa == shop.posterior_mean_MPa


# ---------------------------------------------------------------------------
# Missing file raises a clean error
# ---------------------------------------------------------------------------


def test_calibrate_missing_file_raises(tmp_path) -> None:
    bad = tmp_path / "does_not_exist.csv"
    with pytest.raises(FileNotFoundError):
        au.calibrate(
            pretrained="austenite/4140-baseline-v0.1",
            observations=bad,
        )


# ---------------------------------------------------------------------------
# 400 -> ValidationError for unknown pretrained id
# ---------------------------------------------------------------------------


def test_calibrate_unknown_pretrained_raises(httpx_mock) -> None:
    httpx_mock.add_response(
        url=URL, method="POST", status_code=400,
        json={"error": "unknown_pretrained", "message": "not in registry"},
    )
    with pytest.raises(au.ValidationError):
        au.calibrate(
            pretrained="austenite/does-not-exist",
            observations=[1500.0, 1520.0],
        )


# ---------------------------------------------------------------------------
# Records form (dict per row) also works
# ---------------------------------------------------------------------------


def test_calibrate_records_form(httpx_mock) -> None:
    httpx_mock.add_response(url=URL, method="POST", json=_mock_payload())
    obs = au.CalibrateObservations(
        records=[
            {"sigma_y_MPa": 1500.0, "heat": "H1"},
            {"sigma_y_MPa": 1520.0, "heat": "H2"},
        ]
    )
    shop = au.calibrate(
        pretrained="austenite/4140-baseline-v0.1",
        observations=obs,
    )
    assert isinstance(shop, au.ShopPrior)


# ---------------------------------------------------------------------------
# Repr is informative
# ---------------------------------------------------------------------------


def test_shop_prior_repr(httpx_mock) -> None:
    httpx_mock.add_response(url=URL, method="POST", json=_mock_payload())
    shop = au.calibrate(
        pretrained="austenite/4140-baseline-v0.1",
        observations=[1500.0, 1520.0, 1530.0],
    )
    s = repr(shop)
    assert "ShopPrior" in s
    assert "austenite/4140-baseline-v0.1" in s
    assert "1522.4" in s
