"""Tests for au.rbi.api_581_full + fleet_screen + corrosion rate + risk matrix.

The 5×5 risk-matrix coverage tests reproduce the API RP 581 3rd ed. (2016)
Part 1 §4.1 Table 4.1 banding for representative POF / COF combinations,
spanning every corner of the green/yellow/orange/red colour scheme.

The corrosion-rate sanity tests verify that the de Waard-Milliams 1991
+ Annex 2.A alloy factors return values within the published envelope
(~0.5-5 mm/yr for CS-CO2 at 80 C / 25 bar CO2 partial pressure).
"""

from __future__ import annotations

import math

import pytest

import austenite as au


# ---------------------------------------------------------------------------
# 5x5 risk matrix — API 581 Part 1 §4.1 Table 4.1
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("pof_cat", "cof_cat", "expected_band"),
    [
        (1, "A", "low"),
        (1, "E", "med"),
        (2, "C", "med"),
        (3, "E", "high"),
        (5, "A", "med"),
        (5, "E", "high"),
        (4, "D", "high"),
        (2, "B", "low"),
    ],
)
def test_risk_matrix_corners_match_published(pof_cat, cof_cat, expected_band) -> None:
    """Risk band lookup matches API RP 581 Part 1 §4.1 colour scheme."""

    assert au.rbi.risk_matrix_band(pof_cat, cof_cat) == expected_band


# ---------------------------------------------------------------------------
# POF / COF classification
# ---------------------------------------------------------------------------


def test_classify_pof_table_4_1() -> None:
    """API 581 §4.1 Table 4.1 POF bands."""

    assert au.rbi.classify_pof(1e-6) == 1
    assert au.rbi.classify_pof(1e-4) == 2
    assert au.rbi.classify_pof(1e-3) == 3
    assert au.rbi.classify_pof(1e-2) == 4
    assert au.rbi.classify_pof(1e-1) == 5


def test_classify_cof_table_4_1() -> None:
    """API 581 §4.1 Table 4.1 COF bands ($)."""

    assert au.rbi.classify_cof(5_000) == "A"
    assert au.rbi.classify_cof(50_000) == "B"
    assert au.rbi.classify_cof(500_000) == "C"
    assert au.rbi.classify_cof(5_000_000) == "D"
    assert au.rbi.classify_cof(50_000_000) == "E"


# ---------------------------------------------------------------------------
# CO2 corrosion-rate envelope (de Waard-Milliams 1991)
# ---------------------------------------------------------------------------


def test_co2_corrosion_rate_envelope_CS_80C_25bar_CO2() -> None:
    """CS at 80 C, P_CO2 = 25 bar should be in the published 10-200 mm/yr
    uninhibited de Waard-Milliams range. (Scale formation deceleration kicks
    in above 80 C; engineering corrosion inhibitors not modelled here.)"""

    out = au.rbi.api581_corrosion_rate(
        alloy="CS", mechanism="CO2", T_C=80, P_MPa=2.5, yCorr=1.0,
    )
    assert 10.0 <= out["CR_mm_yr"] <= 200.0
    assert "Waard-Milliams" in out["notes"] or "Annex 2.A" in out["notes"]
    assert "API RP 581" in out["citation"]


def test_co2_corrosion_rate_inhibited_by_scale_at_higher_T() -> None:
    """Above 80 C CS gets Fe-scale protection — CR at 120 C / low P_CO2 should
    drop into the engineering-design 1-20 mm/yr range."""

    out = au.rbi.api581_corrosion_rate(
        alloy="CS", mechanism="CO2", T_C=120, P_MPa=0.5, yCorr=0.2,
    )
    assert 0.0 < out["CR_mm_yr"] <= 20.0


def test_co2_corrosion_rate_austenitic_immune() -> None:
    """304L should be ~50x lower than CS at the same conditions."""

    cs = au.rbi.api581_corrosion_rate(alloy="CS", mechanism="CO2",
                                      T_C=80, P_MPa=2.5, yCorr=1.0)["CR_mm_yr"]
    ss = au.rbi.api581_corrosion_rate(alloy="304L", mechanism="CO2",
                                      T_C=80, P_MPa=2.5, yCorr=1.0)["CR_mm_yr"]
    assert ss < cs / 10.0


# ---------------------------------------------------------------------------
# Single-asset api_581_full
# ---------------------------------------------------------------------------


def test_api_581_full_returns_complete_verdict() -> None:
    """Smoke + structural check on the aggregate single-asset verdict."""

    v = au.rbi.api_581_full(
        equipment={"type": "vessel", "tag": "V-2401"},
        service="sweet-corrosion",
        chemistry={"CO2_pct": 1, "Cl_ppm": 50, "T_C": 80, "P_MPa": 2.5},
        material="SA-516-70",
        inspection_history=[{"year": 2024, "method": "UT", "thickness_mm": 11.8}],
        age_yr=8,
    )
    assert 1 <= v.POF_category <= 5
    assert v.COF_category in ("A", "B", "C", "D", "E")
    assert v.risk_band in ("low", "med", "med-high", "high")
    assert v.risk_matrix == f"{v.POF_category}{v.COF_category}"
    assert v.recommended_inspection_interval_years >= 1
    assert "thinning" in v.damage_factors
    assert "API RP 581" in v.citation


def test_api_581_full_thinning_dominates_for_high_CR() -> None:
    """An aged thin wall in aggressive CO2 service should land in high-risk band."""

    v = au.rbi.api_581_full(
        equipment={"type": "vessel", "tag": "V-X"},
        service="sweet-corrosion",
        chemistry={"CO2_pct": 5, "T_C": 60, "P_MPa": 5},
        material="A106 Gr B",
        cof_usd=5e6,
        age_yr=20,
        t_nominal_mm=10,
        t_min_mm=8,
    )
    assert v.damage_factors["thinning"] > 100  # large DF
    assert v.POF_category >= 3
    assert v.risk_band in ("med-high", "high")


def test_api_581_full_uses_inspection_category_to_reduce_DF() -> None:
    """Best-effectiveness (A) inspection should reduce DF vs default (C)."""

    common = dict(
        equipment={"type": "vessel", "tag": "V-Y"},
        service="sweet-corrosion",
        chemistry={"CO2_pct": 1, "T_C": 80, "P_MPa": 2.5},
        material="SA-516-70",
        age_yr=10,
        t_nominal_mm=12,
        t_min_mm=8,
    )
    v_C = au.rbi.api_581_full(**common, inspection_category="C", n_inspections=1)
    v_A = au.rbi.api_581_full(**common, inspection_category="A", n_inspections=2)
    assert v_A.damage_factors["thinning"] <= v_C.damage_factors["thinning"]


# ---------------------------------------------------------------------------
# fleet_screen
# ---------------------------------------------------------------------------


def test_fleet_screen_with_dataframe_input() -> None:
    """Vectorised fleet rank — total_risk column + correct ordering."""

    pd = pytest.importorskip("pandas")
    assets = pd.DataFrame([
        {"tag": "V-1", "type": "vessel", "service": "sweet-corrosion",
         "material": "SA-516-70", "T_C": 80, "P_MPa": 2.5, "CO2_pct": 1.0,
         "cof_usd": 5e5, "age_yr": 8, "t_mm": 12.7, "t_min_mm": 8.0},
        {"tag": "V-2", "type": "column", "service": "sour",
         "material": "SA-516-70", "T_C": 130, "P_MPa": 1.5, "H2S_ppm": 500,
         "cof_usd": 1e6, "age_yr": 12, "t_mm": 18, "t_min_mm": 10},
        {"tag": "V-3", "type": "hex", "service": "amine",
         "material": "304L", "T_C": 50, "P_MPa": 0.5,
         "cof_usd": 2e5, "age_yr": 6, "t_mm": 10, "t_min_mm": 7},
    ])
    out = au.rbi.fleet_screen(assets)
    assert isinstance(out, pd.DataFrame)
    assert len(out) == 3
    assert set(out.columns) >= {"tag", "POF_per_yr", "COF_category", "risk_matrix",
                                "risk_band", "total_risk"}
    # at least one asset should rank above the others
    sorted_ = out.sort_values("total_risk", ascending=False)
    assert sorted_["total_risk"].iloc[0] >= sorted_["total_risk"].iloc[-1]


def test_fleet_screen_accepts_list_of_dicts() -> None:
    """The same call works without pandas as plain list-of-dicts in/out."""

    assets = [
        {"tag": "V-1", "type": "vessel", "service": "sweet-corrosion",
         "material": "SA-516-70", "T_C": 80, "P_MPa": 2.5, "CO2_pct": 1.0,
         "cof_usd": 5e5, "age_yr": 8, "t_mm": 12.7, "t_min_mm": 8.0},
    ]
    out = au.rbi.fleet_screen(assets)
    # could be DataFrame or list, we don't care which here
    if hasattr(out, "iloc"):
        assert len(out) == 1
    else:
        assert isinstance(out, list)
        assert out[0]["tag"] == "V-1"


# ---------------------------------------------------------------------------
# NDE POD library
# ---------------------------------------------------------------------------


def test_pod_curve_monotonic_in_depth() -> None:
    """P_d should rise monotonically with depth for any sane POD curve."""

    a = [au.rbi.pod_curve("UT", d) for d in (0.5, 1.0, 2.0, 4.0)]
    assert all(a[i + 1] >= a[i] for i in range(len(a) - 1))


def test_pod_curve_a90_matches_library() -> None:
    """P_d at the library's a_90 mm should be in the canonical ~0.8-0.97 range.
    (The published a_90 values are MIL-HDBK-1823A nominal; small slop in the
    (μ_ln, σ_ln) fit gives a few-percent jitter around 0.9.)"""

    for c in au.rbi.NDE_POD_LIBRARY:
        p90 = au.rbi.pod_curve(c.id, c.a_90_mm)
        # MIL-HDBK-1823A nominal a_90 → P_d ≈ 0.90; allow slop from (μ_ln, σ_ln) fit
        assert 0.80 <= p90 <= 0.999, f"{c.id}: P_d({c.a_90_mm})={p90:.2f}"


def test_api581_effectiveness_categorises_thinning_methods() -> None:
    """UT-PA should outperform VT at small t_min."""

    pa = au.rbi.api581_effectiveness("UT-PA", t_min_mm=1.0)
    vt = au.rbi.api581_effectiveness("VT", t_min_mm=1.0)
    assert pa <= vt   # 'A' < 'E' lexicographically


# ---------------------------------------------------------------------------
# Damage-mechanism screen
# ---------------------------------------------------------------------------


def test_damage_mechanism_screen_lookup() -> None:
    m = au.rbi.damage_mechanism("scc")
    assert m is not None
    assert m.id == "scc"
    assert "304L" in m.susceptible_materials
    assert "PT" in m.recommended_nde


def test_damage_mechanism_screen_unknown_returns_none() -> None:
    assert au.rbi.damage_mechanism("notamech") is None


# ---------------------------------------------------------------------------
# Tank-bottom RBI (API 653)
# ---------------------------------------------------------------------------


def test_tank_bottom_rbi_MIC_multiplier_reduces_life() -> None:
    """MIC=True should produce shorter remaining life than MIC=False."""

    no_mic = au.rbi.tank_bottom_rbi(
        t_nominal_mm=9.5, t_min_mm=2.54, CR_topside_mm_yr=0.05,
        CR_underside_mm_yr=0.1, CR_edge_mm_yr=0.2, MIC=False,
        service_age_yr=10, product="crude",
    )
    with_mic = au.rbi.tank_bottom_rbi(
        t_nominal_mm=9.5, t_min_mm=2.54, CR_topside_mm_yr=0.05,
        CR_underside_mm_yr=0.1, CR_edge_mm_yr=0.2, MIC=True,
        service_age_yr=10, product="crude",
    )
    assert with_mic["remaining_life_yr"] < no_mic["remaining_life_yr"]
    assert "MIC" in with_mic["notes"]
    assert "API 653" in with_mic["citation"]


def test_tank_bottom_rbi_limiting_location_consistency() -> None:
    """Highest CR should set the limiting location."""

    r = au.rbi.tank_bottom_rbi(
        t_nominal_mm=9.5, t_min_mm=2.54,
        CR_topside_mm_yr=0.01, CR_underside_mm_yr=0.01, CR_edge_mm_yr=0.50,
        MIC=False, service_age_yr=10, product="crude",
    )
    assert r["limiting_location"] == "edge"
