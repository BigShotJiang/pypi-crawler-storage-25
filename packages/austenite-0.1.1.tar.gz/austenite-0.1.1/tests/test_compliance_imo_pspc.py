"""Tests for the IMO PSPC (MSC.215(82)) coating-system checker."""

from __future__ import annotations

import pytest

import austenite as au
from austenite.compliance_standards import StandardVerdict, imo_pspc


def test_imo_pspc_pass_well_specified_coating() -> None:
    v = imo_pspc.check(
        mechanical={
            "DFT_nominal_um": 320,
            "DFT_min_um": 335,
            "DFT_max_um": 580,
            "stripe_coat_count": 2,
            "main_coat_count": 2,
            "surface_prep_Sa": 2.5,
            "adhesion_MPa_min": 4.0,
            "salt_content_mg_per_m2": 30,
            "dust_rating_ISO8502_3": 2,
            "rh_pct_max_during_application": 75,
            "surface_T_above_dewpoint_C": 5,
            "design_target_useful_life_years": 18,
            "preheat_temperature_C": 10,
        },
    )
    assert isinstance(v, StandardVerdict)
    assert v.passed is True
    assert v.failed_items == []
    assert v.spec_id == "IMO PSPC (MSC.215(82))"


def test_imo_pspc_fail_low_dft() -> None:
    v = imo_pspc.check(mechanical={"DFT_min_um": 250, "stripe_coat_count": 2,
                                   "main_coat_count": 2})
    assert v.passed is False
    assert any("DFT_min_um" in f and "below min 320" in f for f in v.failed_items)


def test_imo_pspc_fail_too_few_stripe_coats() -> None:
    v = imo_pspc.check(mechanical={"DFT_min_um": 350, "stripe_coat_count": 1,
                                   "main_coat_count": 2})
    assert v.passed is False
    assert any("stripe_coat_count" in f and "below min 2" in f for f in v.failed_items)


def test_imo_pspc_ignores_composition_silently() -> None:
    """PSPC has no chemistry envelope — supplying composition is OK but ignored."""

    v = imo_pspc.check(
        composition={"C": 0.20},  # ignored
        mechanical={"DFT_min_um": 350, "stripe_coat_count": 2, "main_coat_count": 2},
    )
    # The composition should be acknowledged in the notes, not in failed_items
    assert any("composition: ignored" in n for n in v.notes)
    assert all("C =" not in f for f in v.failed_items)


def test_imo_pspc_via_dispatcher() -> None:
    v = au.compliance.check_standard(
        "pspc",
        mechanical={"DFT_min_um": 350, "stripe_coat_count": 2, "main_coat_count": 2},
    )
    assert isinstance(v, StandardVerdict)
    assert v.spec_id == "IMO PSPC (MSC.215(82))"
