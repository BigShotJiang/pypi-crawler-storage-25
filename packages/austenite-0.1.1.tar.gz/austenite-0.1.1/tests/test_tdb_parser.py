"""Tests for ``austenite.io.tdb`` — the SGTE TDB parser.

Covers:

* Element / species / phase / constituent / function / parameter / type-def
  statement parsing against a synthetic micro-TDB shipped with the package.
* Tokenization corner cases (Fortran D exponents, ``'`` type-def code,
  comment + string handling, signed numbers).
* Redlich-Kister mixing parameter parsing (``L(BCC_A2,CR,FE:VA;0)``).
* Magnetic ``TC`` / ``BMAGN`` parameters round-trip.
* ``write_tdb`` → ``read_tdb`` round-trip preserves every parameter,
  every function range, every phase, every species.
* ``TdbParseError`` carries line / column metadata for malformed input.
* Error messages on unterminated string literal and bad PARAMETER signature.
* Default elements + database info captured.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from austenite.io import read_tdb, write_tdb
from austenite.io.tdb import (
    Parameter,
    Phase,
    Species,
    TdbParseError,
    TdbSystem,
    _parse_formula,
    _parse_parameter_name,
    _tokenize,
)


FIXTURE = Path(__file__).parent / "fixtures" / "synthetic.tdb"


def _system() -> TdbSystem:
    return read_tdb(FIXTURE)


# ---------------------------------------------------------------------------
# 1. Element parsing
# ---------------------------------------------------------------------------


def test_elements_parsed_from_synthetic_tdb() -> None:
    sys = _system()
    assert sys.elements == ["FE", "CR", "NI", "MO", "MN", "SI", "C"]
    fe = sys.element_data["FE"]
    assert fe["reference_phase"] == "BCC_A2"
    assert pytest.approx(fe["atomic_mass"], rel=1e-3) == 55.847
    assert pytest.approx(fe["H298"], rel=1e-3) == 4489.0
    assert pytest.approx(fe["S298"], rel=1e-3) == 27.2797


def test_default_system_default_elements_recorded() -> None:
    sys = _system()
    assert sys.default_elements[:3] == ["FE", "CR", "NI"]


def test_database_info_captured() -> None:
    sys = _system()
    assert "Fe-Cr-Ni-Mo-Mn-Si-C" in sys.database_info


# ---------------------------------------------------------------------------
# 2. Phases + constituents
# ---------------------------------------------------------------------------


def test_phases_in_declaration_order() -> None:
    sys = _system()
    assert sys.phases == ["LIQUID", "BCC_A2", "FCC_A1", "SIGMA", "M23C6"]


def test_bcc_phase_has_model_codes_and_sites() -> None:
    sys = _system()
    bcc = sys.phase_objects["BCC_A2"]
    assert "%" in bcc.model_codes
    assert "&" in bcc.model_codes  # magnetic type-def code
    assert bcc.sublattice_sites == [1.0, 3.0]
    assert bcc.constituents == [["FE", "CR", "NI", "MO", "MN"], ["VA"]]


def test_sigma_phase_three_sublattices() -> None:
    sys = _system()
    sigma = sys.phase_objects["SIGMA"]
    assert sigma.sublattice_sites == [10.0, 4.0, 16.0]
    assert sigma.constituents[0] == ["FE", "NI"]
    assert sigma.constituents[1] == ["CR", "MO"]
    assert set(sigma.constituents[2]) == {"CR", "FE", "MO", "NI"}


def test_m23c6_line_compound_constituents() -> None:
    sys = _system()
    m23c6 = sys.phase_objects["M23C6"]
    assert m23c6.sublattice_sites == [20.0, 3.0, 6.0]
    assert m23c6.constituents[2] == ["C"]


# ---------------------------------------------------------------------------
# 3. FUNCTION definitions
# ---------------------------------------------------------------------------


def test_function_gfebcc_two_segments() -> None:
    sys = _system()
    ranges = sys.functions["GFEBCC"]
    assert len(ranges) == 2
    assert pytest.approx(ranges[0][0]) == 298.15
    assert pytest.approx(ranges[0][1]) == 1811.0
    assert "1224.83" in ranges[0][2]
    assert pytest.approx(ranges[1][0]) == 1811.0
    assert pytest.approx(ranges[1][1]) == 6000.0
    assert "T*LN" in ranges[1][2].replace(" ", "")


def test_function_zero_constant() -> None:
    sys = _system()
    z = sys.functions["ZERO"]
    assert len(z) == 1
    assert z[0][2].replace(" ", "") == "+0.0"


# ---------------------------------------------------------------------------
# 4. PARAMETER parsing
# ---------------------------------------------------------------------------


def test_parameter_count() -> None:
    sys = _system()
    # 4 unaries + 3 Fe-Cr binary + 3 sigma + 2 magnetic + 2 M23C6 = 14
    assert len(sys.parameters) == 14


def test_fe_bcc_endmember_parameter() -> None:
    sys = _system()
    p = sys.parameter("G", "BCC_A2", [["FE"], ["VA"]], order=0)
    assert p is not None
    assert p.expression[0][0] == 298.15
    assert "GFEBCC" in p.expression[0][2]
    assert "Dinsdale" in p.reference


def test_fe_cr_binary_l0_and_l1_parameters() -> None:
    sys = _system()
    l0 = sys.parameter("L", "BCC_A2", [["CR", "FE"], ["VA"]], order=0)
    l1 = sys.parameter("L", "BCC_A2", [["CR", "FE"], ["VA"]], order=1)
    assert l0 is not None and l1 is not None
    assert "20500" in l0.expression[0][2]
    assert "1410" in l1.expression[0][2]
    assert "Andersson" in l0.reference


def test_sigma_phase_endmember_parameters() -> None:
    sys = _system()
    fe_cr_cr = sys.parameter("G", "SIGMA", [["FE"], ["CR"], ["CR"]], order=0)
    assert fe_cr_cr is not None
    assert "117300" in fe_cr_cr.expression[0][2]
    assert "Hammar" in fe_cr_cr.reference


def test_magnetic_tc_and_bmagn_parameters() -> None:
    sys = _system()
    tc = sys.parameter("TC", "BCC_A2", [["FE"], ["VA"]], order=0)
    bmagn = sys.parameter("BMAGN", "BCC_A2", [["FE"], ["VA"]], order=0)
    assert tc is not None and bmagn is not None
    assert "+1043.0" in tc.expression[0][2] or "1043" in tc.expression[0][2]
    assert "2.22" in bmagn.expression[0][2]


def test_parameters_for_phase_helper() -> None:
    sys = _system()
    bcc_params = sys.parameters_for_phase("BCC_A2")
    # 2 endmembers + 2 RK + 2 magnetic = 6
    assert len(bcc_params) == 6
    for p in bcc_params:
        assert p.phase == "BCC_A2"


# ---------------------------------------------------------------------------
# 5. SPECIES & line-compound formulas
# ---------------------------------------------------------------------------


def test_species_includes_elements_and_carbides() -> None:
    sys = _system()
    assert "FE" in sys.species  # implicit element species
    assert "CR23C6" in sys.species
    cr23c6 = sys.species["CR23C6"]
    assert cr23c6.stoichiometry == {"CR": 23.0, "C": 6.0}


def test_fe3c_species_parses_correctly() -> None:
    sys = _system()
    fe3c = sys.species["FE3C"]
    assert fe3c.stoichiometry == {"FE": 3.0, "C": 1.0}


# ---------------------------------------------------------------------------
# 6. TYPE_DEFINITION
# ---------------------------------------------------------------------------


def test_type_definitions_captured() -> None:
    sys = _system()
    assert "%" in sys.type_definitions
    assert "&" in sys.type_definitions
    assert "BCC_A2" in sys.type_definitions["&"]
    assert "FCC_A1" in sys.type_definitions["'"]


# ---------------------------------------------------------------------------
# 7. References block
# ---------------------------------------------------------------------------


def test_references_parsed() -> None:
    sys = _system()
    assert "REF1" in sys.references
    assert "Dinsdale" in sys.references["REF1"]
    assert "REF3" in sys.references


# ---------------------------------------------------------------------------
# 8. Round-trip — write_tdb → read_tdb preserves the system
# ---------------------------------------------------------------------------


def test_write_tdb_roundtrip_preserves_elements_and_phases() -> None:
    sys1 = _system()
    text = write_tdb(sys1)
    sys2 = read_tdb(text)
    assert sys1.elements == sys2.elements
    assert set(sys1.phases) == set(sys2.phases)


def test_write_tdb_roundtrip_preserves_parameter_count() -> None:
    sys1 = _system()
    text = write_tdb(sys1)
    sys2 = read_tdb(text)
    assert len(sys1.parameters) == len(sys2.parameters)


def test_write_tdb_roundtrip_preserves_function_ranges() -> None:
    sys1 = _system()
    text = write_tdb(sys1)
    sys2 = read_tdb(text)
    for fname in ("GFEBCC", "GCRBCC", "GNIFCC"):
        r1 = sys1.functions[fname]
        r2 = sys2.functions[fname]
        assert len(r1) == len(r2), f"{fname}: {len(r1)} vs {len(r2)}"
        for (lo1, hi1, _), (lo2, hi2, _) in zip(r1, r2):
            assert pytest.approx(lo1) == lo2
            assert pytest.approx(hi1) == hi2


def test_write_tdb_roundtrip_preserves_species_stoichiometry() -> None:
    sys1 = _system()
    text = write_tdb(sys1)
    sys2 = read_tdb(text)
    for name in ("FE3C", "CR23C6"):
        assert sys1.species[name].stoichiometry == sys2.species[name].stoichiometry


def test_write_tdb_writes_to_disk(tmp_path: Path) -> None:
    sys1 = _system()
    out = tmp_path / "out.tdb"
    text = write_tdb(sys1, path=out)
    assert out.read_text(encoding="utf-8") == text


# ---------------------------------------------------------------------------
# 9. Tokenizer corner cases
# ---------------------------------------------------------------------------


def test_tokenizer_handles_fortran_d_exponent() -> None:
    tokens = _tokenize("FUNCTION FOO 298.15 1.23D-4 ; 6000 N !")
    nums = [t for t in tokens if t.kind == "NUMBER"]
    # 1.23D-4 should be tokenized as one NUMBER
    assert any("D" in t.value or "1.23" in t.value for t in nums)


def test_tokenizer_strips_dollar_comments() -> None:
    src = """
    $ this is a comment - should be ignored
    ELEMENT FE BCC 55.85 4489 27.28 !
    """
    tokens = _tokenize(src)
    keywords = [t.value for t in tokens if t.kind == "WORD"]
    assert "ELEMENT" in keywords
    assert "comment" not in keywords  # comments are dropped


def test_tokenizer_handles_signed_numbers() -> None:
    tokens = _tokenize("PARAMETER G(X,Y) 298.15 -8856.940 +157.48*T ; 6000 N !")
    nums = [t.value for t in tokens if t.kind == "NUMBER"]
    assert any("-8856" in n for n in nums) or "-8856.940" in nums


def test_tokenizer_single_quote_is_word_not_string() -> None:
    """Single quote ``'`` is a valid TYPE_DEFINITION code char in SGTE."""

    tokens = _tokenize("TYPE_DEFINITION ' GES A_P_D FCC_A1 MAGNETIC -3 0.28 !")
    quotes = [t for t in tokens if t.value == "'"]
    assert quotes
    assert quotes[0].kind == "WORD"
    # No STRING tokens should have been opened
    strings = [t for t in tokens if t.kind == "STRING"]
    assert not strings


def test_unterminated_double_quoted_string_raises() -> None:
    with pytest.raises(TdbParseError):
        _tokenize('PARAMETER G(BCC,FE;0) 298.15 +1.0 ; 6000 N "unterminated\n')


# ---------------------------------------------------------------------------
# 10. Parameter signature parsing
# ---------------------------------------------------------------------------


def test_parse_parameter_name_unary() -> None:
    parsed = _parse_parameter_name("G(BCC_A2,FE)")
    assert parsed is not None
    kind, phase, sublats, order = parsed
    assert kind == "G"
    assert phase == "BCC_A2"
    assert sublats == [["FE"]]
    assert order == 0


def test_parse_parameter_name_rk_mixing() -> None:
    parsed = _parse_parameter_name("L(BCC_A2,CR,FE:VA;1)")
    assert parsed is not None
    kind, phase, sublats, order = parsed
    assert kind == "L"
    assert sublats == [["CR", "FE"], ["VA"]]
    assert order == 1


def test_parse_parameter_name_three_sublattices() -> None:
    parsed = _parse_parameter_name("G(SIGMA,FE:CR:CR;0)")
    assert parsed is not None
    _, _, sublats, _ = parsed
    assert sublats == [["FE"], ["CR"], ["CR"]]


def test_parse_parameter_name_malformed_returns_none() -> None:
    assert _parse_parameter_name("not-a-signature") is None


# ---------------------------------------------------------------------------
# 11. Formula parser
# ---------------------------------------------------------------------------


def test_parse_formula_uppercase_with_known_elements() -> None:
    assert _parse_formula("FE3C", known_elements=["FE", "C"]) == {"FE": 3.0, "C": 1.0}


def test_parse_formula_uppercase_ambiguous_falls_back() -> None:
    # Without known elements, FE in all-caps becomes F + E.
    out = _parse_formula("FE", known_elements=[])
    assert out == {"F": 1.0, "E": 1.0}


def test_parse_formula_camelcase_unambiguous() -> None:
    assert _parse_formula("Fe3C") == {"FE": 3.0, "C": 1.0}


def test_parse_formula_empty_string_returns_empty_dict() -> None:
    assert _parse_formula("") == {}


# ---------------------------------------------------------------------------
# 12. read_tdb accepts string, Path, bytes
# ---------------------------------------------------------------------------


def test_read_tdb_accepts_path_object() -> None:
    sys = read_tdb(FIXTURE)
    assert sys.elements


def test_read_tdb_accepts_string_path() -> None:
    sys = read_tdb(str(FIXTURE))
    assert sys.elements


def test_read_tdb_accepts_bytes() -> None:
    sys = read_tdb(FIXTURE.read_bytes())
    assert sys.elements


def test_read_tdb_accepts_inline_text() -> None:
    src = """
    ELEMENT FE BCC 55.847 4489.0 27.28 !
    PHASE LIQUID % 1 1 !
    """
    sys = read_tdb(src)
    assert sys.elements == ["FE"]
    assert sys.phases == ["LIQUID"]


# ---------------------------------------------------------------------------
# 13. TdbParseError metadata
# ---------------------------------------------------------------------------


def test_tdb_parse_error_carries_line_column() -> None:
    err = TdbParseError("oops", line=42, column=7)
    assert err.line == 42
    assert err.column == 7
    assert "line 42:7" in str(err)


def test_summary_string_includes_counts() -> None:
    sys = _system()
    s = sys.summary()
    assert "elements=7" in s
    assert "phases=5" in s
    assert "parameters=14" in s
    assert "functions=5" in s
