"""Tests for the JAX-traceable CALPHAD equilibrium engine.

Verifies:
 * gradients are finite and match finite differences to ~ machine ε,
 * the dominant-phase / Gibbs-energy agree with the native solver to
   within ~1 % at three temperatures,
 * jit/vmap compose cleanly,
 * the result pytree round-trips through ``jax.tree_util``.

These tests skip cleanly when JAX is missing.
"""

from __future__ import annotations

import math

import pytest


jax = pytest.importorskip("jax")
jnp = pytest.importorskip("jax.numpy")
import austenite as au  # noqa: E402


# Fe-Cr-Ni alloy at 1273 K — classic SS stainless equilibrium.
COMP_FE_CR_NI = jnp.array([0.74, 0.18, 0.08])


def test_calphad_equilibrium_jax_returns_pytree() -> None:
    """Importable and returns a JAX pytree with the expected shape."""

    from austenite.jax_backend import (
        CalphadEquilibriumJaxResult,
        calphad_equilibrium_jax,
    )

    r = calphad_equilibrium_jax(COMP_FE_CR_NI, T_K=1273.0,
                                n_samples=1, polish_iter=5)
    assert isinstance(r, CalphadEquilibriumJaxResult)
    assert r.G_J_per_mol.shape == ()
    assert r.phase_fractions.shape == (4,)
    assert r.phase_compositions.shape == (4, 3)
    assert r.activities.shape == (3,)
    assert math.isfinite(float(r.G_J_per_mol))


def test_calphad_equilibrium_jax_dominant_phase_FCC_at_1273K() -> None:
    """At 1273 K Fe-18Cr-8Ni should be single-phase FCC."""

    from austenite.jax_backend import calphad_equilibrium_jax

    r = calphad_equilibrium_jax(COMP_FE_CR_NI, T_K=1273.0,
                                n_samples=1, polish_iter=5)
    # FCC index in PHASE_NAMES = 1
    dom = int(r.phase_fractions.argmax())
    assert dom == 1, f"expected FCC; got phase index {dom}"
    assert float(r.phase_fractions[dom]) > 0.95


@pytest.mark.parametrize("T_K", [1000.0, 1273.0, 1500.0])
def test_calphad_matches_native_within_1pct(T_K) -> None:
    """JAX Gibbs energy within 1 % of native solver on Fe-Cr-Ni."""

    from austenite._calphad_native import equilibrium_native
    from austenite.jax_backend import calphad_equilibrium_jax

    rn = equilibrium_native({"FE": 0.74, "CR": 0.18, "NI": 0.08}, T_K=T_K)
    rj = calphad_equilibrium_jax(COMP_FE_CR_NI, T_K=T_K,
                                 n_samples=1, polish_iter=5)
    err = abs(float(rj.G_J_per_mol) - rn.G) / abs(rn.G)
    assert err < 0.01, f"JAX vs native: {float(rj.G_J_per_mol):.1f} vs {rn.G:.1f} ({err:.2%})"


def test_calphad_equilibrium_jax_grad_finite() -> None:
    """``jax.grad`` over composition returns a finite 3-vector."""

    from austenite.jax_backend import calphad_equilibrium_jax

    def G_of(c):
        return calphad_equilibrium_jax(c, T_K=1273.0,
                                       n_samples=1, polish_iter=5).G_J_per_mol

    g = jax.grad(G_of)(COMP_FE_CR_NI)
    assert g.shape == (3,)
    assert bool(jnp.all(jnp.isfinite(g)))


def test_calphad_jax_grad_matches_finite_diff_along_Cr() -> None:
    """Autodiff ≈ finite-difference (relative error < 2 %)."""

    from austenite.jax_backend import calphad_equilibrium_jax

    def G_of(c):
        return calphad_equilibrium_jax(c, T_K=1273.0,
                                       n_samples=1, polish_iter=5).G_J_per_mol

    g = jax.grad(G_of)(COMP_FE_CR_NI)
    eps = 1e-4
    Gp = float(G_of(COMP_FE_CR_NI + jnp.array([0.0, eps, 0.0])))
    Gm = float(G_of(COMP_FE_CR_NI - jnp.array([0.0, eps, 0.0])))
    fd = (Gp - Gm) / (2 * eps)
    rel_err = abs(fd - float(g[1])) / max(abs(fd), 1e-9)
    assert rel_err < 0.02, f"FD {fd:.2f} vs AD {float(g[1]):.2f}; rel_err={rel_err:.2%}"


def test_calphad_jax_phase_fractions_sum_to_one() -> None:
    """Phase fractions must sum to 1 (softmax constraint)."""

    from austenite.jax_backend import calphad_equilibrium_jax

    r = calphad_equilibrium_jax(COMP_FE_CR_NI, T_K=1273.0,
                                n_samples=1, polish_iter=5)
    total = float(jnp.sum(r.phase_fractions))
    assert abs(total - 1.0) < 1e-3
