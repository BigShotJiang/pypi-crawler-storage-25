"""Multi-language MTC parsing tests.

Verifies that German + Japanese cert text strings are detected,
translated into English-symbol equivalents before being sent to the
parser, and yield a sane chemistry map.
"""

from __future__ import annotations

import json

import pytest

import austenite as au
from austenite._languages import (
    alias_to_symbol,
    detect_language,
    translate_element_tokens,
)


PARSE_URL = "https://api-test.austenite.org/v1/mtc/parse"


# ── unit tests of the language helpers ──


def test_alias_to_symbol_english_and_german() -> None:
    assert alias_to_symbol("Carbon") == "C"
    assert alias_to_symbol("Kohlenstoff") == "C"
    assert alias_to_symbol("Mangan") == "Mn"
    assert alias_to_symbol("Cromo") == "Cr"
    assert alias_to_symbol("マンガン") == "Mn"
    assert alias_to_symbol("탄소") == "C"
    assert alias_to_symbol("锰") == "Mn"
    assert alias_to_symbol("not_an_element") is None
    assert alias_to_symbol("") is None


def test_detect_language_german_header() -> None:
    text = (
        "Abnahmeprüfzeugnis 3.1 nach DIN EN 10204\n"
        "Werkstoffnummer 1.7225 / Werkstoff 42CrMo4\n"
        "Schmelze H12345\n"
        "Chemische Zusammensetzung:\n"
        "Kohlenstoff 0.41  Mangan 0.85  Chrom 1.02  Molybdän 0.22\n"
    )
    assert detect_language(text) == "de"


def test_detect_language_japanese_header() -> None:
    text = (
        "ミルシート (証明書)\n"
        "材料: SCM440\n"
        "ヒート番号: H98765\n"
        "化学成分 (wt%):\n"
        "炭素 0.40  マンガン 0.80  クロム 1.05  モリブデン 0.20\n"
    )
    assert detect_language(text) == "ja"


def test_detect_language_falls_back_to_english() -> None:
    assert detect_language("just some random text with no cues") == "en"
    assert detect_language("") == "en"


def test_translate_element_tokens_german() -> None:
    text = "Kohlenstoff 0.41 Mangan 0.85 Chrom 1.02"
    out = translate_element_tokens(text)
    assert " C " in out
    assert " Mn " in out
    assert " Cr " in out


def test_translate_element_tokens_japanese() -> None:
    text = "炭素 0.40 マンガン 0.80 クロム 1.05"
    out = translate_element_tokens(text)
    assert " C " in out
    assert " Mn " in out
    assert " Cr " in out


# ── integration tests through au.mtc.parse with mocked HTTP ──


def test_parse_german_cert_normalises_before_post(httpx_mock) -> None:
    """The text the worker receives should already use English symbols."""
    httpx_mock.add_response(
        url=PARSE_URL,
        method="POST",
        json={
            "heat_number": "H12345",
            "grade": "42CrMo4",
            "composition": {"C": 0.41, "Mn": 0.85, "Cr": 1.02, "Mo": 0.22},
            "confidence": 0.91,
        },
    )
    german_cert = (
        "Abnahmeprüfzeugnis 3.1 nach DIN EN 10204\n"
        "Werkstoff 42CrMo4 / Schmelze H12345\n"
        "Kohlenstoff 0.41  Mangan 0.85  Chrom 1.02  Molybdän 0.22\n"
    )
    r = au.mtc.parse(text=german_cert)
    assert r.heat_number == "H12345"
    assert r.composition["C"] == pytest.approx(0.41)

    sent = httpx_mock.get_requests()[-1].read().decode("utf-8")
    body = json.loads(sent)
    payload_text = body["text"]
    # Server-side parser only knows English symbols, so the client
    # MUST translate "Kohlenstoff" → " C " before transmitting.
    assert " C " in payload_text
    assert " Mn " in payload_text
    assert " Cr " in payload_text


def test_parse_japanese_cert_normalises_before_post(httpx_mock) -> None:
    httpx_mock.add_response(
        url=PARSE_URL,
        method="POST",
        json={
            "heat_number": "H98765",
            "grade": "SCM440",
            "composition": {"C": 0.40, "Mn": 0.80, "Cr": 1.05, "Mo": 0.20},
            "confidence": 0.88,
        },
    )
    japanese_cert = (
        "ミルシート (証明書)\n"
        "材料: SCM440  ヒート H98765\n"
        "炭素 0.40 マンガン 0.80 クロム 1.05 モリブデン 0.20\n"
    )
    r = au.mtc.parse(text=japanese_cert)
    assert r.grade == "SCM440"
    assert r.composition["C"] == pytest.approx(0.40)

    sent = httpx_mock.get_requests()[-1].read().decode("utf-8")
    body = json.loads(sent)
    assert " C " in body["text"]
    assert " Mn " in body["text"]
    assert " Cr " in body["text"]
    assert " Mo " in body["text"]


def test_parse_explicit_language_skips_detection(httpx_mock) -> None:
    httpx_mock.add_response(
        url=PARSE_URL,
        method="POST",
        json={"composition": {"C": 0.4}},
    )
    au.mtc.parse(text="Kohlenstoff 0.41", language="de")
    sent = httpx_mock.get_requests()[-1].read().decode("utf-8")
    body = json.loads(sent)
    assert " C " in body["text"]


def test_detect_language_with_whitelist() -> None:
    text = (
        "ミルシート (証明書)\n"
        "炭素 0.40 マンガン 0.80\n"
    )
    # If the QC team only accepts EN/DE, Japanese characters won't win.
    assert detect_language(text, allowed=["en", "de"]) == "en"
    assert detect_language(text, allowed=["en", "de", "ja"]) == "ja"
