"""Tests for the JAX-traceable AM melt-pool engines.

Covers Rosenthal 1946 / Eagar-Tsai 1983 / Goldak 1984 — finiteness,
gradient sign, and finite-difference / autodiff consistency.
"""

from __future__ import annotations

import math

import pytest


jax = pytest.importorskip("jax")
jnp = pytest.importorskip("jax.numpy")


# ---------------------------------------------------------------------------
# IN718 fixture
# ---------------------------------------------------------------------------


@pytest.fixture(scope="module")
def in718():
    from austenite.jax_backend import in718_props
    return in718_props()


@pytest.fixture(scope="module")
def ti64():
    from austenite.jax_backend import ti64_props
    return ti64_props()


# ---------------------------------------------------------------------------
# Rosenthal
# ---------------------------------------------------------------------------


def test_rosenthal_runs_and_returns_pytree(in718) -> None:
    from austenite.jax_backend import meltpool_rosenthal_jax, MeltPoolJaxResult

    r = meltpool_rosenthal_jax(285.0, 960.0, in718)
    assert isinstance(r, MeltPoolJaxResult)
    assert math.isfinite(float(r.L_mm))
    assert float(r.L_mm) > 0
    assert float(r.W_mm) > 0
    assert float(r.D_mm) > 0


def test_rosenthal_grad_w_r_t_power_positive(in718) -> None:
    """More power → longer pool: dL/dP > 0."""

    from austenite.jax_backend import meltpool_rosenthal_jax

    def L_of(P):
        return meltpool_rosenthal_jax(P, 960.0, in718).L_mm

    g = jax.grad(L_of)(jnp.float32(285.0))
    assert float(g) > 0, f"dL/dP must be positive; got {float(g)}"


# ---------------------------------------------------------------------------
# Eagar-Tsai
# ---------------------------------------------------------------------------


def test_eagar_tsai_runs(in718) -> None:
    from austenite.jax_backend import meltpool_eagar_tsai_jax

    r = meltpool_eagar_tsai_jax(285.0, 960.0, in718)
    assert math.isfinite(float(r.L_mm))
    assert 0.05 < float(r.L_mm) < 5.0


def test_eagar_tsai_grad_dL_dP_finite_and_positive(in718) -> None:
    """``dL/dP`` from the Eagar-Tsai model is finite and positive."""

    from austenite.jax_backend import meltpool_eagar_tsai_jax

    def L_of(P):
        return meltpool_eagar_tsai_jax(P, 960.0, in718).L_mm

    dL_dP = jax.grad(L_of)(jnp.float32(285.0))
    assert math.isfinite(float(dL_dP))
    assert float(dL_dP) > 0


def test_eagar_tsai_grad_matches_finite_diff_dL_dP(in718) -> None:
    """Autodiff dL/dP matches central FD within 5 %."""

    from austenite.jax_backend import meltpool_eagar_tsai_jax

    def L_of(P):
        return meltpool_eagar_tsai_jax(P, 960.0, in718).L_mm

    dL_dP_ad = float(jax.grad(L_of)(jnp.float32(285.0)))
    eps = 1.0
    fd = (float(L_of(jnp.float32(285.0 + eps)))
          - float(L_of(jnp.float32(285.0 - eps)))) / (2 * eps)
    rel = abs(fd - dL_dP_ad) / max(abs(fd), 1e-9)
    assert rel < 0.05, f"FD {fd:.6g} vs AD {dL_dP_ad:.6g}; rel={rel:.2%}"


# ---------------------------------------------------------------------------
# Goldak
# ---------------------------------------------------------------------------


def test_goldak_runs(in718) -> None:
    from austenite.jax_backend import meltpool_goldak_jax

    r = meltpool_goldak_jax(285.0, 960.0, in718)
    assert math.isfinite(float(r.L_mm))
    assert math.isfinite(float(r.T_peak_K))


def test_goldak_grad_w_r_t_a_f_finite(in718) -> None:
    """``dL/da_f`` is finite (Goldak ellipsoid length increases with a_f)."""

    from austenite.jax_backend import meltpool_goldak_jax

    def L_of(a_f):
        return meltpool_goldak_jax(285.0, 960.0, in718, a_f_mm=a_f).L_mm

    g = jax.grad(L_of)(jnp.float32(0.25))
    assert math.isfinite(float(g))
    assert float(g) > 0  # increasing a_f extends the front lobe → longer pool


# ---------------------------------------------------------------------------
# Vmap composition
# ---------------------------------------------------------------------------


def test_eagar_tsai_vmap_over_powers(in718) -> None:
    """vmap a power sweep without crashing."""

    from austenite.jax_backend import meltpool_eagar_tsai_jax

    powers = jnp.array([100.0, 200.0, 300.0, 400.0], dtype=jnp.float32)
    fn = jax.vmap(lambda P: meltpool_eagar_tsai_jax(P, 960.0, in718).L_mm)
    Ls = fn(powers)
    assert Ls.shape == (4,)
    assert bool(jnp.all(jnp.isfinite(Ls)))
    # Monotonic increasing in power
    diffs = jnp.diff(Ls)
    assert bool(jnp.all(diffs > 0))


# ---------------------------------------------------------------------------
# Ti-6Al-4V smoke
# ---------------------------------------------------------------------------


def test_eagar_tsai_ti64(ti64) -> None:
    from austenite.jax_backend import meltpool_eagar_tsai_jax

    r = meltpool_eagar_tsai_jax(285.0, 960.0, ti64)
    # Ti-6Al-4V has lower k than IN718 -> larger pool for same power
    assert math.isfinite(float(r.L_mm))
    assert float(r.L_mm) > 0
