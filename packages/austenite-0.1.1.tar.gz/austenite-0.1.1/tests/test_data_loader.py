"""Tests for au.data.* lazy-loaded reference datasets."""

from __future__ import annotations

import pytest

import austenite as au


# ---------------------------------------------------------------------------
# alloys.json
# ---------------------------------------------------------------------------


def test_alloys_loads_and_is_nonempty() -> None:
    df = au.data.alloys()
    n = len(df) if not hasattr(df, "shape") else df.shape[0]
    assert n >= 100, f"alloys count = {n}"


def test_alloys_production_size_expanded() -> None:
    """After data expansion the alloy catalog should hold 600+ grades."""

    df = au.data.alloys()
    n = len(df) if not hasattr(df, "shape") else df.shape[0]
    assert n >= 600, f"alloys count = {n} (expected >= 600 post-expansion)"


def test_alloys_every_entry_has_citation() -> None:
    """Every alloy entry must carry a non-empty citation string (no invented data)."""

    pd = pytest.importorskip("pandas")
    df = au.data.alloys()
    # citation is a required column
    assert "citation" in df.columns
    missing = df[df["citation"].isna() | (df["citation"].astype(str).str.len() == 0)]
    assert len(missing) == 0, (
        f"{len(missing)} alloy rows missing citation; first: "
        f"{missing.iloc[0].to_dict() if len(missing) else 'n/a'}"
    )


def test_alloys_filter_by_family() -> None:
    pd = pytest.importorskip("pandas")
    df = au.data.alloys()
    ni = df[df["family"] == "Nickel Alloy"]
    assert len(ni) >= 5
    for col in ("Sy_MPa", "Sut_MPa", "E_GPa", "rho_kg_m3"):
        assert col in ni.columns


def test_alloys_family_coverage_expanded() -> None:
    """Production catalog should span at least 10 distinct alloy families."""

    pd = pytest.importorskip("pandas")
    df = au.data.alloys()
    families = set(df["family"].dropna().unique())
    # Carbon Steel, Low-Alloy, Cr-Mo, Stainless Austenitic, Duplex, PH,
    # Nickel Alloy, Titanium Alloy, Aluminum Alloy, Copper Alloy, Cast Iron,
    # Tool Steel, Cobalt Alloy, Refractory Metal, Polymer, Ceramic, etc.
    assert len(families) >= 10, f"only {len(families)} families: {families}"


def test_alloy_lookup_by_asme_code() -> None:
    row = au.data.alloy_lookup("SA-516 Gr 70")
    assert row is not None
    assert row["Sy_MPa"] == 260
    assert "citation" in row


def test_alloy_lookup_case_insensitive() -> None:
    assert au.data.alloy_lookup("sa-240 304") is not None
    assert au.data.alloy_lookup("SA-240 304") is not None


def test_alloy_lookup_unknown_returns_none() -> None:
    assert au.data.alloy_lookup("NOT-A-REAL-GRADE-XYZ") is None


def test_alloy_lookup_new_grades_resolve() -> None:
    """Spot-check a handful of newly-added grades that engineers expect to find."""

    for query in ("A992", "Inconel 718", "Ti-6Al-4V", "7050-T7451", "Hastelloy X"):
        row = au.data.alloy_lookup(query)
        assert row is not None, f"failed to resolve {query!r} from expanded catalog"


# ---------------------------------------------------------------------------
# fatigue_curves.json
# ---------------------------------------------------------------------------


def test_fatigue_curves_loads_all() -> None:
    df = au.data.fatigue_curves()
    n = len(df) if not hasattr(df, "shape") else df.shape[0]
    assert n >= 30, f"fatigue curve count = {n}"


def test_fatigue_curves_production_size_expanded() -> None:
    """After expansion the S-N curve database should hold 150+ entries."""

    df = au.data.fatigue_curves()
    n = len(df) if not hasattr(df, "shape") else df.shape[0]
    assert n >= 150, f"fatigue curve count = {n} (expected >= 150 post-expansion)"


def test_fatigue_curves_every_entry_has_citation() -> None:
    pd = pytest.importorskip("pandas")
    df = au.data.fatigue_curves()
    assert "citation" in df.columns
    missing = df[df["citation"].isna() | (df["citation"].astype(str).str.len() == 0)]
    assert len(missing) == 0


def test_fatigue_curves_filter_by_alloy() -> None:
    pd = pytest.importorskip("pandas")
    df = au.data.fatigue_curves(alloy="4140")
    assert len(df) >= 1
    assert all("4140" in str(a).lower() or "4140" in str(a) for a in df["alloy"])


def test_fatigue_curves_includes_iiw_fat_classes() -> None:
    """Expanded catalog must include IIW Hobbacher weld FAT-classes."""

    pd = pytest.importorskip("pandas")
    df = au.data.fatigue_curves(alloy="FAT")
    assert len(df) >= 5  # FAT-36 through FAT-160 added


def test_fatigue_curves_schema_complete() -> None:
    pd = pytest.importorskip("pandas")
    df = au.data.fatigue_curves()
    required = ("alloy", "sigma_f_MPa", "b", "Se_MPa", "Ne_cycles", "citation")
    for c in required:
        assert c in df.columns, f"missing column {c}"


# ---------------------------------------------------------------------------
# kic_database.json
# ---------------------------------------------------------------------------


def test_kic_database_loads_all() -> None:
    df = au.data.kic_database()
    n = len(df) if not hasattr(df, "shape") else df.shape[0]
    assert n >= 30, f"K_IC entry count = {n}"


def test_kic_database_production_size_expanded() -> None:
    """After expansion the K_IC database should hold 200+ entries."""

    df = au.data.kic_database()
    n = len(df) if not hasattr(df, "shape") else df.shape[0]
    assert n >= 200, f"K_IC count = {n} (expected >= 200 post-expansion)"


def test_kic_database_every_entry_has_citation() -> None:
    pd = pytest.importorskip("pandas")
    df = au.data.kic_database()
    assert "citation" in df.columns
    missing = df[df["citation"].isna() | (df["citation"].astype(str).str.len() == 0)]
    assert len(missing) == 0


def test_kic_database_filter_by_alloy_titanium() -> None:
    pd = pytest.importorskip("pandas")
    df = au.data.kic_database(alloy="Ti-6Al-4V")
    assert len(df) >= 1
    for k in df["K_IC_MPa_sqrt_m"]:
        assert k > 0


def test_kic_database_transition_temperature_curves() -> None:
    """Ferritic steels should have multiple temperatures (transition curve)."""

    pd = pytest.importorskip("pandas")
    df = au.data.kic_database(alloy="A516 Gr 70")
    # Multiple T values for one ferritic steel demonstrates transition coverage
    assert len(df) >= 2
    temps = sorted(set(df["temperature_C"].tolist()))
    assert len(temps) >= 2


def test_kic_database_schema_complete() -> None:
    pd = pytest.importorskip("pandas")
    df = au.data.kic_database()
    required = ("alloy", "K_IC_MPa_sqrt_m", "temperature_C", "citation")
    for c in required:
        assert c in df.columns, f"missing column {c}"


# ---------------------------------------------------------------------------
# published_benchmarks.json
# ---------------------------------------------------------------------------


def test_published_benchmarks_load() -> None:
    df = au.data.published_benchmarks()
    n = len(df) if not hasattr(df, "shape") else df.shape[0]
    assert n >= 15, f"benchmark count = {n}"


def test_published_benchmarks_have_required_columns() -> None:
    pd = pytest.importorskip("pandas")
    df = au.data.published_benchmarks()
    required = ("id", "capability", "input", "expected", "tolerance_pct", "citation")
    for c in required:
        assert c in df.columns


# ---------------------------------------------------------------------------
# open_tdb stub
# ---------------------------------------------------------------------------


def test_open_tdb_raises_not_implemented() -> None:
    with pytest.raises(NotImplementedError, match="pycalphad"):
        au.data.open_tdb("nonexistent.tdb")
