"""Tests for the DNV-OS-F101 compliance checker.

Covers PASS / FAIL on composition, CE_IIW auto-derivation, and the
top-level ``au.compliance.check_standard`` dispatcher.
"""

from __future__ import annotations

import pytest

import austenite as au
from austenite.compliance_standards import StandardVerdict, dnv_os_f101


def test_dnv_os_f101_pass_typical_X65() -> None:
    """An X65-class composition + mechanical envelope should pass."""

    v = dnv_os_f101.check(
        composition={
            "C": 0.10, "Si": 0.30, "Mn": 1.40, "P": 0.012, "S": 0.003,
            "Cu": 0.10, "Ni": 0.20, "Cr": 0.05, "Mo": 0.05,
            "V": 0.05, "Nb": 0.04, "Ti": 0.02,
        },
        mechanical={
            "sigma_y_MPa": 450, "sigma_uts_MPa": 540,
            "elongation_pct": 24, "CVN_J_at_-30C": 70, "hardness_HV": 220,
        },
    )
    assert isinstance(v, StandardVerdict)
    assert v.passed is True
    assert v.failed_items == []
    assert v.spec_id == "DNV-OS-F101"
    # CE_IIW should have been derived and noted within limit
    assert any("CE_IIW" in n for n in v.notes)


def test_dnv_os_f101_fail_carbon_too_high() -> None:
    """Carbon above 0.16 wt% should fail."""

    v = dnv_os_f101.check(composition={"C": 0.20, "Mn": 1.20, "P": 0.012, "S": 0.005})
    assert v.passed is False
    assert any("C =" in f and "exceeds max 0.16" in f for f in v.failed_items)


def test_dnv_os_f101_fail_low_charpy() -> None:
    """Charpy < 27 J at -30 °C should fail even if chemistry is fine."""

    v = dnv_os_f101.check(
        composition={"C": 0.10, "Mn": 1.30, "P": 0.010, "S": 0.003},
        mechanical={"sigma_y_MPa": 450, "sigma_uts_MPa": 540,
                    "elongation_pct": 24, "CVN_J_at_-30C": 15},
    )
    assert v.passed is False
    assert any("CVN_J_at_-30C" in f and "below min 27" in f for f in v.failed_items)


def test_dnv_os_f101_via_dispatcher_and_alias() -> None:
    """``au.compliance.check_standard("dnv")`` should resolve via alias."""

    v = au.compliance.check_standard(
        "dnv",
        composition={"C": 0.10, "Mn": 1.30, "P": 0.010, "S": 0.003},
    )
    assert isinstance(v, StandardVerdict)
    assert v.passed is True
    assert v.spec_id == "DNV-OS-F101"
    assert v.citation.startswith("DNV-OS-F101")
