"""Tests for au.corrosion — CO2, sulfidation, amine SCC, K_ISCC, NACE, pitting."""
from __future__ import annotations

import math
import pytest

from austenite.corrosion import (
    SourServiceEnvelope,
    arrhenius_corrosion_rate,
    cassagne_amine_scc_rate,
    de_waard_lotz_co2_rate,
    galvele_pitting_potential,
    gerberich_KISCC,
    krom_bakker_H_flux,
    mcconomy_sulfidation_rate,
    nace_mr0175_envelope,
)


# ---------------------------------------------------------------------------
# de Waard-Lotz CO2
# ---------------------------------------------------------------------------


def test_de_waard_lotz_basic_finite():
    cr = de_waard_lotz_co2_rate(T_C=80, p_CO2_bar=2.0)
    assert math.isfinite(cr)
    assert cr > 0


def test_de_waard_lotz_higher_T_higher_rate():
    cr_lo = de_waard_lotz_co2_rate(T_C=40, p_CO2_bar=1.0)
    cr_hi = de_waard_lotz_co2_rate(T_C=120, p_CO2_bar=1.0)
    assert cr_hi > cr_lo


def test_de_waard_lotz_higher_pCO2_higher_rate():
    cr_lo = de_waard_lotz_co2_rate(T_C=80, p_CO2_bar=0.1)
    cr_hi = de_waard_lotz_co2_rate(T_C=80, p_CO2_bar=10.0)
    assert cr_hi > cr_lo


def test_de_waard_lotz_higher_pH_less_corrosion():
    """Higher pH (less acid) → less corrosion."""
    cr_acid = de_waard_lotz_co2_rate(T_C=80, p_CO2_bar=1.0, pH=4.0)
    cr_neutral = de_waard_lotz_co2_rate(T_C=80, p_CO2_bar=1.0, pH=7.0)
    assert cr_acid > cr_neutral


def test_de_waard_lotz_scale_factor_reduces_rate():
    cr_no_scale = de_waard_lotz_co2_rate(T_C=80, p_CO2_bar=1.0, f_scale=1.0)
    cr_with_scale = de_waard_lotz_co2_rate(T_C=80, p_CO2_bar=1.0, f_scale=0.2)
    assert cr_with_scale < cr_no_scale


def test_de_waard_lotz_zero_co2_returns_zero():
    assert de_waard_lotz_co2_rate(T_C=80, p_CO2_bar=0) == 0.0


# ---------------------------------------------------------------------------
# McConomy sulfidation
# ---------------------------------------------------------------------------


def test_mcconomy_basic_finite():
    cr = mcconomy_sulfidation_rate(T_C=400, H2S_ppm=500, alloy="5Cr")
    assert math.isfinite(cr)
    assert cr >= 0


def test_mcconomy_higher_alloy_lower_rate():
    """Higher Cr content → lower sulfidation rate."""
    cr_cs = mcconomy_sulfidation_rate(T_C=350, H2S_ppm=1000, alloy="CS")
    cr_5cr = mcconomy_sulfidation_rate(T_C=350, H2S_ppm=1000, alloy="5Cr")
    cr_316 = mcconomy_sulfidation_rate(T_C=350, H2S_ppm=1000, alloy="18Cr-8Ni")
    assert cr_cs > cr_5cr > cr_316


def test_mcconomy_zero_H2S_returns_zero():
    assert mcconomy_sulfidation_rate(T_C=350, H2S_ppm=0, alloy="CS") == 0.0


# ---------------------------------------------------------------------------
# Cassagne amine SCC
# ---------------------------------------------------------------------------


def test_cassagne_active_region_finite():
    cr = cassagne_amine_scc_rate(
        T_C=100, amine_type="MEA", amine_loading=0.3,
        co2_loading=0.5, stress_ratio_to_yield=0.6,
    )
    assert math.isfinite(cr)


def test_cassagne_below_critical_stress_returns_zero():
    """Stress < 0.3·σ_y → no SCC."""
    cr = cassagne_amine_scc_rate(
        T_C=100, amine_type="MEA", amine_loading=0.3, stress_ratio_to_yield=0.1,
    )
    assert cr == 0.0


def test_cassagne_outside_T_envelope_returns_zero():
    """T below 60°C → no MEA SCC."""
    cr = cassagne_amine_scc_rate(
        T_C=20, amine_type="MEA", amine_loading=0.3, stress_ratio_to_yield=0.6,
    )
    assert cr == 0.0


def test_cassagne_rich_co2_higher_rate():
    cr_lean = cassagne_amine_scc_rate(
        T_C=100, amine_type="MEA", amine_loading=0.3,
        co2_loading=0.1, stress_ratio_to_yield=0.6,
    )
    cr_rich = cassagne_amine_scc_rate(
        T_C=100, amine_type="MEA", amine_loading=0.3,
        co2_loading=1.5, stress_ratio_to_yield=0.6,
    )
    assert cr_rich > cr_lean


# ---------------------------------------------------------------------------
# Gerberich-Wozniak K_ISCC
# ---------------------------------------------------------------------------


def test_gerberich_zero_H_returns_KIc():
    """Zero H → K_ISCC ≈ K_Ic (no H-embrittlement)."""
    K = gerberich_KISCC(sigma_y_MPa=500, H_concentration_ppm=0, KIc_MPa_sqm=80)
    # σ_y=500, σ_y_ref=1400 → factor = 0.643 — so K_ISCC = 80 * 0.643 ≈ 51
    assert K > 0
    assert K <= 80


def test_gerberich_higher_H_lower_KISCC():
    K_low = gerberich_KISCC(sigma_y_MPa=500, H_concentration_ppm=1, KIc_MPa_sqm=80)
    K_high = gerberich_KISCC(sigma_y_MPa=500, H_concentration_ppm=10, KIc_MPa_sqm=80)
    assert K_high < K_low


def test_gerberich_higher_yield_lower_KISCC():
    """Higher yield strength → more H-susceptible → lower K_ISCC."""
    K_low_sy = gerberich_KISCC(sigma_y_MPa=400, H_concentration_ppm=2, KIc_MPa_sqm=80)
    K_hi_sy = gerberich_KISCC(sigma_y_MPa=1100, H_concentration_ppm=2, KIc_MPa_sqm=80)
    assert K_hi_sy < K_low_sy


# ---------------------------------------------------------------------------
# NACE MR0175 envelope
# ---------------------------------------------------------------------------


def test_nace_sweet_service_region_0():
    """Very low H2S → region 0 (sweet)."""
    r = nace_mr0175_envelope(pH2S_bar=0.0001, pH_field=7.0)
    assert isinstance(r, SourServiceEnvelope)
    assert r.envelope_region == "region-0"
    assert r.passed


def test_nace_mild_sour_region_1():
    r = nace_mr0175_envelope(pH2S_bar=0.005, pH_field=6.0)
    assert r.envelope_region == "region-1"
    assert r.HV_max_required == 250.0


def test_nace_severe_sour_region_3_low_HV_required():
    """High p(H2S) + low pH → region 3 (severe)."""
    r = nace_mr0175_envelope(pH2S_bar=0.5, pH_field=3.5)
    assert r.envelope_region == "region-3"
    assert r.HV_max_required == 237.0


def test_nace_high_chloride_adds_note():
    r = nace_mr0175_envelope(pH2S_bar=0.005, pH_field=5.5, chloride_mg_L=80_000)
    assert any("Cl" in note or "chloride" in note.lower() for note in r.notes)


# ---------------------------------------------------------------------------
# Galvele pitting potential
# ---------------------------------------------------------------------------


def test_galvele_basic_316L():
    E_pit = galvele_pitting_potential(chloride_concentration_M=1.0, alloy="316L")
    assert math.isfinite(E_pit)


def test_galvele_higher_Cl_lower_Epit():
    """Higher chloride → easier pitting → lower E_pit."""
    E_lo = galvele_pitting_potential(chloride_concentration_M=0.1, alloy="316L")
    E_hi = galvele_pitting_potential(chloride_concentration_M=5.0, alloy="316L")
    assert E_lo > E_hi


def test_galvele_higher_Cr_alloy_higher_Epit():
    """Duplex 2205 has more Cr+Mo → higher pitting potential than 304."""
    E_304 = galvele_pitting_potential(chloride_concentration_M=1.0, alloy="304")
    E_2205 = galvele_pitting_potential(chloride_concentration_M=1.0, alloy="duplex-2205")
    assert E_2205 > E_304


def test_galvele_zero_chloride_returns_inf():
    """No Cl → no pitting → E_pit → ∞."""
    E = galvele_pitting_potential(chloride_concentration_M=0)
    assert math.isinf(E)


# ---------------------------------------------------------------------------
# Krom-Bakker H flux
# ---------------------------------------------------------------------------


def test_krom_bakker_basic():
    J = krom_bakker_H_flux(sigma_normal_MPa=200, T_C=25)
    assert math.isfinite(J)
    assert J > 0


def test_krom_bakker_higher_stress_higher_flux():
    """Tensile stress enhances H permeation."""
    J_lo = krom_bakker_H_flux(sigma_normal_MPa=50, T_C=25)
    J_hi = krom_bakker_H_flux(sigma_normal_MPa=300, T_C=25)
    assert J_hi > J_lo


# ---------------------------------------------------------------------------
# Arrhenius
# ---------------------------------------------------------------------------


def test_arrhenius_higher_T_higher_rate():
    cr_lo = arrhenius_corrosion_rate(T_C=50, A=1e10, Q_kJ_mol=80)
    cr_hi = arrhenius_corrosion_rate(T_C=120, A=1e10, Q_kJ_mol=80)
    assert cr_hi > cr_lo


def test_arrhenius_reference_scaling():
    """When reference rate is given, T=T_ref should return same value."""
    cr = arrhenius_corrosion_rate(
        T_C=25, A=0,  # A unused when ref given
        Q_kJ_mol=80,
        reference_rate_at_T_ref_mmyr=0.5, T_ref_C=25,
    )
    assert math.isclose(cr, 0.5, rel_tol=1e-9)
