"""Tests for ``austenite.io.materials_project`` — MP REST bridge.

Two layers:

1. **Offline tests** — the import-error path, the data classes, and
   cross-validation math (driven through ``austenite_calphad_fn`` injection
   so no network is needed). These run on every CI.

2. **Live tests** — gated by ``MP_API_KEY`` env var. They hit the real MP
   API. These are SKIPPED by default in CI.
"""

from __future__ import annotations

import os
import sys
from unittest import mock

import pytest

from austenite.io.materials_project import (
    MaterialsProjectAuthError,
    MaterialsProjectImportError,
    MpCrossValidation,
    MpEntry,
    _build_crossval,
    _get_api_key,
    cross_validate_calphad,
)


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


def test_mp_entry_to_dict_roundtrip() -> None:
    e = MpEntry(
        material_id="mp-150",
        formula="Fe",
        elements=["Fe"],
        formation_energy_per_atom_eV=0.0,
        energy_above_hull_eV=0.0,
        symmetry="Im-3m",
        nsites=2,
    )
    d = e.to_dict()
    assert d["material_id"] == "mp-150"
    assert d["symmetry"] == "Im-3m"
    assert d["formation_energy_per_atom_eV"] == 0.0


def test_mp_crossvalidation_to_dict_keys_match_api_contract() -> None:
    cv = MpCrossValidation(
        austenite_G_kJ=[-50.0, -30.0],
        mp_dft_G_kJ=[-48.0, -32.0],
        material_ids=["mp-1", "mp-2"],
        r2=0.9,
        mae_kJ=2.0,
        n_entries=2,
    )
    d = cv.to_dict()
    for k in ("austenite_G", "mp_dft_G", "material_ids", "r2", "mae_kJ", "n_entries"):
        assert k in d


# ---------------------------------------------------------------------------
# Cross-validation math (mocked CALPHAD function)
# ---------------------------------------------------------------------------


def test_build_crossval_perfect_match_returns_r2_one() -> None:
    cv = _build_crossval([1.0, 2.0, 3.0], [1.0, 2.0, 3.0], ["a", "b", "c"])
    assert pytest.approx(cv.r2) == 1.0
    assert cv.mae_kJ == 0.0
    assert cv.n_entries == 3


def test_build_crossval_constant_mp_returns_zero_r2() -> None:
    # ss_tot = 0 when all mp values identical → r2 falls back to 0.
    cv = _build_crossval([1.0, 2.0, 3.0], [5.0, 5.0, 5.0], ["a", "b", "c"])
    assert cv.r2 == 0.0


def test_build_crossval_n_less_than_2_returns_empty_stats() -> None:
    cv = _build_crossval([1.0], [1.0], ["a"])
    assert cv.r2 == 0.0
    assert cv.mae_kJ == 0.0


def test_build_crossval_mae_is_l1_mean() -> None:
    cv = _build_crossval([1.0, 2.0, 3.0], [2.0, 4.0, 6.0], ["a", "b", "c"])
    # |1-2| + |2-4| + |3-6| = 6 → mae = 2.0
    assert pytest.approx(cv.mae_kJ) == 2.0
    assert -10.0 < cv.r2 < 1.0  # imperfect match → r2 < 1


# ---------------------------------------------------------------------------
# Auth + import-error paths
# ---------------------------------------------------------------------------


def test_missing_api_key_raises_auth_error(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("MP_API_KEY", raising=False)
    with pytest.raises(MaterialsProjectAuthError) as excinfo:
        _get_api_key()
    assert "MP_API_KEY" in str(excinfo.value)
    assert "materialsproject.org" in str(excinfo.value)


def test_present_api_key_returns_value(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("MP_API_KEY", "test-key-deadbeef")
    assert _get_api_key() == "test-key-deadbeef"


def test_query_empty_elements_raises() -> None:
    from austenite.io.materials_project import query

    with pytest.raises(ValueError, match="elements"):
        query([])


def test_query_missing_mp_api_raises_import_error(monkeypatch: pytest.MonkeyPatch) -> None:
    """When mp-api is not installed the import path raises with hint."""

    monkeypatch.setenv("MP_API_KEY", "test-key")
    # Force the mp_api import to fail
    real_modules = sys.modules.copy()
    monkeypatch.setitem(sys.modules, "mp_api", None)
    monkeypatch.setitem(sys.modules, "mp_api.client", None)

    from austenite.io.materials_project import query

    with pytest.raises(MaterialsProjectImportError) as excinfo:
        query(["Fe", "Cr"])
    msg = str(excinfo.value)
    assert "mp-api" in msg
    assert "austenite[mp]" in msg


# ---------------------------------------------------------------------------
# Cross-validate with injected CALPHAD function (offline path)
# ---------------------------------------------------------------------------


def test_cross_validate_with_injected_calphad_returns_zero_when_no_mp(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If the MP query path raises (no key) we expect a clean error
    surface — not a silent zero result. This verifies the auth check is
    reachable."""

    monkeypatch.delenv("MP_API_KEY", raising=False)
    # Either auth-error (mp_api installed but no key) OR import-error (mp_api
    # not installed) is acceptable — both surface a clean error to the user.
    with pytest.raises((MaterialsProjectAuthError, MaterialsProjectImportError)):
        cross_validate_calphad(["Fe", "Cr"])


def test_cross_validate_passes_calphad_fn_when_entries_supplied(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Inject a fake ``query`` returning two entries and a CALPHAD
    function that returns a constant. The R^2 / MAE math should still
    execute without hitting MP."""

    fake_entries = [
        MpEntry(
            material_id="mp-FAKE1",
            formula="FeCr",
            elements=["Fe", "Cr"],
            formation_energy_per_atom_eV=-0.5,
            nsites=2,
        ),
        MpEntry(
            material_id="mp-FAKE2",
            formula="FeNi",
            elements=["Fe", "Ni"],
            formation_energy_per_atom_eV=-0.4,
            nsites=2,
        ),
    ]
    monkeypatch.setattr(
        "austenite.io.materials_project.query",
        lambda *a, **kw: fake_entries,
    )

    cv = cross_validate_calphad(
        ["Fe", "Cr", "Ni"],
        T_K=1273.0,
        austenite_calphad_fn=lambda comp, T: -45000.0,  # constant J/mol
    )
    assert cv.n_entries == 2
    assert cv.material_ids == ["mp-FAKE1", "mp-FAKE2"]
    # MP energies in kJ/mol: -0.5 eV/atom × 96.485 = -48.24, -0.4 → -38.59
    assert -50.0 < cv.mp_dft_G_kJ[0] < -45.0
    assert -40.0 < cv.mp_dft_G_kJ[1] < -35.0
    # austenite returns -45.0 kJ/mol for both
    assert all(g == -45.0 for g in cv.austenite_G_kJ)


# ---------------------------------------------------------------------------
# Live MP tests — opt-in via MP_API_KEY
# ---------------------------------------------------------------------------


@pytest.mark.skipif(
    not os.environ.get("MP_API_KEY"),
    reason="MP_API_KEY not set — live MP tests skipped",
)
def test_query_fe_returns_at_least_one_entry() -> None:  # pragma: no cover - live
    from austenite.io.materials_project import query

    entries = query(["Fe"], max_results=3)
    assert len(entries) >= 1
    assert any("Fe" in e.elements or "FE" in [x.upper() for x in e.elements]
               for e in entries)
