"""Tests for au.validate — per-capability oracle validation badges."""

from __future__ import annotations

import pytest

import austenite as au
from austenite.validate import (
    AllBadges,
    Badge,
    badge_for,
    generate_all_badges,
    list_capabilities,
)


# ---------------------------------------------------------------------------
# badge_for
# ---------------------------------------------------------------------------


def test_badge_for_am_qualification_returns_validated_badge():
    b = badge_for("am_qualification")
    assert isinstance(b, Badge)
    assert b.n_cases > 0
    assert 0 <= b.n_pass <= b.n_cases
    # shields.io url
    assert "img.shields.io" in b.shields_url
    # references include Promoppatum or King
    refs_blob = " ".join(b.references)
    assert "Promoppatum" in refs_blob or "King" in refs_blob


def test_badge_for_markdown_includes_pass_rate_and_max_err():
    b = badge_for("am_qualification")
    md = b.markdown()
    assert "validated" in md.lower() or "Validated" in md
    assert f"{b.n_pass}" in md
    assert f"{b.n_cases}" in md
    assert "Max error" in md


def test_badge_for_unknown_capability_raises_notimplemented():
    with pytest.raises(NotImplementedError):
        badge_for("unknown_capability_xyz")


def test_badge_for_empty_string_raises_value():
    with pytest.raises(ValueError):
        badge_for("")


def test_badge_for_pass_rate_calculated():
    b = badge_for("design_path")
    # pass_rate = n_pass / n_cases
    assert abs(b.pass_rate - b.n_pass / b.n_cases) < 1e-9


def test_badge_for_color_green_when_high_pass_rate():
    """A capability with >= 95% pass and <= 10% err should be green."""

    b = badge_for("design_path")  # 24/25 pass, 8% max err → green
    assert b.color in ("green", "yellowgreen")


def test_badge_to_dict_includes_pass_rate_and_url():
    b = badge_for("ffs")
    d = b.to_dict()
    assert "pass_rate" in d
    assert "shields_url" in d
    assert d["n_cases"] == b.n_cases


# ---------------------------------------------------------------------------
# generate_all_badges
# ---------------------------------------------------------------------------


def test_generate_all_badges_returns_one_per_capability():
    ab = generate_all_badges()
    assert isinstance(ab, AllBadges)
    assert len(ab) >= 5  # the ship list has ≥10 capabilities
    # iter works
    for b in ab:
        assert isinstance(b, Badge)


def test_generate_all_badges_markdown_includes_every_capability():
    ab = generate_all_badges()
    md = ab.markdown()
    assert "Austenite Validation Badges" in md
    for cap in list_capabilities():
        if cap in ab.badges:
            assert cap in md


# ---------------------------------------------------------------------------
# list_capabilities
# ---------------------------------------------------------------------------


def test_list_capabilities_includes_key_capabilities():
    caps = list_capabilities()
    assert "am_qualification" in caps
    assert "design_path" in caps
    assert "ffs" in caps


# ---------------------------------------------------------------------------
# Lazy load via au.* namespace
# ---------------------------------------------------------------------------


def test_lazy_namespace():
    assert hasattr(au, "validate")
    assert callable(au.validate.badge_for)
