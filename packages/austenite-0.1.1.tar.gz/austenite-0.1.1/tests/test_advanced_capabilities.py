"""Tests for the 11 advanced-capability modules added in the Tier 1/2/3 push.

Modules:
  1. active_learning      — BALD / ALM / QBC
  2. icme_monte_carlo     — composition-uncertainty propagation
  3. creep_pinn           — Wilshire + PINN residual
  4. am_planner           — layer-wise build planning
  5. inverse_heat_treat   — target HV → schedule
  6. wps_generator        — auto-WPS per AWS D1.1 / ASME IX
  7. nace_mr0175          — BOM sour-service screen
  8. api581_scenarios     — cost-optimal RBI plan
  9. asme_iii             — NB Class 1 stress + fatigue
 10. ttt_cct              — composition → TTT/CCT
 11. lca, pbf_screening, welding_distortion, busbar_designer,
     phase_field_grain   — Tier 3 polish modules
"""

from __future__ import annotations

import math

import pytest


# ---------------------------------------------------------------------------
# 1. ACTIVE LEARNING
# ---------------------------------------------------------------------------


def test_bald_score_zero_when_no_epistemic() -> None:
    from austenite.active_learning import bald_score

    # If σ²_θ ≈ 0, BALD ≈ 0
    assert bald_score(0.0, 1.0) == 0.0


def test_bald_score_increases_with_epistemic() -> None:
    from austenite.active_learning import bald_score

    s_lo = bald_score(0.1, 1.1)
    s_hi = bald_score(1.0, 2.0)
    assert s_hi > s_lo > 0


def test_alm_score_returns_variance() -> None:
    from austenite.active_learning import alm_score

    assert alm_score(0.5) == 0.5
    assert alm_score(-1.0) == 0.0


def test_next_experiment_picks_highest() -> None:
    from austenite.active_learning import Candidate, next_experiment

    cs = [Candidate({"x": 1}, 5.0, 0.1), Candidate({"x": 2}, 5.0, 2.0),
          Candidate({"x": 3}, 5.0, 0.5)]
    out = next_experiment(cs, noise_variance=1.0, method="BALD", n_select=1)
    assert out[0].candidate.inputs["x"] == 2


def test_qbc_disagreement() -> None:
    from austenite.active_learning import query_by_committee_disagreement

    # 3 identical predictions → 0 disagreement
    assert query_by_committee_disagreement([5, 5, 5]) == 0.0
    # variation present
    v = query_by_committee_disagreement([1, 2, 3, 4])
    assert v > 0


# ---------------------------------------------------------------------------
# 2. ICME MONTE CARLO
# ---------------------------------------------------------------------------


def test_icme_mc_returns_valid_distribution() -> None:
    from austenite.icme_monte_carlo import CompositionUncertainty, run_probabilistic_icme

    comp = [
        CompositionUncertainty("Al", 0.5, 0.05),
        CompositionUncertainty("Ti", 0.9, 0.08),
    ]
    out = run_probabilistic_icme(comp, n_samples=200, seed=42)
    assert out.n_samples == 200
    assert out.mean_sigma_y_MPa > 0
    assert out.sigma_sigma_y_MPa >= 0
    lo, hi = out.hpd_sigma_y_95
    assert lo <= out.mean_sigma_y_MPa <= hi
    assert 0 <= out.p_survives_target_cycles <= 1


def test_icme_mc_handles_zero_uncertainty() -> None:
    from austenite.icme_monte_carlo import CompositionUncertainty, run_probabilistic_icme

    comp = [CompositionUncertainty("Al", 0.5, 0.0), CompositionUncertainty("Ti", 0.9, 0.0)]
    out = run_probabilistic_icme(comp, n_samples=100, seed=1)
    # Zero comp uncertainty → near-zero σ_y variance
    assert out.sigma_sigma_y_MPa < 1.0


# ---------------------------------------------------------------------------
# 3. CREEP PINN
# ---------------------------------------------------------------------------


def test_creep_pinn_drops_with_higher_stress() -> None:
    from austenite.creep_pinn import predict_creep_life

    r_lo = predict_creep_life("Grade91_9Cr1Mo", 100, 600, sigma_uts_MPa=560)
    r_hi = predict_creep_life("Grade91_9Cr1Mo", 200, 600, sigma_uts_MPa=560)
    assert r_lo.rupture_hours_classical > r_hi.rupture_hours_classical


def test_creep_pinn_unknown_alloy_passthrough() -> None:
    from austenite.creep_pinn import predict_creep_life

    r = predict_creep_life("Unobtanium-7", 150, 700, sigma_uts_MPa=600)
    # PINN correction = 1.0 for unknown alloy
    assert r.rupture_hours_pinn == r.rupture_hours_classical
    assert r.epistemic_factor == 1.0


def test_creep_pinn_disable_with_use_pinn_false() -> None:
    from austenite.creep_pinn import predict_creep_life

    r = predict_creep_life("Grade91_9Cr1Mo", 100, 600, sigma_uts_MPa=560, use_pinn=False)
    assert r.epistemic_factor == 1.0
    assert r.method == "Wilshire-only"


# ---------------------------------------------------------------------------
# 4. AM PLANNER
# ---------------------------------------------------------------------------


def test_am_planner_returns_layers() -> None:
    from austenite.am_planner import AlloyProperties, MachineSpec, plan_build

    m = MachineSpec(laser_power_W=250, scan_speed_mm_s=1200)
    a = AlloyProperties(name="IN718", k_W_mK=10.5, Cp_J_kgK=525, rho_kg_m3=8200,
                        T_solidus_K=1500, T_liquidus_K=1610, alpha_um_m_K=13)
    p = plan_build(n_layers=5, machine=m, alloy=a)
    assert p.n_layers == 5
    assert len(p.layers) == 5
    assert 0 <= p.overall_pof <= 1


def test_am_planner_keyhole_warning() -> None:
    from austenite.am_planner import AlloyProperties, MachineSpec, plan_build

    m = MachineSpec(laser_power_W=1000, scan_speed_mm_s=300)  # extreme power
    a = AlloyProperties(name="AlSi10Mg", k_W_mK=140, Cp_J_kgK=900, rho_kg_m3=2670,
                        T_solidus_K=830, T_liquidus_K=900, alpha_um_m_K=21)
    p = plan_build(n_layers=3, machine=m, alloy=a)
    # Likely keyhole regime
    assert any(L.normalized_enthalpy > 5 for L in p.layers)


# ---------------------------------------------------------------------------
# 5. INVERSE HEAT TREAT
# ---------------------------------------------------------------------------


def test_inverse_HT_finds_schedule() -> None:
    from austenite.inverse_heat_treat import design_heat_treat

    comp = {"C": 0.4, "Mn": 0.8, "Cr": 1.0, "Mo": 0.25}
    s = design_heat_treat(comp, target_HV=400)
    assert 100 < s.temper_T_C < 700
    assert 0 < s.temper_time_h <= 4
    assert s.quench_medium in ("oil", "water", "polymer")
    # Predicted HV within ±50 of target
    assert abs(s.predicted_HV - 400) < 75


def test_inverse_HT_sigma_y_target() -> None:
    from austenite.inverse_heat_treat import design_heat_treat

    comp = {"C": 0.4, "Mn": 0.8, "Cr": 1.0, "Mo": 0.25}
    s = design_heat_treat(comp, target_sigma_y_MPa=900)
    # σ_y from HV via Pavlina-Tyne is consistent
    expected_HV = (900 + 90.7) / 2.876
    assert abs(s.predicted_HV - expected_HV) < 100


def test_inverse_HT_raises_without_target() -> None:
    from austenite.inverse_heat_treat import design_heat_treat

    with pytest.raises(ValueError):
        design_heat_treat({"C": 0.4})


# ---------------------------------------------------------------------------
# 6. WPS GENERATOR
# ---------------------------------------------------------------------------


def test_wps_thin_carbon_steel_no_pwht() -> None:
    from austenite.wps_generator import recommend_wps

    w = recommend_wps("ASTM A516-70", "E7018", thickness_mm=12, p_number=1)
    assert not w.pwht_required
    assert w.preheat_C >= 0
    assert w.process == "SMAW"


def test_wps_thick_cr_mo_pwht() -> None:
    from austenite.wps_generator import recommend_wps

    w = recommend_wps("ASTM A335 P22", "E9018-B3", thickness_mm=50, p_number=5)
    assert w.pwht_required
    assert w.pwht_T_C > 700


def test_wps_austenitic_ss_no_pwht_low_interpass() -> None:
    from austenite.wps_generator import recommend_wps

    w = recommend_wps("ASTM A312 TP316L", "ER316L", thickness_mm=20, p_number=8,
                      process="GTAW")
    assert not w.pwht_required
    assert any("austenitic" in n.lower() for n in w.notes)


# ---------------------------------------------------------------------------
# 7. NACE MR0175 BOM CHECK
# ---------------------------------------------------------------------------


def test_nace_316SS_low_pH2S_low_T_passes() -> None:
    from austenite.nace_mr0175 import BOMComponent, check_component

    c = BOMComponent("V1", "316SS", service_T_C=50, pH2S_kPa=0.1, pH=6.0)
    r = check_component(c)
    assert r.compliant


def test_nace_316SS_severe_sour_fails() -> None:
    from austenite.nace_mr0175 import BOMComponent, check_component

    c = BOMComponent("V2", "316SS", service_T_C=80, pH2S_kPa=50, pH=3.5)
    r = check_component(c)
    assert not r.compliant


def test_nace_summary() -> None:
    from austenite.nace_mr0175 import BOMComponent, check_bom, summary

    bom = [
        BOMComponent("V1", "316SS", 50, 0.1, 6.0),
        BOMComponent("V2", "316SS", 80, 50, 3.5),
        BOMComponent("V3", "Inconel_625", 200, 50, 3.5),
    ]
    s = summary(check_bom(bom))
    assert s["n_total"] == 3
    assert s["n_fail"] >= 1
    assert "V2" in s["fail_tags"]


# ---------------------------------------------------------------------------
# 8. API 581 SCENARIO
# ---------------------------------------------------------------------------


def test_api581_pof_rises_with_time() -> None:
    from austenite.api581_scenarios import DamageState, pof_at_year

    s = DamageState("thinning", current_metric=2, rate_mean=0.5,
                    rate_sigma=0.1, critical_metric=10)
    pof_1y = pof_at_year(s, 1)
    pof_10y = pof_at_year(s, 10)
    assert pof_10y > pof_1y


def test_api581_selects_cheaper_inspection_when_low_pof() -> None:
    from austenite.api581_scenarios import (
        DamageState, default_inspection_catalogue, select_inspection_plan,
    )

    state = DamageState("thinning", 0.5, 0.1, 0.02, 10)
    plan = select_inspection_plan(
        state, default_inspection_catalogue(), consequence_usd=1e6,
    )
    # With low POF, VT or UT manual is sufficient
    assert plan.chosen_method in ("VT", "UT manual", "AUT (auto UT)", "RT", "PA-UT", "AET (continuous)")
    assert plan.expected_total_cost_usd > 0


def test_api581_selects_higher_pod_when_high_consequence() -> None:
    from austenite.api581_scenarios import (
        DamageState, default_inspection_catalogue, select_inspection_plan,
    )

    # Damage already near critical → real POF risk, high consequence
    state = DamageState("HTHA", current_metric=8.5, rate_mean=0.5,
                        rate_sigma=0.4, critical_metric=10)
    plan = select_inspection_plan(
        state, default_inspection_catalogue(), consequence_usd=1e9,
    )
    # With huge consequence + actual POF, higher-POD methods win
    assert plan.chosen_method in ("PA-UT", "AET (continuous)", "AUT (auto UT)", "RT", "UT manual")


# ---------------------------------------------------------------------------
# 9. ASME III NB
# ---------------------------------------------------------------------------


def test_asme_iii_primary_membrane_pass() -> None:
    from austenite.asme_iii import StressLinearization, assess_nb_class1

    sl = StressLinearization(P_m_MPa=100, P_b_MPa=50, Q_MPa=200, F_MPa=50)
    r = assess_nb_class1(sl, S_m_MPa=150)
    assert r.passes_NB3221_membrane
    assert r.passes_NB3221_bending
    assert r.passes_NB3222_secondary


def test_asme_iii_fatigue_usage_factor() -> None:
    from austenite.asme_iii import (
        asme_design_fatigue_curve_carbon_steel, fatigue_usage_factor,
    )

    curve = asme_design_fatigue_curve_carbon_steel()
    # 1000 cycles at 240 MPa S_a — N_allow ≈ 5000 → U = 0.2
    U = fatigue_usage_factor([(240.0, 1000)], curve)
    assert 0.1 <= U <= 0.4


def test_asme_iii_creep_fatigue_passes_origin() -> None:
    from austenite.asme_iii import creep_fatigue_NH_T1432

    ok, _ = creep_fatigue_NH_T1432(0.0, 0.0)
    assert ok


def test_asme_iii_creep_fatigue_fails_beyond_envelope() -> None:
    from austenite.asme_iii import creep_fatigue_NH_T1432

    ok, _ = creep_fatigue_NH_T1432(0.9, 0.9)
    assert not ok


# ---------------------------------------------------------------------------
# 10. TTT/CCT
# ---------------------------------------------------------------------------


def test_ttt_4140_steel() -> None:
    from austenite.ttt_cct import compute_ttt

    comp = {"C": 0.4, "Mn": 0.8, "Si": 0.25, "Cr": 1.0, "Mo": 0.25}
    ttt = compute_ttt(comp)
    # 4140 Ms ≈ 320-350 °C
    assert 280 <= ttt.Ms_C <= 380
    # Ae3 ≈ 800°C
    assert 750 <= ttt.Ae3_C <= 850
    # Bs > Ms
    assert ttt.Bs_C > ttt.Ms_C
    # Critical cooling rate positive
    assert ttt.critical_cooling_rate_C_s > 0


def test_ttt_high_C_steel_low_Ms() -> None:
    from austenite.ttt_cct import compute_ttt

    comp = {"C": 1.0, "Mn": 0.4}
    ttt = compute_ttt(comp)
    # High C steel has low Ms
    assert ttt.Ms_C < 250


# ---------------------------------------------------------------------------
# 11A. LCA
# ---------------------------------------------------------------------------


def test_lca_carbon_steel() -> None:
    from austenite.lca import assess

    r = assess("Carbon_Steel", mass_kg=100)
    assert r.total_CO2_kg == 1.9 * 100
    assert r.critical_minerals == []


def test_lca_nickel_alloy_has_critical() -> None:
    from austenite.lca import assess

    r = assess("Inconel_718", mass_kg=10)
    assert "Ni" in r.critical_minerals
    assert r.risk_score > 0.5


def test_lca_compare_sorts_by_co2() -> None:
    from austenite.lca import compare

    out = compare(["Inconel_718", "Carbon_Steel", "Stainless_316L"])
    co2s = [r.total_CO2_kg for r in out]
    assert co2s == sorted(co2s)


# ---------------------------------------------------------------------------
# 11B. PBF SCREENING
# ---------------------------------------------------------------------------


def test_pbf_screening_returns_grid() -> None:
    from austenite.am_planner import AlloyProperties
    from austenite.pbf_screening import screen_process_window

    a = AlloyProperties("IN718", 10.5, 525, 8200, 1500, 1610, 13)
    w = screen_process_window(a, n_P=4, n_v=4)
    assert len(w.P_grid_W) == 4
    assert len(w.pof_map) == 4
    assert len(w.pof_map[0]) == 4


def test_pbf_volumetric_energy_density() -> None:
    from austenite.pbf_screening import volumetric_energy_density

    ved = volumetric_energy_density(250, 1200, layer_um=30, hatch_um=100)
    # = 250 / (1200 · 0.03 · 0.1) = 69.4 J/mm³
    assert 50 < ved < 100


# ---------------------------------------------------------------------------
# 11C. WELDING DISTORTION
# ---------------------------------------------------------------------------


def test_welding_distortion_increases_with_heat_input() -> None:
    from austenite.welding_distortion import predict_distortion

    lo = predict_distortion(800, 10)
    hi = predict_distortion(2500, 10)
    assert hi.angular_distortion_deg > lo.angular_distortion_deg
    assert hi.transverse_shrinkage_mm > lo.transverse_shrinkage_mm


def test_welding_distortion_zero_thickness() -> None:
    from austenite.welding_distortion import predict_distortion

    r = predict_distortion(1000, 0)
    assert r.transverse_shrinkage_mm == 0.0
    assert r.angular_distortion_deg == 0.0


# ---------------------------------------------------------------------------
# 11D. BUSBAR DESIGNER
# ---------------------------------------------------------------------------


def test_busbar_design_cu_default() -> None:
    from austenite.busbar_designer import design_busbar

    b = design_busbar(1000, material="Cu_C11000", length_m=1.0)
    assert b.cross_section_mm2 > 50
    assert b.voltage_drop_mV > 0
    assert b.iacs_pct == 100


def test_busbar_design_aluminum_lower_iacs() -> None:
    from austenite.busbar_designer import design_busbar

    b = design_busbar(1000, material="Al_1350")
    assert b.iacs_pct == 61


def test_busbar_resistivity_T_dep() -> None:
    from austenite.busbar_designer import resistivity_at_T

    r20 = resistivity_at_T("Cu_C11000", 20.0)
    r100 = resistivity_at_T("Cu_C11000", 100.0)
    assert r100 > r20


# ---------------------------------------------------------------------------
# 11E. PHASE-FIELD GRAIN GROWTH
# ---------------------------------------------------------------------------


def test_phase_field_grain_growth_reduces_count() -> None:
    from austenite.phase_field_grain import simulate_grain_growth

    r = simulate_grain_growth(grid_size=8, n_grains_initial=8, time_steps=5, seed=0)
    # Grain count cannot grow
    assert r.n_grains_final <= r.n_grains_initial
    assert r.mean_grain_diameter_lattice_units > 0


def test_phase_field_grain_growth_returns_grid() -> None:
    from austenite.phase_field_grain import simulate_grain_growth

    r = simulate_grain_growth(grid_size=4, n_grains_initial=3, time_steps=2, seed=1)
    assert r.grid_size == 4
    assert len(r.eta_field_final) == 4
    assert len(r.eta_field_final[0]) == 4
