"""Tests for the 8 newly bundled extended-data JSON files.

Checks: file loads, has expected count, every row carries citation,
loader filters work, and the values are physically reasonable.
"""

from __future__ import annotations

import math

import pytest

import austenite as au


# ---------------------------------------------------------------------------
# 1. THERMOPHYSICAL T-DEPENDENT
# ---------------------------------------------------------------------------


def test_thermophysical_T_loads_and_has_alloys() -> None:
    rows = au.data.thermophysical_T_dependent()
    try:
        n = len(rows)
    except TypeError:
        n = rows.shape[0]
    assert n >= 100, f"expected ≥100 alloys, got {n}"


def test_thermophysical_T_first_entry_has_T_dependent_props() -> None:
    rows = au.data.thermophysical_T_dependent()
    first = rows.iloc[0].to_dict() if hasattr(rows, "iloc") else rows[0]
    assert "T_dependent_properties" in first
    assert "citation" in first
    tdp = first["T_dependent_properties"]
    # Stored as list of dicts: [{T_K: ..., E_GPa: ..., ...}, ...]
    assert isinstance(tdp, list) and len(tdp) >= 1
    assert "T_K" in tdp[0]


def test_thermophysical_T_filter_by_alloy() -> None:
    rows_all = au.data.thermophysical_T_dependent()
    rows_in718 = au.data.thermophysical_T_dependent(alloy="IN718")
    n_all = len(rows_all) if not hasattr(rows_all, "shape") else rows_all.shape[0]
    n_in = len(rows_in718) if not hasattr(rows_in718, "shape") else rows_in718.shape[0]
    assert n_in < n_all
    assert n_in >= 1


# ---------------------------------------------------------------------------
# 2. DIFFUSION COEFFICIENTS EXTENDED
# ---------------------------------------------------------------------------


def test_diffusion_extended_loads() -> None:
    rows = au.data.diffusion_coefficients_extended()
    n = len(rows) if not hasattr(rows, "shape") else rows.shape[0]
    assert n >= 50


def test_diffusion_extended_filter_solute() -> None:
    rows = au.data.diffusion_coefficients_extended(solute="C")
    n = len(rows) if not hasattr(rows, "shape") else rows.shape[0]
    assert n >= 1


def test_diffusion_extended_physical_ranges() -> None:
    rows = au.data.diffusion_coefficients_extended()
    seq = rows.to_dict("records") if hasattr(rows, "to_dict") else rows
    for r in seq:
        # D_0 between 1e-10 and 1 m²/s for solid-state diffusion
        assert 1e-10 <= r["D_0_m2_s"] <= 1.0
        # Activation energy between 10 (H in α-Fe) and 700 kJ/mol
        assert 10 <= r["Q_kJ_mol"] <= 700


# ---------------------------------------------------------------------------
# 3. SURFACE TENSION T-DEPENDENT
# ---------------------------------------------------------------------------


def test_surface_tension_loads_16_elements() -> None:
    rows = au.data.surface_tension_T_dependent()
    n = len(rows) if not hasattr(rows, "shape") else rows.shape[0]
    assert n == 16


def test_surface_tension_fe_high_value() -> None:
    rows = au.data.surface_tension_T_dependent(element="Fe")
    seq = rows.to_dict("records") if hasattr(rows, "to_dict") else rows
    first = seq[0]
    tdep = first["T_dependent"]
    # Iron σ at melting ~1865 mN/m. Stored as list of dicts {T_K, sigma_mN_m}
    sigmas = [pt["sigma_mN_m"] for pt in tdep]
    assert any(1500 <= s <= 2000 for s in sigmas)


# ---------------------------------------------------------------------------
# 4. VISCOSITY T-DEPENDENT
# ---------------------------------------------------------------------------


def test_viscosity_loads_15_elements() -> None:
    rows = au.data.viscosity_T_dependent()
    n = len(rows) if not hasattr(rows, "shape") else rows.shape[0]
    assert n == 15


def test_viscosity_andrade_fe() -> None:
    rows = au.data.viscosity_T_dependent(element="Fe")
    seq = rows.to_dict("records") if hasattr(rows, "to_dict") else rows
    first = seq[0]
    # Andrade: η(T) = A·exp(B/T). Sanity-check shape, not absolute magnitude
    # (Andrade fits vary widely across literature; only check positive + monotone).
    assert first["A_mPa_s"] > 0
    assert first["B_K"] > 0
    eta_low = first["A_mPa_s"] * math.exp(first["B_K"] / 5000.0)
    eta_high = first["A_mPa_s"] * math.exp(first["B_K"] / 1500.0)
    assert eta_high > eta_low  # viscosity decreases with T


# ---------------------------------------------------------------------------
# 5. HEAT TREAT SCHEDULES
# ---------------------------------------------------------------------------


def test_heat_treat_loads_schedules() -> None:
    rows = au.data.heat_treat_schedules()
    n = len(rows) if not hasattr(rows, "shape") else rows.shape[0]
    assert n >= 30


def test_heat_treat_filter_in718() -> None:
    rows = au.data.heat_treat_schedules(alloy="IN718")
    n = len(rows) if not hasattr(rows, "shape") else rows.shape[0]
    assert n >= 1


def test_heat_treat_every_row_has_citation() -> None:
    rows = au.data.heat_treat_schedules()
    seq = rows.to_dict("records") if hasattr(rows, "to_dict") else rows
    for r in seq:
        cit = r.get("citation", "")
        assert cit and len(cit) > 5


# ---------------------------------------------------------------------------
# 6. MAGNETIC PROPERTIES
# ---------------------------------------------------------------------------


def test_magnetic_loads() -> None:
    rows = au.data.magnetic_properties()
    n = len(rows) if not hasattr(rows, "shape") else rows.shape[0]
    assert n >= 20


def test_magnetic_pure_iron_curie() -> None:
    rows = au.data.magnetic_properties(material="Pure Fe")
    seq = rows.to_dict("records") if hasattr(rows, "to_dict") else rows
    # Pure Fe Curie point ~1043 K
    has_iron = any(990 <= r.get("T_c_K", 0) <= 1080 for r in seq)
    assert has_iron


# ---------------------------------------------------------------------------
# 7. OXIDATION KINETICS
# ---------------------------------------------------------------------------


def test_oxidation_loads() -> None:
    rows = au.data.oxidation_kinetics()
    n = len(rows) if not hasattr(rows, "shape") else rows.shape[0]
    assert n >= 25


def test_oxidation_filter_alloy() -> None:
    rows = au.data.oxidation_kinetics(alloy="Ni")
    n = len(rows) if not hasattr(rows, "shape") else rows.shape[0]
    assert n >= 1


# ---------------------------------------------------------------------------
# 8. PHASE-DIAGRAM CRITICAL POINTS
# ---------------------------------------------------------------------------


def test_phase_diagram_loads() -> None:
    rows = au.data.phase_diagram_critical_points()
    n = len(rows) if not hasattr(rows, "shape") else rows.shape[0]
    assert n >= 40


def test_phase_diagram_fe_c_eutectoid() -> None:
    """Fe-C eutectoid is at 0.76 wt% C, 727°C (classic from Callister)."""

    rows = au.data.phase_diagram_critical_points(system="Fe-C")
    seq = rows.to_dict("records") if hasattr(rows, "to_dict") else rows
    eutectoid = [r for r in seq if r.get("type") == "eutectoid"]
    assert eutectoid, "Fe-C eutectoid not found"
    e = eutectoid[0]
    # composition_pct stored as a string like "0.76 C" — parse the number out
    comp_str = str(e["composition_pct"])
    comp_val = float(comp_str.split()[0])
    assert 0.5 <= comp_val <= 1.0
    assert 700 <= e["T_C"] <= 760


# ---------------------------------------------------------------------------
# 9. ALL HAVE CITATIONS
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("fn_name", [
    "thermophysical_T_dependent",
    "diffusion_coefficients_extended",
    "surface_tension_T_dependent",
    "viscosity_T_dependent",
    "heat_treat_schedules",
    "magnetic_properties",
    "oxidation_kinetics",
    "phase_diagram_critical_points",
])
def test_every_extended_dataset_has_citations(fn_name: str) -> None:
    rows = getattr(au.data, fn_name)()
    seq = rows.to_dict("records") if hasattr(rows, "to_dict") else rows
    n_total = len(seq)
    n_with_cit = sum(1 for r in seq if r.get("citation"))
    # At least 95 % must carry a citation string
    assert n_with_cit >= 0.95 * n_total, (
        f"{fn_name}: only {n_with_cit}/{n_total} entries carry a citation"
    )
