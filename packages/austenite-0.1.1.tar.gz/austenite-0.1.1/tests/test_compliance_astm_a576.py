"""Tests for the ASTM A576 (carbon-steel hot-wrought bar) checker."""

from __future__ import annotations

import pytest

import austenite as au
from austenite.compliance_standards import StandardVerdict, astm_a576


def test_astm_a576_pass_1045_default() -> None:
    v = astm_a576.check(
        composition={"C": 0.46, "Mn": 0.75, "P": 0.025, "S": 0.030},
        mechanical={"sigma_y_MPa": 460, "sigma_uts_MPa": 600,
                    "elongation_pct": 17, "hardness_HB": 180},
    )
    assert isinstance(v, StandardVerdict)
    assert v.passed is True
    assert v.spec_id == "ASTM A576"
    assert "1045" in v.citation


def test_astm_a576_pass_1018_grade() -> None:
    v = astm_a576.check(
        composition={"C": 0.18, "Mn": 0.75, "P": 0.025, "S": 0.030},
        mechanical={"sigma_y_MPa": 320, "sigma_uts_MPa": 450,
                    "elongation_pct": 27, "hardness_HB": 140},
        grade="1018",
    )
    assert v.passed is True


def test_astm_a576_fail_carbon_outside_grade_window_1018() -> None:
    """1018 chemistry mandates C 0.15–0.20 — a 0.50 carbon should fail."""

    v = astm_a576.check(composition={"C": 0.50, "Mn": 0.75}, grade="1018")
    assert v.passed is False
    assert any("C =" in f and "exceeds max 0.2" in f for f in v.failed_items)


def test_astm_a576_fail_1095_hardness_too_high() -> None:
    v = astm_a576.check(
        composition={"C": 0.95, "Mn": 0.40, "P": 0.025, "S": 0.030},
        mechanical={"sigma_y_MPa": 600, "sigma_uts_MPa": 1000,
                    "elongation_pct": 10, "hardness_HB": 300},  # above 269 max
        grade="1095",
    )
    assert v.passed is False
    assert any("hardness_HB" in f and "exceeds max 269" in f for f in v.failed_items)


def test_astm_a576_list_grades() -> None:
    assert set(astm_a576.list_grades()) == {"1018", "1045", "1095"}
