"""Tests for the MTC endpoints."""

from __future__ import annotations

import base64
from pathlib import Path

import pytest

import austenite as au


PARSE_URL = "https://api-test.austenite.org/v1/mtc/parse"
DETECT_URL = "https://api-test.austenite.org/v1/mtc/detect-grade"


def test_parse_happy_path_text(httpx_mock) -> None:
    httpx_mock.add_response(
        url=PARSE_URL,
        method="POST",
        json={
            "heat_number": "H12345",
            "grade": "AISI 4140",
            "composition": {"Fe": 0.97, "C": 0.004, "Cr": 0.01},
            "mechanical": {"sigma_y_MPa": 1535},
            "confidence": 0.94,
        },
    )
    r = au.mtc.parse(text="some MTC text")
    assert r.heat_number == "H12345"
    assert r.grade == "AISI 4140"
    assert r.composition["Cr"] == pytest.approx(0.01)
    assert r.confidence == pytest.approx(0.94)


def test_parse_uploads_bytes_as_base64(httpx_mock, tmp_path: Path) -> None:
    pdf_bytes = b"%PDF-1.4 fake pdf bytes"
    f = tmp_path / "cert.pdf"
    f.write_bytes(pdf_bytes)

    httpx_mock.add_response(url=PARSE_URL, method="POST", json={"composition": {}})

    au.mtc.parse(f)
    body = httpx_mock.get_requests()[-1].read().decode("utf-8")
    assert base64.b64encode(pdf_bytes).decode("ascii") in body


def test_parse_uploads_raw_bytes(httpx_mock) -> None:
    pdf_bytes = b"%PDF-1.4 raw bytes test"
    httpx_mock.add_response(url=PARSE_URL, method="POST", json={"composition": {}})
    au.mtc.parse(pdf_bytes)
    body = httpx_mock.get_requests()[-1].read().decode("utf-8")
    assert base64.b64encode(pdf_bytes).decode("ascii") in body


def test_detect_grade_happy_path(httpx_mock) -> None:
    httpx_mock.add_response(
        url=DETECT_URL,
        method="POST",
        json={
            "candidates": [
                {"grade": "AISI 304L", "score": 0.92},
                {"grade": "AISI 316L", "score": 0.31},
            ],
            "best": "AISI 304L",
            "confidence": 0.92,
        },
    )
    r = au.mtc.detect_grade({"Fe": 0.7, "Cr": 0.18, "Ni": 0.08})
    assert r.best == "AISI 304L"
    assert r.confidence == pytest.approx(0.92)
    assert len(r.candidates) == 2


def test_detect_grade_400(httpx_mock) -> None:
    httpx_mock.add_response(
        url=DETECT_URL,
        method="POST",
        status_code=400,
        json={"error": "composition required"},
    )
    with pytest.raises(au.ValidationError):
        au.mtc.detect_grade({})
