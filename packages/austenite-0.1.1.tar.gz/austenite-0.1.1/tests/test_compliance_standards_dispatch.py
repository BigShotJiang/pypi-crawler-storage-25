"""Integration tests for au.compliance.check_standard + list_standards.

Covers:
  * 15 specs visible (10 envelope checkers + 5 edition-tracked)
  * Edition-corpus stub path
  * Envelope-checker path
  * Unknown-spec returns ``None`` (plugin fallback with no plugin)
  * StandardVerdict back-compat (``.passes`` alias, ``.to_dict()`` shape)
  * Every bundled JSON file loads + parses
"""

from __future__ import annotations

import json
from importlib import resources

import pytest

import austenite as au
from austenite.compliance_standards import StandardVerdict, _STANDARD_MODULES


_EXPECTED_STANDARDS = {
    # New envelope checkers
    "AMS 6418",
    "AMS 6517",
    "ASTM A574",
    "ASTM A576",
    "DNV-OS-F101",
    "GB/T 711",
    "IMO PSPC (MSC.215(82))",
    "JIS G3106",
    "KS B 0801",
    "MIL-S-46100",
    # Edition-tracked (existing)
    "API 579-1",
    "API 581",
    "ASME II-D",
    "ASTM A29",
    "NACE MR0175",
}


def test_list_standards_contains_all_15_specs() -> None:
    listed = set(au.compliance.list_standards())
    missing = _EXPECTED_STANDARDS - listed
    assert not missing, f"missing standards in list: {missing}"


def test_check_standard_envelope_route_returns_StandardVerdict() -> None:
    v = au.compliance.check_standard(
        "DNV-OS-F101",
        composition={"C": 0.10, "Mn": 1.30, "P": 0.010, "S": 0.003},
    )
    assert isinstance(v, StandardVerdict)
    assert v.spec_id == "DNV-OS-F101"


def test_check_standard_edition_corpus_route_returns_stub() -> None:
    v = au.compliance.check_standard("ASME II-D")
    assert isinstance(v, dict)
    assert v["spec"] == "ASME II-D"
    assert isinstance(v["editions"], list) and len(v["editions"]) >= 1
    assert "bayesian_p_pass" in v["note"]


def test_check_standard_unknown_spec_returns_None() -> None:
    """No envelope checker, not in edition corpus, no plugin → None."""

    assert au.compliance.check_standard("totally-made-up-spec-12345") is None


def test_StandardVerdict_passes_alias_and_to_dict() -> None:
    v = au.compliance.check_standard(
        "DNV-OS-F101",
        composition={"C": 0.10, "Mn": 1.30, "P": 0.010, "S": 0.003},
    )
    assert isinstance(v, StandardVerdict)
    assert v.passes is True          # back-compat alias
    d = v.to_dict()
    assert d["passed"] is True
    assert d["passes"] is True
    assert d["spec_id"] == "DNV-OS-F101"
    assert isinstance(d["failed_items"], list)
    assert isinstance(d["notes"], list)


def test_all_10_envelope_data_files_load() -> None:
    """Every JSON limits file in _data/ must parse and have the right shape."""

    pkg = resources.files("austenite.compliance_standards._data")
    for canonical, modname in _STANDARD_MODULES.items():
        filename = f"{modname}.json"
        text = (pkg / filename).read_text(encoding="utf-8")
        data = json.loads(text)
        assert data["id"] == canonical, (
            f"{filename}: id={data['id']!r} doesn't match canonical {canonical!r}"
        )
        # Must have one of: top-level limits OR per-grade map OR size_classes
        has_limits = bool((data.get("limits") or {}).get("composition_wt_pct")
                          or (data.get("limits") or {}).get("mechanical"))
        has_grades = bool(data.get("grades"))
        has_sizes = bool(data.get("size_classes"))
        assert has_limits or has_grades or has_sizes, (
            f"{filename}: must have one of limits / grades / size_classes"
        )
        # Citation should be non-empty
        assert data.get("citation") or data.get("primary_paper"), (
            f"{filename}: must have citation or primary_paper"
        )


def test_check_standard_alias_resolution() -> None:
    """Loose aliases should resolve to canonical envelope-checker ids."""

    cases = {
        "dnv": "DNV-OS-F101",
        "pspc": "IMO PSPC (MSC.215(82))",
        "sm490": "JIS G3106",
        "q345": "GB/T 711",
        "ks0801": "KS B 0801",
        "ams6517": "AMS 6517",
        "ams6418": "AMS 6418",
        "mils46100": "MIL-S-46100",
        "a576": "ASTM A576",
        "a574": "ASTM A574",
    }
    for alias, canonical in cases.items():
        try:
            v = au.compliance.check_standard(alias)
        except ValueError as e:
            pytest.fail(f"alias '{alias}' failed to resolve: {e}")
        # IMO PSPC / KS B 0801 may pass even with no input (no mandatory checks
        # fail when nothing supplied) — just verify the spec_id route is right.
        if isinstance(v, StandardVerdict):
            assert v.spec_id == canonical, (
                f"alias '{alias}' resolved to {v.spec_id!r}, expected {canonical!r}"
            )
        else:
            pytest.fail(f"alias '{alias}' did not route to envelope checker")
