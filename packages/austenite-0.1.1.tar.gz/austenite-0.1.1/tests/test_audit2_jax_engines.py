"""Numerical-accuracy audit of the JAX-differentiable physics engines.

Audit scope (audit #2):
    * ``austenite.jax_backend._fad``      — differentiable Level 2A FAD
    * ``austenite.jax_backend._meltpool`` — differentiable Rosenthal /
      Eagar-Tsai / Goldak melt-pool models

Goal: confirm each JAX engine AGREES with its analytic / literature
counterpart and that ``jax.grad`` returns finite gradients.

These tests do NOT modify the source. The previously-documented defects
(edge/surface-flaw K_I missing the √π factor; Goldak peak T saturating a
hard 5000 K clamp) have been FIXED in source, so the corresponding tests
now assert the correct physics directly.

float64 is enabled at import time so every comparison is deterministic.
"""

from __future__ import annotations

import math

import pytest


jax = pytest.importorskip("jax")
jax.config.update("jax_enable_x64", True)  # MUST be set before tracing
jnp = pytest.importorskip("jax.numpy")


# Reference analytic helpers (plain Python, no JAX) -------------------------


def _kr_curve_ref(Lr: float) -> float:
    """Level 2A / Milne-Ainsworth Option-2 FAD curve, reference impl."""

    return (1.0 - 0.14 * Lr * Lr) * (0.3 + 0.7 * math.exp(-0.65 * Lr**6))


def _edge_Y_ref(alpha: float) -> float:
    """Tada-Paris-Irwin single-edge-notch polynomial (√(πa) convention)."""

    return (1.12 - 0.231 * alpha + 10.55 * alpha**2
            - 21.72 * alpha**3 + 30.39 * alpha**4)


# ===========================================================================
# FAD — Level 2A failure assessment diagram
# ===========================================================================


def test_fad_curve_equals_one_at_Lr_zero() -> None:
    """At Lr -> 0 the assessment curve Kr must be exactly 1.0."""

    from austenite.jax_backend import fad_2a_jax

    # sigma ~ 0 drives Lr ~ 0; Kr_curve_at_Lr is the curve ordinate.
    r = fad_2a_jax(a_mm=2.0, sigma=1e-7, sigma_y=400.0, sigma_uts=600.0,
                   KIc=100.0, geometry="edge-crack")
    assert abs(float(r.Lr)) < 1e-6
    assert abs(float(r.Kr_curve_at_Lr) - 1.0) < 1e-6


@pytest.mark.parametrize("Lr_target", [0.2, 0.5, 0.8, 1.0])
def test_fad_curve_matches_milne_ainsworth_formula(Lr_target: float) -> None:
    """Kr_curve_at_Lr must equal (1-0.14 Lr^2)(0.3+0.7 exp(-0.65 Lr^6)).

    The engine multiplies the raw curve by a smooth ``soft_cut`` sigmoid
    ``sigmoid(20*(Lr_max - Lr))`` (line 234) so the curve goes to zero
    differentiably past the cutoff. Well below Lr_max that factor is ~1,
    so we compare against ``raw * soft_cut`` to stay exact.
    """

    from austenite.jax_backend import fad_2a_jax

    # Choose sigma so that Lr == Lr_target (Lr = sigma / sigma_y).
    sigma_y, sigma_uts = 400.0, 600.0
    sigma = Lr_target * sigma_y
    r = fad_2a_jax(a_mm=2.0, sigma=sigma, sigma_y=sigma_y, sigma_uts=sigma_uts,
                   KIc=100.0, geometry="edge-crack")
    assert abs(float(r.Lr) - Lr_target) < 1e-6
    lr_max = (sigma_y + sigma_uts) / (2.0 * sigma_y)
    soft_cut = 1.0 / (1.0 + math.exp(-20.0 * (lr_max - Lr_target)))
    ref = _kr_curve_ref(Lr_target) * soft_cut
    assert abs(float(r.Kr_curve_at_Lr) - ref) < 1e-6


def test_fad_point_inside_curve_is_safe() -> None:
    """Small crack + low stress -> point under the curve -> distance > 0."""

    from austenite.jax_backend import fad_2a_jax

    r = fad_2a_jax(a_mm=1.0, sigma=80.0, sigma_y=380.0, sigma_uts=550.0,
                   KIc=120.0, geometry="edge-crack")
    assert float(r.Kr) < float(r.Kr_curve_at_Lr)      # genuinely interior
    assert float(r.distance_to_curve) > 0.0           # positive == safe
    assert float(r.acceptable) > 0.5


def test_fad_point_outside_curve_is_unsafe() -> None:
    """Large crack + high stress -> point above the curve -> distance < 0."""

    from austenite.jax_backend import fad_2a_jax

    r = fad_2a_jax(a_mm=40.0, sigma=350.0, sigma_y=380.0, sigma_uts=550.0,
                   KIc=30.0, geometry="edge-crack")
    assert float(r.distance_to_curve) < 0.0
    assert float(r.acceptable) < 0.5


def test_fad_Lr_max_matches_flow_stress_definition() -> None:
    """Lr_max == (sigma_y + sigma_uts) / (2 sigma_y)."""

    from austenite.jax_backend import fad_2a_jax

    r = fad_2a_jax(a_mm=5.0, sigma=200.0, sigma_y=400.0, sigma_uts=600.0,
                   KIc=80.0, geometry="edge-crack")
    assert abs(float(r.Lr_max) - (400.0 + 600.0) / (2.0 * 400.0)) < 1e-9


def test_fad_center_crack_KI_matches_westergaard() -> None:
    """Centre crack: K_I must equal sigma * sqrt(pi a) (Westergaard)."""

    from austenite.jax_backend import fad_2a_jax

    a_mm, sigma = 5.0, 200.0
    a_m = a_mm * 1e-3
    r = fad_2a_jax(a_mm=a_mm, sigma=sigma, sigma_y=380.0, sigma_uts=550.0,
                   KIc=80.0, geometry="center-crack", W_mm=50.0)
    k_ref = sigma * math.sqrt(math.pi * a_m)
    rel = abs(float(r.K_I_MPa_sqm) - k_ref) / k_ref
    assert rel < 1e-6, f"center-crack K_I rel err {rel:.2%}"


def test_fad_through_wall_KI_matches_feddersen_secant() -> None:
    """Through-wall: K_I == sigma sqrt(pi a) sqrt(sec(pi a/2W))."""

    from austenite.jax_backend import fad_2a_jax

    a_mm, W, sigma = 5.0, 50.0, 200.0
    a_m = a_mm * 1e-3
    sec = 1.0 / math.cos(math.pi * (a_mm / W) / 2.0)
    k_ref = sigma * math.sqrt(math.pi * a_m) * math.sqrt(sec)
    r = fad_2a_jax(a_mm=a_mm, sigma=sigma, sigma_y=380.0, sigma_uts=550.0,
                   KIc=80.0, geometry="through-wall", W_mm=W)
    rel = abs(float(r.K_I_MPa_sqm) - k_ref) / k_ref
    assert rel < 1e-6, f"through-wall K_I rel err {rel:.2%}"


def test_fad_edge_crack_KI_includes_sqrt_pi() -> None:
    """Edge-crack K_I now pre-bakes the sqrt(pi) factor (fixed).

    _fad.py ``_edge`` folds √π into the Tada/Anderson single-edge-notch
    Y-polynomial, so ``K_I = Y·σ·√a`` is consistent with the
    K = Y·σ·√(π a) convention. The engine therefore predicts the
    physically correct (conservative) K_I.

    Correct edge-crack K_I (a=5mm, sigma=200, W=50) ≈ 29.67 MPa.sqrt(m)
    (≈28 MPa.sqrt(m) order-of-magnitude); the old buggy value was the
    1.772× (=√π) smaller 16.74 MPa.sqrt(m).
    """

    from austenite.jax_backend import fad_2a_jax

    a_mm, W, sigma = 5.0, 50.0, 200.0
    a_m = a_mm * 1e-3
    Y = math.sqrt(math.pi) * _edge_Y_ref(a_mm / W)   # √π pre-baked
    k_correct = Y * sigma * math.sqrt(a_m)           # = Y_poly·σ·√(πa)
    k_buggy = _edge_Y_ref(a_mm / W) * sigma * math.sqrt(a_m)  # old, no √π
    got = float(fad_2a_jax(a_mm=a_mm, sigma=sigma, sigma_y=380.0,
                           sigma_uts=550.0, KIc=80.0,
                           geometry="edge-crack", W_mm=W).K_I_MPa_sqm)
    # Engine now matches the correct (√π) form within 2 %.
    assert abs(got - k_correct) / k_correct < 0.02, (
        f"edge K_I {got:.4g} vs correct {k_correct:.4g}")
    # ...and is sqrt(pi) ABOVE the old buggy value (no longer non-conservative).
    assert abs(got / k_buggy - math.sqrt(math.pi)) < 1e-6


def test_fad_surface_flaw_KI_includes_sqrt_pi() -> None:
    """Surface-flaw K_I now pre-bakes the sqrt(pi) factor (fixed).

    ``_surf`` returns Y = √π·M/√Q (= √π·1.094/√1.376); with the
    K = Y·σ·√a line that yields the Newman-Raju deepest-point SIF
    M·σ·√(π a / Q). Correct value ≈ 23.38 MPa.sqrt(m) (the old buggy
    value was the √π-smaller 13.19 MPa.sqrt(m)).
    """

    from austenite.jax_backend import fad_2a_jax

    a_mm, sigma = 5.0, 200.0
    a_m = a_mm * 1e-3
    M, Q = 1.094, 1.376
    k_correct = M * sigma * math.sqrt(math.pi * a_m / Q)   # Newman-Raju
    k_buggy = M / math.sqrt(Q) * sigma * math.sqrt(a_m)    # old, no √π
    got = float(fad_2a_jax(a_mm=a_mm, sigma=sigma, sigma_y=380.0,
                           sigma_uts=550.0, KIc=80.0,
                           geometry="surface-flaw", W_mm=50.0).K_I_MPa_sqm)
    assert abs(got - k_correct) / k_correct < 0.02, (
        f"surface K_I {got:.4g} vs correct {k_correct:.4g}")
    assert abs(got / k_buggy - math.sqrt(math.pi)) < 1e-6


def test_fad_grad_is_finite_and_correctly_signed() -> None:
    """jax.grad of the scalar margin is finite; bigger crack / higher
    stress both reduce the margin (negative gradient)."""

    from austenite.jax_backend import fad_2a_jax

    def margin(a, s):
        return fad_2a_jax(a_mm=a, sigma=s, sigma_y=380.0, sigma_uts=550.0,
                          KIc=80.0, geometry="edge-crack").distance_to_curve

    g_a, g_s = jax.grad(margin, argnums=(0, 1))(jnp.float64(5.0),
                                                jnp.float64(200.0))
    assert math.isfinite(float(g_a)) and math.isfinite(float(g_s))
    assert float(g_a) < 0.0
    assert float(g_s) < 0.0


def test_fad_grad_matches_finite_difference() -> None:
    """Autodiff d(margin)/da agrees with central FD within 2 %."""

    from austenite.jax_backend import fad_2a_jax

    def margin(a):
        return fad_2a_jax(a_mm=a, sigma=jnp.float64(200.0), sigma_y=380.0,
                          sigma_uts=550.0, KIc=80.0,
                          geometry="edge-crack").distance_to_curve

    a0 = jnp.float64(5.0)
    g_ad = float(jax.grad(margin)(a0))
    eps = 1e-3
    fd = (float(margin(a0 + eps)) - float(margin(a0 - eps))) / (2 * eps)
    rel = abs(fd - g_ad) / max(abs(fd), 1e-9)
    assert rel < 0.02, f"FD={fd:.6g} AD={g_ad:.6g} rel={rel:.2%}"


# ===========================================================================
# Melt-pool — Rosenthal / Eagar-Tsai / Goldak
# ===========================================================================


def test_rosenthal_length_matches_cline_anthony_closed_form() -> None:
    """Rosenthal L equals the Cline-Anthony length scale to <1e-9 rel."""

    from austenite.jax_backend import meltpool_rosenthal_jax, in718_props

    p = in718_props()
    eta, k, Tl, T0 = 0.30, 26.0, 1623.0, 353.0
    L_ref = eta * 285.0 / (2.0 * math.pi * k * (Tl - T0)) * 1e3
    got = float(meltpool_rosenthal_jax(285.0, 960.0, p).L_mm)
    rel = abs(got - L_ref) / L_ref
    assert rel < 1e-6, f"Rosenthal L rel err {rel:.2%} (got {got}, ref {L_ref})"


def test_rosenthal_length_scales_linearly_with_power() -> None:
    """L is proportional to laser power P (doubling P doubles L)."""

    from austenite.jax_backend import meltpool_rosenthal_jax, in718_props

    p = in718_props()
    l1 = float(meltpool_rosenthal_jax(285.0, 960.0, p).L_mm)
    l2 = float(meltpool_rosenthal_jax(570.0, 960.0, p).L_mm)
    assert abs(l2 / l1 - 2.0) < 1e-6


def test_rosenthal_pool_grows_with_power_shrinks_with_speed() -> None:
    """Peak T and pool size rise with P; cooling rate rises with v.

    In the Cline-Anthony length scale L is independent of v, so the
    'shrinks with speed' physics shows up in the cooling rate (which is
    proportional to v) — verify both the up-with-P and up-with-v trends.
    """

    from austenite.jax_backend import meltpool_rosenthal_jax, in718_props

    p = in718_props()
    # Up with power
    assert (float(meltpool_rosenthal_jax(300.0, 960.0, p).T_peak_K)
            > float(meltpool_rosenthal_jax(100.0, 960.0, p).T_peak_K))
    assert (float(meltpool_rosenthal_jax(300.0, 960.0, p).L_mm)
            > float(meltpool_rosenthal_jax(100.0, 960.0, p).L_mm))
    # Cooling rate up with speed
    c_slow = float(meltpool_rosenthal_jax(285.0, 480.0, p).cooling_rate_K_s)
    c_fast = float(meltpool_rosenthal_jax(285.0, 960.0, p).cooling_rate_K_s)
    assert c_fast > c_slow
    assert abs(c_fast / c_slow - 2.0) < 1e-6


def test_rosenthal_cooling_rate_matches_formula() -> None:
    """Cooling = 2 pi k v (Tl-T0)^2 / (eta P) within 1e-9 rel."""

    from austenite.jax_backend import meltpool_rosenthal_jax, in718_props

    p = in718_props()
    eta, k, Tl, T0 = 0.30, 26.0, 1623.0, 353.0
    v_ms = 960.0 * 1e-3
    ref = 2.0 * math.pi * k * v_ms * (Tl - T0) ** 2 / (eta * 285.0)
    got = float(meltpool_rosenthal_jax(285.0, 960.0, p).cooling_rate_K_s)
    assert abs(got - ref) / ref < 1e-6


def test_rosenthal_lower_conductivity_gives_larger_pool() -> None:
    """Ti-6Al-4V (low k) yields a larger Cline-Anthony L than 316L for
    matched P/v once you account for its own deltaT — here just confirm
    pool size scales inversely with k at fixed deltaT."""

    from austenite.jax_backend import meltpool_rosenthal_jax, in718_props

    p_hi_k = in718_props()                      # k = 26
    p_lo_k = in718_props(k_W_m_K=7.2)           # Ti-like k, same deltaT
    l_hi = float(meltpool_rosenthal_jax(285.0, 960.0, p_hi_k).L_mm)
    l_lo = float(meltpool_rosenthal_jax(285.0, 960.0, p_lo_k).L_mm)
    assert l_lo > l_hi
    assert abs(l_lo / l_hi - 26.0 / 7.2) < 1e-6


def test_rosenthal_grad_dL_dP_finite_and_positive() -> None:
    """jax.grad dL/dP is finite and positive (= Cline-Anthony slope)."""

    from austenite.jax_backend import meltpool_rosenthal_jax, in718_props

    p = in718_props()

    def L_of(P):
        return meltpool_rosenthal_jax(P, 960.0, p).L_mm

    g = float(jax.grad(L_of)(jnp.float64(285.0)))
    eta, k, Tl, T0 = 0.30, 26.0, 1623.0, 353.0
    slope_ref = eta / (2.0 * math.pi * k * (Tl - T0)) * 1e3  # dL/dP analytic
    assert math.isfinite(g) and g > 0
    assert abs(g - slope_ref) / slope_ref < 1e-6


def test_eagar_tsai_length_matches_blended_closed_form() -> None:
    """Eagar-Tsai L equals the engine's blended low-/high-Pe closed form.

    The engine smoothly blends the low-Pe form
    ``sqrt(eta P v/(2 pi k dT^2)) + rb`` with the high-Pe Rosenthal
    length using ``blend = sigmoid(2*(Pe-1))``. Verify the implementation
    reproduces this exact blend (rel < 1e-6) at a representative point.

    NOTE (design observation, not a bug): because ``blend`` saturates at
    ``sigmoid(-2) ~ 0.119`` as Pe -> 0, the *pure* low-Pe limit is never
    fully recovered (>=12 % of the high-Pe term always leaks in). The
    docstring claims L is "exact for low Pe"; in practice the floor blend
    keeps it ~10-15 % above the pure Eagar-Tsai value at small Pe.
    """

    from austenite.jax_backend import meltpool_eagar_tsai_jax, in718_props

    p = in718_props()
    eta, k, rho, cp, Tl, T0 = 0.30, 26.0, 8190.0, 625.0, 1623.0, 353.0
    alpha = k / (rho * cp)
    rb = 40e-6
    P, v_mm = 285.0, 50.0
    v_ms = v_mm * 1e-3
    Pe = v_ms * rb / alpha
    blend = 1.0 / (1.0 + math.exp(-2.0 * (Pe - 1.0)))
    inside = eta * P * v_ms / (2.0 * math.pi * k * (Tl - T0) ** 2)
    L_low = math.sqrt(inside) + rb
    L_high = eta * P / (2.0 * math.pi * k * (Tl - T0))
    L_ref = ((1.0 - blend) * L_low + blend * L_high) * 1e3
    got = float(meltpool_eagar_tsai_jax(P, v_mm, p, beam_radius_um=40.0).L_mm)
    assert abs(got - L_ref) / L_ref < 1e-6, f"blended L rel err"
    # Document the unreachable-pure-low-Pe floor.
    assert 0.11 < blend < 0.30


def test_eagar_tsai_length_monotonic_in_power() -> None:
    """Pool length increases with power."""

    from austenite.jax_backend import meltpool_eagar_tsai_jax, in718_props

    p = in718_props()
    powers = [100.0, 200.0, 300.0, 400.0]
    Ls = [float(meltpool_eagar_tsai_jax(P, 960.0, p).L_mm) for P in powers]
    assert all(b > a for a, b in zip(Ls, Ls[1:]))


def test_eagar_tsai_grad_dL_dP_matches_finite_difference() -> None:
    """Autodiff dL/dP matches central FD within 1 %."""

    from austenite.jax_backend import meltpool_eagar_tsai_jax, in718_props

    p = in718_props()

    def L_of(P):
        return meltpool_eagar_tsai_jax(P, 960.0, p).L_mm

    g_ad = float(jax.grad(L_of)(jnp.float64(285.0)))
    eps = 1.0
    fd = (float(L_of(jnp.float64(286.0))) - float(L_of(jnp.float64(284.0)))) / (2 * eps)
    assert math.isfinite(g_ad)
    assert abs(fd - g_ad) / max(abs(fd), 1e-12) < 0.01


def test_goldak_peak_T_matches_energy_per_length_formula() -> None:
    """Goldak T_peak == T0 + f_r eta P / (v rho cp pi b c) (fixed form).

    The peak temperature is now a dimensionally-correct energy-per-unit-
    length expression  ΔT = f_r·η·P / (v·ρ·cp·π·b·c)  with a SOFT
    vaporisation cap at T_vap = T_liquidus + 1500 via softplus. With low
    power + 1 mm axes the result sits far below T_vap, so the soft cap is
    inactive and the closed form matches to <1e-6 rel.
    """

    from austenite.jax_backend import meltpool_goldak_jax, in718_props

    p = in718_props()
    eta, rho, cp, T0 = 0.30, 8190.0, 625.0, 353.0
    Tl = 1623.0
    T_vap = Tl + 1500.0
    P, v = 50.0, 960.0
    a_f, a_r, b, c = 1.0, 1.0, 1.0, 1.0       # mm — large pool, low ΔT
    f_r = 2.0 * a_r / (a_f + a_r)
    v_ms = v * 1e-3
    cross_section_m2 = math.pi * (b * 1e-3) * (c * 1e-3)
    dT = (f_r * eta * P) / (v_ms * rho * cp * cross_section_m2)
    T_ref = T0 + dT
    assert T_ref < T_vap                          # soft cap inactive here
    got = float(meltpool_goldak_jax(P, v, p, a_f_mm=a_f, a_r_mm=a_r,
                                    b_mm=b, c_mm=c).T_peak_K)
    assert abs(got - T_ref) / T_ref < 1e-6


def test_goldak_default_geometry_peak_T_is_finite_and_varies_with_power() -> None:
    """With the DEFAULT ellipsoid axes the Goldak peak T no longer
    saturates a hard 5000 K clamp (fixed).

    The rewritten energy-per-length form keeps T_peak finite and below
    the soft vaporisation ceiling T_vap = T_liquidus + 1500, varying
    monotonically with power and carrying a finite, positive gradient
    w.r.t. P — so optimisers can actually move it.
    """

    from austenite.jax_backend import meltpool_goldak_jax, in718_props

    p = in718_props()
    Tl = 1623.0
    T_vap = Tl + 1500.0

    got = float(meltpool_goldak_jax(285.0, 960.0, p).T_peak_K)
    assert math.isfinite(got)
    assert abs(got - 5000.0) > 1.0                # no longer pinned at 5000
    assert got < T_vap                            # below the soft cap
    assert got > 353.0                            # above preheat

    # Varies with power: two different powers give two different peaks.
    t_lo = float(meltpool_goldak_jax(100.0, 960.0, p).T_peak_K)
    t_hi = float(meltpool_goldak_jax(300.0, 960.0, p).T_peak_K)
    assert t_hi > t_lo + 1.0

    # Gradient w.r.t. P is finite and strictly positive (clamp no longer kills it).
    g = float(jax.grad(lambda P: meltpool_goldak_jax(P, 960.0, p).T_peak_K)(
        jnp.float64(285.0)))
    assert math.isfinite(g) and g > 0.0


def test_goldak_length_is_sum_of_half_axes() -> None:
    """Goldak L == a_f + a_r, W == 2b, D == c."""

    from austenite.jax_backend import meltpool_goldak_jax, in718_props

    p = in718_props()
    r = meltpool_goldak_jax(285.0, 960.0, p, a_f_mm=0.25, a_r_mm=0.50,
                            b_mm=0.20, c_mm=0.10)
    assert abs(float(r.L_mm) - 0.75) < 1e-9
    assert abs(float(r.W_mm) - 0.40) < 1e-9
    assert abs(float(r.D_mm) - 0.10) < 1e-9


def test_goldak_grad_w_r_t_a_f_finite_and_positive() -> None:
    """jax.grad dL/da_f is finite and positive (front lobe lengthens L)."""

    from austenite.jax_backend import meltpool_goldak_jax, in718_props

    p = in718_props()

    def L_of(a_f):
        return meltpool_goldak_jax(285.0, 960.0, p, a_f_mm=a_f).L_mm

    g = float(jax.grad(L_of)(jnp.float64(0.25)))
    assert math.isfinite(g) and g > 0
