# -*- coding: utf-8 -*-
"""Agentic action execution for AI Chat plugin. (C) 2026 by Maciej Piecko

Handles file creation, console execution, package installation, and patch
application triggered by special code fences in LLM responses.
"""

import os
import re


# ---------------------------------------------------------------------------
# Agentic system prompt injected when agentic mode is enabled
# ---------------------------------------------------------------------------
AGENTIC_SYSTEM_PROMPT = """\
You can take direct actions by using special code fences. The user will see a \
button and must click it to confirm and execute each action.

Create or overwrite a file (path relative to project root, or absolute):
```file:path/to/file.py
# file content here
```

Run Python code in the IPython console:
```run:python
print("hello world")
```

Install a Python package:
```install:pip
numpy pandas
```

Apply a unified diff patch to an existing file:
```patch:path/to/file.py
--- a/path/to/file.py
+++ b/path/to/file.py
@@ -1,3 +1,3 @@
 context line
-old line
+new line
```

Use these action fences only when the user explicitly asks you to create or \
modify files, run code, or install packages. Always explain what you are doing \
before the action fence."""


# ---------------------------------------------------------------------------
# Execution helpers
# ---------------------------------------------------------------------------

def execute_create_file(path, content, base_dir=None):
    """Create or overwrite a file. Returns the absolute path written."""
    if base_dir and not os.path.isabs(path):
        path = os.path.join(base_dir, path)
    path = os.path.normpath(os.path.abspath(path))
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as f:
        f.write(content)
    return path


def execute_patch_file(path, diff_text, base_dir=None):
    """Apply a unified diff to a file. Returns the absolute path written."""
    if base_dir and not os.path.isabs(path):
        path = os.path.join(base_dir, path)
    path = os.path.normpath(os.path.abspath(path))
    try:
        with open(path, "r", encoding="utf-8") as f:
            original = f.read()
    except FileNotFoundError:
        original = ""
    result = _apply_unified_diff(original, diff_text)
    with open(path, "w", encoding="utf-8", newline="") as f:
        f.write(result)
    return path


def _apply_unified_diff(original_text, diff_text):
    """Apply a unified diff string to original_text. Returns new text."""
    orig_lines = original_text.splitlines()
    result = list(orig_lines)
    offset = 0
    i = 0
    diff_lines = diff_text.splitlines()

    while i < len(diff_lines):
        line = diff_lines[i]
        if not line.startswith("@@"):
            i += 1
            continue

        m = re.match(r"@@\s+-(\d+)(?:,(\d+))?\s+\+(\d+)(?:,(\d+))?\s+@@", line)
        if not m:
            i += 1
            continue

        old_start = max(0, int(m.group(1)) - 1)
        old_count = int(m.group(2)) if m.group(2) is not None else 1
        i += 1

        # Collect hunk lines, stop at next hunk or end
        hunk_old = []   # lines as they were (context + removed)
        hunk_new = []   # lines as they should be (context + added)
        while i < len(diff_lines):
            hl = diff_lines[i]
            if hl.startswith("@@"):
                break
            if hl.startswith("---") or hl.startswith("+++"):
                i += 1
                continue
            if hl.startswith("-"):
                hunk_old.append(hl[1:])
            elif hl.startswith("+"):
                hunk_new.append(hl[1:])
            elif hl.startswith(" "):
                hunk_old.append(hl[1:])
                hunk_new.append(hl[1:])
            elif hl == "":
                # Blank line within hunk counts as context
                hunk_old.append("")
                hunk_new.append("")
            i += 1

        pos = old_start + offset
        # Clamp position to valid range
        pos = max(0, min(pos, len(result)))
        end = min(pos + len(hunk_old), len(result))
        result[pos:end] = hunk_new
        offset += len(hunk_new) - len(hunk_old)

    return "\n".join(result)


# ---------------------------------------------------------------------------
# Qt confirm dialog  (imported lazily to avoid Qt import at module load)
# ---------------------------------------------------------------------------

def show_confirm_dialog(parent, action_type, target, content, base_dir=None):
    """
    Show a modal confirmation dialog for one agentic action.

    Returns:
        (confirmed: bool, final_path: str)  — final_path may differ from
        target if the user edited it in the dialog (file/patch actions).
    """
    from qtpy.QtWidgets import (
        QDialog, QVBoxLayout, QHBoxLayout, QLabel,
        QPlainTextEdit, QLineEdit, QDialogButtonBox, QPushButton,
        QFrame, QSizePolicy,
    )
    from qtpy.QtCore import Qt
    from qtpy.QtGui import QFont as _QFont

    dlg = QDialog(parent)
    dlg.setWindowTitle("Confirm Agentic Action")
    dlg.setMinimumWidth(560)
    dlg.setMinimumHeight(320)

    lay = QVBoxLayout(dlg)
    lay.setSpacing(8)
    lay.setContentsMargins(14, 14, 14, 14)

    # ── Header ──────────────────────────────────────────────────────────
    _ICONS = {"file": "📄", "patch": "🩹", "run": "▶", "install": "📦"}
    _LABELS = {
        "file":    "Create / Overwrite File",
        "patch":   "Apply Patch",
        "run":     "Run in IPython Console",
        "install": "Install Package",
    }
    icon = _ICONS.get(action_type, "?")
    label = _LABELS.get(action_type, action_type)

    hdr = QLabel(f"<b>{icon} {label}</b>")
    hdr.setStyleSheet("font-size: 11pt; color: #4ec9b0;")
    lay.addWidget(hdr)

    sep = QFrame()
    sep.setFrameShape(QFrame.HLine)
    sep.setStyleSheet("color: #444; margin: 2px 0;")
    lay.addWidget(sep)

    # ── Path / target field (editable for file/patch) ───────────────────
    _path_edit = None
    if action_type in ("file", "patch"):
        path_row = QHBoxLayout()
        path_row.addWidget(QLabel("Path:"))
        _path_edit = QLineEdit(target)
        _path_edit.setPlaceholderText("Relative to project root, or absolute")
        _path_edit.setStyleSheet("font-size: 9pt;")
        path_row.addWidget(_path_edit, 1)
        lay.addLayout(path_row)
    elif action_type == "install":
        pkg_lbl = QLabel(f"<b>Package(s):</b> <code>{target or content.strip()}</code>")
        pkg_lbl.setTextFormat(Qt.RichText)
        lay.addWidget(pkg_lbl)
    elif action_type == "run":
        run_lbl = QLabel(f"<b>Language:</b> {target}")
        lay.addWidget(run_lbl)

    # ── Content preview ─────────────────────────────────────────────────
    preview = QPlainTextEdit()
    preview.setReadOnly(True)
    preview.setPlainText(content)
    preview.setMaximumHeight(200)
    preview.setFont(_QFont("Monospace", 9))
    preview.setStyleSheet(
        "QPlainTextEdit { background: #1e1e1e; color: #d4d4d4; "
        "border: 1px solid #444; border-radius: 3px; padding: 4px; }")
    preview.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
    lay.addWidget(preview)

    # ── Base-dir note ────────────────────────────────────────────────────
    if base_dir and action_type in ("file", "patch"):
        note = QLabel(f"Relative paths resolved from: <code>{base_dir}</code>")
        note.setTextFormat(Qt.RichText)
        note.setStyleSheet("color: #888; font-size: 8pt;")
        lay.addWidget(note)

    # ── Buttons ─────────────────────────────────────────────────────────
    btns = QDialogButtonBox()
    ok_btn = QPushButton(f"{icon} Execute")
    ok_btn.setDefault(True)
    ok_btn.setStyleSheet(
        "QPushButton { background: #2a4a2a; color: #80c880; "
        "border: 1px solid #4a8a4a; border-radius: 3px; padding: 4px 16px; }"
        "QPushButton:hover { background: #3a5a3a; }")
    cancel_btn = QPushButton("Cancel")
    cancel_btn.setStyleSheet(
        "QPushButton { padding: 4px 16px; }")
    btns.addButton(ok_btn, QDialogButtonBox.AcceptRole)
    btns.addButton(cancel_btn, QDialogButtonBox.RejectRole)
    btns.accepted.connect(dlg.accept)
    btns.rejected.connect(dlg.reject)
    lay.addWidget(btns)

    result = dlg.exec_()
    confirmed = result == QDialog.Accepted
    final_path = _path_edit.text().strip() if _path_edit else target
    return confirmed, final_path
