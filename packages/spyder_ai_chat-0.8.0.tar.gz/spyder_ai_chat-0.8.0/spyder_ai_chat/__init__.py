# -*- coding: utf-8 -*-
"""Spyder AI Chat Plugin (C) 2026 by Maciej Piecko"""
__version__ = "0.7.1"
