## [1.11.2] - 2026-04-23

### Features

- **sphinx**: Add JS dataset search; inherit data-class tags/tasks ([587cbc4](https://github.com/experimaestro/datamaestro/commit/587cbc42b7f4246ec70e4cc8d24f6465b42f3de0))
