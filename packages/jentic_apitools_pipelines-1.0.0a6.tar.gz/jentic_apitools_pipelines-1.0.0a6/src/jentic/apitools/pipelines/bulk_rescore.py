"""Bulk rescore operation for rescoring all OpenAPI specs in a local repository clone."""

from __future__ import annotations

import gzip
import json
import shutil
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from jentic.apitools.common.models import (
    OASJsonRequest,
    OASProcessConfiguration,
    OASRequestMeta,
    SpecSourceUrl,
)
from jentic.apitools.common.utils.logging import get_module_logger
from jentic.apitools.pipelines.pipelines import import_openapi
from jentic.apitools.pipelines.repo_tools import (
    _parse_github_repo,
    rebuild_scores_json,
)


logger = get_module_logger(__name__)


@dataclass
class BulkRescoreConfig:
    """Configuration for a bulk rescore operation."""

    local_repo_path: Path
    github_repo_url: str = "https://github.com/jentic/jentic-public-apis"
    output_dir: Path | None = None
    github_repo_branch: str = "main"
    base_dir: str = "apis/openapi"
    max_iterations: int | None = None
    dry_run: bool = False


@dataclass
class BulkRescoreItemResult:
    """Result for a single API rescore."""

    vendor: str
    api_name: str
    version: str
    success: bool
    error_message: str | None = None
    output_version_dir: str | None = None


@dataclass
class BulkRescoreResult:
    """Overall result for the bulk rescore operation."""

    total: int
    succeeded: int
    failed: int
    items: list[BulkRescoreItemResult] = field(default_factory=list)
    output_dir: Path = field(default_factory=lambda: Path("."))
    report_path: Path | None = None


def _discover_specs(base_path: Path) -> list[tuple[str, str, str]]:
    """Discover all OpenAPI specs under a base directory.

    Expects structure: <vendor>/<api>/<version>/openapi.json

    Returns sorted list of (vendor, api_name, version) tuples.
    """
    specs = []
    for openapi_file in sorted(base_path.glob("*/*/*/openapi.json")):
        rel = openapi_file.relative_to(base_path)
        parts = rel.parts
        if len(parts) == 4:
            specs.append((parts[0], parts[1], parts[2]))
    return specs


def _read_api_id(base_path: Path, vendor: str, api_name: str) -> str | None:
    """Read api_id from <vendor>/<api>/meta.json if present."""
    meta_path = base_path / vendor / api_name / "meta.json"
    if not meta_path.is_file():
        return None
    try:
        data = json.loads(meta_path.read_text(encoding="utf-8"))
        return data.get("api_info", {}).get("id")
    except Exception:
        logger.warning("Failed to read api meta from %s", meta_path)
        return None


COMPRESS_THRESHOLD_BYTES = 50 * 1024 * 1024  # 50 MB


def _copy_diagnostics(
    src: Path,
    dst_meta_dir: Path,
    vendor: str,
    api_name: str,
    version: str,
) -> None:
    """Copy diagnostics.json, compressing with gzip if it exceeds the size threshold.

    When the file exceeds 50 MB it is written as diagnostics.json.gz and any
    existing uncompressed diagnostics.json is removed.  When it is within the
    threshold the plain file is written and any stale .gz variant is removed.
    """
    dst_plain = dst_meta_dir / "diagnostics.json"
    dst_gz = dst_meta_dir / "diagnostics.json.gz"
    src_size = src.stat().st_size

    if src_size > COMPRESS_THRESHOLD_BYTES:
        with src.open("rb") as f_src, gzip.open(dst_gz, "wb", compresslevel=6) as f_gz:
            shutil.copyfileobj(f_src, f_gz)
        if dst_plain.exists():
            dst_plain.unlink()
        compressed_size = dst_gz.stat().st_size
        logger.info(
            "Compressed diagnostics.json for %s/%s/%s (%d MB -> %d MB)",
            vendor,
            api_name,
            version,
            src_size // (1024 * 1024),
            compressed_size // (1024 * 1024),
        )
    else:
        shutil.copy2(src, dst_plain)
        if dst_gz.exists():
            dst_gz.unlink()
        logger.info(
            "Copied diagnostics.json for %s/%s/%s",
            vendor,
            api_name,
            version,
        )


def _copy_results(
    config: BulkRescoreConfig,
    items: list[BulkRescoreItemResult],
) -> None:
    """Copy rescore results back to the local repo clone."""
    base_path = config.local_repo_path / config.base_dir

    for item in items:
        if not item.success or not item.output_version_dir:
            continue

        src_version_dir = Path(item.output_version_dir)
        dst_version_dir = base_path / item.vendor / item.api_name / item.version

        # Copy scorecard.json
        src_scorecard = src_version_dir / "scorecard.json"
        if src_scorecard.is_file():
            shutil.copy2(src_scorecard, dst_version_dir / "scorecard.json")
            logger.info(
                "Copied scorecard.json for %s/%s/%s", item.vendor, item.api_name, item.version
            )

        # Copy diagnostics.json (compressed if over threshold)
        src_diagnostics = src_version_dir / "meta" / "diagnostics.json"
        dst_meta_dir = dst_version_dir / "meta"
        if src_diagnostics.is_file() and dst_meta_dir.is_dir():
            _copy_diagnostics(
                src_diagnostics, dst_meta_dir, item.vendor, item.api_name, item.version
            )

        # Merge diagnostics section into existing meta.json
        src_meta = src_version_dir / "meta" / "meta.json"
        dst_meta = dst_meta_dir / "meta.json"
        if src_meta.is_file() and dst_meta.is_file():
            try:
                existing = json.loads(dst_meta.read_text(encoding="utf-8"))
                new_meta = json.loads(src_meta.read_text(encoding="utf-8"))
                new_diagnostics = new_meta.get("meta", {}).get("diagnostics")
                if new_diagnostics is not None and "meta" in existing:
                    existing["meta"]["diagnostics"] = new_diagnostics
                    dst_meta.write_text(
                        json.dumps(existing, indent=2, ensure_ascii=False) + "\n",
                        encoding="utf-8",
                    )
                    logger.info(
                        "Updated meta.json diagnostics for %s/%s/%s",
                        item.vendor,
                        item.api_name,
                        item.version,
                    )
            except Exception:
                logger.exception(
                    "Failed to merge meta.json for %s/%s/%s",
                    item.vendor,
                    item.api_name,
                    item.version,
                )


def recalculate_scores(local_repo_path: Path, base_dir: str = "apis/openapi") -> dict[str, float]:
    """Recalculate scores.json by reading summary.score from all scorecard.json files.

    Backward-compatible wrapper around ``rebuild_scores_json``.
    """
    return rebuild_scores_json(local_repo_path, base_dir=base_dir)


def _generate_report(result: BulkRescoreResult, config: BulkRescoreConfig) -> str:
    """Generate a markdown report for the bulk rescore operation."""
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    lines = [
        "# Bulk Rescore Report",
        "",
        f"Date: {now}",
        f"Repository: {config.github_repo_url}",
        f"Branch: {config.github_repo_branch}",
        f"Dry run: {config.dry_run}",
        f"Output: {result.output_dir}",
        "",
        "## Summary",
        "",
        f"Total: {result.total}, Succeeded: {result.succeeded}, Failed: {result.failed}",
        "",
        "## Results",
        "",
        "| Vendor | API | Version | Status | Error |",
        "|--------|-----|---------|--------|-------|",
    ]
    for item in result.items:
        status = "OK" if item.success else "FAILED"
        error = item.error_message or ""
        lines.append(f"| {item.vendor} | {item.api_name} | {item.version} | {status} | {error} |")

    return "\n".join(lines) + "\n"


def bulk_rescore(config: BulkRescoreConfig) -> BulkRescoreResult:
    """Rescore all OpenAPI specs in a local repository clone.

    Iterates the directory structure at local_repo_path/base_dir, constructs
    raw GitHub URLs for each spec, and runs import_openapi for each one.
    When not in dry_run mode, copies results back to the local repo.
    """
    # Resolve output directory
    output_dir = config.output_dir
    if output_dir is None:
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        output_dir = Path(f"__data__/rescore_{timestamp}")
    output_dir.mkdir(parents=True, exist_ok=True)

    # Parse GitHub repo URL
    owner, repo_name = _parse_github_repo(config.github_repo_url)

    # Discover specs
    base_path = config.local_repo_path / config.base_dir
    specs = _discover_specs(base_path)
    if config.max_iterations is not None:
        specs = specs[: config.max_iterations]

    logger.info("Discovered %d specs to rescore", len(specs))

    # Build canonical URL bases
    raw_base = f"https://raw.githubusercontent.com/{owner}/{repo_name}/refs/heads/{config.github_repo_branch}/{config.base_dir}"
    ui_base = (
        f"https://github.com/{owner}/{repo_name}/tree/{config.github_repo_branch}/{config.base_dir}"
    )

    items: list[BulkRescoreItemResult] = []

    for i, (vendor, api_name, version) in enumerate(specs):
        label = f"{vendor}/{api_name}"
        spec_url = f"{raw_base}/{vendor}/{api_name}/{version}/openapi.json"
        api_id = _read_api_id(base_path, vendor, api_name)

        logger.info("[%d/%d] Rescoring %s/%s/%s", i + 1, len(specs), vendor, api_name, version)

        process_config = OASProcessConfiguration(
            enable_llm_analysis=True,
            bundled_spec=True,
            enable_spec_repair=False,
        )
        meta = OASRequestMeta(
            label=label,
            output_dir=str(output_dir),
            original_url=spec_url,
            api_id=api_id,
            canonical_source_url=spec_url,
            canonical_artifacts_base_url=raw_base,
            canonical_artifacts_base_url_ui=ui_base,
            oas_process_configuration=process_config,
        )
        oas_request = OASJsonRequest(
            spec=SpecSourceUrl(kind="url", url=spec_url),
            meta=meta,
        )

        try:
            result = import_openapi(oas_request, spec_url=spec_url, validate_unbundled=False)
            items.append(
                BulkRescoreItemResult(
                    vendor=vendor,
                    api_name=api_name,
                    version=version,
                    success=result.success,
                    error_message=result.error_message,
                    output_version_dir=result.version_dir,
                )
            )
        except Exception as exc:
            logger.exception("Failed to rescore %s/%s/%s", vendor, api_name, version)
            items.append(
                BulkRescoreItemResult(
                    vendor=vendor,
                    api_name=api_name,
                    version=version,
                    success=False,
                    error_message=str(exc),
                )
            )

    succeeded = sum(1 for item in items if item.success)
    failed = sum(1 for item in items if not item.success)

    bulk_result = BulkRescoreResult(
        total=len(items),
        succeeded=succeeded,
        failed=failed,
        items=items,
        output_dir=output_dir,
    )

    # Post-processing: copy results to local repo
    if not config.dry_run:
        _copy_results(config, items)
        recalculate_scores(config.local_repo_path, config.base_dir)

    # Generate report
    report_text = _generate_report(bulk_result, config)
    report_path = output_dir / "report.md"
    report_path.write_text(report_text, encoding="utf-8")
    bulk_result.report_path = report_path
    logger.info("Report written to %s", report_path)

    return bulk_result
