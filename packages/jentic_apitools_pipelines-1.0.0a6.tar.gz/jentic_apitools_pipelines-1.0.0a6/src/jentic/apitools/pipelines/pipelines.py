"""High-level helper that downloads, converts, repairs, and writes an OpenAPI spec."""

from __future__ import annotations

import time
from datetime import datetime
from pathlib import Path

import datadog
from jentic.apitools.openapi.parser.core import OpenAPIParser, json_dumps, load_uri
from jentic.apitools.openapi.transformer.bundler.core import OpenAPIBundler
from jentic.apitools.openapi.transformer.core.references import (
    count_references,
    find_absolute_http_urls,
    find_relative_urls,
)
from jentic.apitools.openapi.validator.core import JenticDiagnostic
from lsprotocol.types import DiagnosticSeverity

from jentic.apitools.analyze.openapi_analyzer import OpenAPIAnalyzer
from jentic.apitools.common.models import (
    DiagnosticTarget,
    OASJsonRequest,
    OASProcessResult,
    ProgressCallback,
)
from jentic.apitools.common.utils.spec_utils import derive_endpoint_name, reorder_openapi_spec
from jentic.apitools.pipelines.artifacts import (
    build_api_metadata,
    build_apis_json,
    build_vendor_meta_json,
    extract_version,
)
from jentic.apitools.pipelines.file_manager import (
    PipelineFileManager,
    safe_read_spec,
    safe_write_json,
)
from jentic.apitools.pipelines.operations import (
    PipelineFatalError,
    build_diagnostic,
    build_fatal_diagnostic,
    build_reference_diagnostics,
    convert_spec_if_needed,
    find_server_url_diagnostics,
    get_oas_title,
    get_oas_version,
    is_valid_spec,
    load_and_parse_spec,
    reorder_spec,
    resolve_pipeline_inputs,
    validate_uris,
)
from jentic.apitools.score.score import calculate_score
from jentic.apitools.storage import (
    create_storage_context_from_oas_request_meta,  # create_storage_context_with_fallback
)


__all__ = ["import_openapi", "score_openapi"]

from jentic.apitools.common.utils.logging import get_module_logger


logger = get_module_logger(__name__)


def _report(callback: ProgressCallback | None, progress: int, message: str) -> None:
    """Report progress if a callback is provided."""
    if callback is not None:
        callback(progress, message)


try:
    datadog.initialize(
        statsd_socket_path="/var/run/datadog/dsd.socket",
    )
except Exception:  # noqa: BLE001
    logger.debug("Datadog socket not available; metrics disabled")


def import_openapi(
    oas_request: OASJsonRequest,
    *,
    spec_url: str,
    meta_zip_url: str | None = None,
    validate_unbundled: bool = True,
    progress_callback: ProgressCallback | None = None,
) -> OASProcessResult:
    """Download, parse, validate and bundle an OpenAPI spec.

    Args:
        oas_request: OASJsonRequest - details for the import process
        spec_url: URL or path to the spec to import
        meta_zip_url: Optional URL to metadata zip file
        validate_unbundled: whether the unbundled spec should be validated and repaired before bundling. Defaults to True.
    """

    oas_request_meta = oas_request.meta
    oas_process_configuration = oas_request_meta.oas_process_configuration
    enable_llm_analysis = oas_request_meta.oas_process_configuration.enable_llm_analysis or False

    with create_storage_context_from_oas_request_meta(oas_request_meta) as storage_ctx:
        # StorageContext provides working_dir (temp during processing)
        # and handles persistence to final destination on exit
        output_dir = storage_ctx.working_dir
        logger.info(
            f"Using storage context for output_dir {oas_request_meta.output_dir} with working dir: {output_dir} for {spec_url}"
        )
        try:
            # Resolve and sanitize inputs
            context = resolve_pipeline_inputs(oas_request_meta, spec_url, Path(output_dir))
            _report(progress_callback, 5, "Resolving inputs")
            # Prefer a non-file original_url if available, regardless of import_url type
            if context.original_url and (
                context.original_url.lower().startswith("http://")
                or context.original_url.lower().startswith("https://")
            ):
                canonical_source_url = context.original_url
            else:
                if context.import_url and not (
                    context.import_url.lower().startswith("http://")
                    or context.import_url.lower().startswith("https://")
                ):
                    # Content upload stored as a temp file
                    canonical_source_url = (
                        oas_request_meta.canonical_source_url
                        if oas_request_meta.canonical_source_url
                        else "content://uploaded"
                    )
                else:
                    canonical_source_url = (
                        oas_request_meta.canonical_source_url
                        if oas_request_meta.canonical_source_url
                        else context.import_url
                    )

            logger.info("Importing API: vendor %s, api_name %s", context.vendor, context.api_name)

            # Validate URIs (raises PipelineFatalError on fatal errors)
            validate_uris(context)

            # Load and parse spec
            imported_spec_text, imported_spec_content = load_and_parse_spec(
                context.import_url,
                oas_process_configuration.conn_timeout,
                oas_process_configuration.read_timeout,
                context.diagnostics,
                "import",
            )
            original_spec_text = imported_spec_text
            _report(progress_callback, 10, "Loading and parsing spec")

            # Load API meta if provided
            api_meta_text = None
            if context.api_meta_url:
                logger.debug("loading api_meta_url %s", context.api_meta_url)
                try:
                    api_meta_text = load_uri(
                        context.api_meta_url,
                        oas_process_configuration.conn_timeout,
                        oas_process_configuration.read_timeout,
                    )
                except Exception as e:
                    context.diagnostics.append(
                        build_diagnostic(
                            f"Failed to download/store api meta: {e}",
                            "failed-to-download-api-meta",
                            "loader",
                            DiagnosticSeverity.Warning,
                            target=DiagnosticTarget.META_URL,
                        )
                    )

            # Validate spec is OAS
            if not is_valid_spec(imported_spec_content):
                logger.error(
                    "Imported spec is not a valid OpenAPI specification: %s", context.import_url
                )
                diag = build_fatal_diagnostic(
                    "Imported spec is not a valid OpenAPI specification",
                    "imported-spec-not-oas",
                    "loader",
                    DiagnosticTarget.IMPORT_URL,
                )
                context.diagnostics.append(diag)
                return OASProcessResult(
                    False,
                    diagnostics=context.diagnostics,
                    error_message=diag.message,
                    error_code=diag.code,
                )

            # Extract version and setup file manager
            version = extract_version(imported_spec_content) or "1.0"
            context.version = version

            # Initialize file manager for path handling
            file_mgr = PipelineFileManager(
                Path(output_dir), context.vendor, context.api_name, version, "import"
            )
            _report(progress_callback, 15, "Validating spec format")

        except PipelineFatalError as e:
            return OASProcessResult(
                False,
                diagnostics=context.diagnostics,
                error_message=str(e),
                error_code=e.code,
            )

        # Continue processing - use context for subsequent operations
        target_version_dir = (
            Path(oas_request_meta.output_dir or output_dir)
            / context.vendor
            / context.api_name
            / version
        )
        diagnostics = context.diagnostics

        # Create aliases for easier access
        vendor = context.vendor
        api_name = context.api_name
        import_url = context.import_url
        label = context.label

        logger.debug(f"version dir: {str(file_mgr.version_dir)}")

        # Create necessary directories and save pristine copy
        try:
            file_mgr.ensure_directories()
            path: Path = file_mgr.get_path("source_pristine")
            path.write_text(original_spec_text, encoding="utf-8")
        except OSError as e:
            diag = build_diagnostic(
                f"Failed to write pristine copy: {e}", "write-pristine-failed", "fs"
            )
            diag.set_data_field("fatal", True)
            diagnostics.append(diag)
            return OASProcessResult(
                False,
                diagnostics=diagnostics,
                error_message=str(e),
                error_code="write-pristine-failed",
            )

        # Save API meta if provided
        if api_meta_text:
            safe_write_json(file_mgr.get_path("api_meta"), api_meta_text, diagnostics, fatal=False)
        else:
            vendor_meta_json = build_vendor_meta_json(str(vendor), str(api_name))
            safe_write_json(
                file_mgr.get_path("api_meta"), vendor_meta_json, diagnostics, fatal=False
            )

        # Convert spec if needed (Swagger2 or Google Discovery → OAS3)
        source_pristine_path = file_mgr.get_path("source_pristine")
        try:
            imported_spec_content, imported_spec_text, was_converted = convert_spec_if_needed(
                imported_spec_content,
                imported_spec_text,
                source_pristine_path,
                diagnostics,
                file_mgr,
            )
        except PipelineFatalError as e:
            return OASProcessResult(
                False,
                diagnostics=diagnostics,
                error_message=str(e),
                error_code=e.code,
            )
        _report(progress_callback, 25, "Converting spec format")

        resolved_original_url = oas_request_meta.original_url
        if not resolved_original_url:
            resolved_original_url = imported_spec_content.get("info", {}).get("x-jentic-source-url")
        if resolved_original_url and not imported_spec_content.get("info", {}).get(
            "x-jentic-source-url"
        ):
            imported_spec_content.setdefault("info", {})["x-jentic-source-url"] = (
                resolved_original_url
            )

        # Reorder spec for consistent structure
        imported_spec_content = reorder_spec(
            imported_spec_content, diagnostics, DiagnosticTarget.IMPORTED_SPEC
        )
        imported_spec_text = json_dumps(imported_spec_content, 2)
        logger.debug(f"reordered imported spec: {imported_spec_content.get('openapi')}")
        logger.debug(f"reordered imported_spec_text: {imported_spec_text[:20]}")

        relative_refs = find_relative_urls(imported_spec_content, True)
        absolute_http_refs = find_absolute_http_urls(imported_spec_content, True)
        (
            _imported_total_refs_count,
            _imported_local_refs_count,
            imported_relative_refs_count,
            imported_absolute_http_refs_count,
        ) = count_references(imported_spec_content, True)
        _report(progress_callback, 30, "Analyzing references")

        if (
            len(relative_refs) > 0
            and not oas_request_meta.oas_process_configuration.accepts_relative_references
        ):
            logger.exception("Spec includes relative references")
            diag = build_diagnostic(
                "Spec includes relative references",
                "spec-includes-relative-refs",
                "import-pipeline",
            )
            diag.set_data_field("fatal", True)
            diagnostics.append(diag)
            return OASProcessResult(
                False,
                diagnostics=diagnostics,
                error_message=diag.message,
                error_code="spec-includes-relative-refs",
            )

        if (
            len(absolute_http_refs) > 0
            and not oas_request_meta.oas_process_configuration.accepts_absolute_http_references
        ):
            logger.exception("Spec includes absolute HTTP references")
            diag = build_diagnostic(
                "Spec includes absolute HTTP references",
                "spec-includes-absolute-http-refs",
                "import-pipeline",
            )
            diag.set_data_field("fatal", True)
            diagnostics.append(diag)
            return OASProcessResult(
                False,
                diagnostics=diagnostics,
                error_message=diag.message,
                error_code="spec-includes-absolute-http-refs",
            )

        # Save import spec (input)
        input_spec_path = file_mgr.get_path("input_spec")
        if not safe_write_json(input_spec_path, imported_spec_text, diagnostics, True):
            return OASProcessResult(
                False,
                diagnostics=diagnostics,
                output_dir=oas_request_meta.output_dir,
                error_message="Failed to write input spec",
                error_code="failed-to-write-input-spec",
            )

        # Save repair spec for further processing (output)
        output_spec_path = file_mgr.get_path("output_spec")
        if not safe_write_json(output_spec_path, imported_spec_text, diagnostics, True):
            return OASProcessResult(
                False,
                diagnostics=diagnostics,
                output_dir=oas_request_meta.output_dir,
                error_message="Failed to write output spec",
                error_code="failed-to-write-output-spec",
            )

        processed_import_spec_content = imported_spec_content
        processed_import_spec_text = imported_spec_text
        processed_import_diagnostics = diagnostics
        if not validate_unbundled:
            logger.info("Skipping validate and repair on the import spec")
        else:
            validation_uri = str(output_spec_path.as_uri()) if was_converted else spec_url
            logger.info("Running validate on the import spec: %s", validation_uri)
            t0 = time.monotonic()
            validate_unbundled_diagnostics = OpenAPIAnalyzer().analyze(
                validation_uri,
                base_url=str(import_url),
                enable_llm_analysis=enable_llm_analysis,
                target=DiagnosticTarget.IMPORTED_SPEC,
                spec_type=DiagnosticTarget.IMPORTED_SPEC.value,
            )
            logger.info("Unbundled validation completed in %.1fs", time.monotonic() - t0)
            if validate_unbundled_diagnostics:
                logger.info(
                    "Validation issues found in unbundled validation for import_url %s",
                    validation_uri,
                )
                diagnostics.extend(validate_unbundled_diagnostics)
            safe_write_json(file_mgr.get_path("diagnostics"), diagnostics, diagnostics, fatal=False)

            processed_import_diagnostics = validate_unbundled_diagnostics

            if oas_process_configuration.reject_invalid_server_urls is not False:
                server_url_issues = find_server_url_diagnostics(
                    validate_unbundled_diagnostics or []
                )
                if server_url_issues:
                    codes = ", ".join(sorted({str(d.code) for d in server_url_issues if d.code}))
                    msg = f"Spec has server URL issues: {codes}"
                    logger.error(msg)
                    diag = build_diagnostic(
                        msg,
                        "invalid-server-urls",
                        "import-pipeline",
                    )
                    diag.set_data_field("fatal", True)
                    diagnostics.append(diag)
                    return OASProcessResult(
                        False,
                        diagnostics=diagnostics,
                        error_message=diag.message,
                        error_code="invalid-server-urls",
                    )

        _report(progress_callback, 40, "Validating unbundled spec")

        if oas_process_configuration.bundled_spec:
            bundled_spec_content = processed_import_spec_content
        else:
            try:
                # bundle spec
                if was_converted:
                    logger.info(f"Bundling converted spec: {str(output_spec_path)}")
                    t0 = time.monotonic()
                    bundled_spec_content = OpenAPIBundler("redocly").bundle(
                        str(output_spec_path.as_uri()), return_type=dict
                    )
                    logger.info("Bundling completed in %.1fs", time.monotonic() - t0)
                else:
                    logger.info(f"Bundling import_url: {str(import_url)}")
                    t0 = time.monotonic()
                    bundled_spec_content = OpenAPIBundler("redocly").bundle(
                        import_url, return_type=dict
                    )
                    logger.info("Bundling completed in %.1fs", time.monotonic() - t0)
            except Exception as e:
                logger.exception(f"Failed to bundle: {e}")
                diagnostics.append(
                    build_diagnostic(f"Failed to bundle: {e}", "bundle-failed", "fs")
                )
                safe_write_json(
                    file_mgr.get_path("diagnostics"), diagnostics, diagnostics, fatal=False
                )
                safe_write_json(
                    file_mgr.get_path("final_diagnostics"),
                    processed_import_diagnostics,
                    diagnostics,
                    fatal=False,
                )

                oas_version = get_oas_version(imported_spec_content)
                api_metadata = build_api_metadata(
                    oas_request_meta,
                    str(import_url),
                    str(vendor),
                    str(api_name),
                    str(version),
                    datetime.now().replace(microsecond=0).isoformat(),
                    oas_version,
                    Path(output_dir),
                    output_spec_path,
                    None,
                    source_pristine_path,
                    diagnostics,
                    processed_import_diagnostics,
                    True,
                )

                score = calculate_score(
                    spec_path=output_spec_path,
                    spec_text=processed_import_spec_text,
                    spec_content=processed_import_spec_content,
                    diagnostics=processed_import_diagnostics,
                    vendor=str(vendor),
                    api_name=get_oas_title(imported_spec_content),
                    version=str(version),
                    oas_version=oas_version,
                    oas_request_meta=oas_request_meta,
                    source_url=str(canonical_source_url),
                    artifacts_root=Path(output_dir),
                    fatalError=True,
                    include_diagnostics=False,
                )

                safe_write_json(
                    file_mgr.get_path("final_api_metadata"), api_metadata, diagnostics, fatal=False
                )
                safe_write_json(
                    file_mgr.get_path("api_metadata"), api_metadata, diagnostics, fatal=False
                )
                safe_write_json(file_mgr.get_path("scorecard"), score, diagnostics, fatal=False)

                return OASProcessResult(
                    False,
                    diagnostics,
                    str(oas_request_meta.output_dir),
                    str(target_version_dir),
                    derive_endpoint_name(label),
                    error_message="Failed to write final API metadata",
                    error_code="failed-to-write-final-api-metadata",
                )

            if resolved_original_url and not bundled_spec_content.get("info", {}).get(
                "x-jentic-source-url"
            ):
                bundled_spec_content.setdefault("info", {})["x-jentic-source-url"] = (
                    resolved_original_url
                )
            # reorder spec
            try:
                bundled_spec_content = reorder_openapi_spec(bundled_spec_content)
            except Exception as e:
                logger.exception(f"Failed to reorder repaired: {e}")
                diagnostics.append(
                    build_diagnostic(
                        f"Failed to reorder: {e}",
                        "failed-to-reorder-bundled-spec",
                        "loader",
                        DiagnosticSeverity.Warning,
                        target=DiagnosticTarget.BUNDLED_SPEC,
                    )
                )

        bundled_spec_text = json_dumps(bundled_spec_content, 2)
        _report(progress_callback, 55, "Bundling spec")

        relative_refs = find_relative_urls(bundled_spec_content, True)
        absolute_http_refs = find_absolute_http_urls(bundled_spec_content, True)

        # save bundled spec (output and input for cumulative overlays)
        output_bundled_spec_path = file_mgr.get_path("output_spec", bundled=True)
        if not safe_write_json(output_bundled_spec_path, bundled_spec_text, diagnostics):
            safe_write_json(file_mgr.get_path("diagnostics"), diagnostics, diagnostics, fatal=False)
            return OASProcessResult(
                False,
                diagnostics=diagnostics,
                error_message="Failed to write bundled spec",
                error_code="failed-to-write-bundled-spec",
            )

        # save the immutable bundled first import on which the cumulative overlays are applied
        input_bundled_spec_path = file_mgr.get_path("input_spec", bundled=True)
        if not safe_write_json(input_bundled_spec_path, bundled_spec_text, diagnostics):
            return OASProcessResult(
                False,
                diagnostics=diagnostics,
                error_message="Failed to write input bundled spec",
                error_code="failed-to-write-input-bundled-spec",
            )

        # do a final validation on the bundled spec and save it
        bundle_diagnostics: list[JenticDiagnostic] = []
        try:
            # validate bundled spec directly
            logger.info(
                f"Final Validation of bundled spec {str(output_bundled_spec_path)}, LLM analysis: {enable_llm_analysis}"
            )
            t0 = time.monotonic()
            validation_diagnostics = OpenAPIAnalyzer().analyze(
                str(output_bundled_spec_path),
                base_url=str(import_url),
                enable_llm_analysis=enable_llm_analysis,
                target=DiagnosticTarget.BUNDLED_SPEC,
                spec_type=DiagnosticTarget.BUNDLED_SPEC.value,
            )
            logger.info("Bundled validation completed in %.1fs", time.monotonic() - t0)
            if validation_diagnostics:
                logger.info(
                    "Validation issues found in final validation for import_url %s",
                    str(output_bundled_spec_path),
                )
                bundle_diagnostics.extend(validation_diagnostics)
            diagnostics.extend(validation_diagnostics)
            safe_write_json(file_mgr.get_path("diagnostics"), diagnostics, diagnostics, fatal=False)

            if oas_process_configuration.reject_invalid_server_urls is not False:
                server_url_issues = find_server_url_diagnostics(validation_diagnostics or [])
                if server_url_issues:
                    codes = ", ".join(sorted({str(d.code) for d in server_url_issues if d.code}))
                    msg = f"Bundled spec has server URL issues: {codes}"
                    logger.error(msg)
                    diag = build_diagnostic(
                        msg,
                        "invalid-server-urls",
                        "import-pipeline",
                    )
                    diag.set_data_field("fatal", True)
                    diagnostics.append(diag)
                    return OASProcessResult(
                        False,
                        diagnostics,
                        str(oas_request_meta.output_dir),
                        str(target_version_dir),
                        derive_endpoint_name(label),
                        error_message=diag.message,
                        error_code="invalid-server-urls",
                    )

        except Exception:
            logger.exception(
                f"Error in final validation of bundled spec {str(output_bundled_spec_path)}"
            )
            return OASProcessResult(
                False,
                diagnostics,
                str(oas_request_meta.output_dir),
                str(target_version_dir),
                derive_endpoint_name(label),
                error_message="Failed to write final diagnostics",
                error_code="failed-to-write-final-diagnostics",
            )
        _report(progress_callback, 65, "Validating bundled spec")

        logger.info("Saving final openapi and overlays")
        bundled_spec_text = safe_read_spec(output_bundled_spec_path, diagnostics, True)
        if bundled_spec_text:
            safe_write_json(
                file_mgr.get_path("final_spec"), bundled_spec_text, diagnostics, fatal=False
            )

        if file_mgr.get_path("overlays", bundled=True).exists():
            bundled_overlays_text = safe_read_spec(
                file_mgr.get_path("overlays", bundled=True), diagnostics
            )
            if bundled_overlays_text:
                safe_write_json(
                    file_mgr.get_path("final_overlays"),
                    bundled_overlays_text,
                    diagnostics,
                    fatal=False,
                )

        ref_diags = build_reference_diagnostics(
            bundled_spec_content,
            imported_relative_refs_count,
            imported_absolute_http_refs_count,
        )
        bundle_diagnostics.extend(ref_diags)

        safe_write_json(
            file_mgr.get_path("final_diagnostics"), bundle_diagnostics, diagnostics, fatal=False
        )

        logger.debug("Building api_metadata")
        t0 = time.monotonic()

        oas_version = get_oas_version(imported_spec_content)

        # prepare and save api_metadata
        api_metadata = build_api_metadata(
            oas_request_meta,
            str(import_url),
            str(vendor),
            str(api_name),
            str(version),
            datetime.now().replace(microsecond=0).isoformat(),
            oas_version,
            Path(output_dir),
            output_spec_path,
            output_bundled_spec_path,
            source_pristine_path,
            processed_import_diagnostics,
            bundle_diagnostics,
            False,
        )
        logger.info("api_metadata built in %.1fs", time.monotonic() - t0)

        t0 = time.monotonic()
        score = calculate_score(
            spec_path=output_bundled_spec_path,
            spec_text=bundled_spec_text,
            spec_content=bundled_spec_content,
            diagnostics=bundle_diagnostics,
            vendor=str(vendor),
            api_name=get_oas_title(imported_spec_content),
            version=str(version),
            oas_version=oas_version,
            oas_request_meta=oas_request_meta,
            source_url=str(canonical_source_url),
            artifacts_root=Path(output_dir),
            fatalError=False,
            include_diagnostics=False,
        )

        logger.info("Score calculated in %.1fs", time.monotonic() - t0)
        _report(progress_callback, 80, "Calculating score")

        safe_write_json(
            file_mgr.get_path("final_api_metadata"), api_metadata, diagnostics, fatal=False
        )
        safe_write_json(file_mgr.get_path("api_metadata"), api_metadata, diagnostics, fatal=False)

        safe_write_json(file_mgr.get_path("scorecard"), score, diagnostics, fatal=False)

        apis_json = build_apis_json(
            oas_request_meta,
            bundled_spec_content,
            str(vendor),
            str(api_name),
            str(version),
            Path(output_dir),
            output_bundled_spec_path,
        )
        safe_write_json(file_mgr.get_path("apis_json"), apis_json, diagnostics, fatal=False)
        _report(progress_callback, 90, "Saving artifacts")
        logger.info("Executed import pipeline")
        # download and save doc URLs and context
        # process doc URLs and context with LLM to:
        # extract a summary / docs of APIs for human consumption
        # extract a summary / docs tailored for execution, generation and search
        return OASProcessResult(
            True,
            diagnostics,
            str(oas_request_meta.output_dir),
            str(target_version_dir),
            derive_endpoint_name(label),
        )


def score_openapi(
    oas_request: OASJsonRequest,
    *,
    spec_url: str,
    progress_callback: ProgressCallback | None = None,
) -> OASProcessResult:
    """Download, parse, bundle, and score an OpenAPI spec.

    Args:
        oas_request: OASJsonRequest - details for the import process
        spec_url: URL or path to the spec to import
    """

    oas_request_meta = oas_request.meta
    oas_process_configuration = oas_request_meta.oas_process_configuration
    enable_llm_analysis = oas_request_meta.oas_process_configuration.enable_llm_analysis or False
    include_diagnostics_in_score = oas_process_configuration.include_diagnostics_in_score or False
    skip_bundle = oas_process_configuration.skip_bundle or False

    with create_storage_context_from_oas_request_meta(oas_request_meta) as storage_ctx:
        # StorageContext provides working_dir (temp during processing)
        # and handles persistence to final destination on exit
        output_dir = storage_ctx.working_dir
        logger.info(
            f"Using storage context for output_dir {oas_request_meta.output_dir} with working dir: {output_dir} for {spec_url}"
        )

        try:
            # Resolve and sanitize inputs
            context = resolve_pipeline_inputs(oas_request_meta, spec_url, Path(output_dir))
            _report(progress_callback, 5, "Resolving inputs")
            logger.debug("Importing API: vendor %s, api_name %s", context.vendor, context.api_name)

            # Validate URIs (raises PipelineFatalError on fatal errors)
            validate_uris(context)

            if context.original_url and (
                context.original_url.lower().startswith("http://")
                or context.original_url.lower().startswith("https://")
            ):
                canonical_source_url = context.original_url
            else:
                if context.import_url and not (
                    context.import_url.lower().startswith("http://")
                    or context.import_url.lower().startswith("https://")
                ):
                    # Content upload stored as a temp file
                    canonical_source_url = (
                        oas_request_meta.canonical_source_url
                        if oas_request_meta.canonical_source_url
                        else "content://uploaded"
                    )
                else:
                    canonical_source_url = (
                        oas_request_meta.canonical_source_url
                        if oas_request_meta.canonical_source_url
                        else context.import_url
                    )

            logger.info("Scoring API: vendor %s, api_name %s", context.vendor, context.api_name)
            # Load and parse spec
            imported_spec_text, imported_spec_content = load_and_parse_spec(
                context.import_url,
                oas_process_configuration.conn_timeout,
                oas_process_configuration.read_timeout,
                context.diagnostics,
                "import",
            )
            _report(progress_callback, 10, "Loading and parsing spec")

            # Validate spec is OAS
            if not is_valid_spec(imported_spec_content):
                logger.error(
                    "Imported spec is not a valid OpenAPI specification: %s", context.import_url
                )
                diag = build_fatal_diagnostic(
                    "Imported spec is not a valid OpenAPI specification",
                    "imported-spec-not-oas",
                    "loader",
                    DiagnosticTarget.IMPORT_URL,
                )
                context.diagnostics.append(diag)
                return OASProcessResult(
                    False,
                    diagnostics=context.diagnostics,
                    error_message="Imported spec is not a valid OpenAPI specification",
                    error_code="imported-spec-not-oas",
                )

            # Extract version and setup file manager
            version = extract_version(imported_spec_content) or "1.0"
            context.version = version

            # Initialize file manager for path handling
            file_mgr = PipelineFileManager(
                Path(output_dir), context.vendor, context.api_name, version, "import"
            )
            _report(progress_callback, 15, "Validating spec format")

        except PipelineFatalError as e:
            # Fatal error already logged and diagnostics populated
            return OASProcessResult(
                False,
                diagnostics=context.diagnostics,
                error_message=str(e),
                error_code=e.code,
            )

        # Continue processing - use context for subsequent operations
        target_version_dir = (
            Path(oas_request_meta.output_dir or output_dir)
            / context.vendor
            / context.api_name
            / version
        )
        diagnostics = context.diagnostics

        # Create aliases for easier access
        vendor = context.vendor
        api_name = context.api_name
        import_url = context.import_url
        label = context.label

        logger.debug(f"version dir: {str(file_mgr.version_dir)}")

        # Create necessary directories
        try:
            file_mgr.ensure_directories()
            source_pristine_path = file_mgr.get_path("source_pristine")
            source_pristine_path.write_text(imported_spec_text, encoding="utf-8")
        except OSError as e:
            diag = build_diagnostic(
                f"Failed to ensure_directories: {e}", "ensure-directories", "fs"
            )
            diag.set_data_field("fatal", True)
            diagnostics.append(diag)
            return OASProcessResult(
                False,
                diagnostics=diagnostics,
                error_message=str(e),
                error_code="failed-to-ensure-directories",
            )

        # Convert spec if needed (Swagger2 or Google Discovery → OAS3)
        try:
            imported_spec_content, imported_spec_text, was_converted = convert_spec_if_needed(
                imported_spec_content,
                imported_spec_text,
                source_pristine_path,
                diagnostics,
                file_mgr,
                False,
            )
        except PipelineFatalError as e:
            return OASProcessResult(
                False, diagnostics=diagnostics, error_message=str(e), error_code=e.code
            )
        _report(progress_callback, 25, "Converting spec format")

        relative_refs = find_relative_urls(imported_spec_content, True)
        absolute_http_refs = find_absolute_http_urls(imported_spec_content, True)
        (
            _imported_total_refs_count,
            _imported_local_refs_count,
            imported_relative_refs_count,
            imported_absolute_http_refs_count,
        ) = count_references(imported_spec_content, True)

        if (
            len(relative_refs) > 0
            and not oas_request_meta.oas_process_configuration.accepts_relative_references
        ):
            logger.error("Spec includes relative references")
            diag = build_diagnostic(
                "Spec includes relative references",
                "spec-includes-relative-refs",
                "import-pipeline",
            )
            diag.set_data_field("fatal", True)
            diagnostics.append(diag)
            return OASProcessResult(
                False,
                diagnostics=diagnostics,
                error_message="Spec includes relative references",
                error_code="spec-includes-relative-refs",
            )

        if (
            len(absolute_http_refs) > 0
            and not oas_request_meta.oas_process_configuration.accepts_absolute_http_references
        ):
            logger.error("Spec includes absolute HTTP references")
            diag = build_diagnostic(
                "Spec includes absolute HTTP references",
                "spec-includes-absolute-http-refs",
                "import-pipeline",
            )
            diag.set_data_field("fatal", True)
            diagnostics.append(diag)
            return OASProcessResult(
                False,
                diagnostics=diagnostics,
                error_message="Spec includes absolute HTTP references",
                error_code="spec-includes-absolute-http-refs",
            )

        # Save spec for further processing (output)
        output_spec_path = file_mgr.get_path("output_spec")
        if not safe_write_json(output_spec_path, imported_spec_text, diagnostics, True):
            return OASProcessResult(
                False,
                diagnostics=diagnostics,
                output_dir=oas_request_meta.output_dir,
                error_message="Failed to write output spec",
                error_code="failed-to-write-output-spec",
            )

        processed_import_spec_content = imported_spec_content
        processed_import_spec_text = imported_spec_text
        processed_import_diagnostics = diagnostics

        if skip_bundle:
            logger.info("Skipping bundling step (skip_bundle=True)")
            score_spec_content = processed_import_spec_content
            score_spec_text = processed_import_spec_text
            score_spec_path = output_spec_path
            validation_target = DiagnosticTarget.IMPORTED_SPEC
            _report(progress_callback, 50, "Skipping bundling step")
        else:
            try:
                # bundle spec
                if was_converted:
                    logger.info(f"Bundling converted spec: {str(output_spec_path)}")
                    t0 = time.monotonic()
                    bundled_spec_text = OpenAPIBundler("redocly").bundle(
                        str(output_spec_path.as_uri()), return_type=str
                    )
                    logger.info("Bundling completed in %.1fs", time.monotonic() - t0)
                else:
                    logger.info(f"Bundling import_url: {str(import_url)}")
                    t0 = time.monotonic()
                    bundled_spec_text = OpenAPIBundler("redocly").bundle(
                        import_url, return_type=str
                    )
                    logger.info("Bundling completed in %.1fs", time.monotonic() - t0)
                bundled_spec_content = OpenAPIParser("pyyaml", logger=logger).parse(
                    bundled_spec_text
                )
                _report(progress_callback, 35, "Bundling spec")

            except Exception as e:
                logger.exception(f"Failed to bundle: {e}")
                diagnostics.append(
                    build_diagnostic(f"Failed to bundle: {e}", "bundle-failed", "fs")
                )
                safe_write_json(
                    file_mgr.get_path("diagnostics"), diagnostics, diagnostics, fatal=True
                )
                safe_write_json(
                    file_mgr.get_path("final_diagnostics"),
                    processed_import_diagnostics,
                    diagnostics,
                    fatal=True,
                )

                oas_version = get_oas_version(imported_spec_content)
                api_metadata = build_api_metadata(
                    oas_request_meta,
                    str(import_url),
                    str(vendor),
                    str(api_name),
                    str(version),
                    datetime.now().replace(microsecond=0).isoformat(),
                    oas_version,
                    Path(output_dir),
                    output_spec_path,
                    None,
                    None,
                    diagnostics,
                    processed_import_diagnostics,
                    True,
                )

                score = calculate_score(
                    spec_path=output_spec_path,
                    spec_text=processed_import_spec_text,
                    spec_content=processed_import_spec_content,
                    diagnostics=processed_import_diagnostics,
                    vendor=str(vendor),
                    api_name=get_oas_title(imported_spec_content),
                    version=str(version),
                    oas_version=oas_version,
                    oas_request_meta=oas_request_meta,
                    source_url=str(canonical_source_url),
                    artifacts_root=Path(output_dir),
                    fatalError=True,
                    include_diagnostics=include_diagnostics_in_score,
                )

                safe_write_json(
                    file_mgr.get_path("final_api_metadata"),
                    api_metadata,
                    diagnostics,
                    fatal=False,
                )
                safe_write_json(file_mgr.get_path("scorecard"), score, diagnostics, fatal=False)

                return OASProcessResult(
                    False,
                    diagnostics,
                    str(oas_request_meta.output_dir),
                    str(target_version_dir),
                    derive_endpoint_name(label),
                    error_message="Failed to bundle spec",
                    error_code="failed-to-bundle-spec",
                )

            # save bundled spec (output and input for cumulative overlays)
            output_bundled_spec_path = file_mgr.get_path("output_spec", bundled=True)
            if not safe_write_json(output_bundled_spec_path, bundled_spec_text, diagnostics):
                safe_write_json(
                    file_mgr.get_path("diagnostics"), diagnostics, diagnostics, fatal=False
                )
                return OASProcessResult(
                    False,
                    diagnostics=diagnostics,
                    error_message="Failed to write bundled spec",
                    error_code="failed-to-write-bundled-spec",
                )
            _report(progress_callback, 50, "Saving bundled spec")

            score_spec_content = bundled_spec_content
            score_spec_text = bundled_spec_text
            score_spec_path = output_bundled_spec_path
            validation_target = DiagnosticTarget.BUNDLED_SPEC

        # do a final validation on the spec and save it
        final_diagnostics: list[JenticDiagnostic] = []
        try:
            logger.info(
                "Final validation of %s spec %s, LLM analysis: %s",
                "unbundled" if skip_bundle else "bundled",
                str(score_spec_path),
                enable_llm_analysis,
            )
            t0 = time.monotonic()
            validation_diagnostics = OpenAPIAnalyzer().analyze(
                str(score_spec_path),
                base_url=str(import_url),
                enable_llm_analysis=enable_llm_analysis,
                target=validation_target,
                spec_type=validation_target.value,
            )
            logger.info(
                "%s validation completed in %.1fs",
                "Unbundled" if skip_bundle else "Bundled",
                time.monotonic() - t0,
            )
            if validation_diagnostics:
                logger.info(
                    "Validation issues found in final validation for path %s",
                    str(score_spec_path),
                )
                final_diagnostics.extend(validation_diagnostics)
            diagnostics.extend(validation_diagnostics)
        except Exception:
            logger.exception(
                "Error in final validation of %s spec %s",
                "unbundled" if skip_bundle else "bundled",
                str(score_spec_path),
            )
            return OASProcessResult(
                False,
                diagnostics,
                str(oas_request_meta.output_dir),
                str(target_version_dir),
                derive_endpoint_name(label),
                error_message=f"Failed to validate {'unbundled' if skip_bundle else 'bundled'} spec",
                error_code=f"failed-to-validate-{'unbundled' if skip_bundle else 'bundled'}-spec",
            )
        _report(progress_callback, 65, "Validating spec")

        ref_diags = build_reference_diagnostics(
            score_spec_content,
            imported_relative_refs_count,
            imported_absolute_http_refs_count,
        )
        final_diagnostics.extend(ref_diags)

        safe_write_json(
            file_mgr.get_path("final_diagnostics"),
            final_diagnostics,
            diagnostics,
            fatal=False,
        )

        logger.debug("Building api_metadata")

        oas_version = get_oas_version(imported_spec_content)

        score = calculate_score(
            spec_path=score_spec_path,
            spec_text=score_spec_text,
            spec_content=score_spec_content,
            diagnostics=final_diagnostics,
            vendor=str(vendor),
            api_name=get_oas_title(imported_spec_content),
            version=str(version),
            oas_version=oas_version,
            oas_request_meta=oas_request_meta,
            source_url=str(canonical_source_url),
            artifacts_root=Path(output_dir),
            fatalError=False,
            include_diagnostics=include_diagnostics_in_score,
        )
        _report(progress_callback, 85, "Calculating score")

        safe_write_json(file_mgr.get_path("scorecard"), score, diagnostics, fatal=False)
        _report(progress_callback, 90, "Saving results")

        logger.info("Executed score pipeline")
        return OASProcessResult(
            True,
            diagnostics,
            str(oas_request_meta.output_dir),
            str(target_version_dir),
            derive_endpoint_name(label),
        )
