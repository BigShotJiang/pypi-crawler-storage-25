"""Pipeline step functions for OpenAPI processing.

This module provides reusable, step-based functions that can be composed
into import and QA pipelines. Each step handles a specific part of the
pipeline with standardized error handling.
"""

from __future__ import annotations

import re
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal, Tuple, overload

from deepdiff import DeepDiff
from jentic.apitools.openapi.common.uri import is_uri_like
from jentic.apitools.openapi.parser.core import (
    DocumentLoadError,
    OpenAPIParser,
    OpenAPIParserError,
    json_dumps,
    load_uri,
)
from jentic.apitools.openapi.validator.core import JenticDiagnostic
from lsprotocol.types import DiagnosticSeverity, Position, Range

from jentic.apitools.common.models import DiagnosticTarget, OASRequestMeta
from jentic.apitools.common.utils.file_utils import sanitize_filepath
from jentic.apitools.common.utils.logging import get_module_logger
from jentic.apitools.common.utils.spec_utils import (
    convert_to_openapi3,
    reorder_openapi_spec,
    split_label,
)


logger = get_module_logger(__name__)


SERVER_URL_DIAGNOSTIC_CODES: frozenset[str] = frozenset(
    {
        "hosts-https-only-oas3",
        "INVALID_SERVER_OBJECT_FORMAT",
        "MISSING_SERVER_URL",
        "no-empty-servers",
        "no-undefined-server-variable",
        "no-server-example.com",
        "oas3-server-variables",
        "oas3-api-servers",
        "RELATIVE_SERVER_URL",
        "SERVER_URL_MISSING_OR_EMPTY",
    }
)


def find_server_url_diagnostics(
    diagnostics: list[JenticDiagnostic],
) -> list[JenticDiagnostic]:
    """Return diagnostics whose code matches a known server-URL issue."""
    return [d for d in diagnostics if d.code in SERVER_URL_DIAGNOSTIC_CODES]


class PipelineFatalError(Exception):
    """Fatal error in pipeline that should stop processing.

    This exception carries diagnostic information and can be caught
    at the pipeline level to build appropriate error responses.
    """

    def __init__(self, message: str, code: str, diagnostics: list[JenticDiagnostic]):
        super().__init__(message)
        self.code = code
        self.diagnostics = diagnostics


@dataclass
class PipelineContext:
    """Context object holding pipeline execution state.

    This object is passed through pipeline steps and accumulates
    state and diagnostics as processing proceeds.
    """

    # Input parameters
    oas_request_meta: OASRequestMeta
    spec_url: str
    output_dir: Path
    import_url: str

    # Resolved values
    label: str
    vendor: str
    api_name: str
    version: str | None = None

    # URLs
    original_url: str | None = None
    api_meta_url: str | None = None

    # Processing state
    diagnostics: list[JenticDiagnostic] = field(default_factory=list)


def build_diagnostic(
    msg: str,
    code: str,
    source: str,
    severity: DiagnosticSeverity | None = DiagnosticSeverity.Error,
    *,
    target: DiagnosticTarget | None = None,
    path: list[str | int] | None = None,
    fixable: bool = True,
) -> JenticDiagnostic:
    diag = JenticDiagnostic(
        range=Range(Position(0, 0), Position(0, 0)),
        message=msg,
        code=code,
        source=source,
        severity=severity,
    )
    if target:
        diag.set_target(target.value)
    diag.set_path(path)
    diag.set_fixable(fixable)
    return diag


def build_fatal_diagnostic(
    msg: str, code: str, source: str, target: DiagnosticTarget | None = None
) -> JenticDiagnostic:
    """Build a diagnostic marked as fatal.

    Args:
        msg: Error message
        code: Error code
        source: Source of the error (e.g., "loader", "parser")
        target: Optional diagnostic target

    Returns:
        JenticDiagnostic with fatal flag set
    """

    diag = build_diagnostic(msg, code, source, DiagnosticSeverity.Error, target=target)
    diag.set_data_field("fatal", True)
    return diag


def build_reference_diagnostics(
    final_spec_content: dict,
    imported_relative_refs_count: int,
    imported_absolute_http_refs_count: int,
    skip_bundle: bool = False,
) -> list[JenticDiagnostic]:
    """Build informational diagnostics about $ref usage in bundled or unbundled spec.

    Counts references in the bundled spec and if skip_bundle is False computes how many were
    resolved during bundling by comparing against the pre-bundle counts.
    """
    from jentic.apitools.openapi.transformer.core.references import count_references

    validation_target = (
        DiagnosticTarget.IMPORTED_SPEC if skip_bundle else DiagnosticTarget.BUNDLED_SPEC
    )
    (
        final_total_refs_count,
        final_local_refs_count,
        final_relative_refs_count,
        final_absolute_http_refs_count,
    ) = count_references(final_spec_content, True)

    resolved_refs_count = (
        final_local_refs_count
        + imported_relative_refs_count
        + imported_absolute_http_refs_count
        - final_relative_refs_count
        - final_absolute_http_refs_count
    )

    diags: list[JenticDiagnostic] = []

    d = build_diagnostic(
        f"API has {final_relative_refs_count} relative references",
        "relative_refs",
        "loader",
        DiagnosticSeverity.Information,
        target=validation_target,
    )
    d.set_data_field("relative_refs", final_relative_refs_count)
    diags.append(d)

    d = build_diagnostic(
        f"API has {final_absolute_http_refs_count} http absolute references",
        "absolute_http_refs",
        "loader",
        DiagnosticSeverity.Information,
        target=validation_target,
    )
    d.set_data_field("absolute_http_refs", final_absolute_http_refs_count)
    diags.append(d)

    d = build_diagnostic(
        f"API has {final_total_refs_count} total references",
        "total_refs",
        "loader",
        DiagnosticSeverity.Information,
        target=validation_target,
    )
    d.set_data_field("total_refs", final_total_refs_count)
    diags.append(d)

    d = build_diagnostic(
        f"API has {resolved_refs_count} resolved references",
        "resolved_refs",
        "loader",
        DiagnosticSeverity.Information,
        target=validation_target,
    )
    d.set_data_field("resolved_refs", resolved_refs_count)
    diags.append(d)

    return diags


def resolve_pipeline_inputs(
    oas_request_meta: OASRequestMeta, spec_url: str, output_dir: Path
) -> PipelineContext:
    """Resolve and sanitize all pipeline inputs into a context object.

    Args:
        oas_request_meta: Request metadata
        spec_url: URL or path to the spec
        output_dir: Output directory for pipeline artifacts

    Returns:
        PipelineContext with resolved and sanitized values
    """
    # Sanitize label
    label = sanitize_filepath(oas_request_meta.label)

    # Handle import URL
    import_url = str(spec_url) if spec_url else None
    if not import_url:
        raise ValueError("spec_url must be provided")

    # Extract other URLs
    original_url = str(oas_request_meta.original_url) if oas_request_meta.original_url else None
    api_meta_url = str(oas_request_meta.api_meta_url) if oas_request_meta.api_meta_url else None

    # Sanitize label path segments
    vendor, api_name = split_label(label)
    vendor = sanitize_filepath(vendor)
    api_name = sanitize_filepath(api_name)

    return PipelineContext(
        oas_request_meta=oas_request_meta,
        spec_url=spec_url,
        output_dir=output_dir,
        label=label,
        vendor=vendor,
        api_name=api_name,
        import_url=import_url,
        original_url=original_url,
        api_meta_url=api_meta_url,
    )


def validate_uris(context: PipelineContext) -> None:
    """Validate all URIs in the context.

    Adds diagnostics for invalid URIs but doesn't fail fatally.

    Args:
        context: Pipeline context with URIs to validate
    """
    # Validate original URI if exists
    if context.original_url:
        logger.debug("verifying original_url %s", context.original_url)
        if not is_uri_like(context.original_url):
            msg = f"Invalid original URI: {context.original_url}"
            context.diagnostics.append(
                build_warning_diagnostic(
                    msg, "invalid-original-uri", "loader", DiagnosticTarget.ORIGINAL_URL
                )
            )
            logger.warning(msg)

    # Validate api_meta URI if exists
    if context.api_meta_url:
        if not is_uri_like(context.api_meta_url):
            msg = f"Invalid meta URI: {context.api_meta_url}"
            context.diagnostics.append(
                build_warning_diagnostic(
                    msg, "invalid-meta-uri", "loader", DiagnosticTarget.META_URL
                )
            )
            logger.warning(msg)

    # Validate docURIs if exist
    if context.oas_request_meta.doc_urls:
        for doc_url in context.oas_request_meta.doc_urls:
            logger.debug("verifying doc_url %s", doc_url)
            if not is_uri_like(str(doc_url)):
                msg = f"Invalid docURI: {doc_url}"
                context.diagnostics.append(
                    build_warning_diagnostic(
                        msg, "invalid-doc-uri", "loader", DiagnosticTarget.DOCS_URL
                    )
                )
                logger.warning(msg)

    # Validate import URI (this one is fatal if invalid)
    logger.debug("verifying import_url %s", context.import_url)
    if not is_uri_like(context.import_url) and (
        not context.import_url or not context.import_url.startswith("content://")
    ):
        msg = f"Invalid import URI: {context.import_url}"
        diag = build_fatal_diagnostic(
            msg, "invalid-import-uri", "loader", DiagnosticTarget.IMPORT_URL
        )
        logger.error(msg)
        context.diagnostics.append(diag)
        raise PipelineFatalError(msg, "invalid-import-uri", context.diagnostics)


def build_warning_diagnostic(
    msg: str, code: str, source: str, target: DiagnosticTarget | None = None
) -> JenticDiagnostic:
    """Build a warning diagnostic.

    Args:
        msg: Warning message
        code: Warning code
        source: Source of the warning
        target: Optional diagnostic target

    Returns:
        JenticDiagnostic with warning severity
    """
    return build_diagnostic(msg, code, source, DiagnosticSeverity.Warning, target=target)


def is_valid_spec(data: dict) -> Tuple[bool, str | None]:  # pragma: no cover
    """Best-effort validation that *content* looks like an API spec."""

    if "swagger" in data or "openapi" in data:
        return True, None
    if is_google_format(data):
        return True, None
    return False, "File is not a valid OpenAPI, Swagger, or Google API spec"


def is_google_format(data: dict) -> bool:  # pragma: no cover
    kind = data.get("kind", "")
    has_discovery_version = "discoveryVersion" in data
    return kind.startswith("discovery#") or has_discovery_version


def is_swagger_2(data: dict) -> bool:
    return str(data.get("swagger", "")).startswith("2.")


def is_swagger_30(data: dict) -> bool:
    return str(data.get("openapi", "")).startswith("3.0")


def get_oas_version(data: dict) -> str:
    return str(data.get("openapi", ""))


def get_oas_title(data: dict) -> str:
    return str(data.get("info", {}).get("title", ""))


SURR = re.compile(r"[\ud800-\udfff]")


def _has_surrogate(s: str) -> bool:
    return bool(SURR.search(s))


def _repair_string(s: str) -> str:
    # Fast path: avoid work if clean
    if not _has_surrogate(s):
        return s
    logger.warning("Repairing string with surrogates")
    # Merge valid UTF-16 surrogate pairs; replace lone surrogates with U+FFFD
    return s.encode("utf-16", "surrogatepass").decode("utf-16", "replace")


def repair_tree(x: Any) -> Any:
    try:
        if isinstance(x, str):
            return _repair_string(x)
        if isinstance(x, list):
            return [repair_tree(v) for v in x]
        if isinstance(x, tuple):
            return tuple(repair_tree(v) for v in x)
        if isinstance(x, dict):
            # Also repair *keys* (they can carry bad code points too)
            return {
                (_repair_string(k) if isinstance(k, str) else k): repair_tree(v)
                for k, v in x.items()
            }
        # ints, floats, bool, None, etc.
        return x
    except Exception as e:
        logger.exception(f"Failed to repair tree: {e}")
        return x


def parse(spec_text: str) -> dict:
    return repair_tree(OpenAPIParser("pyyaml", logger=logger).parse(spec_text))


def load_and_parse_spec(
    url: str,
    conn_timeout: int,
    read_timeout: int,
    diagnostics: list[JenticDiagnostic],
    error_prefix: str = "import",
) -> tuple[str, dict]:
    """Load and parse a spec from a URL.

    Args:
        url: URL to load from
        conn_timeout: Connection timeout in seconds
        read_timeout: Read timeout in seconds
        diagnostics: List to append diagnostics to
        error_prefix: Prefix for error codes (e.g., "import", "converted")

    Returns:
        Tuple of (spec_text, spec_content)

    Raises:
        PipelineFatalError: If loading or parsing fails
    """

    # Load the spec
    logger.debug("loading spec from %s", url)
    try:
        spec_text = load_uri(url, conn_timeout, read_timeout)
    except DocumentLoadError as e:
        msg = f"Failed to download {error_prefix} spec: {e}"
        diag = build_fatal_diagnostic(
            msg, f"failed-to-download-{error_prefix}-spec", "loader", DiagnosticTarget.IMPORT_URL
        )
        logger.exception(msg)
        diagnostics.append(diag)
        raise PipelineFatalError(msg, f"failed-to-download-{error_prefix}-spec", diagnostics)

    # Parse the spec
    logger.debug("parsing loaded spec")
    try:
        spec_content = parse(spec_text)
    except OpenAPIParserError as e:
        msg = f"Failed to parse {error_prefix} spec: {e}"
        diag = build_fatal_diagnostic(
            msg,
            f"failed-to-parse-{error_prefix}-spec",
            "default-parser",
            DiagnosticTarget.IMPORT_URL,
        )
        logger.exception(msg)
        diagnostics.append(diag)
        raise PipelineFatalError(msg, f"failed-to-parse-{error_prefix}-spec", diagnostics)

    return spec_text, spec_content


def convert_spec_if_needed(
    spec_content: dict,
    spec_text: str,
    source_file: Path,
    diagnostics: list[JenticDiagnostic],
    file_manager,
    write_file: bool = True,
) -> tuple[dict, str, bool]:
    """Convert spec to OAS3 if needed (from Swagger2 or Google Discovery).

    Args:
        spec_content: The spec content to check
        source_file: Path to the source file
        diagnostics: List to append diagnostics to
        file_manager: PipelineFileManager for saving converted files

    Returns:
        Tuple of (spec_content, spec_text, was_converted)

    Raises:
        PipelineFatalError: If conversion is needed but fails critically
    """
    logger.info("Checking if conversion is needed...")

    # Check for Swagger 2
    if is_swagger_2(spec_content):
        diagnostics.append(
            build_diagnostic(
                "Imported spec is Swagger 2",
                "imported-spec-is-swagger-2",
                "converter",
                DiagnosticSeverity.Information,
                target=DiagnosticTarget.IMPORTED_SPEC,
            )
        )
        source_text = source_file.read_text(encoding="utf-8")
        if write_file:
            # Save original Swagger2
            swagger_path = file_manager.get_path("source_swagger")
            swagger_path.write_text(source_file.read_text(encoding="utf-8"), encoding="utf-8")

        logger.info("Converting Swagger2 → OAS3 …")
        with tempfile.NamedTemporaryFile(mode="w+", encoding="utf-8", suffix=".conv") as tf:
            tf.write(source_text)
            tf.flush()
            tf_path = Path(tf.name)
            converted_path = convert_to_openapi3(str(tf_path), "swagger_2")

            if converted_path:
                logger.info("Swagger2 conversion completed")
                return _reload_converted_spec(Path(converted_path), diagnostics)
            else:
                logger.warning("Swagger2 conversion failed, proceeding with original file")
                diagnostics.append(
                    build_diagnostic(
                        "Failed to convert Swagger2 to OAS3",
                        "failed-to-convert-swagger-2-to-oas3",
                        "converter",
                    )
                )
                return spec_content, json_dumps(spec_content, 2), False

    # Check for Google Discovery format
    elif is_google_format(spec_content):
        diagnostics.append(
            build_diagnostic(
                "Imported spec is Google Discovery",
                "imported-spec-is-google-discovery",
                "converter",
                DiagnosticSeverity.Information,
                target=DiagnosticTarget.IMPORTED_SPEC,
            )
        )
        source_text = source_file.read_text(encoding="utf-8")
        if write_file:
            # Save original Google format
            google_path = file_manager.get_path("source_google")
            google_path.write_text(source_file.read_text(encoding="utf-8"), encoding="utf-8")

        logger.info("Converting Google Discovery → OAS3 …")
        with tempfile.NamedTemporaryFile(mode="w+", encoding="utf-8", suffix=".conv") as tf:
            tf.write(source_text)
            tf.flush()
            tf_path = Path(tf.name)
            converted_path = convert_to_openapi3(str(tf_path), "google")

            if converted_path:
                logger.info("Google conversion completed")
                return _reload_converted_spec(Path(converted_path), diagnostics)
            else:
                logger.warning("Google conversion failed, proceeding with original file")
                diagnostics.append(
                    build_diagnostic(
                        "Failed to convert Google to OAS3",
                        "failed-to-convert-google-to-oas3",
                        "converter",
                    )
                )
                return spec_content, json_dumps(spec_content, 2), False

    logger.info("No conversion needed")
    return spec_content, spec_text, False


def _reload_converted_spec(
    converted_path: Path, diagnostics: list[JenticDiagnostic]
) -> tuple[dict, str, bool]:
    """Reload and parse a converted spec.

    Args:
        converted_path: Path to the converted spec file
        diagnostics: List to append diagnostics to

    Returns:
        Tuple of (spec_content, spec_text, True)

    Raises:
        PipelineFatalError: If reloading fails
    """

    try:
        spec_text, spec_content = load_and_parse_spec(
            str(converted_path.as_uri()),
            30,  # Default timeout
            30,  # Default timeout
            diagnostics,
            "converted",
        )
        return spec_content, spec_text, True
    except PipelineFatalError:
        # Re-raise with better context
        raise


def reorder_spec(
    spec_content: dict,
    diagnostics: list[JenticDiagnostic],
    target: DiagnosticTarget = DiagnosticTarget.IMPORTED_SPEC,
) -> dict:
    """Reorder a spec for consistent structure.

    Args:
        spec_content: The spec to reorder
        diagnostics: List to append diagnostics to
        target: Diagnostic target

    Returns:
        Reordered spec (or original if reordering fails)
    """

    logger.debug("reordering spec")
    try:
        return reorder_openapi_spec(spec_content)
    except Exception as e:
        logger.exception(f"Failed to reorder spec: {e}")
        diagnostics.append(
            build_diagnostic(
                f"Failed to reorder: {e}",
                "failed-to-reorder-spec",
                "loader",
                DiagnosticSeverity.Warning,
                target=target,
            )
        )
        return spec_content


@overload
def diff_dicts_struct(
    a: dict | list,
    b: dict | list,
    *,
    return_type: Literal["json"],
    ignore_order: bool = True,
    significant_digits: int | None = None,
    exclude_paths: set[str] | None = None,
) -> str: ...


@overload
def diff_dicts_struct(
    a: dict | list,
    b: dict | list,
    *,
    return_type: Literal["dict"] = ...,
    ignore_order: bool = True,
    significant_digits: int | None = None,
    exclude_paths: set[str] | None = None,
) -> dict: ...


def diff_dicts_struct(
    a: dict | list,
    b: dict | list,
    *,
    return_type: Literal["json", "dict"] = "dict",
    ignore_order: bool = True,
    significant_digits: int | None = None,
    exclude_paths: set[str] | None = None,
) -> dict | str:
    """Return a DeepDiff result comparing two dicts/lists."""
    diff = DeepDiff(
        a,
        b,
        ignore_order=ignore_order,
        significant_digits=significant_digits,
        exclude_paths=exclude_paths or set(),
        view="tree",
    )

    if return_type == "dict":
        return diff.to_dict()
    return diff.to_json()
