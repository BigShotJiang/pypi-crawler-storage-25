"""Rebuild root apis.json and scores.json from all API specs in a local repository clone."""

from __future__ import annotations

import copy
import json
from datetime import date
from pathlib import Path
from urllib.parse import urlparse

from jentic.apitools.common.utils.logging import get_module_logger


logger = get_module_logger(__name__)


def _parse_github_repo(github_repo_url: str) -> tuple[str, str]:
    """Extract (owner, repo_name) from a GitHub URL.

    Expects a repository root URL of the form:
      https://github.com/<owner>/<repo>[.git]
    """
    parsed = urlparse(github_repo_url)
    path_parts = [p for p in parsed.path.strip("/").split("/") if p]
    if len(path_parts) != 2:
        raise ValueError(
            f"Cannot parse owner/repo from URL (expected GitHub repository root URL): "
            f"{github_repo_url}"
        )
    owner, repo = path_parts[0], path_parts[1]
    if repo.endswith(".git"):
        repo = repo[:-4]
    return owner, repo


# Static "general" sections of the root apis.json (everything except `modified` and `include`)
_ROOT_APIS_JSON_TEMPLATE: dict = {
    "aid": "apis.json:jentic-public-apis",
    "name": "Jentic Public APIs",
    "type": "Collection",
    "description": "AI-ready catalog of public APIs.",
    "url": "https://github.com/jentic/jentic-public-apis/blob/main/apis/openapi/apis.json",
    "tags": ["APIs", "catalog", "OpenAPI", "OAK", "Jentic"],
    "created": "2025-12-17",
    "specificationVersion": "0.20",
    "maintainers": [
        {
            "FN": "Jentic",
            "x-github": "jentic",
            "url": "https://github.com/jentic",
        }
    ],
    "common": [
        {
            "type": "GitHubRepo",
            "url": "https://github.com/jentic/jentic-public-apis",
        },
        {
            "type": "Documentation",
            "name": "Jentic Docs",
            "url": "https://docs.jentic.com/",
        },
    ],
}


def rebuild_scores_json(
    local_repo_path: Path,
    *,
    base_dir: str | Path = "apis/openapi",
) -> dict[str, float]:
    """Rebuild scores.json by reading summary.score from all scorecard.json files.

    Walks <local_repo_path>/<base_dir>/*/*/*/scorecard.json, extracts
    summary.score from each, and writes a sorted JSON mapping of
    <vendor>/<api>/<version> -> score to <base_dir>/scores.json.

    Returns the scores dict that was written.
    """
    base_path = local_repo_path / base_dir
    scores: dict[str, float] = {}

    for scorecard_file in sorted(base_path.glob("*/*/*/scorecard.json")):
        rel = scorecard_file.relative_to(base_path)
        parts = rel.parts
        if len(parts) != 4:
            continue
        key = f"{parts[0]}/{parts[1]}/{parts[2]}"
        try:
            data = json.loads(scorecard_file.read_text(encoding="utf-8"))
            score = data.get("summary", {}).get("score")
            if score is not None:
                scores[key] = score
            else:
                logger.warning("No summary.score in %s", scorecard_file)
        except Exception:
            logger.warning("Failed to read scorecard %s", scorecard_file)

    scores = dict(sorted(scores.items(), key=lambda item: item[1], reverse=True))

    scores_path = base_path / "scores.json"
    scores_path.write_text(
        json.dumps(scores, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    logger.info("Wrote %d entries to %s", len(scores), scores_path)

    return scores


def rebuild_apis_json(
    local_repo_path: Path,
    *,
    github_repo_url: str = "https://github.com/jentic/jentic-public-apis",
    github_repo_branch: str | None = "main",
    base_dir: str | Path = "apis/openapi",
) -> dict:
    """Rebuild root apis.json from all version-level apis.json files.

    Walks <local_repo_path>/<base_dir>/*/*/*/apis.json, reads each to
    extract the display name, and assembles the root apis.json with an
    include array pointing to all discovered APIs.

    Returns the root apis.json dict that was written.
    """
    base_dir_path = Path(base_dir)
    base_path = local_repo_path / base_dir_path
    branch = github_repo_branch or "main"
    owner, repo_name = _parse_github_repo(github_repo_url)
    base_dir_str = base_dir_path.as_posix()
    raw_base = (
        f"https://raw.githubusercontent.com/{owner}/{repo_name}/refs/heads/{branch}/{base_dir_str}"
    )

    include: list[dict[str, str]] = []

    for apis_file in sorted(base_path.glob("*/*/*/apis.json")):
        rel = apis_file.relative_to(base_path)
        parts = rel.parts
        if len(parts) != 4:
            continue
        vendor, api_name, version = parts[0], parts[1], parts[2]

        # Read display name from version-level apis.json
        display_name = f"{vendor}/{api_name}"
        try:
            data = json.loads(apis_file.read_text(encoding="utf-8"))
            display_name = data.get("name", display_name)
        except Exception:
            logger.warning("Failed to read apis.json %s", apis_file)

        entry_name = f"{vendor}:{api_name}@{version} - {display_name}"
        entry_url = f"{raw_base}/{vendor}/{api_name}/{version}/apis.json"
        include.append({"name": entry_name, "url": entry_url})

    root = copy.deepcopy(_ROOT_APIS_JSON_TEMPLATE)
    root["modified"] = date.today().isoformat()
    root["include"] = include
    root["url"] = raw_base + "/apis.json"
    for entry in root["common"]:
        if entry.get("type") == "GitHubRepo":
            entry["url"] = github_repo_url
            break

    apis_path = base_path / "apis.json"
    apis_path.write_text(
        json.dumps(root, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    logger.info("Wrote %d include entries to %s", len(include), apis_path)

    return root
