"""Pipeline file management utilities for handling OpenAPI spec artifacts.

This module provides utilities for managing file paths, write operations, and spec artifacts
in the OpenAPI import and QA pipelines.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from jentic.apitools.openapi.parser.core import json_dumps
from jentic.apitools.openapi.validator.core import JenticDiagnostic
from lsprotocol.types import DiagnosticSeverity
from pydantic import BaseModel

from jentic.apitools.common.utils.logging import get_module_logger
from jentic.apitools.pipelines.operations import build_diagnostic


logger = get_module_logger(__name__)


class PipelineFileManager:
    """Manages file path resolution for pipeline operations.

    This class encapsulates the directory structure and path generation logic for
    OpenAPI spec processing pipelines (import and QA). It generates paths on-demand
    based on semantic artifact names.

    Example:
        >>> file_mgr = PipelineFileManager(base_dir, "vendor", "api", "1.0", "import")
        >>> input_path = file_mgr.get_path("input_spec")
        >>> bundled_uri = file_mgr.get_path("output_spec", bundled=True, as_uri=True)
    """

    def __init__(
        self,
        base_dir: Path,
        vendor: str,
        api_name: str,
        version: str,
        pipeline_type: Literal["import", "qa"],
    ):
        """Initialize the file manager with directory structure.

        Args:
            base_dir: Base directory for all outputs
            vendor: Vendor/organization name
            api_name: API name
            version: API version
            pipeline_type: Type of pipeline ("import" or "qa")
        """
        self.base_dir = base_dir
        self.vendor = vendor
        self.api_name = api_name
        self.version = version
        self.pipeline_type = pipeline_type

        # Build directory structure
        self.vendor_dir = base_dir / vendor
        self.api_dir = self.vendor_dir / api_name
        self.version_dir = self.api_dir / version
        self.meta_dir = self.version_dir / "meta"
        self.pipeline_dir = self.meta_dir / pipeline_type

        # Source dir only for import pipeline
        if pipeline_type == "import":
            self.source_dir = self.meta_dir / "source"

    def ensure_directories(self) -> None:
        """Create necessary directories for the pipeline."""
        self.pipeline_dir.mkdir(parents=True, exist_ok=True)
        if self.pipeline_type == "import":
            self.source_dir.mkdir(parents=True, exist_ok=True)

    def get_path(self, artifact: str, bundled: bool = False) -> Path:
        """Get path for a specific artifact type.

        Args:
            artifact: Semantic name like "input_spec", "output_spec", "diagnostics", "overlays"
            bundled: Whether this is the bundled version (adds -bundle suffix vs -entry)

        Returns:
            Path object

        Raises:
            ValueError: If artifact name is not recognized
        """
        # QA pipeline always works with bundled specs, so no suffix needed
        if self.pipeline_type == "qa":
            suffix = ""
        else:
            suffix = "-bundle" if bundled else "-entry"

        # Pipeline-specific artifacts (in meta/{import|qa}/)
        if artifact == "input_spec":
            if self.pipeline_type == "qa":
                path = self.pipeline_dir / "input.json"
            else:
                path = self.pipeline_dir / f"input{suffix}.json"
        elif artifact == "output_spec":
            if self.pipeline_type == "qa":
                path = self.pipeline_dir / "output.json"
            else:
                path = self.pipeline_dir / f"output{suffix}.json"
        elif artifact == "diagnostics":
            path = self.pipeline_dir / f"diagnostics-{self.pipeline_type}.json"
        elif artifact == "overlays":
            if self.pipeline_type == "qa":
                path = self.pipeline_dir / "overlays.json"
            else:
                path = self.pipeline_dir / f"overlays{suffix}.json"
        elif artifact == "api_metadata":
            path = self.pipeline_dir / "meta.json"

        # Final artifacts (in version_dir/ or meta/)
        elif artifact == "final_spec":
            path = self.version_dir / "openapi.json"
        elif artifact == "final_overlays":
            path = self.meta_dir / "overlays.json"
        elif artifact == "final_diagnostics":
            path = self.meta_dir / "diagnostics.json"
        elif artifact == "final_api_metadata":
            path = self.meta_dir / "meta.json"
        elif artifact == "apis_json":
            path = self.version_dir / "apis.json"
        elif artifact == "api_meta":
            path = self.api_dir / "meta.json"
        elif artifact == "scorecard":
            path = self.version_dir / "scorecard.json"

        # Source artifacts (import pipeline only)
        elif artifact == "source_pristine":
            if self.pipeline_type != "import":
                raise ValueError(f"Artifact '{artifact}' only available in import pipeline")
            path = self.source_dir / "source.dat"
        elif artifact == "source_swagger":
            if self.pipeline_type != "import":
                raise ValueError(f"Artifact '{artifact}' only available in import pipeline")
            path = self.source_dir / "swagger.json"
        elif artifact == "source_google":
            if self.pipeline_type != "import":
                raise ValueError(f"Artifact '{artifact}' only available in import pipeline")
            path = self.source_dir / "google.json"

        else:
            raise ValueError(f"Unknown artifact: {artifact}")

        return path


def safe_write_json(
    path: Path,
    content: dict | list | str | BaseModel,
    diagnostics: list[JenticDiagnostic],
    fatal: bool = True,
    error_code: str | None = None,
) -> bool:
    """Write json content to file with standardized error handling.

    This helper wraps file write operations with consistent error handling,
    diagnostic creation, and logging.

    Args:
        path: Target file path
        content: Content to write (dict/list will be serialized to JSON, str written directly)
        diagnostics: List to append diagnostic to if write fails
        fatal: Whether failure should be marked as fatal
        error_code: Custom error code (defaults to "write-{filename}-failed")

    Returns:
        True if write succeeded, False if it failed

    """
    try:
        if isinstance(content, BaseModel):
            text = content.model_dump_json(indent=2, exclude_unset=True)
        elif isinstance(content, (dict, list)):
            text = json_dumps(content, 2)
        else:
            text = content
        path.write_text(text, encoding="utf-8")
        logger.debug(f"Successfully wrote {path.name} to {path}")
        return True
    except OSError as e:
        logger.exception(f"Failed to write {path.name}: {e}")

        # Generate error code from filename if not provided
        if error_code is None:
            filename = path.stem.replace("-", "_").replace(".", "_")
            error_code = f"write-{filename}-failed"

        # Build diagnostic with appropriate severity
        diag = build_diagnostic(
            f"Failed to write {path.name}: {e}",
            error_code,
            "fs",
            DiagnosticSeverity.Error if fatal else DiagnosticSeverity.Warning,
        )
        if fatal:
            diag.set_data_field("fatal", True)
        diagnostics.append(diag)
        return False


def safe_read_spec(
    path: Path, diagnostics: list[JenticDiagnostic], fatal: bool = False
) -> str | None:
    """Read spec content from file with error handling.

    Args:
        path: Source file path
        diagnostics: List to append diagnostic to if read fails
        fatal: Whether failure should be marked as fatal

    Returns:
        File content as string, or None if read failed
    """
    try:
        content = path.read_text(encoding="utf-8")
        logger.debug(f"Successfully read {path.name} from {path}")
        return content
    except OSError as e:
        logger.exception(f"Failed to read {path.name}: {e}")

        diag = build_diagnostic(
            f"Failed to read {path.name}: {e}",
            f"read-{path.stem}-failed",
            "fs",
            DiagnosticSeverity.Error if fatal else DiagnosticSeverity.Warning,
        )
        if fatal:
            diag.set_data_field("fatal", True)
        diagnostics.append(diag)
        return None


@dataclass
class SpecArtifact:
    """Represents a spec artifact with content and optional file path.

    This class encapsulates an OpenAPI spec's content, text representation,
    and file system location. It provides lazy text generation and convenient
    methods for saving and getting URIs for tool integration.

    Attributes:
        content: The parsed spec as a dictionary
        text: The JSON text representation (generated lazily if needed)
        path: The file system path where this artifact is/will be saved

    Example:
        >>> artifact = SpecArtifact(spec_dict)
        >>> artifact.save(file_mgr.get_path("output_spec"), diagnostics)
        >>> validator.validate(artifact.get_uri())
    """

    content: dict
    text: str | None = None
    path: Path | None = None

    def get_text(self) -> str:
        """Get JSON text representation, generating if needed.

        Returns:
            The spec serialized as JSON with 2-space indentation
        """
        if self.text is None:
            self.text = json_dumps(self.content, 2)
        return self.text

    def get_uri(self) -> str:
        """Get file:// URI for passing to tools.

        Returns:
            The file URI (e.g., "file:///path/to/spec.json")

        Raises:
            ValueError: If artifact hasn't been saved to a file yet
        """
        if not self.path:
            raise ValueError("Artifact not saved to file - call save() first")
        return str(self.path.as_uri())

    def save(self, path: Path, diagnostics: list[JenticDiagnostic], fatal: bool = True) -> bool:
        """Save artifact to file with error handling.

        Args:
            path: Target file path
            diagnostics: List to append diagnostic to if save fails
            fatal: Whether failure should be marked as fatal

        Returns:
            True if save succeeded, False if it failed
        """
        if safe_write_json(path, self.get_text(), diagnostics, fatal=fatal):
            self.path = path
            return True
        return False

    def update_content(self, new_content: dict, new_text: str | None = None) -> None:
        """Update the artifact's content and optionally text.

        Args:
            new_content: New spec dictionary
            new_text: New text representation (will be regenerated if None)
        """
        self.content = new_content
        self.text = new_text
