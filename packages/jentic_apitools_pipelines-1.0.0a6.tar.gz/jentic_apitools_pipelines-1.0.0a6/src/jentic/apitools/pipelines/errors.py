"""Custom exception types for the pipeline sub-package."""

from __future__ import annotations


__all__: list[str] = [
    "PipelineError",
    "ConversionError",
    "ProcessError",
]


class PipelineError(Exception):
    """Base class for pipeline errors."""


class ConversionError(PipelineError):
    """Raised when conversion fails during the pipeline run."""


class ProcessError(PipelineError):
    """Raised when processing (validation/repair) fails."""
