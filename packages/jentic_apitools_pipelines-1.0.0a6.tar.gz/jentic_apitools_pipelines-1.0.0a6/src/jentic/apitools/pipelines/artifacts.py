"""Artifact and metadata builders for pipeline outputs."""

from __future__ import annotations

import hashlib
import json
import os
from collections import Counter
from collections.abc import Mapping
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any, List

import datadog
from jentic.apitools.openapi.parser.core import OpenAPIParser
from jentic.apitools.openapi.validator.core import JenticDiagnostic
from lsprotocol.types import DiagnosticSeverity

from jentic.apitools.common.models import OASRequestMeta
from jentic.apitools.common.utils.logging import get_module_logger
from jentic.apitools.pipelines.operations import diff_dicts_struct


logger = get_module_logger(__name__)


def log_scoring_results(job_id: str, scorecard_data: dict, source_url: str) -> None:
    """Log scoring results with job context."""
    try:
        if not scorecard_data:
            logger.debug(f"No scorecard data provided for job {job_id}")
            return

        summary = scorecard_data.get("summary", {})
        overall_score = summary.get("score")

        if overall_score is None:
            logger.warning(f"No overall score found in scorecard for job {job_id}")
            return

        logger.info(
            "Scoring completed",
            extra={"job_id": job_id, "overall_score": overall_score, "source_url": source_url},
        )

        dimensions = summary.get("dimensions", [])
        for dimension in dimensions:
            dimension_kind = dimension.get("kind", "UNKNOWN")
            dimension_score = dimension.get("score", None)
            logger.info(
                "Dimension score",
                extra={
                    "job_id": job_id,
                    "dimension": dimension_kind,
                    "dimension_score": dimension_score,
                },
            )
            try:
                datadog.statsd.gauge(  # type: ignore[reportPrivateImportUsage]
                    "api_scoring.dimension_score",
                    dimension_score,
                    tags=[f"dimension:{dimension_kind}"],
                )
            except Exception:
                logger.debug("Failed to send Datadog metric for dimension %s", dimension_kind)

    except Exception as e:
        logger.warning(f"Failed to log scoring results for job {job_id}: {e}")


def get_first_server_url(spec: dict) -> str | None:
    """Extract the first server URL from an OpenAPI spec."""
    servers = spec.get("servers")
    if servers and isinstance(servers, list) and len(servers) > 0:
        first_server = servers[0]
        if isinstance(first_server, dict):
            return first_server.get("url")
    return None


def extract_version(spec: dict) -> str | None:
    """Extract the version from an OpenAPI spec."""
    try:
        if "info" in spec and "version" in spec["info"]:
            return str(spec["info"]["version"])
    except Exception:
        pass
    return None


def write_repair_log(
    repair_actions: List[dict],
    target_dir: str | Path,
    file_name: str = "repair_log.txt",
) -> None:
    """Emit a human-readable log of repair_actions (if any)."""
    if not repair_actions:
        return
    repair_log_path = os.path.join(str(target_dir), file_name)
    with open(repair_log_path, "w", encoding="utf-8") as log_f:
        log_f.write("Repair Log\n")
        log_f.write(f"Processed Timestamp: {datetime.now().isoformat()}\n\n")

        for action in repair_actions:
            log_f.write("-" * 50 + "\n")
            timestamp = action.get("timestamp", "N/A")
            issue_obj = action.get("issue")

            issue_code = getattr(issue_obj, "code", "N/A") if issue_obj else "N/A"
            issue_message = getattr(issue_obj, "message", "N/A") if issue_obj else "N/A"
            level_attr = getattr(issue_obj, "level", "N/A") if issue_obj else "N/A"
            issue_severity = (
                level_attr.upper()
                if isinstance(level_attr, str)
                else getattr(level_attr, "name", str(level_attr)).upper()
            )
            location = getattr(issue_obj, "location", None)
            issue_location_str = (
                (location.json_path if hasattr(location, "json_path") else str(location))
                if location
                else "N/A"
            )

            action_taken = action.get("action_taken", "N/A")
            fixed_status = action.get("fixed", "N/A")
            source = action.get("source", "N/A")
            issue_source = action.get("issue_source", "N/A")
            issue_target = action.get("issue_target", "N/A")

            log_f.write(
                f"Time: {timestamp}\nIssue: {issue_code} | {issue_severity}\n"
                f"Message: {issue_message}\nLocation: {issue_location_str}\n"
                f"Fixed: {fixed_status}\n"
                f"Source: {source}\n"
                f"Issue Source: {issue_source}\n"
                f"Issue Target: {issue_target}\n"
                f"Action: {action_taken}\n"
            )


def build_apis_json(
    oas_request_meta: OASRequestMeta,
    spec: dict,
    vendor: str,
    api_name: str,
    version: str,
    artifacts_root: Path,
    bundle_path: Path | None,
) -> dict[str, Any]:
    """Build APIs.json metadata for an API."""
    if not bundle_path:
        return {"apis": []}
    apis = []

    resolved_root_path = (
        f"{str(artifacts_root)}/{vendor}/{api_name}/{version}" if artifacts_root else None
    )
    resolved_bundle_path = str(bundle_path) if bundle_path else None
    resolved_apisjson_url = str(bundle_path.parent / "apis.json")
    resolved_root_path_ui = (
        f"{oas_request_meta.canonical_artifacts_base_url_ui}/{vendor}/{api_name}/{version}"
        if oas_request_meta.canonical_artifacts_base_url_ui
        else resolved_root_path
    )
    if oas_request_meta.canonical_artifacts_base_url:
        resolved_root_path = (
            f"{oas_request_meta.canonical_artifacts_base_url}/{vendor}/{api_name}/{version}"
        )
        resolved_apisjson_url = f"{resolved_root_path}/apis.json" if bundle_path else None
        resolved_bundle_path = f"{resolved_root_path}/openapi.json" if bundle_path else None
        resolved_root_path_ui = (
            f"{oas_request_meta.canonical_artifacts_base_url_ui}/{vendor}/{api_name}/{version}"
        )

    api_description = (
        spec.get("info", {}).get("description") or f"{vendor}/{api_name} version {version}"
    )
    api_summary = spec.get("info", {}).get("title") or api_description
    contact_name = spec.get("info", {}).get("contact", {}).get("name") or None
    contact_email = spec.get("info", {}).get("contact", {}).get("email") or None
    contact_url = spec.get("info", {}).get("contact", {}).get("url") or None
    contact = None
    if contact_name or contact_url or contact_email:
        contact = {}
        contact["FN"] = contact_name if contact_name else contact_email if contact_email else ""
        if contact_email:
            contact["email"] = contact_email
        if contact_url:
            contact["url"] = contact_url

    api_base_url = get_first_server_url(spec)
    aid = f"{vendor}:{api_name}-{version}"

    image_url = (
        spec.get("info", {}).get("x-logo", {}).get("url", "")
        if isinstance(spec.get("info", {}).get("x-logo"), dict)
        else ""
    )
    external_docs_url = (
        spec.get("externalDocs", {}).get("url")
        if isinstance(spec.get("externalDocs"), dict)
        else None
    )
    human_url = external_docs_url or resolved_root_path_ui or ""

    api_entry = {
        "aid": aid,
        "name": api_summary,
        "description": api_description,
        "image": image_url,
        "baseURL": api_base_url or "",
        "humanURL": human_url,
        "version": version,
        "tags": [vendor, api_name],
        "properties": [
            {
                "type": "OpenAPI",
                "name": "OpenAPI definition",
                "url": resolved_bundle_path,
                "mediaType": "application/openapi+json",
            },
            {"type": "GitHubRepo", "url": resolved_root_path_ui},
        ],
    }
    if contact:
        api_entry["contact"] = [contact]
    apis.append(api_entry)
    header = {
        "aid": aid,
        "name": api_summary,
        "type": "Index",
        "description": api_description,
        "url": resolved_apisjson_url,
        "tags": [vendor, api_name],
        "created": date.today().isoformat(),
        "modified": date.today().isoformat(),
        "specificationVersion": "0.19",
        "access": "3rd-Party",
        "maintainers": [{"FN": "Jentic", "X-github": "jentic", "url": "https://github.com/jentic"}],
    }
    out = header
    out["apis"] = apis
    return out


def canonicalize_for_dict_diff(obj: dict | list) -> dict | list:
    """Recursively sort mapping keys. Does NOT reorder lists."""

    def sort_map(obj: dict | list) -> dict | list:
        if isinstance(obj, Mapping):
            return {k: sort_map(obj[k]) for k in sorted(obj.keys(), key=str)}
        if isinstance(obj, list):
            return [sort_map(v) for v in obj]
        return obj

    return sort_map(obj)


def build_vendor_meta_json(vendor: str, api_name: str | None = "main") -> dict[str, Any]:
    normalized = f"{vendor}/{api_name}"
    id_hash = hashlib.md5(normalized.encode()).hexdigest()
    friendly_id = vendor if api_name == "main" else normalized

    return {
        "oak_meta": "1.0.0",
        "api_info": {
            "id": id_hash,
            "format": "openapi",
            "vendor": vendor,
            "api_name": api_name,
            "friendly_id": friendly_id,
        },
    }


def build_api_metadata(
    oas_request_meta: OASRequestMeta,
    source_url: str,
    vendor: str,
    api_name: str,
    version: str,
    retrieved_at: str,
    oas_version: str,
    artifacts_root: Path,
    spec_path: Path,
    bundle_path: Path | None,
    original_path: Path | None,
    diagnostics: List[JenticDiagnostic],
    bundle_diagnostics: List[JenticDiagnostic],
    fatalError: bool = False,
    importing: bool = True,
    existing_api_metadata: dict | None = None,
) -> dict[str, Any]:
    """Build API metadata dictionary."""
    source_keywords = ["repair", "validator", "loader", "parser", "comparator", "converter", "fs"]

    def get_source_matches(diag):
        source = diag.source or ""
        for keyword in source_keywords:
            if keyword in source:
                yield keyword

    severity_counts = Counter(diag.severity for diag in diagnostics)
    source_counts = Counter(keyword for diag in diagnostics for keyword in get_source_matches(diag))

    bundle_severity_counts = Counter(diag.severity for diag in bundle_diagnostics)
    bundle_source_counts = Counter(
        keyword for diag in bundle_diagnostics for keyword in get_source_matches(diag)
    )

    relative_refs_count = 0
    absolute_refs_count = 0
    resolved_original_url = None
    has_fatal_errors = False
    rewritten_invalid_refs = False
    persistent_invalid_refs = False

    for diag in diagnostics:
        if diag.code == "found-relative-references" and hasattr(diag, "data") and diag.data:
            try:
                relative_refs_count = int(diag.data.get("relativeRefsCount", 0))
            except (ValueError, TypeError):
                relative_refs_count = 0

        if diag.code == "found-absolute-http-references" and hasattr(diag, "data") and diag.data:
            try:
                absolute_refs_count = int(diag.data.get("absoluteRefsCount", 0))
            except (ValueError, TypeError):
                absolute_refs_count = 0

        if diag.code == "rewriting-relative-refs":
            rewritten_invalid_refs = True

        if diag.code == "persistent-invalid-refs":
            persistent_invalid_refs = True

        if hasattr(diag, "data") and diag.data and diag.data.get("fatal"):
            has_fatal_errors = True

    bundle_exists = True if bundle_path and bundle_path.exists() else False
    bundle_content = {}
    original_content = {}
    spec_content = {}

    try:
        if bundle_exists:
            assert bundle_path is not None
            bundle_content = OpenAPIParser().parse(bundle_path.as_uri())
    except Exception:
        pass

    bundleSame = False
    originalSame = False

    if importing:
        if spec_path and spec_path.exists():
            spec_content = OpenAPIParser().parse(spec_path.as_uri())
        try:
            if original_path and original_path.exists():
                original_content = OpenAPIParser().parse(original_path.as_uri())
        except Exception:
            pass

        spec_canonical = canonicalize_for_dict_diff(spec_content)
        if bundle_exists:
            if bundle_content.get("components") == {}:
                bundle_content.pop("components", None)
            bundle_canonical = canonicalize_for_dict_diff(bundle_content)
            original_canonical = canonicalize_for_dict_diff(original_content)
            bundleSame = True
            originalSame = True
            try:
                if bundle_canonical != spec_canonical:
                    diff = diff_dicts_struct(
                        spec_canonical, bundle_canonical, ignore_order=True, return_type="json"
                    )
                    if diff and diff.strip() != "{}" and diff.strip() != "[]":
                        logger.debug(f"Bundled spec differs from imported spec: {diff}")
                        bundleSame = False
                if bundle_canonical != original_canonical:
                    diff = diff_dicts_struct(
                        original_canonical, bundle_canonical, ignore_order=True, return_type="json"
                    )
                    if diff and diff.strip() != "{}" and diff.strip() != "[]":
                        logger.debug(f"Bundled spec differs from original spec: {diff}")
                        originalSame = False
            except Exception:  # keep diff errors non-fatal
                pass

        try:
            resolved_original_url = spec_content.get("info", {}).get("x-jentic-source-url")
        except (json.JSONDecodeError, OSError, KeyError):
            pass

    status = "failed" if (has_fatal_errors or bundle_path is None or fatalError) else "staging"
    current_timestamp = datetime.now(timezone.utc).replace(microsecond=0).isoformat()

    resolved_root_path = (
        f"{str(artifacts_root)}/{vendor}/{api_name}/{version}" if artifacts_root else None
    )
    resolved_bundle_path = str(bundle_path) if bundle_path else None
    resolved_root_path_ui = (
        f"{oas_request_meta.canonical_artifacts_base_url_ui}/{vendor}/{api_name}/{version}"
        if oas_request_meta.canonical_artifacts_base_url_ui
        else resolved_root_path
    )
    if oas_request_meta.canonical_artifacts_base_url:
        resolved_root_path = (
            f"{oas_request_meta.canonical_artifacts_base_url}/{vendor}/{api_name}/{version}"
        )
        resolved_root_path_ui = (
            f"{oas_request_meta.canonical_artifacts_base_url_ui}/{vendor}/{api_name}/{version}"
        )
        resolved_bundle_path = f"{resolved_root_path}/openapi.json" if bundle_path else None

    if source_url and source_url.startswith("file://"):
        resolved_source_url = (
            oas_request_meta.canonical_source_url
            if oas_request_meta.canonical_source_url
            else "content://uploaded"
        )
    else:
        resolved_source_url = (
            oas_request_meta.canonical_source_url
            if oas_request_meta.canonical_source_url
            else source_url
        )

    license_name = None
    if bundle_exists:
        license_name = (
            bundle_content.get("info", {}).get("license", {}).get("name")
            or bundle_content.get("info", {}).get("license", {}).get("identifier")
            or None
        )

    aid = f"urn:oak:{vendor}:{api_name}:{version}"

    if importing:
        return {
            "$schema": "https://jentic.com/schemas/api-meta.schema.json",
            "id": aid,
            "status": status,
            "bundled": bundle_exists,
            "info": {
                "vendor": vendor,
                "apiName": api_name,
                "version": version,
                "oasVersion": oas_version or "3.0.0",
                "license": license_name,
            },
            "artifacts": {
                "base": resolved_root_path_ui,
                "entry": resolved_bundle_path,
            },
            "meta": {
                "timestamps": {"added": current_timestamp, "updated": current_timestamp},
                "diagnostics": {
                    "severity": {
                        "errors": bundle_severity_counts[DiagnosticSeverity.Error],
                        "warnings": bundle_severity_counts[DiagnosticSeverity.Warning],
                        "info": bundle_severity_counts[DiagnosticSeverity.Information],
                    },
                    "source": {
                        keyword: bundle_source_counts[keyword] for keyword in source_keywords
                    },
                },
                "references": {"relative": relative_refs_count, "absolute": absolute_refs_count},
                "import": {
                    "source": {
                        "url": resolved_source_url,
                        "apiId": oas_request_meta.api_id if oas_request_meta.api_id else "",
                        "apiVersionId": oas_request_meta.api_version_id
                        if oas_request_meta.api_version_id
                        else "",
                        "resolvedOriginalUrl": resolved_original_url,
                        "retrievedAt": retrieved_at,
                    },
                    "diagnostics": {
                        "severity": {
                            "errors": severity_counts[DiagnosticSeverity.Error],
                            "warnings": severity_counts[DiagnosticSeverity.Warning],
                            "info": severity_counts[DiagnosticSeverity.Information],
                        },
                        "source": {keyword: source_counts[keyword] for keyword in source_keywords},
                        "persistentInvalidRefs": persistent_invalid_refs,
                        "rewrittenInvalidRefs": rewritten_invalid_refs,
                    },
                    "bundleSameAsRoot": bundleSame,
                    "bundleSameAsImported": originalSame,
                },
            },
        }
    else:
        api_metadata = {
            "$schema": "https://jentic.com/schemas/api-meta.schema.json",
            "id": aid,
            "status": status,
            "info": {
                "vendor": vendor,
                "apiName": api_name,
                "version": version,
                "oasVersion": oas_version or "3.0.0",
                "license": license_name,
            },
            "artifacts": {"base": resolved_root_path_ui, "entry": resolved_bundle_path},
            "meta": {
                "timestamps": {"added": current_timestamp, "updated": current_timestamp},
                "diagnostics": {
                    "severity": {
                        "errors": bundle_severity_counts[DiagnosticSeverity.Error],
                        "warnings": bundle_severity_counts[DiagnosticSeverity.Warning],
                        "info": bundle_severity_counts[DiagnosticSeverity.Information],
                    },
                    "source": {
                        keyword: bundle_source_counts[keyword] for keyword in source_keywords
                    },
                },
                "references": {"relative": relative_refs_count, "absolute": absolute_refs_count},
                "qa": {
                    "diagnostics": {
                        "severity": {
                            "errors": severity_counts[DiagnosticSeverity.Error],
                            "warnings": severity_counts[DiagnosticSeverity.Warning],
                            "info": severity_counts[DiagnosticSeverity.Information],
                        },
                        "source": {keyword: source_counts[keyword] for keyword in source_keywords},
                        "persistentInvalidRefs": persistent_invalid_refs,
                        "rewrittenInvalidRefs": rewritten_invalid_refs,
                    }
                },
            },
        }
        if existing_api_metadata:
            api_metadata["meta"]["import"] = existing_api_metadata["meta"]["import"]
        return api_metadata
