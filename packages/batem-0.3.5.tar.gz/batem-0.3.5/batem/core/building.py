"""Building model construction and simulation orchestration utilities.

.. module:: batem.core.building

This module provides the high-level orchestration logic required to build a
BATEM building model from contextual data, generate thermal networks, configure
HVAC controllers, and run coupled simulations. It binds together solar,
thermal, control, and model-making subsystems to offer a cohesive workflow.

The dataclasses defined here use reStructuredText field lists so that automated
documentation can surface every parameter accepted by the simulation pipeline.

:Author: stephane.ploix@grenoble-inp.fr
:License: GNU General Public License v3.0
Common geometry/view primitives (window/floor data classes and PyVista views)
are imported from :mod:`batem.core.building` to avoid duplication with
``batem.core.basicbuilding``.
"""
from functools import cached_property
from datetime import datetime
from pyvista.core.pointset import PolyData
from dataclasses import dataclass, field
from pyvista.plotting.plotter import Plotter
from xhtml2pdf import pisa
from math import sqrt, atan2, radians, cos, sin, degrees, isfinite
import pyvista as pv
import os
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import types
import prettytable
from typing import Any, TypeAlias

from batem.core.data import DataProvider, Bindings
from batem.core.control import HeatingPeriod, CoolingPeriod, OccupancyProfile, SignalGenerator, TemperatureController, Simulation, TemperatureSetpointPort, HVACcontinuousModePort, LongAbsencePeriod
from batem.core.inhabitants import Preference
from batem.core.model import ModelMaker
from batem.core.components import Side, Composition
from batem.core.library import SIDE_TYPES, SLOPES
from batem.core.solar import SolarModel, SolarSystem, Collector, SideMask, Mask, StackedMask
from batem.core.statemodel import StateModel
from batem.core.utils import FilePathBuilder


Vertices: TypeAlias = list[tuple[float, float]]
Vertex: TypeAlias = tuple[float, float]

pv.set_jupyter_backend('html')
# shared geometry/view data classes are imported from batem.core.building


def footprint_from_rectangular_building(east_west_length: float, north_south_length: float) -> Vertices:
    return [(-east_west_length / 2, -north_south_length / 2), (east_west_length / 2, -north_south_length / 2), (east_west_length / 2, north_south_length / 2), (-east_west_length / 2, north_south_length / 2)]


def rotate(footprint: Vertices, angle_deg: float) -> Vertices:
    """Rotate footprint points around origin by ``angle_deg`` degrees."""
    if abs(angle_deg) <= 1e-12:
        return list(footprint)
    angle_rad = radians(angle_deg)
    cos_a = cos(angle_rad)
    sin_a = sin(angle_rad)
    return [(cos_a * x - sin_a * y, sin_a * x + cos_a * y) for x, y in footprint]


def shoelace_area_m2(closed_footprint: Vertices) -> float:
    """Signed-area formula for a closed vertex ring (last point may repeat the first)."""
    n = len(closed_footprint)
    twice_area = 0.0
    for i in range(n):
        x1, y1 = closed_footprint[i]
        x2, y2 = closed_footprint[(i + 1) % n]
        twice_area += x1 * y2 - x2 * y1
    return abs(twice_area) / 2.0


def edge_length_m(vertex_a: Vertex, vertex_b: Vertex) -> float:
    return sqrt((vertex_b[0] - vertex_a[0]) ** 2 + (vertex_b[1] - vertex_a[1]) ** 2)


def _rotate_vector_around_axis(vector: np.ndarray, axis_unit: np.ndarray, angle_rad: float) -> np.ndarray:
    """Apply Rodrigues' rotation of ``vector`` around a unit axis ``axis_unit``."""
    c = cos(angle_rad)
    s = sin(angle_rad)
    v = np.asarray(vector, dtype=float)
    k = np.asarray(axis_unit, dtype=float)
    return v * c + np.cross(k, v) * s + k * float(np.dot(k, v)) * (1.0 - c)


@dataclass
class SideMaskData:
    """Obstacle mask in the site plane."""
    x_center: float
    y_center: float
    width: float
    height: float
    elevation: float
    exposure_deg: float
    slope_deg: float = 90.0
    #: Roll of the mask rectangle around the outward normal (degrees), after
    #: the width axis has been fixed in the façade plane (see
    #: ``tangent_x`` / ``tangent_y``). Distant masks in :class:`ContextData` leave
    #: the tangents as NaN and use the exposure-based width from
    #: :class:`~batem.core.solar.SideMask` instead.
    normal_angle_with_south_deg: float = 0.0
    #: Unit tangent of the footprint edge (horizontal, site ``x,y``), when the
    #: mask is tied to a real façade segment; otherwise NaN.
    tangent_x: float = float("nan")
    tangent_y: float = float("nan")
    #: Unit outward normal of the façade in the site horizontal plane; NaN when
    #: not derived from a footprint edge.
    facade_normal_x: float = float("nan")
    facade_normal_y: float = float("nan")


@dataclass
class WindowData:
    floor_index: int
    mid_elevation_m: float
    exposure_deg: float
    surface_m2: float
    solar_factor: float


@dataclass
class FloorData:
    floor_index: int
    mid_elevation_m: float
    hsurface_m2: Vertices
    plain_vsurface_m2: float = 0.0
    windows_data: list[WindowData] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.glazing_vsurface_m2: float = 0.0
        for window_data in self.windows_data:
            self.glazing_vsurface_m2 += window_data.surface_m2


@dataclass
class ContextData:
    """Common context metadata shared by basic and complex building pipelines."""

    latitude_north_deg: float
    longitude_east_deg: float
    location: str
    albedo: float
    pollution: float
    ground_temperature: float
    starting_stringdate: str = None
    ending_stringdate: str = None
    number_of_levels: int = 3
    side_masks: list[SideMaskData] = field(default_factory=list)
    simulated_year: int = 2022


@dataclass
class BuildingData:
    """Physical and operational parameters defining a BATEM building model.

    This dataclass stores the geometry, material compositions, HVAC capacities,
    and occupant-related assumptions used when generating thermal networks and
    control systems.

    :param footprint: Closed or open polygon ``(x, y)`` points in meters (first
        point is repeated when closing the loop).
    :param side_glazing_ratios: One ratio per façade segment after closure, or a single
        value broadcast to all sides. Drives ``ref_glazing_ratio`` … ``left_glazing_ratio``
        (indices ``0 … 3`` modulo ``n_sides``) for the rectangular :class:`ZoneFloor` model.
    :param n_floors: Number of occupied floors (excluding the basement zone).
    :param floor_height: Storey height in metres for regular floors.
    :param base_elevation: Basement height in metres.
    :param z_rotation_angle_deg: Clockwise rotation of the building footprint.
    :param glazing_solar_factor: Solar heat gain coefficient applied to glazing.
    :param shutter_closed_temperature: Outdoor temperature threshold (°C) above which
        shutters are closed and solar gains are set to 0. If None, shutters are never closed.
    :param compositions: Mapping of envelope component names to layer tuples
        ``(material_name, thickness_m)``.
    :param max_heating_power: Maximum heating power available per zone in watts.
    :param max_cooling_power: Maximum cooling power available per zone in watts.
    :param body_metabolism: Basal metabolic heat production per occupant in watts (typically 100W).
    :param occupant_consumption: Additional heat gains per occupant from activities and appliances in watts (typically 150W).
    :param body_PCO2: CO₂ production per occupant in litres per hour.
    :param density_occupants_per_100m2: Occupant density used for gain profiles.
    :param regular_air_renewal_rate_vol_per_hour: Baseline ventilation rate used
        for nominal operation (volumes per hour).
    :param super_air_renewal_rate_vol_per_hour: Ventilation rate applied during
        forced ventilation or free-cooling strategies (volumes per hour).
    :param initial_temperature: Initial temperature (°C) for all thermal states.
    :param low_heating_setpoint: Setback heating setpoint in degrees Celsius.
    :param normal_heating_setpoint: Comfort heating setpoint in degrees Celsius.
    :param high_heating_setpoint: Boost heating setpoint in degrees Celsius.
    :param state_model_order_max: Optional upper bound for model reduction.
    :param periodic_depth_seconds: Maximum penetration depth for periodic inputs.
    :param compositions: mapping with keys such as ``wall``, ``roof``, ``glazing``, ``ground_floor``,
        and optionally ``intermediate_floor``, ``basement_floor``; values are layer tuples
        ``(material_name, thickness_m)``.
    """
    footprint: Vertices
    side_glazing_ratios: list[float]
    n_floors: int
    floor_height: float
    base_elevation: float
    z_rotation_angle_deg: float
    glazing_solar_factor: float
    compositions: dict[str, tuple[tuple[str, float], ...]]
    max_floor_heating_power: float
    max_floor_cooling_power: float
    density_occupants_per_100m2: float
    initial_temperature: float
    low_heating_setpoint: float
    normal_heating_setpoint: float
    normal_cooling_setpoint: float
    regular_air_renewal_rate_vol_per_hour: float
    super_air_renewal_rate_vol_per_hour: float | None = None
    body_metabolism: float = 100.0
    occupant_consumption: float = 150.0
    body_PCO2: float = 7.0
    shutter_closed_temperature: float | None = None  # if not None, shutters are closed and solar gains are set to 0 when outdoor temperature exceeds this threshold
    free_cooling_setpoint_margin: float | None = None
    long_absence_period: tuple[str, str] = ('1/8', '15/8')
    heating_period: tuple[str, str] = ('1/11', '1/5')
    cooling_period: tuple[str, str] = ('1/6', '30/9')
    hvac_cop_heating: float = 3.5
    hvac_cop_cooling: float = 3.5
    regular_ventilation_heat_recovery_efficiency: float = 0.8
    state_model_order_max: int | None = None
    periodic_depth_seconds: int = 3600

    def __post_init__(self) -> None:
        """Close and rotate the footprint, validate inputs, then fill derived geometry."""
        self._close_footprint()
        if self.z_rotation_angle_deg != 0:
            self.footprint = rotate(self.footprint, self.z_rotation_angle_deg)
        polygon: Polygon = Polygon(self.footprint)
        if not polygon.is_simple():
            polygon.footprint_plot(False)
            raise ValueError("Footprint is not forming a simple polygon")
        self.has_basement: bool = self.base_elevation > 0

        self.n_sides = len(self.footprint) - 1
        self._normalize_side_glazing_ratios()
        self._require_composition_keys()
        self._attach_composition_sides()
        self._compute_geometry()
        self._compute_window_local_masks()

    def plot_footprint(self) -> None:
        polygon: Polygon = Polygon(self.footprint)
        polygon.footprint_plot()

    def _close_footprint(self) -> None:
        if self.footprint[0] != self.footprint[-1]:
            self.footprint.append(self.footprint[0])

    def _normalize_side_glazing_ratios(self) -> None:
        ratios: list[float] = self.side_glazing_ratios
        if len(ratios) == 1:
            self.side_glazing_ratios = [float(ratios[0])] * self.n_sides
        elif len(ratios) == self.n_sides:
            self.side_glazing_ratios = [float(x) for x in ratios]
        else:
            raise ValueError(
                f"Number of sides ({self.n_sides}) does not match number of glazing ratios ({len(ratios)})"
            )

    def _require_composition_keys(self) -> None:
        required: list[str] = ['inout_wall', 'inout_roof', 'inout_glazing', 'floor_ground']
        if self.n_floors > 1:
            required.append('lowup_floor')
        if self.base_elevation > 0:
            required.append('basement_ground')
        missing: list[str] = [key for key in required if key not in self.compositions]
        if missing:
            raise ValueError(f"Missing compositions for: {', '.join(missing)}")

    def _attach_composition_sides(self) -> None:
        self.wall: Side = Side(*self.compositions['inout_wall'])
        self.roof: Side = Side(*self.compositions['inout_roof'])
        self.glazing: Side = Side(*self.compositions['inout_glazing'])
        self.ground_floor: Side = Side(*self.compositions['floor_ground'])
        if 'lowup_floor' in self.compositions:
            self.intermediate_floor = Side(*self.compositions['lowup_floor'])
        else:
            self.intermediate_floor = None
        if 'basement_ground' in self.compositions:
            self.basement_floor = Side(*self.compositions['basement_ground'])
        else:
            self.basement_floor = None

    def _compute_geometry(self) -> None:
        if len(self.footprint) < 3:
            raise ValueError(f"Perimeter points must have at least 3 points, got {len(self.footprint)}")

        # Use footprint winding to pick the outward normal consistently:
        # - CCW polygon: outside is on the right of each directed edge
        # - CW polygon:  outside is on the left of each directed edge
        signed_twice_area = 0.0
        for i in range(self.n_sides):
            x1, y1 = self.footprint[i]
            x2, y2 = self.footprint[i + 1]
            signed_twice_area += x1 * y2 - x2 * y1
        is_ccw_polygon = signed_twice_area > 0

        self.sides_length_m: list[float] = []
        self.sides_exposure_deg: list[float] = []
        self.sides_plain_floor_vsurface_m2: list[float] = []
        self.sides_glazing_floor_vsurface_m2: list[float] = []
        self.sides_plain_basement_vsurface_m2: list[float] = []
        self.sides_mask: list[SideMaskData] = []
        self.floors_data: list[FloorData] = []

        self.footprint_surface_m2: float = shoelace_area_m2(self.footprint)
        self.building_height_m: float = self.base_elevation + self.floor_height * self.n_floors

        for side_id in range(self.n_sides):
            x1, y1 = self.footprint[side_id]
            x2, y2 = self.footprint[side_id + 1]
            dx, dy = x2 - x1, y2 - y1
            side_length_m: float = edge_length_m((x1, y1), (x2, y2))
            if is_ccw_polygon:
                normal_x, normal_y = dy, -dx
            else:
                normal_x, normal_y = -dy, dx

            # Convert normal from math frame (0°=east, CCW+) to BATEM solar frame:
            # 0°=south, +90°=west, -90°=east.
            normal_angle_math_deg = degrees(atan2(normal_y, normal_x))
            exposure_deg = -normal_angle_math_deg - 90.0
            exposure_deg = ((exposure_deg + 180.0) % 360.0) - 180.0
            glazing_ratio: float = self.side_glazing_ratios[side_id]

            self.sides_length_m.append(side_length_m)
            self.sides_exposure_deg.append(exposure_deg)
            self.sides_plain_floor_vsurface_m2.append(side_length_m * self.floor_height * (1.0 - glazing_ratio))
            self.sides_glazing_floor_vsurface_m2.append(side_length_m * self.floor_height * glazing_ratio)
            self.sides_plain_basement_vsurface_m2.append(side_length_m * self.base_elevation)
            tangent_x = dx / side_length_m
            tangent_y = dy / side_length_m
            facade_normal_x = normal_x / side_length_m
            facade_normal_y = normal_y / side_length_m
            self.sides_mask.append(
                SideMaskData(
                    x_center=(x1 + x2) / 2.0,
                    y_center=(y1 + y2) / 2.0,
                    width=side_length_m,
                    height=self.building_height_m,
                    elevation=0.0,
                    exposure_deg=exposure_deg,
                    normal_angle_with_south_deg=0.0,
                    tangent_x=tangent_x,
                    tangent_y=tangent_y,
                    facade_normal_x=facade_normal_x,
                    facade_normal_y=facade_normal_y,
                )
            )

        self.perimeter_m: float = sum(
            edge_length_m(self.footprint[i], self.footprint[i + 1]) for i in range(self.n_sides)
        )
        self.plain_floor_vsurface_m2: float = sum(self.sides_plain_floor_vsurface_m2)
        self.glazing_floor_vsurface_m2: float = sum(self.sides_glazing_floor_vsurface_m2)
        self.plain_basement_vsurface_m2: float = sum(self.sides_plain_basement_vsurface_m2)

        # floor_horizontal_outline: Vertices = list(self.footprint[:-1])
        for floor_index in range(0, self.n_floors):
            mid_floor_elevation_m: float = self.base_elevation + (floor_index + 0.5) * self.floor_height
            floor_windows: list[WindowData] = [
                WindowData(
                    floor_index=floor_index,
                    mid_elevation_m=mid_floor_elevation_m,
                    exposure_deg=self.sides_exposure_deg[side_index],
                    surface_m2=glazing_ratio * side_length_m * self.floor_height,
                    solar_factor=self.glazing_solar_factor,
                )
                for side_index, (side_length, glazing_ratio) in enumerate(
                    zip(self.sides_length_m, self.side_glazing_ratios)
                )
            ]
            self.floors_data.append(
                FloorData(
                    floor_index=floor_index,
                    mid_elevation_m=mid_floor_elevation_m,
                    hsurface_m2=self.footprint_surface_m2,
                    plain_vsurface_m2=self.plain_floor_vsurface_m2,
                    windows_data=floor_windows,
                )
            )

    def _compute_window_local_masks(self) -> None:
        """Build local self-obstruction masks for façade collectors.

        The baseline collector already applies the façade visibility band
        (``exposure_deg - 90`` to ``exposure_deg + 90``). This method adds
        *near-field* masks produced by the building itself in concave/re-entrant
        configurations.

        Strategy:
        - Detect reflex vertices in the footprint and derive re-entrant sides.
        - Only those sides receive local self-obstruction masks.
        - For each re-entrant side pair, build several ``SideMask`` instances
          from multiple observer points along the window edge (0, 25, 50, 75,
          100% of segment length).
        - Use the opposite wall face (inner face, ``exposure + 180°``) so
          masking models inside-courtyard blocking rather than the external face.

        The resulting list is later combined with ``StackedMask`` in
        ``RegularZone.__init__``; intersecting masks across observer samples
        yields a conservative obstruction envelope and avoids non-physical
        angular holes for polygonal façades.
        """
        signed_twice_area = 0.0
        for k in range(self.n_sides):
            x1, y1 = self.footprint[k]
            x2, y2 = self.footprint[k + 1]
            signed_twice_area += x1 * y2 - x2 * y1
        is_ccw_polygon = signed_twice_area > 0

        reflex_vertices: set[int] = set()
        for k in range(self.n_sides):
            prev_x, prev_y = self.footprint[(k - 1) % self.n_sides]
            curr_x, curr_y = self.footprint[k]
            next_x, next_y = self.footprint[(k + 1) % self.n_sides]
            ux, uy = curr_x - prev_x, curr_y - prev_y
            vx, vy = next_x - curr_x, next_y - curr_y
            cross_z = ux * vy - uy * vx
            if (is_ccw_polygon and cross_z < 0) or ((not is_ccw_polygon) and cross_z > 0):
                reflex_vertices.add(k)

        reentrant_sides: set[int] = set()
        for vertex_index in reflex_vertices:
            reentrant_sides.add((vertex_index - 1) % self.n_sides)
            reentrant_sides.add(vertex_index % self.n_sides)

        self.window_local_masks: list[list[Mask]] = []
        for i in range(self.n_sides):
            local_masks: list[Mask] = []
            # Only façades participating in a re-entrant corner can receive
            # local self-masks.
            if i not in reentrant_sides:
                self.window_local_masks.append(local_masks)
                continue

            x1, y1 = self.footprint[i]
            x2, y2 = self.footprint[i + 1]
            # Robust local obstruction envelope:
            # sample several observer points along the window width and combine
            # their side masks conservatively (logical AND on passthrough).
            observer_points_xy: list[tuple[float, float]] = [
                (x1 + t * (x2 - x1), y1 + t * (y2 - y1))
                for t in (0.0, 0.25, 0.5, 0.75, 1.0)
            ]
            for j, other_side_data in enumerate(self.sides_mask):
                if i == j:
                    continue
                if j not in reentrant_sides:
                    continue
                inner_exposure_deg = other_side_data.exposure_deg + 180.0
                if inner_exposure_deg > 180.0:
                    inner_exposure_deg -= 360.0
                inner_normal_rotation_deg = other_side_data.normal_angle_with_south_deg + 180.0
                if inner_normal_rotation_deg > 180.0:
                    inner_normal_rotation_deg -= 360.0
                for observer_x, observer_y in observer_points_xy:
                    dx = other_side_data.x_center - observer_x
                    dy = other_side_data.y_center - observer_y
                    local_masks.append(
                        SideMask(
                            # SideMask is evaluated in observer-local coordinates.
                            x_center=dx,
                            y_center=dy,
                            width=other_side_data.width,
                            height=other_side_data.height,
                            exposure_deg=inner_exposure_deg,
                            slope_deg=other_side_data.slope_deg,
                            elevation=other_side_data.elevation,
                            normal_rotation_angle_deg=inner_normal_rotation_deg,
                        )
                    )
            self.window_local_masks.append(local_masks)


@dataclass
class FloorResult:
    """Per-zone HVAC summary after simulation.

    ``zone_key`` matches the thermal zone name (``basement``, ``floor0``, …).
    """

    zone_key: str
    external_envelope_surface_m2: float
    heat_production_Wh: list[float]

    @cached_property
    def heat_production_heating_Wh(self) -> list[float]:
        return [p if p > 0 else 0 for p in self.heat_production_Wh]

    @cached_property
    def heat_production_cooling_Wh(self) -> list[float]:
        return [p if p < 0 else 0 for p in self.heat_production_Wh]


@dataclass
class BuildingResult:
    datetimes: list[datetime]
    hvac_cop_heating: float
    hvac_cop_cooling: float
    floor_results: list[FloorResult]

    @cached_property
    def external_envelope_surface_m2(self) -> float:
        return sum(floor_result.external_envelope_surface_m2 for floor_result in self.floor_results)

    @cached_property
    def heat_production_Wh(self) -> list[float]:
        return [sum(floor_result.heat_production_Wh[i] for floor_result in self.floor_results) for i in range(len(self.floor_results[0].heat_production_Wh))]

    @cached_property
    def heat_production_heating_Wh(self) -> list[float]:
        return [p if p > 0 else 0 for p in self.heat_production_Wh]

    @cached_property
    def heat_production_cooling_Wh(self) -> list[float]:
        return [p if p < 0 else 0 for p in self.heat_production_Wh]


class Polygon:

    def __init__(self, footprint: Vertices, eps: float = 1e-12) -> None:
        self.footprint: Vertices = footprint
        self.eps: float = eps

    def __repr__(self) -> str:
        return f"Polygon(footprint={self.footprint}, is_simple={self.is_simple()!r})"

    def is_simple(self) -> bool:
        """
        Check whether a closed polygonal chain defined by footprint points is simple:
        no self-intersection except consecutive edges meeting at shared endpoints.

        A footprint may repeat the first vertex at the end to close the ring; that
        duplicate is ignored for the test.
        """
        footprint: Vertices = self.footprint[0:-1]
        n_vertices: int = len(footprint)
        if n_vertices < 3:
            return False

        for i in range(n_vertices):
            vertex1: Vertex = footprint[i]
            vertex2: Vertex = footprint[(i + 1) % n_vertices]
            if abs(vertex1[0] - vertex2[0]) <= self.eps and abs(vertex1[1] - vertex2[1]) <= self.eps:
                return False

        for i in range(n_vertices):
            vertex1: Vertex = footprint[i]
            vertex2: Vertex = footprint[(i + 1) % n_vertices]

            for j in range(i + 1, n_vertices):
                if j == i:
                    continue
                if j == (i + 1) % n_vertices:
                    continue
                if i == (j + 1) % n_vertices:
                    continue
                vertex3: Vertex = footprint[j]
                vertex4: Vertex = footprint[(j + 1) % n_vertices]

                if self._segments_intersect(vertex1, vertex2, vertex3, vertex4, self.eps):
                    return False
        return True

    def footprint_plot(self, simple: bool = True) -> None:
        """Plot footprint and closed edge chain in the plane."""
        if len(self.footprint) < 1:
            return

        xs: list[float] = [vertex[0] for vertex in self.footprint]
        ys: list[float] = [vertex[1] for vertex in self.footprint]

        fig, ax = plt.subplots(figsize=(7.0, 7.0))
        ax.plot(xs, ys, color="C0", linewidth=1.8, alpha=0.85, zorder=1)
        ax.scatter(xs, ys, c="C0", s=90, zorder=3, edgecolors="black", linewidths=1.0)
        for i, (x, y) in enumerate(self.footprint):
            ax.annotate(str(i), (x, y), xytext=(5, 5), textcoords="offset points", fontsize=11, fontweight="bold")
        ax.set_aspect("equal", adjustable="box")
        ax.grid(True, alpha=0.35)
        ax.set_xlabel("x")
        ax.set_ylabel("y")
        if not simple:
            ax.set_title("ERROR: footprint is not forming a simple polygon")
        else:
            ax.set_title("Footprint")
        fig.tight_layout()
        backend: str = matplotlib.get_backend().lower()
        out: str | None = os.environ.get("SIMPLE_POLYNOME_FIG_PATH")
        if out or "agg" in backend:
            path: str = out or "/tmp/simple_polynome_complex_building.png"
            fig.savefig(path, dpi=150)
            print(f"Saved figure to {path}")
        else:
            plt.show()
        plt.close(fig)

    @staticmethod
    def _orient(vertex1: Vertex, vertex2: Vertex, vertex3: Vertex) -> float:
        """Signed area / 2D cross product."""
        return (vertex2[0] - vertex1[0]) * (vertex3[1] - vertex1[1]) - (vertex2[1] - vertex1[1]) * (vertex3[0] - vertex1[0])

    @staticmethod
    def _almost_equal(x: float, y: float, eps: float = 1e-12) -> bool:
        return abs(x - y) <= eps

    @staticmethod
    def _vertex_on_segment(vertex1: Vertex, vertex2: Vertex, vertex3: Vertex, eps: float) -> bool:
        """Return True iff p is collinear with [a,b] and lies in its bounding box."""
        if abs(Polygon._orient(vertex1, vertex2, vertex3)) > eps:
            return False
        return (
            min(vertex1[0], vertex2[0]) - eps <= vertex3[0] <= max(vertex1[0], vertex2[0]) + eps
            and min(vertex1[1], vertex2[1]) - eps <= vertex3[1] <= max(vertex1[1], vertex2[1]) + eps
        )

    @staticmethod
    def _segments_intersect(vertex1: Vertex, vertex2: Vertex, vertex3: Vertex, vertex4: Vertex, eps: float) -> bool:
        """Return True iff closed segments [a,b] and [c,d] intersect."""
        orient1: float = Polygon._orient(vertex1, vertex2, vertex3)
        orient2: float = Polygon._orient(vertex1, vertex2, vertex4)
        orient3: float = Polygon._orient(vertex3, vertex4, vertex1)
        orient4: float = Polygon._orient(vertex3, vertex4, vertex2)

        # Proper intersection
        if ((orient1 > eps and orient2 < -eps) or (orient1 < -eps and orient2 > eps)) and (
            (orient3 > eps and orient4 < -eps) or (orient3 < -eps and orient4 > eps)
        ):
            return True

        # Degenerate / collinear cases
        if abs(orient1) <= eps and Polygon._vertex_on_segment(vertex1, vertex2, vertex3, eps):
            return True
        if abs(orient2) <= eps and Polygon._vertex_on_segment(vertex1, vertex2, vertex4, eps):
            return True
        if abs(orient3) <= eps and Polygon._vertex_on_segment(vertex3, vertex4, vertex1, eps):
            return True
        if abs(orient4) <= eps and Polygon._vertex_on_segment(vertex3, vertex4, vertex2, eps):
            return True
        return False


class BuildingView:
    """Polygon-based 3D view for :class:`BuildingData` footprints."""

    def __init__(self, building_data: BuildingData) -> None:
        self.building_data: BuildingData = building_data
        self.building_color: str = "#B0BEC5"
        self.base_color: str = "#5D4037"
        self.glass_color: str = "#42A5F5"
        self.edge_color: str = "#37474F"
        self.slab_color: str = "#78909C"

    @staticmethod
    def _footprint_ring_xy(footprint: Vertices) -> list[tuple[float, float]]:
        """Unique horizontal polygon vertices (drop repeated closing point)."""
        if len(footprint) >= 2 and footprint[0] == footprint[-1]:
            return list(footprint[:-1])
        return list(footprint)

    @staticmethod
    def _polygon_xy_triangulation(ring_xy: list[tuple[float, float]]) -> np.ndarray:
        """Return ``(m, 3)`` triangle vertex indices for a simple (possibly concave) polygon.

        Ear clipping on the closed ring (exactly ``n - 2`` triangles for ``n`` vertices),
        so the interior is fully covered without gaps and without crossing concave notches.
        The ring is oriented CCW internally so convex / inside tests are consistent.
        """
        pts2 = np.asarray(ring_xy, dtype=float)
        n: int = int(pts2.shape[0])
        if n < 3:
            return np.zeros((0, 3), dtype=np.int64)

        twice_area = 0.0
        for i in range(n):
            j = (i + 1) % n
            twice_area += float(pts2[i, 0] * pts2[j, 1] - pts2[j, 0] * pts2[i, 1])
        # Ear clipping assumes CCW boundary; flip CW footprints.
        if twice_area < 0.0:
            pts2 = np.flipud(pts2.copy())
            remap = np.arange(n, dtype=np.int64)[::-1]
        else:
            remap = np.arange(n, dtype=np.int64)

        if n == 3:
            tri = np.array([[0, 1, 2]], dtype=np.int64)
            return remap[tri]

        idx: list[int] = list(range(n))
        tris: list[list[int]] = []
        eps = 1e-10

        def tri_area2(a: np.ndarray, b: np.ndarray, c: np.ndarray) -> float:
            return float((b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]))

        def is_convex_vertex(i_prev: int, i: int, i_next: int) -> bool:
            p_prev = pts2[i_prev]
            p = pts2[i]
            p_next = pts2[i_next]
            d1 = p - p_prev
            d2 = p_next - p
            cr = float(d1[0] * d2[1] - d1[1] * d2[0])
            if abs(cr) < 1e-14:
                return False
            return cr > 0.0

        def strictly_inside(q_idx: int, a_idx: int, b_idx: int, c_idx: int) -> bool:
            a, b, c = pts2[a_idx], pts2[b_idx], pts2[c_idx]
            q = pts2[q_idx]
            o1 = tri_area2(a, b, c)
            if abs(o1) < 1e-14:
                return False
            s1 = tri_area2(a, b, q)
            s2 = tri_area2(b, c, q)
            s3 = tri_area2(c, a, q)
            if o1 > 0.0:
                return s1 > eps and s2 > eps and s3 > eps
            return s1 < -eps and s2 < -eps and s3 < -eps

        max_iter = max(1000, n * n * 4)
        iterations = 0
        while len(idx) > 3:
            nloc = len(idx)
            found = False
            for k in range(nloc):
                i_prev = idx[(k - 1) % nloc]
                i_mid = idx[k % nloc]
                i_next = idx[(k + 1) % nloc]
                if not is_convex_vertex(i_prev, i_mid, i_next):
                    continue
                ok = True
                for m in range(nloc):
                    q_idx = idx[m]
                    if q_idx in (i_prev, i_mid, i_next):
                        continue
                    if strictly_inside(q_idx, i_prev, i_mid, i_next):
                        ok = False
                        break
                if not ok:
                    continue
                tris.append([i_prev, i_mid, i_next])
                del idx[k]
                found = True
                break
            if not found:
                break
            iterations += 1
            if iterations > max_iter:
                break
        if len(idx) == 3:
            tris.append([idx[0], idx[1], idx[2]])
        if not tris:
            return np.zeros((0, 3), dtype=np.int64)
        tris_arr = np.asarray(tris, dtype=np.int64)
        return remap[tris_arr]

    @staticmethod
    def _horizontal_tri_sheet_polydata(ring_xy: list[tuple[float, float]], z: float, outward_up: bool) -> PolyData:
        """Horizontal sheet at *z* as triangles; normals point ±Z depending on *outward_up*."""
        tris = BuildingView._polygon_xy_triangulation(ring_xy)
        if tris.shape[0] == 0:
            return PolyData()
        pts = np.array([[x, y, z] for x, y in ring_xy], dtype=float)
        for ti in range(tris.shape[0]):
            i, j, k = int(tris[ti, 0]), int(tris[ti, 1]), int(tris[ti, 2])
            p0, p1, p2 = pts[i], pts[j], pts[k]
            cz = float(np.cross(p1 - p0, p2 - p0)[2])
            if (outward_up and cz < 0.0) or ((not outward_up) and cz > 0.0):
                tris[ti, 1], tris[ti, 2] = tris[ti, 2], tris[ti, 1]
        faces = np.empty(4 * tris.shape[0], dtype=np.int32)
        faces[0::4] = 3
        faces[1::4] = tris[:, 0].astype(np.int32)
        faces[2::4] = tris[:, 1].astype(np.int32)
        faces[3::4] = tris[:, 2].astype(np.int32)
        return PolyData(pts, faces=faces)

    @staticmethod
    def _footprint_polydata(footprint: Vertices, elevation: float) -> PolyData:
        ring = BuildingView._footprint_ring_xy(footprint)
        if len(ring) < 3:
            return PolyData()
        return BuildingView._horizontal_tri_sheet_polydata(ring, elevation, outward_up=True)

    @staticmethod
    def _vertical_prism_polydata(footprint: Vertices, z0: float, z1: float) -> PolyData:
        ring = BuildingView._footprint_ring_xy(footprint)
        n_vertices: int = len(ring)
        if n_vertices < 3 or z1 <= z0 + 1e-9:
            return PolyData()
        pts_arr = np.zeros((2 * n_vertices, 3), dtype=float)
        for i, (x, y) in enumerate(ring):
            pts_arr[i, :] = (x, y, z0)
            pts_arr[i + n_vertices, :] = (x, y, z1)
        faces: list[int] = [n_vertices] + list(range(n_vertices - 1, -1, -1))
        faces += [n_vertices] + list(range(n_vertices, 2 * n_vertices))
        for i in range(n_vertices):
            j: int = (i + 1) % n_vertices
            faces += [4, i, j, j + n_vertices, i + n_vertices]
        return PolyData(pts_arr, faces=np.asarray(faces, dtype=np.int32))

    @staticmethod
    def _merge_polys(parts: list[PolyData]) -> PolyData:
        ok: list[PolyData] = [p for p in parts if p.n_points > 0]
        if not ok:
            return PolyData()
        out: PolyData = ok[0].copy(deep=True)
        for p in ok[1:]:
            out = out.merge(p)
        return out

    @staticmethod
    def _horizontal_cap_polydata(footprint: Vertices, z: float, outward_up: bool) -> PolyData:
        ring = BuildingView._footprint_ring_xy(footprint)
        n_vertices: int = len(ring)
        if n_vertices < 3:
            return PolyData()
        order = range(n_vertices) if outward_up else range(n_vertices - 1, -1, -1)
        ordered_ring = [ring[i] for i in order]
        return BuildingView._horizontal_tri_sheet_polydata(ordered_ring, z, outward_up=outward_up)

    @staticmethod
    def _quad_uz(x1: float, y1: float, x2: float, y2: float, edge_len: float, u_a: float, u_b: float, z_a: float, z_b: float) -> PolyData:
        if u_b <= u_a + 1e-9 or z_b <= z_a + 1e-9 or edge_len < 1e-9:
            return PolyData()

        def p_at(u: float) -> Vertex:
            t = u / edge_len
            return x1 + t * (x2 - x1), y1 + t * (y2 - y1)

        xa, ya = p_at(u_a)
        xb, yb = p_at(u_b)
        corners = np.array([[xa, ya, z_a], [xb, yb, z_a], [xb, yb, z_b], [xa, ya, z_b]], dtype=float)
        return PolyData(corners, faces=np.array([4, 0, 1, 2, 3], dtype=np.int32))

    def _wall_facade_with_window_hole(self, x1: float, y1: float, x2: float, y2: float, z0: float, z1: float, glazing_ratio: float) -> tuple[list[PolyData], PolyData]:
        dx, dy = x2 - x1, y2 - y1
        elen: float = sqrt(dx * dx + dy * dy)
        if elen < 1e-9 or z1 <= z0 + 1e-9:
            return [], PolyData()
        nx, ny = dy / elen, -dx / elen
        strips: list[PolyData] = []
        if glazing_ratio <= 1e-6:
            strips.append(self._quad_uz(x1, y1, x2, y2, elen, 0.0, elen, z0, z1))
            return strips, PolyData()

        ww: float = elen * sqrt(glazing_ratio)
        zh: float = (z1 - z0) * sqrt(glazing_ratio)
        uc: float = 0.5 * elen
        zc: float = 0.5 * (z0 + z1)
        u_lo: float = max(0.0, uc - 0.5 * ww)
        u_hi: float = min(elen, uc + 0.5 * ww)
        z_lo_w: float = max(z0, zc - 0.5 * zh)
        z_hi_w: float = min(z1, zc + 0.5 * zh)
        if u_hi <= u_lo + 1e-6 or z_hi_w <= z_lo_w + 1e-6:
            strips.append(self._quad_uz(x1, y1, x2, y2, elen, 0.0, elen, z0, z1))
            return strips, PolyData()

        if z_lo_w > z0 + 1e-6:
            strips.append(self._quad_uz(x1, y1, x2, y2, elen, 0.0, elen, z0, z_lo_w))
        if z1 > z_hi_w + 1e-6:
            strips.append(self._quad_uz(x1, y1, x2, y2, elen, 0.0, elen, z_hi_w, z1))
        if u_lo > 1e-6:
            strips.append(self._quad_uz(x1, y1, x2, y2, elen, 0.0, u_lo, z_lo_w, z_hi_w))
        if elen - u_hi > 1e-6:
            strips.append(self._quad_uz(x1, y1, x2, y2, elen, u_hi, elen, z_lo_w, z_hi_w))

        eps: float = 0.04

        def p_at(u: float) -> Vertex:
            t: float = u / elen
            return x1 + t * (x2 - x1), y1 + t * (y2 - y1)

        xa, ya = p_at(u_lo)
        xb, yb = p_at(u_hi)
        glass = np.array(
            [
                [xa + nx * eps, ya + ny * eps, z_lo_w],
                [xb + nx * eps, yb + ny * eps, z_lo_w],
                [xb + nx * eps, yb + ny * eps, z_hi_w],
                [xa + nx * eps, ya + ny * eps, z_hi_w],
            ],
            dtype=float,
        )
        return strips, PolyData(glass, faces=np.array([4, 0, 1, 2, 3], dtype=np.int32))

    def _floor_storey_mesh_with_openings(self, footprint: Vertices, z0: float, z1: float, ratios: list[float]) -> tuple[PolyData, list[PolyData]]:
        ring = self._footprint_ring_xy(footprint)
        n_ring: int = len(ring)
        wall_parts: list[PolyData] = [
            self._horizontal_cap_polydata(footprint, z0, outward_up=False),
            self._horizontal_cap_polydata(footprint, z1, outward_up=True),
        ]
        glass_list: list[PolyData] = []
        for i in range(n_ring):
            x1, y1 = ring[i]
            x2, y2 = ring[(i + 1) % n_ring]
            g = ratios[i] if i < len(ratios) else 0.0
            strips, glass = self._wall_facade_with_window_hole(x1, y1, x2, y2, z0, z1, g)
            wall_parts.extend(strips)
            if glass.n_points > 0:
                glass_list.append(glass)
        return self._merge_polys(wall_parts), glass_list

    def _add_cardinal_direction_labels(self, plotter: pv.Plotter) -> None:
        """Annotate the horizontal plane with South / North / East / West.

        Convention (exposure-style azimuth, degrees from South):

        - South: 0°
        - East: −90°
        - West: +90°
        - North: 180°

        World axes in the plot: **+X is East**, **+Y is North** (South is −Y).
        """
        footprint = self.building_data.footprint
        if not footprint:
            return
        xs: list[float] = [p[0] for p in footprint]
        ys: list[float] = [p[1] for p in footprint]
        cx: float = (min(xs) + max(xs)) / 2.0
        cy: float = (min(ys) + max(ys)) / 2.0
        dx: float = max(xs) - min(xs)
        dy: float = max(ys) - min(ys)
        span_xy: float = max(dx, dy, 1.0)
        radius: float = 0.55 * span_xy + 0.15 * span_xy
        elevation: float = max(0.12, 0.05 * max(self.building_data.base_elevation, 1.0))

        # Unit vectors in plan: +X East, +Y North
        label_spec: list[tuple[str, float, float]] = [
            ("South (0°)", 0.0, -1.0),
            ("North (180°)", 0.0, 1.0),
            ("East (-90°)", 1.0, 0.0),
            ("West (90°)", -1.0, 0.0),
        ]
        pts_arr = np.array(
            [[cx + radius * ux, cy + radius * uy, elevation] for _, ux, uy in label_spec],
            dtype=float,
        )
        labels = [text for text, _, _ in label_spec]
        cloud = pv.PolyData(pts_arr)
        plotter.add_point_labels(
            cloud,
            labels,
            font_size=28,
            point_size=14,
            text_color="white",
            point_color="#212121",
            always_visible=True,
        )

    def draw(self, plotter: pv.Plotter) -> None:
        footprint: Vertices = self.building_data.footprint
        if footprint:
            xs: list[float] = [point[0] for point in footprint]
            ys: list[float] = [point[1] for point in footprint]
            min_x, max_x = min(xs), max(xs)
            min_y, max_y = min(ys), max(ys)
            dx = max_x - min_x
            dy = max_y - min_y
            pad_x = 0.1 * dx if dx > 1e-9 else 0.1
            pad_y = 0.1 * dy if dy > 1e-9 else 0.1
            ground_rect = pv.Plane(
                center=((min_x + max_x) / 2.0, (min_y + max_y) / 2.0, 0.0),
                direction=(0, 0, 1),
                i_size=dx + 2.0 * pad_x,
                j_size=dy + 2.0 * pad_y,
            )
            plotter.add_mesh(ground_rect, color="#2E7D32", opacity=0.35, show_edges=False)
        floor_height: float = self.building_data.floor_height
        base_elevation: float = self.building_data.base_elevation
        n_floors: int = self.building_data.n_floors
        ratios: list[float] = self.building_data.side_glazing_ratios

        if base_elevation > 1e-6:
            base_mesh = self._vertical_prism_polydata(footprint, 0.0, base_elevation)
            if base_mesh.n_cells > 0:
                plotter.add_mesh(base_mesh, color=self.base_color, opacity=1.0, smooth_shading=True, show_edges=True, edge_color="black", line_width=1.2)

        for k in range(n_floors):
            z0: float = base_elevation + k * floor_height
            z1: float = base_elevation + (k + 1) * floor_height
            cell, glass_panes = self._floor_storey_mesh_with_openings(footprint, z0, z1, ratios)
            if cell.n_cells > 0:
                plotter.add_mesh(cell, color=self.building_color, opacity=1.0, smooth_shading=True, show_edges=True, edge_color=self.edge_color, line_width=1.0)
            for gmesh in glass_panes:
                plotter.add_mesh(gmesh, color=self.glass_color, opacity=0.55, smooth_shading=True, show_edges=True, edge_color="#0D47A1", line_width=1.0)
            slab = self._footprint_polydata(footprint, elevation=z1 - 0.04)
            if slab.n_points > 0:
                thick = slab.extrude((0.0, 0.0, 0.08), capping=True, inplace=False)
                plotter.add_mesh(thick, color=self.slab_color, opacity=0.35, show_edges=False)

        self._add_cardinal_direction_labels(plotter)


class SideMaskView:
    """Draw helper for one distant side mask (obstacle + normal arrow)."""
    def __init__(self, side_mask_data: SideMaskData) -> None:
        self.color = "red"
        self.opacity: float = 0.35
        self.x_center: float = side_mask_data.x_center
        self.y_center: float = side_mask_data.y_center
        self.z_center: float = side_mask_data.elevation + side_mask_data.height / 2
        self.center_ref: tuple[float, float, float] = (self.x_center, self.y_center, self.z_center)
        self.width: float = side_mask_data.width
        self.height: float = side_mask_data.height
        self.elevation: float = side_mask_data.elevation
        self.exposure_deg: float = side_mask_data.exposure_deg
        self.slope_deg: float = side_mask_data.slope_deg
        self.normal_rotation_deg: float = side_mask_data.normal_angle_with_south_deg
        self.tangent_x: float = side_mask_data.tangent_x
        self.tangent_y: float = side_mask_data.tangent_y
        self.facade_normal_x: float = side_mask_data.facade_normal_x
        self.facade_normal_y: float = side_mask_data.facade_normal_y
        self._use_footprint_facade_axes: bool = (
            isfinite(self.tangent_x)
            and isfinite(self.tangent_y)
            and isfinite(self.facade_normal_x)
            and isfinite(self.facade_normal_y)
        )
        slope_rad: float = radians(self.slope_deg)
        exposure_rad: float = radians(side_mask_data.exposure_deg)
        if self._use_footprint_facade_axes:
            self.normal = (self.facade_normal_x, self.facade_normal_y, 0.0)
        else:
            self.normal = (cos(exposure_rad) * sin(slope_rad), sin(exposure_rad) * sin(slope_rad), -cos(slope_rad))
        self.azimuth_deg: float = degrees(atan2(self.y_center, self.x_center))
        self.altitude_deg: float = degrees(atan2(self.elevation, sqrt(self.x_center**2 + self.y_center**2)))
        self.distance_m: float = sqrt(self.x_center**2 + self.y_center**2)

    def make(self) -> pv.PolyData:
        if abs(self.slope_deg - 90.0) < 1e-6:
            return self._vertical_mask_quad_polydata()
        plane: pv.PolyData = pv.Plane(
            center=self.center_ref,
            direction=self.normal,
            i_size=self.height,
            j_size=self.width,
        )
        if abs(self.normal_rotation_deg + 90.0) > 1e-9:
            plane.rotate_vector(
                vector=self.normal,
                angle=self.normal_rotation_deg + 90.0,
                point=self.center_ref,
                inplace=True,
            )
        return plane

    def _vertical_mask_quad_polydata(self) -> pv.PolyData:
        """Quad mesh for a vertical façade: footprint-based axes when available."""
        up = np.array([0.0, 0.0, 1.0], dtype=float)
        if self._use_footprint_facade_axes:
            w0 = np.array([self.tangent_x, self.tangent_y, 0.0], dtype=float)
            n = np.array([self.facade_normal_x, self.facade_normal_y, 0.0], dtype=float)
            w0n = float(np.linalg.norm(w0))
            nn = float(np.linalg.norm(n))
            if w0n < 1e-12 or nn < 1e-12:
                return PolyData()
            w0 = w0 / w0n
            n = n / nn
            if abs(float(np.dot(w0, n))) > 1e-5:
                return PolyData()
        else:
            e = radians(self.exposure_deg)
            n = np.array([cos(e), sin(e), 0.0], dtype=float)
            n_norm = float(np.linalg.norm(n))
            if n_norm < 1e-12:
                return PolyData()
            n = n / n_norm
            w0 = np.cross(up, n)
            w0n = float(np.linalg.norm(w0))
            if w0n < 1e-12:
                return PolyData()
            w0 = w0 / w0n
        # Match PyVista / wall strip convention: rotate the in-plane basis by +90°
        # around the outward normal, then assign width along the horizontal in-plane
        # axis and height along the vertical axis (see :class:`~batem.core.solar.SideMask`).
        roll_rad = radians(90.0 + self.normal_rotation_deg)
        w_vert = _rotate_vector_around_axis(w0, n, roll_rad)
        h_horiz = np.cross(n, w_vert)
        hh = float(np.linalg.norm(h_horiz))
        if hh < 1e-12:
            return PolyData()
        h_horiz = h_horiz / hh
        if w_vert[2] < 0.0:
            w_vert = -w_vert
            h_horiz = -h_horiz
        c = np.array([self.x_center, self.y_center, self.elevation + 0.5 * self.height], dtype=float)
        half_w = 0.5 * self.width
        half_h = 0.5 * self.height
        corners = np.array(
            [
                c - half_w * h_horiz - half_h * w_vert,
                c + half_w * h_horiz - half_h * w_vert,
                c + half_w * h_horiz + half_h * w_vert,
                c - half_w * h_horiz + half_h * w_vert,
            ],
            dtype=float,
        )
        faces = np.array([4, 0, 1, 2, 3], dtype=np.int32)
        return PolyData(corners, faces=faces)

    def draw(self, plotter: pv.Plotter) -> None:
        plane = self.make()
        tail: tuple[float, float, float] = self.center_ref
        head: tuple[float, float, float] = (self.center_ref[0] + 3.0 * self.normal[0], self.center_ref[1] + 3.0 * self.normal[1], self.center_ref[2] + 3.0 * self.normal[2])
        arrow = pv.Arrow(start=tail, direction=[head[i] - tail[i] for i in range(3)], tip_length=0.2, tip_radius=0.15, shaft_radius=0.05)
        plotter.add_mesh(plane, color=self.color, opacity=self.opacity, smooth_shading=True)
        plotter.add_mesh(arrow, color="black")


class Context:

    def __init__(self, context_data: ContextData) -> None:
        self.context_data: ContextData = context_data
        self.distant_masks: list[SideMask] = list()
        self.side_mask_views: list[SideMaskView] = list()
        for side_mask in context_data.side_masks:
            self.distant_masks.append(SideMask(side_mask.x_center, side_mask.y_center, side_mask.width, side_mask.height, side_mask.exposure_deg, side_mask.slope_deg, side_mask.elevation, side_mask.normal_angle_with_south_deg))
            side_mask_view: SideMaskView = SideMaskView(side_mask)
            side_mask_view.make()
            self.side_mask_views.append(side_mask_view)

        bindings: Bindings = Bindings()
        bindings('TZ:outdoor', 'weather_temperature')
        if context_data.starting_stringdate is None:
            context_data.starting_stringdate = f"01/01/{context_data.simulated_year}"
        if context_data.ending_stringdate is None:
            context_data.ending_stringdate = f"31/12/{context_data.simulated_year}"
        self.dp: DataProvider = DataProvider(location=context_data.location, latitude_north_deg=context_data.latitude_north_deg, longitude_east_deg=context_data.longitude_east_deg, starting_stringdate=context_data.starting_stringdate, ending_stringdate=context_data.ending_stringdate, bindings=bindings, albedo=context_data.albedo, pollution=context_data.pollution, number_of_levels=context_data.number_of_levels, initial_year=context_data.simulated_year)
        self.solar_model: SolarModel = SolarModel(self.dp.weather_data, distant_masks=self.distant_masks)


class PrismBasementZone:
    """Below-grade thermal zone for a polygon prism (:class:`BuildingData`).

    Modeled like other zones in the RC network, but **without** occupants, glazing,
    HVAC, or outdoor ventilation. Heat balance uses ``PZ = GAIN`` with ``GAIN = 0`` and
    ``PHVAC = 0``. Boundaries: slab to **ground** (``TZ:ground``, typically ~13 °C from
    context), façades to **outdoor** (weather), and slab/ceiling to **floor0** (occupied
    ground storey).
    """

    def __init__(self, building_data: BuildingData, solar_model: SolarModel) -> None:  # floor_number: int,
        self.name: str = "basement"
        self.building_data: BuildingData = building_data
        # self.solar_model: SolarModel = solar_model
        # self.solar_system: SolarSystem = SolarSystem(solar_model)
        # self.n_floors: int = building_data.n_floors
        # self.floor_height: float = building_data.floor_height
        self.elevation_m: float = building_data.base_elevation
        self.hsurface_m2: float = building_data.footprint_surface_m2
        self.volume_m3: float = self.hsurface_m2 * self.elevation_m
        self.plain_vsurface_m2: float = sum(building_data.sides_plain_basement_vsurface_m2)
        # Below-grade envelope for reporting (façade toward outdoor + slab on ground)
        self.external_envelope_surface_m2: float = self.plain_vsurface_m2 + self.hsurface_m2

    # def window_masks(self) -> dict[str, Mask]:
    #     return {}

    def make(self, model_maker: ModelMaker, dp: DataProvider) -> None:
        model_maker.make_side(self.building_data.basement_floor(self.name, 'ground', SIDE_TYPES.FLOOR, self.hsurface_m2))
        model_maker.make_side(self.building_data.wall(self.name, 'outdoor', SIDE_TYPES.WALL, self.plain_vsurface_m2))
        # Slab between basement and ground occupied storey (zones are floor0 … floor{n-1})
        model_maker.make_side(self.building_data.ground_floor(self.name, 'floor0', SIDE_TYPES.FLOOR, self.hsurface_m2))


class PrismZoneFloor:
    """Occupied storey for polygon-prism buildings: one solar collector per façade segment."""

    def __init__(self, floor_index: int, building_data: BuildingData, solar_model: SolarModel) -> None:
        """``floor_index`` is 0-based: ground occupied storey is ``floor0``."""
        self.floor_index: int = floor_index
        self.name: str = f"floor{floor_index}"
        self.building_data: BuildingData = building_data
        self.solar_model: SolarModel = solar_model
        self.solar_system: SolarSystem = SolarSystem(solar_model)
        self.n_floors: int = building_data.n_floors
        self.base_elevation: float = building_data.base_elevation
        self.floor_height: float = building_data.floor_height
        self.z_rotation_angle_deg: float = building_data.z_rotation_angle_deg
        self.floor_surface: float = building_data.footprint_surface_m2
        self.volume: float = self.floor_surface * self.floor_height
        self.volume_m3: float = self.volume
        self.mid_elevation: float = self.base_elevation + self.floor_height * (floor_index + 0.5)
        self.window_surfaces: list[float] = list(building_data.sides_glazing_floor_vsurface_m2)
        self.window_angles_deg: list[float] = list(building_data.sides_exposure_deg)
        self.windows_names: list[str] = [f"side{i}" for i in range(building_data.n_sides)]
        self.glazing_surface: float = sum(self.window_surfaces)
        self.wall_surface: float = sum(building_data.sides_plain_floor_vsurface_m2)
        self._window_masks: dict[str, Mask] = {}
        self.zone_window_collectors: list[Collector] = []
        self.external_envelope_surface_m2: float = self.wall_surface + self.glazing_surface
        if self.floor_index == self.n_floors - 1:
            self.external_envelope_surface_m2 += self.floor_surface
        self.hvac_heat_production_kWh_per_year_cooling: float = 0.0
        self.hvac_heat_production_kWh_per_year_heating: float = 0.0
        self.hvac_electric_consumption_kWh_per_year_cooling: float = 0.0
        self.hvac_electric_consumption_kWh_per_year_heating: float = 0.0

    def window_masks(self) -> dict[str, Mask]:
        return self._window_masks

    def make(self, model_maker: ModelMaker, dp: DataProvider) -> None:
        if self.floor_index == self.n_floors - 1:
            # Roof exchange surface is plan area, not zone volume.
            model_maker.make_side(self.building_data.roof(self.name, 'outdoor', SIDE_TYPES.CEILING, self.floor_surface))
        else:
            assert self.building_data.intermediate_floor is not None, "intermediate_floor should be defined when n_floors > 1"
            model_maker.make_side(self.building_data.intermediate_floor(self.name, f'floor{self.floor_index + 1}', SIDE_TYPES.FLOOR, self.floor_surface))
        if self.floor_index == 0 and self.base_elevation == 0:
            model_maker.make_side(self.building_data.ground_floor(self.name, 'ground', SIDE_TYPES.FLOOR, self.floor_surface))
        model_maker.make_side(self.building_data.wall(self.name, 'outdoor', SIDE_TYPES.WALL, self.wall_surface))
        model_maker.make_side(self.building_data.glazing(self.name, 'outdoor', SIDE_TYPES.GLAZING, self.glazing_surface))
        regular_rate = self.building_data.regular_air_renewal_rate_vol_per_hour
        nominal_airflow = (regular_rate * self.volume / 3600) if regular_rate is not None else 0.0
        model_maker.connect_airflow(self.name, 'outdoor', nominal_value=nominal_airflow)

        for side_index, (window_name, window_angle, window_surface) in enumerate(zip(self.windows_names, self.window_angles_deg, self.window_surfaces)):
            side_local_masks: list[Mask] = self.building_data.window_local_masks[side_index]
            close_mask: Mask | None = StackedMask(*side_local_masks) if side_local_masks else None
            collector: Collector = Collector(
                self.solar_system,
                window_name,
                surface_m2=window_surface,
                exposure_deg=window_angle,
                slope_deg=SLOPES.VERTICAL.value,
                solar_factor=self.building_data.glazing_solar_factor,
                close_mask=close_mask,
                observer_elevation_m=self.mid_elevation,
            )
            self.zone_window_collectors.append(collector)
            self._window_masks[window_name] = collector.mask


class Building:
    """High-level orchestrator for generating and simulating a BATEM building.

    The class assembles the context, solar model, thermal network, HVAC
    controllers, and simulation engine required to execute a full-year building
    simulation.

    :param context_data: Geographic and climatic context description.
    :param building_data: Physical parameters and HVAC capacities.
    :ivar context: Instantiated :class:`Context` wrapping weather and bindings.
    :ivar dp: Shared :class:`~batem.core.data.DataProvider` used across modules.
    :ivar simulation: Configured :class:`~batem.core.control.Simulation` object.
    :ivar floors: Zone layers (basement + one per occupied storey) for the polygon prism model.
    """

    def __init__(self, context_data: ContextData, building_data: BuildingData) -> None:
        self.context: Context = Context(context_data)
        self.context_data: ContextData = context_data
        self.dp: DataProvider = self.context.dp
        self.datetimes: list[datetime] = self.dp.datetimes
        self.building_data: BuildingData = building_data
        self.building_view = BuildingView(building_data)
        # self.building_view.make()
        self.dp.add_param('CCO2:outdoor', 400)
        self.dp.add_param('TZ:ground', context_data.ground_temperature)

        solar_model: SolarModel = self.context.solar_model

        zone_floors: list[PrismBasementZone | PrismZoneFloor] = []
        zone_name_volumes: dict[str, float] = {}
        if building_data.has_basement:
            zone_floors.append(PrismBasementZone(building_data, solar_model))
            zone_name_volumes[zone_floors[0].name] = zone_floors[0].volume_m3
        # n_floors = number of occupied storeys (excluding basement). Zone names: floor0 … floor{n_floors-1}.
        for floor_index in range(0, building_data.n_floors):
            zone_floor = PrismZoneFloor(floor_index, building_data, solar_model)
            zone_floors.append(zone_floor)
            zone_name_volumes[zone_floor.name] = zone_floor.volume
        zone_name_volumes['outdoor'] = None
        zone_name_volumes['ground'] = None
        self.zone_names: list[str] = [zone_floor.name for zone_floor in zone_floors]
        self.zone_floors: list[PrismBasementZone | PrismZoneFloor] = zone_floors
        self.zone_outdoor_regular_airflows_m3_per_s: dict[str, float] = {}
        airflow_defaults: dict[str, float] = {}
        airflow_bounds: dict[str, float] = {}
        airflow_names: list[str] = []
        # Set up airflow for each occupied storey (basement has no regular outdoor airflow)
        for zone_floor in zone_floors:
            if isinstance(zone_floor, PrismBasementZone):
                continue
            volume: float | None = getattr(zone_floor, 'volume', None)
            if volume is None:
                continue
            airflow_name = f'Q:{zone_floor.name}-outdoor'
            base_value: float | None = None
            bound_upper: float = 0.0
            if self.building_data.regular_air_renewal_rate_vol_per_hour is not None:
                print(f"Floor {zone_floor.name} has a regular airflow: {self.building_data.regular_air_renewal_rate_vol_per_hour} vol/h")
                regular_airflow_m3_per_s: float = (self.building_data.regular_air_renewal_rate_vol_per_hour * volume) / 3600.0
                self.zone_outdoor_regular_airflows_m3_per_s[zone_floor.name] = regular_airflow_m3_per_s
                base_value = regular_airflow_m3_per_s
                bound_upper = max(bound_upper, regular_airflow_m3_per_s)
            if base_value is None:
                base_value = 0.0
            bound_upper = max(bound_upper, base_value)
            airflow_defaults[airflow_name] = base_value
            airflow_bounds[airflow_name] = bound_upper
            airflow_names.append(airflow_name)
        if airflow_names:
            self.dp.add_data_names_in_fingerprint(*airflow_names)
            for airflow_name, default_value in airflow_defaults.items():
                values = [default_value for _ in self.dp.ks]
                if airflow_name in self.dp:
                    self.dp.add_var(airflow_name, values, force=True)
                else:
                    self.dp.add_var(airflow_name, values)
                bound_upper = airflow_bounds.get(airflow_name, default_value)
                if bound_upper <= 0.0:
                    bound_upper = 1e-6
                if hasattr(self.dp, 'independent_variable_set'):
                    self.dp.independent_variable_set.variable_bounds[airflow_name] = (0.0, bound_upper)

        # Store initial heat recovery efficiency as parameter (will be updated as time series after simulation)
        # The actual time-varying efficiency will be set in _update_ventilation_heat_recovery_efficiency()
        self.dp.add_param('ventilation_heat_recovery_efficiency', building_data.regular_ventilation_heat_recovery_efficiency)

        # #### STATE MODEL MAKER AND SURFACES ####
        model_maker: ModelMaker = ModelMaker(data_provider=self.dp, periodic_depth_seconds=building_data.periodic_depth_seconds, state_model_order_max=building_data.state_model_order_max, **zone_name_volumes)

        # Calculate max occupancy per floor based on floor area and density
        # density_occupants_per_100m2 is per unit area, applied to each floor independently
        max_occupancy_per_floor: float = (
            building_data.density_occupants_per_100m2 * building_data.footprint_surface_m2 / 100.0
        )

        # Realistic default occupancy profile (low at night, peak during daytime).
        # This prevents unrealistically large internal gains (and winter overheating).
        siggen: SignalGenerator = SignalGenerator(
            self.dp,
            OccupancyProfile(
                weekday_profile={
                    0: max_occupancy_per_floor * 0.10,
                    6: max_occupancy_per_floor * 0.15,
                    8: max_occupancy_per_floor * 0.45,
                    9: max_occupancy_per_floor * 0.70,
                    12: max_occupancy_per_floor * 0.55,
                    14: max_occupancy_per_floor * 0.70,
                    18: max_occupancy_per_floor * 0.45,
                    21: max_occupancy_per_floor * 0.20,
                    23: max_occupancy_per_floor * 0.10,
                },
                weekend_profile={
                    0: max_occupancy_per_floor * 0.12,
                    8: max_occupancy_per_floor * 0.20,
                    12: max_occupancy_per_floor * 0.35,
                    18: max_occupancy_per_floor * 0.22,
                    23: max_occupancy_per_floor * 0.12,
                },
            ),
        )
        siggen.add_hvac_period(HeatingPeriod(building_data.heating_period[0], building_data.heating_period[1], weekday_profile={0: building_data.low_heating_setpoint, 7: building_data.normal_heating_setpoint}, weekend_profile={00: building_data.low_heating_setpoint, 7: building_data.normal_heating_setpoint}))
        siggen.add_hvac_period(CoolingPeriod(building_data.cooling_period[0], building_data.cooling_period[1], weekday_profile={0: None, 10: building_data.normal_cooling_setpoint, 18: None}, weekend_profile={0: None, 10: building_data.normal_cooling_setpoint, 18: None}))
        if building_data.long_absence_period is not None:
            siggen.add_long_absence_period(LongAbsencePeriod(building_data.long_absence_period[0], building_data.long_absence_period[1]))
        else:
            siggen.add_long_absence_period(LongAbsencePeriod(building_data.long_absence_period[0], building_data.long_absence_period[1]))
        # Create per-floor signals
        controllers: dict[str, TemperatureController] = {}

        for zone_floor in zone_floors:
            zone_floor.make(model_maker, self.dp)
            # Occupancy profile and HVAC seasons
            if isinstance(zone_floor, PrismBasementZone):
                # Unoccupied, no windows, no HVAC; no Q:basement-outdoor (see airflow loop above).
                # RC links: basement ↔ ground (TZ:ground), ↔ outdoor, ↔ floor0 — see PrismBasementZone.make.
                # PZ = GAIN with GAIN = 0; PHVAC = 0. Basement never uses siggen.generate (no MODE/SETPOINT schedule).
                n_steps: int = len(self.dp.ks)
                zeros: list[float] = [0.0] * n_steps
                self.dp.add_var(f'GAIN_SOLAR:{zone_floor.name}', zeros)
                self.dp.add_var(f'OCCUPANCY:{zone_floor.name}', zeros)
                self.dp.add_var(f'PRESENCE:{zone_floor.name}', [0] * n_steps)
                self.dp.add_var(f'GAIN_OCCUPANCY:{zone_floor.name}', zeros)
                self.dp.add_var(f'GAIN:{zone_floor.name}', zeros)
                self.dp.add_var(f'PCO2:{zone_floor.name}', zeros)
            else:
                # Regular floors: generate signals (SETPOINT, MODE, OCCUPANCY, PRESENCE)
                siggen.generate(zone_floor.name)
                # Get solar gain (returns None if no collectors)
                solar_gain = zone_floor.solar_system.powers_W(gather_collectors=True)
                # Handle case where there are no collectors (solar_gain is None)
                if solar_gain is None:
                    solar_gain = [0.0 for _ in self.dp.ks]
                # Apply shutter control: set solar gains to 0 when outdoor temperature exceeds threshold
                if building_data.shutter_closed_temperature is not None:
                    weather_temperature = self.dp.series('weather_temperature')
                    solar_gain = [0.0 if weather_temperature[k] > building_data.shutter_closed_temperature else solar_gain[k] for k in self.dp.ks]
                self.dp.add_var(f'GAIN_SOLAR:{zone_floor.name}', solar_gain)
                # Add solar to gains
                zone_occupancy: list[float | None] = self.dp.series(f'OCCUPANCY:{zone_floor.name}')

                # Handle None values in occupancy (convert None to 0 for gain calculation)
                # OCCUPANCY contains the actual number of occupants (0 to max_occupancy), not a ratio
                # Total occupancy gain = body_metabolism + occupant_consumption (activities/appliances)
                occupancy_gain: list[float] = [(building_data.body_metabolism + building_data.occupant_consumption) * (_ if _ is not None else 0.0) for _ in zone_occupancy]
                self.dp.add_var(f'GAIN_OCCUPANCY:{zone_floor.name}', occupancy_gain)
                self.dp.add_var(f'GAIN:{zone_floor.name}', [occupancy_gain[k] + solar_gain[k] for k in self.dp.ks])
                self.dp.add_var(f'PCO2:{zone_floor.name}', (siggen.filter(zone_occupancy, lambda x: x * building_data.body_PCO2 if x is not None else 0)))

        model_maker.zones_to_simulate({floor.name: floor.volume_m3 for floor in zone_floors})
        # Nominal state model - must be created before TemperatureControllers
        model_maker.nominal
        if self.building_data.initial_temperature is not None:
            self._initialize_state_models(model_maker, self.building_data.initial_temperature)

        # Create HVAC controllers after nominal state model is ready
        for zone_floor in zone_floors:
            if isinstance(zone_floor, PrismZoneFloor):
                hvac_port: HVACcontinuousModePort = HVACcontinuousModePort(data_provider=self.dp, zone_name=zone_floor.name, max_floor_heating_power=building_data.max_floor_heating_power, max_floor_cooling_power=building_data.max_floor_cooling_power)
                temperature_setpoint_port: TemperatureSetpointPort = TemperatureSetpointPort(data_provider=self.dp, zone_name=zone_floor.name, heating_levels=[16, 19, 20, 21, 22, 23, 24], cooling_levels=[24, 25, 26, 27, 28])
                controllers[zone_floor.name] = TemperatureController(hvac_heat_port=hvac_port, temperature_setpoint_port=temperature_setpoint_port, model_maker=model_maker)

        self.simulation: Simulation = Simulation(model_maker, body_metabolism=building_data.body_metabolism, occupant_consumption=building_data.occupant_consumption)
        for zone_floor in zone_floors:
            if isinstance(zone_floor, PrismZoneFloor):
                self.simulation.add_temperature_controller(zone_name=zone_floor.name, temperature_controller=controllers[zone_floor.name])

    def _initialize_state_models(self, model_maker: ModelMaker, temperature: float) -> None:
        def _set_uniform_initial_state(state_model: StateModel, temp: float) -> StateModel:
            if state_model is None or state_model.n_states == 0:
                return state_model
            target_state: np.ndarray = np.full((state_model.n_states, 1), float(temp))
            state_model.set_state(target_state)
            return state_model

        if hasattr(model_maker, "state_models_cache"):
            model_maker.state_models_cache = {
                key: _set_uniform_initial_state(sm, temperature) for key, sm in model_maker.state_models_cache.items()
            }

        nominal_model: StateModel | None = getattr(model_maker, "nominal_state_model", None)
        if nominal_model is not None:
            _set_uniform_initial_state(nominal_model, temperature)

        original_make_k = model_maker.make_k

        def make_k_with_initial_state(self, *args, **kwargs):
            state_model: StateModel = original_make_k(*args, **kwargs)
            return _set_uniform_initial_state(state_model, temperature)

        model_maker.make_k = types.MethodType(make_k_with_initial_state, model_maker)

    def _calculate_hvac_electric_consumption(self, heat_production_Wh: list[float]) -> list[float]:
        """Calculate HVAC electrical consumption from heat production using appropriate COP."""
        return [
            production / self.building_data.hvac_cop_heating if production > 0
            else production / self.building_data.hvac_cop_cooling
            for production in heat_production_Wh
        ]

    def _initialize_ventilation_heat_recovery_efficiency(self, suffix: str = 'sim') -> None:
        """Initialize ventilation heat recovery efficiency with default values per floor.

        Initializes RECOV variables with regular_ventilation_heat_recovery_efficiency.
        These will be updated during simulation based on free cooling conditions.
        Adds RECOV variables to fingerprint so model is rebuilt when they change.
        """
        # Format suffix with # prefix if not empty (e.g., 'sim' -> '#sim')
        if suffix:
            suffix_formatted = f'#{suffix}' if not suffix.startswith('#') else suffix
        else:
            suffix_formatted = ''

        # Process each floor separately
        recovery_var_names = []
        for floor in self.zone_floors:
            if isinstance(floor, PrismBasementZone):
                continue

            recovery_var_name = f'RECOV:{floor.name}{suffix_formatted}'
            recovery_var_names.append(recovery_var_name)
            # Initialize with regular efficiency for all time steps
            efficiency_values = [self.building_data.regular_ventilation_heat_recovery_efficiency] * len(self.dp.ks)
            self.dp.add_var(recovery_var_name, efficiency_values)
            # Set bounds for fingerprint calculation (efficiency ranges from 0.0 to 1.0)
            # Use a small range to avoid division by zero, but allow for 0.0 to 1.0
            if hasattr(self.dp, 'independent_variable_set'):
                self.dp.independent_variable_set.variable_bounds[recovery_var_name] = (0.0, 1.0)

        # Add RECOV variables to fingerprint so model is rebuilt when they change
        if recovery_var_names:
            self.dp.add_data_names_in_fingerprint(*recovery_var_names)
            # Also add to model maker's fingerprint list (accessed through simulation)
            if hasattr(self, 'simulation') and self.simulation is not None:
                model_maker = self.simulation.model_maker
                for recovery_var_name in recovery_var_names:
                    if recovery_var_name not in model_maker.data_names_in_fingerprint:
                        model_maker.data_names_in_fingerprint = recovery_var_name

    def _update_ventilation_heat_recovery_efficiency_at_k(self, k: int, suffix: str = 'sim', pre_control_outputs: dict = None) -> None:
        """Update ventilation heat recovery efficiency at time step k based on previous time step conditions.

        Updates RECOV[k] based on conditions from time step k-1 (or k=0 for first time step).
        This allows RECOV[k] to affect the model at time step k.

        Free cooling (RECOV=0) is active when:
        - HVAC mode is not heating (mode != 1) AND
        - Indoor temperature > normal_heating_setpoint + free_cooling_setpoint_margin (too hot) AND
        - (outdoor temperature + free_cooling_setpoint_margin) < indoor temperature (outdoor is cooler)

        Otherwise sets it to regular_ventilation_heat_recovery_efficiency.
        """
        if self.building_data.free_cooling_setpoint_margin is None:
            return

        # Format suffix with # prefix if not empty
        if suffix:
            suffix_formatted = f'#{suffix}' if not suffix.startswith('#') else suffix
        else:
            suffix_formatted = ''

        # Process each floor separately
        for floor in self.zone_floors:
            if isinstance(floor, PrismBasementZone):
                continue

            recovery_var_name = f'RECOV:{floor.name}{suffix_formatted}'
            mode_var_name = f'MODE:{floor.name}{suffix_formatted}'
            indoor_temp_var_name = f'TZ_OP:{floor.name}{suffix_formatted}'

            try:
                # Use previous time step's conditions to determine RECOV[k]
                # For k=0, use k=0 (will use defaults if not available)
                prev_k = max(0, k - 1)

                # Get outdoor temp for current time step k
                outdoor_temp_k = self.dp('weather_temperature', k)

                # Try to get mode from previous time step
                try:
                    mode = self.dp(mode_var_name, prev_k)
                except Exception:
                    # If not available, default to heating mode
                    mode = 1

                # Try to get indoor temp from previous time step
                try:
                    indoor_temp = self.dp(indoor_temp_var_name, prev_k)
                except Exception:
                    # If not available, use outdoor temp as fallback
                    indoor_temp = self.dp('weather_temperature', prev_k) if prev_k >= 0 else outdoor_temp_k

                # Free cooling condition:
                # 1. Mode is not heating (mode != 1) AND
                # 2. Indoor temp > normal_heating_setpoint + free_cooling_setpoint_margin (too hot) AND
                # 3. (outdoor temp + free_cooling_setpoint_margin) < indoor temp (outdoor is cooler)
                if (mode != 1 and  # mode 1 is heating
                        indoor_temp > (self.building_data.normal_heating_setpoint + self.building_data.free_cooling_setpoint_margin) and
                        (outdoor_temp_k + self.building_data.free_cooling_setpoint_margin) < indoor_temp):
                    # Free cooling active: disable heat recovery
                    efficiency_k = 0.0
                else:
                    # Use regular efficiency
                    efficiency_k = self.building_data.regular_ventilation_heat_recovery_efficiency

                # Update RECOV at time step k (this will be used for the model at time step k)
                # Note: This updates RECOV[k] which affects the fingerprint, so the model will be rebuilt
                self.dp(recovery_var_name, k, efficiency_k)
            except Exception:
                # If update fails, keep existing value
                pass

    def simulate(self, suffix: str = 'sim') -> BuildingResult:
        """Run the building simulation and return results.

        If free_cooling_setpoint_margin is defined, RECOV is updated during simulation
        at each time step based on previous time step conditions (to avoid circular dependency).
        """
        # Initialize RECOV variables with default values before simulation
        self._initialize_ventilation_heat_recovery_efficiency(suffix=suffix)

        # Define action rule to update RECOV at each time step (called before state model is built)
        def update_recovery_action_rule(simulation, k: int) -> None:
            """Action rule to update RECOV[k] based on previous time step (k-1) conditions."""
            self._update_ventilation_heat_recovery_efficiency_at_k(k, suffix=suffix)

        # Run simulation with action rule to update RECOV during simulation
        if self.building_data.free_cooling_setpoint_margin is not None:
            self.simulation.run(suffix=suffix, action_rule=update_recovery_action_rule)
        else:
            self.simulation.run(suffix=suffix)

        floor_results: list[FloorResult] = []

        # Calculate HVAC consumption for each floor
        for floor in self.zone_floors:
            if isinstance(floor, PrismZoneFloor):
                phvac_var_name: str = f'PHVAC:{floor.name}#sim'
                phvac_production_Wh: list[float] = self.dp.series(phvac_var_name)
            else:
                phvac_production_Wh = [0.0] * len(self.dp.ks)

            floor_results.append(FloorResult(
                zone_key=floor.name,
                external_envelope_surface_m2=floor.external_envelope_surface_m2,
                heat_production_Wh=phvac_production_Wh
            ))

        self.building_result: BuildingResult = BuildingResult(
            datetimes=self.datetimes,
            hvac_cop_heating=self.building_data.hvac_cop_heating,
            hvac_cop_cooling=self.building_data.hvac_cop_cooling,
            floor_results=floor_results
        )

        # Store building-level results
        building_heat_production_Wh: list[float] = self.building_result.heat_production_Wh
        self.dp.add_var('PHVAC:building#sim', building_heat_production_Wh)  # , force=True
        self.dp.add_var('HVAC_ELEC:building#sim', self._calculate_hvac_electric_consumption(building_heat_production_Wh))

        # Store floor-level results
        for floor_result in floor_results:
            # Use force=True to allow overwriting variables that may have been created during simulation
            # self.dp.add_var(f'PHVAC:{floor_result.zone_key}#sim', floor_result.heat_production_Wh) # , force=True
            self.dp.add_var(f'HVAC_ELEC:{floor_result.zone_key}#sim', self._calculate_hvac_electric_consumption(floor_result.heat_production_Wh))

        return self.building_result

    def _print_hvac_power_recommendations(self) -> None:
        """Print recommended HVAC power sizing based on peak and top 5% average demands.

        Analyzes the HVAC power time series to recommend appropriate heating and cooling
        capacities. The maximum value represents absolute peak demand, while the top 5%
        average provides a more robust sizing recommendation that avoids over-sizing for
        rare extreme events.
        """
        print("\n" + "=" * 30)
        print("RECOMMENDED HVAC POWER SIZING")
        print("=" * 30)

        # Collect data per floor and building-wide
        floor_recommendations: list[dict] = []
        all_heating_powers: list[float] = []
        all_cooling_powers: list[float] = []

        for floor in self.zone_floors:
            if f'PHVAC:{floor.name}#sim' in self.dp:
                phvac_series = self.dp.series(f'PHVAC:{floor.name}#sim')

                # Separate heating and cooling for this floor
                floor_heating_powers: list[float] = [p for p in phvac_series if p > 0]
                floor_cooling_powers: list[float] = [abs(p) for p in phvac_series if p < 0]

                # Calculate floor-level recommendations
                floor_rec = {'floor_name': floor.name}

                if floor_heating_powers:
                    max_heating = max(floor_heating_powers)
                    sorted_heating = sorted(floor_heating_powers, reverse=True)
                    top_5_count = max(1, int(len(sorted_heating) * 0.05))
                    avg_top_5_heating = sum(sorted_heating[:top_5_count]) / top_5_count
                    floor_rec['max_heating_kW'] = max_heating / 1000
                    floor_rec['avg5_heating_kW'] = avg_top_5_heating / 1000
                    all_heating_powers.extend(floor_heating_powers)
                else:
                    floor_rec['max_heating_kW'] = 0.0
                    floor_rec['avg5_heating_kW'] = 0.0

                if floor_cooling_powers:
                    max_cooling = max(floor_cooling_powers)
                    sorted_cooling = sorted(floor_cooling_powers, reverse=True)
                    top_5_count = max(1, int(len(sorted_cooling) * 0.05))
                    avg_top_5_cooling = sum(sorted_cooling[:top_5_count]) / top_5_count
                    floor_rec['max_cooling_kW'] = max_cooling / 1000
                    floor_rec['avg5_cooling_kW'] = avg_top_5_cooling / 1000
                    all_cooling_powers.extend(floor_cooling_powers)
                else:
                    floor_rec['max_cooling_kW'] = 0.0
                    floor_rec['avg5_cooling_kW'] = 0.0

                floor_recommendations.append(floor_rec)

        # Print per-floor recommendations
        if floor_recommendations:
            print("\nPer-Floor Recommendations:")
            print("-" * 30)
            for rec in floor_recommendations:
                floor_name = rec['floor_name']

                # Heating line
                if rec['max_heating_kW'] > 0:
                    print(f"  {floor_name:15s} - Heating: {rec['max_heating_kW']:5.1f} kW ({rec['avg5_heating_kW']:5.1f} kW @5%)", end="")
                else:
                    print(f"  {floor_name:15s} - Heating: None", end="")

                # Cooling line
                if rec['max_cooling_kW'] > 0:
                    print(f"   |   Cooling: {rec['max_cooling_kW']:5.1f} kW ({rec['avg5_cooling_kW']:5.1f} kW @5%)")
                else:
                    print("   |   Cooling: None")

        print("=" * 30 + "\n")

    def print_results(self, augmented: bool = False, report_name: str = None) -> None:
        """Print building and floor-level HVAC results in a formatted table.

        Displays heat needs (total, heating, cooling) and electric consumption
        for each floor and the building total, including per m² values.

        :param augmented: If True, includes detailed comfort assessment per floor
        :type augmented: bool
        :param report_name: If provided, generates a markdown report with this name in the results folder
        :type report_name: str | None
        """

        if self.building_result is None:
            # Try to get results from stored variables if available
            try:
                floor_results: list[FloorResult] = []
                for floor in self.zone_floors:
                    phvac_var_name: str = f'PHVAC:{floor.name}#sim'
                    if phvac_var_name in self.dp:
                        phvac_production_Wh: list[float] = self.dp.series(phvac_var_name)
                    else:
                        phvac_production_Wh = [0.0] * len(self.dp.ks)

                    floor_results.append(FloorResult(
                        zone_key=floor.name,
                        external_envelope_surface_m2=floor.external_envelope_surface_m2,
                        heat_production_Wh=phvac_production_Wh
                    ))

                self.building_result = BuildingResult(
                    hvac_cop_heating=self.building_data.hvac_cop_heating,
                    hvac_cop_cooling=self.building_data.hvac_cop_cooling,
                    floor_results=floor_results
                )
            except Exception:
                raise ValueError("No building_result provided and cannot reconstruct from stored data. Please run simulate() first or provide a BuildingResult.")

        # Collect data for all floors
        floor_data: list[dict] = []
        floor_names: list[str] = []

        for floor_result in self.building_result.floor_results:
            # Calculate totals in kWh
            heat_heating_kWh = sum(floor_result.heat_production_heating_Wh) / 1000.0
            heat_cooling_kWh = sum(floor_result.heat_production_cooling_Wh) / 1000.0  # Keep negative for cooling
            # Total heat is the sum of absolute values of heating and cooling
            heat_total_kWh = abs(heat_heating_kWh) + abs(heat_cooling_kWh)

            # Calculate electric consumption (use absolute value for cooling when calculating electricity)
            elec_heating_kWh = heat_heating_kWh / self.building_result.hvac_cop_heating if heat_heating_kWh > 0 else 0.0
            elec_cooling_kWh = abs(heat_cooling_kWh) / self.building_result.hvac_cop_cooling if heat_cooling_kWh < 0 else 0.0
            elec_total_kWh = elec_heating_kWh + elec_cooling_kWh

            # Calculate per m² values using external_envelope_surface_m2
            surface = floor_result.external_envelope_surface_m2
            heat_total_per_m2 = heat_total_kWh / surface if surface > 0 else 0.0
            heat_heating_per_m2 = heat_heating_kWh / surface if surface > 0 else 0.0
            heat_cooling_per_m2 = heat_cooling_kWh / surface if surface > 0 else 0.0
            elec_total_per_m2 = elec_total_kWh / surface if surface > 0 else 0.0
            elec_heating_per_m2 = elec_heating_kWh / surface if surface > 0 else 0.0
            elec_cooling_per_m2 = elec_cooling_kWh / surface if surface > 0 else 0.0

            floor_names.append(floor_result.zone_key)
            floor_data.append({
                'surface': surface,
                'heat_total_kWh': heat_total_kWh,
                'heat_heating_kWh': heat_heating_kWh,
                'heat_cooling_kWh': heat_cooling_kWh,
                'elec_total_kWh': elec_total_kWh,
                'elec_heating_kWh': elec_heating_kWh,
                'elec_cooling_kWh': elec_cooling_kWh,
                'heat_total_per_m2': heat_total_per_m2,
                'heat_heating_per_m2': heat_heating_per_m2,
                'heat_cooling_per_m2': heat_cooling_per_m2,
                'elec_total_per_m2': elec_total_per_m2,
                'elec_heating_per_m2': elec_heating_per_m2,
                'elec_cooling_per_m2': elec_cooling_per_m2
            })

        # Calculate building totals as sum of floor values (excluding basement)
        # Exclude basement from totals since it has no HVAC
        building_heat_heating_kWh = sum(data['heat_heating_kWh'] for name, data in zip(floor_names, floor_data) if name != "basement")
        building_heat_cooling_kWh = sum(data['heat_cooling_kWh'] for name, data in zip(floor_names, floor_data) if name != "basement")  # Keep negative for cooling
        # Total heat is the sum of absolute values of heating and cooling
        building_heat_total_kWh = sum(data['heat_total_kWh'] for name, data in zip(floor_names, floor_data) if name != "basement")

        building_elec_heating_kWh = sum(data['elec_heating_kWh'] for name, data in zip(floor_names, floor_data) if name != "basement")
        building_elec_cooling_kWh = sum(data['elec_cooling_kWh'] for name, data in zip(floor_names, floor_data) if name != "basement")
        building_elec_total_kWh = sum(data['elec_total_kWh'] for name, data in zip(floor_names, floor_data) if name != "basement")

        building_surface = sum(data['surface'] for name, data in zip(floor_names, floor_data) if name != "basement")
        building_heat_total_per_m2 = building_heat_total_kWh / building_surface if building_surface > 0 else 0.0
        building_heat_heating_per_m2 = building_heat_heating_kWh / building_surface if building_surface > 0 else 0.0
        building_heat_cooling_per_m2 = building_heat_cooling_kWh / building_surface if building_surface > 0 else 0.0
        building_elec_total_per_m2 = building_elec_total_kWh / building_surface if building_surface > 0 else 0.0
        building_elec_heating_per_m2 = building_elec_heating_kWh / building_surface if building_surface > 0 else 0.0
        building_elec_cooling_per_m2 = building_elec_cooling_kWh / building_surface if building_surface > 0 else 0.0

        # Add building total to floor_names and floor_data
        floor_names.append("BUILDING TOTAL")
        floor_data.append({
            'surface': building_surface,
            'heat_total_kWh': building_heat_total_kWh,
            'heat_heating_kWh': building_heat_heating_kWh,
            'heat_cooling_kWh': building_heat_cooling_kWh,
            'elec_total_kWh': building_elec_total_kWh,
            'elec_heating_kWh': building_elec_heating_kWh,
            'elec_cooling_kWh': building_elec_cooling_kWh,
            'heat_total_per_m2': building_heat_total_per_m2,
            'heat_heating_per_m2': building_heat_heating_per_m2,
            'heat_cooling_per_m2': building_heat_cooling_per_m2,
            'elec_total_per_m2': building_elec_total_per_m2,
            'elec_heating_per_m2': building_elec_heating_per_m2,
            'elec_cooling_per_m2': building_elec_cooling_per_m2
        })

        # Create transposed table with metrics as rows and floors as columns
        table = prettytable.PrettyTable()
        table.field_names = ["Metric"] + floor_names

        # Add rows for each metric with both kWh and kWh/m²
        table.add_row(["External envelope (m²)"] + [f"{int(round(data['surface']))}" for data in floor_data])
        table.add_row([""] + [""] * len(floor_names))  # Empty row for spacing

        table.add_row(["Heat Total (kWh)"] + [f"{int(round(data['heat_total_kWh']))}" for data in floor_data])
        table.add_row(["Heat Total (kWh/m²)"] + [f"{int(round(data['heat_total_per_m2']))}" for data in floor_data])
        table.add_row([""] + [""] * len(floor_names))  # Empty row for spacing

        table.add_row(["Heat Heating (kWh)"] + [f"{int(round(data['heat_heating_kWh']))}" for data in floor_data])
        table.add_row(["Heat Heating (kWh/m²)"] + [f"{int(round(data['heat_heating_per_m2']))}" for data in floor_data])
        table.add_row([""] + [""] * len(floor_names))  # Empty row for spacing

        table.add_row(["Heat Cooling (kWh)"] + [f"{int(round(data['heat_cooling_kWh']))}" for data in floor_data])
        table.add_row(["Heat Cooling (kWh/m²)"] + [f"{int(round(data['heat_cooling_per_m2']))}" for data in floor_data])
        table.add_row([""] + [""] * len(floor_names))  # Empty row for spacing

        table.add_row(["Elec Total (kWh)"] + [f"{int(round(data['elec_total_kWh']))}" for data in floor_data])
        table.add_row(["Elec Total (kWh/m²)"] + [f"{int(round(data['elec_total_per_m2']))}" for data in floor_data])
        table.add_row([""] + [""] * len(floor_names))  # Empty row for spacing

        table.add_row(["Elec Heating (kWh)"] + [f"{int(round(data['elec_heating_kWh']))}" for data in floor_data])
        table.add_row(["Elec Heating (kWh/m²)"] + [f"{int(round(data['elec_heating_per_m2']))}" for data in floor_data])
        table.add_row([""] + [""] * len(floor_names))  # Empty row for spacing

        table.add_row(["Elec Cooling (kWh)"] + [f"{int(round(data['elec_cooling_kWh']))}" for data in floor_data])
        table.add_row(["Elec Cooling (kWh/m²)"] + [f"{int(round(data['elec_cooling_per_m2']))}" for data in floor_data])

        # Set alignment - left for metric column, right for all floor columns
        table.align["Metric"] = "l"
        for floor_name in floor_names:
            table.align[floor_name] = "r"

        # Print table
        print("\n" + "=" * 30)
        print("BUILDING HVAC RESULTS")
        print("=" * 30)
        print(f"COP Heating: {self.building_result.hvac_cop_heating:.2f} | COP Cooling: {self.building_result.hvac_cop_cooling:.2f}")
        print("=" * 30)
        print(table)
        print("=" * 30 + "\n")

        # Calculate and print recommended HVAC power sizing
        self._print_hvac_power_recommendations()

        total_energy_needs: float = 0
        # Print comfort assessment summary for all floors
        # Configure preference with HVAC COPs so energy costs are calculated correctly
        # Assuming mode 1 = heating, mode -1 = cooling (you may need to adjust based on your mode conventions)
        preference: Preference = Preference(
            mode_cop={
                1: self.building_data.hvac_cop_heating,
                -1: self.building_data.hvac_cop_cooling
            }
        )
        floor_comfort_data: list[dict] = []
        for floor in self.zone_floors:
            print(f'\n##### Zone {floor.name} ######\n')
            envelope_surface: float = getattr(floor, 'external_envelope_surface_m2', self.building_data.footprint_surface_m2)
            if f'PHVAC:{floor.name}#sim' in self.dp:
                floor_energy_needs: float = sum([abs(_) for _ in self.dp.series(f'PHVAC:{floor.name}#sim')])
                cooling_energy_needs: float = sum([abs(_) for _ in self.dp.series(f'PHVAC:{floor.name}#sim') if _ < 0])
                heating_energy_needs: float = sum([abs(_) for _ in self.dp.series(f'PHVAC:{floor.name}#sim') if _ > 0])
                print(f'Floor {floor.name} HVAC system consumption: {round(floor_energy_needs/1000/envelope_surface)} kWh/m2.year (cooling: {round(cooling_energy_needs/1000/envelope_surface)} kWh/m2.year, heating: {round(heating_energy_needs/1000/envelope_surface)} kWh/m2.year)')
                total_energy_needs += floor_energy_needs

                # Get MODE data if available for accurate cost calculation
                modes_data = self.dp.series(f'MODE:{floor.name}') if f'MODE:{floor.name}' in self.dp else None

                if augmented:
                    preference.print_assessment(
                        self.dp.datetimes,
                        self.dp.series(f'PHVAC:{floor.name}#sim'),
                        self.dp.series(f'TZ_OP:{floor.name}#sim'),
                        self.dp.series(f'CCO2:{floor.name}#sim'),
                        self.dp.series(f'OCCUPANCY:{floor.name}'),
                        modes=modes_data
                    )

                # Collect floor data for comfort summary table
                floor_comfort_data.append({
                    'floor_name': floor.name,
                    'datetimes': self.dp.datetimes,
                    'PHVAC': self.dp.series(f'PHVAC:{floor.name}#sim'),
                    'temperatures': self.dp.series(f'TZ_OP:{floor.name}#sim'),
                    'CO2_concentrations': self.dp.series(f'CCO2:{floor.name}#sim'),
                    'occupancies': self.dp.series(f'OCCUPANCY:{floor.name}'),
                    'modes': modes_data
                })
            elif f'TZ_OP:{floor.name}#sim' in self.dp:
                # Simulated zone without HVAC (e.g. basement): still report thermal / air quality outputs
                temps = self.dp.series(f'TZ_OP:{floor.name}#sim')
                print(
                    f'Zone {floor.name} has no HVAC (free-floating). '
                    f'Mean operative temperature {float(np.mean(temps)):.1f} °C '
                    f'(min {float(np.min(temps)):.1f}, max {float(np.max(temps)):.1f}).'
                )
                cco2_key = f'CCO2:{floor.name}#sim'
                cco2_series: list[float] = self.dp.series(cco2_key) if cco2_key in self.dp else [0.0] * len(self.dp.ks)
                phvac_zeros = [0.0] * len(self.dp.ks)
                if augmented:
                    preference.print_assessment(
                        self.dp.datetimes,
                        phvac_zeros,
                        temps,
                        cco2_series,
                        self.dp.series(f'OCCUPANCY:{floor.name}'),
                        modes=None,
                    )
                floor_comfort_data.append({
                    'floor_name': floor.name,
                    'datetimes': self.dp.datetimes,
                    'PHVAC': phvac_zeros,
                    'temperatures': temps,
                    'CO2_concentrations': cco2_series,
                    'occupancies': self.dp.series(f'OCCUPANCY:{floor.name}'),
                    'modes': None,
                })
            else:
                print(f'Floor {floor.name} has no HVAC system and no simulated operative temperature in the data provider.')

        # Print compact comfort summary table for all floors
        if floor_comfort_data:
            preference.print_comfort(floor_comfort_data)

        # Generate markdown report if requested
        if report_name is not None:
            self._generate_markdown_report(
                report_name=report_name,
                floor_names=floor_names,
                floor_data=floor_data,
                floor_comfort_data=floor_comfort_data,
                preference=preference
            )

    def _generate_markdown_report(
        self,
        report_name: str,
        floor_names: list[str],
        floor_data: list[dict],
        floor_comfort_data: list[dict],
        preference: Preference
    ) -> None:
        """Generate a markdown report with building simulation results.

        :param report_name: Name of the markdown file (without extension)
        :param floor_names: List of floor names
        :param floor_data: List of dictionaries containing floor data
        :param floor_comfort_data: List of dictionaries containing comfort data
        :param preference: Preference object for comfort calculations
        """
        import os

        # Get results folder path
        file_path_builder = FilePathBuilder()
        results_folder = file_path_builder.get_work_folder("results")

        # Create figures subfolder
        figures_folder = os.path.join(results_folder, "figures")
        os.makedirs(figures_folder, exist_ok=True)

        # Ensure .md extension
        if not report_name.endswith('.md'):
            report_name += '.md'

        report_path = os.path.join(results_folder, report_name)

        # Generate markdown content
        markdown_content = []

        # Title
        markdown_content.append("# Building HVAC Simulation Results\n")
        markdown_content.append(f"*Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*\n\n")

        # Add 3D building visualization
        markdown_content.append("## 3D Building View\n\n")
        try:
            building_3d_filename = f"{report_name.replace('.md', '')}_building_3d.png"
            building_3d_path = os.path.join(figures_folder, building_3d_filename)
            self.save_building_plot(building_3d_path)
            markdown_content.append(f"![3D Building View](figures/{building_3d_filename})\n\n")
            markdown_content.append(
                f"*Building geometry with {self.building_data.n_floors} floors, "
                f"footprint area: {self.building_data.footprint_surface_m2:.1f} m²*\n\n"
            )
        except Exception as e:
            print(f"Warning: Could not generate 3D building plot: {e}")
            markdown_content.append("*3D building visualization not available*\n\n")

        # COP Information
        markdown_content.append("## HVAC System Configuration\n")
        markdown_content.append(f"- **Heating COP**: {self.building_result.hvac_cop_heating:.2f}\n")
        markdown_content.append(f"- **Cooling COP**: {self.building_result.hvac_cop_cooling:.2f}\n\n")

        # Add recommended HVAC power sizing
        markdown_content.append("## Recommended HVAC Power Sizing\n\n")
        markdown_content.append("Recommended HVAC capacities based on peak demand and top 5% average:\n\n")

        # Calculate recommended powers (same logic as _print_hvac_power_recommendations)
        floor_recommendations: list[dict] = []
        for floor in self.zone_floors:
            if f'PHVAC:{floor.name}#sim' in self.dp:
                phvac_series = self.dp.series(f'PHVAC:{floor.name}#sim')

                floor_heating_powers: list[float] = [p for p in phvac_series if p > 0]
                floor_cooling_powers: list[float] = [abs(p) for p in phvac_series if p < 0]

                floor_rec = {'floor_name': floor.name}

                if floor_heating_powers:
                    max_heating = max(floor_heating_powers)
                    sorted_heating = sorted(floor_heating_powers, reverse=True)
                    top_5_count = max(1, int(len(sorted_heating) * 0.05))
                    avg_top_5_heating = sum(sorted_heating[:top_5_count]) / top_5_count
                    floor_rec['max_heating_kW'] = max_heating / 1000
                    floor_rec['avg5_heating_kW'] = avg_top_5_heating / 1000
                else:
                    floor_rec['max_heating_kW'] = 0.0
                    floor_rec['avg5_heating_kW'] = 0.0

                if floor_cooling_powers:
                    max_cooling = max(floor_cooling_powers)
                    sorted_cooling = sorted(floor_cooling_powers, reverse=True)
                    top_5_count = max(1, int(len(sorted_cooling) * 0.05))
                    avg_top_5_cooling = sum(sorted_cooling[:top_5_count]) / top_5_count
                    floor_rec['max_cooling_kW'] = max_cooling / 1000
                    floor_rec['avg5_cooling_kW'] = avg_top_5_cooling / 1000
                else:
                    floor_rec['max_cooling_kW'] = 0.0
                    floor_rec['avg5_cooling_kW'] = 0.0

                floor_recommendations.append(floor_rec)

        if floor_recommendations:
            markdown_content.append("| Floor | Heating (max) | Heating (@5%) | Cooling (max) | Cooling (@5%) |\n")
            markdown_content.append("|-------|---------------|---------------|---------------|---------------|\n")
            for rec in floor_recommendations:
                heating_max = f"{rec['max_heating_kW']:.1f} kW" if rec['max_heating_kW'] > 0 else "None"
                heating_5 = f"{rec['avg5_heating_kW']:.1f} kW" if rec['avg5_heating_kW'] > 0 else "None"
                cooling_max = f"{rec['max_cooling_kW']:.1f} kW" if rec['max_cooling_kW'] > 0 else "None"
                cooling_5 = f"{rec['avg5_cooling_kW']:.1f} kW" if rec['avg5_cooling_kW'] > 0 else "None"
                markdown_content.append(f"| {rec['floor_name']} | {heating_max} | {heating_5} | {cooling_max} | {cooling_5} |\n")
            markdown_content.append("\n*@5%: Average of the top 5% highest power values*\n\n")

        # Main results table
        markdown_content.append("## Energy Consumption Summary\n\n")

        # Create markdown table
        markdown_content.append("| Metric | " + " | ".join(floor_names) + " |\n")
        markdown_content.append("|" + "---|" * (len(floor_names) + 1) + "\n")

        # Add data rows
        markdown_content.append("| **External envelope (m²)** | " + " | ".join([f"{int(round(data['surface']))}" for data in floor_data]) + " |\n")
        markdown_content.append("| | " + " | ".join([""] * len(floor_names)) + " |\n")

        markdown_content.append("| **Heat Total (kWh)** | " + " | ".join([f"{int(round(data['heat_total_kWh']))}" for data in floor_data]) + " |\n")
        markdown_content.append("| **Heat Total (kWh/m²)** | " + " | ".join([f"{int(round(data['heat_total_per_m2']))}" for data in floor_data]) + " |\n")
        markdown_content.append("| | " + " | ".join([""] * len(floor_names)) + " |\n")

        markdown_content.append("| **Heat Heating (kWh)** | " + " | ".join([f"{int(round(data['heat_heating_kWh']))}" for data in floor_data]) + " |\n")
        markdown_content.append("| **Heat Heating (kWh/m²)** | " + " | ".join([f"{int(round(data['heat_heating_per_m2']))}" for data in floor_data]) + " |\n")
        markdown_content.append("| | " + " | ".join([""] * len(floor_names)) + " |\n")

        markdown_content.append("| **Heat Cooling (kWh)** | " + " | ".join([f"{int(round(data['heat_cooling_kWh']))}" for data in floor_data]) + " |\n")
        markdown_content.append("| **Heat Cooling (kWh/m²)** | " + " | ".join([f"{int(round(data['heat_cooling_per_m2']))}" for data in floor_data]) + " |\n")
        markdown_content.append("| | " + " | ".join([""] * len(floor_names)) + " |\n")

        markdown_content.append("| **Elec Total (kWh)** | " + " | ".join([f"{int(round(data['elec_total_kWh']))}" for data in floor_data]) + " |\n")
        markdown_content.append("| **Elec Total (kWh/m²)** | " + " | ".join([f"{int(round(data['elec_total_per_m2']))}" for data in floor_data]) + " |\n")
        markdown_content.append("| | " + " | ".join([""] * len(floor_names)) + " |\n")

        markdown_content.append("| **Elec Heating (kWh)** | " + " | ".join([f"{int(round(data['elec_heating_kWh']))}" for data in floor_data]) + " |\n")
        markdown_content.append("| **Elec Heating (kWh/m²)** | " + " | ".join([f"{int(round(data['elec_heating_per_m2']))}" for data in floor_data]) + " |\n")
        markdown_content.append("| | " + " | ".join([""] * len(floor_names)) + " |\n")

        markdown_content.append("| **Elec Cooling (kWh)** | " + " | ".join([f"{int(round(data['elec_cooling_kWh']))}" for data in floor_data]) + " |\n")
        markdown_content.append("| **Elec Cooling (kWh/m²)** | " + " | ".join([f"{int(round(data['elec_cooling_per_m2']))}" for data in floor_data]) + " |\n")
        markdown_content.append("\n")

        # Add comfort summary if available
        if floor_comfort_data:
            markdown_content.append("## Comfort Assessment Summary\n\n")

            # Calculate comfort metrics for each floor using the same logic as print_comfort
            comfort_metrics = []
            for floor_data_item in floor_comfort_data:
                datetimes = floor_data_item['datetimes']
                temperatures = floor_data_item['temperatures']
                co2_concentrations = floor_data_item['CO2_concentrations']
                occupancies = floor_data_item['occupancies']
                phvac = floor_data_item['PHVAC']
                modes = floor_data_item.get('modes')

                # Calculate metrics using Preference methods
                hours = [dt.hour for dt in datetimes]
                thermal_dis = preference.thermal_comfort_dissatisfaction(temperatures, occupancies, hours) * 100
                co2_dis = preference.air_quality_dissatisfaction(co2_concentrations, occupancies) * 100
                comfort_dis = preference.comfort_dissatisfaction(temperatures, co2_concentrations, occupancies, hours) * 100

                # Calculate temperature quality distribution
                hour_quality_counters = {'extreme cold': 0, 'cold': 0, 'perfect': 0, 'warm': 0, 'extreme warm': 0}
                n_hours_with_presence = 0
                sleeping_hours_set = preference.sleeping_hours

                for k, temperature in enumerate(temperatures):
                    if occupancies[k] > 0:
                        if sleeping_hours_set and hours[k] in sleeping_hours_set:
                            continue
                        n_hours_with_presence += 1

                        if temperature < preference.extreme_temperatures[0]:
                            hour_quality_counters['extreme cold'] += 1
                        elif temperature < preference.preferred_temperatures[0]:
                            hour_quality_counters['cold'] += 1
                        elif temperature > preference.extreme_temperatures[1]:
                            hour_quality_counters['extreme warm'] += 1
                        elif temperature > preference.preferred_temperatures[1]:
                            hour_quality_counters['warm'] += 1
                        else:
                            hour_quality_counters['perfect'] += 1

                perfect_pct = (100 * hour_quality_counters['perfect'] / n_hours_with_presence) if n_hours_with_presence > 0 else 0.0
                cold_pct = (100 * hour_quality_counters['cold'] / n_hours_with_presence) if n_hours_with_presence > 0 else 0.0
                warm_pct = (100 * hour_quality_counters['warm'] / n_hours_with_presence) if n_hours_with_presence > 0 else 0.0
                extreme_pct = (100 * (hour_quality_counters['extreme cold'] + hour_quality_counters['extreme warm']) / n_hours_with_presence) if n_hours_with_presence > 0 else 0.0

                # ICONE indicator and daily electricity cost (€/day)
                icone_value = preference.icone(co2_concentrations, occupancies)
                daily_cost = preference.daily_cost_euros(phvac, modes, power_unit='Wh')

                comfort_metrics.append({
                    'floor': floor_data_item['floor_name'],
                    'thermal_discomfort': thermal_dis,
                    'co2_discomfort': co2_dis,
                    'comfort_discomfort': comfort_dis,
                    'perfect': perfect_pct,
                    'cold': cold_pct,
                    'warm': warm_pct,
                    'extreme': extreme_pct,
                    'icone': icone_value,
                    'daily_cost_eur': daily_cost
                })

            # Create comfort table
            markdown_content.append("| Metric | " + " | ".join([m['floor'] for m in comfort_metrics]) + " |\n")
            markdown_content.append("|" + "---|" * (len(comfort_metrics) + 1) + "\n")
            markdown_content.append("| **Thermal Discomfort (%)** | " + " | ".join([f"{m['thermal_discomfort']:.1f}" for m in comfort_metrics]) + " |\n")
            markdown_content.append("| **CO2 Discomfort (%)** | " + " | ".join([f"{m['co2_discomfort']:.1f}" for m in comfort_metrics]) + " |\n")
            markdown_content.append("| **Overall Discomfort (%)** | " + " | ".join([f"{m['comfort_discomfort']:.1f}" for m in comfort_metrics]) + " |\n")
            markdown_content.append("| | " + " | ".join([""] * len(comfort_metrics)) + " |\n")
            markdown_content.append("| **Perfect (%)** | " + " | ".join([f"{m['perfect']:.1f}" for m in comfort_metrics]) + " |\n")
            markdown_content.append("| **Cold (%)** | " + " | ".join([f"{m['cold']:.1f}" for m in comfort_metrics]) + " |\n")
            markdown_content.append("| **Warm (%)** | " + " | ".join([f"{m['warm']:.1f}" for m in comfort_metrics]) + " |\n")
            markdown_content.append("| **Extreme (%)** | " + " | ".join([f"{m['extreme']:.1f}" for m in comfort_metrics]) + " |\n")
            markdown_content.append("| **ICONE** | " + " | ".join([f"{m['icone']:.2f}" for m in comfort_metrics]) + " |\n")
            markdown_content.append("| **Electricity Cost (€/day)** | " + " | ".join([f"{m['daily_cost_eur']:.2f}" for m in comfort_metrics]) + " |\n")
            markdown_content.append("\n")

            # Add comfort definitions
            markdown_content.append("### Comfort Definitions\n\n")
            markdown_content.append("**Thermal Comfort Zones:**\n")
            markdown_content.append(f"- **Preferred temperature range**: {preference.preferred_temperatures[0]:.1f}°C to {preference.preferred_temperatures[1]:.1f}°C\n")
            markdown_content.append(f"- **Extreme temperature bounds**: {preference.extreme_temperatures[0]:.1f}°C to {preference.extreme_temperatures[1]:.1f}°C\n")
            markdown_content.append("- **Perfect**: Temperature within preferred range\n")
            markdown_content.append("- **Cold**: Below preferred range but above extreme cold\n")
            markdown_content.append("- **Warm**: Above preferred range but below extreme warm\n")
            markdown_content.append("- **Extreme**: Outside extreme temperature bounds\n\n")

            markdown_content.append("**Air Quality:**\n")
            markdown_content.append(f"- **Preferred CO₂ concentration**: {preference.preferred_CO2_concentration[0]:.0f} to {preference.preferred_CO2_concentration[1]:.0f} ppm\n")
            markdown_content.append(f"- **Thermal weight vs CO₂**: {preference.temperature_weight_wrt_CO2:.2f}\n")
            markdown_content.append(f"- **Energy cost weight vs comfort**: {preference.power_weight_wrt_comfort:.2f}\n\n")

            if preference.sleeping_hours:
                sleeping_hours_str = ", ".join([str(h) for h in sorted(preference.sleeping_hours)])
                markdown_content.append(f"**Sleeping hours** (excluded from thermal comfort): {sleeping_hours_str}\n\n")

        # Add heliodon plots section
        markdown_content.append("## Solar Access Analysis (Heliodon Plots)\n\n")
        markdown_content.append("The following diagrams show the sun path and solar access for each floor's windows, " +
                                "including horizon masks and obstacles.\n\n")

        # Generate and save heliodon plots for each floor
        heliodon_images = []
        for floor in self.zone_floors:
            if isinstance(floor, PrismBasementZone):
                continue  # Skip basement

            try:
                # Generate heliodon plot
                axes = self.plot_heliodon(floor.floor_index)

                if axes is not None:
                    # Get the current figure
                    fig = plt.gcf()

                    # Save figure to figures subfolder
                    heliodon_filename = f"{report_name.replace('.md', '')}_heliodon_{floor.name}.png"
                    heliodon_path = os.path.join(figures_folder, heliodon_filename)
                    fig.savefig(heliodon_path, dpi=150, bbox_inches='tight')
                    plt.close(fig)  # Close the figure to free memory

                    heliodon_images.append({
                        'floor': floor.name,
                        'filename': f"figures/{heliodon_filename}",  # Relative path from results folder
                        'elevation': floor.mid_elevation
                    })
            except Exception as e:
                print(f"Warning: Could not generate heliodon plot for {floor.name}: {e}")
                continue

        # Add heliodon images to markdown
        if heliodon_images:
            for img_info in heliodon_images:
                markdown_content.append(f"### {img_info['floor']} (Elevation: {img_info['elevation']:.1f}m)\n\n")
                markdown_content.append(f"![Heliodon for {img_info['floor']}]({img_info['filename']})\n\n")
        else:
            markdown_content.append("*No heliodon plots available (no windows or solar data)*\n\n")

        # Add building parameters section
        markdown_content.append("## Building Parameters\n\n")
        markdown_content.append("### Geometry\n")
        markdown_content.append(f"- **Footprint area**: {self.building_data.footprint_surface_m2:.2f} m²\n")
        markdown_content.append(f"- **Perimeter**: {self.building_data.perimeter_m:.2f} m\n")
        markdown_content.append(f"- **Façade segments**: {self.building_data.n_sides}\n")
        markdown_content.append(f"- **Number of floors**: {self.building_data.n_floors}\n")
        markdown_content.append(f"- **Floor height**: {self.building_data.floor_height:.2f} m\n")
        markdown_content.append(f"- **Base elevation**: {self.building_data.base_elevation:.2f} m\n")
        markdown_content.append(f"- **Rotation angle**: {self.building_data.z_rotation_angle_deg:.1f}°\n\n")

        markdown_content.append("### Glazing\n")
        ratios_summary: str = ", ".join(f"{r:.0%}" for r in self.building_data.side_glazing_ratios)
        markdown_content.append(f"- **Glazing ratio per façade segment**: {ratios_summary}\n")
        markdown_content.append(f"- **Glazing solar factor**: {self.building_data.glazing_solar_factor:.2f}\n")
        if self.building_data.shutter_closed_temperature is not None:
            markdown_content.append(f"- **Shutter closed temperature**: {self.building_data.shutter_closed_temperature:.1f}°C\n")
        markdown_content.append("\n")

        # Add wall compositions with surfaces
        markdown_content.append("### Wall Compositions and Surfaces\n\n")

        # Calculate U-values for each composition type
        composition_u_values = {}

        for comp_name, layers in self.building_data.compositions.items():
            try:
                # Determine position based on composition type
                if comp_name in ['roof', 'ground_floor', 'basement_floor', 'intermediate_floor']:
                    position = 'horizontal'
                    first_layer_indoor = True
                    last_layer_indoor = False
                    heating_floor = (comp_name == 'ground_floor')
                else:  # wall
                    position = 'vertical'
                    first_layer_indoor = True
                    last_layer_indoor = False
                    heating_floor = False

                # Create composition to calculate U-value
                comp = Composition(
                    first_layer_indoor=first_layer_indoor,
                    last_layer_indoor=last_layer_indoor,
                    position=position,
                    indoor_average_temperature_in_celsius=20,
                    outdoor_average_temperature_in_celsius=5,
                    wind_speed_is_m_per_sec=2.4,
                    heating_floor=heating_floor
                )
                for material, thickness in layers:
                    comp.layer(material, thickness)

                composition_u_values[comp_name] = comp.U
            except (KeyError, ValueError, AttributeError):
                # Material not in library or calculation error - show as N/A
                composition_u_values[comp_name] = None
            except Exception:
                # Other errors - also show as N/A
                composition_u_values[comp_name] = None

        # Calculate wall surfaces per side for each floor
        markdown_content.append("**Wall Compositions:**\n\n")
        markdown_content.append("| Component | U-value (W/m²·K) | Layers |\n")
        markdown_content.append("|-----------|------------------|--------|\n")
        has_na = False
        for comp_name, layers in self.building_data.compositions.items():
            u_value = composition_u_values.get(comp_name, None)
            u_str = f"{u_value:.3f}" if u_value is not None else "N/A"
            if u_value is None:
                has_na = True
            layers_str = ", ".join([f"{mat}({th*1000:.0f}mm)" for mat, th in layers])
            markdown_content.append(f"| {comp_name} | {u_str} | {layers_str} |\n")
        if has_na:
            markdown_content.append("\n*Note: N/A indicates that U-value could not be calculated (material may need to be loaded into properties library)*\n")
        markdown_content.append("\n")

        # Add wall and glazing surfaces per side for each floor
        markdown_content.append("**Surfaces per Side (per floor):**\n\n")
        markdown_content.append("| Floor | Side | Wall Surface (m²) | Glazing Surface (m²) | Normal Direction (°) |\n")
        markdown_content.append("|-------|------|-------------------|----------------------|----------------------|\n")

        bd = self.building_data
        for floor in self.zone_floors:
            if isinstance(floor, PrismBasementZone):
                continue
            for i in range(bd.n_sides):
                wall_surface_side = bd.sides_plain_floor_vsurface_m2[i]
                glazing_surface = bd.sides_glazing_floor_vsurface_m2[i]
                normal_angle = bd.sides_exposure_deg[i] % 360
                markdown_content.append(
                    f"| {floor.name} | side{i} | {wall_surface_side:.1f} | {glazing_surface:.1f} | {normal_angle:.1f}° |\n"
                )

        for floor in self.zone_floors:
            if isinstance(floor, PrismZoneFloor) and floor.floor_index == bd.n_floors - 1:
                roof_surface = bd.footprint_surface_m2
                markdown_content.append(f"| {floor.name} | roof | {roof_surface:.1f} | 0.0 | 90.0° (up) |\n")
                break

        markdown_content.append("\n")
        markdown_content.append("*Normal direction: azimuth angle in degrees (0° = South, 90° = West, 180° = North, 270° = East)*\n\n")

        markdown_content.append("### HVAC Control\n")
        markdown_content.append(f"- **Low heating setpoint**: {self.building_data.low_heating_setpoint:.1f}°C\n")
        markdown_content.append(f"- **Normal heating setpoint**: {self.building_data.normal_heating_setpoint:.1f}°C\n")
        markdown_content.append(f"- **Normal cooling setpoint**: {self.building_data.normal_cooling_setpoint:.1f}°C\n")
        markdown_content.append(f"- **Heating period**: {self.building_data.heating_period[0]} to {self.building_data.heating_period[1]}\n")
        markdown_content.append(f"- **Cooling period**: {self.building_data.cooling_period[0]} to {self.building_data.cooling_period[1]}\n")
        markdown_content.append(f"- **Max heating power**: {self.building_data.max_floor_heating_power/1000:.1f} kW\n")
        markdown_content.append(f"- **Max cooling power**: {self.building_data.max_floor_cooling_power/1000:.1f} kW\n")
        markdown_content.append(f"- **Heat recovery efficiency**: {self.building_data.regular_ventilation_heat_recovery_efficiency:.1%}\n")
        markdown_content.append(f"- **Air renewal rate**: {self.building_data.regular_air_renewal_rate_vol_per_hour:.2f} vol/h\n")
        if self.building_data.free_cooling_setpoint_margin is not None:
            markdown_content.append(f"- **Free cooling setpoint margin**: {self.building_data.free_cooling_setpoint_margin:.1f}°C\n")
        markdown_content.append("\n")

        markdown_content.append("### Occupancy\n")
        markdown_content.append(f"- **Density**: {self.building_data.density_occupants_per_100m2:.1f} occupants per 100 m²\n")
        markdown_content.append(f"- **Body metabolism**: {self.building_data.body_metabolism:.0f} W per person (at 20°C)\n")
        markdown_content.append(f"- **Occupant consumption**: {self.building_data.occupant_consumption:.0f} W per person\n")
        markdown_content.append(f"- **CO₂ production**: {self.building_data.body_PCO2:.1f} L/h per person\n")
        if self.building_data.long_absence_period:
            markdown_content.append(f"- **Long absence period**: {self.building_data.long_absence_period[0]} to {self.building_data.long_absence_period[1]}\n")
        markdown_content.append("\n")

        markdown_content.append("### Simulation Settings\n")
        markdown_content.append(f"- **Initial temperature**: {self.building_data.initial_temperature:.1f}°C\n")
        if self.building_data.state_model_order_max is not None:
            markdown_content.append(f"- **State model order max**: {self.building_data.state_model_order_max}\n")
        markdown_content.append(f"- **Periodic depth**: {self.building_data.periodic_depth_seconds:.0f} seconds\n")
        markdown_content.append("\n")

        # Write to file
        with open(report_path, 'w', encoding='utf-8') as f:
            f.writelines(markdown_content)

        print(f"\n✓ Markdown report generated: {report_path}")
        if heliodon_images:
            print(f"✓ Generated {len(heliodon_images)} heliodon plot(s)\n")
        else:
            print()

        # Generate PDF if possible
        self._generate_pdf_from_markdown(report_path, results_folder)

    def _generate_pdf_from_markdown(self, markdown_path: str, output_folder: str) -> None:
        """Generate a PDF from the markdown report if PDF conversion tools are available.

        Tries multiple methods in order:
        1. pypandoc (requires pandoc installed)
        2. markdown + weasyprint (HTML to PDF)
        3. markdown + xhtml2pdf (HTML to PDF)

        :param markdown_path: Path to the markdown file
        :param output_folder: Folder where PDF should be saved
        """
        import os
        import tempfile

        # Generate PDF filename
        pdf_filename = os.path.splitext(os.path.basename(markdown_path))[0] + '.pdf'
        pdf_path = os.path.join(output_folder, pdf_filename)

        # Method 1: Try pypandoc (requires pandoc binary)
        try:
            import pypandoc
            base_dir = os.path.dirname(os.path.abspath(markdown_path))

            # Read markdown content and replace Unicode characters with LaTeX-safe equivalents
            with open(markdown_path, 'r', encoding='utf-8') as f:
                md_content = f.read()

            # Replace Unicode characters that cause LaTeX issues
            # Use simple text replacements that work with standard LaTeX
            unicode_replacements = {
                '₂': '$_{2}$',  # Subscript 2 (CO₂ -> CO$_{2}$)
                '₀': '$_{0}$',  # Subscript 0
                '₁': '$_{1}$',  # Subscript 1
                '₃': '$_{3}$',  # Subscript 3
                '²': '$^{2}$',  # Superscript 2 (m² -> m$^{2}$)
                '³': '$^{3}$',  # Superscript 3
                '°': '$^{\\circ}$',  # Degree symbol (°C -> $^{\circ}$C)
                '·': '$\\cdot$',  # Middle dot (in math mode)
            }

            md_content_safe = md_content
            for unicode_char, latex_replacement in unicode_replacements.items():
                md_content_safe = md_content_safe.replace(unicode_char, latex_replacement)

            # Write to temporary markdown file with safe characters
            temp_md_file = tempfile.NamedTemporaryFile(mode='w', suffix='.md', delete=False, encoding='utf-8')
            temp_md_file.write(md_content_safe)
            temp_md_file.close()
            temp_md_path = temp_md_file.name

            # Create a temporary LaTeX header file for better formatting
            header_file = tempfile.NamedTemporaryFile(mode='w', suffix='.tex', delete=False, encoding='utf-8')
            header_file.write('\\usepackage{extsizes}\n')
            header_file.write('\\usepackage{graphicx}\n')
            header_file.write('\\usepackage{float}\n')
            header_file.write('\\usepackage{amsmath}\n')  # For math mode support
            header_file.write('\\renewcommand{\\normalsize}{\\fontsize{11pt}{13pt}\\selectfont}\n')
            header_file.write('\\renewcommand{\\small}{\\fontsize{10pt}{12pt}\\selectfont}\n')
            header_file.write('\\renewcommand{\\footnotesize}{\\fontsize{9pt}{11pt}\\selectfont}\n')
            header_file.close()

            extra_args = [
                '--resource-path', base_dir,
                '--variable', 'geometry=margin=0.75in',
                '--variable', 'linestretch=1.0',
                '--variable', 'documentclass=article',
                '--variable', 'fontsize=11pt',
                '--variable', 'toc-depth=2',
                '--include-in-header', header_file.name
            ]

            # Try XeLaTeX first (better Unicode support), fall back to pdflatex
            try:
                output = pypandoc.convert_file(
                    temp_md_path, 'pdf', outputfile=pdf_path,
                    extra_args=extra_args + ['--pdf-engine=xelatex']
                )
            except Exception:
                # Fall back to pdflatex
                output = pypandoc.convert_file(
                    temp_md_path, 'pdf', outputfile=pdf_path,
                    extra_args=extra_args + ['--pdf-engine=pdflatex']
                )

            assert output == "", "Error during conversion"

            # Clean up temporary files
            try:
                os.unlink(header_file.name)
                os.unlink(temp_md_path)
            except Exception:
                pass

            # Clean up temporary header file
            try:
                os.unlink(header_file.name)
            except Exception:
                pass

            print(f"✓ PDF report generated: {pdf_path}")
            return

        except ImportError:
            pass  # pypandoc not available
        except Exception as e:
            # pypandoc available but conversion failed
            print(f"⚠ PDF generation with pypandoc failed: {e}")

        # Method 2: Try markdown + weasyprint
        try:
            import markdown
            from weasyprint import HTML, CSS

            # Read markdown file
            with open(markdown_path, 'r', encoding='utf-8') as f:
                md_content = f.read()

            # Convert markdown to HTML
            html_content = markdown.markdown(md_content, extensions=['tables', 'fenced_code'])

            # Add basic CSS styling
            css_content = """
            @page {
                size: A4;
                margin: 0.75in;
            }
            body {
                font-family: Arial, sans-serif;
                font-size: 11pt;
                line-height: 1.4;
            }
            h1 { font-size: 18pt; margin-top: 0.5em; margin-bottom: 0.3em; }
            h2 { font-size: 16pt; margin-top: 0.5em; margin-bottom: 0.3em; }
            h3 { font-size: 14pt; margin-top: 0.4em; margin-bottom: 0.2em; }
            table { border-collapse: collapse; width: 100%; margin: 1em 0; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; font-weight: bold; }
            img { max-width: 100%; height: auto; }
            code { background-color: #f4f4f4; padding: 2px 4px; border-radius: 3px; }
            pre { background-color: #f4f4f4; padding: 10px; border-radius: 5px; overflow-x: auto; }
            """

            # Generate PDF
            HTML(string=html_content, base_url=os.path.dirname(markdown_path)).write_pdf(
                pdf_path,
                stylesheets=[CSS(string=css_content)]
            )

            print(f"✓ PDF report generated: {pdf_path}")
            return

        except ImportError:
            pass  # weasyprint not available
        except Exception as e:
            print(f"⚠ PDF generation with weasyprint failed: {e}")

        # Method 3: Try markdown + xhtml2pdf
        try:
            import markdown

            # Read markdown file
            with open(markdown_path, 'r', encoding='utf-8') as f:
                md_content = f.read()

            # Convert markdown to HTML
            html_content = markdown.markdown(md_content, extensions=['tables', 'fenced_code'])

            # Add basic CSS styling
            html_with_style = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <style>
                    @page {{
                        size: A4;
                        margin: 0.75in;
                    }}
                    body {{
                        font-family: Arial, sans-serif;
                        font-size: 11pt;
                        line-height: 1.4;
                    }}
                    h1 {{ font-size: 18pt; margin-top: 0.5em; margin-bottom: 0.3em; }}
                    h2 {{ font-size: 16pt; margin-top: 0.5em; margin-bottom: 0.3em; }}
                    h3 {{ font-size: 14pt; margin-top: 0.4em; margin-bottom: 0.2em; }}
                    table {{ border-collapse: collapse; width: 100%; margin: 1em 0; }}
                    th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
                    th {{ background-color: #f2f2f2; font-weight: bold; }}
                    img {{ max-width: 100%; height: auto; }}
                </style>
            </head>
            <body>
            {html_content}
            </body>
            </html>
            """

            # Generate PDF
            with open(pdf_path, 'wb') as pdf_file:
                pisa.CreatePDF(html_with_style, dest=pdf_file)

            print(f"✓ PDF report generated: {pdf_path}")
            return

        except ImportError:
            pass  # xhtml2pdf not available
        except Exception as e:
            print(f"⚠ PDF generation with xhtml2pdf failed: {e}")

        # If all methods failed
        print("⚠ PDF generation skipped: No PDF conversion tools available. Install 'pypandoc' (requires pandoc), 'weasyprint', or 'xhtml2pdf' to generate PDF reports.")

    def draw_context_side_masks(self, plotter: Plotter) -> None:
        """Draw 3D obstacles from ``ContextData.side_masks`` (``Context.side_mask_views``)."""
        for side_mask_view in self.context.side_mask_views:
            side_mask_view.draw(plotter)

    def draw(self, window_size: tuple[int, int] = (1024, 768)) -> None:
        """Display the 3D building visualization in an interactive window.

        :param window_size: Window size in pixels (width, height)
        :type window_size: tuple[int, int]
        """
        plotter: Plotter = pv.Plotter(window_size=window_size)
        plotter.set_background("white")
        plotter.clear()
        if self.building_view is not None:
            self.building_view.draw(plotter)
        ground: PolyData = pv.Plane(center=(0, 0, 0), direction=(0, 0, 1), i_size=60, j_size=60)
        plotter.add_mesh(ground, color="#DDDDDD", opacity=1)
        self.draw_context_side_masks(plotter)
        plotter.add_axes(line_width=2)
        plotter.show_bounds(grid="front", location="outer", all_edges=True, xtitle="X (North -> South)", ytitle="Y (West -> East)", ztitle="Z (Up)")
        plotter.enable_eye_dome_lighting()
        plotter.camera_position = [(25, -35, 25), (0, 0, 5), (0, 0, 1)]
        plotter.show(auto_close=False)

    def save_building_plot(self, output_path: str, window_size: tuple[int, int] = (1600, 1200)) -> None:
        """Save the 3D building visualization to an image file.

        Automatically frames the entire building in view with a 3/4 perspective angle.

        :param output_path: Path where the image will be saved
        :type output_path: str
        :param window_size: Window size in pixels (width, height) for rendering
        :type window_size: tuple[int, int]
        """
        plotter: Plotter = pv.Plotter(off_screen=True, window_size=window_size)
        plotter.set_background("white")
        plotter.clear()
        if self.building_view is not None:
            self.building_view.draw(plotter)
        ground: PolyData = pv.Plane(center=(0, 0, 0), direction=(0, 0, 1), i_size=60, j_size=60)
        plotter.add_mesh(ground, color="#DDDDDD", opacity=1)
        self.draw_context_side_masks(plotter)
        plotter.add_axes(line_width=2)
        plotter.show_bounds(grid="front", location="outer", all_edges=True, xtitle="X (North -> South)", ytitle="Y (West -> East)", ztitle="Z (Up)")
        plotter.enable_eye_dome_lighting()

        # Reset camera to fit all actors (building, ground, masks, etc.)
        plotter.reset_camera()

        # Get the bounds of all actors to calculate building center and size
        bounds = plotter.renderer.ComputeVisiblePropBounds()
        if bounds[0] < bounds[1]:  # Check if we have valid bounds
            # Calculate building center
            center_x = (bounds[0] + bounds[1]) / 2
            center_y = (bounds[2] + bounds[3]) / 2
            center_z = (bounds[4] + bounds[5]) / 2

            # Calculate building dimensions
            size_x = bounds[1] - bounds[0]
            size_y = bounds[3] - bounds[2]
            size_z = bounds[5] - bounds[4]
            max_size = max(size_x, size_y, size_z)

            # Set camera position for a 3/4 perspective view
            # Position camera at a distance proportional to building size
            distance = max_size * 2.5
            camera_position = [
                center_x + distance * 0.7,  # Offset in X
                center_y - distance * 0.7,   # Offset in Y (negative for better angle)
                center_z + distance * 0.4     # Offset in Z (elevated view)
            ]
            focal_point = [center_x, center_y, center_z + size_z * 0.3]  # Focus slightly above ground
            view_up = [0, 0, 1]  # Z-axis is up

            plotter.camera_position = [camera_position, focal_point, view_up]

            # Zoom out slightly to ensure everything is visible with some margin
            plotter.camera.zoom(0.9)

        plotter.screenshot(output_path)
        plotter.close()

    def plot_heliodon(self, floor_index: int) -> Any | None:
        """Plot heliodon charts for every window on one occupied storey.

        For each façade glazing, calls :meth:`~batem.core.solar.SolarModel.plot_heliodon` with that
        collector’s mask, ``observer_elevation_m`` at the floor mid-elevation, and the weather year.
        The combined mask is horizon + context distant masks + the window mask.

        :param floor_index: Occupied storey index to plot: ``0`` = ground storey (``floor0``), …, ``n_floors - 1`` = top storey.
        :return: List-like of subplot axes, or ``None`` if the floor has no windows to plot.
        """
        # Get year from weather data if not provided

        first_date: datetime = self.dp.weather_data.datetimes[0]
        year: int = first_date.year
        floor: Any = None
        for f in self.zone_floors:
            if isinstance(f, PrismZoneFloor) and f.floor_index == floor_index:
                floor = f
                break
        if floor is None:
            raise ValueError(f'Occupied storey index {floor_index} not found in building (expected 0 … {self.building_data.n_floors - 1})')
        window_masks_dict: dict[str, Mask] = floor.window_masks()
        if len(window_masks_dict) == 0:
            # Skip floors with no windows (e.g., basement)
            return None

        # Filter windows to only include those with surface > 0
        # Check if floor has window_surfaces attribute (RegularZone) and filter accordingly
        windows_with_surface: dict[str, Mask] = {}
        if hasattr(floor, 'window_surfaces') and hasattr(floor, 'windows_names'):
            for window_name, window_surface in zip(floor.windows_names, floor.window_surfaces):
                if window_name in window_masks_dict and window_surface > 0:
                    windows_with_surface[window_name] = window_masks_dict[window_name]
        else:
            # Fallback: use all windows if we can't check surface
            windows_with_surface = window_masks_dict

        if len(windows_with_surface) == 0:
            # Skip floors with no windows with surface > 0
            return None

        # Calculate grid size based on number of windows
        n_windows = len(windows_with_surface)
        if n_windows == 1:
            n_rows, n_cols = 1, 1
        elif n_windows == 2:
            n_rows, n_cols = 1, 2
        elif n_windows == 3:
            n_rows, n_cols = 2, 2
        else:  # 4 or more
            n_rows, n_cols = 2, 2

        fig, axes = plt.subplots(n_rows, n_cols, figsize=(12, 8))
        if n_windows == 1:
            axes = [axes]  # Make it a list for consistent iteration
        else:
            axes = axes.flatten()  # Flatten 2D array to 1D for easier indexing
        fig.suptitle(f'Heliodon for {floor.name}, Elevation: {floor.mid_elevation:.1f}m', fontsize=12)

        for i, (window_name, window_mask) in enumerate(windows_with_surface.items()):
            if i >= len(axes):
                break  # Safety check: don't exceed available subplots
            self.context.solar_model.plot_heliodon(name=f'Window {window_name}', year=year, observer_elevation_m=floor.mid_elevation, mask=window_mask, axes=axes[i])
            axes[i].set_title(f'Window {window_name}')
            axes[i].set_xlabel('Azimuth in degrees (0° = South, +90° =West)')

        # Hide unused subplots
        for i in range(len(windows_with_surface), len(axes)):
            axes[i].set_visible(False)

        plt.tight_layout()
        return axes


# Consolidated API aliases to indicate unified module ownership.
ComplexBuilding = Building
ComplexBuildingData = BuildingData
