__version__ = "0.7.3"
APP_TITLE = "Adbnik"
