# deped-dcp-template

`deped-dcp-template` is the shared runtime package for DepEd DCP data-cleaning projects. It bundles the [canonical Excel collection templates](https://drive.google.com/drive/folders/1yPXog1LspPTe39lNpNinmTD7rmur8q03), extracts their controlled lists into SQLite lookup tables, and exposes common helpers that downstream personnel, equipment, connectivity, and registry packages should reuse instead of copying locally.

The package is currently versioned as `0.4.0`.

## Install

Published package:

```bash
uv add deped-dcp-template
```

Sibling checkout during local development:

```toml
[tool.uv.sources]
deped-dcp-template = { path = "../deped-dcp-template" }
```

## Main Commands

Build a template-derived lookup database:

```bash
uv run deped-dcp-template extract \
  --templates-dir templates \
  --output artifacts/base.db
```

Show a lookup summary:

```bash
uv run deped-dcp-template show --db artifacts/base.db
```

Upload the canonical templates to R2:

```bash
uv run deped-dcp-template r2 upload \
  --source templates \
  --prefix deped-dcp-template/templates
```

Profile a SQLite table:

```bash
uv run profile-table path/to/data.db table_name
```

## What This Package Owns

- canonical v1.16 workbook templates in `templates/`
- lookup database extraction from the school, division, and region templates
- R2 source-artifact upload, download, and listing helpers
- Rich console, logging, status, and progress helpers
- CSV, workbook, timestamp, SQL-file, and normalization helpers
- governance entity and personnel primitives with no consumer schema dependency
- the `profile-table` SQLite profiling CLI

Consumer repos still own operational CSV ingestion, domain schemas, views,
promotion workflows, public table contracts, and final audit artifacts.

## Documentation

- [Docs index](docs/index.md)
- [Architecture](docs/architecture.md)
- [Lookup extraction](docs/lookup-extraction.md)
- [R2 transfer](docs/r2-transfer.md)
- [Normalization helpers](docs/normalization.md)
- [File and SQL helpers](docs/file-sql-helpers.md)
- [Rich logging and progress](docs/rich-logging.md)
- [SQLite profiling](docs/profiling.md)
- [Downstream adoption](docs/downstream-adoption.md)

Build the docs:

```bash
uv run zensical build
```

## Development

```bash
uv run pytest -q
uv run zensical build
```

Publish, when credentials are available:

```bash
just publish
```
