"""SQLite and SQL-file helper functions."""

from __future__ import annotations

import importlib.resources as resources
import sqlite3
from pathlib import Path
from types import ModuleType


def quote_identifier(identifier: str) -> str:
    """Return a SQLite-quoted identifier."""
    return '"' + identifier.replace('"', '""') + '"'


def read_sql(path: str | Path, *, package: str | ModuleType | None = None) -> str:
    """Read SQL from a local path or package resource."""
    if package is None:
        return Path(path).read_text(encoding="utf-8")
    return resources.files(package).joinpath(str(path)).read_text(encoding="utf-8")


def execute_sql_script(
    conn: sqlite3.Connection,
    path: str | Path,
    *,
    package: str | ModuleType | None = None,
) -> None:
    """Read and execute a SQL script against a SQLite connection."""
    conn.executescript(read_sql(path, package=package))


def sqlite_table_columns(conn: sqlite3.Connection, table_name: str) -> list[str]:
    """Return column names for a SQLite table or view."""
    rows = conn.execute(f"PRAGMA table_info({quote_identifier(table_name)})").fetchall()
    return [row[1] for row in rows]


def require_sqlite_table_columns(
    conn: sqlite3.Connection,
    table_name: str,
    required_columns: set[str] | list[str] | tuple[str, ...],
) -> list[str]:
    """Validate that a SQLite table has the required columns."""
    existing = set(sqlite_table_columns(conn, table_name))
    missing = [column for column in required_columns if column not in existing]
    if missing:
        formatted = ", ".join(missing)
        raise ValueError(f"{table_name} missing required column(s): {formatted}")
    return sorted(existing)
