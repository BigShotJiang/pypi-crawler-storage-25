"""Cloudflare R2 transfer helpers."""

from __future__ import annotations

import fnmatch
import hashlib
from pathlib import Path, PurePosixPath
from typing import Any, Iterable, Protocol

from botocore.exceptions import ClientError
from r2 import R2Settings, create_client
from pydantic import BaseModel, Field, ValidationError, computed_field
from rich.progress import Progress

from .console import create_progress, get_console

CANONICAL_TEMPLATE_FILENAMES = (
    "ict-equipment-inventory-school-template_v1.16.xlsx",
    "ict-equipment-inventory-division-template_v1.16.xlsx",
    "ict-equipment-inventory-region-template_v1.16.xlsx",
)


class TemplateAsset(BaseModel):
    """Manifest entry for a bundled template workbook."""

    filename: str
    template_version: str
    size: int
    sha256: str
    r2_key: str


class TransferItem(BaseModel):
    """A single transfer result."""

    source: str
    target: str
    key: str
    size: int = 0
    sha256: str | None = None
    status: str


class TransferSummary(BaseModel):
    """Aggregate transfer result."""

    bucket: str
    prefix: str
    items: list[TransferItem] = Field(default_factory=list)

    @computed_field
    @property
    def uploaded(self) -> int:
        return sum(1 for item in self.items if item.status == "uploaded")

    @computed_field
    @property
    def downloaded(self) -> int:
        return sum(1 for item in self.items if item.status == "downloaded")

    @computed_field
    @property
    def skipped(self) -> int:
        return sum(1 for item in self.items if item.status == "skipped")


class R2Client(Protocol):
    def upload(self, file_like: str | Path, key: str, *args: Any, **kwargs: Any): ...

    def download(self, key: str, local_file: str | Path): ...

    def fetch(self, *args: Any, **kwargs: Any) -> dict[str, Any]: ...


class BotoR2Client:
    """Small adapter around the S3-compatible boto3 client used by cloudflare-r2."""

    def __init__(self, client: Any, bucket: str):
        self.client = client
        self.name = bucket

    def upload(self, file_like: str | Path, key: str, *args: Any, **kwargs: Any):
        with open(file_like, "rb") as read_file:
            return self.client.upload_fileobj(read_file, self.name, key, *args, **kwargs)

    def download(self, key: str, local_file: str | Path):
        with open(local_file, "wb") as write_file:
            return self.client.download_fileobj(self.name, key, write_file)

    def fetch(self, *args: Any, **kwargs: Any) -> dict[str, Any]:
        return self.client.list_objects_v2(Bucket=self.name, *args, **kwargs)

    def get(self, key: str) -> dict[str, Any] | None:
        try:
            return self.client.get_object(Bucket=self.name, Key=key)
        except Exception:
            return None


def get_r2_bucket(settings: R2Settings | None = None) -> R2Client:
    """Create a Cloudflare R2 bucket client from settings."""
    resolved = settings or R2Settings()
    return BotoR2Client(create_client(resolved), require_bucket(resolved))


def require_bucket(settings: R2Settings) -> str:
    """Return the configured bucket or raise a clear local error."""
    if not settings.bucket:
        raise RuntimeError("Missing required R2 environment variable(s): R2_BUCKET")
    return settings.bucket


def normalize_r2_prefix(prefix: str | None) -> str:
    """Normalize and validate a remote key prefix."""
    if not prefix:
        return ""
    pure = PurePosixPath(prefix.strip().replace("\\", "/"))
    if pure.is_absolute() or any(part == ".." for part in pure.parts):
        raise ValueError(f"Unsafe R2 prefix: {prefix}")
    return "/".join(part for part in pure.parts if part not in ("", ".")).strip("/")


def build_r2_key(prefix: str | None, relative_path: str | Path) -> str:
    """Build a safe R2 key from a prefix and relative path."""
    normalized_prefix = normalize_r2_prefix(prefix)
    relative = PurePosixPath(str(relative_path).replace("\\", "/"))
    if relative.is_absolute() or any(part == ".." for part in relative.parts):
        raise ValueError(f"Unsafe relative path for R2 key: {relative_path}")
    parts = [part for part in relative.parts if part not in ("", ".")]
    if not parts:
        raise ValueError("R2 key cannot be empty")
    suffix = "/".join(parts)
    return f"{normalized_prefix}/{suffix}" if normalized_prefix else suffix


def sha256_file(path: str | Path) -> str:
    """Return the SHA-256 digest for a local file."""
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def template_manifest(
    templates_dir: str | Path = "templates",
    *,
    prefix: str = "deped-dcp-template/templates",
) -> list[TemplateAsset]:
    """Build the runtime manifest for canonical template workbooks."""
    root = Path(templates_dir)
    assets: list[TemplateAsset] = []
    for filename in CANONICAL_TEMPLATE_FILENAMES:
        path = root / filename
        if not path.exists():
            raise FileNotFoundError(path)
        version = filename.rsplit("_v", 1)[1].removesuffix(".xlsx")
        assets.append(
            TemplateAsset(
                filename=filename,
                template_version=version,
                size=path.stat().st_size,
                sha256=sha256_file(path),
                r2_key=build_r2_key(prefix, filename),
            )
        )
    return assets


def _matches_include(path: Path, patterns: Iterable[str] | None) -> bool:
    if patterns is None:
        return True
    normalized = path.as_posix()
    return any(fnmatch.fnmatch(normalized, pattern) for pattern in patterns)


def iter_upload_files(
    source: str | Path,
    *,
    include: Iterable[str] | None = None,
) -> list[Path]:
    """Return uploadable files, ignoring hidden macOS metadata files."""
    source_path = Path(source)
    if source_path.is_file():
        return [source_path] if source_path.name != ".DS_Store" else []
    if not source_path.is_dir():
        raise FileNotFoundError(source_path)

    if include is None and source_path.name == "templates":
        return [source_path / filename for filename in CANONICAL_TEMPLATE_FILENAMES]

    files: list[Path] = []
    for path in sorted(item for item in source_path.rglob("*") if item.is_file()):
        if path.name == ".DS_Store":
            continue
        relative = path.relative_to(source_path)
        if _matches_include(relative, include):
            files.append(path)
    return files


def remote_object_exists(client: Any, bucket: str, key: str) -> bool:
    """Return whether an R2 object exists using whichever client API is available."""
    meta_client = getattr(getattr(client, "bucket", None), "meta", None)
    boto_client = getattr(meta_client, "client", None)
    if boto_client is None:
        boto_client = getattr(client, "client", None)
    if boto_client is not None and hasattr(boto_client, "head_object"):
        try:
            boto_client.head_object(Bucket=bucket, Key=key)
            return True
        except ClientError as exc:
            code = _client_error_code(exc)
            if code in {"404", "NoSuchKey", "NotFound"}:
                return False
            raise _transfer_error("check", key, exc) from exc
    if hasattr(client, "get"):
        try:
            return client.get(key) is not None
        except ClientError as exc:
            code = _client_error_code(exc)
            if code in {"404", "NoSuchKey", "NotFound"}:
                return False
            raise _transfer_error("check", key, exc) from exc
    return False


def _client_error_code(exc: ClientError) -> str:
    return str(exc.response.get("Error", {}).get("Code", ""))


def _transfer_error(action: str, key: str, exc: Exception) -> RuntimeError:
    if isinstance(exc, ClientError):
        code = _client_error_code(exc)
        message = exc.response.get("Error", {}).get("Message", str(exc))
        if code == "SignatureDoesNotMatch":
            return RuntimeError(
                "R2 rejected the request signature while trying to "
                f"{action} {key!r}. Verify CF_ACCT_ID/R2_ACCOUNT_ID is the "
                "Cloudflare account ID for this bucket, verify the access key "
                "and secret are from the same R2 token, and leave R2_REGION set "
                "to auto unless the bucket requires a specific signing region."
            )
        return RuntimeError(f"R2 {action} failed for {key!r}: {code} {message}")
    return RuntimeError(f"R2 {action} failed for {key!r}: {exc}")


def upload_files(
    source: str | Path,
    *,
    prefix: str | None = None,
    settings: R2Settings | None = None,
    client: R2Client | None = None,
    include: Iterable[str] | None = None,
    overwrite: bool = False,
    dry_run: bool = False,
    progress: Progress | None = None,
) -> TransferSummary:
    """Upload local files to R2."""
    resolved = settings or R2Settings()
    resolved_prefix = prefix if prefix is not None else resolved.prefix
    normalized_prefix = normalize_r2_prefix(resolved_prefix)
    bucket = client or get_r2_bucket(resolved)
    bucket_name = require_bucket(resolved)
    source_path = Path(source)
    files = iter_upload_files(source_path, include=include)
    summary = TransferSummary(bucket=bucket_name, prefix=normalized_prefix)
    own_progress = progress is None
    progress = progress or create_progress(transient=True)

    with progress if own_progress else _nullcontext(progress):
        task_id = progress.add_task(
            "Uploading R2 objects",
            total=sum(path.stat().st_size for path in files),
        )
        for path in files:
            relative = path.name if source_path.is_file() else path.relative_to(source_path)
            key = build_r2_key(normalized_prefix, relative)
            size = path.stat().st_size
            digest = sha256_file(path)
            status = "uploaded"
            if not overwrite and remote_object_exists(bucket, bucket_name, key):
                status = "skipped"
            elif dry_run:
                status = "dry-run"
            else:
                try:
                    bucket.upload(path, key)
                except Exception as exc:
                    raise _transfer_error("upload", key, exc) from exc
            progress.update(task_id, advance=size)
            summary.items.append(
                TransferItem(
                    source=str(path),
                    target=key,
                    key=key,
                    size=size,
                    sha256=digest,
                    status=status,
                )
            )
    return summary


def list_objects(
    *,
    prefix: str | None = None,
    settings: R2Settings | None = None,
    client: R2Client | None = None,
) -> list[dict[str, Any]]:
    """List R2 objects under a prefix, following pagination."""
    resolved = settings or R2Settings()
    resolved_prefix = prefix if prefix is not None else resolved.prefix
    normalized_prefix = normalize_r2_prefix(resolved_prefix)
    bucket = client or get_r2_bucket(resolved)
    objects: list[dict[str, Any]] = []
    continuation_token: str | None = None
    while True:
        kwargs: dict[str, Any] = {}
        if normalized_prefix:
            kwargs["Prefix"] = f"{normalized_prefix}/"
        if continuation_token:
            kwargs["ContinuationToken"] = continuation_token
        response = bucket.fetch(**kwargs)
        objects.extend(response.get("Contents", []))
        if not response.get("IsTruncated"):
            return objects
        continuation_token = response.get("NextContinuationToken")
        if not continuation_token:
            return objects


def _local_target_for_key(target: Path, prefix: str, key: str) -> Path:
    key_path = PurePosixPath(key)
    if prefix and not str(key_path).startswith(f"{prefix}/"):
        raise ValueError(f"Object key is outside prefix: {key}")
    relative_text = str(key_path)[len(prefix) + 1 :] if prefix else str(key_path)
    relative = PurePosixPath(relative_text)
    if relative.is_absolute() or any(part == ".." for part in relative.parts):
        raise ValueError(f"Unsafe R2 object key: {key}")
    output = target.joinpath(*relative.parts).resolve()
    target_root = target.resolve()
    if target_root not in output.parents and output != target_root:
        raise ValueError(f"Unsafe R2 object key: {key}")
    return output


def download_files(
    target: str | Path,
    *,
    prefix: str | None = None,
    settings: R2Settings | None = None,
    client: R2Client | None = None,
    overwrite: bool = False,
    dry_run: bool = False,
    progress: Progress | None = None,
) -> TransferSummary:
    """Download R2 objects under a prefix into a local target directory."""
    resolved = settings or R2Settings()
    resolved_prefix = prefix if prefix is not None else resolved.prefix
    normalized_prefix = normalize_r2_prefix(resolved_prefix)
    bucket = client or get_r2_bucket(resolved)
    bucket_name = require_bucket(resolved)
    target_path = Path(target)
    objects = list_objects(prefix=normalized_prefix, settings=resolved, client=bucket)
    summary = TransferSummary(bucket=bucket_name, prefix=normalized_prefix)
    own_progress = progress is None
    progress = progress or create_progress(transient=True)

    with progress if own_progress else _nullcontext(progress):
        task_id = progress.add_task(
            "Downloading R2 objects",
            total=sum(int(obj.get("Size", 0)) for obj in objects),
        )
        for obj in objects:
            key = obj["Key"]
            output = _local_target_for_key(target_path, normalized_prefix, key)
            size = int(obj.get("Size", 0))
            status = "downloaded"
            if output.exists() and not overwrite:
                status = "skipped"
            elif dry_run:
                status = "dry-run"
            else:
                output.parent.mkdir(parents=True, exist_ok=True)
                try:
                    bucket.download(key, output)
                except Exception as exc:
                    raise _transfer_error("download", key, exc) from exc
            digest = (
                sha256_file(output)
                if output.exists() and status != "dry-run"
                else None
            )
            progress.update(task_id, advance=size)
            summary.items.append(
                TransferItem(
                    source=key,
                    target=str(output),
                    key=key,
                    size=size,
                    sha256=digest,
                    status=status,
                )
            )
    return summary


class _nullcontext:
    def __init__(self, value: Progress):
        self.value = value

    def __enter__(self) -> Progress:
        return self.value

    def __exit__(self, *args: Any) -> None:
        return None


def load_settings_for_cli() -> R2Settings:
    """Load settings and convert Pydantic errors into concise CLI text."""
    try:
        return R2Settings()
    except ValidationError as exc:
        missing = [
            str(error["loc"][0])
            for error in exc.errors()
            if error.get("type") == "missing"
        ]
        if missing:
            joined = ", ".join(missing)
            raise RuntimeError(f"Missing required R2 environment variable(s): {joined}") from exc
        raise RuntimeError(str(exc)) from exc


def print_summary(summary: TransferSummary) -> None:
    """Print a concise transfer summary."""
    console = get_console()
    console.print(summary.model_dump_json(indent=2))
