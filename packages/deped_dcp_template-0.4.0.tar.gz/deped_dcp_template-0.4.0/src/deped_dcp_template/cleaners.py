"""Shared normalization and parsing helpers."""

from __future__ import annotations

import re
from difflib import get_close_matches

from email_validator import EmailNotValidError, validate_email

from .constants import (
    ARABIC_TO_ROMAN,
    BOOLEAN_TRUE_VALUES,
    BRAND_SYNONYMS,
    CANONICAL_POSITION_LOOKUP,
    EMAIL_DOMAIN_FIXES,
    GENERIC_EQUIPMENT_VALUES,
    INVALID_POSITION_PATTERNS,
    LOW_CARDINALITY_ALIASES,
    NORMALIZED_POSITION_MAP,
    NULL_LIKE_VALUES,
    POSITION_FAMILY_PREFIXES,
    POSITION_TYPOS,
    normalize_position_lookup_key,
)
from .normalization import clean_review_text, normalize_label, normalize_review_key
from .timestamps import parse_date


def clean_text(value: str | None) -> str | None:
    """Normalize freeform text and collapse null-like sentinels."""
    return clean_review_text(value)


def normalize_header(value: str | None) -> str:
    """Collapse embedded whitespace in CSV headers."""
    return normalize_label(value)


def normalize_identifier(value: str | None) -> str | None:
    """Normalize numeric-looking identifiers to plain string form."""
    text = clean_text(value)
    if text is None:
        return None
    if re.fullmatch(r"\d+\.0+", text):
        return text.split(".", 1)[0]
    if re.fullmatch(r"\d+(?:\.\d+)?[eE][+-]?\d+", text):
        try:
            return str(int(float(text)))
        except ValueError:
            return text
    return text


def normalize_school_id(value: str | None) -> int | None:
    """Normalize school identifiers to integers."""
    text = normalize_identifier(value)
    if text is None:
        return None
    if text.isdigit():
        return int(text)
    try:
        return int(float(text))
    except ValueError:
        return None


def to_bool_int(value: str | None) -> int:
    """Convert known truthy string values to SQLite-friendly integers."""
    text = clean_text(value)
    if text is None:
        return 0
    return 1 if text.upper() in BOOLEAN_TRUE_VALUES else 0


def normalize_phone(value: str | None) -> tuple[str | None, bool]:
    """Normalize Philippine mobile numbers and flag suspicious scientific notation."""
    text = clean_text(value)
    if text is None:
        return None, False

    suspicious = bool(re.fullmatch(r"\d+(?:\.\d+)?[eE][+-]?\d+", text))
    if suspicious:
        try:
            digits = str(int(float(text)))
        except ValueError:
            digits = re.sub(r"\D", "", text)
    else:
        digits = re.sub(r"\D", "", text)

    if not digits:
        return None, suspicious
    if len(digits) == 10 and digits.startswith("9"):
        digits = f"0{digits}"
    elif len(digits) == 12 and digits.startswith("63"):
        digits = f"0{digits[2:]}"
    return digits, suspicious


def clean_email(value: str | None) -> tuple[str | None, bool]:
    """Normalize email casing and fix common DepEd domain typos."""
    text = clean_text(value)
    if text is None:
        return None, False
    email = text.lower().replace(" ", "")
    if "@" not in email or email.count("@") != 1:
        return None, False
    local, domain = email.split("@", 1)
    if not local or not domain:
        return None, False
    fixed_domain = EMAIL_DOMAIN_FIXES.get(domain, domain)
    bad_domain = fixed_domain != domain
    if (
        domain.startswith("deped")
        and fixed_domain == domain
        and domain != "deped.gov.ph"
    ):
        fixed_domain = "deped.gov.ph"
        bad_domain = True
    return f"{local}@{fixed_domain}", bad_domain


def validate_normalized_email(value: str | None) -> tuple[str | None, bool]:
    """Validate a normalized email address before persistence."""
    if value is None:
        return None, False
    try:
        validated = validate_email(value, check_deliverability=False)
    except EmailNotValidError:
        return None, True
    return validated.normalized, False


def is_valid_deped_domain(domain: str) -> bool:
    """Return whether a domain is an allowed DepEd address domain."""
    return domain == "deped.gov.ph" or bool(
        re.fullmatch(r"[a-z0-9-]+(?:\.[a-z0-9-]+)*\.deped\.gov\.ph", domain)
    )


def repair_deped_domain(domain: str) -> tuple[str, bool]:
    """Repair obvious DepEd domain typos while preserving valid subdomains."""
    normalized_domain = re.sub(r"\.+", ".", domain.strip("."))
    bad_domain = normalized_domain != domain

    if is_valid_deped_domain(normalized_domain):
        return normalized_domain, bad_domain

    prefixed_match = re.fullmatch(r"(?P<prefix>\d+)deped\.gov\.ph", normalized_domain)
    if prefixed_match:
        return "deped.gov.ph", True

    fixed_domain = EMAIL_DOMAIN_FIXES.get(normalized_domain, normalized_domain)
    if fixed_domain != normalized_domain:
        normalized_domain = fixed_domain
        bad_domain = True
    if is_valid_deped_domain(normalized_domain):
        return normalized_domain, bad_domain

    labels = normalized_domain.split(".")
    if len(labels) < 3 or labels[-2:] != ["gov", "ph"]:
        return normalized_domain, bad_domain

    prefix_labels = labels[:-2]
    for tail_size in (1, 2):
        if len(prefix_labels) < tail_size:
            continue
        candidate = "".join(
            re.sub(r"[^a-z0-9]", "", part) for part in prefix_labels[-tail_size:]
        )
        if get_close_matches(candidate, ["deped"], n=1, cutoff=0.8):
            preserved_prefix = prefix_labels[:-tail_size]
            repaired = ".".join([*preserved_prefix, "deped", "gov", "ph"])
            return repaired, True

    return normalized_domain, bad_domain


def clean_deped_email(value: str | None) -> tuple[str | None, bool, str | None]:
    """Normalize DepEd email addresses and reclassify non-DepEd emails."""
    text = clean_text(value)
    if text is None:
        return None, False, None

    email = text.lower().replace(" ", "")
    if "@" not in email or email.count("@") != 1:
        return None, False, None

    local, domain = email.split("@", 1)
    if not local or not domain:
        return None, False, None

    normalized_raw_domain = re.sub(r"\.+", ".", domain.strip("."))
    prefixed_match = re.fullmatch(
        r"(?P<prefix>\d+)deped\.gov\.ph", normalized_raw_domain
    )
    normalized_domain, bad_domain = repair_deped_domain(domain)
    if prefixed_match:
        local = f"{local}{prefixed_match.group('prefix')}"
    if not is_valid_deped_domain(normalized_domain):
        generic_email, _ = clean_email(value)
        return None, False, generic_email

    return f"{local}@{normalized_domain}", bad_domain, None


def parse_cost(value: str | None) -> float | None:
    """Parse currency strings and simple quantity-at-price patterns."""
    text = clean_text(value)
    if text is None:
        return None
    qty_match = re.fullmatch(
        r"(?i)\s*(\d+(?:\.\d+)?)\s*units?\s*@\s*(?:php|₱)?\s*([\d,]+(?:\.\d+)?)\s*",
        text,
    )
    if qty_match:
        return float(qty_match.group(1)) * float(qty_match.group(2).replace(",", ""))
    stripped = re.sub(r"(?i)\bphp\b|₱|,", "", text).strip()
    try:
        return float(stripped)
    except ValueError:
        return None


def parse_float(value: str | None) -> float | None:
    """Parse a freeform numeric field to float."""
    text = clean_text(value)
    if text is None:
        return None
    match = re.search(r"\d+(?:\.\d+)?", text.replace(",", ""))
    if not match:
        return None
    return float(match.group(0))


ROMAN_POSITION_LEVELS = frozenset(ARABIC_TO_ROMAN.values())


def preprocess_position_text(text: str) -> str:
    """Normalize raw position text before key-level matching."""
    preprocessed = text.upper().strip()
    contract_pattern = r"(?:J\.?\s*O\.?|JOB ORDER|COS|CONTRACT OF SERVICE)"
    if not re.fullmatch(
        rf"{contract_pattern}(?:\s*[/,-]\s*{contract_pattern})*", preprocessed
    ):
        preprocessed = re.sub(
            rf"^(?:{contract_pattern})\b\s*[-/:]?\s*", "", preprocessed
        )
        preprocessed = re.sub(
            rf"\s*[-/:]?\s*(?:{contract_pattern})\s*$", "", preprocessed
        )
    if not re.fullmatch(r"[A-Z]{1,5}-\d+", preprocessed):
        preprocessed = re.sub(r"\s*-\s*\d+\s*$", "", preprocessed)
    preprocessed = re.sub(r"[,/]\s*S?\d+\s*$", "", preprocessed)
    preprocessed = re.sub(r"\s*\(.*?\)\s*", " ", preprocessed)
    preprocessed = re.sub(r"\s+REG\.?\s*$", "", preprocessed)
    preprocessed = re.sub(
        r"^(?:ALS\s+)*(?:SENIOR|JUNIOR)\s+HIGH\s+SCHOOL\s*,?\s*TEACHER\b",
        "TEACHER",
        preprocessed,
    )
    preprocessed = re.sub(
        r"^(?:ALS\s+)*(?:SECONDARY|SENIOR HIGH SCHOOL|JUNIOR HIGH SCHOOL)\s+TEACHER\b",
        "TEACHER",
        preprocessed,
    )
    preprocessed = re.sub(
        r"^(?:ALS\s+)*(?:SHS|JHS)\s+TEACHER\b", "TEACHER", preprocessed
    )
    preprocessed = re.sub(r"^(?:ALS\s+)*(?:SHST|JHST)\b", "TEACHER", preprocessed)
    preprocessed = re.sub(
        r"\s+(?:SHS|JHS|ALS|HR|SEF|CTI|ACAD\s*TRACK)\b.*$",
        "",
        preprocessed,
    )
    preprocessed = re.sub(
        r"\s*[-/]\s*(?:SHS|JHS|ALS|SENIOR\s+HIGH\s+SCHOOL|JUNIOR\s+HIGH\s+SCHOOL)\b.*$",
        "",
        preprocessed,
    )
    preprocessed = re.sub(
        r"\s*[-/]?\s*(?:OIC|CONCURRENT|SECTION\s*HEAD|UNIT\s*HEAD).*$",
        "",
        preprocessed,
    )
    return re.sub(r"\s+", " ", preprocessed).strip()


def normalize_position_key(text: str) -> str:
    """Build a normalized lookup key from preprocessed position text."""
    return normalize_position_lookup_key(text)


def normalize_position_level(level: str) -> str | None:
    """Return a canonical Roman numeral level when the token looks valid."""
    if level in ARABIC_TO_ROMAN:
        return ARABIC_TO_ROMAN[level]
    if re.fullmatch(r"1{1,4}", level):
        return "I" * len(level)
    if level in ROMAN_POSITION_LEVELS:
        return level
    return None


def expand_position_family(normalized: str) -> str | None:
    """Expand compact position families like TIII or ADAS II."""
    prefixes = sorted(POSITION_FAMILY_PREFIXES.items(), key=lambda item: -len(item[0]))
    for prefix, title in prefixes:
        for pattern in (
            rf"^{re.escape(prefix)}\s+(?P<level>[A-Z0-9]+)$",
            rf"^{re.escape(prefix)}-(?P<level>[A-Z0-9]+)$",
            rf"^{re.escape(prefix)}(?P<level>[A-Z0-9]+)$",
        ):
            match = re.fullmatch(pattern, normalized)
            if not match:
                continue
            level = normalize_position_level(match.group("level"))
            if level is not None:
                return f"{title} {level}"
    return None


def is_invalid_position(normalized: str) -> bool:
    """Return whether the normalized value should be rejected outright."""
    return any(re.match(pattern, normalized) for pattern in INVALID_POSITION_PATTERNS)


def lookup_position_title(normalized: str) -> str | None:
    """Return a canonical title for a normalized key when one exists."""
    return NORMALIZED_POSITION_MAP.get(normalized) or CANONICAL_POSITION_LOOKUP.get(
        normalized
    )


def resolve_teacher_descriptor(normalized: str) -> str | None:
    """Collapse SHS/JHS teacher variants to canonical Teacher titles."""
    teacher_descriptor_match = re.fullmatch(
        r"(?:ALS\s+)*(?:SHS|JHS|SHST|JHST|SECONDARY\s+SCHOOL\s+TEACHER|SENIOR\s+HIGH\s+SCHOOL\s*,?\s*TEACHER|JUNIOR\s+HIGH\s+SCHOOL\s*,?\s*TEACHER)\s+(?P<level>[A-Z0-9]+)",
        normalized,
    )
    if teacher_descriptor_match is None:
        return None
    level = normalize_position_level(teacher_descriptor_match.group("level"))
    if level is None:
        return None
    return f"Teacher {level}"


def resolve_expanded_position_family(normalized: str) -> str | None:
    """Expand compact position families and look up the canonical title."""
    expanded = expand_position_family(normalized)
    if expanded is None:
        return None
    expanded_key = normalize_position_key(expanded.upper())
    return lookup_position_title(expanded_key)


def position_issue(raw: str | None) -> tuple[str | None, str | None]:
    """Return a canonical title and any position-specific issue code."""
    text = clean_text(raw)
    if text is None:
        return None, None

    preprocessed = preprocess_position_text(text)
    normalized = normalize_position_key(preprocessed)

    if is_invalid_position(normalized):
        return None, "invalid_position"

    direct_match = lookup_position_title(normalized)
    if direct_match is not None:
        return direct_match, None

    teacher_match = resolve_teacher_descriptor(normalized)
    if teacher_match is not None:
        return teacher_match, None

    expanded_match = resolve_expanded_position_family(normalized)
    if expanded_match is not None:
        return expanded_match, None

    matches = get_close_matches(
        normalized, CANONICAL_POSITION_LOOKUP.keys(), n=1, cutoff=0.82
    )
    if matches:
        return CANONICAL_POSITION_LOOKUP[matches[0]], None
    return None, "unmapped_position"


def normalize_position(raw: str | None) -> str | None:
    """Normalize position titles to canonical values."""
    normalized, _ = position_issue(raw)
    return normalized


def normalize_equipment_category(raw: str | None) -> str:
    """Map raw equipment category values to the canonical lookup set."""
    text = (clean_text(raw) or "").lower()
    if "high" in text:
        return "High-value"
    if "low" in text:
        return "Low-value"
    return "Unknown"


def normalize_title_token(value: str) -> str:
    """Title-case text while preserving all-uppercase acronyms and years."""
    if value.isupper() and len(value) <= 5:
        return value
    if value.isdigit():
        return value
    return value.title()


def prettify_tokens(text: str) -> str:
    """Return stable title-cased output while preserving acronyms and digits."""
    parts = [normalize_title_token(part) for part in re.split(r"(\W+)", text) if part]
    return "".join(parts)


def normalize_alias_key(value: str | None) -> str | None:
    """Normalize a string for alias-table matching."""
    text = clean_text(value)
    if text is None:
        return None
    return re.sub(r"[^A-Z0-9]+", " ", text.upper()).strip()


def classify_equipment_dimension_value(
    kind: str, value: str | None
) -> tuple[str | None, str | None]:
    """Classify a raw equipment dimension value before canonicalization."""
    text = clean_text(value)
    if text is None:
        return None, None

    alias_key = normalize_alias_key(text)
    token_key = re.sub(r"[^A-Z0-9]+", "", text.upper())
    if not token_key:
        return text, "invalid_value"
    if alias_key in GENERIC_EQUIPMENT_VALUES:
        return text, "generic_value"
    if len(token_key) == 1:
        return text, "invalid_value"
    if token_key.isdigit() and (
        kind in {"brand", "acquisition_mode", "acquisition_source"}
        or len(token_key) <= 4
    ):
        return text, "invalid_value"
    return text, None


def normalize_equipment_item(value: str | None) -> str | None:
    """Normalize equipment item names conservatively."""
    text = clean_text(value)
    if text is None:
        return None
    return prettify_tokens(re.sub(r"\s+", " ", text).strip())


def normalize_equipment_brand(value: str | None) -> str | None:
    """Normalize brands conservatively with a small approved synonym list."""
    text = clean_text(value)
    if text is None:
        return None
    collapsed = re.sub(r"\s+", " ", text).strip()
    alias_key = normalize_alias_key(collapsed)
    if alias_key in BRAND_SYNONYMS:
        return BRAND_SYNONYMS[alias_key]
    return prettify_tokens(collapsed)


def normalize_equipment_model(value: str | None) -> str | None:
    """Normalize model values conservatively without semantic merges."""
    text = clean_text(value)
    if text is None:
        return None
    return prettify_tokens(re.sub(r"\s+", " ", text).strip())


def canonicalize_equipment_dimension(
    kind: str, value: str | None
) -> tuple[str | None, str | None]:
    """Return a canonical value or issue code for selected equipment dimensions."""
    text, issue = classify_equipment_dimension_value(kind, value)
    if text is None or issue is not None:
        return None, issue

    if kind == "brand":
        return normalize_equipment_brand(text), None
    if kind == "model":
        return None, "raw_only_value"
    if kind in {"acquisition_mode", "acquisition_source"}:
        canonical = normalize_low_cardinality_dimension(kind, text)
        if canonical is None:
            return None, "unmapped_value"
        return canonical, None
    raise ValueError(f"Unsupported equipment dimension kind: {kind}")


def normalize_low_cardinality_dimension(kind: str, value: str | None) -> str | None:
    """Aggressively canonicalize low-cardinality equipment dimensions."""
    text = clean_text(value)
    if text is None:
        return None

    if kind == "dcp_year":
        match = re.search(r"\b(20\d{2})\b", text)
        return match.group(1) if match else None

    alias_key = normalize_alias_key(text)
    if alias_key is None:
        return None

    if kind == "dcp_package":
        package_match = re.search(r"\bPACKAGE\s*([A-Z0-9]+)\b", alias_key)
        if package_match:
            return f"DCP Package {package_match.group(1)}"
        lot_match = re.search(r"\bLOT\s*([A-Z0-9]+)\b", alias_key)
        if lot_match:
            return f"Lot {lot_match.group(1)}"
        cleaned = re.sub(r"\bDCP\b", "", alias_key).strip()
        return f"DCP {prettify_tokens(cleaned)}" if cleaned else None

    alias_map = LOW_CARDINALITY_ALIASES[kind]
    if alias_key in alias_map:
        return alias_map[alias_key]
    if kind in {"acquisition_mode", "acquisition_source"}:
        return None
    return prettify_tokens(re.sub(r"\s+", " ", text).strip())


def normalize_person_name(value: str | None) -> str | None:
    """Normalize a person name for parsed output and matching."""
    text = clean_text(value)
    if text is None:
        return None
    text = re.sub(r"\s+", " ", text).strip(" ,;:-")
    if not text:
        return None
    return prettify_tokens(text)


def person_name_key(value: str | None) -> str | None:
    """Normalize a person name for exact-match lookups."""
    text = normalize_person_name(value)
    if text is None:
        return None
    return re.sub(r"[^A-Z0-9]+", " ", text.upper()).strip()


def parse_person_reference(value: str | None) -> tuple[str | None, str | None]:
    """Extract a normalized person name and employee ID from freeform text."""
    text = clean_text(value)
    if text is None:
        return None, None

    employee_id = None
    residual = text
    patterns = [
        r"(?i)\b(?:employee\s*id|emp\s*id|id)\s*[:#-]?\s*([A-Z0-9-]+)\b",
        r"\(([A-Z0-9-]*\d[A-Z0-9-]*)\)$",
        r"-\s*([A-Z0-9-]*\d[A-Z0-9-]*)$",
    ]
    for pattern in patterns:
        match = re.search(pattern, residual)
        if match:
            employee_id = normalize_identifier(match.group(1))
            residual = f"{residual[: match.start()]} {residual[match.end() :]}"
            break

    cleaned_name = normalize_person_name(re.sub(r"\(\s*\)", "", residual))
    return cleaned_name, employee_id


def normalize_equipment_dimension(value: str | None) -> str | None:
    """Backward-compatible alias for conservative equipment item normalization."""
    return normalize_equipment_item(value)
