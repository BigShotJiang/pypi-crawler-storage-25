"""Date and timestamp parsing helpers."""

from __future__ import annotations

from datetime import date, datetime, timezone

from .normalization import clean_review_text

DATE_FORMATS = (
    "%m/%d/%Y",
    "%m/%d/%y",
    "%Y-%m-%d",
    "%Y/%m/%d",
)

DATETIME_FORMATS = (
    "%m/%d/%Y %H:%M:%S",
    "%m/%d/%Y %H:%M",
    "%m/%d/%y %H:%M:%S",
    "%m/%d/%y %H:%M",
    "%Y-%m-%d %H:%M:%S",
    "%Y-%m-%d %H:%M",
    "%Y/%m/%d %H:%M:%S",
    "%Y/%m/%d %H:%M",
)


def parse_date(value: object | None) -> str | None:
    """Return an ISO date string or None if the value is blank or invalid."""
    text = clean_review_text(value)
    if text is None or text.upper() == "NAN-NAN-NAN":
        return None
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(text, fmt).date().isoformat()
        except ValueError:
            continue
    return None


def parse_timestamp(value: object | None) -> datetime | None:
    """Parse common submitted timestamp formats into a datetime."""
    text = clean_review_text(value)
    if text is None:
        return None
    iso_text = text.replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(iso_text)
    except ValueError:
        pass
    for fmt in DATETIME_FORMATS:
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            continue
    parsed_date = parse_date(text)
    if parsed_date is None:
        return None
    return datetime.combine(date.fromisoformat(parsed_date), datetime.min.time())


def normalize_submission_timestamp(value: object | None) -> str | None:
    """Return a normalized ISO timestamp string for submitted source records."""
    parsed = parse_timestamp(value)
    if parsed is None:
        return None
    if parsed.tzinfo is timezone.utc:
        return parsed.isoformat().replace("+00:00", "Z")
    return parsed.isoformat()
