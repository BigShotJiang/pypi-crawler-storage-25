#!/usr/bin/env python3
"""Profile every column in a SQLite table: type guess, avg length, dirty-value %, outliers, and value frequencies."""

from __future__ import annotations

import argparse
import re
import sqlite3
import sys
from collections import Counter
from typing import Any

from rich.console import Console
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
)

console = Console(stderr=True)


# ---------------------------------------------------------------------------
# Type-guessing heuristics
# ---------------------------------------------------------------------------

_INTEGER_RE = re.compile(r"^-?\d+$")
_FLOAT_RE = re.compile(r"^-?\d*\.\d+$")
_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_DATETIME_RE = re.compile(r"^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}")
_BOOLEAN_LIKE = {"0", "1", "true", "false", "yes", "no", "y", "n"}


def _guess_type(samples: list[str]) -> str:
    if not samples:
        return "empty"
    counts: Counter[str] = Counter()
    for v in samples:
        v = v.strip()
        if _DATETIME_RE.match(v):
            counts["datetime"] += 1
        elif _DATE_RE.match(v):
            counts["date"] += 1
        elif _INTEGER_RE.match(v):
            counts["integer"] += 1
        elif _FLOAT_RE.match(v):
            counts["float"] += 1
        elif v.lower() in _BOOLEAN_LIKE:
            counts["boolean"] += 1
        else:
            counts["text"] += 1
    dominant, dominant_count = counts.most_common(1)[0]
    pct = dominant_count / len(samples)
    if pct >= 0.9:
        return dominant
    second = counts.most_common(2)
    if len(second) > 1:
        return f"mixed({dominant}/{second[1][0]})"
    return dominant


# ---------------------------------------------------------------------------
# Dirty-value heuristics
# ---------------------------------------------------------------------------

_EXCEL_ERROR_RE = re.compile(r"^#(VALUE|REF|NAME|DIV/0|N/A|NULL|NUM)!", re.I)
_FORMULA_RE = re.compile(r"^=")
_IP_LIKE_RE = re.compile(r"^\d{1,3}(\.\d{1,3}){3}$")
_PLACEHOLDER_RE = re.compile(r"^(n/?a|none|null|tbd|unknown|test|sample|xxx+)$", re.I)


def _is_dirty(value: str, avg_len: float) -> bool:
    """Return True if the value looks like a data quality issue."""
    v = value.strip()
    if not v:
        return False  # nulls counted separately
    if _EXCEL_ERROR_RE.match(v):
        return True
    if _FORMULA_RE.match(v):
        return True
    if _PLACEHOLDER_RE.match(v):
        return True
    # Unusually long value: flag if > 5× the column average (and avg is meaningful)
    if avg_len > 0 and len(v) > max(5 * avg_len, 200):
        return True
    # Non-printable characters
    if any(ord(c) < 32 and c not in "\t\n\r" for c in v):
        return True
    return False


# ---------------------------------------------------------------------------
# Outlier detection (IQR method)
# ---------------------------------------------------------------------------


def _quantile(sorted_vals: list[float], q: float) -> float:
    """Linear interpolation quantile on a pre-sorted list."""
    n = len(sorted_vals)
    if n == 0:
        return 0.0
    idx = q * (n - 1)
    lo, hi = int(idx), min(int(idx) + 1, n - 1)
    return sorted_vals[lo] + (idx - lo) * (sorted_vals[hi] - sorted_vals[lo])


def _detect_outliers(values: list[str], type_guess: str) -> dict[str, Any]:
    """
    Return outlier statistics for a column using the Tukey IQR fence method
    (fence = Q1 - 1.5·IQR, Q3 + 1.5·IQR).  Only runs for integer/float/mixed
    columns that contain a numeric component.
    """
    empty: dict[str, Any] = {
        "numeric_count": 0,
        "numeric_min": None,
        "numeric_max": None,
        "numeric_mean": None,
        "numeric_median": None,
        "numeric_q1": None,
        "numeric_q3": None,
        "outlier_count": 0,
        "outlier_pct": 0.0,
        "outlier_low_fence": None,
        "outlier_high_fence": None,
        "outlier_examples": [],
    }

    is_numeric = type_guess in ("integer", "float") or (
        type_guess.startswith("mixed")
        and any(t in type_guess for t in ("integer", "float"))
    )
    if not is_numeric:
        return empty

    nums: list[float] = []
    for v in values:
        v = v.strip()
        if _INTEGER_RE.match(v) or _FLOAT_RE.match(v):
            try:
                nums.append(float(v))
            except ValueError:
                pass

    if len(nums) < 4:  # too few points for meaningful IQR
        return empty

    nums.sort()
    n = len(nums)
    q1 = _quantile(nums, 0.25)
    q3 = _quantile(nums, 0.75)
    iqr = q3 - q1
    low_fence = q1 - 1.5 * iqr
    high_fence = q3 + 1.5 * iqr

    outliers = [x for x in nums if x < low_fence or x > high_fence]
    outlier_pct = len(outliers) / n * 100

    # Representative examples: up to 3 most extreme on each side
    low_examples = sorted(x for x in outliers if x < low_fence)[:3]
    high_examples = sorted((x for x in outliers if x > high_fence), reverse=True)[:3]
    examples = [str(int(x) if x == int(x) else x) for x in low_examples + high_examples]

    return {
        "numeric_count": n,
        "numeric_min": nums[0],
        "numeric_max": nums[-1],
        "numeric_mean": sum(nums) / n,
        "numeric_median": _quantile(nums, 0.5),
        "numeric_q1": q1,
        "numeric_q3": q3,
        "outlier_count": len(outliers),
        "outlier_pct": outlier_pct,
        "outlier_low_fence": low_fence,
        "outlier_high_fence": high_fence,
        "outlier_examples": examples,
    }


# ---------------------------------------------------------------------------
# Column profiling
# ---------------------------------------------------------------------------


def _profile_column(
    conn: sqlite3.Connection,
    table: str,
    column: str,
    total_rows: int,
    progress: Progress | None = None,
    task_id: int | None = None,
) -> dict[str, Any]:
    cur = conn.cursor()

    def _step(label: str) -> None:
        if progress is not None and task_id is not None:
            progress.update(task_id, description=f"[bold]{column}[/] [dim]{label}[/]")

    # Null count
    _step("nulls")
    cur.execute(
        f'SELECT COUNT(*) FROM "{table}" WHERE "{column}" IS NULL OR CAST("{column}" AS TEXT) = ""'
    )
    null_count: int = cur.fetchone()[0]
    non_null = total_rows - null_count

    # All non-null text values (cap at 50 000 for large tables)
    _step("values")
    cur.execute(
        f'SELECT CAST("{column}" AS TEXT) FROM "{table}" WHERE "{column}" IS NOT NULL AND CAST("{column}" AS TEXT) != "" LIMIT 50000'
    )
    values: list[str] = [row[0] for row in cur.fetchall()]

    avg_len = sum(len(v) for v in values) / len(values) if values else 0.0
    max_len = max((len(v) for v in values), default=0)
    type_guess = _guess_type(values)

    _step("dirty check")
    dirty = [v for v in values if _is_dirty(v, avg_len)]
    dirty_pct = len(dirty) / total_rows * 100 if total_rows else 0.0

    # Value frequency (top 30 distinct values)
    _step("frequencies")
    cur.execute(
        f"""
        SELECT CAST("{column}" AS TEXT) AS val, COUNT(*) AS cnt
        FROM "{table}"
        WHERE "{column}" IS NOT NULL AND CAST("{column}" AS TEXT) != ""
        GROUP BY val
        ORDER BY cnt DESC
        LIMIT 30
        """
    )
    freq: list[tuple[str, int]] = cur.fetchall()

    _step("outliers")
    outlier_stats = _detect_outliers(values, type_guess)

    return {
        "column": column,
        "total_rows": total_rows,
        "null_count": null_count,
        "null_pct": null_count / total_rows * 100 if total_rows else 0.0,
        "non_null": non_null,
        "avg_len": avg_len,
        "max_len": max_len,
        "type_guess": type_guess,
        "dirty_count": len(dirty),
        "dirty_pct": dirty_pct,
        "dirty_examples": sorted(set(dirty), key=len, reverse=True)[:5],
        "top_values": freq,
        **outlier_stats,
    }


# ---------------------------------------------------------------------------
# Markdown rendering
# ---------------------------------------------------------------------------

_SEVERITY_THRESHOLD_DIRTY = 1.0  # % dirty values that triggers a warning
_SEVERITY_THRESHOLD_NULL = 50.0  # % nulls that triggers a warning
_SEVERITY_THRESHOLD_OUTLIER = 5.0  # % outliers that triggers a warning


def _fmt_num(x: float | None, decimals: int = 2) -> str:
    if x is None:
        return "—"
    return f"{x:,.{decimals}f}"


def _summary_row(p: dict[str, Any]) -> str:
    flags = []
    if p["dirty_pct"] >= _SEVERITY_THRESHOLD_DIRTY:
        flags.append("⚠ dirty")
    if p["null_pct"] >= _SEVERITY_THRESHOLD_NULL:
        flags.append("⚠ nulls")
    if p["outlier_pct"] >= _SEVERITY_THRESHOLD_OUTLIER:
        flags.append("⚠ outliers")
    flag_str = f" ({', '.join(flags)})" if flags else ""
    outlier_cell = f"{p['outlier_pct']:.1f}%" if p["numeric_count"] else "—"
    return (
        f"| `{p['column']}` | {p['type_guess']} | {p['avg_len']:.1f} | {p['max_len']:,} "
        f"| {p['null_pct']:.1f}% | {p['dirty_pct']:.1f}%{flag_str} | {outlier_cell} |"
    )


def _detail_lines(p: dict[str, Any]) -> list[str]:
    lines: list[str] = []
    lines.append(f"### `{p['column']}`\n")
    lines.append(f"- **Type guess:** {p['type_guess']}")
    lines.append(f"- **Avg / max length:** {p['avg_len']:.1f} / {p['max_len']:,} chars")
    lines.append(
        f"- **Null / empty:** {p['null_count']:,} of {p['total_rows']:,} ({p['null_pct']:.1f}%)"
    )
    lines.append(
        f"- **Suspect dirty values:** {p['dirty_count']:,} ({p['dirty_pct']:.2f}%)"
    )

    if p["dirty_examples"]:
        lines.append("- **Dirty examples (longest first):**")
        for ex in p["dirty_examples"]:
            truncated = ex[:120].replace("\n", " ↵ ").replace("|", "¦")
            lines.append(f"  - `{truncated}`{'…' if len(ex) > 120 else ''}")

    if p["numeric_count"]:
        lines.append(f"- **Numeric stats** ({p['numeric_count']:,} parsed values):")
        lines.append(
            f"  - Min / Max: {_fmt_num(p['numeric_min'])} / {_fmt_num(p['numeric_max'])}"
        )
        lines.append(
            f"  - Mean / Median: {_fmt_num(p['numeric_mean'])} / {_fmt_num(p['numeric_median'])}"
        )
        lines.append(
            f"  - Q1 / Q3: {_fmt_num(p['numeric_q1'])} / {_fmt_num(p['numeric_q3'])}"
        )
        lines.append(
            f"- **Outliers (IQR method):** {p['outlier_count']:,} ({p['outlier_pct']:.2f}%) — "
            f"fence [{_fmt_num(p['outlier_low_fence'])}, {_fmt_num(p['outlier_high_fence'])}]"
        )
        if p["outlier_examples"]:
            lines.append(
                f"  - Extreme values: {', '.join(f'`{e}`' for e in p['outlier_examples'])}"
            )

    if p["top_values"]:
        lines.append("\n**Top values** (non-null, by frequency):\n")
        lines.append("| Value | Count |")
        lines.append("|-------|------:|")
        for val, cnt in p["top_values"]:
            display = val[:80].replace("\n", " ↵ ").replace("|", "¦")
            suffix = "…" if len(val) > 80 else ""
            lines.append(f"| `{display}{suffix}` | {cnt:,} |")
    lines.append("")
    return lines


def _collect_issues(profiles: list[dict[str, Any]]) -> list[str]:
    issues: list[str] = []

    high_null = [p for p in profiles if p["null_pct"] >= _SEVERITY_THRESHOLD_NULL]
    if high_null:
        cols = ", ".join(f"`{p['column']}` ({p['null_pct']:.0f}%)" for p in high_null)
        issues.append(
            f"**High null rate (≥50%):** {cols} — consider whether these fields are optional "
            "by design or reflect incomplete submissions."
        )

    for p in (p for p in profiles if p["dirty_pct"] >= _SEVERITY_THRESHOLD_DIRTY):
        examples_str = "; ".join(
            f"`{ex[:60].replace(chr(10), ' ↵ ')}{'…' if len(ex) > 60 else ''}`"
            for ex in p["dirty_examples"][:3]
        )
        issues.append(
            f"**`{p['column']}`** has {p['dirty_pct']:.1f}% suspect values "
            f"({p['dirty_count']:,} rows). Examples: {examples_str}"
        )

    for p in (p for p in profiles if p["outlier_pct"] >= _SEVERITY_THRESHOLD_OUTLIER):
        examples_str = ", ".join(f"`{e}`" for e in p["outlier_examples"][:4])
        issues.append(
            f"**`{p['column']}`** has {p['outlier_pct']:.1f}% outliers "
            f"({p['outlier_count']:,} values outside IQR fence "
            f"[{_fmt_num(p['outlier_low_fence'])}, {_fmt_num(p['outlier_high_fence'])}]). "
            f"Extremes: {examples_str}"
        )

    for p in (p for p in profiles if p["max_len"] > 500 and p["type_guess"] == "text"):
        if not any(p["column"] in i for i in issues):
            issues.append(
                f"**`{p['column']}`** contains very long text (max {p['max_len']:,} chars, avg {p['avg_len']:.0f}). "
                "Free-text field — consider capping or normalising before analysis."
            )

    mixed_types = [p for p in profiles if p["type_guess"].startswith("mixed")]
    if mixed_types:
        cols = ", ".join(f"`{p['column']}` ({p['type_guess']})" for p in mixed_types)
        issues.append(
            f"**Mixed-type columns:** {cols} — values are not consistently typed; "
            "coercion or cleansing required."
        )

    low_card = [
        p
        for p in profiles
        if p["type_guess"] == "text"
        and 0 < len(p["top_values"]) <= 10
        and p["non_null"] > 100
    ]
    if low_card:
        cols = ", ".join(f"`{p['column']}`" for p in low_card)
        issues.append(
            f"**Low-cardinality text fields:** {cols} — these may be better modelled as "
            "enumerations or foreign-key references."
        )

    return issues


def _render_markdown(table: str, profiles: list[dict[str, Any]]) -> str:
    lines: list[str] = []
    lines.append(f"# Column Profile: `{table}`\n")
    lines.append(f"**Total rows:** {profiles[0]['total_rows']:,}\n" if profiles else "")

    lines.append("## Summary\n")
    lines.append("| Column | Type | Avg len | Max len | Null % | Dirty % | Outlier % |")
    lines.append("|--------|------|--------:|--------:|-------:|--------:|----------:|")
    for p in profiles:
        lines.append(_summary_row(p))
    lines.append("")

    lines.append("## Column Detail\n")
    for p in profiles:
        lines.extend(_detail_lines(p))

    lines.append("## Analysis\n")
    issues = _collect_issues(profiles)
    if not issues:
        lines.append("No significant data quality issues detected.")
    else:
        for issue in issues:
            lines.append(f"- {issue}\n")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("db", help="Path to the SQLite database file")
    parser.add_argument("table", help="Table name to profile")
    parser.add_argument(
        "--columns",
        help="Comma-separated list of columns to profile (default: all)",
        default=None,
    )
    args = parser.parse_args()

    conn = sqlite3.connect(args.db)
    conn.row_factory = sqlite3.Row

    # Validate table
    tables = {
        row[0]
        for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")
    }
    if args.table not in tables:
        print(
            f"Error: table '{args.table}' not found. Available tables:\n  "
            + "\n  ".join(sorted(tables)),
            file=sys.stderr,
        )
        sys.exit(1)

    # Resolve columns
    pragma = conn.execute(f'PRAGMA table_info("{args.table}")')
    all_columns = [row["name"] for row in pragma]
    if args.columns:
        selected = [c.strip() for c in args.columns.split(",")]
        unknown = [c for c in selected if c not in all_columns]
        if unknown:
            print(f"Error: unknown columns: {unknown}", file=sys.stderr)
            sys.exit(1)
        columns = selected
    else:
        columns = all_columns

    total_rows: int = conn.execute(f'SELECT COUNT(*) FROM "{args.table}"').fetchone()[0]

    profiles = []
    with Progress(
        SpinnerColumn(),
        TextColumn("{task.description}"),
        BarColumn(),
        MofNCompleteColumn(),
        TimeElapsedColumn(),
        console=console,
    ) as progress:
        task_id = progress.add_task(f"[bold]{columns[0]}[/]", total=len(columns))
        for col in columns:
            profiles.append(
                _profile_column(conn, args.table, col, total_rows, progress, task_id)
            )
            progress.advance(task_id)

    conn.close()
    print(_render_markdown(args.table, profiles))


if __name__ == "__main__":
    main()
