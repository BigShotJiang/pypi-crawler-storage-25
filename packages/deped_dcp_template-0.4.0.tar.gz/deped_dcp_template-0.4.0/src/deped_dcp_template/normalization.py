"""Shared text normalization helpers."""

from __future__ import annotations

import re

from .constants import NULL_LIKE_VALUES


def normalize_label(value: object | None) -> str:
    """Return a whitespace-normalized label suitable for headers and keys."""
    if value is None:
        return ""
    text = str(value).replace("\ufeff", "").strip()
    return re.sub(r"\s+", " ", text)


def clean_review_text(value: object | None) -> str | None:
    """Normalize freeform review/audit text while preserving human casing."""
    text = normalize_label(value)
    if not text or text.upper() in NULL_LIKE_VALUES:
        return None
    return text


def normalize_review_key(value: object | None) -> str:
    """Return a stable uppercase key for matching review/audit labels."""
    text = clean_review_text(value)
    if text is None:
        return ""
    key = re.sub(r"[^A-Za-z0-9]+", "_", text.upper()).strip("_")
    return re.sub(r"_+", "_", key)
