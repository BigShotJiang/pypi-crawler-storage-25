"""Shared Rich console and progress helpers."""

from __future__ import annotations

from contextlib import contextmanager
from typing import Iterator

from rich.console import Console
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    SpinnerColumn,
    TaskProgressColumn,
    TextColumn,
    TimeElapsedColumn,
    TransferSpeedColumn,
)

CONSOLE = Console(stderr=True)


def get_console() -> Console:
    """Return the package-wide Rich console."""
    return CONSOLE


def create_progress(*, transient: bool = False) -> Progress:
    """Create the shared progress layout used by command-line transfers."""
    return Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        DownloadColumn(),
        TransferSpeedColumn(),
        TimeElapsedColumn(),
        console=CONSOLE,
        transient=transient,
    )


def log_info(message: str) -> None:
    CONSOLE.print(f"[cyan]info[/cyan] {message}")


def log_success(message: str) -> None:
    CONSOLE.print(f"[green]ok[/green] {message}")


def log_warning(message: str) -> None:
    CONSOLE.print(f"[yellow]warn[/yellow] {message}")


def log_error(message: str) -> None:
    CONSOLE.print(f"[red]error[/red] {message}")


@contextmanager
def command_step(message: str) -> Iterator[None]:
    """Wrap a command step in a consistent Rich status line."""
    with CONSOLE.status(message, spinner="dots"):
        yield
