"""Shared runtime helpers for DepEd DCP packages."""
