# staub

Placeholder package for [Staub AI](https://staub.ai).

The real `staub` package is not published yet. This release exists to secure
the namespace on PyPI.

Visit [staub.ai](https://staub.ai) to learn more, or follow updates at
[github.com/staubai](https://github.com/staubai).
