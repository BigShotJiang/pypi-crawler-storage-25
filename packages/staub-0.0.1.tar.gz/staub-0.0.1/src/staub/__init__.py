"""Placeholder for the staub package. See https://staub.ai"""

__version__ = "0.0.1"

_MESSAGE = (
    "staub: this PyPI package is a placeholder. "
    "The real Staub AI package is not published yet. "
    "Visit https://staub.ai for updates."
)


def __getattr__(name: str):
    raise AttributeError(_MESSAGE)
