"""
Browser Manager Module
Handles browser automation and lifecycle management
"""

import os
import time
import logging
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.firefox.service import Service as FirefoxService
from selenium.webdriver.safari.service import Service as SafariService
from selenium.webdriver.edge.service import Service as EdgeService
from selenium.common.exceptions import WebDriverException, TimeoutException
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.firefox import GeckoDriverManager
from webdriver_manager.microsoft import EdgeChromiumDriverManager

from config import BROWSERS, TEST_CONFIG

class BrowserManager:
    """Manages browser instances and automation"""
    
    def __init__(self):
        self.driver = None
        self.browser_name = None
        self.logger = logging.getLogger(__name__)
        
    def launch_browser(self, browser_name):
        """Launch specified browser with appropriate configuration"""
        try:
            self.browser_name = browser_name
            browser_config = BROWSERS.get(browser_name)
            
            if not browser_config:
                raise ValueError(f"Unsupported browser: {browser_name}")
            
            # Check if browser executable exists (for browsers that need it)
            if browser_config.get("executable_path") and browser_name not in ["chrome", "firefox"]:
                if not browser_config["executable_path"]:
                    raise RuntimeError(f"{browser_config['name']} is not installed or could not be found on this system")
                    
            self.logger.info(f"Launching {browser_config['name']}")
            
            if browser_name == "chrome":
                self.driver = self._launch_chrome()
            elif browser_name == "firefox":
                self.driver = self._launch_firefox()
            elif browser_name == "safari":
                self.driver = self._launch_safari()
            elif browser_name == "edge":
                self.driver = self._launch_edge()
            elif browser_name == "opera":
                self.driver = self._launch_opera()
            elif browser_name == "brave":
                self.driver = self._launch_brave()
            elif browser_name == "tor":
                self.driver = self._launch_tor()
            else:
                raise ValueError(f"Browser {browser_name} not implemented yet")
                
            # Set common timeouts
            self.driver.implicitly_wait(10)
            self.driver.set_page_load_timeout(TEST_CONFIG["page_load_timeout"])
            
            self.logger.info(f"Successfully launched {browser_config['name']}")
            return self.driver
            
        except Exception as e:
            self.logger.error(f"Failed to launch {browser_name}: {str(e)}")
            raise
    
    def _launch_chrome(self):
        """Launch Chrome browser with stealth configuration"""
        try:
            from src.captcha.stealth_config import get_stealth_chrome_options, apply_stealth_script
            
            options = get_stealth_chrome_options()
            service = ChromeService(ChromeDriverManager().install())
            driver = webdriver.Chrome(service=service, options=options)
            apply_stealth_script(driver)
            return driver
        except Exception as e:
            logging.error(f"Chrome stealth launch failed: {e}")
            options = webdriver.ChromeOptions()
            options.add_argument("--no-sandbox")
            options.add_argument("--disable-dev-shm-usage")
            service = ChromeService(ChromeDriverManager().install())
            return webdriver.Chrome(service=service, options=options)
    
    def _launch_firefox(self):
        """Launch Firefox browser with stealth configuration"""
        from config import BROWSERS
        firefox_binary = BROWSERS.get("firefox", {}).get("executable_path")

        try:
            from src.captcha.stealth_config import get_stealth_firefox_options, apply_stealth_script
            options = get_stealth_firefox_options()
            if firefox_binary:
                options.binary_location = firefox_binary
            service = FirefoxService(GeckoDriverManager().install())
            driver = webdriver.Firefox(service=service, options=options)
            apply_stealth_script(driver)
            return driver
        except Exception as e:
            logging.error(f"Firefox stealth launch failed: {e}")
            options = webdriver.FirefoxOptions()
            if firefox_binary:
                options.binary_location = firefox_binary
            service = FirefoxService(GeckoDriverManager().install())
            return webdriver.Firefox(service=service, options=options)
    
    def _launch_safari(self):
        """Launch Safari browser with stealth configuration"""
        driver = webdriver.Safari()
        
        # Apply stealth JavaScript
        try:
            from src.captcha.stealth_config import apply_stealth_script
            apply_stealth_script(driver)
        except:
            pass
        
        return driver
    
    def _launch_edge(self):
        """Launch Microsoft Edge browser with stealth configuration"""
        try:
            from src.captcha.stealth_config import apply_stealth_script
            
            options = webdriver.EdgeOptions()
            options.add_argument("--no-sandbox")
            options.add_argument("--disable-blink-features=AutomationControlled")
            options.add_experimental_option("excludeSwitches", ["enable-automation"])
            
            try:
                driver = webdriver.Edge(options=options)
            except:
                service = EdgeService(EdgeChromiumDriverManager().install())
                driver = webdriver.Edge(service=service, options=options)
            
            apply_stealth_script(driver)
            return driver
        except Exception as e:
            logging.error(f"Edge launch failed: {e}")
            raise
    
    def _launch_opera(self):
        """Launch Opera browser - smart version detection"""
        opera_path = BROWSERS["opera"]["executable_path"]
        if not opera_path or not os.path.exists(opera_path):
            raise RuntimeError("Opera browser not found. Please install Opera or check the installation path.")
        
        try:
            from src.captcha.stealth_config import apply_stealth_script
            
            options = webdriver.ChromeOptions()
            options.binary_location = opera_path
            options.add_argument("--no-sandbox")
            options.add_argument("--disable-dev-shm-usage")
            options.add_argument("--disable-blink-features=AutomationControlled")
            options.add_experimental_option("excludeSwitches", ["enable-automation"])
            options.add_experimental_option('useAutomationExtension', False)
            
            # Try common Opera/Chromium versions silently
            versions_to_try = ["146", "147", "145", "148", "144"]
            
            driver = None
            for version in versions_to_try:
                try:
                    service = ChromeService(ChromeDriverManager(driver_version=version).install())
                    driver = webdriver.Chrome(service=service, options=options)
                    self.logger.info(f"Opera launched successfully")
                    break
                except Exception as e:
                    if "version" in str(e).lower() or "only supports" in str(e).lower():
                        continue  # Try next version silently
                    else:
                        raise  # Different error
            
            if not driver:
                raise RuntimeError("Could not find compatible ChromeDriver for Opera. Please update Opera or ChromeDriver.")
            
            # Give time for any popups
            time.sleep(2)
            
            apply_stealth_script(driver)
            return driver
        except Exception as e:
            logging.error(f"Opera launch failed: {e}")
            raise
    
    def _launch_brave(self):
        """Launch Brave browser"""
        brave_path = BROWSERS["brave"]["executable_path"]
        if not brave_path or not os.path.exists(brave_path):
            raise RuntimeError("Brave browser not found. Please install Brave or check the installation path.")
        
        options = webdriver.ChromeOptions()
        options.binary_location = brave_path
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-blink-features=AutomationControlled")
        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        
        service = ChromeService(ChromeDriverManager().install())
        return webdriver.Chrome(service=service, options=options)
    
    def _launch_tor(self):
        """Launch Tor browser with proper proxy configuration"""
        try:
            import subprocess
            
            tor_binary = BROWSERS["tor"]["executable_path"]
            if not tor_binary or not os.path.exists(tor_binary):
                raise RuntimeError("Tor browser not found. Please install Tor Browser or check the installation path.")
            
            # Try to start Tor service
            tor_service_path = os.path.dirname(tor_binary) + "/Tor/tor"
            if os.path.exists(tor_service_path):
                subprocess.Popen([tor_service_path, "--SocksPort", "9050"], 
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                time.sleep(5)
            
            options = webdriver.FirefoxOptions()
            options.binary_location = tor_binary
            
            # Tor-specific proxy settings
            options.set_preference("network.proxy.type", 1)
            options.set_preference("network.proxy.socks", "127.0.0.1")
            options.set_preference("network.proxy.socks_port", 9050)
            options.set_preference("network.proxy.socks_remote_dns", True)
            options.set_preference("network.proxy.socks_version", 5)
            
            # Security and privacy settings
            options.set_preference("dom.webdriver.enabled", False)
            options.set_preference("useAutomationExtension", False)
            options.set_preference("security.tls.insecure_fallback_hosts", "")
            options.set_preference("network.http.connection-timeout", 120)
            options.set_preference("network.http.response.timeout", 120)
            
            # Window settings
            options.add_argument("--width=1920")
            options.add_argument("--height=1080")
            
            service = FirefoxService(GeckoDriverManager().install())
            driver = webdriver.Firefox(service=service, options=options)
            
            # Extended timeouts for Tor
            driver.set_page_load_timeout(180)  # 3 minutes for Tor
            driver.implicitly_wait(15)
            
            return driver
            
        except Exception as e:
            logging.error(f"Tor launch failed: {e}")
            raise
    
    def _handle_captcha_verification(self):
        """Handle CAPTCHA with working 2captcha.com solver"""
        try:
            current_url = self.driver.current_url.lower()
            page_text = self.driver.page_source.lower()[:3000]  # Only check start of page
            
            # Check if CAPTCHA is present (URL or page content)
            captcha_indicators = ["captcha", "unusual traffic", "i'm not a robot", "recaptcha"]
            is_sorry_page = "sorry" in current_url
            has_captcha = any(ind in page_text for ind in captcha_indicators)
            
            if not (is_sorry_page or has_captcha):
                return False  # No CAPTCHA detected
            
            self.logger.warning("🚨 CAPTCHA detected!")
            
            # Try 2captcha solver
            try:
                from src.captcha.working_captcha_solver import WorkingCaptchaSolver
                import os
                
                api_key = os.environ.get('TWOCAPTCHA_API_KEY', 'd0dc6e53acad7efa600b1b8a32a4abe7')
                
                if api_key and api_key != 'ENTER_YOUR_API_KEY':
                    solver = WorkingCaptchaSolver(api_key)
                    if solver.solve_google_recaptcha(self.driver, max_attempts=2):
                        self.logger.info("✅ CAPTCHA solved via 2captcha.com")
                        return True
                    else:
                        self.logger.warning("⚠️ 2captcha solver did not succeed")
                else:
                    self.logger.warning("⚠️ 2captcha API key not set")
            except Exception as e:
                self.logger.warning(f"2captcha failed: {e}")
            
            # Fallback: wait for manual solve
            self.logger.warning("⚠️ Waiting 15 seconds for manual CAPTCHA solve...")
            time.sleep(15)
            return True
            
        except Exception as e:
            self.logger.error(f"Error handling CAPTCHA: {e}")
            return False

    def navigate_to_url(self, url):
        """Navigate to specified URL"""
        try:
            if not self.driver:
                raise RuntimeError("No browser instance available")
                
            self.logger.info(f"Navigating to {url}")
            
            # Try to load the page
            try:
                self.driver.get(url)
            except TimeoutException:
                # Page load timed out, but might still be usable
                self.logger.warning(f"Page load timeout for {url}, checking if usable...")
                # Check if we're at least on the right domain
                current_url = self.driver.current_url
                if url.split('/')[2] in current_url:
                    self.logger.info(f"Page partially loaded, continuing...")
                    return True
                else:
                    self.logger.error(f"Timeout and wrong page: {current_url}")
                    return False
            
            # Wait for page to be ready
            try:
                WebDriverWait(self.driver, 10).until(
                    lambda driver: driver.execute_script("return document.readyState") == "complete"
                )
            except:
                # Page might be usable even if not "complete"
                pass
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error navigating to {url}: {str(e)}")
            return False
    
    def perform_search(self, search_engine, query):
        """Perform search on specified search engine with human-like behavior"""
        try:
            import random
            from config import SEARCH_ENGINES
            
            engine_config = SEARCH_ENGINES.get(search_engine)
            if not engine_config:
                raise ValueError(f"Unsupported search engine: {search_engine}")
            
            # Navigate to search engine
            if not self.navigate_to_url(engine_config["url"]):
                return False
            
            time.sleep(1)  # Brief wait for page load
            
            # Special handling for Firefox + Yahoo (known timeout issue)
            if search_engine == "yahoo" and self.browser_name == "firefox":
                try:
                    # Give Firefox extra time for Yahoo
                    time.sleep(3)
                    # Check if page actually loaded
                    if "yahoo" not in self.driver.current_url.lower():
                        self.logger.warning("Yahoo page didn't load properly on Firefox")
                        return False
                except Exception as e:
                    self.logger.error(f"Firefox + Yahoo check failed: {e}")
                    return False
            
            # Handle initial CAPTCHA if present
            self._handle_captcha_verification()
            
            # Special handling for Bing human verification checkbox
            if search_engine == "bing":
                try:
                    time.sleep(2)
                    # Look for Bing's "I'm not a robot" checkbox
                    checkbox_selectors = [
                        "input[type='checkbox'][id*='verify']",
                        "input[type='checkbox'][name*='verify']",
                        "input[type='checkbox'][aria-label*='verify']",
                        "input[type='checkbox'][aria-label*='human']",
                        "#challenge-running input[type='checkbox']",
                        "input.cb[type='checkbox']"
                    ]
                    
                    for selector in checkbox_selectors:
                        try:
                            checkbox = WebDriverWait(self.driver, 3).until(
                                EC.presence_of_element_located((By.CSS_SELECTOR, selector))
                            )
                            if checkbox and not checkbox.is_selected():
                                self.logger.info(f"✅ Found Bing verification checkbox: {selector}")
                                # Click the checkbox
                                checkbox.click()
                                time.sleep(1)
                                self.logger.info("✅ Clicked Bing verification checkbox")
                                break
                        except:
                            continue
                except Exception as e:
                    self.logger.debug(f"No Bing verification checkbox found (this is OK): {e}")
            
            # Special handling for Yahoo (video overlay issue)
            if search_engine == "yahoo":
                try:
                    # Wait longer for Yahoo to fully load
                    time.sleep(5)
                    
                    # Scroll to top
                    self.driver.execute_script("window.scrollTo(0, 0);")
                    time.sleep(1)
                    
                    # Remove video overlays and modals
                    self.driver.execute_script("""
                        var videos = document.querySelectorAll('video');
                        videos.forEach(function(v) { 
                            v.style.display = 'none'; 
                            v.remove();
                        });
                        var overlays = document.querySelectorAll('[class*="overlay"], [class*="modal"], [class*="promo"]');
                        overlays.forEach(function(o) { 
                            o.style.display = 'none';
                            o.remove();
                        });
                    """)
                    time.sleep(1)
                except Exception as e:
                    self.logger.warning(f"Yahoo video handling: {e}")
            
            # Find search box with longer timeout
            search_box = WebDriverWait(self.driver, 30).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, engine_config["search_box_selector"]))
            )
            
            # Wait for element to be clickable
            search_box = WebDriverWait(self.driver, 30).until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, engine_config["search_box_selector"]))
            )
            
            # For Yahoo, use JavaScript click to avoid overlay issues
            if search_engine == "yahoo":
                try:
                    self.driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", search_box)
                    time.sleep(0.5)
                    self.driver.execute_script("arguments[0].focus(); arguments[0].click();", search_box)
                except:
                    search_box.click()
            else:
                search_box.click()
            
            time.sleep(0.3)
            
            # Type query quickly (no human-like delays)
            search_box.send_keys(query)
            
            time.sleep(0.5)
            search_box.submit()
            
            # Wait for results
            time.sleep(3)
            
            # Check for CAPTCHA after search
            if self._handle_captcha_verification():
                # Wait for CAPTCHA resolution
                time.sleep(8)
            
            # Verify results loaded with longer timeout
            try:
                WebDriverWait(self.driver, 30).until(
                    lambda driver: len(driver.find_elements(By.CSS_SELECTOR, "a[href]")) > 5
                )
            except TimeoutException:
                self.logger.warning("Results may not have loaded completely")
            
            self.logger.info(f"Search completed: '{query}' on {engine_config['name']}")
            return True
            
        except TimeoutException:
            self.logger.error(f"Timeout during search: {query}")
            return False
        except Exception as e:
            self.logger.error(f"Error during search: {str(e)}")
            return False
    
    def get_browser_info(self):
        """Get browser information"""
        if not self.driver:
            return None
            
        try:
            return {
                "name": self.browser_name,
                "version": self.driver.capabilities.get("browserVersion", "Unknown"),
                "user_agent": self.driver.execute_script("return navigator.userAgent;")
            }
        except Exception as e:
            self.logger.error(f"Error getting browser info: {str(e)}")
            return None
    
    def close_browser(self):
        """Close browser instance"""
        try:
            if self.driver:
                self.driver.quit()
                self.logger.info(f"Closed {self.browser_name} browser")
                self.driver = None
                self.browser_name = None
                return True
        except Exception as e:
            self.logger.error(f"Error closing browser: {str(e)}")
            return False
    
    def __enter__(self):
        """Context manager entry"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit"""
        self.close_browser()

# Test the browser manager
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    # Test Chrome browser
    with BrowserManager() as browser:
        if browser.launch_browser("chrome"):
            print("Chrome launched successfully")
            browser.navigate_to_url("https://www.google.com")
            browser.perform_search("google", "test query")
            time.sleep(2)
        else:
            print("Failed to launch Chrome")