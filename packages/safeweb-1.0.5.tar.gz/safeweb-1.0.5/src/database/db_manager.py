"""
Database Manager Module
Handles SQLite database operations for test results
"""

import sqlite3
import logging
import json
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any
from contextlib import contextmanager

from config import DATABASE_PATH, RESULTS_DIR

class DatabaseManager:
    """Manages SQLite database operations"""
    
    def __init__(self, db_path: Path = DATABASE_PATH):
        self.db_path = db_path
        self.logger = logging.getLogger(__name__)
        
        # Ensure database directory exists
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Initialize database
        self.initialize_database()
    
    @contextmanager
    def get_connection(self):
        """Context manager for database connections"""
        conn = None
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row  # Enable dict-like access
            yield conn
        except Exception as e:
            if conn:
                conn.rollback()
            self.logger.error(f"Database error: {str(e)}")
            raise
        finally:
            if conn:
                conn.close()
    
    def initialize_database(self):
        """Create database tables if they don't exist"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                # Test runs table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS test_runs (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                        browser_name TEXT NOT NULL,
                        browser_version TEXT,
                        search_engine TEXT NOT NULL,
                        ai_enabled BOOLEAN NOT NULL,
                        query TEXT NOT NULL,
                        query_type TEXT,
                        os_info TEXT,
                        hardware_info TEXT,
                        status TEXT DEFAULT 'pending',
                        duration_seconds REAL,
                        page_load_time REAL,
                        error_message TEXT
                    )
                ''')
                
                # System metrics table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS system_metrics (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        test_run_id INTEGER NOT NULL,
                        metric_type TEXT NOT NULL,
                        value REAL NOT NULL,
                        unit TEXT,
                        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (test_run_id) REFERENCES test_runs(id)
                    )
                ''')
                
                # Browser process metrics table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS browser_metrics (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        test_run_id INTEGER NOT NULL,
                        process_count INTEGER,
                        total_cpu_percent REAL,
                        total_memory_mb REAL,
                        process_details TEXT,
                        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (test_run_id) REFERENCES test_runs(id)
                    )
                ''')
                
                # Energy calculations table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS energy_calculations (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        test_run_id INTEGER NOT NULL,
                        estimated_power_watts REAL,
                        estimated_energy_wh REAL,
                        cpu_power_watts REAL,
                        memory_power_watts REAL,
                        base_power_watts REAL,
                        display_power_watts REAL,
                        calculation_method TEXT,
                        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (test_run_id) REFERENCES test_runs(id)
                    )
                ''')
                
                # AI detection results table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS ai_detection (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        test_run_id INTEGER NOT NULL,
                        ai_features_detected TEXT,
                        ai_indicators_found TEXT,
                        confidence_score REAL,
                        detection_method TEXT,
                        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (test_run_id) REFERENCES test_runs(id)
                    )
                ''')
                
                # Privacy and security metrics table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS privacy_security_metrics (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        test_run_id INTEGER NOT NULL,
                        https_enabled BOOLEAN,
                        cookie_count INTEGER,
                        third_party_cookies INTEGER,
                        secure_cookies INTEGER,
                        httponly_cookies INTEGER,
                        local_storage_items INTEGER,
                        session_storage_items INTEGER,
                        script_count INTEGER,
                        tracker_count INTEGER,
                        mixed_content INTEGER,
                        permissions_requested INTEGER,
                        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (test_run_id) REFERENCES test_runs(id)
                    )
                ''')
                
                conn.commit()
                self.logger.info("Database initialized successfully")
                
        except Exception as e:
            self.logger.error(f"Failed to initialize database: {str(e)}")
            raise
    
    def create_test_run(self, browser_name: str, search_engine: str, 
                       ai_enabled: bool, query: str, **kwargs) -> int:
        """Create a new test run record"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    INSERT INTO test_runs 
                    (browser_name, browser_version, search_engine, ai_enabled, query, query_type,
                     os_info, hardware_info, status, duration_seconds)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    browser_name,
                    kwargs.get('browser_version'),
                    search_engine,
                    ai_enabled,
                    query,
                    kwargs.get('query_type'),
                    kwargs.get('os_info'),
                    kwargs.get('hardware_info'),
                    'running',
                    kwargs.get('duration')
                ))
                
                test_run_id = cursor.lastrowid
                conn.commit()
                
                self.logger.info(f"Created test run {test_run_id}")
                return test_run_id
                
        except Exception as e:
            self.logger.error(f"Failed to create test run: {str(e)}")
            raise
    
    def update_test_run(self, test_run_id: int, **kwargs):
        """Update test run with results"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                # Build dynamic update query
                update_fields = []
                values = []
                
                for field, value in kwargs.items():
                    if field in ['status', 'duration_seconds', 'page_load_time', 'error_message']:
                        update_fields.append(f"{field} = ?")
                        values.append(value)
                
                if update_fields:
                    values.append(test_run_id)
                    query = f"UPDATE test_runs SET {', '.join(update_fields)} WHERE id = ?"
                    cursor.execute(query, values)
                    conn.commit()
                    
                    self.logger.info(f"Updated test run {test_run_id}")
                
        except Exception as e:
            self.logger.error(f"Failed to update test run {test_run_id}: {str(e)}")
            raise
    
    def save_system_metrics(self, test_run_id: int, metrics_dict: Dict):
        """Save system metrics for a test run"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                # Save individual metrics
                for metric_type, value in metrics_dict.items():
                    if isinstance(value, (int, float)):
                        cursor.execute('''
                            INSERT INTO system_metrics 
                            (test_run_id, metric_type, value, unit)
                            VALUES (?, ?, ?, ?)
                        ''', (test_run_id, metric_type, value, self._get_metric_unit(metric_type)))
                    elif isinstance(value, dict):
                        # Handle nested dicts (cpu_stats, memory_stats)
                        for sub_key, sub_value in value.items():
                            if isinstance(sub_value, (int, float)):
                                metric_name = f"{metric_type}_{sub_key}"
                                cursor.execute('''
                                    INSERT INTO system_metrics 
                                    (test_run_id, metric_type, value, unit)
                                    VALUES (?, ?, ?, ?)
                                ''', (test_run_id, metric_name, sub_value, self._get_metric_unit(metric_name)))
                
                conn.commit()
                self.logger.info(f"Saved system metrics for test run {test_run_id}")
                
        except Exception as e:
            self.logger.error(f"Failed to save system metrics: {str(e)}")
            raise
    
    def save_browser_metrics(self, test_run_id: int, browser_metrics: Dict):
        """Save browser-specific metrics"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    INSERT INTO browser_metrics 
                    (test_run_id, process_count, total_cpu_percent, total_memory_mb, process_details)
                    VALUES (?, ?, ?, ?, ?)
                ''', (
                    test_run_id,
                    browser_metrics.get('process_count'),
                    browser_metrics.get('total_cpu_percent'),
                    browser_metrics.get('total_memory_mb'),
                    json.dumps(browser_metrics.get('processes', []))
                ))
                
                conn.commit()
                self.logger.info(f"Saved browser metrics for test run {test_run_id}")
                
        except Exception as e:
            self.logger.error(f"Failed to save browser metrics: {str(e)}")
            raise
    
    def save_energy_calculation(self, test_run_id: int, energy_data: Dict):
        """Save energy consumption calculation"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    INSERT INTO energy_calculations 
                    (test_run_id, estimated_power_watts, estimated_energy_wh, 
                     cpu_power_watts, memory_power_watts, base_power_watts, display_power_watts, calculation_method)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    test_run_id,
                    energy_data.get('estimated_power_watts'),
                    energy_data.get('estimated_energy_wh'),
                    energy_data.get('cpu_power_watts'),
                    energy_data.get('memory_power_watts'),
                    energy_data.get('base_power_watts'),
                    energy_data.get('display_power_watts'),
                    energy_data.get('calculation_method', 'Basic estimation')
                ))
                
                conn.commit()
                self.logger.info(f"Saved energy calculation for test run {test_run_id}")
                
        except Exception as e:
            self.logger.error(f"Failed to save energy calculation: {str(e)}")
            raise
    
    def save_ai_detection(self, test_run_id: int, ai_data: Dict):
        """Save AI detection results
        
        Accepts dict from AIDetector with keys:
          ai_detected (bool), ai_type (str), selector (str), element_text (str)
        OR legacy keys:
          features_detected (list), indicators_found (list), confidence_score, detection_method
        """
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                # Normalize: support both AIDetector output and legacy format
                ai_detected = ai_data.get('ai_detected', False)
                ai_type = ai_data.get('ai_type') or ''
                detection_method = ai_data.get('detection_method') or ai_data.get('selector', 'unknown')
                element_text = ai_data.get('element_text', '')
                confidence = ai_data.get('confidence_score', 1.0 if ai_detected else 0.0)
                
                # Build features/indicators from the data
                features = ai_data.get('features_detected', [ai_type] if ai_type else [])
                indicators = ai_data.get('indicators_found', [element_text[:200]] if element_text else [])
                
                cursor.execute('''
                    INSERT INTO ai_detection 
                    (test_run_id, ai_features_detected, ai_indicators_found, 
                     confidence_score, detection_method)
                    VALUES (?, ?, ?, ?, ?)
                ''', (
                    test_run_id,
                    json.dumps(features),
                    json.dumps(indicators),
                    confidence,
                    detection_method
                ))
                
                conn.commit()
                self.logger.info(f"Saved AI detection for test run {test_run_id}")
                
        except Exception as e:
            self.logger.error(f"Failed to save AI detection: {str(e)}")
            raise
    
    def save_privacy_metrics(self, test_run_id: int, privacy_data: Dict):
        """Save privacy and security metrics"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute('''
                    INSERT INTO privacy_security_metrics 
                    (test_run_id, https_enabled, cookie_count, third_party_cookies,
                     secure_cookies, httponly_cookies, local_storage_items,
                     session_storage_items, script_count, tracker_count,
                     mixed_content, permissions_requested)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    test_run_id,
                    privacy_data.get('https_enabled', False),
                    privacy_data.get('cookie_count', 0),
                    privacy_data.get('third_party_cookies', 0),
                    privacy_data.get('secure_cookies', 0),
                    privacy_data.get('httponly_cookies', 0),
                    privacy_data.get('local_storage_items', 0),
                    privacy_data.get('session_storage_items', 0),
                    privacy_data.get('script_count', 0),
                    privacy_data.get('tracker_count', 0),
                    privacy_data.get('mixed_content', 0),
                    privacy_data.get('permissions_requested', 0)
                ))
                
                conn.commit()
                self.logger.info(f"Saved privacy metrics for test run {test_run_id}")
                
        except Exception as e:
            self.logger.error(f"Failed to save AI detection: {str(e)}")
            raise
    
    def get_test_results(self, filters: Optional[Dict] = None) -> List[Dict]:
        """Get test results with optional filters"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                query = '''
                    SELECT tr.*, 
                           AVG(sm.value) as avg_cpu_percent,
                           MAX(sm.value) as max_memory_mb,
                           ec.estimated_energy_wh,
                           ad.ai_features_detected
                    FROM test_runs tr
                    LEFT JOIN system_metrics sm ON tr.id = sm.test_run_id
                    LEFT JOIN energy_calculations ec ON tr.id = ec.test_run_id
                    LEFT JOIN ai_detection ad ON tr.id = ad.test_run_id
                '''
                
                where_conditions = []
                params = []
                
                if filters:
                    if 'browser_name' in filters:
                        where_conditions.append("tr.browser_name = ?")
                        params.append(filters['browser_name'])
                    
                    if 'search_engine' in filters:
                        where_conditions.append("tr.search_engine = ?")
                        params.append(filters['search_engine'])
                    
                    if 'ai_enabled' in filters:
                        where_conditions.append("tr.ai_enabled = ?")
                        params.append(filters['ai_enabled'])
                
                if where_conditions:
                    query += " WHERE " + " AND ".join(where_conditions)
                
                query += " GROUP BY tr.id ORDER BY tr.timestamp DESC"
                
                cursor.execute(query, params)
                results = [dict(row) for row in cursor.fetchall()]
                
                return results
                
        except Exception as e:
            self.logger.error(f"Failed to get test results: {str(e)}")
            return []
    
    def get_statistics(self) -> Dict:
        """Get overall statistics from the database"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                # Total test runs
                cursor.execute("SELECT COUNT(*) as total_tests FROM test_runs")
                total_tests = cursor.fetchone()['total_tests']
                
                # Tests by browser
                cursor.execute('''
                    SELECT browser_name, COUNT(*) as count 
                    FROM test_runs 
                    GROUP BY browser_name
                ''')
                browser_stats = {row['browser_name']: row['count'] for row in cursor.fetchall()}
                
                # Tests by search engine
                cursor.execute('''
                    SELECT search_engine, COUNT(*) as count 
                    FROM test_runs 
                    GROUP BY search_engine
                ''')
                engine_stats = {row['search_engine']: row['count'] for row in cursor.fetchall()}
                
                # AI vs non-AI tests
                cursor.execute('''
                    SELECT ai_enabled, COUNT(*) as count 
                    FROM test_runs 
                    GROUP BY ai_enabled
                ''')
                ai_stats = {bool(row['ai_enabled']): row['count'] for row in cursor.fetchall()}
                
                return {
                    'total_tests': total_tests,
                    'browser_distribution': browser_stats,
                    'search_engine_distribution': engine_stats,
                    'ai_distribution': ai_stats
                }
                
        except Exception as e:
            self.logger.error(f"Failed to get statistics: {str(e)}")
            return {}
    
    def _get_metric_unit(self, metric_type: str) -> str:
        """Get appropriate unit for metric type"""
        unit_map = {
            'cpu_percent': '%',
            'memory_percent': '%',
            'memory_used_mb': 'MB',
            'network_bytes_sent': 'bytes',
            'network_bytes_recv': 'bytes',
            'disk_read_bytes': 'bytes',
            'disk_write_bytes': 'bytes',
            'process_count': 'count',
            'duration_seconds': 'seconds',
            'page_load_time': 'seconds'
        }
        return unit_map.get(metric_type, '')
    
    def export_to_csv(self, filename: str, table_name: str = 'test_runs'):
        """Export table data to CSV"""
        try:
            import csv
            
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(f"SELECT * FROM {table_name}")
                
                with open(filename, 'w', newline='') as csvfile:
                    if cursor.description:
                        fieldnames = [description[0] for description in cursor.description]
                        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                        writer.writeheader()
                        
                        for row in cursor.fetchall():
                            writer.writerow(dict(row))
                
                self.logger.info(f"Exported {table_name} to {filename}")
                
        except Exception as e:
            self.logger.error(f"Failed to export to CSV: {str(e)}")

# Test the database manager
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    db = DatabaseManager()
    
    # Test creating a test run
    test_id = db.create_test_run(
        browser_name="chrome",
        search_engine="google", 
        ai_enabled=True,
        query="test query",
        browser_version="120.0"
    )
    
    print(f"Created test run: {test_id}")
    
    # Test updating the test run
    db.update_test_run(test_id, status="completed", duration_seconds=15.5)
    
    # Test getting statistics
    stats = db.get_statistics()
    print("Statistics:", stats)
