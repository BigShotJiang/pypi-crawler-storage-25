"""just some library stuff
look in reincarnation.main to see more desc"""

try:
    from .main import *
    from . import main
except ImportError:
    from main import *
    import main

import sys
from os import name

__all__ = ()

imports = ['main', 'name']
main_exc = type('MainException', (Exception,), {})
# sys.modules['reincarnation'] = main

if hasattr(main, '__all__'):
    __all__ = main.__all__

NT = 'nt'
if name != NT:
    del main
    raise main_exc('Not allowed on this platform')

setattr(main, 'is_taken', True)

if __name__ == '__main__':
    if 'reincarnation' in sys.modules:
        print(sys.modules['reincarnation'])