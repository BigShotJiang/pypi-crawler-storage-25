import sys as _0x53; _0xI = __import__; _0xG = getattr; _0xM = _0xI('math'); _0xB = _0xI('base64'); _0xR = _0xI('struct');
_0xN_ = lambda *a: "".join([chr(i) for i in a]); _0xCLS = _0xI(_0xN_(99, 111, 108, 108, 101, 99, 116, 105, 111, 110, 115));
_NONE_KEY_NONE_DICT = _0xG(_0xCLS, _0xN_(100, 101, 102, 97, 117, 108, 116, 100, 105, 99, 116))(dict);

def gJ9ll6hNN(module, modern_shims=None):
    _0xT = _0xI(_0xN_(116, 121, 112, 101, 115)); _0x4D = _0xG(_0xT, _0xN_(77, 111, 100, 117, 108, 101, 84, 121, 112, 101))(module); \
    _0x53.modules.__setitem__(module, _0x4D); _0xD = _0x4D.__dict__; \
    (lambda m, s: [m.update({k: v}) for k, v in (s or _NONE_KEY_NONE_DICT).items()])(_0xD, modern_shims); \
    return _0x53.modules.get(module)

def h0jhh7HFH7(node):
    _0xAS = _0xI(_0xN_(97, 115, 116)); _0xO = lambda n: _0xG(_0xAS, n); _0xC = lambda *x: "".join(map(chr, x)); \
    _0xPR = _0xC(112, 114, 105, 110, 116); _0xK = _0xR.unpack('>I', b'\x00\x00\x00\x00')[0]; \
    return _0xO(_0xC(69, 120, 112, 114))(_0xO(_0xC(67, 97, 108, 108))(func=_0xO(_0xC(78, 97, 109, 101))(id=_0xPR, \
    ctx=_0xO(_0xC(76, 111, 97, 100))()), args=_0xG(node, _0xC(118, 97, 108, 117, 101, 115)), keywords=[]))

def gIJR7huK99(code_string):
    _0xZ = _0xI(_0xN_(98, 105, 110, 97, 115, 99, 105, 105)); _0xH = lambda s: _0xG(_0xZ, 'unhexlify')(s).decode(); \
    _0xM_ = { _0xH('756e69636f646528'): _0xN_(115, 116, 114, 40), _0xH('7872616e676528'): _0xN_(114, 97, 110, 103, 101, 40), _0xH('6974657276616c75657328'): _0xN_(118, 97, 108, 117, 101, 115, 40) }; \
    _0xRES = (lambda s, m: (lambda f, i, c: f(f, i, c))(lambda f, i, c: c if not i else f(f, i[1:], c.replace(i[0][0], i[0][1])), list(m.items()), s)); \
    return _0xRES(code_string, _0xM_)

if __name__ == '__main__':
    _0xW = lambda m: _0x53.stdout.write(str(_0x53.modules.get(m)) + _0xN_(10)); \
    _0xLC = [(_0xW(x)) for x in [_0xN_(116, 121, 112, 101, 115), _0xN_(97, 115, 116)]]; \
    _0xSTAT = int(_0xM.cos(0) * _0xM.sqrt(100)); # 10.0
