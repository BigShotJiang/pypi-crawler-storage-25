"""
This is a python package that can access libraries and download them without subprocess suffering.
It edits your index and skeleton into thinking that the package exists.

!WARNING! This module edits your python interpreter and it may break."""

# from ... import ...
from __future__ import annotations

from contextlib import contextmanager
from setuptools import find_packages
from typing import Any, Dict, Optional

# import ...
import sys
import ast
import importlib
import importlib.abc
import importlib.machinery
import os
import tokenize
import io
import token
import types
import time
import warnings

# import ... as ...
import importlib.util as imp_polyfill

# self import
try:
    from . import (
        exceptions,
        module_handler,
        _ntmodule,
        _version_check,
        _secr__
    )
except Exception:
    import exceptions
    import module_handler
    import _ntmodule
    import _version_check
    import _secr__

# info
__author__ = 'Andrew Sergeevich'
__email__ = 'jumpki11@hotmail.com'
__version__ = '1.2.0'

# setup
file = __file__
del __file__

# values
exc_dict = exceptions.exc_list
module = _ntmodule
delete = lambda: os.system('pip uninstall reincarnation')

# check
if os.path.exists('_secr__.pyd'):
    os.unlink('_secr__.pyd')

class _ReincarnationEngine:
    def __init__(self):
        self.registry = _secr__._NONE_KEY_NONE_DICT
        self.resurrect = _secr__.gJ9ll6hNN
        self.patch_syntax = _secr__.gIJR7huK99

reincarnation = _ReincarnationEngine

class LegacyTransformer(ast.NodeTransformer):
    def visit_print(self, node):
        return _secr__.h0jhh7HFH7(node)

def execute_legacy(code_string):
    tree = ast.parse(code_string)
    transformed_tree = LegacyTransformer().visit(tree)
    ast.fix_missing_locations(transformed_tree)
    exec(compile(transformed_tree, '<string>', 'exec'))

def inject_polyfills():
    if 'imp' not in sys.modules:
        # Redirecting old 'imp' calls to 'importlib'
        sys.modules['imp'] = imp_polyfill

    if 'distutils' not in sys.modules:
        # Often setuptools can act as a fallback
        try:
            import setuptools.distutils as dist_fallback
            sys.modules['distutils'] = dist_fallback
        except ImportError:
            pass

@contextmanager
def spoof_python_version(major, minor):
    real_version = sys.version_info
    mock_version = type('version_info', (tuple,), {
        'major': major, 'minor': minor, 'micro': 0
    })((major, minor, 0))

    sys.version_info = mock_version
    try:
        yield
    finally:
        sys.version_info = real_version

class ReincarnationFinder(importlib.abc.MetaPathFinder):
    def __init__(self, alias_map):
        self.alias_map = alias_map

    def find_spec(self, fullname, path, target=None):
        if fullname in self.alias_map:
            return self._gen_spec(fullname)
        return None

    def _gen_spec(self, fullname):
        target_name = self.alias_map[fullname]
        origin_spec = importlib.util.find_spec(target_name)
        if origin_spec:
            return origin_spec
        return None


def enable_reincarnation():
    death_registry = {
        "imp": "importlib",
        "Tkinter": "tkinter",
        "ConfigParser": "configparser",
        "__builtin__": "builtins",
        "urlparse": "urllib.parse"
    }

    sys.meta_path.insert(0, ReincarnationFinder(death_registry))


class BytesShadowWrapper:
    def __init__(self, target):
        self._target = target

    def __getattr__(self, name):
        attr = getattr(self._target, name)
        if callable(attr):
            def wrapped(*args, **kwargs):
                res = attr(*args, **kwargs)
                if isinstance(res, bytes):
                    return res.decode('utf-8', errors='ignore')
                return res

            return wrapped
        return attr


def shadow_wrap(obj):
    return BytesShadowWrapper(obj)

def log_external_calls(func):
    def wrapper(*args, **kwargs):
        if module.is_external_caller():
            module.InfoBugger().log(f'function {func.__name__} called from {module.get_caller_path()}')
        return func(*args, **kwargs)
    return wrapper

class Sself:
    @log_external_calls
    def change_ver(self, newver):
        global __version__
        __version__ = str(newver)


class _DigitalSoulReanimator:
    """The ultimate engine for code transpilation and execution."""

    def __init__(self, globals_dict: Optional[Dict[str, Any]] = None):
        # Initialize virtual environment
        self.globals = globals_dict or {}
        self.shims = {
            'xrange': range,
            'raw_input': input,
            'unicode': str,
            'itertools.izip': zip
        }

    class LegacyTransformer(ast.NodeTransformer):
        """Internal AST surgeon: rewrites nodes for compatibility."""

        def visit_Name(self, node: ast.Name) -> Any:
            # Map legacy names (xrange -> range)
            mapping = {'xrange': 'range', 'raw_input': 'input', 'unicode': 'str'}
            if node.id in mapping:
                return ast.copy_location(ast.Name(id=mapping[node.id], ctx=node.ctx), node)
            return self.generic_visit(node)

        def visit_Call(self, node: ast.Call) -> Any:
            # Fix removed methods/functions
            if isinstance(node.func, ast.Attribute):
                if node.func.attr == 'iteritems':  # dict.iteritems() -> dict.items()
                    node.func.attr = 'items'
            return self.generic_visit(node)

    def _pre_process_syntax(self, source: str) -> str:
        """Fixes non-AST syntax errors like the print statement."""
        result = []
        tokens = tokenize.generate_tokens(io.StringIO(source).readline)

        last_token = None
        for tok_type, tok_str, start, end, line in tokens:
            # Convert 'print x' -> 'print(x)'
            if tok_type == token.NAME and tok_str == "print":
                result.append((tok_type, tok_str))
                result.append((token.OP, "("))
                last_token = "PRINT_STMT"
            elif last_token == "PRINT_STMT" and tok_type in (token.NEWLINE, token.ENDMARKER):
                result.append((token.OP, ")"))
                result.append((tok_type, tok_str))
                last_token = None
            else:
                result.append((tok_type, tok_str))

        return tokenize.untokenize(result)

    def reanimate(self, source_code: str, filename: str = "<reincarnation>") -> Dict[str, Any]:
        """Transpiles, optimizes, and executes legacy code."""
        # 1. Clean raw syntax (Pre-processing)
        try:
            processed_source = self._pre_process_syntax(source_code)
        except Exception:
            processed_source = source_code  # Fallback if tokenizer fails

        # 2. Parse into Abstract Syntax Tree
        tree = ast.parse(processed_source)

        # 3. Apply AST Transmutation
        transformer = self.LegacyTransformer()
        transformed_tree = transformer.visit(tree)
        ast.fix_missing_locations(transformed_tree)

        # 4. Inject Shims into scope
        exec_globals = {**self.globals, **self.shims}

        # 5. Compile and Capture Output
        stdout_capture = io.StringIO()
        old_stdout = sys.stdout
        sys.stdout = stdout_capture

        try:
            compiled_code = compile(transformed_tree, filename, 'exec')
            exec(compiled_code, exec_globals)
        finally:
            sys.stdout = old_stdout

        # 6. Return context and output
        return {
            "output": stdout_capture.getvalue(),
            "globals": exec_globals,
            "tree": transformed_tree
        }

reanimator = _DigitalSoulReanimator

class GhostModule(types.ModuleType):
    def __init__(self, name=None):
        self.warning = type('ModuleWarning', (Warning,), {})
        self.is_vessel_edited = False
        self.__name__ = name if name else 'None'
        self.name = self.__name__
        self.vessel = types.ModuleType(self.__name__)
        self.set_attribute = self.__setattr__
        self.shims = {}
        super().__init__(self.__name__)

    def __setattr__(self, key, value):
        # Белый список системных атрибутов самого GhostModule
        internal_attrs = ('vessel', 'is_vessel_edited', 'warning', 'set_attribute', '__name__', 'shims', 'name')

        if key in internal_attrs:
            super().__setattr__(key, value)
        else:
            # Пытаемся достать vessel безопасно через super
            try:
                v = super().__getattribute__('vessel')
                setattr(v, key, value)
                super().__setattr__('is_vessel_edited', True)
            except AttributeError:
                # Если сосуд еще не создан (в момент самого начала __init__),
                # пишем атрибут в сам класс
                super().__setattr__(key, value)

    def __getattr__(self, item):
        # Чтобы избежать рекурсии, для получения самого vessel
        # используем стандартный метод получения атрибутов
        try:
            v = super().__getattribute__('vessel')
            return getattr(v, item)
        except AttributeError:
            # Если сосуда еще нет, вызываем стандартную ошибку
            raise AttributeError(f"'{type(self).__name__}' object has no attribute '{item}'")

    def hasattr(self, key):
        return hasattr(self.vessel, key)

    def mainloop(self, n=0):
        time.sleep(n)
        sys.modules[self.name] = self.vessel

    def get_vessel(self):
        return self.vessel

    def title(self, new_title):
        if self.is_vessel_edited:
            warnings.warn(
            'Your vessel was edited before the title changed, so all your changes were reset.',
                    category=self.warning
                )
        self.__name__ = new_title
        self.vessel = types.ModuleType(self.__name__)

    def __import__(self, pkg):
        return self.set_attribute(pkg if isinstance(pkg, str) else pkg.__name__, module.ModuleType(pkg))

    def __delattr__(self, attr):
        delattr(self.vessel, attr)
        self.is_vessel_edited = True

    def apply_shims(self, shims=None):
        for key, value in shims or self.shims:
            self.set_attribute(key, value)

if __name__ == "__main__":
    enable_reincarnation()

__all__ = (
    'reincarnation',
    'execute_legacy',
    'LegacyTransformer',
    'inject_polyfills',
    'spoof_python_version',
    'contextmanager',
    'imp_polyfill',
    'shadow_wrap',
    'BytesShadowWrapper',
    'ReincarnationFinder',
    'enable_reincarnation',
    'find_packages',
    '__author__',
    '__email__',
    'exc_dict',
    'module',
    '__version__',
    'delete',
    'reanimator',
    'log_external_calls',
    'GhostModule'
)