#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
MoleditPy — A Python-based molecular editing software

Author: Hiromichi Yokoyama
License: GPL-3.0 license
Repo: https://github.com/HiroYokoyama/python_molecular_editor
DOI: 10.5281/zenodo.17268532
"""

from __future__ import annotations
import ast
import hashlib
import importlib.util
import logging
import os
import shutil
import sys
import zipfile
from typing import Any, Callable, Dict, List, Optional, Tuple

from PyQt6.QtCore import QUrl
from PyQt6.QtGui import QDesktopServices
from PyQt6.QtWidgets import QMessageBox

try:
    from .plugin_interface import PluginContext
except ImportError:
    # Fallback if running as script
    from moleditpy_linux.plugins.plugin_interface import PluginContext


class PluginManager:
    def _compute_sha256(self, path: str) -> str:
        """Computes SHA-256 for a file or a directory (concatenated hashes of all files)."""
        if os.path.isfile(path):
            return self._sha256_for_file(path)
        if os.path.isdir(path):
            return self._sha256_for_directory(path)
        return "N/A"

    def _sha256_for_file(self, path: str) -> str:
        """Computes SHA-256 for a single file."""
        hasher = hashlib.sha256()
        try:
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(8192), b""):
                    hasher.update(chunk)
            return hasher.hexdigest()
        except (AttributeError, OSError, RuntimeError, ValueError, TypeError):
            return "N/A"

    def _sha256_for_directory(self, dir_path: str) -> str:
        """Computes SHA-256 for a directory by hashing all files in sorted order."""
        hasher = hashlib.sha256()
        try:
            root = os.path.abspath(dir_path)
            for current_root, _dirs, files in os.walk(root):
                rel_root = os.path.relpath(current_root, root)
                for filename in sorted(files):
                    file_path = os.path.join(current_root, filename)
                    rel_path = os.path.normpath(os.path.join(rel_root, filename))
                    # Hash the path to ensure directory structure is captured
                    hasher.update(rel_path.encode("utf-8", errors="replace"))
                    hasher.update(b"\0")
                    with open(file_path, "rb") as f:
                        for chunk in iter(lambda: f.read(8192), b""):
                            hasher.update(chunk)
                    hasher.update(b"\0")
            return hasher.hexdigest()
        except (AttributeError, OSError, RuntimeError, ValueError, TypeError):
            return "N/A"

    def __init__(self, main_window: Any = None) -> None:
        self.plugin_dir: str = os.path.join(
            os.path.expanduser("~"), ".moleditpy", "plugins"
        )
        self.plugins: List[Dict[str, Any]] = []  # List of dicts
        self.main_window: Any = main_window

        # Registries for actions
        self.menu_actions: List[Dict[str, Any]] = []
        self.toolbar_actions: List[Dict[str, Any]] = []
        self.drop_handlers: List[Dict[str, Any]] = []

        # Extended Registries
        self.export_actions: List[Dict[str, Any]] = []
        self.optimization_methods: Dict[str, Dict[str, Any]] = {}
        self.file_openers: Dict[str, List[Dict[str, Any]]] = {}
        self.analysis_tools: List[Dict[str, Any]] = []
        self.save_handlers: Dict[str, Callable] = {}
        self.load_handlers: Dict[str, Callable] = {}
        self.custom_3d_styles: Dict[str, Dict[str, Any]] = {}
        self.document_reset_handlers: List[Dict[str, Any]] = []
        self.plugin_windows: Dict[
            str, Dict[str, Any]
        ] = {}  # Map of plugin_name -> {window_id -> window}

    def get_main_window(self) -> Any:
        return self.main_window

    def set_main_window(self, mw: Any) -> None:
        self.main_window = mw

    def ensure_plugin_dir(self) -> None:
        """Creates the plugin directory if it doesn't exist."""
        if not os.path.exists(self.plugin_dir):
            try:
                os.makedirs(self.plugin_dir)
            except OSError as e:
                logging.error(f"Error creating plugin directory: {e}")

    def open_plugin_folder(self) -> None:
        """Opens the plugin directory in the OS file explorer."""
        self.ensure_plugin_dir()
        QDesktopServices.openUrl(QUrl.fromLocalFile(self.plugin_dir))

    def install_plugin(self, file_path: str) -> Tuple[bool, str]:
        """Copies a plugin file to the plugin directory. Supports .py and .zip."""
        self.ensure_plugin_dir()
        try:
            # Handle trailing slash and normalize path
            file_path = os.path.normpath(file_path)
            filename = os.path.basename(file_path)

            if os.path.isdir(file_path):
                # Copy entire directory
                dest_path = os.path.join(self.plugin_dir, filename)
                if os.path.exists(dest_path):
                    # Option 1: Overwrite (remove then copy) - safer for clean install
                    if os.path.isdir(dest_path):
                        shutil.rmtree(dest_path)
                    else:
                        os.remove(dest_path)

                # Copy directory, ignoring cache files
                shutil.copytree(
                    file_path,
                    dest_path,
                    ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".git"),
                )
                msg = f"Installed package {filename}"
            elif filename.lower().endswith(".zip"):
                # Extract ZIP contents
                with zipfile.ZipFile(file_path, "r") as zf:
                    # Smart Extraction: Check if ZIP has a single top-level folder
                    # Fix for paths with backslashes on Windows if zip was created on Windows
                    roots = set()
                    for name in zf.namelist():
                        # Normalize path separators to forward slash for consistent check
                        name = name.replace("\\", "/")
                        parts = name.split("/")
                        if parts[0]:
                            roots.add(parts[0])

                    is_nested = len(roots) == 1

                    if is_nested:
                        # Case A: ZIP contains a single folder (e.g. MyPlugin/init.py)
                        top_folder = list(roots)[0]

                        # Guard: If the single item is __init__.py, we MUST create a wrapper folder
                        # otherwise we pollute the plugin_dir root.
                        if top_folder == "__init__.py":
                            is_nested = False

                    if is_nested:
                        # Case A (Confirmed): Extract directly
                        dest_path = os.path.join(self.plugin_dir, top_folder)

                        # Clean Install: Remove existing folder to prevent stale files
                        if os.path.exists(dest_path):
                            if os.path.isdir(dest_path):
                                shutil.rmtree(dest_path)
                            else:
                                os.remove(dest_path)

                        zf.extractall(self.plugin_dir)
                        msg = f"Installed package {top_folder} (from ZIP)"
                    else:
                        # Case B: ZIP is flat (e.g. file1.py, file2.py or just __init__.py)
                        # Extract into a new folder named after the ZIP file
                        folder_name = os.path.splitext(filename)[0]
                        dest_path = os.path.join(self.plugin_dir, folder_name)

                        if os.path.exists(dest_path):
                            if os.path.isdir(dest_path):
                                shutil.rmtree(dest_path)
                            else:
                                os.remove(dest_path)

                        os.makedirs(dest_path)
                        zf.extractall(dest_path)
                        msg = f"Installed package {folder_name} (from Flat ZIP)"
            else:
                # Standard file copy
                dest_path = os.path.join(self.plugin_dir, filename)
                if os.path.exists(dest_path):
                    if os.path.isdir(dest_path):
                        shutil.rmtree(dest_path)
                shutil.copy2(file_path, dest_path)
                msg = f"Installed {filename}"

            # Reload plugins after install
            if self.main_window:
                self.discover_plugins(self.main_window)
            return True, msg
        except (
            AttributeError,
            RuntimeError,
            ValueError,
            OSError,
            ImportError,
            SyntaxError,
        ) as e:
            return False, str(e)

    def discover_plugins(self, parent: Any = None) -> List[Dict[str, Any]]:
        """
        Hybrid discovery:
        - Folders with '__init__.py' -> Treated as single package plugin.
        - Folders without '__init__.py' -> Treated as category folders (scan for .py inside).
        """
        if parent:
            self.main_window = parent

        self.ensure_plugin_dir()
        self.plugins = []
        # Clear registries
        self.menu_actions = []
        self.toolbar_actions = []
        self.drop_handlers = []
        self.export_actions = []
        self.optimization_methods = {}
        self.file_openers = {}
        self.analysis_tools = []
        self.save_handlers = {}
        self.load_handlers = {}
        self.custom_3d_styles = {}
        self.document_reset_handlers = []

        if not os.path.exists(self.plugin_dir):
            return []

        for root, dirs, files in os.walk(self.plugin_dir):
            # Exclude hidden directories
            dirs[:] = [d for d in dirs if not d.startswith("__") and d != "__pycache__"]

            # [Check] Is current dir a package (plugin body)?
            if "__init__.py" in files:
                # === Case 1: Package Plugin (Folder is the plugin) ===

                # Stop recursion into this folder
                dirs[:] = []

                entry_point = os.path.join(root, "__init__.py")
                # Category is relative path to parent folder
                rel_path = os.path.relpath(os.path.dirname(root), self.plugin_dir)
                category = rel_path if rel_path != "." else ""

                # Module name is the folder name
                module_name = os.path.basename(root)

                self._load_single_plugin(entry_point, module_name, category)

            else:
                # === Case 2: Category Folder (Load individual .py files) ===

                # Category is relative path to current folder
                rel_path = os.path.relpath(root, self.plugin_dir)
                category = rel_path if rel_path != "." else ""

                for filename in files:
                    if filename.endswith(".py") and not filename.startswith("__"):
                        entry_point = os.path.join(root, filename)
                        module_name = os.path.splitext(filename)[0]

                        self._load_single_plugin(entry_point, module_name, category)

        return self.plugins

    def _load_single_plugin(
        self, filepath: str, module_name: str, category: str
    ) -> None:
        """Common loading logic for both single-file and package plugins."""
        try:
            # Ensure unique module name by including category path
            # e.g. Analysis.Docking
            unique_module_name = (
                f"{category.replace(os.sep, '.')}.{module_name}"
                if category
                else module_name
            )
            unique_module_name = unique_module_name.strip(".")

            is_package = os.path.basename(filepath) == "__init__.py"
            pkg_dir = os.path.dirname(filepath) if is_package else None

            # For package plugins, register stub parent packages so that
            # relative imports (e.g. "from . import parser") resolve correctly.
            if is_package and "." in unique_module_name:
                parts = unique_module_name.split(".")
                for i in range(1, len(parts)):
                    parent_name = ".".join(parts[:i])
                    if parent_name not in sys.modules:
                        import types as _types

                        stub = _types.ModuleType(parent_name)
                        stub.__path__ = []
                        stub.__package__ = parent_name
                        sys.modules[parent_name] = stub

            spec = importlib.util.spec_from_file_location(
                unique_module_name,
                filepath,
                submodule_search_locations=([pkg_dir] if is_package else None),  # type: ignore[list-item]
            )
            if spec and spec.loader:
                module = importlib.util.module_from_spec(spec)
                sys.modules[spec.name] = module

                # Inject category info
                module.PLUGIN_CATEGORY = category

                spec.loader.exec_module(module)

                # --- Metadata Extraction ---
                # Metadata
                # Priority: PLUGIN_XXX > __xxx__ > Fallback
                plugin_name = getattr(module, "PLUGIN_NAME", module_name)
                plugin_version = getattr(
                    module, "PLUGIN_VERSION", getattr(module, "__version__", "Unknown")
                )
                plugin_author = getattr(
                    module, "PLUGIN_AUTHOR", getattr(module, "__author__", "Unknown")
                )
                plugin_desc = getattr(
                    module, "PLUGIN_DESCRIPTION", getattr(module, "__doc__", "")
                )
                plugin_category = getattr(module, "PLUGIN_CATEGORY", category)

                # Additional cleanup for docstring (strip whitespace)
                if plugin_desc is None:
                    plugin_desc = ""
                plugin_desc = str(plugin_desc).strip()

                # Handle version tuple
                if isinstance(plugin_version, tuple):
                    plugin_version = ".".join(map(str, plugin_version))

                # Interface compliance
                has_run = hasattr(module, "run") and callable(module.run)
                has_autorun = hasattr(module, "autorun") and callable(module.autorun)
                has_init = hasattr(module, "initialize") and callable(module.initialize)

                status = "Loaded"

                # Execute initialization
                if has_init:
                    context = PluginContext(self, plugin_name)
                    # Pass category to context if needed, currently not storing it in context directly but could be useful
                    try:
                        module.initialize(context)
                    except (
                        AttributeError,
                        RuntimeError,
                        ValueError,
                        OSError,
                        ImportError,
                        SyntaxError,
                    ) as e:
                        # [BROAD EXCEPTION] Plugins have root power; catch all potential failures during init.
                        status = f"Error (Init): {e}"
                        # Initialization errors are stored in plugin status for display in Plugin Dialog
                        logging.error(f"Plugin {plugin_name} initialize error: {e}")
                elif has_autorun:
                    try:
                        if self.main_window:
                            module.autorun(self.main_window)
                        else:
                            status = "Skipped (No MW)"
                    except (
                        AttributeError,
                        RuntimeError,
                        ValueError,
                        OSError,
                        ImportError,
                        SyntaxError,
                    ) as e:
                        status = f"Error (Autorun): {e}"
                        # Autorun errors are stored in plugin status
                        print(f"Plugin {plugin_name} autorun error: {e}")
                elif not has_run:
                    status = "No Entry Point"

                self.plugins.append(
                    {
                        "name": plugin_name,
                        "version": plugin_version,
                        "author": plugin_author,
                        "description": plugin_desc,
                        "module": module,
                        "category": plugin_category,  # Store category
                        "status": status,
                        "filepath": filepath,
                        "has_run": has_run,
                    }
                )

        except (
            AttributeError,
            RuntimeError,
            ValueError,
            OSError,
            ImportError,
            SyntaxError,
        ) as e:
            # [BROAD EXCEPTION] Loading failures are caught to prevent a single buggy plugin from
            # crashing the entire discovery process.
            logging.error(f"Failed to load plugin {module_name}: {e}")

    def run_plugin(self, module: Any, main_window: Any) -> None:
        """Executes the plugin's run method (Legacy manual trigger)."""
        try:
            module.run(main_window)
        except (
            AttributeError,
            RuntimeError,
            ValueError,
            OSError,
            ImportError,
            SyntaxError,
        ) as e:
            QMessageBox.critical(
                main_window,
                "Plugin Error",
                f"Error running plugin '{getattr(module, 'PLUGIN_NAME', 'Unknown')}':\n{e}",
            )

    # --- Registration Callbacks ---
    def register_menu_action(
        self,
        plugin_name: str,
        path: str,
        callback: Callable,
        text: str,
        icon: str,
        shortcut: str,
    ) -> None:
        self.menu_actions.append(
            {
                "plugin": plugin_name,
                "path": path,
                "callback": callback,
                "text": text,
                "icon": icon,
                "shortcut": shortcut,
            }
        )

    def register_toolbar_action(
        self, plugin_name: str, callback: Callable, text: str, icon: str, tooltip: str
    ) -> None:
        self.toolbar_actions.append(
            {
                "plugin": plugin_name,
                "callback": callback,
                "text": text,
                "icon": icon,
                "tooltip": tooltip,
            }
        )

    def register_drop_handler(
        self, plugin_name: str, callback: Callable, priority: int
    ) -> None:
        self.drop_handlers.append(
            {"priority": priority, "plugin": plugin_name, "callback": callback}
        )
        # Sort by priority desc
        self.drop_handlers.sort(key=lambda x: x["priority"], reverse=True)

    def register_export_action(
        self, plugin_name: str, label: str, callback: Callable
    ) -> None:
        self.export_actions.append(
            {"plugin": plugin_name, "label": label, "callback": callback}
        )

    def register_optimization_method(
        self, plugin_name: str, method_name: str, callback: Callable
    ) -> None:
        # Key by upper-case method name for consistency
        self.optimization_methods[method_name.upper()] = {
            "plugin": plugin_name,
            "callback": callback,
            "label": method_name,
        }

    def register_file_opener(
        self, plugin_name: str, extension: str, callback: Callable, priority: int = 0
    ) -> None:
        # Normalize extension to lowercase
        ext = extension.lower()
        if not ext.startswith("."):
            ext = "." + ext

        if ext not in self.file_openers:
            self.file_openers[ext] = []

        self.file_openers[ext].append(
            {"plugin": plugin_name, "callback": callback, "priority": priority}
        )

        # Sort by priority descending
        self.file_openers[ext].sort(key=lambda x: x["priority"], reverse=True)

    # Analysis Tools registration
    def register_analysis_tool(
        self, plugin_name: str, label: str, callback: Callable
    ) -> None:
        self.analysis_tools.append(
            {"plugin": plugin_name, "label": label, "callback": callback}
        )

    # State Persistence registration
    def register_save_handler(self, plugin_name: str, callback: Callable) -> None:
        self.save_handlers[plugin_name] = callback

    def register_load_handler(self, plugin_name: str, callback: Callable) -> None:
        self.load_handlers[plugin_name] = callback

    def register_3d_style(
        self, plugin_name: str, style_name: str, callback: Callable
    ) -> None:
        self.custom_3d_styles[style_name] = {
            "plugin": plugin_name,
            "callback": callback,
        }

    def register_document_reset_handler(
        self, plugin_name: str, callback: Callable
    ) -> None:
        """Register callback to be invoked when a new document is created."""
        self.document_reset_handlers.append(
            {"plugin": plugin_name, "callback": callback}
        )

    # --- New API Implementation ---
    def show_status_message(self, message: str, timeout: int = 3000) -> None:
        """Display a message in the MainWindow status bar."""
        if self.main_window and hasattr(self.main_window, "statusBar"):
            status_bar = self.main_window.statusBar()
            if status_bar:
                status_bar.showMessage(message, timeout)

    def push_undo_checkpoint(self) -> None:
        """Triggers an undo checkpoint in the application state."""
        if self.main_window and hasattr(self.main_window, "state_manager"):
            self.main_window.state_manager.push_undo_state()

    def refresh_3d_view(self) -> None:
        """Force a re-render of the 3D scene."""
        if (
            self.main_window
            and hasattr(self.main_window, "plotter")
            and self.main_window.plotter
        ):
            self.main_window.plotter.render()

    def reset_3d_camera(self) -> None:
        """Reset the 3D camera to fit the current molecule."""
        if (
            self.main_window
            and hasattr(self.main_window, "plotter")
            and self.main_window.plotter
        ):
            self.main_window.plotter.reset_camera()
            self.main_window.plotter.render()

    def get_selected_atom_indices(self) -> List[int]:
        """Retrieve RDKit atom indices currently selected in the 2D scene."""
        selected_indices = []
        if not self.main_window:
            return []

        # Check 2D selection
        try:
            # We need to access the scene items.
            # In MoleditPy, atoms in the scene are AtomItem objects which have an 'atom_id'.
            # These atom_ids map to entries in state_manager.data.atoms.
            # RDKit molecule atoms have an '_original_atom_id' property.

            scene = getattr(self.main_window, "scene", None)
            if scene:
                selected_items = scene.selectedItems()
                selected_atom_ids = set()
                for item in selected_items:
                    # Relying on duck-typing for AtomItem
                    if hasattr(item, "atom_id"):
                        selected_atom_ids.add(item.atom_id)

                # Now map these editor IDs to RDKit indices
                mol = getattr(self.main_window, "current_mol", None)
                if mol and selected_atom_ids:
                    for i in range(mol.GetNumAtoms()):
                        atom = mol.GetAtomWithIdx(i)
                        if atom.HasProp("_original_atom_id"):
                            try:
                                orig_id = atom.GetIntProp("_original_atom_id")
                                if orig_id in selected_atom_ids:
                                    selected_indices.append(i)
                            except (RuntimeError, ValueError, TypeError):
                                continue
        except ImportError:
            pass
        except Exception as e:
            logging.error(f"Error retrieving selected atom indices: {e}")

        return selected_indices

    def register_window(self, plugin_name: str, window_id: str, window: Any) -> None:
        """Register a plugin window to keep it alive and manageable."""
        if plugin_name not in self.plugin_windows:
            self.plugin_windows[plugin_name] = {}
        self.plugin_windows[plugin_name][window_id] = window

    def get_window(self, plugin_name: str, window_id: str) -> Optional[Any]:
        """Retrieve a registered plugin window."""
        return self.plugin_windows.get(plugin_name, {}).get(window_id)

    def invoke_document_reset_handlers(self) -> None:
        """Call all registered document reset handlers."""
        for handler in self.document_reset_handlers:
            try:
                handler["callback"]()
            except (
                AttributeError,
                RuntimeError,
                ValueError,
                OSError,
                ImportError,
                SyntaxError,
            ) as e:
                # [BROAD EXCEPTION] Document reset handlers are user plugins; catch all to prevent data loss.
                logging.error(
                    f"Error in document reset handler for {handler['plugin']}: {e}"
                )

    def get_plugin_info_safe(self, file_path: str) -> Dict[str, str]:
        """Extracts plugin metadata using AST parsing (safe, no execution)."""
        info = {
            "name": os.path.basename(file_path),
            "version": "Unknown",
            "author": "Unknown",
            "description": "",
        }
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                tree = ast.parse(f.read())

            for node in tree.body:
                targets = []
                if isinstance(node, ast.Assign):
                    targets = node.targets
                elif isinstance(node, ast.AnnAssign):
                    targets = [node.target]

                for target in targets:
                    if isinstance(target, ast.Name):
                        # Helper to extract value
                        val = None
                        if node.value:  # AnnAssign might presumably not have value? (though usually does for module globals)
                            if isinstance(node.value, ast.Constant):  # Py3.8+
                                val = node.value.value
                            elif hasattr(ast, "Str") and isinstance(
                                node.value, getattr(ast, "Str", type(None))
                            ):  # Py3.7 and below
                                val = node.value.s
                            elif isinstance(node.value, ast.Tuple):
                                # Handle version tuples e.g. (1, 0, 0)
                                try:
                                    # Extract simple constants from tuple
                                    elts = []
                                    for elt in node.value.elts:
                                        if isinstance(elt, ast.Constant):
                                            elts.append(elt.value)
                                        elif hasattr(ast, "Num") and isinstance(
                                            elt, getattr(ast, "Num", type(None))
                                        ):
                                            elts.append(elt.n)
                                    val = ".".join(map(str, elts))
                                except (
                                    AttributeError,
                                    RuntimeError,
                                    ValueError,
                                    TypeError,
                                ):
                                    # Fallback for complex AST structures during metadata extraction
                                    pass

                        if val is not None:
                            if target.id == "PLUGIN_NAME":
                                info["name"] = str(val)
                            elif target.id == "PLUGIN_VERSION":
                                info["version"] = str(val)
                            elif target.id == "PLUGIN_AUTHOR":
                                info["author"] = str(val)
                            elif target.id == "PLUGIN_DESCRIPTION":
                                info["description"] = str(val)
                            elif target.id == "PLUGIN_CATEGORY":
                                info["category"] = str(val)
                            elif (
                                target.id == "__version__"
                                and info["version"] == "Unknown"
                            ):
                                info["version"] = str(val)
                            elif (
                                target.id == "__author__"
                                and info["author"] == "Unknown"
                            ):
                                info["author"] = str(val)

                # Docstring extraction
                if isinstance(node, ast.Expr):
                    val = None
                    if isinstance(node.value, ast.Constant) and isinstance(
                        node.value.value, str
                    ):
                        val = node.value.value
                    elif hasattr(ast, "Str") and isinstance(
                        node.value, getattr(ast, "Str", type(None))
                    ):
                        val = node.value.s

                    if val and not info["description"]:
                        info["description"] = val.strip().split("\n")[0]

        except (
            AttributeError,
            RuntimeError,
            ValueError,
            OSError,
            ImportError,
            SyntaxError,
        ) as e:
            # Metadata extraction is best-effort and should not block the app.
            logging.debug(f"Error parsing plugin info for {file_path}: {e}")
        return info
