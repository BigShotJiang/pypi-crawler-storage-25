# AGENTS.md — Agentic Engineering Framework

> **Version**: v2.0
> **Date**: 2026-04-23

---

## Project Overview

**Name**: Agentic Engineering Framework (ADWS)
**Purpose**: A vendor-neutral framework for standardizing how AI coding agents interact with software repositories. Provides cross-tool adapters, reusable skills, and a CLI for agent-driven development workflows.
**Primary Language**: Python 3.12+
**Framework**: Custom CLI built with `argparse`, `subprocess`, and `pydantic`
**Repository Type**: Single project

---

## Navigation

| Path | Type | Purpose | Entry Point |
|------|------|---------|-------------|
| `adws/` | package | Core CLI and workflow engine | `adws/cli.py` |
| `adws/agent.py` | module | Agent provider dispatch | `prompt_agent()` |
| `adws/providers.py` | module | Provider implementations (OpenCode, Claude CLI, Venice API) | `get_provider()` |
| `skills/` | directory | Reusable agent skills (SKILL.md format) | `skills/*/SKILL.md` |
| `adapters/` | directory | Cross-tool adapters (claude-code, cursor, etc.) | `adapters/*/generate.sh` |
| `templates/` | directory | Project templates (AGENTS.md, plan, review) | `templates/` |
| `docs/` | directory | Framework documentation | `docs/*.md` |
| `tests/` | tests | Test suites | `adws/tests/` |

---

## Architecture

- **Service type**: CLI tool and framework library
- **Database**: None (file-based configuration)
- **External integrations**: OpenCode CLI, Claude Code CLI, Venice.AI API, Anthropic API, OpenAI API
- **Authentication**: API keys via environment variables (`ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, `VENICE_API_KEY`)
- **Deployment target**: PyPI package (`pip install adws`)

### Key Directories

| Directory | Purpose |
|---|---|
| `adws/` | Core Python package — CLI, providers, health checks, data types |
| `skills/` | Reusable agent skills in vendor-neutral SKILL.md format |
| `adapters/` | Tool-specific adapters that translate universal files to tool-native formats |
| `templates/` | Project templates for bootstrapping new repositories |
| `docs/` | Framework documentation and standards |
| `scripts/` | Build and deployment scripts |

---

## Development Commands

### Setup

```bash
# Install dependencies
pip install -e ".[dev]"

# Set up environment
cp .env.example .env
```

### Validation

```bash
# Run tests
pytest adws/tests/

# Run linter
ruff check .

# Run formatter check
ruff format --check .

# Run type checker
mypy adws/

# Run build
python -m build
```

### Run Locally

```bash
# Start CLI
adws --help

# Run health check
adws health
```

---

## Coding Rules

### Style

- Follow PEP 8 as enforced by Ruff
- Use descriptive variable and function names
- Keep functions focused — one responsibility per function
- Maximum function length: ~50 lines (prefer shorter)

### Patterns

- **Error handling**: Use `try/except` with specific exceptions; return `None` or empty structures on failure rather than crashing
- **Logging**: Use Python `logging` module; structured JSON for machine-readable output
- **Testing**: Use `pytest` with `unittest.mock` for external dependencies
- **Naming**: `snake_case` for Python; `kebab-case` for CLI commands and file names

### Do NOT

- Do not use `print()` for logging — use the `logging` module
- Do not add dependencies without documenting them in `pyproject.toml`
- Do not modify generated adapter files directly — edit the generator scripts
- Do not commit credentials, API keys, or secrets
- Do not leave orphaned code — if a module is not imported, remove it

---

## Risk Areas

| Path / Area | Risk Level | Notes |
|---|---|---|
| `adws/agent.py` | High | Dispatches to live agent providers — incorrect prompts can modify production code |
| `adws/providers.py` | High | Interfaces with external CLI tools and APIs — API key handling |
| `skills/` | Medium | Skills are executed by agents — incorrect skill definitions propagate errors |
| `adapters/` | Low | Adapter scripts are read-only generators — no direct code execution |
| `docs/` | Low | Documentation only |
| `tests/` | Low | Test-only changes |

---

## Review Expectations

### All Changes

- [ ] Tests pass (existing + new)
- [ ] Linter passes with no new warnings (`ruff check .`)
- [ ] No unrelated changes included
- [ ] Commit messages follow conventional format: `type(scope): description`

### Feature Changes

- [ ] Acceptance criteria met
- [ ] Edge cases handled (missing env vars, missing tools, API failures)
- [ ] Error messages are user-friendly
- [ ] Documentation updated if behavior changed

### Adapter Changes

- [ ] Generator script updated (not just output files)
- [ ] Output files re-generated and verified
- [ ] Cross-tool compatibility maintained

---

## Escalation

### Channels

- **Standard**: Open a GitHub issue
- **Urgent**: Tag maintainers in the PR

### Escalation Triggers

- Changes to agent provider dispatch logic (`adws/agent.py`, `adws/providers.py`)
- Changes to skill execution contract or SKILL.md schema
- Changes requiring coordination with external tool vendors (Claude Code, OpenCode, Cursor)
- Ambiguous requirements after one clarification attempt
- Test failures that cannot be resolved in 2 attempts

---

## Environment Variables

| Variable | Purpose | Required |
|---|---|---|
| `ANTHROPIC_API_KEY` | Anthropic API access (Claude Code, OpenCode backend) | Yes (if using Anthropic) |
| `OPENAI_API_KEY` | OpenAI API access (OpenCode backend) | Yes (if using OpenAI) |
| `VENICE_API_KEY` | Venice.AI API access | Yes (if using Venice provider) |
| `ADW_AGENT_PROVIDER` | Active agent provider: `claude_cli`, `opencode`, `venice_api` | No (default: `claude_cli`) |
| `CLAUDE_CODE_PATH` | Path to Claude Code CLI binary | No (default: `claude`) |
| `OPENCODE_HOOKS_LOG_DIR` | Base directory for OpenCode hook session logs | No (default: `logs`) |

---

## Tool-Specific Configuration

This repository supports multiple AI coding tools. Each tool has its own configuration directory:

| Tool | Directory | Purpose |
|---|---|---|
| **OpenCode** | `.opencode/` | OpenCode CLI settings, hooks, slash commands |
| **Claude Code** | `.claude/` | Claude Code project context (`CLAUDE.md`) and slash commands |
| **Cursor** | `.cursor/` | Cursor rules and configuration (via adapter) |

> **Important**: The universal files (`AGENTS.md`, `skills/*/SKILL.md`) are the single source of truth. Tool-specific directories are generated from these via adapters. Never edit `.claude/CLAUDE.md` or `.opencode/commands/` directly — edit the source files and re-run the adapter.

---

## Additional Context

### Known Issues

- `adws` PyPI package may not be published yet — install from source with `pip install -e .`
- Claude Code adapter (`adapters/claude-code/`) generates `.claude/` directory but it is not yet committed to the repo

### Recent Changes

- Framework v2.0 introduced cross-tool adapter pattern
- Skills moved to vendor-neutral `SKILL.md` format
- ADWS CLI now supports three providers: OpenCode, Claude Code CLI, Venice API

### Team Conventions

- All hook scripts in `.opencode/hooks/` must be executable Python scripts with `uv run --script` shebang
- Adapter scripts must be idempotent — running them multiple times produces the same output
- Skills must follow the `SKILL.md` schema defined in `docs/cross-tool-standard.md`

---

*This file follows the [Agentic Engineering Workflow Framework](https://github.com/Spree-Finance/AgenticEngineeringFramework) v2.0 standard.*
