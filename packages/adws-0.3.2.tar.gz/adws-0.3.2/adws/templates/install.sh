#!/bin/bash
# ADW Framework Installer
# Installs the Agentic Engineering Framework into any project
#
# Usage:
#   git clone https://github.com/Spree-Finance/AgenticEngineeringFramework.git
#   bash AgenticEngineeringFramework/install.sh [target_directory]
#
# Minimum viable install: AGENTS.md, manifest.yml, .env, .adws/

set -e

# ── Colors ──
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[0;33m'
RED='\033[0;31m'
NC='\033[0m'

# ── Configuration ──
FRAMEWORK_REPO="https://github.com/Spree-Finance/AgenticEngineeringFramework.git"
FRAMEWORK_BRANCH="main"
TARGET_DIR="${1:-$(pwd)}"
ADWS_DIR="$TARGET_DIR/.adws"
TEMP_DIR=""

# ── Cleanup ──
cleanup() {
    if [ -n "$TEMP_DIR" ] && [ -d "$TEMP_DIR" ]; then
        rm -rf "$TEMP_DIR"
    fi
}
trap cleanup EXIT

# ── Helpers ──
print_header() {
    echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}  Agentic Engineering Framework Installer${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}"
    echo ""
}

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

detect_package_manager() {
    if command -v uv &> /dev/null; then
        echo "uv"
    elif command -v pip &> /dev/null; then
        echo "pip"
    else
        echo ""
    fi
}

detect_tool_directory() {
    # Detect which AI tool is being used and return its commands directory
    if [ -d "$TARGET_DIR/.opencode" ]; then
        echo "$TARGET_DIR/.opencode/commands"
    elif [ -d "$TARGET_DIR/.claude" ]; then
        echo "$TARGET_DIR/.claude/commands"
    elif [ -d "$TARGET_DIR/.claude-code" ]; then
        echo "$TARGET_DIR/.claude-code/commands"
    else
        # Default to .opencode/commands
        echo "$TARGET_DIR/.opencode/commands"
    fi
}

# ── Main ──
print_header

echo "Target directory: $TARGET_DIR"
echo ""

# Validate target directory
if [ ! -d "$TARGET_DIR" ]; then
    print_error "Target directory does not exist: $TARGET_DIR"
    exit 1
fi

# Check if already installed
if [ -d "$ADWS_DIR" ] || [ -f "$TARGET_DIR/AGENTS.md" ]; then
    print_warning "ADW Framework appears to already be installed in this project"
    read -p "Reinstall? (y/N) " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Cancelled"
        exit 0
    fi
    # Backup existing files
    if [ -f "$TARGET_DIR/AGENTS.md" ]; then
        mv "$TARGET_DIR/AGENTS.md" "$TARGET_DIR/AGENTS.md.backup.$(date +%s)"
        print_warning "Backed up existing AGENTS.md"
    fi
    if [ -f "$TARGET_DIR/manifest.yml" ]; then
        mv "$TARGET_DIR/manifest.yml" "$TARGET_DIR/manifest.yml.backup.$(date +%s)"
        print_warning "Backed up existing manifest.yml"
    fi
    if [ -f "$TARGET_DIR/.env" ]; then
        mv "$TARGET_DIR/.env" "$TARGET_DIR/.env.backup.$(date +%s)"
        print_warning "Backed up existing .env"
    fi
    rm -rf "$ADWS_DIR"
fi

# Create temp directory for framework files
TEMP_DIR=$(mktemp -d)
print_success "Created temporary directory: $TEMP_DIR"

# Try to install adws pip package
PKG_MANAGER=$(detect_package_manager)
if [ -n "$PKG_MANAGER" ]; then
    echo ""
    echo "Installing adws pip package..."
    if [ "$PKG_MANAGER" = "uv" ]; then
        if uv pip install adws 2>/dev/null; then
            print_success "Installed adws via uv"
        else
            print_warning "Could not install adws from PyPI, will use local copy"
        fi
    else
        if pip install adws 2>/dev/null; then
            print_success "Installed adws via pip"
        else
            print_warning "Could not install adws from PyPI, will use local copy"
        fi
    fi
else
    print_warning "No package manager found (uv or pip). CLI commands will not be available."
fi

# ── Copy minimum viable files ──
echo ""
echo "Installing framework files..."

# Create .adws directory
mkdir -p "$ADWS_DIR"
print_success "Created $ADWS_DIR"

# Determine if we're running from a cloned framework repo or pip install
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -f "$SCRIPT_DIR/AGENTS.md" ]; then
    # Running from pip install (adws/templates/)
    FRAMEWORK_ROOT="$SCRIPT_DIR"
    print_success "Detected pip install templates: $FRAMEWORK_ROOT"
elif [ -f "$SCRIPT_DIR/templates/AGENTS.md" ]; then
    # Running from the framework repo itself (repo root)
    FRAMEWORK_ROOT="$SCRIPT_DIR"
    print_success "Detected framework source: $FRAMEWORK_ROOT"
else
    # Need to clone the framework repo
    echo "Cloning framework repository..."
    if command -v git &> /dev/null; then
        git clone --depth 1 --branch "$FRAMEWORK_BRANCH" "$FRAMEWORK_REPO" "$TEMP_DIR/framework" 2>/dev/null || true
        if [ -d "$TEMP_DIR/framework/templates" ]; then
            FRAMEWORK_ROOT="$TEMP_DIR/framework"
            print_success "Cloned framework repository"
        else
            print_error "Could not clone framework repository"
            print_error "Please run this script from the framework repo or ensure git is available"
            exit 1
        fi
    else
        print_error "Git is not installed and framework source not found"
        exit 1
    fi
fi

# Copy templates
if [ -f "$FRAMEWORK_ROOT/AGENTS.md" ]; then
    # Running from pip install (adws/templates/)
    cp "$FRAMEWORK_ROOT/AGENTS.md" "$TARGET_DIR/AGENTS.md"
    print_success "Copied AGENTS.md"

    # Copy manifest.yml
    if [ -f "$FRAMEWORK_ROOT/manifest.yml" ]; then
        cp "$FRAMEWORK_ROOT/manifest.yml" "$TARGET_DIR/manifest.yml"
        print_success "Created manifest.yml"
    fi

    # Copy .env.example
    if [ -f "$FRAMEWORK_ROOT/.env.example" ]; then
        cp "$FRAMEWORK_ROOT/.env.example" "$TARGET_DIR/.env"
        print_success "Copied .env.example to .env"
    else
        touch "$TARGET_DIR/.env"
        print_warning "No .env.example found, created empty .env"
    fi
else
    # Running from repo root
    cp "$FRAMEWORK_ROOT/templates/AGENTS.md" "$TARGET_DIR/AGENTS.md"
    print_success "Copied AGENTS.md"

    # Create manifest.yml from template or generate minimal one
    if [ -f "$FRAMEWORK_ROOT/templates/manifest.yml" ]; then
        cp "$FRAMEWORK_ROOT/templates/manifest.yml" "$TARGET_DIR/manifest.yml"
    else
        # Generate minimal manifest.yml
        PROJECT_NAME=$(basename "$TARGET_DIR")
        cat > "$TARGET_DIR/manifest.yml" << EOF
# Agentic Engineering Framework — manifest.yml
# Universal machine-readable project entry point
# https://github.com/Spree-Finance/AgenticEngineeringFramework

framework_version: "2.0"
project:
  name: "$PROJECT_NAME"
  description: "Add your project description here"
  language: ""
  framework: ""
entry_points:
  readme: "README.md"
  agents: "AGENTS.md"
  env: ".env"
paths:
  source: ""
  tests: ""
  docs: ""
  scripts: ""
  adws: ".adws/"
EOF
    fi
    print_success "Created manifest.yml"

    # Copy .env.example to .env
    if [ -f "$FRAMEWORK_ROOT/.env.example" ]; then
        cp "$FRAMEWORK_ROOT/.env.example" "$TARGET_DIR/.env"
        print_success "Copied .env.example to .env"
    else
        touch "$TARGET_DIR/.env"
        print_warning "No .env.example found, created empty .env"
    fi

    # Copy ADW core files to .adws/
    if [ -d "$FRAMEWORK_ROOT/adws" ]; then
        cp -r "$FRAMEWORK_ROOT/adws"/* "$ADWS_DIR/"
        print_success "Copied ADW core files to .adws/"
    fi

    # Copy scripts to .adws/scripts/
    if [ -d "$FRAMEWORK_ROOT/scripts" ]; then
        mkdir -p "$ADWS_DIR/scripts"
        cp "$FRAMEWORK_ROOT/scripts"/*.sh "$ADWS_DIR/scripts/" 2>/dev/null || true
        print_success "Copied scripts to .adws/scripts/"
    fi
fi

# ── Copy slash commands ──
# Copy OpenCode commands
if [ -d "$FRAMEWORK_ROOT/.opencode/commands" ]; then
    OPCODE_DIR="$TARGET_DIR/.opencode/commands"
    mkdir -p "$OPCODE_DIR"
    for cmd in "$FRAMEWORK_ROOT/.opencode/commands"/*.md; do
        if [ -f "$cmd" ]; then
            cmd_name=$(basename "$cmd")
            cp "$cmd" "$OPCODE_DIR/$cmd_name"
        fi
    done
    print_success "Copied slash commands to .opencode/commands/"
fi

# Copy Claude commands
if [ -d "$FRAMEWORK_ROOT/.claude/commands" ]; then
    CLAUDE_DIR="$TARGET_DIR/.claude/commands"
    mkdir -p "$CLAUDE_DIR"
    for cmd in "$FRAMEWORK_ROOT/.claude/commands"/*.md; do
        if [ -f "$cmd" ]; then
            cmd_name=$(basename "$cmd")
            cp "$cmd" "$CLAUDE_DIR/$cmd_name"
        fi
    done
    print_success "Copied slash commands to .claude/commands/"
fi

# ── Summary ──
echo ""
echo -e "${GREEN}═══════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}  ADW Framework installed successfully!${NC}"
echo -e "${GREEN}═══════════════════════════════════════════════════════${NC}"
echo ""
echo "Installed files:"
echo "  📄 $TARGET_DIR/AGENTS.md"
echo "  📄 $TARGET_DIR/manifest.yml"
echo "  📄 $TARGET_DIR/.env"
echo "  📁 $ADWS_DIR/"
if [ -d "$TARGET_DIR/.opencode/commands" ]; then
    echo "  📁 $TARGET_DIR/.opencode/commands/"
fi
if [ -d "$TARGET_DIR/.claude/commands" ]; then
    echo "  📁 $TARGET_DIR/.claude/commands/"
fi
echo ""
echo "Next steps:"
echo "  1. Edit $TARGET_DIR/.env and fill in your values"
echo "  2. Edit $TARGET_DIR/AGENTS.md with your project details"
echo "  3. Edit $TARGET_DIR/manifest.yml with your project structure"
echo ""

if command -v adws &> /dev/null; then
    echo "  4. Run 'adws health' to verify the installation"
    echo "  5. Run 'adws --help' to see available commands"
else
    echo "  4. Install the adws pip package: pip install adws"
    echo "  5. Then run 'adws health' to verify"
fi

echo ""
echo "For more information, see:"
echo "  https://github.com/Spree-Finance/AgenticEngineeringFramework"
echo ""
