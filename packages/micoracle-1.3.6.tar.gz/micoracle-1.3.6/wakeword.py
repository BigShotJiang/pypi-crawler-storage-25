"""Wake-word gate — pre-filters utterances before the full STT backend.

Uses the same model as the main STT (default: medium.en) so only one model
is downloaded and loaded. On Apple Silicon uses mlx-whisper; everywhere else
uses faster-whisper.

Usage::

    gate = WakeWordGate(mlx_repo="mlx-community/whisper-medium.en-mlx-4bit")
    result = gate.check(pcm_int16, sample_rate=16000)
    if result.passed:
        full_text = my_full_stt.transcribe(pcm_int16, sample_rate)
"""

from __future__ import annotations

import os
import platform
from dataclasses import dataclass

import numpy as np


WAKE_VARIANTS: dict[str, set[str]] = {
    "claude": {"claude", "clawed", "clod", "cloudy", "clyde", "claud", "cloth",
               "cloud", "clade", "clawd", "claw"},
    "codex":  {"codex", "codec", "codecs", "coded", "coed", "goodx", "godex",
               "coedx", "kotex"},
}

FUZZY_BLOCKLIST: set[str] = {
    "cortex", "kodak", "clot", "cloak",
    "code", "codes", "coke", "cope", "core",
}

GATE_CHECK_WORDS: int = 3
MIN_GATE_DURATION_S: float = 1.0
# RMS threshold on int16 scale — audio below this is background noise, not speech.
# Typical speech: 500-3000. Background hum/fan: <300. Configurable via env var.
MIN_SPEECH_RMS: int = int(os.environ.get("VOICE_AGENT_MIN_RMS", "300"))

MLX_MODEL_REPOS: dict[str, str] = {
    "tiny.en":   "mlx-community/whisper-tiny.en-mlx-4bit",
    "small.en":  "mlx-community/whisper-small.en-mlx-4bit",
    "medium.en": "mlx-community/whisper-medium.en-mlx-4bit",
    "large-v3":  "mlx-community/whisper-large-v3-mlx",
}


@dataclass
class GateResult:
    wake: str | None
    wake_idx: int
    tiny_text: str
    passed: bool


def _is_apple_silicon() -> bool:
    if platform.system() != "Darwin":
        return False
    if platform.machine() in ("arm64", "aarch64"):
        return True
    # Conda/Rosetta envs may report x86_64 even on M-chip — check processor
    try:
        import subprocess
        out = subprocess.check_output(["sysctl", "-n", "hw.optional.arm64"],
                                      stderr=subprocess.DEVNULL, text=True).strip()
        return out == "1"
    except Exception:
        return False


def mlx_repo_for(model: str) -> str:
    """Map a model name like 'medium.en' to its MLX HuggingFace repo."""
    return MLX_MODEL_REPOS.get(model, f"mlx-community/whisper-{model}-mlx-4bit")


def _rms(pcm: np.ndarray) -> float:
    return float(np.sqrt(np.mean(pcm.astype(np.float32) ** 2)))


def _is_hallucination_loop(text: str) -> bool:
    """Detect Whisper's repeating-phrase hallucination pattern."""
    words = text.lower().split()
    if len(words) < 9:
        return False
    for size in range(2, 7):
        if len(words) < size * 3:
            continue
        for i in range(len(words) - size * 3 + 1):
            chunk = words[i:i + size]
            if (words[i + size:i + 2 * size] == chunk
                    and words[i + 2 * size:i + 3 * size] == chunk):
                return True
    return False


class WakeWordGate:
    """Loads one Whisper model and exposes ``check()`` for each utterance.

    Shares the same model as the main STT — no extra download needed.
    Uses mlx-whisper on Apple Silicon, faster-whisper everywhere else.
    """

    def __init__(
        self,
        model: str = "tiny.en",
        mlx_repo: str | None = None,
        compute_type: str = "int8",
        min_speech_rms: int = MIN_SPEECH_RMS,
    ) -> None:
        self.model_size = model
        self.min_speech_rms = min_speech_rms

        if _is_apple_silicon():
            self._backend = "mlx"
            self._mlx_repo = mlx_repo or mlx_repo_for(model)
            import mlx_whisper  # type: ignore  # noqa: F401
        else:
            self._backend = "faster"
            from faster_whisper import WhisperModel
            self._model = WhisperModel(model, device="cpu", compute_type=compute_type)

    def _first_word_matches(self, text: str) -> tuple[str | None, int]:
        import difflib
        words = [w.strip(",.!?;:\"'") for w in text.split() if w.strip(",.!?;:\"'")]
        if not words:
            return None, -1
        for idx, word in enumerate(words[:GATE_CHECK_WORDS]):
            lw = word.lower()
            if lw in FUZZY_BLOCKLIST:
                continue
            for wake, variants in WAKE_VARIANTS.items():
                if lw in variants:
                    return wake, idx
                for variant in variants:
                    if difflib.SequenceMatcher(None, lw, variant).ratio() >= 0.78:
                        return wake, idx
        return None, -1

    def check(self, pcm_int16: np.ndarray, sample_rate: int = 16000) -> GateResult:
        duration_s = len(pcm_int16) / sample_rate
        if duration_s < MIN_GATE_DURATION_S:
            return GateResult(wake=None, wake_idx=-1, tiny_text="<short>", passed=True)

        # Reject background noise / fan hum before hitting the model
        if _rms(pcm_int16) < self.min_speech_rms:
            return GateResult(wake=None, wake_idx=-1, tiny_text="<noise>", passed=False)

        if self._backend == "mlx":
            text = self._transcribe_mlx(pcm_int16, sample_rate)
        else:
            text = self._transcribe_faster(pcm_int16)

        # Reject Whisper hallucination loops before wake-word matching
        if _is_hallucination_loop(text):
            return GateResult(wake=None, wake_idx=-1, tiny_text="<hallucination>", passed=False)

        wake, idx = self._first_word_matches(text)
        return GateResult(wake=wake, wake_idx=idx, tiny_text=text, passed=wake is not None)

    # Gate prompt — just wake words so tiny.en is biased toward them.
    _GATE_PROMPT = "Claude, Codex."

    def _transcribe_mlx(self, pcm_int16: np.ndarray, sample_rate: int) -> str:
        import mlx_whisper  # type: ignore
        audio_f32 = pcm_int16.astype(np.float32) / 32768.0
        result = mlx_whisper.transcribe(
            audio_f32,
            path_or_hf_repo=self._mlx_repo,
            language="en",
            fp16=True,
            word_timestamps=False,
            condition_on_previous_text=False,
            initial_prompt=self._GATE_PROMPT,
            temperature=0.0,   # greedy — gate only needs fast wake-word detection
        )
        return " ".join(result.get("text", "").split())

    def _transcribe_faster(self, pcm_int16: np.ndarray) -> str:
        import logging
        audio_f32 = pcm_int16.astype(np.float32) / 32768.0
        fw_log = logging.getLogger("faster_whisper")
        prev_level = fw_log.level
        fw_log.setLevel(logging.ERROR)
        try:
            segments, _ = self._model.transcribe(
                audio_f32,
                language="en",
                beam_size=1,
                best_of=1,
                temperature=0.0,
                condition_on_previous_text=False,
                no_speech_threshold=0.6,
                log_prob_threshold=-1.0,
                initial_prompt="Claude, Codex.",
            )
            return " ".join(s.text.strip() for s in segments).strip()
        finally:
            fw_log.setLevel(prev_level)
