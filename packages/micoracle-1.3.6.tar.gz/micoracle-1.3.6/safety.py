"""Safety and privacy pipeline for transcribed voice commands.

All checks are optional and individually togglable via env vars.
Default state: PII redaction ON, credential blocking ON,
               dangerous-command warning ON, OpenAI moderation OFF.

Set VOICE_AGENT_SAFETY=false to disable the entire pipeline.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field


@dataclass
class SafetyResult:
    safe: bool            # False = do not dispatch
    text: str             # possibly redacted version of the original
    blocked: bool         # True = hard block (credential / moderation hit)
    warnings: list[str] = field(default_factory=list)
    reason: str | None = None   # populated when blocked=True


# ── PII patterns ──────────────────────────────────────────────────────────────

_PII_PATTERNS: dict[str, tuple[str, str]] = {
    "email":       (r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b",
                    "<EMAIL>"),
    "phone":       (r"\b(\+1[\s.\-]?)?\(?\d{3}\)?[\s.\-]?\d{3}[\s.\-]?\d{4}\b",
                    "<PHONE>"),
    "ssn":         (r"\b\d{3}[- ]\d{2}[- ]\d{4}\b",
                    "<SSN>"),
    "credit_card": (r"\b(?:\d{4}[\s\-]?){3}\d{4}\b",
                    "<CARD>"),
    "ip_address":  (r"\b(?:\d{1,3}\.){3}\d{1,3}\b",
                    "<IP>"),
}

# Email domains developers commonly use in test/example code — not real PII.
_TEST_EMAIL_DOMAINS: frozenset[str] = frozenset({
    "example.com", "example.org", "example.net",
    "test.com", "test.org",
    "foo.com", "bar.com", "baz.com",
    "domain.com", "email.com",
    "localhost",
})

# Private / loopback / link-local IP ranges — never real PII in dev context.
_SAFE_IP_RE = re.compile(
    r"^(127\.\d+\.\d+\.\d+"                        # loopback
    r"|192\.168\.\d+\.\d+"                          # RFC-1918
    r"|10\.\d+\.\d+\.\d+"                           # RFC-1918
    r"|172\.(1[6-9]|2[0-9]|3[01])\.\d+\.\d+"       # RFC-1918
    r"|169\.254\.\d+\.\d+"                          # link-local
    r"|0\.0\.0\.0"
    r"|255\.255\.255\.255)$"
)

# ── Credential patterns (hard block) ─────────────────────────────────────────

_CREDENTIAL_PATTERNS: dict[str, str] = {
    "OpenAI key":       r"sk-[A-Za-z0-9]{20,}",
    "Anthropic key":    r"sk-ant-[A-Za-z0-9\-_]{40,}",
    "AWS access key":   r"AKIA[0-9A-Z]{16}",
    "GitHub token":     r"gh[ps]_[A-Za-z0-9]{36}",
    "API key literal":  r"(?i)api[_\-]?key\s*[=:]\s*[A-Za-z0-9_\-]{16,}",
    "password literal": r"(?i)password\s*[=:]\s*\S{6,}",
    "bearer token":     r"(?i)bearer\s+[A-Za-z0-9\-_\.]{20,}",
}

# ── Dangerous command patterns ────────────────────────────────────────────────

# Hard block — only truly catastrophic, irreversible operations.
# Deliberately narrow: legitimate developer paths like /home/user/project must pass.
_BLOCK_PATTERNS: list[tuple[str, str]] = [
    # rm -rf / or rm -rf /* only (not /some/project/path)
    (r"\brm\s+(-r\s+-f|-rf|-fr)\s+/\*?(\s|;|&&|\|\||$)",  "rm -rf on filesystem root"),
    # Windows: format c: /q (destructive disk format)
    (r"\bformat\s+[a-zA-Z]:\s*/q",                         "disk format"),
    # dd targeting a whole disk device (sda, hda) — not a partition (sda1)
    (r"\bdd\s+if=.*of=/dev/[sh]d[a-z](?!\d)",              "dd whole-disk overwrite"),
    (r"\bmkfs\b",                                           "mkfs filesystem wipe"),
    (r"\bwipefs\b",                                         "wipefs"),
]

# Soft warn — log and allow (user is a developer, these can be legitimate)
_WARN_PATTERNS: list[tuple[str, str]] = [
    (r"\brm\s+(-r|-f|-rf|-fr)\b",        "recursive/force delete"),
    (r"(?i)\bdrop\s+table\b",            "SQL DROP TABLE"),
    (r"(?i)\btruncate\s+table\b",        "SQL TRUNCATE"),
    (r"(?i)\bdelete\s+from\b",           "SQL DELETE FROM"),
    (r"(?i)\bdrop\s+database\b",         "DROP DATABASE"),
    (r"\bgit\s+push\s+.*--force\b",      "force git push"),
    (r"\bgit\s+reset\s+--hard\b",        "hard git reset"),
    (r"\bgit\s+clean\s+-[fdx]+\b",       "git clean"),
    (r"\bsudo\s+rm\b",                   "sudo rm"),
]


# ── Filter classes ────────────────────────────────────────────────────────────

class PIIRedactor:
    def scan(self, text: str) -> tuple[str, list[str]]:
        found: list[str] = []
        for name, (pattern, placeholder) in _PII_PATTERNS.items():
            if name == "email":
                text, count = self._redact_emails(text, placeholder)
            elif name == "ip_address":
                text, count = self._redact_ips(text, placeholder)
            else:
                text, count = re.subn(pattern, placeholder, text)
            if count:
                found.append(name)
        return text, found

    def _redact_emails(self, text: str, placeholder: str) -> tuple[str, int]:
        pattern, _ = _PII_PATTERNS["email"]
        count = 0
        def _replace(m: re.Match) -> str:
            nonlocal count
            domain = m.group(0).split("@", 1)[1].lower()
            if domain in _TEST_EMAIL_DOMAINS:
                return m.group(0)   # keep — test/example address
            count += 1
            return placeholder
        return re.sub(pattern, _replace, text), count

    def _redact_ips(self, text: str, placeholder: str) -> tuple[str, int]:
        pattern, _ = _PII_PATTERNS["ip_address"]
        count = 0
        def _replace(m: re.Match) -> str:
            nonlocal count
            if _SAFE_IP_RE.match(m.group(0)):
                return m.group(0)   # keep — private/loopback IP
            count += 1
            return placeholder
        return re.sub(pattern, _replace, text), count


class CredentialScanner:
    def scan(self, text: str) -> list[str]:
        return [
            name for name, pattern in _CREDENTIAL_PATTERNS.items()
            if re.search(pattern, text)
        ]


class DangerousCommandFilter:
    def scan(self, text: str) -> tuple[bool, str | None, list[str]]:
        for pattern, label in _BLOCK_PATTERNS:
            if re.search(pattern, text, re.IGNORECASE):
                return True, label, []
        warnings = [
            label for pattern, label in _WARN_PATTERNS
            if re.search(pattern, text, re.IGNORECASE)
        ]
        return False, None, warnings


class OpenAIModerationFilter:
    """Uses OpenAI's free /v1/moderations endpoint. No-op if key absent."""

    def scan(self, text: str) -> tuple[bool, str | None]:
        try:
            import openai
            result = openai.moderations.create(input=text)
            output = result.results[0]
            if output.flagged:
                cats = output.categories.model_dump()
                flagged = [k for k, v in cats.items() if v]
                return True, ", ".join(flagged)
        except Exception:
            pass
        return False, None


# ── Pipeline ──────────────────────────────────────────────────────────────────

class SafetyPipeline:
    """Runs all enabled filters. Designed to be instantiated once at startup."""

    def __init__(self) -> None:
        def _flag(var: str, default: str = "true") -> bool:
            return os.environ.get(var, default).lower() not in ("false", "0", "no")

        self._enabled    = _flag("VOICE_AGENT_SAFETY")
        self._pii        = PIIRedactor()           if _flag("VOICE_AGENT_SAFETY_PII")         else None
        self._creds      = CredentialScanner()     if _flag("VOICE_AGENT_SAFETY_CREDENTIALS")  else None
        self._dangerous  = DangerousCommandFilter() if _flag("VOICE_AGENT_SAFETY_DANGEROUS")   else None
        # Moderation is opt-in (requires OPENAI_API_KEY + explicit enable)
        self._moderation = (
            OpenAIModerationFilter()
            if _flag("VOICE_AGENT_SAFETY_MODERATION", "false") and os.environ.get("OPENAI_API_KEY")
            else None
        )

    def check(self, text: str) -> SafetyResult:
        if not self._enabled:
            return SafetyResult(safe=True, text=text, blocked=False)

        warnings: list[str] = []
        redacted = text

        # 1. PII — redact in place, soft warning
        if self._pii:
            redacted, pii_found = self._pii.scan(redacted)
            warnings.extend(f"PII redacted: {p}" for p in pii_found)

        # 2. Credentials — hard block (check original, not redacted)
        if self._creds:
            cred_found = self._creds.scan(text)
            if cred_found:
                return SafetyResult(
                    safe=False, text=text, blocked=True,
                    warnings=warnings,
                    reason=f"Credential leak blocked: {', '.join(cred_found)}",
                )

        # 3. Dangerous commands — hard block or soft warn
        if self._dangerous:
            blocked, block_reason, danger_warns = self._dangerous.scan(text)
            warnings.extend(danger_warns)
            if blocked:
                return SafetyResult(
                    safe=False, text=text, blocked=True,
                    warnings=warnings,
                    reason=f"Dangerous command blocked: {block_reason}",
                )

        # 4. OpenAI content moderation — hard block
        if self._moderation:
            flagged, category = self._moderation.scan(text)
            if flagged:
                return SafetyResult(
                    safe=False, text=text, blocked=True,
                    warnings=warnings,
                    reason=f"Content moderation blocked: {category}",
                )

        return SafetyResult(safe=True, text=redacted, blocked=False, warnings=warnings)
