"""Tests for platform detection, hardware auto-selection, and model mapping.

Covers every branch of _is_apple_silicon() including the Rosetta 2 / conda
edge case where platform.machine() returns 'x86_64' on real Apple Silicon.
"""

from __future__ import annotations

import subprocess
import sys
import types
from unittest.mock import patch

import pytest

import stt
import wakeword
from hands_free_voice import detect_hardware, default_model_for_hardware
from wakeword import mlx_repo_for, MLX_MODEL_REPOS


# ── helpers ───────────────────────────────────────────────────────────────────

def _patch_platform(monkeypatch, system: str, machine: str, sysctl_out: str = "0"):
    """Patch sys.platform, platform.machine, and sysctl in both stt and wakeword."""
    monkeypatch.setattr("stt.sys.platform", system if system != "darwin" else "darwin")
    monkeypatch.setattr("stt.platform.machine", lambda: machine)
    monkeypatch.setattr("wakeword.platform.system", lambda: system)
    monkeypatch.setattr("wakeword.platform.machine", lambda: machine)
    monkeypatch.setattr(
        "subprocess.check_output",
        lambda *a, **kw: sysctl_out,
    )


# ── _is_apple_silicon (wakeword) ──────────────────────────────────────────────

class TestIsAppleSiliconWakeword:
    def test_arm64_darwin_is_true(self, monkeypatch):
        _patch_platform(monkeypatch, "Darwin", "arm64")
        assert wakeword._is_apple_silicon() is True

    def test_aarch64_darwin_is_true(self, monkeypatch):
        _patch_platform(monkeypatch, "Darwin", "aarch64")
        assert wakeword._is_apple_silicon() is True

    def test_rosetta_x86_with_sysctl_1_is_true(self, monkeypatch):
        """Conda/Rosetta: machine=x86_64 but sysctl says hw.optional.arm64=1."""
        _patch_platform(monkeypatch, "Darwin", "x86_64", sysctl_out="1")
        assert wakeword._is_apple_silicon() is True

    def test_intel_mac_x86_sysctl_0_is_false(self, monkeypatch):
        _patch_platform(monkeypatch, "Darwin", "x86_64", sysctl_out="0")
        assert wakeword._is_apple_silicon() is False

    def test_linux_is_false(self, monkeypatch):
        _patch_platform(monkeypatch, "Linux", "x86_64")
        assert wakeword._is_apple_silicon() is False

    def test_windows_is_false(self, monkeypatch):
        _patch_platform(monkeypatch, "Windows", "AMD64")
        assert wakeword._is_apple_silicon() is False

    def test_sysctl_exception_returns_false(self, monkeypatch):
        monkeypatch.setattr("wakeword.platform.system", lambda: "Darwin")
        monkeypatch.setattr("wakeword.platform.machine", lambda: "x86_64")
        monkeypatch.setattr(
            "subprocess.check_output",
            lambda *a, **kw: (_ for _ in ()).throw(FileNotFoundError("sysctl missing")),
        )
        assert wakeword._is_apple_silicon() is False


# ── _is_apple_silicon (stt) ───────────────────────────────────────────────────

class TestIsAppleSiliconStt:
    def test_arm64_darwin_is_true(self, monkeypatch):
        monkeypatch.setattr("stt.sys.platform", "darwin")
        monkeypatch.setattr("stt.platform.machine", lambda: "arm64")
        assert stt._is_apple_silicon() is True

    def test_rosetta_with_sysctl_1_is_true(self, monkeypatch):
        monkeypatch.setattr("stt.sys.platform", "darwin")
        monkeypatch.setattr("stt.platform.machine", lambda: "x86_64")
        monkeypatch.setattr("subprocess.check_output", lambda *a, **kw: "1")
        assert stt._is_apple_silicon() is True

    def test_intel_mac_is_false(self, monkeypatch):
        monkeypatch.setattr("stt.sys.platform", "darwin")
        monkeypatch.setattr("stt.platform.machine", lambda: "x86_64")
        monkeypatch.setattr("subprocess.check_output", lambda *a, **kw: "0")
        assert stt._is_apple_silicon() is False

    def test_linux_is_false(self, monkeypatch):
        monkeypatch.setattr("stt.sys.platform", "linux")
        assert stt._is_apple_silicon() is False


# ── auto_select_stt_backend ───────────────────────────────────────────────────

class TestAutoSelectSttBackend:
    def _stub_mlx_whisper(self, monkeypatch):
        monkeypatch.setitem(sys.modules, "mlx_whisper", types.ModuleType("mlx_whisper"))

    def test_apple_silicon_arm64_selects_mlx(self, monkeypatch):
        self._stub_mlx_whisper(monkeypatch)
        monkeypatch.setattr("stt.sys.platform", "darwin")
        monkeypatch.setattr("stt.platform.machine", lambda: "arm64")
        assert stt.auto_select_stt_backend() == "mlx"

    def test_apple_silicon_aarch64_selects_mlx(self, monkeypatch):
        self._stub_mlx_whisper(monkeypatch)
        monkeypatch.setattr("stt.sys.platform", "darwin")
        monkeypatch.setattr("stt.platform.machine", lambda: "aarch64")
        assert stt.auto_select_stt_backend() == "mlx"

    def test_rosetta_with_sysctl_selects_mlx(self, monkeypatch):
        self._stub_mlx_whisper(monkeypatch)
        monkeypatch.setattr("stt.sys.platform", "darwin")
        monkeypatch.setattr("stt.platform.machine", lambda: "x86_64")
        monkeypatch.setattr("subprocess.check_output", lambda *a, **kw: "1")
        assert stt.auto_select_stt_backend() == "mlx"

    def test_intel_mac_selects_faster(self, monkeypatch):
        monkeypatch.setattr("stt.sys.platform", "darwin")
        monkeypatch.setattr("stt.platform.machine", lambda: "x86_64")
        monkeypatch.setattr("subprocess.check_output", lambda *a, **kw: "0")
        assert stt.auto_select_stt_backend() == "faster"

    def test_linux_selects_faster(self, monkeypatch):
        monkeypatch.setattr("stt.sys.platform", "linux")
        monkeypatch.setattr("stt.platform.machine", lambda: "x86_64")
        assert stt.auto_select_stt_backend() == "faster"

    def test_windows_selects_faster(self, monkeypatch):
        monkeypatch.setattr("stt.sys.platform", "win32")
        monkeypatch.setattr("stt.platform.machine", lambda: "AMD64")
        assert stt.auto_select_stt_backend() == "faster"


# ── detect_hardware ───────────────────────────────────────────────────────────

class TestDetectHardware:
    def _reset_cache(self, monkeypatch):
        import hands_free_voice as hfv
        monkeypatch.setattr(hfv, "_HW_CACHE", None)

    def test_apple_silicon(self, monkeypatch):
        self._reset_cache(monkeypatch)
        monkeypatch.setattr("platform.system", lambda: "Darwin")
        monkeypatch.setattr("platform.machine", lambda: "arm64")
        assert detect_hardware() == "apple_silicon"

    def test_rosetta_apple_silicon(self, monkeypatch):
        self._reset_cache(monkeypatch)
        monkeypatch.setattr("platform.system", lambda: "Darwin")
        monkeypatch.setattr("platform.machine", lambda: "x86_64")
        monkeypatch.setattr("subprocess.check_output", lambda *a, **kw: "1")
        assert detect_hardware() == "apple_silicon"

    def test_intel_mac(self, monkeypatch):
        self._reset_cache(monkeypatch)
        monkeypatch.setattr("platform.system", lambda: "Darwin")
        monkeypatch.setattr("platform.machine", lambda: "x86_64")
        monkeypatch.setattr("subprocess.check_output", lambda *a, **kw: "0")
        assert detect_hardware() == "cpu"

    def test_cuda_gpu(self, monkeypatch):
        self._reset_cache(monkeypatch)
        monkeypatch.setattr("platform.system", lambda: "Linux")
        monkeypatch.setattr(
            "subprocess.run",
            lambda *a, **kw: type("R", (), {"returncode": 0, "stdout": "8192 MiB"})(),
        )
        assert detect_hardware() == "cuda_gpu"

    def test_cpu_only_no_nvidia(self, monkeypatch):
        self._reset_cache(monkeypatch)
        monkeypatch.setattr("platform.system", lambda: "Linux")
        monkeypatch.setattr(
            "subprocess.run",
            lambda *a, **kw: type("R", (), {"returncode": 1, "stdout": ""})(),
        )
        assert detect_hardware() == "cpu"

    def test_caches_result(self, monkeypatch):
        self._reset_cache(monkeypatch)
        monkeypatch.setattr("platform.system", lambda: "Linux")
        call_count = [0]

        def fake_run(*a, **kw):
            call_count[0] += 1
            return type("R", (), {"returncode": 1, "stdout": ""})()

        monkeypatch.setattr("subprocess.run", fake_run)
        detect_hardware()
        detect_hardware()
        assert call_count[0] == 1  # second call hits cache


# ── default_model_for_hardware ────────────────────────────────────────────────

class TestDefaultModelForHardware:
    def _reset_cache(self, monkeypatch):
        import hands_free_voice as hfv
        monkeypatch.setattr(hfv, "_HW_CACHE", None)

    def test_apple_silicon_default_is_medium(self, monkeypatch):
        self._reset_cache(monkeypatch)
        monkeypatch.setattr("platform.system", lambda: "Darwin")
        monkeypatch.setattr("platform.machine", lambda: "arm64")
        assert default_model_for_hardware() == "medium.en"

    def test_cuda_gpu_default_is_medium(self, monkeypatch):
        self._reset_cache(monkeypatch)
        monkeypatch.setattr("platform.system", lambda: "Linux")
        monkeypatch.setattr(
            "subprocess.run",
            lambda *a, **kw: type("R", (), {"returncode": 0, "stdout": "8192 MiB"})(),
        )
        assert default_model_for_hardware() == "medium.en"

    def test_cpu_only_default_is_tiny(self, monkeypatch):
        self._reset_cache(monkeypatch)
        monkeypatch.setattr("platform.system", lambda: "Linux")
        monkeypatch.setattr(
            "subprocess.run",
            lambda *a, **kw: type("R", (), {"returncode": 1, "stdout": ""})(),
        )
        assert default_model_for_hardware() == "tiny.en"


# ── mlx_repo_for ─────────────────────────────────────────────────────────────

class TestMlxRepoFor:
    def test_all_known_models_have_repos(self):
        for model in MLX_MODEL_REPOS:
            assert mlx_repo_for(model) == MLX_MODEL_REPOS[model]

    def test_tiny_en_repo(self):
        assert mlx_repo_for("tiny.en") == "mlx-community/whisper-tiny.en-mlx-4bit"

    def test_medium_en_repo(self):
        assert mlx_repo_for("medium.en") == "mlx-community/whisper-medium.en-mlx-4bit"

    def test_large_v3_repo(self):
        assert mlx_repo_for("large-v3") == "mlx-community/whisper-large-v3-mlx"

    def test_unknown_model_uses_fallback_pattern(self):
        repo = mlx_repo_for("custom-model")
        assert repo == "mlx-community/whisper-custom-model-mlx-4bit"

    def test_all_known_repos_contain_mlx_community(self):
        for model in MLX_MODEL_REPOS:
            assert mlx_repo_for(model).startswith("mlx-community/")

    def test_all_known_repos_contain_4bit(self):
        for model, repo in MLX_MODEL_REPOS.items():
            if model != "large-v3":   # large-v3 doesn't use 4bit suffix
                assert "4bit" in repo or "mlx" in repo


# ── WakeWordGate backend selection (no model loading) ────────────────────────

class TestWakeWordGateBackendSelection:
    def test_apple_silicon_uses_mlx_backend(self, monkeypatch):
        monkeypatch.setattr("wakeword.platform.system", lambda: "Darwin")
        monkeypatch.setattr("wakeword.platform.machine", lambda: "arm64")
        import sys
        fake_mlx = type(sys)("mlx_whisper")
        fake_mlx.transcribe = lambda *a, **kw: {"text": ""}
        monkeypatch.setitem(sys.modules, "mlx_whisper", fake_mlx)
        gate = wakeword.WakeWordGate(model="medium.en")
        assert gate._backend == "mlx"

    def test_non_apple_uses_faster_backend(self, monkeypatch):
        monkeypatch.setattr("wakeword.platform.system", lambda: "Linux")
        monkeypatch.setattr("wakeword.platform.machine", lambda: "x86_64")
        import sys
        fake_fw = type(sys)("faster_whisper")
        fake_fw.WhisperModel = lambda *a, **kw: object()
        monkeypatch.setitem(sys.modules, "faster_whisper", fake_fw)
        gate = wakeword.WakeWordGate(model="medium.en")
        assert gate._backend == "faster"

    def test_mlx_repo_uses_model_mapping(self, monkeypatch):
        monkeypatch.setattr("wakeword.platform.system", lambda: "Darwin")
        monkeypatch.setattr("wakeword.platform.machine", lambda: "arm64")
        import sys
        fake_mlx = type(sys)("mlx_whisper")
        monkeypatch.setitem(sys.modules, "mlx_whisper", fake_mlx)
        gate = wakeword.WakeWordGate(model="medium.en")
        assert gate._mlx_repo == "mlx-community/whisper-medium.en-mlx-4bit"

    def test_custom_mlx_repo_override(self, monkeypatch):
        monkeypatch.setattr("wakeword.platform.system", lambda: "Darwin")
        monkeypatch.setattr("wakeword.platform.machine", lambda: "arm64")
        import sys
        fake_mlx = type(sys)("mlx_whisper")
        monkeypatch.setitem(sys.modules, "mlx_whisper", fake_mlx)
        gate = wakeword.WakeWordGate(
            model="medium.en",
            mlx_repo="my-org/my-custom-whisper",
        )
        assert gate._mlx_repo == "my-org/my-custom-whisper"

    def test_model_size_stored(self, monkeypatch):
        monkeypatch.setattr("wakeword.platform.system", lambda: "Linux")
        monkeypatch.setattr("wakeword.platform.machine", lambda: "x86_64")
        import sys
        fake_fw = type(sys)("faster_whisper")
        fake_fw.WhisperModel = lambda *a, **kw: object()
        monkeypatch.setitem(sys.modules, "faster_whisper", fake_fw)
        gate = wakeword.WakeWordGate(model="small.en")
        assert gate.model_size == "small.en"


# ── WakeWordGate._first_word_matches (pure logic, no model) ──────────────────

class TestFirstWordMatches:
    def _gate(self, monkeypatch):
        """Return a WakeWordGate with model loading stubbed out."""
        monkeypatch.setattr("wakeword.platform.system", lambda: "Linux")
        monkeypatch.setattr("wakeword.platform.machine", lambda: "x86_64")
        import sys
        fake_fw = type(sys)("faster_whisper")
        fake_fw.WhisperModel = lambda *a, **kw: object()
        monkeypatch.setitem(sys.modules, "faster_whisper", fake_fw)
        return wakeword.WakeWordGate(model="medium.en")

    def test_claude_exact(self, monkeypatch):
        gate = self._gate(monkeypatch)
        wake, idx = gate._first_word_matches("claude refactor this")
        assert wake == "claude" and idx == 0

    def test_codex_exact(self, monkeypatch):
        gate = self._gate(monkeypatch)
        wake, idx = gate._first_word_matches("codex write tests")
        assert wake == "codex" and idx == 0

    def test_variant_clawed(self, monkeypatch):
        gate = self._gate(monkeypatch)
        wake, idx = gate._first_word_matches("clawed help me")
        assert wake == "claude"

    def test_variant_codec(self, monkeypatch):
        gate = self._gate(monkeypatch)
        wake, idx = gate._first_word_matches("codec explain this")
        assert wake == "codex"

    def test_fuzzy_claudee(self, monkeypatch):
        gate = self._gate(monkeypatch)
        wake, idx = gate._first_word_matches("claudee write hello")
        assert wake == "claude"

    def test_blocklist_cortex_ignored(self, monkeypatch):
        gate = self._gate(monkeypatch)
        wake, _ = gate._first_word_matches("cortex pathway is active")
        assert wake is None

    def test_blocklist_kodak_ignored(self, monkeypatch):
        gate = self._gate(monkeypatch)
        wake, _ = gate._first_word_matches("kodak makes cameras")
        assert wake is None

    def test_no_wake_word(self, monkeypatch):
        gate = self._gate(monkeypatch)
        assert gate._first_word_matches("hello world how are you") == (None, -1)

    def test_empty_string(self, monkeypatch):
        gate = self._gate(monkeypatch)
        assert gate._first_word_matches("") == (None, -1)

    def test_punctuation_stripped(self, monkeypatch):
        gate = self._gate(monkeypatch)
        wake, idx = gate._first_word_matches("claude, write hello")
        assert wake == "claude" and idx == 0


# ── WakeWordGate.check short-audio passthrough ───────────────────────────────

class TestGateCheckShortAudio:
    def _gate(self, monkeypatch):
        monkeypatch.setattr("wakeword.platform.system", lambda: "Linux")
        monkeypatch.setattr("wakeword.platform.machine", lambda: "x86_64")
        import sys
        fake_fw = type(sys)("faster_whisper")
        fake_fw.WhisperModel = lambda *a, **kw: object()
        monkeypatch.setitem(sys.modules, "faster_whisper", fake_fw)
        return wakeword.WakeWordGate(model="medium.en")

    def test_short_audio_passes_through(self, monkeypatch):
        import numpy as np
        gate = self._gate(monkeypatch)
        short_pcm = np.zeros(8000, dtype=np.int16)   # 0.5s < MIN_GATE_DURATION_S
        result = gate.check(short_pcm, sample_rate=16000)
        assert result.passed is True
        assert result.tiny_text == "<short>"

    def test_short_audio_does_not_invoke_model(self, monkeypatch):
        import numpy as np
        gate = self._gate(monkeypatch)
        called = [False]
        gate._transcribe_faster = lambda *a, **kw: (called.__setitem__(0, True), "")[1]
        short_pcm = np.zeros(8000, dtype=np.int16)
        gate.check(short_pcm)
        assert not called[0]
