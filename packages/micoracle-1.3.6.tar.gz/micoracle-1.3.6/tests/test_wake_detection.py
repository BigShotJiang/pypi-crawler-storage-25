"""Unit tests for wake-word detection and command extraction (pure functions)."""

from __future__ import annotations

from hands_free_voice import detect_wake_word, extract_command, _preview_phrase


class TestDetectWakeWord:
    def test_exact_match_claude(self):
        assert detect_wake_word("claude write a function") == ("claude", 0)

    def test_exact_match_codex(self):
        assert detect_wake_word("codex explain this code") == ("codex", 0)

    def test_case_insensitive(self):
        assert detect_wake_word("CODEX WRITE HELLO") == ("codex", 0)
        assert detect_wake_word("Claude write a test") == ("claude", 0)

    def test_wake_must_be_first_word(self):
        # CHECK_FIRST_N_WORDS=1 — wake word must be spoken first
        wake, idx = detect_wake_word("hey claude please help")
        assert wake is None
        assert idx == -1

    def test_wake_not_found_in_middle(self):
        wake, idx = detect_wake_word("um ok claude help")
        assert wake is None
        assert idx == -1

    def test_wake_not_found_past_first_word(self):
        wake, idx = detect_wake_word("one two three claude refactor")
        assert wake is None
        assert idx == -1

    def test_punctuation_stripped(self):
        assert detect_wake_word("Claude, write hello") == ("claude", 0)
        assert detect_wake_word('"codex" write hello') == ("codex", 0)

    def test_no_wake_word(self):
        assert detect_wake_word("hello world how are you") == (None, -1)

    def test_empty_string(self):
        assert detect_wake_word("") == (None, -1)

    def test_whitespace_only(self):
        assert detect_wake_word("     ") == (None, -1)

    def test_exact_variant_cloud_matches_claude(self):
        # "cloud" is in the claude variant set.
        assert detect_wake_word("cloud refactor this") == ("claude", 0)

    def test_exact_variant_codec_matches_codex(self):
        # "codec" is in the codex variant set.
        assert detect_wake_word("codec explain this") == ("codex", 0)

    def test_fuzzy_match_claudee(self):
        # "claudee" is close enough to "claude" to clear the 0.78 threshold.
        wake, _ = detect_wake_word("claudee write hello")
        assert wake == "claude"

    def test_fuzzy_below_threshold(self):
        # "correct" is too far from "codex" (~0.55 ratio) to match.
        assert detect_wake_word("correct answer here") == (None, -1)


class TestExtractCommand:
    def test_basic(self):
        assert extract_command("codex write hello", 0) == "write hello"

    def test_with_comma(self):
        # Trailing punctuation and leading comma handled by strip
        assert extract_command("codex, write hello", 0) == "write hello"

    def test_empty_after_wake(self):
        assert extract_command("codex", 0) == ""

    def test_trailing_period(self):
        assert extract_command("codex write hello.", 0) == "write hello"

    def test_non_zero_idx_drops_prefix(self):
        assert extract_command("hey codex write hello", 1) == "write hello"

    def test_only_wake_with_period(self):
        assert extract_command("codex.", 0) == ""

    def test_multiple_sentences(self):
        cmd = extract_command("codex write hello and then exit", 0)
        assert cmd == "write hello and then exit"


class TestPreviewPhrase:
    def test_extracts_content_words(self):
        # "a", "in" are stop words — should be filtered
        assert _preview_phrase("write a snake game in python") == "write snake game"

    def test_skips_all_stop_words(self):
        assert _preview_phrase("fix the bug on line") == "fix bug line"

    def test_short_command_returns_all(self):
        assert _preview_phrase("snake game") == "snake game"

    def test_single_content_word(self):
        assert _preview_phrase("refactor") == "refactor"

    def test_all_stop_words_falls_back_to_raw(self):
        # If every word is a stop word, fall back to first n raw words
        assert _preview_phrase("a the and") != ""

    def test_respects_n_words_limit(self):
        result = _preview_phrase("build a rest api server with authentication", n_words=2)
        assert len(result.split()) <= 2

    def test_strips_punctuation_from_content(self):
        result = _preview_phrase("write a snake game, please")
        assert "game" in result
        assert "," not in result

    def test_real_example_explain_class(self):
        result = _preview_phrase("explain what this class does")
        assert "explain" in result
        assert "class" in result

    def test_real_example_refactor_function(self):
        result = _preview_phrase("refactor this function into smaller helpers")
        assert "refactor" in result
        assert "function" in result or "helpers" in result
