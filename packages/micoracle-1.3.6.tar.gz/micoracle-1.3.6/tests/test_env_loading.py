"""Tests for runtime .env loading behavior."""

from __future__ import annotations

import hands_free_voice as hfv


def test_load_env_files_prefers_invocation_directory(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("VOICE_AGENT_MODEL", raising=False)
    monkeypatch.delenv("VOICE_AGENT_STT_BACKEND", raising=False)
    (tmp_path / ".env").write_text(
        "VOICE_AGENT_MODEL=medium.en\n"
        "VOICE_AGENT_STT_BACKEND=mlx\n",
        encoding="utf-8",
    )

    hfv._load_env_files()

    assert hfv.os.environ["VOICE_AGENT_MODEL"] == "medium.en"
    assert hfv.os.environ["VOICE_AGENT_STT_BACKEND"] == "mlx"


def test_load_dotenv_does_not_override_existing_env(monkeypatch, tmp_path):
    monkeypatch.setenv("VOICE_AGENT_MODEL", "tiny.en")
    env_file = tmp_path / ".env"
    env_file.write_text("VOICE_AGENT_MODEL=medium.en\n", encoding="utf-8")

    hfv._load_dotenv(env_file)

    assert hfv.os.environ["VOICE_AGENT_MODEL"] == "tiny.en"
