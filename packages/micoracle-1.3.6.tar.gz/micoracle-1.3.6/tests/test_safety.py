"""Tests for safety.py — no network, no mic required."""

from __future__ import annotations

import importlib
import os
from unittest.mock import MagicMock, patch

import pytest

import safety as _s


def _email(local: str, domain: str, suffix: str) -> str:
    return f"{local}@{domain}.{suffix}"


# ── PIIRedactor ───────────────────────────────────────────────────────────────

class TestPIIRedactor:
    def setup_method(self):
        self.r = _s.PIIRedactor()

    def test_redacts_email(self):
        text, found = self.r.scan(f"send to {_email('john', 'samplemail', 'io')} please")
        assert "<EMAIL>" in text
        assert "email" in found

    def test_redacts_phone_us(self):
        text, found = self.r.scan("call me at 415-555-1234 okay")
        assert "<PHONE>" in text
        assert "phone" in found

    def test_redacts_ssn(self):
        text, found = self.r.scan("my ssn is 123-45-6789")
        assert "<SSN>" in text
        assert "ssn" in found

    def test_redacts_credit_card(self):
        text, found = self.r.scan("card 4111 1111 1111 1111 please")
        assert "<CARD>" in text
        assert "credit_card" in found

    def test_redacts_ip_address(self):
        text, found = self.r.scan("connect to 8.8.8.8 now")
        assert "<IP>" in text
        assert "ip_address" in found

    def test_clean_text_unchanged(self):
        original = "write a function to sort a list"
        text, found = self.r.scan(original)
        assert text == original
        assert found == []

    def test_multiple_pii_in_one_string(self):
        address = _email("john", "company", "io")
        text, found = self.r.scan(f"email {address} and call 555-123-4567")
        assert "email" in found
        assert "phone" in found
        assert address not in text

    def test_original_not_mutated(self):
        original = f"my email is {_email('x', 'y', 'com')}"
        _, _ = self.r.scan(original)
        assert original == f"my email is {_email('x', 'y', 'com')}"

    # ── false-positive guards ──────────────────────────────────────────────────

    def test_does_not_redact_test_email_domains(self):
        for domain in ("example.com", "test.com", "foo.com", "domain.com"):
            text, found = self.r.scan(f"user@{domain}")
            assert f"user@{domain}" in text, f"Should not redact @{domain}"
            assert "email" not in found

    def test_redacts_real_email_domain(self):
        text, found = self.r.scan(_email("contact", "realcompany", "io"))
        assert "<EMAIL>" in text
        assert "email" in found

    def test_does_not_redact_private_ip(self):
        for ip in ("127.0.0.1", "192.168.1.1", "10.0.0.1", "172.16.0.1", "0.0.0.0"):
            text, found = self.r.scan(f"connect to {ip}")
            assert ip in text, f"Should not redact private IP {ip}"
            assert "ip_address" not in found

    def test_redacts_public_ip(self):
        text, found = self.r.scan("server at 8.8.8.8")
        assert "<IP>" in text
        assert "ip_address" in found

    def test_does_not_redact_localhost(self):
        text, found = self.r.scan("run on 127.0.0.1:8080")
        assert "127.0.0.1" in text


# ── CredentialScanner ─────────────────────────────────────────────────────────

class TestCredentialScanner:
    def setup_method(self):
        self.s = _s.CredentialScanner()

    def test_detects_openai_key(self):
        found = self.s.scan("use sk-abcdefghijklmnopqrstuvwxyz123456")
        assert "OpenAI key" in found

    def test_detects_aws_key(self):
        found = self.s.scan("AKIAIOSFODNN7EXAMPLE in config")
        assert "AWS access key" in found

    def test_detects_github_token(self):
        found = self.s.scan("token ghp_" + "a" * 36)
        assert "GitHub token" in found

    def test_detects_anthropic_key(self):
        found = self.s.scan("sk-ant-" + "a" * 50)
        assert "Anthropic key" in found

    def test_detects_bearer_token(self):
        found = self.s.scan("Authorization: bearer " + "x" * 30)
        assert "bearer token" in found

    def test_clean_text_returns_empty(self):
        found = self.s.scan("write a hello world function")
        assert found == []

    def test_multiple_credentials_found(self):
        found = self.s.scan("sk-abcdefghijklmnopqrstuvwxyz123456 AKIAIOSFODNN7EXAMPLE")
        assert len(found) >= 2


# ── DangerousCommandFilter ────────────────────────────────────────────────────

class TestDangerousCommandFilter:
    def setup_method(self):
        self.f = _s.DangerousCommandFilter()

    # Hard blocks
    def test_blocks_rm_rf_root(self):
        blocked, reason, _ = self.f.scan("rm -rf /")
        assert blocked
        assert reason is not None

    def test_blocks_rm_rf_root_wildcard(self):
        blocked, _, _ = self.f.scan("rm -rf /*")
        assert blocked

    def test_blocks_rm_rf_root_with_space(self):
        blocked, _, _ = self.f.scan("rm -r -f /")
        assert blocked

    # ── false-positive guards — legitimate developer paths must pass ──────────

    def test_does_not_block_rm_rf_project_path(self):
        blocked, _, _ = self.f.scan("rm -rf /home/user/myproject/dist")
        assert not blocked

    def test_does_not_block_rm_rf_relative_path(self):
        blocked, _, _ = self.f.scan("rm -rf ./node_modules")
        assert not blocked

    def test_does_not_block_rm_rf_build_dir(self):
        blocked, _, _ = self.f.scan("rm -rf /tmp/build-output")
        assert not blocked

    def test_does_not_block_dd_partition(self):
        # targeting /dev/sda1 (partition) should NOT hard-block — could be legit
        blocked, _, _ = self.f.scan("dd if=image.iso of=/dev/sda1")
        assert not blocked

    def test_blocks_dd_whole_disk(self):
        blocked, _, _ = self.f.scan("dd if=/dev/zero of=/dev/sda")
        assert blocked

    def test_blocks_mkfs(self):
        blocked, _, _ = self.f.scan("mkfs.ext4 /dev/sdb")
        assert blocked

    def test_blocks_dd_overwrite(self):
        blocked, _, _ = self.f.scan("dd if=/dev/zero of=/dev/sda")
        assert blocked

    # Soft warns
    def test_warns_rm_rf_dir(self):
        blocked, _, warnings = self.f.scan("rm -rf ./node_modules")
        assert not blocked
        assert any("delete" in w for w in warnings)

    def test_warns_sql_drop_table(self):
        blocked, _, warnings = self.f.scan("DROP TABLE users")
        assert not blocked
        assert any("DROP TABLE" in w for w in warnings)

    def test_warns_git_reset_hard(self):
        blocked, _, warnings = self.f.scan("git reset --hard HEAD~1")
        assert not blocked
        assert any("reset" in w for w in warnings)

    def test_warns_git_force_push(self):
        blocked, _, warnings = self.f.scan("git push origin main --force")
        assert not blocked
        assert any("force" in w for w in warnings)

    def test_warns_delete_from(self):
        blocked, _, warnings = self.f.scan("DELETE FROM orders WHERE id=5")
        assert not blocked
        assert warnings

    # Safe commands
    def test_safe_command_passes(self):
        blocked, reason, warnings = self.f.scan("write a python function to reverse a string")
        assert not blocked
        assert reason is None
        assert warnings == []

    def test_safe_git_command_passes(self):
        blocked, _, warnings = self.f.scan("git commit -m add new feature")
        assert not blocked
        assert warnings == []


# ── SafetyPipeline ────────────────────────────────────────────────────────────

class TestSafetyPipeline:
    def _pipeline(self, env: dict | None = None):
        base = {
            "VOICE_AGENT_SAFETY": "true",
            "VOICE_AGENT_SAFETY_PII": "true",
            "VOICE_AGENT_SAFETY_CREDENTIALS": "true",
            "VOICE_AGENT_SAFETY_DANGEROUS": "true",
            "VOICE_AGENT_SAFETY_MODERATION": "false",
        }
        if env:
            base.update(env)
        with patch.dict(os.environ, base, clear=False):
            return _s.SafetyPipeline()

    def test_safe_command_passes(self):
        pipeline = self._pipeline()
        result = pipeline.check("write a function to parse JSON")
        assert result.safe
        assert not result.blocked
        assert result.text == "write a function to parse JSON"

    def test_pii_redacted_in_output(self):
        pipeline = self._pipeline()
        result = pipeline.check(f"send to {_email('user', 'company', 'io')}")
        assert result.safe
        assert "<EMAIL>" in result.text
        assert any("PII redacted" in w for w in result.warnings)

    def test_credential_blocks(self):
        pipeline = self._pipeline()
        result = pipeline.check("use sk-abcdefghijklmnopqrstuvwxyz123456")
        assert not result.safe
        assert result.blocked
        assert "Credential" in result.reason

    def test_dangerous_command_blocks(self):
        pipeline = self._pipeline()
        result = pipeline.check("rm -rf /")
        assert not result.safe
        assert result.blocked
        assert "Dangerous" in result.reason

    def test_warn_does_not_block(self):
        pipeline = self._pipeline()
        result = pipeline.check("git reset --hard HEAD")
        assert result.safe
        assert not result.blocked
        assert result.warnings  # warning exists

    def test_master_switch_off_bypasses_all(self):
        pipeline = self._pipeline({"VOICE_AGENT_SAFETY": "false"})
        result = pipeline.check("rm -rf /")
        assert result.safe
        assert not result.blocked

    def test_pii_disabled_does_not_redact(self):
        pipeline = self._pipeline({"VOICE_AGENT_SAFETY_PII": "false"})
        address = _email("user", "example", "com")
        result = pipeline.check(f"email me at {address}")
        assert address in result.text

    def test_credentials_disabled_allows_key(self):
        pipeline = self._pipeline({"VOICE_AGENT_SAFETY_CREDENTIALS": "false"})
        result = pipeline.check("sk-abcdefghijklmnopqrstuvwxyz123456")
        assert not result.blocked

    def test_dangerous_disabled_allows_rm_rf(self):
        pipeline = self._pipeline({
            "VOICE_AGENT_SAFETY_DANGEROUS": "false",
            "VOICE_AGENT_SAFETY_CREDENTIALS": "false",
        })
        result = pipeline.check("rm -rf /")
        assert not result.blocked

    def test_result_text_is_redacted_not_original(self):
        pipeline = self._pipeline()
        cmd = "my card is 4111 1111 1111 1111"
        result = pipeline.check(cmd)
        assert "4111" not in result.text
        assert "<CARD>" in result.text

    def test_blocked_result_is_not_safe(self):
        pipeline = self._pipeline()
        result = pipeline.check("AKIAIOSFODNN7EXAMPLE")
        assert result.safe is False
        assert result.blocked is True

    def test_reason_populated_on_block(self):
        pipeline = self._pipeline()
        result = pipeline.check("rm -rf /")
        assert result.reason is not None
        assert len(result.reason) > 0

    def test_moderation_skipped_without_key(self):
        env = {"VOICE_AGENT_SAFETY_MODERATION": "true"}
        env.pop("OPENAI_API_KEY", None)
        with patch.dict(os.environ, env, clear=False):
            os.environ.pop("OPENAI_API_KEY", None)
            pipeline = _s.SafetyPipeline()
        assert pipeline._moderation is None
