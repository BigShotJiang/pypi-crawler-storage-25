"""Dispatch behavior tests."""

from __future__ import annotations

from unittest.mock import MagicMock

import hands_free_voice as hfv
import tts


def test_dispatch_no_speak_does_not_sleep(monkeypatch):
    adapter = MagicMock()
    sleeper = MagicMock()
    monkeypatch.setattr(hfv.time, "sleep", sleeper)

    hfv._dispatch(adapter, "Cursor.exe", "codex", "write tests", tts.SilentTTS())

    sleeper.assert_not_called()
    adapter.paste_and_return.assert_called_once_with("write tests", "Cursor.exe")


def test_dispatch_preview_delay_is_opt_in(monkeypatch):
    class FakeTTS(tts.TTSBackend):
        name = "fake"

        def __init__(self) -> None:
            self.spoken: list[str] = []

        def speak(self, phrase: str) -> None:
            self.spoken.append(phrase)

    adapter = MagicMock()
    sleeper = MagicMock()
    fake_tts = FakeTTS()
    monkeypatch.setenv("VOICE_AGENT_TTS_PREVIEW_DELAY", "0.25")
    monkeypatch.setattr(hfv.time, "sleep", sleeper)

    hfv._dispatch(adapter, "Cursor.exe", "codex", "write a snake game", fake_tts)

    assert fake_tts.spoken == ["write snake game"]
    sleeper.assert_called_once_with(0.25)
    adapter.paste_and_return.assert_called_once_with("write a snake game", "Cursor.exe")
