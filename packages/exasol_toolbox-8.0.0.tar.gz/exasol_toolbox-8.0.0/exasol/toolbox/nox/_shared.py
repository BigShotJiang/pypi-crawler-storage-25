from __future__ import annotations

import argparse
from collections import ChainMap
from collections.abc import (
    MutableMapping,
)
from enum import (
    Enum,
    auto,
)
from pathlib import Path
from typing import Any

from nox import Session

from noxconfig import (
    PROJECT_CONFIG,
)

DOCS_OUTPUT_DIR = ".html-documentation"


class Mode(Enum):
    Fix = auto()
    Check = auto()


def get_filtered_python_files(project_root: Path) -> list[str]:
    """
    Returns iterable of Python files after removing excluded paths
    """
    files = project_root.glob("**/*.py")

    def exclude(path: Path):
        current = set(path.parents) | {path}
        return current.intersection(PROJECT_CONFIG.excluded_python_paths)

    return [f"{path}" for path in files if not exclude(path)]


def _context_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    parser.add_argument(
        "--db-version", default="7.1.9", help="Specify the Exasol DB version to be used"
    )
    parser.add_argument(
        "--coverage", action="store_true", help="Enable the collection of coverage data"
    )
    return parser


def _context(session: Session, **kwargs: Any) -> MutableMapping[str, Any]:
    parser = _context_parser()
    namespace, args = parser.parse_known_args(session.posargs)
    cli_context: MutableMapping[str, Any] = vars(namespace)
    cli_context["fwd-args"] = args
    default_context = {"db_version": "7.1.9", "coverage": False}
    # Note: ChainMap scans last to first
    return ChainMap(kwargs, cli_context, default_context)
