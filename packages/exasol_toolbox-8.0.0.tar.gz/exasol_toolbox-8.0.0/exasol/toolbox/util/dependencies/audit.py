from __future__ import annotations

import json
import subprocess  # nosec: B404 - risk of subprocess is accepted
import tempfile
from dataclasses import dataclass
from enum import Enum
from inspect import cleandoc
from pathlib import Path
from re import search
from typing import (
    Any,
)

from pydantic import (
    BaseModel,
    ConfigDict,
)

from exasol.toolbox.util.dependencies.shared_models import (
    Package,
    poetry_files_from_latest_tag,
)

PIP_AUDIT_VULNERABILITY_PATTERN = (
    r"(?m)^Found \d+ known vulnerabilit(?:y|ies) in \d+ package(?:s)?$"
)

PipAuditEntry = dict[str, str | list[str] | tuple[str, ...]]


@dataclass
class SubprocessException(Exception):
    command: list[str]
    cwd: Path
    env: dict[str, str]
    returncode: int
    stdout: str
    stderr: str

    @classmethod
    def from_subprocess(
        cls,
        proc: subprocess.CompletedProcess,
        command: list[str],
        cwd: Path,
        env: dict[str, str] | None = None,
    ) -> SubprocessException:
        return cls(command, cwd, env or {}, proc.returncode, proc.stdout, proc.stderr)


class PipAuditException(SubprocessException):
    pass


class PoetryException(SubprocessException):
    pass


class VulnerabilitySource(str, Enum):
    CVE = "CVE"
    CWE = "CWE"
    GHSA = "GHSA"
    PYSEC = "PYSEC"

    @classmethod
    def from_prefix(cls, name: str) -> VulnerabilitySource | None:
        for el in cls:
            if name.upper().startswith(el.value):
                return el
        return None

    def get_link(self, package: str, vuln_id: str) -> str:
        if self == VulnerabilitySource.CWE:
            cwe_id = vuln_id.upper().replace(f"{VulnerabilitySource.CWE.value}-", "")
            return f"https://cwe.mitre.org/data/definitions/{cwe_id}.html"

        map_link = {
            VulnerabilitySource.CVE: "https://nvd.nist.gov/vuln/detail/{vuln_id}",
            VulnerabilitySource.GHSA: "https://github.com/advisories/{vuln_id}",
            VulnerabilitySource.PYSEC: "https://github.com/pypa/advisory-database/blob/main/vulns/{package}/{vuln_id}.yaml",
        }
        return map_link[self].format(package=package, vuln_id=vuln_id)


class Vulnerability(BaseModel):
    model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)

    package: Package
    id: str
    aliases: list[str]
    fix_versions: list[str]
    description: str

    @classmethod
    def from_audit_entry(
        cls, package_name: str, version: str, vuln_entry: dict[str, Any]
    ) -> Vulnerability:
        """
        Create a Vulnerability from a pip-audit vulnerability entry
        """
        return cls(
            package=Package(name=package_name, version=version),
            id=vuln_entry["id"],
            aliases=vuln_entry["aliases"],
            fix_versions=vuln_entry["fix_versions"],
            description=vuln_entry["description"],
        )

    @property
    def references(self) -> list[str]:
        return sorted([self.id] + self.aliases)

    @property
    def reference_links(self) -> tuple[str, ...]:
        return tuple(
            source.get_link(package=self.package.name, vuln_id=reference)
            for reference in self.references
            if (source := VulnerabilitySource.from_prefix(reference.upper()))
        )

    @property
    def security_issue_entry(self) -> PipAuditEntry:
        return {
            "name": self.package.name,
            "version": str(self.package.version),
            "refs": self.references,
            "description": self.description,
            "coordinates": self.package.coordinates,
            "references": self.reference_links,
        }

    @property
    def vulnerability_id(self) -> str | None:
        """
        Ensure a consistent way of identifying a vulnerability for string generation.
        """
        for ref in self.references:
            ref_upper = ref.upper()
            if ref_upper.startswith(VulnerabilitySource.CVE.value):
                return ref
            if ref_upper.startswith(VulnerabilitySource.GHSA.value):
                return ref
            if ref_upper.startswith(VulnerabilitySource.PYSEC.value):
                return ref
        return self.references[0]

    @property
    def subsection_for_changelog_summary(self) -> str:
        """
        Create a subsection to be included in the Summary section of a versioned changelog.
        """
        indent = " " * 12
        references = f"\n{indent}".join(
            f"* {link}" for link in sorted(self.reference_links)
        )
        description = self.description.replace("\n", f"\n{indent}")
        return cleandoc(f"""
            ### {self.vulnerability_id} in {self.package.coordinates}

            {description}

            #### References

            {references}
            """)


def export_dependencies_to_file(output_file: Path, working_directory: Path) -> None:
    """
    Export all dependencies to a requirements.txt format

    The default for `poetry export` is to only include the main dependencies and their
    transitive dependencies, by adding `--all-groups` and `all-extras` we get
    all dependencies defined in groups, like dev dependencies, and all optional
    dependencies.
    """
    command = [
        "poetry",
        "export",
        "--format=requirements.txt",
        "--all-groups",
        "--all-extras",
        "--without-hashes",
        "-o",
        str(output_file),
    ]
    output = subprocess.run(
        command,
        capture_output=True,
        text=True,
        cwd=working_directory,
    )  # nosec: B603 - allow fixed poetry usage
    if output.returncode != 0:
        raise PoetryException.from_subprocess(output, command, cwd=working_directory)


def audit_poetry_files(working_directory: Path) -> str:
    """
    Audit the `pyproject.toml` and `poetry.lock` files

    pip-audit evaluates installed packages. This is to provide
    additional security-related information beyond seeing if a given package
    has a known vulnerability. Thus, to audit our `pyproject.toml` and
    `poetry.lock` files without altering a locally sourced poetry environment,
    this function first exports the locked packages to a requirements.txt file.
    Then, pip-audit evaluates the requirements.txt by installing them to a virtualenv
    and then inspecting the dependencies.
    """

    with tempfile.TemporaryDirectory() as path:
        tmpdir = Path(path)
        requirements_path = tmpdir / "requirements.txt"
        export_dependencies_to_file(requirements_path, working_directory)

        # CLI option `--disable-pip` skips dependency resolution in pip.  The
        # option can be used with hashed requirements files to avoid
        # `pip-audit` installing an isolated environment and speed up the
        # audit significantly.
        #
        # In real use scenarios of the PTB we usually have hashed
        # requirements. Unfortunately this is not the case for the example
        # project created in the integration tests.
        command = ["pip-audit", "-r", requirements_path.name, "-f", "json"]
        output = subprocess.run(
            command,
            capture_output=True,
            text=True,
            cwd=tmpdir,
        )  # nosec: B603 - allow fixed pip-audit usage

    if output.returncode != 0:
        # pip-audit does not distinguish between 1) finding vulnerabilities
        # and 2) other errors performing the pip-audit (i.e. malformed file);
        # they both map to returncode = 1, so we have our own logic to raise errors
        # for the case of 2) and not 1).
        if not search(PIP_AUDIT_VULNERABILITY_PATTERN, output.stderr.strip()):
            raise PipAuditException.from_subprocess(output, command, cwd=tmpdir)
    return output.stdout


class Vulnerabilities(BaseModel):
    vulnerabilities: list[Vulnerability]

    @classmethod
    def load_from_pip_audit(cls, working_directory: Path) -> Vulnerabilities:
        """
        Convert the pip-audit JSON output into a Vulnerabilities model

        The output from pip-audit is a JSON, which as a dictionary looks like:
        >>> audit_dict = {"dependencies": [
        ... {"name": "alabaster", "version": "0.7.16", "vulns": []},
        ... {"name": "cryptography", "version": "43.0.3", "vulns":
        ... [{"id": "GHSA-79v4-65xg-pq4g", "fix_versions": ["44.0.1"],
        ... "aliases": ["CVE-2024-12797"],
        ... "description": "pyca/cryptography\'s wheels..."}, ...]}]}
        """
        audit_json = audit_poetry_files(working_directory)
        audit_dict = json.loads(audit_json)

        vulnerabilities = []
        for entry in audit_dict["dependencies"]:
            for vuln_entry in entry.get("vulns", []):
                vulnerabilities.append(
                    Vulnerability.from_audit_entry(
                        package_name=entry["name"],
                        version=entry["version"],
                        vuln_entry=vuln_entry,
                    )
                )
        return Vulnerabilities(vulnerabilities=vulnerabilities)

    @property
    def security_issue_dict(self) -> list[PipAuditEntry]:
        return [
            vulnerability.security_issue_entry for vulnerability in self.vulnerabilities
        ]


def get_vulnerabilities(working_directory: Path) -> list[Vulnerability]:
    return Vulnerabilities.load_from_pip_audit(
        working_directory=working_directory
    ).vulnerabilities


def get_vulnerabilities_from_latest_tag(root_path: Path) -> list[Vulnerability]:
    with poetry_files_from_latest_tag(root_path=root_path) as tmp_dir:
        return get_vulnerabilities(working_directory=tmp_dir)
