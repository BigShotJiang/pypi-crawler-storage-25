"""Tests for bitacorista.db — data layer."""

import pytest
from bitacorista import db as store


# --- Schema ---


def test_init_db_creates_tables(db):
    conn, _ = db
    tables = [r[0] for r in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
    ).fetchall()]
    assert "entries" in tables
    assert "edges" in tables
    assert "exchanges" in tables
    assert "session_meta" in tables


# --- IDs ---


def test_next_id_increments(db):
    conn, _ = db
    assert store.next_id(conn) == "E001"
    assert store.next_id(conn) == "E002"
    assert store.next_id(conn) == "E003"


# --- Entries ---


def test_add_entry_and_get_entry(db):
    conn, _ = db
    eid = store.add_entry(conn, tipo="DECISIÓN", resumen="Usar SQLite", contexto="Por rendimiento")
    assert eid == "E001"
    entry = store.get_entry(conn, eid)
    assert entry["tipo"] == "DECISIÓN"
    assert entry["resumen"] == "Usar SQLite"
    assert entry["contexto"] == "Por rendimiento"
    assert entry["estado"] == "INFERIDO"


def test_add_entry_explicit_estado(db):
    conn, _ = db
    eid = store.add_entry(conn, tipo="DESCARTE", resumen="React descartado", estado="DESCARTADO")
    assert store.get_entry(conn, eid)["estado"] == "DESCARTADO"


def test_add_entry_rejects_invalid_tipo(db):
    conn, _ = db
    with pytest.raises(Exception):
        store.add_entry(conn, tipo="INVALIDO", resumen="test")


def test_add_entry_rejects_invalid_estado(db):
    conn, _ = db
    with pytest.raises(Exception):
        store.add_entry(conn, tipo="DECISIÓN", resumen="test", estado="MALO")


def test_get_entries_filters_by_tipo(db):
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="D1")
    store.add_entry(conn, tipo="DESCARTE", resumen="X1", estado="DESCARTADO")
    store.add_entry(conn, tipo="DECISIÓN", resumen="D2")
    results = store.get_entries(conn, tipo="DECISIÓN")
    assert len(results) == 2
    assert all(r["tipo"] == "DECISIÓN" for r in results)


def test_get_entries_filters_by_estado(db):
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="D1", estado="FIRME")
    store.add_entry(conn, tipo="DECISIÓN", resumen="D2", estado="INFERIDO")
    store.add_entry(conn, tipo="DECISIÓN", resumen="D3", estado="FIRME")
    assert len(store.get_entries(conn, estado="FIRME")) == 2


def test_update_estado(db):
    conn, _ = db
    eid = store.add_entry(conn, tipo="DECISIÓN", resumen="Test", estado="INFERIDO")
    store.update_estado(conn, eid, "FIRME")
    assert store.get_entry(conn, eid)["estado"] == "FIRME"


def test_get_entry_nonexistent_returns_none(db):
    conn, _ = db
    assert store.get_entry(conn, "E999") is None


def test_add_entry_rollback_on_invalid_preserves_next_id(db):
    conn, _ = db
    n_before = int(store.get_meta(conn, "next_id"))
    with pytest.raises(Exception):
        store.add_entry(conn, tipo="INVALIDO", resumen="Test")
    n_after = int(store.get_meta(conn, "next_id"))
    assert n_after == n_before


# --- Edges ---


def test_add_edge_and_get_edges(db):
    conn, _ = db
    e1 = store.add_entry(conn, tipo="DECISIÓN", resumen="A")
    e2 = store.add_entry(conn, tipo="DECISIÓN", resumen="B")
    store.add_edge(conn, e1, e2, "EXTRACTED", 1.0)
    edges = store.get_edges(conn, e1)
    assert len(edges) == 1
    assert edges[0]["source"] == e1
    assert edges[0]["target"] == e2


def test_add_edge_duplicate_is_ignored(db):
    conn, _ = db
    e1 = store.add_entry(conn, tipo="DECISIÓN", resumen="A")
    e2 = store.add_entry(conn, tipo="DECISIÓN", resumen="B")
    store.add_edge(conn, e1, e2, "EXTRACTED")
    store.add_edge(conn, e1, e2, "EXTRACTED")
    assert len(store.get_edges(conn)) == 1


def test_cascade_delete_removes_edges(db):
    conn, _ = db
    e1 = store.add_entry(conn, tipo="DECISIÓN", resumen="A")
    e2 = store.add_entry(conn, tipo="DECISIÓN", resumen="B")
    store.add_edge(conn, e1, e2, "EXTRACTED")
    conn.execute("DELETE FROM entries WHERE id = ?", (e1,))
    assert len(store.get_edges(conn)) == 0


# --- Exchanges ---


def test_add_exchange_and_get_exchanges(db):
    conn, _ = db
    store.add_exchange(conn, 1, "Hola", "Qué tal")
    store.add_exchange(conn, 2, "Siguiente", "Ok")
    exs = store.get_exchanges(conn)
    assert len(exs) == 2
    assert exs[0]["user_msg"] == "Hola"
    assert exs[1]["n"] == 2


def test_count_exchanges(db):
    conn, _ = db
    assert store.count_exchanges(conn) == 0
    store.add_exchange(conn, 1, "Hola")
    store.add_exchange(conn, 2, "Chau")
    assert store.count_exchanges(conn) == 2


# --- Meta ---


def test_set_meta_and_get_meta(db):
    conn, _ = db
    store.set_meta(conn, "test_key", "test_value")
    assert store.get_meta(conn, "test_key") == "test_value"
    assert store.get_meta(conn, "nonexistent") is None


# --- Graph ---


def test_bfs_traversal(db):
    conn, _ = db
    e1 = store.add_entry(conn, tipo="DECISIÓN", resumen="A")
    e2 = store.add_entry(conn, tipo="DECISIÓN", resumen="B")
    e3 = store.add_entry(conn, tipo="DECISIÓN", resumen="C")
    store.add_edge(conn, e1, e2, "EXTRACTED")
    store.add_edge(conn, e2, e3, "EXTRACTED")
    result = store.bfs(conn, e1, max_depth=3)
    depths = {r[0]: r[1] for r in result}
    assert depths[e2] == 1
    assert depths[e3] == 2


# --- Helpers ---


def test_floats_blob_roundtrip():
    original = [0.1, 0.2, 0.3, -0.5, 1.0]
    blob = store._floats_to_blob(original)
    recovered = store._blob_to_floats(blob)
    for a, b in zip(original, recovered):
        assert abs(a - b) < 1e-6


# --- Resumen ---


def test_get_resumen_format(db):
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="Usar Vue", estado="FIRME")
    store.add_entry(conn, tipo="DESCARTE", resumen="React descartado", estado="DESCARTADO")
    store.add_entry(conn, tipo="DESCUBRIMIENTO", resumen="Algo inferido", estado="INFERIDO")
    resumen = store.get_resumen(conn)
    assert "DECISIONES FIRMES:" in resumen
    assert "Usar Vue" in resumen
    assert "NO PROPONER" in resumen
    assert "3 entradas" in resumen


# --- Stats ---


def test_get_stats_empty(db):
    conn, _ = db
    stats = store.get_stats(conn)
    assert stats["entries"] == 0
    assert stats["exchanges"] == 0
    assert stats["detection_rate"] == 0
    assert stats["by_tipo"] == {}
    assert stats["by_estado"] == {}
    assert stats["top_connected"] == []


def test_get_stats_with_data(db):
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="Usar Vue", estado="FIRME")
    store.add_entry(conn, tipo="DESCARTE", resumen="React descartado", estado="DESCARTADO")
    store.add_entry(conn, tipo="DECISIÓN", resumen="SQLite DB", estado="FIRME")
    store.add_exchange(conn, n=1, user_msg="test", asst_msg="ok")
    store.add_exchange(conn, n=2, user_msg="test2", asst_msg="ok2")

    stats = store.get_stats(conn)
    assert stats["entries"] == 3
    assert stats["exchanges"] == 2
    assert stats["detection_rate"] == 1.5
    assert stats["by_tipo"]["DECISIÓN"] == 2
    assert stats["by_tipo"]["DESCARTE"] == 1
    assert stats["by_estado"]["FIRME"] == 2
    assert stats["by_estado"]["DESCARTADO"] == 1


def test_get_stats_top_connected(db):
    conn, _ = db
    store.add_entry(conn, tipo="DECISIÓN", resumen="A")
    store.add_entry(conn, tipo="DECISIÓN", resumen="B")
    store.add_entry(conn, tipo="DECISIÓN", resumen="C")
    store.add_edge(conn, "E001", "E002")
    store.add_edge(conn, "E001", "E003")

    stats = store.get_stats(conn)
    assert len(stats["top_connected"]) > 0
    assert stats["top_connected"][0]["id"] == "E001"


# --- Proyecto mode ---


def test_proyecto_creates_sessions_table(proyecto_db):
    conn, _ = proyecto_db
    tables = [r[0] for r in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
    ).fetchall()]
    assert "sessions" in tables
    assert store.get_meta(conn, "modo") == "proyecto"


def test_create_session_and_list(proyecto_db):
    conn, _ = proyecto_db
    sid = store.create_session(conn, name="brainstorm")
    sessions = store.list_sessions(conn)
    assert len(sessions) == 1
    assert store.get_active_session(conn) == sid


def test_proyecto_accepts_hipotesis_and_fuente(proyecto_db):
    conn, _ = proyecto_db
    e1 = store.add_entry(conn, tipo="HIPÓTESIS", resumen="Vue es mejor")
    e2 = store.add_entry(conn, tipo="FUENTE", resumen="Paper de Smith")
    assert store.get_entry(conn, e1)["tipo"] == "HIPÓTESIS"
    assert store.get_entry(conn, e2)["tipo"] == "FUENTE"


def test_sesion_mode_rejects_hipotesis(db):
    conn, _ = db
    with pytest.raises(Exception):
        store.add_entry(conn, tipo="HIPÓTESIS", resumen="test")


def test_evidencia(proyecto_db):
    conn, _ = proyecto_db
    h = store.add_entry(conn, tipo="HIPÓTESIS", resumen="Vue es mejor")
    s = store.add_entry(conn, tipo="FUENTE", resumen="Benchmark favorable")
    c = store.add_entry(conn, tipo="FUENTE", resumen="Benchmark desfavorable")
    store.add_edge(conn, h, s, "SUPPORTS")
    store.add_edge(conn, h, c, "CONTRADICTS")
    ev = store.evidencia(conn, h)
    assert len(ev["supports"]) == 1
    assert len(ev["contradicts"]) == 1


def test_versiones_chain(proyecto_db):
    conn, _ = proyecto_db
    e1 = store.add_entry(conn, tipo="DECISIÓN", resumen="Usar React", estado="OBSOLETO")
    e2 = store.add_entry(conn, tipo="DECISIÓN", resumen="Usar Vue", estado="FIRME")
    store.add_edge(conn, e2, e1, "SUPERSEDES")
    chain = store.versiones(conn, e2)
    assert len(chain) == 2
    assert chain[0]["id"] == e1
    assert chain[1]["id"] == e2


def test_versiones_cycle_no_infinite_loop(proyecto_db):
    conn, _ = proyecto_db
    e1 = store.add_entry(conn, tipo="DECISIÓN", resumen="A", estado="OBSOLETO")
    e2 = store.add_entry(conn, tipo="DECISIÓN", resumen="B", estado="FIRME")
    store.add_edge(conn, e2, e1, "SUPERSEDES")
    store.add_edge(conn, e1, e2, "SUPERSEDES")
    chain = store.versiones(conn, e1)
    assert 1 <= len(chain) <= 3


def test_versiones_nonexistent_returns_empty(proyecto_db):
    conn, _ = proyecto_db
    assert store.versiones(conn, "E999") == []


def test_add_entry_with_session_id(proyecto_db):
    conn, _ = proyecto_db
    sid = store.get_active_session(conn)
    eid = store.add_entry(conn, tipo="DECISIÓN", resumen="Test", session_id=sid)
    assert store.get_entry(conn, eid)["session_id"] == sid
