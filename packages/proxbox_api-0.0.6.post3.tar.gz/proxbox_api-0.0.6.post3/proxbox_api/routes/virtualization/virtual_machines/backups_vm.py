"""VM backup discovery, batch processing, and sync routes."""

import asyncio
import os
from datetime import datetime
from typing import Annotated

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import StreamingResponse

from proxbox_api.dependencies import NetBoxSessionDep, ProxboxTagDep
from proxbox_api.exception import ProxboxException
from proxbox_api.logger import logger
from proxbox_api.netbox_rest import (
    rest_create_async,
    rest_list,
    rest_list_async,
    rest_reconcile_async,
)
from proxbox_api.proxmox_to_netbox.models import NetBoxBackupSyncState
from proxbox_api.routes.proxmox.cluster import ClusterStatusDep
from proxbox_api.services.proxmox_helpers import dump_models, get_node_storage_content
from proxbox_api.services.sync.storage_links import (
    build_storage_index,
    find_storage_record,
    storage_name_from_volume_id,
)
from proxbox_api.services.sync.vm_helpers import parse_comma_separated_ints
from proxbox_api.session.proxmox import ProxmoxSessionsDep
from proxbox_api.utils.streaming import WebSocketSSEBridge, sse_event

router = APIRouter()
_DEFAULT_FETCH_CONCURRENCY = max(1, int(os.getenv("PROXBOX_PROXMOX_FETCH_CONCURRENCY", "8")))


def _volids_from_proxmox_storage_backup_items(items: list[dict]) -> set[str]:
    """Collect Proxmox volume IDs for backup content rows (volid / NetBox volume_id)."""
    out: set[str] = set()
    for item in items:
        if item.get("content") != "backup":
            continue
        vid = item.get("volid")
        if isinstance(vid, str) and vid:
            out.add(vid)
    return out


def _relation_id_or_none(value):
    if isinstance(value, dict):
        value = value.get("id")
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


async def _load_storage_index(netbox_session) -> dict[tuple[str, str], dict]:
    nb = netbox_session
    try:
        storage_records = await rest_list_async(nb, "/api/plugins/proxbox/storage/")
    except Exception as error:
        error_detail = getattr(error, "detail", str(error))
        error_msg = f"{type(error).__name__}: {error_detail}"
        logger.warning("Error loading storage records for backup sync: %s", error_msg)
        return {}
    return build_storage_index(storage_records)


async def create_netbox_backups(
    backup,
    netbox_session: NetBoxSessionDep,
    *,
    cluster_name: str | None = None,
    storage_index: dict[tuple[str, str], dict] | None = None,
    vm_cache: dict[int, dict | None] | None = None,
):
    nb = netbox_session
    vmid_log: str | int | None = None
    try:
        if not isinstance(backup, dict):
            return None
        # Get the virtual machine on NetBox by the VM ID.
        vmid = backup.get("vmid", None)
        vmid_log = vmid
        if not vmid:
            return None

        vmid_int = int(vmid)
        virtual_machine = vm_cache.get(vmid_int) if vm_cache is not None else None
        if virtual_machine is None:
            # Get the virtual machine on NetBox by the VM ID using custom field filter
            vms = await rest_list_async(
                nb,
                "/api/virtualization/virtual-machines/",
                query={"cf_proxmox_vm_id": vmid_int},
            )
            virtual_machine = vms[0] if vms else None
            if vm_cache is not None:
                vm_cache[vmid_int] = virtual_machine

        if not virtual_machine:
            return None

        # Process verification data
        verification = backup.get("verification", {})
        verification_state = verification.get("state")
        verification_upid = verification.get("upid")

        # Process storage and volume data
        volume_id = backup.get("volid", None)
        storage_name = storage_name_from_volume_id(volume_id)
        storage_record = find_storage_record(
            storage_index or {},
            cluster_name=cluster_name,
            storage_name=storage_name,
        )

        # Process creation time
        creation_time = None
        ctime = backup.get("ctime", None)
        if ctime:
            creation_time = datetime.fromtimestamp(ctime).isoformat()

        backup_payload = {
            "proxmox_storage": storage_record.get("id") if storage_record else None,
            "virtual_machine": virtual_machine.get("id"),
            "subtype": backup.get("subtype"),
            "creation_time": creation_time,
            "size": backup.get("size"),
            "verification_state": verification_state,
            "verification_upid": verification_upid,
            "volume_id": volume_id,
            "notes": backup.get("notes"),
            "vmid": vmid,
            "format": backup.get("format"),
        }

        netbox_backup = await rest_reconcile_async(
            nb,
            "/api/plugins/proxbox/backups/",
            lookup={"volume_id": volume_id},
            payload=backup_payload,
            schema=NetBoxBackupSyncState,
            current_normalizer=lambda record: {
                "proxmox_storage": _relation_id_or_none(record.get("proxmox_storage")),
                "virtual_machine": _relation_id_or_none(record.get("virtual_machine")),
                "subtype": record.get("subtype"),
                "creation_time": record.get("creation_time"),
                "size": record.get("size"),
                "verification_state": record.get("verification_state"),
                "verification_upid": record.get("verification_upid"),
                "volume_id": record.get("volume_id"),
                "notes": record.get("notes"),
                "vmid": record.get("vmid"),
                "format": record.get("format"),
            },
        )

        # Create a journal entry for the backup
        await rest_create_async(
            nb,
            "/api/extras/journal-entries/",
            {
                "assigned_object_type": "netbox_proxbox.vmbackup",
                "assigned_object_id": netbox_backup.id,
                "kind": "info",
                "comments": f"Backup created for VM {vmid} in storage {storage_name}",
            },
        )

        return netbox_backup

    except Exception as error:
        error_detail = getattr(error, "detail", str(error))
        error_msg = f"{type(error).__name__}: {error_detail}"
        logger.warning("Error creating NetBox backup for VM %s: %s", vmid_log, error_msg)
        return None


async def process_backups_batch(backup_tasks: list, batch_size: int = 10) -> tuple[list, int]:
    """
    Process a list of backup tasks in batches to avoid overwhelming the API.

    Returns:
        (successful_reconcile_results, failure_count) where failures are exceptions from gather.
    """
    results: list = []
    failures = 0
    for i in range(0, len(backup_tasks), batch_size):
        batch = backup_tasks[i : i + batch_size]
        batch_results = await asyncio.gather(*batch, return_exceptions=True)
        for r in batch_results:
            if isinstance(r, Exception):
                failures += 1
            elif r is not None:
                results.append(r)
    return results, failures


async def get_node_backups(
    pxs: ProxmoxSessionsDep,
    cluster_status: ClusterStatusDep,
    node: str,
    storage: str,
    netbox_session: NetBoxSessionDep,
    storage_index: dict[tuple[str, str], dict] | None = None,
    vmid: str | None = None,
) -> tuple[list, set[str]]:
    nb = netbox_session
    vm_cache: dict[int, dict | None] = {}
    """
    Get backups for a specific node and storage.

    Returns:
        (async tasks for NetBox reconcile, set of Proxmox volid strings seen on storage)
    """
    for proxmox, cluster in zip(pxs, cluster_status):
        if cluster and cluster.node_list:
            cluster_name = getattr(cluster, "name", None)
            for cluster_node in cluster.node_list:
                if cluster_node.name == node:
                    try:
                        backups = await asyncio.to_thread(
                            lambda: dump_models(
                                get_node_storage_content(
                                    proxmox,
                                    node=node,
                                    storage=storage,
                                    vmid=vmid,
                                    content="backup",
                                )
                            )
                        )

                        if vmid is not None:
                            filtered_vmid = str(vmid).strip()
                            backups = [
                                backup
                                for backup in backups
                                if str(backup.get("vmid", "")).strip() == filtered_vmid
                            ]

                        volids = _volids_from_proxmox_storage_backup_items(backups)
                        tasks = [
                            create_netbox_backups(
                                backup,
                                nb,
                                cluster_name=cluster_name,
                                storage_index=storage_index,
                                vm_cache=vm_cache,
                            )
                            for backup in backups
                            if backup.get("content") == "backup"
                        ]
                        return tasks, volids
                    except Exception as error:
                        logger.warning("Error getting backups for node %s: %s", node, error)
                        continue
    return [], set()


@router.get("/backups/create")
async def create_virtual_machine_backups(
    netbox_session: NetBoxSessionDep,
    pxs: ProxmoxSessionsDep,
    cluster_status: ClusterStatusDep,
    node: Annotated[
        str,
        Query(
            title="Node",
            description="The name of the node to retrieve the storage content for.",
        ),
    ],
    storage: Annotated[
        str,
        Query(
            title="Storage",
            description="The name of the storage to retrieve the content for.",
        ),
    ],
    vmid: Annotated[
        str | None,
        Query(title="VM ID", description="The ID of the VM to retrieve the content for."),
    ] = None,
):
    storage_index = await _load_storage_index(netbox_session)
    backup_tasks, _volids = await get_node_backups(
        pxs,
        cluster_status,
        node,
        storage,
        netbox_session=netbox_session,
        storage_index=storage_index,
        vmid=vmid,
    )
    if not backup_tasks:
        raise ProxboxException(message="Node or Storage not found.")

    reconciled, _failures = await process_backups_batch(backup_tasks)
    return reconciled


async def _create_all_virtual_machine_backups(  # noqa: C901
    netbox_session,
    pxs,
    cluster_status,
    tag,
    delete_nonexistent_backup=False,
    fetch_max_concurrency: int | None = None,
    websocket=None,
    use_websocket=False,
    vmid_filter: str | None = None,
):
    """Internal function that handles backup sync with optional websocket support.

    When ``vmid_filter`` is provided only backups belonging to that Proxmox VMID
    are fetched and synced.
    """
    nb = netbox_session
    results = []
    failure_count = 0
    deleted_count = 0
    backup_sync_ok = False
    storage_index = await _load_storage_index(nb)
    vm_cache: dict[int, dict | None] = {}

    try:
        if use_websocket and websocket:
            await websocket.send_json(
                {
                    "step": "backups",
                    "status": "started",
                    "message": "Starting backup synchronization.",
                }
            )

        all_backup_tasks = []
        proxmox_backups = set()
        discovery_tasks: list[asyncio.Task] = []
        fetch_semaphore = asyncio.Semaphore(fetch_max_concurrency or _DEFAULT_FETCH_CONCURRENCY)

        async def _discover_backups_for_node_storage(
            proxmox,
            cluster_name: str,
            node_name: str,
            storage_name: str,
        ) -> tuple[list, set[str]]:
            async with fetch_semaphore:
                _extra: dict = {}
                if vmid_filter is not None:
                    _extra["vmid"] = vmid_filter
                backups = await asyncio.to_thread(
                    lambda: dump_models(
                        get_node_storage_content(
                            proxmox,
                            node=node_name,
                            storage=storage_name,
                            content="backup",
                            **_extra,
                        )
                    )
                )
                if vmid_filter is not None:
                    filtered_vmid = str(vmid_filter).strip()
                    backups = [
                        backup
                        for backup in backups
                        if str(backup.get("vmid", "")).strip() == filtered_vmid
                    ]
                volids = _volids_from_proxmox_storage_backup_items(backups)
                tasks = [
                    create_netbox_backups(
                        backup,
                        nb,
                        cluster_name=cluster_name,
                        storage_index=storage_index,
                        vm_cache=vm_cache,
                    )
                    for backup in backups
                    if backup.get("content") == "backup"
                ]
            return tasks, volids

        for proxmox, cluster in zip(pxs, cluster_status):
            cluster_name = getattr(cluster, "name", None) if cluster else None
            storage_list = [
                {
                    "storage": storage_dict.get("storage"),
                    "nodes": storage_dict.get("nodes", "all"),
                }
                for storage_dict in proxmox.session.storage.get()
                if "backup" in storage_dict.get("content")
            ]

            if cluster and cluster.node_list:
                for cluster_node in cluster.node_list:
                    for storage in storage_list:
                        if storage.get("nodes") == "all" or cluster_node.name in storage.get(
                            "nodes", []
                        ):
                            discovery_tasks.append(
                                asyncio.create_task(
                                    _discover_backups_for_node_storage(
                                        proxmox=proxmox,
                                        cluster_name=cluster_name,
                                        node_name=cluster_node.name,
                                        storage_name=storage.get("storage"),
                                    )
                                )
                            )

        if discovery_tasks:
            discovery_results = await asyncio.gather(*discovery_tasks, return_exceptions=True)
            for result in discovery_results:
                if isinstance(result, Exception):
                    logger.warning("Backup discovery failed: %s", result, exc_info=True)
                    continue
                node_backup_tasks, node_volids = result
                all_backup_tasks.extend(node_backup_tasks)
                proxmox_backups.update(node_volids)

        if not all_backup_tasks:
            error_msg = "No backups found to process"
            if use_websocket and websocket:
                await websocket.send_json(
                    {
                        "step": "backups",
                        "status": "warning",
                        "message": error_msg,
                    }
                )
            raise ProxboxException(message=error_msg)

        if use_websocket and websocket:
            await websocket.send_json(
                {
                    "step": "backups",
                    "status": "discovered",
                    "message": f"Found {len(all_backup_tasks)} backups to process.",
                    "count": len(all_backup_tasks),
                }
            )

        results, failure_count = await process_backups_batch(all_backup_tasks)
        if failure_count:
            logger.warning("Backup batch reported %s task error(s)", failure_count)

        if delete_nonexistent_backup:
            try:
                netbox_backups = rest_list(nb, "/api/plugins/proxbox/backups/")
                skipped_no_volid = 0

                for backup in netbox_backups:
                    vid = backup.volume_id
                    if not vid:
                        skipped_no_volid += 1
                        continue
                    if vid not in proxmox_backups:
                        try:
                            backup.delete()
                            deleted_count += 1
                        except Exception:
                            logger.warning(
                                "Failed to delete backup for VM %s",
                                backup.vmid,
                                exc_info=True,
                            )

                if skipped_no_volid:
                    logger.info(
                        "Skipped %s NetBox backup(s) with empty volume_id",
                        skipped_no_volid,
                    )
            except Exception:
                logger.warning("Error during backup deletion pass", exc_info=True)

        backup_sync_ok = True

        if use_websocket and websocket and backup_sync_ok:
            await websocket.send_json(
                {
                    "step": "backups",
                    "status": "completed",
                    "message": (
                        f"Backup sync completed. {len(results)} reconciled, "
                        f"{failure_count} task error(s), {deleted_count} deleted."
                    ),
                    "result": {
                        "reconciled": len(results),
                        "failed_tasks": failure_count,
                        "deleted": deleted_count,
                    },
                }
            )

    except ProxboxException:
        raise
    except Exception as error:
        error_msg = f"Error during backup sync: {str(error)}"
        logger.error(error_msg, exc_info=True)
        if use_websocket and websocket:
            await websocket.send_json(
                {
                    "step": "backups",
                    "status": "failed",
                    "message": error_msg,
                    "error": str(error),
                }
            )
        raise ProxboxException(message=error_msg)

    logger.info("Syncing backups finished")
    return results


@router.get("/backups/all/create")
async def create_all_virtual_machine_backups(
    netbox_session: NetBoxSessionDep,
    pxs: ProxmoxSessionsDep,
    cluster_status: ClusterStatusDep,
    tag: ProxboxTagDep,
    delete_nonexistent_backup: Annotated[
        bool,
        Query(
            title="Delete Nonexistent Backup",
            description="If true, deletes backups that exist in NetBox but not in Proxmox.",
        ),
    ] = False,
    fetch_max_concurrency: Annotated[
        int | None,
        Query(
            title="Fetch max concurrency",
            description="Maximum parallel Proxmox fetch operations for backup discovery.",
            ge=1,
        ),
    ] = None,
    netbox_vm_ids: str | None = Query(
        default=None,
        title="NetBox VM IDs",
        description="Comma-separated list of NetBox VM IDs to sync. When provided, only these VMs will be synced.",
    ),
):
    vmid_filter_list = None
    vm_ids = parse_comma_separated_ints(netbox_vm_ids)
    if vm_ids:
        vmid_filter_list = await _get_proxmox_vmids_from_netbox_vm_ids(netbox_session, vm_ids)

    return await _create_all_virtual_machine_backups(
        netbox_session=netbox_session,
        pxs=pxs,
        cluster_status=cluster_status,
        tag=tag,
        delete_nonexistent_backup=delete_nonexistent_backup,
        fetch_max_concurrency=fetch_max_concurrency,
        vmid_filter=vmid_filter_list,
    )


async def _get_proxmox_vmids_from_netbox_vm_ids(
    netbox_session, netbox_vm_ids: list[int]
) -> list[int]:
    """Get Proxmox VM IDs from NetBox VM IDs."""
    if not netbox_vm_ids:
        return []

    try:
        vms = await rest_list_async(
            netbox_session,
            "/api/virtualization/virtual-machines/",
            query={"id": ",".join(str(vid) for vid in netbox_vm_ids)},
        )
        proxmox_vmids: list[int] = []
        if vms and isinstance(vms, list):
            for vm in vms:
                if not isinstance(vm, dict):
                    continue
                cf = vm.get("custom_fields", {}) or {}
                raw_vmid = cf.get("proxmox_vm_id")
                if raw_vmid is not None and str(raw_vmid).strip().isdigit():
                    proxmox_vmids.append(int(str(raw_vmid).strip()))
        return proxmox_vmids
    except Exception:
        return []


@router.get("/backups/all/create/stream", response_model=None)
async def create_all_virtual_machine_backups_stream(
    netbox_session: NetBoxSessionDep,
    pxs: ProxmoxSessionsDep,
    cluster_status: ClusterStatusDep,
    tag: ProxboxTagDep,
    delete_nonexistent_backup: Annotated[
        bool,
        Query(
            title="Delete Nonexistent Backup",
            description="If true, deletes backups that exist in NetBox but not in Proxmox.",
        ),
    ] = False,
    fetch_max_concurrency: Annotated[
        int | None,
        Query(
            title="Fetch max concurrency",
            description="Maximum parallel Proxmox fetch operations for backup discovery.",
            ge=1,
        ),
    ] = None,
    netbox_vm_ids: str | None = Query(
        default=None,
        title="NetBox VM IDs",
        description="Comma-separated list of NetBox VM IDs to sync. When provided, only these VMs will be synced.",
    ),
):
    vmid_filter_list = None
    vm_ids = parse_comma_separated_ints(netbox_vm_ids)
    if vm_ids:
        vmid_filter_list = await _get_proxmox_vmids_from_netbox_vm_ids(netbox_session, vm_ids)

    async def event_stream():
        bridge = WebSocketSSEBridge()

        async def _run_sync():
            try:
                return await _create_all_virtual_machine_backups(
                    netbox_session=netbox_session,
                    pxs=pxs,
                    cluster_status=cluster_status,
                    tag=tag,
                    delete_nonexistent_backup=delete_nonexistent_backup,
                    fetch_max_concurrency=fetch_max_concurrency,
                    vmid_filter=vmid_filter_list,
                    websocket=bridge,
                    use_websocket=True,
                )
            finally:
                await bridge.close()

        sync_task = asyncio.create_task(_run_sync())
        try:
            yield sse_event(
                "step",
                {
                    "step": "backups",
                    "status": "started",
                    "message": "Starting backup synchronization.",
                },
            )
            async for frame in bridge.iter_sse():
                yield frame
            result = await sync_task
            yield sse_event(
                "step",
                {
                    "step": "backups",
                    "status": "completed",
                    "message": "Backup synchronization finished.",
                    "result": {"count": len(result) if result else 0},
                },
            )
            yield sse_event(
                "complete",
                {
                    "ok": True,
                    "message": "Backup sync completed.",
                    "result": {"count": len(result) if result else 0},
                },
            )
        except Exception as error:
            yield sse_event(
                "error",
                {
                    "step": "backups",
                    "status": "failed",
                    "error": str(error),
                    "detail": str(error),
                },
            )
            yield sse_event(
                "complete",
                {
                    "ok": False,
                    "message": "Backup sync failed.",
                    "errors": [{"detail": str(error)}],
                },
            )

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


@router.get("/{netbox_vm_id}/backups/create/stream", response_model=None)
async def create_virtual_machine_backups_by_id_stream(
    netbox_vm_id: int,
    netbox_session: NetBoxSessionDep,
    pxs: ProxmoxSessionsDep,
    cluster_status: ClusterStatusDep,
    tag: ProxboxTagDep,
    delete_nonexistent_backup: Annotated[
        bool,
        Query(
            title="Delete Nonexistent Backup",
            description="If true, deletes backups that exist in NetBox but not in Proxmox.",
        ),
    ] = False,
    fetch_max_concurrency: Annotated[
        int | None,
        Query(
            title="Fetch max concurrency",
            description="Maximum parallel Proxmox fetch operations for backup discovery.",
            ge=1,
        ),
    ] = None,
):
    """Sync backups for a single NetBox VM identified by its primary key."""
    vm_record = await asyncio.to_thread(
        lambda: netbox_session.virtualization.virtual_machines.get(id=netbox_vm_id)
    )
    if vm_record is None:
        raise HTTPException(
            status_code=404,
            detail=f"Virtual machine id={netbox_vm_id} was not found in NetBox.",
        )

    vm_data = (
        vm_record
        if isinstance(vm_record, dict)
        else (vm_record.serialize() if hasattr(vm_record, "serialize") else dict(vm_record))
    )
    cf = vm_data.get("custom_fields") or {}
    raw_vmid = cf.get("proxmox_vm_id")
    proxmox_vmid: str | None = None
    if raw_vmid is not None:
        stripped = str(raw_vmid).strip()
        if stripped.isdigit():
            proxmox_vmid = stripped

    if proxmox_vmid is None:
        raise HTTPException(
            status_code=422,
            detail=(
                f"Virtual machine id={netbox_vm_id} has no proxmox_vm_id custom field set; "
                "cannot filter backups."
            ),
        )

    async def event_stream():
        bridge = WebSocketSSEBridge()

        async def _run_sync():
            try:
                return await _create_all_virtual_machine_backups(
                    netbox_session=netbox_session,
                    pxs=pxs,
                    cluster_status=cluster_status,
                    tag=tag,
                    delete_nonexistent_backup=delete_nonexistent_backup,
                    fetch_max_concurrency=fetch_max_concurrency,
                    websocket=bridge,
                    use_websocket=True,
                    vmid_filter=proxmox_vmid,
                )
            finally:
                await bridge.close()

        sync_task = asyncio.create_task(_run_sync())
        try:
            yield sse_event(
                "step",
                {
                    "step": "backups",
                    "status": "started",
                    "message": f"Starting backup sync for VM id={netbox_vm_id}.",
                },
            )
            async for frame in bridge.iter_sse():
                yield frame
            result = await sync_task
            yield sse_event(
                "step",
                {
                    "step": "backups",
                    "status": "completed",
                    "message": "Backup synchronization finished.",
                    "result": {"count": len(result) if result else 0},
                },
            )
            yield sse_event(
                "complete",
                {
                    "ok": True,
                    "message": "Backup sync completed.",
                    "result": {"count": len(result) if result else 0},
                },
            )
        except Exception as error:
            yield sse_event(
                "error",
                {
                    "step": "backups",
                    "status": "failed",
                    "error": str(error),
                    "detail": str(error),
                },
            )
            yield sse_event(
                "complete",
                {
                    "ok": False,
                    "message": "Backup sync failed.",
                    "errors": [{"detail": str(error)}],
                },
            )

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )
