"""
Backwards-compatible import shim.

The SDK uses AuditLog(db_path) directly — this keeps that interface working
while the real implementation lives in autopil.db.sqlite.
"""

from autopil.db.sqlite import SQLiteAuditLog as AuditLog

__all__ = ["AuditLog"]
