"""
AutoPIL OpenAIAgentsGuard — context governance for OpenAI Agents SDK.

Integrates AutoPIL's policy enforcement, audit logging, and lineage tracking
with agents built on the OpenAI Agents SDK (openai-agents).

Two integration patterns:

1. Decorator pattern — wraps individual tool functions:

       from autopil.openai_agents_guard import OpenAIAgentsGuard, SensitivityLevel

       guard = OpenAIAgentsGuard(policy_path="policies/", audit_db="autopil.db")

       @guard.protect(
           agent_role="support_agent",
           user_id="agent_01",
           source_id="customer_records",
           sensitivity_level=SensitivityLevel.HIGH,
           session_id=SESSION_ID,
       )
       def lookup_customer(customer_id: str) -> dict:
           return crm.fetch(customer_id)

   Register with the OpenAI Agents SDK:
       from agents import function_tool

       @function_tool
       def lookup_customer_tool(customer_id: str) -> str:
           result = lookup_customer(customer_id)   # AutoPIL enforces here
           return str(result)

2. guarded_function_tool helper — combines @function_tool + @guard.protect():

       from autopil.openai_agents_guard import OpenAIAgentsGuard

       guard = OpenAIAgentsGuard(policy_path="policies/", audit_db="autopil.db")

       @guard.function_tool(
           agent_role="support_agent",
           user_id="agent_01",
           source_id="customer_records",
           sensitivity_level=SensitivityLevel.HIGH,
           session_id=SESSION_ID,
       )
       def lookup_customer(customer_id: str) -> dict:
           return crm.fetch(customer_id)

       # lookup_customer is now a fully guarded OpenAI Agents function_tool.
       # Pass it directly to Agent(tools=[lookup_customer]).

All decisions are stamped source_type='openai_agents' in the audit log.
"""

from __future__ import annotations

from functools import wraps
from typing import Any, Callable, Optional

from .guard import ContextGuard
from .models import SensitivityLevel


class OpenAIAgentsGuard(ContextGuard):
    """
    AutoPIL ContextGuard for OpenAI Agents SDK.

    Drop-in replacement for ContextGuard that tags every audit event
    with source_type='openai_agents'.

    Usage:
        from autopil.openai_agents_guard import OpenAIAgentsGuard

        guard = OpenAIAgentsGuard(policy_path="policies/", audit_db="autopil.db")

        @guard.protect(
            agent_role="support_agent",
            user_id="u1",
            source_id="customer_records",
        )
        def lookup_customer(customer_id: str) -> dict:
            return crm.fetch(customer_id)

    Session TTL — set at the guard level, applies to all protect() calls:
        guard = OpenAIAgentsGuard(policy_path="policies/", audit_db="autopil.db",
                                  session_ttl_minutes=60)
    """

    _source_type: str = "openai_agents"

    def function_tool(
        self,
        *,
        agent_role: str,
        user_id: str,
        source_id: str,
        sensitivity_level: SensitivityLevel = SensitivityLevel.MEDIUM,
        session_id: Optional[str] = None,
    ) -> Callable:
        """
        Decorator that combines AutoPIL policy enforcement with the OpenAI
        Agents SDK @function_tool decorator.

        Requires: pip install openai-agents

        The decorated function is both policy-guarded (AutoPIL) and registered
        as a function tool (OpenAI Agents SDK). Pass it directly to Agent(tools=[...]).

        Raises PermissionError at call time on DENY.

        Args:
            agent_role:        The agent's declared role.
            user_id:           Identifier for the invoking user or agent.
            source_id:         The data source being requested.
            sensitivity_level: Data sensitivity level.
            session_id:        Session identifier (auto-generated if omitted).

        Example:
            @guard.function_tool(
                agent_role="support_agent",
                user_id="u1",
                source_id="customer_records",
                sensitivity_level=SensitivityLevel.HIGH,
            )
            def lookup_customer(customer_id: str) -> dict:
                return crm.fetch(customer_id)

            agent = Agent(name="Support", tools=[lookup_customer])
        """
        try:
            from agents import function_tool as openai_function_tool
        except ImportError as exc:
            raise ImportError(
                "OpenAI Agents SDK not installed.\n"
                "Install with: pip install openai-agents"
            ) from exc

        def decorator(fn: Callable) -> Any:
            # First wrap with AutoPIL policy enforcement
            protected = self.protect(
                agent_role=agent_role,
                user_id=user_id,
                source_id=source_id,
                sensitivity_level=sensitivity_level,
                session_id=session_id,
            )(fn)

            # Then register as an OpenAI Agents function_tool
            @openai_function_tool
            @wraps(fn)
            def tool_fn(*args: Any, **kwargs: Any) -> Any:
                return protected(*args, **kwargs)

            return tool_fn

        return decorator
