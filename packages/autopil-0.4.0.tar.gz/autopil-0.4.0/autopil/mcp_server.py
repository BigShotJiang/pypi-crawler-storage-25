"""
AutoPIL MCP Server — context governance for autonomous agents via Model Context Protocol.

Exposes AutoPIL's policy enforcement, audit log, and lineage tracking as MCP tools
that any MCP-compatible agent (Claude, GPT-4, Gemini, etc.) can call natively.

Two integration patterns:

1. Pre-check pattern (recommended):
   Agent calls `evaluate_context` before every retrieval. If ALLOW, proceeds.
   If DENY, stops and surfaces the reason. Zero changes to retrieval code.

2. Audit-only pattern:
   Agent calls `record_action` after each retrieval to build a lineage trail,
   and queries `get_audit_stats` / `query_audit_log` for governance reporting.

Usage:
    python mcp_serve.py --policy policies/ --db autopil.db

Claude Desktop config (claude_desktop_config.json):
    {
      "mcpServers": {
        "autopil": {
          "command": "python",
          "args": ["/path/to/mcp_serve.py", "--policy", "policies/", "--db", "autopil.db"]
        }
      }
    }
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime
from typing import Any

try:
    import mcp.server.stdio
    from mcp.server import Server
    from mcp.types import TextContent, Tool
except ImportError as exc:
    raise ImportError(
        "MCP server dependencies not installed.\n"
        "Install with: pip install autopil[mcp]"
    ) from exc

from .db import create_stores
from .models import AuditEvent, Decision, SensitivityLevel
from .policy_engine import PolicyEngine
from . import telemetry

# ── Tool name constants ───────────────────────────────────────────────────────
TOOL_EVALUATE        = "evaluate_context"
TOOL_AUDIT_QUERY     = "query_audit_log"
TOOL_AUDIT_STATS     = "get_audit_stats"
TOOL_LIST_POLICIES   = "list_policies"
TOOL_RECORD_ACTION   = "record_action"
TOOL_RELOAD_POLICIES = "reload_policies"
TOOL_SESSION_STATUS  = "get_session_status"

ALL_TOOLS = [
    TOOL_EVALUATE,
    TOOL_AUDIT_QUERY,
    TOOL_AUDIT_STATS,
    TOOL_LIST_POLICIES,
    TOOL_RECORD_ACTION,
    TOOL_RELOAD_POLICIES,
    TOOL_SESSION_STATUS,
]

# ─────────────────────────────────────────────────────────────────────────────
# dispatch_tool — all tool logic lives here, testable without MCP transport
# ─────────────────────────────────────────────────────────────────────────────

async def dispatch_tool(
    *,
    name: str,
    arguments: dict,
    audit_log: Any,
    lineage_store: Any,
    state: dict[str, Any],
    policy_path: str,
    tenant_id: str,
) -> list[TextContent]:
    """
    Core tool dispatch logic, decoupled from the MCP server wiring.

    Called by the @server.call_tool() handler and directly by tests.
    Returns a list[TextContent] matching the MCP tool response contract.
    """

    def _text(msg: str) -> list[TextContent]:
        return [TextContent(type="text", text=msg)]

    def _error(msg: str) -> list[TextContent]:
        return _text(f"❌ Error: {msg}")

    # ── evaluate_context ──────────────────────────────────────────────────────
    if name == TOOL_EVALUATE:
        agent_role      = arguments["agent_role"]
        user_id         = arguments["user_id"]
        source_id       = arguments["source_id"]
        sensitivity_str = arguments["sensitivity_level"]
        session_id      = arguments["session_id"]
        task_type       = arguments.get("task_type")
        query           = arguments.get("query", "")

        try:
            sensitivity = SensitivityLevel(sensitivity_str)
        except ValueError:
            return _error(
                f"Invalid sensitivity_level '{sensitivity_str}'. "
                "Must be one of: low, medium, high, restricted."
            )

        from .models import ContextRequest
        request = ContextRequest(
            query=query,
            agent_role=agent_role,
            user_id=user_id,
            source_id=source_id,
            sensitivity_level=sensitivity,
            session_id=session_id,
            task_type=task_type,
        )

        # Cross-agent session isolation
        owner = audit_log.get_session_owner(session_id, tenant_id)
        if owner and owner != agent_role:
            decision    = Decision.DENY
            policy_name = "cross_agent_isolation"
            reason      = (
                f"Session '{session_id[:8]}…' is owned by '{owner}'. "
                f"Agent '{agent_role}' cannot access another agent's session context."
            )
        else:
            decision, policy_name, reason = state["engine"].evaluate(request)

        event_id = str(uuid.uuid4())
        audit_log.record(
            AuditEvent(
                event_id=event_id,
                session_id=session_id,
                agent_role=agent_role,
                user_id=user_id,
                source_id=source_id,
                query=query,
                decision=decision,
                policy_name=policy_name,
                reason=reason,
                timestamp=datetime.utcnow(),
                context_hash=None,
                sensitivity_level=sensitivity.value,
                source_type="mcp",
            ),
            tenant_id=tenant_id,
        )

        result = {
            "decision":    decision.value,
            "policy_name": policy_name,
            "reason":      reason,
            "event_id":    event_id,
            "session_id":  session_id,
            "agent_role":  agent_role,
            "source_id":   source_id,
        }

        if decision == Decision.ALLOW:
            message = (
                f"✅ ALLOW — {agent_role} may access '{source_id}'.\n"
                f"Policy: {policy_name}\n"
                f"Event ID: {event_id} (pass to record_action to log what you do with the data)"
            )
        else:
            message = (
                f"🚫 DENY — {agent_role} is not permitted to access '{source_id}'.\n"
                f"Reason: {reason}\n"
                f"Policy: {policy_name}\n"
                f"Do not proceed with this retrieval. Inform the user that access is not permitted."
            )

        return _text(f"{message}\n\n{json.dumps(result, indent=2)}")

    # ── query_audit_log ───────────────────────────────────────────────────────
    elif name == TOOL_AUDIT_QUERY:
        limit       = min(int(arguments.get("limit", 20)), 200)
        role_filter = arguments.get("agent_role")
        dec_filter  = arguments.get("decision")
        sid_filter  = arguments.get("session_id")

        events = (
            audit_log.get_session_events(sid_filter, tenant_id)
            if sid_filter
            else audit_log.get_all_events(tenant_id)
        )
        if role_filter:
            events = [e for e in events if e.agent_role == role_filter]
        if dec_filter:
            events = [e for e in events if e.decision.value == dec_filter]
        events = events[-limit:]

        rows = [
            {
                "event_id":    e.event_id,
                "timestamp":   e.timestamp.isoformat(),
                "agent_role":  e.agent_role,
                "source_id":   e.source_id,
                "decision":    e.decision.value,
                "policy_name": e.policy_name,
                "reason":      e.reason,
                "session_id":  e.session_id,
            }
            for e in events
        ]

        summary = (
            f"Found {len(rows)} audit event(s)"
            + (f" for role '{role_filter}'" if role_filter else "")
            + (f" with decision {dec_filter}" if dec_filter else "")
            + "."
        )
        return _text(f"{summary}\n\n{json.dumps(rows, indent=2)}")

    # ── get_audit_stats ───────────────────────────────────────────────────────
    elif name == TOOL_AUDIT_STATS:
        events  = audit_log.get_all_events(tenant_id)
        total   = len(events)
        allowed = sum(1 for e in events if e.decision == Decision.ALLOW)
        denied  = total - allowed
        deny_rate = round(denied / total * 100, 1) if total else 0.0

        role_counts: dict[str, int] = {}
        for e in events:
            role_counts[e.agent_role] = role_counts.get(e.agent_role, 0) + 1
        top_roles = sorted(role_counts.items(), key=lambda x: x[1], reverse=True)[:5]

        stats = {
            "total_events":    total,
            "allowed":         allowed,
            "denied":          denied,
            "deny_rate_pct":   deny_rate,
            "top_agent_roles": [{"role": r, "events": c} for r, c in top_roles],
        }
        summary = (
            f"Audit summary: {total} total events, "
            f"{allowed} allowed ({100 - deny_rate:.1f}%), "
            f"{denied} denied ({deny_rate}%)."
        )
        return _text(f"{summary}\n\n{json.dumps(stats, indent=2)}")

    # ── list_policies ─────────────────────────────────────────────────────────
    elif name == TOOL_LIST_POLICIES:
        industry_filter = arguments.get("industry")
        role_filter     = arguments.get("agent_role")

        policies = state["engine"].policies
        if industry_filter:
            policies = [p for p in policies if p.get("industry") == industry_filter]
        if role_filter:
            policies = [p for p in policies if p.get("agent_role") == role_filter]

        rows = [
            {
                "name":            p.get("name"),
                "agent_role":      p.get("agent_role"),
                "industry":        p.get("industry"),
                "category":        p.get("category"),
                "allowed_sources": p.get("allowed_sources", []),
                "denied_sources":  p.get("denied_sources", []),
                "allowed_tasks":   p.get("allowed_tasks", []),
                "denied_tasks":    p.get("denied_tasks", []),
                "max_sensitivity": p.get("max_sensitivity"),
            }
            for p in policies
        ]

        summary = f"{len(rows)} active polic{'y' if len(rows) == 1 else 'ies'} loaded."
        return _text(f"{summary}\n\n{json.dumps(rows, indent=2)}")

    # ── record_action ─────────────────────────────────────────────────────────
    elif name == TOOL_RECORD_ACTION:
        event_id    = arguments["event_id"]
        action_type = arguments["action_type"]
        detail      = arguments.get("detail", {})
        outcome     = arguments.get("outcome")

        all_events = audit_log.get_all_events(tenant_id)
        event = next((e for e in all_events if e.event_id == event_id), None)
        if event is None:
            return _error(
                f"No audit event found with event_id='{event_id}'. "
                "Pass the event_id returned by evaluate_context."
            )

        from .models import AgentAction
        action = AgentAction(
            action_id=str(uuid.uuid4()),
            event_id=event_id,
            session_id=event.session_id,
            agent_role=event.agent_role,
            action_type=action_type,
            action_detail=detail,
            outcome=outcome,
            timestamp=datetime.utcnow(),
        )
        lineage_store.record_action(action, tenant_id)

        result = {
            "action_id":   action.action_id,
            "event_id":    event_id,
            "agent_role":  event.agent_role,
            "action_type": action_type,
            "outcome":     outcome,
        }
        return _text(f"✅ Action recorded. Provenance trail updated.\n\n{json.dumps(result, indent=2)}")

    # ── reload_policies ───────────────────────────────────────────────────────
    elif name == TOOL_RELOAD_POLICIES:
        state["engine"] = PolicyEngine(policy_path)
        count = len(state["engine"].policies)
        return _text(
            f"✅ Policies reloaded from '{policy_path}'. "
            f"{count} polic{'y' if count == 1 else 'ies'} active."
        )

    # ── get_session_status ────────────────────────────────────────────────────
    elif name == TOOL_SESSION_STATUS:
        session_id = arguments["session_id"]
        events = audit_log.get_session_events(session_id, tenant_id)

        if not events:
            return _error(f"No events found for session_id='{session_id}'.")

        owner   = events[0].agent_role
        total   = len(events)
        allowed = sum(1 for e in events if e.decision == Decision.ALLOW)
        denied  = total - allowed
        sources = list({e.source_id for e in events})

        status = {
            "session_id":       session_id,
            "owner_role":       owner,
            "total_events":     total,
            "allowed":          allowed,
            "denied":           denied,
            "sources_accessed": sources,
            "first_event":      events[0].timestamp.isoformat(),
            "last_event":       events[-1].timestamp.isoformat(),
        }
        summary = (
            f"Session '{session_id[:12]}…' owned by '{owner}'. "
            f"{total} events ({allowed} allowed, {denied} denied) "
            f"across {len(sources)} source(s)."
        )
        return _text(f"{summary}\n\n{json.dumps(status, indent=2)}")

    else:
        return _error(f"Unknown tool: '{name}'")


# ─────────────────────────────────────────────────────────────────────────────
# create_mcp_server — wires dispatch_tool into the MCP Server
# ─────────────────────────────────────────────────────────────────────────────

def create_mcp_server(
    policy_path: str,
    audit_db: str = "autopil_audit.db",
    database_url: str | None = None,
    tenant_id: str = "default",
) -> Server:
    """
    Build and return a configured MCP Server instance.

    Args:
        policy_path:  Path to policy YAML file or directory.
        audit_db:     SQLite DB path (ignored if database_url is set).
        database_url: Postgres connection string (optional).
        tenant_id:    Tenant scope for all operations.
    """
    server = Server("autopil")

    stores = create_stores(database_url=database_url, db_path=audit_db)
    audit_log, _, _, _, _, lineage_store, _ = stores
    engine = PolicyEngine(policy_path)
    state: dict[str, Any] = {"engine": engine}

    telemetry.setup()

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        return [
            Tool(
                name=TOOL_EVALUATE,
                description=(
                    "Evaluate whether an agent is permitted to access a data source. "
                    "Call this BEFORE every retrieval. Returns ALLOW or DENY with the "
                    "matched policy name and reason. All decisions are audit-logged."
                ),
                inputSchema={
                    "type": "object",
                    "required": ["agent_role", "user_id", "source_id", "sensitivity_level", "session_id"],
                    "properties": {
                        "agent_role":        {"type": "string"},
                        "user_id":           {"type": "string"},
                        "source_id":         {"type": "string"},
                        "sensitivity_level": {"type": "string", "enum": ["low", "medium", "high", "restricted"]},
                        "session_id":        {"type": "string"},
                        "task_type":         {"type": "string"},
                        "query":             {"type": "string"},
                    },
                },
            ),
            Tool(
                name=TOOL_AUDIT_QUERY,
                description="Query the immutable audit log. Filter by role, decision, or session.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "limit":      {"type": "integer", "default": 20},
                        "agent_role": {"type": "string"},
                        "decision":   {"type": "string", "enum": ["ALLOW", "DENY"]},
                        "session_id": {"type": "string"},
                    },
                },
            ),
            Tool(
                name=TOOL_AUDIT_STATS,
                description="Get aggregate audit stats: totals, deny rate, top agent roles.",
                inputSchema={"type": "object", "properties": {}},
            ),
            Tool(
                name=TOOL_LIST_POLICIES,
                description="List active governance policies. Filter by industry or agent_role.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "industry":   {"type": "string"},
                        "agent_role": {"type": "string"},
                    },
                },
            ),
            Tool(
                name=TOOL_RECORD_ACTION,
                description=(
                    "Record what the agent did with retrieved context. Links a downstream "
                    "action to the audit event that authorized the retrieval."
                ),
                inputSchema={
                    "type": "object",
                    "required": ["event_id", "action_type", "detail"],
                    "properties": {
                        "event_id":    {"type": "string"},
                        "action_type": {"type": "string"},
                        "detail":      {"type": "object"},
                        "outcome":     {"type": "string"},
                    },
                },
            ),
            Tool(
                name=TOOL_RELOAD_POLICIES,
                description="Reload all policies from disk without restarting the server.",
                inputSchema={"type": "object", "properties": {}},
            ),
            Tool(
                name=TOOL_SESSION_STATUS,
                description="Get governance status of a session: owner, event count, sources accessed.",
                inputSchema={
                    "type": "object",
                    "required": ["session_id"],
                    "properties": {"session_id": {"type": "string"}},
                },
            ),
        ]

    @server.call_tool()
    async def call_tool(name: str, arguments: dict) -> list[TextContent]:
        return await dispatch_tool(
            name=name,
            arguments=arguments,
            audit_log=audit_log,
            lineage_store=lineage_store,
            state=state,
            policy_path=policy_path,
            tenant_id=tenant_id,
        )

    return server


# ─────────────────────────────────────────────────────────────────────────────
# Entry points
# ─────────────────────────────────────────────────────────────────────────────

def _cli_main() -> None:
    """Console script entry point (autopil-mcp)."""
    import sys
    sys.path.insert(0, str(__file__).replace("/autopil/mcp_server.py", ""))
    import mcp_serve  # type: ignore[import]
    mcp_serve.main()


async def run_stdio_server(
    policy_path: str,
    audit_db: str = "autopil_audit.db",
    database_url: str | None = None,
    tenant_id: str = "default",
) -> None:
    """Run the MCP server over stdio (Claude Desktop and most MCP clients)."""
    server = create_mcp_server(
        policy_path=policy_path,
        audit_db=audit_db,
        database_url=database_url,
        tenant_id=tenant_id,
    )
    async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )
