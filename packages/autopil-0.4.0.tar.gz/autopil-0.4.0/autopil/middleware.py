"""
AutoPIL ASGI Middleware — governance at the API layer.

Intercepts HTTP requests to configured URL patterns and enforces AutoPIL
policy BEFORE the request reaches any route handler. Platform teams can
mandate governance across entire services without touching individual
agent codebases.

Integration (FastAPI / Starlette):

    from autopil.guard import ContextGuard
    from autopil.middleware import AutoPILMiddleware, RouteRule
    from autopil.models import SensitivityLevel

    guard = ContextGuard(policy_path="policies/", audit_db="autopil.db")

    app.add_middleware(
        AutoPILMiddleware,
        guard=guard,
        rules=[
            # Static source_id
            RouteRule(
                path_pattern="/api/retrieve",
                agent_role="data_analyst",
                source_id="account_summaries",
                sensitivity_level=SensitivityLevel.MEDIUM,
            ),
            # Dynamic source_id from URL path parameter
            RouteRule(
                path_pattern="/api/retrieve/{source}",
                agent_role="data_analyst",
                source_id="{source}",
            ),
            # Restrict to specific HTTP methods
            RouteRule(
                path_pattern="/api/search",
                agent_role="search_agent",
                source_id="search_index",
                methods={"GET", "POST"},
            ),
        ],
    )

Behaviour:
  ALLOW  → injects X-AutoPIL-* response headers, passes request to handler.
  DENY   → returns 403 JSON immediately (default).
  DENY + on_deny="log" → shadow mode: records DENY audit event but lets
           the request through. Use this to measure policy impact before
           enabling enforcement.

All events are stamped source_type='api' regardless of which ContextGuard
subclass is used.

Response headers injected on every matched request:
  X-AutoPIL-Decision    ALLOW | DENY
  X-AutoPIL-Event-ID    UUID of the audit event
  X-AutoPIL-Policy      Matched policy name
  X-AutoPIL-Session-ID  Session identifier

403 JSON body (on DENY + block mode):
  {
    "error":       "access_denied",
    "decision":    "DENY",
    "source_id":   "...",
    "agent_role":  "...",
    "policy_name": "...",
    "reason":      "...",
    "event_id":    "...",
    "session_id":  "..."
  }
"""

from __future__ import annotations

import dataclasses
import json
import re
import uuid
from typing import Any, Callable, Iterable
from urllib.parse import parse_qs

from .guard import ContextGuard
from .models import Decision, SensitivityLevel


# ── route rule ────────────────────────────────────────────────────────────────

@dataclasses.dataclass
class RouteRule:
    """
    Governance rule for a URL path pattern.

    path_pattern supports:
      - Exact path:        "/api/retrieve"
      - Path parameters:   "/api/retrieve/{source_id}"
      - Segment wildcard:  "/api/*"   (matches one path segment)
      - Full wildcard:     "/api/**"  (matches anything after /api/)

    source_id supports:
      - Static string:     "account_summaries"
      - Path param ref:    "{source_id}"  (resolved from matched path parameter)

    Context extraction (applied to each matched request):
      user_id_header    — HTTP header containing the user/agent identifier.
                          Falls back to "anonymous" if absent.
      session_id_header — HTTP header containing the session identifier.
                          Auto-generated UUID if absent.
      query_param       — Query string parameter containing the retrieval query.
                          Falls back to the request path if absent.
      query_body_field  — JSON body field for the retrieval query. When set,
                          the middleware buffers the request body to read it.
                          Overrides query_param when present in the body.
    """
    path_pattern:      str
    agent_role:        str
    source_id:         str
    sensitivity_level: SensitivityLevel = SensitivityLevel.MEDIUM
    methods:           frozenset | None = None  # None = all HTTP methods
    user_id_header:    str              = "X-User-ID"
    session_id_header: str              = "X-Session-ID"
    query_param:       str              = "q"
    query_body_field:  str | None       = None


# ── middleware ────────────────────────────────────────────────────────────────

class AutoPILMiddleware:
    """
    ASGI middleware that enforces AutoPIL governance at the API layer.

    Works with FastAPI, Starlette, and any ASGI-compatible framework.
    Non-HTTP scopes (WebSocket, lifespan) are always passed through unchanged.

    Args:
        app:      The downstream ASGI application.
        guard:    A ContextGuard (or subclass) instance.
        rules:    Ordered list of RouteRule objects. First match wins.
        on_deny:  "block" (default) — return 403 on DENY.
                  "log"   (shadow)  — record DENY in audit log but let
                                      the request through.
    """

    def __init__(
        self,
        app: Any,
        *,
        guard: ContextGuard,
        rules: list[RouteRule],
        on_deny: str = "block",
    ) -> None:
        self.app     = app
        self.guard   = guard
        self.on_deny = on_deny
        # Pre-compile path patterns to avoid regex overhead per request
        self._compiled: list[tuple[re.Pattern, RouteRule]] = [
            (_compile_pattern(rule.path_pattern), rule)
            for rule in rules
        ]

    async def __call__(self, scope: dict, receive: Callable, send: Callable) -> None:
        # Only intercept HTTP requests
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        path   = scope.get("path", "")
        method = scope.get("method", "GET").upper()

        rule, path_params = self._match(path, method)
        if rule is None:
            await self.app(scope, receive, send)
            return

        # ── extract context from the request ──────────────────────────────

        raw_headers = {
            k.decode("latin-1").lower(): v.decode("latin-1")
            for k, v in scope.get("headers", [])
        }
        qs_params  = parse_qs(scope.get("query_string", b"").decode())

        user_id    = raw_headers.get(rule.user_id_header.lower(), "anonymous")
        session_id = raw_headers.get(rule.session_id_header.lower(), "") or str(uuid.uuid4())
        query      = qs_params.get(rule.query_param, [""])[0]

        # Optional: read JSON body for query extraction (buffers body)
        replay_receive = receive
        if rule.query_body_field:
            body_bytes, replay_receive = await _buffer_body(receive)
            try:
                body_json = json.loads(body_bytes)
                query = body_json.get(rule.query_body_field, query)
            except (json.JSONDecodeError, AttributeError, UnicodeDecodeError):
                pass

        # Resolve source_id (static string or "{param}" reference)
        source_id = _resolve_source_id(rule.source_id, path_params)

        # Fall back to request path when no explicit query was provided
        effective_query = query or path

        # ── policy evaluation ─────────────────────────────────────────────

        decision, policy_name, reason = self.guard._evaluate_request(
            agent_role=rule.agent_role,
            user_id=user_id,
            source_id=source_id,
            sensitivity_level=rule.sensitivity_level,
            sid=session_id,
            query=effective_query,
        )

        # ── audit logging ─────────────────────────────────────────────────
        # Pre-generate event_id so it can be included in response headers
        # and the 403 body before the downstream handler runs.

        event_id = str(uuid.uuid4())
        self.guard._record_event(
            event_id=event_id,
            agent_role=rule.agent_role,
            user_id=user_id,
            source_id=source_id,
            query=effective_query,
            decision=decision,
            policy_name=policy_name,
            reason=reason,
            sensitivity_level=rule.sensitivity_level,
            sid=session_id,
            context_hash=None,
            source_type="api",
        )

        # ── deny path ─────────────────────────────────────────────────────

        if decision == Decision.DENY and self.on_deny == "block":
            await _send_deny_response(send, {
                "error":       "access_denied",
                "decision":    "DENY",
                "source_id":   source_id,
                "agent_role":  rule.agent_role,
                "policy_name": policy_name,
                "reason":      reason,
                "event_id":    event_id,
                "session_id":  session_id,
            })
            return

        # ── allow path (or shadow log mode) ──────────────────────────────
        # Inject X-AutoPIL-* headers into the downstream response.

        autopil_headers = [
            (b"x-autopil-decision",    decision.value.encode()),
            (b"x-autopil-event-id",    event_id.encode()),
            (b"x-autopil-policy",      policy_name.encode()),
            (b"x-autopil-session-id",  session_id.encode()),
        ]

        async def send_with_headers(message: dict) -> None:
            if message["type"] == "http.response.start":
                existing = list(message.get("headers", []))
                message  = {**message, "headers": existing + autopil_headers}
            await send(message)

        await self.app(scope, replay_receive, send_with_headers)

    def _match(self, path: str, method: str) -> tuple[RouteRule | None, dict]:
        """Return the first matching RouteRule and its extracted path parameters."""
        for pattern, rule in self._compiled:
            if rule.methods and method not in rule.methods:
                continue
            m = pattern.match(path)
            if m:
                return rule, m.groupdict()
        return None, {}


# ── internal helpers ──────────────────────────────────────────────────────────

def _compile_pattern(path_pattern: str) -> re.Pattern:
    """
    Compile a path pattern string to a regex.

    Conversion rules:
      {param}  →  (?P<param>[^/]+)  (named capture, one path segment)
      **       →  .*                (matches anything including slashes)
      *        →  [^/]*             (matches one path segment, no slashes)
      other    →  re.escape(other)
    """
    # Split on tokens: {param}, **, or *
    tokens = re.split(r'(\{[^}]+\}|\*\*|\*)', path_pattern)
    parts  = []
    for tok in tokens:
        if tok.startswith('{') and tok.endswith('}'):
            param_name = tok[1:-1]
            parts.append(f'(?P<{param_name}>[^/]+)')
        elif tok == '**':
            parts.append('.*')
        elif tok == '*':
            parts.append('[^/]*')
        else:
            parts.append(re.escape(tok))
    return re.compile('^' + ''.join(parts) + '$')


def _resolve_source_id(template: str, path_params: dict) -> str:
    """Replace {param} references in source_id template with actual path values."""
    def _sub(m: re.Match) -> str:
        return path_params.get(m.group(1), m.group(0))
    return re.sub(r'\{(\w+)\}', _sub, template)


async def _buffer_body(receive: Callable) -> tuple[bytes, Callable]:
    """
    Consume and buffer the full ASGI request body.

    Returns (body_bytes, replay_receive) where replay_receive is a new
    receive callable that re-emits the buffered messages so the downstream
    handler can still read the body.
    """
    messages: list[dict] = []
    while True:
        msg = await receive()
        messages.append(msg)
        if not msg.get("more_body", False):
            break
    body = b"".join(m.get("body", b"") for m in messages)

    # Build a stateful replay callable
    state = {"index": 0}

    async def replay() -> dict:
        i = state["index"]
        state["index"] += 1
        return messages[i]

    return body, replay


async def _send_deny_response(send: Callable, body_dict: dict) -> None:
    """Send a 403 JSON response to the client."""
    body = json.dumps(body_dict).encode()
    await send({
        "type":    "http.response.start",
        "status":  403,
        "headers": [
            (b"content-type",          b"application/json"),
            (b"content-length",        str(len(body)).encode()),
            (b"x-autopil-decision",    b"DENY"),
        ],
    })
    await send({"type": "http.response.body", "body": body, "more_body": False})
