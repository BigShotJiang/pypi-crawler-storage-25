"""
Session cleanup background job.

Runs as a daemon thread inside the API process. On each tick it calls
purge_expired_sessions(retention_days) on the SessionStore, which deletes
rows that have been expired or revoked for longer than retention_days.

Configuration (all via environment variables, also settable in create_app):
  AUTOPIL_SESSION_RETENTION_DAYS   int   How many days to keep expired/revoked sessions (default: 90)
  AUTOPIL_SESSION_CLEANUP_INTERVAL int   How often to run the purge, in seconds (default: 3600)

The job is a daemon thread — it will not block process shutdown.
"""

import logging
import threading
import time

logger = logging.getLogger(__name__)

_DEFAULT_RETENTION_DAYS     = 90
_DEFAULT_INTERVAL_SECONDS   = 3600   # run once per hour


class SessionCleanupJob:
    """
    Background daemon thread that periodically purges old expired/revoked sessions.

    Usage:
        job = SessionCleanupJob(session_store, retention_days=90, interval_seconds=3600)
        job.start()   # non-blocking; runs as a daemon thread
        job.stop()    # signals the thread to stop after its current sleep
    """

    def __init__(
        self,
        session_store,
        retention_days: int = _DEFAULT_RETENTION_DAYS,
        interval_seconds: int = _DEFAULT_INTERVAL_SECONDS,
    ):
        self._store             = session_store
        self._retention_days    = retention_days
        self._interval_seconds  = interval_seconds
        self._stop_event        = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        """Start the background cleanup thread. Idempotent — does nothing if already running."""
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run,
            name="autopil-session-cleanup",
            daemon=True,
        )
        self._thread.start()
        logger.info(
            "Session cleanup job started — retention=%dd, interval=%ds",
            self._retention_days,
            self._interval_seconds,
        )

    def stop(self) -> None:
        """Signal the thread to stop. Returns immediately; does not join."""
        self._stop_event.set()

    def _run(self) -> None:
        while not self._stop_event.is_set():
            try:
                deleted = self._store.purge_expired_sessions(self._retention_days)
                if deleted > 0:
                    logger.info(
                        "Session cleanup: deleted %d expired/revoked session(s) "
                        "(retention=%dd)",
                        deleted,
                        self._retention_days,
                    )
                else:
                    logger.debug(
                        "Session cleanup: nothing to purge (retention=%dd)",
                        self._retention_days,
                    )
            except Exception:
                logger.exception("Session cleanup job encountered an error — will retry next interval")

            # Sleep in short increments so stop() is responsive
            for _ in range(self._interval_seconds):
                if self._stop_event.is_set():
                    break
                time.sleep(1)

        logger.info("Session cleanup job stopped")
