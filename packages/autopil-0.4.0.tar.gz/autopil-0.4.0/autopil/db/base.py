"""
Abstract base classes for AutoPIL storage backends.

All methods that touch stored data are scoped by tenant_id.
Swap backends by changing the concrete class — nothing else changes.
"""

from abc import ABC, abstractmethod

from autopil.models import AgentAction, AgentRegistryEntry, AuditEvent


class AuditLogBase(ABC):

    @abstractmethod
    def record(self, event: AuditEvent, tenant_id: str = "default") -> None:
        """Persist an audit event. Append-only — no updates."""

    @abstractmethod
    def get_session_events(self, session_id: str, tenant_id: str = "default") -> list[AuditEvent]:
        """Return all events for a session scoped to tenant, ordered by timestamp."""

    @abstractmethod
    def get_all_events(self, tenant_id: str = "default") -> list[AuditEvent]:
        """Return all events for a tenant, ordered by timestamp."""

    @abstractmethod
    def get_session_owner(self, session_id: str, tenant_id: str = "default") -> str | None:
        """Return the agent_role that first recorded an event for this session."""

    @abstractmethod
    def verify_chain(self, tenant_id: str = "default") -> dict:
        """
        Walk all events for the tenant in timestamp order and verify the SHA-256
        hash chain is unbroken.

        Returns a dict with:
            valid        bool   — True if every chained event's hash is intact
            total        int    — total events in the tenant
            chained      int    — events that carry a chain_hash
            legacy       int    — events recorded before chaining was enabled
            broken_at    str|None — event_id of the first broken link, or None
        """

    @abstractmethod
    def purge_old_events(self, retention_days: int, tenant_id: str | None = None) -> int:
        """
        Delete audit events older than retention_days.
        Pass tenant_id to scope the purge to one tenant; None purges all tenants.
        Returns the total number of events deleted.
        """


class KeyStoreBase(ABC):

    @abstractmethod
    def create_key(self, name: str, tenant_id: str, is_superadmin: bool = False) -> tuple[str, str]:
        """Create a key for a tenant. Returns (key_id, plaintext). Plaintext shown once."""

    @abstractmethod
    def validate(self, plaintext: str) -> dict | None:
        """
        Validate a plaintext key. Returns dict with key_id, tenant_id, is_superadmin,
        or None if invalid/revoked. Updates last_used timestamp.
        """

    @abstractmethod
    def get_tenant_id_for_key(self, plaintext: str) -> str | None:
        """
        Look up tenant_id for a key regardless of is_active status.
        Used to detect deactivated (e.g. expired trial) tenants vs truly invalid keys.
        Returns tenant_id string or None if the key hash doesn't exist at all.
        """

    @abstractmethod
    def list_keys(self, tenant_id: str) -> list[dict]:
        """Return all keys for a tenant. Never include plaintext or hash."""

    @abstractmethod
    def revoke(self, key_id: str, tenant_id: str) -> bool:
        """Revoke a key. Returns True if the key existed and belonged to this tenant."""

    @abstractmethod
    def rotate_key(self, key_id: str, tenant_id: str) -> tuple[str, str] | None:
        """
        Create a replacement key (same name, scope, expiry) then revoke the old one.
        Returns (new_key_id, plaintext) or None if the original key was not found.
        """

    @abstractmethod
    def count(self, tenant_id: str | None = None) -> int:
        """Total keys. Pass tenant_id to count for a specific tenant."""


class TenantStoreBase(ABC):

    @abstractmethod
    def create_tenant(self, name: str) -> str:
        """Create a tenant. Returns tenant_id."""

    @abstractmethod
    def get_tenant(self, tenant_id: str) -> dict | None:
        """Return tenant record or None."""

    @abstractmethod
    def list_tenants(self) -> list[dict]:
        """Return all tenants."""

    @abstractmethod
    def deactivate_tenant(self, tenant_id: str) -> bool:
        """Deactivate a tenant. Returns True if it existed."""

    @abstractmethod
    def purge_tenant_data(self, tenant_id: str) -> dict:
        """
        Delete all operational data for a tenant across every table.
        The tenant row in `tenants` is retained as a record that the account existed.

        Returns a dict of {table: rows_deleted} for logging.
        """

    @abstractmethod
    def list_inactive_tenants(self, deactivated_before: str | None = None) -> list[dict]:
        """Return all tenants where is_active = False. If deactivated_before is set, only return
        tenants deactivated on or before that ISO timestamp."""

    @abstractmethod
    def update_tenant_retention(
        self, tenant_id: str, retention_days: int, session_retention_days: int
    ) -> bool:
        """Update retention settings for a tenant. Returns True if found."""

    @abstractmethod
    def count(self) -> int:
        """Total number of tenants."""


class PolicyStoreBase(ABC):

    @abstractmethod
    def upsert(self, policy: dict, tenant_id: str, changed_by: str | None = None, user_modified: bool = False) -> str:
        """Insert or update a policy matched by (name, industry, category). Returns policy_id."""

    @abstractmethod
    def get(self, name: str, tenant_id: str, industry: str | None = None, category: str | None = None) -> dict | None:
        """Return active policy by (name, industry, category), or None."""

    @abstractmethod
    def get_by_id(self, policy_id: str, tenant_id: str) -> dict | None:
        """Return active policy by policy_id, or None."""

    @abstractmethod
    def update_by_id(self, policy_id: str, policy_data: dict, tenant_id: str, changed_by: str | None = None, user_modified: bool = True) -> dict | None:
        """Update an existing policy by policy_id. Saves old version to history. Returns updated dict or None if not found."""

    @abstractmethod
    def list_active(self, tenant_id: str) -> list[dict]:
        """Return all active policies for tenant, ordered by industry, category, name."""

    @abstractmethod
    def delete_by_id(self, policy_id: str, tenant_id: str) -> bool:
        """Soft-delete a policy by policy_id. Returns True if it existed and was active."""

    @abstractmethod
    def get_history_by_id(self, policy_id: str, tenant_id: str) -> list[dict]:
        """Return version history for a policy by policy_id, newest first."""

    @abstractmethod
    def count(self, tenant_id: str) -> int:
        """Count active policies for a tenant."""


class LineageStoreBase(ABC):

    @abstractmethod
    def record_action(self, action: AgentAction, tenant_id: str) -> None:
        """Record an agent action linked to an audit event. Append-only."""

    @abstractmethod
    def get_actions_for_event(self, event_id: str, tenant_id: str) -> list[AgentAction]:
        """Return all actions linked to a specific audit event, ordered by timestamp."""

    @abstractmethod
    def get_actions_for_session(self, session_id: str, tenant_id: str) -> list[AgentAction]:
        """Return all actions for a session, ordered by timestamp."""


class SessionStoreBase(ABC):

    @abstractmethod
    def create_session(
        self,
        session_id: str,
        agent_role: str,
        user_id: str,
        tenant_id: str,
        ttl_minutes: int | None = None,
    ) -> None:
        """Persist a new session record. Idempotent — silently skips if already exists."""

    @abstractmethod
    def get_session(self, session_id: str, tenant_id: str) -> dict | None:
        """Return session record or None if unknown."""

    @abstractmethod
    def touch_session(self, session_id: str, tenant_id: str, agent_role: str) -> bool:
        """
        Update last_active to now, but only if the session is owned by agent_role.

        Returns True if the row was updated, False if the session was not found
        or agent_role does not match the stored owner.  Callers should treat
        False as a signal to re-run the ownership check and deny the request.
        """

    @abstractmethod
    def revoke_session(
        self,
        session_id: str,
        tenant_id: str,
        reason: str = "admin_action",
    ) -> bool:
        """Mark a session as revoked, recording the reason and revoked_at timestamp. Returns True if found."""

    @abstractmethod
    def list_sessions(self, tenant_id: str, include_expired: bool = False) -> list[dict]:
        """Return sessions for tenant, newest first. Excludes expired unless requested."""

    @abstractmethod
    def is_valid(self, session_id: str, tenant_id: str) -> tuple[bool, str]:
        """
        Check whether a session may proceed.
        Returns (True, "") if valid, or (False, reason) if expired/revoked/unknown.
        """

    @abstractmethod
    def update_session_context_hash(
        self,
        session_id: str,
        tenant_id: str,
        event_context_hash: str,
    ) -> None:
        """
        Incrementally chain a new event context hash into the session's
        accumulated context hash.

        Algorithm: new_session_hash = sha256(prev_session_hash + event_context_hash)
        where prev_session_hash is the empty string on the first ALLOW event.

        Only called for ALLOW events that produced a non-None context_hash.
        DENY events do not contribute to the session context hash.
        """

    @abstractmethod
    def revoke_sessions_by(
        self,
        tenant_id: str,
        agent_role: str | None = None,
        user_id: str | None = None,
        reason: str = "bulk_revocation",
    ) -> int:
        """
        Revoke all active (non-revoked) sessions matching the given filters,
        recording the reason and revoked_at timestamp on each row.

        Filter semantics: AND — both agent_role and user_id must match when both
        are supplied.  At least one must be provided; raises ValueError otherwise.

        Returns the number of sessions that were revoked.
        """

    @abstractmethod
    def purge_expired_sessions(self, retention_days: int, tenant_id: str | None = None) -> int:
        """
        Delete sessions that have been expired or revoked for longer than retention_days.

        Specifically, removes rows where:
          - is_revoked = True, OR
          - expires_at IS NOT NULL AND expires_at < now

        AND the expires_at (or last_active for revoked rows) is older than
        (now - retention_days). This prevents accidentally deleting sessions
        that expired within the retention window (still useful for incident review).

        Pass tenant_id to scope the purge to one tenant; None purges all tenants.
        Returns the number of rows deleted.
        """


class AgentRegistryStoreBase(ABC):

    @abstractmethod
    def ensure_registered(self, agent_role: str, tenant_id: str) -> str:
        """Upsert a draft entry for agent_role if none exists. Returns agent_id."""

    @abstractmethod
    def create(self, entry: AgentRegistryEntry, tenant_id: str) -> str:
        """Persist a new registry entry. Returns agent_id."""

    @abstractmethod
    def get(self, agent_id: str, tenant_id: str) -> AgentRegistryEntry | None:
        """Return entry by agent_id scoped to tenant, or None."""

    @abstractmethod
    def get_by_role(self, agent_role: str, tenant_id: str) -> AgentRegistryEntry | None:
        """Return entry by agent_role for this tenant, or None."""

    @abstractmethod
    def list_agents(
        self,
        tenant_id: str,
        status: str | None = None,
        framework: str | None = None,
        owner: str | None = None,
    ) -> list[AgentRegistryEntry]:
        """Return all registry entries for tenant, optionally filtered, ordered by display_name."""

    @abstractmethod
    def update(self, agent_id: str, updates: dict, tenant_id: str) -> bool:
        """Update mutable metadata fields. Returns True if found."""

    @abstractmethod
    def update_status(
        self,
        agent_id: str,
        status: str,
        tenant_id: str,
        approved_by: str | None = None,
    ) -> bool:
        """Transition agent status. Returns True if found."""

    @abstractmethod
    def get_activity_stats(self, agent_roles: list[str], tenant_id: str, days: int = 7) -> dict:
        """Return {agent_role: {last_active, event_count_7d, deny_rate_7d}} from audit trail."""


class AlertStoreBase(ABC):

    @abstractmethod
    def create_rule(self, rule: dict, tenant_id: str) -> str:
        """Create an alert rule. Returns rule_id."""

    @abstractmethod
    def get_rule(self, rule_id: str, tenant_id: str) -> dict | None:
        """Return rule by ID, or None."""

    @abstractmethod
    def list_rules(self, tenant_id: str) -> list[dict]:
        """Return all rules for tenant, ordered by created_at."""

    @abstractmethod
    def update_rule(self, rule_id: str, updates: dict, tenant_id: str) -> bool:
        """Update mutable fields on a rule. Returns True if found."""

    @abstractmethod
    def delete_rule(self, rule_id: str, tenant_id: str) -> bool:
        """Delete a rule. Returns True if found."""

    @abstractmethod
    def mark_fired(self, rule_id: str, fired_at: str) -> None:
        """Update last_fired_at for cooldown tracking."""

    @abstractmethod
    def record_delivery(self, delivery: dict) -> None:
        """Record a delivery attempt (sent, failed, or no_destination)."""

    @abstractmethod
    def list_deliveries(self, tenant_id: str, limit: int = 50) -> list[dict]:
        """Return recent deliveries for tenant, newest first."""
