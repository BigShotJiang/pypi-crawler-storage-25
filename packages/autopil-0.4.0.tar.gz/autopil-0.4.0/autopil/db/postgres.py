"""
Postgres backend — for production and enterprise deployments.

Requires psycopg2-binary:
    pip install autopil[postgres]

DATABASE_URL format:
    postgresql://user:password@host:5432/dbname
"""

import hashlib
import os
import secrets
import uuid as _uuid_mod
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone

try:
    import psycopg2
    import psycopg2.extras
    import psycopg2.pool
except ImportError as e:
    raise ImportError(
        "Postgres backend requires psycopg2. Install it with: pip install autopil[postgres]"
    ) from e

from autopil.models import AgentAction, AgentRegistryEntry, AuditEvent, Decision
from autopil.pii_mask import mask_event

from .base import (AuditLogBase, AgentRegistryStoreBase, AlertStoreBase, KeyStoreBase,
                   LineageStoreBase, SessionStoreBase, TenantStoreBase, PolicyStoreBase)

KEY_PREFIX = "apl_"


def _compute_pg_chain_hash(prev_hash: str, event: AuditEvent, tenant_id: str) -> str:
    """SHA-256 over the immutable audit fields and the previous hash."""
    ts = event.timestamp.isoformat() if isinstance(event.timestamp, datetime) else str(event.timestamp)
    payload = "|".join([
        prev_hash,
        event.event_id,
        tenant_id,
        ts,
        event.agent_role,
        event.user_id,
        event.source_id,
        event.decision.value,
        event.query,
    ])
    return hashlib.sha256(payload.encode()).hexdigest()


def _hash(key: str) -> str:
    return hashlib.sha256(key.encode()).hexdigest()


class _PostgresBase:
    def __init__(self, database_url: str):
        self._pool = psycopg2.pool.ThreadedConnectionPool(1, 10, dsn=database_url)

    @contextmanager
    def _conn(self):
        conn = self._pool.getconn()
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            self._pool.putconn(conn)


class PostgresAuditLog(_PostgresBase, AuditLogBase):

    def __init__(self, database_url: str):
        super().__init__(database_url)
        self._pii_mask = os.environ.get("AUTOPIL_LOG_PII_MASK", "").lower() in ("1", "true", "yes")
        self._init_db()

    def _init_db(self):
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS audit_events (
                        event_id          TEXT PRIMARY KEY,
                        session_id        TEXT NOT NULL,
                        agent_role        TEXT NOT NULL,
                        user_id           TEXT NOT NULL,
                        source_id         TEXT NOT NULL,
                        query             TEXT NOT NULL,
                        decision          TEXT NOT NULL,
                        policy_name       TEXT NOT NULL,
                        reason            TEXT NOT NULL,
                        context_hash      TEXT,
                        timestamp         TIMESTAMPTZ NOT NULL,
                        tenant_id         TEXT NOT NULL DEFAULT 'default',
                        sensitivity_level TEXT,
                        source_type       TEXT NOT NULL DEFAULT 'rest'
                    )
                """)
                # Migrations: add columns for databases created before these fields existed
                cur.execute("""
                    ALTER TABLE audit_events
                    ADD COLUMN IF NOT EXISTS tenant_id TEXT NOT NULL DEFAULT 'default'
                """)
                cur.execute("""
                    ALTER TABLE audit_events
                    ADD COLUMN IF NOT EXISTS sensitivity_level TEXT
                """)
                cur.execute("""
                    ALTER TABLE audit_events
                    ADD COLUMN IF NOT EXISTS source_type TEXT NOT NULL DEFAULT 'rest'
                """)
                cur.execute("ALTER TABLE audit_events ADD COLUMN IF NOT EXISTS catalog_enriched BOOLEAN NOT NULL DEFAULT FALSE")
                cur.execute("ALTER TABLE audit_events ADD COLUMN IF NOT EXISTS catalog_connection_id TEXT")
                cur.execute("ALTER TABLE audit_events ADD COLUMN IF NOT EXISTS pii_masked BOOLEAN NOT NULL DEFAULT FALSE")
                cur.execute("CREATE INDEX IF NOT EXISTS idx_audit_session ON audit_events(session_id)")
                cur.execute("CREATE INDEX IF NOT EXISTS idx_audit_timestamp ON audit_events(timestamp)")
                cur.execute("CREATE INDEX IF NOT EXISTS idx_audit_tenant ON audit_events(tenant_id)")

    def record(self, event: AuditEvent, tenant_id: str = "default") -> None:
        if self._pii_mask:
            event = mask_event(event, tenant_id)
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """INSERT INTO audit_events
                       (event_id, session_id, agent_role, user_id, source_id,
                        query, decision, policy_name, reason, context_hash,
                        timestamp, tenant_id, sensitivity_level, source_type,
                        catalog_enriched, catalog_connection_id, pii_masked)
                       VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                    (event.event_id, event.session_id, event.agent_role, event.user_id,
                     event.source_id, event.query, event.decision.value, event.policy_name,
                     event.reason, event.context_hash, event.timestamp, tenant_id,
                     event.sensitivity_level, event.source_type,
                     event.catalog_enriched, event.catalog_connection_id, event.pii_masked),
                )

    def get_session_events(self, session_id: str, tenant_id: str = "default") -> list[AuditEvent]:
        with self._conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    "SELECT * FROM audit_events WHERE session_id=%s AND tenant_id=%s ORDER BY timestamp",
                    (session_id, tenant_id),
                )
                return [self._row_to_event(r) for r in cur.fetchall()]

    def get_all_events(self, tenant_id: str = "default") -> list[AuditEvent]:
        with self._conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    "SELECT * FROM audit_events WHERE tenant_id=%s ORDER BY timestamp",
                    (tenant_id,),
                )
                return [self._row_to_event(r) for r in cur.fetchall()]

    def get_session_owner(self, session_id: str, tenant_id: str = "default") -> str | None:
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """SELECT agent_role FROM audit_events
                       WHERE session_id=%s AND tenant_id=%s ORDER BY timestamp LIMIT 1""",
                    (session_id, tenant_id),
                )
                row = cur.fetchone()
        return row[0] if row else None

    def _row_to_event(self, row: dict) -> AuditEvent:
        ts = row["timestamp"]
        if isinstance(ts, str):
            ts = datetime.fromisoformat(ts)
        return AuditEvent(
            event_id=row["event_id"], session_id=row["session_id"],
            agent_role=row["agent_role"], user_id=row["user_id"],
            source_id=row["source_id"], query=row["query"],
            decision=Decision(row["decision"]), policy_name=row["policy_name"],
            reason=row["reason"], timestamp=ts, context_hash=row["context_hash"],
            sensitivity_level=row.get("sensitivity_level"),
            source_type=row.get("source_type", "rest"),
            catalog_enriched=bool(row.get("catalog_enriched", False)),
            catalog_connection_id=row.get("catalog_connection_id"),
            pii_masked=bool(row.get("pii_masked", False)),
        )

    def _get_chain_anchor(self, tenant_id: str) -> dict | None:
        with self._conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    "SELECT anchor_hash, purged_before, purged_count FROM audit_chain_anchors WHERE tenant_id=%s",
                    (tenant_id,),
                )
                row = cur.fetchone()
        if not row:
            return None
        return {"anchor_hash": row["anchor_hash"], "purged_before": str(row["purged_before"]), "purged_count": row["purged_count"]}

    def verify_chain(self, tenant_id: str = "default") -> dict:
        events = self.get_all_events(tenant_id)
        total = len(events)
        chain_start = next((i for i, e in enumerate(events) if e.chain_hash is not None), None)
        if chain_start is None:
            return {"valid": True, "total": total, "chained": 0, "legacy": total, "broken_at": None}
        legacy = chain_start
        chained_events = events[chain_start:]
        anchor = self._get_chain_anchor(tenant_id)
        prev = anchor["anchor_hash"] if anchor else "GENESIS"
        for idx, event in enumerate(chained_events):
            if event.prev_hash != prev:
                return {"valid": False, "total": total, "chained": idx, "legacy": legacy, "broken_at": event.event_id}
            expected = _compute_pg_chain_hash(prev, event, tenant_id)
            if event.chain_hash != expected:
                return {"valid": False, "total": total, "chained": idx, "legacy": legacy, "broken_at": event.event_id}
            prev = event.chain_hash
        return {"valid": True, "total": total, "chained": len(chained_events), "legacy": legacy, "broken_at": None}

    def purge_old_events(self, retention_days: int, tenant_id: str | None = None) -> int:
        from datetime import timedelta
        cutoff = datetime.utcnow() - timedelta(days=retention_days)
        with self._conn() as conn:
            with conn.cursor() as cur:
                if tenant_id:
                    tenant_ids = [tenant_id]
                else:
                    cur.execute(
                        "SELECT DISTINCT tenant_id FROM audit_events WHERE timestamp < %s", (cutoff,)
                    )
                    tenant_ids = [r[0] for r in cur.fetchall()]

                total_deleted = 0
                for tid in tenant_ids:
                    cur.execute(
                        """SELECT chain_hash FROM audit_events
                           WHERE tenant_id=%s AND timestamp < %s
                           ORDER BY timestamp DESC LIMIT 1""",
                        (tid, cutoff),
                    )
                    row = cur.fetchone()
                    if not row:
                        continue
                    anchor_hash = row[0] or "GENESIS"

                    cur.execute(
                        "SELECT COUNT(*) FROM audit_events WHERE tenant_id=%s AND timestamp < %s",
                        (tid, cutoff),
                    )
                    purged_count = cur.fetchone()[0]

                    cur.execute(
                        """INSERT INTO audit_chain_anchors
                               (tenant_id, anchor_hash, purged_before, purged_count, created_at)
                           VALUES (%s, %s, %s, %s, %s)
                           ON CONFLICT(tenant_id) DO UPDATE SET
                               anchor_hash=EXCLUDED.anchor_hash,
                               purged_before=EXCLUDED.purged_before,
                               purged_count=EXCLUDED.purged_count,
                               created_at=EXCLUDED.created_at""",
                        (tid, anchor_hash, cutoff, purged_count, datetime.utcnow()),
                    )
                    cur.execute(
                        "DELETE FROM audit_events WHERE tenant_id=%s AND timestamp < %s",
                        (tid, cutoff),
                    )
                    total_deleted += purged_count

        return total_deleted


class PostgresKeyStore(_PostgresBase, KeyStoreBase):

    def __init__(self, database_url: str):
        super().__init__(database_url)
        self._init_db()

    def _init_db(self):
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS api_keys (
                        key_id        TEXT PRIMARY KEY,
                        key_hash      TEXT NOT NULL UNIQUE,
                        name          TEXT NOT NULL,
                        created_at    TIMESTAMPTZ NOT NULL,
                        last_used     TIMESTAMPTZ,
                        is_active     BOOLEAN NOT NULL DEFAULT TRUE,
                        tenant_id     TEXT NOT NULL DEFAULT 'default',
                        is_superadmin BOOLEAN NOT NULL DEFAULT FALSE,
                        scope         TEXT NOT NULL DEFAULT 'admin',
                        expires_at    TIMESTAMPTZ
                    )
                """)
                cur.execute("ALTER TABLE api_keys ADD COLUMN IF NOT EXISTS tenant_id TEXT NOT NULL DEFAULT 'default'")
                cur.execute("ALTER TABLE api_keys ADD COLUMN IF NOT EXISTS is_superadmin BOOLEAN NOT NULL DEFAULT FALSE")
                cur.execute("ALTER TABLE api_keys ADD COLUMN IF NOT EXISTS scope TEXT NOT NULL DEFAULT 'admin'")
                cur.execute("ALTER TABLE api_keys ADD COLUMN IF NOT EXISTS expires_at TIMESTAMPTZ")
                cur.execute("CREATE INDEX IF NOT EXISTS idx_keys_tenant ON api_keys(tenant_id)")

    def create_key(
        self,
        name: str,
        tenant_id: str = "default",
        is_superadmin: bool = False,
        scope: str = "admin",
        expires_days: int | None = None,
    ) -> tuple[str, str]:
        key_id    = secrets.token_hex(8)
        plaintext = KEY_PREFIX + secrets.token_hex(24)
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """INSERT INTO api_keys
                       (key_id, key_hash, name, created_at, tenant_id, is_superadmin, scope, expires_at)
                       VALUES (%s,%s,%s,NOW(),%s,%s,%s,
                               CASE WHEN %s IS NOT NULL
                                    THEN NOW() + (%s || ' days')::INTERVAL
                                    ELSE NULL END)""",
                    (key_id, _hash(plaintext), name, tenant_id, is_superadmin, scope,
                     str(expires_days) if expires_days is not None else None,
                     str(expires_days) if expires_days is not None else None),
                )
        return key_id, plaintext

    def validate(self, plaintext: str) -> dict | None:
        if not plaintext.startswith(KEY_PREFIX):
            return None
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT key_id, tenant_id, is_superadmin, scope FROM api_keys WHERE key_hash=%s AND is_active=TRUE",
                    (_hash(plaintext),),
                )
                row = cur.fetchone()
                if row:
                    cur.execute("UPDATE api_keys SET last_used=NOW() WHERE key_id=%s", (row[0],))
                    return {"key_id": row[0], "tenant_id": row[1], "is_superadmin": bool(row[2]),
                            "scope": row[3] or "admin"}
        return None

    def get_tenant_id_for_key(self, plaintext: str) -> str | None:
        if not plaintext.startswith(KEY_PREFIX):
            return None
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT tenant_id FROM api_keys WHERE key_hash=%s",
                    (_hash(plaintext),),
                )
                row = cur.fetchone()
                return row[0] if row else None

    def list_keys(self, tenant_id: str = "default") -> list[dict]:
        with self._conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    "SELECT key_id, name, created_at, last_used, is_active, tenant_id, is_superadmin, scope FROM api_keys WHERE tenant_id=%s ORDER BY created_at",
                    (tenant_id,),
                )
                rows = cur.fetchall()
        return [
            {"key_id": r["key_id"], "name": r["name"],
             "created_at": r["created_at"].isoformat() if hasattr(r["created_at"], "isoformat") else r["created_at"],
             "last_used": r["last_used"].isoformat() if r["last_used"] and hasattr(r["last_used"], "isoformat") else r["last_used"],
             "is_active": bool(r["is_active"]), "tenant_id": r["tenant_id"],
             "is_superadmin": bool(r["is_superadmin"]), "scope": r["scope"] or "admin"}
            for r in rows
        ]

    def revoke(self, key_id: str, tenant_id: str = "default") -> bool:
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "UPDATE api_keys SET is_active=FALSE WHERE key_id=%s AND tenant_id=%s AND is_active=TRUE",
                    (key_id, tenant_id),
                )
                return cur.rowcount > 0

    def rotate_key(self, key_id: str, tenant_id: str) -> tuple[str, str] | None:
        with self._conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    """SELECT name, is_superadmin, scope,
                              CASE WHEN expires_at IS NOT NULL
                                   THEN GREATEST(1, DATE_PART('day', expires_at - NOW())::int)
                                   ELSE NULL END AS expires_days
                       FROM api_keys WHERE key_id=%s AND tenant_id=%s AND is_active=TRUE""",
                    (key_id, tenant_id),
                )
                row = cur.fetchone()
        if not row:
            return None
        new_id, plaintext = self.create_key(
            row["name"], tenant_id, bool(row["is_superadmin"]),
            row["scope"] or "admin", row["expires_days"],
        )
        self.revoke(key_id, tenant_id)
        return new_id, plaintext

    def count(self, tenant_id: str | None = None) -> int:
        with self._conn() as conn:
            with conn.cursor() as cur:
                if tenant_id:
                    cur.execute("SELECT COUNT(*) FROM api_keys WHERE tenant_id=%s", (tenant_id,))
                else:
                    cur.execute("SELECT COUNT(*) FROM api_keys")
                return cur.fetchone()[0]


class PostgresTenantStore(_PostgresBase, TenantStoreBase):

    def __init__(self, database_url: str):
        super().__init__(database_url)
        self._init_db()

    def _init_db(self):
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS tenants (
                        tenant_id              TEXT PRIMARY KEY,
                        name                   TEXT NOT NULL UNIQUE,
                        created_at             TIMESTAMPTZ NOT NULL,
                        is_active              BOOLEAN NOT NULL DEFAULT TRUE,
                        deactivated_at         TIMESTAMPTZ,
                        retention_days         INTEGER NOT NULL DEFAULT 365,
                        session_retention_days INTEGER NOT NULL DEFAULT 90
                    )
                """)
                # Migrations for pre-retention schema
                cur.execute("ALTER TABLE tenants ADD COLUMN IF NOT EXISTS deactivated_at TIMESTAMPTZ")
                cur.execute("ALTER TABLE tenants ADD COLUMN IF NOT EXISTS retention_days INTEGER NOT NULL DEFAULT 365")
                cur.execute("ALTER TABLE tenants ADD COLUMN IF NOT EXISTS session_retention_days INTEGER NOT NULL DEFAULT 90")

    def create_tenant(self, name: str) -> str:
        tenant_id = "ten_" + secrets.token_hex(8)
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "INSERT INTO tenants (tenant_id, name, created_at) VALUES (%s,%s,NOW())",
                    (tenant_id, name),
                )
        return tenant_id

    def get_tenant(self, tenant_id: str) -> dict | None:
        with self._conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    """SELECT tenant_id, name, created_at, is_active,
                              retention_days, session_retention_days
                       FROM tenants WHERE tenant_id=%s""",
                    (tenant_id,),
                )
                row = cur.fetchone()
        if not row:
            return None
        return {
            "tenant_id": row["tenant_id"], "name": row["name"],
            "created_at": row["created_at"].isoformat() if hasattr(row["created_at"], "isoformat") else row["created_at"],
            "is_active": bool(row["is_active"]),
            "retention_days": row["retention_days"] if row["retention_days"] is not None else 365,
            "session_retention_days": row["session_retention_days"] if row["session_retention_days"] is not None else 90,
        }

    def list_tenants(self) -> list[dict]:
        with self._conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    """SELECT tenant_id, name, created_at, is_active,
                              retention_days, session_retention_days
                       FROM tenants ORDER BY created_at"""
                )
                rows = cur.fetchall()
        return [{
            "tenant_id": r["tenant_id"], "name": r["name"],
            "created_at": r["created_at"].isoformat() if hasattr(r["created_at"], "isoformat") else r["created_at"],
            "is_active": bool(r["is_active"]),
            "retention_days": r["retention_days"] if r["retention_days"] is not None else 365,
            "session_retention_days": r["session_retention_days"] if r["session_retention_days"] is not None else 90,
        } for r in rows]

    def update_tenant_retention(
        self, tenant_id: str, retention_days: int, session_retention_days: int
    ) -> bool:
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """UPDATE tenants SET retention_days=%s, session_retention_days=%s
                       WHERE tenant_id=%s""",
                    (retention_days, session_retention_days, tenant_id),
                )
                return cur.rowcount > 0

    def deactivate_tenant(self, tenant_id: str) -> bool:
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "UPDATE tenants SET is_active=FALSE, deactivated_at=NOW() WHERE tenant_id=%s AND is_active=TRUE",
                    (tenant_id,),
                )
                return cur.rowcount > 0

    def purge_tenant_data(self, tenant_id: str) -> dict:
        tables = [
            "audit_events",
            "api_keys",
            "sessions",
            "policies",
            "policy_versions",
            "alert_rules",
            "alert_deliveries",
            "agent_actions",
            "agent_registry",
        ]
        deleted = {}
        with self._conn() as conn:
            with conn.cursor() as cur:
                for table in tables:
                    try:
                        cur.execute(f"DELETE FROM {table} WHERE tenant_id = %s", (tenant_id,))
                        deleted[table] = cur.rowcount
                    except Exception:
                        deleted[table] = 0
        return deleted

    def list_inactive_tenants(self, deactivated_before: str | None = None) -> list[dict]:
        with self._conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                if deactivated_before:
                    cur.execute(
                        "SELECT tenant_id, name, created_at, deactivated_at FROM tenants "
                        "WHERE is_active = FALSE AND deactivated_at IS NOT NULL AND deactivated_at <= %s",
                        (deactivated_before,),
                    )
                else:
                    cur.execute(
                        "SELECT tenant_id, name, created_at, deactivated_at FROM tenants WHERE is_active = FALSE"
                    )
                rows = cur.fetchall()
        def _iso(v):
            return v.isoformat() if hasattr(v, "isoformat") else v
        return [
            {"tenant_id": r["tenant_id"], "name": r["name"],
             "created_at": _iso(r["created_at"]), "deactivated_at": _iso(r["deactivated_at"])}
            for r in rows
        ]

    def count(self) -> int:
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT COUNT(*) FROM tenants")
                return cur.fetchone()[0]


import json


class PostgresPolicyStore(_PostgresBase, PolicyStoreBase):

    def __init__(self, database_url: str):
        super().__init__(database_url)
        self._init_db()

    def _init_db(self):
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS policies (
                        policy_id       TEXT PRIMARY KEY,
                        name            TEXT NOT NULL,
                        agent_role      TEXT NOT NULL,
                        allowed_sources TEXT NOT NULL DEFAULT '[]',
                        denied_sources  TEXT NOT NULL DEFAULT '[]',
                        allowed_tasks   TEXT NOT NULL DEFAULT '[]',
                        denied_tasks    TEXT NOT NULL DEFAULT '[]',
                        max_sensitivity TEXT NOT NULL DEFAULT 'high',
                        industry        TEXT,
                        category        TEXT,
                        tenant_id       TEXT NOT NULL,
                        created_at      TIMESTAMPTZ NOT NULL,
                        updated_at      TIMESTAMPTZ NOT NULL,
                        version         INTEGER NOT NULL DEFAULT 1,
                        changed_by      TEXT,
                        is_active       BOOLEAN NOT NULL DEFAULT TRUE,
                        user_modified   BOOLEAN NOT NULL DEFAULT FALSE,
                        description     TEXT
                    )
                """)
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS policy_versions (
                        version_id      TEXT PRIMARY KEY,
                        policy_id       TEXT NOT NULL,
                        name            TEXT NOT NULL,
                        agent_role      TEXT NOT NULL,
                        allowed_sources TEXT NOT NULL DEFAULT '[]',
                        denied_sources  TEXT NOT NULL DEFAULT '[]',
                        allowed_tasks   TEXT NOT NULL DEFAULT '[]',
                        denied_tasks    TEXT NOT NULL DEFAULT '[]',
                        max_sensitivity TEXT NOT NULL,
                        industry        TEXT,
                        category        TEXT,
                        version         INTEGER NOT NULL,
                        tenant_id       TEXT NOT NULL,
                        changed_by      TEXT,
                        changed_at      TIMESTAMPTZ NOT NULL
                    )
                """)
                # Migrations: add columns if upgrading from older schema
                for col, definition in [
                    ("allowed_tasks", "TEXT NOT NULL DEFAULT '[]'"),
                    ("denied_tasks",  "TEXT NOT NULL DEFAULT '[]'"),
                    ("industry",      "TEXT"),
                    ("category",      "TEXT"),
                ]:
                    cur.execute(f"ALTER TABLE policies ADD COLUMN IF NOT EXISTS {col} {definition}")
                    cur.execute(f"ALTER TABLE policy_versions ADD COLUMN IF NOT EXISTS {col} {definition}")
                cur.execute("ALTER TABLE policies ADD COLUMN IF NOT EXISTS user_modified BOOLEAN NOT NULL DEFAULT FALSE")
                cur.execute("ALTER TABLE policies ADD COLUMN IF NOT EXISTS description TEXT")
                # Constraint migration: replace UNIQUE(name, tenant_id) with functional unique index
                cur.execute("ALTER TABLE policies DROP CONSTRAINT IF EXISTS policies_name_tenant_id_key")
                cur.execute("""
                    CREATE UNIQUE INDEX IF NOT EXISTS policies_name_industry_category_tenant_uniq
                    ON policies (name, COALESCE(industry, ''), COALESCE(category, ''), tenant_id)
                    WHERE is_active = TRUE
                """)

    def upsert(self, policy: dict, tenant_id: str, changed_by: str | None = None, user_modified: bool = False) -> str:
        name            = policy["name"]
        agent_role      = policy["agent_role"]
        allowed         = json.dumps(policy.get("allowed_sources", []))
        denied          = json.dumps(policy.get("denied_sources", []))
        allowed_tasks   = json.dumps(policy.get("allowed_tasks", []))
        denied_tasks    = json.dumps(policy.get("denied_tasks", []))
        sensitivity     = policy.get("max_sensitivity", "high")
        industry        = policy.get("industry")
        category        = policy.get("category")
        description     = policy.get("description")

        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """SELECT policy_id, version, agent_role, allowed_sources, denied_sources,
                              max_sensitivity, allowed_tasks, denied_tasks, industry, category,
                              user_modified, description
                       FROM policies
                       WHERE name=%s AND COALESCE(industry,'')=COALESCE(%s,'')
                         AND COALESCE(category,'')=COALESCE(%s,'')
                         AND tenant_id=%s AND is_active=TRUE""",
                    (name, industry, category, tenant_id),
                )
                existing = cur.fetchone()

                if existing:
                    policy_id, version = existing[0], existing[1]
                    unchanged = (
                        existing[2] == agent_role and
                        existing[3] == allowed and
                        existing[4] == denied and
                        existing[5] == sensitivity and
                        existing[6] == allowed_tasks and
                        existing[7] == denied_tasks and
                        existing[8] == industry and
                        existing[9] == category and
                        bool(existing[10]) == user_modified and
                        existing[11] == description
                    )
                    if unchanged:
                        return policy_id
                    new_version = version + 1
                    cur.execute(
                        """UPDATE policies SET agent_role=%s, allowed_sources=%s, denied_sources=%s,
                           allowed_tasks=%s, denied_tasks=%s, max_sensitivity=%s,
                           industry=%s, category=%s, updated_at=NOW(), version=%s, changed_by=%s,
                           user_modified=%s, description=%s
                           WHERE policy_id=%s""",
                        (agent_role, allowed, denied, allowed_tasks, denied_tasks,
                         sensitivity, industry, category, new_version, changed_by,
                         user_modified, description, policy_id),
                    )
                    cur.execute(
                        """INSERT INTO policy_versions
                           (version_id, policy_id, name, agent_role, allowed_sources, denied_sources,
                            allowed_tasks, denied_tasks, max_sensitivity, industry, category,
                            version, tenant_id, changed_by, changed_at)
                           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,NOW())""",
                        (secrets.token_hex(8), policy_id, name, agent_role, allowed, denied,
                         allowed_tasks, denied_tasks, sensitivity, industry, category,
                         new_version, tenant_id, changed_by),
                    )
                else:
                    policy_id = "pol_" + secrets.token_hex(8)
                    cur.execute(
                        """INSERT INTO policies
                           (policy_id, name, agent_role, allowed_sources, denied_sources,
                            allowed_tasks, denied_tasks, max_sensitivity, industry, category,
                            tenant_id, created_at, updated_at, version, changed_by, user_modified, description)
                           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,NOW(),NOW(),1,%s,%s,%s)""",
                        (policy_id, name, agent_role, allowed, denied, allowed_tasks, denied_tasks,
                         sensitivity, industry, category, tenant_id, changed_by, user_modified, description),
                    )
                    cur.execute(
                        """INSERT INTO policy_versions
                           (version_id, policy_id, name, agent_role, allowed_sources, denied_sources,
                            allowed_tasks, denied_tasks, max_sensitivity, industry, category,
                            version, tenant_id, changed_by, changed_at)
                           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,1,%s,%s,NOW())""",
                        (secrets.token_hex(8), policy_id, name, agent_role, allowed, denied,
                         allowed_tasks, denied_tasks, sensitivity, industry, category, tenant_id, changed_by),
                    )
        return policy_id

    def get(self, name: str, tenant_id: str, industry: str | None = None, category: str | None = None) -> dict | None:
        with self._conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    """SELECT policy_id, name, agent_role, allowed_sources, denied_sources,
                              allowed_tasks, denied_tasks, max_sensitivity, industry, category,
                              version, created_at, updated_at, changed_by, user_modified, description
                       FROM policies
                       WHERE name=%s AND COALESCE(industry,'')=COALESCE(%s,'')
                         AND COALESCE(category,'')=COALESCE(%s,'')
                         AND tenant_id=%s AND is_active=TRUE""",
                    (name, industry, category, tenant_id),
                )
                row = cur.fetchone()
        return self._row_to_dict(row) if row else None

    def get_by_id(self, policy_id: str, tenant_id: str) -> dict | None:
        with self._conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    """SELECT policy_id, name, agent_role, allowed_sources, denied_sources,
                              allowed_tasks, denied_tasks, max_sensitivity, industry, category,
                              version, created_at, updated_at, changed_by, user_modified, description
                       FROM policies WHERE policy_id=%s AND tenant_id=%s AND is_active=TRUE""",
                    (policy_id, tenant_id),
                )
                row = cur.fetchone()
        return self._row_to_dict(row) if row else None

    def list_active(self, tenant_id: str) -> list[dict]:
        with self._conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    """SELECT policy_id, name, agent_role, allowed_sources, denied_sources,
                              allowed_tasks, denied_tasks, max_sensitivity, industry, category,
                              version, created_at, updated_at, changed_by, user_modified, description
                       FROM policies WHERE tenant_id=%s AND is_active=TRUE ORDER BY industry, category, name""",
                    (tenant_id,),
                )
                return [self._row_to_dict(r) for r in cur.fetchall()]

    def delete(self, name: str, tenant_id: str) -> bool:
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "UPDATE policies SET is_active=FALSE WHERE name=%s AND tenant_id=%s AND is_active=TRUE",
                    (name, tenant_id),
                )
                return cur.rowcount > 0

    def delete_by_id(self, policy_id: str, tenant_id: str) -> bool:
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "UPDATE policies SET is_active=FALSE WHERE policy_id=%s AND tenant_id=%s AND is_active=TRUE",
                    (policy_id, tenant_id),
                )
                return cur.rowcount > 0

    def update_by_id(self, policy_id: str, policy_data: dict, tenant_id: str, changed_by: str | None = None, user_modified: bool = True) -> dict | None:
        allowed       = json.dumps(policy_data.get("allowed_sources", []))
        denied        = json.dumps(policy_data.get("denied_sources", []))
        allowed_tasks = json.dumps(policy_data.get("allowed_tasks", []))
        denied_tasks  = json.dumps(policy_data.get("denied_tasks", []))
        sensitivity   = policy_data.get("max_sensitivity", "high")
        agent_role    = policy_data["agent_role"]
        industry      = policy_data.get("industry")
        category      = policy_data.get("category")
        description   = policy_data.get("description")

        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """SELECT version, name, agent_role, allowed_sources, denied_sources,
                              max_sensitivity, allowed_tasks, denied_tasks, industry, category, user_modified, description
                       FROM policies WHERE policy_id=%s AND tenant_id=%s AND is_active=TRUE""",
                    (policy_id, tenant_id),
                )
                existing = cur.fetchone()
                if not existing:
                    return None
                version, pol_name = existing[0], existing[1]
                unchanged = (
                    existing[2] == agent_role and existing[3] == allowed and
                    existing[4] == denied and existing[5] == sensitivity and
                    existing[6] == allowed_tasks and existing[7] == denied_tasks and
                    existing[8] == industry and existing[9] == category and
                    bool(existing[10]) == user_modified and existing[11] == description
                )
                if not unchanged:
                    new_version = version + 1
                    cur.execute(
                        """UPDATE policies SET agent_role=%s, allowed_sources=%s, denied_sources=%s,
                           allowed_tasks=%s, denied_tasks=%s, max_sensitivity=%s,
                           industry=%s, category=%s, updated_at=NOW(), version=%s,
                           changed_by=%s, user_modified=%s, description=%s WHERE policy_id=%s""",
                        (agent_role, allowed, denied, allowed_tasks, denied_tasks,
                         sensitivity, industry, category, new_version, changed_by, user_modified, description, policy_id),
                    )
                    cur.execute(
                        """INSERT INTO policy_versions
                           (version_id, policy_id, name, agent_role, allowed_sources, denied_sources,
                            allowed_tasks, denied_tasks, max_sensitivity, industry, category,
                            version, tenant_id, changed_by, changed_at)
                           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,NOW())""",
                        (secrets.token_hex(8), policy_id, pol_name, agent_role, allowed, denied,
                         allowed_tasks, denied_tasks, sensitivity, industry, category,
                         new_version, tenant_id, changed_by),
                    )
        return self.get_by_id(policy_id, tenant_id)

    def get_history(self, name: str, tenant_id: str) -> list[dict]:
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT policy_id FROM policies WHERE name=%s AND tenant_id=%s",
                    (name, tenant_id),
                )
                row = cur.fetchone()
            if not row:
                return []
            policy_id = row[0]
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    """SELECT version_id, version, agent_role, allowed_sources, denied_sources,
                              allowed_tasks, denied_tasks, max_sensitivity, industry, category,
                              changed_by, changed_at
                       FROM policy_versions WHERE policy_id=%s AND tenant_id=%s
                       ORDER BY version DESC""",
                    (policy_id, tenant_id),
                )
                return [
                    {
                        "version_id":      r["version_id"],
                        "version":         r["version"],
                        "agent_role":      r["agent_role"],
                        "allowed_sources": json.loads(r["allowed_sources"]),
                        "denied_sources":  json.loads(r["denied_sources"]),
                        "allowed_tasks":   json.loads(r["allowed_tasks"]) if r["allowed_tasks"] else [],
                        "denied_tasks":    json.loads(r["denied_tasks"]) if r["denied_tasks"] else [],
                        "max_sensitivity": r["max_sensitivity"],
                        "industry":        r["industry"],
                        "category":        r["category"],
                        "changed_by":      r["changed_by"],
                        "changed_at":      r["changed_at"].isoformat() if hasattr(r["changed_at"], "isoformat") else r["changed_at"],
                    }
                    for r in cur.fetchall()
                ]

    def get_history_by_id(self, policy_id: str, tenant_id: str) -> list[dict]:
        with self._conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    """SELECT version_id, version, agent_role, allowed_sources, denied_sources,
                              allowed_tasks, denied_tasks, max_sensitivity, industry, category,
                              changed_by, changed_at
                       FROM policy_versions WHERE policy_id=%s AND tenant_id=%s
                       ORDER BY version DESC""",
                    (policy_id, tenant_id),
                )
                return [
                    {
                        "version_id":      r["version_id"],
                        "version":         r["version"],
                        "agent_role":      r["agent_role"],
                        "allowed_sources": json.loads(r["allowed_sources"]),
                        "denied_sources":  json.loads(r["denied_sources"]),
                        "allowed_tasks":   json.loads(r["allowed_tasks"]) if r["allowed_tasks"] else [],
                        "denied_tasks":    json.loads(r["denied_tasks"]) if r["denied_tasks"] else [],
                        "max_sensitivity": r["max_sensitivity"],
                        "industry":        r["industry"],
                        "category":        r["category"],
                        "changed_by":      r["changed_by"],
                        "changed_at":      r["changed_at"].isoformat() if hasattr(r["changed_at"], "isoformat") else r["changed_at"],
                    }
                    for r in cur.fetchall()
                ]

    def count(self, tenant_id: str) -> int:
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT COUNT(*) FROM policies WHERE tenant_id=%s AND is_active=TRUE",
                    (tenant_id,),
                )
                return cur.fetchone()[0]

    def _row_to_dict(self, row) -> dict:
        def iso(v):
            return v.isoformat() if hasattr(v, "isoformat") else v
        return {
            "policy_id":      row["policy_id"],
            "name":           row["name"],
            "agent_role":     row["agent_role"],
            "allowed_sources": json.loads(row["allowed_sources"]),
            "denied_sources":  json.loads(row["denied_sources"]),
            "allowed_tasks":   json.loads(row["allowed_tasks"]) if row.get("allowed_tasks") else [],
            "denied_tasks":    json.loads(row["denied_tasks"]) if row.get("denied_tasks") else [],
            "max_sensitivity": row["max_sensitivity"],
            "industry":        row.get("industry"),
            "category":        row.get("category"),
            "version":         row["version"],
            "created_at":      iso(row["created_at"]),
            "updated_at":      iso(row["updated_at"]),
            "changed_by":      row["changed_by"],
            "user_modified":   bool(row.get("user_modified", False)),
            "description":     row.get("description"),
        }


class PostgresAlertStore(_PostgresBase, AlertStoreBase):

    def __init__(self, database_url: str):
        super().__init__(database_url)
        self._init_db()

    def _init_db(self):
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS alert_rules (
                        rule_id          TEXT PRIMARY KEY,
                        tenant_id        TEXT NOT NULL,
                        name             TEXT NOT NULL,
                        rule_type        TEXT NOT NULL,
                        threshold        INTEGER NOT NULL DEFAULT 5,
                        window_minutes   INTEGER NOT NULL DEFAULT 60,
                        cooldown_minutes INTEGER NOT NULL DEFAULT 60,
                        webhook_url      TEXT,
                        email            TEXT,
                        is_enabled       BOOLEAN NOT NULL DEFAULT TRUE,
                        created_at       TIMESTAMPTZ NOT NULL,
                        last_fired_at    TIMESTAMPTZ
                    )
                """)
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS alert_deliveries (
                        delivery_id TEXT PRIMARY KEY,
                        rule_id     TEXT NOT NULL,
                        tenant_id   TEXT NOT NULL,
                        fired_at    TIMESTAMPTZ NOT NULL,
                        rule_name   TEXT NOT NULL,
                        rule_type   TEXT NOT NULL,
                        detail      TEXT NOT NULL,
                        status      TEXT NOT NULL,
                        error       TEXT
                    )
                """)
                cur.execute("CREATE INDEX IF NOT EXISTS idx_alert_rules_tenant ON alert_rules(tenant_id)")
                cur.execute("CREATE INDEX IF NOT EXISTS idx_alert_deliveries_tenant ON alert_deliveries(tenant_id)")

    def create_rule(self, rule: dict, tenant_id: str) -> str:
        rule_id = "alr_" + secrets.token_hex(8)
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """INSERT INTO alert_rules
                       (rule_id, tenant_id, name, rule_type, threshold, window_minutes,
                        cooldown_minutes, webhook_url, email, is_enabled, created_at)
                       VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,TRUE,NOW())""",
                    (rule_id, tenant_id, rule["name"], rule["rule_type"],
                     rule.get("threshold", 5), rule.get("window_minutes", 60),
                     rule.get("cooldown_minutes", 60),
                     rule.get("webhook_url"), rule.get("email")),
                )
        return rule_id

    def get_rule(self, rule_id: str, tenant_id: str) -> dict | None:
        with self._conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    "SELECT * FROM alert_rules WHERE rule_id=%s AND tenant_id=%s",
                    (rule_id, tenant_id),
                )
                row = cur.fetchone()
        return self._rule_row(dict(row)) if row else None

    def list_rules(self, tenant_id: str) -> list[dict]:
        with self._conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    "SELECT * FROM alert_rules WHERE tenant_id=%s ORDER BY created_at",
                    (tenant_id,),
                )
                return [self._rule_row(dict(r)) for r in cur.fetchall()]

    def update_rule(self, rule_id: str, updates: dict, tenant_id: str) -> bool:
        allowed = {"name", "threshold", "window_minutes", "cooldown_minutes",
                   "webhook_url", "email", "is_enabled"}
        fields = {k: v for k, v in updates.items() if k in allowed}
        if not fields:
            return False
        set_clause = ", ".join(f"{k}=%s" for k in fields)
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    f"UPDATE alert_rules SET {set_clause} WHERE rule_id=%s AND tenant_id=%s",
                    (*fields.values(), rule_id, tenant_id),
                )
                return cur.rowcount > 0

    def delete_rule(self, rule_id: str, tenant_id: str) -> bool:
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "DELETE FROM alert_rules WHERE rule_id=%s AND tenant_id=%s",
                    (rule_id, tenant_id),
                )
                return cur.rowcount > 0

    def mark_fired(self, rule_id: str, fired_at: str) -> None:
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "UPDATE alert_rules SET last_fired_at=%s WHERE rule_id=%s",
                    (fired_at, rule_id),
                )

    def record_delivery(self, delivery: dict) -> None:
        delivery_id = secrets.token_hex(12)
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """INSERT INTO alert_deliveries
                       (delivery_id, rule_id, tenant_id, fired_at, rule_name,
                        rule_type, detail, status, error)
                       VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                    (delivery_id, delivery["rule_id"], delivery["tenant_id"],
                     delivery["fired_at"], delivery["rule_name"], delivery["rule_type"],
                     delivery["detail"], delivery["status"], delivery.get("error")),
                )

    def list_deliveries(self, tenant_id: str, limit: int = 50) -> list[dict]:
        with self._conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    """SELECT delivery_id, rule_id, tenant_id, fired_at, rule_name,
                              rule_type, detail, status, error
                       FROM alert_deliveries WHERE tenant_id=%s
                       ORDER BY fired_at DESC LIMIT %s""",
                    (tenant_id, limit),
                )
                rows = cur.fetchall()
        return [
            {
                "delivery_id": r["delivery_id"], "rule_id": r["rule_id"],
                "tenant_id": r["tenant_id"],
                "fired_at": r["fired_at"].isoformat() if hasattr(r["fired_at"], "isoformat") else r["fired_at"],
                "rule_name": r["rule_name"], "rule_type": r["rule_type"],
                "detail": json.loads(r["detail"]), "status": r["status"], "error": r["error"],
            }
            for r in rows
        ]

    def _rule_row(self, row: dict) -> dict:
        def iso(v):
            return v.isoformat() if hasattr(v, "isoformat") else v
        return {
            "rule_id": row["rule_id"], "tenant_id": row["tenant_id"],
            "name": row["name"], "rule_type": row["rule_type"],
            "threshold": row["threshold"], "window_minutes": row["window_minutes"],
            "cooldown_minutes": row["cooldown_minutes"],
            "webhook_url": row.get("webhook_url"), "email": row.get("email"),
            "is_enabled": bool(row["is_enabled"]),
            "created_at": iso(row["created_at"]),
            "last_fired_at": iso(row["last_fired_at"]) if row.get("last_fired_at") else None,
        }


class PostgresSessionStore(_PostgresBase, SessionStoreBase):
    """
    Postgres-backed session store.

    Tracks session lifecycle: creation, activity, TTL expiration, and revocation.
    Primary key is (session_id, tenant_id) to match the SQLite implementation.
    """

    def __init__(self, database_url: str):
        super().__init__(database_url)
        self._init_db()

    def _init_db(self):
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS sessions (
                        session_id    TEXT        NOT NULL,
                        tenant_id     TEXT        NOT NULL,
                        agent_role    TEXT        NOT NULL,
                        user_id       TEXT        NOT NULL,
                        created_at    TIMESTAMPTZ NOT NULL,
                        last_active   TIMESTAMPTZ NOT NULL,
                        expires_at    TIMESTAMPTZ,
                        ttl_minutes   INTEGER,
                        is_revoked         BOOLEAN     NOT NULL DEFAULT FALSE,
                        context_hash       TEXT,
                        revocation_reason  TEXT,
                        revoked_at         TIMESTAMPTZ,
                        PRIMARY KEY (session_id, tenant_id)
                    )
                """)
                cur.execute(
                    "CREATE INDEX IF NOT EXISTS idx_sessions_tenant ON sessions(tenant_id, created_at)"
                )
                # Migrations: add columns for databases created before this schema
                cur.execute("ALTER TABLE sessions ADD COLUMN IF NOT EXISTS ttl_minutes INTEGER")
                cur.execute("ALTER TABLE sessions ADD COLUMN IF NOT EXISTS expires_at TIMESTAMPTZ")
                cur.execute("ALTER TABLE sessions ADD COLUMN IF NOT EXISTS context_hash TEXT")
                cur.execute("ALTER TABLE sessions ADD COLUMN IF NOT EXISTS revocation_reason TEXT")
                cur.execute("ALTER TABLE sessions ADD COLUMN IF NOT EXISTS revoked_at TIMESTAMPTZ")

    def create_session(
        self,
        session_id: str,
        agent_role: str,
        user_id: str,
        tenant_id: str,
        ttl_minutes: int | None = None,
    ) -> None:
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """INSERT INTO sessions
                       (session_id, tenant_id, agent_role, user_id,
                        created_at, last_active, expires_at, ttl_minutes, is_revoked)
                       VALUES (%s, %s, %s, %s,
                               NOW(), NOW(),
                               CASE WHEN %s IS NOT NULL
                                    THEN NOW() + (%s || ' minutes')::INTERVAL
                                    ELSE NULL END,
                               %s, FALSE)
                       ON CONFLICT (session_id, tenant_id) DO NOTHING""",
                    (
                        session_id, tenant_id, agent_role, user_id,
                        str(ttl_minutes) if ttl_minutes is not None else None,
                        str(ttl_minutes) if ttl_minutes is not None else None,
                        ttl_minutes,
                    ),
                )

    def get_session(self, session_id: str, tenant_id: str) -> dict | None:
        with self._conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    """SELECT session_id, tenant_id, agent_role, user_id,
                              created_at, last_active, expires_at, ttl_minutes, is_revoked,
                              context_hash, revocation_reason, revoked_at
                       FROM sessions WHERE session_id = %s AND tenant_id = %s""",
                    (session_id, tenant_id),
                )
                row = cur.fetchone()
        return self._row_to_session(row) if row else None

    def touch_session(self, session_id: str, tenant_id: str, agent_role: str) -> bool:
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """UPDATE sessions SET last_active = NOW()
                       WHERE session_id = %s AND tenant_id = %s AND agent_role = %s""",
                    (session_id, tenant_id, agent_role),
                )
                return cur.rowcount > 0

    def revoke_session(
        self,
        session_id: str,
        tenant_id: str,
        reason: str = "admin_action",
    ) -> bool:
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """UPDATE sessions
                       SET is_revoked = TRUE, revocation_reason = %s, revoked_at = NOW()
                       WHERE session_id = %s AND tenant_id = %s""",
                    (reason, session_id, tenant_id),
                )
                return cur.rowcount > 0

    def list_sessions(self, tenant_id: str, include_expired: bool = False) -> list[dict]:
        with self._conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                if include_expired:
                    cur.execute(
                        """SELECT session_id, tenant_id, agent_role, user_id,
                                  created_at, last_active, expires_at, ttl_minutes, is_revoked,
                                  context_hash, revocation_reason, revoked_at
                           FROM sessions WHERE tenant_id = %s
                           ORDER BY created_at DESC""",
                        (tenant_id,),
                    )
                else:
                    cur.execute(
                        """SELECT session_id, tenant_id, agent_role, user_id,
                                  created_at, last_active, expires_at, ttl_minutes, is_revoked,
                                  context_hash, revocation_reason, revoked_at
                           FROM sessions
                           WHERE tenant_id = %s
                             AND is_revoked = FALSE
                             AND (expires_at IS NULL OR expires_at > NOW())
                           ORDER BY created_at DESC""",
                        (tenant_id,),
                    )
                rows = cur.fetchall()
        return [self._row_to_session(r) for r in rows]

    def is_valid(self, session_id: str, tenant_id: str) -> tuple[bool, str]:
        session = self.get_session(session_id, tenant_id)
        if session is None:
            return False, "session_not_found"
        if session["is_revoked"]:
            return False, "session_revoked"
        if session["expires_at"] is not None:
            now = datetime.now(timezone.utc)
            expires = session["expires_at"]
            # psycopg2 returns TIMESTAMPTZ as timezone-aware datetime objects
            if isinstance(expires, str):
                expires = datetime.fromisoformat(expires)
            if expires.tzinfo is None:
                expires = expires.replace(tzinfo=timezone.utc)
            if now > expires:
                return False, "session_expired"
        return True, ""

    def update_session_context_hash(
        self,
        session_id: str,
        tenant_id: str,
        event_context_hash: str,
    ) -> None:
        import hashlib
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT context_hash FROM sessions WHERE session_id = %s AND tenant_id = %s",
                    (session_id, tenant_id),
                )
                row = cur.fetchone()
                if row is None:
                    return
                prev = row[0] or ""
                new_hash = hashlib.sha256(
                    (prev + event_context_hash).encode()
                ).hexdigest()
                cur.execute(
                    "UPDATE sessions SET context_hash = %s WHERE session_id = %s AND tenant_id = %s",
                    (new_hash, session_id, tenant_id),
                )

    def revoke_sessions_by(
        self,
        tenant_id: str,
        agent_role: str | None = None,
        user_id: str | None = None,
        reason: str = "bulk_revocation",
    ) -> int:
        if agent_role is None and user_id is None:
            raise ValueError("At least one of agent_role or user_id must be provided")
        clauses = ["tenant_id = %s", "is_revoked = FALSE"]
        params: list = [reason, tenant_id]
        if agent_role is not None:
            clauses.append("agent_role = %s")
            params.append(agent_role)
        if user_id is not None:
            clauses.append("user_id = %s")
            params.append(user_id)
        sql = (
            f"UPDATE sessions SET is_revoked = TRUE, revocation_reason = %s, revoked_at = NOW() "
            f"WHERE {' AND '.join(clauses)}"
        )
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                return cur.rowcount

    def purge_expired_sessions(self, retention_days: int, tenant_id: str | None = None) -> int:
        from datetime import timedelta
        cutoff = datetime.now(timezone.utc) - timedelta(days=retention_days)
        with self._conn() as conn:
            with conn.cursor() as cur:
                if tenant_id:
                    cur.execute(
                        """DELETE FROM sessions
                           WHERE tenant_id = %s
                             AND ((is_revoked = TRUE AND last_active < %s)
                               OR (expires_at IS NOT NULL AND expires_at < %s))""",
                        (tenant_id, cutoff, cutoff),
                    )
                else:
                    cur.execute(
                        """DELETE FROM sessions
                           WHERE (is_revoked = TRUE AND last_active < %s)
                              OR (expires_at IS NOT NULL AND expires_at < %s)""",
                        (cutoff, cutoff),
                    )
                return cur.rowcount

    def _row_to_session(self, row) -> dict:
        def iso(v):
            return v.isoformat() if hasattr(v, "isoformat") else v

        return {
            "session_id":   row["session_id"],
            "tenant_id":    row["tenant_id"],
            "agent_role":   row["agent_role"],
            "user_id":      row["user_id"],
            "created_at":   iso(row["created_at"]),
            "last_active":  iso(row["last_active"]),
            "expires_at":   iso(row["expires_at"]) if row["expires_at"] is not None else None,
            "ttl_minutes":  row["ttl_minutes"],
            "is_revoked":        bool(row["is_revoked"]),
            "context_hash":      row["context_hash"],
            "revocation_reason": row["revocation_reason"],
            "revoked_at":        iso(row["revoked_at"]) if row["revoked_at"] is not None else None,
        }


class PostgresLineageStore(_PostgresBase, LineageStoreBase):
    """
    Postgres-backed lineage store.

    Records agent actions linked to audit events, enabling a traceable chain from
    policy evaluation (ALLOW/DENY) through to downstream agent decisions and outcomes.
    """

    def __init__(self, database_url: str):
        super().__init__(database_url)
        self._init_db()

    def _init_db(self):
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS agent_actions (
                        action_id     TEXT        NOT NULL,
                        event_id      TEXT        NOT NULL,
                        session_id    TEXT        NOT NULL,
                        agent_role    TEXT        NOT NULL,
                        action_type   TEXT        NOT NULL,
                        action_detail JSONB       NOT NULL DEFAULT '{}',
                        outcome       TEXT,
                        timestamp     TIMESTAMPTZ NOT NULL,
                        tenant_id     TEXT        NOT NULL,
                        PRIMARY KEY (action_id, tenant_id)
                    )
                """)
                cur.execute("""
                    CREATE INDEX IF NOT EXISTS idx_agent_actions_event_id
                    ON agent_actions(event_id, tenant_id)
                """)
                cur.execute("""
                    CREATE INDEX IF NOT EXISTS idx_agent_actions_session_id
                    ON agent_actions(session_id, tenant_id)
                """)
            conn.commit()

    def record_action(self, action: AgentAction, tenant_id: str) -> None:
        ts = action.timestamp if isinstance(action.timestamp, datetime) else datetime.fromisoformat(str(action.timestamp))
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """INSERT INTO agent_actions
                       (action_id, event_id, session_id, agent_role, action_type,
                        action_detail, outcome, timestamp, tenant_id)
                       VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                       ON CONFLICT (action_id, tenant_id) DO NOTHING""",
                    (
                        action.action_id,
                        action.event_id,
                        action.session_id,
                        action.agent_role,
                        action.action_type,
                        psycopg2.extras.Json(action.action_detail),
                        action.outcome,
                        ts,
                        tenant_id,
                    ),
                )
            conn.commit()

    def get_actions_for_event(self, event_id: str, tenant_id: str) -> list[AgentAction]:
        with self._conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    """SELECT action_id, event_id, session_id, agent_role, action_type,
                              action_detail, outcome, timestamp
                       FROM agent_actions
                       WHERE event_id = %s AND tenant_id = %s
                       ORDER BY timestamp""",
                    (event_id, tenant_id),
                )
                rows = cur.fetchall()
        return [self._row_to_action(r) for r in rows]

    def get_actions_for_session(self, session_id: str, tenant_id: str) -> list[AgentAction]:
        with self._conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    """SELECT action_id, event_id, session_id, agent_role, action_type,
                              action_detail, outcome, timestamp
                       FROM agent_actions
                       WHERE session_id = %s AND tenant_id = %s
                       ORDER BY timestamp""",
                    (session_id, tenant_id),
                )
                rows = cur.fetchall()
        return [self._row_to_action(r) for r in rows]

    def _row_to_action(self, row) -> AgentAction:
        ts = row["timestamp"]
        if isinstance(ts, str):
            ts = datetime.fromisoformat(ts)
        return AgentAction(
            action_id=row["action_id"],
            event_id=row["event_id"],
            session_id=row["session_id"],
            agent_role=row["agent_role"],
            action_type=row["action_type"],
            action_detail=row["action_detail"] if isinstance(row["action_detail"], dict) else {},
            outcome=row["outcome"],
            timestamp=ts,
        )


class PostgresAgentRegistryStore(_PostgresBase, AgentRegistryStoreBase):
    """
    Postgres-backed agent registry store.

    Tracks agent identity, approval status, framework, and live activity stats
    across the tenant's audit trail.
    """

    def __init__(self, database_url: str):
        super().__init__(database_url)
        self._init_db()

    def _init_db(self):
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS agent_registry (
                        agent_id      TEXT        NOT NULL,
                        tenant_id     TEXT        NOT NULL,
                        agent_role    TEXT        NOT NULL,
                        display_name  TEXT        NOT NULL,
                        description   TEXT,
                        owner         TEXT,
                        framework     TEXT,
                        policy_name   TEXT,
                        status        TEXT        NOT NULL DEFAULT 'draft',
                        version       TEXT        NOT NULL DEFAULT '1.0.0',
                        created_at    TIMESTAMPTZ NOT NULL,
                        updated_at    TIMESTAMPTZ NOT NULL,
                        created_by    TEXT,
                        approved_by   TEXT,
                        approved_at   TIMESTAMPTZ,
                        PRIMARY KEY (agent_id, tenant_id)
                    )
                """)
                cur.execute("""
                    CREATE UNIQUE INDEX IF NOT EXISTS idx_agent_registry_role_tenant
                    ON agent_registry(agent_role, tenant_id)
                """)
                cur.execute("""
                    CREATE INDEX IF NOT EXISTS idx_agent_registry_tenant
                    ON agent_registry(tenant_id)
                """)
            conn.commit()

    def ensure_registered(self, agent_role: str, tenant_id: str) -> str:
        now = datetime.now(timezone.utc)
        display_name = agent_role.replace("_", " ").title()
        with self._conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    "SELECT agent_id FROM agent_registry WHERE agent_role = %s AND tenant_id = %s",
                    (agent_role, tenant_id),
                )
                row = cur.fetchone()
                if row:
                    return row["agent_id"]
                agent_id = str(_uuid_mod.uuid4())
                cur.execute(
                    """INSERT INTO agent_registry
                       (agent_id, tenant_id, agent_role, display_name, status, version,
                        created_at, updated_at)
                       VALUES (%s, %s, %s, %s, 'draft', '1.0.0', %s, %s)
                       ON CONFLICT (agent_role, tenant_id) DO NOTHING""",
                    (agent_id, tenant_id, agent_role, display_name, now, now),
                )
                # Fetch the actual agent_id in case of conflict
                cur.execute(
                    "SELECT agent_id FROM agent_registry WHERE agent_role = %s AND tenant_id = %s",
                    (agent_role, tenant_id),
                )
                row = cur.fetchone()
            conn.commit()
        return row["agent_id"]

    def create(self, entry: AgentRegistryEntry, tenant_id: str) -> str:
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """INSERT INTO agent_registry
                       (agent_id, tenant_id, agent_role, display_name, description, owner,
                        framework, policy_name, status, version, created_at, updated_at,
                        created_by, approved_by, approved_at)
                       VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                       ON CONFLICT (agent_id, tenant_id) DO NOTHING""",
                    (
                        entry.agent_id, tenant_id, entry.agent_role, entry.display_name,
                        entry.description, entry.owner, entry.framework, entry.policy_name,
                        entry.status, entry.version,
                        entry.created_at, entry.updated_at,
                        getattr(entry, "created_by", None),
                        getattr(entry, "approved_by", None),
                        getattr(entry, "approved_at", None),
                    ),
                )
            conn.commit()
        return entry.agent_id

    def get(self, agent_id: str, tenant_id: str) -> AgentRegistryEntry | None:
        with self._conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    "SELECT * FROM agent_registry WHERE agent_id = %s AND tenant_id = %s",
                    (agent_id, tenant_id),
                )
                row = cur.fetchone()
        return self._row_to_entry(row) if row else None

    def get_by_role(self, agent_role: str, tenant_id: str) -> AgentRegistryEntry | None:
        with self._conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    "SELECT * FROM agent_registry WHERE agent_role = %s AND tenant_id = %s",
                    (agent_role, tenant_id),
                )
                row = cur.fetchone()
        return self._row_to_entry(row) if row else None

    def list_agents(
        self,
        tenant_id: str,
        status: str | None = None,
        framework: str | None = None,
        owner: str | None = None,
    ) -> list[AgentRegistryEntry]:
        query = "SELECT * FROM agent_registry WHERE tenant_id = %s"
        params: list = [tenant_id]
        if status:
            query += " AND status = %s"
            params.append(status)
        if framework:
            query += " AND framework = %s"
            params.append(framework)
        if owner:
            query += " AND owner = %s"
            params.append(owner)
        query += " ORDER BY display_name"
        with self._conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(query, params)
                rows = cur.fetchall()
        return [self._row_to_entry(r) for r in rows]

    def update(self, agent_id: str, updates: dict, tenant_id: str) -> bool:
        allowed = {"display_name", "description", "owner", "framework", "policy_name", "version"}
        fields = {k: v for k, v in updates.items() if k in allowed}
        if not fields:
            return False
        fields["updated_at"] = datetime.now(timezone.utc)
        set_clause = ", ".join(f"{k} = %s" for k in fields)
        values = list(fields.values()) + [agent_id, tenant_id]
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    f"UPDATE agent_registry SET {set_clause} WHERE agent_id = %s AND tenant_id = %s",
                    values,
                )
                updated = cur.rowcount > 0
            conn.commit()
        return updated

    def update_status(
        self,
        agent_id: str,
        status: str,
        tenant_id: str,
        approved_by: str | None = None,
    ) -> bool:
        now = datetime.now(timezone.utc)
        with self._conn() as conn:
            with conn.cursor() as cur:
                if status == "approved" and approved_by:
                    cur.execute(
                        """UPDATE agent_registry
                           SET status = %s, approved_by = %s, approved_at = %s, updated_at = %s
                           WHERE agent_id = %s AND tenant_id = %s""",
                        (status, approved_by, now, now, agent_id, tenant_id),
                    )
                else:
                    cur.execute(
                        """UPDATE agent_registry
                           SET status = %s, updated_at = %s
                           WHERE agent_id = %s AND tenant_id = %s""",
                        (status, now, agent_id, tenant_id),
                    )
                updated = cur.rowcount > 0
            conn.commit()
        return updated

    def get_activity_stats(self, agent_roles: list[str], tenant_id: str, days: int = 7) -> dict:
        if not agent_roles:
            return {}
        cutoff = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(days=days)
        placeholders = ",".join(["%s"] * len(agent_roles))
        with self._conn() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                try:
                    cur.execute(
                        f"""SELECT agent_role,
                                   MAX(timestamp)  AS last_active,
                                   COUNT(*)        AS total,
                                   SUM(CASE WHEN decision = 'DENY' THEN 1 ELSE 0 END) AS denies
                            FROM audit_events
                            WHERE tenant_id = %s
                              AND agent_role IN ({placeholders})
                              AND timestamp >= %s
                            GROUP BY agent_role""",
                        [tenant_id] + agent_roles + [cutoff],
                    )
                    rows = cur.fetchall()
                except Exception:
                    return {}
        return {
            r["agent_role"]: {
                "last_active":    r["last_active"].isoformat() if r["last_active"] else None,
                "event_count_7d": r["total"],
                "deny_rate_7d":   round(r["denies"] / r["total"], 3) if r["total"] > 0 else 0.0,
            }
            for r in rows
        }

    def _row_to_entry(self, row) -> AgentRegistryEntry:
        def _dt(v):
            if v is None:
                return None
            if isinstance(v, datetime):
                return v
            return datetime.fromisoformat(str(v))

        return AgentRegistryEntry(
            agent_id=row["agent_id"],
            tenant_id=row["tenant_id"],
            agent_role=row["agent_role"],
            display_name=row["display_name"],
            description=row["description"],
            owner=row["owner"],
            framework=row["framework"],
            policy_name=row["policy_name"],
            status=row["status"],
            version=row["version"],
            created_at=_dt(row["created_at"]),
            updated_at=_dt(row["updated_at"]),
            created_by=row.get("created_by"),
            approved_by=row.get("approved_by"),
            approved_at=_dt(row.get("approved_at")),
        )
