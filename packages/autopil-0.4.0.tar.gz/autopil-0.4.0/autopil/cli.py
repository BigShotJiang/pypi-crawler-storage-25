"""
AutoPIL server entry point.

Used by the `autopil-serve` console script installed by pip.
Can also be invoked directly: python -m autopil.cli
"""

import argparse
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path


DEFAULT_POLICY = str(Path(__file__).parent.parent.parent.parent / "policies")
DEFAULT_DB     = "autopil_audit.db"


_DEMO_AGENTS = [
    {"agent_role": "fraud_orchestrator",  "display_name": "Fraud Orchestrator",   "framework": "langgraph", "policy_name": "fraud_orchestrator_policy",  "owner": "fraud_ops_team",   "description": "Routes fraud alerts and coordinates sub-agents."},
    {"agent_role": "transaction_analyst", "display_name": "Transaction Analyst",  "framework": "langgraph", "policy_name": "transaction_analyst_policy",  "owner": "fraud_ops_team",   "description": "Analyzes payment patterns and velocity to detect suspicious transactions."},
    {"agent_role": "account_profiler",    "display_name": "Account Profiler",     "framework": "langgraph", "policy_name": "account_profiler_policy",     "owner": "fraud_ops_team",   "description": "Profiles account-level risk signals. No access to transaction detail or PII."},
    {"agent_role": "kyc_specialist",      "display_name": "KYC Specialist",       "framework": "langgraph", "policy_name": "kyc_specialist_policy",       "owner": "fraud_ops_team",   "description": "Identity verification, sanctions screening, and adverse media review."},
    {"agent_role": "sar_generator",       "display_name": "SAR Generator",        "framework": "langgraph", "policy_name": "sar_generator_policy",        "owner": "fraud_ops_team",   "description": "Drafts Suspicious Activity Reports from processed agent outputs only."},
    {"agent_role": "analyst",             "display_name": "Portfolio Analyst",    "framework": None,        "policy_name": "analyst_read_only",           "owner": "analytics_team",   "description": "Reads portfolio, transaction, and credit data for analytical reporting."},
    {"agent_role": "risk_agent",          "display_name": "Risk Agent",           "framework": None,        "policy_name": "block_pii_external",          "owner": "risk_team",        "description": "Evaluates market and credit risk. Blocked from all PII sources."},
    {"agent_role": "compliance_agent",    "display_name": "Compliance Agent",     "framework": None,        "policy_name": "compliance_audit_trail",      "owner": "compliance_team",  "description": "Accesses compliance and trading data for regulatory reporting."},
]


def _seed_demo_agents(agent_registry_store, tenant_id: str) -> None:
    from autopil.models import AgentRegistryEntry
    now = datetime.now(timezone.utc)
    for a in _DEMO_AGENTS:
        try:
            entry = AgentRegistryEntry(
                agent_id=str(uuid.uuid4()),
                tenant_id=tenant_id,
                agent_role=a["agent_role"],
                display_name=a["display_name"],
                status="approved",
                version="1.0.0",
                framework=a["framework"],
                policy_name=a["policy_name"],
                owner=a["owner"],
                description=a["description"],
                created_by="seed",
                approved_by="seed",
                approved_at=now,
                created_at=now,
                updated_at=now,
            )
            agent_registry_store.create(entry, tenant_id)
        except Exception:
            pass


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="autopil-serve",
        description="AutoPIL API Server — context governance for autonomous agents",
    )
    parser.add_argument("--policy", default=os.environ.get("AUTOPIL_POLICY", DEFAULT_POLICY),
                        help="Path to policy YAML file")
    parser.add_argument("--db",     default=os.environ.get("AUTOPIL_DB", DEFAULT_DB),
                        help="Path to SQLite audit DB (ignored if DATABASE_URL is set)")
    parser.add_argument("--host",   default=os.environ.get("AUTOPIL_HOST", "0.0.0.0"),
                        help="Host to bind")
    parser.add_argument("--port",   default=int(os.environ.get("AUTOPIL_PORT", "8000")), type=int,
                        help="Port to listen on")
    args = parser.parse_args()

    try:
        import uvicorn
        from autopil.api import create_app
        from autopil.db import create_stores
        from autopil import telemetry
    except ImportError as e:
        raise SystemExit(
            f"\nMissing server dependencies: {e}\n"
            "Install with: pip install autopil[server]\n"
        ) from e

    database_url = os.environ.get("DATABASE_URL")

    print(f"\n  AutoPIL API Server")
    print(f"  Policy   : {args.policy}")
    if database_url:
        safe_url = database_url.split("@")[-1] if "@" in database_url else database_url
        print(f"  Database : postgres @ {safe_url}")
    else:
        print(f"  Database : sqlite @ {args.db}")

    # ── bootstrap tenant + superadmin key on first start ─────────────────────
    stores = create_stores(database_url=database_url, db_path=args.db)
    _, key_store, tenant_store = stores[0], stores[1], stores[2]
    agent_registry_store = stores[7]
    if tenant_store.count() == 0:
        tenant_id = tenant_store.create_tenant("default")
        _, plaintext = key_store.create_key("superadmin", tenant_id=tenant_id, is_superadmin=True)
        print(f"\n  ⚠  First start — created 'default' tenant and superadmin key:")
        print(f"     {plaintext}")
        print(f"     Save this — it will not be shown again.\n")
    elif key_store.count() == 0:
        tenants = tenant_store.list_tenants()
        tenant_id = tenants[0]["tenant_id"]
        _, plaintext = key_store.create_key("superadmin", tenant_id=tenant_id, is_superadmin=True)
        print(f"\n  ⚠  No API keys found. Generated superadmin key for tenant '{tenants[0]['name']}':")
        print(f"     {plaintext}")
        print(f"     Save this — it will not be shown again.\n")

    # ── seed demo agents for any tenant that has no agents yet ───────────────
    for _t in tenant_store.list_tenants():
        if not agent_registry_store.list_agents(_t["tenant_id"]):
            _seed_demo_agents(agent_registry_store, _t["tenant_id"])
    # Also seed for the literal 'default' tenant_id used by legacy keys
    if not agent_registry_store.list_agents("default"):
        _seed_demo_agents(agent_registry_store, "default")

    otel_on = telemetry.setup()
    if otel_on:
        print(f"  OTEL     : {os.environ.get('OTEL_EXPORTER_OTLP_ENDPOINT', 'console')}")

    print(f"  Docs     : http://localhost:{args.port}/docs\n")

    ttl_env = os.environ.get("AUTOPIL_SESSION_TTL_MINUTES")
    session_ttl = int(ttl_env) if ttl_env else None

    retention_env = os.environ.get("AUTOPIL_SESSION_RETENTION_DAYS")
    session_retention = int(retention_env) if retention_env else None

    cleanup_interval_env = os.environ.get("AUTOPIL_SESSION_CLEANUP_INTERVAL")
    session_cleanup_interval = int(cleanup_interval_env) if cleanup_interval_env else 3600

    app = create_app(
        policy_path=args.policy,
        audit_db=args.db,
        database_url=database_url,
        session_ttl_minutes=session_ttl,
        session_retention_days=session_retention,
        session_cleanup_interval=session_cleanup_interval,
    )
    uvicorn.run(app, host=args.host, port=args.port, reload=False)


if __name__ == "__main__":
    main()
