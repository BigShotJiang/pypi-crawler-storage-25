from datetime import datetime
from enum import Enum
from typing import Optional
from pydantic import BaseModel, Field
import uuid

from autopil.models import Decision, KeyScope, SensitivityLevel


# ── API Key schemas ───────────────────────────────────────────────────────────

class CreateKeyRequest(BaseModel):
    name:         str          = Field(..., description="Human-readable label for this key")
    scope:        KeyScope     = Field(KeyScope.ADMIN, description="Key permission scope")
    expires_days: Optional[int] = Field(None, description="Expiry in days; omit for no expiry")


class CreateKeyResponse(BaseModel):
    key_id:     str
    name:       str
    key:        str = Field(..., description="Plaintext key — shown once, store it now")
    created_at: str


class KeySummary(BaseModel):
    key_id:        str
    name:          str
    created_at:    str
    last_used:     Optional[str] = None
    is_active:     bool
    tenant_id:     str
    is_superadmin: bool = False
    scope:         str  = "admin"


# ── Tenant schemas ────────────────────────────────────────────────────────────

class CreateTenantRequest(BaseModel):
    name: str = Field(..., description="Unique tenant name (e.g. company slug)")


class TenantResponse(BaseModel):
    tenant_id:  str
    name:       str
    created_at: str
    is_active:  bool


class CreateTenantResponse(BaseModel):
    tenant_id:  str
    name:       str
    created_at: str
    admin_key:  str = Field(..., description="Initial admin key for this tenant — shown once")


# ── Quickstart schemas ───────────────────────────────────────────────────────

class QuickstartStatusResponse(BaseModel):
    completed: bool
    tenant_age_days: int


class QuickstartRunRequest(BaseModel):
    agent_role:        str             = Field(default="analyst",       description="Agent role to evaluate")
    source_id:         str             = Field(default="customer_data", description="Data source being accessed")
    sensitivity_level: SensitivityLevel = Field(default=SensitivityLevel.MEDIUM)


class QuickstartRunResponse(BaseModel):
    decision:    Decision
    policy_name: str
    reason:      str
    event_id:    str
    allowed:     bool


class QuickstartScenario(BaseModel):
    source_id:         str
    sensitivity_level: str
    description:       str

class QuickstartAgentItem(BaseModel):
    agent_role:     str
    display_name:   str
    policy_name:    str
    allow_scenario: QuickstartScenario
    deny_scenario:  QuickstartScenario

class QuickstartAgentsResponse(BaseModel):
    industry: str
    agents:   list[QuickstartAgentItem]


# ── Use case schemas ───────────────────────────────────────────────────────────

class UseCaseAgent(BaseModel):
    agent_role:   str
    display_name: str
    framework:    Optional[str] = None

class UseCaseItem(BaseModel):
    usecase_id:   str
    display_name: str
    description:  str
    industry:     str
    agents:       list[UseCaseAgent]
    step_count:   int

class UseCasesResponse(BaseModel):
    usecases: list[UseCaseItem]

class UseCaseRunRequest(BaseModel):
    usecase: str = "fraud_investigation"

class UseCaseStepResult(BaseModel):
    step:                 int
    agent_role:           str
    display_name:         str
    session_id:           str
    source_id:            str
    decision:             str
    policy_name:          str
    reason:               str
    event_id:             str
    is_isolation_attempt: bool
    description:          str

class UseCaseRunResponse(BaseModel):
    usecase:              str
    steps:                list[UseCaseStepResult]
    isolation_violations: int
    alert_fired:          bool
    summary:              str


# ── Request schemas ──────────────────────────────────────────────────────────

class EvaluateRequest(BaseModel):
    query: str
    agent_role: str
    user_id: str
    source_id: str
    sensitivity_level: SensitivityLevel = SensitivityLevel.MEDIUM
    session_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    task_type: Optional[str] = Field(default=None, description="Task context for task-level policy scoping")
    context_hash: Optional[str] = Field(
        default=None,
        description=(
            "SHA-256 hash of the data retrieved after the previous ALLOW decision "
            "in this session. When supplied on an ALLOW, it is chained into the "
            "session's accumulated context hash for end-to-end provenance."
        ),
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "query": "Retrieve customer credit score for loan underwriting",
                "agent_role": "underwriting_analyst",
                "user_id": "user_001",
                "source_id": "credit_bureau_scores",
                "sensitivity_level": "high",
                "session_id": "sess_abc123",
            }
        }
    }


# ── Response schemas ─────────────────────────────────────────────────────────

class EvaluateResponse(BaseModel):
    decision: Decision
    policy_name: str
    reason: str
    event_id: str
    session_id: str
    timestamp: datetime


class AuditEventResponse(BaseModel):
    event_id: str
    session_id: str
    agent_role: str
    user_id: str
    source_id: str
    query: str
    decision: Decision
    policy_name: str
    reason: str
    timestamp: datetime
    context_hash: Optional[str] = None
    sensitivity_level: Optional[str] = None
    source_type: str = "rest"
    catalog_enriched: bool = False
    catalog_connection_id: Optional[str] = None
    pii_masked: bool = False


class AuditTrailResponse(BaseModel):
    session_id: str
    total_events: int
    allowed: int
    denied: int
    events: list[AuditEventResponse]


class PolicySummary(BaseModel):
    name: str
    agent_role: str
    allowed_sources: list[str]
    denied_sources: list[str]
    max_sensitivity: str


class HealthResponse(BaseModel):
    status: str
    version: str
    git_sha: Optional[str] = None
    policy_file: str
    audit_db: str


class ReadyResponse(BaseModel):
    status: str          # "ready" or "degraded"
    db: str              # "ok" or error detail
    policies_loaded: int


class CreatePolicyRequest(BaseModel):
    name: str = Field(..., description="Unique policy name")
    agent_role: str = Field(..., description="Agent role this policy applies to")
    allowed_sources: list[str] = Field(default=[], description="Allowed data sources (empty = all non-denied)")
    denied_sources: list[str] = Field(default=[], description="Always-blocked data sources")
    max_sensitivity: str = Field(default="high", description="Sensitivity ceiling: low | medium | high | restricted")
    allowed_tasks: list[str] = Field(default=[], description="Tasks this role may perform (empty = all non-denied)")
    denied_tasks: list[str] = Field(default=[], description="Tasks always blocked for this role")
    industry: Optional[str] = Field(default=None, description="Industry vertical (e.g. financial_services, healthcare)")
    category: Optional[str] = Field(default=None, description="Functional category within the industry (e.g. consumer_banking)")
    description: Optional[str] = Field(default=None, description="One-line summary of what this policy governs")


class UpdatePolicyRequest(BaseModel):
    agent_role: str
    allowed_sources: list[str] = []
    denied_sources: list[str] = []
    max_sensitivity: str = "high"
    allowed_tasks: list[str] = []
    denied_tasks: list[str] = []
    industry: Optional[str] = None
    category: Optional[str] = None
    description: Optional[str] = None


class PolicyDetailResponse(BaseModel):
    policy_id: str
    name: str
    agent_role: str
    allowed_sources: list[str]
    denied_sources: list[str]
    max_sensitivity: str
    allowed_tasks: list[str] = []
    denied_tasks: list[str] = []
    industry: Optional[str] = None
    category: Optional[str] = None
    version: int
    created_at: str
    updated_at: str
    changed_by: Optional[str] = None
    user_modified: bool = False
    description: Optional[str] = None


class PolicyVersionResponse(BaseModel):
    version_id: str
    version: int
    agent_role: str
    allowed_sources: list[str]
    denied_sources: list[str]
    max_sensitivity: str
    allowed_tasks: list[str] = []
    denied_tasks: list[str] = []
    industry: Optional[str] = None
    category: Optional[str] = None
    changed_by: Optional[str] = None
    changed_at: str


# ── Lineage schemas ───────────────────────────────────────────────────────────

class RecordActionRequest(BaseModel):
    event_id:      str  = Field(..., description="audit event_id that drove this action")
    session_id:    str  = Field(..., description="session_id from the audit event")
    action_type:   str  = Field(..., description="e.g. 'loan_decision', 'tool_call', 'response'")
    action_detail: dict = Field(default={}, description="Free-form JSON describing the action")
    outcome:       Optional[str] = Field(default=None, description="Optional outcome summary")


class AgentActionResponse(BaseModel):
    action_id:     str
    event_id:      str
    session_id:    str
    agent_role:    str
    action_type:   str
    action_detail: dict
    outcome:       Optional[str]
    timestamp:     datetime


class LineageResponse(BaseModel):
    event_id: str
    event:    AuditEventResponse
    actions:  list[AgentActionResponse]


# ── Session schemas ───────────────────────────────────────────────────────────

class RevocationReason(str, Enum):
    admin_action          = "admin_action"
    fraud_detected        = "fraud_detected"
    user_logged_out       = "user_logged_out"
    policy_violation      = "policy_violation"
    compromised_credential = "compromised_credential"
    bulk_revocation       = "bulk_revocation"


class SessionResponse(BaseModel):
    session_id:         str
    agent_role:         str
    user_id:            str
    created_at:         str
    last_active:        str
    expires_at:         Optional[str] = None
    ttl_minutes:        Optional[int] = None
    is_revoked:         bool
    status:             str  # "active" | "expired" | "revoked"
    context_hash:       Optional[str] = None
    revocation_reason:  Optional[str] = None
    revoked_at:         Optional[str] = None


# ── Alert schemas ─────────────────────────────────────────────────────────────

class AlertRuleType(str, Enum):
    denial_spike        = "denial_spike"
    new_source          = "new_source"
    isolation_violation = "isolation_violation"
    high_deny_rate      = "high_deny_rate"


class CreateAlertRuleRequest(BaseModel):
    name:             str           = Field(..., description="Human-readable label for this rule")
    rule_type:        AlertRuleType
    threshold:        int           = Field(default=5,  ge=1, description="Count (denial_spike) or percent (high_deny_rate) to trigger")
    window_minutes:   int           = Field(default=60, ge=1, description="Look-back window in minutes")
    cooldown_minutes: int           = Field(default=60, ge=0, description="Minimum minutes between consecutive fires (0 = no cooldown)")
    webhook_url:      Optional[str] = Field(default=None, description="HTTP endpoint to POST alert payload")
    email:            Optional[str] = Field(default=None, description="Email address (requires SMTP_HOST env var)")


class UpdateAlertRuleRequest(BaseModel):
    name:             Optional[str]  = None
    threshold:        Optional[int]  = Field(default=None, ge=1)
    window_minutes:   Optional[int]  = Field(default=None, ge=1)
    cooldown_minutes: Optional[int]  = Field(default=None, ge=0)
    webhook_url:      Optional[str]  = None
    email:            Optional[str]  = None
    is_enabled:       Optional[bool] = None


class AlertRuleResponse(BaseModel):
    rule_id:          str
    name:             str
    rule_type:        str
    threshold:        int
    window_minutes:   int
    cooldown_minutes: int
    webhook_url:      Optional[str] = None
    email:            Optional[str] = None
    is_enabled:       bool
    created_at:       str
    last_fired_at:    Optional[str] = None


class AlertDeliveryResponse(BaseModel):
    delivery_id: str
    rule_id:     str
    rule_name:   str
    rule_type:   str
    fired_at:    str
    detail:      dict
    status:      str
    error:       Optional[str] = None


# ── Agent Registry schemas ────────────────────────────────────────────────────

class RegisterAgentRequest(BaseModel):
    agent_role:   str           = Field(..., description="Agent role — must match a policy agent_role")
    display_name: str           = Field(..., description="Human-readable name for this agent")
    description:  Optional[str] = Field(default=None, description="What this agent does")
    owner:        Optional[str] = Field(default=None, description="Team or person responsible")
    framework:    Optional[str] = Field(default=None, description="langgraph | openai_agents | langchain | etc.")
    policy_name:  Optional[str] = Field(default=None, description="Policy governing this agent")
    version:      str           = Field(default="1.0.0", description="Semantic version")


class UpdateAgentRequest(BaseModel):
    display_name: Optional[str] = None
    description:  Optional[str] = None
    owner:        Optional[str] = None
    framework:    Optional[str] = None
    policy_name:  Optional[str] = None
    version:      Optional[str] = None


class UpdateAgentStatusRequest(BaseModel):
    status: str = Field(
        ..., description="New status: pending_approval | approved | deprecated"
    )


class AgentRegistryEntryResponse(BaseModel):
    agent_id:       str
    agent_role:     str
    display_name:   str
    status:         str
    version:        str
    created_at:     str
    updated_at:     str
    description:    Optional[str]   = None
    owner:          Optional[str]   = None
    framework:      Optional[str]   = None
    policy_name:    Optional[str]   = None
    created_by:     Optional[str]   = None
    approved_by:    Optional[str]   = None
    approved_at:    Optional[str]   = None
    last_active:    Optional[str]   = None
    event_count_7d: int             = 0
    deny_rate_7d:   float           = 0.0


class AgentRegistryStatsResponse(BaseModel):
    total:              int
    approved:           int
    draft:              int
    pending_approval:   int
    deprecated:         int


# ── Key rotation ──────────────────────────────────────────────────────────────

class RotateKeyResponse(BaseModel):
    key_id:     str
    key:        str
    name:       str
    created_at: str


# ── Generic action responses ─────────────────────────────────────────────────

class StatusResponse(BaseModel):
    """Generic response for delete / deactivate / revoke actions."""
    status: str


class ReloadPoliciesResponse(BaseModel):
    status: str
    policies_imported: int
    policies_skipped: int


class AuditStatsResponse(BaseModel):
    total_events:    int
    allowed:         int
    denied:          int
    active_sessions: int
    top_roles:       list[list]             # [[role, count], ...]
    top_sources:     list[list]             # [[source_id, count], ...]
    recent_events:   list[AuditEventResponse]
    by_source_type:  dict[str, dict]


class WebhookAcceptedResponse(BaseModel):
    status:         str
    connection_id:  str
    assets_queued:  int


# ── Audit chain + retention ───────────────────────────────────────────────────

class ChainVerifyResponse(BaseModel):
    valid:      bool
    total:      int
    chained:    int
    legacy:     int
    broken_at:  Optional[str] = None


class AuditRetentionResponse(BaseModel):
    retention_days: int
    policy:         str
    anchor:         Optional[dict] = None


class RetentionSettingsResponse(BaseModel):
    retention_days:         int
    session_retention_days: int
    audit_policy:           str
    session_policy:         str


class UpdateRetentionSettingsRequest(BaseModel):
    retention_days:         Optional[int] = None
    session_retention_days: Optional[int] = None
