"""
Backwards-compatible import shim.

The API uses KeyStore(db_path) directly — this keeps that interface working
while the real implementation lives in autopil.db.sqlite.
"""

from autopil.db.sqlite import SQLiteKeyStore as KeyStore
from autopil.db.sqlite import KEY_PREFIX

__all__ = ["KeyStore", "KEY_PREFIX"]
