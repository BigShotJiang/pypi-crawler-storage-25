"""
AutoPIL BedrockGuard — context governance for AWS Bedrock Agents.

Integrates AutoPIL's policy enforcement, audit logging, and lineage tracking
with agents built on Amazon Bedrock Agent Runtime.

Two integration patterns:

1. Decorator pattern:

       from autopil.bedrock_guard import BedrockGuard, SensitivityLevel

       guard = BedrockGuard(policy_path="policies/", audit_db="autopil.db")

       @guard.protect(
           agent_role="claims_agent",
           user_id="agent_01",
           source_id="claims_db",
           sensitivity_level=SensitivityLevel.HIGH,
           session_id=SESSION_ID,
       )
       def retrieve_claim(query: str) -> dict:
           return claims_index.search(query)

2. Client-wrapping pattern — wraps a boto3 Bedrock Agent Runtime client:

       import boto3
       from autopil.bedrock_guard import BedrockGuard

       guard = BedrockGuard(policy_path="policies/", audit_db="autopil.db")
       bedrock_rt = boto3.client("bedrock-agent-runtime", region_name="us-east-1")

       safe_client = guard.wrap_invoke_agent(
           bedrock_rt,
           agent_role="claims_agent",
           user_id="agent_01",
           source_id="claims_db",
           sensitivity_level=SensitivityLevel.HIGH,
           session_id=SESSION_ID,
       )
       response = safe_client.invoke_agent(
           agentId="ABCDEF1234",
           agentAliasId="TSTALIASID",
           sessionId=SESSION_ID,
           inputText="What is the status of claim #4821?",
       )

All decisions are stamped source_type='bedrock' in the audit log.
"""

from __future__ import annotations

from typing import Any, Optional

from .guard import ContextGuard
from .models import SensitivityLevel


class BedrockGuard(ContextGuard):
    """
    AutoPIL ContextGuard for AWS Bedrock Agents.

    Drop-in replacement for ContextGuard that tags every audit event
    with source_type='bedrock'.

    Usage:
        from autopil.bedrock_guard import BedrockGuard

        guard = BedrockGuard(policy_path="policies/", audit_db="autopil.db")

        @guard.protect(
            agent_role="claims_agent",
            user_id="u1",
            source_id="claims_db",
        )
        def retrieve_claim(query: str) -> dict:
            return claims_index.search(query)

    Session TTL — set at the guard level, applies to all protect() calls:
        guard = BedrockGuard(policy_path="policies/", audit_db="autopil.db",
                             session_ttl_minutes=60)
    """

    _source_type: str = "bedrock"

    def wrap_invoke_agent(
        self,
        client: Any,
        *,
        agent_role: str,
        user_id: str,
        source_id: str,
        sensitivity_level: SensitivityLevel = SensitivityLevel.MEDIUM,
        session_id: Optional[str] = None,
    ) -> Any:
        """
        Wrap a boto3 bedrock-agent-runtime client so that every .invoke_agent()
        call is policy-evaluated before the request is sent to AWS.

        Returns a thin proxy that delegates all non-invoke_agent attributes to
        the original client. Raises PermissionError on DENY.

        inputText is extracted as the query for policy evaluation.
        All other invoke_agent kwargs are forwarded unchanged.

        Args:
            client:            A boto3 bedrock-agent-runtime client.
            agent_role:        The agent's declared role.
            user_id:           Identifier for the invoking user or agent.
            source_id:         The knowledge base / data source being accessed.
            sensitivity_level: Data sensitivity level.
            session_id:        Session identifier (auto-generated if omitted).

        Example:
            import boto3
            bedrock_rt = boto3.client("bedrock-agent-runtime")
            safe = guard.wrap_invoke_agent(
                bedrock_rt,
                agent_role="claims_agent",
                user_id="u1",
                source_id="claims_db",
                sensitivity_level=SensitivityLevel.HIGH,
            )
            resp = safe.invoke_agent(
                agentId="ABCDEF1234",
                agentAliasId="TSTALIASID",
                sessionId="sess-001",
                inputText="Show open claims for policy P-99",
            )
        """
        guard = self
        original_client = client

        def _invoke_impl(input_text: str, **invoke_kwargs: Any) -> Any:
            return original_client.invoke_agent(inputText=input_text, **invoke_kwargs)

        protected = guard.protect(
            agent_role=agent_role,
            user_id=user_id,
            source_id=source_id,
            sensitivity_level=sensitivity_level,
            session_id=session_id,
        )(_invoke_impl)

        class _GuardedBedrockClient:
            def invoke_agent(self, *, inputText: str = "", **kwargs: Any) -> Any:
                return protected(inputText, **kwargs)

            def __getattr__(self, name: str) -> Any:
                return getattr(original_client, name)

        return _GuardedBedrockClient()

    def wrap_invoke_agent_async(
        self,
        client: Any,
        *,
        agent_role: str,
        user_id: str,
        source_id: str,
        sensitivity_level: SensitivityLevel = SensitivityLevel.MEDIUM,
        session_id: Optional[str] = None,
    ) -> Any:
        """
        Wrap an aioboto3 bedrock-agent-runtime async client so that every
        .invoke_agent() call is policy-evaluated before the request is sent.

        Use this when your agent pipeline is async end-to-end (e.g. with aioboto3).

        Example:
            import aioboto3
            session = aioboto3.Session()
            async with session.client("bedrock-agent-runtime") as bedrock_rt:
                safe = guard.wrap_invoke_agent_async(
                    bedrock_rt,
                    agent_role="claims_agent",
                    user_id="u1",
                    source_id="claims_db",
                )
                resp = await safe.invoke_agent(
                    agentId="ABCDEF1234",
                    agentAliasId="TSTALIASID",
                    sessionId="sess-001",
                    inputText="Show open claims",
                )
        """
        guard = self
        original_client = client

        async def _invoke_impl_async(input_text: str, **invoke_kwargs: Any) -> Any:
            if hasattr(original_client, "invoke_agent"):
                result = original_client.invoke_agent(inputText=input_text, **invoke_kwargs)
                # Support both coroutines (aioboto3) and regular returns (sync mock)
                if hasattr(result, "__await__"):
                    return await result
                return result
            raise AttributeError("client has no invoke_agent method")

        protected = guard.protect_async(
            agent_role=agent_role,
            user_id=user_id,
            source_id=source_id,
            sensitivity_level=sensitivity_level,
            session_id=session_id,
        )(_invoke_impl_async)

        class _AsyncGuardedBedrockClient:
            async def invoke_agent(self, *, inputText: str = "", **kwargs: Any) -> Any:
                return await protected(inputText, **kwargs)

            def __getattr__(self, name: str) -> Any:
                return getattr(original_client, name)

        return _AsyncGuardedBedrockClient()
