"""
AutoPIL LlamaIndexGuard — context governance for LlamaIndex agents.

Integrates AutoPIL's policy enforcement, audit logging, and lineage tracking
with agents and query pipelines built on LlamaIndex.

Two integration patterns:

1. Decorator pattern — wraps individual retrieval functions:

       from autopil.llamaindex_guard import LlamaIndexGuard, SensitivityLevel

       guard = LlamaIndexGuard(policy_path="policies/", audit_db="autopil.db")

       @guard.protect(
           agent_role="research_agent",
           user_id="agent_01",
           source_id="clinical_notes",
           sensitivity_level=SensitivityLevel.HIGH,
           session_id=SESSION_ID,
       )
       def query_index(query_str: str) -> list:
           return index.as_retriever().retrieve(query_str)

2. Query engine wrapping — wraps an existing LlamaIndex QueryEngine:

       from autopil.llamaindex_guard import LlamaIndexGuard

       guard = LlamaIndexGuard(policy_path="policies/", audit_db="autopil.db")
       safe_engine = guard.wrap_query_engine(
           engine=vector_index.as_query_engine(),
           agent_role="research_agent",
           user_id="agent_01",
           source_id="clinical_notes",
           sensitivity_level=SensitivityLevel.HIGH,
           session_id=SESSION_ID,
       )
       # safe_engine.query() enforces policy before every retrieval

All decisions are stamped source_type='llamaindex' in the audit log.
"""

from __future__ import annotations

from typing import Any, Optional

from .guard import ContextGuard
from .models import SensitivityLevel


class LlamaIndexGuard(ContextGuard):
    """
    AutoPIL ContextGuard for LlamaIndex agents and query engines.

    Drop-in replacement for ContextGuard that tags every audit event
    with source_type='llamaindex'.

    Usage:
        from autopil.llamaindex_guard import LlamaIndexGuard

        guard = LlamaIndexGuard(policy_path="policies/", audit_db="autopil.db")

        @guard.protect(
            agent_role="research_agent",
            user_id="u1",
            source_id="clinical_notes",
            sensitivity_level=SensitivityLevel.HIGH,
        )
        def retrieve(query_str: str) -> list:
            return index.as_retriever().retrieve(query_str)

    Session TTL — set at the guard level, applies to all protect() calls:
        guard = LlamaIndexGuard(policy_path="policies/", audit_db="autopil.db",
                                session_ttl_minutes=60)
    """

    _source_type: str = "llamaindex"

    def wrap_query_engine(
        self,
        engine: Any,
        *,
        agent_role: str,
        user_id: str,
        source_id: str,
        sensitivity_level: SensitivityLevel = SensitivityLevel.MEDIUM,
        session_id: Optional[str] = None,
    ) -> Any:
        """
        Wrap a LlamaIndex QueryEngine so that every .query() call is
        policy-evaluated before retrieval occurs.

        Returns a thin proxy that delegates to the original engine on ALLOW
        and raises PermissionError on DENY.

        Args:
            engine:            A LlamaIndex BaseQueryEngine (or any object
                               with a .query(str) method).
            agent_role:        The agent's declared role.
            user_id:           Identifier for the invoking user or agent.
            source_id:         The index / data source being queried.
            sensitivity_level: Data sensitivity level.
            session_id:        Session identifier (auto-generated if omitted).

        Example:
            safe_engine = guard.wrap_query_engine(
                engine=index.as_query_engine(),
                agent_role="research_agent",
                user_id="u1",
                source_id="clinical_notes",
                sensitivity_level=SensitivityLevel.HIGH,
            )
            response = safe_engine.query("What medications were prescribed?")
        """
        guard = self

        class _GuardedQueryEngine:
            def __init__(self):
                self._engine = engine
                self._protected_query = guard.protect(
                    agent_role=agent_role,
                    user_id=user_id,
                    source_id=source_id,
                    sensitivity_level=sensitivity_level,
                    session_id=session_id,
                )(engine.query)

            def query(self, query_str: str) -> Any:
                return self._protected_query(query_str)

            def __getattr__(self, name: str) -> Any:
                return getattr(self._engine, name)

        return _GuardedQueryEngine()

    def wrap_query_engine_async(
        self,
        engine: Any,
        *,
        agent_role: str,
        user_id: str,
        source_id: str,
        sensitivity_level: SensitivityLevel = SensitivityLevel.MEDIUM,
        session_id: Optional[str] = None,
    ) -> Any:
        """
        Wrap a LlamaIndex QueryEngine so that every .aquery() call is
        policy-evaluated before retrieval occurs.

        Returns a proxy with both .aquery() (async) and .query() (sync) methods.
        Use when your LlamaIndex pipeline is async end-to-end.

        Example:
            safe = guard.wrap_query_engine_async(
                engine=index.as_query_engine(),
                agent_role="research_agent",
                user_id="u1",
                source_id="clinical_notes",
                sensitivity_level=SensitivityLevel.HIGH,
            )
            response = await safe.aquery("What medications were prescribed?")
        """
        guard = self

        class _AsyncGuardedQueryEngine:
            def __init__(self):
                self._engine = engine
                # Pre-build both decorators at construction time so the same
                # session_id is reused consistently across all calls, whether
                # the caller uses .aquery() (async) or .query() (sync).
                self._protected_aquery = guard.protect_async(
                    agent_role=agent_role,
                    user_id=user_id,
                    source_id=source_id,
                    sensitivity_level=sensitivity_level,
                    session_id=session_id,
                )(self._aquery_impl)
                self._protected_query = guard.protect(
                    agent_role=agent_role,
                    user_id=user_id,
                    source_id=source_id,
                    sensitivity_level=sensitivity_level,
                    session_id=session_id,
                )(engine.query)

            async def _aquery_impl(self, query_str: str) -> Any:
                if hasattr(self._engine, "aquery"):
                    return await self._engine.aquery(query_str)
                return self._engine.query(query_str)

            async def aquery(self, query_str: str) -> Any:
                return await self._protected_aquery(query_str)

            def query(self, query_str: str) -> Any:
                return self._protected_query(query_str)

            def __getattr__(self, name: str) -> Any:
                return getattr(self._engine, name)

        return _AsyncGuardedQueryEngine()
