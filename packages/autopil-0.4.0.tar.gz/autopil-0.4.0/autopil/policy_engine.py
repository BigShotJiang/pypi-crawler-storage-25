from pathlib import Path
from typing import Optional
import yaml

_UNSET = object()  # sentinel for "no decay rule matched"

from .models import ContextRequest, Decision, SENSITIVITY_ORDER


class PolicyEngine:
    def __init__(self, policy_path: str):
        self.policies = self._load(policy_path)

    @classmethod
    def from_list(cls, policies: list) -> "PolicyEngine":
        """Build a PolicyEngine directly from a list of policy dicts (e.g. from DB)."""
        engine = cls.__new__(cls)
        engine.policies = policies
        return engine

    def _load(self, path: str) -> list:
        p = Path(path)
        files = sorted(p.glob("**/*.yaml")) if p.is_dir() else [p]
        policies = []
        for f in files:
            with open(f) as fh:
                data = yaml.safe_load(fh)
            # Inject industry and category from directory structure:
            # policies/<industry>/<category>.yaml
            parts = f.relative_to(p).parts if p.is_dir() else ()
            industry = parts[0] if len(parts) >= 2 else None
            category = Path(parts[1]).stem if len(parts) >= 2 else (Path(parts[0]).stem if len(parts) == 1 else None)
            for pol in data.get("policies", []):
                pol.setdefault("industry", industry)
                pol.setdefault("category", category)
                policies.append(pol)
        return policies

    def evaluate(self, request: ContextRequest) -> tuple[Decision, str, str]:
        """
        Returns (decision, policy_name, reason).
        Deny-by-default — if no policy matches, access is denied.

        Sensitivity ceiling is the more restrictive of:
          - policy max_sensitivity (static)
          - the applicable sensitivity_decay rule for the session's current age
        """
        for policy in self.policies:
            if policy["agent_role"] != request.agent_role:
                continue

            # Denied sources take priority
            denied = policy.get("denied_sources", [])
            if request.source_id in denied:
                return (
                    Decision.DENY,
                    policy["name"],
                    f"Source '{request.source_id}' is explicitly denied for role '{request.agent_role}'",
                )

            # Task-type checks (only when task_type is provided)
            if request.task_type is not None:
                denied_tasks = policy.get("denied_tasks", [])
                if request.task_type in denied_tasks:
                    return (
                        Decision.DENY,
                        policy["name"],
                        f"Task '{request.task_type}' is explicitly denied for role '{request.agent_role}'",
                    )
                allowed_tasks = policy.get("allowed_tasks", [])
                if allowed_tasks and request.task_type not in allowed_tasks:
                    return (
                        Decision.DENY,
                        policy["name"],
                        f"Task '{request.task_type}' is not in the allowed task list for role '{request.agent_role}'",
                    )

            # Allowed sources — if list exists, source must be in it
            allowed = policy.get("allowed_sources", [])
            if allowed and request.source_id not in allowed:
                return (
                    Decision.DENY,
                    policy["name"],
                    f"Source '{request.source_id}' is not in the allowed list for role '{request.agent_role}'",
                )

            # Sensitivity ceiling: static ceiling, tightened by decay if session age is known
            static_ceiling = policy.get("max_sensitivity", "restricted")
            effective_ceiling, decay_rule = self._effective_sensitivity_ceiling(
                policy, static_ceiling, request.session_age_minutes
            )

            req_level = SENSITIVITY_ORDER.index(request.sensitivity_level.value)
            max_level = SENSITIVITY_ORDER.index(effective_ceiling)
            if req_level > max_level:
                if decay_rule:
                    reason = (
                        f"Data sensitivity '{request.sensitivity_level.value}' exceeds "
                        f"effective ceiling '{effective_ceiling}' for role '{request.agent_role}' "
                        f"— session is {request.session_age_minutes}m old "
                        f"(decay rule: after {decay_rule['after_minutes']}m → {decay_rule['max_sensitivity']})"
                    )
                else:
                    reason = (
                        f"Data sensitivity '{request.sensitivity_level.value}' exceeds "
                        f"ceiling '{effective_ceiling}' for role '{request.agent_role}'"
                    )
                return Decision.DENY, policy["name"], reason

            return Decision.ALLOW, policy["name"], "Access granted"

        return (
            Decision.DENY,
            "default_deny",
            f"No matching policy for agent role '{request.agent_role}' — denied by default",
        )

    # ── internal helpers ─────────────────────────────────────────────────────

    @staticmethod
    def _effective_sensitivity_ceiling(
        policy: dict,
        static_ceiling: str,
        session_age_minutes: Optional[int],
    ) -> tuple[str, Optional[dict]]:
        """
        Return (effective_ceiling, matched_decay_rule).

        The effective ceiling is the more restrictive of the static policy ceiling
        and the applicable decay rule for the current session age.

        Decay rules are evaluated in ascending threshold order; the highest
        threshold that has been exceeded defines the ceiling. If session_age_minutes
        is None or no decay schedule is defined, the static ceiling is returned
        and matched_decay_rule is None.
        """
        decay_schedule = policy.get("sensitivity_decay", [])
        if not decay_schedule or session_age_minutes is None:
            return static_ceiling, None

        # Sort ascending so we walk from smallest threshold to largest
        sorted_rules = sorted(decay_schedule, key=lambda r: r["after_minutes"])

        matched_rule = None
        for rule in sorted_rules:
            if session_age_minutes >= rule["after_minutes"]:
                matched_rule = rule

        if matched_rule is None:
            return static_ceiling, None

        decay_ceiling = matched_rule["max_sensitivity"]
        # Pick the more restrictive of static ceiling vs decay ceiling
        if SENSITIVITY_ORDER.index(decay_ceiling) < SENSITIVITY_ORDER.index(static_ceiling):
            return decay_ceiling, matched_rule
        return static_ceiling, None  # static is already as tight or tighter; decay has no effect

    def get_session_ttl(self, agent_role: str, fallback: Optional[int] = None) -> Optional[int]:
        """
        Return the session TTL (minutes) for an agent role.

        Precedence:
          1. session_ttl_minutes field in the matching policy (most specific)
          2. fallback argument — typically the global AUTOPIL_SESSION_TTL_MINUTES
          3. None — no expiry

        Only the first matching policy for the role is consulted (same lookup
        order as evaluate()).
        """
        for policy in self.policies:
            if policy["agent_role"] == agent_role:
                ttl = policy.get("session_ttl_minutes")
                if ttl is not None:
                    return int(ttl)
                return fallback
        return fallback
