"""
PII masking for audit events.

When AUTOPIL_LOG_PII_MASK=true, sensitive fields are replaced before DB write:
  - query     → sha256:<16-char hex>  (tenant-salted SHA-256)
  - user_id   → uid:<16-char hex>     (tenant-salted SHA-256, consistent within tenant)
  - reason    → query=<value> substrings are hashed; rest of reason is preserved intact

The chain hash (context_hash) is NOT affected — masking happens after chain hash
computation, before the INSERT, so chain integrity is preserved.

Salt derivation: AUTOPIL_SECRET_KEY + ":" + tenant_id
"""

import hashlib
import os
import re
from dataclasses import replace

from autopil.models import AuditEvent


def _get_salt(tenant_id: str) -> bytes:
    secret = os.environ.get("AUTOPIL_SECRET_KEY", "autopil-default-salt")
    return f"{secret}:{tenant_id}".encode()


def _hash_field(value: str, salt: bytes, prefix: str) -> str:
    h = hashlib.sha256(salt + value.encode()).hexdigest()[:16]
    return f"{prefix}:{h}"


def _mask_reason(reason: str, salt: bytes) -> str:
    """Replace query=<value> in reason with query=sha256:<hash>. All other text is preserved."""
    def replace_match(m: re.Match) -> str:
        val = m.group(1)
        h = hashlib.sha256(salt + val.encode()).hexdigest()[:16]
        return f"query=sha256:{h}"
    return re.sub(r"query=([^,\n]+)", replace_match, reason)


def mask_event(event: AuditEvent, tenant_id: str) -> AuditEvent:
    """Return a new AuditEvent with PII fields masked. Original event is not modified."""
    salt = _get_salt(tenant_id)
    return replace(
        event,
        query=_hash_field(event.query, salt, "sha256"),
        user_id=_hash_field(event.user_id, salt, "uid"),
        reason=_mask_reason(event.reason, salt),
        pii_masked=True,
    )
