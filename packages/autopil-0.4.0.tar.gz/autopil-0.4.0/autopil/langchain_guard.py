"""
AutoPIL LangChainGuard — context governance for LangChain agents.

Integrates AutoPIL's policy enforcement, audit logging, and lineage tracking
with agents built on LangChain / LangGraph.

Two integration patterns:

1. Decorator pattern — wraps individual tool functions before the agent calls them:

       from autopil.langchain_guard import LangChainGuard, SensitivityLevel

       guard = LangChainGuard(policy_path="policies/", audit_db="autopil.db")

       @guard.protect(
           agent_role="loan_agent",
           user_id="agent_01",
           source_id="account_summaries",
           sensitivity_level=SensitivityLevel.MEDIUM,
           session_id=SESSION_ID,
       )
       def get_account_summary(customer_id: str) -> dict:
           return db.query(customer_id)

2. Tool-wrapping pattern — wraps an existing LangChain BaseTool in-place:

       from langchain.tools import Tool
       from autopil.langchain_guard import LangChainGuard

       guard = LangChainGuard(policy_path="policies/", audit_db="autopil.db")
       raw_tool = Tool(name="account_lookup", func=lookup_fn, description="...")
       guarded  = guard.wrap_tool(
           raw_tool,
           agent_role="loan_agent",
           user_id="agent_01",
           source_id="account_summaries",
           sensitivity_level=SensitivityLevel.MEDIUM,
           session_id=SESSION_ID,
       )
       # Pass guarded to your LangChain agent; it raises PermissionError on DENY

All decisions are stamped source_type='langchain' in the audit log, enabling
per-channel visibility in the AutoPIL dashboard.
"""

from __future__ import annotations

from typing import Any, Callable, Optional

from .guard import ContextGuard
from .models import SensitivityLevel


class LangChainGuard(ContextGuard):
    """
    AutoPIL ContextGuard for LangChain / LangGraph agents.

    Drop-in replacement for ContextGuard that tags every audit event
    with source_type='langchain'.

    Usage:
        from autopil.langchain_guard import LangChainGuard

        guard = LangChainGuard(policy_path="policies/", audit_db="autopil.db")

        @guard.protect(agent_role="loan_agent", user_id="u1", source_id="credit_scores")
        def get_credit_score(customer_id: str) -> dict:
            return vectorstore.similarity_search(customer_id)

    Session TTL — set at the guard level, applies to all protect() calls:
        guard = LangChainGuard(policy_path="policies/", audit_db="autopil.db",
                               session_ttl_minutes=60)
    """

    _source_type: str = "langchain"

    def wrap_tool(
        self,
        tool: Any,
        *,
        agent_role: str,
        user_id: str,
        source_id: str,
        sensitivity_level: SensitivityLevel = SensitivityLevel.MEDIUM,
        session_id: Optional[str] = None,
    ) -> Any:
        """
        Wrap a LangChain BaseTool's _run method with AutoPIL policy enforcement.

        Returns the same tool object with its _run patched in-place.
        Raises PermissionError at tool-call time on DENY.

        Args:
            tool:              A LangChain BaseTool (or any object with a callable _run).
            agent_role:        The agent's declared role.
            user_id:           Identifier for the invoking user or agent.
            source_id:         The data source the tool represents.
            sensitivity_level: Data sensitivity level.
            session_id:        Session identifier (auto-generated if omitted).

        Returns:
            The same tool object with _run wrapped.

        Example:
            from langchain.tools import Tool
            raw = Tool(name="account_lookup", func=lookup, description="...")
            guarded = guard.wrap_tool(raw, agent_role="loan_agent",
                                      user_id="u1", source_id="accounts")
        """
        original_run = tool._run

        protected_run = self.protect(
            agent_role=agent_role,
            user_id=user_id,
            source_id=source_id,
            sensitivity_level=sensitivity_level,
            session_id=session_id,
        )(original_run)

        tool._run = protected_run
        return tool

    def wrap_tool_async(
        self,
        tool: Any,
        *,
        agent_role: str,
        user_id: str,
        source_id: str,
        sensitivity_level: SensitivityLevel = SensitivityLevel.MEDIUM,
        session_id: Optional[str] = None,
    ) -> Any:
        """
        Wrap a LangChain BaseTool's _arun method with AutoPIL policy enforcement.

        Returns the same tool object with its _arun patched in-place.
        Use this alongside wrap_tool() when your LangChain agent runs in an
        async context (e.g. with ainvoke() or arun()).

        If the tool does not define _arun, a default async wrapper is added
        that delegates to the protected _run.

        Example:
            guard.wrap_tool_async(tool, agent_role="loan_agent",
                                  user_id="u1", source_id="accounts")
            result = await tool._arun("query")
        """
        if hasattr(tool, "_arun") and callable(tool._arun):
            original_arun = tool._arun
        else:
            # Fall back: create an async wrapper around _run
            _sync_run = tool._run
            async def original_arun(*args: Any, **kwargs: Any) -> Any:
                return _sync_run(*args, **kwargs)

        tool._arun = self.protect_async(
            agent_role=agent_role,
            user_id=user_id,
            source_id=source_id,
            sensitivity_level=sensitivity_level,
            session_id=session_id,
        )(original_arun)
        return tool
