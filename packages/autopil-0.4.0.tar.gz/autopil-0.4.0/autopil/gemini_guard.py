"""
AutoPIL GeminiGuard — context governance for Google Gemini agents.

Integrates AutoPIL's policy enforcement, audit logging, and lineage tracking
with agents built on the Google Gemini API (google-generativeai or Vertex AI).

Two integration patterns:

1. Decorator pattern — wraps individual tool functions called by the agent:

       from autopil.gemini_guard import GeminiGuard, SensitivityLevel

       guard = GeminiGuard(policy_path="policies/", audit_db="autopil.db")

       @guard.protect(
           agent_role="loan_agent",
           user_id="agent_01",
           source_id="account_summaries",
           sensitivity_level=SensitivityLevel.MEDIUM,
           session_id=SESSION_ID,
       )
       def get_account_summary(customer_id: str) -> dict:
           return db.query(customer_id)

   Then register the unwrapped function signature with Gemini and dispatch
   through the protected version in your tool-call loop:

       # Gemini function-call loop
       response = model.generate_content(prompt)
       part = response.candidates[0].content.parts[0]
       if part.function_call:
           fc = part.function_call
           if fc.name == "get_account_summary":
               result = get_account_summary(**fc.args)   # AutoPIL enforces here

2. Inline guard pattern — useful when you don't own the retrieval function:

       result = guard.call_if_allowed(
           fn=my_retrieval_fn,
           agent_role="loan_agent",
           user_id="agent_01",
           source_id="credit_scores",
           sensitivity_level=SensitivityLevel.HIGH,
           session_id=SESSION_ID,
           fn_args={"customer_id": "cust_001"},
       )

All decisions are stamped source_type='gemini' in the audit log, enabling
per-channel visibility in the AutoPIL dashboard.
"""

from __future__ import annotations

from typing import Any, Callable, Optional

from .guard import ContextGuard
from .models import SensitivityLevel


class GeminiGuard(ContextGuard):
    """
    AutoPIL ContextGuard for Google Gemini agents.

    Drop-in replacement for ContextGuard that tags every audit event
    with source_type='gemini', giving Gemini agents their own channel
    in dashboard charts, stat cards, and the audit events filter.

    Usage:
        from autopil.gemini_guard import GeminiGuard

        guard = GeminiGuard(policy_path="policies/", audit_db="autopil.db")

        @guard.protect(
            agent_role="loan_agent",
            user_id="agent_01",
            source_id="account_summaries",
        )
        def get_account_summary(customer_id: str) -> dict:
            return {"balance": 142000, "account_age_years": 5}

    Session TTL — set at the guard level, applies to all protect() calls:
        guard = GeminiGuard(policy_path="policies/", audit_db="autopil.db",
                            session_ttl_minutes=60)
    """

    _source_type: str = "gemini"

    async def call_if_allowed_async(
        self,
        fn: Callable[..., Any],
        *,
        agent_role: str,
        user_id: str,
        source_id: str,
        sensitivity_level: SensitivityLevel = SensitivityLevel.MEDIUM,
        session_id: Optional[str] = None,
        fn_args: Optional[dict] = None,
    ) -> Any:
        """
        Async version of call_if_allowed for use with async Gemini tool functions.

        Example:
            result = await guard.call_if_allowed_async(
                fn=async_query_db,
                agent_role="wealth_advisor",
                user_id="u1",
                source_id="client_portfolios",
                sensitivity_level=SensitivityLevel.HIGH,
                session_id=session_id,
                fn_args={"client_id": "client_001"},
            )
        """
        protected = self.protect_async(
            agent_role=agent_role,
            user_id=user_id,
            source_id=source_id,
            sensitivity_level=sensitivity_level,
            session_id=session_id,
        )(fn)
        return await protected(**(fn_args or {}))

    def call_if_allowed(
        self,
        fn: Callable[..., Any],
        *,
        agent_role: str,
        user_id: str,
        source_id: str,
        sensitivity_level: SensitivityLevel = SensitivityLevel.MEDIUM,
        session_id: Optional[str] = None,
        fn_args: Optional[dict] = None,
    ) -> Any:
        """
        Inline guard for use inside a Gemini tool-call dispatch loop.

        Evaluates policy for the given agent/source, records the audit event,
        then calls fn(**fn_args) if allowed. Raises PermissionError on DENY.

        Args:
            fn:                The retrieval function to call if allowed.
            agent_role:        The Gemini agent's declared role.
            user_id:           Identifier for the invoking user or agent.
            source_id:         The data source being requested.
            sensitivity_level: Data sensitivity level.
            session_id:        Session identifier (auto-generated if omitted).
            fn_args:           Keyword arguments to pass to fn on ALLOW.

        Returns:
            The return value of fn(**fn_args).

        Raises:
            PermissionError: If policy evaluation returns DENY.

        Example:
            result = guard.call_if_allowed(
                fn=query_credit_db,
                agent_role="loan_agent",
                user_id="agent_01",
                source_id="credit_scores",
                sensitivity_level=SensitivityLevel.HIGH,
                session_id=session_id,
                fn_args={"customer_id": "cust_001"},
            )
        """
        protected = self.protect(
            agent_role=agent_role,
            user_id=user_id,
            source_id=source_id,
            sensitivity_level=sensitivity_level,
            session_id=session_id,
        )(fn)
        return protected(**(fn_args or {}))
