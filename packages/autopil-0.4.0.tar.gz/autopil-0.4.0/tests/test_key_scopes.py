"""
Integration tests for API key scope enforcement.

Verifies that the three key scopes (admin, read, evaluate) are correctly
enforced in require_api_key — i.e. that scope is stored, returned by
validate(), and actually blocks requests that exceed the key's permission.

Scope definitions (from models.KeyScope):
  admin    — full access to all endpoints
  read     — GET endpoints + POST /v1/context/evaluate
  evaluate — POST /v1/context/evaluate only
"""

import uuid

import pytest
from fastapi.testclient import TestClient

from autopil.api.app import create_app
from autopil.db import create_stores


# ── shared helpers ────────────────────────────────────────────────────────────

EVALUATE_PAYLOAD = {
    "query":             "test query",
    "agent_role":        "analyst",
    "user_id":           "u1",
    "source_id":         "reports",
    "sensitivity_level": "low",
    "session_id":        str(uuid.uuid4()),
}


def _make_client(policy_file: str, audit_db: str, scope: str) -> TestClient:
    """Spin up an app and return a TestClient authenticated with a key of the given scope."""
    stores = create_stores(db_path=audit_db)
    _, key_store, tenant_store, *_ = stores
    tenant_id = tenant_store.create_tenant(f"tenant-{scope}-{uuid.uuid4().hex[:6]}")
    _, plaintext = key_store.create_key(f"{scope}-key", tenant_id=tenant_id, scope=scope)
    app = create_app(policy_path=policy_file, audit_db=audit_db)
    return TestClient(app, headers={"X-API-Key": plaintext})


# ── evaluate scope ────────────────────────────────────────────────────────────

class TestEvaluateScope:
    """evaluate-scoped key: only POST /v1/context/evaluate is permitted."""

    @pytest.fixture
    def eval_client(self, policy_file, audit_db):
        return _make_client(policy_file, audit_db, "evaluate")

    def test_evaluate_endpoint_is_allowed(self, eval_client):
        r = eval_client.post("/v1/context/evaluate", json=EVALUATE_PAYLOAD)
        assert r.status_code == 200

    def test_get_policies_is_blocked(self, eval_client):
        r = eval_client.get("/v1/policies")
        assert r.status_code == 403

    def test_get_audit_events_is_blocked(self, eval_client):
        r = eval_client.get("/v1/audit/events")
        assert r.status_code == 403

    def test_get_audit_stats_is_blocked(self, eval_client):
        r = eval_client.get("/v1/audit/stats")
        assert r.status_code == 403

    def test_list_keys_is_blocked(self, eval_client):
        r = eval_client.get("/v1/keys")
        assert r.status_code == 403

    def test_create_key_is_blocked(self, eval_client):
        r = eval_client.post("/v1/keys", json={"name": "should-fail"})
        assert r.status_code == 403

    def test_create_policy_is_blocked(self, eval_client):
        r = eval_client.post("/v1/policies", json={
            "name": "x", "agent_role": "analyst",
            "allowed_sources": [], "denied_sources": [], "max_sensitivity": "low",
        })
        assert r.status_code == 403

    def test_error_detail_is_informative(self, eval_client):
        r = eval_client.get("/v1/policies")
        assert "evaluate" in r.json()["detail"].lower()


# ── read scope ────────────────────────────────────────────────────────────────

class TestReadScope:
    """read-scoped key: GET endpoints + POST /v1/context/evaluate allowed; writes blocked."""

    @pytest.fixture
    def read_client(self, policy_file, audit_db):
        return _make_client(policy_file, audit_db, "read")

    def test_get_policies_is_allowed(self, read_client):
        r = read_client.get("/v1/policies")
        assert r.status_code == 200

    def test_get_audit_events_is_allowed(self, read_client):
        r = read_client.get("/v1/audit/events")
        assert r.status_code == 200

    def test_get_audit_stats_is_allowed(self, read_client):
        r = read_client.get("/v1/audit/stats")
        assert r.status_code == 200

    def test_list_keys_is_allowed(self, read_client):
        r = read_client.get("/v1/keys")
        assert r.status_code == 200

    def test_evaluate_endpoint_is_allowed(self, read_client):
        r = read_client.post("/v1/context/evaluate", json=EVALUATE_PAYLOAD)
        assert r.status_code == 200

    def test_create_key_is_blocked(self, read_client):
        r = read_client.post("/v1/keys", json={"name": "should-fail"})
        assert r.status_code == 403

    def test_create_policy_is_blocked(self, read_client):
        r = read_client.post("/v1/policies", json={
            "name": "x", "agent_role": "analyst",
            "allowed_sources": [], "denied_sources": [], "max_sensitivity": "low",
        })
        assert r.status_code == 403

    def test_delete_policy_is_blocked(self, read_client):
        r = read_client.delete("/v1/policies/any_policy")
        assert r.status_code == 403

    def test_error_detail_is_informative(self, read_client):
        r = read_client.post("/v1/keys", json={"name": "x"})
        assert "read-only" in r.json()["detail"].lower()


# ── admin scope ───────────────────────────────────────────────────────────────

class TestAdminScope:
    """admin-scoped key: no scope-level restrictions beyond superadmin routes."""

    @pytest.fixture
    def admin_client(self, policy_file, audit_db):
        return _make_client(policy_file, audit_db, "admin")

    def test_get_policies_is_allowed(self, admin_client):
        r = admin_client.get("/v1/policies")
        assert r.status_code == 200

    def test_evaluate_is_allowed(self, admin_client):
        r = admin_client.post("/v1/context/evaluate", json=EVALUATE_PAYLOAD)
        assert r.status_code == 200

    def test_create_key_is_allowed(self, admin_client):
        r = admin_client.post("/v1/keys", json={"name": "new-key"})
        assert r.status_code == 200

    def test_list_keys_is_allowed(self, admin_client):
        r = admin_client.get("/v1/keys")
        assert r.status_code == 200

    def test_create_policy_is_allowed(self, admin_client):
        r = admin_client.post("/v1/policies", json={
            "name": "scope_test_policy",
            "agent_role": "analyst",
            "allowed_sources": ["reports"],
            "denied_sources": [],
            "max_sensitivity": "high",
        })
        assert r.status_code == 200


# ── scope stored and returned correctly ──────────────────────────────────────

class TestScopeStoredCorrectly:
    """Verify scope is persisted and appears in the key list."""

    def test_scope_reflected_in_key_list(self, policy_file, audit_db):
        """Keys created with explicit scopes should show that scope in GET /v1/keys."""
        stores = create_stores(db_path=audit_db)
        _, key_store, tenant_store, *_ = stores
        tenant_id = tenant_store.create_tenant(f"scope-check-{uuid.uuid4().hex[:6]}")
        _, admin_plaintext = key_store.create_key("admin-k",    tenant_id=tenant_id, scope="admin")
        key_store.create_key("read-k",    tenant_id=tenant_id, scope="read")
        key_store.create_key("eval-k",    tenant_id=tenant_id, scope="evaluate")

        app = create_app(policy_path=policy_file, audit_db=audit_db)
        c = TestClient(app, headers={"X-API-Key": admin_plaintext})
        keys = {k["name"]: k["scope"] for k in c.get("/v1/keys").json()}

        assert keys["admin-k"]  == "admin"
        assert keys["read-k"]   == "read"
        assert keys["eval-k"]   == "evaluate"

    def test_default_scope_is_admin(self, policy_file, audit_db):
        """A key created without explicit scope defaults to admin."""
        stores = create_stores(db_path=audit_db)
        _, key_store, tenant_store, *_ = stores
        tenant_id = tenant_store.create_tenant(f"default-scope-{uuid.uuid4().hex[:6]}")
        _, plaintext = key_store.create_key("default-k", tenant_id=tenant_id)

        app = create_app(policy_path=policy_file, audit_db=audit_db)
        c = TestClient(app, headers={"X-API-Key": plaintext})
        keys = {k["name"]: k["scope"] for k in c.get("/v1/keys").json()}
        assert keys["default-k"] == "admin"
