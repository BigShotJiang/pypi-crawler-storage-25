"""
Additional tests for autopil/telemetry.py — covering branches not reached by
the existing test_telemetry.py.

Covers: setup() when OTEL SDK not installed, metrics-only setup (console),
OTLP trace/metric reader (ImportError fallback), metrics-only evaluate_span path,
and _Span.set_result DENY when StatusCode is not importable.
"""

import sys
from unittest.mock import MagicMock, patch

import pytest

import autopil.telemetry as telemetry


@pytest.fixture(autouse=True)
def reset_telemetry():
    telemetry.reset()
    yield
    telemetry.reset()


# ── setup() when OTEL SDK is not installed (lines 70-71) ─────────────────────

def test_setup_returns_false_when_otel_not_installed():
    """Simulate missing opentelemetry-sdk by patching import to fail."""
    otel_keys = {k: None for k in sys.modules if k.startswith("opentelemetry")}
    with patch.dict(sys.modules, otel_keys):
        result = telemetry.setup()
    assert result is False
    # After patching, _initialized was set to True but _tracer remains None
    telemetry.reset()


# ── setup() with console metrics exporter (lines 93-112, 268-273) ────────────

def test_setup_console_metrics_initializes_instruments(monkeypatch):
    monkeypatch.setenv("OTEL_METRICS_EXPORTER", "console")
    monkeypatch.delenv("OTEL_TRACES_EXPORTER", raising=False)
    monkeypatch.delenv("OTEL_EXPORTER_OTLP_ENDPOINT", raising=False)
    result = telemetry.setup()
    assert result is True
    assert telemetry._eval_counter is not None
    assert telemetry._deny_counter is not None
    assert telemetry._duration_histo is not None
    assert telemetry._tracer is None  # no trace exporter configured


def test_setup_console_metrics_increments_counter(monkeypatch):
    monkeypatch.setenv("OTEL_METRICS_EXPORTER", "console")
    monkeypatch.delenv("OTEL_TRACES_EXPORTER", raising=False)
    monkeypatch.delenv("OTEL_EXPORTER_OTLP_ENDPOINT", raising=False)
    telemetry.setup()

    # metrics-only path: _tracer is None, _eval_counter is set
    with telemetry.evaluate_span(
        agent_role="analyst", source_id="reports",
        tenant_id="t1", session_id="s1",
    ) as span:
        span.set_result(decision="ALLOW", policy_name="p")
    # Shouldn't raise — metrics path runs without a tracer


def test_setup_metrics_only_deny_path(monkeypatch):
    monkeypatch.setenv("OTEL_METRICS_EXPORTER", "console")
    monkeypatch.delenv("OTEL_TRACES_EXPORTER", raising=False)
    monkeypatch.delenv("OTEL_EXPORTER_OTLP_ENDPOINT", raising=False)
    telemetry.setup()

    with telemetry.evaluate_span(
        agent_role="analyst", source_id="executive_comms",
        tenant_id="t1", session_id="s1",
    ) as span:
        span.set_result(decision="DENY", policy_name="p", reason="denied")
    # Should run deny counter path without error


# ── _attach_trace_exporter OTLP path (lines 249-264) ─────────────────────────

def test_attach_trace_exporter_otlp_without_package(monkeypatch):
    """OTLP exporter not installed → ImportError silently skipped, no crash."""
    monkeypatch.setenv("OTEL_TRACES_EXPORTER", "otlp")
    monkeypatch.setenv("OTEL_EXPORTER_OTLP_ENDPOINT", "http://localhost:4317")
    monkeypatch.delenv("OTEL_METRICS_EXPORTER", raising=False)
    # The OTLP exporter packages are not installed in test env → ImportError in loop
    result = telemetry.setup()
    # Returns True because traces_exp is set (even if exporter failed to load)
    # OR returns False if no exporter could be attached — either way no crash


def test_attach_trace_exporter_otlp_importerror_handled():
    """Directly test _attach_trace_exporter with otlp + endpoint when packages missing."""
    from opentelemetry.sdk.trace import TracerProvider
    provider = TracerProvider()
    # OTLP packages not installed — both mods in the loop raise ImportError → no-op
    telemetry._attach_trace_exporter(provider, "otlp", "http://localhost:4317")
    # No crash, no processor added (loop exhausted with ImportError on each mod)


def test_attach_trace_exporter_otlp_mocked_success():
    """Lines 258-262: success path when OTLP trace exporter IS available (mocked)."""
    from opentelemetry.sdk.trace import TracerProvider

    mock_exporter_instance = MagicMock()
    mock_exporter_cls = MagicMock(return_value=mock_exporter_instance)
    mock_mod = MagicMock()
    mock_mod.OTLPSpanExporter = mock_exporter_cls

    provider = TracerProvider()
    with patch("importlib.import_module", return_value=mock_mod):
        telemetry._attach_trace_exporter(provider, "otlp", "http://localhost:4317")

    mock_exporter_cls.assert_called_once_with(endpoint="http://localhost:4317")


# ── _make_metric_reader (lines 268-288) ──────────────────────────────────────

def test_make_metric_reader_console_returns_reader():
    reader = telemetry._make_metric_reader("console", "")
    assert reader is not None


def test_make_metric_reader_otlp_without_package_returns_none():
    """OTLP exporter packages not installed → both ImportErrors → returns None."""
    reader = telemetry._make_metric_reader("otlp", "http://localhost:4317")
    assert reader is None


def test_make_metric_reader_otlp_mocked_success():
    """Line 282: success path when OTLP metric exporter IS available (mocked)."""
    mock_exporter_cls = MagicMock()
    mock_exporter_cls.return_value = MagicMock()
    mock_mod = MagicMock()
    mock_mod.OTLPMetricExporter = mock_exporter_cls

    with patch("importlib.import_module", return_value=mock_mod):
        reader = telemetry._make_metric_reader("otlp", "http://localhost:4317")

    assert reader is not None
    mock_exporter_cls.assert_called_once_with(endpoint="http://localhost:4317")


def test_make_metric_reader_unknown_exporter_returns_none():
    reader = telemetry._make_metric_reader("zipkin", "")
    assert reader is None


# ── _Span.set_result DENY with StatusCode ImportError (lines 208-209) ────────

def test_span_set_result_deny_status_code_import_error():
    """If opentelemetry.trace.StatusCode import fails, set_result does not crash."""
    otel_span = MagicMock()
    span = telemetry._Span(otel_span)
    # Patch opentelemetry.trace to None → triggers ImportError in set_result
    with patch.dict(sys.modules, {"opentelemetry.trace": None}):
        span.set_result(decision="DENY", policy_name="p", reason="blocked")
    assert span.decision == "DENY"
    assert span.policy_name == "p"


def test_span_set_result_allow_no_status_call():
    """ALLOW decision should NOT call set_status on the OTEL span."""
    otel_span = MagicMock()
    span = telemetry._Span(otel_span)
    span.set_result(decision="ALLOW", policy_name="p")
    otel_span.set_status.assert_not_called()


# ── setup() idempotent when already initialized (line 60) ────────────────────

def test_setup_idempotent_returns_same_result(monkeypatch):
    monkeypatch.delenv("OTEL_TRACES_EXPORTER", raising=False)
    monkeypatch.delenv("OTEL_METRICS_EXPORTER", raising=False)
    monkeypatch.delenv("OTEL_EXPORTER_OTLP_ENDPOINT", raising=False)
    r1 = telemetry.setup()
    r2 = telemetry.setup()  # second call — _initialized is True
    assert r1 == r2 == False
