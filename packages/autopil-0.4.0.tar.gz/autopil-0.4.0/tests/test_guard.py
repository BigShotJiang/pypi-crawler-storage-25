"""
Tests for autopil.guard.ContextGuard

Coverage:
  - Allowed retrieval succeeds and returns context
  - Denied retrieval raises PermissionError
  - Audit event is recorded for every call (allow and deny)
  - Context hash is populated on ALLOW and None on DENY
  - Cross-agent isolation: second agent on same session is denied
  - Session isolation: different sessions are independent
  - Decorator preserves return value from wrapped function
  - _record_event accepts explicit event_id and source_type overrides
  - Session lifecycle: TTL expiry and revocation enforced by the SDK
  - session_ttl_minutes parameter wired into session creation
"""

import sqlite3
import uuid
from datetime import datetime, timedelta, timezone

import pytest

from autopil.guard import ContextGuard
from autopil.models import Decision, SensitivityLevel


# ── helpers ───────────────────────────────────────────────────────────────────

def make_retriever(return_value="context_data"):
    """A fake retrieval function that returns a fixed value."""
    def retrieve(query: str):
        return return_value
    return retrieve


# ── basic allow / deny ────────────────────────────────────────────────────────

class TestAllowDeny:
    def test_allowed_call_returns_context(self, guard):
        sid = str(uuid.uuid4())

        @guard.protect(agent_role="analyst", user_id="u1", source_id="reports",
                       sensitivity_level=SensitivityLevel.LOW, session_id=sid)
        def retrieve(query: str):
            return ["doc1", "doc2"]

        result = retrieve("find reports")
        assert result == ["doc1", "doc2"]

    def test_denied_call_raises_permission_error(self, guard):
        sid = str(uuid.uuid4())

        @guard.protect(agent_role="analyst", user_id="u1", source_id="executive_comms",
                       session_id=sid)
        def retrieve(query: str):
            return ["secret"]

        with pytest.raises(PermissionError, match="DENIED"):
            retrieve("find comms")

    def test_unknown_role_raises_permission_error(self, guard):
        @guard.protect(agent_role="rogue", user_id="u1", source_id="reports")
        def retrieve(query: str):
            return []

        with pytest.raises(PermissionError, match="DENIED"):
            retrieve("anything")

    def test_sensitivity_above_ceiling_is_denied(self, guard):
        """viewer max_sensitivity=medium — RESTRICTED should be denied."""
        sid = str(uuid.uuid4())

        @guard.protect(agent_role="viewer", user_id="u1", source_id="reports",
                       sensitivity_level=SensitivityLevel.RESTRICTED, session_id=sid)
        def retrieve(query: str):
            return []

        with pytest.raises(PermissionError):
            retrieve("sensitive query")


# ── audit trail ───────────────────────────────────────────────────────────────

class TestAuditTrail:
    def test_allow_creates_audit_event(self, guard):
        sid = str(uuid.uuid4())

        @guard.protect(agent_role="analyst", user_id="u1", source_id="reports",
                       session_id=sid)
        def retrieve(query: str):
            return "data"

        retrieve("q")
        events = guard.audit_log.get_session_events(sid)
        assert len(events) == 1
        assert events[0].decision == Decision.ALLOW

    def test_deny_creates_audit_event(self, guard):
        sid = str(uuid.uuid4())

        @guard.protect(agent_role="analyst", user_id="u1", source_id="executive_comms",
                       session_id=sid)
        def retrieve(query: str):
            return []

        with pytest.raises(PermissionError):
            retrieve("q")

        events = guard.audit_log.get_session_events(sid)
        assert len(events) == 1
        assert events[0].decision == Decision.DENY

    def test_audit_event_fields_match_request(self, guard):
        sid = str(uuid.uuid4())

        @guard.protect(agent_role="analyst", user_id="u42", source_id="reports",
                       session_id=sid)
        def retrieve(query: str):
            return "ok"

        retrieve("my query")
        event = guard.audit_log.get_session_events(sid)[0]
        assert event.agent_role  == "analyst"
        assert event.user_id     == "u42"
        assert event.source_id   == "reports"
        assert event.query       == "my query"
        assert event.session_id  == sid

    def test_get_audit_trail_convenience_method(self, guard):
        sid = str(uuid.uuid4())

        @guard.protect(agent_role="analyst", user_id="u1", source_id="reports",
                       session_id=sid)
        def retrieve(query: str):
            return "data"

        retrieve("q")
        trail = guard.get_audit_trail(sid)
        assert len(trail) == 1


# ── context hash ──────────────────────────────────────────────────────────────

class TestContextHash:
    def test_context_hash_set_on_allow(self, guard):
        sid = str(uuid.uuid4())

        @guard.protect(agent_role="analyst", user_id="u1", source_id="reports",
                       session_id=sid)
        def retrieve(query: str):
            return "some context"

        retrieve("q")
        event = guard.audit_log.get_session_events(sid)[0]
        assert event.context_hash is not None
        assert len(event.context_hash) == 16  # first 16 chars of sha256 hex

    def test_context_hash_none_on_deny(self, guard):
        sid = str(uuid.uuid4())

        @guard.protect(agent_role="analyst", user_id="u1", source_id="executive_comms",
                       session_id=sid)
        def retrieve(query: str):
            return "secret"

        with pytest.raises(PermissionError):
            retrieve("q")

        event = guard.audit_log.get_session_events(sid)[0]
        assert event.context_hash is None


# ── cross-agent isolation ─────────────────────────────────────────────────────

class TestCrossAgentIsolation:
    def test_second_agent_on_same_session_is_denied(self, guard):
        """Session established by analyst — viewer trying same session must be denied."""
        sid = str(uuid.uuid4())

        @guard.protect(agent_role="analyst", user_id="u1", source_id="reports",
                       session_id=sid)
        def analyst_retrieve(query: str):
            return "analyst data"

        @guard.protect(agent_role="viewer", user_id="u2", source_id="reports",
                       session_id=sid)
        def viewer_retrieve(query: str):
            return "viewer data"

        analyst_retrieve("q")  # establishes session ownership

        with pytest.raises(PermissionError, match="cross_agent_isolation|owned by"):
            viewer_retrieve("q")

    def test_cross_agent_deny_is_audited(self, guard):
        sid = str(uuid.uuid4())

        @guard.protect(agent_role="analyst", user_id="u1", source_id="reports",
                       session_id=sid)
        def analyst_retrieve(query: str):
            return "data"

        @guard.protect(agent_role="viewer", user_id="u2", source_id="reports",
                       session_id=sid)
        def viewer_retrieve(query: str):
            return "data"

        analyst_retrieve("q")

        with pytest.raises(PermissionError):
            viewer_retrieve("q")

        events = guard.audit_log.get_session_events(sid)
        assert len(events) == 2
        isolation_event = events[1]
        assert isolation_event.decision    == Decision.DENY
        assert isolation_event.policy_name == "cross_agent_isolation"

    def test_same_agent_can_reuse_session(self, guard):
        """Same agent role on the same session should continue to work."""
        sid = str(uuid.uuid4())

        @guard.protect(agent_role="analyst", user_id="u1", source_id="reports",
                       session_id=sid)
        def retrieve(query: str):
            return f"data for {query}"

        result1 = retrieve("first")
        result2 = retrieve("second")
        assert result1 is not None
        assert result2 is not None

        events = guard.audit_log.get_session_events(sid)
        assert len(events) == 2
        assert all(e.decision == Decision.ALLOW for e in events)

    def test_different_sessions_are_independent(self, guard):
        """Two agents on different sessions should each succeed independently."""
        sid_a = str(uuid.uuid4())
        sid_b = str(uuid.uuid4())

        @guard.protect(agent_role="analyst", user_id="u1", source_id="reports",
                       session_id=sid_a)
        def analyst_retrieve(query: str):
            return "analyst"

        @guard.protect(agent_role="viewer", user_id="u2", source_id="reports",
                       session_id=sid_b)
        def viewer_retrieve(query: str):
            return "viewer"

        r1 = analyst_retrieve("q")
        r2 = viewer_retrieve("q")
        assert r1 == "analyst"
        assert r2 == "viewer"


# ── _record_event overrides (used by AutoPILMiddleware) ───────────────────────

class TestRecordEventOverrides:
    """
    _record_event accepts optional event_id and source_type parameters.
    The middleware pre-generates an event_id and always passes source_type="api"
    regardless of which guard subclass is in use.
    """

    def test_explicit_event_id_is_used(self, guard):
        sid = str(uuid.uuid4())
        fixed_id = "aaaabbbb-cccc-dddd-eeee-ffffaaaabbbb"
        guard._record_event(
            agent_role="analyst", user_id="u1", source_id="reports",
            query="q", decision=Decision.ALLOW, policy_name="p", reason="ok",
            sensitivity_level=SensitivityLevel.MEDIUM, sid=sid,
            context_hash=None, event_id=fixed_id,
        )
        events = guard.get_audit_trail(sid)
        assert events[0].event_id == fixed_id

    def test_explicit_event_id_sets_last_event_id(self, guard):
        fixed_id = "11112222-3333-4444-5555-666677778888"
        guard._record_event(
            agent_role="analyst", user_id="u1", source_id="reports",
            query="q", decision=Decision.ALLOW, policy_name="p", reason="ok",
            sensitivity_level=SensitivityLevel.MEDIUM, sid=str(uuid.uuid4()),
            context_hash=None, event_id=fixed_id,
        )
        assert guard.last_event_id == fixed_id

    def test_source_type_override_replaces_class_default(self, guard):
        """Middleware always stamps source_type='api', overriding _source_type='sdk'."""
        assert guard._source_type == "sdk"
        sid = str(uuid.uuid4())
        guard._record_event(
            agent_role="analyst", user_id="u1", source_id="reports",
            query="q", decision=Decision.ALLOW, policy_name="p", reason="ok",
            sensitivity_level=SensitivityLevel.MEDIUM, sid=sid,
            context_hash=None, source_type="api",
        )
        assert guard.get_audit_trail(sid)[0].source_type == "api"

    def test_omitting_event_id_auto_generates_uuid(self, guard):
        sid = str(uuid.uuid4())
        returned_id = guard._record_event(
            agent_role="analyst", user_id="u1", source_id="reports",
            query="q", decision=Decision.ALLOW, policy_name="p", reason="ok",
            sensitivity_level=SensitivityLevel.MEDIUM, sid=sid,
            context_hash=None,
        )
        assert len(returned_id) == 36  # UUID format
        assert guard.get_audit_trail(sid)[0].event_id == returned_id

    def test_omitting_source_type_uses_class_default(self, guard):
        sid = str(uuid.uuid4())
        guard._record_event(
            agent_role="analyst", user_id="u1", source_id="reports",
            query="q", decision=Decision.ALLOW, policy_name="p", reason="ok",
            sensitivity_level=SensitivityLevel.MEDIUM, sid=sid,
            context_hash=None,
        )
        assert guard.get_audit_trail(sid)[0].source_type == "sdk"


# ── session lifecycle (TTL + revocation) ──────────────────────────────────────

class TestSessionLifecycle:
    """
    Verify that ContextGuard enforces TTL expiry and revocation via the
    SessionStore — not just through the REST API path.
    """

    def test_session_store_is_created_on_first_call(self, guard):
        """After the first protect() call the session exists in the session store."""
        sid = str(uuid.uuid4())

        @guard.protect(agent_role="analyst", user_id="u1", source_id="reports",
                       session_id=sid)
        def retrieve(query: str):
            return "data"

        retrieve("q")
        session = guard.session_store.get_session(sid, guard.tenant_id)
        assert session is not None
        assert session["agent_role"] == "analyst"
        assert session["session_id"] == sid

    def test_session_owner_stored_correctly(self, guard):
        """The agent_role of the first caller is stored as session owner."""
        sid = str(uuid.uuid4())

        @guard.protect(agent_role="analyst", user_id="u1", source_id="reports",
                       session_id=sid)
        def retrieve(query: str):
            return "data"

        retrieve("q")
        session = guard.session_store.get_session(sid, guard.tenant_id)
        assert session["agent_role"] == "analyst"

    def test_last_active_updated_on_subsequent_calls(self, guard):
        """touch_session is called on every subsequent valid call."""
        sid = str(uuid.uuid4())

        @guard.protect(agent_role="analyst", user_id="u1", source_id="reports",
                       session_id=sid)
        def retrieve(query: str):
            return "data"

        retrieve("first")
        before = guard.session_store.get_session(sid, guard.tenant_id)["last_active"]

        retrieve("second")
        after = guard.session_store.get_session(sid, guard.tenant_id)["last_active"]

        # last_active must be >= initial value (monotonic)
        assert after >= before

    def test_revoked_session_is_denied(self, guard):
        """Revoking a session causes subsequent protect() calls to raise PermissionError."""
        sid = str(uuid.uuid4())

        @guard.protect(agent_role="analyst", user_id="u1", source_id="reports",
                       session_id=sid)
        def retrieve(query: str):
            return "data"

        # First call — establishes the session
        retrieve("q")

        # Revoke it directly via the session store
        guard.session_store.revoke_session(sid, guard.tenant_id)

        with pytest.raises(PermissionError, match="session revoked"):
            retrieve("q2")

    def test_revoked_session_deny_is_audited(self, guard):
        """The revocation denial is written to the audit trail."""
        sid = str(uuid.uuid4())

        @guard.protect(agent_role="analyst", user_id="u1", source_id="reports",
                       session_id=sid)
        def retrieve(query: str):
            return "data"

        retrieve("q")
        guard.session_store.revoke_session(sid, guard.tenant_id)

        with pytest.raises(PermissionError):
            retrieve("q2")

        events = guard.audit_log.get_session_events(sid)
        deny_event = events[-1]
        assert deny_event.decision == Decision.DENY
        assert deny_event.policy_name == "session_revoked"

    def test_expired_session_is_denied(self, guard):
        """A session with expires_at in the past causes protect() to raise PermissionError."""
        sid = str(uuid.uuid4())

        @guard.protect(agent_role="analyst", user_id="u1", source_id="reports",
                       session_id=sid)
        def retrieve(query: str):
            return "data"

        # First call — creates the session
        retrieve("q")

        # Manually expire it by backdating expires_at
        past = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
        with sqlite3.connect(guard.session_store.db_path) as conn:
            conn.execute(
                "UPDATE sessions SET expires_at = ? WHERE session_id = ?",
                (past, sid),
            )

        with pytest.raises(PermissionError, match="session expired"):
            retrieve("q2")

    def test_expired_session_deny_is_audited(self, guard):
        """The expiry denial is written to the audit trail with policy_name='session_expired'."""
        sid = str(uuid.uuid4())

        @guard.protect(agent_role="analyst", user_id="u1", source_id="reports",
                       session_id=sid)
        def retrieve(query: str):
            return "data"

        retrieve("q")

        past = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
        with sqlite3.connect(guard.session_store.db_path) as conn:
            conn.execute(
                "UPDATE sessions SET expires_at = ? WHERE session_id = ?",
                (past, sid),
            )

        with pytest.raises(PermissionError):
            retrieve("q2")

        events = guard.audit_log.get_session_events(sid)
        deny_event = events[-1]
        assert deny_event.decision == Decision.DENY
        assert deny_event.policy_name == "session_expired"

    def test_session_ttl_minutes_stored_on_session(self, policy_file, audit_db):
        """When session_ttl_minutes is set on the guard, created sessions have expires_at."""
        guard_with_ttl = ContextGuard(
            policy_path=policy_file,
            audit_db=audit_db,
            session_ttl_minutes=60,
        )
        sid = str(uuid.uuid4())

        @guard_with_ttl.protect(agent_role="analyst", user_id="u1",
                                source_id="reports", session_id=sid)
        def retrieve(query: str):
            return "data"

        retrieve("q")
        session = guard_with_ttl.session_store.get_session(sid, guard_with_ttl.tenant_id)
        assert session["expires_at"] is not None
        assert session["ttl_minutes"] == 60

    def test_no_ttl_by_default(self, guard):
        """Without session_ttl_minutes the session has no expiry (expires_at=None)."""
        sid = str(uuid.uuid4())

        @guard.protect(agent_role="analyst", user_id="u1", source_id="reports",
                       session_id=sid)
        def retrieve(query: str):
            return "data"

        retrieve("q")
        session = guard.session_store.get_session(sid, guard.tenant_id)
        assert session["expires_at"] is None

    def test_touch_session_not_called_on_cross_agent_deny(self, guard):
        """
        When a different role tries to use an existing session, the isolation
        denial fires before touch_session — last_active must not be updated.
        """
        import time
        sid = str(uuid.uuid4())

        @guard.protect(agent_role="analyst", user_id="u1", source_id="reports",
                       session_id=sid)
        def analyst_fn(query: str):
            return "data"

        @guard.protect(agent_role="viewer", user_id="u2", source_id="reports",
                       session_id=sid)
        def viewer_fn(query: str):
            return "data"

        analyst_fn("q")
        before = guard.session_store.get_session(sid, guard.tenant_id)["last_active"]

        time.sleep(0.01)
        with pytest.raises(PermissionError):
            viewer_fn("q")

        after = guard.session_store.get_session(sid, guard.tenant_id)["last_active"]
        assert after == before  # last_active unchanged — touch never ran
