"""
Tests for LlamaIndexGuard — AutoPIL's integration layer for LlamaIndex agents.
"""

import uuid
import textwrap
import pytest

from autopil.llamaindex_guard import LlamaIndexGuard
from autopil.models import Decision, SensitivityLevel

POLICY_YAML = textwrap.dedent("""\
policies:
  - name: clinical_researcher_policy
    agent_role: clinical_researcher
    allowed_sources:
      - patient_cohorts
      - trial_outcomes
    denied_sources:
      - patient_pii
      - investigational_drug_formulary
    max_sensitivity: medium
""")


@pytest.fixture
def guard(tmp_path):
    (tmp_path / "policy.yaml").write_text(POLICY_YAML)
    return LlamaIndexGuard(
        policy_path=str(tmp_path / "policy.yaml"),
        audit_db=str(tmp_path / "test.db"),
    )


@pytest.fixture
def sid():
    return str(uuid.uuid4())


class TestSourceTypeTagging:
    def test_allowed_event_tagged_llamaindex(self, guard, sid):
        @guard.protect(agent_role="clinical_researcher", user_id="u1",
                       source_id="patient_cohorts", session_id=sid)
        def fetch(_): return {}
        fetch("q")
        assert guard.get_audit_trail(sid)[0].source_type == "llamaindex"

    def test_denied_event_tagged_llamaindex(self, guard, sid):
        @guard.protect(agent_role="clinical_researcher", user_id="u1",
                       source_id="patient_pii", session_id=sid)
        def fetch(_): return {}
        with pytest.raises(PermissionError):
            fetch("q")
        events = guard.get_audit_trail(sid)
        assert events[0].source_type == "llamaindex"
        assert events[0].decision == Decision.DENY

    def test_not_tagged_sdk_or_mcp(self, guard, sid):
        @guard.protect(agent_role="clinical_researcher", user_id="u1",
                       source_id="patient_cohorts", session_id=sid)
        def fetch(_): return {}
        fetch("q")
        assert guard.get_audit_trail(sid)[0].source_type not in ("sdk", "mcp", "rest")


class TestPolicyEnforcement:
    def test_allowed_returns_data(self, guard, sid):
        @guard.protect(agent_role="clinical_researcher", user_id="u1",
                       source_id="trial_outcomes", session_id=sid)
        def fetch(_): return {"efficacy": 0.73}
        assert fetch("NCT_001")["efficacy"] == 0.73

    def test_denied_raises(self, guard, sid):
        @guard.protect(agent_role="clinical_researcher", user_id="u1",
                       source_id="investigational_drug_formulary", session_id=sid)
        def fetch(_): return {}
        with pytest.raises(PermissionError, match="DENIED"):
            fetch("q")

    def test_sensitivity_ceiling(self, guard, sid):
        @guard.protect(agent_role="clinical_researcher", user_id="u1",
                       source_id="patient_cohorts",
                       sensitivity_level=SensitivityLevel.HIGH,  # above max medium
                       session_id=sid)
        def fetch(_): return {}
        with pytest.raises(PermissionError):
            fetch("q")


class TestWrapQueryEngine:
    class _MockEngine:
        def query(self, query_str: str) -> str:
            return f"results for: {query_str}"

    def test_allowed_engine_returns_result(self, guard, sid):
        engine = self._MockEngine()
        safe = guard.wrap_query_engine(engine, agent_role="clinical_researcher",
                                       user_id="u1", source_id="patient_cohorts",
                                       session_id=sid)
        result = safe.query("T2D patients")
        assert "results for" in result

    def test_denied_engine_raises(self, guard, sid):
        engine = self._MockEngine()
        safe = guard.wrap_query_engine(engine, agent_role="clinical_researcher",
                                       user_id="u1",
                                       source_id="investigational_drug_formulary",
                                       session_id=sid)
        with pytest.raises(PermissionError):
            safe.query("GLP-1 variants")

    def test_wrapped_engine_tags_llamaindex(self, guard, sid):
        engine = self._MockEngine()
        safe = guard.wrap_query_engine(engine, agent_role="clinical_researcher",
                                       user_id="u1", source_id="patient_cohorts",
                                       session_id=sid)
        safe.query("cohort data")
        assert guard.get_audit_trail(sid)[0].source_type == "llamaindex"

    def test_wrapped_engine_proxies_other_attrs(self, guard, sid):
        class RichEngine:
            name = "test_engine"
            def query(self, q): return "ok"

        safe = guard.wrap_query_engine(RichEngine(), agent_role="clinical_researcher",
                                       user_id="u1", source_id="patient_cohorts",
                                       session_id=sid)
        assert safe.name == "test_engine"


class TestAsyncQueryEngineSessionConsistency:
    """
    wrap_query_engine_async() must pre-build both the async and sync protect
    decorators at construction time so that both .aquery() and .query() reuse
    the same session_id — not generate a fresh UUID per sync call.
    """

    @pytest.mark.asyncio
    async def test_aquery_and_query_share_session(self, guard, sid):
        """Both .aquery() and .query() on the same proxy must use the supplied session_id."""
        class DualEngine:
            def query(self, q): return f"sync:{q}"
            async def aquery(self, q): return f"async:{q}"

        safe = guard.wrap_query_engine_async(
            DualEngine(),
            agent_role="clinical_researcher",
            user_id="u1",
            source_id="patient_cohorts",
            session_id=sid,
        )

        await safe.aquery("first")
        safe.query("second")

        events = guard.get_audit_trail(sid)
        assert len(events) == 2
        assert all(e.session_id == sid for e in events)

    @pytest.mark.asyncio
    async def test_revoked_session_blocks_both_aquery_and_query(self, guard, sid):
        """Revoking a session blocks both .aquery() and .query() on the same proxy."""
        class DualEngine:
            def query(self, q): return "sync"
            async def aquery(self, q): return "async"

        safe = guard.wrap_query_engine_async(
            DualEngine(),
            agent_role="clinical_researcher",
            user_id="u1",
            source_id="patient_cohorts",
            session_id=sid,
        )

        await safe.aquery("establish")
        guard.session_store.revoke_session(sid, guard.tenant_id)

        with pytest.raises(PermissionError, match="session revoked"):
            await safe.aquery("blocked")

        with pytest.raises(PermissionError, match="session revoked"):
            safe.query("blocked")


class TestAuditTrail:
    def test_mixed_decisions_all_tagged_llamaindex(self, guard, sid):
        @guard.protect(agent_role="clinical_researcher", user_id="u1",
                       source_id="patient_cohorts", session_id=sid)
        def allowed(_): return {}

        @guard.protect(agent_role="clinical_researcher", user_id="u1",
                       source_id="patient_pii", session_id=sid)
        def denied(_): return {}

        allowed("q")
        with pytest.raises(PermissionError):
            denied("q")

        events = guard.get_audit_trail(sid)
        assert len(events) == 2
        assert all(e.source_type == "llamaindex" for e in events)
