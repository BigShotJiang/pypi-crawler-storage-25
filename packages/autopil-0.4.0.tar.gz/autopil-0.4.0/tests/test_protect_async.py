"""
Tests for protect_async — AutoPIL's async-native policy enforcement decorator.

Covers:
  - Basic ALLOW / DENY behavior for async functions
  - source_type tagging across all guard subclasses (sdk, gemini, langchain,
    llamaindex, openai_agents, bedrock)
  - Context hash computed correctly for async return values
  - last_event_id set per-coroutine via ContextVar
  - Concurrent Task isolation (the core ContextVar guarantee)
  - Cross-agent session isolation in async context
  - Sensitivity ceiling enforcement
  - Framework async helpers: call_if_allowed_async, wrap_tool_async,
    wrap_query_engine_async, wrap_invoke_agent_async
"""

import asyncio
import textwrap
import uuid

import pytest
import pytest_asyncio

from autopil.guard import ContextGuard
from autopil.bedrock_guard import BedrockGuard
from autopil.gemini_guard import GeminiGuard
from autopil.langchain_guard import LangChainGuard
from autopil.llamaindex_guard import LlamaIndexGuard
from autopil.openai_agents_guard import OpenAIAgentsGuard
from autopil.models import Decision, SensitivityLevel


# ── shared policy ─────────────────────────────────────────────────────────────

POLICY_YAML = textwrap.dedent("""\
policies:
  - name: analyst_policy
    agent_role: analyst
    allowed_sources:
      - reports
      - market_data
    denied_sources:
      - pii_records
      - internal_models
    max_sensitivity: high
""")


@pytest.fixture
def guard(tmp_path):
    (tmp_path / "policy.yaml").write_text(POLICY_YAML)
    return ContextGuard(
        policy_path=str(tmp_path / "policy.yaml"),
        audit_db=str(tmp_path / "test.db"),
    )


@pytest.fixture
def sid():
    return str(uuid.uuid4())


# ── basic async ALLOW / DENY ──────────────────────────────────────────────────

class TestProtectAsyncBasic:
    @pytest.mark.asyncio
    async def test_allow_returns_result(self, guard, sid):
        @guard.protect_async(agent_role="analyst", user_id="u1",
                             source_id="reports", session_id=sid)
        async def fetch(_): return {"rows": 42}

        result = await fetch("quarterly sales")
        assert result == {"rows": 42}

    @pytest.mark.asyncio
    async def test_deny_raises_permission_error(self, guard, sid):
        @guard.protect_async(agent_role="analyst", user_id="u1",
                             source_id="pii_records", session_id=sid)
        async def fetch(_): return {}

        with pytest.raises(PermissionError, match="DENIED"):
            await fetch("query")

    @pytest.mark.asyncio
    async def test_denied_function_body_never_called(self, guard, sid):
        called = []

        @guard.protect_async(agent_role="analyst", user_id="u1",
                             source_id="pii_records", session_id=sid)
        async def fetch(_):
            called.append(True)
            return {}

        with pytest.raises(PermissionError):
            await fetch("q")
        assert called == [], "function body must not execute on DENY"

    @pytest.mark.asyncio
    async def test_allow_audit_event_recorded(self, guard, sid):
        @guard.protect_async(agent_role="analyst", user_id="u1",
                             source_id="reports", session_id=sid)
        async def fetch(_): return {}

        await fetch("q")
        events = guard.get_audit_trail(sid)
        assert len(events) == 1
        assert events[0].decision == Decision.ALLOW

    @pytest.mark.asyncio
    async def test_deny_audit_event_recorded(self, guard, sid):
        @guard.protect_async(agent_role="analyst", user_id="u1",
                             source_id="pii_records", session_id=sid)
        async def fetch(_): return {}

        with pytest.raises(PermissionError):
            await fetch("q")
        events = guard.get_audit_trail(sid)
        assert len(events) == 1
        assert events[0].decision == Decision.DENY

    @pytest.mark.asyncio
    async def test_sensitivity_ceiling_denied(self, guard, sid):
        @guard.protect_async(agent_role="analyst", user_id="u1",
                             source_id="reports",
                             sensitivity_level=SensitivityLevel.RESTRICTED,
                             session_id=sid)
        async def fetch(_): return {}

        with pytest.raises(PermissionError):
            await fetch("q")
        assert guard.get_audit_trail(sid)[0].decision == Decision.DENY

    @pytest.mark.asyncio
    async def test_preserves_function_name(self, guard, sid):
        @guard.protect_async(agent_role="analyst", user_id="u1",
                             source_id="reports", session_id=sid)
        async def my_retrieval_fn(_): return {}

        assert my_retrieval_fn.__name__ == "my_retrieval_fn"

    @pytest.mark.asyncio
    async def test_kwargs_supported(self, guard, sid):
        @guard.protect_async(agent_role="analyst", user_id="u1",
                             source_id="reports", session_id=sid)
        async def fetch(query: str, limit: int = 10): return {"limit": limit}

        result = await fetch(query="q", limit=5)
        assert result == {"limit": 5}


# ── context hash ─────────────────────────────────────────────────────────────

class TestContextHash:
    @pytest.mark.asyncio
    async def test_context_hash_set_on_allow(self, guard, sid):
        @guard.protect_async(agent_role="analyst", user_id="u1",
                             source_id="reports", session_id=sid)
        async def fetch(_): return {"value": 99}

        await fetch("q")
        events = guard.get_audit_trail(sid)
        assert events[0].context_hash is not None
        assert len(events[0].context_hash) == 16

    @pytest.mark.asyncio
    async def test_context_hash_none_on_deny(self, guard, sid):
        @guard.protect_async(agent_role="analyst", user_id="u1",
                             source_id="pii_records", session_id=sid)
        async def fetch(_): return {}

        with pytest.raises(PermissionError):
            await fetch("q")
        assert guard.get_audit_trail(sid)[0].context_hash is None


# ── last_event_id via ContextVar ──────────────────────────────────────────────

class TestLastEventId:
    @pytest.mark.asyncio
    async def test_last_event_id_set_after_allow(self, guard, sid):
        @guard.protect_async(agent_role="analyst", user_id="u1",
                             source_id="reports", session_id=sid)
        async def fetch(_): return {}

        assert guard.last_event_id is None
        await fetch("q")
        assert guard.last_event_id is not None

    @pytest.mark.asyncio
    async def test_last_event_id_set_after_deny(self, guard, sid):
        @guard.protect_async(agent_role="analyst", user_id="u1",
                             source_id="pii_records", session_id=sid)
        async def fetch(_): return {}

        with pytest.raises(PermissionError):
            await fetch("q")
        # event_id is set even on DENY — so record_action can reference it
        assert guard.last_event_id is not None

    @pytest.mark.asyncio
    async def test_last_event_id_matches_audit_event(self, guard, sid):
        @guard.protect_async(agent_role="analyst", user_id="u1",
                             source_id="reports", session_id=sid)
        async def fetch(_): return {}

        await fetch("q")
        events = guard.get_audit_trail(sid)
        assert guard.last_event_id == events[0].event_id

    @pytest.mark.asyncio
    async def test_sequential_calls_update_last_event_id(self, guard):
        sid1, sid2 = str(uuid.uuid4()), str(uuid.uuid4())

        @guard.protect_async(agent_role="analyst", user_id="u1",
                             source_id="reports", session_id=sid1)
        async def fetch1(_): return {}

        @guard.protect_async(agent_role="analyst", user_id="u1",
                             source_id="market_data", session_id=sid2)
        async def fetch2(_): return {}

        await fetch1("q")
        eid1 = guard.last_event_id
        await fetch2("q")
        eid2 = guard.last_event_id

        assert eid1 != eid2
        assert guard.last_event_id == eid2


# ── concurrent Task isolation (the ContextVar guarantee) ─────────────────────

class TestConcurrentTaskIsolation:
    @pytest.mark.asyncio
    async def test_concurrent_tasks_have_isolated_last_event_ids(self, guard):
        """
        Two concurrent Tasks using the same guard must not overwrite each
        other's last_event_id. This would FAIL with threading.local() because
        all asyncio Tasks share the same thread.
        """
        sid_a = str(uuid.uuid4())
        sid_b = str(uuid.uuid4())

        @guard.protect_async(agent_role="analyst", user_id="u1",
                             source_id="reports", session_id=sid_a)
        async def fetch_a(_):
            await asyncio.sleep(0.01)  # yield to event loop so tasks interleave
            return {"from": "a"}

        @guard.protect_async(agent_role="analyst", user_id="u1",
                             source_id="market_data", session_id=sid_b)
        async def fetch_b(_):
            return {"from": "b"}

        async def task_a():
            await fetch_a("q")
            return guard.last_event_id

        async def task_b():
            await asyncio.sleep(0.005)  # start after a, but finish before a
            await fetch_b("q")
            return guard.last_event_id

        eid_a, eid_b = await asyncio.gather(
            asyncio.create_task(task_a()),
            asyncio.create_task(task_b()),
        )

        assert eid_a is not None
        assert eid_b is not None
        assert eid_a != eid_b, (
            "ContextVar isolation failed: concurrent Tasks share last_event_id"
        )

    @pytest.mark.asyncio
    async def test_concurrent_tasks_audit_trails_independent(self, guard):
        """Concurrent Tasks produce independent audit trails with no cross-contamination."""
        sessions = [str(uuid.uuid4()) for _ in range(5)]
        results = {}

        async def run_task(sid: str, source: str, expected_decision: Decision):
            @guard.protect_async(agent_role="analyst", user_id="u1",
                                 source_id=source, session_id=sid)
            async def fetch(_):
                await asyncio.sleep(0)
                return {}

            try:
                await fetch("q")
            except PermissionError:
                pass
            results[sid] = guard.get_audit_trail(sid)

        sources = ["reports", "pii_records", "market_data", "internal_models", "reports"]
        expected = [Decision.ALLOW, Decision.DENY, Decision.ALLOW, Decision.DENY, Decision.ALLOW]

        await asyncio.gather(*[
            asyncio.create_task(run_task(sessions[i], sources[i], expected[i]))
            for i in range(5)
        ])

        for i, sid in enumerate(sessions):
            assert len(results[sid]) == 1
            assert results[sid][0].decision == expected[i], (
                f"session {i}: expected {expected[i]}, got {results[sid][0].decision}"
            )
            assert results[sid][0].session_id == sid


# ── source_type tagging across all guard subclasses ───────────────────────────

class TestSourceTypeTagging:
    @pytest.mark.asyncio
    async def test_base_guard_tags_sdk(self, guard, sid):
        @guard.protect_async(agent_role="analyst", user_id="u1",
                             source_id="reports", session_id=sid)
        async def fetch(_): return {}
        await fetch("q")
        assert guard.get_audit_trail(sid)[0].source_type == "sdk"

    @pytest.mark.asyncio
    async def test_gemini_guard_tags_gemini(self, tmp_path):
        (tmp_path / "p.yaml").write_text(POLICY_YAML)
        g = GeminiGuard(policy_path=str(tmp_path / "p.yaml"),
                        audit_db=str(tmp_path / "g.db"))
        sid = str(uuid.uuid4())

        @g.protect_async(agent_role="analyst", user_id="u1",
                         source_id="reports", session_id=sid)
        async def fetch(_): return {}
        await fetch("q")
        assert g.get_audit_trail(sid)[0].source_type == "gemini"

    @pytest.mark.asyncio
    async def test_langchain_guard_tags_langchain(self, tmp_path):
        (tmp_path / "p.yaml").write_text(POLICY_YAML)
        g = LangChainGuard(policy_path=str(tmp_path / "p.yaml"),
                           audit_db=str(tmp_path / "g.db"))
        sid = str(uuid.uuid4())

        @g.protect_async(agent_role="analyst", user_id="u1",
                         source_id="reports", session_id=sid)
        async def fetch(_): return {}
        await fetch("q")
        assert g.get_audit_trail(sid)[0].source_type == "langchain"

    @pytest.mark.asyncio
    async def test_llamaindex_guard_tags_llamaindex(self, tmp_path):
        (tmp_path / "p.yaml").write_text(POLICY_YAML)
        g = LlamaIndexGuard(policy_path=str(tmp_path / "p.yaml"),
                            audit_db=str(tmp_path / "g.db"))
        sid = str(uuid.uuid4())

        @g.protect_async(agent_role="analyst", user_id="u1",
                         source_id="reports", session_id=sid)
        async def fetch(_): return {}
        await fetch("q")
        assert g.get_audit_trail(sid)[0].source_type == "llamaindex"

    @pytest.mark.asyncio
    async def test_openai_agents_guard_tags_openai_agents(self, tmp_path):
        (tmp_path / "p.yaml").write_text(POLICY_YAML)
        g = OpenAIAgentsGuard(policy_path=str(tmp_path / "p.yaml"),
                              audit_db=str(tmp_path / "g.db"))
        sid = str(uuid.uuid4())

        @g.protect_async(agent_role="analyst", user_id="u1",
                         source_id="reports", session_id=sid)
        async def fetch(_): return {}
        await fetch("q")
        assert g.get_audit_trail(sid)[0].source_type == "openai_agents"

    @pytest.mark.asyncio
    async def test_bedrock_guard_tags_bedrock(self, tmp_path):
        (tmp_path / "p.yaml").write_text(POLICY_YAML)
        g = BedrockGuard(policy_path=str(tmp_path / "p.yaml"),
                         audit_db=str(tmp_path / "g.db"))
        sid = str(uuid.uuid4())

        @g.protect_async(agent_role="analyst", user_id="u1",
                         source_id="reports", session_id=sid)
        async def fetch(_): return {}
        await fetch("q")
        assert g.get_audit_trail(sid)[0].source_type == "bedrock"


# ── cross-agent session isolation ─────────────────────────────────────────────

class TestCrossAgentIsolationAsync:
    @pytest.mark.asyncio
    async def test_second_agent_denied_on_owned_session(self, guard):
        sid = str(uuid.uuid4())

        @guard.protect_async(agent_role="analyst", user_id="u1",
                             source_id="reports", session_id=sid)
        async def fetch_analyst(_): return {}

        @guard.protect_async(agent_role="risk_officer", user_id="u2",
                             source_id="reports", session_id=sid)
        async def fetch_risk(_): return {}

        await fetch_analyst("first call — analyst owns the session")

        with pytest.raises(PermissionError, match="cannot access another agent"):
            await fetch_risk("should be denied")

        events = guard.get_audit_trail(sid)
        assert events[-1].decision == Decision.DENY
        assert events[-1].policy_name == "cross_agent_isolation"


# ── framework async helpers ───────────────────────────────────────────────────

class TestGeminiCallIfAllowedAsync:
    @pytest.mark.asyncio
    async def test_allowed_returns_result(self, tmp_path):
        (tmp_path / "p.yaml").write_text(POLICY_YAML)
        g = GeminiGuard(policy_path=str(tmp_path / "p.yaml"),
                        audit_db=str(tmp_path / "g.db"))
        sid = str(uuid.uuid4())

        async def async_retrieval(client_id: str) -> dict:
            return {"balance": 100}

        result = await g.call_if_allowed_async(
            fn=async_retrieval,
            agent_role="analyst",
            user_id="u1",
            source_id="reports",
            session_id=sid,
            fn_args={"client_id": "c1"},
        )
        assert result == {"balance": 100}

    @pytest.mark.asyncio
    async def test_denied_raises(self, tmp_path):
        (tmp_path / "p.yaml").write_text(POLICY_YAML)
        g = GeminiGuard(policy_path=str(tmp_path / "p.yaml"),
                        audit_db=str(tmp_path / "g.db"))

        async def fn(): return {}

        with pytest.raises(PermissionError):
            await g.call_if_allowed_async(
                fn=fn,
                agent_role="analyst",
                user_id="u1",
                source_id="pii_records",
            )

    @pytest.mark.asyncio
    async def test_tags_gemini(self, tmp_path):
        (tmp_path / "p.yaml").write_text(POLICY_YAML)
        g = GeminiGuard(policy_path=str(tmp_path / "p.yaml"),
                        audit_db=str(tmp_path / "g.db"))
        sid = str(uuid.uuid4())

        async def fn() -> dict: return {}

        await g.call_if_allowed_async(fn=fn, agent_role="analyst", user_id="u1",
                                      source_id="reports", session_id=sid)
        assert g.get_audit_trail(sid)[0].source_type == "gemini"


class TestLangChainWrapToolAsync:
    @pytest.mark.asyncio
    async def test_arun_allowed(self, tmp_path):
        (tmp_path / "p.yaml").write_text(POLICY_YAML)
        g = LangChainGuard(policy_path=str(tmp_path / "p.yaml"),
                           audit_db=str(tmp_path / "g.db"))
        sid = str(uuid.uuid4())

        class MockTool:
            async def _arun(self, query): return {"async": True}

        tool = MockTool()
        g.wrap_tool_async(tool, agent_role="analyst", user_id="u1",
                          source_id="reports", session_id=sid)
        result = await tool._arun("q")
        assert result == {"async": True}

    @pytest.mark.asyncio
    async def test_arun_denied_raises(self, tmp_path):
        (tmp_path / "p.yaml").write_text(POLICY_YAML)
        g = LangChainGuard(policy_path=str(tmp_path / "p.yaml"),
                           audit_db=str(tmp_path / "g.db"))

        class MockTool:
            async def _arun(self, query): return {}

        tool = MockTool()
        g.wrap_tool_async(tool, agent_role="analyst", user_id="u1",
                          source_id="pii_records")
        with pytest.raises(PermissionError):
            await tool._arun("q")

    @pytest.mark.asyncio
    async def test_fallback_to_sync_run_when_no_arun(self, tmp_path):
        """If the tool has no _arun, wrap_tool_async creates one from _run."""
        (tmp_path / "p.yaml").write_text(POLICY_YAML)
        g = LangChainGuard(policy_path=str(tmp_path / "p.yaml"),
                           audit_db=str(tmp_path / "g.db"))
        sid = str(uuid.uuid4())

        class SyncOnlyTool:
            def _run(self, query): return {"sync": True}

        tool = SyncOnlyTool()
        assert not hasattr(tool, "_arun")
        g.wrap_tool_async(tool, agent_role="analyst", user_id="u1",
                          source_id="reports", session_id=sid)
        result = await tool._arun("q")
        assert result == {"sync": True}

    @pytest.mark.asyncio
    async def test_tags_langchain(self, tmp_path):
        (tmp_path / "p.yaml").write_text(POLICY_YAML)
        g = LangChainGuard(policy_path=str(tmp_path / "p.yaml"),
                           audit_db=str(tmp_path / "g.db"))
        sid = str(uuid.uuid4())

        class MockTool:
            async def _arun(self, q): return {}

        tool = MockTool()
        g.wrap_tool_async(tool, agent_role="analyst", user_id="u1",
                          source_id="reports", session_id=sid)
        await tool._arun("q")
        assert g.get_audit_trail(sid)[0].source_type == "langchain"


class TestLlamaIndexWrapQueryEngineAsync:
    @pytest.mark.asyncio
    async def test_aquery_allowed(self, tmp_path):
        (tmp_path / "p.yaml").write_text(POLICY_YAML)
        g = LlamaIndexGuard(policy_path=str(tmp_path / "p.yaml"),
                            audit_db=str(tmp_path / "g.db"))
        sid = str(uuid.uuid4())

        class MockEngine:
            async def aquery(self, q): return f"result: {q}"
            def query(self, q): return f"result: {q}"

        safe = g.wrap_query_engine_async(MockEngine(), agent_role="analyst",
                                          user_id="u1", source_id="reports",
                                          session_id=sid)
        result = await safe.aquery("clinical data")
        assert "result" in result

    @pytest.mark.asyncio
    async def test_aquery_denied_raises(self, tmp_path):
        (tmp_path / "p.yaml").write_text(POLICY_YAML)
        g = LlamaIndexGuard(policy_path=str(tmp_path / "p.yaml"),
                            audit_db=str(tmp_path / "g.db"))

        class MockEngine:
            async def aquery(self, q): return "secret"
            def query(self, q): return "secret"

        safe = g.wrap_query_engine_async(MockEngine(), agent_role="analyst",
                                          user_id="u1", source_id="pii_records")
        with pytest.raises(PermissionError):
            await safe.aquery("q")

    @pytest.mark.asyncio
    async def test_fallback_to_sync_query_when_no_aquery(self, tmp_path):
        """Engines without .aquery() fall back to sync .query()."""
        (tmp_path / "p.yaml").write_text(POLICY_YAML)
        g = LlamaIndexGuard(policy_path=str(tmp_path / "p.yaml"),
                            audit_db=str(tmp_path / "g.db"))
        sid = str(uuid.uuid4())

        class SyncEngine:
            def query(self, q): return f"sync: {q}"

        safe = g.wrap_query_engine_async(SyncEngine(), agent_role="analyst",
                                          user_id="u1", source_id="reports",
                                          session_id=sid)
        result = await safe.aquery("q")
        assert result == "sync: q"

    @pytest.mark.asyncio
    async def test_tags_llamaindex(self, tmp_path):
        (tmp_path / "p.yaml").write_text(POLICY_YAML)
        g = LlamaIndexGuard(policy_path=str(tmp_path / "p.yaml"),
                            audit_db=str(tmp_path / "g.db"))
        sid = str(uuid.uuid4())

        class MockEngine:
            async def aquery(self, q): return {}
            def query(self, q): return {}

        safe = g.wrap_query_engine_async(MockEngine(), agent_role="analyst",
                                          user_id="u1", source_id="reports",
                                          session_id=sid)
        await safe.aquery("q")
        assert g.get_audit_trail(sid)[0].source_type == "llamaindex"


# ── AWS Bedrock async helper ───────────────────────────────────────────────────

class TestBedrockWrapInvokeAgentAsync:
    def _make_guard(self, tmp_path):
        (tmp_path / "p.yaml").write_text(POLICY_YAML)
        return BedrockGuard(policy_path=str(tmp_path / "p.yaml"),
                            audit_db=str(tmp_path / "g.db"))

    @pytest.mark.asyncio
    async def test_async_allowed_returns_response(self, tmp_path):
        g = self._make_guard(tmp_path)

        class AsyncClient:
            def invoke_agent(self, *, inputText, **kw):
                return {"completion": f"answer for: {inputText}"}

        safe = g.wrap_invoke_agent_async(AsyncClient(), agent_role="analyst",
                                         user_id="u1", source_id="reports")
        result = await safe.invoke_agent(inputText="show revenue report")
        assert result == {"completion": "answer for: show revenue report"}

    @pytest.mark.asyncio
    async def test_async_denied_raises_permission_error(self, tmp_path):
        g = self._make_guard(tmp_path)

        class AsyncClient:
            def invoke_agent(self, *, inputText, **kw):
                return {"completion": "secret"}

        safe = g.wrap_invoke_agent_async(AsyncClient(), agent_role="analyst",
                                         user_id="u1", source_id="pii_records")
        with pytest.raises(PermissionError):
            await safe.invoke_agent(inputText="show PII")

    @pytest.mark.asyncio
    async def test_async_source_type_is_bedrock(self, tmp_path):
        g = self._make_guard(tmp_path)
        sid = str(uuid.uuid4())

        class AsyncClient:
            def invoke_agent(self, *, inputText, **kw):
                return {}

        safe = g.wrap_invoke_agent_async(AsyncClient(), agent_role="analyst",
                                         user_id="u1", source_id="reports",
                                         session_id=sid)
        await safe.invoke_agent(inputText="q")
        assert g.get_audit_trail(sid)[0].source_type == "bedrock"

    @pytest.mark.asyncio
    async def test_async_input_text_used_as_query(self, tmp_path):
        g = self._make_guard(tmp_path)
        sid = str(uuid.uuid4())

        class AsyncClient:
            def invoke_agent(self, *, inputText, **kw):
                return {}

        safe = g.wrap_invoke_agent_async(AsyncClient(), agent_role="analyst",
                                         user_id="u1", source_id="reports",
                                         session_id=sid)
        await safe.invoke_agent(inputText="what is the claims status?")
        assert g.get_audit_trail(sid)[0].query == "what is the claims status?"

    @pytest.mark.asyncio
    async def test_async_getattr_delegates_to_client(self, tmp_path):
        g = self._make_guard(tmp_path)

        class AsyncClient:
            region = "us-east-1"
            def invoke_agent(self, *, inputText, **kw): return {}

        safe = g.wrap_invoke_agent_async(AsyncClient(), agent_role="analyst",
                                         user_id="u1", source_id="reports")
        assert safe.region == "us-east-1"
