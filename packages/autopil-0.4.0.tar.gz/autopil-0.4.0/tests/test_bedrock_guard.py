"""
Tests for BedrockGuard — AutoPIL's integration layer for AWS Bedrock Agents.

Verifies that:
- BedrockGuard stamps source_type='bedrock' on every audit event
- wrap_invoke_agent() enforces ALLOW/DENY policy before invoking the client
- wrap_invoke_agent_async() works for async pipelines (including sync-client fallback)
- The decorator pattern (guard.protect) works correctly with source_type='bedrock'
- All other kwargs (agentId, agentAliasId, sessionId) are forwarded unchanged
- Non-invoke_agent attributes delegate transparently to the original client
"""

import uuid
import textwrap
import pytest
import pytest_asyncio

from autopil.bedrock_guard import BedrockGuard
from autopil.models import Decision, SensitivityLevel


# ── shared policy ─────────────────────────────────────────────────────────────

POLICY_YAML = textwrap.dedent("""\
policies:
  - name: claims_agent_policy
    agent_role: claims_agent
    allowed_sources:
      - claims_db
      - policy_documents
    denied_sources:
      - internal_actuarial_models
      - other_policyholder_data
    max_sensitivity: high
""")


# ── mock boto3 client ─────────────────────────────────────────────────────────

class MockBedrockClient:
    """Minimal mock of a boto3 bedrock-agent-runtime client."""

    def __init__(self, response=None):
        self._response = response or {"completion": "mock_response", "status": 200}
        self.last_call_kwargs = {}
        self.region_name = "us-east-1"

    def invoke_agent(self, *, inputText: str = "", **kwargs):
        self.last_call_kwargs = {"inputText": inputText, **kwargs}
        return self._response


# ── fixtures ─────────────────────────────────────────────────────────────────

@pytest.fixture
def guard(tmp_path):
    (tmp_path / "policy.yaml").write_text(POLICY_YAML)
    return BedrockGuard(
        policy_path=str(tmp_path / "policy.yaml"),
        audit_db=str(tmp_path / "test.db"),
    )


@pytest.fixture
def sid():
    return str(uuid.uuid4())


@pytest.fixture
def mock_client():
    return MockBedrockClient()


# ── TestBedrockGuardWrapInvokeAgent ──────────────────────────────────────────

class TestBedrockGuardWrapInvokeAgent:

    def test_allowed_returns_response(self, guard, sid, mock_client):
        safe = guard.wrap_invoke_agent(
            mock_client,
            agent_role="claims_agent",
            user_id="u1",
            source_id="claims_db",
            session_id=sid,
        )
        result = safe.invoke_agent(
            inputText="Show open claims",
            agentId="AGENT-001",
            agentAliasId="ALIAS-001",
            sessionId=sid,
        )
        assert result == mock_client._response

    def test_denied_raises_permission_error(self, guard, sid, mock_client):
        safe = guard.wrap_invoke_agent(
            mock_client,
            agent_role="claims_agent",
            user_id="u1",
            source_id="internal_actuarial_models",   # denied
            session_id=sid,
        )
        with pytest.raises(PermissionError, match="DENIED"):
            safe.invoke_agent(
                inputText="Get actuarial model parameters",
                agentId="AGENT-001",
                agentAliasId="ALIAS-001",
                sessionId=sid,
            )

    def test_input_text_used_as_query(self, guard, sid, mock_client):
        safe = guard.wrap_invoke_agent(
            mock_client,
            agent_role="claims_agent",
            user_id="u1",
            source_id="claims_db",
            session_id=sid,
        )
        safe.invoke_agent(inputText="Claim status for CLM-4821")
        events = guard.get_audit_trail(sid)
        assert len(events) == 1
        assert events[0].query == "Claim status for CLM-4821"

    def test_other_kwargs_forwarded(self, guard, sid, mock_client):
        safe = guard.wrap_invoke_agent(
            mock_client,
            agent_role="claims_agent",
            user_id="u1",
            source_id="claims_db",
            session_id=sid,
        )
        safe.invoke_agent(
            inputText="Show claim details",
            agentId="ABCDEF1234",
            agentAliasId="TSTALIASID",
            sessionId="sess-999",
        )
        assert mock_client.last_call_kwargs["agentId"] == "ABCDEF1234"
        assert mock_client.last_call_kwargs["agentAliasId"] == "TSTALIASID"
        assert mock_client.last_call_kwargs["sessionId"] == "sess-999"
        assert mock_client.last_call_kwargs["inputText"] == "Show claim details"

    def test_audit_event_recorded(self, guard, sid, mock_client):
        safe = guard.wrap_invoke_agent(
            mock_client,
            agent_role="claims_agent",
            user_id="u1",
            source_id="claims_db",
            session_id=sid,
        )
        safe.invoke_agent(inputText="List open claims")
        events = guard.get_audit_trail(sid)
        assert len(events) == 1

    def test_source_type_is_bedrock(self, guard, sid, mock_client):
        safe = guard.wrap_invoke_agent(
            mock_client,
            agent_role="claims_agent",
            user_id="u1",
            source_id="claims_db",
            session_id=sid,
        )
        safe.invoke_agent(inputText="Get claim summary")
        events = guard.get_audit_trail(sid)
        assert events[0].source_type == "bedrock"

    def test_getattr_delegates_to_client(self, guard, sid, mock_client):
        safe = guard.wrap_invoke_agent(
            mock_client,
            agent_role="claims_agent",
            user_id="u1",
            source_id="claims_db",
            session_id=sid,
        )
        # region_name is an attribute on the mock client, not on the guarded proxy
        assert safe.region_name == "us-east-1"

    def test_denied_client_never_called(self, guard, sid, mock_client):
        safe = guard.wrap_invoke_agent(
            mock_client,
            agent_role="claims_agent",
            user_id="u1",
            source_id="other_policyholder_data",    # denied
            session_id=sid,
        )
        with pytest.raises(PermissionError):
            safe.invoke_agent(inputText="Get other holder's data")
        # Client should never have been invoked
        assert mock_client.last_call_kwargs == {}


# ── TestBedrockGuardWrapInvokeAgentAsync ─────────────────────────────────────

class TestBedrockGuardWrapInvokeAgentAsync:

    @pytest.mark.asyncio
    async def test_async_allowed_returns_response(self, guard, sid, mock_client):
        safe = guard.wrap_invoke_agent_async(
            mock_client,
            agent_role="claims_agent",
            user_id="u1",
            source_id="claims_db",
            session_id=sid,
        )
        result = await safe.invoke_agent(
            inputText="Async: show open claims",
            agentId="AGENT-001",
            agentAliasId="ALIAS-001",
            sessionId=sid,
        )
        assert result == mock_client._response

    @pytest.mark.asyncio
    async def test_async_denied_raises_permission_error(self, guard, sid, mock_client):
        safe = guard.wrap_invoke_agent_async(
            mock_client,
            agent_role="claims_agent",
            user_id="u1",
            source_id="internal_actuarial_models",  # denied
            session_id=sid,
        )
        with pytest.raises(PermissionError, match="DENIED"):
            await safe.invoke_agent(inputText="Get actuarial model")

    @pytest.mark.asyncio
    async def test_async_source_type_is_bedrock(self, guard, sid, mock_client):
        safe = guard.wrap_invoke_agent_async(
            mock_client,
            agent_role="claims_agent",
            user_id="u1",
            source_id="policy_documents",
            session_id=sid,
        )
        await safe.invoke_agent(inputText="Retrieve policy doc for POL-001")
        events = guard.get_audit_trail(sid)
        assert len(events) == 1
        assert events[0].source_type == "bedrock"

    @pytest.mark.asyncio
    async def test_async_fallback_sync_client(self, guard, sid):
        """If client.invoke_agent() is a sync function (not a coroutine), still works."""
        sync_client = MockBedrockClient(response={"completion": "sync_result"})
        safe = guard.wrap_invoke_agent_async(
            sync_client,
            agent_role="claims_agent",
            user_id="u1",
            source_id="claims_db",
            session_id=sid,
        )
        result = await safe.invoke_agent(inputText="Sync fallback test")
        assert result == {"completion": "sync_result"}

    @pytest.mark.asyncio
    async def test_async_getattr_delegates_to_client(self, guard, sid, mock_client):
        safe = guard.wrap_invoke_agent_async(
            mock_client,
            agent_role="claims_agent",
            user_id="u1",
            source_id="claims_db",
            session_id=sid,
        )
        assert safe.region_name == "us-east-1"


# ── TestBedrockGuardDecorator ─────────────────────────────────────────────────

class TestBedrockGuardDecorator:

    def test_protect_allows(self, guard, sid):
        @guard.protect(
            agent_role="claims_agent",
            user_id="u1",
            source_id="claims_db",
            session_id=sid,
        )
        def fetch_claim(query: str) -> dict:
            return {"claim_id": "CLM-001", "status": "open"}

        result = fetch_claim("Get claim CLM-001")
        assert result == {"claim_id": "CLM-001", "status": "open"}

    def test_protect_denies(self, guard, sid):
        @guard.protect(
            agent_role="claims_agent",
            user_id="u1",
            source_id="internal_actuarial_models",  # denied
            session_id=sid,
        )
        def fetch_model(query: str) -> dict:
            return {"model": "v7"}

        with pytest.raises(PermissionError, match="DENIED"):
            fetch_model("Get model parameters")

    def test_source_type_tagged(self, guard, sid):
        @guard.protect(
            agent_role="claims_agent",
            user_id="u1",
            source_id="policy_documents",
            session_id=sid,
        )
        def fetch_policy(query: str) -> dict:
            return {"policy": "POL-9901"}

        fetch_policy("Retrieve policy")
        events = guard.get_audit_trail(sid)
        assert len(events) == 1
        assert events[0].source_type == "bedrock"

    def test_protect_deny_source_type_tagged(self, guard, sid):
        @guard.protect(
            agent_role="claims_agent",
            user_id="u1",
            source_id="other_policyholder_data",    # denied
            session_id=sid,
        )
        def fetch(_: str) -> dict:
            return {}

        with pytest.raises(PermissionError):
            fetch("query")

        events = guard.get_audit_trail(sid)
        assert events[0].source_type == "bedrock"
        assert events[0].decision == Decision.DENY

    def test_sensitivity_ceiling_denied(self, guard, sid):
        @guard.protect(
            agent_role="claims_agent",
            user_id="u1",
            source_id="claims_db",
            sensitivity_level=SensitivityLevel.RESTRICTED,  # above max_sensitivity=high
            session_id=sid,
        )
        def fetch(_: str) -> dict:
            return {}

        with pytest.raises(PermissionError):
            fetch("query")

        events = guard.get_audit_trail(sid)
        assert events[0].decision == Decision.DENY
        assert events[0].source_type == "bedrock"

    def test_last_event_id_set_after_call(self, guard, sid):
        @guard.protect(
            agent_role="claims_agent",
            user_id="u1",
            source_id="claims_db",
            session_id=sid,
        )
        def fetch(_: str) -> dict:
            return {}

        assert guard.last_event_id is None
        fetch("q")
        assert guard.last_event_id is not None

    def test_multiple_calls_all_tagged_bedrock(self, guard, sid):
        @guard.protect(
            agent_role="claims_agent",
            user_id="u1",
            source_id="claims_db",
            session_id=sid,
        )
        def allowed(_): return {}

        @guard.protect(
            agent_role="claims_agent",
            user_id="u1",
            source_id="internal_actuarial_models",
            session_id=sid,
        )
        def denied(_): return {}

        allowed("q")
        with pytest.raises(PermissionError):
            denied("q")

        events = guard.get_audit_trail(sid)
        assert len(events) == 2
        assert all(e.source_type == "bedrock" for e in events)
        assert {e.decision for e in events} == {Decision.ALLOW, Decision.DENY}
