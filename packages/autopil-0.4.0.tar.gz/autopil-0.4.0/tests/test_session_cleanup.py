"""
Tests for session cleanup: purge_expired_sessions (SQLite) and SessionCleanupJob.
"""

import sqlite3
import time
import uuid
from datetime import datetime, timedelta, timezone
from unittest.mock import MagicMock, patch

import pytest

from autopil.db.sqlite import SQLiteSessionStore
from autopil.session_cleanup import SessionCleanupJob


# ── helpers ───────────────────────────────────────────────────────────────────

def _sid():
    return str(uuid.uuid4())


def _past_iso(days=100):
    return (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()


def _future_iso(days=1):
    return (datetime.now(timezone.utc) + timedelta(days=days)).isoformat()


# ── SQLiteSessionStore.purge_expired_sessions ─────────────────────────────────

@pytest.fixture
def store(tmp_path):
    return SQLiteSessionStore(str(tmp_path / "sessions.db"))


@pytest.fixture
def tenant():
    return "tenant_test"


def test_purge_nothing_when_db_empty(store, tenant):
    deleted = store.purge_expired_sessions(retention_days=90)
    assert deleted == 0


def test_purge_ignores_active_session(store, tenant):
    """Active sessions (no expires_at, not revoked) are never deleted."""
    sid = _sid()
    store.create_session(sid, "analyst", "u1", tenant)
    deleted = store.purge_expired_sessions(retention_days=0)
    assert deleted == 0
    assert store.get_session(sid, tenant) is not None


def test_purge_ignores_session_expired_within_retention_window(store, tenant):
    """A session expired 5 days ago should NOT be deleted if retention_days=90."""
    sid = _sid()
    store.create_session(sid, "analyst", "u1", tenant, ttl_minutes=1)
    # Manually set expires_at to 5 days ago (within 90-day window)
    five_days_ago = (datetime.now(timezone.utc) - timedelta(days=5)).isoformat()
    with sqlite3.connect(store.db_path) as conn:
        conn.execute(
            "UPDATE sessions SET expires_at = ? WHERE session_id = ?",
            (five_days_ago, sid),
        )
    deleted = store.purge_expired_sessions(retention_days=90)
    assert deleted == 0
    assert store.get_session(sid, tenant) is not None


def test_purge_deletes_session_expired_beyond_retention(store, tenant):
    """A session expired 100 days ago IS deleted when retention_days=90."""
    sid = _sid()
    store.create_session(sid, "analyst", "u1", tenant, ttl_minutes=1)
    old_expiry = _past_iso(days=100)
    with sqlite3.connect(store.db_path) as conn:
        conn.execute(
            "UPDATE sessions SET expires_at = ? WHERE session_id = ?",
            (old_expiry, sid),
        )
    deleted = store.purge_expired_sessions(retention_days=90)
    assert deleted == 1
    assert store.get_session(sid, tenant) is None


def test_purge_deletes_revoked_session_beyond_retention(store, tenant):
    """A revoked session whose last_active is 100 days ago is deleted."""
    sid = _sid()
    store.create_session(sid, "analyst", "u1", tenant)
    store.revoke_session(sid, tenant)
    # Backdate last_active to beyond retention window
    old_ts = _past_iso(days=100)
    with sqlite3.connect(store.db_path) as conn:
        conn.execute(
            "UPDATE sessions SET last_active = ? WHERE session_id = ?",
            (old_ts, sid),
        )
    deleted = store.purge_expired_sessions(retention_days=90)
    assert deleted == 1
    assert store.get_session(sid, tenant) is None


def test_purge_keeps_recently_revoked_session(store, tenant):
    """A revoked session with last_active 5 days ago is kept when retention_days=90."""
    sid = _sid()
    store.create_session(sid, "analyst", "u1", tenant)
    store.revoke_session(sid, tenant)
    # last_active stays at now — well within 90-day window
    deleted = store.purge_expired_sessions(retention_days=90)
    assert deleted == 0
    assert store.get_session(sid, tenant) is not None


def test_purge_deletes_only_eligible_rows(store, tenant):
    """Mixed session states: only the one beyond retention window is deleted."""
    # Active — should survive
    active = _sid()
    store.create_session(active, "analyst", "u1", tenant)

    # Expired 5 days ago — within retention window, should survive
    recent_expired = _sid()
    store.create_session(recent_expired, "analyst", "u1", tenant, ttl_minutes=1)
    five_ago = (datetime.now(timezone.utc) - timedelta(days=5)).isoformat()
    with sqlite3.connect(store.db_path) as conn:
        conn.execute(
            "UPDATE sessions SET expires_at = ? WHERE session_id = ?",
            (five_ago, recent_expired),
        )

    # Expired 100 days ago — beyond retention, should be deleted
    old_expired = _sid()
    store.create_session(old_expired, "analyst", "u1", tenant, ttl_minutes=1)
    old_ts = _past_iso(days=100)
    with sqlite3.connect(store.db_path) as conn:
        conn.execute(
            "UPDATE sessions SET expires_at = ? WHERE session_id = ?",
            (old_ts, old_expired),
        )

    deleted = store.purge_expired_sessions(retention_days=90)

    assert deleted == 1
    assert store.get_session(active, tenant) is not None
    assert store.get_session(recent_expired, tenant) is not None
    assert store.get_session(old_expired, tenant) is None


def test_purge_retention_days_zero_removes_all_expired(store, tenant):
    """retention_days=0 means delete anything expired or revoked right now."""
    # Session expired in the past (any past time counts with retention=0)
    sid = _sid()
    store.create_session(sid, "analyst", "u1", tenant, ttl_minutes=1)
    past = (datetime.now(timezone.utc) - timedelta(seconds=1)).isoformat()
    with sqlite3.connect(store.db_path) as conn:
        conn.execute(
            "UPDATE sessions SET expires_at = ? WHERE session_id = ?",
            (past, sid),
        )
    deleted = store.purge_expired_sessions(retention_days=0)
    assert deleted == 1


# ── SessionCleanupJob ─────────────────────────────────────────────────────────

def test_cleanup_job_calls_purge(tmp_path):
    """Job calls purge_expired_sessions on the store."""
    mock_store = MagicMock()
    mock_store.purge_expired_sessions.return_value = 3

    job = SessionCleanupJob(mock_store, retention_days=90, interval_seconds=1)
    job.start()
    time.sleep(0.2)   # let the thread tick at least once
    job.stop()

    mock_store.purge_expired_sessions.assert_called_with(90)


def test_cleanup_job_start_is_idempotent(tmp_path):
    """Calling start() twice doesn't create a second thread."""
    mock_store = MagicMock()
    mock_store.purge_expired_sessions.return_value = 0

    job = SessionCleanupJob(mock_store, retention_days=90, interval_seconds=1)
    job.start()
    first_thread = job._thread
    job.start()   # second call — should be a no-op
    assert job._thread is first_thread
    job.stop()


def test_cleanup_job_stop_signals_thread():
    """stop() sets the stop event."""
    mock_store = MagicMock()
    mock_store.purge_expired_sessions.return_value = 0

    job = SessionCleanupJob(mock_store, retention_days=90, interval_seconds=3600)
    job.start()
    assert not job._stop_event.is_set()
    job.stop()
    assert job._stop_event.is_set()


def test_cleanup_job_survives_purge_exception():
    """An exception in purge_expired_sessions is caught; the thread keeps running."""
    mock_store = MagicMock()
    call_count = {"n": 0}

    def side_effect(days):
        call_count["n"] += 1
        if call_count["n"] == 1:
            raise RuntimeError("DB connection lost")
        return 0

    mock_store.purge_expired_sessions.side_effect = side_effect

    job = SessionCleanupJob(mock_store, retention_days=90, interval_seconds=1)
    job.start()
    time.sleep(2.5)   # allow two full 1-second interval cycles to complete
    job.stop()

    # Should have been called more than once — survived the first exception
    assert mock_store.purge_expired_sessions.call_count >= 2


def test_cleanup_job_is_daemon_thread():
    """The cleanup thread must be a daemon so it doesn't block process exit."""
    mock_store = MagicMock()
    mock_store.purge_expired_sessions.return_value = 0

    job = SessionCleanupJob(mock_store, retention_days=90, interval_seconds=3600)
    job.start()
    assert job._thread.daemon is True
    job.stop()


# ── Postgres purge_expired_sessions (mock) ────────────────────────────────────

def test_postgres_purge_expired_sessions_calls_delete():
    """PostgresSessionStore.purge_expired_sessions runs the DELETE statement."""
    from contextlib import contextmanager
    from unittest.mock import MagicMock, patch

    cursor = MagicMock()
    cursor.rowcount = 5

    cur_ctx = MagicMock()
    cur_ctx.__enter__ = lambda s: cursor
    cur_ctx.__exit__ = MagicMock(return_value=False)

    conn = MagicMock()
    conn.cursor.return_value = cur_ctx

    pool = MagicMock()
    pool.getconn.return_value = conn

    with patch("autopil.db.postgres.psycopg2.pool.ThreadedConnectionPool") as mock_cls:
        mock_cls.return_value = pool
        from autopil.db.postgres import PostgresSessionStore
        ss = PostgresSessionStore("postgresql://fake/db")
        deleted = ss.purge_expired_sessions(retention_days=90)

    assert deleted == 5
    calls = cursor.execute.call_args_list
    delete_call = next((c for c in calls if "DELETE FROM sessions" in str(c)), None)
    assert delete_call is not None


# ── create_app wires up SessionCleanupJob ─────────────────────────────────────

def test_create_app_starts_cleanup_job_when_retention_set(tmp_path, policy_file):
    """create_app starts SessionCleanupJob when session_retention_days is provided."""
    from autopil.api.app import create_app
    with patch("autopil.api.app.SessionCleanupJob") as mock_job_cls:
        mock_job = MagicMock()
        mock_job_cls.return_value = mock_job
        create_app(
            policy_path=str(policy_file),
            audit_db=str(tmp_path / "test.db"),
            session_retention_days=90,
            session_cleanup_interval=3600,
        )
    mock_job_cls.assert_called_once()
    _, kwargs = mock_job_cls.call_args
    assert kwargs["retention_days"] == 90
    assert kwargs["interval_seconds"] == 3600
    mock_job.start.assert_called_once()


def test_create_app_does_not_start_cleanup_job_when_retention_not_set(tmp_path, policy_file):
    """create_app does not start SessionCleanupJob when session_retention_days is None."""
    from autopil.api.app import create_app
    with patch("autopil.api.app.SessionCleanupJob") as mock_job_cls:
        create_app(
            policy_path=str(policy_file),
            audit_db=str(tmp_path / "test.db"),
            session_retention_days=None,
        )
    mock_job_cls.assert_not_called()
