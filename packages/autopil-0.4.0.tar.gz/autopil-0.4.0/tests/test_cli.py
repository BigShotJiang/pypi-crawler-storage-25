"""
Tests for autopil/cli.py — bootstrap logic and demo agent seeding.

uvicorn.run is always mocked so no server is started.
"""

import uuid
from datetime import datetime, timezone
from unittest.mock import patch, MagicMock

import pytest

from autopil.db import create_stores
from autopil.cli import _seed_demo_agents, _DEMO_AGENTS


# ── fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def db_stores(tmp_path):
    db = str(tmp_path / "cli_test.db")
    return create_stores(db_path=db), db


# ── _seed_demo_agents ─────────────────────────────────────────────────────────

def test_seed_demo_agents_creates_all_agents(db_stores):
    stores, _ = db_stores
    agent_registry_store = stores[7]
    _, _, tenant_store = stores[0], stores[1], stores[2]
    tenant_id = tenant_store.create_tenant("seed_test")

    _seed_demo_agents(agent_registry_store, tenant_id)

    agents = agent_registry_store.list_agents(tenant_id)
    assert len(agents) == len(_DEMO_AGENTS)


def test_seed_demo_agents_correct_roles(db_stores):
    stores, _ = db_stores
    agent_registry_store = stores[7]
    _, _, tenant_store = stores[0], stores[1], stores[2]
    tenant_id = tenant_store.create_tenant("roles_test")

    _seed_demo_agents(agent_registry_store, tenant_id)

    agents = agent_registry_store.list_agents(tenant_id)
    roles = {a.agent_role for a in agents}
    expected_roles = {a["agent_role"] for a in _DEMO_AGENTS}
    assert roles == expected_roles


def test_seed_demo_agents_all_approved(db_stores):
    stores, _ = db_stores
    agent_registry_store = stores[7]
    _, _, tenant_store = stores[0], stores[1], stores[2]
    tenant_id = tenant_store.create_tenant("approved_test")

    _seed_demo_agents(agent_registry_store, tenant_id)

    agents = agent_registry_store.list_agents(tenant_id)
    assert all(a.status == "approved" for a in agents)


def test_seed_demo_agents_idempotent_on_exception(db_stores):
    """_seed_demo_agents swallows exceptions per agent — partial failures don't crash."""
    stores, _ = db_stores
    agent_registry_store = stores[7]
    _, _, tenant_store = stores[0], stores[1], stores[2]
    tenant_id = tenant_store.create_tenant("exc_test")

    # Patch create to raise on first call, succeed on the rest
    original_create = agent_registry_store.create
    call_count = [0]

    def flaky_create(entry, tid):
        call_count[0] += 1
        if call_count[0] == 1:
            raise RuntimeError("simulated failure")
        return original_create(entry, tid)

    agent_registry_store.create = flaky_create
    _seed_demo_agents(agent_registry_store, tenant_id)  # must not raise

    agents = agent_registry_store.list_agents(tenant_id)
    assert len(agents) == len(_DEMO_AGENTS) - 1  # first one failed, rest seeded


def test_seed_demo_agents_scoped_to_tenant(db_stores):
    """Agents seeded for tenant A are not visible to tenant B."""
    stores, _ = db_stores
    agent_registry_store = stores[7]
    _, _, tenant_store = stores[0], stores[1], stores[2]
    t1 = tenant_store.create_tenant("tenant_a")
    t2 = tenant_store.create_tenant("tenant_b")

    _seed_demo_agents(agent_registry_store, t1)

    assert len(agent_registry_store.list_agents(t1)) == len(_DEMO_AGENTS)
    assert agent_registry_store.list_agents(t2) == []


# ── main() bootstrap ──────────────────────────────────────────────────────────

def _run_main(db_path, extra_env=None):
    """Run cli.main() with uvicorn and telemetry mocked out."""
    import os
    env = {"AUTOPIL_DB": db_path}
    if extra_env:
        env.update(extra_env)
    with patch.dict(os.environ, env, clear=False), \
         patch("uvicorn.run"), \
         patch("autopil.telemetry.setup", return_value=False), \
         patch("sys.argv", ["autopil-serve"]):
        from autopil.cli import main
        main()


def test_main_creates_default_tenant_on_first_start(tmp_path):
    db = str(tmp_path / "bootstrap.db")
    stores = create_stores(db_path=db)
    _, _, tenant_store = stores[0], stores[1], stores[2]

    assert tenant_store.count() == 0
    _run_main(db)
    assert tenant_store.count() == 1


def test_main_creates_superadmin_key_on_first_start(tmp_path):
    db = str(tmp_path / "bootstrap_key.db")
    stores = create_stores(db_path=db)
    _, key_store = stores[0], stores[1]

    assert key_store.count() == 0
    _run_main(db)
    assert key_store.count() >= 1


def test_main_creates_key_if_tenant_exists_but_no_keys(tmp_path):
    db = str(tmp_path / "nokeys.db")
    stores = create_stores(db_path=db)
    _, key_store, tenant_store = stores[0], stores[1], stores[2]

    # Pre-create a tenant but no keys
    tenant_store.create_tenant("existing_tenant")
    assert key_store.count() == 0

    _run_main(db)
    assert key_store.count() >= 1


def test_main_does_not_duplicate_tenant_on_second_start(tmp_path):
    db = str(tmp_path / "idempotent.db")
    _run_main(db)
    _run_main(db)

    stores = create_stores(db_path=db)
    _, _, tenant_store = stores[0], stores[1], stores[2]
    assert tenant_store.count() == 1


def test_main_seeds_agents_for_default_tenant(tmp_path):
    db = str(tmp_path / "agents.db")
    _run_main(db)

    stores = create_stores(db_path=db)
    agent_registry_store = stores[7]
    _, _, tenant_store = stores[0], stores[1], stores[2]

    tenants = tenant_store.list_tenants()
    assert len(tenants) == 1
    agents = agent_registry_store.list_agents(tenants[0]["tenant_id"])
    assert len(agents) == len(_DEMO_AGENTS)


def test_main_does_not_reseed_agents_on_second_start(tmp_path):
    db = str(tmp_path / "no_reseed.db")
    _run_main(db)
    _run_main(db)

    stores = create_stores(db_path=db)
    agent_registry_store = stores[7]
    _, _, tenant_store = stores[0], stores[1], stores[2]
    tenants = tenant_store.list_tenants()
    agents = agent_registry_store.list_agents(tenants[0]["tenant_id"])
    assert len(agents) == len(_DEMO_AGENTS)
