"""
Tests for GeminiGuard — AutoPIL's integration layer for Google Gemini agents.

Verifies that:
- GeminiGuard stamps source_type='gemini' on every audit event
- ALLOW / DENY policy enforcement works correctly
- call_if_allowed() dispatches to fn on ALLOW, raises PermissionError on DENY
- Audit trail correctly records Gemini events distinct from sdk/rest/mcp events
"""

import os
import uuid
import tempfile
import textwrap
import pytest

from autopil.gemini_guard import GeminiGuard
from autopil.models import Decision, SensitivityLevel


# ── fixtures ─────────────────────────────────────────────────────────────────

POLICY_YAML = textwrap.dedent("""\
policies:
  - name: wealth_advisor_policy
    agent_role: wealth_advisor
    allowed_sources:
      - client_portfolios
      - market_risk_scores
    denied_sources:
      - other_client_data
      - proprietary_models
    max_sensitivity: high
""")


@pytest.fixture
def guard(tmp_path):
    policy_file = tmp_path / "policy.yaml"
    policy_file.write_text(POLICY_YAML)
    db_path = str(tmp_path / "test.db")
    return GeminiGuard(policy_path=str(policy_file), audit_db=db_path)


@pytest.fixture
def session_id():
    return str(uuid.uuid4())


# ── source_type tagging ───────────────────────────────────────────────────────

class TestSourceTypeTagging:
    def test_allowed_event_tagged_gemini(self, guard, session_id):
        @guard.protect(
            agent_role="wealth_advisor",
            user_id="u1",
            source_id="client_portfolios",
            sensitivity_level=SensitivityLevel.MEDIUM,
            session_id=session_id,
        )
        def fetch(_: str) -> dict:
            return {"balance": 100}

        fetch("query")
        events = guard.get_audit_trail(session_id)
        assert len(events) == 1
        assert events[0].source_type == "gemini"

    def test_denied_event_tagged_gemini(self, guard, session_id):
        @guard.protect(
            agent_role="wealth_advisor",
            user_id="u1",
            source_id="other_client_data",  # denied source
            sensitivity_level=SensitivityLevel.HIGH,
            session_id=session_id,
        )
        def fetch(_: str) -> dict:
            return {}

        with pytest.raises(PermissionError):
            fetch("query")

        events = guard.get_audit_trail(session_id)
        assert len(events) == 1
        assert events[0].source_type == "gemini"
        assert events[0].decision == Decision.DENY

    def test_source_type_is_not_sdk(self, guard, session_id):
        @guard.protect(
            agent_role="wealth_advisor",
            user_id="u1",
            source_id="client_portfolios",
            session_id=session_id,
        )
        def fetch(_: str) -> dict:
            return {}

        fetch("q")
        events = guard.get_audit_trail(session_id)
        assert events[0].source_type != "sdk"
        assert events[0].source_type != "rest"
        assert events[0].source_type != "mcp"


# ── policy enforcement ────────────────────────────────────────────────────────

class TestPolicyEnforcement:
    def test_allowed_source_returns_data(self, guard, session_id):
        @guard.protect(
            agent_role="wealth_advisor",
            user_id="u1",
            source_id="client_portfolios",
            session_id=session_id,
        )
        def fetch(_: str) -> dict:
            return {"aum": 4_200_000}

        result = fetch("get portfolio")
        assert result == {"aum": 4_200_000}

    def test_denied_source_raises(self, guard, session_id):
        @guard.protect(
            agent_role="wealth_advisor",
            user_id="u1",
            source_id="other_client_data",
            session_id=session_id,
        )
        def fetch(_: str) -> dict:
            return {}

        with pytest.raises(PermissionError, match="DENIED"):
            fetch("get data")

    def test_sensitivity_ceiling_denied(self, guard, session_id):
        @guard.protect(
            agent_role="wealth_advisor",
            user_id="u1",
            source_id="client_portfolios",
            sensitivity_level=SensitivityLevel.RESTRICTED,  # above max_sensitivity=high
            session_id=session_id,
        )
        def fetch(_: str) -> dict:
            return {}

        with pytest.raises(PermissionError):
            fetch("query")

        events = guard.get_audit_trail(session_id)
        assert events[0].decision == Decision.DENY
        assert events[0].source_type == "gemini"


# ── call_if_allowed ───────────────────────────────────────────────────────────

class TestCallIfAllowed:
    def test_allowed_dispatches_to_fn(self, guard, session_id):
        def retrieval_fn(customer_id: str) -> dict:
            return {"balance": 99_000}

        result = guard.call_if_allowed(
            fn=retrieval_fn,
            agent_role="wealth_advisor",
            user_id="u1",
            source_id="client_portfolios",
            sensitivity_level=SensitivityLevel.MEDIUM,
            session_id=session_id,
            fn_args={"customer_id": "cust_001"},
        )
        assert result == {"balance": 99_000}

    def test_denied_raises_permission_error(self, guard, session_id):
        def retrieval_fn(customer_id: str) -> dict:
            return {"data": "secret"}

        with pytest.raises(PermissionError):
            guard.call_if_allowed(
                fn=retrieval_fn,
                agent_role="wealth_advisor",
                user_id="u1",
                source_id="proprietary_models",  # denied
                session_id=session_id,
                fn_args={"customer_id": "cust_001"},
            )

    def test_call_if_allowed_tags_gemini(self, guard, session_id):
        def fn() -> str:
            return "ok"

        guard.call_if_allowed(
            fn=fn,
            agent_role="wealth_advisor",
            user_id="u1",
            source_id="market_risk_scores",
            session_id=session_id,
        )
        events = guard.get_audit_trail(session_id)
        assert events[0].source_type == "gemini"


# ── audit trail ───────────────────────────────────────────────────────────────

class TestAuditTrail:
    def test_multiple_calls_all_tagged_gemini(self, guard, session_id):
        @guard.protect(
            agent_role="wealth_advisor",
            user_id="u1",
            source_id="client_portfolios",
            session_id=session_id,
        )
        def allowed_fn(_: str) -> dict:
            return {}

        @guard.protect(
            agent_role="wealth_advisor",
            user_id="u1",
            source_id="other_client_data",
            session_id=session_id,
        )
        def denied_fn(_: str) -> dict:
            return {}

        allowed_fn("q1")
        with pytest.raises(PermissionError):
            denied_fn("q2")

        events = guard.get_audit_trail(session_id)
        assert len(events) == 2
        assert all(e.source_type == "gemini" for e in events)
        decisions = {e.decision for e in events}
        assert Decision.ALLOW in decisions
        assert Decision.DENY in decisions

    def test_last_event_id_set_after_call(self, guard, session_id):
        @guard.protect(
            agent_role="wealth_advisor",
            user_id="u1",
            source_id="client_portfolios",
            session_id=session_id,
        )
        def fetch(_: str) -> dict:
            return {}

        assert guard.last_event_id is None
        fetch("q")
        assert guard.last_event_id is not None
