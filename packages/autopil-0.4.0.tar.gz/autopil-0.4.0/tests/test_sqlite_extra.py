"""
Additional tests for autopil/db/sqlite.py — covering methods and branches
not reached by the existing test suite.

Covers: _ts_str, purge_old_events, rotate_key, key count by tenant,
get_tenant not-found, policy count, update_rule no-op, get_actions_for_session,
session is_valid branches, and full SQLiteAgentRegistryStore CRUD.
"""

import uuid
from datetime import datetime, timedelta, timezone

import pytest

from autopil.db import create_stores
from autopil.db.sqlite import (
    SQLiteAgentRegistryStore,
    SQLiteAuditLog,
    SQLiteKeyStore,
    SQLiteLineageStore,
    SQLitePolicyStore,
    SQLiteSessionStore,
    SQLiteTenantStore,
    _ts_str,
)
from autopil.models import AgentAction, AgentRegistryEntry, AuditEvent, Decision


# ── fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def db(tmp_path) -> str:
    return str(tmp_path / "extra_test.db")


@pytest.fixture
def audit_log(db):
    return SQLiteAuditLog(db)


@pytest.fixture
def key_store(db):
    return SQLiteKeyStore(db)


@pytest.fixture
def tenant_store(db):
    return SQLiteTenantStore(db)


@pytest.fixture
def policy_store(db):
    return SQLitePolicyStore(db)


@pytest.fixture
def lineage_store(db):
    return SQLiteLineageStore(db)


@pytest.fixture
def session_store(db):
    return SQLiteSessionStore(db)


@pytest.fixture
def agent_registry(db):
    return SQLiteAgentRegistryStore(db)


@pytest.fixture
def tenant_id(tenant_store):
    return tenant_store.create_tenant("extra_test_tenant")


def _make_event(agent_role="analyst", session_id=None, decision=Decision.ALLOW,
                source_id="reports") -> AuditEvent:
    return AuditEvent(
        event_id=str(uuid.uuid4()),
        session_id=session_id or str(uuid.uuid4()),
        agent_role=agent_role,
        user_id="u1",
        source_id=source_id,
        query="test query",
        decision=decision,
        policy_name="pol",
        reason="r",
        timestamp=datetime.utcnow(),
    )


def _make_entry(agent_role="analyst", status="approved", framework=None, owner=None) -> AgentRegistryEntry:
    now = datetime.utcnow()
    return AgentRegistryEntry(
        agent_id=str(uuid.uuid4()),
        tenant_id="placeholder",
        agent_role=agent_role,
        display_name=agent_role.title(),
        status=status,
        version="1.0.0",
        created_at=now,
        updated_at=now,
        framework=framework,
        owner=owner,
    )


# ── _ts_str ───────────────────────────────────────────────────────────────────

def test_ts_str_with_datetime():
    dt = datetime(2024, 6, 15, 12, 0, 0)
    result = _ts_str(dt)
    assert result == dt.isoformat()


def test_ts_str_with_non_datetime():
    # Line 22: the else branch — converts non-datetime to str
    result = _ts_str("2024-06-15T12:00:00")
    assert result == "2024-06-15T12:00:00"
    result2 = _ts_str(12345)
    assert result2 == "12345"


# ── SQLiteAuditLog.purge_old_events ──────────────────────────────────────────

def test_purge_old_events_with_tenant_id(audit_log, db):
    tenant_store = SQLiteTenantStore(db)
    tid = tenant_store.create_tenant("purge_tenant")
    # Record an old event
    old_event = _make_event()
    old_event.timestamp = datetime.utcnow() - timedelta(days=10)
    # SQLite records use isoformat so we need to insert with old timestamp
    import sqlite3
    with sqlite3.connect(db) as conn:
        conn.execute(
            """INSERT INTO audit_events
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (old_event.event_id, old_event.session_id, old_event.agent_role,
             old_event.user_id, old_event.source_id, old_event.query,
             old_event.decision.value, old_event.policy_name, old_event.reason,
             None, old_event.timestamp.isoformat(), tid, None, "rest", 0, None, 0),
        )
    count = audit_log.purge_old_events(retention_days=5, tenant_id=tid)
    assert count == 1


def test_purge_old_events_without_tenant_id(audit_log, db):
    """No tenant_id → purges across all tenants."""
    import sqlite3
    old_ts = (datetime.utcnow() - timedelta(days=30)).isoformat()
    eid = str(uuid.uuid4())
    with sqlite3.connect(db) as conn:
        conn.execute(
            """INSERT INTO audit_events
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (eid, str(uuid.uuid4()), "analyst", "u1", "src",
             "q", "ALLOW", "pol", "r", None, old_ts, "t1", None, "rest", 0, None, 0),
        )
    count = audit_log.purge_old_events(retention_days=5)
    assert count == 1


def test_purge_old_events_returns_zero_when_nothing_old(audit_log):
    event = _make_event()
    audit_log.record(event, tenant_id="t1")
    count = audit_log.purge_old_events(retention_days=1)
    assert count == 0


# ── SQLiteKeyStore.rotate_key ─────────────────────────────────────────────────

def test_rotate_key_returns_new_key(key_store, tenant_id):
    key_id, _ = key_store.create_key("test_key", tenant_id=tenant_id)
    result = key_store.rotate_key(key_id, tenant_id)
    assert result is not None
    new_id, plaintext = result
    assert new_id != key_id
    assert plaintext.startswith("apl_")


def test_rotate_key_invalidates_old_key(key_store, tenant_id):
    key_id, old_plaintext = key_store.create_key("test_key", tenant_id=tenant_id)
    key_store.rotate_key(key_id, tenant_id)
    assert key_store.validate(old_plaintext) is None


def test_rotate_key_unknown_key_returns_none(key_store, tenant_id):
    result = key_store.rotate_key("nonexistent_key_id", tenant_id)
    assert result is None


# ── SQLiteKeyStore.count by tenant ────────────────────────────────────────────

def test_key_count_by_tenant(key_store, tenant_id):
    assert key_store.count(tenant_id=tenant_id) == 0
    key_store.create_key("k1", tenant_id=tenant_id)
    key_store.create_key("k2", tenant_id=tenant_id)
    assert key_store.count(tenant_id=tenant_id) == 2


# ── SQLiteTenantStore.get_tenant not found ────────────────────────────────────

def test_get_tenant_not_found(tenant_store):
    result = tenant_store.get_tenant("ten_nonexistent")
    assert result is None


# ── SQLitePolicyStore.count ───────────────────────────────────────────────────

def test_policy_count(policy_store, tenant_id):
    assert policy_store.count(tenant_id) == 0
    policy_store.upsert({"name": "p1", "agent_role": "analyst"}, tenant_id)
    policy_store.upsert({"name": "p2", "agent_role": "viewer"}, tenant_id)
    assert policy_store.count(tenant_id) == 2


# ── SQLiteAlertStore.update_rule no-op ───────────────────────────────────────

def test_update_rule_with_no_valid_fields(stores, tenant_id):
    """update_rule returns False when no valid fields are in updates."""
    _, _, _, _, alert_store, _, _, _ = stores
    rule_id = alert_store.create_rule({"name": "R", "rule_type": "denial_spike"}, tenant_id)
    result = alert_store.update_rule(rule_id, {"nonexistent_field": "value"}, tenant_id)
    assert result is False


# ── SQLiteLineageStore.get_actions_for_session ────────────────────────────────

def test_get_actions_for_session(lineage_store, audit_log, tenant_id):
    event = _make_event()
    audit_log.record(event, tenant_id=tenant_id)
    action = AgentAction(
        action_id=str(uuid.uuid4()),
        event_id=event.event_id,
        session_id=event.session_id,
        agent_role=event.agent_role,
        action_type="read",
        action_detail={"rows": 5},
        outcome="success",
        timestamp=datetime.utcnow(),
    )
    lineage_store.record_action(action, tenant_id=tenant_id)

    results = lineage_store.get_actions_for_session(event.session_id, tenant_id)
    assert len(results) == 1
    assert results[0].action_type == "read"
    assert results[0].action_detail == {"rows": 5}


def test_get_actions_for_session_empty(lineage_store, tenant_id):
    results = lineage_store.get_actions_for_session(str(uuid.uuid4()), tenant_id)
    assert results == []


# ── SQLiteSessionStore.touch_session ownership ────────────────────────────────

def test_touch_session_correct_owner_returns_true(session_store, tenant_id):
    sid = str(uuid.uuid4())
    session_store.create_session(sid, "analyst", "u1", tenant_id)
    result = session_store.touch_session(sid, tenant_id, "analyst")
    assert result is True


def test_touch_session_wrong_owner_returns_false(session_store, tenant_id):
    """A different agent_role cannot update last_active on a session it doesn't own."""
    sid = str(uuid.uuid4())
    session_store.create_session(sid, "analyst", "u1", tenant_id)
    result = session_store.touch_session(sid, tenant_id, "rogue_agent")
    assert result is False


def test_touch_session_wrong_owner_does_not_modify_row(session_store, tenant_id):
    """Verify last_active is unchanged after a wrong-owner touch attempt."""
    import time
    sid = str(uuid.uuid4())
    session_store.create_session(sid, "analyst", "u1", tenant_id)
    before = session_store.get_session(sid, tenant_id)["last_active"]

    time.sleep(0.01)
    session_store.touch_session(sid, tenant_id, "rogue_agent")
    after = session_store.get_session(sid, tenant_id)["last_active"]

    assert after == before


def test_touch_session_unknown_session_returns_false(session_store, tenant_id):
    result = session_store.touch_session("nonexistent", tenant_id, "analyst")
    assert result is False


# ── SQLiteSessionStore.is_valid ───────────────────────────────────────────────

def test_is_valid_session_not_found(session_store, tenant_id):
    valid, reason = session_store.is_valid("nonexistent", tenant_id)
    assert valid is False
    assert reason == "session_not_found"


def test_is_valid_session_revoked(session_store, tenant_id):
    sid = str(uuid.uuid4())
    session_store.create_session(sid, "analyst", "u1", tenant_id)
    session_store.revoke_session(sid, tenant_id)
    valid, reason = session_store.is_valid(sid, tenant_id)
    assert valid is False
    assert reason == "session_revoked"


def test_is_valid_session_expired(session_store, tenant_id):
    sid = str(uuid.uuid4())
    session_store.create_session(sid, "analyst", "u1", tenant_id, ttl_minutes=1)
    # Manually expire it by setting expires_at in the past (with timezone)
    import sqlite3
    db_path = session_store.db_path
    past = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
    with sqlite3.connect(db_path) as conn:
        conn.execute(
            "UPDATE sessions SET expires_at = ? WHERE session_id = ?", (past, sid)
        )
    valid, reason = session_store.is_valid(sid, tenant_id)
    assert valid is False
    assert reason == "session_expired"


def test_is_valid_session_expired_naive_timestamp(session_store, tenant_id):
    """Line 898: expires_at stored without timezone → tzinfo attached before compare."""
    sid = str(uuid.uuid4())
    session_store.create_session(sid, "analyst", "u1", tenant_id, ttl_minutes=1)
    import sqlite3
    db_path = session_store.db_path
    # Store a naive ISO timestamp (no +00:00) that is in the past
    past_naive = (datetime.utcnow() - timedelta(hours=1)).strftime("%Y-%m-%dT%H:%M:%S")
    with sqlite3.connect(db_path) as conn:
        conn.execute(
            "UPDATE sessions SET expires_at = ? WHERE session_id = ?", (past_naive, sid)
        )
    valid, reason = session_store.is_valid(sid, tenant_id)
    assert valid is False
    assert reason == "session_expired"


def test_is_valid_session_active(session_store, tenant_id):
    sid = str(uuid.uuid4())
    session_store.create_session(sid, "analyst", "u1", tenant_id)
    valid, reason = session_store.is_valid(sid, tenant_id)
    assert valid is True
    assert reason == ""


# ── revoke_sessions_by ────────────────────────────────────────────────────────

def test_revoke_sessions_by_agent_role(session_store, tenant_id):
    sid1, sid2, sid3 = str(uuid.uuid4()), str(uuid.uuid4()), str(uuid.uuid4())
    session_store.create_session(sid1, "analyst", "u1", tenant_id)
    session_store.create_session(sid2, "analyst", "u2", tenant_id)
    session_store.create_session(sid3, "trader",  "u1", tenant_id)
    count = session_store.revoke_sessions_by(tenant_id, agent_role="analyst")
    assert count == 2
    assert session_store.get_session(sid1, tenant_id)["is_revoked"] is True
    assert session_store.get_session(sid2, tenant_id)["is_revoked"] is True
    assert session_store.get_session(sid3, tenant_id)["is_revoked"] is False


def test_revoke_sessions_by_user_id(session_store, tenant_id):
    sid1, sid2, sid3 = str(uuid.uuid4()), str(uuid.uuid4()), str(uuid.uuid4())
    session_store.create_session(sid1, "analyst", "alice", tenant_id)
    session_store.create_session(sid2, "trader",  "alice", tenant_id)
    session_store.create_session(sid3, "analyst", "bob",   tenant_id)
    count = session_store.revoke_sessions_by(tenant_id, user_id="alice")
    assert count == 2
    assert session_store.get_session(sid1, tenant_id)["is_revoked"] is True
    assert session_store.get_session(sid2, tenant_id)["is_revoked"] is True
    assert session_store.get_session(sid3, tenant_id)["is_revoked"] is False


def test_revoke_sessions_by_both_filters(session_store, tenant_id):
    sid1, sid2, sid3 = str(uuid.uuid4()), str(uuid.uuid4()), str(uuid.uuid4())
    session_store.create_session(sid1, "analyst", "alice", tenant_id)
    session_store.create_session(sid2, "analyst", "bob",   tenant_id)
    session_store.create_session(sid3, "trader",  "alice", tenant_id)
    count = session_store.revoke_sessions_by(tenant_id, agent_role="analyst", user_id="alice")
    assert count == 1  # only sid1 matches both
    assert session_store.get_session(sid1, tenant_id)["is_revoked"] is True
    assert session_store.get_session(sid2, tenant_id)["is_revoked"] is False
    assert session_store.get_session(sid3, tenant_id)["is_revoked"] is False


def test_revoke_sessions_by_no_filters_raises(session_store, tenant_id):
    with pytest.raises(ValueError, match="At least one"):
        session_store.revoke_sessions_by(tenant_id)


def test_revoke_sessions_by_skips_already_revoked(session_store, tenant_id):
    sid = str(uuid.uuid4())
    session_store.create_session(sid, "analyst", "u1", tenant_id)
    session_store.revoke_session(sid, tenant_id)
    count = session_store.revoke_sessions_by(tenant_id, agent_role="analyst")
    assert count == 0  # already revoked — not counted again


def test_revoke_sessions_by_no_match_returns_zero(session_store, tenant_id):
    count = session_store.revoke_sessions_by(tenant_id, agent_role="nonexistent_role")
    assert count == 0


# ── SQLiteAgentRegistryStore — full CRUD ─────────────────────────────────────

def test_ensure_registered_creates_new_agent(agent_registry, tenant_id):
    agent_id = agent_registry.ensure_registered("analyst", tenant_id)
    assert agent_id is not None
    assert len(agent_id) > 0


def test_ensure_registered_idempotent(agent_registry, tenant_id):
    id1 = agent_registry.ensure_registered("analyst", tenant_id)
    id2 = agent_registry.ensure_registered("analyst", tenant_id)
    assert id1 == id2


def test_get_returns_entry(agent_registry, tenant_id):
    entry = _make_entry()
    agent_registry.create(entry, tenant_id)
    result = agent_registry.get(entry.agent_id, tenant_id)
    assert result is not None
    assert result.agent_id == entry.agent_id
    assert result.agent_role == entry.agent_role


def test_get_returns_none_for_missing(agent_registry, tenant_id):
    result = agent_registry.get("nonexistent_id", tenant_id)
    assert result is None


def test_get_by_role_found(agent_registry, tenant_id):
    entry = _make_entry(agent_role="viewer")
    agent_registry.create(entry, tenant_id)
    result = agent_registry.get_by_role("viewer", tenant_id)
    assert result is not None
    assert result.agent_role == "viewer"


def test_get_by_role_not_found(agent_registry, tenant_id):
    result = agent_registry.get_by_role("nonexistent_role", tenant_id)
    assert result is None


def test_list_agents_filter_by_status(agent_registry, tenant_id):
    agent_registry.create(_make_entry(agent_role="analyst", status="approved"), tenant_id)
    agent_registry.create(_make_entry(agent_role="viewer", status="draft"), tenant_id)
    approved = agent_registry.list_agents(tenant_id, status="approved")
    assert len(approved) == 1
    assert approved[0].agent_role == "analyst"


def test_list_agents_filter_by_framework(agent_registry, tenant_id):
    agent_registry.create(_make_entry(agent_role="analyst", framework="langchain"), tenant_id)
    agent_registry.create(_make_entry(agent_role="viewer", framework="openai_agents"), tenant_id)
    results = agent_registry.list_agents(tenant_id, framework="langchain")
    assert len(results) == 1
    assert results[0].agent_role == "analyst"


def test_list_agents_filter_by_owner(agent_registry, tenant_id):
    agent_registry.create(_make_entry(agent_role="analyst", owner="team_a"), tenant_id)
    agent_registry.create(_make_entry(agent_role="viewer", owner="team_b"), tenant_id)
    results = agent_registry.list_agents(tenant_id, owner="team_a")
    assert len(results) == 1
    assert results[0].agent_role == "analyst"


def test_update_agent_fields(agent_registry, tenant_id):
    entry = _make_entry(agent_role="analyst")
    agent_registry.create(entry, tenant_id)
    result = agent_registry.update(
        entry.agent_id,
        {"display_name": "Senior Analyst", "description": "Updated desc"},
        tenant_id,
    )
    assert result is True
    updated = agent_registry.get(entry.agent_id, tenant_id)
    assert updated.display_name == "Senior Analyst"
    assert updated.description == "Updated desc"


def test_update_agent_no_valid_fields(agent_registry, tenant_id):
    entry = _make_entry()
    agent_registry.create(entry, tenant_id)
    result = agent_registry.update(entry.agent_id, {"nonexistent": "value"}, tenant_id)
    assert result is False


def test_update_status_approved_with_approver(agent_registry, tenant_id):
    entry = _make_entry(agent_role="analyst", status="pending_approval")
    agent_registry.create(entry, tenant_id)
    result = agent_registry.update_status(
        entry.agent_id, "approved", tenant_id, approved_by="admin_user"
    )
    assert result is True
    updated = agent_registry.get(entry.agent_id, tenant_id)
    assert updated.status == "approved"
    assert updated.approved_by == "admin_user"


def test_update_status_without_approver(agent_registry, tenant_id):
    entry = _make_entry(agent_role="analyst", status="approved")
    agent_registry.create(entry, tenant_id)
    result = agent_registry.update_status(entry.agent_id, "deprecated", tenant_id)
    assert result is True
    updated = agent_registry.get(entry.agent_id, tenant_id)
    assert updated.status == "deprecated"


def test_update_status_nonexistent_agent(agent_registry, tenant_id):
    result = agent_registry.update_status("nonexistent", "approved", tenant_id)
    assert result is False


def test_get_activity_stats_empty_roles(agent_registry, tenant_id):
    result = agent_registry.get_activity_stats([], tenant_id)
    assert result == {}


def test_get_activity_stats_with_events(agent_registry, audit_log, tenant_id):
    entry = _make_entry(agent_role="analyst")
    agent_registry.create(entry, tenant_id)
    # Seed some audit events
    for _ in range(3):
        audit_log.record(_make_event(agent_role="analyst", decision=Decision.ALLOW), tenant_id)
    for _ in range(2):
        audit_log.record(_make_event(agent_role="analyst", decision=Decision.DENY), tenant_id)

    stats = agent_registry.get_activity_stats(["analyst"], tenant_id, days=1)
    assert "analyst" in stats
    assert stats["analyst"]["event_count_7d"] == 5
    assert stats["analyst"]["deny_rate_7d"] == pytest.approx(0.4)


def test_get_activity_stats_no_audit_table(tmp_path, tenant_id):
    """get_activity_stats returns {} gracefully when audit_events table doesn't exist."""
    registry_only_db = str(tmp_path / "registry_only.db")
    # Create registry store without creating audit log (no audit_events table)
    registry = SQLiteAgentRegistryStore(registry_only_db)
    # Creating a tenant manually
    import sqlite3
    with sqlite3.connect(registry_only_db) as conn:
        conn.execute("CREATE TABLE IF NOT EXISTS tenants (tenant_id TEXT PRIMARY KEY, name TEXT, created_at TEXT, is_active INTEGER DEFAULT 1)")
        conn.execute("INSERT INTO tenants VALUES ('t1', 'test', '2024-01-01', 1)")

    result = registry.get_activity_stats(["analyst"], "t1")
    assert result == {}
