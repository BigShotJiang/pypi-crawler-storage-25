"""
Tests for autopil.policy_engine.PolicyEngine

Coverage:
  - Allowed sources are granted
  - Denied sources are blocked (even if in allowed list)
  - Sources not in allowed list are blocked
  - Sensitivity ceiling enforcement
  - No matching policy → default deny
  - Admin wildcard (empty allowed_sources = allow all non-denied)
  - Policy reload
"""

import textwrap

import pytest

from autopil.models import ContextRequest, Decision, SensitivityLevel
from autopil.policy_engine import PolicyEngine


def make_req(agent_role, source_id, sensitivity=SensitivityLevel.LOW) -> ContextRequest:
    return ContextRequest(
        query="test",
        agent_role=agent_role,
        user_id="u1",
        source_id=source_id,
        sensitivity_level=sensitivity,
    )


# ── allowed sources ───────────────────────────────────────────────────────────

class TestAllowedSources:
    def test_allowed_source_is_granted(self, engine):
        decision, policy, _ = engine.evaluate(make_req("analyst", "reports"))
        assert decision == Decision.ALLOW
        assert policy == "analyst_policy"

    def test_second_allowed_source_is_granted(self, engine):
        decision, _, _ = engine.evaluate(make_req("analyst", "market_data"))
        assert decision == Decision.ALLOW

    def test_viewer_allowed_source_is_granted(self, engine):
        decision, _, _ = engine.evaluate(make_req("viewer", "reports"))
        assert decision == Decision.ALLOW


# ── denied sources ────────────────────────────────────────────────────────────

class TestDeniedSources:
    def test_denied_source_is_blocked(self, engine):
        decision, policy, reason = engine.evaluate(make_req("analyst", "executive_comms"))
        assert decision == Decision.DENY
        assert "explicitly denied" in reason

    def test_denied_takes_priority(self, engine):
        """executive_comms appears in denied — should be blocked for all roles."""
        for role in ("analyst", "viewer", "admin"):
            decision, _, _ = engine.evaluate(make_req(role, "executive_comms"))
            assert decision == Decision.DENY, f"Expected DENY for role={role}"

    def test_source_not_in_allowed_list_is_blocked(self, engine):
        """viewer can only access reports — market_data is in their denied list."""
        decision, _, reason = engine.evaluate(make_req("viewer", "market_data"))
        assert decision == Decision.DENY

    def test_source_not_in_allowed_and_not_denied_is_blocked(self, engine):
        """analyst has an allowed list — unknown source not in it should be denied."""
        decision, _, _ = engine.evaluate(make_req("analyst", "mystery_source"))
        assert decision == Decision.DENY


# ── sensitivity ceiling ───────────────────────────────────────────────────────

class TestSensitivityCeiling:
    def test_within_ceiling_is_allowed(self, engine):
        decision, _, _ = engine.evaluate(make_req("analyst", "reports", SensitivityLevel.HIGH))
        assert decision == Decision.ALLOW

    def test_at_ceiling_is_allowed(self, engine):
        decision, _, _ = engine.evaluate(make_req("viewer", "reports", SensitivityLevel.MEDIUM))
        assert decision == Decision.ALLOW

    def test_above_ceiling_is_denied(self, engine):
        """viewer max_sensitivity=medium — restricted should be denied."""
        decision, _, reason = engine.evaluate(make_req("viewer", "reports", SensitivityLevel.RESTRICTED))
        assert decision == Decision.DENY
        assert "ceiling" in reason or "exceeds" in reason

    def test_admin_allows_restricted(self, engine):
        """admin max_sensitivity=restricted — restricted level should be allowed."""
        decision, _, _ = engine.evaluate(make_req("admin", "reports", SensitivityLevel.RESTRICTED))
        assert decision == Decision.ALLOW


# ── default deny ──────────────────────────────────────────────────────────────

class TestDefaultDeny:
    def test_unknown_role_is_denied(self, engine):
        decision, policy, reason = engine.evaluate(make_req("rogue", "reports"))
        assert decision == Decision.DENY
        assert policy == "default_deny"
        assert "rogue" in reason

    def test_empty_role_is_denied(self, engine):
        decision, _, _ = engine.evaluate(make_req("", "reports"))
        assert decision == Decision.DENY


# ── admin wildcard ────────────────────────────────────────────────────────────

class TestAdminWildcard:
    def test_admin_can_access_unlisted_source(self, engine):
        """admin has empty allowed_sources → allow everything not explicitly denied."""
        decision, _, _ = engine.evaluate(make_req("admin", "any_source"))
        assert decision == Decision.ALLOW

    def test_admin_still_blocked_on_denied(self, engine):
        decision, _, _ = engine.evaluate(make_req("admin", "executive_comms"))
        assert decision == Decision.DENY


# ── policy reload ─────────────────────────────────────────────────────────────

class TestPolicyReload:
    def test_reload_picks_up_new_policy(self, tmp_path):
        p = tmp_path / "policies.yaml"
        p.write_text(textwrap.dedent("""
            policies:
              - name: original
                agent_role: tester
                allowed_sources: [source_a]
                denied_sources: []
                max_sensitivity: high
        """))
        engine = PolicyEngine(str(p))
        assert engine.evaluate(make_req("tester", "source_a"))[0] == Decision.ALLOW
        assert engine.evaluate(make_req("tester", "source_b"))[0] == Decision.DENY

        # Update the policy file and reload
        p.write_text(textwrap.dedent("""
            policies:
              - name: updated
                agent_role: tester
                allowed_sources: [source_a, source_b]
                denied_sources: []
                max_sensitivity: high
        """))
        engine2 = PolicyEngine(str(p))
        assert engine2.evaluate(make_req("tester", "source_b"))[0] == Decision.ALLOW


# ── task-level scoping ────────────────────────────────────────────────────────

class TestTaskScoping:
    """Policy engine tests for allowed_tasks / denied_tasks."""

    def _engine(self, extra_policy_fields: str = "") -> "PolicyEngine":
        import textwrap, tempfile, pathlib
        yaml_text = textwrap.dedent(f"""
            policies:
              - name: task_policy
                agent_role: analyst
                allowed_sources: [reports]
                denied_sources: []
                max_sensitivity: high
                {extra_policy_fields}
        """)
        p = pathlib.Path(tempfile.mktemp(suffix=".yaml"))
        p.write_text(yaml_text)
        return PolicyEngine(str(p))

    def _req(self, task_type=None):
        return ContextRequest(
            query="test", agent_role="analyst", user_id="u1",
            source_id="reports", sensitivity_level=SensitivityLevel.LOW,
            task_type=task_type,
        )

    def test_no_task_fields_no_task_type_allows(self):
        engine = self._engine()
        decision, _, _ = engine.evaluate(self._req())
        assert decision == Decision.ALLOW

    def test_no_task_fields_with_task_type_allows(self):
        """task_type is ignored when policy has no task constraints."""
        engine = self._engine()
        decision, _, _ = engine.evaluate(self._req(task_type="initial_underwriting"))
        assert decision == Decision.ALLOW

    def test_allowed_tasks_permits_matching_task(self):
        engine = self._engine("allowed_tasks: [initial_underwriting, renewal]")
        decision, _, _ = engine.evaluate(self._req(task_type="initial_underwriting"))
        assert decision == Decision.ALLOW

    def test_allowed_tasks_blocks_unlisted_task(self):
        engine = self._engine("allowed_tasks: [initial_underwriting]")
        decision, _, reason = engine.evaluate(self._req(task_type="customer_callback"))
        assert decision == Decision.DENY
        assert "customer_callback" in reason

    def test_allowed_tasks_no_task_type_allows(self):
        """allowed_tasks whitelist is only applied when task_type is provided."""
        engine = self._engine("allowed_tasks: [initial_underwriting]")
        decision, _, _ = engine.evaluate(self._req(task_type=None))
        assert decision == Decision.ALLOW

    def test_denied_tasks_blocks_matching_task(self):
        engine = self._engine("denied_tasks: [customer_callback]")
        decision, _, reason = engine.evaluate(self._req(task_type="customer_callback"))
        assert decision == Decision.DENY
        assert "customer_callback" in reason

    def test_denied_tasks_permits_non_matching_task(self):
        engine = self._engine("denied_tasks: [customer_callback]")
        decision, _, _ = engine.evaluate(self._req(task_type="initial_underwriting"))
        assert decision == Decision.ALLOW

    def test_denied_task_overrides_allowed_task(self):
        """denied_tasks takes priority over allowed_tasks."""
        engine = PolicyEngine.from_list([{
            "name": "task_policy",
            "agent_role": "analyst",
            "allowed_sources": ["reports"],
            "denied_sources": [],
            "max_sensitivity": "high",
            "allowed_tasks": ["initial_underwriting"],
            "denied_tasks": ["initial_underwriting"],
        }])
        decision, _, _ = engine.evaluate(self._req(task_type="initial_underwriting"))
        assert decision == Decision.DENY

    def test_denied_task_checked_before_source(self):
        """Task denial fires before source checks."""
        engine = self._engine("denied_tasks: [blocked_task]")
        req = ContextRequest(
            query="test", agent_role="analyst", user_id="u1",
            source_id="reports", sensitivity_level=SensitivityLevel.LOW,
            task_type="blocked_task",
        )
        decision, _, reason = engine.evaluate(req)
        assert decision == Decision.DENY
        assert "blocked_task" in reason


class TestGetSessionTtl:
    """Tests for PolicyEngine.get_session_ttl()."""

    def _engine_with_ttl(self, ttl_minutes):
        """Build an engine whose single policy has a session_ttl_minutes field."""
        policy = {
            "name": "ttl_policy",
            "agent_role": "analyst",
            "allowed_sources": ["reports"],
            "denied_sources": [],
            "max_sensitivity": "high",
            "session_ttl_minutes": ttl_minutes,
        }
        return PolicyEngine.from_list([policy])

    def _engine_without_ttl(self):
        """Build an engine whose single policy has no session_ttl_minutes field."""
        policy = {
            "name": "no_ttl_policy",
            "agent_role": "analyst",
            "allowed_sources": ["reports"],
            "denied_sources": [],
            "max_sensitivity": "medium",
        }
        return PolicyEngine.from_list([policy])

    def test_returns_policy_ttl_when_set(self):
        engine = self._engine_with_ttl(60)
        assert engine.get_session_ttl("analyst") == 60

    def test_policy_ttl_overrides_fallback(self):
        """Policy-level TTL wins over the global fallback."""
        engine = self._engine_with_ttl(60)
        assert engine.get_session_ttl("analyst", fallback=480) == 60

    def test_falls_back_to_global_when_no_policy_ttl(self):
        """Policy exists but has no session_ttl_minutes — use fallback."""
        engine = self._engine_without_ttl()
        assert engine.get_session_ttl("analyst", fallback=480) == 480

    def test_returns_none_when_no_policy_ttl_and_no_fallback(self):
        """No policy TTL, no fallback — returns None (no expiry)."""
        engine = self._engine_without_ttl()
        assert engine.get_session_ttl("analyst") is None

    def test_returns_fallback_for_unknown_role(self):
        """No policy matches the role — return fallback."""
        engine = self._engine_without_ttl()
        assert engine.get_session_ttl("unknown_role", fallback=240) == 240

    def test_returns_none_for_unknown_role_no_fallback(self):
        engine = self._engine_without_ttl()
        assert engine.get_session_ttl("unknown_role") is None

    def test_ttl_loaded_from_yaml_file(self, tmp_path):
        """Round-trip: session_ttl_minutes survives YAML load."""
        import textwrap
        yaml_file = tmp_path / "policy.yaml"
        yaml_file.write_text(textwrap.dedent("""
            policies:
              - name: yaml_ttl_policy
                agent_role: compliance_officer
                allowed_sources: [audit_logs]
                denied_sources: []
                max_sensitivity: restricted
                session_ttl_minutes: 60
        """))
        engine = PolicyEngine(str(yaml_file))
        assert engine.get_session_ttl("compliance_officer") == 60
        assert engine.get_session_ttl("compliance_officer", fallback=480) == 60


class TestSensitivityDecay:
    """Tests for sensitivity_decay enforcement in PolicyEngine.evaluate()."""

    def _engine(self, max_sensitivity="restricted", decay=None):
        policy = {
            "name": "decay_policy",
            "agent_role": "investigator",
            "allowed_sources": ["case_data"],
            "denied_sources": [],
            "max_sensitivity": max_sensitivity,
        }
        if decay is not None:
            policy["sensitivity_decay"] = decay
        return PolicyEngine.from_list([policy])

    def _req(self, sensitivity, age_minutes=None):
        return ContextRequest(
            query="test",
            agent_role="investigator",
            user_id="u1",
            source_id="case_data",
            sensitivity_level=SensitivityLevel(sensitivity),
            session_age_minutes=age_minutes,
        )

    def test_no_decay_schedule_allows_within_ceiling(self):
        engine = self._engine(max_sensitivity="restricted", decay=None)
        decision, _, _ = engine.evaluate(self._req("restricted", age_minutes=120))
        assert decision == Decision.ALLOW

    def test_no_session_age_skips_decay(self):
        """When session_age_minutes is None, decay schedule is ignored."""
        engine = self._engine(decay=[{"after_minutes": 1, "max_sensitivity": "low"}])
        decision, _, _ = engine.evaluate(self._req("restricted", age_minutes=None))
        assert decision == Decision.ALLOW

    def test_decay_not_triggered_before_threshold(self):
        """At 29 minutes, the 30-minute decay rule has not yet fired."""
        engine = self._engine(decay=[{"after_minutes": 30, "max_sensitivity": "high"}])
        decision, _, _ = engine.evaluate(self._req("restricted", age_minutes=29))
        assert decision == Decision.ALLOW

    def test_decay_triggers_at_exact_threshold(self):
        """At exactly 30 minutes, the decay rule fires and restricted is denied."""
        engine = self._engine(decay=[{"after_minutes": 30, "max_sensitivity": "high"}])
        decision, _, reason = engine.evaluate(self._req("restricted", age_minutes=30))
        assert decision == Decision.DENY
        assert "30m" in reason
        assert "high" in reason

    def test_decay_triggers_after_threshold(self):
        engine = self._engine(decay=[{"after_minutes": 30, "max_sensitivity": "high"}])
        decision, _, _ = engine.evaluate(self._req("restricted", age_minutes=90))
        assert decision == Decision.DENY

    def test_allows_below_decayed_ceiling(self):
        """Session is 60m old, decayed ceiling is high — medium access is still allowed."""
        engine = self._engine(decay=[{"after_minutes": 30, "max_sensitivity": "high"}])
        decision, _, _ = engine.evaluate(self._req("high", age_minutes=60))
        assert decision == Decision.ALLOW

    def test_second_decay_threshold_applies(self):
        """At 50 minutes, the second rule (after_minutes:45 → medium) should apply."""
        engine = self._engine(decay=[
            {"after_minutes": 30, "max_sensitivity": "high"},
            {"after_minutes": 45, "max_sensitivity": "medium"},
        ])
        decision, _, reason = engine.evaluate(self._req("high", age_minutes=50))
        assert decision == Decision.DENY
        assert "45m" in reason
        assert "medium" in reason

    def test_static_ceiling_wins_when_already_tighter(self):
        """Decay says high but static ceiling is already medium — no change."""
        engine = self._engine(max_sensitivity="medium",
                              decay=[{"after_minutes": 10, "max_sensitivity": "high"}])
        # high decay ceiling is looser than medium static — medium should still win
        decision, _, _ = engine.evaluate(self._req("high", age_minutes=60))
        assert decision == Decision.DENY  # denied by static medium ceiling, not decay

    def test_decay_reason_includes_age_and_rule(self):
        engine = self._engine(decay=[{"after_minutes": 30, "max_sensitivity": "high"}])
        _, _, reason = engine.evaluate(self._req("restricted", age_minutes=45))
        assert "45m old" in reason
        assert "after 30m" in reason
        assert "high" in reason

    def test_decay_loaded_from_yaml(self, tmp_path):
        """Round-trip: sensitivity_decay survives YAML load."""
        import textwrap
        yaml_file = tmp_path / "policy.yaml"
        yaml_file.write_text(textwrap.dedent("""
            policies:
              - name: yaml_decay_policy
                agent_role: fraud_investigator
                allowed_sources: [transactions]
                denied_sources: []
                max_sensitivity: restricted
                session_ttl_minutes: 60
                sensitivity_decay:
                  - after_minutes: 30
                    max_sensitivity: high
                  - after_minutes: 45
                    max_sensitivity: medium
        """))
        engine = PolicyEngine(str(yaml_file))
        req_restricted = ContextRequest(
            query="test", agent_role="fraud_investigator", user_id="u1",
            source_id="transactions", sensitivity_level=SensitivityLevel.RESTRICTED,
            session_age_minutes=20,
        )
        req_restricted_old = ContextRequest(
            query="test", agent_role="fraud_investigator", user_id="u1",
            source_id="transactions", sensitivity_level=SensitivityLevel.RESTRICTED,
            session_age_minutes=35,
        )
        assert engine.evaluate(req_restricted)[0] == Decision.ALLOW   # 20m, no decay yet
        assert engine.evaluate(req_restricted_old)[0] == Decision.DENY  # 35m, capped at high
