"""
Tests for autopil/mcp_server.py — dispatch_tool() logic.

dispatch_tool() is an async function but is fully decoupled from MCP transport,
so we exercise it via asyncio.run() without needing a live MCP server.
"""

import asyncio
import json
import uuid

import pytest

mcp = pytest.importorskip("mcp", reason="mcp package not installed — skipping MCP tests")

from autopil.db import create_stores
from autopil.mcp_server import dispatch_tool, ALL_TOOLS
from autopil.models import AuditEvent, Decision
from autopil.policy_engine import PolicyEngine
from datetime import datetime


# ── helpers ───────────────────────────────────────────────────────────────────

def _run(coro):
    """Run an async coroutine synchronously."""
    return asyncio.run(coro)


def _text_of(result) -> str:
    """Extract the text from a list[TextContent] response."""
    return result[0].text


def _dispatch(name, arguments, *, audit_log, lineage_store, engine, policy_path, tenant_id):
    """Convenience wrapper around dispatch_tool."""
    state = {"engine": engine}
    return _run(dispatch_tool(
        name=name,
        arguments=arguments,
        audit_log=audit_log,
        lineage_store=lineage_store,
        state=state,
        policy_path=policy_path,
        tenant_id=tenant_id,
    ))


def _seed_event(audit_log, tenant_id, *, agent_role="analyst", source_id="reports",
                decision=Decision.ALLOW, session_id=None) -> AuditEvent:
    e = AuditEvent(
        event_id=str(uuid.uuid4()),
        session_id=session_id or str(uuid.uuid4()),
        agent_role=agent_role,
        user_id="u1",
        source_id=source_id,
        query="test",
        decision=decision,
        policy_name="p",
        reason="r",
        timestamp=datetime.utcnow(),
    )
    audit_log.record(e, tenant_id=tenant_id)
    return e


# ── fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def mcp_env(tmp_path):
    """Return (audit_log, lineage_store, engine, policy_path, tenant_id) backed by a fresh DB."""
    import textwrap
    policy_yaml = textwrap.dedent("""
        policies:
          - name: analyst_policy
            agent_role: analyst
            allowed_sources:
              - reports
              - market_data
            denied_sources:
              - executive_comms
            max_sensitivity: high
    """)
    policy_file = tmp_path / "policies.yaml"
    policy_file.write_text(policy_yaml)
    db_path = str(tmp_path / "mcp_test.db")

    stores = create_stores(db_path=db_path)
    audit_log, _, tenant_store, _, _, lineage_store, _, _ = stores
    tenant_id = tenant_store.create_tenant("mcp_test")
    engine = PolicyEngine(str(policy_file))

    return audit_log, lineage_store, engine, str(policy_file), tenant_id


# ── evaluate_context ──────────────────────────────────────────────────────────

def test_evaluate_context_allow(mcp_env):
    audit_log, lineage_store, engine, policy_path, tenant_id = mcp_env
    result = _dispatch("evaluate_context", {
        "agent_role": "analyst",
        "user_id": "u1",
        "source_id": "reports",
        "sensitivity_level": "medium",
        "session_id": str(uuid.uuid4()),
        "query": "get report",
    }, audit_log=audit_log, lineage_store=lineage_store, engine=engine,
       policy_path=policy_path, tenant_id=tenant_id)

    text = _text_of(result)
    assert "ALLOW" in text
    assert "analyst" in text
    data = json.loads(text.split("\n\n", 1)[1])
    assert data["decision"] == "ALLOW"
    assert "event_id" in data


def test_evaluate_context_deny(mcp_env):
    audit_log, lineage_store, engine, policy_path, tenant_id = mcp_env
    result = _dispatch("evaluate_context", {
        "agent_role": "analyst",
        "user_id": "u1",
        "source_id": "executive_comms",
        "sensitivity_level": "high",
        "session_id": str(uuid.uuid4()),
    }, audit_log=audit_log, lineage_store=lineage_store, engine=engine,
       policy_path=policy_path, tenant_id=tenant_id)

    text = _text_of(result)
    assert "DENY" in text
    data = json.loads(text.split("\n\n", 1)[1])
    assert data["decision"] == "DENY"


def test_evaluate_context_invalid_sensitivity(mcp_env):
    audit_log, lineage_store, engine, policy_path, tenant_id = mcp_env
    result = _dispatch("evaluate_context", {
        "agent_role": "analyst",
        "user_id": "u1",
        "source_id": "reports",
        "sensitivity_level": "ultra_secret",
        "session_id": str(uuid.uuid4()),
    }, audit_log=audit_log, lineage_store=lineage_store, engine=engine,
       policy_path=policy_path, tenant_id=tenant_id)

    text = _text_of(result)
    assert "Error" in text
    assert "sensitivity_level" in text


def test_evaluate_context_records_to_audit_log(mcp_env):
    audit_log, lineage_store, engine, policy_path, tenant_id = mcp_env
    session_id = str(uuid.uuid4())
    _dispatch("evaluate_context", {
        "agent_role": "analyst",
        "user_id": "u1",
        "source_id": "reports",
        "sensitivity_level": "low",
        "session_id": session_id,
    }, audit_log=audit_log, lineage_store=lineage_store, engine=engine,
       policy_path=policy_path, tenant_id=tenant_id)

    events = audit_log.get_session_events(session_id, tenant_id)
    assert len(events) == 1
    assert events[0].source_type == "mcp"


def test_evaluate_context_cross_agent_isolation(mcp_env):
    audit_log, lineage_store, engine, policy_path, tenant_id = mcp_env
    session_id = str(uuid.uuid4())
    # Seed a prior event from 'analyst' to establish session ownership
    _seed_event(audit_log, tenant_id, agent_role="analyst", session_id=session_id)

    # 'viewer' tries to use the same session — should be denied
    result = _dispatch("evaluate_context", {
        "agent_role": "viewer",
        "user_id": "u1",
        "source_id": "reports",
        "sensitivity_level": "low",
        "session_id": session_id,
    }, audit_log=audit_log, lineage_store=lineage_store, engine=engine,
       policy_path=policy_path, tenant_id=tenant_id)

    text = _text_of(result)
    assert "DENY" in text
    assert "isolation" in text.lower() or "owned by" in text


# ── query_audit_log ───────────────────────────────────────────────────────────

def test_query_audit_log_empty(mcp_env):
    audit_log, lineage_store, engine, policy_path, tenant_id = mcp_env
    result = _dispatch("query_audit_log", {}, audit_log=audit_log,
                       lineage_store=lineage_store, engine=engine,
                       policy_path=policy_path, tenant_id=tenant_id)
    text = _text_of(result)
    assert "0 audit event" in text


def test_query_audit_log_returns_events(mcp_env):
    audit_log, lineage_store, engine, policy_path, tenant_id = mcp_env
    _seed_event(audit_log, tenant_id, agent_role="analyst")
    _seed_event(audit_log, tenant_id, agent_role="analyst")

    result = _dispatch("query_audit_log", {"limit": 10}, audit_log=audit_log,
                       lineage_store=lineage_store, engine=engine,
                       policy_path=policy_path, tenant_id=tenant_id)
    text = _text_of(result)
    rows = json.loads(text.split("\n\n", 1)[1])
    assert len(rows) == 2


def test_query_audit_log_filter_by_role(mcp_env):
    audit_log, lineage_store, engine, policy_path, tenant_id = mcp_env
    _seed_event(audit_log, tenant_id, agent_role="analyst")
    _seed_event(audit_log, tenant_id, agent_role="viewer")

    result = _dispatch("query_audit_log", {"agent_role": "analyst"}, audit_log=audit_log,
                       lineage_store=lineage_store, engine=engine,
                       policy_path=policy_path, tenant_id=tenant_id)
    text = _text_of(result)
    rows = json.loads(text.split("\n\n", 1)[1])
    assert all(r["agent_role"] == "analyst" for r in rows)


def test_query_audit_log_filter_by_session(mcp_env):
    audit_log, lineage_store, engine, policy_path, tenant_id = mcp_env
    sid = str(uuid.uuid4())
    _seed_event(audit_log, tenant_id, session_id=sid)
    _seed_event(audit_log, tenant_id)  # different session

    result = _dispatch("query_audit_log", {"session_id": sid}, audit_log=audit_log,
                       lineage_store=lineage_store, engine=engine,
                       policy_path=policy_path, tenant_id=tenant_id)
    rows = json.loads(_text_of(result).split("\n\n", 1)[1])
    assert all(r["session_id"] == sid for r in rows)


# ── get_audit_stats ───────────────────────────────────────────────────────────

def test_get_audit_stats_empty(mcp_env):
    audit_log, lineage_store, engine, policy_path, tenant_id = mcp_env
    result = _dispatch("get_audit_stats", {}, audit_log=audit_log,
                       lineage_store=lineage_store, engine=engine,
                       policy_path=policy_path, tenant_id=tenant_id)
    stats = json.loads(_text_of(result).split("\n\n", 1)[1])
    assert stats["total_events"] == 0
    assert stats["deny_rate_pct"] == 0.0


def test_get_audit_stats_with_events(mcp_env):
    audit_log, lineage_store, engine, policy_path, tenant_id = mcp_env
    _seed_event(audit_log, tenant_id, decision=Decision.ALLOW)
    _seed_event(audit_log, tenant_id, decision=Decision.DENY)
    _seed_event(audit_log, tenant_id, decision=Decision.DENY)

    result = _dispatch("get_audit_stats", {}, audit_log=audit_log,
                       lineage_store=lineage_store, engine=engine,
                       policy_path=policy_path, tenant_id=tenant_id)
    stats = json.loads(_text_of(result).split("\n\n", 1)[1])
    assert stats["total_events"] == 3
    assert stats["allowed"] == 1
    assert stats["denied"] == 2
    assert stats["deny_rate_pct"] == pytest.approx(66.7, abs=0.1)


# ── list_policies ─────────────────────────────────────────────────────────────

def test_list_policies_returns_all(mcp_env):
    audit_log, lineage_store, engine, policy_path, tenant_id = mcp_env
    result = _dispatch("list_policies", {}, audit_log=audit_log,
                       lineage_store=lineage_store, engine=engine,
                       policy_path=policy_path, tenant_id=tenant_id)
    rows = json.loads(_text_of(result).split("\n\n", 1)[1])
    assert len(rows) == 1
    assert rows[0]["agent_role"] == "analyst"


def test_list_policies_filter_by_role(mcp_env):
    audit_log, lineage_store, engine, policy_path, tenant_id = mcp_env
    result = _dispatch("list_policies", {"agent_role": "analyst"}, audit_log=audit_log,
                       lineage_store=lineage_store, engine=engine,
                       policy_path=policy_path, tenant_id=tenant_id)
    rows = json.loads(_text_of(result).split("\n\n", 1)[1])
    assert all(r["agent_role"] == "analyst" for r in rows)


def test_list_policies_filter_no_match(mcp_env):
    audit_log, lineage_store, engine, policy_path, tenant_id = mcp_env
    result = _dispatch("list_policies", {"agent_role": "nonexistent"}, audit_log=audit_log,
                       lineage_store=lineage_store, engine=engine,
                       policy_path=policy_path, tenant_id=tenant_id)
    rows = json.loads(_text_of(result).split("\n\n", 1)[1])
    assert rows == []


# ── record_action ─────────────────────────────────────────────────────────────

def test_record_action_success(mcp_env):
    audit_log, lineage_store, engine, policy_path, tenant_id = mcp_env
    event = _seed_event(audit_log, tenant_id)

    result = _dispatch("record_action", {
        "event_id": event.event_id,
        "action_type": "read",
        "detail": {"rows_read": 10},
        "outcome": "success",
    }, audit_log=audit_log, lineage_store=lineage_store, engine=engine,
       policy_path=policy_path, tenant_id=tenant_id)

    text = _text_of(result)
    assert "Action recorded" in text
    data = json.loads(text.split("\n\n", 1)[1])
    assert data["event_id"] == event.event_id
    assert data["action_type"] == "read"
    assert "action_id" in data


def test_record_action_missing_event(mcp_env):
    audit_log, lineage_store, engine, policy_path, tenant_id = mcp_env
    result = _dispatch("record_action", {
        "event_id": str(uuid.uuid4()),
        "action_type": "read",
        "detail": {},
    }, audit_log=audit_log, lineage_store=lineage_store, engine=engine,
       policy_path=policy_path, tenant_id=tenant_id)

    text = _text_of(result)
    assert "Error" in text
    assert "event_id" in text


# ── reload_policies ───────────────────────────────────────────────────────────

def test_reload_policies(mcp_env):
    audit_log, lineage_store, engine, policy_path, tenant_id = mcp_env
    state = {"engine": engine}
    result = _run(dispatch_tool(
        name="reload_policies",
        arguments={},
        audit_log=audit_log,
        lineage_store=lineage_store,
        state=state,
        policy_path=policy_path,
        tenant_id=tenant_id,
    ))
    text = _text_of(result)
    assert "reloaded" in text
    assert "1 policy" in text or "policies" in text


# ── get_session_status ────────────────────────────────────────────────────────

def test_get_session_status_success(mcp_env):
    audit_log, lineage_store, engine, policy_path, tenant_id = mcp_env
    sid = str(uuid.uuid4())
    _seed_event(audit_log, tenant_id, agent_role="analyst", session_id=sid, decision=Decision.ALLOW)
    _seed_event(audit_log, tenant_id, agent_role="analyst", session_id=sid, decision=Decision.DENY)

    result = _dispatch("get_session_status", {"session_id": sid}, audit_log=audit_log,
                       lineage_store=lineage_store, engine=engine,
                       policy_path=policy_path, tenant_id=tenant_id)
    text = _text_of(result)
    status = json.loads(text.split("\n\n", 1)[1])
    assert status["session_id"] == sid
    assert status["owner_role"] == "analyst"
    assert status["total_events"] == 2
    assert status["allowed"] == 1
    assert status["denied"] == 1


def test_get_session_status_no_events(mcp_env):
    audit_log, lineage_store, engine, policy_path, tenant_id = mcp_env
    result = _dispatch("get_session_status", {"session_id": str(uuid.uuid4())},
                       audit_log=audit_log, lineage_store=lineage_store, engine=engine,
                       policy_path=policy_path, tenant_id=tenant_id)
    text = _text_of(result)
    assert "Error" in text


# ── unknown tool ──────────────────────────────────────────────────────────────

def test_unknown_tool_returns_error(mcp_env):
    audit_log, lineage_store, engine, policy_path, tenant_id = mcp_env
    result = _dispatch("not_a_real_tool", {}, audit_log=audit_log,
                       lineage_store=lineage_store, engine=engine,
                       policy_path=policy_path, tenant_id=tenant_id)
    text = _text_of(result)
    assert "Error" in text
    assert "not_a_real_tool" in text


# ── ALL_TOOLS constant ────────────────────────────────────────────────────────

def test_all_tools_list_completeness():
    assert len(ALL_TOOLS) == 7
    expected = {
        "evaluate_context", "query_audit_log", "get_audit_stats",
        "list_policies", "record_action", "reload_policies", "get_session_status",
    }
    assert set(ALL_TOOLS) == expected
