"""
Tests for OpenAIAgentsGuard — AutoPIL's integration layer for OpenAI Agents SDK.
"""

import sys
import uuid
import textwrap
from unittest.mock import MagicMock, patch

import pytest

from autopil.openai_agents_guard import OpenAIAgentsGuard
from autopil.models import Decision, SensitivityLevel

POLICY_YAML = textwrap.dedent("""\
policies:
  - name: support_agent_policy
    agent_role: support_agent
    allowed_sources:
      - billing_records
      - support_tickets
    denied_sources:
      - other_customer_accounts
      - pricing_models
    max_sensitivity: high
""")


@pytest.fixture
def guard(tmp_path):
    (tmp_path / "policy.yaml").write_text(POLICY_YAML)
    return OpenAIAgentsGuard(
        policy_path=str(tmp_path / "policy.yaml"),
        audit_db=str(tmp_path / "test.db"),
    )


@pytest.fixture
def sid():
    return str(uuid.uuid4())


class TestSourceTypeTagging:
    def test_allowed_event_tagged_openai_agents(self, guard, sid):
        @guard.protect(agent_role="support_agent", user_id="u1",
                       source_id="billing_records", session_id=sid)
        def fetch(_): return {}
        fetch("q")
        assert guard.get_audit_trail(sid)[0].source_type == "openai_agents"

    def test_denied_event_tagged_openai_agents(self, guard, sid):
        @guard.protect(agent_role="support_agent", user_id="u1",
                       source_id="other_customer_accounts", session_id=sid)
        def fetch(_): return {}
        with pytest.raises(PermissionError):
            fetch("q")
        events = guard.get_audit_trail(sid)
        assert events[0].source_type == "openai_agents"
        assert events[0].decision == Decision.DENY

    def test_not_tagged_sdk_or_mcp(self, guard, sid):
        @guard.protect(agent_role="support_agent", user_id="u1",
                       source_id="billing_records", session_id=sid)
        def fetch(_): return {}
        fetch("q")
        assert guard.get_audit_trail(sid)[0].source_type not in ("sdk", "mcp", "rest", "gemini")


class TestPolicyEnforcement:
    def test_allowed_returns_data(self, guard, sid):
        @guard.protect(agent_role="support_agent", user_id="u1",
                       source_id="support_tickets", session_id=sid)
        def fetch(_): return [{"id": "TKT-1"}]
        assert fetch("q") == [{"id": "TKT-1"}]

    def test_denied_raises(self, guard, sid):
        @guard.protect(agent_role="support_agent", user_id="u1",
                       source_id="pricing_models", session_id=sid)
        def fetch(_): return {}
        with pytest.raises(PermissionError, match="DENIED"):
            fetch("q")

    def test_sensitivity_ceiling(self, guard, sid):
        @guard.protect(agent_role="support_agent", user_id="u1",
                       source_id="billing_records",
                       sensitivity_level=SensitivityLevel.RESTRICTED,
                       session_id=sid)
        def fetch(_): return {}
        with pytest.raises(PermissionError):
            fetch("q")
        assert guard.get_audit_trail(sid)[0].decision == Decision.DENY


class TestFunctionToolRequiresPackage:
    def test_function_tool_raises_import_error_when_not_installed(self, guard, sid):
        """function_tool() raises ImportError immediately if openai-agents is not installed."""
        import sys
        agents_mod = sys.modules.pop("agents", None)
        try:
            with pytest.raises(ImportError, match="openai-agents"):
                guard.function_tool(
                    agent_role="support_agent",
                    user_id="u1",
                    source_id="billing_records",
                    session_id=sid,
                )
        finally:
            if agents_mod is not None:
                sys.modules["agents"] = agents_mod


class TestAuditTrail:
    def test_multiple_calls_all_tagged_openai_agents(self, guard, sid):
        @guard.protect(agent_role="support_agent", user_id="u1",
                       source_id="billing_records", session_id=sid)
        def allowed(_): return {}

        @guard.protect(agent_role="support_agent", user_id="u1",
                       source_id="other_customer_accounts", session_id=sid)
        def denied(_): return {}

        allowed("q")
        with pytest.raises(PermissionError):
            denied("q")

        events = guard.get_audit_trail(sid)
        assert len(events) == 2
        assert all(e.source_type == "openai_agents" for e in events)
        assert {e.decision for e in events} == {Decision.ALLOW, Decision.DENY}

    def test_last_event_id_populated(self, guard, sid):
        @guard.protect(agent_role="support_agent", user_id="u1",
                       source_id="billing_records", session_id=sid)
        def fetch(_): return {}
        assert guard.last_event_id is None
        fetch("q")
        assert guard.last_event_id is not None


class TestFunctionToolDecorator:
    """Tests for OpenAIAgentsGuard.function_tool() — lines 134-152."""

    def _mock_agents(self):
        """Return a mock agents module whose function_tool is identity."""
        mock_agents = MagicMock()
        mock_agents.function_tool = MagicMock(side_effect=lambda fn: fn)
        return mock_agents

    def test_function_tool_wraps_and_calls_openai_decorator(self, guard, sid):
        mock_agents = self._mock_agents()
        with patch.dict(sys.modules, {"agents": mock_agents}):
            @guard.function_tool(
                agent_role="support_agent",
                user_id="u1",
                source_id="billing_records",
                session_id=sid,
            )
            def get_billing(account_id: str) -> dict:
                return {"balance": 100}

        mock_agents.function_tool.assert_called_once()

    def test_function_tool_allow_executes_fn(self, guard, sid):
        mock_agents = self._mock_agents()
        with patch.dict(sys.modules, {"agents": mock_agents}):
            @guard.function_tool(
                agent_role="support_agent",
                user_id="u1",
                source_id="billing_records",
                session_id=sid,
            )
            def get_billing(account_id: str) -> dict:
                return {"account": account_id}

        result = get_billing("ACC-123")
        assert result == {"account": "ACC-123"}

    def test_function_tool_deny_raises_permission_error(self, guard, sid):
        mock_agents = self._mock_agents()
        with patch.dict(sys.modules, {"agents": mock_agents}):
            @guard.function_tool(
                agent_role="support_agent",
                user_id="u1",
                source_id="other_customer_accounts",
                session_id=sid,
            )
            def get_other_accounts() -> list:
                return []

        with pytest.raises(PermissionError):
            get_other_accounts()

    def test_function_tool_auto_session_id(self, guard):
        """session_id=None → auto-generated session; should not crash."""
        mock_agents = self._mock_agents()
        with patch.dict(sys.modules, {"agents": mock_agents}):
            @guard.function_tool(
                agent_role="support_agent",
                user_id="u1",
                source_id="billing_records",
                session_id=None,
            )
            def fetch_data() -> str:
                return "data"

        result = fetch_data()
        assert result == "data"

    def test_function_tool_sensitivity_ceiling_deny(self, guard, sid):
        mock_agents = self._mock_agents()
        with patch.dict(sys.modules, {"agents": mock_agents}):
            @guard.function_tool(
                agent_role="support_agent",
                user_id="u1",
                source_id="billing_records",
                sensitivity_level=SensitivityLevel.RESTRICTED,
                session_id=sid,
            )
            def get_restricted() -> str:
                return "secret"

        with pytest.raises(PermissionError):
            get_restricted()
