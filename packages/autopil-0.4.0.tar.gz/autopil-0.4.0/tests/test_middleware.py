"""
Tests for AutoPILMiddleware — ASGI middleware for API-layer governance.

Covers:
  - Unmatched routes pass through unchanged
  - Static source_id rules (ALLOW and DENY)
  - Dynamic source_id extracted from URL path parameters
  - Query extracted from query string parameter
  - Query extracted from JSON body (query_body_field)
  - Response headers injected on ALLOW (X-AutoPIL-*)
  - 403 JSON body structure on DENY
  - source_type="api" stamped on all middleware events
  - Method filtering (rule.methods)
  - Wildcard path patterns (* and **)
  - Shadow mode (on_deny="log") — records DENY but passes request through
  - Session auto-generation when header absent
  - user_id falls back to "anonymous"
  - Audit trail recorded correctly
"""

import json
import textwrap
import uuid

import pytest
from fastapi import FastAPI
from fastapi.responses import JSONResponse
from starlette.testclient import TestClient

from autopil.guard import ContextGuard
from autopil.middleware import AutoPILMiddleware, RouteRule, _compile_pattern, _resolve_source_id
from autopil.models import Decision, SensitivityLevel


# ── policy ────────────────────────────────────────────────────────────────────

POLICY_YAML = textwrap.dedent("""\
policies:
  - name: analyst_policy
    agent_role: analyst
    allowed_sources:
      - reports
      - market_data
      - search_index
    denied_sources:
      - pii_records
      - executive_comms
    max_sensitivity: high
""")


@pytest.fixture
def policy_file(tmp_path):
    p = tmp_path / "policy.yaml"
    p.write_text(POLICY_YAML)
    return str(p)


@pytest.fixture
def guard(policy_file, tmp_path):
    return ContextGuard(
        policy_path=policy_file,
        audit_db=str(tmp_path / "test.db"),
    )


def make_app(guard, rules, on_deny="block"):
    """Build a minimal FastAPI app with AutoPILMiddleware and simple test routes."""
    app = FastAPI()
    app.add_middleware(AutoPILMiddleware, guard=guard, rules=rules, on_deny=on_deny)

    @app.get("/api/retrieve")
    async def retrieve(q: str = ""):
        return {"source": "reports", "q": q}

    @app.get("/api/retrieve/{source}")
    async def retrieve_by_source(source: str, q: str = ""):
        return {"source": source, "q": q}

    @app.post("/api/search")
    async def search(body: dict):
        return {"query": body.get("query"), "hits": 10}

    @app.get("/api/admin")
    async def admin():
        return {"secret": "admin data"}

    @app.get("/api/public")
    async def public():
        return {"ok": True}

    return app


def client_for(app) -> TestClient:
    return TestClient(app, raise_server_exceptions=False)


DEFAULT_HEADERS = {"X-User-ID": "analyst_01", "X-Session-ID": str(uuid.uuid4())}


# ── pass-through (no matching rule) ──────────────────────────────────────────

class TestPassThrough:
    def test_unmatched_path_passes_through(self, guard):
        app = make_app(guard, rules=[
            RouteRule("/api/retrieve", "analyst", "reports"),
        ])
        with client_for(app) as c:
            r = c.get("/api/public", headers=DEFAULT_HEADERS)
        assert r.status_code == 200
        assert "x-autopil-decision" not in r.headers

    def test_unmatched_method_passes_through(self, guard):
        app = make_app(guard, rules=[
            RouteRule("/api/retrieve", "analyst", "reports", methods=frozenset({"GET"})),
        ])
        with client_for(app) as c:
            r = c.post("/api/retrieve", headers=DEFAULT_HEADERS)
        assert r.status_code in (200, 405, 422)
        assert "x-autopil-decision" not in r.headers


# ── ALLOW behaviour ───────────────────────────────────────────────────────────

class TestAllow:
    def test_allow_returns_200(self, guard):
        app = make_app(guard, rules=[
            RouteRule("/api/retrieve", "analyst", "reports"),
        ])
        with client_for(app) as c:
            r = c.get("/api/retrieve?q=revenue", headers=DEFAULT_HEADERS)
        assert r.status_code == 200

    def test_allow_injects_decision_header(self, guard):
        app = make_app(guard, rules=[
            RouteRule("/api/retrieve", "analyst", "reports"),
        ])
        with client_for(app) as c:
            r = c.get("/api/retrieve", headers=DEFAULT_HEADERS)
        assert r.headers["x-autopil-decision"] == "ALLOW"

    def test_allow_injects_event_id_header(self, guard):
        app = make_app(guard, rules=[
            RouteRule("/api/retrieve", "analyst", "reports"),
        ])
        with client_for(app) as c:
            r = c.get("/api/retrieve", headers=DEFAULT_HEADERS)
        event_id = r.headers.get("x-autopil-event-id")
        assert event_id is not None
        assert len(event_id) == 36  # UUID format

    def test_allow_injects_policy_header(self, guard):
        app = make_app(guard, rules=[
            RouteRule("/api/retrieve", "analyst", "reports"),
        ])
        with client_for(app) as c:
            r = c.get("/api/retrieve", headers=DEFAULT_HEADERS)
        assert r.headers.get("x-autopil-policy") == "analyst_policy"

    def test_allow_handler_still_executes(self, guard):
        app = make_app(guard, rules=[
            RouteRule("/api/retrieve", "analyst", "reports"),
        ])
        with client_for(app) as c:
            r = c.get("/api/retrieve?q=test", headers=DEFAULT_HEADERS)
        assert r.json()["q"] == "test"

    def test_allow_audit_event_decision(self, guard):
        sid = str(uuid.uuid4())
        app = make_app(guard, rules=[
            RouteRule("/api/retrieve", "analyst", "reports",
                      session_id_header="X-Session-ID"),
        ])
        with client_for(app) as c:
            c.get("/api/retrieve", headers={"X-User-ID": "u1", "X-Session-ID": sid})
        events = guard.get_audit_trail(sid)
        assert len(events) == 1
        assert events[0].decision == Decision.ALLOW


# ── DENY behaviour ────────────────────────────────────────────────────────────

class TestDeny:
    def test_deny_returns_403(self, guard):
        app = make_app(guard, rules=[
            RouteRule("/api/admin", "analyst", "pii_records"),
        ])
        with client_for(app) as c:
            r = c.get("/api/admin", headers=DEFAULT_HEADERS)
        assert r.status_code == 403

    def test_deny_body_has_error_field(self, guard):
        app = make_app(guard, rules=[
            RouteRule("/api/admin", "analyst", "pii_records"),
        ])
        with client_for(app) as c:
            r = c.get("/api/admin", headers=DEFAULT_HEADERS)
        body = r.json()
        assert body["error"] == "access_denied"
        assert body["decision"] == "DENY"

    def test_deny_body_has_event_id(self, guard):
        app = make_app(guard, rules=[
            RouteRule("/api/admin", "analyst", "pii_records"),
        ])
        with client_for(app) as c:
            r = c.get("/api/admin", headers=DEFAULT_HEADERS)
        assert "event_id" in r.json()
        assert len(r.json()["event_id"]) == 36

    def test_deny_body_has_reason(self, guard):
        app = make_app(guard, rules=[
            RouteRule("/api/admin", "analyst", "pii_records"),
        ])
        with client_for(app) as c:
            r = c.get("/api/admin", headers=DEFAULT_HEADERS)
        assert r.json()["reason"] != ""

    def test_deny_handler_not_executed(self, guard):
        executed = []
        app = FastAPI()
        app.add_middleware(AutoPILMiddleware, guard=guard, rules=[
            RouteRule("/api/admin", "analyst", "pii_records"),
        ])

        @app.get("/api/admin")
        async def admin():
            executed.append(True)
            return {"secret": "data"}

        with client_for(app) as c:
            c.get("/api/admin", headers=DEFAULT_HEADERS)
        assert executed == [], "handler must not execute on DENY"

    def test_deny_decision_header_present(self, guard):
        app = make_app(guard, rules=[
            RouteRule("/api/admin", "analyst", "pii_records"),
        ])
        with client_for(app) as c:
            r = c.get("/api/admin", headers=DEFAULT_HEADERS)
        assert r.headers.get("x-autopil-decision") == "DENY"

    def test_deny_audit_event_recorded(self, guard):
        sid = str(uuid.uuid4())
        app = make_app(guard, rules=[
            RouteRule("/api/admin", "analyst", "pii_records"),
        ])
        with client_for(app) as c:
            c.get("/api/admin", headers={"X-User-ID": "u1", "X-Session-ID": sid})
        events = guard.get_audit_trail(sid)
        assert len(events) == 1
        assert events[0].decision == Decision.DENY


# ── source_type tagging ───────────────────────────────────────────────────────

class TestSourceType:
    def test_allow_event_tagged_api(self, guard):
        sid = str(uuid.uuid4())
        app = make_app(guard, rules=[RouteRule("/api/retrieve", "analyst", "reports")])
        with client_for(app) as c:
            c.get("/api/retrieve", headers={"X-User-ID": "u1", "X-Session-ID": sid})
        assert guard.get_audit_trail(sid)[0].source_type == "api"

    def test_deny_event_tagged_api(self, guard):
        sid = str(uuid.uuid4())
        app = make_app(guard, rules=[RouteRule("/api/admin", "analyst", "pii_records")])
        with client_for(app) as c:
            c.get("/api/admin", headers={"X-User-ID": "u1", "X-Session-ID": sid})
        assert guard.get_audit_trail(sid)[0].source_type == "api"

    def test_source_type_is_api_not_sdk(self, guard):
        """Even when using a base ContextGuard (source_type='sdk'), middleware overrides to 'api'."""
        assert guard._source_type == "sdk"  # guard default
        sid = str(uuid.uuid4())
        app = make_app(guard, rules=[RouteRule("/api/retrieve", "analyst", "reports")])
        with client_for(app) as c:
            c.get("/api/retrieve", headers={"X-User-ID": "u1", "X-Session-ID": sid})
        assert guard.get_audit_trail(sid)[0].source_type == "api"


# ── dynamic source_id from path params ───────────────────────────────────────

class TestDynamicSourceId:
    def test_allowed_source_from_path(self, guard):
        app = make_app(guard, rules=[
            RouteRule("/api/retrieve/{source}", "analyst", "{source}"),
        ])
        with client_for(app) as c:
            r = c.get("/api/retrieve/reports", headers=DEFAULT_HEADERS)
        assert r.status_code == 200
        assert r.headers["x-autopil-decision"] == "ALLOW"

    def test_denied_source_from_path(self, guard):
        app = make_app(guard, rules=[
            RouteRule("/api/retrieve/{source}", "analyst", "{source}"),
        ])
        with client_for(app) as c:
            r = c.get("/api/retrieve/pii_records", headers=DEFAULT_HEADERS)
        assert r.status_code == 403
        assert r.json()["source_id"] == "pii_records"

    def test_audit_records_resolved_source_id(self, guard):
        sid = str(uuid.uuid4())
        app = make_app(guard, rules=[
            RouteRule("/api/retrieve/{source}", "analyst", "{source}"),
        ])
        with client_for(app) as c:
            c.get("/api/retrieve/market_data",
                  headers={"X-User-ID": "u1", "X-Session-ID": sid})
        events = guard.get_audit_trail(sid)
        assert events[0].source_id == "market_data"


# ── query extraction ──────────────────────────────────────────────────────────

class TestQueryExtraction:
    def test_query_from_query_string(self, guard):
        sid = str(uuid.uuid4())
        app = make_app(guard, rules=[
            RouteRule("/api/retrieve", "analyst", "reports", query_param="q"),
        ])
        with client_for(app) as c:
            c.get("/api/retrieve?q=revenue+forecast",
                  headers={"X-User-ID": "u1", "X-Session-ID": sid})
        events = guard.get_audit_trail(sid)
        assert events[0].query == "revenue forecast"

    def test_query_from_json_body(self, guard):
        sid = str(uuid.uuid4())
        app = FastAPI()
        app.add_middleware(AutoPILMiddleware, guard=guard, rules=[
            RouteRule("/api/search", "analyst", "search_index",
                      methods=frozenset({"POST"}), query_body_field="query"),
        ])

        @app.post("/api/search")
        async def search(body: dict):
            return {"ok": True}

        with client_for(app) as c:
            c.post("/api/search", json={"query": "what is my balance"},
                   headers={"X-User-ID": "u1", "X-Session-ID": sid})
        events = guard.get_audit_trail(sid)
        assert events[0].query == "what is my balance"

    def test_body_passed_to_handler_after_buffering(self, guard):
        """When query_body_field is set, the downstream handler still receives the body."""
        received_body = []
        app = FastAPI()
        app.add_middleware(AutoPILMiddleware, guard=guard, rules=[
            RouteRule("/api/search", "analyst", "search_index",
                      methods=frozenset({"POST"}), query_body_field="query"),
        ])

        @app.post("/api/search")
        async def search(body: dict):
            received_body.append(body)
            return {"ok": True}

        with client_for(app) as c:
            c.post("/api/search", json={"query": "balance inquiry"},
                   headers=DEFAULT_HEADERS)
        assert received_body == [{"query": "balance inquiry"}]


# ── user_id and session_id extraction ────────────────────────────────────────

class TestContextExtraction:
    def test_user_id_from_header(self, guard):
        sid = str(uuid.uuid4())
        app = make_app(guard, rules=[RouteRule("/api/retrieve", "analyst", "reports")])
        with client_for(app) as c:
            c.get("/api/retrieve", headers={"X-User-ID": "analyst_bob", "X-Session-ID": sid})
        assert guard.get_audit_trail(sid)[0].user_id == "analyst_bob"

    def test_user_id_defaults_to_anonymous(self, guard):
        sid = str(uuid.uuid4())
        app = make_app(guard, rules=[RouteRule("/api/retrieve", "analyst", "reports")])
        with client_for(app) as c:
            c.get("/api/retrieve", headers={"X-Session-ID": sid})
        assert guard.get_audit_trail(sid)[0].user_id == "anonymous"

    def test_session_id_auto_generated_when_absent(self, guard):
        app = make_app(guard, rules=[RouteRule("/api/retrieve", "analyst", "reports")])
        with client_for(app) as c:
            r = c.get("/api/retrieve", headers={"X-User-ID": "u1"})
        session_id = r.headers.get("x-autopil-session-id")
        assert session_id is not None and len(session_id) == 36

    def test_custom_user_id_header(self, guard):
        sid = str(uuid.uuid4())
        app = FastAPI()
        app.add_middleware(AutoPILMiddleware, guard=guard, rules=[
            RouteRule("/api/retrieve", "analyst", "reports",
                      user_id_header="X-Forwarded-User"),
        ])

        @app.get("/api/retrieve")
        async def retrieve():
            return {}

        with client_for(app) as c:
            c.get("/api/retrieve",
                  headers={"X-Forwarded-User": "proxy_user", "X-Session-ID": sid})
        assert guard.get_audit_trail(sid)[0].user_id == "proxy_user"


# ── method filtering ──────────────────────────────────────────────────────────

class TestMethodFiltering:
    def test_matching_method_is_governed(self, guard):
        app = make_app(guard, rules=[
            RouteRule("/api/retrieve", "analyst", "pii_records",
                      methods=frozenset({"GET"})),
        ])
        with client_for(app) as c:
            r = c.get("/api/retrieve", headers=DEFAULT_HEADERS)
        assert r.status_code == 403

    def test_non_matching_method_passes_through(self, guard):
        app = FastAPI()
        app.add_middleware(AutoPILMiddleware, guard=guard, rules=[
            RouteRule("/api/retrieve", "analyst", "pii_records",
                      methods=frozenset({"POST"})),
        ])

        @app.get("/api/retrieve")
        async def retrieve():
            return {"ok": True}

        with client_for(app) as c:
            r = c.get("/api/retrieve", headers=DEFAULT_HEADERS)
        assert r.status_code == 200
        assert "x-autopil-decision" not in r.headers


# ── wildcard patterns ─────────────────────────────────────────────────────────

class TestWildcardPatterns:
    def test_segment_wildcard_matches_any_segment(self, guard):
        app = FastAPI()
        app.add_middleware(AutoPILMiddleware, guard=guard, rules=[
            RouteRule("/api/*/data", "analyst", "pii_records"),
        ])

        @app.get("/api/{thing}/data")
        async def handler(thing: str):
            return {}

        with client_for(app) as c:
            r = c.get("/api/users/data", headers=DEFAULT_HEADERS)
        assert r.status_code == 403

    def test_full_wildcard_matches_deep_paths(self, guard):
        app = FastAPI()
        app.add_middleware(AutoPILMiddleware, guard=guard, rules=[
            RouteRule("/api/**", "analyst", "pii_records"),
        ])

        @app.get("/api/v2/deep/path")
        async def handler():
            return {}

        with client_for(app) as c:
            r = c.get("/api/v2/deep/path", headers=DEFAULT_HEADERS)
        assert r.status_code == 403


# ── shadow mode (on_deny="log") ───────────────────────────────────────────────

class TestShadowMode:
    def test_shadow_mode_passes_request_through_on_deny(self, guard):
        app = make_app(guard, rules=[
            RouteRule("/api/admin", "analyst", "pii_records"),
        ], on_deny="log")
        with client_for(app) as c:
            r = c.get("/api/admin", headers=DEFAULT_HEADERS)
        assert r.status_code == 200  # handler ran

    def test_shadow_mode_still_records_deny_event(self, guard):
        sid = str(uuid.uuid4())
        app = make_app(guard, rules=[
            RouteRule("/api/admin", "analyst", "pii_records"),
        ], on_deny="log")
        with client_for(app) as c:
            c.get("/api/admin", headers={"X-User-ID": "u1", "X-Session-ID": sid})
        events = guard.get_audit_trail(sid)
        assert len(events) == 1
        assert events[0].decision == Decision.DENY

    def test_shadow_mode_injects_deny_header(self, guard):
        app = make_app(guard, rules=[
            RouteRule("/api/admin", "analyst", "pii_records"),
        ], on_deny="log")
        with client_for(app) as c:
            r = c.get("/api/admin", headers=DEFAULT_HEADERS)
        assert r.headers.get("x-autopil-decision") == "DENY"


# ── rule compilation helpers ──────────────────────────────────────────────────

class TestCompilePattern:
    def test_exact_match(self):
        p = _compile_pattern("/api/retrieve")
        assert p.match("/api/retrieve")
        assert not p.match("/api/retrieve/extra")

    def test_path_param(self):
        p = _compile_pattern("/api/retrieve/{source}")
        m = p.match("/api/retrieve/reports")
        assert m and m.group("source") == "reports"

    def test_segment_wildcard(self):
        p = _compile_pattern("/api/*/data")
        assert p.match("/api/users/data")
        assert not p.match("/api/users/extra/data")

    def test_full_wildcard(self):
        p = _compile_pattern("/api/**")
        assert p.match("/api/v2/deep/nested/path")

    def test_resolve_source_id_static(self):
        assert _resolve_source_id("reports", {}) == "reports"

    def test_resolve_source_id_from_path_param(self):
        assert _resolve_source_id("{source}", {"source": "market_data"}) == "market_data"

    def test_resolve_source_id_missing_param(self):
        assert _resolve_source_id("{source}", {}) == "{source}"  # unchanged
