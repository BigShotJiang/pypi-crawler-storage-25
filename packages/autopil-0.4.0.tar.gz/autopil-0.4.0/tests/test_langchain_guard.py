"""
Tests for LangChainGuard — AutoPIL's integration layer for LangChain agents.
"""

import uuid
import textwrap
import pytest

from autopil.langchain_guard import LangChainGuard
from autopil.models import Decision, SensitivityLevel

POLICY_YAML = textwrap.dedent("""\
policies:
  - name: compliance_screener_policy
    agent_role: compliance_screener
    allowed_sources:
      - transaction_history
      - sanctions_watchlist
    denied_sources:
      - other_customer_data
      - aml_model_weights
    max_sensitivity: high
""")


@pytest.fixture
def guard(tmp_path):
    (tmp_path / "policy.yaml").write_text(POLICY_YAML)
    return LangChainGuard(
        policy_path=str(tmp_path / "policy.yaml"),
        audit_db=str(tmp_path / "test.db"),
    )


@pytest.fixture
def sid():
    return str(uuid.uuid4())


class TestSourceTypeTagging:
    def test_allowed_event_tagged_langchain(self, guard, sid):
        @guard.protect(agent_role="compliance_screener", user_id="u1",
                       source_id="transaction_history", session_id=sid)
        def fetch(_): return {}
        fetch("q")
        events = guard.get_audit_trail(sid)
        assert events[0].source_type == "langchain"

    def test_denied_event_tagged_langchain(self, guard, sid):
        @guard.protect(agent_role="compliance_screener", user_id="u1",
                       source_id="other_customer_data", session_id=sid)
        def fetch(_): return {}
        with pytest.raises(PermissionError):
            fetch("q")
        events = guard.get_audit_trail(sid)
        assert events[0].source_type == "langchain"
        assert events[0].decision == Decision.DENY

    def test_not_tagged_sdk_or_mcp(self, guard, sid):
        @guard.protect(agent_role="compliance_screener", user_id="u1",
                       source_id="transaction_history", session_id=sid)
        def fetch(_): return {}
        fetch("q")
        assert guard.get_audit_trail(sid)[0].source_type not in ("sdk", "mcp", "rest")


class TestPolicyEnforcement:
    def test_allowed_source_returns_data(self, guard, sid):
        @guard.protect(agent_role="compliance_screener", user_id="u1",
                       source_id="sanctions_watchlist", session_id=sid)
        def fetch(_): return {"status": "clear"}
        assert fetch("ACME") == {"status": "clear"}

    def test_denied_source_raises(self, guard, sid):
        @guard.protect(agent_role="compliance_screener", user_id="u1",
                       source_id="aml_model_weights", session_id=sid)
        def fetch(_): return {}
        with pytest.raises(PermissionError, match="DENIED"):
            fetch("q")

    def test_sensitivity_ceiling(self, guard, sid):
        @guard.protect(agent_role="compliance_screener", user_id="u1",
                       source_id="transaction_history",
                       sensitivity_level=SensitivityLevel.RESTRICTED, session_id=sid)
        def fetch(_): return {}
        with pytest.raises(PermissionError):
            fetch("q")
        assert guard.get_audit_trail(sid)[0].decision == Decision.DENY


class TestWrapTool:
    def test_wrap_tool_allows_on_allowed_source(self, guard, sid):
        class MockTool:
            def _run(self, query): return {"data": 42}

        tool = MockTool()
        guard.wrap_tool(tool, agent_role="compliance_screener", user_id="u1",
                        source_id="transaction_history", session_id=sid)
        result = tool._run("q")
        assert result == {"data": 42}

    def test_wrap_tool_denied_raises(self, guard, sid):
        class MockTool:
            def _run(self, query): return {}

        tool = MockTool()
        guard.wrap_tool(tool, agent_role="compliance_screener", user_id="u1",
                        source_id="other_customer_data", session_id=sid)
        with pytest.raises(PermissionError):
            tool._run("q")

    def test_wrap_tool_tags_langchain(self, guard, sid):
        class MockTool:
            def _run(self, query): return {}

        tool = MockTool()
        guard.wrap_tool(tool, agent_role="compliance_screener", user_id="u1",
                        source_id="transaction_history", session_id=sid)
        tool._run("q")
        assert guard.get_audit_trail(sid)[0].source_type == "langchain"


class TestAuditTrail:
    def test_mixed_decisions_all_tagged_langchain(self, guard, sid):
        @guard.protect(agent_role="compliance_screener", user_id="u1",
                       source_id="transaction_history", session_id=sid)
        def allowed(_): return {}

        @guard.protect(agent_role="compliance_screener", user_id="u1",
                       source_id="other_customer_data", session_id=sid)
        def denied(_): return {}

        allowed("q")
        with pytest.raises(PermissionError):
            denied("q")

        events = guard.get_audit_trail(sid)
        assert len(events) == 2
        assert all(e.source_type == "langchain" for e in events)
        assert {e.decision for e in events} == {Decision.ALLOW, Decision.DENY}
