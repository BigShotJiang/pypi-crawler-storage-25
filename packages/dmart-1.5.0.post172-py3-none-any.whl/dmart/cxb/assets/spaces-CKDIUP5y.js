import{w as s}from"./svelte-BmOA9CA2.js";const o=s(null);export{o as s};
