"""SurrealDB schema for the decision ledger — v4 (v0.5.0 clean break).

Targets SurrealDB 2.x embedded via Python SDK (surrealdb>=1.0.0).
Uses SEARCH ANALYZER syntax (v2 compatible, not FULLTEXT ANALYZER which is v3+).

Graph shape (v4):
  Decision tier:  input_span -yields-> decision -binds_to-> code_region
  Retrieval tier: symbol -locates-> code_region

To initialise: await init_schema(client)
Schema migrations: await migrate(client)
"""

from __future__ import annotations

import logging
from datetime import UTC

from .client import LedgerClient, LedgerError

logger = logging.getLogger(__name__)

# ── Schema version ──────────────────────────────────────────────────────
# v4 (v0.5.0): atomic clean break.
#   - source_span → input_span (verbatim text required, no DEFAULT)
#   - intent → decision (+ product_signoff double-entry axis)
#   - compliance_check.intent_id → decision_id (+ pruned flag)
#   - edges: yields(input_span→decision), binds_to(decision→code_region),
#             locates(symbol→code_region)
#   - removed: maps_to, implements
SCHEMA_VERSION = 17

# Maps schema version → minimum bicameral-mcp code version that understands it.
# Used to produce actionable "upgrade your binary" messages.
SCHEMA_COMPATIBILITY: dict[int, str] = {
    4: "0.5.0",
    5: "0.6.0",
    6: "0.7.0",
    7: "0.8.0",
    8: "0.9.0",
    9: "0.9.3",
    11: "0.11.0",  # placeholder; release-eng pins final value at PR merge
    12: "0.12.0",  # placeholder; release-eng pins final value at PR merge
    13: "0.12.1",  # provenance FLEXIBLE on binds_to (#72)
    14: "0.13.0",  # placeholder; release-eng pins final value at PR merge — Phase 4 (#61)
    15: "0.15.x",  # decision.governance (#109 — governance metadata)
    16: "0.13.x",  # #252 Layer 2 — wire-format sentinel via bicameral_meta table; placeholder, release-eng pins final value at PR merge
    17: "0.14.x",  # re-runnable yields integrity cleanup; placeholder, release-eng pins final value at PR merge
}

# SurrealDB error substrings that init_schema treats as recoverable: the row
# state predates the new constraint and the next migration is responsible for
# cleaning it up. The substring set is the load-bearing safety contract — any
# new pattern here must be paired with a fixture-DB regression test
# (tests/test_schema_recoverable_errors.py) that produces the exact string,
# so a future surrealdb-py bump that changes the format fails CI loudly.
RECOVERABLE_DEFINE_PATTERNS: tuple[str, ...] = (
    "already exists",  # DEFINE re-applied with no change
    "already contains",  # UNIQUE index attempted on table w/ duplicates
    "expected a record<",  # TYPE constraint mismatch (rename of IN/OUT type)
    "but expected",  # generic value-type assertion failure (defensive)
)

# Migrations that drop or recreate tables/data. These are never auto-applied;
# the user must explicitly confirm via bicameral_reset(confirm=True).
DESTRUCTIVE_MIGRATIONS: frozenset[int] = frozenset()


class DestructiveMigrationRequired(LedgerError):
    """Pending migration step drops data and requires explicit user confirmation.

    Raise when a destructive migration is pending and allow_destructive=False.
    Callers should surface: "run bicameral_reset(confirm=True) to proceed."
    """


class SchemaVersionTooNew(LedgerError):
    """DB schema version is newer than the running code understands.

    Raised when the DB was written by a newer binary. User must upgrade.
    """


# Analyzers
_ANALYZERS = [
    # Business language: transcripts, PRDs, decisions
    "DEFINE ANALYZER biz_analyzer TOKENIZERS blank, class, punct FILTERS lowercase, ascii, snowball(english)",
    # Code symbols: CamelCase + snake_case aware
    "DEFINE ANALYZER code_analyzer TOKENIZERS class, camel FILTERS lowercase, ascii",
]

# Core tables
_TABLES = [
    # ── Decision tier ────────────────────────────────────────────────────
    # input_span — raw verbatim text excerpt from a meeting, PRD, Slack, or
    # implementation-time rationale. "What was said / written."
    # text is required — no DEFAULT. A span without verbatim text is rejected
    # at the ingest contract boundary (IngestDecision.source_excerpt must be
    # non-empty). See v0.5.0 plan §Core Principle.
    "DEFINE TABLE input_span SCHEMAFULL",
    "DEFINE FIELD text           ON input_span TYPE string ASSERT string::len($value) > 0",
    "DEFINE FIELD source_type    ON input_span TYPE string",  # transcript | notion | slack | document | manual | implementation_choice
    "DEFINE FIELD source_ref     ON input_span TYPE string DEFAULT ''",  # meeting ID, page URL, etc.
    "DEFINE FIELD speakers       ON input_span TYPE array<string> DEFAULT []",
    "DEFINE FIELD meeting_date   ON input_span TYPE string DEFAULT ''",
    "DEFINE FIELD created_at     ON input_span TYPE datetime DEFAULT time::now()",
    "DEFINE INDEX idx_input_span_ref   ON input_span FIELDS source_type, source_ref",
    # Dedup: same excerpt from same source is the same span
    "DEFINE INDEX idx_input_span_dedup ON input_span FIELDS source_type, source_ref, text UNIQUE",
    # decision — extracted decision / requirement. "What was decided."
    # Denormalized source fields (source_type, source_ref, speakers, meeting_date)
    # are kept for query speed; they mirror the linked input_span but are never
    # derived from the span's text when the excerpt is missing.
    "DEFINE TABLE decision SCHEMAFULL CHANGEFEED 30d INCLUDE ORIGINAL",
    "DEFINE FIELD description    ON decision TYPE string",
    "DEFINE FIELD rationale      ON decision TYPE string DEFAULT ''",
    "DEFINE FIELD feature_hint   ON decision TYPE string DEFAULT ''",
    "DEFINE FIELD feature_group  ON decision TYPE option<string> DEFAULT NONE",
    "DEFINE FIELD source_type    ON decision TYPE string DEFAULT ''",
    "DEFINE FIELD source_ref     ON decision TYPE string DEFAULT ''",
    "DEFINE FIELD meeting_date   ON decision TYPE string DEFAULT ''",
    "DEFINE FIELD speakers       ON decision TYPE array<string> DEFAULT []",
    "DEFINE FIELD status         ON decision TYPE string DEFAULT 'ungrounded' "
    "ASSERT $value IN ['reflected', 'drifted', 'pending', 'ungrounded']",
    "DEFINE FIELD created_at     ON decision TYPE datetime DEFAULT time::now()",
    # v0.4.13-style content-addressable dedup; same derivation, renamed type
    "DEFINE FIELD canonical_id   ON decision TYPE string DEFAULT ''",
    # Double-entry axis — signoff is stored; eng_reflected is derived
    # from compliance_check aggregation at read time via project_decision_status.
    # Shape: {state: 'proposed'|'ratified', session_id, created_at/ratified_at, signer?, note?}
    "DEFINE FIELD signoff ON decision FLEXIBLE TYPE option<object> DEFAULT NONE",
    # v0.9.3 — hierarchical decision model (CodeGenome-aligned).
    # See docs/decision-level.md for the full reference, including the
    # tolerant-NULL policy and codegenome-write semantics per level.
    #
    # Quick reference (full doc covers nuance + examples):
    #   L1   = behavioural / product claim   → no codegenome identity write
    #   L2   = implementation identity       → codegenome identity write enabled
    #   L3   = glue / infrastructure detail  → no codegenome identity write
    #   NONE = unclassified (legacy rows)    → treated as L3 (skip), tolerant policy
    #
    # Enforced by handlers/bind.py L1-exemption guard; the ASSERT below
    # is the only schema-level constraint.
    "DEFINE FIELD decision_level     ON decision TYPE option<string> DEFAULT NONE "
    "ASSERT $value = NONE OR $value IN ['L1', 'L2', 'L3']",
    "DEFINE FIELD parent_decision_id ON decision TYPE option<string> DEFAULT NONE",
    # v15 (#109) — optional governance metadata. FLEXIBLE because the
    # nested object carries pydantic-validated keys (decision_class,
    # risk_class, escalation_class, owner, supervisor,
    # notification_channels, protected_component, review_after);
    # SurrealDB v2 silently strips nested keys for plain TYPE object
    # without FLEXIBLE. None for pre-v15 rows; readers fall back to
    # ``derive_governance_metadata`` defaults at evaluation time.
    "DEFINE FIELD governance         ON decision FLEXIBLE TYPE option<object> DEFAULT NONE",
    "DEFINE INDEX idx_decision_canonical ON decision FIELDS canonical_id UNIQUE",
    "DEFINE INDEX idx_decision_fts ON decision FIELDS description "
    "SEARCH ANALYZER biz_analyzer BM25(1.2, 0.75) HIGHLIGHTS",
    # Powers the "awaiting signoff" PM dashboard queue
    "DEFINE INDEX idx_decision_signoff ON decision FIELDS signoff",
    # ── Shared / unchanged ──────────────────────────────────────────────
    # symbol — a named code entity (function, class, file). Retrieval-tier only.
    "DEFINE TABLE symbol SCHEMAFULL",
    "DEFINE FIELD name           ON symbol TYPE string",
    "DEFINE FIELD file_path      ON symbol TYPE string",
    "DEFINE FIELD sym_type       ON symbol TYPE string",
    "DEFINE FIELD last_seen      ON symbol TYPE datetime DEFAULT time::now()",
    "DEFINE FIELD hit_count      ON symbol TYPE int DEFAULT 0",
    "DEFINE INDEX idx_sym_name   ON symbol FIELDS name SEARCH ANALYZER code_analyzer BM25(1.2, 0.75)",
    "DEFINE INDEX idx_sym_file   ON symbol FIELDS file_path",
    # code_region — a specific span within a file. Shared between the two tiers:
    # decision tier addresses it via binds_to; retrieval tier via locates.
    "DEFINE TABLE code_region SCHEMAFULL CHANGEFEED 30d INCLUDE ORIGINAL",
    "DEFINE FIELD file_path      ON code_region TYPE string",
    "DEFINE FIELD symbol_name    ON code_region TYPE string",  # display-only metadata, not a graph edge target
    "DEFINE FIELD start_line     ON code_region TYPE int",
    "DEFINE FIELD end_line       ON code_region TYPE int",
    "DEFINE FIELD purpose        ON code_region TYPE string DEFAULT ''",
    "DEFINE FIELD repo           ON code_region TYPE string DEFAULT ''",
    "DEFINE FIELD pinned_commit  ON code_region TYPE string DEFAULT ''",
    "DEFINE FIELD content_hash   ON code_region TYPE string DEFAULT ''",
    "DEFINE INDEX idx_region_sym  ON code_region FIELDS symbol_name",
    "DEFINE INDEX idx_region_file ON code_region FIELDS repo, file_path",
    # vocab_cache — grounding reuse cache for query→code_region lookups
    "DEFINE TABLE vocab_cache SCHEMAFULL",
    "DEFINE FIELD query_text     ON vocab_cache TYPE string",
    "DEFINE FIELD repo           ON vocab_cache TYPE string",
    "DEFINE FIELD symbols        ON vocab_cache FLEXIBLE TYPE array DEFAULT []",
    "DEFINE FIELD hit_count      ON vocab_cache TYPE int DEFAULT 0",
    "DEFINE FIELD last_hit       ON vocab_cache TYPE datetime DEFAULT time::now()",
    "DEFINE INDEX idx_vocab_query ON vocab_cache FIELDS query_text SEARCH ANALYZER biz_analyzer BM25(1.2, 0.75)",
    "DEFINE INDEX idx_vocab_repo  ON vocab_cache FIELDS repo",
    # ledger_sync — idempotency cursor (last synced commit per repo)
    "DEFINE TABLE ledger_sync SCHEMAFULL",
    "DEFINE FIELD repo               ON ledger_sync TYPE string",
    "DEFINE FIELD last_synced_commit ON ledger_sync TYPE string",
    "DEFINE FIELD synced_at          ON ledger_sync TYPE datetime DEFAULT time::now()",
    "DEFINE INDEX idx_sync_repo ON ledger_sync FIELDS repo UNIQUE",
    # source_cursor — upstream ingestion checkpoint per source stream
    "DEFINE TABLE source_cursor SCHEMAFULL",
    "DEFINE FIELD repo            ON source_cursor TYPE string",
    "DEFINE FIELD source_type     ON source_cursor TYPE string",
    "DEFINE FIELD source_scope    ON source_cursor TYPE string DEFAULT 'default'",
    "DEFINE FIELD cursor          ON source_cursor TYPE string DEFAULT ''",
    "DEFINE FIELD last_source_ref ON source_cursor TYPE string DEFAULT ''",
    "DEFINE FIELD synced_at       ON source_cursor TYPE datetime DEFAULT time::now()",
    "DEFINE FIELD status          ON source_cursor TYPE string DEFAULT 'ok'",
    "DEFINE FIELD error           ON source_cursor TYPE string DEFAULT ''",
    "DEFINE INDEX idx_source_cursor ON source_cursor FIELDS repo, source_type, source_scope UNIQUE",
    # compliance_check — LLM verification cache.
    # Cache key: (decision_id, region_id, content_hash) — one verdict per code shape.
    # pruned=true means the caller said "not_relevant" — retrieval mistake, binds_to
    # edge has been deleted. Row kept for audit trail.
    #
    # CHANGEFEED 30d INCLUDE ORIGINAL (Phase 4 / #61, F1 audit remediation):
    # required so caller-LLM verdicts that overwrite an auto-resolved
    # cosmetic row remain forensically recoverable for 30 days. Without
    # the changefeed, the original (semantic_status='semantically_preserved')
    # row would be silently lost on overwrite.
    "DEFINE TABLE compliance_check SCHEMAFULL CHANGEFEED 30d INCLUDE ORIGINAL",
    "DEFINE FIELD decision_id  ON compliance_check TYPE string",  # renamed from intent_id
    "DEFINE FIELD region_id    ON compliance_check TYPE string",
    "DEFINE FIELD content_hash ON compliance_check TYPE string",
    "DEFINE FIELD commit_hash  ON compliance_check TYPE string DEFAULT ''",
    "DEFINE FIELD verdict      ON compliance_check TYPE string "
    "ASSERT $value IN ['compliant', 'drifted', 'not_relevant']",
    "DEFINE FIELD pruned       ON compliance_check TYPE bool DEFAULT false",
    "DEFINE FIELD confidence   ON compliance_check TYPE string "
    "ASSERT $value IN ['high', 'medium', 'low']",
    "DEFINE FIELD explanation  ON compliance_check TYPE string DEFAULT ''",
    "DEFINE FIELD phase        ON compliance_check TYPE string "
    "ASSERT $value IN ['ingest', 'drift', 'regrounding', 'supersession', 'divergence'] "
    "DEFAULT 'drift'",
    "DEFINE FIELD checked_at   ON compliance_check TYPE datetime DEFAULT time::now()",
    "DEFINE FIELD ephemeral    ON compliance_check TYPE bool DEFAULT false",
    # Phase 4 (#61) — semantic drift evaluation fields.
    # semantic_status records whether an auto-classifier or caller-LLM
    # judged the change cosmetic vs semantically meaningful.
    # evidence_refs is a free-form audit trail of the signals that drove
    # the verdict (e.g. ['signature:1.00', 'neighbors:0.97']).
    "DEFINE FIELD semantic_status ON compliance_check TYPE option<string> DEFAULT NONE "
    "ASSERT $value = NONE OR $value IN ['semantically_preserved', 'semantic_change']",
    "DEFINE FIELD evidence_refs   ON compliance_check TYPE array<string> DEFAULT []",
    "DEFINE INDEX idx_cc_cache_key ON compliance_check FIELDS decision_id, region_id, content_hash UNIQUE",
    "DEFINE INDEX idx_cc_decision  ON compliance_check FIELDS decision_id",
    "DEFINE INDEX idx_cc_region    ON compliance_check FIELDS region_id",
    "DEFINE INDEX idx_cc_commit    ON compliance_check FIELDS commit_hash",
    "DEFINE INDEX idx_cc_ephemeral ON compliance_check FIELDS ephemeral",
    # graph_proposal — AI-generated edge proposals for human review.
    # from_id / to_id are TYPE string (not TYPE record) because this table can
    # link across different node types. Traverse via type::thing($from_id).
    # AI does NOT write here yet (schema-only for v0.8.x infrastructure).
    "DEFINE TABLE graph_proposal SCHEMAFULL",
    "DEFINE FIELD proposal_type ON graph_proposal TYPE string "
    "ASSERT $value IN ['context_for', 'supersedes', 'related_to', 'contradicts']",
    "DEFINE FIELD from_id       ON graph_proposal TYPE string",
    "DEFINE FIELD to_id         ON graph_proposal TYPE string",
    "DEFINE FIELD reason        ON graph_proposal TYPE string DEFAULT ''",
    "DEFINE FIELD confidence    ON graph_proposal TYPE float",
    "DEFINE FIELD state         ON graph_proposal TYPE string "
    "ASSERT $value IN ['pending', 'approved', 'rejected', 'auto_approved'] DEFAULT 'pending'",
    "DEFINE FIELD session_id    ON graph_proposal TYPE string DEFAULT ''",
    "DEFINE FIELD created_at    ON graph_proposal TYPE datetime DEFAULT time::now()",
    "DEFINE FIELD reviewed_at   ON graph_proposal TYPE option<datetime> DEFAULT NONE",
    # ── CodeGenome tier (v11, additive — Phase 1+2 / #59) ───────────────
    # All writes are gated by codegenome.write_identity_records=True at the
    # handler boundary. Tables exist unconditionally so toggling the flag
    # mid-deployment does not require a migration.
    # code_subject — a conceptual code target (function, class, module…)
    # that can survive movement across files. Distinct from `symbol`,
    # which is keyed on name+kind at one point in time.
    "DEFINE TABLE code_subject SCHEMAFULL",
    "DEFINE FIELD kind               ON code_subject TYPE string",
    "DEFINE FIELD canonical_name     ON code_subject TYPE string",
    "DEFINE FIELD repo_ref           ON code_subject TYPE option<string>",
    "DEFINE FIELD current_confidence ON code_subject TYPE float ASSERT $value >= 0 AND $value <= 1",
    "DEFINE FIELD created_at         ON code_subject TYPE datetime DEFAULT time::now()",
    "DEFINE FIELD updated_at         ON code_subject TYPE datetime DEFAULT time::now()",
    "DEFINE INDEX idx_code_subject_canonical ON code_subject FIELDS kind, canonical_name UNIQUE",
    # subject_identity — durable fingerprint for one observation of a
    # code_subject. Phase 3 (#60) will add a supersedes edge between
    # identities; not defined yet.
    "DEFINE TABLE subject_identity SCHEMAFULL",
    "DEFINE FIELD address              ON subject_identity TYPE string",
    "DEFINE FIELD identity_type        ON subject_identity TYPE string",
    "DEFINE FIELD structural_signature ON subject_identity TYPE option<string>",
    "DEFINE FIELD behavioral_signature ON subject_identity TYPE option<string>",
    "DEFINE FIELD signature_hash       ON subject_identity TYPE option<string>",
    "DEFINE FIELD content_hash         ON subject_identity TYPE option<string>",
    "DEFINE FIELD confidence           ON subject_identity TYPE float "
    "ASSERT $value >= 0 AND $value <= 1",
    "DEFINE FIELD model_version        ON subject_identity TYPE string",
    "DEFINE FIELD created_at           ON subject_identity TYPE datetime DEFAULT time::now()",
    # v12 (Phase 3): 1-hop call-graph neighbor addresses captured at bind
    # time for the continuity matcher's Jaccard signal. None for pre-v12 rows.
    "DEFINE FIELD neighbors_at_bind    ON subject_identity TYPE option<array<string>> DEFAULT NONE",
    "DEFINE INDEX idx_subject_identity_address ON subject_identity FIELDS address UNIQUE",
    # subject_version — concrete location/symbol observation at one
    # repo_ref. Phase 3 (#60) will write versions when a continuity match
    # resolves a relocation; Phase 1+2 only defines the table (foundation
    # so the schema migration fires once, not twice).
    "DEFINE TABLE subject_version SCHEMAFULL",
    "DEFINE FIELD repo_ref       ON subject_version TYPE string",
    "DEFINE FIELD file_path      ON subject_version TYPE string",
    "DEFINE FIELD start_line     ON subject_version TYPE int",
    "DEFINE FIELD end_line       ON subject_version TYPE int",
    "DEFINE FIELD symbol_name    ON subject_version TYPE option<string>",
    "DEFINE FIELD symbol_kind    ON subject_version TYPE option<string>",
    "DEFINE FIELD content_hash   ON subject_version TYPE option<string>",
    "DEFINE FIELD signature_hash ON subject_version TYPE option<string>",
    "DEFINE FIELD created_at     ON subject_version TYPE datetime DEFAULT time::now()",
    "DEFINE INDEX idx_subject_version_loc "
    "ON subject_version FIELDS repo_ref, file_path, start_line, end_line",
]

# Edge tables — all with UNIQUE(in, out) for team-mode replay idempotency
#
# Decision tier:
#   input_span -yields-> decision    (extraction provenance, 1:N)
#   decision -binds_to-> code_region (decision is about this code, N:N)
#
# HITL edges (v0.8.0):
#   decision -supersedes-> decision  (human-confirmed supersession)
#   input_span -context_for-> decision (human-confirmed context provision)
#
# Retrieval tier:
#   symbol -locates-> code_region   (symbol body occupies this region at this commit)
_EDGES = [
    # input_span → decision (extraction provenance)
    "DEFINE TABLE yields SCHEMAFULL TYPE RELATION IN input_span OUT decision",
    "DEFINE FIELD created_at ON yields TYPE datetime DEFAULT time::now()",
    "DEFINE INDEX idx_yields_unique ON yields FIELDS in, out UNIQUE",
    # decision → code_region (direct binding — decision tier only)
    "DEFINE TABLE binds_to SCHEMAFULL TYPE RELATION IN decision OUT code_region",
    "DEFINE FIELD confidence ON binds_to TYPE float ASSERT $value >= 0 AND $value <= 1",
    # FLEXIBLE is required for provenance: callers attach nested
    # objects (e.g. {"caller_llm": {...}, "search_hint": {...}}) and
    # SurrealDB v2 silently strips nested keys for plain ``TYPE object``
    # without FLEXIBLE. See issue #72.
    "DEFINE FIELD provenance ON binds_to FLEXIBLE TYPE object DEFAULT {}",
    "DEFINE FIELD created_at ON binds_to TYPE datetime DEFAULT time::now()",
    "DEFINE INDEX idx_binds_to_unique ON binds_to FIELDS in, out UNIQUE",
    # symbol → code_region (retrieval tier — BM25 / graph / future embeddings)
    "DEFINE TABLE locates SCHEMAFULL TYPE RELATION IN symbol OUT code_region",
    "DEFINE FIELD confidence ON locates TYPE float ASSERT $value >= 0 AND $value <= 1",
    "DEFINE FIELD created_at ON locates TYPE datetime DEFAULT time::now()",
    "DEFINE INDEX idx_locates_unique ON locates FIELDS in, out UNIQUE",
    # decision → decision (human-confirmed supersession — v0.8.0 HITL)
    "DEFINE TABLE supersedes SCHEMAFULL TYPE RELATION IN decision OUT decision",
    "DEFINE FIELD confidence  ON supersedes TYPE float",
    "DEFINE FIELD reason      ON supersedes TYPE string DEFAULT ''",
    "DEFINE FIELD created_at  ON supersedes TYPE datetime DEFAULT time::now()",
    "DEFINE INDEX idx_supersedes_unique ON supersedes FIELDS in, out UNIQUE",
    # input_span → decision (human-confirmed context provision — v0.8.0 HITL)
    "DEFINE TABLE context_for SCHEMAFULL TYPE RELATION IN input_span OUT decision",
    "DEFINE FIELD relevance_score ON context_for TYPE float",
    "DEFINE FIELD reason          ON context_for TYPE string DEFAULT ''",
    "DEFINE FIELD state           ON context_for TYPE string "
    "ASSERT $value IN ['proposed', 'confirmed', 'rejected'] DEFAULT 'proposed'",
    "DEFINE FIELD created_at      ON context_for TYPE datetime DEFAULT time::now()",
    "DEFINE INDEX idx_ctx_unique ON context_for FIELDS in, out UNIQUE",
    # code_region → code_region (structural dependency — unchanged)
    "DEFINE TABLE depends_on SCHEMAFULL TYPE RELATION IN code_region OUT code_region",
    "DEFINE FIELD edge_type  ON depends_on TYPE string",
    "DEFINE FIELD created_at ON depends_on TYPE datetime DEFAULT time::now()",
    "DEFINE INDEX idx_depends_on_unique ON depends_on FIELDS in, out, edge_type UNIQUE",
    # ── CodeGenome edges (v11, additive — Phase 1+2 / #59) ──────────────
    # code_subject → has_identity → subject_identity
    "DEFINE TABLE has_identity SCHEMAFULL TYPE RELATION IN code_subject OUT subject_identity",
    "DEFINE FIELD confidence ON has_identity TYPE float ASSERT $value >= 0 AND $value <= 1",
    "DEFINE FIELD created_at ON has_identity TYPE datetime DEFAULT time::now()",
    "DEFINE INDEX idx_has_identity_unique ON has_identity FIELDS in, out UNIQUE",
    # code_subject → has_version → subject_version
    "DEFINE TABLE has_version SCHEMAFULL TYPE RELATION IN code_subject OUT subject_version",
    "DEFINE FIELD confidence ON has_version TYPE float ASSERT $value >= 0 AND $value <= 1",
    "DEFINE FIELD created_at ON has_version TYPE datetime DEFAULT time::now()",
    "DEFINE INDEX idx_has_version_unique ON has_version FIELDS in, out UNIQUE",
    # decision → about → code_subject (used by find_subject_identities_for_decision
    # to walk decision → subject → identity in two hops)
    "DEFINE TABLE about SCHEMAFULL TYPE RELATION IN decision OUT code_subject",
    "DEFINE FIELD confidence ON about TYPE float ASSERT $value >= 0 AND $value <= 1",
    "DEFINE FIELD created_at ON about TYPE datetime DEFAULT time::now()",
    "DEFINE INDEX idx_about_unique ON about FIELDS in, out UNIQUE",
    # ── CodeGenome continuity edge (v12, Phase 3 / #60) ────────────────
    # subject_identity → identity_supersedes → subject_identity
    # Records identity transitions when the continuity matcher resolves a
    # moved/renamed/moved_and_renamed symbol. Old identity is the OUT-of-scope
    # row written at original bind time; new identity is the row written by
    # Phase 3's auto-resolve sequence at link_commit time.
    "DEFINE TABLE identity_supersedes SCHEMAFULL "
    "TYPE RELATION IN subject_identity OUT subject_identity",
    "DEFINE FIELD change_type   ON identity_supersedes TYPE string "
    "ASSERT $value IN ['moved', 'renamed', 'moved_and_renamed']",
    "DEFINE FIELD confidence    ON identity_supersedes TYPE float "
    "ASSERT $value >= 0 AND $value <= 1",
    "DEFINE FIELD evidence_refs ON identity_supersedes TYPE array<string> DEFAULT []",
    "DEFINE FIELD created_at    ON identity_supersedes TYPE datetime DEFAULT time::now()",
    "DEFINE INDEX idx_identity_supersedes_unique ON identity_supersedes FIELDS in, out UNIQUE",
]

# Schema version tracking
_META = [
    "DEFINE TABLE schema_meta SCHEMAFULL",
    "DEFINE FIELD version     ON schema_meta TYPE int",
    "DEFINE FIELD migrated_at ON schema_meta TYPE datetime DEFAULT time::now()",
]

# #252 Layer 2 — wire-format sentinel.
# Separate from `_META` (schema_meta) because schema_meta is DELETEd on every
# `_set_schema_version` call. bicameral_meta has stable persistence semantics:
# write-once for `at_first_write`, update-each-connect for `at_last_write`.
_BICAMERAL_META = [
    "DEFINE TABLE bicameral_meta SCHEMAFULL",
    "DEFINE FIELD surrealdb_client_version_at_first_write ON bicameral_meta TYPE option<string> DEFAULT NONE",
    "DEFINE FIELD surrealdb_client_version_at_last_write  ON bicameral_meta TYPE option<string> DEFAULT NONE",
    "DEFINE FIELD last_write_at                            ON bicameral_meta TYPE option<datetime> DEFAULT NONE",
]


def _with_overwrite(sql: str) -> str:
    """Inject OVERWRITE into a DEFINE statement so it updates existing definitions.

    Transforms e.g. "DEFINE FIELD status ON ..." into
    "DEFINE FIELD status OVERWRITE ON ..." so that init_schema always applies
    the current field constraints (ASSERT clauses, DEFAULT values, TYPE) even
    when the field already exists in the DB.
    """
    for keyword in (
        "DEFINE TABLE",
        "DEFINE FIELD",
        "DEFINE INDEX",
        "DEFINE ANALYZER",
        "DEFINE EVENT",
    ):
        if sql.upper().startswith(keyword) and "OVERWRITE" not in sql.upper():
            return keyword + " OVERWRITE" + sql[len(keyword) :]
    return sql


async def _execute_define_idempotent(client: LedgerClient, sql: str) -> None:
    """Run a DEFINE statement; treat known recoverable errors as success.

    Recoverable patterns are listed in ``RECOVERABLE_DEFINE_PATTERNS``:

    - ``already exists`` — DEFINE re-applied; no-op.
    - ``already contains`` — UNIQUE index against duplicates; the migration
      that cleans stale data runs next and re-issues the index.
    - ``expected a record<`` — DEFINE TABLE / INDEX OVERWRITE re-validating
      legacy rows whose IN/OUT type was renamed (e.g. v3 ``yields.in =
      source_span:*`` against the current ``RELATION IN input_span``).
      The migration that drops those rows runs next.
    - ``but expected`` — generic value-type assertion failure; same recovery
      shape as the type-mismatch case.

    Any other ``LedgerError`` propagates so connect() fails fast and the
    operator sees an actionable message pointing at ``bicameral-mcp diagnose``.
    """
    try:
        await client.execute(sql)
    except LedgerError as exc:
        msg_lower = str(exc).lower()
        if not any(p in msg_lower for p in RECOVERABLE_DEFINE_PATTERNS):
            raise
        # Loud signal — UNIQUE-violation and type-mismatch each warrant a
        # warning so the next migration's cleanup is visible in audit logs.
        if (
            "already contains" in msg_lower
            or "expected a record<" in msg_lower
            or "but expected" in msg_lower
        ):
            logger.warning(
                "[schema] DEFINE skipped — existing data violates new constraint "
                "(%s). Migration will clean stale rows and re-apply. detail=%s",
                sql.split("ON")[0].strip(),
                str(exc).splitlines()[0] if str(exc) else "",
            )
            try:
                from audit_log import AuditEventType
                from audit_log import emit as audit_emit

                audit_emit(
                    AuditEventType.SCHEMA_DEFINE_SKIPPED,
                    sql_prefix=sql.split("ON")[0].strip(),
                    error_class=type(exc).__name__,
                )
            except Exception:  # noqa: BLE001 — audit MUST NOT break init_schema
                pass


async def init_schema(client: LedgerClient) -> None:
    """Create or update all tables, indexes, and analyzers.

    Uses OVERWRITE on every DEFINE statement so field constraints (ASSERT
    clauses, DEFAULT values, TYPE) are always brought up to the current schema
    definition — even when running against a DB created by an older version.
    """
    for sql in _ANALYZERS + _TABLES + _EDGES + _META + _BICAMERAL_META:
        sql = sql.strip()
        if sql:
            await _execute_define_idempotent(client, _with_overwrite(sql))


# ── Migrations ──────────────────────────────────────────────────────────


async def _clean_yields_legacy_rows(client: LedgerClient, *, log_tag: str) -> int:
    """Delete `yields` rows whose IN/OUT references the v3-era types
    (`source_span:*` / `intent:*`) that no longer match the current
    `RELATION IN input_span OUT decision` constraint.

    Returns the count of rows removed. Tolerates per-row failures so a
    single rejected delete does not abort the whole pass.
    """
    try:
        stale = await client.query(
            "SELECT id FROM yields "
            "WHERE string::starts_with(type::string(in), 'source_span:') "
            "   OR string::starts_with(type::string(out), 'intent:')"
        )
    except Exception as exc:
        logger.warning("[migration] %s: stale-edge select failed: %s", log_tag, exc)
        return 0
    removed = 0
    for row in stale or []:
        try:
            await client.execute(f"DELETE {row['id']}")
            removed += 1
        except Exception:
            pass
    if removed:
        logger.info("[migration] %s: removed %d stale legacy yields edges", log_tag, removed)
    return removed


async def _dedupe_yields(client: LedgerClient, *, log_tag: str) -> int:
    """Drop duplicate `yields` rows by (in, out), keeping the first seen.

    Returns the count of duplicates removed. Caller is responsible for
    re-applying ``DEFINE INDEX idx_yields_unique`` afterwards.
    """
    try:
        rows = await client.query("SELECT id, in, out FROM yields")
    except Exception as exc:
        logger.warning("[migration] %s: dedup select failed: %s", log_tag, exc)
        return 0
    seen: set[tuple[str, str]] = set()
    removed = 0
    for row in rows or []:
        key = (str(row.get("in", "")), str(row.get("out", "")))
        if key in seen:
            try:
                await client.execute(f"DELETE {row['id']}")
                removed += 1
            except Exception:
                pass
        else:
            seen.add(key)
    if removed:
        logger.info("[migration] %s: removed %d duplicate yields edges", log_tag, removed)
    return removed


async def _migrate_v4_to_v5(client: LedgerClient) -> None:
    """v4 → v5: Remove stale v3-era yields edges and deduplicate.

    Some DBs that went through v3→v4 still have residual source_span→intent
    edges in the yields table (the REMOVE TABLE in v3→v4 silently failed).
    Those stale edges prevent DEFINE INDEX idx_yields_unique from being
    applied, which broke startup.

    See also ``_migrate_v16_to_v17`` — a re-run of the same cleanup, gated
    on the v16→v17 boundary, for DBs that rolled past v5 with the
    corruption still present.
    """
    await _clean_yields_legacy_rows(client, log_tag="v4 → v5")
    await _dedupe_yields(client, log_tag="v4 → v5")
    await _execute_define_idempotent(
        client,
        "DEFINE INDEX idx_yields_unique ON yields FIELDS in, out UNIQUE",
    )

    logger.info("[migration] v4 → v5: yields table clean, unique index applied")


async def _migrate_v5_to_v6(client: LedgerClient) -> None:
    """v5 → v6: Rename product_signoff → signoff + tag historical records.

    Historical migration policy:
    - product_signoff = {...}  →  signoff = {state:'ratified', signer, ratified_at, session_id:null, note}
    - product_signoff = None with bindings  →  signoff = {state:'ratified', signer:'legacy-migration', ...}
    - product_signoff = None without bindings  →  signoff stays None (ungrounded)

    New ingests after v0.7.0 write signoff = {state:'proposed', ...} by default.
    """
    from datetime import datetime

    now_iso = datetime.now(UTC).isoformat()

    try:
        all_decisions = await client.query("SELECT id, product_signoff FROM decision")
        migrated = 0
        for row in all_decisions or []:
            decision_id = str(row.get("id", ""))
            old_signoff = row.get("product_signoff")

            if old_signoff and isinstance(old_signoff, dict):
                # Had explicit product_signoff → tag as ratified
                new_signoff = {
                    "state": "ratified",
                    "signer": old_signoff.get("signer", "unknown"),
                    "ratified_at": old_signoff.get("timestamp", now_iso),
                    "session_id": None,
                    "note": old_signoff.get("note", ""),
                    "source_commit_ref": old_signoff.get("source_commit_ref", ""),
                }
                try:
                    await client.execute(
                        f"UPDATE {decision_id} SET signoff = $s",
                        {"s": new_signoff},
                    )
                    migrated += 1
                except Exception as exc:
                    logger.warning("[migration] v5→v6: failed to migrate %s: %s", decision_id, exc)
            elif old_signoff is None:
                # Check for bindings — implicitly-ratified decisions get legacy-migration tag
                bindings = await client.query(
                    f"SELECT count() AS n FROM binds_to WHERE in = {decision_id} LIMIT 1"
                )
                has_bindings = bindings and int((bindings[0] or {}).get("n", 0)) > 0
                if has_bindings:
                    new_signoff = {
                        "state": "ratified",
                        "signer": "legacy-migration",
                        "ratified_at": now_iso,
                        "session_id": None,
                        "note": "",
                    }
                    try:
                        await client.execute(
                            f"UPDATE {decision_id} SET signoff = $s",
                            {"s": new_signoff},
                        )
                        migrated += 1
                    except Exception as exc:
                        logger.warning("[migration] v5→v6: failed to tag %s: %s", decision_id, exc)

        logger.info("[migration] v5 → v6: migrated %d decision signoff records", migrated)
    except Exception as exc:
        logger.warning("[migration] v5 → v6: signoff migration failed: %s", exc)

    # Re-apply index under new field name
    await _execute_define_idempotent(
        client, "DEFINE INDEX idx_decision_signoff ON decision FIELDS signoff"
    )
    logger.info("[migration] v5 → v6: signoff field indexed")


async def _migrate_v6_to_v7(client: LedgerClient) -> None:
    """v6 → v7: Add HITL graph edges and graph_proposal table.

    Additive only — no data loss. Defines new tables and updates the
    decision.status ASSERT to include 'superseded' and 'context_pending'.
    """
    new_stmts = [
        # New HITL edge tables
        "DEFINE TABLE supersedes SCHEMAFULL TYPE RELATION IN decision OUT decision",
        "DEFINE FIELD confidence  ON supersedes TYPE float",
        "DEFINE FIELD reason      ON supersedes TYPE string DEFAULT ''",
        "DEFINE FIELD created_at  ON supersedes TYPE datetime DEFAULT time::now()",
        "DEFINE INDEX idx_supersedes_unique ON supersedes FIELDS in, out UNIQUE",
        "DEFINE TABLE context_for SCHEMAFULL TYPE RELATION IN input_span OUT decision",
        "DEFINE FIELD relevance_score ON context_for TYPE float",
        "DEFINE FIELD reason          ON context_for TYPE string DEFAULT ''",
        "DEFINE FIELD state           ON context_for TYPE string "
        "ASSERT $value IN ['proposed', 'confirmed', 'rejected'] DEFAULT 'proposed'",
        "DEFINE FIELD created_at      ON context_for TYPE datetime DEFAULT time::now()",
        "DEFINE INDEX idx_ctx_unique ON context_for FIELDS in, out UNIQUE",
        # Proposal infrastructure (AI does not write here yet)
        "DEFINE TABLE graph_proposal SCHEMAFULL",
        "DEFINE FIELD proposal_type ON graph_proposal TYPE string "
        "ASSERT $value IN ['context_for', 'supersedes', 'related_to', 'contradicts']",
        "DEFINE FIELD from_id       ON graph_proposal TYPE string",
        "DEFINE FIELD to_id         ON graph_proposal TYPE string",
        "DEFINE FIELD reason        ON graph_proposal TYPE string DEFAULT ''",
        "DEFINE FIELD confidence    ON graph_proposal TYPE float",
        "DEFINE FIELD state         ON graph_proposal TYPE string "
        "ASSERT $value IN ['pending', 'approved', 'rejected', 'auto_approved'] DEFAULT 'pending'",
        "DEFINE FIELD session_id    ON graph_proposal TYPE string DEFAULT ''",
        "DEFINE FIELD created_at    ON graph_proposal TYPE datetime DEFAULT time::now()",
        "DEFINE FIELD reviewed_at   ON graph_proposal TYPE option<datetime> DEFAULT NONE",
        # Expanded status ASSERT (v6→v7 era; narrowed again in v10)
        "DEFINE FIELD status ON decision TYPE string DEFAULT 'ungrounded' "
        "ASSERT $value IN ['reflected', 'drifted', 'pending', 'ungrounded', "
        "'proposal', 'superseded', 'context_pending']",
        # Note: v10 migration tightens this to ['reflected','drifted','pending','ungrounded']
    ]
    for sql in new_stmts:
        await _execute_define_idempotent(client, sql.strip())
    logger.info("[migration] v6 → v7: HITL edge tables and graph_proposal defined")


async def _migrate_v7_to_v8(client: LedgerClient) -> None:
    """v7 → v8: Add ephemeral field to compliance_check.

    Additive only — no data loss. Backfills existing records to ephemeral=false
    so queries using WHERE ephemeral = false continue to include all pre-v8 rows.
    """
    new_stmts = [
        "DEFINE FIELD ephemeral ON compliance_check TYPE bool DEFAULT false",
        "DEFINE INDEX idx_cc_ephemeral ON compliance_check FIELDS ephemeral",
    ]
    for sql in new_stmts:
        await _execute_define_idempotent(client, sql.strip())

    try:
        await client.execute("UPDATE compliance_check SET ephemeral = false WHERE ephemeral = NONE")
        logger.info(
            "[migration] v7 → v8: backfilled compliance_check.ephemeral = false on existing rows"
        )
    except Exception as exc:
        logger.warning("[migration] v7 → v8: backfill failed (non-fatal): %s", exc)

    logger.info("[migration] v7 → v8: ephemeral field added to compliance_check")


async def _migrate_v8_to_v9(client: LedgerClient) -> None:
    """v8 → v9: Add decision_level and parent_decision_id to decision table.

    Additive only — no data loss. Existing decisions get NULL for both fields
    (the DEFAULT NONE handles this automatically at query time).
    """
    new_stmts = [
        "DEFINE FIELD decision_level ON decision TYPE option<string> DEFAULT NONE "
        "ASSERT $value = NONE OR $value IN ['L1', 'L2', 'L3']",
        "DEFINE FIELD parent_decision_id ON decision TYPE option<string> DEFAULT NONE",
    ]
    for sql in new_stmts:
        await _execute_define_idempotent(client, sql.strip())

    logger.info("[migration] v8 → v9: decision_level and parent_decision_id added")


async def _migrate_v9_to_v10(client: LedgerClient) -> None:
    """v9 → v10: Decouple signoff state from status.

    Before: status ∈ {reflected, drifted, pending, ungrounded, proposal,
                      superseded, context_pending}
    After:  status ∈ {reflected, drifted, pending, ungrounded}  (code-compliance only)
            signoff.state carries: proposed | ratified | rejected | collision_pending
                                   | context_pending | superseded

    Migration steps:
    1. Superseded decisions: write signoff.state='superseded' (these had no signoff
       written by resolve_collision — it only set status). Then set status='ungrounded'
       (retired from drift tracking).
    2. Decisions whose status was 'proposal' or 'context_pending' (written by the old
       project_decision_status short-circuits): reset to 'ungrounded'. Their correct
       code-compliance status will be re-derived on the next drift sweep.
    3. Tighten the ASSERT constraint on the status field.
    """
    from datetime import datetime

    _now = datetime.now(UTC).isoformat()

    # Step 1: superseded decisions — move superseded into signoff
    superseded_rows = await client.query(
        "SELECT type::string(id) AS id, signoff FROM decision WHERE status = 'superseded'"
    )
    migrated_superseded = 0
    for row in superseded_rows or []:
        decision_id = row.get("id", "")
        existing_signoff = row.get("signoff") or {}
        if not decision_id:
            continue
        # Only write if signoff.state isn't already superseded
        if isinstance(existing_signoff, dict) and existing_signoff.get("state") == "superseded":
            pass
        else:
            new_signoff = dict(existing_signoff) if isinstance(existing_signoff, dict) else {}
            new_signoff["state"] = "superseded"
            new_signoff["superseded_at"] = _now
            await client.execute(
                f"UPDATE {decision_id} SET signoff = $s",
                {"s": new_signoff},
            )
        await client.execute(
            f"UPDATE {decision_id} SET status = 'ungrounded'",
        )
        migrated_superseded += 1

    # Step 2: reset 'proposal' and 'context_pending' status to 'ungrounded'
    # (their signoff already carries the right state; the status field was a
    # projection artifact of the old project_decision_status short-circuits)
    await client.execute(
        "UPDATE decision SET status = 'ungrounded' WHERE status IN ['proposal', 'context_pending']"
    )

    # Step 3: tighten ASSERT
    await _execute_define_idempotent(
        client,
        "DEFINE FIELD status ON decision TYPE string DEFAULT 'ungrounded' "
        "ASSERT $value IN ['reflected', 'drifted', 'pending', 'ungrounded']",
    )

    logger.info(
        "[migration] v9 → v10: signoff/status decoupled; "
        "%d superseded decisions migrated; proposal/context_pending → ungrounded",
        migrated_superseded,
    )


async def _migrate_v10_to_v11(client: LedgerClient) -> None:
    """v10 → v11: Add CodeGenome identity tables and edges (#59).

    Additive only — no data loss. Defines new tables (``code_subject``,
    ``subject_identity``, ``subject_version``) and edges (``has_identity``,
    ``has_version``, ``about``). Writes to these tables are gated by the
    ``codegenome.write_identity_records`` feature flag at the handler
    boundary, so toggling the flag does not require another migration.
    """
    new_stmts = [
        # Tables
        "DEFINE TABLE code_subject SCHEMAFULL",
        "DEFINE FIELD kind               ON code_subject TYPE string",
        "DEFINE FIELD canonical_name     ON code_subject TYPE string",
        "DEFINE FIELD repo_ref           ON code_subject TYPE option<string>",
        "DEFINE FIELD current_confidence ON code_subject TYPE float "
        "ASSERT $value >= 0 AND $value <= 1",
        "DEFINE FIELD created_at         ON code_subject TYPE datetime DEFAULT time::now()",
        "DEFINE FIELD updated_at         ON code_subject TYPE datetime DEFAULT time::now()",
        "DEFINE INDEX idx_code_subject_canonical "
        "ON code_subject FIELDS kind, canonical_name UNIQUE",
        "DEFINE TABLE subject_identity SCHEMAFULL",
        "DEFINE FIELD address              ON subject_identity TYPE string",
        "DEFINE FIELD identity_type        ON subject_identity TYPE string",
        "DEFINE FIELD structural_signature ON subject_identity TYPE option<string>",
        "DEFINE FIELD behavioral_signature ON subject_identity TYPE option<string>",
        "DEFINE FIELD signature_hash       ON subject_identity TYPE option<string>",
        "DEFINE FIELD content_hash         ON subject_identity TYPE option<string>",
        "DEFINE FIELD confidence           ON subject_identity TYPE float "
        "ASSERT $value >= 0 AND $value <= 1",
        "DEFINE FIELD model_version        ON subject_identity TYPE string",
        "DEFINE FIELD created_at           ON subject_identity TYPE datetime DEFAULT time::now()",
        "DEFINE INDEX idx_subject_identity_address ON subject_identity FIELDS address UNIQUE",
        "DEFINE TABLE subject_version SCHEMAFULL",
        "DEFINE FIELD repo_ref       ON subject_version TYPE string",
        "DEFINE FIELD file_path      ON subject_version TYPE string",
        "DEFINE FIELD start_line     ON subject_version TYPE int",
        "DEFINE FIELD end_line       ON subject_version TYPE int",
        "DEFINE FIELD symbol_name    ON subject_version TYPE option<string>",
        "DEFINE FIELD symbol_kind    ON subject_version TYPE option<string>",
        "DEFINE FIELD content_hash   ON subject_version TYPE option<string>",
        "DEFINE FIELD signature_hash ON subject_version TYPE option<string>",
        "DEFINE FIELD created_at     ON subject_version TYPE datetime DEFAULT time::now()",
        "DEFINE INDEX idx_subject_version_loc "
        "ON subject_version FIELDS repo_ref, file_path, start_line, end_line",
        # Edges
        "DEFINE TABLE has_identity SCHEMAFULL TYPE RELATION IN code_subject OUT subject_identity",
        "DEFINE FIELD confidence ON has_identity TYPE float ASSERT $value >= 0 AND $value <= 1",
        "DEFINE FIELD created_at ON has_identity TYPE datetime DEFAULT time::now()",
        "DEFINE INDEX idx_has_identity_unique ON has_identity FIELDS in, out UNIQUE",
        "DEFINE TABLE has_version SCHEMAFULL TYPE RELATION IN code_subject OUT subject_version",
        "DEFINE FIELD confidence ON has_version TYPE float ASSERT $value >= 0 AND $value <= 1",
        "DEFINE FIELD created_at ON has_version TYPE datetime DEFAULT time::now()",
        "DEFINE INDEX idx_has_version_unique ON has_version FIELDS in, out UNIQUE",
        "DEFINE TABLE about SCHEMAFULL TYPE RELATION IN decision OUT code_subject",
        "DEFINE FIELD confidence ON about TYPE float ASSERT $value >= 0 AND $value <= 1",
        "DEFINE FIELD created_at ON about TYPE datetime DEFAULT time::now()",
        "DEFINE INDEX idx_about_unique ON about FIELDS in, out UNIQUE",
    ]
    for sql in new_stmts:
        await _execute_define_idempotent(client, sql.strip())
    logger.info("[migration] v10 → v11: CodeGenome identity tables and edges defined")


# Registry: version → migration function that brings DB from version-1 to version.
# Pre-v4 migrations are removed; DBs older than v4 must be reset.
async def _migrate_v11_to_v12(client: LedgerClient) -> None:
    """v11 → v12: Add CodeGenome continuity infrastructure (#60).

    Additive only — no data loss. Defines the new ``identity_supersedes``
    edge table and adds a nullable ``neighbors_at_bind`` field to
    ``subject_identity``. Existing rows have ``neighbors_at_bind = None``;
    Phase 3's continuity matcher gracefully degrades for them (Jaccard
    signal contributes zero, remaining weights renormalize via the
    ``weighted_average`` helper).
    """
    new_stmts = [
        "DEFINE FIELD neighbors_at_bind ON subject_identity TYPE option<array<string>> DEFAULT NONE",
        "DEFINE TABLE identity_supersedes SCHEMAFULL "
        "TYPE RELATION IN subject_identity OUT subject_identity",
        "DEFINE FIELD change_type   ON identity_supersedes TYPE string "
        "ASSERT $value IN ['moved', 'renamed', 'moved_and_renamed']",
        "DEFINE FIELD confidence    ON identity_supersedes TYPE float "
        "ASSERT $value >= 0 AND $value <= 1",
        "DEFINE FIELD evidence_refs ON identity_supersedes TYPE array<string> DEFAULT []",
        "DEFINE FIELD created_at    ON identity_supersedes TYPE datetime DEFAULT time::now()",
        "DEFINE INDEX idx_identity_supersedes_unique ON identity_supersedes FIELDS in, out UNIQUE",
    ]
    for sql in new_stmts:
        await _execute_define_idempotent(client, sql.strip())
    logger.info("[migration] v11 → v12: identity_supersedes edge + neighbors_at_bind field defined")


async def _migrate_v12_to_v13(client: LedgerClient) -> None:
    """v12 → v13: Add FLEXIBLE to binds_to.provenance (#72)."""
    await _execute_define_idempotent(
        client,
        "DEFINE FIELD OVERWRITE provenance ON binds_to FLEXIBLE TYPE object DEFAULT {}",
    )
    logger.info("[migration] v12 → v13: binds_to.provenance redefined as FLEXIBLE")


async def _migrate_v13_to_v14(client: LedgerClient) -> None:
    """v13 → v14: Add CHANGEFEED on compliance_check + semantic_status +
    evidence_refs fields (#61 Phase 4).

    Three additive changes:

    1. Retrofit ``CHANGEFEED 30d INCLUDE ORIGINAL`` on the
       ``compliance_check`` table. Required so caller-LLM verdicts that
       overwrite an auto-resolved cosmetic row remain forensically
       recoverable for 30 days (F1 audit remediation).

    2. Add ``semantic_status`` (nullable string with ASSERT enum
       ``['semantically_preserved', 'semantic_change']``).

    3. Add ``evidence_refs`` (array of strings, default ``[]``).

    All three are additive: existing rows read back ``semantic_status =
    NONE`` and ``evidence_refs = []`` until rewritten. The CHANGEFEED
    retrofit via ``DEFINE TABLE OVERWRITE`` preserves all existing rows.

    Originally numbered v12→v13 in the Phase 4 plan; PR #81 (provenance
    FLEXIBLE) merged claiming v13 first per Obs-V3-1 of the v3 audit,
    so this migration was renumbered v13→v14 during /qor-substantiate.
    """
    new_stmts = [
        "DEFINE TABLE compliance_check SCHEMAFULL CHANGEFEED 30d INCLUDE ORIGINAL",
        "DEFINE FIELD semantic_status ON compliance_check "
        "TYPE option<string> DEFAULT NONE "
        "ASSERT $value = NONE OR $value IN ['semantically_preserved', 'semantic_change']",
        "DEFINE FIELD evidence_refs ON compliance_check TYPE array<string> DEFAULT []",
    ]
    for sql in new_stmts:
        await _execute_define_idempotent(client, _with_overwrite(sql))
    logger.info(
        "[migration] v13 → v14: compliance_check changefeed retrofitted; "
        "semantic_status + evidence_refs fields defined"
    )


async def _migrate_v14_to_v15(client: LedgerClient) -> None:
    """v14 → v15: Add optional governance metadata to decision (#109).

    Single additive change: ``decision.governance`` flexible-object
    field defaulting to NONE. Pre-v15 rows read back ``governance =
    NONE`` and fall through to ``derive_governance_metadata`` defaults
    at engine evaluation time.

    FLEXIBLE is required so nested keys (decision_class, risk_class,
    escalation_class, owner, supervisor, notification_channels,
    protected_component, review_after) survive SurrealDB v2's nested-
    key stripping for plain TYPE object — same lesson as binds_to
    provenance (#72).
    """
    await _execute_define_idempotent(
        client,
        "DEFINE FIELD OVERWRITE governance ON decision FLEXIBLE TYPE option<object> DEFAULT NONE",
    )
    logger.info("[migration] v14 → v15: decision.governance field added")


async def _migrate_v15_to_v16(client: LedgerClient) -> None:
    """v15 → v16: Introduce bicameral_meta table for wire-format sentinel (#252 Layer 2).

    No data migration required — the bicameral_meta DEFINEs are applied
    via init_schema's OVERWRITE pass on every connect (see _BICAMERAL_META
    constant). The first-write value is populated by
    ``_write_wire_format_sentinel`` at the end of ``adapter.connect()``.
    Existing v15 ledgers transitioning to v16 will record the upgrading
    binary's surrealdb-py version as the ``at_first_write`` because we
    have no archaeological record of which version originally wrote them.

    The migration body is intentionally empty; the registry entry exists
    so the migration loop in ``migrate(client)`` sees v15→v16 as a known
    forward path (avoids ``SchemaVersionTooNew`` on existing v15 ledgers
    when v16-aware code starts).
    """
    return


async def _migrate_v16_to_v17(client: LedgerClient) -> None:
    """v16 → v17: Re-run the yields integrity cleanup (#296 follow-up).

    The v4 → v5 cleanup (``_migrate_v4_to_v5``) was the last reachable
    pass that purged v3-era ``source_span:*`` rows from the ``yields``
    table. Any DB whose ``schema_meta.version`` rolled past 5 with the
    corruption still present is permanently broken on the v4→v5 boundary
    — ``migrate()`` only iterates ``range(current+1, SCHEMA_VERSION+1)``,
    so historical migrations are unreachable.

    This migration re-runs the same yields cleanup body. It is a no-op on
    a clean DB (zero deletions, idempotent index re-apply). It exists to
    cover any operator whose ledger crashes connect() with the type
    mismatch ``yields.in expected a record<input_span>`` because their DB
    holds the legacy rows.

    Symmetric with v4→v5 — both call into
    ``_clean_yields_legacy_rows`` + ``_dedupe_yields`` so the SQL lives
    in one place. Add a new fixture under
    ``tests/fixtures/legacy_ledgers/`` for any future row-shape we
    discover; the registry-driven test parametrizes over it.
    """
    await _clean_yields_legacy_rows(client, log_tag="v16 → v17")
    await _dedupe_yields(client, log_tag="v16 → v17")
    await _execute_define_idempotent(
        client,
        "DEFINE INDEX idx_yields_unique ON yields FIELDS in, out UNIQUE",
    )


async def _write_wire_format_sentinel(
    client: LedgerClient,
) -> tuple[str | None, str | None, str]:
    """Read and update the ``bicameral_meta`` row with the running surrealdb-py version.

    Returns ``(recorded, running, status)`` where ``status`` is one of
    ``"first-write"`` (no prior recorded version), ``"match"`` (recorded
    equals running), or ``"drift"`` (recorded differs from running).

    Side effects: updates ``surrealdb_client_version_at_last_write`` and
    ``last_write_at`` on the singleton ``bicameral_meta`` row. Sets
    ``surrealdb_client_version_at_first_write`` only when it was previously
    NONE (immutable after first set). If the table has no row yet (fresh
    ledger), CREATEs the singleton row with both first/last fields set to
    the running version.

    The caller (``adapter.connect``) is responsible for emitting the
    audit-log event based on the returned status; this helper does not
    import audit_log to keep the ledger module's dependency surface tight.
    """
    import importlib.metadata

    try:
        running = importlib.metadata.version("surrealdb")
    except importlib.metadata.PackageNotFoundError:
        running = "unknown"

    rows = await client.query("SELECT * FROM bicameral_meta LIMIT 1")
    if not rows:
        await client.query(
            "CREATE bicameral_meta SET "
            "surrealdb_client_version_at_first_write = $running, "
            "surrealdb_client_version_at_last_write = $running, "
            "last_write_at = time::now()",
            {"running": running},
        )
        return None, running, "first-write"

    row = rows[0]
    recorded = row.get("surrealdb_client_version_at_last_write")
    first = row.get("surrealdb_client_version_at_first_write")

    if first is None:
        await client.query(
            "UPDATE bicameral_meta SET "
            "surrealdb_client_version_at_first_write = $running, "
            "surrealdb_client_version_at_last_write = $running, "
            "last_write_at = time::now()",
            {"running": running},
        )
        return recorded, running, "first-write"

    await client.query(
        "UPDATE bicameral_meta SET "
        "surrealdb_client_version_at_last_write = $running, "
        "last_write_at = time::now()",
        {"running": running},
    )

    if recorded == running:
        return recorded, running, "match"
    return recorded, running, "drift"


_MIGRATIONS: dict[int, ...] = {
    5: _migrate_v4_to_v5,
    6: _migrate_v5_to_v6,
    7: _migrate_v6_to_v7,
    8: _migrate_v7_to_v8,
    9: _migrate_v8_to_v9,
    10: _migrate_v9_to_v10,
    11: _migrate_v10_to_v11,
    12: _migrate_v11_to_v12,
    13: _migrate_v12_to_v13,
    14: _migrate_v13_to_v14,
    15: _migrate_v14_to_v15,
    16: _migrate_v15_to_v16,
    17: _migrate_v16_to_v17,
}


async def _get_schema_version(client: LedgerClient) -> int:
    """Read current schema version from DB. Returns 0 if no version tracked."""
    rows = await client.query("SELECT version FROM schema_meta LIMIT 1")
    if rows and rows[0].get("version") is not None:
        return int(rows[0]["version"])
    return 0


async def _set_schema_version(client: LedgerClient, version: int) -> None:
    """Upsert the schema version in schema_meta."""
    await client.execute("DELETE FROM schema_meta")
    await client.execute(
        "CREATE schema_meta SET version = $v, migrated_at = time::now()",
        {"v": version},
    )


async def migrate(client: LedgerClient, allow_destructive: bool = False) -> None:
    """Run any pending migrations to bring the DB up to SCHEMA_VERSION.

    Called after init_schema() in adapter.connect(). Safe to call repeatedly.

    Raises:
        SchemaVersionTooNew: DB schema is ahead of the code — upgrade the binary.
        DestructiveMigrationRequired: A pending step drops data and
            allow_destructive=False. Call with allow_destructive=True (via
            bicameral_reset confirm=True) to proceed.
    """
    current = await _get_schema_version(client)

    if current == SCHEMA_VERSION:
        return

    if current > SCHEMA_VERSION:
        required_ver = SCHEMA_COMPATIBILITY.get(current, "unknown")
        raise SchemaVersionTooNew(
            f"DB schema v{current} requires bicameral-mcp>={required_ver}; "
            f"you're running schema v{SCHEMA_VERSION}. "
            f"Upgrade: pipx upgrade bicameral-mcp"
        )

    logger.info(
        "[migration] Schema version %d → %d (%d migration(s) to apply)",
        current,
        SCHEMA_VERSION,
        SCHEMA_VERSION - current,
    )

    for target_version in range(current + 1, SCHEMA_VERSION + 1):
        fn = _MIGRATIONS.get(target_version)
        if fn is None:
            logger.warning("[migration] No migration function for version %d", target_version)
            continue
        if target_version in DESTRUCTIVE_MIGRATIONS and not allow_destructive:
            raise DestructiveMigrationRequired(
                f"schema v{target_version - 1}→v{target_version} is a breaking migration "
                f"that drops legacy data. Call bicameral_reset(confirm=True) to proceed."
            )
        await fn(client)
        await _set_schema_version(client, target_version)

    logger.info("[migration] Schema migrated to version %d", SCHEMA_VERSION)
