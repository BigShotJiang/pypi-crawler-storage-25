"""Configuration for TgrEzLi. Uses TgrezliConfig from types."""

from TgrEzLi.types import TgrezliConfig

__all__ = ["TgrezliConfig"]
