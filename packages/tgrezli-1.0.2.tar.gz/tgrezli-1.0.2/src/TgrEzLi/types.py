"""Type definitions and data structures for TgrEzLi."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, TypedDict

# --- Config (nested dict for TEL) ---


class ConnectionConfig(TypedDict, total=False):
    """Token and chats; if present in TgrEzLiConfig, connect() is called in __init__."""

    token: str
    chats: dict[str, str]


class LoggingConfig(TypedDict, total=False):
    """Logging options. save_log_file replaces save_log; default False."""

    debug: bool
    save_log_file: bool
    log_file_path: str


class ApiServerConfig(TypedDict, total=False):
    """Embedded API server host and port."""

    host: str
    port: int


class TgrEzLiConfig(TypedDict, total=False):
    """Full config for TEL(). All keys optional. .connect() remains available."""

    connection: ConnectionConfig
    logging: LoggingConfig
    api_server: ApiServerConfig


@dataclass(frozen=False)
class TgrezliConfig:
    """Legacy flat config (backward compat). Prefer TgrEzLiConfig dict."""

    save_log: bool = True
    log_file: str = "TgrEzLi.log"
    api_host: str = "localhost"
    api_port: int = 9999


# --- Handler payloads (internal; passed from core to user via thread-local) ---


@dataclass
class TgMsgData:
    """Payload for onMessage handlers."""

    text: str
    msg_id: int | None
    chat_id: str
    user_id: int | None
    user_name: str | None
    timestamp: Any
    raw_update: Any

    @property
    def msgId(self) -> int | None:
        return self.msg_id

    @property
    def chatId(self) -> str:
        return self.chat_id

    @property
    def userId(self) -> int | None:
        return self.user_id

    @property
    def userName(self) -> str | None:
        return self.user_name


@dataclass
class TgCmdData:
    """Payload for onCommand handlers."""

    command: str
    args: str
    msg_id: int | None
    chat_id: str
    user_id: int | None
    user_name: str | None
    timestamp: Any
    raw_update: Any

    @property
    def msgId(self) -> int | None:
        return self.msg_id

    @property
    def chatId(self) -> str:
        return self.chat_id

    @property
    def userId(self) -> int | None:
        return self.user_id

    @property
    def userName(self) -> str | None:
        return self.user_name


@dataclass
class TgCbData:
    """Payload for onCallback handlers."""

    text: str | None
    value: str
    msg_id: int | None
    chat_id: str
    user_id: int | None
    user_name: str | None
    timestamp: Any
    raw_update: Any

    @property
    def msgId(self) -> int | None:
        return self.msg_id

    @property
    def chatId(self) -> str:
        return self.chat_id

    @property
    def userId(self) -> int | None:
        return self.user_id

    @property
    def userName(self) -> str | None:
        return self.user_name


@dataclass
class TgArgsData:
    """Payload for onApiReq handlers (POST body)."""

    _data: dict[str, Any]

    def get(self, key: str, default: Any = None) -> Any:
        return self._data.get(key, default)
