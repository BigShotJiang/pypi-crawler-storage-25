"""TgrEzLi: Telegram bot library with sync-style API and optional embedded API server."""
from __future__ import annotations

from ezlog import EzLog

from TgrEzLi.core import TEL, __version__
from TgrEzLi.models import TgArgs, TgCb, TgCmd, TgMsg
from TgrEzLi.requests import TReq, TgrezliRequestError
from TgrEzLi.types import TgrEzLiConfig, TgrezliConfig

# Preconfigured ezlog instance for user code (e.g. log.info(), log.success())
log = EzLog()

__all__ = [
    "TEL",
    "TgMsg",
    "TgCmd",
    "TgCb",
    "TgArgs",
    "TReq",
    "TgrEzLiConfig",
    "TgrezliConfig",
    "TgrezliRequestError",
    "log",
    "__version__",
]


def main() -> None:
    """CLI entry point: print version and short usage."""
    print(f"TgrEzLi {__version__}")
    print("Usage: from TgrEzLi import TEL, TgMsg, TgCmd, TgCb, TgArgs, TReq, log")
    print("  bot = TEL(); bot.connect(token, chat_dict); ...")
