"""Tests for apple_jobs.parser — all offline, fixture-based."""

from apple_jobs.parser import extract_raw_jobs, parse_job, parse_page


class TestExtractRawJobs:
    """Tests for the low-level HTML → raw dict extraction."""

    def test_extracts_20_jobs_from_real_page(self, page_1_html: str):
        jobs, total = extract_raw_jobs(page_1_html)
        assert len(jobs) == 20

    def test_total_records_is_positive(self, page_1_html: str):
        _, total = extract_raw_jobs(page_1_html)
        assert total > 0

    def test_each_job_has_required_fields(self, page_1_html: str):
        jobs, _ = extract_raw_jobs(page_1_html)
        for job in jobs:
            assert "positionId" in job
            assert "postingTitle" in job
            assert isinstance(job["positionId"], str)
            assert len(job["postingTitle"]) > 0

    def test_jobs_have_team_info(self, page_1_html: str):
        jobs, _ = extract_raw_jobs(page_1_html)
        for job in jobs:
            assert "team" in job
            assert "teamName" in job["team"]

    def test_jobs_have_locations(self, page_1_html: str):
        jobs, _ = extract_raw_jobs(page_1_html)
        for job in jobs:
            assert "locations" in job
            assert isinstance(job["locations"], list)

    def test_jobs_have_posting_dates(self, page_1_html: str):
        jobs, _ = extract_raw_jobs(page_1_html)
        for job in jobs:
            assert "postDateInGMT" in job or "postingDate" in job

    def test_empty_page_returns_no_jobs(self, empty_html: str):
        jobs, total = extract_raw_jobs(empty_html)
        assert len(jobs) == 0
        assert total == 0

    def test_malformed_page_extracts_partial(self, malformed_html: str):
        jobs, total = extract_raw_jobs(malformed_html)
        # The malformed fixture has a positionId but the object may or
        # may not parse depending on structure. Either 0 or 1 is acceptable.
        assert len(jobs) <= 1


class TestParseJob:
    """Tests for raw dict → AppleJob model mapping."""

    def test_basic_fields(self, page_1_html: str):
        raw_jobs, _ = extract_raw_jobs(page_1_html)
        job = parse_job(raw_jobs[0])
        assert job.position_id
        assert job.title
        assert job.url.startswith("https://jobs.apple.com/")

    def test_team_is_populated(self, page_1_html: str):
        raw_jobs, _ = extract_raw_jobs(page_1_html)
        job = parse_job(raw_jobs[0])
        assert job.team.name

    def test_url_contains_position_id(self, page_1_html: str):
        raw_jobs, _ = extract_raw_jobs(page_1_html)
        job = parse_job(raw_jobs[0])
        assert job.position_id in job.url

    def test_posted_at_is_parsed(self, page_1_html: str):
        raw_jobs, _ = extract_raw_jobs(page_1_html)
        # At least some jobs should have a parseable date
        parsed_dates = [parse_job(r).posted_at for r in raw_jobs]
        assert any(d is not None for d in parsed_dates)

    def test_location_property(self, page_1_html: str):
        raw_jobs, _ = extract_raw_jobs(page_1_html)
        job = parse_job(raw_jobs[0])
        # location property should return a non-empty string
        assert isinstance(job.location, str)

    def test_summary_has_no_raw_html_tags(self, page_1_html: str):
        raw_jobs, _ = extract_raw_jobs(page_1_html)
        for raw in raw_jobs[:5]:
            job = parse_job(raw)
            assert "<" not in job.summary or ">" not in job.summary

    def test_missing_fields_dont_crash(self):
        """Minimal raw dict should still produce a model, not crash."""
        minimal = {
            "positionId": "123",
            "postingTitle": "Test Job",
        }
        job = parse_job(minimal)
        assert job.position_id == "123"
        assert job.title == "Test Job"
        assert job.team.name == ""
        assert job.locations == []
        assert job.url == "https://jobs.apple.com/en-us/details/123"


class TestParsePage:
    """Tests for full-page parsing into AppleJobsPage."""

    def test_page_has_20_jobs(self, page_1_html: str):
        page = parse_page(page_1_html, page_number=1)
        assert len(page.jobs) == 20

    def test_total_records_positive(self, page_1_html: str):
        page = parse_page(page_1_html, page_number=1)
        assert page.total_records > 0

    def test_page_number_is_set(self, page_1_html: str):
        page = parse_page(page_1_html, page_number=3)
        assert page.page == 3

    def test_total_pages_math(self, page_1_html: str):
        page = parse_page(page_1_html, page_number=1)
        expected = (page.total_records + 19) // 20
        assert page.total_pages == expected

    def test_has_next_on_page_1(self, page_1_html: str):
        page = parse_page(page_1_html, page_number=1)
        assert page.has_next is True

    def test_empty_page(self, empty_html: str):
        page = parse_page(empty_html, page_number=1)
        assert len(page.jobs) == 0
        assert page.total_records == 0
        assert page.has_next is False
