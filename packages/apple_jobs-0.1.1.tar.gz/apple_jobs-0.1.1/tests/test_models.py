"""Tests for apple_jobs.models — pure unit tests, no I/O."""

from datetime import datetime, timezone

from apple_jobs.models import AppleJob, AppleJobLocation, AppleJobsPage, AppleJobTeam


class TestAppleJob:

    def _make_job(self, **overrides):
        defaults = dict(
            position_id="12345",
            title="Senior iOS Engineer",
            summary="Build great things.",
            url="https://jobs.apple.com/en-us/details/12345/senior-ios-engineer",
            posted_at=datetime(2026, 4, 11, tzinfo=timezone.utc),
            posting_date="Apr 11, 2026",
            team=AppleJobTeam(name="Software and Services", code="SFTWR"),
            locations=[
                AppleJobLocation(
                    name="Cupertino",
                    country="United States of America",
                    country_id="iso-country-USA",
                )
            ],
            home_office=False,
            weekly_hours=40,
        )
        defaults.update(overrides)
        return AppleJob(**defaults)

    def test_location_property_us(self):
        job = self._make_job()
        assert job.location == "Cupertino"

    def test_location_property_non_us(self):
        job = self._make_job(
            locations=[
                AppleJobLocation(
                    name="London",
                    country="United Kingdom",
                    country_id="iso-country-GBR",
                )
            ]
        )
        assert job.location == "London, United Kingdom"

    def test_location_property_empty(self):
        job = self._make_job(locations=[])
        assert job.location == ""

    def test_is_remote(self):
        assert self._make_job(home_office=True).is_remote is True
        assert self._make_job(home_office=False).is_remote is False

    def test_is_part_time(self):
        assert self._make_job(weekly_hours=20).is_part_time is True
        assert self._make_job(weekly_hours=40).is_part_time is False

    def test_frozen(self):
        job = self._make_job()
        try:
            job.title = "Nope"  # type: ignore[misc]
            assert False, "Should be frozen"
        except AttributeError:
            pass


class TestAppleJobsPage:

    def test_total_pages(self):
        page = AppleJobsPage(jobs=[], total_records=45, page=1)
        assert page.total_pages == 3  # ceil(45/20)

    def test_total_pages_exact(self):
        page = AppleJobsPage(jobs=[], total_records=40, page=1)
        assert page.total_pages == 2

    def test_has_next_true(self):
        page = AppleJobsPage(jobs=[], total_records=100, page=1)
        assert page.has_next is True

    def test_has_next_false_last_page(self):
        page = AppleJobsPage(jobs=[], total_records=40, page=2)
        assert page.has_next is False

    def test_has_next_false_zero(self):
        page = AppleJobsPage(jobs=[], total_records=0, page=1)
        assert page.has_next is False
