"""Public data models for apple-jobs.

These map directly to Apple's server-rendered job data — no
proprietary enrichment, no skill extraction, no scoring. Just the
fields Apple provides, cleaned up into a stable Python API.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional


@dataclass(frozen=True)
class AppleJobLocation:
    """A single location attached to a job posting."""

    name: str
    """Display name (e.g. "Cupertino", "Austin", "London")."""

    country: str
    """Full country name (e.g. "United States of America")."""

    country_id: str
    """Apple's internal country code (e.g. "iso-country-USA")."""

    city: str = ""
    state: str = ""
    metro: str = ""
    region: str = ""


@dataclass(frozen=True)
class AppleJobTeam:
    """The team / department a role belongs to."""

    name: str
    """Human-readable team name (e.g. "Software and Services")."""

    code: str = ""
    """Apple's internal team code (e.g. "SFTWR")."""

    id: str = ""
    """Apple's internal team ID (e.g. "teamsAndSubTeams-SFTWR")."""


@dataclass(frozen=True)
class AppleJob:
    """A single Apple job posting.

    All fields come from Apple's server-rendered search data. No fields
    are inferred, enriched, or scored — what Apple sends is what you get.
    """

    position_id: str
    """Apple's unique position identifier (numeric string)."""

    title: str
    """Job title as posted (e.g. "Senior iOS Engineer, Maps")."""

    summary: str
    """Job description / summary. Usually 2-3 paragraphs. May contain
    light HTML remnants after extraction; consumers should strip if
    needed."""

    url: str
    """Direct URL to the job detail page on jobs.apple.com."""

    posted_at: Optional[datetime]
    """When the job was posted (UTC). Parsed from Apple's ISO 8601
    ``postDateInGMT`` field. None if parsing failed."""

    posting_date: str
    """Human-readable posting date as Apple provides it
    (e.g. "Apr 11, 2026")."""

    team: AppleJobTeam
    """Team / department."""

    locations: List[AppleJobLocation] = field(default_factory=list)
    """One or more locations. Most jobs have one; multi-location
    postings have several."""

    home_office: bool = False
    """True if Apple flags this as a remote/home-office role."""

    weekly_hours: int = 40
    """Standard weekly hours. <40 usually means part-time."""

    req_id: str = ""
    """Requisition ID (e.g. "200656061-3956")."""

    slug: str = ""
    """URL-friendly title slug (e.g. "senior-ios-engineer-maps")."""

    @property
    def location(self) -> str:
        """Convenience: primary location as a simple string."""
        if not self.locations:
            return ""
        loc = self.locations[0]
        if loc.country_id == "iso-country-USA" or not loc.country:
            return loc.name
        return f"{loc.name}, {loc.country}" if loc.name else loc.country

    @property
    def is_remote(self) -> bool:
        """True if Apple flags the role as home-office eligible."""
        return self.home_office

    @property
    def is_part_time(self) -> bool:
        """True if standard weekly hours are below 40."""
        return self.weekly_hours < 40


@dataclass(frozen=True)
class AppleJobsPage:
    """One page of Apple search results."""

    jobs: List[AppleJob]
    """Jobs on this page (up to 20)."""

    total_records: int
    """Total jobs matching the current search (Apple-reported)."""

    page: int
    """Current page number (1-indexed)."""

    @property
    def total_pages(self) -> int:
        """Total pages available, based on 20 jobs/page."""
        return (self.total_records + 19) // 20

    @property
    def has_next(self) -> bool:
        return self.page < self.total_pages
