"""
Minimal CLI for apple-jobs.

Usage:
    python -m apple_jobs                    # show total count
    python -m apple_jobs search "iOS"       # search by keyword
    python -m apple_jobs search --team "Software and Services"
    python -m apple_jobs page 3             # fetch page 3
    python -m apple_jobs dump               # dump all jobs as JSON lines
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict
from datetime import datetime
from typing import Any

from apple_jobs.client import AppleJobsClient


def _json_default(obj: Any) -> Any:
    if isinstance(obj, datetime):
        return obj.isoformat()
    raise TypeError(f"Not serializable: {type(obj)}")


def _job_to_line(job: Any) -> str:
    d = asdict(job)
    return json.dumps(d, default=_json_default, ensure_ascii=False)


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        prog="apple-jobs",
        description="Fetch Apple job listings from jobs.apple.com",
    )
    parser.add_argument(
        "--delay",
        type=float,
        default=0.5,
        help="Seconds between page requests (default: 0.5)",
    )
    sub = parser.add_subparsers(dest="command")

    # search
    search_p = sub.add_parser("search", help="Search jobs by keyword/team/location")
    search_p.add_argument("query", nargs="?", default=None, help="Search text")
    search_p.add_argument("--location", default=None)
    search_p.add_argument("--team", default=None)
    search_p.add_argument("--limit", type=int, default=20)
    search_p.add_argument("--max-pages", type=int, default=50, help="Max pages to scan (default: 50)")
    search_p.add_argument("--json", action="store_true", help="Output as JSON lines")

    # page
    page_p = sub.add_parser("page", help="Fetch a specific page")
    page_p.add_argument("number", type=int, default=1, nargs="?")
    page_p.add_argument("--json", action="store_true")

    # dump
    dump_p = sub.add_parser("dump", help="Dump all jobs as JSON lines")
    dump_p.add_argument("--max-pages", type=int, default=300)

    # count
    sub.add_parser("count", help="Show total job count")

    args = parser.parse_args(argv)

    client = AppleJobsClient(delay=args.delay)

    if args.command is None or args.command == "count":
        total = client.get_total_count()
        print(f"Apple has {total:,} open positions on jobs.apple.com")
        return

    if args.command == "search":
        jobs = client.search(
            query=args.query,
            location=args.location,
            team=args.team,
            limit=args.limit,
            max_pages=args.max_pages,
        )
        if getattr(args, "json", False):
            for job in jobs:
                print(_job_to_line(job))
        else:
            if not jobs:
                print("No matching jobs found.")
                return
            for job in jobs:
                loc = job.location or "Remote" if job.home_office else job.location or "?"
                print(f"  {job.title}")
                print(f"    {job.team.name} · {loc} · {job.posting_date}")
                print(f"    {job.url}")
                print()
            print(f"Showing {len(jobs)} result(s).")

    elif args.command == "page":
        page = client.search_page(args.number)
        if getattr(args, "json", False):
            for job in page.jobs:
                print(_job_to_line(job))
        else:
            print(
                f"Page {page.page}/{page.total_pages} "
                f"({page.total_records:,} total jobs)"
            )
            print()
            for job in page.jobs:
                print(f"  {job.title} — {job.team.name} ({job.location})")
            print()

    elif args.command == "dump":
        count = 0
        for job in client.iter_jobs(max_pages=args.max_pages):
            print(_job_to_line(job))
            count += 1
        print(f"# Dumped {count:,} jobs", file=sys.stderr)


if __name__ == "__main__":
    main()
