"""
apple-jobs — A clean Python client for Apple's career listings.

Fetches, paginates, and normalizes job postings from jobs.apple.com
without a headless browser, API key, or third-party scraping service.

Usage::

    from apple_jobs import AppleJobsClient

    client = AppleJobsClient()
    for job in client.search(query="iOS engineer", location="United States"):
        print(job.title, job.team, job.url)

Apple serves ~4,700 job listings at jobs.apple.com/en-us/search, with
20 per page rendered as escaped JSON in a <script> block. This library
parses that HTML directly — no Selenium, no Playwright, just HTTP GET
+ deterministic extraction.
"""

from apple_jobs.client import AppleJobsClient
from apple_jobs.models import AppleJob, AppleJobsPage
from apple_jobs.exceptions import AppleJobsError, AppleJobsParseError

__all__ = [
    "AppleJobsClient",
    "AppleJob",
    "AppleJobsPage",
    "AppleJobsError",
    "AppleJobsParseError",
]

__version__ = "0.1.1"
