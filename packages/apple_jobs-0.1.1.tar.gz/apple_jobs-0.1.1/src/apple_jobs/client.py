"""
AppleJobsClient — the main public API for fetching Apple job listings.

Handles HTTP transport, pagination, politeness delays, and retries.
Returns clean AppleJob / AppleJobsPage models. No headless browser,
no API key, no third-party service.

Usage::

    from apple_jobs import AppleJobsClient

    client = AppleJobsClient()

    # Search with filters
    for job in client.search(query="swift", location="United States"):
        print(job.title, job.location, job.url)

    # Get a single page
    page = client.search_page(page=1)
    print(f"{page.total_records} total jobs, page {page.page}/{page.total_pages}")

    # Iterate all jobs (auto-paginates)
    for job in client.iter_jobs():
        print(job.title)
"""

from __future__ import annotations

import logging
import time
from typing import Iterator, List, Optional

import httpx

from apple_jobs.exceptions import AppleJobsError, AppleJobsHTTPError
from apple_jobs.models import AppleJob, AppleJobsPage
from apple_jobs.parser import parse_page

logger = logging.getLogger(__name__)

SEARCH_URL = "https://jobs.apple.com/en-us/search"
DEFAULT_DELAY = 0.5  # seconds between page requests
DEFAULT_RETRIES = 3
DEFAULT_TIMEOUT = 30.0
USER_AGENT = "apple-jobs-client/0.1 (Python; +https://github.com/seekerscore/apple-jobs)"


class AppleJobsClient:
    """Synchronous client for Apple's career job listings.

    Args:
        delay: Seconds between page fetches (default 0.5). Apple doesn't
            document rate limits but their CDN will 429 aggressive clients.
        retries: Number of retries per failed request (default 3).
        timeout: HTTP request timeout in seconds (default 30).
        user_agent: Custom User-Agent header. Defaults to a polite
            identifier with a project URL.
    """

    def __init__(
        self,
        *,
        delay: float = DEFAULT_DELAY,
        retries: int = DEFAULT_RETRIES,
        timeout: float = DEFAULT_TIMEOUT,
        user_agent: str = USER_AGENT,
    ):
        self.delay = delay
        self.retries = retries
        self._client = httpx.Client(
            timeout=timeout,
            headers={"User-Agent": user_agent},
            follow_redirects=True,
        )

    def __enter__(self) -> "AppleJobsClient":
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def _fetch_page_html(self, page: int) -> str:
        """Fetch raw HTML for a search page with retry."""
        last_err: Optional[Exception] = None
        for attempt in range(self.retries):
            try:
                resp = self._client.get(
                    SEARCH_URL,
                    params={"page": str(page)},
                )
                if resp.status_code == 200:
                    return resp.text
                if resp.status_code >= 500:
                    last_err = AppleJobsHTTPError(resp.status_code)
                    if attempt < self.retries - 1:
                        time.sleep(self.delay * (attempt + 1))
                    continue
                raise AppleJobsHTTPError(resp.status_code)
            except httpx.HTTPError as e:
                last_err = AppleJobsError(f"HTTP error on page {page}: {e}")
                if attempt < self.retries - 1:
                    time.sleep(self.delay * (attempt + 1))
                continue
        raise last_err or AppleJobsError(f"Failed to fetch page {page}")

    def search_page(self, page: int = 1) -> AppleJobsPage:
        """Fetch a single page of Apple job results.

        Args:
            page: Page number (1-indexed). Each page has up to 20 jobs.

        Returns:
            AppleJobsPage with jobs and pagination metadata.

        Raises:
            AppleJobsError: On network or parsing failure.
        """
        html = self._fetch_page_html(page)
        return parse_page(html, page_number=page)

    def search(
        self,
        *,
        query: Optional[str] = None,
        location: Optional[str] = None,
        team: Optional[str] = None,
        limit: int = 100,
        max_pages: int = 300,
    ) -> List[AppleJob]:
        """Search Apple jobs and return up to ``limit`` results.

        Note: Apple's search page does not support server-side text
        filtering via URL params for arbitrary queries. This method
        fetches pages and filters client-side when ``query`` is provided.
        ``location`` and ``team`` also filter client-side.

        For unfiltered bulk access, use :meth:`iter_jobs` instead.

        Args:
            query: Text to match against title + summary (case-insensitive).
            location: Text to match against location name (case-insensitive).
            team: Text to match against team name (case-insensitive).
            limit: Maximum jobs to return (default 100).
            max_pages: Safety cap on pages to fetch (default 300). Prevents
                runaway pagination when searching for rare terms across a
                large corpus. Set lower for faster searches.

        Returns:
            List of matching AppleJob instances.
        """
        results: List[AppleJob] = []
        q_lower = query.lower() if query else None
        loc_lower = location.lower() if location else None
        team_lower = team.lower() if team else None

        for job in self.iter_jobs(max_pages=max_pages):
            # Client-side filtering
            if q_lower:
                haystack = f"{job.title} {job.summary}".lower()
                if q_lower not in haystack:
                    continue
            if loc_lower:
                job_loc = job.location.lower()
                if loc_lower not in job_loc:
                    # Also check all location names
                    if not any(loc_lower in l.name.lower() for l in job.locations):
                        if not any(loc_lower in l.country.lower() for l in job.locations):
                            continue
            if team_lower:
                if team_lower not in job.team.name.lower():
                    continue

            results.append(job)
            if len(results) >= limit:
                break

        return results

    def iter_jobs(self, *, max_pages: int = 300) -> Iterator[AppleJob]:
        """Iterate over ALL Apple job listings, auto-paginating.

        Yields one AppleJob at a time. Handles pagination transparently.
        Respects the politeness delay between page requests.

        Args:
            max_pages: Safety cap on pages to fetch (default 300 = 6000 jobs).

        Yields:
            AppleJob instances in the order Apple returns them (newest first
            by default).
        """
        for page_num in range(1, max_pages + 1):
            try:
                page = self.search_page(page_num)
            except AppleJobsError as e:
                logger.warning(f"Failed to fetch page {page_num}: {e}")
                return

            if not page.jobs:
                return

            yield from page.jobs

            if not page.has_next:
                return

            if page_num < max_pages:
                time.sleep(self.delay)

    def get_total_count(self) -> int:
        """Get the total number of Apple job listings currently available.

        Fetches just page 1 and reads the ``totalRecords`` field.

        Returns:
            Total job count as reported by Apple.
        """
        page = self.search_page(1)
        return page.total_records
