"""
HTML parser for Apple's career search pages.

Extracted from production Seeker ingestion (services/ingestion/sources/apple.py).
The core extraction logic (_extract_jobs_from_html, _unescape_js_string) is
copied directly — it is battle-tested against Apple's actual HTML and handles:

  - Double-escaped JSON (JSON inside a JS string inside a <script> block)
  - JS-specific escape sequences (line continuations, hex escapes, single quotes)
  - Bracket-walking to isolate individual job objects from a larger state tree
  - totalRecords extraction for pagination termination

This module has ZERO dependencies on Seeker internals. It operates on raw HTML
strings and returns plain Python dicts.
"""

import json
import re
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from apple_jobs.exceptions import AppleJobsParseError
from apple_jobs.models import (
    AppleJob,
    AppleJobLocation,
    AppleJobsPage,
    AppleJobTeam,
)


def _unescape_js_string(s: str) -> str:
    """Unescape a JavaScript string literal into valid JSON-parseable text.

    Apple embeds job data as escaped JSON inside a JS string inside a
    <script> block — double-escaped. The server uses JS string escapes
    that are not all valid JSON escapes, so we need a thorough unescape
    pass BEFORE json.loads can parse individual objects.
    """
    # Placeholder for real backslashes so later passes don't double-decode.
    result = s.replace("\\\\", "\x00BACKSLASH\x00")
    result = result.replace('\\"', '"')
    result = result.replace("\\/", "/")
    result = result.replace("\\n", "\n")
    result = result.replace("\\r", "\r")
    result = result.replace("\\t", "\t")
    result = result.replace("\\'", "'")
    # JS line continuations: backslash + literal newline → remove both
    result = result.replace("\\\n", "")
    result = result.replace("\\\r\n", "")
    # Hex escapes \xNN → character
    result = re.sub(
        r"\\x([0-9a-fA-F]{2})",
        lambda m: chr(int(m.group(1), 16)),
        result,
    )
    # Any remaining unrecognized \X → just X (strip the backslash)
    result = re.sub(r"\\([^u])", r"\1", result)
    # Restore real backslashes
    result = result.replace("\x00BACKSLASH\x00", "\\")
    return result


def extract_raw_jobs(html: str) -> Tuple[List[Dict[str, Any]], int]:
    """Extract raw job dicts and total record count from Apple search HTML.

    Args:
        html: Full HTML response from ``jobs.apple.com/en-us/search?page=N``

    Returns:
        (list of raw Apple job dicts, total_records)

    Raises:
        AppleJobsParseError: If the expected script block is not found
            (likely means Apple changed their site structure).
    """
    # Find the large script block containing job data
    scripts = re.findall(r"<script[^>]*>(.*?)</script>", html, re.DOTALL)
    target: Optional[str] = None
    for s in scripts:
        if "postingTitle" in s and len(s) > 10000:
            target = s
            break

    if target is None:
        # Could be an empty results page (legitimate) or a site change
        return [], 0

    unesc = _unescape_js_string(target)

    # Extract totalRecords
    total_records = 0
    total_match = re.search(r'"totalRecords":(\d+)', unesc)
    if total_match:
        total_records = int(total_match.group(1))

    # Find each job object by locating positionId occurrences and
    # bracket-walking to extract the enclosing {...} object.
    jobs: List[Dict[str, Any]] = []
    for m in re.finditer(r'"positionId":"(\d+)"', unesc):
        pos = m.start()

        # Walk backwards to find the opening {
        depth = 0
        start = pos
        while start > 0:
            start -= 1
            ch = unesc[start]
            if ch == "}":
                depth += 1
            elif ch == "{":
                if depth == 0:
                    break
                depth -= 1

        # Walk forwards from start to find matching closing }
        depth = 0
        end = start
        while end < len(unesc):
            ch = unesc[end]
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    end += 1
                    break
            end += 1

        obj_str = unesc[start:end]
        try:
            obj = json.loads(obj_str)
            if obj.get("positionId") and obj.get("postingTitle"):
                jobs.append(obj)
        except (json.JSONDecodeError, ValueError):
            continue

    return jobs, total_records


def parse_job(raw: Dict[str, Any]) -> AppleJob:
    """Convert a raw Apple job dict into an AppleJob model.

    This is a clean mapping — no enrichment, no scoring, no skill
    extraction. Just Apple's data in a stable Python shape.
    """
    position_id = str(raw.get("positionId") or "")
    title = raw.get("postingTitle", "") or ""
    summary = raw.get("jobSummary", "") or ""

    # Strip stray HTML from summary
    summary = re.sub(r"<[^>]+>", " ", summary)
    summary = re.sub(r"\s+", " ", summary).strip()

    slug = raw.get("transformedPostingTitle", "") or ""
    if position_id and slug:
        url = f"https://jobs.apple.com/en-us/details/{position_id}/{slug}"
    elif position_id:
        url = f"https://jobs.apple.com/en-us/details/{position_id}"
    else:
        url = ""

    # Parse posted date (ISO 8601 from postDateInGMT)
    posted_at: Optional[datetime] = None
    date_str = raw.get("postDateInGMT") or ""
    if date_str:
        try:
            posted_at = datetime.fromisoformat(
                date_str.replace("Z", "+00:00")
            )
        except (ValueError, TypeError):
            pass
    if posted_at is None:
        # Fall back to human-readable postingDate
        posting_date_str = raw.get("postingDate") or ""
        if posting_date_str:
            for fmt in ("%b %d, %Y", "%B %d, %Y"):
                try:
                    posted_at = datetime.strptime(
                        posting_date_str, fmt
                    ).replace(tzinfo=timezone.utc)
                    break
                except (ValueError, TypeError):
                    continue

    # Team
    team_raw = raw.get("team") or {}
    team = AppleJobTeam(
        name=team_raw.get("teamName") or "",
        code=team_raw.get("teamCode") or "",
        id=team_raw.get("teamID") or "",
    )

    # Locations
    locations: List[AppleJobLocation] = []
    for loc_raw in raw.get("locations") or []:
        locations.append(
            AppleJobLocation(
                name=loc_raw.get("name") or "",
                country=loc_raw.get("countryName") or "",
                country_id=loc_raw.get("countryID") or "",
                city=loc_raw.get("city") or "",
                state=loc_raw.get("stateProvince") or "",
                metro=loc_raw.get("metro") or "",
                region=loc_raw.get("region") or "",
            )
        )

    return AppleJob(
        position_id=position_id,
        title=title,
        summary=summary,
        url=url,
        posted_at=posted_at,
        posting_date=raw.get("postingDate") or "",
        team=team,
        locations=locations,
        home_office=bool(raw.get("homeOffice", False)),
        weekly_hours=int(raw.get("standardWeeklyHours") or 40),
        req_id=raw.get("reqId") or "",
        slug=slug,
    )


def parse_page(html: str, page_number: int = 1) -> AppleJobsPage:
    """Parse a full Apple search page into an AppleJobsPage.

    Args:
        html: Raw HTML from ``jobs.apple.com/en-us/search?page=N``
        page_number: The page number (for metadata; not validated)

    Returns:
        AppleJobsPage with parsed jobs and pagination info
    """
    raw_jobs, total_records = extract_raw_jobs(html)
    jobs = [parse_job(raw) for raw in raw_jobs]
    return AppleJobsPage(
        jobs=jobs,
        total_records=total_records,
        page=page_number,
    )
