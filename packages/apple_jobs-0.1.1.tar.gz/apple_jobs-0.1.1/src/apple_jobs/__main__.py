"""Allow ``python -m apple_jobs`` to invoke the CLI."""

from apple_jobs.cli import main

main()
