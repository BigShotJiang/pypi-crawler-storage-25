"""Exceptions for the apple-jobs client."""


class AppleJobsError(Exception):
    """Base exception for apple-jobs operations."""


class AppleJobsParseError(AppleJobsError):
    """Raised when the HTML structure cannot be parsed.

    This usually means Apple changed their career site markup. If you
    see this, check for a newer version of the library or file an issue.
    """


class AppleJobsHTTPError(AppleJobsError):
    """Raised on non-recoverable HTTP errors from jobs.apple.com."""

    def __init__(self, status_code: int, message: str = ""):
        self.status_code = status_code
        super().__init__(message or f"HTTP {status_code} from jobs.apple.com")
