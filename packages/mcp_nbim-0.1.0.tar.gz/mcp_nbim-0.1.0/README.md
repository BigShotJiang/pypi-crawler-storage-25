# NBIM MCP Server

MCP server for querying data from Norway's [Government Pension Fund Global](https://www.nbim.no/en/) — the world's largest sovereign wealth fund.

## What it does

Provides 6 tools for querying fund data through the Model Context Protocol:

| Tool | Description |
|------|-------------|
| `nbim_fund_value` | Current fund value and asset allocation breakdown |
| `nbim_holdings_search` | Search equity holdings by company, country, or sector |
| `nbim_top_holdings` | Top N holdings by market value with filters |
| `nbim_country_allocation` | Geographic allocation across 70+ countries |
| `nbim_returns` | Annual and cumulative returns since 1998 |
| `nbim_exclusions` | Companies excluded or under observation |

## Install

```bash
pip install mcp-nbim
```

Or with [uvx](https://docs.astral.sh/uv/):

```bash
uvx mcp-nbim
```

## Quick start

```bash
# Run with streamable HTTP (port 8008)
mcp-nbim

# Run with stdio (for Claude Desktop, Claude Code)
mcp-nbim --stdio
```

### Claude Desktop

Add to `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "nbim": {
      "command": "uvx",
      "args": ["mcp-nbim", "--stdio"]
    }
  }
}
```

Or if installed with pip:

```json
{
  "mcpServers": {
    "nbim": {
      "command": "mcp-nbim",
      "args": ["--stdio"]
    }
  }
}
```

### Claude Code

```bash
claude mcp add nbim -- uvx mcp-nbim --stdio
```

### Docker

```bash
docker compose up
```

## Example queries

- "What is the fund worth today?" → `nbim_fund_value()`
- "Top 10 holdings in Japan" → `nbim_top_holdings(n=10, country='JP')`
- "Does the fund own Tesla?" → `nbim_holdings_search(query='Tesla')`
- "How has the US allocation changed?" → compare `nbim_country_allocation()` across years
- "Which companies are excluded for coal?" → `nbim_exclusions(criterion='coal')`
- "Fund performance in 2008" → `nbim_returns(start_year=2008, end_year=2008)`

## Data sources

- **Holdings & fund value:** [NBIM Investment Data API](https://www.nbim.no/en/the-fund/investments/) (JSON, no auth required)
- **Returns:** Scraped from [nbim.no/en/the-fund/returns/](https://www.nbim.no/en/the-fund/returns/) with hardcoded fallback
- **Exclusions:** Scraped from [nbim.no exclusion list](https://www.nbim.no/en/the-fund/responsible-investment/exclusion-of-companies/)

Holdings data updates semi-annually and covers equities (~9,000 companies). Historical data goes back to 1998. No authentication required.

## Related

- [Norges Bank MCP](https://github.com/gervilabs/mcp-nb) — Exchange rates, policy rate, yield curves
- Built by [Gervi Labs](https://gervilabs.com)
