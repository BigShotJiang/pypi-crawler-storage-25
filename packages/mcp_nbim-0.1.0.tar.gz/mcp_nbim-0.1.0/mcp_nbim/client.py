"""HTTP client for NBIM's investment data API and web pages."""

import re
import time
from typing import Any, Callable, Dict, List, Optional

import requests
from bs4 import BeautifulSoup

try:
    from .config import (
        NBIM_API_BASE,
        RETURNS_URL,
        EXCLUSIONS_URL,
        USER_AGENT,
        REQUEST_TIMEOUT_SECONDS,
        CACHE_TTL_INIT,
        CACHE_TTL_HOLDINGS,
        CACHE_TTL_HISTORY,
        CACHE_TTL_RETURNS,
        CACHE_TTL_EXCLUSIONS,
        ANNUAL_RETURNS_FALLBACK,
    )
except ImportError:
    from config import (
        NBIM_API_BASE,
        RETURNS_URL,
        EXCLUSIONS_URL,
        USER_AGENT,
        REQUEST_TIMEOUT_SECONDS,
        CACHE_TTL_INIT,
        CACHE_TTL_HOLDINGS,
        CACHE_TTL_HISTORY,
        CACHE_TTL_RETURNS,
        CACHE_TTL_EXCLUSIONS,
        ANNUAL_RETURNS_FALLBACK,
    )


class _Cache:
    """Simple in-memory cache with per-key TTL."""

    def __init__(self) -> None:
        self._store: Dict[str, tuple] = {}  # key -> (expiry_timestamp, data)

    def get(self, key: str) -> Any:
        entry = self._store.get(key)
        if entry and time.time() < entry[0]:
            return entry[1]
        return None

    def set(self, key: str, value: Any, ttl: int) -> None:
        self._store[key] = (time.time() + ttl, value)

    def get_or_fetch(self, key: str, fetch_fn: Callable, ttl: int) -> Any:
        cached = self.get(key)
        if cached is not None:
            return cached
        value = fetch_fn()
        self.set(key, value, ttl)
        return value


class NBIMClient:
    """Client for NBIM's investment data JSON API and web pages."""

    def __init__(self) -> None:
        self.session = requests.Session()
        self._cache = _Cache()

    def _headers(self) -> Dict[str, str]:
        return {
            "Accept": "application/json",
            "User-Agent": USER_AGENT,
        }

    def _get_json(self, url: str) -> Any:
        resp = self.session.get(
            url, headers=self._headers(), timeout=REQUEST_TIMEOUT_SECONDS
        )
        if not resp.ok:
            raise RuntimeError(
                f"NBIM API error: {resp.status_code} for {url}. {resp.text[:300]}"
            )
        return resp.json()

    def _get_html(self, url: str) -> str:
        headers = {"User-Agent": USER_AGENT}
        resp = self.session.get(url, headers=headers, timeout=REQUEST_TIMEOUT_SECONDS)
        if not resp.ok:
            raise RuntimeError(
                f"NBIM page error: {resp.status_code} for {url}. {resp.text[:300]}"
            )
        return resp.text

    # ------------------------------------------------------------------
    # JSON API methods
    # ------------------------------------------------------------------

    def get_init(self) -> Dict[str, Any]:
        """Fetch init.json: available periods, NAV history, history file ref."""
        return self._cache.get_or_fetch(
            "init",
            lambda: self._get_json(f"{NBIM_API_BASE}/init.json"),
            CACHE_TTL_INIT,
        )

    def get_holdings(self, date: str) -> List[Dict[str, Any]]:
        """Fetch holdings for a specific reporting date (e.g. '2025-12-31').

        Returns the 'data' array from the holdings JSON.
        """
        def fetch():
            result = self._get_json(f"{NBIM_API_BASE}/{date}.json")
            return result.get("data", [])
        return self._cache.get_or_fetch(f"holdings:{date}", fetch, CACHE_TTL_HOLDINGS)

    def get_history(self, date: str) -> List[Dict[str, Any]]:
        """Fetch country allocation history for a reporting date.

        Returns the 'data' array from the history JSON.
        """
        def fetch():
            result = self._get_json(f"{NBIM_API_BASE}/history/{date}.json")
            return result.get("data", [])
        return self._cache.get_or_fetch(f"history:{date}", fetch, CACHE_TTL_HISTORY)

    def get_available_periods(self) -> List[Dict[str, Any]]:
        """Return the list of available reporting periods from init.json."""
        init = self.get_init()
        return init.get("data", {}).get("details", [])

    def get_nav_data(self) -> List[Dict[str, Any]]:
        """Return the NAV array from init.json."""
        init = self.get_init()
        return init.get("data", {}).get("nav", [])

    def get_latest_date(self) -> str:
        """Return the most recent reporting date string (e.g. '2025-12-31')."""
        periods = self.get_available_periods()
        if not periods:
            raise RuntimeError("No reporting periods available from NBIM.")
        return periods[0]["date"][:10]  # "2025-12-31T00:00:00+01:00" -> "2025-12-31"

    def get_history_date(self) -> str:
        """Return the history file date from init.json."""
        init = self.get_init()
        hist = init.get("data", {}).get("history", {})
        return hist.get("date", self.get_latest_date())[:10]

    def get_period_date(self, year: Optional[int] = None) -> str:
        """Resolve a year to the corresponding reporting date string.

        If year is None, returns the most recent period.
        Prefers year-end reports over interim (H1) reports.
        """
        if year is None:
            return self.get_latest_date()

        periods = self.get_available_periods()
        # Prefer non-interim (year-end) for the given year
        for p in periods:
            p_date = p["date"][:10]
            p_year = int(p_date[:4])
            if p_year == year and not p.get("interim", False):
                return p_date
        # Fall back to interim
        for p in periods:
            p_date = p["date"][:10]
            p_year = int(p_date[:4])
            if p_year == year:
                return p_date

        available_years = sorted(set(int(p["date"][:4]) for p in periods), reverse=True)
        raise ValueError(
            f"No data for year {year}. Available years: {available_years[:10]}"
        )

    # ------------------------------------------------------------------
    # Web scraping methods
    # ------------------------------------------------------------------

    def scrape_returns(self) -> Dict[int, float]:
        """Scrape annual returns from the NBIM returns page.

        Returns a dict of {year: return_percentage}.
        Falls back to hardcoded data on failure.
        """
        cached = self._cache.get("returns")
        if cached is not None:
            return cached

        try:
            html = self._get_html(RETURNS_URL)
            returns = self._parse_returns_html(html)
            if returns:
                self._cache.set("returns", returns, CACHE_TTL_RETURNS)
                return returns
        except Exception:
            pass

        # Fallback to hardcoded data
        return ANNUAL_RETURNS_FALLBACK

    def _parse_returns_html(self, html: str) -> Dict[int, float]:
        """Extract annual returns from Highcharts inline JS data.

        The page contains 8 data series. Series 1 (0-indexed) is the total
        annual fund return. Series are ordered sequentially in the HTML:
        all data points for series 0, then all for series 1, etc.
        We detect series boundaries when the year sequence resets.
        """
        pattern = r"Date\.UTC\((\d{4})\s*,\s*\d+\s*,\s*\d+\)\s*,\s*(-?[\d.]+)"
        matches = re.findall(pattern, html)
        if not matches:
            return {}

        # Split matches into series by detecting year resets
        series: List[List[tuple]] = []
        current: List[tuple] = []
        last_year = None
        for year_str, value_str in matches:
            year = int(year_str)
            if last_year is not None and year < last_year:
                series.append(current)
                current = []
            current.append((year, float(value_str)))
            last_year = year
        if current:
            series.append(current)

        # Series 1 is total annual return
        if len(series) < 2:
            return {}

        return {year: value for year, value in series[1]}

    def scrape_exclusions(self) -> List[Dict[str, str]]:
        """Scrape the exclusion/observation list from NBIM.

        Returns a list of dicts with keys:
        company, category, criterion, decision, date
        """
        def fetch():
            html = self._get_html(EXCLUSIONS_URL)
            return self._parse_exclusions_html(html)
        return self._cache.get_or_fetch("exclusions", fetch, CACHE_TTL_EXCLUSIONS)

    def _parse_exclusions_html(self, html: str) -> List[Dict[str, str]]:
        """Parse the exclusion table from HTML.

        The table has 6 columns: Company, (empty), Category, Criterion,
        Decision, Publishing date. We skip the empty second column.
        """
        soup = BeautifulSoup(html, "html.parser")
        records: List[Dict[str, str]] = []

        table = soup.find("table")
        if not table:
            raise RuntimeError("Could not find exclusion table on NBIM page.")

        rows = table.find_all("tr")
        for row in rows[1:]:  # Skip header row
            cells = row.find_all("td")
            if len(cells) < 5:
                continue
            # Column indices: 0=Company, 1=empty, 2=Category, 3=Criterion,
            #                 4=Decision, 5=Publishing date
            record = {
                "company": cells[0].get_text(strip=True),
                "category": cells[2].get_text(strip=True),
                "criterion": cells[3].get_text(strip=True),
                "decision": cells[4].get_text(strip=True),
                "date": cells[5].get_text(strip=True) if len(cells) > 5 else "",
            }
            if record["company"]:
                records.append(record)

        return records
