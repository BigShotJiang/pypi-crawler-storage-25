"""MCP server for NBIM Government Pension Fund Global data."""
