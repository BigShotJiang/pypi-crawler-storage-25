import sys
import traceback

from fastmcp import FastMCP

try:
    from .entry_prompt import nbim_entry_prompt
    from .tools import (
        nbim_fund_value,
        nbim_holdings_search,
        nbim_top_holdings,
        nbim_country_allocation,
        nbim_returns,
        nbim_exclusions,
    )
    from .config import SERVER_PORT
except ImportError:
    from entry_prompt import nbim_entry_prompt
    from tools import (
        nbim_fund_value,
        nbim_holdings_search,
        nbim_top_holdings,
        nbim_country_allocation,
        nbim_returns,
        nbim_exclusions,
    )
    from config import SERVER_PORT


mcp: FastMCP = FastMCP("NBIMServer")

mcp.tool()(nbim_fund_value)
mcp.tool()(nbim_holdings_search)
mcp.tool()(nbim_top_holdings)
mcp.tool()(nbim_country_allocation)
mcp.tool()(nbim_returns)
mcp.tool()(nbim_exclusions)

mcp.prompt()(nbim_entry_prompt)


def main() -> None:
    transport = "stdio" if "--stdio" in sys.argv else "streamable-http"
    print(f"[NBIM MCP] Starting NBIMServer on {transport}...", file=sys.stderr)
    try:
        if transport == "stdio":
            mcp.run("stdio")
        else:
            mcp.run("streamable-http", host="0.0.0.0", port=SERVER_PORT)
        print("[NBIM MCP] Finished", file=sys.stderr)
    except Exception as exc:
        print(f"[NBIM MCP] Error: {exc}", file=sys.stderr)
        traceback.print_exc(file=sys.stderr)
    finally:
        print("[NBIM MCP] Exiting...", file=sys.stderr)


if __name__ == "__main__":
    main()
