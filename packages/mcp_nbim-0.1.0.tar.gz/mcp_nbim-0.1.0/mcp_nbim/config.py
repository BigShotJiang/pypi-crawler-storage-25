# NBIM API
NBIM_API_BASE = "https://www.nbim.no/api/investments/v2"
NBIM_WEB_BASE = "https://www.nbim.no/en/the-fund"

# Page URLs
RETURNS_URL = f"{NBIM_WEB_BASE}/returns/"
EXCLUSIONS_URL = f"{NBIM_WEB_BASE}/responsible-investment/exclusion-of-companies/"

# Server
SERVER_PORT = 8008
USER_AGENT = "NBIM-MCP/1.0 (gervilabs.com)"
REQUEST_TIMEOUT_SECONDS = 30

# Cache TTLs (seconds)
CACHE_TTL_INIT = 3600          # 1 hour
CACHE_TTL_HOLDINGS = 86400     # 24 hours (data updates semi-annually)
CACHE_TTL_HISTORY = 86400      # 24 hours
CACHE_TTL_RETURNS = 3600       # 1 hour
CACHE_TTL_EXCLUSIONS = 21600   # 6 hours

# Asset class codes from init.json nav array
ASSET_CLASS_NAMES = {
    "eq": "Equities",
    "fi": "Fixed Income",
    "re": "Unlisted Real Estate",
    "ri": "Renewable Infrastructure",
}

# Asset type indices from history JSON
ASSET_TYPE_NAMES = {
    0: "Equities",
    1: "Fixed Income",
    2: "Real Estate",
    3: "Infrastructure",
}

# User-friendly asset class aliases -> asset type index
ASSET_CLASS_ALIASES = {
    "equity": 0, "equities": 0, "eq": 0,
    "fixed_income": 1, "fixed income": 1, "fi": 1, "bonds": 1,
    "real_estate": 2, "real estate": 2, "re": 2, "property": 2,
    "infrastructure": 3, "ri": 3, "renewable": 3,
}

# Country code to name (top fund countries + Nordics)
COUNTRY_NAMES = {
    "AD": "Andorra", "AE": "United Arab Emirates", "AG": "Antigua and Barbuda",
    "AR": "Argentina", "AT": "Austria", "AU": "Australia",
    "BB": "Barbados", "BD": "Bangladesh", "BE": "Belgium",
    "BG": "Bulgaria", "BH": "Bahrain", "BM": "Bermuda",
    "BR": "Brazil", "BS": "Bahamas", "BW": "Botswana",
    "CA": "Canada", "CH": "Switzerland", "CL": "Chile",
    "CN": "China", "CO": "Colombia", "CR": "Costa Rica",
    "CY": "Cyprus", "CZ": "Czech Republic",
    "DE": "Germany", "DK": "Denmark",
    "EG": "Egypt", "EE": "Estonia", "ES": "Spain",
    "FI": "Finland", "FO": "Faroe Islands", "FR": "France",
    "GB": "United Kingdom", "GE": "Georgia", "GH": "Ghana",
    "GR": "Greece", "GT": "Guatemala",
    "HK": "Hong Kong", "HR": "Croatia", "HU": "Hungary",
    "ID": "Indonesia", "IE": "Ireland", "IL": "Israel",
    "IN": "India", "IS": "Iceland", "IT": "Italy",
    "JM": "Jamaica", "JO": "Jordan", "JP": "Japan",
    "KE": "Kenya", "KR": "South Korea", "KW": "Kuwait",
    "KY": "Cayman Islands", "KZ": "Kazakhstan",
    "LB": "Lebanon", "LK": "Sri Lanka", "LT": "Lithuania",
    "LU": "Luxembourg", "LV": "Latvia",
    "MA": "Morocco", "MC": "Monaco", "MU": "Mauritius",
    "MX": "Mexico", "MY": "Malaysia",
    "NG": "Nigeria", "NL": "Netherlands", "NO": "Norway", "NZ": "New Zealand",
    "OM": "Oman",
    "PA": "Panama", "PE": "Peru", "PH": "Philippines",
    "PK": "Pakistan", "PL": "Poland", "PT": "Portugal",
    "QA": "Qatar",
    "RO": "Romania", "RS": "Serbia", "RU": "Russia", "RW": "Rwanda",
    "SA": "Saudi Arabia", "SE": "Sweden", "SG": "Singapore",
    "SI": "Slovenia", "SK": "Slovakia",
    "TH": "Thailand", "TN": "Tunisia", "TR": "Turkey", "TT": "Trinidad and Tobago",
    "TW": "Taiwan", "TZ": "Tanzania",
    "UA": "Ukraine", "UG": "Uganda", "US": "United States", "UY": "Uruguay",
    "VG": "British Virgin Islands", "VN": "Vietnam",
    "ZA": "South Africa", "ZM": "Zambia", "ZW": "Zimbabwe",
}

# Exclusion criterion keyword aliases for search
EXCLUSION_CRITERION_ALIASES = {
    "coal": "coal",
    "tobacco": "tobacco",
    "nuclear": "nuclear weapons",
    "cannabis": "cannabis",
    "cluster": "cluster munitions",
    "environment": "environmental damage",
    "human rights": "human rights",
    "war": "war",
    "corruption": "corruption",
    "weapons": "weapons",
    "ghg": "greenhouse gas",
    "emissions": "greenhouse gas",
    "climate": "greenhouse gas",
}

# Hardcoded annual returns (total fund, %) as fallback
# Source: nbim.no/en/the-fund/returns/ — updated once per year
ANNUAL_RETURNS_FALLBACK = {
    1998: 9.26, 1999: 12.44, 2000: 2.49, 2001: -2.47,
    2002: -4.74, 2003: 12.59, 2004: 8.94, 2005: 11.09,
    2006: 7.92, 2007: 4.26, 2008: -23.31, 2009: 25.62,
    2010: 9.62, 2011: -2.54, 2012: 13.42, 2013: 15.95,
    2014: 7.58, 2015: 2.74, 2016: 6.92, 2017: 13.66,
    2018: -6.12, 2019: 19.95, 2020: 10.86, 2021: 14.51,
    2022: -14.11, 2023: 16.14, 2024: 13.09, 2025: 15.11,
}
