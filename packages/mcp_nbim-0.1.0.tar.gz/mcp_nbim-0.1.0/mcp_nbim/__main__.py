"""Allow running with: python -m mcp_nbim"""

from mcp_nbim.server import main

main()
