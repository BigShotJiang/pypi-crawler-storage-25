def nbim_entry_prompt() -> str:
    return (
        """## NBIM MCP Server — Government Pension Fund Global
Access data from the world's largest sovereign wealth fund (NOK 21,000+ billion).

**TOOLS:**
- `nbim_fund_value()` — current fund value and asset allocation breakdown
- `nbim_holdings_search(query, year, country, sector)` — search equity holdings by company name
- `nbim_top_holdings(n, year, country, sector)` — top holdings by market value
- `nbim_country_allocation(year, asset_class, top_n)` — geographic allocation by country
- `nbim_returns(start_year, end_year)` — annual and cumulative returns since 1998
- `nbim_exclusions(query, category, criterion)` — excluded/observed companies with reasons

**EXAMPLE QUERIES:**
- "What is the fund worth today?" → `nbim_fund_value()`
- "Top 10 holdings in Japan" → `nbim_top_holdings(n=10, country='JP')`
- "Does the fund own Apple?" → `nbim_holdings_search(query='Apple')`
- "Country allocation in 2020 vs 2025" → call `nbim_country_allocation()` for each year
- "How did the fund perform in 2008?" → `nbim_returns(start_year=2008, end_year=2008)`
- "Which companies are excluded for coal?" → `nbim_exclusions(criterion='coal')`

**NOTES:**
- Holdings data covers equities only (bonds via Snowflake in future version).
- Holdings update semi-annually (year-end and H1 interim reports), dating back to 1998.
- No authentication required — all data is publicly available from nbim.no.
- The fund owns stakes in ~9,000 companies across 70+ countries.
"""
    )
