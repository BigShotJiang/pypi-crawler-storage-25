"""MCP tool functions for NBIM Government Pension Fund Global data."""

from typing import Any, Dict, List, Optional

try:
    from .client import NBIMClient
    from .config import (
        ASSET_CLASS_NAMES,
        ASSET_CLASS_ALIASES,
        ASSET_TYPE_NAMES,
        COUNTRY_NAMES,
        EXCLUSION_CRITERION_ALIASES,
    )
except ImportError:
    from client import NBIMClient
    from config import (
        ASSET_CLASS_NAMES,
        ASSET_CLASS_ALIASES,
        ASSET_TYPE_NAMES,
        COUNTRY_NAMES,
        EXCLUSION_CRITERION_ALIASES,
    )

_client = NBIMClient()


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------

def _format_table(headers: List[str], rows: List[List[Any]]) -> str:
    """Format data as a pipe-separated text table."""
    str_rows = [[str(c) if c is not None else "" for c in row] for row in rows]
    widths = [len(h) for h in headers]
    for row in str_rows:
        for i, cell in enumerate(row):
            if i < len(widths):
                widths[i] = max(widths[i], len(cell))

    def pad(cells: List[str]) -> str:
        return " | ".join(
            c.ljust(widths[i]) if i < len(widths) else c
            for i, c in enumerate(cells)
        )

    lines = [pad(headers), "-+-".join("-" * w for w in widths)]
    for row in str_rows:
        lines.append(pad(row))
    return "\n".join(lines)


def _format_nok_billions(value: float) -> str:
    """Format a NOK value (raw number) as billions with one decimal."""
    billions = value / 1_000_000_000
    if billions >= 1000:
        return f"{billions:,.0f}"
    elif billions >= 1:
        return f"{billions:,.1f}"
    else:
        return f"{billions:,.2f}"


def _format_pct(value: float) -> str:
    """Format a percentage value."""
    return f"{value:.1f}%"


def _country_name(code: str) -> str:
    """Resolve a country code to a display name."""
    return COUNTRY_NAMES.get(code, code)


# ---------------------------------------------------------------------------
# MCP Tools
# ---------------------------------------------------------------------------

def nbim_fund_value() -> str:
    """Get the current value of the Government Pension Fund Global and its asset allocation.

    Returns the total fund value in NOK and USD, broken down by asset class
    (equities, fixed income, real estate, renewable energy infrastructure),
    with percentage allocations and historical fund value over the last 10 years.
    """
    try:
        nav_data = _client.get_nav_data()
        if not nav_data:
            return "Error: No NAV data available from NBIM."

        # Find the most recent date
        dates = sorted(set(entry["d"][:10] for entry in nav_data), reverse=True)
        latest_date = dates[0]

        # Aggregate by asset class for the latest date
        latest_entries = [e for e in nav_data if e["d"][:10] == latest_date]
        asset_rows = []
        total_nok = 0
        total_usd = 0

        for ac_code in ["eq", "fi", "re", "ri"]:
            entries = [e for e in latest_entries if e["a"] == ac_code]
            if entries:
                nok = entries[0]["v"]["n"]
                usd = entries[0]["v"]["e"]
                total_nok += nok
                total_usd += usd
                asset_rows.append((ASSET_CLASS_NAMES.get(ac_code, ac_code), nok, usd))

        # Build asset allocation table
        alloc_headers = ["Asset Class", "Value (NOK bn)", "Value (USD bn)", "Share"]
        alloc_rows = []
        for name, nok, usd in asset_rows:
            share = (nok / total_nok * 100) if total_nok > 0 else 0
            alloc_rows.append([
                name,
                _format_nok_billions(nok),
                _format_nok_billions(usd),
                _format_pct(share),
            ])

        # Historical fund value (last 10 years, year-end only)
        year_totals: Dict[int, float] = {}
        for entry in nav_data:
            date_str = entry["d"][:10]
            year = int(date_str[:4])
            # Only count year-end dates (December)
            if "-12-" in date_str:
                year_totals[year] = year_totals.get(year, 0) + entry["v"]["n"]

        hist_headers = ["Year", "Value (NOK bn)"]
        hist_rows = []
        for year in sorted(year_totals.keys(), reverse=True)[:10]:
            hist_rows.append([str(year), _format_nok_billions(year_totals[year])])

        # Format output
        sections = [
            f"## Government Pension Fund Global — Fund Value",
            f"As of: {latest_date}\n",
            f"Total fund value: {_format_nok_billions(total_nok)} billion NOK "
            f"({_format_nok_billions(total_usd)} billion USD)\n",
            "### Asset Allocation",
            _format_table(alloc_headers, alloc_rows),
            "",
            "### Historical Fund Value (last 10 years)",
            _format_table(hist_headers, hist_rows),
        ]

        return "\n".join(sections)

    except Exception as e:
        return f"Error fetching fund value: {e}"


def nbim_holdings_search(
    query: str,
    year: Optional[int] = None,
    country: Optional[str] = None,
    sector: Optional[str] = None,
    max_results: int = 25,
) -> str:
    """Search the fund's equity holdings by company name, country, or sector.

    Args:
        query: Search term for company name (case-insensitive partial match).
               Use '*' or empty string to match all companies (useful with filters).
        year: Reporting year (1998-2025). Defaults to most recent available.
        country: Filter by ISO country code (e.g. 'US', 'NO', 'JP').
        sector: Filter by sector name (e.g. 'Technology', 'Financials', 'Energy').
               Case-insensitive partial match.
        max_results: Maximum results to return (default 25, max 100).

    Returns matching holdings sorted by market value (NOK), with company name,
    country, sector, value, and ownership percentage.
    """
    try:
        date = _client.get_period_date(year)
        holdings = _client.get_holdings(date)

        if not holdings:
            return f"No holdings data available for {date}."

        max_results = min(max_results, 100)
        query_lower = query.strip().lower() if query and query != "*" else ""
        country_upper = country.strip().upper() if country else None
        sector_lower = sector.strip().lower() if sector else None

        matches = []
        for h in holdings:
            # Name filter
            if query_lower and query_lower not in h.get("n", "").lower():
                continue
            # Country filter
            if country_upper and h.get("cc", "").upper() != country_upper:
                continue
            # Sector filter
            eq = h.get("eq", {})
            h_sector = eq.get("s", "") if isinstance(eq, dict) else ""
            if sector_lower and sector_lower not in h_sector.lower():
                continue
            matches.append(h)

        # Sort by market value NOK descending
        matches.sort(key=lambda x: x.get("a", {}).get("n", 0), reverse=True)
        total_matches = len(matches)
        matches = matches[:max_results]

        if not matches:
            filters = []
            if query_lower:
                filters.append(f"query='{query}'")
            if country_upper:
                filters.append(f"country={country_upper}")
            if sector_lower:
                filters.append(f"sector='{sector}'")
            return f"No holdings found for {', '.join(filters)} in {date[:4]}."

        headers = ["Company", "Country", "Sector", "Value (NOK bn)", "Ownership"]
        rows = []
        for h in matches:
            eq = h.get("eq", {})
            h_sector = eq.get("s", "") if isinstance(eq, dict) else ""
            nok_val = h.get("a", {}).get("n", 0)
            ownership = h.get("o", 0)
            rows.append([
                h.get("n", ""),
                _country_name(h.get("cc", "")),
                h_sector,
                _format_nok_billions(nok_val),
                _format_pct(ownership) if ownership else "",
            ])

        title = f"## Holdings Search"
        filters_desc = []
        if query_lower:
            filters_desc.append(f'"{query}"')
        if country_upper:
            filters_desc.append(f"country={country_upper}")
        if sector_lower:
            filters_desc.append(f"sector={sector}")
        if filters_desc:
            title += f": {', '.join(filters_desc)}"

        sections = [
            title,
            f"Period: {date} | Showing {len(matches)} of {total_matches} matches\n",
            _format_table(headers, rows),
        ]

        if total_matches > max_results:
            sections.append(
                f"\n... showing top {max_results} by value. "
                f"Use max_results to see more (max 100)."
            )

        return "\n".join(sections)

    except Exception as e:
        return f"Error searching holdings: {e}"


def nbim_top_holdings(
    n: int = 20,
    year: Optional[int] = None,
    country: Optional[str] = None,
    sector: Optional[str] = None,
) -> str:
    """Get the top N equity holdings in the fund by market value.

    Args:
        n: Number of top holdings to return (default 20, max 100).
        year: Reporting year (1998-2025). Defaults to most recent available.
        country: Filter by ISO country code (e.g. 'US', 'NO', 'JP').
        sector: Filter by sector name (e.g. 'Technology', 'Financials').
               Case-insensitive partial match.

    Returns a ranked table of the fund's largest equity positions with
    company name, country, sector, market value, and ownership stake.
    """
    try:
        date = _client.get_period_date(year)
        holdings = _client.get_holdings(date)

        if not holdings:
            return f"No holdings data available for {date}."

        n = min(max(n, 1), 100)
        country_upper = country.strip().upper() if country else None
        sector_lower = sector.strip().lower() if sector else None

        filtered = []
        for h in holdings:
            if country_upper and h.get("cc", "").upper() != country_upper:
                continue
            eq = h.get("eq", {})
            h_sector = eq.get("s", "") if isinstance(eq, dict) else ""
            if sector_lower and sector_lower not in h_sector.lower():
                continue
            filtered.append(h)

        # Sort by market value NOK descending
        filtered.sort(key=lambda x: x.get("a", {}).get("n", 0), reverse=True)
        top = filtered[:n]

        if not top:
            return f"No holdings found with the given filters for {date[:4]}."

        headers = ["Rank", "Company", "Country", "Sector", "Value (NOK bn)", "Ownership"]
        rows = []
        for i, h in enumerate(top, 1):
            eq = h.get("eq", {})
            h_sector = eq.get("s", "") if isinstance(eq, dict) else ""
            nok_val = h.get("a", {}).get("n", 0)
            ownership = h.get("o", 0)
            rows.append([
                str(i),
                h.get("n", ""),
                _country_name(h.get("cc", "")),
                h_sector,
                _format_nok_billions(nok_val),
                _format_pct(ownership) if ownership else "",
            ])

        title = f"## Top {len(top)} Holdings — Government Pension Fund Global"
        subtitle_parts = [f"Period: {date}"]
        if country_upper:
            subtitle_parts.append(f"Country: {_country_name(country_upper)}")
        if sector_lower:
            subtitle_parts.append(f"Sector: {sector}")
        subtitle = " | ".join(subtitle_parts)

        sections = [title, f"{subtitle}\n", _format_table(headers, rows)]

        total_nok = sum(h.get("a", {}).get("n", 0) for h in top)
        sections.append(
            f"\nTotal value of top {len(top)}: "
            f"{_format_nok_billions(total_nok)} billion NOK"
        )

        return "\n".join(sections)

    except Exception as e:
        return f"Error fetching top holdings: {e}"


def nbim_country_allocation(
    year: Optional[int] = None,
    asset_class: Optional[str] = None,
    top_n: int = 20,
) -> str:
    """Get the fund's geographic allocation by country.

    Shows how the fund's investments are distributed across countries,
    with values in NOK and USD and percentage share of total.

    Args:
        year: Year to show (1998-2025). Defaults to most recent available.
        asset_class: Filter by asset class — 'equity', 'fixed_income',
                     'real_estate', 'infrastructure', or None for all.
                     Also accepts short codes: 'eq', 'fi', 're', 'ri'.
        top_n: Number of top countries to show (default 20, max 50).

    Returns a ranked table of countries by fund allocation.
    """
    try:
        hist_date = _client.get_history_date()
        history = _client.get_history(hist_date)

        if not history:
            return "No country allocation data available from NBIM."

        sample = history[0]
        years = sample.get("Years", [])
        if not years:
            return "No year data in history."

        target_year = year if year else max(years)
        if target_year not in years:
            return f"No data for year {target_year}. Available: {min(years)}-{max(years)}"
        year_idx = years.index(target_year)

        # Determine which asset types to include
        asset_type_indices = [0, 1, 2, 3]  # All by default
        ac_label = "All asset classes"
        if asset_class:
            ac_lower = asset_class.strip().lower()
            if ac_lower in ASSET_CLASS_ALIASES:
                idx = ASSET_CLASS_ALIASES[ac_lower]
                asset_type_indices = [idx]
                ac_label = ASSET_TYPE_NAMES.get(idx, asset_class)
            elif ac_lower != "all":
                return (
                    f"Unknown asset class '{asset_class}'. "
                    f"Use: equity, fixed_income, real_estate, infrastructure, or all."
                )

        top_n = min(max(top_n, 1), 50)

        # Aggregate by country
        country_data = []
        for entry in history:
            cc = entry.get("CountryCode", "")
            total_nok = 0
            total_usd = 0
            for av in entry.get("AssetValues", []):
                if av.get("AssetType") in asset_type_indices:
                    nok_vals = av.get("ValuesNok", [])
                    usd_vals = av.get("ValuesUsd", [])
                    if year_idx < len(nok_vals):
                        total_nok += nok_vals[year_idx]
                    if year_idx < len(usd_vals):
                        total_usd += usd_vals[year_idx]
            if total_nok > 0:
                country_data.append((cc, total_nok, total_usd))

        # Sort by NOK value descending
        country_data.sort(key=lambda x: x[1], reverse=True)
        grand_total_nok = sum(c[1] for c in country_data)
        top_countries = country_data[:top_n]

        headers = ["Rank", "Country", "Value (NOK bn)", "Value (USD bn)", "Share"]
        rows = []
        for i, (cc, nok, usd) in enumerate(top_countries, 1):
            share = (nok / grand_total_nok * 100) if grand_total_nok > 0 else 0
            rows.append([
                str(i),
                _country_name(cc),
                _format_nok_billions(nok),
                _format_nok_billions(usd),
                _format_pct(share),
            ])

        sections = [
            f"## Country Allocation — Government Pension Fund Global",
            f"Year: {target_year} | {ac_label} | "
            f"{len(country_data)} countries total\n",
            _format_table(headers, rows),
            f"\nTotal across all {len(country_data)} countries: "
            f"{_format_nok_billions(grand_total_nok)} billion NOK",
        ]

        if len(country_data) > top_n:
            sections.append(
                f"Showing top {top_n}. Use top_n to see more (max 50)."
            )

        return "\n".join(sections)

    except Exception as e:
        return f"Error fetching country allocation: {e}"


def nbim_returns(
    start_year: Optional[int] = None,
    end_year: Optional[int] = None,
) -> str:
    """Get annual and cumulative returns for the Government Pension Fund Global.

    Shows the fund's total annual return for each year since inception in 1998,
    along with the cumulative annualized return.

    Args:
        start_year: Start year (1998-2025). Defaults to 1998.
        end_year: End year (1998-2025). Defaults to most recent year.

    Returns a table of annual returns and cumulative annualized returns.
    """
    try:
        returns = _client.scrape_returns()

        if not returns:
            return "Error: No returns data available."

        all_years = sorted(returns.keys())
        start = start_year if start_year else min(all_years)
        end = end_year if end_year else max(all_years)

        # Calculate cumulative annualized return
        cumulative_factor = 1.0
        cumulative_by_year: Dict[int, float] = {}
        year_count = 0
        for y in all_years:
            cumulative_factor *= (1 + returns[y] / 100)
            year_count += 1
            annualized = (cumulative_factor ** (1 / year_count) - 1) * 100
            cumulative_by_year[y] = annualized

        # Filter to requested range
        filtered_years = [y for y in all_years if start <= y <= end]

        if not filtered_years:
            return f"No returns data for {start}-{end}. Available: {min(all_years)}-{max(all_years)}"

        headers = ["Year", "Annual Return", "Cumulative Annualized"]
        rows = []
        for y in filtered_years:
            annual = returns[y]
            cumul = cumulative_by_year.get(y, 0)
            rows.append([
                str(y),
                f"{annual:+.2f}%",
                f"{cumul:.2f}%",
            ])

        sections = [
            f"## Government Pension Fund Global — Returns",
            f"Period: {filtered_years[0]}-{filtered_years[-1]}\n",
            _format_table(headers, rows),
        ]

        # Add summary
        latest_year = filtered_years[-1]
        if latest_year in cumulative_by_year:
            sections.append(
                f"\nSince inception (1998): "
                f"{cumulative_by_year[latest_year]:.2f}% annualized"
            )

        if len(filtered_years) > 1:
            best_year = max(filtered_years, key=lambda y: returns[y])
            worst_year = min(filtered_years, key=lambda y: returns[y])
            sections.append(
                f"Best year: {best_year} ({returns[best_year]:+.2f}%) | "
                f"Worst year: {worst_year} ({returns[worst_year]:+.2f}%)"
            )

        return "\n".join(sections)

    except Exception as e:
        return f"Error fetching returns: {e}"


def nbim_exclusions(
    query: Optional[str] = None,
    category: Optional[str] = None,
    criterion: Optional[str] = None,
) -> str:
    """Get companies excluded from or under observation by the Government Pension Fund Global.

    The fund excludes companies based on product criteria (coal, tobacco, weapons)
    or conduct criteria (human rights, environment, corruption).

    Args:
        query: Search company name (case-insensitive partial match).
        category: Filter by 'product' or 'conduct' (product-based vs conduct-based).
        criterion: Filter by criterion keyword (e.g. 'coal', 'tobacco', 'nuclear',
                   'human rights', 'environment', 'corruption', 'weapons', 'cannabis',
                   'cluster', 'ghg', 'emissions', 'war').

    Returns a table of excluded/observed companies with category, criterion,
    decision type, and date.
    """
    try:
        records = _client.scrape_exclusions()

        if not records:
            return "No exclusion data available. Check https://www.nbim.no/en/the-fund/responsible-investment/exclusion-of-companies/"

        query_lower = query.strip().lower() if query else None
        category_lower = category.strip().lower() if category else None
        criterion_lower = criterion.strip().lower() if criterion else None

        # Resolve criterion alias
        criterion_search = None
        if criterion_lower:
            criterion_search = EXCLUSION_CRITERION_ALIASES.get(
                criterion_lower, criterion_lower
            )

        filtered = []
        for r in records:
            if query_lower and query_lower not in r["company"].lower():
                continue
            if category_lower:
                if category_lower == "product" and "product" not in r["category"].lower():
                    continue
                if category_lower == "conduct" and "conduct" not in r["category"].lower():
                    continue
            if criterion_search and criterion_search.lower() not in r["criterion"].lower():
                continue
            filtered.append(r)

        if not filtered:
            filters = []
            if query_lower:
                filters.append(f"query='{query}'")
            if category_lower:
                filters.append(f"category={category}")
            if criterion_search:
                filters.append(f"criterion='{criterion}'")
            return f"No exclusions found for {', '.join(filters)}."

        headers = ["Company", "Category", "Criterion", "Decision", "Date"]
        rows = []
        for r in filtered:
            rows.append([
                r["company"],
                r["category"],
                r["criterion"],
                r["decision"],
                r["date"],
            ])

        # Truncate if too many
        truncated = False
        if len(rows) > 100:
            rows = rows[:100]
            truncated = True

        title = "## Excluded and Observed Companies"
        subtitle_parts = [f"Total: {len(records)} companies"]
        if query_lower or category_lower or criterion_search:
            subtitle_parts.append(f"Matches: {len(filtered)}")
        subtitle = " | ".join(subtitle_parts)

        # Count by type
        product_count = sum(1 for r in records if "product" in r["category"].lower())
        conduct_count = sum(1 for r in records if "conduct" in r["category"].lower())

        sections = [
            title,
            f"{subtitle}\n",
            _format_table(headers, rows),
        ]

        if truncated:
            sections.append(f"\n... showing first 100 of {len(filtered)} matches.")

        sections.append(
            f"\nProduct-based: {product_count} | Conduct-based: {conduct_count}"
        )

        return "\n".join(sections)

    except Exception as e:
        return f"Error fetching exclusions: {e}"
