# Geography Module Documentation

::: navlib.geo.geography
    options:
      show_source: true
      heading_level: 3
      filters: public
