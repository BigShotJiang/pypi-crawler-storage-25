# Time Module Documentation

::: navlib.time.time
    options:
      show_source: true
      heading_level: 3
      filters: public
