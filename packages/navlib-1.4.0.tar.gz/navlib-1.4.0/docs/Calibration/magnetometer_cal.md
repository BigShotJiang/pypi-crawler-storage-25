# Magnetometer Calibration Module Documentation

!!! warning "Optional Dependencies Required"
    Some magnetometer calibration methods (MAGYC and MagFactor3) require `jax` and
    `gtsam`, which are **not installed by default**. Install the `calibration` extra
    to enable them:

    ```bash
    pip install navlib[calibration]
    ```

    On **Python >= 3.12**, `gtsam` requires a pre-release build:

    ```bash
    pip install navlib[calibration] --pre
    ```

    If using `uv`:

    ```toml
    [tool.uv]
    prerelease = "allow"
    ```

::: navlib.cal.cal_mag
    options:
      show_source: true
      heading_level: 3
      filters: public
