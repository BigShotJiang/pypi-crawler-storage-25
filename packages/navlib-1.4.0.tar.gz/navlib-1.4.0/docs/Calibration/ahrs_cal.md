# AHRS Calibration Module Documentation

::: navlib.cal.cal_ahrs
    options:
      show_source: true
      heading_level: 3
      filters: public
