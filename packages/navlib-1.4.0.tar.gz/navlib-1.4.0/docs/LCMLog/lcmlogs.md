# LCM Logs Utilities Module Documentation

::: navlib.lcmlog.log_to_smat
    options:
      show_source: true
      heading_level: 3
      filters: public
