# LCM Logs Parser Module Documentation

::: navlib.lcmlog.parse_lcmlog
    options:
      show_source: true
      heading_level: 3
      filters: public
