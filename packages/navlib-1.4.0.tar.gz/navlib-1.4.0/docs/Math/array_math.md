# Array Math Module Documentation

::: navlib.math.vmath
    options:
      show_source: true
      heading_level: 3
      filters: public
