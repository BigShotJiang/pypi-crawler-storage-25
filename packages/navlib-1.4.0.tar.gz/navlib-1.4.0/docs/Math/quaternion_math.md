# Quaternion Math Module Documentation

::: navlib.math.quaternion
    options:
      show_source: true
      heading_level: 3
      filters: public
