# Filters Math Module Documentation

::: navlib.math.filters
    options:
      show_source: true
      heading_level: 3
      filters: public
