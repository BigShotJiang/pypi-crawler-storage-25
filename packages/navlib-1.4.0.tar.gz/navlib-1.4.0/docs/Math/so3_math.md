# SO(3) Math Module Documentation

::: navlib.math.so3
    options:
      show_source: true
      heading_level: 3
      filters: public
