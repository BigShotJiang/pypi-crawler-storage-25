# Attitude Estimation Module Documentation

::: navlib.nav.attitude_estimation
    options:
      show_source: true
      heading_level: 3
      filters: public
