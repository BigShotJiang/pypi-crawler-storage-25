# State Estimation Module Documentation

::: navlib.nav.state_estimation
    options:
      show_source: true
      heading_level: 3
      filters: public
