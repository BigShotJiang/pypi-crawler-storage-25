# Kalman Filter Module Documentation

::: navlib.nav.kalman_filter
    options:
      show_source: true
      heading_level: 3
      filters: public
