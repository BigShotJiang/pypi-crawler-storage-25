# Seawater Module Documentation

::: navlib.environment.seawater
    options:
      show_source: true
      heading_level: 3
      filters: public
