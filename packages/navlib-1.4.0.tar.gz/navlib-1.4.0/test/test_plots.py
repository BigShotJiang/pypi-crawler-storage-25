"""
Test module for the plots module.

Authors: Sebastián Rodríguez-Martínez
Contact: srodriguez@mbari.org
Last Update: 2025-04-14
"""

import os
import tempfile

import matplotlib

matplotlib.use("Agg")  # non-interactive backend — must be set before importing pyplot
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pytest  # noqa: E402

from navlib.plots import (  # noqa: E402
    plot_axis_comparison,
    plot_axis_timeseries,
    plot_magnetic_field,
    plot_magnetic_field_comparison,
    plot_trajectory,
    plot_trajectory_comparison,
    plot_triaxial_comparison,
    plot_triaxial_timeseries,
)
from navlib.plots.plots import (  # noqa: E402
    plot_axis_comparison as plot_axis_comparison_direct,
    plot_axis_timeseries as plot_axis_timeseries_direct,
    plot_magnetic_field as plot_magnetic_field_direct,
    plot_magnetic_field_comparison as plot_magnetic_field_comparison_direct,
    plot_trajectory as plot_trajectory_direct,
    plot_trajectory_comparison as plot_trajectory_comparison_direct,
    plot_triaxial_comparison as plot_triaxial_comparison_direct,
    plot_triaxial_timeseries as plot_triaxial_timeseries_direct,
)
from navlib.plots.plots import _scale_time_array  # noqa: E402


# ---------------------------------------------------------------------------
# Shared synthetic data
# ---------------------------------------------------------------------------

N = 200
TIME = np.linspace(0, 100, N)
DATA_3AXIS = np.random.randn(N, 3)
DATA_1AXIS = np.random.randn(N)
XY_DATA = np.column_stack(
    [
        np.cumsum(np.random.randn(N)),
        np.cumsum(np.random.randn(N)),
    ]
)
DEPTH = np.linspace(0, 50, N)


# ---------------------------------------------------------------------------
# Import tests
# ---------------------------------------------------------------------------


def test_imports():
    # Checks that navlib.plots and navlib.plots.plots expose the same objects
    assert (
        plot_triaxial_timeseries.__code__.co_code
        == plot_triaxial_timeseries_direct.__code__.co_code
    )
    assert (
        plot_triaxial_comparison.__code__.co_code
        == plot_triaxial_comparison_direct.__code__.co_code
    )
    assert (
        plot_axis_timeseries.__code__.co_code
        == plot_axis_timeseries_direct.__code__.co_code
    )
    assert (
        plot_axis_comparison.__code__.co_code
        == plot_axis_comparison_direct.__code__.co_code
    )
    assert (
        plot_magnetic_field.__code__.co_code
        == plot_magnetic_field_direct.__code__.co_code
    )
    assert (
        plot_magnetic_field_comparison.__code__.co_code
        == plot_magnetic_field_comparison_direct.__code__.co_code
    )
    assert plot_trajectory.__code__.co_code == plot_trajectory_direct.__code__.co_code
    assert (
        plot_trajectory_comparison.__code__.co_code
        == plot_trajectory_comparison_direct.__code__.co_code
    )


# ---------------------------------------------------------------------------
# _scale_time_array
# ---------------------------------------------------------------------------


def test_scale_time_array():
    # Test 1: Fewer than two points raises ValueError
    with pytest.raises(ValueError):
        _scale_time_array(np.array([0.0]))

    # Test 2: Auto-detection — duration < 120 s -> seconds
    t, label = _scale_time_array(np.linspace(0, 60, 10))
    assert label == "Time (s)"
    np.testing.assert_array_equal(t, np.linspace(0, 60, 10))

    # Test 3: Auto-detection — duration > 120 s -> minutes
    t, label = _scale_time_array(np.linspace(0, 300, 10))
    assert label == "Time (min)"
    np.testing.assert_allclose(t, np.linspace(0, 300, 10) / 60)

    # Test 4: Auto-detection — duration > 3600 s -> hours
    t, label = _scale_time_array(np.linspace(0, 7200, 10))
    assert label == "Time (h)"
    np.testing.assert_allclose(t, np.linspace(0, 7200, 10) / 3600)

    # Test 5: Explicit unit override
    t, label = _scale_time_array(np.linspace(0, 60, 10), unit="min")
    assert label == "Time (min)"
    np.testing.assert_allclose(t, np.linspace(0, 60, 10) / 60)


# ---------------------------------------------------------------------------
# plot_triaxial_timeseries
# ---------------------------------------------------------------------------


def test_plot_triaxial_timeseries():
    # Test 1: Time array with fewer than two points raises ValueError
    with pytest.raises(ValueError):
        plot_triaxial_timeseries([0.0], [[1, 2, 3]], show=False, close=True)

    # Test 2: Data with wrong shape raises ValueError
    with pytest.raises(ValueError):
        plot_triaxial_timeseries(TIME, np.random.randn(N, 2), show=False, close=True)

    # Test 3: Valid input — returns (Figure, array of 3 axes)
    fig, axes = plot_triaxial_timeseries(TIME, DATA_3AXIS, show=False, close=True)
    assert isinstance(fig, plt.Figure)
    assert len(axes) == 3

    # Test 4: magnitude=True adds a fourth subplot
    fig, axes = plot_triaxial_timeseries(
        TIME, DATA_3AXIS, magnitude=True, show=False, close=True
    )
    assert len(axes) == 4

    # Test 5: Axes pass-through — figure is taken from the provided axes
    fig_outer, axes_outer = plt.subplots(3, 1)
    fig_ret, axes_ret = plot_triaxial_timeseries(
        TIME, DATA_3AXIS, ax=axes_outer, show=False, close=False
    )
    assert fig_ret is fig_outer
    plt.close(fig_outer)

    # Test 6: save_path writes a file
    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
        path = f.name
    try:
        plot_triaxial_timeseries(
            TIME, DATA_3AXIS, save_path=path, show=False, close=True
        )
        assert os.path.getsize(path) > 0
    finally:
        os.unlink(path)


# ---------------------------------------------------------------------------
# plot_triaxial_comparison
# ---------------------------------------------------------------------------


def test_plot_triaxial_comparison():
    sensor_data = [DATA_3AXIS, DATA_3AXIS * 0.9]
    sensor_names = ["Sensor A", "Sensor B"]

    # Test 1: Mismatched sensor_names length raises ValueError
    with pytest.raises(ValueError):
        plot_triaxial_comparison(
            TIME, sensor_data, ["Only One"], show=False, close=True
        )

    # Test 2: Mismatched time_data list length raises ValueError
    with pytest.raises(ValueError):
        plot_triaxial_comparison(
            [TIME], sensor_data, sensor_names, show=False, close=True
        )

    # Test 3: Data with wrong shape raises ValueError
    with pytest.raises(ValueError):
        plot_triaxial_comparison(
            TIME,
            [np.random.randn(N, 2), DATA_3AXIS],
            sensor_names,
            show=False,
            close=True,
        )

    # Test 4: Valid input — returns (Figure, array of 3 axes)
    fig, axes = plot_triaxial_comparison(
        TIME, sensor_data, sensor_names, show=False, close=True
    )
    assert isinstance(fig, plt.Figure)
    assert len(axes) == 3

    # Test 5: Per-sensor time arrays
    fig, axes = plot_triaxial_comparison(
        [TIME, TIME * 0.5], sensor_data, sensor_names, show=False, close=True
    )
    assert len(axes) == 3

    # Test 6: magnitude=True adds a fourth subplot
    fig, axes = plot_triaxial_comparison(
        TIME, sensor_data, sensor_names, magnitude=True, show=False, close=True
    )
    assert len(axes) == 4


# ---------------------------------------------------------------------------
# plot_axis_timeseries
# ---------------------------------------------------------------------------


def test_plot_axis_timeseries():
    # Test 1: 2D time array raises ValueError
    with pytest.raises(ValueError):
        plot_axis_timeseries(np.ones((N, 2)), DATA_1AXIS, show=False, close=True)

    # Test 2: Time array with fewer than two points raises ValueError
    with pytest.raises(ValueError):
        plot_axis_timeseries([0.0], [1.0], show=False, close=True)

    # Test 3: axis_index out of bounds raises ValueError
    with pytest.raises(ValueError):
        plot_axis_timeseries(TIME, DATA_3AXIS, axis_index=5, show=False, close=True)

    # Test 4: Time and data length mismatch raises ValueError
    with pytest.raises(ValueError):
        plot_axis_timeseries(TIME, DATA_1AXIS[:10], show=False, close=True)

    # Test 5: Valid input with 1D data — returns (Figure, Axes)
    fig, ax = plot_axis_timeseries(TIME, DATA_1AXIS, show=False, close=True)
    assert isinstance(fig, plt.Figure)
    assert isinstance(ax, plt.Axes)

    # Test 6: Valid input with 2D data, selecting axis 1
    fig, ax = plot_axis_timeseries(
        TIME, DATA_3AXIS, axis_index=1, show=False, close=True
    )
    assert isinstance(fig, plt.Figure)

    # Test 7: Axes pass-through
    fig_outer, ax_outer = plt.subplots()
    fig_ret, ax_ret = plot_axis_timeseries(
        TIME, DATA_1AXIS, ax=ax_outer, show=False, close=False
    )
    assert fig_ret is fig_outer
    assert ax_ret is ax_outer
    plt.close(fig_outer)


# ---------------------------------------------------------------------------
# plot_axis_comparison
# ---------------------------------------------------------------------------


def test_plot_axis_comparison():
    sensor_data = [DATA_3AXIS, DATA_3AXIS * 1.1]
    sensor_names = ["Sensor A", "Sensor B"]

    # Test 1: Mismatched sensor_names length raises ValueError
    with pytest.raises(ValueError):
        plot_axis_comparison(TIME, sensor_data, ["Only One"], show=False, close=True)

    # Test 2: Mismatched time_data list length raises ValueError
    with pytest.raises(ValueError):
        plot_axis_comparison([TIME], sensor_data, sensor_names, show=False, close=True)

    # Test 3: axis_index out of bounds raises ValueError
    with pytest.raises(ValueError):
        plot_axis_comparison(
            TIME, sensor_data, sensor_names, axis_index=5, show=False, close=True
        )

    # Test 4: Time and data length mismatch raises ValueError
    with pytest.raises(ValueError):
        plot_axis_comparison(
            TIME,
            [DATA_3AXIS[:10], DATA_3AXIS],
            sensor_names,
            show=False,
            close=True,
        )

    # Test 5: Valid input — returns (Figure, Axes)
    fig, ax = plot_axis_comparison(
        TIME, sensor_data, sensor_names, show=False, close=True
    )
    assert isinstance(fig, plt.Figure)
    assert isinstance(ax, plt.Axes)

    # Test 6: Valid with 1D sensor data arrays
    fig, ax = plot_axis_comparison(
        TIME,
        [DATA_1AXIS, DATA_1AXIS * 0.5],
        sensor_names,
        show=False,
        close=True,
    )
    assert isinstance(fig, plt.Figure)

    # Test 7: Per-sensor time arrays
    fig, ax = plot_axis_comparison(
        [TIME, TIME], sensor_data, sensor_names, show=False, close=True
    )
    assert isinstance(fig, plt.Figure)


# ---------------------------------------------------------------------------
# plot_magnetic_field
# ---------------------------------------------------------------------------


def test_plot_magnetic_field():
    vectors = np.random.randn(N, 3)

    # Test 1: Wrong shape raises ValueError
    with pytest.raises(ValueError):
        plot_magnetic_field(np.random.randn(N, 2), show=False, close=True)

    # Test 2: 1D array raises ValueError
    with pytest.raises(ValueError):
        plot_magnetic_field(np.random.randn(N), show=False, close=True)

    # Test 3: Valid input — returns (Figure, Axes)
    fig, ax = plot_magnetic_field(vectors, show=False, close=True)
    assert isinstance(fig, plt.Figure)
    assert ax is not None

    # Test 4: Axes pass-through
    fig_outer = plt.figure()
    ax_outer = fig_outer.add_subplot(111, projection="3d")
    fig_ret, ax_ret = plot_magnetic_field(vectors, ax=ax_outer, show=False, close=False)
    assert fig_ret is fig_outer
    assert ax_ret is ax_outer
    plt.close(fig_outer)


# ---------------------------------------------------------------------------
# plot_magnetic_field_comparison
# ---------------------------------------------------------------------------


def test_plot_magnetic_field_comparison():
    sensor_data = [np.random.randn(N, 3), np.random.randn(N, 3)]
    sensor_names = ["Sensor A", "Sensor B"]

    # Test 1: Mismatched sensor_names length raises ValueError
    with pytest.raises(ValueError):
        plot_magnetic_field_comparison(
            sensor_data, ["Only One"], show=False, close=True
        )

    # Test 2: Data with wrong shape raises ValueError
    with pytest.raises(ValueError):
        plot_magnetic_field_comparison(
            [np.random.randn(N, 2), np.random.randn(N, 3)],
            sensor_names,
            show=False,
            close=True,
        )

    # Test 3: Valid input — returns (Figure, Axes)
    fig, ax = plot_magnetic_field_comparison(
        sensor_data, sensor_names, show=False, close=True
    )
    assert isinstance(fig, plt.Figure)
    assert ax is not None

    # Test 4: normalize_vectors=False skips normalization
    fig, ax = plot_magnetic_field_comparison(
        sensor_data,
        sensor_names,
        normalize_vectors=False,
        show=False,
        close=True,
    )
    assert isinstance(fig, plt.Figure)


# ---------------------------------------------------------------------------
# plot_trajectory
# ---------------------------------------------------------------------------


def test_plot_trajectory():
    # Test 1: xy_data with too few columns raises ValueError
    with pytest.raises(ValueError):
        plot_trajectory(np.random.randn(N, 1), show=False, close=True)

    # Test 2: z_data length mismatch raises ValueError
    with pytest.raises(ValueError):
        plot_trajectory(XY_DATA, z_data=DEPTH[:10], show=False, close=True)

    # Test 3: Valid input without z_data — returns (Figure, Axes)
    fig, ax = plot_trajectory(XY_DATA, show=False, close=True)
    assert isinstance(fig, plt.Figure)
    assert isinstance(ax, plt.Axes)

    # Test 4: Valid input with z_data (colormap mode)
    fig, ax = plot_trajectory(XY_DATA, z_data=DEPTH, show=False, close=True)
    assert isinstance(fig, plt.Figure)

    # Test 5: remove_offset shifts trajectory to origin
    fig, ax = plot_trajectory(XY_DATA, remove_offset=True, show=False, close=True)
    assert isinstance(fig, plt.Figure)

    # Test 6: marker=None disables scatter points
    fig, ax = plot_trajectory(XY_DATA, marker=None, show=False, close=True)
    assert isinstance(fig, plt.Figure)

    # Test 7: Axes pass-through
    fig_outer, ax_outer = plt.subplots()
    fig_ret, ax_ret = plot_trajectory(XY_DATA, ax=ax_outer, show=False, close=False)
    assert fig_ret is fig_outer
    assert ax_ret is ax_outer
    plt.close(fig_outer)


# ---------------------------------------------------------------------------
# plot_trajectory_comparison
# ---------------------------------------------------------------------------


def test_plot_trajectory_comparison():
    traj_data = [XY_DATA, XY_DATA * 0.95]
    sensor_names = ["Nav A", "Nav B"]

    # Test 1: Mismatched sensor_names length raises ValueError
    with pytest.raises(ValueError):
        plot_trajectory_comparison(traj_data, ["Only One"], show=False, close=True)

    # Test 2: Trajectory with too few columns raises ValueError
    with pytest.raises(ValueError):
        plot_trajectory_comparison(
            [np.random.randn(N, 1), XY_DATA], sensor_names, show=False, close=True
        )

    # Test 3: Mismatched depth_data length raises ValueError
    with pytest.raises(ValueError):
        plot_trajectory_comparison(
            traj_data, sensor_names, depth_data=[DEPTH], show=False, close=True
        )

    # Test 4: Mismatched time_data length raises ValueError
    with pytest.raises(ValueError):
        plot_trajectory_comparison(
            traj_data, sensor_names, time_data=[TIME], show=False, close=True
        )

    # Test 5: Valid input without depth — ax_depth is None
    fig, (ax_traj, ax_depth) = plot_trajectory_comparison(
        traj_data, sensor_names, show=False, close=True
    )
    assert isinstance(fig, plt.Figure)
    assert isinstance(ax_traj, plt.Axes)
    assert ax_depth is None

    # Test 6: Valid input with depth — both axes populated
    fig, (ax_traj, ax_depth) = plot_trajectory_comparison(
        traj_data,
        sensor_names,
        depth_data=[DEPTH, DEPTH * 0.9],
        show=False,
        close=True,
    )
    assert isinstance(ax_traj, plt.Axes)
    assert isinstance(ax_depth, plt.Axes)

    # Test 7: Valid input with depth and time
    fig, (ax_traj, ax_depth) = plot_trajectory_comparison(
        traj_data,
        sensor_names,
        depth_data=[DEPTH, DEPTH * 0.9],
        time_data=[TIME, TIME],
        show=False,
        close=True,
    )
    assert isinstance(ax_depth, plt.Axes)

    # Test 8: Axes pass-through
    fig_outer, (ax_t, ax_d) = plt.subplots(1, 2)
    fig_ret, _ = plot_trajectory_comparison(
        traj_data,
        sensor_names,
        depth_data=[DEPTH, DEPTH * 0.9],
        axes=(ax_t, ax_d),
        show=False,
        close=False,
    )
    assert fig_ret is fig_outer
    plt.close(fig_outer)
