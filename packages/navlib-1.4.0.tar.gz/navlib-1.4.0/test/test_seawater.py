"""
Test module for the seawater module.

Authors: Sebastián Rodríguez-Martínez
Contact: srodriguez@mbari.org
Last Update: 2025/04/14
"""

import numpy as np
import pytest

from navlib import (
    ctd2oxygen_saturation,
    ctd2salinity,
    ctd2svel,
    ctp2pden,
    ctp2salinity,
    depth2pressure,
)
from navlib.environment import ctd2oxygen_saturation as ctd2oxygen_saturation_relative
from navlib.environment import ctd2salinity as ctd2salinity_relative
from navlib.environment import ctd2svel as ctd2svel_relative
from navlib.environment import ctp2pden as ctp2pden_relative
from navlib.environment import ctp2salinity as ctp2salinity_relative
from navlib.environment import depth2pressure as depth2pressure_relative


def test_imports():
    # Checks that the absolute and relative imports work correctly
    assert (
        ctd2oxygen_saturation_relative.__code__.co_code
        == ctd2oxygen_saturation.__code__.co_code
    )
    assert ctd2salinity_relative.__code__.co_code == ctd2salinity.__code__.co_code
    assert ctd2svel_relative.__code__.co_code == ctd2svel.__code__.co_code
    assert ctp2pden_relative.__code__.co_code == ctp2pden.__code__.co_code
    assert ctp2salinity_relative.__code__.co_code == ctp2salinity.__code__.co_code
    assert depth2pressure_relative.__code__.co_code == depth2pressure.__code__.co_code


def test_ctd2svel_raise_checks():
    # Valid base inputs for later tests (all arrays are 1D and of same shape)
    conductivity_valid = np.array([1.0, 1.2, 0.9])
    temperature_valid = np.array([10.0, 12.0, 11.0])
    depth_valid = -np.array([100.0, 200.0, 150.0])  # negative values
    latitude_valid = np.array([30.0, 30.0, 30.0])
    longitude_valid = np.array([0.0, 0.0, 0.0])

    # --------------------------
    # Type checks
    # --------------------------
    with pytest.raises(TypeError) as excinfo:
        ctd2svel(
            {"wrong": "type"},
            temperature_valid,
            depth_valid,
            latitude_valid,
            longitude_valid,
        )
    assert "Conductivity must be a float or an array." in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        ctd2svel(
            conductivity_valid,
            "not a float or array",
            depth_valid,
            latitude_valid,
            longitude_valid,
        )
    assert "Temperature must be a float or an array." in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        ctd2svel(
            conductivity_valid,
            temperature_valid,
            {"bad": "depth"},
            latitude_valid,
            longitude_valid,
        )
    assert "Depth must be a float or an array." in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        ctd2svel(
            conductivity_valid,
            temperature_valid,
            depth_valid,
            "invalid",
            longitude_valid,
        )
    assert "Latitude must be a float or an array." in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        ctd2svel(
            conductivity_valid,
            temperature_valid,
            depth_valid,
            latitude_valid,
            "invalid",
        )
    assert "Longitude must be a float or an array." in str(excinfo.value)

    # --------------------------
    # Shape checks: multidimensional arrays
    # --------------------------
    conductivity_multi = np.array([[1.0, 1.2, 0.9], [1.0, 1.2, 0.9]])
    with pytest.raises(ValueError) as excinfo:
        ctd2svel(
            conductivity_multi,
            temperature_valid,
            depth_valid,
            latitude_valid,
            longitude_valid,
        )
    assert "Conductivity must be a 1D array." in str(excinfo.value)

    temperature_multi = np.array([[10.0, 12.0, 11.0], [10.0, 12.0, 11.0]])
    with pytest.raises(ValueError) as excinfo:
        ctd2svel(
            conductivity_valid,
            temperature_multi,
            depth_valid,
            latitude_valid,
            longitude_valid,
        )
    assert "Temperature must be a 1D array." in str(excinfo.value)

    depth_multi = np.array([[100.0, 200.0, 150.0], [100.0, 200.0, 150.0]])
    with pytest.raises(ValueError) as excinfo:
        ctd2svel(
            conductivity_valid,
            temperature_valid,
            depth_multi,
            latitude_valid,
            longitude_valid,
        )
    assert "Depth must be a 1D array." in str(excinfo.value)

    # --------------------------
    # Same shape check: mismatch between inputs
    # --------------------------
    temperature_diff = np.array([10.0, 12.0])  # shape mismatch
    with pytest.raises(ValueError) as excinfo:
        ctd2svel(
            conductivity_valid,
            temperature_diff,
            depth_valid,
            latitude_valid,
            longitude_valid,
        )
    assert "must have the same shape" in str(excinfo.value)

    # --------------------------
    # Depth must be negative
    # --------------------------
    depth_positive = np.array([100.0, 200.0, 150.0])
    with pytest.raises(ValueError) as excinfo:
        ctd2svel(
            conductivity_valid,
            temperature_valid,
            depth_positive,
            latitude_valid,
            longitude_valid,
        )
    assert "Depth must be negative." in str(excinfo.value)

    # --------------------------
    # Latitude range check [-90,90]
    # --------------------------
    latitude_invalid = np.array([30.0, 95.0, 30.0])
    with pytest.raises(ValueError) as excinfo:
        ctd2svel(
            conductivity_valid,
            temperature_valid,
            depth_valid,
            latitude_invalid,
            longitude_valid,
        )
    assert "Latitude must be between -90 and 90 degrees." in str(excinfo.value)

    # --------------------------
    # Longitude range check [-360,360]
    # --------------------------
    longitude_invalid = np.array([0.0, 400.0, 0.0])
    with pytest.raises(ValueError) as excinfo:
        ctd2svel(
            conductivity_valid,
            temperature_valid,
            depth_valid,
            latitude_valid,
            longitude_invalid,
        )
    assert "Longitude must be between -360 and 360 degrees." in str(excinfo.value)


def test_depth2pressure_raise_checks():
    # Valid inputs for later tests: 1D arrays with matching shapes, negative depths, and valid latitudes.
    depth_valid = np.array([-100.0, -200.0, -150.0])
    latitude_valid = np.array([30.0, 30.0, 30.0])

    # Basic valid call should not raise an error.
    pressure = depth2pressure(depth_valid, latitude_valid)
    assert isinstance(pressure, np.ndarray)
    assert pressure.shape == depth_valid.shape

    # --------------------------
    # Type checks
    # --------------------------
    with pytest.raises(TypeError) as excinfo:
        depth2pressure({"invalid": "object"}, latitude_valid)
    assert "Depth must be a float or an array." in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        depth2pressure(depth_valid, "not a float or an array")
    assert "Latitude must be a float or an array." in str(excinfo.value)

    # --------------------------
    # Shape checks (multidimensional arrays)
    # --------------------------
    depth_2d = np.array([[-100.0, -200.0, -150.0], [-100.0, -200.0, -150.0]])
    with pytest.raises(ValueError) as excinfo:
        depth2pressure(depth_2d, latitude_valid)
    assert "Depth must be a 1D array." in str(excinfo.value)

    latitude_2d = np.array([[30.0, 30.0, 30.0], [30.0, 30.0, 30.0]])
    with pytest.raises(ValueError) as excinfo:
        depth2pressure(depth_valid, latitude_2d)
    assert "Latitude must be a 1D array." in str(excinfo.value)

    # --------------------------
    # Same shape check: depth and latitude must match shape
    # --------------------------
    latitude_mismatch = np.array([30.0, 30.0])  # Different shape than depth_valid
    with pytest.raises(ValueError) as excinfo:
        depth2pressure(depth_valid, latitude_mismatch)
    assert "Depth and latitude must have the same shape." in str(excinfo.value)

    # --------------------------
    # Depth negativity check
    # --------------------------
    depth_positive = np.array([-100.0, 200.0, -150.0])  # 200.0 is positive
    with pytest.raises(ValueError) as excinfo:
        depth2pressure(depth_positive, latitude_valid)
    assert "Depth must be negative." in str(excinfo.value)

    # --------------------------
    # Latitude bounds check: must be between -90 and 90
    # --------------------------
    latitude_invalid = np.array([30.0, 100.0, 30.0])  # 100.0 is out of range
    with pytest.raises(ValueError) as excinfo:
        depth2pressure(depth_valid, latitude_invalid)
    assert "Latitude must be between -90 and 90 degrees." in str(excinfo.value)


def test_ctp2salinity_raise_checks():
    # Valid base inputs (all 1D arrays with the same shape)
    conductivity_valid = np.array([1.0, 1.2, 0.9])
    temperature_valid = np.array([10.0, 12.0, 11.0])
    pressure_valid = np.array([50.0, 55.0, 52.0])
    latitude_valid = np.array([30.0, 30.0, 30.0])
    longitude_valid = np.array([0.0, 0.0, 0.0])

    # --------------------------
    # Type checks
    # --------------------------
    with pytest.raises(TypeError) as excinfo:
        ctp2salinity(
            {"wrong": "type"},
            temperature_valid,
            pressure_valid,
            latitude_valid,
            longitude_valid,
        )
    assert "Conductivity must be a float or an array." in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        ctp2salinity(
            conductivity_valid,
            "not a float or array",
            pressure_valid,
            latitude_valid,
            longitude_valid,
        )
    assert "Temperature must be a float or an array." in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        ctp2salinity(
            conductivity_valid,
            temperature_valid,
            {"bad": "pressure"},
            latitude_valid,
            longitude_valid,
        )
    assert "Pressure must be a float or an array." in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        ctp2salinity(
            conductivity_valid,
            temperature_valid,
            pressure_valid,
            "invalid",
            longitude_valid,
        )
    assert "Latitude must be a float or an array." in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        ctp2salinity(
            conductivity_valid,
            temperature_valid,
            pressure_valid,
            latitude_valid,
            "invalid",
        )
    assert "Longitude must be a float or an array." in str(excinfo.value)

    # --------------------------
    # Shape checks: multidimensional arrays
    # --------------------------
    conductivity_multi = np.array([[1.0, 1.2, 0.9], [1.0, 1.2, 0.9]])
    with pytest.raises(ValueError) as excinfo:
        ctp2salinity(
            conductivity_multi,
            temperature_valid,
            pressure_valid,
            latitude_valid,
            longitude_valid,
        )
    assert "Conductivity must be a 1D array." in str(excinfo.value)

    temperature_multi = np.array([[10.0, 12.0, 11.0], [10.0, 12.0, 11.0]])
    with pytest.raises(ValueError) as excinfo:
        ctp2salinity(
            conductivity_valid,
            temperature_multi,
            pressure_valid,
            latitude_valid,
            longitude_valid,
        )
    assert "Temperature must be a 1D array." in str(excinfo.value)

    pressure_multi = np.array([[50.0, 55.0, 52.0], [50.0, 55.0, 52.0]])
    with pytest.raises(ValueError) as excinfo:
        ctp2salinity(
            conductivity_valid,
            temperature_valid,
            pressure_multi,
            latitude_valid,
            longitude_valid,
        )
    assert "Pressure must be a 1D array." in str(excinfo.value)

    # --------------------------
    # Same shape check: mismatch between inputs
    # --------------------------
    temperature_diff = np.array([10.0, 12.0])  # shape mismatch with valid inputs
    with pytest.raises(ValueError) as excinfo:
        ctp2salinity(
            conductivity_valid,
            temperature_diff,
            pressure_valid,
            latitude_valid,
            longitude_valid,
        )
    assert "must have the same shape" in str(excinfo.value)

    # --------------------------
    # Latitude range check [-90,90]
    # --------------------------
    latitude_invalid = np.array([30.0, 95.0, 30.0])
    with pytest.raises(ValueError) as excinfo:
        ctp2salinity(
            conductivity_valid,
            temperature_valid,
            pressure_valid,
            latitude_invalid,
            longitude_valid,
        )
    assert "Latitude must be between -90 and 90 degrees." in str(excinfo.value)

    # --------------------------
    # Longitude range check [-360,360]
    # --------------------------
    longitude_invalid = np.array([0.0, 400.0, 0.0])
    with pytest.raises(ValueError) as excinfo:
        ctp2salinity(
            conductivity_valid,
            temperature_valid,
            pressure_valid,
            latitude_valid,
            longitude_invalid,
        )
    assert "Longitude must be between -360 and 360 degrees." in str(excinfo.value)


def test_ctd2salinity_raise_checks():
    # Valid base inputs for later tests (all arrays are 1D and of same shape)
    conductivity_valid = np.array([1.0, 1.2, 0.9])
    temperature_valid = np.array([10.0, 12.0, 11.0])
    depth_valid = -np.array([100.0, 200.0, 150.0])  # negative values
    latitude_valid = np.array([30.0, 30.0, 30.0])
    longitude_valid = np.array([0.0, 0.0, 0.0])

    # --------------------------
    # Type checks
    # --------------------------
    with pytest.raises(TypeError) as excinfo:
        ctd2salinity(
            {"wrong": "type"},
            temperature_valid,
            depth_valid,
            latitude_valid,
            longitude_valid,
        )
    assert "Conductivity must be a float or an array." in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        ctd2salinity(
            conductivity_valid,
            "not a float or array",
            depth_valid,
            latitude_valid,
            longitude_valid,
        )
    assert "Temperature must be a float or an array." in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        ctd2salinity(
            conductivity_valid,
            temperature_valid,
            {"bad": "depth"},
            latitude_valid,
            longitude_valid,
        )
    assert "Depth must be a float or an array." in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        ctd2salinity(
            conductivity_valid,
            temperature_valid,
            depth_valid,
            "invalid",
            longitude_valid,
        )
    assert "Latitude must be a float or an array." in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        ctd2salinity(
            conductivity_valid,
            temperature_valid,
            depth_valid,
            latitude_valid,
            "invalid",
        )
    assert "Longitude must be a float or an array." in str(excinfo.value)

    # --------------------------
    # Shape checks: multidimensional arrays
    # --------------------------
    conductivity_multi = np.array([[1.0, 1.2, 0.9], [1.0, 1.2, 0.9]])
    with pytest.raises(ValueError) as excinfo:
        ctd2salinity(
            conductivity_multi,
            temperature_valid,
            depth_valid,
            latitude_valid,
            longitude_valid,
        )
    assert "Conductivity must be a 1D array." in str(excinfo.value)

    temperature_multi = np.array([[10.0, 12.0, 11.0], [10.0, 12.0, 11.0]])
    with pytest.raises(ValueError) as excinfo:
        ctd2salinity(
            conductivity_valid,
            temperature_multi,
            depth_valid,
            latitude_valid,
            longitude_valid,
        )
    assert "Temperature must be a 1D array." in str(excinfo.value)

    depth_multi = np.array([[100.0, 200.0, 150.0], [100.0, 200.0, 150.0]])
    with pytest.raises(ValueError) as excinfo:
        ctd2salinity(
            conductivity_valid,
            temperature_valid,
            depth_multi,
            latitude_valid,
            longitude_valid,
        )
    assert "Depth must be a 1D array." in str(excinfo.value)

    # --------------------------
    # Same shape check: mismatch between inputs
    # --------------------------
    temperature_diff = np.array([10.0, 12.0])  # shape mismatch
    with pytest.raises(ValueError) as excinfo:
        ctd2salinity(
            conductivity_valid,
            temperature_diff,
            depth_valid,
            latitude_valid,
            longitude_valid,
        )
    assert "must have the same shape" in str(excinfo.value)

    # --------------------------
    # Depth must be negative
    # --------------------------
    depth_positive = np.array([100.0, 200.0, 150.0])
    with pytest.raises(ValueError) as excinfo:
        ctd2salinity(
            conductivity_valid,
            temperature_valid,
            depth_positive,
            latitude_valid,
            longitude_valid,
        )
    assert "Depth must be negative." in str(excinfo.value)

    # --------------------------
    # Latitude range check [-90,90]
    # --------------------------
    latitude_invalid = np.array([30.0, 95.0, 30.0])
    with pytest.raises(ValueError) as excinfo:
        ctd2salinity(
            conductivity_valid,
            temperature_valid,
            depth_valid,
            latitude_invalid,
            longitude_valid,
        )
    assert "Latitude must be between -90 and 90 degrees." in str(excinfo.value)

    # --------------------------
    # Longitude range check [-360,360]
    # --------------------------
    longitude_invalid = np.array([0.0, 400.0, 0.0])
    with pytest.raises(ValueError) as excinfo:
        ctd2salinity(
            conductivity_valid,
            temperature_valid,
            depth_valid,
            latitude_valid,
            longitude_invalid,
        )
    assert "Longitude must be between -360 and 360 degrees." in str(excinfo.value)


def test_ctp2pden_raise_checks():
    # Valid base inputs (all 1D arrays with matching shapes)
    conductivity_valid = np.array([1.0, 1.2, 0.9])
    temperature_valid = np.array([10.0, 12.0, 11.0])
    pressure_valid = np.array([50.0, 55.0, 52.0])
    latitude_valid = np.array([30.0, 30.0, 30.0])
    longitude_valid = np.array([0.0, 0.0, 0.0])
    pressure_reference_valid = np.array([0.0, 0.0, 0.0])

    # --------------------------
    # Type checks
    # --------------------------
    with pytest.raises(TypeError) as excinfo:
        ctp2pden(
            {"wrong": "type"},
            temperature_valid,
            pressure_valid,
            latitude_valid,
            longitude_valid,
            pressure_reference_valid,
        )
    assert "Conductivity must be a float or an array." in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        ctp2pden(
            conductivity_valid,
            "not a float or array",
            pressure_valid,
            latitude_valid,
            longitude_valid,
            pressure_reference_valid,
        )
    assert "Temperature must be a float or an array." in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        ctp2pden(
            conductivity_valid,
            temperature_valid,
            {"bad": "pressure"},
            latitude_valid,
            longitude_valid,
            pressure_reference_valid,
        )
    assert "Pressure must be a float or an array." in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        ctp2pden(
            conductivity_valid,
            temperature_valid,
            pressure_valid,
            "invalid",
            longitude_valid,
            pressure_reference_valid,
        )
    assert "Latitude must be a float or an array." in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        ctp2pden(
            conductivity_valid,
            temperature_valid,
            pressure_valid,
            latitude_valid,
            "invalid",
            pressure_reference_valid,
        )
    assert "Longitude must be a float or an array." in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        ctp2pden(
            conductivity_valid,
            temperature_valid,
            pressure_valid,
            latitude_valid,
            longitude_valid,
            "invalid",
        )
    assert "Pressure reference must be a float or an array." in str(excinfo.value)

    # --------------------------
    # Shape checks: multidimensional arrays
    # --------------------------
    conductivity_multi = np.array([[1.0, 1.2, 0.9], [1.0, 1.2, 0.9]])
    with pytest.raises(ValueError) as excinfo:
        ctp2pden(
            conductivity_multi,
            temperature_valid,
            pressure_valid,
            latitude_valid,
            longitude_valid,
            pressure_reference_valid,
        )
    assert "Conductivity must be a 1D array." in str(excinfo.value)

    temperature_multi = np.array([[10.0, 12.0, 11.0], [10.0, 12.0, 11.0]])
    with pytest.raises(ValueError) as excinfo:
        ctp2pden(
            conductivity_valid,
            temperature_multi,
            pressure_valid,
            latitude_valid,
            longitude_valid,
            pressure_reference_valid,
        )
    assert "Temperature must be a 1D array." in str(excinfo.value)

    pressure_multi = np.array([[50.0, 55.0, 52.0], [50.0, 55.0, 52.0]])
    with pytest.raises(ValueError) as excinfo:
        ctp2pden(
            conductivity_valid,
            temperature_valid,
            pressure_multi,
            latitude_valid,
            longitude_valid,
            pressure_reference_valid,
        )
    assert "Pressure must be a 1D array." in str(excinfo.value)

    pressure_reference_multi = np.array([[0.0, 0.0, 0.0], [0.0, 0.0, 0.0]])
    with pytest.raises(ValueError) as excinfo:
        ctp2pden(
            conductivity_valid,
            temperature_valid,
            pressure_valid,
            latitude_valid,
            longitude_valid,
            pressure_reference_multi,
        )
    assert "Pressure reference must be a 1D array." in str(excinfo.value)

    # --------------------------
    # Same shape check: mismatch between inputs
    # --------------------------
    temperature_diff = np.array([10.0, 12.0])  # shape mismatch with valid inputs
    with pytest.raises(ValueError) as excinfo:
        ctp2pden(
            conductivity_valid,
            temperature_diff,
            pressure_valid,
            latitude_valid,
            longitude_valid,
            pressure_reference_valid,
        )
    assert "must have the same shape" in str(excinfo.value)

    # --------------------------
    # Latitude range check [-90,90]
    # --------------------------
    latitude_invalid = np.array([30.0, 95.0, 30.0])
    with pytest.raises(ValueError) as excinfo:
        ctp2pden(
            conductivity_valid,
            temperature_valid,
            pressure_valid,
            latitude_invalid,
            longitude_valid,
            pressure_reference_valid,
        )
    assert "Latitude must be between -90 and 90 degrees." in str(excinfo.value)

    # --------------------------
    # Longitude range check [-360,360]
    # --------------------------
    longitude_invalid = np.array([0.0, 400.0, 0.0])
    with pytest.raises(ValueError) as excinfo:
        ctp2pden(
            conductivity_valid,
            temperature_valid,
            pressure_valid,
            latitude_valid,
            longitude_invalid,
            pressure_reference_valid,
        )
    assert "Longitude must be between -360 and 360 degrees." in str(excinfo.value)


def test_ctd2oxygen_saturation_raise_checks():
    # Valid base inputs (all 1D arrays with matching shapes; note that depth must be negative)
    conductivity_valid = np.array([1.0, 1.2, 0.9])
    temperature_valid = np.array([10.0, 12.0, 11.0])
    depth_valid = -np.array([100.0, 200.0, 150.0])  # negative values
    latitude_valid = np.array([30.0, 30.0, 30.0])
    longitude_valid = np.array([0.0, 0.0, 0.0])

    # A basic valid call should return an output without raising errors.
    o2sol = ctd2oxygen_saturation(
        conductivity_valid,
        temperature_valid,
        depth_valid,
        latitude_valid,
        longitude_valid,
    )
    assert isinstance(o2sol, np.ndarray)
    assert o2sol.shape == depth_valid.shape

    # --------------------------
    # Type checks
    # --------------------------
    with pytest.raises(TypeError) as excinfo:
        ctd2oxygen_saturation(
            {"wrong": "type"},
            temperature_valid,
            depth_valid,
            latitude_valid,
            longitude_valid,
        )
    assert "Conductivity must be a float or an array." in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        ctd2oxygen_saturation(
            conductivity_valid,
            "not a float or array",
            depth_valid,
            latitude_valid,
            longitude_valid,
        )
    assert "Temperature must be a float or an array." in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        ctd2oxygen_saturation(
            conductivity_valid,
            temperature_valid,
            {"bad": "depth"},
            latitude_valid,
            longitude_valid,
        )
    assert "Depth must be a float or an array." in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        ctd2oxygen_saturation(
            conductivity_valid,
            temperature_valid,
            depth_valid,
            "invalid",
            longitude_valid,
        )
    assert "Latitude must be a float or an array." in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        ctd2oxygen_saturation(
            conductivity_valid,
            temperature_valid,
            depth_valid,
            latitude_valid,
            "invalid",
        )
    assert "Longitude must be a float or an array." in str(excinfo.value)

    # --------------------------
    # Shape checks: multidimensional arrays
    # --------------------------
    conductivity_multi = np.array([[1.0, 1.2, 0.9], [1.0, 1.2, 0.9]])
    with pytest.raises(ValueError) as excinfo:
        ctd2oxygen_saturation(
            conductivity_multi,
            temperature_valid,
            depth_valid,
            latitude_valid,
            longitude_valid,
        )
    assert "Conductivity must be a 1D array." in str(excinfo.value)

    temperature_multi = np.array([[10.0, 12.0, 11.0], [10.0, 12.0, 11.0]])
    with pytest.raises(ValueError) as excinfo:
        ctd2oxygen_saturation(
            conductivity_valid,
            temperature_multi,
            depth_valid,
            latitude_valid,
            longitude_valid,
        )
    assert "Temperature must be a 1D array." in str(excinfo.value)

    depth_multi = np.array([[-100.0, -200.0, -150.0], [-100.0, -200.0, -150.0]])
    with pytest.raises(ValueError) as excinfo:
        ctd2oxygen_saturation(
            conductivity_valid,
            temperature_valid,
            depth_multi,
            latitude_valid,
            longitude_valid,
        )
    assert "Depth must be a 1D array." in str(excinfo.value)

    # --------------------------
    # Same shape check: mismatch between inputs
    # --------------------------
    temperature_diff = np.array([10.0, 12.0])  # shape mismatch with valid inputs
    with pytest.raises(ValueError) as excinfo:
        ctd2oxygen_saturation(
            conductivity_valid,
            temperature_diff,
            depth_valid,
            latitude_valid,
            longitude_valid,
        )
    assert "must have the same shape" in str(excinfo.value)

    # --------------------------
    # Depth negativity check
    # --------------------------
    depth_positive = np.array([100.0, 200.0, 150.0])
    with pytest.raises(ValueError) as excinfo:
        ctd2oxygen_saturation(
            conductivity_valid,
            temperature_valid,
            depth_positive,
            latitude_valid,
            longitude_valid,
        )
    assert "Depth must be negative." in str(excinfo.value)

    # --------------------------
    # Latitude range check [-90,90]
    # --------------------------
    latitude_invalid = np.array([30.0, 95.0, 30.0])
    with pytest.raises(ValueError) as excinfo:
        ctd2oxygen_saturation(
            conductivity_valid,
            temperature_valid,
            depth_valid,
            latitude_invalid,
            longitude_valid,
        )
    assert "Latitude must be between -90 and 90 degrees." in str(excinfo.value)

    # --------------------------
    # Longitude range check [-360,360]
    # --------------------------
    longitude_invalid = np.array([0.0, 400.0, 0.0])
    with pytest.raises(ValueError) as excinfo:
        ctd2oxygen_saturation(
            conductivity_valid,
            temperature_valid,
            depth_valid,
            latitude_valid,
            longitude_invalid,
        )
    assert "Longitude must be between -360 and 360 degrees." in str(excinfo.value)
