# import methods from the corresponding modules
from .plots import (
    plot_axis_comparison,
    plot_axis_timeseries,
    plot_magnetic_field,
    plot_magnetic_field_comparison,
    plot_trajectory,
    plot_trajectory_comparison,
    plot_triaxial_comparison,
    plot_triaxial_timeseries,
)

__all__ = [
    "plot_triaxial_timeseries",
    "plot_triaxial_comparison",
    "plot_axis_timeseries",
    "plot_axis_comparison",
    "plot_magnetic_field",
    "plot_magnetic_field_comparison",
    "plot_trajectory",
    "plot_trajectory_comparison",
]
