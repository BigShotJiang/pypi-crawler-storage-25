"""
plots.py — Sensor data visualization utilities for underwater robotics platforms.

Functions:
    plot_triaxial_timeseries: Plot triaxial (3-axis) sensor data over time.
    plot_triaxial_comparison: Plot triaxial sensor data from multiple sensors.
    plot_axis_timeseries: Plot a single axis from a sensor over time.
    plot_axis_comparison: Plot a single axis from multiple sensors.
    plot_magnetic_field: Plot magnetic field vectors on a unit sphere.
    plot_magnetic_field_comparison: Plot magnetic field vectors from multiple sensors.
    plot_trajectory: Plot a 2D trajectory with optional Z-based colormap.
    plot_trajectory_comparison: Plot multiple 2D trajectories for comparison.

Authors: CoMPAS Lab
Contact: srodriguez@mbari.org
"""

import warnings

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.collections import LineCollection

from ..math.vmath import norm, normalize


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _scale_time_array(time, unit="auto"):
    """
    Scales a time array and returns the corresponding label.

    Args:
        time (array-like): Timestamps in seconds.
        unit (str): 'auto', 's', 'min', or 'h'.

    Returns:
        tuple: (scaled_time, time_label)
    """
    time = np.asarray(time)
    if time.size < 2:
        raise ValueError("Time array must contain at least two points.")

    if unit == "auto":
        duration = time[-1] - time[0]
        if duration > 3600:
            unit = "h"
        elif duration > 120:
            unit = "min"
        else:
            unit = "s"

    if unit == "h":
        return time / 3600, "Time (h)"
    elif unit == "min":
        return time / 60, "Time (min)"
    else:
        return time, "Time (s)"


def _apply_geotiff_background(ax, background_png, background_tfw, x, y):
    """
    Overlays a georeferenced PNG background on an axes, cropped to the trajectory bounds.

    Args:
        ax (matplotlib.axes.Axes): Target axes.
        background_png (str): Path to background PNG image.
        background_tfw (str): Path to corresponding TFW world file.
        x (np.ndarray): Trajectory X coordinates.
        y (np.ndarray): Trajectory Y coordinates.
    """
    try:
        import matplotlib.image as mpimg

        with open(background_tfw, "r") as f:
            lines = f.readlines()
            pixel_size_x = float(lines[0].strip())
            rotation_x = float(lines[1].strip())
            rotation_y = float(lines[2].strip())
            pixel_size_y = float(lines[3].strip())
            upper_left_x = float(lines[4].strip())
            upper_left_y = float(lines[5].strip())

        img = mpimg.imread(background_png)
        height, width = img.shape[:2]

        if rotation_x != 0 or rotation_y != 0:
            warnings.warn(
                "Rotated georeferenced images are not fully supported.",
                UserWarning,
            )
            return

        img_x_min = upper_left_x
        img_x_max = upper_left_x + width * pixel_size_x
        img_y_max = upper_left_y
        img_y_min = upper_left_y + height * pixel_size_y

        x_range = x.max() - x.min()
        y_range = y.max() - y.min()
        padding_x = x_range * 0.1
        padding_y = y_range * 0.1

        plot_x_min = x.min() - padding_x
        plot_x_max = x.max() + padding_x
        plot_y_min = y.min() - padding_y
        plot_y_max = y.max() + padding_y

        clip_x_min = max(img_x_min, plot_x_min)
        clip_x_max = min(img_x_max, plot_x_max)
        clip_y_min = max(img_y_min, plot_y_min)
        clip_y_max = min(img_y_max, plot_y_max)

        if clip_x_min >= clip_x_max or clip_y_min >= clip_y_max:
            return  # No overlap between image and trajectory

        pixel_x_start = max(0, min(int((clip_x_min - img_x_min) / pixel_size_x), width))
        pixel_x_end = max(0, min(int((clip_x_max - img_x_min) / pixel_size_x), width))
        pixel_y_start = max(
            0, min(int((img_y_max - clip_y_max) / abs(pixel_size_y)), height)
        )
        pixel_y_end = max(
            0, min(int((img_y_max - clip_y_min) / abs(pixel_size_y)), height)
        )

        cropped_img = img[pixel_y_start:pixel_y_end, pixel_x_start:pixel_x_end]
        if cropped_img.size > 0:
            ax.imshow(
                cropped_img,
                extent=[clip_x_min, clip_x_max, clip_y_min, clip_y_max],
                origin="upper",
                alpha=0.7,
                aspect="auto",
            )
            ax.set_xlim(plot_x_min, plot_x_max)
            ax.set_ylim(plot_y_min, plot_y_max)

    except Exception as e:
        warnings.warn(f"Could not load background image: {e}", UserWarning)


def _draw_unit_sphere(ax, alpha=0.5):
    """Draw a unit sphere wireframe on a 3D axes."""
    u = np.linspace(0, 2 * np.pi, 100)
    v = np.linspace(0, np.pi, 100)
    xs = np.outer(np.cos(u), np.sin(v))
    ys = np.outer(np.sin(u), np.sin(v))
    zs = np.outer(np.ones_like(u), np.cos(v))
    ax.plot_wireframe(
        xs, ys, zs, rstride=10, cstride=10, color="black", linewidth=0.5, alpha=alpha
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def plot_triaxial_timeseries(
    time,
    data,
    axis_labels=("X", "Y", "Z"),
    title="3-Axis Sensor Data",
    units="",
    remove_time_offset=True,
    time_unit="auto",
    figsize=(8, 6),
    legend=False,
    legend_loc="best",
    grid=True,
    sharex=True,
    colors=("tab:blue", "tab:orange", "tab:green"),
    xlim=None,
    ylim=None,
    save_path=None,
    magnitude=False,
    show=True,
    close=False,
    ax=None,
):
    """
    Plot triaxial (3-axis) sensor data over time, with one subplot per axis
    and an optional magnitude subplot.

    Args:
        time (array-like): 1D array of timestamps in seconds.
        data (array-like): Array of shape (N, 3).
        axis_labels (tuple): Labels for X, Y, Z axes.
        title (str): Figure title.
        units (str): Units for y-axis labels.
        remove_time_offset (bool): If True, subtracts the first timestamp.
        time_unit (str): 'auto', 's', 'min', or 'h'.
        figsize (tuple): Figure size.
        legend (bool): Show per-subplot legends.
        legend_loc (str): Legend location.
        grid (bool): Show grid.
        sharex (bool): Share x-axis across subplots.
        colors (tuple): Colors for each axis.
        xlim (tuple): X-axis limits.
        ylim (tuple): Y-axis limits (applied to axis subplots only, not the
            magnitude subplot).
        save_path (str): If provided, saves the figure to this path.
        magnitude (bool): If True, adds a magnitude subplot.
        show (bool): If True, calls plt.show(). Set to False when embedding in
            a larger figure or running headless.
        close (bool): If True, closes the figure after showing.
        ax (array-like, optional): Pre-existing axes to plot into. Must contain
            at least 3 elements (4 when magnitude=True).

    Returns:
        tuple: (fig, axes)
    """
    time = np.asarray(time)
    data = np.asarray(data)

    if time.size < 2:
        raise ValueError("Time array must contain at least two points.")
    if data.ndim != 2 or data.shape[1] != 3:
        raise ValueError("Data must have shape (N, 3).")

    if remove_time_offset:
        time = time - time[0]

    time, x_label = _scale_time_array(time, time_unit)

    n_subplots = 4 if magnitude else 3

    created_fig = ax is None
    if created_fig:
        fig, axes = plt.subplots(n_subplots, 1, figsize=figsize, sharex=sharex)
    else:
        axes = ax
        fig = axes[0].get_figure()

    for i in range(3):
        axes[i].plot(time, data[:, i], color=colors[i], label=axis_labels[i])
        axes[i].set_ylabel(f"{axis_labels[i]} ({units})" if units else axis_labels[i])
        if legend:
            axes[i].legend(loc=legend_loc)
        if grid:
            axes[i].grid(True)
        if xlim:
            axes[i].set_xlim(xlim)
        if ylim:
            axes[i].set_ylim(ylim)

    if magnitude:
        mag = norm(data)
        axes[3].plot(time, mag, color="tab:red", label="|M|")
        axes[3].set_ylabel(f"Magnitude ({units})" if units else "Magnitude")
        if legend:
            axes[3].legend(loc=legend_loc)
        if grid:
            axes[3].grid(True)
        if xlim:
            axes[3].set_xlim(xlim)

    axes[-1].set_xlabel(x_label)
    fig.suptitle(title)

    if created_fig:
        plt.tight_layout(rect=[0, 0, 1, 0.96])

    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
    if show:
        plt.show()
    if close:
        plt.close(fig)

    return fig, axes


def plot_triaxial_comparison(
    time_data,
    sensor_data,
    sensor_names,
    axis_labels=("X", "Y", "Z"),
    title="Multi-Sensor 3-Axis Comparison",
    units="",
    remove_time_offset=True,
    time_unit="auto",
    figsize=(8, 6),
    legend=True,
    grid=True,
    sharex=True,
    colors=None,
    linestyles=None,
    xlim=None,
    ylim=None,
    save_path=None,
    magnitude=False,
    show=True,
    close=False,
    ax=None,
):
    """
    Plot triaxial sensor data from multiple sensors for comparison, with one
    subplot per axis and an optional magnitude subplot.

    Args:
        time_data (array-like or list): Shared time array or list of per-sensor arrays.
        sensor_data (list): List of (N_i, 3) arrays, one per sensor.
        sensor_names (list): Labels for each sensor.
        axis_labels (tuple): Labels for X, Y, Z axes.
        title (str): Figure title.
        units (str): Units for y-axis labels.
        remove_time_offset (bool): If True, subtracts the first timestamp per sensor.
        time_unit (str): 'auto', 's', 'min', or 'h'.
        figsize (tuple): Figure size.
        legend (bool): Show a shared legend below the figure.
        grid (bool): Show grid.
        sharex (bool): Share x-axis across subplots.
        colors (list): Colors for each sensor. Defaults to tab10.
        linestyles (list): Linestyles for each sensor.
        xlim (tuple): X-axis limits.
        ylim (tuple): Y-axis limits (applied to axis subplots only, not the
            magnitude subplot).
        save_path (str): If provided, saves the figure to this path.
        magnitude (bool): If True, adds a magnitude subplot.
        show (bool): If True, calls plt.show(). Set to False when embedding in
            a larger figure or running headless.
        close (bool): If True, closes the figure after showing.
        ax (array-like, optional): Pre-existing axes to plot into. Must contain
            at least 3 elements (4 when magnitude=True).

    Returns:
        tuple: (fig, axes)
    """
    n_sensors = len(sensor_data)
    if len(sensor_names) != n_sensors:
        raise ValueError("sensor_names length must match sensor_data length.")

    if isinstance(time_data, (list, tuple)):
        if len(time_data) != n_sensors:
            raise ValueError("time_data list length must match sensor_data length.")
        times = [np.asarray(t) for t in time_data]
    else:
        times = [np.asarray(time_data) for _ in range(n_sensors)]

    sensors = []
    for i, data in enumerate(sensor_data):
        data = np.asarray(data)
        if data.ndim != 2 or data.shape[1] != 3:
            raise ValueError(f"Sensor {i} data must have shape (N, 3).")
        sensors.append(data)

    if colors is None:
        colors = list(plt.colormaps["tab10"].colors[:n_sensors])
    if linestyles is None:
        linestyles = ["-"] * n_sensors

    processed_times = []
    x_labels = []
    for time in times:
        if remove_time_offset:
            time = time - time[0]
        scaled_time, x_label = _scale_time_array(time, time_unit)
        processed_times.append(scaled_time)
        x_labels.append(x_label)

    longest_idx = int(np.argmax([t[-1] - t[0] for t in processed_times]))
    shared_x_label = x_labels[longest_idx]

    n_subplots = 4 if magnitude else 3

    created_fig = ax is None
    if created_fig:
        fig, axes = plt.subplots(n_subplots, 1, figsize=figsize, sharex=sharex)
    else:
        axes = ax
        fig = axes[0].get_figure()

    plot_handles = []

    for axis_idx in range(3):
        for sensor_idx in range(n_sensors):
            (line,) = axes[axis_idx].plot(
                processed_times[sensor_idx],
                sensors[sensor_idx][:, axis_idx],
                color=colors[sensor_idx],
                linestyle=linestyles[sensor_idx],
                label=sensor_names[sensor_idx],
                alpha=0.65,
            )
            if axis_idx == 0:
                plot_handles.append(line)

        axes[axis_idx].set_ylabel(
            f"{axis_labels[axis_idx]} ({units})" if units else axis_labels[axis_idx]
        )
        if grid:
            axes[axis_idx].grid(True, alpha=0.3)
        if xlim:
            axes[axis_idx].set_xlim(xlim)
        if ylim:
            axes[axis_idx].set_ylim(ylim)

    if magnitude:
        for sensor_idx in range(n_sensors):
            mag = norm(sensors[sensor_idx])
            axes[3].plot(
                processed_times[sensor_idx],
                mag,
                color=colors[sensor_idx],
                linestyle=linestyles[sensor_idx],
                alpha=0.65,
            )
        axes[3].set_ylabel(f"Magnitude ({units})" if units else "Magnitude")
        if grid:
            axes[3].grid(True, alpha=0.3)
        if xlim:
            axes[3].set_xlim(xlim)

    axes[-1].set_xlabel(shared_x_label)
    fig.suptitle(title)

    if legend:
        fig.legend(
            handles=plot_handles,
            labels=sensor_names,
            loc="lower center",
            ncol=n_sensors,
            frameon=False,
            bbox_to_anchor=(0.5, 0.01),
        )

    if created_fig:
        plt.tight_layout(rect=[0, 0.05, 1, 0.95])

    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
    if show:
        plt.show()
    if close:
        plt.close(fig)

    return fig, axes


def plot_axis_timeseries(
    time,
    data,
    axis_label="",
    axis_index=0,
    title="Single Axis Sensor Data",
    units="",
    remove_time_offset=True,
    time_unit="auto",
    figsize=(8, 6),
    grid=True,
    color="tab:blue",
    xlim=None,
    ylim=None,
    save_path=None,
    show=True,
    close=False,
    ax=None,
):
    """
    Plot a single axis from a sensor (or multidimensional array) over time.

    Args:
        time (array-like): 1D array of timestamps (in seconds).
        data (array-like): N-dimensional data array. axis_index selects the desired column.
        axis_label (str): Label for the axis being plotted.
        axis_index (int): Axis index to plot if data has more than one dimension.
        title (str): Plot title.
        units (str): Units for the y-axis label.
        remove_time_offset (bool): If True, subtracts the first timestamp.
        time_unit (str): 'auto', 's', 'min', or 'h' for time axis scaling.
        figsize (tuple): Figure size.
        grid (bool): Show grid on plot.
        color (str): Color for the line.
        xlim (tuple): X-axis limits.
        ylim (tuple): Y-axis limits.
        save_path (str): If provided, saves the figure to this path.
        show (bool): If True, calls plt.show(). Set to False when embedding in
            a larger figure or running headless.
        close (bool): If True, closes the figure after showing.
        ax (matplotlib.axes.Axes, optional): Pre-existing axes to plot into.

    Returns:
        tuple: (fig, ax)
    """
    time = np.asarray(time).squeeze()
    data = np.asarray(data)

    if time.ndim != 1:
        raise ValueError("Time must be a 1D array.")
    if time.size < 2:
        raise ValueError("Time array must contain at least two points.")

    if data.ndim == 1:
        axis_data = data
    else:
        if axis_index >= data.shape[1]:
            raise ValueError(
                f"axis_index {axis_index} out of bounds for data with shape {data.shape}."
            )
        axis_data = data[:, axis_index]

    axis_data = np.squeeze(axis_data)
    if axis_data.shape[0] != time.shape[0]:
        raise ValueError("Time and data must have the same number of samples.")

    if remove_time_offset:
        time = time - time[0]

    time, x_label = _scale_time_array(time, time_unit)

    created_fig = ax is None
    if created_fig:
        fig, ax = plt.subplots(1, 1, figsize=figsize)
    else:
        fig = ax.get_figure()

    ax.plot(time, axis_data, color=color, alpha=0.65, linewidth=1.5)
    ax.set_xlabel(x_label)
    y_label = axis_label if axis_label else f"Axis {axis_index}"
    y_label += f" ({units})" if units else ""
    ax.set_ylabel(y_label)
    ax.set_title(title)

    if grid:
        ax.grid(True, alpha=0.3)
    if xlim:
        ax.set_xlim(xlim)
    if ylim:
        ax.set_ylim(ylim)

    if created_fig:
        plt.tight_layout()

    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
    if show:
        plt.show()
    if close:
        plt.close(fig)

    return fig, ax


def plot_axis_comparison(
    time_data,
    sensor_data,
    sensor_names,
    axis_index=0,
    axis_label="",
    title="Single Axis Sensor Comparison",
    units="",
    remove_time_offset=True,
    time_unit="auto",
    figsize=(8, 6),
    legend=True,
    grid=True,
    colors=None,
    linestyles=None,
    xlim=None,
    ylim=None,
    save_path=None,
    show=True,
    close=False,
    ax=None,
):
    """
    Plot a single axis from multiple sensors for detailed comparison.

    Args:
        time_data (array-like or list): Shared time array or list of per-sensor time arrays.
        sensor_data (list): List of arrays to compare.
        sensor_names (list): Labels for each sensor.
        axis_index (int): Column index to extract from multi-dimensional data.
        axis_label (str): Label for the y-axis.
        title (str): Plot title.
        units (str): Units for the y-axis label.
        remove_time_offset (bool): If True, subtracts the first timestamp per sensor.
        time_unit (str): 'auto', 's', 'min', or 'h'.
        figsize (tuple): Figure size.
        legend (bool): Show a shared legend below the figure.
        grid (bool): Show grid.
        colors (list): Colors for each sensor. Defaults to tab10.
        linestyles (list): Linestyles for each sensor.
        xlim (tuple): X-axis limits.
        ylim (tuple): Y-axis limits.
        save_path (str): If provided, saves the figure to this path.
        show (bool): If True, calls plt.show(). Set to False when embedding in
            a larger figure or running headless.
        close (bool): If True, closes the figure after showing.
        ax (matplotlib.axes.Axes, optional): Pre-existing axes to plot into.

    Returns:
        tuple: (fig, ax)
    """
    n_sensors = len(sensor_data)
    if len(sensor_names) != n_sensors:
        raise ValueError("sensor_names length must match sensor_data length.")

    if isinstance(time_data, (list, tuple)):
        if len(time_data) != n_sensors:
            raise ValueError("time_data list length must match sensor_data length.")
        times = [np.asarray(t).squeeze() for t in time_data]
    else:
        times = [np.asarray(time_data).squeeze() for _ in range(n_sensors)]

    extracted_data = []
    for i, data in enumerate(sensor_data):
        data = np.asarray(data)
        if data.ndim == 1:
            axis_data = data
        else:
            if axis_index >= data.shape[1]:
                raise ValueError(
                    f"axis_index {axis_index} out of bounds for sensor {i} with shape {data.shape}."
                )
            axis_data = data[:, axis_index]
        axis_data = np.squeeze(axis_data)
        if axis_data.shape[0] != times[i].shape[0]:
            raise ValueError(f"Sensor {i}: time and data length mismatch.")
        extracted_data.append(axis_data)

    if colors is None:
        colors = list(plt.colormaps["tab10"].colors[:n_sensors])
    if linestyles is None:
        linestyles = ["-"] * n_sensors

    processed_times = []
    x_labels = []
    for time in times:
        if remove_time_offset:
            time = time - time[0]
        scaled_time, x_label = _scale_time_array(time, time_unit)
        processed_times.append(scaled_time)
        x_labels.append(x_label)

    longest_idx = int(np.argmax([t[-1] - t[0] for t in processed_times]))
    shared_x_label = x_labels[longest_idx]

    created_fig = ax is None
    if created_fig:
        fig, ax = plt.subplots(1, 1, figsize=figsize)
    else:
        fig = ax.get_figure()

    plot_handles = []
    for i in range(n_sensors):
        (line,) = ax.plot(
            processed_times[i],
            extracted_data[i],
            color=colors[i],
            linestyle=linestyles[i],
            label=sensor_names[i],
            alpha=0.65,
            linewidth=1.5,
        )
        plot_handles.append(line)

    ax.set_xlabel(shared_x_label)
    y_label = axis_label if axis_label else f"Axis {axis_index}"
    y_label += f" ({units})" if units else ""
    ax.set_ylabel(y_label)
    ax.set_title(title)

    if grid:
        ax.grid(True, alpha=0.3)
    if xlim:
        ax.set_xlim(xlim)
    if ylim:
        ax.set_ylim(ylim)

    if legend:
        fig.legend(
            handles=plot_handles,
            labels=sensor_names,
            loc="lower center",
            ncol=n_sensors,
            frameon=False,
            bbox_to_anchor=(0.5, 0.01),
        )

    if created_fig:
        plt.tight_layout(rect=[0, 0.05, 1, 0.95])

    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
    if show:
        plt.show()
    if close:
        plt.close(fig)

    return fig, ax


def plot_magnetic_field(
    vectors,
    title="Magnetic Field on Unit Sphere",
    sphere_alpha=0.5,
    marker=".",
    units="",
    figsize=(6, 6),
    save_path=None,
    show=True,
    close=False,
    ax=None,
):
    """
    Plots the direction of magnetic field vectors as scatter points on a unit sphere.

    Args:
        vectors (array-like): (N, 3) array of magnetic field vectors.
        title (str): Title for the plot.
        sphere_alpha (float): Opacity of the wireframe sphere.
        marker (str): Marker style for scatter points.
        units (str): Units label for axes.
        figsize (tuple): Figure size.
        save_path (str): If provided, saves the figure to this path.
        show (bool): If True, calls plt.show(). Set to False when embedding in
            a larger figure or running headless.
        close (bool): If True, closes the figure after showing.
        ax (matplotlib.axes.Axes, optional): Pre-existing 3D axes to plot into.

    Returns:
        tuple: (fig, ax)
    """
    vectors = np.asarray(vectors)
    if vectors.ndim != 2 or vectors.shape[1] != 3:
        raise ValueError("Input must have shape (N, 3).")

    unit_vectors = normalize(vectors)

    created_fig = ax is None
    if created_fig:
        fig = plt.figure(figsize=figsize)
        ax = fig.add_subplot(111, projection="3d")
    else:
        fig = ax.get_figure()

    _draw_unit_sphere(ax, alpha=sphere_alpha)
    ax.scatter(
        unit_vectors[:, 0], unit_vectors[:, 1], unit_vectors[:, 2], marker=marker
    )

    ax.set_xlim([-1, 1])
    ax.set_ylim([-1, 1])
    ax.set_zlim([-1, 1])
    ax.set_box_aspect([1, 1, 1])
    ax.set_xlabel(f"X ({units})" if units else "X")
    ax.set_ylabel(f"Y ({units})" if units else "Y")
    ax.set_zlabel(f"Z ({units})" if units else "Z")
    ax.set_title(title)
    ax.view_init(elev=20, azim=45)

    if created_fig:
        plt.tight_layout()

    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
    if show:
        plt.show()
    if close:
        plt.close(fig)

    return fig, ax


def plot_magnetic_field_comparison(
    sensor_data,
    sensor_names,
    axis_labels=("X", "Y", "Z"),
    title="Magnetic Field on Unit Sphere",
    sphere_alpha=0.5,
    marker=".",
    units="",
    legend=True,
    legend_loc="best",
    colors=None,
    figsize=(6, 6),
    save_path=None,
    normalize_vectors=True,
    show=True,
    close=False,
    ax=None,
):
    """
    Plots the direction of magnetic field vectors from multiple sensors as scatter
    points on a unit sphere.

    Args:
        sensor_data (list): List of (N_i, 3) arrays, one per sensor.
        sensor_names (list): Labels for each sensor.
        axis_labels (tuple): Labels for X, Y, Z axes.
        title (str): Plot title.
        sphere_alpha (float): Opacity of the wireframe sphere.
        marker (str): Marker style for scatter points.
        units (str): Units label for axes.
        legend (bool): Show legend.
        legend_loc (str): Legend location.
        colors (list): Colors for each sensor. Defaults to tab10.
        figsize (tuple): Figure size.
        save_path (str): If provided, saves the figure to this path.
        normalize_vectors (bool): If True, normalizes vectors to unit length before
            plotting. Set to False if data is already normalized.
        show (bool): If True, calls plt.show(). Set to False when embedding in
            a larger figure or running headless.
        close (bool): If True, closes the figure after showing.
        ax (matplotlib.axes.Axes, optional): Pre-existing 3D axes to plot into.

    Returns:
        tuple: (fig, ax)
    """
    n_sensors = len(sensor_data)
    if len(sensor_names) != n_sensors:
        raise ValueError("sensor_names length must match sensor_data length.")

    sensors = []
    for i, data in enumerate(sensor_data):
        data = np.asarray(data)
        if data.ndim != 2 or data.shape[1] != 3:
            raise ValueError(f"Sensor {i} data must have shape (N, 3).")
        sensors.append(data)

    if colors is None:
        colors = list(plt.colormaps["tab10"].colors[:n_sensors])

    if normalize_vectors:
        sensors = [normalize(data) for data in sensors]

    created_fig = ax is None
    if created_fig:
        fig = plt.figure(figsize=figsize)
        ax = fig.add_subplot(111, projection="3d")
    else:
        fig = ax.get_figure()

    _draw_unit_sphere(ax, alpha=sphere_alpha)

    for sensor_idx in range(n_sensors):
        ax.scatter(
            sensors[sensor_idx][:, 0],
            sensors[sensor_idx][:, 1],
            sensors[sensor_idx][:, 2],
            marker=marker,
            color=colors[sensor_idx],
            label=sensor_names[sensor_idx],
            alpha=0.65,
        )

    ax.set_xlim([-1, 1])
    ax.set_ylim([-1, 1])
    ax.set_zlim([-1, 1])
    ax.set_box_aspect([1, 1, 1])
    ax.set_xlabel(f"{axis_labels[0]} ({units})" if units else axis_labels[0])
    ax.set_ylabel(f"{axis_labels[1]} ({units})" if units else axis_labels[1])
    ax.set_zlabel(f"{axis_labels[2]} ({units})" if units else axis_labels[2])
    ax.set_title(title)

    if legend:
        ax.legend(loc=legend_loc)

    ax.view_init(elev=20, azim=45)

    if created_fig:
        plt.tight_layout()

    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
    if show:
        plt.show()
    if close:
        plt.close(fig)

    return fig, ax


def plot_trajectory(
    xy_data,
    z_data=None,
    x_index=0,
    y_index=1,
    title="2D Trajectory",
    xlabel="X (m)",
    ylabel="Y (m)",
    z_label="Z Value",
    color="tab:blue",
    cmap="viridis",
    marker="o",
    markersize=4,
    linewidth=3.5,
    alpha=0.8,
    figsize=(8, 6),
    grid=True,
    remove_offset=False,
    save_path=None,
    background_png=None,
    background_tfw=None,
    show=True,
    close=False,
    ax=None,
):
    """
    Plot a 2D trajectory with optional Z-based colormap and optional georeferenced background.

    Args:
        xy_data (array-like): Array of shape (N, >=2). Columns are [X, Y, ...].
        z_data (array-like, optional): Z values of shape (N,) for colormap (e.g., depth).
        x_index (int): Column index for X coordinates.
        y_index (int): Column index for Y coordinates.
        title (str): Plot title.
        xlabel (str): X-axis label.
        ylabel (str): Y-axis label.
        z_label (str): Colorbar label when z_data is provided.
        color (str): Line color when z_data is not used.
        cmap (str): Colormap name when z_data is provided.
        marker (str or None): Marker style. Pass None to disable markers.
        markersize (int): Marker size.
        linewidth (float): Line width.
        alpha (float): Line/scatter opacity.
        figsize (tuple): Figure size.
        grid (bool): Show grid.
        remove_offset (bool): If True, subtract the initial X/Y to start at origin.
        save_path (str): If provided, saves the figure to this path.
        background_png (str, optional): Path to background PNG image.
        background_tfw (str, optional): Path to corresponding TFW world file.
        show (bool): If True, calls plt.show(). Set to False when embedding in
            a larger figure or running headless.
        close (bool): If True, closes the figure after showing.
        ax (matplotlib.axes.Axes, optional): Pre-existing axes to plot into.

    Returns:
        tuple: (fig, ax)
    """
    xy_data = np.asarray(xy_data)
    if xy_data.shape[1] <= max(x_index, y_index):
        raise ValueError(
            "xy_data does not contain enough dimensions for the specified indices."
        )

    x = xy_data[:, x_index].copy()
    y = xy_data[:, y_index].copy()

    if remove_offset:
        x = x - x[0]
        y = y - y[0]
        if z_data is not None:
            z_data = np.asarray(z_data).copy() - z_data[0]

    created_fig = ax is None
    if created_fig:
        fig, ax = plt.subplots(figsize=figsize)
    else:
        fig = ax.get_figure()

    if background_png and background_tfw:
        _apply_geotiff_background(ax, background_png, background_tfw, x, y)

    if z_data is not None:
        z_data = np.asarray(z_data)
        if z_data.shape[0] != x.shape[0]:
            raise ValueError("z_data and xy_data length mismatch.")

        points = np.array([x, y]).T.reshape(-1, 1, 2)
        segments = np.concatenate([points[:-1], points[1:]], axis=1)
        z_segments = (z_data[:-1] + z_data[1:]) / 2

        lc = LineCollection(
            segments, array=z_segments, cmap=cmap, linewidth=linewidth, alpha=alpha
        )
        ax.add_collection(lc)
        ax.autoscale()

        if marker is not None:
            ax.scatter(
                x, y, c=z_data, cmap=cmap, marker=marker, s=markersize**2, alpha=alpha
            )

        cbar = plt.colorbar(lc, ax=ax)
        cbar.set_label(z_label)
    else:
        ax.plot(x, y, color=color, linewidth=linewidth, alpha=alpha)
        if marker is not None:
            ax.scatter(x, y, color=color, marker=marker, s=markersize**2, alpha=alpha)

    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.set_aspect("equal", adjustable="box")

    if grid:
        ax.grid(True, alpha=0.3)

    if created_fig:
        plt.tight_layout()

    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
    if show:
        plt.show()
    if close:
        plt.close(fig)

    return fig, ax


def plot_trajectory_comparison(
    trajectory_data,
    sensor_names,
    time_data=None,
    depth_data=None,
    x_index=0,
    y_index=1,
    title="2D Trajectory Comparison",
    xlabel="X (m)",
    ylabel="Y (m)",
    zlabel="Depth (m)",
    remove_offset=False,
    figsize=(12, 6),
    colors=None,
    linestyles=None,
    linewidth=2.0,
    alpha=0.8,
    grid=True,
    save_path=None,
    show=True,
    close=False,
    axes=None,
):
    """
    Plot multiple 2D trajectories with an optional depth subplot.

    Args:
        trajectory_data (list): List of arrays, each with shape (N_i, >=2).
        sensor_names (list): Labels for each trajectory.
        time_data (list, optional): List of time arrays, one per trajectory. Used
            for the x-axis of the depth subplot when provided.
        depth_data (list, optional): List of depth arrays, one per trajectory.
        x_index (int): Column index for X coordinates.
        y_index (int): Column index for Y coordinates.
        title (str): Figure title.
        xlabel (str): X-axis label for the trajectory subplot.
        ylabel (str): Y-axis label for the trajectory subplot.
        zlabel (str): Y-axis label for the depth subplot.
        remove_offset (bool): If True, subtract initial x/y/depth values per trajectory.
        figsize (tuple): Figure size.
        colors (list): Colors for each trajectory. Defaults to tab10.
        linestyles (list): Linestyles for each trajectory.
        linewidth (float): Line width.
        alpha (float): Line opacity.
        grid (bool): Show grid.
        save_path (str): If provided, saves the figure to this path.
        show (bool): If True, calls plt.show(). Set to False when embedding in
            a larger figure or running headless.
        close (bool): If True, closes the figure after showing.
        axes (tuple, optional): Pre-existing (ax_traj, ax_depth) axes to plot into.
            ax_depth may be None when depth_data is not used.

    Returns:
        tuple: (fig, (ax_traj, ax_depth)) — ax_depth is None when depth_data is not provided.
    """
    n_sensors = len(trajectory_data)
    if len(sensor_names) != n_sensors:
        raise ValueError("sensor_names length must match trajectory_data length.")
    if depth_data is not None and len(depth_data) != n_sensors:
        raise ValueError("depth_data length must match trajectory_data length.")
    if time_data is not None and len(time_data) != n_sensors:
        raise ValueError("time_data length must match trajectory_data length.")

    if colors is None:
        colors = list(plt.colormaps["tab10"].colors[:n_sensors])
    if linestyles is None:
        linestyles = ["-"] * n_sensors

    created_fig = axes is None
    if created_fig:
        if depth_data is not None:
            fig, (ax_traj, ax_depth) = plt.subplots(
                1,
                2,
                figsize=figsize,
                gridspec_kw={"width_ratios": [1, 1]},
            )
        else:
            fig, ax_traj = plt.subplots(1, 1, figsize=figsize)
            ax_depth = None
    else:
        ax_traj, ax_depth = axes
        fig = ax_traj.get_figure()

    plot_handles = []
    x_label = "Sample Index"  # default, overwritten when time_data is provided

    for i in range(n_sensors):
        traj = np.asarray(trajectory_data[i])
        if traj.shape[1] <= max(x_index, y_index):
            raise ValueError(f"Trajectory {i} does not contain enough dimensions.")

        x = traj[:, x_index].copy()
        y = traj[:, y_index].copy()
        depth = np.asarray(depth_data[i]).copy() if depth_data is not None else None

        if remove_offset:
            x -= x[0]
            y -= y[0]
            if depth is not None:
                depth -= depth[0]

        (line,) = ax_traj.plot(
            x,
            y,
            label=sensor_names[i],
            color=colors[i],
            linestyle=linestyles[i],
            linewidth=linewidth,
            alpha=alpha,
        )
        plot_handles.append(line)

        if depth is not None and ax_depth is not None:
            if time_data is not None:
                t = np.asarray(time_data[i]) - time_data[i][0]
                scaled_time, x_label = _scale_time_array(t)
                ax_depth.plot(
                    scaled_time,
                    depth,
                    color=colors[i],
                    linestyle=linestyles[i],
                    linewidth=linewidth,
                    alpha=alpha,
                )
            else:
                ax_depth.plot(
                    depth,
                    color=colors[i],
                    linestyle=linestyles[i],
                    linewidth=linewidth,
                    alpha=alpha,
                )

    ax_traj.set_title("XY Trajectory Comparison")
    ax_traj.set_xlabel(xlabel)
    ax_traj.set_ylabel(ylabel)
    ax_traj.set_aspect("equal", adjustable="box")
    if grid:
        ax_traj.grid(True, alpha=0.3)

    if ax_depth is not None:
        ax_depth.set_title("Depth Comparison")
        ax_depth.set_ylabel(zlabel)
        ax_depth.set_xlabel(x_label)
        if grid:
            ax_depth.grid(True, alpha=0.3)

    fig.legend(
        handles=plot_handles,
        labels=sensor_names,
        loc="lower center",
        ncol=n_sensors,
        frameon=False,
        bbox_to_anchor=(0.5, 0.01),
    )

    fig.suptitle(title)

    if created_fig:
        plt.tight_layout(rect=[0, 0.08, 1, 0.95])

    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
    if show:
        plt.show()
    if close:
        plt.close(fig)

    return fig, (ax_traj, ax_depth)
