"""LangChain integration for Neruva agent memory.

Two drop-in wrappers covering the modern LangChain plug points:

  NeruvaChatMessageHistory    -- auto-records every turn into Records
                                  substrate; works with the modern
                                  RunnableWithMessageHistory pattern,
                                  AgentExecutor, anything taking a
                                  BaseChatMessageHistory.

  NeruvaContextRetriever      -- pulls federated agent_recall (KG +
                                  Records) for a question. Plug into
                                  any chain that takes a BaseRetriever
                                  (RetrievalQA, create_retrieval_chain).

Install:
    pip install neruva-langchain

Usage (3 lines):
    from neruva_langchain import NeruvaChatMessageHistory
    history = NeruvaChatMessageHistory(api_key="nv_...", namespace="my_user")
    # pass `history` to RunnableWithMessageHistory or any chain that
    # takes a BaseChatMessageHistory
"""
from neruva_langchain.history import NeruvaChatMessageHistory
from neruva_langchain.retriever import NeruvaContextRetriever

try:
    from neruva_langchain.auto_pilot import (
        NeruvaAutoPilot,
        NeruvaAutoPilotCallback,
    )
    _AUTOPILOT = ["NeruvaAutoPilot", "NeruvaAutoPilotCallback"]
except Exception:  # pragma: no cover - langchain may not be installed
    _AUTOPILOT = []

from neruva_langchain.toolbox import NeruvaCodeGraph, NeruvaCognitive

__all__ = [
    "NeruvaChatMessageHistory",
    "NeruvaContextRetriever",
    "NeruvaCodeGraph",
    "NeruvaCognitive",
] + _AUTOPILOT

from importlib.metadata import PackageNotFoundError, version as _pkg_version

try:
    __version__ = _pkg_version("neruva-langchain")
except PackageNotFoundError:
    __version__ = "0.0.0+local"
