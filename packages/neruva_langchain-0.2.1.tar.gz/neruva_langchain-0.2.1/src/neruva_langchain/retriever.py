"""BaseRetriever wrapper for LangChain RetrievalQA / chains.

Returns Document objects sourced from agent_recall (Records + KG
federation). Each Document's page_content is the record text or the
KG fact stringification; metadata carries source / score / namespace.

Usage:
    from neruva_langchain import NeruvaContextRetriever
    from langchain.chains import RetrievalQA
    from langchain_anthropic import ChatAnthropic

    retriever = NeruvaContextRetriever(api_key="nv_...", namespace="user_alice")
    qa = RetrievalQA.from_chain_type(
        llm=ChatAnthropic(model="claude-opus-4-7"),
        retriever=retriever,
    )
    qa.invoke("Where does Alice work?")
"""
from __future__ import annotations

from typing import Any, List, Optional

from langchain_core.documents import Document
from langchain_core.retrievers import BaseRetriever
from pydantic import PrivateAttr

from neruva_langchain._client import NeruvaClient


class NeruvaContextRetriever(BaseRetriever):
    """LangChain retriever backed by Neruva federated agent_recall."""

    namespace: str = "agent"
    namespaces: Optional[List[str]] = None
    user_id: Optional[str] = None
    top_k: int = 10

    _client: Any = PrivateAttr()

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self._client = NeruvaClient(api_key=api_key, base_url=base_url)

    def _get_relevant_documents(
        self,
        query: str,
        *,
        run_manager: Any = None,
    ) -> List[Document]:
        result = self._client.agent_recall(
            query=query,
            namespace=self.namespace,
            namespaces=self.namespaces,
            top_k=self.top_k,
            user_id=self.user_id,
        )
        docs: List[Document] = []
        for hit in result.get("records", []):
            docs.append(Document(
                page_content=str(hit.get("text", "")),
                metadata={
                    "source": "records",
                    "id": hit.get("id"),
                    "kind": hit.get("kind"),
                    "score": hit.get("score"),
                    "tags": hit.get("tags") or [],
                    "ts": hit.get("ts"),
                },
            ))
        for fact in result.get("kg_facts", []):
            docs.append(Document(
                page_content=f"{fact['subject']} {fact['relation']} {fact['object']}",
                metadata={
                    "source": "kg",
                    "subject": fact["subject"],
                    "relation": fact["relation"],
                    "object": fact["object"],
                    "confidence": fact.get("confidence"),
                },
            ))
        return docs
