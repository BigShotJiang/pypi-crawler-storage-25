"""Auto-pilot integration for LangChain.

Exposes two surfaces:

  NeruvaAutoPilot           -- framework-agnostic core. Fetches the
                                canonical substrate prompts (route_intent,
                                reflect, extract) and runs them through
                                the caller's LangChain LLM. Returns
                                structured results.

  NeruvaAutoPilotCallback   -- LangChain BaseCallbackHandler subclass.
                                Auto-fires intent routing on chain_start
                                and (optionally) reflection on chain_end.
                                Drop into any chain via callbacks=[...].

Pattern-C throughout: substrate emits the prompt, caller LLM runs it,
SDK pushes structured results back via the existing client. Substrate
stays $0/call.
"""
from __future__ import annotations

import json
import re
from typing import Any, Callable, Optional

from neruva_langchain._client import NeruvaClient

try:
    from langchain.callbacks.base import BaseCallbackHandler
    from langchain_core.language_models import BaseLanguageModel
    _LC_AVAILABLE = True
except Exception:  # pragma: no cover - langchain optional
    BaseCallbackHandler = object  # type: ignore[misc, assignment]
    BaseLanguageModel = Any  # type: ignore[misc, assignment]
    _LC_AVAILABLE = False


# Canonical extraction prompt -- mirrors neruva_memory_api/entity_extractor.py
# and neruva_record/_auto_extract.py. Inlined to avoid coupling to either.
_EXTRACTION_PROMPT = (
    "You are a precise triple extractor. Given input text, extract the "
    "factual (subject, predicate, object) triples it asserts. Use "
    "canonical lowercase tokens. Predicates are short verb phrases "
    "(e.g., 'lives_in', 'works_at', 'said', 'is_a').\n\n"
    "Output ONLY a JSON array. No prose. No commentary.\n\n"
    'Example input: "Alice told me she lives in Toronto and works at Acme."\n'
    'Example output: [["alice","lives_in","toronto"],["alice","works_at","acme"]]\n\n'
    "If the text contains no extractable facts, output []."
)


def _strip_json(s: str) -> str:
    """Best-effort: pull a JSON object or array out of an LLM response
    that may include markdown fences or commentary."""
    s = s.strip()
    # Markdown fence
    m = re.search(r"```(?:json)?\s*(.+?)```", s, re.DOTALL)
    if m:
        return m.group(1).strip()
    # First {...} or [...] block
    for opener, closer in (("{", "}"), ("[", "]")):
        i, j = s.find(opener), s.rfind(closer)
        if 0 <= i < j:
            return s[i:j + 1]
    return s


class NeruvaAutoPilot:
    """Framework-agnostic auto-pilot helper for LangChain users.

    Wraps Neruva's 3 auto-pilot endpoints with a LangChain LLM callable.
    Call from inside a chain / agent / runnable to route intents,
    reflect on turns, or extract facts.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        namespace: str = "default",
        llm: Optional[BaseLanguageModel] = None,
    ) -> None:
        self.client = NeruvaClient(api_key=api_key)
        self.namespace = namespace
        self.llm = llm
        self._auto_kg = f"{namespace}-auto-kg"

    def _invoke_llm(self, prompt: str) -> str:
        if self.llm is None:
            raise RuntimeError(
                "NeruvaAutoPilot was constructed without an llm= argument. "
                "Pass a LangChain LLM (e.g., ChatAnthropic(...)) to enable "
                "the classify/reflect/extract methods."
            )
        msg = self.llm.invoke(prompt)
        # ChatModels return BaseMessage with .content; LLMs return str.
        text = getattr(msg, "content", None) or str(msg)
        return text if isinstance(text, str) else str(text)

    # ---- Layer 2: intent routing ----
    def classify_intent(
        self,
        user_message: str,
        recent_context_summary: Optional[str] = None,
    ) -> dict[str, Any]:
        """Fetch substrate's intent-classifier prompt, run it through
        our LLM, return the parsed classification. Raises if no LLM."""
        payload = self.client._post(
            "/v1/agent/route_intent_prompt",
            {
                "user_message": user_message,
                "recent_context_summary": recent_context_summary,
            },
        )
        raw = self._invoke_llm(payload["prompt"])
        try:
            return json.loads(_strip_json(raw))
        except Exception:
            return {"primary_intent": "none", "confidence": 0.0}

    # ---- Layer 3: reflective auto-write ----
    def reflect(
        self,
        recent_turns: list[dict[str, Any]],
        auto_write: bool = True,
    ) -> dict[str, Any]:
        """Fetch substrate's reflection prompt over recent_turns, run
        it through our LLM, parse the structured response. If
        auto_write=True (default), persist decisions/facts/mistakes/
        open_questions to substrate via records_ingest + hd_kg_add_facts.
        """
        payload = self.client._post(
            "/v1/agent/reflect_prompt",
            {"recent_turns": recent_turns},
        )
        raw = self._invoke_llm(payload["prompt"])
        try:
            parsed = json.loads(_strip_json(raw))
        except Exception:
            return {"decisions": [], "facts": [], "mistakes": [], "open_questions": []}
        if auto_write:
            self._write_reflected(parsed)
        return parsed

    def _write_reflected(self, parsed: dict[str, Any]) -> None:
        items = []
        for d in parsed.get("decisions", []) or []:
            items.append({
                "kind": "decision",
                "text": d.get("text", ""),
                "tags": (d.get("tags") or []) + ["auto-reflected"],
            })
        for m in parsed.get("mistakes", []) or []:
            items.append({
                "kind": "mistake",
                "text": m.get("text", "") + (
                    f"  ROOT CAUSE: {m.get('root_cause')}" if m.get("root_cause") else ""
                ),
                "tags": ["auto-reflected"],
            })
        for q in parsed.get("open_questions", []) or []:
            items.append({
                "kind": "open_question",
                "text": q if isinstance(q, str) else q.get("text", ""),
                "tags": ["auto-reflected"],
            })
        if items:
            try:
                self.client._post(f"/v1/records/{self.namespace}", {"items": items})
            except Exception:
                pass
        facts = parsed.get("facts", []) or []
        if facts:
            triples = [
                [f.get("subject", ""), f.get("relation", ""), f.get("object", "")]
                for f in facts
                if f.get("subject") and f.get("relation") and f.get("object")
            ]
            if triples:
                try:
                    self.client._post(
                        f"/v1/hd/kg/{self._auto_kg}/facts",
                        {"facts": triples},
                    )
                except Exception:
                    pass

    # ---- Layer 1: extraction ----
    def extract_facts(self, text: str, auto_write: bool = True) -> list[list[str]]:
        """Run the canonical extraction prompt against `text` via our
        LLM, parse the triple list. If auto_write=True, push to
        <namespace>-auto-kg."""
        prompt = _EXTRACTION_PROMPT + "\n\nINPUT:\n" + text
        raw = self._invoke_llm(prompt)
        try:
            triples = json.loads(_strip_json(raw))
        except Exception:
            return []
        if not isinstance(triples, list):
            return []
        clean = [
            t for t in triples
            if isinstance(t, list) and len(t) == 3 and all(isinstance(x, str) for x in t)
        ]
        if auto_write and clean:
            try:
                self.client._post(
                    f"/v1/hd/kg/{self._auto_kg}/facts",
                    {"facts": clean},
                )
            except Exception:
                pass
        return clean


class NeruvaAutoPilotCallback(BaseCallbackHandler):
    """LangChain callback handler that auto-fires intent routing on
    chain_start and (optionally) reflection on chain_end.

    Add to any chain / agent via callbacks=[NeruvaAutoPilotCallback(...)].
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        namespace: str = "default",
        llm: Optional[BaseLanguageModel] = None,
        enable_route: bool = True,
        enable_reflect: bool = False,
        on_intent: Optional[Callable[[dict], None]] = None,
    ) -> None:
        if not _LC_AVAILABLE:
            raise RuntimeError(
                "langchain is not installed. Install with: "
                "pip install 'neruva-langchain[auto-pilot]' or pip install langchain"
            )
        super().__init__()
        self.ap = NeruvaAutoPilot(api_key=api_key, namespace=namespace, llm=llm)
        self.enable_route = enable_route
        self.enable_reflect = enable_reflect
        self.on_intent = on_intent
        self._turn_buffer: list[dict[str, Any]] = []

    def on_chain_start(self, serialized, inputs, **kwargs) -> None:  # noqa: D401
        if not self.enable_route or not self.ap.llm:
            return
        # Grab the user input -- LangChain passes various shapes; we
        # take the first string value we find.
        msg = ""
        if isinstance(inputs, dict):
            for v in inputs.values():
                if isinstance(v, str) and v.strip():
                    msg = v
                    break
        if not msg:
            return
        try:
            intent = self.ap.classify_intent(msg)
            self._turn_buffer.append({"role": "user", "text": msg})
            if self.on_intent:
                self.on_intent(intent)
        except Exception:
            pass

    def on_chain_end(self, outputs, **kwargs) -> None:  # noqa: D401
        if isinstance(outputs, dict):
            for v in outputs.values():
                if isinstance(v, str) and v.strip():
                    self._turn_buffer.append({"role": "assistant", "text": v[:4000]})
                    break
        # Optionally reflect every 10 turns
        if self.enable_reflect and len(self._turn_buffer) >= 10:
            try:
                self.ap.reflect(self._turn_buffer[-10:], auto_write=True)
            except Exception:
                pass
