"""Drop-in BaseChatMessageHistory for LangChain.

Every message added gets auto-piped into Neruva's Records substrate via
agent_remember (which also extracts factual triples into the KG when
present). On reload, messages are pulled from records_timeline.

Wire it into any LangChain primitive that accepts a BaseChatMessageHistory:

    from langchain_core.messages import HumanMessage, AIMessage
    from neruva_langchain import NeruvaChatMessageHistory

    history = NeruvaChatMessageHistory(
        api_key="nv_...",
        namespace="user_alice",
    )

    history.add_user_message("My name is Alice and I live in Toronto.")
    history.add_ai_message("Nice to meet you, Alice!")

    # Later (even after process restart) — substrate-backed:
    print(history.messages)
"""
from __future__ import annotations

from typing import List, Optional

from langchain_core.chat_history import BaseChatMessageHistory
from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    HumanMessage,
    SystemMessage,
    messages_from_dict,
)

from neruva_langchain._client import NeruvaClient


# Records kinds we use for LangChain message mapping. Stays inside the
# canonical Records kind vocabulary so dashboards / cortex agents render
# them correctly.
_KIND_USER = "user_prompt"
_KIND_AI = "assistant_turn"
_KIND_SYSTEM = "llm_turn"


class NeruvaChatMessageHistory(BaseChatMessageHistory):
    """LangChain-compatible chat history backed by Neruva Records.

    Survives process restarts. Multi-session capable (multi-namespace
    fan-out via agent_recall is available -- this wrapper is single-
    namespace, matching LangChain's BaseChatMessageHistory contract)."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        namespace: str = "agent",
        user_id: Optional[str] = None,
        load_limit: int = 200,
    ) -> None:
        self._client = NeruvaClient(api_key=api_key, base_url=base_url)
        self.namespace = namespace
        self.user_id = user_id
        self.load_limit = int(load_limit)

    @property
    def messages(self) -> List[BaseMessage]:
        """Pull the last N messages in chronological order (oldest first)."""
        result = self._client.records_timeline(
            self.namespace,
            limit=self.load_limit,
            kinds=[_KIND_USER, _KIND_AI, _KIND_SYSTEM],
        )
        # records_timeline returns {"records": [...]}; memory_timeline returns
        # {"items": [...]}. Pick records_timeline's shape since that's what
        # this wrapper hits.
        items = list(result.get("records") or result.get("items") or [])
        # records_timeline returns most-recent first; LangChain expects oldest first
        items.reverse()
        out: List[BaseMessage] = []
        for it in items:
            kind = str(it.get("kind", ""))
            text = str(it.get("text", ""))
            if kind == _KIND_USER:
                out.append(HumanMessage(content=text))
            elif kind == _KIND_AI:
                out.append(AIMessage(content=text))
            elif kind == _KIND_SYSTEM:
                out.append(SystemMessage(content=text))
        return out

    def add_message(self, message: BaseMessage) -> None:
        """Append one message. Routes by message type."""
        if isinstance(message, HumanMessage):
            self._ingest(message.content, _KIND_USER)
        elif isinstance(message, AIMessage):
            self._ingest(message.content, _KIND_AI)
        elif isinstance(message, SystemMessage):
            self._ingest(message.content, _KIND_SYSTEM)
        else:
            # Unknown subtype -- ingest as raw note with the type name tag
            self._ingest(
                str(message.content),
                _KIND_SYSTEM,
                extra_tags=[f"type:{type(message).__name__}"],
            )

    def clear(self) -> None:
        """LangChain spec method. Records doesn't have a 'forget-all-in-
        namespace' shortcut yet; use records_forget client-side OR
        memory_delete_index if you want full cleanup. For now this is a
        no-op so callers don't accidentally lose all their context."""
        # Intentionally a no-op. If you really want hard delete, call
        # records_forget directly via the REST API with your own filter.
        pass

    # ---- internals ----------------------------------------------------

    def _ingest(
        self,
        text: str,
        kind: str,
        extra_tags: Optional[List[str]] = None,
    ) -> None:
        if not text:
            return
        tags = ["langchain", f"kind:{kind}"] + list(extra_tags or [])
        self._client.agent_remember(
            text=str(text),
            namespace=self.namespace,
            tags=tags,
            kind=kind,
            user_id=self.user_id,
        )
