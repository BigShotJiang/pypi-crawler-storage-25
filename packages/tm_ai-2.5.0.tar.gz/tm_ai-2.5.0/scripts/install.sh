#!/usr/bin/env bash
# =============================================================================
# CVC (Cognitive Version Control) — Bulletproof Installer for macOS/Linux/WSL
# Usage:  curl -fsSL https://jaimeena.com/cvc/install.sh | bash
# =============================================================================
set -uo pipefail   # NOT -e — keep going through cleanup errors

PACKAGE="tm-ai[all]"
PYPI_NAME="tm-ai"
TOOL_NAME="cvc"
UV_INSTALL_URL="https://astral.sh/uv/install.sh"

# ── CVC branded colours (match install.bat) ────────────────────────────────
CVC_RED=$'\033[38;2;204;51;51m'
CVC_BRIGHT=$'\033[38;2;255;68;68m'
CVC_DIM=$'\033[38;2;139;112;112m'
CVC_GREEN=$'\033[38;2;80;200;120m'
BOLD=$'\033[1m'
RESET=$'\033[0m'

info() { printf "  %s%s%s\n"   "${CVC_DIM}"   "$1" "${RESET}"; }
ok()   { printf "  %s%s✓%s %s\n" "${CVC_GREEN}" "${BOLD}" "${RESET}" "$1"; }
warn() { printf "  %s⚠ %s%s\n"  "${CVC_DIM}"   "$1" "${RESET}"; }

# ── Fetch latest version from PyPI ──────────────────────────────────────────
LATEST_VERSION=""
if command -v curl &>/dev/null; then
    LATEST_VERSION=$(curl -sf "https://pypi.org/pypi/tm-ai/json" 2>/dev/null \
        | grep -o '"version":"[^"]*"' | head -n1 | cut -d'"' -f4 || true)
fi
echo ""
printf "%s%s* Installing %sCVC%s...%s\n" \
    "${CVC_RED}" "${BOLD}" "${CVC_BRIGHT}" "${CVC_RED}" "${RESET}"

# ── Ensure uv is available ──────────────────────────────────────────────────
if ! command -v uv &>/dev/null; then
    info "Installing uv package manager..."
    curl -fsSL "$UV_INSTALL_URL" | sh >/dev/null 2>&1 || true
    export PATH="$HOME/.cargo/bin:$HOME/.local/bin:$PATH"
    if ! command -v uv &>/dev/null; then
        printf "  %s%sx uv is required but could not be installed.%s\n" \
            "${CVC_RED}" "${BOLD}" "${RESET}" >&2
        info "Manual install: https://docs.astral.sh/uv/getting-started/installation/"
        exit 1
    fi
fi

# ── Compute uv tool bin UP FRONT (never delete from it) ─────────────────────
UV_TOOL_BIN=""
UV_TOOL_BIN=$(uv tool dir --bin 2>/dev/null || true)
if [ -z "$UV_TOOL_BIN" ] || [ ! -d "$UV_TOOL_BIN" ]; then
    UV_TOOL_BIN="$HOME/.local/bin"
fi
UV_TOOL_BIN="${UV_TOOL_BIN%/}"

is_uv_owned() {
    local p="${1%/}"
    [[ "$p" == "$UV_TOOL_BIN"* ]]
}

# ── Step 1: purge every old tm-ai / cvc installation (silent) ───────────────

# 1a. Uninstall tm-ai from every Python on PATH
SEEN_PYTHONS=""
IFS=: read -ra PATH_DIRS <<< "$PATH"
for dir in "${PATH_DIRS[@]}"; do
    [ -d "$dir" ] || continue
    for _pyexe in python3 python python3.13 python3.12 python3.11 python3.10; do
        full="$dir/$_pyexe"
        if [ -x "$full" ] && [[ ":$SEEN_PYTHONS:" != *":$full:"* ]]; then
            SEEN_PYTHONS="$SEEN_PYTHONS:$full"
            if "$full" -m pip show tm-ai &>/dev/null; then
                "$full" -m pip uninstall tm-ai -y >/dev/null 2>&1 || true
            fi
        fi
    done
done

# 1b. conda — base env + all named envs
if command -v conda &>/dev/null; then
    conda run -n base pip uninstall tm-ai -y >/dev/null 2>&1 || true
    conda remove -n base tm-ai -y >/dev/null 2>&1 || true
    while IFS= read -r env_path; do
        _conda_py="$env_path/bin/python"
        [ -x "$_conda_py" ] || continue
        if "$_conda_py" -m pip show tm-ai &>/dev/null; then
            "$_conda_py" -m pip uninstall tm-ai -y >/dev/null 2>&1 || true
        fi
    done < <(conda env list 2>/dev/null | grep -v '^#' | awk '{print $NF}')
fi

# 1c. pipx
if command -v pipx &>/dev/null; then
    pipx uninstall tm-ai >/dev/null 2>&1 || true
fi

# 1d. brew (macOS)
if command -v brew &>/dev/null; then
    brew uninstall tm-ai >/dev/null 2>&1 || true
fi

# 1e. Delete stale cvc shims from PATH dirs (NOT from uv's bin)
for dir in "${PATH_DIRS[@]}"; do
    [ -d "$dir" ] || continue
    for stale in cvc cvc.py; do
        stale_path="$dir/$stale"
        if [ -f "$stale_path" ] && ! is_uv_owned "$stale_path"; then
            rm -f "$stale_path" >/dev/null 2>&1 || true
        fi
    done
done

# 1f. Remove existing uv tool entry (forces a clean reinstall)
if uv tool list 2>/dev/null | grep -q "^$PYPI_NAME"; then
    uv tool uninstall "$PYPI_NAME" >/dev/null 2>&1 || true
fi

# ── Step 2: fresh install via uv tool (force + refresh bypasses all caches) ─
if ! uv tool install --force --refresh "$PACKAGE" >/dev/null 2>&1; then
    printf "\n%s%sInstallation failed. Retrying with verbose output:%s\n" \
        "${CVC_RED}" "${BOLD}" "${RESET}"
    if ! uv tool install --force --refresh "$PACKAGE"; then
        exit 1
    fi
fi
ok "CVC installed"

# ── Step 3: force uv bin to the FRONT of PATH (session + shell RCs) ─────────
mkdir -p "$UV_TOOL_BIN"

add_to_front_of_path() {
    local cfg="$1"
    local guard_start='# >>> cvc path >>>'
    local guard_end='# <<< cvc path <<<'
    local line='export PATH="'"$UV_TOOL_BIN"':$PATH"'

    [ -f "$cfg" ] || return 0

    # Strip any previous cvc path block
    if grep -q "$guard_start" "$cfg" 2>/dev/null; then
        awk -v s="$guard_start" -v e="$guard_end" '
            $0 == s {skip=1; next}
            $0 == e {skip=0; next}
            !skip {print}
        ' "$cfg" > "${cfg}.tmp" && mv "${cfg}.tmp" "$cfg"
    fi

    # Prepend new block at the TOP (before any conda init)
    local tmp; tmp=$(mktemp)
    {
        echo "$guard_start"
        echo "$line"
        echo "$guard_end"
        echo ""
        cat "$cfg"
    } > "$tmp"
    mv "$tmp" "$cfg"
}

for rc in "$HOME/.bashrc" "$HOME/.bash_profile" "$HOME/.zshrc" "$HOME/.profile"; do
    [ -f "$rc" ] && add_to_front_of_path "$rc"
done

export PATH="$UV_TOOL_BIN:$PATH"
uv tool update-shell >/dev/null 2>&1 || true

ok "PATH updated (uv tool bin is now first)"

# ── Step 4: verify the installed version matches PyPI ───────────────────────
INSTALLED_VERSION=""
CVC_BIN="$UV_TOOL_BIN/cvc"
if [ -x "$CVC_BIN" ]; then
    INSTALLED_VERSION=$("$CVC_BIN" --version 2>/dev/null | head -n1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' || true)
elif command -v "$TOOL_NAME" &>/dev/null; then
    INSTALLED_VERSION=$("$TOOL_NAME" --version 2>/dev/null | head -n1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' || true)
fi

echo ""
V_STR=""; [ -n "$INSTALLED_VERSION" ] && V_STR=" v${INSTALLED_VERSION}"
printf "%s%s* %sCVC%s%s installed successfully.%s\n" \
    "${CVC_RED}" "${BOLD}" "${CVC_BRIGHT}" "${V_STR}" "${CVC_RED}" "${RESET}"
echo ""
printf "%sRun %s%s%scvc%s %sto start.%s\n" \
    "${CVC_DIM}" "${RESET}" "${CVC_BRIGHT}" "${BOLD}" "${RESET}" "${CVC_DIM}" "${RESET}"
echo ""
#!/usr/bin/env bash
# =============================================================================
# CVC (Cognitive Version Control) — Bulletproof Installer for macOS/Linux/WSL
# Usage:  curl -fsSL https://jaimeena.com/cvc/install.sh | bash
#
# Handles every worst-case scenario:
#   - conda injecting its bin/ into PATH, shadowing uv's bin
#   - Old pip-installed cvc in multiple Python envs
#   - Stale uv tool cache returning old versions
#   - PATH not updated for current session / wrong shell RC
# =============================================================================
set -uo pipefail   # note: NO -e so we can continue through cleanup errors

PACKAGE="tm-ai[all]"
PYPI_NAME="tm-ai"
TOOL_NAME="cvc"
UV_INSTALL_URL="https://astral.sh/uv/install.sh"

RED='\033[0;31m'; GREEN='\033[0;32m'; CYAN='\033[0;36m'; YELLOW='\033[0;33m'
BOLD='\033[1m'; DIM='\033[2m'; RESET='\033[0m'

step()  { echo -e "${CYAN}${BOLD}==>${RESET} $1"; }
ok()    { echo -e "${GREEN}${BOLD} ✓${RESET}  $1"; }
warn()  { echo -e "${YELLOW}${BOLD} ⚠${RESET}  $1"; }
err()   { echo -e "${RED}${BOLD} ✗${RESET}  $1" >&2; }

# ── Fetch latest PyPI version for display / verification ────────────────────
LATEST_VERSION=""
if command -v curl &>/dev/null; then
    LATEST_VERSION=$(curl -sf "https://pypi.org/pypi/tm-ai/json" 2>/dev/null \
        | grep -o '"version":"[^"]*"' | head -n1 | cut -d'"' -f4 || true)
fi
V_STR=""; [ -n "$LATEST_VERSION" ] && V_STR=" v${LATEST_VERSION}"

echo ""
echo -e "${RED}${BOLD}* Installing ${CYAN}CVC${V_STR}${RED}...${RESET}"
echo ""

# ── Step 0: ensure uv is available ──────────────────────────────────────────
if ! command -v uv &>/dev/null; then
    step "Installing uv package manager..."
    curl -fsSL "$UV_INSTALL_URL" | sh >/dev/null 2>&1 || true
    export PATH="$HOME/.cargo/bin:$HOME/.local/bin:$PATH"
    if ! command -v uv &>/dev/null; then
        err "uv is required but could not be installed."
        err "Manual fix: https://docs.astral.sh/uv/getting-started/installation/"
        exit 1
    fi
fi

# ── Compute uv tool bin UP FRONT (never delete from it) ─────────────────────
UV_TOOL_BIN=""
UV_TOOL_BIN=$(uv tool dir --bin 2>/dev/null || true)
if [ -z "$UV_TOOL_BIN" ] || [ ! -d "$UV_TOOL_BIN" ]; then
    UV_TOOL_BIN="$HOME/.local/bin"
fi
UV_TOOL_BIN="${UV_TOOL_BIN%/}"

is_uv_owned() {
    local p="${1%/}"
    [[ "$p" == "$UV_TOOL_BIN"* ]]
}

# ── Step 1: purge EVERY old tm-ai installation ──────────────────────────────

# 1a. Uninstall tm-ai from every Python on PATH
SEEN_PYTHONS=""
IFS=: read -ra PATH_DIRS <<< "$PATH"
for dir in "${PATH_DIRS[@]}"; do
    [ -d "$dir" ] || continue
    for _pyexe in python3 python python3.13 python3.12 python3.11 python3.10; do
        full="$dir/$_pyexe"
        if [ -x "$full" ] && [[ ":$SEEN_PYTHONS:" != *":$full:"* ]]; then
            SEEN_PYTHONS="$SEEN_PYTHONS:$full"
            if "$full" -m pip show tm-ai &>/dev/null; then
                "$full" -m pip uninstall tm-ai -y >/dev/null 2>&1 || true
            fi
        fi
    done
done

# 1b. conda — uninstall from base + all named envs
if command -v conda &>/dev/null; then
    conda run -n base pip uninstall tm-ai -y >/dev/null 2>&1 || true
    conda remove -n base tm-ai -y >/dev/null 2>&1 || true
    while IFS= read -r env_path; do
        _conda_py="$env_path/bin/python"
        [ -x "$_conda_py" ] || continue
        if "$_conda_py" -m pip show tm-ai &>/dev/null; then
            "$_conda_py" -m pip uninstall tm-ai -y >/dev/null 2>&1 || true
        fi
    done < <(conda env list 2>/dev/null | grep -v '^#' | awk '{print $NF}')
fi

# 1c. pipx
if command -v pipx &>/dev/null; then
    pipx uninstall tm-ai >/dev/null 2>&1 || true
fi

# 1d. brew (macOS)
if command -v brew &>/dev/null; then
    brew uninstall tm-ai >/dev/null 2>&1 || true
fi

# 1e. Delete stale cvc shims from PATH dirs (NOT from uv's bin)
for dir in "${PATH_DIRS[@]}"; do
    [ -d "$dir" ] || continue
    for stale in cvc cvc.py; do
        stale_path="$dir/$stale"
        if [ -f "$stale_path" ] && ! is_uv_owned "$stale_path"; then
            rm -f "$stale_path" >/dev/null 2>&1 || true
        fi
    done
done

# 1f. Uninstall existing uv tool entry (force clean reinstall)
if uv tool list 2>/dev/null | grep -q "^$PYPI_NAME"; then
    uv tool uninstall "$PYPI_NAME" >/dev/null 2>&1 || true
fi

# ── Step 2: fresh install with --force --refresh (bypass all caches) ────────
if ! uv tool install --force --refresh "$PACKAGE" >/dev/null 2>&1; then
    warn "Install failed. Retrying with verbose output..."
    if ! uv tool install --force --refresh "$PACKAGE"; then
        err "uv tool install failed."
        exit 1
    fi
fi

# ── Step 3: prepend uv bin to PATH (shell RCs + current session) ────────────
mkdir -p "$UV_TOOL_BIN"

add_to_front_of_path() {
    local cfg="$1"
    local guard_start='# >>> cvc path >>>'
    local guard_end='# <<< cvc path <<<'
    local line='export PATH="'"$UV_TOOL_BIN"':$PATH"'

    [ -f "$cfg" ] || return 0

    # Remove any previous cvc path block (portable across BSD/GNU sed)
    if grep -q "$guard_start" "$cfg" 2>/dev/null; then
        awk -v s="$guard_start" -v e="$guard_end" '
            $0 == s {skip=1; next}
            $0 == e {skip=0; next}
            !skip {print}
        ' "$cfg" > "${cfg}.tmp" && mv "${cfg}.tmp" "$cfg"
    fi

    # Prepend the new block at the TOP (before any conda init block)
    local tmp; tmp=$(mktemp)
    {
        echo "$guard_start"
        echo "$line"
        echo "$guard_end"
        echo ""
        cat "$cfg"
    } > "$tmp"
    mv "$tmp" "$cfg"
}

for rc in "$HOME/.bashrc" "$HOME/.bash_profile" "$HOME/.zshrc" "$HOME/.profile"; do
    [ -f "$rc" ] && add_to_front_of_path "$rc"
done

# Apply to current session
export PATH="$UV_TOOL_BIN:$PATH"
uv tool update-shell >/dev/null 2>&1 || true

# ── Step 4: verify installed version matches PyPI ───────────────────────────
INSTALLED_VERSION=""
CVC_BIN="$UV_TOOL_BIN/cvc"
if [ -x "$CVC_BIN" ]; then
    INSTALLED_VERSION=$("$CVC_BIN" --version 2>/dev/null | head -n1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' || true)
elif command -v "$TOOL_NAME" &>/dev/null; then
    INSTALLED_VERSION=$("$TOOL_NAME" --version 2>/dev/null | head -n1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' || true)
fi

echo -e "${RED}${BOLD}* CVC installed successfully.${RESET}"
if [ -n "$INSTALLED_VERSION" ]; then
    echo -e "  ${DIM}Version: v${INSTALLED_VERSION}${RESET}"
fi
if [ -n "$LATEST_VERSION" ] && [ -n "$INSTALLED_VERSION" ] && [ "$INSTALLED_VERSION" != "$LATEST_VERSION" ]; then
    warn "Expected v${LATEST_VERSION}, got v${INSTALLED_VERSION}."
    warn "Open a NEW terminal — PATH changes take effect in new sessions."
fi

echo ""
echo -e "Run ${RED}${BOLD}cvc${RESET} to start."
echo -e "${DIM}(Open a new terminal if you still see an old version.)${RESET}"
echo ""
