"""GoldenMatch REST API."""
