"""
end-to-end test for agent-memory-layer.

Builds a minimal 3-node LangGraph (inject_memory → chat → record_memory),
runs it over two turns, triggers consolidation in between, and verifies
that memories carry across conversations.

Prerequisites:
    1. Docker Postgres running:  docker compose up -d
    2. AI Core env vars set (or in .env):
         AICORE_CLIENT_ID, AICORE_CLIENT_SECRET,
         AICORE_AUTH_URL, AICORE_BASE_URL
    3. Library installed:  pip install -e ".[langgraph]"

Usage:
    python scripts/e2e_test.py
"""

import asyncio
import logging
import os
import sys
from pathlib import Path
from typing import Annotated, Optional

from dotenv import load_dotenv
from typing_extensions import TypedDict

load_dotenv(Path(__file__).resolve().parent.parent / ".env", override=True)
load_dotenv(Path(__file__).resolve().parent.parent / "src" / "agent_memory_layer" / ".env", override=True)

from langchain_core.messages import AIMessage, BaseMessage, HumanMessage
from langgraph.graph import END, StateGraph
from langgraph.graph.message import add_messages

from gen_ai_hub.orchestration.models.config import OrchestrationConfig
from gen_ai_hub.orchestration.models.llm import LLM
from gen_ai_hub.orchestration.models.message import SystemMessage, UserMessage
from gen_ai_hub.orchestration.models.template import Template
from gen_ai_hub.orchestration.service import OrchestrationService

from agent_memory_layer import (
    ConsolidationJobRepository,
    EpisodeRepository,
    MemoryItemRepository,
    MemoryManager,
    run_consolidation,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
)
logger = logging.getLogger("e2e_test")

DB_URL = "postgresql://memory_user:memory_pass@localhost:5432/agent_memory"

SCOPE = {
    "user_id": "test-user-001",
    "agent_id": "e2e-bot",
    "workflow_id": None,
}


# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------
class ChatState(TypedDict, total=False):
    messages: Annotated[list[BaseMessage], add_messages]
    user_id: str
    agent_id: str
    workflow_id: Optional[str]
    working_memory: dict


# ---------------------------------------------------------------------------
# Chat node — calls AI Core
# ---------------------------------------------------------------------------
def build_chat_node(model_name: str = "gpt-4o"):
    llm = LLM(name=model_name, parameters={"temperature": 0.0, "max_tokens": 512})

    def chat_node(state: ChatState) -> dict:
        messages = state.get("messages", [])
        working_memory = state.get("working_memory", {})
        injected_facts = working_memory.get("injected_facts", [])

        system_text = "You are a helpful assistant. Keep responses short (2-3 sentences)."
        if injected_facts:
            system_text += "\n\nYou remember these facts about the user:\n"
            system_text += "\n".join(f"- {f}" for f in injected_facts)

        user_msg = messages[-1].content if messages else ""

        template = Template(
            messages=[
                SystemMessage(content=system_text),
                UserMessage(content=user_msg),
            ]
        )
        service = OrchestrationService(
            config=OrchestrationConfig(llm=llm, template=template)
        )
        response = service.run()
        content = response.module_results.llm.choices[0].message.content

        return {"messages": [AIMessage(content=content)]}

    return chat_node


# ---------------------------------------------------------------------------
# Wrapper for record_node — converts BaseMessage objects to dicts
# ---------------------------------------------------------------------------
def build_record_wrapper(record_node):
    async def wrapper(state: ChatState) -> dict:
        messages = state.get("messages", [])
        serialized = []
        for m in messages:
            if isinstance(m, BaseMessage):
                serialized.append({"role": m.type, "content": m.content})
            elif isinstance(m, dict):
                serialized.append(m)
        patched_state = {**state, "messages": serialized}
        return await record_node(patched_state)

    return wrapper


# ---------------------------------------------------------------------------
# Graph builder
# ---------------------------------------------------------------------------
def build_test_graph(manager: MemoryManager):
    graph = StateGraph(ChatState)

    graph.add_node("inject_memory", manager.inject_node)
    graph.add_node("chat", build_chat_node())
    graph.add_node("record_memory", build_record_wrapper(manager.record_node))

    graph.set_entry_point("inject_memory")
    graph.add_edge("inject_memory", "chat")
    graph.add_edge("chat", "record_memory")
    graph.add_edge("record_memory", END)

    return graph.compile()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def step(num: int, total: int, label: str):
    print(f"\n[{num}/{total}] {label}")


def ok(detail: str = ""):
    msg = "      ✓ OK"
    if detail:
        msg += f"  —  {detail}"
    print(msg)


def fail(detail: str):
    print(f"      ✗ FAIL  —  {detail}")
    sys.exit(1)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
async def main():
    total = 8
    passed = 0

    # ------------------------------------------------------------------
    step(1, total, "Starting MemoryManager...")
    # ------------------------------------------------------------------
    try:
        manager = await MemoryManager.create(
            db_url=DB_URL,
            aicore_client_id=os.environ.get("AICORE_CLIENT_ID"),
            aicore_client_secret=os.environ.get("AICORE_CLIENT_SECRET"),
            aicore_auth_url=os.environ.get("AICORE_AUTH_URL"),
            aicore_base_url=os.environ.get("AICORE_BASE_URL"),
            consolidation_interval_hours=999,
            decay_daily_hour=23,
        )
        ok("DB pool open, migrations applied, scheduler running")
        passed += 1
    except Exception as e:
        fail(f"Could not start MemoryManager: {e}")

    try:
        # ------------------------------------------------------------------
        step(2, total, "Building mini LangGraph...")
        # ------------------------------------------------------------------
        graph = build_test_graph(manager)
        ok("inject_memory → chat → record_memory → END")
        passed += 1

        # ------------------------------------------------------------------
        step(3, total, 'Turn 1: "I\'m a Python developer working on SAP integrations"')
        # ------------------------------------------------------------------
        turn1_state = await graph.ainvoke(
            {
                **SCOPE,
                "messages": [
                    HumanMessage(
                        content="Hi! I'm a Python developer and I mainly work on SAP integrations. "
                        "I prefer using async code and PostgreSQL for my projects."
                    )
                ],
            }
        )

        wm1 = turn1_state.get("working_memory", {})
        facts_t1 = wm1.get("injected_facts", [])
        ai_reply_1 = turn1_state["messages"][-1].content

        print(f"      → Injected facts: {len(facts_t1)} (expected 0, first turn)")
        print(f"      → AI response: {ai_reply_1[:100]}...")

        if len(facts_t1) != 0:
            fail("Expected 0 injected facts on first turn")

        episode_repo = EpisodeRepository(manager.pool, schema=manager.config.sap_memory_db_schema)
        episodes = await episode_repo.get_unconsolidated(
            user_id=SCOPE["user_id"], agent_id=SCOPE["agent_id"]
        )
        print(f"      → Episodes in DB: {len(episodes)}")
        if len(episodes) < 1:
            fail("Episode was not recorded")
        ok("Turn 1 complete — episode recorded, no prior memories")
        passed += 1

        # ------------------------------------------------------------------
        step(4, total, "Consolidating episodes via AI Core LLM...")
        # ------------------------------------------------------------------
        memory_repo = MemoryItemRepository(manager.pool, schema=manager.config.sap_memory_db_schema)
        job_repo = ConsolidationJobRepository(manager.pool, schema=manager.config.sap_memory_db_schema)

        job = await run_consolidation(
            episode_repo=episode_repo,
            memory_repo=memory_repo,
            job_repo=job_repo,
            config=manager.config,
            user_id=SCOPE["user_id"],
            agent_id=SCOPE["agent_id"],
            workflow_id=SCOPE["workflow_id"],
        )

        if job is None:
            fail("Consolidation returned None — no episodes found?")
        if job.status != "completed":
            fail(f"Consolidation status: {job.status}, error: {job.error}")

        print(f"      → Status: {job.status}")
        print(f"      → Facts created: {job.facts_created}")

        items = await memory_repo.fetch_by_scope(
            user_id=SCOPE["user_id"],
            agent_id=SCOPE["agent_id"],
        )
        print(f"      → Memory items in DB: {len(items)}")
        for item in items:
            print(f"        • [{item.importance:.2f}] {item.content[:80]}")

        if len(items) == 0:
            fail("No memory items created after consolidation")
        ok(f"{len(items)} fact(s) extracted and stored")
        passed += 1

        # ------------------------------------------------------------------
        step(5, total, 'Turn 2: "What language should I use for my next project?"')
        # ------------------------------------------------------------------
        turn2_state = await graph.ainvoke(
            {
                **SCOPE,
                "messages": [
                    HumanMessage(
                        content="I'm starting a new project to build a REST API. "
                        "What programming language and database should I use?"
                    )
                ],
            }
        )

        wm2 = turn2_state.get("working_memory", {})
        facts_t2 = wm2.get("injected_facts", [])
        ai_reply_2 = turn2_state["messages"][-1].content

        print(f"      → Injected facts: {len(facts_t2)}")
        for f in facts_t2:
            print(f"        • {f[:80]}")
        print(f"      → AI response: {ai_reply_2[:120]}...")

        ok("Turn 2 complete — response informed by memories")
        passed += 1

        # ------------------------------------------------------------------
        step(6, total, "Verifying memory injection...")
        # ------------------------------------------------------------------
        if len(facts_t2) > 0:
            ok(f"{len(facts_t2)} fact(s) injected into Turn 2 — memories carried across turns!")
            passed += 1
        else:
            fail("No facts were injected in Turn 2 — memory pipeline broken")

        # ------------------------------------------------------------------
        step(7, total, "Testing importance decay...")
        # ------------------------------------------------------------------
        items_before = await memory_repo.fetch_by_scope(
            user_id=SCOPE["user_id"], agent_id=SCOPE["agent_id"]
        )
        importances_before = [i.importance for i in items_before]

        affected = await memory_repo.decay_importance(
            decay_factor=0.8,
            min_importance=0.05,
            user_id=SCOPE["user_id"],
            agent_id=SCOPE["agent_id"],
        )

        items_after = await memory_repo.fetch_by_scope(
            user_id=SCOPE["user_id"], agent_id=SCOPE["agent_id"]
        )
        importances_after = [i.importance for i in items_after]

        print(f"      → Items affected: {affected}")
        print(f"      → Before: {[f'{x:.2f}' for x in importances_before]}")
        print(f"      → After:  {[f'{x:.2f}' for x in importances_after]}")

        if all(a <= b for a, b in zip(importances_after, importances_before)):
            ok("Importance scores decreased as expected")
            passed += 1
        else:
            fail("Importance did not decay")

        # ------------------------------------------------------------------
        step(8, total, "Closing MemoryManager...")
        # ------------------------------------------------------------------
        await manager.close()
        ok("Pool closed, scheduler stopped")
        passed += 1

    except Exception as e:
        logger.exception("Unexpected error")
        if manager.is_started:
            await manager.close()
        fail(str(e))

    # ------------------------------------------------------------------
    print(f"\n{'='*50}")
    print(f"  Result: {passed}/{total} steps passed")
    if passed == total:
        print("  All steps passed!")
    print(f"{'='*50}\n")


if __name__ == "__main__":
    print("\n=== agent-memory-layer E2E Test ===\n")
    asyncio.run(main())
