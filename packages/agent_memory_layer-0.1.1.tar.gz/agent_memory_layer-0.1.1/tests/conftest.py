import pytest


class AsyncContextManagerMock:
    """
    makes a value usable as : async with pool.acquire() as conn
    """

    def __init__(self, value) -> None:
        self._value = value

    async def __aenter__(self):
        return self._value

    async def __aexit__(self, *args):
        pass


def make_mock_pool(
    fetch_result=None,
    fetchrow_result=None,
    execute_result="UPDATE 1",
):
    """
    returns a (pool, conn) tuple where both are mocks

    pool.acquire() works as an async context manager
    conn.fetch / conn.fetchrow / conn.execute are pre-configured with the provided return value
    """

    from unittest.mock import AsyncMock, MagicMock

    conn = AsyncMock()
    conn.fetch = AsyncMock(return_value=fetch_result or [])
    conn.fetchrow = AsyncMock(return_value=fetchrow_result)
    conn.execute = AsyncMock(return_value=execute_result)

    pool = MagicMock()
    pool.acquire = MagicMock(return_value=AsyncContextManagerMock(conn))

    return pool, conn


@pytest.fixture
def mock_pool():
    pool, _ = make_mock_pool()
    return pool


@pytest.fixture
def make_pool_and_conn():
    return make_mock_pool()
