from unittest.mock import AsyncMock, Mock

import pytest

from agent_memory_layer.manager import MemoryManager


def build_manager() -> MemoryManager:
    return MemoryManager(
        db_url="postgresql://example",
        aicore_client_id="client-id",
        aicore_client_secret="client-secret",
        aicore_auth_url="https://auth.example.com",
        aicore_base_url="https://api.example.com",
    )


@pytest.mark.asyncio
async def test_create_starts_manager(monkeypatch):
    fake_pool = Mock()
    fake_scheduler = Mock()
    fake_inject_node = Mock()
    fake_record_node = Mock()

    create_pool = AsyncMock(return_value=fake_pool)
    apply_migrations = AsyncMock()
    build_scheduler = Mock(return_value=fake_scheduler)

    monkeypatch.setattr("agent_memory_layer.manager.create_pool", create_pool)
    monkeypatch.setattr("agent_memory_layer.manager.apply_migrations", apply_migrations)
    monkeypatch.setattr(
        "agent_memory_layer.manager.build_inject_node", Mock(return_value=fake_inject_node)
    )
    monkeypatch.setattr(
        "agent_memory_layer.manager.build_record_node", Mock(return_value=fake_record_node)
    )
    monkeypatch.setattr("agent_memory_layer.manager.build_scheduler", build_scheduler)

    manager = await MemoryManager.create(
        db_url="postgresql://example",
        aicore_client_id="client-id",
        aicore_client_secret="client-secret",
        aicore_auth_url="https://auth.example.com",
        aicore_base_url="https://api.example.com",
    )

    create_pool.assert_awaited_once_with(manager.config)
    apply_migrations.assert_awaited_once_with(fake_pool, manager.config)
    build_scheduler.assert_called_once_with(fake_pool, manager.config, scopes=None)
    fake_scheduler.start.assert_called_once_with()
    assert manager.pool is fake_pool
    assert manager.inject_node is fake_inject_node
    assert manager.record_node is fake_record_node
    assert manager.is_started is True


@pytest.mark.asyncio
async def test_start_cleans_up_pool_when_setup_fails(monkeypatch):
    fake_pool = Mock()

    create_pool = AsyncMock(return_value=fake_pool)
    close_pool = AsyncMock()

    monkeypatch.setattr("agent_memory_layer.manager.create_pool", create_pool)
    monkeypatch.setattr(
        "agent_memory_layer.manager.apply_migrations",
        AsyncMock(side_effect=RuntimeError("setup failed")),
    )
    monkeypatch.setattr("agent_memory_layer.manager.close_pool", close_pool)

    manager = build_manager()

    with pytest.raises(RuntimeError, match="setup failed"):
        await manager.start()

    close_pool.assert_awaited_once_with(fake_pool)
    assert manager.pool is None
    assert manager.scheduler is None
    assert manager.is_started is False


@pytest.mark.asyncio
async def test_close_stops_scheduler_and_closes_pool(monkeypatch):
    fake_pool = Mock()
    fake_scheduler = Mock()
    close_pool = AsyncMock()

    monkeypatch.setattr("agent_memory_layer.manager.close_pool", close_pool)

    manager = build_manager()
    manager.pool = fake_pool
    manager.scheduler = fake_scheduler
    manager.inject_node = Mock()
    manager.record_node = Mock()
    manager.is_started = True

    await manager.close()

    fake_scheduler.shutdown.assert_called_once_with(wait=False)
    close_pool.assert_awaited_once_with(fake_pool)
    assert manager.pool is None
    assert manager.scheduler is None
    assert manager.inject_node is None
    assert manager.record_node is None
    assert manager.is_started is False