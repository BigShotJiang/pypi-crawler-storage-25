# Changelog

## 0.1.0 (2026-04-18)

Initial release.

### Features

- `MemoryManager` — single entry point for the library lifecycle (start, use, close)
- LangGraph nodes: `inject_node` (retrieves memories) and `record_node` (saves episodes)
- Consolidation pipeline — LLM-based fact extraction from conversation episodes via SAP AI Core
- Importance decay — daily background job that gradually lowers memory importance scores
- Scheduled consolidation — periodic background job via APScheduler
- PostgreSQL storage layer with asyncpg (episodes, memory items, consolidation jobs)
- Auto-migrations on startup
- Configuration via environment variables, `.env` files, or Cloud Foundry VCAP_SERVICES
- Docker Compose setup for local PostgreSQL development
