import logging

from agent_memory_layer.config import MemoryConfig
from agent_memory_layer.nodes import build_inject_node, build_record_node
from agent_memory_layer.scheduler import build_scheduler
from agent_memory_layer.storage.database import apply_migrations, close_pool, create_pool

logger = logging.getLogger(__name__)


class MemoryManager:
    """
    Single entry point for agent-memory-layer.

    Usage:
        manager = MemoryManager(
            db_url="postgresql://user:pass@host/db",
            aicore_client_id="...",
            aicore_client_secret="...",
            aicore_auth_url="...",
            aicore_base_url="...",
        )

        await manager.start()

        graph.add_node("inject_memory", manager.inject_node)
        graph.add_node("record_memory", manager.record_node)

        await manager.close()
    """

    def __init__(
        self,
        *,
        db_url,
        aicore_client_id,
        aicore_client_secret,
        aicore_auth_url,
        aicore_base_url,
        aicore_llm_model="gpt-4o",
        aicore_resource_group="default",
        db_schema="sap_agent_memory",
        scopes=None,
        inject_min_importance=0.1,
        inject_limit=20,
        consolidation_interval_hours=6,
        decay_daily_hour=2,
        decay_factor=0.95,
        decay_threshold=0.05,
    ):
        """Store configuration and prepare the manager for startup."""
        self.config = MemoryConfig(
            aicore_client_id=aicore_client_id,
            aicore_client_secret=aicore_client_secret,
            aicore_auth_url=aicore_auth_url,
            aicore_base_url=aicore_base_url,
            aicore_llm_model=aicore_llm_model,
            aicore_resource_group=aicore_resource_group,
            sap_memory_db_schema=db_schema,
            sap_memory_db_url=db_url,
            sap_memory_inject_min_importance=inject_min_importance,
            sap_memory_inject_limit=inject_limit,
            sap_memory_consolidation_interval_hours=consolidation_interval_hours,
            sap_memory_consolidation_decay_daily_hour=decay_daily_hour,
            sap_memory_consolidation_decay_factor=decay_factor,
            sap_memory_consolidation_decay_threshold=decay_threshold,
        )

        self.scopes = scopes
        self.pool = None
        self.inject_node = None
        self.record_node = None
        self.scheduler = None
        self.is_started = False

    @classmethod
    async def create(
        cls,
        *,
        db_url,
        aicore_client_id,
        aicore_client_secret,
        aicore_auth_url,
        aicore_base_url,
        aicore_llm_model="gpt-4o",
        aicore_resource_group="default",
        db_schema="sap_agent_memory",
        scopes=None,
        inject_min_importance=0.1,
        inject_limit=20,
        consolidation_interval_hours=6,
        decay_daily_hour=2,
        decay_factor=0.95,
        decay_threshold=0.05,
    ):
        """
        Create, start, and return a ready-to-use MemoryManager.
        """
        manager = cls(
            db_url=db_url,
            aicore_client_id=aicore_client_id,
            aicore_client_secret=aicore_client_secret,
            aicore_auth_url=aicore_auth_url,
            aicore_base_url=aicore_base_url,
            aicore_llm_model=aicore_llm_model,
            aicore_resource_group=aicore_resource_group,
            db_schema=db_schema,
            scopes=scopes,
            inject_min_importance=inject_min_importance,
            inject_limit=inject_limit,
            consolidation_interval_hours=consolidation_interval_hours,
            decay_daily_hour=decay_daily_hour,
            decay_factor=decay_factor,
            decay_threshold=decay_threshold,
        )
        await manager.start()
        return manager

    async def start(self):
        """open the database, run setup, and start the scheduler."""
        if self.is_started:
            raise RuntimeError("MemoryManager is already started.")

        self.pool = await create_pool(self.config)
        logger.info("agent-memory-layer: database pool created.")

        try:
            await apply_migrations(self.pool, self.config)
            logger.info("agent-memory-layer: migrations applied.")

            self.inject_node = build_inject_node(self.pool, self.config)
            self.record_node = build_record_node(self.pool, self.config)
            logger.info("agent-memory-layer: nodes ready.")

            self.scheduler = build_scheduler(self.pool, self.config, scopes=self.scopes) # this builds a schdueler and returns us the object having methods registered to schedule jobs
            self.scheduler.start() # this start method comes from the apscheduler library
            logger.info("agent-memory-layer: scheduler started.")
        except Exception:
            await close_pool(self.pool)
            self.pool = None
            self.inject_node = None
            self.record_node = None
            self.scheduler = None
            raise

        self.is_started = True

    async def close(self):
        """
        Shuts down the scheduler and closes the database pool.
        Always call this when your application exits.
        """
        if self.scheduler is not None:
            self.scheduler.shutdown(wait=False)
            self.scheduler = None
            logger.info("agent-memory-layer: scheduler stopped.")

        await close_pool(self.pool)
        if self.pool is not None:
            logger.info("agent-memory-layer: pool closed.")

        self.pool = None
        self.inject_node = None
        self.record_node = None
        self.is_started = False
