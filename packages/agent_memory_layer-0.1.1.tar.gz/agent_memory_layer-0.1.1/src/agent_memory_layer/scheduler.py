import logging
from datetime import datetime, timezone

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.interval import IntervalTrigger

from agent_memory_layer.config import MemoryConfig
from agent_memory_layer.consolidation.pipeline import run_consolidation
from agent_memory_layer.storage.consolidation_job_repository import (
    ConsolidationJobRepository,
)
from agent_memory_layer.storage.episode_repository import EpisodeRepository
from agent_memory_layer.storage.memory_item_repository import MemoryItemRepository

logger = logging.getLogger(__name__)


def build_scheduler(
    pool,
    config: MemoryConfig,
    *,
    scopes: list[dict] | None = None,
) -> AsyncIOScheduler:
    """
    build and return a configured APScheduler AsyncIOScheduler
    schedules two recurring jobs:

    1. consolidation - runs every N hhours , processes unconsolidated episode into memory items for each scope
    2. decay - runs daily at a comfigured hour, decays importance scores and deletes stale facts

    args:
        pool: asyncpg connection pool
        config: MemoryConfig instance
        scopes: list of scope dicts to process

    usage:
        scheduler = build_scheduler(pool, config, scopes=[...])
        schedular.start()
        scheduler.shutdown()
    """

    scheduler = AsyncIOScheduler()
    effective_scopes = scopes or [
        {"user_id": None, "agent_id": None, "workflow_id": None}
    ]

    episode_repo = EpisodeRepository(pool, schema=config.sap_memory_db_schema)
    memory_repo = MemoryItemRepository(pool, schema=config.sap_memory_db_schema)
    job_repo = ConsolidationJobRepository(pool, schema=config.sap_memory_db_schema)

    # job 1: consolidation
    async def consolidation_job():
        logger.info(f"consolidation job strated at : {datetime.now(timezone.utc)}")
        for scope in effective_scopes:
            try:
                job = await run_consolidation(
                    episode_repo=episode_repo,
                    memory_repo=memory_repo,
                    job_repo=job_repo,
                    config=config,
                    user_id=scope.get("user_id"),
                    agent_id=scope.get("agent_id"),
                    workflow_id=scope.get("workflow_id"),
                )

                if job:
                    logger.info(
                        f"consolidation compelte for scope {scope}, facts created: {job.facts_created}"
                    )
            except Exception as e:
                logger.exception(f"consolidation failed for scope {scope}")

    # job 2: decay
    async def decay_job():
        logger.info(f"decay job started at {datetime.now(timezone.utc)}")
        for scope in effective_scopes:
            try:
                affected = await memory_repo.decay_importance(
                    decay_factor=config.sap_memory_consolidation_decay_factor,
                    min_importance=config.sap_memory_consolidation_decay_threshold,
                    user_id=scope.get("user_id"),
                    agent_id=scope.get("agent_id"),
                    workflow_id=scope.get("workflow_id"),
                )

                logger.info(
                    f"decay complete for scope {scope} and items affected: {affected}"
                )
            except Exception as e:
                logger.exception(f"decay failed for scope: {scope}")

    # registering jobs
    scheduler.add_job(
        consolidation_job,
        trigger=IntervalTrigger(
            hours=config.sap_memory_consolidation_cleanup_interval_hours
        ),
        id="sap_memory_consolidation",
        replace_existing=True,
    )

    scheduler.add_job(
        decay_job,
        trigger=CronTrigger(
            hour=config.sap_memory_consolidation_decay_daily_hour,
            timezone="UTC",
        ),
        id="sap_memory_decay",
        replace_existing=True,
    )

    return scheduler
