import json
from contextlib import asynccontextmanager
from pathlib import Path
from typing import AsyncIterator

import asyncpg
from asyncpg import Pool

from agent_memory_layer.config import MemoryConfig

_MIGRATIONS_DIR = Path(__file__).parent.parent / "migrations"


async def _init_connection(conn: asyncpg.Connection) -> None:
    """
    registering JSONB codec on every connection in the pool
    asyncpg create this automatically whenever there is a new connection created
    """
    await conn.set_type_codec(
        "jsonb", encoder=json.dumps, decoder=json.loads, schema="pg_catalog"
    )


async def apply_migrations(pool: Pool, config: MemoryConfig):
    """
    exectues all SQL migration files in order
    substitues {schema} placeholder before execution
    """
    migration_files = sorted(_MIGRATIONS_DIR.glob("*.sql"))
    async with pool.acquire() as conn:
        for path in migration_files:
            sql = path.read_text().format(schema=config.sap_memory_db_schema)
            await conn.execute(sql)


async def create_pool(
    config: MemoryConfig, *, min_size: int = 2, max_size: int = 10
) -> Pool:
    """Create and return an asyncpg pool."""
    return await asyncpg.create_pool(
        dsn=config.db_dsn,
        min_size=min_size,
        max_size=max_size,
        init=_init_connection,
    )


async def close_pool(pool: Pool | None) -> None:
    """Close the pool if it exists."""
    if pool is not None:
        await pool.close()


@asynccontextmanager
async def get_pool(
    config: MemoryConfig, *, min_size: int = 2, max_size: int = 10
) -> AsyncIterator[Pool]:
    """
    async context manager that creates, yields, and closes an asyncpg Pool.

    usage:
    aysnc with get_pool(config) as pool:
        repo = EpisodeRepository(pool, schema=config.sap_memory_db_schema)
    """

    pool = await create_pool(config, min_size=min_size, max_size=max_size)

    try:
        yield pool
    finally:
        await close_pool(pool)
