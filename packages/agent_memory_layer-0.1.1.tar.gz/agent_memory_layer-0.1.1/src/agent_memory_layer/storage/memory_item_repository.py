from uuid import UUID
from asyncpg import Pool

from agent_memory_layer.models.memory_item import MemoryItem


class MemoryItemRepository:
    """
    persistance layer for MemoryItem objects.
    """

    def __init__(self, pool: Pool, *, schema: str = "sap_agent_memory") -> None:
        self._pool = pool
        self._s = schema

    async def upsert(self, item: MemoryItem) -> None:
        """
        insert or update a memory item by primary key
        """
        async with self._pool.acquire() as conn:
            await conn.execute(
                f"""
                INSERT INTO {self._s}.memory_items
                (id, user_id, agent_id, workflow_id, content, memory_types, importance, created_at, updated_at)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
                ON CONFLICT (id) DO UPDATE SET
                    content = EXCLUDED.content,
                    memory_types = EXCLUDED.memory_types,
                    importance = EXCLUDED.importance,
                    updated_at = EXCLUDED.updated_at
                """,
                item.id,
                item.user_id,
                item.agent_id,
                item.workflow_id,
                item.content,
                item.memory_types,
                item.importance,
                item.created_at,
                item.updated_at,
            )

    async def fetch_by_scope(
        self,
        *,
        user_id: str | None = None,
        agent_id: str | None = None,
        workflow_id: str | None = None,
        min_importance: float = 0.0,
        limit: int = 100,
    ) -> list[MemoryItem]:
        """
        fetches memory item for a scope, ordered by importance descending
        """
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(
                f"""
                SELECT * FROM {self._s}.memory_items
                WHERE user_id IS NOT DISTINCT FROM $1
                AND agent_id IS NOT DISTINCT FROM $2
                AND workflow_id IS NOT DISTINCT FROM $3
                AND importance >=$4
                ORDER BY importance DESC
                LIMIT $5 
                """,
                user_id,
                agent_id,
                workflow_id,
                min_importance,
                limit,
            )
        return [MemoryItem(**dict(row)) for row in rows]

    async def delete(self, item_id: UUID) -> bool:
        """
        delete a memory item by id
        returns True if deleted, False if not found
        """
        async with self._pool.acquire() as conn:
            result = await conn.execute(
                f"""
                DELETE FROM {self._s}.memory_items WHERE id = $1
                """,
                item_id,
            )
        return int(result.split()[-1]) == 1

    async def decay_importance(
        self,
        *,
        decay_factor: float,
        min_importance: float,
        user_id: str | None = None,
        agent_id: str | None = None,
        workflow_id: str | None = None,
    ) -> int:
        """
        multiply importance by decay factor for all items in scope
        items that fall below min_importance are deleted
        returns total rows affected
        """

        async with self._pool.acquire() as conn:
            updated = await conn.execute(
                f"""
                UPDATE {self._s}.memory_items
                SET importance = importance * $1
                WHERE importance * $1 >= $2
                AND user_id     IS NOT DISTINCT FROM $3                                                                 
                AND agent_id    IS NOT DISTINCT FROM $4                                                                 
                AND workflow_id IS NOT DISTINCT FROM $5 
""",
                decay_factor,
                min_importance,
                user_id,
                agent_id,
                workflow_id,
            )

            deleted = await conn.execute(
                f"""                                                                                                      
                  DELETE FROM {self._s}.memory_items                                                                        
                  WHERE importance < $1                                                                                     
                    AND user_id     IS NOT DISTINCT FROM $2                                                                 
                    AND agent_id    IS NOT DISTINCT FROM $3                                                                 
                    AND workflow_id IS NOT DISTINCT FROM $4                                                                 
                  """,
                min_importance,
                user_id,
                agent_id,
                workflow_id,
            )

        return int(updated.split()[-1]) + int(deleted.split()[-1])
