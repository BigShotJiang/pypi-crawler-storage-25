from uuid import UUID

import asyncpg
from asyncpg import Pool

from agent_memory_layer.models.episode import EpisodeRecord


class EpisodeRepository:
    """
    persistance layer for EpisodeRecord objects
    """

    def __init__(self, pool: Pool, *, schema: str = "sap_agent_memory") -> None:
        self._pool = pool
        self._s = schema

    async def save(self, episode: EpisodeRecord) -> None:
        """
        inserts a new episode record
        """
        async with self._pool.acquire() as conn:
            await conn.execute(
                f"""
                INSERT INTO {self._s}.episodes
                (id, user_id, agent_id, workflow_id, messages, created_at, consolidated)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
                """,
                episode.id,
                episode.user_id,
                episode.agent_id,
                episode.workflow_id,
                episode.messages,
                episode.created_at,
                episode.consolidated,
            )

    async def get_unconsolidated(
        self,
        *,
        user_id: str | None = None,
        agent_id: str | None = None,
        workflow_id: str | None = None,
        limit: int = 500,
    ) -> list[EpisodeRecord]:
        """
        fetches unprocessed episodes for a given scope
        """
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(
                f"""
                SELECT * FROM {self._s}.episodes
                WHERE consolidated = FALSE
                AND user_id IS NOT DISTINCT FROM $1
                AND agent_id IS NOT DISTINCT FROM $2
                AND workflow_id IS NOT DISTINCT FROM $3
                ORDER BY created_at ASC
                LIMIT $4
                """,
                user_id,
                agent_id,
                workflow_id,
                limit,
            )
        return [EpisodeRecord(**dict(row)) for row in rows]

    async def mark_consolidated(self, episode_ids: list[UUID]) -> int:
        """
        bulk marked episodes as consolidated
        returns number or rows updates
        """
        if not episode_ids:
            return 0
        async with self._pool.acquire() as conn:
            result = await conn.execute(
                f"""
                UPDATE {self._s}.episodes 
                SET consolidated = TRUE
                WHERE id = ANY($1::uuid[])
                """,
                episode_ids,
            )
        return int(result.split()[-1])
