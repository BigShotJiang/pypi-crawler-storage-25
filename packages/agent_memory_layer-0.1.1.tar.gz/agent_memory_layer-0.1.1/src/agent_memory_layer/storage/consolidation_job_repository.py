from datetime import datetime
from uuid import UUID

from asyncpg import Pool

from agent_memory_layer.models.consolidation_job import ConsolidationJob


class ConsolidationJobRepository:
    """
    persistance layer for Consolidation objects
    """

    def __init__(self, pool: Pool, *, schema: str = "sap_agent_memory") -> None:
        self._pool = pool
        self._s = schema

    async def create(self, job: ConsolidationJob) -> None:
        """
        insert a new consolidation job record
        """
        async with self._pool.acquire() as conn:
            await conn.execute(
                f"""
            INSERT INTO {self._s}.consolidation_jobs
            (id, scope_user_id, scope_agent_id, scope_workflow_id, status, episodes_processed, facts_created, content_checksum, started_at, finished_at, error)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
            """,
                job.id,
                job.scope_user_id,
                job.scope_agent_id,
                job.scope_workflow_id,
                job.status,
                job.episodes_processed,
                job.facts_created,
                job.content_checksum,
                job.started_at,
                job.finished_at,
                job.error,
            )

    async def update_status(
        self,
        job_id: UUID,
        *,
        status: str,
        episodes_processed: int = 0,
        facts_created: int = 0,
        content_checksum: str | None = None,
        finished_at: datetime | None = None,
        error: str | None = None,
    ) -> None:
        """
        updates job's outcome field after pipeline completes or fails
        """
        async with self._pool.acquire() as conn:
            await conn.execute(
                f"""
                UPDATE {self._s}.consolidation_jobs SET
                status = $2,
                episodes_processed = $3,
                facts_created = $4,
                content_checksum = $5,
                finished_at = $6,
                error = $7
                WHERE id = $1
                """,
                job_id,
                status,
                episodes_processed,
                facts_created,
                content_checksum,
                finished_at,
                error,
            )

    async def get_last_for_scope(
        self,
        *,
        user_id: str | None = None,
        agent_id: str | None = None,
        workflow_id: str | None = None,
    ) -> ConsolidationJob | None:
        """
        returns the most recently started job for a given scope
        returns none if no job has ever run for this scope
        """

        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                f"""
                SELECT * FROM {self._s}.consolidation_jobs
                    WHERE scope_user_id     IS NOT DISTINCT FROM $1                                                   
                AND scope_agent_id    IS NOT DISTINCT FROM $2
                AND scope_workflow_id IS NOT DISTINCT FROM $3
                ORDER BY started_at DESC                                                                          
                LIMIT 1 
                """,
                user_id,
                agent_id,
                workflow_id,
            )

        if row is None:
            return None

        return ConsolidationJob(**dict(row))
