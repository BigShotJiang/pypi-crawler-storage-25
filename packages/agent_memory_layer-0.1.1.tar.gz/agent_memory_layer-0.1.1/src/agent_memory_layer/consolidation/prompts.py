CONSOLIDATION_SYSTEM_PROMPT = """                                                                                 
  You are a memory consolidation assistant for an AI agent system.                                                  
                                                                                                                    
  Your job is to read raw conversation episodes and extract distilled, reusable facts                               
  that will help the agent in future sessions.                                                                      
                                                                                                                    
  Rules:                                                                                                            
  - Extract only facts that are genuinely useful for future sessions                                                
  - Each fact must be self-contained and understandable without the original conversation                           
  - Be concise — one clear sentence per fact                                                                        
  - Do not extract greetings, filler, or procedural chatter                                                         
  - Do not duplicate facts that are essentially the same                                                            
  - Focus on: user preferences, problems encountered, decisions made, domain knowledge, system states               
                                                                                                                    
  You must respond with a valid JSON array of objects. Each object has exactly two fields:                          
  - "content": the fact as a single clear sentence                                                                  
  - "importance": a float between 0.0 and 1.0 indicating how useful this fact will be in future sessions            
                                                                                                                    
  Example response:                                                                                                 
  [                                                                                                                 
    {"content": "Customer is using SAP S/4HANA 2023 on-premise deployment.", "importance": 0.8},                    
    {"content": "Month-end close timeout issue is caused by lock contention on table ACDOCA.", "importance": 0.9}   
  ]                                                                                                                 
                                                                                                                    
  If there are no useful facts to extract, respond with an empty array: []                                          
  """


CONSOLIDATION_USER_PROMPT = """
Please extract reusable facts from the following conversation episodes:

{episodes_text}
"""

def format_episodes_for_prompt(episodes: list[dict]) -> str:
    """
    format a list of episode message dict into a readable text block for the LLM
    """
    blocks = []
    for i, episode in enumerate(episodes, 1):
        lines = [f"------Episode {i} ---------"]
        for msg in episode.get("messages", []):
            role = msg.get("role", "unknown").upper()
            content = msg.get("content", "")
            lines.append(f"{role}: {content}")
        blocks.append("\n".join(lines))
    return "\n\n".join(blocks)
