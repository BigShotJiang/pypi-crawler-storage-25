import hashlib
import json
import logging
from datetime import datetime, timezone

from gen_ai_hub.orchestration.models.llm import LLM                                                               
from gen_ai_hub.orchestration.models.template import Template                                                     
from gen_ai_hub.orchestration.models.message import SystemMessage, UserMessage                                    
from gen_ai_hub.orchestration.models.config import OrchestrationConfig                                            
from gen_ai_hub.orchestration.service import OrchestrationService 

from agent_memory_layer.config import MemoryConfig
from agent_memory_layer.models.consolidation_job import ConsolidationJob
from agent_memory_layer.models.memory_item import MemoryItem
from agent_memory_layer.storage.consolidation_job_repository import ConsolidationJobRepository
from agent_memory_layer.storage.episode_repository import EpisodeRepository
from agent_memory_layer.storage.memory_item_repository import MemoryItemRepository
from agent_memory_layer.consolidation.prompts import (
    CONSOLIDATION_SYSTEM_PROMPT,
    CONSOLIDATION_USER_PROMPT,
    format_episodes_for_prompt,
)

logger = logging.getLogger(__name__)

def _compute_checksum(episodes)->str:
    """
    SHA256 of all episode message content - used for idempotency
    """
    combined = json.dumps(
        [e.messages for e in episodes],
        sort_keys=True,
    ).encode()
    return hashlib.sha256(combined).hexdigest()

def _parse_llm_response(raw: str)-> list[dict]:
    """
    parse LLM json response into a list of fact dicts
    returns empty list if parsing fails
    """
    try:
        cleaned = raw.strip()
        if cleaned.startswith("```"):
            cleaned = cleaned.split("\n", 1)[-1]
            cleaned = cleaned.rsplit("````",1)[0]
        return json.loads(cleaned)
    except (json.JSONDecodeError, ValueError):
        logger.warning("failed to parse LLM response as JSON: %s", raw[:200])
        return []

def _call_llm(config: MemoryConfig, episodes_text: str) -> str:
    """
    call the sap ai core orchestration service
    returns raw llm response string
    """
    llm = LLM(
        name=config.aicore_llm_model,
        parameters={"temperature": 0.0, "max_tokens": 2048}
    )

    template = Template(
        messages=[
            SystemMessage(content=CONSOLIDATION_SYSTEM_PROMPT),
            UserMessage(
                content=CONSOLIDATION_USER_PROMPT.format(episodes_text=episodes_text)
            )
        ]
    )

    service = OrchestrationService(config=OrchestrationConfig(llm=llm, template=template))
    response = service.run()
    return response.module_results.llm.choices[0].message.content # type: ignore


async def run_consolidation(
        *,
        episode_repo: EpisodeRepository,
        memory_repo: MemoryItemRepository,
        job_repo: ConsolidationJobRepository,
        config: MemoryConfig,
        user_id: str | None = None,
        agent_id: str | None = None,
        workflow_id: str | None = None,
) -> ConsolidationJob | None:
    """
    run one consolidation pipeline pass for a given scope
    steps:
    1. loading unconsolidated episodes
    2. checksum check - skip if nothing new
    3. creating job record
    4. calling LLM to extract facts
    5. writting memory items
    6. mark episodes consolidated
    7. update jobs to completed/failed

    returns the ConsolidationJob record for this run
    """

    # 1. loading unconsolidated episodes
    episodes = await episode_repo.get_unconsolidated(
        user_id=user_id,
        agent_id=agent_id,
        workflow_id=workflow_id,
    )

    if not episodes:
        logger.info(f"no unconsolidated episodes for scope: {user_id}, {agent_id}, {workflow_id}")
        return None
    
    # 2. checksum check
    checksum = _compute_checksum(episodes)
    last_job = await job_repo.get_last_for_scope(
        user_id=user_id,
        agent_id=agent_id,
        workflow_id=workflow_id,
    )

    if last_job and last_job.content_checksum == checksum:
        logger.info(f"checksum unchanged, skipping consolidation for scope {user_id}, {agent_id}, {workflow_id}")
        return last_job
    
    # 3. create job record
    job = ConsolidationJob(
        scope_user_id=user_id,
        scope_agent_id=agent_id,
        scope_workflow_id=workflow_id,
    )

    await job_repo.create(job)

    try:
       # 4. calling llm
        episodes_text = format_episodes_for_prompt(
           [{"messages": e.messages} for e in episodes]
        )

        raw_text = _call_llm(config, episodes_text)

       # 5. parsing + writting memory items
        facts = _parse_llm_response(raw_text)
        for fact in facts:
           item = MemoryItem(
               user_id=user_id,
               agent_id=agent_id,
               workflow_id=workflow_id,
               content=fact.get("content", ""),
               importance=float(fact.get("importance", 0.5))
           )
           await memory_repo.upsert(item)
        

        # 6. marking episodes consolidated
        await episode_repo.mark_consolidated([e.id for e in episodes])
       
       # 7. updating job to completed
        await job_repo.update_status(
           job.id,
           status="completed",
           episodes_processed=len(facts),
           facts_created=len(facts),
           content_checksum=checksum,
           finished_at=datetime.now(timezone.utc),
       )

        job.status="completed"
        job.facts_created=len(facts)
        job.episodes_processed=len(episodes)

    except Exception as e:
        logging.error(f"consolidation pipeline failed for {user_id}, {agent_id}, {workflow_id}")
        await job_repo.update_status(
            job.id,
            status="failed",
            error=str(e),
            finished_at=datetime.now(timezone.utc)
        )

        job.status="failed"
        job.error=str(e)
    
    return job








    


