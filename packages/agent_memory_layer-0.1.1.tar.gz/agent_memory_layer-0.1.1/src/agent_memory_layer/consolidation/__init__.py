from .pipeline import run_consolidation

__all__ = ["run_consolidation"]

