from pydantic import BaseModel, Field
from datetime import datetime, timezone
from uuid import UUID, uuid4


class MemoryItem(BaseModel):
    """
    a single distilled fact extracted from episodes by the consolidation pipeline.
    these are what agents actually read at the start of the each session.
    """

    id: UUID = Field(default_factory=uuid4)

    user_id: str | None = None
    agent_id: str | None = None
    workflow_id: str | None = None

    content: str
    memory_types: str = "semantic"
    importance: float = 0.5

    # timestamps
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
