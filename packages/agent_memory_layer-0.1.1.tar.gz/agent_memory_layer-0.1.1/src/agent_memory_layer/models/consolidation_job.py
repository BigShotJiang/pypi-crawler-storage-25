from datetime import datetime, timezone
from uuid import UUID, uuid4

from pydantic import BaseModel, Field


class ConsolidationJob(BaseModel):
    """
    tracks a single consolidation pipeline run
    created at the start of each run, updated when it finishes
    the content_checksum prevents reprocessing the same episodes twice
    """

    id: UUID = Field(default_factory=uuid4)

    # which scope this job ran for
    scope_user_id: str | None = None
    scope_agent_id: str | None = None
    scope_workflow_id: str | None = None

    # job lifecycle
    status: str = "pending"
    episodes_processed: int = 0
    facts_created: int = 0

    # idempotency: SHA256 of all episode content processed
    # if this matches the last run's checksum - nothing new - it'll be skipped
    content_checksum: str | None = None

    started_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    finished_at: datetime | None = None

    # error if status == failed
    error: str | None = None
