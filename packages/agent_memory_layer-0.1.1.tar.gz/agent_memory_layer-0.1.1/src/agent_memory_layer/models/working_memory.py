from pydantic import BaseModel, Field
from datetime import datetime, timezone
from uuid import UUID, uuid4


class WorkingMemoryFrame(BaseModel):
    """
    ephimeral in-session memory, created at sesion start by inject_node
    never written to database. discarded when the langgraph run ends.
    """

    session_id: UUID = Field(default_factory=uuid4)

    user_id: str | None = None
    agent_id: str | None = None
    workflow_id: str | None = None

    # content
    injected_facts: list[str] = Field(default_factory=list)

    scratch: dict = Field(default_factory=dict)

    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    