from datetime import datetime, timezone
from uuid import UUID, uuid4

from pydantic import BaseModel, Field


class EpisodeRecord(BaseModel):
    """
    A single saved conversation turn - raw, unprocessed.
    """

    id: UUID = Field(default_factory=uuid4)

    user_id: str | None = None
    agent_id: str | None = None
    workflow_id: str | None = None

    messages: list[dict] = Field(default_factory=list)

    # metadata
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    consolidated: bool = False  # flipped to True after pipeline runs
