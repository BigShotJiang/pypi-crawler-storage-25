-- creating schema
CREATE SCHEMA IF NOT EXISTS {schema};

--------------------------------------------------------------------
-- episodes
CREATE TABLE IF NOT EXISTS {schema}.episodes (
    id UUID PRIMARY KEY,
    user_id TEXT,
    agent_id TEXT,
    workflow_id TEXT,
    messages JSONB NOT NULL DEFAULT '[]',
    created_at TIMESTAMPTZ NOT NULL,
    consolidated BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE INDEX IF NOT EXISTS idx_episodes_scope ON {schema}.episodes (user_id, agent_id, workflow_id); -- indexing only the rows where consolidated=false (partial indexing)
CREATE INDEX IF NOT EXISTS idx_episodes_unconsolidated ON {schema}.episodes (consolidated)
WHERE consolidated = FALSE;

----------------------------------------------------------------------
-- memory items
CREATE TABLE IF NOT EXISTS {schema}.memory_items (
    id UUID PRIMARY KEY,
    user_id TEXT,
    agent_id TEXT,
    workflow_id TEXT,
    content TEXT NOT NULL,
    memory_types TEXT NOT NULL DEFAULT 'semantic',
    importance DOUBLE PRECISION NOT NULL DEFAULT 0.5,
    created_at TIMESTAMPTZ NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_memory_items_scope ON {schema}.memory_items (user_id, agent_id, workflow_id);

CREATE INDEX IF NOT EXISTS idx_memory_items_importance ON {schema}.memory_items (importance);

-------------------------------------------------------------------------
-- consolidation_jobs                                                                                                     
CREATE TABLE IF NOT EXISTS {schema}.consolidation_jobs (
    id UUID PRIMARY KEY,
    scope_user_id TEXT,
    scope_agent_id TEXT,
    scope_workflow_id TEXT,
    status TEXT NOT NULL DEFAULT 'pending',
    episodes_processed INTEGER NOT NULL DEFAULT 0,
    facts_created INTEGER NOT NULL DEFAULT 0,
    content_checksum TEXT,
    started_at TIMESTAMPTZ NOT NULL,
    finished_at TIMESTAMPTZ,
    error TEXT
);

CREATE INDEX IF NOT EXISTS idx_consolidation_jobs_scope ON {schema}.consolidation_jobs (scope_user_id, scope_agent_id, scope_workflow_id);