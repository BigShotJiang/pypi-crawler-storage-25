import os
from typing import Any

from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class MemoryConfig(BaseSettings):
    """
    Configuration for agent-memory-layer.

    reads from environment variables or a .env file.
    All AICORE_* vars match the existing SWA codebase exactly — no extra setup
    needed for teams already using gen-ai-hub.

    DB vars use the SAP_MEMORY_DB_ prefix.
    Consolidation tuning vars use the SAP_MEMORY_CONSOLIDATION_ prefix.
    """

    # --- AI Core (same as SWA settings.py) ---
    aicore_client_id: str | None = None
    aicore_client_secret: str | None = None
    aicore_auth_url: str | None = None
    aicore_base_url: str | None = None
    aicore_resource_group: str = "default"
    aicore_llm_model: str = "gpt-4o"

    # --- Database ---
    sap_memory_db_host: str = "localhost"
    sap_memory_db_port: int = 5432
    sap_memory_db_name: str = "sap_memory"
    sap_memory_db_user: str = "postgres"
    sap_memory_db_password: str = "postgres"
    sap_memory_db_schema: str = "sap_agent_memory"
    sap_memory_db_url: str | None = None

    # --- Consolidation tuning ---
    sap_memory_consolidation_interval_hours: int = 6
    sap_memory_consolidation_decay_daily_hour: int = 2   # 2am UTC
    sap_memory_consolidation_decay_factor: float = 0.95
    sap_memory_consolidation_decay_threshold: float = 0.05
    sap_memory_consolidation_cleanup_interval_hours: int = 1
    sap_memory_inject_min_importance: float = 0.1
    sap_memory_inject_limit: int = 20

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

    @model_validator(mode="after")
    def _export_aicore_env_vars(self) -> "MemoryConfig":
        """
        Mirror AICore credentials into os.environ so gen-ai-hub SDK picks them
        up automatically — same behaviour as SWA settings.py.
        """
        if self.aicore_client_id:
            os.environ["AICORE_CLIENT_ID"] = self.aicore_client_id
        if self.aicore_client_secret:
            os.environ["AICORE_CLIENT_SECRET"] = self.aicore_client_secret
        if self.aicore_auth_url:
            os.environ["AICORE_AUTH_URL"] = self.aicore_auth_url
        if self.aicore_base_url:
            os.environ["AICORE_BASE_URL"] = self.aicore_base_url
        os.environ["AICORE_RESOURCE_GROUP"] = self.aicore_resource_group
        return self

    @property
    def db_dsn(self) -> str:
        """asyncpg-compatible DSN string."""
        if self.sap_memory_db_url:
            return self.sap_memory_db_url
        return (
            f"postgresql://{self.sap_memory_db_user}:{self.sap_memory_db_password}"
            f"@{self.sap_memory_db_host}:{self.sap_memory_db_port}/{self.sap_memory_db_name}"
        )

    @classmethod
    def from_vcap_services(cls, vcap: dict[str, Any]) -> "MemoryConfig":
        """
        Building config from a parsed VCAP_SERVICES dict (Cloud Foundry).

        Extracting AICore credentials from the 'aicore' binding and
        PostgreSQL credentials from the 'postgresql' binding automatically.

        Usage:
            import json, os
            vcap = json.loads(os.environ["VCAP_SERVICES"])
            config = MemoryConfig.from_vcap_services(vcap)
        """
        overrides: dict[str, Any] = {}

        # AICore binding
        aicore_bindings = vcap.get("aicore", [])
        if aicore_bindings:
            creds = aicore_bindings[0]["credentials"]
            overrides["aicore_client_id"] = creds.get("clientid", "")
            overrides["aicore_client_secret"] = creds.get("clientsecret", "")
            overrides["aicore_auth_url"] = creds.get("url", "")
            overrides["aicore_base_url"] = (
                creds.get("serviceurls", {}).get("AI_API_URL", "")
            )

        # PostgreSQL binding (HANA Cloud or standard CF postgres)
        pg_bindings = vcap.get("postgresql", vcap.get("hana", []))
        if pg_bindings:
            creds = pg_bindings[0]["credentials"]
            overrides["sap_memory_db_host"] = creds.get("hostname", "localhost")
            overrides["sap_memory_db_port"] = int(creds.get("port", 5432))
            overrides["sap_memory_db_name"] = creds.get("dbname", "sap_memory")
            overrides["sap_memory_db_user"] = creds.get("username", "postgres")
            overrides["sap_memory_db_password"] = creds.get("password", "")

        return cls(**overrides)
