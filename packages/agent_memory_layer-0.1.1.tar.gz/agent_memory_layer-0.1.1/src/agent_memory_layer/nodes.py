import logging
from datetime import datetime, timezone
from typing import Any

from asyncpg import Pool

from agent_memory_layer.config import MemoryConfig
from agent_memory_layer.models.episode import EpisodeRecord
from agent_memory_layer.models.working_memory import WorkingMemoryFrame
from agent_memory_layer.storage.episode_repository import EpisodeRepository
from agent_memory_layer.storage.memory_item_repository import MemoryItemRepository

logger = logging.getLogger(__name__)

def build_inject_node(
        pool: Pool,
        config: MemoryConfig,
):
    """
    returns a langgraph node function that loads MemoryItems into state at the start of the session

    usage in langgraph graph:

    inject = build_inject_node(pool, config)
    graph.add_node("inject_memory", inject)
    """

    memory_repo = MemoryItemRepository(pool, schema=config.sap_memory_db_schema)

    async def inject_node(state: dict[str, Any])-> dict[str, Any]:
        user_id = state.get("user_id")
        agent_id = state.get("agent_id")
        workflow_id = state.get("workflow_id")

        items = await memory_repo.fetch_by_scope(
            user_id=user_id,
            agent_id=agent_id,
            workflow_id=workflow_id,
            min_importance=config.sap_memory_inject_min_importance,
            limit=config.sap_memory_inject_limit,
        )

        frame = WorkingMemoryFrame(
            user_id=user_id,
            agent_id=agent_id,
            workflow_id=workflow_id,
            injected_facts=[item.content for item in items]
        )

        logger.info(f"injected memory facts for scope, {len(items)}, {user_id}, {agent_id}, {workflow_id}")
        return {**state, "working_memory": frame.model_dump()}
    
    return inject_node


def build_record_node(pool: Pool, config: MemoryConfig):
    """
    returns a langgraph node function that saves the conversation as an EpisodeRecord at the end of a session

    usage in langgraph graph:
    record = build_record_node(pool, config)
    graph.add_node("record_memory", record)
    """

    episode_repo = EpisodeRepository(pool, schema=config.sap_memory_db_schema)

    async def record_node(state: dict[str, Any])-> dict[str, Any]:
        user_id = state.get("user_id")
        agent_id = state.get("agent_id")
        workflow_id = state.get("workflow_id")

        messages = state.get("messages", [])

        if not messages:
            logger.info("no messages in state, skipping episode recording")
            return state

        episode = EpisodeRecord(
            user_id=user_id,
            agent_id=agent_id,
            workflow_id=workflow_id,
            messages=messages,
            created_at=datetime.now(timezone.utc),
        )

        await episode_repo.save(episode)

        logger.info(f"recorded episode {episode.id} for scope: {user_id}, {agent_id}, {workflow_id}")
        return state # we need to return the state here as langgraph expects every node to be returning a dictionary of state
    
    return record_node




