"""Config — surface and inspect CLI configuration."""

import json
import os
import re
from pathlib import Path
from typing import Annotated

import typer

from regard.core.output import die, output

config_app = typer.Typer(
    name="config",
    no_args_is_help=True,
    help="View or change CLI configuration.",
)

DEFAULT_POLYGON_RPC = "https://rpc.regard.computer/regard/evm/137"
DEFAULT_KILLSWITCH_SLIPPAGE = 0.10
DEFAULT_PENDING_TTL_MINUTES = 15
DEFAULT_SEND_COOLDOWN_SECONDS = 30

_ADDRESS_RE = re.compile(r"^0x[a-fA-F0-9]{40}$")
_URL_RE = re.compile(r"^https?://[^\s]+$")

# Mapping of user-facing setting names → (env var, validator, description).
# Agents and users can see the accepted keys via `regard config --help` or by
# reading setting names from `regard config show`.
_SETTINGS = {
    "killswitch-address": "KILLSWITCH_ADDRESS",
    "killswitch-slippage": "KILLSWITCH_SLIPPAGE",
    "polygon-rpc": "POLYGON_RPC",
    "polymarket-clob-url": "POLYMARKET_CLOB_URL",
    "pending-ttl-minutes": "PENDING_TTL_MINUTES",
    "send-max-amount": "SEND_MAX_AMOUNT",
    "send-daily-max": "SEND_DAILY_MAX",
    "send-cooldown-seconds": "SEND_COOLDOWN",
    "send-allow-raw-address": "SEND_ALLOW_RAW_ADDRESS",
}


def _effective_slippage(raw_val) -> float:
    """Return the slippage that killswitch will actually use."""
    if raw_val:
        try:
            s = float(raw_val)
            if 0.001 <= s <= 0.5:
                return s
        except (ValueError, TypeError):
            pass
    return DEFAULT_KILLSWITCH_SLIPPAGE


def _validate_address(value: str) -> str:
    """Accept a 0x-prefixed EVM address; reject anything resembling a private key (64 hex)."""
    value = value.strip()
    if not _ADDRESS_RE.match(value):
        die(
            "validation_error",
            "INVALID_ADDRESS",
            f"Expected a 0x-prefixed EVM address (40 hex chars). Got: {value[:6]}… ({len(value)} chars)",
            hint="An EVM address looks like 0x347E363866Ad5849705e4c3be4FfA7ad0C3f4e14",
        )
    return value


def _trading_address() -> str | None:
    """Best-effort lookup of the trading wallet address from env + settings."""
    from regard.venues.hyperliquid.client import _load_settings_env
    settings = _load_settings_env()
    key = os.environ.get("HYPERLIQUID_PRIVATE_KEY") or settings.get("HYPERLIQUID_PRIVATE_KEY")
    if not key:
        return None
    try:
        import eth_account
        return eth_account.Account.from_key(key).address
    except Exception:
        return None


def _validate_url(value: str) -> str:
    value = value.strip()
    if not _URL_RE.match(value):
        die("validation_error", "INVALID_URL", f"Expected http(s) URL. Got: {value[:40]}…")
    return value


def _validate_slippage(value: str) -> str:
    try:
        f = float(value)
    except ValueError:
        die("validation_error", "INVALID_SLIPPAGE", f"Expected a number between 0.001 and 0.5. Got: {value}")
    if not (0.001 <= f <= 0.5):
        die("validation_error", "INVALID_SLIPPAGE", f"Slippage must be between 0.001 and 0.5. Got: {f}")
    return str(f)


def _validate_ttl_minutes(value: str) -> str:
    """Proposal pending-TTL — integer minutes in [1, 1440] (1 day max)."""
    try:
        m = int(value)
    except ValueError:
        die("validation_error", "INVALID_TTL",
            f"Expected an integer number of minutes (1–1440). Got: {value}")
    if not (1 <= m <= 1440):
        die("validation_error", "INVALID_TTL",
            f"TTL must be between 1 and 1440 minutes (24h max). Got: {m}",
            hint="Crypto moves fast — default 15 min is a reasonable backstop.")
    return str(m)


def _validate_positive_number(value: str) -> str:
    """Positive float (for send amount caps). Any decimal > 0 accepted."""
    try:
        f = float(value)
    except ValueError:
        die("validation_error", "INVALID_NUMBER",
            f"Expected a positive number. Got: {value}")
    if f <= 0:
        die("validation_error", "INVALID_NUMBER",
            f"Must be greater than zero. Got: {f}")
    return str(f)


def _validate_non_negative_int(value: str) -> str:
    """Non-negative integer (for cooldown seconds). 0 = disabled."""
    try:
        n = int(value)
    except ValueError:
        die("validation_error", "INVALID_NUMBER",
            f"Expected a non-negative integer. Got: {value}")
    if n < 0:
        die("validation_error", "INVALID_NUMBER",
            f"Must be zero or greater. Got: {n}")
    return str(n)


def _validate_bool(value: str) -> str:
    """Accept common bool tokens, normalize to 'true' / 'false'.

    Match what settings.local.json typically holds — lowercase string. Env var
    truthy check in upstream code looks for truthy-string presence; storing
    the explicit value here makes the config state readable.
    """
    v = value.strip().lower()
    if v in ("true", "1", "yes", "on"):
        return "true"
    if v in ("false", "0", "no", "off", ""):
        return "false"
    die("validation_error", "INVALID_BOOL",
        f"Expected true/false (or yes/no, on/off, 1/0). Got: {value}")


_VALIDATORS = {
    "killswitch-address": _validate_address,
    "killswitch-slippage": _validate_slippage,
    "polygon-rpc": _validate_url,
    "polymarket-clob-url": _validate_url,
    "pending-ttl-minutes": _validate_ttl_minutes,
    "send-max-amount": _validate_positive_number,
    "send-daily-max": _validate_positive_number,
    "send-cooldown-seconds": _validate_non_negative_int,
    "send-allow-raw-address": _validate_bool,
}


def _project_settings_path() -> Path:
    """Where to write: existing project settings if found (walking up from CWD), else CWD."""
    from regard.venues.hyperliquid.client import _find_project_settings
    found = _find_project_settings()
    return found if found is not None else (Path.cwd() / ".claude" / "settings.local.json")


def _write_setting(env_var: str, value: str) -> Path:
    """Atomic merge of a single env var into <project>/.claude/settings.local.json."""
    path = _project_settings_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    settings: dict = {}
    if path.exists():
        try:
            settings = json.loads(path.read_text())
        except (json.JSONDecodeError, OSError):
            pass
    env = settings.setdefault("env", {})
    env[env_var] = value
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(settings, indent=2) + "\n")
    os.replace(tmp, path)
    return path


@config_app.command()
def show():
    """Show current configuration."""
    from regard.venues.hyperliquid.client import _find_project_settings, _load_settings_env
    from regard.venues.polymarket.client import DEFAULT_CLOB_URL

    settings = _load_settings_env()
    custom_rpc = settings.get("POLYGON_RPC")
    custom_clob_url = settings.get("POLYMARKET_CLOB_URL")

    killswitch_addr = settings.get("KILLSWITCH_ADDRESS")
    custom_slippage = settings.get("KILLSWITCH_SLIPPAGE")
    effective_slip = _effective_slippage(custom_slippage)

    project_settings = _find_project_settings()

    # Pending TTL (minutes) + send safety caps
    pending_ttl = settings.get("PENDING_TTL_MINUTES")
    send_max = settings.get("SEND_MAX_AMOUNT")
    send_daily = settings.get("SEND_DAILY_MAX")
    send_cooldown = settings.get("SEND_COOLDOWN")
    send_raw = settings.get("SEND_ALLOW_RAW_ADDRESS")

    def _ttl_effective(raw):
        try:
            m = int(raw) if raw else DEFAULT_PENDING_TTL_MINUTES
            return m if 1 <= m <= 1440 else DEFAULT_PENDING_TTL_MINUTES
        except (ValueError, TypeError):
            return DEFAULT_PENDING_TTL_MINUTES

    def _cooldown_effective(raw):
        try:
            n = int(raw) if raw else DEFAULT_SEND_COOLDOWN_SECONDS
            return n if n >= 0 else DEFAULT_SEND_COOLDOWN_SECONDS
        except (ValueError, TypeError):
            return DEFAULT_SEND_COOLDOWN_SECONDS

    result = {
        "project_settings_path": str(project_settings) if project_settings else None,
        "in_project": project_settings is not None,
        "polygon_rpc": {
            "current": custom_rpc or DEFAULT_POLYGON_RPC,
            "source": "settings" if custom_rpc else "default",
            "default": DEFAULT_POLYGON_RPC,
        },
        "polymarket_clob_url": {
            "current": custom_clob_url or DEFAULT_CLOB_URL,
            "source": "settings" if custom_clob_url else "default",
            "default": DEFAULT_CLOB_URL,
        },
        "killswitch_address": {
            "current": killswitch_addr or None,
            "configured": killswitch_addr is not None,
        },
        "killswitch_slippage": {
            "current": effective_slip,
            "source": "settings" if custom_slippage and effective_slip != DEFAULT_KILLSWITCH_SLIPPAGE else "default",
            "default": DEFAULT_KILLSWITCH_SLIPPAGE,
        },
        "pending_ttl_minutes": {
            "current": _ttl_effective(pending_ttl),
            "source": "settings" if pending_ttl else "default",
            "default": DEFAULT_PENDING_TTL_MINUTES,
        },
        "send_max_amount": {
            "current": float(send_max) if send_max else None,
            "configured": send_max is not None,
        },
        "send_daily_max": {
            "current": float(send_daily) if send_daily else None,
            "configured": send_daily is not None,
        },
        "send_cooldown_seconds": {
            "current": _cooldown_effective(send_cooldown),
            "source": "settings" if send_cooldown else "default",
            "default": DEFAULT_SEND_COOLDOWN_SECONDS,
        },
        "send_allow_raw_address": {
            "current": str(send_raw).lower() == "true" if send_raw else False,
            "configured": send_raw is not None,
        },
    }
    output(result, None)


@config_app.command("set")
def set_value(
    key: Annotated[str, typer.Argument(help=f"Setting name. One of: {', '.join(_SETTINGS)}")],
    value: Annotated[str, typer.Argument(help="New value")],
):
    """Set a config value — writes to <project>/.claude/settings.local.json.

    Run in a separate terminal, `cd`'d to the project directory. The value is
    validated per-key before write; an invalid value does not touch the file.
    """
    if key not in _SETTINGS:
        die(
            "validation_error",
            "UNKNOWN_SETTING",
            f"Unknown setting '{key}'. Valid keys: {', '.join(_SETTINGS)}",
            hint="Run `regard config show` to see current values",
        )

    validated = _VALIDATORS[key](value)

    # Safety check — killswitch destination must not equal the trading wallet
    if key == "killswitch-address":
        trading = _trading_address()
        if trading and trading.lower() == validated.lower():
            die(
                "validation_error",
                "SAME_AS_TRADING_WALLET",
                "Killswitch destination cannot equal the trading wallet — sweeping funds to yourself is a no-op",
                hint="Use a separate wallet address as the emergency destination",
            )

    env_var = _SETTINGS[key]
    path = _write_setting(env_var, validated)
    output({"set": key, "value": validated, "path": str(path)}, None)
