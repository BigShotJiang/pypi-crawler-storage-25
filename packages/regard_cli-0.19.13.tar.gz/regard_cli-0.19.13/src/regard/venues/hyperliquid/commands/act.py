"""Act commands — order, cancel, cancel-all, leverage, stop, transfer, preflight."""

import sys
from typing import Annotated

import typer

from regard.core.output import die, output
from regard.core.proposal import create_proposal, register_executor, register_safety_validator
from regard.main import hl_app
from regard.venues.hyperliquid.client import (
    get_account_mode,
    get_active_asset_data,
    get_address,
    get_all_mids,
    get_all_orders,
    get_all_positions,
    get_asset_margin_info,
    get_asset_oracle_px,
    get_collateral_map,
    get_dex_for_coin,
    get_exchange,
    get_info,
    is_isolated_only,
)
from regard.venues.hyperliquid.resolver import get_resolver

SIDE_MAP = {"buy": True, "long": True, "sell": False, "short": False}


def _validate_trigger_direction(trigger_px: float, mid: float, is_long: bool, is_tp: bool):
    """Validate that a stop/TP trigger price is on the correct side of market.

    Dies with BAD_STOP or BAD_TP if the trigger would fire immediately.
    No-op if mid price is unavailable (mid <= 0).
    """
    if mid <= 0:
        return
    if not is_tp:
        if is_long and trigger_px >= mid:
            die("validation_error", "BAD_STOP",
                f"Stop loss {trigger_px:.6g} is above market ({mid:.6g}) for a long — would trigger immediately",
                hint="Stop loss for longs must be below current price")
        if not is_long and trigger_px <= mid:
            die("validation_error", "BAD_STOP",
                f"Stop loss {trigger_px:.6g} is below market ({mid:.6g}) for a short — would trigger immediately",
                hint="Stop loss for shorts must be above current price")
    else:
        if is_long and trigger_px <= mid:
            die("validation_error", "BAD_TP",
                f"Take profit {trigger_px:.6g} is below market ({mid:.6g}) for a long — would trigger immediately",
                hint="Take profit for longs must be above current price")
        if not is_long and trigger_px >= mid:
            die("validation_error", "BAD_TP",
                f"Take profit {trigger_px:.6g} is above market ({mid:.6g}) for a short — would trigger immediately",
                hint="Take profit for shorts must be below current price")


def _check_liq_vs_stop(position: dict, trigger_px: float, is_long: bool) -> list:
    """Check if a stop loss is inside the liquidation price.

    Constitution Article II: isolated → hard reject, cross → warn.
    Returns warnings list (may be empty). Dies for isolated margin violations.
    """
    liq_px_str = position.get("liquidationPx", "")
    if not liq_px_str:
        return []
    liq_px = float(liq_px_str)
    if liq_px <= 0:
        return []

    is_inside = (is_long and liq_px > trigger_px) or (not is_long and liq_px < trigger_px)
    if not is_inside:
        return []

    lev_info = position.get("leverage", {})
    margin_type = lev_info.get("type", "cross")
    code = "LIQ_ABOVE_STOP" if is_long else "LIQ_BELOW_STOP"
    # Warning body: "any stop below/above liq will never trigger"
    warn_direction = "below" if is_long else "above"
    # Hint: "set stop above/below liq" (opposite — escape the danger zone)
    hint_direction = "above" if is_long else "below"

    if margin_type == "isolated":
        # Isolated margin: liq price is deterministic → hard reject
        die("validation_error", "STOP_INSIDE_LIQ",
            f"Stop at {trigger_px:.6g} is inside liquidation price {liq_px:.6g} "
            f"(isolated margin — liq price is fixed, stop will never trigger)",
            hint=f"Set stop {hint_direction} {liq_px:.6g} or switch to cross margin",
            exit_code=2)

    # Cross margin: liq depends on portfolio → warn only
    return [{
        "code": code,
        "message": f"Liquidation at {liq_px:.6g} — any stop {warn_direction} that will never trigger (yours: {trigger_px:.6g})",
        "liq_price": liq_px,
    }]


def _check_oracle_bound(info, coin: str, px: float, px_kind: str = "price", threshold_pct: float = 1.0) -> list:
    """Preflight warning if a price is outside the per-asset oracle bound.

    HL validates trigger_px / limit_px against each asset's oracle bound at approve
    time; HIP-3 deployers can set very tight bounds (notoriously tight on xyz:CL
    during CME off-hours — 'Price too far from oracle' rejections). This preflight
    surfaces the risk as a warning at propose time instead of a silent approve-time
    failure. Threshold is a heuristic across all HL perps; specific deployer bounds
    may be tighter.

    Returns a list of 0-1 warning dicts.
    """
    oracle = get_asset_oracle_px(info, coin)
    if not oracle or oracle == 0:
        return []
    delta_pct = abs(px - oracle) / oracle * 100
    if delta_pct > threshold_pct:
        return [{
            "code": "ORACLE_BOUND_WARNING",
            "message": (
                f"{px_kind.capitalize()} {px:.6g} is {delta_pct:.2f}% from oracle {oracle:.6g} — "
                f"HL may reject at approve-time with 'Price too far from oracle'. "
                f"Deployer-configured bound; tightest on HIP-3 commodities during underlying off-hours."
            ),
            "oracle_price": oracle,
            "price": px,
            "delta_pct": round(delta_pct, 2),
            "threshold_pct": threshold_pct,
            "kind": px_kind,
        }]
    return []


def _classify_hl_error(msg: str) -> tuple[str, str | None]:
    """Map raw HL error strings to CLI error codes + optional hint.

    Grown reactively as production sessions surface patterns. Preserves the
    raw venue message unchanged; only the `code` field is refined so agents
    can pattern-match on stable semantic labels instead of prose.

    Returns `(code, hint)`. `hint` is None when the code itself is enough;
    otherwise gives agents / users a next-step suggestion.
    """
    lower = msg.lower()
    if "too far from oracle" in lower or "price too far" in lower:
        return (
            "PRICE_TOO_FAR_FROM_ORACLE",
            "Limit/trigger price outside HL's per-asset oracle bound. Place closer to oracle, "
            "or use a synthetic stop via `regard watch price` + manual close when a tight stop "
            "is essential and the bound is very tight (HIP-3 commodities during off-hours).",
        )
    if "insufficient margin" in lower:
        return ("INSUFFICIENT_MARGIN", None)
    if "cannot switch leverage type" in lower:
        return (
            "LEVERAGE_TYPE_LOCKED",
            "HL blocks switching between cross and isolated margin while a position is open. "
            "Close the position first, then change leverage type.",
        )
    # Unclassified venue error — stable fallback. Raw message preserved in `message`.
    return ("ORDER_REJECTED", None)


def _check_leverage_preflight(info, coin: str, requested_lev: int, requested_is_cross: bool, margin_info: dict) -> list:
    """Preflight warnings for `regard hl leverage` when a position is already open.

    HL rejects `updateLeverage` in two specific cases with open positions:
    1. Type switch (cross↔isolated) — "Cannot switch leverage type with open position"
    2. strictIsolated + leverage increase — the increase frees margin, which
       strictIsolated forbids ("strictIsolated doesn't allow removing margin from
       open positions", confirmed by HL team on Discord 2026-03-13)

    Returns warnings list suitable for the proposal's `warnings[]` field; empty
    when there's no open position or no expected rejection.
    """
    try:
        addr = get_address()
        positions = get_all_positions(info, addr)
    except Exception as exc:
        # Best-effort — don't block propose on a read error, but emit a visible
        # signal so the agent knows preflight's silence means "unknown", not "safe".
        # Without this, a type-switch proposal emits clean and runtime blows up.
        return [{
            "code": "PREFLIGHT_UNAVAILABLE",
            "message": (
                f"Could not verify open positions for {coin} — preflight skipped. "
                f"HL may still reject at approve-time (type switch on open position, "
                f"strictIsolated margin-removal)."
            ),
            "asset": coin,
            "reason": str(exc)[:200],
        }]

    pos = None
    for p in positions:
        if p.get("coin") == coin:
            pos = p
            break
    if pos is None:
        return []

    lev_info = pos.get("leverage", {}) or {}
    current_type = lev_info.get("type", "")  # "cross" | "isolated" | ""
    try:
        current_lev = int(lev_info.get("value", 0))
    except (TypeError, ValueError):
        current_lev = 0

    requested_type = "cross" if requested_is_cross else "isolated"
    warnings = []

    if current_type and current_type != requested_type:
        warnings.append({
            "code": "LEVERAGE_TYPE_SWITCH_WITH_POSITION",
            "message": (
                f"Open position on {coin} uses {current_type} margin; requested {requested_type}. "
                f"HL will reject: 'Cannot switch leverage type with open position'. "
                f"Close the position first."
            ),
            "asset": coin,
            "current_margin_type": current_type,
            "requested_margin_type": requested_type,
        })
        return warnings  # other warnings are moot if the type switch will fail

    is_strict_isolated = margin_info.get("margin_mode") == "strictIsolated"
    # When leverage value is unreadable (0 or missing), we can't compare, but
    # strictIsolated still makes ANY leverage change risky — warn unconditionally
    # rather than silently skip the guard.
    if is_strict_isolated and current_lev == 0:
        warnings.append({
            "code": "LEVERAGE_INCREASE_STRICT_ISOLATED",
            "message": (
                f"{coin} uses strictIsolated margin and has an open position "
                f"(current leverage unknown). Leverage changes that release margin "
                f"are forbidden; close the position first to be safe."
            ),
            "asset": coin,
            "current_leverage": None,
            "requested_leverage": requested_lev,
            "margin_mode": "strictIsolated",
        })
    elif is_strict_isolated and requested_lev > current_lev:
        warnings.append({
            "code": "LEVERAGE_INCREASE_STRICT_ISOLATED",
            "message": (
                f"{coin} uses strictIsolated margin; position is at {current_lev}x, "
                f"requested {requested_lev}x. Increasing leverage releases margin, "
                f"which strictIsolated forbids — HL will likely reject. "
                f"Close the position first, or lower leverage instead."
            ),
            "asset": coin,
            "current_leverage": current_lev,
            "requested_leverage": requested_lev,
            "margin_mode": "strictIsolated",
        })
    elif current_lev and requested_lev != current_lev:
        warnings.append({
            "code": "LEVERAGE_CHANGE_WITH_POSITION",
            "message": (
                f"Position is open on {coin} at {current_lev}x — leverage change to "
                f"{requested_lev}x may be accepted or rejected depending on venue state."
            ),
            "asset": coin,
            "current_leverage": current_lev,
            "requested_leverage": requested_lev,
        })

    return warnings


def _die_with_dex_hint(asset: str, msg: str):
    """Die with a classified error code, plus a dex hint for HIP-3 margin shortfalls."""
    code, generic_hint = _classify_hl_error(msg)
    dex = get_dex_for_coin(asset)
    # INSUFFICIENT_MARGIN on a HIP-3 dex gets an extra balance + transfer hint
    if code == "INSUFFICIENT_MARGIN" and dex:
        try:
            info = get_info()
            addr = get_address()
            dex_state = info.post("/info", {"type": "clearinghouseState", "user": addr, "dex": dex})
            dex_val = dex_state.get("marginSummary", dex_state.get("crossMarginSummary", {})).get("accountValue", "0")
            die("venue_error", code, msg,
                hint=f"{dex} dex balance: ${dex_val}. Transfer funds: regard hl transfer <amount> --to {dex}",
                exit_code=4)
        except SystemExit:
            raise
        except Exception:
            pass
    die("venue_error", code, msg, hint=generic_hint, exit_code=4)


def _parse_order_response(resp, asset: str, side_str: str, size: str):
    """Parse SDK order response into CLI output format."""
    if resp.get("status") == "err":
        msg = resp.get("response", str(resp))
        _die_with_dex_hint(asset, msg)

    data = resp.get("response", {}).get("data", {})
    statuses = data.get("statuses", [])
    if not statuses:
        die("venue_error", "ORDER_REJECTED", "No status in response", exit_code=4)

    st = statuses[0]
    if "error" in st:
        _die_with_dex_hint(asset, st["error"])

    if "filled" in st:
        filled = st["filled"]
        return {
            "status": "filled",
            "oid": filled.get("oid", 0),
            "asset": asset,
            "side": side_str,
            "size": filled.get("totalSz", size),
            "avg_price": filled.get("avgPx", ""),
        }
    elif "resting" in st:
        resting = st["resting"]
        return {
            "status": "resting",
            "oid": resting.get("oid", 0),
            "asset": asset,
            "side": side_str,
            "size": size,
        }
    else:
        return {"status": "unknown", "raw": st}



@hl_app.command()
def order(
    ctx: typer.Context,
    asset: Annotated[str, typer.Argument(help="Asset name")],
    side: Annotated[str, typer.Argument(help="buy/long or sell/short")],
    size: Annotated[str, typer.Argument(help="Amount in base asset")],
    price: Annotated[str | None, typer.Argument(help="Limit price")] = None,
    market: Annotated[bool, typer.Option("--market", help="Market order (IOC)")] = False,
    tif: Annotated[str | None, typer.Option("--tif", help="gtc|ioc|alo")] = None,
    reduce_only: Annotated[bool, typer.Option("--reduce-only", help="Reduce only")] = False,
    tp: Annotated[str | None, typer.Option("--tp", help="Take profit trigger price")] = None,
    sl: Annotated[str | None, typer.Option("--sl", help="Stop loss trigger price")] = None,
    cloid: Annotated[str | None, typer.Option("--cloid", help="Client order ID (hex)")] = None,
):
    """Place an order. Creates a proposal — use `regard approve` to execute."""
    opts = ctx.obj

    side_lower = side.lower()
    if side_lower not in SIDE_MAP:
        die("validation_error", "INVALID_SIDE", f"Invalid side: {side}", hint="Use buy/long or sell/short", param="side")

    is_buy = SIDE_MAP[side_lower]

    info = get_info(opts["testnet"])
    resolver = get_resolver(info)
    resolved = resolver.resolve(asset)

    is_market = market or price is None

    # Validate size precision against szDecimals from asset meta
    try:
        from decimal import Decimal
        sz_decimals = None
        if ":" in resolved:
            # HIP-3 asset — look up in dex-specific meta
            dex_name = resolved.split(":")[0]
            dex_meta = info.meta(dex=dex_name)
            for asset_info in dex_meta["universe"]:
                if asset_info["name"] == resolved:
                    sz_decimals = asset_info.get("szDecimals", 8)
                    break
        else:
            # Default perp — look up in default meta
            meta = info.meta()
            asset_idx = info.coin_to_asset.get(resolved)
            if asset_idx is not None and asset_idx < len(meta["universe"]):
                sz_decimals = meta["universe"][asset_idx].get("szDecimals", 8)

        if sz_decimals is not None:
            d_size = Decimal(size)
            if d_size != d_size.quantize(Decimal(10) ** -sz_decimals):
                die("validation_error", "PRECISION_EXCEEDED",
                    f"Size {size} exceeds allowed precision of {sz_decimals} decimal places for {resolved}",
                    param="size", exit_code=2)
    except SystemExit:
        raise
    except Exception:
        pass  # if meta lookup fails, let the exchange validate

    # Minimum $10 notional at mark price (exchange rejects below this)
    mids = get_all_mids(info)
    mark = mids.get(resolved)
    if mark:
        notional = float(size) * float(mark)
        if notional < 10:
            min_size = 10 / float(mark)
            die("validation_error", "BELOW_MIN_NOTIONAL",
                f"Order notional ${notional:.2f} (size {size} × mark ${float(mark):,.2f}) is below the $10 minimum",
                hint=f"Minimum size for {resolved} at current price: {min_size:.6g}",
                param="size", exit_code=2)

    # TP/SL require a limit order — market fills instantly, no resting order to attach to
    if is_market and (tp or sl):
        die("validation_error", "MARKET_WITH_TPSL",
            "Cannot use --sl or --tp with a market order",
            hint="Use a limit price instead of --market to attach TP/SL")

    # Validate TIF for limit orders
    if not is_market:
        tif_map = {"gtc": "Gtc", "ioc": "Ioc", "alo": "Alo"}
        tif_val = tif_map.get((tif or "gtc").lower())
        if not tif_val:
            die("validation_error", "INVALID_TIF", f"Invalid TIF: {tif}", hint="Valid values: gtc, ioc, alo", param="tif")

    # Validate TP/SL direction before creating proposal
    warnings = []
    if tp or sl:
        mids = get_all_mids(info)
        mid = float(mids.get(resolved, "0"))
        if sl:
            _validate_trigger_direction(float(sl), mid, is_buy, is_tp=False)
            # Liq-vs-stop on existing position (new positions skip — liq unknown until open)
            # Use the existing position's side, not the new order's side
            addr = get_address()
            all_pos = get_all_positions(info, addr)
            for pos in all_pos:
                if pos["coin"] == resolved:
                    existing_is_long = float(pos["szi"]) > 0
                    warnings.extend(_check_liq_vs_stop(pos, float(sl), existing_is_long))
                    break
        if tp:
            _validate_trigger_direction(float(tp), mid, is_buy, is_tp=True)

    # Capture mark price for price delta check at approve time
    checks = {}
    mids = get_all_mids(info)
    mark = mids.get(resolved)
    if mark is not None:
        checks["mark_price"] = mark

    # Warn if limit price is far from market (likely hallucinated price)
    # Skip for ALO (post-only) — ALO orders are cancelled if marketable, not filled
    tif_lower = (tif or "gtc").lower()
    if not is_market and price and mark and tif_lower != "alo":
        try:
            limit_px = float(price)
            mark_px = float(mark)
            if mark_px > 0:
                pct = (limit_px - mark_px) / mark_px * 100
                if is_buy and pct > 100:
                    warnings.append(f"Buy limit ${limit_px:,.6g} is {pct:,.0f}% above mark ${mark_px:,.6g} — will fill immediately at market price")
                elif not is_buy and pct < -50:
                    warnings.append(f"Sell limit ${limit_px:,.6g} is {abs(pct):,.0f}% below mark ${mark_px:,.6g} — will fill immediately at market price")
        except (ValueError, TypeError):
            pass  # non-numeric price — let downstream validation handle it

    # Oracle-bound preflight (catches HIP-3 'Price too far from oracle' at propose time)
    if not is_market and price:
        try:
            warnings.extend(_check_oracle_bound(info, resolved, float(price), "limit"))
        except (ValueError, TypeError):
            pass
    if sl:
        try:
            warnings.extend(_check_oracle_bound(info, resolved, float(sl), "sl trigger"))
        except (ValueError, TypeError):
            pass
    if tp:
        try:
            warnings.extend(_check_oracle_bound(info, resolved, float(tp), "tp trigger"))
        except (ValueError, TypeError):
            pass

    params = {
        "asset": resolved,
        "side": side_lower,
        "is_buy": is_buy,
        "size": size,
        "price": price,
        "market": is_market,
        "tif": tif,
        "reduce_only": reduce_only,
        "tp": tp,
        "sl": sl,
        "cloid": cloid,
        "testnet": opts["testnet"],
    }

    proposal = create_proposal("hl", "order", params, checks, warnings)
    output(proposal, opts["fields"])


def execute_order(params: dict) -> dict:
    """Execute an order from proposal params. Called by `regard approve`."""
    exchange = get_exchange(params.get("testnet", False))
    resolved = params["asset"]

    # HIP-3 assets need dex metadata loaded in the SDK before execution.
    # The propose phase loads it via Resolver, but approve runs in a separate
    # process so the SDK's coin_to_asset map is empty for HIP-3 coins.
    if ":" in resolved:
        from regard.venues.hyperliquid.resolver import Resolver
        Resolver(exchange.info).resolve(resolved)
    is_buy = params["is_buy"]
    sz = float(params["size"])
    side_str = params["side"]
    size_str = params["size"]

    from hyperliquid.utils.types import Cloid as SdkCloid
    sdk_cloid = SdkCloid.from_str(params["cloid"]) if params.get("cloid") else None

    if params.get("market"):
        try:
            resp = exchange.market_open(resolved, is_buy, sz, cloid=sdk_cloid)
        except SystemExit:
            raise
        except Exception as e:
            _die_with_dex_hint(resolved, str(e))
        return _parse_order_response(resp, resolved, side_str, size_str)

    # Limit order
    px = float(params["price"])
    tif_map = {"gtc": "Gtc", "ioc": "Ioc", "alo": "Alo"}
    tif_val = tif_map.get((params.get("tif") or "gtc").lower())
    order_type = {"limit": {"tif": tif_val}}

    if params.get("tp") or params.get("sl"):
        order_requests = [
            {
                "coin": resolved,
                "is_buy": is_buy,
                "sz": sz,
                "limit_px": px,
                "order_type": order_type,
                "reduce_only": params.get("reduce_only", False),
                "cloid": sdk_cloid,
            }
        ]
        if params.get("tp"):
            tp_px = float(params["tp"])
            tp_type = {"trigger": {"triggerPx": tp_px, "isMarket": True, "tpsl": "tp"}}
            order_requests.append({
                "coin": resolved,
                "is_buy": not is_buy,
                "sz": sz,
                "limit_px": tp_px,
                "order_type": tp_type,
                "reduce_only": True,
            })
        if params.get("sl"):
            sl_px = float(params["sl"])
            sl_type = {"trigger": {"triggerPx": sl_px, "isMarket": True, "tpsl": "sl"}}
            order_requests.append({
                "coin": resolved,
                "is_buy": not is_buy,
                "sz": sz,
                "limit_px": sl_px,
                "order_type": sl_type,
                "reduce_only": True,
            })

        try:
            resp = exchange.bulk_orders(
                [exchange._order_request_to_wire(r) for r in order_requests]
                if hasattr(exchange, "_order_request_to_wire")
                else order_requests,
                grouping="normalTpsl",
            )
        except SystemExit:
            raise
        except Exception as e:
            _die_with_dex_hint(resolved, str(e))
        return _parse_order_response(resp, resolved, side_str, size_str)
    else:
        try:
            resp = exchange.order(resolved, is_buy, sz, px, order_type, params.get("reduce_only", False), cloid=sdk_cloid)
        except SystemExit:
            raise
        except Exception as e:
            _die_with_dex_hint(resolved, str(e))
        return _parse_order_response(resp, resolved, side_str, size_str)


register_executor("hl", "order", execute_order)


@hl_app.command()
def cancel(
    ctx: typer.Context,
    first: Annotated[str | None, typer.Argument(help="OID or asset name")] = None,
    second: Annotated[str | None, typer.Argument(help="OID (if first is asset)")] = None,
    cloid: Annotated[str | None, typer.Option("--cloid", help="Cancel by client order ID")] = None,
    asset_opt: Annotated[str | None, typer.Option("--asset", help="Asset for cloid cancel")] = None,
):
    """Cancel a specific order. Creates a proposal — use `regard approve` to execute."""
    opts = ctx.obj
    info = get_info(opts["testnet"])

    if cloid:
        if not asset_opt:
            die("validation_error", "MISSING_ARGUMENT", "Must specify --asset with --cloid", hint="regard hl cancel --cloid 0x... --asset BTC")
        if not cloid.startswith("0x") or len(cloid) != 34:
            die("validation_error", "INVALID_CLOID", f"Client order ID must be 0x + 32 hex chars, got: {cloid}",
                hint="Example: 0x0123456789abcdef0123456789abcdef", param="cloid")
        resolver = get_resolver(info)
        resolved = resolver.resolve(asset_opt)
        params = {"asset": resolved, "cloid": cloid, "testnet": opts["testnet"]}
    elif first is None:
        die("validation_error", "MISSING_ARGUMENT", "Must specify OID or --cloid",
            hint="regard hl cancel <oid> OR regard hl cancel --cloid 0x... --asset BTC")
    elif second is not None:
        resolver = get_resolver(info)
        resolved = resolver.resolve(first)
        oid = int(second)
        params = {"asset": resolved, "oid": oid, "testnet": opts["testnet"]}
    else:
        oid = int(first)
        addr = get_address()
        open_orders = info.open_orders(addr)
        coin = None
        for o in open_orders:
            if o["oid"] == oid:
                coin = o["coin"]
                break
        if not coin:
            die("validation_error", "ORDER_NOT_FOUND", f"Order {oid} not found in open orders", hint=f"Pass asset explicitly: regard hl cancel BTC {oid}")
        params = {"asset": coin, "oid": oid, "testnet": opts["testnet"]}

    proposal = create_proposal("hl", "cancel", params, {}, [])
    output(proposal, opts["fields"])


def execute_cancel(params: dict) -> dict:
    """Execute a cancel from proposal params."""
    exchange = get_exchange(params.get("testnet", False))
    resolved = params["asset"]

    if "cloid" in params:
        from hyperliquid.utils.types import Cloid as SdkCloid
        resp = exchange.cancel_by_cloid(resolved, SdkCloid.from_str(params["cloid"]))
        if isinstance(resp, dict) and resp.get("status") == "err":
            die("venue_error", "CANCEL_FAILED", resp.get("response", str(resp)), exit_code=4)
        return {"status": "cancelled", "asset": resolved, "cloid": params["cloid"]}
    else:
        oid = params["oid"]
        resp = exchange.cancel(resolved, oid)
        if isinstance(resp, dict) and resp.get("status") == "err":
            die("venue_error", "CANCEL_FAILED", resp.get("response", str(resp)), exit_code=4)
        return {"status": "cancelled", "oid": oid, "asset": resolved}


register_executor("hl", "cancel", execute_cancel)


@hl_app.command(name="cancel-all")
def cancel_all(
    ctx: typer.Context,
    asset: Annotated[str | None, typer.Argument(help="Cancel only this asset's orders")] = None,
):
    """Cancel all open orders. Creates a proposal — use `regard approve` to execute."""
    opts = ctx.obj
    info = get_info(opts["testnet"])
    addr = get_address()
    all_orders = get_all_orders(info, addr)

    if asset:
        resolver = get_resolver(info)
        resolved = resolver.resolve(asset)
        all_orders = [o for o in all_orders if o["coin"] == resolved]

    if not all_orders:
        output({"cancelled": 0, "assets": []}, opts["fields"])
        return

    cancel_requests = [{"coin": o["coin"], "oid": o["oid"]} for o in all_orders]
    assets_found = sorted(set(o["coin"] for o in all_orders))
    params = {"cancel_requests": cancel_requests, "count": len(all_orders), "assets": assets_found, "testnet": opts["testnet"]}

    proposal = create_proposal("hl", "cancel-all", params, {}, [])
    output(proposal, opts["fields"])


def execute_cancel_all(params: dict) -> dict:
    """Execute a cancel-all from proposal params."""
    exchange = get_exchange(params.get("testnet", False))
    cancel_requests = params["cancel_requests"]
    resp = exchange.bulk_cancel(cancel_requests)
    result = {"cancelled": params["count"], "assets": params["assets"]}
    if isinstance(resp, dict) and resp.get("status") == "err":
        die("venue_error", "CANCEL_FAILED", resp.get("response", str(resp)), exit_code=4)
    if isinstance(resp, dict):
        result["response"] = resp
    return result


register_executor("hl", "cancel-all", execute_cancel_all)


@hl_app.command()
def leverage(
    ctx: typer.Context,
    asset: Annotated[str, typer.Argument(help="Asset name")],
    lev: Annotated[int, typer.Argument(help="Leverage (integer)")],
    cross: Annotated[bool, typer.Option("--cross", help="Cross margin")] = False,
    isolated: Annotated[bool, typer.Option("--isolated", help="Isolated margin")] = False,
):
    """Set leverage for an asset. Creates a proposal — use `regard approve` to execute."""
    opts = ctx.obj

    if cross and isolated:
        die("validation_error", "CONFLICTING_OPTIONS", "Cannot specify both --cross and --isolated")

    info = get_info(opts["testnet"])
    resolver = get_resolver(info)
    resolved = resolver.resolve(asset)

    # Fetch margin_info once — also used by preflight below
    margin_info = get_asset_margin_info(info, resolved)

    is_cross = not isolated  # default is cross
    if is_cross and is_isolated_only(margin_info):
        mode = margin_info.get("margin_mode") or "onlyIsolated"
        print(f"Warning: {resolved} requires isolated margin ({mode}). Using isolated.", file=sys.stderr)
        is_cross = False

    warnings = _check_leverage_preflight(info, resolved, lev, is_cross, margin_info)

    params = {
        "asset": resolved,
        "leverage": lev,
        "is_cross": is_cross,
        "testnet": opts["testnet"],
    }

    proposal = create_proposal("hl", "leverage", params, {}, warnings)
    output(proposal, opts["fields"])


def execute_leverage(params: dict) -> dict:
    """Execute a leverage change from proposal params.

    HL's `updateLeverage` endpoint returns HTTP 200 + `{"status": "err", "response": msg}`
    on rejections (e.g. type switch with open position, strictIsolated margin-removal
    blocks). Raw message preserved; code refined via `_classify_hl_error()`.
    """
    exchange = get_exchange(params.get("testnet", False))
    resp = exchange.update_leverage(params["leverage"], params["asset"], params["is_cross"])
    # Defensive: guard against SDK drift. Current SDK (0.14+) returns a dict,
    # but a future version returning a bare string must not be silently
    # treated as success — same class of bug this fix was designed to eliminate.
    if not isinstance(resp, dict):
        code, hint = _classify_hl_error(str(resp))
        die("venue_error", code, str(resp), hint=hint, exit_code=4)
    if resp.get("status") == "err":
        msg = resp.get("response", str(resp))
        msg_str = msg if isinstance(msg, str) else str(msg)
        code, hint = _classify_hl_error(msg_str)
        die("venue_error", code, msg_str, hint=hint, exit_code=4)
    return {
        "asset": params["asset"],
        "leverage": params["leverage"],
        "margin_mode": "cross" if params["is_cross"] else "isolated",
    }


register_executor("hl", "leverage", execute_leverage)


@hl_app.command()
def stop(
    ctx: typer.Context,
    asset: Annotated[str, typer.Argument(help="Asset name")],
    price: Annotated[str, typer.Argument(help="Trigger price")],
    tp: Annotated[bool, typer.Option("--tp", help="Take profit instead of stop loss")] = False,
):
    """Set a stop loss (or take profit) on an existing position. Creates a proposal — use `regard approve` to execute."""
    opts = ctx.obj
    info = get_info(opts["testnet"])
    resolver = get_resolver(info)
    resolved = resolver.resolve(asset)

    # Look up the current position across all dexes (default + HIP-3)
    addr = get_address()
    all_pos = get_all_positions(info, addr)
    position = None
    for pos in all_pos:
        if pos["coin"] == resolved:
            position = pos
            break

    if not position:
        die("validation_error", "NO_POSITION", f"No open position for {resolved}",
            hint=f"Check positions: regard hl positions {asset}")

    size = abs(float(position["szi"]))
    is_long = float(position["szi"]) > 0
    trigger_px = float(price)

    # Validate trigger direction (shared with order --sl/--tp)
    mids = get_all_mids(info)
    mid = float(mids.get(resolved, "0"))
    _validate_trigger_direction(trigger_px, mid, is_long, is_tp=tp)

    # Liq-vs-stop: isolated → hard reject, cross → warn (Constitution Article II)
    warnings = []
    if not tp:
        warnings.extend(_check_liq_vs_stop(position, trigger_px, is_long))

    # Oracle-bound preflight (catches HIP-3 'Price too far from oracle' at propose time)
    warnings.extend(_check_oracle_bound(info, resolved, trigger_px, "tp trigger" if tp else "sl trigger"))

    checks = {}
    mark = mids.get(resolved)
    if mark is not None:
        checks["mark_price"] = mark

    params = {
        "asset": resolved,
        "trigger_price": price,
        "size": str(size),
        "is_long": is_long,
        "is_tp": tp,
        "testnet": opts["testnet"],
    }

    proposal = create_proposal("hl", "stop", params, checks, warnings)
    output(proposal, opts["fields"])


def execute_stop(params: dict) -> dict:
    """Execute a stop/TP from proposal params."""
    exchange = get_exchange(params.get("testnet", False))
    resolved = params["asset"]
    trigger_px = float(params["trigger_price"])
    size = float(params["size"])
    is_long = params["is_long"]
    is_tp = params["is_tp"]

    tpsl = "tp" if is_tp else "sl"
    trigger_type = {"trigger": {"triggerPx": trigger_px, "isMarket": True, "tpsl": tpsl}}

    is_buy = not is_long
    try:
        resp = exchange.order(resolved, is_buy, size, trigger_px, trigger_type, reduce_only=True)
    except SystemExit:
        raise
    except Exception as e:
        err = str(e)
        if "reduce only" in err.lower() or "no position" in err.lower():
            die("venue_error", "POSITION_CLOSED",
                f"Position for {resolved} may have closed since proposal — reduce-only order rejected: {err}",
                hint=f"Check positions: regard hl positions {resolved}",
                exit_code=4)
        code, hint = _classify_hl_error(err)
        die("venue_error", code, err, hint=hint, exit_code=4)
    result = _parse_order_response(resp, resolved, "sell" if is_long else "buy", params["size"])
    result["trigger_price"] = params["trigger_price"]
    result["type"] = "take_profit" if is_tp else "stop_loss"
    result["position_side"] = "long" if is_long else "short"
    return result


register_executor("hl", "stop", execute_stop)


@hl_app.command()
def transfer(
    ctx: typer.Context,
    amount: Annotated[str, typer.Argument(help="Amount to transfer")],
    token: Annotated[str | None, typer.Option("--token", help="Token name (required for spot transfers, e.g. USDH)")] = None,
    to: Annotated[str | None, typer.Option("--to", help="Destination: dex name or 'spot'")] = None,
    from_dex: Annotated[str | None, typer.Option("--from", help="Source: dex name or 'spot'")] = None,
):
    """Transfer funds between perp dexes or spot. Creates a proposal — use `regard approve` to execute."""
    opts = ctx.obj

    if not to and not from_dex:
        die("validation_error", "MISSING_OPTION", "Specify --to or --from dex name",
            hint="regard hl transfer 5.00 --to xyz  OR  regard hl transfer 1.0 --to spot --token USDC")

    source = from_dex or ""
    dest = to or ""
    if source == "default":
        source = ""
    if dest == "default":
        dest = ""
    source_label = source or "default"
    dest_label = dest or "default"
    is_spot = source == "spot" or dest == "spot"

    info = get_info(opts["testnet"])
    addr = get_address()

    # Unified/portfolio margin accounts share margin across all dexes — intra-account transfers are no-ops
    acct_mode = get_account_mode(info, addr)
    if acct_mode in ("unifiedAccount", "portfolioMargin"):
        die("validation_error", "UNIFIED_ACCOUNT",
            f"Your account is in {acct_mode} mode — margin is shared across all dexes. "
            "No transfer needed, you can trade on any dex directly.",
            exit_code=2)

    if is_spot:
        # Article I: spot transfers MUST specify --token in either direction.
        # Previously perp→spot silently defaulted to USDC, which is wrong for
        # HIP-3 dexes using non-USDC collateral (flx=USDH, hyna=USDE, cash=USDT0)
        # and a silent pick among candidates even for default→spot.
        if not token:
            die("validation_error", "MISSING_TOKEN",
                "Specify --token for spot transfers (e.g. --token USDC or --token USDH)",
                exit_code=2)
        token_name = token
    else:
        collateral_map = get_collateral_map(info)
        src_token = collateral_map.get(source, ("USDC", 0))
        dst_token = collateral_map.get(dest, ("USDC", 0))

        if src_token[1] != dst_token[1]:
            die("validation_error", "COLLATERAL_MISMATCH",
                f"{source_label} dex uses {src_token[0]} but {dest_label} dex uses {dst_token[0]} — "
                f"cannot transfer between dexes with different collateral tokens",
                exit_code=2)
        token_name = token or src_token[0]

    # Validate amount is numeric
    try:
        transfer_amount = float(amount)
    except ValueError:
        die("validation_error", "INVALID_AMOUNT", f"Amount must be a number, got: {amount}", param="amount")

    # Check source balance at propose time
    if source == "spot":
        # Spot source: check spot balance for the specific token
        # Use spot_user_state directly so API errors are caught (get_spot_balances
        # swallows exceptions and returns [], which would false-reject).
        try:
            spot_state = info.spot_user_state(addr)
            raw_bals = spot_state.get("balances", [])
            spot_meta = info.spot_meta()
            tokens_by_index = {t["index"]: t for t in spot_meta["tokens"]}
            token_bal = 0.0
            for bal in raw_bals:
                t_info = tokens_by_index.get(bal.get("token", -1))
                if t_info and t_info["name"] == token_name:
                    if "total" in bal:
                        # Unified account format
                        token_bal = float(bal["total"])
                    else:
                        # Legacy format: holds/withdrawn in wei
                        holds = int(bal.get("holds", "0"))
                        withdrawn = int(bal.get("withdrawn", "0"))
                        wei_decimals = t_info.get("weiDecimals", 18)
                        token_bal = (holds - withdrawn) / (10 ** wei_decimals)
                    break
            if token_bal > 0 and transfer_amount > token_bal:
                die("venue_error", "INSUFFICIENT_BALANCE",
                    f"Spot balance for {token_name} is {token_bal}, cannot transfer {transfer_amount}",
                    hint="Check balances: regard hl balances",
                    exit_code=4)
        except SystemExit:
            raise
        except Exception:
            pass  # API error → skip check, let exchange validate
    else:
        try:
            state = info.post("/info", {"type": "clearinghouseState", "user": addr, "dex": source})
            available = float(state.get("withdrawable", "0"))
            if transfer_amount > available:
                die("venue_error", "INSUFFICIENT_BALANCE",
                    f"{source_label} dex has ${available:.2f} withdrawable {token_name}, cannot transfer ${transfer_amount:.2f}",
                    hint="Some balance may be locked as margin for open positions",
                    exit_code=4)
        except SystemExit:
            raise
        except Exception:
            pass

    # Resolve SDK-compatible token name for non-canonical tokens (USDH, USDE, USDT0)
    # Canonical tokens use plain name; non-canonical need "NAME:tokenId" for send_asset
    sdk_token_name = token_name
    try:
        spot_meta = info.spot_meta()
        for t in spot_meta.get("tokens", []):
            if t["name"] == token_name:
                if not t.get("isCanonical", False):
                    sdk_token_name = f"{t['name']}:{t['tokenId']}"
                break
    except Exception:
        pass  # fall back to plain name

    params = {
        "amount": amount,
        "source": source,
        "dest": dest,
        "source_label": source_label,
        "dest_label": dest_label,
        "token": token_name,
        "sdk_token": sdk_token_name,
        "addr": addr,
        "testnet": opts["testnet"],
    }

    proposal = create_proposal("hl", "transfer", params, {}, [])
    output(proposal, opts["fields"])


def execute_transfer(params: dict) -> dict:
    """Execute a transfer from proposal params."""
    exchange = get_exchange(params.get("testnet", False))
    addr = params["addr"]
    source = params["source"]
    dest = params["dest"]
    token_name = params.get("sdk_token", params["token"])
    amount = float(params["amount"])

    try:
        resp = exchange.send_asset(addr, source, dest, token_name, amount)
        if resp.get("status") == "err":
            die("venue_error", "TRANSFER_FAILED", resp.get("response", str(resp)), exit_code=4)
    except SystemExit:
        raise
    except Exception as e:
        die("venue_error", "TRANSFER_FAILED", str(e), exit_code=4)

    return {
        "amount": params["amount"],
        "from_dex": params["source_label"],
        "to_dex": params["dest_label"],
        "token": token_name,
    }


register_executor("hl", "transfer", execute_transfer)


# ---------------------------------------------------------------------------
# Send — wallet-to-wallet transfer via address book
# ---------------------------------------------------------------------------


@hl_app.command()
def send(
    ctx: typer.Context,
    amount: Annotated[str, typer.Argument(help="Amount to send")],
    to: Annotated[str | None, typer.Option("--to", help="Address book label")] = None,
    to_address: Annotated[str | None, typer.Option("--to-address", help="Raw address (requires SEND_ALLOW_RAW_ADDRESS)")] = None,
    token: Annotated[str, typer.Option("--token", help="Token name (e.g. USDC, USDH) — required")] = "",
):
    """Send tokens to a labeled address. Creates a proposal."""
    opts = ctx.obj
    info = get_info(opts["testnet"])

    from regard.commands.address import resolve_address
    from regard.core.audit import log_event
    from regard.core.safety import check_amount_cap, check_cooldown, check_daily_cap, classify_risk
    from regard.venues.hyperliquid.client import _load_settings_env

    settings_env = _load_settings_env()

    # --- Token is required ---
    # Constitution Article I forbids silent picks on ambiguous input. HL spot
    # accounts routinely hold multiple tokens (USDC, USDH, USDE, USDT0), so
    # defaulting to USDC would silently choose one among many. Require explicit
    # specification. Mirrors `poly send` at polymarket/commands/act.py:568-571.
    if not token:
        die("validation_error", "MISSING_TOKEN",
            "Must specify --token (e.g. USDC, USDH, USDE, USDT0)",
            hint="regard hl send <amount> --to <label> --token USDC")

    # --- Resolve destination ---
    if to and to_address:
        die("validation_error", "CONFLICTING_OPTIONS", "Use --to or --to-address, not both")
    elif to:
        dest = resolve_address(to, "hl")
        dest_address = dest["address"]
        dest_label = dest["label"]
    elif to_address:
        if not settings_env.get("SEND_ALLOW_RAW_ADDRESS"):
            die(
                "validation_error", "RAW_ADDRESS_BLOCKED",
                "Raw addresses are disabled. Use --to <label> with the address book.",
                hint="To enable: set SEND_ALLOW_RAW_ADDRESS=true in settings. Or add the address: regard address add <label> <address>",
            )
        from regard.commands.address import _validate_checksum
        dest_address = _validate_checksum(to_address)
        dest_label = "RAW"
    else:
        die("validation_error", "MISSING_DESTINATION", "Must specify --to <label> or --to-address <address>")
        return

    # --- Resolve token via spot_meta ---
    amt = float(amount)
    sdk_token = token
    try:
        spot_meta = info.spot_meta()
        found = False
        for t in spot_meta.get("tokens", []):
            if t["name"].upper() == token.upper():
                found = True
                if not t.get("isCanonical", False):
                    sdk_token = f"{t['name']}:{t['tokenId']}"
                else:
                    sdk_token = t["name"]
                break
        if not found:
            die("validation_error", "UNKNOWN_TOKEN", f"Token '{token}' not found in Hyperliquid spot_meta",
                hint="Check available tokens with: regard hl spot-balances")
    except SystemExit:
        raise
    except Exception:
        pass  # fall back to plain name

    addr = get_address(testnet=opts["testnet"])

    # --- Self-send check ---
    if addr.lower() == dest_address.lower():
        die("validation_error", "SELF_SEND", "Cannot send to yourself",
            hint="Check --to label or --to-address")

    # --- Safety checks (config gates fire before state checks so users see
    #     their own caps before "insufficient balance") ---
    check_amount_cap(amt, token, settings_env)
    check_daily_cap(amt, token, "hl", settings_env)
    check_cooldown(dest_address, settings_env)

    # --- Balance check ---
    try:
        from regard.venues.hyperliquid.client import get_spot_balances
        balances = get_spot_balances(info, addr)
        balance = 0.0
        for b in balances:
            if b.get("token", "").upper() == token.upper():
                balance = float(b.get("balance", 0))
                break
    except Exception:
        balance = 0.0

    if balance < amt:
        die("venue_error", "INSUFFICIENT_BALANCE",
            f"Balance ({balance} {token}) less than send amount ({amt} {token})",
            exit_code=4)

    # --- Risk classification ---
    risk = classify_risk(amt, balance)

    warnings = []
    if risk == "HIGH":
        warnings.append({"type": "high_risk", "message": f"Sending {amt/balance*100:.0f}% of your {token} balance"})
    elif risk == "CRITICAL":
        warnings.append({"type": "critical_risk", "message": f"Sending {amt/balance*100:.0f}% of your {token} balance. Approve will require --confirm-addr"})

    params = {
        "sender": addr,
        "dest_address": dest_address,
        "dest_label": dest_label,
        "token": token,
        "sdk_token": sdk_token,
        "amount": str(amt),
        "testnet": opts["testnet"],
    }
    checks = {
        "sender": addr,
        "sender_balance": str(balance),
        "projected_balance": str(round(balance - amt, 6)),
        "risk": risk,
    }

    log_event("proposed", command="send", venue="hl", to=dest_address, to_label=dest_label, token=token, amount=str(amt), risk=risk)
    proposal = create_proposal("hl", "send", params, checks, warnings)
    output(proposal, opts["fields"])


def validate_hl_send_safety(params: dict) -> None:
    """Pre-claim safety re-checks for hl send (sender key, cooldown, daily cap).

    Called from approve BEFORE claim_proposal so fixable mismatches don't
    consume the pending file. Also invoked by the executor as defense-in-depth.
    """
    from regard.core.safety import check_cooldown, check_daily_cap
    from regard.venues.hyperliquid.client import _load_settings_env

    settings_env = _load_settings_env()
    check_daily_cap(float(params["amount"]), params["token"], "hl", settings_env)
    check_cooldown(params["dest_address"], settings_env)

    current_addr = get_address(testnet=params.get("testnet", False))
    expected_sender = params.get("sender", "")
    if expected_sender and current_addr.lower() != expected_sender.lower():
        die("validation_error", "SENDER_MISMATCH",
            f"Current key ({current_addr}) does not match proposal sender ({expected_sender})",
            hint="Set HYPERLIQUID_PRIVATE_KEY to the same key used when creating the proposal")


def execute_hl_send(params: dict) -> dict:
    """Execute an HL send from proposal params."""
    from regard.core.audit import log_event

    # Defense-in-depth: approve runs the same check pre-claim so a mismatch
    # here indicates a race between validator and executor or a direct caller.
    validate_hl_send_safety(params)

    exchange = get_exchange(params.get("testnet", False))
    dest = params["dest_address"]
    token_name = params.get("sdk_token", params["token"])
    amount = float(params["amount"])

    try:
        resp = exchange.send_asset(dest, "spot", "spot", token_name, amount)
        if resp.get("status") == "err":
            die("venue_error", "SEND_FAILED", resp.get("response", str(resp)), exit_code=4)
    except SystemExit:
        raise
    except Exception as e:
        die("venue_error", "SEND_FAILED", str(e), exit_code=4)

    try:
        log_event("executed", command="send", venue="hl", to=dest, to_label=params["dest_label"],
                  token=params["token"], amount=params["amount"])
    except Exception as e:
        import sys
        print(f"WARNING: audit log write failed ({e}) — send succeeded", file=sys.stderr)

    return {
        "status": "sent",
        "destination": dest,
        "destination_label": params["dest_label"],
        "token": params["token"],
        "amount": params["amount"],
    }


register_executor("hl", "send", execute_hl_send)
register_safety_validator("hl", "send", validate_hl_send_safety)


@hl_app.command()
def preflight(
    ctx: typer.Context,
    asset: Annotated[str, typer.Argument(help="Asset name")],
    side: Annotated[str, typer.Argument(help="buy/long or sell/short")],
    size: Annotated[str, typer.Argument(help="Size to check")],
    sl: Annotated[str | None, typer.Option("--sl", help="Planned stop loss price")] = None,
):
    """Pre-trade risk check: margin, leverage, liq price, position sizing, warnings."""
    opts = ctx.obj

    side_lower = side.lower()
    if side_lower not in SIDE_MAP:
        die("validation_error", "INVALID_SIDE", f"Invalid side: {side}", hint="Use buy/long or sell/short", param="side")

    info = get_info(opts["testnet"])
    resolver = get_resolver(info)
    resolved = resolver.resolve(asset)
    addr = get_address()
    dex = get_dex_for_coin(resolved)
    is_buy = SIDE_MAP[side_lower]
    idx = 0 if is_buy else 1

    # Get active asset data (max trade sizes, available margin)
    asset_data = get_active_asset_data(info, addr, resolved)

    result = {
        "asset": resolved,
        "dex": dex or "default",
        "side": side_lower,
        "requested_size": size,
    }

    warnings = []

    if asset_data:
        max_szs = asset_data.get("maxTradeSzs", ["0", "0"])
        avail = asset_data.get("availableToTrade", ["0", "0"])
        mark_px = float(asset_data.get("markPx", "0"))
        lev_info = asset_data.get("leverage", {})
        lev_value = lev_info.get("value", 1)
        lev_type = lev_info.get("type", "cross")

        result["mark_px"] = asset_data.get("markPx", "")
        result["leverage"] = lev_info
        result["max_size"] = max_szs[idx]
        result["available_to_trade"] = avail[idx]
        result["can_trade"] = float(max_szs[idx]) >= float(size)

        # --- Risk metrics ---
        sz = float(size)

        # Notional exposure
        notional = sz * mark_px
        result["notional"] = round(notional, 2)

        # Equity — for unified accounts, use total account value (includes spot),
        # not dex-specific balance which is misleadingly small.
        try:
            acct_mode = get_account_mode(info, addr)
            if acct_mode == "unifiedAccount":
                state = info.user_state(addr)
            else:
                dex_name = dex or ""
                state = info.post("/info", {"type": "clearinghouseState", "user": addr, "dex": dex_name})
            margin = state.get("marginSummary", state.get("crossMarginSummary", {}))
            equity = float(margin.get("accountValue", "0"))
            result["equity"] = round(equity, 2)
            if equity > 0:
                notional_pct = (notional / equity) * 100
                result["notional_pct"] = round(notional_pct, 1)
                if notional_pct > 50:
                    warnings.append({
                        "code": "HIGH_NOTIONAL",
                        "message": f"{notional_pct:.1f}% of equity in one trade (${notional:.2f} / ${equity:.2f})",
                    })
        except Exception:
            pass

        # Margin required (approximate)
        if lev_value > 0:
            result["margin_required"] = round(notional / lev_value, 2)

        # Liquidation price estimate (isolated only — cross liq depends on full portfolio)
        if mark_px > 0 and lev_value > 0:
            if lev_type == "isolated":
                if is_buy:
                    liq_est = mark_px * (1 - 1 / lev_value)
                else:
                    liq_est = mark_px * (1 + 1 / lev_value)
                result["liq_price_est"] = round(liq_est, 6)
            else:
                result["liq_price_est"] = None  # cross: depends on portfolio

        # Stop loss analysis
        if sl is not None:
            sl_px = float(sl)
            result["stop_price"] = sl
            max_loss = sz * abs(mark_px - sl_px)
            result["max_loss"] = round(max_loss, 2)

            # Check liq vs stop
            liq_est = result.get("liq_price_est")
            if liq_est is not None:
                if is_buy and liq_est > sl_px:
                    safe_lev = max(1, int(mark_px / (mark_px - sl_px * 0.95)))
                    warnings.append({
                        "code": "LIQ_ABOVE_STOP",
                        "message": f"Liquidation at {liq_est:.6g} — any stop below that will never trigger (yours: {sl_px:.6g})",
                        "liq_price": liq_est,
                        "suggested_leverage": safe_lev,
                    })
                elif not is_buy and liq_est < sl_px:
                    safe_lev = max(1, int(mark_px / (sl_px * 1.05 - mark_px)))
                    warnings.append({
                        "code": "LIQ_BELOW_STOP",
                        "message": f"Liquidation at {liq_est:.6g} — any stop above that will never trigger (yours: {sl_px:.6g})",
                        "liq_price": liq_est,
                        "suggested_leverage": safe_lev,
                    })
    else:
        result["can_trade"] = False
        result["error"] = "Could not fetch asset data"

    # If can't trade on HIP-3, check dex balance
    if not result.get("can_trade") and dex:
        try:
            dex_state = info.post("/info", {"type": "clearinghouseState", "user": addr, "dex": dex})
            dex_margin = dex_state.get("marginSummary", dex_state.get("crossMarginSummary", {}))
            dex_val = dex_margin.get("accountValue", "0")
            result["dex_balance"] = dex_val
            if float(dex_val) == 0:
                result["recovery"] = {
                    "action": "transfer_funds",
                    "dex": dex,
                    "command": f"regard hl transfer <amount> --to {dex}",
                }
        except Exception:
            pass

    # Existing position check
    try:
        all_pos = get_all_positions(info, addr)
        for pos in all_pos:
            if pos["coin"] == resolved:
                pos_size = float(pos["szi"])
                result["existing_position"] = {
                    "side": "long" if pos_size > 0 else "short",
                    "size": abs(pos_size),
                    "entry_px": pos.get("entryPx", ""),
                    "unrealized_pnl": pos.get("unrealizedPnl", ""),
                    "liq_price": pos.get("liquidationPx", ""),
                }
                warnings.append({
                    "code": "EXISTING_POSITION",
                    "message": f"Already {'long' if pos_size > 0 else 'short'} {abs(pos_size)} {resolved} from {pos.get('entryPx', '?')}",
                })
                # Liq-vs-stop on existing position (cross margin has real liq price)
                if sl is not None:
                    warnings.extend(_check_liq_vs_stop(pos, float(sl), pos_size > 0))
                break
    except Exception:
        pass

    result["warnings"] = warnings

    # Build display
    lines = [f"Preflight: {side_lower} {size} {resolved}"]
    lines.append(f"  Mark price     {result.get('mark_px', '?')}")
    lev = result.get("leverage", {})
    if lev:
        lines.append(f"  Leverage       {lev.get('value', '?')}x {lev.get('type', '')}")
    lines.append(f"  Can trade      {'yes' if result.get('can_trade') else 'NO'}")
    if "notional" in result:
        lines.append(f"  Notional       ${result['notional']}")
    if "equity" in result:
        lines.append(f"  Equity         ${result['equity']}")
    if "notional_pct" in result:
        lines.append(f"  Exposure       {result['notional_pct']}% of equity")
    if "margin_required" in result:
        lines.append(f"  Margin req     ${result['margin_required']}")
    if result.get("liq_price_est") is not None:
        lines.append(f"  Liq price est  {result['liq_price_est']:.6g}")
    elif result.get("liq_price_est") is None and lev.get("type") == "cross":
        lines.append("  Liq price est  n/a (cross margin — depends on portfolio)")
    if sl is not None:
        lines.append(f"  Stop loss      {sl}")
    if "max_loss" in result:
        lines.append(f"  Max loss       ${result['max_loss']}")
    if result.get("existing_position"):
        ep = result["existing_position"]
        lines.append(f"  Existing pos   {ep['side']} {ep['size']} @ {ep['entry_px']}")
    if warnings:
        lines.append("")
        for w in warnings:
            lines.append(f"  ⚠ {w['code']}: {w['message']}")
            if "suggested_leverage" in w:
                lines.append(f"    → Suggested leverage: {w['suggested_leverage']}x")
    result["display"] = "\n".join(lines)

    output(result, opts["fields"])
