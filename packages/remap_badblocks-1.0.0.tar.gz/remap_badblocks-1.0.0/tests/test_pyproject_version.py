import os
from tomllib import load

from remap_badblocks import __version__


def test_version():
    pyproject = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "..", "pyproject.toml"
    )
    with open(pyproject, "rb") as f:
        assert str(__version__) == load(f)["project"]["version"]
