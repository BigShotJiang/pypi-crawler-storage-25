from packaging.version import Version

__version__ = Version("1.0.0")
