from pathlib import Path
from typing import Any, Callable, Iterable, Optional, Union

from remap_badblocks.src.badblocks.badblocks import Badblocks
from remap_badblocks.src.mapping import Mapping


class DeviceConfig:
    id: int
    path: Path
    name: str
    sector_size: int
    badblocks: Badblocks
    depends_on: set[int]
    logical_range: tuple[int, int]
    apply_at_startup: bool = False
    spare_sectors: int
    mapping: Optional[Mapping] = None
    enabled: bool = True

    ATTRS = [
        "id",
        "path",
        "name",
        "sector_size",
        "badblocks",
        "depends_on",
        "logical_range",
        "apply_at_startup",
        "spare_sectors",
        "mapping",
        "enabled",
    ]

    ATTR_STRINGIFY: dict[str, Callable[[Any], str]] = {
        "enabled": lambda x: "enabled" if x else "disabled",
        "badblocks": lambda x: "badblocks count=" + str(len(x)),
        "mapping": lambda x: "mapping=" + ("defined" if x is not None else "undefined"),
    }

    def __init__(
        self,
        id: int,
        path: Union[Path, str],
        name: str,
        sector_size: int,
        badblocks: Iterable[int],
        logical_range: tuple[int, int],
        spare_sectors: int,
        apply_at_startup: bool = False,
        depends_on: Iterable[int] = set(),
        mapping: Optional[Mapping] = None,
        enabled: bool = True,
    ):
        if isinstance(path, str):
            path = Path(path)
        self.id = id
        self.path = path
        self.name = name
        self.sector_size = sector_size
        self.badblocks = Badblocks(badblocks)
        self.mapping = mapping if mapping is not None else None
        self.spare_sectors = spare_sectors
        self.depends_on = set(depends_on)
        self.logical_range = logical_range
        self.apply_at_startup = apply_at_startup
        self.enabled = enabled

    def __str__(self) -> str:
        def print_attr(attr: str) -> str:
            value = getattr(self, attr)
            if attr in self.ATTR_STRINGIFY:
                return self.ATTR_STRINGIFY[attr](value)
            else:
                return f"{attr}={value}"

        return "DeviceConfig(\n\t" + ",\n\t".join(map(print_attr, self.ATTRS)) + "\n)"

    def get_applied_path(self) -> Path:
        return Path("/dev/mapper/", self.name)

    def __hash__(self) -> int:
        return self.id
