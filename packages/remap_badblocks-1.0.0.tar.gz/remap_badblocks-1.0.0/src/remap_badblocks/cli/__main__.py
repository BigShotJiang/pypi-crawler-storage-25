from argparse import ArgumentParser, Namespace
from pathlib import Path
from typing import Callable

from remap_badblocks.src.devices.devices_config import DevicesConfig
from remap_badblocks.src.devices_config_constants import \
    DEFAULT_DEVICES_CONFIG_PATH

from .commands import apply, init, update_mapping, version
from .commands.apply import define_command as define_apply_command
from .commands.device import define_commands as define_device_commands
from .commands.device import run_commands as run_device_commands
from .commands.init import define_command as define_init_command
from .commands.update_mapping import \
    define_command as define_update_mapping_command

argparse = ArgumentParser(
    description="Badblocks remapper for block devices.",
)

argparse.add_argument(
    "-P",
    "--db-path",
    type=Path,
    default=DEFAULT_DEVICES_CONFIG_PATH,
    help="Path to the devices configuration database.",
)

subparser = argparse.add_subparsers(
    title="Commands",
    dest="command",
    metavar="",
)

init_subparser = subparser.add_parser(
    "init",
    help="Initialize a device, equivalent to running device add + device remap + device apply",
)
define_init_command(init_subparser)

update_mapping_subparser = subparser.add_parser(
    "update-mapping",
    help=(
        "Update the badblocks of a device and its mapping. This is equivalent to running"
        " device scan + device remap + device apply"
    ),
)
define_update_mapping_command(update_mapping_subparser)

apply_subparser = subparser.add_parser(
    "apply",
    help=(
        "Apply a device (i.e. create the virtual block device that maps the badblocks). This is equivalent to running"
        " device apply."
    ),
)
define_apply_command(apply_subparser)

device_subparser = subparser.add_parser(
    "device",
    help="Manage devices in the database.",
)
define_device_commands(device_subparser, dest="device_command")

version_parser = subparser.add_parser(
    "version", help="Print the version of the badblocks remapper."
)


def main() -> None:
    args = argparse.parse_args()
    db_path: Path = args.db_path

    subcommands: dict[str, Callable[[str, DevicesConfig, Namespace], None]] = {
        "device": run_device_commands,
    }

    static_commands: dict[str, Callable[[], None]] = {
        "version": version,
    }

    commands: dict[str, Callable[[DevicesConfig, Namespace], None]] = {
        "apply": apply,
        "init": init,
        "update-mapping": update_mapping,
    }

    available_commands = (
        set(subcommands.keys()) | set(static_commands.keys()) | set(commands.keys())
    )
    if args.command not in available_commands:
        raise ValueError(
            f"Unknown command: {args.command}. Please use one of {available_commands}."
        )

    if args.command in static_commands:
        static_commands[args.command]()
    else:
        if db_path.is_dir():
            raise ValueError("The provided path must not be a directory.")
        devices_config = DevicesConfig(db_path)
        if args.command in subcommands:
            subcommands[args.command](
                getattr(args, f"{args.command}_command"), devices_config, args
            )
        elif args.command in commands:
            commands[args.command](devices_config, args)


if __name__ == "__main__":
    main()
