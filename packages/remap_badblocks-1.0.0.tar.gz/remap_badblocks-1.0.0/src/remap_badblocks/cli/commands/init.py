from argparse import ArgumentParser, Namespace
from pathlib import Path
from typing import Literal, Optional, TypedDict

from remap_badblocks.cli.commands.device.add import add
from remap_badblocks.cli.commands.device.apply import apply
from remap_badblocks.cli.commands.device.remap import remap
from remap_badblocks.src.devices.devices_config import DevicesConfig


def define_command(subparser: ArgumentParser) -> None:
    subparser.add_argument("name", type=str, help="The name of the output device.")
    subparser.add_argument(
        "--wwn",
        type=str,
        help="The WWN of the device to add.",
    )
    subparser.add_argument(
        "--path",
        type=Path,
        help="The path to the device to add.",
    )
    subparser.add_argument(
        "--depends-on",
        type=str,
        default=[],
        action="append",
        help=(
            "The name of a device that this device depends on. Can be specified multiple times to add multiple"
            " dependencies. This is used to ensure that devices are applied in the correct order."
        ),
    )
    subparser.add_argument(
        "--logical-sector-range",
        type=str,
        default="-",
        help=(
            "Logical sector range to assign to the device. Format: 'start-end', where 'end' can be omitted to mean"
            " 'till the end of the device'. Both start and end can be specified as sector numbers or as byte offsets."
            " In case of byte offsets, they must be multiples of the sector size. If not specified, the whole device"
            " will be used. Note that end is not included in the range."
        ),
    )
    subparser.add_argument(
        "--spare-space",
        type=str,
        required=True,
        help="Number of spare sectors to reserve in case new badblocks are found.",
    )
    subparser.add_argument(
        "--apply-method",
        type=str,
        default="device-mapper",
        choices=["device-mapper"],
        help="Method to apply the mapping. Only device-mapper is available",
    )


class InitArgs(TypedDict):
    name: str
    wwn: Optional[str]
    path: Optional[Path]
    depends_on: set[str]
    logical_sector_range: str
    spare_space: str
    apply_method: Literal["device-mapper"]


def parse_args(args: Namespace) -> InitArgs:
    return {
        "name": args.name,
        "wwn": args.wwn,
        "path": args.path,
        "depends_on": set(args.depends_on),
        "logical_sector_range": args.logical_sector_range.strip(),
        "spare_space": args.spare_space.strip(),
        "apply_method": args.apply_method,
    }


def init(dc: DevicesConfig, args: Namespace) -> None:
    add_args = Namespace(
        name=args.name,
        wwn=args.wwn,
        path=args.path,
        depends_on=args.depends_on,
        depends_on_id=[],
        logical_sector_range=args.logical_sector_range,
        spare_space=args.spare_space,
        apply_method=args.apply_method,
    )
    remap_args = Namespace(
        id=None,
        name=args.name,
        reset_mapping=False,
        ignore_badblocks=True,
    )
    apply_args = Namespace(
        id=None,
        name=args.name,
        method=args.apply_method,
    )

    print("Adding device to the database...")
    add(dc, add_args)
    print("...device added.")

    print("Initializing device mapping...")
    remap(dc, remap_args)
    print("...device mapping initialized.")

    print("Applying device...")
    apply(dc, apply_args)
    print("...device applied.")
