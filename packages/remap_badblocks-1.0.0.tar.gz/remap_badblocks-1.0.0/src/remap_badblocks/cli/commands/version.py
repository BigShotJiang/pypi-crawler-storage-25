from remap_badblocks import __version__


def get_version() -> str:
    return str(__version__)


def version():
    print(f"remap-badblocks version v{get_version()}")
