from argparse import ArgumentParser, Namespace
from pathlib import Path
from typing import Optional, TypedDict

from remap_badblocks.src.devices.devices_config import DevicesConfig
from remap_badblocks.src.utils._run_command import run_command_realtime


class RemoveArgs(TypedDict):
    id: Optional[int]
    name: Optional[str]
    unapply_first: bool


def parse_args(args: Namespace) -> RemoveArgs:
    return {
        "id": args.id,
        "name": args.name,
        "unapply_first": args.unapply_first,
    }


def get_device_id_from_args(dc: DevicesConfig, args: RemoveArgs) -> int:
    id: Optional[int] = args["id"]
    name: Optional[str] = args["name"]

    if id is not None and name is not None:
        raise ValueError(
            "Only one of --id or --name can be provided to remove a device from the database."
        )
    elif id is None and name is None:
        raise ValueError(
            "Either --id or --name must be provided to remove a device from the database."
        )
    elif id is not None:
        return id
    else:
        assert name is not None
        return dc.get_device(name=name).id


def remove(dc: DevicesConfig, _args: Namespace) -> None:
    """
    Remove the configuration of a device from the database.
    """
    args = parse_args(_args)
    id = get_device_id_from_args(dc, args)

    device = dc.get_device(id=id)
    dm_device_path = Path("/dev/mapper/{}".format(device.name))

    if dm_device_path.exists():
        if not args["unapply_first"]:
            raise RuntimeError(
                f"Device {device.name} is currently applied. Please specify --unapply-first to unapply it before"
                " removing it from the database."
            )
        for _ in run_command_realtime(["dmsetup", "remove", device.name]):
            pass

    dc.remove_device(id)


def define_command(remove_devices_parser: ArgumentParser) -> None:
    remove_devices_parser.add_argument(
        "--id",
        type=int,
        default=None,
        help="The ID of the device to remove. If neither --id or --name are provided, an error will be raised.",
    )
    remove_devices_parser.add_argument(
        "--name",
        type=str,
        default=None,
        help="The name of the device to remove. If neither --id or --name are provided, an error will be raised.",
    )
    remove_devices_parser.add_argument(
        "--unapply-first",
        action="store_true",
        help=(
            "Unapply the device before removing it from the database if it is currently applied. Handle with care."
        ),
    )
