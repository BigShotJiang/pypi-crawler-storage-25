from typing import Iterable

from remap_badblocks.src.badblocks._compute_good_ranges import (
    compute_good_ranges, reserve_space_from_good_ranges)
from remap_badblocks.src.badblocks._mapping_generation import generate_mapping
from remap_badblocks.src.badblocks._remap_badblocks import (
    filter_out_used_and_bad_spare_sectors, iter_all_spare_sectors,
    remap_badblocks, simplify_mapping)
from remap_badblocks.src.devices.device_config import DeviceConfig
from remap_badblocks.src.mapping import Mapping, MappingElement


def generate_remapping(
    reset_mapping: bool,
    device: DeviceConfig,
    badblocks: Iterable[int],
    n_spare_sectors: int,
) -> Mapping:
    new_mapping: Iterable[tuple[int, int, int]]

    if (device.mapping is None) or reset_mapping:
        good_ranges = compute_good_ranges(
            badblocks, available_range=device.logical_range
        )
        good_ranges = reserve_space_from_good_ranges(good_ranges, n_spare_sectors)
        good_ranges = reserve_space_from_good_ranges(
            good_ranges,
            int(100 * 1024 / device.sector_size),
        )
        new_mapping = generate_mapping(
            good_ranges,
        )
    else:
        badblocks_ = set(badblocks)
        spare_sectors = iter_all_spare_sectors(n_spare_sectors, device.logical_range[0])
        spare_sectors = filter_out_used_and_bad_spare_sectors(
            spare_sectors, device.mapping, badblocks_
        )
        new_mapping = remap_badblocks(
            device.mapping,
            badblocks_,
            spare_sectors,
        )

    new_mapping = list(new_mapping)
    assert new_mapping, "Available spare blocks are not enough"

    new_mapping = simplify_mapping(new_mapping)

    return Mapping(set(map(MappingElement.from_tuple, new_mapping)))
