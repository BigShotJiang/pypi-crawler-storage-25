from argparse import ArgumentParser, Namespace
from typing import Iterable, TypedDict

from remap_badblocks.src.devices.device_config import DeviceConfig
from remap_badblocks.src.devices.devices_config import DevicesConfig


class ListArgs(TypedDict):
    all: bool


def parse_args(args: Namespace) -> ListArgs:
    return {
        "all": args.all,
    }


def get_devices_to_print(args: ListArgs, dc: DevicesConfig) -> Iterable[DeviceConfig]:
    if args["all"]:
        return dc.get_devices()
    else:
        return filter(lambda d: d.enabled, dc.get_devices())


def list(dc: DevicesConfig, _args: Namespace) -> None:
    """
    List the configuration of devices from the database.
    """
    args = parse_args(_args)

    for device in get_devices_to_print(args, dc):
        print(str(device))


def define_command(list_devices_parser: ArgumentParser) -> None:
    list_devices_parser.add_argument(
        "-a",
        "--all",
        action="store_true",
        help="Also get disabled devices.",
    )
