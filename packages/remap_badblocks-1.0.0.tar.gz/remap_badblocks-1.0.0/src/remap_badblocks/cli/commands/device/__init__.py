from argparse import ArgumentParser, Namespace
from typing import Callable

from remap_badblocks.src.devices.devices_config import DevicesConfig

from .add import add as func_add
from .add import define_command as define_add_command
from .apply import apply as func_apply
from .apply import define_command as define_apply_command
from .get import define_command as define_get_command
from .get import get as func_get
from .list import define_command as define_list_command
from .list import list as func_list
from .remap import define_command as define_remap_command
from .remap import remap as func_remap
from .remove import define_command as define_remove_command
from .remove import remove as func_remove
from .scan import define_command as define_scan_command
from .scan import scan as func_scan
from .set import define_command as define_set_command
from .set import set as func_set


def define_commands(subparser: ArgumentParser, dest: str) -> None:
    device = subparser.add_subparsers(
        title="device",
        dest=dest,
        help="Device action to perform",
        required=True,
    )

    add_new_device_parser = device.add_parser(
        "add",
        help="Create a new device in the remap_badblocks database. No mapping is created at this stage, "
        "other than keeping leaving some space empty as spare sectors. Use the remap command to create the mapping.",
    )
    define_add_command(add_new_device_parser)

    get_device_parser = device.add_parser(
        "get",
        help="Get the configuration of a device in the database.",
    )
    define_get_command(get_device_parser)

    list_devices_parser = device.add_parser(
        "list",
        help="List the existing device(s) in the database.",
    )
    define_list_command(list_devices_parser)

    remove_devices_parser = device.add_parser(
        "remove",
        help="Remove an existing device in the database.",
    )
    define_remove_command(remove_devices_parser)

    remap_parser = device.add_parser(
        "remap",
        help=(
            "Update the mapping of a device in the database based on current badblocks. This will keep all the current"
            " mapping except for the badblocks that are still not skipped. They will be mapped to spare sectors."
            " If there are not enough spare sectors, an error will be raised."
            " The new mapping will be stored in the database, but it will not be applied automatically to the device,"
            " you need to use the apply command for that."
        ),
    )
    define_remap_command(remap_parser)

    scan_parser = device.add_parser(
        "scan",
        help=(
            "Scan the device for new badblocks and store them in the database. This will"
            " compute/update the device's badblocks list and store it in the database."
            " This command won't update the mapping of the device, use remap for that."
        ),
    )
    define_scan_command(scan_parser)

    apply_devices_parser = device.add_parser(
        "apply",
        help=(
            "Apply a remapping that's already existing in the database. All provided devices will be applied,"
            " regardless if it's already applied. This might cause errors."
        ),
    )
    define_apply_command(apply_devices_parser)

    set_device_parser = device.add_parser(
        "set",
        help="Set config of an already existing device in the database.",
    )
    define_set_command(set_device_parser)


def run_commands(command: str, dc: DevicesConfig, args: Namespace) -> None:
    commands: dict[str, Callable[[DevicesConfig, Namespace], None]] = {
        "add": func_add,
        "apply": func_apply,
        "get": func_get,
        "list": func_list,
        "set": func_set,
        "remove": func_remove,
        "remap": func_remap,
        "scan": func_scan,
    }

    if command in commands:
        commands[command](dc, args)
    else:
        raise ValueError(
            f"Unknown command: {command}. Please use one of {tuple(commands.keys())}."
        )
