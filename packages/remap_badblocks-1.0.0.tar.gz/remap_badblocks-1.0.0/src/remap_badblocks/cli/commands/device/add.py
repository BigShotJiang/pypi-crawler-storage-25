import os
from argparse import ArgumentParser, Namespace
from pathlib import Path
from typing import Optional, TypedDict

from remap_badblocks.src.devices.devices_config import DevicesConfig
from remap_badblocks.src.utils._get_device_info import (
    get_disk_block_size, get_disk_number_of_blocks, resolve_device_name)
from remap_badblocks.src.utils._parse_inputs import (
    parse_bytes_to_sectors, parse_memory_number_to_bytes,
    parse_memory_range_to_sectors)


class AddArgs(TypedDict):
    wwn: Optional[str]
    path: Optional[Path]
    name: str
    depends_on_id: set[int]
    depends_on: set[str]
    logical_sector_range: str
    spare_space: str


def parse_args(args: Namespace) -> AddArgs:
    return {
        "wwn": args.wwn,
        "path": args.path,
        "name": args.name,
        "depends_on_id": set(args.depends_on_id),
        "depends_on": set(args.depends_on),
        "logical_sector_range": args.logical_sector_range.strip(),
        "spare_space": args.spare_space.strip(),
    }


def get_path_from_args(args: AddArgs) -> Path:
    wwn = args["wwn"]
    path = args["path"]

    if wwn is not None and path is not None:
        raise ValueError("Only one of --wwn or --path can be provided, not both.")

    if path is not None:
        if isinstance(path, str):
            path = Path(path)
        return path
    elif wwn is not None:
        if not wwn.startswith("/dev/disk/by-id/"):
            wwn = os.path.join("/dev/disk/by-id/", wwn)
        return Path(wwn)
    else:
        raise ValueError("Either --wwn or --path must be provided.")


def get_device_dependencies_from_args(dc: DevicesConfig, args: AddArgs) -> set[int]:
    return args["depends_on_id"] | {
        dc.get_device(name=dep).id for dep in args["depends_on"] if dep
    }


def get_logical_block_range_from_args(
    args: AddArgs, sector_size: int, total_sectors: int
) -> tuple[int, int]:
    logical_start_block, logical_end_block = parse_memory_range_to_sectors(
        args["logical_sector_range"], sector_size
    )

    if logical_start_block is None:
        logical_start_block = 0
    if logical_end_block is None:
        logical_end_block = total_sectors

    return logical_start_block, logical_end_block


def convert_space_to_sectors(spare_space: str, sector_size: int) -> int:
    spare_blocks = parse_bytes_to_sectors(
        parse_memory_number_to_bytes(spare_space, sector_size=sector_size),
        sector_size,
    )

    return spare_blocks


def add(dc: DevicesConfig, _args: Namespace) -> None:
    """
    Add a new device to the database.
    """
    args = parse_args(_args)
    path: Path = get_path_from_args(args)

    sector_size = get_disk_block_size(resolve_device_name(path))
    total_sectors = get_disk_number_of_blocks(resolve_device_name(path))
    spare_sectors = convert_space_to_sectors(args["spare_space"], sector_size)

    dc.add_device(
        path=path,
        name=args["name"],
        sector_size=sector_size,
        depends_on=get_device_dependencies_from_args(dc, args),
        logical_range=get_logical_block_range_from_args(
            args, sector_size, total_sectors
        ),
        spare_sectors=spare_sectors,
    )


def define_command(add_new_device_parser: ArgumentParser) -> None:
    add_new_device_parser.add_argument(
        "name", type=str, help="The name of the output device."
    )
    add_new_device_parser.add_argument(
        "--wwn",
        type=str,
        help="The WWN of the device to add.",
    )
    add_new_device_parser.add_argument(
        "--path",
        type=Path,
        help="The path to the device to add.",
    )
    add_new_device_parser.add_argument(
        "--depends-on",
        type=str,
        default=[],
        action="append",
        help=(
            "The name of a device that this device depends on. Can be specified multiple times to add multiple"
            " dependencies. This is used to ensure that devices are applied in the correct order."
        ),
    )
    add_new_device_parser.add_argument(
        "--depends-on-id",
        type=int,
        default=[],
        action="append",
        help=(
            "The ID of a device that this device depends on. Can be specified multiple times to add multiple"
            " dependencies. This is used to ensure that devices are applied in the correct order."
        ),
    )
    add_new_device_parser.add_argument(
        "--logical-sector-range",
        type=str,
        default="-",
        help=(
            "Logical sector range to assign to the device. Format: 'start-end', where 'end' can be omitted to mean"
            " 'till the end of the device'. Both start and end can be specified as sector numbers or as byte offsets."
            " In case of byte offsets, they must be multiples of the sector size. If not specified, the whole device"
            " will be used. Note that end is not included in the range."
        ),
    )
    add_new_device_parser.add_argument(
        "--spare-space",
        type=str,
        required=True,
        help="Number of spare sectors to reserve in case new badblocks are found.",
    )
