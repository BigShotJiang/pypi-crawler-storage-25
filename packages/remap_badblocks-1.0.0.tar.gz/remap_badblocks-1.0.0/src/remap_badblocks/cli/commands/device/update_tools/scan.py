from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import Literal, Optional

from remap_badblocks.src.badblocks._find_badblocks import (
    get_all_badblocks, read_known_badblocks)
from remap_badblocks.src.devices.device_config import DeviceConfig
from remap_badblocks.src.utils._run_command import pipe_lines_to_file


def run_badblocks_scan(
    mode: Literal["read", "write", "skip"],
    known_badblocks: set[int],
    device: DeviceConfig,
    block_range: tuple[int, int],
    output: Optional[Path] = None,
) -> set[int]:
    if mode == "skip":
        return known_badblocks

    with NamedTemporaryFile() as known_badblocks_file:
        known_badblocks_file.write("\n".join(map(str, known_badblocks)).encode("utf-8"))
        known_badblocks_file.flush()

        badblocks: set[int] = set(
            get_all_badblocks(
                device.path,
                device.sector_size,
                mode=mode,
                known_badblocks_file=Path(known_badblocks_file.name),
                block_range=block_range,
            )
        )

        if output is not None:
            pipe_lines_to_file(badblocks, output)

        return badblocks


def get_known_badblocks(
    external_known_badblocks_file: Optional[Path], device: DeviceConfig
) -> set[int]:
    known_badblocks: set[int] = set(device.badblocks)

    # If known badblocks file is passed, merge it into our known_badblocks
    if external_known_badblocks_file is not None:
        known_badblocks.update(
            read_known_badblocks(known_badblocks_file=external_known_badblocks_file)
        )

    return known_badblocks


def scan_and_collect_badblocks(
    external_known_badblocks_file: Optional[Path],
    mode: Literal["read", "write", "skip"],
    block_range: tuple[int, int],
    device: DeviceConfig,
    output: Optional[Path] = None,
):
    known_badblocks = get_known_badblocks(external_known_badblocks_file, device)
    badblocks = run_badblocks_scan(mode, known_badblocks, device, block_range, output)

    print(
        f"Finished scanning for new badblocks. Went from {len(known_badblocks)} to {len(badblocks)}."
    )

    return badblocks
