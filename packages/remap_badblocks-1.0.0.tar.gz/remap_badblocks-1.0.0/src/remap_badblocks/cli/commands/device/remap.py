from argparse import ArgumentParser, Namespace
from typing import Iterable, Optional, TypedDict

from remap_badblocks.cli.commands.device.update_tools.remap import \
    generate_remapping
from remap_badblocks.src.devices.device_config import DeviceConfig
from remap_badblocks.src.devices.devices_config import DevicesConfig


class ScanAndRemapArgs(TypedDict):
    device_id: Optional[int]
    device_name: Optional[str]
    reset_mapping: bool
    ignore_badblocks: bool


def parse_args(args: Namespace) -> ScanAndRemapArgs:
    return {
        "device_id": args.id,
        "device_name": args.name,
        "reset_mapping": args.reset_mapping,
        "ignore_badblocks": args.ignore_badblocks,
    }


def get_device_from_args(args: ScanAndRemapArgs, dc: DevicesConfig) -> DeviceConfig:
    if args["device_id"] is None:
        if args["device_name"] is not None:
            return dc.get_device(name=args["device_name"])
        else:
            raise ValueError(
                "Either --id or --name must be provided to update a device in the database."
            )

    return dc.get_device(id=args["device_id"])


def remap(dc: DevicesConfig, _args: Namespace) -> None:
    """
    Scan for new badblocks and update the mapping of a device in the database.
    """
    args = parse_args(_args)

    device: DeviceConfig = get_device_from_args(args, dc)
    n_spare_sectors = device.spare_sectors

    badblocks: Iterable[int]
    if args["ignore_badblocks"]:
        badblocks = set()
    else:
        badblocks = device.badblocks

    new_mapping = generate_remapping(
        args["reset_mapping"],
        device,
        badblocks,
        n_spare_sectors,
    )
    dc.update_device(id=device.id, mapping=new_mapping, spare_sectors=n_spare_sectors)

    print("Mapping updated.")


def define_command(scan_and_remap_parser: ArgumentParser) -> None:
    scan_and_remap_parser.add_argument(
        "--id",
        type=int,
        default=None,
        help="The ID of the device.",
    )
    scan_and_remap_parser.add_argument(
        "--name",
        type=str,
        default=None,
        help="The name of the device.",
    )
    scan_and_remap_parser.add_argument(
        "--reset-mapping",
        action="store_true",
        help=(
            "If specified, will ignore existing mapping and build a new mapping from scratch."
            " DANGER: this might lead to data loss, handle with care"
        ),
    )
    scan_and_remap_parser.add_argument(
        "--ignore-badblocks",
        action="store_true",
        help=(
            "If specified, will ignore the existing badblocks list and build/update the mapping without skipping"
            " any badblocks. This can be useful if you are rescuing a disk with an already existing FS and you want"
            " to start with a clean mapping, without skipping any blocks."
        ),
    )
