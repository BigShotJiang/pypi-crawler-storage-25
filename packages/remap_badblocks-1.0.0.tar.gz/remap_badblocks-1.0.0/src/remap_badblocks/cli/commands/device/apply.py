from argparse import ArgumentParser, Namespace
from pathlib import Path
from typing import Iterable, Literal, Optional, TypedDict

from remap_badblocks.src.devices.device_config import DeviceConfig
from remap_badblocks.src.devices.devices_config import DevicesConfig
from remap_badblocks.src.mapping import Mapping
from remap_badblocks.src.remappers._check_applied_devices import \
    filter_applied_devices
from remap_badblocks.src.remappers._generate_dm_table import generate_dm_table
from remap_badblocks.src.utils._run_command import run_command_realtime
from remap_badblocks.src.utils._sort_devices import \
    sort_devices_by_dependencies


class ApplyArgs(TypedDict):
    device_id: Optional[int]
    device_name: Optional[str]
    method: Literal["device-mapper"]
    allow_reapply: bool


def parse_args(args: Namespace) -> ApplyArgs:
    return {
        "device_id": args.id,
        "device_name": args.name,
        "method": args.method,
        "allow_reapply": args.allow_reapply,
    }


def get_user_wanted_device_list(
    dc: DevicesConfig, args: ApplyArgs
) -> Iterable[DeviceConfig]:
    if args["device_id"] is not None:
        return [dc.get_device(id=args["device_id"])]
    elif args["device_name"] is not None:
        return [dc.get_device(name=args["device_name"])]
    else:
        return filter(lambda d: d.enabled, dc.get_devices())


def plan_apply_devices(
    dc: DevicesConfig, devices: Iterable[DeviceConfig]
) -> Iterable[DeviceConfig]:
    return sort_devices_by_dependencies(
        list(devices), already_applied_devices=filter_applied_devices(dc.get_devices())
    )


def apply_device_mapper(device: DeviceConfig, allow_reapply: bool):
    mapping: Optional[Mapping] = device.mapping
    sector_size: int = device.sector_size
    device_path: Path = device.path

    assert mapping is not None, "Call ‘remap_badblocks update‘ before applying"

    device_dmtable_identifier = device_path

    dmtable = "\n".join(
        generate_dm_table(device_dmtable_identifier, mapping, sector_size)
    )

    dm_device_path = Path("/dev/mapper/{}".format(device.name))
    if dm_device_path.exists():
        if not allow_reapply:
            raise RuntimeError(
                f"Device {dm_device_path} already exists. Use --allow-reapply to reapply the device"
                " and update the mapping without removing it first."
            )
        else:
            for _ in run_command_realtime(["dmsetup", "suspend", device.name]):
                pass
            for _ in run_command_realtime(
                ["dmsetup", "reload", device.name], stdin=dmtable
            ):
                pass
            for _ in run_command_realtime(["dmsetup", "resume", device.name]):
                pass
    else:
        for _ in run_command_realtime(
            ["dmsetup", "create", device.name], stdin=dmtable
        ):
            pass

    print("Applied device to {}.".format(dm_device_path))


def apply(dc: DevicesConfig, _args: Namespace):
    args = parse_args(_args)

    devices: Iterable[DeviceConfig] = get_user_wanted_device_list(dc, args)
    devices = plan_apply_devices(dc, devices)

    # TODO: remove already applied devices

    method = args["method"]
    assert (
        method == "device-mapper"
    ), f"Only ‘device-mapper‘ method is available, found ‘{method}‘"

    for device in devices:
        apply_device_mapper(device, allow_reapply=args["allow_reapply"])


def define_command(apply_devices_parser: ArgumentParser) -> None:
    apply_devices_parser.add_argument(
        "--id",
        type=int,
        default=None,
        help="The ID of the device to apply. If neither --id or --name are provided, all devices will be applied.",
    )
    apply_devices_parser.add_argument(
        "--name",
        type=str,
        default=None,
        help="The name of the device to apply. If neither --id or --name are provided, all devices will be applied.",
    )
    apply_devices_parser.add_argument(
        "--method",
        type=str,
        default="device-mapper",
        choices=["device-mapper"],
        help="Method to apply the mapping. Only device-mapper is available",
    )
    apply_devices_parser.add_argument(
        "--allow-reapply",
        action="store_true",
        help=(
            "Reapply the device even if it is already applied. This can be useful to update "
            "the mapping of an already applied device without removing it first. Handle with care, though I/O "
            "will be suspended during the reapplication."
        ),
    )
