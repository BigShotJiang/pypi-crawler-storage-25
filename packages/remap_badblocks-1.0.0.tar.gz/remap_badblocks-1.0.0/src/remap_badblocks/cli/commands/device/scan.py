from argparse import ArgumentParser, Namespace
from pathlib import Path
from typing import Literal, Optional, TypedDict

from remap_badblocks.cli.commands.device.update_tools.scan import \
    scan_and_collect_badblocks
from remap_badblocks.src.devices.device_config import DeviceConfig
from remap_badblocks.src.devices.devices_config import DevicesConfig
from remap_badblocks.src.utils._parse_inputs import \
    parse_memory_range_to_sectors


class ScanArgs(TypedDict):
    device_id: Optional[int]
    device_name: Optional[str]
    mode: Literal["read", "write", "skip"]
    output: Optional[Path]
    block_range: str
    external_known_badblocks_file: Optional[Path]


def parse_args(args: Namespace) -> ScanArgs:
    return {
        "device_id": args.id,
        "device_name": args.name,
        "mode": args.mode,
        "output": args.output,
        "block_range": args.block_range,
        "external_known_badblocks_file": args.known_badblocks_file,
    }


def get_device_from_args(args: ScanArgs, dc: DevicesConfig) -> DeviceConfig:
    if args["device_id"] is None:
        if args["device_name"] is not None:
            return dc.get_device(name=args["device_name"])
        else:
            raise ValueError(
                "Either --id or --name must be provided to update a device in the database."
            )

    return dc.get_device(id=args["device_id"])


def get_scan_block_range_from_args(
    args: ScanArgs, device: DeviceConfig
) -> tuple[int, int]:
    start_block, end_block = parse_memory_range_to_sectors(
        args["block_range"],
        sector_size=device.sector_size,
    )

    if (start_block is not None and start_block < device.logical_range[0]) or (
        end_block is not None and end_block > device.logical_range[1]
    ):
        raise ValueError(
            f"Block range {start_block}-{end_block} must be contained"
            f" within the logical range {device.logical_range[0]}-{device.logical_range[1]}."
        )

    if start_block is None:
        start_block = device.logical_range[0]
    if end_block is None:
        end_block = device.logical_range[1]

    return start_block, end_block


def scan(dc: DevicesConfig, _args: Namespace) -> None:
    """
    Scan for new badblocks and store them in the database.
    """
    args = parse_args(_args)

    device: DeviceConfig = get_device_from_args(args, dc)
    block_range = get_scan_block_range_from_args(args, device)

    badblocks = scan_and_collect_badblocks(
        args["external_known_badblocks_file"],
        args["mode"],
        block_range,
        device,
        args["output"],
    )

    dc.update_device(
        id=device.id,
        badblocks=badblocks,
    )

    print("Badblocks list updated.")


def define_command(scan_parser: ArgumentParser) -> None:
    scan_parser.add_argument(
        "--id",
        type=int,
        default=None,
        help="The ID of the device.",
    )
    scan_parser.add_argument(
        "--name",
        type=str,
        default=None,
        help="The name of the device.",
    )
    scan_parser.add_argument(
        "--mode",
        type=str,
        choices=["read", "write", "skip"],
        default="read",
        help="Mode for computing badblocks",
    )
    scan_parser.add_argument(
        "--known-badblocks-file",
        type=Path,
        default=None,
        help=(
            "Path to file with known badblocks (a sector number for each line) that will be merged to those found"
            " so far. Take care the sector size is the same as configured into remap_badblocks"
        ),
    )
    scan_parser.add_argument(
        "--block-range",
        type=str,
        help=(
            "Block range to check (e.g., 0-1000, or 1573-), omitted start and end means the whole logical range. Note"
            " that the end is not included in the range"
        ),
        default="-",
    )
    scan_parser.add_argument(
        "--output",
        type=Path,
        default=None,
        help="Badblocks are stored internally. If provided, they will also be copied to this file.",
    )
