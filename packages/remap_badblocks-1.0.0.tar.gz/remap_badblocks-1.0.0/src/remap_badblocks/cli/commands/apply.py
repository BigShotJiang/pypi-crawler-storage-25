from argparse import ArgumentParser, Namespace

from remap_badblocks.src.devices.devices_config import DevicesConfig

from .device.apply import apply as func_apply
from .device.apply import define_command as define_apply_command


def define_command(subparser: ArgumentParser) -> None:
    define_apply_command(subparser)


def apply(dc: DevicesConfig, args: Namespace) -> None:
    func_apply(dc, args)
