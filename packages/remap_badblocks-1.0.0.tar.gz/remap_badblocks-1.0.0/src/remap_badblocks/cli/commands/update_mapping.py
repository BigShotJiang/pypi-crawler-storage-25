from argparse import ArgumentParser, Namespace
from pathlib import Path
from typing import Literal, Optional, TypedDict

from remap_badblocks.cli.commands.device.apply import apply
from remap_badblocks.cli.commands.device.remap import remap
from remap_badblocks.cli.commands.device.scan import scan
from remap_badblocks.src.devices.devices_config import DevicesConfig


def define_command(subparser: ArgumentParser) -> None:
    subparser.add_argument(
        "--id",
        type=int,
        default=None,
        help="The ID of the device.",
    )
    subparser.add_argument(
        "--name",
        type=str,
        default=None,
        help="The name of the device.",
    )
    subparser.add_argument(
        "--scan-mode",
        type=str,
        choices=["read", "write", "skip"],
        default="read",
        help="Mode for computing badblocks",
    )
    subparser.add_argument(
        "--known-badblocks-file",
        type=Path,
        default=None,
        help=(
            "Path to file with known badblocks (a sector number for each line) that will be merged to those found"
            " so far. Take care the sector size is the same as configured into remap_badblocks"
        ),
    )
    subparser.add_argument(
        "--block-range",
        type=str,
        help=(
            "Block range to check (e.g., 0-1000, or 1573-), omitted start and end means the whole logical range. Note"
            " that the end is not included in the range"
        ),
        default="-",
    )
    subparser.add_argument(
        "--apply-method",
        type=str,
        default="device-mapper",
        choices=["device-mapper"],
        help="Method to apply the mapping. Only device-mapper is available",
    )
    subparser.add_argument(
        "--allow-reapply",
        action="store_true",
        help=(
            "Reapply the device even if it is already applied. This can be useful to update "
            "the mapping of an already applied device without removing it first. Handle with care, though I/O "
            "will be suspended during the reapplication."
        ),
    )


class UpdateMappingArgs(TypedDict):
    id: Optional[int]
    name: Optional[str]
    scan_mode: Literal["read", "write", "skip"]
    known_badblocks_file: Optional[Path]
    block_range: str
    apply_method: Literal["device-mapper"]
    allow_reapply: bool


def parse_args(args: Namespace) -> UpdateMappingArgs:
    return {
        "id": args.id,
        "name": args.name,
        "scan_mode": args.scan_mode,
        "known_badblocks_file": args.known_badblocks_file,
        "block_range": args.block_range,
        "apply_method": args.apply_method,
        "allow_reapply": args.allow_reapply,
    }


def update_mapping(dc: DevicesConfig, args: Namespace) -> None:
    scan_args = Namespace(
        id=args.id,
        name=args.name,
        mode=args.scan_mode,
        known_badblocks_file=args.known_badblocks_file,
        block_range=args.block_range,
        output=None,
    )
    remap_args = Namespace(
        id=args.id,
        name=args.name,
        reset_mapping=False,
        ignore_badblocks=False,
    )
    apply_args = Namespace(
        id=args.id,
        name=args.name,
        method=args.apply_method,
        allow_reapply=args.allow_reapply,
    )

    print("Scanning for new badblocks and updating mapping...")
    scan(dc, scan_args)
    print("...badblocks scan completed.")

    print("Updating device mapping...")
    remap(dc, remap_args)
    print("...device mapping updated.")

    print("Applying device...")
    apply(dc, apply_args)
    print("...device applied.")
