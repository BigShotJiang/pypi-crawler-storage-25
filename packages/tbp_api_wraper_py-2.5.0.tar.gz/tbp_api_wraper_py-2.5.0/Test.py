from tbp_api_wraper_py import CTbpBase


if __name__ == "__main__":
    instance : CTbpBase = CTbpBase();
    instance.m_timeout = 5000
    instance.m_api_key = "YOUR_API_KEY"
    print(instance.GetAllClients())
    print(instance.m_json)
    