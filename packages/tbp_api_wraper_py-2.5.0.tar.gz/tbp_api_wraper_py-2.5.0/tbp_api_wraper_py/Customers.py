#+------------------------------------------------------------------+
#|                                                     Customers.py |
#|                                  Copyright 2025, Niquel Mendoza. |
#|                          https://www.mql5.com/es/users/nique_372 |
#+------------------------------------------------------------------+

from .Base import *

 
#---
class CTbpCustomers(CTbpBase):
    def __init__(self):
        super().__init__()
        self.m_aditional_data : ITbpAdditionalData = None
        self.m_software_id : str = ""

    #---
    # Nota importante
    # Las funciones reontanr un bool de exito o falso en la llamda \ parse json como tal no el valor
    # Para eso consulten el json o hay funciones que ya trean un &out

    #- Get customers of a software
    #- Lista clientes de un software concreto.
    def GetCustomersSotfware(self) -> bool:  # Para el resultado consultar el json
        headers : Dict[str, Any] = {"api-key": self.m_api_key}

        response : Response = requests.get(
            f'{THE_BOT_PLACE_BASE_URL}customers/{self.m_software_id}',
            headers=headers,
            timeout=float(self.m_timeout / 1000.0)
        )

        if(response.status_code != 200):
            self.LogError(f'Fallo al mandar request, codigo de requeset={response.status_code}, result:\n{response.text}')
            return False

        try:
            self.m_json = response.json()
        except requests.exceptions.JSONDecodeError as e:
            self.LogError(f'Fallo al parsear json, {str(e)}')
            return False

        return True

    #---
    #- User has software
    #- Verifica licencia incluyendo datos adicionales.
    def UserHasSoftware(self, userd_id : str) -> tuple[bool, bool]:  # Resultado en out
        headers : Dict[str, Any] = {"api-key": self.m_api_key}

        response : Response = requests.get(
            f'{THE_BOT_PLACE_BASE_URL}customers/user-has-product?userId={userd_id}&softwareId={self.m_software_id}&additional={self.m_aditional_data.Get()}',
            headers=headers,
            timeout=float(self.m_timeout / 1000.0)
        )

        if(response.status_code != 200):
            self.LogError(f'Fallo al mandar request, codigo de requeset={response.status_code}, result:\n{response.text}')
            return False, False

        out = (response.text == "true")
        return True, out

    #---
    #- User has software (no additional data)
    #- Comprueba si un usuario posee una licencia sin la necesidad de enviar un dato adicional.
    #- ATENCIÓN: este endpoint no valida datos adicionales asociados a la licencia, por lo que puede si un
    #- tercero posee el userId podrá usar tu bot. Este endpoint está pensado para la reventa de bots.
    def UserHastSoftwareNoaAdditionalData(self, userd_id : str) -> tuple[bool, bool]:  # Resultado en out
        headers : Dict[str, Any] = {"api-key": self.m_api_key}

        response : Response = requests.get(
            f'{THE_BOT_PLACE_BASE_URL}customers/user-has-product-no-additional?userId={userd_id}&softwareId={self.m_software_id}',
            headers=headers,
            timeout=float(self.m_timeout / 1000.0)
        )

        if(response.status_code != 200):
            self.LogError(f'Fallo al mandar request, codigo de requeset={response.status_code}, result:\n{response.text}')
            return False, False

        out = (response.text == "true")
        return True, out

    #---
    #- User has software (Telegram)
    #- Comprueba licencia usando identificador de Telegram.
    def UserHastSoftwareTelegram(self, telegram_user : str) -> tuple[bool, bool]:  # Resultado en out
        headers : Dict[str, Any] = {"api-key": self.m_api_key}

        response : Response = requests.get(
            f'{THE_BOT_PLACE_BASE_URL}customers/user-has-product-by-telegram?telegram={telegram_user}&softwareId={self.m_software_id}&additional={self.m_aditional_data.Get()}',
            headers=headers,
            timeout=float(self.m_timeout / 1000.0)
        )

        if(response.status_code != 200):
            self.LogError(f'Fallo al mandar request, codigo de requeset={response.status_code}, result:\n{response.text}')
            return False, False

        out = (response.text == "true")
        return True, out

    #---
    #- First demo download
    #- Comprueba si es la primera descarga de demo de un software.
    def FirstDemoDowlandSoftware(self, user_id : str) -> tuple[bool, int]:  # Resultado en out
        headers : Dict[str, Any] = {"api-key": self.m_api_key}

        response : Response = requests.get(
            f'{THE_BOT_PLACE_BASE_URL}software/first-demo-download?userId={user_id}&softwareId={self.m_software_id}',
            headers=headers,
            timeout=float(self.m_timeout / 1000.0)
        )

        if(response.status_code != 200):
            self.LogError(f'Fallo al mandar request, codigo de requeset={response.status_code}, result:\n{response.text}')
            return False, 0

        try:
            out = int(response.text)  # Viene en unix
        except ValueError as e:
            self.LogError(f'Fallo al convertir timestamp, {str(e)}')
            return False, 0

        return True, out
