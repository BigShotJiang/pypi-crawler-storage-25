#+------------------------------------------------------------------+
#|                                                          Jobs.py |
#|                                  Copyright 2025, Niquel Mendoza. |
#|                          https://www.mql5.com/es/users/nique_372 |
#+------------------------------------------------------------------+

from .Base import *

#---
class CTbpJobs(CTbpBase):
    def __init__(self):
        super().__init__()

    #---
    # Verifica si el software relacionado con un trabajo puede usarse.
    # Resultado en GetLastJson()
    def GetJobSoftwareAccess(self, user_id : str, job_id : str) -> bool:
        headers : Dict[str, Any] = {"api-key": self.m_api_key}

        response : Response = requests.get(
            f'{THE_BOT_PLACE_BASE_URL}jobs/?userId={user_id}&jobId={job_id}',
            headers=headers,
            timeout=float(self.m_timeout / 1000.0)
        )

        if(response.status_code != 200):
            self.LogError(f'Fallo al ejecutar get, codigo de requeset={response.status_code}, result:\n{response.text}')
            return False

        try:
            self.m_json = response.json()
        except requests.exceptions.JSONDecodeError as e:
            self.LogError(f'Fallo al parsear json, {str(e)}')
            return False

        return True

    #---
    # Verifica si un usuario puede acceder a la entrega de un trabajo.
    # Resultado en GetLastJson()
    def CheckJobDeliveryAccess(self, user_id : str, job_id : str) -> bool:
        headers : Dict[str, Any] = {"api-key": self.m_api_key}

        response : Response = requests.get(
            f'{THE_BOT_PLACE_BASE_URL}job/{job_id}?userId={user_id}',
            headers=headers,
            timeout=float(self.m_timeout / 1000.0)
        )

        if(response.status_code != 200):
            self.LogError(f'Fallo al ejecutar get, codigo de requeset={response.status_code}, result:\n{response.text}')
            return False

        try:
            self.m_json = response.json()
        except requests.exceptions.JSONDecodeError as e:
            self.LogError(f'Fallo al parsear json, {str(e)}')
            return False

        return True
