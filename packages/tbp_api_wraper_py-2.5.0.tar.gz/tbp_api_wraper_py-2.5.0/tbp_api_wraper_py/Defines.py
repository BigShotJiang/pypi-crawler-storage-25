# Defines
# Copyright 2025, Niquel Mendoza.
# https://www.mql5.com/es/users/nique_372

import json 
from tsn_utils import CLoggerBase  
from abc import abstractmethod
import requests
from requests import Response
from typing import Dict, Any

THE_BOT_PLACE_BASE_URL = "https://europe-west2-thebotplace.cloudfunctions.net/api/v1/api/"

class ITbpAdditionalData:
    def __init__(self):
        pass
    @abstractmethod
    def Get(self) -> str:
        pass 