# Base
# Copyright 2025, Niquel Mendoza.
# https://www.mql5.com/es/users/nique_372

from .Defines import *

class CTbpBase(CLoggerBase):
    def __init__(self):
        super().__init__()
        self.m_api_key : str  = ""
        self.m_json : dict = {}
        self.m_timeout : int = 0
        
 
    #---
    def GetAllClients(self) -> bool:
        headers : Dict[str, Any] = {"api-key": self.m_api_key}

        response : Response  = requests.get(
            f'{THE_BOT_PLACE_BASE_URL}customers/',
            headers=headers,
            timeout=float(self.m_timeout / 1000.0)
        ) 
        
        if(response.status_code != 200):
            self.LogError(f'Fallo al mandar request, codigo de requeset={response.status_code}, res = {response.text}');
            return False
        
        try:
            self.m_json = response.json()
        except requests.exceptions.JSONDecodeError as e:
            self.LogError(f'Fallo al parsear json, {str(e)}')
            return False
            
        return True 
        
            
            
        
        