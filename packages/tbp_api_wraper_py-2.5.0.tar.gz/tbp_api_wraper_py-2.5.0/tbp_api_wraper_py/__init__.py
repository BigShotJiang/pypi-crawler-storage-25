#+------------------------------------------------------------------+
#| Imports                                                          |
#+------------------------------------------------------------------+
from .Customers import CTbpCustomers
from .Jobs  import CTbpJobs 
from .Base  import CTbpBase 
from .Defines import THE_BOT_PLACE_BASE_URL

#+------------------------------------------------------------------+
#| General                                                          |
#+------------------------------------------------------------------+
__version__ = "1.0.0"             
__author__ = "TradeSystemsNique"    
__license__ = "Nique & Leo NL-NC"                
__copyright__ = "Copyright 2025, TradeSystemsNique"   


__all__ = [
    'CTbpCustomers',
    'CTbpJobs',
    'CTbpBase',
    'ITbpAdditionalData',
    'THE_BOT_PLACE_BASE_URL'
]