"""
Module to handle CLI/Text configurations
"""

from .interface import Interface, InterfaceSet
from .int_ranges import (
    int_list_2_int_range_list,
    int_ranges_str_2_int_list,
    int_ranges_str,
)
from .cisco_iosxe import (
    CiscoIosxeInterfaces,
    sort_cisco_iosxe_interface_names,
    cisco_iosxe_vlans_str,
)
from .cisco_nxos import (
    CiscoNxosInterfaces,
    sort_cisco_nxos_interface_names,
    cisco_nxos_vlans_str,
)

__version__ = "0.2.0"
version_info = (0, 2, 0)
