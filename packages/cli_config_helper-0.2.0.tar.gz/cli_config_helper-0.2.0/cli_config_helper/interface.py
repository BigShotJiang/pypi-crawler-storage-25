"""Basic classes to handle interface names/config"""

import re
from typing import Iterable


class SlotPath(list):
    """
    Represents the HW path of an interface
    """

    def __str__(self) -> str:
        return "/".join([str(x) for x in self])

    def __hash__(self):  # type: ignore
        r = self.__str__().__hash__()
        return r

    def __repr__(self):
        return f"{type(self)}[{self.__str__()}]"

    @property
    def module(self) -> "int|None":
        """
        Get module ID of slot path
        """
        if self:
            return self[0]
        return None


class Interface:
    """
    Class to represent an interface within a CLI/Text based configuration
    """

    _prefix_regex = r"[A-Za-z_-]+"
    _pre_prefix__gt__weight: "dict[str, int]" = {}
    _id_regex = r"\d+(/\d+)*"
    _id_separator = "/"
    _sub_interface_separator = "."

    def __init__(self, name: str, config: "list[str]|None" = None):
        if_match_regex = (
            rf"({self._prefix_regex})({self._id_regex})"
            + rf"({self._sub_interface_separator}(\d+))?"
        )
        match = re.match(if_match_regex, name)
        if not match:
            raise ValueError(
                f"Interface name '{name}' does not match required interface regex '{if_match_regex}"
            )
        self.regex_match = match
        self.name = name
        if config is None:
            self.config = []
        else:
            self.config = config
        self.slot_path = SlotPath(self.id_path[:-1])
        self.pre_prefix__gt__weight = self._pre_prefix__gt__weight

    @property
    def prefix(self) -> str:
        """
        Get interface name's prefix (tnterface type)
        """
        return self.regex_match.groups()[0]

    @property
    def id_path(self) -> "list[int]":
        """
        Get interface's ID path
        """
        ids = self.regex_match.groups()[1].split(self._id_separator)
        return [int(x) for x in ids]
        # return [int(self.regex_match.groups()[1])]

    @property
    def sub_interface_id(self) -> "int|None":
        """
        Get interface's sub interface ID or 'None' if not defined
        """
        if self.regex_match.groups()[-1] is None:
            return None
        return int(self.regex_match.groups()[-1])

    @property
    def port(self) -> int:
        """
        Return Port ID of Interface (last ID in ID Path)
        """
        return self.id_path[-1]

    def __str__(self):
        return self.name

    def __eq__(self, other):
        if not isinstance(other, Interface):
            return False
        if self.prefix != other.prefix:
            return False
        if self.id_path != other.id_path:
            return False
        return self.sub_interface_id == other.sub_interface_id

    def __ne__(self, other):
        return not self.__eq__(other)

    def _get_pre_prefix__gt__weight(self, i: "Interface") -> int:
        for regex, weight in self.pre_prefix__gt__weight.items():
            if re.match(regex, i.prefix):
                return weight
        return 0

    def _prefix__gt__(self, other: "Interface") -> "bool|None":
        if self.prefix != other.prefix:
            s_weight = self._get_pre_prefix__gt__weight(self)
            o_weight = self._get_pre_prefix__gt__weight(other)
            if s_weight != o_weight:
                return s_weight > o_weight
            return self.prefix > other.prefix
        return None

    def _id_path__gt__(self, other: "Interface") -> "bool|None":
        s_id_len = len(self.id_path)
        o_id_len = len(other.id_path)
        for i in range(s_id_len):
            if i < o_id_len:
                if self.id_path[i] != other.id_path[i]:
                    return self.id_path[i] > other.id_path[i]
            else:
                return True
        # Self ids are same as in others. But if other has more ids it is greater than self.
        if o_id_len > s_id_len:
            return False
        return None

    def _subif__gt__(self, other: "Interface") -> "bool|None":
        if self.sub_interface_id is None:
            return False
        if other.sub_interface_id is None:
            return (
                self.sub_interface_id is not None
            )  # self has subinterface --> self is greater
        return self.sub_interface_id > other.sub_interface_id

    def __gt__(self, other):
        if not isinstance(other, Interface):
            raise TypeError(
                f"'>' not supported between instances of '{type(self)}' and '{type(other)}'"
            )
        for test_func in [self._prefix__gt__, self._id_path__gt__, self._subif__gt__]:
            check = test_func(other)
            if check is not None:
                return check
        return False

    def __ge__(self, other):
        if not isinstance(other, Interface):
            raise TypeError(
                f"'>=' not supported between instances of '{type(self)}' and '{type(other)}'"
            )
        return self.__eq__(other) or self.__gt__(other)

    def __lt__(self, other):
        if not isinstance(other, Interface):
            raise TypeError(
                f"'<' not supported between instances of '{type(self)}' and '{type(other)}'"
            )
        return not self.__gt__(other) and not self.__eq__(other)

    def __le__(self, other):
        if not isinstance(other, Interface):
            raise TypeError(
                f"'<=' not supported between instances of '{type(self)}' and '{type(other)}'"
            )
        return not self.__gt__(other)

    def __hash__(self):
        return id(self)

    def __repr__(self):
        return f"{self.name} >> {super().__repr__()}"


class InterfaceSet(set["Interface"]):
    """
    Representing a set of Interface objects
    """

    _element_class = Interface

    def names(self, sort: bool = True, reverse: bool = False) -> "list[str]":
        """
        Get all interface names
        """
        if sort:
            return [x.name for x in sorted(self, reverse=reverse)]
        return [x.name for x in self]

    def items(
        self, sort: bool = True, reverse: bool = False
    ) -> "list[tuple[str, list[str]]]":
        """
        Get list of all (interface.name, interface.config) tuples
        """
        if sort:
            return [(x.name, x.config) for x in sorted(self, reverse=reverse)]
        return [(x.name, x.config) for x in self]

    @classmethod
    def _type_validation(cls, element):
        if not isinstance(element, cls._element_class):
            raise TypeError(
                f"{cls.__name__} can only contain {cls._element_class.__name__} object"
            )

    def add_interface(
        self, element: "Interface | str", config: "None | list[str]" = None
    ) -> "Interface":
        """
        Add an Interface object or a interface name str to this set
        """
        if isinstance(element, str):
            element = self._element_class(name=element, config=config)
        self._type_validation(element)
        self.add(element)
        return element

    def add(
        self,
        element: "Interface",
    ):
        """
        Add an Interface object to this set
        """
        self._type_validation(element)
        for i in self:
            if i.name == element.name:
                self.remove(i)
                break
        super().add(element)

    def update(self, *s: "Iterable[Interface]") -> "None":
        """
        Add Interface objects to this set
        """
        for i in s:
            if isinstance(i, self._element_class):
                i = [i]
            for element in i:
                self.add(element)

    def get(self, name: str) -> "Interface | None":
        """
        Get an Interface object from set by name
        """
        for i in self:
            if i.name == name:
                return i
        return None

    def extend_config(self, name: str, config: "list[str]") -> "Interface":
        """
        Add config lines to interface within set.
        If interface name not found, a new one is created.
        """
        if interface := self.get(name):
            interface.config += config
            return interface
        i = self._element_class(name=name, config=config)
        self.add(i)
        return i
