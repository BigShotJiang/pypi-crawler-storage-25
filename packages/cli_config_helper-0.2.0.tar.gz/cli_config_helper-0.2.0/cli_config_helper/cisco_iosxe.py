"""Basic classes to handle Cisco IOS-XE interface names/config"""

import re
from typing import TYPE_CHECKING
from .interface import Interface, InterfaceSet, SlotPath
from .int_ranges import int_ranges_str

if TYPE_CHECKING:
    from typing import Iterable, Literal

_UPPER_LOCIGAL_PORT_WEIGHT = {
    "Auto-Template": 10,
    "Loopback": 20,
    "Port-channel": 30,
    "Multilink": 40,
    "CTunnel": 50,
    "Tunnel-tp": 110,  # "Tunnel" shadows this!
    "Tunnel": 60,
    "MFR": 70,
    "SBC": 80,
    "pseudowire": 90,
    "VPN": 100,
    "LISP": 120,
    "Overlay": 130,
    "VirtualPortGroup": 140,
    ".*": 1000,  # Any unspecific interface name (prefix)
}

_LOWER_LOCIGAL_PORT_WEIGHT = {
    "router": {
        "Virtual-PPP": 10,
        "Virtual-Template": 20,
        "Dialer": 30,
        "multiservice": 40,
        "vasileft": 50,
        "vasiright": 60,
        "Group-Async": 70,
        "BVI": 80,
        "Vif": 90,
        "vmi": 100,
        "BDI": 110,
        "BD-VIF": 120,
        "GMPLS": 130,
        "Vlan": 140,
        "nve": 150,
    },
    "switch": {
        "Virtual-PPP": 10,
        "Virtual-Template": 20,
        "Dialer": 30,
        "multiservice": 40,
        "vasileft": 50,
        "vasiright": 60,
        "Group-Async": 70,
        "BVI": 80,
        "Vif": 90,
        "vmi": 100,
        "BD-VIF": 110,
        "Vlan": 120,
        "GMPLS": 130,
        "BDI": 140,
        "nve": 150,
    },
}

_ETHERNET_SLOT_LOCAL_WEIGTH = {
    "FastEthernet": 10,
    "GigabitEthernet": 20,
    "TenGigabitEthernet": 30,
    "FortyGigabitEthernet": 40,
    "TwentyFiveGigE": 50,
    "HundredGigE": 60,
}


class CiscoIosxeInterfaces:
    """
    Class to represent an interfaces and their config lines
    within a IOS-XE CLI configuration
    """

    def __init__(self, device: "Literal['router', 'switch']" = "switch"):
        self._lower_logical_port_weight = _LOWER_LOCIGAL_PORT_WEIGHT[device]
        self._upper_logical_interfaces = InterfaceSet()
        self._lower_logical_interfaces = InterfaceSet()
        self._ethernet_slots: "dict[SlotPath, InterfaceSet]" = {}
        self._app_ethernet_modules: "dict[int|None, InterfaceSet]" = {}

    def add_interface(
        self, name: str, config: "list[str] | None" = None
    ) -> "Interface":
        """
        Add a interface name and a config if given
        """
        i = Interface(name=name, config=config)
        self.add(i)
        return i

    def add(self, i: Interface):
        """
        Add an interface object
        """
        for regex in self._lower_logical_port_weight:
            if re.match(regex, i.prefix):
                i.pre_prefix__gt__weight = self._lower_logical_port_weight
                self._lower_logical_interfaces.add(i)
                return
        if re.match(".*(thernet|GigE)", i.prefix):
            if re.match("App.*", i.prefix):
                if i.slot_path.module not in self._app_ethernet_modules:
                    self._app_ethernet_modules[i.slot_path.module] = InterfaceSet()
                self._app_ethernet_modules[i.slot_path.module].add(i)
                return
            if i.slot_path not in self._ethernet_slots:
                self._ethernet_slots[i.slot_path] = InterfaceSet()
            i.pre_prefix__gt__weight = _ETHERNET_SLOT_LOCAL_WEIGTH
            self._ethernet_slots[i.slot_path].add(i)
            return
        i.pre_prefix__gt__weight = _UPPER_LOCIGAL_PORT_WEIGHT
        self._upper_logical_interfaces.add(i)
        return

    def _all_interfaces(
        self, sort: bool = True, reverse: bool = False
    ) -> "list[Interface]":
        if sort:
            func = sorted
        else:
            func = list

        ifs = func(self._upper_logical_interfaces)
        all_slots = sorted(self._ethernet_slots)
        if all_slots:
            previous_module = all_slots[0].module
            for slot in sorted(all_slots):
                if slot.module != previous_module:
                    # before jumping to next module, append AppEthernet interfaces
                    ifs += func(self._app_ethernet_modules.get(previous_module, []))
                    previous_module = slot.module
                ifs += func(self._ethernet_slots[slot])
            # append AppEthernet interfaces of last module
            ifs += func(self._app_ethernet_modules.get(previous_module, []))
        ifs += func(self._lower_logical_interfaces)
        if reverse:
            return list(reversed(ifs))
        return ifs

    def names(self, sort: bool = True, reverse: bool = False) -> "list[str]":
        """
        Get all interface names
        """
        return [x.name for x in self._all_interfaces(sort=sort, reverse=reverse)]

    def items(
        self, sort: bool = True, reverse: bool = False
    ) -> "list[tuple[str, list[str]]]":
        """
        Get list of all (interface.name, interface.config) tuples
        """
        return [
            (x.name, x.config) for x in self._all_interfaces(sort=sort, reverse=reverse)
        ]

    def get(self, name: str) -> "Interface | None":
        """
        Get an Interface object from set by name
        """
        for k in self._all_interfaces():
            if k.name == name:
                return k
        return None

    def extend_config(self, name: str, config: "list[str]") -> "Interface":
        """
        Add config lines to interface within set.
        If interface name not found, a new one is created.
        """
        if interface := self.get(name):
            interface.config += config
        return self.add_interface(name=name, config=config)

    def __len__(self) -> int:
        return len(self._all_interfaces())

    def __iter__(self):
        return self._all_interfaces().__iter__()

    def __contains__(self, item: "Interface"):
        for interface in self._all_interfaces():
            if id(item) == id(interface):
                return True
        return False


def sort_cisco_iosxe_interface_names(
    names: "Iterable[str]", device: "Literal['router', 'switch']" = "switch"
) -> "list[str]":
    """
    Sort given interface names in correct order
    of appereance within a CLI configuration.

    Select IOS-XE device type to have platform agnostic order.
    """

    interfaces = CiscoIosxeInterfaces(device=device)
    for name in names:
        interfaces.add_interface(name)
    return interfaces.names()


def cisco_iosxe_vlans_str(
    values: "str|Iterable[str|int]",
    line_length: int = 0,
    new_line_length: "int|None" = None,
) -> "list[str]":
    # pylint: disable=duplicate-code
    """
    Builds a list of strings containing vlan ranges
    like in Cisco IOS-XE configurations.

    options:
        values:
            type: list[str] | list[int] | str | dict
            description: Element(s) containing integer information
            required: true
        max_length:
            type: int
            description: "Maximum length of first returned string containing
            comma-separated integer ranges (0 or >10)"
            required: false
            default: 0
        max_length_next:
            type: int
            description: "Maximum length of second and continueing returned
            string containing comma-separated integer ranges (>10)"
            required: false
            default: 0

    returns:
        type: list
        description: List of comma-separated integer range strings
        elements: str"
    """
    if values is None:
        return []
    if isinstance(values, str):
        if values == "all":
            return ["all"]
        if values == "none":
            return ["none"]
    return int_ranges_str(
        values=values,
        max_int=4096,
        line_length=line_length,
        new_line_length=new_line_length,
        dual_int_ranges=False,
    )
