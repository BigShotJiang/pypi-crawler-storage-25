"""
Converting between list of integers and list of integer range strings
"""

from collections.abc import Iterable as _Iterable
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from typing import Iterable


def int_ranges_str_2_int_list(string_list: str) -> "list[int]":
    """
    Parse a string representing a comma-separated list of integer ranges
    into a list of integers

    Example:
    str_list: ['100-103,105']
    returns: [100, 101, 102, 103, 105]
    """
    if not string_list:
        return []
    integer_list = []
    for element in string_list.split(","):
        words = element.split("-")
        if len(words) == 1:
            integer_list.append(int(element))
        elif len(words) == 2:
            start, end = words
            integer_list.extend(
                range(
                    int(start),
                    int(end) + 1,
                )
            )
        else:
            raise ValueError(
                f"'{string_list}' is not a valid comma-separated integer range list."
            )
    return integer_list


def int_list_2_int_range_list(l: "list[int]") -> "list[tuple[int, int]]":
    """
    Transform a list of integer values
    to a list of range tuples (start, end).

    Example:
    l: [1, 21, 22, 23, 45, 46]
    returns: [(1, 1), (21, 23), (45, 46)]
    """
    if not l:
        return []
    return_list = []
    l = sorted(l)
    end_int = start_int = l[0]
    for cur_int in l[1:]:
        if cur_int == end_int + 1:
            # This vlan ID extends current range
            end_int = cur_int
            continue
        # We have a new range
        return_list.append((start_int, end_int))
        start_int = cur_int
        end_int = cur_int
    # add last range
    return_list.append((start_int, end_int))
    return return_list


def _convert_int_ranges_2_str_list(
    int_ranges: "list[tuple[int, int]]",
    line_length: "int" = 0,
    new_line_length: "int|None" = None,
    dual_int_ranges: bool = True,
) -> "list[str]":
    def add_str(s: str, line: str) -> "tuple[str, list[str]]":
        _lines = []
        if 0 < limit < len(line) + len(s) + 1:
            _lines.append(line)
            line = s
        elif line:
            line += "," + s
        else:
            line = s
        return line, _lines

    lines = []
    line = ""
    limit = line_length
    for start_int, end_int in int_ranges:
        if len(lines) > 0 and new_line_length:
            limit = new_line_length
        if start_int == end_int:
            s = str(start_int)
        elif not dual_int_ranges and start_int + 1 == end_int:
            line, new_lines1 = add_str(str(start_int), line)
            line, new_lines2 = add_str(str(end_int), line)
            lines += new_lines1 + new_lines2
            continue
        else:
            s = f"{start_int}-{end_int}"
        line, new_lines = add_str(s, line)
        lines += new_lines
    if line:
        lines.append(line)
    return lines


def _get_sorted_integer_list(
    values: "Iterable[int | str]", max_int: int = 0
) -> list[int]:
    # Convert strings to integers, needed:
    int_list = []
    for i in values:
        i_int = int(i)
        if 0 < max_int < i_int:
            raise ValueError(
                f"Integer value '{i_int}' is greater than limit of {max_int}"
            )
        if i_int < 0:
            raise ValueError(f"Unsupported negative integer value '{i_int}'")
        int_list.append(i_int)
    return sorted(int_list)


def _check_options(
    max_int: int = 0,
    line_length: int = 0,
    new_line_length: "int|None" = None,
):

    # Check 'max_int' parameter
    if not isinstance(max_int, int) or max_int < 0:
        raise ValueError("Parameter 'max_int' needs to be an integer and >= 0.")
    # Check 'max_length' and 'max_length_next' parameters
    if not isinstance(line_length, int) or (line_length != 0 and line_length < 11):
        raise ValueError("Parameter 'max_length' needs to be an integer and >= 11.")
    if new_line_length is not None and (
        not isinstance(new_line_length, int)
        or (line_length != 0 and new_line_length < 11)
    ):
        raise ValueError(
            "Parameter 'max_length_next' needs to be an integer and >= 11."
        )


def int_ranges_str(
    values: "str|Iterable[str|int]",
    max_int: int = 0,
    line_length: int = 0,
    new_line_length: "int|None" = None,
    dual_int_ranges: bool = True,
) -> "list[str]":
    """
    Builds a list of comma-separated integer range
    list strings from any given informationen containing integers or
    integer ranges.

    options:
        values:
            type: list[str] | list[int] | str | dict
            description: Element(s) containing integer information
            required: true
        max_int:
            type: int
            description: "Maximum allowed integer value"
            required: false
            default: 0
        max_length:
            type: int
            description: "Maximum length of first returned string containing
            comma-separated integer ranges (0 or >10)"
            required: false
            default: 0
        max_length_next:
            type: int
            description: "Maximum length of second and continueing returned
            string containing comma-separated integer ranges (>10)"
            required: false
            default: 0
        dual_int_ranges:
            type: bool
            description: "Select parsing mode of a range of two values.
            I.E. select between '10-11' (dual_int_range) and '10,11'."
            required: false
            default: true

    returns:
        type: list
        description: List of comma-separated integer range strings
        elements: str"
    """

    _check_options(
        max_int=max_int, line_length=line_length, new_line_length=new_line_length
    )
    # Check 'values'
    if not values:
        return []
    if isinstance(values, str):
        values = int_ranges_str_2_int_list(values)
    elif isinstance(values, _Iterable):
        values = list(values)
    else:
        raise ValueError("Given Integer information is not valid.")

    values = [int(x) for x in values]
    if not values:
        return []
    if 0 < max_int < max(values):
        raise ValueError(
            f"Given value contains integer values exceeding the limit of {max_int}"
        )
    if min(values) < 0:
        raise ValueError("Given value contains an unsupported negative integer value")
    if len(values) == 1:
        return [str(values[0])]

    return _convert_int_ranges_2_str_list(
        int_ranges=int_list_2_int_range_list(l=values),
        line_length=line_length,
        new_line_length=new_line_length,
        dual_int_ranges=dual_int_ranges,
    )
