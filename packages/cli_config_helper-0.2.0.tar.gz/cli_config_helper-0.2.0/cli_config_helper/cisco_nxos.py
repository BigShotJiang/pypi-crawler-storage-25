"""Basic classes to handle Cisco NX-OS interface names/config"""

from typing import TYPE_CHECKING

from .interface import Interface, InterfaceSet
from .int_ranges import int_ranges_str

if TYPE_CHECKING:
    from typing import Iterable


class CiscoNxosInterface(Interface):
    """
    Class representing an interface within a NX-OS configuration.
    It implements the correct order/sorting
    """

    _pre_prefix__gt__weight = {
        "Vlan": 10,
        "port-channel": 20,
        "Tunnel": 30,
        "nve": 40,
        "Ethernet": 50,
        "mgmt": 60,
        "loopback": 70,
        ".*": 1000,  # Any unspecific interface name (prefix)
    }


class CiscoNxosInterfaces(InterfaceSet):
    """
    Class to represent an interfaces and their config lines
    within a NX-OS CLI configuration
    """

    _element_class = CiscoNxosInterface


def sort_cisco_nxos_interface_names(names: "Iterable[str]") -> "list[str]":
    """
    Sort given interface names in correct order
    of appereance within a CLI configuration.
    """

    interfaces = CiscoNxosInterfaces()
    for name in names:
        interfaces.add_interface(name)
    return interfaces.names()


def cisco_nxos_vlans_str(
    values: "str|Iterable[str|int]",
    line_length: int = 0,
    new_line_length: "int|None" = None,
) -> "list[str]":
    # pylint: disable=duplicate-code
    """
    Builds a list of strings containing vlan ranges
    like in Cisco NX-OS configurations.

    options:
        values:
            type: list[str] | list[int] | str | dict
            description: Element(s) containing integer information
            required: true
        max_length:
            type: int
            description: "Maximum length of first returned string containing
            comma-separated integer ranges (0 or >10)"
            required: false
            default: 0
        max_length_next:
            type: int
            description: "Maximum length of second and continueing returned
            string containing comma-separated integer ranges (>10)"
            required: false
            default: 0

    returns:
        type: list
        description: List of comma-separated integer range strings
        elements: str"
    """
    if values is None:
        return []
    if isinstance(values, str):
        if values == "all":
            return ["all"]
        if values == "none":
            return ["none"]
    return int_ranges_str(
        values=values,
        max_int=4096,
        line_length=line_length,
        new_line_length=new_line_length,
        dual_int_ranges=True,
    )
