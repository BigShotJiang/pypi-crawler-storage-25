#!/usr/bin/env python3
"""
anyonecandock  CLI  —  acd <command> [options]

Commands
--------
  dock      Full pipeline: receptor + ligand + Vina docking (single ligand)
  batch     Batch docking from a .smi file or SMILES list
  receptor  Prepare a receptor only (download/convert → .pdb + .pdbqt + box)
  ligand    Prepare a ligand only (SMILES/file → .pdbqt + .sdf)
  redock    Self-docking validation: re-dock the co-crystal ligand automatically
            (no ligand input required — SMILES fetched from RCSB CCD)
  diagram   Generate a 2D interaction diagram SVG for a completed docking run

Run  acd <command> --help  for per-command options.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import textwrap
from pathlib import Path

# ── optional pretty-print ─────────────────────────────────────────────────────
try:
    from rich.console import Console
    from rich.table import Table
    from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn
    _RICH = True
    _con = Console()
except ImportError:
    _RICH = False

    class _FakeConsole:
        def print(self, *a, **kw): print(*a)
        def log(self, *a, **kw): print(*a)
        def rule(self, *a, **kw): print("─" * 60)
    _con = _FakeConsole()


# ── helpers ───────────────────────────────────────────────────────────────────

def _banner():
    txt = textwrap.dedent("""\
        ╔══════════════════════════════════════════════════════╗
        ║  anyone can dock  —  AutoDock Vina 1.2.7 + pKaNET   ║
        ╚══════════════════════════════════════════════════════╝""")
    if _RICH:
        _con.print(f"[bold cyan]{txt}[/bold cyan]")
    else:
        print(txt)


def _ok(msg: str):
    prefix = "[green]✓[/green]" if _RICH else "✓"
    _con.print(f"{prefix}  {msg}")


def _warn(msg: str):
    prefix = "[yellow]⚠[/yellow]" if _RICH else "⚠"
    _con.print(f"{prefix}  {msg}")


def _err(msg: str):
    prefix = "[red]✗[/red]" if _RICH else "✗"
    _con.print(f"{prefix}  {msg}")
    sys.exit(1)


def _step(msg: str):
    if _RICH:
        _con.rule(f"[bold]{msg}[/bold]")
    else:
        print(f"\n{'─'*60}\n  {msg}\n{'─'*60}")


def _import_core():
    """Import core.py from the same package directory."""
    try:
        from anyonecandock import core
        return core
    except ImportError:
        here = Path(__file__).resolve().parent
        import importlib.util
        spec = importlib.util.spec_from_file_location("core", here / "core.py")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod


def _spinner(label: str):
    if _RICH:
        return Progress(
            SpinnerColumn(),
            TextColumn(f"[cyan]{label}[/cyan]"),
            TimeElapsedColumn(),
            transient=True,
        )
    import contextlib
    @contextlib.contextmanager
    def _fake():
        print(f"⏳  {label} …")
        yield None
    return _fake()


def _pubchem_smiles(name: str) -> str:
    """Look up a compound by name on PubChem and return its SMILES."""
    import requests
    from urllib.parse import quote

    _ok(f"Searching PubChem for '{name}' …")

    # Step 1: get CID from name
    r = requests.get(
        f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/"
        f"{quote(name)}/cids/JSON",
        timeout=10,
    )
    if r.status_code != 200:
        _err(f"Compound '{name}' not found on PubChem (HTTP {r.status_code})")

    cid = r.json()["IdentifierList"]["CID"][0]
    _ok(f"Found CID: {cid}")

    # Step 2: try each property key individually
    for prop in ["IsomericSMILES", "CanonicalSMILES"]:
        try:
            r2 = requests.get(
                f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/"
                f"{cid}/property/{prop}/JSON",
                timeout=10,
            )
            if r2.status_code == 200:
                props = r2.json().get("PropertyTable", {}).get("Properties", [{}])
                smiles = props[0].get(prop, "") if props else ""
                if smiles:
                    _ok(f"Found SMILES: {smiles}")
                    return smiles
        except Exception:
            continue

    # Step 3: fallback — scrape from full compound JSON
    try:
        r3 = requests.get(
            f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/{cid}/JSON",
            timeout=15,
        )
        if r3.status_code == 200:
            compounds = r3.json().get("PC_Compounds", [{}])
            for prop_item in compounds[0].get("props", []):
                label = prop_item.get("urn", {}).get("label", "")
                if "SMILES" in label:
                    val    = prop_item.get("value", {})
                    smiles = val.get("sval") or val.get("string") or ""
                    if smiles:
                        _ok(f"Found SMILES (fallback): {smiles}")
                        return smiles
    except Exception:
        pass

    _err(f"PubChem returned no usable SMILES for '{name}'")


def _resolve_ligand(args, name: str) -> tuple[str, str]:
    """Return (smiles, name) from --smiles or --compound."""
    if getattr(args, "ligand_file", None):
        return "", name  # file path — caller handles prepare_ligand_from_file

    smiles   = getattr(args, "smiles",   None) or ""
    compound = getattr(args, "compound", None) or ""

    if compound and not smiles:
        smiles = _pubchem_smiles(compound)
        if not name or name == "LIG":
            name = compound.replace(" ", "_")

    if not smiles:
        _err("Provide --smiles <SMILES>,  --compound <name>,  or  --ligand-file <path>")

    return smiles, name


def _print_scores(scores: list, ref_score: float | None = None,
                  pose_mols: list | None = None,
                  crystal_pdb: str | None = None,
                  core=None):
    """Print docking score table with RMSD vs crystal when available."""
    if not scores:
        _warn("No scores returned.")
        return

    # compute RMSD vs crystal for each pose
    rmsds: dict = {}
    if core and pose_mols and crystal_pdb and os.path.exists(crystal_pdb):
        for s in scores:
            idx = (s["pose"] - 1) if s["pose"] else 0
            if idx < len(pose_mols):
                try:
                    r = core.calc_rmsd_heavy(pose_mols[idx], crystal_pdb)
                    rmsds[s["pose"]] = round(r, 2) if r is not None else None
                except Exception:
                    rmsds[s["pose"]] = None

    if _RICH:
        t = Table(title="Docking Scores", show_header=True, header_style="bold cyan")
        t.add_column("Pose", style="dim")
        t.add_column("Affinity (kcal/mol)", justify="right")
        if rmsds:
            t.add_column("RMSD vs crystal (Å)", justify="right")
        for s in scores:
            aff   = s["affinity"]
            aclr  = "green" if aff < -8 else "yellow" if aff < -6 else "red"
            row   = [str(s["pose"]), f"[{aclr}]{aff:.2f}[/{aclr}]"]
            if rmsds:
                r = rmsds.get(s["pose"])
                if r is None:
                    row.append("—")
                else:
                    rclr = "green" if r <= 2.0 else "yellow" if r <= 3.0 else "red"
                    row.append(f"[{rclr}]{r:.2f}[/{rclr}]")
            t.add_row(*row)
        _con.print(t)
    else:
        header = f"\n{'Pose':>6}  {'Affinity':>16}"
        if rmsds:
            header += f"  {'RMSD vs crystal':>16}"
        print(header)
        print("─" * (48 + (18 if rmsds else 0)))
        for s in scores:
            line = f"{s['pose']:>6}  {s['affinity']:>16.2f}"
            if rmsds:
                r = rmsds.get(s["pose"])
                line += f"  {str(round(r, 2)) if r is not None else '—':>16}"
            print(line)

    best  = scores[0]["affinity"]
    label = ("Very strong" if best < -11 else "Strong" if best < -9
             else "Moderate" if best < -7 else "Weak")
    _ok(f"Best pose: {best:.2f} kcal/mol  ({label} predicted binding)")
    if ref_score is not None:
        _ok(f"vs reference: {best - ref_score:+.2f} kcal/mol")
    if rmsds:
        r1 = rmsds.get(scores[0]["pose"])
        if r1 is not None:
            verdict = ("✓ good reproduction" if r1 <= 2.0
                       else "⚠ moderate" if r1 <= 3.0
                       else "✗ differs from crystal")
            _ok(f"Best pose RMSD vs crystal: {r1:.2f} Å  ({verdict})")


def _write_scores_csv(scores: list, path: str, lig_name: str = "",
                      rmsds: dict | None = None):
    with open(path, "w", newline="") as fh:
        fieldnames = ["ligand", "pose", "affinity", "rmsd_vs_crystal"]
        w = csv.DictWriter(fh, fieldnames=fieldnames)
        w.writeheader()
        for s in scores:
            r = (rmsds or {}).get(s["pose"])
            w.writerow({
                "ligand":           lig_name,
                "pose":             s["pose"],
                "affinity":         s["affinity"],
                "rmsd_vs_crystal":  round(r, 2) if r is not None else "",
            })


# ── sub-command: receptor ─────────────────────────────────────────────────────

def cmd_receptor(args):
    core = _import_core()
    _step("Receptor preparation")

    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)

    if args.pdb:
        token = args.pdb.strip().upper()
        fmt   = args.fmt.upper()
        ext   = "cif" if fmt == "CIF" else "pdb"
        raw   = str(out / f"raw.{ext}")
        _ok(f"Downloading {token} ({fmt}) from RCSB …")
        rc, _ = core.run_cmd(["curl", "-sf",
                               f"https://files.rcsb.org/download/{token}.{ext}",
                               "-o", raw])
        if rc != 0 or not os.path.exists(raw) or os.path.getsize(raw) < 200:
            if fmt == "PDB":
                raw_cif = str(out / "raw.cif")
                rc2, _ = core.run_cmd(["curl", "-sf",
                                        f"https://files.rcsb.org/download/{token}.cif",
                                        "-o", raw_cif])
                if rc2 == 0 and os.path.exists(raw_cif) and os.path.getsize(raw_cif) > 200:
                    raw = raw_cif
                    _warn("PDB unavailable; fell back to CIF")
                else:
                    _err(f"Download failed for {token}")
            else:
                _err(f"Download failed for {token}")
    elif args.file:
        raw = args.file
        if not os.path.exists(raw):
            _err(f"File not found: {raw}")
    else:
        _err("Provide --pdb <PDB_ID>  or  --file <path>")

    manual_xyz = (float(args.cx or 0), float(args.cy or 0), float(args.cz or 0))

    print("⏳  Preparing receptor …")
    result = core.prepare_receptor(
        raw_pdb    = raw,
        wdir       = out,
        center_mode= args.center,
        manual_xyz = manual_xyz,
        prody_sel  = args.sel or "",
        box_size   = (args.bx, args.by, args.bz),
    )

    if not result["success"]:
        _err(f"Receptor preparation failed: {result['error']}")

    cx, cy, cz = result["cx"], result["cy"], result["cz"]
    _ok(f"Receptor PDB : {result['rec_fh']}")
    _ok(f"PDBQT        : {result['rec_pdbqt']}")
    _ok(f"Box config   : {result['config_txt']}")
    _ok(f"Grid center  : ({cx:.3f}, {cy:.3f}, {cz:.3f})")
    if result.get("cocrystal_ligand_id"):
        _ok(f"Co-crystal   : {result['cocrystal_ligand_id']}")

    summary = {
        "rec_fh":              result["rec_fh"],
        "rec_pdbqt":           result["rec_pdbqt"],
        "config_txt":          result["config_txt"],
        "cx": cx, "cy": cy, "cz": cz,
        "sx": result["sx"], "sy": result["sy"], "sz": result["sz"],
        "ligand_pdb_path":     result.get("ligand_pdb_path"),
        "cocrystal_ligand_id": result.get("cocrystal_ligand_id", ""),
    }
    summary_path = str(out / "receptor_summary.json")
    with open(summary_path, "w") as fh:
        json.dump(summary, fh, indent=2)
    _ok(f"Summary JSON : {summary_path}")


# ── sub-command: ligand ────────────────────────────────────────────────────────

def cmd_ligand(args):
    core = _import_core()
    _step("Ligand preparation")

    out  = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    name = args.name or "LIG"
    ph   = args.ph
    prot_mode = "neutral" if args.neutral else "pkanet"

    print(f"⏳  Preparing {name} at pH {ph} …")

    if getattr(args, "file", None):
        if not os.path.exists(args.file):
            _err(f"File not found: {args.file}")
        result = core.prepare_ligand_from_file(args.file, name, out)
    else:
        smiles, name = _resolve_ligand(args, name)
        result = core.prepare_ligand(
            smiles        = smiles,
            name          = name,
            ph            = ph,
            wdir          = out,
            mode          = prot_mode,
            use_pubchem   = not args.no_pubchem,
            max_tautomers = args.max_tautomers,
            ph_window     = args.ph_window,
        )

    if not result["success"]:
        _err(f"Ligand preparation failed: {result['error']}")

    _ok(f"PDBQT         : {result['pdbqt']}")
    _ok(f"SDF (3D)      : {result['sdf']}")
    _ok(f"Formal charge : {int(result.get('net_charge', result.get('charge', 0))):+d}")
    _ok(f"SMILES (final): {result.get('prot_smiles', '')}")
    if result.get("pkanet_ranked_csv"):
        _ok(f"pKaNET CSV    : {result['pkanet_ranked_csv']}")


# ── sub-command: dock ─────────────────────────────────────────────────────────

def cmd_dock(args):
    core = _import_core()
    _banner()
    _step("Single-ligand docking")

    out = Path(args.output).resolve()
    out.mkdir(parents=True, exist_ok=True)

    # ── Step 1: Receptor ──────────────────────────────────────────────────────
    _step("Step 1 — Receptor")

    if args.receptor_json:
        with open(args.receptor_json) as fh:
            rec_summary = json.load(fh)
        _ok(f"Using saved receptor: {rec_summary['rec_fh']}")
    else:
        rec_out = out / "receptor"
        rec_out.mkdir(exist_ok=True)

        if os.path.exists(args.receptor):
            raw = os.path.abspath(args.receptor)
        else:
            token   = args.receptor.strip().upper()
            fmt_ext = "cif" if args.fmt.upper() == "CIF" else "pdb"
            raw     = str(rec_out / f"raw.{fmt_ext}")
            _ok(f"Downloading {token} …")
            rc, _ = core.run_cmd(["curl", "-sf",
                                   f"https://files.rcsb.org/download/{token}.{fmt_ext}",
                                   "-o", raw])
            if rc != 0 or not os.path.exists(raw) or os.path.getsize(raw) < 200:
                raw_cif = str(rec_out / "raw.cif")
                rc2, _ = core.run_cmd(["curl", "-sf",
                                        f"https://files.rcsb.org/download/{token}.cif",
                                        "-o", raw_cif])
                if rc2 == 0 and os.path.exists(raw_cif) and os.path.getsize(raw_cif) > 200:
                    raw = raw_cif
                    _warn("PDB unavailable; fell back to CIF")
                else:
                    _err(f"Download failed for {token}")

        manual_xyz = (float(args.cx or 0), float(args.cy or 0), float(args.cz or 0))

        print("⏳  Preparing receptor …")
        rec_result = core.prepare_receptor(
            raw_pdb    = raw,
            wdir       = rec_out,
            center_mode= args.center,
            manual_xyz = manual_xyz,
            prody_sel  = args.sel or "",
            box_size   = (args.bx, args.by, args.bz),
        )
        if not rec_result["success"]:
            _err(f"Receptor prep failed: {rec_result['error']}")

        rec_summary = {
            "rec_fh":              rec_result["rec_fh"],
            "rec_pdbqt":           rec_result["rec_pdbqt"],
            "config_txt":          rec_result["config_txt"],
            "cx": rec_result["cx"], "cy": rec_result["cy"], "cz": rec_result["cz"],
            "sx": rec_result["sx"], "sy": rec_result["sy"], "sz": rec_result["sz"],
            "ligand_pdb_path":     rec_result.get("ligand_pdb_path"),
            "cocrystal_ligand_id": rec_result.get("cocrystal_ligand_id", ""),
        }
        with open(str(rec_out / "receptor_summary.json"), "w") as fh:
            json.dump(rec_summary, fh, indent=2)

        cx, cy, cz = rec_result["cx"], rec_result["cy"], rec_result["cz"]
        _ok(f"Receptor ready — center ({cx:.2f}, {cy:.2f}, {cz:.2f})")
        if rec_result.get("cocrystal_ligand_id"):
            _ok(f"Co-crystal ligand: {rec_result['cocrystal_ligand_id']}")

    rec_pdbqt  = os.path.abspath(rec_summary["rec_pdbqt"])
    config_txt = os.path.abspath(rec_summary["config_txt"])

    # ── Step 2: Vina binary ───────────────────────────────────────────────────
    print("⏳  Checking Vina binary …")
    vina_path, vina_err = core.get_vina_binary()
    if vina_path is None:
        _err(f"Could not get Vina binary: {vina_err}")
    _ok(f"Vina: {vina_path}")

    # ── Step 3: Ligand ────────────────────────────────────────────────────────
    _step("Step 2 — Ligand")

    lig_out   = out / "ligand"
    lig_out.mkdir(exist_ok=True)
    name      = args.name or "LIG"
    ph        = args.ph
    prot_mode = "neutral" if args.neutral else "pkanet"

    if getattr(args, "ligand_file", None):
        print(f"⏳  Preparing {name} from file …")
        lig_result = core.prepare_ligand_from_file(args.ligand_file, name, lig_out)
    else:
        smiles, name = _resolve_ligand(args, name)
        print(f"⏳  Preparing {name} at pH {ph} …")
        lig_result = core.prepare_ligand(
            smiles        = smiles,
            name          = name,
            ph            = ph,
            wdir          = lig_out,
            mode          = prot_mode,
            use_pubchem   = not args.no_pubchem,
            max_tautomers = args.max_tautomers,
            ph_window     = args.ph_window,
        )

    if not lig_result["success"]:
        _err(f"Ligand prep failed: {lig_result['error']}")

    prot_smiles = lig_result.get("prot_smiles", "")
    charge      = int(lig_result.get("net_charge", lig_result.get("charge", 0)))
    _ok(f"Ligand SMILES : {prot_smiles}")
    _ok(f"Formal charge : {charge:+d}")

    # ── Step 4: Optional redocking reference ─────────────────────────────────
    ref_score = None
    if args.redock_smiles:
        _step("Step 2b — Redocking reference")
        pts    = args.redock_smiles.strip().split(None, 1)
        rd_smi = pts[0]
        rd_nm  = pts[1].replace(" ", "_") if len(pts) > 1 else "redock"
        print(f"⏳  Docking reference {rd_nm} …")
        rd_prep = core.prepare_ligand(rd_smi, "redock_" + rd_nm, ph,
                                       lig_out, mode=prot_mode)
        if rd_prep["success"]:
            rd_dock = core.run_vina(
                receptor_pdbqt = rec_pdbqt,
                ligand_pdbqt   = os.path.abspath(rd_prep["pdbqt"]),
                config_txt     = config_txt,
                vina_path      = vina_path,
                exhaustiveness = args.exhaustiveness,
                n_modes        = args.poses,
                energy_range   = int(args.energy_range),
                wdir           = lig_out,
                out_name       = "redock_" + rd_nm,
            )
            if rd_dock["success"] and rd_dock["top_score"] is not None:
                ref_score = rd_dock["top_score"]
                _ok(f"Reference score: {ref_score:.2f} kcal/mol")

    # ── Step 5: Docking ───────────────────────────────────────────────────────
    _step("Step 3 — AutoDock Vina")

    print(f"⏳  Running Vina (exhaustiveness={args.exhaustiveness}) …")
    dock = core.run_vina(
        receptor_pdbqt = rec_pdbqt,
        ligand_pdbqt   = os.path.abspath(lig_result["pdbqt"]),
        config_txt     = config_txt,
        vina_path      = vina_path,
        exhaustiveness = args.exhaustiveness,
        n_modes        = args.poses,
        energy_range   = int(args.energy_range),
        wdir           = out,
        out_name       = name,
    )

    if not dock["success"]:
        _err(f"Vina failed: {dock['error']}\n{dock['log'][:400]}")

    # ── Bond-order fix ────────────────────────────────────────────────────────
    pv_sdf = str(out / f"{name}_pv_ready.sdf")
    if prot_smiles:
        core.fix_sdf_bond_orders(dock["out_sdf"], prot_smiles, pv_sdf)
    if not os.path.exists(pv_sdf) or os.path.getsize(pv_sdf) < 10:
        pv_sdf = dock["out_sdf"]

    # ── Load pose mols for RMSD ───────────────────────────────────────────────
    sdf_src   = pv_sdf if (os.path.exists(pv_sdf) and os.path.getsize(pv_sdf) > 10) \
                else dock["out_sdf"]
    pose_mols = core.load_mols_from_sdf(sdf_src, sanitize=False)
    crystal_pdb = rec_summary.get("ligand_pdb_path") or ""

    # ── Compute RMSD dict for CSV ─────────────────────────────────────────────
    rmsds: dict = {}
    if crystal_pdb and os.path.exists(crystal_pdb):
        for s in dock["scores"]:
            idx = (s["pose"] - 1) if s["pose"] else 0
            if idx < len(pose_mols):
                try:
                    r = core.calc_rmsd_heavy(pose_mols[idx], crystal_pdb)
                    rmsds[s["pose"]] = round(r, 2) if r is not None else None
                except Exception:
                    rmsds[s["pose"]] = None

    # ── Results ───────────────────────────────────────────────────────────────
    _step("Results")
    _print_scores(
        dock["scores"],
        ref_score   = ref_score,
        pose_mols   = pose_mols,
        crystal_pdb = crystal_pdb if crystal_pdb and os.path.exists(crystal_pdb) else None,
        core        = core,
    )

    scores_csv = str(out / f"{name}_scores.csv")
    _write_scores_csv(dock["scores"], scores_csv, lig_name=name, rmsds=rmsds)

    _ok(f"All poses PDBQT : {dock['out_pdbqt']}")
    _ok(f"All poses SDF   : {dock['out_sdf']}")
    if os.path.exists(pv_sdf) and os.path.getsize(pv_sdf) > 10:
        _ok(f"PV-ready SDF    : {pv_sdf}")
    _ok(f"Scores CSV      : {scores_csv}")

    # ── Optional per-pose SDF ─────────────────────────────────────────────────
    if args.save_poses:
        poses_dir = out / "poses"
        poses_dir.mkdir(exist_ok=True)
        for i, mol in enumerate(pose_mols, 1):
            core.write_single_pose(    mol, str(poses_dir / f"{name}_pose{i}.sdf"))
            core.write_single_pose_pdb(mol, str(poses_dir / f"{name}_pose{i}.pdb"))
        _ok(f"Individual poses: {poses_dir}/")

    # ── Optional 2D diagram ───────────────────────────────────────────────────
    if args.diagram:
        _generate_diagram(
            core       = core,
            rec_fh     = rec_summary["rec_fh"],
            pose_sdf   = pv_sdf if os.path.exists(pv_sdf) else dock["out_sdf"],
            smiles     = prot_smiles,
            lig_name   = name,
            best_score = dock["top_score"],
            pose_idx   = 0,
            out        = out,
            cutoff     = args.diagram_cutoff,
        )


# ── sub-command: batch ────────────────────────────────────────────────────────

def cmd_batch(args):
    core = _import_core()
    _banner()
    _step("Batch docking")

    out = Path(args.output).resolve()
    out.mkdir(parents=True, exist_ok=True)

    # ── Receptor ──────────────────────────────────────────────────────────────
    if args.receptor_json:
        with open(args.receptor_json) as fh:
            rec_summary = json.load(fh)
        _ok(f"Loaded receptor: {rec_summary['rec_fh']}")
    else:
        rec_out = out / "receptor"
        rec_out.mkdir(exist_ok=True)

        if os.path.exists(args.receptor):
            raw = os.path.abspath(args.receptor)
        else:
            token = args.receptor.strip().upper()
            raw   = str(rec_out / "raw.pdb")
            _ok(f"Downloading {token} …")
            rc, _ = core.run_cmd(["curl", "-sf",
                                   f"https://files.rcsb.org/download/{token}.pdb",
                                   "-o", raw])
            if rc != 0 or not os.path.exists(raw) or os.path.getsize(raw) < 200:
                _err(f"Download failed for {token}")

        print("⏳  Preparing receptor …")
        rec_result = core.prepare_receptor(
            raw_pdb    = raw,
            wdir       = rec_out,
            center_mode= args.center,
            box_size   = (args.bx, args.by, args.bz),
        )
        if not rec_result["success"]:
            _err(f"Receptor prep failed: {rec_result['error']}")

        rec_summary = {
            "rec_fh":    rec_result["rec_fh"],
            "rec_pdbqt": rec_result["rec_pdbqt"],
            "config_txt": rec_result["config_txt"],
            "ligand_pdb_path": rec_result.get("ligand_pdb_path"),
        }
        _ok("Receptor ready")

    rec_pdbqt   = os.path.abspath(rec_summary["rec_pdbqt"])
    config_txt  = os.path.abspath(rec_summary["config_txt"])
    crystal_pdb = rec_summary.get("ligand_pdb_path") or ""

    # ── Read ligand input ─────────────────────────────────────────────────────
    smiles_pairs: list[tuple[str, str]] = []

    if args.ligands:
        with open(args.ligands) as fh:
            for i, line in enumerate(fh):
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                pts = line.split(None, 1)
                nm  = pts[1].replace(" ", "_") if len(pts) > 1 else f"lig_{i+1}"
                smiles_pairs.append((pts[0], nm))
    elif args.smiles_list:
        for i, entry in enumerate(args.smiles_list):
            pts = entry.strip().split(None, 1)
            nm  = pts[1].replace(" ", "_") if len(pts) > 1 else f"lig_{i+1}"
            smiles_pairs.append((pts[0], nm))
    else:
        _err("Provide --ligands <file.smi>  or  --smiles-list SMILES [SMILES ...]")

    _ok(f"Ligands to dock: {len(smiles_pairs)}")

    # ── Vina binary ───────────────────────────────────────────────────────────
    print("⏳  Checking Vina binary …")
    vina_path, vina_err = core.get_vina_binary()
    if vina_path is None:
        _err(f"Could not get Vina: {vina_err}")

    # ── Optional reference ────────────────────────────────────────────────────
    ref_score = None
    prot_mode = "neutral" if args.neutral else "pkanet"

    if args.redock_smiles:
        pts    = args.redock_smiles.strip().split(None, 1)
        rd_smi = pts[0]
        rd_nm  = pts[1].replace(" ", "_") if len(pts) > 1 else "redock"
        rd_out = out / "redock"
        rd_out.mkdir(exist_ok=True)
        print(f"⏳  Docking reference {rd_nm} …")
        rd_prep = core.prepare_ligand(rd_smi, "redock_" + rd_nm, args.ph, rd_out)
        if rd_prep["success"]:
            rd_dock = core.run_vina(
                receptor_pdbqt = rec_pdbqt,
                ligand_pdbqt   = os.path.abspath(rd_prep["pdbqt"]),
                config_txt     = config_txt,
                vina_path      = vina_path,
                exhaustiveness = args.exhaustiveness,
                n_modes        = args.poses,
                energy_range   = 3,
                wdir           = rd_out,
                out_name       = "redock_" + rd_nm,
            )
            if rd_dock["success"] and rd_dock["top_score"] is not None:
                ref_score = rd_dock["top_score"]
                _ok(f"Reference score: {ref_score:.2f} kcal/mol")

    # ── Main loop ─────────────────────────────────────────────────────────────
    results = []
    n = len(smiles_pairs)

    for i, (smi, nm) in enumerate(smiles_pairs, 1):
        print(f"  [{i}/{n}] {nm}")
        lig_wdir = out / nm
        lig_wdir.mkdir(exist_ok=True)
        try:
            prep = core.prepare_ligand(
                smiles = smi, name = nm, ph = args.ph,
                wdir   = lig_wdir, mode = prot_mode,
            )
            if not prep["success"]:
                results.append({"Name": nm, "SMILES": smi, "Top Score": None,
                                 "Charge": None, "RMSD vs crystal": "",
                                 "Status": f"PREP_FAILED: {prep['error']}"})
                _warn(f"  Prep failed: {prep['error']}")
                continue

            dock = core.run_vina(
                receptor_pdbqt = rec_pdbqt,
                ligand_pdbqt   = os.path.abspath(prep["pdbqt"]),
                config_txt     = config_txt,
                vina_path      = vina_path,
                exhaustiveness = args.exhaustiveness,
                n_modes        = args.poses,
                energy_range   = 3,
                wdir           = lig_wdir,
                out_name       = nm,
            )
            if not dock["success"] or dock["top_score"] is None:
                results.append({"Name": nm, "SMILES": smi, "Top Score": None,
                                 "Charge": prep.get("charge"), "RMSD vs crystal": "",
                                 "Status": "DOCK_FAILED"})
                _warn("  Dock failed")
                continue

            pv_sdf = str(lig_wdir / f"{nm}_pv_ready.sdf")
            core.fix_sdf_bond_orders(dock["out_sdf"],
                                      prep.get("prot_smiles", smi), pv_sdf)
            if not os.path.exists(pv_sdf) or os.path.getsize(pv_sdf) < 10:
                pv_sdf = dock["out_sdf"]

            # RMSD vs crystal for best pose
            rmsd_best = ""
            if crystal_pdb and os.path.exists(crystal_pdb):
                mols = core.load_mols_from_sdf(pv_sdf, sanitize=False)
                if mols:
                    try:
                        r = core.calc_rmsd_heavy(mols[0], crystal_pdb)
                        if r is not None:
                            rmsd_best = round(r, 2)
                    except Exception:
                        pass

            top = dock["top_score"]
            results.append({
                "Name":            nm,
                "SMILES":          smi,
                "Prepared SMILES": prep.get("prot_smiles", ""),
                "Top Score":       top,
                "Charge":          prep.get("charge"),
                "RMSD vs crystal": rmsd_best,
                "Status":          "OK",
                "out_sdf":         dock["out_sdf"],
                "pv_sdf":          pv_sdf,
                "out_pdbqt":       dock["out_pdbqt"],
            })
            label = "✓ Strong" if top < -9 else "✓ Moderate" if top < -7 else "  Weak"
            rmsd_txt = f"  RMSD {rmsd_best} Å" if rmsd_best != "" else ""
            _ok(f"  {label}  {top:.2f} kcal/mol{rmsd_txt}")

        except Exception as exc:
            results.append({"Name": nm, "SMILES": smi, "Top Score": None,
                             "Charge": None, "RMSD vs crystal": "",
                             "Status": f"ERROR: {exc}"})
            _warn(f"  Exception: {exc}")

    # ── Summary ───────────────────────────────────────────────────────────────
    _step("Batch Summary")
    ok_results = sorted([r for r in results if r["Status"] == "OK"],
                        key=lambda r: r["Top Score"])

    if _RICH:
        t = Table(
            title = f"Batch Results  (ref = {ref_score:.2f} kcal/mol)" if ref_score
                    else "Batch Results",
            show_header=True, header_style="bold cyan",
        )
        t.add_column("Rank")
        t.add_column("Name")
        t.add_column("Top Score",       justify="right")
        t.add_column("Δ vs ref",        justify="right")
        t.add_column("RMSD vs crystal", justify="right")
        t.add_column("Charge",          justify="right")
        for rank, r in enumerate(ok_results, 1):
            s     = r["Top Score"]
            aclr  = "green" if s < -9 else "yellow" if s < -7 else "red"
            delta = f"{s - ref_score:+.2f}" if ref_score is not None else "—"
            rmsd  = str(r["RMSD vs crystal"]) if r["RMSD vs crystal"] != "" else "—"
            t.add_row(str(rank), r["Name"], f"[{aclr}]{s:.2f}[/{aclr}]",
                      delta, rmsd, str(r.get("Charge", "?")))
        _con.print(t)
    else:
        print(f"\n{'Rank':>5}  {'Name':<28}  {'Score':>8}  {'Δ ref':>7}  "
              f"{'RMSD':>6}  {'Charge':>6}")
        print("─" * 72)
        for rank, r in enumerate(ok_results, 1):
            s     = r["Top Score"]
            delta = f"{s - ref_score:+.2f}" if ref_score is not None else "—"
            rmsd  = str(r["RMSD vs crystal"]) if r["RMSD vs crystal"] != "" else "—"
            print(f"{rank:>5}  {r['Name']:<28}  {s:>8.2f}  {delta:>7}  "
                  f"{rmsd:>6}  {str(r.get('Charge','?')):>6}")

    csv_path = str(out / "batch_scores.csv")
    with open(csv_path, "w", newline="") as fh:
        fieldnames = ["Name", "SMILES", "Prepared SMILES", "Top Score",
                      "Charge", "RMSD vs crystal", "Status", "out_sdf", "pv_sdf"]
        w = csv.DictWriter(fh, fieldnames=fieldnames, extrasaction="ignore")
        w.writeheader()
        w.writerows(results)

    n_ok = sum(1 for r in results if r["Status"] == "OK")
    _ok(f"Scores CSV  : {csv_path}")
    _ok(f"Completed   : {n_ok}/{n} ligands docked successfully")
    if ref_score is not None and ok_results:
        _ok(f"Better than reference: "
            f"{sum(1 for r in ok_results if r['Top Score'] < ref_score)} ligand(s)")


# ── 2D diagram helper ─────────────────────────────────────────────────────────

def _generate_diagram(core, rec_fh, pose_sdf, smiles, lig_name,
                      best_score, pose_idx, out, cutoff=4.5):
    try:
        title = f"Pose {pose_idx+1}  ·  {lig_name}"
        if best_score is not None:
            title += f"  ·  {best_score:.2f} kcal/mol"
        print("⏳  Generating 2D interaction diagram …")
        svg_bytes = core.draw_interaction_diagram(
            receptor_pdb = rec_fh,
            pose_sdf     = pose_sdf,
            smiles       = smiles,
            title        = title,
            cutoff       = cutoff,
            size         = (800, 759),
            max_residues = 14,
        )
        diag_path = str(out / f"{lig_name}_diagram.svg")
        with open(diag_path, "wb") as fh:
            fh.write(svg_bytes)
        _ok(f"2D diagram SVG: {diag_path}")

        try:
            import cairosvg
            png_bytes = cairosvg.svg2png(bytestring=svg_bytes, scale=2,
                                          background_color="white")
            png_path = str(out / f"{lig_name}_diagram.png")
            with open(png_path, "wb") as fh:
                fh.write(png_bytes)
            _ok(f"2D diagram PNG: {png_path}")
        except ImportError:
            _warn("cairosvg not installed — PNG skipped (pip install cairosvg)")
    except Exception as exc:
        _warn(f"Diagram generation failed: {exc}")


def cmd_diagram(args):
    core = _import_core()
    _step("2D interaction diagram")

    if not os.path.exists(args.receptor):
        _err(f"Receptor PDB not found: {args.receptor}")
    if not os.path.exists(args.pose_sdf):
        _err(f"Pose SDF not found: {args.pose_sdf}")

    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)

    mols = core.load_mols_from_sdf(args.pose_sdf, sanitize=False)
    if not mols:
        _err("No molecules found in SDF file")
    idx = max(0, min(args.pose - 1, len(mols) - 1))

    import tempfile
    with tempfile.NamedTemporaryFile(suffix=".sdf", delete=False) as tf:
        tmp_sdf = tf.name
    core.write_single_pose(mols[idx], tmp_sdf)

    _generate_diagram(
        core       = core,
        rec_fh     = args.receptor,
        pose_sdf   = tmp_sdf,
        smiles     = args.smiles or "",
        lig_name   = args.name or "ligand",
        best_score = args.score,
        pose_idx   = idx,
        out        = out,
        cutoff     = args.cutoff,
    )
    os.unlink(tmp_sdf)


# ── sub-command: redock ──────────────────────────────────────────────────────

def cmd_redock(args):
    """
    Self-docking validation: automatically re-docks the co-crystal ligand that
    is already bound in the input structure, with no ligand input required.

    Pipeline
    --------
    1. Prepare receptor  (extract + remove co-crystal ligand → box centred on it)
    2. Identify ligand   (3-letter residue code from detected HETATM)
    3. Acquire SMILES    (RCSB CCD API  →  CIF _chem_comp.pdbx_smiles  →  3D fallback)
    4. Prepare ligand    (protonation, 3-D conformer, PDBQT)
    5. Dock with Vina
    6. Report RMSD vs crystal pose  (pass ≤ 2.0 Å, borderline ≤ 3.0 Å, fail > 3.0 Å)
    """
    core = _import_core()
    _banner()
    _step("Redocking — self-docking validation")

    out = Path(args.output).resolve()
    out.mkdir(parents=True, exist_ok=True)

    # ── Step 1: Receptor ──────────────────────────────────────────────────
    _step("Step 1 — Receptor preparation")

    raw = ""

    if args.receptor_json:
        with open(args.receptor_json) as fh:
            rec_summary = json.load(fh)
        _ok(f"Using saved receptor : {rec_summary['rec_fh']}")
    else:
        rec_out = out / "receptor"
        rec_out.mkdir(exist_ok=True)

        if os.path.exists(args.receptor):
            raw = os.path.abspath(args.receptor)
        else:
            token   = args.receptor.strip().upper()
            fmt_ext = "cif" if args.fmt.upper() == "CIF" else "pdb"
            raw     = str(rec_out / f"raw.{fmt_ext}")
            _ok(f"Downloading {token} ({fmt_ext.upper()}) from RCSB …")
            rc, _ = core.run_cmd([
                "curl", "-sf",
                f"https://files.rcsb.org/download/{token}.{fmt_ext}",
                "-o", raw,
            ])
            if rc != 0 or not os.path.exists(raw) or os.path.getsize(raw) < 200:
                raw_cif = str(rec_out / "raw.cif")
                rc2, _ = core.run_cmd([
                    "curl", "-sf",
                    f"https://files.rcsb.org/download/{token}.cif",
                    "-o", raw_cif,
                ])
                if rc2 == 0 and os.path.exists(raw_cif) and os.path.getsize(raw_cif) > 200:
                    raw = raw_cif
                    _warn("PDB unavailable; fell back to CIF")
                else:
                    _err(f"Download failed for {token}")

        manual_xyz = (float(args.cx or 0), float(args.cy or 0), float(args.cz or 0))

        print("⏳  Preparing receptor …")
        rec_result = core.prepare_receptor(
            raw_pdb     = raw,
            wdir        = rec_out,
            center_mode = args.center,
            manual_xyz  = manual_xyz,
            prody_sel   = args.sel or "",
            box_size    = (args.bx, args.by, args.bz),
        )
        if not rec_result["success"]:
            _err(f"Receptor preparation failed: {rec_result['error']}")

        rec_summary = {
            "rec_fh":              rec_result["rec_fh"],
            "rec_pdbqt":           rec_result["rec_pdbqt"],
            "config_txt":          rec_result["config_txt"],
            "cx": rec_result["cx"], "cy": rec_result["cy"], "cz": rec_result["cz"],
            "sx": rec_result["sx"], "sy": rec_result["sy"], "sz": rec_result["sz"],
            "ligand_pdb_path":     rec_result.get("ligand_pdb_path"),
            "cocrystal_ligand_id": rec_result.get("cocrystal_ligand_id", ""),
        }
        with open(str(rec_out / "receptor_summary.json"), "w") as fh:
            json.dump(rec_summary, fh, indent=2)

        cx, cy, cz = rec_result["cx"], rec_result["cy"], rec_result["cz"]
        _ok(f"Receptor ready  — center ({cx:.2f}, {cy:.2f}, {cz:.2f})")
        if rec_result.get("cocrystal_ligand_id"):
            _ok(f"Co-crystal detected : {rec_result['cocrystal_ligand_id']}")

    # ── Step 2: Identify co-crystal ligand ───────────────────────────────
    _step("Step 2 — Co-crystal ligand identification")

    ligand_pdb   = rec_summary.get("ligand_pdb_path") or ""
    cocrystal_id = rec_summary.get("cocrystal_ligand_id") or ""

    # Optional manual residue-name override (e.g. --resname DC3)
    if args.resname:
        parts = cocrystal_id.split("_")
        if len(parts) >= 3:
            cocrystal_id = "_".join([args.resname.upper()] + parts[1:])
        else:
            cocrystal_id = args.resname.upper()
        _ok(f"Residue name overridden to : {args.resname.upper()}")

    if not ligand_pdb or not os.path.exists(ligand_pdb):
        _warn("No co-crystal ligand was extracted during receptor preparation.")
        # List what IS in the structure so the user can pick
        try:
            ligands = core.scan_ligands(rec_summary["rec_fh"])
        except Exception:
            ligands = []
        if ligands:
            det = ", ".join(
                f"{l['resname']} chain {l['chain']} resid {l['resid']} "
                f"({l['n_atoms']} atoms)"
                for l in ligands[:6]
            )
            _err(
                f"Detected HETATMs: {det}\n"
                "  Re-run without --receptor-json so the pipeline can extract "
                "the ligand,\n"
                "  or add  --resname <3-letter-code>  together with "
                "--center auto."
            )
        else:
            _err(
                "No drug-like HETATM found in the structure.\n"
                "  Redocking requires a co-crystal ligand (HETATM) in the "
                "input PDB/CIF.\n"
                "  Use  acd dock  to dock a new ligand instead."
            )

    resname = cocrystal_id.split("_")[0].upper() if cocrystal_id else ""
    _ok(f"Co-crystal ligand : {cocrystal_id}")
    _ok(f"Extracted PDB     : {ligand_pdb}")

    # ── Step 3: SMILES acquisition ────────────────────────────────────────
    _step("Step 3 — SMILES acquisition")

    smiles, source, smi_warn = core.get_cocrystal_smiles(
        ligand_pdb_path     = ligand_pdb,
        cocrystal_ligand_id = cocrystal_id,
        raw_pdb             = raw,          # empty when --receptor-json used
    )

    if not smiles:
        _err(
            f"Could not obtain SMILES for '{resname}'.\n"
            f"  Tried: RCSB CCD API  →  CIF _chem_comp.pdbx_smiles  →  "
            f"RDKit/OpenBabel 3D conversion.\n"
            f"  Provide it manually:  acd dock --receptor ... "
            f"--smiles '<SMILES>' --name {resname}"
        )

    _SOURCE_LABELS = {
        "rcsb_ccd":      "RCSB Chemical Component Dictionary (ideal / curated)",
        "cif_block":     "CIF file  _chem_comp.pdbx_smiles",
        "3d_conversion": "3D coordinate conversion — RDKit / OpenBabel  ⚠ verify",
    }
    _ok(f"SMILES source : {_SOURCE_LABELS.get(source, source)}")
    _ok(f"SMILES        : {smiles}")
    if smi_warn:
        _warn(smi_warn)

    # ── Step 4: Vina binary ───────────────────────────────────────────────
    print("⏳  Checking Vina binary …")
    vina_path, vina_err = core.get_vina_binary()
    if vina_path is None:
        _err(f"Could not get Vina binary: {vina_err}")
    _ok(f"Vina : {vina_path}")

    # ── Step 5: Ligand preparation ────────────────────────────────────────
    _step("Step 4 — Ligand preparation")

    name      = args.name or resname or "REDOCK"
    ph        = args.ph
    prot_mode = "neutral" if args.neutral else "pkanet"
    lig_out   = out / "ligand"
    lig_out.mkdir(exist_ok=True)

    print(f"⏳  Preparing {name} at pH {ph} …")
    lig_result = core.prepare_ligand(
        smiles        = smiles,
        name          = name,
        ph            = ph,
        wdir          = lig_out,
        mode          = prot_mode,
        use_pubchem   = not args.no_pubchem,
        max_tautomers = args.max_tautomers,
        ph_window     = args.ph_window,
    )

    if not lig_result["success"]:
        _err(f"Ligand preparation failed: {lig_result['error']}")

    prot_smiles = lig_result.get("prot_smiles", "")
    charge      = int(lig_result.get("net_charge", lig_result.get("charge", 0)))
    _ok(f"Prepared SMILES : {prot_smiles}")
    _ok(f"Formal charge   : {charge:+d}")
    if lig_result.get("pkanet_ranked_csv"):
        _ok(f"pKaNET CSV      : {lig_result['pkanet_ranked_csv']}")

    # ── Step 6: AutoDock Vina ─────────────────────────────────────────────
    _step("Step 5 — AutoDock Vina")

    rec_pdbqt  = os.path.abspath(rec_summary["rec_pdbqt"])
    config_txt = os.path.abspath(rec_summary["config_txt"])

    print(f"⏳  Running Vina (exhaustiveness={args.exhaustiveness}) …")
    dock = core.run_vina(
        receptor_pdbqt = rec_pdbqt,
        ligand_pdbqt   = os.path.abspath(lig_result["pdbqt"]),
        config_txt     = config_txt,
        vina_path      = vina_path,
        exhaustiveness = args.exhaustiveness,
        n_modes        = args.poses,
        energy_range   = int(args.energy_range),
        wdir           = out,
        out_name       = name,
    )

    if not dock["success"]:
        _err(f"Vina failed: {dock['error']}\n{dock['log'][:400]}")

    # ── Bond-order fix ────────────────────────────────────────────────────
    pv_sdf = str(out / f"{name}_pv_ready.sdf")
    if prot_smiles:
        core.fix_sdf_bond_orders(dock["out_sdf"], prot_smiles, pv_sdf)
    if not os.path.exists(pv_sdf) or os.path.getsize(pv_sdf) < 10:
        pv_sdf = dock["out_sdf"]

    # ── Load pose molecules ───────────────────────────────────────────────
    sdf_src   = (pv_sdf if (os.path.exists(pv_sdf) and
                             os.path.getsize(pv_sdf) > 10)
                 else dock["out_sdf"])
    pose_mols = core.load_mols_from_sdf(sdf_src, sanitize=False)

    # ── RMSD vs crystal pose ──────────────────────────────────────────────
    rmsds: dict = {}
    if ligand_pdb and os.path.exists(ligand_pdb):
        for s in dock["scores"]:
            idx = (s["pose"] - 1) if s["pose"] else 0
            if idx < len(pose_mols):
                try:
                    r = core.calc_rmsd_heavy(pose_mols[idx], ligand_pdb)
                    rmsds[s["pose"]] = round(r, 2) if r is not None else None
                except Exception:
                    rmsds[s["pose"]] = None

    # ── Score table ───────────────────────────────────────────────────────
    _step("Results")
    _print_scores(
        dock["scores"],
        ref_score   = None,
        pose_mols   = pose_mols,
        crystal_pdb = ligand_pdb if (ligand_pdb and os.path.exists(ligand_pdb)) else None,
        core        = core,
    )

    # ── Redocking verdict ─────────────────────────────────────────────────
    if rmsds:
        best_rmsd = rmsds.get(dock["scores"][0]["pose"])
        if best_rmsd is not None:
            if best_rmsd <= 2.0:
                clr     = "green"
                verdict = "✓ PASS"
                detail  = f"{best_rmsd:.2f} Å ≤ 2.0 Å — docking protocol validated"
            elif best_rmsd <= 3.0:
                clr     = "yellow"
                verdict = "⚠ BORDERLINE"
                detail  = f"{best_rmsd:.2f} Å  (2–3 Å, acceptable for flexible loops)"
            else:
                clr     = "red"
                verdict = "✗ FAIL"
                detail  = f"{best_rmsd:.2f} Å > 3.0 Å — pose differs from crystal"

            if _RICH:
                _con.print(
                    f"\n  Redocking verdict : "
                    f"[bold {clr}]{verdict}[/bold {clr}]  —  {detail}\n"
                )
            else:
                print(f"\n  Redocking verdict : {verdict}  —  {detail}\n")

    # ── CSV output ────────────────────────────────────────────────────────
    scores_csv = str(out / f"{name}_redock_scores.csv")
    _write_scores_csv(dock["scores"], scores_csv, lig_name=name, rmsds=rmsds)

    # ── File summary ──────────────────────────────────────────────────────
    _ok(f"All poses PDBQT : {dock['out_pdbqt']}")
    _ok(f"All poses SDF   : {dock['out_sdf']}")
    if os.path.exists(pv_sdf) and os.path.getsize(pv_sdf) > 10:
        _ok(f"PV-ready SDF    : {pv_sdf}")
    _ok(f"Crystal ligand  : {ligand_pdb}")
    _ok(f"Scores CSV      : {scores_csv}")
    _ok(f"SMILES source   : {source}")

    # ── Optional per-pose SDF ─────────────────────────────────────────────
    if args.save_poses:
        poses_dir = out / "poses"
        poses_dir.mkdir(exist_ok=True)
        for i, mol in enumerate(pose_mols, 1):
            core.write_single_pose(    mol, str(poses_dir / f"{name}_pose{i}.sdf"))
            core.write_single_pose_pdb(mol, str(poses_dir / f"{name}_pose{i}.pdb"))
        _ok(f"Individual poses : {poses_dir}/")

    # ── Optional 2D diagram ───────────────────────────────────────────────
    if args.diagram:
        _generate_diagram(
            core       = core,
            rec_fh     = rec_summary["rec_fh"],
            pose_sdf   = pv_sdf if os.path.exists(pv_sdf) else dock["out_sdf"],
            smiles     = prot_smiles,
            lig_name   = name,
            best_score = dock["top_score"],
            pose_idx   = 0,
            out        = out,
            cutoff     = args.diagram_cutoff,
        )


# ── argument parser ───────────────────────────────────────────────────────────

def _add_receptor_args(p):
    p.add_argument("--receptor",      metavar="PDB_ID_or_FILE",
                   help="4-letter PDB ID (auto-downloaded) or path to .pdb/.cif file")
    p.add_argument("--receptor-json", metavar="PATH",
                   help="JSON from a previous  acd receptor  run (skips re-prep)")
    p.add_argument("--fmt",    default="PDB", choices=["PDB", "CIF"])
    p.add_argument("--center", default="auto",
                   choices=["auto", "manual", "selection"])
    p.add_argument("--cx", type=float, help="X centre (--center manual)")
    p.add_argument("--cy", type=float, help="Y centre (--center manual)")
    p.add_argument("--cz", type=float, help="Z centre (--center manual)")
    p.add_argument("--sel", metavar="PRODY_SEL",
                   help="ProDy selection string (--center selection)")
    p.add_argument("--bx", type=int, default=20, help="Box X size Å (default: 20)")
    p.add_argument("--by", type=int, default=20, help="Box Y size Å (default: 20)")
    p.add_argument("--bz", type=int, default=20, help="Box Z size Å (default: 20)")


def _add_ligand_args(p):
    p.add_argument("--smiles",        metavar="SMILES",
                   help="Ligand SMILES string")
    p.add_argument("--compound",      metavar="NAME",
                   help="Compound name to search on PubChem (e.g. baicalein, erlotinib)")
    p.add_argument("--ligand-file",   metavar="PATH",
                   help="Ligand structure file (.sdf/.mol2/.pdb)")
    p.add_argument("--name",          default="LIG",
                   help="Ligand output name (default: LIG)")
    p.add_argument("--ph",            type=float, default=7.4,
                   help="Target pH (default: 7.4)")
    p.add_argument("--pkanet",        action="store_true", default=True,
                   help="Use pKaNET Cloud+ protonation (default)")
    p.add_argument("--neutral",       action="store_true",
                   help="Neutral mode: keep input charge, add H only")
    p.add_argument("--no-pubchem",    action="store_true",
                   help="Skip PubChem pKa lookup")
    p.add_argument("--max-tautomers", type=int, default=8, metavar="N")
    p.add_argument("--ph-window",     type=float, default=1.0)


def _add_vina_args(p):
    p.add_argument("-e", "--exhaustiveness", type=int, default=16, metavar="N",
                   help="Vina exhaustiveness (default: 16)")
    p.add_argument("-n", "--poses",          type=int, default=10, metavar="N",
                   help="Max poses to output (default: 10)")
    p.add_argument("--energy-range",         type=float, default=3.0, metavar="KCAL",
                   help="Energy range above best pose (default: 3.0)")


def build_parser() -> argparse.ArgumentParser:
    root = argparse.ArgumentParser(
        prog="acd",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    root.add_argument("--version", action="version", version="%(prog)s (anyonecandock)")
    sub = root.add_subparsers(dest="command", required=True)

    # ── dock ──────────────────────────────────────────────────────────────────
    p_dock = sub.add_parser(
        "dock",
        help="Full pipeline: receptor → ligand → Vina → results",
        description=textwrap.dedent("""\
            End-to-end single-ligand docking.

            Examples
            --------
              acd dock --receptor 1M17 --smiles "CCO" --name ethanol
              acd dock --receptor 1M17 --compound baicalein
              acd dock --receptor receptor.pdb --ligand-file ligand.sdf --name mylig
              acd dock --receptor-json ./rec/receptor_summary.json --compound erlotinib
        """),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_receptor_args(p_dock)
    _add_ligand_args(p_dock)
    _add_vina_args(p_dock)
    p_dock.add_argument("-o", "--output",        default="./acd_results")
    p_dock.add_argument("--redock-smiles",        metavar="'SMILES [name]'")
    p_dock.add_argument("--save-poses",           action="store_true")
    p_dock.add_argument("--diagram",              action="store_true")
    p_dock.add_argument("--diagram-cutoff",       type=float, default=4.5, metavar="Å")

    # ── batch ─────────────────────────────────────────────────────────────────
    p_batch = sub.add_parser(
        "batch",
        help="Batch docking from a .smi file or SMILES list",
        description=textwrap.dedent("""\
            Examples
            --------
              acd batch --receptor 1M17 --ligands compounds.smi
              acd batch --receptor 4AGN --smiles-list "CCO ethanol" "c1ccccc1O phenol"
        """),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_receptor_args(p_batch)
    _add_vina_args(p_batch)
    p_batch.add_argument("--ph",           type=float, default=7.4)
    p_batch.add_argument("--pkanet",       action="store_true", default=True)
    p_batch.add_argument("--neutral",      action="store_true")
    p_batch.add_argument("--ligands",      metavar="FILE.smi")
    p_batch.add_argument("--smiles-list",  nargs="+", metavar="'SMILES [name]'")
    p_batch.add_argument("--redock-smiles", metavar="'SMILES [name]'")
    p_batch.add_argument("-o", "--output", default="./acd_batch")

    # ── receptor ──────────────────────────────────────────────────────────────
    p_rec = sub.add_parser("receptor", help="Prepare receptor only")
    p_rec.add_argument("--pdb",    metavar="PDB_ID")
    p_rec.add_argument("--file",   metavar="PATH")
    p_rec.add_argument("--fmt",    default="PDB", choices=["PDB", "CIF"])
    p_rec.add_argument("--center", default="auto",
                       choices=["auto", "manual", "selection"])
    p_rec.add_argument("--cx", type=float)
    p_rec.add_argument("--cy", type=float)
    p_rec.add_argument("--cz", type=float)
    p_rec.add_argument("--sel", metavar="PRODY_SEL")
    p_rec.add_argument("--bx", type=int, default=20)
    p_rec.add_argument("--by", type=int, default=20)
    p_rec.add_argument("--bz", type=int, default=20)
    p_rec.add_argument("-o", "--output", default="./acd_receptor")

    # ── ligand ────────────────────────────────────────────────────────────────
    p_lig = sub.add_parser("ligand", help="Prepare ligand only")
    _add_ligand_args(p_lig)
    p_lig.add_argument("--file", metavar="PATH")
    p_lig.add_argument("-o", "--output", default="./acd_ligand")

    # ── diagram ───────────────────────────────────────────────────────────────
    p_diag = sub.add_parser("diagram", help="Generate 2D interaction diagram")
    p_diag.add_argument("--receptor", required=True, metavar="PATH")
    p_diag.add_argument("--pose-sdf", required=True, metavar="PATH")
    p_diag.add_argument("--smiles",   metavar="SMILES")
    p_diag.add_argument("--name",     default="ligand")
    p_diag.add_argument("--pose",     type=int, default=1)
    p_diag.add_argument("--score",    type=float)
    p_diag.add_argument("--cutoff",   type=float, default=4.5)
    p_diag.add_argument("-o", "--output", default="./acd_diagram")

    # ── redock ────────────────────────────────────────────────────────────────
    p_redock = sub.add_parser(
        "redock",
        help="Self-docking validation: re-dock the co-crystal ligand automatically",
        description=textwrap.dedent("""\
            Automatically re-docks the co-crystal ligand already present in the
            input PDB/CIF — no SMILES or compound name required.

            SMILES acquisition (in priority order):
              1. RCSB Chemical Component Dictionary API (ideal, stereo-correct)
              2. _chem_comp.pdbx_smiles field in the CIF file
              3. 3D→SMILES conversion from the extracted LIG.pdb (fallback, ⚠ verify)

            A RMSD vs the original crystal pose is computed for every docked pose.
            Verdict: PASS ≤ 2.0 Å  |  BORDERLINE ≤ 3.0 Å  |  FAIL > 3.0 Å

            Examples
            --------
              acd redock --receptor 4AGN
              acd redock --receptor structure.cif --fmt CIF
              acd redock --receptor 4AGN --resname DC3 --name DC3 --diagram
              acd redock --receptor-json ./rec/receptor_summary.json
        """),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    # receptor args (reuse helper, but make --receptor optional when --receptor-json used)
    p_redock.add_argument("--receptor",      metavar="PDB_ID_or_FILE",
                          help="4-letter PDB ID (auto-downloaded) or path to .pdb/.cif")
    p_redock.add_argument("--receptor-json", metavar="PATH",
                          help="JSON from a previous  acd receptor  run (skips re-prep)")
    p_redock.add_argument("--fmt",    default="PDB", choices=["PDB", "CIF"])
    p_redock.add_argument("--center", default="auto",
                          choices=["auto", "manual", "selection"])
    p_redock.add_argument("--cx", type=float)
    p_redock.add_argument("--cy", type=float)
    p_redock.add_argument("--cz", type=float)
    p_redock.add_argument("--sel", metavar="PRODY_SEL")
    p_redock.add_argument("--bx", type=int, default=20)
    p_redock.add_argument("--by", type=int, default=20)
    p_redock.add_argument("--bz", type=int, default=20)
    # redock-specific
    p_redock.add_argument("--resname",  metavar="3-LETTER-CODE",
                          help="Override the auto-detected ligand residue name "
                               "(e.g. DC3, ATP).  Useful when multiple HETATMs "
                               "are present or when using --receptor-json.")
    # ligand / protonation args
    p_redock.add_argument("--name",          default="",
                          help="Output name for redocked ligand (default: residue code)")
    p_redock.add_argument("--ph",            type=float, default=7.4)
    p_redock.add_argument("--neutral",       action="store_true")
    p_redock.add_argument("--no-pubchem",    action="store_true")
    p_redock.add_argument("--max-tautomers", type=int,   default=8)
    p_redock.add_argument("--ph-window",     type=float, default=1.0)
    # vina args
    _add_vina_args(p_redock)
    # output / extras
    p_redock.add_argument("-o", "--output",      default="./acd_redock")
    p_redock.add_argument("--save-poses",        action="store_true")
    p_redock.add_argument("--diagram",           action="store_true")
    p_redock.add_argument("--diagram-cutoff",    type=float, default=4.5, metavar="Å")

    return root


def main():
    parser = build_parser()
    args   = parser.parse_args()

    dispatch = {
        "dock":     cmd_dock,
        "batch":    cmd_batch,
        "receptor": cmd_receptor,
        "ligand":   cmd_ligand,
        "diagram":  cmd_diagram,
        "redock":   cmd_redock,
    }
    fn = dispatch.get(args.command)
    if fn is None:
        parser.print_help()
        sys.exit(1)

    try:
        fn(args)
    except KeyboardInterrupt:
        print("\nInterrupted.")
        sys.exit(130)


if __name__ == "__main__":
    main()