# anyone can dock — CLI

Molecular docking from the command line, powered by **AutoDock Vina 1.2.7**, **pKaNET Cloud+**, and **RDKit**.

## Installation

### System dependencies (Ubuntu / Debian)

```bash
sudo apt-get install -y openbabel libopenbabel-dev \
  libcairo2-dev libpango1.0-dev libpangocairo-1.0-0
```

### pip (recommended)

```bash
# 1. clone the repository
git clone https://github.com/nyelidl/anyone-docking.git
cd anyone-docking

# 2. install in editable mode  (add [all] for ADMET-AI + PNG export)
pip install -e .
pip install -e ".[all]"
```

### conda

```bash
conda create -n acd python=3.11 -y
conda activate acd

# system libs via conda-forge
conda install -c conda-forge openbabel cairosvg rdkit prody -y

# package itself
pip install -e .
```

After installation the `acd` command is available in your shell.

---

## Commands

```
acd --help
acd dock     --help
acd batch    --help
acd receptor --help
acd ligand   --help
acd diagram  --help
```

---

## Quick examples

### 1. Full single-ligand docking (PDB ID + SMILES)

```bash
acd dock \
  --receptor 1M17 \
  --smiles "COCCOC1=C(C=C2C(=C1)C(=NC=N2)NC3=CC=CC(=C3)C#C)OCCOC" \
  --name erlotinib \
  --ph 7.4 \
  --exhaustiveness 16 \
  --output ./erlotinib_dock
```

Output in `./erlotinib_dock/`:
```
receptor/rec.pdb
receptor/rec.pdbqt
receptor/receptor_summary.json
ligand/erlotinib.pdbqt
erlotinib_out.pdbqt      ← all poses
erlotinib_out.sdf
erlotinib_pv_ready.sdf   ← bond-order corrected
erlotinib_scores.csv
```

### 2. Add 2D interaction diagram and save per-pose files

```bash
acd dock \
  --receptor 1M17 \
  --smiles "COCCOC1=C(C=C2C(=C1)C(=NC=N2)NC3=CC=CC(=C3)C#C)OCCOC" \
  --name erlotinib \
  --diagram \
  --save-poses \
  --output ./erlotinib_full
```

### 3. Use a local PDB/CIF file

```bash
acd dock \
  --receptor my_homology_model.pdb \
  --smiles "CCc1nn(C)c2cc(-c3cncnc3Nc3cccc(S(N)(=O)=O)c3)ccc12" \
  --name compound_1 \
  --center manual --cx 14.2 --cy -3.8 --cz 22.1 \
  --bx 22 --by 22 --bz 22
```

### 4. Batch docking from a .smi file

```bash
# compounds.smi: one "SMILES name" per line
cat > compounds.smi << 'EOF'
O=c1cc(-c2ccc(O)cc2)oc2cc(O)cc(O)c12 Apigenin
O=c1cc(-c2ccccc2)oc2cc(O)c(O)c(O)c12 Baicalein
COCCOC1=C(C=C2C(=C1)C(=NC=N2)NC3=CC=CC(=C3)C#C)OCCOC Erlotinib
EOF

acd batch \
  --receptor 1M17 \
  --ligands compounds.smi \
  --ph 7.4 \
  --exhaustiveness 8 \
  --redock-smiles "COCCOC1=C(C=C2C(=C1)C(=NC=N2)NC3=CC=CC(=C3)C#C)OCCOC Erlotinib" \
  --output ./batch_egfr
```

Output `./batch_egfr/batch_scores.csv`:
```
Name,SMILES,Prepared SMILES,Top Score,Charge,Status,...
Erlotinib,...,-9.12,0,OK,...
Apigenin,...,-8.44,0,OK,...
Baicalein,...,-8.01,0,OK,...
```

### 5. Prepare receptor once, re-use for many batch runs

```bash
# Step A — prepare receptor (saved as JSON)
acd receptor --pdb 1M17 --output ./rec_1m17

# Step B — batch with saved receptor (no re-download or re-prep)
acd batch \
  --receptor-json ./rec_1m17/receptor_summary.json \
  --ligands library.smi \
  --output ./screen_run_1
```

### 6. Stand-alone 2D diagram for an existing docking result

```bash
acd diagram \
  --receptor ./rec_1m17/receptor/rec.pdb \
  --pose-sdf  ./erlotinib_dock/erlotinib_pv_ready.sdf \
  --smiles "COCCOC1=C(C=C2C(=C1)C(=NC=N2)NC3=CC=CC(=C3)C#C)OCCOC" \
  --name erlotinib \
  --pose 1 \
  --score -9.4 \
  --output ./diagrams
```

---

## Programmatic use (Python API)

```python
from anyonecandock import (
    prepare_receptor,
    prepare_ligand,
    run_vina,
    get_vina_binary,
    fix_sdf_bond_orders,
    draw_interaction_diagram,
)
from pathlib import Path

wdir = Path("./my_run")
wdir.mkdir(exist_ok=True)

# 1. Receptor
rec = prepare_receptor(
    raw_pdb="1M17.pdb",
    wdir=wdir,
    center_mode="auto",
    box_size=(20, 20, 20),
)

# 2. Ligand
lig = prepare_ligand(
    smiles="COCCOC1=C(...)OCCOC",
    name="erlotinib",
    ph=7.4,
    wdir=wdir,
    mode="pkanet",
)

# 3. Vina
vina, _ = get_vina_binary()
dock = run_vina(
    receptor_pdbqt=rec["rec_pdbqt"],
    ligand_pdbqt=lig["pdbqt"],
    config_txt=rec["config_txt"],
    vina_path=vina,
    exhaustiveness=16,
    n_modes=10,
    energy_range=3,
    wdir=wdir,
    out_name="erlotinib",
)
print(f"Best score: {dock['top_score']:.2f} kcal/mol")

# 4. 2D diagram
svg = draw_interaction_diagram(
    receptor_pdb=rec["rec_fh"],
    pose_sdf=dock["out_sdf"],
    smiles=lig["prot_smiles"],
    title="Erlotinib · 1M17",
)
Path("diagram.svg").write_bytes(svg)
```

---

## Environment variables

| Variable | Default | Effect |
|---|---|---|
| `VINA_PATH` | auto-downloaded | Point to a custom Vina binary |
| `ACD_WORKDIR` | temp dir per run | Persistent working directory |

---

## Optional extras

| Feature | Install |
|---|---|
| PNG export for diagrams | `pip install cairosvg` |
| ADMET predictions | `pip install admet-ai` |
| Pretty terminal tables | `pip install rich` |
| ML pKa backend | `pip install pkasolver` |

---

## Citation

If you use Anyone Can Dock in your research, please cite:

> Hengphasatporn et al. *J. Chem. Inf. Model.* 2026 — DFDD  
> Eberhardt et al. *J. Chem. Inf. Model.* 2021, 61, 3891–3898 — AutoDock Vina 1.2.7
