# autoplay-l7

Playwright automation scaffold installer for L7 projects.

## Installation

```bash
pip install autoplay-l7
```

## Usage

Inside your project root, run:

```bash
autoplay init
```

### Behavior

- If `tests/` **exists** → installs scaffold into `tests/automation/`
- If `tests/automation/` **already exists** → merges scaffold files into it (existing files are not deleted)
- If no `tests/` folder exists → creates `tests/automation/` with the full scaffold

### Options

```
autoplay init [--target DIR]

  --target DIR   Project root to install into (default: current directory)
```

### Example

```bash
cd my-project/
autoplay init
# → tests/automation/ is created or updated
```

## What gets installed

```
tests/automation/
├── conftest.py
├── pytest.ini
├── requirements.txt
├── playwright.sh
├── utils/
│   ├── commands.py
│   ├── networks.py
│   └── utility_functions.py
├── pages/
│   ├── base_page.py
│   ├── homepage.py
│   └── ...
├── e2e/
│   ├── base_tc.py
│   ├── placeholder/
│   └── Test case Templates/
└── fixtures/
    └── index_seed.yml
```

## Running tests

```bash
cd tests/automation/
./playwright.sh -t "e2e/placeholder/placeholder.py"
```

For Docker mode:

```bash
./playwright.sh -t "e2e/placeholder/placeholder.py" -D
```
