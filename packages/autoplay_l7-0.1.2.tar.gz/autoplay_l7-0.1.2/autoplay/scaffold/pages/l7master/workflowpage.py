import os,re, sys, allure, time
from calendar import monthrange
from datetime import datetime
from playwright.sync_api import Page, expect
from pages.mes_page import MESPage
from utils.networks import Networking
import pytest_check as check

class Workflowpage:
    
    def __init__(self,page):
        self.page = page
        self.submit_button = self.page.get_by_role("button", name="Submit", exact=True)
        self.span = self.page.locator(".rounded-sm.table-normal > .body").first
        self.attach_file_button = page.get_by_role("button", name="Attach File")
        self.save_button = page.get_by_role("button", name="Save")
        self.done_button = page.get_by_role("button", name="Done")
        self.transact_reagent_a="TransAct Reagent A"
        self.transact_reagent_b="TransAct Reagent B"
        self.l7_master = "L7|Master"
        self.xpath_ancestor_block_content = "xpath=ancestor::div[contains(@class, 'block-content')]"
        self.div_draw_toggler = "div.drawer-toggler"
    
    @allure.step("Entering value '{value}' in field '{label_text}'")
    def set_free_text_value(self, label_text: str, value: str):
        label = self.page.get_by_text(label_text, exact=True)
        label.wait_for(state="visible", timeout=5000)
        container = label.locator("../..")
        input_box = container.locator("input[type='text']:not([data-v-bf3f5926])").first
        input_box.wait_for(state="visible", timeout=5000)
        input_box.click()
        input_box.click(click_count=3)
        input_box.type(value)
        actual_value = input_box.input_value().strip()
        check.equal(actual_value, value, f"Value filled in '{label_text}' should be '{value}'")
        allure.attach(actual_value, name=f"Field '{label_text}' value", attachment_type=allure.attachment_type.TEXT)

    @allure.step("Set numeric value '{value}' in field '{label_text}'")
    def set_numeric_value(self, label_text: str, value: str, unit: str = None):
        label = self.page.locator(f"label:has-text('{label_text}')").first
        label.wait_for(state="visible", timeout=5000)
        container = label.locator("xpath=ancestor::div[contains(@class, 'form-field')]")
        container.wait_for(state="visible", timeout=5000)

        input_box = container.locator("input[type='text']").first
        input_box.scroll_into_view_if_needed()
        input_box.wait_for(state="visible", timeout=5000)
        input_box.fill(str(value))

        if unit:
            unit_element = input_box.locator("xpath=following-sibling::div[1]")
            if unit_element.count() == 0:
                unit_element = container.locator(f"xpath=.//div[normalize-space(text())='{unit}']").first
            unit_element.wait_for(state="attached", timeout=5000)

            actual_unit = unit_element.inner_text().strip().replace("\u00a0", " ").replace("\n", "")
            expected_unit = unit.strip().replace("\u00a0", " ").replace("\n", "")

            #expect(unit_element).to_have_text(expected_unit)

            check.equal(actual_unit, expected_unit,f"Field '{label_text}' should have unit '{expected_unit}'")
            allure.attach(f"Numeric value: {value} {actual_unit}",name=f"Field '{label_text}' value with unit",
                attachment_type=allure.attachment_type.TEXT)
        return self

    @allure.step("Select outdated date: Month {month}, Day {day}, Picker Index {index}")
    def outdated_date(self, month: int, day: int, index: int = 0):
        if day <= monthrange(2025, month)[1]:
            date_input = self.page.locator("input.flatpickr-input[data-input='true']").nth(index)
            date_input.click()
            active_calendar = self.page.locator('.flatpickr-calendar.open').last
            active_calendar.locator('.flatpickr-monthDropdown-months').select_option(str(month))
            active_calendar.locator(f'.flatpickr-day:has-text("{day}")').first.click()
            self.page.locator("body").click()
            self.page.wait_for_timeout(1000)
            selected_date = date_input.input_value()
            allure.attach(selected_date, name=f"Selected outdated date (picker {index})", attachment_type=allure.attachment_type.TEXT)
        else:
            raise ValueError(f"Invalid day: {day} for month: {month}")


    @allure.step("Set calibration due date")
    def set_calibration_due_date(self, index: int = 0, date_format: str = "MMM YYYY", target_date: datetime = None):
        date_to_select = target_date or datetime.now()
        target_day = date_to_select.day
        target_month = date_to_select.month - 1  # 0-based index for dropdown
        target_year = date_to_select.year

        date_input = self.page.locator("input.flatpickr-input[data-input='true']").nth(index)
        date_input.click()

        active_calendar = self.page.locator(".flatpickr-calendar.open").last
        active_calendar.wait_for(state="visible")

        month_dropdown = active_calendar.locator(".flatpickr-monthDropdown-months")
        year_input = active_calendar.locator(".numInput.cur-year")

        if month_dropdown.is_visible() and year_input.is_visible():
            month_dropdown.select_option(str(target_month))
            year_input.fill(str(target_year))
            year_input.press("Enter")  # Confirm the year change

        else:
            while True:
                current_month_text = active_calendar.locator(".cur-month").inner_text().strip()
                current_year_text = active_calendar.locator(".numInput.cur-year").input_value().strip()
                current_month = datetime.strptime(current_month_text, "%b").month
                current_year = int(current_year_text)

                if current_month == date_to_select.month and current_year == target_year:
                    break

                if (current_year, current_month) < (target_year, date_to_select.month):
                    active_calendar.locator(".flatpickr-next-month").click()
                else:
                    active_calendar.locator(".flatpickr-prev-month").click()

        day_selector = f'.flatpickr-day:not(.prevMonthDay):not(.nextMonthDay):has-text("{target_day}")'
        active_calendar.locator(day_selector).first.click()

        selected_date = date_input.input_value().strip()
        if date_format == "MMM YYYY":
            expected_format = date_to_select.strftime("%b %Y")
        elif date_format == "DD MMM YYYY":
            expected_format = date_to_select.strftime("%d %b %Y")
        else:
            raise ValueError("date_format must be 'MMM YYYY' or 'DD MMM YYYY'")

        check.is_true(expected_format in selected_date, f"Expected '{expected_format}', got '{selected_date}'")
        
        allure.attach(f"Selected: {selected_date}\nExpected format: {expected_format}",name=f"Calibration due date (Field {index + 1})",
            attachment_type=allure.attachment_type.TEXT)


    @allure.step("Complete and save step")
    def complete_save(self):
        complete_button = self.page.get_by_text("Complete")
        complete_button.click()
        container = complete_button.locator("..")  
        checkbox = container.get_by_role("checkbox")
        checkbox.wait_for(state="visible", timeout=500) 
        checkbox.check()
        self.page.get_by_role("button", name="Save").click()
        return self

    @allure.step("Verify field '{field_name}' auto-filled and optionally update with new value '{new_value}'")
    def verify_and_update_field(self, field_name: str, new_value: str = None, field_type: str = "text"):
        label = self.page.get_by_text(field_name, exact=True)
        label.wait_for(state="visible", timeout=5000)
        if field_type == "select":
            field_locator = label.locator("xpath=following::select[1]")
        else:
            field_locator = label.locator("xpath=following::input[@type='text'][1]")
        field_locator.wait_for(state="visible", timeout=5000)
        expect(field_locator).to_be_visible()
        field_locator.click()
        if field_type == "select":
            original_value = field_locator.input_value() or field_locator.text_content()
        else:
            original_value = field_locator.input_value()
        check.is_true(original_value.strip() != "", f"Expected '{field_name}' to be auto-filled, got empty")
        if field_type == "date":
            date_pattern = r'^[A-Za-z]{3}\s\d{4}$'
            check.is_true(re.match(date_pattern, original_value.strip()), f"Expected '{field_name}' in 'MMM YYYY' format, got '{original_value}'")
        expect(field_locator).to_be_enabled()
        if new_value is not None and field_type != "date":
            if field_type == "select":
                field_locator.select_option(value=new_value)
            else:
                field_locator.clear()
                field_locator.fill(new_value)
            updated_value = field_locator.input_value()
            check.equal(updated_value, new_value, f"'{field_name}' updated value should be '{new_value}'")
            allure.attach(f"Original: {original_value}, Updated: {updated_value}", name=f"Field '{field_name}' update", attachment_type=allure.attachment_type.TEXT)
            return {"original": original_value, "updated": updated_value}
        allure.attach(original_value, name=f"Field '{field_name}' value", attachment_type=allure.attachment_type.TEXT)
        return {"original": original_value, "updated": original_value}

    @allure.step("Select current date in date picker and verify format DD MMM YYYY, hh:mm CT")
    def select_current_date(self, picker_index, expected_formats="DD MMM YYYY, hh:mm CT"):
        regex_formats = [
        r'^\d{2}\s[A-Za-z]{3}\s\d{4},\s\d{2}:\d{2}\sCT$',  # 25 Dec 2024, 14:30 CT
        r'^\d{2}\s[A-Za-z]{3}\s\d{4}\s\d{2}:\d{2}\sCT$',   # 25 Dec 2024 14:30 CT
        r'^\d{2}/\d{2}/\d{4},\s\d{2}:\d{2}\sCT$']       # 25/12/2024, 14:30 CT

        now = datetime.now()
        input_locator = self.page.locator('input.flatpickr-input').nth(picker_index)
        
        input_locator.click()
        active_calendar = self.page.locator('.flatpickr-calendar.open').last
        active_calendar.locator('.flatpickr-monthDropdown-months').select_option(str(now.month - 1))
        active_calendar.locator('.numInput.cur-year').fill(str(now.year))
        active_calendar.locator('.flatpickr-day.today').click()
        self.page.keyboard.press('Enter')
        
        self.page.wait_for_timeout(1000)
        populated_value = input_locator.input_value()
        
        format_matched = any(re.match(pattern, populated_value) for pattern in regex_formats)
        check.is_true(format_matched,
                    f"Date picker {picker_index} format is incorrect. Expected format: '{expected_formats}'. Got: '{populated_value}'")
        
        allure.attach(f"Selected value: {populated_value}\nExpected format: {expected_formats}",name=f"Date picker {picker_index} value",
            attachment_type=allure.attachment_type.TEXT)
        return populated_value
    
    @allure.step("{field_name} is autopopulated with {expected_value} {unit}")
    def verify_field_value(self, locator, expected_value, field_name="Field", unit=None):
        actual_value = locator.get_attribute("value")
        
        if unit:
            unit_element = locator.locator("xpath=following-sibling::div[1]")
            if unit_element.count() == 0:
                unit_element = locator.locator(f"xpath=.//div[normalize-space(text())='{unit}']").first
            
            unit_element.wait_for(state="attached", timeout=5000)
            actual_unit = unit_element.inner_text().strip().replace("\u00a0", " ").replace("\n", "")
            expected_unit = unit.strip().replace("\u00a0", " ").replace("\n", "")
        
            check.equal(actual_unit, expected_unit, f"Field '{field_name}' should have unit '{expected_unit}'")
            allure.attach(f"Numeric value: {actual_value} {actual_unit}", name=f"Field '{field_name}' value with unit",
                        attachment_type=allure.attachment_type.TEXT)
        assert actual_value == str(expected_value), f"Expected {field_name} to be '{expected_value}', but found '{actual_value}'"

    @allure.step("Fields are autopopulated with expected values")
    def verify_readonly_fields(self, fields_to_verify):
        for field in fields_to_verify:
            if len(field) == 4:
                locator, expected_value, field_name, unit = field
            else: 
                locator, expected_value, field_name = field
                unit = None  
            self.verify_field_value(locator, expected_value, field_name, unit)

    @allure.step("File attached {file_path}")
    def attach_file(self, file_path):
        self.attach_file_button.click()
        self.page.locator("input[type='file']").set_input_files(file_path)
  
    def perform_review_sign(self, username, password):
        form = self.page.locator("form").filter(has_text="Performed bySign")
        form.get_by_placeholder("username").dblclick()
        form.get_by_placeholder("username").fill(username)
        form.get_by_placeholder("password").click()
        form.get_by_placeholder("password").fill(password)
        form.get_by_role("button").click()
        self.page.wait_for_timeout(2000)

    def verify_sign(self, username, password):
        form = self.page.locator("form", has_text=re.compile(r"(Checked by|Verified by)", re.IGNORECASE))
        form.get_by_placeholder("username").fill(username)
        form.get_by_placeholder("password").click()
        form.get_by_placeholder("password").fill(password)
        form.get_by_role("button").click()

    @allure.step("Select picklist options in sequence: {options}")
    def toggle_picklist(self, selector: str, options: list):
        select_element = self.page.locator(selector)
        select_element.wait_for(state="visible", timeout=500)
        select_element.click()
        self.page.wait_for_timeout(500)
        
        for option in options:
            select_element.select_option(value=option)
            self.page.wait_for_timeout(1000) 
        return self

    @allure.step("Update inventory item: {item_name} with quantity: {quantity}")
    def update_inventory_item(self, item_name: str, quantity: str, index: int):

        item_input = self.page.locator("input[data-v-4ff5d346]").nth(index)
        item_input.wait_for(state="visible", timeout=5000)
        item_input.click()
        
        editor_modal = self.page.locator("div.modal-container[data-test='overlay__modal-container']").filter(has_text="Inventory Item Editor").first
        editor_modal.wait_for(state="visible", timeout=5000)
        self.page.wait_for_timeout(2000)
        remove_input = editor_modal.locator("input[name='remove']").first
        remove_input.wait_for(state="visible", timeout=5000)
        remove_input.clear()
        remove_input.fill(quantity)
        
        save_button = editor_modal.locator("button.btn.primary:has-text('Save')")
        save_button.wait_for(state="visible", timeout=5000)
        save_button.click()
        self.page.wait_for_timeout(500)
        return self
    
    @allure.step("Update transkit inventory item: {item_name}")
    def update_transkit_inventory_item(self, item_name: str, index: int):

        transkit_box = self.page.locator('input[tabindex="null"]').nth(index) 
        transkit_box.wait_for(state="visible", timeout=5000)
        transkit_box.click()
        
        checkbox_option = self.page.locator('span.ag-cell-value[role="presentation"]').filter(has_text=item_name)
        checkbox_option.wait_for(state="visible", timeout=5000)
        check.is_true(checkbox_option.is_visible(), "The field is not a resourcelink")
        checkbox_option.click()

        # self.verify_field_type(checkbox_option, "resourcelink")
        
        self.page.wait_for_timeout(500)
        self.submit_button.wait_for(state="visible", timeout=5000)
        self.submit_button.click()
        self.page.wait_for_timeout(200)
        self.save_button.click()
        self.page.wait_for_timeout(500)
        return self
    
    @allure.step("Verifying the instructions text dispalyed")
    def check_instructions_and_readonly(self, locator, expected_text, index = None):
        element = self.page.locator(locator)
        if index is not None:
            element = element.nth(index)
        element.wait_for(state='visible', timeout=5000)
        actual_text = element.inner_text()

        def normalize(text: str) -> str:
            return "".join(text.split())  # removes all whitespace

        normalized_actual = normalize(actual_text)
        normalized_expected = normalize(expected_text)
        check.equal(normalized_actual,normalized_expected,"The instructions are incorrect/missing")
        return self

    @allure.step("Toggle checkbox: {checkbox_label}")
    def toggle_checkbox(self, checkbox_label: str):
    
        label_element = self.page.get_by_text(checkbox_label, exact=True)
        label_element.wait_for(state="visible", timeout=5000)

        container = label_element.locator("..")  
        checkbox = container.locator("input[data-v-d9e20716][type='checkbox']")
        
        if checkbox.count() == 0:
            container = label_element.locator("../..")
            checkbox = container.locator("input[data-v-d9e20716][type='checkbox']")
        checkbox.wait_for(state="visible", timeout=5000)
        
        if not checkbox.is_checked():
            checkbox.check()
            self.page.wait_for_timeout(300)
            expect(checkbox).to_be_checked()
        checkbox.uncheck()
        self.page.wait_for_timeout(300)
        expect(checkbox).not_to_be_checked()
        checkbox.check()
        self.page.wait_for_timeout(300)
        expect(checkbox).to_be_checked()
        allure.attach(f"Checkbox '{checkbox_label}' is checked", name="Checkbox State", attachment_type=allure.attachment_type.TEXT)
        return self
    
    def submit_to_next_unit_operation(self):
        submit_to_next = self.page.locator("button:has(span:has-text('Submit to Next Unit Operation'))")
        submit_to_next.wait_for(state="visible", timeout=5000)
        submit_to_next.click()

    def get_input_for_field(self, field_label: str):
        field_container = self.page.locator("div").filter(
        has=self.page.locator("label", has_text=field_label)).last # Using last because often the wrapper is the innermost div
        input_box = field_container.locator("input").first
        return input_box

    @allure.step("Verify numeric field range '{field_label}' with invalid value '{invalid_value}' and valid value '{valid_value}'")
    def verify_field_range_validation(self, field_label: str, invalid_value: str, valid_value: str):
        input_box = self.get_input_for_field(field_label)
        input_box.click()
        input_box.fill(invalid_value)
        self.span.click()
        time.sleep(1)

        out_of_range_msg = self.page.get_by_test_id("out-of-range-msg")
        expect(out_of_range_msg).to_be_visible(timeout=5000)
        message_text = out_of_range_msg.text_content().lower()
        check.is_true("out of range" in message_text, f"Expected 'out of range' message, got '{message_text}'")

        input_box.click()
        input_box.fill(valid_value)
        self.span.click()
        time.sleep(1)

    @allure.step("Select multiselect options: {options} for field '{header_name}'")
    def multiselect_picklist(self, selector: str, options: list, header_name: str = ""):
        
        for option in options:
            multiselect_trigger = self.page.locator(selector)
            multiselect_trigger.wait_for(state="visible", timeout=5000)
            multiselect_trigger.click()
            self.page.wait_for_timeout(500)
            
            dropdown = self.page.locator('.multiselect__content')
            dropdown.wait_for(state="visible", timeout=2000)
            
            option_locator = self.page.locator(f'.multiselect__element:has-text("{option}")')
            if option_locator.count() == 0:
                option_locator = dropdown.get_by_text(option, exact=True)
            option_locator.click()
            
            self.span.click()
            self.page.wait_for_timeout(500)
        return self
    
    @allure.step("Verifying the picklist {label_text} has options {expected_options}")
    def verify_picklist_options(self,label_text: str, expected_options: list[str], select_option=None):

        label = self.page.locator(f'xpath=//label[normalize-space(text())="{label_text}"]')
        expect(label).to_be_visible()
        select = self.page.locator(f'xpath=//label[normalize-space(text())="{label_text}"]/following::select[1]')
        expect(select).to_be_visible()
        actual_options = select.locator("option").all_text_contents()
       
        for option in expected_options:
            check.is_in(option, actual_options, f'Expected option "{option}" not found in picklist "{label_text}"')

        option_to_select = select_option or expected_options[0]
        select.select_option(label=option_to_select)
       

    @allure.step("Add and register {num_samples} Transduced Material Sample(s)")
    def add_samples(self, sample_type: str, num_samples: int, max_samples: int):

        assert 1 <= num_samples <= max_samples, f"You can only register 1 to {max_samples} samples"

        self.page.get_by_role("button", name="Add", exact=True).click()
        self.page.wait_for_timeout(1000)  # Increase wait time to ensure modal loads fully
        self.page.get_by_role("button", name="Add new samples").click()
        
        sample_type_dropdown = self.page.locator("select").first
        sample_type_dropdown.select_option(label = sample_type)
        self.page.wait_for_timeout(500)

        number_input = self.page.locator("input.num-entities-input[placeholder^='ex:']").first
        number_input.wait_for(state="visible", timeout=5000)  
        number_input.click()
        number_input.fill(str(num_samples))
        self.page.wait_for_timeout(2000)

        register_button = self.page.get_by_role("button", name=f"Register ({num_samples})")
        register_button.wait_for(state="visible", timeout=2000)
        self.page.wait_for_timeout(500)
        register_button.click()

        self.page.wait_for_timeout(500)
        self.page.get_by_role("button", name="Close").click()
        self.page.wait_for_timeout(1000)

        for i in range(num_samples):
            sample_id_cell = self.page.get_by_role("cell", name=re.compile(r"ESP\d+")).nth(i)
            sample_id_cell.wait_for(state="visible", timeout=5000)
            actual_id = sample_id_cell.inner_text().strip()
            allure.attach(actual_id, name=f"Sample ID {i+1}", attachment_type=allure.attachment_type.TEXT)

            timestamp_cell = self.page.locator("role=cell").filter(has_text=re.compile(r"\d{2}/\d{2}/\d{4} \d{2}:\d{2} [ap]m IST")).nth(i)
            timestamp_cell.wait_for(state="visible", timeout=5000)
            actual_time = timestamp_cell.inner_text().strip()
            allure.attach(actual_time, name=f"Time Registered {i+1}", attachment_type=allure.attachment_type.TEXT)

            pattern = r"^\d{2}/\d{2}/\d{4} \d{2}:\d{2} [ap]m IST$"
            check.is_true(re.match(pattern, actual_time),
                        f"Sample {i+1} Time Registered format is incorrect: {actual_time}")
        return self
    
    @allure.step("Fetch barcode for {entity_id}")
    def get_barcode(self, entity_id: str) -> str:
        self.page.wait_for_timeout(500)
        self.page.locator(".drawer-toggler").click()
        assets_locator = self.page.get_by_role("link", name="Entities").click()
        
        assets_locator.wait_for(state="visible", timeout=5000)
        self.page.wait_for_timeout(500)
        assets_locator.click()
        
        entity_link = self.page.get_by_role("link", name=entity_id)
        entity_link.wait_for(state="visible", timeout=5000)
        self.page.wait_for_timeout(500)
        entity_link.click()

        textbox = self.page.get_by_role("textbox", name="No barcode created")
        textbox.wait_for(state="visible", timeout=5000)
        barcode_value = textbox.input_value().strip()
        allure.attach(barcode_value, name=f"Barcode for {entity_id}", attachment_type=allure.attachment_type.TEXT)
        return barcode_value

    @allure.step("Fill field '{header}' for entity '{entity_id}' with barcode '{barcode_value}'")
    def fill_barcode_field(self, entity_id: str, header: str, barcode_value: str):
        label = self.page.get_by_text(header, exact=True)
        container = label.locator(self.xpath_ancestor_block_content)
        input_field = container.locator("input[type='text']").first
        input_field.wait_for(state="visible", timeout=5000)
        if not input_field.is_enabled():
            raise RuntimeError(f"Input field for '{header}' is not enabled yet")
        input_field.fill(barcode_value)
        input_field.press("Enter")

        check.equal(input_field.input_value(),barcode_value,f"Failed to fill '{header}' with expected barcode '{barcode_value}'")
        allure.attach(barcode_value,name=f"Barcode for {entity_id}",attachment_type=allure.attachment_type.TEXT)

    @allure.step("'Verifying auto-populated value in {header_name}")
    def verify_auto_populated_field(self, header_name):
        header = self.page.get_by_text(header_name, exact=True)
        container = header.locator(self.xpath_ancestor_block_content)
        input_field = container.locator("input")
        auto_populated_text = input_field.input_value()
        allure.attach(f"Auto-populated value for '{header_name}': {auto_populated_text}", name="Auto-populated Value", attachment_type=allure.attachment_type.TEXT)
        check.is_true(auto_populated_text != "", f"The field for '{header_name}' is not auto-populated correctly. Found: '{auto_populated_text}'")

    def normalize_date(self, date_str: str) -> str:
        formats = [
            "%b %Y",  # MMM YYYY (Nov 2025)
            "%d %b %Y",  # DD MMM YYYY (10 Nov 2025)
            "%d %b %Y %H:%M CT", ] # DD MMM YYYY hh:mm CT (10 Nov 2025 03:30 CT)

        for fmt in formats:
            try:
                normalized_date = datetime.strptime(date_str, fmt).strftime("%Y-%m-%d %H:%M")
                return normalized_date
            except ValueError:
                continue
        raise ValueError(f"Date format not recognized: '{date_str}'")

    @allure.step("Field is a '{expected_type}'")
    def verify_field_type(self, locator, expected_type: str):
        expect(locator).to_be_visible()
        locator.dblclick()

        if self.page.locator(".ag-popup").is_visible() or self.page.locator("[role='dialog']").is_visible():
            actual_type = "resourcelink"
        else:
            input_field = self.page.locator('.ag-cell-editor input, .editor-container input')
            input_field.wait_for(state='visible', timeout=5000) 

            if (self.page.locator(".ag-cell-editor input[type='number']").is_visible() or
                self.page.locator(".number-input").is_visible() or
                self.page.locator(".editor-container input[type='number']").is_visible()):
                actual_type = "numeric"

            elif self.page.locator(".ag-cell-editor input").is_visible() or self.page.locator(".editor-container input").is_visible():
                actual_type = "free text"

            else:
                actual_type = "unknown"
        check.equal(actual_type, expected_type, f"Expected field type '{expected_type}' but detected '{actual_type}'")

    @allure.step("'{header_name}' picklist is auto-populated with'{text}'")
    def field_is_autopopulated_picklist(self, header_name, text):
        header = self.page.get_by_text(header_name, exact=True)
        container = header.locator(self.xpath_ancestor_block_content)
        picklist_field = container.locator("select") 
        picklist_field.wait_for(state="visible", timeout=5000)
        selected_value = picklist_field.locator("option:checked").inner_text().strip()
        check.is_true(selected_value == text, f"The picklist field has no/incorrect default value. Expected: '{text}', Found: '{selected_value}'")

    def add_items_in_assets(self):
         # Find the block related to the header
        self.page.wait_for_timeout(1000)
        self.page.locator(".drawer-toggler").click()
        self.page.wait_for_timeout(500)
        self.page.get_by_role("link", name="Assets").first.click()
        self.page.wait_for_timeout(1000)

        self.page.locator("[data-test=\"filter-container-name\"]").click()
        self.page.locator("[data-test=\"filter-container-name\"]").fill("TransAct1")
        self.page.wait_for_timeout(1000)
        self.page.get_by_role("link", name="TransAct1").click()

        if self.page.locator("i.close-panel.esp-icons", has_text="last_page").is_visible():
            # Click the collapse/close icon first
            self.page.locator("i.close-panel.esp-icons", has_text="last_page").click()
            self.page.wait_for_timeout(500)

        self.page.get_by_role("button", name="add Add").click()
        self.page.wait_for_timeout(2000)
        self.page.locator(".checkbox-container").first.click()
        self.page.get_by_role("button", name="Select").click()

        item_1 = self.page.locator("div.sample_content--name", has_text=self.transact_reagent_a)
        drop_target = self.page.locator("div.container.test").first
        item_1.drag_to(drop_target)

        item_2 = self.page.locator("div.sample_content--name", has_text=self.transact_reagent_b)
        drop_target = self.page.locator("div.container.test").first
        item_2.drag_to(drop_target)

        self.page.get_by_role("listitem").filter(has_text=self.transact_reagent_a).get_by_role("spinbutton").first.click()
        self.page.get_by_role("listitem").filter(has_text=self.transact_reagent_a).get_by_role("spinbutton").first.fill("50")
        self.page.get_by_role("listitem").filter(has_text=self.transact_reagent_b).get_by_role("spinbutton").first.click()
        self.page.get_by_role("listitem").filter(has_text=self.transact_reagent_b).get_by_role("spinbutton").first.fill("50")
        self.page.get_by_role("button", name="Save").click()
        self.page.get_by_role("button", name="Done").click()

    def verify_vendors_present(self, vendor_names: list[str]):
        with allure.step("Navigate to Vendors page"):
            master_link = self.page.get_by_role("link", name=self.l7_master)
            master_link.wait_for(state="visible", timeout=10000)
            master_link.click()

            vendors_link = self.page.get_by_role("link", name="Vendors")
            vendors_link.wait_for(state="visible", timeout=10000)
            vendors_link.click()

            grid = self.page.locator(".ag-center-cols-viewport")
            grid.wait_for(state="visible", timeout=10000)

            for vendor in vendor_names:
                with allure.step(f"Check vendor: {vendor}"):
                    locator = self.page.get_by_role("gridcell", name=vendor)
                    is_visible = locator.is_visible()
                    check.is_true(is_visible, f"Vendor '{vendor}' should be present in the Vendors grid")

    def add_vendor_to_item_type(self, item_type_name: str, vendor_name: str):
        with allure.step(f"Add vendor '{vendor_name}' to item type '{item_type_name}'"):
            drawer_toggler = self.page.locator(self.div_draw_toggler)
            if drawer_toggler.count() > 0 and drawer_toggler.is_visible():
                drawer_toggler.click()

            master_link = self.page.get_by_role("link", name=self.l7_master)
            master_link.wait_for(state="visible", timeout=15000)
            master_link.click()

            item_types_link = self.page.get_by_role("link", name="Item Types")
            item_types_link.wait_for(state="visible", timeout=15000)
            item_types_link.click()
            self.page.wait_for_timeout(1000)

            search_input = self.page.locator("input[placeholder='ex: John Doe']").first
            search_input.click()
            search_input.fill(item_type_name)
            search_input.press("Enter")
            self.page.wait_for_timeout(1000)

            item_type_link = self.page.get_by_role("link", name=item_type_name, exact = True)
            item_type_link.wait_for(state="visible", timeout=10000)
            item_type_link.click()

            add_vendor_btn = self.page.locator("div.wrapper", has_text="Add Vendors")
            add_vendor_btn.wait_for(state="visible", timeout=10000)
            add_vendor_btn.click()

            modal = self.page.locator("[data-test='overlay__modal-container']")
            modal.wait_for(state="visible", timeout=10000)

            removal_msg_locator = modal.locator("span", has_text=f'removed Vendor "{vendor_name}"')
            if removal_msg_locator.count() > 0:
                removal_msg_locator.wait_for(state="detached", timeout=15000)
            self.page.wait_for_timeout(1500)
            vendor_row = modal.locator(f'div.row.selectable-row:has(a:text("{vendor_name}"))')
            vendor_row.wait_for(state="visible", timeout=10000)
            vendor_checkbox = vendor_row.locator('i[data-testid="checkbox"]')
            vendor_checkbox.click()

            self.page.get_by_role("button", name="Select").click()
            modal.wait_for(state="detached", timeout=10000)
            self.page.get_by_role("button", name="Save").click()

            added_vendor = self.page.locator(f'div.row:has(a:text("{vendor_name}"))')
            check.is_true(added_vendor.count() > 0, f"Vendor '{vendor_name}' should be present in item type '{item_type_name}'")

            self.page.locator('a[href="#/master/item-types"]').click()
            self.page.wait_for_timeout(1000)

    def add_new_inventory_item(self, item_name: str, item_type: str, lot_number: str = None, original_amount: float = None, expiration_date: str = None):
        with allure.step(f"Created new inventory item '{item_name}' with type '{item_type}'"):
            drawer_toggler = self.page.locator(self.div_draw_toggler)
            if drawer_toggler.count() > 0 and drawer_toggler.is_visible():
                drawer_toggler.click()

            inventory_link = self.page.get_by_role("link", name="Inventory")
            inventory_link.wait_for(state="visible", timeout=15000)
            inventory_link.click()
            self.page.wait_for_timeout(1000)

            new_item_btn = self.page.locator("div.label", has_text="New Item")
            new_item_btn.click()
           
            modal = self.page.locator("[data-test='overlay__modal-container']")
            modal.get_by_label("Item Name").fill(item_name)

            item_type_select = modal.locator("select#item-type")
            item_type_select.select_option(label=item_type)

            if lot_number:
                modal.get_by_label("Lot Number").fill(lot_number)
        
            if original_amount is not None:
                modal.get_by_label("Original Amount").fill(str(original_amount))
        
            if expiration_date:
                formatted_date = datetime.strptime(expiration_date, "%Y-%m-%d").strftime("%m/%d/%Y")
                date_input = modal.locator('input[placeholder="ex: MM/DD/YYYY"]')
                date_input.click()
                date_input.fill(formatted_date)
                date_input.press("Enter")

            create_btn = modal.locator("#register-form-submit")
            create_btn.scroll_into_view_if_needed()
            create_btn.click()

    def open_inventory_item_and_edit(self, item_type: str, item_name: str, manufacturer_item_number: str = None, manufacturer_date: str = None):
        
        self.page.reload()
        self.page.wait_for_load_state('networkidle')
        self.page.wait_for_selector('div.ag-row', timeout=10000)

        search_input = self.page.locator("input[data-test='filter-item-name']").first
        search_input.click()
        search_input.fill(item_name)
        search_input.press("Enter")
        self.page.wait_for_timeout(1000)
        
        parent_value = self.page.locator("span.ag-group-value",has_text=re.compile(rf"\s*{re.escape(item_type)}\s*"))
        parent_value.first.wait_for(state="visible", timeout=10000)  
        parent_value.first.dblclick()
        self.page.wait_for_timeout(800)

        item_link = self.page.locator(f'a.protocol-link:text("{item_name}")').first
        item_link.wait_for(state="visible", timeout=8000)
        item_link.first.click()
        self.page.wait_for_load_state('networkidle')

        data_tab = self.page.get_by_role("link", name="Data", exact=True)
        data_tab.click()
        self.page.wait_for_selector('div.ag-row')

        with allure.step (f"Filled item number '{manufacturer_item_number}' and manufacture date '{manufacturer_date}'"):
            if manufacturer_item_number:
                first_cell = self.page.locator('div.ag-row:nth-of-type(1) div.ag-cell-value').nth(1)
                self.page.wait_for_timeout(1000)
                first_cell.dblclick()
                self.page.wait_for_timeout(500)
                editor_input = self.page.get_by_role("textbox", name="Input Editor")
                editor_input.wait_for(state="visible", timeout=5000)
                editor_input.fill(manufacturer_item_number)
                editor_input.press("Enter")
                updated_first_cell_text = first_cell.inner_text()
                self.page.wait_for_timeout(1000)
                check.is_true(len(updated_first_cell_text) > 0, "Item Number edit failed. Manufacture Item number cell is empty after editing'")

            if manufacturer_date:
                second_cell = self.page.locator('div.ag-row:nth-of-type(2) div.ag-cell-value').nth(1)
                second_cell.dblclick()
                date_input = self.page.locator('input.flatpickr-input').first
                date_input.wait_for(state="visible", timeout=3000)
                date_input.fill(manufacturer_date)
                date_input.press("Enter")
                updated_second_cell_text = second_cell.inner_text().strip()
                self.page.wait_for_timeout(1000)
                check.is_true(len(updated_second_cell_text) > 0,"Manufacture Date cell is empty after editing.")
            self.done_button.click()

            self.page.wait_for_selector('div.ag-cell-editing',state='detached',timeout=3000)

    def open_item_type_and_validate_details(self, item_name, expected_unit, expected_consumption, expected_desc = None):
        drawer_toggler = self.page.locator(self.div_draw_toggler)
        if drawer_toggler.count() > 0 and drawer_toggler.is_visible():
            drawer_toggler.click()

        master_link = self.page.get_by_role("link", name=self.l7_master)
        master_link.wait_for(state="visible", timeout=15000)
        master_link.click()

        item_types_link = self.page.get_by_role("link", name="Item Types")
        item_types_link.wait_for(state="visible", timeout=15000)
        item_types_link.click()
        self.page.wait_for_timeout(1000)

        search_input = self.page.locator("input[placeholder='ex: John Doe']").first
        search_input.click()
        search_input.fill(item_name)
        search_input.press("Enter")
        self.page.wait_for_timeout(1000)

        row = self.page.locator(f'//div[contains(@class, "ag-row")]//div[@col-id="name"]//a[normalize-space()="{item_name}"]/ancestor::div[contains(@class, "ag-row")]')
        desc_cell = row.locator('xpath=.//div[@col-id="description"]')
        desc_cell.first.wait_for(state="visible", timeout=7000)
        desc_cell.first.click(force=True)

        panel = self.page.locator("div.admin-item-type-details-inspector")
        panel.wait_for(state="visible", timeout=10000)

        with allure.step(f"'{item_name}' has unit '{expected_unit}' and is of '{expected_consumption}' type with description '{expected_desc}'"):
            unit_value = panel.locator("div.item-details-cell:has-text('Units') + div.cell-data")
            unit_value.wait_for(state='visible', timeout=5000)
            unit_text = unit_value.inner_text().strip().replace('(s)', '')  # remove (s) from UI
            expected_unit_normalized = expected_unit.strip().replace('(s)', '')
            check.equal(unit_text,expected_unit_normalized,f"Unit mismatch: Expected '{expected_unit_normalized}', Found '{unit_text}'")
            
            type_value = panel.locator("div.item-details-cell:has-text('Type') + div.cell-data")
            type_value.wait_for(state='visible', timeout=5000)
            consumption_text = type_value.inner_text().strip()
            check.equal(consumption_text, expected_consumption, f"Consumption type mismatch: Expected '{expected_consumption}', Found '{consumption_text}'")

            desc_value = panel.locator("div.item-details-cell:has-text('Description') + div.cell-data")
            if desc_value.count() > 0:
                desc_text = desc_value.first.inner_text().strip() or None
            else:
                desc_text = None
            if expected_desc is not None or desc_text is not None:
                check.equal(desc_text, expected_desc, f"Description mismatch: Expected '{expected_desc}', Found '{desc_text}'")