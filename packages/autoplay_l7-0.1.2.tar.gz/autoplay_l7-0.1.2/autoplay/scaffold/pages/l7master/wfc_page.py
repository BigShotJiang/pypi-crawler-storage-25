from pages.base_page import BasePage

class WFCPage(BasePage):
    def __init__(self, page):
        super().__init__(page)
        self.page = page
        self.wfc_link = self.build_url("/#/master/workflow-chains")
        self.page.wfc_name_textbox = self.page.get_by_role("textbox", name = "workflow-chain-name")
        self.page.wfc_description_textbox = self.page.get_by_role("textbox", name = "workflow-chain-description")
        self.page.wfc_name_owner = self.page.get_by_role("textbox", name = "workflow-chain-owner")
        self.page.wfc_tags = self.page.get_by_role("textbox", name = "Workflow Tags")

    def navigate_to_wfc(self):
        self.page.goto(self.wfc_link)
    
    def select_wfc(self, wfc_name):
        self.page.goto(self.wfc_link)
        self.page.wfc_name_textbox.wait_for(state="visible").fill(wfc_name)
        self.page.get_by_role("link", name=wfc_name).first.click()
    
    def pin_wfc(self, wfc_name):
        self.select_wfc(wfc_name)
        self.page.get_by_role("button", name = "Pin").wait_for(state="visible").click()


    




        



