import allure, re
from playwright.sync_api import expect
from pages.mes_page import MESPage
from pages.l7master.workflowpage import Workflowpage
from pages.homepage import HomePage
import pytest_check as check
from utils.networks import Networking

class SignaturePage:
     
    def __init__(self, page):  
        self.page = page
        self.mes = MESPage(self.page)
        self.homepage = HomePage(self.page)
        self.workpage = Workflowpage(self.page)

        self.master_link = page.get_by_role("link", name="L7|Master")
        self.l7_master_title = page.locator("div.selected_app__title:text('L7|Master')")
        self.protocols_page = page.locator("div.admin-page__name:text('Protocols')")
        self.signature_link = page.get_by_role("link", name="Signature Flows")
        self.performed_checkedby_link = page.get_by_role("link", name="MES Performed by/Checked by")
        self.performed_verifiedby_link = page.locator("a.protocol-link:has-text('MES Performed By/Verified By')")
        self.back_to_signature_flows = page.locator("a[href='#/master/signature-flows'].active")
        self.accept_reasons_row = page.locator("tr:has(td:text('Accept Reasons'))")
        self.reject_reasons_row = page.locator("tr:has(td:text('Reject Reasons'))")
        self.advanced_sections = page.locator("span.advanced-text:text('Advanced')")
        self.signature_boxes = page.locator("div.info:has(.name.handle)")
        self.search_input = page.locator("input[placeholder='ex: John Doe']").first
        self.reviews_group = page.locator("span.ag-group-value").filter(has_text=re.compile(r"^Reviews?$"))
        self.signature_flow_select = page.locator("div.parameter-cell:has(label:text('Signature Flow')) select")
        self.back_to_protocols = page.locator("a[href='#/master/protocols'].active")
        self.checked_by = "Checked by"
        self.performed_by = "Performed by"

    def navigate_to_signatureflows(self):
        with allure.step("Navigate to Signature Flows"):
            self.master_link.wait_for(state="visible", timeout=15000)
            self.master_link.click()
            self.signature_link.wait_for(state="visible", timeout=15000)
            self.signature_link.click()
    
    def performed_checkedby(self):
        with allure.step("Opening MES Performed by/Checked by"):
            self.performed_checkedby_link.wait_for(state="visible", timeout=15000)
            self.performed_checkedby_link.click()
    
    def performed_verifiedby(self):
        with allure.step("Opening MES Performed By/Verified By"):
            self.performed_verifiedby_link.wait_for(state="visible", timeout=15000)
            self.performed_verifiedby_link.click()
    
    def navigate_back_to_signature_flows(self):
            self.back_to_signature_flows.wait_for(state="visible", timeout=15000)
            self.back_to_signature_flows.click()
    
    def verify_accept_reasons(self, expected_tags=["Performed by", "Checked by"]):
        with allure.step(f"Verifying Accept Reasons contain {expected_tags}"):
            accept_reasons_cell = self.accept_reasons_row.locator("td").nth(1)
            accept_reasons_cell.wait_for(state="visible", timeout=10000)
            
            for expected_tag in expected_tags:
                with allure.step(f"✓ Verify '{expected_tag}' tag exists"):
                    # Use re.compile with re.IGNORECASE to match both 'by' and 'By'
                    tag = accept_reasons_cell.locator("span.tag-span").filter(has_text=re.compile(f"^{expected_tag}$", re.IGNORECASE))
                    
                    # Assertions
                    expect(tag).to_be_visible(timeout=10000)
                    check.is_true(tag.is_visible(), f"Accept Reasons should contain '{expected_tag}' (case-insensitive)")
        
    def verify_reject_reasons(self):
        with allure.step("Verifying Reject Reasons contain 'Out of Spec'"):
            reject_reasons_cell = self.reject_reasons_row.locator("td").nth(1)
            out_of_spec_tag = reject_reasons_cell.locator("span.tag-span:text('Out of Spec')")
            expect(out_of_spec_tag).to_be_visible()
            check.is_true(out_of_spec_tag.is_visible(), "Reject Reasons should contain 'Out of Spec'")
    
    def click_advanced_sections(self):
            advanced_count = self.advanced_sections.count()
            for i in range(advanced_count):
                with allure.step(f"Click Advanced for Signature {i+1}"):
                    self.advanced_sections.nth(i).click()
                    self.page.wait_for_timeout(500) 
    
    def verify_signature_details(self, signature_number, expected_label):
        with allure.step(f"Verifying Signature {signature_number} details"):
            signature_box = self.signature_boxes.nth(signature_number - 1)
            signature_name = signature_box.locator(".name.handle").text_content()
            with allure.step(f"✓ Signature Name: '{signature_name}' contains expected elements"):
                check.is_in(f"Signature {signature_number}", signature_name, f"Signature {signature_number} name verification")
                check.is_in("Workgroup: Technician", signature_name, f"Signature {signature_number} should show Workgroup: Technician")
            
            type_select = signature_box.locator("select").first
            selected_type = type_select.input_value()
            with allure.step(f"✓ Type: '{selected_type}' equals 'workgroup'"):
                check.equal(selected_type, "workgroup", f"Signature {signature_number} Type should be Workgroup")
            
            workgroup_input = signature_box.locator("input[placeholder*='workgroup']")
            workgroup_value = workgroup_input.input_value()
            with allure.step(f"✓ Workgroup/Role: '{workgroup_value}' equals 'Technician'"):
                check.equal(workgroup_value, "Technician", f"Signature {signature_number} Workgroup should be Technician")
            
            label_input = signature_box.locator("input[placeholder='Label']")
            label_value = label_input.input_value()
            with allure.step(f"✓ Label: '{label_value}' equals '{expected_label}'"):
                check.equal(label_value, expected_label, f"Signature {signature_number} Label should be '{expected_label}'")
            
            block_progress_checkbox = signature_box.locator("div:has-text('Block process progress until signed') + div .checkbox.checked")
            block_progress_status = "✓ Checked" if block_progress_checkbox.is_visible() else "✗ Unchecked"
            with allure.step(f"✓ Block progress until signed: {block_progress_status}"):
                check.is_true(block_progress_checkbox.is_visible(), f"Signature {signature_number} should have 'Block progress until signed' checked")
            
            data_policy_select = signature_box.locator("select").last
            selected_policy = data_policy_select.input_value()
            with allure.step(f"✓ Data modification policy: '{selected_policy}' equals 'Re-sign on data change'"):
                check.equal(selected_policy, "Re-sign on data change", 
                            f"Signature {signature_number} Data modification policy should be 'Re-sign on data change'")

    @allure.step("Verifying Archive button is visible")
    def verify_archive(self):
        self.navigate_back_to_signature_flows()
        self.page.wait_for_timeout(1000)
        unchecked_checkbox = self.page.locator("i[data-testid='checkbox']:has-text('check_box_outline_blank')").first
        unchecked_checkbox.wait_for(state="visible", timeout=10000)
        unchecked_checkbox.click()
        self.page.wait_for_timeout(2000)
        archive_button = self.page.locator("button:has(span:text('esp_delete')):has(div.label:text('Archive'))")
        archive_button.wait_for(state="visible", timeout=5000)
        expect(archive_button).to_be_visible()
        check.is_true(archive_button.is_visible(), "Archive button with delete icon should appear after checking checkbox")
    
    def verify_all_signature_requirements(self, signature_type="checked_by"):
        self.page.wait_for_timeout(1000)
        with allure.step("Verify all signature requirements"):
            if signature_type == "checked_by":
                self.page.wait_for_timeout(1000)
                expected_tags = [self.performed_by, self.checked_by]
                first_label = self.performed_by     
                second_label = self.checked_by
            elif signature_type == "verified_by":
                self.page.wait_for_timeout(1000)
                expected_tags = [self.performed_by, "Verified by"]
                first_label = self.performed_by     
                second_label = "Verified by"
            else:
                raise ValueError(f"Invalid signature_type: {signature_type}")
            self.page.wait_for_timeout(1000)
            self.verify_accept_reasons(expected_tags)
            self.verify_reject_reasons()
            self.click_advanced_sections()
            self.verify_signature_details(1, first_label)
            self.verify_signature_details(2, second_label)

    def navigate_to_protocols(self):
        self.l7_master_title.wait_for(state="visible", timeout=10000)
        self.l7_master_title.click()
        self.page.wait_for_timeout(1000)
        self.protocols_page.wait_for(state="visible", timeout=10000)
        self.protocols_page.click()

    def search_and_open_protocol(self, protocol_name):
        self.search_input.wait_for(state="visible", timeout=10000)
        self.search_input.fill(protocol_name)
        self.search_input.press("Enter")
        protocol_link = self.page.get_by_role("link", name=protocol_name, exact=True)
        protocol_link.wait_for(state="visible", timeout=10000)
        protocol_link.click()

    def verify_protocol_signature_flow(self, protocol_name):
        with allure.step(f"Verify signature flow for '{protocol_name}'"):
            try:
                self.reviews_group.wait_for(timeout=10000)
                bounding_box = self.reviews_group.bounding_box()
                if bounding_box:
                    self.page.evaluate(f"window.scrollTo(0, {bounding_box['y'] - 200})")
                    self.page.wait_for_timeout(1000)
                self.reviews_group.click()
                self.page.wait_for_timeout(1500)
            except Exception:
                try:
                    reviews_section = self.page.locator("span.ag-group-value:text('Reviews')")
                    if reviews_section.count() > 0:
                        reviews_section.click()
                    else:
                        review_section = self.page.locator("span.ag-group-value:text('Review')")
                        review_section.click()
                    self.page.wait_for_timeout(1500)
                except Exception as fallback_error:
                    check.fail(f"Could not find Reviews/Review section for protocol '{protocol_name}': {fallback_error}")
            
        with allure.step("Verifying 'MES Performed By/Verified By' option exists"):
            self.signature_flow_select.wait_for(state="visible", timeout=5000)
            expected_option = self.signature_flow_select.locator("option:text('MES Performed By/Verified By')")
            option_exists = expected_option.count() > 0
            check.is_true(option_exists, f"Protocol '{protocol_name}' should have 'MES Performed By/Verified By' option available")
    
    def navigate_back_to_protocols(self):
        with allure.step("Navigate back to protocols"):
            max_retries = 5

            for attempt in range(max_retries):
                try:
                    self.back_to_protocols.wait_for(state="visible", timeout=10000)
                    self.back_to_protocols.click()
                    Networking.intercptor(self.page,"api/profile", 200)
                    self.search_input.wait_for(state="visible", timeout=10000)
                    return

                except Exception as e:
                    print(f"Navigate back attempt {attempt + 1} failed: {e}")

                    if attempt < max_retries - 1:
                        try:
                            self.page.goto("#/master/protocols")
                            Networking.intercptor(self.page,"api/profile", 200)

                            if self.search_input.count() > 0:
                                return

                            self.navigate_to_protocols()
                            return

                        except Exception as nav_error:
                            print(f"Alternative navigation failed: {nav_error}")

                            if attempt == max_retries - 1:
                                raise RuntimeError(
                                    f"Failed to navigate back to protocols after {max_retries} attempts"
                                ) from nav_error
                    else:
                        raise RuntimeError(
                            f"Failed to navigate back to protocols after {max_retries} attempts"
                        ) from e


    def verify_all_protocols_signature_flow(self):
        protocol_list = [
            "Cell Selection Equipment Log",
            "Cell Transduction Equipment Log",
            "Cell Wash Equipment Log",
            "Cryopreservation Equipment Log",
            "Electroporation Equipment Log",
            "Expansion Equipment Log",
            "Fill, Finish, Formulation Equipment Log",
            "Inoculation Equipment Log",
            "Inventory Routing Equipment Log",
            "Irradiation Equipment Log",
            "Lovo Cell Harvest Equipment Log",
            "Pre-Inoculation Equipment Log",
            "Lovo Cell Harvest Equipment Setup & Protocol Selection",
            "Lovo Cell Harvest Kitting and Consumables",
            "Lovo Cell Harvest Process and Kit Disassembly",
            "Lovo Cell Harvest Protocol Initiation",
            "Irradiation",
            "Finished Goods Inventory Routing",
            "Finished Goods Registration",
        ]

        with allure.step(f"Verify Signature Flow for {len(protocol_list)} protocols"):
            for i, protocol_name in enumerate(protocol_list):
                with allure.step(f"Protocol {i + 1}/{len(protocol_list)}: {protocol_name}"):
                    self.page.wait_for_timeout(1000)
                    try:
                        self.page.wait_for_timeout(1000)
                        self.search_and_open_protocol(protocol_name)
                        self.verify_protocol_signature_flow(protocol_name)
                        self.page.wait_for_timeout(2000)

                        if i < len(protocol_list) - 1:
                            with allure.step(f"Navigating back from {protocol_name}"):
                                self.navigate_back_to_protocols()

                    except Exception as e:

                        if i < len(protocol_list) - 1:
                            try:
                                self.page.wait_for_timeout(1500)
                                self.navigate_to_protocols()
                            except Exception as recovery_error:
                                print(f"Recovery navigation failed: {recovery_error}")
                                raise RuntimeError(
                                    f"Failed to process protocol '{protocol_name}' "
                                    f"and could not recover navigation"
                                ) from recovery_error
                        else:
                            raise RuntimeError(
                                f"Failed while processing final protocol '{protocol_name}'"
                            ) from e

    def complete_protocol_verification_flow(self):
        with allure.step("Complete Protocol Signature Flow Verification"):
            self.navigate_to_protocols()
            self.verify_all_protocols_signature_flow()

    def scroll_ag_grid_until_text_visible(self, text: str, max_scrolls: int = 20): 
        viewport = self.page.locator(".ag-body-viewport")
        expect(viewport).to_be_visible()
        
        for _ in range(max_scrolls):
            if self.page.locator(f"span.ag-group-value:text('{text}')").count() > 0:
                return
            viewport.evaluate("(el) => el.scrollBy(0, el.clientHeight * 2)")  
            self.page.wait_for_timeout(100) 
        raise AssertionError(f"'{text}' not found in AG Grid after scrolling")

    def verify_protocol_signature_flow(self, protocol_name):
        with allure.step(f"Verify signature flow for '{protocol_name}'"):
            try:
                if self.reviews_group.count() > 0:
                    self.reviews_group.click()
                    self.page.wait_for_timeout(1500)
                else:
                    try:
                        self.scroll_ag_grid_until_text_visible("Reviews", max_scrolls=15)
                    except AssertionError:
                        self.scroll_ag_grid_until_text_visible("Review", max_scrolls=15)
                    self.reviews_group.wait_for(timeout=3000)  
                    self.reviews_group.click()
                    self.page.wait_for_timeout(1500)
                    
            except Exception:
                try:
                    reviews_section = self.page.locator("span.ag-group-value:text('Reviews')")
                    if reviews_section.count() > 0:
                        reviews_section.click()
                    else:
                        review_section = self.page.locator("span.ag-group-value:text('Review')")
                        review_section.click()
                    self.page.wait_for_timeout(1000) 
                except Exception as fallback_error:
                    check.fail(f"Could not find Reviews/Review section for protocol '{protocol_name}': {fallback_error}")
            
        with allure.step("Verifying 'MES Performed By/Verified By' option exists"):
            self.signature_flow_select.wait_for(state="visible", timeout=8000)
            expected_option = self.signature_flow_select.locator("option:text('MES Performed By/Verified By')")
            option_exists = expected_option.count() > 0
            check.is_true(option_exists, f"Protocol '{protocol_name}' should have 'MES Performed By/Verified By' option available")

    def verify_signature_flow_requirements(self):
        """Verify that completion requires all signatures"""
        disabled_checkbox = self.page.locator("input[type='checkbox'][disabled]")
        disabled_checkbox.scroll_into_view_if_needed()
        with allure.step("Checkbox is disabled"):
            disabled_checkbox.wait_for(state="visible", timeout=5000)
        
        is_disabled = disabled_checkbox.is_disabled()
        check.is_true(is_disabled, "Complete checkbox should be disabled without signatures")
       
        self.workpage.perform_review_sign("admin@localhost", "password")
        self.page.wait_for_timeout(1000)
        with allure.step("Checkbox is still disabled after signing only the Performed By signature"):
            disabled_checkbox_after_partial = self.page.locator("input[type='checkbox'][disabled]")
            if disabled_checkbox_after_partial.count() > 0:
                disabled_checkbox_after_partial.scroll_into_view_if_needed()
                is_still_disabled = disabled_checkbox_after_partial.is_disabled()
                check.is_true(is_still_disabled, "Complete checkbox should remain disabled with partial signatures")

        with allure.step("Checkbox is enabled only after signing the second signature, proceeding to Complete and Save"):
            self.workpage.verify_sign("admin@localhost", "password")
            self.workpage.complete_save()

    def navigate_to_config(self):  
        self.homepage.navigate_home()
        self.page.wait_for_timeout(1000)
        self.homepage.allow_unpinned_versions()
        self.homepage.navigate_home()
        self.page.wait_for_timeout(1000)

    def navigate_to_mes(self, mes_batch_name):
        self.homepage.navigate_to_mes()
        self.mes.create_batch_record("Cell Therapy Product",mes_batch_name)
        self.page.wait_for_timeout(1000)
        self.homepage.open_worksheet(mes_batch_name)
        self.page.wait_for_timeout(500)
    
    

    def verify_mes_signatures(self):
        self.workpage.set_free_text_value(label_text="Plasmatherm ID", value="P123")
        self.verify_signature_flow_requirements()
        self.page.wait_for_timeout(2500)
        label = self.page.get_by_text("Patient ID", exact=True)
        label.scroll_into_view_if_needed()
        self.workpage.set_free_text_value(label_text="Patient ID", value="P001")
        self.verify_signature_flow_requirements()