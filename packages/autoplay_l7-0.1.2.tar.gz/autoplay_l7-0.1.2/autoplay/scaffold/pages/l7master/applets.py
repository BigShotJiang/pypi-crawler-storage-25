from playwright.sync_api import expect
import pytest_check as check
import allure
from utils.networks import Networking

class Applets:
    def __init__(self, page):
        self.page = page
        self.content_frame = self.page.get_by_text("Browser not compatible").content_frame
    
    def navigate_to_applets(self):
        self.page.get_by_role("link", name="Applets").click()
        Networking.interceptor(self.page, "api/reports", 200)
        
    def open_add_assets(self):
        self.page.get_by_text("Add Assets").click()
        Networking.interceptor(self.page, "api/resources", 200)
    
    def dropdown_selection(self):
        content_frame = self.page.get_by_text("Browser not compatible").content_frame
        dropdown_input = content_frame.locator('input[placeholder="Select Asset Type"]')
        expect(dropdown_input).to_be_visible()
        dropdown_input.click()
        dropdown_list = content_frame.locator('section.list-items ul')
        expect(dropdown_list).to_be_visible(timeout=3000)
        self.content_frame.get_by_text("Automated Cell Processing (P").click()

    def reset_button(self):
        self.content_frame.get_by_role("button", name="Reset").click()
        dropdown_input = self.content_frame.locator('input[placeholder="Select Asset Type"]')
        input_value = dropdown_input.input_value()
        assert input_value == "", f"Expected empty input after reset, got: '{input_value}'"
        placeholder = dropdown_input.get_attribute("placeholder")
        assert placeholder == "Select Asset Type", f"Expected placeholder 'Select Asset Type', got: '{placeholder}'"
        
    def enter_information_button(self):
        self.content_frame.get_by_role("button", name="Enter Information for Asset(s)").click()
        
    def fill_asset_information(self, asset_name, model, manufacturer):
        # Asset name field
        asset_name_field = self.content_frame.get_by_role("textbox").nth(1)
        expect(asset_name_field).to_be_visible()
        expect(asset_name_field).to_be_enabled()
        asset_name_field.click()
        asset_name_field.fill(asset_name)
        expect(asset_name_field).to_have_value(asset_name)
        # Model field  
        model_field = self.content_frame.get_by_role("textbox").nth(2)
        expect(model_field).to_be_visible()
        expect(model_field).to_be_enabled()
        model_field.click()
        model_field.fill(model)
        expect(model_field).to_have_value(model)
        # Manufacturer field
        manufacturer_field = self.content_frame.get_by_role("textbox").nth(3)
        expect(manufacturer_field).to_be_visible()
        expect(manufacturer_field).to_be_enabled()
        manufacturer_field.click()
        manufacturer_field.fill(manufacturer)
        expect(manufacturer_field).to_have_value(manufacturer)
        
    def click_add_button_and_verify(self, asset_name):
        self.content_frame.get_by_role("button", name="Add").click()
        asset_entry = self.content_frame.locator(f"span:has-text('Asset Name: {asset_name}')")
        asset_entry.wait_for(state="visible", timeout=1000)
        asset_container = self.content_frame.locator(f"div:has(span:text('Asset Name: {asset_name}'))")
        trashcan = asset_container.locator("#trashcan")
        trashcan.wait_for(state="visible", timeout=1000)
        
    def click_cancel_button(self):
        self.content_frame.get_by_role("button", name="Cancel").click()
        modal_container = self.page.locator(".fas-modal-container")
        expect(modal_container).not_to_be_visible(timeout=5000)
        
    def click_submit_button(self):
        self.content_frame.get_by_role("button", name="Submit").click()
    
    def verify_toast_msg(self):
        toast_container = self.page.locator("[role='alert'], .toast, .notification, .alert")
        toast_container.wait_for(state="visible", timeout=10000)
        assets_created_text = self.page.locator("text=Assets Created!")
        assets_created_text.wait_for(state="visible", timeout=5000)

    def navigate_to_entities(self):
        self.page.wait_for_timeout(2000)
        self.page.locator(".drawer-toggler").click()
        self.page.get_by_role("link", name="Entities").click()
        Networking.interceptor(self.page, "/api/v3", 200)
    
    def check_asset_present(self, asset_name):
        self.page.wait_for_timeout(2000)
        assert self.page.locator(f"a:has-text('{asset_name}')").is_visible(), f"Asset {asset_name} not found in grid"
