from utils.networks import Networking
from pages.base_page import PASSWORD, USER, BasePage

class HomePage(BasePage):
    def __init__(self, page):
        super().__init__(page)

    def navigate_to_login(self):
        self.navigate("#/login?redirect=/home")
        
    def navigate_to_project(self):
        self._click_nav_link("Projects")

    def navigate_to_lims(self):
        self._click_nav_link("LIMS")

    def navigate_to_applets(self):
        self._click_nav_link("Applets")

    def navigate_to_materials_receipt(self):
        self.navigate_to_applets()
        self.page.get_by_text("Materials Receipt").first.click()
        Networking.interceptor(self.page, "/api/workflows", 200)

    def navigate_to_master_new_tab(self):
        self._click_nav_link("L7|Master")

    def navigate_to_inventory(self):
        self.page.wait_for_timeout(1000)
        self._click_nav_link("Inventory")
        Networking.interceptor(self.page, "api/items", 200)

    def allow_unpinned_versions(self):
        self._click_nav_link("Configuration")
        self.page.get_by_role("button", name="View ▾").first.click()
        self.page.get_by_role("button", name="Code").click()
        self.page.wait_for_timeout(2000)
        # Modify Ace Editor content via JS
        self.page.evaluate("""
            () => {
                const editor = ace.edit(document.querySelector(".ace_editor"));
                const content = editor.getValue();
                const newContent = content.replace(
                    /("allow_unpinned_versions"\\s*:\\s*)false/,
                    '$1true'
                );
                editor.setValue(newContent, -1);
            }
        """)
        self.page.get_by_role("button", name="Save").click()