import re
import os
from utils.networks import Networking

DEFAULT_PORT = "8002"

HOST = os.getenv("ESP_HOST", "localhost")
PORT = os.getenv("ESP_PORT", DEFAULT_PORT)
USER = os.getenv("ESP_USER", "admin@localhost")
PASSWORD = os.getenv("ESP_PASSWORD")
class BasePage:
    
    def __init__(self, page):
        self.page = page

    def navigate(self, path: str = ""):
        self.page.goto(self.build_url(path))

    def login(self, username = USER, password = PASSWORD):
        self.page.wait_for_timeout(1000)
        self.page.get_by_role("textbox", name="Username").fill(username)
        self.page.get_by_role("textbox", name="Password").fill(password)
        self.page.get_by_role("button", name="Log In").click()
        Networking.interceptor(self.page, "api/configuration", 200)

    
    def _click_nav_link(self, name: str, exact: bool = True) -> None:
        link = self.page.get_by_role("link", name=name, exact=exact)
        if link.count() == 1:
            link.click()
        else:
            self.page.locator(".drawer-toggler").wait_for(state="visible")
            self.page.locator(".drawer-toggler").click()
            first = link.first
            first.wait_for(state="visible")
            first.scroll_into_view_if_needed()
            first.click()

    def _open_nav_link_new_tab(self, name: str, exact: bool = True):
        link = self.page.get_by_role("link", name=name, exact=exact)
        if link.count() != 1:
            self.page.locator(".drawer-toggler").wait_for(state="visible")
            self.page.locator(".drawer-toggler").click()
        target = link.first
        target.wait_for(state="visible")
        target.scroll_into_view_if_needed()
        with self.page.context.expect_page() as new_page_info:
            target.click(modifiers=["ControlOrMeta"])
        new_page = new_page_info.value
        new_page.wait_for_load_state()
        new_page.bring_to_front()
        return new_page

    @staticmethod
    def build_url(path: str = "") -> str:
        ssl = int(PORT) == 443
        base = f"{'https' if ssl else 'http'}://{HOST}:{PORT}"
        return f"{base}/{path.lstrip('/')}" if path else base

    
