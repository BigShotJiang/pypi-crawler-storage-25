import os, re, allure
import pytest_check as check
from playwright.sync_api import Page
from utils.networks import Networking
from datetime import datetime
from pages.base_page import PASSWORD, USER, BasePage

class MESPage(BasePage):
    def __init__(self, page):
        super().__init__(page)
        self.mes_link = self.page.get_by_role("navigation").get_by_role("link", name="Manufacturing Execution System")
        self.calender_locator = ".flatpickr-calendar.open"
        self.mm_dd_yyyy_format = r'^\d{1,2}/\d{1,2}/\d{4}$'
        self.flatpicker_prev_month = ".flatpickr-prev-month"
        self.flatpicker_next_month = ".flatpickr-next-month"
        self.xpath_ancestor_block_content = "xpath=ancestor::div[contains(@class, 'block-content')]"
        self.text_input = "input[type='text']"
        self.toast_main_panel = ".toast--main-panel"
        self.dd_mm_yyyy_format = "DD MMM YYYY"
        self.container="xpath=ancestor::div[contains(@class, 'block-content')]"
        self.text_field = "input[type='text']"
        self.apply_changes_button = self.page.get_by_role("button", name="Apply Changes")

    def navigate_to_mes(self):
        self._click_nav_link("Manufacturing Execution System")
        Networking.interceptor(self.page, "api/mes", 200)
        check.is_true("/mes" in self.page.url.lower(), "Expected URL to contain '/mes'")
        
    def create_batch_record(self,product,batch_name):
        self.page.wait_for_timeout(500)
        self.page.locator("[data-test=\"mes-home-header--btn-new\"]").click()
        Networking.interceptor(self.page, "api/profile",200)
        self.page.wait_for_timeout(500)
        self.page.get_by_text("keyboard_arrow_down").click()
        self.page.get_by_test_id("product-select").get_by_text(product).click()
        self.page.get_by_test_id("batch-name-input").click()
        self.page.get_by_test_id("batch-name-input").fill(batch_name)
        self.page.wait_for_timeout(1000)
        self.select_batch_field(header="MBR Version",index=1)
        self.page.wait_for_timeout(1000)
        self.page.get_by_role("button", name="Create").click()
        Networking.interceptor(self.page, "api/mes", 200)
        self.page.wait_for_timeout(1000)
        check.is_true(self.page.get_by_text(batch_name).first.is_visible(), "The batch record is not created")

    def select_batch_field(self,header,option=None, index=None):
        label = self.page.get_by_text(header)
        select_box = label.locator("xpath=../..").locator("select")
        if option != None:
            select_box.select_option(label=option)
            check.equal(select_box.input_value(), option, "The option is not selected")
        else:
            select_box.select_option(index=index)

    def open_batch(self,batch_name):
        self.page.get_by_role("link", name=batch_name, exact=True).first.click()
        Networking.interceptor(self.page, "api/reports", 200)
        self.page.wait_for_timeout(1000)
        check.is_true("/mes/unit-operation/open/" in self.page.url.lower(), "Expected URL to contain '/mes/unit-operation/open/'")
        self.page.wait_for_timeout(1000)
        if self.apply_changes_button.is_visible():
            self.apply_changes_button.click()

    def sign_off(self, signature_type: str, username: str = USER, password: str = PASSWORD):
        form = self.page.locator("form").filter(has_text=signature_type)
        form.get_by_placeholder("username").fill(username)
        form.get_by_placeholder("password").fill(password)
        form.get_by_role("button").click()
        Networking.interceptor(self.page, "/rollup", 200)
        signed_user_locator = self.page.locator(f"text={username}")
        check.greater(signed_user_locator.count(),0,f"Signed-in user '{username}' not found in Tech workgroup")

    def complete_save(self):
        self.page.get_by_text("Complete", exact=True).click()
        complete_checkbox = self.page.get_by_text("Complete", exact=True).locator("..").get_by_role("checkbox")
        complete_checkbox.check()
        self.page.get_by_role("button", name="Save").click()
        Networking.interceptor(self.page, "api/workflow_chain_instances", 200)
    
    def complete_save_v2(self, step_text):
        self.page.get_by_text("Complete", exact=True).click()
        step_section = self.page.locator("section").filter(has_text=step_text)
        checkbox = step_section.get_by_role("checkbox")
        checkbox.check()
        self.page.get_by_role("button", name="Save").click()

    def verify_nextstep_visible(self, step_number):
        self.page.wait_for_timeout(1500)
        hashlink_element = self.page.locator(f"[id='#hashlink-{step_number}']")
        check.is_true(hashlink_element.is_visible(timeout=10000), f"Step {step_number} is not visible")
    
    def verify_equipment_log_instruction(self, expected_text):
        instruction_element = self.page.locator("[data-v-f5d4a7bf].instruction")
        is_read_only = instruction_element.get_attribute("is-read-only")
        instruction_text = instruction_element.text_content().strip()
        expected_read_only = "false"
        check.equal(instruction_text, expected_text, f"Expected: '{expected_text}', but got: '{instruction_text}'")
        check.equal(is_read_only, expected_read_only, f"Expected read-only to be '{expected_read_only}', but got: '{is_read_only}'")

    def fill_equipment_id(self, equipment_type, equipment_id, expected_value, index):
        self.page.get_by_text(equipment_type, exact=True).click()
        textbox_locator = self.page.locator("div").filter(
            has_text=re.compile(f"^highlight_offadd_circle{equipment_type}$")
        ).get_by_role("textbox")
        textbox_locator.click()
        textbox_locator.fill(equipment_id)
        textbox_locator.press("Enter")
        self.page.wait_for_timeout(1000)
        input_element = self.page.locator("span.input-field-wrapper input[type='text']").nth(index)
        input_value = input_element.input_value()
        check.is_true(expected_value in input_value, f"Expected input to contain '{expected_value}', but got: '{input_value}'")

    def verify_toast_message(self, expected_message="Date entered has passed, please choose another one"):
        toast_locator = self.page.locator(".toast").filter(has_text="Notification")
        toast_locator.wait_for(state="visible", timeout=5000)
        toast_description = toast_locator.locator(".description")
        actual_message = toast_description.text_content().strip()
        check.equal(actual_message, expected_message, f"Expected toast message: '{expected_message}', but got: '{actual_message}'")
        warning_status = toast_locator.locator(".toast--status.warning")
        check.is_true(warning_status.is_visible(), "Toast should be a warning notification")
        close_button = toast_locator.locator(".toast--close i")
        if close_button.is_visible():
            close_button.click()
            toast_locator.wait_for(state="hidden", timeout=3000)

    def select_date_from_date_picker(self, field_name: str, test_outdated=True, date_format="MMM YYYY"):
        date_input = self.page.locator(f'label[title="{field_name}"]').locator('..').locator("input.flatpickr-input[data-input='true']")
        date_input.click()
        self.page.wait_for_timeout(500)
        if test_outdated:
            self._select_outdated_date()
            date_input.click()
            self.page.wait_for_timeout(500)
        self._select_current_date()
        self._verify_date_format(date_input, expected_format=date_format)

    def _select_outdated_date(self):
        self.page.wait_for_selector(self.calender_locator, state="visible", timeout=10000)
        self.page.wait_for_timeout(500)
        self.page.locator(".flatpickr-calendar.open .flatpickr-prev-month").click()
        self.page.wait_for_timeout(500)
        day_selector = ".flatpickr-calendar.open .flatpickr-day:not(.prevMonthDay):not(.nextMonthDay)"
        days = self.page.locator(day_selector)
        for i in range(days.count()):
            if days.nth(i).inner_text().strip() == "15":
                days.nth(i).click()
                return
        if days.count() > 0:
            days.first.click()

    def _select_current_date(self):
        self.page.wait_for_selector(self.calender_locator, state="visible", timeout=10000)
        self.page.wait_for_timeout(500)
        self.page.locator(".flatpickr-calendar.open .flatpickr-next-month").click()
        self.page.wait_for_timeout(500)
        today_selector = ".flatpickr-calendar.open .flatpickr-day.today"
        if self.page.locator(today_selector).count() > 0:
            self.page.locator(today_selector).click()
        else:
            current_month_days = ".flatpickr-calendar.open .flatpickr-day:not(.prevMonthDay):not(.nextMonthDay)"
            self.page.locator(current_month_days).first.click()

    def _verify_date_format(self, field_element, expected_format="MMM YYYY"):
        field_value = field_element.input_value()
        format_patterns = {
            "MMM YYYY": r'^[A-Za-z]{3}\s\d{4}$',                    # Oct 2024
            self.dd_mm_yyyy_format: r'^\d{1,2}\s[A-Za-z]{3}\s\d{4}$',       # 23 Oct 2024
            "DD MMM YYYY CT": r'^\d{1,2}\s[A-Za-z]{3}\s\d{4},\s\d{1,2}:\d{2}\sCT$',  # 23 Oct 2025, 12:00 CT
            "DD MMM YYYY CT 1": r'^\d{1,2}\s[A-Za-z]{3}\s\d{4}\s\d{1,2}:\d{2}\sCT$',  # 23 Oct 2025 12:00 CT
            "MM/DD/YYYY": self.mm_dd_yyyy_format,              # 10/23/2024
            "DD/MM/YYYY": self.mm_dd_yyyy_format,              # 23/10/2024
            "YYYY-MM-DD": r'^\d{4}-\d{1,2}-\d{1,2}$',              # 2024-10-23
            "DD-MM-YYYY": r'^\d{1,2}-\d{1,2}-\d{4}$',              # 23-10-2024
        }
        if expected_format not in format_patterns:
            raise ValueError(f"Unsupported date format: {expected_format}. Supported formats: {list(format_patterns.keys())}")
        date_pattern = format_patterns[expected_format]
        check.is_true(bool(re.match(date_pattern, field_value)), f"Date format should be {expected_format}, but got: '{field_value}'")

    def verify_picklist_options(self, field_name, expected_options, final_selection=None):
        self.dismiss_overlay_if_present()
        field_container = self.page.locator(f'label[title="{field_name}"]').locator('..')
        self.page.wait_for_timeout(1000)
        field_container.get_by_role("combobox").click()
        dropdown = field_container.get_by_role("combobox")
        for option in expected_options:
            dropdown.select_option(option)
            selected = dropdown.input_value()
            check.equal(selected, option, f"Option '{option}' not available in {field_name}")
        if final_selection:
            dropdown.select_option(final_selection)
        return True

    def verify_picklist_options_with_text_strip(self, field_name, expected_options, final_selection=None):
        self.dismiss_overlay_if_present()
        field_container = self.page.locator(f'label[title="{field_name}"]').locator('..')
        self.page.wait_for_timeout(1000)
        field_container.get_by_role("combobox").click()
        dropdown = field_container.get_by_role("combobox")
        for option in expected_options:
            dropdown.select_option(option)
            selected = dropdown.locator("option:checked").text_content().strip()
            check.equal(selected, option, f"Option '{option}' not available in {field_name}")
        if final_selection:
            dropdown.select_option(final_selection)
        return True
    
    def verify_checkbox(self, checkbox_label):
        self.page.get_by_text(checkbox_label).click()
        escaped_label = re.escape(checkbox_label)
        pattern = f"^highlight_offadd_circle{escaped_label}$"
        checkbox_locator = self.page.locator("div").filter(has_text=re.compile(pattern)).get_by_role("checkbox")
        checkbox_locator.check()
        check.is_true(checkbox_locator.is_checked(), f"Checkbox '{checkbox_label}' should be checked")
        checkbox_locator.uncheck()
        check.is_false(checkbox_locator.is_checked(), f"Checkbox '{checkbox_label}' should be unchecked")
        checkbox_locator.check()
        check.is_true(checkbox_locator.is_checked(), f"Checkbox '{checkbox_label}' should be checked again")
        return True

    def verify_checkbox_3520(self, checkbox_label):
        self.page.get_by_text(checkbox_label).click()
        block = self.page.locator(".block-content").filter(
            has=self.page.locator(f'label[title="{checkbox_label}"]')
        )
        checkbox_locator = block.locator("input[type='checkbox']")
        checkbox_locator.check()
        check.is_true(checkbox_locator.is_checked(), f"Checkbox '{checkbox_label}' should be checked")
        checkbox_locator.uncheck()
        check.is_false(checkbox_locator.is_checked(), f"Checkbox '{checkbox_label}' should be unchecked")
        checkbox_locator.check()
        check.is_true(checkbox_locator.is_checked(), f"Checkbox '{checkbox_label}' should be checked again")
        return True
     
    
    def verify_instruction_content(self, key_phrases_list, instruction_locator="[data-v-f5d4a7bf].instruction"):
        instruction_element = self.page.locator(instruction_locator)
        instruction_element.wait_for(state="visible", timeout=10000)
        instruction_text = instruction_element.text_content().strip()
        is_read_only = instruction_element.get_attribute("is-read-only")
        check.equal(is_read_only, "false", f"Expected read-only to be 'false', but got: '{is_read_only}'")
        missing_phrases = []
        found_phrases = []
        for phrase in key_phrases_list:
            if phrase in instruction_text:
                found_phrases.append(phrase)
            else:
                missing_phrases.append(phrase)
        check.equal(len(missing_phrases), 0, f"Missing {len(missing_phrases)} key phrases: {missing_phrases}")
        return True
    
    def upload_file(self, file_path):
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
        self.page.get_by_text("File Attachment").click()
        self.page.get_by_role("button", name="Attach File").click()
        self.page.get_by_role("button", name="Choose File").set_input_files(file_path)
        self.page.wait_for_timeout(1000)
        return True

    def handle_inventory_item(self, field_name: str, expected_item_type: str, quantity_to_remove: int):
        field_locator = self.page.locator("div").filter(has_text=re.compile(rf"^highlight_offadd_circle{re.escape(field_name)}$"))
        textbox = field_locator.get_by_role("textbox")
        textbox.click()
        modal = self.page.locator('[data-test="overlay__modal-container"]').filter(has_text="Inventory Item Editor")
        modal.wait_for(state="visible")
        item_field = self.page.locator("span.multiselect__single")
        actual_item_type = item_field.text_content().strip()
        check.equal(actual_item_type, expected_item_type, f"Expected item type: {expected_item_type}, Got: {actual_item_type}")
        quantity_input = modal.locator('input[name="remove"]')
        quantity_input.fill(str(quantity_to_remove))
        save_button = modal.locator('button:has-text("Save")')
        save_button.click()
        modal.wait_for(state="hidden")
        field_value = textbox.input_value()
        check.is_true(len(field_value) > 0, f"Field {field_name} should reflect quantity change")

    def add_samples(self,sample_type: str, num_samples: int, max_samples: int = 3, button_index: int = 0):
        check.is_true(1 <= num_samples <= max_samples, f"Number of samples must be between 1-{max_samples}, got {num_samples}")
        add_button = self.page.locator('button .label:has-text("Add")').locator('..').nth(button_index)
        check.is_true(add_button.is_visible(), f"Add button at index {button_index} should be visible")
        add_button.click()
        add_new_samples_button = self.page.get_by_role("button", name="Add new samples")
        check.is_true(add_new_samples_button.is_visible(), "Add new samples button should be visible")
        add_new_samples_button.click()
        number_input = self.page.locator('input.num-entities-input').first
        number_input.click()
        number_input.fill(str(num_samples))
        check.equal(number_input.input_value(), str(num_samples),
            f"Failed to enter number of samples: expected {num_samples} of {sample_type}, got {number_input.input_value()}")
        self.page.wait_for_timeout(1000)
        register_button = self.page.get_by_role("button", name=f"Register ({num_samples})")
        register_button.wait_for(state="visible", timeout=5000)
        check.is_true(register_button.is_visible(), f"Register ({num_samples}) button should be visible")
        check.is_true(register_button.is_enabled(), f"Register ({num_samples}) button should be enabled")
        register_button.click()

        sample_id_header = self.page.locator('.ag-header-cell-text:has-text("Sample ID")')
        if sample_id_header.count() > 0:
            check.is_true(sample_id_header.is_visible(), "Sample ID column should be visible in the grid")

        close_button = self.page.get_by_role("button", name="Close")
        check.is_true(close_button.is_visible(), "Close button should be visible")
        close_button.click()
        return True
    
    def dismiss_overlay_if_present(self):
        overlay_selectors = [
            ".overlay",
            ".modal",
            ".loading",
            ".spinner",
            "[data-testid*='overlay']",
            ".backdrop"
        ]
        
        for selector in overlay_selectors:
            overlay = self.page.locator(selector)
            if overlay.count() > 0 and overlay.first.is_visible():
                close_selectors = [
                    f"{selector} [data-test*='close']",
                    f"{selector} .close",
                    f"{selector} button:has-text('Close')",
                    f"{selector} button:has-text('×')",
                    f"{selector} .close-btn"
                ]
                for close_selector in close_selectors:
                    close_btn = self.page.locator(close_selector)
                    if close_btn.count() > 0:
                        close_btn.first.click()
                        self.page.wait_for_timeout(500)
                        return
                overlay.first.press("Escape")
                self.page.wait_for_timeout(500)
                return
        self.page.wait_for_timeout(200)
    
    def set_date_field_with_validation(self, header: str, date_type: str, expected_format: str = "DD MMM YYYY"):
        format_patterns = {
            "MMM YYYY": r'^[A-Za-z]{3}\s\d{4}$',
            self.dd_mm_yyyy_format: r'^\d{1,2}\s[A-Za-z]{3}\s\d{4}$',
            "DD MMM YYYY CT": r'^\d{1,2}\s[A-Za-z]{3}\s\d{4},\s\d{1,2}:\d{2}\sCT$',
            "DD MMM YYYY CT 1": r'^\d{1,2}\s[A-Za-z]{3}\s\d{4}\s\d{1,2}:\d{2}\sCT$',
            "MM/DD/YYYY": self.mm_dd_yyyy_format,
            "DD/MM/YYYY": self.mm_dd_yyyy_format,
            "YYYY-MM-DD": r'^\d{4}-\d{1,2}-\d{1,2}$',
            "DD-MM-YYYY": r'^\d{1,2}-\d{1,2}-\d{4}$',
        }
        if expected_format not in format_patterns:
            raise ValueError(f"Unsupported date format: {expected_format}")
        if date_type.lower() not in ["outdated", "future"]:
            raise ValueError(f"Invalid date_type: {date_type}")
        date_pattern = format_patterns[expected_format]

        if date_type.lower() == "outdated":
            toast_message = "Date entered has passed"
            navigation_selector = self.flatpicker_prev_month
            return_navigation_selector = self.flatpicker_next_month
        else:  # future
            toast_message = "Date cannot be in the future"
            navigation_selector = self.flatpicker_next_month
            return_navigation_selector = self.flatpicker_prev_month
        label = self.page.get_by_text(header, exact=True)
        container = label.locator(self.xpath_ancestor_block_content)
        date_input = container.locator(self.text_input).first
        date_input.wait_for(state="visible", timeout=10000)
        date_input.scroll_into_view_if_needed()
        date_input.click(force=True)
        calendar = self.page.locator(self.calender_locator)
        calendar.wait_for(state="visible", timeout=10000)
        existing_toasts = self.page.locator(self.toast_main_panel, has_text=toast_message).count()
        navigation_btn = calendar.locator(navigation_selector)
        navigation_btn.wait_for(state="visible", timeout=5000)
        navigation_btn.click()
        self.page.wait_for_timeout(500)
        today_day = datetime.today().day
        day_selector = f".flatpickr-day:not(.prevMonthDay):not(.nextMonthDay):has-text('{today_day}')"
        calendar.locator(day_selector).first.click()
        date_input.blur()
        self.page.wait_for_timeout(500)
        value = date_input.input_value()
        check.is_true(re.match(date_pattern, value), 
                    f"Date format should be {expected_format}, but got: '{value}'")
        self.page.wait_for_timeout(1000)
        new_toasts = self.page.locator(self.toast_main_panel, has_text=toast_message).count()
        check.is_true(new_toasts > existing_toasts, 
                    f"Toast for {date_type} date did not appear")
        date_input.click(force=True)
        calendar.wait_for(state="visible", timeout=10000)
        return_btn = calendar.locator(return_navigation_selector)
        return_btn.wait_for(state="visible", timeout=5000)
        return_btn.click()
        self.page.wait_for_timeout(500)
        today_element = calendar.locator(".flatpickr-day.today")
        today_element.wait_for(state="visible", timeout=5000)
        today_element.click()
        self.page.wait_for_timeout(1000)
        updated_value = date_input.input_value()
        check.is_true(re.match(date_pattern, updated_value),
                    f"Final date format should be {expected_format}, but got: '{updated_value}'")
        
    def set_date_field_by_header(self, header: str):
        label = self.page.get_by_text(header, exact=True)
        container = label.locator(self.xpath_ancestor_block_content)
        date_input = container.locator(self.text_input).first
        date_input.click()
        calendar = self.page.locator(self.calender_locator).first
        calendar.wait_for(state="visible")
        prev_month_btn = calendar.locator(self.flatpicker_next_month)
        prev_month_btn.wait_for(state="visible")
        existing_toasts = self.page.locator(self.toast_main_panel, has_text="Date entered has passed").count()
        prev_month_btn.click()
        today_day = datetime.today().day
        calendar.get_by_text(str(today_day), exact=True).first.click()
        date_input.blur()  
        value = date_input.input_value()
        check.is_true(
            value is not None and (
                re.match(r"^[A-Z][a-z]{2} \d{4}$", str(value)) or 
                re.match(r"^\d{1,2}\s[A-Za-z]{3}\s\d{4},\s\d{1,2}:\d{2}\sCT$", str(value)) or 
                re.match(r"^(\d{2} )?[A-Z][a-z]{2} \d{4}$", str(value)) or 
                re.match(r"^\d{1,2}\s[A-Za-z]{3}\s\d{4}\s\d{1,2}:\d{2}\sCT$", str(value))
            ),
            f"Unexpected date format: {value}"
        )
        self.page.wait_for_timeout(500)
        new_toasts = self.page.locator(self.toast_main_panel, has_text="Date cannot be in the future").count()
        check.is_true(new_toasts > existing_toasts, f"Toast for future date did not appear in DOM (existing {existing_toasts}, now {new_toasts})")
        self.page.locator("i.esp-icons", has_text="close")
        self.page.wait_for_timeout(1000)
        date_input.click()
        calendar = self.page.locator(self.calender_locator).first
        calendar.wait_for(state="visible")
        next_month_btn = calendar.locator(self.flatpicker_prev_month)
        next_month_btn.wait_for(state="visible")
        next_month_btn.click()
        today_day = datetime.today().day
        calendar.get_by_text(str(today_day), exact=True).first.click()
        self.page.wait_for_timeout(2000)
        check.is_true(
            value is not None and (
                re.match(r"^[A-Z][a-z]{2} \d{4}$", str(value)) or 
                re.match(r"^\d{1,2}\s[A-Za-z]{3}\s\d{4},\s\d{1,2}:\d{2}\sCT$", str(value)) or 
                re.match(r"^(\d{2} )?[A-Z][a-z]{2} \d{4}$", str(value)) or 
                re.match(r"^\d{1,2}\s[A-Za-z]{3}\s\d{4}\s\d{1,2}:\d{2}\sCT$", str(value))
            ),
            f"Unexpected date format: {value}"
        )

    def sign_off2(self, signature_type: str, username: str = USER, password: str = PASSWORD, index: int = 0):
        form = self.page.locator("form").filter(has_text=signature_type).nth(index)
        form.get_by_placeholder("username").fill(username)
        form.get_by_placeholder("password").fill(password)
        form.get_by_role("button").click()
        Networking.interceptor(self.page, "/rollup", 200)
        signed_user_locator = self.page.locator(f"text={username}")
        check.greater(signed_user_locator.count(),0,f"Signed-in user '{username}' not found in Tech workgroup")

    def set_date_time(self, header: str):
        label = self.page.get_by_text(header, exact=True)
        container = label.locator(self.xpath_ancestor_block_content)
        date_input = container.locator(self.text_input).first
        date_input.click()
        calendar = self.page.locator(self.calender_locator).first
        calendar.wait_for(state="visible")
        today_day = datetime.today().day
        calendar.get_by_text(str(today_day), exact=True).first.click()
        date_input.blur()  
        value = date_input.input_value()
        def is_valid_datetime_format(date_str):
            if not date_str:
                return False
            cleaned = str(date_str).strip()
            patterns = [
                r"^\d{1,2}\s+[A-Za-z]{3}\s+\d{4},\s+\d{1,2}:\d{2}\s+CT$",  # "02 Jan 2026, 12:00 CT"
                r"^\d{1,2}\s+[A-Za-z]{3}\s+\d{4}\s+\d{1,2}:\d{2}\s+CT$",   # "02 Jan 2026 12:00 CT"
                r"^\d{1,2}[A-Za-z]{3}\d{4}$",                                 # "13May2026"
            ]
            return any(re.match(pattern, cleaned) for pattern in patterns)
        check.is_true(
            is_valid_datetime_format(value),
            f"Unexpected date format: '{value}'"
        )
        self.page.wait_for_timeout(500)
    
    def numeric_within_range_field(self, header_name, value):
        header = self.page.get_by_text(header_name, exact=True)
        container = header.locator(self.xpath_ancestor_block_content)
        spin_input = container.get_by_role("spinbutton").first
        field = container.locator(self.text_input).first
        field.click()
        spin_input.fill(str(value))
        header.click()
        self.page.wait_for_timeout(1000)
        actual_value = field.input_value().replace(',', '')
        check.is_true(str(value) == actual_value, f"Value mismatch. Expected: '{value}', Actual: '{field.input_value()}'")
    
    def sign_signature(self, signature_type: str, username: str = "admin@localhost", password: str = "password"):
        """Signs a signature for specific type (e.g., 'Performed by', 'Verified by')"""
        form = self.page.locator("form").filter(has_text=signature_type)
        form.get_by_placeholder("username").fill(username)
        form.get_by_placeholder("password").fill(password)
        form.get_by_role("button").click()
        Networking.interceptor(self.page, "/rollup", 200)
        signed_user_locator = self.page.locator(f"text={username}")
        check.greater(signed_user_locator.count(),0,f"Signed-in user '{username}' not found in Tech workgroup")

    def sign_signature_by_label(self, signature_type: str, username: str = "admin@localhost", password: str = "password"):
        """Signs a signature block located by label title (e.g., 'Issued By (QA)').
        Use when the label is outside the form element so filter(has_text=) won't match."""
        block = self.page.locator(f'label[title="{signature_type}"]').locator(self.xpath_ancestor_block_content)
        form = block.locator("form")
        form.locator("input.username").fill(username)
        form.locator("input.password").fill(password)
        form.get_by_role("button", name="Sign").click()
        Networking.interceptor(self.page, "/rollup", 200)
        signed_user_locator = self.page.locator(f"text={username}")
        check.greater(signed_user_locator.count(), 0, f"Signed-in user '{username}' not found after signing '{signature_type}'")
        
    def verify_numerical_field(self, header_name,unit=None):
        header = self.page.get_by_text(header_name, exact=True)
        container = header.locator(self.container)
        spin_input = container.get_by_role("spinbutton").first
        field = container.locator(self.text_field).first
        field.click()
        spin_input.fill("23")
        spin_input.press("Enter")
        check.is_true(spin_input.input_value() == "23", "The field is not accepting numerical input")
        validity = spin_input.evaluate("el => el.validity.valid")
        check.is_true(validity, "The field is accepting invalid input (non-numerical)")
        if unit:
            unit_span = container.locator(f"div:has-text('{unit}')").nth(0)
            check.is_true(unit_span.is_visible(), f"The field '{header_name}' does not show unit '{unit}'")
        header.click()
    

    def set_batch_size(self, header_name, batch_size="23"):
        header = self.page.get_by_text(header_name, exact=True)
        container = header.locator(self.container)
        spin_input = container.get_by_role("spinbutton").first
        field = container.locator(self.text_field).first
        field.click()
        spin_input.fill(str(batch_size))
        spin_input.press("Enter")
    
    def select_save_ebr(self):
        self.page.get_by_role("button", name="Save").click()