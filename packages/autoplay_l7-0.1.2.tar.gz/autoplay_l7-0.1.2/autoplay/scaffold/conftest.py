import os
import pytest
import logging
import subprocess
import re
from pathlib import Path

from playwright.sync_api import sync_playwright
from utils.commands import seed, seed_teardown

try:
    from screeninfo import get_monitors
except ImportError:
    get_monitors = None

HEADLESS = os.getenv("PLAYWRIGHT_HEADLESS", "true") == "true"
VIDEO_CAPTURE = os.getenv("PLAYWRIGHT_CAPTURE_VIDEO", "false") == "true"
PLAYWRIGHT_REPORT = os.getenv("PLAYWRIGHT_REPORT", "false") == "true"
REPORT_PATH = "test-report"

# Worker isolation — every parallel container gets its own namespace
WORKER_ID    = os.getenv("WORKER_ID", "worker_default")
FIXTURE_FILE = f"fixtures_{WORKER_ID}.txt"   # e.g. fixtures_worker_a.txt

# Seed file can be overridden per pipeline run
SEED_FILE = os.getenv("SEED_FILE", "index_seed.yml")


# ── Database seed: runs ONCE per test session, even with -n workers ──────────
#
# Problem solved: with pytest-xdist each worker is a separate process.
# A package-scoped autouse fixture runs once *per worker per package* —
# every worker would hit seed() and seed_teardown() concurrently, causing
# duplicate-key errors and partial teardowns.
#
# Fix: session scope + an fcntl-protected sentinel file so only the first
# arriving worker seeds, and only the last departing worker tears down.

@pytest.fixture(scope="session", autouse=True)
def initial_seed():
    """
    Session-scoped seed: runs once when the worker container starts,
    torn down after all tests in this worker complete.
    Seeds base entities and items first, then the index seed.
    """
    print(f"\n[{WORKER_ID}] Seeding entities, items, and {SEED_FILE} ...")
    seed(SEED_FILE)
    yield
    print(f"\n[{WORKER_ID}] Teardown seed {SEED_FILE}, items, entities ...")
    seed_teardown(SEED_FILE)



# ── Browser: one per worker process (session scope is correct here) ──────────

@pytest.fixture(scope="session")
def browser():
    with sync_playwright() as p:
        browser = p.chromium.launch(
            headless=HEADLESS,
            args=["--disable-blink-features=AutomationControlled"],
        )
        yield browser
        browser.close()

# ── Test outcome tracking ──────────────────────────────────────────────────────
@pytest.hookimpl(tryfirst=True, hookwrapper=True)
def pytest_runtest_makereport(item):
    outcome = yield
    rep = outcome.get_result()
    setattr(item, "rep_" + rep.when, rep)


# ── Page: one per test, each worker has its own browser ─────────────────────

# ── Page ───────────────────────────────────────────────────────────────────────
@pytest.fixture(scope="function", autouse=True)
def page(browser, request):
    context_options = {}
    if VIDEO_CAPTURE:
        os.makedirs(f"{REPORT_PATH}/video", exist_ok=True)
        context_options["record_video_dir"] = f"{REPORT_PATH}/video"

    context = browser.new_context(**context_options)

    # Track all extra pages opened in this context (popups / new tabs)
    extra_pages = []
    if VIDEO_CAPTURE:
        context.on("page", lambda p: extra_pages.append(p))

    page = context.new_page()
    yield page

    if VIDEO_CAPTURE and page.video:
        nodeid_split = request.node.nodeid.split("::")
        tx_folder  = nodeid_split[0].split("/")[-2]   # e.g. TX_5048
        test_func  = nodeid_split[-1]                  # e.g. test_post_decontamination
        test_id    = f"{tx_folder}-{test_func}"

        # ── Rename all videos BEFORE context.close() so Playwright finalizes
        #    each file under its new name (Linux/macOS rename keeps the fd open).

        # Main page
        try:
            main_path = page.video.path()
            new_path  = os.path.join(f"{REPORT_PATH}/video", f"{WORKER_ID}-{test_id}.webm")
            os.rename(main_path, new_path)
            logging.info(f"[{WORKER_ID}] Video → {new_path}")
        except Exception as e:
            logging.warning(f"[{WORKER_ID}] Could not rename main video: {e}")

        # Popup / new-tab pages (tab2, tab3, …)
        tab_num = 2
        for extra in (p for p in extra_pages if p is not page):
            if extra.video:
                try:
                    extra_path = extra.video.path()
                    extra_new  = os.path.join(
                        f"{REPORT_PATH}/video",
                        f"{WORKER_ID}-{test_id}-tab{tab_num}.webm"
                    )
                    os.rename(extra_path, extra_new)
                    logging.info(f"[{WORKER_ID}] Popup video → {extra_new}")
                    tab_num += 1
                except Exception as e:
                    logging.warning(f"[{WORKER_ID}] Could not rename popup video: {e}")

    context.close()   # finalizes all videos at their (already-renamed) paths


# ── Page auto-setup ────────────────────────────────────────────────────────────
@pytest.fixture(scope="function", autouse=True)
def setup_page(request, page):
    print(f"\n[{WORKER_ID}] Initializing page for test")
    if hasattr(request, "instance"):
        request.instance.page = page
    yield page
    print(f"\n[{WORKER_ID}] Cleaning up page fixture")

# ── Allure environment ─────────────────────────────────────────────────────────
ALLURE_RESULTS_DIR  = "allure-results"
_CACHED_ESP_VERSION = None

def get_esp_version():
    global _CACHED_ESP_VERSION
    if _CACHED_ESP_VERSION is not None:
        return _CACHED_ESP_VERSION
    env_version = os.getenv("L7ESP_VERSION")
    if env_version:
        _CACHED_ESP_VERSION = env_version
        return _CACHED_ESP_VERSION
    for cmd in ["esp version", "docker compose exec -T server esp version"]:
        try:
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=15)
            output = (result.stdout or "") + (result.stderr or "")
            match  = re.search(r'(\d{1,5}\.\d{1,5}\.\d{1,5})', output)
            if match:
                _CACHED_ESP_VERSION = match.group(1)
                return _CACHED_ESP_VERSION
        except ValueError:
            continue
    _CACHED_ESP_VERSION = "Unknown"
    return _CACHED_ESP_VERSION

def get_project_name():
    ci_project = os.getenv("BITBUCKET_REPO_SLUG") or os.getenv("PROJECT_NAME")
    if ci_project:
        return ci_project
    path = Path.cwd()
    for parent in path.parents:
        if parent.name.lower() == "tests":
            return parent.parent.name
    return path.name

def pytest_configure(config):
    if PLAYWRIGHT_REPORT:
        os.makedirs(f"{REPORT_PATH}/report", exist_ok=True)
        config.option.htmlpath = f"{REPORT_PATH}/report/report.html"

def pytest_sessionstart(session):
    os.makedirs(ALLURE_RESULTS_DIR, exist_ok=True)
    env_file = os.path.join(ALLURE_RESULTS_DIR, "environment.properties")
    with open(env_file, "w", encoding="utf-8") as f:
        f.write(f"ESP Version = {get_esp_version()}\n")
        f.write(f"Project = {get_project_name()}\n")
        f.write(f"Environment = {os.getenv('TEST_ENV', 'QA')}\n")
        f.write(f"Worker = {WORKER_ID}\n")   # handy for debugging shards
