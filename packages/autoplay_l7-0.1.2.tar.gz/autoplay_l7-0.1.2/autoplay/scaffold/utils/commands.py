import os
import subprocess
from pathlib import Path

from pages.base_page import HOST, PORT

def ensure_yaml_file(filepath, prefix=None):
    fixtures_folder = "./fixtures" if os.getenv("DOCKER_MODE", "false").lower() != "true" else os.getenv(
        "FIXTURES_FOLDER", "./tests/automation/fixtures")
    # Remove leading `/` if present
    filepath = filepath.lstrip("/")
    full_path = Path(fixtures_folder) / filepath if not prefix else Path(fixtures_folder) / prefix / filepath

    # Add .yml extension if not already present
    if not full_path.suffix in [".yaml", ".yml"]:
        full_path = full_path.with_suffix(".yml")

    if os.getenv("DOCKER_MODE", "false").lower() != "true":
        if not full_path.exists():
            raise FileNotFoundError(f"Seed file {full_path} does not exist.")
    else:
        result = subprocess.run(
            f"docker compose exec server ls {full_path}", shell=True, capture_output=True, text=True
        )

        if "No such file or directory" in result.stderr:
            raise FileNotFoundError(f"Seed file {full_path} does not exist.")

    return str(full_path)


def exec_command(command, log=False, env=None, fail_on_non_zero_exit=True, timeout=None):
    env_vars = os.environ.copy()
    if env:
        env_vars.update(env)

    try:
        result = subprocess.run(
            command, shell=True, capture_output=True, text=True, timeout=timeout, env=env_vars
        )
        if log:
            print(f"Command executed: {command}")
            print(f"STDOUT: {result.stdout}")
            print(f"STDERR: {result.stderr}")
        # Raise exception if the command fails and `fail_on_non_zero_exit` is True
        if fail_on_non_zero_exit and result.returncode != 0:
            error_message = (
                f"`exec('{command}')` failed because the command exited with a non-zero code.\n"
                f"Code: {result.returncode}\nStdout: {result.stdout}\nStderr: {result.stderr}"
            )
            raise RuntimeError(error_message)
        return result
    except subprocess.TimeoutExpired as e:
        raise RuntimeError(f"Command timed out: {command}")


def build_esp_command(cmd, **cmd_options):
    if os.getenv("DOCKER_MODE", "false").lower() == "true":
        # Docker-based execution
        command_parts = ["docker", "compose", "exec", "server", "esp"]
    else:
        # Native execution
        command_parts = ["esp"]

    if cmd_options.get("port") in ["8080", "8002"]:
        cmd_options["port"] = PORT

    for key, value in cmd_options.items():
        if value:
            command_parts += [f"--{key.replace('_', '-')}", str(value)]

    command_parts.append(cmd)
    return " ".join(command_parts)


def exec_esp(command, common_options=None, exec_options=None):
    common_options = common_options or {}
    exec_options = exec_options or {}
    default_esp_options = {
        "host": HOST,
        "port": PORT,
        "user": os.environ.get("ESP_USER"),
        "password": os.environ.get("ESP_PASSWORD"),
    }
    esp_options = {**default_esp_options, **common_options}

    esp_command = build_esp_command(command, **esp_options)
    return exec_command(esp_command, **exec_options)


def seed(config, command_options=None, common_options=None, exec_options=None):
    command_options = command_options or {"fixture_prefix": ""}
    exec_options = exec_options or {"timeout": 360000}
    fixture_path = ensure_yaml_file(config, command_options.get("fixture_prefix"))
    command_parts = ["seed"]

    for key, value in command_options.items():
        if value:
            command_parts.append(f"--{key.replace('_', '-')}")
    command_parts.append(fixture_path)

    command = " ".join(command_parts)
    exec_esp(command, common_options, exec_options)


def seed_teardown(config):
    seed(config, command_options={"drop": True, "deep": True},
         exec_options={"timeout": 360000, "fail_on_non_zero_exit": False})


def run_custom_python_script(python_file_name: str, script_dir: str):
    """
        Runs a custom Python script either in Docker or native mode.
    """
    is_docker = os.getenv("DOCKER_MODE", "false").lower() == "true"

    if is_docker:
        # Docker-based command
        command = f"docker compose exec server bash -c 'cd {script_dir} && /opt/l7esp/data/extensions/client/bin/python {python_file_name}'"
    else:
        # Native/local command
        full_path = os.path.join(script_dir, python_file_name)
        command = f"python {full_path}"

    return exec_command(command, log=True)

def run_esp_with_path_command(command_name, path, **options):
    """
    Runs an ESP Command from a specified directory (`cd <path>` first).

    Parameters:
        command_name (str): The ESP command to run (e.g., `dump`).
        path (str): The directory where the command should be executed.
        options (dict): Additional options for the ESP command.

    Example:
        run_esp_with_path_command("dump", "/data/models", model="Sample")
    """
    # Build the ESP command
    esp_command = build_esp_command(command_name, **options)

    # Determine Docker mode
    if os.getenv("DOCKER_MODE", "false").lower() == "true":
        # Docker-based execution with directory change
        docker_command = f"docker compose exec server bash -c 'cd {path} && {esp_command}'"
        return exec_command(docker_command, log=True)
    else:
        # Native execution with directory change
        native_command = f"cd {path} && {esp_command}"
        return exec_command(native_command, log=True)


def exec_psql_shell(sql_command):
    """
    Executes SQL command in PostgreSQL interactive shell either in Docker or native environment.

    Parameters:
        sql_command (str): The SQL command to execute
    """
    if os.getenv("DOCKER_MODE", "false").lower() == "true":
        # Docker-based execution
        command = f"docker compose exec server bash -c 'echo \"{sql_command}\" | psql'"
    else:
        # Native execution
        command = f"echo \"{sql_command}\" | psql"

    return exec_command(command, log=True)


def run_esp_dump(model, path):
    # Determine Docker mode
    if os.getenv("DOCKER_MODE", "false").lower() == "true":
        # Docker-based execution with directory change
        docker_command = f"docker compose exec server bash -c 'cd {path} && esp dump --model {model}'"
        return exec_command(docker_command, log=True)
    else:
        # Native execution with directory change
        native_command = f"cd {path} && esp dump --model {model}"
        return exec_command(native_command, log=True)