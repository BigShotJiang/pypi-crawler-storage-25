class Networking:
    @staticmethod
    def interceptor(page, target_url, status_code, max_attempts=5, retry_interval=1000, timeout_per_attempt=60000):
        attempts = 0
        while attempts < max_attempts:
            attempts += 1
            intercepted_response = page.wait_for_event(
                "response",
                lambda response: target_url in response.url and response.status == status_code,
                timeout=timeout_per_attempt
            )
            if intercepted_response:
                return intercepted_response
            page.wait_for_timeout(retry_interval)
        return None