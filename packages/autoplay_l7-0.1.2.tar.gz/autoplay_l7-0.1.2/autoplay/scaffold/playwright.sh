#!/bin/bash
set -e


: "${ESP_HOST:="127.0.0.1"}"
: "${ESP_PORT:="$(python3 -c 'import sys; sys.path.insert(0, "."); from pages.base_page import DEFAULT_PORT; print(DEFAULT_PORT)' 2>/dev/null || echo "8002")"}"
: "${ESP_USER:="admin@localhost"}"
: "${ESP_PASSWORD:="password"}"
: "${PLAYWRIGHT_HEADLESS:="false"}"
: "${PLAYWRIGHT_REPORT:="false"}"
: "${PLAYWRIGHT_SPEC_PATTERN:="e2e/**/*.py"}"
: "${PLAYWRIGHT_TAGS:="-@skip"}"
: "${PLAYWRIGHT_CAPTURE_VIDEO:="false"}"
: "${DOCKER_MODE:="false"}"
: "${FIXTURES_FOLDER:="./tests/automation/fixtures"}"

usage() {
    echo "Usage: $0 [options]
Options:
  -h  Help
  -H  ESP Host (default: $ESP_HOST)
  -P  ESP Port (default: $ESP_PORT)
  -u  ESP User (default: $ESP_USER)
  -X  ESP Password (default: $ESP_PASSWORD)
  -r  Run in headed mode
  -d  Generate HTML report
  -t  Specific subset of specs to run
  -g  Specific tag/s to run
  -c  Capture video
  -D  Docker Mode (default: $DOCKER_MODE)
  -n  Parallel Workers
"
    exit 1
}

while getopts ":hH:P:u:X:rdt:g:cDn" opt; do
    case $opt in
        h) usage ;;
        H) ESP_HOST=$OPTARG ;;
        P) ESP_PORT=$OPTARG ;;
        u) ESP_USER=$OPTARG ;;
        X) ESP_PASSWORD=$OPTARG ;;
        r) PLAYWRIGHT_HEADLESS="true" ;;
        d) PLAYWRIGHT_REPORT="true" ;;
        t) PLAYWRIGHT_SPEC_PATTERN="$OPTARG" ;;
        g) PLAYWRIGHT_TAGS="$OPTARG" ;;
        c) PLAYWRIGHT_CAPTURE_VIDEO="true" ;;
        D) DOCKER_MODE="true" ;;
        n) PLAYWRIGHT_WORKERS="$OPTARG" ;;
        *) usage ;;
    esac
done
shift $((OPTIND -1))

export ESP_HOST
export ESP_PORT
export ESP_USER
export ESP_PASSWORD
export DOCKER_MODE
export FIXTURES_FOLDER
export PLAYWRIGHT_HEADLESS
export PLAYWRIGHT_REPORT
export PLAYWRIGHT_SPEC_PATTERN
export PLAYWRIGHT_TAGS
export PLAYWRIGHT_CAPTURE_VIDEO
export PLAYWRIGHT_WORKERS

# Check dependencies
if ! python -c 'import playwright' &>/dev/null; then
    echo "Playwright is not installed. Please run 'pip install playwright' and 'playwright install'"
    exit 1
fi

# Prepare report directories
rm -rf test-report/video test-report/report > /dev/null
rm -rf allure-results > /dev/null
rm -rf allure-report > /dev/null

echo "Running Playwright tests with configuration:"
echo "ESP_HOST: $ESP_HOST"
echo "ESP_PORT: $ESP_PORT"
echo "ESP_USER: $ESP_USER"
echo "PLAYWRIGHT_HEADLESS: $PLAYWRIGHT_HEADLESS"
echo "PLAYWRIGHT_SPEC_PATTERN: $PLAYWRIGHT_SPEC_PATTERN"
echo "PLAYWRIGHT_REPORT: $PLAYWRIGHT_REPORT"
echo "PLAYWRIGHT_WORKERS: $PLAYWRIGHT_WORKERS"

# Execute pytest with proper arguments
# shellcheck disable=SC1073
# shellcheck disable=SC2233
if [[ -n "$PLAYWRIGHT_WORKERS" ]]; then
    pytest --dist=loadscope -n $PLAYWRIGHT_WORKERS $PLAYWRIGHT_SPEC_PATTERN
else
    export PYTHONPATH="$(pwd)"
    pytest  $PLAYWRIGHT_SPEC_PATTERN  --confcutdir=$(pwd) --import-mode=importlib --alluredir=allure-results
fi