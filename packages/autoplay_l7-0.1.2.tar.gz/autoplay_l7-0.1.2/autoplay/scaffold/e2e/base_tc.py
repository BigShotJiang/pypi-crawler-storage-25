import logging

from pages.base_page import BasePage
from pages.homepage import HomePage
from utils.commands import seed


class BaseTC(BasePage):
    """Base class for all TC (test case) implementations.

    Subclasses override precondition(), main(), and teardown() as needed.
    TX (test set) files call these three methods in order via the standard
    lifecycle managed by BaseTX.
    """

    def __init__(self, page):
        super().__init__(page)
        self.homepage = HomePage(page)

    def precondition(self):
        """Login and seed test data. Override to customize."""
        self.homepage.navigate_to_login()
        print(f"Implement precondition() from base_tc. Override in TC subclass if specific precondition is needed.")
        logger = self.page.get_by_test_id("logger")
        logging.info("Implement precondition() from base_tc. Override in TC subclass if specific precondition is needed.")

    def main(self):
        """Test body. Must be overridden by each TC subclass."""
        raise NotImplementedError(f"{type(self).__name__} must implement main()")

    def teardown(self):
        """Optional per-TC cleanup. Override when cleanup is needed."""
        print(f"Implemented teardown() from base_tc. Override in TC subclass if specific teardown is needed.")
        logger = self.page.get_by_test_id("logger")
        logging.info("Implemented teardown() from base_tc. Override in TC subclass if specific teardown is needed.")