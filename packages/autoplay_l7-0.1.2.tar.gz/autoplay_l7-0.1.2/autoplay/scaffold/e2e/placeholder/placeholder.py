import pytest
import allure
import pages.homepage as HomePage

from utils.commands import seed_teardown

class TestClientName:
    @classmethod
    def setup_class(cls):
        pass

    def teardown_class(cls):
        pass

    def setup_method(self, method):
        pass

    def teardown_method(self, method):

        if method.__name__ == "test_placeholder":
            seed_teardown("index_seed.yml")

    @allure.title("Placeholder Test")
    @allure.description("This is a placeholder test to verify the test framework setup.")
    def test_placeholder(self, page):
        homepage = HomePage.HomePage(page)
        homepage.navigate_to_login()
        homepage.login()
        homepage.allow_unpinned_versions()

