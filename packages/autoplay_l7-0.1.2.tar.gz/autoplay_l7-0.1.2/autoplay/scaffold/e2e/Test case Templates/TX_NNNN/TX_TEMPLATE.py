# HOW TO USE THIS TEMPLATE
# -------------------------
# 1. Copy this file to:  e2e/<SOW>/<TX_XXXX>/TX_XXXX.py
# 2. Replace TX_XXXX with the Spira test-set ID (e.g. TX_7074).
# 3. For every TC in the test set:
#    a. Create  e2e/<SOW>/<TX_XXXX>/TC_NNNNN.py  (copy TC_TEMPLATE.py)
#    b. Import the class below and add it to _TC_MAP.
# 4. Add one test_TC_NNNNN() method per TC.
#    The method body is always just:  self._active_tc.main()

import allure
from automation.pages.base_page import BasePage
# from tests.automation.e2e.<SOW>.<TX_XXXX>.TC_NNNNN import TC_NNNNN

# Maps test method names → TC class.  Add one entry per TC.
_TC_MAP = {
    # "test_TC_NNNNN": TC_NNNNN,
}


@allure.feature("<spira-test-set-name>")
class Test_TX_XXXX(BasePage):

    def setup_method(self, method):
        tc_class = _TC_MAP.get(method.__name__)
        if tc_class:
            self._active_tc = tc_class(self.page)
            self._active_tc.precondition()

    def teardown_method(self, method):
        if hasattr(self, "_active_tc"):
            self._active_tc.teardown()
            del self._active_tc

    # def test_TC_NNNNN(self):
    #     self._active_tc.main()
