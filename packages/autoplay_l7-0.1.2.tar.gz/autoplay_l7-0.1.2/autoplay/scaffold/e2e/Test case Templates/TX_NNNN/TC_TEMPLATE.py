# HOW TO USE THIS TEMPLATE
# -------------------------
# 1. Copy this file to:  e2e/<SOW>/<TX_XXXX>/TC_NNNNN.py
# 2. Replace TC_NNNNN with the Spira test-case ID (e.g. TC_142054).
# 3. Add fixture data to:  fixtures/<TX_XXXX>/TC_NNNNN.yml
# 4. Implement precondition(), main(), and (if needed) teardown().

import allure
from automation.e2e.base_tc import BaseTC
from automation.utils.commands import seed


class TC_NNNNN(BaseTC):

    @allure.step("Precondition")
    def precondition(self):
        self.homepage.navigate_to_login()
        self.homepage.login()
        seed("<TX_XXXX>/TC_NNNNN")

    @allure.step("Test steps")
    def main(self):
        pass

    def teardown(self):
        # Add per-TC cleanup here if needed; otherwise delete this method.
        pass
