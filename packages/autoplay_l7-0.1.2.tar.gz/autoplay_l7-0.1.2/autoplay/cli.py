import argparse
import shutil
from importlib import resources
from pathlib import Path


def _get_scaffold_path() -> Path:
    with resources.as_file(resources.files("autoplay").joinpath("scaffold")) as p:
        return p


def _resolve_target(base: Path) -> Path:
    tests_dir = base / "tests"
    if tests_dir.is_dir():
        return tests_dir / "automation"
    return base / "tests" / "automation"


def cmd_init(args: argparse.Namespace) -> None:
    base = Path(args.target).resolve()
    target = _resolve_target(base)
    scaffold = _get_scaffold_path()

    if target.exists():
        shutil.copytree(scaffold, target, dirs_exist_ok=True)
        print(f"automation/ scaffold merged into {target}")
    else:
        shutil.copytree(scaffold, target)
        print(f"automation/ scaffold created at {target}")


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="autoplay",
        description="Playwright automation scaffold installer",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    init_parser = sub.add_parser("init", help="Copy automation scaffold into the current project")
    init_parser.add_argument(
        "--target",
        default=".",
        metavar="DIR",
        help="Directory to create automation/ in (default: current directory)",
    )
    init_parser.set_defaults(func=cmd_init)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
