# pywiscat

[![Build Status](https://github.com/wmo-im/pywiscat/workflows/build%20%E2%9A%99%EF%B8%8F/badge.svg)](https://github.com/wmo-im/pywiscat/actions)

## Pythonic API to WMO WIS Catalogue

pywiscat provides a Pythonic API atop the WIS2 Global Discovery Catalogue (GDC).

## Installation

### pip

Install latest stable version from [PyPI](https://pypi.org/project/pywiscat).

```bash
pip3 install pywiscat
```

### From source

Install latest development version.

```bash
python3 -m venv pywiscat
cd pywiscat
. bin/activate
git clone https://github.com/wmo-im/pywiscat.git
cd pywiscat
pip3 install .
```

## Running

The default GDC used in pywiscat is https://wis2-gdc.weather.gc.ca/collections/wis2-discovery-metadata.

To use a different catalogue, set the `PYWISCAT_GDC_URL` environment variable before running pywiscat.

From command line:

```bash
# fetch version
pywiscat --version

## WIS2 workflows

# search the WIS2 Global Discovery Catalogue (GDC)
pywiscat search

# search the WIS2 Global Discovery Catalogue (GDC) with a full text query
pywiscat search --query radar

# search the WIS2 Global Discovery Catalogue (GDC) for only recommended data
pywiscat search --data-policy recommended

# search the WIS2 Global Discovery Catalogue (GDC) by country
pywiscat search --country Germany

# search the WIS2 Global Discovery Catalogue (GDC) with a bounding box query
pywiscat search --bbox -142,42,-52,84

# get more information about a WIS2 GDC record
pywiscat get urn:x-wmo:md:can:eccc-msc:c7c9d726-c48a-49e3-98ab-78a1ab87cda8

## Archive utilities

# download and extract a WIS2 GDC metadata archive zipfile to a specific directory
# downloads from PYWISCAT_GDC_URL by default
# override with --global-discovery-catalogue (https://example.org/collections/wis2-discovery-metadata)
pywiscat archive get /path/to/archive

# compare GDC metadata archive zipfile to other GDC metadata archive zipfiles
# this requires each GDC metadata archive zipfile to be downloaded and extracted via
# pywiscat archive get /path/to/archive (directory MUST be identical)
pywiscat archive compare /path/archive --centre-id ca-eccc-msc-global-discovery-catalogue

## Metrics analyzers

# analyze core records by centre identifier
pywiscat metrics core /path/to/archive

# analyze recommended records by centre identifier
pywiscat metrics recommended /path/to/archive

# analyze Earth system disciplines by centre identifier
pywiscat metrics earth-system-discipline /path/to/archive

# analyze Key Performance Indicators (KPIs) by centre identifier
pywiscat metrics kpi ca-eccc-msc /path/to/archive
```

## Using the API
```python

## WIS2 workflows

from pywiscat.wis2.catalogue import search, get

# search catalogue
results = search(q='radar', bbox=[-142, 42, -52, 84]))

# get a single catalogue record
results = get('urn:x-wmo:md:can:eccc-msc:c7c9d726-c48a-49e3-98ab-78a1ab87cda8')
```


## Development

```bash
python3 -m venv pywiscat
cd pywiscat
source bin/activate
git clone https://github.com/wmo-im/pywiscat.git
pip3 install .
```

### Running tests

```bash
python3 tests/run_tests.py
```

## Releasing

```bash
# create release (x.y.z is the release version)
vi pyproject.toml  # update [project]/version
git commit -am 'update release version x.y.z'
git push origin master
git tag -a x.y.z -m 'tagging release version x.y.z'
git push --tags

# upload to PyPI
rm -fr build dist *.egg-info
python3 -m build
twine upload dist/*

# publish release on GitHub (https://github.com/wmo-im/pywiscat/releases/new)

# bump version back to dev
vi pyproject.toml  # update [project]/version
git commit -am 'back to dev'
git push origin master
```

## Code Conventions

[PEP8](https://www.python.org/dev/peps/pep-0008)

## Issues

Issues are managed at https://github.com/wmo-im/pywiscat/issues

## Contact

* [Tom Kralidis](https://github.com/tomkralidis)
* [Ján Osuský](https://github.com/josusky)
