"""Renderers for undeclared-intent analyzer results.

Pure-function renderers that consume the dict returned by
:func:`sentience_governor.analyze.undeclared_intent.compute_undeclared_intent_spend`
and produce surface-specific output.

Two surfaces in v0.2.4:

* :func:`render_cli` — terminal output. One-screen-friendly,
  screenshot-worthy. Does NOT print the save prompt — that ordering
  is governed by the CLI handler (P7: prompt only after the user
  sees the metric, suppress on non-ok status).
* :func:`render_markdown_report` — saved Markdown report with the
  canonical two-vector footer. Written to
  ``~/.sentience/reports/`` by the CLI ``--save`` flow.

These renderers are pure: no I/O, no env reads, no input mutation.
File-writing lives in the CLI handler, not here.

See ``docs/plans/v0.2.4-undeclared-intent-token-spend.md`` (revision
v3) §"Where it surfaces" for the locked output shapes and the
canonical footer copy.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

# ---------------------------------------------------------------------------
# Status constants (mirrored from the analyzer module so renderers don't
# import from the analyzer — avoids circular import risk and keeps this
# module independently testable).
# ---------------------------------------------------------------------------

STATUS_OK = "ok"
STATUS_PARTIAL = "partial"
STATUS_NO_TOKEN_DATA = "no_token_data"
STATUS_NO_TURNS = "no_turns"

# Canonical footer copy — LOCKED per plan v3 §"Canonical saved-report
# footer copy". Any change here must be matched in the plan doc.
_CANONICAL_FOOTER = (
    "This is one session. A consolidated view across all your runs —\n"
    "drift trends, compute attributed across workflows, agent behavior\n"
    "compared over time — is what's next. If you'd find it useful,\n"
    "the most helpful thing is hearing what it should answer.\n"
    "\n"
    "Reply: operators@crescerelabs.com\n"
    "Or stay informed: getsentience.ai/launch-list\n"
)

# Footer line copy — LOCKED per plan v3 §"Differentiated footer copy".
_FOOTER_AGENT_BOUND = (
    "{undeclared_tokens:,} tokens were attributed to turns that touched "
    "execution outside\n"
    "this session's declared operational intent. Were these valid and\n"
    "expected? If not, policy can intervene at the execution boundary —\n"
    "review, constraint, confirmation, or block."
)

_FOOTER_SURFACE_BOUND = (
    "This session contains no declared intent — every attributed turn\n"
    "is classified as undeclared. Often this reflects a surface-level\n"
    "limitation (e.g. Claude Code hooks today, which don't yet expose\n"
    "an intent-declaration primitive) rather than agent drift."
)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def render_cli(result: Dict[str, Any], *, color: bool = True) -> str:
    """Render an undeclared-intent result for the terminal.

    Args:
        result: The dict returned by ``compute_undeclared_intent_spend``.
        color: Reserved for future ANSI color support. Currently
            unused; the v0.2.4 surface is plain text for screenshot
            stability and PyPI README rendering.

    Returns:
        Plain-text rendering, terminated with a single newline.
        Status branches:

        * ``ok`` / ``partial`` — full breakdown + footer.
        * ``no_token_data`` — short notice; no breakdown; no footer.
        * ``no_turns`` — short notice; no breakdown; no footer.

    Pure function; does not print the save prompt.
    """
    status = result.get("status", "")
    session_id = result.get("session_id") or ""
    sid_short = session_id[:8] if session_id else "(unknown)"

    if status == STATUS_NO_TOKEN_DATA:
        return _render_no_token_data(sid_short)

    if status == STATUS_NO_TURNS:
        return _render_no_turns(sid_short)

    # ok / partial — full breakdown.
    lines: List[str] = []
    title = f"Undeclared-Intent Spend — session {sid_short}..."
    lines.append(title)
    lines.append("─" * max(len(title), 41))

    total = int(result.get("total_tokens", 0) or 0)
    undeclared = int(result.get("undeclared_tokens", 0) or 0)
    declared = int(result.get("declared_tokens", 0) or 0)
    pct = float(result.get("undeclared_percent", 0.0) or 0.0)
    declared_pct = round(100.0 - pct, 1) if total > 0 else 0.0

    lines.append(f"Total compute       {total:>9,} tokens")
    lines.append(
        f"Undeclared          {undeclared:>9,} tokens   ({pct:.1f}%)"
    )
    lines.append(
        f"Declared            {declared:>9,} tokens   ({declared_pct:.1f}%)"
    )
    lines.append("")

    undeclared_turns = result.get("undeclared_turns") or []
    if undeclared_turns:
        lines.append("Undeclared turns")
        for entry in undeclared_turns:
            lines.append(_format_turn_line(entry))
        lines.append("")

    # v0.2.5 — profile-driven sections. Each is omitted when the
    # underlying list is empty / metadata is absent, so v0.2.4-shaped
    # traces produce byte-identical CLI output (regression guard per
    # plan CP4 §"CLI render with no profile metadata: identical to
    # v0.2.4 output").
    high_consequence_events = result.get("high_consequence_events") or []
    if high_consequence_events:
        lines.append("High-consequence operations")
        for entry in high_consequence_events:
            lines.append(_format_high_consequence_line(entry))
        lines.append("")

    task_boundary_events = result.get("task_boundary_events") or []
    if task_boundary_events:
        lines.append("Task boundaries crossed")
        for entry in task_boundary_events:
            lines.append(_format_task_boundary_line(entry))
        lines.append("")

    # Profile metadata footnote — only when the trace identifies a
    # loaded operator-authored profile. The fingerprint correlates
    # this report to the operator's local profile file.
    if result.get("profile_loaded") is True:
        fp = result.get("profile_fingerprint") or "(unknown)"
        psv = result.get("profile_schema_version")
        psv_str = str(psv) if isinstance(psv, int) else "(unknown)"
        lines.append(
            f"Profile: fingerprint {fp}, schema v{psv_str}"
        )
        lines.append("")

    # Status partial — surface a small advisory above the footer.
    if status == STATUS_PARTIAL:
        warn_count = (
            int(result.get("unpaired_event_count", 0) or 0)
            + int(result.get("untokened_pair_count", 0) or 0)
            + int(result.get("dedupe_conflict_count", 0) or 0)
            + int(result.get("malformed_event_count", 0) or 0)
        )
        lines.append(
            f"Note: status=partial — {warn_count} trace warning(s) "
            "accumulated.\n"
            "Numeric attribution above is correct for the readable "
            "subset; see\n"
            "--json output for the warnings list."
        )
        lines.append("")

    # Footer line — branch on session_has_declared_intent.
    has_intent = bool(result.get("session_has_declared_intent", False))
    if has_intent:
        lines.append(_FOOTER_AGENT_BOUND.format(undeclared_tokens=undeclared))
    else:
        lines.append(_FOOTER_SURFACE_BOUND)

    return "\n".join(lines) + "\n"


def render_markdown_report(result: Dict[str, Any]) -> str:
    """Render an undeclared-intent result as a Markdown report.

    Args:
        result: The dict returned by ``compute_undeclared_intent_spend``.

    Returns:
        Markdown content suitable for writing to
        ``~/.sentience/reports/undeclared-intent-*.md``.

    Includes the canonical two-vector footer (operators@crescerelabs.com
    reply path + launch-list link) — the v0.2.4 relationship surface
    per plan v3 §"Save flow".

    Pure function; does not write to disk.
    """
    status = result.get("status", "")
    session_id = result.get("session_id") or ""
    sid_short = session_id[:8] if session_id else "(unknown)"

    lines: List[str] = []
    lines.append(f"# Undeclared-Intent Spend — session `{sid_short}...`")
    lines.append("")
    lines.append(f"- Status: `{status}`")

    if status in (STATUS_NO_TOKEN_DATA, STATUS_NO_TURNS):
        if status == STATUS_NO_TOKEN_DATA:
            lines.append(
                "- No token-bearing `CONTEXT_SNAPSHOT` events were found "
                "in this session."
            )
            lines.append(
                "- This usually means Track 2 token-attribution hooks "
                "are not wired."
            )
        else:
            lines.append(
                "- Reasoning turns were detected but none carried "
                "populated token totals."
            )
        lines.append("")
        lines.append(_canonical_footer_markdown())
        return "\n".join(lines) + "\n"

    # ok / partial — full breakdown.
    total = int(result.get("total_tokens", 0) or 0)
    undeclared = int(result.get("undeclared_tokens", 0) or 0)
    declared = int(result.get("declared_tokens", 0) or 0)
    pct = float(result.get("undeclared_percent", 0.0) or 0.0)
    declared_pct = round(100.0 - pct, 1) if total > 0 else 0.0
    undeclared_turn_count = int(result.get("undeclared_turn_count", 0) or 0)
    total_turn_count = int(result.get("total_turn_count", 0) or 0)

    lines.append(f"- Total turns: {total_turn_count}")
    lines.append(f"- Undeclared turns: {undeclared_turn_count}")
    lines.append("")
    lines.append("## Headline")
    lines.append("")
    lines.append("| Metric | Tokens | Share |")
    lines.append("|---|---:|---:|")
    lines.append(f"| Total compute | {total:,} | 100.0% |")
    lines.append(f"| Undeclared | {undeclared:,} | {pct:.1f}% |")
    lines.append(f"| Declared | {declared:,} | {declared_pct:.1f}% |")
    lines.append("")

    undeclared_turns = result.get("undeclared_turns") or []
    if undeclared_turns:
        lines.append("## Undeclared turns")
        lines.append("")
        lines.append("| Turn | Tool(s) | Tokens | Reason(s) |")
        lines.append("|---|---|---:|---|")
        for entry in undeclared_turns:
            t_id = (entry.get("turn_id") or "")[:8]
            tools = ", ".join(entry.get("tool_ids") or []) or "—"
            tokens = int(entry.get("tokens", 0) or 0)
            reasons = ", ".join(entry.get("reasons") or [])
            lines.append(f"| `{t_id}...` | {tools} | {tokens:,} | {reasons} |")
        lines.append("")

    # v0.2.5 — Profile section. Only emitted when the trace
    # identifies a loaded operator-authored profile. Markdown report
    # omits both header and body when profile_loaded is not True, so
    # v0.2.4-shaped traces produce byte-identical reports.
    if result.get("profile_loaded") is True:
        fp = result.get("profile_fingerprint") or "(unknown)"
        psv = result.get("profile_schema_version")
        psv_str = str(psv) if isinstance(psv, int) else "(unknown)"
        lines.append("## Profile")
        lines.append("")
        lines.append("This session ran under a governance profile.")
        lines.append("")
        lines.append(f"- Profile fingerprint: `{fp}`")
        lines.append(f"- Schema version: {psv_str}")
        lines.append("")
        lines.append(
            "(For the full expectations that drove these results, see "
            "your local `~/.sentience/profile.yaml` — the analyzer does "
            "not embed profile contents in this report.)"
        )
        lines.append("")

    # v0.2.5 — High-consequence operations section. Always omitted
    # when no events present (regression guard).
    high_consequence_events = result.get("high_consequence_events") or []
    if high_consequence_events:
        lines.append("## High-consequence operations")
        lines.append("")
        lines.append("| Turn | Tool |")
        lines.append("|---|---|")
        for entry in high_consequence_events:
            t_id = (entry.get("turn_id") or "")[:8] if entry.get("turn_id") else "—"
            tool = entry.get("tool_id") or "—"
            lines.append(f"| `{t_id}` | {tool} |")
        lines.append("")

    # v0.2.5 — Task boundaries section.
    task_boundary_events = result.get("task_boundary_events") or []
    if task_boundary_events:
        lines.append("## Task boundaries crossed")
        lines.append("")
        lines.append("| Turn | Tool when crossed |")
        lines.append("|---|---|")
        for entry in task_boundary_events:
            t_id = (entry.get("turn_id") or "")[:8] if entry.get("turn_id") else "—"
            tool = entry.get("tool_id") or "—"
            lines.append(f"| `{t_id}` | {tool} |")
        lines.append("")

    if status == STATUS_PARTIAL:
        lines.append("## Notes")
        lines.append("")
        lines.append(
            "Status: `partial`. The analyzer accumulated trace warnings "
            "while reading this session. Numeric attribution above is "
            "correct for the readable subset; the full warnings list is "
            "available in the JSON output (`--json`)."
        )
        lines.append("")

    lines.append("## Operational interpretation")
    lines.append("")
    has_intent = bool(result.get("session_has_declared_intent", False))
    if has_intent:
        lines.append(
            f"{undeclared:,} tokens were attributed to turns that touched "
            "execution outside this session's declared operational intent. "
            "Were these valid and expected? If not, policy can intervene "
            "at the execution boundary — review, constraint, confirmation, "
            "or block."
        )
    else:
        lines.append(
            "This session contains no declared intent — every attributed "
            "turn is classified as undeclared. Often this reflects a "
            "surface-level limitation (e.g. Claude Code hooks today, which "
            "don't yet expose an intent-declaration primitive) rather than "
            "agent drift."
        )
    lines.append("")
    lines.append(_canonical_footer_markdown())
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _format_turn_line(entry: Dict[str, Any]) -> str:
    """One CLI line for an undeclared turn."""
    t_id = (entry.get("turn_id") or "")[:8]
    tools = entry.get("tool_ids") or []
    primary_tool = tools[0] if tools else "—"
    tokens = int(entry.get("tokens", 0) or 0)
    reasons = entry.get("reasons") or []
    reason_str = ",".join(reasons)
    return (
        f"  Turn {t_id:<8}  {primary_tool:<24} "
        f"{tokens:>7,} tokens   {reason_str}"
    )


def _format_high_consequence_line(entry: Dict[str, Any]) -> str:
    """One CLI line for a HIGH_CONSEQUENCE_DETECTED event.

    Shape mirrors _format_turn_line for visual consistency:
    indented "Turn <short>  <tool>" so the three v0.2.5 sections
    align column-wise in screenshot output.
    """
    t_id = (entry.get("turn_id") or "")[:8] if entry.get("turn_id") else "—"
    tool = entry.get("tool_id") or "—"
    return f"  Turn {t_id:<8}  {tool}"


def _format_task_boundary_line(entry: Dict[str, Any]) -> str:
    """One CLI line for a TASK_BOUNDARY_CROSSED event."""
    t_id = (entry.get("turn_id") or "")[:8] if entry.get("turn_id") else "—"
    tool = entry.get("tool_id") or "—"
    return f"  Turn {t_id:<8}  {tool}"


def _render_no_token_data(sid_short: str) -> str:
    return (
        f"Undeclared-Intent Spend — session {sid_short}...\n"
        f"{'─' * 41}\n"
        "Status: no_token_data\n"
        "\n"
        "No token-bearing CONTEXT_SNAPSHOT events were found in this\n"
        "session. This usually means Track 2 token-attribution hooks\n"
        "are not wired (the MCP wrapper auto-emits them; the Claude\n"
        "Code hook captures them when the SessionEnd hook is\n"
        "configured).\n"
        "\n"
        "To see what a populated analysis looks like right now, run:\n"
        "    sentience analyze undeclared-intent --showcase\n"
    )


def _render_no_turns(sid_short: str) -> str:
    return (
        f"Undeclared-Intent Spend — session {sid_short}...\n"
        f"{'─' * 41}\n"
        "Status: no_turns\n"
        "\n"
        "Reasoning turns were detected but none carried populated\n"
        "token totals. The analyzer cannot attribute compute without\n"
        "token data on the per-turn CONTEXT_SNAPSHOT events.\n"
    )


def _canonical_footer_markdown() -> str:
    """The canonical two-vector footer — LOCKED copy."""
    return (
        "---\n"
        "\n"
        "This is one session. A consolidated view across all your runs — "
        "drift trends, compute attributed across workflows, agent behavior "
        "compared over time — is what's next. If you'd find it useful, "
        "the most helpful thing is hearing what it should answer.\n"
        "\n"
        "Reply: <operators@crescerelabs.com>\n"
        "\n"
        "Or stay informed: <https://getsentience.ai/launch-list>\n"
    )
