"""Analyzer modules — derived metrics computed from v0.2.3+ trace data.

Each analyzer is a pure-function module that reads governance event
lists and returns structured results. Analyzers do not perform I/O,
do not read environment state, do not mutate inputs, and produce
byte-stable output for identical inputs. See per-module docstrings
for the specific guarantees.

The first analyzer (v0.2.4) is :mod:`undeclared_intent`, which
computes how much of a session's compute attributed to turns that
touched execution outside the session's declared operational intent.

Future analyzers (v0.2.5+ candidates) include policy-violation burn
rate and refined retry tax. See `docs/strategy/post-v0.2.3-roadmap-triage.md`
for the parking-lot tier framework.
"""

from sentience_governor.analyze.renderers import (
    render_cli,
    render_markdown_report,
)
from sentience_governor.analyze.undeclared_intent import (
    compute_undeclared_intent_spend,
)

__all__ = [
    "compute_undeclared_intent_spend",
    "render_cli",
    "render_markdown_report",
]
