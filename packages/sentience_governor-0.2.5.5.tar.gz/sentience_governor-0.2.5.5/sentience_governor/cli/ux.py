"""`sentience` — signal-first trace viewer for agent-hook sessions.

Purpose
-------
Opinionated CLI for the high-noise, high-volume agent-hook workflow
(Claude Code today; Cursor / Codex / OpenCode in the future). Three
subcommands:

* ``sentience status`` — self-check. Is the hook capturing sessions?
* ``sentience list`` — what sessions exist? One line per session.
* ``sentience open [--latest | <session_id>]`` — curated view of one
  session with Summary, Focus block, Notes, Key Events, Full Trace,
  Footer.

Relationship to ``sentience-cli``
---------------------------------
Two CLIs, two audiences.

* ``sentience-cli <file>`` (``sentience_governor.cli.viewer``) is the
  raw, full-fidelity viewer. Every event renders with detail. Used by
  library integrators (MCP wrapper, LangChain) and by the
  golden-trace snapshot tests. Stays unchanged.

* ``sentience`` (this module) is the curated, narrative viewer. Uses
  signal-hierarchy rendering with a baseline-noise classifier so
  hundreds of near-identical events in a Claude Code session compress
  into a scannable story.

Spec
----
The full design lives at ``docs/plans/sentience-cli-v1-ux.md``. That
doc is the source of truth; this module must not drift from it.

Implementation notes
--------------------
* Single-file v1. Classifier, formatter, render blocks, and CLI
  dispatch all live here. Can split into submodules later if any one
  piece grows.
* Reuses ``parse_events`` from :mod:`sentience_governor.cli.viewer`
  for the trace parsing primitive — no duplicate JSONL handling.
* Reuses the default sink path from
  :mod:`sentience_governor.wrapper.claude_code_hook` so a user who
  has not set ``SENTIENCE_CLAUDE_CODE_SINK_PATH`` gets the same path
  the hook writes to.
* Fail-safe: unknown tools, missing fields, corrupt JSON lines all
  render as ``???`` rather than crashing. Forward-compatible with
  future adapters.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from collections import Counter, defaultdict
from datetime import datetime
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

from sentience_governor.analyze import (
    compute_undeclared_intent_spend,
    render_cli as render_undeclared_cli,
    render_markdown_report as render_undeclared_markdown,
)
from sentience_governor.cli.first_run import maybe_run_first_run_flow
from sentience_governor.cli.viewer import parse_events
from sentience_governor.profile import GovernanceProfile
from sentience_governor.profile.loader import DEFAULT_PROFILE_PATH

# ---------------------------------------------------------------------------
# Defaults — mirror what the Claude Code hook writes to.
# Imported lazily so test suites that patch env vars still see them.
# ---------------------------------------------------------------------------

_DEFAULT_SINK_DIR = Path.home() / ".sentience" / "traces" / "claude-code"


def _resolve_trace_dir() -> Path:
    """Return the trace directory the hook is writing to.

    Honours the same env var the Claude Code hook honours
    (``SENTIENCE_CLAUDE_CODE_SINK_PATH``) with the same disambiguation
    rule: ``.jsonl`` suffix = shared-file mode (return parent
    directory); anything else = per-session directory mode.
    """
    raw = os.environ.get("SENTIENCE_CLAUDE_CODE_SINK_PATH", "").strip()
    if not raw:
        return _DEFAULT_SINK_DIR
    base = Path(raw).expanduser()
    if base.suffix == ".jsonl":
        return base.parent
    return base


# ---------------------------------------------------------------------------
# Gloss table — LOCKED per docs/plans/sentience-cli-v1-ux.md §5.5.
# Every advisory / policy code here must match the plan doc exactly.
# ---------------------------------------------------------------------------

_GLOSS: Dict[str, str] = {
    "POL-001": "write operation without declared intent",
    "POL-002": "agent not registered",
    "POL-003": "unclassified context",
    "POL-004": "memory write without classification or retention policy",
    "POL-005": "sensitivity escalation without authorization",
    "INTENT_MISSING": "no intent declared",
    "SCOPE_INTENT_MISMATCH": "tool call does not match declared intent",
    "SCOPE_OPERATION_UNEXPECTED": "unexpected operation type for declared scope",
    "CONTEXT_UNCLASSIFIED": "context data not classified",
    "SENSITIVITY_ESCALATION": "context sensitivity escalated",
    "MEMORY_WRITE_CANDIDATE": "write outside declared scope",
    "MEMORY_WRITE_UNCLASSIFIED": "memory write lacks classification",
    "AGENT_UNREGISTERED": "agent not registered before session start",
}


def _gloss(code: str) -> str:
    """Return the plain-English gloss for a code; empty string if unknown.

    Per §5.5: if a new code appears that is not in the table, render
    the code alone (no invented wording).
    """
    return _GLOSS.get(code, "")


# ---------------------------------------------------------------------------
# Baseline-noise classifier — §6.1 of the plan.
# ---------------------------------------------------------------------------

# Known baseline patterns: (event_type, code) where code may be an
# advisory flag OR a policy violation. Both forms appear on the wire.
_BASELINE_PATTERNS: set = {
    ("INTENT_DECLARED", "INTENT_MISSING"),
    ("CONTEXT_SNAPSHOT", "POL-003"),
    ("CONTEXT_SNAPSHOT", "CONTEXT_UNCLASSIFIED"),
}

_BASELINE_FREQUENCY_THRESHOLD = 0.80


@dataclass
class _ClassifiedSession:
    """Result of classifying one session's events.

    ``anomalies`` holds one entry per event that carries at least one
    anomaly code. ``baseline_codes_present`` records which known
    baseline patterns crossed the 80% threshold in this session.

    Focus is derived from ``anomalies`` (§5.2 coupling rule). Summary
    is derived from ``anomaly_code_counts``. Both come from the same
    source; they cannot drift.
    """

    events: List[dict]
    anomalies: List["_EventAnomaly"] = field(default_factory=list)
    anomaly_code_counts: Counter = field(default_factory=Counter)
    baseline_codes_present: set = field(default_factory=set)
    tool_counts: Counter = field(default_factory=Counter)


@dataclass
class _EventAnomaly:
    """One event's worth of anomaly data, carried through to render."""

    sequence: int
    event_type: str
    tool_name: str
    tool_input: dict
    code: str  # the primary (highest-priority) anomaly code
    all_codes: List[str]
    user_impact_rank: int  # lower is more severe per §5.3 ordering
    raw_event: dict = field(default_factory=dict)
    # raw_event is carried so Key Events / Focus refs can render
    # non-SCOPE events (MEMORY_WRITE_ATTEMPT, INTENT_DECLARED, etc.)
    # via _format_event_oneline rather than the tool-action path.


def _user_impact_rank(event_type: str, code: str, tool_name: str) -> int:
    """Rank an anomaly by user impact (§5.3 ordering).

    Lower is more severe. Ordering:
      1. Destructive operations (writes, deletes, memory writes)
      2. Unexpected command execution (Bash-class)
      3. Scope mismatches
      4. Context exposure issues
    Policy-code severity is a tiebreaker only.
    """
    if code in ("MEMORY_WRITE_CANDIDATE", "MEMORY_WRITE_UNCLASSIFIED", "POL-004"):
        return 1
    if event_type == "MEMORY_WRITE_ATTEMPT":
        return 1
    if tool_name == "Bash" and code in (
        "POL-001",
        "SCOPE_OPERATION_UNEXPECTED",
    ):
        return 2
    if code in ("SCOPE_INTENT_MISMATCH", "SCOPE_OPERATION_UNEXPECTED", "POL-001"):
        return 3
    if code in ("SENSITIVITY_ESCALATION", "POL-005"):
        return 4
    # Anything else (unknown codes, context flags not filtered as baseline)
    return 5


def classify_session(events: List[dict]) -> _ClassifiedSession:
    """Classify events into anomalies vs baseline noise.

    Pattern + frequency rule per §6.1:

    * A ``(event_type, code)`` tuple is baseline iff it matches a
      known-baseline pattern AND appears in >80% of eligible events
      of that event_type.
    * Everything else is anomaly.

    ``events`` must already be ordered by event_sequence_number. The
    caller (``parse_events``) guarantees this.
    """
    result = _ClassifiedSession(events=events)

    # Step 1 — compute per-event-type frequencies for each known pattern.
    events_by_type: Dict[str, List[dict]] = defaultdict(list)
    for ev in events:
        events_by_type[ev.get("event_type", "")].append(ev)

    baseline_eligible: set = set()  # (event_type, code) tuples that meet the rule
    for pattern in _BASELINE_PATTERNS:
        event_type, code = pattern
        eligible = events_by_type.get(event_type, [])
        if not eligible:
            continue
        matching = 0
        for ev in eligible:
            if _event_has_code(ev, code):
                matching += 1
        frequency = matching / len(eligible)
        if frequency > _BASELINE_FREQUENCY_THRESHOLD:
            baseline_eligible.add(pattern)
            result.baseline_codes_present.add(code)

    # Step 2 — walk events, classify each code as baseline or anomaly.
    for ev in events:
        event_type = ev.get("event_type", "")
        tool_name = _extract_tool_name(ev)
        if tool_name:
            result.tool_counts[tool_name] += 1

        event_codes = _all_event_codes(ev)
        anomaly_codes: List[str] = []
        for code in event_codes:
            if (event_type, code) in baseline_eligible:
                continue  # baseline noise
            anomaly_codes.append(code)

        if not anomaly_codes:
            continue

        # Pick the highest-priority anomaly code (lowest rank value).
        ranked = sorted(
            anomaly_codes,
            key=lambda c: _user_impact_rank(event_type, c, tool_name),
        )
        primary = ranked[0]
        for c in anomaly_codes:
            result.anomaly_code_counts[c] += 1

        result.anomalies.append(
            _EventAnomaly(
                sequence=ev.get("event_sequence_number", 0),
                event_type=event_type,
                tool_name=tool_name,
                tool_input=_extract_tool_input(ev),
                code=primary,
                all_codes=anomaly_codes,
                user_impact_rank=_user_impact_rank(event_type, primary, tool_name),
                raw_event=ev,
            )
        )

    return result


def _all_event_codes(event: dict) -> List[str]:
    """Flatten advisory_flags + policy_violations into a single list."""
    flags = event.get("advisory_flags") or []
    vios = event.get("policy_violations") or []
    out: List[str] = []
    if isinstance(flags, list):
        out.extend(str(x) for x in flags if x)
    if isinstance(vios, list):
        out.extend(str(x) for x in vios if x)
    return out


def _event_has_code(event: dict, code: str) -> bool:
    return code in _all_event_codes(event)


# ---------------------------------------------------------------------------
# Locked event formatting table — §5.6 of the plan.
# Unknown tools fall back to `<tool_name> → ???`, NEVER crash.
# Tool identity is always preserved even when payload is unknown.
# ---------------------------------------------------------------------------


def _extract_tool_name(event: dict) -> str:
    """Return the tool_id from a SCOPE_ASSERTED payload, or empty string."""
    payload = event.get("payload")
    if not isinstance(payload, dict):
        return ""
    return str(payload.get("tool_id") or "")


def _extract_tool_input(event: dict) -> dict:
    """Best-effort extraction of tool_input shape from either a native
    wrapper trace or a Claude Code hook trace.

    The library wrappers emit SCOPE_ASSERTED events without tool_input
    in the payload. The Claude Code hook also does not encode tool_input
    on SCOPE_ASSERTED (it appears on the PreToolUse payload at dispatch,
    not on the emitted event). We return an empty dict in that case;
    the formatter falls back to ``???`` which is the documented behaviour.
    """
    payload = event.get("payload")
    if not isinstance(payload, dict):
        return {}
    ti = payload.get("tool_input")
    return ti if isinstance(ti, dict) else {}


def _format_tool_action(tool_name: str, tool_input: dict) -> str:
    """Render a tool invocation per the LOCKED §5.6 table.

    Preserves tool identity even when the payload carries no meaningful
    target: renders a bare ``<tool_name>`` rather than the
    broken-looking ``<tool_name> → ???`` (F-V3). The ``→`` arrow is only
    shown when there is an actual target/argument to point at.
    """
    if not tool_name:
        # Truly unknown event shape — no identity to preserve.
        return "(unknown tool)"

    ti = tool_input if isinstance(tool_input, dict) else {}

    if tool_name == "Bash":
        cmd = str(ti.get("command") or "")
        if not cmd:
            return tool_name
        shown = cmd[:60] + ("…" if len(cmd) > 60 else "")
        return f'{tool_name} → run("{shown}")'

    if tool_name in ("Edit", "Write", "NotebookEdit", "Read"):
        path = ti.get("file_path") or ti.get("notebook_path") or ""
        if not path:
            return tool_name
        return f'{tool_name} → "{path}"'

    if tool_name == "Grep":
        pattern = ti.get("pattern") or ""
        path = ti.get("path") or ""
        if pattern and path:
            return f'{tool_name} → "{pattern}" in "{path}"'
        if pattern:
            return f'{tool_name} → "{pattern}"'
        return tool_name

    if tool_name == "Glob":
        pattern = ti.get("pattern") or ""
        return f'{tool_name} → "{pattern}"' if pattern else tool_name

    if tool_name == "WebFetch":
        url = ti.get("url") or ""
        return f'{tool_name} → {url}' if url else tool_name

    if tool_name == "WebSearch":
        query = ti.get("query") or ""
        return f'{tool_name} → "{query}"' if query else tool_name

    if tool_name == "ToolSearch":
        # Claude Code's ToolSearch payload carries no query/target today
        # (it surfaces as a bare SCOPE_ASSERTED with no searchable arg),
        # so this renders as a clean "ToolSearch". Future-proof: if a
        # query field appears, show it.
        query = ti.get("query") or ti.get("q") or ""
        return f'{tool_name} → "{query}"' if query else tool_name

    if tool_name in ("Agent", "Task"):
        desc = ti.get("description") or ti.get("prompt") or ""
        if desc:
            shown = str(desc)[:60] + ("…" if len(str(desc)) > 60 else "")
            return f'{tool_name} → {shown}'
        return tool_name

    if tool_name.startswith("mcp__"):
        parts = tool_name.split("__", 2)
        if len(parts) >= 3:
            _, server, op = parts
            return f"MCP[{server}] → {op}(...)"
        return tool_name

    # Unknown tool — preserve identity, degrade payload to ???.
    return tool_name


def _format_anomaly_action(anomaly: "_EventAnomaly") -> str:
    """Render one anomaly's action line for Key Events / Focus refs.

    SCOPE_ASSERTED events render via the tool-action path (preserves
    tool identity via :func:`_format_tool_action`). Non-SCOPE events
    (MEMORY_WRITE_ATTEMPT, INTENT_DECLARED, CONTEXT_SNAPSHOT) render
    via :func:`_format_event_oneline` so operators see a meaningful
    narrative instead of ``??? → ???``.
    """
    if anomaly.event_type == "SCOPE_ASSERTED":
        return _format_tool_action(anomaly.tool_name, anomaly.tool_input or {})
    if anomaly.raw_event:
        return _format_event_oneline(anomaly.raw_event)
    return "(unknown event)"


def _format_nontool_event(event: dict) -> str:
    """Render a non-tool event as narrative per §5.6, not schema.

    Examples:
        INTENT_DECLARED → none provided
        CONTEXT_SNAPSHOT → unclassified context (44 tokens)
        AGENT_REGISTERED → agent claude-code-abc123
        MEMORY_WRITE_ATTEMPT → write to filesystem
    """
    event_type = event.get("event_type", "???")
    payload = event.get("payload") if isinstance(event.get("payload"), dict) else {}

    if event_type == "AGENT_REGISTERED":
        agent_id = payload.get("agent_id") or event.get("agent_id") or "unknown"
        return f"{event_type} → agent {agent_id}"

    if event_type == "INTENT_DECLARED":
        source = payload.get("intent_source") or "none"
        if source in (None, "none", "", "unknown"):
            return f"{event_type} → none provided"
        objective = payload.get("stated_objective")
        if objective:
            shown = str(objective)[:50] + ("…" if len(str(objective)) > 50 else "")
            return f'{event_type} → "{shown}" (source={source})'
        return f"{event_type} → source={source}"

    if event_type == "CONTEXT_SNAPSHOT":
        tokens = payload.get("context_size_tokens")
        classification = payload.get("classification_source") or "unclassified"
        if tokens is not None:
            return f"{event_type} → {classification} context ({tokens} tokens)"
        return f"{event_type} → {classification} context"

    if event_type == "MEMORY_WRITE_ATTEMPT":
        target = payload.get("target_store") or "unknown target"
        return f"{event_type} → write to {target}"

    if event_type == "GOVERNANCE_ERROR":
        err = payload.get("error_type") or "unknown"
        return f"{event_type} → {err}"

    return f"{event_type} → ???"


def _format_event_oneline(event: dict) -> str:
    """Render any event as a single indented narrative line.

    For SCOPE_ASSERTED: ``<primitive> → <tool> → <action>``.
    For everything else: delegated to :func:`_format_nontool_event`.
    """
    event_type = event.get("event_type", "???")
    if event_type == "SCOPE_ASSERTED":
        tool_name = _extract_tool_name(event)
        tool_input = _extract_tool_input(event)
        action = _format_tool_action(tool_name, tool_input)
        # action already contains `<tool> → <payload>`; prefix with primitive.
        return f"{event_type} → {action}"
    return _format_nontool_event(event)


# ---------------------------------------------------------------------------
# Focus derivation — §5.3, MUST derive from Summary's anomaly list
# (§5.2 coupling rule). Never compute anomalies twice.
# ---------------------------------------------------------------------------


@dataclass
class _FocusBullet:
    marker: str  # always "⚠" per §5.3
    description: str  # plain-English ("write operations outside declared scope")
    refs: List[str]  # event-formatted references


def _build_focus_bullets(cls: _ClassifiedSession) -> List[_FocusBullet]:
    """Group anomalies into up to 4 user-impact-ordered bullets.

    Grouping strategy:
      1. Destructive ops (rank 1) -> "N write operations outside declared scope"
      2. Unexpected commands (rank 2) -> "N unexpected command executions"
      3. Scope mismatches (rank 3) -> "N scope mismatches"
      4. Context/escalation (rank 4) -> "N context escalations"
      Everything else (rank 5) -> "N other anomalies"

    Each bullet's ``refs`` holds up to 3 concrete event-formatted
    references for inline display (§5.3 example shape).
    """
    if not cls.anomalies:
        return []

    groups: Dict[int, List[_EventAnomaly]] = defaultdict(list)
    for a in cls.anomalies:
        groups[a.user_impact_rank].append(a)

    rank_to_label = {
        1: "write operations outside declared scope",
        2: "unexpected command executions",
        3: "scope mismatches",
        4: "context escalations",
        5: "other anomalies",
    }

    bullets: List[_FocusBullet] = []
    for rank in sorted(groups.keys()):
        group = groups[rank]
        label = rank_to_label[rank]
        refs = []
        for a in group[:3]:
            refs.append(_format_anomaly_action(a))
        bullets.append(
            _FocusBullet(
                marker="⚠",
                description=f"{len(group)} {label}",
                refs=refs,
            )
        )

    return bullets[:4]


# ---------------------------------------------------------------------------
# Render — the six-block output of `sentience open`.
# ---------------------------------------------------------------------------


def _render_header(session_id: str, events: List[dict]) -> str:
    first_ts = ""
    for ev in events:
        ts = ev.get("timestamp_utc") or ev.get("timestamp") or ""
        if ts:
            first_ts = ts.split(".")[0].replace("T", " ")
            break
    return (
        f"Session: {session_id}\n"
        f"Time:    {first_ts or 'unknown'}\n"
        f"Events:  {len(events)}\n"
    )


def _render_summary(cls: _ClassifiedSession) -> str:
    if cls.anomalies:
        status_line = "Status: ⚠ anomalies detected\n"
        lines = [status_line, ""]
        total = sum(cls.anomaly_code_counts.values())
        lines.append(f"⚠ Violations: {total}")
        for code, n in cls.anomaly_code_counts.most_common():
            g = _gloss(code)
            suffix = f" — {g}" if g else ""
            lines.append(f"  - {n} {code}{suffix}")
    else:
        lines = [
            "Status: ✓ baseline behavior",
            "",
            "No violations beyond expected Claude Code baseline.",
        ]

    lines.append("")
    lines.append("Top tools:")
    top = cls.tool_counts.most_common(5)
    if top:
        for tool, n in top:
            lines.append(f"  {tool} ({n})")
    else:
        lines.append("  (none)")
    lines.append("")
    return "Summary\n\n" + "\n".join(lines)


def _render_focus(cls: _ClassifiedSession) -> str:
    header = "Focus (what to pay attention to)\n\n"
    if not cls.anomalies:
        return header + "No anomalies detected. Observed flags match expected Claude Code baseline behavior.\n"
    bullets = _build_focus_bullets(cls)
    body_lines: List[str] = []
    for b in bullets:
        refs_text = ""
        if b.refs:
            refs_text = " (" + "; ".join(b.refs) + ")"
        body_lines.append(f"• {b.marker} {b.description}{refs_text}")
    return header + "\n".join(body_lines) + "\n"


def _render_notes(cls: _ClassifiedSession) -> str:
    """Shown only when at least one baseline code crossed the threshold."""
    if not cls.baseline_codes_present:
        return ""
    lines = ["Notes", ""]
    if "INTENT_MISSING" in cls.baseline_codes_present:
        lines.append("- INTENT_MISSING is expected (Claude Code does not expose intent yet)")
    if ("POL-003" in cls.baseline_codes_present
            or "CONTEXT_UNCLASSIFIED" in cls.baseline_codes_present):
        lines.append("- POL-003 appears on most context reads (current classification limitation)")
    lines.append("- Focus on:")
    lines.append("    • scope mismatches")
    lines.append("    • write operations")
    lines.append("    • unexpected tool usage")
    lines.append("")
    return "\n".join(lines)


def _render_key_events(cls: _ClassifiedSession) -> str:
    header = "Key Events\n\n"
    if not cls.anomalies:
        return header + "No violations detected in this session.\n"

    ordered = sorted(
        cls.anomalies,
        key=lambda a: (a.user_impact_rank, a.sequence),
    )
    shown = ordered[:10]
    more = len(ordered) - len(shown)

    blocks: List[str] = []
    for a in shown:
        action = _format_anomaly_action(a)
        gloss = _gloss(a.code)
        issue = f"{a.code} ({gloss})" if gloss else a.code
        blocks.append(f"⚠ [{a.sequence}] {action}\n    Issue: {issue}")
    out = "\n\n".join(blocks) + "\n"
    if more > 0:
        out += f"\n... and {more} more (see Full Trace)\n"
    return header + out


def _render_full_trace(events: List[dict]) -> str:
    header = "Full Trace\n\n"
    lines: List[str] = []
    for ev in events:
        seq = ev.get("event_sequence_number", "?")
        line = _format_event_oneline(ev)
        lines.append(f"[{seq}] {line}")
    return header + "\n".join(lines) + "\n"


def _render_footer(trace_dir: Path, session_file: Optional[Path]) -> str:
    raw_path = str(session_file) if session_file else str(trace_dir)
    return (
        "Next steps\n\n"
        "View all sessions → sentience list\n"
        "Open another      → sentience open <session_id>\n"
        f"Raw JSONL         → cat {raw_path}\n"
        "\n"
        "Tip: after running Claude Code, use `sentience open --latest` to review the session.\n"
    )


def render_open(
    session_id: str,
    events: List[dict],
    session_file: Path,
    summary: bool = False,
) -> str:
    """Compose the output for one session.

    ``summary=False`` (default): six-block output — Header, Summary,
    Focus, Notes, Key Events, Full Trace, Footer.

    ``summary=True``: skips the Full Trace block. Fits on one terminal
    screen for the typical session. Every anomaly still surfaces in
    Key Events; the JSONL file on disk is unchanged. The footer
    already tells operators where to read the raw events if they
    need them.

    Note: this is not a filter on event content. The Full Trace
    invariant ("every event rendered in order") holds on the default
    output; ``--summary`` only controls whether that block is
    printed to the terminal.
    """
    cls = classify_session(events)
    blocks = [
        _render_header(session_id, events),
        _render_summary(cls),
        _render_focus(cls),
        _render_notes(cls),
        _render_key_events(cls),
    ]
    if not summary:
        blocks.append(_render_full_trace(events))
    blocks.append(_render_footer(session_file.parent, session_file))
    # Notes block is empty for clean sessions — elide it cleanly.
    return "\n".join(b for b in blocks if b)


# ---------------------------------------------------------------------------
# Session discovery — shared by `list`, `open --latest`, `open <id>`.
# ---------------------------------------------------------------------------


def _session_start_epoch(path: Path) -> Optional[float]:
    """Epoch seconds of a session's first event, or None if unavailable.

    The first event's ``timestamp_utc`` is the session-start time. Unlike
    file mtime, it is STABLE: it does not advance as the session appends
    more events. Used as the primary ordering key so an actively-written
    live session does not keep jumping to the top between consecutive CLI
    invocations (F-V4).

    Defensive — returns None on any read/parse failure so the caller can
    fall back to mtime.
    """
    try:
        with open(path, "r", encoding="utf-8") as f:
            line = f.readline()
        if not line.strip():
            return None
        ts = json.loads(line).get("timestamp_utc")
        if not ts:
            return None
        return datetime.fromisoformat(str(ts).replace("Z", "+00:00")).timestamp()
    except (OSError, ValueError, json.JSONDecodeError):
        return None


def _list_session_files(trace_dir: Path) -> List[Path]:
    """Return .jsonl session files in the directory, newest first.

    Ordering key is ``(session_start_time, mtime)`` descending:
      - **Primary: session-start time** (first event's timestamp_utc).
        Stable across invocations — a live session being appended does
        not reorder, so `list`, `open --latest`, and `analyze --latest`
        always agree on which session is "latest" (F-V4).
      - **Secondary: mtime** — tiebreaker when start times are equal or
        unavailable (e.g. fixtures sharing a timestamp, or malformed
        first events). Falls back to pure-mtime behavior in those cases.

    Excludes the ``.jsonl.index`` sidecar glob automatically (Path.glob
    suffix match is strict).
    """
    if not trace_dir.exists() or not trace_dir.is_dir():
        return []
    files = [p for p in trace_dir.glob("*.jsonl") if p.is_file()]

    def _key(p: Path) -> Tuple[float, float]:
        mtime = p.stat().st_mtime
        start = _session_start_epoch(p)
        return (start if start is not None else mtime, mtime)

    files.sort(key=_key, reverse=True)
    return files


def _load_session(path: Path) -> Tuple[str, List[dict]]:
    """Load one session file, return (session_id, events).

    Uses the shared ``parse_events`` so NDJSON / JSON-array parsing
    stays consistent with ``sentience-cli``. If the file contains
    multiple session_ids (shared-file mode), returns only the
    session_id matching the filename stem, falling back to the first
    session_id encountered.
    """
    with open(path, encoding="utf-8") as fh:
        sessions = parse_events(fh)
    if not sessions:
        return (path.stem, [])
    if path.stem in sessions:
        return (path.stem, sessions[path.stem])
    # Shared-file or stem mismatch — pick the first session encountered.
    first = next(iter(sessions))
    return (first, sessions[first])


def _relative_time(mtime: float, now: Optional[float] = None) -> str:
    now = now or time.time()
    delta = max(0, now - mtime)
    if delta < 60:
        return "just now"
    if delta < 3600:
        return f"{int(delta / 60)}m ago"
    if delta < 86400:
        return f"{int(delta / 3600)}h ago"
    if delta < 7 * 86400:
        return f"{int(delta / 86400)}d ago"
    # Over a week — show absolute date.
    return time.strftime("%Y-%m-%d", time.localtime(mtime))


# ---------------------------------------------------------------------------
# Subcommand handlers
# ---------------------------------------------------------------------------


def run_status(args: argparse.Namespace) -> int:
    """`sentience status` — is the hook capturing sessions?"""
    trace_dir = _resolve_trace_dir()

    if not trace_dir.exists():
        print("Sentience Status\n")
        print(f"Hook:           not detected")
        print(f"Trace path:     {trace_dir}")
        print()
        print("No sessions found yet.")
        print()
        print("Run Claude Code with the hook enabled, then run:")
        print("    sentience status")
        return 1

    files = _list_session_files(trace_dir)
    if not files:
        print("Sentience Status\n")
        print(f"Hook:           trace path available")
        print(f"Trace path:     {trace_dir}")
        print()
        print("No sessions captured yet.")
        print()
        print("Run Claude Code with the hook enabled, then run:")
        print("    sentience status")
        return 1

    # At least one session exists.
    latest = files[0]
    session_id, events = _load_session(latest)

    # Count violations (anomalies only, matching Summary semantics).
    cls = classify_session(events)
    violation_total = sum(cls.anomaly_code_counts.values())

    # Pick a sample event for the status — prefer a SCOPE_ASSERTED so
    # the reader sees a tool invocation; fall back to any event.
    sample_line = ""
    for ev in events:
        if ev.get("event_type") == "SCOPE_ASSERTED":
            tool_name = _extract_tool_name(ev)
            sample_line = _format_tool_action(tool_name, _extract_tool_input(ev))
            break
    if not sample_line and events:
        sample_line = _format_event_oneline(events[0])

    ts = latest.stat().st_mtime
    ts_str = time.strftime("%Y-%m-%d %H:%M", time.localtime(ts))

    print("Sentience Status\n")
    print(f"Hook:           sessions detected")
    print(f"Trace path:     {trace_dir}")
    print()
    print("Last session:")
    print(f"  ID:           {session_id}")
    print(f"  Time:         {ts_str}")
    print(f"  Events:       {len(events)}")
    print(f"  Violations:   {violation_total}")
    if sample_line:
        print()
        print("Sample event:")
        print(f"  {sample_line}")
    print()
    print("Sentience is governing your Claude Code sessions locally.")
    return 0


def run_list(args: argparse.Namespace) -> int:
    """`sentience list` — what sessions exist?"""
    trace_dir = _resolve_trace_dir()
    files = _list_session_files(trace_dir)
    if not files:
        print("No sessions found yet.")
        print()
        print("Run Claude Code with the hook enabled, then run:")
        print("    sentience status")
        return 0

    print("Sentience Sessions\n")

    shown = files[:20]
    for i, f in enumerate(shown, start=1):
        session_id, events = _load_session(f)
        cls = classify_session(events)
        violation_total = sum(cls.anomaly_code_counts.values())
        symbol = "⚠" if violation_total > 0 else "✓"
        rel = _relative_time(f.stat().st_mtime)
        # Short session id for display (first 12 chars).
        sid_short = session_id[:12] if session_id else f.stem[:12]
        print(
            f"{i:>2}. {sid_short:<16} {rel:<8} "
            f"{len(events):>3} events   {symbol} {violation_total}"
        )

    if len(files) > 20:
        print()
        print(f"Showing latest 20 sessions (of {len(files)} total)")

    print()
    print("Tip:")
    print("Open latest session → sentience open --latest")
    print("Open specific      → sentience open <session_id>")
    return 0


def run_open(args: argparse.Namespace) -> int:
    """`sentience open [--latest | <session_id> | <path>]` — render one session.

    Accepts a session-id prefix, a trace file path, or --latest — the
    same forms `sentience analyze` accepts (F-V10), via the shared
    resolver.
    """
    target, err = _resolve_session_target(args.session_id, args.latest)
    if target is None:
        print(err, file=sys.stderr)
        return 1

    session_id, events = _load_session(target)
    if not events:
        print(f"Session file {target} has no parseable events.", file=sys.stderr)
        return 1

    summary_mode = getattr(args, "summary", False)
    out = render_open(session_id, events, target, summary=summary_mode)
    print(out)
    return 0


# ---------------------------------------------------------------------------
# Analyze subcommand — undeclared-intent
# ---------------------------------------------------------------------------


_REPORTS_DIR = Path.home() / ".sentience" / "reports"


def _bundled_showcase_path() -> Optional[Path]:
    """Return the path to the bundled closed-loop showcase trace, or None.

    Ships inside the package (``sentience_governor/data/showcase/``) so a
    fresh-install operator can see a populated analysis via
    ``sentience analyze undeclared-intent --showcase`` before they have
    wired token capture (F-V5). The package installs as regular files
    (not zip-imported), so the resource path is directly usable.
    """
    try:
        from importlib import resources

        ref = resources.files("sentience_governor").joinpath(
            "data/showcase/v025-closed-loop.jsonl"
        )
        p = Path(str(ref))
        return p if p.is_file() else None
    except (ModuleNotFoundError, AttributeError, OSError, TypeError):
        return None


def _resolve_session_target(
    target: Optional[str],
    latest: bool,
) -> Tuple[Optional[Path], Optional[str]]:
    """Resolve a session reference to a trace file path.

    Shared by `sentience open` AND `sentience analyze` so both
    subcommands accept the same forms (F-V10 — previously `open` only
    accepted session-id prefixes, while `analyze` also accepted file
    paths).

    Returns ``(path, error_message)``. On success ``error_message`` is
    None; on failure ``path`` is None.

    Resolution order:
      1. ``target`` is an existing file path → use it directly.
      2. ``target`` looks like a path (contains '/' or .jsonl suffix)
         but does not exist → clear file-not-found error (not treated
         as a session prefix).
      3. ``latest`` (or no target) → newest session in the trace dir.
      4. Otherwise treat ``target`` as a session-id prefix.
    """
    # File-path mode (does not depend on the trace dir).
    if target:
        candidate = Path(target).expanduser()
        if candidate.is_file():
            return candidate, None
        if "/" in target or candidate.suffix == ".jsonl":
            return None, f"Trace file not found: {target}"

    trace_dir = _resolve_trace_dir()
    files = _list_session_files(trace_dir)
    if not files:
        return None, (
            f"No sessions found under {trace_dir}.\n"
            "Run a Claude Code session with the hook enabled, "
            "or pass an explicit trace file path."
        )

    if latest or not target:
        return files[0], None

    # Session-id prefix match.
    exact = [f for f in files if f.stem == target]
    if exact:
        return exact[0], None
    prefix = [f for f in files if f.stem.startswith(target)]
    if len(prefix) == 1:
        return prefix[0], None
    if len(prefix) > 1:
        names = "\n".join(f"  {f.stem}" for f in prefix[:10])
        return None, (
            f"Ambiguous session prefix {target!r} — {len(prefix)} matches:\n"
            f"{names}"
        )
    return None, f"No session matching {target!r}"


def _resolve_analyze_target(
    args: argparse.Namespace,
) -> Tuple[Optional[Path], Optional[str]]:
    """Thin wrapper over :func:`_resolve_session_target` for analyze."""
    return _resolve_session_target(
        getattr(args, "target", None),
        getattr(args, "latest", False),
    )


def _write_undeclared_report(result: Dict, target_path: Path) -> Path:
    """Write the saved Markdown report and return its path.

    Path shape:
      ~/.sentience/reports/undeclared-intent-<sid-prefix>-<timestamp>.md

    Side-effecting: creates the reports directory if needed.
    """
    _REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    sid = (result.get("session_id") or target_path.stem) or "unknown"
    sid_short = sid[:12].replace("/", "_")
    ts = time.strftime("%Y%m%dT%H%M%S", time.localtime())
    out = _REPORTS_DIR / f"undeclared-intent-{sid_short}-{ts}.md"
    body = render_undeclared_markdown(result)
    out.write_text(body, encoding="utf-8")
    return out


def run_analyze_undeclared_intent(args: argparse.Namespace) -> int:
    """`sentience analyze undeclared-intent [target] [flags]` handler.

    Per plan v3 §"Save prompt — behavior contract":
      - Save prompt fires only after successful render AND status==ok.
      - --json / --no-prompt suppress prompting unconditionally.
      - --save skips the prompt and writes directly.
      - On non-ok status (no_token_data / no_turns / partial), the
        save prompt is suppressed.
      - After a successful save, echo the written file path.
    """
    if getattr(args, "showcase", False):
        target_path = _bundled_showcase_path()
        if target_path is None:
            print(
                "error: bundled showcase trace not found in this install.",
                file=sys.stderr,
            )
            return 1
    else:
        target_path, err = _resolve_analyze_target(args)
        if target_path is None:
            print(err, file=sys.stderr)
            return 1

    try:
        _, events = _load_session(target_path)
    except (OSError, ValueError) as exc:
        print(f"Failed to read trace {target_path}: {exc}", file=sys.stderr)
        return 1

    result = compute_undeclared_intent_spend(events)

    # --json mode: emit structured result and exit, no prompts.
    if getattr(args, "json", False):
        print(json.dumps(result, indent=2, sort_keys=False))
        return 0

    # Human-readable render.
    print(render_undeclared_cli(result))

    # Save flow — strict P7 ordering.
    status = result.get("status")
    save_eligible = status == "ok"  # partial / no_token_data / no_turns are NOT eligible

    if getattr(args, "save", False):
        if not save_eligible:
            print(
                f"Skipping save: status={status} (only status=ok results are saved).",
                file=sys.stderr,
            )
            return 0
        out_path = _write_undeclared_report(result, target_path)
        print(f"Saved to {out_path}")
        return 0

    if getattr(args, "no_prompt", False):
        return 0

    if not save_eligible:
        return 0

    # Interactive prompt — only fires for status=ok and only after the
    # metric has already been printed above (P7 ordering).
    try:
        answer = input("Save this report? [Y/n]: ").strip().lower()
    except EOFError:
        # Non-interactive stdin — treat as decline; do not save.
        return 0
    if answer in ("", "y", "yes"):
        out_path = _write_undeclared_report(result, target_path)
        print(f"Saved to {out_path}")
    return 0


# ---------------------------------------------------------------------------
# CLI entry
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# v0.2.5 — `sentience profile ...` subcommand handlers
# ---------------------------------------------------------------------------
#
# Six verbs (per plan §CLI proposal):
#   * view      — print the active profile (defaults or file-backed)
#   * validate  — read-only schema check; never mutates the file
#   * export    — write current profile to an explicit path
#   * import    — read from explicit path, validate, install at default
#   * edit      — open the default profile file in $EDITOR
#   * init      — create a starter profile at the default path
#
# Each handler returns the process exit code (0 on success, non-zero on
# error). All output is written via print() to stdout/stderr; no
# handler ever raises (errors are translated to printed messages +
# non-zero exit).


def _read_profile_for_view(
    explicit_path: Optional[Path] = None,
) -> Tuple[GovernanceProfile, bool]:
    """Load a profile for ``view`` / ``validate``.

    Returns ``(profile, was_loaded_from_file)``. When ``explicit_path``
    is given, the profile is loaded from that path; otherwise the
    default path is consulted. ``was_loaded_from_file`` is False only
    when no file existed at the default path — useful for ``view`` to
    tell the operator "you're seeing defaults, not your file."
    """
    if explicit_path is not None:
        return GovernanceProfile.from_file(explicit_path), True
    if not DEFAULT_PROFILE_PATH.is_file():
        return GovernanceProfile.defaults(), False
    return GovernanceProfile.from_file(DEFAULT_PROFILE_PATH), True


def run_profile_view(args: argparse.Namespace) -> int:
    """Print the active profile to stdout.

    When no profile file exists, prints the defaults with a banner so
    the operator understands they're seeing the fallback, not their
    own configuration. ``--resolved`` is reserved for showing
    effective values after future inheritance (``extends``); in v0.2.5
    it behaves the same as the default view.
    """
    try:
        profile, from_file = _read_profile_for_view()
    except (ValueError, OSError) as exc:
        print(f"error: failed to load profile: {exc}", file=sys.stderr)
        return 1

    if not from_file:
        print(
            f"# No profile file found at {DEFAULT_PROFILE_PATH}.",
            file=sys.stderr,
        )
        print(
            "# Showing defaults. Run `sentience profile init` to create one.",
            file=sys.stderr,
        )
    else:
        print(f"# Source: {profile.source_path}", file=sys.stderr)
        print(f"# Fingerprint: {profile.fingerprint()}", file=sys.stderr)

    # YAML body to stdout — operators can pipe `sentience profile view`
    # straight into a file if they want a copy.
    try:
        import yaml  # local import; PyYAML is a v0.2.5 dependency
    except ImportError:
        print("error: PyYAML is required to render profiles", file=sys.stderr)
        return 1
    print(
        yaml.safe_dump(
            profile.to_dict(),
            default_flow_style=False,
            sort_keys=False,
            indent=2,
        ),
        end="",
    )
    return 0


def run_profile_validate(args: argparse.Namespace) -> int:
    """Validate the profile at the default path (or an explicit one).

    READ-ONLY: never writes to disk. Prints validation result and a
    content-hash integrity check against the file's header (if
    present). Exit 0 when valid, 1 on errors.
    """
    target_path: Optional[Path] = (
        Path(args.path) if getattr(args, "path", None) else None
    )

    try:
        profile, from_file = _read_profile_for_view(explicit_path=target_path)
    except (ValueError, OSError) as exc:
        print(f"error: failed to load profile: {exc}", file=sys.stderr)
        return 1

    if not from_file:
        print(
            f"No profile file at {DEFAULT_PROFILE_PATH}. "
            "Defaults are valid by construction.",
            file=sys.stderr,
        )
        return 0

    result = profile.validate(strict=bool(getattr(args, "strict", False)))
    print(result.format_human())

    # Integrity check: compare computed hash to header (if present).
    # Strictly read-only — we only peek the first few lines.
    header_hash = _peek_header_hash(profile.source_path)
    if header_hash is not None:
        current = profile.content_hash()
        if header_hash == current:
            print(f"content_hash: OK ({current[:12]}...)")
        else:
            # F-V9: this is informational, not an error — the operator
            # edited the file after it was generated, which is expected
            # and fine. The old "MISMATCH" wording read as a failure to
            # non-developers. The runtime always uses the recomputed
            # hash; the header is advisory and never modified here.
            print(
                f"ℹ Header hash is stale — file edited after generation. "
                f"The runtime uses the recomputed hash {current[:12]} "
                f"(header was {header_hash[:12]})."
            )

    if not result.is_valid:
        return 1
    return 0


def run_profile_export(args: argparse.Namespace) -> int:
    """Write the active profile to an explicit path with a fresh header."""
    dest = Path(args.path).expanduser()
    try:
        profile, _ = _read_profile_for_view()
        profile.export(dest)
    except (ValueError, OSError) as exc:
        print(f"error: export failed: {exc}", file=sys.stderr)
        return 1
    print(f"Exported profile to {dest}")
    return 0


def run_profile_import(args: argparse.Namespace) -> int:
    """Read a profile from an explicit path, validate, install at default.

    Errors out if validation fails so operators can't accidentally
    install a broken file. The destination is overwritten on success
    (operator is expected to back up first if needed).
    """
    src = Path(args.path).expanduser()
    if not src.is_file():
        print(f"error: source file not found: {src}", file=sys.stderr)
        return 1

    try:
        profile = GovernanceProfile.from_file(src)
    except (ValueError, OSError) as exc:
        print(f"error: failed to read {src}: {exc}", file=sys.stderr)
        return 1

    result = profile.validate(strict=False)
    if not result.is_valid:
        print("Import refused — profile failed validation:", file=sys.stderr)
        print(result.format_human(), file=sys.stderr)
        return 1

    try:
        profile.export(DEFAULT_PROFILE_PATH)
    except OSError as exc:
        print(f"error: failed to install profile: {exc}", file=sys.stderr)
        return 1
    print(f"Imported {src} -> {DEFAULT_PROFILE_PATH}")
    return 0


def _resolve_editor_command() -> Optional[List[str]]:
    """Resolve an editor launch command, or None if none is available.

    F-V8: macOS does not set ``$EDITOR`` by default, and a non-developer
    operator is unlikely to have configured it. Rather than hard-error,
    fall back through a sensible chain:
      1. ``$VISUAL``
      2. ``$EDITOR``
      3. ``nano`` → ``vim`` → ``vi`` (whichever is on PATH)
      4. macOS only: ``open -e`` (TextEdit)

    Returns the command as a list prefix (so multi-arg launchers like
    ``open -e`` work), to which the file path is appended by the caller.
    """
    import shutil

    for env_var in ("VISUAL", "EDITOR"):
        val = os.environ.get(env_var, "").strip()
        if val:
            return [val]

    for editor in ("nano", "vim", "vi"):
        if shutil.which(editor):
            return [editor]

    if sys.platform == "darwin" and shutil.which("open"):
        return ["open", "-e"]

    return None


def run_profile_edit(args: argparse.Namespace) -> int:
    """Open the default profile file in an editor.

    Does NOT create the file; that's ``init``'s job (single
    responsibility). If the file doesn't exist, prints a hint and
    exits non-zero so operators don't silently end up editing an
    empty buffer.
    """
    if not DEFAULT_PROFILE_PATH.is_file():
        print(
            f"error: no profile at {DEFAULT_PROFILE_PATH}. "
            "Run `sentience profile init` first.",
            file=sys.stderr,
        )
        return 1

    editor_cmd = _resolve_editor_command()
    if editor_cmd is None:
        print(
            "error: no editor found. Set $EDITOR (e.g. `export EDITOR=nano`) "
            "or install nano/vim, then try again.",
            file=sys.stderr,
        )
        return 1

    import subprocess  # local import; only used here
    try:
        result = subprocess.run([*editor_cmd, str(DEFAULT_PROFILE_PATH)])
    except (FileNotFoundError, OSError) as exc:
        print(
            f"error: failed to launch editor {' '.join(editor_cmd)!r}: {exc}",
            file=sys.stderr,
        )
        return 1
    return result.returncode


def run_profile_init(args: argparse.Namespace) -> int:
    """Create a starter profile at the default path.

    Refuses to overwrite an existing file (operator must delete or
    move the old file first — never silent loss).
    """
    if DEFAULT_PROFILE_PATH.exists():
        print(
            f"error: {DEFAULT_PROFILE_PATH} already exists. "
            "Delete or move it before running init.",
            file=sys.stderr,
        )
        return 1

    profile = GovernanceProfile.defaults()
    try:
        profile.export(DEFAULT_PROFILE_PATH)
    except OSError as exc:
        print(f"error: failed to write {DEFAULT_PROFILE_PATH}: {exc}", file=sys.stderr)
        return 1
    print(f"Created starter profile at {DEFAULT_PROFILE_PATH}")
    print("Run `sentience profile view` to see it, or `sentience profile edit` to tune it.")
    return 0


def _peek_header_hash(path: Path) -> Optional[str]:
    """Return the SHA256 hash from a profile file's header, or None.

    Reads only the first few lines (header lives at the top); never
    parses or modifies the YAML body. Defensive — returns None on any
    failure rather than raising.
    """
    try:
        with open(path, "r", encoding="utf-8") as f:
            for _ in range(10):  # header is at most a few lines
                line = f.readline()
                if not line:
                    return None
                # Expected shape: "# Content hash: sha256:<64 hex>"
                stripped = line.strip()
                if stripped.startswith("# Content hash:"):
                    _, _, value = stripped.partition(":")
                    # value is now "sha256:<hex>" with possible leading space
                    value = value.strip()
                    if value.startswith("sha256:"):
                        return value[len("sha256:") :]
                    return value
    except OSError:
        return None
    return None


_HOOK_BINARY_NAME = "sentience-claude-code-hook"


def _resolve_hook_binary() -> Optional[str]:
    """Return the absolute path to the ``sentience-claude-code-hook`` binary.

    Resolution order, designed to work across install methods
    (pipx-isolated venv, pip-in-venv, dev source):
      1. The directory containing the running interpreter
         (``sys.executable``) — this is the hook that belongs to the
         SAME install as the ``sentience`` binary being run. Preferred
         first because ``shutil.which`` can otherwise pick a *different*
         install that happens to be earlier on PATH (e.g. a global pipx
         install shadowing a project venv), which would wire a hook of
         the wrong version. Checks both POSIX (``bin/``) and Windows
         (``Scripts/`` next to ``python.exe``, ``.exe`` suffix) layouts.
      2. ``shutil.which`` — fallback for unusual layouts where the hook
         is not a sibling of the interpreter but is on PATH.

    Returns None if the binary cannot be located; the caller decides
    how to surface that.
    """
    import shutil

    # NB: do NOT .resolve() sys.executable — a venv/pipx `python` is a
    # symlink to the base interpreter, and resolving it would jump OUT of
    # the venv bin dir (where the hook sibling lives) into the base
    # Python's bin (where it does not), defeating this whole branch. Use
    # the unresolved parent: the bin dir the running script lives in.
    interp_dir = Path(sys.executable).parent
    for cand in (
        interp_dir / _HOOK_BINARY_NAME,
        interp_dir / f"{_HOOK_BINARY_NAME}.exe",  # Windows
    ):
        if cand.is_file():
            return str(cand)

    found = shutil.which(_HOOK_BINARY_NAME)
    if found:
        return str(Path(found).resolve())

    return None


def _hook_entry(command: str) -> dict:
    """The canonical hook entry shape written into .claude/settings.json."""
    return {"matcher": "", "hooks": [{"type": "command", "command": command}]}


def _entry_has_command(entries: list, command: str) -> bool:
    """True if any hook entry in ``entries`` already wires ``command``."""
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        for hook in entry.get("hooks", []):
            if isinstance(hook, dict) and hook.get("command") == command:
                return True
    return False


def run_init_claude_code(args: argparse.Namespace) -> int:
    """`sentience init claude-code [path]` — wire the Claude Code hook.

    Writes (or idempotently merges into) ``<path>/.claude/settings.json``
    so Claude Code invokes the sentience hook on every tool call. Does
    NOT clobber the operator's other hooks or settings.
    """
    project_dir = Path(getattr(args, "path", None) or ".").expanduser().resolve()
    if not project_dir.is_dir():
        print(f"error: {project_dir} is not a directory.", file=sys.stderr)
        return 1

    command = _resolve_hook_binary()
    if command is None:
        print(
            f"error: could not locate the {_HOOK_BINARY_NAME!r} binary.\n"
            "It ships with sentience-governor — confirm the install "
            "(e.g. `pipx list | grep sentience-governor`) and that its "
            "bin directory exists.",
            file=sys.stderr,
        )
        return 1

    claude_dir = project_dir / ".claude"
    settings_path = claude_dir / "settings.json"

    # Load existing settings (tolerant of absent / empty / invalid file).
    settings: dict = {}
    if settings_path.is_file():
        try:
            raw = settings_path.read_text(encoding="utf-8").strip()
            settings = json.loads(raw) if raw else {}
            if not isinstance(settings, dict):
                print(
                    f"error: {settings_path} does not contain a JSON object; "
                    "refusing to overwrite. Inspect it manually.",
                    file=sys.stderr,
                )
                return 1
        except (OSError, json.JSONDecodeError) as exc:
            print(
                f"error: could not read existing {settings_path}: {exc}. "
                "Fix or remove it, then re-run.",
                file=sys.stderr,
            )
            return 1

    hooks = settings.setdefault("hooks", {})
    if not isinstance(hooks, dict):
        print(
            f"error: 'hooks' in {settings_path} is not an object; refusing "
            "to overwrite. Inspect it manually.",
            file=sys.stderr,
        )
        return 1

    added = []
    already = []
    for event in ("PreToolUse", "PostToolUse"):
        entries = hooks.setdefault(event, [])
        if not isinstance(entries, list):
            print(
                f"error: hooks.{event} in {settings_path} is not a list; "
                "refusing to overwrite. Inspect it manually.",
                file=sys.stderr,
            )
            return 1
        if _entry_has_command(entries, command):
            already.append(event)
        else:
            entries.append(_hook_entry(command))
            added.append(event)

    if not added:
        print(f"Hook already wired in {settings_path} ({', '.join(already)}).")
        print("Nothing to do.")
        return 0

    try:
        claude_dir.mkdir(parents=True, exist_ok=True)
        settings_path.write_text(
            json.dumps(settings, indent=2) + "\n", encoding="utf-8"
        )
    except OSError as exc:
        print(f"error: failed to write {settings_path}: {exc}", file=sys.stderr)
        return 1

    print(f"Hook installed in {settings_path}")
    print(f"  command: {command}")
    print(f"  events:  {', '.join(added)}" + (
        f"  (already present: {', '.join(already)})" if already else ""
    ))
    print()
    print(f"Run Claude Code from {project_dir}, then: sentience status")
    return 0


def run_demo(args: argparse.Namespace) -> int:
    """`sentience demo <name>` — run a packaged, self-contained demo.

    Demos ship inside the package (F-V6) so they run from any install
    without the operator needing a Python path. Two demos:
      - undeclared-intent: a synthesized drift session (~20.7% undeclared)
      - closed-loop: the bundled clean showcase trace (100% declared)
    """
    name = getattr(args, "demo_name", None)

    if name == "undeclared-intent":
        from sentience_governor.demos import build_session_events

        events = build_session_events()
        result = compute_undeclared_intent_spend(events)
        print(render_undeclared_cli(result))
        print()
        print("This is a synthesized demo session. Re-run the analyzer on "
              "any captured trace with:")
        print("    sentience analyze undeclared-intent <session-id | path>")
        return 0

    if name == "closed-loop":
        path = _bundled_showcase_path()
        if path is None:
            print(
                "error: bundled showcase trace not found in this install.",
                file=sys.stderr,
            )
            return 1
        _, events = _load_session(path)
        result = compute_undeclared_intent_spend(events)
        print(render_undeclared_cli(result))
        return 0

    # No demo name (shouldn't happen — argparse requires it) — list them.
    print("Available demos:")
    print("  sentience demo undeclared-intent   Synthesized drift session.")
    print("  sentience demo closed-loop         Clean closed-loop showcase.")
    return 0


def _print_command_guide() -> int:
    """Friendly guide printed when `sentience` is run with no subcommand.

    F-V2: a first-time operator who types `sentience` to "see what's
    there" should get useful guidance, not an argparse error. argparse
    with required subcommands would exit non-zero before any of our
    code ran; instead we make the subcommand optional and route here.
    """
    print("Sentience Governor — local governance for agent sessions.")
    print()
    print("Commands:")
    print("  sentience status            Check the hook is capturing sessions.")
    print("  sentience list              List captured sessions, newest first.")
    print("  sentience open <id>         Render one session (Summary / Key Events / Trace).")
    print("  sentience analyze <metric>  Run a derived-metric analyzer over a session.")
    print("  sentience profile <verb>    View / validate / edit the governance profile.")
    print("  sentience init claude-code  Wire the Claude Code hook into a project.")
    print()
    print("New here? Start with:")
    print("    sentience status")
    print()
    print("Run any command with -h for details (e.g. `sentience analyze -h`).")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="sentience",
        description=(
            "Sentience Governor — curated viewer for agent-hook session traces "
            "(Claude Code today; more coming). Pairs with the raw "
            "`sentience-cli` tool for library-trace inspection."
        ),
    )
    # F-V2: subcommand is optional. Bare `sentience` routes to a helpful
    # guide (see end of main) instead of an argparse "required argument"
    # error. A bad subcommand still errors via argparse as before.
    subparsers = parser.add_subparsers(dest="command", required=False)

    p_status = subparsers.add_parser(
        "status", help="Check that the hook is capturing sessions."
    )
    p_status.set_defaults(func=run_status)

    p_list = subparsers.add_parser(
        "list", help="List captured sessions, newest first (max 20)."
    )
    p_list.set_defaults(func=run_list)

    p_open = subparsers.add_parser(
        "open",
        help="Render one session with Summary / Focus / Notes / Key Events / Full Trace.",
    )
    p_open.add_argument(
        "session_id",
        nargs="?",
        default=None,
        help=(
            "Session id (or prefix) under the default trace dir, OR a "
            "path to a .jsonl trace file. If omitted, uses --latest."
        ),
    )
    p_open.add_argument(
        "--latest",
        action="store_true",
        help="Open the most recently modified session (default when no session_id given).",
    )
    p_open.add_argument(
        "--summary",
        action="store_true",
        help=(
            "Skip the Full Trace block so the rendered output fits on "
            "one terminal screen. Header, Summary, Focus, Notes, Key "
            "Events, and Footer all print as usual. Every event is "
            "still on disk in the JSONL; the footer shows the path."
        ),
    )
    p_open.set_defaults(func=run_open)

    # ------------------------------------------------------------------
    # `sentience analyze ...` — derived metrics over v0.2.3+ traces.
    # First sub-subcommand: `undeclared-intent` (v0.2.4).
    # ------------------------------------------------------------------
    p_analyze = subparsers.add_parser(
        "analyze",
        help=(
            "Run a derived-metric analyzer over a captured session trace."
        ),
    )
    analyze_subparsers = p_analyze.add_subparsers(
        dest="analyzer", required=True
    )

    p_undeclared = analyze_subparsers.add_parser(
        "undeclared-intent",
        help=(
            "Compute how much compute was attributed to turns that "
            "touched execution outside the session's declared intent."
        ),
    )
    p_undeclared.add_argument(
        "target",
        nargs="?",
        default=None,
        help=(
            "Session id (or prefix) under the default trace dir, OR a "
            "path to an .jsonl trace file. If omitted, uses --latest."
        ),
    )
    p_undeclared.add_argument(
        "--latest",
        action="store_true",
        help="Analyze the most recently captured session.",
    )
    p_undeclared.add_argument(
        "--showcase",
        action="store_true",
        help=(
            "Analyze the bundled closed-loop showcase trace — a populated "
            "example you can run on a fresh install before wiring token "
            "capture. Ignores any target/--latest."
        ),
    )
    p_undeclared.add_argument(
        "--json",
        action="store_true",
        help="Emit structured JSON instead of human-readable output.",
    )
    p_undeclared.add_argument(
        "--save",
        action="store_true",
        help=(
            "Skip the interactive prompt and write the Markdown report "
            "directly to ~/.sentience/reports/."
        ),
    )
    p_undeclared.add_argument(
        "--no-prompt",
        action="store_true",
        dest="no_prompt",
        help="Disable the post-render save prompt entirely.",
    )
    p_undeclared.set_defaults(func=run_analyze_undeclared_intent)

    # ------------------------------------------------------------------
    # `sentience profile ...` — v0.2.5 governance profile commands.
    # ------------------------------------------------------------------
    p_profile = subparsers.add_parser(
        "profile",
        help=(
            "View, validate, and manage the operator-authored "
            "governance profile (~/.sentience/profile.yaml)."
        ),
    )
    profile_subparsers = p_profile.add_subparsers(
        dest="profile_verb", required=True
    )

    pv_view = profile_subparsers.add_parser(
        "view",
        help="Print the active profile (defaults if no file exists).",
    )
    pv_view.add_argument(
        "--resolved",
        action="store_true",
        help=(
            "Show effective values after resolving inheritance "
            "(reserved for future `extends`; v0.2.5 behaves the same "
            "as plain view)."
        ),
    )
    pv_view.set_defaults(func=run_profile_view)

    pv_validate = profile_subparsers.add_parser(
        "validate",
        help=(
            "Validate the profile schema. Read-only: never modifies "
            "the file."
        ),
    )
    pv_validate.add_argument(
        "path",
        nargs="?",
        default=None,
        help="Path to validate (defaults to ~/.sentience/profile.yaml).",
    )
    pv_validate.add_argument(
        "--strict",
        action="store_true",
        help="Error on unknown keys instead of warning.",
    )
    pv_validate.set_defaults(func=run_profile_validate)

    pv_export = profile_subparsers.add_parser(
        "export",
        help="Write the active profile to an explicit path with a fresh header.",
    )
    pv_export.add_argument(
        "path",
        help="Destination file path.",
    )
    pv_export.set_defaults(func=run_profile_export)

    pv_import = profile_subparsers.add_parser(
        "import",
        help=(
            "Read a profile from a path, validate, install at "
            "~/.sentience/profile.yaml."
        ),
    )
    pv_import.add_argument(
        "path",
        help="Source file path.",
    )
    pv_import.set_defaults(func=run_profile_import)

    pv_edit = profile_subparsers.add_parser(
        "edit",
        help="Open ~/.sentience/profile.yaml in $EDITOR.",
    )
    pv_edit.set_defaults(func=run_profile_edit)

    pv_init = profile_subparsers.add_parser(
        "init",
        help="Create a starter profile at ~/.sentience/profile.yaml.",
    )
    pv_init.set_defaults(func=run_profile_init)

    # ------------------------------------------------------------------
    # `sentience init ...` — one-command runtime wiring.
    # First target: `claude-code` (writes/merges .claude/settings.json).
    # ------------------------------------------------------------------
    p_init = subparsers.add_parser(
        "init",
        help="Wire a runtime's hook so sentience captures its sessions.",
    )
    init_subparsers = p_init.add_subparsers(dest="runtime", required=True)

    pi_claude = init_subparsers.add_parser(
        "claude-code",
        help=(
            "Install the Claude Code hook into a project's "
            ".claude/settings.json (idempotent merge)."
        ),
    )
    pi_claude.add_argument(
        "path",
        nargs="?",
        default=None,
        help=(
            "Project directory to wire (defaults to the current "
            "directory). The hook is written to <path>/.claude/settings.json."
        ),
    )
    pi_claude.set_defaults(func=run_init_claude_code)

    # ------------------------------------------------------------------
    # `sentience demo ...` — packaged runnable demos (F-V6). Importable
    # from any install, so no Python-path knowledge needed.
    # ------------------------------------------------------------------
    p_demo = subparsers.add_parser(
        "demo",
        help="Run a packaged demo session through the analyzer.",
    )
    p_demo.add_argument(
        "demo_name",
        choices=["undeclared-intent", "closed-loop"],
        help=(
            "Which demo to run. 'undeclared-intent' = a synthesized drift "
            "session; 'closed-loop' = the bundled clean showcase trace."
        ),
    )
    p_demo.set_defaults(func=run_demo)

    args = parser.parse_args()

    # First-run flow runs AFTER argparse succeeds (so --help / shell
    # completion paths exit before reaching here) and BEFORE the
    # requested subcommand executes. The flow itself short-circuits
    # if state already exists, if SENTIENCE_NO_FIRST_RUN_PROMPT is
    # set, or if any error occurs (defensive — never blocks a real
    # command). See sentience_governor/cli/first_run.py.
    maybe_run_first_run_flow(package_version=_resolve_package_version())

    # F-V2: no subcommand given → print the guide (first-run flow has
    # already fired above, so a brand-new operator sees the welcome
    # AND the guide on a bare `sentience`).
    if getattr(args, "func", None) is None:
        return _print_command_guide()

    return args.func(args)


def _resolve_package_version() -> Optional[str]:
    """Best-effort sentience-governor version, or None if unavailable.

    Used to populate the optional ``package_version`` field on the
    launch-list subscribe payload. If the package metadata isn't
    importable for any reason, return None — the field is optional
    and the server treats absence as no-op.
    """
    try:
        from importlib.metadata import PackageNotFoundError, version

        return version("sentience-governor")
    except (ImportError, Exception):  # PackageNotFoundError + safety
        return None


if __name__ == "__main__":
    sys.exit(main())
