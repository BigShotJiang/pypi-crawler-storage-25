from __future__ import annotations
import json,os,re,shlex,subprocess,sys,tomllib
from importlib import metadata
from pathlib import Path
from urllib import error,request
import click
PACKAGE_NAME='gv-cli'
PYPI_JSON_URL=f"https://pypi.org/pypi/{PACKAGE_NAME}/json"
CHECK_TIMEOUT_SECONDS=2.
SKIP_ENV_VAR='GV_SKIP_CLI_VERSION_CHECK'
LATEST_VERSION_ENV_VAR='GV_CLI_LATEST_VERSION'
DRY_RUN_UPGRADE_ENV_VAR='GV_CLI_DRY_RUN_UPGRADE'
PIPX_UPGRADE_COMMAND='pipx upgrade gv-cli'
UV_UPGRADE_COMMAND='uv tool upgrade gv-cli'
INSTALL_SCRIPT_COMMAND='curl -fsSL https://tabtabtab.ai/install.sh | sh'
UV_TOOL_PACKAGE_NAMES=PACKAGE_NAME,'futurebelike-gv'
_RELEASE_RE=re.compile('^\\s*v?(\\d+(?:\\.\\d+){0,2})')
def installed_cli_version()->str|None:
	try:return metadata.version(PACKAGE_NAME)
	except metadata.PackageNotFoundError:return _local_pyproject_version()
def fetch_latest_cli_version(timeout:float=CHECK_TIMEOUT_SECONDS)->str|None:
	B=os.getenv(LATEST_VERSION_ENV_VAR,'').strip()
	if B:return B
	D=request.Request(PYPI_JSON_URL,headers={'Accept':'application/json','User-Agent':f"gv-cli-version-check/{installed_cli_version()or"unknown"}"})
	try:
		with request.urlopen(D,timeout=timeout)as E:F=json.loads(E.read().decode('utf-8'))
	except(OSError,TimeoutError,error.URLError,json.JSONDecodeError):return
	C=F.get('info')
	if not isinstance(C,dict):return
	A=C.get('version');return A if isinstance(A,str)and A.strip()else None
def is_version_behind(current:str,latest:str)->bool:
	A=_release_parts(current);B=_release_parts(latest)
	if A is None or B is None:return False
	return A<B
def enforce_latest_cli_version()->None:
	if os.getenv(SKIP_ENV_VAR,'').strip():return
	A=installed_cli_version()
	if not A:return
	B=fetch_latest_cli_version()
	if not B or not is_version_behind(A,B):return
	if is_interactive_upgrade():
		if prompt_and_upgrade(A,B):raise click.exceptions.Exit(0)
		return
	raise click.ClickException(_upgrade_required_message(A,B))
def is_interactive_upgrade()->bool:return bool(sys.stdin.isatty()and sys.stdout.isatty())
def prompt_and_upgrade(current:str,latest:str)->bool:
	A=latest;click.echo('New gv version detected. Upgrade to continue.');click.echo(f"Current version: {current}");click.echo(f"Latest version: {A}");click.echo()
	if not click.confirm('Upgrade now?',default=True):click.echo(f"Continuing with the current gv CLI. Upgrade soon with: {INSTALL_SCRIPT_COMMAND}");return False
	if install_latest_cli_version(A):click.echo('Upgrade complete. Re-run your gv command to continue.')
	else:click.echo('Dry run complete. No changes made.')
	return True
def install_latest_cli_version(latest:str)->bool:
	C=latest;F=_upgrade_command();B=shlex.join(F)
	if os.getenv(DRY_RUN_UPGRADE_ENV_VAR,'').strip():click.echo(f"Dry run: would run `{B}`.");return False
	click.echo(f"Installing gv-cli {C}...")
	try:G=subprocess.run(F,check=True,capture_output=True,text=True)
	except subprocess.CalledProcessError as A:
		D=_format_command_output(A.stdout,A.stderr);E='\n'.join([f"Upgrade failed with exit code {A.returncode}.",*_missing_pip_hint_lines(D),_manual_upgrade_hint(),f"Attempted command: {B}"])
		if D:E=f"{E}\n\nupgrade command output:\n{D}"
		raise click.ClickException(E)from A
	except OSError as A:raise click.ClickException(f"Upgrade failed: {A}\n{_manual_upgrade_hint()}\nAttempted command: {B}")from A
	H=_probe_installed_cli_version()
	if not _is_upgrade_satisfied(H,C):I=H or'unknown';raise click.ClickException(f"Upgrade command completed, but gv-cli is still not current.\nInstalled version: {I}\nRequired version: {C}\n{_manual_upgrade_hint()}\nAttempted command: {B}{_command_output_section(G.stdout,G.stderr)}")
	return True
def _command_output_section(stdout:str|bytes|None,stderr:str|bytes|None)->str:
	A=_format_command_output(stdout,stderr)
	if not A:return''
	return f"\n\nupgrade command output:\n{A}"
def _format_command_output(stdout:str|bytes|None,stderr:str|bytes|None,max_lines:int=20)->str:
	B=max_lines;C=[_coerce_output(stdout),_coerce_output(stderr)];A='\n'.join(A for A in C if A).splitlines()
	if len(A)>B:D=len(A)-B;A=[f"... omitted {D} earlier lines ...",*A[-B:]]
	return'\n'.join(A).strip()
def _coerce_output(output:str|bytes|None)->str:
	A=output
	if A is None:return''
	if isinstance(A,bytes):return A.decode('utf-8',errors='replace').strip()
	return A.strip()
def _probe_installed_cli_version()->str|None:
	A=[sys.executable,'-c',f"from importlib import metadata; print(metadata.version({PACKAGE_NAME!r}))"]
	try:B=subprocess.run(A,check=True,capture_output=True,text=True)
	except(subprocess.CalledProcessError,OSError):return
	C=B.stdout.strip();return C or None
def _is_upgrade_satisfied(installed:str|None,latest:str)->bool:
	B=latest;A=installed
	if not A:return False
	if A.strip()==B.strip():return True
	C=_release_parts(A);D=_release_parts(B)
	if C is None or D is None:return False
	return C>=D
def _upgrade_required_message(current:str,latest:str)->str:return'\n'.join(['New gv version detected. Upgrade to continue.',f"Current version: {current}",f"Latest version: {latest}",'',f"Upgrade with: {shlex.join(_upgrade_command())}",_manual_upgrade_hint()])
def _upgrade_command()->list[str]:
	A=_uv_tool_name_for_python(sys.executable)
	if A is not None:return['uv','tool','upgrade',A]
	return[sys.executable,'-m','pip','install','--upgrade','--no-cache-dir',PACKAGE_NAME]
def _uv_tool_name_for_python(executable:str)->str|None:
	A=Path(executable)
	try:A=A.resolve()
	except OSError:pass
	B=A.parent.parent
	if A.parent.name!='bin'or B.name not in UV_TOOL_PACKAGE_NAMES:return
	if B.parent.name!='tools'or B.parent.parent.name!='uv':return
	return B.name
def _manual_upgrade_hint()->str:return f"Upgrade manually with: {INSTALL_SCRIPT_COMMAND}"
def _manual_upgrade_hints()->str:return _manual_upgrade_hint()
def _missing_pip_hint_lines(details:str)->list[str]:
	if'No module named pip'not in details:return[]
	return['This looks like an old gv self-upgrade bug: gv tried to run pip inside a uv tool environment, but uv tools do not always include pip.','Rerun the installer to repair the install.']
def _release_parts(value:str)->tuple[int,int,int]|None:
	B=_RELEASE_RE.match(value)
	if B is None:return
	A=[int(A)for A in B.group(1).split('.')]
	while len(A)<3:A.append(0)
	return tuple(A[:3])
def _local_pyproject_version()->str|None:
	for D in Path(__file__).resolve().parents:
		C=D/'pyproject.toml'
		if not C.is_file():continue
		try:E=tomllib.loads(C.read_text(encoding='utf-8'))
		except(OSError,tomllib.TOMLDecodeError):return
		A=E.get('tool',{}).get('poetry',{})
		if not isinstance(A,dict)or A.get('name')!=PACKAGE_NAME:continue
		B=A.get('version');return B if isinstance(B,str)and B.strip()else None