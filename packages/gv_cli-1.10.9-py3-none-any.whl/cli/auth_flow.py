from __future__ import annotations
import base64,hashlib,json,secrets,socketserver
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler
from threading import Event,Thread
import time
from typing import Any
from urllib import error,parse,request
from urllib.parse import urlparse
from.auth_session import CONFIG_PATH,OAuthSession,load_oauth_session,save_oauth_session
from.browser_launcher import BrowserLaunchResult,open_url
OAUTH_SCOPES='profile email offline_access'
HTTP_USER_AGENT='gv-cli/0.1'
class ApiRequestError(RuntimeError):
	def __init__(A,message:str,status_code:int):super().__init__(message);A.status_code=status_code
@dataclass(frozen=True)
class ClerkAuthConfig:
	publishable_key:str;oauth_client_id:str;oauth_redirect_uri:str
	@classmethod
	def from_payload(B,payload:dict[str,Any])->'ClerkAuthConfig':A=payload;return B(publishable_key=str(A['publishableKey']),oauth_client_id=str(A['oauthClientId']),oauth_redirect_uri=str(A['oauthRedirectUri']))
@dataclass(frozen=True)
class OAuthDiscovery:
	issuer:str;authorization_endpoint:str;token_endpoint:str;revocation_endpoint:str|None
	@classmethod
	def from_payload(B,payload:dict[str,Any])->'OAuthDiscovery':A=payload;return B(issuer=str(A['issuer']),authorization_endpoint=str(A['authorization_endpoint']),token_endpoint=str(A['token_endpoint']),revocation_endpoint=_optional_string(A.get('revocation_endpoint')))
@dataclass
class OAuthCallbackState:event:Event;code:str|None=None;error:str|None=None
def login(api_url:str)->int:A=fetch_clerk_auth_config(api_url);B=fetch_oauth_discovery(A.publishable_key);C=build_pkce_verifier();D=secrets.token_urlsafe(24);E=build_authorization_url(A,B,D,build_pkce_challenge(C));F=wait_for_oauth_callback(D,E,A.oauth_redirect_uri);G=exchange_authorization_code(A,B,F,C);save_oauth_session(G);print(f"Saved login to {CONFIG_PATH}");return 0
def logout()->int:
	if load_oauth_session()is None:print('Already logged out');return 0
	save_oauth_session(None);print(f"Removed saved login from {CONFIG_PATH}");return 0
def fetch_clerk_auth_config(api_url:str)->ClerkAuthConfig:A=_request_json(f"{api_url}/v1/auth/clerk",'GET');return ClerkAuthConfig.from_payload(A)
def _optional_string(value:Any)->str|None:
	A=value
	if A is None:return
	return str(A)
def _parse_error_message(payload:dict[str,Any],status_code:int)->str:
	B=payload;C=B.get('error')
	if isinstance(C,str)and C:
		D=B.get('error_description')
		if isinstance(D,str)and D:return D
		return C
	A=B.get('detail')
	if isinstance(A,str)and A:return A
	if isinstance(A,list):
		E=[]
		for F in A:
			if isinstance(F,dict)and F.get('msg'):E.append(str(F['msg']))
		if E:return'; '.join(E)
	return f"Request failed with {status_code}"
def _extract_error_message(raw:str,status_code:int)->str:
	B=status_code;A=raw
	try:D=json.loads(A)if A else{}
	except json.JSONDecodeError:D={}
	C=_parse_error_message(D,B)
	if C!=f"Request failed with {B}":return C
	if A.strip():return f"Request failed with {B}: {A.strip()}"
	return C
def _request_json(url:str,method:str,payload:dict[str,Any]|None=None)->dict[str,Any]:
	B=payload;C=json.dumps(B).encode('utf-8')if B is not None else None;D=request.Request(url,method=method,data=C,headers={'Content-Type':'application/json','Accept':'application/json','User-Agent':HTTP_USER_AGENT})
	try:
		with request.urlopen(D,timeout=30)as E:return json.loads(E.read().decode('utf-8'))
	except error.HTTPError as A:F=A.read().decode('utf-8');raise ApiRequestError(_extract_error_message(F,A.code),A.code)from A
	except error.URLError as A:raise RuntimeError(str(A.reason))from A
def _request_form_json(url:str,payload:dict[str,str])->dict[str,Any]:
	B=parse.urlencode(payload).encode('utf-8');C=request.Request(url,method='POST',data=B,headers={'Content-Type':'application/x-www-form-urlencoded','Accept':'application/json','User-Agent':HTTP_USER_AGENT})
	try:
		with request.urlopen(C,timeout=30)as D:return json.loads(D.read().decode('utf-8'))
	except error.HTTPError as A:E=A.read().decode('utf-8');raise ApiRequestError(_extract_error_message(E,A.code),A.code)from A
	except error.URLError as A:raise RuntimeError(str(A.reason))from A
def clerk_frontend_api_from_publishable_key(publishable_key:str)->str:
	A=publishable_key.split('_',2)
	if len(A)!=3 or not A[2]:raise RuntimeError('gv login is not configured correctly.')
	B=A[2];D='='*((4-len(B)%4)%4)
	try:E=base64.urlsafe_b64decode(B+D).decode('utf-8')
	except(ValueError,UnicodeDecodeError)as F:raise RuntimeError('gv login is not configured correctly.')from F
	C=E.rstrip('$').strip()
	if not C:raise RuntimeError('gv login is not configured correctly.')
	return C
def fetch_oauth_discovery(publishable_key:str)->OAuthDiscovery:A=clerk_frontend_api_from_publishable_key(publishable_key);B=_request_json(f"https://{A}/.well-known/openid-configuration",'GET');return OAuthDiscovery.from_payload(B)
def parse_loopback_redirect_uri(redirect_uri:str)->tuple[str,int,str]:
	A=urlparse(redirect_uri)
	if A.scheme!='http':raise RuntimeError('gv login callback URL must use http for localhost callbacks.')
	if A.hostname not in{'127.0.0.1','localhost'}:raise RuntimeError('gv login callback URL must use localhost or 127.0.0.1.')
	if A.port is None:raise RuntimeError('gv login callback URL must include an explicit port.')
	B=A.path or'/';return A.hostname,A.port,B
def extract_code_from_callback_url(expected_state:str,callback_url:str,expected_path:str)->str:
	B=urlparse(callback_url.strip())
	if B.path!=expected_path:raise RuntimeError('The pasted callback URL has the wrong path.')
	A=parse.parse_qs(B.query);E=A.get('state',[''])[0];C=A.get('code',[''])[0];D=A.get('error_description',A.get('error',['']))[0]
	if E!=expected_state:raise RuntimeError('The pasted callback URL has the wrong OAuth state.')
	if D:raise RuntimeError(D)
	if not C:raise RuntimeError('The pasted callback URL did not include an authorization code.')
	return C
def build_pkce_verifier()->str:return secrets.token_urlsafe(64)
def build_pkce_challenge(verifier:str)->str:A=hashlib.sha256(verifier.encode('utf-8')).digest();return base64.urlsafe_b64encode(A).decode('utf-8').rstrip('=')
def build_authorization_url(auth_config:ClerkAuthConfig,discovery:OAuthDiscovery,state:str,code_challenge:str)->str:A=auth_config;B=parse.urlencode({'response_type':'code','client_id':A.oauth_client_id,'redirect_uri':A.oauth_redirect_uri,'scope':OAUTH_SCOPES,'state':state,'code_challenge':code_challenge,'code_challenge_method':'S256'});return f"{discovery.authorization_endpoint}?{B}"
def print_login_instructions(authorization_url:str,redirect_uri:str,launch_result:BrowserLaunchResult)->None:
	B=launch_result;A=authorization_url
	if B.opened:print('Opened the login URL in your browser.')
	elif B.attempted:print('Could not open a browser automatically.');print('Open this URL in any browser:');print(A)
	else:print('No local browser launcher was detected.');print('Open this URL in a browser on your host machine:');print(A)
	print('');print(f"Callback URL: {redirect_uri}");print('');print('Waiting for the browser callback or a pasted redirect URL...');print("If the browser cannot reach this shell's loopback callback,");print('copy the full redirected URL from the browser address bar,');print('paste it below, and press Enter:')
def exchange_authorization_code(auth_config:ClerkAuthConfig,discovery:OAuthDiscovery,code:str,code_verifier:str)->OAuthSession:B=discovery;A=auth_config;C=_request_form_json(B.token_endpoint,{'grant_type':'authorization_code','client_id':A.oauth_client_id,'code':code,'redirect_uri':A.oauth_redirect_uri,'code_verifier':code_verifier});return oauth_session_from_token_payload(C,token_endpoint=B.token_endpoint,client_id=A.oauth_client_id)
def oauth_session_from_token_payload(payload:dict[str,Any],*,token_endpoint:str|None=None,client_id:str|None=None)->OAuthSession:
	A=payload;B=A.get('access_token')
	if not isinstance(B,str)or not B:raise RuntimeError('OAuth token response did not include an access token.')
	C=A.get('expires_in');D=None
	if isinstance(C,(int,float)):D=time.time()+float(C)
	E=A.get('refresh_token');return OAuthSession(access_token=B,expires_at=D,refresh_token=E if isinstance(E,str)else None,token_endpoint=token_endpoint,client_id=client_id)
def wait_for_oauth_callback(expected_state:str,authorization_url:str,redirect_uri:str)->str:
	C=authorization_url;D=expected_state;B=redirect_uri;A=OAuthCallbackState(event=Event());H,I,E=parse_loopback_redirect_uri(B)
	class J(BaseHTTPRequestHandler):
		def do_GET(B)->None:
			F=urlparse(B.path)
			if F.path!=E:B.send_response(404);B.end_headers();return
			C=parse.parse_qs(F.query);I=C.get('state',[''])[0];G=C.get('code',[''])[0];H=C.get('error_description',C.get('error',['']))[0]
			if I!=D:A.error='Received an invalid OAuth state.'
			elif H:A.error=H
			elif not G:A.error='OAuth callback did not include an authorization code.'
			else:A.code=G
			if A.error:B._write_html(400,'Authentication failed. You can close this window.')
			else:B._write_html(200,'Login complete. You can close this window.')
			A.event.set()
		def log_message(A,_format:str,*B:object)->None:0
		def _write_html(A,status_code:int,message:str)->None:B=f"<html><body><p>{message}</p></body></html>".encode('utf-8');A.send_response(status_code);A.send_header('Content-Type','text/html; charset=utf-8');A.send_header('Content-Length',str(len(B)));A.end_headers();A.wfile.write(B)
	class K(socketserver.TCPServer):allow_reuse_address=True
	try:F=K((H,I),J)
	except OSError as G:raise RuntimeError(f"Could not listen on {B}: {G}")from G
	def L()->None:
		while not A.event.is_set():
			try:B=input().strip()
			except EOFError:return
			if not B:continue
			try:A.code=extract_code_from_callback_url(D,B,E)
			except RuntimeError as C:A.error=str(C)
			A.event.set();return
	try:Thread(target=F.handle_request,daemon=True).start();print('\ngv login\n');print_login_instructions(C,B,open_url(C));Thread(target=L,daemon=True).start();A.event.wait()
	finally:F.server_close()
	if A.error:raise RuntimeError(A.error)
	if not A.code:raise RuntimeError('OAuth callback did not include an authorization code.')
	return A.code