from __future__ import annotations
import getpass,logging,os
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from.auth_session import load_cli_config,save_cli_config
try:from posthog import Posthog
except ImportError:Posthog=None
DEFAULT_POSTHOG_API_KEY='phc_VohKNM75PDJQRUGrE5gFx3gGvSKpuhTXP4WNIqxDuy8'
DEFAULT_POSTHOG_HOST='https://eu.i.posthog.com'
TELEMETRY_OPT_IN_CONFIG_KEY='telemetry_opt_in'
@dataclass(frozen=True)
class _PostHogConfig:api_key:str|None;host:str
def capture_repo_add_unsupported(*,directory:Path,reason:str,local_only:bool)->None:A=directory;capture_event('gv_repo_add_unsupported',{'reason':reason,'local_only':local_only,'directory':str(A),'repo_name':A.name})
def capture_cli_command(command_path:str,*,success:bool)->None:A=command_path.split();C=' '.join(['gv',*A[1:]])if A else'gv';B='gv_cli_'+'_'.join(A[1:]);B=B.replace('-','_');capture_event(B,{'command':C,'success':success})
def capture_event(event:str,properties:dict[str,Any])->None:
	if Posthog is None or not telemetry_opted_in():return
	A=_load_posthog_config()
	if not A.api_key:return
	try:
		with _silenced_posthog_logger():
			B=Posthog(project_api_key=A.api_key,host=A.host,max_retries=0,timeout=1)
			try:B.capture(distinct_id=_distinct_id(),event=event,properties={'source':'gv_cli',**properties})
			finally:_shutdown_posthog_client(B)
	except Exception as C:logging.getLogger(__name__).debug('analytics capture failed: %s',C)
def telemetry_opted_in()->bool:return telemetry_consent()is True
def telemetry_consent()->bool|None:
	try:A=load_cli_config().get(TELEMETRY_OPT_IN_CONFIG_KEY)
	except RuntimeError as B:logging.getLogger(__name__).debug('analytics config read failed: %s',B);return
	return A if isinstance(A,bool)else None
def save_telemetry_opt_in(opted_in:bool)->None:A=load_cli_config();A[TELEMETRY_OPT_IN_CONFIG_KEY]=opted_in;save_cli_config(A)
@contextmanager
def _silenced_posthog_logger()->Iterator[None]:
	A=logging.getLogger('posthog');B=A.disabled;A.disabled=True
	try:yield
	finally:A.disabled=B
def _shutdown_posthog_client(client:Any)->None:
	try:client.shutdown()
	except Exception as A:logging.getLogger(__name__).debug('analytics shutdown failed: %s',A)
def _load_posthog_config()->_PostHogConfig:A=os.getenv('GV_POSTHOG_API_KEY','').strip()or os.getenv('POSTHOG_API_KEY','').strip()or DEFAULT_POSTHOG_API_KEY;B=os.getenv('GV_POSTHOG_HOST','').strip()or os.getenv('POSTHOG_HOST','').strip()or DEFAULT_POSTHOG_HOST;return _PostHogConfig(api_key=A,host=B)
def _distinct_id()->str:
	try:A=getpass.getuser().strip()
	except Exception:A=''
	if A:return f"gv-cli:{A}"
	return'gv-cli:unknown'