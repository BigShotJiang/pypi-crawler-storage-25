from __future__ import annotations
import io,base64,json,os,re,shlex,subprocess,sys,time
from dataclasses import dataclass,replace
from pathlib import Path
from typing import Any,Callable,TypeVar
from urllib import error,parse,request
import click,qrcode
from.import analytics,auth_flow,claude_launcher,codex_launcher,cursor_launcher,gv_config_access,github_app_auth_flow,github_access,interactive,openai_access,opencode_launcher,petname,remote_workspaces,runtime,upload as upload_handler,vscode_launcher
from.api_url import normalize_api_url,resolve_api_url
from.auth_session import CONFIG_PATH,get_api_auth_header,load_cli_config,redact_cli_config,save_cli_config
from.profile import handle_profile_apply,handle_profile_job,handle_profile_pull,handle_profile_push,handle_profile_show
from.import ssh_access
from.version_check import enforce_latest_cli_version,installed_cli_version
from.repo_add import handle_repo_add
from.repo_env import handle_env_add,handle_env_list,handle_env_rm,handle_repo_onboard,handle_repo_list
ENV_NAME_RE=re.compile('^[a-z0-9](?:[a-z0-9-]{1,28}[a-z0-9])?$')
EMAIL_RE=re.compile('^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$')
VM_USERNAME_RE=re.compile('^[a-z][a-z0-9_-]{0,31}$')
RESERVED_ENV_NAMES={'create','use','list','destroy'}
RESERVED_VM_USERNAMES={'root'}
HTTP_USER_AGENT='gv-cli/0.1'
CURRENT_ENV_CONFIG_KEY='current_env_by_api_url'
ENV_BASE_DOMAIN='futurebelike.com'
T=TypeVar('T')
ENV_PHASE_LABELS={'ready':'Ready','failed':'Failed','queued':'Queued','waiting_for_instance_running':'Starting cloud machine','waiting_for_public_ip':'Connecting networking','creating_cloudflare_dns_record':'Preparing URL','waiting_for_cloud_init':'Bootstrapping workspace runtime','waiting_for_traefik_http':'Starting public web access','waiting_for_tls_certificate':'Securing URL','waiting_for_opencode_upstream':'Starting workspace'}
@dataclass(frozen=True)
class CreateEnvInput:
	name:str;git_user_name:str;git_user_email:str;vm_username:str|None=None;telemetry_opt_in:bool=False;use_openrouter_credits:bool=True
	def to_payload(A)->dict[str,str|bool]:
		B={'name':A.name,'gitUserName':A.git_user_name,'gitUserEmail':A.git_user_email,'telemetryOptIn':A.telemetry_opt_in,'useOpenRouterCredits':A.use_openrouter_credits}
		if A.vm_username:B['vmUsername']=A.vm_username
		return B
@dataclass(frozen=True)
class EnvRecord:
	id:str;name:str;domain:str;status:str;step:str;instance_id:str|None;public_ip:str|None;cf_record_id:str|None;vm_username:str;opencode_username:str;opencode_password:str|None;git_user_name:str;git_user_email:str;error_message:str|None;created_at:str;updated_at:str;ssh_key_fingerprint:str|None=None;url:str|None=None
	@classmethod
	def from_payload(B,payload:dict[str,Any])->'EnvRecord':A=payload;return B(id=str(A['id']),name=str(A['name']),domain=str(A['domain']),status=str(A['status']),step=str(A['step']),instance_id=_optional_string(A.get('instanceId')),public_ip=_optional_string(A.get('publicIp')),cf_record_id=_optional_string(A.get('cfRecordId')),vm_username=str(A.get('vmUsername')or A['opencodeUsername']),opencode_username=str(A['opencodeUsername']),opencode_password=_optional_string(A.get('opencodePassword')),git_user_name=str(A['gitUserName']),git_user_email=str(A['gitUserEmail']),ssh_key_fingerprint=_optional_string(A.get('sshKeyFingerprint')),error_message=_optional_string(A.get('errorMessage')),created_at=str(A['createdAt']),updated_at=str(A['updatedAt']),url=_optional_string(A.get('url')))
@dataclass(frozen=True)
class MagicLogin:
	url:str;path:str|None=None;expires_in:int|None=None
	@classmethod
	def from_payload(E,payload:dict[str,Any])->'MagicLogin':
		A=payload;B=A.get('url')
		if not isinstance(B,str)or not B:raise RuntimeError('GV Code returned an invalid magic login response')
		C=A.get('path');D=A.get('expiresIn');return E(url=B,path=C if isinstance(C,str)else None,expires_in=D if isinstance(D,int)else None)
class ApiRequestError(RuntimeError):
	def __init__(A,message:str,status_code:int):super().__init__(message);A.status_code=status_code
@dataclass(frozen=True)
class SshTargetChoice:label:str;directory:str|None;project_directory:str|None=None
def _optional_string(value:Any)->str|None:
	A=value
	if A is None:return
	return str(A)
def _display_env_phase(env:EnvRecord)->str:
	A=env
	if A.status=='ready':return ENV_PHASE_LABELS['ready']
	if A.status=='failed':return ENV_PHASE_LABELS['failed']
	return ENV_PHASE_LABELS.get(A.step,'Setting up')
def _opencode_basic_auth_url(env:EnvRecord)->str:
	B=env
	if not B.url:raise RuntimeError('Environment does not have a web URL yet.')
	A=parse.urlsplit(B.url);C=parse.quote(B.opencode_username,safe='');D=parse.quote(_require_opencode_password(B),safe='');E=f"{C}:{D}@{A.netloc}";return parse.urlunsplit((A.scheme,E,A.path,A.query,A.fragment))
def _opencode_basic_auth_header(env:EnvRecord)->str:A=f"{env.opencode_username}:{_require_opencode_password(env)}";B=base64.b64encode(A.encode('utf-8')).decode('ascii');return f"Basic {B}"
def _redact_url_credentials(url:str)->str:
	A=parse.urlsplit(url)
	if'@'not in A.netloc:return url
	B,B,C=A.netloc.rpartition('@');return parse.urlunsplit((A.scheme,C,A.path,A.query,A.fragment))
def print_env_qr(env:EnvRecord)->None:
	A=env
	if not A.url:raise RuntimeError('Environment does not have a web URL yet.')
	D=_require_opencode_password(A);B=qrcode.QRCode(border=1,error_correction=qrcode.constants.ERROR_CORRECT_L);B.add_data(A.url);B.make(fit=True);C=io.StringIO();B.print_ascii(out=C,tty=False,invert=True);click.echo('\nOpen on mobile\n');click.echo(C.getvalue().rstrip());click.echo(f"\nScans to: {A.url}");click.echo('Sign in to the GV Code web app with:');click.echo(f"  GV Code username: {A.opencode_username}");click.echo(f"  GV Code password: {D}")
def print_magic_login_qr(login_url:str)->None:A=qrcode.QRCode(border=1,error_correction=qrcode.constants.ERROR_CORRECT_L);A.add_data(login_url);A.make(fit=True);B=io.StringIO();A.print_ascii(out=B,tty=False,invert=True);click.echo('\nOpen on mobile\n');click.echo(B.getvalue().rstrip())
def print_magic_login_details(magic_login:MagicLogin)->None:
	A=magic_login;click.echo('\nOne-time GV Code login (expire after use)\n');click.echo(f"  login: {A.url}")
	if A.expires_in is not None:B=max(1,(A.expires_in+59)//60);click.echo(f"  expires: {B} minute{"s"if B!=1 else""}")
	print_magic_login_qr(A.url)
def _require_opencode_password(env:EnvRecord)->str:
	if env.opencode_password is None:raise RuntimeError('GV Code password was not returned for this environment.')
	return env.opencode_password
def normalize_env_name(value:str)->str:return value.strip().lower()
def validate_create_env_input(name:str,git_user_name:str,git_user_email:str,vm_username:str|None=None,telemetry_opt_in:bool=False)->CreateEnvInput:
	B=normalize_env_name(name);C=git_user_name.strip();D=git_user_email.strip();A=(vm_username or'').strip().lower()or None
	if not ENV_NAME_RE.match(B):raise ValueError('Environment name must be 3-30 chars of lowercase letters, numbers, or hyphens, and cannot start or end with a hyphen.')
	if B in RESERVED_ENV_NAMES:raise ValueError('Environment name is reserved and cannot be used.')
	if len(C)<2:raise ValueError('Git author name must be at least 2 characters.')
	if not EMAIL_RE.match(D):raise ValueError('Git author email must look like an email address.')
	if A:
		if A in RESERVED_VM_USERNAMES:raise ValueError('Environment username is reserved and cannot be used.')
		if not VM_USERNAME_RE.match(A):raise ValueError('Environment username must start with a lowercase letter and use only lowercase letters, numbers, underscores, or hyphens.')
	return CreateEnvInput(name=B,git_user_name=C,git_user_email=D,vm_username=A,telemetry_opt_in=telemetry_opt_in)
def prompt_for_telemetry_consent()->bool:
	click.echo();click.echo('Help us improve gv by allowing collection of usage statistics. We do not collect sensitive data like prompts, responses, code, file contents, terminal output, tool arguments, or tool output.');click.echo();click.echo("1. Yes, I'm happy to help");click.echo('2. No, I would like to opt out');click.echo('3. Show details of the data collected');click.echo();A=click.prompt('Choose an option',type=click.Choice(['1','2','3']),default='1')
	if A=='1':return True
	if A=='2':return False
	while True:click.echo();click.echo('Telemetry details');click.echo('- GV Code turn start and end events');click.echo('- CLI command events named gv_cli_<command>');click.echo('- Session and turn identifiers');click.echo('- Environment id and name');click.echo('- Model name');click.echo('- Turn duration, token counts, and cost when GV Code reports them');click.echo('- Aggregate assistant message and tool-call counts');click.echo('- Working directory path and basename');click.echo();click.echo('We do not collect prompts, responses, code, file contents, terminal output, tool arguments, or tool output.');click.echo();return click.confirm('Allow collecting statistics',default=True)
def read_git_config(key:str)->str:
	try:A=subprocess.run(['git','config','--global','--get',key],check=True,capture_output=True,text=True)
	except(FileNotFoundError,subprocess.CalledProcessError):return''
	return A.stdout.strip()
def default_init_values(name_arg:str|None)->tuple[str,str,str]:return normalize_env_name(name_arg or os.getenv('USER','')),read_git_config('user.name'),read_git_config('user.email')
def read_local_whoami()->str:
	try:A=subprocess.run(['whoami'],check=True,capture_output=True,text=True)
	except(FileNotFoundError,subprocess.CalledProcessError):return os.getenv('USER','').strip()
	return A.stdout.strip()or os.getenv('USER','').strip()
def is_interactive_input()->bool:return interactive.is_interactive_input()
def prompt_for_env_name(current_name:str)->str:A=current_name;B=A or'<name>';return click.prompt(f"Please enter your Environment Name.\nThis name will be used for your coding agent's url e.g. {B}.{ENV_BASE_DOMAIN}",default=A,show_default=bool(A))
def resolve_interactive_value(value:T|None,*,missing_error:str,prompt_value:Callable[[],T],validate:Callable[[T],T])->T:return interactive.resolve_interactive_value(value,missing_error=missing_error,prompt_value=prompt_value,validate=validate,is_interactive_input=is_interactive_input)
def check_name_availability(api_url:str,name:str)->bool:
	B=request_api_json(api_url,'GET',f"/v1/envs/check-name/{normalize_env_name(name)}");A=B.get('available')
	if not isinstance(A,bool):raise RuntimeError('gv returned an invalid availability response')
	return A
def suggest_env_name(api_url:str)->str:
	for A in petname.generate_candidates():
		if check_name_availability(api_url,A):return A
	raise click.ClickException('Could not find an available suggested environment name.')
def missing_init_options(name:str|None,git_user_name:str|None,git_user_email:str|None)->list[str]:
	A=[]
	if not(name or'').strip():A.append('--name')
	if not(git_user_name or'').strip():A.append('--git-user-name')
	if not(git_user_email or'').strip():A.append('--git-user-email')
	return A
def collect_init_input(api_url:str|None,name_arg:str|None,git_user_name_arg:str|None,git_user_email_arg:str|None,telemetry_opt_in_arg:bool|None=None)->CreateEnvInput:
	J=git_user_email_arg;I=git_user_name_arg;G=telemetry_opt_in_arg;C=api_url;B=name_arg;N,O,P=default_init_values(B);Q=read_local_whoami();R=B if B is not None else N;K=I if I is not None else O;L=J if J is not None else P
	if not is_interactive_input():
		S=missing_init_options(R,K,L)
		if S:raise click.ClickException('Missing required options for non-interactive use: '+', '.join(S))
		try:return validate_create_env_input(R,K,L,Q,G is True)
		except ValueError as H:raise click.ClickException(str(H))from H
	if not O or not P:click.echo('Git author defaults were not found. `gv env create` uses these to configure the default Git author name and email inside the new environment.\nSet them with `git config --global user.name "Your Name"` and `git config --global user.email "you@example.com"`, or enter them below.\n')
	M=B is None;T=I is None;U=J is None;D=B if B is not None else suggest_env_name(C)if C else N;E=K;F=L
	while True:
		V=prompt_for_env_name(D)if M else D;W=click.prompt('Git author name',default=E,show_default=bool(E))if T else E;X=click.prompt('Git author email',default=F,show_default=bool(F))if U else F
		try:A=validate_create_env_input(V,W,X,Q,G is True)
		except ValueError as H:click.echo(f"\n{H}\n",err=True);D=V;E=W;F=X;M=True;T=True;U=True;continue
		if C and not check_name_availability(C,A.name):click.echo(f"\nEnvironment name {A.name} already exists.\n",err=True);D=suggest_env_name(C);E=A.git_user_name;F=A.git_user_email;click.echo(f"Suggested available name: {D}");M=True;continue
		Y=analytics.telemetry_consent()
		if G is None and Y is None:Z=prompt_for_telemetry_consent();return CreateEnvInput(name=A.name,git_user_name=A.git_user_name,git_user_email=A.git_user_email,vm_username=A.vm_username,telemetry_opt_in=Z)
		if G is None:return CreateEnvInput(name=A.name,git_user_name=A.git_user_name,git_user_email=A.git_user_email,vm_username=A.vm_username,telemetry_opt_in=Y is True)
		return A
def _parse_error_message(payload:dict[str,Any],status_code:int)->str:
	B=payload;C=B.get('error')
	if isinstance(C,str)and C:
		D=B.get('error_description')
		if isinstance(D,str)and D:return D
		return C
	A=B.get('detail')
	if isinstance(A,str)and A:return A
	if isinstance(A,list):
		E=[]
		for F in A:
			if isinstance(F,dict)and F.get('msg'):E.append(str(F['msg']))
		if E:return'; '.join(E)
	return f"Request failed with {status_code}"
def _extract_error_message(raw:str,status_code:int)->str:
	B=status_code;A=raw
	try:D=json.loads(A)if A else{}
	except json.JSONDecodeError:D={}
	C=_parse_error_message(D,B)
	if C!=f"Request failed with {B}":return C
	if A.strip():return f"Request failed with {B}: {A.strip()}"
	return C
def _request_json(method:str,url:str,payload:dict[str,Any]|None=None,*,headers:dict[str,str]|None=None)->dict[str,Any]:
	C=headers;B=payload;E=json.dumps(B).encode('utf-8')if B is not None else None;D={'Content-Type':'application/json','Accept':'application/json','User-Agent':HTTP_USER_AGENT}
	if C:D.update(C)
	F=request.Request(url,method=method,data=E,headers=D)
	try:
		with request.urlopen(F,timeout=30)as G:return json.loads(G.read().decode('utf-8'))
	except error.HTTPError as A:H=A.read().decode('utf-8');raise ApiRequestError(_extract_error_message(H,A.code),A.code)from A
	except error.URLError as A:raise RuntimeError(str(A.reason))from A
def create_opencode_magic_login(env:EnvRecord,*,redirect:str='/')->MagicLogin:
	A=env
	if not A.url:raise RuntimeError('Environment does not have a web URL yet.')
	B=MagicLogin.from_payload(_request_json('POST',f"{A.url.rstrip("/")}/auth/magic",{'redirect':redirect},headers={'Authorization':_opencode_basic_auth_header(A)}))
	if B.path:return replace(B,url=parse.urljoin(f"{A.url.rstrip("/")}/",B.path.lstrip('/')))
	return B
def create_env(api_url:str,input_data:CreateEnvInput)->EnvRecord:
	B=request_api_json(api_url,'POST','/v1/envs',input_data.to_payload());A=B.get('env')
	if not isinstance(A,dict):raise RuntimeError('gv returned an invalid environment response')
	return EnvRecord.from_payload(A)
def fetch_env(api_url:str,env_id:str,*,reveal:bool=False)->EnvRecord:
	A=f"/v1/envs/{env_id}"
	if reveal:A=f"{A}?reveal=true"
	C=request_api_json(api_url,'GET',A);B=C.get('env')
	if not isinstance(B,dict):raise RuntimeError('gv returned an invalid environment response')
	return EnvRecord.from_payload(B)
def list_envs(api_url:str)->list[EnvRecord]:
	B=request_api_json(api_url,'GET','/v1/envs');A=B.get('envs')
	if not isinstance(A,list):raise RuntimeError('gv returned an invalid environment list response')
	return[EnvRecord.from_payload(A)for A in A if isinstance(A,dict)]
def find_env_by_name(envs:list[EnvRecord],name:str)->EnvRecord:
	A=normalize_env_name(name)
	for B in envs:
		if B.name==A:return B
	raise RuntimeError(f"Environment {A} not found.")
def _current_env_locks(config:dict[str,Any])->dict[str,Any]:
	A=config.get(CURRENT_ENV_CONFIG_KEY)
	if isinstance(A,dict):return A
	return{}
def read_current_env_lock(api_url:str)->dict[str,str]|None:
	A=_current_env_locks(load_cli_config()).get(api_url)
	if not isinstance(A,dict):return
	B=A.get('id');C=A.get('name')
	if not isinstance(B,str)or not B.strip():return
	if not isinstance(C,str)or not C.strip():return
	return{'id':B,'name':C}
def save_current_env_lock(api_url:str,env:EnvRecord)->None:A=load_cli_config();B=dict(_current_env_locks(A));B[api_url]={'id':env.id,'name':env.name};A[CURRENT_ENV_CONFIG_KEY]=B;save_cli_config(A)
def clear_current_env_lock(api_url:str)->None:
	A=load_cli_config();B=dict(_current_env_locks(A));B.pop(api_url,None)
	if B:A[CURRENT_ENV_CONFIG_KEY]=B
	else:A.pop(CURRENT_ENV_CONFIG_KEY,None)
	save_cli_config(A)
def _is_not_found_error(exc:RuntimeError)->bool:A=getattr(exc,'status_code',None);return A==404 or'not found'in str(exc).lower()
def _format_env_switch_list(envs:list[EnvRecord])->str:A=['Available environments:'];A.extend(f"- {A.name}: {_display_env_phase(A)} {A.url}"for A in envs);return'\n'.join(A)
def resolve_current_env(api_url:str,*,reveal:bool=False)->EnvRecord:
	E=reveal;A=api_url;C=read_current_env_lock(A)
	if C is not None:
		try:D=fetch_env(A,C['id'],reveal=True)if E else fetch_env(A,C['id'])
		except RuntimeError as F:
			if _is_not_found_error(F):clear_current_env_lock(A);raise RuntimeError('No current env selected. Run gv env use <name>.')from F
			raise
		if D.name!=C['name']:save_current_env_lock(A,D)
		return D
	B=list_envs(A)
	if len(B)==1:
		save_current_env_lock(A,B[0])
		if E and B[0].opencode_password is None:return fetch_env(A,B[0].id,reveal=True)
		return B[0]
	if not B:raise RuntimeError('No current env selected. Run gv env use <name>.')
	raise RuntimeError(f"{_format_env_switch_list(B)}\nRun gv env use <name> to choose one.")
def resolve_target_env(api_url:str,env_name:str|None=None,*,reveal:bool=False)->EnvRecord:
	D=reveal;C=env_name;A=api_url
	if C is None:return resolve_current_env(A,reveal=D)
	B=find_env_by_name(list_envs(A),C)
	if D and B.opencode_password is None:return fetch_env(A,B.id,reveal=True)
	return B
def resolve_target_env_interactively(api_url:str,env_name:str|None=None,*,reveal:bool=False)->EnvRecord:
	E=env_name;B=reveal;A=api_url
	if E is not None:return resolve_target_env(A,E,reveal=B)
	try:return resolve_current_env(A,reveal=B)
	except RuntimeError:
		if not is_interactive_input():raise
		C=list_envs(A)
		if not C:raise
		click.echo(_format_env_switch_list(C));D=select_env_interactively(C)
		if B and D.opencode_password is None:return fetch_env(A,D.id,reveal=True)
		return D
def handle_env_use(name:str)->int:
	try:A=resolve_api_url();B=find_env_by_name(list_envs(A),name);save_current_env_lock(A,B)
	except RuntimeError as C:raise click.ClickException(str(C))from C
	click.echo(f"Current env: {B.name}");return 0
def _resolve_repo_add_env(directory:str,env_name:str|None=None)->tuple[str|None,str|None,str|None,str|None,str|None,str|None]:
	B=resolve_api_url();A=resolve_target_env(B,env_name,reveal=True)
	if A.status!='ready'or not A.public_ip:raise click.ClickException(f"Environment {A.name} is not ready yet: {_display_env_phase(A)}.")
	return A.id,A.name,A.url,A.vm_username,A.opencode_username,A.opencode_password
def request_api_json(api_url:str,method:str,path:str,payload:dict[str,Any]|None=None,*,authenticated:bool=True)->dict[str,Any]:
	B=authenticated;C:dict[str,str]={}
	if B:C['Authorization']=get_api_auth_header()
	try:return _request_json(method,f"{api_url}{path}",payload,headers=C)
	except ApiRequestError as A:
		if B and A.status_code==401:raise RuntimeError('Unauthorized. Run `gv auth login` and try again.')from A
		raise A
def handle_login()->int:return auth_flow.login(resolve_api_url())
def handle_logout()->int:
	C=auth_flow.logout();A,B=ssh_access.clear_managed_ssh_state()
	if A or B:click.echo(f"Removed gv-managed SSH state ({A} key{"s"if A!=1 else""}, {B} config block{"s"if B!=1 else""}).")
	return C
def print_env_info(env:EnvRecord,*,title:str,sensitive:bool,github_status:str|None=None)->None:
	C=github_status;B=sensitive;A=env;click.echo(f"\n{title}\n");click.echo(f"Name: {A.name}");click.echo(f"Status: {_display_env_phase(A)}");click.echo(f"GV Code URL: {A.url}")
	if B:click.echo(f"password: {_require_opencode_password(A)}")
	else:click.echo('password: *** (reveal this with --reveal flag)')
	if A.public_ip:
		click.echo('SSH Command: gv ssh');click.echo(f"SSH username: {A.vm_username}")
		if B:click.echo(f"Direct SSH host: {A.public_ip}")
	if B and A.ssh_key_fingerprint:click.echo(f"SSH key fingerprint: {A.ssh_key_fingerprint}")
	if C is not None:
		if C=='disabled':click.echo('GitHub: disabled (enable with `gv github enable`)')
		else:click.echo(f"GitHub: {C}")
	if A.error_message:click.echo(f"Error: {A.error_message}")
def select_env_interactively(envs:list[EnvRecord])->EnvRecord:
	B=[A.name for A in envs];C=click.prompt('Environment name',type=click.Choice(B,case_sensitive=False));D=normalize_env_name(C)
	for A in envs:
		if A.name==D:return A
	raise RuntimeError('Selected environment was not found')
def print_env_list(envs:list[EnvRecord])->None:
	click.echo('\nEnvironments\n')
	for A in envs:click.echo(f"- {A.name}: {_display_env_phase(A)} {A.url}")
	click.echo(f"\nUse `gv env use <name>` to choose one, for example `gv env use {envs[0].name}`.")
def print_ready_env(env:EnvRecord)->None:print_env_info(env,title='Environment ready',sensitive=True)
def _format_env_create_phase(env:EnvRecord,*,elapsed_seconds:int|None=None)->str:
	B=elapsed_seconds;A=env;D=_display_env_phase(A)
	if B is None:C=D
	else:C=f"still {D} after {B}s"
	if B is None and A.status not in{'ready','failed'}and A.step=='waiting_for_traefik_http':return f"{C} (this can take between 2-5 minutes)"
	return C
def print_env_create_success(env:EnvRecord,magic_login:MagicLogin|None=None)->None:
	B=magic_login;A=env
	if not A.url:raise RuntimeError('Environment does not have a web URL yet.')
	click.echo('\nEnv creation is complete.\n')
	if B is not None:click.echo('Next step:');click.echo(f"  log in with this url: {B.url}");click.echo('  expires: 5 minutes or after first use');click.echo('\nSee environment details with `gv info`');click.echo('For mobile, generate a one-time login link and QR code with `gv info --qr`');return
	click.echo('Next step, open your coding agent:');click.echo(f"  url: {A.url}");click.echo(f"  password: {_require_opencode_password(A)}");click.echo('\nMagic login was unavailable, so use the password above.');click.echo('See environment details with `gv info`')
def _env_flag(func):return click.option('--env','env_name',default=None,help='Override the current env for this command.')(func)
def handle_init(name_arg:str|None,git_user_name_arg:str|None,git_user_email_arg:str|None,telemetry_opt_in_arg:bool|None=None,enable_openai_arg:bool|None=None,enable_github_arg:bool|None=None,mirror_cli_arg:bool|None=None)->int:
	M=mirror_cli_arg;L=enable_github_arg;K=enable_openai_arg;J=name_arg;U=30;C:str|None=None
	if is_interactive_input():
		try:C=resolve_api_url()
		except RuntimeError as B:raise click.ClickException(str(B))from B
	while True:
		E=collect_init_input(C,J,git_user_name_arg,git_user_email_arg,telemetry_opt_in_arg)
		try:analytics.save_telemetry_opt_in(E.telemetry_opt_in)
		except RuntimeError as B:raise click.ClickException(str(B))from B
		if C is None:
			try:C=resolve_api_url()
			except RuntimeError as B:raise click.ClickException(str(B))from B
		try:
			N=K is True
			if K is None and is_interactive_input()and openai_access.local_codex_auth_exists():N=click.confirm(f"Local Codex OpenAI auth detected at {openai_access.LOCAL_CODEX_PATH}. Enable it on the new env once it's ready?",default=True)
			click.secho('$50 in API credits are enabled for AI. Email hello@tabtabtab.ai if you need more.',dim=True);E=replace(E,use_openrouter_credits=True);H=create_env(C,E);I=L is True;O=False
			if L is None and is_interactive_input():I=click.confirm("Connect GitHub to the new env once it's ready? This will open GitHub in your browser.",default=True);O=I
			P=M is True
			if M is None and is_interactive_input():P=click.confirm("Mirror your local shell, editor, Git settings, and common CLI tools into this cloud env when it's ready?",default=True)
			click.echo(f"\nCreating environment {H.name}...");Q='';F=time.monotonic();R=F
			while True:
				A=fetch_env(C,H.id);S=f"{A.status}:{A.step}";D=time.monotonic()
				if S!=Q:click.echo(f"- {_format_env_create_phase(A)}");Q=S;R=D;F=D
				elif D-F>=U:V=int(D-R);click.echo(f"- {_format_env_create_phase(A,elapsed_seconds=V)}");F=D
				if A.status=='ready':
					A=fetch_env(C,H.id,reveal=True)
					try:_apply_gv_config_install(C,A)
					except Exception as B:click.echo(f"GV config was not installed on {A.name}: {B}",err=True);click.echo('VM-side gv commands may not stay authenticated to the GV control plane.',err=True)
					if N:_apply_openai_enable(C,A)
					if I:_apply_github_enable(C,A,confirm_launch=O)
					save_current_env_lock(C,A);click.echo(f"Switched current env to {A.name}")
					if P:_apply_profile_to_ready_env(A)
					T=None
					try:T=create_opencode_magic_login(A)
					except(RuntimeError,ValueError)as B:click.echo(f"Magic login was unavailable: {B}",err=True)
					print_env_create_success(A,T);return 0
				if A.status=='failed':raise RuntimeError(A.error_message or'Provisioning failed.')
				time.sleep(5)
		except RuntimeError as B:
			G=str(B)
			if'already exists'not in G:raise click.ClickException(G)from B
			if not is_interactive_input():raise click.ClickException(G)from B
			click.echo(f"\n{G}\n",err=True);J=None
def handle_info(reveal:bool,qr:bool=False,env_name:str|None=None,yes:bool=False)->int:
	B=reveal;E:str|None=None
	try:
		if(B or qr)and not yes:
			if not is_interactive_input():raise click.ClickException('`gv env info --reveal/--qr` requires a terminal confirmation prompt.')
			H='This will create a one-time login QR code. If magic login is unavailable, it will show the GV Code password. Would you like to proceed?'if qr and not B else'This will show the GV Code password. Would you like to proceed?'
			if not click.confirm(H,default=False):return 0
		F=resolve_api_url();A=resolve_target_env(F,env_name,reveal=B or qr)
	except RuntimeError as C:raise click.ClickException(str(C))from C
	if A.public_ip:
		try:I=ssh_access.fetch_env_ssh_access(F,A.id,request_api_json);E=github_access.github_status(A.id,I)
		except RuntimeError:E='unknown'
	print_env_info(A,title='Environment info',sensitive=B,github_status=E);click.echo(f"Current env: {A.name}")
	if qr:
		try:print_magic_login_details(create_opencode_magic_login(A))
		except(RuntimeError,ValueError)as C:click.echo(f"Magic login was unavailable: {C}",err=True);print_env_qr(A)
	try:G=[B for B in list_envs(F)if B.id!=A.id]
	except RuntimeError:G=[]
	if G:
		click.echo('\nOther environments')
		for D in G:click.echo(f"- {D.name}: {_display_env_phase(D)} {D.url} (switch with `gv env use {D.name}`)")
	return 0
def destroy_env(api_url:str,env_id:str)->None:request_api_json(api_url,'DELETE',f"/v1/envs/{env_id}")
def handle_destroy(name:str|None,all_envs:bool,yes:bool)->int:
	F=all_envs;E=name
	if F and E:raise click.ClickException('Pass either NAME or --all, not both.')
	if not F and not E:raise click.ClickException('Pass an environment name, or --all.')
	try:C=resolve_api_url();G=list_envs(C)
	except RuntimeError as B:raise click.ClickException(str(B))from B
	if F:D=G
	else:
		try:D=[find_env_by_name(G,E)]
		except RuntimeError as B:raise click.ClickException(str(B))from B
	if not D:click.echo('No environments to destroy.');return 0
	if not yes:
		if not is_interactive_input():raise click.ClickException('Refusing to destroy without --yes in a non-interactive shell.')
		click.echo('The following environments will be destroyed:')
		for A in D:click.echo(f"- {A.name} ({A.status}) {A.url or""}".rstrip())
		if not click.confirm('This permanently deletes the selected cloud dev environment(s). Work stored only in the environment will be lost. Continue?',default=False):click.echo('Aborted.');return 1
	H=0
	for A in D:
		try:
			destroy_env(C,A.id);I=read_current_env_lock(C)
			if I and I['id']==A.id:clear_current_env_lock(C)
			click.echo(f"Destroyed {A.name}.")
		except RuntimeError as B:H=1;click.echo(f"Failed to destroy {A.name}: {B}",err=True)
	return H
def handle_ssh(ssh_args:tuple[str,...],env_name:str|None=None)->int:
	B=ssh_args
	try:
		D=resolve_api_url();G=not B and is_interactive_input();A=resolve_target_env(D,env_name,reveal=G);C=ssh_access.fetch_env_ssh_access(D,A.id,request_api_json)
		if B or not is_interactive_input():return ssh_access.run_ssh(A.id,C,B)
		E=choose_ssh_target(A.name,discover_ssh_targets(A))
		if E.directory is None:ssh_access.exec_ssh(A.id,C,());return 0
		ssh_access.exec_ssh(A.id,C,(build_ssh_cd_command(E.directory),),allocate_tty=True);return 0
	except RuntimeError as F:raise click.ClickException(str(F))from F
def handle_upload(local_paths:tuple[str,...],remote_path:str|None,force:bool,workspace_name:str|None=None,env_name:str|None=None)->int:return upload_handler.handle_upload(local_paths,remote_path,force,workspace_name,env_name,resolve_env=_resolve_upload_env,fetch_ssh_access=_fetch_upload_ssh_access,is_interactive_input=is_interactive_input)
def _resolve_upload_env(env_name:str|None)->tuple[str,EnvRecord]:A=resolve_api_url();return A,resolve_target_env_interactively(A,env_name,reveal=True)
def _fetch_upload_ssh_access(api_url:str,env_id:str)->ssh_access.EnvSshAccess:return ssh_access.fetch_env_ssh_access(api_url,env_id,request_api_json)
def handle_opencode(env_name:str|None=None)->int:
	try:B=resolve_api_url();C=resolve_target_env(B,env_name,reveal=True);return opencode_launcher.handle_opencode(C)
	except RuntimeError as A:raise click.ClickException(str(A))from A
def handle_claude(env_name:str|None=None)->int:
	try:A=resolve_api_url();B=resolve_target_env(A,env_name,reveal=True);D=ssh_access.fetch_env_ssh_access(A,B.id,request_api_json);return claude_launcher.handle_claude(B,D)
	except RuntimeError as C:raise click.ClickException(str(C))from C
def handle_codex(env_name:str|None=None)->int:
	try:A=resolve_api_url();B=resolve_target_env(A,env_name,reveal=True);D=ssh_access.fetch_env_ssh_access(A,B.id,request_api_json);return codex_launcher.handle_codex(B,D)
	except RuntimeError as C:raise click.ClickException(str(C))from C
def handle_vscode(env_name:str|None=None)->int:
	try:A=resolve_api_url();B=resolve_target_env(A,env_name,reveal=True);D=ssh_access.fetch_env_ssh_access(A,B.id,request_api_json);return vscode_launcher.handle_vscode(B,D)
	except RuntimeError as C:raise click.ClickException(str(C))from C
def handle_cursor(env_name:str|None=None)->int:
	try:A=resolve_api_url();B=resolve_target_env(A,env_name,reveal=True);D=ssh_access.fetch_env_ssh_access(A,B.id,request_api_json);return cursor_launcher.handle_cursor(B,D)
	except RuntimeError as C:raise click.ClickException(str(C))from C
def discover_ssh_targets(env:EnvRecord)->list[SshTargetChoice]:
	B=[SshTargetChoice(label='~',directory=None)];C=remote_workspaces.discover_env_workspace_records(env)
	for A in C:B.append(SshTargetChoice(label=A.workspace_label,directory=A.directory,project_directory=A.project_directory))
	return B
def choose_ssh_target(env_name:str,choices:list[SshTargetChoice])->SshTargetChoice:
	A=choices
	if not A:raise RuntimeError('No SSH targets are available.')
	click.echo(f"\nSSH targets for {env_name}\n");C:str|None=None
	for(D,B)in enumerate(A,start=1):
		if B.directory is None:click.echo(f"  [{D}] {B.label}");continue
		if B.project_directory!=C:C=B.project_directory;click.echo(remote_workspaces.display_directory(B.project_directory or''))
		click.echo(f"  [{D}] {B.label}")
	if len(A)==1:return A[0]
	E=click.prompt('Choose an SSH target (input number)',type=click.IntRange(1,len(A)),default=1,show_default=True);return A[E-1]
def build_ssh_cd_command(directory:str)->str:A=f'cd {shlex.quote(directory)} && exec "${{SHELL:-/bin/bash}}" -i';return f"bash -lc {shlex.quote(A)}"
def handle_github_enable(env_name:str|None=None,yes:bool=False)->int:
	try:
		if not yes and not is_interactive_input():raise click.ClickException('`gv github enable` requires --yes in a non-interactive shell before opening GitHub.')
		if not yes:
			click.echo('GV will open GitHub so you can authorize this environment with your account.');click.echo('After approval, GV will install account access on this environment.')
			if not click.confirm('Continue?',default=False):return 0
		B=resolve_api_url();A=resolve_target_env(B,env_name,reveal=True);D=ssh_access.fetch_env_ssh_access(B,A.id,request_api_json);gv_config_access.install_local_gv_config(B,A,D);E=github_app_auth_flow.run_github_app_auth_flow(B,A,request_api_json=request_api_json,is_interactive_input=is_interactive_input)
	except RuntimeError as C:raise click.ClickException(str(C))from C
	click.echo(f"GitHub account connected for {A.name} as {E}.");_handle_repo_setup_after_github_auth(A);return 0
def handle_github_disable(env_name:str|None=None)->int:
	try:B=resolve_api_url();A=resolve_target_env(B,env_name);D=ssh_access.fetch_env_ssh_access(B,A.id,request_api_json);github_access.disable_github(A.id,D)
	except RuntimeError as C:raise click.ClickException(str(C))from C
	click.echo(f"GitHub auth disabled for {A.name}.");return 0
def handle_github_status(env_name:str|None=None)->int:
	try:B=resolve_api_url();A=resolve_target_env(B,env_name);D=ssh_access.fetch_env_ssh_access(B,A.id,request_api_json);E=github_access.github_status(A.id,D)
	except RuntimeError as C:raise click.ClickException(str(C))from C
	click.echo(f"{A.name}: {E}");return 0
def handle_openai_enable(env_name:str|None=None,yes:bool=False)->int:
	try:
		if not yes and not is_interactive_input():raise click.ClickException('`gv openai enable` requires --yes in a non-interactive shell before reading your local Codex auth.')
		if not openai_access.local_codex_auth_exists():raise click.ClickException(openai_access.LOCAL_CODEX_MISSING_HINT)
		if not yes and not click.confirm(f"This will read {openai_access.LOCAL_CODEX_PATH} and upload its contents to the selected environment so OpenAI-powered tools are signed in there too. Continue?",default=False):return 0
		B=resolve_api_url();A=resolve_target_env(B,env_name);D=ssh_access.fetch_env_ssh_access(B,A.id,request_api_json);E=openai_access.read_local_codex_auth();F=openai_access.enable_openai(A.id,D,E)
	except RuntimeError as C:raise click.ClickException(str(C))from C
	_print_openai_enable_result(A.name,F);return 0
def handle_openai_status(env_name:str|None=None)->int:
	try:B=resolve_api_url();A=resolve_target_env(B,env_name);D=ssh_access.fetch_env_ssh_access(B,A.id,request_api_json);E=openai_access.openai_status(A.id,D)
	except RuntimeError as C:raise click.ClickException(str(C))from C
	click.echo(f"{A.name}: {openai_access.format_status(E)}");return 0
def _apply_openai_enable(api_url:str,env:'EnvRecord')->None:
	A=env;click.echo(f"\nEnabling OpenAI auth on {A.name}...")
	try:B=ssh_access.fetch_env_ssh_access(api_url,A.id,request_api_json);C=openai_access.read_local_codex_auth();D=openai_access.enable_openai(A.id,B,C)
	except RuntimeError as E:click.echo(f"OpenAI auth not enabled: {E}",err=True);return
	_print_openai_enable_result(A.name,D)
def _print_openai_enable_result(env_name:str,detail:object)->None:
	B=env_name;A=detail
	if isinstance(A,str)and A:click.echo(f"{B}: {A}")
	else:click.echo(f"OpenAI auth enabled for {B}.")
def _apply_gv_config_install(api_url:str,env:'EnvRecord')->None:A=api_url;B=ssh_access.fetch_env_ssh_access(A,env.id,request_api_json);gv_config_access.install_local_gv_config(A,env,B)
def _apply_github_enable(api_url:str,env:'EnvRecord',*,confirm_launch:bool=False)->None:
	A=env;click.echo(f"\nEnabling GitHub auth on {A.name}...")
	if confirm_launch and not click.confirm(f"Open GitHub now to authorize {A.name} with your account?",default=True):click.echo(f"GitHub account was not connected for {A.name}.",err=True);click.echo(f"Enable it later with: gv github enable --env {A.name}",err=True);return
	try:B=github_app_auth_flow.run_github_app_auth_flow(api_url,A,request_api_json=request_api_json,is_interactive_input=is_interactive_input)
	except RuntimeError as C:click.echo(f"GitHub account was not connected: {C}",err=True);return
	click.echo(f"GitHub account connected for {A.name} as {B}.");_handle_repo_setup_after_github_auth(A)
def _handle_repo_setup_after_github_auth(env:'EnvRecord')->None:
	A=github_app_auth_flow.confirm_github_app_install_instructions(is_interactive_input=is_interactive_input)
	if A:_offer_repo_setup_after_github_auth(env);return
	_print_unconfirmed_repo_access_guidance(env)
def _print_unconfirmed_repo_access_guidance(env:'EnvRecord')->None:click.echo('');click.echo('Repo access was not confirmed, so repo setup was skipped.');click.echo(f"After granting repo access, run: {_repo_add_command_hint(env.name)}")
def _offer_repo_setup_after_github_auth(env:'EnvRecord')->None:
	A=env;click.echo('');click.echo('Repo access confirmed, but no repo has been added yet.')
	if not is_interactive_input():click.echo(f"Add a repo with: {_repo_add_command_hint(A.name)}");return
	if not click.confirm('Add a repo now?',default=True):click.echo(f"Set one up later with: {_repo_add_command_hint(A.name)}");return
	B=click.prompt('Repo path or GitHub URL').strip()
	if not B:click.echo(f"Set one up later with: {_repo_add_command_hint(A.name)}");return
	try:C=handle_repo_add(B,local_only=False,auto_approve=False,skip_env=False,target_env_id=A.id,target_env_name=A.name,target_env_url=A.url,target_env_vm_user=A.vm_username,target_env_opencode_username=A.opencode_username,target_env_opencode_password=A.opencode_password)
	except(RuntimeError,click.ClickException)as D:click.echo(f"Repo setup did not complete: {D}",err=True);click.echo(f"Try again with: {_repo_add_command_hint(A.name,B)}",err=True);return
	if C!=0:click.echo(f"Repo setup did not complete. Try again with: {_repo_add_command_hint(A.name,B)}",err=True)
def _repo_add_command_hint(env_name:str,directory_or_url:str|None=None)->str:
	B=directory_or_url;A=['gv','repo','add','--env',env_name]
	if B is None:C=[shlex.quote(A)for A in A];return' '.join([*C,'<path-or-github-url>'])
	A.append(B);return shlex.join(A)
def _apply_profile_to_ready_env(env:'EnvRecord')->None:
	click.echo(f"\nMirroring your local dev setup to {env.name}...")
	try:handle_profile_push(json_out=False,env_name=env.name,no_wait=False)
	except Exception as A:click.echo(f"Dev setup was not mirrored: {A}",err=True);return
class TrackedCommand(click.Command):
	def invoke(D,ctx:click.Context)->Any:
		A=False
		try:B=super().invoke(ctx);A=True;return B
		except click.exceptions.Exit as C:A=C.exit_code==0;raise
		finally:analytics.capture_cli_command(ctx.command_path,success=A)
class OrderedGroup(click.Group):
	command_class=TrackedCommand
	def list_commands(A,ctx:click.Context)->list[str]:return list(A.commands)
def _show_version(ctx:click.Context,_param:click.Parameter,value:bool)->None:
	if not value or ctx.resilient_parsing:return
	click.echo(f"gv {installed_cli_version()or"unknown"}");ctx.exit()
def _is_top_level_metadata_request(args:list[str])->bool:
	A=args
	if not A:return True
	if A in(['--version'],['version']):return True
	return'--help'in A or'-h'in A
@click.group(cls=OrderedGroup,context_settings={'help_option_names':['-h','--help']},help='\x08\nWelcome to gv.\n\ngv gives you a cloud dev environment for running coding agents.\n\n\x08\nGetting started:\n  1. Log in:\n     gv auth login\n\n\x08\n  2. Create your first cloud environment:\n     gv env create\n\n\x08\nAgent Instructions:\n  Some commands may prompt for missing required input.\n  Prompting is intended for human use.\n  For agent or CI usage, always pass required options explicitly.\n  If required options are missing in a non-interactive environment,\n  the command will fail instead of prompting.\n\n')
@click.option('--version',is_flag=True,is_eager=True,expose_value=False,callback=_show_version,help='Show the version and exit.')
def cli()->None:0
@cli.command('version',help='Show the version and exit.')
def version_command()->None:click.echo(f"gv {installed_cli_version()or"unknown"}")
@cli.group('env',cls=OrderedGroup,help='Manage cloud dev environments.')
def env_group()->None:0
@env_group.command('create',help='Create a new environment. Prompts for missing required values when run in a terminal.')
@click.option('--name',help='Environment name.')
@click.option('--git-user-name',help='Git author name for commits made in the environment.')
@click.option('--git-user-email',help='Git author email for commits made in the environment.')
@click.option('--telemetry/--no-telemetry',default=None,help='Opt in or out of coding-agent usage telemetry for this environment.')
@click.option('--enable-openai/--no-enable-openai',default=None,help='After the env is ready, push local Codex OpenAI auth without prompting.')
@click.option('--enable-github/--no-enable-github',default=None,help='After the env is ready, open GitHub without prompting.')
@click.option('--mirror-cli/--no-mirror-cli',default=None,help='After the env is ready, mirror local shell, editor, Git, and CLI tools.')
def env_create_command(name:str|None,git_user_name:str|None,git_user_email:str|None,telemetry:bool|None,enable_openai:bool|None,enable_github:bool|None,mirror_cli:bool|None)->None:handle_init(name,git_user_name,git_user_email,telemetry,enable_openai,enable_github,mirror_cli)
@env_group.command('list',help='List environments you own.')
@click.option('--json','json_out',is_flag=True,help='Emit JSON.')
def env_list_command(json_out:bool)->None:raise click.exceptions.Exit(handle_env_ls(json_out))
@env_group.command('info',help='Show current environment connection details.')
@click.option('--reveal',is_flag=True,help='Prompt before including sensitive fields like the GV Code password.')
@click.option('--qr',is_flag=True,help='Prompt before showing a mobile login QR code for GV Code.')
@click.option('-y','--yes',is_flag=True,help='Skip the confirmation prompt for --reveal/--qr.')
@_env_flag
def env_info_command(reveal:bool,qr:bool,yes:bool,env_name:str|None)->None:raise click.exceptions.Exit(handle_info(reveal,qr,env_name,yes))
@env_group.command('use',help='Select the current environment.')
@click.argument('name')
def env_use_command(name:str)->None:raise click.exceptions.Exit(handle_env_use(name))
@env_group.command('destroy',help='Permanently delete an environment and its cloud resources. Use --all to delete every env you own.')
@click.argument('name',required=False)
@click.option('--all','all_envs',is_flag=True,help='Destroy every environment you own.')
@click.option('--yes',is_flag=True,help='Skip the confirmation prompt.')
def env_destroy_command(name:str|None,all_envs:bool,yes:bool)->None:raise click.exceptions.Exit(handle_destroy(name,all_envs,yes))
_EDITOR_CHOICES='opencode','claude','codex','vscode','cursor'
def handle_env_ls(json_out:bool)->int:
	try:D=resolve_api_url();B=list_envs(D)
	except RuntimeError as E:raise click.ClickException(str(E))from E
	if json_out:click.echo(json.dumps([{'id':A.id,'name':A.name,'status':A.status,'step':A.step,'url':A.url,'public_ip':A.public_ip,'created_at':A.created_at}for A in B],indent=2,sort_keys=True));return 0
	if not B:click.echo('No environments.');return 0
	F=read_current_env_lock(D);C=[('NAME','STATUS','URL')]
	for A in B:G='*'if F and F['id']==A.id else' ';C.append((f"{G} {A.name}",_display_env_phase(A),A.url or'-'))
	H=[max(len(B[A])for B in C)for A in range(3)]
	for I in C:click.echo('  '.join(I[A].ljust(H[A])for A in range(3)))
	return 0
@cli.group('auth',cls=OrderedGroup,help='Log in to gv.')
def auth_group()->None:0
@auth_group.command('login',help='Log in to gv.')
def auth_login_command()->None:raise click.exceptions.Exit(handle_login())
@auth_group.command('logout',help='Log out of gv on this machine.')
def auth_logout_command()->None:raise click.exceptions.Exit(handle_logout())
@cli.command('info',help='Show current environment connection details.')
@click.option('--reveal',is_flag=True,help='Prompt before including sensitive fields like the GV Code password.')
@click.option('--qr',is_flag=True,help='Prompt before showing a mobile login QR code for GV Code.')
@click.option('-y','--yes',is_flag=True,help='Skip the confirmation prompt for --reveal/--qr.')
@_env_flag
def info(reveal:bool,qr:bool,yes:bool,env_name:str|None)->None:raise click.exceptions.Exit(handle_info(reveal,qr,env_name,yes))
@cli.command('support',help='Show how to contact gv support.')
def support_command()->None:click.echo('For any queries, email hello@tabtabtab.ai.')
@cli.command('ssh',context_settings={'ignore_unknown_options':True},help='SSH into the current environment. Pass a remote command after `--` to run it over SSH.')
@_env_flag
@click.argument('ssh_args',nargs=-1,type=click.UNPROCESSED)
def ssh(env_name:str|None,ssh_args:tuple[str,...])->None:raise click.exceptions.Exit(handle_ssh(ssh_args,env_name))
@cli.command('upload',help='Upload local files to the current environment and show transfer progress.\n\n\x08\nExamples:\n  gv upload ./notes.md --to ~/workspace/notes.md\n  gv upload ./docs --to docs/ --workspace my-repo\n  gv upload ./large.zip --to ~/workspace/ --force')
@_env_flag
@click.option('--to','remote_path',help='Destination on the environment. Use a full path like ~/workspace/file.txt, or use --workspace with a relative path like docs/.')
@click.option('--force',is_flag=True,help='Overwrite existing remote files.')
@click.option('--workspace','workspace_name',help='Put relative --to paths inside a workspace. Accepts a workspace label, project:workspace, or full remote workspace directory.')
@click.argument('local_paths',nargs=-1,type=click.UNPROCESSED)
def upload(env_name:str|None,remote_path:str|None,force:bool,workspace_name:str|None,local_paths:tuple[str,...])->None:raise click.exceptions.Exit(handle_upload(local_paths,remote_path,force,workspace_name,env_name))
@cli.command('open',help='Open a local editor attached to the current environment over SSH.')
@_env_flag
@click.argument('editor',required=False,type=click.Choice(_EDITOR_CHOICES),default='opencode')
def open_command(env_name:str|None,editor:str)->None:
	B=env_name;A=editor
	if A=='opencode':raise click.exceptions.Exit(handle_opencode(B))
	if A=='claude':raise click.exceptions.Exit(handle_claude(B))
	if A=='codex':raise click.exceptions.Exit(handle_codex(B))
	if A=='vscode':raise click.exceptions.Exit(handle_vscode(B))
	if A=='cursor':raise click.exceptions.Exit(handle_cursor(B))
	raise click.ClickException(f"Unknown editor: {A}")
@cli.group(cls=OrderedGroup,help='Manage CLI configuration.')
def config()->None:0
@cli.group('repo',cls=OrderedGroup,help='Repo onboarding commands.')
def repo_group()->None:0
@cli.group('github',cls=OrderedGroup,help='Manage GitHub access on an environment.')
def github_group()->None:0
@cli.group('runtime',cls=OrderedGroup,help='Manage the current GV workspace runtime.')
def runtime_group()->None:0
@runtime_group.command('up',help='Start the current workspace runtime.')
def runtime_up_command()->None:raise click.exceptions.Exit(_runtime_call(runtime.handle_runtime_up))
@runtime_group.command('status',help='Show the current workspace runtime status.')
def runtime_status_command()->None:raise click.exceptions.Exit(_runtime_call(runtime.handle_runtime_status))
@runtime_group.command('ports',help='List published runtime ports.')
@click.option('--all','all_runtimes',is_flag=True,help='List ports for all GV runtimes on this VM.')
def runtime_ports_command(all_runtimes:bool)->None:raise click.exceptions.Exit(_runtime_call(runtime.handle_runtime_ports,all_runtimes=all_runtimes))
@runtime_group.command('preview',help='Create a public preview URL for a service or host port.')
@click.argument('target')
def runtime_preview_command(target:str)->None:raise click.exceptions.Exit(_runtime_call(runtime.handle_runtime_preview,target))
@runtime_group.command('logs',help='Show logs for the current workspace runtime.')
def runtime_logs_command()->None:raise click.exceptions.Exit(_runtime_call(runtime.handle_runtime_logs))
@runtime_group.command('down',help='Stop the current workspace runtime.')
def runtime_down_command()->None:raise click.exceptions.Exit(_runtime_call(runtime.handle_runtime_down))
@runtime_group.command('rebuild',help='Rebuild and start the current workspace runtime.')
def runtime_rebuild_command()->None:raise click.exceptions.Exit(_runtime_call(runtime.handle_runtime_rebuild))
def _runtime_call(func,*C,**D)->int:
	try:return func(*C,**D)
	except subprocess.CalledProcessError as A:B=(A.stderr or A.stdout or'').strip();E=f": {B}"if B else'';raise click.ClickException(f"Runtime command failed with exit code {A.returncode}{E}")from A
	except RuntimeError as A:raise click.ClickException(str(A))from A
@config.command('set-api-url',help='Save the gv API URL.')
@click.argument('url')
def config_set_api_url(url:str)->None:
	try:B=normalize_api_url(url);C=load_cli_config();C['api_url']=B;save_cli_config(C);click.echo(f"Saved api_url to {CONFIG_PATH}");click.echo(B)
	except ValueError as A:raise click.ClickException(str(A))from A
	except RuntimeError as A:raise click.ClickException(str(A))from A
@config.command('show',help='Show the saved CLI configuration.')
def config_show()->None:
	try:B=load_cli_config();click.echo(json.dumps(redact_cli_config(B),indent=2,sort_keys=True))
	except RuntimeError as A:raise click.ClickException(str(A))from A
@github_group.command('enable',help='Connect GitHub to an environment.')
@click.option('-y','--yes',is_flag=True,help='Skip the confirmation prompt.')
@_env_flag
def github_enable_command(yes:bool,env_name:str|None)->None:raise click.exceptions.Exit(handle_github_enable(env_name,yes))
@github_group.command('disable',help='Remove GitHub auth from an environment.')
@_env_flag
def github_disable_command(env_name:str|None)->None:raise click.exceptions.Exit(handle_github_disable(env_name))
@github_group.command('status',help='Show GitHub auth status on an environment.')
@_env_flag
def github_status_command(env_name:str|None)->None:raise click.exceptions.Exit(handle_github_status(env_name))
@cli.group('openai',cls=OrderedGroup,help='Manage OpenAI auth on an environment.')
def openai_group()->None:0
@openai_group.command('enable',help='Push local Codex OpenAI auth (~/.codex/auth.json) to an environment.')
@click.option('-y','--yes',is_flag=True,help='Skip the confirmation prompt.')
@_env_flag
def openai_enable_command(yes:bool,env_name:str|None)->None:raise click.exceptions.Exit(handle_openai_enable(env_name,yes))
@openai_group.command('status',help='Show OpenAI auth status on an environment.')
@_env_flag
def openai_status_command(env_name:str|None)->None:raise click.exceptions.Exit(handle_openai_status(env_name))
@repo_group.command('add',help='Set up a repo in a cloud environment.')
@click.argument('directory_or_url',metavar='DIRECTORY_OR_URL')
@click.option('--dry-run',is_flag=True,help='Preview what would be saved without changing anything.')
@click.option('--yes','auto_approve',is_flag=True,help='Accept the default classification without an interactive review.')
@click.option('--skip-env','skip_env',is_flag=True,help='Skip env var discovery entirely.')
@_env_flag
def repo_add_command(directory_or_url:str,dry_run:bool,auto_approve:bool,skip_env:bool,env_name:str|None)->None:
	C=dry_run;B=directory_or_url;D:str|None=None;E:str|None=None;F:str|None=None;G:str|None=None;H:str|None=None;I:str|None=None
	if not C:
		try:
			A=_resolve_repo_add_env(B,env_name);D,E,F,G=A[:4]
			if len(A)>=6:H=A[4];I=A[5]
		except RuntimeError as J:raise click.ClickException(str(J))from J
	raise click.exceptions.Exit(handle_repo_add(B,local_only=C,auto_approve=auto_approve,skip_env=skip_env,target_env_id=D,target_env_name=E,target_env_url=F,target_env_vm_user=G,target_env_opencode_username=H,target_env_opencode_password=I))
@repo_group.command('list',help='List repos you have registered.')
@click.option('--json','json_out',is_flag=True,help='Emit JSON.')
def repo_list_command(json_out:bool)->None:raise click.exceptions.Exit(handle_repo_list(json_out=json_out))
@repo_group.group('env',cls=OrderedGroup,help='Manage env vars / secrets on a repo.')
def repo_env_group()->None:0
def _repo_flag(func):return click.option('--repo','repo',default=None,help='Repo id (or id-prefix / name). Defaults to the repo at $PWD.')(func)
@repo_group.command('onboard',help='Re-run cloud setup for an already-registered repo.')
@_repo_flag
def repo_onboard_command(repo:str|None)->None:raise click.exceptions.Exit(handle_repo_onboard(repo=repo))
@repo_env_group.command('list',help='List env vars / secrets on a repo.')
@_repo_flag
@click.option('--reveal',is_flag=True,help='Show secret values in plaintext.')
@click.option('--json','json_out',is_flag=True,help='Emit JSON.')
def repo_env_list_command(repo:str|None,reveal:bool,json_out:bool)->None:raise click.exceptions.Exit(handle_env_list(repo=repo,reveal=reveal,json_out=json_out))
@repo_env_group.command('add',help='Upsert an env var on a repo (KEY=VALUE).')
@_repo_flag
@click.argument('assignment')
@click.option('--source',default='.env',show_default=True,help='Source path recorded with the entry (relative to repo root).')
@click.option('--secret/--plain','mark_secret',default=None,help="Override auto-classification. If unset, the CLI's classifier decides.")
def repo_env_add_command(repo:str|None,assignment:str,source:str,mark_secret:bool|None)->None:raise click.exceptions.Exit(handle_env_add(repo=repo,assignment=assignment,source=source,mark_secret=mark_secret))
@repo_env_group.command('rm',help='Delete an env var from a repo.')
@_repo_flag
@click.argument('key')
@click.option('--source',default=None,help='Restrict delete to this source path. Required if the key is ambiguous.')
@click.option('--yes','yes',is_flag=True,help='Skip the confirmation prompt.')
def repo_env_rm_command(repo:str|None,key:str,source:str|None,yes:bool)->None:raise click.exceptions.Exit(handle_env_rm(repo=repo,key=key,source=source,yes=yes))
@cli.group('profile',cls=OrderedGroup,help='Capture your local dev environment.')
def profile_group()->None:0
@profile_group.command('show',help='Print your locally-detected profile. No upload.')
@click.option('--json','json_out',is_flag=True,help='Emit JSON.')
def profile_show_command(json_out:bool)->None:handle_profile_show(json_out)
@profile_group.command('push',help='Save your local dev profile to gv.')
@click.option('--apply','apply_current',is_flag=True,help='After pushing, install the profile on the current env.')
@click.option('--no-wait','no_wait',is_flag=True,help='With --apply, return immediately instead of waiting for mirroring to finish.')
@click.option('--json','json_out',is_flag=True,help='Emit JSON.')
@_env_flag
def profile_push_command(apply_current:bool,no_wait:bool,json_out:bool,env_name:str|None)->None:
	C=env_name;B=no_wait;A=apply_current
	if B and not A:raise click.UsageError('--no-wait only makes sense with --apply.')
	if C and not A:raise click.UsageError('--env only makes sense with --apply.')
	D=None
	if A:
		try:D=resolve_target_env(resolve_api_url(),C).name
		except RuntimeError as E:raise click.ClickException(str(E))from E
	handle_profile_push(json_out=json_out,env_name=D,no_wait=B)
@profile_group.command('apply',help='Install the pushed profile on the current env (without re-pushing).')
@click.option('--no-wait','no_wait',is_flag=True,help='Return immediately instead of waiting for mirroring to finish.')
@click.option('--json','json_out',is_flag=True,help='Emit JSON.')
@_env_flag
def profile_apply_command(no_wait:bool,json_out:bool,env_name:str|None)->None:
	A=env_name
	try:A=resolve_target_env(resolve_api_url(),A).name
	except RuntimeError as B:raise click.ClickException(str(B))from B
	handle_profile_apply(A,json_out=json_out,no_wait=no_wait)
@profile_group.command('job',help='Show progress for a profile mirror operation.')
@click.argument('job_id')
@click.option('--watch',is_flag=True,help='Wait until the operation finishes.')
@click.option('--json','json_out',is_flag=True,help='Emit JSON.')
def profile_job_command(job_id:str,watch:bool,json_out:bool)->None:handle_profile_job(job_id,json_out=json_out,watch=watch)
@profile_group.command('pull',help='Show the dev profile saved in gv.')
@click.option('--json','json_out',is_flag=True,help='Emit JSON.')
def profile_pull_command(json_out:bool)->None:handle_profile_pull(json_out)
def main()->int:
	try:
		B=sys.argv[1:]
		if not _is_top_level_metadata_request(B):enforce_latest_cli_version()
		cli.main(args=B,prog_name='gv',standalone_mode=False);return 0
	except click.ClickException as A:A.show();return A.exit_code
	except click.exceptions.Exit as A:return A.exit_code
	except KeyboardInterrupt:click.echo('',err=True);return 130
	except RuntimeError as A:click.echo(str(A),err=True);return 1
if __name__=='__main__':raise SystemExit(main())