from __future__ import annotations
import base64,re
from urllib.parse import quote
_GIT_REMOTE_RE=re.compile('\n    ^\n    (?:                                 # scheme / user@host prefix (all optional)\n        (?:https?|ssh|git)://[^/]+/\n      | [^@\\s:]+@[^:/\\s]+:\n      | [^:/\\s]+:                       # bare `host:` (old-style ssh)\n    )?\n    (?P<owner>[^/\\s]+)                  # owner / org / user\n    /\n    (?P<name>[^/\\s]+?)                  # repo name\n    (?:\\.git)?                          # optional .git suffix\n    /?$\n    ',re.VERBOSE)
_GITHUB_REMOTE_RE=re.compile('\n    ^\n    (?:\n        git@github\\.com:\n      | ssh://git@github\\.com/\n      | https://github\\.com/\n    )\n    (?P<owner>[^/\\s]+)\n    /\n    (?P<name>[^/\\s]+?)\n    (?:\\.git)?\n    /?$\n    ',re.VERBOSE|re.IGNORECASE)
def parse_git_owner(remote_url:str|None)->str|None:
	A=remote_url
	if not A:return
	B=_GIT_REMOTE_RE.match(A.strip());return B.group('owner')if B else None
def normalize_github_remote_to_https(remote_url:str|None)->str|None:
	A=remote_url
	if not A:return
	B=_GITHUB_REMOTE_RE.match(A.strip())
	if not B:return A
	return f"https://github.com/{B.group("owner")}/{B.group("name")}.git"
def build_opencode_workspace_path(vm_user:str|None,repo_name:str,*,workspace_name:str|None=None)->str|None:
	C=workspace_name;B=repo_name;A=vm_user
	if not A or not B:return
	if C:return f"/home/{A}/workspace/.gv-workspaces/{B}/{C}"
	return f"/home/{A}/workspace/{B}"
def build_opencode_session_url(env_url:str|None,vm_user:str|None,repo_name:str,session_id:str|None=None,*,workspace_name:str|None=None)->str|None:
	C=session_id;B=repo_name;A=env_url
	if not A or not B:return
	D=build_opencode_workspace_path(vm_user,B,workspace_name=workspace_name)
	if not D:return
	F=base64.b64encode(D.encode('utf-8')).decode('ascii').rstrip('=');E=f"{A.rstrip("/")}/{F}/session"
	if C:return f"{E}/{quote(C,safe="")}"
	return E
def format_opencode_hints(url:str,repo_name:str,*,has_session_id:bool)->list[str]:
	A=[f"GV Code: {url}",'Continue in GV Code to start working.']
	if not has_session_id:A.append(f"Open the {repo_name} workspace if GV Code shows multiple projects.")
	return A
def preview_value(value:str,is_secret:bool,*,reveal:bool=False)->str:
	A=value
	if is_secret and not reveal:return'********'
	if len(A)>40:return A[:37]+'...'
	return A
def format_sync_status(status:str|None,step:str|None=None)->str:
	A=status
	if A=='ready':return'Ready'
	if A=='failed':return'Failed'
	if A in{'running','pending'}:return'Setting up'
	if step=='queued':return'Queued'
	return'Working'
def short_id(full_id:str,length:int=8)->str:return full_id[:length]
def render_table(rows:list[list[str]],headers:list[str])->str:
	C=headers;A=[len(A)for A in C]
	for F in rows:
		for(D,G)in enumerate(F):A[D]=max(A[D],len(G))
	def B(row:list[str])->str:return'  '.join(C.ljust(A[B])for(B,C)in enumerate(row)).rstrip()
	E=[B(C),B(['-'*A for A in A])];E.extend(B(A)for A in rows);return'\n'.join(E)