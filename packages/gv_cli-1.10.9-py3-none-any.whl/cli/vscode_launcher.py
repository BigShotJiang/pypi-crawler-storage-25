from __future__ import annotations
import asyncio,os,shutil,subprocess,sys
from pathlib import Path
from typing import Protocol
import httpx
from.import opencode_launcher,remote_workspaces,ssh_access
REMOTE_SSH_EXTENSION='ms-vscode-remote.remote-ssh'
class EnvLike(Protocol):id:str;name:str;url:str|None;opencode_username:str;opencode_password:str
def handle_vscode(env:EnvLike,ssh_details:ssh_access.EnvSshAccess)->int:
	A=env;D=ensure_local_vscode_ready();opencode_launcher.validate_env_supports_attach(A)
	try:B=asyncio.run(remote_workspaces.discover_workspace_records(A))
	except httpx.HTTPError as C:raise RuntimeError(f"Failed to query remote GV Code: {C}")from C
	if not B:raise RuntimeError('GV Code has no known projects in this environment yet. Open the web UI first to initialize one.')
	E=remote_workspaces.choose_workspace_record(A.name,B);F=ssh_access.install_ssh_config_entry(A.id,A.name,ssh_details);exec_vscode(D,F,E.directory);return 0
def ensure_local_vscode_ready()->str:
	A=_resolve_local_vscode_path()
	if not A:raise RuntimeError("VS Code CLI (`code`) is not installed locally or not on PATH. Install VS Code and, on macOS, run `Shell Command: Install 'code' command in PATH`.")
	_run_local_vscode_command(A,'--version');B=_run_local_vscode_command(A,'--list-extensions');C={A.strip()for A in B.stdout.splitlines()if A.strip()}
	if REMOTE_SSH_EXTENSION not in C:raise RuntimeError('VS Code Remote - SSH is required locally. Install it with `code --install-extension ms-vscode-remote.remote-ssh`.')
	return A
def exec_vscode(vscode_path:str,ssh_alias:str,directory:str)->None:A=[vscode_path,'--remote',f"ssh-remote+{ssh_alias}",directory];os.execvpe(A[0],A,os.environ.copy())
def _run_local_vscode_command(vscode_path:str,*G:str)->subprocess.CompletedProcess[str]:
	B=vscode_path;D=[B,*G]
	try:A=subprocess.run(D,check=False,capture_output=True,text=True,timeout=15)
	except OSError as C:raise RuntimeError(f"VS Code CLI at `{B}` could not be executed: {C}.")from C
	except subprocess.TimeoutExpired as C:E=' '.join(D[1:]);raise RuntimeError(f"VS Code CLI at `{B}` did not respond to `code {E}`.")from C
	if A.returncode==0:return A
	H=f"signal {-A.returncode}"if A.returncode<0 else f"exit code {A.returncode}";F=(A.stderr or A.stdout).strip();I=f" {F}"if F else'';E=' '.join(D[1:]);raise RuntimeError(f"VS Code CLI at `{B}` failed to run `code {E}` ({H}).{I}")
def _resolve_local_vscode_path()->str|None:
	A=shutil.which('code')
	if A:return A
	if sys.platform!='darwin':return
	for B in _macos_vscode_candidates():
		if B.is_file():return str(B)
def _macos_vscode_candidates()->tuple[Path,...]:return Path('/Applications/Visual Studio Code.app/Contents/Resources/app/bin/code'),Path.home()/'Applications/Visual Studio Code.app/Contents/Resources/app/bin/code'