from __future__ import annotations
import asyncio,os,re,shutil,subprocess
from dataclasses import dataclass
from typing import Any,Protocol
import click,httpx
from.import remote_workspaces
MINIMUM_OPENCODE_VERSION=1,14,11
MINIMUM_OPENCODE_VERSION_TEXT=f"{MINIMUM_OPENCODE_VERSION[0]}.{MINIMUM_OPENCODE_VERSION[1]}.x"
OPENCODE_INSTALL_COMMAND='curl -fsSL https://opencode.ai/install | bash'
class EnvLike(Protocol):name:str;url:str|None;opencode_username:str;opencode_password:str
@dataclass(frozen=True)
class SessionRecord:id:str;title:str;directory:str;updated_at:int
@dataclass(frozen=True)
class WorktreeRecord:name:str;branch:str;directory:str
@dataclass(frozen=True)
class LaunchChoice:
	project_label:str;workspace_label:str;directory:str;session_id:str|None;session_title:str|None;create_workspace:bool=False
	@property
	def is_create_workspace(self)->bool:return self.create_workspace
	@property
	def is_new_session(self)->bool:return self.session_id is None and not self.create_workspace
def handle_opencode(env:EnvLike)->int:
	A=env;E=ensure_local_opencode_installed();validate_env_supports_attach(A)
	try:F,D=asyncio.run(discover_remote_opencode(A))
	except httpx.HTTPError as B:raise RuntimeError(f"Failed to query remote GV Code: {B}")from B
	validate_version_compatibility(E,F)
	if not D:raise RuntimeError('GV Code has no known projects in this environment yet. Open the web UI first to initialize one.')
	C=choose_launch_choice(A.name,D)
	if C.is_create_workspace:
		click.echo('Creating new workspace...')
		try:C=asyncio.run(create_workspace_launch_choice(A,C))
		except httpx.HTTPError as B:raise RuntimeError(f"Failed to create remote GV Code workspace: {B}")from B
		click.echo(f"Starting new session in {C.workspace_label}")
	exec_attach(A,C);return 0
def ensure_local_opencode_installed()->tuple[int,int,int]:
	B=shutil.which('opencode')
	if not B:raise RuntimeError(f"OpenCode CLI is not installed locally. Install it with `{OPENCODE_INSTALL_COMMAND}` and try again.")
	try:A=subprocess.run([B,'--version'],check=False,capture_output=True,text=True,timeout=10)
	except OSError as C:raise RuntimeError(f"OpenCode CLI is installed at `{B}` but could not be executed: {C}. Reinstall it with `{OPENCODE_INSTALL_COMMAND}`.")from C
	except subprocess.TimeoutExpired as C:raise RuntimeError(f"OpenCode CLI at `{B}` did not respond to `opencode --version`. Reinstall or upgrade it with `{OPENCODE_INSTALL_COMMAND}`.")from C
	if A.returncode==0:
		D=(A.stdout or A.stderr).strip();E=_parse_opencode_version(D)
		if E is None:G=D or'<empty output>';raise RuntimeError(f"OpenCode CLI at `{B}` returned an unrecognized version string `{G}`. Upgrade it to {MINIMUM_OPENCODE_VERSION_TEXT} or newer with `{OPENCODE_INSTALL_COMMAND}`.")
		if _compatibility_version(E)<_compatibility_version(MINIMUM_OPENCODE_VERSION):raise RuntimeError(f"OpenCode CLI at `{B}` is too old ({D}). Version {MINIMUM_OPENCODE_VERSION_TEXT} or newer is required. Upgrade it with `{OPENCODE_INSTALL_COMMAND}`.")
		return E
	H=f"signal {-A.returncode}"if A.returncode<0 else f"exit code {A.returncode}";F=(A.stderr or A.stdout).strip();I=f" {F}"if F else'';raise RuntimeError(f"OpenCode CLI at `{B}` failed to run `opencode --version` ({H}).{I} Reinstall or upgrade it with `{OPENCODE_INSTALL_COMMAND}`.")
def validate_env_supports_attach(env:EnvLike)->None:
	if not env.url:raise RuntimeError('Environment does not have a GV Code URL yet.')
	if env.opencode_username!='opencode':raise RuntimeError('This environment uses a non-default GV Code username. `opencode attach` currently requires username `opencode`.')
async def discover_launch_choices(env:EnvLike)->list[LaunchChoice]:B,A=await discover_remote_opencode(env);return A
async def discover_remote_opencode(env:EnvLike)->tuple[tuple[int,int,int]|None,list[LaunchChoice]]:
	B=env
	async with httpx.AsyncClient(timeout=15,auth=httpx.BasicAuth(B.opencode_username,B.opencode_password))as E:J=await fetch_remote_opencode_version(E,B.url or'');G=await remote_workspaces.fetch_workspace_records(E,B.url or'');K=await asyncio.gather(*(fetch_sessions(E,B.url or'',A.directory)for A in G))
	C:list[LaunchChoice]=[];F:tuple[str,str]|None=None;D:remote_workspaces.WorkspaceRecord|None=None
	for(A,L)in zip(G,K,strict=True):
		H=A.project_label,A.project_directory
		if F is not None and H!=F:
			if D is not None:C.append(_create_workspace_choice(D))
		F=H;D=A
		for I in L:C.append(LaunchChoice(project_label=A.project_label,workspace_label=A.workspace_label,directory=A.directory,session_id=I.id,session_title=I.title))
		C.append(LaunchChoice(project_label=A.project_label,workspace_label=A.workspace_label,directory=A.directory,session_id=None,session_title=None))
	if D is not None:C.append(_create_workspace_choice(D))
	return J,C
async def fetch_remote_opencode_version(client:httpx.AsyncClient,base_url:str)->tuple[int,int,int]|None:
	A=await client.get(f"{base_url.rstrip("/")}/global/health");A.raise_for_status();B=A.json()
	if not isinstance(B,dict):return
	C=_string(B.get('version'))
	if not C:return
	return _parse_opencode_version(C)
def validate_version_compatibility(local_version:tuple[int,int,int],remote_version:tuple[int,int,int]|None)->None:
	B=local_version;A=remote_version
	if A is None or _compatibility_version(B)>=_compatibility_version(A):return
	C=_format_opencode_version(A);D=_format_opencode_version(B);E=f"npm install -g opencode-ai@{C}";raise RuntimeError(f"Local OpenCode CLI is on an older compatibility line than the remote environment ({D} < {C}). `opencode attach` can fail when the local client is behind the server. Upgrade with `{OPENCODE_INSTALL_COMMAND}` or install the exact server version with `{E}`.")
async def fetch_sessions(client:httpx.AsyncClient,base_url:str,directory:str)->list[SessionRecord]:
	D=await client.get(f"{base_url.rstrip("/")}/session",params={'directory':directory});D.raise_for_status();I=D.json();J=_extract_items(I,singular='session',plural='sessions');B:list[SessionRecord]=[]
	for A in J:
		if _string(A.get('parentID')):continue
		C=A.get('time')
		if not isinstance(C,dict):continue
		if C.get('archived')is not None:continue
		E=_string(A.get('id'));F=_string(A.get('title'));G=_string(A.get('directory'));H=_int_value(C.get('updated'))
		if not E or not F or not G or H is None:continue
		B.append(SessionRecord(id=E,title=F,directory=G,updated_at=H))
	B.sort(key=lambda session:(-session.updated_at,session.title.lower(),session.id));return B
async def create_workspace_launch_choice(env:EnvLike,choice:LaunchChoice)->LaunchChoice:
	B=choice;A=env
	async with httpx.AsyncClient(timeout=60,auth=httpx.BasicAuth(A.opencode_username,A.opencode_password))as D:C=await create_worktree(D,A.url or'',B.directory)
	return LaunchChoice(project_label=B.project_label,workspace_label=C.name,directory=C.directory,session_id=None,session_title=None)
async def create_worktree(client:httpx.AsyncClient,base_url:str,project_directory:str)->WorktreeRecord:
	B=await client.post(f"{base_url.rstrip("/")}/experimental/worktree",params={'directory':project_directory},json={});B.raise_for_status();A=B.json()
	if not isinstance(A,dict):raise RuntimeError('GV Code returned an invalid worktree response.')
	C=_string(A.get('name'));D=_string(A.get('branch'));E=_string(A.get('directory'))
	if not C or not D or not E:raise RuntimeError('GV Code returned an incomplete worktree response.')
	return WorktreeRecord(name=C,branch=D,directory=E)
def choose_launch_choice(env_name:str,choices:list[LaunchChoice])->LaunchChoice:
	B=choices;click.echo(f"\nGV Code sessions for {env_name}\n");E:tuple[str,str]|None=None;C:tuple[str,str]|None=None
	for(D,A)in enumerate(B,start=1):
		F=_project_directory_for_choice(A,B);G=A.project_label,F
		if G!=E:E=G;C=None;click.echo(remote_workspaces.display_directory(F))
		if A.is_create_workspace:C=None;click.echo(f"  [{D}] Create new workspace");continue
		H=A.project_label,A.workspace_label
		if H!=C:C=H;click.echo(f"  {A.workspace_label}")
		if A.is_new_session:click.echo(f"    [{D}] New session")
		else:click.echo(f"    [{D}] Resume: {A.session_title}")
	if len(B)==1:return B[0]
	I=click.prompt('Choose a session (input number)',type=click.IntRange(1,len(B)));return B[I-1]
def _create_workspace_choice(record:remote_workspaces.WorkspaceRecord)->LaunchChoice:A=record;return LaunchChoice(project_label=A.project_label,workspace_label='',directory=A.project_directory,session_id=None,session_title=None,create_workspace=True)
def exec_attach(env:EnvLike,choice:LaunchChoice)->None:
	A=choice;B=['opencode','attach',env.url or'','--dir',A.directory]
	if A.session_id:B.extend(['--session',A.session_id])
	C=os.environ.copy();C['OPENCODE_SERVER_PASSWORD']=env.opencode_password;os.execvpe(B[0],B,C)
def _project_directory_for_choice(choice:LaunchChoice,choices:list[LaunchChoice])->str:
	A=choice
	if A.is_create_workspace or A.workspace_label=='main':return A.directory
	for B in choices:
		if B.project_label==A.project_label and B.workspace_label=='main':return B.directory
	return A.directory
def _extract_items(payload:Any,*,singular:str,plural:str)->list[dict[str,Any]]:
	C=plural;A=payload
	if isinstance(A,list):return[A for A in A if isinstance(A,dict)]
	if isinstance(A,dict):
		for D in(C,singular):
			B=A.get(D)
			if isinstance(B,list):return[A for A in B if isinstance(A,dict)]
			if isinstance(B,dict):return[B]
	raise RuntimeError(f"GV Code returned an invalid {C} response.")
def _string(value:Any)->str|None:
	A=value
	if A is None:return
	B=str(A);return B or None
def _int_value(value:Any)->int|None:
	A=value
	if A is None:return
	try:return int(A)
	except(TypeError,ValueError):return
def _parse_opencode_version(output:str)->tuple[int,int,int]|None:
	A=re.search('(?<!\\d)(\\d+)\\.(\\d+)\\.(\\d+)(?!\\d)',output)
	if not A:return
	return tuple(int(A)for A in A.groups())
def _format_opencode_version(version:tuple[int,int,int])->str:return'.'.join(str(A)for A in version)
def _compatibility_version(version:tuple[int,int,int])->tuple[int,int]:return version[:2]