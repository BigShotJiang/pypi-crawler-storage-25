from __future__ import annotations
import asyncio,base64,json,re,shlex,time
from collections import Counter
from pathlib import Path
from urllib import error,request
from urllib.parse import unquote,urlparse
import click,httpx
from..analytics import capture_repo_add_unsupported
from..github_app_auth_flow import GITHUB_APP_INSTALL_URL
from..http_client import UNAUTHORIZED_MESSAGE,api_base_url,auth_headers
from..repo_env.client import get_json
from..repo_env.format import build_opencode_session_url,format_sync_status,format_opencode_hints,normalize_github_remote_to_https
from..repo_env.format import preview_value as _preview_value
from..repo_env.resolve import RepoRef
from.classify import classify
from.env_values import RawEnvVar,collect_env_vars
from.remote import read_git_info
from.schema import EnvVarEntry,GitInfo,RepoAddOutcome,RepoAddRequest
from.sync import post_repo_add
__all__=['handle_repo_add']
def handle_repo_add(directory_arg:str|None,*,local_only:bool=False,auto_approve:bool=False,skip_env:bool=False,target_env_id:str|None=None,target_env_name:str|None=None,target_env_url:str|None=None,target_env_vm_user:str|None=None,target_env_opencode_username:str|None=None,target_env_opencode_password:str|None=None)->int:
	M=auto_approve;I=target_env_id;G=target_env_name;F=directory_arg;C=local_only
	if not F:raise RuntimeError('Usage: gv repo add <directory-or-github-url>')
	N=_git_info_from_github_url(F);A:Path|None=None;H:str;J:str
	if N is None:
		A=Path(F).expanduser().resolve()
		if not A.exists():raise RuntimeError(f"Directory not found: {A}")
		if not A.is_dir():raise RuntimeError(f"Not a directory: {A}")
		D=read_git_info(A);H=A.name;J=str(A)
	else:D=N;H=_repo_name_from_remote(D.remote_url);J=D.remote_url or F
	K=normalize_github_remote_to_https(D.remote_url)
	if C and not K:
		if A is not None:capture_repo_add_unsupported(directory=A,reason='missing_git_remote',local_only=True)
		raise RuntimeError('Only repositories with a git remote are supported for now.')
	if not C and I and G:_require_remote_access_preflight(remote_url=K,retry_arg=F,target_env_id=I,target_env_name=G)
	E:list[EnvVarEntry]=[];L=False
	if skip_env or A is None:L=True
	else:
		O=collect_env_vars(A)
		if O:
			E=_build_entries(O)
			if not M:_print_summary(E,local_only=C);E=_review_entries(E)
	if not C and not M and not L and E and not _ask_send_to_backend():C=True
	B=_build_outcome(repo_name=H,git_info=D,entries=E,skipped_env=L,local_only=C,target_env_name=G,target_env_url=target_env_url,target_env_vm_user=target_env_vm_user,target_env_opencode_username=target_env_opencode_username,target_env_opencode_password=target_env_opencode_password)
	if not C:
		Q=RepoAddRequest(local_path=J,name=H,target_env_id=I,git_remote_url=K,active_branch=D.active_branch,default_branch=D.default_branch,env_vars=E)
		try:P=asyncio.run(post_repo_add(Q));_apply_sync_state(B,P);_poll_repo_sync(B,P.id)
		except RuntimeError as R:B.backend_sync_error=_format_repo_setup_error(str(R),remote_url=B.git_remote_url,env_name=G);B.exit_code=1
	_refresh_opencode_login(B);_print_outcome(B);return B.exit_code
def _git_info_from_github_url(value:str)->GitInfo|None:
	C=value.strip();A:str|None=None
	if C.lower().startswith('git@github.com:'):A=C.split(':',1)[1]
	elif C.lower().startswith('github.com/'):A=C[len('github.com'):]
	else:
		B=urlparse(C);E=(B.hostname or'').lower()
		if B.scheme.lower()in{'http','https'}and E=='github.com':A=B.path
		elif B.scheme.lower()=='ssh'and E=='github.com'and(B.username or'').lower()=='git':A=B.path
	if A is None:return
	F=[unquote(A)for A in A.split('/')if A]
	if len(F)!=2:raise RuntimeError('Unsupported GitHub URL. Use https://github.com/OWNER/REPO[.git].')
	G,D=F
	if D.endswith('.git'):D=D[:-4]
	if not G or not D:raise RuntimeError('Unsupported GitHub URL. Use https://github.com/OWNER/REPO[.git].')
	H=f"https://github.com/{G}/{D}.git";return GitInfo(remote_url=H)
def _repo_name_from_remote(remote_url:str|None)->str:
	B=remote_url
	if not B:return'repo'
	C=urlparse(B).path.rstrip('/');A=Path(C).name
	if A.endswith('.git'):A=A[:-4]
	return A or'repo'
def _print_summary(entries:list[EnvVarEntry],*,local_only:bool)->None:
	A=entries;C=sorted({A.source_path for A in A});D=sum(1 for A in A if A.is_secret);E=len(A)-D;F='file'if len(C)==1 else'files';click.echo(f"Found {len(A)} env var(s) across {len(C)} {F}: {", ".join(C)}");click.echo(f"  {D} classified as secret, {E} as plain (by key name + value entropy).")
	if not local_only:click.echo('  All values are stored securely by gv.')
	click.echo('');click.echo('Classification (S=secret, P=plain):')
	for B in A:G='S'if B.is_secret else'P';H=_preview_value(B.value,B.is_secret);click.echo(f"  [{G}] {B.key} ({B.source_path})  {H}")
	click.echo('')
def _ask_send_to_backend()->bool:return click.confirm('Save to gv?',default=True)
def _require_remote_access_preflight(*,remote_url:str|None,retry_arg:str|None,target_env_id:str,target_env_name:str)->None:
	A=remote_url
	if not _is_github_remote(A):return
	_check_control_plane_repo_access(remote_url=A,retry_arg=retry_arg,target_env_id=target_env_id,target_env_name=target_env_name)
def _check_control_plane_repo_access(*,remote_url:str,retry_arg:str|None,target_env_id:str,target_env_name:str)->None:
	D=remote_url;B=target_env_name;C=_github_repo_slug(D)
	if C is None:return
	A=_post_control_plane_repo_access(target_env_id,C)
	if A.is_success:return
	E=_response_error_detail(A)
	if A.status_code==401:raise RuntimeError(UNAUTHORIZED_MESSAGE)
	if A.status_code==409:raise click.ClickException(f"GitHub auth is disabled on {B}. Run `gv github enable` and try again.")
	if A.status_code>=500:raise click.ClickException(f"GitHub auth cannot be checked on {B}: {E or f"HTTP {A.status_code}"}")
	raise click.ClickException(_github_repo_access_message(repo_slug=C,remote_url=D,retry_arg=retry_arg,target_env_name=B))
def _post_control_plane_repo_access(target_env_id:str,repo_slug:str)->httpx.Response:
	with httpx.Client(timeout=30,headers=auth_headers())as A:return A.post(f"{api_base_url()}/v1/envs/{target_env_id}/github-repo-access",json={'repoSlug':repo_slug})
def _github_repo_slug(remote_url:str|None)->str|None:
	B=remote_url
	if not B:return
	C=urlparse(B)
	if(C.hostname or'').lower()!='github.com':return
	D=[unquote(A)for A in C.path.split('/')if A]
	if len(D)!=2:return
	E,A=D
	if A.endswith('.git'):A=A[:-4]
	if not E or not A:return
	return f"{E}/{A}"
def _response_error_detail(response:httpx.Response)->str:
	try:A=response.json()
	except ValueError:return''
	if not isinstance(A,dict):return''
	B=A.get('githubMessage')or A.get('error')or A.get('detail');return B if isinstance(B,str)else''
def _github_repo_access_message(*,repo_slug:str|None,remote_url:str|None,retry_arg:str|None=None,target_env_name:str|None)->str:
	C=target_env_name;B=remote_url;D=repo_slug or B or'this repo';A=['gv','repo','add']
	if C:A.extend(['--env',C])
	E=retry_arg or B
	if E:A.append(E)
	F=[f"The GV GitHub App cannot access {D} yet.",f"Open {GITHUB_APP_INSTALL_URL} and grant the app access to {D}.",'Then run:',f"  {shlex.join(A)}"];return'\n'.join(F)
def _looks_like_github_access_error(message:str)->bool:A=message.lower();B='write access to repository not granted','requested url returned error: 403','the requested url returned error: 403','repository not found','not found','could not read from remote repository';return any(B in A for B in B)
def _format_repo_setup_error(message:str,*,remote_url:str|None,env_name:str|None)->str:
	B=message;A=remote_url
	if not _is_github_remote(A)or not _looks_like_github_access_error(B):return B
	return _github_repo_access_message(repo_slug=_github_repo_slug(A),remote_url=A,retry_arg=None,target_env_name=env_name)
def _is_github_remote(remote_url:str|None)->bool:A=remote_url;return bool(A and A.lower().startswith('https://github.com/'))
def _build_entries(raw_vars:list[RawEnvVar])->list[EnvVarEntry]:return[EnvVarEntry(key=A.key,value=A.value,source_path=A.source_path,is_secret=classify(A.key,A.value))for A in raw_vars]
def _review_entries(entries:list[EnvVarEntry])->list[EnvVarEntry]:
	A=entries;B=_detect_editor();D=f"Edit in {B}? (flip classifications or drop entries)"if B else'Edit interactively? (flip classifications)'
	if not click.confirm(D,default=False):return A
	if B is None:return _flip_loop(A)
	C=_editor_review(A)
	if C is not None:return C
	click.echo(f"{B} returned nothing — falling back to interactive flip.");return _flip_loop(A)
def _detect_editor()->str|None:
	try:from click._termui_impl import Editor as B;A=B().get_editor()
	except Exception:return
	if not A:return
	return A.split()[0]
_REVIEW_LINE_RE=re.compile('^\\[(?P<marker>[SPXspx])\\]\\s*\\|\\s*(?P<key>[^|]+?)\\s*\\|\\s*(?P<source>[^|]+?)\\s*(?:\\|.*)?$')
def _render_review_doc(entries:list[EnvVarEntry])->str:A=entries;B=['# Edit markers to classify each env var:','#   [S] secret  — masked below; encrypted at rest','#   [P] plain   — shown below; encrypted at rest too','#   [X] exclude — drop this var (or just delete the line)','#','# Fields: marker | key | source | value preview','# Save and exit to apply. Abort the editor to keep the original list.',''];C=max((len(A.key)for A in A),default=1);D=max((len(A.source_path)for A in A),default=1);E=['[{m}] | {k} | {s} | {v}'.format(m='S'if A.is_secret else'P',k=A.key.ljust(C),s=A.source_path.ljust(D),v=_preview_value(A.value,A.is_secret))for A in A];return'\n'.join(B+E)+'\n'
def _parse_review_doc(doc:str,entries:list[EnvVarEntry])->list[EnvVarEntry]:
	E=entries;H={(A.key,A.source_path):A for A in E};C:dict[tuple[str,str],EnvVarEntry]={}
	for I in doc.splitlines():
		D=I.strip()
		if not D or D.startswith('#'):continue
		A=_REVIEW_LINE_RE.match(D)
		if not A:continue
		F=A.group('marker').upper();G=A.group('key').strip(),A.group('source').strip();B=H.get(G)
		if B is None or F=='X':continue
		C[G]=EnvVarEntry(key=B.key,value=B.value,source_path=B.source_path,is_secret=F=='S')
	return[C[A.key,A.source_path]for A in E if(A.key,A.source_path)in C]
def _editor_review(entries:list[EnvVarEntry])->list[EnvVarEntry]|None:
	A=entries;C=_render_review_doc(A)
	try:B=click.edit(C,require_save=True,extension='.gv-env')
	except click.UsageError:return
	if B is None:return A
	return _parse_review_doc(B,A)
def _flip_loop(entries:list[EnvVarEntry])->list[EnvVarEntry]:
	D=entries;F=Counter(A.key for A in D);E={A for(A,B)in F.items()if B>1};B={_flip_identifier(A,include_source=A.key in E):A for A in D}
	while True:
		A=click.prompt('Enter a key to flip (use KEY@source for duplicates; blank to finish)',default='',show_default=False).strip()
		if not A:break
		if A not in B:click.echo(f"Unknown key: {A}");continue
		C=B[A];B[A]=EnvVarEntry(key=C.key,value=C.value,source_path=C.source_path,is_secret=not C.is_secret);G='S'if B[A].is_secret else'P';click.echo(f"  {A} -> {G}")
	return[B[_flip_identifier(A,include_source=A.key in E)]for A in D]
def _flip_identifier(entry:EnvVarEntry,*,include_source:bool)->str:
	A=entry
	if include_source:return f"{A.key}@{A.source_path}"
	return A.key
def _build_outcome(*,repo_name:str,git_info:GitInfo,entries:list[EnvVarEntry],skipped_env:bool,local_only:bool,target_env_name:str|None,target_env_url:str|None,target_env_vm_user:str|None,target_env_opencode_username:str|None,target_env_opencode_password:str|None)->RepoAddOutcome:D=target_env_vm_user;C=target_env_url;B=repo_name;A=entries;E=sorted({A.source_path for A in A});F=sum(1 for A in A if A.is_secret);return RepoAddOutcome(exit_code=0,repo_name=B,target_env_name=target_env_name,target_env_url=C,target_env_vm_user=D,target_env_opencode_username=target_env_opencode_username,target_env_opencode_password=target_env_opencode_password,opencode_session_url=build_opencode_session_url(C,D,B),git_remote_url=git_info.remote_url,env_captured=len(A),secrets_captured=F,env_sources=E,skipped_env=skipped_env,dry_run=local_only)
def _apply_sync_state(outcome:RepoAddOutcome,repo:RepoRef)->None:
	B=repo;A=outcome;A.sync_status=B.sync_status;A.sync_step=B.sync_step
	if B.opencode_session_id:A.opencode_session_id=B.opencode_session_id;A.opencode_session_url=build_opencode_session_url(A.target_env_url,A.target_env_vm_user,A.repo_name,B.opencode_session_id,workspace_name='onboarding')
	if B.sync_status=='failed'and B.sync_error_message:A.backend_sync_error=_format_repo_setup_error(B.sync_error_message,remote_url=A.git_remote_url,env_name=A.target_env_name);A.exit_code=1
def _refresh_opencode_login(outcome:RepoAddOutcome)->None:
	A=outcome
	if A.dry_run or A.exit_code!=0 or not A.opencode_session_url or not A.target_env_url or not A.target_env_opencode_username or not A.target_env_opencode_password:return
	B=_redirect_path_from_url(A.opencode_session_url)
	try:A.opencode_login_url=_create_opencode_magic_login_url(env_url=A.target_env_url,username=A.target_env_opencode_username,password=A.target_env_opencode_password,redirect=B)
	except RuntimeError as C:A.opencode_login_error=str(C)
def _redirect_path_from_url(url:str)->str:
	A=urlparse(url);B=A.path or'/'
	if A.query:B=f"{B}?{A.query}"
	if A.fragment:B=f"{B}#{A.fragment}"
	return B
def _create_opencode_magic_login_url(*,env_url:str,username:str,password:str,redirect:str)->str:
	D=f"{username}:{password}";E=base64.b64encode(D.encode('utf-8')).decode('ascii');F=json.dumps({'redirect':redirect}).encode('utf-8');G=request.Request(f"{env_url.rstrip("/")}/auth/magic",method='POST',data=F,headers={'Authorization':f"Basic {E}",'Content-Type':'application/json','Accept':'application/json'})
	try:
		with request.urlopen(G,timeout=30)as H:I=json.loads(H.read().decode('utf-8'))
	except error.HTTPError as A:C=A.read().decode('utf-8',errors='replace').strip();J=f": {C}"if C else'';raise RuntimeError(f"GV Code magic login failed with HTTP {A.code}{J}")from A
	except(error.URLError,TimeoutError,json.JSONDecodeError)as A:raise RuntimeError(f"GV Code magic login failed: {A}")from A
	B=I.get('url')
	if not isinstance(B,str)or not B:raise RuntimeError('GV Code returned an invalid magic login response')
	return B
def _poll_repo_sync(outcome:RepoAddOutcome,repo_id:str,*,timeout_seconds:float=8.,interval_seconds:float=1.)->None:
	A=outcome
	if A.backend_sync_error:return
	if A.sync_status in{'ready','failed'}:return
	C=time.monotonic()+timeout_seconds
	while time.monotonic()<C:
		time.sleep(interval_seconds);D=get_json(f"/v1/repos/{repo_id}");B=D.get('repo')
		if not isinstance(B,dict):break
		E=RepoRef.from_payload(B);_apply_sync_state(A,E)
		if A.sync_status in{'ready','failed'}:return
def _print_outcome(outcome:RepoAddOutcome)->None:
	A=outcome;click.echo('');click.echo(f"Repo: {A.repo_name}")
	if A.target_env_name:click.echo(f"Target env: {A.target_env_name}")
	if A.opencode_session_url:
		if A.opencode_login_url:click.echo(f"GV Code login: {A.opencode_login_url}");click.echo('Opens the repo workspace and signs you in.');click.echo('Continue in GV Code to start working.');click.echo('If this link expires, run `gv info --qr` for a new one.')
		elif A.dry_run:click.echo(f"GV Code: {A.opencode_session_url}")
		else:
			for B in format_opencode_hints(A.opencode_session_url,A.repo_name,has_session_id=bool(A.opencode_session_id)):click.echo(B)
			if A.opencode_login_error:click.echo(f"Magic login was unavailable: {A.opencode_login_error}",err=True);click.echo('If GV Code asks you to sign in, run `gv info --qr` for a one-time login link.',err=True)
	if A.git_remote_url:click.echo(f"Remote: {A.git_remote_url}")
	if A.skipped_env:click.echo('Env capture: skipped')
	else:
		click.echo(f"Env captured: {A.env_captured} ({A.secrets_captured} secret, {A.env_captured-A.secrets_captured} plain)")
		if A.env_sources:click.echo(f"Sources: {", ".join(A.env_sources)}")
	if A.dry_run:click.echo('Mode: --dry-run (nothing saved)')
	elif A.backend_sync_error:click.echo(f"Repo setup failed: {A.backend_sync_error}",err=True)
	else:click.echo('Repo setup: ok')
	if A.sync_status:
		click.echo(f"Cloud workspace: {format_sync_status(A.sync_status,A.sync_step)}")
		if A.sync_status not in{'ready','failed'}:click.echo('Cloud setup is still running. You do not need to wait.');click.echo('Check progress later with `gv repo list`.')