from __future__ import annotations
import contextlib,os,shutil,subprocess,sys,webbrowser
from dataclasses import dataclass
@dataclass(frozen=True)
class BrowserLaunchResult:opened:bool;attempted:bool
def is_wsl_environment()->bool:
	if os.environ.get('WSL_DISTRO_NAME')or os.environ.get('WSL_INTEROP'):return True
	try:
		with open('/proc/version',encoding='utf-8')as B:A=B.read().lower()
	except OSError:return False
	return'microsoft'in A or'wsl'in A
def has_graphical_browser_hint()->bool:return bool(os.environ.get('DISPLAY')or os.environ.get('WAYLAND_DISPLAY')or os.environ.get('BROWSER'))
def browser_launcher_command()->list[str]|None:
	if sys.platform=='darwin':A=shutil.which('open');return[A]if A else None
	if sys.platform.startswith('linux'):
		if is_wsl_environment():
			for B in('wslview','wsl-open'):
				A=shutil.which(B)
				if A:return[A]
			if not has_graphical_browser_hint():return
		if not has_graphical_browser_hint():return
		A=shutil.which('xdg-open');return[A]if A else None
@contextlib.contextmanager
def suppress_process_stderr():
	with open(os.devnull,'w',encoding='utf-8')as B:
		A=os.dup(2)
		try:os.dup2(B.fileno(),2);yield
		finally:os.dup2(A,2);os.close(A)
def open_url(url:str)->BrowserLaunchResult:
	A=browser_launcher_command()
	if A is None:
		if sys.platform.startswith('win')or os.name=='nt'or os.environ.get('BROWSER'):
			with suppress_process_stderr():
				try:return BrowserLaunchResult(opened=webbrowser.open(url),attempted=True)
				except webbrowser.Error:return BrowserLaunchResult(opened=False,attempted=True)
		return BrowserLaunchResult(opened=False,attempted=False)
	try:B=subprocess.run([*A,url],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=10,check=False)
	except(OSError,subprocess.TimeoutExpired):return BrowserLaunchResult(opened=False,attempted=True)
	return BrowserLaunchResult(opened=B.returncode==0,attempted=True)