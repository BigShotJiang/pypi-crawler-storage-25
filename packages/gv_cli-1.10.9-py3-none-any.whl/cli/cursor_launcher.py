from __future__ import annotations
import asyncio,os,shutil,subprocess,sys
from pathlib import Path
from typing import Protocol
import httpx
from.import opencode_launcher,remote_workspaces,ssh_access
REMOTE_SSH_EXTENSIONS=frozenset({'anysphere.remote-ssh','ms-vscode-remote.remote-ssh'})
class EnvLike(Protocol):id:str;name:str;url:str|None;opencode_username:str;opencode_password:str
def handle_cursor(env:EnvLike,ssh_details:ssh_access.EnvSshAccess)->int:
	A=env;D=ensure_local_cursor_ready();opencode_launcher.validate_env_supports_attach(A)
	try:B=asyncio.run(remote_workspaces.discover_workspace_records(A))
	except httpx.HTTPError as C:raise RuntimeError(f"Failed to query remote GV Code: {C}")from C
	if not B:raise RuntimeError('GV Code has no known projects in this environment yet. Open the web UI first to initialize one.')
	E=remote_workspaces.choose_workspace_record(A.name,B);F=ssh_access.install_ssh_config_entry(A.id,A.name,ssh_details);exec_cursor(D,F,E.directory);return 0
def ensure_local_cursor_ready()->str:
	A=_resolve_local_cursor_path()
	if not A:raise RuntimeError("Cursor CLI (`cursor`) is not installed locally or not on PATH. Install Cursor and, on macOS, run `Shell Command: Install 'cursor' command in PATH`.")
	_run_local_cursor_command(A,'--version');B=_run_local_cursor_command(A,'--list-extensions');C={A.strip()for A in B.stdout.splitlines()if A.strip()}
	if not C.intersection(REMOTE_SSH_EXTENSIONS):raise RuntimeError('Cursor Remote SSH is required locally. Install it with `cursor --install-extension ms-vscode-remote.remote-ssh`.')
	return A
def exec_cursor(cursor_path:str,ssh_alias:str,directory:str)->None:A=[cursor_path,'--remote',f"ssh-remote+{ssh_alias}",directory];os.execvpe(A[0],A,os.environ.copy())
def _run_local_cursor_command(cursor_path:str,*G:str)->subprocess.CompletedProcess[str]:
	B=cursor_path;D=[B,*G]
	try:A=subprocess.run(D,check=False,capture_output=True,text=True,timeout=15)
	except OSError as C:raise RuntimeError(f"Cursor CLI at `{B}` could not be executed: {C}.")from C
	except subprocess.TimeoutExpired as C:E=' '.join(D[1:]);raise RuntimeError(f"Cursor CLI at `{B}` did not respond to `cursor {E}`.")from C
	if A.returncode==0:return A
	H=f"signal {-A.returncode}"if A.returncode<0 else f"exit code {A.returncode}";F=(A.stderr or A.stdout).strip();I=f" {F}"if F else'';E=' '.join(D[1:]);raise RuntimeError(f"Cursor CLI at `{B}` failed to run `cursor {E}` ({H}).{I}")
def _resolve_local_cursor_path()->str|None:
	A=shutil.which('cursor')
	if A:return A
	if sys.platform!='darwin':return
	for B in _macos_cursor_candidates():
		if B.is_file():return str(B)
def _macos_cursor_candidates()->tuple[Path,...]:return Path('/Applications/Cursor.app/Contents/Resources/app/bin/cursor'),Path.home()/'Applications/Cursor.app/Contents/Resources/app/bin/cursor'