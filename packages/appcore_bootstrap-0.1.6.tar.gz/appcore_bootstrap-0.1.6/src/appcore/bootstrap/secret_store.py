"""Secret blob loading and cached secret access."""

from __future__ import annotations

import copy
from typing import Any

import yaml
from appcore.common import exceptions as common_exceptions
from appcore.config import config_manager, settings_models
from appcore.crypto import crypto
from appcore.key_provider import secret_provider


class SecretStore:
    """In-memory cache of resolved plaintext secret values."""

    def __init__(self, data: dict[str, Any]) -> None:
        """Store a defensive copy of the resolved secret mapping."""
        self._data = copy.deepcopy(data)

    @classmethod
    def load(
        cls,
        provider: secret_provider.SecretBlobProvider,
        crypto_service: crypto.CryptoService,
    ) -> SecretStore:
        """Load, decrypt, merge, and cache secret blobs."""
        base_data = cls._parse_blob(provider.get_base_blob(), crypto_service)
        override_blob = provider.get_override_blob()
        override_data = (
            cls._parse_blob(override_blob, crypto_service) if override_blob is not None else {}
        )
        merged = config_manager.deep_merge(base_data, override_data)
        return cls(cls._resolve_encrypted_values(merged, crypto_service))

    def get(self, key: str, default: Any = None) -> Any:
        """Return a cached secret using dot-notation lookup."""
        current: Any = self._data
        for part in key.split("."):
            if not isinstance(current, dict) or part not in current:
                return default
            current = current[part]
        return copy.deepcopy(current)

    def get_str(self, key: str, default: str = "") -> str:
        """Return a cached string secret."""
        value = self.get(key, default)
        return value if isinstance(value, str) else str(value)

    def get_section(self, prefix: str) -> dict[str, Any]:
        """Return a cached secret subsection using dot-notation lookup."""
        value = self.get(prefix, {})
        return value if isinstance(value, dict) else {}

    def as_dict(self) -> dict[str, Any]:
        """Return a defensive copy of the cached secret mapping."""
        return copy.deepcopy(self._data)

    @staticmethod
    def _parse_blob(blob: str, crypto_service: crypto.CryptoService) -> dict[str, Any]:
        """Decrypt and parse one secret blob."""
        plaintext = crypto_service.decrypt_if_encrypted(blob)
        try:
            parsed = yaml.safe_load(plaintext) or {}
        except yaml.YAMLError as exc:
            raise common_exceptions.ConfigurationError(
                f"Failed to parse decrypted secret blob YAML: {exc}"
            ) from exc
        if not isinstance(parsed, dict):
            raise common_exceptions.ConfigurationError(
                "Decrypted secret blob must contain a YAML mapping"
            )
        return parsed

    @classmethod
    def _resolve_encrypted_values(
        cls,
        value: Any,
        crypto_service: crypto.CryptoService,
    ) -> Any:
        """Recursively decrypt any ENC(...) values within the parsed secret mapping."""
        if isinstance(value, dict):
            return {
                key: cls._resolve_encrypted_values(item, crypto_service)
                for key, item in value.items()
            }
        if isinstance(value, list):
            return [cls._resolve_encrypted_values(item, crypto_service) for item in value]
        if isinstance(value, str):
            return crypto_service.decrypt_if_encrypted(value)
        return value


def build_resolved_settings(
    config: config_manager.ConfigManager,
    secrets: SecretStore,
) -> settings_models.AppSettings:
    """Merge cached secrets onto the base config and validate the final settings."""
    merged = config_manager.deep_merge(config.raw, secrets.as_dict())
    return settings_models.AppSettings.model_validate(merged)
