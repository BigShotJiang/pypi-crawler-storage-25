"""Application context container for initialized services."""

from __future__ import annotations

import logging
from dataclasses import dataclass

from appcore.bootstrap.secret_store import SecretStore
from appcore.config import config_manager
from appcore.crypto import crypto
from appcore.database import db_manager
from appcore.email_ import email_client


@dataclass(frozen=True)
class AppContext:
    """Immutable application service container."""

    environment: str
    config: config_manager.ConfigManager
    logger: logging.Logger
    crypto: crypto.CryptoService
    secrets: SecretStore
    email: email_client.EmailClient
    db: db_manager.DatabaseManager


ctx: AppContext | None = None
