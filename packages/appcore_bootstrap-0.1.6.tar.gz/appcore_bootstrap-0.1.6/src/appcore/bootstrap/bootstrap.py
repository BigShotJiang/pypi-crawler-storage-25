"""Bootstrap entrypoint for wiring all appcore services together."""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import NoReturn

from appcore.bootstrap import app_context
from appcore.bootstrap import app_context as app_context_module
from appcore.bootstrap.secret_store import SecretStore, build_resolved_settings
from appcore.common import exceptions as common_exceptions
from appcore.config import config_manager
from appcore.crypto import crypto
from appcore.database import configure_manager, connection_config, db_manager
from appcore.email_ import email_client
from appcore.key_provider import key_provider, secret_provider
from appcore.logging_ import logger_factory


def startup(config_dir: Path = Path("config")) -> app_context.AppContext:
    """Initialize all configured services and publish the global context."""
    try:
        environment = config_manager.resolve_environment()
    except Exception as exc:
        _abort("resolve_environment", exc)

    try:
        config = config_manager.ConfigManager(environment, config_dir)
    except Exception as exc:
        _abort("config", exc)

    try:
        logger = logger_factory.LoggerFactory.create(config.settings.logging)
    except Exception as exc:
        _abort("logging", exc)

    try:
        provider = key_provider.KeyProviderFactory.create(config.settings.security.master_key)
    except Exception as exc:
        _abort("key_provider", exc)

    try:
        crypto_service = crypto.CryptoService(
            provider=provider,
            salt=config.settings.security.crypto.salt.encode("utf-8"),
        )
    except Exception as exc:
        _abort("crypto", exc)

    try:
        blob_provider = secret_provider.SecretBlobProviderFactory.create(
            config.settings.security.secrets,
            environment=environment,
            root_dir=config_dir.parent,
        )
        secrets = SecretStore.load(blob_provider, crypto_service)
        resolved_settings = build_resolved_settings(config, secrets)
        config.replace_settings(resolved_settings)
    except Exception as exc:
        _abort("secrets", exc)

    try:
        default_connection_string: str | None = None
        connection_configs: list[connection_config.ConnectionConfig] = []
        for name, connection in resolved_settings.database.connections.items():
            connection_configs.append(
                connection_config.ConnectionConfig(
                    name=name,
                    dialect=connection.dialect,
                    encrypted_connection_string=connection.encrypted_connection_string,
                    pool_size=connection.pool_size,
                    max_overflow=connection.max_overflow,
                    pool_timeout=connection.pool_timeout,
                    echo=connection.echo,
                )
            )
            if name == resolved_settings.database.default:
                default_connection_string = crypto_service.decrypt_if_encrypted(
                    connection.encrypted_connection_string
                )
        db = db_manager.DatabaseManager(
            configs=connection_configs,
            crypto_service=crypto_service,
            default_name=resolved_settings.database.default,
        )
        configure_manager(db)
        if default_connection_string is not None:
            os.environ["DATABASE_URL"] = default_connection_string
    except Exception as exc:
        _abort("database", exc)

    try:
        if any(sink.type == "database" for sink in resolved_settings.logging.sinks):
            database_sink = next(
                sink for sink in resolved_settings.logging.sinks if sink.type == "database"
            )
            logger = logger_factory.LoggerFactory.create(
                resolved_settings.logging,
                db_engine=db.get_engine(database_sink.connection_name),
            )
    except Exception as exc:
        _abort("logging_database_sink", exc)

    try:
        email = email_client.EmailClient.from_config(resolved_settings.email, crypto_service)
    except Exception as exc:
        _abort("email", exc)

    context = app_context.AppContext(
        environment=environment,
        config=config,
        logger=logger,
        crypto=crypto_service,
        secrets=secrets,
        email=email,
        db=db,
    )
    app_context_module.ctx = context
    return context


def _abort(step: str, cause: Exception) -> NoReturn:
    """Convert failures into BootstrapError and exit the process."""
    error = common_exceptions.BootstrapError(step, cause)
    print(str(error), file=sys.stderr)
    raise SystemExit(1)
