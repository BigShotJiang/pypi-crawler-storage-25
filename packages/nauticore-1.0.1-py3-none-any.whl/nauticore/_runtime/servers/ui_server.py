from __future__ import annotations

import importlib
import logging
from pathlib import Path
from typing import Any


logger = logging.getLogger(__name__)


def _default_dist_dir() -> Path:
    return Path(__file__).resolve().parent.parent.parent / "frontend_dist"


DEFAULT_DIST_DIR = _default_dist_dir()


def create_app(dist_dir: str | Path | None = None) -> Any:
    fastapi = importlib.import_module("fastapi")
    responses = importlib.import_module("fastapi.responses")
    FastAPI = getattr(fastapi, "FastAPI")
    HTTPException = getattr(fastapi, "HTTPException")
    FileResponse = getattr(responses, "FileResponse")
    PlainTextResponse = getattr(responses, "PlainTextResponse")

    resolved_dist_dir = Path(dist_dir) if dist_dir else DEFAULT_DIST_DIR
    resolved_dist_dir = resolved_dist_dir.resolve()
    index_path = resolved_dist_dir / "index.html"

    app = FastAPI()

    @app.get("/health")
    async def health_check() -> dict[str, str]:
        status = "ready" if resolved_dist_dir.exists() else "missing"
        return {"status": status, "dist_dir": str(resolved_dist_dir)}

    @app.get("/{requested_path:path}")
    async def serve(requested_path: str) -> Any:
        normalized_path = requested_path.strip("/")
        if not normalized_path:
            if index_path.exists():
                return FileResponse(index_path)
            return PlainTextResponse("frontend_dist/index.html not found", status_code=404)

        candidate = (resolved_dist_dir / normalized_path).resolve()
        if resolved_dist_dir not in candidate.parents and candidate != resolved_dist_dir:
            raise HTTPException(status_code=403, detail="Forbidden")

        if candidate.is_file():
            return FileResponse(candidate)

        if index_path.exists():
            return FileResponse(index_path)

        raise HTTPException(status_code=404, detail="Not Found")

    logger.info("UI server configured for dist dir: %s", resolved_dist_dir)
    return app
