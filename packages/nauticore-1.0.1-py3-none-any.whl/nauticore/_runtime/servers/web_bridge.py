from __future__ import annotations

import asyncio
import json
import logging
import threading
from typing import List, Dict, Any
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, Response
from ...communication import Frontend
from ...utils import sys_logger
from ...utils.data_logger import DataLogger


DEBUG_WS = False

logger = logging.getLogger(__name__)
if DEBUG_WS:
    logger.setLevel(logging.DEBUG)


class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []
        self.loop = None

    def set_loop(self, loop):
        self.loop = loop

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)
        try:
            peer = websocket.client
            logger.info("WS connected: %s", peer)
        except Exception:
            logger.info("WS connected")
        sys_logger.event("WS_CONNECT")

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)
        try:
            peer = websocket.client
            logger.info("WS disconnected: %s", peer)
        except Exception:
            logger.info("WS disconnected")
        sys_logger.event("WS_DISCONNECT")

    async def broadcast(self, message: str):
        connections_to_remove = []
        for connection in self.active_connections:
            try:
                await connection.send_text(message)
            except Exception:
                connections_to_remove.append(connection)

        for connection in connections_to_remove:
            if connection in self.active_connections:
                self.active_connections.remove(connection)
                try:
                    peer = connection.client
                    logger.warning("WS disconnected (during broadcast): %s", peer)
                except Exception:
                    logger.warning("WS disconnected (during broadcast)")

    def broadcast_sync(self, message_dict: dict):
        if not self.loop:
            return
        if not self.active_connections:
            return

        try:
            msg_str = json.dumps(message_dict)
            asyncio.run_coroutine_threadsafe(self.broadcast(msg_str), self.loop)
        except RuntimeError as e:
            logger.error("Broadcast sync error: %s", e)
        except Exception as e:
            logger.error("Broadcast sync error: %s", e)


class WebBridge:
    def __init__(self, mur_app: Frontend):
        self.mur = mur_app
        self.app = FastAPI()
        self.manager = ConnectionManager()
        self.subscribed_topics = set()
        self.data_logger = DataLogger()

        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=False,
            allow_methods=["*"],
            allow_headers=["*"],
        )

        self.app.get("/")(self.root)

        self.app.websocket("/ws")(self.websocket_endpoint)

        self.app.post("/recording/start")(self.recording_start)
        self.app.post("/recording/stop")(self.recording_stop)
        self.app.get("/recording/status")(self.recording_status)
        self.app.get("/recordings")(self.recordings_list)
        self.app.get("/recordings/{session_id}")(self.recordings_get)
        self.app.get("/recordings/{session_id}/download")(self.recordings_download)
        self.app.delete("/recordings/{session_id}")(self.recordings_delete)

        self.app.add_event_handler("startup", self.startup_event)
        self.app.add_event_handler("shutdown", self.shutdown_event)

    async def root(self):
        return {"message": "MUR Web Bridge is running"}

    async def startup_event(self):
        logger.info("Starting MUR Frontend in background...")
        sys_logger.event("WEB_BRIDGE_START")
        self.manager.set_loop(asyncio.get_running_loop())

        self.mur.running = True

        t_listen = threading.Thread(target=self.mur._listen_loop)
        t_listen.daemon = True
        t_listen.start()

        self.mur.register()
        await asyncio.sleep(0.5)

        t_timer = threading.Thread(target=self.mur._timer_loop)
        t_timer.daemon = True
        t_timer.start()

    async def shutdown_event(self):
        logger.info("Shutting down MUR Frontend...")
        sys_logger.event("WEB_BRIDGE_STOP")
        if self.data_logger.active:
            self.data_logger.stop()
        self.mur.shutdown()

    def _create_ros_to_web_callback(self, topic):
        def callback(msg_data):
            self.data_logger.log_rx(topic, msg_data)
            payload = {
                "type": "topic_msg",
                "topic": topic,
                "data": msg_data
            }
            self.manager.broadcast_sync(payload)
        return callback

    def _ensure_subscribed(self, topic: str):
        if topic in self.subscribed_topics:
            return
        self.mur.msg_routes[topic] = self._create_ros_to_web_callback(topic)
        self.subscribed_topics.add(topic)
        logger.info("Bridge subscribed to %s", topic)
        sys_logger.event("TOPIC_SUBSCRIBE", topic)

    async def handle_client_message(self, websocket: WebSocket, data: dict):
        cmd = data.get("op")

        if cmd == "publish":
            topic = data.get('topic')
            msg_type = data.get('type')
            msg_data = data.get('msg')
            logger.debug("WS publish -> %s (%s)", topic, msg_type)
            self.data_logger.log_tx(topic, msg_type, msg_data)
            try:
                loop = asyncio.get_running_loop()
                await loop.run_in_executor(
                    None,
                    self.mur.publish,
                    topic,
                    msg_type,
                    msg_data
                )
            except Exception as e:
                logger.error("Publish error: %s", e)
                sys_logger.error("TOPIC_PUBLISH", f"{topic}: {e}")

        elif cmd == "subscribe":
            topic = data['topic']
            if topic in self.subscribed_topics:
                logger.debug("Bridge already subscribed to %s", topic)
            else:
                self._ensure_subscribed(topic)

        elif cmd == "call_service":
            service_name = data['service']
            service_type = data['type']
            service_args = data.get('args', {})
            sys_logger.event("SERVICE_CALL", service_name)
            loop = asyncio.get_running_loop()
            try:
                response = await loop.run_in_executor(
                    None,
                    self.mur.call_service,
                    service_name,
                    service_type,
                    service_args
                )
                await websocket.send_json({
                    "type": "service_response",
                    "req_id": data.get("req_id"),
                    "data": response,
                    "status": "success"
                })
            except Exception as e:
                sys_logger.error("SERVICE_CALL", f"{service_name}: {e}")
                await websocket.send_json({
                    "type": "service_response",
                    "req_id": data.get("req_id"),
                    "error": str(e),
                    "status": "error"
                })

    async def websocket_endpoint(self, websocket: WebSocket):
        await self.manager.connect(websocket)
        self._ensure_subscribed("/imu/imu_data")
        self._ensure_subscribed("/depth/depth_data")
        try:
            while True:
                try:
                    text = await websocket.receive_text()
                except Exception as e:
                    logger.warning("WS receive error: %s", e)
                    break

                logger.debug("WS recv: %s", text[:200])
                try:
                    data = json.loads(text)
                except Exception as e:
                    logger.warning("WS json error: %s", e)
                    continue

                try:
                    await self.handle_client_message(websocket, data)
                except Exception as e:
                    logger.error("WS handle error: %s", e)
        except WebSocketDisconnect:
            self.manager.disconnect(websocket)
        except Exception as e:
            logger.error("WebSocket Error: %s", e)
            self.manager.disconnect(websocket)

    async def recording_start(self, body: dict | None = None):
        body = body or {}
        if self.data_logger.active:
            return Response(
                json.dumps({"error": "Recording already in progress", "session_id": self.data_logger.session_id}),
                status_code=409,
                media_type="application/json"
            )
        result = self.data_logger.start(session_id=body.get("session_id"))
        if "error" in result:
            return Response(json.dumps(result), status_code=409, media_type="application/json")
        return result

    async def recording_stop(self):
        if not self.data_logger.active:
            return Response(
                json.dumps({"error": "No recording in progress"}),
                status_code=400,
                media_type="application/json"
            )
        return self.data_logger.stop()

    async def recording_status(self):
        return self.data_logger.status

    async def recordings_list(self):
        return self.data_logger.list_recordings()

    async def recordings_get(self, session_id: str):
        meta = self.data_logger.get_recording(session_id)
        if meta is None:
            return Response(
                json.dumps({"error": "Recording not found"}),
                status_code=404,
                media_type="application/json"
            )
        return meta

    async def recordings_download(self, session_id: str):
        session_dir = self.data_logger.data_dir / session_id
        if not session_dir.exists():
            return Response(
                json.dumps({"error": "Recording not found"}),
                status_code=404,
                media_type="application/json"
            )

        import zipfile
        import io
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            for name in ("data.jsonl", "recording_meta.json"):
                fpath = session_dir / name
                if fpath.exists():
                    zf.write(fpath, name)
        buf.seek(0)
        return Response(
            buf.getvalue(),
            media_type="application/zip",
            headers={"Content-Disposition": f"attachment; filename={session_id}.zip"}
        )

    async def recordings_delete(self, session_id: str):
        if self.data_logger.active and self.data_logger.session_id == session_id:
            return Response(
                json.dumps({"error": "Cannot delete active recording"}),
                status_code=409,
                media_type="application/json"
            )
        ok = self.data_logger.delete_recording(session_id)
        if not ok:
            return Response(
                json.dumps({"error": "Recording not found"}),
                status_code=404,
                media_type="application/json"
            )
        return {"status": "deleted", "session_id": session_id}


def create_app(server_ip, server_port, public_key):
    mur = Frontend(server_ip, server_port, public_key)
    bridge = WebBridge(mur)
    return bridge.app
