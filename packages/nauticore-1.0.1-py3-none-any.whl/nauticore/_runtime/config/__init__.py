"""Internal runtime configuration package for nauticore."""
