"""Internal bootstrap helpers for nauticore."""
