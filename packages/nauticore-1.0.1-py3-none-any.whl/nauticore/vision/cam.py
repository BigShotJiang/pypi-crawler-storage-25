import cv2
import logging
import threading
import time
import av
from contextlib import asynccontextmanager


logger = logging.getLogger(__name__)


class Camera:
    def __init__(self, video_source):
        self.video_source = video_source
        self.lock = threading.Lock()

        self.cond = threading.Condition()
        self.frame_seq = 0
        self.latest_frame = None

        self.raw_cond = threading.Condition()
        self.raw_seq = 0
        self.latest_raw_frame = None

        self._jpeg_quality = 50

        self._frame_callbacks = []
        self._frame_callbacks_lock = threading.Lock()

        self.container = None
        self.video_stream = None

        self._fail_count = 0
        self._last_reconnect_time = 0.0
        self._start_time = time.time()
        self._last_frame_time = 0.0

        self.running = True
        self._connect()

        self.thread_decode = threading.Thread(target=self._decode_loop, daemon=True)
        self.thread_encode = threading.Thread(target=self._encode_loop, daemon=True)
        self.thread_decode.start()
        self.thread_encode.start()

        self.watchdog_thread = threading.Thread(target=self._watchdog, daemon=True)
        self.watchdog_thread.start()

    def add_frame_callback(self, callback):
        with self._frame_callbacks_lock:
            self._frame_callbacks.append(callback)

    def remove_frame_callback(self, callback):
        with self._frame_callbacks_lock:
            try:
                self._frame_callbacks.remove(callback)
            except ValueError:
                pass

    def _dispatch_frame_callbacks(self, bgr_frame, seq):
        with self._frame_callbacks_lock:
            callbacks = list(self._frame_callbacks)
        for cb in callbacks:
            try:
                cb(bgr_frame, seq)
            except Exception:
                logger.exception("Frame callback error")

    def _connect(self):
        try:
            if self.container is not None:
                try:
                    self.container.close()
                except Exception:
                    pass

            options = {
                "rtsp_transport": "udp",
                "fflags": "nobuffer",
                "flags": "low_delay",
                "max_delay": "0",
                "stimeout": "5000000"
            }

            self.container = av.open(self.video_source, options=options)
            self.video_stream = self.container.streams.video[0]

            return True
        except Exception as e:
            logger.exception("连接流媒体失败")
            self.container = None
            self.video_stream = None
            return False

    def _watchdog(self):
        while self.running:
            if time.time() - self._start_time < 5.0:
                time.sleep(0.5)
                continue

            no_frame_for = time.time() - (self._last_frame_time or self._start_time)
            if no_frame_for > 5.0:
                logger.warning("看门狗报警：长时间未收到画面，准备重连...")
                self._reconnect()
            time.sleep(1.0)

    def _reconnect(self):
        now = time.time()
        if now - self._last_reconnect_time < 2.0:
            return
        self._last_reconnect_time = now

        with self.lock:
            self._connect()
        self._fail_count = 0
        self._last_frame_time = time.time()

    def _decode_loop(self):
        while self.running:
            if self.container is None or self.video_stream is None:
                self._fail_count += 1
                if self._fail_count >= 10:
                    self._reconnect()
                time.sleep(0.5)
                continue

            try:
                for frame in self.container.decode(self.video_stream):
                    if not self.running:
                        break

                    img = frame.to_ndarray(format="bgr24")

                    with self.raw_cond:
                        self.latest_raw_frame = img
                        self.raw_seq += 1
                        current_seq = self.raw_seq
                        self.raw_cond.notify_all()

                    self._dispatch_frame_callbacks(img, current_seq)
                    self._last_frame_time = time.time()
                    self._fail_count = 0

            except Exception as e:
                logger.exception("拉流异常")
                self._fail_count += 1
                if self._fail_count >= 3:
                    self._reconnect()
                time.sleep(0.5)

    def _encode_loop(self):
        encode_params = [int(cv2.IMWRITE_JPEG_QUALITY), int(self._jpeg_quality)]
        last_encoded_seq = -1

        while self.running:
            with self.raw_cond:
                if self.raw_seq <= last_encoded_seq:
                    self.raw_cond.wait(timeout=1.0)

                if self.raw_seq <= last_encoded_seq:
                    continue

                img = self.latest_raw_frame
                last_encoded_seq = self.raw_seq

            if img is None:
                continue

            ok, jpeg = cv2.imencode('.jpg', img, encode_params)
            if not ok:
                continue

            data = jpeg.tobytes()

            with self.cond:
                self.latest_frame = data
                self.frame_seq += 1
                self.cond.notify_all()

            time.sleep(0.002)

    def get_frame(self):
        return self.latest_frame

    def get_raw_frame(self):
        with self.raw_cond:
            return self.latest_raw_frame, self.raw_seq

    def get_frame_info(self):
        with self.cond:
            return {
                "frame_seq": self.frame_seq,
                "has_frame": self.latest_frame is not None,
            }

    def release(self):
        self.running = False
        if hasattr(self, "thread_decode") and self.thread_decode.is_alive():
            self.thread_decode.join(timeout=1.0)
        if hasattr(self, "thread_encode") and self.thread_encode.is_alive():
            self.thread_encode.join(timeout=1.0)
        if hasattr(self, "watchdog_thread") and self.watchdog_thread.is_alive():
            self.watchdog_thread.join(timeout=1.0)
        with self.lock:
            if self.container:
                self.container.close()
