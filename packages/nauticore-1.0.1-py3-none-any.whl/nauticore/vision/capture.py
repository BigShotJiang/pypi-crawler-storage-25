from __future__ import annotations

import json
import logging
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import cv2

from .cam import Camera
from ..utils import sys_logger

logger = logging.getLogger(__name__)

DEFAULT_CAPTURE_DIR = Path.cwd() / "data"
DEFAULT_QUALITY = 90
DEFAULT_MAX_FRAMES = 100000
DEFAULT_MAX_DURATION_S = 1800


class FrameCaptureManager:
    def __init__(self, camera: Camera, capture_dir: Path | None = None):
        self.camera = camera
        self.capture_dir = capture_dir or DEFAULT_CAPTURE_DIR
        self._active = False
        self._session_id: str | None = None
        self._cam_label: str = "cam1"
        self._session_dir: Path | None = None
        self._frames_dir: Path | None = None
        self._frame_count = 0
        self._total_size_bytes = 0
        self._start_ts: float = 0.0
        self._start_ts_ms: int = 0
        self._meta: dict[str, Any] = {}
        self._index_file = None
        self._lock = threading.Lock()
        self._callback = None
        self._write_queue = []
        self._writer_thread: threading.Thread | None = None
        self._writer_stop = threading.Event()
        self._flush_counter = 0

    @property
    def active(self) -> bool:
        return self._active

    @property
    def session_id(self) -> str | None:
        return self._session_id

    def start(
        self,
        session_id: str | None = None,
        cam_label: str = "cam1",
        quality: int = DEFAULT_QUALITY,
        max_frames: int = DEFAULT_MAX_FRAMES,
        max_duration_s: int = DEFAULT_MAX_DURATION_S,
    ) -> dict[str, Any]:
        with self._lock:
            if self._active:
                return {
                    "error": "Capture already in progress",
                    "session_id": self._session_id,
                }

            quality = max(1, min(100, quality))
            max_frames = max(1, min(500000, max_frames))
            max_duration_s = max(1, 86400 * 365)

            now = datetime.now()
            if session_id:
                self._session_id = session_id
            else:
                self._session_id = f"cap_{now.strftime('%Y%m%d_%H%M%S')}"

            self._cam_label = cam_label
            self._session_dir = self.capture_dir / self._session_id / "image"
            cam_display = f"Cam {cam_label[-1]}" if cam_label.startswith("cam") else cam_label
            self._frames_dir = self._session_dir / cam_display
            self._session_dir.mkdir(parents=True, exist_ok=True)
            self._frames_dir.mkdir(parents=True, exist_ok=True)

            self._frame_count = 0
            self._total_size_bytes = 0
            self._start_ts = time.time()
            self._start_ts_ms = int(time.time() * 1000)
            self._flush_counter = 0

            self._meta = {
                "session_id": self._session_id,
                "cam_label": cam_label,
                "jpeg_quality": quality,
                "max_frames": max_frames,
                "max_duration_s": max_duration_s,
                "start_ts": self._start_ts_ms,
                "start_iso": datetime.fromtimestamp(
                    self._start_ts_ms / 1000, tz=timezone.utc
                ).isoformat(),
            }

            index_path = self._frames_dir / "capture_index.jsonl"
            self._index_file = open(index_path, "w", encoding="utf-8")

            self._write_queue = []
            self._writer_stop.clear()
            self._writer_thread = threading.Thread(
                target=self._writer_loop,
                args=(quality, max_frames, max_duration_s),
                daemon=True,
            )
            self._writer_thread.start()

            self._callback = self._on_frame
            self.camera.add_frame_callback(self._callback)

            self._active = True

            sys_logger.capture_start(self._session_id, fps=0)
            logger.info(
                "Frame capture started: %s/%s (callback-driven, full stream)",
                self._session_id,
                cam_label,
            )

            return {
                "session_id": self._session_id,
                "cam_label": cam_label,
                "status": "capturing",
                "quality": quality,
            }

    def stop(self) -> dict[str, Any]:
        with self._lock:
            if not self._active:
                return {"error": "No capture in progress"}

            if self._callback:
                self.camera.remove_frame_callback(self._callback)
                self._callback = None

            self._writer_stop.set()
            if self._writer_thread and self._writer_thread.is_alive():
                self._writer_thread.join(timeout=10.0)

            self._active = False

            if self._index_file:
                self._index_file.close()
                self._index_file = None

            stop_ts_ms = int(time.time() * 1000)
            duration_s = time.time() - self._start_ts

            self._meta["stop_ts"] = stop_ts_ms
            self._meta["stop_iso"] = datetime.fromtimestamp(
                stop_ts_ms / 1000, tz=timezone.utc
            ).isoformat()
            self._meta["total_frames"] = self._frame_count
            self._meta["total_size_bytes"] = self._total_size_bytes
            self._meta["duration_s"] = round(duration_s, 2)
            if duration_s > 0 and self._frame_count > 0:
                self._meta["actual_fps"] = round(self._frame_count / duration_s, 2)

            meta_path = self._frames_dir / "capture_meta.json"
            with open(meta_path, "w", encoding="utf-8") as f:
                json.dump(self._meta, f, indent=2, ensure_ascii=False)

            camera_meta_path = self._session_dir / "CameraMeta.json"
            if camera_meta_path.exists():
                try:
                    with open(camera_meta_path, "r", encoding="utf-8") as f:
                        camera_meta = json.load(f)
                except Exception:
                    camera_meta = {}
            else:
                camera_meta = {"cameras": []}

            cam_display = f"Cam {self._cam_label[-1]}" if self._cam_label.startswith("cam") else self._cam_label
            cam_entry = {
                "label": cam_display,
                "cam_id": self._cam_label,
                "total_frames": self._frame_count,
                "total_size_bytes": self._total_size_bytes,
                "duration_s": round(duration_s, 2),
                "actual_fps": self._meta.get("actual_fps", 0),
                "start_iso": self._meta.get("start_iso", ""),
                "stop_iso": self._meta.get("stop_iso", ""),
            }

            replaced = False
            for i, c in enumerate(camera_meta["cameras"]):
                if c.get("cam_id") == self._cam_label:
                    camera_meta["cameras"][i] = cam_entry
                    replaced = True
                    break
            if not replaced:
                camera_meta["cameras"].append(cam_entry)

            with open(camera_meta_path, "w", encoding="utf-8") as f:
                json.dump(camera_meta, f, indent=2, ensure_ascii=False)

            sys_logger.capture_stop(self._session_id, self._frame_count)
            logger.info(
                "Frame capture stopped: %s/%s, %d frames, %.1fs",
                self._session_id,
                self._cam_label,
                self._frame_count,
                duration_s,
            )

            result = {
                "session_id": self._session_id,
                "cam_label": self._cam_label,
                "status": "stopped",
                "total_frames": self._frame_count,
                "total_size_bytes": self._total_size_bytes,
                "duration_s": round(duration_s, 2),
                "download_url": f"/capture/download?session_id={self._session_id}&cam_label={self._cam_label}",
            }

            self._session_id = None
            self._session_dir = None
            self._frames_dir = None
            self._writer_thread = None

            return result

    @property
    def status(self) -> dict[str, Any]:
        if not self._active:
            return {"active": False}

        elapsed = time.time() - self._start_ts
        return {
            "active": True,
            "session_id": self._session_id,
            "cam_label": self._cam_label,
            "captured_frames": self._frame_count,
            "elapsed_s": round(elapsed, 1),
            "estimated_size_bytes": self._total_size_bytes,
            "queue_depth": len(self._write_queue),
        }

    def _on_frame(self, bgr_frame, seq):
        if not self._active:
            return
        self._write_queue.append((bgr_frame, seq, int(time.time() * 1000)))

    def _writer_loop(self, quality: int, max_frames: int, max_duration_s: int):
        encode_params = [int(cv2.IMWRITE_JPEG_QUALITY), quality]

        while not self._writer_stop.is_set() or self._write_queue:
            if not self._write_queue:
                self._writer_stop.wait(timeout=0.05)
                continue

            bgr_frame, seq, ts_ms = self._write_queue.pop(0)

            try:
                filename = f"frame_{seq:06d}_{ts_ms}.jpg"
                filepath = self._frames_dir / filename

                ok, jpeg = cv2.imencode(".jpg", bgr_frame, encode_params)
                if ok:
                    jpeg_bytes = jpeg.tobytes()
                    filepath.write_bytes(jpeg_bytes)

                    size_bytes = len(jpeg_bytes)
                    self._frame_count += 1
                    self._total_size_bytes += size_bytes

                    index_entry = {
                        "seq": seq,
                        "ts": ts_ms,
                        "ts_iso": datetime.fromtimestamp(
                            ts_ms / 1000, tz=timezone.utc
                        ).isoformat(),
                        "file": filename,
                        "size_bytes": size_bytes,
                    }
                    self._index_file.write(
                        json.dumps(index_entry, ensure_ascii=False) + "\n"
                    )
                    self._flush_counter += 1
                    if self._flush_counter >= 30:
                        self._index_file.flush()
                        self._flush_counter = 0

            except Exception:
                logger.exception("Frame write error in writer loop")

            if self._frame_count >= max_frames:
                logger.info("Max frames reached: %d", max_frames)
                break

            elapsed_total = time.time() - self._start_ts
            if elapsed_total >= max_duration_s:
                logger.info("Max duration reached: %ds", max_duration_s)
                break

        if self._index_file:
            self._index_file.flush()

        if self._frame_count >= max_frames or (time.time() - self._start_ts) >= max_duration_s:
            self._active = False
