from __future__ import annotations

import json
import logging
import zipfile
from pathlib import Path
from typing import Any

import cv2

logger = logging.getLogger(__name__)


class VideoCompiler:
    @staticmethod
    def compile_mp4(cam_dir: Path, output_path: Path | None = None) -> Path | None:
        index_path = cam_dir / "capture_index.jsonl"
        if not index_path.exists():
            logger.error("capture_index.jsonl not found in %s", cam_dir)
            return None

        meta_path = cam_dir / "capture_meta.json"
        meta: dict[str, Any] = {}
        if meta_path.exists():
            with open(meta_path, "r", encoding="utf-8") as f:
                meta = json.load(f)

        entries: list[dict] = []
        with open(index_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        entries.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue

        if not entries:
            logger.warning("No frame entries found in %s", cam_dir)
            return None

        first_frame_path = cam_dir / entries[0]["file"]
        first_frame = cv2.imread(str(first_frame_path))
        if first_frame is None:
            logger.error("Cannot read first frame: %s", first_frame_path)
            return None

        height, width = first_frame.shape[:2]

        duration_s = 0.0
        if len(entries) >= 2:
            duration_s = (entries[-1]["ts"] - entries[0]["ts"]) / 1000.0
        fps = len(entries) / duration_s if duration_s > 0 else meta.get("actual_fps", 30.0)
        fps = max(1.0, min(120.0, fps))

        cam_label = meta.get("cam_label", cam_dir.name)
        session_id = meta.get("session_id", cam_dir.parent.name)
        if output_path is None:
            output_path = cam_dir / f"{session_id}_{cam_label}.mp4"

        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        writer = cv2.VideoWriter(str(output_path), fourcc, fps, (width, height))

        if not writer.isOpened():
            logger.error("Failed to open VideoWriter for %s", output_path)
            return None

        written = 0
        for entry in entries:
            frame_path = cam_dir / entry["file"]
            frame = cv2.imread(str(frame_path))
            if frame is not None:
                writer.write(frame)
                written += 1
            else:
                logger.warning("Skipping unreadable frame: %s", frame_path)

        writer.release()

        if meta_path.exists():
            with open(meta_path, "r", encoding="utf-8") as f:
                meta = json.load(f)
            meta["compile_output"] = output_path.name
            meta["compile_frames"] = written
            meta["compile_fps"] = round(fps, 2)
            with open(meta_path, "w", encoding="utf-8") as f:
                json.dump(meta, f, indent=2, ensure_ascii=False)

        logger.info("Compiled %d frames @ %.2f fps -> %s", written, fps, output_path)
        return output_path

    @staticmethod
    def compile_zip(cam_dir: Path, output_path: Path | None = None) -> Path | None:
        cam_label = cam_dir.name
        session_id = cam_dir.parent.name
        if output_path is None:
            output_path = cam_dir.parent / f"{session_id}_{cam_label}.zip"

        with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for item in sorted(cam_dir.iterdir()):
                if item.is_file():
                    zf.write(item, arcname=f"{session_id}/{cam_label}/{item.name}")

        logger.info("Zipped %s -> %s", cam_dir, output_path)
        return output_path
