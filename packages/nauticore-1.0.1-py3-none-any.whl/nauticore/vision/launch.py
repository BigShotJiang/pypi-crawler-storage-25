from __future__ import annotations

import argparse
import asyncio
import logging
import time
from contextlib import asynccontextmanager
from pathlib import Path

import uvicorn
from fastapi import FastAPI, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, StreamingResponse

from .cam import Camera
from .capture import FrameCaptureManager
from .compile import VideoCompiler


logger = logging.getLogger(__name__)
camera: Camera | None = None
capture_manager: FrameCaptureManager | None = None
cam_label: str = "cam1"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Launch the nauticore vision service.")
    parser.add_argument("--source", required=True, help="RTSP or camera source URI.")
    parser.add_argument("--host", default="0.0.0.0", help="Bind host for the vision service.")
    parser.add_argument("--port", type=int, default=8002, help="Bind port for the vision service.")
    parser.add_argument("--cam-label", default="cam1", help="Camera label for capture directory naming (cam1/cam2).")
    parser.add_argument("--access-log", action="store_true", help="Enable uvicorn access logs.")
    return parser.parse_args()


def create_app(video_source: str, label: str = "cam1") -> FastAPI:
    global camera, capture_manager, cam_label
    cam_label = label

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        global camera, capture_manager
        try:
            camera = Camera(video_source=video_source)
            capture_manager = FrameCaptureManager(camera=camera)
            logger.info("摄像头初始化成功 (%s)", cam_label)
        except Exception:
            logger.exception("摄像头初始化失败")
            camera = None
            capture_manager = None
        yield
        if capture_manager and capture_manager.active:
            capture_manager.stop()
        if camera:
            camera.release()
            logger.info("摄像头已释放")

    app = FastAPI(lifespan=lifespan)

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=False,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.get("/")
    async def index() -> HTMLResponse:
        html_content = """<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
  </head>
  <body style="margin:0;padding:0;background:#000;overflow:hidden;">
    <img src="/video_feed" alt="" style="width:100vw;height:100vh;object-fit:contain;display:block;" />
  </body>
</html>
"""
        return HTMLResponse(content=html_content)

    @app.get("/frame")
    async def get_frame() -> Response:
        global camera
        if camera is None:
            return Response("摄像头未初始化", status_code=500)

        frame_data = camera.get_frame()
        if frame_data is None:
            return Response("获取帧失败", status_code=500)

        return Response(
            content=frame_data,
            media_type="image/jpeg",
            headers={
                "Cache-Control": "no-cache, no-store, must-revalidate",
                "Pragma": "no-cache",
                "Expires": "0",
            },
        )

    @app.get("/video_feed")
    async def video_feed() -> StreamingResponse:
        async def generate():
            global camera
            last_seq = 0
            last_send_time = 0.0
            while True:
                try:
                    if not camera:
                        await asyncio.sleep(0.2)
                        continue

                    seq = camera.frame_seq
                    if seq <= last_seq:
                        await asyncio.sleep(0.01)
                        continue

                    with camera.cond:
                        seq = camera.frame_seq
                        frame = camera.latest_frame
                    now = time.time()

                    should_send = bool(frame) and (seq != last_seq or (now - last_send_time) > 1.0)
                    if should_send and frame:
                        last_seq = seq
                        last_send_time = now
                        payload = (
                            b"--frame\r\n"
                            b"Content-Type: image/jpeg\r\n"
                            + f"Content-Length: {len(frame)}\r\n\r\n".encode("ascii")
                            + frame
                            + b"\r\n"
                        )
                        yield payload
                    else:
                        await asyncio.sleep(0.01)
                except asyncio.CancelledError:
                    break
                except Exception:
                    logger.exception("视频流推送异常")
                    await asyncio.sleep(0.1)

        return StreamingResponse(
            generate(),
            media_type="multipart/x-mixed-replace;boundary=frame",
            headers={
                "Cache-Control": "no-cache, no-store, must-revalidate",
                "Pragma": "no-cache",
                "Expires": "0",
            },
        )

    @app.get("/health")
    async def health_check() -> dict[str, str]:
        global camera
        if camera and camera.container:
            return {"status": "healthy", "camera": "connected", "cam_label": cam_label}
        return {"status": "unhealthy", "camera": "disconnected", "cam_label": cam_label}

    # ── Frame Capture API ──────────────────────────────────────

    @app.post("/capture/start")
    async def capture_start(body: dict | None = None):
        global capture_manager, cam_label
        if capture_manager is None:
            return Response("摄像头未初始化", status_code=500)

        body = body or {}
        result = capture_manager.start(
            session_id=body.get("session_id"),
            cam_label=cam_label,
            quality=body.get("quality", 90),
            max_frames=body.get("max_frames", 100000),
            max_duration_s=body.get("max_duration_s", 1800),
        )

        if "error" in result:
            from fastapi import HTTPException
            raise HTTPException(status_code=409, detail=result)
        return result

    @app.post("/capture/stop")
    async def capture_stop():
        global capture_manager
        if capture_manager is None:
            return Response("摄像头未初始化", status_code=500)

        result = capture_manager.stop()
        if "error" in result:
            from fastapi import HTTPException
            raise HTTPException(status_code=404, detail=result)
        return result

    @app.get("/capture/status")
    async def capture_status():
        global capture_manager
        if capture_manager is None:
            return {"active": False, "camera": "uninitialized", "cam_label": cam_label}
        return capture_manager.status

    @app.get("/capture/download")
    async def capture_download(session_id: str, cam_label_arg: str = "", format: str = "mp4"):
        from fastapi import HTTPException

        captures_dir = capture_manager.capture_dir if capture_manager else FrameCaptureManager.DEFAULT_CAPTURE_DIR
        session_dir = captures_dir / session_id / "image"

        if not session_dir.exists() or not session_dir.is_dir():
            raise HTTPException(status_code=404, detail="Session not found")

        label = cam_label_arg or cam_label
        cam_display = f"Cam {label[-1]}" if label.startswith("cam") else label
        cam_dir = session_dir / cam_display

        if not cam_dir.exists() or not cam_dir.is_dir():
            raise HTTPException(status_code=404, detail=f"{label} directory not found in session")

        if format == "zip":
            zip_path = VideoCompiler.compile_zip(cam_dir)
            if zip_path is None:
                raise HTTPException(status_code=500, detail="ZIP compilation failed")
            return FileResponse(
                path=str(zip_path),
                filename=zip_path.name,
                media_type="application/zip",
            )

        mp4_path = VideoCompiler.compile_mp4(cam_dir)
        if mp4_path is None:
            raise HTTPException(status_code=500, detail="MP4 compilation failed")
        return FileResponse(
            path=str(mp4_path),
            filename=mp4_path.name,
            media_type="video/mp4",
        )

    return app


def main() -> None:
    args = parse_args()
    app = create_app(video_source=args.source, label=args.cam_label)
    uvicorn.run(
        app,
        host=args.host,
        port=args.port,
        workers=1,
        access_log=args.access_log,
    )


if __name__ == "__main__":
    main()
