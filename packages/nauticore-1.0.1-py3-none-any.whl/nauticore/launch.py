from __future__ import annotations

import argparse
import importlib
import json
import logging
import multiprocessing as mp
import signal
import socket
import time
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from .utils import sys_logger

logger = logging.getLogger(__name__)
processes: list[tuple[str, mp.Process | None]] = []
UI_HOST = "0.0.0.0"
UI_PORT = 9090
DEFAULT_VEHICLE_SUFFIX = ".veh"
DEFAULT_MANIFEST_PATH = "manifest.json"
DEFAULT_PUBLIC_KEY_PATH = "keys/public.pem"
DEFAULT_WEB_HOST = "0.0.0.0"
DEFAULT_WEB_PORT = 8000
DEFAULT_VISION_HOST = "0.0.0.0"


@dataclass(frozen=True)
class ServiceSpec:
    name: str
    target: Callable[..., None]
    kwargs: dict[str, Any]
    port: int


def configure_logging() -> None:
    logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s")


def import_uvicorn() -> Any:
    return importlib.import_module("uvicorn")


def get_backend_dir() -> Path:
    return Path(__file__).resolve().parent


def check_port_available(port: int) -> bool:
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        result = sock.connect_ex(("127.0.0.1", port))
        sock.close()
        return result != 0
    except Exception:
        return False


def run_web_service(
    ros_ip: str,
    ros_port: int,
    public_key: str | bytes,
    host: str = "0.0.0.0",
    port: int = 8000,
    access_log: bool = False,
) -> None:
    configure_logging()

    from ._runtime.servers.web_bridge import create_app

    app = create_app(server_ip=ros_ip, server_port=ros_port, public_key=public_key)
    uvicorn = import_uvicorn()
    uvicorn.run(app, host=host, port=port, workers=1, access_log=access_log)


def run_ui_service(
    access_log: bool = False,
) -> None:
    configure_logging()

    from ._runtime.servers.ui_server import create_app

    app = create_app()
    uvicorn = import_uvicorn()
    uvicorn.run(app, host=UI_HOST, port=UI_PORT, workers=1, access_log=access_log)


def run_vision_service(
    video_source: str,
    host: str = "0.0.0.0",
    port: int = 8002,
    cam_label: str = "cam1",
    access_log: bool = False,
) -> None:
    configure_logging()

    from .vision.launch import create_app

    app = create_app(video_source=video_source, label=cam_label)
    uvicorn = import_uvicorn()
    uvicorn.run(app, host=host, port=port, workers=1, access_log=access_log)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="MUR 系统上位机启动器")
    parser.add_argument("vehicle", help="vehicle 文件路径，例如 auv1.veh")
    return parser.parse_args()


def resolve_vehicle_path(vehicle: str) -> Path:
    vehicle_path = Path(vehicle).expanduser()
    if vehicle_path.exists():
        return vehicle_path

    if not vehicle_path.suffix:
        veh_path = vehicle_path.with_suffix(DEFAULT_VEHICLE_SUFFIX)
        if veh_path.exists():
            return veh_path

    raise FileNotFoundError(f"找不到 vehicle 描述文件: {vehicle}")


def load_vehicle_manifest(archive: zipfile.ZipFile) -> dict[str, Any]:
    try:
        manifest_bytes = archive.read(DEFAULT_MANIFEST_PATH)
    except KeyError as exc:
        raise ValueError(f"vehicle 描述文件缺少 {DEFAULT_MANIFEST_PATH}") from exc

    try:
        manifest = json.loads(manifest_bytes.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("manifest.json 不是有效的 UTF-8 JSON 文件") from exc

    if not isinstance(manifest, dict):
        raise ValueError("manifest.json 顶层必须是对象")

    return manifest


def get_required_mapping(container: dict[str, Any], key: str, context: str) -> dict[str, Any]:
    value = container.get(key)
    if not isinstance(value, dict):
        raise ValueError(f"{context} 缺少对象字段 {key}")
    return value


def get_required_str(container: dict[str, Any], key: str, context: str) -> str:
    value = container.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{context} 缺少非空字符串字段 {key}")
    return value


def get_required_int(container: dict[str, Any], key: str, context: str) -> int:
    value = container.get(key)
    if not isinstance(value, int):
        raise ValueError(f"{context} 缺少整数类型字段 {key}")
    return value


def get_optional_bool(container: dict[str, Any], key: str, default: bool) -> bool:
    value = container.get(key, default)
    if not isinstance(value, bool):
        raise ValueError(f"字段 {key} 必须是布尔值")
    return value


def read_archive_bytes(archive: zipfile.ZipFile, member_path: str) -> bytes:
    try:
        return archive.read(member_path)
    except KeyError as exc:
        raise ValueError(f"vehicle 描述文件缺少文件: {member_path}") from exc


def build_service_specs(vehicle_path: Path) -> list[ServiceSpec]:
    with zipfile.ZipFile(vehicle_path) as archive:
        manifest = load_vehicle_manifest(archive)

        specs: list[ServiceSpec] = [
            ServiceSpec(
                name="前端静态页面服务",
                target=run_ui_service,
                kwargs={"access_log": False},
                port=UI_PORT,
            )
        ]

        ros_config = get_required_mapping(manifest, "ros", "manifest")
        ros_ip = get_required_str(ros_config, "ip", "manifest.ros")
        ros_port = get_required_int(ros_config, "port", "manifest.ros")

        web_config = manifest.get("web", {})
        if web_config and not isinstance(web_config, dict):
            raise ValueError("manifest.web 必须是对象")

        if get_optional_bool(web_config, "enabled", True):
            public_key_member = web_config.get("public_key", DEFAULT_PUBLIC_KEY_PATH)
            if not isinstance(public_key_member, str) or not public_key_member.strip():
                raise ValueError("manifest.web.public_key 必须是非空字符串")
            web_host = web_config.get("host", DEFAULT_WEB_HOST)
            web_port = web_config.get("port", DEFAULT_WEB_PORT)
            if not isinstance(web_host, str) or not web_host.strip():
                raise ValueError("manifest.web.host 必须是非空字符串")
            if not isinstance(web_port, int):
                raise ValueError("manifest.web.port 必须是整数")

            specs.append(
                ServiceSpec(
                    name="Web服务器",
                    target=run_web_service,
                    kwargs={
                        "ros_ip": ros_ip,
                        "ros_port": ros_port,
                        "public_key": read_archive_bytes(archive, public_key_member),
                        "host": web_host,
                        "port": web_port,
                        "access_log": False,
                    },
                    port=web_port,
                )
            )

        vision_config = manifest.get("vision", {})
        if vision_config and not isinstance(vision_config, dict):
            raise ValueError("manifest.vision 必须是对象")

        streams = vision_config.get("streams", [])
        if streams and not isinstance(streams, list):
            raise ValueError("manifest.vision.streams 必须是数组")

        vision_host = vision_config.get("host", DEFAULT_VISION_HOST)
        if not isinstance(vision_host, str) or not vision_host.strip():
            raise ValueError("manifest.vision.host 必须是非空字符串")

        for index, stream in enumerate(streams, start=1):
            if not isinstance(stream, dict):
                raise ValueError(f"manifest.vision.streams[{index - 1}] 必须是对象")
            if not get_optional_bool(stream, "enabled", True):
                continue

            stream_name = stream.get("name", f"视频流服务{index}")
            if not isinstance(stream_name, str) or not stream_name.strip():
                raise ValueError(f"manifest.vision.streams[{index - 1}].name 必须是非空字符串")

            stream_port = get_required_int(stream, "port", f"manifest.vision.streams[{index - 1}]")
            video_source = get_required_str(stream, "source", f"manifest.vision.streams[{index - 1}]")
            cam_label = stream.get("cam_label", f"cam{index}")

            specs.append(
                ServiceSpec(
                    name=stream_name,
                    target=run_vision_service,
                    kwargs={
                        "video_source": video_source,
                        "host": vision_host,
                        "port": stream_port,
                        "cam_label": cam_label,
                        "access_log": False,
                    },
                    port=stream_port,
                )
            )

        return specs


def print_port_status(specs: list[ServiceSpec]) -> None:
    logger.info("检查端口占用情况...")
    for spec in specs:
        if check_port_available(spec.port):
            logger.info("  ✓ 端口 %s (%s) 可用", spec.port, spec.name)
        else:
            logger.warning("  ✗ 端口 %s (%s) 被占用", spec.port, spec.name)


def stop_processes() -> None:
    for index, (name, process) in enumerate(processes):
        if process is None:
            continue
        if process.is_alive():
            try:
                process.terminate()
                process.join(timeout=5)
            except Exception as exc:
                logger.warning("关闭 %s 时出错: %s", name, exc)
                try:
                    process.kill()
                except Exception:
                    pass
        processes[index] = (name, None)
        sys_logger.service_stopped(name)


def signal_handler(sig: int | None, frame: object | None) -> None:
    logger.info("接收到终止信号，正在关闭所有服务...")
    sys_logger.shutdown()
    stop_processes()
    logger.info("所有服务已关闭")
    raise SystemExit(0)


def start_services(specs: list[ServiceSpec]) -> None:
    context = mp.get_context("spawn")
    for spec in specs:
        logger.info("启动 %s (端口 %s)", spec.name, spec.port)
        sys_logger.service_started(spec.name, spec.port)
        process = context.Process(name=spec.name, target=spec.target, kwargs=spec.kwargs)
        process.start()
        processes.append((spec.name, process))
        time.sleep(1)


def monitor_processes() -> int:
    while True:
        for index, (name, process) in enumerate(processes):
            if process is not None and not process.is_alive():
                process.join(timeout=0)
                logger.warning("%s 已退出，退出码: %s", name, process.exitcode)
                processes[index] = (name, None)

        if processes and all(process is None for _, process in processes):
            logger.info("所有服务已停止")
            return 0

        time.sleep(1)


def main() -> int:
    configure_logging()
    args = parse_args()

    if hasattr(signal, "SIGINT"):
        signal.signal(signal.SIGINT, signal_handler)
    if hasattr(signal, "SIGTERM"):
        signal.signal(signal.SIGTERM, signal_handler)

    try:
        backend_dir = get_backend_dir()
        vehicle_path = resolve_vehicle_path(args.vehicle)
        logger.info("后端目录: %s", backend_dir)
        logger.info("vehicle 描述文件: %s", vehicle_path)
        sys_logger.startup(str(vehicle_path))
        specs = build_service_specs(vehicle_path)
    except (OSError, ValueError, zipfile.BadZipFile) as exc:
        logger.error("加载 vehicle 描述文件失败: %s", exc)
        sys_logger.error("LAUNCH", str(exc))
        return 1

    print_port_status(specs)

    if not specs:
        logger.error("没有启动任何服务")
        return 1

    start_services(specs)
    logger.info("所有服务已启动，按 Ctrl+C 停止")

    try:
        return monitor_processes()
    except KeyboardInterrupt:
        signal_handler(None, None)
        return 0


if __name__ == "__main__":
    raise SystemExit(main())