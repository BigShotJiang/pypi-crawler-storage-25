import base64
import json
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.fernet import Fernet

class CryptoHelper:
    @staticmethod
    def generate_rsa_keys(key_size=2048):
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=key_size,
            backend=default_backend()
        )

        pem_private = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()
        )

        public_key = private_key.public_key()

        pem_public = public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )

        return pem_private, pem_public

    @staticmethod
    def load_private_key(path):
        with open(path, "rb") as key_file:
            return CryptoHelper.load_private_key_bytes(key_file.read())

    @staticmethod
    def load_public_key(path):
        with open(path, "rb") as key_file:
            return CryptoHelper.load_public_key_bytes(key_file.read())

    @staticmethod
    def load_private_key_bytes(private_key_bytes, password=None):
        return serialization.load_pem_private_key(private_key_bytes, password=password, backend=default_backend())

    @staticmethod
    def load_public_key_bytes(public_key_bytes):
        return serialization.load_pem_public_key(public_key_bytes, backend=default_backend())

    @staticmethod
    def rsa_decrypt(private_key, ciphertext):
        return private_key.decrypt(
            ciphertext,
            padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()), algorithm=hashes.SHA256(), label=None)
        )

    @staticmethod
    def rsa_encrypt(public_key, message_bytes):
        return public_key.encrypt(
            message_bytes,
            padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()), algorithm=hashes.SHA256(), label=None)
        )

    @staticmethod
    def sym_encrypt(key, data_dict):
        f = Fernet(key)
        json_str = json.dumps(data_dict)
        return f.encrypt(json_str.encode('utf-8'))

    @staticmethod
    def sym_decrypt(key, token):
        f = Fernet(key)
        data = f.decrypt(token)
        return json.loads(data.decode('utf-8'))
