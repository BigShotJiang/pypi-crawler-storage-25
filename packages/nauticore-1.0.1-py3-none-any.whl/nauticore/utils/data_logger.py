from __future__ import annotations

import json
import logging
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

DEFAULT_DATA_DIR = Path.cwd() / "data"


class DataLogger:
    def __init__(self, data_dir: Path | None = None):
        self.data_dir = data_dir or DEFAULT_DATA_DIR
        self._active = False
        self._session_id: str | None = None
        self._session_dir: Path | None = None
        self._data_file = None
        self._rx_count = 0
        self._tx_count = 0
        self._topics_rx: set[str] = set()
        self._topics_tx: set[str] = set()
        self._start_ts: float = 0.0
        self._start_ts_ms: int = 0
        self._lock = threading.Lock()
        self._flush_counter = 0

    @property
    def active(self) -> bool:
        return self._active

    @property
    def session_id(self) -> str | None:
        return self._session_id

    def start(self, session_id: str | None = None) -> dict[str, Any]:
        with self._lock:
            if self._active:
                return {"error": "Recording already in progress", "session_id": self._session_id}

            now = datetime.now()
            if session_id:
                self._session_id = session_id
            else:
                self._session_id = f"AUV_Data_{now.strftime('%Y%m%d_%H%M%S')}"

            self._session_dir = self.data_dir / self._session_id
            self._session_dir.mkdir(parents=True, exist_ok=True)

            self._rx_count = 0
            self._tx_count = 0
            self._topics_rx.clear()
            self._topics_tx.clear()
            self._start_ts = time.time()
            self._start_ts_ms = int(time.time() * 1000)
            self._flush_counter = 0

            self._data_file = open(self._session_dir / "data.jsonl", "w", encoding="utf-8")

            self._active = True
            logger.info("Data recording started: %s", self._session_id)

            return {
                "session_id": self._session_id,
                "status": "recording",
                "data_dir": str(self._session_dir),
            }

    def stop(self) -> dict[str, Any]:
        with self._lock:
            if not self._active:
                return {"error": "No recording in progress"}

            self._active = False

            if self._data_file:
                self._data_file.close()
                self._data_file = None

            stop_ts_ms = int(time.time() * 1000)
            duration_s = time.time() - self._start_ts

            meta = {
                "session_id": self._session_id,
                "start_ts": self._start_ts_ms,
                "start_iso": datetime.fromtimestamp(
                    self._start_ts_ms / 1000, tz=timezone.utc
                ).isoformat(),
                "stop_ts": stop_ts_ms,
                "stop_iso": datetime.fromtimestamp(
                    stop_ts_ms / 1000, tz=timezone.utc
                ).isoformat(),
                "duration_s": round(duration_s, 2),
                "rx_count": self._rx_count,
                "tx_count": self._tx_count,
                "topics_rx": sorted(self._topics_rx),
                "topics_tx": sorted(self._topics_tx),
            }

            meta_path = self._session_dir / "recording_meta.json"
            with open(meta_path, "w", encoding="utf-8") as f:
                json.dump(meta, f, indent=2, ensure_ascii=False)

            logger.info(
                "Data recording stopped: %s, rx=%d, tx=%d, %.1fs",
                self._session_id,
                self._rx_count,
                self._tx_count,
                duration_s,
            )

            result = {
                "session_id": self._session_id,
                "status": "stopped",
                "rx_count": self._rx_count,
                "tx_count": self._tx_count,
                "duration_s": round(duration_s, 2),
                "data_dir": str(self._session_dir),
            }

            self._session_id = None
            self._session_dir = None

            return result

    def log_rx(self, topic: str, msg_data: Any) -> None:
        if not self._active:
            return
        entry = {
            "ts": int(time.time() * 1000),
            "direction": "rx",
            "topic": topic,
            "data": msg_data,
        }
        line = json.dumps(entry, ensure_ascii=False, default=str) + "\n"
        with self._lock:
            if not self._active or not self._data_file:
                return
            try:
                self._data_file.write(line)
                self._rx_count += 1
                self._topics_rx.add(topic)
                self._flush_counter += 1
                if self._flush_counter >= 30:
                    self._data_file.flush()
                    self._flush_counter = 0
            except Exception:
                logger.exception("log_rx write error")

    def log_tx(self, topic: str, msg_type: str, msg_data: Any) -> None:
        if not self._active:
            return
        entry = {
            "ts": int(time.time() * 1000),
            "direction": "tx",
            "topic": topic,
            "type": msg_type,
            "data": msg_data,
        }
        line = json.dumps(entry, ensure_ascii=False, default=str) + "\n"
        with self._lock:
            if not self._active or not self._data_file:
                return
            try:
                self._data_file.write(line)
                self._tx_count += 1
                self._topics_tx.add(topic)
                self._flush_counter += 1
                if self._flush_counter >= 30:
                    self._data_file.flush()
                    self._flush_counter = 0
            except Exception:
                logger.exception("log_tx write error")

    @property
    def status(self) -> dict[str, Any]:
        if not self._active:
            return {"active": False}
        elapsed = time.time() - self._start_ts
        return {
            "active": True,
            "session_id": self._session_id,
            "rx_count": self._rx_count,
            "tx_count": self._tx_count,
            "elapsed_s": round(elapsed, 1),
            "topics_rx": sorted(self._topics_rx),
            "topics_tx": sorted(self._topics_tx),
        }

    def list_recordings(self) -> list[dict[str, Any]]:
        if not self.data_dir.exists():
            return []
        results = []
        for session_dir in sorted(self.data_dir.iterdir(), reverse=True):
            if not session_dir.is_dir():
                continue
            meta_path = session_dir / "recording_meta.json"
            if meta_path.exists():
                try:
                    with open(meta_path, "r", encoding="utf-8") as f:
                        meta = json.load(f)
                    meta["session_id"] = session_dir.name
                    results.append(meta)
                except Exception:
                    results.append({
                        "session_id": session_dir.name,
                        "status": "incomplete",
                    })
            else:
                data_path = session_dir / "data.jsonl"
                if data_path.exists():
                    results.append({
                        "session_id": session_dir.name,
                        "status": "recording",
                    })
        return results

    def get_recording(self, session_id: str) -> dict[str, Any] | None:
        session_dir = self.data_dir / session_id
        if not session_dir.exists():
            return None
        meta_path = session_dir / "recording_meta.json"
        if meta_path.exists():
            try:
                with open(meta_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                return None
        return {"session_id": session_id, "status": "incomplete"}

    def delete_recording(self, session_id: str) -> bool:
        import shutil
        session_dir = self.data_dir / session_id
        if not session_dir.exists():
            return False
        try:
            shutil.rmtree(session_dir)
            return True
        except Exception:
            logger.exception("delete_recording failed: %s", session_id)
            return False
