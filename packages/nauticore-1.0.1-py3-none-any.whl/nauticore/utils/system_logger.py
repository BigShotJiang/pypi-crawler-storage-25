import logging
from datetime import datetime
from pathlib import Path


class SystemLogger:
    _instance = None
    _log_dir = Path.cwd() / "log"

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self._initialized = True
        self._log_dir.mkdir(parents=True, exist_ok=True)
        self._log_file = self._log_dir / f"AUV_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
        self._logger = logging.getLogger(f"nauticore.system")
        self._logger.setLevel(logging.INFO)
        self._logger.handlers.clear()
        handler = logging.FileHandler(self._log_file, encoding="utf-8")
        handler.setLevel(logging.INFO)
        formatter = logging.Formatter("%(asctime)s - %(message)s", datefmt="%Y-%m-%d %H:%M:%S")
        handler.setFormatter(formatter)
        self._logger.addHandler(handler)
        self._logger.propagate = False

    def info(self, message: str):
        self._logger.info(message)

    def event(self, event_type: str, details: str = ""):
        msg = f"[{event_type}] {details}" if details else f"[{event_type}]"
        self._logger.info(msg)

    def startup(self, vehicle_name: str = ""):
        self.event("SYSTEM_STARTUP")

    def shutdown(self):
        self.event("SYSTEM_SHUTDOWN")

    def service_started(self, service_name: str, port: int = 0):
        self.event("SERVICE_STARTED", service_name)

    def service_stopped(self, service_name: str):
        self.event("SERVICE_STOPPED", service_name)

    def error(self, component: str, message: str):
        self._logger.error(f"[{component}] {message}")

    def capture_start(self, session_id: str, fps: float = 0):
        self.event("CAPTURE_START", f"{session_id} fps={fps}")

    def capture_stop(self, session_id: str, frames: int = 0):
        self.event("CAPTURE_STOP", f"{session_id} frames={frames}")


sys_logger = SystemLogger()
