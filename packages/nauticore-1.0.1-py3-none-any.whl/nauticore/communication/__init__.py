"""Public communication API for nauticore."""

from .frontend import Frontend

__all__ = ["Frontend"]