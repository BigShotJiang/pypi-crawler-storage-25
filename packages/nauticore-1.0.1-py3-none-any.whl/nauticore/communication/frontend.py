import socket
import threading
import time
import uuid
import atexit
import json
from cryptography.fernet import Fernet
from ..utils import CryptoHelper
from ..utils import sys_logger

import logging

logger = logging.getLogger(__name__)


class Frontend:
    def __init__(self, server_ip, server_port, public_key_source):
        self.server_addr = (server_ip, server_port)
        self.public_key = self.load_public_key(public_key_source)

        self.session_key = Fernet.generate_key()

        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(('0.0.0.0', 0))

        self.msg_routes = {}
        self.service_routes = {}

        self.pending_service_requests = {}
        self.timer_tasks = []

        self.running = False
        atexit.register(self.shutdown)

    @staticmethod
    def load_public_key(public_key_source):
        if isinstance(public_key_source, (bytes, bytearray)):
            return CryptoHelper.load_public_key_bytes(bytes(public_key_source))
        return CryptoHelper.load_public_key(public_key_source)

    @staticmethod
    def load_private_key(private_key_source):
        if isinstance(private_key_source, (bytes, bytearray)):
            return CryptoHelper.load_private_key_bytes(bytes(private_key_source))
        return CryptoHelper.load_private_key(private_key_source)

    def _send_encrypted_cmd(self, cmd_dict):
        encrypted = CryptoHelper.sym_encrypt(self.session_key, cmd_dict)
        self.sock.sendto(encrypted, self.server_addr)

    def register(self):
        reg_data = {
            'cmd': 'register',
            'key': self.session_key.decode('utf-8')
        }
        json_bytes = json.dumps(reg_data).encode('utf-8')
        encrypted = CryptoHelper.rsa_encrypt(self.public_key, json_bytes)
        self.sock.sendto(encrypted, self.server_addr)
        logger.info("Registration sent to %s:%s", *self.server_addr)
        sys_logger.event("ROS_REGISTER")

    def publish(self, topic, type_str, message_dict):
        cmd = {
            'cmd': 'publish',
            'topic': topic,
            'type': type_str,
            'data': message_dict
        }
        try:
            self._send_encrypted_cmd(cmd)
        except Exception as e:
            logger.error("Publish error on topic %s: %s", topic, e)

    def call_service(self, service_name, type_str, request_dict, timeout=5):
        req_id = str(uuid.uuid4())
        event = threading.Event()
        container = {'response': None}

        self.pending_service_requests[req_id] = (event, container)

        cmd = {
            'cmd': 'service_call',
            'service': service_name,
            'type': type_str,
            'data': request_dict,
            'id': req_id
        }
        self._send_encrypted_cmd(cmd)

        if event.wait(timeout):
            return container['response']
        else:
            del self.pending_service_requests[req_id]
            raise TimeoutError(f"Service call {service_name} timed out")

    def route_msg(self, topic):
        def decorator(func):
            self.msg_routes[topic] = func
            return func
        return decorator

    def route_service(self, service_name):
        def decorator(func):
            def wrapper(request_dict, type_str="std_srvs/Trigger"):
                return self.call_service(service_name, type_str, request_dict)
            return wrapper
        return decorator

    def timer(self, interval_ms):
        def decorator(func):
            self.timer_tasks.append((func, interval_ms / 1000.0))
            return func
        return decorator

    def _listen_loop(self):
        import concurrent.futures
        executor = concurrent.futures.ThreadPoolExecutor(max_workers=4)

        while self.running:
            try:
                data, _ = self.sock.recvfrom(65535)
                msg = CryptoHelper.sym_decrypt(self.session_key, data)
                msg_type = msg.get('type')

                if msg_type == 'topic_msg':
                    topic = msg['topic']
                    if topic in self.msg_routes:
                        executor.submit(self.msg_routes[topic], msg['data'])

                elif msg_type == 'service_response':
                    req_id = msg['id']
                    if req_id in self.pending_service_requests:
                        event, container = self.pending_service_requests[req_id]
                        container['response'] = msg['data']
                        event.set()
                        del self.pending_service_requests[req_id]

                elif msg_type == 'ack':
                    logger.info("Server ACK: %s", msg['msg'])

            except Exception as e:
                logger.debug("Listen loop error: %s", e)

        executor.shutdown(wait=False)

    def _timer_loop(self):
        last_runs = {func: 0 for func, _ in self.timer_tasks}
        while self.running:
            now = time.time()
            for func, interval in self.timer_tasks:
                if now - last_runs[func] >= interval:
                    try:
                        func()
                    except Exception as e:
                        logger.error("Timer task error: %s", e)
                    last_runs[func] = now
            time.sleep(0.01)

    def run(self):
        self.running = True

        t_listen = threading.Thread(target=self._listen_loop)
        t_listen.daemon = True
        t_listen.start()

        self.register()
        time.sleep(0.5)

        t_timer = threading.Thread(target=self._timer_loop)
        t_timer.daemon = True
        t_timer.start()

        logger.info("MUR Frontend running. Press Ctrl+C to exit.")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            self.shutdown()

    def shutdown(self):
        if self.running:
            logger.info("Shutting down Frontend...")
            sys_logger.event("ROS_DISCONNECT")
            try:
                cmd = {'cmd': 'disconnect'}
                self._send_encrypted_cmd(cmd)
            except Exception:
                pass
            self.running = False
            self.sock.close()
