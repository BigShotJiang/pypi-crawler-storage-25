"""Configuration loading, validation, and path helpers for PyStator.

``ConfigValidator`` and ``validate_config`` are lazy-loaded so that
importing ``pystator.config`` does **not** require Pydantic.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from pystator.config.auth import (
    get_auth_admin_group_claims,
    get_auth_admin_role_claims,
    get_auth_jwt_secret,
    get_auth_users,
    is_auth_disabled,
)
from pystator.config.database import get_database_url, set_database_url
from pystator.config.discovery import (
    get_discovery_backend,
    get_discovery_database_url,
    get_discovery_drift_alert_threshold,
    get_discovery_drift_min_sample,
    get_discovery_drift_severe_threshold,
    get_discovery_low_sample_threshold,
    get_discovery_min_confidence,
    get_discovery_min_edge_count,
    is_discovery_shadow_enabled,
)
from pystator.config.loader import ConfigLoader, load_config
from pystator.config.paths import find_config_file
from pystator.config.ui import get_ui_app_name, get_ui_theme

if TYPE_CHECKING:
    from pystator.config.validator import ConfigValidator as ConfigValidator
    from pystator.config.validator import validate_config as validate_config

__all__ = [
    # Auth
    "get_auth_admin_group_claims",
    "get_auth_admin_role_claims",
    "get_auth_jwt_secret",
    "get_auth_users",
    "is_auth_disabled",
    # Database
    "get_database_url",
    "set_database_url",
    # Discovery
    "get_discovery_backend",
    "get_discovery_database_url",
    "get_discovery_drift_alert_threshold",
    "get_discovery_drift_min_sample",
    "get_discovery_drift_severe_threshold",
    "get_discovery_low_sample_threshold",
    "get_discovery_min_confidence",
    "get_discovery_min_edge_count",
    "is_discovery_shadow_enabled",
    # UI
    "get_ui_app_name",
    "get_ui_theme",
    # Config loading / validation
    "ConfigLoader",
    "ConfigValidator",
    "find_config_file",
    "load_config",
    "validate_config",
]

# Lazy imports for Pydantic-dependent symbols
_LAZY_IMPORTS: dict[str, tuple[str, str]] = {
    "ConfigValidator": ("pystator.config.validator", "ConfigValidator"),
    "validate_config": ("pystator.config.validator", "validate_config"),
}


def __getattr__(name: str) -> Any:
    if name in _LAZY_IMPORTS:
        module_path, attr = _LAZY_IMPORTS[name]
        import importlib

        mod = importlib.import_module(module_path)
        return getattr(mod, attr)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
