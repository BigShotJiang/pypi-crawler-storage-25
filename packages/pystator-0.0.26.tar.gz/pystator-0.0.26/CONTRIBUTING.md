# Contributing to PyStator

Thank you for your interest in contributing. This document describes how to set up a development environment, run checks, and submit changes.

## Prerequisites

- Python 3.11, 3.12, or 3.13
- Node.js 20+ (for the optional UI under `src/pystator/ui`)

## Development setup

From the repository root:

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -U pip
pip install -e ".[dev]"
```

## Running tests

```bash
pytest
```

## Linting and formatting

```bash
ruff format --check src/pystator tests
ruff check src/pystator tests
```

## Type checking (Python)

```bash
mypy src/pystator
```

CI runs `mypy` with a non-failing fallback; fixing new type errors is still appreciated.

## UI (Next.js)

```bash
cd src/pystator/ui
npm ci
npm run type-check
```

Use `npm run dev` / `npm run build` as documented in [`src/pystator/ui/README.md`](src/pystator/ui/README.md).

## Documentation site (MkDocs)

The user-facing docs under `docs/` are built with **MkDocs** and **mkdocstrings** (Python API pages under `docs/api/`). From the repo root, with dev dependencies installed (`pip install -e ".[dev]"`, which pulls in `pystator[api]` and thus MkDocs):

```bash
mkdocs serve    # local preview at http://127.0.0.1:8000/
mkdocs build    # output in site/
```

The CLI also exposes `pystator docs serve` / `pystator docs build` when the `api` extra is installed. API reference pages import `pystator` and optional drivers (SQLAlchemy, etc.); if `mkdocs build` fails on missing modules, install `pystator[api]` or the full `[dev]` extra.

## Pull requests

1. Open an issue first for larger features or design changes so we can align early.
2. Keep changes focused; match existing style and patterns.
3. Add or update tests when behavior changes.
4. Target `main` or `develop` as used by the project (CI runs on PRs to both).

## Community conduct

Please read [`CODE_OF_CONDUCT.md`](CODE_OF_CONDUCT.md). For security-sensitive reports, see [`SECURITY.md`](SECURITY.md).
