# -#- coding: utf-8 -#-
from facturacion_electronica import facturacion_electronica as fe
from facturacion_electronica.firma import Firma
import json
from lxml import etree
import unittest


def verificar_firma_xml(firma_electronica, xml):
    firma = Firma(firma_electronica)
    result = firma.verificar_firma_xml(xml)
    return result

class TestActualizacion2026(unittest.TestCase):
    """
    Test Actualización 2026 (Nuevos campos y RUTProvSW diferenciados)
    """

    def test_01_timbrar_y_enviar_factura_2026(self):
        """Test factura (DTE 33) con campos 2026."""
        print("\nSe inicia test factura 2026")
        with open("facturacion_electronica/ejemplos/ejemplo_actualizacion_2026.json") as f:
            ejemplo = json.load(f)

        firma_electronica = ejemplo['firma_electronica'].copy()
        result = fe.timbrar_y_enviar(ejemplo)

        self.assertFalse(result.get('errores', False), f"Errores: {result.get('errores')}")
        self.assertTrue(result.get('sii_xml_request', False))

        # Verificar firma
        self.assertEqual((0,''), verificar_firma_xml(firma_electronica, result['sii_xml_request']))

        # Verificar campos en el XML del DTE
        dte_xml_str = '<?xml version="1.0" encoding="ISO-8859-1"?>' + result['detalles'][0]['sii_xml_dte']
        xml = etree.fromstring(dte_xml_str.replace('xmlns="http://www.sii.cl/SiiDte"', '').encode('ISO-8859-1'))

        # Transporte
        transporte = xml.find('Documento/Encabezado/Transporte')
        self.assertIsNotNone(transporte)
        self.assertEqual(transporte.find('Patente').text, 'ABCD12')
        self.assertEqual(transporte.find('PatenteCarro').text, 'XY9988')
        self.assertEqual(transporte.find('FchSalida').text, '2026-04-01')
        self.assertEqual(transporte.find('HraSalida').text, '10:00:00')
        self.assertEqual(transporte.find('FchLlegada').text, '2026-04-02')

        # Retenedor en Detalle
        retenedor = xml.find('Documento/Detalle/Retenedor')
        self.assertIsNotNone(retenedor)
        self.assertEqual(retenedor.find('IndAgente').text, 'R')
        self.assertEqual(retenedor.find('MntBaseFaena').text, '500')

        # ManejoMadera y GeoRefEmision
        geo_ref = xml.find('Documento/GeoRefEmision')
        self.assertIsNotNone(geo_ref)
        self.assertEqual(geo_ref.find('LatitudEmision').text, '-33.4489')
        self.assertEqual(geo_ref.find('LongitudEmision').text, '-70.6693')
        self.assertEqual(geo_ref.find('SistemaReferencia').text, '1')

        manejo_madera = xml.find('Documento/ManejoMadera')
        self.assertIsNotNone(manejo_madera)
        self.assertEqual(manejo_madera.find('ComunaRolOrigen').text, '123456')
        self.assertEqual(manejo_madera.find('MnzRolOrigen').text, '654321')
        self.assertEqual(manejo_madera.find('PrdRolOrigen').text, '111222')
        self.assertEqual(manejo_madera.find('ComunaRolDestino').text, '654321')
        self.assertEqual(manejo_madera.find('MnzRolDestino').text, '123456')
        self.assertEqual(manejo_madera.find('PrdRolDestino').text, '222111')
        self.assertEqual(manejo_madera.find('CodPlanConaf').text, 'PLAN-2026')
        self.assertEqual(manejo_madera.find('AvisoEjecucionFaena').text, 'AVISO-001')
        self.assertEqual(manejo_madera.find('LatitudOrigenMadera').text, '-35.0000')
        self.assertEqual(manejo_madera.find('LongitudOrigenMadera').text, '-71.0000')
        self.assertEqual(manejo_madera.find('LatitudDestinoMadera').text, '-36.0000')
        self.assertEqual(manejo_madera.find('LongitudDestinoMadera').text, '-72.0000')
        self.assertEqual(manejo_madera.find('SistemareferenciaMadera').text, '1')

    def test_02_timbrar_y_enviar_boleta_2026(self):
        """Test boleta (DTE 39) con RUTProvSW."""
        return
        print("\nSe inicia test boleta 2026")
        with open("facturacion_electronica/ejemplos/ejemplo_boleta_2026.json") as f:
            ejemplo = json.load(f)

        firma_electronica = ejemplo['firma_electronica'].copy()
        result = fe.timbrar_y_enviar(ejemplo)

        self.assertFalse(result.get('errores', False), f"Errores: {result.get('errores')}")
        self.assertTrue(result.get('sii_xml_request', False))

        # Verificar campos en el XML del DTE
        dte_xml_str = '<?xml version="1.0" encoding="ISO-8859-1"?>' + result['detalles'][0]['sii_xml_dte']
        xml = etree.fromstring(dte_xml_str.replace('xmlns="http://www.sii.cl/SiiDte"', '').encode('ISO-8859-1'))

        # Receptor y RUTProvSW
        self.assertEqual(xml.find('Documento/Encabezado/Receptor/RUTRecep').text, '66666666-6')
        rut_prov_sw = xml.find('Documento/Encabezado/RUTProvSW')
        self.assertIsNotNone(rut_prov_sw)
        self.assertEqual(rut_prov_sw.text, '78203889-3')

if __name__ == '__main__':
    unittest.main()
