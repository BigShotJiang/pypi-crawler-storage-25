# -#- coding: utf-8 -#-
"""
Test de intercambio: OdooCoop (76883241-2) genera un EnvioDTE
dirigido a Daniel Santibáñez (16291998-9) para el proceso de
intercambio entre contribuyentes.

Etapa 1 (solo para test): Se timbra un DTE de ejemplo para obtener
    el xml firmado. En producción este xml ya existe, es el mismo
    DTE que fue enviado al SII.
Etapa 2: Se toma el xml del DTE ya timbrado y se genera el EnvioDTE
    de intercambio usando fe.xml_envio(), con RutReceptor = 16291998-9
    (Daniel Santibáñez, el receptor del documento).
"""
from facturacion_electronica import facturacion_electronica as fe
from facturacion_electronica.firma import Firma
import json
from lxml import etree
import unittest


def verificar_firma_xml(firma_electronica, xml):
    firma = Firma(firma_electronica)
    result = firma.verificar_firma_xml(xml)
    return result


class TestXMLIntercambio(unittest.TestCase):
    """
    Test Intercambio: OdooCoop (76883241-2) envía EnvioDTE
    a Daniel Santibáñez (16291998-9) como intercambio
    """

    def test_intercambio_odoocoop_a_daniel(self):
        """
        Intercambio desde OdooCoop (76883241-2) a Daniel Santibáñez (16291998-9).
        Etapa 1 (solo test): Timbrar un DTE (factura 33) para obtener el xml.
            En producción este xml ya existe: es el DTE enviado al SII.
        Etapa 2: Generar EnvioDTE con fe.xml_envio() hacia 16291998-9
        """
        print("Se inicia test intercambio OdooCoop -> Daniel Santibáñez")
        f = open("facturacion_electronica/ejemplos/ejemplo_basico_33.json")
        txt_json = f.read()
        f.close()
        ejemplo = json.loads(txt_json)
        firma_electronica = ejemplo['firma_electronica'].copy()

        # Solo timbrar 1 DTE (el primero)
        ejemplo_timbrar = ejemplo.copy()
        primer_doc = ejemplo['Documento'][0].copy()
        primer_doc['documentos'] = [primer_doc['documentos'][0]]
        ejemplo_timbrar['Documento'] = [primer_doc]

        """
            Etapa 1 (solo para test):
            Timbrar DTE para obtener el xml firmado.
            En producción este paso no existe, se usa directamente
            el sii_xml_dte del DTE que ya fue enviado al SII.
        """
        result_timbrado = fe.timbrar(ejemplo_timbrar)
        self.assertEqual(len(result_timbrado), 1)
        dte = result_timbrado[0]
        self.assertFalse(dte.get('error', False),
                         f"Error timbrando: {dte.get('error')}")
        self.assertTrue(dte.get('sii_xml_dte', False))
        self.assertTrue(dte.get('sii_barcode_img', False))

        # Verificar firma del DTE timbrado
        string_xml_dte = '<?xml version="1.0" encoding="ISO-8859-1"?>' + \
                            dte['sii_xml_dte']
        result_firma = verificar_firma_xml(
            firma_electronica.copy(),
            string_xml_dte)
        self.assertEqual((0, ''), result_firma)

        """
            Etapa 2: Generar EnvioDTE de intercambio con fe.xml_envio()
            Se usa el xml del DTE timbrado (en producción sería el DTE
            que ya fue enviado al SII).
            Emisor: OdooCoop (76883241-2)
            RutReceptor: Daniel Santibáñez (16291998-9)
        """
        xml_dte = etree.fromstring(
            string_xml_dte.replace(
                'xmlns="http://www.sii.cl/SiiDte"', ''
            ).encode('ISO-8859-1'))
        rut_recep = xml_dte.find('Documento/Encabezado/Receptor/RUTRecep').text

        vals_envio = {
            "test": True,
            "Emisor": ejemplo['Emisor'].copy(),
            "firma_electronica": firma_electronica.copy(),
            "RutReceptor": rut_recep,
            "Documento": [{
                "TipoDTE": 33,
                "documentos": [{
                    "NroDTE": 1,
                    "sii_xml_request": dte['sii_xml_dte'],
                    "Folio": dte['Folio'],
                }]
            }]
        }

        result_envio = fe.xml_envio(vals_envio)
        self.assertFalse(result_envio.get('errores', False),
                         f"Error en xml_envio: {result_envio.get('errores')}")
        self.assertTrue(result_envio.get('sii_xml_request', False))

        # Verificar firma del EnvioDTE
        result_firma = verificar_firma_xml(
            firma_electronica.copy(),
            result_envio['sii_xml_request'])
        self.assertEqual((0, ''), result_firma)

        """
            Verificar estructura XML del envío
        """
        xml = etree.fromstring(
            result_envio['sii_xml_request'].replace(
                'xmlns="http://www.sii.cl/SiiDte"', ''
            ).replace(
                'xmlns="http://www.w3.org/2000/09/xmldsig#"', ''
            ).encode('ISO-8859-1'))

        Caratula = xml.find("SetDTE/Caratula")
        self.assertIsNotNone(Caratula)
        self.assertEqual(Caratula.find("RutEmisor").text, "76883241-2",
                         "RutEmisor debe ser OdooCoop")
        self.assertEqual(Caratula.find("RutReceptor").text, "16291998-9",
                         "RutReceptor debe ser Daniel Santibáñez")

        SubTotDTEs = xml.findall("SetDTE/Caratula/SubTotDTE")
        self.assertEqual(len(SubTotDTEs), 1)
        self.assertEqual(SubTotDTEs[0].find("TpoDTE").text, "33")
        self.assertEqual(SubTotDTEs[0].find("NroDTE").text, "1")

        DTEs = xml.findall("SetDTE/DTE")
        self.assertEqual(len(DTEs), 1)

        # Verificar Signature del envío
        sig_envio = xml.find("Signature")
        self.assertIsNotNone(sig_envio)
        digest_envio = sig_envio.find("SignedInfo/Reference/DigestValue")
        self.assertIsNotNone(digest_envio)

        # Verificar Signature del DTE dentro del envío
        sig_dte = DTEs[0].find("Signature")
        self.assertIsNotNone(sig_dte)
        digest_dte = sig_dte.find("SignedInfo/Reference/DigestValue")
        self.assertIsNotNone(digest_dte)


if __name__ == '__main__':
    unittest.main()
