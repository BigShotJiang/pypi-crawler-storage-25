from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from tempfile import mkdtemp
from typing import Any, Protocol
from urllib.parse import quote


@dataclass(frozen=True)
class ArtifactRef:
    key: str
    path: str


class Storage(Protocol):
    def write(self, key: str, value: Any) -> ArtifactRef: ...


@dataclass
class LocalStorage:
    root: Path = field(default_factory=lambda: Path(mkdtemp(prefix="craftflow-artifacts-")))

    def write(self, key: str, value: Any) -> ArtifactRef:
        path = self.root / f"{quote(key, safe='')}.txt"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(str(value), encoding="utf-8")
        return ArtifactRef(key=key, path=str(path))


__all__ = ["ArtifactRef", "LocalStorage", "Storage"]
