from __future__ import annotations

from dataclasses import dataclass
from typing import Any


class CraftType:
    def __init__(self, value: Any) -> None:
        self.value = value

    def __eq__(self, other: object) -> bool:
        return type(self) is type(other) and getattr(other, "value", None) == self.value

    def __hash__(self) -> int:
        return hash((type(self), self.value))

    def __str__(self) -> str:
        return str(self.value)


class Media(CraftType):
    def __init__(self, value: Any) -> None:
        super().__init__(value)
        if not isinstance(self.value, str):
            raise TypeError(f"{type(self).__name__} value must be a string")


class Image(Media):
    pass


class Video(Media):
    pass


class Audio(Media):
    pass


class Latent(Media):
    pass


class Spatial(CraftType):
    def __init__(self, value: Any) -> None:
        super().__init__(value)
        if not isinstance(self.value, str):
            raise TypeError(f"{type(self).__name__} value must be a string")


class Mask(Spatial):
    pass


class BBox(Spatial):
    pass


class Segmentation(Spatial):
    pass


class Textual(CraftType):
    def __init__(self, value: Any) -> None:
        super().__init__(value)
        if not isinstance(self.value, str):
            raise TypeError(f"{type(self).__name__} value must be a string")


class Prompt(Textual):
    pass


class Caption(Textual):
    pass


class Numeric(CraftType):
    def __init__(self, value: Any) -> None:
        super().__init__(value)
        if not isinstance(self.value, (int, float)):
            raise TypeError(f"{type(self).__name__} value must be numeric")


class Seed(Numeric):
    pass


class Score(Numeric):
    pass


class Embedding(CraftType):
    pass


class ImageBatch(CraftType):
    pass


class VideoBatch(CraftType):
    pass


MediaType = Media


@dataclass(frozen=True)
class Resources:
    cpu: float | None = None
    gpu: bool | None = None
    memory_gb: float | None = None
    vram_gb: float | None = None
    provider: str | None = None
