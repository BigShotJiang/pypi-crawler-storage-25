from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol

from .storage import LocalStorage, Storage


class Executor(Protocol):
    def run(self, workflow: Any, inputs: dict[str, Any]) -> Any: ...


@dataclass
class LocalExecutor:
    storage: Storage | None = None

    def __post_init__(self) -> None:
        if self.storage is None:
            self.storage = LocalStorage()

    def run(self, workflow: Any, inputs: dict[str, Any]) -> Any:
        return workflow._execute_local(self.storage, inputs)
