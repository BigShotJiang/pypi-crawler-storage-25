from __future__ import annotations

from dataclasses import dataclass, field
from time import perf_counter
from typing import Any, ClassVar

from .executors import Executor, LocalExecutor
from .storage import ArtifactRef, LocalStorage, Storage
from .types import Audio, BBox, Caption, CraftType, Embedding, Image, ImageBatch, Latent, Mask, Media, MediaType, Numeric, Prompt, Resources, Score, Segmentation, Seed, Spatial, Textual, Video, VideoBatch


class CraftflowError(Exception):
    pass


class CraftflowTypeError(CraftflowError, TypeError):
    pass


class CraftflowReferenceError(CraftflowError, ValueError):
    pass


@dataclass(frozen=True)
class PortRef:
    node: str | None
    output: str

    @property
    def key(self) -> str:
        return self.output if self.node is None else f"{self.node}.{self.output}"


class Op:
    inputs: ClassVar[dict[str, type]] = {}
    outputs: ClassVar[dict[str, type]] = {}
    deterministic: ClassVar[bool] = True
    cache: ClassVar[bool] = True
    supports_batch: ClassVar[bool] = False
    resources: ClassVar[Resources | None] = None

    def run(self, **kwargs: Any) -> dict[str, Any] | Any:
        raise NotImplementedError

    def params(self) -> dict[str, Any]:
        return {}

    def resource_hints(self, inputs: dict[str, Any], params: dict[str, Any]) -> Resources | None:
        return self.resources


@dataclass(frozen=True)
class Node:
    id: str
    op: Op
    inputs: dict[str, PortRef]
    params: dict[str, Any] = field(default_factory=dict)

    def cache_key(self, inputs: dict[str, Any], provider_version: str = "local") -> str:
        import hashlib, json

        payload = {
            "op": type(self.op).__name__,
            "params": self.op.params(),
            "inputs": {k: _stable_hash(inputs[v.key]) for k, v in sorted(self.inputs.items())},
            "provider": provider_version,
        }
        return hashlib.sha256(json.dumps(payload, sort_keys=True, default=str).encode()).hexdigest()

    def resource_hints(self, inputs: dict[str, Any]) -> Resources | None:
        return self.op.resource_hints(inputs, self.op.params())


@dataclass(frozen=True)
class Graph:
    name: str
    nodes: list[Node]
    inputs: dict[str, type]
    output: PortRef
    output_type: type
    node_map: dict[str, Node] = field(init=False, repr=False)

    def __post_init__(self) -> None:
        object.__setattr__(self, "node_map", {node.id: node for node in self.nodes})

    def summary(self) -> str:
        lines = [f"workflow: {self.name}"]
        lines.append("inputs: " + (", ".join(f"{k}:{v.__name__}" for k, v in self.inputs.items()) or "-"))
        for node in self.nodes:
            bindings = ", ".join(f"{name}={ref.key}" for name, ref in node.inputs.items())
            lines.append(f"node {node.id}: {node.op.__class__.__name__}({bindings})")
        lines.append(f"output: {self.output.key} : {self.output_type.__name__}")
        return "\n".join(lines)


@dataclass(frozen=True)
class ExprRef:
    expr: OpCall
    output: str


@dataclass(frozen=True)
class OpCall:
    op_cls: type[Op]
    kwargs: dict[str, Any]
    params: dict[str, Any] = field(default_factory=dict)

    def __getattr__(self, name: str) -> ExprRef:
        if name not in self.op_cls.outputs:
            raise AttributeError(name)
        return ExprRef(self, name)


@dataclass(frozen=True)
class InputRef:
    name: str


class RemoveBackground(Op):
    inputs = {"image": Image}
    outputs = {"image": Image, "mask": Mask}

    def __init__(self, model: str = "rembg") -> None:
        self.model = model

    def params(self) -> dict[str, Any]:
        return {"model": self.model}

    def resource_hints(self, inputs: dict[str, Any], params: dict[str, Any]) -> Resources | None:
        if params.get("model") == "sam2":
            return Resources(gpu=True, vram_gb=8, provider="local")
        return Resources(cpu=2, memory_gb=4, provider="local")

    def run(self, **kwargs: Any) -> dict[str, Any]:
        image = kwargs["image"]
        return {"image": image, "mask": Mask(f"mask({image})")}


class Inpaint(Op):
    inputs = {"image": Image, "mask": Mask, "prompt": Prompt}
    outputs = {"image": Image}

    def run(self, **kwargs: Any) -> dict[str, Any]:
        return {"image": kwargs["image"]}


class Upscale(Op):
    inputs = {"image": Image}
    outputs = {"image": Image}
    supports_batch = True

    def run(self, **kwargs: Any) -> dict[str, Any]:
        return {"image": kwargs["image"]}


class TextToImage(Op):
    inputs = {"prompt": Prompt}
    outputs = {"image": Image, "latent": Latent}

    def run(self, **kwargs: Any) -> dict[str, Any]:
        prompt = kwargs["prompt"]
        return {"image": Image(f"image({prompt})"), "latent": Latent(f"latent({prompt})")}


class ImageToImage(Op):
    inputs = {"image": Image, "prompt": Prompt}
    outputs = {"image": Image}

    def run(self, **kwargs: Any) -> dict[str, Any]:
        return {"image": kwargs["image"]}


class _C:
    def input(self, name: str) -> InputRef:
        return InputRef(name)

    def ref(self, ref: str) -> PortRef:
        if "." not in ref:
            raise ValueError("references must use '<node>.<output>'")
        node, output = ref.split(".", 1)
        return PortRef(node, output)

    def remove_bg(self, image: Any, model: str = "rembg") -> OpCall:
        return OpCall(RemoveBackground, {"image": image}, {"model": model})

    def inpaint(self, *, image: Any, mask: Any, prompt: Any) -> OpCall:
        return OpCall(Inpaint, {"image": image, "mask": mask, "prompt": prompt})

    def upscale(self, image: Any) -> OpCall:
        return OpCall(Upscale, {"image": image})

    def text_to_image(self, *, prompt: Any) -> OpCall:
        return OpCall(TextToImage, {"prompt": prompt})

    def image_to_image(self, *, image: Any, prompt: Any) -> OpCall:
        return OpCall(ImageToImage, {"image": image, "prompt": prompt})


C = _C()


@dataclass
class TraceStep:
    provider: str = "local"
    duration: float = 0.0


@dataclass
class Trace:
    steps: dict[str, TraceStep] = field(default_factory=dict)
    total_cost: float = 0.0


@dataclass
class RunResult:
    artifacts: dict[str, ArtifactRef]
    trace: Trace
    result: Any


def _stable_hash(value: Any) -> str:
    import hashlib, json

    def normalize(item: Any) -> Any:
        if isinstance(item, CraftType):
            return {"type": type(item).__name__, "value": normalize(item.value)}
        if isinstance(item, dict):
            return {str(k): normalize(v) for k, v in sorted(item.items())}
        if isinstance(item, (list, tuple)):
            return [normalize(v) for v in item]
        return item

    payload = json.dumps(normalize(value), sort_keys=True, default=str)
    return hashlib.sha256(payload.encode()).hexdigest()


class Workflow:
    def __init__(self, name: str) -> None:
        self.name = name
        self.input_types: dict[str, type] = {}
        self._flow: dict[str, OpCall] = {}
        self._output: Any = None

    def inputs(self, **kwargs: type) -> Workflow:
        self.input_types.update(kwargs)
        return self

    def input(self, name: str, typ: type) -> PortRef:
        self.input_types[name] = typ
        return PortRef(None, name)

    def flow(self, **kwargs: OpCall) -> Workflow:
        self._flow.update(kwargs)
        return self

    def run_batch(self, inputs_list: list[dict[str, Any]], executor: str | Executor | None = "local") -> list[RunResult]:
        if not isinstance(inputs_list, list):
            raise TypeError("run_batch expects a list of input dictionaries")
        return [self.run(executor=executor, inputs=inputs) for inputs in inputs_list]

    def output(self, output: Any) -> Workflow:
        self._output = output
        return self

    def validate(self) -> Graph:
        return self.check()

    def check(self) -> Graph:
        return self._compile()

    def run(self, executor: str | Executor | None = "local", inputs: dict[str, Any] | None = None) -> RunResult:
        self.check()
        if executor in (None, "local"):
            executor = LocalExecutor()
        if isinstance(executor, str):
            raise ValueError("only the local executor is implemented")
        return executor.run(self, dict(inputs or {}))

    def _execute_local(self, storage: Storage, inputs: dict[str, Any]) -> RunResult:
        graph = self._compile()
        values = self._prepare_inputs(inputs)
        artifacts: dict[str, ArtifactRef] = {}
        trace = Trace()

        for node in graph.nodes:
            kwargs = {name: values[ref.key] for name, ref in node.inputs.items()}
            started = perf_counter()
            result = node.op.run(**kwargs)
            duration = perf_counter() - started
            if not isinstance(result, dict):
                if len(node.op.outputs) != 1:
                    raise TypeError(f"{node.id} must return a dict for multiple outputs")
                result = {next(iter(node.op.outputs)): result}
            for output, expected in node.op.outputs.items():
                if output not in result:
                    raise ValueError(f"{node.id} did not return output {output}")
                value = self._coerce_value(result[output], expected, f"{node.id}.{output}")
                key = f"{node.id}.{output}"
                values[key] = value
                artifacts[key] = storage.write(key, value)
            trace.steps[node.id] = TraceStep(duration=duration)
            trace.steps[node.id].provider = node.op.params().get("provider", "local")

        return RunResult(artifacts=artifacts, trace=trace, result=values[graph.output.key])

    def _prepare_inputs(self, inputs: dict[str, Any]) -> dict[str, Any]:
        values = dict(inputs)
        for required, typ in self.input_types.items():
            if required not in values:
                raise ValueError(f"missing input {required}")
            values[required] = self._coerce_value(values[required], typ, required)
        return values

    def _coerce_value(self, value: Any, typ: type, name: str) -> Any:
        if isinstance(value, typ):
            return value
        if issubclass(typ, CraftType):
            if issubclass(typ, Numeric):
                if isinstance(value, (int, float)):
                    return typ(value)
            elif isinstance(value, str):
                return typ(value)
            raise TypeError(f"{name} expected {typ.__name__}")
        if not isinstance(value, typ):
            raise TypeError(f"{name} expected {typ.__name__}")
        return value

    def _compile(self) -> Graph:
        return self._compile_declarative() if self._flow else self._compile_compositional()

    def _compile_declarative(self) -> Graph:
        available = dict(self.input_types)
        pending = dict(self._flow)
        nodes: list[Node] = []
        while pending:
            progressed = False
            for node_id, call in list(pending.items()):
                deps = self._call_dependencies(call)
                if all(self._dep_available(dep, available) for dep in deps):
                    nodes.append(self._compile_call(node_id, call, available))
                    available.update({f"{node_id}.{name}": typ for name, typ in call.op_cls.outputs.items()})
                    pending.pop(node_id)
                    progressed = True
            if not progressed:
                self._raise_unresolved(pending, available)
        output = self._resolve_output(self._output, available)
        self._detect_cycles(nodes)
        return Graph(self.name, nodes, dict(self.input_types), output, available[output.key])

    def _compile_compositional(self) -> Graph:
        available = dict(self.input_types)
        nodes: list[Node] = []
        memo: dict[int, str] = {}
        counter = 0

        def build(value: Any) -> PortRef:
            nonlocal counter
            if isinstance(value, ExprRef):
                node_id = build_call(value.expr)
                return PortRef(node_id, value.output)
            if isinstance(value, OpCall):
                if len(value.op_cls.outputs) != 1:
                    raise ValueError("multi-output ops need an explicit output attribute")
                return PortRef(build_call(value), next(iter(value.op_cls.outputs)))
            return self._resolve_ref(value, available)

        def build_call(call: OpCall) -> str:
            nonlocal counter
            ident = id(call)
            if ident in memo:
                return memo[ident]
            self._check_call_shape(call)
            inputs = {name: build(value) for name, value in call.kwargs.items()}
            node_id = f"{call.op_cls.__name__[0].lower()}{call.op_cls.__name__[1:]}_{counter}"
            counter += 1
            memo[ident] = node_id
            self._validate_input_types(call, inputs, available, node_id=node_id)
            nodes.append(Node(node_id, call.op_cls(**call.params), inputs, call.params))
            available.update({f"{node_id}.{name}": typ for name, typ in call.op_cls.outputs.items()})
            return node_id

        output = build(self._output)
        self._detect_cycles(nodes)
        return Graph(self.name, nodes, dict(self.input_types), output, available[output.key])

    def _compile_call(self, node_id: str, call: OpCall, available: dict[str, type]) -> Node:
        self._check_call_shape(call)
        inputs = {name: self._resolve_ref(value, available) for name, value in call.kwargs.items()}
        self._validate_input_types(call, inputs, available, node_id=node_id)
        return Node(node_id, call.op_cls(**call.params), inputs, call.params)

    def _validated_kwargs(self, call: OpCall, available: dict[str, type]) -> dict[str, Any]:
        self._check_call_shape(call)
        for name, value in call.kwargs.items():
            ref = self._resolve_ref(value, available)
            self._ensure_type(ref, call.op_cls.inputs[name], available)
        return call.kwargs

    def _validate_input_types(self, call: OpCall, inputs: dict[str, PortRef], available: dict[str, type], node_id: str) -> None:
        errors: list[str] = []
        for name, ref in inputs.items():
            try:
                self._ensure_type(ref, call.op_cls.inputs[name], available, target=f"{node_id}.{name}")
            except CraftflowTypeError as exc:
                errors.append(str(exc))
        if errors:
            raise CraftflowTypeError("\n".join(errors))

    def _ensure_type(self, ref: PortRef, expected: type, available: dict[str, type], target: str | None = None) -> None:
        actual = self._type_of(ref, available)
        if not self._compatible(actual, expected):
            lhs = target or ref.key
            raise CraftflowTypeError(f"{lhs} expected {expected.__name__}, got {actual.__name__} from {ref.key}")

    def _compatible(self, actual: type, expected: type) -> bool:
        return actual is expected or (isinstance(actual, type) and isinstance(expected, type) and issubclass(actual, expected))

    def _check_call_shape(self, call: OpCall) -> None:
        missing = set(call.op_cls.inputs) - set(call.kwargs)
        extra = set(call.kwargs) - set(call.op_cls.inputs)
        if missing:
            raise ValueError(f"{call.op_cls.__name__} missing inputs: {sorted(missing)}")
        if extra:
            raise ValueError(f"{call.op_cls.__name__} got unknown inputs: {sorted(extra)}")

    def _resolve_ref(self, value: Any, available: dict[str, type]) -> PortRef:
        if isinstance(value, InputRef):
            value = PortRef(None, value.name)
        elif isinstance(value, str):
            if "." in value:
                value = C.ref(value)
            elif value in available:
                value = PortRef(None, value)
            else:
                raise CraftflowReferenceError(f"invalid ref {value}")
        if not isinstance(value, PortRef):
            raise TypeError("inputs must be PortRef, C.input(...), C.ref(...), or expression outputs")
        self._type_of(value, available)
        return value

    def _resolve_output(self, value: Any, available: dict[str, type]) -> PortRef:
        if isinstance(value, OpCall):
            raise ValueError("declarative workflows must output a named ref like 'node.output'")
        ref = self._resolve_ref(value, available)
        if ref.node is None and ref.key not in available:
            raise CraftflowReferenceError(f"invalid output ref {ref.key}")
        return ref

    def _type_of(self, ref: PortRef, available: dict[str, type]) -> type:
        if ref.key not in available:
            raise CraftflowReferenceError(f"invalid ref {ref.key}")
        return available[ref.key]

    def _call_dependencies(self, call: OpCall) -> set[str]:
        deps: set[str] = set()
        for value in call.kwargs.values():
            if isinstance(value, InputRef):
                deps.add(value.name)
            elif isinstance(value, PortRef) and value.node is not None:
                deps.add(value.key)
            elif isinstance(value, str):
                if "." in value:
                    deps.add(value.split(".", 1)[0])
                elif value in self.input_types:
                    deps.add(value)
            elif isinstance(value, ExprRef):
                deps.update(self._call_dependencies(value.expr))
            elif isinstance(value, OpCall):
                deps.update(self._call_dependencies(value))
        return deps

    def _raise_unresolved(self, pending: dict[str, OpCall], available: dict[str, type]) -> None:
        missing = []
        for node_id, call in pending.items():
            deps = sorted(dep for dep in self._call_dependencies(call) if not self._dep_available(dep, available))
            missing.append(f"{node_id}: {deps}")
        raise CraftflowReferenceError(f"invalid ref or cycle: {', '.join(missing)}")

    def _dep_available(self, dep: str, available: dict[str, type]) -> bool:
        return dep in available or any(key.startswith(f"{dep}.") for key in available)

    def _detect_cycles(self, nodes: list[Node]) -> None:
        known = {node.id for node in nodes}
        deps = {node.id: {ref.node for ref in node.inputs.values() if ref.node in known} for node in nodes}
        temporary: set[str] = set()
        permanent: set[str] = set()

        def visit(node_id: str) -> None:
            if node_id in permanent:
                return
            if node_id in temporary:
                raise ValueError("cycle detected")
            temporary.add(node_id)
            for dep in deps.get(node_id, set()):
                visit(dep)
            temporary.remove(node_id)
            permanent.add(node_id)

        for node_id in deps:
            visit(node_id)


__all__ = [
    "Caption",
    "CraftType",
    "Audio",
    "BBox",
    "C",
    "Graph",
    "Image",
    "ImageBatch",
    "ImageToImage",
    "Inpaint",
    "Node",
    "Op",
    "OpCall",
    "Resources",
    "PortRef",
    "RemoveBackground",
    "RunResult",
    "Mask",
    "MediaType",
    "Media",
    "Numeric",
    "Prompt",
    "Score",
    "TextToImage",
    "Trace",
    "TraceStep",
    "Seed",
    "Spatial",
    "Textual",
    "Upscale",
    "VideoBatch",
    "Workflow",
]
