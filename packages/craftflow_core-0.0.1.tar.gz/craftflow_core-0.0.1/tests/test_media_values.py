import pytest

from craftflow import Caption, Image, Mask, Prompt, Score, Seed


@pytest.mark.parametrize(
    "typ,value",
    [
        (Image, "img-1"),
        (Mask, "mask-1"),
        (Prompt, "prompt-1"),
        (Caption, "caption-1"),
        (Seed, 7),
        (Score, 0.75),
    ],
)
def test_media_values_support_equality_and_str(typ, value):
    assert typ(value) == typ(value)
    assert str(typ(value)) == str(value)
    assert typ(value) != Image("different")


def test_media_values_reject_non_strings():
    with pytest.raises(TypeError, match="Image value must be a string"):
        Image(123)  # type: ignore[arg-type]


@pytest.mark.parametrize("typ,value", [(Seed, "bad"), (Score, "bad")])
def test_numeric_types_reject_non_numeric_values(typ, value):
    with pytest.raises(TypeError, match=f"{typ.__name__} value must be numeric"):
        typ(value)  # type: ignore[arg-type]


@pytest.mark.parametrize("typ,value", [(Seed, 7), (Score, 0.5)])
def test_numeric_types_accept_numeric_values(typ, value):
    assert typ(value).value == value
