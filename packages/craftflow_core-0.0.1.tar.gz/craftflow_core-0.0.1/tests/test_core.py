from pathlib import Path

import pytest

from craftflow import C, Graph, Image, Mask, Prompt, Workflow


def test_declarative_api_builds_valid_graph_with_forward_refs():
    wf = (
        Workflow("ad_image")
        .inputs(image=Image, prompt=Prompt)
        .flow(
            final=C.upscale(C.ref("edit.image")),
            edit=C.inpaint(image=C.ref("cutout.image"), mask=C.ref("cutout.mask"), prompt=C.input("prompt")),
            cutout=C.remove_bg(C.input("image")),
        )
        .output("final.image")
    )

    graph = wf.validate()

    assert isinstance(graph, Graph)
    assert [node.id for node in graph.nodes] == ["cutout", "edit", "final"]


def test_compositional_api_builds_valid_graph():
    wf = Workflow("ad2")
    image = wf.input("image", Image)
    prompt = wf.input("prompt", Prompt)

    cutout = C.remove_bg(image)
    edit = C.inpaint(image=cutout.image, mask=cutout.mask, prompt=prompt)
    final = C.upscale(edit.image)
    wf.output(final)

    graph = wf.validate()

    assert len(graph.nodes) == 3
    assert graph.output.key.endswith(".image")


def test_type_mismatch_is_rejected():
    wf = (
        Workflow("bad")
        .inputs(image=Image, prompt=Prompt)
        .flow(cutout=C.remove_bg(C.input("image")), edit=C.inpaint(image=C.ref("cutout.image"), mask=C.ref("cutout.image"), prompt=C.input("prompt")))
        .output("edit.image")
    )

    with pytest.raises(TypeError, match="expected Mask"):
        wf.validate()


def test_invalid_reference_is_rejected():
    wf = Workflow("badref").inputs(image=Image).flow(cutout=C.remove_bg(C.input("image"))).output("cutout.nope")

    with pytest.raises(ValueError, match="invalid ref cutout.nope"):
        wf.validate()


def test_cycle_is_rejected():
    wf = (
        Workflow("cycle")
        .inputs(image=Image, prompt=Prompt)
        .flow(
            a=C.remove_bg(C.ref("b.image")),
            b=C.upscale(C.ref("a.image")),
        )
        .output("a.image")
    )

    with pytest.raises(ValueError, match="cycle detected|invalid ref or cycle"):
        wf.validate()


def test_local_run_returns_artifacts_trace_and_result():
    wf = (
        Workflow("run")
        .inputs(image=Image, prompt=Prompt)
        .flow(cutout=C.remove_bg(C.input("image")), edit=C.inpaint(image=C.ref("cutout.image"), mask=C.ref("cutout.mask"), prompt=C.input("prompt")))
        .output("edit.image")
    )

    result = wf.run(inputs={"image": "img", "prompt": "p"})

    assert str(result.result) == "img"
    assert result.artifacts["cutout.image"].path
    assert Path(result.artifacts["cutout.image"].path).exists()
    assert set(result.trace.steps) == {"cutout", "edit"}


def test_missing_runtime_input_is_rejected():
    wf = Workflow("run").inputs(image=Image).flow(cutout=C.remove_bg(C.input("image"))).output("cutout.image")

    with pytest.raises(ValueError, match="missing input image"):
        wf.run(inputs={})


def test_builtin_types_are_exported():
    assert Image is not Mask
    assert Prompt.__name__ == "Prompt"
