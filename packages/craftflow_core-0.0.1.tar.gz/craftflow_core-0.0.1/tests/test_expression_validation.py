import pytest

from craftflow import C, Image, Prompt, Workflow
from craftflow_core.core import Inpaint, OpCall


def test_builtin_output_attribute_validation_and_ref_parsing():
    assert C.text_to_image(prompt=C.input("prompt")).image.output == "image"
    with pytest.raises(AttributeError):
        _ = C.text_to_image(prompt=C.input("prompt")).nope
    with pytest.raises(ValueError, match="<node>.<output>"):
        C.ref("broken")


def test_missing_and_extra_op_inputs_are_rejected():
    with pytest.raises(ValueError, match="Inpaint missing inputs"):
        Workflow("x").inputs(image=Image, prompt=Prompt).flow(x=OpCall(Inpaint, {"image": C.input("image"), "prompt": C.input("prompt")})).output("x.image").check()
    with pytest.raises(ValueError, match="Inpaint got unknown inputs"):
        Workflow("y").inputs(image=Image, prompt=Prompt).flow(x=OpCall(Inpaint, {"image": C.input("image"), "mask": C.input("image"), "prompt": C.input("prompt"), "extra": C.input("prompt")})).output("x.image").check()
