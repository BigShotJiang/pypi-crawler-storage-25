from craftflow import C, Graph, Image, Mask, Prompt, Workflow
from craftflow.executors import LocalExecutor
from craftflow.storage import ArtifactRef, LocalStorage, Storage
from craftflow.types import Audio, BBox, Caption, CraftType, Embedding, Image as ImageType, ImageBatch, Latent, Mask as MaskType, MediaType, Prompt as PromptType, Resources, Score, Segmentation, Seed, Spatial, Textual, Video, VideoBatch
from craftflow_core import C as CoreC, Workflow as CoreWorkflow


def test_public_imports_are_stable():
    assert Image is ImageType
    assert Prompt is PromptType
    assert Mask is MaskType
    assert Graph is not None and Workflow is not None and C is not None
    assert LocalExecutor is not None and LocalStorage is not None and Storage is not None
    assert ArtifactRef is not None
    assert all(issubclass(cls, CraftType) for cls in [Image, Mask, Prompt, Latent, Video, Audio, Embedding, BBox, Segmentation, Caption, Seed, Score, ImageBatch, VideoBatch])
    assert Resources(cpu=1).cpu == 1
    assert CoreWorkflow is Workflow
    assert CoreC is C
