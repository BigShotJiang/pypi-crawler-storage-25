import pytest

from craftflow import C, Image, Mask, Prompt, Video, Workflow, Media
from craftflow_core.core import CraftflowReferenceError, CraftflowTypeError, Op, OpCall
from craftflow_core.types import Resources, VideoBatch


def _node_ids_before_deps(graph):
    position = {node.id: index for index, node in enumerate(graph.nodes)}
    for node in graph.nodes:
        for ref in node.inputs.values():
            if ref.node in position:
                assert position[ref.node] < position[node.id]


def test_declarative_workflow_supports_branching_forward_refs_and_topological_execution():
    wf = (
        Workflow("dag")
        .inputs(image=Image, prompt=Prompt)
        .flow(
            final=C.upscale(C.ref("paint.image")),
            paint=C.inpaint(image=C.ref("seed.image"), mask=C.ref("seed.mask"), prompt=C.input("prompt")),
            seed=C.remove_bg(C.input("image")),
            branch=C.image_to_image(image=C.ref("seed.image"), prompt=C.input("prompt")),
        )
        .output("final.image")
    )
    graph = wf.check()

    assert {n.id for n in graph.nodes} == {"seed", "branch", "paint", "final"}
    _node_ids_before_deps(graph)
    assert graph.output.key == "final.image"


def test_declarative_workflow_accepts_plain_string_refs_and_input_names():
    wf = (
        Workflow("strings")
        .inputs(image=Image, prompt=Prompt)
        .flow(seed=C.remove_bg("image"), edit=C.inpaint(image="seed.image", mask="seed.mask", prompt="prompt"))
        .output("edit.image")
    )

    graph = wf.check()

    assert [n.id for n in graph.nodes] == ["seed", "edit"]
    assert graph.output.key == "edit.image"


def test_output_can_use_plain_string_or_c_ref():
    wf = Workflow("out").inputs(image=Image).flow(seed=C.remove_bg(C.input("image"))).output(C.ref("seed.image"))
    assert wf.check().output.key == "seed.image"


def test_compositional_workflow_supports_nested_expressions_and_shared_subexpressions():
    wf = Workflow("nested").inputs(image=Image, prompt=Prompt)
    cutout = C.remove_bg(C.input("image"))
    edit = C.inpaint(image=cutout.image, mask=cutout.mask, prompt=C.input("prompt"))
    final = C.upscale(C.image_to_image(image=edit.image, prompt=C.input("prompt")).image)
    wf.output(final)

    graph = wf.check()

    assert len(graph.nodes) == 4
    _node_ids_before_deps(graph)
    assert graph.output.key.endswith(".image")


def test_compositional_multi_output_op_requires_explicit_output_attribute():
    wf = Workflow("multi").inputs(image=Image).output(C.remove_bg(C.input("image")))

    with pytest.raises(ValueError, match="multi-output ops need an explicit output attribute"):
        wf.check()


def test_larger_cycle_is_rejected():

    cyc = Workflow("cycle").inputs(image=Image, prompt=Prompt).flow(a=C.remove_bg(C.ref("b.image")), b=C.upscale(C.ref("c.image")), c=C.upscale(C.ref("a.image"))).output("a.image")
    with pytest.raises(ValueError, match="cycle detected|invalid ref or cycle"):
        cyc.check()


def test_workflow_check_and_summary_and_string_refs_match():
    wf = (
        Workflow("summary")
        .inputs(image=Image, prompt=Prompt)
        .flow(seed=C.remove_bg(C.input("image")), edit=C.inpaint(image=C.ref("seed.image"), mask=C.ref("seed.mask"), prompt=C.input("prompt")))
        .output(C.ref("edit.image"))
    )

    graph = wf.check()
    summary = graph.summary()

    assert "workflow: summary" in summary
    assert "inputs: image:Image, prompt:Prompt" in summary
    assert "seed.image" in summary and "seed.mask" in summary
    assert "output: edit.image : Image" in summary


def test_aggregated_type_mismatch_reports_node_and_input_names():
    wf = (
        Workflow("bad")
        .inputs(image=Image, prompt=Prompt)
        .flow(cutout=C.remove_bg(C.input("image")), edit=C.inpaint(image=C.ref("cutout.mask"), mask=C.ref("cutout.image"), prompt=C.input("prompt")))
        .output("edit.image")
    )

    with pytest.raises(CraftflowTypeError, match=r"edit\.image expected Image, got Mask from cutout\.mask|edit\.mask expected Mask, got Image from cutout\.image") as exc:
        wf.check()
    message = str(exc.value)
    assert "edit.image expected Image, got Mask from cutout.mask" in message
    assert "edit.mask expected Mask, got Image from cutout.image" in message


def test_swapped_refs_are_reported_as_aggregated_type_errors():
    wf = (
        Workflow("swap")
        .inputs(image=Image, prompt=Prompt)
        .flow(cutout=C.remove_bg(C.input("image")), edit=C.inpaint(image=C.ref("cutout.mask"), mask=C.ref("cutout.image"), prompt="prompt"))
        .output("edit.image")
    )

    with pytest.raises(CraftflowTypeError) as exc:
        wf.check()
    assert "edit.image expected Image" in str(exc.value)
    assert "edit.mask expected Mask" in str(exc.value)


def test_custom_media_supertype_accepts_broad_media_inputs():
    class NeedsMedia(Op):
        inputs = {"image": Media}
        outputs = {"image": Media}

        def run(self, **kwargs):
            return {"image": kwargs["image"]}

    wf = Workflow("media").inputs(image=Image).flow(out=OpCall(NeedsMedia, {"image": C.input("image")})).output("out.image")
    assert wf.check().output.key == "out.image"


def test_cache_key_changes_with_params_inputs_and_provider_version():
    wf = Workflow("cache").inputs(image=Image).flow(seed=C.remove_bg(C.input("image"), model="sam2")).output("seed.image")
    graph = wf.check()
    node = graph.nodes[0]
    values = {"image": Image("x")}
    key1 = node.cache_key(values, provider_version="v1")
    key2 = node.cache_key(values, provider_version="v2")
    assert key1 != key2


def test_cache_key_distinguishes_concrete_media_types_and_params():
    class EchoMedia(Op):
        inputs = {"image": Media}
        outputs = {"image": Media}

        def __init__(self, model: str = "base") -> None:
            self.model = model

        def params(self):
            return {"model": self.model}

        def run(self, **kwargs):
            return {"image": kwargs["image"]}

    wf = Workflow("cache2").inputs(image=Media).flow(out=OpCall(EchoMedia, {"image": C.input("image")}, {"model": "base"})).output("out.image")
    node = wf.check().nodes[0]
    image_key = node.cache_key({"image": Image("x")})
    video_key = node.cache_key({"image": Video("x")})
    model_key = node.cache_key({"image": Image("x")}, provider_version="local")

    assert image_key != video_key
    assert image_key == model_key


def test_cache_key_changes_with_op_params_and_model():
    wf1 = Workflow("cache3").inputs(image=Image).flow(out=C.remove_bg(C.input("image"), model="rembg")).output("out.image")
    wf2 = Workflow("cache4").inputs(image=Image).flow(out=C.remove_bg(C.input("image"), model="sam2")).output("out.image")
    node1 = wf1.check().nodes[0]
    node2 = wf2.check().nodes[0]
    values = {"image": Image("x")}

    assert node1.cache_key(values) != node2.cache_key(values)


def test_remove_bg_resources_depend_on_model():
    rembg = C.remove_bg(C.input("image"))
    sam2 = C.remove_bg(C.input("image"), model="sam2")
    wf = Workflow("res").inputs(image=Image).flow(a=rembg, b=sam2).output("a.image")
    graph = wf.check()
    assert graph.node_map["a"].resource_hints({}) == Resources(cpu=2, gpu=None, memory_gb=4, vram_gb=None, provider="local")
    assert graph.node_map["b"].resource_hints({}) == Resources(cpu=None, gpu=True, memory_gb=None, vram_gb=8, provider="local")


def test_batch_support_flags_and_run_batch_order():
    assert C.upscale(C.input("image")).op_cls.supports_batch is True
    assert C.remove_bg(C.input("image")).op_cls.supports_batch is False
    wf = Workflow("batch").inputs(image=Image).flow(out=C.upscale(C.input("image"))).output("out.image")
    results = wf.run_batch([{"image": "one"}, {"image": "two"}])
    assert [str(r.result) for r in results] == ["one", "two"]


def test_invalid_output_ref_fails_cleanly():
    wf = Workflow("oops").inputs(image=Image).flow(seed=C.remove_bg(C.input("image"))).output(C.ref("missing.image"))
    with pytest.raises(CraftflowReferenceError, match="invalid output ref|invalid ref"):
        wf.check()


def test_run_auto_checks_before_execution():
    wf = Workflow("run-check").inputs(image=Image, prompt=Prompt).flow(edit=C.inpaint(image=C.input("image"), mask=C.input("image"), prompt=C.input("prompt"))).output("edit.image")
    with pytest.raises(CraftflowTypeError):
        wf.run(inputs={"image": Image("i"), "prompt": Prompt("p")})


def test_declarative_and_compositional_compile_to_same_shape():
    declarative = Workflow("same").inputs(image=Image, prompt=Prompt).flow(seed=C.remove_bg(C.input("image")), final=C.upscale(C.ref("seed.image"))).output("final.image").check()
    compositional = Workflow("same").inputs(image=Image, prompt=Prompt)
    seed = C.remove_bg(C.input("image"))
    compositional.flow(seed=seed, final=C.upscale(C.ref("seed.image"))).output(C.ref("final.image"))
    compositional = compositional.check()

    assert [n.op.__class__ for n in declarative.nodes] == [n.op.__class__ for n in compositional.nodes]
    assert declarative.output.key == compositional.output.key
