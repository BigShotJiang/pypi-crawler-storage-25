from pathlib import Path

import pytest

from craftflow import C, Image, Prompt, Workflow
from craftflow.executors import LocalExecutor
from craftflow.storage import ArtifactRef, LocalStorage
from craftflow_core.core import Op, OpCall


class FakeStorage:
    def __init__(self):
        self.writes = []

    def write(self, key, value):
        ref = ArtifactRef(key=key, path=f"/fake/{len(self.writes)}.txt")
        self.writes.append((key, value, ref))
        return ref


def test_default_executor_and_local_executor_object_run():
    wf = Workflow("run").inputs(image=Image, prompt=Prompt).flow(out=C.image_to_image(image=C.input("image"), prompt=C.input("prompt"))).output("out.image")
    result = wf.run(inputs={"image": "raw-image", "prompt": "raw-prompt"})
    assert str(result.result) == "raw-image"
    assert isinstance(result.artifacts["out.image"], ArtifactRef)

    fake = FakeStorage()
    result2 = wf.run(executor=LocalExecutor(storage=fake), inputs={"image": "x", "prompt": "y"})
    assert len(fake.writes) == 1
    assert result2.artifacts["out.image"].path == "/fake/0.txt"


def test_complex_branching_flow_persists_all_artifacts_with_unique_paths():
    storage = LocalStorage()
    wf = (
        Workflow("branching")
        .inputs(image=Image, prompt=Prompt)
        .flow(
            cutout=C.remove_bg(C.input("image")),
            edit=C.inpaint(image=C.ref("cutout.image"), mask=C.ref("cutout.mask"), prompt=C.input("prompt")),
            upscale=C.upscale(C.ref("edit.image")),
            rerender=C.image_to_image(image=C.input("image"), prompt=C.input("prompt")),
            synth=C.text_to_image(prompt=C.input("prompt")),
            synth_upscale=C.upscale(C.ref("synth.image")),
        )
        .output("upscale.image")
    )

    result = wf.run(executor=LocalExecutor(storage=storage), inputs={"image": Image("source-image"), "prompt": Prompt("stylize")})

    assert isinstance(result.result, Image)
    assert str(result.result) == "source-image"
    assert set(result.artifacts) == {
        "cutout.image",
        "cutout.mask",
        "edit.image",
        "upscale.image",
        "rerender.image",
        "synth.image",
        "synth.latent",
        "synth_upscale.image",
    }
    paths = [artifact.path for artifact in result.artifacts.values()]
    assert len(paths) == len(set(paths))
    assert all(Path(path).exists() for path in paths)
    assert all(Path(path).read_text(encoding="utf-8") for path in paths)


def test_local_storage_uses_collision_safe_artifact_paths():
    storage = LocalStorage()

    first = storage.write("a.b_c", "first")
    second = storage.write("a_b.c", "second")

    assert first.path != second.path
    assert Path(first.path).read_text(encoding="utf-8") == "first"
    assert Path(second.path).read_text(encoding="utf-8") == "second"


def test_missing_runtime_output_and_invalid_executor_and_coercion():
    wf = Workflow("bad").inputs(image=Image, prompt=Prompt).flow(out=C.remove_bg(C.input("image"))).output("out.image")
    with pytest.raises(ValueError, match="missing input prompt"):
        Workflow("miss").inputs(prompt=Prompt).flow(out=C.text_to_image(prompt=C.input("prompt"))).output("out.image").run(inputs={})
    with pytest.raises(ValueError, match="only the local executor"):
        wf.run(executor="other", inputs={"image": "x", "prompt": "y"})


def test_runtime_output_missing_and_non_dict_single_output_is_coerced():
    class BadOutput(Op):
        inputs = {"image": Image}
        outputs = {"image": Image}

        def run(self, **kwargs):
            return {}

    class ScalarOutput(Op):
        inputs = {"image": Image}
        outputs = {"image": Image}

        def run(self, **kwargs):
            return "scalar"

    bad = Workflow("bad2").inputs(image=Image).flow(out=OpCall(BadOutput, {"image": C.input("image")})).output("out.image")
    with pytest.raises(ValueError, match="did not return output image"):
        bad.run(inputs={"image": "x"})

    scalar = Workflow("scalar").inputs(image=Image).flow(out=OpCall(ScalarOutput, {"image": C.input("image")})).output("out.image")
    result = scalar.run(inputs={"image": "x"})
    assert str(result.result) == "scalar"
