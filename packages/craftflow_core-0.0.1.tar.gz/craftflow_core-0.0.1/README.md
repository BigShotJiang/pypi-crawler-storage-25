# craftflow-core

Core Craftflow workflow primitives for building typed, lazy workflows for generative media.

This package currently publishes the foundational `craftflow_core` implementation and the top-level `craftflow` compatibility import.
