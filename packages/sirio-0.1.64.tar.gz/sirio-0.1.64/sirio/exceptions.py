class TimeoutException(Exception):
    pass

class RetriableException(Exception):
    pass

class NotRetriableException(Exception):
    pass

class SirioBoServiceTimeoutException(TimeoutException):
    pass

class SirioBoServiceRetriableException(RetriableException):
    pass

class SirioBoServiceNotRetriableException(NotRetriableException):
    pass

class SirioAiServiceTokenLimitException(Exception):
    pass

class SirioAiContentFilterException(Exception):
    def __init__(self, message, filter_details=None):
        super().__init__(message)
        self.filter_details = filter_details
