from __future__ import annotations

import json
from typing import Any, Iterator, Literal, overload

import httpx

from .types import (
    ChatCompletion,
    ChatCompletionChunk,
    Choice,
    Delta,
    GuardrailViolation,
    LoraAdapter,
    Message,
    StreamChoice,
    TrainingJob,
    TrainingStatus,
    Usage,
    Violation,
)

_DEFAULT_BASE_URL = "https://rkdune--symmetry.modal.run"


class Asymmetric:
    """Asymmetric API client with guardrail support."""

    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = 120.0,
    ) -> None:
        self._http = httpx.Client(
            base_url=base_url.rstrip("/"),
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            timeout=timeout,
        )
        self.chat = _Chat(self)
        self.guardrails = _Guardrails(self)
        self.finetuning = _Finetuning(self)

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> Asymmetric:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


class _Chat:
    def __init__(self, client: Asymmetric) -> None:
        self.completions = _Completions(client)


class _Completions:
    def __init__(self, client: Asymmetric) -> None:
        self._client = client

    @overload
    def create(
        self,
        *,
        model: str,
        messages: list[dict[str, str]],
        stream: Literal[False] = ...,
        guardrail_policy: str | list[str] | None = ...,
        chunk_size: int = ...,
        sliding_window: int = ...,
        finetuning: dict[str, Any] | None = ...,
        **kwargs: Any,
    ) -> ChatCompletion: ...

    @overload
    def create(
        self,
        *,
        model: str,
        messages: list[dict[str, str]],
        stream: Literal[True],
        guardrail_policy: str | list[str] | None = ...,
        chunk_size: int = ...,
        sliding_window: int = ...,
        finetuning: dict[str, Any] | None = ...,
        **kwargs: Any,
    ) -> Iterator[ChatCompletionChunk]: ...

    def create(
        self,
        *,
        model: str,
        messages: list[dict[str, str]],
        stream: bool = False,
        guardrail_policy: str | list[str] | None = None,
        chunk_size: int = 10,
        sliding_window: int = 5,
        finetuning: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> ChatCompletion | Iterator[ChatCompletionChunk]:
        body: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "stream": stream,
            **kwargs,
        }
        if guardrail_policy is not None:
            body["guardrail_policy"] = guardrail_policy
            body["chunk_size"] = chunk_size
            body["sliding_window"] = sliding_window
        if finetuning is not None:
            body.update(finetuning)

        if stream:
            return self._stream(body)
        return self._complete(body)

    def _complete(self, body: dict[str, Any]) -> ChatCompletion:
        resp = self._client._http.post("/v1/chat/completions", json=body)
        if resp.status_code == 400:
            detail = resp.json().get("detail", "")
            if "Guardrail violation" in detail:
                raise _parse_violation(detail)
        resp.raise_for_status()
        return _build_completion(resp.json())

    def _stream(
        self, body: dict[str, Any]
    ) -> Iterator[ChatCompletionChunk]:
        with self._client._http.stream(
            "POST", "/v1/chat/completions", json=body
        ) as resp:
            resp.raise_for_status()
            for line in resp.iter_lines():
                if not line.startswith("data: "):
                    continue
                payload = line[6:]
                if payload == "[DONE]":
                    return
                data = json.loads(payload)
                if "error" in data:
                    msg = data["error"]
                    if "Guardrail violation" in msg:
                        raise _parse_violation(msg)
                    raise RuntimeError(msg)
                yield _build_chunk(data)


class _Guardrails:
    def __init__(self, client: Asymmetric) -> None:
        self._client = client

    def list_violations(self) -> list[Violation]:
        resp = self._client._http.get("/guardrail/violations")
        resp.raise_for_status()
        return [
            Violation(
                id=v["id"],
                timestamp=v["timestamp"],
                user_input=v.get("user_input"),
                model_output=v["model_output"],
                guardrail_policy=v["guardrail_policy"],
            )
            for v in resp.json().get("violations", [])
        ]


class _Finetuning:
    def __init__(self, client: Asymmetric) -> None:
        self._client = client

    def train(self, memory_group: str, lora_name: str) -> TrainingJob:
        resp = self._client._http.post(
            "/finetuning/train",
            json={"memory_group": memory_group, "lora_name": lora_name},
        )
        resp.raise_for_status()
        data = resp.json()
        return TrainingJob(
            status=data["status"],
            message=data["message"],
            lora_name=data.get("lora_name"),
            version=data.get("version"),
            memories_count=data.get("memories_count"),
            job_id=data.get("job_id"),
        )

    def status(self, memory_group: str, lora_name: str) -> TrainingStatus:
        resp = self._client._http.get(
            "/finetuning/status",
            params={"memory_group": memory_group, "lora_name": lora_name},
        )
        resp.raise_for_status()
        data = resp.json()
        return TrainingStatus(
            memory_group=data["memory_group"],
            lora_name=data["lora_name"],
            queued_count=data["queued_count"],
            trained_count=data["trained_count"],
            training_status=data["training_status"],
            current_version=data["current_version"],
            last_training_started=data.get("last_training_started"),
            last_training_completed=data.get("last_training_completed"),
            last_error=data.get("last_error"),
            lora_status=data.get("lora_status"),
            lora_ready=data["lora_ready"],
        )

    def list(self) -> list[LoraAdapter]:
        resp = self._client._http.get("/finetuning/loras")
        resp.raise_for_status()
        return [
            LoraAdapter(
                lora_name=a["lora_name"],
                memory_group=a["memory_group"],
                status=a["status"],
                active_version=a["active_version"],
                created_at=a["created_at"],
                updated_at=a["updated_at"],
            )
            for a in resp.json().get("loras", [])
        ]


# --- Helpers ---


def _parse_violation(detail: str) -> GuardrailViolation:
    """Parse violation detail string from the API."""
    policy = ""
    text = ""
    try:
        if "Policy: '" in detail:
            after = detail.split("Policy: '", 1)[1]
            policy = after.split("'. ", 1)[0]
        for marker in ("Text in violation: '", "Text: '"):
            if marker in detail:
                raw = detail.split(marker, 1)[1]
                text = raw[:-1] if raw.endswith("'") else raw
                break
    except (IndexError, ValueError):
        pass
    return GuardrailViolation(policy=policy, text=text)


def _build_completion(data: dict[str, Any]) -> ChatCompletion:
    choices = [
        Choice(
            index=c.get("index", i),
            message=Message(
                role=c["message"]["role"],
                content=c["message"].get("content"),
            ),
            finish_reason=c.get("finish_reason"),
        )
        for i, c in enumerate(data["choices"])
    ]
    usage = None
    if u := data.get("usage"):
        usage = Usage(
            prompt_tokens=u.get("prompt_tokens", 0),
            completion_tokens=u.get("completion_tokens", 0),
            total_tokens=u.get("total_tokens", 0),
        )
    return ChatCompletion(
        id=data["id"], model=data["model"], choices=choices, usage=usage
    )


def _build_chunk(data: dict[str, Any]) -> ChatCompletionChunk:
    choices = [
        StreamChoice(
            index=c.get("index", i),
            delta=Delta(
                role=c.get("delta", {}).get("role"),
                content=c.get("delta", {}).get("content"),
            ),
            finish_reason=c.get("finish_reason"),
        )
        for i, c in enumerate(data.get("choices", []))
    ]
    return ChatCompletionChunk(
        id=data.get("id", ""),
        model=data.get("model", ""),
        choices=choices,
    )
