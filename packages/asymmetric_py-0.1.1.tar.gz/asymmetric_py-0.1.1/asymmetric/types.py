from dataclasses import dataclass


class GuardrailViolation(Exception):
    """Raised when a guardrail policy violation is detected."""

    def __init__(self, policy: str, text: str) -> None:
        self.policy = policy
        self.text = text
        super().__init__(f"Guardrail violation detected. Policy: '{policy}'")


@dataclass
class Message:
    role: str
    content: str | None = None


@dataclass
class Delta:
    role: str | None = None
    content: str | None = None


@dataclass
class Choice:
    index: int
    message: Message
    finish_reason: str | None = None


@dataclass
class StreamChoice:
    index: int
    delta: Delta
    finish_reason: str | None = None


@dataclass
class Usage:
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


@dataclass
class ChatCompletion:
    id: str
    model: str
    choices: list[Choice]
    usage: Usage | None = None


@dataclass
class ChatCompletionChunk:
    id: str
    model: str
    choices: list[StreamChoice]


@dataclass
class Violation:
    id: str
    timestamp: str
    user_input: str | None
    model_output: str
    guardrail_policy: str


@dataclass
class TrainingJob:
    status: str
    message: str
    lora_name: str | None = None
    version: int | None = None
    memories_count: int | None = None
    job_id: str | None = None


@dataclass
class TrainingStatus:
    memory_group: str
    lora_name: str
    queued_count: int
    trained_count: int
    training_status: str
    current_version: int
    last_training_started: int | None
    last_training_completed: int | None
    last_error: str | None
    lora_status: str | None
    lora_ready: bool


@dataclass
class LoraAdapter:
    lora_name: str
    memory_group: str
    status: str
    active_version: int
    created_at: int
    updated_at: int
