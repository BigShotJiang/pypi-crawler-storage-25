# Publishing

Build the package locally before uploading:

```bash
uv build --no-sources
```

This writes a wheel and source distribution to `dist/`. Check those files before publishing.

## TestPyPI

```bash
export UV_PUBLISH_TOKEN=pypi-...
uv publish \
  --publish-url https://test.pypi.org/legacy/ \
  --check-url https://test.pypi.org/simple/
```

## PyPI

```bash
export UV_PUBLISH_TOKEN=pypi-...
uv publish
```
