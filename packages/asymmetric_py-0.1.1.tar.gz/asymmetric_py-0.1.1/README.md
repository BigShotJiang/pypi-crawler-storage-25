<h1 align="center">asymmetric-py</h1>

Read the docs at https://asymmetric.sh/docs


## Install

```bash
pip install asymmetric-py
```

## Usage

```python
from asymmetric import Asymmetric, GuardrailViolation

client = Asymmetric(api_key="sk_live_...")
```

### Guardrails

#### Basic completion

```python
try:
    response = client.chat.completions.create(
        model="openai/gpt-4o-mini",
        messages=[{"role": "user", "content": "Tell me about Caltech"}],
        guardrail_policy="Flag any content mentioning Caltech",
    )
    print(response.choices[0].message.content)
except GuardrailViolation as e:
    print(e.policy)
```

#### Streaming

```python
try:
    for chunk in client.chat.completions.create(
        model="openai/gpt-4o-mini",
        messages=[{"role": "user", "content": "Tell me about Caltech"}],
        guardrail_policy="Flag any content mentioning Caltech",
        stream=True,
    ):
        if chunk.choices[0].delta.content:
            print(chunk.choices[0].delta.content, end="")
except GuardrailViolation as e:
    print(f"\nViolation: {e.policy}")
```

#### Multiple policies

```python
response = client.chat.completions.create(
    model="openai/gpt-4o-mini",
    messages=[{"role": "user", "content": "Hello"}],
    guardrail_policy=[
        "Flag any content promoting violence",
        "Flag any content containing profanity",
    ],
)
```

#### Violation history

```python
violations = client.guardrails.list_violations()
for v in violations:
    print(v.timestamp, v.guardrail_policy)
```

### Memories

#### Log and use memories in a request

```python
response = client.chat.completions.create(
    model="openai/gpt-4o-mini",
    messages=[{"role": "user", "content": "What did Darwin discover?"}],
    memory=[
        {"group": "darwin_agent", "goal": "Historical records about Darwin"}
    ],
)
print(response.choices[0].message.content)
```

### Finetuning

#### Trigger training and inspect status

```python
job = client.finetuning.train(
    memory_group="darwin_agent",
    lora_name="darwin_adapter",
)
print(job.status, job.message)

status = client.finetuning.status(
    memory_group="darwin_agent",
    lora_name="darwin_adapter",
)
print(f"Ready: {status.lora_ready}")

# List all adapters
adapters = client.finetuning.list()
for a in adapters:
    print(f"{a.lora_name}: {a.status}")
```

#### LoRA inference

```python
response = client.chat.completions.create(
    model="asymmetric/Qwen3-8B",
    messages=[{"role": "user", "content": "Tell me about Darwin's voyages"}],
    finetuning={"lora_name": "darwin_adapter"},
)
print(response.choices[0].message.content)
```

#### Auto-training with memory

```python
response = client.chat.completions.create(
    model="openai/gpt-4o-mini",
    messages=[{"role": "user", "content": "What did Darwin discover?"}],
    memory=[{"group": "darwin_agent", "goal": "Historical records about Darwin"}],
    finetuning={
        "lora_name": "darwin_adapter",
        "finetune_thresh": 3,
        "min_finetune_group": 5,
    },
)
```
