import json

import httpx
import pytest

from asymmetric import Asymmetric, GuardrailViolation


def make_client(handler):
    client = Asymmetric(api_key="test-key", base_url="https://api.example.com/")
    client._http.close()
    client._http = httpx.Client(
        transport=httpx.MockTransport(handler),
        base_url="https://api.example.com",
        headers={
            "Authorization": "Bearer test-key",
            "Content-Type": "application/json",
        },
    )
    return client


def test_chat_completion_builds_expected_request():
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "POST"
        assert str(request.url) == "https://api.example.com/v1/chat/completions"
        assert request.headers["Authorization"] == "Bearer test-key"

        body = json.loads(request.content)
        assert body == {
            "model": "openai/gpt-4o-mini",
            "messages": [{"role": "user", "content": "Hello"}],
            "stream": False,
            "temperature": 0.2,
            "guardrail_policy": "No secrets",
            "chunk_size": 12,
            "sliding_window": 3,
            "lora_name": "adapter-v1",
        }

        return httpx.Response(
            200,
            json={
                "id": "chatcmpl_123",
                "model": "openai/gpt-4o-mini",
                "choices": [
                    {
                        "message": {"role": "assistant", "content": "Hi"},
                        "finish_reason": "stop",
                    }
                ],
                "usage": {
                    "prompt_tokens": 1,
                    "completion_tokens": 1,
                    "total_tokens": 2,
                },
            },
        )

    client = make_client(handler)

    try:
        completion = client.chat.completions.create(
            model="openai/gpt-4o-mini",
            messages=[{"role": "user", "content": "Hello"}],
            guardrail_policy="No secrets",
            chunk_size=12,
            sliding_window=3,
            finetuning={"lora_name": "adapter-v1"},
            temperature=0.2,
        )
    finally:
        client.close()

    assert completion.choices[0].message.content == "Hi"
    assert completion.usage is not None
    assert completion.usage.total_tokens == 2


def test_chat_completion_raises_guardrail_violation():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            400,
            json={
                "detail": "Guardrail violation detected. Policy: 'No secrets'. "
                "Text in violation: 'secret token'"
            },
        )

    client = make_client(handler)

    try:
        with pytest.raises(GuardrailViolation) as exc_info:
            client.chat.completions.create(
                model="openai/gpt-4o-mini",
                messages=[{"role": "user", "content": "Hello"}],
            )
    finally:
        client.close()

    assert exc_info.value.policy == "No secrets"
    assert exc_info.value.text == "secret token"


def test_streaming_chat_completion_yields_chunks():
    payload = (
        'data: {"id":"chatcmpl_123","model":"openai/gpt-4o-mini",'
        '"choices":[{"delta":{"role":"assistant","content":"Hi"}}]}\n\n'
        'data: {"id":"chatcmpl_123","model":"openai/gpt-4o-mini",'
        '"choices":[{"delta":{"content":" there"},"finish_reason":"stop"}]}\n\n'
        "data: [DONE]\n\n"
    )

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, text=payload)

    client = make_client(handler)

    try:
        chunks = list(
            client.chat.completions.create(
                model="openai/gpt-4o-mini",
                messages=[{"role": "user", "content": "Hello"}],
                stream=True,
            )
        )
    finally:
        client.close()

    assert [chunk.choices[0].delta.content for chunk in chunks] == ["Hi", " there"]
    assert chunks[0].choices[0].delta.role == "assistant"
    assert chunks[-1].choices[0].finish_reason == "stop"


def test_list_violations_parses_response():
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "GET"
        assert str(request.url) == "https://api.example.com/guardrail/violations"
        return httpx.Response(
            200,
            json={
                "violations": [
                    {
                        "id": "vio_123",
                        "timestamp": "2026-04-04T12:00:00Z",
                        "user_input": "hello",
                        "model_output": "blocked",
                        "guardrail_policy": "No secrets",
                    }
                ]
            },
        )

    client = make_client(handler)

    try:
        violations = client.guardrails.list_violations()
    finally:
        client.close()

    assert len(violations) == 1
    assert violations[0].guardrail_policy == "No secrets"


def test_finetuning_status_parses_response():
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "GET"
        assert str(request.url) == (
            "https://api.example.com/finetuning/status"
            "?memory_group=darwin&lora_name=adapter-v1"
        )
        return httpx.Response(
            200,
            json={
                "memory_group": "darwin",
                "lora_name": "adapter-v1",
                "queued_count": 1,
                "trained_count": 4,
                "training_status": "ready",
                "current_version": 2,
                "last_training_started": 10,
                "last_training_completed": 20,
                "last_error": None,
                "lora_status": "ready",
                "lora_ready": True,
            },
        )

    client = make_client(handler)

    try:
        status = client.finetuning.status("darwin", "adapter-v1")
    finally:
        client.close()

    assert status.current_version == 2
    assert status.lora_ready is True
