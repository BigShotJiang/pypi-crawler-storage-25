"""
satellite_plotting.py

This module provides plotting functions for satellite associated modules

"""

class Plotting_tools:
    def __init__(self,satellite=[]):
        self.satellite = satellite

    def plot_lonlat_info(self,lonlat_step,extracted_lon_range=[],extracted_lat_range=[]):
        import numpy as np
        if len(extracted_lon_range)<1:
            lon_s = self.lon_range[0]
            lon_e = self.lon_range[1]
        else:
            lon_s = extracted_lon_range[0]
            lon_e = extracted_lon_range[1]

        if  len(extracted_lat_range)<1:
            lat_s = self.lat_range[0]
            lat_e = self.lat_range[1]
        else:
            lat_s = extracted_lat_range[0]
            lat_e = extracted_lat_range[1]

        lon_range = lon_e - lon_s
        lat_range = lat_e - lat_s
        if lonlat_step == 1:
            step_gap = 1
        else:
            step_gap = lonlat_step-1
#        lon_step = np.floor((lon_range)/(step_gap))
#        lat_step = np.floor((lat_range)/(step_gap))
#        if lat_step < 1:
#            lat_step = 1
##
        lon_step = (lon_range)/(step_gap)
        lat_step = (lat_range)/(step_gap)
        if 0.75 <= lon_step <= 1:
            lon_step = 1
        elif 0.35 <= lon_step < 0.75:
            lon_step = 0.5
        elif lon_step < 0.35:
            lon_step = 0.2
        else:
            lon_step = np.floor(lon_step)
        if 0.75 <= lat_step <= 1:
            lat_step = 1
        elif 0.35 <= lat_step < 0.75:
            lat_step = 0.5
        elif lat_step < 0.35:
            lat_step = 0.2
        else:
            lat_step = np.floor(lat_step)

##
        return(lon_s,lon_e,lat_s,lat_e,lon_range,lat_range,lon_step,lat_step)

    def plot_basemap_unit(self,lon_s,lon_e,lat_s,lat_e,
                          lon_range,lat_range,lon_step,lat_step,
                          coast_line_color='olive',coast_line_width=1.3,coast_res='i',
                          lonlat_c='k',lonlat_width=0.01,lonlat_order=1,font_size=24):
        import numpy as np
        import matplotlib.pyplot as plt
        from mpl_toolkits.basemap import Basemap
        if lon_range > lat_range:
            fig,ax1 = plt.subplots(1,1,figsize=(13*(lon_range/lat_range),13.3),tight_layout=True)
        else:
            fig,ax1 = plt.subplots(1,1,figsize=(13,13.4*(lat_range/lon_range)),tight_layout=True)
        m = Basemap(llcrnrlon=lon_s, urcrnrlon=lon_e, llcrnrlat=lat_s, urcrnrlat=lat_e,resolution=coast_res)
        m.drawparallels(np.arange(lat_s, lat_e+1, lat_step),
                        labels=[1, 0, 0, 0], linewidth=lonlat_width, color=lonlat_c,
                        fontsize=font_size-2,zorder=lonlat_order)
        m.drawmeridians(np.arange(lon_s, lon_e+1, lon_step),
                        labels=[0, 0, 0, 1], linewidth=lonlat_width, color=lonlat_c,
                        fontsize=font_size-2,zorder=lonlat_order)
        m.drawcoastlines(linewidth=coast_line_width,color=coast_line_color,zorder=3)
        return(ax1,m,fig)
   
    def plot_hima_band_data_unit(self,band_array,plotting_lon_list,plotting_lat_list,
                                 m,
                                 tbb_range=[180,300],cmap='Greys'):
        import numpy as np
        import matplotlib.pyplot as plt
        from mpl_toolkits.basemap import Basemap

        #### rgb band
        xi, yi = np.meshgrid(plotting_lon_list,plotting_lat_list)
        band_array_shape = band_array.shape
        if len(band_array_shape)>2:
            plot_array = np.where(np.isnan(band_array), 0, band_array)
            hima_plot = m.pcolormesh(xi,yi,plot_array)
            return(hima_plot, ['rgb'])
        else:
        #### single band
            if len(tbb_range) < 1:
                bt_min = int(round(np.min(band_array),-1)+10)
                bt_max = int(round(np.max(band_array),-1)-10)
                #print(bt_min,bt_max)
            else:
                bt_min = tbb_range[0]
                bt_max = tbb_range[1]
            hima_plot = m.pcolormesh(xi,yi,band_array,vmin=bt_min,vmax=bt_max,cmap=cmap)
            return(hima_plot, [bt_min, bt_max])


    def plot_profile_unit(self,profile_data,x_axis,reference_hei,shading='contourf',color_map=[],value_range=[0,100],extend='min',zorder=2):
        import numpy as np
        import matplotlib.pyplot as plt
        if shading == 'pcolormesh':
            prof = plt.pcolormesh(x_axis,reference_hei,profile_data,
                                cmap=color_map,
                                vmin=value_range[0],vmax=value_range[1],
                                zorder=2)
        if shading == 'contourf':
            prof = plt.contourf(x_axis,reference_hei,profile_data,
                                cmap=color_map,extend=extend,
                                levels=np.arange(value_range[0],value_range[1]+0.05,0.1),zorder=2)
        return(prof)

    def plot_title_unit(self,title,loc='left',pad=40,font_size=24):
### figure info
        import matplotlib.pyplot as plt
        plt.title(title,loc=loc,fontsize=font_size,pad=pad)

    def save_fig_unit(self,figure_main,figure_name=[],prefix=[],
                      dpi=300, figure_path=[],save_fig=True):
        from pathlib import Path
        import matplotlib.pyplot as plt

        if save_fig:
            if figure_path == None or figure_path == []:
                figure_path = ''+str(self.work_path)+'/'
            else:
                Path(figure_path).mkdir(parents=True, exist_ok=True)
                figure_path = ''+str(figure_path)+'/'

            if len(figure_name)>0:
                figure_main = ''+figure_name+'_'+figure_main+''
            plt.savefig(''+figure_path+''+prefix+'_'+figure_main+'.png',dpi=dpi)

    def plot_timezone_unit(self,ax1,lon_s,lon_e,lat_s,lat_e,lat_range,
                           font_size=24,utc_label=True,night_time_label=False,
                           timezone_gradient=True):
        import numpy as np
        import matplotlib.pyplot as plt
        from matplotlib.patches import Polygon
        import matplotlib.cm as cm
### time zone
        lon_min = np.arange(-7.5,353,15)
        lon_max = np.arange(7.5,368,15)
        lat_min, lat_max = lat_s, lat_e
        if night_time_label:
            color_step, local_ref_time_day,local_ref_time_night = self.cloudsat_string_info(night_time=night_time_label)
        else:
            color_step, local_ref_time_day = self.cloudsat_string_info()
        cmap = cm.get_cmap('Blues_r', len(lon_min)*3)
        zone_num = int((lon_e+7.5)/15)+1
        if zone_num >25:
           zone_num = 25
        for j in range(int((lon_s+7.5)/15),zone_num):
            polygon = [(lon_min[j], -90), (lon_max[j], -90), (lon_max[j], 90), (lon_min[j], 90)]
            if timezone_gradient:
                color = cmap(color_step[j]*3 / len(lon_min))
            else:
                color = 'aliceblue'
            poly_map = Polygon(polygon, edgecolor='thistle', facecolor=color, alpha=1, linewidth=2)
            ax1.add_patch(poly_map)
            utc_pos = (lon_max[j] + lon_min[j])/2
            
            if utc_pos < lon_s:
                utc_pos = lon_s
            if utc_pos > lon_e:
                utc_pos = lon_e
            if utc_label:
                if night_time_label:
                    plt.text(utc_pos,lat_max+(lat_range/180),
                             f"{local_ref_time_day[j]} & {local_ref_time_night[j]}UTC",c='teal',
                             fontsize=font_size-2, fontweight='bold',
                             va='bottom',ha='center',
                             bbox=dict(facecolor='ghostwhite', edgecolor='indigo', boxstyle='round,pad=0.1'),zorder=6)
                else:
                    plt.text(utc_pos,lat_max+(lat_range/180),
                             f"{local_ref_time_day[j]}UTC",c='teal',
                             fontsize=font_size-2, fontweight='bold',
                             va='bottom',ha='center',
                             bbox=dict(facecolor='ghostwhite', edgecolor='indigo', boxstyle='round,pad=0.1'),zorder=6)

    def plot_arrow_unit(self,ax1,plot_lon,plot_lat,lon_range,lat_range,quiver_len,
                        track_dir_pos='edge'):
        plot_lon = self.check_list(plot_lon)
        plot_lat = self.check_list(plot_lat)
        track_num = len(plot_lon)
        for t in range(track_num):
            #### track dir at edge
            #print(quiver_len)
            if len(plot_lon[t]) >= quiver_len:
                if track_dir_pos == 'edge':
                    arrow_lon = plot_lon[t][-quiver_len]
                    arrow_lat = plot_lat[t][-quiver_len]
                    arrow_dir_lon = (plot_lon[t][-1]-plot_lon[t][-quiver_len])
                    arrow_dir_lat = (plot_lat[t][-1]-plot_lat[t][-quiver_len])
                #### track dir at center
                else:
                    id_pos = int(len(plot_lon[t])/2)
                    half_len = int(quiver_len/2)
                    arrow_lon = plot_lon[t][id_pos-half_len]
                    arrow_lat = plot_lat[t][id_pos-half_len]
                    arrow_dir_lon = (plot_lon[t][id_pos+half_len]-plot_lon[t][id_pos-half_len])
                    arrow_dir_lat = (plot_lat[t][id_pos+half_len]-plot_lat[t][id_pos-half_len])
                ax1.quiver(arrow_lon, arrow_lat, 
                           arrow_dir_lon, arrow_dir_lat,
                           angles="xy",scale_units="xy",
                           color='floralwhite',edgecolor='black',
                           linewidth=1,alpha=1,scale=1,
                           width=0.00485/(lon_range/lat_range),zorder=5)

    """
    color map
    """
    def customized_colormap(self,color_map_name):
        color_map_name = self.check_list(color_map_name)
        color_map = color_map_name[0] 
        method = getattr(self, color_map)
        output_color_map = method()
        return(output_color_map)

    def light_YlGnBu(self):
        import matplotlib.colors as mcolors
        ### colormap setting
        light_YlGnBu = mcolors.LinearSegmentedColormap.from_list(
            "light_YlGnBu", ["#ffffcc", "#a1dab4", "#41b6c4", "#2c7fb8", "#2870c9"], N=256)
        light_YlGnBu.set_under((1, 1, 1, 0))
        return(light_YlGnBu)

    """
    track color tools
    """
    def get_track_colors(self, plot_lat,lat_trans_top=60.0,lat_trans_bot=50.0,
                         color_ascending = [0.09803921568627451, 0.09803921568627451, 0.4392156862745098, 1.0],
                         color_descending = [1.0, 0.27058823529411763, 0.0, 1.0],
                         color_polar = [0.7803921568627451, 0.08235294117647059, 0.5215686274509804, 1.0]
                        ):
        import numpy as np
        """
        EarthCARE ascending  --> night
                  descending --> day
        CloudSat  ascending  --> day
                  descending --> night
        """
        # track moving direction
        plot_lat = self.check_list(plot_lat)
        plot_lat[0].shape
        if len(plot_lat[0].shape) < 2:
            plot_lat[0] = plot_lat[0][:,None]
        dlat = np.diff(plot_lat[0][:,0], prepend=plot_lat[0][0])
        is_ascending = dlat > 0      # lat increase; ascending
        #is_descending = dlat < 0     # lat decrease; descending
        # color
        COLOR_ASCEND = np.array(color_ascending)      # Default midnightblue 
        COLOR_DESCEND   = np.array(color_descending)  # Default orangered
        COLOR_POLAR = np.array(color_polar)           # Default mediumvioletred
        #track_colors = np.zeros((len(plot_lat[0]), 4))
        alat = abs(plot_lat[0])
        base_colors = np.where(is_ascending[:, None],COLOR_ASCEND,COLOR_DESCEND)
        w = self.transition_weight(alat,
                                   lat_trans_top=lat_trans_top,
                                   lat_trans_bot=lat_trans_bot)
        track_colors = (1 - w) * base_colors + w * COLOR_POLAR
        track_colors[alat[:,0]>=67.5] = COLOR_POLAR
        #for j in range(len(plot_lat[0])):
        #    alat = abs(plot_lat[0][j])
        #    # polar region
        #    if alat >= 67.5:
        #        track_colors[j] = COLOR_POLAR
        #        continue
        #    # day night base color
        #    base_color = COLOR_ASCEND if is_ascending[j] else COLOR_DESCEND
        #    # transition area
        #    w = self.transition_weight(alat,
        #                               lat_trans_top=lat_trans_top,
        #                               lat_trans_bot=lat_trans_bot)
        #    # linear combine color
        #    track_colors[j] = (1 - w) * base_color + w * COLOR_POLAR
        return track_colors

    def transition_weight(self,abs_lat,lat_trans_top=60.0,lat_trans_bot=50):
        import numpy as np
        """
        Lat 50 --> 0
        Lat 60 --> 1
        """
        w = (np.abs(abs_lat) - lat_trans_bot) / (lat_trans_top - lat_trans_bot)
        return np.clip(w, 0.0, 1.0)


