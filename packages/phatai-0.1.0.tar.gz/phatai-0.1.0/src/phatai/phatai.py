
class Phatai:
    full_name = "Nguyen Tan Phat"
    major = "Mecatronic"
    job = "Computer vision research engineer"
    
    def handsome(self):
        return "Phat AI so handsome."