# Copyright 2024 OpenSynergy Indonesia
# Copyright 2024 PT. Simetri Sinergi Indonesia
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl-3.0-standalone.html).
{
    "name": "Letter Management - Work Log Integration",
    "version": "14.0.1.3.0",
    "contributors": ["Andhitia Rama <andhitia.r@gmail.com>"],
    "website": "https://simetri-sinergi.id",
    "author": "OpenSynergy Indonesia, PT. Simetri Sinergi Indonesia",
    "license": "AGPL-3",
    "installable": True,
    "depends": [
        "ssi_letter",
        "ssi_work_log_mixin",
    ],
    "data": [],
    "demo": [],
    "images": [],
}
