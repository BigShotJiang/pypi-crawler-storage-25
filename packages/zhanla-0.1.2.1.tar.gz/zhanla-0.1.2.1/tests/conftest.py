"""Test bootstrap for source-tree CLI runs."""
from pathlib import Path
import sys

import pytest


_REPO_ROOT = Path(__file__).resolve().parents[3]
for package_dir in (
    _REPO_ROOT / "packages" / "sdk-py",
    _REPO_ROOT / "packages" / "cli",
):
    package_path = str(package_dir)
    if package_path not in sys.path:
        sys.path.insert(0, package_path)

import zhanla.store as store
from zhanla.registry import registry


@pytest.fixture(autouse=True)
def _clean_bench_state():
    registry.clear()
    store.clear()
    yield
    registry.clear()
    store.clear()
