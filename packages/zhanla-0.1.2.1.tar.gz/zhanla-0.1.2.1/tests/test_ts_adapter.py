from __future__ import annotations

import pytest

from zhanla import Tool
from zhanla_cli.manifest import ComponentManifest
from zhanla_cli.ts_adapter import build_manifest_component, ts_result_to_traces


def _tool() -> Tool:
    return Tool(
        name="double",
        description="d",
        input_schema={},
        fn=lambda x: {"result": x * 2},
        output_schema={"result": int},
        key="double",
    )


def test_build_manifest_component_preserves_manifest_key() -> None:
    manifest = ComponentManifest(
        name="double",
        description="d",
        component_type="tool",
        key="double-key",
        key_source="explicit",
        language="typescript",
        is_runnable=True,
        is_eval=False,
        execution_mode="code",
        fn_present=True,
        output_schema={"type": "object", "properties": {"result": {"type": "number"}}},
        source_language="typescript",
    )

    component = build_manifest_component(manifest, [manifest])

    assert component.key == "double-key"
    assert component.component_type.value == "tool"


def test_ts_result_to_traces_maps_path_taken() -> None:
    component = _tool()
    row = {"x": 2}
    row_result = {
        "status": "ok",
        "output": {"result": 4},
        "pathTaken": {
            "kind": "tool",
            "function_definition": {"name": "double", "description": "d"},
            "input": {"x": 2},
            "output": {"result": 4},
        },
    }

    component_trace, eval_trace = ts_result_to_traces(
        row=row,
        row_result=row_result,
        component=component,
        eval_component=None,
        trigger_run_id="run-1",
    )

    assert eval_trace is None
    assert component_trace.path_taken is not None
    assert component_trace.path_taken["kind"] == "tool"


def test_ts_result_to_traces_missing_path_taken_is_none() -> None:
    component = _tool()
    row = {"x": 3}
    row_result = {
        "status": "ok",
        "output": {"result": 6},
    }

    component_trace, _ = ts_result_to_traces(
        row=row,
        row_result=row_result,
        component=component,
        eval_component=None,
        trigger_run_id="run-2",
    )

    assert component_trace.path_taken is None


@pytest.mark.parametrize(
    "payload",
    [
        "not-an-object",
        {"kind": "llm_processor"},
        {"kind": 123},
    ],
)
def test_ts_result_to_traces_invalid_path_taken_is_none(payload: object) -> None:
    component = _tool()
    row_result = {
        "status": "ok",
        "output": {"result": 1},
        "pathTaken": payload,
    }

    component_trace, _ = ts_result_to_traces(
        row={"x": 1},
        row_result=row_result,
        component=component,
        eval_component=None,
        trigger_run_id="run-3",
    )

    assert component_trace.path_taken is None
