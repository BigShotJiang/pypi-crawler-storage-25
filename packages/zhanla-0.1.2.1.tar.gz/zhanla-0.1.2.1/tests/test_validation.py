"""Tests for class-based component validation."""
from __future__ import annotations

import zhanla as bench
from zhanla_cli.discovery import validate_component, validate_components


# ---------------------------------------------------------------------------
# Phase 1: Structure validation
# ---------------------------------------------------------------------------

def test_valid_tool_passes() -> None:
    def fn(x: int) -> dict:
        return {"result": x}

    t = bench.Tool(name="valid_tool", description="d", input_schema={}, fn=fn, output_schema={"result": int}, key="valid-tool")
    assert validate_component(t) == []


def test_tool_missing_output_schema() -> None:
    def fn(x: int) -> dict:
        return {"result": x}

    # Bypass __init__ validation by setting output_schema to None after construction
    t = bench.Tool(name="t", description="d", input_schema={}, fn=fn, output_schema={"r": int}, key="t")
    t.output_schema = None
    errors = validate_component(t)
    assert any("output_schema" in e for e in errors)


def test_skill_missing_instructions() -> None:
    s = bench.Skill(name="s", description="d", instructions="do stuff", key="s")
    s.instructions = ""
    errors = validate_component(s)
    assert any("instructions" in e for e in errors)


def test_agent_missing_model() -> None:
    a = bench.Agent(name="a", description="d", instructions="i", model="gpt-4o", key="a")
    a.model = ""
    errors = validate_component(a)
    assert any("model" in e for e in errors)


def test_llm_processor_missing_model() -> None:
    p = bench.LLMProcessor(name="p", description="d", instructions="i", model="gpt-4o", key="p")
    p.model = ""
    errors = validate_component(p)
    assert any("model" in e for e in errors)


def test_llm_eval_missing_instructions() -> None:
    e = bench.LLMEval(name="e", description="d", instructions="i", model="gpt-4o", key="e")
    e.instructions = ""
    errors = validate_component(e)
    assert any("instructions" in e_msg for e_msg in errors)


def test_orchestration_cycle_detection() -> None:
    def fn(x: int) -> dict:
        return {"result": x}

    t = bench.Tool(name="t", description="d", input_schema={}, fn=fn, output_schema={"result": int}, key="t")
    o = bench.Orchestration(
        name="cyclic",
        description="d",
        steps=[
            bench.Step(component=t, name="a", next=["b"]),
            bench.Step(component=t, name="b", next=["a"]),
        ],
        key="cyclic",
    )
    errors = validate_component(o)
    assert any("cycle" in e for e in errors)


def test_orchestration_dangling_next() -> None:
    def fn(x: int) -> dict:
        return {"result": x}

    t = bench.Tool(name="t", description="d", input_schema={}, fn=fn, output_schema={"result": int}, key="t")
    o = bench.Orchestration(
        name="dangling",
        description="d",
        steps=[
            bench.Step(component=t, name="a", next=["nonexistent"]),
        ],
        key="dangling",
    )
    errors = validate_component(o)
    assert any("unknown step" in e for e in errors)


def test_conditional_references_validated() -> None:
    def fn(x: int) -> dict:
        return {"result": x}

    t = bench.Tool(name="t", description="d", input_schema={}, fn=fn, output_schema={"result": int}, key="t")
    o = bench.Orchestration(
        name="bad_cond",
        description="d",
        steps=[
            bench.Step(
                component=bench.Conditional(
                    condition=lambda x: True,
                    if_true="missing_step",
                    if_false="also_missing",
                ),
                name="route",
            ),
        ],
        key="bad-cond",
    )
    errors = validate_component(o)
    assert any("unknown step" in e for e in errors)


def test_checklist_weights_length_mismatch() -> None:
    def fn(output: str) -> dict:
        return {"score": 1.0}

    e1 = bench.CodeEval(name="e1", description="d", fn=fn, key="e1")
    c = bench.Checklist(
        name="c", description="d",
        evals=[e1],
        weights=[0.5, 0.5],  # too many weights
        key="c",
    )
    errors = validate_component(c)
    assert any("weights must match" in e for e in errors)


def test_checklist_negative_weights() -> None:
    def fn(output: str) -> dict:
        return {"score": 1.0}

    e1 = bench.CodeEval(name="e1", description="d", fn=fn, key="e1")
    c = bench.Checklist(
        name="c", description="d",
        evals=[e1],
        weights=[-0.5],
        key="c",
    )
    errors = validate_component(c)
    assert any("positive" in e for e in errors)


def test_eval_tree_threshold_out_of_range() -> None:
    def fn(output: str) -> dict:
        return {"score": 0.5}

    e = bench.CodeEval(name="e", description="d", fn=fn, key="e")
    tree = bench.EvalTree(
        name="bad_tree",
        description="d",
        root=bench.Branch(
            eval=e,
            threshold=1.5,  # out of range
            if_pass=[bench.Edge(weight=1.0, node=bench.Leaf(eval=e))],
            if_fail=[bench.Edge(weight=1.0, node=bench.Leaf(eval=e))],
        ),
        key="bad-tree",
    )
    errors = validate_component(tree)
    assert any("threshold" in e_msg for e_msg in errors)


def test_eval_tree_negative_edge_weight() -> None:
    def fn(output: str) -> dict:
        return {"score": 0.5}

    e = bench.CodeEval(name="e", description="d", fn=fn, key="e")
    tree = bench.EvalTree(
        name="bad_weight",
        description="d",
        root=bench.Branch(
            eval=e,
            threshold=0.5,
            if_pass=[bench.Edge(weight=-1.0, node=bench.Leaf(eval=e))],
            if_fail=[bench.Edge(weight=1.0, node=bench.Leaf(eval=e))],
        ),
        key="bad-weight",
    )
    errors = validate_component(tree)
    assert any("positive" in e_msg for e_msg in errors)


def test_validate_components_returns_prefixed_errors() -> None:
    a = bench.Agent(name="a", description="d", instructions="i", model="gpt-4o", key="a")
    a.model = ""
    issues = validate_components([a])
    assert all(i.startswith("ERROR:") for i in issues)
    assert len(issues) > 0
