"""Tests for the bench CLI main commands — class-based model."""
from __future__ import annotations

import builtins
import importlib
import sys
import types
from pathlib import Path

from typer.testing import CliRunner

from zhanla_cli import auth
from zhanla_cli.manifest import ComponentManifest
from zhanla_cli.main import _get_base_url, app

runner = CliRunner()


def _write_component(tmp_path: Path) -> Path:
    module_path = tmp_path / "component.py"
    module_path.write_text(
        "import zhanla as bench\n\n"
        "def fn(x: int = 1) -> dict:\n"
        "    return {'v': x}\n\n"
        "test_tool = bench.Tool(\n"
        "    name='test_tool',\n"
        "    description='A test tool',\n"
        "    input_schema={},\n"
        "    fn=fn,\n"
        "    output_schema={'v': int},\n"
        "    key='test-tool',\n"
        ")\n"
    )
    return module_path


def _write_eval(tmp_path: Path) -> Path:
    eval_path = tmp_path / "evaluator.py"
    eval_path.write_text(
        "import zhanla as bench\n\n"
        "def score_fn(**kwargs) -> dict:\n"
        "    return {'score': 0.9}\n\n"
        "test_scorer = bench.CodeEval(\n"
        "    name='test_scorer',\n"
        "    description='A test scorer',\n"
        "    fn=score_fn,\n"
        "    key='test-scorer',\n"
        ")\n"
    )
    return eval_path


def _write_dataset(tmp_path: Path) -> Path:
    dataset_path = tmp_path / "data.json"
    dataset_path.write_text('[{"x": 1}, {"x": 2}]')
    return dataset_path


_EXECUTION_MODE_MAP = {
    "tool": "code",
    "code_eval": "code",
    "orchestration": "dag",
    "skill": "prompt",
    "agent": "prompt",
    "llm_processor": "prompt",
    "llm_eval": "prompt",
    "checklist": "composite",
    "eval_tree": "composite",
}


def _ts_manifest(
    *,
    name: str,
    component_type: str,
    is_runnable: bool,
    is_eval: bool,
    file_path: str,
    symbol_name: str | None = None,
    **extra,
) -> ComponentManifest:
    return ComponentManifest(
        name=name,
        description=f"{name} description",
        component_type=component_type,
        key=name,
        key_source="explicit",
        language="typescript",
        is_runnable=is_runnable,
        is_eval=is_eval,
        execution_mode=_EXECUTION_MODE_MAP.get(component_type, "unknown"),
        file_path=file_path,
        symbol_name=symbol_name or name,
        **extra,
    )


def test_list_without_subcommand_shows_help() -> None:
    result = runner.invoke(app, ["list"])
    assert result.exit_code == 0
    assert "datasets" in result.output
    assert "autoraters" in result.output
    assert "Missing command" not in result.output


def test_root_help_makes_list_subcommands_explicit() -> None:
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "list datasets" in result.output
    assert "list autoraters" in result.output


def test_get_base_url_defaults_to_prod_even_when_next_public_app_url_is_set(monkeypatch) -> None:
    monkeypatch.delenv("BENCH_BASE_URL", raising=False)
    monkeypatch.setenv("NEXT_PUBLIC_APP_URL", "http://localhost:3000/")

    assert _get_base_url() == "https://benchmark-black.vercel.app"


def test_list_datasets_uses_sdk_api(tmp_path: Path, monkeypatch) -> None:
    creds_path = tmp_path / "creds" / "credentials.json"
    monkeypatch.setattr(auth, "CREDENTIALS_PATH", creds_path)
    auth.save_credentials(
        {
            "key_id": "bm_kid_test",
            "secret": "bm_sec_test",
            "supabase_url": "https://example.com",
            "supabase_anon_key": "anon",
            "org_id": "org-1",
        }
    )

    monkeypatch.setattr(
        "zhanla_cli.auth.get_fresh_token",
        lambda _base_url: {
            "supabase_url": "https://example.com",
            "supabase_anon_key": "anon",
            "access_token": "token",
            "org_id": "org-1",
        },
    )

    captured: dict = {}

    def fake_list_web_datasets(**kwargs):
        captured.update(kwargs)
        return [
            {
                "id": "dataset-1",
                "name": "tickets",
                "created_at": "2026-04-25T03:03:30Z",
            }
        ]

    monkeypatch.setattr("zhanla_cli.web.list_web_datasets", fake_list_web_datasets)
    monkeypatch.delenv("BENCH_BASE_URL", raising=False)
    monkeypatch.setenv("NEXT_PUBLIC_APP_URL", "http://localhost:3000")

    result = runner.invoke(app, ["list", "datasets"])

    assert result.exit_code == 0
    assert captured["base_url"] == "https://benchmark-black.vercel.app"
    assert captured["org_id"] == "org-1"
    assert "dataset-1" in result.output
    assert "tickets" in result.output


def test_list_autoraters_uses_sdk_api(tmp_path: Path, monkeypatch) -> None:
    creds_path = tmp_path / "creds" / "credentials.json"
    monkeypatch.setattr(auth, "CREDENTIALS_PATH", creds_path)
    auth.save_credentials(
        {
            "key_id": "bm_kid_test",
            "secret": "bm_sec_test",
            "supabase_url": "https://example.com",
            "supabase_anon_key": "anon",
            "org_id": "org-1",
        }
    )

    monkeypatch.setattr(
        "zhanla_cli.auth.get_fresh_token",
        lambda _base_url: {
            "supabase_url": "https://example.com",
            "supabase_anon_key": "anon",
            "access_token": "token",
            "org_id": "org-1",
        },
    )

    captured: dict = {}

    def fake_list_web_autoraters(**kwargs):
        captured.update(kwargs)
        return [
            {
                "id": "autorater-1",
                "name": "lead_segment_eval",
                "owner_id": "tool-1",
                "owner_type": "tool",
                "created_at": "2026-04-28T04:12:09Z",
            }
        ]

    monkeypatch.setattr("zhanla_cli.web.list_web_autoraters", fake_list_web_autoraters)
    monkeypatch.delenv("BENCH_BASE_URL", raising=False)
    monkeypatch.setenv("NEXT_PUBLIC_APP_URL", "http://localhost:3000")

    result = runner.invoke(app, ["list", "autoraters"])

    assert result.exit_code == 0
    assert captured["base_url"] == "https://benchmark-black.vercel.app"
    assert captured["org_id"] == "org-1"
    assert "autorater-1" in result.output
    assert "lead_segment_eval" in result.output


def test_list_datasets_not_logged_in_exits_1(tmp_path: Path, monkeypatch) -> None:
    creds_path = tmp_path / "no_creds" / "credentials.json"
    monkeypatch.setattr(auth, "CREDENTIALS_PATH", creds_path)

    result = runner.invoke(app, ["list", "datasets"])

    assert result.exit_code == 1
    assert "Not logged in" in result.output
    assert "Traceback" not in result.output


def test_list_datasets_invalid_saved_login_exits_1(tmp_path: Path, monkeypatch) -> None:
    creds_path = tmp_path / "creds" / "credentials.json"
    creds_path.parent.mkdir(parents=True, exist_ok=True)
    creds_path.write_text("{}")
    monkeypatch.setattr(auth, "CREDENTIALS_PATH", creds_path)

    result = runner.invoke(app, ["list", "datasets"])

    assert result.exit_code == 1
    assert "Run `zhanla login` again" in result.output
    assert "Traceback" not in result.output


def test_run_not_logged_in_exits_1(tmp_path: Path, monkeypatch) -> None:
    module_path = _write_component(tmp_path)
    eval_path = _write_eval(tmp_path)
    dataset_path = _write_dataset(tmp_path)
    creds_path = tmp_path / "no_creds" / "credentials.json"
    monkeypatch.setattr(auth, "CREDENTIALS_PATH", creds_path)

    result = runner.invoke(app, [
        "run", f"{module_path}:test_tool",
        "--eval", str(eval_path),
        "--dataset", str(dataset_path),
    ])
    assert result.exit_code == 1
    assert "Not logged in" in result.output


def test_run_invalid_saved_login_exits_1(tmp_path: Path, monkeypatch) -> None:
    module_path = _write_component(tmp_path)
    eval_path = _write_eval(tmp_path)
    dataset_path = _write_dataset(tmp_path)
    creds_path = tmp_path / "creds" / "credentials.json"
    creds_path.parent.mkdir(parents=True, exist_ok=True)
    creds_path.write_text("{}")
    monkeypatch.setattr(auth, "CREDENTIALS_PATH", creds_path)

    result = runner.invoke(app, [
        "run", f"{module_path}:test_tool",
        "--eval", str(eval_path),
        "--dataset", str(dataset_path),
    ])

    assert result.exit_code == 1
    assert "Run `zhanla login` again" in result.output
    assert "Traceback" not in result.output


def test_run_dry_run_skips_login_check(tmp_path: Path, monkeypatch) -> None:
    module_path = _write_component(tmp_path)
    eval_path = _write_eval(tmp_path)
    dataset_path = _write_dataset(tmp_path)
    creds_path = tmp_path / "no_creds" / "credentials.json"
    monkeypatch.setattr(auth, "CREDENTIALS_PATH", creds_path)

    result = runner.invoke(app, [
        "run", f"{module_path}:test_tool",
        "--eval", str(eval_path),
        "--dataset", str(dataset_path),
        "--dry-run",
    ])
    assert result.exit_code == 0
    assert "Mean score" in result.output


def test_run_with_eval_dry_run(tmp_path: Path, monkeypatch) -> None:
    module_path = _write_component(tmp_path)
    eval_path = _write_eval(tmp_path)
    dataset_path = _write_dataset(tmp_path)
    creds_path = tmp_path / "no_creds" / "credentials.json"
    monkeypatch.setattr(auth, "CREDENTIALS_PATH", creds_path)

    result = runner.invoke(app, [
        "run", f"{module_path}:test_tool",
        "--eval", str(eval_path),
        "--dataset", str(dataset_path),
        "--dry-run",
    ])
    assert result.exit_code == 0
    assert "Mean score" in result.output


def test_run_exits_when_python_closure_discovery_fails(tmp_path: Path, monkeypatch) -> None:
    module_path = _write_component(tmp_path)
    eval_path = _write_eval(tmp_path)
    dataset_path = _write_dataset(tmp_path)
    creds_path = tmp_path / "no_creds" / "credentials.json"
    monkeypatch.setattr(auth, "CREDENTIALS_PATH", creds_path)

    web_stub = types.ModuleType("zhanla_cli.web")
    web_stub.derive_expected_output = lambda row: ""
    web_stub.derive_model_input = lambda row: ""
    web_stub.derive_model_response = lambda output: ""
    web_stub.fetch_web_dataset = lambda **kwargs: None
    web_stub.fetch_web_prompt = lambda **kwargs: None
    web_stub.start_evaluate_only = lambda **kwargs: None
    monkeypatch.setitem(sys.modules, "zhanla_cli.web", web_stub)

    def _raise(_spec: str):
        raise ValueError("duplicate key")

    monkeypatch.setattr("zhanla_cli.runners.discover_python_components", _raise)

    result = runner.invoke(app, [
        "run", f"{module_path}:test_tool",
        "--eval", str(eval_path),
        "--dataset", str(dataset_path),
        "--dry-run",
    ])

    assert result.exit_code == 1
    assert "Closure discovery failed: duplicate key" in result.output


def test_run_upload_failure_exits_1(tmp_path: Path, monkeypatch) -> None:
    module_path = _write_component(tmp_path)
    eval_path = _write_eval(tmp_path)
    dataset_path = _write_dataset(tmp_path)
    creds_path = tmp_path / "creds" / "credentials.json"
    monkeypatch.setattr(auth, "CREDENTIALS_PATH", creds_path)
    auth.save_credentials(
        {
            "key_id": "bm_kid_test",
            "secret": "bm_sec_test",
            "supabase_url": "https://example.com",
            "supabase_anon_key": "anon",
            "org_id": "org-1",
        }
    )

    monkeypatch.setattr(
        "zhanla_cli.auth.get_fresh_token",
        lambda _base_url: {
            "supabase_url": "https://example.com",
            "supabase_anon_key": "anon",
            "access_token": "token",
            "org_id": "org-1",
        },
    )
    monkeypatch.setattr(
        "zhanla_cli.writer.write_run_results",
        lambda *args, **kwargs: (_ for _ in ()).throw(RuntimeError("db write failed")),
    )

    result = runner.invoke(app, [
        "run", f"{module_path}:test_tool",
        "--eval", str(eval_path),
        "--dataset", str(dataset_path),
    ])

    assert result.exit_code == 1
    assert "Sync/upload failed: db write failed" in result.output


def test_run_with_upload_prints_url(tmp_path: Path, monkeypatch) -> None:
    module_path = _write_component(tmp_path)
    eval_path = _write_eval(tmp_path)
    dataset_path = tmp_path / "data.json"
    dataset_path.write_text('[{"x": 1}]')
    creds_path = tmp_path / "creds" / "credentials.json"
    monkeypatch.setattr(auth, "CREDENTIALS_PATH", creds_path)
    auth.save_credentials(
        {
            "key_id": "bm_kid_test",
            "secret": "bm_sec_test",
            "supabase_url": "https://example.com",
            "supabase_anon_key": "anon",
            "org_id": "org-1",
        }
    )

    monkeypatch.setattr(
        "zhanla_cli.auth.get_fresh_token",
        lambda _base_url: {
            "supabase_url": "https://example.com",
            "supabase_anon_key": "anon",
            "access_token": "token",
            "org_id": "org-1",
        },
    )

    from zhanla_cli.writer import UploadResult

    monkeypatch.setattr(
        "zhanla_cli.writer.write_run_results",
        lambda *args, **kwargs: UploadResult(
            dataset_id="dataset-789",
            dataset_item_ids=["item-1"],
            autorater_id="autorater-123",
            autorater_run_id="run-456",
        ),
    )

    result = runner.invoke(app, [
        "run", f"{module_path}:test_tool",
        "--eval", str(eval_path),
        "--dataset", str(dataset_path),
    ])

    assert result.exit_code == 0
    assert "Autorater ID: autorater-123" in result.output
    assert "Autorater Run ID: run-456" in result.output
    assert "Open: Open run (" in result.output
    assert "Autorater ID: autorater-123" in result.output
    assert "Autorater Run ID: run-456" in result.output
    assert "Upload started at:" in result.output
    assert "Upload completed at:" in result.output


def test_upload_command_removed() -> None:
    result = runner.invoke(app, ["upload", "component.py:test"])
    assert result.exit_code != 0  # command no longer exists


def test_flush_removed() -> None:
    result = runner.invoke(app, ["flush"])
    assert result.exit_code != 0  # command no longer exists


def test_run_with_web_eval_uses_evaluate_only_flow(tmp_path: Path, monkeypatch) -> None:
    module_path = _write_component(tmp_path)
    dataset_path = _write_dataset(tmp_path)
    creds_path = tmp_path / "creds" / "credentials.json"
    monkeypatch.setattr(auth, "CREDENTIALS_PATH", creds_path)
    auth.save_credentials(
        {
            "key_id": "bm_kid_test",
            "secret": "bm_sec_test",
            "supabase_url": "https://example.com",
            "supabase_anon_key": "anon",
            "org_id": "org-1",
        }
    )

    monkeypatch.setattr(
        "zhanla_cli.auth.get_fresh_token",
        lambda _base_url: {
            "supabase_url": "https://example.com",
            "supabase_anon_key": "anon",
            "access_token": "token",
            "org_id": "org-1",
        },
    )

    from zhanla_cli.writer import UploadResult

    monkeypatch.setattr(
        "zhanla_cli.writer.write_run_results",
        lambda *args, **kwargs: UploadResult(
            dataset_id="dataset-123",
            dataset_item_ids=["item-1", "item-2"],
        ),
    )
    monkeypatch.setattr(
        "zhanla_cli.web.start_evaluate_only",
        lambda **kwargs: {"runId": "run-999", "triggerRunId": "tr-1"},
    )
    monkeypatch.setattr(
        "zhanla_cli.evaluations.poll_evaluation",
        lambda **kwargs: {
            "status": "completed",
            "overall_score": 0.75,
            "items_total": 2,
            "items_completed": 2,
            "error": None,
        },
    )

    result = runner.invoke(
        app,
        [
            "run",
            f"{module_path}:test_tool",
            "--dataset",
            str(dataset_path),
            "--web-eval",
            "autorater-web-1",
        ],
    )

    assert result.exit_code == 0
    assert "Remote Evaluation" in result.output
    assert "run-999" in result.output


def test_run_with_web_config_triggers_web_only_flow(tmp_path: Path, monkeypatch) -> None:
    creds_path = tmp_path / "creds" / "credentials.json"
    monkeypatch.setattr(auth, "CREDENTIALS_PATH", creds_path)
    auth.save_credentials(
        {
            "key_id": "bm_kid_test",
            "secret": "bm_sec_test",
            "supabase_url": "https://example.com",
            "supabase_anon_key": "anon",
            "org_id": "org-1",
        }
    )

    monkeypatch.setattr(
        "zhanla_cli.auth.get_fresh_token",
        lambda _base_url: {
            "supabase_url": "https://example.com",
            "supabase_anon_key": "anon",
            "access_token": "token",
            "org_id": "org-1",
        },
    )
    monkeypatch.setattr(
        "zhanla_cli.web.fetch_web_prompt",
        lambda **kwargs: {"id": "prompt-1", "slug": "prod-prompt"},
    )
    monkeypatch.setattr(
        "zhanla_cli.evaluations.start_evaluation",
        lambda **kwargs: {"runId": "run-web-1", "triggerRunId": "tr-web-1"},
    )
    monkeypatch.setattr(
        "zhanla_cli.evaluations.poll_evaluation",
        lambda **kwargs: {
            "status": "completed",
            "overall_score": 0.91,
            "items_total": 4,
            "items_completed": 4,
            "error": None,
        },
    )

    result = runner.invoke(
        app,
        [
            "run",
            "--web-config",
            "prompt-1",
            "--web-dataset",
            "dataset-1",
            "--web-eval",
            "autorater-1",
        ],
    )

    assert result.exit_code == 0
    assert "Web prompt: prod-prompt" in result.output
    assert "run-web-1" in result.output


def test_run_with_web_config_passes_model_endpoint(tmp_path: Path, monkeypatch) -> None:
    creds_path = tmp_path / "creds" / "credentials.json"
    monkeypatch.setattr(auth, "CREDENTIALS_PATH", creds_path)
    auth.save_credentials(
        {
            "key_id": "bm_kid_test",
            "secret": "bm_sec_test",
            "supabase_url": "https://example.com",
            "supabase_anon_key": "anon",
            "org_id": "org-1",
        }
    )

    monkeypatch.setattr(
        "zhanla_cli.auth.get_fresh_token",
        lambda _base_url: {
            "supabase_url": "https://example.com",
            "supabase_anon_key": "anon",
            "access_token": "token",
            "org_id": "org-1",
        },
    )
    monkeypatch.setattr(
        "zhanla_cli.web.fetch_web_prompt",
        lambda **kwargs: {"id": "prompt-1", "slug": "prod-prompt"},
    )

    captured: dict = {}

    def fake_start_evaluation(**kwargs):
        captured.update(kwargs)
        return {"runId": "run-web-2", "triggerRunId": "tr-web-2"}

    monkeypatch.setattr("zhanla_cli.evaluations.start_evaluation", fake_start_evaluation)
    monkeypatch.setattr(
        "zhanla_cli.evaluations.poll_evaluation",
        lambda **kwargs: {
            "status": "completed",
            "overall_score": 0.91,
            "items_total": 4,
            "items_completed": 4,
            "error": None,
        },
    )

    result = runner.invoke(
        app,
        [
            "run",
            "--web-config",
            "prompt-1",
            "--web-dataset",
            "dataset-1",
            "--web-eval",
            "autorater-1",
            "--model-endpoint",
            "openai:gpt-4.1-mini",
        ],
    )

    assert result.exit_code == 0
    assert captured["model_endpoint"] == "openai:gpt-4.1-mini"


def test_run_model_endpoint_requires_web_config() -> None:
    result = runner.invoke(
        app,
        [
            "run",
            "component.py:test",
            "--dataset",
            "data.json",
            "--eval",
            "eval.py:test_eval",
            "--model-endpoint",
            "openai:gpt-4.1-mini",
        ],
    )

    assert result.exit_code == 1
    assert "--model-endpoint is only supported with --web-config." in result.output


def test_ts_run_with_upload_reuses_shared_upload_and_prints_url(tmp_path: Path, monkeypatch) -> None:
    dataset_path = _write_dataset(tmp_path)
    component_path = tmp_path / "components.ts"
    eval_path = tmp_path / "evals.ts"
    component_path.write_text("// ts component placeholder\n")
    eval_path.write_text("// ts eval placeholder\n")

    creds_path = tmp_path / "creds" / "credentials.json"
    monkeypatch.setattr(auth, "CREDENTIALS_PATH", creds_path)
    auth.save_credentials(
        {
            "key_id": "bm_kid_test",
            "secret": "bm_sec_test",
            "supabase_url": "https://example.com",
            "supabase_anon_key": "anon",
            "org_id": "org-1",
        }
    )

    monkeypatch.setattr(
        "zhanla_cli.auth.get_fresh_token",
        lambda _base_url: {
            "supabase_url": "https://example.com",
            "supabase_anon_key": "anon",
            "access_token": "token",
            "org_id": "org-1",
        },
    )

    manifests_by_path = {
        f"{component_path}:research_pipeline": [
            _ts_manifest(
                name="fetch_sources",
                component_type="tool",
                is_runnable=True,
                is_eval=False,
                file_path=str(component_path),
                output_schema={"type": "object", "properties": {"result": {"type": "string"}}},
                fn_present=True,
            ),
            _ts_manifest(
                name="research_pipeline",
                component_type="orchestration",
                is_runnable=True,
                is_eval=False,
                file_path=str(component_path),
                steps=[
                    {
                        "name": "fetch",
                        "component_ref": {
                            "key": "fetch_sources",
                            "component_type": "tool",
                            "name": "fetch_sources",
                            "language": "typescript",
                            "execution_mode": "code",
                        },
                        "next": [],
                    }
                ],
            ),
        ],
        str(eval_path): [
            _ts_manifest(
                name="research_quality_tree",
                component_type="code_eval",
                is_runnable=False,
                is_eval=True,
                file_path=str(eval_path),
                source_code="return { score: 1.0 }",
                source_language="typescript",
                source_format="function",
                fn_present=True,
            ),
        ],
    }

    monkeypatch.setattr(
        "zhanla_cli.runners.discover_ts_components",
        lambda path: manifests_by_path[path],
    )
    monkeypatch.setattr("zhanla_cli.runners.NodeRunner.start", lambda self: None)
    monkeypatch.setattr("zhanla_cli.runners.NodeRunner.stop", lambda self: None)

    async def fake_run_row(self, row, trigger_run_id):
        return {
            "status": "ok",
            "output": {"result": row["x"]},
            "eval_output": {"score": 0.9},
        }

    monkeypatch.setattr("zhanla_cli.runners.NodeRunner.run_row", fake_run_row)

    from zhanla_cli.writer import UploadResult

    captured: dict = {}

    def fake_write_run_results(**kwargs):
        captured.update(kwargs)
        return UploadResult(
            dataset_id="dataset-1",
            dataset_item_ids=["item-1", "item-2"],
            autorater_id="autorater-ts-1",
            autorater_run_id="run-ts-1",
        )

    monkeypatch.setattr("zhanla_cli.writer.write_run_results", fake_write_run_results)

    result = runner.invoke(
        app,
        [
            "run",
            f"{component_path}:research_pipeline",
            "--eval",
            f"{eval_path}:research_quality_tree",
            "--dataset",
            str(dataset_path),
        ],
    )

    assert result.exit_code == 0
    assert captured["component"].name == "research_pipeline"
    assert captured["eval_component"].name == "research_quality_tree"
    assert captured["component_traces"][0].output == {"result": 1}
    assert captured["eval_traces"][0].output == {"score": 0.9}
    assert "Autorater ID: autorater-ts-1" in result.output
    assert "Autorater Run ID: run-ts-1" in result.output
    assert "Open: Open run (" in result.output
    assert "Mean score" in result.output


def test_ts_run_with_web_eval_uses_evaluate_only_flow(tmp_path: Path, monkeypatch) -> None:
    dataset_path = _write_dataset(tmp_path)
    component_path = tmp_path / "components.ts"
    component_path.write_text("// ts component placeholder\n")

    creds_path = tmp_path / "creds" / "credentials.json"
    monkeypatch.setattr(auth, "CREDENTIALS_PATH", creds_path)
    auth.save_credentials(
        {
            "key_id": "bm_kid_test",
            "secret": "bm_sec_test",
            "supabase_url": "https://example.com",
            "supabase_anon_key": "anon",
            "org_id": "org-1",
        }
    )

    monkeypatch.setattr(
        "zhanla_cli.auth.get_fresh_token",
        lambda _base_url: {
            "supabase_url": "https://example.com",
            "supabase_anon_key": "anon",
            "access_token": "token",
            "org_id": "org-1",
        },
    )

    monkeypatch.setattr(
        "zhanla_cli.runners.discover_ts_components",
        lambda path: [
            _ts_manifest(
                name="fetch_sources",
                component_type="tool",
                is_runnable=True,
                is_eval=False,
                file_path=path,
                output_schema={"type": "object", "properties": {"summary": {"type": "string"}}},
                fn_present=True,
            ),
            _ts_manifest(
                name="research_pipeline",
                component_type="orchestration",
                is_runnable=True,
                is_eval=False,
                file_path=path,
                steps=[
                    {
                        "name": "fetch",
                        "component_ref": {
                            "key": "fetch_sources",
                            "component_type": "tool",
                            "name": "fetch_sources",
                            "language": "typescript",
                            "execution_mode": "code",
                        },
                        "next": [],
                    }
                ],
            ),
        ],
    )
    monkeypatch.setattr("zhanla_cli.runners.NodeRunner.start", lambda self: None)
    monkeypatch.setattr("zhanla_cli.runners.NodeRunner.stop", lambda self: None)

    async def fake_run_row(self, row, trigger_run_id):
        return {
            "status": "ok",
            "output": {"summary": f"item-{row['x']}"},
            "pathTaken": {
                "kind": "orchestration",
                "steps": [
                    {
                        "name": "fetch",
                        "type": "tool",
                        "input": {"x": row["x"]},
                        "output": {"summary": f"item-{row['x']}"},
                    }
                ],
            },
        }

    monkeypatch.setattr("zhanla_cli.runners.NodeRunner.run_row", fake_run_row)

    from zhanla_cli.writer import UploadResult

    monkeypatch.setattr(
        "zhanla_cli.writer.write_run_results",
        lambda **kwargs: UploadResult(
            dataset_id="dataset-ts-1",
            dataset_item_ids=["item-1", "item-2"],
        ),
    )

    captured_items: dict = {}

    def fake_start_evaluate_only(**kwargs):
        captured_items.update(kwargs)
        return {"runId": "run-web-ts-1", "triggerRunId": "tr-web-ts-1"}

    monkeypatch.setattr("zhanla_cli.web.start_evaluate_only", fake_start_evaluate_only)
    monkeypatch.setattr(
        "zhanla_cli.evaluations.poll_evaluation",
        lambda **kwargs: {
            "status": "completed",
            "overall_score": 0.66,
            "items_total": 2,
            "items_completed": 2,
            "error": None,
        },
    )

    result = runner.invoke(
        app,
        [
            "run",
            f"{component_path}:research_pipeline",
            "--dataset",
            str(dataset_path),
            "--web-eval",
            "autorater-web-ts-1",
        ],
    )

    assert result.exit_code == 0
    assert captured_items["dataset_id"] == "dataset-ts-1"
    assert len(captured_items["items"]) == 2
    assert captured_items["items"][0]["modelResponse"] == '{"summary": "item-1"}'
    assert captured_items["items"][0]["pathTaken"]["kind"] == "orchestration"
    assert captured_items["items"][0]["pathTaken"]["steps"][0]["name"] == "fetch"
    assert "Remote Evaluation" in result.output
    assert "run-web-ts-1" in result.output


def _assert_main_import_does_not_require_python_sdk(monkeypatch) -> None:
    original_modules = {
        name: sys.modules.get(name)
        for name in (
            "zhanla_cli.main",
            "zhanla_cli.manifest",
            "zhanla_cli.ui",
            "zhanla_cli.ts_adapter",
            "zhanla_cli.writer",
            "zhanla_cli.runners",
            "zhanla_cli.data_utils",
            "zhanla_cli.contracts",
        )
    }

    real_import = builtins.__import__

    def guarded_import(name, globals=None, locals=None, fromlist=(), level=0):
        if name == "zhanla" or name.startswith("zhanla."):
            raise ModuleNotFoundError(name=name)
        return real_import(name, globals, locals, fromlist, level)

    monkeypatch.setattr(builtins, "__import__", guarded_import)

    for name in original_modules:
        sys.modules.pop(name, None)

    try:
        module = importlib.import_module("zhanla_cli.main")
        assert module.app.info.name == "zhanla"
    finally:
        for name, module in original_modules.items():
            if module is None:
                sys.modules.pop(name, None)
            else:
                sys.modules[name] = module


def test_ts_dry_run_does_not_import_python_sdk(tmp_path: Path, monkeypatch) -> None:
    dataset_path = _write_dataset(tmp_path)
    component_path = tmp_path / "components.ts"
    eval_path = tmp_path / "evals.ts"
    component_path.write_text("// ts component placeholder\n")
    eval_path.write_text("// ts eval placeholder\n")

    manifests_by_path = {
        f"{component_path}:research_pipeline": [
            _ts_manifest(
                name="fetch_sources",
                component_type="tool",
                is_runnable=True,
                is_eval=False,
                file_path=str(component_path),
                output_schema={"type": "object", "properties": {"result": {"type": "number"}}},
                fn_present=True,
            ),
            _ts_manifest(
                name="research_pipeline",
                component_type="orchestration",
                is_runnable=True,
                is_eval=False,
                file_path=str(component_path),
                steps=[
                    {
                        "name": "fetch",
                        "component_ref": {
                            "key": "fetch_sources",
                            "component_type": "tool",
                            "name": "fetch_sources",
                            "language": "typescript",
                            "execution_mode": "code",
                        },
                        "next": [],
                    }
                ],
            ),
        ],
        str(eval_path): [
            _ts_manifest(
                name="research_quality_tree",
                component_type="code_eval",
                is_runnable=False,
                is_eval=True,
                file_path=str(eval_path),
                source_code="return { score: 1.0 }",
                source_language="typescript",
                source_format="function",
                fn_present=True,
            ),
        ],
    }

    monkeypatch.setattr(
        "zhanla_cli.runners.discover_ts_components",
        lambda path: manifests_by_path[path],
    )
    monkeypatch.setattr("zhanla_cli.runners.NodeRunner.start", lambda self: None)
    monkeypatch.setattr("zhanla_cli.runners.NodeRunner.stop", lambda self: None)

    async def fake_run_row(self, row, trigger_run_id):
        return {
            "status": "ok",
            "output": {"result": row["x"]},
            "eval_output": {"score": 1.0},
        }

    monkeypatch.setattr("zhanla_cli.runners.NodeRunner.run_row", fake_run_row)

    real_import = builtins.__import__

    def guarded_import(name, globals=None, locals=None, fromlist=(), level=0):
        if name == "zhanla" or name.startswith("zhanla."):
            raise ModuleNotFoundError(name=name)
        return real_import(name, globals, locals, fromlist, level)

    monkeypatch.setattr(builtins, "__import__", guarded_import)

    result = runner.invoke(
        app,
        [
            "run",
            f"{component_path}:research_pipeline",
            "--eval",
            f"{eval_path}:research_quality_tree",
            "--dataset",
            str(dataset_path),
            "--dry-run",
        ],
    )

    assert result.exit_code == 0
    assert "Mean score" in result.output


def test_main_import_does_not_require_python_sdk(monkeypatch) -> None:
    _assert_main_import_does_not_require_python_sdk(monkeypatch)
