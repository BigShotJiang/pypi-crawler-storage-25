"""Tests for the writer module — class-based model."""
from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone

import zhanla as bench
from zhanla.types import ComponentType, EvalTrace, Step
from zhanla_cli.manifest import ComponentManifest
from zhanla_cli.ts_adapter import build_manifest_component
from zhanla_cli import writer


@dataclass
class FakeResult:
    data: list[dict] | dict | None


class FakeQuery:
    def __init__(self, client: "FakeClient", table: str) -> None:
        self.client = client
        self.table = table
        self.filters: dict[str, object] = {}
        self.operation = "select"
        self.payload: dict | None = None
        self.limit_count: int | None = None
        self._order_col: str | None = None
        self._order_desc: bool = False

    def select(self, *_args, **_kwargs) -> "FakeQuery":
        self.operation = "select"
        return self

    def eq(self, key: str, value: object) -> "FakeQuery":
        self.filters[key] = value
        return self

    def limit(self, _count: int) -> "FakeQuery":
        self.limit_count = _count
        return self

    def order(self, col: str, *, desc: bool = False) -> "FakeQuery":
        self._order_col = col
        self._order_desc = desc
        return self

    def delete(self) -> "FakeQuery":
        self.operation = "delete"
        self.payload = None
        return self

    def insert(self, payload: dict) -> "FakeQuery":
        self.operation = "insert"
        self.payload = self.client.normalize_payload(payload)
        self.client.insert_calls.append((self.table, self.payload))
        return self

    def update(self, payload: dict) -> "FakeQuery":
        self.operation = "update"
        self.payload = self.client.normalize_payload(payload)
        return self

    def execute(self) -> FakeResult:
        if self.operation == "select":
            rows = self.client.lookup(self.table, self.filters, self.limit_count)
            if self._order_col is not None:
                rows = sorted(
                    rows,
                    key=lambda r: r.get(self._order_col, 0),
                    reverse=self._order_desc,
                )
                if self.limit_count is not None:
                    rows = rows[:self.limit_count]
            return FakeResult(rows)
        if self.operation == "update":
            return FakeResult(self.client.update_result(self.table, self.payload or {}, self.filters))
        if self.operation == "delete":
            return FakeResult(self.client.delete_result(self.table, self.filters))
        if self.payload is None:
            raise AssertionError("insert called without payload")
        return FakeResult(self.client.insert_result(self.table, self.payload))


class FakeClient:
    def __init__(self) -> None:
        self.records: dict[str, list[dict]] = {
            "agents": [],
            "tools": [],
            "skills": [],
            "orchestrations": [],
            "autoraters": [],
            "autorater_eval_items": [],
            "autorater_checklist_item": [],
            "autorater_nodes": [],
            "autorater_edges": [],
            "autorater_runs": [],
            "autorater_results": [],
            "component_families": [],
            "component_definitions": [],
            "datasets": [],
            "dataset_items": [],
            "component_datasets": [],
        }
        self.insert_calls: list[tuple[str, dict]] = []

    def table(self, name: str) -> FakeQuery:
        return FakeQuery(self, name)

    def normalize_payload(self, payload: dict) -> dict:
        return json.loads(json.dumps(payload))

    def lookup(
        self,
        table: str,
        filters: dict[str, object],
        limit_count: int | None = None,
    ) -> list[dict]:
        rows = [
            row for row in self.records.get(table, [])
            if all(row.get(key) == value for key, value in filters.items())
        ]
        if limit_count is not None:
            return rows[:limit_count]
        return rows

    def insert_result(self, table: str, payload: dict) -> list[dict]:
        row = {"id": f"{table}-{len(self.records.get(table, [])) + 1}", **payload}
        self.records.setdefault(table, []).append(row)
        return [row]

    def update_result(self, table: str, payload: dict, filters: dict[str, object]) -> list[dict]:
        updated: list[dict] = []
        for row in self.records.get(table, []):
            if all(row.get(key) == value for key, value in filters.items()):
                row.update(payload)
                updated.append(row)
        return updated

    def delete_result(self, table: str, filters: dict[str, object]) -> list[dict]:
        existing = self.records.get(table, [])
        deleted = [
            row for row in existing
            if all(row.get(key) == value for key, value in filters.items())
        ]
        self.records[table] = [
            row for row in existing
            if not all(row.get(key) == value for key, value in filters.items())
        ]
        return deleted


def test_write_run_results_creates_autorater_run_and_results(monkeypatch) -> None:
    client = FakeClient()
    monkeypatch.setattr(writer, "get_supabase_client", lambda *args, **kwargs: client)

    def tool_fn(x: int) -> dict:
        return {"result": x}

    def eval_fn(**kwargs) -> dict:
        return {"score": 0.8}

    component = bench.Tool(name="my_tool", description="d", input_schema={}, fn=tool_fn, output_schema={"result": int}, key="my-tool")
    eval_comp = bench.CodeEval(name="my_scorer", description="d", fn=eval_fn, key="my-scorer")

    comp_traces = [
        EvalTrace(
            name="my_tool",
            component_type=ComponentType.TOOL,
            input={"x": 1},
            output={"result": 2},
            error=None,
            latency_ms=10.0,
            steps=[],
            status="completed",
            trigger_run_id="run-1",
        ),
        EvalTrace(
            name="my_tool",
            component_type=ComponentType.TOOL,
            input={"x": 3},
            output={"result": 4},
            error=None,
            latency_ms=15.0,
            steps=[],
            status="completed",
            trigger_run_id="run-1",
        ),
    ]
    eval_traces = [
        EvalTrace(
            name="my_scorer",
            component_type=ComponentType.CODE_EVAL,
            input={"x": 1, "result": 2},
            output={"score": 0.8, "reasoning": "good"},
            error=None,
            latency_ms=5.0,
            steps=[],
            status="completed",
            trigger_run_id="run-1",
        ),
        EvalTrace(
            name="my_scorer",
            component_type=ComponentType.CODE_EVAL,
            input={"x": 3, "result": 4},
            output={"score": 0.9, "reasoning": "great"},
            error=None,
            latency_ms=5.0,
            steps=[],
            status="completed",
            trigger_run_id="run-1",
        ),
    ]

    upload_result = writer.write_run_results(
        component=component,
        eval_component=eval_comp,
        component_traces=comp_traces,
        eval_traces=eval_traces,
        supabase_url="url",
        supabase_anon_key="anon",
        access_token="token",
        org_id="org-1",
        dataset_item_ids=["item-1", "item-2"],
    )

    assert upload_result is not None
    assert upload_result.autorater_id == "autoraters-1"
    assert upload_result.autorater_run_id == "autorater_runs-1"

    # Component family and versioned definition created
    family_inserts = [c for c in client.insert_calls if c[0] == "component_families"]
    assert len(family_inserts) >= 1
    definition_inserts = [c for c in client.insert_calls if c[0] == "component_definitions"]
    assert len(definition_inserts) >= 1
    assert definition_inserts[0][1]["version"] == 1
    assert definition_inserts[0][1]["is_prod"] is True

    # Tool entity upserted in the correct table
    tool_inserts = [c for c in client.insert_calls if c[0] == "tools"]
    assert len(tool_inserts) == 1
    assert tool_inserts[0][1]["component_family_id"] is not None
    assert "name" not in tool_inserts[0][1]
    assert "description" not in tool_inserts[0][1]
    assert "function_name" not in tool_inserts[0][1]
    assert "schema_definition" not in tool_inserts[0][1]

    # Autorater upserted
    autorater_inserts = [c for c in client.insert_calls if c[0] == "autoraters"]
    assert len(autorater_inserts) == 1
    assert client.records["autoraters"][0]["organization_id"] == "org-1"
    assert client.records["autoraters"][0]["mode"] == "simple"
    assert client.records["autoraters"][0]["simple_eval_item_id"] == "autorater_eval_items-1"

    eval_item_inserts = [c for c in client.insert_calls if c[0] == "autorater_eval_items"]
    assert len(eval_item_inserts) == 1
    assert eval_item_inserts[0][1]["type"] == "code_python"
    assert "def eval_fn" in eval_item_inserts[0][1]["content"]

    # One autorater_runs row
    ar_run_inserts = [c for c in client.insert_calls if c[0] == "autorater_runs"]
    assert len(ar_run_inserts) == 1
    assert abs(ar_run_inserts[0][1]["overall_score"] - 0.85) < 1e-10
    assert ar_run_inserts[0][1]["trigger_source"] == "sdk"
    assert ar_run_inserts[0][1]["items_total"] == 2

    # Two autorater_results rows
    ar_result_inserts = [c for c in client.insert_calls if c[0] == "autorater_results"]
    assert len(ar_result_inserts) == 2
    assert ar_result_inserts[0][1]["overall_score"] == 0.8
    assert ar_result_inserts[0][1]["dataset_item_id"] == "item-1"
    assert ar_result_inserts[0][1]["llm_response"] == "2"
    assert "score" not in ar_result_inserts[0][1]["result"]
    assert ar_result_inserts[0][1]["result"]["reasoning"] == "good"


def test_write_run_results_no_eval_traces_returns_none(monkeypatch) -> None:
    client = FakeClient()
    monkeypatch.setattr(writer, "get_supabase_client", lambda *args, **kwargs: client)

    def fn() -> dict:
        return {"result": 1}

    component = bench.Tool(name="my_tool", description="d", input_schema={}, fn=fn, output_schema={"result": int}, key="my-tool")
    eval_comp = bench.CodeEval(name="scorer", description="d", fn=fn, key="scorer")

    result = writer.write_run_results(
        component=component,
        eval_component=eval_comp,
        component_traces=[],
        eval_traces=[None],
        supabase_url="url",
        supabase_anon_key="anon",
        access_token="token",
        org_id="org-1",
    )

    assert result is not None
    assert result.autorater_id is None
    assert result.autorater_run_id is None
    # Entity still upserted
    tool_inserts = [c for c in client.insert_calls if c[0] == "tools"]
    assert len(tool_inserts) == 1


def test_write_run_results_syncs_llm_eval_as_prompt_item(monkeypatch) -> None:
    client = FakeClient()
    monkeypatch.setattr(writer, "get_supabase_client", lambda *args, **kwargs: client)

    def tool_fn(topic: str) -> dict:
        return {"summary": topic}

    component = bench.Tool(
        name="topic_tool",
        description="d",
        input_schema={},
        fn=tool_fn,
        output_schema={"summary": str}, key="topic-tool"
    )
    eval_comp = bench.LLMEval(
        name="prompt_eval",
        description="Judge the generated summary.",
        instructions="Return a score for the generated summary.",
        model="gpt-4o-mini",
        output_schema={"score": float}, key="prompt-eval"
    )

    comp_traces = [
        EvalTrace(
            name="topic_tool",
            component_type=ComponentType.TOOL,
            input={"topic": "ai"},
            output={"summary": "ai"},
            error=None,
            latency_ms=10.0,
            steps=[],
            status="completed",
            trigger_run_id="run-llm",
        )
    ]
    eval_traces = [
        EvalTrace(
            name="prompt_eval",
            component_type=ComponentType.LLM_EVAL,
            input={"summary": "ai"},
            output={"score": 1.0},
            error=None,
            latency_ms=5.0,
            steps=[],
            status="completed",
            trigger_run_id="run-llm",
        )
    ]

    result = writer.write_run_results(
        component=component,
        eval_component=eval_comp,
        component_traces=comp_traces,
        eval_traces=eval_traces,
        supabase_url="url",
        supabase_anon_key="anon",
        access_token="token",
        org_id="org-1",
    )

    assert result is not None
    assert client.records["autoraters"][0]["mode"] == "simple"
    assert client.records["autoraters"][0]["simple_eval_item_id"] == "autorater_eval_items-1"
    assert client.records["autorater_eval_items"][0]["type"] == "prompt"
    assert client.records["autorater_eval_items"][0]["content"] == eval_comp.instructions
    assert client.records["autorater_eval_items"][0]["output_type"] == "TEXT"


def test_write_run_results_syncs_typescript_closure_component_by_manifest_key(monkeypatch) -> None:
    client = FakeClient()
    monkeypatch.setattr(writer, "get_supabase_client", lambda *args, **kwargs: client)

    manifest = ComponentManifest(
        name="ts_tool",
        description="TS tool",
        component_type="tool",
        key="ts-tool",
        key_source="explicit",
        language="typescript",
        is_runnable=True,
        is_eval=False,
        execution_mode="code",
        fn_present=True,
        output_schema={"type": "object", "properties": {"result": {"type": "number"}}},
        source_code="export const tsTool = () => ({ result: 1 });",
        source_language="typescript",
        source_format="function",
    )
    component = build_manifest_component(manifest, [manifest])

    result = writer.write_run_results(
        component=component,
        eval_component=component,
        component_traces=[],
        eval_traces=[],
        supabase_url="url",
        supabase_anon_key="anon",
        access_token="token",
        org_id="org-1",
        closure=[manifest],
    )

    assert result is not None
    families = client.records["component_families"]
    definitions = client.records["component_definitions"]
    assert len(families) == 1
    assert len(definitions) == 1
    assert families[0]["key"] == "ts-tool"
    assert definitions[0]["definition"]["source_language"] == "typescript"


def test_write_run_results_syncs_typescript_code_eval_as_code_typescript(monkeypatch) -> None:
    client = FakeClient()
    monkeypatch.setattr(writer, "get_supabase_client", lambda *args, **kwargs: client)

    def tool_fn(topic: str) -> dict:
        return {"summary": topic}

    def eval_fn(**kwargs) -> dict:
        return {"score": 1.0}

    component = bench.Tool(
        name="topic_tool",
        description="d",
        input_schema={},
        fn=tool_fn,
        output_schema={"type": "object", "properties": {"summary": {"type": "string"}}}, key="topic-tool"
    )
    eval_comp = bench.CodeEval(name="ts_eval", description="TS judge", fn=eval_fn, key="ts-eval")
    eval_comp.source_language = "typescript"
    eval_comp.source_code = "export const tsEval = () => ({ score: 1.0 });"

    comp_traces = [
        EvalTrace(
            name="topic_tool",
            component_type=ComponentType.TOOL,
            input={"topic": "ai"},
            output={"summary": "ai"},
            error=None,
            latency_ms=10.0,
            steps=[],
            status="completed",
            trigger_run_id="run-ts",
        )
    ]
    eval_traces = [
        EvalTrace(
            name="ts_eval",
            component_type=ComponentType.CODE_EVAL,
            input={"summary": "ai"},
            output={"score": 1.0},
            error=None,
            latency_ms=5.0,
            steps=[],
            status="completed",
            trigger_run_id="run-ts",
        )
    ]

    result = writer.write_run_results(
        component=component,
        eval_component=eval_comp,
        component_traces=comp_traces,
        eval_traces=eval_traces,
        supabase_url="url",
        supabase_anon_key="anon",
        access_token="token",
        org_id="org-1",
    )

    assert result is not None
    assert client.records["autorater_eval_items"][0]["type"] == "code_typescript"
    assert client.records["autorater_eval_items"][0]["content"] == eval_comp.source_code
    defn_inserts = [c for c in client.insert_calls if c[0] == "component_definitions"]
    tool_defn = defn_inserts[0][1]["definition"]
    assert tool_defn["component_type"] == "tool"
    assert tool_defn["source_code"] == component.source_code
    assert tool_defn["source_language"] == "python"


def test_write_run_results_syncs_checklist_structure(monkeypatch) -> None:
    client = FakeClient()
    monkeypatch.setattr(writer, "get_supabase_client", lambda *args, **kwargs: client)

    def tool_fn(message: str) -> dict:
        return {"message": message}

    def eval_priority(**kwargs) -> dict:
        return {"score": 1.0}

    def eval_team(**kwargs) -> dict:
        return {"score": 0.5}

    component = bench.Tool(name="message_tool", description="d", input_schema={}, fn=tool_fn, output_schema={"message": str}, key="message-tool")
    eval_one = bench.CodeEval(name="priority_eval", description="d", fn=eval_priority, key="priority-eval")
    eval_two = bench.CodeEval(name="team_eval", description="d", fn=eval_team, key="team-eval")
    checklist = bench.Checklist(
        name="triage_checklist",
        description="d",
        evals=[eval_one, eval_two],
        weights=[0.7, 0.3], key="triage-checklist"
    )

    comp_traces = [
        EvalTrace(
            name="message_tool",
            component_type=ComponentType.TOOL,
            input={"message": "hello"},
            output={"message": "hello"},
            error=None,
            latency_ms=10.0,
            steps=[],
            status="completed",
            trigger_run_id="run-checklist",
        )
    ]
    eval_traces = [
        EvalTrace(
            name="triage_checklist",
            component_type=ComponentType.CHECKLIST,
            input={"message": "hello"},
            output={"score": 0.75},
            error=None,
            latency_ms=5.0,
            steps=[],
            status="completed",
            trigger_run_id="run-checklist",
        )
    ]

    result = writer.write_run_results(
        component=component,
        eval_component=checklist,
        component_traces=comp_traces,
        eval_traces=eval_traces,
        supabase_url="url",
        supabase_anon_key="anon",
        access_token="token",
        org_id="org-1",
    )

    assert result is not None
    assert client.records["autoraters"][0]["organization_id"] == "org-1"
    assert client.records["autoraters"][0]["mode"] == "checklist"
    assert client.records["autoraters"][0]["simple_eval_item_id"] is None
    assert len(client.records["autorater_eval_items"]) == 2
    assert len(client.records["autorater_checklist_item"]) == 2
    assert client.records["autorater_checklist_item"][0]["order_index"] == 0
    assert client.records["autorater_checklist_item"][0]["weight"] == 0.7
    assert client.records["autorater_checklist_item"][1]["order_index"] == 1
    assert client.records["autorater_checklist_item"][1]["weight"] == 0.3


def test_write_run_results_syncs_eval_tree_structure(monkeypatch) -> None:
    client = FakeClient()
    monkeypatch.setattr(writer, "get_supabase_client", lambda *args, **kwargs: client)

    def tool_fn(topic: str) -> dict:
        return {"topic": topic}

    def root_eval(**kwargs) -> dict:
        return {"score": 1.0}

    def pass_eval(**kwargs) -> dict:
        return {"score": 1.0}

    def fail_eval(**kwargs) -> dict:
        return {"score": 0.0}

    component = bench.Tool(name="topic_tool", description="d", input_schema={}, fn=tool_fn, output_schema={"topic": str}, key="topic-tool")
    root = bench.CodeEval(name="root_eval", description="d", fn=root_eval, key="root-eval")
    pass_leaf = bench.CodeEval(name="pass_eval", description="d", fn=pass_eval, key="pass-eval")
    fail_leaf = bench.CodeEval(name="fail_eval", description="d", fn=fail_eval, key="fail-eval")
    tree = bench.EvalTree(
        name="tree_eval",
        description="d",
        root=bench.Branch(
            eval=root,
            threshold=1.0,
            if_pass=[bench.Edge(weight=0.8, node=bench.Leaf(eval=pass_leaf))],
            if_fail=[bench.Edge(weight=0.2, node=bench.Leaf(eval=fail_leaf))],
        ), key="tree-eval"
    )

    comp_traces = [
        EvalTrace(
            name="topic_tool",
            component_type=ComponentType.TOOL,
            input={"topic": "ai"},
            output={"topic": "ai"},
            error=None,
            latency_ms=10.0,
            steps=[],
            status="completed",
            trigger_run_id="run-tree",
        )
    ]
    eval_traces = [
        EvalTrace(
            name="tree_eval",
            component_type=ComponentType.EVAL_TREE,
            input={"topic": "ai"},
            output={"score": 1.0},
            error=None,
            latency_ms=5.0,
            steps=[],
            status="completed",
            trigger_run_id="run-tree",
        )
    ]

    result = writer.write_run_results(
        component=component,
        eval_component=tree,
        component_traces=comp_traces,
        eval_traces=eval_traces,
        supabase_url="url",
        supabase_anon_key="anon",
        access_token="token",
        org_id="org-1",
    )

    assert result is not None
    assert client.records["autoraters"][0]["organization_id"] == "org-1"
    assert client.records["autoraters"][0]["mode"] == "tree"
    assert len(client.records["autorater_eval_items"]) == 3
    assert len(client.records["autorater_nodes"]) == 3
    assert len(client.records["autorater_edges"]) == 2
    branch_labels = sorted(row.get("branch_label") for row in client.records["autorater_edges"])
    assert branch_labels == ["if_fail", "if_pass"]
    root_node = next(row for row in client.records["autorater_nodes"] if row["is_root"] is True)
    child_weights = sorted(
        row["weight"] for row in client.records["autorater_nodes"] if row["is_root"] is False
    )
    assert root_node["weight"] == 1.0
    assert child_weights == [0.2, 0.8]


def test_write_run_results_creates_dataset_items_when_missing(monkeypatch) -> None:
    client = FakeClient()
    monkeypatch.setattr(writer, "get_supabase_client", lambda *args, **kwargs: client)

    def tool_fn(x: int) -> dict:
        return {"result": x}

    def eval_fn(**kwargs) -> dict:
        return {"score": 1.0}

    component = bench.Tool(name="my_tool", description="d", input_schema={}, fn=tool_fn, output_schema={"result": int}, key="my-tool")
    eval_comp = bench.CodeEval(name="my_eval", description="d", fn=eval_fn, key="my-eval")

    comp_trace = EvalTrace(
        name="my_tool",
        component_type=ComponentType.TOOL,
        input={"x": 1},
        output={"result": 1},
        error=None,
        latency_ms=1.0,
        steps=[],
        status="completed",
        trigger_run_id="run-1",
    )
    eval_trace = EvalTrace(
        name="my_eval",
        component_type=ComponentType.CODE_EVAL,
        input={"x": 1, "result": 1},
        output={"score": 1.0},
        error=None,
        latency_ms=1.0,
        steps=[],
        status="completed",
        trigger_run_id="run-1",
    )

    upload_result = writer.write_run_results(
        component=component,
        eval_component=eval_comp,
        component_traces=[comp_trace],
        eval_traces=[eval_trace],
        supabase_url="url",
        supabase_anon_key="anon",
        access_token="token",
        org_id="org-1",
        dataset_name="local_data",
        dataset_rows=[{"x": 1}],
    )

    assert upload_result is not None
    assert upload_result.dataset_id == "datasets-1"
    assert upload_result.dataset_item_ids == ["dataset_items-1"]

    dataset_inserts = [c for c in client.insert_calls if c[0] == "datasets"]
    assert len(dataset_inserts) == 1
    assert dataset_inserts[0][1]["input_columns"] == {"x": "integer"}
    dataset_item_inserts = [c for c in client.insert_calls if c[0] == "dataset_items"]
    assert len(dataset_item_inserts) == 1
    component_dataset_inserts = [c for c in client.insert_calls if c[0] == "component_datasets"]
    assert len(component_dataset_inserts) == 1

    autorater_result_inserts = [c for c in client.insert_calls if c[0] == "autorater_results"]
    assert len(autorater_result_inserts) == 1
    assert autorater_result_inserts[0][1]["dataset_item_id"] == "dataset_items-1"
    assert autorater_result_inserts[0][1]["llm_response"] == "1"


def test_write_run_results_serializes_structured_model_response(monkeypatch) -> None:
    client = FakeClient()
    monkeypatch.setattr(writer, "get_supabase_client", lambda *args, **kwargs: client)

    def tool_fn(x: int) -> dict:
        return {"summary": f"value={x}", "passed": True}

    def eval_fn(**kwargs) -> dict:
        return {"score": 1.0}

    component = bench.Tool(
        name="my_tool",
        description="d",
        input_schema={},
        fn=tool_fn,
        output_schema={"summary": str, "passed": bool}, key="my-tool"
    )
    eval_comp = bench.CodeEval(name="my_eval", description="d", fn=eval_fn, key="my-eval")

    comp_trace = EvalTrace(
        name="my_tool",
        component_type=ComponentType.TOOL,
        input={"x": 1},
        output={"summary": "value=1", "passed": True},
        error=None,
        latency_ms=1.0,
        steps=[],
        status="completed",
        trigger_run_id="run-1",
    )
    eval_trace = EvalTrace(
        name="my_eval",
        component_type=ComponentType.CODE_EVAL,
        input={"x": 1},
        output={"score": 1.0},
        error=None,
        latency_ms=1.0,
        steps=[],
        status="completed",
        trigger_run_id="run-1",
    )

    writer.write_run_results(
        component=component,
        eval_component=eval_comp,
        component_traces=[comp_trace],
        eval_traces=[eval_trace],
        supabase_url="url",
        supabase_anon_key="anon",
        access_token="token",
        org_id="org-1",
        dataset_item_ids=["item-1"],
    )

    autorater_result_inserts = [c for c in client.insert_calls if c[0] == "autorater_results"]
    assert len(autorater_result_inserts) == 1
    assert (
        autorater_result_inserts[0][1]["llm_response"]
        == '{"passed": true, "summary": "value=1"}'
    )


def test_write_run_results_excludes_model_output_from_result_payload(monkeypatch) -> None:
    client = FakeClient()
    monkeypatch.setattr(writer, "get_supabase_client", lambda *args, **kwargs: client)

    def tool_fn(x: int) -> dict:
        return {"result": x * 2}

    def eval_fn(**kwargs) -> dict:
        return {
            "score": 1.0,
            "passed": True,
            "reasoning": "matches expected output",
            "result": {"priority": kwargs["result"]},
        }

    component = bench.Tool(
        name="my_tool",
        description="d",
        input_schema={},
        fn=tool_fn,
        output_schema={"result": int}, key="my-tool"
    )
    eval_comp = bench.CodeEval(name="my_eval", description="d", fn=eval_fn, key="my-eval")

    comp_trace = EvalTrace(
        name="my_tool",
        component_type=ComponentType.TOOL,
        input={"x": 2},
        output={"result": 4},
        error=None,
        latency_ms=1.0,
        steps=[],
        status="completed",
        trigger_run_id="run-1",
    )
    eval_trace = EvalTrace(
        name="my_eval",
        component_type=ComponentType.CODE_EVAL,
        input={"x": 2, "result": 4},
        output={
            "score": 1.0,
            "passed": True,
            "reasoning": "matches expected output",
            "result": {"priority": 4},
        },
        error=None,
        latency_ms=1.0,
        steps=[],
        status="completed",
        trigger_run_id="run-1",
    )

    writer.write_run_results(
        component=component,
        eval_component=eval_comp,
        component_traces=[comp_trace],
        eval_traces=[eval_trace],
        supabase_url="url",
        supabase_anon_key="anon",
        access_token="token",
        org_id="org-1",
        dataset_item_ids=["item-1"],
    )

    autorater_result_inserts = [c for c in client.insert_calls if c[0] == "autorater_results"]
    assert len(autorater_result_inserts) == 1
    assert autorater_result_inserts[0][1]["llm_response"] == "4"
    assert autorater_result_inserts[0][1]["result"] == {
        "passed": True,
        "reasoning": "matches expected output",
        "result": {"priority": 4},
    }


def test_write_run_results_preserves_eval_tree_result_payload(monkeypatch) -> None:
    client = FakeClient()
    monkeypatch.setattr(writer, "get_supabase_client", lambda *args, **kwargs: client)

    def tool_fn(topic: str) -> dict:
        return {"topic": topic}

    def root_eval(**kwargs) -> dict:
        return {"score": 1.0}

    def pass_eval(**kwargs) -> dict:
        return {"score": 0.75, "passed": True}

    component = bench.Tool(
        name="topic_tool",
        description="d",
        input_schema={},
        fn=tool_fn,
        output_schema={"topic": str}, key="topic-tool"
    )
    tree = bench.EvalTree(
        name="tree_eval",
        description="d",
        root=bench.Branch(
            eval=bench.CodeEval(name="root_eval", description="d", fn=root_eval, key="root-eval"),
            threshold=0.5,
            if_pass=[
                bench.Edge(
                    weight=1.0,
                    node=bench.Leaf(
                        eval=bench.CodeEval(name="pass_eval", description="d", fn=pass_eval, key="pass-eval")
                    ),
                )
            ],
            if_fail=[],
        ), key="tree-eval"
    )

    comp_trace = EvalTrace(
        name="topic_tool",
        component_type=ComponentType.TOOL,
        input={"topic": "ai"},
        output={"topic": "ai"},
        error=None,
        latency_ms=10.0,
        steps=[],
        status="completed",
        trigger_run_id="run-tree",
    )
    eval_trace = EvalTrace(
        name="tree_eval",
        component_type=ComponentType.EVAL_TREE,
        input={"topic": "ai"},
        output={
            "score": 0.75,
            "details": [{"type": "leaf", "name": "pass_eval", "score": 0.75, "weight": 1.0}],
            "result": {
                "type": "branch",
                "name": "root_eval",
                "score": 0.75,
                "threshold": 0.5,
                "routing_score": 1.0,
                "selected_branch": "if_pass",
                "routing_result": {"score": 1.0},
                "children": [
                    {
                        "type": "leaf",
                        "name": "pass_eval",
                        "score": 0.75,
                        "weight": 1.0,
                        "result": {"score": 0.75, "passed": True},
                    }
                ],
            },
        },
        error=None,
        latency_ms=5.0,
        steps=[],
        status="completed",
        trigger_run_id="run-tree",
    )

    writer.write_run_results(
        component=component,
        eval_component=tree,
        component_traces=[comp_trace],
        eval_traces=[eval_trace],
        supabase_url="url",
        supabase_anon_key="anon",
        access_token="token",
        org_id="org-1",
        dataset_item_ids=["item-1"],
    )

    autorater_result_inserts = [c for c in client.insert_calls if c[0] == "autorater_results"]
    assert len(autorater_result_inserts) == 1
    assert autorater_result_inserts[0][1]["result"]["result"] == {
        "type": "branch",
        "name": "root_eval",
        "score": 0.75,
        "threshold": 0.5,
        "routing_score": 1.0,
        "selected_branch": "if_pass",
        "routing_result": {"score": 1.0},
        "children": [
            {
                "type": "leaf",
                "name": "pass_eval",
                "score": 0.75,
                "weight": 1.0,
                "result": {"score": 0.75, "passed": True},
            }
        ],
    }


def test_write_run_results_marks_failed_json_output(monkeypatch) -> None:
    client = FakeClient()
    monkeypatch.setattr(writer, "get_supabase_client", lambda *args, **kwargs: client)

    def tool_fn(x: int) -> dict:
        return {"result": x}

    def eval_fn(**kwargs) -> dict:
        return {"score": 0.0, "passed": False}

    component = bench.Tool(
        name="my_tool",
        description="d",
        input_schema={},
        fn=tool_fn,
        output_schema={"result": int}, key="my-tool"
    )
    eval_comp = bench.CodeEval(name="my_eval", description="d", fn=eval_fn, key="my-eval")

    comp_trace = EvalTrace(
        name="my_tool",
        component_type=ComponentType.TOOL,
        input={"x": 2},
        output={"_component_error": "Unterminated string in JSON at position 28 (line 1 column 29)"},
        error=None,
        latency_ms=1.0,
        steps=[],
        status="completed",
        trigger_run_id="run-1",
    )
    eval_trace = EvalTrace(
        name="my_eval",
        component_type=ComponentType.CODE_EVAL,
        input={"x": 2},
        output={"score": 0.0, "passed": False},
        error=None,
        latency_ms=1.0,
        steps=[],
        status="completed",
        trigger_run_id="run-1",
    )

    writer.write_run_results(
        component=component,
        eval_component=eval_comp,
        component_traces=[comp_trace],
        eval_traces=[eval_trace],
        supabase_url="url",
        supabase_anon_key="anon",
        access_token="token",
        org_id="org-1",
        dataset_item_ids=["item-1"],
    )

    autorater_result_inserts = [c for c in client.insert_calls if c[0] == "autorater_results"]
    assert len(autorater_result_inserts) == 1
    assert autorater_result_inserts[0][1]["result"] == {
        "passed": False,
        "reason": "Model response doesn't match the requested output schema.",
        "output_schema_error": "Unterminated string in JSON at position 28 (line 1 column 29)",
    }


def test_write_run_results_links_existing_dataset(monkeypatch) -> None:
    client = FakeClient()
    monkeypatch.setattr(writer, "get_supabase_client", lambda *args, **kwargs: client)

    def tool_fn(x: int) -> dict:
        return {"result": x}

    def eval_fn(**kwargs) -> dict:
        return {"score": 1.0}

    component = bench.Tool(name="my_tool", description="d", input_schema={}, fn=tool_fn, output_schema={"result": int}, key="my-tool")
    eval_comp = bench.CodeEval(name="my_eval", description="d", fn=eval_fn, key="my-eval")

    comp_trace = EvalTrace(
        name="my_tool",
        component_type=ComponentType.TOOL,
        input={"x": 1},
        output={"result": 1},
        error=None,
        latency_ms=1.0,
        steps=[],
        status="completed",
        trigger_run_id="run-1",
    )
    eval_trace = EvalTrace(
        name="my_eval",
        component_type=ComponentType.CODE_EVAL,
        input={"x": 1, "result": 1},
        output={"score": 1.0},
        error=None,
        latency_ms=1.0,
        steps=[],
        status="completed",
        trigger_run_id="run-1",
    )

    result = writer.write_run_results(
        component=component,
        eval_component=eval_comp,
        component_traces=[comp_trace],
        eval_traces=[eval_trace],
        supabase_url="url",
        supabase_anon_key="anon",
        access_token="token",
        org_id="org-1",
        dataset_id="dataset-123",
        dataset_item_ids=["item-1"],
    )

    assert result is not None
    component_dataset_inserts = [c for c in client.insert_calls if c[0] == "component_datasets"]
    assert len(component_dataset_inserts) == 1
    assert component_dataset_inserts[0][1]["dataset_id"] == "dataset-123"


def test_write_run_results_replaces_existing_dataset_items(monkeypatch) -> None:
    client = FakeClient()
    client.records["datasets"] = [
        {
            "id": "dataset-123",
            "name": "tickets",
            "organization_id": "org-1",
            "description": "old",
            "input_columns": {},
        }
    ]
    client.records["dataset_items"] = [
        {"id": "old-1", "dataset_id": "dataset-123", "input": {"x": 1}, "is_active": True},
        {"id": "old-2", "dataset_id": "dataset-123", "input": {"x": 2}, "is_active": True},
    ]
    monkeypatch.setattr(writer, "get_supabase_client", lambda *args, **kwargs: client)

    component = bench.Tool(
        name="my_tool",
        description="d",
        input_schema={},
        fn=lambda x: {"result": x},
        output_schema={"result": int}, key="my-tool"
    )
    eval_comp = bench.CodeEval(name="my_eval", description="d", fn=lambda **kwargs: {"score": 1.0}, key="my-eval")

    comp_trace = EvalTrace(
        name="my_tool",
        component_type=ComponentType.TOOL,
        input={"x": 1},
        output={"result": 1},
        error=None,
        latency_ms=1.0,
        steps=[],
        status="completed",
        trigger_run_id="run-1",
    )
    eval_trace = EvalTrace(
        name="my_eval",
        component_type=ComponentType.CODE_EVAL,
        input={"x": 1, "result": 1},
        output={"score": 1.0},
        error=None,
        latency_ms=1.0,
        steps=[],
        status="completed",
        trigger_run_id="run-1",
    )

    result = writer.write_run_results(
        component=component,
        eval_component=eval_comp,
        component_traces=[comp_trace],
        eval_traces=[eval_trace],
        supabase_url="url",
        supabase_anon_key="anon",
        access_token="token",
        org_id="org-1",
        dataset_name="tickets",
        dataset_rows=[{"x": 2}, {"x": 7}],
    )

    assert result is not None
    dataset_items = sorted(client.records["dataset_items"], key=lambda row: row["id"])
    assert len(dataset_items) == 3
    assert next(row for row in dataset_items if row["id"] == "old-1")["is_active"] is False
    assert next(row for row in dataset_items if row["id"] == "old-2")["is_active"] is True
    inserted = next(row for row in dataset_items if row["id"].startswith("dataset_items-"))
    assert inserted["input"] == {"x": 7}
    assert inserted["is_active"] is True
    assert client.records["datasets"][0]["input_columns"] == {"x": "integer"}


def test_write_run_results_snapshots_tool_source_code(monkeypatch) -> None:
    client = FakeClient()
    monkeypatch.setattr(writer, "get_supabase_client", lambda *args, **kwargs: client)

    def tool_fn(x: int) -> dict:
        return {"result": x}

    def eval_fn(**kwargs) -> dict:
        return {"score": 1.0}

    component = bench.Tool(name="my_tool", description="d", input_schema={}, fn=tool_fn, output_schema={"result": int}, key="my-tool")
    eval_comp = bench.CodeEval(name="my_eval", description="d", fn=eval_fn, key="my-eval")

    comp_trace = EvalTrace(
        name="my_tool",
        component_type=ComponentType.TOOL,
        input={"x": 1},
        output={"result": 1},
        error=None,
        latency_ms=1.0,
        steps=[],
        status="completed",
        trigger_run_id="run-1",
    )
    eval_trace = EvalTrace(
        name="my_eval",
        component_type=ComponentType.CODE_EVAL,
        input={"x": 1, "result": 1},
        output={"score": 1.0},
        error=None,
        latency_ms=1.0,
        steps=[],
        status="completed",
        trigger_run_id="run-1",
    )

    result = writer.write_run_results(
        component=component,
        eval_component=eval_comp,
        component_traces=[comp_trace],
        eval_traces=[eval_trace],
        supabase_url="url",
        supabase_anon_key="anon",
        access_token="token",
        org_id="org-1",
        dataset_item_ids=["item-1"],
    )

    assert result is not None
    definitions = client.records["component_definitions"]
    tool_definition = next(
        row for row in definitions if row["name"] == "my_tool"
    )
    parsed_definition = tool_definition["definition"]
    assert "source_code" in parsed_definition
    assert "def tool_fn" in parsed_definition["source_code"]
    assert parsed_definition["name"] == "my_tool"
    assert "definition" not in parsed_definition
    # New schema: family + versioned row
    assert tool_definition["version"] == 1
    assert tool_definition["is_prod"] is True


def test_write_run_results_syncs_skill_into_skills_table(monkeypatch) -> None:
    client = FakeClient()
    monkeypatch.setattr(writer, "get_supabase_client", lambda *args, **kwargs: client)

    component = bench.Skill(
        name="my_skill",
        description="skill desc",
        instructions="Do the thing", key="my-skill"
    )
    eval_comp = bench.CodeEval(name="my_eval", description="d", fn=lambda **kwargs: {"score": 1.0}, key="my-eval")

    comp_trace = EvalTrace(
        name="my_skill",
        component_type=ComponentType.SKILL,
        input={"x": 1},
        output={"result": "ok"},
        error=None,
        latency_ms=1.0,
        steps=[],
        status="completed",
        trigger_run_id="run-1",
    )
    eval_trace = EvalTrace(
        name="my_eval",
        component_type=ComponentType.CODE_EVAL,
        input={"x": 1, "result": "ok"},
        output={"score": 1.0},
        error=None,
        latency_ms=1.0,
        steps=[],
        status="completed",
        trigger_run_id="run-1",
    )

    result = writer.write_run_results(
        component=component,
        eval_component=eval_comp,
        component_traces=[comp_trace],
        eval_traces=[eval_trace],
        supabase_url="url",
        supabase_anon_key="anon",
        access_token="token",
        org_id="org-1",
        dataset_item_ids=["item-1"],
    )

    assert result is not None
    skill_inserts = [c for c in client.insert_calls if c[0] == "skills"]
    assert len(skill_inserts) == 1
    assert skill_inserts[0][1]["component_family_id"] is not None
    assert "name" not in skill_inserts[0][1]
    assert "description" not in skill_inserts[0][1]
    defn_inserts = [c for c in client.insert_calls if c[0] == "component_definitions"]
    assert defn_inserts[0][1]["definition"]["name"] == "my_skill"


def test_write_run_results_syncs_orchestration_graph(monkeypatch) -> None:
    client = FakeClient()
    monkeypatch.setattr(writer, "get_supabase_client", lambda *args, **kwargs: client)

    step_tool = bench.Tool(
        name="step_tool",
        description="d",
        input_schema={},
        fn=lambda **kwargs: {"ok": True},
        output_schema={"ok": bool}, key="step-tool"
    )
    component = bench.Orchestration(
        name="my_orchestration",
        description="orch desc",
        steps=[
            bench.Step(component=step_tool, name="step_one"),
        ], key="my-orchestration"
    )
    eval_comp = bench.CodeEval(name="my_eval", description="d", fn=lambda **kwargs: {"score": 1.0}, key="my-eval")

    comp_trace = EvalTrace(
        name="my_orchestration",
        component_type=ComponentType.ORCHESTRATION,
        input={"x": 1},
        output={"ok": True},
        error=None,
        latency_ms=1.0,
        steps=[],
        status="completed",
        trigger_run_id="run-1",
    )
    eval_trace = EvalTrace(
        name="my_eval",
        component_type=ComponentType.CODE_EVAL,
        input={"x": 1, "ok": True},
        output={"score": 1.0},
        error=None,
        latency_ms=1.0,
        steps=[],
        status="completed",
        trigger_run_id="run-1",
    )

    result = writer.write_run_results(
        component=component,
        eval_component=eval_comp,
        component_traces=[comp_trace],
        eval_traces=[eval_trace],
        supabase_url="url",
        supabase_anon_key="anon",
        access_token="token",
        org_id="org-1",
        dataset_item_ids=["item-1"],
    )

    assert result is not None
    orchestration_inserts = [c for c in client.insert_calls if c[0] == "orchestrations"]
    assert len(orchestration_inserts) == 1
    assert orchestration_inserts[0][1]["component_family_id"] is not None
    assert "name" not in orchestration_inserts[0][1]
    assert "description" not in orchestration_inserts[0][1]
    defn_inserts = [c for c in client.insert_calls if c[0] == "component_definitions"]
    orch_defn = defn_inserts[0][1]["definition"]
    assert orch_defn["component_type"] == "orchestration"
    assert any(step["name"] == "step_one" for step in orch_defn["steps"])


def test_write_run_results_serializes_component_definition_without_cycles(monkeypatch) -> None:
    client = FakeClient()
    monkeypatch.setattr(writer, "get_supabase_client", lambda *args, **kwargs: client)

    step_tool = bench.Tool(
        name="step_tool",
        description="d",
        input_schema={},
        fn=lambda **kwargs: {"ok": True},
        output_schema={"ok": bool}, key="step-tool"
    )
    component = bench.Orchestration(
        name="my_orchestration",
        description="orch desc",
        steps=[bench.Step(component=step_tool, name="step_one")], key="my-orchestration"
    )
    eval_comp = bench.CodeEval(name="my_eval", description="d", fn=lambda **kwargs: {"score": 1.0}, key="my-eval")

    comp_trace = EvalTrace(
        name="my_orchestration",
        component_type=ComponentType.ORCHESTRATION,
        input={"x": 1},
        output={"ok": True},
        error=None,
        latency_ms=1.0,
        steps=[],
        status="completed",
        trigger_run_id="run-1",
    )
    eval_trace = EvalTrace(
        name="my_eval",
        component_type=ComponentType.CODE_EVAL,
        input={"x": 1, "ok": True},
        output={"score": 1.0},
        error=None,
        latency_ms=1.0,
        steps=[],
        status="completed",
        trigger_run_id="run-1",
    )

    result = writer.write_run_results(
        component=component,
        eval_component=eval_comp,
        component_traces=[comp_trace],
        eval_traces=[eval_trace],
        supabase_url="url",
        supabase_anon_key="anon",
        access_token="token",
        org_id="org-1",
        dataset_item_ids=["item-1"],
    )

    assert result is not None
    definitions = client.records["component_definitions"]
    orchestration_definition = next(
        row
        for row in definitions
        if row["name"] == "my_orchestration"
    )
    assert orchestration_definition["definition"]["name"] == "my_orchestration"
    assert "definition" not in orchestration_definition["definition"]


def test_write_run_results_keeps_agent_specific_fields_inside_definition_json(monkeypatch) -> None:
    client = FakeClient()
    monkeypatch.setattr(writer, "get_supabase_client", lambda *args, **kwargs: client)

    component = bench.Agent(
        name="my_agent",
        description="agent desc",
        instructions="Be helpful",
        model="gpt-5.4-mini", key="my-agent"
    )
    eval_comp = bench.CodeEval(name="my_eval", description="d", fn=lambda **kwargs: {"score": 1.0}, key="my-eval")

    comp_trace = EvalTrace(
        name="my_agent",
        component_type=ComponentType.AGENT,
        input={"message": "hi"},
        output={"result": "ok"},
        error=None,
        latency_ms=1.0,
        steps=[],
        status="completed",
        trigger_run_id="run-1",
    )
    eval_trace = EvalTrace(
        name="my_eval",
        component_type=ComponentType.CODE_EVAL,
        input={"message": "hi", "result": "ok"},
        output={"score": 1.0},
        error=None,
        latency_ms=1.0,
        steps=[],
        status="completed",
        trigger_run_id="run-1",
    )

    result = writer.write_run_results(
        component=component,
        eval_component=eval_comp,
        component_traces=[comp_trace],
        eval_traces=[eval_trace],
        supabase_url="url",
        supabase_anon_key="anon",
        access_token="token",
        org_id="org-1",
        dataset_item_ids=["item-1"],
    )

    assert result is not None
    definition = next(
        row
        for row in client.records["component_definitions"]
        if row["name"] == "my_agent"
    )
    assert definition["definition"]["instructions"] == "Be helpful"
    assert definition["definition"]["model"] == "gpt-5.4-mini"
    assert "instructions" not in definition
    assert "model" not in definition


# ---------------------------------------------------------------------------
# output_type / model_response_format tests
# ---------------------------------------------------------------------------

def _make_tool_and_traces(name: str = "t") -> tuple:
    def tool_fn(**kwargs) -> dict:
        return {"result": 1}

    component = bench.Tool(
        name=name,
        description="d",
        input_schema={},
        fn=tool_fn,
        output_schema={"type": "object", "properties": {"result": {"type": "number"}}},
        key=name.replace("_", "-"),
    )
    trace = EvalTrace(
        name=name,
        component_type=ComponentType.TOOL,
        input={},
        output={"result": 1},
        error=None,
        latency_ms=1.0,
        steps=[],
        status="completed",
        trigger_run_id="run-1",
    )
    return component, trace


def test_code_eval_defaults_to_json_output_type(monkeypatch) -> None:
    client = FakeClient()
    monkeypatch.setattr(writer, "get_supabase_client", lambda *args, **kwargs: client)

    component, comp_trace = _make_tool_and_traces("my_tool")
    eval_comp = bench.CodeEval(name="my_eval", description="d", fn=lambda **kwargs: {"score": 1.0}, key="my-eval")

    eval_trace = EvalTrace(
        name="my_eval",
        component_type=ComponentType.CODE_EVAL,
        input={},
        output={"score": 1.0},
        error=None,
        latency_ms=1.0,
        steps=[],
        status="completed",
        trigger_run_id="run-1",
    )

    writer.write_run_results(
        component=component,
        eval_component=eval_comp,
        component_traces=[comp_trace],
        eval_traces=[eval_trace],
        supabase_url="url",
        supabase_anon_key="anon",
        access_token="token",
        org_id="org-1",
    )

    item = client.records["autorater_eval_items"][0]
    assert item["output_type"] == "JSON"


def test_code_eval_model_response_format_text_override(monkeypatch) -> None:
    client = FakeClient()
    monkeypatch.setattr(writer, "get_supabase_client", lambda *args, **kwargs: client)

    component, comp_trace = _make_tool_and_traces("my_tool")
    eval_comp = bench.CodeEval(
        name="text_eval",
        description="d",
        fn=lambda **kwargs: {"score": 1.0},
        model_response_format="TEXT", key="text-eval"
    )

    eval_trace = EvalTrace(
        name="text_eval",
        component_type=ComponentType.CODE_EVAL,
        input={},
        output={"score": 1.0},
        error=None,
        latency_ms=1.0,
        steps=[],
        status="completed",
        trigger_run_id="run-1",
    )

    writer.write_run_results(
        component=component,
        eval_component=eval_comp,
        component_traces=[comp_trace],
        eval_traces=[eval_trace],
        supabase_url="url",
        supabase_anon_key="anon",
        access_token="token",
        org_id="org-1",
    )

    item = client.records["autorater_eval_items"][0]
    assert item["output_type"] == "TEXT"


def test_llm_eval_always_uses_text_output_type(monkeypatch) -> None:
    client = FakeClient()
    monkeypatch.setattr(writer, "get_supabase_client", lambda *args, **kwargs: client)

    component, comp_trace = _make_tool_and_traces("my_tool")
    eval_comp = bench.LLMEval(
        name="llm_eval",
        description="d",
        instructions="Score this.",
        model="gpt-4o-mini",
        output_schema={"score": float},
        key="llm-eval",
    )

    eval_trace = EvalTrace(
        name="llm_eval",
        component_type=ComponentType.LLM_EVAL,
        input={},
        output={"score": 1.0},
        error=None,
        latency_ms=1.0,
        steps=[],
        status="completed",
        trigger_run_id="run-1",
    )

    writer.write_run_results(
        component=component,
        eval_component=eval_comp,
        component_traces=[comp_trace],
        eval_traces=[eval_trace],
        supabase_url="url",
        supabase_anon_key="anon",
        access_token="token",
        org_id="org-1",
    )

    item = client.records["autorater_eval_items"][0]
    assert item["output_type"] == "TEXT"


def test_code_eval_model_response_format_changes_behavior_hash() -> None:
    """model_response_format is a runtime-affecting field — changing it must change behavior_hash."""
    from zhanla.manifest import to_manifest, compute_behavior_hash

    def fn(**kwargs) -> dict:
        return {"score": 1.0}

    eval_json = bench.CodeEval(name="e", description="d", fn=fn, model_response_format="JSON", key="e")
    eval_text = bench.CodeEval(name="e", description="d", fn=fn, model_response_format="TEXT", key="e")
    eval_yaml = bench.CodeEval(name="e", description="d", fn=fn, model_response_format="YAML", key="e")

    bh_json = compute_behavior_hash(to_manifest(eval_json))
    bh_text = compute_behavior_hash(to_manifest(eval_text))
    bh_yaml = compute_behavior_hash(to_manifest(eval_yaml))

    assert bh_json != bh_text
    assert bh_json != bh_yaml
    assert bh_text != bh_yaml


# ---------------------------------------------------------------------------
# Component family + versioning tests
# ---------------------------------------------------------------------------

def _make_component_and_traces(name: str = "my_tool") -> tuple:
    """Build a minimal Tool + matching EvalTrace pair for writer tests."""
    def tool_fn(x: int) -> dict:
        return {"result": x}

    def eval_fn(**kwargs) -> dict:
        return {"score": 1.0}

    component = bench.Tool(
        name=name,
        description="d",
        input_schema={},
        fn=tool_fn,
        output_schema={"result": int},
        key=name.replace("_", "-"),
    )
    eval_comp = bench.CodeEval(name="scorer", description="d", fn=eval_fn, key="scorer")
    comp_trace = EvalTrace(
        name=name,
        component_type=ComponentType.TOOL,
        input={"x": 1},
        output={"result": 1},
        error=None,
        latency_ms=1.0,
        steps=[],
        status="completed",
        trigger_run_id="run-1",
    )
    eval_trace = EvalTrace(
        name="scorer",
        component_type=ComponentType.CODE_EVAL,
        input={"x": 1, "result": 1},
        output={"score": 1.0},
        error=None,
        latency_ms=1.0,
        steps=[],
        status="completed",
        trigger_run_id="run-1",
    )
    return component, eval_comp, comp_trace, eval_trace


def test_sync_creates_family_and_version_1_as_prod(monkeypatch) -> None:
    """First sync creates a family + version 1 marked is_prod=True."""
    client = FakeClient()
    monkeypatch.setattr(writer, "get_supabase_client", lambda *args, **kwargs: client)

    component, eval_comp, comp_trace, eval_trace = _make_component_and_traces()

    writer.write_run_results(
        component=component,
        eval_component=eval_comp,
        component_traces=[comp_trace],
        eval_traces=[eval_trace],
        supabase_url="url",
        supabase_anon_key="anon",
        access_token="token",
        org_id="org-1",
        dataset_item_ids=["item-1"],
    )

    families = client.records["component_families"]
    definitions = client.records["component_definitions"]

    tool_families = [f for f in families if f["component_type"] == "tool"]
    assert len(tool_families) == 1
    assert tool_families[0]["key"] == "my-tool"
    assert tool_families[0]["key_source"] == "explicit"

    tool_definitions = [d for d in definitions if d["name"] == "my_tool"]
    assert len(tool_definitions) == 1
    assert tool_definitions[0]["version"] == 1
    assert tool_definitions[0]["is_prod"] is True
    assert tool_definitions[0]["parent_version_id"] is None
    assert tool_definitions[0]["behavior_hash"] is not None
    assert tool_definitions[0]["snapshot_hash"] is not None


def test_sync_second_call_is_noop_when_unchanged(monkeypatch) -> None:
    """Syncing the same component twice should not create a second version row."""
    client = FakeClient()
    monkeypatch.setattr(writer, "get_supabase_client", lambda *args, **kwargs: client)

    component, eval_comp, comp_trace, eval_trace = _make_component_and_traces()

    kwargs = dict(
        component=component,
        eval_component=eval_comp,
        component_traces=[comp_trace],
        eval_traces=[eval_trace],
        supabase_url="url",
        supabase_anon_key="anon",
        access_token="token",
        org_id="org-1",
        dataset_item_ids=["item-1"],
    )
    writer.write_run_results(**kwargs)
    writer.write_run_results(**kwargs)

    definitions = [d for d in client.records["component_definitions"] if d["name"] == "my_tool"]
    assert len(definitions) == 1  # still only one version row


def test_sync_second_version_when_code_changes(monkeypatch) -> None:
    """Changing the implementation creates version 2 (draft, is_prod=False)."""
    client = FakeClient()
    monkeypatch.setattr(writer, "get_supabase_client", lambda *args, **kwargs: client)

    def eval_fn(**kwargs) -> dict:
        return {"score": 1.0}

    eval_comp = bench.CodeEval(name="scorer", description="d", fn=eval_fn, key="scorer")

    def tool_fn_v1(x: int) -> dict:
        return {"result": x}

    def tool_fn_v2(x: int) -> dict:
        return {"result": x * 2}

    comp_v1 = bench.Tool(name="my_tool", description="d", input_schema={}, fn=tool_fn_v1, output_schema={"result": int}, key="my-tool")
    comp_v2 = bench.Tool(name="my_tool", description="d", input_schema={}, fn=tool_fn_v2, output_schema={"result": int}, key="my-tool")

    trace = EvalTrace(
        name="my_tool",
        component_type=ComponentType.TOOL,
        input={"x": 1},
        output={"result": 1},
        error=None,
        latency_ms=1.0,
        steps=[],
        status="completed",
        trigger_run_id="run-1",
    )
    eval_trace = EvalTrace(
        name="scorer",
        component_type=ComponentType.CODE_EVAL,
        input={"x": 1, "result": 1},
        output={"score": 1.0},
        error=None,
        latency_ms=1.0,
        steps=[],
        status="completed",
        trigger_run_id="run-1",
    )

    common = dict(
        eval_component=eval_comp,
        component_traces=[trace],
        eval_traces=[eval_trace],
        supabase_url="url",
        supabase_anon_key="anon",
        access_token="token",
        org_id="org-1",
        dataset_item_ids=["item-1"],
    )
    writer.write_run_results(component=comp_v1, **common)
    writer.write_run_results(component=comp_v2, **common)

    definitions = sorted(
        [d for d in client.records["component_definitions"] if d["name"] == "my_tool"],
        key=lambda d: d["version"],
    )
    assert len(definitions) == 2
    assert definitions[0]["version"] == 1
    assert definitions[0]["is_prod"] is True
    assert definitions[1]["version"] == 2
    assert definitions[1]["is_prod"] is False
    assert definitions[1]["parent_version_id"] == definitions[0]["id"]

    # Both belong to the same family
    families = [f for f in client.records["component_families"] if f["component_type"] == "tool"]
    assert len(families) == 1
    assert definitions[0]["family_id"] == definitions[1]["family_id"]


def _test_sync_implicit_rename_preserves_lineage(monkeypatch, capsys) -> None:
    """Renaming a component (implicit key) with same code reuses existing family."""
    client = FakeClient()
    monkeypatch.setattr(writer, "get_supabase_client", lambda *args, **kwargs: client)

    def eval_fn(**kwargs) -> dict:
        return {"score": 1.0}

    def tool_fn(x: int) -> dict:
        return {"result": x}

    eval_comp = bench.CodeEval(name="scorer", description="d", fn=eval_fn, key="scorer")
    eval_trace = EvalTrace(
        name="scorer",
        component_type=ComponentType.CODE_EVAL,
        input={},
        output={"score": 1.0},
        error=None,
        latency_ms=1.0,
        steps=[],
        status="completed",
        trigger_run_id="run-1",
    )

    # First sync under original name
    comp_v1 = bench.Tool(name="my_tool", description="d", input_schema={}, fn=tool_fn, output_schema={"result": int}, key="my-tool")
    trace = EvalTrace(name="my_tool", component_type=ComponentType.TOOL, input={"x": 1}, output={"result": 1},
                      error=None, latency_ms=1.0, steps=[], status="completed", trigger_run_id="run-1")
    common = dict(
        eval_component=eval_comp, component_traces=[trace], eval_traces=[eval_trace],
        supabase_url="url", supabase_anon_key="anon", access_token="token",
        org_id="org-1", dataset_item_ids=["item-1"],
    )
    writer.write_run_results(component=comp_v1, **common)

    # Second sync under renamed component (same implementation)
    comp_v2 = bench.Tool(name="renamed_tool", description="d", input_schema={}, fn=tool_fn, output_schema={"result": int}, key="renamed-tool")
    trace2 = EvalTrace(name="renamed_tool", component_type=ComponentType.TOOL, input={"x": 1}, output={"result": 1},
                       error=None, latency_ms=1.0, steps=[], status="completed", trigger_run_id="run-1")
    writer.write_run_results(component=comp_v2, component_traces=[trace2], **{k: v for k, v in common.items() if k != "component_traces"})

    tool_families = [f for f in client.records["component_families"] if f["component_type"] == "tool"]
    # Only one tool family — the rename reused it
    assert len(tool_families) == 1
    assert tool_families[0]["key"] == "my-tool"  # original key preserved

    # Notice printed to stdout
    captured = capsys.readouterr()
    assert "my-tool" in captured.out or "renamed_tool" in captured.out


def test_sync_explicit_key_ignores_rename_detection(monkeypatch) -> None:
    """Explicit keys always route to their own family, never triggering rename detection."""
    client = FakeClient()
    monkeypatch.setattr(writer, "get_supabase_client", lambda *args, **kwargs: client)

    def eval_fn(**kwargs) -> dict:
        return {"score": 1.0}

    def tool_fn(x: int) -> dict:
        return {"result": x}

    eval_comp = bench.CodeEval(name="scorer", description="d", fn=eval_fn, key="scorer")
    eval_trace = EvalTrace(
        name="scorer", component_type=ComponentType.CODE_EVAL,
        input={}, output={"score": 1.0}, error=None, latency_ms=1.0,
        steps=[], status="completed", trigger_run_id="run-1",
    )

    comp_a = bench.Tool(name="tool_a", description="d", input_schema={}, fn=tool_fn, output_schema={"result": int}, key="family-a")
    comp_b = bench.Tool(name="tool_b", description="d", input_schema={}, fn=tool_fn, output_schema={"result": int}, key="family-b")

    for comp, tname in [(comp_a, "tool_a"), (comp_b, "tool_b")]:
        trace = EvalTrace(name=tname, component_type=ComponentType.TOOL, input={"x": 1}, output={"result": 1},
                          error=None, latency_ms=1.0, steps=[], status="completed", trigger_run_id="run-1")
        writer.write_run_results(
            component=comp, eval_component=eval_comp,
            component_traces=[trace], eval_traces=[eval_trace],
            supabase_url="url", supabase_anon_key="anon", access_token="token",
            org_id="org-1", dataset_item_ids=["item-1"],
        )

    tool_families = [f for f in client.records["component_families"] if f["component_type"] == "tool"]
    assert len(tool_families) == 2
    family_keys = sorted(f["key"] for f in tool_families)
    assert family_keys == ["family-a", "family-b"]


def _test_sync_ambiguous_rename_raises(monkeypatch) -> None:
    """If two implicit families already share the same behavior_hash, syncing a third
    component with the same behavior raises RuntimeError (ambiguous rename).

    This state can arise from a race condition or manual DB manipulation. We reproduce
    it by pre-seeding two implicit families with matching behavior_hash rows directly
    into the FakeClient, then syncing a new component that matches both.
    """
    import pytest
    from zhanla.manifest import to_manifest, compute_behavior_hash

    client = FakeClient()
    monkeypatch.setattr(writer, "get_supabase_client", lambda *args, **kwargs: client)

    def eval_fn(**kwargs) -> dict:
        return {"score": 1.0}

    def tool_fn(x: int) -> dict:
        return {"result": x}

    eval_comp = bench.CodeEval(name="scorer", description="d", fn=eval_fn, key="scorer")
    eval_trace = EvalTrace(
        name="scorer", component_type=ComponentType.CODE_EVAL,
        input={}, output={"score": 1.0}, error=None, latency_ms=1.0,
        steps=[], status="completed", trigger_run_id="run-1",
    )

    # Compute the behavior_hash that tool_c will produce
    comp_c = bench.Tool(name="tool_c", description="d", input_schema={}, fn=tool_fn, output_schema={"result": int}, key="tool-c")
    tool_c_bh = compute_behavior_hash(to_manifest(comp_c))

    # Seed two pre-existing implicit families with that same behavior_hash
    client.records["component_families"] = [
        {"id": "fam-1", "organization_id": "org-1", "component_type": "tool", "key": "tool-alpha", "key_source": "implicit"},
        {"id": "fam-2", "organization_id": "org-1", "component_type": "tool", "key": "tool-beta", "key_source": "implicit"},
    ]
    client.records["component_definitions"] = [
        {"id": "def-1", "family_id": "fam-1", "behavior_hash": tool_c_bh, "snapshot_hash": "s1", "version": 1},
        {"id": "def-2", "family_id": "fam-2", "behavior_hash": tool_c_bh, "snapshot_hash": "s2", "version": 1},
    ]

    # Now syncing tool_c should be ambiguous
    trace_c = EvalTrace(name="tool_c", component_type=ComponentType.TOOL, input={"x": 1}, output={"result": 1},
                        error=None, latency_ms=1.0, steps=[], status="completed", trigger_run_id="run-1")
    with pytest.raises(RuntimeError, match="Ambiguous rename"):
        writer.write_run_results(
            component=comp_c, eval_component=eval_comp,
            component_traces=[trace_c], eval_traces=[eval_trace],
            supabase_url="url", supabase_anon_key="anon", access_token="token",
            org_id="org-1", dataset_item_ids=["item-1"],
        )
