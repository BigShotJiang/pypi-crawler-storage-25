"""Tests for NodeRunner and PythonRunner adapters."""
from __future__ import annotations

import asyncio
import json
from io import BytesIO
from typing import Any
from unittest.mock import MagicMock, patch
try:
    from unittest.mock import AsyncMock
except ImportError:
    # Python 3.7 fallback
    AsyncMock = MagicMock
import subprocess

import pytest

import zhanla as bench
from zhanla.types import Tool, CodeEval, Skill
from zhanla.manifest import to_manifest, ComponentManifest
from zhanla_cli.runners import (
    PythonRunner,
    NodeRunner,
    RunnerError,
    detect_language,
    validate_same_language,
)


# ---------------------------------------------------------------------------
# detect_language
# ---------------------------------------------------------------------------

def test_detect_language_python() -> None:
    assert detect_language("components.py") == "python"
    assert detect_language("path/to/evals.py") == "python"


def test_detect_language_typescript() -> None:
    assert detect_language("components.ts") == "typescript"
    assert detect_language("path/to/evals.ts") == "typescript"


def test_detect_language_unknown_raises() -> None:
    with pytest.raises(ValueError, match="Unsupported"):
        detect_language("components.js")


def test_detect_language_no_extension_raises() -> None:
    with pytest.raises(ValueError, match="Unsupported"):
        detect_language("components")


# ---------------------------------------------------------------------------
# validate_same_language
# ---------------------------------------------------------------------------

def test_validate_same_language_python_python() -> None:
    # Should not raise
    validate_same_language(component_lang="python", eval_lang="python")


def test_validate_same_language_ts_ts() -> None:
    validate_same_language(component_lang="typescript", eval_lang="typescript")


def test_validate_same_language_mismatch_raises() -> None:
    with pytest.raises(ValueError, match="same language"):
        validate_same_language(component_lang="python", eval_lang="typescript")

    with pytest.raises(ValueError, match="same language"):
        validate_same_language(component_lang="typescript", eval_lang="python")


def test_validate_same_language_no_eval() -> None:
    # No eval — always OK
    validate_same_language(component_lang="python", eval_lang=None)
    validate_same_language(component_lang="typescript", eval_lang=None)


# ---------------------------------------------------------------------------
# PythonRunner
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_python_runner_tool() -> None:
    def fn(x: int) -> dict:
        return {"result": x * 2}

    tool = bench.Tool(name="double", description="d", input_schema={}, fn=fn, output_schema={"result": int}, key="double")
    manifest = to_manifest(tool)

    runner = PythonRunner(component=tool, eval_component=None)
    result = await runner.run_row({"x": 5}, trigger_run_id="run-1")

    assert result["status"] == "ok"
    assert result["output"]["result"] == 10


@pytest.mark.asyncio
async def test_python_runner_with_eval() -> None:
    def fn(x: int) -> dict:
        return {"result": x}

    def score(**kwargs) -> dict:
        return {"score": 1.0 if kwargs.get("model_response") == "3" else 0.0}

    tool = bench.Tool(name="t", description="d", input_schema={}, fn=fn, output_schema={"result": int}, key="t")
    ev = bench.CodeEval(name="ev", description="d", fn=score, key="ev")

    runner = PythonRunner(component=tool, eval_component=ev)
    result = await runner.run_row({"x": 3}, trigger_run_id="run-2")

    assert result["status"] == "ok"
    assert result["eval_output"]["score"] == 1.0


@pytest.mark.asyncio
async def test_python_runner_component_error() -> None:
    def fn(x: int) -> dict:
        raise RuntimeError("boom")

    tool = bench.Tool(name="err", description="d", input_schema={}, fn=fn, output_schema={"result": int}, key="err")
    runner = PythonRunner(component=tool, eval_component=None)
    result = await runner.run_row({"x": 1}, trigger_run_id="run-err")

    assert result["status"] == "error"
    assert "boom" in result["error"]


# ---------------------------------------------------------------------------
# NodeRunner
# ---------------------------------------------------------------------------

def _make_node_runner(responses: list[dict]) -> NodeRunner:
    """Create a NodeRunner with a mocked subprocess."""
    manifest = ComponentManifest(
        name="my_ts_tool",
        description="d",
        component_type="tool",
        language="typescript",
        is_runnable=True,
        is_eval=False,
        version_hash="abc",
        file_path="components.ts",
        symbol_name="my_ts_tool",
    )

    runner = NodeRunner(
        manifest=manifest,
        eval_manifest=None,
        file_path="components.ts",
    )
    runner._process = MagicMock()

    # Set up readline to return encoded NDJSON lines
    lines = [json.dumps(r).encode() + b"\n" for r in responses]
    runner._process.stdout = MagicMock()
    runner._process.stdout.readline = MagicMock(side_effect=lines + [b""])
    runner._process.stdin = MagicMock()
    runner._process.stdin.write = MagicMock()
    runner._process.stdin.flush = MagicMock()
    runner._process.poll = MagicMock(return_value=None)

    return runner


@pytest.mark.asyncio
async def test_node_runner_sends_row_as_ndjson() -> None:
    runner = _make_node_runner([{"status": "ok", "output": {"result": "hello"}}])

    result = await runner.run_row({"input": "test"}, trigger_run_id="node-run-1")

    # Verify stdin was written
    runner._process.stdin.write.assert_called_once()
    written = runner._process.stdin.write.call_args[0][0]
    parsed = json.loads(written.decode())
    assert parsed["input"] == "test"

    assert result["status"] == "ok"
    assert result["output"]["result"] == "hello"


@pytest.mark.asyncio
async def test_node_runner_handles_error_response() -> None:
    runner = _make_node_runner([{"status": "error", "error": "something went wrong"}])

    result = await runner.run_row({}, trigger_run_id="node-run-err")
    assert result["status"] == "error"
    assert "something went wrong" in result["error"]


@pytest.mark.asyncio
async def test_node_runner_subprocess_crash() -> None:
    runner = _make_node_runner([])
    runner._process.stdout.readline = MagicMock(return_value=b"")
    runner._process.poll = MagicMock(return_value=1)  # non-zero exit

    result = await runner.run_row({}, trigger_run_id="crash-run")
    assert result["status"] == "error"
    assert "subprocess" in result["error"].lower() or "exit" in result["error"].lower()


def test_node_runner_missing_zhanla_sdk_ts_error(tmp_path) -> None:
    """NodeRunner.start() raises a clear error when npx zhanla-sdk-ts is not available."""
    manifest = ComponentManifest(
        name="t",
        description="d",
        component_type="tool",
        key="t",
        key_source="explicit",
        language="typescript",
        is_runnable=True,
        is_eval=False,
        execution_mode="code",
        file_path="components.ts",
        symbol_name="t",
    )
    runner = NodeRunner(
        manifest=manifest,
        eval_manifest=None,
        file_path="components.ts",
    )

    with patch("subprocess.Popen") as mock_popen:
        mock_popen.side_effect = FileNotFoundError("npx not found")
        with pytest.raises(RunnerError, match="zhanla-sdk-ts"):
            runner.start()


def test_node_runner_start_passes_eval_target(monkeypatch) -> None:
    manifest = ComponentManifest(
        name="tool_component_name",
        description="d",
        component_type="tool",
        key="tool-component-name",
        key_source="explicit",
        language="typescript",
        is_runnable=True,
        is_eval=False,
        execution_mode="code",
        file_path="components.ts",
        symbol_name="exportedTool",
    )
    eval_manifest = ComponentManifest(
        name="eval_component_name",
        description="d",
        component_type="code_eval",
        key="eval-component-name",
        key_source="explicit",
        language="typescript",
        is_runnable=False,
        is_eval=True,
        execution_mode="code",
        file_path="evals.ts",
        symbol_name="exportedEval",
    )
    captured: dict[str, Any] = {}

    def fake_popen(cmd, **kwargs):
        captured["cmd"] = cmd
        proc = MagicMock()
        proc.stdin = MagicMock()
        proc.stdout = MagicMock()
        proc.stderr = MagicMock()
        return proc

    monkeypatch.setattr(subprocess, "Popen", fake_popen)

    runner = NodeRunner(
        manifest=manifest,
        eval_manifest=eval_manifest,
        file_path="components.ts",
    )
    runner.start()

    assert captured["cmd"] == [
        "npx",
        "zhanla-sdk-ts",
        "run",
        "components.ts:tool_component_name",
        "--eval",
        "evals.ts:eval_component_name",
    ]


# ---------------------------------------------------------------------------
# NodeRunner TS discovery (mocked subprocess)
# ---------------------------------------------------------------------------

def test_discover_ts_components_parses_manifest_json(tmp_path) -> None:
    """discover_ts_components shells out to npx zhanla-sdk-ts discover and parses JSON."""
    from zhanla_cli.runners import discover_ts_components

    ts_file = tmp_path / "components.ts"
    ts_file.write_text("export const myTool = new Tool({...})")

    expected = [
        {
            "name": "myTool",
            "description": "A TS tool",
            "component_type": "tool",
            "key": "my-tool",
            "key_source": "explicit",
            "language": "typescript",
            "is_runnable": True,
            "is_eval": False,
            "execution_mode": "code",
            "fn_present": True,
            "file_path": str(ts_file),
            "symbol_name": "myTool",
        }
    ]

    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(
            returncode=0,
            stdout=json.dumps(expected),
            stderr="",
        )
        manifests = discover_ts_components(str(ts_file))

    assert len(manifests) == 1
    assert manifests[0].name == "myTool"
    assert manifests[0].language == "typescript"


def test_discover_ts_components_not_found_raises() -> None:
    """discover_ts_components raises RunnerError when zhanla-sdk-ts is missing."""
    from zhanla_cli.runners import discover_ts_components

    with patch("subprocess.run") as mock_run:
        mock_run.side_effect = FileNotFoundError("npx not found")
        with pytest.raises(RunnerError, match="zhanla-sdk-ts"):
            discover_ts_components("components.ts")


def test_discover_ts_components_nonzero_exit_raises(tmp_path) -> None:
    """discover_ts_components raises ValueError on non-zero exit."""
    from zhanla_cli.runners import discover_ts_components

    ts_file = tmp_path / "comps.ts"
    ts_file.write_text("")

    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(
            returncode=1,
            stdout="",
            stderr="Error: no components found",
        )
        with pytest.raises(ValueError, match="No TypeScript components"):
            discover_ts_components(str(ts_file))


def test_discover_ts_components_malformed_json_raises(tmp_path) -> None:
    """discover_ts_components raises ValueError if discovery output is not valid JSON."""
    from zhanla_cli.runners import discover_ts_components

    ts_file = tmp_path / "bad.ts"
    ts_file.write_text("")

    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(
            returncode=0,
            stdout="not json at all",
            stderr="",
        )
        with pytest.raises(ValueError, match="manifest"):
            discover_ts_components(str(ts_file))


# ---------------------------------------------------------------------------
# TS discovery: only exported components are discoverable
# ---------------------------------------------------------------------------

def test_discover_ts_only_returns_exported_components(tmp_path) -> None:
    """Only exported TS component instances should appear in discovery results."""
    from zhanla_cli.runners import discover_ts_components

    ts_file = tmp_path / "components.ts"
    ts_file.write_text("")

    # Simulate TS discovery returning only the exported component
    exported_only = [
        {
            "name": "exportedTool",
            "description": "Exported",
            "component_type": "tool",
            "key": "exported-tool",
            "key_source": "explicit",
            "language": "typescript",
            "is_runnable": True,
            "is_eval": False,
            "execution_mode": "code",
            "fn_present": True,
            "file_path": str(ts_file),
            "symbol_name": "exportedTool",
        }
    ]

    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(
            returncode=0,
            stdout=json.dumps(exported_only),
            stderr="",
        )
        manifests = discover_ts_components(str(ts_file))

    assert len(manifests) == 1
    assert manifests[0].name == "exportedTool"
