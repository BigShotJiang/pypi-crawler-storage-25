"""Tests for ComponentManifest and to_manifest() serialization."""
from __future__ import annotations

import inspect
import textwrap

import pytest

import zhanla as bench
from zhanla.types import (
    ComponentType,
    Tool,
    CodeEval,
    Skill,
    Agent,
    LLMProcessor,
    LLMEval,
    Orchestration,
    OrchestrationStep,
    Conditional,
    Checklist,
    EvalTree,
    Branch,
    Edge,
    Leaf,
)
from zhanla.manifest import (
    ComponentManifest,
    ComponentRef,
    to_manifest,
    normalize_output_schema,
    validate_manifest,
    compute_behavior_hash,
    compute_snapshot_hash,
    _ref_to_dict,
)
from zhanla.types import _slugify, _validate_key


def _explicit_key(name: str) -> str:
    return _slugify(name)


# ---------------------------------------------------------------------------
# Key validation and slugification
# ---------------------------------------------------------------------------

def test_slugify_basic() -> None:
    assert _slugify("my_tool") == "my-tool"
    assert _slugify("MyTool") == "mytool"
    assert _slugify("my tool") == "my-tool"
    assert _slugify("My_Fancy Tool") == "my-fancy-tool"


def test_slugify_special_chars() -> None:
    assert _slugify("tool!@#$%") == "tool"
    assert _slugify("tool---name") == "tool-name"
    assert _slugify("  leading trailing  ") == "leading-trailing"


def test_slugify_truncates_to_64() -> None:
    long_name = "a" * 80
    result = _slugify(long_name)
    assert len(result) <= 64


def test_validate_key_accepts_valid() -> None:
    # No exception should be raised for these
    _validate_key("my-tool", "x")
    _validate_key("tool123", "x")
    _validate_key("a", "x")
    _validate_key("a" * 64, "x")


def test_validate_key_rejects_empty() -> None:
    with pytest.raises(ValueError, match="empty"):
        _validate_key("", "my_component")


def test_validate_key_rejects_uppercase() -> None:
    with pytest.raises(ValueError, match="key"):
        _validate_key("MyTool", "my_component")


def test_validate_key_rejects_underscores() -> None:
    with pytest.raises(ValueError, match="key"):
        _validate_key("my_tool", "my_component")


def test_validate_key_rejects_too_long() -> None:
    with pytest.raises(ValueError, match="64"):
        _validate_key("a" * 65, "my_component")


def test_component_explicit_key_stored() -> None:
    tool = Tool(
        name="my_tool",
        description="d",
        input_schema={},
        fn=lambda: {},
        output_schema={"r": str},
        key="custom-key",
    )
    assert tool.key == "custom-key"


def test_component_explicit_key_in_manifest() -> None:
    tool = Tool(
        name="my_tool",
        description="d",
        input_schema={},
        fn=lambda: {},
        output_schema={"r": str},
        key="custom-key",
    )
    m = to_manifest(tool)
    assert m.key == "custom-key"
    assert m.key_source == "explicit"


def test_component_missing_key_raises_type_error() -> None:
    with pytest.raises(TypeError):
        Tool(
            name="My Fancy Tool",
            description="d",
            input_schema={},
            fn=lambda: {},
            output_schema={"r": str},
        )


def test_component_invalid_key_raises_on_construction() -> None:
    with pytest.raises(ValueError):
        Tool(
            name="t",
            description="d",
            input_schema={},
            fn=lambda: {},
            output_schema={"r": str},
            key="Invalid_Key!",
        )


def test_typed_refs_use_explicit_keys() -> None:
    t1 = Tool(
        name="my_tool",
        description="d",
        input_schema={},
        fn=lambda: {},
        output_schema={"r": str},
        key=_explicit_key("my_tool"),
    )
    t2 = Tool(name="other tool", description="d", input_schema={}, fn=lambda: {}, output_schema={"r": str}, key="other-explicit")
    skill = Skill(name="s", description="d", instructions="Do it", tools=[t1, t2], key="s")
    m = to_manifest(skill)
    assert m.tool_refs is not None
    assert len(m.tool_refs) == 2
    keys = [r.key if isinstance(r, ComponentRef) else r["key"] for r in m.tool_refs]
    assert "my-tool" in keys
    assert "other-explicit" in keys


# ---------------------------------------------------------------------------
# normalize_output_schema
# ---------------------------------------------------------------------------

def test_normalize_schema_none() -> None:
    assert normalize_output_schema(None) is None


def test_normalize_schema_simple_dict() -> None:
    result = normalize_output_schema({"result": str, "count": int})
    assert result["type"] == "object"
    assert result["properties"]["result"] == {"type": "string"}
    assert result["properties"]["count"] == {"type": "number"}


def test_normalize_schema_bool() -> None:
    result = normalize_output_schema({"flag": bool})
    assert result["properties"]["flag"] == {"type": "boolean"}


def test_normalize_schema_list_type() -> None:
    result = normalize_output_schema({"items": list})
    assert result["properties"]["items"] == {"type": "array", "items": {}}


def test_normalize_schema_already_json_schema() -> None:
    schema = {
        "type": "object",
        "properties": {"x": {"type": "string"}},
    }
    result = normalize_output_schema(schema)
    assert result == schema


def test_normalize_schema_pydantic_model() -> None:
    try:
        from pydantic import BaseModel

        class MyOutput(BaseModel):
            result: str
            count: int

        result = normalize_output_schema(MyOutput)
        assert result["type"] == "object"
        assert "result" in result["properties"]
        assert "count" in result["properties"]
    except ImportError:
        pytest.skip("pydantic not installed")


# ---------------------------------------------------------------------------
# to_manifest for Tool
# ---------------------------------------------------------------------------

def test_to_manifest_tool() -> None:
    def fn(x: int) -> dict:
        return {"result": x}

    tool = Tool(
        name="my_tool",
        description="A tool",
        input_schema={},
        fn=fn,
        output_schema={"result": int},
        key="my-tool",
    )
    m = to_manifest(tool, file_path="components.py", symbol_name="my_tool")

    assert isinstance(m, ComponentManifest)
    assert m.name == "my_tool"
    assert m.description == "A tool"
    assert m.component_type == "tool"
    assert m.language == "python"
    assert m.is_runnable is True
    assert m.is_eval is False
    assert m.fn_present is True
    assert m.file_path == "components.py"
    assert m.symbol_name == "my_tool"
    assert m.is_async is False
    assert m.output_schema is not None
    assert m.output_schema["type"] == "object"
    assert m.key == "my-tool"
    assert m.key_source == "explicit"
    assert m.execution_mode == "code"
    # hashes are computed by the CLI, not stored in the manifest
    bh = compute_behavior_hash(m)
    assert bh is not None and len(bh) == 64


def test_to_manifest_tool_async() -> None:
    async def fn(x: int) -> dict:
        return {"result": x}

    tool = Tool(name="async_tool", description="d", input_schema={}, fn=fn, output_schema={"result": int}, key="async-tool")
    m = to_manifest(tool)
    assert m.is_async is True


def test_to_manifest_tool_source_code() -> None:
    def fn(x: int) -> dict:
        return {"result": x}

    tool = Tool(name="t", description="d", input_schema={}, fn=fn, output_schema={"result": int}, key="t")
    m = to_manifest(tool)
    assert m.source_code is not None
    assert "def fn" in m.source_code
    assert m.source_language == "python"
    assert m.source_format == "function"


# ---------------------------------------------------------------------------
# to_manifest for CodeEval
# ---------------------------------------------------------------------------

def test_to_manifest_code_eval() -> None:
    def score_fn(**kwargs) -> dict:
        return {"score": 0.9}

    ev = CodeEval(name="scorer", description="grades output", fn=score_fn, key="scorer")
    m = to_manifest(ev)

    assert m.name == "scorer"
    assert m.component_type == "code_eval"
    assert m.is_eval is True
    assert m.is_runnable is False
    assert m.fn_present is True
    assert compute_behavior_hash(m) is not None


# ---------------------------------------------------------------------------
# to_manifest for Skill
# ---------------------------------------------------------------------------

def test_to_manifest_skill() -> None:
    t = Tool(name="fetch", description="d", input_schema={}, fn=lambda: {}, output_schema={"result": str}, key="fetch")
    skill = Skill(
        name="summarize",
        description="Summarizes text",
        instructions="Summarize this",
        tools=[t],
        key="summarize",
    )
    m = to_manifest(skill)

    assert m.component_type == "skill"
    assert m.instructions == "Summarize this"
    assert m.fn_present is None
    assert m.tool_refs is not None
    assert len(m.tool_refs) == 1
    assert _ref_to_dict(m.tool_refs[0])["key"] == "fetch"
    assert m.is_runnable is False


def test_to_manifest_skill_without_source_metadata() -> None:
    skill = Skill(name="prompt_skill", description="d", instructions="Do something useful", key="prompt-skill")
    m = to_manifest(skill)
    assert m.fn_present is None
    assert m.source_code is None


# ---------------------------------------------------------------------------
# to_manifest for Agent
# ---------------------------------------------------------------------------

def test_to_manifest_agent() -> None:
    t = Tool(name="search", description="d", input_schema={}, fn=lambda: {}, output_schema={"result": str}, key="search")
    s = Skill(name="analyze", description="d", instructions="Analyze", key="analyze")
    sub = Agent(name="sub_agent", description="d", instructions="help", model="gpt-4", key="sub-agent")

    agent = Agent(
        name="main_agent",
        description="Main agent",
        instructions="You are helpful",
        model="claude-3-5-sonnet",
        tools=[t],
        skills=[s],
        agents=[sub],
        output_schema={"answer": str},
        key="main-agent",
    )
    m = to_manifest(agent)

    assert m.component_type == "agent"
    assert m.instructions == "You are helpful"
    assert m.model == "claude-3-5-sonnet"
    assert m.tool_refs is not None and _ref_to_dict(m.tool_refs[0])["key"] == "search"
    assert m.skill_refs is not None and _ref_to_dict(m.skill_refs[0])["key"] == "analyze"
    assert m.agent_refs is not None and _ref_to_dict(m.agent_refs[0])["key"] == "sub-agent"
    assert m.output_schema is not None
    assert m.is_runnable is True


# ---------------------------------------------------------------------------
# to_manifest for LLMProcessor
# ---------------------------------------------------------------------------

def test_to_manifest_llm_processor() -> None:
    proc = LLMProcessor(
        name="extractor",
        description="Extracts info",
        instructions="Extract key info",
        model="gpt-4o",
        output_schema={"key": str},
        key="extractor",
    )
    m = to_manifest(proc)

    assert m.component_type == "llm_processor"
    assert m.model == "gpt-4o"
    assert m.instructions == "Extract key info"
    assert m.is_runnable is True
    assert m.is_eval is False


# ---------------------------------------------------------------------------
# to_manifest for LLMEval
# ---------------------------------------------------------------------------

def test_to_manifest_llm_eval() -> None:
    ev = LLMEval(
        name="quality_rater",
        description="Rates quality",
        instructions="Rate the response",
        model="gpt-4o",
        key="quality-rater",
    )
    m = to_manifest(ev)

    assert m.component_type == "llm_eval"
    assert m.is_eval is True
    assert m.model == "gpt-4o"


# ---------------------------------------------------------------------------
# to_manifest for Orchestration
# ---------------------------------------------------------------------------

def test_to_manifest_orchestration() -> None:
    t1 = Tool(name="step1", description="d", input_schema={}, fn=lambda: {}, output_schema={"r": str}, key="step1")
    t2 = Tool(name="step2", description="d", input_schema={}, fn=lambda: {}, output_schema={"r": str}, key="step2")

    orch = Orchestration(
        name="pipeline",
        description="A pipeline",
        steps=[
            OrchestrationStep(name="s1", component=t1, next=["s2"]),
            OrchestrationStep(name="s2", component=t2),
        ],
        key="pipeline",
    )
    m = to_manifest(orch)

    assert m.component_type == "orchestration"
    assert m.is_runnable is True
    assert len(m.steps) == 2
    assert m.steps[0]["name"] == "s1"
    assert m.steps[0]["component_ref"]["key"] == "step1"
    assert m.steps[0]["next"] == ["s2"]
    assert m.steps[1]["name"] == "s2"
    assert m.steps[1]["next"] == []


def test_to_manifest_orchestration_with_conditional() -> None:
    t1 = Tool(name="check", description="d", input_schema={}, fn=lambda: {}, output_schema={"r": str}, key="check")
    t2 = Tool(name="pass_step", description="d", input_schema={}, fn=lambda: {}, output_schema={"r": str}, key="pass-step")
    t3 = Tool(name="fail_step", description="d", input_schema={}, fn=lambda: {}, output_schema={"r": str}, key="fail-step")

    cond = Conditional(condition=lambda ctx: True, if_true="s2", if_false="s3")

    orch = Orchestration(
        name="branching",
        description="d",
        steps=[
            OrchestrationStep(name="s1", component=t1, next=["cond"]),
            OrchestrationStep(name="cond", component=cond),
            OrchestrationStep(name="s2", component=t2),
            OrchestrationStep(name="s3", component=t3),
        ],
        key="branching",
    )
    m = to_manifest(orch)

    cond_step = next(s for s in m.steps if s["name"] == "cond")
    assert cond_step["is_conditional"] is True
    assert cond_step["if_true"] == "s2"
    assert cond_step["if_false"] == "s3"


# ---------------------------------------------------------------------------
# to_manifest for Checklist
# ---------------------------------------------------------------------------

def test_to_manifest_checklist() -> None:
    e1 = CodeEval(name="e1", description="d", fn=lambda **k: {"score": 1.0}, key="e1")
    e2 = CodeEval(name="e2", description="d", fn=lambda **k: {"score": 0.5}, key="e2")

    checklist = Checklist(
        name="quality_check",
        description="Quality checklist",
        evals=[e1, e2],
        weights=[0.7, 0.3],
        key="quality-check",
    )
    m = to_manifest(checklist)

    assert m.component_type == "checklist"
    assert m.is_eval is True
    assert m.eval_refs is not None
    assert [_ref_to_dict(r)["key"] for r in m.eval_refs] == ["e1", "e2"]
    assert m.weights == [0.7, 0.3]


def test_to_manifest_checklist_no_weights() -> None:
    e1 = CodeEval(name="e1", description="d", fn=lambda **k: {"score": 1.0}, key="e1")
    checklist = Checklist(name="c", description="d", evals=[e1], key="c")
    m = to_manifest(checklist)
    assert m.weights is None


# ---------------------------------------------------------------------------
# to_manifest for EvalTree
# ---------------------------------------------------------------------------

def test_to_manifest_eval_tree() -> None:
    branch_eval = CodeEval(name="router", description="d", fn=lambda **k: {"score": 0.8}, key="router")
    leaf_eval = CodeEval(name="scorer", description="d", fn=lambda **k: {"score": 0.9}, key="scorer")

    tree = EvalTree(
        name="adaptive_eval",
        description="Adaptive evaluation",
        root=Branch(
            eval=branch_eval,
            threshold=0.5,
            if_pass=[Edge(weight=1.0, node=Leaf(eval=leaf_eval))],
            if_fail=[Edge(weight=1.0, node=Leaf(eval=leaf_eval))],
        ),
        key="adaptive-eval",
    )
    m = to_manifest(tree)

    assert m.component_type == "eval_tree"
    assert m.is_eval is True
    assert m.root is not None
    assert m.root["eval_ref"]["key"] == "router"
    assert m.root["threshold"] == 0.5
    assert len(m.root["if_pass"]) == 1
    assert m.root["if_pass"][0]["weight"] == 1.0
    assert m.root["if_pass"][0]["node"]["type"] == "leaf"
    assert m.root["if_pass"][0]["node"]["eval_ref"]["key"] == "scorer"


# ---------------------------------------------------------------------------
# validate_manifest
# ---------------------------------------------------------------------------

def test_validate_manifest_valid_tool() -> None:
    def fn(x: int) -> dict:
        return {"result": x}

    tool = Tool(name="t", description="d", input_schema={}, fn=fn, output_schema={"result": int}, key="t")
    m = to_manifest(tool)
    errors = validate_manifest(m)
    assert errors == []


def _make_manifest(**kwargs) -> ComponentManifest:
    """Build a minimal ComponentManifest for validation tests."""
    defaults = {
        "name": "my_component",
        "description": "d",
        "component_type": "tool",
        "key": "my-component",
        "key_source": "explicit",
        "language": "python",
        "is_runnable": True,
        "is_eval": False,
        "execution_mode": "code",
    }
    defaults.update(kwargs)
    return ComponentManifest(**defaults)


def test_validate_manifest_missing_name() -> None:
    m = _make_manifest(name="")
    errors = validate_manifest(m)
    assert any("name" in e.lower() for e in errors)


def test_validate_manifest_missing_description() -> None:
    m = _make_manifest(name="my_tool", description="")
    errors = validate_manifest(m)
    assert any("description" in e.lower() for e in errors)


def test_validate_manifest_tool_requires_fn() -> None:
    m = _make_manifest(name="my_tool", fn_present=False)
    errors = validate_manifest(m)
    assert any("fn" in e.lower() for e in errors)


def test_validate_manifest_tool_requires_output_schema() -> None:
    m = _make_manifest(name="my_tool", fn_present=True, output_schema=None)
    errors = validate_manifest(m)
    assert any("output_schema" in e.lower() for e in errors)


def test_validate_manifest_agent_requires_instructions_and_model() -> None:
    m = _make_manifest(
        name="agent",
        component_type="agent",
        execution_mode="prompt",
        instructions=None,
        model=None,
    )
    errors = validate_manifest(m)
    assert any("instructions" in e.lower() for e in errors)
    assert any("model" in e.lower() for e in errors)


def test_validate_manifest_valid_code_eval() -> None:
    ev = CodeEval(name="ev", description="d", fn=lambda **k: {"score": 1.0}, key="ev")
    m = to_manifest(ev)
    errors = validate_manifest(m)
    assert errors == []


# ---------------------------------------------------------------------------
# Behavior hash and snapshot hash stability
# ---------------------------------------------------------------------------

def test_behavior_hash_stable_across_calls() -> None:
    def fn(x: int) -> dict:
        return {"result": x}

    tool = Tool(name="t", description="d", input_schema={}, fn=fn, output_schema={"result": int}, key="t")
    m1 = to_manifest(tool)
    m2 = to_manifest(tool)
    assert compute_behavior_hash(m1) == compute_behavior_hash(m2)


def test_behavior_hash_changes_with_different_fn() -> None:
    def fn_a(x: int) -> dict:
        return {"result": x}

    def fn_b(x: int) -> dict:
        return {"result": x * 2}

    tool_a = Tool(name="t", description="d", input_schema={}, fn=fn_a, output_schema={"result": int}, key="t")
    tool_b = Tool(name="t", description="d", input_schema={}, fn=fn_b, output_schema={"result": int}, key="t")

    assert compute_behavior_hash(to_manifest(tool_a)) != compute_behavior_hash(to_manifest(tool_b))


def test_behavior_hash_ignores_name_and_description() -> None:
    """behavior_hash must not change when only name/description change (rename safety)."""
    def fn(x: int) -> dict:
        return {"result": x}

    tool_a = Tool(name="tool_a", description="Original", input_schema={}, fn=fn, output_schema={"result": int}, key="tool-a")
    tool_b = Tool(name="tool_b", description="Renamed", input_schema={}, fn=fn, output_schema={"result": int}, key="tool-b")

    # Same source_code but different names → behavior_hash must match
    m_a = to_manifest(tool_a)
    m_b = to_manifest(tool_b)
    assert compute_behavior_hash(m_a) == compute_behavior_hash(m_b)


def test_snapshot_hash_changes_with_name() -> None:
    """snapshot_hash includes name/description, so renaming must produce a different hash."""
    def fn(x: int) -> dict:
        return {"result": x}

    tool_a = Tool(name="tool_a", description="d", input_schema={}, fn=fn, output_schema={"result": int}, key="tool-a")
    tool_b = Tool(name="tool_b", description="d", input_schema={}, fn=fn, output_schema={"result": int}, key="tool-b")

    assert compute_snapshot_hash(to_manifest(tool_a)) != compute_snapshot_hash(to_manifest(tool_b))


def test_snapshot_hash_stable_across_calls() -> None:
    def fn(x: int) -> dict:
        return {"result": x}

    tool = Tool(name="t", description="d", input_schema={}, fn=fn, output_schema={"result": int}, key="t")
    m1 = to_manifest(tool)
    m2 = to_manifest(tool)
    assert compute_snapshot_hash(m1) == compute_snapshot_hash(m2)


def test_hash_length() -> None:
    def fn(x: int) -> dict:
        return {"result": x}

    tool = Tool(name="t", description="d", input_schema={}, fn=fn, output_schema={"result": int}, key="t")
    m = to_manifest(tool)
    assert len(compute_behavior_hash(m)) == 64
    assert len(compute_snapshot_hash(m)) == 64


# ---------------------------------------------------------------------------
# TypeScript manifest round-trip (parsing from JSON)
# ---------------------------------------------------------------------------

def test_manifest_from_dict() -> None:
    """ComponentManifest can be constructed from a plain dict (e.g., parsed from TS discovery)."""
    data = {
        "name": "my_ts_tool",
        "description": "A TypeScript tool",
        "component_type": "tool",
        "key": "my-ts-tool",
        "key_source": "explicit",
        "language": "typescript",
        "is_runnable": True,
        "is_eval": False,
        "execution_mode": "code",
        "fn_present": True,
        "output_schema": {"type": "object", "properties": {"result": {"type": "string"}}},
        "file_path": "components.ts",
        "symbol_name": "my_ts_tool",
        "is_async": False,
        "source_language": "typescript",
        "source_format": "function",
    }
    m = ComponentManifest(**data)
    assert m.name == "my_ts_tool"
    assert m.key == "my-ts-tool"
    assert m.key_source == "explicit"
    assert m.language == "typescript"
    assert m.execution_mode == "code"
    assert m.output_schema["type"] == "object"
