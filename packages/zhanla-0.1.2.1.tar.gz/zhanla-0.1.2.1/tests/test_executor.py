"""Tests for class-based component execution."""
from __future__ import annotations

import asyncio
import json

import pytest

import zhanla as bench
from zhanla.types import LLMResponse, _slugify
from zhanla.trace_store import TraceContext
from zhanla_cli.executor import execute_row, load_dataset, _validate_output_schema, _build_path_taken


class FakeRunner:
    def __init__(
        self,
        text: str = "{}",
        *,
        tool_calls: list | None = None,
        capture_context: bool = False,
        repair_text: str | None = None,
    ) -> None:
        self.text = text
        self.tool_calls = tool_calls or []
        self.capture_context = capture_context
        self.repair_text = repair_text
        self.seen_messages: list[list[dict]] = []
        self.seen_models: list[str] = []
        self.contexts: list[TraceContext | None] = []
        self.json_repair_flags: list[bool] = []

    def build_messages(self, component: object, row: dict) -> list[dict]:
        messages = [
            {"role": "system", "content": getattr(component, "instructions", "")},
            {"role": "user", "content": json.dumps(row)},
        ]
        self.seen_messages.append(messages)
        return messages

    async def call_llm(
        self,
        messages: list[dict],
        model: str,
        tools: list | None,
        output_schema: object,
        json_repair: bool = False,
    ) -> LLMResponse:
        del messages, tools, output_schema
        self.seen_models.append(model)
        self.json_repair_flags.append(json_repair)
        if self.capture_context:
            from zhanla.trace_store import get_trace_context

            self.contexts.append(get_trace_context())
        if len(self.json_repair_flags) > 1 and self.repair_text is not None:
            return LLMResponse(text=self.repair_text, tool_calls=[], stop_reason="stop")
        return LLMResponse(text=self.text, tool_calls=self.tool_calls, stop_reason="stop")


def _key(name: str) -> str:
    return _slugify(name)


@pytest.mark.asyncio
async def test_execute_row_tool() -> None:
    def fn(x: int) -> dict:
        return {"result": x * 2}

    tool = bench.Tool(name="double", description="d", input_schema={}, fn=fn, output_schema={"result": int}, key=_key("double"))
    result = await execute_row(tool, None, {"x": 5}, "trigger-1")

    assert result.component_trace.name == "double"
    assert result.component_trace.output == {"result": 10}
    assert result.component_trace.status == "completed"
    assert result.component_trace.trigger_run_id == "trigger-1"
    assert result.eval_trace is None


@pytest.mark.asyncio
async def test_execute_row_with_eval() -> None:
    def tool_fn(x: int) -> dict:
        return {"result": x * 2}

    def eval_fn(**kwargs) -> dict:
        return {"score": 1.0 if kwargs.get("model_response") == "84" else 0.0}

    tool = bench.Tool(name="double", description="d", input_schema={}, fn=tool_fn, output_schema={"result": int}, key=_key("double"))
    ev = bench.CodeEval(name="scorer", description="d", fn=eval_fn, key=_key("scorer"))

    result = await execute_row(tool, ev, {"x": 42}, "trigger-2")

    assert result.component_trace.output == {"result": 84}
    assert result.eval_trace is not None
    assert result.eval_trace.output["score"] == 1.0
    assert result.eval_trace.trigger_run_id == "trigger-2"


@pytest.mark.asyncio
async def test_execute_row_short_circuits_eval_for_schema_mismatch_errors() -> None:
    def tool_fn(**_: object) -> dict:
        raise ValueError("unterminated json from model")

    def eval_fn(**kwargs) -> dict:
        raise AssertionError("eval should not be called for malformed JSON output")

    tool = bench.Tool(name="broken", description="d", input_schema={}, fn=tool_fn, output_schema={}, key=_key("broken"))
    ev = bench.CodeEval(name="scorer", description="d", fn=eval_fn, key=_key("scorer"))

    result = await execute_row(tool, ev, {"x": 1}, "trigger-demoted")

    assert result.component_trace.status == "completed"
    assert result.component_trace.output == {"_component_error": "unterminated json from model"}
    assert result.component_trace.error is None
    assert result.component_trace.path_taken is not None
    assert result.component_trace.path_taken["error"] == "unterminated json from model"
    assert result.eval_trace is not None
    assert result.eval_trace.status == "completed"
    assert result.eval_trace.output == {
        "score": 0.0,
        "passed": False,
        "reason": "Model response doesn't match the requested output schema.",
        "output_schema_error": "unterminated json from model",
    }


@pytest.mark.asyncio
async def test_execute_row_demotes_non_schema_component_error_into_eval_input() -> None:
    def tool_fn(**_: object) -> dict:
        raise ValueError("service unavailable")

    captured_kwargs: dict[str, str] = {}

    def eval_fn(**kwargs) -> dict:
        captured_kwargs.update(kwargs)
        payload = json.loads(kwargs["model_response"])
        return {"score": 0.0, "passed": False, "result": payload}

    tool = bench.Tool(name="broken", description="d", input_schema={}, fn=tool_fn, output_schema={}, key=_key("broken"))
    ev = bench.CodeEval(name="scorer", description="d", fn=eval_fn, key=_key("scorer"))

    result = await execute_row(tool, ev, {"x": 1}, "trigger-demoted")

    assert result.component_trace.status == "completed"
    assert result.component_trace.output == {"_component_error": "service unavailable"}
    assert result.eval_trace is not None
    assert result.eval_trace.status == "completed"
    assert result.eval_trace.output == {
        "score": 0.0,
        "passed": False,
        "result": {"_component_error": "service unavailable"},
    }
    assert captured_kwargs["model_response"] == '{"_component_error": "service unavailable"}'


@pytest.mark.asyncio
async def test_execute_row_eval_receives_text_contract() -> None:
    def tool_fn(a: int, b: str) -> dict:
        return {"computed": f"{a}-{b}"}

    received_kwargs = {}

    def eval_fn(**kwargs) -> dict:
        received_kwargs.update(kwargs)
        return {"score": 1.0}

    tool = bench.Tool(name="passthrough", description="d", input_schema={}, fn=tool_fn, output_schema={"computed": str}, key=_key("passthrough"))
    ev = bench.CodeEval(name="kwarg_checker", description="d", fn=eval_fn, key=_key("kwarg_checker"))

    await execute_row(tool, ev, {"a": 5, "b": "hello"}, "trigger-3")

    assert received_kwargs["model_input"] == '{"a": 5, "b": "hello"}'
    assert received_kwargs["model_response"] == '{"computed": "5-hello"}'
    assert received_kwargs["expected_output"] == ""


@pytest.mark.asyncio
async def test_execute_row_eval_receives_expected_output_text() -> None:
    def tool_fn(**kwargs) -> dict:
        return {"result": kwargs["x"]}

    received_kwargs = {}

    def eval_fn(**kwargs) -> dict:
        received_kwargs.update(kwargs)
        return {"score": 1.0}

    tool = bench.Tool(name="passthrough", description="d", input_schema={}, fn=tool_fn, output_schema={"result": int}, key=_key("passthrough"))
    ev = bench.CodeEval(name="kwarg_checker", description="d", fn=eval_fn, key=_key("kwarg_checker"))

    await execute_row(
        tool,
        ev,
        {"x": 5, "expected_output": {"target": 5}},
        "trigger-4",
    )

    assert received_kwargs["model_input"] == '{"expected_output": {"target": 5}, "x": 5}'
    assert received_kwargs["model_response"] == "5"
    assert received_kwargs["expected_output"] == '{"target": 5}'


@pytest.mark.asyncio
async def test_execute_row_eval_supports_legacy_two_arg_signature() -> None:
    def tool_fn(**kwargs) -> dict:
        return {"result": kwargs["x"]}

    captured: dict[str, str] = {}

    def eval_fn(model_response: str, expected_output: str) -> dict:
        captured["model_response"] = model_response
        captured["expected_output"] = expected_output
        return {"score": 1.0 if model_response == "5" else 0.0}

    tool = bench.Tool(name="passthrough", description="d", input_schema={}, fn=tool_fn, output_schema={"result": int}, key=_key("passthrough"))
    ev = bench.CodeEval(name="legacy_eval", description="d", fn=eval_fn, key=_key("legacy_eval"))

    result = await execute_row(
        tool,
        ev,
        {"x": 5, "expected_output": {"target": 5}},
        "trigger-legacy-two-arg",
    )

    assert result.eval_trace is not None
    assert result.eval_trace.error is None
    assert result.eval_trace.output["score"] == 1.0
    assert captured == {
        "model_response": "5",
        "expected_output": '{"target": 5}',
    }


@pytest.mark.asyncio
async def test_execute_row_eval_supports_legacy_output_arg_name() -> None:
    def tool_fn() -> dict:
        return {"priority": "high"}

    captured: dict[str, str] = {}

    def eval_fn(output: str) -> dict:
        captured["output"] = output
        return {"score": 1.0}

    tool = bench.Tool(name="priority", description="d", input_schema={}, fn=tool_fn, output_schema={"priority": str}, key=_key("priority"))
    ev = bench.CodeEval(name="legacy_output_eval", description="d", fn=eval_fn, key=_key("legacy_output_eval"))

    result = await execute_row(tool, ev, {}, "trigger-legacy-output")

    assert result.eval_trace is not None
    assert result.eval_trace.error is None
    assert result.eval_trace.output["score"] == 1.0
    assert captured["output"] == '{"priority": "high"}'


@pytest.mark.asyncio
async def test_execute_row_error_continues() -> None:
    def fn(x: int) -> dict:
        raise ValueError("fail on 1")

    tool = bench.Tool(name="err_tool", description="d", input_schema={}, fn=fn, output_schema={"result": int}, key=_key("err_tool"))
    result = await execute_row(tool, None, {"x": 1}, "err-run")

    assert result.component_trace.status == "failed"
    assert "fail on 1" in result.component_trace.error
    assert result.eval_trace is None


@pytest.mark.asyncio
async def test_execute_row_async_tool() -> None:
    async def fn(x: int) -> dict:
        await asyncio.sleep(0.001)
        return {"result": x}

    tool = bench.Tool(name="async_tool", description="d", input_schema={}, fn=fn, output_schema={"result": int}, key=_key("async_tool"))
    result = await execute_row(tool, None, {"x": 10}, "async-run")

    assert result.component_trace.output == {"result": 10}
    assert result.component_trace.status == "completed"


@pytest.mark.asyncio
async def test_execute_row_skill_with_fn() -> None:
    skill = bench.Skill(name="summarize", description="d", instructions="Summarize", key=_key("summarize"))
    result = await execute_row(skill, None, {"text": "hello world"}, "skill-run")

    assert result.component_trace.status == "failed"
    assert "cannot be executed directly" in result.component_trace.error


@pytest.mark.asyncio
async def test_execute_row_skill_without_fn() -> None:
    skill = bench.Skill(name="translate", description="d", instructions="Translate to French", key=_key("translate"))
    result = await execute_row(skill, None, {}, "skill-run")

    assert result.component_trace.status == "failed"
    assert "cannot be executed directly" in result.component_trace.error


@pytest.mark.asyncio
async def test_execute_checklist() -> None:
    def fn1(**kwargs) -> dict:
        return {"score": 1.0}

    def fn2(**kwargs) -> dict:
        return {"score": 0.5}

    e1 = bench.CodeEval(name="e1", description="d", fn=fn1, key=_key("e1"))
    e2 = bench.CodeEval(name="e2", description="d", fn=fn2, key=_key("e2"))
    checklist = bench.Checklist(
        name="quality",
        description="Quality check",
        evals=[e1, e2],
        weights=[0.6, 0.4],
        key=_key("quality"),
    )

    result = await execute_row(
        bench.Tool(name="t", description="d", input_schema={}, fn=lambda: {"out": 1}, output_schema={"out": int}, key=_key("t")),
        checklist,
        {},
        "checklist-run",
    )

    assert result.eval_trace is not None
    score = result.eval_trace.output["score"]
    # (1.0 * 0.6 + 0.5 * 0.4) / (0.6 + 0.4) = 0.8
    assert abs(score - 0.8) < 0.01


@pytest.mark.asyncio
async def test_execute_eval_tree() -> None:
    def branch_fn(**kwargs) -> dict:
        print("branch count", 3)
        return {"score": 0.8}  # >= 0.5 threshold, take pass branch

    def leaf_fn(**kwargs) -> dict:
        print("leaf score", 0.9)
        return {"score": 0.9}

    branch_eval = bench.CodeEval(name="branch_eval", description="d", fn=branch_fn, key=_key("branch_eval"))
    leaf_eval = bench.CodeEval(name="leaf_eval", description="d", fn=leaf_fn, key=_key("leaf_eval"))

    tree = bench.EvalTree(
        name="adaptive",
        description="d",
        root=bench.Branch(
            eval=branch_eval,
            threshold=0.5,
            if_pass=[bench.Edge(weight=1.0, node=bench.Leaf(eval=leaf_eval))],
            if_fail=[bench.Edge(weight=1.0, node=bench.Leaf(eval=leaf_eval))],
        ),
        key=_key("adaptive"),
    )

    result = await execute_row(
        bench.Tool(name="t", description="d", input_schema={}, fn=lambda: {"out": 1}, output_schema={"out": int}, key=_key("t")),
        tree,
        {},
        "tree-run",
    )

    assert result.eval_trace is not None
    assert abs(result.eval_trace.output["score"] - 0.9) < 0.01
    assert result.eval_trace.output["result"] == {
        "type": "branch",
        "name": "branch_eval",
        "score": 0.9,
        "threshold": 0.5,
        "routing_score": 0.8,
        "selected_branch": "if_pass",
        "routing_result": {
            "score": 0.8,
            "logs": [{"stream": "stdout", "message": "branch count 3"}],
        },
        "children": [
            {
                "type": "leaf",
                "name": "leaf_eval",
                "score": 0.9,
                "weight": 1.0,
                "result": {
                    "score": 0.9,
                    "logs": [{"stream": "stdout", "message": "leaf score 0.9"}],
                },
            }
        ],
    }


@pytest.mark.asyncio
async def test_execute_row_code_eval_captures_print_logs() -> None:
    def tool_fn() -> dict:
        return {"out": 1}

    def eval_fn(**kwargs) -> dict:
        print("claims count", 2)
        return {"score": 1.0}

    result = await execute_row(
        bench.Tool(name="t", description="d", input_schema={}, fn=tool_fn, output_schema={"out": int}, key=_key("t")),
        bench.CodeEval(name="print_eval", description="d", fn=eval_fn, key=_key("print_eval")),
        {},
        "print-run",
    )

    assert result.eval_trace is not None
    assert result.eval_trace.output == {
        "score": 1.0,
        "logs": [{"stream": "stdout", "message": "claims count 2"}],
    }


# ---------------------------------------------------------------------------
# path_taken population
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_execute_row_tool_path_taken() -> None:
    def fn(x: int) -> dict:
        return {"result": x * 2}

    tool = bench.Tool(name="double", description="multiplies by 2", input_schema={}, fn=fn, output_schema={"result": int}, key=_key("double"))
    result = await execute_row(tool, None, {"x": 5}, "run-1")

    pt = result.component_trace.path_taken
    assert pt is not None
    assert pt["kind"] == "tool"
    assert pt["function_definition"]["name"] == "double"
    assert pt["function_definition"]["description"] == "multiplies by 2"
    assert "source_code" in pt["function_definition"]
    assert pt["input"] == {"x": 5}
    assert pt["output"] == {"result": 10}
    assert "error" not in pt


@pytest.mark.asyncio
async def test_execute_row_tool_path_taken_error() -> None:
    def fn(x: int) -> dict:
        raise ValueError("bad input")

    tool = bench.Tool(name="broken", description="d", input_schema={}, fn=fn, output_schema={"result": int}, key=_key("broken"))
    result = await execute_row(tool, None, {"x": 1}, "run-err")

    pt = result.component_trace.path_taken
    assert pt is not None
    assert pt["kind"] == "tool"
    assert "error" in pt
    assert "bad input" in pt["error"]
    assert "output" not in pt


@pytest.mark.asyncio
async def test_execute_row_skill_path_taken() -> None:
    skill = bench.Skill(
        name="translate",
        description="d",
        instructions="Translate to French",
        key=_key("translate"),
    )
    result = await execute_row(skill, None, {}, "run-skill")

    pt = result.component_trace.path_taken
    assert pt is not None
    assert pt["kind"] == "skill"
    assert pt["prompt"] == "Translate to French"
    assert "cannot be executed directly" in pt["error"]


@pytest.mark.asyncio
async def test_execute_row_agent_path_taken() -> None:
    runner = FakeRunner('{"segment":"smb","reasoning":"ok"}')
    agent = bench.Agent(
        name="classifier",
        description="d",
        instructions="Classify leads",
        model="gpt-4o",
        runner=runner,
        key=_key("classifier"),
    )
    result = await execute_row(agent, None, {"company": "Acme", "employees": "50"}, "run-agent")

    pt = result.component_trace.path_taken
    assert pt is not None
    assert pt["kind"] == "agent"
    assert pt["prompt"] == "Classify leads"
    roles = [m["role"] for m in pt["messages"]]
    assert "system" in roles
    assert "user" in roles
    assert "assistant" in roles
    assert "error" not in pt


@pytest.mark.asyncio
async def test_execute_row_orchestration_path_taken() -> None:
    def step1_fn(**kwargs) -> dict:
        return {"a": 1}

    def step2_fn(**kwargs) -> dict:
        return {"b": 2}

    t1 = bench.Tool(name="t1", description="d", input_schema={}, fn=step1_fn, output_schema={"a": int}, key=_key("t1"))
    t2 = bench.Tool(name="t2", description="d", input_schema={}, fn=step2_fn, output_schema={"b": int}, key=_key("t2"))

    orch = bench.Orchestration(
        name="pipeline",
        description="d",
        steps=[
            bench.Step(name="first", component=t1, next=["second"]),
            bench.Step(name="second", component=t2, next=[]),
        ],
        key=_key("pipeline"),
    )
    result = await execute_row(orch, None, {"x": 1}, "run-orch")

    pt = result.component_trace.path_taken
    assert pt is not None
    assert pt["kind"] == "orchestration"
    assert isinstance(pt["steps"], list)
    step_names = [s["name"] for s in pt["steps"]]
    assert step_names == ["first", "second"]
    assert pt["steps"][0]["kind"] == "tool"
    assert pt["steps"][0]["prompt"] is None  # tools have no instructions
    assert pt["steps"][0]["output"] == {"a": 1}
    assert pt["steps"][1]["kind"] == "tool"
    assert pt["steps"][1]["prompt"] is None
    assert pt["steps"][1]["output"] == {"b": 2}
    assert "error" not in pt


@pytest.mark.asyncio
async def test_execute_row_orchestration_conditional_path_taken() -> None:
    """Only the branch that actually ran should appear in steps."""
    def true_fn(**kwargs) -> dict:
        return {"branch": "true"}

    def false_fn(**kwargs) -> dict:
        return {"branch": "false"}

    t_true = bench.Tool(name="true_step", description="d", input_schema={}, fn=true_fn, output_schema={"branch": str}, key=_key("true_step"))
    t_false = bench.Tool(name="false_step", description="d", input_schema={}, fn=false_fn, output_schema={"branch": str}, key=_key("false_step"))

    cond = bench.Conditional(
        condition=lambda acc: True,
        if_true="take_true",
        if_false="take_false",
    )

    orch = bench.Orchestration(
        name="branching",
        description="d",
        steps=[
            bench.Step(name="router", component=cond, next=[]),
            bench.Step(name="take_true", component=t_true, next=[]),
            bench.Step(name="take_false", component=t_false, next=[]),
        ],
        key=_key("branching"),
    )
    result = await execute_row(orch, None, {}, "run-cond")

    pt = result.component_trace.path_taken
    assert pt is not None
    assert pt["kind"] == "orchestration"
    step_names = [s["name"] for s in pt["steps"]]
    assert "take_true" in step_names
    assert "take_false" not in step_names


# ---------------------------------------------------------------------------
# _build_path_taken unit tests
# ---------------------------------------------------------------------------

def test_build_path_taken_tool() -> None:
    tool = bench.Tool(name="t", description="desc", input_schema={}, fn=lambda: {}, output_schema={}, key=_key("t"))
    pt = _build_path_taken(tool, {"x": 1}, {"y": 2}, None)
    assert pt["kind"] == "tool"
    assert "source_code" in pt["function_definition"]
    assert pt["input"] == {"x": 1}
    assert pt["output"] == {"y": 2}
    assert "error" not in pt


def test_build_path_taken_skill() -> None:
    skill = bench.Skill(name="s", description="d", instructions="Do X", key=_key("s"))
    pt = _build_path_taken(skill, {}, None, None)
    assert pt["kind"] == "skill"
    assert pt["prompt"] == "Do X"


def test_build_path_taken_agent() -> None:
    agent = bench.Agent(name="a", description="d", instructions="Think", model="gpt-4o", key=_key("a"))
    pt = _build_path_taken(agent, {}, {"out": 1}, None)
    assert pt["kind"] == "agent"
    assert pt["prompt"] == "Think"
    roles = [m["role"] for m in pt["messages"]]
    assert roles == ["system", "user", "assistant"]


def test_build_path_taken_orchestration() -> None:
    orch = bench.Orchestration(name="o", description="d", steps=[], key=_key("o"))
    steps = [{"name": "s1", "output": {}}]
    pt = _build_path_taken(orch, {}, None, None, orchestration_steps=steps)
    assert pt["kind"] == "orchestration"
    assert pt["steps"] == steps


def test_build_path_taken_unsupported_returns_none() -> None:
    ev = bench.CodeEval(name="e", description="d", fn=lambda: {}, key=_key("e"))
    assert _build_path_taken(ev, {}, None, None) is None


# ---------------------------------------------------------------------------
# Dataset loading
# ---------------------------------------------------------------------------

def test_load_json_dataset(tmp_path) -> None:
    path = tmp_path / "data.json"
    path.write_text(json.dumps([
        {"_config": {"name": "test_data", "description": "Test"}},
        {"x": 1, "y": "a"},
        {"x": 2, "y": "b"},
    ]))

    rows, config = load_dataset(str(path))
    assert len(rows) == 2
    assert config == {"name": "test_data", "description": "Test"}
    assert rows[0] == {"x": 1, "y": "a"}


def test_load_json_no_config(tmp_path) -> None:
    path = tmp_path / "data.json"
    path.write_text(json.dumps([{"x": 1}, {"x": 2}]))

    rows, config = load_dataset(str(path))
    assert len(rows) == 2
    assert config is None


def test_load_json_with_schema_header(tmp_path) -> None:
    path = tmp_path / "data.json"
    path.write_text(json.dumps([
        {
            "_schema": {
                "x": {"type": "integer"},
                "y": {"type": "string"},
            }
        },
        {"x": 1, "y": "a"},
        {"x": 2, "y": "b"},
    ]))

    rows, config = load_dataset(str(path))
    assert len(rows) == 2
    assert config == {
        "schema": {
            "x": {"type": "integer"},
            "y": {"type": "string"},
        }
    }
    assert rows[0] == {"x": 1, "y": "a"}


def test_load_json_legacy_object_shape(tmp_path) -> None:
    path = tmp_path / "data.json"
    path.write_text(json.dumps({
        "schema": {
            "x": {"type": "integer"},
            "y": {"type": "string"},
        },
        "rows": [
            {"x": 1, "y": "a"},
            {"x": 2, "y": "b"},
        ],
    }))

    rows, config = load_dataset(str(path))
    assert len(rows) == 2
    assert config == {
        "schema": {
            "x": {"type": "integer"},
            "y": {"type": "string"},
        }
    }
    assert rows[1] == {"x": 2, "y": "b"}


def test_load_csv_dataset(tmp_path) -> None:
    path = tmp_path / "data.csv"
    path.write_text("x,y\n1,a\n2,b\n")

    rows, config = load_dataset(str(path))
    assert len(rows) == 2
    assert rows[0] == {"x": "1", "y": "a"}
    assert config is None


def test_load_unsupported_format_raises(tmp_path) -> None:
    path = tmp_path / "data.txt"
    path.write_text("hello")

    with pytest.raises(ValueError, match="Unsupported"):
        load_dataset(str(path))


# ---------------------------------------------------------------------------
# Output schema validation
# ---------------------------------------------------------------------------

def test_validate_output_schema_passes() -> None:
    result = _validate_output_schema(
        {"results": ["a"], "count": 5},
        {"results": list, "count": int},
        "my_tool",
    )
    assert result is None


def test_validate_output_schema_missing_key() -> None:
    result = _validate_output_schema(
        {"results": ["a"]},
        {"results": list, "count": int},
        "my_tool",
    )
    assert result is not None
    assert "Missing keys" in result


def test_validate_output_schema_extra_key() -> None:
    result = _validate_output_schema(
        {"results": ["a"], "count": 5, "extra": True},
        {"results": list, "count": int},
        "my_tool",
    )
    assert result is not None
    assert "Extra keys" in result


def test_validate_output_schema_type_mismatch() -> None:
    result = _validate_output_schema(
        {"results": ["a"], "count": "five"},
        {"results": list, "count": int},
        "my_tool",
    )
    assert result is not None
    assert "Type mismatch" in result


def test_validate_output_schema_none_schema() -> None:
    result = _validate_output_schema(
        {"anything": "goes"},
        None,
        "my_tool",
    )
    assert result is None


def test_validate_output_schema_json_schema_object_passes() -> None:
    result = _validate_output_schema(
        {"industry": "technology", "company_size": "small", "enriched": True},
        {
            "type": "object",
            "properties": {
                "industry": {"type": "string"},
                "company_size": {"type": "string"},
                "enriched": {"type": "boolean"},
            },
        },
        "enrich_lead",
    )
    assert result is None


# ---------------------------------------------------------------------------
# runner execution path
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_execute_row_agent_with_runner() -> None:
    """Agent with runner executes through the runner contract."""
    runner = FakeRunner('{"team":"billing","reason":"routed: refund issue"}')
    agent = bench.Agent(
        name="router",
        description="d",
        instructions="Route tickets",
        model="claude-sonnet-4-6",
        runner=runner,
        key=_key("router"),
    )
    result = await execute_row(agent, None, {"message": "refund issue"}, "run-runner")

    assert result.component_trace.status == "completed"
    assert result.component_trace.output == {
        "team": "billing",
        "reason": "routed: refund issue",
        "_stopReason": "stop",
    }
    assert runner.seen_models == ["claude-sonnet-4-6"]


@pytest.mark.asyncio
async def test_execute_row_llm_processor_with_runner() -> None:
    """LLMProcessor with runner executes through the runner contract."""
    runner = FakeRunner('{"context_note":"confirmed","bullets":["bullet1"]}')
    proc = bench.LLMProcessor(
        name="context_step",
        description="d",
        instructions="Carry context",
        model="claude-haiku-4-5",
        runner=runner,
        key=_key("context_step"),
    )
    result = await execute_row(proc, None, {"input": {"topic": "AI"}}, "run-proc")

    assert result.component_trace.status == "completed"
    assert result.component_trace.output["context_note"] == "confirmed"


@pytest.mark.asyncio
async def test_execute_row_runner_returns_tool_calls_without_error_on_empty_text() -> None:
    runner = FakeRunner(
        "",
        tool_calls=[bench.ToolCall(name="lookup_customer", input={"customer_id": "cus_123"}, id="call_1")],
    )
    agent = bench.Agent(
        name="triage_with_tools",
        description="d",
        instructions="Use tools",
        model="claude-sonnet-4-6",
        runner=runner,
        key=_key("triage_with_tools"),
    )

    result = await execute_row(agent, None, {"question": "who is this?"}, "run-tools-only")

    assert result.component_trace.status == "completed"
    assert result.component_trace.output == {
        "_toolCalls": [{"name": "lookup_customer", "input": {"customer_id": "cus_123"}, "id": "call_1"}],
        "_stopReason": "stop",
    }


@pytest.mark.asyncio
async def test_execute_row_runner_returns_mixed_text_and_tool_calls() -> None:
    runner = FakeRunner(
        '{"answer":"Working on it"}',
        tool_calls=[bench.ToolCall(name="lookup_customer", input={"customer_id": "cus_123"}, id="call_1")],
    )
    agent = bench.Agent(
        name="triage_with_partial_answer",
        description="d",
        instructions="Use tools",
        model="claude-sonnet-4-6",
        runner=runner,
        output_schema={"answer": str},
        key=_key("triage_with_partial_answer"),
    )

    result = await execute_row(agent, None, {"question": "who is this?"}, "run-tools-mixed")

    assert result.component_trace.status == "completed"
    assert result.component_trace.output == {
        "answer": "Working on it",
        "_toolCalls": [{"name": "lookup_customer", "input": {"customer_id": "cus_123"}, "id": "call_1"}],
        "_stopReason": "stop",
    }


@pytest.mark.asyncio
async def test_execute_row_runner_preserves_malformed_tool_args() -> None:
    runner = FakeRunner(
        "",
        tool_calls=[
            bench.ToolCall(
                name="lookup_customer",
                input={},
                id="call_1",
                _parseError='{"customer_id":',
            )
        ],
    )
    agent = bench.Agent(
        name="triage_with_bad_args",
        description="d",
        instructions="Use tools",
        model="claude-sonnet-4-6",
        runner=runner,
        key=_key("triage_with_bad_args"),
    )

    result = await execute_row(agent, None, {"question": "who is this?"}, "run-tools-bad-args")

    assert result.component_trace.status == "completed"
    assert result.component_trace.output == {
        "_toolCalls": [{
            "name": "lookup_customer",
            "input": {},
            "id": "call_1",
            "_parseError": '{"customer_id":',
        }],
        "_stopReason": "stop",
    }


@pytest.mark.asyncio
async def test_execute_row_runner_skips_schema_validation_when_tool_calls_present() -> None:
    runner = FakeRunner(
        '{"other":"Working on it"}',
        tool_calls=[bench.ToolCall(name="lookup_customer", input={"customer_id": "cus_123"}, id="call_1")],
    )
    agent = bench.Agent(
        name="triage_with_partial_answer",
        description="d",
        instructions="Use tools",
        model="claude-sonnet-4-6",
        runner=runner,
        output_schema={"answer": str},
        key=_key("triage_with_partial_answer"),
    )

    result = await execute_row(agent, None, {"question": "who is this?"}, "run-tools-mixed")

    assert result.component_trace.status == "completed"
    assert result.component_trace.output == {
        "other": "Working on it",
        "_toolCalls": [{"name": "lookup_customer", "input": {"customer_id": "cus_123"}, "id": "call_1"}],
        "_stopReason": "stop",
    }


@pytest.mark.asyncio
async def test_execute_row_runner_returns_empty_response_with_stop_reason_only() -> None:
    runner = FakeRunner("")
    agent = bench.Agent(
        name="empty_response_agent",
        description="d",
        instructions="Use tools",
        model="claude-sonnet-4-6",
        runner=runner,
        output_schema={"answer": str},
        key=_key("empty_response_agent"),
    )

    result = await execute_row(agent, None, {"question": "who is this?"}, "run-empty")

    assert result.component_trace.status == "completed"
    assert result.component_trace.output == {"_stopReason": "stop"}


@pytest.mark.asyncio
async def test_execute_row_runner_forwards_json_repair_flag() -> None:
    runner = FakeRunner('{"answer":"fixed"}')
    agent = bench.Agent(
        name="repair_agent",
        description="d",
        instructions="Repair JSON",
        model="gpt-4o",
        runner=runner,
        output_schema={"answer": str},
        json_repair=True,
        key=_key("repair_agent"),
    )

    result = await execute_row(agent, None, {"question": "who is this?"}, "run-repair")

    assert result.component_trace.status == "completed"
    assert result.component_trace.output == {"answer": "fixed", "_stopReason": "stop"}
    assert runner.json_repair_flags == [True]


@pytest.mark.asyncio
async def test_execute_row_runner_raises_structured_error_when_repair_fails() -> None:
    class FailingRepairRunner(FakeRunner):
        async def call_llm(
            self,
            messages: list[dict],
            model: str,
            tools: list | None,
            output_schema: object,
            json_repair: bool = False,
        ) -> LLMResponse:
            del messages, model, tools, output_schema
            self.json_repair_flags.append(json_repair)
            raise ValueError('JSON repair failed for provider=openai model=gpt-4o original_response_preview="bad" repair_attempt_preview="still bad"')

    runner = FailingRepairRunner()
    agent = bench.Agent(
        name="repair_agent",
        description="d",
        instructions="Repair JSON",
        model="gpt-4o",
        runner=runner,
        output_schema={"answer": str},
        json_repair=True,
        key=_key("repair_agent"),
    )

    result = await execute_row(agent, None, {"question": "who is this?"}, "run-repair-fail")

    assert result.component_trace.status == "failed"
    assert "JSON repair failed for provider=" in result.component_trace.error
    assert runner.json_repair_flags == [True]


@pytest.mark.asyncio
async def test_execute_row_skill_is_not_runnable() -> None:
    """Skills are prompt-only and cannot execute in the Python CLI."""
    skill = bench.Skill(name="writer", description="d", instructions="Write", key=_key("writer"))
    result = await execute_row(skill, None, {}, "run-skill-llm")
    assert result.component_trace.status == "failed"
    assert "not runnable" in result.component_trace.error or "cannot be executed directly" in result.component_trace.error


@pytest.mark.asyncio
async def test_execute_row_runner_async() -> None:
    """Async runner call_llm is awaited correctly."""
    class AsyncRunner(FakeRunner):
        async def call_llm(
            self,
            messages: list[dict],
            model: str,
            tools: list | None,
            output_schema: object,
            json_repair: bool = False,
        ) -> LLMResponse:
            del messages, model, tools, output_schema, json_repair
            await asyncio.sleep(0.001)
            return LLMResponse(text='{"doubled":14}', tool_calls=[], stop_reason="stop")

    agent = bench.Agent(
        name="doubler",
        description="d",
        instructions="Double x",
        model="claude-sonnet-4-6",
        runner=AsyncRunner(),
        key=_key("doubler"),
    )
    result = await execute_row(agent, None, {"x": 7}, "run-async-llm")
    assert result.component_trace.output == {"doubled": 14, "_stopReason": "stop"}


@pytest.mark.asyncio
async def test_execute_row_runner_error() -> None:
    """Errors in runner execution are captured as failed status."""
    class BadRunner(FakeRunner):
        async def call_llm(
            self,
            messages: list[dict],
            model: str,
            tools: list | None,
            output_schema: object,
            json_repair: bool = False,
        ) -> LLMResponse:
            del messages, model, tools, output_schema, json_repair
            raise RuntimeError("LLM call failed")

    agent = bench.Agent(
        name="broken",
        description="d",
        instructions="Break",
        model="claude-sonnet-4-6",
        runner=BadRunner(),
        key=_key("broken"),
    )
    result = await execute_row(agent, None, {}, "run-err-llm")
    assert result.component_trace.status == "failed"
    assert "LLM call failed" in result.component_trace.error


@pytest.mark.asyncio
async def test_execute_row_runner_sets_trace_context() -> None:
    """Trace context is set during runner execution and reset after."""
    from zhanla.trace_store import get_trace_context

    runner = FakeRunner('{"ok":true}', capture_context=True)
    agent = bench.Agent(
        name="ctx_check",
        description="d",
        instructions="Check context",
        model="claude-sonnet-4-6",
        runner=runner,
        key=_key("ctx_check"),
    )
    await execute_row(
        agent,
        None,
        {},
        "trace-ctx-run",
        autorater_run_id="run-abc",
        dataset_item_id="item-xyz",
    )

    assert len(runner.contexts) == 1
    ctx = runner.contexts[0]
    assert ctx is not None
    assert ctx.autorater_run_id == "run-abc"
    assert ctx.dataset_item_id == "item-xyz"
    assert get_trace_context() is None


@pytest.mark.asyncio
async def test_execute_row_runner_with_eval() -> None:
    """Runner result flows into eval pipeline correctly."""
    runner = FakeRunner('{"priority":"urgent"}')
    def eval_fn(**kwargs: object) -> dict:
        return {"score": 1.0}

    agent = bench.Agent(
        name="triage",
        description="d",
        instructions="Triage",
        model="claude-sonnet-4-6",
        runner=runner,
        key=_key("triage"),
    )
    ev = bench.CodeEval(name="scorer", description="d", fn=eval_fn, key=_key("scorer"))
    result = await execute_row(agent, ev, {"message": "system outage"}, "run-eval-llm")

    assert result.component_trace.output == {"priority": "urgent", "_stopReason": "stop"}
    assert result.eval_trace is not None
    assert result.eval_trace.output["score"] == 1.0


@pytest.mark.asyncio
async def test_execute_row_agent_without_runner_errors() -> None:
    """Runner is required at execution time for runner-backed components."""
    agent = bench.Agent(
        name="classifier",
        description="d",
        instructions="Classify leads",
        model="gpt-4o",
        key=_key("classifier"),
    )
    result = await execute_row(agent, None, {"company": "Acme", "employees": "50"}, "run-placeholder")

    assert result.component_trace.status == "failed"
    assert "Runner is required for component 'classifier'" in result.component_trace.error
