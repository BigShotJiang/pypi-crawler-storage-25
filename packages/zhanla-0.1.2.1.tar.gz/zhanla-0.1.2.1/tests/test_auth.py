from __future__ import annotations

from pathlib import Path

import httpx
import pytest

from zhanla_cli import auth


def test_save_and_load_credentials(tmp_path: Path, monkeypatch) -> None:
    creds_path = tmp_path / "credentials.json"
    monkeypatch.setattr(auth, "CREDENTIALS_PATH", creds_path)

    data = {"key_id": "bm_kid_test", "secret": "bm_sec_test", "org_id": "org-1"}
    auth.save_credentials(data)

    loaded = auth.get_credentials()
    assert loaded == data


def test_delete_credentials(tmp_path: Path, monkeypatch) -> None:
    creds_path = tmp_path / "credentials.json"
    monkeypatch.setattr(auth, "CREDENTIALS_PATH", creds_path)

    auth.save_credentials({"key_id": "k"})
    auth.delete_credentials()

    assert auth.get_credentials() is None


def test_get_fresh_token_not_logged_in(tmp_path: Path, monkeypatch) -> None:
    creds_path = tmp_path / "nonexistent" / "credentials.json"
    monkeypatch.setattr(auth, "CREDENTIALS_PATH", creds_path)

    with pytest.raises(RuntimeError, match="Not logged in"):
        auth.get_fresh_token("https://example.com")


def test_get_credentials_rejects_invalid_saved_login(tmp_path: Path, monkeypatch) -> None:
    creds_path = tmp_path / "credentials.json"
    creds_path.write_text("{}")
    monkeypatch.setattr(auth, "CREDENTIALS_PATH", creds_path)

    with pytest.raises(RuntimeError, match="Run `zhanla login` again"):
        auth.get_credentials()


def test_get_fresh_token_maps_unauthorized_to_relogin(tmp_path: Path, monkeypatch) -> None:
    creds_path = tmp_path / "credentials.json"
    monkeypatch.setattr(auth, "CREDENTIALS_PATH", creds_path)
    auth.save_credentials({"key_id": "bad", "secret": "bad"})

    request = httpx.Request("POST", "https://example.com/api/v1/auth/token")
    response = httpx.Response(
        401,
        json={"error": "Invalid SDK API key."},
        request=request,
    )
    monkeypatch.setattr(auth.httpx, "post", lambda *args, **kwargs: response)

    with pytest.raises(RuntimeError, match="Run `zhanla login` again"):
        auth.get_fresh_token("https://example.com")


def test_exchange_key_for_token_surfaces_server_error(monkeypatch) -> None:
    request = httpx.Request("POST", "https://example.com/api/v1/auth/token")
    response = httpx.Response(
        500,
        json={
            "error": (
                "Zhanla server configuration error. This is on us, not your SDK API key "
                "or local setup. Please contact the Zhanla team."
            ),
        },
        request=request,
    )

    monkeypatch.setattr(auth.httpx, "post", lambda *args, **kwargs: response)

    with pytest.raises(
        RuntimeError,
        match=(
            "Server error from https://example.com "
            r"\(500 Internal Server Error\): Zhanla server configuration error\. "
            "This is on us, not your SDK API key or local setup\\. "
            "Please contact the Zhanla team\\."
        ),
    ):
        auth.exchange_key_for_token("bm_kid_test", "bm_sec_test", "https://example.com")
