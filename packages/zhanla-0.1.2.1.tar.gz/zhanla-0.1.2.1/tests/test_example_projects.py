from __future__ import annotations

import sys
from pathlib import Path

import pytest
import zhanla as bench

from zhanla_cli.discovery import discover_eval, discover_targeted_component

_EXAMPLE_ROOT = Path(__file__).resolve().parents[3] / "example projects"


def _example_spec(*parts: str, symbol: str) -> str:
    return f"{_EXAMPLE_ROOT.joinpath(*parts)}:{symbol}"


def _clear_example_modules(*module_names: str) -> None:
    for module_name in module_names:
        sys.modules.pop(module_name, None)


def test_async_research_llm_eval_imports_with_example_runner() -> None:
    _clear_example_modules("provider")

    component = discover_eval(
        _example_spec(
            "async-research-assistant",
            "research_pipeline_eval.py",
            symbol="research_quality_llm_eval",
        )
    )

    assert isinstance(component.runner, bench.Runner)
    assert component.output_schema == {"score": float, "reasoning": str}


def test_async_research_source_scanner_imports_as_runner_component() -> None:
    _clear_example_modules("provider", "source_scanner_tool")

    component, _ = discover_targeted_component(
        _example_spec(
            "async-research-assistant",
            "source_scanner_tool.py",
            symbol="source_scanner_py",
        )
    )

    assert component.component_type.value == "llm_processor"
    assert isinstance(component.runner, bench.Runner)
    assert component.output_schema == {"bullets": list}


def test_async_research_pipeline_imports_with_runner_backed_steps() -> None:
    _clear_example_modules("provider", "source_scanner_tool")

    component, _ = discover_targeted_component(
        _example_spec(
            "async-research-assistant",
            "research_pipeline.py",
            symbol="research_brief_pipeline_py",
        )
    )

    step_types = [
        step.component.component_type.value
        for step in component.steps
        if hasattr(step.component, "component_type")
    ]
    assert step_types == ["llm_processor", "llm_processor", "llm_processor", "tool"]


def test_tool_calling_demo_agent_imports_with_provider_backed_runner() -> None:
    _clear_example_modules("provider")

    component, _ = discover_targeted_component(
        _example_spec(
            "tool-calling-demo",
            "components.py",
            symbol="tool_calling_triage_agent_py",
        )
    )

    assert isinstance(component.runner, bench.Runner)
    assert component.output_schema == {"answer": str}


@pytest.mark.parametrize(
    ("parts", "symbol", "expected_schema"),
    [
        (
            ("customer-support-triage", "team_router_agent.py"),
            "team_router_py",
            {"team": str, "reason": str},
        ),
        (
            ("lead-enrichment-smoke-test", "lead_classifier_agent.py"),
            "lead_classifier_py",
            {"segment": str, "reason": str},
        ),
    ],
)
def test_example_agents_declare_expected_output_schema(
    parts: tuple[str, str],
    symbol: str,
    expected_schema: dict[str, type],
) -> None:
    _clear_example_modules("provider")

    component, _ = discover_targeted_component(_example_spec(*parts, symbol=symbol))

    assert component.output_schema == expected_schema
    for field_name in expected_schema:
        assert f'"{field_name}"' in component.instructions
