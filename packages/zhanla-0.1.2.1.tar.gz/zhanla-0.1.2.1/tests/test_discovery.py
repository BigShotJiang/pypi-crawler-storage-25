"""Tests for class-based component discovery."""
from __future__ import annotations

from pathlib import Path

import pytest

from zhanla_cli.discovery import (
    discover_components,
    discover_targeted_component,
    discover_eval,
    parse_target,
    validate_component,
    validate_components,
)


def test_parse_target_with_name() -> None:
    filepath, name = parse_target("component.py:my_tool")
    assert filepath == "component.py"
    assert name == "my_tool"


def test_parse_target_without_name() -> None:
    filepath, name = parse_target("component.py")
    assert filepath == "component.py"
    assert name is None


def test_parse_target_empty_name_raises() -> None:
    with pytest.raises(ValueError, match="Empty component name"):
        parse_target("component.py:")


def test_discover_from_file(tmp_path: Path) -> None:
    module_path = tmp_path / "sample.py"
    module_path.write_text(
        "import zhanla as bench\n\n"
        "def fn(x: int) -> dict:\n"
        "    return {'result': x}\n\n"
        "my_tool = bench.Tool(\n"
        "    name='sample_tool',\n"
        "    description='A tool',\n"
        "    input_schema={},\n"
        "    fn=fn,\n"
        "    output_schema={'result': int},\n"
        "    key='sample-tool',\n"
        ")\n"
    )

    components = discover_components(str(module_path))
    assert len(components) == 1
    assert components[0].name == "sample_tool"


def test_no_components_found_raises(tmp_path: Path) -> None:
    module_path = tmp_path / "empty.py"
    module_path.write_text("x = 1\n")

    with pytest.raises(ValueError, match="No bench components"):
        discover_components(str(module_path))


def test_invalid_file_raises() -> None:
    with pytest.raises(ValueError, match="File not found"):
        discover_components("/nonexistent/path.py")


def test_discover_targeted_component(tmp_path: Path) -> None:
    module_path = tmp_path / "comp.py"
    module_path.write_text(
        "import zhanla as bench\n\n"
        "def fn_a(x: int) -> dict:\n"
        "    return {'result': x}\n\n"
        "def fn_b(x: int) -> dict:\n"
        "    return {'result': x * 2}\n\n"
        "tool_a = bench.Tool(name='tool_a', description='d', input_schema={}, fn=fn_a, output_schema={'result': int}, key='tool-a')\n"
        "tool_b = bench.Tool(name='tool_b', description='d', input_schema={}, fn=fn_b, output_schema={'result': int}, key='tool-b')\n"
    )

    comp, all_comps = discover_targeted_component(f"{module_path}:tool_a")
    assert comp.name == "tool_a"
    assert len(all_comps) == 2


def test_discover_targeted_auto_select(tmp_path: Path) -> None:
    module_path = tmp_path / "single.py"
    module_path.write_text(
        "import zhanla as bench\n\n"
        "def fn(x: int) -> dict:\n"
        "    return {'result': x}\n\n"
        "only_tool = bench.Tool(name='only_one', description='d', input_schema={}, fn=fn, output_schema={'result': int}, key='only-one')\n"
    )

    comp, _ = discover_targeted_component(str(module_path))
    assert comp.name == "only_one"


def test_discover_targeted_multiple_no_name_raises(tmp_path: Path) -> None:
    module_path = tmp_path / "multi.py"
    module_path.write_text(
        "import zhanla as bench\n\n"
        "def fn() -> dict:\n"
        "    return {'result': 1}\n\n"
        "a = bench.Tool(name='a', description='d', input_schema={}, fn=fn, output_schema={'result': int}, key='a')\n"
        "b = bench.Tool(name='b', description='d', input_schema={}, fn=fn, output_schema={'result': int}, key='b')\n"
    )

    with pytest.raises(ValueError, match="Multiple components"):
        discover_targeted_component(str(module_path))


def test_discover_eval(tmp_path: Path) -> None:
    eval_path = tmp_path / "evaluator.py"
    eval_path.write_text(
        "import zhanla as bench\n\n"
        "def score_fn(**kwargs) -> dict:\n"
        "    return {'score': 0.9}\n\n"
        "my_scorer = bench.CodeEval(name='my_scorer', description='d', fn=score_fn, key='my-scorer')\n"
    )

    eval_comp = discover_eval(f"{eval_path}:my_scorer")
    assert eval_comp.name == "my_scorer"


def test_discover_eval_auto_select(tmp_path: Path) -> None:
    eval_path = tmp_path / "evaluator.py"
    eval_path.write_text(
        "import zhanla as bench\n\n"
        "def score_fn(**kwargs) -> dict:\n"
        "    return {'score': 0.9}\n\n"
        "my_scorer = bench.CodeEval(name='my_scorer', description='d', fn=score_fn, key='my-scorer')\n"
    )

    eval_comp = discover_eval(str(eval_path))
    assert eval_comp.name == "my_scorer"


def test_discover_eval_no_evals_raises(tmp_path: Path) -> None:
    path = tmp_path / "no_eval.py"
    path.write_text(
        "import zhanla as bench\n\n"
        "def fn() -> dict:\n"
        "    return {'result': 1}\n\n"
        "t = bench.Tool(name='not_eval', description='d', input_schema={}, fn=fn, output_schema={'result': int}, key='not-eval')\n"
    )

    with pytest.raises(ValueError, match="No eval components"):
        discover_eval(str(path))


def test_discover_targeted_component_supports_same_directory_imports(tmp_path: Path) -> None:
    helper_path = tmp_path / "helpers.py"
    helper_path.write_text(
        "def build_result(value: int) -> dict:\n"
        "    return {'value': value}\n"
    )

    module_path = tmp_path / "component.py"
    module_path.write_text(
        "import zhanla as bench\n"
        "from helpers import build_result\n\n"
        "def fn(value: int = 1) -> dict:\n"
        "    return build_result(value)\n\n"
        "importing_tool = bench.Tool(\n"
        "    name='importing_tool',\n"
        "    description='d',\n"
        "    input_schema={},\n"
        "    fn=fn,\n"
        "    output_schema={'value': int},\n"
        "    key='importing-tool',\n"
        ")\n"
    )

    comp, all_comps = discover_targeted_component(f"{module_path}:importing_tool")
    assert comp.name == "importing_tool"
    assert len(all_comps) == 1
