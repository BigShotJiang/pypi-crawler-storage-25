from zhanla_cli.graph_builder import build_graph_from_steps


def test_build_graph_from_steps_preserves_if_else_handles() -> None:
    graph = build_graph_from_steps([
        {"name": "fetch", "component_ref": {"key": "fetch", "component_type": "tool", "name": "fetch"}, "next": ["cond"]},
        {"name": "cond", "is_conditional": True, "if_true": "pass_step", "if_false": "fail_step"},
        {"name": "pass_step", "component_ref": {"key": "pass-step", "component_type": "tool", "name": "pass_step"}, "next": []},
        {"name": "fail_step", "component_ref": {"key": "fail-step", "component_type": "tool", "name": "fail_step"}, "next": []},
    ])

    cond_node = next(node for node in graph["nodes"] if node["id"] == "cond")
    assert cond_node["data"]["cases"] == [
        {
            "id": "cond__true",
            "name": "True",
            "condition": "condition() returned truthy",
        },
        {
            "id": "cond__false",
            "name": "False",
            "condition": "condition() returned falsy",
        },
    ]

    true_edge = next(edge for edge in graph["edges"] if edge["id"] == "cond-true")
    false_edge = next(edge for edge in graph["edges"] if edge["id"] == "cond-false")
    assert true_edge["sourceHandle"] == "cond__true"
    assert false_edge["sourceHandle"] == "cond__false"

