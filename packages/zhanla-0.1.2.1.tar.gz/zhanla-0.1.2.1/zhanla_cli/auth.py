"""Authentication helpers for the bench CLI."""
import json
from pathlib import Path
from typing import Optional

import httpx

CREDENTIALS_PATH = Path.home() / ".benchmark" / "credentials.json"
LOGIN_REQUIRED_MESSAGE = "Not logged in. Run `zhanla login` first."
LOGIN_AGAIN_MESSAGE = "Saved login is invalid or expired. Run `zhanla login` again."
INVALID_LOGIN_MESSAGE = "Saved login is unreadable or incomplete. Run `zhanla login` again."
SERVER_ERROR_SUFFIX = (
    "This is a problem with the Zhanla server, not your SDK API key or local setup. "
    "Please contact the Zhanla team."
)


def get_credentials() -> Optional[dict]:
    """Load saved credentials from disk."""
    if not CREDENTIALS_PATH.exists():
        return None
    try:
        data = json.loads(CREDENTIALS_PATH.read_text())
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(INVALID_LOGIN_MESSAGE) from exc

    if not isinstance(data, dict):
        raise RuntimeError(INVALID_LOGIN_MESSAGE)

    required_fields = ("key_id", "secret")
    if any(not isinstance(data.get(field), str) or not data[field].strip() for field in required_fields):
        raise RuntimeError(INVALID_LOGIN_MESSAGE)

    return data


def save_credentials(data: dict) -> None:
    """Persist credentials to disk, creating parent directories as needed."""
    CREDENTIALS_PATH.parent.mkdir(parents=True, exist_ok=True)
    CREDENTIALS_PATH.write_text(json.dumps(data, indent=2))


def delete_credentials() -> None:
    """Remove the credentials file if it exists."""
    if CREDENTIALS_PATH.exists():
        CREDENTIALS_PATH.unlink()


def _extract_error_detail(response: httpx.Response) -> str:
    """Pull the most useful error string out of an HTTP response."""
    try:
        payload = response.json()
    except ValueError:
        payload = None

    if isinstance(payload, dict):
        for key in ("error", "message", "detail"):
            value = payload.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()

    text = response.text.strip()
    if text:
        return text

    return response.reason_phrase or "Request failed"


def _format_server_error(base_url: str, response: httpx.Response) -> str:
    """Render a user-facing message for 5xx responses."""
    status = f"{response.status_code} {response.reason_phrase}".strip()
    detail = _extract_error_detail(response)
    lowered = detail.lower()
    if (
        "please contact the zhanla team" in lowered
        or "not your sdk api key or local setup" in lowered
    ):
        return f"Server error from {base_url} ({status}): {detail}"
    return f"Server error from {base_url} ({status}): {detail}. {SERVER_ERROR_SUFFIX}"


def exchange_key_for_token(key_id: str, secret: str, base_url: str) -> dict:
    """Exchange an SDK API key for a short-lived Supabase JWT.

    Calls POST /api/v1/auth/token and returns the response JSON, which
    includes: access_token, supabase_url, org_id, expires_at.
    """
    try:
        resp = httpx.post(
            f"{base_url}/api/v1/auth/token",
            json={"key_id": key_id, "secret": secret},
            timeout=10.0,
        )
    except httpx.RequestError as exc:
        raise RuntimeError(f"Request to {base_url} failed: {exc}") from exc

    if resp.is_error:
        if resp.status_code >= 500:
            raise RuntimeError(_format_server_error(base_url, resp))
        status = f"{resp.status_code} {resp.reason_phrase}".strip()
        detail = _extract_error_detail(resp)
        raise RuntimeError(f"{status}: {detail}")

    return resp.json()


def get_fresh_token(base_url: str) -> dict:
    """Load credentials from disk and exchange them for a fresh JWT.

    Returns a merged dict of credentials + token data:
        key_id, secret, supabase_url, org_id, access_token, expires_at
    """
    creds = get_credentials()
    if not creds:
        raise RuntimeError(LOGIN_REQUIRED_MESSAGE)
    try:
        token_data = exchange_key_for_token(creds["key_id"], creds["secret"], base_url)
    except RuntimeError as exc:
        message = str(exc)
        if message.startswith("401 ") or message.startswith("403 "):
            raise RuntimeError(LOGIN_AGAIN_MESSAGE) from exc
        raise
    return {**creds, **token_data}
