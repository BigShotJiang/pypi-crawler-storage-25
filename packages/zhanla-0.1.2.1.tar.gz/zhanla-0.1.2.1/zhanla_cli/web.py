"""Helpers for CLI web-backed datasets, prompts, and evaluations."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import httpx

from zhanla_cli.eval_contract import (
    derive_expected_output as _derive_expected_output,
    derive_model_input as _derive_model_input,
    derive_model_response as _derive_model_response,
    stringify_value as _stringify_value_impl,
)
from zhanla_cli.writer import get_supabase_client


@dataclass
class WebDataset:
    dataset_id: str
    dataset_name: str
    rows: list[dict]
    item_ids: list[str]


class SdkListRouteUnavailable(RuntimeError):
    """Raised when the server doesn't expose the SDK list endpoints yet."""


def _stringify_value(value: object) -> str:
    return _stringify_value_impl(value)


def derive_model_input(row: dict) -> str:
    return _derive_model_input(row)


def derive_expected_output(row: dict) -> str:
    """Return the plain-text eval contract for expected output.

    Managed evaluate-only runs should always receive text fields. Structured
    dataset values are serialized here, and eval code is responsible for
    parsing JSON/YAML/plain text as needed.
    """
    return _derive_expected_output(row)


def derive_model_response(output: object) -> str:
    """Return the plain-text eval contract for model responses.

    Component outputs may remain structured internally for tracing, upload, and
    debugging, but the eval boundary is text-only. Evals should parse this
    string themselves if they want structured data.
    """
    return _derive_model_response(output)


def fetch_web_dataset(
    *,
    supabase_url: str,
    supabase_anon_key: str,
    access_token: str,
    dataset_id: str,
) -> WebDataset:
    client = get_supabase_client(supabase_url, supabase_anon_key, access_token)

    dataset_result = (
        client.table("datasets")
        .select("id,name")
        .eq("id", dataset_id)
        .limit(1)
        .execute()
    )
    dataset_rows = getattr(dataset_result, "data", None) or []
    if not dataset_rows:
        raise RuntimeError(f"Dataset not found: {dataset_id}")

    item_result = (
        client.table("dataset_items")
        .select("id,input,is_active,created_at")
        .eq("dataset_id", dataset_id)
        .eq("is_active", True)
        .execute()
    )
    raw_items = getattr(item_result, "data", None) or []
    if not raw_items:
        raise RuntimeError(f"No active dataset items found for dataset: {dataset_id}")

    sorted_items = sorted(raw_items, key=lambda row: row.get("created_at") or "")
    return WebDataset(
        dataset_id=dataset_rows[0]["id"],
        dataset_name=dataset_rows[0].get("name") or dataset_id,
        rows=[item.get("input") or {} for item in sorted_items],
        item_ids=[item["id"] for item in sorted_items],
    )


def fetch_web_prompt(
    *,
    supabase_url: str,
    supabase_anon_key: str,
    access_token: str,
    prompt_id: str,
) -> dict:
    client = get_supabase_client(supabase_url, supabase_anon_key, access_token)
    result = (
        client.table("prompts")
        .select("id,slug,owner_id,owner_type")
        .eq("id", prompt_id)
        .limit(1)
        .execute()
    )
    rows = getattr(result, "data", None) or []
    if not rows:
        raise RuntimeError(f"Prompt not found: {prompt_id}")
    return rows[0]


def _sdk_headers(*, access_token: str, org_id: Optional[str]) -> dict[str, str]:
    headers = {"Authorization": f"Bearer {access_token}"}
    if org_id:
        headers["X-Org-Id"] = org_id
    return headers


def _extract_http_error(response: httpx.Response) -> str:
    try:
        payload = response.json()
    except ValueError:
        payload = None

    if isinstance(payload, dict):
        for key in ("error", "message", "detail"):
            value = payload.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()

    text = response.text.strip()
    return text or response.reason_phrase or "Request failed"


def _request_sdk_list(
    *,
    base_url: str,
    access_token: str,
    org_id: Optional[str],
    path: str,
    result_key: str,
    params: dict[str, str],
) -> list[dict]:
    try:
        response = httpx.get(
            f"{base_url.rstrip('/')}{path}",
            params=params,
            headers=_sdk_headers(access_token=access_token, org_id=org_id),
            timeout=30.0,
        )
    except httpx.RequestError as exc:
        raise SdkListRouteUnavailable(
            f"SDK list endpoint request failed for {path}: {exc}"
        ) from exc
    if response.status_code in {404, 405}:
        raise SdkListRouteUnavailable(
            f"SDK list endpoint is not available at {path}"
        )
    if not response.is_success:
        detail = _extract_http_error(response)
        raise RuntimeError(f"HTTP {response.status_code}: {detail}")

    payload = response.json()
    rows = payload.get(result_key)
    if not isinstance(rows, list):
        raise RuntimeError(f"Unexpected response from {path}: {payload}")
    return [row for row in rows if isinstance(row, dict)]


def list_web_datasets(
    *,
    base_url: str,
    access_token: str,
    org_id: Optional[str] = None,
    owner_type: Optional[str] = None,
    owner_id: Optional[str] = None,
    name: Optional[str] = None,
) -> list[dict]:
    params = {
        key: value
        for key, value in {
            "owner_type": owner_type,
            "owner_id": owner_id,
            "name": name,
        }.items()
        if value is not None
    }
    return _request_sdk_list(
        base_url=base_url,
        access_token=access_token,
        org_id=org_id,
        path="/api/v1/sdk/datasets",
        result_key="datasets",
        params=params,
    )


def list_web_autoraters(
    *,
    base_url: str,
    access_token: str,
    org_id: Optional[str] = None,
    owner_type: Optional[str] = None,
    owner_id: Optional[str] = None,
    name: Optional[str] = None,
) -> list[dict]:
    params = {
        key: value
        for key, value in {
            "owner_type": owner_type,
            "owner_id": owner_id,
            "name": name,
        }.items()
        if value is not None
    }
    return _request_sdk_list(
        base_url=base_url,
        access_token=access_token,
        org_id=org_id,
        path="/api/v1/sdk/autoraters",
        result_key="autoraters",
        params=params,
    )


def start_evaluate_only(
    *,
    base_url: str,
    access_token: str,
    autorater_id: str,
    items: list[dict],
    dataset_id: Optional[str] = None,
    org_id: Optional[str] = None,
) -> dict:
    payload: dict = {
        "autorater_id": autorater_id,
        "items": items,
    }
    if dataset_id is not None:
        payload["dataset_id"] = dataset_id

    headers: dict = {"Authorization": f"Bearer {access_token}"}
    if org_id:
        headers["X-Org-Id"] = org_id

    response = httpx.post(
        f"{base_url}/api/v1/sdk/evaluations/evaluate-only/start",
        json=payload,
        headers=headers,
        timeout=30.0,
    )
    if not response.is_success:
        try:
            detail = response.json().get("error", response.text)
        except Exception:
            detail = response.text
        raise RuntimeError(f"HTTP {response.status_code}: {detail}")
    data = response.json()
    if "runId" not in data:
        raise RuntimeError(f"Unexpected response from evaluate-only start: {data}")
    return data
