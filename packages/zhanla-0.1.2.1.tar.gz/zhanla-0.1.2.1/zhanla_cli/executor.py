"""Execute bench components against datasets with class-based runtime contracts."""
from __future__ import annotations

import asyncio
import csv
import io
import inspect
import json
import time
from contextlib import redirect_stderr, redirect_stdout
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any
from uuid import uuid4

from zhanla_cli.eval_contract import build_eval_kwargs
from zhanla.json_utils import parse_json_response
from zhanla.types import (
    ZhanlaComponent,
    ComponentType,
    EvalTrace,
    LLMResponse,
    Step,
    Tool,
    CodeEval,
    Skill,
    Agent,
    LLMProcessor,
    LLMEval,
    Orchestration,
    OrchestrationStep,
    Conditional,
    Checklist,
    EvalTree,
    Branch,
    Leaf,
)
from zhanla.trace_store import (
    TraceContext,
    set_trace_context,
    reset_trace_context,
)

_COMPONENT_ERROR_KEY = "_component_error"
_OUTPUT_SCHEMA_MISMATCH_REASON = "Model response doesn't match the requested output schema."
_JSON_OUTPUT_ERROR_MARKERS = (
    "unterminated string in json",
    "unexpected end of json input",
    "jsondecodeerror",
    "expecting value",
    "extra data",
    "unexpected token",
)
_LEGACY_CODE_EVAL_ARG_ALIASES = {
    "output": "model_response",
    "response": "model_response",
    "expected": "expected_output",
    "input": "model_input",
}
_CODE_EVAL_CONTEXT_PARAM_NAMES = {"context", "eval_context", "payload"}


def _normalize_captured_stream_logs(
    stdout_text: str,
    stderr_text: str,
) -> list[dict[str, str]]:
    logs: list[dict[str, str]] = []
    for line in stdout_text.splitlines():
        line = line.rstrip()
        if line:
            logs.append({"stream": "stdout", "message": line})
    for line in stderr_text.splitlines():
        line = line.rstrip()
        if line:
            logs.append({"stream": "stderr", "message": line})
    return logs


def _build_component_failure_output(error: str) -> dict[str, str]:
    """Serialize a component failure into structured output for downstream evals."""
    return {_COMPONENT_ERROR_KEY: error}


def _is_output_schema_mismatch_error(error: str) -> bool:
    normalized = error.lower()
    return (
        "output doesn't match declared output_schema" in normalized
        or any(marker in normalized for marker in _JSON_OUTPUT_ERROR_MARKERS)
    )


def _build_schema_mismatch_eval_output(error: str) -> dict[str, Any]:
    return {
        "score": 0.0,
        "passed": False,
        "reason": _OUTPUT_SCHEMA_MISMATCH_REASON,
        "output_schema_error": error,
    }


def load_dataset(path: str) -> tuple[list[dict], dict | None]:
    """Load a dataset file and return (rows, config_or_None).

    JSON format:
    - Top-level array of objects.
    - One or more leading metadata rows may define `_config` and/or `_schema`.
    - Remaining objects are data rows.
    - Legacy object form with `schema` + `rows` is still accepted.

    CSV format:
    - Standard CSV with header row.
    """
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Dataset file not found: {path}")

    if p.suffix == ".json":
        data = json.loads(p.read_text())
        if isinstance(data, dict):
            rows = data.get("rows")
            if not isinstance(rows, list):
                raise ValueError(
                    "JSON dataset object form must include a top-level 'rows' array."
                )
            config = {
                key: value
                for key, value in data.items()
                if key != "rows"
            } or None
            return rows, config

        if not isinstance(data, list):
            raise ValueError(
                "JSON dataset must be a top-level array of objects or a legacy object with 'rows'."
            )

        config: dict[str, Any] | None = None
        rows = []
        saw_data_row = False
        for item in data:
            if (
                not saw_data_row
                and isinstance(item, dict)
                and ("_config" in item or "_schema" in item)
            ):
                merged_config = dict(config or {})
                raw_config = item.get("_config")
                if isinstance(raw_config, dict):
                    merged_config.update(raw_config)
                elif raw_config is not None:
                    merged_config["_config"] = raw_config
                if "_schema" in item:
                    merged_config["schema"] = item["_schema"]
                config = merged_config or None
                continue

            saw_data_row = True
            rows.append(item)
        return rows, config

    if p.suffix == ".csv":
        with p.open(newline="") as f:
            return list(csv.DictReader(f)), None

    raise ValueError(f"Unsupported dataset format: {p.suffix!r}. Expected .json or .csv.")


# ---------------------------------------------------------------------------
# Output schema validation
# ---------------------------------------------------------------------------

def _validate_output_schema(output: dict, schema: Any, component_name: str) -> str | None:
    """Validate output against declared schema. Returns error message or None."""
    if schema is None:
        return None

    # Get expected keys
    expected_keys: dict[str, Any] = {}
    if isinstance(schema, dict):
        if schema.get("type") == "object" and isinstance(schema.get("properties"), dict):
            expected_keys = schema["properties"]
        else:
            expected_keys = schema
    elif isinstance(schema, type) and hasattr(schema, "model_fields"):
        # Pydantic model
        expected_keys = {name: field.annotation for name, field in schema.model_fields.items()}
    else:
        return None

    if not expected_keys:
        return None

    actual_keys = set(output.keys())
    expected_key_set = set(expected_keys.keys())

    missing = expected_key_set - actual_keys
    extra = actual_keys - expected_key_set

    errors: list[str] = []
    if missing:
        errors.append(f"Missing keys: {', '.join(sorted(missing))}")
    if extra:
        errors.append(f"Extra keys: {', '.join(sorted(extra))}")

    # Type checking
    for key in expected_key_set & actual_keys:
        expected_type = expected_keys[key]
        actual_value = output[key]
        if isinstance(expected_type, dict):
            json_type = expected_type.get("type")
            if json_type is not None:
                type_map: dict[str, tuple[type, ...]] = {
                    "string": (str,),
                    "number": (int, float),
                    "integer": (int,),
                    "boolean": (bool,),
                    "array": (list,),
                    "object": (dict,),
                    "null": (type(None),),
                }
                allowed_types = type_map.get(json_type)
                if allowed_types is not None and not isinstance(actual_value, allowed_types):
                    expected_name = json_type
                    errors.append(
                        f"Type mismatch for '{key}': expected {expected_name}, "
                        f"got {type(actual_value).__name__}"
                    )
            continue

        if expected_type is not None and not isinstance(actual_value, expected_type):
            errors.append(
                f"Type mismatch for '{key}': expected {expected_type.__name__}, "
                f"got {type(actual_value).__name__}"
            )

    if errors:
        schema_repr = {
            k: (v if isinstance(v, dict) else getattr(v, "__name__", str(v)))
            for k, v in expected_keys.items()
        }
        return (
            f'Error: {component_name} output doesn\'t match declared output_schema.\n\n'
            f'  {chr(10).join(errors)}\n\n'
            f'  Declared:  {schema_repr}\n'
            f'  Actual:    {output}\n\n'
            f'Fix the output_schema or the function return value.'
        )
    return None


# ---------------------------------------------------------------------------
# Component execution
# ---------------------------------------------------------------------------

@dataclass
class RowResult:
    """Result of executing one dataset row through component + eval pipeline."""
    row: dict
    component_trace: EvalTrace
    eval_trace: EvalTrace | None = None


async def _execute_fn(fn: Any, args: list[Any], kwargs: dict, is_async: bool) -> Any:
    """Execute a sync or async callable."""
    if is_async:
        return await fn(*args, **kwargs)
    return fn(*args, **kwargs)


def _prepare_code_eval_call(fn: Any, kwargs: dict[str, Any]) -> tuple[list[Any], dict[str, Any]]:
    """Adapt canonical eval kwargs to older Python CodeEval function signatures."""
    try:
        signature = inspect.signature(fn)
    except (TypeError, ValueError):
        return [], kwargs

    params = list(signature.parameters.values())
    if any(param.kind == inspect.Parameter.VAR_KEYWORD for param in params):
        return [], kwargs

    concrete_params = [param for param in params if param.kind != inspect.Parameter.VAR_POSITIONAL]
    if len(concrete_params) == 1 and concrete_params[0].name in _CODE_EVAL_CONTEXT_PARAM_NAMES:
        param = concrete_params[0]
        if param.kind == inspect.Parameter.KEYWORD_ONLY:
            return [], {param.name: dict(kwargs)}
        return [dict(kwargs)], {}

    canonical_order = ("model_response", "expected_output", "model_input")
    used_keys: set[str] = set()
    args: list[Any] = []
    named_kwargs: dict[str, Any] = {}

    def next_unused_key() -> str | None:
        for key in canonical_order:
            if key in kwargs and key not in used_keys:
                return key
        return None

    for param in params:
        if param.kind == inspect.Parameter.VAR_POSITIONAL:
            next_key = next_unused_key()
            while next_key is not None:
                args.append(kwargs[next_key])
                used_keys.add(next_key)
                next_key = next_unused_key()
            continue

        canonical_key: str | None = None
        if param.name in kwargs:
            canonical_key = param.name
        else:
            canonical_key = _LEGACY_CODE_EVAL_ARG_ALIASES.get(param.name)

        if canonical_key is None or canonical_key not in kwargs or canonical_key in used_keys:
            if param.kind in (inspect.Parameter.POSITIONAL_ONLY, inspect.Parameter.POSITIONAL_OR_KEYWORD):
                canonical_key = next_unused_key()
            else:
                canonical_key = None

        if canonical_key is None:
            continue

        used_keys.add(canonical_key)
        value = kwargs[canonical_key]
        if param.kind == inspect.Parameter.KEYWORD_ONLY:
            named_kwargs[param.name] = value
        else:
            args.append(value)

    return args, named_kwargs


async def _run_tool(comp: Tool, kwargs: dict) -> dict:
    """Execute a Tool component."""
    result = await _execute_fn(comp.fn, [], kwargs, comp.is_async)
    if isinstance(result, dict):
        return result
    return {"result": result}


async def _run_code_eval(comp: CodeEval, kwargs: dict) -> dict:
    """Execute a CodeEval component."""
    stdout_buffer = io.StringIO()
    stderr_buffer = io.StringIO()
    call_args, call_kwargs = _prepare_code_eval_call(comp.fn, kwargs)
    with redirect_stdout(stdout_buffer), redirect_stderr(stderr_buffer):
        result = await _execute_fn(comp.fn, call_args, call_kwargs, comp.is_async)
    logs = _normalize_captured_stream_logs(
        stdout_buffer.getvalue(),
        stderr_buffer.getvalue(),
    )
    if isinstance(result, dict):
        return {**result, "logs": logs} if logs else result
    return {"score": result, "logs": logs} if logs else {"score": result}


async def _run_skill(comp: Skill, kwargs: dict) -> dict:
    """Skills are prompt-only definitions and are not directly executable."""
    raise ValueError(
        f"Skill '{comp.name}' cannot be executed directly. "
        "Skills are prompt-only and not runnable in the Python CLI."
    )


async def _run_runner_component(
    comp: Agent | LLMProcessor | LLMEval,
    kwargs: dict,
) -> dict:
    """Execute a runner-backed component and validate structured output."""
    runner = getattr(comp, "runner", None)
    if runner is None:
        raise ValueError(
            f"Runner is required for component '{comp.name}'. Set component.runner explicitly."
        )

    model = getattr(comp, "model", None)
    if not model:
        raise ValueError(
            f"Model is required for component '{comp.name}'. Set component.model explicitly."
        )

    messages = runner.build_messages(comp, kwargs)
    response = await runner.call_llm(
        messages=messages,
        model=model,
        tools=getattr(comp, "tools", None),
        output_schema=getattr(comp, "output_schema", None),
        json_repair=getattr(comp, "json_repair", False),
        temperature=getattr(comp, "temperature", None),
        top_k=getattr(comp, "top_k", None),
    )
    return _parse_runner_response(comp, response)


def _parse_runner_response(
    comp: Agent | LLMProcessor | LLMEval,
    response: LLMResponse,
) -> dict:
    """Parse text output from a runner and validate it against the declared schema."""
    text = response.text.strip()
    has_text_output = bool(text)
    has_tool_calls = bool(response.tool_calls)
    if not text:
        result: dict[str, Any] = {}
    else:
        try:
            parsed = parse_json_response(text)
        except Exception:
            result = {"result": text}
        else:
            if not isinstance(parsed, dict):
                result = {"result": parsed}
            else:
                result = parsed

    if not has_tool_calls and has_text_output:
        schema_error = _validate_output_schema(result, getattr(comp, "output_schema", None), comp.name)
        if schema_error is not None:
            raise ValueError(schema_error)

    if has_tool_calls:
        result["_toolCalls"] = [
            {
                "name": tc.name,
                "input": tc.input,
                "id": tc.id,
                **({"_parseError": tc._parseError} if tc._parseError else {}),
            }
            for tc in response.tool_calls
        ]
    if response.stop_reason is not None:
        result["_stopReason"] = response.stop_reason
    return result


async def _run_agent(comp: Agent, kwargs: dict) -> dict:
    """Execute an Agent component via its configured runner."""
    return await _run_runner_component(comp, kwargs)


async def _run_llm_processor(comp: LLMProcessor, kwargs: dict) -> dict:
    """Execute an LLMProcessor component via its configured runner."""
    return await _run_runner_component(comp, kwargs)


async def _run_llm_eval(comp: LLMEval, kwargs: dict) -> dict:
    """Execute an LLMEval component via its configured runner."""
    return await _run_runner_component(comp, kwargs)


async def _run_orchestration(
    comp: Orchestration,
    input_data: dict,
    steps_collector: list[dict] | None = None,
) -> dict:
    """Execute an Orchestration DAG."""
    accumulated: dict[str, Any] = {"input": input_data}
    steps = {s.name: s for s in comp.steps}

    # Find the first step (the one not referenced as a next target by any other)
    all_next_targets: set[str] = set()
    for s in comp.steps:
        if isinstance(s.component, Conditional):
            all_next_targets.add(s.component.if_true)
            all_next_targets.add(s.component.if_false)
        all_next_targets.update(s.next)

    start_candidates = [s for s in comp.steps if s.name not in all_next_targets]
    if not start_candidates:
        start_candidates = [comp.steps[0]]

    current_step_name = start_candidates[0].name
    last_output: dict = {}

    visited: set[str] = set()
    while current_step_name and current_step_name not in visited:
        visited.add(current_step_name)
        step = steps.get(current_step_name)
        if step is None:
            break

        component = step.component

        if isinstance(component, Conditional):
            # Conditional produces no output, just routes
            result = component.condition(accumulated)
            current_step_name = component.if_true if result else component.if_false
            continue

        # Execute the step's component
        step_output = await _execute_component(component, accumulated)
        accumulated[step.name] = step_output
        last_output = step_output

        if steps_collector is not None:
            steps_collector.append({
                "name": current_step_name,
                "kind": component.component_type.value,
                "prompt": getattr(component, "instructions", None),
                "output": step_output,
            })

        # Determine next step
        if step.next:
            current_step_name = step.next[0]
        else:
            current_step_name = ""

    return last_output


async def _run_checklist(comp: Checklist, kwargs: dict) -> dict:
    """Execute a Checklist eval - runs all evals and computes weighted average."""
    scores: list[float] = []
    weights = comp.weights or [1.0] * len(comp.evals)
    details: list[dict] = []

    for eval_comp in comp.evals:
        result = await _execute_component(eval_comp, kwargs)
        score = float(result.get("score", 0.0))
        scores.append(score)
        details.append({"name": eval_comp.name, "score": score, **result})

    weighted_sum = sum(s * w for s, w in zip(scores, weights))
    total_weight = sum(weights)
    final_score = weighted_sum / total_weight if total_weight > 0 else 0.0

    return {"score": final_score, "details": details}


async def _run_eval_tree(comp: EvalTree, kwargs: dict) -> dict:
    """Execute an EvalTree - route through branches, score at leaves."""
    score, details, result = await _eval_branch(comp.root, kwargs)
    return {"score": score, "details": details, "result": result}


async def _eval_branch(branch: Branch, kwargs: dict) -> tuple[float, list[dict], dict]:
    """Recursively evaluate a Branch node."""
    # Run the branch eval for routing
    branch_result = await _execute_component(branch.eval, kwargs)
    branch_score = float(branch_result.get("score", 0.0))

    # Choose branch based on threshold
    took_pass = branch_score >= branch.threshold
    edges = branch.if_pass if took_pass else branch.if_fail

    # Evaluate the selected edges
    leaf_scores: list[tuple[float, float]] = []  # (score, weight)
    details: list[dict] = []
    children: list[dict] = []

    details.append(
        {
            "type": "branch",
            "name": branch.eval.name,
            "score": branch_score,
            "threshold": branch.threshold,
            "selected_branch": "if_pass" if took_pass else "if_fail",
            "result": branch_result,
        }
    )

    for edge in edges:
        if isinstance(edge.node, Leaf):
            result = await _execute_component(edge.node.eval, kwargs)
            score = float(result.get("score", 0.0))
            leaf_scores.append((score, edge.weight))
            leaf_node = {
                "type": "leaf",
                "name": edge.node.eval.name,
                "score": score,
                "weight": edge.weight,
                "result": result,
            }
            details.append(leaf_node)
            children.append(leaf_node)
        elif isinstance(edge.node, Branch):
            sub_score, sub_details, sub_tree = await _eval_branch(edge.node, kwargs)
            leaf_scores.append((sub_score, edge.weight))
            details.extend(sub_details)
            children.append({**sub_tree, "weight": edge.weight})

    # Weighted average
    if leaf_scores:
        weighted_sum = sum(s * w for s, w in leaf_scores)
        total_weight = sum(w for _, w in leaf_scores)
        final_score = weighted_sum / total_weight if total_weight > 0 else 0.0
    else:
        final_score = 0.0

    return (
        final_score,
        details,
        {
            "type": "branch",
            "name": branch.eval.name,
            "score": final_score,
            "threshold": branch.threshold,
            "routing_score": branch_score,
            "selected_branch": "if_pass" if took_pass else "if_fail",
            "routing_result": branch_result,
            "children": children,
        },
    )


async def _execute_component(comp: ZhanlaComponent, kwargs: dict) -> dict:
    """Execute any component type and return its output dict."""
    ct = comp.component_type

    if ct == ComponentType.TOOL:
        return await _run_tool(comp, kwargs)  # type: ignore[arg-type]
    if ct == ComponentType.CODE_EVAL:
        return await _run_code_eval(comp, kwargs)  # type: ignore[arg-type]
    if ct == ComponentType.SKILL:
        return await _run_skill(comp, kwargs)  # type: ignore[arg-type]
    if ct == ComponentType.AGENT:
        return await _run_agent(comp, kwargs)  # type: ignore[arg-type]
    if ct == ComponentType.LLM_PROCESSOR:
        return await _run_llm_processor(comp, kwargs)  # type: ignore[arg-type]
    if ct == ComponentType.LLM_EVAL:
        return await _run_llm_eval(comp, kwargs)  # type: ignore[arg-type]
    if ct == ComponentType.ORCHESTRATION:
        return await _run_orchestration(comp, kwargs)  # type: ignore[arg-type]
    if ct == ComponentType.CHECKLIST:
        return await _run_checklist(comp, kwargs)  # type: ignore[arg-type]
    if ct == ComponentType.EVAL_TREE:
        return await _run_eval_tree(comp, kwargs)  # type: ignore[arg-type]

    raise ValueError(f"Unsupported component type: {ct}")


def _build_path_taken(
    component: ZhanlaComponent,
    input_data: dict,
    output: dict | None,
    error: str | None,
    orchestration_steps: list[dict] | None = None,
) -> dict | None:
    """Build a PathTaken dict from a completed component execution."""
    ct = component.component_type

    if ct == ComponentType.TOOL:
        try:
            source_code = inspect.getsource(component.fn)  # type: ignore[union-attr]
        except (OSError, TypeError):
            source_code = None
        result: dict[str, Any] = {
            "kind": "tool",
            "function_definition": {
                "name": component.name,
                "description": component.description,
                "source_code": source_code,
            },
            "input": input_data,
        }
        if output is not None:
            result["output"] = output
        if error is not None:
            result["error"] = error
        return result

    if ct == ComponentType.SKILL:
        result = {
            "kind": "skill",
            "prompt": getattr(component, "instructions", "") or "",
        }
        if error is not None:
            result["error"] = error
        return result

    if ct == ComponentType.AGENT:
        instructions = getattr(component, "instructions", None)
        messages: list[dict] = []
        if instructions:
            messages.append({"role": "system", "content": instructions})
        messages.append({"role": "user", "content": input_data})
        if output is not None:
            messages.append({"role": "assistant", "content": output})
        result = {"kind": "agent", "prompt": instructions or "", "messages": messages}
        if error is not None:
            result["error"] = error
        return result

    if ct == ComponentType.ORCHESTRATION:
        result = {"kind": "orchestration", "steps": orchestration_steps or []}
        if error is not None:
            result["error"] = error
        return result

    return None


async def execute_row(
    component: ZhanlaComponent,
    eval_component: ZhanlaComponent | None,
    row: dict,
    trigger_run_id: str,
    *,
    autorater_run_id: str | None = None,
    dataset_item_id: str | None = None,
    supabase_client: Any | None = None,
) -> RowResult:
    """Execute one dataset row: run the component, then optionally run the eval.

    When the component has a runner, a TraceContext is set for the duration of the
    call so bench.wrap() interceptors can record LLM calls. After execution the
    captured calls are flushed and written to Supabase when a client is provided.
    """
    start = time.perf_counter()
    output: dict | None = None
    error: str | None = None
    demoted_error: str | None = None
    orchestration_steps: list[dict] | None = None
    llm_calls: list = []
    runner = getattr(component, "runner", None)

    try:
        if runner is not None:
            trace_id = str(uuid4())
            ctx = TraceContext(
                trace_id=trace_id,
                autorater_run_id=autorater_run_id,
                dataset_item_id=dataset_item_id,
            )
            token = set_trace_context(ctx)
            try:
                output = await _execute_component(component, row)
            finally:
                llm_calls = ctx.flush()
                reset_trace_context(token)

            if llm_calls and supabase_client is not None:
                await supabase_client.table("llm_calls").insert(
                    [asdict(call) for call in llm_calls]
                ).execute()
        elif component.component_type == ComponentType.ORCHESTRATION:
            orchestration_steps = []
            output = await _run_orchestration(
                component,  # type: ignore[arg-type]
                row,
                orchestration_steps,
            )
        else:
            output = await _execute_component(component, row)
    except Exception as exc:
        error = str(exc)
        if eval_component is not None:
            demoted_error = error
            output = _build_component_failure_output(error)
            error = None

    latency_ms = (time.perf_counter() - start) * 1000.0

    comp_trace = EvalTrace(
        name=component.name,
        component_type=component.component_type,
        input=row,
        output=output,
        error=error,
        latency_ms=latency_ms,
        steps=[],
        status="failed" if error else "completed",
        trigger_run_id=trigger_run_id,
        path_taken=_build_path_taken(
            component,
            row,
            output,
            demoted_error or error,
            orchestration_steps,
        ),
    )

    result = RowResult(row=row, component_trace=comp_trace)

    # Short-circuit eval execution for malformed / schema-mismatched outputs.
    if (
        eval_component is not None
        and output is not None
        and isinstance(output, dict)
        and isinstance(output.get(_COMPONENT_ERROR_KEY), str)
        and _is_output_schema_mismatch_error(output[_COMPONENT_ERROR_KEY])
    ):
        result.eval_trace = EvalTrace(
            name=eval_component.name,
            component_type=eval_component.component_type,
            input=build_eval_kwargs(row, output),
            output=_build_schema_mismatch_eval_output(output[_COMPONENT_ERROR_KEY]),
            error=None,
            latency_ms=0.0,
            steps=[],
            status="completed",
            trigger_run_id=trigger_run_id,
        )
        return result

    # Run eval if provided and component succeeded
    if eval_component is not None and output is not None:
        eval_kwargs = build_eval_kwargs(row, output)
        eval_start = time.perf_counter()
        eval_output: dict | None = None
        eval_error: str | None = None

        try:
            eval_runner = getattr(eval_component, "runner", None)
            if eval_runner is not None:
                trace_id = str(uuid4())
                ctx = TraceContext(
                    trace_id=trace_id,
                    autorater_run_id=autorater_run_id,
                    dataset_item_id=dataset_item_id,
                )
                token = set_trace_context(ctx)
                try:
                    eval_output = await _execute_component(eval_component, eval_kwargs)
                finally:
                    llm_calls = ctx.flush()
                    reset_trace_context(token)

                if llm_calls and supabase_client is not None:
                    await supabase_client.table("llm_calls").insert(
                        [asdict(call) for call in llm_calls]
                    ).execute()
            else:
                eval_output = await _execute_component(eval_component, eval_kwargs)
        except Exception as exc:
            eval_error = str(exc)

        eval_latency = (time.perf_counter() - eval_start) * 1000.0

        eval_trace = EvalTrace(
            name=eval_component.name,
            component_type=eval_component.component_type,
            input=eval_kwargs,
            output=eval_output,
            error=eval_error,
            latency_ms=eval_latency,
            steps=[],
            status="failed" if eval_error else "completed",
            trigger_run_id=trigger_run_id,
        )
        result.eval_trace = eval_trace

    return result
