"""Discover and validate class-based bench components from user Python files."""
from __future__ import annotations

import importlib.util
import inspect
import sys
from pathlib import Path

from zhanla.registry import registry
from zhanla.types import (
    ZhanlaComponent,
    ComponentType,
    Tool,
    CodeEval,
    Skill,
    Agent,
    LLMProcessor,
    LLMEval,
    Orchestration,
    OrchestrationStep,
    Conditional,
    Checklist,
    EvalTree,
    Branch,
    Edge,
)

# All component base classes we scan for
_COMPONENT_CLASSES = (
    Tool, CodeEval, Skill, Agent, LLMProcessor, LLMEval,
    Orchestration, Checklist, EvalTree,
)


def parse_target(spec: str) -> tuple[str, str | None]:
    """Parse a ``file.py:component_name`` spec into (filepath, name | None)."""
    if ":" in spec:
        filepath, name = spec.rsplit(":", 1)
        if not name:
            raise ValueError(f"Empty component name in target: {spec!r}")
        return filepath, name
    return spec, None


def _import_module(filepath: str) -> object:
    """Import a Python file and return the module object."""
    path = Path(filepath).resolve()
    if not path.exists():
        raise ValueError(f"File not found: {filepath}")

    module_name = f"_bench_user_{path.stem}"
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise ValueError(f"Cannot load file: {filepath}")

    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    module_dir = str(path.parent)
    inserted = False
    if module_dir not in sys.path:
        sys.path.insert(0, module_dir)
        inserted = True
    try:
        spec.loader.exec_module(module)  # type: ignore[union-attr]
    finally:
        if inserted:
            try:
                sys.path.remove(module_dir)
            except ValueError:
                pass
    return module


def _collect_components(module: object) -> list[ZhanlaComponent]:
    """Scan module attributes for bench component class instances."""
    components: list[ZhanlaComponent] = []
    seen: set[int] = set()
    for attr_name in dir(module):
        obj = getattr(module, attr_name, None)
        if obj is None:
            continue
        if isinstance(obj, ZhanlaComponent) and id(obj) not in seen:
            seen.add(id(obj))
            components.append(obj)
    return components


def discover_components(filepath: str) -> list[ZhanlaComponent]:
    """Load a Python file and return all bench component instances found."""
    registry.clear()
    module = _import_module(filepath)
    components = _collect_components(module)

    if not components:
        raise ValueError(f"No bench components found in {filepath}")

    # Register discovered components
    for comp in components:
        try:
            registry.register(comp)
        except ValueError:
            pass  # already registered

    return components


def discover_targeted_component(
    spec: str,
) -> tuple[ZhanlaComponent, list[ZhanlaComponent]]:
    """Discover a specific component from a ``file.py:name`` spec.

    Returns (targeted_component, all_components_in_file).
    """
    filepath, name = parse_target(spec)

    registry.clear()
    module = _import_module(filepath)
    all_components = _collect_components(module)

    if not all_components:
        raise ValueError(f"No bench components found in {filepath}")

    for comp in all_components:
        try:
            registry.register(comp)
        except ValueError:
            pass

    # Separate runnable and eval components
    runnable = [c for c in all_components if c.is_runnable]

    if name is not None:
        # Find by name across all runnable types
        matches = [c for c in runnable if c.name == name]
        if not matches:
            # Also check eval components
            eval_matches = [c for c in all_components if c.is_eval and c.name == name]
            if eval_matches:
                raise ValueError(
                    f"'{name}' is an eval component. Use --eval to reference it."
                )
            available = ", ".join(c.name for c in runnable)
            raise ValueError(
                f"Component '{name}' not found in {filepath}. Available: {available}"
            )
        if len(matches) > 1:
            types = ", ".join(f"{c.component_type.value}" for c in matches)
            raise ValueError(
                f"Ambiguous name '{name}' in {filepath}: matches types [{types}]. "
                f"Names must be unique across runnable types in the same file."
            )
        return matches[0], all_components

    # Auto-select when no name given and exactly one runnable component
    if len(runnable) == 1:
        return runnable[0], all_components

    if len(runnable) == 0:
        raise ValueError(f"No runnable components found in {filepath}")

    names = ", ".join(c.name for c in runnable)
    raise ValueError(
        f"Multiple components in {filepath}: {names}. "
        f"Specify which one with file.py:component_name"
    )


def discover_eval(
    spec: str,
    all_components: list[ZhanlaComponent] | None = None,
) -> ZhanlaComponent:
    """Resolve an eval component from a file:name spec or from already-loaded components.

    The eval can be a CodeEval, LLMEval, Checklist, or EvalTree.
    """
    filepath, name = parse_target(spec)

    module = _import_module(filepath)
    file_components = _collect_components(module)

    evals = [c for c in file_components if c.is_eval]

    if not evals:
        raise ValueError(f"No eval components found in {filepath}")

    if name is not None:
        matches = [c for c in evals if c.name == name]
        if not matches:
            available = ", ".join(c.name for c in evals)
            raise ValueError(
                f"Eval '{name}' not found in {filepath}. Available: {available}"
            )
        return matches[0]

    if len(evals) == 1:
        return evals[0]

    names = ", ".join(c.name for c in evals)
    raise ValueError(
        f"Multiple evals in {filepath}: {names}. "
        f"Specify which one with file.py:eval_name"
    )


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def validate_component(comp: ZhanlaComponent) -> list[str]:
    """Validate a single component's structure (Phase 1). Returns error strings."""
    errors: list[str] = []

    if not getattr(comp, "name", None):
        errors.append("Component is missing a name")
        return errors

    if not getattr(comp, "description", None):
        errors.append(f"'{comp.name}' is missing a description")

    ct = comp.component_type

    # fn required for Tool, CodeEval
    if ct in (ComponentType.TOOL, ComponentType.CODE_EVAL):
        fn = getattr(comp, "fn", None)
        if fn is None or not callable(fn):
            errors.append(f"'{comp.name}' must provide a callable `fn`")

    # instructions required for Skill, Agent, LLMProcessor, LLMEval
    if ct in (ComponentType.SKILL, ComponentType.AGENT, ComponentType.LLM_PROCESSOR, ComponentType.LLM_EVAL):
        if not getattr(comp, "instructions", None):
            errors.append(f"'{comp.name}' is missing instructions")

    # model required for Agent, LLMProcessor, LLMEval
    if ct in (ComponentType.AGENT, ComponentType.LLM_PROCESSOR, ComponentType.LLM_EVAL):
        if not getattr(comp, "model", None):
            errors.append(f"'{comp.name}' must specify a model")

    # output_schema required for Tool
    if ct == ComponentType.TOOL:
        if getattr(comp, "output_schema", None) is None:
            errors.append(f"'{comp.name}' must declare an output_schema")

    # Orchestration DAG validation
    if ct == ComponentType.ORCHESTRATION:
        errors.extend(_validate_orchestration(comp))

    # Checklist validation
    if ct == ComponentType.CHECKLIST:
        errors.extend(_validate_checklist(comp))

    # EvalTree validation
    if ct == ComponentType.EVAL_TREE:
        errors.extend(_validate_eval_tree(comp))

    return errors


def _validate_orchestration(orch: ZhanlaComponent) -> list[str]:
    """Validate orchestration DAG structure."""
    errors: list[str] = []
    steps = getattr(orch, "steps", [])
    step_names = {s.name for s in steps}

    for step in steps:
        comp = step.component
        # Validate next targets exist
        for target in step.next:
            if target not in step_names:
                errors.append(f"Step '{step.name}' references unknown step '{target}'")

        # Validate conditional targets
        if isinstance(comp, Conditional):
            if comp.if_true not in step_names:
                errors.append(f"Conditional references unknown step '{comp.if_true}'")
            if comp.if_false not in step_names:
                errors.append(f"Conditional references unknown step '{comp.if_false}'")

    # Cycle detection via DFS
    adj: dict[str, list[str]] = {}
    for step in steps:
        targets = list(step.next)
        if isinstance(step.component, Conditional):
            targets = [step.component.if_true, step.component.if_false]
        adj[step.name] = targets

    visited: set[str] = set()
    path: set[str] = set()

    def dfs(node: str) -> str | None:
        if node in path:
            return node
        if node in visited:
            return None
        visited.add(node)
        path.add(node)
        for nxt in adj.get(node, []):
            result = dfs(nxt)
            if result is not None:
                return result
        path.discard(node)
        return None

    for step in steps:
        cycle_node = dfs(step.name)
        if cycle_node is not None:
            errors.append(f"Orchestration '{orch.name}' has a cycle involving '{cycle_node}'")
            break

    return errors


def _validate_checklist(checklist: ZhanlaComponent) -> list[str]:
    errors: list[str] = []
    evals = getattr(checklist, "evals", [])
    weights = getattr(checklist, "weights", None)

    if weights is not None:
        if len(weights) != len(evals):
            errors.append("Number of weights must match number of evals")
        for w in weights:
            if not isinstance(w, (int, float)) or w <= 0:
                errors.append("Weights must be positive numbers")
                break

    return errors


def _validate_eval_tree(tree: ZhanlaComponent) -> list[str]:
    errors: list[str] = []
    root = getattr(tree, "root", None)
    if root is not None:
        errors.extend(_validate_branch(root))
    return errors


def _validate_branch(branch: object) -> list[str]:
    errors: list[str] = []
    from zhanla.types import Branch as BranchType

    if not isinstance(branch, BranchType):
        return errors

    threshold = getattr(branch, "threshold", 0.5)
    if not (0.0 <= threshold <= 1.0):
        errors.append("Branch threshold must be between 0.0 and 1.0")

    for edge in getattr(branch, "if_pass", []):
        if not isinstance(edge.weight, (int, float)) or edge.weight <= 0:
            errors.append("Weights must be positive numbers")
        if isinstance(edge.node, BranchType):
            errors.extend(_validate_branch(edge.node))

    for edge in getattr(branch, "if_fail", []):
        if not isinstance(edge.weight, (int, float)) or edge.weight <= 0:
            errors.append("Weights must be positive numbers")
        if isinstance(edge.node, BranchType):
            errors.extend(_validate_branch(edge.node))

    return errors


def validate_components(components: list[ZhanlaComponent]) -> list[str]:
    """Validate all components. Returns list of issue strings prefixed with ERROR: or WARNING:."""
    issues: list[str] = []
    for comp in components:
        for err in validate_component(comp):
            issues.append(f"ERROR: {err}")
    return issues


# ---------------------------------------------------------------------------
# Manifest-based discovery (returns ComponentManifest instead of live objects)
# ---------------------------------------------------------------------------

def discover_python_as_manifests(
    filepath: str,
    symbol_name: str | None = None,
) -> list:
    """Discover Python components from a file and return them as ComponentManifest objects.

    This is the manifest-first path used by the CLI when the target is a .py file.
    The live objects are still imported (for execution), but discovery returns manifests.
    """
    from zhanla_cli.manifest import to_manifest
    from pathlib import Path as _Path

    abs_path = str(_Path(filepath).resolve())
    components = discover_components(filepath)
    return [
        to_manifest(c, file_path=abs_path)
        for c in components
    ]
