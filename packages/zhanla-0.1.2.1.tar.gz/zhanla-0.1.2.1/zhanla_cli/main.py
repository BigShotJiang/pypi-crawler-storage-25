"""Main CLI entry point using Typer."""
import asyncio
import uuid
from datetime import datetime
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console

app = typer.Typer(name="zhanla", help="Zhanla CLI for running AI component evaluations")
list_app = typer.Typer(
    help="List datasets or autoraters: use `zhanla list datasets` or `zhanla list autoraters`.",
    invoke_without_command=True,
)
app.add_typer(
    list_app,
    name="list",
    help="List datasets or autoraters: use `zhanla list datasets` or `zhanla list autoraters`.",
)
console = Console()

# Load .env.local so API keys are available to both Python and TypeScript components.
from zhanla_cli.runners import load_dotenv_local as _load_dotenv_local
_dotenv_path = _load_dotenv_local()
if _dotenv_path is not None:
    console.print(f"[dim]Loaded env from {_dotenv_path}[/dim]")

BASE_URL_ENV = "BENCH_BASE_URL"
DEFAULT_BASE_URL = "https://benchmark-black.vercel.app"


def _get_base_url() -> str:
    import os
    return os.environ.get(BASE_URL_ENV, DEFAULT_BASE_URL).rstrip("/")


def _parse_target(spec: str) -> tuple[str, str | None]:
    if ":" in spec:
        filepath, name = spec.rsplit(":", 1)
        if not name:
            raise ValueError(f"Empty component name in target: {spec!r}")
        return filepath, name
    return spec, None


def _is_missing_python_sdk(exc: ModuleNotFoundError) -> bool:
    missing = exc.name or ""
    return missing == "zhanla" or missing.startswith("zhanla.")


def _exit_missing_python_sdk() -> None:
    typer.echo(
        "Python local execution requires zhanla-sdk-py. "
        "Install it with `pip install zhanla-sdk-py`.",
        err=True,
    )
    raise typer.Exit(1)


# ---------------------------------------------------------------------------
# zhanla login
# ---------------------------------------------------------------------------

@app.command()
def login() -> None:
    """Authenticate with your SDK API key."""
    from zhanla_cli.auth import exchange_key_for_token, save_credentials

    composite_key = typer.prompt("Enter your SDK API key", hide_input=True)

    if "." not in composite_key:
        typer.echo("Invalid key format. Expected: bm_kid_XXXX.bm_sec_XXXX", err=True)
        raise typer.Exit(1)

    key_id, secret = composite_key.split(".", 1)
    base_url = _get_base_url()

    try:
        token_data = exchange_key_for_token(key_id, secret, base_url)
    except Exception as e:
        typer.echo(f"Login failed: {e}", err=True)
        raise typer.Exit(1)

    save_credentials(
        {
            "key_id": key_id,
            "secret": secret,
            "supabase_url": token_data["supabase_url"],
            "supabase_anon_key": token_data["supabase_anon_key"],
            "org_id": token_data["org_id"],
        }
    )
    typer.echo("Logged in successfully.")


# ---------------------------------------------------------------------------
# zhanla logout
# ---------------------------------------------------------------------------

@app.command()
def logout() -> None:
    """Remove saved credentials."""
    from zhanla_cli.auth import delete_credentials
    delete_credentials()
    typer.echo("Logged out.")


# ---------------------------------------------------------------------------
# zhanla run
# ---------------------------------------------------------------------------

@app.command()
def run(
    target: Optional[str] = typer.Argument(
        None,
        help="component.py:name — file path and component name",
    ),
    eval_target: Optional[str] = typer.Option(
        None, "--eval", "-e",
        help="eval.py:name — file path and eval name",
    ),
    dataset: Optional[str] = typer.Option(
        None, "--dataset", "-d",
        help="Path to dataset file (.json or .csv)",
    ),
    web_eval: Optional[str] = typer.Option(
        None, "--web-eval",
        help="Autorater ID for a managed web evaluation run",
    ),
    web_dataset: Optional[str] = typer.Option(
        None, "--web-dataset",
        help="Dataset ID to fetch from the web app before local execution",
    ),
    web_config: Optional[str] = typer.Option(
        None, "--web-config",
        help="Prompt ID for a fully web-backed run",
    ),
    model_endpoint: Optional[str] = typer.Option(
        None, "--model-endpoint",
        help="Model endpoint override for fully web-backed runs",
    ),
    dry_run: bool = typer.Option(False, "--dry-run", help="Validate and execute locally, skip sync/upload"),
    fail_on_row_error: bool = typer.Option(
        False,
        "--fail-on-row-error",
        help="Exit non-zero when any dataset row has component or eval execution errors.",
    ),
) -> None:
    """Run a component against a dataset and score with an eval.

    All three arguments are required:
      zhanla run <component> --dataset <file> --eval <evaluator>
    """
    from zhanla_cli.data_utils import load_dataset, validate_output_schema
    from zhanla_cli.evaluations import poll_evaluation, start_evaluation
    from zhanla_cli.manifest import validate_manifest
    from zhanla_cli.runners import (
        NodeRunner,
        RunnerError,
        detect_language,
        validate_same_language,
        discover_ts_components,
        discover_python_components,
    )
    from zhanla_cli.ui import (
        print_components_table,
        print_remote_evaluation_summary,
        print_score_summary,
        create_progress,
    )
    from zhanla_cli.web import (
        derive_expected_output,
        derive_model_input,
        derive_model_response,
        fetch_web_dataset,
        fetch_web_prompt,
        start_evaluate_only,
    )

    base_url = _get_base_url()
    trigger_run_id = str(uuid.uuid4())

    if bool(target) == bool(web_config):
        typer.echo(
            "Provide exactly one component source: local target or --web-config.",
            err=True,
        )
        raise typer.Exit(1)

    if bool(dataset) == bool(web_dataset):
        typer.echo(
            "Provide exactly one dataset source: --dataset or --web-dataset.",
            err=True,
        )
        raise typer.Exit(1)

    if bool(eval_target) == bool(web_eval):
        typer.echo(
            "Provide exactly one evaluation source: --eval or --web-eval.",
            err=True,
        )
        raise typer.Exit(1)

    if web_config and (target or eval_target or dataset):
        typer.echo(
            "--web-config is only supported for the fully web-backed flow "
            "(--web-config + --web-dataset + --web-eval).",
            err=True,
        )
        raise typer.Exit(1)

    if model_endpoint and not web_config:
        typer.echo("--model-endpoint is only supported with --web-config.", err=True)
        raise typer.Exit(1)

    if web_config and dry_run:
        typer.echo("Dry run is not supported for fully web-backed runs.", err=True)
        raise typer.Exit(1)

    if web_config and not (web_dataset and web_eval):
        typer.echo(
            "--web-config requires --web-dataset and --web-eval.",
            err=True,
        )
        raise typer.Exit(1)

    if dry_run and web_eval:
        typer.echo("Dry run is not supported with --web-eval.", err=True)
        raise typer.Exit(1)

    token_data: dict | None = None

    component = None
    eval_component = None
    component_manifest = None
    eval_manifest = None
    ts_manifests: dict[str, object] = {}
    component_lang: str | None = None
    eval_lang: str | None = None
    closure_manifests: list | None = None  # full transitive closure for upload

    # --- Discover component ---
    if target:
        target_filepath, target_name = _parse_target(target)

        try:
            component_lang = detect_language(target_filepath)
        except ValueError as e:
            typer.echo(str(e), err=True)
            raise typer.Exit(1)

        if component_lang == "typescript":
            # TypeScript path: discover via npx zhanla-sdk-ts
            ts_spec = f"{target_filepath}:{target_name}" if target_name else target_filepath
            try:
                discovered_ts_manifests = discover_ts_components(ts_spec)
            except RunnerError as e:
                typer.echo(str(e), err=True)
                raise typer.Exit(1)
            except ValueError as e:
                typer.echo(str(e), err=True)
                raise typer.Exit(1)

            # The closure is leaf-first; root (target) is the last element.
            closure_manifests = discovered_ts_manifests
            for manifest in closure_manifests:
                ts_manifests[manifest.name] = manifest

            runnable = [m for m in closure_manifests if m.is_runnable]

            if target_name is not None:
                matches = [m for m in runnable if m.name == target_name]
                if not matches:
                    eval_matches = [m for m in closure_manifests if m.is_eval and m.name == target_name]
                    if eval_matches:
                        typer.echo(
                            f"'{target_name}' is an eval component. Use --eval to reference it.",
                            err=True,
                        )
                    else:
                        available = ", ".join(m.name for m in runnable)
                        typer.echo(
                            f"Component '{target_name}' not found in {target_filepath}. "
                            f"Available: {available}",
                            err=True,
                        )
                    raise typer.Exit(1)
                component_manifest = matches[0]
            elif len(runnable) == 1:
                component_manifest = runnable[0]
            elif len(runnable) == 0:
                typer.echo(f"No runnable components found in {target_filepath}", err=True)
                raise typer.Exit(1)
            else:
                names = ", ".join(m.name for m in runnable)
                typer.echo(
                    f"Multiple components in {target_filepath}: {names}. "
                    f"Specify which one with file.ts:component_name",
                    err=True,
                )
                raise typer.Exit(1)

            # Validate manifest
            from zhanla_cli.manifest import validate_manifest
            manifest_errors = validate_manifest(component_manifest)
            if manifest_errors:
                for err in manifest_errors:
                    typer.echo(f"ERROR: {err}", err=True)
                raise typer.Exit(1)

            typer.echo(f"Component: {component_manifest.name} (TypeScript)")

        else:
            # Python path: discover live object for execution, closure manifests for upload
            try:
                from zhanla_cli.discovery import (
                    discover_targeted_component,
                    validate_component,
                )
            except ModuleNotFoundError as exc:
                if _is_missing_python_sdk(exc):
                    _exit_missing_python_sdk()
                raise
            try:
                component, _ = discover_targeted_component(target)
            except ValueError as e:
                typer.echo(str(e), err=True)
                raise typer.Exit(1)

            print_components_table([component])

            comp_errors = validate_component(component)
            if comp_errors:
                for err in comp_errors:
                    typer.echo(f"ERROR: {err}", err=True)
                raise typer.Exit(1)

            try:
                closure_manifests = discover_python_components(target)
            except ValueError as e:
                typer.echo(f"Closure discovery failed: {e}", err=True)
                raise typer.Exit(1)

    # --- Discover eval ---
    if eval_target:
        eval_filepath, _ = _parse_target(eval_target)

        try:
            eval_lang = detect_language(eval_filepath)
        except ValueError as e:
            typer.echo(str(e), err=True)
            raise typer.Exit(1)

        # Same-language validation
        try:
            validate_same_language(component_lang or "python", eval_lang)
        except ValueError as e:
            typer.echo(str(e), err=True)
            raise typer.Exit(1)

        if eval_lang == "typescript":
            try:
                ts_eval_manifests = discover_ts_components(eval_filepath)
            except RunnerError as e:
                typer.echo(str(e), err=True)
                raise typer.Exit(1)
            except ValueError as e:
                typer.echo(str(e), err=True)
                raise typer.Exit(1)

            for manifest in ts_eval_manifests:
                ts_manifests[manifest.name] = manifest

            eval_manifests_list = [m for m in ts_eval_manifests if m.is_eval]
            _, eval_name = _parse_target(eval_target)

            if eval_name is not None:
                matches = [m for m in eval_manifests_list if m.name == eval_name]
                if not matches:
                    available = ", ".join(m.name for m in eval_manifests_list)
                    typer.echo(
                        f"Eval '{eval_name}' not found in {eval_filepath}. Available: {available}",
                        err=True,
                    )
                    raise typer.Exit(1)
                eval_manifest = matches[0]
            elif len(eval_manifests_list) == 1:
                eval_manifest = eval_manifests_list[0]
            elif len(eval_manifests_list) == 0:
                typer.echo(f"No eval components found in {eval_filepath}", err=True)
                raise typer.Exit(1)
            else:
                names = ", ".join(m.name for m in eval_manifests_list)
                typer.echo(
                    f"Multiple evals in {eval_filepath}: {names}. "
                    f"Specify which one with file.ts:eval_name",
                    err=True,
                )
                raise typer.Exit(1)

            typer.echo(f"Eval: {eval_manifest.name} (TypeScript)")
        else:
            try:
                from zhanla_cli.discovery import discover_eval, validate_component
            except ModuleNotFoundError as exc:
                if _is_missing_python_sdk(exc):
                    _exit_missing_python_sdk()
                raise
            try:
                eval_component = discover_eval(eval_target)
            except ValueError as e:
                typer.echo(str(e), err=True)
                raise typer.Exit(1)

            eval_errors = validate_component(eval_component)
            if eval_errors:
                for err in eval_errors:
                    typer.echo(f"ERROR: {err}", err=True)
                raise typer.Exit(1)

            typer.echo(f"Eval: {eval_component.name}")
    elif web_eval:
        typer.echo(f"Web autorater: {web_eval}")

    # --- Auth check ---
    requires_auth = (not dry_run) or bool(web_dataset) or bool(web_eval) or bool(web_config)
    if requires_auth:
        token_data = _require_token(base_url)

    if web_config:
        assert token_data is not None
        prompt = fetch_web_prompt(
            supabase_url=token_data["supabase_url"],
            supabase_anon_key=token_data["supabase_anon_key"],
            access_token=token_data["access_token"],
            prompt_id=web_config,
        )
        typer.echo(f"Web prompt: {prompt.get('slug') or web_config}")
        start_result = start_evaluation(
            base_url=base_url,
            access_token=token_data["access_token"],
            autorater_id=web_eval,
            dataset_id=web_dataset,
            prompt_id=web_config,
            model_endpoint=model_endpoint,
            org_id=token_data["org_id"],
        )
        result_url = f"{base_url}/autoraters/{web_eval}/runs/{start_result['runId']}"
        final_status = poll_evaluation(
            base_url=base_url,
            access_token=token_data["access_token"],
            run_id=start_result["runId"],
            org_id=token_data["org_id"],
        )
        print_remote_evaluation_summary(
            component_name=prompt.get("slug") or web_config,
            run_status=final_status,
            result_url=result_url,
            autorater_id=web_eval,
            autorater_run_id=start_result["runId"],
        )
        if final_status.get("status") == "failed":
            raise typer.Exit(1)
        return

    # For TS components, we have a manifest but no live object.
    # For Python components, we have a live object.
    is_ts_run = component_lang == "typescript" and component_manifest is not None

    if not is_ts_run:
        assert component is not None

    # --- Load dataset ---
    try:
        if dataset:
            dataset_rows, dataset_config = load_dataset(dataset)
            dataset_name = Path(dataset).stem
            dataset_id = None
            dataset_item_ids = None
        else:
            assert token_data is not None
            web_dataset_result = fetch_web_dataset(
                supabase_url=token_data["supabase_url"],
                supabase_anon_key=token_data["supabase_anon_key"],
                access_token=token_data["access_token"],
                dataset_id=web_dataset or "",
            )
            dataset_rows = web_dataset_result.rows
            dataset_config = None
            dataset_name = web_dataset_result.dataset_name
            dataset_id = web_dataset_result.dataset_id
            dataset_item_ids = web_dataset_result.item_ids
    except Exception as e:
        typer.echo(f"Failed to load dataset: {e}", err=True)
        raise typer.Exit(1)

    if not dataset_rows:
        typer.echo("Dataset is empty.", err=True)
        raise typer.Exit(1)

    # --- Execute with progress bar ---
    results: list = []
    output_schema = component_manifest.output_schema if is_ts_run else getattr(component, "output_schema", None)

    if is_ts_run:
        # TypeScript path: start NodeRunner subprocess, stream rows
        assert component_manifest is not None
        node_runner = NodeRunner(
            manifest=component_manifest,
            eval_manifest=eval_manifest,
            file_path=component_manifest.file_path or "",
        )
        try:
            node_runner.start()
        except RunnerError as e:
            typer.echo(str(e), err=True)
            raise typer.Exit(1)

        comp_name = component_manifest.name
        try:
            progress = create_progress()
            with progress:
                task = progress.add_task(
                    f"Running {comp_name}",
                    total=len(dataset_rows),
                    status="starting",
                )

                async def run_ts_with_progress():
                    out = []
                    for i, row in enumerate(dataset_rows):
                        progress.update(task, status=f"row {i + 1}/{len(dataset_rows)}")
                        row_result = await node_runner.run_row(row, trigger_run_id)
                        out.append(row_result)

                        if (
                            i == 0
                            and output_schema
                            and row_result.get("output")
                            and "_component_error" not in row_result["output"]
                        ):
                            schema_error = validate_output_schema(
                                row_result["output"], output_schema, component_manifest.name
                            )
                            if schema_error:
                                progress.update(task, status="schema error")
                                raise ValueError(schema_error)

                        progress.advance(task)
                    progress.update(task, status="done")
                    return out

                try:
                    results = asyncio.run(run_ts_with_progress())
                except ValueError as e:
                    typer.echo(str(e), err=True)
                    raise typer.Exit(1)
        finally:
            node_runner.stop()

    # Python path
    else:
        try:
            from zhanla_cli.executor import execute_row
        except ModuleNotFoundError as exc:
            if _is_missing_python_sdk(exc):
                _exit_missing_python_sdk()
            raise
        progress = create_progress()
        with progress:
            task = progress.add_task(
                f"Running {component.name}",
                total=len(dataset_rows),
                status="starting",
            )

            async def run_with_progress():
                out = []
                for i, row in enumerate(dataset_rows):
                    progress.update(task, status=f"row {i + 1}/{len(dataset_rows)}")
                    result = await execute_row(component, eval_component, row, trigger_run_id)
                    out.append(result)

                    # First-row fail-fast output validation
                    if (
                        i == 0
                        and output_schema
                        and result.component_trace.output
                        and "_component_error" not in result.component_trace.output
                    ):
                        schema_error = validate_output_schema(
                            result.component_trace.output, output_schema, component.name
                        )
                        if schema_error:
                            progress.update(task, status="schema error")
                            raise ValueError(schema_error)

                    progress.advance(task)
                progress.update(task, status="done")
                return out

            try:
                results = asyncio.run(run_with_progress())
            except ValueError as e:
                typer.echo(str(e), err=True)
                raise typer.Exit(1)

    if is_ts_run:
        from zhanla_cli.ts_adapter import build_manifest_component, ts_result_to_traces

        component = build_manifest_component(component_manifest, list(ts_manifests.values()))
        eval_component = (
            build_manifest_component(eval_manifest, list(ts_manifests.values()))
            if eval_manifest is not None
            else None
        )
        converted = [
            ts_result_to_traces(
                row=row,
                row_result=row_result,
                component=component,
                eval_component=eval_component,
                trigger_run_id=trigger_run_id,
            )
            for row, row_result in zip(dataset_rows, results)
        ]
        component_traces = [component_trace for component_trace, _ in converted]
        eval_traces = [eval_trace for _, eval_trace in converted]
    else:
        component_traces = [r.component_trace for r in results]
        eval_traces = [r.eval_trace for r in results]

    # --- Upload ---
    upload_failed = False
    result_url: str | None = None
    autorater_id: str | None = None
    autorater_run_id: str | None = None
    upload_started_at: str | None = None
    upload_completed_at: str | None = None

    if not dry_run:
        upload_started_at = datetime.now().astimezone().isoformat(timespec="seconds")
        try:
            from zhanla_cli.writer import write_run_results
            assert token_data is not None

            upload_result = write_run_results(
                component=component,
                eval_component=eval_component or component,
                component_traces=component_traces,
                eval_traces=eval_traces,
                supabase_url=token_data["supabase_url"],
                supabase_anon_key=token_data["supabase_anon_key"],
                access_token=token_data["access_token"],
                org_id=token_data["org_id"],
                closure=closure_manifests,
                dataset_id=dataset_id,
                dataset_item_ids=dataset_item_ids,
                dataset_name=dataset_name,
                dataset_rows=dataset_rows if dataset_id is None else None,
            )
            if web_eval:
                if not upload_result.dataset_id or not upload_result.dataset_item_ids:
                    raise RuntimeError("Dataset upload did not return dataset item IDs")

                items = []
                for item_id, row, component_trace in zip(upload_result.dataset_item_ids, dataset_rows, component_traces):
                    items.append(
                        {
                            "itemId": item_id,
                            "modelInput": derive_model_input(row),
                            "modelResponse": derive_model_response(
                                component_trace.output
                            ),
                            "expectedOutput": derive_expected_output(row),
                            "pathTaken": component_trace.path_taken,
                        }
                    )

                start_result = start_evaluate_only(
                    base_url=base_url,
                    access_token=token_data["access_token"],
                    autorater_id=web_eval,
                    items=items,
                    dataset_id=upload_result.dataset_id,
                    org_id=token_data["org_id"],
                )
                autorater_id = web_eval
                autorater_run_id = start_result["runId"]
                result_url = (
                    f"{base_url}/autoraters/{web_eval}/runs/{start_result['runId']}"
                )
                final_status = poll_evaluation(
                    base_url=base_url,
                    access_token=token_data["access_token"],
                    run_id=start_result["runId"],
                    org_id=token_data["org_id"],
                )
                upload_completed_at = datetime.now().astimezone().isoformat(timespec="seconds")
                print_remote_evaluation_summary(
                    component_name=component.name,
                    run_status=final_status,
                    result_url=result_url,
                    autorater_id=autorater_id,
                    autorater_run_id=autorater_run_id,
                    upload_started_at=upload_started_at,
                    upload_completed_at=upload_completed_at,
                )
                if final_status.get("status") == "failed":
                    raise RuntimeError(final_status.get("error") or "Remote evaluation failed")
            elif upload_result is not None:
                autorater_id = upload_result.autorater_id
                autorater_run_id = upload_result.autorater_run_id
                if upload_result.autorater_id and upload_result.autorater_run_id:
                    result_url = (
                        f"{base_url}/autoraters/{upload_result.autorater_id}"
                        f"/runs/{upload_result.autorater_run_id}"
                    )
            if upload_completed_at is None:
                upload_completed_at = datetime.now().astimezone().isoformat(timespec="seconds")
        except Exception as e:
            upload_completed_at = datetime.now().astimezone().isoformat(timespec="seconds")
            typer.echo(f"Sync/upload failed: {e}", err=True)
            upload_failed = True

    # --- Print summary ---
    if not web_eval:
        print_score_summary(
            component_traces=component_traces,
            eval_traces=eval_traces,
            component_name=component.name,
            dry_run=dry_run,
            uploaded=not upload_failed,
            result_url=result_url,
            autorater_id=autorater_id,
            autorater_run_id=autorater_run_id,
            upload_started_at=upload_started_at,
            upload_completed_at=upload_completed_at,
        )

    component_failed_count = sum(1 for trace in component_traces if trace.status == "failed")
    eval_failed_count = sum(1 for trace in eval_traces if trace is not None and trace.status == "failed")

    if fail_on_row_error and (component_failed_count > 0 or eval_failed_count > 0):
        typer.echo(
            (
                "Run failed due to row execution errors: "
                f"{component_failed_count} component row(s), {eval_failed_count} eval row(s)."
            ),
            err=True,
        )
        raise typer.Exit(1)

    if upload_failed:
        raise typer.Exit(1)


# ---------------------------------------------------------------------------
# zhanla list datasets / zhanla list autoraters
# ---------------------------------------------------------------------------

OWNER_TYPES = ["agent", "skill", "tool", "orchestration"]
OWNER_TABLES = {
    "agent": "agents",
    "skill": "skills",
    "tool": "tools",
    "orchestration": "orchestrations",
}


def _require_token(base_url: str) -> dict:
    from zhanla_cli.auth import get_fresh_token

    try:
        return get_fresh_token(base_url)
    except RuntimeError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1) from exc


def _owner_belongs_to_org(client, *, owner_id: str, owner_type: str, org_id: str) -> bool:
    table_name = OWNER_TABLES.get(owner_type)
    if table_name is None:
        return False
    try:
        result = (
            client.table(table_name)
            .select("id")
            .eq("id", owner_id)
            .eq("organization_id", org_id)
            .limit(1)
            .execute()
        )
    except Exception:
        return False
    rows = getattr(result, "data", None) or []
    return bool(rows)


def _list_datasets_via_supabase(
    *,
    client,
    org_id: str,
    owner_type: str | None,
    owner_id: str | None,
    name: str | None,
) -> list[dict]:
    if owner_type or owner_id:
        link_query = client.table("component_datasets").select("dataset_id,owner_id,owner_type")
        if owner_type:
            link_query = link_query.eq("owner_type", owner_type)
        if owner_id:
            link_query = link_query.eq("owner_id", owner_id)
        link_rows = getattr(link_query.execute(), "data", None) or []
        dataset_ids = sorted({
            row.get("dataset_id")
            for row in link_rows
            if isinstance(row.get("dataset_id"), str)
            and isinstance(row.get("owner_id"), str)
            and isinstance(row.get("owner_type"), str)
            and _owner_belongs_to_org(
                client,
                owner_id=row["owner_id"],
                owner_type=row["owner_type"],
                org_id=org_id,
            )
        })
        if not dataset_ids:
            return []
        query = (
            client.table("datasets")
            .select("id,name,description,input_columns,created_at,deleted_at")
            .eq("organization_id", org_id)
            .in_("id", dataset_ids)
            .order("created_at", desc=True)
        )
    else:
        query = (
            client.table("datasets")
            .select("id,name,description,input_columns,created_at,deleted_at")
            .eq("organization_id", org_id)
            .order("created_at", desc=True)
        )

    if name:
        query = query.ilike("name", f"%{name}%")

    rows = getattr(query.execute(), "data", None) or []
    return [row for row in rows if row.get("deleted_at") is None]


def _list_autoraters_via_supabase(
    *,
    client,
    org_id: str,
    owner_type: str | None,
    owner_id: str | None,
    name: str | None,
) -> list[dict]:
    query = (
        client.table("autoraters")
        .select("id,name,description,mode,owner_id,owner_type,created_at")
        .eq("organization_id", org_id)
        .order("created_at", desc=True)
    )
    if owner_type:
        query = query.eq("owner_type", owner_type)
    if owner_id:
        query = query.eq("owner_id", owner_id)
    if name:
        query = query.ilike("name", f"%{name}%")

    rows = getattr(query.execute(), "data", None) or []
    return list(rows)


@list_app.callback()
def list_resources(ctx: typer.Context) -> None:
    """List available web resources."""
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit()


@list_app.command("datasets")
def list_datasets(
    owner_type: Optional[str] = typer.Option(
        None, "--component-type", "-t",
        help=f"Filter by component type: {', '.join(OWNER_TYPES)}",
    ),
    owner_id: Optional[str] = typer.Option(None, "--component-id", "-c", help="Filter by component ID"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Filter by name (case-insensitive substring)"),
) -> None:
    """List datasets available in the web app."""
    from rich.table import Table
    from zhanla_cli.web import (
        SdkListRouteUnavailable,
        list_web_datasets as _list_web_datasets,
    )
    from zhanla_cli.writer import get_supabase_client as _get_client

    if owner_type and owner_type not in OWNER_TYPES:
        typer.echo(f"Invalid --owner-type '{owner_type}'. Choose from: {', '.join(OWNER_TYPES)}", err=True)
        raise typer.Exit(1)

    base_url = _get_base_url()
    token_data = _require_token(base_url)

    client = _get_client(
        token_data["supabase_url"],
        token_data["supabase_anon_key"],
        token_data["access_token"],
    )
    try:
        rows = _list_web_datasets(
            base_url=base_url,
            access_token=token_data["access_token"],
            org_id=token_data.get("org_id"),
            owner_type=owner_type,
            owner_id=owner_id,
            name=name,
        )
    except SdkListRouteUnavailable:
        rows = _list_datasets_via_supabase(
            client=client,
            org_id=token_data["org_id"],
            owner_type=owner_type,
            owner_id=owner_id,
            name=name,
        )

    if not rows:
        typer.echo("No datasets found.")
        return

    table = Table(title="Datasets", show_lines=False)
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Name", style="bold")
    table.add_column("Created", style="dim")

    for row in rows:
        created = (row.get("created_at") or "")[:10]
        table.add_row(row["id"], row.get("name") or "", created)

    console.print(table)
    console.print("[dim]Use --web-dataset <ID> in `zhanla run`[/dim]")


@list_app.command("autoraters")
def list_autoraters(
    owner_type: Optional[str] = typer.Option(
        None, "--component-type", "-t",
        help=f"Filter by component type: {', '.join(OWNER_TYPES)}",
    ),
    owner_id: Optional[str] = typer.Option(None, "--component-id", "-c", help="Filter by component ID"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Filter by name (case-insensitive substring)"),
) -> None:
    """List autoraters available in the web app."""
    from rich.table import Table
    from zhanla_cli.web import (
        SdkListRouteUnavailable,
        list_web_autoraters as _list_web_autoraters,
    )
    from zhanla_cli.writer import get_supabase_client as _get_client

    if owner_type and owner_type not in OWNER_TYPES:
        typer.echo(f"Invalid --owner-type '{owner_type}'. Choose from: {', '.join(OWNER_TYPES)}", err=True)
        raise typer.Exit(1)

    base_url = _get_base_url()
    token_data = _require_token(base_url)

    client = _get_client(
        token_data["supabase_url"],
        token_data["supabase_anon_key"],
        token_data["access_token"],
    )
    try:
        rows = _list_web_autoraters(
            base_url=base_url,
            access_token=token_data["access_token"],
            org_id=token_data.get("org_id"),
            owner_type=owner_type,
            owner_id=owner_id,
            name=name,
        )
    except SdkListRouteUnavailable:
        rows = _list_autoraters_via_supabase(
            client=client,
            org_id=token_data["org_id"],
            owner_type=owner_type,
            owner_id=owner_id,
            name=name,
        )

    if not rows:
        typer.echo("No autoraters found.")
        return

    table = Table(title="Autoraters", show_lines=False)
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Name", style="bold")
    table.add_column("Type", style="magenta")
    table.add_column("Owner ID", style="dim")
    table.add_column("Created", style="dim")

    for row in rows:
        created = (row.get("created_at") or "")[:10]
        table.add_row(
            row["id"],
            row.get("name") or "",
            row.get("owner_type") or "",
            row.get("owner_id") or "",
            created,
        )

    console.print(table)
    console.print("[dim]Use --web-eval <ID> in `zhanla run`[/dim]")


if __name__ == "__main__":
    app()
