"""Build a ReactFlow graph dict from SDK-authored orchestration steps."""
from __future__ import annotations

from typing import Any


def _if_else_case_id(node_id: str, branch: str) -> str:
    return f"{node_id}__{branch}"


def build_graph_from_steps(steps: list[dict]) -> dict:
    """Convert typed orchestration steps into a ReactFlow graph dict.

    Sequential steps become component_ref nodes.
    Conditional steps become if_else nodes.
    Edges are built from each step's next list and conditional branches.
    """
    nodes: list[dict] = []
    edges: list[dict] = []

    for step in steps:
        node_id = step["name"]

        if step.get("is_conditional"):
            true_handle = _if_else_case_id(node_id, "true")
            false_handle = _if_else_case_id(node_id, "false")
            nodes.append({
                "id": node_id,
                "type": "agentBuilder",
                "data": {
                    "nodeType": "if_else",
                    "label": node_id,
                    "cases": [
                        {
                            "id": true_handle,
                            "name": "True",
                            "condition": "condition() returned truthy",
                        },
                        {
                            "id": false_handle,
                            "name": "False",
                            "condition": "condition() returned falsy",
                        },
                    ],
                },
            })
            if step.get("if_true"):
                edges.append({
                    "id": f"{node_id}-true",
                    "source": node_id,
                    "target": step["if_true"],
                    "sourceHandle": true_handle,
                })
            if step.get("if_false"):
                edges.append({
                    "id": f"{node_id}-false",
                    "source": node_id,
                    "target": step["if_false"],
                    "sourceHandle": false_handle,
                })
        else:
            ref = _extract_component_ref(step)
            if ref is None:
                continue
            nodes.append({
                "id": node_id,
                "type": "agentBuilder",
                "data": {
                    "nodeType": "component_ref",
                    "label": node_id,
                    "componentType": ref.get("component_type", ""),
                    "componentKey": ref.get("key", ""),
                    "componentName": ref.get("name", ""),
                    "language": ref.get("language", ""),
                    "executionMode": ref.get("execution_mode", ""),
                },
            })
            for next_step in step.get("next") or []:
                edges.append({
                    "id": f"{node_id}-{next_step}",
                    "source": node_id,
                    "target": next_step,
                })

    return {"nodes": nodes, "edges": edges}


def _extract_component_ref(step: dict) -> dict[str, Any] | None:
    """Extract the component_ref dict from a step, handling both dict and object forms."""
    ref = step.get("component_ref")
    if ref is None:
        return None
    if isinstance(ref, dict):
        return ref
    # ComponentRef dataclass
    return {
        "key": getattr(ref, "key", ""),
        "component_type": getattr(ref, "component_type", ""),
        "name": getattr(ref, "name", ""),
        "language": getattr(ref, "language", ""),
        "execution_mode": getattr(ref, "execution_mode", ""),
    }
