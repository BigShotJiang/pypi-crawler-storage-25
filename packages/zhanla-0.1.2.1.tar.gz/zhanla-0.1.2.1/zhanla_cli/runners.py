"""Runner protocol and implementations for Python and TypeScript components.

PythonRunner: wraps the existing Python executor for Python-authored components.
NodeRunner: manages a long-lived Node subprocess for TypeScript-authored components.
discover_ts_components: shells out to npx zhanla-sdk-ts discover to get manifests.
"""
from __future__ import annotations

import asyncio
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

from zhanla_cli.manifest import ComponentManifest


# ---------------------------------------------------------------------------
# .env.local loader
# ---------------------------------------------------------------------------

def load_dotenv_local(start_dir: str | Path | None = None) -> Path | None:
    """Parse .env.local and inject vars into os.environ (skip already-set keys).

    Walks up from start_dir (defaults to cwd) until it finds .env.local or
    reaches the filesystem root. Returns the path if found, else None.
    """
    directory = Path(start_dir or Path.cwd()).resolve()
    env_path: Path | None = None
    for parent in [directory, *directory.parents]:
        candidate = parent / ".env.local"
        if candidate.is_file():
            env_path = candidate
            break

    if env_path is None:
        return None

    with env_path.open() as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key and key not in os.environ:
                os.environ[key] = value

    return env_path


class RunnerError(RuntimeError):
    """Raised when a runner encounters a fatal setup or execution error."""


def _ensure_ts_sdk_available() -> None:
    """Verify that the TS SDK CLI is already installed without triggering installs."""
    try:
        result = subprocess.run(
            ["npx", "--no-install", "zhanla-sdk-ts", "--help"],
            capture_output=True,
            text=True,
            timeout=15,
        )
    except FileNotFoundError:
        raise RunnerError(
            "TypeScript support requires Node.js and npx. "
            "Install Node.js and add @zhanla/sdk-ts in the current project."
        )

    if result.returncode == 0:
        return

    stderr = (result.stderr or "").strip()
    stdout = (result.stdout or "").strip()
    details = stderr or stdout
    raise RunnerError(
        "TypeScript support requires @zhanla/sdk-ts to already be installed "
        "in the current project. Install it with `npm install @zhanla/sdk-ts`."
        + (f" Error: {details}" if details else "")
    )


# ---------------------------------------------------------------------------
# Language detection
# ---------------------------------------------------------------------------

def detect_language(filepath: str) -> str:
    """Infer component language from file extension. Returns 'python' or 'typescript'."""
    suffix = Path(filepath).suffix.lower()
    if suffix == ".py":
        return "python"
    if suffix == ".ts":
        return "typescript"
    raise ValueError(
        f"Unsupported file extension: {suffix!r} in {filepath!r}. "
        f"Use .py for Python components or .ts for TypeScript components."
    )


def validate_same_language(component_lang: str, eval_lang: str | None) -> None:
    """Raise ValueError if component and eval languages don't match."""
    if eval_lang is None:
        return
    if component_lang != eval_lang:
        raise ValueError(
            f"Component and eval must be implemented in the same language. "
            f"Component is {component_lang!r} but eval is {eval_lang!r}. "
            f"Mixed-language local runs are not supported in v1."
        )


# ---------------------------------------------------------------------------
# TypeScript discovery
# ---------------------------------------------------------------------------

def discover_python_components(spec: str) -> list[ComponentManifest]:
    """Shell out to `python -m zhanla.discover file.py:ComponentName` and parse the result.

    Returns a leaf-first list of ComponentManifest objects covering the full closure.
    Raises ValueError if discovery fails or output is malformed.
    """
    result = subprocess.run(
        [sys.executable, "-m", "zhanla.discover", spec],
        capture_output=True,
        text=True,
        timeout=30,
    )

    if result.returncode != 0:
        stderr = (result.stderr or "").strip()
        raise ValueError(
            f"Discovery failed for {spec}: {stderr}" if stderr else f"Discovery failed for {spec}"
        )

    stdout = (result.stdout or "").strip()
    try:
        raw_manifests = json.loads(stdout)
    except json.JSONDecodeError as exc:
        raise ValueError(
            f"Invalid manifest JSON from zhanla.discover: {exc}. Output was: {stdout[:200]!r}"
        )

    if not isinstance(raw_manifests, list):
        raise ValueError(
            f"Expected a JSON array from zhanla.discover, got: {type(raw_manifests).__name__}"
        )

    manifests = []
    for raw in raw_manifests:
        if not isinstance(raw, dict):
            continue
        manifests.append(ComponentManifest(**{
            k: v for k, v in raw.items()
            if k in ComponentManifest.__dataclass_fields__
        }))
    return manifests


def discover_ts_components(spec: str) -> list[ComponentManifest]:
    """Shell out to `npx zhanla-sdk-ts discover <file.ts[:ExportName]>` and parse the result.

    The spec may be a plain file path or `file.ts:ExportName` for targeted closure discovery.
    Returns a list of ComponentManifest objects.
    Raises RunnerError if zhanla-sdk-ts is not installed.
    Raises ValueError if no components are found or output is malformed.
    """
    _ensure_ts_sdk_available()
    result = subprocess.run(
        ["npx", "--no-install", "zhanla-sdk-ts", "discover", spec],
        capture_output=True,
        text=True,
        timeout=30,
    )

    if result.returncode != 0:
        stderr = (result.stderr or "").strip()
        raise ValueError(
            f"No TypeScript components found in {spec}. "
            + (f"Error: {stderr}" if stderr else "")
        )

    stdout = (result.stdout or "").strip()
    try:
        raw_manifests = json.loads(stdout)
    except json.JSONDecodeError as exc:
        raise ValueError(
            f"Invalid manifest JSON from zhanla-sdk-ts discover: {exc}. "
            f"Output was: {stdout[:200]!r}"
        )

    if not isinstance(raw_manifests, list):
        raise ValueError(
            f"Expected a JSON array from zhanla-sdk-ts discover, got: {type(raw_manifests).__name__}"
        )

    manifests = []
    for raw in raw_manifests:
        if not isinstance(raw, dict):
            continue
        manifests.append(ComponentManifest(**{
            k: v for k, v in raw.items()
            if k in ComponentManifest.__dataclass_fields__
        }))

    return manifests


# ---------------------------------------------------------------------------
# PythonRunner
# ---------------------------------------------------------------------------

class PythonRunner:
    """Runner for Python-authored components. Wraps the existing executor."""

    def __init__(
        self,
        component: Any,
        eval_component: Any | None,
    ) -> None:
        self._component = component
        self._eval_component = eval_component

    def start(self) -> None:
        """No-op: Python runner uses in-process execution."""

    def stop(self) -> None:
        """No-op: no subprocess to clean up."""

    async def run_row(
        self,
        row: dict,
        trigger_run_id: str,
    ) -> dict:
        """Execute one row through the Python component (and optional eval).

        Returns a dict with:
        - status: "ok" | "error"
        - output: the component output dict
        - eval_output: the eval output dict (if eval component provided)
        - error: error message string (on failure)
        """
        from zhanla_cli.executor import execute_row

        result = await execute_row(
            self._component,
            self._eval_component,
            row,
            trigger_run_id,
        )

        if result.component_trace.status == "failed":
            return {
                "status": "error",
                "error": result.component_trace.error or "Unknown error",
            }

        response: dict = {
            "status": "ok",
            "output": result.component_trace.output or {},
        }

        if result.eval_trace is not None:
            if result.eval_trace.status == "failed":
                response["eval_error"] = result.eval_trace.error or "Eval error"
            else:
                response["eval_output"] = result.eval_trace.output or {}

        return response


# ---------------------------------------------------------------------------
# NodeRunner
# ---------------------------------------------------------------------------

class NodeRunner:
    """Runner for TypeScript-authored components.

    Manages a single long-lived Node subprocess per zhanla run invocation.
    Communicates with the subprocess over NDJSON on stdin/stdout.
    """

    def __init__(
        self,
        manifest: ComponentManifest,
        eval_manifest: ComponentManifest | None,
        file_path: str,
    ) -> None:
        self._manifest = manifest
        self._eval_manifest = eval_manifest
        self._file_path = file_path
        self._process: subprocess.Popen | None = None

    def start(self) -> None:
        """Start the long-lived Node subprocess."""
        target_name = self._manifest.name
        target = f"{self._file_path}:{target_name}"
        _ensure_ts_sdk_available()
        command = ["npx", "--no-install", "zhanla-sdk-ts", "run", target]
        if self._eval_manifest is not None:
            eval_target = (
                f"{self._eval_manifest.file_path}:{self._eval_manifest.name}"
                if self._eval_manifest.file_path and self._eval_manifest.name
                else None
            )
            if eval_target:
                command.extend(["--eval", eval_target])
        try:
            self._process = subprocess.Popen(
                command,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=os.environ.copy(),
            )
        except FileNotFoundError:
            raise RunnerError(
                "TypeScript support requires Node.js and npx. "
                "Install Node.js and add @zhanla/sdk-ts in the current project."
            )

    def stop(self) -> None:
        """Terminate the subprocess if running."""
        if self._process is not None:
            try:
                self._process.stdin.close()  # type: ignore[union-attr]
                self._process.wait(timeout=5)
            except Exception:
                self._process.kill()
            finally:
                self._process = None

    async def run_row(
        self,
        row: dict,
        trigger_run_id: str,
    ) -> dict:
        """Send one row to the subprocess and read back the NDJSON result."""
        if self._process is None:
            return {"status": "error", "error": "NodeRunner not started"}

        # Check if subprocess has crashed
        if self._process.poll() is not None:
            exit_code = self._process.poll()
            return {
                "status": "error",
                "error": f"TypeScript subprocess exited unexpectedly (exit code {exit_code})",
            }

        # Write the row as a JSON line to stdin
        line = json.dumps(row).encode() + b"\n"
        try:
            self._process.stdin.write(line)  # type: ignore[union-attr]
            self._process.stdin.flush()  # type: ignore[union-attr]
        except BrokenPipeError:
            return {"status": "error", "error": "TypeScript subprocess pipe broken"}

        # Read the result line from stdout
        result_line = self._process.stdout.readline()  # type: ignore[union-attr]
        if not result_line:
            exit_code = self._process.poll()
            return {
                "status": "error",
                "error": (
                    f"TypeScript subprocess produced no output "
                    f"(exit code {exit_code})"
                ),
            }

        try:
            return json.loads(result_line.decode())
        except json.JSONDecodeError as exc:
            return {
                "status": "error",
                "error": f"Invalid JSON from TypeScript subprocess: {exc}",
            }
