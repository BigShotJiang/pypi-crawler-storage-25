"""Canonical eval-input serialization helpers.

This module defines the plain-text eval contract used across local execution
and managed evaluate-only flows:
  - model_input
  - model_response
  - expected_output
"""
from __future__ import annotations

import json


def stringify_value(value: object) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    try:
        return json.dumps(value, ensure_ascii=True, sort_keys=True)
    except TypeError:
        return str(value)


def derive_model_input(row: dict) -> str:
    if "input" in row:
        return stringify_value(row["input"])
    return stringify_value(row)


def derive_expected_output(row: dict) -> str:
    if "expected_output" in row:
        return stringify_value(row["expected_output"])
    if "output" in row:
        return stringify_value(row["output"])
    return ""


def derive_model_response(output: object) -> str:
    if isinstance(output, dict) and set(output.keys()) == {"result"}:
        return stringify_value(output["result"])
    if isinstance(output, dict) and set(output.keys()) == {"output"}:
        return stringify_value(output["output"])
    return stringify_value(output)


def build_eval_kwargs(row: dict, output: object) -> dict[str, str]:
    """Build the canonical text-only eval kwargs."""
    return {
        "model_input": derive_model_input(row),
        "model_response": derive_model_response(output),
        "expected_output": derive_expected_output(row),
    }
