"""CLI-owned contracts shared across TS, web, and upload flows."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any


class ComponentType(str, Enum):
    AGENT = "agent"
    SKILL = "skill"
    TOOL = "tool"
    ORCHESTRATION = "orchestration"
    LLM_PROCESSOR = "llm_processor"
    CODE_EVAL = "code_eval"
    LLM_EVAL = "llm_eval"
    CHECKLIST = "checklist"
    EVAL_TREE = "eval_tree"


EXECUTION_MODES: dict[ComponentType, str] = {
    ComponentType.TOOL: "code",
    ComponentType.CODE_EVAL: "code",
    ComponentType.SKILL: "prompt",
    ComponentType.AGENT: "prompt",
    ComponentType.LLM_PROCESSOR: "prompt",
    ComponentType.LLM_EVAL: "prompt",
    ComponentType.ORCHESTRATION: "dag",
    ComponentType.CHECKLIST: "composite",
    ComponentType.EVAL_TREE: "composite",
}


def component_type_value(value: object) -> str:
    """Normalize any enum-or-string component type to its string value."""
    if isinstance(value, ComponentType):
        return value.value
    raw = getattr(value, "value", value)
    return str(raw)


@dataclass
class Step:
    """A single named step recorded within a parent trace."""

    name: str
    data: Any
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


@dataclass
class EvalTrace:
    """Execution record for a single component invocation."""

    name: str
    component_type: ComponentType | object
    input: dict
    output: dict | None
    error: str | None
    latency_ms: float
    steps: list[Step]
    status: str
    trigger_run_id: str | None = None
    path_taken: dict | None = None


@dataclass
class ComponentRef:
    """Typed reference to a nested component, emitted during manifest traversal."""

    key: str
    component_type: str
    name: str
    language: str
    execution_mode: str


@dataclass
class ConditionalStep:
    """Minimal conditional node used by manifest-backed TS orchestrations."""

    condition: Any
    if_true: str
    if_false: str


@dataclass
class OrchestrationStep:
    """Minimal orchestration step used by manifest-backed TS orchestrations."""

    name: str
    component: Any
    next: list[str] = field(default_factory=list)


@dataclass
class LeafNode:
    """Leaf node for manifest-backed TS eval trees."""

    eval: Any


@dataclass
class Edge:
    """Weighted edge for manifest-backed TS eval trees."""

    weight: float
    node: Any


@dataclass
class BranchNode:
    """Branch node for manifest-backed TS eval trees."""

    eval: Any
    threshold: float
    if_pass: list[Edge] = field(default_factory=list)
    if_fail: list[Edge] = field(default_factory=list)
