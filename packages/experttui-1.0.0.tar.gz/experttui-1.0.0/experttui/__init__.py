from __future__ import annotations
"""
ExpertTUI — Simple Terminal UI library for Python.
Version 1.0.0

Public API
----------
  menu_1D(items, ...)
  menu_2D(items, ...)
  clear_screen()
  hide_cursor() / show_cursor()

Item type hints (for autocomplete — import and annotate variables):
  ActionItem, SelectorItem, InputItem, CheckboxItem, HrItem
"""

__version__ = "1.0.0"
__author__  = "Your Name"
__all__ = [
    "menu_1D", "menu_2D",
    "clear_screen", "hide_cursor", "show_cursor",
    "ActionItem", "SelectorItem", "InputItem", "CheckboxItem", "HrItem",
]


import re
import sys
from typing import Any, Callable, Dict, List, Literal, Optional, Tuple, Union

import colorama
import readchar
from colorama import Fore, Style

colorama.just_fix_windows_console()


# ══════════════════════════════════════════════════════
#  Exported TypedDicts   (import for dict-key autocomplete)
# ══════════════════════════════════════════════════════

try:
    from typing import TypedDict

    class ActionItem(TypedDict, total=False):
        """Dict-based selectable action item."""
        type: Literal["action"]
        text: str
        function: Optional[Callable[[], Any]]
        disabled: bool
        color_selected: Optional[str]
        prefix: Optional[str]
        suffix: Optional[str]

    class SelectorItem(TypedDict, total=False):
        """Left / right cycling value picker."""
        type: Literal["selector"]
        text: str
        options: List[str]
        index: int
        color_selected: Optional[str]
        color_options: Optional[str]
        enter: Optional[bool]       # per-item override of enter_selector

    class InputItem(TypedDict, total=False):
        """Inline text input field."""
        type: Literal["input"]
        text: str
        value: str
        placeholder: str
        color_selected: Optional[str]

    class CheckboxItem(TypedDict, total=False):
        """Toggle checkbox."""
        type: Literal["checkbox"]
        text: str
        checked: bool
        disabled: bool
        color_selected: Optional[str]

    class HrItem(TypedDict, total=False):
        """Horizontal separator.  Connects to the border with junction chars when border is set."""
        type: Literal["hr"]
        fill: Literal["single", "double", "rounded", "heavy", "block"]
        label: str

except ImportError:  # pragma: no cover
    ActionItem = SelectorItem = InputItem = CheckboxItem = HrItem = dict  # type: ignore


# ══════════════════════════════════════════════════════
#  Border & junction data
# ══════════════════════════════════════════════════════

_BORDERS: Dict[str, Dict[str, str]] = {
    "double":  {"tl": "╔", "tr": "╗", "bl": "╚", "br": "╝", "h": "═", "v": "║"},
    "single":  {"tl": "┌", "tr": "┐", "bl": "└", "br": "┘", "h": "─", "v": "│"},
    "rounded": {"tl": "╭", "tr": "╮", "bl": "╰", "br": "╯", "h": "─", "v": "│"},
    "heavy":   {"tl": "┏", "tr": "┓", "bl": "┗", "br": "┛", "h": "━", "v": "┃"},
    "block":   {"tl": "█", "tr": "█", "bl": "█", "br": "█", "h": "█", "v": "█"},
}

# (border_v_char, hr_h_char) → (left_junction, right_junction)
_JUNCTIONS: Dict[Tuple[str, str], Tuple[str, str]] = {
    ("│", "─"): ("├", "┤"),
    ("│", "═"): ("╞", "╡"),
    ("│", "━"): ("┝", "┥"),
    ("║", "─"): ("╟", "╢"),
    ("║", "═"): ("╠", "╣"),
    ("┃", "─"): ("┠", "┨"),
    ("┃", "━"): ("┣", "┫"),
    ("█", "█"): ("█", "█"),
}

# (border_h_char, gap_v_char) → T-junction pointing DOWN (top border meets gap)
_TOP_JUNCTIONS: Dict[Tuple[str, str], str] = {
    ("─", "│"): "┬", ("─", "║"): "╥",
    ("═", "│"): "╤", ("═", "║"): "╦",
    ("━", "┃"): "┳",
    ("█", "█"): "█",
}

# (border_h_char, gap_v_char) → T-junction pointing UP (bottom border meets gap)
_BOT_JUNCTIONS: Dict[Tuple[str, str], str] = {
    ("─", "│"): "┴", ("─", "║"): "╨",
    ("═", "│"): "╧", ("═", "║"): "╩",
    ("━", "┃"): "┻",
    ("█", "█"): "█",
}

# (hr_h_char, gap_v_char) → cross junction (hr meets gap)
_CROSS_JUNCTIONS: Dict[Tuple[str, str], str] = {
    ("─", "│"): "┼", ("─", "║"): "╫",
    ("═", "│"): "╪", ("═", "║"): "╬",
    ("━", "┃"): "╋",
    ("█", "█"): "█",
}


# ══════════════════════════════════════════════════════
#  Public utilities
# ══════════════════════════════════════════════════════

def clear_screen() -> None:
    """Clears the entire terminal screen."""
    sys.stdout.write("\033[3J\033[2J\033[H" * 2)
    sys.stdout.flush()

def hide_cursor() -> None:
    """Hides the terminal cursor."""
    sys.stdout.write("\033[?25l")
    sys.stdout.flush()

def show_cursor() -> None:
    """Shows the terminal cursor."""
    sys.stdout.write("\033[?25h")
    sys.stdout.flush()


# ══════════════════════════════════════════════════════
#  Private: terminal / string helpers
# ══════════════════════════════════════════════════════

def _visual_len(text: str) -> int:
    """Visible length of a string (ANSI escape codes stripped)."""
    return len(re.sub(r"\033\[[0-9;]*m", "", text))

def _truncate_ansi(text: str, max_len: int) -> str:
    """Truncates text to max_len visible characters, preserving ANSI codes."""
    if _visual_len(text) <= max_len:
        return text
    result, visible, i = [], 0, 0
    while i < len(text):
        if text[i] == "\033":
            j = text.find("m", i)
            if j == -1: break
            result.append(text[i:j+1]); i = j + 1
        else:
            if visible >= max_len: break
            result.append(text[i]); visible += 1; i += 1
    result.append(Style.RESET_ALL)
    return "".join(result)

def _clear_lines(n: int) -> None:
    """Moves cursor up n lines and clears to end of screen."""
    if n > 0:
        sys.stdout.write(f"\033[{n}A\033[J")
        sys.stdout.flush()


# ══════════════════════════════════════════════════════
#  Private: border / junction helpers
# ══════════════════════════════════════════════════════

def _get_border(style: Any) -> Optional[Dict[str, str]]:
    if not style: return None
    if style is True: return _BORDERS["double"]
    return _BORDERS.get(style, _BORDERS["double"])

def _get_junction(v: str, h: str) -> Tuple[str, str]:
    """Returns (left_junction, right_junction) for a border-to-hr connection."""
    return _JUNCTIONS.get((v, h), (v, v))

def _gap_separator(fill_style: Any, gap: int) -> str:
    """Returns a string of exactly `gap` characters for the column separator."""
    if not fill_style or gap <= 0: return " " * gap
    chars = {"double": "║", "single": "│", "rounded": "│", "heavy": "┃", "block": "█"}
    c = chars.get(fill_style, " ")
    if c == "█": return "█" * gap
    lpad = (gap - 1) // 2
    return " " * lpad + c + " " * (gap - 1 - lpad)

def _gap_v_char(fill_style: Any) -> str:
    """Returns the vertical character for a gap_fill style."""
    chars = {"double": "║", "single": "│", "rounded": "│", "heavy": "┃", "block": "█"}
    return chars.get(fill_style, " ") if fill_style else " "

def _col_break_positions(col_widths: List[int], gap: int, gap_fill: Any,
                         rows: Optional[list] = None) -> List[int]:
    """
    Returns gap-center positions (relative to content start) that appear in EVERY
    content row.  If any non-hr row has fewer columns than needed for a break, that
    break is excluded — prevents dangling ┬/┴ when full-width rows mix with
    multi-column rows.
    """
    if not gap_fill or gap <= 0 or not col_widths or len(col_widths) <= 1:
        return []

    # Minimum column count across all non-hr content rows
    if rows is not None:
        content = [r for r in rows
                   if not (len(r) == 1 and isinstance(r[0], dict) and r[0].get("type") == "hr")]
        min_cols = min((len(r) for r in content), default=0)
        if min_cols <= 1:
            return []   # at least one full-width row — no consistent column boundary
        usable = col_widths[:min_cols - 1]
    else:
        usable = col_widths[:-1]

    lpad = (gap - 1) // 2
    positions, pos = [], 0
    for w in usable:
        pos += w
        positions.append(pos + lpad)
        pos += gap
    return positions

def _inject_junctions(line_chars: list, positions: List[int], padding_left: int,
                      inner_w: int, junction_char: str) -> None:
    """Mutates line_chars in-place, inserting junction_char at each break position."""
    for p in positions:
        actual = padding_left + p
        if 0 <= actual < inner_w:
            line_chars[actual] = junction_char


# ══════════════════════════════════════════════════════
#  Private: margin / padding resolver
# ══════════════════════════════════════════════════════

def _resolve_sides(cfg: dict, prefix: str) -> Dict[str, int]:
    base = cfg.get(prefix) or 0
    return {
        side: (cfg[f"{prefix}_{side}"] if cfg.get(f"{prefix}_{side}") is not None else base)
        for side in ("top", "right", "bottom", "left")
    }


# ══════════════════════════════════════════════════════
#  Private: item renderers
# ══════════════════════════════════════════════════════

def _affixes(selection_type: str) -> Tuple[str, str]:
    if selection_type == "left_arrow":  return "> ", "  "
    if selection_type == "two_arrows":  return "< ", " >"
    return "  ", "  "

def _render_item(item: Any, selected: bool, cfg: dict) -> str:
    if isinstance(item, str):   return item
    if isinstance(item, tuple): return _render_tuple(item, selected, cfg)
    if isinstance(item, dict):
        t = item.get("type", "action")
        if t == "selector": return _render_selector(item, selected, cfg)
        if t == "input":    return _render_input(item, selected, cfg)
        if t == "checkbox": return _render_checkbox(item, selected, cfg)
        if t == "hr":       return ""   # placeholder; drawn by _draw_menu
        return _render_action(item, selected, cfg)
    return str(item)

def _render_tuple(item: tuple, selected: bool, cfg: dict) -> str:
    label = item[0]
    pre, suf = _affixes(cfg["selection_type"])
    if selected:
        return getattr(Fore, cfg["color"]) + Style.BRIGHT + pre + label + suf + Style.RESET_ALL
    return " " * len(pre) + label

def _render_action(item: dict, selected: bool, cfg: dict) -> str:
    dom = {"text": "", "function": None, "disabled": False, "color_selected": None, "prefix": None, "suffix": None}
    it  = {**dom, **item}
    pre, suf = _affixes(cfg["selection_type"])
    if it["prefix"] is not None: pre = it["prefix"]
    if it["suffix"] is not None: suf = it["suffix"]
    if it["disabled"]:
        return Fore.LIGHTBLACK_EX + " " * len(pre) + it["text"] + Style.RESET_ALL
    if selected:
        c = (it["color_selected"] or cfg["color"]).upper()
        return getattr(Fore, c) + Style.BRIGHT + pre + it["text"] + suf + Style.RESET_ALL
    return " " * len(pre) + it["text"]

def _render_selector(item: dict, selected: bool, cfg: dict) -> str:
    """
    Inactive:       {indent}{label}:   {val}  
    Selected:       {indent}{label}: < {val} >
    Active (enter): {indent}{label}: [ {val} ]
    All three have equal visual width.
    """
    dom = {"text": "", "options": [], "index": 0, "color_selected": None, "color_options": None, "enter": None}
    it  = {**dom, **item}
    pre, _ = _affixes(cfg["selection_type"])
    indent = " " * len(pre)
    opts   = it["options"]
    idx    = it["index"] % len(opts) if opts else 0
    val    = opts[idx] if opts else ""

    w = cfg["width"]
    if w != "auto":
        val = val[:max(0, int(w) - len(indent) - len(it["text"]) - 6)]

    if selected:
        cl     = (it["color_selected"] or cfg["color"]).upper()
        co     = (it["color_options"]  or cfg["color"]).upper()
        active = cfg.get("_selector_active", False)
        if active:
            brackets = ("[ ", " ]")
            bc = Fore.WHITE
        else:
            brackets = ("< ", " >")
            bc = getattr(Fore, co)
        return (indent + getattr(Fore, cl) + Style.BRIGHT + it["text"] + ": " + Style.RESET_ALL
                + bc + Style.BRIGHT + brackets[0] + val + brackets[1] + Style.RESET_ALL)
    return indent + it["text"] + f":   {val}  "

def _render_input(item: dict, selected: bool, cfg: dict) -> str:
    dom = {"text": "", "value": "", "placeholder": "", "color_selected": None}
    it  = {**dom, **item}
    pre, _ = _affixes(cfg["selection_type"])
    indent = " " * len(pre)
    w      = cfg["width"]
    max_w  = None if w == "auto" else max(0, int(w) - len(indent) - len(it["text"]) - 6)

    if selected:
        c   = (it["color_selected"] or cfg["color"]).upper()
        raw = it["value"] if it["value"] else it["placeholder"]
        if max_w is not None: raw = raw[:max_w]
        display = raw if it["value"] else Fore.LIGHTBLACK_EX + raw + Style.RESET_ALL
        return indent + getattr(Fore, c) + Style.BRIGHT + it["text"] + ": " + Style.RESET_ALL + f"< {display} >"
    raw = it["value"] or it["placeholder"]
    if max_w is not None: raw = raw[:max_w]
    return indent + it["text"] + f":   {raw}  "

def _render_checkbox(item: dict, selected: bool, cfg: dict) -> str:
    dom = {"text": "", "checked": False, "disabled": False, "color_selected": None}
    it  = {**dom, **item}
    pre, suf = _affixes(cfg["selection_type"])
    mark = "[x]" if it["checked"] else "[ ]"
    if it["disabled"]:
        return Fore.LIGHTBLACK_EX + " " * len(pre) + f"{mark} {it['text']}" + Style.RESET_ALL
    if selected:
        c = (it["color_selected"] or cfg["color"]).upper()
        return getattr(Fore, c) + Style.BRIGHT + pre + f"{mark} {it['text']}" + suf + Style.RESET_ALL
    return " " * len(pre) + f"{mark} {it['text']}"


# ══════════════════════════════════════════════════════
#  Private: hr line renderer
# ══════════════════════════════════════════════════════

def _render_hr_line(item: dict, content_w: int, padding: dict, border_chars: Optional[dict],
                    ml: str, cfg: dict, col_breaks: Optional[List[int]] = None) -> str:
    """Renders a full-width hr separator line with optional border junctions and cross junctions."""
    bs   = cfg.get("border")
    fill = item.get("fill") or ("double" if bs is True else bs if bs else "single")
    if fill not in _BORDERS: fill = "single"

    h_char = _BORDERS[fill]["h"]
    label  = item.get("label", "")
    inner  = padding["left"] + content_w + padding["right"]

    if label:
        s      = f" {label} "
        dashes = max(0, inner - len(s))
        left_d = dashes // 2
        content = h_char * left_d + s + h_char * (dashes - left_d)
        content = content[:inner].ljust(inner, h_char)
    else:
        content = h_char * inner

    # Insert cross junctions where gap separators would be
    if col_breaks and cfg.get("gap_fill"):
        gv   = _gap_v_char(cfg["gap_fill"])
        junc = _CROSS_JUNCTIONS.get((h_char, gv), gv)
        chars = list(content)
        _inject_junctions(chars, col_breaks, padding["left"], inner, junc)
        content = "".join(chars)

    if border_chars:
        lj, rj = _get_junction(border_chars["v"], h_char)
        return ml + lj + content + rj
    return ml + content


# ══════════════════════════════════════════════════════
#  Private: 2D column helpers
# ══════════════════════════════════════════════════════

def _column_widths(rows: list, cfg: dict) -> List[int]:
    """Max visual width of each column across all rows (uses both selected and unselected states)."""
    if not rows: return []
    max_cols = max(len(r) for r in rows)
    widths   = []
    for j in range(max_cols):
        w = 0
        for row in rows:
            if j < len(row):
                w = max(w,
                        _visual_len(_render_item(row[j], True,  cfg)),
                        _visual_len(_render_item(row[j], False, cfg)))
        widths.append(w)
    return widths

def _render_row_2d(row: list, sel_col: int, col_widths: Optional[List[int]], cfg: dict) -> str:
    """Renders one row of a 2D menu, joining cells with the configured gap separator."""
    align = cfg.get("align", True)
    sep   = _gap_separator(cfg.get("gap_fill", False), cfg.get("gap", 2))
    parts = []
    for ci, item in enumerate(row):
        r = _render_item(item, ci == sel_col, cfg)
        if align and col_widths and ci < len(col_widths):
            r += " " * max(0, col_widths[ci] - _visual_len(r))
        parts.append(r)
    return sep.join(parts)


# ══════════════════════════════════════════════════════
#  Private: draw backend
# ══════════════════════════════════════════════════════

def _draw_menu(lines: list, idx_range: Any, cfg: dict,
               col_breaks: Optional[List[int]] = None) -> Tuple[int, dict, int]:
    """
    Renders a list of lines (strings or HrItem dicts) with border, padding, and margin.
    col_breaks: 0-indexed gap-center positions relative to content start (2D only).
    Returns (total_lines, line_map, content_w).
    """
    margin       = _resolve_sides(cfg, "margin")
    padding      = _resolve_sides(cfg, "padding")
    border_chars = _get_border(cfg["border"])
    w_opt        = cfg["width"]
    ml           = " " * margin["left"]

    text_lines = [l for l in lines if isinstance(l, str)]
    if w_opt == "auto":
        content_w = max((_visual_len(l) for l in text_lines), default=0)
    else:
        content_w = int(w_opt)
        lines = [_truncate_ansi(l, content_w) if isinstance(l, str) else l for l in lines]

    inner_w  = padding["left"] + content_w + padding["right"]
    line_map: Dict[int, int] = {}
    line_num = 0

    for _ in range(margin["top"]):
        print(); line_num += 1

    if border_chars:
        h = border_chars["h"]
        if col_breaks and cfg.get("gap_fill"):
            gv   = _gap_v_char(cfg["gap_fill"])
            junc = _TOP_JUNCTIONS.get((h, gv), gv)
            chars = list(h * inner_w)
            _inject_junctions(chars, col_breaks, padding["left"], inner_w, junc)
            top = border_chars["tl"] + "".join(chars) + border_chars["tr"]
        else:
            top = border_chars["tl"] + h * inner_w + border_chars["tr"]
        print(ml + top); line_num += 1

    for _ in range(padding["top"]):
        print(ml + (border_chars["v"] + " " * inner_w + border_chars["v"] if border_chars else ""))
        line_num += 1

    for idx, l in zip(idx_range, lines):
        line_map[idx] = line_num
        if isinstance(l, dict) and l.get("type") == "hr":
            print(_render_hr_line(l, content_w, padding, border_chars, ml, cfg, col_breaks))
        else:
            pad = max(0, content_w - _visual_len(l))
            if border_chars:
                print(ml + border_chars["v"] + " " * padding["left"] + l + " " * pad + " " * padding["right"] + border_chars["v"])
            else:
                print(ml + " " * padding["left"] + l + " " * pad + " " * padding["right"])
        line_num += 1

    for _ in range(padding["bottom"]):
        print(ml + (border_chars["v"] + " " * inner_w + border_chars["v"] if border_chars else ""))
        line_num += 1

    if border_chars:
        h = border_chars["h"]
        if col_breaks and cfg.get("gap_fill"):
            gv   = _gap_v_char(cfg["gap_fill"])
            junc = _BOT_JUNCTIONS.get((h, gv), gv)
            chars = list(h * inner_w)
            _inject_junctions(chars, col_breaks, padding["left"], inner_w, junc)
            bot = border_chars["bl"] + "".join(chars) + border_chars["br"]
        else:
            bot = border_chars["bl"] + h * inner_w + border_chars["br"]
        print(ml + bot); line_num += 1

    for _ in range(margin["bottom"]):
        print(); line_num += 1

    sys.stdout.flush()
    return line_num, line_map, content_w


def _draw_1d(items: list, selectable: list, sel: int, scroll: int, cfg: dict) -> Tuple[int, dict, int]:
    h       = cfg["height"]
    visible = range(len(items)) if h == "auto" else range(scroll, min(scroll + int(h), len(items)))
    lines   = []
    for idx in visible:
        item = items[idx]
        if isinstance(item, dict) and item.get("type") == "hr":
            lines.append(item)
        else:
            lines.append(_render_item(item, selectable[sel] == idx, cfg))
    return _draw_menu(lines, visible, cfg)


def _draw_2d(rows: list, sel_rows: list, sel_in_row: dict,
             row_sel: int, col_sel: int, scroll: int, cfg: dict) -> Tuple[int, dict, int]:
    h       = cfg["height"]
    gap     = cfg.get("gap", 2)
    align   = cfg.get("align", True)
    sr      = sel_rows[row_sel] if sel_rows else -1
    sc      = sel_in_row[sr][col_sel] if sr >= 0 else -1
    visible = range(len(rows)) if h == "auto" else range(scroll, min(scroll + int(h), len(rows)))
    cw      = _column_widths(rows, cfg) if align else None

    col_breaks = _col_break_positions(cw, gap, cfg.get("gap_fill"), rows) if cw else []

    lines = []
    for ri in visible:
        row = rows[ri]
        if len(row) == 1 and isinstance(row[0], dict) and row[0].get("type") == "hr":
            lines.append(row[0])
        else:
            lines.append(_render_row_2d(row, sc if ri == sr else -1, cw, cfg))
    return _draw_menu(lines, visible, cfg, col_breaks)


# ══════════════════════════════════════════════════════
#  Private: inline input editor
# ══════════════════════════════════════════════════════

def _edit_loop(buf: list, orig: list, max_len: Optional[int], on_change: Callable) -> bool:
    """Core editing loop.  Returns True if cancelled (ESC), False if confirmed (Enter)."""
    on_change()
    show_cursor()
    while True:
        key = readchar.readkey()
        if key == readchar.key.ENTER:
            hide_cursor(); return False
        if key == readchar.key.ESC:
            buf[:] = orig; on_change(); hide_cursor(); return True
        if key in (readchar.key.BACKSPACE, "\x7f"):
            if buf: buf.pop(); on_change()
        elif len(key) == 1 and key.isprintable():
            if max_len is None or len(buf) < max_len:
                buf.append(key); on_change()


def _inline_edit_1d(
    item: dict, cfg: dict, total_lines: int, item_line: int,
    items: list, selectable: list, sel: int, scroll: int, content_w: int,
) -> Tuple[int, dict, int]:
    """Edits an input field inline within a 1D menu."""
    bc     = _get_border(cfg["border"])
    margin = _resolve_sides(cfg, "margin")
    pad    = _resolve_sides(cfg, "padding")
    pre, _ = _affixes(cfg["selection_type"])
    indent = " " * len(pre)
    w_opt  = cfg["width"]
    label  = item.get("text", "")

    col_start = margin["left"] + (1 if bc else 0) + pad["left"] + len(indent) + len(label) + len(": < ") + 1
    max_val   = None if w_opt == "auto" else max(0, int(w_opt) - len(indent) - len(label) - 6)

    buf  = list(item.get("value", ""))
    orig = list(buf)
    st   = {"total": total_lines, "cw": content_w}

    def draw_all() -> None:
        item["value"] = "".join(buf)
        dn = st["total"] - item_line
        if dn > 0: sys.stdout.write(f"\033[{dn}B")
        sys.stdout.write("\r"); sys.stdout.flush()
        _clear_lines(st["total"])
        t, _, c = _draw_1d(items, selectable, sel, scroll, cfg)
        st["total"] = t; st["cw"] = c
        sys.stdout.write(f"\033[{st['total'] - item_line}A\033[{col_start + len(buf)}G")
        sys.stdout.flush()

    def draw_line() -> None:
        ml = " " * margin["left"]
        sys.stdout.write("\r\033[K")
        sys.stdout.write(ml + (bc["v"] + " " * pad["left"] if bc else " " * pad["left"]))
        rendered = _render_input({**item, "value": "".join(buf)}, True, cfg)
        sys.stdout.write(rendered)
        p = max(0, st["cw"] - _visual_len(rendered))
        sys.stdout.write(" " * p + " " * pad["right"] + (bc["v"] if bc else ""))
        sys.stdout.write(f"\033[{col_start + len(buf)}G")
        sys.stdout.flush()

    sys.stdout.write(f"\033[{total_lines - item_line}A"); sys.stdout.flush()
    redraw    = draw_all if w_opt == "auto" else draw_line
    cancelled = _edit_loop(buf, orig, max_val, redraw)
    item["value"] = "".join(orig if cancelled else buf)

    dn = st["total"] - item_line
    if dn > 0: sys.stdout.write(f"\033[{dn}B")
    sys.stdout.write("\r"); sys.stdout.flush()
    _clear_lines(st["total"])
    return _draw_1d(items, selectable, sel, scroll, cfg)


def _inline_edit_2d(
    item: dict, col_idx: int, cfg: dict, total_lines: int, item_line: int,
    rows: list, sel_rows: list, sel_in_row: dict,
    row_sel: int, col_sel: int, scroll: int, content_w: int,
) -> Tuple[int, dict, int]:
    """Edits an input field inline within a 2D menu."""
    bc      = _get_border(cfg["border"])
    margin  = _resolve_sides(cfg, "margin")
    pad     = _resolve_sides(cfg, "padding")
    pre, _  = _affixes(cfg["selection_type"])
    indent  = " " * len(pre)
    w_opt   = cfg["width"]
    label   = item.get("text", "")
    gap     = cfg.get("gap", 2)
    align   = cfg.get("align", True)
    sr      = sel_rows[row_sel]
    sc_act  = sel_in_row[sr][col_sel]
    row     = rows[sr]

    cw_cols = _column_widths(rows, cfg) if align else None
    if align and cw_cols:
        h_offset = sum(cw_cols[c] for c in range(col_idx)) + gap * col_idx
    else:
        h_offset = sum(_visual_len(_render_item(row[c], False, cfg)) for c in range(col_idx)) + gap * col_idx

    col_start = margin["left"] + (1 if bc else 0) + pad["left"] + h_offset + len(indent) + len(label) + len(": < ") + 1
    max_val   = None if w_opt == "auto" else max(0, int(w_opt) - len(indent) - len(label) - 6)

    buf  = list(item.get("value", ""))
    orig = list(buf)
    st   = {"total": total_lines, "cw": content_w}

    def draw_all() -> None:
        item["value"] = "".join(buf)
        dn = st["total"] - item_line
        if dn > 0: sys.stdout.write(f"\033[{dn}B")
        sys.stdout.write("\r"); sys.stdout.flush()
        _clear_lines(st["total"])
        t, _, c = _draw_2d(rows, sel_rows, sel_in_row, row_sel, col_sel, scroll, cfg)
        st["total"] = t; st["cw"] = c
        sys.stdout.write(f"\033[{st['total'] - item_line}A\033[{col_start + len(buf)}G")
        sys.stdout.flush()

    def draw_line() -> None:
        ml  = " " * margin["left"]
        sep = _gap_separator(cfg.get("gap_fill", False), gap)
        cur_cw = _column_widths(rows, cfg) if align else None
        sys.stdout.write("\r\033[K")
        sys.stdout.write(ml + (bc["v"] + " " * pad["left"] if bc else " " * pad["left"]))
        parts = []
        for ci, it in enumerate(row):
            r = (_render_input({**item, "value": "".join(buf)}, True, cfg)
                 if ci == col_idx else _render_item(it, ci == sc_act, cfg))
            if align and cur_cw and ci < len(cur_cw):
                r += " " * max(0, cur_cw[ci] - _visual_len(r))
            parts.append(r)
        rendered = sep.join(parts)
        sys.stdout.write(rendered)
        p = max(0, st["cw"] - _visual_len(rendered))
        sys.stdout.write(" " * p + " " * pad["right"] + (bc["v"] if bc else ""))
        sys.stdout.write(f"\033[{col_start + len(buf)}G")
        sys.stdout.flush()

    sys.stdout.write(f"\033[{total_lines - item_line}A"); sys.stdout.flush()
    redraw    = draw_all if w_opt == "auto" else draw_line
    cancelled = _edit_loop(buf, orig, max_val, redraw)
    item["value"] = "".join(orig if cancelled else buf)

    dn = st["total"] - item_line
    if dn > 0: sys.stdout.write(f"\033[{dn}B")
    sys.stdout.write("\r"); sys.stdout.flush()
    _clear_lines(st["total"])
    return _draw_2d(rows, sel_rows, sel_in_row, row_sel, col_sel, scroll, cfg)


# ══════════════════════════════════════════════════════
#  Private: selector enter helper
# ══════════════════════════════════════════════════════

def _selector_needs_enter(item: dict, cfg: dict) -> bool:
    per = item.get("enter")
    return bool(per) if per is not None else bool(cfg.get("enter_selector", False))


# ══════════════════════════════════════════════════════
#  menu_1D
# ══════════════════════════════════════════════════════

def menu_1D(
    items: list,
    *,
    color: str = "YELLOW",
    selection_type: Literal["left_arrow", "two_arrows"] = "left_arrow",
    moving: Literal["both", "arrows", "wsad"] = "both",
    border: Union[bool, Literal["single", "double", "rounded", "heavy", "block"]] = False,
    wait_after_function: bool = False,
    return_after_action: bool = False,
    enter_selector: bool = False,
    width: Union[Literal["auto"], int] = "auto",
    height: Union[Literal["auto"], int] = "auto",
    margin: int = 0,
    margin_top: Optional[int] = None,
    margin_right: Optional[int] = None,
    margin_bottom: Optional[int] = None,
    margin_left: Optional[int] = None,
    padding: int = 0,
    padding_top: Optional[int] = None,
    padding_right: Optional[int] = None,
    padding_bottom: Optional[int] = None,
    padding_left: Optional[int] = None,
) -> None:
    """
    Displays an interactive vertical (1D) terminal menu.

    Parameters
    ----------
    items : list
        A list of items to display.  Each element can be one of:

        ``"label"``
            Static non-selectable text.

        ``("label", callable)``
            Selectable action item.

        ``{"text": str, "function": callable, ...}``
            Action item (dict form). Optional keys: ``disabled`` (bool),
            ``color_selected`` (str), ``prefix`` (str), ``suffix`` (str).

        ``{"type": "selector", "text": str, "options": list, "index": int, ...}``
            Left / right cycling value picker.  Optional keys: ``color_selected``,
            ``color_options``, ``enter`` (bool — per-item ``enter_selector`` override).

        ``{"type": "input", "text": str, "value": str, "placeholder": str, ...}``
            Inline text field.  Enter opens the editor, ESC cancels without saving.
            Optional key: ``color_selected``.

        ``{"type": "checkbox", "text": str, "checked": bool, ...}``
            Toggle checkbox.  Enter flips ``checked`` in-place.
            Optional keys: ``disabled``, ``color_selected``.

        ``{"type": "hr"}``
            Horizontal separator line.  Connects to the menu border with the correct
            Unicode junction characters when a ``border`` style is set.
            Optional keys: ``fill`` (border style name), ``label`` (centred text).

    color : str
        Colorama colour name for the highlighted item.  Default ``"YELLOW"``.
    selection_type : "left_arrow" | "two_arrows"
        Visual indicator.  ``"left_arrow"`` → ``> item``,
        ``"two_arrows"`` → ``< item >``.
    moving : "both" | "arrows" | "wsad"
        Which keys move the cursor.
    border : bool | "single" | "double" | "rounded" | "heavy" | "block"
        Draw a border.  ``True`` uses ``"double"``.
    wait_after_function : bool
        Pause for any key after an action runs before redrawing.
    return_after_action : bool
        Exit the menu after an action runs instead of redrawing it.
    enter_selector : bool
        If ``True``, a selector requires Enter to enter edit mode; LEFT / RIGHT
        changes the value, Enter confirms, ESC restores and exits edit mode.
        Can be overridden per-item with ``"enter": bool`` on the selector dict.
    width : "auto" | int
        ``"auto"`` (default): border resizes live to the widest item.
        int N: fixed content width; excess truncated, input capped at available space.
    height : "auto" | int
        ``"auto"`` (default): all items visible.
        int N: visible row count; scrolls to keep the selection visible.
    margin : int
        Space *outside* the border on all four sides.
    margin_top / margin_right / margin_bottom / margin_left : int | None
        Per-side override for ``margin``.
    padding : int
        Space *inside* the border on all four sides.
    padding_top / padding_right / padding_bottom / padding_left : int | None
        Per-side override for ``padding``.
    """
    if not isinstance(items, list):
        raise TypeError(f"items must be a list, not {type(items).__name__}")

    cfg: Dict[str, Any] = {
        "color": color.upper(), "selection_type": selection_type, "moving": moving,
        "border": border, "wait_after_function": wait_after_function,
        "return_after_action": return_after_action, "enter_selector": enter_selector,
        "width": width, "height": height,
        "margin": margin, "margin_top": margin_top, "margin_right": margin_right,
        "margin_bottom": margin_bottom, "margin_left": margin_left,
        "padding": padding, "padding_top": padding_top, "padding_right": padding_right,
        "padding_bottom": padding_bottom, "padding_left": padding_left,
    }

    selectable = [
        i for i, item in enumerate(items)
        if isinstance(item, tuple)
        or (isinstance(item, dict)
            and not item.get("disabled", False)
            and item.get("type") not in ("hr",))
    ]

    if not selectable:
        for item in items: print(_render_item(item, False, cfg))
        return

    sel          = 0
    scroll       = 0
    sel_active   = False
    sel_orig_idx = 0
    hide_cursor()

    def draw(sel_a: bool = False) -> Tuple[int, dict, int]:
        return _draw_1d(items, selectable, sel, scroll, {**cfg, "_selector_active": sel_a})

    try:
        total, line_map, cw = draw()
        mv    = cfg["moving"]
        h_opt = cfg["height"]

        while True:
            key     = readchar.readkey()
            current = items[selectable[sel]]
            changed = False

            # ── selector edit mode ────────────────────────────────────
            if sel_active:
                opts = current.get("options", [])
                if (key == readchar.key.LEFT  and mv in ["both","arrows"]) or (key.lower() == "a" and mv in ["both","wsad"]):
                    if opts: current["index"] = (current.get("index",0) - 1) % len(opts); changed = True
                elif (key == readchar.key.RIGHT and mv in ["both","arrows"]) or (key.lower() == "d" and mv in ["both","wsad"]):
                    if opts: current["index"] = (current.get("index",0) + 1) % len(opts); changed = True
                elif key == readchar.key.ENTER:
                    sel_active = False; changed = True
                elif key == readchar.key.ESC:
                    current["index"] = sel_orig_idx; sel_active = False; changed = True
                if changed: _clear_lines(total); total, line_map, cw = draw(sel_active)
                continue

            # ── navigation ────────────────────────────────────────────
            if (key.lower() == "w" and mv in ["both","wsad"]) or (key == readchar.key.UP    and mv in ["both","arrows"]):
                sel = (sel - 1) % len(selectable); changed = True
            elif (key.lower() == "s" and mv in ["both","wsad"]) or (key == readchar.key.DOWN  and mv in ["both","arrows"]):
                sel = (sel + 1) % len(selectable); changed = True

            elif (key == readchar.key.LEFT  and mv in ["both","arrows"]) or (key.lower() == "a" and mv in ["both","wsad"]):
                if isinstance(current, dict) and current.get("type") == "selector" and not _selector_needs_enter(current, cfg):
                    opts = current.get("options", [])
                    if opts: current["index"] = (current.get("index",0) - 1) % len(opts); changed = True
            elif (key == readchar.key.RIGHT and mv in ["both","arrows"]) or (key.lower() == "d" and mv in ["both","wsad"]):
                if isinstance(current, dict) and current.get("type") == "selector" and not _selector_needs_enter(current, cfg):
                    opts = current.get("options", [])
                    if opts: current["index"] = (current.get("index",0) + 1) % len(opts); changed = True

            elif key == readchar.key.ENTER:
                t = current.get("type") if isinstance(current, dict) else None
                if t == "checkbox":
                    current["checked"] = not current.get("checked", False)
                    _clear_lines(total); total, line_map, cw = draw()
                    continue
                elif t == "input":
                    total, line_map, cw = _inline_edit_1d(
                        current, cfg, total, line_map[selectable[sel]], items, selectable, sel, scroll, cw)
                elif t == "selector" and _selector_needs_enter(current, cfg):
                    sel_active = True; sel_orig_idx = current.get("index", 0); changed = True
                else:
                    action = current[1] if isinstance(current, tuple) else current.get("function")
                    if callable(action):
                        _clear_lines(total); show_cursor(); action()
                        if cfg["wait_after_function"]: readchar.readkey()
                        if cfg["return_after_action"]: break
                        hide_cursor(); total, line_map, cw = draw()
                continue

            elif key == readchar.key.ESC:
                break

            if changed and h_opt != "auto":
                idx = selectable[sel]; h = int(h_opt)
                if idx < scroll: scroll = idx
                elif idx >= scroll + h: scroll = idx - h + 1

            if changed:
                _clear_lines(total); total, line_map, cw = draw()

    finally:
        show_cursor()


# ══════════════════════════════════════════════════════
#  menu_2D
# ══════════════════════════════════════════════════════

def menu_2D(
    items: list,
    *,
    color: str = "YELLOW",
    selection_type: Literal["left_arrow", "two_arrows"] = "left_arrow",
    moving: Literal["both", "arrows", "wsad"] = "both",
    border: Union[bool, Literal["single", "double", "rounded", "heavy", "block"]] = False,
    wait_after_function: bool = False,
    return_after_action: bool = False,
    enter_selector: bool = False,
    width: Union[Literal["auto"], int] = "auto",
    height: Union[Literal["auto"], int] = "auto",
    margin: int = 0,
    margin_top: Optional[int] = None,
    margin_right: Optional[int] = None,
    margin_bottom: Optional[int] = None,
    margin_left: Optional[int] = None,
    padding: int = 0,
    padding_top: Optional[int] = None,
    padding_right: Optional[int] = None,
    padding_bottom: Optional[int] = None,
    padding_left: Optional[int] = None,
    align: bool = True,
    gap: int = 2,
    gap_fill: Union[bool, Literal["single", "double", "rounded", "heavy", "block"]] = False,
) -> None:
    """
    Displays an interactive 2D terminal menu.

    ``items`` is a list of rows.  Each row is either:

    - A **list** — a row with multiple column items.
    - A **single item** (str / tuple / dict) — shorthand for a 1-column row.
      A bare ``{"type": "hr", ...}`` produces a full-width separator spanning all columns.

    Navigation
    ----------
    UP / DOWN  (or W / S)
        Move between rows.
    LEFT / RIGHT  (or A / D, per ``moving``)
        - Row with **multiple** selectable columns → move between columns.
        - Row with **one** selectable column that is a selector → cycle its value
          (unless ``enter_selector`` / per-item ``"enter": True`` is active).

    Parameters
    ----------
    items : list
        See ``menu_1D`` for supported item formats.
    align : bool
        If ``True`` (default), every column uses the same fixed width (the maximum
        rendered width of any cell in that column) so columns stay visually aligned.
    gap : int
        Space (in columns) between adjacent cells in a row.  Default ``2``.
    gap_fill : bool | border-style-name
        Character used to fill the inter-column gap.  ``False`` (default) → plain spaces.
        A border style name → the corresponding vertical character, centred in the gap
        with spaces.

    All other parameters are identical to ``menu_1D``.
    """
    if not isinstance(items, list):
        raise TypeError(f"items must be a list, not {type(items).__name__}")

    cfg: Dict[str, Any] = {
        "color": color.upper(), "selection_type": selection_type, "moving": moving,
        "border": border, "wait_after_function": wait_after_function,
        "return_after_action": return_after_action, "enter_selector": enter_selector,
        "width": width, "height": height,
        "margin": margin, "margin_top": margin_top, "margin_right": margin_right,
        "margin_bottom": margin_bottom, "margin_left": margin_left,
        "padding": padding, "padding_top": padding_top, "padding_right": padding_right,
        "padding_bottom": padding_bottom, "padding_left": padding_left,
        "align": align, "gap": gap, "gap_fill": gap_fill,
    }

    rows: List[list] = [r if isinstance(r, list) else [r] for r in items]

    sel_in_row: Dict[int, List[int]] = {}
    sel_rows:   List[int]            = []
    for ri, row in enumerate(rows):
        if len(row) == 1 and isinstance(row[0], dict) and row[0].get("type") == "hr":
            continue
        sel_cols = [
            ci for ci, it in enumerate(row)
            if isinstance(it, tuple)
            or (isinstance(it, dict) and not it.get("disabled", False) and it.get("type") not in ("hr",))
        ]
        if sel_cols:
            sel_in_row[ri] = sel_cols; sel_rows.append(ri)

    if not sel_rows:
        for row in rows:
            print("  ".join(_render_item(it, False, cfg) for it in row))
        return

    row_sel      = 0
    col_sel      = 0
    scroll       = 0
    sel_active   = False
    sel_orig_idx = 0
    hide_cursor()

    def draw(sel_a: bool = False) -> Tuple[int, dict, int]:
        return _draw_2d(rows, sel_rows, sel_in_row, row_sel, col_sel, scroll, {**cfg, "_selector_active": sel_a})

    try:
        total, line_map, cw = draw()
        mv    = cfg["moving"]
        h_opt = cfg["height"]

        while True:
            key         = readchar.readkey()
            cur_row_idx = sel_rows[row_sel]
            sel_cols    = sel_in_row[cur_row_idx]
            cur_col_idx = sel_cols[col_sel]
            current     = rows[cur_row_idx][cur_col_idx]
            changed     = False

            # ── selector edit mode ────────────────────────────────────
            if sel_active:
                opts = current.get("options", [])
                if (key == readchar.key.LEFT  and mv in ["both","arrows"]) or (key.lower() == "a" and mv in ["both","wsad"]):
                    if opts: current["index"] = (current.get("index",0) - 1) % len(opts); changed = True
                elif (key == readchar.key.RIGHT and mv in ["both","arrows"]) or (key.lower() == "d" and mv in ["both","wsad"]):
                    if opts: current["index"] = (current.get("index",0) + 1) % len(opts); changed = True
                elif key == readchar.key.ENTER:
                    sel_active = False; changed = True
                elif key == readchar.key.ESC:
                    current["index"] = sel_orig_idx; sel_active = False; changed = True
                if changed: _clear_lines(total); total, line_map, cw = draw(sel_active)
                continue

            # ── navigation ────────────────────────────────────────────
            if (key.lower() == "w" and mv in ["both","wsad"]) or (key == readchar.key.UP    and mv in ["both","arrows"]):
                row_sel = (row_sel - 1) % len(sel_rows)
                col_sel = min(col_sel, len(sel_in_row[sel_rows[row_sel]]) - 1)
                changed = True
            elif (key.lower() == "s" and mv in ["both","wsad"]) or (key == readchar.key.DOWN  and mv in ["both","arrows"]):
                row_sel = (row_sel + 1) % len(sel_rows)
                col_sel = min(col_sel, len(sel_in_row[sel_rows[row_sel]]) - 1)
                changed = True

            elif (key == readchar.key.LEFT  and mv in ["both","arrows"]) or (key.lower() == "a" and mv in ["both","wsad"]):
                if len(sel_cols) > 1:
                    col_sel = (col_sel - 1) % len(sel_cols); changed = True
                elif isinstance(current, dict) and current.get("type") == "selector" and not _selector_needs_enter(current, cfg):
                    opts = current.get("options", [])
                    if opts: current["index"] = (current.get("index",0) - 1) % len(opts); changed = True
            elif (key == readchar.key.RIGHT and mv in ["both","arrows"]) or (key.lower() == "d" and mv in ["both","wsad"]):
                if len(sel_cols) > 1:
                    col_sel = (col_sel + 1) % len(sel_cols); changed = True
                elif isinstance(current, dict) and current.get("type") == "selector" and not _selector_needs_enter(current, cfg):
                    opts = current.get("options", [])
                    if opts: current["index"] = (current.get("index",0) + 1) % len(opts); changed = True

            elif key == readchar.key.ENTER:
                t = current.get("type") if isinstance(current, dict) else None
                if t == "checkbox":
                    current["checked"] = not current.get("checked", False)
                    _clear_lines(total); total, line_map, cw = draw()
                    continue
                elif t == "input":
                    total, line_map, cw = _inline_edit_2d(
                        current, cur_col_idx, cfg, total, line_map[cur_row_idx],
                        rows, sel_rows, sel_in_row, row_sel, col_sel, scroll, cw)
                elif t == "selector" and _selector_needs_enter(current, cfg):
                    sel_active = True; sel_orig_idx = current.get("index", 0); changed = True
                else:
                    action = current[1] if isinstance(current, tuple) else current.get("function")
                    if callable(action):
                        _clear_lines(total); show_cursor(); action()
                        if cfg["wait_after_function"]: readchar.readkey()
                        if cfg["return_after_action"]: break
                        hide_cursor(); total, line_map, cw = draw()
                continue

            elif key == readchar.key.ESC:
                break

            if changed and h_opt != "auto":
                idx = sel_rows[row_sel]; h = int(h_opt)
                if idx < scroll: scroll = idx
                elif idx >= scroll + h: scroll = idx - h + 1

            if changed:
                _clear_lines(total); total, line_map, cw = draw()

    finally:
        show_cursor()


# ══════════════════════════════════════════════════════
#  Example
# ══════════════════════════════════════════════════════
