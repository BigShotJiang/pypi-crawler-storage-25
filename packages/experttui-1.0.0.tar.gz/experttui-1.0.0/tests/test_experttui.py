"""
Unit tests for ExpertTUI — render layer (no real terminal required).
Run:  pytest
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from experttui import menu_1D, menu_2D
from experttui import (
    _visual_len, _truncate_ansi,
    _get_border, _get_junction, _gap_separator,
    _col_break_positions, _render_item, _render_action,
    _render_selector, _render_input, _render_checkbox,
    _render_hr_line, _column_widths, _render_row_2d,
    _resolve_sides, _affixes,
)


def _cfg(**ov):
    base = {
        "color": "YELLOW", "selection_type": "left_arrow",
        "moving": "both", "border": False, "width": "auto",
        "height": "auto", "enter_selector": False,
        "align": True, "gap": 2, "gap_fill": False,
        "margin": 0, "margin_top": None, "margin_right": None,
        "margin_bottom": None, "margin_left": None,
        "padding": 0, "padding_top": None, "padding_right": None,
        "padding_bottom": None, "padding_left": None,
    }
    base.update(ov)
    return base

def _pad():
    return {"left": 0, "right": 0, "top": 0, "bottom": 0}


# ── _visual_len ───────────────────────────────────────────────────────────────

def test_visual_len_plain():          assert _visual_len("hello") == 5
def test_visual_len_empty():          assert _visual_len("") == 0
def test_visual_len_strips_ansi():
    from colorama import Fore, Style
    assert _visual_len(Fore.RED + "hello" + Style.RESET_ALL) == 5


# ── _truncate_ansi ────────────────────────────────────────────────────────────

def test_truncate_no_op():            assert _truncate_ansi("hi", 10) == "hi"
def test_truncate_length():           assert _visual_len(_truncate_ansi("abcde", 3)) == 3
def test_truncate_ansi_preserved():
    from colorama import Fore, Style
    assert _visual_len(_truncate_ansi(Fore.GREEN + "hello" + Style.RESET_ALL, 3)) == 3


# ── _get_border ───────────────────────────────────────────────────────────────

def test_border_false():              assert _get_border(False) is None
def test_border_none():               assert _get_border(None) is None
def test_border_true_is_double():     assert _get_border(True)["tl"] == "╔"
def test_border_single():
    b = _get_border("single");        assert b["tl"] == "┌" and b["h"] == "─"
def test_border_rounded():            assert _get_border("rounded")["tl"] == "╭"
def test_border_heavy():              assert _get_border("heavy")["h"] == "━"
def test_border_block():              assert _get_border("block")["h"] == "█"
def test_border_unknown_fallback():   assert _get_border("xyz")["tl"] == "╔"


# ── _get_junction ─────────────────────────────────────────────────────────────

def test_junction_single():           assert _get_junction("│", "─") == ("├", "┤")
def test_junction_double():           assert _get_junction("║", "═") == ("╠", "╣")
def test_junction_fallback():
    lj, rj = _get_junction("X", "Y");  assert lj == rj == "X"


# ── _gap_separator ────────────────────────────────────────────────────────────

def test_gap_false():                 assert _gap_separator(False, 3) == "   "
def test_gap_zero():                  assert _gap_separator("single", 0) == ""
def test_gap_1():                     assert _gap_separator("single", 1) == "│"
def test_gap_block():                 assert _gap_separator("block", 4) == "████"
def test_gap_correct_length():
    for n in range(1, 8):
        assert len(_gap_separator("single", n)) == n


# ── _col_break_positions ──────────────────────────────────────────────────────

def test_breaks_no_fill():            assert _col_break_positions([10,12], 3, False) == []
def test_breaks_single_col_row():
    # one single-col row → no breaks
    assert _col_break_positions([10,12], 3, "single", [["A"],["A","B"]]) == []
def test_breaks_all_two_col():
    rows = [["A","B"],["C","D"]]
    breaks = _col_break_positions([10,12], 3, "single", rows)
    assert len(breaks) == 1 and breaks[0] == 10 + (3-1)//2
def test_breaks_no_rows():
    assert _col_break_positions([10,12], 3, "single", []) == []


# ── _resolve_sides ────────────────────────────────────────────────────────────

def test_resolve_base():
    m = _resolve_sides(_cfg(margin=2), "margin")
    assert m == {"top":2,"right":2,"bottom":2,"left":2}
def test_resolve_override():
    m = _resolve_sides(_cfg(margin=2, margin_left=0), "margin")
    assert m["left"] == 0 and m["top"] == 2
def test_resolve_zero():
    p = _resolve_sides(_cfg(padding=0), "padding")
    assert all(v == 0 for v in p.values())


# ── _affixes ──────────────────────────────────────────────────────────────────

def test_affixes_left():  assert _affixes("left_arrow")  == ("> ", "  ")
def test_affixes_two():   assert _affixes("two_arrows")  == ("< ", " >")


# ── _render_item dispatch ─────────────────────────────────────────────────────

def test_render_string():         assert _render_item("Hello", False, _cfg()) == "Hello"
def test_render_hr_placeholder(): assert _render_item({"type":"hr"}, False, _cfg()) == ""
def test_render_tuple_contains():
    r = _render_item(("Opt", lambda: None), False, _cfg())
    assert "Opt" in r


# ── _render_action ────────────────────────────────────────────────────────────

def test_action_disabled():
    r = _render_action({"text":"Locked","disabled":True}, False, _cfg())
    assert "Locked" in r
def test_action_selected():
    r = _render_action({"text":"Go"}, True, _cfg()); assert "Go" in r
def test_action_not_selected():
    r = _render_action({"text":"Go"}, False, _cfg()); assert "Go" in r


# ── _render_selector ─────────────────────────────────────────────────────────

SEL = {"type":"selector","text":"Q","options":["A","B"],"index":0}

def test_selector_not_selected():
    r = _render_selector(SEL, False, _cfg()); assert "A" in r and "Q" in r
def test_selector_selected_arrow():
    r = _render_selector(SEL, True,  _cfg()); assert "<" in r
def test_selector_active_bracket():
    r = _render_selector(SEL, True,  {**_cfg(),"_selector_active":True})
    assert "[" in r
def test_selector_equal_width():
    s = _visual_len(_render_selector(SEL, True,  _cfg()))
    u = _visual_len(_render_selector(SEL, False, _cfg()))
    assert s == u
def test_selector_truncates_at_fixed_width():
    it = {"type":"selector","text":"X","options":["VeryLongValue"],"index":0}
    r  = _render_selector(it, True, _cfg(width=10))
    assert _visual_len(r) <= 18   # some tolerance for ANSI codes


# ── _render_input ─────────────────────────────────────────────────────────────

def test_input_value():
    it = {"type":"input","text":"N","value":"Alice","placeholder":"…"}
    assert "Alice" in _render_input(it, True, _cfg())
def test_input_placeholder():
    it = {"type":"input","text":"N","value":"","placeholder":"hint"}
    assert "hint" in _render_input(it, True, _cfg())
def test_input_equal_width():
    it = {"type":"input","text":"N","value":"X","placeholder":"Y"}
    assert (_visual_len(_render_input(it, True,  _cfg())) ==
            _visual_len(_render_input(it, False, _cfg())))


# ── _render_checkbox ─────────────────────────────────────────────────────────

def test_checkbox_checked():
    it = {"type":"checkbox","text":"M","checked":True}
    assert "[x]" in _render_checkbox(it, False, _cfg())
def test_checkbox_unchecked():
    it = {"type":"checkbox","text":"M","checked":False}
    assert "[ ]" in _render_checkbox(it, False, _cfg())
def test_checkbox_same_width():
    on  = {"type":"checkbox","text":"SFX","checked":True}
    off = {"type":"checkbox","text":"SFX","checked":False}
    assert (_visual_len(_render_checkbox(on,  True,  _cfg())) ==
            _visual_len(_render_checkbox(off, True,  _cfg())))
    assert (_visual_len(_render_checkbox(on,  False, _cfg())) ==
            _visual_len(_render_checkbox(off, False, _cfg())))


# ── _render_hr_line ───────────────────────────────────────────────────────────

def test_hr_no_border():
    r = _render_hr_line({}, 10, _pad(), None, "", _cfg())
    assert "─" in r and len(r) == 10
def test_hr_with_border():
    bc = _get_border("single")
    r  = _render_hr_line({}, 10, _pad(), bc, "", _cfg(border="single"))
    assert r.startswith("├") and r.endswith("┤")
def test_hr_with_label():
    r = _render_hr_line({"label":"Hi"}, 20, _pad(), None, "", _cfg())
    assert "Hi" in r and len(r) == 20
def test_hr_custom_fill():
    r = _render_hr_line({"fill":"double"}, 8, _pad(), None, "", _cfg())
    assert "═" in r
def test_hr_cross_junction():
    bc = _get_border("single")
    r  = _render_hr_line({}, 12, _pad(), bc, "",
                         _cfg(border="single", gap_fill="single"),
                         col_breaks=[5])
    assert "┼" in r


# ── _column_widths ────────────────────────────────────────────────────────────

def test_colwidths_empty():    assert _column_widths([], _cfg()) == []
def test_colwidths_one_col():
    rows = [["Alpha"],["Bravo"]]
    w = _column_widths(rows, _cfg())
    assert len(w) == 1 and w[0] >= _visual_len("Alpha")   # +prefix
def test_colwidths_two_cols():
    rows = [["Short","Longer"],["Med","X"]]
    w = _column_widths(rows, _cfg())
    assert len(w) == 2 and w[1] >= _visual_len("Longer")


# ── _render_row_2d ────────────────────────────────────────────────────────────

def test_row_two_cols():
    r = _render_row_2d(["Hello","World"], -1, None, _cfg())
    assert "Hello" in r and "World" in r
def test_row_gap_spaces():
    r = _render_row_2d(["A","B"], -1, None, _cfg(gap=3, gap_fill=False))
    assert "   " in r
def test_row_gap_fill_char():
    r = _render_row_2d(["A","B"], -1, None, _cfg(gap=3, gap_fill="single"))
    assert "│" in r


# ── Public API smoke tests ────────────────────────────────────────────────────

def test_menu1d_static_only(capsys):
    menu_1D(["line one", "line two"])
    out = capsys.readouterr().out
    assert "line one" in out and "line two" in out

def test_menu2d_static_only(capsys):
    menu_2D(["header", "footer"])
    out = capsys.readouterr().out
    assert "header" in out

def test_menu1d_type_error():
    with pytest.raises(TypeError): menu_1D("not a list")

def test_menu2d_type_error():
    with pytest.raises(TypeError): menu_2D({"not": "a list"})
