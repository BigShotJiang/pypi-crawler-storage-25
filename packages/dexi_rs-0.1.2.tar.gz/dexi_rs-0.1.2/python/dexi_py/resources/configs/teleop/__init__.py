"""Teleoperation vector and DexPilot configs."""
