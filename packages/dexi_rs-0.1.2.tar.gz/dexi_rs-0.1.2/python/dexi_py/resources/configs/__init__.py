"""Packaged retargeting YAML configs."""
