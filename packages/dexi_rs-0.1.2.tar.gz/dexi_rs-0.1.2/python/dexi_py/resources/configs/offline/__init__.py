"""Offline position-retargeting configs."""
