"""Packaged dexi resources."""
