"""Packaged runtime assets."""
