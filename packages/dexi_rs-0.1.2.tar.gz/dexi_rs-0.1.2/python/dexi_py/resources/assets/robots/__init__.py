"""Packaged robot assets."""
