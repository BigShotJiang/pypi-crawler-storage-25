"""Packaged robot hand URDF assets."""
