# Notifications — Remote Commands and Troubleshooting

Remote commands (Slack / Telegram), what gets notified, the credentials reference, troubleshooting, and known caveats. See [Channel Setup](19a-notifications-channels.md) for the per-channel setup walkthroughs.

## Remote Commands

When Urika is running with a project loaded, Slack and Telegram become interactive -- you can send commands and get responses.

### How it works

1. Launch Urika: `urika`
2. Load a project: `/project my-study`
3. The bot starts listening
4. Send commands from Telegram/Slack
5. Bot responds with results
6. Bot stops when you exit Urika or switch projects

### Available commands

Type `/help` in Telegram/Slack to see all commands. Type `/help <command>` for details on a specific command.

**Always available (instant response):**

| Command | Description |
|---------|-------------|
| `/status` | Project overview -- experiments, runs, completion state |
| `/results` | Leaderboard -- top methods ranked by primary metric |
| `/methods` | Last 10 registered methods with status and metrics |
| `/criteria` | Current success criteria |
| `/experiments` | Last 10 experiments with status and run counts |
| `/logs` | Last 5 run logs from the most recent experiment |
| `/usage` | Token counts, cost, agent calls |
| `/help` | List all commands (or `/help run` for details on a specific command) |

**Run control (during active run):**

| Command | Description |
|---------|-------------|
| `/pause` | Pause after the current turn completes |
| `/stop` | Stop immediately and clear queued commands |
| `/resume` | Resume a paused or stopped experiment |

**Agent commands (run when idle, queued when busy):**

| Command | Description |
|---------|-------------|
| `/run` | Start an experiment (default settings) |
| `/advisor <question>` | Ask the advisor a question |
| `/evaluate` | Run the evaluator on the most recent experiment |
| `/plan` | Run the planning agent |
| `/report` | Generate a report |
| `/present` | Generate a presentation |
| `/finalize` | Run the finalizer |
| `/build-tool <description>` | Create a custom tool |

Agent commands take time to complete (seconds to minutes). You'll get a message like "Running /advisor (thinking -- may take a few minutes)..." followed by the result when it's ready.

If an agent is already running, your command is queued and runs automatically when the current one finishes. `/stop` clears the queue.

### Commands not available remotely

These require interactive terminal input: `/new`, `/project`, `/config`, `/notifications`, `/update`, `/inspect`, `/knowledge`, `/quit`.

### When the bot is offline

The bot only listens when Urika is running with a project loaded. If you send a command while Urika is closed, the bot won't respond. Launch Urika and load the project to bring the bot online.

All remote commands are shown in the TUI terminal with a `[Remote]` tag so you can see what's happening.


## What Gets Notified

Notifications are experiment-level only -- no per-turn noise. You get notified at key milestones:

| Event | When | What you see |
|-------|------|-------------|
| Experiment started | New experiment created (autonomous mode) | Name and description |
| Criteria met | Evaluator says success criteria satisfied | Criteria met message |
| Experiment completed | After reports generated | Runs, methods, best result (e.g. "5 runs, 3 methods. Best: random_forest r2=82.3%") |
| Experiment failed | Agent error | Error details |
| Paused | ESC or remote `/pause` | Turn count and current results |
| Stopped | Ctrl+C or remote `/stop` | Turn count and current results |


## Credentials and Security

- **All tokens and passwords are stored in `~/.urika/secrets.env`** (file permissions: owner-read-only). They are never written to config files.
- You can also set credentials as regular environment variables -- these take precedence over `secrets.env`.
- **Remote commands use the same PauseController as the local ESC key** -- they don't bypass any security boundaries.
- **Notification failures never block experiments.** If email/Slack/Telegram is down, the experiment continues normally. Errors are logged.


## Configuration Reference

### Global settings (`~/.urika/settings.toml`)

Channel configuration -- shared across all projects:

```toml
[notifications.email]
smtp_server = "smtp.gmail.com"
smtp_port = 587
from_addr = "you@gmail.com"
username = "you@gmail.com"
to = ["you@gmail.com", "team@lab.edu"]
password_env = "URIKA_EMAIL_PASSWORD"

[notifications.slack]
channel = "#urika-results"
bot_token_env = "SLACK_BOT_TOKEN"
app_token_env = "SLACK_APP_TOKEN"

[notifications.telegram]
chat_id = "123456789"
bot_token_env = "TELEGRAM_BOT_TOKEN"
```

### Project settings (`urika.toml`)

Select which channels to enable and optional overrides:

```toml
[notifications]
channels = ["email", "telegram"]

# Optional: extra email recipients for this project
[notifications.email]
to = ["collaborator@university.edu"]

# Optional: different Telegram group for this project
[notifications.telegram]
chat_id = "-100999888"
```

### Credential store (`~/.urika/secrets.env`)

```
URIKA_EMAIL_PASSWORD=xxxx xxxx xxxx xxxx
SLACK_BOT_TOKEN=xoxb-...
SLACK_APP_TOKEN=xapp-...
TELEGRAM_BOT_TOKEN=123456789:ABC...
```

## Troubleshooting

When a channel isn't delivering, the dashboard's **Send test notification** button
on Settings → Notifications is the fastest diagnostic — it sends one event
through every configured channel and reports per-channel success or the
specific error message returned by the channel's SDK.

For each channel, the most common failures are:

### Email

| Symptom | Likely cause | Fix |
|---|---|---|
| `Authentication failed (535)` | App password wrong or 2FA app password not generated | Regenerate the Google / Outlook app password and update `SMTP_PASSWORD` |
| `[Errno 111] Connection refused` | SMTP host or port wrong | Verify host (`smtp.gmail.com` for Gmail; `smtp.office365.com` for Outlook) and port (587 for STARTTLS) |
| `getaddrinfo failed` | Hostname typo, DNS issue | Verify the SMTP host string |
| `STARTTLS extension not supported` | Server requires SSL not TLS | Switch to port 465 with SSL — currently Urika uses STARTTLS only; file an issue if you need SSL |
| Tests pass but no email arrives | Mail filter, wrong `to` address | Check spam folder; verify `to` field |

### Slack

| Symptom | Likely cause | Fix |
|---|---|---|
| `invalid_auth` | Bot token revoked or wrong env var | Re-issue the bot token in your Slack app settings; update the env var |
| `not_in_channel` | Bot was never invited to the channel | In Slack, run `/invite @YourBotName` in the channel |
| `channel_not_found` | Wrong channel name or private channel without access | Verify channel name; bot must be a member of private channels |
| Inbound commands don't work | App token (Socket Mode) not configured | Set `SLACK_APP_TOKEN` env var and the **App token env var** field on the dashboard; ensure Socket Mode is enabled in app settings |
| `missing_scope` | Bot missing OAuth scope | Add `chat:write`, `chat:write.public`, and `app_mentions:read` scopes; reinstall app |

### Telegram

| Symptom | Likely cause | Fix |
|---|---|---|
| `Unauthorized` / `InvalidToken` | Bot token wrong or revoked | Get a fresh token from @BotFather |
| `chat not found` | Wrong chat ID or bot never messaged the chat | Open the chat with the bot and send `/start`; re-fetch the chat ID via `getUpdates` |
| `Forbidden: bot was blocked by the user` | User blocked the bot | Unblock in Telegram client |
| Inline buttons don't respond | Polling stopped after error | Check Urika logs; restart Urika to re-establish polling |

### General diagnostics

- **No notifications at all:** confirm the project's `notifications` config has at least one channel set to `enabled = true` (`urika notifications --show` or the project's Notifications tab).
- **Some events deliver, others don't:** Slack and Telegram apply per-event-type formatting based on the canonical event vocabulary. Unknown event types fall through to a default ℹ icon — if you're seeing the default icon for events that should have specific formatting, check `urika.toml` for stale event-type strings.
- **Channel logs as "failed health check" at startup:** the channel's auth probe failed before any event was sent. The bus excludes failing channels from dispatch — fix the credential issue and restart Urika.

## Caveats

A few behaviours worth knowing about up front:

- **Pause / Stop / Resume buttons (Telegram inline keyboard) only appear on `experiment_started` events.** Mid-experiment notifications don't carry the keyboard — for fine-grained control during an active run, use the bot's `/pause`, `/stop`, `/resume` slash commands directly.
- **Email batches low-priority events.** Events with `priority="low"` are queued and flushed only when a `medium` or `high` event arrives, or at shutdown. This avoids inbox flooding for routine progress events. Slack and Telegram do not batch — every event sends immediately.
- **Per-channel priority filtering is not yet user-configurable.** Today, every enabled channel receives every event the bus emits.
- **Health check on bad credentials excludes a channel from dispatch for the entire process lifetime.** Updating credentials in env vars does NOT re-probe the running bus — restart Urika so the next `bus.start()` re-runs the health check. The dashboard's Send-test button builds a fresh bus from un-saved form data and probes each channel directly, so use it to confirm fixes before restarting.
- **Test sends count toward your channel's rate limits.** Slack rate-limits ~1 message/sec/channel; Telegram rate-limits ~30 messages/sec; Gmail rate-limits ~100/day on free SMTP. Don't spam the test button.
- **Inbound Slack commands require Socket Mode + an app token in addition to the bot token.** Outbound notifications work with just the bot token; inbound (slash commands, button taps) needs the app-token env var set.
- **`experiment_paused` and `paused` are different events.** `experiment_paused` is end-of-experiment ("the entire experiment was paused after turn N"). `paused` is a generic mid-loop pause (e.g., autonomous-mode pause between experiments). Both are notified separately so you can wire them differently if needed.

---

**Next:** [Security Model](20-security.md)


## See also

- [Notifications — Channel Setup](19a-notifications-channels.md)
- [CLI Reference](16a-cli-projects.md)
- [Configuration](14b-global-config.md)
- [Dashboard — Settings](18c-dashboard-settings.md)
