"""
Code execution sandbox — supports Daytona and E2B providers.

Provides a thin wrapper for running AI-generated code in isolated
containers. Any agent or MCP tool can use this to execute code safely.

Provider selection:
    SANDBOX_PROVIDER=daytona  → uses Daytona SDK (default when DAYTONA_API_KEY set)
    SANDBOX_PROVIDER=e2b      → uses E2B Code Interpreter

Usage:
    from sandbox import run_code, run_code_with_files

    result = run_code("print('hello')")
    print(result["stdout"])
"""

import contextlib
import logging
import os

logger = logging.getLogger("sandbox")

_PROVIDER = os.getenv("SANDBOX_PROVIDER", "").lower()


def _get_provider() -> str:
    """Determine which sandbox provider to use."""
    if _PROVIDER == "daytona":
        return "daytona"
    if _PROVIDER == "e2b":
        return "e2b"
    # Auto-detect: prefer Daytona if key is set
    if os.getenv("DAYTONA_API_KEY"):
        return "daytona"
    if os.getenv("E2B_API_KEY"):
        return "e2b"
    return "none"


def is_available() -> bool:
    """Check if any sandbox provider is configured."""
    return _get_provider() != "none"


def _extract_daytona_artifacts(response) -> list[dict]:
    """Extract rich outputs from a Daytona ExecuteResponse."""
    results = []
    if not hasattr(response, "artifacts") or not response.artifacts:
        return results
    arts = response.artifacts
    # artifacts.charts is a list[Chart] | None
    if hasattr(arts, "charts") and arts.charts:
        for chart in arts.charts:
            if hasattr(chart, "png") and chart.png:
                results.append({"type": "png", "value": chart.png})
            elif hasattr(chart, "html") and chart.html:
                results.append({"type": "html", "value": chart.html})
    return results


# ─── Daytona Provider ────────────────────────────────────────────────────


def _run_code_daytona(
    code: str,
    language: str = "python",
    timeout: int = 30,
    packages: list[str] | None = None,
    envs: dict[str, str] | None = None,
) -> dict:
    """Execute code in a Daytona sandbox."""
    from daytona import CreateSandboxBaseParams, Daytona

    daytona = Daytona()
    sandbox = daytona.create(
        CreateSandboxBaseParams(
            language=language,
            env_vars=envs or {},
            ephemeral=True,
        )
    )

    try:
        # Install packages
        if packages:
            pkg_list = " ".join(packages)
            if language == "javascript":
                install_result = sandbox.process.exec(f"npm install {pkg_list}", timeout=60)
            else:
                install_result = sandbox.process.exec(f"pip install -q {pkg_list}", timeout=60)
            if install_result.exit_code != 0:
                logger.warning("Package install failed: %s", install_result.result[:200])

        # Execute code
        response = sandbox.process.code_run(code, timeout=timeout)

        stdout = response.result or ""
        error = None
        exit_code = response.exit_code

        # Daytona combines stdout/stderr — extract stderr on error
        stderr = ""
        if exit_code != 0:
            # On failure, result often contains the traceback
            error = stdout
            # Try to separate stderr from stdout
            if "Traceback" in stdout:
                parts = stdout.split("Traceback", 1)
                stderr = "Traceback" + parts[1] if len(parts) > 1 else ""
                stdout = parts[0] if len(parts) > 1 else ""

        # Collect rich results from artifacts
        results = _extract_daytona_artifacts(response)

        return {
            "stdout": stdout,
            "stderr": stderr,
            "error": error,
            "exit_code": exit_code,
            "results": results,
        }

    except Exception as e:
        return {
            "stdout": "",
            "stderr": str(e),
            "error": str(e),
            "exit_code": 1,
            "results": [],
        }
    finally:
        with contextlib.suppress(Exception):
            sandbox.stop()  # ephemeral sandboxes auto-delete on stop
            logger.debug("Daytona sandbox stopped")


def _run_code_with_files_daytona(
    code: str,
    files: dict[str, str | bytes] | None = None,
    language: str = "python",
    timeout: int = 30,
    packages: list[str] | None = None,
) -> dict:
    """Execute code with pre-uploaded files in a Daytona sandbox."""
    from daytona import CreateSandboxBaseParams, Daytona

    daytona = Daytona()
    sandbox = daytona.create(
        CreateSandboxBaseParams(
            language=language,
            ephemeral=True,
        )
    )

    try:
        # Upload files
        if files:
            for path, content in files.items():
                if isinstance(content, str):
                    content = content.encode("utf-8")
                sandbox.fs.upload_file(content, path)

        # Install packages
        if packages:
            pkg_list = " ".join(packages)
            if language == "javascript":
                sandbox.process.exec(f"npm install {pkg_list}", timeout=60)
            else:
                sandbox.process.exec(f"pip install -q {pkg_list}", timeout=60)

        # Execute
        response = sandbox.process.code_run(code, timeout=timeout)

        stdout = response.result or ""
        stderr = ""
        error = None
        exit_code = response.exit_code

        if exit_code != 0:
            error = stdout
            if "Traceback" in stdout:
                parts = stdout.split("Traceback", 1)
                stderr = "Traceback" + parts[1] if len(parts) > 1 else ""
                stdout = parts[0] if len(parts) > 1 else ""

        results = _extract_daytona_artifacts(response)

        return {
            "stdout": stdout,
            "stderr": stderr,
            "error": error,
            "exit_code": exit_code,
            "results": results,
        }

    except Exception as e:
        return {
            "stdout": "",
            "stderr": str(e),
            "error": str(e),
            "exit_code": 1,
            "results": [],
        }
    finally:
        with contextlib.suppress(Exception):
            sandbox.stop()
            logger.debug("Daytona sandbox stopped")


# ─── E2B Provider (fallback) ─────────────────────────────────────────────


def _run_code_e2b(
    code: str,
    language: str = "python",
    timeout: int = 30,
    packages: list[str] | None = None,
    envs: dict[str, str] | None = None,
) -> dict:
    """Execute code in an E2B sandbox."""
    from e2b_code_interpreter import Sandbox

    sbx = Sandbox.create(timeout=max(timeout + 30, 60), envs=envs)

    try:
        if packages:
            pkg_list = " ".join(packages)
            if language == "javascript":
                sbx.commands.run(f"npm install {pkg_list}", timeout=60)
            else:
                sbx.commands.run(f"pip install -q {pkg_list}", timeout=60)

        execution = sbx.run_code(code, timeout=timeout)

        stdout = "".join(execution.logs.stdout) if execution.logs.stdout else ""
        stderr = "".join(execution.logs.stderr) if execution.logs.stderr else ""

        results = []
        if execution.results:
            for r in execution.results:
                if hasattr(r, "text") and r.text:
                    results.append({"type": "text", "value": r.text})
                if hasattr(r, "png") and r.png:
                    results.append({"type": "png", "value": r.png})
                if hasattr(r, "html") and r.html:
                    results.append({"type": "html", "value": r.html})

        error = None
        if execution.error:
            error = f"{execution.error.name}: {execution.error.value}\n{execution.error.traceback}"

        return {
            "stdout": stdout,
            "stderr": stderr,
            "error": error,
            "exit_code": 0 if not execution.error else 1,
            "results": results,
        }

    except Exception as e:
        return {
            "stdout": "",
            "stderr": str(e),
            "error": str(e),
            "exit_code": 1,
            "results": [],
        }
    finally:
        with contextlib.suppress(Exception):
            sbx.kill()
            logger.debug("E2B sandbox killed")


def _run_code_with_files_e2b(
    code: str,
    files: dict[str, str | bytes] | None = None,
    language: str = "python",
    timeout: int = 30,
    packages: list[str] | None = None,
) -> dict:
    """Execute code with pre-uploaded files in an E2B sandbox."""
    from e2b_code_interpreter import Sandbox

    sbx = Sandbox.create(timeout=max(timeout + 60, 90))

    try:
        if files:
            for path, content in files.items():
                if isinstance(content, str):
                    content = content.encode("utf-8")
                sbx.files.write(path, content)

        if packages:
            pkg_list = " ".join(packages)
            if language == "javascript":
                sbx.commands.run(f"npm install {pkg_list}", timeout=60)
            else:
                sbx.commands.run(f"pip install -q {pkg_list}", timeout=60)

        execution = sbx.run_code(code, timeout=timeout)

        stdout = "".join(execution.logs.stdout) if execution.logs.stdout else ""
        stderr = "".join(execution.logs.stderr) if execution.logs.stderr else ""

        results = []
        if execution.results:
            for r in execution.results:
                if hasattr(r, "text") and r.text:
                    results.append({"type": "text", "value": r.text})
                if hasattr(r, "png") and r.png:
                    results.append({"type": "png", "value": r.png})

        error = None
        if execution.error:
            error = f"{execution.error.name}: {execution.error.value}\n{execution.error.traceback}"

        return {
            "stdout": stdout,
            "stderr": stderr,
            "error": error,
            "exit_code": 0 if not execution.error else 1,
            "results": results,
        }

    except Exception as e:
        return {
            "stdout": "",
            "stderr": str(e),
            "error": str(e),
            "exit_code": 1,
            "results": [],
        }
    finally:
        with contextlib.suppress(Exception):
            sbx.kill()
            logger.debug("E2B sandbox killed")


# ─── Public API (unchanged interface) ────────────────────────────────────


def run_code(
    code: str,
    language: str = "python",
    timeout: int = 30,
    packages: list[str] | None = None,
    envs: dict[str, str] | None = None,
) -> dict:
    """Execute code in an isolated sandbox.

    Dispatches to Daytona or E2B based on SANDBOX_PROVIDER env var.

    Args:
        code: Source code to execute
        language: "python" or "javascript" (default: python)
        timeout: Max execution time in seconds (default: 30)
        packages: Pip/npm packages to install before running
        envs: Environment variables for the sandbox

    Returns:
        {
            "stdout": str,
            "stderr": str,
            "error": str | None,
            "exit_code": int,
            "results": list,  # rich outputs (plots, dataframes, etc.)
        }
    """
    provider = _get_provider()
    logger.debug("Running code with provider: %s", provider)

    if provider == "daytona":
        return _run_code_daytona(code, language, timeout, packages, envs)
    if provider == "e2b":
        return _run_code_e2b(code, language, timeout, packages, envs)

    return {
        "stdout": "",
        "stderr": "No sandbox provider configured. Set DAYTONA_API_KEY or E2B_API_KEY.",
        "error": "No sandbox provider configured",
        "exit_code": 1,
        "results": [],
    }


def run_code_with_files(
    code: str,
    files: dict[str, str | bytes] | None = None,
    language: str = "python",
    timeout: int = 30,
    packages: list[str] | None = None,
) -> dict:
    """Execute code with pre-uploaded files in an isolated sandbox.

    Args:
        code: Source code to execute
        files: Dict of {path: content} to write before execution
        language: "python" or "javascript"
        timeout: Max execution time in seconds
        packages: Packages to install

    Returns: Same as run_code()
    """
    provider = _get_provider()
    logger.debug("Running code with files using provider: %s", provider)

    if provider == "daytona":
        return _run_code_with_files_daytona(code, files, language, timeout, packages)
    if provider == "e2b":
        return _run_code_with_files_e2b(code, files, language, timeout, packages)

    return {
        "stdout": "",
        "stderr": "No sandbox provider configured. Set DAYTONA_API_KEY or E2B_API_KEY.",
        "error": "No sandbox provider configured",
        "exit_code": 1,
        "results": [],
    }
