#!/usr/bin/env python3
"""
End-to-end check: fetch Wikipedia plain text → vector_store_add chunks → vector_store_search.

Run from repo root:
  python3 vending_machine_mcp/tests/e2e_vector_store_wikipedia.py

Uses a temporary SQLite file (VECTOR_STORE_DB) so it does not touch ~/.local/share.
No API keys required (local hash embeddings); with VOYAGE/OpenAI/Gemini keys the
same code path runs provider embeddings.
"""

from __future__ import annotations

import asyncio
import json
import os
import re
import sys
import tempfile
import urllib.parse
import urllib.request


BAKED_SQLITE_EXCERPT = """
SQLite is a C-language library that implements a small, fast, self-contained,
high-reliability, full-featured SQL database engine. SQLite is built into all
mobile phones and most computers and comes bundled with countless applications.
The SQLite file format is stable, cross-platform, and backwards compatible.
Developers claim it to be the most widely deployed database engine in the world.

The embedded relational database engine stores data in a single file. It supports
transactions, indexes, and triggers. Applications link against SQLite as a library
rather than talking to a separate database server process.
""".strip()


def _wiki_api_url(title: str) -> str:
    params = urllib.parse.urlencode(
        {
            "action": "query",
            "format": "json",
            "prop": "extracts",
            "explaintext": "1",
            "titles": title,
        }
    )
    return f"https://en.wikipedia.org/w/api.php?{params}"


def _fetch_wikipedia_extract(title: str) -> str:
    """MediaWiki API: plain-text extract (no HTML)."""
    url = _wiki_api_url(title)
    headers = {
        "User-Agent": "VendaVectorStoreE2E/1.0 (https://github.com/YokiiDesu/Vending-Machine; educational test)",
    }
    req = urllib.request.Request(url, headers=headers)

    # Prefer certifi CA bundle when urllib fails (common on macOS Python.org builds).
    try:
        import ssl

        try:
            import certifi

            ctx = ssl.create_default_context(cafile=certifi.where())
            with urllib.request.urlopen(req, timeout=45, context=ctx) as resp:
                data = json.loads(resp.read().decode())
        except ImportError:
            with urllib.request.urlopen(req, timeout=45) as resp:
                data = json.loads(resp.read().decode())
    except Exception:
        import subprocess

        curl = subprocess.run(
            ["curl", "-fsSL", "-A", headers["User-Agent"], url],
            capture_output=True,
            text=True,
            timeout=60,
        )
        if curl.returncode != 0:
            raise RuntimeError(curl.stderr or "curl failed") from None
        data = json.loads(curl.stdout)

    pages = data.get("query", {}).get("pages", {})
    page = next(iter(pages.values()))
    if "missing" in page:
        raise RuntimeError(f"Wikipedia page not found: {title!r}")
    return (page.get("extract") or "").strip()


def _fetch_text_with_fallback(title: str) -> tuple[str, str]:
    """Return (text, source_label)."""
    try:
        return _fetch_wikipedia_extract(title), "wikipedia-api"
    except Exception as e:
        print(f"WARN: live Wikipedia fetch failed ({e}); using baked-in excerpt for vector E2E.")
        return BAKED_SQLITE_EXCERPT, "baked-in"


def _paragraph_chunks(text: str, max_chunks: int = 12, max_chars: int = 1500) -> list[str]:
    parts = [p.strip() for p in re.split(r"\n{2,}", text) if p.strip()]
    chunks: list[str] = []
    for p in parts:
        if len(p) > max_chars:
            for i in range(0, len(p), max_chars):
                chunks.append(p[i : i + max_chars])
        else:
            chunks.append(p)
        if len(chunks) >= max_chunks:
            break
    return chunks


async def main() -> int:
    fd, db_path = tempfile.mkstemp(suffix=".sqlite3")
    os.close(fd)
    os.unlink(db_path)  # vector_store will create the file
    os.environ["VECTOR_STORE_DB"] = db_path

    # Import after VECTOR_STORE_DB is set
    pkg = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if pkg not in sys.path:
        sys.path.insert(0, pkg)

    import vector_store as vs  # noqa: E402

    title = "SQLite"
    print(f"Fetching text for {title!r} (Wikipedia API or fallback) …")
    extract, source = _fetch_text_with_fallback(title)
    if len(extract) < 200:
        print("ERROR: extract too short")
        return 1
    print(f"Got {len(extract)} chars from {source}.")

    chunks = _paragraph_chunks(extract)
    print(f"Split into {len(chunks)} chunk(s) for indexing.")
    collection = "e2e-wikipedia-sqlite"

    for i, chunk in enumerate(chunks):
        msg = await vs.add_document(collection, chunk, doc_id=f"para-{i}", metadata={"title": title, "chunk": i})
        if msg.startswith("Error"):
            print("add_document:", msg)
            return 1

    # Query that should match stored content semantically (or lexically overlap for local hash)
    query = "embedded relational database engine"
    print(f"\nSearching for: {query!r} …")
    out = await vs.search(collection, query, limit=5)
    print(out)

    if "No matches" in out or "Error:" in out:
        print("\nE2E FAILED: search returned no usable results.")
        return 1

    # Parse top score line if present
    if "score=" not in out:
        print("\nE2E FAILED: unexpected search output shape.")
        return 1

    print("\nE2E OK: documents indexed and search returned scored results.")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
