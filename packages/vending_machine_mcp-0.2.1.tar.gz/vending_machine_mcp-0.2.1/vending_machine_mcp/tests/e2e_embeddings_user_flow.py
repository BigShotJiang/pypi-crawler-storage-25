#!/usr/bin/env python3
"""
End-to-end embedding paths as an end user would hit them after `pip install`:

1. Script marketplace: seed → embed_query → search_scripts (same as `search_scripts` tool).
2. Personal KB: vector_store_add → vector_store_search (collection first, then query).

Uses temporary SQLite files so ~/.local/share is untouched.

Run from repo:
  python3 vending_machine_mcp/tests/e2e_embeddings_user_flow.py

With no embedding API keys, both paths use deterministic local hash (dim=256).
If VOYAGE/OpenAI/Gemini keys are in the environment, the same code uses those providers;
dimensions must match between index and query (do not mix providers without re-indexing).
"""

from __future__ import annotations

import asyncio
import os
import sys
import tempfile


def _pkg_dir() -> str:
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _configure_isolated_dbs(tmpdir: str) -> None:
    os.environ["SCRIPT_INDEX_DB_PATH"] = os.path.join(tmpdir, "script_index.sqlite3")
    os.environ["VECTOR_STORE_DB"] = os.path.join(tmpdir, "vector_store.sqlite3")


def _clear_embedding_keys() -> None:
    """Reproducible local-hash run; comment out to exercise real providers."""
    for k in (
        "VOYAGE_API_KEY",
        "OPENAI_API_KEY",
        "GEMINI_API_KEY",
        "GOOGLE_API_KEY",
    ):
        os.environ.pop(k, None)


async def _tool_search_scripts(query: str) -> str:
    """Same logic as mcp_server.search_scripts (graph path only)."""
    from graph import embed_query as _embed_query
    from graph import is_available as _graph_available
    from graph import search_scripts as _graph_search

    if not _graph_available():
        return "graph unavailable"
    query_embedding = _embed_query(query)
    results = _graph_search(query_embedding, limit=5)
    if not results:
        return "no graph results"
    lines = [f'Search results for "{query}":']
    for r in results:
        lines.append(f"  {r['vendingCode']} — {r['name']}  score={r['score']:.4f}")
    return "\n".join(lines)


def main() -> None:
    tmpdir = tempfile.mkdtemp(prefix="vm-mcp-e2e-")
    _configure_isolated_dbs(tmpdir)
    _clear_embedding_keys()

    pkg = _pkg_dir()
    sys.path.insert(0, pkg)
    os.chdir(pkg)

    # Match server: optional .env (may restore keys); then force DB paths again so
    # this run never writes to the user's default script/vector DBs.
    try:
        from dotenv import load_dotenv

        load_dotenv(override=True)
    except ImportError:
        pass
    _configure_isolated_dbs(tmpdir)
    _clear_embedding_keys()

    # User session: import store (triggers seed + graph sync).
    import graph as graph_mod  # noqa: F401
    import scripts  # noqa: F401 — runs _seed()

    from graph import embed_query, is_available, search_scripts

    # --- Script index (marketplace search) ---
    assert is_available(), "SQLite script index should open"
    q = "analyze csv file statistics columns"
    emb = embed_query(q)
    assert len(emb) > 0, "query embedding must be non-empty"
    results = search_scripts(emb, limit=8)
    assert results, "seed scripts should produce search hits"
    top_names = [r["name"] for r in results[:3]]
    assert "CSV Analyzer" in top_names, f"expected CSV Analyzer in top 3, got {top_names}"
    print("[OK] script index: embed_query → search_scripts")
    print(f"     query={q!r} dim={len(emb)} top={top_names}")

    # --- MCP tool-shaped call ---
    async def _run_tool():
        text = await _tool_search_scripts("summarize text or article")
        assert "S-" in text and ("score=" in text or "Search results" in text), text[:500]
        print("[OK] tool-shaped search_scripts")
        preview = next(
            (ln for ln in text.split("\n") if ln.strip() and not ln.startswith('Search results for "')),
            text[:80],
        )
        print(f"     {preview[:100]}")

    asyncio.run(_run_tool())

    # --- Vector store (user KB) — signature is search(collection, query, ...) ---
    async def _run_vector():
        import vector_store

        add_out = await vector_store.add_document(
            "e2e-kb",
            "SQLite is an embedded relational database engine used by many applications.",
        )
        assert "Stored document" in add_out, add_out[:300]
        search_out = await vector_store.search(
            "e2e-kb",
            "embedded relational database",
            limit=3,
        )
        assert "Top " in search_out and "SQLite" in search_out, search_out[:500]
        print("[OK] vector_store: add_document → search(collection, query)")
        print("    ", search_out.split("\n")[2] if len(search_out.split("\n")) > 2 else search_out[:120])

    asyncio.run(_run_vector())

    graph_mod.close()
    print("\nAll embedding E2E checks passed.")
    print(f"Temp dir (you may delete): {tmpdir}")


if __name__ == "__main__":
    main()
