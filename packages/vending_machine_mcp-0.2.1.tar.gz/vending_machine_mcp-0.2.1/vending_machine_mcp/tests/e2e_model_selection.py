#!/usr/bin/env python3
"""
End-to-end test for configurable embedding models.

Tests three scenarios:
1. Explicit model param: pass provider/model/dimensions directly to add_document and search.
2. Env var defaults: set EMBEDDING_PROVIDER / EMBEDDING_MODEL / EMBEDDING_DIMENSIONS,
   verify they're picked up automatically.
3. Per-collection auto-detect: add docs with one provider, search without specifying —
   verifies _collection_config returns the right (provider, model, dim).

All tests use local-hash embeddings (no API keys needed) with different dimension sizes
to confirm the dimension routing works correctly.

Run from repo:
  python3 vending_machine_mcp/tests/e2e_model_selection.py
"""

from __future__ import annotations

import asyncio
import os
import sys
import tempfile


def _pkg_dir() -> str:
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _setup(tmpdir: str) -> None:
    os.environ["VECTOR_STORE_DB"] = os.path.join(tmpdir, "vector_store.sqlite3")
    os.environ["SCRIPT_INDEX_DB_PATH"] = os.path.join(tmpdir, "script_index.sqlite3")
    for k in ("VOYAGE_API_KEY", "OPENAI_API_KEY", "GEMINI_API_KEY", "GOOGLE_API_KEY",
              "EMBEDDING_PROVIDER", "EMBEDDING_MODEL", "EMBEDDING_DIMENSIONS"):
        os.environ.pop(k, None)


def main() -> None:
    tmpdir = tempfile.mkdtemp(prefix="vm-mcp-model-sel-")
    _setup(tmpdir)

    pkg = _pkg_dir()
    sys.path.insert(0, pkg)
    os.chdir(pkg)

    import vector_store
    from vector_store import (
        PROVIDER_MODELS,
        _collection_config,
        _default_dimensions,
        _default_model,
        _default_provider,
    )

    # -----------------------------------------------------------------------
    # Test 0: PROVIDER_MODELS dict and helpers
    # -----------------------------------------------------------------------
    assert "openai" in PROVIDER_MODELS
    assert "voyage" in PROVIDER_MODELS
    assert "gemini" in PROVIDER_MODELS
    assert "local" in PROVIDER_MODELS

    assert PROVIDER_MODELS["openai"]["default"] == "text-embedding-3-small"
    assert PROVIDER_MODELS["voyage"]["default"] == "voyage-4-lite"
    assert PROVIDER_MODELS["gemini"]["default"] == "gemini-embedding-001"

    assert "voyage-code-3" in PROVIDER_MODELS["voyage"]["models"]
    assert "voyage-finance-2" in PROVIDER_MODELS["voyage"]["models"]
    assert "gemini-embedding-2-preview" in PROVIDER_MODELS["gemini"]["models"]
    assert "text-embedding-3-large" in PROVIDER_MODELS["openai"]["models"]

    # No keys set, no env vars → should be "local"
    assert _default_provider() == "local", f"Expected local, got {_default_provider()}"
    assert _default_model("local") == "local-hash-256"
    assert _default_dimensions() is None
    print("[OK] PROVIDER_MODELS dict and default helpers (no keys → local)")

    # -----------------------------------------------------------------------
    # Test 1: Env var defaults
    # -----------------------------------------------------------------------
    os.environ["EMBEDDING_PROVIDER"] = "openai"
    os.environ["EMBEDDING_MODEL"] = "text-embedding-3-large"
    os.environ["EMBEDDING_DIMENSIONS"] = "512"

    assert _default_provider() == "openai"
    assert _default_model("openai") == "text-embedding-3-large"
    assert _default_dimensions() == 512
    print("[OK] Env var defaults: EMBEDDING_PROVIDER=openai, MODEL=text-embedding-3-large, DIMENSIONS=512")

    # Clean up env for next tests
    for k in ("EMBEDDING_PROVIDER", "EMBEDDING_MODEL", "EMBEDDING_DIMENSIONS"):
        os.environ.pop(k, None)

    # -----------------------------------------------------------------------
    # Test 2: embed_text returns (vec, provider, model) tuple
    # -----------------------------------------------------------------------
    async def _test_embed_text_signature():
        result = await vector_store.embed_text("hello world", for_query=False)
        assert len(result) == 3, f"Expected 3-tuple, got {len(result)}"
        vec, prov, mdl = result
        assert isinstance(vec, list)
        assert isinstance(prov, str)
        assert isinstance(mdl, str)
        # With no keys → local
        assert prov == "local", f"Expected local, got {prov}"
        assert "local-hash" in mdl, f"Expected local-hash model, got {mdl}"
        print(f"[OK] embed_text returns 3-tuple: (vec[{len(vec)}], {prov}, {mdl})")

    asyncio.run(_test_embed_text_signature())

    # -----------------------------------------------------------------------
    # Test 3: Explicit provider/model/dimensions on embed_text
    # -----------------------------------------------------------------------
    async def _test_explicit_params():
        vec128, prov, mdl = await vector_store.embed_text(
            "test text", for_query=False, provider="local", dimensions=128,
        )
        assert len(vec128) == 128, f"Expected dim=128, got {len(vec128)}"
        assert prov == "local"
        assert "128" in mdl
        print(f"[OK] Explicit provider=local, dimensions=128 → dim={len(vec128)}, model={mdl}")

        vec512, _, _ = await vector_store.embed_text(
            "test text", for_query=False, provider="local", dimensions=512,
        )
        assert len(vec512) == 512, f"Expected dim=512, got {len(vec512)}"
        print(f"[OK] Explicit provider=local, dimensions=512 → dim={len(vec512)}")

    asyncio.run(_test_explicit_params())

    # -----------------------------------------------------------------------
    # Test 4: add_document with explicit model, then auto-detect via _collection_config
    # -----------------------------------------------------------------------
    async def _test_add_and_autodetect():
        # Reset connection to pick up fresh DB
        vector_store._conn = None

        result = await vector_store.add_document(
            "test-col-128",
            "SQLite is an embedded relational database.",
            provider="local",
            dimensions=128,
        )
        assert "Stored document" in result
        assert "dim=128" in result
        assert "provider=local" in result
        print(f"[OK] add_document(provider=local, dim=128): {result.split(chr(10))[0]}")

        cfg = _collection_config("test-col-128")
        assert cfg is not None, "collection config should not be None"
        stored_prov, stored_mdl, stored_dim = cfg
        assert stored_prov == "local", f"Expected local, got {stored_prov}"
        assert stored_dim == 128, f"Expected dim=128, got {stored_dim}"
        assert "128" in stored_mdl, f"Expected model containing 128, got {stored_mdl}"
        print(f"[OK] _collection_config('test-col-128') → ({stored_prov}, {stored_mdl}, {stored_dim})")

    asyncio.run(_test_add_and_autodetect())

    # -----------------------------------------------------------------------
    # Test 5: search auto-detects collection provider (dim must match)
    # -----------------------------------------------------------------------
    async def _test_search_autodetect():
        vector_store._conn = None

        await vector_store.add_document(
            "search-test",
            "Python is a programming language.",
            provider="local",
            dimensions=64,
        )
        await vector_store.add_document(
            "search-test",
            "JavaScript runs in the browser.",
            doc_id="doc-js",
            provider="local",
            dimensions=64,
        )

        # Search without specifying provider — should auto-detect local/64
        result = await vector_store.search("search-test", "programming language")
        assert "Top" in result, f"Expected results, got: {result[:200]}"
        assert "Python" in result or "programming" in result.lower()
        print(f"[OK] search auto-detect: found results in search-test collection")

        # Search with wrong dimensions should find nothing
        result_wrong = await vector_store.search(
            "search-test", "programming", provider="local", dimensions=512,
        )
        assert "No matches" in result_wrong, f"Expected no matches with dim=512, got: {result_wrong[:200]}"
        print("[OK] search with mismatched dimensions correctly returns no matches")

    asyncio.run(_test_search_autodetect())

    # -----------------------------------------------------------------------
    # Test 6: _add_sync stores model column
    # -----------------------------------------------------------------------
    async def _test_model_column():
        vector_store._conn = None
        conn = vector_store._get_conn()

        await vector_store.add_document(
            "model-col",
            "Testing model column storage.",
            doc_id="mdl-test",
            provider="local",
            dimensions=64,
        )

        row = conn.execute(
            "SELECT model FROM vector_documents WHERE collection='model-col' AND doc_id='mdl-test'"
        ).fetchone()
        assert row is not None, "Row not found"
        model_val = row["model"]
        assert "local-hash" in model_val, f"Expected model containing 'local-hash', got {model_val!r}"
        print(f"[OK] model column stored: {model_val!r}")

    asyncio.run(_test_model_column())

    # -----------------------------------------------------------------------
    # Test 7: graph.py reads env var defaults
    # -----------------------------------------------------------------------
    os.environ.pop("EMBEDDING_PROVIDER", None)
    os.environ.pop("EMBEDDING_MODEL", None)
    os.environ.pop("EMBEDDING_DIMENSIONS", None)

    from graph import _env_dimensions, _env_model, _env_provider

    assert _env_provider() == "local", f"Expected local (no keys), got {_env_provider()}"
    assert _env_model("voyage") == "voyage-4-lite"
    assert _env_model("openai") == "text-embedding-3-small"
    assert _env_model("gemini") == "gemini-embedding-001"
    assert _env_dimensions() is None

    os.environ["EMBEDDING_PROVIDER"] = "gemini"
    os.environ["EMBEDDING_MODEL"] = "gemini-embedding-2-preview"
    os.environ["EMBEDDING_DIMENSIONS"] = "256"
    assert _env_provider() == "gemini"
    assert _env_model("gemini") == "gemini-embedding-2-preview"
    assert _env_dimensions() == 256
    print("[OK] graph.py env var helpers: _env_provider, _env_model, _env_dimensions")

    # Clean up
    for k in ("EMBEDDING_PROVIDER", "EMBEDDING_MODEL", "EMBEDDING_DIMENSIONS"):
        os.environ.pop(k, None)

    # -----------------------------------------------------------------------
    # Test 8: embeddings_agent.py EMBEDDING_PROVIDERS updated
    # -----------------------------------------------------------------------
    from agents.embeddings_agent import EMBEDDING_PROVIDERS

    assert EMBEDDING_PROVIDERS["voyage"]["default"] == "voyage-4-lite"
    assert EMBEDDING_PROVIDERS["gemini"]["default"] == "gemini-embedding-001"
    assert "voyage-code-3" in EMBEDDING_PROVIDERS["voyage"]["models"]
    assert "voyage-4" in EMBEDDING_PROVIDERS["voyage"]["models"]
    assert "gemini-embedding-2-preview" in EMBEDDING_PROVIDERS["gemini"]["models"]
    print("[OK] embeddings_agent.py EMBEDDING_PROVIDERS updated with new defaults and models")

    # -----------------------------------------------------------------------
    print(f"\nAll model selection E2E checks passed.")
    print(f"Temp dir (you may delete): {tmpdir}")


if __name__ == "__main__":
    main()
