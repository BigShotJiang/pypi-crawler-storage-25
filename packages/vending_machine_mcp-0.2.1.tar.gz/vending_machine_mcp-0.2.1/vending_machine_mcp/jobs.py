"""
Job store for async agent tasks.

Persists to Supabase PostgreSQL when configured. Falls back to in-memory dict.
The jobs table has Supabase Realtime enabled — any UPDATE automatically
broadcasts to subscribed frontend clients (MCP → frontend bridge).
"""

from __future__ import annotations

import logging
import time
import uuid
from enum import StrEnum
from typing import Any, TypedDict

logger = logging.getLogger("jobs")


class JobStatus(StrEnum):
    queued = "queued"
    running = "running"
    complete = "complete"
    error = "error"
    cancelled = "cancelled"
    expired = "expired"


# Terminal states — once a job reaches these, it cannot transition further
TERMINAL_STATES = {JobStatus.complete, JobStatus.error, JobStatus.cancelled, JobStatus.expired}

# Default max duration before a job is reaped (10 minutes)
DEFAULT_JOB_TIMEOUT = 1800


class Job(TypedDict):
    job_id: str
    agent_id: str
    agent_name: str
    task: str
    status: JobStatus
    created_at: float
    started_at: float | None
    completed_at: float | None
    timeout_at: float | None
    output: str
    steps: list[dict]
    metadata: dict | None
    error: str | None


# In-memory store (always used as hot cache; Supabase is write-through)
JOB_STORE: dict[str, Job] = {}


def _get_sb():
    try:
        from supabase_client import get_supabase

        return get_supabase()
    except Exception:
        return None


def _to_db_row(job: Job, source: str = "web", user_id: str | None = None) -> dict[str, Any]:
    """Convert a Job dict to a Supabase-compatible row."""
    import json

    return {
        "id": job["job_id"],
        "agent_id": job["agent_id"],
        "agent_name": job["agent_name"],
        "task": job["task"][:10000],  # Truncate very long tasks
        "status": job["status"],
        "output": job["output"][:500000] if job["output"] else "",  # 500KB max
        "error": job["error"],
        "steps": json.dumps(job["steps"]) if job["steps"] else "[]",
        "metadata": json.dumps(job["metadata"]) if job["metadata"] else None,
        "source": source,
        "user_id": user_id,
    }


# ---------------------------------------------------------------------------
# CRUD
# ---------------------------------------------------------------------------


def create_job(
    agent_id: str,
    agent_name: str,
    task: str,
    source: str = "web",
    user_id: str | None = None,
) -> Job:
    """Create a new queued job."""
    now = time.time()
    job: Job = {
        "job_id": str(uuid.uuid4()),
        "agent_id": agent_id,
        "agent_name": agent_name,
        "task": task,
        "status": JobStatus.queued,
        "created_at": now,
        "started_at": None,
        "completed_at": None,
        "timeout_at": now + DEFAULT_JOB_TIMEOUT,
        "output": "",
        "steps": [],
        "metadata": None,
        "error": None,
    }

    # Always store in memory (hot cache)
    JOB_STORE[job["job_id"]] = job

    # Write-through to Supabase
    sb = _get_sb()
    if sb:
        try:
            sb.table("jobs").insert(_to_db_row(job, source=source, user_id=user_id)).execute()
        except Exception as e:
            logger.warning("Failed to persist job to Supabase: %s", e)

    # Audit trail
    try:
        from audit import log_action

        log_action(
            tenant_id=user_id or "anonymous",
            action="job.create",
            resource_type="job",
            resource_id=job["job_id"],
            metadata={"agent": agent_id, "source": source},
        )
    except Exception as e:
        logger.debug("Audit log failed for job %s: %s", job["job_id"], e)

    # Track metric
    try:
        from middleware import inc_metric

        inc_metric("jobs_created")
    except Exception as e:
        logger.debug("Metric tracking failed: %s", e)

    return job


def get_job(job_id: str) -> Job | None:
    """Get a job by ID. Checks in-memory first, then Supabase."""
    # Hot cache first
    job = JOB_STORE.get(job_id)
    if job:
        return job

    # Fallback to DB for historical jobs
    sb = _get_sb()
    if sb:
        try:
            result = sb.table("jobs").select("*").eq("id", job_id).limit(1).execute()
            if result.data and len(result.data) > 0:
                row = result.data[0]
                import json

                return {
                    "job_id": row["id"],
                    "agent_id": row["agent_id"],
                    "agent_name": row["agent_name"],
                    "task": row["task"],
                    "status": row["status"],
                    "created_at": row.get("created_at", 0),
                    "started_at": row.get("started_at"),
                    "completed_at": row.get("completed_at"),
                    "output": row.get("output", ""),
                    "steps": json.loads(row["steps"]) if isinstance(row.get("steps"), str) else row.get("steps", []),
                    "metadata": json.loads(row["metadata"])
                    if isinstance(row.get("metadata"), str)
                    else row.get("metadata"),
                    "error": row.get("error"),
                }
        except Exception as e:
            logger.debug("Failed to get job from Supabase: %s", e)

    return None


def list_jobs(user_id: str | None = None, limit: int = 50) -> list[Job]:
    """List jobs, optionally filtered by user."""
    # For now, return from memory (fast)
    jobs = sorted(JOB_STORE.values(), key=lambda j: j["created_at"], reverse=True)
    return jobs[:limit]


def update_job(job_id: str, **fields: Any) -> Job | None:
    """Update a job. Writes to both memory and Supabase.

    When Supabase Realtime is enabled on the jobs table, this UPDATE
    automatically broadcasts to all subscribed frontend clients.
    """
    job = JOB_STORE.get(job_id)
    if not job:
        return None

    for k, v in fields.items():
        if k in job:
            job[k] = v  # type: ignore[literal-required]

    # Write-through to Supabase (triggers Realtime broadcast)
    sb = _get_sb()
    if sb:
        try:
            import json

            db_update: dict[str, Any] = {}
            for k, v in fields.items():
                if k == "steps":
                    db_update["steps"] = json.dumps(v) if isinstance(v, list) else v
                elif k == "metadata":
                    db_update["metadata"] = json.dumps(v) if isinstance(v, dict) else v
                elif k == "output":
                    db_update["output"] = v[:500000] if v else ""
                elif k in ("status", "error", "started_at", "completed_at"):
                    db_update[k] = v

            if db_update:
                sb.table("jobs").update(db_update).eq("id", job_id).execute()
        except Exception as e:
            logger.debug("Failed to update job in Supabase: %s", e)

    return job


# ---------------------------------------------------------------------------
# Job Lifecycle
# ---------------------------------------------------------------------------


def cancel_job(job_id: str) -> Job | None:
    """Cancel a job. Only works if the job is not in a terminal state."""
    job = get_job(job_id)
    if not job:
        return None
    if job["status"] in TERMINAL_STATES:
        return job  # Already done — no-op

    return update_job(
        job_id,
        status=JobStatus.cancelled,
        completed_at=time.time(),
        error="Cancelled by user or system",
    )


def reap_stuck_jobs() -> list[str]:
    """Find and expire jobs that have exceeded their timeout.

    Returns list of expired job IDs.
    """
    now = time.time()
    reaped = []

    for job_id, job in list(JOB_STORE.items()):
        if job["status"] in TERMINAL_STATES:
            continue

        timeout_at = job.get("timeout_at")
        if timeout_at and now > timeout_at:
            update_job(
                job_id,
                status=JobStatus.expired,
                completed_at=now,
                error=f"Job timed out after {DEFAULT_JOB_TIMEOUT}s",
            )
            reaped.append(job_id)
            logger.warning(
                "Reaped stuck job %s (agent=%s, age=%ds)",
                job_id,
                job["agent_id"],
                int(now - job["created_at"]),
            )

    return reaped


def load_active_jobs_from_db() -> int:
    """Load non-terminal jobs from Supabase into memory on startup.

    Returns the number of jobs loaded.
    """
    sb = _get_sb()
    if not sb:
        return 0

    try:
        import json as json_mod

        result = sb.table("jobs").select("*").in_("status", ["queued", "running"]).execute()
        loaded = 0
        for row in result.data or []:
            job: Job = {
                "job_id": row["id"],
                "agent_id": row.get("agent_id", ""),
                "agent_name": row.get("agent_name", ""),
                "task": row.get("task", ""),
                "status": JobStatus(row.get("status", "error")),
                "created_at": row.get("created_at", 0),
                "started_at": row.get("started_at"),
                "completed_at": row.get("completed_at"),
                "timeout_at": row.get("timeout_at"),
                "output": row.get("output", ""),
                "steps": json_mod.loads(row["steps"]) if row.get("steps") else [],
                "metadata": json_mod.loads(row["metadata"]) if row.get("metadata") else None,
                "error": row.get("error"),
            }
            JOB_STORE[job["job_id"]] = job
            loaded += 1

        if loaded:
            logger.info("Loaded %d active jobs from database", loaded)
        return loaded

    except Exception as e:
        logger.warning("Failed to load jobs from database: %s", e)
        return 0
