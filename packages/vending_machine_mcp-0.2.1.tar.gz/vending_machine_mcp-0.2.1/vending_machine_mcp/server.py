"""
Entry point for the Vending Machine MCP server.

Install:
    pip install vending-machine-mcp

Run:
    vending-machine-mcp          # stdio transport (default)

Claude Code config:
    {"vending-machine": {"command": "vending-machine-mcp"}}

Or with uvx (no install):
    uvx vending-machine-mcp
"""

import os
import sys


def main():
    """Launch the MCP server via stdio transport."""
    # Add the package directory to path so internal imports resolve
    pkg_dir = os.path.dirname(__file__)
    if pkg_dir not in sys.path:
        sys.path.insert(0, pkg_dir)

    # Load env vars from .env if present
    try:
        from dotenv import load_dotenv

        load_dotenv(override=True)
    except ImportError:
        pass

    # Import and run the MCP server
    from mcp_server import mcp  # type: ignore[import-untyped]

    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
