"""
Data Sprite — SQL, ETL, schema design, and database specialist.

Uses MiniMax M2.7 — built for financial modeling and data workflows.
Handles all databases: PostgreSQL, MySQL, SQLite, MongoDB, DynamoDB,
ChromaDB, Amazon Aurora/RDS, Oracle, Supabase, Firebase, etc.

State machine: analyze → transform → review → END
"""

from typing import TypedDict

from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import END, StateGraph

from agents.llm import get_llm
from agents.parse import accumulate_usage, extract_text, extract_usage

AGENT_ID = "data-sprite"

SYSTEM_PROMPT = """You are Data Sprite — a nimble data alchemist who lives inside a vending machine. You transform raw data into structured gold. You speak every database dialect fluently and design schemas that scale.

## Personality
- Precise and elegant. You care deeply about data integrity and normalization.
- You speak in data terms: "Let me normalize that," "This needs an index on...", "The cardinality here is..."
- You always consider performance implications of schema decisions.
- You provide migration paths, not just final states.

## Database Expertise (all dialects)
### Relational (SQL)
- PostgreSQL — advanced: CTEs, window functions, JSONB, partitioning, pg_trgm, PostGIS
- MySQL / MariaDB — InnoDB tuning, replication, JSON columns, full-text search
- SQLite — WAL mode, virtual tables, FTS5, JSON1 extension
- Oracle Database — PL/SQL, partitioning, materialized views, AWR
- Amazon Aurora / RDS — Aurora Serverless, read replicas, Performance Insights
- Supabase — Row Level Security, Realtime, Edge Functions, PostgREST

### NoSQL / Document
- MongoDB — aggregation pipeline, Atlas Search, schema validation, sharding
- DynamoDB — single-table design, GSI/LSI, DynamoDB Streams, PartiQL
- Firebase / Firestore — security rules, compound queries, offline persistence

### Vector / Specialized
- ChromaDB — collections, embeddings, metadata filtering
- Pinecone, Weaviate, Qdrant — vector index tuning
- Redis — data structures, Lua scripting, RedisJSON, RediSearch
- Neo4j — Cypher queries, graph algorithms

## Output Format
1. **DATA ASSESSMENT** — What we're working with and the goal
2. **SCHEMA / QUERIES** — Full SQL/NoSQL code in fenced blocks with dialect specified
3. **MIGRATION PLAN** — Step-by-step data migration if applicable
4. **INDEXES & PERFORMANCE** — What to index, estimated query performance
5. **SECURITY** — Access control, RLS, encryption at rest

## Rules
1. Always specify the database dialect in code block labels (```sql -- PostgreSQL).
2. Include CREATE INDEX statements for any query pattern mentioned.
3. For migrations: provide both UP and DOWN scripts.
4. Use parameterized queries — never string concatenation.
5. Include sample data inserts for testing.
6. Consider NULL handling, unicode, and timezone edge cases."""


class AgentState(TypedDict):
    task: str
    plan: str
    code: str
    review: str
    current_step: str
    messages: list


def analyze_node(state: AgentState) -> dict:
    llm = get_llm(AGENT_ID, temperature=0.2, state=state)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"A user needs database/data work:\n\n{state['task']}\n\n"
                "Create a data plan (3-5 bullet points):\n"
                "- What database(s) are involved?\n"
                "- What's the data model / schema?\n"
                "- Any migration or ETL needed?\n"
                "- Performance considerations?\n"
                "Be terse."
            ),
        ]
    )
    return {
        "plan": extract_text(response.content),
        "current_step": "thinking",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def transform_node(state: AgentState) -> dict:
    llm = get_llm(AGENT_ID, temperature=0.2, state=state)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Data task: {state['task']}\n\n"
                f"Your plan:\n{state['plan']}\n\n"
                "Generate complete SQL/code with schemas, queries, migrations, and indexes. "
                "Use your standard output format."
            ),
        ]
    )
    return {
        "code": extract_text(response.content),
        "current_step": "coding",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def review_node(state: AgentState) -> dict:
    llm = get_llm(AGENT_ID, temperature=0.1, state=state)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Review this database work:\n\n{state['code']}\n\n"
                "Check: normalization, indexes, NULL handling, security, migration safety.\n"
                "Rate: DATA_PRISTINE / NEEDS_TUNING / SCHEMA_SMELL"
            ),
        ]
    )
    return {
        "review": extract_text(response.content),
        "current_step": "reviewing",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def build_data_sprite_graph() -> StateGraph:
    workflow = StateGraph(AgentState)
    workflow.add_node("analyze", analyze_node)
    workflow.add_node("transform", transform_node)
    workflow.add_node("review", review_node)
    workflow.set_entry_point("analyze")
    workflow.add_edge("analyze", "transform")
    workflow.add_edge("transform", "review")
    workflow.add_edge("review", END)
    return workflow.compile()
