"""
Test Goblin — Test generation specialist.

Uses Qwen3 Coder (480B MoE) for dedicated code generation.
Writes unit tests, integration tests, edge cases, and test fixtures.

State machine: analyze → generate → review → END
"""

from typing import TypedDict

from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import END, StateGraph

from agents.llm import get_llm
from agents.parse import accumulate_usage, extract_text, extract_usage

AGENT_ID = "test-goblin"

SYSTEM_PROMPT = """You are Test Goblin — a mischievous quality assurance gremlin who lives inside a vending machine. You write tests that break code in ways developers never imagined. You find edge cases that lurk in the shadows.

## Personality
- Devious and thorough. You think like an adversary trying to break the code.
- You speak like a QA troll: "Let's see if it handles...", "Edge case found!", "What if we pass..."
- You celebrate test failures — they prove the tests are working.
- You write tests that are readable, maintainable, and actually useful.

## Specialties
- Unit tests (pytest, Jest, Vitest, Go testing, JUnit)
- Integration tests (API testing, database testing)
- Edge cases (null, empty, overflow, unicode, concurrent access)
- Property-based testing (hypothesis, fast-check)
- Mocking and fixtures
- Test coverage analysis

## Output Format
1. **TEST STRATEGY** — What we're testing and why
2. **TEST CODE** — Complete test files in fenced code blocks
3. **EDGE CASES** — List of edge cases covered
4. **SETUP** — How to run the tests (commands, dependencies)
5. **COVERAGE NOTES** — What's covered and what's not

## Rules
1. Generate complete, runnable test files — no placeholders.
2. Use the same language and test framework as the source code.
3. Include at least 3 edge cases per function.
4. Use descriptive test names that explain what's being tested.
5. Include both positive (happy path) and negative (error path) tests.
6. Add comments explaining non-obvious test logic."""


class AgentState(TypedDict):
    task: str
    plan: str
    code: str
    review: str
    current_step: str
    messages: list


def analyze_node(state: AgentState) -> dict:
    llm = get_llm(AGENT_ID, temperature=0.2, state=state)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"A user needs tests for:\n\n{state['task']}\n\n"
                "Create a test plan (3-5 bullet points):\n"
                "- What language/framework to use?\n"
                "- What functions/endpoints to test?\n"
                "- What edge cases to target?\n"
                "Be terse and devious."
            ),
        ]
    )
    return {
        "plan": extract_text(response.content),
        "current_step": "thinking",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def generate_node(state: AgentState) -> dict:
    llm = get_llm(AGENT_ID, temperature=0.2, state=state)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Code to test:\n\n{state['task']}\n\n"
                f"Your test plan:\n{state['plan']}\n\n"
                "Generate complete test files. Include happy paths, error paths, "
                "and at least 3 devious edge cases per function."
            ),
        ]
    )
    return {
        "code": extract_text(response.content),
        "current_step": "coding",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def review_node(state: AgentState) -> dict:
    llm = get_llm(AGENT_ID, temperature=0.1, state=state)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Review these tests:\n\n{state['code']}\n\n"
                "Are we missing edge cases? Are mocks correct? Would these actually catch bugs?\n"
                "Rate: GOBLIN_APPROVED / NEEDS_MORE_CHAOS / TOO_BASIC"
            ),
        ]
    )
    return {
        "review": extract_text(response.content),
        "current_step": "reviewing",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def build_test_goblin_graph() -> StateGraph:
    workflow = StateGraph(AgentState)
    workflow.add_node("analyze", analyze_node)
    workflow.add_node("generate", generate_node)
    workflow.add_node("review", review_node)
    workflow.set_entry_point("analyze")
    workflow.add_edge("analyze", "generate")
    workflow.add_edge("generate", "review")
    workflow.add_edge("review", END)
    return workflow.compile()
