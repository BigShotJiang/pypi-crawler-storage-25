"""
Code Gremlin - LangGraph agent for the Vending Machine.
Uses OpenAI Codex via OpenRouter for code generation.

State machine: plan → write → review → dispense
"""

from typing import TypedDict

from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import END, StateGraph

from agents.llm import get_llm
from agents.parse import accumulate_usage, extract_text, extract_usage

SYSTEM_PROMPT = """You are the Code Gremlin — a grizzled, caffeinated script specialist who lives inside a vending machine. You write scripts that WORK. No fluff, no bloat, just clean, battle-tested code.

## Personality
- Terse but friendly. You talk like a senior engineer at 2am who's had too much coffee.
- You use brief, punchy comments in your code.
- You occasionally mutter observations like "ah, classic off-by-one territory" or "let me firewall this real quick."
- You NEVER apologize. You fix things.

## Specialties
You are an expert in "glue languages" — the scripts that hold everything together:
- Python — automation, data wrangling, file processing, web scraping
- Bash/Shell — server ops, cron jobs, file management, deployment
- PowerShell — Windows admin, AD management, system automation
- Excel VBA — macros, report automation, data cleanup
- Node.js (mjs) — API scripts, file transforms, quick utilities

## Rules
1. Always detect the best language for the task unless the user specifies one.
2. Include a shebang line for bash/python scripts.
3. Add inline comments only where the logic isn't obvious.
4. For PowerShell: follow security best practices, use approved verbs, avoid Invoke-Expression.
5. For VBA: include instructions on where to paste the code (e.g., "Paste into a Standard Module").
6. NEVER generate code that deletes files, drops tables, or performs destructive operations without explicit confirmation logic built into the script.
7. If the request is ambiguous, pick the most reasonable interpretation and note your assumption.
8. Keep scripts self-contained — no external dependencies unless absolutely necessary."""

AGENT_ID = "code-gremlin"


class AgentState(TypedDict):
    task: str
    plan: str
    code: str
    review: str
    messages: list
    current_step: str


def plan_node(state: AgentState) -> dict:
    llm = get_llm(AGENT_ID, temperature=0.3, state=state)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"A user just hired you. Their request:\n\n{state['task']}\n\n"
                "Respond with ONLY a brief plan (3-5 bullet points) of how you'll write this script. "
                "Detect the best scripting language. Be terse. No code yet."
            ),
        ]
    )
    return {
        "plan": extract_text(response.content),
        "current_step": "thinking",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def write_node(state: AgentState) -> dict:
    llm = get_llm(AGENT_ID, temperature=0.2, state=state)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Task: {state['task']}\n\nYour plan:\n{state['plan']}\n\n"
                "Now write the complete script. Output ONLY the code in a single fenced code block. "
                "No explanations outside the code block. Include inline comments where helpful."
            ),
        ]
    )
    return {
        "code": extract_text(response.content),
        "current_step": "coding",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def review_node(state: AgentState) -> dict:
    llm = get_llm(AGENT_ID, temperature=0.1, state=state)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Review this script for bugs, edge cases, and security issues:\n\n{state['code']}\n\n"
                "Be brief. List only actual issues or confirm it's clean. "
                "Format: bullet points, max 5 items. End with a verdict: PASS or NEEDS_FIX."
            ),
        ]
    )
    return {
        "review": extract_text(response.content),
        "current_step": "reviewing",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def build_code_gremlin_graph() -> StateGraph:
    workflow = StateGraph(AgentState)
    workflow.add_node("plan", plan_node)
    workflow.add_node("write", write_node)
    workflow.add_node("review", review_node)
    workflow.set_entry_point("plan")
    workflow.add_edge("plan", "write")
    workflow.add_edge("write", "review")
    workflow.add_edge("review", END)
    return workflow.compile()
