"""
Embeddings Agent — chunking strategies.

Five strategies for splitting text into embeddable chunks:
1. paragraph — split on double newlines, merge small paragraphs
2. sentence — split on sentence boundaries, merge small sentences
3. fixed_size — sliding window with configurable overlap
4. recursive — recursive character splitting (LangChain-style)
5. contextualized — Voyage-only, returns chunks grouped for voyage-context-3
"""

import re


def chunk_paragraph(text: str, max_chars: int = 1000) -> list[str]:
    """Split on paragraph boundaries, merging small paragraphs."""
    paragraphs = text.split("\n\n")
    chunks: list[str] = []
    current = ""

    for para in paragraphs:
        para = para.strip()
        if not para:
            continue
        if len(current) + len(para) + 2 > max_chars and current:
            chunks.append(current.strip())
            current = para
        else:
            current = f"{current}\n\n{para}" if current else para

    if current.strip():
        chunks.append(current.strip())

    return chunks if chunks else [text[:max_chars]]


def chunk_sentence(text: str, max_chars: int = 1000) -> list[str]:
    """Split on sentence boundaries, merging small sentences."""
    # Split on sentence-ending punctuation followed by space or newline
    sentences = re.split(r"(?<=[.!?])\s+", text)
    chunks: list[str] = []
    current = ""

    for sent in sentences:
        sent = sent.strip()
        if not sent:
            continue
        if len(current) + len(sent) + 1 > max_chars and current:
            chunks.append(current.strip())
            current = sent
        else:
            current = f"{current} {sent}" if current else sent

    if current.strip():
        chunks.append(current.strip())

    return chunks if chunks else [text[:max_chars]]


def chunk_fixed_size(text: str, chunk_size: int = 1000, overlap: int = 200) -> list[str]:
    """Fixed-size sliding window with overlap."""
    if not text:
        return []

    chunks: list[str] = []
    start = 0
    while start < len(text):
        end = start + chunk_size
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        if end >= len(text):
            break
        start = end - overlap

    return chunks if chunks else [text[:chunk_size]]


def chunk_recursive(
    text: str,
    max_chars: int = 1000,
    separators: list[str] | None = None,
) -> list[str]:
    """Recursive character splitting — tries separators in order of priority.

    Mirrors LangChain's RecursiveCharacterTextSplitter logic:
    try to split on the most meaningful boundary first, fall back to smaller ones.
    """
    if separators is None:
        separators = ["\n\n", "\n", ". ", " ", ""]

    if len(text) <= max_chars:
        return [text.strip()] if text.strip() else []

    # Find the first separator that actually appears in the text
    for i, sep in enumerate(separators):
        if not sep:
            # Empty separator = character-level split (last resort)
            return chunk_fixed_size(text, chunk_size=max_chars, overlap=0)

        if sep not in text:
            continue

        parts = text.split(sep)
        chunks: list[str] = []
        current = ""

        for part in parts:
            candidate = f"{current}{sep}{part}" if current else part
            if len(candidate) <= max_chars:
                current = candidate
            else:
                if current:
                    chunks.append(current.strip())
                # If this single part is too big, recurse with next separator
                if len(part) > max_chars:
                    sub_chunks = chunk_recursive(part, max_chars, separators[i + 1 :])
                    chunks.extend(sub_chunks)
                    current = ""
                else:
                    current = part

        if current.strip():
            chunks.append(current.strip())

        if chunks:
            return chunks

    # Fallback — nothing worked, just cut
    return chunk_fixed_size(text, chunk_size=max_chars, overlap=0)


def chunk_contextualized(text: str, max_chars: int = 1000) -> list[str]:
    """Chunk for Voyage contextualized embeddings.

    Returns individual chunks. The caller (provider wrapper) is responsible
    for passing them as a grouped list to voyage-context-3's
    contextualized_embed API.

    Uses paragraph splitting as the base, since contextualized embeddings
    work best with semantically coherent chunks.
    """
    return chunk_paragraph(text, max_chars=max_chars)


# ---------------------------------------------------------------------------
# Strategy dispatcher
# ---------------------------------------------------------------------------

CHUNK_FUNCTIONS = {
    "paragraph": chunk_paragraph,
    "sentence": chunk_sentence,
    "fixed_size": chunk_fixed_size,
    "recursive": chunk_recursive,
    "contextualized": chunk_contextualized,
}


def auto_select_strategy(text: str, provider: str, model: str) -> str:
    """Heuristic to pick the best chunking strategy."""
    # Voyage context model -> contextualized
    if provider == "voyage" and model == "voyage-context-3":
        return "contextualized"

    # Code content (high indentation / bracket ratio) -> fixed_size with overlap
    lines = text.split("\n")[:200]  # sample first 200 lines
    if lines:
        indented = sum(1 for line in lines if line.startswith(("  ", "\t")))
        bracket_count = sum(line.count("{") + line.count("}") for line in lines)
        if indented / len(lines) > 0.3 or bracket_count > len(lines) * 0.1:
            return "fixed_size"

    # Clear paragraph breaks -> paragraph
    if text.count("\n\n") > 3:
        return "paragraph"

    # Default -> recursive
    return "recursive"


def run_chunking(
    text: str,
    strategy: str = "auto",
    provider: str = "",
    model: str = "",
    max_chars: int = 1000,
    chunk_size: int = 1000,
    overlap: int = 200,
) -> tuple[str, list[str]]:
    """Run a chunking strategy. Returns (resolved_strategy, chunks)."""
    if strategy == "auto" or strategy not in CHUNK_FUNCTIONS:
        strategy = auto_select_strategy(text, provider, model)

    fn = CHUNK_FUNCTIONS[strategy]

    if strategy == "fixed_size":
        chunks = fn(text, chunk_size=chunk_size, overlap=overlap)
    elif strategy == "recursive":
        chunks = fn(text, max_chars=max_chars)
    else:
        chunks = fn(text, max_chars=max_chars)

    return strategy, chunks
