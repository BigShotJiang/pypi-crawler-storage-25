"""
Embeddings Agent — batch JSONL generation, batch job creation, polling, and download.

Supports:
  - OpenAI Batch API: 50% discount, 50K requests/batch, 200MB max, 24h window
  - Voyage AI Batch: 33% discount, 100K inputs/batch, 12h window
  - Gemini Batch: 50% discount

All providers follow the same flow:
  1. build_jsonl() — generate JSONL string from chunks + params
  2. build_metadata_sidecar() — generate chunk metadata JSONL
  3. create_batch() — upload JSONL file + create batch job
  4. poll_batch() — check batch status
  5. download_batch() — retrieve completed results
"""

import json
import logging
import os
import tempfile
import time

logger = logging.getLogger("embeddings.batch")


# ---------------------------------------------------------------------------
# JSONL builders
# ---------------------------------------------------------------------------


def build_openai_jsonl(
    chunks: list[str],
    model: str = "text-embedding-3-small",
    dimensions: int | None = None,
) -> str:
    """Build OpenAI batch JSONL. Each line is a POST /v1/embeddings request."""
    lines = []
    for i, chunk in enumerate(chunks):
        body: dict = {"model": model, "input": chunk}
        if dimensions is not None:
            body["dimensions"] = dimensions
        lines.append(
            json.dumps(
                {
                    "custom_id": f"emb-{i}",
                    "method": "POST",
                    "url": "/v1/embeddings",
                    "body": body,
                }
            )
        )
    return "\n".join(lines)


def build_voyage_jsonl(
    chunks: list[str],
    model: str = "voyage-4-lite",
    input_type: str | None = None,
    dimensions: int | None = None,
    output_dtype: str | None = None,
) -> str:
    """Build Voyage AI batch JSONL."""
    lines = []
    for i, chunk in enumerate(chunks):
        body: dict = {"input": [chunk], "model": model}
        if input_type:
            body["input_type"] = input_type
        if dimensions is not None:
            body["output_dimension"] = dimensions
        if output_dtype:
            body["output_dtype"] = output_dtype
        lines.append(
            json.dumps(
                {
                    "custom_id": f"emb-{i}",
                    "body": body,
                }
            )
        )
    return "\n".join(lines)


def build_gemini_jsonl(
    chunks: list[str],
    model: str = "gemini-embedding-001",
    dimensions: int | None = None,
    task_type: str | None = None,
) -> str:
    """Build Gemini batch JSONL."""
    lines = []
    for i, chunk in enumerate(chunks):
        body: dict = {"model": model, "content": chunk}
        if dimensions is not None:
            body["output_dimensionality"] = dimensions
        if task_type:
            body["task_type"] = task_type
        lines.append(
            json.dumps(
                {
                    "custom_id": f"emb-{i}",
                    "body": body,
                }
            )
        )
    return "\n".join(lines)


JSONL_BUILDERS = {
    "openai": build_openai_jsonl,
    "voyage": build_voyage_jsonl,
    "gemini": build_gemini_jsonl,
}


def build_jsonl(
    chunks: list[str],
    provider: str,
    model: str,
    **kwargs,
) -> str:
    """Dispatch to the correct JSONL builder."""
    builder = JSONL_BUILDERS.get(provider)
    if not builder:
        raise ValueError(f"No JSONL builder for provider: {provider}")

    # Filter kwargs to only what the builder accepts
    if provider == "openai":
        return builder(chunks, model=model, dimensions=kwargs.get("dimensions"))
    elif provider == "voyage":
        return builder(
            chunks,
            model=model,
            input_type=kwargs.get("input_type"),
            dimensions=kwargs.get("dimensions"),
            output_dtype=kwargs.get("output_dtype"),
        )
    elif provider == "gemini":
        return builder(
            chunks,
            model=model,
            dimensions=kwargs.get("dimensions"),
            task_type=kwargs.get("task_type"),
        )
    return builder(chunks, model=model)


def build_metadata_sidecar(
    chunks: list[str],
    source_file: str = "unknown",
) -> str:
    """Build metadata sidecar JSONL — maps custom_id to chunk text and position."""
    lines = []
    char_offset = 0
    for i, chunk in enumerate(chunks):
        lines.append(
            json.dumps(
                {
                    "custom_id": f"emb-{i}",
                    "text": chunk[:200],  # preview only
                    "source_file": source_file,
                    "chunk_index": i,
                    "char_offset": char_offset,
                }
            )
        )
        char_offset += len(chunk)
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# OpenAI Batch API operations
# ---------------------------------------------------------------------------


def _openai_upload_file(jsonl_content: str) -> str:
    """Upload a JSONL file to OpenAI for batch processing. Returns file_id."""
    from openai import OpenAI

    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY", ""))

    # Write to temp file (OpenAI SDK needs a file-like object)
    with tempfile.NamedTemporaryFile(mode="w", suffix=".jsonl", delete=False) as f:
        f.write(jsonl_content)
        temp_path = f.name

    try:
        with open(temp_path, "rb") as f:
            file_obj = client.files.create(file=f, purpose="batch")
        return file_obj.id
    finally:
        os.unlink(temp_path)


def create_openai_batch(jsonl_content: str) -> dict:
    """Upload JSONL and create an OpenAI batch job.

    Returns: {"batch_id": str, "status": str, "file_id": str}
    """
    from openai import OpenAI

    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY", ""))

    file_id = _openai_upload_file(jsonl_content)
    logger.info(f"OpenAI batch file uploaded: {file_id}")

    batch = client.batches.create(
        input_file_id=file_id,
        endpoint="/v1/embeddings",
        completion_window="24h",
    )

    logger.info(f"OpenAI batch created: {batch.id} (status: {batch.status})")
    return {
        "batch_id": batch.id,
        "status": batch.status,
        "file_id": file_id,
        "provider": "openai",
        "created_at": time.time(),
    }


def poll_openai_batch(batch_id: str) -> dict:
    """Check the status of an OpenAI batch job.

    Returns: {"batch_id": str, "status": str, "output_file_id": str | None,
              "completed": int, "failed": int, "total": int}
    """
    from openai import OpenAI

    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY", ""))
    batch = client.batches.retrieve(batch_id)

    counts = batch.request_counts
    return {
        "batch_id": batch.id,
        "status": batch.status,
        "output_file_id": batch.output_file_id,
        "error_file_id": batch.error_file_id,
        "completed": counts.completed if counts else 0,
        "failed": counts.failed if counts else 0,
        "total": counts.total if counts else 0,
    }


def download_openai_batch(batch_id: str) -> list[dict]:
    """Download completed OpenAI batch results.

    Returns a list of result dicts, each containing:
    {"custom_id": str, "embedding": list[float], "model": str}
    """
    from openai import OpenAI

    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY", ""))

    # Get the output file ID
    batch = client.batches.retrieve(batch_id)
    if not batch.output_file_id:
        raise ValueError(f"Batch {batch_id} has no output file (status: {batch.status})")

    # Download the file content
    content = client.files.content(batch.output_file_id)
    text = content.text

    results = []
    for line in text.strip().split("\n"):
        if not line:
            continue
        entry = json.loads(line)
        custom_id = entry.get("custom_id", "")
        response = entry.get("response", {})
        body = response.get("body", {})

        if response.get("status_code") == 200 and body.get("data"):
            embedding = body["data"][0]["embedding"]
            results.append(
                {
                    "custom_id": custom_id,
                    "embedding": embedding,
                    "model": body.get("model", ""),
                }
            )
        else:
            error = response.get("error", {})
            results.append(
                {
                    "custom_id": custom_id,
                    "error": error.get("message", "Unknown error"),
                }
            )

    return results


# ---------------------------------------------------------------------------
# Voyage AI Batch API operations
# ---------------------------------------------------------------------------


def create_voyage_batch(jsonl_content: str) -> dict:
    """Create a Voyage AI batch job.

    Voyage batch API uses their SDK directly — upload inputs in bulk.
    Returns: {"batch_id": str, "status": str}
    """
    import voyageai

    client = voyageai.Client(api_key=os.getenv("VOYAGE_API_KEY", ""))

    # Parse JSONL to extract inputs and model
    requests = []
    model = "voyage-4-lite"
    for line in jsonl_content.strip().split("\n"):
        entry = json.loads(line)
        body = entry["body"]
        model = body.get("model", model)
        requests.append(body)

    # Voyage batch: submit all at once
    # The Voyage SDK batch method varies by version — use create_batch if available
    if hasattr(client, "create_batch"):
        result = client.create_batch(requests=requests)
        return {
            "batch_id": result.batch_id if hasattr(result, "batch_id") else str(time.time()),
            "status": "submitted",
            "provider": "voyage",
            "created_at": time.time(),
        }

    # Fallback: no native batch — return JSONL for manual submission
    logger.warning("Voyage SDK doesn't support create_batch — returning JSONL only")
    return {
        "batch_id": f"voyage-jsonl-{int(time.time())}",
        "status": "jsonl_ready",
        "provider": "voyage",
        "jsonl": jsonl_content,
        "created_at": time.time(),
    }


def poll_voyage_batch(batch_id: str) -> dict:
    """Check Voyage batch status."""
    import voyageai

    client = voyageai.Client(api_key=os.getenv("VOYAGE_API_KEY", ""))

    if hasattr(client, "get_batch"):
        result = client.get_batch(batch_id)
        return {
            "batch_id": batch_id,
            "status": getattr(result, "status", "unknown"),
            "provider": "voyage",
        }

    return {"batch_id": batch_id, "status": "unknown", "provider": "voyage"}


def download_voyage_batch(batch_id: str) -> list[dict]:
    """Download Voyage batch results."""
    import voyageai

    client = voyageai.Client(api_key=os.getenv("VOYAGE_API_KEY", ""))

    if hasattr(client, "get_batch_results"):
        result = client.get_batch_results(batch_id)
        if hasattr(result, "embeddings"):
            return [{"custom_id": f"emb-{i}", "embedding": emb} for i, emb in enumerate(result.embeddings)]

    return []


# ---------------------------------------------------------------------------
# Gemini Batch API operations
# ---------------------------------------------------------------------------


def create_gemini_batch(jsonl_content: str) -> dict:
    """Create a Gemini batch job.

    Gemini batch API uses the google-genai SDK.
    Returns: {"batch_id": str, "status": str}
    """
    # Gemini batch embedding is less standardized — return JSONL for now
    logger.info("Gemini batch: returning JSONL for manual submission")
    return {
        "batch_id": f"gemini-jsonl-{int(time.time())}",
        "status": "jsonl_ready",
        "provider": "gemini",
        "jsonl": jsonl_content,
        "created_at": time.time(),
    }


def poll_gemini_batch(batch_id: str) -> dict:
    """Check Gemini batch status."""
    return {"batch_id": batch_id, "status": "unknown", "provider": "gemini"}


def download_gemini_batch(batch_id: str) -> list[dict]:
    """Download Gemini batch results."""
    return []


# ---------------------------------------------------------------------------
# Unified batch dispatcher
# ---------------------------------------------------------------------------

BATCH_CREATE = {
    "openai": create_openai_batch,
    "voyage": create_voyage_batch,
    "gemini": create_gemini_batch,
}

BATCH_POLL = {
    "openai": poll_openai_batch,
    "voyage": poll_voyage_batch,
    "gemini": poll_gemini_batch,
}

BATCH_DOWNLOAD = {
    "openai": download_openai_batch,
    "voyage": download_voyage_batch,
    "gemini": download_gemini_batch,
}


def create_batch(provider: str, jsonl_content: str) -> dict:
    """Create a batch job with the appropriate provider."""
    fn = BATCH_CREATE.get(provider)
    if not fn:
        raise ValueError(f"No batch support for provider: {provider}")
    return fn(jsonl_content)


def poll_batch(provider: str, batch_id: str) -> dict:
    """Poll a batch job's status."""
    fn = BATCH_POLL.get(provider)
    if not fn:
        raise ValueError(f"No batch support for provider: {provider}")
    return fn(batch_id)


def download_batch(provider: str, batch_id: str) -> list[dict]:
    """Download completed batch results."""
    fn = BATCH_DOWNLOAD.get(provider)
    if not fn:
        raise ValueError(f"No batch support for provider: {provider}")
    return fn(batch_id)
