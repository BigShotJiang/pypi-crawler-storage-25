"""
Embeddings Agent — similarity analysis and statistics.
"""

import json
import math


def cosine_similarity(a: list[float], b: list[float]) -> float:
    """Compute cosine similarity between two vectors."""
    dot = sum(x * y for x, y in zip(a, b, strict=False))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


def compute_similarity_pairs(
    embeddings: list[list[float]],
) -> list[tuple[int, int, float]]:
    """Compute all pairwise cosine similarities. Returns sorted list (high to low)."""
    n = len(embeddings)
    pairs: list[tuple[int, int, float]] = []
    for i in range(n):
        for j in range(i + 1, n):
            sim = cosine_similarity(embeddings[i], embeddings[j])
            pairs.append((i, j, sim))
    pairs.sort(key=lambda x: x[2], reverse=True)
    return pairs


def build_similarity_report(
    chunks: list[str],
    embeddings: list[list[float]],
    provider: str,
    model: str,
    file_name: str,
    strategy: str,
    dimensions_used: int | None = None,
    truncated_from: int | None = None,
) -> str:
    """Build a markdown similarity report from embeddings."""
    n = len(embeddings)
    actual_dims = len(embeddings[0]) if embeddings else 0
    pairs = compute_similarity_pairs(embeddings)

    most_similar = pairs[:3] if pairs else []
    least_similar = pairs[-3:] if len(pairs) >= 3 else pairs

    lines = [
        "## Embedding Results",
        "",
        f"**Provider:** {provider} | **Model:** {model}",
        f"**Dimensions:** {actual_dims}"
        + (" (reduced from default)" if dimensions_used and dimensions_used != actual_dims else ""),
        f"**Chunks:** {n}" + (f" (capped from {truncated_from})" if truncated_from else ""),
        f"**Strategy:** {strategy}",
        f"**File:** {file_name}",
        "",
        "### Most Similar Chunk Pairs",
    ]

    for i, j, sim in most_similar:
        preview_i = chunks[i][:80].replace("\n", " ")
        preview_j = chunks[j][:80].replace("\n", " ")
        lines.append(f"- **{sim:.4f}** — Chunk {i + 1} vs Chunk {j + 1}")
        lines.append(f"  - `{preview_i}...`")
        lines.append(f"  - `{preview_j}...`")

    lines.append("")
    lines.append("### Least Similar Chunk Pairs")
    for i, j, sim in least_similar:
        preview_i = chunks[i][:80].replace("\n", " ")
        preview_j = chunks[j][:80].replace("\n", " ")
        lines.append(f"- **{sim:.4f}** — Chunk {i + 1} vs Chunk {j + 1}")
        lines.append(f"  - `{preview_i}...`")
        lines.append(f"  - `{preview_j}...`")

    if pairs:
        avg_sim = sum(s[2] for s in pairs) / len(pairs)
        lines.extend(
            [
                "",
                "### Statistics",
                f"- **Average pairwise similarity:** {avg_sim:.4f}",
                f"- **Max similarity:** {pairs[0][2]:.4f}",
                f"- **Min similarity:** {pairs[-1][2]:.4f}",
                f"- **Total pairs computed:** {len(pairs)}",
            ]
        )

    # Raw data summary
    lines.extend(
        [
            "",
            "### Raw Data",
            "```json",
            json.dumps(
                {
                    "provider": provider,
                    "model": model,
                    "dimensions": actual_dims,
                    "chunk_count": n,
                    "strategy": strategy,
                    "chunks": [
                        {
                            "index": i,
                            "text_preview": c[:100],
                            "embedding_norm": round(math.sqrt(sum(x * x for x in embeddings[i])), 4),
                        }
                        for i, c in enumerate(chunks)
                    ],
                },
                indent=2,
            ),
            "```",
        ]
    )

    return "\n".join(lines)


def build_raw_json(
    chunks: list[str],
    embeddings: list[list[float]],
    provider: str,
    model: str,
) -> str:
    """Return embeddings as a JSON string (for raw_json output format)."""
    data = {
        "provider": provider,
        "model": model,
        "dimensions": len(embeddings[0]) if embeddings else 0,
        "embeddings": [
            {
                "index": i,
                "text": c,
                "embedding": emb,
            }
            for i, (c, emb) in enumerate(zip(chunks, embeddings, strict=False))
        ],
    }
    return json.dumps(data, indent=2)


def build_raw_jsonl(
    chunks: list[str],
    embeddings: list[list[float]],
    provider: str,
    model: str,
) -> str:
    """Return embeddings as JSONL (one JSON object per line)."""
    lines = []
    for i, (chunk, emb) in enumerate(zip(chunks, embeddings, strict=False)):
        lines.append(
            json.dumps(
                {
                    "index": i,
                    "text": chunk,
                    "embedding": emb,
                    "provider": provider,
                    "model": model,
                }
            )
        )
    return "\n".join(lines)
