"""
Embeddings Agent — LangGraph graph with modular pipeline.

State machine:
  route_node -> analyze_node -> chunk_node -> [conditional]
    REALTIME: -> embed_realtime_node -> review_node -> END
    BATCH:    -> embed_batch_node    -> review_node -> END
    ANALYSIS: route_node -> analyze_node -> analysis_node -> review_node -> END

Phase 1 implements: route, analyze, chunk, embed_realtime, review.
Phase 2 adds: embed_batch, analysis.
"""

import asyncio
import concurrent.futures
import logging
from typing import Any

from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import END, StateGraph

from agents.embeddings.analysis import (
    build_raw_json,
    build_raw_jsonl,
    build_similarity_report,
)
from agents.embeddings.batch import (
    build_jsonl,
    build_metadata_sidecar,
    create_batch,
)
from agents.embeddings.chunking import run_chunking
from agents.embeddings.providers import run_embedding, run_multimodal_embedding
from agents.embeddings.types import (
    SYSTEM_PROMPT,
    AgentState,
    get_model_info,
    resolve_provider_and_model,
)
from agents.llm import get_llm
from agents.parse import accumulate_usage, extract_text, extract_usage

logger = logging.getLogger("embeddings.agent")

# Max chunks for realtime mode (avoids API cost explosion)
MAX_REALTIME_CHUNKS = 200


# ---------------------------------------------------------------------------
# Node: route
# ---------------------------------------------------------------------------


def route_node(state: AgentState) -> dict:
    """Determine mode, resolve provider/model, select chunk strategy."""
    is_multimodal = state.get("multimodal", False)

    if is_multimodal:
        # Multimodal: auto-select provider/model if not specified
        provider = state.get("provider", "")
        model = state.get("model", "")
        mime = state.get("file_mime_type", "") or ""

        if not provider and not model:
            # Default to Gemini for images/PDFs/audio, Voyage for images/video
            if mime.startswith("video/"):
                provider, model = "voyage", "voyage-multimodal-3.5"
            else:
                provider, model = "gemini", "gemini-embedding-2-preview"
        elif provider == "voyage" and not model:
            model = "voyage-multimodal-3.5"
        elif provider == "gemini" and not model:
            model = "gemini-embedding-2-preview"
        elif not provider:
            provider, model = resolve_provider_and_model("", model)

        return {
            "provider": provider,
            "model": model,
            "mode": "multimodal",
            "chunk_strategy": "none",
            "output_format": state.get("output_format", "") or "similarity_report",
            "current_step": "thinking",
        }

    # Text mode: resolve normally
    provider, model = resolve_provider_and_model(
        state.get("provider", ""),
        state.get("model", ""),
    )

    # Mode: default to realtime, allow override from state
    mode = state.get("mode", "") or "realtime"

    # Chunk strategy: use provided or auto-detect later (in chunk_node)
    strategy = state.get("chunk_strategy", "") or "auto"

    # Output format
    output_format = state.get("output_format", "") or "similarity_report"

    # Check if contextualized is appropriate
    model_info = get_model_info(provider, model)
    if model_info.get("supports_contextualized") and strategy == "auto":
        strategy = "contextualized"

    return {
        "provider": provider,
        "model": model,
        "mode": mode,
        "chunk_strategy": strategy,
        "output_format": output_format,
        "current_step": "thinking",
    }


# ---------------------------------------------------------------------------
# Node: analyze
# ---------------------------------------------------------------------------


def analyze_node(state: AgentState) -> dict:
    """LLM plans the embedding strategy."""
    state_dict: dict[str, Any] = dict(state)
    llm = get_llm("embeddings-agent", temperature=0.3, max_tokens=2048, state=state_dict)

    is_multimodal = state.get("mode") == "multimodal"
    provider = state.get("provider", "openai")
    model = state.get("model", "")
    strategy = state.get("chunk_strategy", "auto")
    mode = state.get("mode", "realtime")

    model_info = get_model_info(provider, model)
    dims = state.get("dimensions") or model_info.get("dimensions", "default")

    if is_multimodal:
        file_desc = (
            f"**File:** {state.get('file_name', 'unknown')} (binary, MIME: {state.get('file_mime_type', 'unknown')})"
        )
        analysis_prompt = (
            f"A user uploaded a binary file for multimodal embedding.\n\n"
            f"{file_desc}\n"
            f"**Provider:** {provider} | **Model:** {model}\n"
            f"**Dimensions:** {dims}\n"
            f"**User instructions:** {state.get('task', '')}\n\n"
            "Create a brief analysis plan (3-5 bullet points):\n"
            "- What type of content is this file likely to contain?\n"
            "- What embedding model and parameters to use?\n"
            "- Any constraints (file size, format support)?\n"
            "- What the embedding will capture (visual features, audio patterns, etc.)?\n"
            "Be terse."
        )
    else:
        file_preview = state.get("file_content", "")[:2000]
        char_count = len(state.get("file_content", ""))
        line_count = state.get("file_content", "").count("\n") + 1
        analysis_prompt = (
            f"A user uploaded a file for embedding processing.\n\n"
            f"**File:** {state.get('file_name', 'unknown')} ({char_count:,} chars, {line_count:,} lines)\n"
            f"**Provider:** {provider} | **Model:** {model}\n"
            f"**Mode:** {mode} | **Strategy:** {strategy}\n"
            f"**Dimensions:** {dims}\n"
            f"**User instructions:** {state.get('task', '')}\n\n"
            f"File preview (first 2000 chars):\n```\n{file_preview}\n```\n\n"
            "Create a brief analysis plan (3-5 bullet points):\n"
            "- What chunking strategy and why?\n"
            "- Estimated chunk count?\n"
            "- What parameters to use (dimensions, encoding, etc.)?\n"
            "- What analysis to perform on the embeddings?\n"
            "Be terse."
        )

    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(content=analysis_prompt),
        ]
    )
    return {
        "analysis": extract_text(response.content),
        "current_step": "thinking",
        "token_usage": accumulate_usage(state_dict, extract_usage(response)),
    }


# ---------------------------------------------------------------------------
# Node: chunk
# ---------------------------------------------------------------------------


def chunk_node(state: AgentState) -> dict:
    """Run the selected chunking strategy on the file content.

    For multimodal files, chunking is skipped — the binary file
    is treated as a single unit and embedded directly.
    """
    if state.get("mode") == "multimodal":
        # No chunking for binary files — single embedding per file
        return {
            "chunk_strategy": "none",
            "chunks": [state.get("file_name", "multimodal_file")],
            "current_step": "coding",
        }

    text = state.get("file_content", "")
    strategy = state.get("chunk_strategy", "auto")
    provider = state.get("provider", "openai")
    model = state.get("model", "")

    resolved_strategy, chunks = run_chunking(
        text,
        strategy=strategy,
        provider=provider,
        model=model,
    )

    return {
        "chunk_strategy": resolved_strategy,
        "chunks": chunks,
        "current_step": "coding",
    }


# ---------------------------------------------------------------------------
# Node: embed_realtime
# ---------------------------------------------------------------------------


def embed_realtime_node(state: AgentState) -> dict:
    """Generate embeddings in realtime via provider SDK."""
    chunks = state.get("chunks", [])
    provider = state.get("provider", "openai")
    model = state.get("model", "")
    strategy = state.get("chunk_strategy", "paragraph")
    output_format = state.get("output_format", "similarity_report")

    # Cap chunks
    truncated_from = None
    if len(chunks) > MAX_REALTIME_CHUNKS:
        truncated_from = len(chunks)
        chunks = chunks[:MAX_REALTIME_CHUNKS]

    # Build embedding kwargs from state
    embed_kwargs: dict = {
        "provider": provider,
        "model": model,
    }
    if state.get("dimensions"):
        embed_kwargs["dimensions"] = state.get("dimensions")
    if state.get("encoding_format"):
        embed_kwargs["encoding_format"] = state.get("encoding_format")
    if state.get("input_type"):
        embed_kwargs["input_type"] = state.get("input_type")
    if state.get("output_dtype"):
        embed_kwargs["output_dtype"] = state.get("output_dtype")
    if state.get("task_type"):
        embed_kwargs["task_type"] = state.get("task_type")
    if strategy == "contextualized" and provider == "voyage":
        embed_kwargs["contextualized"] = True

    try:
        # Provider SDK calls are sync; if an event loop is already running,
        # run in a worker thread to avoid blocking.
        try:
            asyncio.get_running_loop()
            in_running_loop = True
        except RuntimeError:
            in_running_loop = False

        if in_running_loop:
            with concurrent.futures.ThreadPoolExecutor() as pool:
                embeddings = pool.submit(lambda: run_embedding(chunks, **embed_kwargs)).result()
        else:
            embeddings = run_embedding(chunks, **embed_kwargs)
    except Exception as e:
        return {
            "embeddings_result": f"Embedding generation failed ({provider}/{model}): {e}",
            "current_step": "coding",
        }

    # Build output based on format
    if output_format == "raw_json":
        result = build_raw_json(chunks, embeddings, provider, model)
    elif output_format == "raw_jsonl":
        result = build_raw_jsonl(chunks, embeddings, provider, model)
    else:
        result = build_similarity_report(
            chunks,
            embeddings,
            provider,
            model,
            file_name=state.get("file_name", "unknown"),
            strategy=strategy,
            dimensions_used=state.get("dimensions"),
            truncated_from=truncated_from,
        )

    return {
        "embeddings_result": result,
        "embeddings": embeddings,
        "chunks": chunks,
        "current_step": "coding",
    }


# ---------------------------------------------------------------------------
# Node: embed_multimodal
# ---------------------------------------------------------------------------


def embed_multimodal_node(state: AgentState) -> dict:
    """Generate embeddings for binary multimodal files (images, PDFs, video, audio)."""
    import base64

    provider = state.get("provider", "gemini")
    model = state.get("model", "gemini-embedding-2-preview")
    file_name = state.get("file_name", "unknown")
    mime_type = state.get("file_mime_type", "application/octet-stream")

    # Decode the base64 file bytes
    b64_data = state.get("file_bytes_b64", "")
    if not b64_data:
        return {
            "embeddings_result": "No binary file data found. Upload a file first.",
            "current_step": "coding",
        }

    try:
        file_bytes = base64.b64decode(b64_data)
    except Exception as e:
        return {
            "embeddings_result": f"Failed to decode file data: {e}",
            "current_step": "coding",
        }

    # Extract text context from the task for richer embeddings
    task = state.get("task", "")
    # Strip the file metadata block to get just the user instructions
    text_context = task.split("--- UPLOADED FILE:")[0].strip() or None

    embed_kwargs: dict = {
        "file_bytes": file_bytes,
        "mime_type": mime_type,
        "provider": provider,
        "model": model,
    }
    if state.get("dimensions"):
        embed_kwargs["dimensions"] = state.get("dimensions")
    if state.get("input_type"):
        embed_kwargs["input_type"] = state.get("input_type")
    if text_context:
        embed_kwargs["text_context"] = text_context

    try:
        try:
            asyncio.get_running_loop()
            in_running_loop = True
        except RuntimeError:
            in_running_loop = False

        if in_running_loop:
            with concurrent.futures.ThreadPoolExecutor() as pool:
                embeddings = pool.submit(lambda: run_multimodal_embedding(**embed_kwargs)).result()
        else:
            embeddings = run_multimodal_embedding(**embed_kwargs)
    except Exception as e:
        return {
            "embeddings_result": f"Multimodal embedding failed ({provider}/{model}): {e}",
            "current_step": "coding",
        }

    # Build report
    actual_dims = len(embeddings[0]) if embeddings else 0
    import json
    import math

    lines = [
        "## Multimodal Embedding Results",
        "",
        f"**Provider:** {provider} | **Model:** {model}",
        f"**File:** {file_name} ({mime_type})",
        f"**File size:** {len(file_bytes):,} bytes",
        f"**Dimensions:** {actual_dims}",
        f"**Embeddings generated:** {len(embeddings)}",
        "",
    ]

    if len(embeddings) == 1:
        norm = math.sqrt(sum(x * x for x in embeddings[0]))
        lines.extend(
            [
                "### Embedding Summary",
                f"- **Vector norm:** {norm:.4f}",
                f"- **Non-zero dimensions:** {sum(1 for x in embeddings[0] if abs(x) > 1e-8)}",
                f"- **Max value:** {max(embeddings[0]):.6f}",
                f"- **Min value:** {min(embeddings[0]):.6f}",
            ]
        )
    elif len(embeddings) > 1:
        # Multiple embeddings (e.g., multi-page PDF) — show similarity
        from agents.embeddings.analysis import compute_similarity_pairs

        pairs = compute_similarity_pairs(embeddings)
        if pairs:
            avg_sim = sum(p[2] for p in pairs) / len(pairs)
            lines.extend(
                [
                    "### Cross-page Similarity",
                    f"- **Average similarity:** {avg_sim:.4f}",
                    f"- **Most similar:** pages {pairs[0][0] + 1} & {pairs[0][1] + 1} ({pairs[0][2]:.4f})",
                    f"- **Least similar:** pages {pairs[-1][0] + 1} & {pairs[-1][1] + 1} ({pairs[-1][2]:.4f})",
                ]
            )

    # Raw data
    lines.extend(
        [
            "",
            "### Raw Data",
            "```json",
            json.dumps(
                {
                    "provider": provider,
                    "model": model,
                    "file": file_name,
                    "mime_type": mime_type,
                    "dimensions": actual_dims,
                    "embedding_count": len(embeddings),
                    "embeddings": [
                        {
                            "index": i,
                            "norm": round(math.sqrt(sum(x * x for x in emb)), 4),
                            "preview": emb[:8],
                        }
                        for i, emb in enumerate(embeddings)
                    ],
                },
                indent=2,
            ),
            "```",
        ]
    )

    return {
        "embeddings_result": "\n".join(lines),
        "embeddings": embeddings,
        "chunks": [file_name],
        "current_step": "coding",
    }


# ---------------------------------------------------------------------------
# Node: embed_batch
# ---------------------------------------------------------------------------


def embed_batch_node(state: AgentState) -> dict:
    """Generate batch JSONL + create batch job (or return JSONL for download)."""
    chunks = state.get("chunks", [])
    provider = state.get("provider", "openai")
    model = state.get("model", "")
    file_name = state.get("file_name", "unknown")

    # Build JSONL
    jsonl_kwargs: dict = {}
    if state.get("dimensions"):
        jsonl_kwargs["dimensions"] = state.get("dimensions")
    if state.get("input_type"):
        jsonl_kwargs["input_type"] = state.get("input_type")
    if state.get("output_dtype"):
        jsonl_kwargs["output_dtype"] = state.get("output_dtype")
    if state.get("task_type"):
        jsonl_kwargs["task_type"] = state.get("task_type")

    try:
        jsonl_content = build_jsonl(chunks, provider, model, **jsonl_kwargs)
        sidecar = build_metadata_sidecar(chunks, source_file=file_name)
    except Exception as e:
        return {
            "embeddings_result": f"JSONL generation failed ({provider}/{model}): {e}",
            "current_step": "coding",
        }

    # Try to create an actual batch job with the provider
    batch_result = None
    try:
        batch_result = create_batch(provider, jsonl_content)
    except Exception as e:
        logger.warning(f"Batch creation failed for {provider}: {e}. Returning JSONL only.")

    # Build output
    lines = [
        "## Batch Embedding Job",
        "",
        f"**Provider:** {provider} | **Model:** {model}",
        f"**Chunks:** {len(chunks)}",
        f"**File:** {file_name}",
        "",
    ]

    if batch_result and batch_result.get("status") not in ("jsonl_ready", None):
        batch_id = batch_result["batch_id"]
        lines.extend(
            [
                "### Batch Job Created",
                f"- **Batch ID:** `{batch_id}`",
                f"- **Status:** {batch_result['status']}",
                f"- **Provider:** {provider}",
                "",
                f"Poll status at: `GET /api/agents/embeddings-agent/batch/{batch_id}?provider={provider}`",
            ]
        )
        return {
            "embeddings_result": "\n".join(lines),
            "batch_job_id": batch_id,
            "batch_status": batch_result["status"],
            "metadata_sidecar": sidecar,
            "current_step": "coding",
        }

    # No live batch API — return JSONL for download
    lines.extend(
        [
            "### Batch JSONL (ready for submission)",
            "",
            "Download the JSONL below and submit it to the provider's batch API",
            f"for discounted processing ({provider}: "
            + ("50%" if provider in ("openai", "gemini") else "33%")
            + " off).",
            "",
            "#### Request JSONL",
            "```jsonl",
            jsonl_content[:5000] + ("\n..." if len(jsonl_content) > 5000 else ""),
            "```",
            "",
            "#### Metadata Sidecar",
            "```jsonl",
            sidecar[:3000] + ("\n..." if len(sidecar) > 3000 else ""),
            "```",
        ]
    )

    return {
        "embeddings_result": "\n".join(lines),
        "metadata_sidecar": sidecar,
        "current_step": "coding",
    }


# ---------------------------------------------------------------------------
# Node: review
# ---------------------------------------------------------------------------


def review_node(state: AgentState) -> dict:
    """LLM reviews the embedding results."""
    state_dict: dict[str, Any] = dict(state)
    llm = get_llm("embeddings-agent", temperature=0.2, max_tokens=2048, state=state_dict)

    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Review these embedding results for completeness and quality:\n\n"
                f"{state.get('embeddings_result', '')}\n\n"
                "Check for:\n"
                "1. Were all chunks processed successfully?\n"
                "2. Are the similarity scores reasonable?\n"
                "3. Any anomalies in the data (e.g., all similarities near 1.0)?\n"
                "4. Suggestions for the user (e.g., try different chunking, use a different model)?\n\n"
                "Rate: VECTORS_ALIGNED / NEEDS_RECALIBRATION / DATA_ERROR"
            ),
        ]
    )
    return {
        "review": extract_text(response.content),
        "current_step": "reviewing",
        "token_usage": accumulate_usage(state_dict, extract_usage(response)),
    }


# ---------------------------------------------------------------------------
# Conditional edge: after chunk, route to realtime or batch
# ---------------------------------------------------------------------------


def _after_chunk(state: AgentState) -> str:
    mode = state.get("mode", "realtime")
    if mode == "multimodal":
        return "embed_multimodal"
    if mode == "batch":
        return "embed_batch"
    return "embed_realtime"


# ---------------------------------------------------------------------------
# Graph builder
# ---------------------------------------------------------------------------


def build_embeddings_agent_graph():
    """Build and compile the embeddings agent LangGraph.

    State machine:
      route -> analyze -> chunk -> [conditional]
        REALTIME:   -> embed_realtime   -> review -> END
        BATCH:      -> embed_batch      -> review -> END
        MULTIMODAL: -> embed_multimodal -> review -> END
    """
    workflow = StateGraph(AgentState)

    workflow.add_node("route", route_node)
    workflow.add_node("analyze", analyze_node)
    workflow.add_node("chunk", chunk_node)
    workflow.add_node("embed_realtime", embed_realtime_node)
    workflow.add_node("embed_batch", embed_batch_node)
    workflow.add_node("embed_multimodal", embed_multimodal_node)
    workflow.add_node("review", review_node)

    workflow.set_entry_point("route")
    workflow.add_edge("route", "analyze")
    workflow.add_edge("analyze", "chunk")
    workflow.add_conditional_edges(
        "chunk",
        _after_chunk,
        {
            "embed_realtime": "embed_realtime",
            "embed_batch": "embed_batch",
            "embed_multimodal": "embed_multimodal",
        },
    )
    workflow.add_edge("embed_realtime", "review")
    workflow.add_edge("embed_batch", "review")
    workflow.add_edge("embed_multimodal", "review")
    workflow.add_edge("review", END)

    return workflow.compile()
