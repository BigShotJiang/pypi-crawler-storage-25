"""
Embeddings Agent package — multi-provider embedding with modular pipeline.
"""

from agents.embeddings.agent import build_embeddings_agent_graph

__all__ = ["build_embeddings_agent_graph"]
