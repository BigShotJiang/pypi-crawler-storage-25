"""
Agent registry for the vending-machine-mcp package.

13 specialized agents available via hire_agent().
"""

from agents.bug_hunter import build_bug_hunter_graph
from agents.cloud_sensei import build_cloud_sensei_graph
from agents.code_gremlin import build_code_gremlin_graph
from agents.data_sprite import build_data_sprite_graph
from agents.desk_pilot import build_desk_pilot_graph
from agents.devops_dwarf import build_devops_dwarf_graph
from agents.embeddings import build_embeddings_agent_graph
from agents.inbox_zero import build_inbox_zero_graph
from agents.mcp_maker import build_mcp_maker_graph
from agents.number_crunch import build_number_crunch_graph
from agents.pdf_forge import build_pdf_forge_graph
from agents.test_goblin import build_test_goblin_graph
from agents.vibe_writer import build_vibe_writer_graph

# Pre-compile agents at import time
AGENT_GRAPHS = {
    "code-gremlin": build_code_gremlin_graph(),
    "inbox-zero": build_inbox_zero_graph(),
    "vibe-writer": build_vibe_writer_graph(),
    "number-crunch": build_number_crunch_graph(),
    "mcp-maker": build_mcp_maker_graph(),
    "embeddings-agent": build_embeddings_agent_graph(),
    "bug-hunter": build_bug_hunter_graph(),
    "devops-dwarf": build_devops_dwarf_graph(),
    "test-goblin": build_test_goblin_graph(),
    "data-sprite": build_data_sprite_graph(),
    "pdf-forge": build_pdf_forge_graph(),
    "cloud-sensei": build_cloud_sensei_graph(),
    "desk-pilot": build_desk_pilot_graph(),
}

AGENT_NAMES = {
    "code-gremlin": "Code Gremlin",
    "inbox-zero": "Inbox Zero",
    "vibe-writer": "Vibe Writer",
    "number-crunch": "Number Crunch",
    "mcp-maker": "MCP Maker",
    "embeddings-agent": "Embeddings Agent",
    "bug-hunter": "Bug Hunter",
    "devops-dwarf": "DevOps Dwarf",
    "test-goblin": "Test Goblin",
    "data-sprite": "Data Sprite",
    "pdf-forge": "PDF Forge",
    "cloud-sensei": "Cloud Sensei",
    "desk-pilot": "Desk Pilot",
}


def build_initial_state(task: str, **extra) -> dict:
    """Build the initial state dict for any agent."""
    state = {
        "task": task,
        "current_step": "idle",
        "plan": "",
        "code": "",
        "review": "",
        "messages": [],
        "research": "",
        "analysis": "",
        "organization": "",
        "voice_analysis": "",
        "draft": "",
        "computation": "",
        "assessment": "",
        "recipe": "",
        "report": "",
        "file_content": "",
        "file_name": "",
        "provider": "",
        "embeddings_result": "",
        "model_override": None,
        "token_usage": {"input_tokens": 0, "output_tokens": 0},
    }
    state.update(extra)
    return state


def format_step_output(step: str, state_update: dict) -> str:
    """Format agent step output for display."""
    if step == "thinking":
        return (
            state_update.get("plan")
            or state_update.get("analysis")
            or state_update.get("voice_analysis")
            or state_update.get("assessment")
            or ""
        )
    elif step == "coding":
        return (
            state_update.get("code")
            or state_update.get("research")
            or state_update.get("report")
            or state_update.get("organization")
            or state_update.get("draft")
            or state_update.get("computation")
            or state_update.get("recipe")
            or state_update.get("embeddings_result")
            or ""
        )
    elif step == "researching":
        return state_update.get("research", "")
    elif step == "reviewing":
        return state_update.get("review", "")
    return ""


def estimate_tokens(text: str) -> int:
    """Rough token estimate (~3-4 chars per token)."""
    if not text:
        return 0
    return max(1, len(text) // 4)
