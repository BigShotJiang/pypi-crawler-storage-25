"""
DevOps Dwarf — Infrastructure, deployment, and CI/CD agent.

Uses gpt-5.3-codex for top-tier infrastructure-as-code generation.
Dockerfiles, Terraform, GitHub Actions, AWS CDK, Kubernetes manifests.
AWS IaC MCP server validates CloudFormation/CDK output automatically.

State machine: plan → build → validate → review → END
"""

import re
from typing import TypedDict

from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import END, StateGraph

from agents.llm import get_llm
from agents.parse import accumulate_usage, extract_text, extract_usage

AGENT_ID = "devops-dwarf"

SYSTEM_PROMPT = """You are DevOps Dwarf — a grizzled infrastructure engineer who lives inside a vending machine. You forge deployment pipelines, containerize applications, and build cloud infrastructure that doesn't fall over at 3am.

## Personality
- Pragmatic and battle-hardened. You've seen every deployment failure mode.
- You speak like a sysadmin: "Let me containerize that," "Here's your pipeline," "This deploys to..."
- You always include health checks, rollback strategies, and security best practices.
- You hate snowflake servers. Everything is code. Everything is reproducible.

## Specialties
- Docker / Podman — multi-stage builds, layer optimization, security scanning
- CI/CD — GitHub Actions, GitLab CI, CircleCI, Jenkins
- Infrastructure as Code — Terraform, AWS CDK, Pulumi, CloudFormation
- Kubernetes — Helm charts, manifests, service mesh
- Cloud — AWS (ECS, Lambda, EC2, S3, RDS), GCP, Azure
- Monitoring — Prometheus, Grafana, CloudWatch, Datadog

## Output Format
1. **DEPLOYMENT STRATEGY** — Overview of what we're building
2. **FILES** — Each file with full content in fenced code blocks
3. **SETUP INSTRUCTIONS** — Step-by-step commands to deploy
4. **SECURITY NOTES** — What's hardened and what needs attention
5. **ROLLBACK PLAN** — How to undo if things go wrong

## Rules
1. Generate complete, runnable files — no placeholders or TODOs.
2. Always use multi-stage Docker builds to minimize image size.
3. Never hardcode secrets — use env vars or secret managers.
4. Include health checks in every container/service definition.
5. Pin versions for reproducibility (base images, Terraform providers, dependencies).
6. Add comments explaining non-obvious configuration choices."""


class AgentState(TypedDict):
    task: str
    plan: str
    code: str
    validation: str
    review: str
    current_step: str
    messages: list


def plan_node(state: AgentState) -> dict:
    llm = get_llm(AGENT_ID, temperature=0.2, state=state)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"A user needs infrastructure/deployment work:\n\n{state['task']}\n\n"
                "Create a deployment plan (3-5 bullet points):\n"
                "- What files to generate?\n"
                "- What cloud services/tools to use?\n"
                "- Any security considerations?\n"
                "Be terse."
            ),
        ]
    )
    return {
        "plan": extract_text(response.content),
        "current_step": "thinking",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def build_node(state: AgentState) -> dict:
    llm = get_llm(AGENT_ID, temperature=0.2, state=state)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Infrastructure request: {state['task']}\n\n"
                f"Your plan:\n{state['plan']}\n\n"
                "Generate all files with complete, runnable content. "
                "Use your standard output format with full code blocks."
            ),
        ]
    )
    return {
        "code": extract_text(response.content),
        "current_step": "coding",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


# ---------------------------------------------------------------------------
# Template extraction helpers
# ---------------------------------------------------------------------------

# Matches JSON blocks that look like CloudFormation (contain AWSTemplateFormatVersion or Resources)
_CFN_JSON_RE = re.compile(
    r"```(?:json)?\s*\n(\{[^`]*?(?:AWSTemplateFormatVersion|Resources)[^`]*?\})\s*\n```",
    re.DOTALL,
)

# Matches YAML blocks that look like CloudFormation
_CFN_YAML_RE = re.compile(
    r"```(?:ya?ml)?\s*\n(.*?(?:AWSTemplateFormatVersion|Resources:).*?)\n```",
    re.DOTALL,
)

# Matches SAM template patterns
_SAM_RE = re.compile(
    r"```(?:ya?ml)?\s*\n(.*?(?:AWS::Serverless|Transform:.*AWS::Serverless).*?)\n```",
    re.DOTALL,
)


def _extract_cfn_templates(code: str) -> list[str]:
    """Extract CloudFormation/SAM templates from build output."""
    templates: list[str] = []

    for match in _CFN_JSON_RE.finditer(code):
        templates.append(match.group(1))

    for pattern in [_CFN_YAML_RE, _SAM_RE]:
        for match in pattern.finditer(code):
            text = match.group(1)
            if text not in templates:
                templates.append(text)

    return templates


async def validate_node(state: AgentState) -> dict:
    """Validate CloudFormation/CDK templates using the AWS IaC MCP server.

    Runs cfn-lint validation and cfn-guard compliance checking on any
    CloudFormation or SAM templates found in the build output.
    Gracefully passes through if IaC server is unavailable.
    """
    from agents.aws_mcp import check_cfn_compliance, get_iac_guidance, validate_cfn

    code = state.get("code", "")
    templates = _extract_cfn_templates(code)

    if not templates:
        return {"validation": "", "current_step": "validating"}

    results: list[str] = []

    for i, template in enumerate(templates[:3]):  # Limit to 3 templates
        label = f"Template {i + 1}" if len(templates) > 1 else "Template"

        # Validate syntax and schema
        validation = await validate_cfn(template)
        if validation and "[" not in validation[:5]:
            results.append(f"### {label} — Validation\n{validation}")

        # Check compliance (security/best practices)
        compliance = await check_cfn_compliance(template)
        if compliance and "[" not in compliance[:5]:
            results.append(f"### {label} — Compliance\n{compliance}")

    # If SAM/serverless detected, fetch SAM guidance
    if "AWS::Serverless" in code or "sam" in code.lower():
        sam_guidance = await get_iac_guidance("sam")
        if sam_guidance and "[" not in sam_guidance[:5]:
            results.append(f"### SAM Best Practices\n{sam_guidance}")

    return {
        "validation": "\n\n".join(results) if results else "",
        "current_step": "validating",
    }


def review_node(state: AgentState) -> dict:
    llm = get_llm(AGENT_ID, temperature=0.1, state=state)

    # Include validation results in the review context
    validation_context = ""
    validation = state.get("validation", "")
    if validation:
        validation_context = (
            f"\n\n## AWS IaC Validation Results (from cfn-lint + cfn-guard)\n"
            f"{validation[:6000]}\n"
            f"---\n"
            f"Address any validation errors or compliance violations in your review.\n"
        )

    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Review this infrastructure code:\n\n{state['code']}\n\n"
                f"{validation_context}"
                "Check: security hardening, version pinning, health checks, secret handling.\n"
                "Rate: DEPLOY_READY / NEEDS_HARDENING / MISCONFIGURED"
            ),
        ]
    )
    return {
        "review": extract_text(response.content),
        "current_step": "reviewing",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def build_devops_dwarf_graph() -> StateGraph:
    workflow = StateGraph(AgentState)
    workflow.add_node("plan", plan_node)
    workflow.add_node("build", build_node)
    workflow.add_node("validate", validate_node)
    workflow.add_node("review", review_node)
    workflow.set_entry_point("plan")
    workflow.add_edge("plan", "build")
    workflow.add_edge("build", "validate")
    workflow.add_edge("validate", "review")
    workflow.add_edge("review", END)
    return workflow.compile()
