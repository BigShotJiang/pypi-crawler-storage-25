"""
Number Crunch - LangGraph agent for data analysis and insights.

State machine: analyze → compute → review → END
"""

from typing import TypedDict

from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import END, StateGraph

from agents.llm import get_llm
from agents.parse import accumulate_usage, extract_text, extract_usage

AGENT_ID = "number-crunch"

SYSTEM_PROMPT = """You are Number Crunch — a sharp, data-obsessed analyst who lives inside a vending machine. You find patterns where others see noise.

## Personality
- Direct and numbers-driven. You let the data speak first.
- You love tables, percentages, and clean visualizations.
- You say things like "the data tells a different story" and "let me run the numbers."
- Skeptical of anecdotal evidence. You want sample sizes and confidence intervals.

## Specialties
- Spreadsheet analysis and formula creation
- Trend identification and forecasting
- Data cleaning and transformation logic
- Statistical summaries (mean, median, outliers, distributions)
- Chart/visualization recommendations
- KPI dashboards and metric definitions

## Rules
1. Always start with "What question are we trying to answer?"
2. Present numbers in context — raw numbers without benchmarks are useless.
3. Use tables and structured output for clarity.
4. Flag outliers and anomalies explicitly.
5. Suggest the right chart type for the data (bar, line, scatter, etc.).
6. If data is insufficient, say so. Never fabricate statistics.
7. Provide actionable insights, not just descriptions."""


class AgentState(TypedDict):
    task: str
    analysis: str
    computation: str
    review: str
    current_step: str


def _get_llm():
    return get_llm(AGENT_ID, temperature=0.2)


def analyze_node(state: AgentState) -> dict:
    llm = _get_llm()
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"A user needs data analysis:\n\n{state['task']}\n\n"
                "What's the core question? What data do we have vs need? "
                "Brief analysis plan (3-5 points). What metrics matter?"
            ),
        ]
    )
    return {
        "analysis": extract_text(response.content),
        "current_step": "thinking",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def compute_node(state: AgentState) -> dict:
    llm = _get_llm()
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Analysis task: {state['task']}\n\nYour plan:\n{state['analysis']}\n\n"
                "Now produce the full analysis. Include: data breakdown tables, "
                "key metrics, formulas or logic used, visualization recommendations, "
                "and actionable insights."
            ),
        ]
    )
    return {
        "computation": extract_text(response.content),
        "current_step": "coding",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def review_node(state: AgentState) -> dict:
    llm = _get_llm()
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Review this analysis:\n\n{state['computation']}\n\n"
                "Check for: calculation errors, misleading comparisons, missing context, "
                "and actionability of insights. Brief review (max 5 items). "
                "End with: CONFIDENCE: HIGH / MEDIUM / LOW."
            ),
        ]
    )
    return {
        "review": extract_text(response.content),
        "current_step": "reviewing",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def build_number_crunch_graph() -> StateGraph:
    workflow = StateGraph(AgentState)
    workflow.add_node("analyze", analyze_node)
    workflow.add_node("compute", compute_node)
    workflow.add_node("review", review_node)
    workflow.set_entry_point("analyze")
    workflow.add_edge("analyze", "compute")
    workflow.add_edge("compute", "review")
    workflow.add_edge("review", END)
    return workflow.compile()
