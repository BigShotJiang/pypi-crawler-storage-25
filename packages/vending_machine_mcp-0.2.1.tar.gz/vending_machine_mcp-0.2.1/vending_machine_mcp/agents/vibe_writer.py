"""
Vibe Writer - LangGraph agent for content creation and ghostwriting.

State machine: analyze_voice → draft → review → END
"""

from typing import TypedDict

from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import END, StateGraph

from agents.llm import get_llm
from agents.parse import accumulate_usage, extract_text, extract_usage

AGENT_ID = "vibe-writer"

SYSTEM_PROMPT = """You are the Vibe Writer — a smooth, adaptable ghostwriter who lives inside a vending machine. You turn rough ideas into polished content.

## Personality
- Chameleon-like. You match any tone the user needs.
- You think in formats: LinkedIn post, tweet thread, newsletter, email.
- Slightly witty, never cringe. You have taste.
- You say things like "let me find the voice here" and "the hook needs to hit harder."

## Specialties
- LinkedIn posts (professional, thought-leadership)
- Tweet/X threads (punchy, high-engagement)
- Newsletter intros and sections
- Professional emails (cold outreach, follow-ups, thank-yous)
- Blog post outlines and drafts
- Taglines and headlines

## Rules
1. Always ask yourself: "Who is the audience?" before writing.
2. Match the formality level to the platform.
3. Include a clear CTA (call-to-action) when appropriate.
4. Keep LinkedIn posts under 1300 characters. Tweets under 280.
5. Never use buzzwords without substance behind them.
6. If the user gives a rough draft, improve it — don't rewrite from scratch unless asked.
7. Provide 2-3 variations when doing headlines or taglines."""


class AgentState(TypedDict):
    task: str
    voice_analysis: str
    draft: str
    review: str
    current_step: str


def _get_llm():
    return get_llm(AGENT_ID, temperature=0.7)


def voice_node(state: AgentState) -> dict:
    llm = _get_llm()
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"A user hired you to write:\n\n{state['task']}\n\n"
                "Analyze: What's the target platform? Audience? Tone? "
                "Brief voice analysis (3-5 points). What format(s) will you produce?"
            ),
        ]
    )
    return {
        "voice_analysis": extract_text(response.content),
        "current_step": "thinking",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def draft_node(state: AgentState) -> dict:
    llm = _get_llm()
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Writing task: {state['task']}\n\nVoice analysis:\n{state['voice_analysis']}\n\n"
                "Now write the content. If multiple formats were identified, produce each one. "
                "Label each format clearly. Make it polished and ready to post/send."
            ),
        ]
    )
    return {
        "draft": extract_text(response.content),
        "current_step": "coding",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def review_node(state: AgentState) -> dict:
    llm = _get_llm()
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Review this content:\n\n{state['draft']}\n\n"
                "Check: tone consistency, length for platform, CTA effectiveness, "
                "any cringe or buzzword offenses. Brief review (max 5 items). "
                "End with: VIBE CHECK: [FIRE / SOLID / NEEDS WORK]."
            ),
        ]
    )
    return {
        "review": extract_text(response.content),
        "current_step": "reviewing",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def build_vibe_writer_graph() -> StateGraph:
    workflow = StateGraph(AgentState)
    workflow.add_node("voice", voice_node)
    workflow.add_node("draft", draft_node)
    workflow.add_node("review", review_node)
    workflow.set_entry_point("voice")
    workflow.add_edge("voice", "draft")
    workflow.add_edge("draft", "review")
    workflow.add_edge("review", END)
    return workflow.compile()
