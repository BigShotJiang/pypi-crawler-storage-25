"""
Inbox Zero - LangGraph agent for email triage and organization.

State machine: analyze → organize → review → END
"""

from typing import TypedDict

from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import END, StateGraph

from agents.llm import get_llm
from agents.parse import accumulate_usage, extract_text, extract_usage

AGENT_ID = "inbox-zero"

SYSTEM_PROMPT = """You are Inbox Zero — a calm, hyper-organized productivity assistant who lives inside a vending machine. You tame email chaos.

## Personality
- Zen-like calm. You speak in short, reassuring sentences.
- You categorize everything. Labels are your love language.
- You're gently encouraging: "You're doing great. Let's sort this out."
- You think in systems and workflows, not one-off fixes.

## Specialties
- Email triage and prioritization (urgent / action-needed / FYI / archive)
- Drafting professional replies
- Meeting summary extraction from email threads
- Newsletter/subscription audit
- Follow-up tracking and reminder suggestions

## Rules
1. Always categorize items into clear priority buckets.
2. Suggest specific labels or folder names.
3. For draft replies: match the sender's formality level.
4. Flag anything that looks like it needs a response within 24 hours.
5. Be concise — inbox overwhelm is the enemy.
6. Never assume access to actual email. Work with what the user describes or pastes."""


class AgentState(TypedDict):
    task: str
    analysis: str
    organization: str
    review: str
    current_step: str


def _get_llm():
    return get_llm(AGENT_ID, temperature=0.3)


def analyze_node(state: AgentState) -> dict:
    llm = _get_llm()
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"A user needs help with their inbox:\n\n{state['task']}\n\n"
                "First, analyze the situation. What's the inbox problem? "
                "What categories or patterns do you see? Brief analysis (3-5 points)."
            ),
        ]
    )
    return {
        "analysis": extract_text(response.content),
        "current_step": "thinking",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def organize_node(state: AgentState) -> dict:
    llm = _get_llm()
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Inbox task: {state['task']}\n\nYour analysis:\n{state['analysis']}\n\n"
                "Now provide the full organizational plan or draft responses. "
                "Use clear sections: Priority Buckets, Suggested Labels, Draft Replies (if applicable), "
                "and Follow-up Reminders."
            ),
        ]
    )
    return {
        "organization": extract_text(response.content),
        "current_step": "coding",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def review_node(state: AgentState) -> dict:
    llm = _get_llm()
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Review this inbox organization plan:\n\n{state['organization']}\n\n"
                "Check for: missed priorities, tone issues in drafts, any follow-ups that might slip. "
                "Brief review (max 5 items). End with: INBOX STATUS: [TAMED / NEEDS ATTENTION / CRITICAL]."
            ),
        ]
    )
    return {
        "review": extract_text(response.content),
        "current_step": "reviewing",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def build_inbox_zero_graph() -> StateGraph:
    workflow = StateGraph(AgentState)
    workflow.add_node("analyze", analyze_node)
    workflow.add_node("organize", organize_node)
    workflow.add_node("review", review_node)
    workflow.set_entry_point("analyze")
    workflow.add_edge("analyze", "organize")
    workflow.add_edge("organize", "review")
    workflow.add_edge("review", END)
    return workflow.compile()
