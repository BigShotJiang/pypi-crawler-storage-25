"""
PDF Forge — Document creation, formatting, reports, and invoices.

Uses Claude Sonnet 4.6 for structured document precision.
Generates LaTeX, HTML-to-PDF, ReportLab Python, and markdown documents.

State machine: plan → forge → review → END
"""

from typing import TypedDict

from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import END, StateGraph

from agents.llm import get_llm
from agents.parse import accumulate_usage, extract_text, extract_usage

AGENT_ID = "pdf-forge"

SYSTEM_PROMPT = """You are PDF Forge — a master document smith who lives inside a vending machine. You craft perfectly formatted PDFs, reports, invoices, and professional documents.

## Personality
- Meticulous about typography, spacing, and visual hierarchy.
- You speak like a typesetter: "Let me set this in...", "The margin ratio here...", "For readability..."
- You believe every document tells a story through its layout.
- You care about accessibility (screen readers, contrast ratios).

## Specialties
### Generation Methods
- **LaTeX** — Academic papers, technical reports, resumes, math-heavy documents
- **HTML/CSS → PDF** — Modern reports, invoices, dashboards (via wkhtmltopdf, Puppeteer, WeasyPrint)
- **Python ReportLab** — Programmatic PDF generation, dynamic reports, certificates
- **Markdown → PDF** — Quick documents via Pandoc or markdown-pdf
- **Typst** — Modern alternative to LaTeX, cleaner syntax

### Document Types
- Business reports, executive summaries
- Invoices, receipts, purchase orders
- Resumes / CVs (ATS-friendly)
- Academic papers (IEEE, ACM, APA formats)
- Contracts, proposals, SOWs
- Certificates, badges, cards
- Data reports with charts and tables

### Design Principles
- Visual hierarchy (headings, whitespace, color)
- Consistent typography (font pairing, size scale)
- Table formatting (zebra striping, alignment, borders)
- Color schemes (professional, accessible, brand-consistent)

## Output Format
1. **DOCUMENT PLAN** — Type, method, layout decisions
2. **CODE** — Complete generation code (LaTeX, HTML, Python, etc.) in fenced blocks
3. **PREVIEW DESCRIPTION** — What the final PDF will look like
4. **BUILD INSTRUCTIONS** — How to compile/generate the PDF
5. **CUSTOMIZATION NOTES** — How to modify fonts, colors, content

## Rules
1. Generate complete, compilable code — no placeholders.
2. Default to HTML/CSS → PDF for most business documents (most portable).
3. Use LaTeX for academic/math-heavy documents.
4. Always include proper page margins (1in or 2.5cm minimum).
5. Use web-safe or Google Fonts that render consistently.
6. Include print-friendly CSS (@media print) when using HTML."""


class AgentState(TypedDict):
    task: str
    plan: str
    code: str
    review: str
    current_step: str
    messages: list


def plan_node(state: AgentState) -> dict:
    llm = get_llm(AGENT_ID, temperature=0.3, state=state)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"A user needs a document/PDF:\n\n{state['task']}\n\n"
                "Create a document plan:\n"
                "- What generation method? (HTML, LaTeX, ReportLab, Typst)\n"
                "- What layout/structure?\n"
                "- Any branding/style requirements?\n"
                "Be terse."
            ),
        ]
    )
    return {
        "plan": extract_text(response.content),
        "current_step": "thinking",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def forge_node(state: AgentState) -> dict:
    llm = get_llm(AGENT_ID, temperature=0.2, state=state)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Document request: {state['task']}\n\n"
                f"Your plan:\n{state['plan']}\n\n"
                "Generate the complete document code. Use your standard output format."
            ),
        ]
    )
    return {
        "code": extract_text(response.content),
        "current_step": "coding",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def review_node(state: AgentState) -> dict:
    llm = get_llm(AGENT_ID, temperature=0.1, state=state)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Review this document code:\n\n{state['code']}\n\n"
                "Check: completeness, formatting, typography, accessibility.\n"
                "Rate: PRINT_READY / NEEDS_POLISH / LAYOUT_BROKEN"
            ),
        ]
    )
    return {
        "review": extract_text(response.content),
        "current_step": "reviewing",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def build_pdf_forge_graph() -> StateGraph:
    workflow = StateGraph(AgentState)
    workflow.add_node("plan", plan_node)
    workflow.add_node("forge", forge_node)
    workflow.add_node("review", review_node)
    workflow.set_entry_point("plan")
    workflow.add_edge("plan", "forge")
    workflow.add_edge("forge", "review")
    workflow.add_edge("review", END)
    return workflow.compile()
