"""
Cloud Sensei — AWS architecture, troubleshooting, and cloud guidance agent.

Uses Xiaomi MiMo V2 Pro — 1M context, top-tier reasoning, agentic workflows.
Uses AWS MCP servers for live documentation, knowledge, pricing, and SOPs.

State machine: assess → research → advise → review → END
"""

from typing import TypedDict

from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import END, StateGraph

from agents.llm import get_llm
from agents.parse import accumulate_usage, extract_text, extract_usage

AGENT_ID = "cloud-sensei"

SYSTEM_PROMPT = """You are Cloud Sensei — a wise cloud architect who lives inside a vending machine. You've designed, deployed, and debugged AWS infrastructure at every scale, from a single Lambda to a multi-region fortress.

## Personality
- Calm and authoritative. You've seen every AWS failure mode.
- You speak like a sensei: "The path forward is...", "Consider this architecture...", "The root cause lies in..."
- You always think about cost, security, reliability, and operational excellence.
- You reference AWS Well-Architected Framework pillars naturally.

## AWS Expertise (comprehensive)
### Compute
- Lambda (functions, layers, extensions, provisioned concurrency, SnapStart)
- ECS / Fargate (task definitions, services, capacity providers, service connect)
- EC2 (instance types, spot, graviton, placement groups, dedicated hosts)
- App Runner, Elastic Beanstalk, Lightsail
- Step Functions (Standard, Express, distributed map)

### Storage & Database
- S3 (lifecycle, replication, intelligent tiering, access points, Object Lambda)
- DynamoDB (single-table design, GSI/LSI, DAX, Streams, Global Tables)
- RDS / Aurora (Serverless v2, read replicas, proxy, Blue/Green deployments)
- ElastiCache (Redis, Memcached), DocumentDB, Neptune, Timestream, QLDB
- EFS, FSx, EBS (gp3, io2, st1)

### Networking
- VPC (subnets, route tables, NAT, VPC endpoints, peering, Transit Gateway)
- CloudFront (OAC, Lambda@Edge, CloudFront Functions, cache policies)
- Route 53 (routing policies, health checks, DNSSEC)
- API Gateway (REST, HTTP, WebSocket), ALB, NLB, Global Accelerator
- PrivateLink, Direct Connect, Site-to-Site VPN

### Security & Identity
- IAM (policies, roles, permission boundaries, SCP, identity center)
- Cognito (user pools, identity pools, hosted UI, custom auth)
- KMS, Secrets Manager, Parameter Store, Certificate Manager
- WAF, Shield, GuardDuty, Security Hub, Inspector, Macie
- CloudTrail, Config, Access Analyzer

### DevOps & Observability
- CloudFormation, CDK, SAM, Terraform
- CodePipeline, CodeBuild, CodeDeploy
- CloudWatch (metrics, logs, alarms, dashboards, Logs Insights, Synthetics)
- X-Ray, Application Signals, EventBridge
- Systems Manager (Patch Manager, Session Manager, Run Command)

### AI/ML & Analytics
- Bedrock (Claude, Titan, custom models, knowledge bases, agents)
- SageMaker (training, inference, endpoints, pipelines)
- Athena, Glue, EMR, Redshift, Lake Formation, QuickSight
- Kinesis (Data Streams, Firehose, Analytics)

## Output Format
1. **ASSESSMENT** — Current situation and key concerns
2. **ARCHITECTURE** — Recommended design with service selection rationale
3. **IMPLEMENTATION** — IaC code (CDK/Terraform/CloudFormation) or CLI commands
4. **SECURITY** — IAM policies, encryption, network isolation
5. **COST ESTIMATE** — Monthly cost breakdown for the proposed architecture
6. **OPERATIONAL** — Monitoring, alerting, backup, disaster recovery

## Rules
1. Always consider cost — suggest the cheapest option that meets requirements.
2. Security by default — least privilege IAM, encryption everywhere, private subnets.
3. Include actual IaC code or CLI commands, not just descriptions.
4. Reference specific AWS documentation or service limits when relevant.
5. Consider multi-AZ and disaster recovery for production workloads.
6. Suggest AWS Well-Architected Framework pillar improvements."""


class AgentState(TypedDict):
    task: str
    plan: str
    research: str  # AWS docs + knowledge + pricing content
    code: str
    review: str
    current_step: str
    messages: list


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

# Common AWS service name → pricing service code mapping
_SERVICE_CODES: dict[str, str] = {
    "lambda": "AWSLambda",
    "ec2": "AmazonEC2",
    "s3": "AmazonS3",
    "dynamodb": "AmazonDynamoDB",
    "rds": "AmazonRDS",
    "ecs": "AmazonECS",
    "fargate": "AmazonECS",
    "cloudfront": "AmazonCloudFront",
    "api gateway": "AmazonApiGateway",
    "sqs": "AWSQueueService",
    "sns": "AmazonSNS",
    "elasticache": "AmazonElastiCache",
    "bedrock": "AmazonBedrock",
    "sagemaker": "AmazonSageMaker",
    "step functions": "AWSStepFunctions",
}


def _extract_service_codes(text: str) -> list[str]:
    """Extract AWS service pricing codes from text."""
    text_lower = text.lower()
    codes = []
    for keyword, code in _SERVICE_CODES.items():
        if keyword in text_lower and code not in codes:
            codes.append(code)
    return codes[:3]  # Limit to top 3 to avoid excessive API calls


# ---------------------------------------------------------------------------
# Graph nodes
# ---------------------------------------------------------------------------


def assess_node(state: AgentState) -> dict:
    """Analyze the question and identify which AWS services/topics to research."""
    llm = get_llm(AGENT_ID, temperature=0.2, state=state)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"A user needs AWS guidance:\n\n{state['task']}\n\n"
                "Assess the situation:\n"
                "- What AWS services are involved?\n"
                "- What's the scale/requirements?\n"
                "- Key architectural decisions to make?\n"
                "- Any compliance/security requirements?\n"
                "- What specific documentation topics should I look up?\n"
                "Be terse. List 2-3 specific search queries for AWS docs."
            ),
        ]
    )
    return {
        "plan": extract_text(response.content),
        "current_step": "thinking",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


async def research_node(state: AgentState) -> dict:
    """Fetch relevant AWS documentation, knowledge, SOPs, and pricing.

    Uses multiple AWS MCP servers for comprehensive research:
    - AWS Documentation — official docs and API references
    - AWS Knowledge — What's New, blogs, Well-Architected, Agent SOPs
    - AWS Pricing — real-time pricing for mentioned services
    """
    from agents.aws_mcp import get_agent_sops, get_pricing, search_docs, search_knowledge

    task = state["task"]
    plan = state.get("plan", "")

    sections: list[str] = []

    # 1. Search official AWS documentation
    doc_results = await search_docs(task[:200], limit=5)
    if doc_results and "[" not in doc_results[:5]:
        sections.append(f"## AWS Documentation\n\n{doc_results}")

    # Supplementary docs search based on assessment keywords
    keywords = [w for w in plan.split() if w[0:1].isupper() and len(w) > 3] if plan else []
    if keywords:
        service_query = " ".join(keywords[:5])
        supplementary = await search_docs(service_query, topics=["reference_documentation"], limit=3)
        if supplementary and "[" not in supplementary[:5]:
            sections.append(f"## Additional Reference\n\n{supplementary}")

    # 2. Search broader AWS Knowledge base (What's New, blogs, Well-Architected)
    knowledge_results = await search_knowledge(task[:200], limit=5)
    if knowledge_results and "[" not in knowledge_results[:5]:
        sections.append(f"## AWS Knowledge Base\n\n{knowledge_results}")

    # 3. Get step-by-step SOPs if applicable
    sop_results = await get_agent_sops(task[:200])
    if sop_results and "[" not in sop_results[:5]:
        sections.append(f"## AWS Agent SOPs\n\n{sop_results}")

    # 4. Get pricing for mentioned services (best-effort)
    service_codes = _extract_service_codes(f"{task} {plan}")
    pricing_parts: list[str] = []
    for code in service_codes:
        pricing = await get_pricing(code)
        if pricing and "[" not in pricing[:5]:
            pricing_parts.append(pricing)
    if pricing_parts:
        sections.append("## AWS Pricing\n\n" + "\n\n".join(pricing_parts))

    combined = "\n\n".join(sections) if sections else "[AWS MCP servers unavailable]"
    return {"research": combined, "current_step": "researching"}


def advise_node(state: AgentState) -> dict:
    """Generate guidance grounded in real AWS documentation."""
    llm = get_llm(AGENT_ID, temperature=0.2, state=state)

    doc_context = state.get("research", "")
    doc_section = ""
    if doc_context and "[AWS" not in doc_context[:20]:
        doc_section = (
            f"\n\n## Relevant AWS Research (LIVE — use this to ground your answer)\n"
            f"{doc_context[:12000]}\n"
            f"---\n"
            f"IMPORTANT: Reference specific documentation pages and service details from above. "
            f"Cite documentation URLs where applicable. Use pricing data for cost estimates.\n"
        )

    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"AWS task: {state['task']}\n\n"
                f"Your assessment:\n{state['plan']}\n"
                f"{doc_section}\n"
                "Provide comprehensive guidance using your standard output format. "
                "Include IaC code, CLI commands, cost estimates, and security hardening. "
                "Reference the documentation above where relevant."
            ),
        ]
    )
    return {
        "code": extract_text(response.content),
        "current_step": "coding",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


async def review_node(state: AgentState) -> dict:
    """Quality check against Well-Architected Framework with live guidance."""
    from agents.aws_mcp import search_knowledge

    # Fetch live Well-Architected guidance to ground the review
    wa_guidance = await search_knowledge(
        "Well-Architected Framework pillars cost security reliability performance operational excellence"
    )
    wa_section = ""
    if wa_guidance and "[" not in wa_guidance[:5]:
        wa_section = f"\n\nLive Well-Architected guidance:\n{wa_guidance[:4000]}\n"

    llm = get_llm(AGENT_ID, temperature=0.1, state=state)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Review this AWS architecture/guidance:\n\n{state['code']}\n\n"
                f"{wa_section}"
                "Check against Well-Architected pillars: cost, security, reliability, performance, operational excellence.\n"
                "Rate: WELL_ARCHITECTED / NEEDS_REVIEW / ANTI_PATTERN"
            ),
        ]
    )
    return {
        "review": extract_text(response.content),
        "current_step": "reviewing",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def build_cloud_sensei_graph() -> StateGraph:
    workflow = StateGraph(AgentState)
    workflow.add_node("assess", assess_node)
    workflow.add_node("research", research_node)
    workflow.add_node("advise", advise_node)
    workflow.add_node("review", review_node)
    workflow.set_entry_point("assess")
    workflow.add_edge("assess", "research")
    workflow.add_edge("research", "advise")
    workflow.add_edge("advise", "review")
    workflow.add_edge("review", END)
    return workflow.compile()
