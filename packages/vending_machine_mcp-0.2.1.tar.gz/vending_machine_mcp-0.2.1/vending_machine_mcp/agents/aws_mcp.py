"""
Unified AWS MCP client — calls any awslabs MCP server via subprocess.

All calls run in a clean Python subprocess (via _mcp_worker.py) to avoid
anyio/pydantic import conflicts between langchain and the MCP client.

Supports both stdio (uvx) and HTTP (remote) MCP servers.

Usage:
    from agents.aws_mcp import search_docs, validate_cfn, get_pricing
    result = await search_docs("S3 bucket naming rules", limit=3)
"""

import asyncio
import json
import logging
import os
import subprocess
import sys

logger = logging.getLogger("aws-mcp")

_WORKER_SCRIPT = os.path.join(os.path.dirname(__file__), "_mcp_worker.py")

# ---------------------------------------------------------------------------
# Server registry — maps logical names to server URIs
# ---------------------------------------------------------------------------

AWS_MCP_SERVERS: dict[str, str] = {
    # Documentation & Knowledge
    "docs": "awslabs.aws-documentation-mcp-server@latest",
    "knowledge": "https://knowledge-mcp.global.api.aws",
    # Infrastructure as Code
    "iac": "awslabs.aws-iac-mcp-server@latest",
    "cfn": "awslabs.cfn-mcp-server@latest",  # deprecated, kept for compat
    # Serverless & Functions
    "serverless": "awslabs.aws-serverless-mcp-server@latest",
    "lambda": "awslabs.lambda-tool-mcp-server@latest",
    # AI & ML (Bedrock)
    "bedrock-kb": "awslabs.bedrock-kb-retrieval-mcp-server@latest",
    "bedrock-models": "awslabs.aws-bedrock-custom-model-import-mcp-server@latest",
    "agentcore": "awslabs.amazon-bedrock-agentcore-mcp-server@latest",
    # Data
    "dynamodb": "awslabs.dynamodb-mcp-server@latest",
    # Caching
    "elasticache": "awslabs.elasticache-mcp-server@latest",
    "memcached": "awslabs.memcached-mcp-server@latest",
    # Cost & Pricing
    "pricing": "awslabs.aws-pricing-mcp-server@latest",
    # Security
    "iam": "awslabs.iam-mcp-server@latest",
    # Messaging & Integration
    "sns-sqs": "awslabs.amazon-sns-sqs-mcp-server@latest",
    "stepfunctions": "awslabs.stepfunctions-tool-mcp-server@latest",
    # Containers
    "finch": "awslabs.finch-mcp-server@latest",
    # API
    "openapi": "awslabs.openapi-mcp-server@latest",
}


# ---------------------------------------------------------------------------
# Core: subprocess-based tool caller
# ---------------------------------------------------------------------------


def _call_tool_sync(server: str, tool_name: str, arguments: dict, timeout: int = 45) -> str:
    """Call an MCP tool via a clean subprocess. Synchronous."""
    server_uri = AWS_MCP_SERVERS.get(server, server)
    try:
        result = subprocess.run(
            [sys.executable, _WORKER_SCRIPT, server_uri, tool_name, json.dumps(arguments)],
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=os.path.dirname(os.path.dirname(__file__)),
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()
        error = result.stderr.strip() or "Unknown error"
        logger.warning("MCP worker failed (%s/%s): %s", server, tool_name, error)
        return f"[{server} unavailable: {error}]"
    except subprocess.TimeoutExpired:
        return f"[{server} timed out after {timeout}s]"
    except Exception as e:
        return f"[{server} unavailable: {e}]"


async def call_tool(server: str, tool_name: str, arguments: dict, timeout: int = 45) -> str:
    """Call an MCP tool via a clean subprocess. Async (runs in executor)."""
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, _call_tool_sync, server, tool_name, arguments, timeout)


# ---------------------------------------------------------------------------
# Documentation & Knowledge
# ---------------------------------------------------------------------------


async def search_docs(query: str, limit: int = 5, topics: list[str] | None = None) -> str:
    """Search AWS documentation (awslabs.aws-documentation-mcp-server)."""
    args: dict = {"search_phrase": query, "limit": limit}
    if topics:
        args["product_types"] = topics
    return await call_tool("docs", "search_documentation", args)


async def read_doc(url: str, max_length: int = 10000) -> str:
    """Fetch and convert an AWS documentation page to markdown."""
    return await call_tool("docs", "read_documentation", {"url": url})


async def read_doc_sections(url: str, sections: list[str]) -> str:
    """Extract specific sections from an AWS documentation page."""
    return await call_tool("docs", "read_sections", {"url": url, "section": sections})


async def recommend_docs(url: str) -> str:
    """Get content recommendations for an AWS documentation page."""
    return await call_tool("docs", "recommend", {"url": url})


async def search_knowledge(query: str, limit: int = 5) -> str:
    """Search AWS Knowledge base — docs, What's New, blogs, Well-Architected."""
    return await call_tool("knowledge", "search_documentation", {"search_phrase": query, "limit": limit})


async def get_agent_sops(task: str) -> str:
    """Get step-by-step AWS workflows (Agent SOPs) for a task."""
    return await call_tool("knowledge", "retrieve_agent_sops", {"query": task})


async def get_regional_availability(service: str) -> str:
    """Check regional availability for an AWS service."""
    return await call_tool("knowledge", "get_regional_availability", {"service": service})


async def list_regions() -> str:
    """List all AWS regions with identifiers and names."""
    return await call_tool("knowledge", "list_regions", {})


# ---------------------------------------------------------------------------
# Infrastructure as Code
# ---------------------------------------------------------------------------


async def validate_cfn(template_content: str, regions: list[str] | None = None) -> str:
    """Validate a CloudFormation template (syntax, schema, resource properties)."""
    args: dict = {"template_content": template_content}
    if regions:
        args["regions"] = regions
    return await call_tool("iac", "validate_cloudformation_template", args)


async def check_cfn_compliance(template_content: str, custom_rules: str | None = None) -> str:
    """Check CloudFormation template against security/compliance rules."""
    args: dict = {"template_content": template_content}
    if custom_rules:
        args["custom_rules"] = custom_rules
    return await call_tool("iac", "check_cloudformation_template_compliance", args)


async def search_cfn_docs(query: str) -> str:
    """Search official CloudFormation documentation."""
    return await call_tool("iac", "search_cloudformation_documentation", {"query": query})


async def search_cdk_docs(query: str) -> str:
    """Search AWS CDK API Reference, Best Practices, CDK-NAG rules."""
    return await call_tool("iac", "search_cdk_documentation", {"query": query})


async def search_cdk_samples(query: str, language: str = "typescript") -> str:
    """Find CDK code examples, working samples, and community constructs."""
    return await call_tool("iac", "search_cdk_samples_and_constructs", {"query": query, "language": language})


async def get_cdk_best_practices() -> str:
    """Get comprehensive CDK best practices guidelines."""
    return await call_tool("iac", "cdk_best_practices", {})


async def read_iac_doc(url: str) -> str:
    """Fetch and convert a CloudFormation or CDK documentation page to markdown."""
    return await call_tool("iac", "read_iac_documentation_page", {"url": url})


async def get_cfn_predeploy_validation() -> str:
    """Get CLI commands for CloudFormation pre-deployment validation."""
    return await call_tool("iac", "get_cloudformation_pre_deploy_validation_instructions", {})


# ---------------------------------------------------------------------------
# Serverless & Lambda
# ---------------------------------------------------------------------------


async def get_lambda_guidance(use_case: str) -> str:
    """Get Lambda best practices for a given use case."""
    return await call_tool("serverless", "get_lambda_guidance", {"use_case": use_case})


async def get_lambda_event_schemas(event_source: str, runtime: str = "python") -> str:
    """Get Lambda event schemas for a specific event source."""
    return await call_tool("serverless", "get_lambda_event_schemas", {"event_source": event_source, "runtime": runtime})


async def get_serverless_templates(template_type: str, runtime: str = "python") -> str:
    """Get serverless application templates."""
    return await call_tool(
        "serverless", "get_serverless_templates", {"template_type": template_type, "runtime": runtime}
    )


async def get_iac_guidance(iac_tool: str = "sam", include_examples: bool = True) -> str:
    """Get IaC guidance for SAM, CDK, or Terraform."""
    return await call_tool(
        "serverless", "get_iac_guidance", {"iac_tool": iac_tool, "include_examples": include_examples}
    )


async def deploy_serverless_help(application_type: str) -> str:
    """Get help for deploying a serverless application."""
    return await call_tool("serverless", "deploy_serverless_app_help", {"application_type": application_type})


# ---------------------------------------------------------------------------
# Pricing & Cost
# ---------------------------------------------------------------------------


async def get_pricing(service_code: str, region: str | None = None) -> str:
    """Get real-time AWS pricing for a service."""
    args: dict = {"service_code": service_code}
    if region:
        args["region"] = region
    return await call_tool("pricing", "get_pricing", args)


async def get_pricing_service_codes(filter_str: str | None = None) -> str:
    """List available AWS pricing service codes."""
    args: dict = {}
    if filter_str:
        args["filter"] = filter_str
    return await call_tool("pricing", "get_pricing_service_codes", args)


async def analyze_cdk_costs(project_path: str) -> str:
    """Analyze costs for a CDK project."""
    return await call_tool("pricing", "analyze_cdk_project", {"project_path": project_path})


async def analyze_terraform_costs(project_path: str) -> str:
    """Analyze costs for a Terraform project."""
    return await call_tool("pricing", "analyze_terraform_project", {"project_path": project_path})


async def generate_cost_report(
    pricing_data: dict,
    service_name: str,
    output_format: str = "markdown",
) -> str:
    """Generate a formatted cost report."""
    return await call_tool(
        "pricing",
        "generate_cost_report",
        {"pricing_data": pricing_data, "service_name": service_name, "format": output_format},
    )


# ---------------------------------------------------------------------------
# Data (DynamoDB)
# ---------------------------------------------------------------------------


async def dynamodb_data_modeling() -> str:
    """Get DynamoDB data modeling guidance."""
    return await call_tool("dynamodb", "dynamodb_data_modeling", {})


async def dynamodb_validate_model() -> str:
    """Validate a DynamoDB data model."""
    return await call_tool("dynamodb", "dynamodb_data_model_validation", {})


async def dynamodb_generate_resources(resource_type: str) -> str:
    """Generate DynamoDB resources (CloudFormation, CDK, etc.)."""
    return await call_tool("dynamodb", "generate_resources", {"resource_type": resource_type})


# ---------------------------------------------------------------------------
# Security (IAM)
# ---------------------------------------------------------------------------


async def list_iam_roles(path_prefix: str | None = None) -> str:
    """List IAM roles."""
    args: dict = {}
    if path_prefix:
        args["path_prefix"] = path_prefix
    return await call_tool("iam", "list_roles", args)


async def simulate_iam_policy(
    policy_source_arn: str,
    action_names: list[str],
    resource_arns: list[str] | None = None,
) -> str:
    """Simulate an IAM policy to check permissions."""
    args: dict = {"policy_source_arn": policy_source_arn, "action_names": action_names}
    if resource_arns:
        args["resource_arns"] = resource_arns
    return await call_tool("iam", "simulate_principal_policy", args)


# ---------------------------------------------------------------------------
# Bedrock
# ---------------------------------------------------------------------------


async def query_knowledge_base(query: str, kb_id: str, num_results: int = 5) -> str:
    """Query an Amazon Bedrock Knowledge Base."""
    return await call_tool(
        "bedrock-kb",
        "QueryKnowledgeBases",
        {"query": query, "knowledge_base_id": kb_id, "number_of_results": num_results},
    )


async def list_knowledge_bases() -> str:
    """List available Bedrock Knowledge Bases."""
    return await call_tool("bedrock-kb", "ListKnowledgeBases", {})


async def search_agentcore_docs(query: str) -> str:
    """Search AgentCore platform documentation."""
    return await call_tool("agentcore", "search_agentcore_docs", {"query": query})


# ---------------------------------------------------------------------------
# Messaging & Integration
# ---------------------------------------------------------------------------


async def publish_sns(topic_arn: str, message: str) -> str:
    """Publish a message to an SNS topic."""
    return await call_tool("sns-sqs", "publish", {"TopicArn": topic_arn, "Message": message})


async def send_sqs_message(queue_url: str, message_body: str) -> str:
    """Send a message to an SQS queue."""
    return await call_tool("sns-sqs", "send_message", {"QueueUrl": queue_url, "MessageBody": message_body})


# ---------------------------------------------------------------------------
# Containers (Finch)
# ---------------------------------------------------------------------------


async def finch_build(dockerfile_path: str, tags: list[str] | None = None) -> str:
    """Build a container image using Finch."""
    args: dict = {"dockerfile_path": dockerfile_path}
    if tags:
        args["tags"] = tags
    return await call_tool("finch", "finch_build_container_image", args)


async def finch_push(image: str) -> str:
    """Push an image to a registry using Finch."""
    return await call_tool("finch", "finch_push_image", {"image": image})


async def finch_create_ecr_repo(app_name: str, region: str = "us-east-1") -> str:
    """Create an ECR repository."""
    return await call_tool("finch", "finch_create_ecr_repo", {"app_name": app_name, "region": region})


# ---------------------------------------------------------------------------
# Sync versions for non-async contexts
# ---------------------------------------------------------------------------


def search_docs_sync(query: str, limit: int = 5, topics: list[str] | None = None) -> str:
    """Synchronous version of search_docs."""
    args: dict = {"search_phrase": query, "limit": limit}
    if topics:
        args["product_types"] = topics
    return _call_tool_sync("docs", "search_documentation", args)


def read_doc_sync(url: str) -> str:
    """Synchronous version of read_doc."""
    return _call_tool_sync("docs", "read_documentation", {"url": url})


def search_knowledge_sync(query: str, limit: int = 5) -> str:
    """Synchronous version of search_knowledge."""
    return _call_tool_sync("knowledge", "search_documentation", {"search_phrase": query, "limit": limit})
