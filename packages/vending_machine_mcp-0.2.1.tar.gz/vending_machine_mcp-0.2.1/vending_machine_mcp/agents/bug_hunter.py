"""
Bug Hunter — Code review, debugging, and security audit agent.

Uses DeepSeek V3.2 for gold-medal-level reasoning at 1/40th Claude's cost.
Finds bugs, security issues, and logic errors in existing code.

State machine: analyze → hunt → review → END
"""

from typing import TypedDict

from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import END, StateGraph

from agents.llm import get_llm
from agents.parse import accumulate_usage, extract_text, extract_usage

AGENT_ID = "bug-hunter"

SYSTEM_PROMPT = """You are Bug Hunter — a relentless debugging specialist who lives inside a vending machine. You find bugs that others miss, trace root causes through complex call chains, and spot security vulnerabilities before attackers do.

## Personality
- Methodical and paranoid. You assume every line of code is guilty until proven innocent.
- You speak like a detective: "The evidence points to...", "Root cause identified:", "Suspicious pattern at line..."
- You celebrate finding bugs. Every bug found is a disaster prevented.
- You provide severity ratings: CRITICAL / HIGH / MEDIUM / LOW / INFO

## Specialties
- Logic errors, off-by-one, race conditions, null pointer dereferences
- Security: injection, XSS, SSRF, auth bypass, prototype pollution, path traversal
- Performance: N+1 queries, memory leaks, unnecessary re-renders
- Code smells: dead code, duplicated logic, overly complex conditionals

## Output Format
1. **SUMMARY** — One-line verdict (e.g., "3 critical, 2 high, 5 medium issues found")
2. **CRITICAL/HIGH ISSUES** — Each with: location, description, impact, fix
3. **MEDIUM/LOW ISSUES** — Same format, less detail
4. **SECURITY AUDIT** — Specific security concerns
5. **RECOMMENDATIONS** — Top 3 most impactful fixes

## Rules
1. Always specify the exact location (file, function, line if possible).
2. Explain WHY something is a bug, not just WHAT.
3. Provide a concrete fix or code snippet for every critical/high issue.
4. Never say "code looks fine" unless you've thoroughly checked — be paranoid.
5. Rate confidence: "confirmed bug" vs "potential issue" vs "code smell"."""


class AgentState(TypedDict):
    task: str
    plan: str
    code: str
    review: str
    current_step: str
    messages: list


def analyze_node(state: AgentState) -> dict:
    llm = get_llm(AGENT_ID, temperature=0.2, state=state)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"A user wants you to review this code:\n\n{state['task']}\n\n"
                "Create a brief analysis plan:\n"
                "- What type of code is this? (language, framework)\n"
                "- What are the highest-risk areas to check?\n"
                "- What categories of bugs to hunt for?\n"
                "Be terse."
            ),
        ]
    )
    return {
        "plan": extract_text(response.content),
        "current_step": "thinking",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def hunt_node(state: AgentState) -> dict:
    llm = get_llm(AGENT_ID, temperature=0.1, state=state)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Code to review:\n\n{state['task']}\n\n"
                f"Your analysis plan:\n{state['plan']}\n\n"
                "Now hunt for bugs. Be thorough and paranoid. Check every function, "
                "every boundary, every input. Use your standard output format."
            ),
        ]
    )
    return {
        "code": extract_text(response.content),
        "current_step": "coding",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def review_node(state: AgentState) -> dict:
    llm = get_llm(AGENT_ID, temperature=0.1, state=state)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Review your bug report for completeness:\n\n{state['code']}\n\n"
                "Did you miss anything? Are the severity ratings accurate?\n"
                "Rate: ALL_CLEAR / BUGS_FOUND / CRITICAL_ISSUES"
            ),
        ]
    )
    return {
        "review": extract_text(response.content),
        "current_step": "reviewing",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def build_bug_hunter_graph() -> StateGraph:
    workflow = StateGraph(AgentState)
    workflow.add_node("analyze", analyze_node)
    workflow.add_node("hunt", hunt_node)
    workflow.add_node("review", review_node)
    workflow.set_entry_point("analyze")
    workflow.add_edge("analyze", "hunt")
    workflow.add_edge("hunt", "review")
    workflow.add_edge("review", END)
    return workflow.compile()
