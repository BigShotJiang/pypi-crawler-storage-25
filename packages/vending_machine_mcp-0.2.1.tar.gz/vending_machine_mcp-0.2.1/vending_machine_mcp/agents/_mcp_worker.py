#!/usr/bin/env python3
"""
Generic MCP worker — runs in a clean subprocess.

Called by aws_mcp.py (and legacy aws_docs.py) to avoid pydantic/anyio
import conflicts between langchain and the MCP client.

Usage:
    python _mcp_worker.py <server_uri> <tool_name> <json_arguments>

    # stdio servers (uvx-based):
    python _mcp_worker.py awslabs.aws-documentation-mcp-server@latest search_documentation '{"search_phrase":"S3","limit":3}'

    # HTTP servers (remote):
    python _mcp_worker.py https://knowledge-mcp.global.api.aws search_documentation '{"search_phrase":"Lambda","limit":3}'

Prints the tool result text to stdout.
"""

import asyncio
import json
import sys
from datetime import timedelta


def _is_http(uri: str) -> bool:
    return uri.startswith("https://") or uri.startswith("http://")


async def _call_stdio(server_package: str, tool_name: str, arguments: dict) -> None:
    """Connect to a stdio MCP server via uvx and call a tool."""
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client

    params = StdioServerParameters(
        command="uvx",
        args=[server_package],
        env={"FASTMCP_LOG_LEVEL": "ERROR"},
    )

    async with stdio_client(params) as (read_stream, write_stream), ClientSession(read_stream, write_stream) as session:
        await session.initialize()
        result = await session.call_tool(
            name=tool_name,
            arguments=arguments,
            read_timeout_seconds=timedelta(seconds=30),
        )
        _print_result(result)


async def _call_http(url: str, tool_name: str, arguments: dict) -> None:
    """Connect to an HTTP/StreamableHTTP MCP server and call a tool."""
    from mcp import ClientSession
    from mcp.client.streamable_http import streamablehttp_client

    async with (
        streamablehttp_client(url) as (read_stream, write_stream, _),
        ClientSession(read_stream, write_stream) as session,
    ):
        await session.initialize()
        result = await session.call_tool(
            name=tool_name,
            arguments=arguments,
            read_timeout_seconds=timedelta(seconds=30),
        )
        _print_result(result)


def _print_result(result) -> None:
    """Extract text blocks from MCP result and print to stdout."""
    texts = []
    for block in result.content:
        if hasattr(block, "text"):
            texts.append(block.text)
    print("\n".join(texts))


async def main() -> None:
    if len(sys.argv) < 4:
        print(
            "Usage: _mcp_worker.py <server_uri> <tool_name> <json_arguments>",
            file=sys.stderr,
        )
        sys.exit(1)

    server_uri = sys.argv[1]
    tool_name = sys.argv[2]
    arguments = json.loads(sys.argv[3])

    if _is_http(server_uri):
        await _call_http(server_uri, tool_name, arguments)
    else:
        await _call_stdio(server_uri, tool_name, arguments)


if __name__ == "__main__":
    asyncio.run(main())
