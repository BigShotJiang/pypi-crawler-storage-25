"""
Response parser for structured LLM outputs.

OpenAI reasoning models (o-series, Codex) return content as a list of blocks:
  [
    {"type": "reasoning", "encrypted_content": "...", ...},
    {"type": "text", "text": "the actual content", ...}
  ]

Standard models return a plain string.

This module normalizes both formats into a clean string.
"""


def extract_usage(response) -> dict:
    """Extract token usage from a LangChain AIMessage response.

    Returns {"input_tokens": N, "output_tokens": N} or zeros if unavailable.
    """
    usage = getattr(response, "usage_metadata", None) or {}
    return {
        "input_tokens": usage.get("input_tokens", 0),
        "output_tokens": usage.get("output_tokens", 0),
    }


def accumulate_usage(state: dict, new_usage: dict) -> dict:
    """Accumulate token usage across multiple LLM calls within an agent pipeline."""
    existing = state.get("token_usage") or {"input_tokens": 0, "output_tokens": 0}
    return {
        "input_tokens": existing["input_tokens"] + new_usage.get("input_tokens", 0),
        "output_tokens": existing["output_tokens"] + new_usage.get("output_tokens", 0),
    }


def extract_text(content) -> str:
    """
    Extract readable text from an LLM response content field.

    Handles:
    - Plain string responses (Claude, GPT-4, etc.)
    - Structured block responses (o-series, Codex)
    - List of dicts with 'type' and 'text' fields
    """
    # Already a plain string
    if isinstance(content, str):
        return content.strip()

    # List of content blocks (reasoning models)
    if isinstance(content, list):
        text_parts = []
        for block in content:
            if isinstance(block, dict):
                # Only grab "text" type blocks, skip "reasoning" blocks
                if block.get("type") == "text" and "text" in block:
                    text_parts.append(block["text"])
            elif isinstance(block, str):
                text_parts.append(block)
        return "\n".join(text_parts).strip()

    # Fallback — stringify whatever we got
    return str(content).strip()
