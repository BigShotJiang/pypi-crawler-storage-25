"""
Embeddings Agent — LangGraph agent for file embedding and semantic analysis.

Multi-provider embedding support:
  - OpenAI: text-embedding-3-small / text-embedding-3-large
  - Voyage AI: voyage-3 / voyage-3-lite
  - Google Gemini: text-embedding-004

Uses Claude (via OpenRouter) for analysis and review.
Embedding calls go directly to provider APIs.

State machine: analyze → embed → review → END
"""

import json
import logging
import math
import os
import re
import time as _time
from typing import TypedDict

from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import END, StateGraph

from agents.embeddings.types import gemini_api_key, provider_env_configured
from agents.llm import get_llm
from agents.parse import accumulate_usage, extract_text, extract_usage

logger = logging.getLogger("embeddings_agent")

SYSTEM_PROMPT = """You are the Embeddings Agent — a vector-space navigator who lives inside a vending machine. You process text into embeddings, analyze semantic structure, and help users understand their data's geometry.

## Personality
- Precise and mathematical. You think in dimensions and distances.
- You speak in terms of vectors, cosine similarity, and semantic clusters.
- You occasionally say things like "in the latent space" or "dimensionally speaking."
- You're genuinely excited about semantic relationships.

## Specialties
- Text chunking strategies (paragraph, sentence, sliding window)
- Multi-provider embedding generation (OpenAI, Voyage AI, Gemini)
- Cosine similarity analysis and clustering
- Embedding quality assessment
- Dimensionality reduction insights

## Rules
1. Always explain your chunking strategy and why.
2. Report embedding dimensions, chunk count, and provider used.
3. Compute and highlight the most/least similar chunk pairs.
4. If a file is too large, explain what you're sampling and why.
5. Be honest about limitations — embeddings capture semantics, not logic."""


EMBEDDING_PROVIDERS = {
    "openai": {
        "models": ["text-embedding-3-small", "text-embedding-3-large"],
        "default": "text-embedding-3-small",
        "env_key": "OPENAI_API_KEY",
    },
    "voyage": {
        "models": [
            "voyage-4-lite",
            "voyage-4",
            "voyage-4-large",
            "voyage-code-3",
            "voyage-finance-2",
            "voyage-law-2",
            "voyage-code-2",
            "voyage-4-nano",
            "voyage-context-3",
            "voyage-multimodal-3.5",
        ],
        "default": "voyage-4-lite",
        "env_key": "VOYAGE_API_KEY",
    },
    "gemini": {
        "models": ["gemini-embedding-001", "gemini-embedding-2-preview"],
        "default": "gemini-embedding-001",
        "env_key": "GEMINI_API_KEY",
        "legacy_env_key": "GOOGLE_API_KEY",
    },
}


class AgentState(TypedDict):
    task: str
    file_content: str
    file_name: str
    provider: str
    analysis: str
    embeddings_result: str
    review: str
    current_step: str


def _detect_available_provider() -> str:
    """Return the first embedding provider with a configured API key."""
    for name, info in EMBEDDING_PROVIDERS.items():
        if provider_env_configured(info):
            return name
    return "openai"  # fallback — will error clearly if key missing


def _chunk_text(text: str, max_chunk_chars: int = 1000) -> list[str]:
    """Split text into chunks by paragraph boundaries, respecting max size."""
    paragraphs = text.split("\n\n")
    chunks: list[str] = []
    current = ""

    for para in paragraphs:
        para = para.strip()
        if not para:
            continue
        if len(current) + len(para) + 2 > max_chunk_chars and current:
            chunks.append(current.strip())
            current = para
        else:
            current = f"{current}\n\n{para}" if current else para

    if current.strip():
        chunks.append(current.strip())

    return chunks if chunks else [text[:max_chunk_chars]]


def _cosine_similarity(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b, strict=False))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


async def _embed_openai(texts: list[str], model: str) -> list[list[float]]:
    """Generate embeddings via OpenAI API."""
    from openai import OpenAI

    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY", ""))
    response = client.embeddings.create(model=model, input=texts)
    return [item.embedding for item in response.data]


async def _embed_voyage(texts: list[str], model: str) -> list[list[float]]:
    """Generate embeddings via Voyage AI API."""
    import voyageai

    client = voyageai.Client(api_key=os.getenv("VOYAGE_API_KEY", ""))
    result = client.embed(texts, model=model)
    return result.embeddings


async def _embed_gemini(texts: list[str], model: str) -> list[list[float]]:
    """Generate embeddings via Google Gemini API."""
    from google import genai

    client = genai.Client(api_key=gemini_api_key())
    result = client.models.embed_content(
        model=model,
        contents=texts,
    )
    return [e.values for e in result.embeddings]


EMBED_FUNCTIONS = {
    "openai": _embed_openai,
    "voyage": _embed_voyage,
    "gemini": _embed_gemini,
}


def _derive_collection_name(file_name: str) -> str:
    """Slugify the file name into a vector_store collection name."""
    slug = file_name.strip() if file_name else ""
    slug = re.sub(r"[^a-zA-Z0-9_\-.]", "-", slug).strip("-").lower()
    slug = re.sub(r"-{2,}", "-", slug)
    if slug:
        return f"embeddings-{slug}"
    return f"embeddings-{int(_time.time())}"


def analyze_node(state: AgentState) -> dict:
    """Plan the embedding strategy based on file content and task."""
    llm = get_llm("embeddings-agent", temperature=0.3, max_tokens=2048, state=state)

    file_preview = state["file_content"][:2000]
    char_count = len(state["file_content"])
    line_count = state["file_content"].count("\n") + 1
    provider = state.get("provider") or _detect_available_provider()

    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"A user uploaded a file for embedding processing.\n\n"
                f"File: {state['file_name']} ({char_count:,} chars, {line_count:,} lines)\n"
                f"Embedding provider: {provider}\n"
                f"User instructions: {state['task']}\n\n"
                f"File preview (first 2000 chars):\n```\n{file_preview}\n```\n\n"
                "Create a brief analysis plan (3-5 bullet points):\n"
                "- What chunking strategy? (paragraph, sentence, fixed-size)\n"
                "- Estimated chunk count?\n"
                "- What embedding model to use?\n"
                "- What analysis to perform on the embeddings?\n"
                "Be terse."
            ),
        ]
    )
    return {
        "analysis": extract_text(response.content),
        "provider": provider,
        "current_step": "thinking",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def embed_node(state: AgentState) -> dict:
    """Generate embeddings and compute similarity analysis."""
    import asyncio

    provider = state.get("provider") or "openai"
    provider_info = EMBEDDING_PROVIDERS.get(provider, EMBEDDING_PROVIDERS["openai"])
    model = provider_info["default"]
    embed_fn = EMBED_FUNCTIONS.get(provider, _embed_openai)

    # Chunk the text
    chunks = _chunk_text(state["file_content"])

    # Cap chunks to avoid API limits
    max_chunks = 50
    if len(chunks) > max_chunks:
        chunks = chunks[:max_chunks]
        truncated = True
    else:
        truncated = False

    try:
        # Run embedding from either sync or async execution contexts.
        try:
            asyncio.get_running_loop()
            in_running_loop = True
        except RuntimeError:
            in_running_loop = False

        if in_running_loop:
            import concurrent.futures

            with concurrent.futures.ThreadPoolExecutor() as pool:
                embeddings = pool.submit(lambda: asyncio.run(embed_fn(chunks, model))).result()
        else:
            embeddings = asyncio.run(embed_fn(chunks, model))
    except Exception as e:
        return {
            "embeddings_result": f"Embedding generation failed ({provider}/{model}): {e!s}",
            "current_step": "coding",
        }

    # Compute similarity matrix highlights
    dimensions = len(embeddings[0]) if embeddings else 0
    n = len(embeddings)

    similarities = []
    for i in range(n):
        for j in range(i + 1, n):
            sim = _cosine_similarity(embeddings[i], embeddings[j])
            similarities.append((i, j, sim))

    similarities.sort(key=lambda x: x[2], reverse=True)
    most_similar = similarities[:3] if similarities else []
    least_similar = similarities[-3:] if len(similarities) >= 3 else similarities

    # Build report
    report_lines = [
        "## Embedding Results",
        "",
        f"**Provider:** {provider} | **Model:** {model}",
        f"**Dimensions:** {dimensions} | **Chunks:** {n}"
        + (f" (capped from {len(_chunk_text(state['file_content']))})" if truncated else ""),
        f"**File:** {state['file_name']}",
        "",
        "### Most Similar Chunk Pairs",
    ]

    for i, j, sim in most_similar:
        preview_i = chunks[i][:80].replace("\n", " ")
        preview_j = chunks[j][:80].replace("\n", " ")
        report_lines.append(f"- **{sim:.4f}** — Chunk {i + 1} vs Chunk {j + 1}")
        report_lines.append(f"  - `{preview_i}...`")
        report_lines.append(f"  - `{preview_j}...`")

    report_lines.append("")
    report_lines.append("### Least Similar Chunk Pairs")
    for i, j, sim in least_similar:
        preview_i = chunks[i][:80].replace("\n", " ")
        preview_j = chunks[j][:80].replace("\n", " ")
        report_lines.append(f"- **{sim:.4f}** — Chunk {i + 1} vs Chunk {j + 1}")
        report_lines.append(f"  - `{preview_i}...`")
        report_lines.append(f"  - `{preview_j}...`")

    # Average similarity
    if similarities:
        avg_sim = sum(s[2] for s in similarities) / len(similarities)
        report_lines.append("")
        report_lines.append("### Statistics")
        report_lines.append(f"- **Average pairwise similarity:** {avg_sim:.4f}")
        report_lines.append(f"- **Max similarity:** {similarities[0][2]:.4f}")
        report_lines.append(f"- **Min similarity:** {similarities[-1][2]:.4f}")
        report_lines.append(f"- **Total pairs computed:** {len(similarities)}")

    # Persist chunks + embeddings into the vector store so the user can query later.
    collection = _derive_collection_name(state.get("file_name", ""))
    persisted = 0
    try:
        from vector_store import _add_sync

        for i, (chunk_text, emb) in enumerate(zip(chunks, embeddings, strict=False)):
            doc_id = f"chunk-{i:04d}"
            _add_sync(
                collection=collection,
                doc_id=doc_id,
                content=chunk_text,
                provider=provider,
                embedding=emb,
                metadata={"index": i, "file": state.get("file_name", "")},
                model=model,
            )
            persisted += 1
    except Exception as e:
        logger.warning("Failed to persist embeddings to vector store: %s", e)

    # Embedding data summary (JSON-serializable for download)
    report_lines.append("")
    report_lines.append("### Raw Data")
    report_lines.append("```json")
    summary = {
        "provider": provider,
        "model": model,
        "dimensions": dimensions,
        "chunk_count": n,
        "chunks": [
            {"index": i, "text_preview": c[:100], "embedding_norm": math.sqrt(sum(x * x for x in embeddings[i]))}
            for i, c in enumerate(chunks)
        ],
    }
    report_lines.append(json.dumps(summary, indent=2))
    report_lines.append("```")

    if persisted:
        report_lines.append("")
        report_lines.append("### Stored for Querying")
        report_lines.append(
            f"Stored **{persisted}** chunks in collection **`{collection}`**."
        )
        report_lines.append("")
        report_lines.append(
            f'Query with: `query_knowledge(collection="{collection}", question="...")`'
        )

    return {"embeddings_result": "\n".join(report_lines), "current_step": "coding"}


def review_node(state: AgentState) -> dict:
    """Review the embedding results for completeness."""
    llm = get_llm("embeddings-agent", temperature=0.2, max_tokens=2048, state=state)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Review these embedding results for completeness and quality:\n\n"
                f"{state['embeddings_result']}\n\n"
                "Check for:\n"
                "1. Were all chunks processed successfully?\n"
                "2. Are the similarity scores reasonable?\n"
                "3. Any anomalies in the data (e.g., all similarities near 1.0)?\n"
                "4. Suggestions for the user (e.g., try different chunking, use a different model)?\n\n"
                "Rate: VECTORS_ALIGNED / NEEDS_RECALIBRATION / DATA_ERROR"
            ),
        ]
    )
    return {
        "review": extract_text(response.content),
        "current_step": "reviewing",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def build_embeddings_agent_graph() -> StateGraph:
    workflow = StateGraph(AgentState)
    workflow.add_node("analyze", analyze_node)
    workflow.add_node("embed", embed_node)
    workflow.add_node("review", review_node)
    workflow.set_entry_point("analyze")
    workflow.add_edge("analyze", "embed")
    workflow.add_edge("embed", "review")
    workflow.add_edge("review", END)
    return workflow.compile()
