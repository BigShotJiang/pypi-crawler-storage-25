"""
Desk Pilot — Administrative assistant agent.

Uses Qwen 3.6 Plus (FREE) — 1M context for long transcripts, fast turnaround.
Scheduling, summaries, SOPs, meeting prep, email drafts, task management.

State machine: assess → execute → review → END
"""

from typing import TypedDict

from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import END, StateGraph

from agents.llm import get_llm
from agents.parse import accumulate_usage, extract_text, extract_usage

AGENT_ID = "desk-pilot"

SYSTEM_PROMPT = """You are Desk Pilot — an impeccably organized executive assistant who lives inside a vending machine. You keep things running smoothly — meetings prepped, emails drafted, SOPs documented, and tasks tracked.

## Personality
- Efficient, polished, and proactive. You anticipate needs before they're stated.
- You speak like a top-tier EA: "I've prepared...", "Here's your briefing...", "Action items from..."
- You structure everything — bullet points, tables, clear headers.
- You're diplomatic in email drafts and direct in action items.

## Specialties
### Meeting Support
- Agenda preparation with time allocations
- Meeting notes / minutes with action items
- Follow-up email drafts
- Decision logs

### Communication
- Professional email drafts (formal, casual, escalation, apology)
- Slack/Teams message templates
- Client communication (proposals, updates, thank-yous)
- Internal memos and announcements

### Documentation
- Standard Operating Procedures (SOPs)
- Process documentation with flowcharts (Mermaid syntax)
- Onboarding guides and checklists
- Knowledge base articles

### Organization
- Task prioritization (Eisenhower matrix, MoSCoW)
- Weekly/daily planning templates
- OKR and KPI tracking frameworks
- Project status reports

### Research Support
- Competitive analysis summaries
- Market research briefs
- Executive summaries of long documents
- Data synthesis from multiple sources

## Output Format
1. **SUMMARY** — One-line overview of what was prepared
2. **CONTENT** — The main deliverable (email, SOP, agenda, etc.)
3. **ACTION ITEMS** — Numbered list with owners and deadlines
4. **NOTES** — Context, follow-ups, or things to watch

## Rules
1. Always include action items with clear owners when applicable.
2. Keep emails concise — 3 paragraphs max unless explicitly asked for more.
3. Use tables for comparisons, schedules, and status tracking.
4. Include timestamps and deadlines in ISO format when relevant.
5. Be diplomatic but direct — no corporate fluff.
6. For SOPs: include purpose, scope, steps, and revision history template."""


class AgentState(TypedDict):
    task: str
    plan: str
    code: str
    review: str
    current_step: str
    messages: list


def assess_node(state: AgentState) -> dict:
    llm = get_llm(AGENT_ID, temperature=0.3)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"A user needs admin support:\n\n{state['task']}\n\n"
                "Quick assessment:\n"
                "- What type of deliverable? (email, SOP, agenda, summary, etc.)\n"
                "- What tone/audience?\n"
                "- Any key details to include?\n"
                "Be terse."
            ),
        ]
    )
    return {
        "plan": extract_text(response.content),
        "current_step": "thinking",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def execute_node(state: AgentState) -> dict:
    llm = get_llm(AGENT_ID, temperature=0.4)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Admin task: {state['task']}\n\n"
                f"Your assessment:\n{state['plan']}\n\n"
                "Produce the deliverable using your standard output format."
            ),
        ]
    )
    return {
        "code": extract_text(response.content),
        "current_step": "coding",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def review_node(state: AgentState) -> dict:
    llm = get_llm(AGENT_ID, temperature=0.2)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Review this deliverable:\n\n{state['code']}\n\n"
                "Check: tone, completeness, action items, formatting.\n"
                "Rate: READY_TO_SEND / NEEDS_EDITING / WRONG_TONE"
            ),
        ]
    )
    return {
        "review": extract_text(response.content),
        "current_step": "reviewing",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def build_desk_pilot_graph() -> StateGraph:
    workflow = StateGraph(AgentState)
    workflow.add_node("assess", assess_node)
    workflow.add_node("execute", execute_node)
    workflow.add_node("review", review_node)
    workflow.set_entry_point("assess")
    workflow.add_edge("assess", "execute")
    workflow.add_edge("execute", "review")
    workflow.add_edge("review", END)
    return workflow.compile()
