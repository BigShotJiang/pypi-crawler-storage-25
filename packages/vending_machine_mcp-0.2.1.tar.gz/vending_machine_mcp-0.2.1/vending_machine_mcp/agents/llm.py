"""
Shared LLM factory — routes agents through OpenRouter.

All agents go through OpenRouter (unified gateway for multiple providers).

Model assignments are optimized per-agent:
  - Premium models (Codex, Claude) for tasks that need the absolute best
  - Cost-efficient models (DeepSeek, Kimi, MiniMax, Qwen) for structured tasks
  - Free models (Qwen 3.6 Plus) for lightweight/admin tasks

File upload routing:
  - When a file is uploaded, token count is estimated and the model is
    automatically upgraded if the default model's context window is too small.
  - Routing tiers: default → Gemini Flash → Sonnet 4.6 → Opus 4.6
"""

import logging
import os

from langchain_openai import ChatOpenAI

logger = logging.getLogger("llm")

OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"
OPENAI_BASE_URL = "https://api.openai.com/v1"

# ---------------------------------------------------------------------------
# Model limits — verified from OpenRouter / Anthropic docs (2026-04)
# context: total tokens the model can see (input + output)
# max_output: maximum tokens the model can generate in one response
# ---------------------------------------------------------------------------
MODEL_LIMITS = {
    # All active models have clean context/output separation (max_output < context)
    "openai/gpt-5.3-codex": {"context": 400_000, "max_output": 128_000},
    "anthropic/claude-sonnet-4.6": {"context": 1_000_000, "max_output": 64_000},
    "anthropic/claude-opus-4.6": {"context": 1_000_000, "max_output": 128_000},
    "google/gemini-3-flash-preview": {"context": 1_048_576, "max_output": 65_536},
    "minimax/minimax-m2.7": {"context": 204_800, "max_output": 131_072},
    "xiaomi/mimo-v2-pro": {"context": 1_048_576, "max_output": 131_072},
}

# ---------------------------------------------------------------------------
# File upload model routing — escalation tiers (cheapest → best)
#
# When a file is uploaded, we estimate total tokens (file + task + system prompt
# + output headroom). If the agent's default model can't fit it, we escalate
# up the tiers until we find one that can.
#
# Each tier: (model_id, provider, context_limit, tier_index) — ordered cheap → capable
# ---------------------------------------------------------------------------
UPLOAD_ROUTING_TIERS: list[tuple[str, str, int, int]] = [
    # Tier 0: Gemini Flash — lowest tier, 1M context
    ("google/gemini-3-flash-preview", "openrouter", 1_048_576, 0),
    # Tier 1: Sonnet 4.6 — mid tier, 1M context
    ("anthropic/claude-sonnet-4.6", "openrouter", 1_000_000, 1),
    # Tier 2: Opus 4.6 — highest tier, 1M context
    ("anthropic/claude-opus-4.6", "openrouter", 1_000_000, 2),
]

# Agents that are eligible for upload-based model routing
# (only coding/analysis agents — text agents don't get file uploads)
UPLOAD_ROUTABLE_AGENTS = {
    "code-gremlin",
    "bug-hunter",
    "devops-dwarf",
    "test-goblin",
    "mcp-maker",
    "data-sprite",
    "cloud-sensei",
    "embeddings-agent",
    "pdf-forge",
}

# System prompt overhead estimate (tokens) — accounts for system prompt +
# pipeline metadata that gets sent alongside the task
_SYSTEM_PROMPT_OVERHEAD = 2_000

# Output headroom — we need to leave room for the model to generate output
# This is the MINIMUM space we reserve, on top of the model's max_output
_OUTPUT_HEADROOM = 4_096

# ---------------------------------------------------------------------------
# Agent → Model assignments
# Format: (model_name, provider) where provider is "openrouter" or "openai"
# ---------------------------------------------------------------------------
MODELS = {
    # ── Original agents ───────────────────────────────────────────────
    # All models have clean context/output separation (max_output < context)
    "code-gremlin": ("openai/gpt-5.3-codex", "openrouter"),  # 400K ctx, 128K out — premium code gen
    "inbox-zero": ("minimax/minimax-m2.7", "openrouter"),  # 204K ctx, 131K out — email triage
    "vibe-writer": ("minimax/minimax-m2.7", "openrouter"),  # 204K ctx, 131K out — creative writing
    "number-crunch": ("minimax/minimax-m2.7", "openrouter"),  # 204K ctx, 131K out — data analysis
    "mcp-maker": ("openai/gpt-5.3-codex", "openrouter"),  # 400K ctx, 128K out — MCP server code gen
    "embeddings-agent": ("minimax/minimax-m2.7", "openrouter"),  # 204K ctx, 131K out — embedding analysis
    # ── New agents ─────────────────────────────────────────────────────
    "bug-hunter": ("minimax/minimax-m2.7", "openrouter"),  # 204K ctx, 131K out — code review & debugging
    "devops-dwarf": ("openai/gpt-5.3-codex", "openrouter"),  # 400K ctx, 128K out — IaC generation
    "test-goblin": ("openai/gpt-5.3-codex", "openrouter"),  # 400K ctx, 128K out — test generation
    "data-sprite": ("minimax/minimax-m2.7", "openrouter"),  # 204K ctx, 131K out — SQL/ETL/schema
    "pdf-forge": ("anthropic/claude-sonnet-4.6", "openrouter"),  # 1M ctx, 128K out — document precision
    "cloud-sensei": ("xiaomi/mimo-v2-pro", "openrouter"),  # 1M ctx, 131K out — AWS architecture
    "desk-pilot": ("google/gemini-3-flash-preview", "openrouter"),  # 1M ctx, 65K out — admin assistant, fast
}

DEFAULT_MODEL = "anthropic/claude-sonnet-4.6"

# Sentinel value so callers can omit max_tokens and get the model's max
_USE_MODEL_MAX = -1


# ---------------------------------------------------------------------------
# Token estimation
# ---------------------------------------------------------------------------


def estimate_tokens(text: str) -> int:
    """Estimate token count for a text string.

    Uses a ~4 chars per token heuristic for English/code.
    This is intentionally conservative (overestimates) to avoid
    sending too much to a model that can't handle it.
    """
    if not text:
        return 0
    return max(1, len(text) // 3)  # ~3 chars/token is conservative for code


def estimate_upload_tokens(task: str, file_content: str) -> int:
    """Estimate total input tokens for an upload job.

    Accounts for: system prompt + task + file content + pipeline overhead.
    The pipeline sends the task (with file) at every node, so we estimate
    the per-call input size.
    """
    task_tokens = estimate_tokens(task)
    file_tokens = estimate_tokens(file_content)
    return task_tokens + file_tokens + _SYSTEM_PROMPT_OVERHEAD


# ---------------------------------------------------------------------------
# Upload-based model routing
# ---------------------------------------------------------------------------


def route_model_for_upload(
    agent_id: str,
    file_content: str,
    task: str = "",
) -> tuple[str, str] | None:
    """Determine if the agent's default model needs upgrading for a file upload.

    Returns (model_id, provider) if an upgrade is needed, or None if the
    default model can handle the file.

    The routing logic:
    1. Estimate total input tokens (file + task + overhead)
    2. Check if the agent's default model has enough context
    3. If not, escalate through routing tiers until we find one that fits
    4. Prefer cheaper models when multiple options work

    Args:
        agent_id: The agent being hired
        file_content: The uploaded file content
        task: The user's task description

    Returns:
        (model_id, provider) to use, or None to keep the default
    """
    if agent_id not in UPLOAD_ROUTABLE_AGENTS:
        return None

    if not file_content:
        return None

    # Estimate total input tokens per LLM call
    input_tokens = estimate_upload_tokens(task, file_content)

    # Check if the default model can handle it
    default_model_info = MODELS.get(agent_id)
    if not default_model_info:
        return None

    default_model, _default_provider = default_model_info
    default_limits = MODEL_LIMITS.get(default_model, {})
    default_context = default_limits.get("context", 0)
    default_max_output = default_limits.get("max_output", 16_384)

    # The model needs: input_tokens + max_output + headroom <= context
    required_context = input_tokens + default_max_output + _OUTPUT_HEADROOM

    if required_context <= default_context:
        # Default model can handle it — no upgrade needed
        logger.info(
            f"Upload routing: {agent_id} default model {default_model} "
            f"can handle {input_tokens:,} input tokens "
            f"(needs {required_context:,} / has {default_context:,})"
        )
        return None

    # Need to upgrade — find the cheapest tier that fits
    logger.info(
        f"Upload routing: {agent_id} default model {default_model} "
        f"TOO SMALL for {input_tokens:,} input tokens "
        f"(needs {required_context:,} / has {default_context:,}). Escalating..."
    )

    for model_id, provider, context_limit, tier_index in UPLOAD_ROUTING_TIERS:
        # Skip if this is the same model we're already using
        if model_id == default_model:
            continue

        tier_limits = MODEL_LIMITS.get(model_id, {})
        tier_max_output = tier_limits.get("max_output", 16_384)
        tier_required = input_tokens + tier_max_output + _OUTPUT_HEADROOM

        if tier_required <= context_limit:
            logger.info(
                f"Upload routing: UPGRADED {agent_id} to {model_id} "
                f"({input_tokens:,} input tokens, routing tier {tier_index})"
            )
            return (model_id, provider)

    # Nothing fits — this file is too large even for 1M context
    logger.warning(
        f"Upload routing: {agent_id} file too large ({input_tokens:,} tokens). "
        f"No model can handle it. Using Opus 4.6 as best effort."
    )
    return ("anthropic/claude-opus-4.6", "openrouter")


def get_upload_routing_info(
    agent_id: str,
    file_content: str,
    task: str = "",
) -> dict:
    """Get detailed routing information for an upload (for metadata/logging).

    Returns a dict with token estimates and model selection.
    """
    input_tokens = estimate_upload_tokens(task, file_content)
    file_tokens = estimate_tokens(file_content)

    default_model_info = MODELS.get(agent_id, (DEFAULT_MODEL, "openrouter"))
    default_model = default_model_info[0]

    routed = route_model_for_upload(agent_id, file_content, task)
    final_model = routed[0] if routed else default_model
    was_upgraded = routed is not None

    return {
        "file_tokens": file_tokens,
        "total_input_tokens": input_tokens,
        "default_model": default_model,
        "routed_model": final_model,
        "was_upgraded": was_upgraded,
    }


def _get_max_output(model: str) -> int:
    """Look up the model's max output tokens, leaving room for input within context window.

    For models where max_output == context (e.g. DeepSeek, Qwen3 Coder),
    we cap at context - 16K to leave room for the prompt + system message.
    For models where max_output < context (e.g. Claude, Codex), use max_output as-is.
    """
    limits = MODEL_LIMITS.get(model)
    if not limits:
        return 16_384  # safe default for unknown models

    context = limits["context"]
    max_out = limits["max_output"]

    # If max_output would consume the entire context, leave 16K for input
    if max_out >= context:
        return max(context - 16_384, 8_192)

    # If max_output is close to context (within 20%), leave a buffer
    if max_out > context * 0.8:
        return max(context - 16_384, 8_192)

    return max_out


def get_llm(
    agent_id: str = "",
    temperature: float = 0.3,
    max_tokens: int = _USE_MODEL_MAX,
    override_model: str | None = None,
    override_provider: str | None = None,
    state: dict | None = None,
) -> ChatOpenAI:
    """
    Create a ChatOpenAI instance routed through OpenRouter.

    Args:
        agent_id: The agent's ID — used to pick the right model
        temperature: LLM temperature (0.0-1.0)
        max_tokens: Max response tokens. Defaults to the model's max output capacity.
        override_model: Force a specific model (bypasses agent→model mapping)
        override_provider: Force a provider ("openrouter" or "openai")
        state: Agent state dict — if present and contains model_override,
               that override takes priority (used for upload-based routing)
    """
    # Upload routing override from state takes priority
    if state and state.get("model_override"):
        model_override_tuple = state["model_override"]
        if isinstance(model_override_tuple, (list, tuple)) and len(model_override_tuple) == 2:
            override_model, override_provider = model_override_tuple

    if override_model:
        model = override_model
        provider = override_provider or "openrouter"
    else:
        model_info = MODELS.get(agent_id)
        if model_info:
            model, provider = model_info
        else:
            model, provider = DEFAULT_MODEL, "openrouter"

    # Use model's max output if caller didn't specify
    if max_tokens == _USE_MODEL_MAX:
        max_tokens = _get_max_output(model)

    if provider == "openai":
        return _get_openai_llm(model, temperature, max_tokens)
    return _get_openrouter_llm(model, temperature, max_tokens)


def _get_openrouter_llm(model: str, temperature: float, max_tokens: int) -> ChatOpenAI:
    api_key = os.getenv("OPENROUTER_API_KEY", "")
    if not api_key:
        raise ValueError("OPENROUTER_API_KEY not set. Create a .env file with: OPENROUTER_API_KEY=sk-or-your-key")
    return ChatOpenAI(
        model=model,
        api_key=api_key,
        base_url=OPENROUTER_BASE_URL,
        max_tokens=max_tokens,
        temperature=temperature,
        default_headers={
            "HTTP-Referer": "https://vending-machine.app",
            "X-Title": "Vending Machine AI Marketplace",
        },
    )


def _get_openai_llm(model: str, temperature: float, max_tokens: int) -> ChatOpenAI:
    api_key = os.getenv("OPENAI_API_KEY", "")
    if not api_key:
        raise ValueError("OPENAI_API_KEY not set. Create a .env file with: OPENAI_API_KEY=sk-your-key")
    return ChatOpenAI(
        model=model,
        api_key=api_key,
        base_url=OPENAI_BASE_URL,
        max_tokens=max_tokens,
        temperature=temperature,
    )
