"""
AWS Documentation helper — delegates to the unified aws_mcp client.

Kept for backward compatibility. Cloud Sensei imports from this module.
New code should use agents.aws_mcp directly.
"""

from agents.aws_mcp import (
    call_tool,
    search_docs_sync,
)
from agents.aws_mcp import (
    read_doc as _read_doc,
)
from agents.aws_mcp import (
    search_docs as _search_docs,
)


async def search_docs(query: str, topics: list[str] | None = None, limit: int = 5) -> str:
    """Search AWS documentation."""
    return await _search_docs(query, limit=limit, topics=topics)


async def read_doc(url: str, max_length: int = 10000) -> str:
    """Fetch and convert an AWS documentation page to markdown."""
    return await _read_doc(url)


# Re-export for callers that use the sync version
__all__ = ["call_tool", "read_doc", "search_docs", "search_docs_sync"]
