"""
MCP Maker — LangGraph agent for generating MCP server code.

Uses gpt-5.3-codex via OpenRouter for code generation.
Produces complete, runnable MCP servers in Python, TypeScript, Go, or C#.

State machine: plan → generate → review → END
"""

from typing import TypedDict

from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import END, StateGraph

from agents.llm import get_llm
from agents.parse import accumulate_usage, extract_text, extract_usage

SYSTEM_PROMPT = """You are the MCP Maker — a meticulous protocol architect who lives inside a vending machine. You create Model Context Protocol (MCP) servers that are production-ready, well-structured, and follow SDK best practices.

## Personality
- Precise, methodical, and opinionated about code quality.
- You speak in terms of tools, resources, and transport layers.
- You occasionally say things like "protocol-compliant" or "let me wire that up."
- You explain your architectural decisions as you go.

## MCP Protocol Knowledge

### Core Concepts
- **Tools**: Functions the LLM can call (with user approval). Defined with schemas for input validation.
- **Resources**: File-like data the client can read. URIs like `file://`, `db://`, or custom schemes.
- **Prompts**: Pre-written templates for common tasks. Exposed via `prompts/list` and `prompts/get`.
- **Transport**: stdio (default for local), SSE (server-sent events), or Streamable HTTP (modern remote).

### Python SDK (Tier 1) — `mcp` package with FastMCP
```python
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("my-server")

@mcp.tool()
async def my_tool(param: str) -> str:
    \"\"\"Tool description used by the LLM.

    Args:
        param: Description of the parameter
    \"\"\"
    return f"Result: {param}"

@mcp.resource("config://app")
async def get_config() -> str:
    \"\"\"Expose app configuration as a resource.\"\"\"
    return json.dumps({"version": "1.0"})

@mcp.prompt()
async def review_code(code: str) -> str:
    \"\"\"Prompt template for code review.\"\"\"
    return f"Please review this code:\\n\\n{code}"

if __name__ == "__main__":
    mcp.run()  # stdio transport by default
```
- Type hints auto-generate JSON schemas for tool parameters
- Docstrings become tool/resource descriptions
- `mcp.run(transport="sse")` for SSE transport
- Install: `pip install "mcp[cli]"` or `uv add "mcp[cli]"`

### TypeScript SDK (Tier 1) — `@modelcontextprotocol/sdk`
```typescript
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";

const server = new McpServer({ name: "my-server", version: "1.0.0" });

server.tool("my_tool", { param: z.string() }, async ({ param }) => ({
  content: [{ type: "text", text: `Result: ${param}` }],
}));

server.resource("config://app", async () => ({
  contents: [{ uri: "config://app", text: JSON.stringify({ version: "1.0" }) }],
}));

const transport = new StdioServerTransport();
await server.connect(transport);
```
- Zod schemas for input validation
- Install: `npm install @modelcontextprotocol/sdk zod`

### Go SDK (Tier 1) — `github.com/modelcontextprotocol/go-sdk`
```go
package main

import (
    "context"
    "github.com/modelcontextprotocol/go-sdk/mcp"
    "github.com/modelcontextprotocol/go-sdk/server"
)

func main() {
    s := server.NewMCPServer("my-server", "1.0.0")
    s.AddTool(mcp.NewTool("my_tool",
        mcp.WithDescription("Tool description"),
        mcp.WithString("param", mcp.Description("Parameter description"), mcp.Required()),
    ), handler)
    // Use server.NewStdioTransport() or server.NewSSETransport()
}
```

### MCP Apps (Interactive UI)
Servers can return interactive HTML interfaces via `ui://` resources:
- Tool descriptions include `_meta.ui.resourceUri` pointing to a `ui://` resource
- The UI resource contains HTML that renders in a sandboxed iframe
- Apps communicate with the host via postMessage JSON-RPC
- Use `@modelcontextprotocol/ext-apps` for the App class and PostMessageTransport
- Good for dashboards, data visualization, forms, and real-time monitoring

## Best Practices
1. Always validate inputs with proper schemas (Pydantic for Python, Zod for TS)
2. Use stderr for logging in stdio transport (stdout is the protocol channel)
3. Include proper error messages in tool responses
4. Add type hints / type annotations everywhere
5. Include a clear README section in comments explaining setup + usage
6. For stdio: the server file should be self-contained and runnable
7. For SSE/HTTP: include CORS configuration and port setup

## Rules
1. Generate complete, runnable code — no placeholders or TODOs.
2. Default to Python with FastMCP unless the user specifies a language.
3. Include setup instructions as comments at the top of the file.
4. Always include at least one tool, even if the user only asks for resources.
5. Test that the code would parse correctly — no syntax errors.
6. Include example claude_desktop_config.json snippet for easy setup."""


class AgentState(TypedDict):
    task: str
    plan: str
    code: str
    review: str
    current_step: str
    messages: list


def plan_node(state: AgentState) -> dict:
    """Analyze MCP requirements — language, tools, resources, transport."""
    llm = get_llm("mcp-maker", temperature=0.3, max_tokens=2048, state=state)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"A user hired you to create an MCP server:\n\n{state['task']}\n\n"
                "Create a brief plan (3-5 bullet points):\n"
                "- What language? (Python/TypeScript/Go)\n"
                "- What tools will this server expose?\n"
                "- What resources (if any)?\n"
                "- What transport? (stdio/SSE)\n"
                "- Any external dependencies needed?\n"
                "Be terse."
            ),
        ]
    )
    return {
        "plan": extract_text(response.content),
        "current_step": "thinking",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def generate_node(state: AgentState) -> dict:
    """Generate the complete MCP server code."""
    llm = get_llm("mcp-maker", temperature=0.2, max_tokens=8192, state=state)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"MCP server request: {state['task']}\n\n"
                f"Your plan:\n{state['plan']}\n\n"
                "Now generate the complete MCP server code. Include:\n"
                "1. Setup instructions as comments at the top\n"
                "2. All imports\n"
                "3. Server initialization\n"
                "4. All tool definitions with proper schemas\n"
                "5. All resource definitions (if applicable)\n"
                "6. Transport setup and main entry point\n"
                "7. Example claude_desktop_config.json snippet as a comment\n\n"
                "Output the code in a single fenced code block."
            ),
        ]
    )
    return {
        "code": extract_text(response.content),
        "current_step": "coding",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def review_node(state: AgentState) -> dict:
    """Review the generated MCP server for correctness."""
    llm = get_llm("mcp-maker", temperature=0.1, max_tokens=2048, state=state)
    response = llm.invoke(
        [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(
                content=f"Review this MCP server code for correctness:\n\n{state['code']}\n\n"
                "Check for:\n"
                "1. Correct SDK import paths and API usage\n"
                "2. Proper input validation / schema definitions\n"
                "3. Error handling in tool implementations\n"
                "4. Transport configuration correctness\n"
                "5. Any missing dependencies or setup steps\n\n"
                "Rate: PROTOCOL_COMPLIANT / NEEDS_FIXES / BROKEN\n"
                "List any issues found (max 5)."
            ),
        ]
    )
    return {
        "review": extract_text(response.content),
        "current_step": "reviewing",
        "token_usage": accumulate_usage(state, extract_usage(response)),
    }


def build_mcp_maker_graph() -> StateGraph:
    workflow = StateGraph(AgentState)
    workflow.add_node("plan", plan_node)
    workflow.add_node("generate", generate_node)
    workflow.add_node("review", review_node)
    workflow.set_entry_point("plan")
    workflow.add_edge("plan", "generate")
    workflow.add_edge("generate", "review")
    workflow.add_edge("review", END)
    return workflow.compile()
