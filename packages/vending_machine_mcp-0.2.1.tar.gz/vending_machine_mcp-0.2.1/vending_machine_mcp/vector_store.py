"""
SQLite-backed embedding store for MCP users (BYOK).

Stores document embeddings under named collections. Uses the same API keys as the
rest of the package (Voyage → OpenAI → Gemini → deterministic local hash).
Similarity search runs in-process (cosine); no native SQLite extensions required.

Embedding model selection:
- Env vars: EMBEDDING_PROVIDER, EMBEDDING_MODEL, EMBEDDING_DIMENSIONS
- Per-call overrides via provider/model/dimensions params
- Per-collection auto-detect for search/query (reads stored provider + model)
"""

from __future__ import annotations

import asyncio
import json
import logging
import math
import os
import sqlite3
import time
import uuid
from pathlib import Path
from threading import RLock

logger = logging.getLogger("vector_store")

_lock = RLock()
_conn: sqlite3.Connection | None = None

# ---------------------------------------------------------------------------
# Supported providers and models
# ---------------------------------------------------------------------------

PROVIDER_MODELS: dict[str, dict] = {
    "openai": {
        "default": "text-embedding-3-small",
        "models": [
            "text-embedding-3-small",
            "text-embedding-3-large",
        ],
        "env_key": "OPENAI_API_KEY",
        "dimensions_param": "dimensions",
    },
    "voyage": {
        "default": "voyage-4-lite",
        "models": [
            "voyage-4-lite",
            "voyage-4",
            "voyage-4-large",
            "voyage-code-3",
            "voyage-finance-2",
            "voyage-law-2",
            "voyage-code-2",
            "voyage-4-nano",
            "voyage-context-3",
            "voyage-multimodal-3.5",
        ],
        "env_key": "VOYAGE_API_KEY",
        "dimensions_param": "output_dimension",
    },
    "gemini": {
        "default": "gemini-embedding-001",
        "models": [
            "gemini-embedding-001",
            "gemini-embedding-2-preview",
        ],
        "env_key": "GEMINI_API_KEY",
        "legacy_env_key": "GOOGLE_API_KEY",
        "dimensions_param": "output_dimensionality",
    },
    "local": {
        "default": "local-hash-256",
        "models": ["local-hash-256"],
        "env_key": "",
        "dimensions_param": "dims",
    },
}


def _default_provider() -> str:
    """Read EMBEDDING_PROVIDER env var, or auto-detect from available keys."""
    configured = os.getenv("EMBEDDING_PROVIDER", "").strip().lower()
    if configured and configured in PROVIDER_MODELS:
        return configured
    for name, info in PROVIDER_MODELS.items():
        if name == "local":
            continue
        key = info.get("env_key", "")
        if key and os.getenv(key, "").strip():
            return name
        legacy = info.get("legacy_env_key", "")
        if legacy and os.getenv(legacy, "").strip():
            return name
    return "local"


def _default_model(provider: str) -> str:
    configured = os.getenv("EMBEDDING_MODEL", "").strip()
    if configured:
        return configured
    info = PROVIDER_MODELS.get(provider)
    return info["default"] if info else "text-embedding-3-small"


def _default_dimensions() -> int | None:
    val = os.getenv("EMBEDDING_DIMENSIONS", "").strip()
    if val:
        try:
            return int(val)
        except ValueError:
            pass
    return None


# ---------------------------------------------------------------------------
# SQLite
# ---------------------------------------------------------------------------


def _db_path() -> Path:
    configured = os.getenv("VECTOR_STORE_DB", "").strip()
    if configured:
        return Path(configured).expanduser()
    base = Path(os.getenv("XDG_DATA_HOME", str(Path.home() / ".local" / "share")))
    d = base / "vending-machine-mcp"
    d.mkdir(parents=True, exist_ok=True)
    return d / "vector_store.sqlite3"


def _get_conn() -> sqlite3.Connection:
    global _conn
    with _lock:
        if _conn is None:
            path = _db_path()
            path.parent.mkdir(parents=True, exist_ok=True)
            _conn = sqlite3.connect(str(path), check_same_thread=False)
            _conn.row_factory = sqlite3.Row
            _conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS vector_documents (
                    collection TEXT NOT NULL,
                    doc_id TEXT NOT NULL,
                    content TEXT NOT NULL,
                    provider TEXT NOT NULL,
                    dim INTEGER NOT NULL,
                    embedding_json TEXT NOT NULL,
                    metadata_json TEXT NOT NULL,
                    created_at REAL NOT NULL,
                    PRIMARY KEY (collection, doc_id)
                );
                CREATE INDEX IF NOT EXISTS idx_vec_collection ON vector_documents(collection);
                """
            )
            # Migration: add model column if missing (pre-existing DBs)
            cols = {r[1] for r in _conn.execute("PRAGMA table_info(vector_documents)").fetchall()}
            if "model" not in cols:
                _conn.execute("ALTER TABLE vector_documents ADD COLUMN model TEXT NOT NULL DEFAULT ''")
            _conn.commit()
        return _conn


# ---------------------------------------------------------------------------
# Embedding helpers
# ---------------------------------------------------------------------------


def _local_hash_embedding(text: str, dims: int = 256) -> list[float]:
    import hashlib as _hashlib

    vec = [0.0] * dims
    tokens = [t for t in "".join(c.lower() if c.isalnum() else " " for c in text).split() if len(t) > 1]
    for token in tokens:
        h = _hashlib.sha256(token.encode("utf-8")).digest()
        idx = int.from_bytes(h[:2], "big") % dims
        sign = 1.0 if (h[2] % 2 == 0) else -1.0
        weight = 1.0 + (len(token) / 16.0)
        vec[idx] += sign * weight
    norm = math.sqrt(sum(x * x for x in vec))
    if norm == 0:
        return vec
    return [x / norm for x in vec]


def _cosine(a: list[float], b: list[float]) -> float:
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b, strict=False))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(y * y for y in b))
    return dot / (na * nb) if na and nb else 0.0


def _gemini_key() -> str:
    return os.getenv("GEMINI_API_KEY", "").strip() or os.getenv("GOOGLE_API_KEY", "").strip()


async def _embed_voyage(text: str, model: str, for_query: bool, dimensions: int | None) -> list[float]:
    def _run():
        import voyageai
        client = voyageai.Client(api_key=os.environ["VOYAGE_API_KEY"])
        itype = "query" if for_query else "document"
        kwargs: dict = {"input_type": itype}
        if dimensions is not None:
            kwargs["output_dimension"] = dimensions
        result = client.embed([text], model=model, **kwargs)
        return result.embeddings[0]
    return await asyncio.to_thread(_run)


async def _embed_openai(text: str, model: str, for_query: bool, dimensions: int | None) -> list[float]:
    from openai import OpenAI
    client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
    kwargs: dict = {}
    if dimensions is not None:
        kwargs["dimensions"] = dimensions

    def _run():
        r = client.embeddings.create(model=model, input=text, **kwargs)
        return list(r.data[0].embedding)
    return await asyncio.to_thread(_run)


async def _embed_gemini(text: str, model: str, for_query: bool, dimensions: int | None) -> list[float]:
    from google import genai

    def _run():
        client = genai.Client(api_key=_gemini_key())
        kwargs: dict = {}
        if dimensions is not None:
            kwargs["output_dimensionality"] = dimensions
        res = client.models.embed_content(model=model, contents=[text], **kwargs)
        emb = res.embeddings[0]
        vals = getattr(emb, "values", emb)
        if hasattr(vals, "__iter__") and not isinstance(vals, (str, bytes)):
            return [float(x) for x in vals]
        return [float(vals)]
    return await asyncio.to_thread(_run)


async def embed_text(
    text: str,
    *,
    for_query: bool,
    provider: str | None = None,
    model: str | None = None,
    dimensions: int | None = None,
) -> tuple[list[float], str, str]:
    """Return (embedding, provider_label, model_used). Truncates very long inputs.

    Resolution order for each parameter:
      explicit arg -> env var default -> auto-detect from keys
    """
    chunk = text if len(text) <= 32000 else text[:32000]

    prov = provider or _default_provider()
    mdl = model or _default_model(prov)
    dims = dimensions if dimensions is not None else _default_dimensions()

    if prov == "voyage" and os.getenv("VOYAGE_API_KEY", "").strip():
        try:
            vec = await _embed_voyage(chunk, mdl, for_query, dims)
            return vec, "voyage", mdl
        except Exception as e:
            logger.warning("Voyage embed failed: %s", e)
            if provider:
                raise

    if prov == "openai" and os.getenv("OPENAI_API_KEY", "").strip():
        try:
            vec = await _embed_openai(chunk, mdl, for_query, dims)
            return vec, "openai", mdl
        except Exception as e:
            logger.warning("OpenAI embed failed: %s", e)
            if provider:
                raise

    if prov == "gemini" and _gemini_key():
        try:
            vec = await _embed_gemini(chunk, mdl, for_query, dims)
            return vec, "gemini", mdl
        except Exception as e:
            logger.warning("Gemini embed failed: %s", e)
            if provider:
                raise

    # Fallback chain when no explicit provider was requested
    if not provider:
        if os.getenv("VOYAGE_API_KEY", "").strip() and prov != "voyage":
            try:
                fallback_mdl = _default_model("voyage")
                vec = await _embed_voyage(chunk, fallback_mdl, for_query, dims)
                return vec, "voyage", fallback_mdl
            except Exception as e:
                logger.warning("Voyage fallback failed: %s", e)

        if os.getenv("OPENAI_API_KEY", "").strip() and prov != "openai":
            try:
                fallback_mdl = _default_model("openai")
                vec = await _embed_openai(chunk, fallback_mdl, for_query, dims)
                return vec, "openai", fallback_mdl
            except Exception as e:
                logger.warning("OpenAI fallback failed: %s", e)

        if _gemini_key() and prov != "gemini":
            try:
                fallback_mdl = _default_model("gemini")
                vec = await _embed_gemini(chunk, fallback_mdl, for_query, dims)
                return vec, "gemini", fallback_mdl
            except Exception as e:
                logger.warning("Gemini fallback failed: %s", e)

    local_dims = dims if dims is not None else 256
    return _local_hash_embedding(chunk, local_dims), "local", f"local-hash-{local_dims}"


# ---------------------------------------------------------------------------
# Collection config detection
# ---------------------------------------------------------------------------


def _collection_config(collection: str) -> tuple[str, str, int] | None:
    """Return (provider, model, dim) from the first row in a collection, or None."""
    conn = _get_conn()
    row = conn.execute(
        "SELECT provider, model, dim FROM vector_documents WHERE collection = ? LIMIT 1",
        (collection,),
    ).fetchone()
    if not row:
        return None
    return (row["provider"], row["model"] or "", row["dim"])


async def embed_text_for_provider(
    text: str,
    provider: str,
    *,
    for_query: bool,
    model: str = "",
    dimensions: int | None = None,
) -> list[float]:
    """Embed using a specific provider (and optionally model), regardless of key priority."""
    chunk = text if len(text) <= 32000 else text[:32000]
    mdl = model or _default_model(provider)
    dims = dimensions if dimensions is not None else _default_dimensions()

    if provider == "voyage" and os.getenv("VOYAGE_API_KEY", "").strip():
        return await _embed_voyage(chunk, mdl, for_query, dims)

    if provider == "openai" and os.getenv("OPENAI_API_KEY", "").strip():
        return await _embed_openai(chunk, mdl, for_query, dims)

    if provider == "gemini" and _gemini_key():
        return await _embed_gemini(chunk, mdl, for_query, dims)

    if provider == "local":
        local_dims = dims if dims is not None else 256
        return _local_hash_embedding(chunk, local_dims)

    vec, _, _ = await embed_text(chunk, for_query=for_query)
    return vec


# ---------------------------------------------------------------------------
# Storage
# ---------------------------------------------------------------------------


def _add_sync(
    collection: str,
    doc_id: str,
    content: str,
    provider: str,
    embedding: list[float],
    metadata: dict,
    model: str = "",
) -> None:
    conn = _get_conn()
    with _lock:
        conn.execute(
            """
            INSERT INTO vector_documents
            (collection, doc_id, content, provider, dim, embedding_json, metadata_json, created_at, model)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(collection, doc_id) DO UPDATE SET
                content=excluded.content,
                provider=excluded.provider,
                dim=excluded.dim,
                embedding_json=excluded.embedding_json,
                metadata_json=excluded.metadata_json,
                created_at=excluded.created_at,
                model=excluded.model
            """,
            (
                collection,
                doc_id,
                content,
                provider,
                len(embedding),
                json.dumps(embedding),
                json.dumps(metadata),
                time.time(),
                model,
            ),
        )
        conn.commit()


async def add_document(
    collection: str,
    text: str,
    doc_id: str = "",
    metadata: dict | None = None,
    provider: str | None = None,
    model: str | None = None,
    dimensions: int | None = None,
) -> str:
    if not collection.strip():
        return "Error: collection name is required."
    if not text.strip():
        return "Error: text content is empty."
    did = doc_id.strip() or str(uuid.uuid4())
    vec, prov, mdl = await embed_text(
        text, for_query=False, provider=provider, model=model, dimensions=dimensions,
    )
    meta = metadata if metadata is not None else {}
    await asyncio.to_thread(_add_sync, collection.strip(), did, text, prov, vec, meta, mdl)
    path = _db_path()
    return (
        f"Stored document `{did}` in collection `{collection.strip()}` "
        f"(provider={prov}, model={mdl}, dim={len(vec)}).\n"
        f"Database: {path}"
    )


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------


def _search_sync(collection: str, query_embedding: list[float], limit: int) -> list[dict]:
    conn = _get_conn()
    qdim = len(query_embedding)
    rows = conn.execute(
        """
        SELECT doc_id, content, metadata_json, embedding_json
        FROM vector_documents
        WHERE collection = ? AND dim = ?
        """,
        (collection, qdim),
    ).fetchall()

    scored: list[tuple[float, sqlite3.Row]] = []
    for row in rows:
        try:
            emb = json.loads(row["embedding_json"])
        except (json.JSONDecodeError, TypeError):
            continue
        scored.append((_cosine(query_embedding, emb), row))

    scored.sort(key=lambda x: x[0], reverse=True)
    out = []
    for score, row in scored[:limit]:
        try:
            meta = json.loads(row["metadata_json"] or "{}")
        except json.JSONDecodeError:
            meta = {}
        out.append(
            {
                "doc_id": row["doc_id"],
                "score": round(score, 6),
                "content_preview": (row["content"][:500] + "\u2026") if len(row["content"]) > 500 else row["content"],
                "metadata": meta,
            }
        )
    return out


async def search(
    collection: str,
    query: str,
    limit: int = 5,
    provider: str | None = None,
    model: str | None = None,
    dimensions: int | None = None,
) -> str:
    if not collection.strip():
        return "Error: collection name is required."
    if not query.strip():
        return "Error: query is empty."
    lim = max(1, min(limit, 50))
    col = collection.strip()

    # Auto-detect collection config unless caller overrides
    if not provider:
        cfg = await asyncio.to_thread(_collection_config, col)
        if cfg:
            stored_prov, stored_mdl, stored_dim = cfg
            effective_dims = dimensions if dimensions is not None else stored_dim
            try:
                qvec = await embed_text_for_provider(
                    query.strip(), stored_prov, for_query=True,
                    model=stored_mdl, dimensions=effective_dims,
                )
                hits = await asyncio.to_thread(_search_sync, col, qvec, lim)
                if hits:
                    return _format_search_results(col, hits)
            except Exception as e:
                logger.warning("Collection-matched embed failed: %s", e)

    qvec, _, _ = await embed_text(
        query.strip(), for_query=True, provider=provider, model=model, dimensions=dimensions,
    )
    hits = await asyncio.to_thread(_search_sync, col, qvec, lim)
    if not hits:
        return (
            f"No matches in `{col}` for this query embedding "
            f"(dim={len(qvec)}). Add documents with the same embedding provider/keys, "
            f"or use an empty collection check with vector_store_list."
        )
    return _format_search_results(col, hits)


def _format_search_results(col: str, hits: list[dict]) -> str:
    lines = [f"Top {len(hits)} results in `{col}`:\n"]
    for i, h in enumerate(hits, 1):
        lines.append(f"{i}. doc_id={h['doc_id']}  score={h['score']}")
        if h.get("metadata"):
            lines.append(f"   metadata: {h['metadata']}")
        lines.append(f"   {h['content_preview']}\n")
    lines.append(f"Store file: {_db_path()}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# List
# ---------------------------------------------------------------------------


def _list_sync(collection: str | None, limit: int) -> str:
    conn = _get_conn()
    if not collection:
        rows = conn.execute(
            "SELECT collection, COUNT(*) AS n FROM vector_documents GROUP BY collection ORDER BY collection"
        ).fetchall()
        if not rows:
            return f"No collections yet. Database: {_db_path()}"
        lines = ["Collections:\n"]
        for r in rows:
            lines.append(f"  {r['collection']}: {r['n']} document(s)")
        lines.append(f"\nDatabase: {_db_path()}")
        return "\n".join(lines)

    rows = conn.execute(
        """
        SELECT doc_id, provider, model, dim, LENGTH(content) AS chars, created_at
        FROM vector_documents
        WHERE collection = ?
        ORDER BY created_at DESC
        LIMIT ?
        """,
        (collection, limit),
    ).fetchall()
    if not rows:
        return f"No documents in collection `{collection}`."
    lines = [f"Documents in `{collection}` (newest first, max {limit}):\n"]
    for r in rows:
        mdl_str = f"  model={r['model']}" if r["model"] else ""
        lines.append(
            f"  {r['doc_id']}  provider={r['provider']}{mdl_str}  dim={r['dim']}  "
            f"chars={r['chars']}  created={r['created_at']:.0f}"
        )
    lines.append(f"\nDatabase: {_db_path()}")
    return "\n".join(lines)


async def list_collections_or_docs(collection: str = "", limit: int = 50) -> str:
    lim = max(1, min(limit, 200))
    c = collection.strip()
    return await asyncio.to_thread(_list_sync, c or None, lim)


# ---------------------------------------------------------------------------
# RAG: query_knowledge — vector search + LLM answer
# ---------------------------------------------------------------------------

_RAG_SYSTEM_PROMPT = (
    "You are a helpful assistant. Answer the user's question using ONLY the "
    "provided context excerpts. If the context does not contain enough information, "
    "say so honestly. Cite the chunk numbers you relied on (e.g. [1], [3])."
)


def _rag_llm_available() -> bool:
    return bool(
        os.getenv("OPENROUTER_API_KEY", "").strip()
        or os.getenv("OPENAI_API_KEY", "").strip()
        or _gemini_key()
    )


async def _rag_llm_generate(system: str, user: str) -> str:
    """Call the best available LLM. Priority: OpenRouter -> OpenAI -> Gemini."""

    openrouter_key = os.getenv("OPENROUTER_API_KEY", "").strip()
    if openrouter_key:
        try:
            from langchain_openai import ChatOpenAI

            llm = ChatOpenAI(
                model="google/gemini-3-flash-preview",
                api_key=openrouter_key,
                base_url="https://openrouter.ai/api/v1",
                max_tokens=2048,
                temperature=0.2,
            )
            resp = await asyncio.to_thread(
                lambda: llm.invoke([
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ])
            )
            return resp.content if hasattr(resp, "content") else str(resp)
        except Exception as e:
            logger.warning("OpenRouter RAG LLM failed: %s", e)

    openai_key = os.getenv("OPENAI_API_KEY", "").strip()
    if openai_key:
        try:
            from openai import OpenAI

            client = OpenAI(api_key=openai_key)
            resp = await asyncio.to_thread(
                lambda: client.chat.completions.create(
                    model="gpt-4.1-mini",
                    messages=[
                        {"role": "system", "content": system},
                        {"role": "user", "content": user},
                    ],
                    max_tokens=2048,
                    temperature=0.2,
                )
            )
            return resp.choices[0].message.content or ""
        except Exception as e:
            logger.warning("OpenAI RAG LLM failed: %s", e)

    gkey = _gemini_key()
    if gkey:
        try:
            from google import genai

            def _run():
                client = genai.Client(api_key=gkey)
                resp = client.models.generate_content(
                    model="gemini-2.0-flash",
                    contents=f"{system}\n\n{user}",
                )
                return resp.text

            return await asyncio.to_thread(_run)
        except Exception as e:
            logger.warning("Gemini RAG LLM failed: %s", e)

    return ""


async def rag_query(
    collection: str,
    question: str,
    limit: int = 5,
    provider: str | None = None,
    model: str | None = None,
    dimensions: int | None = None,
) -> str:
    """Retrieve relevant chunks from a collection and answer via LLM."""
    if not collection.strip():
        return "Error: collection name is required."
    if not question.strip():
        return "Error: question is empty."
    if not _rag_llm_available():
        return (
            "Error: No LLM key configured for query_knowledge. "
            "Set OPENROUTER_API_KEY, OPENAI_API_KEY, or GEMINI_API_KEY."
        )

    lim = max(1, min(limit, 20))
    col = collection.strip()

    # Auto-detect collection's embedding config unless caller overrides
    if not provider:
        cfg = await asyncio.to_thread(_collection_config, col)
        if cfg:
            stored_prov, stored_mdl, stored_dim = cfg
            effective_dims = dimensions if dimensions is not None else stored_dim
            try:
                qvec = await embed_text_for_provider(
                    question.strip(), stored_prov, for_query=True,
                    model=stored_mdl, dimensions=effective_dims,
                )
            except Exception as e:
                logger.warning("Provider-matched embed failed (%s), falling back: %s", stored_prov, e)
                qvec, _, _ = await embed_text(question.strip(), for_query=True)
        else:
            qvec, _, _ = await embed_text(question.strip(), for_query=True)
    else:
        qvec = await embed_text_for_provider(
            question.strip(), provider, for_query=True,
            model=model or "", dimensions=dimensions,
        )

    hits = await asyncio.to_thread(_search_sync, col, qvec, lim)

    if not hits:
        return (
            f"No matching documents in `{col}` for this question. "
            "Make sure the collection exists (check with vector_store_list) and "
            "that documents were added with the same embedding provider/keys."
        )

    context_parts = []
    for i, h in enumerate(hits, 1):
        preview = h["content_preview"]
        context_parts.append(f"[{i}] (score={h['score']})  {preview}")

    context_block = "\n\n".join(context_parts)
    user_prompt = (
        f"## Context from collection `{col}`\n\n"
        f"{context_block}\n\n"
        f"## Question\n\n{question.strip()}"
    )

    answer = await _rag_llm_generate(_RAG_SYSTEM_PROMPT, user_prompt)
    if not answer:
        return (
            "Retrieved context but failed to generate an answer. "
            "Check your LLM API key configuration."
        )

    source_lines = []
    for i, h in enumerate(hits[:3], 1):
        doc = h["doc_id"]
        score = h["score"]
        source_lines.append(f"  [{i}] {doc} (score={score})")

    return (
        f"{answer}\n\n"
        f"---\n"
        f"Sources (collection=`{col}`, top {len(hits)}):\n"
        + "\n".join(source_lines)
    )
