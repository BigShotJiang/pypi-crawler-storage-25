"""
Local script index for marketplace search: SQLite + bring-your-own-key embeddings.

Stores script metadata and vectors in script_index.sqlite3 under the user data
directory unless SCRIPT_INDEX_DB_PATH is set. No separate graph database is required.

Embeddings: Voyage voyage-code-3 → OpenAI text-embedding-3-small → Gemini
text-embedding-004 → deterministic local hash. Query and indexed documents
must use the same provider in a given install; rows whose vector length differs
from the query are skipped (e.g. after changing API keys, re-seed or delete the DB).

Environment:
- SCRIPT_INDEX_DB_PATH: optional path to sqlite db
- VOYAGE_API_KEY, OPENAI_API_KEY, GEMINI_API_KEY / GOOGLE_API_KEY
"""

from __future__ import annotations

import hashlib
import json
import logging
import math
import os
import secrets
import sqlite3
import string
import time as _time
from pathlib import Path
from threading import RLock

logger = logging.getLogger("graph")

_sqlite_conn: sqlite3.Connection | None = None
_sqlite_ready = False
_sqlite_lock = RLock()

_CODE_CHARS = string.ascii_uppercase + string.digits

_session_last_run: dict[str, tuple[str, float]] = {}
_CHAIN_WINDOW_SECONDS = 60
_usage_call_count = 0


def _default_sqlite_path() -> Path:
    base = Path(os.getenv("XDG_DATA_HOME", str(Path.home() / ".local" / "share")))
    d = base / "vending-machine-mcp"
    d.mkdir(parents=True, exist_ok=True)
    return d / "script_index.sqlite3"


def _sqlite_path() -> Path:
    configured = os.getenv("SCRIPT_INDEX_DB_PATH", "").strip()
    return Path(configured).expanduser() if configured else _default_sqlite_path()


def _get_sqlite_conn() -> sqlite3.Connection:
    global _sqlite_conn
    if _sqlite_conn is None:
        path = _sqlite_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        _sqlite_conn = sqlite3.connect(str(path), check_same_thread=False)
        _sqlite_conn.row_factory = sqlite3.Row
        logger.info("SQLite script index connected: %s", path)
    _ensure_sqlite_schema()
    return _sqlite_conn


def _ensure_sqlite_schema() -> None:
    global _sqlite_ready
    if _sqlite_ready:
        return

    conn = _sqlite_conn
    if conn is None:
        return

    with _sqlite_lock:
        if _sqlite_ready:
            return
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS script_index (
                script_id TEXT PRIMARY KEY,
                vending_code TEXT NOT NULL UNIQUE,
                name TEXT NOT NULL,
                description TEXT NOT NULL,
                creator TEXT NOT NULL,
                price REAL NOT NULL DEFAULT 0,
                runs INTEGER NOT NULL DEFAULT 0,
                revenue REAL NOT NULL DEFAULT 0,
                validation_status TEXT NOT NULL DEFAULT 'pending',
                input_schema TEXT NOT NULL DEFAULT '',
                packages_json TEXT NOT NULL DEFAULT '[]',
                embedding_json TEXT,
                created_at REAL NOT NULL DEFAULT (strftime('%s','now')),
                version INTEGER NOT NULL DEFAULT 1,
                code_hash TEXT NOT NULL DEFAULT ''
            );

            CREATE INDEX IF NOT EXISTS idx_script_index_status ON script_index(validation_status);
            CREATE INDEX IF NOT EXISTS idx_script_index_code ON script_index(vending_code);

            CREATE TABLE IF NOT EXISTS script_chains (
                prev_code TEXT NOT NULL,
                next_code TEXT NOT NULL,
                chain_count INTEGER NOT NULL DEFAULT 1,
                PRIMARY KEY (prev_code, next_code)
            );
            """
        )
        conn.commit()
        _sqlite_ready = True


def _sqlite_code_exists(code: str) -> bool:
    conn = _get_sqlite_conn()
    row = conn.execute("SELECT 1 FROM script_index WHERE vending_code = ? LIMIT 1", (code,)).fetchone()
    return row is not None


def _sqlite_sync_script(script: dict, embedding: list[float] | None = None) -> str:
    conn = _get_sqlite_conn()
    vending_code = script.get("vending_code") or script.get("vendingCode") or ""
    if not vending_code:
        vending_code = generate_vending_code()

    with _sqlite_lock:
        conn.execute(
            """
            INSERT INTO script_index (
                script_id, vending_code, name, description, creator, price, runs, revenue,
                validation_status, input_schema, packages_json, embedding_json, created_at,
                version, code_hash
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(script_id) DO UPDATE SET
                vending_code=excluded.vending_code,
                name=excluded.name,
                description=excluded.description,
                creator=excluded.creator,
                price=excluded.price,
                runs=excluded.runs,
                revenue=excluded.revenue,
                validation_status=excluded.validation_status,
                input_schema=excluded.input_schema,
                packages_json=excluded.packages_json,
                embedding_json=CASE
                    WHEN excluded.embedding_json IS NULL OR excluded.embedding_json = ''
                    THEN script_index.embedding_json
                    ELSE excluded.embedding_json
                END,
                version=excluded.version,
                code_hash=excluded.code_hash
            """,
            (
                script.get("script_id", ""),
                vending_code,
                script.get("name", ""),
                script.get("description", ""),
                script.get("creator", "unknown"),
                float(script.get("price", 0.0)),
                int(script.get("runs", 0)),
                float(script.get("revenue", 0.0)),
                script.get("validation_status", "pending"),
                script.get("input_schema", ""),
                json.dumps(script.get("packages", [])),
                json.dumps(embedding) if embedding is not None else None,
                float(script.get("created_at", _time.time())),
                int(script.get("version", 1)),
                script.get("code_hash", ""),
            ),
        )
        conn.commit()

    logger.info("Script synced to sqlite index: %s (%s)", vending_code, script.get("name", ""))
    return vending_code


def _cosine_similarity(a: list[float], b: list[float]) -> float:
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b, strict=False))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(y * y for y in b))
    return dot / (na * nb) if na and nb else 0.0


def _local_hash_embedding(text: str, dims: int = 256) -> list[float]:
    vec = [0.0] * dims
    tokens = [t for t in "".join(c.lower() if c.isalnum() else " " for c in text).split() if len(t) > 1]
    for token in tokens:
        h = hashlib.sha256(token.encode("utf-8")).digest()
        idx = int.from_bytes(h[:2], "big") % dims
        sign = 1.0 if (h[2] % 2 == 0) else -1.0
        weight = 1.0 + (len(token) / 16.0)
        vec[idx] += sign * weight

    norm = math.sqrt(sum(x * x for x in vec))
    if norm == 0:
        return vec
    return [x / norm for x in vec]


def _gemini_key() -> str:
    return os.getenv("GEMINI_API_KEY", "").strip() or os.getenv("GOOGLE_API_KEY", "").strip()


def _env_provider() -> str:
    """Read EMBEDDING_PROVIDER env var, or auto-detect from keys (same logic as vector_store)."""
    configured = os.getenv("EMBEDDING_PROVIDER", "").strip().lower()
    if configured in {"openai", "voyage", "gemini", "local"}:
        return configured
    if os.getenv("VOYAGE_API_KEY", "").strip():
        return "voyage"
    if os.getenv("OPENAI_API_KEY", "").strip():
        return "openai"
    if _gemini_key():
        return "gemini"
    return "local"


_PROVIDER_DEFAULTS = {
    "voyage": "voyage-4-lite",
    "openai": "text-embedding-3-small",
    "gemini": "gemini-embedding-001",
}


def _env_model(provider: str) -> str:
    configured = os.getenv("EMBEDDING_MODEL", "").strip()
    return configured or _PROVIDER_DEFAULTS.get(provider, "text-embedding-3-small")


def _env_dimensions() -> int | None:
    val = os.getenv("EMBEDDING_DIMENSIONS", "").strip()
    if val:
        try:
            return int(val)
        except ValueError:
            pass
    return None


def _embed_text_sync(text: str, *, for_query: bool) -> list[float]:
    """Embed text using env-configured provider/model/dimensions, with fallback chain."""
    chunk = text if len(text) <= 32000 else text[:32000]
    prov = _env_provider()
    mdl = _env_model(prov)
    dims = _env_dimensions()

    if prov == "voyage" or (prov not in ("openai", "gemini", "local") and os.getenv("VOYAGE_API_KEY", "").strip()):
        voyage_key = os.getenv("VOYAGE_API_KEY", "").strip()
        if voyage_key:
            try:
                import voyageai

                client = voyageai.Client(api_key=voyage_key)
                itype = "query" if for_query else "document"
                kwargs: dict = {"input_type": itype}
                if dims is not None:
                    kwargs["output_dimension"] = dims
                voyage_mdl = mdl if prov == "voyage" else _PROVIDER_DEFAULTS["voyage"]
                result = client.embed([chunk], model=voyage_mdl, **kwargs)
                return result.embeddings[0]
            except Exception as e:
                logger.warning("Voyage embedding failed, trying next provider: %s", e)

    if prov == "openai" or os.getenv("OPENAI_API_KEY", "").strip():
        openai_key = os.getenv("OPENAI_API_KEY", "").strip()
        if openai_key:
            try:
                from openai import OpenAI

                client = OpenAI(api_key=openai_key)
                kwargs = {}
                if dims is not None:
                    kwargs["dimensions"] = dims
                openai_mdl = mdl if prov == "openai" else _PROVIDER_DEFAULTS["openai"]
                r = client.embeddings.create(model=openai_mdl, input=chunk, **kwargs)
                return list(r.data[0].embedding)
            except Exception as e:
                logger.warning("OpenAI embedding failed, trying next provider: %s", e)

    gkey = _gemini_key()
    if prov == "gemini" or gkey:
        if gkey:
            try:
                from google import genai

                client = genai.Client(api_key=gkey)
                kwargs = {}
                if dims is not None:
                    kwargs["output_dimensionality"] = dims
                gemini_mdl = mdl if prov == "gemini" else _PROVIDER_DEFAULTS["gemini"]
                res = client.models.embed_content(model=gemini_mdl, contents=[chunk], **kwargs)
                emb = res.embeddings[0]
                vals = getattr(emb, "values", emb)
                if hasattr(vals, "__iter__") and not isinstance(vals, (str, bytes)):
                    return [float(x) for x in vals]
                return [float(vals)]
            except Exception as e:
                logger.warning("Gemini embedding failed, using local hash: %s", e)

    local_dims = dims if dims is not None else 256
    return _local_hash_embedding(chunk, local_dims)


def close() -> None:
    """Close the SQLite connection (e.g. for tests)."""
    global _sqlite_conn, _sqlite_ready
    if _sqlite_conn:
        _sqlite_conn.close()
        _sqlite_conn = None
        _sqlite_ready = False


def is_available() -> bool:
    try:
        _get_sqlite_conn()
        return True
    except Exception:
        return False


def init_graph() -> None:
    """Ensure SQLite schema exists."""
    _get_sqlite_conn()
    logger.info("MCP script index (SQLite) initialized")


def generate_vending_code() -> str:
    for _ in range(100):
        code = "S-" + "".join([secrets.choice(_CODE_CHARS) for _ in range(4)])
        if not _sqlite_code_exists(code):
            return code
    return "S-" + "".join([secrets.choice(_CODE_CHARS) for _ in range(5)])


def embed_script(script: dict) -> list[float]:
    text = (
        f"{script.get('name', '')}. {script.get('description', '')}. "
        f"Packages: {', '.join(script.get('packages', []))}. "
        f"Input: {script.get('input_schema', '')}. "
        f"Code: {str(script.get('code', ''))[:2000]}"
    )
    return _embed_text_sync(text, for_query=False)


def embed_query(query: str) -> list[float]:
    return _embed_text_sync(query, for_query=True)


def sync_script_to_graph(script: dict, embedding: list[float] | None = None) -> str:
    return _sqlite_sync_script(script, embedding=embedding)


def remove_script_from_graph(script_id: str) -> None:
    conn = _get_sqlite_conn()
    with _sqlite_lock:
        row = conn.execute("SELECT vending_code FROM script_index WHERE script_id = ?", (script_id,)).fetchone()
        conn.execute("DELETE FROM script_index WHERE script_id = ?", (script_id,))
        if row:
            code = row["vending_code"]
            conn.execute("DELETE FROM script_chains WHERE prev_code = ? OR next_code = ?", (code, code))
        conn.commit()


def search_scripts(query_embedding: list[float], limit: int = 5) -> list[dict]:
    qdim = len(query_embedding)
    conn = _get_sqlite_conn()
    rows = conn.execute(
        """
        SELECT vending_code, name, description, price, runs, validation_status, input_schema, creator, embedding_json
        FROM script_index
        WHERE validation_status IN ('approved', 'flagged')
        """
    ).fetchall()

    scored: list[dict] = []
    for row in rows:
        if not row["embedding_json"]:
            continue
        try:
            embedding = json.loads(row["embedding_json"])
        except Exception as e:
            logger.debug("Bad embedding JSON for %s: %s", row.get("vending_code", "?"), e)
            continue
        if len(embedding) != qdim:
            continue
        score = _cosine_similarity(query_embedding, embedding)
        scored.append(
            {
                "vendingCode": row["vending_code"],
                "name": row["name"],
                "description": row["description"],
                "price": float(row["price"]),
                "runs": int(row["runs"]),
                "validationStatus": row["validation_status"],
                "inputSchema": row["input_schema"],
                "creator": row["creator"],
                "score": score,
            }
        )

    scored.sort(key=lambda r: r["score"], reverse=True)
    return scored[:limit]


def get_script_by_code(vending_code: str) -> dict | None:
    conn = _get_sqlite_conn()
    row = conn.execute(
        """
        SELECT script_id, vending_code, name, description, creator, price, runs,
               revenue, validation_status, input_schema, packages_json
        FROM script_index
        WHERE vending_code = ?
        LIMIT 1
        """,
        (vending_code,),
    ).fetchone()
    if not row:
        return None
    return {
        "scriptId": row["script_id"],
        "vendingCode": row["vending_code"],
        "name": row["name"],
        "description": row["description"],
        "creator": row["creator"],
        "price": float(row["price"]),
        "runs": int(row["runs"]),
        "revenue": float(row["revenue"]),
        "validationStatus": row["validation_status"],
        "inputSchema": row["input_schema"],
        "packages": json.loads(row["packages_json"] or "[]"),
    }


def record_usage(vending_code: str, caller: str = "anonymous", session_id: str = "") -> None:
    del caller

    global _usage_call_count
    _usage_call_count += 1

    conn = _get_sqlite_conn()
    with _sqlite_lock:
        conn.execute(
            "UPDATE script_index SET runs = runs + 1 WHERE vending_code = ?",
            (vending_code,),
        )

        if session_id:
            prev = _session_last_run.get(session_id)
            if prev:
                prev_code, prev_time = prev
                if prev_code != vending_code and (_time.time() - prev_time) < _CHAIN_WINDOW_SECONDS:
                    conn.execute(
                        """
                        INSERT INTO script_chains (prev_code, next_code, chain_count)
                        VALUES (?, ?, 1)
                        ON CONFLICT(prev_code, next_code)
                        DO UPDATE SET chain_count = chain_count + 1
                        """,
                        (prev_code, vending_code),
                    )
            _session_last_run[session_id] = (vending_code, _time.time())

        conn.commit()

    if _usage_call_count % 100 == 0:
        _cleanup_stale_sessions()


def _cleanup_stale_sessions() -> None:
    cutoff = _time.time() - 300
    stale = [sid for sid, (_, ts) in _session_last_run.items() if ts < cutoff]
    for sid in stale:
        del _session_last_run[sid]


def get_similar_scripts(vending_code: str, limit: int = 3) -> list[dict]:
    conn = _get_sqlite_conn()
    src = conn.execute(
        "SELECT embedding_json FROM script_index WHERE vending_code = ? LIMIT 1",
        (vending_code,),
    ).fetchone()
    if not src or not src["embedding_json"]:
        return []
    try:
        source_embedding = json.loads(src["embedding_json"])
    except Exception:
        return []
    sdim = len(source_embedding)

    rows = conn.execute(
        """
        SELECT vending_code, name, description, embedding_json
        FROM script_index
        WHERE vending_code <> ? AND validation_status IN ('approved', 'flagged')
        """,
        (vending_code,),
    ).fetchall()

    scored = []
    for row in rows:
        if not row["embedding_json"]:
            continue
        try:
            emb = json.loads(row["embedding_json"])
        except Exception as e:
            logger.debug("Bad embedding JSON: %s", e)
            continue
        if len(emb) != sdim:
            continue
        scored.append(
            {
                "vendingCode": row["vending_code"],
                "name": row["name"],
                "description": row["description"],
                "score": _cosine_similarity(source_embedding, emb),
            }
        )
    scored.sort(key=lambda item: item["score"], reverse=True)
    return scored[:limit]


def get_script_chains(vending_code: str) -> list[dict]:
    conn = _get_sqlite_conn()
    rows = conn.execute(
        """
        SELECT c.next_code AS vendingCode, s.name AS name, c.chain_count AS chainCount
        FROM script_chains c
        JOIN script_index s ON s.vending_code = c.next_code
        WHERE c.prev_code = ? AND s.validation_status IN ('approved', 'flagged')
        ORDER BY c.chain_count DESC
        LIMIT 3
        """,
        (vending_code,),
    ).fetchall()
    return [dict(row) for row in rows]
