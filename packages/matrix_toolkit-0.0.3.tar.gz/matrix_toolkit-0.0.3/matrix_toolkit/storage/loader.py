"""Matrix loading functionality"""

import json
import pickle
from pathlib import Path
from typing import List, Union, Dict, Any, Optional
import numpy as np
from scipy import sparse
from scipy.io import mmread, loadmat
import h5py


class MatrixLoader:
    """Load matrices from various formats"""
    
    def load_collection(
        self,
        path: Union[str, Path],
        format: Optional[str] = None,
        load_metadata: bool = False,  # 改为默认 False
    ) -> Union[List, tuple]:
        """
        Load a collection of matrices
        
        Args:
            path: Directory path to load from
            format: 'npz', 'hdf5', 'mat', 'pickle', 'mtx' (auto-detect if None)
            load_metadata: Whether to load metadata (default: False)
        
        Returns:
            List of matrices if load_metadata=False, 
            or (matrices, metadata) tuple if load_metadata=True
        """
        path = Path(path)
        
        if not path.exists():
            raise FileNotFoundError(f"Path not found: {path}")
        
        # Auto-detect format
        if format is None:
            format = self._detect_format(path)
        
        if format == 'npz':
            matrices = self._load_npz(path)
        elif format == 'hdf5':
            matrices = self._load_hdf5(path)
        elif format == 'mat':
            matrices = self._load_mat(path)
        elif format == 'pickle':
            matrices = self._load_pickle(path)
        elif format == 'mtx':
            matrices = self._load_mtx(path)
        else:
            raise ValueError(f"Unknown format: {format}")
        
        # Load metadata if requested
        if load_metadata:
            metadata = self._load_metadata(path)
            return matrices, metadata
        
        return matrices
    
    def _detect_format(self, path: Path) -> str:
        """Auto-detect storage format"""
        if (path / "matrices.h5").exists():
            return 'hdf5'
        elif (path / "matrices.pkl").exists() or (path / "matrices.pkl.gz").exists():
            return 'pickle'
        elif list(path.glob("*.npz")):
            return 'npz'
        elif list(path.glob("*.mat")):
            return 'mat'
        elif list(path.glob("*.mtx")):
            return 'mtx'
        else:
            raise ValueError(f"Cannot detect format from path: {path}")
    
    def _load_npz(self, path: Path) -> List:
        """Load matrices from NPZ files"""
        matrices = []
        npz_files = sorted(path.glob("*.npz"))
        
        for npz_file in npz_files:
            matrix = sparse.load_npz(npz_file)
            matrices.append(matrix)
        
        return matrices
    
    def _load_hdf5(self, path: Path) -> List:
        """Load matrices from HDF5 file"""
        matrices = []
        file_path = path / "matrices.h5"
        
        with h5py.File(file_path, 'r') as f:
            # Get all groups sorted by name
            groups = sorted(f.keys())
            
            for group_name in groups:
                group = f[group_name]
                
                # Reconstruct COO matrix
                data = group['data'][:]
                row = group['row'][:]
                col = group['col'][:]
                shape = tuple(group.attrs['shape'])
                
                matrix = sparse.coo_matrix((data, (row, col)), shape=shape)
                matrices.append(matrix)
        
        return matrices
    
    def _load_mat(self, path: Path) -> List:
        """Load matrices from MATLAB files"""
        matrices = []
        mat_files = sorted(path.glob("*.mat"))
        
        for mat_file in mat_files:
            mat_data = loadmat(mat_file)
            # Assuming the matrix is stored with key 'matrix'
            matrix = mat_data['matrix']
            matrices.append(matrix)
        
        return matrices
    
    def _load_pickle(self, path: Path) -> List:
        """Load matrices from pickle file"""
        # Try compressed first
        compressed_path = path / "matrices.pkl.gz"
        uncompressed_path = path / "matrices.pkl"
        
        if compressed_path.exists():
            import gzip
            with gzip.open(compressed_path, 'rb') as f:
                matrices = pickle.load(f)
        elif uncompressed_path.exists():
            with open(uncompressed_path, 'rb') as f:
                matrices = pickle.load(f)
        else:
            raise FileNotFoundError("No pickle file found")
        
        return matrices
    
    def _load_mtx(self, path: Path) -> List:
        """Load matrices from Matrix Market files"""
        matrices = []
        mtx_files = sorted(path.glob("*.mtx"))
        
        for mtx_file in mtx_files:
            matrix = mmread(mtx_file)
            matrices.append(matrix)
        
        return matrices
    
    def _load_metadata(self, path: Path) -> Optional[List[Dict]]:
        """Load metadata from JSON file"""
        metadata_path = path / "metadata.json"
        
        if not metadata_path.exists():
            return None
        
        with open(metadata_path, 'r') as f:
            metadata = json.load(f)
        
        return metadata
    


    def load_collection(
        self,
        path: Union[str, Path],
        format: Optional[str] = None,
        load_metadata: bool = True,
    ) -> Union[List, tuple]:
        """
        Load a collection of matrices
        
        Args:
            path: Directory path to load from
            format: 'npz', 'hdf5', 'mat', 'pickle', 'mtx' (auto-detect if None)
            load_metadata: Whether to load metadata
        
        Returns:
            List of matrices, or (matrices, metadata) if load_metadata=True
        """
        path = Path(path)
        
        if not path.exists():
            raise FileNotFoundError(f"Path not found: {path}")
        
        # Auto-detect format
        if format is None:
            format = self._detect_format(path)
        
        if format == 'npz':
            matrices = self._load_npz(path)
        elif format == 'hdf5':
            matrices = self._load_hdf5(path)
        elif format == 'mat':
            matrices = self._load_mat(path)
        elif format == 'pickle':
            matrices = self._load_pickle(path)
        elif format == 'mtx':
            matrices = self._load_mtx(path)
        else:
            raise ValueError(f"Unknown format: {format}")
        
        # Load metadata if requested
        if load_metadata:
            metadata = self._load_metadata(path)
            return matrices, metadata
        
        return matrices