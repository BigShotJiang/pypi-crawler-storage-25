"""Matrix saving functionality"""

import json
import pickle
from pathlib import Path
from typing import List, Union, Dict, Any, Optional
import numpy as np
from scipy import sparse
from scipy.io import mmwrite, savemat
import h5py


class MatrixSaver:
    """Save matrices in various formats"""
    
    def save_collection(
        self,
        matrices: List,
        path: Union[str, Path],
        format: str = 'npz',
        compression: bool = True,
        metadata: Optional[Union[bool, List[Dict]]] = None,
    ):
        """
        Save a collection of matrices
        
        Args:
            matrices: List of matrices to save
            path: Directory path to save to
            format: 'npz', 'hdf5', 'mat', 'pickle', 'mtx'
            compression: Whether to use compression
            metadata: Matrix metadata (True to auto-generate, list of dicts, or None)
        """
        path = Path(path)
        path.mkdir(parents=True, exist_ok=True)
        
        if format == 'npz':
            self._save_npz(matrices, path, compression, metadata)
        elif format == 'hdf5':
            self._save_hdf5(matrices, path, compression, metadata)
        elif format == 'mat':
            self._save_mat(matrices, path, metadata)
        elif format == 'pickle':
            self._save_pickle(matrices, path, compression, metadata)
        elif format == 'mtx':
            self._save_mtx(matrices, path, metadata)
        else:
            raise ValueError(f"Unknown format: {format}")
    
    def _save_npz(
        self, 
        matrices: List, 
        path: Path, 
        compression: bool,
        metadata: Optional[Union[bool, List[Dict]]]
    ):
        """Save matrices as NPZ files"""
        for i, matrix in enumerate(matrices):
            file_path = path / f"matrix_{i:04d}.npz"
            
            # Convert to scipy sparse if needed
            if not sparse.issparse(matrix):
                matrix = sparse.csr_matrix(matrix)
            
            if compression:
                sparse.save_npz(file_path, matrix, compressed=True)
            else:
                sparse.save_npz(file_path, matrix, compressed=False)
        
        # Save metadata
        if metadata:
            self._save_metadata(matrices, path, metadata)
    
    def _save_hdf5(
        self,
        matrices: List,
        path: Path,
        compression: bool,
        metadata: Optional[Union[bool, List[Dict]]]
    ):
        """Save matrices as HDF5 file"""
        file_path = path / "matrices.h5"
        
        with h5py.File(file_path, 'w') as f:
            for i, matrix in enumerate(matrices):
                group = f.create_group(f"matrix_{i:04d}")
                
                # Convert to scipy sparse COO for storage
                if not sparse.issparse(matrix):
                    matrix = sparse.csr_matrix(matrix)
                matrix = sparse.coo_matrix(matrix)
                
                # Store COO components
                compression_opt = 'gzip' if compression else None
                group.create_dataset('data', data=matrix.data, compression=compression_opt)
                group.create_dataset('row', data=matrix.row, compression=compression_opt)
                group.create_dataset('col', data=matrix.col, compression=compression_opt)
                group.attrs['shape'] = matrix.shape
        
        # Save metadata
        if metadata:
            self._save_metadata(matrices, path, metadata)
    
    def _save_mat(
        self,
        matrices: List,
        path: Path,
        metadata: Optional[Union[bool, List[Dict]]]
    ):
        """Save matrices as MATLAB .mat files"""
        for i, matrix in enumerate(matrices):
            file_path = path / f"matrix_{i:04d}.mat"
            
            if not sparse.issparse(matrix):
                matrix = sparse.csr_matrix(matrix)
            
            savemat(file_path, {'matrix': matrix})
        
        # Save metadata
        if metadata:
            self._save_metadata(matrices, path, metadata)
    
    def _save_pickle(
        self,
        matrices: List,
        path: Path,
        compression: bool,
        metadata: Optional[Union[bool, List[Dict]]]
    ):
        """Save matrices as pickle files"""
        if compression:
            import gzip
            file_path = path / "matrices.pkl.gz"
            with gzip.open(file_path, 'wb') as f:
                pickle.dump(matrices, f)
        else:
            file_path = path / "matrices.pkl"
            with open(file_path, 'wb') as f:
                pickle.dump(matrices, f)
        
        # Save metadata
        if metadata:
            self._save_metadata(matrices, path, metadata)
    
    def _save_mtx(
        self,
        matrices: List,
        path: Path,
        metadata: Optional[Union[bool, List[Dict]]]
    ):
        """Save matrices as Matrix Market files"""
        for i, matrix in enumerate(matrices):
            file_path = path / f"matrix_{i:04d}.mtx"
            
            if not sparse.issparse(matrix):
                matrix = sparse.csr_matrix(matrix)
            
            mmwrite(file_path, matrix)
        
        # Save metadata
        if metadata:
            self._save_metadata(matrices, path, metadata)
    
    def _save_metadata(
        self,
        matrices: List,
        path: Path,
        metadata: Union[bool, List[Dict]]
    ):
        """Save metadata for matrices"""
        metadata_list = []
        
        if isinstance(metadata, bool) and metadata:
            # Auto-generate metadata
            for i, matrix in enumerate(matrices):
                if sparse.issparse(matrix):
                    meta = {
                        'index': i,
                        'shape': matrix.shape,
                        'nnz': matrix.nnz,
                        'dtype': str(matrix.dtype),
                        'format': matrix.format,
                    }
                else:
                    meta = {
                        'index': i,
                        'shape': matrix.shape if hasattr(matrix, 'shape') else None,
                        'dtype': str(matrix.dtype) if hasattr(matrix, 'dtype') else None,
                    }
                metadata_list.append(meta)
        elif isinstance(metadata, list):
            metadata_list = metadata
        
        # Save to JSON
        metadata_path = path / "metadata.json"
        with open(metadata_path, 'w') as f:
            json.dump(metadata_list, f, indent=2)