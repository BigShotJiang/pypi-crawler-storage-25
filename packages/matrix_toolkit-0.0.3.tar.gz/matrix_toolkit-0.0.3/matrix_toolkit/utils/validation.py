"""Matrix validation utilities"""

from typing import Any, List, Optional
import numpy as np
from scipy import sparse
import hashlib


class MatrixValidator:
    """Validate matrix properties and integrity"""
    
    @staticmethod
    def validate_matrix(matrix: Any, checks: Optional[List[str]] = None) -> dict:
        """
        Validate a matrix with various checks
        
        Args:
            matrix: Matrix to validate
            checks: List of checks to perform. If None, perform all checks.
                   Options: 'structure', 'values', 'symmetry', 'positive_definite'
        
        Returns:
            Dictionary with validation results
        """
        if checks is None:
            checks = ['structure', 'values']
        
        results = {
            'valid': True,
            'checks': {},
            'warnings': [],
            'errors': []
        }
        
        # Structure check
        if 'structure' in checks:
            structure_result = MatrixValidator._check_structure(matrix)
            results['checks']['structure'] = structure_result
            if not structure_result['passed']:
                results['valid'] = False
                results['errors'].extend(structure_result.get('errors', []))
        
        # Values check
        if 'values' in checks:
            values_result = MatrixValidator._check_values(matrix)
            results['checks']['values'] = values_result
            if not values_result['passed']:
                results['warnings'].extend(values_result.get('warnings', []))
        
        # Symmetry check
        if 'symmetry' in checks:
            symmetry_result = MatrixValidator._check_symmetry(matrix)
            results['checks']['symmetry'] = symmetry_result
        
        # Positive definite check
        if 'positive_definite' in checks:
            pd_result = MatrixValidator._check_positive_definite(matrix)
            results['checks']['positive_definite'] = pd_result
        
        return results
    
    @staticmethod
    def _check_structure(matrix: Any) -> dict:
        """Check matrix structure validity"""
        result = {'passed': True, 'errors': []}
        
        # Check if matrix has shape
        if not hasattr(matrix, 'shape'):
            result['passed'] = False
            result['errors'].append("Matrix has no shape attribute")
            return result
        
        # Check for valid dimensions
        if len(matrix.shape) != 2:
            result['passed'] = False
            result['errors'].append(f"Matrix must be 2D, got shape {matrix.shape}")
        
        # Check for zero dimensions
        if any(dim == 0 for dim in matrix.shape):
            result['passed'] = False
            result['errors'].append(f"Matrix has zero dimension: {matrix.shape}")
        
        # For sparse matrices, check for duplicates
        if sparse.issparse(matrix):
            if hasattr(matrix, 'has_sorted_indices'):
                if not matrix.has_sorted_indices:
                    result['warnings'] = ["Matrix indices are not sorted"]
            
            # Check for canonical format
            if hasattr(matrix, 'has_canonical_format'):
                if not matrix.has_canonical_format:
                    result['warnings'] = result.get('warnings', [])
                    result['warnings'].append("Matrix is not in canonical format")
        
        return result
    
    @staticmethod
    def _check_values(matrix: Any) -> dict:
        """Check for problematic values (NaN, Inf)"""
        result = {'passed': True, 'warnings': []}
        
        try:
            if sparse.issparse(matrix):
                data = matrix.data
            else:
                data = matrix.flatten() if hasattr(matrix, 'flatten') else np.array(matrix).flatten()
            
            # Check for NaN
            if np.any(np.isnan(data)):
                result['passed'] = False
                result['warnings'].append("Matrix contains NaN values")
            
            # Check for Inf
            if np.any(np.isinf(data)):
                result['passed'] = False
                result['warnings'].append("Matrix contains Inf values")
            
            # Check for very large values
            if np.any(np.abs(data) > 1e10):
                result['warnings'].append("Matrix contains very large values (>1e10)")
            
        except Exception as e:
            result['passed'] = False
            result['warnings'].append(f"Error checking values: {str(e)}")
        
        return result
    
    @staticmethod
    def _check_symmetry(matrix: Any) -> dict:
        """Check if matrix is symmetric"""
        result = {'is_symmetric': False}
        
        if not hasattr(matrix, 'shape') or matrix.shape[0] != matrix.shape[1]:
            result['reason'] = "Matrix is not square"
            return result
        
        try:
            if sparse.issparse(matrix):
                # For sparse matrices, check more efficiently
                diff = matrix - matrix.T
                is_symmetric = diff.nnz == 0 or np.allclose(diff.data, 0)
            else:
                is_symmetric = np.allclose(matrix, matrix.T)
            
            result['is_symmetric'] = is_symmetric
            
        except Exception as e:
            result['error'] = str(e)
        
        return result
    
    @staticmethod
    def _check_positive_definite(matrix: Any) -> dict:
        """Check if matrix is positive definite"""
        result = {'is_positive_definite': False}
        
        if not hasattr(matrix, 'shape') or matrix.shape[0] != matrix.shape[1]:
            result['reason'] = "Matrix is not square"
            return result
        
        # Only check small matrices (expensive operation)
        if matrix.shape[0] > 1000:
            result['reason'] = "Matrix too large for positive definite check"
            return result
        
        try:
            if sparse.issparse(matrix):
                matrix_dense = matrix.toarray()
            else:
                matrix_dense = matrix
            
            # Try Cholesky decomposition
            np.linalg.cholesky(matrix_dense)
            result['is_positive_definite'] = True
            
        except np.linalg.LinAlgError:
            result['is_positive_definite'] = False
        except Exception as e:
            result['error'] = str(e)
        
        return result
    
    @staticmethod
    def compute_checksum(matrix: Any) -> str:
        """Compute checksum for matrix integrity verification"""
        if sparse.issparse(matrix):
            # For sparse matrix, hash the data, indices, and shape
            data_bytes = matrix.data.tobytes()
            if hasattr(matrix, 'indices'):
                indices_bytes = matrix.indices.tobytes()
            else:
                # COO format
                indices_bytes = matrix.row.tobytes() + matrix.col.tobytes()
            
            shape_bytes = str(matrix.shape).encode()
            all_bytes = data_bytes + indices_bytes + shape_bytes
        else:
            # For dense matrix
            all_bytes = np.asarray(matrix).tobytes()
        
        return hashlib.sha256(all_bytes).hexdigest()
    
    @staticmethod
    def verify_checksum(matrix: Any, expected_checksum: str) -> bool:
        """Verify matrix checksum"""
        actual_checksum = MatrixValidator.compute_checksum(matrix)
        return actual_checksum == expected_checksum