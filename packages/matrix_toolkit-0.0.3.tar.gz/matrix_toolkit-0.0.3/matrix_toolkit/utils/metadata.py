"""Metadata extraction and management"""

from typing import Dict, Any, Optional
import numpy as np
from scipy import sparse


class MetadataExtractor:
    """Extract metadata from matrices"""
    
    @staticmethod
    def extract(matrix: Any, matrix_name: Optional[str] = None) -> Dict[str, Any]:
        """
        Extract comprehensive metadata from a matrix
        
        Args:
            matrix: Sparse or dense matrix
            matrix_name: Optional name for the matrix
        
        Returns:
            Dictionary of metadata
        """
        metadata = {}
        
        if matrix_name:
            metadata['name'] = matrix_name
        
        # Basic properties
        if hasattr(matrix, 'shape'):
            metadata['shape'] = matrix.shape
            metadata['rows'] = matrix.shape[0]
            metadata['cols'] = matrix.shape[1]
        
        # Sparse matrix properties
        if sparse.issparse(matrix):
            metadata['is_sparse'] = True
            metadata['format'] = matrix.format
            metadata['nnz'] = matrix.nnz
            metadata['density'] = matrix.nnz / (matrix.shape[0] * matrix.shape[1])
            metadata['sparsity'] = 1.0 - metadata['density']
            
            # Data type
            metadata['dtype'] = str(matrix.dtype)
            
            # Structure properties
            metadata['is_square'] = matrix.shape[0] == matrix.shape[1]
            
            # Try to determine symmetry (expensive for large matrices)
            if matrix.shape[0] == matrix.shape[1] and matrix.nnz < 1000000:
                try:
                    is_symmetric = np.allclose(
                        matrix.toarray(),
                        matrix.T.toarray()
                    )
                    metadata['is_symmetric'] = is_symmetric
                except:
                    metadata['is_symmetric'] = None
            
            # Value statistics
            data = matrix.data if hasattr(matrix, 'data') else matrix.toarray().flatten()
            metadata['min_value'] = float(np.min(data))
            metadata['max_value'] = float(np.max(data))
            metadata['mean_value'] = float(np.mean(data))
            metadata['std_value'] = float(np.std(data))
            
            # Pattern analysis
            metadata['has_diagonal'] = MetadataExtractor._has_diagonal(matrix)
            metadata['bandwidth'] = MetadataExtractor._estimate_bandwidth(matrix)
            
        else:
            # Dense matrix
            metadata['is_sparse'] = False
            metadata['dtype'] = str(matrix.dtype) if hasattr(matrix, 'dtype') else None
            metadata['nnz'] = np.count_nonzero(matrix) if hasattr(matrix, '__len__') else None
            metadata['density'] = metadata['nnz'] / matrix.size if metadata['nnz'] else None
        
        return metadata
    
    @staticmethod
    def _has_diagonal(matrix: sparse.spmatrix) -> bool:
        """Check if matrix has non-zero diagonal elements"""
        if matrix.shape[0] != matrix.shape[1]:
            return False
        
        try:
            diag = matrix.diagonal()
            return np.any(diag != 0)
        except:
            return False
    
    @staticmethod
    def _estimate_bandwidth(matrix: sparse.spmatrix) -> Optional[int]:
        """Estimate matrix bandwidth"""
        if matrix.shape[0] != matrix.shape[1]:
            return None
        
        try:
            coo = sparse.coo_matrix(matrix)
            bandwidth = np.max(np.abs(coo.row - coo.col))
            return int(bandwidth)
        except:
            return None
    
    @staticmethod
    def compare_metadata(meta1: Dict[str, Any], meta2: Dict[str, Any]) -> Dict[str, Any]:
        """Compare two metadata dictionaries"""
        comparison = {}
        
        all_keys = set(meta1.keys()) | set(meta2.keys())
        
        for key in all_keys:
            val1 = meta1.get(key)
            val2 = meta2.get(key)
            
            if val1 == val2:
                comparison[key] = {'status': 'equal', 'value': val1}
            else:
                comparison[key] = {
                    'status': 'different',
                    'value1': val1,
                    'value2': val2
                }
        
        return comparison