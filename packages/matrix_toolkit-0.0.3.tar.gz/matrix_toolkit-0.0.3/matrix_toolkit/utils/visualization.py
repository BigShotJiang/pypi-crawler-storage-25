"""Visualization utilities for sparse matrices"""

from typing import Optional, Tuple, Any, List
import numpy as np
from scipy import sparse
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches


class MatrixVisualizer:
    """Visualize sparse matrices and their properties"""
    
    @staticmethod
    def plot_sparsity_pattern(
        matrix: Any,
        title: Optional[str] = None,
        figsize: Tuple[int, int] = (10, 10),
        markersize: float = 1,
        save_path: Optional[str] = None
    ):
        """
        Plot sparsity pattern of a matrix
        
        Args:
            matrix: Sparse matrix
            title: Plot title
            figsize: Figure size
            markersize: Size of markers for non-zero elements
            save_path: Path to save figure
        """
        if not sparse.issparse(matrix):
            matrix = sparse.csr_matrix(matrix)
        
        fig, ax = plt.subplots(figsize=figsize)
        
        # Convert to COO for plotting
        coo = sparse.coo_matrix(matrix)
        
        ax.plot(coo.col, coo.row, 'k.', markersize=markersize)
        ax.set_xlim(0, matrix.shape[1])
        ax.set_ylim(0, matrix.shape[0])
        ax.set_aspect('equal')
        ax.invert_yaxis()
        
        if title:
            ax.set_title(title)
        else:
            ax.set_title(f"Sparsity Pattern ({matrix.shape[0]}×{matrix.shape[1]}, nnz={matrix.nnz})")
        
        ax.set_xlabel('Column')
        ax.set_ylabel('Row')
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        
        plt.show()
    
    @staticmethod
    def plot_distribution(
        metadata_list: List[dict],
        features: List[str] = ['rows', 'sparsity', 'nnz'],
        figsize: Tuple[int, int] = (15, 5),
        save_path: Optional[str] = None
    ):
        """
        Plot distribution of matrix properties
        
        Args:
            metadata_list: List of metadata dictionaries
            features: List of features to plot
            figsize: Figure size
            save_path: Path to save figure
        """
        n_features = len(features)
        fig, axes = plt.subplots(1, n_features, figsize=figsize)
        
        if n_features == 1:
            axes = [axes]
        
        for ax, feature in zip(axes, features):
            values = [m.get(feature) for m in metadata_list if feature in m]
            
            if values:
                ax.hist(values, bins=30, edgecolor='black', alpha=0.7)
                ax.set_xlabel(feature)
                ax.set_ylabel('Count')
                ax.set_title(f'Distribution of {feature}')
                ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        
        plt.show()
    
    @staticmethod
    def plot_matrix_comparison(
        matrices: List[Any],
        labels: Optional[List[str]] = None,
        figsize: Tuple[int, int] = (15, 5),
        save_path: Optional[str] = None
    ):
        """
        Compare sparsity patterns of multiple matrices
        
        Args:
            matrices: List of matrices to compare
            labels: Labels for each matrix
            figsize: Figure size
            save_path: Path to save figure
        """
        n_matrices = len(matrices)
        fig, axes = plt.subplots(1, n_matrices, figsize=figsize)
        
        if n_matrices == 1:
            axes = [axes]
        
        for i, (ax, matrix) in enumerate(zip(axes, matrices)):
            if not sparse.issparse(matrix):
                matrix = sparse.csr_matrix(matrix)
            
            coo = sparse.coo_matrix(matrix)
            ax.plot(coo.col, coo.row, 'k.', markersize=0.5)
            ax.set_xlim(0, matrix.shape[1])
            ax.set_ylim(0, matrix.shape[0])
            ax.set_aspect('equal')
            ax.invert_yaxis()
            
            if labels and i < len(labels):
                ax.set_title(f"{labels[i]}\n{matrix.shape[0]}×{matrix.shape[1]}, nnz={matrix.nnz}")
            else:
                ax.set_title(f"Matrix {i+1}\n{matrix.shape[0]}×{matrix.shape[1]}, nnz={matrix.nnz}")
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        
        plt.show()
    
    @staticmethod
    def plot_statistics_summary(
        stats: dict,
        figsize: Tuple[int, int] = (12, 8),
        save_path: Optional[str] = None
    ):
        """
        Plot summary statistics
        
        Args:
            stats: Statistics dictionary from MatrixSearcher.statistics()
            figsize: Figure size
            save_path: Path to save figure
        """
        fig = plt.figure(figsize=figsize)
        
        # Create grid
        gs = fig.add_gridspec(2, 2, hspace=0.3, wspace=0.3)
        
        # Plot 1: Basic statistics
        ax1 = fig.add_subplot(gs[0, 0])
        metrics = ['avg_rows', 'avg_cols', 'avg_nnz']
        values = [stats.get(m, 0) for m in metrics]
        ax1.bar(range(len(metrics)), values)
        ax1.set_xticks(range(len(metrics)))
        ax1.set_xticklabels(['Avg Rows', 'Avg Cols', 'Avg NNZ'])
        ax1.set_title('Average Matrix Properties')
        ax1.grid(True, alpha=0.3, axis='y')
        
        # Plot 2: Sparsity
        if 'avg_sparsity' in stats:
            ax2 = fig.add_subplot(gs[0, 1])
            sparsity = stats['avg_sparsity']
            density = 1 - sparsity
            ax2.pie([sparsity, density], labels=['Sparse', 'Dense'], 
                   autopct='%1.1f%%', startangle=90)
            ax2.set_title('Average Sparsity')
        
        # Plot 3: Domain distribution
        if 'domains' in stats:
            ax3 = fig.add_subplot(gs[1, :])
            domains = stats['domains']
            ax3.bar(domains.keys(), domains.values())
            ax3.set_xlabel('Domain')
            ax3.set_ylabel('Count')
            ax3.set_title('Matrix Distribution by Domain')
            ax3.tick_params(axis='x', rotation=45)
            ax3.grid(True, alpha=0.3, axis='y')
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        
        plt.show()
    
    @staticmethod
    def plot_bandwidth(
        matrix: Any,
        figsize: Tuple[int, int] = (10, 10),
        save_path: Optional[str] = None
    ):
        """
        Visualize matrix bandwidth
        
        Args:
            matrix: Sparse matrix
            figsize: Figure size
            save_path: Path to save figure
        """
        if not sparse.issparse(matrix):
            matrix = sparse.csr_matrix(matrix)
        
        if matrix.shape[0] != matrix.shape[1]:
            print("Bandwidth visualization only available for square matrices")
            return
        
        fig, ax = plt.subplots(figsize=figsize)
        
        coo = sparse.coo_matrix(matrix)
        
        # Calculate bandwidth for each non-zero
        bandwidths = np.abs(coo.row - coo.col)
        max_bandwidth = bandwidths.max()
        
        # Color by distance from diagonal
        scatter = ax.scatter(coo.col, coo.row, c=bandwidths, 
                           cmap='viridis', s=1, alpha=0.6)
        
        # Add diagonal lines showing bandwidth
        ax.plot([0, matrix.shape[1]], [0, matrix.shape[0]], 'r--', alpha=0.3, label='Main diagonal')
        
        ax.set_xlim(0, matrix.shape[1])
        ax.set_ylim(0, matrix.shape[0])
        ax.set_aspect('equal')
        ax.invert_yaxis()
        
        ax.set_title(f'Matrix Bandwidth Visualization\nMax bandwidth: {max_bandwidth}')
        ax.set_xlabel('Column')
        ax.set_ylabel('Row')
        
        plt.colorbar(scatter, ax=ax, label='Distance from diagonal')
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        
        plt.show()