"""
Unified interface combining SuiteSparse fetcher and Anymatrix generators

This module provides a single interface to access both downloaded matrices
from SuiteSparse and programmatically generated test matrices from Anymatrix.
"""

from typing import Any, Dict, List, Optional, Union
import warnings
from matrix_toolkit.core.fetcher import MatrixFetcher
from matrix_toolkit.anymatrix import AnyMatrix, MatrixProperties


class UnifiedMatrixCollection:
    """
    Unified access to both SuiteSparse and Anymatrix collections
    
    Examples:
        >>> from matrix_toolkit import UnifiedMatrixCollection
        >>> mc = UnifiedMatrixCollection()
        
        # Get from SuiteSparse
        >>> A = mc.get('suitesparse/HB/494_bus', backend='scipy')
        
        # Get from Anymatrix
        >>> B = mc.get('anymatrix/core/beta', 10)
        
        # Search both collections
        >>> results = mc.search(properties=['symmetric', 'positive definite'])
    """
    
    def __init__(self):
        """Initialize unified collection"""
        self.fetcher = MatrixFetcher()
        self.anymatrix = AnyMatrix()
    
    def get(
        self, 
        matrix_id: str, 
        *args, 
        backend: str = 'scipy',
        format: str = 'csr',
        **kwargs
    ) -> Any:
        """
        Get a matrix from either collection
        
        Args:
            matrix_id: Matrix identifier in format:
                      'suitesparse/group/name' or 'anymatrix/group/name'
            *args: Arguments for anymatrix generation
            backend: Backend for SuiteSparse matrices
            format: Format for SuiteSparse matrices
            **kwargs: Additional arguments
        
        Returns:
            Matrix in requested format
        
        Examples:
            >>> mc = UnifiedMatrixCollection()
            >>> # From Anymatrix
            >>> A = mc.get('anymatrix/core/beta', 10)
            >>> # From SuiteSparse
            >>> B = mc.get('suitesparse/HB/494_bus')
        """
        parts = matrix_id.split('/')
        
        if len(parts) < 2:
            raise ValueError(
                "matrix_id must be in format 'source/group/name' "
                "where source is 'suitesparse' or 'anymatrix'"
            )
        
        source = parts[0].lower()
        
        if source == 'anymatrix':
            # Generate from anymatrix
            am_id = '/'.join(parts[1:])
            return self.anymatrix.generate(am_id, *args, **kwargs)
        
        elif source == 'suitesparse':
            # Fetch from SuiteSparse
            ss_id = '/'.join(parts[1:])
            return self.fetcher.get_matrix(
                ss_id, 
                backend=backend, 
                format=format,
                **kwargs
            )
        
        else:
            raise ValueError(
                f"Unknown source: {source}. "
                "Must be 'anymatrix' or 'suitesparse'"
            )
    
    def list(
        self, 
        source: Optional[str] = None,
        group: Optional[str] = None
    ) -> Union[Dict, List]:
        """
        List available matrices
        
        Args:
            source: 'anymatrix', 'suitesparse', or None for both
            group: Specific group to list
        
        Returns:
            List or dict of available matrices
        """
        if source is None:
            return {
                'anymatrix': self.anymatrix.list(group),
                'suitesparse': self._list_suitesparse(group)
            }
        
        elif source == 'anymatrix':
            return self.anymatrix.list(group)
        
        elif source == 'suitesparse':
            return self._list_suitesparse(group)
        
        else:
            raise ValueError(f"Unknown source: {source}")
    
    def _list_suitesparse(self, group: Optional[str] = None):
        """List SuiteSparse matrices"""
        results = self.fetcher.search()
        
        if group:
            # Filter by group
            results = results[results['group'] == group]
        
        return results['name'].tolist() if len(results) > 0 else []
    
    def search(
        self,
        properties: Optional[List[str]] = None,
        source: Optional[str] = None,
        **filters
    ) -> Dict[str, List[str]]:
        """
        Search for matrices across collections
        
        Args:
            properties: List of required properties
            source: 'anymatrix', 'suitesparse', or None for both
            **filters: Additional search filters
        
        Returns:
            Dictionary of source -> list of matrix IDs
        """
        results = {}
        
        if source is None or source == 'anymatrix':
            # Search anymatrix
            if properties:
                am_results = self.anymatrix.search(properties)
                results['anymatrix'] = am_results
            else:
                results['anymatrix'] = []
        
        if source is None or source == 'suitesparse':
            # Search SuiteSparse
            ss_results = self.fetcher.search(**filters)
            if len(ss_results) > 0:
                results['suitesparse'] = ss_results['name'].tolist()
            else:
                results['suitesparse'] = []
        
        return results
    
    def properties(self, matrix_id: str) -> List[str]:
        """
        Get properties of a matrix
        
        Args:
            matrix_id: Matrix identifier
        
        Returns:
            List of properties
        """
        parts = matrix_id.split('/')
        source = parts[0].lower()
        
        if source == 'anymatrix':
            am_id = '/'.join(parts[1:])
            return self.anymatrix.properties(am_id)
        
        elif source == 'suitesparse':
            ss_id = '/'.join(parts[1:])
            metadata = self.fetcher.get_metadata(ss_id)
            
            if metadata:
                # Infer properties from metadata
                props = []
                if metadata.get('symmetry') == 'symmetric':
                    props.append('symmetric')
                if metadata.get('positive_definite'):
                    props.append('positive definite')
                return props
            
            return []
        
        else:
            raise ValueError(f"Unknown source: {source}")
    
    def verify_properties(
        self,
        matrix_id: str,
        *args,
        tol: float = 1e-10,
        verbose: bool = True,
        **kwargs
    ) -> Dict[str, bool]:
        """
        Generate matrix and verify its properties
        
        Args:
            matrix_id: Matrix identifier
            *args: Generation arguments
            tol: Tolerance for checks
            verbose: Print results
            **kwargs: Additional arguments
        
        Returns:
            Dictionary of property -> verification result
        """
        # Get the matrix
        matrix = self.get(matrix_id, *args, **kwargs)
        
        # Get expected properties
        expected_props = self.properties(matrix_id)
        
        if not expected_props:
            warnings.warn(f"No properties defined for {matrix_id}")
            return {}
        
        # Check properties
        from matrix_toolkit.anymatrix.testing.property_checker import check_matrix_properties
        
        return check_matrix_properties(
            matrix,
            matrix_id,
            expected_props,
            tol=tol,
            verbose=verbose
        )
    
    def __repr__(self) -> str:
        am_groups = len(self.anymatrix.groups())
        am_matrices = len(self.anymatrix._matrix_registry)
        
        return (
            f"UnifiedMatrixCollection(\n"
            f"  anymatrix: {am_groups} groups, {am_matrices} matrices\n"
            f"  suitesparse: available via fetcher\n"
            f")"
        )