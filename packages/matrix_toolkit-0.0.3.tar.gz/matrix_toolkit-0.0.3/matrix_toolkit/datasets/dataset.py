"""Matrix dataset management"""

import json
import yaml
from pathlib import Path
from typing import List, Dict, Any, Optional, Union
import numpy as np
from datetime import datetime


class MatrixDataset:
    """Manage a collection of matrices as a dataset"""
    
    def __init__(
        self,
        name: str,
        matrix_names: List[str],
        metadata: Optional[List[Dict]] = None,
        split: Optional[Dict[str, float]] = None,
        description: str = "",
        **kwargs
    ):
        """
        Initialize a matrix dataset
        
        Args:
            name: Dataset name
            matrix_names: List of matrix names in the dataset
            metadata: List of metadata dictionaries for each matrix
            split: Dictionary of split ratios, e.g., {'train': 0.7, 'val': 0.15, 'test': 0.15}
            description: Dataset description
            **kwargs: Additional attributes
        """
        self.name = name
        self.matrix_names = matrix_names
        self.metadata = metadata or []
        self.description = description
        self.created_at = datetime.now().isoformat()
        self.split_ratios = split
        self.splits = {}
        
        # Store additional attributes
        for key, value in kwargs.items():
            setattr(self, key, value)
        
        # Create splits if specified
        if split:
            self._create_splits(split)
    
    def _create_splits(self, split: Dict[str, float]):
        """Create train/val/test splits"""
        if not np.isclose(sum(split.values()), 1.0):
            raise ValueError(f"Split ratios must sum to 1.0, got {sum(split.values())}")
        
        n_matrices = len(self.matrix_names)
        indices = np.random.permutation(n_matrices)
        
        current_idx = 0
        for split_name, ratio in split.items():
            split_size = int(n_matrices * ratio)
            
            # Handle rounding for last split
            if split_name == list(split.keys())[-1]:
                split_indices = indices[current_idx:]
            else:
                split_indices = indices[current_idx:current_idx + split_size]
            
            self.splits[split_name] = [
                self.matrix_names[i] for i in split_indices
            ]
            current_idx += split_size
    
    def get_split(self, split_name: str) -> List[str]:
        """Get matrix names for a specific split"""
        if split_name not in self.splits:
            raise ValueError(f"Split '{split_name}' not found. Available: {list(self.splits.keys())}")
        return self.splits[split_name]
    
    def save(self, path: Union[str, Path]):
        """Save dataset configuration"""
        path = Path(path)
        path.mkdir(parents=True, exist_ok=True)
        
        config = {
            'name': self.name,
            'description': self.description,
            'created_at': self.created_at,
            'matrix_names': self.matrix_names,
            'metadata': self.metadata,
            'split_ratios': self.split_ratios,
            'splits': self.splits,
        }
        
        # Save as YAML for readability
        config_path = path / f"{self.name}_config.yaml"
        with open(config_path, 'w') as f:
            yaml.dump(config, f, default_flow_style=False)
        
        # Also save as JSON for programmatic access
        json_path = path / f"{self.name}_config.json"
        with open(json_path, 'w') as f:
            json.dump(config, f, indent=2)
    
    @classmethod
    def load(cls, path: Union[str, Path]) -> "MatrixDataset":
        """Load dataset from saved configuration"""
        path = Path(path)
        
        # Try YAML first, then JSON
        yaml_files = list(path.glob("*_config.yaml"))
        json_files = list(path.glob("*_config.json"))
        
        if yaml_files:
            config_path = yaml_files[0]
            with open(config_path, 'r') as f:
                config = yaml.safe_load(f)
        elif json_files:
            config_path = json_files[0]
            with open(config_path, 'r') as f:
                config = json.load(f)
        else:
            raise FileNotFoundError(f"No config file found in {path}")
        
        # Create dataset
        dataset = cls(
            name=config['name'],
            matrix_names=config['matrix_names'],
            metadata=config.get('metadata'),
            split=config.get('split_ratios'),
            description=config.get('description', ''),
        )
        
        # Restore splits if they exist
        if 'splits' in config:
            dataset.splits = config['splits']
        
        dataset.created_at = config.get('created_at', datetime.now().isoformat())
        
        return dataset
    
    def save_config(self, config_path: Union[str, Path]):
        """Save just the configuration file"""
        config_path = Path(config_path)
        
        config = {
            'name': self.name,
            'description': self.description,
            'created_at': self.created_at,
            'matrix_names': self.matrix_names,
            'metadata': self.metadata,
            'split_ratios': self.split_ratios,
            'splits': self.splits,
        }
        
        if config_path.suffix == '.yaml' or config_path.suffix == '.yml':
            with open(config_path, 'w') as f:
                yaml.dump(config, f, default_flow_style=False)
        else:
            with open(config_path, 'w') as f:
                json.dump(config, f, indent=2)
    
    @classmethod
    def from_config(cls, config_path: Union[str, Path]) -> "MatrixDataset":
        """Create dataset from config file"""
        config_path = Path(config_path)
        
        if config_path.suffix in ['.yaml', '.yml']:
            with open(config_path, 'r') as f:
                config = yaml.safe_load(f)
        else:
            with open(config_path, 'r') as f:
                config = json.load(f)
        
        dataset = cls(
            name=config['name'],
            matrix_names=config['matrix_names'],
            metadata=config.get('metadata'),
            split=config.get('split_ratios'),
            description=config.get('description', ''),
        )
        
        if 'splits' in config:
            dataset.splits = config['splits']
        
        dataset.created_at = config.get('created_at', datetime.now().isoformat())
        
        return dataset
    
    def __len__(self) -> int:
        return len(self.matrix_names)
    
    def __repr__(self) -> str:
        return (
            f"MatrixDataset(name='{self.name}', "
            f"size={len(self.matrix_names)}, "
            f"splits={list(self.splits.keys())})"
        )