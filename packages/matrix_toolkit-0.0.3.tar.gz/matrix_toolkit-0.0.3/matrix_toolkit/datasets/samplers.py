"""
Sampling strategies for matrix datasets
"""

import random
import numpy as np
import pandas as pd
from typing import List, Optional
from abc import ABC, abstractmethod


class BaseSampler(ABC):
    """Base class for sampling strategies"""
    
    @abstractmethod
    def sample(self, data: pd.DataFrame, n: int, **kwargs) -> pd.DataFrame:
        """Sample n items from data"""
        pass


class RandomSampler(BaseSampler):
    """Random sampling without replacement"""
    
    def __init__(self, seed: Optional[int] = None):
        """
        Args:
            seed: Random seed for reproducibility
        """
        self.seed = seed
        if seed is not None:
            random.seed(seed)
            np.random.seed(seed)
    
    def sample(self, data: pd.DataFrame, n: int, **kwargs) -> pd.DataFrame:
        """Random sample n items"""
        return data.sample(n=min(n, len(data)), random_state=self.seed)


class StratifiedSampler(BaseSampler):
    """Stratified sampling by a categorical feature"""
    
    def __init__(self, stratify_by: str, seed: Optional[int] = None):
        """
        Args:
            stratify_by: Column name to stratify by (e.g., 'group', 'domain')
            seed: Random seed
        """
        self.stratify_by = stratify_by
        self.seed = seed
        if seed is not None:
            random.seed(seed)
            np.random.seed(seed)
    
    def sample(self, data: pd.DataFrame, n: int, **kwargs) -> pd.DataFrame:
        """Sample with stratification"""
        if self.stratify_by not in data.columns:
            raise ValueError(f"Column '{self.stratify_by}' not found in data")
        
        # Calculate samples per stratum
        n_strata = data[self.stratify_by].nunique()
        samples_per_stratum = max(1, n // n_strata)
        
        # Sample from each stratum - use lambda to preserve all columns
        sampled_parts = []
        for group_name, group_df in data.groupby(self.stratify_by):
            n_samples = min(len(group_df), samples_per_stratum)
            sampled_group = group_df.sample(n=n_samples, random_state=self.seed)
            sampled_parts.append(sampled_group)
        
        sampled = pd.concat(sampled_parts, ignore_index=True)
        
        # If we don't have enough samples, fill from random sampling
        if len(sampled) < n:
            remaining = n - len(sampled)
            unsampled = data[~data.index.isin(sampled.index)]
            if len(unsampled) > 0:
                additional = unsampled.sample(
                    n=min(remaining, len(unsampled)),
                    random_state=self.seed
                )
                sampled = pd.concat([sampled, additional], ignore_index=True)
        
        return sampled.head(n)


class DiversitySampler(BaseSampler):
    """Sample to maximize diversity across multiple features"""
    
    def __init__(
        self,
        diversity_features: List[str],
        method: str = 'kmeans',
        seed: Optional[int] = None
    ):
        """
        Args:
            diversity_features: List of features to maximize diversity on
            method: 'kmeans', 'maxmin', or 'greedy'
            seed: Random seed
        """
        self.diversity_features = diversity_features
        self.method = method
        self.seed = seed
        if seed is not None:
            random.seed(seed)
            np.random.seed(seed)
    
    def sample(self, data: pd.DataFrame, n: int, **kwargs) -> pd.DataFrame:
        """Sample to maximize diversity"""
        # Check if all features exist
        for feature in self.diversity_features:
            if feature not in data.columns:
                raise ValueError(f"Feature '{feature}' not found in data")
        
        if self.method == 'kmeans':
            return self._kmeans_sample(data, n)
        elif self.method == 'maxmin':
            return self._maxmin_sample(data, n)
        elif self.method == 'greedy':
            return self._greedy_sample(data, n)
        else:
            raise ValueError(f"Unknown method: {self.method}")
    
    def _kmeans_sample(self, data: pd.DataFrame, n: int) -> pd.DataFrame:
        """K-means clustering based sampling"""
        try:
            from sklearn.cluster import KMeans
            from sklearn.preprocessing import StandardScaler
        except ImportError:
            raise ImportError("scikit-learn required for kmeans sampling")
        
        # Extract and normalize features
        features = data[self.diversity_features].copy()
        
        # Handle non-numeric features
        for col in features.columns:
            if features[col].dtype == 'object':
                features[col] = pd.Categorical(features[col]).codes
        
        scaler = StandardScaler()
        features_scaled = scaler.fit_transform(features)
        
        # Cluster
        n_clusters = min(n, len(data))
        kmeans = KMeans(n_clusters=n_clusters, random_state=self.seed, n_init=10)
        clusters = kmeans.fit_predict(features_scaled)
        
        # Sample one from each cluster - preserve all columns
        data_with_clusters = data.copy()
        data_with_clusters['_cluster_temp'] = clusters
        
        sampled_parts = []
        for cluster_id in range(n_clusters):
            cluster_data = data_with_clusters[data_with_clusters['_cluster_temp'] == cluster_id]
            if len(cluster_data) > 0:
                sampled_parts.append(cluster_data.sample(n=1, random_state=self.seed))
        
        sampled = pd.concat(sampled_parts, ignore_index=True)
        
        # Remove temporary cluster column
        sampled = sampled.drop('_cluster_temp', axis=1)
        
        return sampled.head(n)
    
    def _maxmin_sample(self, data: pd.DataFrame, n: int) -> pd.DataFrame:
        """Max-min distance sampling"""
        from sklearn.preprocessing import StandardScaler
        from sklearn.metrics.pairwise import euclidean_distances
        
        # Extract and normalize features
        features = data[self.diversity_features].copy()
        
        # Handle non-numeric features
        for col in features.columns:
            if features[col].dtype == 'object':
                features[col] = pd.Categorical(features[col]).codes
        
        scaler = StandardScaler()
        features_scaled = scaler.fit_transform(features)
        
        # Start with random point
        if self.seed is not None:
            np.random.seed(self.seed)
        selected_indices = [np.random.randint(len(data))]
        
        # Iteratively add point farthest from selected points
        for _ in range(min(n - 1, len(data) - 1)):
            distances = euclidean_distances(
                features_scaled,
                features_scaled[selected_indices]
            )
            min_distances = distances.min(axis=1)
            
            # Exclude already selected
            min_distances[selected_indices] = -1
            
            # Add farthest point
            farthest = min_distances.argmax()
            selected_indices.append(farthest)
        
        return data.iloc[selected_indices].reset_index(drop=True)
    
    def _greedy_sample(self, data: pd.DataFrame, n: int) -> pd.DataFrame:
        """Greedy diversity sampling"""
        # Simple greedy: ensure coverage of each feature's range
        sampled_indices = []
        
        for feature in self.diversity_features:
            if data[feature].dtype in ['int64', 'float64']:
                # For numeric: sample from min, max, median
                sorted_data = data.sort_values(feature)
                percentiles = [0, 0.25, 0.5, 0.75, 1.0]
                for p in percentiles:
                    idx = int(p * (len(sorted_data) - 1))
                    if idx < len(sorted_data):
                        sampled_indices.append(sorted_data.index[idx])
        
        # Fill remaining with random
        sampled_indices = list(set(sampled_indices))
        remaining = n - len(sampled_indices)
        
        if remaining > 0:
            unsampled = data[~data.index.isin(sampled_indices)]
            if len(unsampled) > 0:
                additional = unsampled.sample(
                    n=min(remaining, len(unsampled)),
                    random_state=self.seed
                )
                sampled_indices.extend(additional.index.tolist())
        
        return data.loc[sampled_indices[:n]].reset_index(drop=True)


class SizeSampler(BaseSampler):
    """Sample by matrix size ranges"""
    
    def __init__(
        self,
        size_ranges: List[tuple],
        samples_per_range: int,
        seed: Optional[int] = None
    ):
        """
        Args:
            size_ranges: List of (min, max) tuples for matrix sizes
            samples_per_range: Number of samples per range
            seed: Random seed
        """
        self.size_ranges = size_ranges
        self.samples_per_range = samples_per_range
        self.seed = seed
    
    def sample(self, data: pd.DataFrame, n: int, **kwargs) -> pd.DataFrame:
        """Sample across size ranges"""
        sampled_parts = []
        
        for min_size, max_size in self.size_ranges:
            # Filter by size range
            mask = (data['rows'] >= min_size) & (data['rows'] <= max_size)
            range_data = data[mask]
            
            if len(range_data) > 0:
                n_samples = min(self.samples_per_range, len(range_data))
                sampled_parts.append(
                    range_data.sample(n=n_samples, random_state=self.seed)
                )
        
        if not sampled_parts:
            return pd.DataFrame()
        
        sampled = pd.concat(sampled_parts, ignore_index=True)
        return sampled.head(n)