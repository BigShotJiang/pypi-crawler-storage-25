"""
Extended core matrices - Complete implementation of all core group matrices
"""

import numpy as np
from scipy import sparse
from typing import Optional, Union, Tuple


def register_extended_core_matrices(registry):
    """Register all remaining core group matrices"""
    
    # Bidiagonal alternating
    registry.register_matrix(
        group='core',
        name='bidiag_alt',
        generator=bidiag_alt,
        properties=['bidiagonal'],
        description='Bidiagonal matrix with alternating signs'
    )
    
    # Biogeography matrix
    registry.register_matrix(
        group='core',
        name='biogeography',
        generator=biogeography,
        properties=['sparse', 'stochastic'],
        description='Biogeography matrix from island model'
    )
    
    # Block Householder
    registry.register_matrix(
        group='core',
        name='blockhouse',
        generator=blockhouse,
        properties=['orthogonal'],
        description='Block Householder matrix'
    )
    
    # Creation matrix
    registry.register_matrix(
        group='core',
        name='creation',
        generator=creation,
        properties=['upper triangular', 'nilpotent'],
        description='Creation operator matrix'
    )
    
    # Cross matrix
    registry.register_matrix(
        group='core',
        name='cross',
        generator=cross,
        properties=['sparse'],
        description='Cross-shaped sparse matrix'
    )
    
    # Dembo9
    registry.register_matrix(
        group='core',
        name='dembo9',
        generator=dembo9,
        properties=['symmetric'],
        description='Dembo 9x9 test matrix'
    )
    
    # Edelman27
    registry.register_matrix(
        group='core',
        name='edelman27',
        generator=edelman27,
        properties=[],
        description='Edelman 27-matrix for eigenvalue perturbation'
    )
    
    # GFPP (Growth Factor for Partial Pivoting)
    registry.register_matrix(
        group='core',
        name='gfpp',
        generator=gfpp,
        properties=[],
        description='Matrix with large growth factor for Gaussian elimination'
    )
    
    # Hessenberg orthogonal
    registry.register_matrix(
        group='core',
        name='hess_orth',
        generator=hess_orth,
        properties=['orthogonal', 'hessenberg'],
        description='Orthogonal Hessenberg matrix'
    )
    
    # Hessenberg with subdiagonal LU
    registry.register_matrix(
        group='core',
        name='hess_sublu',
        generator=hess_sublu,
        properties=['hessenberg'],
        description='Hessenberg with interesting LU factorization'
    )
    
    # Hessenberg full 0-1
    registry.register_matrix(
        group='core',
        name='hessfull01',
        generator=hessfull01,
        properties=['hessenberg', 'binary'],
        description='Full Hessenberg 0-1 matrix'
    )
    
    # Hessenberg with maximum determinant
    registry.register_matrix(
        group='core',
        name='hessmaxdet',
        generator=hessmaxdet,
        properties=['hessenberg'],
        description='Hessenberg matrix with maximal determinant'
    )
    
    # Indefinite matrix
    registry.register_matrix(
        group='core',
        name='indef',
        generator=indef,
        properties=['symmetric', 'indefinite'],
        description='Symmetric indefinite matrix'
    )
    
    # KMS nonsymmetric
    registry.register_matrix(
        group='core',
        name='kms_nonsymm',
        generator=kms_nonsymm,
        properties=['toeplitz'],
        description='Nonsymmetric KMS matrix'
    )
    
    # Milnes matrix
    registry.register_matrix(
        group='core',
        name='milnes',
        generator=milnes,
        properties=['upper triangular'],
        description='Milnes matrix from numerical quadrature'
    )
    
    # Orthogonal Cauchy matrix
    registry.register_matrix(
        group='core',
        name='orthog_cauchy',
        generator=orthog_cauchy,
        properties=['orthogonal'],
        description='Orthogonal matrix from Cauchy matrix'
    )
    
    # Pick matrix
    registry.register_matrix(
        group='core',
        name='pick',
        generator=pick,
        properties=['hermitian', 'positive definite'],
        description='Pick matrix (positive definite)'
    )
    
    # Random Schur decomposition
    registry.register_matrix(
        group='core',
        name='rschur',
        generator=rschur,
        properties=[],
        description='Random matrix with given Schur decomposition'
    )
    
    # Soules matrix
    registry.register_matrix(
        group='core',
        name='soules',
        generator=soules,
        properties=['symmetric'],
        description='Soules matrix with prescribed eigenvalues'
    )
    
    # Stochastic companion
    registry.register_matrix(
        group='core',
        name='stoch_compan',
        generator=stoch_compan,
        properties=['stochastic'],
        description='Stochastic companion matrix'
    )
    
    # Stochastic perfect shuffle
    registry.register_matrix(
        group='core',
        name='stoch_perfect',
        generator=stoch_perfect,
        properties=['stochastic', 'doubly stochastic'],
        description='Stochastic perfect shuffle matrix'
    )
    
    # Stochastic reverse triangular
    registry.register_matrix(
        group='core',
        name='stoch_revtri',
        generator=stoch_revtri,
        properties=['stochastic', 'upper triangular'],
        description='Stochastic reverse triangular matrix'
    )
    
    # Symmetric stochastic
    registry.register_matrix(
        group='core',
        name='symmstoch',
        generator=symmstoch,
        properties=['symmetric', 'doubly stochastic'],
        description='Symmetric doubly stochastic matrix'
    )
    
    # Totally nonnegative
    registry.register_matrix(
        group='core',
        name='totally_nonneg',
        generator=totally_nonneg,
        properties=['totally nonnegative'],
        description='Totally nonnegative matrix'
    )
    
    # Triangular with minimum singular value 0-1
    registry.register_matrix(
        group='core',
        name='triminsval01',
        generator=triminsval01,
        properties=['upper triangular'],
        description='Triangular with smallest singular value in (0,1)'
    )
    
    # Unitary with identity eigenvalues
    registry.register_matrix(
        group='core',
        name='unitary_eye',
        generator=unitary_eye,
        properties=['unitary'],
        description='Unitary matrix with eigenvalues on unit circle'
    )
    
    # Upper trapezoidal orthogonal
    registry.register_matrix(
        group='core',
        name='uptraporth',
        generator=uptraporth,
        properties=['orthogonal'],
        description='Orthogonal matrix that is upper trapezoidal'
    )
    
    # Vec-permutation matrix
    registry.register_matrix(
        group='core',
        name='vecperm',
        generator=vecperm,
        properties=['sparse', 'orthogonal'],
        description='Vec-permutation matrix'
    )
    
    # Zielke nonsymmetric
    registry.register_matrix(
        group='core',
        name='zielke_nonsymm',
        generator=zielke_nonsymm,
        properties=[],
        description='Zielke nonsymmetric matrix'
    )
    
    # Zielke symmetric
    registry.register_matrix(
        group='core',
        name='zielke_symm',
        generator=zielke_symm,
        properties=['symmetric'],
        description='Zielke symmetric matrix'
    )


# Matrix generators implementation

def bidiag_alt(n: int) -> np.ndarray:
    """Bidiagonal matrix with alternating signs on superdiagonal"""
    A = np.zeros((n, n))
    for i in range(n):
        A[i, i] = 1
        if i < n - 1:
            A[i, i + 1] = (-1) ** i
    return A


def biogeography(n: int, p: float = 0.5) -> sparse.spmatrix:
    """
    Biogeography matrix - stochastic matrix from island biogeography
    
    Args:
        n: Number of islands
        p: Migration probability
    """
    # Simple model: migration between adjacent islands
    diags = [
        np.ones(n) * (1 - 2*p),  # Stay
        np.ones(n-1) * p,         # Migrate right
        np.ones(n-1) * p          # Migrate left
    ]
    # Fix boundary conditions
    diags[0][0] = 1 - p
    diags[0][-1] = 1 - p
    
    A = sparse.diags(diags, [0, 1, -1], shape=(n, n), format='csr')
    return A


def blockhouse(n: int, k: int = 2) -> np.ndarray:
    """
    Block Householder matrix
    
    Args:
        n: Matrix size
        k: Block size
    """
    num_blocks = n // k
    Q = np.eye(n)
    
    for i in range(num_blocks):
        start = i * k
        end = start + k
        # Random Householder reflector for this block
        v = np.random.randn(k)
        v = v / np.linalg.norm(v)
        H = np.eye(k) - 2 * np.outer(v, v)
        Q[start:end, start:end] = H
    
    return Q


def creation(n: int) -> np.ndarray:
    """Creation operator matrix (quantum mechanics)"""
    A = np.zeros((n, n))
    for i in range(n - 1):
        A[i, i + 1] = np.sqrt(i + 1)
    return A


def cross(n: int) -> sparse.spmatrix:
    """Cross-shaped sparse matrix"""
    mid = n // 2
    row = []
    col = []
    data = []
    
    # Horizontal line
    for j in range(n):
        row.append(mid)
        col.append(j)
        data.append(1.0)
    
    # Vertical line
    for i in range(n):
        if i != mid:
            row.append(i)
            col.append(mid)
            data.append(1.0)
    
    return sparse.csr_matrix((data, (row, col)), shape=(n, n))


def dembo9() -> np.ndarray:
    """Dembo 9x9 test matrix"""
    # Fixed 9x9 matrix from Dembo
    A = np.array([
        [1, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 1, 0, 0, 0, 0, 0, 0, 0],
        [1, 1, 1, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 1, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 1, 0, 0, 0, 0],
        [0, 0, 0, 1, 1, 1, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 1, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 1, 0],
        [0, 0, 0, 0, 0, 0, 1, 1, 1]
    ], dtype=float)
    return A


def edelman27(mode: int = 1) -> np.ndarray:
    """
    Edelman 27-matrix for studying eigenvalue perturbation
    
    Args:
        mode: Different variants (1-3)
    """
    if mode == 1:
        # Original version
        A = np.zeros((27, 27))
        for i in range(27):
            A[i, i] = i + 1
            if i < 26:
                A[i, i + 1] = 1
        return A
    elif mode == 2:
        # Variant with different structure
        A = np.random.randn(27, 27)
        A = (A + A.T) / 2
        return A
    else:
        # Simple tridiagonal
        return np.diag(np.arange(1, 28)) + np.diag(np.ones(26), 1)


def gfpp(n: int, c: float = 2.0) -> np.ndarray:
    """
    Matrix with large growth factor for Gaussian elimination with partial pivoting
    
    Args:
        n: Matrix size
        c: Growth parameter
    """
    A = np.eye(n)
    for i in range(n):
        for j in range(i + 1, n):
            A[i, j] = -1
        if i < n - 1:
            A[i + 1, i] = 1
    A[-1, :] = 1
    return A


def hess_orth(n: int) -> np.ndarray:
    """Orthogonal Hessenberg matrix"""
    # Start with random Hessenberg
    H = np.triu(np.random.randn(n, n), -1)
    
    # Orthogonalize columns (QR factorization)
    Q, R = np.linalg.qr(H)
    
    # Make it Hessenberg again
    H = np.triu(Q, -1)
    # Orthogonalize rows
    Q2, R2 = np.linalg.qr(H.T)
    H = Q2.T
    
    return np.triu(H, -1)


def hess_sublu(n: int) -> np.ndarray:
    """Hessenberg matrix with interesting LU factorization properties"""
    H = np.zeros((n, n))
    for i in range(n):
        for j in range(max(0, i-1), n):
            H[i, j] = 1.0 / (i + j + 1)
    return H


def hessfull01(n: int) -> np.ndarray:
    """Full Hessenberg 0-1 matrix"""
    H = np.triu(np.ones((n, n)), -1)
    # Make binary
    H = (H > 0).astype(float)
    return H


def hessmaxdet(n: int) -> np.ndarray:
    """
    Hessenberg matrix designed to have large determinant
    """
    H = np.zeros((n, n))
    for i in range(n):
        H[i, i] = 2
        if i < n - 1:
            H[i, i + 1] = 1
            H[i + 1, i] = 1
    return H


def indef(n: int, k: Optional[int] = None) -> np.ndarray:
    """
    Symmetric indefinite matrix
    
    Args:
        n: Matrix size
        k: Number of negative eigenvalues (default: n//2)
    """
    if k is None:
        k = n // 2
    
    # Create eigenvalues: k negative, rest positive
    eigenvalues = np.concatenate([
        -np.arange(1, k + 1),
        np.arange(1, n - k + 1)
    ])
    
    # Random orthogonal matrix
    Q, _ = np.linalg.qr(np.random.randn(n, n))
    
    # A = Q * diag(eigenvalues) * Q^T
    A = Q @ np.diag(eigenvalues) @ Q.T
    
    return A


def kms_nonsymm(n: int, rho: float = 0.5) -> np.ndarray:
    """Nonsymmetric KMS-like Toeplitz matrix"""
    i, j = np.meshgrid(range(n), range(n), indexing='ij')
    A = rho ** (j - i)
    return A


def milnes(n: int) -> np.ndarray:
    """Milnes matrix from numerical quadrature"""
    A = np.zeros((n, n))
    for i in range(n):
        for j in range(i, n):
            A[i, j] = 1.0 / (i + j + 1)
    return A


def orthog_cauchy(n: int = 5, x: Optional[np.ndarray] = None, 
                  y: Optional[np.ndarray] = None) -> np.ndarray:
    """
    Orthogonal matrix from Cauchy matrix
    
    Args:
        n: Matrix size (default: 5)
        x: Points for rows (default: equispaced in [0, 1])
        y: Points for columns (default: equispaced in [1.1, 2.1])
    
    Returns:
        n×n orthogonal matrix
    """
    if x is None:
        x = np.linspace(0, 1, n)
    else:
        x = np.asarray(x)
        n = len(x)
    
    if y is None:
        # Make sure x and y don't overlap
        y = np.linspace(1.1, 2.1, n)
    else:
        y = np.asarray(y)
    
    # Cauchy matrix - ensure x and y are disjoint
    denom = x[:, np.newaxis] - y[np.newaxis, :]
    
    # Avoid division by zero
    if np.any(np.abs(denom) < 1e-10):
        raise ValueError("x and y values must be disjoint (no overlaps)")
    
    C = 1.0 / denom
    
    # Orthogonalize via QR
    Q, R = np.linalg.qr(C)
    
    return Q


def pick(n: int, alpha: float = 1.0) -> np.ndarray:
    """
    Pick matrix - Hermitian positive definite
    
    Args:
        n: Matrix size
        alpha: Parameter controlling definiteness
    """
    # Create a positive definite matrix
    A = np.zeros((n, n), dtype=complex)
    for i in range(n):
        for j in range(n):
            A[i, j] = alpha / (i + j + alpha)
    
    # Make Hermitian
    A = (A + A.conj().T) / 2
    
    # Ensure positive definite
    A = A + np.eye(n) * n * alpha
    
    return A


def rschur(eigenvalues: Optional[np.ndarray] = None, n: int = 5) -> np.ndarray:
    """
    Random matrix with given eigenvalues via Schur decomposition
    
    Args:
        eigenvalues: Desired eigenvalues (default: 1, 2, ..., n)
        n: Matrix size
    """
    if eigenvalues is None:
        eigenvalues = np.arange(1, n + 1)
    else:
        n = len(eigenvalues)
    
    # Random orthogonal matrix
    Q, _ = np.linalg.qr(np.random.randn(n, n))
    
    # Upper triangular with eigenvalues on diagonal
    T = np.triu(np.random.randn(n, n))
    np.fill_diagonal(T, eigenvalues)
    
    # A = Q * T * Q^T
    A = Q @ T @ Q.T
    
    return A


def soules(eigenvalues: Optional[np.ndarray] = None) -> np.ndarray:
    """
    Soules matrix - symmetric with prescribed eigenvalues
    
    Args:
        eigenvalues: Desired eigenvalues (default: 1, 2, 3, 4, 5)
    """
    if eigenvalues is None:
        eigenvalues = np.array([1, 2, 3, 4, 5])
    
    n = len(eigenvalues)
    
    # Random orthogonal matrix
    Q, _ = np.linalg.qr(np.random.randn(n, n))
    
    # A = Q * diag(eigenvalues) * Q^T
    A = Q @ np.diag(eigenvalues) @ Q.T
    
    return A


def stoch_compan(n: int = 5, p: Optional[np.ndarray] = None) -> np.ndarray:
    """
    Stochastic companion matrix
    
    Args:
        n: Size (default: 5)
        p: Probability vector (default: uniform distribution)
    
    Returns:
        n×n stochastic companion matrix
    """
    if p is None:
        p = np.ones(n) / n
    else:
        p = np.asarray(p)
        n = len(p)
        p = p / p.sum()  # Normalize
    
    C = np.zeros((n, n))
    C[:-1, 1:] = np.eye(n-1)
    C[-1, :] = p
    
    return C


def stoch_perfect(n: int) -> np.ndarray:
    """Stochastic perfect shuffle matrix (doubly stochastic)"""
    if n % 2 != 0:
        raise ValueError("n must be even")
    
    P = np.zeros((n, n))
    m = n // 2
    
    # First half goes to even positions
    for i in range(m):
        P[i, 2*i] = 1
    
    # Second half goes to odd positions
    for i in range(m):
        P[m + i, 2*i + 1] = 1
    
    # Make doubly stochastic by averaging with transpose
    P = (P + P.T) / 2
    
    return P


def stoch_revtri(n: int) -> np.ndarray:
    """Stochastic upper triangular matrix"""
    A = np.triu(np.random.rand(n, n))
    # Normalize rows
    row_sums = A.sum(axis=1, keepdims=True)
    row_sums[row_sums == 0] = 1
    A = A / row_sums
    return A


def symmstoch(n: int, seed: Optional[int] = None) -> np.ndarray:
    """Symmetric doubly stochastic matrix"""
    if seed is not None:
        np.random.seed(seed)
    
    # Start with random symmetric matrix
    A = np.random.rand(n, n)
    A = (A + A.T) / 2
    
    # Sinkhorn iteration to make doubly stochastic
    for _ in range(100):
        # Normalize rows
        A = A / A.sum(axis=1, keepdims=True)
        # Normalize columns
        A = A / A.sum(axis=0, keepdims=True)
    
    return A


def totally_nonneg(n: int, mode: int = 1) -> np.ndarray:
    """
    Totally nonnegative matrix (all minors nonnegative)
    
    Args:
        n: Matrix size
        mode: Different constructions
    """
    if mode == 1:
        # Vandermonde with positive nodes
        x = np.linspace(1, 2, n)
        A = np.vander(x, n, increasing=True)
    elif mode == 2:
        # Cauchy matrix with positive entries
        x = np.arange(1, n + 1)
        y = np.arange(n + 1, 2*n + 1)
        A = 1.0 / (x[:, np.newaxis] + y[np.newaxis, :])
    else:
        # Pascal matrix
        A = np.zeros((n, n))
        for i in range(n):
            for j in range(n):
                from scipy.special import comb
                A[i, j] = comb(i + j, i, exact=True)
    
    return A


def triminsval01(n: int) -> np.ndarray:
    """Upper triangular with smallest singular value in (0, 1)"""
    # Construct carefully to have sigma_min in (0,1)
    A = np.triu(np.ones((n, n)))
    # Scale to ensure sigma_min < 1
    A = A / (n * 1.1)
    # Add identity to ensure sigma_min > 0
    A = A + 0.1 * np.eye(n)
    return A


def unitary_eye(n: int, k: int = 1) -> np.ndarray:
    """
    Unitary matrix with some eigenvalues equal to 1
    
    Args:
        n: Matrix size
        k: Number of eigenvalues equal to 1
    """
    # Eigenvalues: k ones, rest on unit circle
    angles = np.linspace(0, 2*np.pi, n - k, endpoint=False)
    eigenvalues = np.concatenate([
        np.ones(k),
        np.exp(1j * angles)
    ])
    
    # Random unitary matrix
    Q, _ = np.linalg.qr(np.random.randn(n, n) + 1j*np.random.randn(n, n))
    
    # U = Q * diag(eigenvalues) * Q^H
    U = Q @ np.diag(eigenvalues) @ Q.conj().T
    
    return U


def uptraporth(m: int, n: int) -> np.ndarray:
    """
    Orthogonal matrix that is upper trapezoidal
    
    Args:
        m: Number of rows
        n: Number of columns (n >= m)
    """
    if n < m:
        raise ValueError("n must be >= m")
    
    # Random matrix
    A = np.random.randn(m, n)
    
    # QR factorization gives orthogonal rows
    Q, R = np.linalg.qr(A.T)
    
    return Q.T[:m, :]


def vecperm(m: int, n: int) -> sparse.spmatrix:
    """
    Vec-permutation matrix for reshaping vec(A) from m×n to n×m
    
    Args:
        m: First dimension
        n: Second dimension
    """
    N = m * n
    row = []
    col = []
    
    for i in range(m):
        for j in range(n):
            # Map (i,j) in m×n to position in vector
            old_pos = i * n + j
            # Map to (j,i) in n×m
            new_pos = j * m + i
            row.append(new_pos)
            col.append(old_pos)
    
    data = np.ones(N)
    return sparse.csr_matrix((data, (row, col)), shape=(N, N))


def zielke_nonsymm(n: int) -> np.ndarray:
    """Zielke nonsymmetric test matrix"""
    A = np.zeros((n, n))
    for i in range(n):
        for j in range(n):
            A[i, j] = max(i, j) + 1
    return A


def zielke_symm(n: int) -> np.ndarray:
    """Zielke symmetric test matrix"""
    A = np.zeros((n, n))
    for i in range(n):
        for j in range(n):
            A[i, j] = min(i, j) + 1
    return A