"""
Anymatrix integration - A collection of test matrices inspired by the 
MATLAB anymatrix toolbox by Higham and Mikaitis.

This module provides programmatic generation of various test matrices
with well-defined properties for numerical computing research.
"""

from matrix_toolkit.anymatrix.registry import AnyMatrix
from matrix_toolkit.anymatrix.properties import MatrixProperties

__all__ = ["AnyMatrix", "MatrixProperties"]

# Version info
__version__ = "0.1.0"
__anymatrix_reference__ = """
Nicholas J. Higham and Mantas Mikaitis. 
Anymatrix: An Extendable MATLAB Matrix Collection. 
Numer. Algorithms, 90:3, 1175-1196, Dec. 2021.
DOI: 10.1007/s11075-021-01226-2
"""