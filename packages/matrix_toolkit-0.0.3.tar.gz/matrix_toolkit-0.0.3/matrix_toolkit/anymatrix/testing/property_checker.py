"""
Property checking for anymatrix matrices

Similar to anymatrix_check_props.m from the MATLAB version.
"""

from typing import Dict, List, Any
from matrix_toolkit.anymatrix.properties import MatrixProperties


def check_matrix_properties(
    matrix: Any,
    matrix_id: str,
    expected_properties: List[str],
    tol: float = 1e-10,
    verbose: bool = True
) -> Dict[str, bool]:
    """
    Check if a matrix has its expected properties
    
    This is analogous to anymatrix_check_props.m from the MATLAB version.
    
    Args:
        matrix: Matrix to check
        matrix_id: Matrix identifier (e.g., 'core/beta')
        expected_properties: List of expected property names
        tol: Tolerance for checks
        verbose: Whether to print results
    
    Returns:
        Dictionary of property_name -> bool (True if property holds)
    """
    results = {}
    all_passed = True
    
    if verbose:
        print(f"\nChecking properties for matrix: {matrix_id}")
        print(f"Matrix shape: {matrix.shape}")
        print("=" * 60)
    
    for prop in expected_properties:
        checker = MatrixProperties.get_checker(prop)
        
        if checker is None:
            if verbose:
                print(f"  {prop:<30} SKIPPED (no checker available)")
            results[prop] = None
            continue
        
        try:
            passed = checker(matrix, tol=tol)
            results[prop] = passed
            
            if verbose:
                status = "✓ PASS" if passed else "✗ FAIL"
                print(f"  {prop:<30} {status}")
            
            if not passed:
                all_passed = False
                
        except Exception as e:
            results[prop] = False
            all_passed = False
            if verbose:
                print(f"  {prop:<30} ✗ ERROR: {e}")
    
    if verbose:
        print("=" * 60)
        status_msg = "All properties verified" if all_passed else "Some properties failed"
        print(f"{status_msg}\n")
    
    return results