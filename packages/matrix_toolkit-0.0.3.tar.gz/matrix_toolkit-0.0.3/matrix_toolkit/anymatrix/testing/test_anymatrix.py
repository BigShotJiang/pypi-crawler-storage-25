"""Tests for anymatrix integration"""

import pytest
import numpy as np
from scipy import sparse

from matrix_toolkit.anymatrix import AnyMatrix, MatrixProperties


@pytest.fixture
def anymatrix():
    """Create AnyMatrix instance"""
    return AnyMatrix()


def test_anymatrix_initialization(anymatrix):
    """Test AnyMatrix initialization"""
    assert anymatrix is not None
    groups = anymatrix.groups()
    assert len(groups) > 0
    assert 'core' in groups


def test_list_matrices(anymatrix):
    """Test listing matrices"""
    # List all
    all_matrices = anymatrix.list()
    assert isinstance(all_matrices, dict)
    assert 'core' in all_matrices
    
    # List specific group
    core_matrices = anymatrix.list('core')
    assert isinstance(core_matrices, list)
    assert len(core_matrices) > 0


def test_generate_beta_matrix(anymatrix):
    """Test generating beta matrix"""
    A = anymatrix.generate('core/beta', 5)
    
    assert A.shape == (5, 5)
    assert MatrixProperties.is_symmetric(A)
    assert MatrixProperties.is_positive_definite(A)


def test_generate_fourier_matrix(anymatrix):
    """Test generating Fourier matrix"""
    F = anymatrix.generate('core/fourier', 8)
    
    assert F.shape == (8, 8)
    assert MatrixProperties.is_unitary(F)


def test_generate_nilpotent_matrices(anymatrix):
    """Test nilpotent matrices"""
    # Upper triangular nilpotent
    A = anymatrix.generate('core/nilpot_triang', 5)
    assert A.shape == (5, 5)
    assert MatrixProperties.is_upper_triangular(A)
    assert MatrixProperties.is_nilpotent(A)
    
    # Tridiagonal nilpotent
    B = anymatrix.generate('core/nilpot_tridiag', 6)
    assert B.shape == (6, 6)
    assert MatrixProperties.is_tridiagonal(B)
    assert MatrixProperties.is_nilpotent(B)


def test_properties_checking(anymatrix):
    """Test property checking"""
    matrix_id = 'core/beta'
    props = anymatrix.properties(matrix_id)
    
    assert 'symmetric' in props
    assert 'positive definite' in props
    
    # Generate and verify
    A = anymatrix.generate(matrix_id, 10)
    results = MatrixProperties.check_properties(A, props)
    
    assert results['symmetric'] is True
    assert results['positive definite'] is True


def test_search_matrices(anymatrix):
    """Test searching for matrices"""
    # Search for symmetric matrices
    symmetric_matrices = anymatrix.search(['symmetric'])
    assert len(symmetric_matrices) > 0
    assert 'core/beta' in symmetric_matrices
    
    # Search for symmetric AND positive definite
    sym_pd_matrices = anymatrix.search(['symmetric', 'positive definite'])
    assert len(sym_pd_matrices) > 0


def test_help_function(anymatrix):
    """Test help function"""
    help_text = anymatrix.help('core/beta')
    
    assert 'beta' in help_text.lower()
    assert 'symmetric' in help_text.lower()


def test_gallery_matrices(anymatrix):
    """Test gallery matrices"""
    # Lehmer matrix
    L = anymatrix.generate('gallery/lehmer', 5)
    assert L.shape == (5, 5)
    assert MatrixProperties.is_symmetric(L)
    assert MatrixProperties.is_positive_definite(L)
    
    # Clement matrix
    C = anymatrix.generate('gallery/clement', 6)
    assert C.shape == (6, 6)
    assert MatrixProperties.is_tridiagonal(C)
    assert MatrixProperties.is_symmetric(C)


def test_sparse_matrices(anymatrix):
    """Test sparse matrix generation"""
    # Perfect shuffle
    P = anymatrix.generate('core/perfect_shuffle', 10)
    assert sparse.issparse(P)
    assert P.shape == (10, 10)
    
    # Collatz
    C = anymatrix.generate('core/collatz', 20)
    assert sparse.issparse(C)


def test_property_checkers():
    """Test individual property checkers"""
    # Symmetric
    A_sym = np.array([[1, 2], [2, 3]])
    assert MatrixProperties.is_symmetric(A_sym)
    
    # Not symmetric
    A_nonsym = np.array([[1, 2], [3, 4]])
    assert not MatrixProperties.is_symmetric(A_nonsym)
    
    # Diagonal
    D = np.diag([1, 2, 3])
    assert MatrixProperties.is_diagonal(D)
    
    # Orthogonal
    Q = np.eye(3)
    assert MatrixProperties.is_orthogonal(Q)
    
    # Tridiagonal
    T = np.diag([1, 2, 3]) + np.diag([1, 1], 1) + np.diag([1, 1], -1)
    assert MatrixProperties.is_tridiagonal(T)


def test_stochastic_matrix():
    """Test stochastic matrix properties"""
    # Row stochastic
    A = np.array([[0.5, 0.5], [0.3, 0.7]])
    assert MatrixProperties.is_stochastic(A)
    
    # Doubly stochastic
    B = np.array([[0.5, 0.5], [0.5, 0.5]])
    assert MatrixProperties.is_doubly_stochastic(B)


def test_circulant_matrix(anymatrix):
    """Test circulant matrices"""
    C = anymatrix.generate('core/circul_binom', 5)
    assert MatrixProperties.is_circulant(C)
    assert MatrixProperties.is_toeplitz(C)


def test_involutory_property():
    """Test involutory property (A^2 = I)"""
    # Create an involutory matrix
    A = np.array([[0, 1], [1, 0]])  # Swap matrix
    assert MatrixProperties.is_involutory(A)
    
    # Verify A^2 = I
    assert np.allclose(A @ A, np.eye(2))