"""
Matrix Toolkit - A comprehensive toolkit for sparse matrix management
"""

__version__ = "0.0.3"
__author__ = "Xinye Chen"
__email__ = "xinyechenai@gmail.com"

from matrix_toolkit.core.fetcher import MatrixFetcher
from matrix_toolkit.core.search import MatrixSearcher
from matrix_toolkit.datasets.dataset import MatrixDataset
from matrix_toolkit.core.config import Config

# Anymatrix integration
from matrix_toolkit.anymatrix import AnyMatrix, MatrixProperties

__all__ = [
    "MatrixFetcher",
    "MatrixSearcher",
    "MatrixDataset",
    "Config",
    "AnyMatrix",
    "MatrixProperties",
]