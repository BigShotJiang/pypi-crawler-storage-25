"""Command-line interface for matrix toolkit"""

from matrix_toolkit.cli.main import cli

__all__ = ["cli"]