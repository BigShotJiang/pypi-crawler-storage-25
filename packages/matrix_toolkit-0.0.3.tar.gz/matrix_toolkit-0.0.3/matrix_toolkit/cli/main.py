"""Main CLI implementation using Click"""

import click
from pathlib import Path
import json
from matrix_toolkit import MatrixFetcher, MatrixDataset
from matrix_toolkit.core.config import config


@click.group()
@click.version_option()
def cli():
    """Matrix Toolkit - Manage sparse matrices from SuiteSparse collection"""
    pass


@cli.command()
@click.option('--rows', type=str, help='Row range (min:max)')
@click.option('--cols', type=str, help='Column range (min:max)')
@click.option('--nnz', type=str, help='Non-zero range (min:max)')
@click.option('--sparsity', type=str, help='Sparsity range (min:max)')
@click.option('--symmetry', type=str, help='Symmetry type')
@click.option('--domain', type=str, help='Application domain')
@click.option('--output', '-o', type=str, help='Output file for results')
def search(**kwargs):
    """Search for matrices matching criteria"""
    fetcher = MatrixFetcher()
    
    # Parse range arguments
    filters = {}
    for key in ['rows', 'cols', 'nnz', 'sparsity']:
        if kwargs.get(key):
            try:
                min_val, max_val = kwargs[key].split(':')
                filters[key] = (float(min_val), float(max_val))
            except:
                click.echo(f"Error: Invalid format for {key}. Use min:max", err=True)
                return
    
    # Add other filters
    if kwargs.get('symmetry'):
        filters['symmetry'] = kwargs['symmetry']
    if kwargs.get('domain'):
        filters['domain'] = kwargs['domain']
    
    # Search
    results = fetcher.search(**filters)
    
    click.echo(f"Found {len(results)} matrices")
    
    if len(results) > 0:
        click.echo("\nTop 10 results:")
        click.echo(results.head(10).to_string())
    
    # Save to file if requested
    if kwargs.get('output'):
        results.to_csv(kwargs['output'], index=False)
        click.echo(f"\nResults saved to {kwargs['output']}")


@cli.command()
@click.option('--name', required=True, help='Matrix name (e.g., HB/494_bus)')
@click.option('--backend', default='scipy', help='Backend: scipy, cupy, jax, torch')
@click.option('--format', default='csr', help='Sparse format: csr, csc, coo, etc.')
@click.option('--output', '-o', type=str, help='Output directory')
def fetch(name, backend, format, output):
    """Fetch a specific matrix"""
    fetcher = MatrixFetcher()
    
    try:
        click.echo(f"Fetching matrix: {name}")
        matrix = fetcher.get_matrix(name, backend=backend, format=format)
        
        click.echo(f"Successfully fetched matrix:")
        click.echo(f"  Shape: {matrix.shape}")
        if hasattr(matrix, 'nnz'):
            click.echo(f"  Non-zeros: {matrix.nnz}")
        click.echo(f"  Backend: {backend}")
        click.echo(f"  Format: {format}")
        
        if output:
            output_path = Path(output)
            output_path.mkdir(parents=True, exist_ok=True)
            fetcher.save_collection([matrix], output_path)
            click.echo(f"\nMatrix saved to {output_path}")
    
    except Exception as e:
        click.echo(f"Error fetching matrix: {e}", err=True)


@cli.command()
@click.option('--domain', type=str, help='Filter by domain')
@click.option('--limit', type=int, default=20, help='Maximum number of results')
def list(domain, limit):
    """List available matrices"""
    fetcher = MatrixFetcher()
    
    filters = {}
    if domain:
        filters['domain'] = domain
    
    results = fetcher.search(**filters)
    
    click.echo(f"Total matrices: {len(results)}")
    
    if len(results) > 0:
        click.echo(f"\nShowing {min(limit, len(results))} matrices:")
        display_cols = ['name', 'rows', 'cols', 'nnz']
        available_cols = [col for col in display_cols if col in results.columns]
        click.echo(results[available_cols].head(limit).to_string())


@cli.group()
def cache():
    """Cache management commands"""
    pass


@cache.command()
def clear():
    """Clear the cache"""
    from matrix_toolkit.core.cache import CacheManager
    
    cache_manager = CacheManager()
    
    click.confirm('Are you sure you want to clear the cache?', abort=True)
    
    cache_manager.clear_cache()
    click.echo("Cache cleared successfully")


@cache.command()
def info():
    """Show cache information"""
    from matrix_toolkit.core.cache import CacheManager
    
    cache_manager = CacheManager()
    stats = cache_manager.get_statistics()
    
    click.echo("Cache Statistics:")
    click.echo(f"  Location: {stats['cache_dir']}")
    click.echo(f"  Total matrices: {stats['total_matrices']}")
    click.echo(f"  Total size: {stats['total_size'] / (1024**2):.2f} MB")
    click.echo(f"  Formats: {', '.join(stats['formats'])}")


@cli.group()
def dataset():
    """Dataset management commands"""
    pass


@dataset.command()
@click.option('--config', type=click.Path(exists=True), required=True, 
              help='Dataset configuration file (YAML or JSON)')
@click.option('--output', '-o', type=str, help='Output directory')
def create(config, output):
    """Create a dataset from configuration file"""
    import yaml
    
    # Load config
    config_path = Path(config)
    if config_path.suffix in ['.yaml', '.yml']:
        with open(config_path, 'r') as f:
            dataset_config = yaml.safe_load(f)
    else:
        with open(config_path, 'r') as f:
            dataset_config = json.load(f)
    
    fetcher = MatrixFetcher()
    
    click.echo(f"Creating dataset: {dataset_config.get('name', 'unnamed')}")
    
    try:
        dataset = fetcher.create_dataset(**dataset_config)
        
        click.echo(f"Dataset created successfully:")
        click.echo(f"  Name: {dataset.name}")
        click.echo(f"  Size: {len(dataset)}")
        click.echo(f"  Splits: {list(dataset.splits.keys())}")
        
        if output:
            output_path = Path(output)
            dataset.save(output_path)
            click.echo(f"\nDataset saved to {output_path}")
    
    except Exception as e:
        click.echo(f"Error creating dataset: {e}", err=True)


@dataset.command()
@click.argument('path', type=click.Path(exists=True))
def info(path):
    """Show dataset information"""
    try:
        dataset = MatrixDataset.load(path)
        
        click.echo(f"Dataset: {dataset.name}")
        click.echo(f"Description: {dataset.description}")
        click.echo(f"Size: {len(dataset)} matrices")
        click.echo(f"Created: {dataset.created_at}")
        
        if dataset.splits:
            click.echo("\nSplits:")
            for split_name, matrices in dataset.splits.items():
                click.echo(f"  {split_name}: {len(matrices)} matrices")
    
    except Exception as e:
        click.echo(f"Error loading dataset: {e}", err=True)


@cli.command()
def config_show():
    """Show current configuration"""
    click.echo("Current Configuration:")
    click.echo(f"  Cache directory: {config.cache_dir}")
    click.echo(f"  Cache size limit: {config.cache_size_limit}")
    click.echo(f"  Auto cleanup: {config.auto_cleanup}")
    click.echo(f"  Show progress: {config.show_progress}")
    click.echo(f"  Lazy load: {config.lazy_load}")
    click.echo(f"  Number of jobs: {config.n_jobs}")
    click.echo(f"  Verify downloads: {config.verify_downloads}")
    click.echo(f"  Retry attempts: {config.retry_attempts}")


if __name__ == '__main__':
    cli()