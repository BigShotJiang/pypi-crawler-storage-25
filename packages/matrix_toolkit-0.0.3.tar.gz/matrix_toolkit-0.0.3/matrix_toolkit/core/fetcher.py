"""Main fetcher class for downloading and managing matrices"""

import os
import random
from pathlib import Path
from typing import Optional, Dict, Any, List, Union, Tuple
import warnings
import requests
from tqdm import tqdm
import numpy as np
from scipy.io import mmread, mmwrite
import pandas as pd

from matrix_toolkit.core.search import MatrixSearcher
from matrix_toolkit.core.cache import CacheManager
from matrix_toolkit.core.config import config as global_config
from matrix_toolkit.converters.base import ConverterFactory
from matrix_toolkit.storage.saver import MatrixSaver
from matrix_toolkit.storage.loader import MatrixLoader
from matrix_toolkit.datasets.dataset import MatrixDataset


class MatrixFetcher:
    """Main class for fetching and managing sparse matrices"""
    
    def __init__(self, cache_dir: Optional[Path] = None, config=None):
        self.config = config or global_config
        self.cache = CacheManager(cache_dir or self.config.cache_dir)
        self.searcher = MatrixSearcher(cache_dir or self.config.cache_dir)
        self.saver = MatrixSaver()
        self.loader = MatrixLoader()
        self.converter_factory = ConverterFactory()
        self.history: List[Dict[str, Any]] = []
        self.custom_filters: Dict[str, callable] = {}
    
    def search(self, **filters) -> pd.DataFrame:
        """Search for matrices matching filters"""
        return self.searcher.search(**filters)
    
    def get_matrix(
        self,
        matrix_name: str,
        backend: str = 'scipy',
        format: str = 'csr',
        dtype: Optional[str] = None,
        verify: bool = True,
        retry: Optional[int] = None,
        preprocessing: Optional[List[str]] = None,
        augmentation: Optional[Dict] = None,
    ):
        """
        Get a single matrix
        
        Args:
            matrix_name: Name of the matrix (e.g., 'HB/494_bus')
            backend: 'scipy', 'cupy', 'jax', 'torch', 'numpy'
            format: Sparse format ('csr', 'csc', 'coo', 'dia', 'bsr', 'lil', 'dok')
            dtype: Data type ('float32', 'float64', etc.)
            verify: Verify download integrity
            retry: Number of retry attempts
            preprocessing: List of preprocessing operations
            augmentation: Dictionary of augmentation operations
        
        Returns:
            Sparse matrix in requested backend and format
        """
        retry = retry or self.config.retry_attempts
        
        # Check cache first
        cached_path = self.cache.get_cached_matrix(matrix_name)
        
        if cached_path is None:
            # Download the matrix
            cached_path = self._download_matrix(matrix_name, retry=retry)
        
        # Load the matrix
        matrix = mmread(cached_path)
        
        # Apply preprocessing
        if preprocessing:
            matrix = self._apply_preprocessing(matrix, preprocessing)
        
        # Apply augmentation
        if augmentation:
            matrix = self._apply_augmentation(matrix, augmentation)
        
        # Convert to requested backend and format
        converter = self.converter_factory.get_converter(backend)
        matrix = converter.convert(matrix, format=format, dtype=dtype)
        
        # Record in history
        self.history.append({
            'operation': 'get_matrix',
            'matrix_name': matrix_name,
            'backend': backend,
            'format': format,
            'timestamp': pd.Timestamp.now()
        })
        
        return matrix
    
    def _download_matrix(self, matrix_name: str, retry: int = 3) -> Path:
        """Download a matrix from SuiteSparse"""
        for attempt in range(retry):
            try:
                # Construct download URL
                # Format: https://sparse.tamu.edu/MM/Group/MatrixName.tar.gz
                group, name = matrix_name.split('/')
                url = f"{self.config.suitesparse_url}/MM/{group}/{name}.tar.gz"
                
                # Download with progress bar
                response = requests.get(url, stream=True, timeout=30)
                response.raise_for_status()
                
                total_size = int(response.headers.get('content-length', 0))
                
                # Save to temporary file
                temp_file = self.cache.cache_dir / f"{name}.tar.gz"
                
                with open(temp_file, 'wb') as f:
                    if self.config.show_progress:
                        with tqdm(total=total_size, unit='B', unit_scale=True) as pbar:
                            for chunk in response.iter_content(chunk_size=8192):
                                f.write(chunk)
                                pbar.update(len(chunk))
                    else:
                        for chunk in response.iter_content(chunk_size=8192):
                            f.write(chunk)
                
                # Extract the .mtx file
                import tarfile
                with tarfile.open(temp_file, 'r:gz') as tar:
                    # Find the .mtx file
                    mtx_members = [m for m in tar.getmembers() if m.name.endswith('.mtx')]
                    if mtx_members:
                        mtx_file = mtx_members[0]
                        tar.extract(mtx_file, self.cache.cache_dir)
                        
                        # Move to standard location
                        extracted_path = self.cache.cache_dir / mtx_file.name
                        cache_path = self.cache.get_cache_path(matrix_name, 'mtx')
                        extracted_path.rename(cache_path)
                        
                        # Cache the matrix
                        metadata = self.searcher.get_metadata(matrix_name)
                        self.cache.cache_matrix(matrix_name, cache_path, format='mtx', 
                                              metadata=metadata)
                        
                        # Clean up
                        temp_file.unlink()
                        
                        return cache_path
                
                raise ValueError(f"No .mtx file found in archive for {matrix_name}")
                
            except Exception as e:
                if attempt == retry - 1:
                    raise RuntimeError(f"Failed to download {matrix_name} after {retry} attempts: {e}")
                warnings.warn(f"Download attempt {attempt + 1} failed: {e}")
        
        raise RuntimeError(f"Failed to download {matrix_name}")
    
    def fetch(
        self,
        n: int = 1,
        mode: str = 'random',
        filters: Optional[Dict] = None,
        format: str = 'csr',
        backend: str = 'scipy',
        max_warn: int = 100,
        seed: Optional[int] = None,
        **kwargs
    ) -> List:
        """
        Fetch multiple matrices
        
        Args:
            n: Number of matrices to fetch
            mode: 'random', 'sequential', 'stratified'
            filters: Search filters
            format: Sparse format
            backend: Target backend
            max_warn: Warn if more than this many matrices match
            seed: Random seed for reproducibility
        
        Returns:
            List of matrices
        """
        if seed is not None:
            random.seed(seed)
            np.random.seed(seed)
        
        # Search for matching matrices
        search_filters = filters or {}
        results_df = self.searcher.search(**search_filters)
        
        if len(results_df) == 0:
            warnings.warn("No matrices found matching the filters")
            return []
        
        if len(results_df) > max_warn:
            warnings.warn(f"Found {len(results_df)} matrices, more than max_warn={max_warn}")
        
        # Select matrices based on mode
        if mode == 'random':
            selected = results_df.sample(n=min(n, len(results_df)))
        elif mode == 'sequential':
            selected = results_df.head(n)
        elif mode == 'stratified':
            # Stratified sampling by group/domain
            if 'group' in results_df.columns:
                selected = results_df.groupby('group', group_keys=False).apply(
                    lambda x: x.sample(min(len(x), max(1, n // results_df['group'].nunique())))
                ).head(n)
            else:
                selected = results_df.sample(n=min(n, len(results_df)))
        else:
            raise ValueError(f"Unknown mode: {mode}")
        
        # Fetch the selected matrices
        matrices = []
        for _, row in selected.iterrows():
            try:
                matrix = self.get_matrix(
                    row['name'],
                    backend=backend,
                    format=format,
                    **kwargs
                )
                matrices.append(matrix)
            except Exception as e:
                warnings.warn(f"Failed to fetch {row['name']}: {e}")
        
        return matrices
    
    def fetch_all(self, filters: Optional[Dict] = None, **kwargs) -> List:
        """Fetch all matrices matching filters"""
        results_df = self.searcher.search(**(filters or {}))
        return self.fetch(n=len(results_df), mode='sequential', filters=filters, **kwargs)
    
    def iter_fetch(self, filters: Optional[Dict] = None, batch_size: int = 10, **kwargs):
        """Iterator for fetching matrices in batches"""
        results_df = self.searcher.search(**(filters or {}))
        
        for i in range(0, len(results_df), batch_size):
            batch_df = results_df.iloc[i:i+batch_size]
            batch_matrices = []
            
            for _, row in batch_df.iterrows():
                try:
                    matrix = self.get_matrix(row['name'], **kwargs)
                    batch_matrices.append(matrix)
                except Exception as e:
                    warnings.warn(f"Failed to fetch {row['name']}: {e}")
            
            yield batch_matrices
    
    def save_collection(
        self,
        matrices: List,
        path: Union[str, Path],
        format: str = 'npz',
        compression: bool = True,
        metadata: bool = True,
    ):
        """Save a collection of matrices"""
        self.saver.save_collection(
            matrices, path, format=format, 
            compression=compression, metadata=metadata
        )
    
    def load_collection(self, path: Union[str, Path], **kwargs):
        """Load a saved collection"""
        return self.loader.load_collection(path, **kwargs)
    
    def create_dataset(
        self,
        name: str,
        filters: Dict,
        size: int,
        split: Optional[Dict[str, float]] = None,
        stratify_by: Optional[str] = None,
        **kwargs
    ) -> MatrixDataset:
        """Create a matrix dataset"""
        # Search for matrices
        results_df = self.searcher.search(**filters)
        
        if len(results_df) < size:
            warnings.warn(f"Only {len(results_df)} matrices found, less than requested {size}")
            size = len(results_df)
        
        # Sample matrices
        if stratify_by and stratify_by in results_df.columns:
            sampled = results_df.groupby(stratify_by, group_keys=False).apply(
                lambda x: x.sample(min(len(x), max(1, size // results_df[stratify_by].nunique())))
            ).head(size)
        else:
            sampled = results_df.sample(n=size)
        
        # Create dataset
        dataset = MatrixDataset(
            name=name,
            matrix_names=sampled['name'].tolist(),
            metadata=sampled.to_dict('records'),
            split=split,
            **kwargs
        )
        
        return dataset
    
    def _apply_preprocessing(self, matrix, operations: List[str]):
        """Apply preprocessing operations to matrix"""
        from scipy import sparse
        
        for op in operations:
            if op == 'normalize':
                # Row normalization
                row_sums = np.array(matrix.sum(axis=1)).flatten()
                row_sums[row_sums == 0] = 1
                matrix = sparse.diags(1.0 / row_sums) @ matrix
            elif op == 'remove_duplicates':
                if hasattr(matrix, 'sum_duplicates'):
                    matrix.sum_duplicates()
            elif op == 'sort_indices':
                if hasattr(matrix, 'sort_indices'):
                    matrix.sort_indices()
        
        return matrix
    
    def _apply_augmentation(self, matrix, augmentation: Dict):
        """Apply augmentation operations to matrix"""
        if 'add_noise' in augmentation:
            noise_level = augmentation['add_noise']
            # Add random noise
            noise = np.random.randn(*matrix.shape) * noise_level
            matrix = matrix + noise
        
        if augmentation.get('permute'):
            # Random row/column permutation
            n_rows, n_cols = matrix.shape
            row_perm = np.random.permutation(n_rows)
            col_perm = np.random.permutation(n_cols)
            matrix = matrix[row_perm, :][:, col_perm]
        
        return matrix
    
    def get_metadata(self, matrix_name: str) -> Optional[Dict]:
        """Get metadata for a matrix"""
        return self.searcher.get_metadata(matrix_name)
    
    def statistics(self, filters: Optional[Dict] = None) -> Dict:
        """Get statistics for matrices"""
        return self.searcher.statistics(filters)
    
    def add_filter(self, name: str, filter_func: callable):
        """Add a custom filter function"""
        self.custom_filters[name] = filter_func
    
    def get_history(self) -> List[Dict]:
        """Get operation history"""
        return self.history
    
    def health_check(self) -> Dict[str, Any]:
        """Perform health check"""
        import shutil
        
        cache_stats = self.cache.get_statistics()
        disk_usage = shutil.disk_usage(self.cache.cache_dir)
        
        return {
            'cache_dir': str(self.cache.cache_dir),
            'cache_size': cache_stats['total_size'],
            'total_matrices_cached': cache_stats['total_matrices'],
            'disk_free': disk_usage.free,
            'disk_total': disk_usage.total,
            'config': {
                'cache_size_limit': self.config.cache_size_limit,
                'auto_cleanup': self.config.auto_cleanup,
            }
        }