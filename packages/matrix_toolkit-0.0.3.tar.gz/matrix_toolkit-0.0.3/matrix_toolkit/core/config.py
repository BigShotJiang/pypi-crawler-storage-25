"""Configuration management for matrix toolkit"""

import os
from pathlib import Path
from typing import Optional
import yaml


class Config:
    """Global configuration for matrix toolkit"""
    
    def __init__(self):
        self.cache_dir = Path.home() / ".matrix_toolkit" / "cache"
        self.cache_size_limit = "10GB"
        self.auto_cleanup = True
        self.show_progress = True
        self.speed_limit: Optional[str] = None
        self.lazy_load = False
        self.memory_limit: Optional[str] = None
        self.n_jobs = 1
        self.verify_downloads = True
        self.retry_attempts = 3
        self.fallback_mirrors = True
        self.suitesparse_url = "https://sparse.tamu.edu"
        
        # Create cache directory if it doesn't exist
        self.cache_dir.mkdir(parents=True, exist_ok=True)
    
    @classmethod
    def from_file(cls, config_path: str) -> "Config":
        """Load configuration from YAML file"""
        config = cls()
        with open(config_path, 'r') as f:
            data = yaml.safe_load(f)
        
        for key, value in data.items():
            if hasattr(config, key):
                if key == 'cache_dir':
                    setattr(config, key, Path(value))
                else:
                    setattr(config, key, value)
        
        return config
    
    def save(self, config_path: str):
        """Save configuration to YAML file"""
        data = {
            'cache_dir': str(self.cache_dir),
            'cache_size_limit': self.cache_size_limit,
            'auto_cleanup': self.auto_cleanup,
            'show_progress': self.show_progress,
            'speed_limit': self.speed_limit,
            'lazy_load': self.lazy_load,
            'memory_limit': self.memory_limit,
            'n_jobs': self.n_jobs,
            'verify_downloads': self.verify_downloads,
            'retry_attempts': self.retry_attempts,
            'fallback_mirrors': self.fallback_mirrors,
            'suitesparse_url': self.suitesparse_url,
        }
        
        with open(config_path, 'w') as f:
            yaml.dump(data, f, default_flow_style=False)
    
    def get_cache_size(self) -> int:
        """Get current cache size in bytes"""
        total_size = 0
        for dirpath, dirnames, filenames in os.walk(self.cache_dir):
            for filename in filenames:
                filepath = os.path.join(dirpath, filename)
                total_size += os.path.getsize(filepath)
        return total_size
    
    def parse_size(self, size_str: str) -> int:
        """Parse size string like '10GB' to bytes"""
        units = {
            'B': 1,
            'KB': 1024,
            'MB': 1024**2,
            'GB': 1024**3,
            'TB': 1024**4,
        }
        
        size_str = size_str.upper().strip()
        for unit, multiplier in units.items():
            if size_str.endswith(unit):
                number = float(size_str[:-len(unit)])
                return int(number * multiplier)
        
        return int(size_str)


# Global configuration instance
config = Config()