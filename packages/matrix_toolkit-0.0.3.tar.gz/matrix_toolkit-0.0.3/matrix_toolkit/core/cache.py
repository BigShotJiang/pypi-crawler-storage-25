"""Cache management for downloaded matrices"""

import os
import json
import shutil
import hashlib
from pathlib import Path
from typing import Optional, Dict, Any
from datetime import datetime
import pickle


class CacheManager:
    """Manages local cache of downloaded matrices"""
    
    def __init__(self, cache_dir: Optional[Path] = None):
        from matrix_toolkit.core.config import config as global_config
        
        self.cache_dir = cache_dir or global_config.cache_dir
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.metadata_file = self.cache_dir / "metadata.json"
        self.metadata = self._load_metadata()
    
    def _load_metadata(self) -> Dict[str, Any]:
        """Load cache metadata"""
        if self.metadata_file.exists():
            with open(self.metadata_file, 'r') as f:
                return json.load(f)
        return {}
    
    def _save_metadata(self):
        """Save cache metadata"""
        with open(self.metadata_file, 'w') as f:
            json.dump(self.metadata, f, indent=2)
    
    def get_cache_path(self, matrix_name: str, format: str = 'mtx') -> Path:
        """Get cache path for a matrix"""
        # Create a hash of the matrix name for filename
        name_hash = hashlib.md5(matrix_name.encode()).hexdigest()
        cache_path = self.cache_dir / f"{name_hash}.{format}"
        return cache_path
    
    def is_cached(self, matrix_name: str, format: str = 'mtx') -> bool:
        """Check if matrix is in cache"""
        cache_path = self.get_cache_path(matrix_name, format)
        return cache_path.exists()
    
    def cache_matrix(self, matrix_name: str, data: Any, format: str = 'mtx', 
                    metadata: Optional[Dict] = None):
        """Cache a matrix with metadata"""
        cache_path = self.get_cache_path(matrix_name, format)
        
        # Save the data
        if format == 'mtx':
            # Assume data is a file path to copy
            shutil.copy2(data, cache_path)
        elif format == 'pickle':
            with open(cache_path, 'wb') as f:
                pickle.dump(data, f)
        else:
            # For other formats, save as-is
            with open(cache_path, 'wb') as f:
                f.write(data)
        
        # Update metadata
        self.metadata[matrix_name] = {
            'format': format,
            'path': str(cache_path),
            'cached_at': datetime.now().isoformat(),
            'size': cache_path.stat().st_size,
            'metadata': metadata or {}
        }
        self._save_metadata()
    
    def get_cached_matrix(self, matrix_name: str, format: str = 'mtx') -> Optional[Path]:
        """Get path to cached matrix"""
        if self.is_cached(matrix_name, format):
            return self.get_cache_path(matrix_name, format)
        return None
    
    def clear_cache(self):
        """Clear all cached matrices"""
        for item in self.cache_dir.iterdir():
            if item.is_file():
                item.unlink()
            elif item.is_dir():
                shutil.rmtree(item)
        
        self.metadata = {}
        self._save_metadata()
    
    def get_cache_size(self) -> int:
        """Get total cache size in bytes"""
        total = 0
        for item in self.cache_dir.rglob('*'):
            if item.is_file():
                total += item.stat().st_size
        return total
    
    def cleanup_old_cache(self, max_age_days: int = 30):
        """Remove cache entries older than max_age_days"""
        from datetime import timedelta
        
        cutoff = datetime.now() - timedelta(days=max_age_days)
        
        to_remove = []
        for matrix_name, info in self.metadata.items():
            cached_at = datetime.fromisoformat(info['cached_at'])
            if cached_at < cutoff:
                to_remove.append(matrix_name)
        
        for matrix_name in to_remove:
            cache_path = Path(self.metadata[matrix_name]['path'])
            if cache_path.exists():
                cache_path.unlink()
            del self.metadata[matrix_name]
        
        self._save_metadata()
        return len(to_remove)
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get cache statistics"""
        return {
            'total_matrices': len(self.metadata),
            'total_size': self.get_cache_size(),
            'cache_dir': str(self.cache_dir),
            'formats': list(set(info['format'] for info in self.metadata.values()))
        }