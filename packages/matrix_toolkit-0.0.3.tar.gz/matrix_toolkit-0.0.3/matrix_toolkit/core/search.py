"""Search and filter matrices from SuiteSparse collection"""

import re
from typing import Optional, Dict, Any, List, Tuple, Union
import pandas as pd
import requests
from pathlib import Path


class MatrixSearcher:
    """Search and filter matrices from SuiteSparse collection"""
    
    def __init__(self, cache_dir: Optional[Path] = None):
        from matrix_toolkit.core.config import config
        from matrix_toolkit.core.cache import CacheManager
        
        self.config = config
        self.cache = CacheManager(cache_dir)
        self.index_df: Optional[pd.DataFrame] = None
        self._load_index()
    
    def _load_index(self):
        """Load or download the SuiteSparse matrix index"""
        index_cache = self.cache.cache_dir / "suitesparse_index.csv"
        
        if index_cache.exists():
            self.index_df = pd.read_csv(index_cache)
        else:
            # Download index from SuiteSparse
            self._download_index()
    
    def _download_index(self):
        """Download matrix index from SuiteSparse"""
        try:
            # Try to use ssgetpy to get the index
            import ssgetpy
            
            # Get the matrix collection metadata
            # This is a simplified version - ssgetpy provides this functionality
            index_url = f"{self.config.suitesparse_url}/files/ssstats.csv"
            
            response = requests.get(index_url, timeout=30)
            response.raise_for_status()
            
            index_cache = self.cache.cache_dir / "suitesparse_index.csv"
            with open(index_cache, 'wb') as f:
                f.write(response.content)
            
            self.index_df = pd.read_csv(index_cache)
            
        except Exception as e:
            print(f"Warning: Could not download SuiteSparse index: {e}")
            # Create a minimal dummy index for testing
            self.index_df = pd.DataFrame({
                'name': [],
                'rows': [],
                'cols': [],
                'nnz': [],
                'pattern': [],
                'symmetry': [],
                'positive_definite': [],
                'kind': [],
                'group': []
            })
    
    def search(
        self,
        rows: Optional[Tuple[int, int]] = None,
        cols: Optional[Tuple[int, int]] = None,
        nnz: Optional[Tuple[int, int]] = None,
        sparsity: Optional[Tuple[float, float]] = None,
        symmetry: Optional[str] = None,
        positive_definite: Optional[bool] = None,
        structure: Optional[str] = None,
        domain: Optional[Union[str, List[str]]] = None,
        kind: Optional[str] = None,
        exclude_patterns: bool = False,
        **kwargs
    ) -> pd.DataFrame:
        """
        Search matrices with given criteria
        
        Args:
            rows: Tuple of (min_rows, max_rows)
            cols: Tuple of (min_cols, max_cols)
            nnz: Tuple of (min_nnz, max_nnz)
            sparsity: Tuple of (min_sparsity, max_sparsity) where sparsity = 1 - nnz/(rows*cols)
            symmetry: 'symmetric', 'unsymmetric', 'hermitian'
            positive_definite: True/False
            structure: 'square', 'rectangular'
            domain: Single domain or list of domains (e.g., 'physics', ['physics', 'circuit'])
            kind: 'real', 'complex', 'binary', 'integer'
            exclude_patterns: Exclude artificially generated pattern matrices
        
        Returns:
            DataFrame of matching matrices
        """
        if self.index_df is None or self.index_df.empty:
            return pd.DataFrame()
        
        df = self.index_df.copy()
        
        # Filter by rows
        if rows is not None:
            df = df[(df['rows'] >= rows[0]) & (df['rows'] <= rows[1])]
        
        # Filter by columns
        if cols is not None:
            df = df[(df['cols'] >= cols[0]) & (df['cols'] <= cols[1])]
        
        # Filter by non-zeros
        if nnz is not None:
            df = df[(df['nnz'] >= nnz[0]) & (df['nnz'] <= nnz[1])]
        
        # Filter by sparsity
        if sparsity is not None:
            # Calculate sparsity
            df['sparsity'] = 1 - (df['nnz'] / (df['rows'] * df['cols']))
            df = df[(df['sparsity'] >= sparsity[0]) & (df['sparsity'] <= sparsity[1])]
        
        # Filter by symmetry
        if symmetry is not None and 'symmetry' in df.columns:
            df = df[df['symmetry'].str.lower() == symmetry.lower()]
        
        # Filter by positive definite
        if positive_definite is not None and 'positive_definite' in df.columns:
            df = df[df['positive_definite'] == positive_definite]
        
        # Filter by structure
        if structure == 'square':
            df = df[df['rows'] == df['cols']]
        elif structure == 'rectangular':
            df = df[df['rows'] != df['cols']]
        
        # Filter by domain/group
        if domain is not None and 'group' in df.columns:
            if isinstance(domain, str):
                domain = [domain]
            df = df[df['group'].isin(domain)]
        
        # Filter by kind
        if kind is not None and 'kind' in df.columns:
            df = df[df['kind'].str.lower() == kind.lower()]
        
        # Exclude patterns
        if exclude_patterns and 'pattern' in df.columns:
            df = df[df['pattern'] == False]
        
        return df
    
    def get_metadata(self, matrix_name: str) -> Optional[Dict[str, Any]]:
        """Get metadata for a specific matrix"""
        if self.index_df is None:
            return None
        
        matches = self.index_df[self.index_df['name'] == matrix_name]
        if len(matches) == 0:
            return None
        
        return matches.iloc[0].to_dict()
    
    def statistics(self, filters: Optional[Dict] = None) -> Dict[str, Any]:
        """Get statistics for matrices matching filters"""
        if filters:
            df = self.search(**filters)
        else:
            df = self.index_df
        
        if df is None or df.empty:
            return {}
        
        stats = {
            'count': len(df),
            'avg_rows': df['rows'].mean() if 'rows' in df.columns else 0,
            'avg_cols': df['cols'].mean() if 'cols' in df.columns else 0,
            'avg_nnz': df['nnz'].mean() if 'nnz' in df.columns else 0,
        }
        
        # Calculate average sparsity
        if 'rows' in df.columns and 'cols' in df.columns and 'nnz' in df.columns:
            sparsity = 1 - (df['nnz'] / (df['rows'] * df['cols']))
            stats['avg_sparsity'] = sparsity.mean()
        
        # Group by domain
        if 'group' in df.columns:
            stats['domains'] = df['group'].value_counts().to_dict()
        
        return stats
    
    def list_domains(self) -> List[str]:
        """List all available domains/groups"""
        if self.index_df is None or 'group' not in self.index_df.columns:
            return []
        
        return sorted(self.index_df['group'].unique().tolist())
    
    def refresh_index(self):
        """Force refresh of the matrix index"""
        index_cache = self.cache.cache_dir / "suitesparse_index.csv"
        if index_cache.exists():
            index_cache.unlink()
        self._download_index()