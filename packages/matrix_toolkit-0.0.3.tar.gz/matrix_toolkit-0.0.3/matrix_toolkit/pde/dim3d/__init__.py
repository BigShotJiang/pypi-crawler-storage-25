"""3D PDE matrix generators"""

from matrix_toolkit.pde.dim3d.generators import (
    generate_3d_laplacian,
    generate_3d_convection_diffusion,
    generate_3d_heat,
    generate_3d_wave,
    generate_3d_helmholtz,
    generate_3d_biharmonic,
)

__all__ = [
    "generate_3d_laplacian",
    "generate_3d_convection_diffusion",
    "generate_3d_heat",
    "generate_3d_wave",
    "generate_3d_helmholtz",
    "generate_3d_biharmonic",
]