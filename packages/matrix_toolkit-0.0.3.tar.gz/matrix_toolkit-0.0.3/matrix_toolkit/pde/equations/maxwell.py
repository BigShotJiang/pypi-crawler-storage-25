"""
Maxwell's equations for electromagnetics
"""

import numpy as np
from scipy import sparse
from typing import Dict, Any

from matrix_toolkit.pde.base import BasePDEEquation


class MaxwellEquation(BasePDEEquation):
    """
    Time-harmonic Maxwell equations
    
    ∇×E - iωμH = 0
    ∇×H + iωεE = J
    
    Or in terms of E only:
    ∇×(∇×E) - ω²με E = -iωμJ
    
    Examples:
        >>> config = PDEConfig(
        ...     dimension=3,
        ...     mesh_size=16,
        ...     coefficients={
        ...         'frequency': 1e9,  # 1 GHz
        ...         'permittivity': 8.854e-12,
        ...         'permeability': 1.257e-6
        ...     }
        ... )
        >>> eq = MaxwellEquation(config)
        >>> A = eq.generate_matrix()
    """
    
    def get_operator_name(self) -> str:
        return "Maxwell"
    
    def get_default_coefficients(self) -> Dict[str, Any]:
        return {
            'frequency': 1e9,                  # Angular frequency ω (rad/s)
            'permittivity': 8.854e-12,        # Electric permittivity ε (F/m)
            'permeability': 1.257e-6,         # Magnetic permeability μ (H/m)
        }
    
    def generate_matrix(self) -> sparse.spmatrix:
        """Generate Maxwell system matrix"""
        if self.config.dimension != 3:
            raise ValueError("Maxwell equations require 3D domain")
        
        coeffs = self.config.coefficients or self.get_default_coefficients()
        
        if self.config.random_params:
            coeffs = self.randomize_coefficients(self.config.random_seed)
        
        omega = coeffs.get('frequency', 1e9)
        eps = coeffs.get('permittivity', 8.854e-12)
        mu = coeffs.get('permeability', 1.257e-6)
        
        return self._generate_3d(omega, eps, mu)
    
    def _generate_3d(self, omega: float, eps: float, mu: float) -> sparse.spmatrix:
        """
        Generate 3D Maxwell curl-curl operator
        
        A = ∇×(∇×) - ω²με I
        """
        nx, ny, nz = self.config.mesh_size
        hx, hy, hz = self.config.get_mesh_spacing()
        n = nx * ny * nz
        
        # Build curl operator
        curl = self._build_curl_3d(nx, ny, nz, hx, hy, hz)
        
        # Curl-curl operator
        curl_curl = curl.T @ curl
        
        # Wave number squared
        k_squared = omega**2 * eps * mu
        
        # Full operator: ∇×(∇×) - k²I
        # Note: 3 vector components
        I = sparse.eye(3 * n, format='csr')
        A = curl_curl - k_squared * I
        
        return A
    
    def _build_curl_3d(
        self,
        nx: int,
        ny: int,
        nz: int,
        hx: float,
        hy: float,
        hz: float
    ) -> sparse.spmatrix:
        """
        Build 3D curl operator
        
        curl(E) = [∂Ez/∂y - ∂Ey/∂z, ∂Ex/∂z - ∂Ez/∂x, ∂Ey/∂x - ∂Ex/∂y]
        """
        n = nx * ny * nz
        
        # Derivative operators
        Dx = sparse.diags([-np.ones(nx-1), np.ones(nx-1)], [0, 1], shape=(nx, nx)) / hx
        Dx_3d = sparse.kron(sparse.kron(Dx, sparse.eye(ny)), sparse.eye(nz))
        
        Dy = sparse.diags([-np.ones(ny-1), np.ones(ny-1)], [0, 1], shape=(ny, ny)) / hy
        Dy_3d = sparse.kron(sparse.kron(sparse.eye(nx), Dy), sparse.eye(nz))
        
        Dz = sparse.diags([-np.ones(nz-1), np.ones(nz-1)], [0, 1], shape=(nz, nz)) / hz
        Dz_3d = sparse.kron(sparse.kron(sparse.eye(nx), sparse.eye(ny)), Dz)
        
        zero = sparse.csr_matrix((n, n))
        
        # Curl operator as 3x3 block matrix
        # curl = [    0      -∂/∂z    ∂/∂y  ]
        #        [  ∂/∂z       0     -∂/∂x  ]
        #        [ -∂/∂y     ∂/∂x      0    ]
        
        row1 = sparse.hstack([zero, -Dz_3d, Dy_3d])
        row2 = sparse.hstack([Dz_3d, zero, -Dx_3d])
        row3 = sparse.hstack([-Dy_3d, Dx_3d, zero])
        
        curl = sparse.vstack([row1, row2, row3], format='csr')
        
        return curl