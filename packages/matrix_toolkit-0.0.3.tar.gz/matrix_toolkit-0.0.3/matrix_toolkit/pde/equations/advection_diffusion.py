"""
Advection-diffusion equation with thermal effects
"""

import numpy as np
from scipy import sparse
from typing import Dict, Any, Tuple

from matrix_toolkit.pde.base import BasePDEEquation


class AdvectionDiffusionEquation(BasePDEEquation):
    """
    Advection-diffusion equation (temperature transport)
    
    ∂T/∂t + u·∇T = α∇²T + Q
    
    where:
    - T is temperature
    - u is velocity field (given)
    - α is thermal diffusivity
    - Q is heat source
    
    Examples:
        >>> config = PDEConfig(
        ...     dimension=2,
        ...     mesh_size=64,
        ...     coefficients={
        ...         'diffusivity': 1.0,
        ...         'velocity': (1.0, 0.5),
        ...         'dt': 0.01
        ...     }
        ... )
        >>> eq = AdvectionDiffusionEquation(config)
        >>> M = eq.generate_matrix()
    """
    
    def get_operator_name(self) -> str:
        return "AdvectionDiffusion"
    
    def get_default_coefficients(self) -> Dict[str, Any]:
        return {
            'diffusivity': 1.0,     # Thermal diffusivity α
            'velocity': None,        # Velocity field u
            'dt': 0.01,             # Time step
            'theta': 0.5,           # Time discretization
        }
    
    def generate_matrix(self) -> sparse.spmatrix:
        """Generate advection-diffusion matrix"""
        coeffs = self.config.coefficients or self.get_default_coefficients()
        
        if self.config.random_params:
            coeffs = self.randomize_coefficients(self.config.random_seed)
        
        alpha = coeffs.get('diffusivity', 1.0)
        velocity = coeffs.get('velocity')
        dt = coeffs.get('dt', 0.01)
        theta = coeffs.get('theta', 0.5)
        
        # Set default velocity based on dimension
        if velocity is None:
            if self.config.dimension == 1:
                velocity = 1.0
            elif self.config.dimension == 2:
                velocity = (1.0, 0.0)
            elif self.config.dimension == 3:
                velocity = (1.0, 0.0, 0.0)
        
        if self.config.dimension == 1:
            return self._generate_1d(alpha, velocity, dt, theta)
        elif self.config.dimension == 2:
            return self._generate_2d(alpha, velocity, dt, theta)
        elif self.config.dimension == 3:
            return self._generate_3d(alpha, velocity, dt, theta)
    
    def _generate_1d(
        self,
        alpha: float,
        u: float,
        dt: float,
        theta: float
    ) -> sparse.spmatrix:
        """Generate 1D advection-diffusion matrix"""
        from matrix_toolkit.pde.dim1d.generators import (
            generate_1d_laplacian,
            generate_1d_convection_diffusion
        )
        
        # Use convection-diffusion generator
        n = self.config.mesh_size[0]
        h = self.config.get_mesh_spacing()[0]
        
        L = generate_1d_laplacian(n, h)
        
        # Advection operator: u ∂/∂x
        Dx = sparse.diags(
            [-np.ones(n-1), np.ones(n-1)],
            [0, 1],
            shape=(n, n)
        ) / (2 * h)
        
        A_adv = u * Dx
        
        # Combined operator
        I = sparse.eye(n, format='csr')
        operator = alpha * L - A_adv
        
        # Time stepping
        M = I - theta * dt * operator
        
        return M
    
    def _generate_2d(
        self,
        alpha: float,
        u: Tuple[float, float],
        dt: float,
        theta: float
    ) -> sparse.spmatrix:
        """Generate 2D advection-diffusion matrix"""
        from matrix_toolkit.pde.dim2d.generators import generate_2d_laplacian
        
        nx, ny = self.config.mesh_size
        hx, hy = self.config.get_mesh_spacing()
        n = nx * ny
        
        # Diffusion
        L = generate_2d_laplacian(nx, ny, hx, hy)
        
        # Advection
        ux, uy = u
        
        Dx = sparse.diags([-np.ones(nx-1), np.ones(nx-1)], [0, 1], shape=(nx, nx)) / (2*hx)
        Dx_2d = sparse.kron(Dx, sparse.eye(ny))
        
        Dy = sparse.diags([-np.ones(ny-1), np.ones(ny-1)], [0, 1], shape=(ny, ny)) / (2*hy)
        Dy_2d = sparse.kron(sparse.eye(nx), Dy)
        
        A_adv = ux * Dx_2d + uy * Dy_2d
        
        # Combined
        I = sparse.eye(n, format='csr')
        operator = alpha * L - A_adv
        
        M = I - theta * dt * operator
        
        return M
    
    def _generate_3d(
        self,
        alpha: float,
        u: Tuple[float, float, float],
        dt: float,
        theta: float
    ) -> sparse.spmatrix:
        """Generate 3D advection-diffusion matrix"""
        from matrix_toolkit.pde.dim3d.generators import generate_3d_laplacian
        
        nx, ny, nz = self.config.mesh_size
        hx, hy, hz = self.config.get_mesh_spacing()
        n = nx * ny * nz
        
        # Diffusion
        L = generate_3d_laplacian(nx, ny, nz, hx, hy, hz)
        
        # Advection
        ux, uy, uz = u
        
        Dx = sparse.diags([-np.ones(nx-1), np.ones(nx-1)], [0, 1], shape=(nx, nx)) / (2*hx)
        Dx_3d = sparse.kron(sparse.kron(Dx, sparse.eye(ny)), sparse.eye(nz))
        
        Dy = sparse.diags([-np.ones(ny-1), np.ones(ny-1)], [0, 1], shape=(ny, ny)) / (2*hy)
        Dy_3d = sparse.kron(sparse.kron(sparse.eye(nx), Dy), sparse.eye(nz))
        
        Dz = sparse.diags([-np.ones(nz-1), np.ones(nz-1)], [0, 1], shape=(nz, nz)) / (2*hz)
        Dz_3d = sparse.kron(sparse.kron(sparse.eye(nx), sparse.eye(ny)), Dz)
        
        A_adv = ux * Dx_3d + uy * Dy_3d + uz * Dz_3d
        
        # Combined
        I = sparse.eye(n, format='csr')
        operator = alpha * L - A_adv
        
        M = I - theta * dt * operator
        
        return M