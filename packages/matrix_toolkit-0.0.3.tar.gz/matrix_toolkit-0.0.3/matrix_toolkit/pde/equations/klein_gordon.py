"""
Klein-Gordon equation (relativistic wave equation)
"""

import numpy as np
from scipy import sparse
from typing import Dict, Any

from matrix_toolkit.pde.base import BasePDEEquation


class KleinGordonEquation(BasePDEEquation):
    """
    Klein-Gordon equation
    
    ∂²φ/∂t² - c²∇²φ + m²c⁴/ℏ² φ = 0
    
    In dimensionless form (c=ℏ=1):
    ∂²φ/∂t² - ∇²φ + m²φ = 0
    
    Examples:
        >>> config = PDEConfig(
        ...     dimension=2,
        ...     mesh_size=64,
        ...     coefficients={
        ...         'mass': 1.0,
        ...         'wave_speed': 1.0,
        ...         'dt': 0.01
        ...     }
        ... )
        >>> eq = KleinGordonEquation(config)
        >>> M = eq.generate_matrix()
    """
    
    def get_operator_name(self) -> str:
        return "KleinGordon"
    
    def get_default_coefficients(self) -> Dict[str, Any]:
        return {
            'mass': 1.0,            # Particle mass m
            'wave_speed': 1.0,      # Speed of light c
            'hbar': 1.0,            # Reduced Planck constant
            'dt': 0.01,
        }
    
    def generate_matrix(self) -> sparse.spmatrix:
        """Generate Klein-Gordon operator"""
        coeffs = self.config.coefficients or self.get_default_coefficients()
        
        if self.config.random_params:
            coeffs = self.randomize_coefficients(self.config.random_seed)
        
        m = coeffs.get('mass', 1.0)
        c = coeffs.get('wave_speed', 1.0)
        hbar = coeffs.get('hbar', 1.0)
        dt = coeffs.get('dt', 0.01)
        
        # Get Laplacian based on dimension
        if self.config.dimension == 1:
            from matrix_toolkit.pde.dim1d.generators import generate_1d_laplacian
            n = self.config.mesh_size[0]
            h = self.config.get_mesh_spacing()[0]
            L = generate_1d_laplacian(n, h)
            n_dof = n
        elif self.config.dimension == 2:
            from matrix_toolkit.pde.dim2d.generators import generate_2d_laplacian
            nx, ny = self.config.mesh_size
            hx, hy = self.config.get_mesh_spacing()
            L = generate_2d_laplacian(nx, ny, hx, hy)
            n_dof = nx * ny
        elif self.config.dimension == 3:
            from matrix_toolkit.pde.dim3d.generators import generate_3d_laplacian
            nx, ny, nz = self.config.mesh_size
            hx, hy, hz = self.config.get_mesh_spacing()
            L = generate_3d_laplacian(nx, ny, nz, hx, hy, hz)
            n_dof = nx * ny * nz
        
        # Klein-Gordon operator
        # Time discretization: (1/dt²)I - c²L + (mc²/ℏ)²I
        mass_term = (m * c**2 / hbar)**2
        
        I = sparse.eye(n_dof, format='csr')
        M = I / dt**2 - c**2 * L + mass_term * I
        
        return M