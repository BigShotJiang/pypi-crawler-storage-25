"""PDE equation implementations"""

from matrix_toolkit.pde.equations.poisson import PoissonEquation
from matrix_toolkit.pde.equations.heat import HeatEquation
from matrix_toolkit.pde.equations.wave import WaveEquation
from matrix_toolkit.pde.equations.convection_diffusion import ConvectionDiffusionEquation
from matrix_toolkit.pde.equations.helmholtz import HelmholtzEquation
from matrix_toolkit.pde.equations.stokes import StokesEquation
from matrix_toolkit.pde.equations.elasticity import ElasticityEquation
from matrix_toolkit.pde.equations.maxwell import MaxwellEquation
from matrix_toolkit.pde.equations.reaction_diffusion import (
    ReactionDiffusionEquation,
    FisherKPPEquation,
    GrayScottEquation
)
from matrix_toolkit.pde.equations.navier_stokes import NavierStokesEquation
from matrix_toolkit.pde.equations.advection_diffusion import AdvectionDiffusionEquation
from matrix_toolkit.pde.equations.burgers import BurgersEquation, Burgers2DEquation
from matrix_toolkit.pde.equations.schrodinger import SchrodingerEquation
from matrix_toolkit.pde.equations.klein_gordon import KleinGordonEquation

__all__ = [
    "PoissonEquation",
    "HeatEquation",
    "WaveEquation",
    "ConvectionDiffusionEquation",
    "HelmholtzEquation",
    "StokesEquation",
    "ElasticityEquation",
    "MaxwellEquation",
    "ReactionDiffusionEquation",
    "FisherKPPEquation",
    "GrayScottEquation",
    "NavierStokesEquation",
    "AdvectionDiffusionEquation",
    "BurgersEquation",
    "Burgers2DEquation",
    "SchrodingerEquation",
    "KleinGordonEquation",
]