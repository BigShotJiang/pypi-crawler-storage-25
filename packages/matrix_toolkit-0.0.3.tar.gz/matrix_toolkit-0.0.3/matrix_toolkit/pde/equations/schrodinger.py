"""
Schrödinger equation
"""

import numpy as np
from scipy import sparse
from typing import Dict, Any, Callable, Optional

from matrix_toolkit.pde.base import BasePDEEquation


class SchrodingerEquation(BasePDEEquation):
    """
    Time-dependent Schrödinger equation
    
    iℏ ∂ψ/∂t = -ℏ²/(2m) ∇²ψ + V(x)ψ
    
    In dimensionless form (ℏ=m=1):
    i ∂ψ/∂t = -1/2 ∇²ψ + V(x)ψ
    
    Examples:
        >>> config = PDEConfig(
        ...     dimension=1,
        ...     mesh_size=512,
        ...     coefficients={
        ...         'potential': 'harmonic',  # V(x) = x²/2
        ...         'dt': 0.001
        ...     }
        ... )
        >>> eq = SchrodingerEquation(config)
        >>> H = eq.generate_matrix()  # Hamiltonian
    """
    
    def get_operator_name(self) -> str:
        return "Schrodinger"
    
    def get_default_coefficients(self) -> Dict[str, Any]:
        return {
            'hbar': 1.0,            # Reduced Planck constant
            'mass': 1.0,            # Particle mass
            'potential': 'free',    # Potential type: 'free', 'harmonic', 'barrier', 'well'
            'potential_strength': 1.0,
            'dt': 0.001,
        }
    
    def generate_matrix(self) -> sparse.spmatrix:
        """
        Generate Hamiltonian matrix H = -∇²/(2m) + V
        
        For time evolution: ψ(t+dt) = exp(-iHdt)ψ(t)
        Using Crank-Nicolson: (I + iHdt/2)ψ^{n+1} = (I - iHdt/2)ψ^n
        """
        coeffs = self.config.coefficients or self.get_default_coefficients()
        
        if self.config.random_params:
            coeffs = self.randomize_coefficients(self.config.random_seed)
        
        hbar = coeffs.get('hbar', 1.0)
        m = coeffs.get('mass', 1.0)
        potential_type = coeffs.get('potential', 'free')
        V_strength = coeffs.get('potential_strength', 1.0)
        
        if self.config.dimension == 1:
            return self._generate_1d(hbar, m, potential_type, V_strength)
        elif self.config.dimension == 2:
            return self._generate_2d(hbar, m, potential_type, V_strength)
        elif self.config.dimension == 3:
            return self._generate_3d(hbar, m, potential_type, V_strength)
    
    def _generate_1d(
        self,
        hbar: float,
        m: float,
        potential_type: str,
        V_strength: float
    ) -> sparse.spmatrix:
        """Generate 1D Schrödinger Hamiltonian"""
        from matrix_toolkit.pde.dim1d.generators import generate_1d_laplacian
        
        n = self.config.mesh_size[0]
        h = self.config.get_mesh_spacing()[0]
        
        # Kinetic energy: -ℏ²/(2m) ∇²
        T = -(hbar**2) / (2 * m) * generate_1d_laplacian(n, h)
        
        # Potential energy V(x)
        x = np.linspace(
            self.config.domain[0] + h,
            self.config.domain[1] - h,
            n
        )
        V = self._get_potential_1d(x, potential_type, V_strength)
        V_matrix = sparse.diags([V], [0], format='csr')
        
        # Hamiltonian
        H = T + V_matrix
        
        return H
    
    def _get_potential_1d(
        self,
        x: np.ndarray,
        potential_type: str,
        strength: float
    ) -> np.ndarray:
        """Get 1D potential function"""
        if potential_type == 'free':
            return np.zeros_like(x)
        
        elif potential_type == 'harmonic':
            # Harmonic oscillator: V(x) = kx²/2
            return strength * x**2 / 2
        
        elif potential_type == 'barrier':
            # Potential barrier
            V = np.zeros_like(x)
            center = (x.max() + x.min()) / 2
            width = (x.max() - x.min()) / 10
            mask = np.abs(x - center) < width
            V[mask] = strength
            return V
        
        elif potential_type == 'well':
            # Potential well
            V = strength * np.ones_like(x)
            center = (x.max() + x.min()) / 2
            width = (x.max() - x.min()) / 4
            mask = np.abs(x - center) < width
            V[mask] = 0
            return V
        
        else:
            return np.zeros_like(x)
    
    def _generate_2d(
        self,
        hbar: float,
        m: float,
        potential_type: str,
        V_strength: float
    ) -> sparse.spmatrix:
        """Generate 2D Schrödinger Hamiltonian"""
        from matrix_toolkit.pde.dim2d.generators import generate_2d_laplacian
        
        nx, ny = self.config.mesh_size
        hx, hy = self.config.get_mesh_spacing()
        
        # Kinetic energy
        T = -(hbar**2) / (2 * m) * generate_2d_laplacian(nx, ny, hx, hy)
        
        # Potential (example: 2D harmonic oscillator)
        x = np.linspace(self.config.domain[0]+hx, self.config.domain[1]-hx, nx)
        y = np.linspace(self.config.domain[2]+hy, self.config.domain[3]-hy, ny)
        X, Y = np.meshgrid(x, y, indexing='ij')
        
        if potential_type == 'harmonic':
            V = V_strength * (X**2 + Y**2) / 2
        else:
            V = np.zeros((nx, ny))
        
        V_matrix = sparse.diags([V.flatten()], [0], format='csr')
        
        H = T + V_matrix
        
        return H
    
    def _generate_3d(
        self,
        hbar: float,
        m: float,
        potential_type: str,
        V_strength: float
    ) -> sparse.spmatrix:
        """Generate 3D Schrödinger Hamiltonian"""
        from matrix_toolkit.pde.dim3d.generators import generate_3d_laplacian
        
        nx, ny, nz = self.config.mesh_size
        hx, hy, hz = self.config.get_mesh_spacing()
        
        # Kinetic energy
        T = -(hbar**2) / (2 * m) * generate_3d_laplacian(nx, ny, nz, hx, hy, hz)
        
        # Potential
        x = np.linspace(self.config.domain[0]+hx, self.config.domain[1]-hx, nx)
        y = np.linspace(self.config.domain[2]+hy, self.config.domain[3]-hy, ny)
        z = np.linspace(self.config.domain[4]+hz, self.config.domain[5]-hz, nz)
        X, Y, Z = np.meshgrid(x, y, z, indexing='ij')
        
        if potential_type == 'harmonic':
            V = V_strength * (X**2 + Y**2 + Z**2) / 2
        else:
            V = np.zeros((nx, ny, nz))
        
        V_matrix = sparse.diags([V.flatten()], [0], format='csr')
        
        H = T + V_matrix
        
        return H