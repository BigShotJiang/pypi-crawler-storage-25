"""
Burgers equation (nonlinear wave equation)
"""

import numpy as np
from scipy import sparse
from typing import Dict, Any

from matrix_toolkit.pde.base import BasePDEEquation


class BurgersEquation(BasePDEEquation):
    """
    Burgers equation: ∂u/∂t + u∂u/∂x = ν∂²u/∂x²
    
    Linearized form: ∂u/∂t + u₀∂u/∂x + u∂u₀/∂x = ν∂²u/∂x²
    
    Models shock wave formation, turbulence
    
    Examples:
        >>> config = PDEConfig(
        ...     dimension=1,
        ...     mesh_size=256,
        ...     coefficients={
        ...         'viscosity': 0.01,
        ...         'dt': 0.001
        ...     }
        ... )
        >>> eq = BurgersEquation(config)
        >>> M = eq.generate_matrix()
    """
    
    def get_operator_name(self) -> str:
        return "Burgers"
    
    def get_default_coefficients(self) -> Dict[str, Any]:
        return {
            'viscosity': 0.01,      # Viscosity ν
            'dt': 0.001,            # Time step
            'theta': 0.5,           # Time discretization
            'u0': 0.0,              # Background velocity for linearization
        }
    
    def generate_matrix(self) -> sparse.spmatrix:
        """Generate Burgers equation matrix (linearized)"""
        if self.config.dimension != 1:
            raise ValueError("Burgers equation implemented for 1D only")
        
        coeffs = self.config.coefficients or self.get_default_coefficients()
        
        if self.config.random_params:
            coeffs = self.randomize_coefficients(self.config.random_seed)
        
        nu = coeffs.get('viscosity', 0.01)
        dt = coeffs.get('dt', 0.001)
        theta = coeffs.get('theta', 0.5)
        u0 = coeffs.get('u0', 0.0)
        
        return self._generate_1d(nu, dt, theta, u0)
    
    def _generate_1d(
        self,
        nu: float,
        dt: float,
        theta: float,
        u0: float
    ) -> sparse.spmatrix:
        """Generate 1D Burgers matrix"""
        from matrix_toolkit.pde.dim1d.generators import generate_1d_laplacian
        
        n = self.config.mesh_size[0]
        h = self.config.get_mesh_spacing()[0]
        
        # Viscous term: ν∂²/∂x²
        L = nu * generate_1d_laplacian(n, h)
        
        # Convection term: u₀∂/∂x (linearized)
        Dx = sparse.diags(
            [-np.ones(n-1), np.ones(n-1)],
            [0, 1],
            shape=(n, n)
        ) / (2 * h)
        
        C = u0 * Dx
        
        # Time stepping: (I/dt - θ(νL - C)) u^{n+1} = ...
        I = sparse.eye(n, format='csr')
        M = I / dt - theta * (L - C)
        
        return M


class Burgers2DEquation(BasePDEEquation):
    """
    2D Burgers equation
    
    ∂u/∂t + u∂u/∂x + v∂u/∂y = ν∇²u
    ∂v/∂t + u∂v/∂x + v∂v/∂y = ν∇²v
    """
    
    def get_operator_name(self) -> str:
        return "Burgers2D"
    
    def get_default_coefficients(self) -> Dict[str, Any]:
        return {
            'viscosity': 0.01,
            'dt': 0.001,
            'theta': 0.5,
            'u0': 0.0,
            'v0': 0.0,
        }
    
    def generate_matrix(self) -> sparse.spmatrix:
        """Generate 2D Burgers system"""
        if self.config.dimension != 2:
            raise ValueError("Burgers2D requires dimension=2")
        
        coeffs = self.config.coefficients or self.get_default_coefficients()
        
        nu = coeffs.get('viscosity', 0.01)
        dt = coeffs.get('dt', 0.001)
        theta = coeffs.get('theta', 0.5)
        u0 = coeffs.get('u0', 0.0)
        v0 = coeffs.get('v0', 0.0)
        
        return self._generate_2d(nu, dt, theta, u0, v0)
    
    def _generate_2d(
        self,
        nu: float,
        dt: float,
        theta: float,
        u0: float,
        v0: float
    ) -> sparse.spmatrix:
        """Generate 2D Burgers matrix"""
        from matrix_toolkit.pde.dim2d.generators import generate_2d_laplacian
        
        nx, ny = self.config.mesh_size
        hx, hy = self.config.get_mesh_spacing()
        n = nx * ny
        
        # Viscous term
        L = nu * generate_2d_laplacian(nx, ny, hx, hy)
        
        # Convection terms
        Dx = sparse.diags([-np.ones(nx-1), np.ones(nx-1)], [0, 1], shape=(nx, nx)) / (2*hx)
        Dx_2d = sparse.kron(Dx, sparse.eye(ny))
        
        Dy = sparse.diags([-np.ones(ny-1), np.ones(ny-1)], [0, 1], shape=(ny, ny)) / (2*hy)
        Dy_2d = sparse.kron(sparse.eye(nx), Dy)
        
        C = u0 * Dx_2d + v0 * Dy_2d
        
        # Time stepping for each component
        I = sparse.eye(n, format='csr')
        component_op = I / dt - theta * (L - C)
        
        # Block diagonal for u and v
        M = sparse.block_diag([component_op, component_op], format='csr')
        
        return M