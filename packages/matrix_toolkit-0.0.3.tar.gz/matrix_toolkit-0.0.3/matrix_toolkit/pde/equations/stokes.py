"""
Stokes equation for incompressible flow: -μ∇²u + ∇p = f, ∇·u = 0
"""

import numpy as np
from scipy import sparse
from typing import Dict, Any, Tuple

from matrix_toolkit.pde.base import BasePDEEquation


class StokesEquation(BasePDEEquation):
    """
    Stokes equations for incompressible viscous flow
    
    -μ∇²u + ∇p = f   (momentum)
    ∇·u = 0           (continuity/incompressibility)
    
    Results in a saddle-point system:
    [A   B^T] [u]   [f]
    [B    0 ] [p] = [0]
    
    where A = μ∇², B = ∇·
    
    Examples:
        >>> config = PDEConfig(
        ...     dimension=2,
        ...     mesh_size=32,
        ...     coefficients={'viscosity': 1.0}
        ... )
        >>> eq = StokesEquation(config)
        >>> A = eq.generate_matrix()  # Returns full saddle-point system
    """
    
    def get_operator_name(self) -> str:
        return "Stokes"
    
    def get_default_coefficients(self) -> Dict[str, Any]:
        return {
            'viscosity': 1.0,  # Dynamic viscosity μ
        }
    
    def generate_matrix(self) -> sparse.spmatrix:
        """
        Generate Stokes saddle-point system matrix
        
        Returns:
            Block matrix [[A, B^T], [B, 0]]
        """
        coeffs = self.config.coefficients or self.get_default_coefficients()
        
        if self.config.random_params:
            coeffs = self.randomize_coefficients(self.config.random_seed)
        
        mu = coeffs.get('viscosity', 1.0)
        
        if self.config.dimension == 2:
            return self._generate_2d(mu)
        elif self.config.dimension == 3:
            return self._generate_3d(mu)
        else:
            raise ValueError("Stokes equation only supported in 2D and 3D")
    
    def _generate_2d(self, mu: float) -> sparse.spmatrix:
        """Generate 2D Stokes system"""
        from matrix_toolkit.pde.dim2d.generators import generate_2d_laplacian
        
        nx, ny = self.config.mesh_size
        hx, hy = self.config.get_mesh_spacing()
        
        # Number of velocity DOFs (2 components)
        n_vel = nx * ny * 2
        # Number of pressure DOFs
        n_pres = nx * ny
        
        # Velocity Laplacian (block diagonal for u and v components)
        L = generate_2d_laplacian(nx, ny, hx, hy)
        A = mu * sparse.block_diag([L, L], format='csr')
        
        # Divergence operator B = [∂/∂x, ∂/∂y]
        B = self._build_divergence_2d(nx, ny, hx, hy)
        
        # Saddle-point system
        # [A   B^T]
        # [B    0 ]
        zero_block = sparse.csr_matrix((n_pres, n_pres))
        
        top = sparse.hstack([A, B.T])
        bottom = sparse.hstack([B, zero_block])
        
        system = sparse.vstack([top, bottom], format='csr')
        
        return system
    
    def _build_divergence_2d(
        self,
        nx: int,
        ny: int,
        hx: float,
        hy: float
    ) -> sparse.spmatrix:
        """
        Build 2D divergence operator: ∂u/∂x + ∂v/∂y
        
        Returns:
            Sparse matrix B of shape (nx*ny, 2*nx*ny)
        """
        n = nx * ny
        
        # ∂/∂x operator (for u component)
        Dx = sparse.diags(
            [-np.ones(nx-1), np.ones(nx-1)],
            [0, 1],
            shape=(nx, nx)
        ) / hx
        Dx_2d = sparse.kron(Dx, sparse.eye(ny))
        
        # ∂/∂y operator (for v component)
        Dy = sparse.diags(
            [-np.ones(ny-1), np.ones(ny-1)],
            [0, 1],
            shape=(ny, ny)
        ) / hy
        Dy_2d = sparse.kron(sparse.eye(nx), Dy)
        
        # B = [∂/∂x, ∂/∂y]
        B = sparse.hstack([Dx_2d, Dy_2d], format='csr')
        
        return B
    
    def _generate_3d(self, mu: float) -> sparse.spmatrix:
        """Generate 3D Stokes system"""
        from matrix_toolkit.pde.dim3d.generators import generate_3d_laplacian
        
        nx, ny, nz = self.config.mesh_size
        hx, hy, hz = self.config.get_mesh_spacing()
        
        # Velocity DOFs (3 components: u, v, w)
        n_vel = nx * ny * nz * 3
        # Pressure DOFs
        n_pres = nx * ny * nz
        
        # Velocity Laplacian
        L = generate_3d_laplacian(nx, ny, nz, hx, hy, hz)
        A = mu * sparse.block_diag([L, L, L], format='csr')
        
        # Divergence operator
        B = self._build_divergence_3d(nx, ny, nz, hx, hy, hz)
        
        # Saddle-point system
        zero_block = sparse.csr_matrix((n_pres, n_pres))
        
        top = sparse.hstack([A, B.T])
        bottom = sparse.hstack([B, zero_block])
        
        system = sparse.vstack([top, bottom], format='csr')
        
        return system
    
    def _build_divergence_3d(
        self,
        nx: int,
        ny: int,
        nz: int,
        hx: float,
        hy: float,
        hz: float
    ) -> sparse.spmatrix:
        """Build 3D divergence operator: ∂u/∂x + ∂v/∂y + ∂w/∂z"""
        n = nx * ny * nz
        
        # ∂/∂x
        Dx = sparse.diags([-np.ones(nx-1), np.ones(nx-1)], [0, 1], shape=(nx, nx)) / hx
        Dx_3d = sparse.kron(sparse.kron(Dx, sparse.eye(ny)), sparse.eye(nz))
        
        # ∂/∂y
        Dy = sparse.diags([-np.ones(ny-1), np.ones(ny-1)], [0, 1], shape=(ny, ny)) / hy
        Dy_3d = sparse.kron(sparse.kron(sparse.eye(nx), Dy), sparse.eye(nz))
        
        # ∂/∂z
        Dz = sparse.diags([-np.ones(nz-1), np.ones(nz-1)], [0, 1], shape=(nz, nz)) / hz
        Dz_3d = sparse.kron(sparse.kron(sparse.eye(nx), sparse.eye(ny)), Dz)
        
        # B = [∂/∂x, ∂/∂y, ∂/∂z]
        B = sparse.hstack([Dx_3d, Dy_3d, Dz_3d], format='csr')
        
        return B