"""
Reaction-diffusion equations
"""

import numpy as np
from scipy import sparse
from typing import Dict, Any, Callable, Optional

from matrix_toolkit.pde.base import BasePDEEquation


class ReactionDiffusionEquation(BasePDEEquation):
    """
    Reaction-diffusion equation: ∂u/∂t = D∇²u + f(u)
    
    where f(u) is a reaction term (can be nonlinear)
    
    For linear case: f(u) = αu gives
    ∂u/∂t = D∇²u + αu
    
    Examples:
        >>> # Linear reaction-diffusion
        >>> config = PDEConfig(
        ...     dimension=2,
        ...     mesh_size=64,
        ...     coefficients={
        ...         'diffusion': 1.0,
        ...         'reaction': -0.1,  # decay
        ...         'dt': 0.01
        ...     }
        ... )
        >>> eq = ReactionDiffusionEquation(config)
        >>> M = eq.generate_matrix()
    """
    
    def get_operator_name(self) -> str:
        return "ReactionDiffusion"
    
    def get_default_coefficients(self) -> Dict[str, Any]:
        return {
            'diffusion': 1.0,      # Diffusion coefficient D
            'reaction': 0.0,       # Linear reaction coefficient α
            'dt': 0.01,            # Time step
            'theta': 0.5,          # Time discretization (0.5 = Crank-Nicolson)
        }
    
    def generate_matrix(self) -> sparse.spmatrix:
        """Generate reaction-diffusion system matrix"""
        coeffs = self.config.coefficients or self.get_default_coefficients()
        
        if self.config.random_params:
            coeffs = self.randomize_coefficients(self.config.random_seed)
        
        D = coeffs.get('diffusion', 1.0)
        alpha = coeffs.get('reaction', 0.0)
        dt = coeffs.get('dt', 0.01)
        theta = coeffs.get('theta', 0.5)
        
        # Get Laplacian
        from matrix_toolkit.pde.equations.poisson import PoissonEquation
        
        laplacian_config = type(self.config)(
            dimension=self.config.dimension,
            domain=self.config.domain,
            mesh_size=self.config.mesh_size,
            boundary_condition=self.config.boundary_condition
        )
        
        poisson = PoissonEquation(laplacian_config)
        L = poisson.generate_matrix()
        
        # Identity and reaction term
        n = self.config.total_dofs()
        I = sparse.eye(n, format='csr')
        R = alpha * I
        
        # Reaction-diffusion operator
        # (I - θ dt (D L + R)) u^{n+1} = (I + (1-θ) dt (D L + R)) u^n
        operator = D * L + R
        M = I - theta * dt * operator
        
        return M
    
    def generate_rhs_matrix(self) -> sparse.spmatrix:
        """Generate RHS matrix for explicit part"""
        coeffs = self.config.coefficients or self.get_default_coefficients()
        
        D = coeffs.get('diffusion', 1.0)
        alpha = coeffs.get('reaction', 0.0)
        dt = coeffs.get('dt', 0.01)
        theta = coeffs.get('theta', 0.5)
        
        from matrix_toolkit.pde.equations.poisson import PoissonEquation
        
        laplacian_config = type(self.config)(
            dimension=self.config.dimension,
            domain=self.config.domain,
            mesh_size=self.config.mesh_size,
            boundary_condition=self.config.boundary_condition
        )
        
        poisson = PoissonEquation(laplacian_config)
        L = poisson.generate_matrix()
        
        n = self.config.total_dofs()
        I = sparse.eye(n, format='csr')
        R = alpha * I
        
        operator = D * L + R
        RHS = I + (1 - theta) * dt * operator
        
        return RHS


class FisherKPPEquation(ReactionDiffusionEquation):
    """
    Fisher-KPP equation: ∂u/∂t = D∇²u + ru(1-u)
    
    Models population dynamics with logistic growth
    """
    
    def get_operator_name(self) -> str:
        return "FisherKPP"
    
    def get_default_coefficients(self) -> Dict[str, Any]:
        coeffs = super().get_default_coefficients()
        coeffs['growth_rate'] = 1.0  # r in ru(1-u)
        return coeffs


class GrayScottEquation(BasePDEEquation):
    """
    Gray-Scott model (two-species reaction-diffusion)
    
    ∂u/∂t = Du∇²u - uv² + F(1-u)
    ∂v/∂t = Dv∇²v + uv² - (F+k)v
    
    Models pattern formation
    """
    
    def get_operator_name(self) -> str:
        return "GrayScott"
    
    def get_default_coefficients(self) -> Dict[str, Any]:
        return {
            'diffusion_u': 2e-5,
            'diffusion_v': 1e-5,
            'feed_rate': 0.055,    # F
            'kill_rate': 0.062,    # k
            'dt': 1.0,
        }
    
    def generate_matrix(self) -> sparse.spmatrix:
        """
        Generate Gray-Scott system matrix
        
        Returns block matrix for [u, v] system
        """
        coeffs = self.config.coefficients or self.get_default_coefficients()
        
        Du = coeffs.get('diffusion_u', 2e-5)
        Dv = coeffs.get('diffusion_v', 1e-5)
        F = coeffs.get('feed_rate', 0.055)
        k = coeffs.get('kill_rate', 0.062)
        dt = coeffs.get('dt', 1.0)
        
        # Get Laplacian
        from matrix_toolkit.pde.equations.poisson import PoissonEquation
        
        laplacian_config = type(self.config)(
            dimension=self.config.dimension,
            domain=self.config.domain,
            mesh_size=self.config.mesh_size,
            boundary_condition=self.config.boundary_condition
        )
        
        poisson = PoissonEquation(laplacian_config)
        L = poisson.generate_matrix()
        
        n = self.config.total_dofs()
        I = sparse.eye(n, format='csr')
        
        # Linear part only (for implicit time stepping)
        # Nonlinear reaction terms handled in RHS
        
        # For u: (I - dt Du L + dt F I)
        A_u = I - dt * Du * L + dt * F * I
        
        # For v: (I - dt Dv L + dt (F+k) I)
        A_v = I - dt * Dv * L + dt * (F + k) * I
        
        # Block diagonal system
        A = sparse.block_diag([A_u, A_v], format='csr')
        
        return A