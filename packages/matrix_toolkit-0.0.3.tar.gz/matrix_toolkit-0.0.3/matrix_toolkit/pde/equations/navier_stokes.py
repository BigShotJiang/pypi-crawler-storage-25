"""
Navier-Stokes equations for incompressible viscous flow
"""

import numpy as np
from scipy import sparse
from typing import Dict, Any, Optional

from matrix_toolkit.pde.base import BasePDEEquation


class NavierStokesEquation(BasePDEEquation):
    """
    Incompressible Navier-Stokes equations
    
    ∂u/∂t + (u·∇)u = -∇p + ν∇²u + f    (momentum)
    ∇·u = 0                              (continuity)
    
    Linearized around a steady state u₀:
    ∂u/∂t + (u₀·∇)u + (u·∇)u₀ = -∇p + ν∇²u + f
    
    For steady Stokes (Re→0): same as StokesEquation
    For unsteady: time-stepping scheme needed
    
    Examples:
        >>> config = PDEConfig(
        ...     dimension=2,
        ...     mesh_size=64,
        ...     coefficients={
        ...         'viscosity': 0.01,
        ...         'dt': 0.01,
        ...         'velocity_x0': 1.0,  # Background flow
        ...         'velocity_y0': 0.0
        ...     }
        ... )
        >>> eq = NavierStokesEquation(config)
        >>> A = eq.generate_matrix()
    """
    
    def get_operator_name(self) -> str:
        return "NavierStokes"
    
    def get_default_coefficients(self) -> Dict[str, Any]:
        return {
            'viscosity': 0.01,      # Kinematic viscosity ν
            'dt': 0.01,             # Time step
            'theta': 0.5,           # Time discretization
            'velocity_x0': 0.0,     # Background velocity x-component
            'velocity_y0': 0.0,     # Background velocity y-component
            'velocity_z0': 0.0,     # Background velocity z-component (3D)
        }
    
    def generate_matrix(self) -> sparse.spmatrix:
        """
        Generate linearized Navier-Stokes system matrix
        
        Returns saddle-point system like Stokes, but with convection term
        """
        coeffs = self.config.coefficients or self.get_default_coefficients()
        
        if self.config.random_params:
            coeffs = self.randomize_coefficients(self.config.random_seed)
        
        nu = coeffs.get('viscosity', 0.01)
        dt = coeffs.get('dt', 0.01)
        theta = coeffs.get('theta', 0.5)
        
        if self.config.dimension == 2:
            u0 = (coeffs.get('velocity_x0', 0.0), coeffs.get('velocity_y0', 0.0))
            return self._generate_2d(nu, dt, theta, u0)
        elif self.config.dimension == 3:
            u0 = (
                coeffs.get('velocity_x0', 0.0),
                coeffs.get('velocity_y0', 0.0),
                coeffs.get('velocity_z0', 0.0)
            )
            return self._generate_3d(nu, dt, theta, u0)
        else:
            raise ValueError("Navier-Stokes only supported in 2D and 3D")
    
    def _generate_2d(
        self,
        nu: float,
        dt: float,
        theta: float,
        u0: tuple
    ) -> sparse.spmatrix:
        """
        Generate 2D Navier-Stokes system
        
        Linearized convection term: (u0·∇)u
        """
        from matrix_toolkit.pde.dim2d.generators import generate_2d_laplacian
        
        nx, ny = self.config.mesh_size
        hx, hy = self.config.get_mesh_spacing()
        n = nx * ny
        
        # Viscous term (Laplacian)
        L = generate_2d_laplacian(nx, ny, hx, hy)
        
        # Convection term with background velocity u0
        u0x, u0y = u0
        C = self._build_convection_2d(nx, ny, hx, hy, u0x, u0y)
        
        # Identity
        I = sparse.eye(n, format='csr')
        
        # Time stepping: (I/dt - θ(νL - C)) u^{n+1} = ...
        # For velocity components (block diagonal)
        velocity_operator = I / dt - theta * (nu * L - C)
        A_vel = sparse.block_diag([velocity_operator, velocity_operator], format='csr')
        
        # Divergence operator (same as Stokes)
        B = self._build_divergence_2d(nx, ny, hx, hy)
        
        # Saddle-point system
        n_vel = 2 * n
        n_pres = n
        zero_block = sparse.csr_matrix((n_pres, n_pres))
        
        top = sparse.hstack([A_vel, B.T])
        bottom = sparse.hstack([B, zero_block])
        
        system = sparse.vstack([top, bottom], format='csr')
        
        return system
    
    def _build_convection_2d(
        self,
        nx: int,
        ny: int,
        hx: float,
        hy: float,
        u0x: float,
        u0y: float
    ) -> sparse.spmatrix:
        """
        Build 2D convection operator: (u0·∇)
        
        (u0x ∂/∂x + u0y ∂/∂y)
        """
        # ∂/∂x operator
        Dx = sparse.diags(
            [-np.ones(nx-1), np.ones(nx-1)],
            [0, 1],
            shape=(nx, nx)
        ) / (2 * hx)
        Dx_2d = sparse.kron(Dx, sparse.eye(ny))
        
        # ∂/∂y operator
        Dy = sparse.diags(
            [-np.ones(ny-1), np.ones(ny-1)],
            [0, 1],
            shape=(ny, ny)
        ) / (2 * hy)
        Dy_2d = sparse.kron(sparse.eye(nx), Dy)
        
        # Convection: u0x ∂/∂x + u0y ∂/∂y
        C = u0x * Dx_2d + u0y * Dy_2d
        
        return C
    
    def _build_divergence_2d(
        self,
        nx: int,
        ny: int,
        hx: float,
        hy: float
    ) -> sparse.spmatrix:
        """Build 2D divergence operator"""
        n = nx * ny
        
        Dx = sparse.diags([-np.ones(nx-1), np.ones(nx-1)], [0, 1], shape=(nx, nx)) / hx
        Dx_2d = sparse.kron(Dx, sparse.eye(ny))
        
        Dy = sparse.diags([-np.ones(ny-1), np.ones(ny-1)], [0, 1], shape=(ny, ny)) / hy
        Dy_2d = sparse.kron(sparse.eye(nx), Dy)
        
        B = sparse.hstack([Dx_2d, Dy_2d], format='csr')
        
        return B
    
    def _generate_3d(
        self,
        nu: float,
        dt: float,
        theta: float,
        u0: tuple
    ) -> sparse.spmatrix:
        """Generate 3D Navier-Stokes system"""
        from matrix_toolkit.pde.dim3d.generators import generate_3d_laplacian
        
        nx, ny, nz = self.config.mesh_size
        hx, hy, hz = self.config.get_mesh_spacing()
        n = nx * ny * nz
        
        # Viscous term
        L = generate_3d_laplacian(nx, ny, nz, hx, hy, hz)
        
        # Convection term
        u0x, u0y, u0z = u0
        C = self._build_convection_3d(nx, ny, nz, hx, hy, hz, u0x, u0y, u0z)
        
        # Time stepping
        I = sparse.eye(n, format='csr')
        velocity_operator = I / dt - theta * (nu * L - C)
        A_vel = sparse.block_diag(
            [velocity_operator, velocity_operator, velocity_operator],
            format='csr'
        )
        
        # Divergence
        B = self._build_divergence_3d(nx, ny, nz, hx, hy, hz)
        
        # Saddle-point system
        n_vel = 3 * n
        n_pres = n
        zero_block = sparse.csr_matrix((n_pres, n_pres))
        
        top = sparse.hstack([A_vel, B.T])
        bottom = sparse.hstack([B, zero_block])
        
        system = sparse.vstack([top, bottom], format='csr')
        
        return system
    
    def _build_convection_3d(
        self,
        nx: int, ny: int, nz: int,
        hx: float, hy: float, hz: float,
        u0x: float, u0y: float, u0z: float
    ) -> sparse.spmatrix:
        """Build 3D convection operator"""
        Dx = sparse.diags([-np.ones(nx-1), np.ones(nx-1)], [0, 1], shape=(nx, nx)) / (2*hx)
        Dx_3d = sparse.kron(sparse.kron(Dx, sparse.eye(ny)), sparse.eye(nz))
        
        Dy = sparse.diags([-np.ones(ny-1), np.ones(ny-1)], [0, 1], shape=(ny, ny)) / (2*hy)
        Dy_3d = sparse.kron(sparse.kron(sparse.eye(nx), Dy), sparse.eye(nz))
        
        Dz = sparse.diags([-np.ones(nz-1), np.ones(nz-1)], [0, 1], shape=(nz, nz)) / (2*hz)
        Dz_3d = sparse.kron(sparse.kron(sparse.eye(nx), sparse.eye(ny)), Dz)
        
        C = u0x * Dx_3d + u0y * Dy_3d + u0z * Dz_3d
        
        return C
    
    def _build_divergence_3d(
        self,
        nx: int, ny: int, nz: int,
        hx: float, hy: float, hz: float
    ) -> sparse.spmatrix:
        """Build 3D divergence operator"""
        Dx = sparse.diags([-np.ones(nx-1), np.ones(nx-1)], [0, 1], shape=(nx, nx)) / hx
        Dx_3d = sparse.kron(sparse.kron(Dx, sparse.eye(ny)), sparse.eye(nz))
        
        Dy = sparse.diags([-np.ones(ny-1), np.ones(ny-1)], [0, 1], shape=(ny, ny)) / hy
        Dy_3d = sparse.kron(sparse.kron(sparse.eye(nx), Dy), sparse.eye(nz))
        
        Dz = sparse.diags([-np.ones(nz-1), np.ones(nz-1)], [0, 1], shape=(nz, nz)) / hz
        Dz_3d = sparse.kron(sparse.kron(sparse.eye(nx), sparse.eye(ny)), Dz)
        
        B = sparse.hstack([Dx_3d, Dy_3d, Dz_3d], format='csr')
        
        return B