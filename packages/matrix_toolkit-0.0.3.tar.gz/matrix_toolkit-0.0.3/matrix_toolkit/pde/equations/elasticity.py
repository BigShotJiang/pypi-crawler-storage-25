"""
Linear elasticity equations
"""

import numpy as np
from scipy import sparse
from typing import Dict, Any

from matrix_toolkit.pde.base import BasePDEEquation


class ElasticityEquation(BasePDEEquation):
    """
    Linear elasticity equations
    
    -∇·σ(u) = f
    
    where σ is the stress tensor:
    σ = λ(∇·u)I + μ(∇u + ∇u^T)
    
    λ, μ are Lamé parameters related to Young's modulus E and Poisson's ratio ν:
    λ = Eν/((1+ν)(1-2ν))
    μ = E/(2(1+ν))
    
    Examples:
        >>> config = PDEConfig(
        ...     dimension=2,
        ...     mesh_size=32,
        ...     coefficients={
        ...         'youngs_modulus': 1.0,
        ...         'poisson_ratio': 0.3
        ...     }
        ... )
        >>> eq = ElasticityEquation(config)
        >>> A = eq.generate_matrix()
    """
    
    def get_operator_name(self) -> str:
        return "Elasticity"
    
    def get_default_coefficients(self) -> Dict[str, Any]:
        return {
            'youngs_modulus': 1.0,    # E
            'poisson_ratio': 0.3,     # ν
        }
    
    def _compute_lame_parameters(self, E: float, nu: float) -> tuple:
        """Compute Lamé parameters from Young's modulus and Poisson's ratio"""
        lmbda = E * nu / ((1 + nu) * (1 - 2 * nu))
        mu = E / (2 * (1 + nu))
        return lmbda, mu
    
    def generate_matrix(self) -> sparse.spmatrix:
        """Generate elasticity system matrix"""
        coeffs = self.config.coefficients or self.get_default_coefficients()
        
        if self.config.random_params:
            coeffs = self.randomize_coefficients(self.config.random_seed)
        
        E = coeffs.get('youngs_modulus', 1.0)
        nu = coeffs.get('poisson_ratio', 0.3)
        
        lmbda, mu = self._compute_lame_parameters(E, nu)
        
        if self.config.dimension == 2:
            return self._generate_2d(lmbda, mu)
        elif self.config.dimension == 3:
            return self._generate_3d(lmbda, mu)
        else:
            raise ValueError("Elasticity equation only supported in 2D and 3D")
    
    def _generate_2d(self, lmbda: float, mu: float) -> sparse.spmatrix:
        """
        Generate 2D elasticity system
        
        Displacement vector: u = [ux, uy]
        Total DOFs: 2*nx*ny
        """
        from matrix_toolkit.pde.dim2d.generators import generate_2d_laplacian
        
        nx, ny = self.config.mesh_size
        hx, hy = self.config.get_mesh_spacing()
        n = nx * ny
        
        # Laplacian for each component
        L = generate_2d_laplacian(nx, ny, hx, hy)
        
        # Derivative operators
        # ∂/∂x
        Dx = sparse.diags(
            [-np.ones(nx-1), np.ones(nx-1)],
            [0, 1],
            shape=(nx, nx)
        ) / (2 * hx)
        Dx_2d = sparse.kron(Dx, sparse.eye(ny))
        
        # ∂/∂y
        Dy = sparse.diags(
            [-np.ones(ny-1), np.ones(ny-1)],
            [0, 1],
            shape=(ny, ny)
        ) / (2 * hy)
        Dy_2d = sparse.kron(sparse.eye(nx), Dy)
        
        # Build elasticity operator
        # A11 = -μ∇² - (λ+μ)∂²/∂x²
        A11 = -mu * L - (lmbda + mu) * (Dx_2d @ Dx_2d)
        
        # A22 = -μ∇² - (λ+μ)∂²/∂y²
        A22 = -mu * L - (lmbda + mu) * (Dy_2d @ Dy_2d)
        
        # A12 = -(λ+μ)∂²/∂x∂y
        A12 = -(lmbda + mu) * (Dx_2d @ Dy_2d)
        
        # A21 = A12^T (symmetry)
        A21 = A12.T
        
        # Assemble block matrix
        # [A11  A12]
        # [A21  A22]
        top = sparse.hstack([A11, A12])
        bottom = sparse.hstack([A21, A22])
        A = sparse.vstack([top, bottom], format='csr')
        
        return A
    
    def _generate_3d(self, lmbda: float, mu: float) -> sparse.spmatrix:
        """
        Generate 3D elasticity system
        
        Displacement vector: u = [ux, uy, uz]
        Total DOFs: 3*nx*ny*nz
        """
        from matrix_toolkit.pde.dim3d.generators import generate_3d_laplacian
        
        nx, ny, nz = self.config.mesh_size
        hx, hy, hz = self.config.get_mesh_spacing()
        n = nx * ny * nz
        
        # Laplacian
        L = generate_3d_laplacian(nx, ny, nz, hx, hy, hz)
        
        # Derivative operators
        Dx = sparse.diags([-np.ones(nx-1), np.ones(nx-1)], [0, 1], shape=(nx, nx)) / (2*hx)
        Dx_3d = sparse.kron(sparse.kron(Dx, sparse.eye(ny)), sparse.eye(nz))
        
        Dy = sparse.diags([-np.ones(ny-1), np.ones(ny-1)], [0, 1], shape=(ny, ny)) / (2*hy)
        Dy_3d = sparse.kron(sparse.kron(sparse.eye(nx), Dy), sparse.eye(nz))
        
        Dz = sparse.diags([-np.ones(nz-1), np.ones(nz-1)], [0, 1], shape=(nz, nz)) / (2*hz)
        Dz_3d = sparse.kron(sparse.kron(sparse.eye(nx), sparse.eye(ny)), Dz)
        
        # Build 3x3 block matrix
        # Diagonal blocks
        A11 = -mu * L - (lmbda + mu) * (Dx_3d @ Dx_3d)
        A22 = -mu * L - (lmbda + mu) * (Dy_3d @ Dy_3d)
        A33 = -mu * L - (lmbda + mu) * (Dz_3d @ Dz_3d)
        
        # Off-diagonal blocks
        A12 = -(lmbda + mu) * (Dx_3d @ Dy_3d)
        A13 = -(lmbda + mu) * (Dx_3d @ Dz_3d)
        A23 = -(lmbda + mu) * (Dy_3d @ Dz_3d)
        
        A21 = A12.T
        A31 = A13.T
        A32 = A23.T
        
        # Assemble
        row1 = sparse.hstack([A11, A12, A13])
        row2 = sparse.hstack([A21, A22, A23])
        row3 = sparse.hstack([A31, A32, A33])
        
        A = sparse.vstack([row1, row2, row3], format='csr')
        
        return A