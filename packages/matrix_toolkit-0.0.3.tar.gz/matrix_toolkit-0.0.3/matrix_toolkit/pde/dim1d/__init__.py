"""1D PDE matrix generators"""

from matrix_toolkit.pde.dim1d.generators import (
    generate_1d_laplacian,
    generate_1d_convection_diffusion,
    generate_1d_heat,
    generate_1d_wave,
    generate_1d_helmholtz,
    generate_1d_biharmonic,
)

__all__ = [
    "generate_1d_laplacian",
    "generate_1d_convection_diffusion",
    "generate_1d_heat",
    "generate_1d_wave",
    "generate_1d_helmholtz",
    "generate_1d_biharmonic",
]