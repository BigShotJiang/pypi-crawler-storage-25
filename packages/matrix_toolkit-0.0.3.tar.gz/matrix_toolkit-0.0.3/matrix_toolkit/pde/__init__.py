"""
PDE Matrix Generation Module

Generate matrices from discretized partial differential equations
in 1D, 2D, and 3D with customizable parameters and output formats.
"""

from matrix_toolkit.pde.base import PDEMatrixGenerator
from matrix_toolkit.pde.config import PDEConfig, BoundaryCondition
from matrix_toolkit.pde.equations import (
    PoissonEquation,
    HeatEquation,
    WaveEquation,
    ConvectionDiffusionEquation,
    HelmholtzEquation
)

__all__ = [
    "PDEMatrixGenerator",
    "PDEConfig",
    "BoundaryCondition",
    "PoissonEquation",
    "HeatEquation",
    "WaveEquation",
    "ConvectionDiffusionEquation",
    "HelmholtzEquation",
]