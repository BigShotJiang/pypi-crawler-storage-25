"""2D PDE matrix generators"""

from matrix_toolkit.pde.dim2d.generators import (
    generate_2d_laplacian,
    generate_2d_convection_diffusion,
    generate_2d_heat,
    generate_2d_wave,
    generate_2d_helmholtz,
    generate_2d_biharmonic,
)

__all__ = [
    "generate_2d_laplacian",
    "generate_2d_convection_diffusion",
    "generate_2d_heat",
    "generate_2d_wave",
    "generate_2d_helmholtz",
    "generate_2d_biharmonic",
]