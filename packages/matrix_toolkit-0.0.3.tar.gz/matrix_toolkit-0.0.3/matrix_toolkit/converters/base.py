"""Base converter class and factory"""

from abc import ABC, abstractmethod
from typing import Any, Optional


class BaseConverter(ABC):
    """Base class for matrix converters"""
    
    @abstractmethod
    def convert(self, matrix: Any, format: str = 'csr', dtype: Optional[str] = None) -> Any:
        """Convert matrix to target backend and format"""
        pass
    
    @abstractmethod
    def supported_formats(self) -> list:
        """Return list of supported sparse formats"""
        pass
    
    def _validate_format(self, format: str):
        """Validate that format is supported"""
        if format not in self.supported_formats():
            raise ValueError(
                f"Format '{format}' not supported. "
                f"Supported formats: {self.supported_formats()}"
            )


class ConverterFactory:
    """Factory for creating converters"""
    
    _converters = {}
    
    @classmethod
    def register_converter(cls, backend: str, converter_class):
        """Register a new converter"""
        cls._converters[backend] = converter_class
    
    @classmethod
    def get_converter(cls, backend: str) -> BaseConverter:
        """Get converter for specified backend"""
        # Lazy import to avoid hard dependencies
        if backend not in cls._converters:
            if backend == 'scipy':
                from matrix_toolkit.converters.scipy_converter import ScipyConverter
                cls._converters[backend] = ScipyConverter()
            elif backend == 'cupy':
                from matrix_toolkit.converters.cupy_converter import CupyConverter
                cls._converters[backend] = CupyConverter()
            elif backend == 'jax':
                from matrix_toolkit.converters.jax_converter import JaxConverter
                cls._converters[backend] = JaxConverter()
            elif backend == 'torch':
                from matrix_toolkit.converters.torch_converter import TorchConverter
                cls._converters[backend] = TorchConverter()
            elif backend == 'numpy':
                from matrix_toolkit.converters.numpy_converter import NumpyConverter
                cls._converters[backend] = NumpyConverter()
            else:
                raise ValueError(f"Unknown backend: {backend}")
        
        return cls._converters[backend]
    
    @classmethod
    def list_backends(cls) -> list:
        """List all available backends"""
        return ['scipy', 'cupy', 'jax', 'torch', 'numpy']