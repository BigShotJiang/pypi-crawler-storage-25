"""PyTorch sparse matrix converter"""

from typing import Any, Optional
import warnings
import numpy as np

from matrix_toolkit.converters.base import BaseConverter


class TorchConverter(BaseConverter):
    """Converter for PyTorch sparse matrices"""
    
    def __init__(self):
        try:
            import torch
            self.torch = torch
            self.available = True
        except ImportError:
            self.available = False
            warnings.warn("PyTorch not available. Install with: pip install torch")
    
    def supported_formats(self) -> list:
        return ['coo', 'csr', 'csc']
    
    def convert(self, matrix: Any, format: str = 'coo', dtype: Optional[str] = None) -> Any:
        """
        Convert matrix to PyTorch sparse format
        
        Args:
            matrix: Input matrix
            format: Target sparse format
            dtype: Target data type
        
        Returns:
            PyTorch sparse tensor
        """
        if not self.available:
            raise RuntimeError("PyTorch is not installed")
        
        self._validate_format(format)
        
        # Import scipy for conversion
        from scipy import sparse
        
        # Convert to scipy first if needed
        if not sparse.issparse(matrix):
            from matrix_toolkit.converters.scipy_converter import ScipyConverter
            scipy_conv = ScipyConverter()
            matrix = scipy_conv.convert(matrix, format='coo')
        
        # Convert to COO format for PyTorch
        if not isinstance(matrix, sparse.coo_matrix):
            matrix = sparse.coo_matrix(matrix)
        
        # Create PyTorch sparse tensor
        indices = self.torch.LongTensor(np.vstack([matrix.row, matrix.col]))
        values = self.torch.FloatTensor(matrix.data)
        shape = matrix.shape
        
        torch_matrix = self.torch.sparse_coo_tensor(
            indices, values, shape, dtype=self._get_torch_dtype(dtype)
        )
        
        # Convert to other formats if requested
        if format == 'csr':
            torch_matrix = torch_matrix.to_sparse_csr()
        elif format == 'csc':
            torch_matrix = torch_matrix.to_sparse_csc()
        
        return torch_matrix
    
    def _get_torch_dtype(self, dtype: Optional[str]):
        """Convert string dtype to torch dtype"""
        if dtype is None:
            return self.torch.float32
        
        dtype_map = {
            'float32': self.torch.float32,
            'float64': self.torch.float64,
            'float16': self.torch.float16,
            'int32': self.torch.int32,
            'int64': self.torch.int64,
            'int16': self.torch.int16,
            'int8': self.torch.int8,
            'uint8': self.torch.uint8,
        }
        
        return dtype_map.get(dtype, self.torch.float32)