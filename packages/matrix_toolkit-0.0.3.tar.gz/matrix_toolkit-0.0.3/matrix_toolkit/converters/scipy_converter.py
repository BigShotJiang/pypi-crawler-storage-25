"""SciPy sparse matrix converter"""

from typing import Any, Optional
import numpy as np
from scipy import sparse

from matrix_toolkit.converters.base import BaseConverter


class ScipyConverter(BaseConverter):
    """Converter for SciPy sparse matrices"""
    
    def supported_formats(self) -> list:
        return ['csr', 'csc', 'coo', 'dia', 'bsr', 'lil', 'dok']
    
    def convert(self, matrix: Any, format: str = 'csr', dtype: Optional[str] = None) -> Any:
        """
        Convert matrix to SciPy sparse format
        
        Args:
            matrix: Input matrix (any format that SciPy can handle)
            format: Target sparse format
            dtype: Target data type
        
        Returns:
            SciPy sparse matrix
        """
        self._validate_format(format)
        
        # Convert to scipy sparse if not already
        if not sparse.issparse(matrix):
            if isinstance(matrix, np.ndarray):
                matrix = sparse.csr_matrix(matrix)
            else:
                # Try to convert from other backends
                matrix = self._from_other_backend(matrix)
        
        # Convert to target format
        format_map = {
            'csr': sparse.csr_matrix,
            'csc': sparse.csc_matrix,
            'coo': sparse.coo_matrix,
            'dia': sparse.dia_matrix,
            'bsr': sparse.bsr_matrix,
            'lil': sparse.lil_matrix,
            'dok': sparse.dok_matrix,
        }
        
        converted = format_map[format](matrix)
        
        # Convert dtype if specified
        if dtype is not None:
            converted = converted.astype(dtype)
        
        return converted
    
    def _from_other_backend(self, matrix: Any):
        """Convert from other backend to scipy"""
        # Try CuPy
        try:
            import cupy as cp
            if hasattr(cp.sparse, 'issparse') and cp.sparse.issparse(matrix):
                return matrix.get()  # Transfer from GPU to CPU
        except ImportError:
            pass
        
        # Try JAX
        try:
            import jax.experimental.sparse as jsparse
            if hasattr(matrix, 'data') and hasattr(matrix, 'indices'):
                # Convert JAX BCOO to scipy
                data = np.array(matrix.data)
                indices = np.array(matrix.indices)
                shape = matrix.shape
                return sparse.coo_matrix((data, (indices[:, 0], indices[:, 1])), shape=shape)
        except ImportError:
            pass
        
        # Try PyTorch
        try:
            import torch
            if torch.is_tensor(matrix) and matrix.is_sparse:
                indices = matrix.indices().cpu().numpy()
                values = matrix.values().cpu().numpy()
                shape = matrix.shape
                return sparse.coo_matrix((values, (indices[0], indices[1])), shape=shape)
        except ImportError:
            pass
        
        raise ValueError(f"Cannot convert matrix of type {type(matrix)} to scipy sparse")