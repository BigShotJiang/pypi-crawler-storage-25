"""JAX sparse matrix converter"""

from typing import Any, Optional
import warnings
import numpy as np

from matrix_toolkit.converters.base import BaseConverter


class JaxConverter(BaseConverter):
    """Converter for JAX sparse matrices"""
    
    def __init__(self):
        try:
            import jax
            import jax.numpy as jnp
            import jax.experimental.sparse as jsparse
            self.jax = jax
            self.jnp = jnp
            self.jsparse = jsparse
            self.available = True
        except ImportError:
            self.available = False
            warnings.warn("JAX not available. Install with: pip install jax jaxlib")
    
    def supported_formats(self) -> list:
        return ['bcoo', 'csr', 'csc']  # JAX primarily uses BCOO
    
    def convert(self, matrix: Any, format: str = 'bcoo', dtype: Optional[str] = None) -> Any:
        """
        Convert matrix to JAX sparse format
        
        Args:
            matrix: Input matrix
            format: Target sparse format (JAX uses BCOO - Batched COO)
            dtype: Target data type
        
        Returns:
            JAX sparse matrix
        """
        if not self.available:
            raise RuntimeError("JAX is not installed")
        
        self._validate_format(format)
        
        # Import scipy for conversion
        from scipy import sparse
        
        # Convert to scipy COO first if needed
        if not sparse.issparse(matrix):
            from matrix_toolkit.converters.scipy_converter import ScipyConverter
            scipy_conv = ScipyConverter()
            matrix = scipy_conv.convert(matrix, format='coo')
        
        if not isinstance(matrix, sparse.coo_matrix):
            matrix = sparse.coo_matrix(matrix)
        
        # Convert to JAX BCOO format
        data = self.jnp.array(matrix.data)
        indices = self.jnp.column_stack([
            self.jnp.array(matrix.row),
            self.jnp.array(matrix.col)
        ])
        shape = matrix.shape
        
        jax_matrix = self.jsparse.BCOO((data, indices), shape=shape)
        
        # Convert dtype if specified
        if dtype is not None:
            jax_matrix = self.jsparse.BCOO(
                (jax_matrix.data.astype(dtype), jax_matrix.indices),
                shape=jax_matrix.shape
            )
        
        return jax_matrix