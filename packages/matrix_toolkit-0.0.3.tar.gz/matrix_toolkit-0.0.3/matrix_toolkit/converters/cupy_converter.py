"""CuPy sparse matrix converter"""

from typing import Any, Optional
import warnings

from matrix_toolkit.converters.base import BaseConverter


class CupyConverter(BaseConverter):
    """Converter for CuPy sparse matrices"""
    
    def __init__(self):
        try:
            import cupy as cp
            self.cp = cp
            self.available = True
        except ImportError:
            self.available = False
            warnings.warn("CuPy not available. Install with: pip install cupy")
    
    def supported_formats(self) -> list:
        return ['csr', 'csc', 'coo']
    
    def convert(self, matrix: Any, format: str = 'csr', dtype: Optional[str] = None) -> Any:
        """
        Convert matrix to CuPy sparse format
        
        Args:
            matrix: Input matrix
            format: Target sparse format
            dtype: Target data type
        
        Returns:
            CuPy sparse matrix on GPU
        """
        if not self.available:
            raise RuntimeError("CuPy is not installed")
        
        self._validate_format(format)
        
        # Import scipy for conversion
        from scipy import sparse
        
        # First convert to scipy if needed
        if not sparse.issparse(matrix):
            if hasattr(self.cp, 'ndarray') and isinstance(matrix, self.cp.ndarray):
                # Already a cupy array
                matrix = self.cp.sparse.csr_matrix(matrix)
            else:
                # Convert to scipy first
                from matrix_toolkit.converters.scipy_converter import ScipyConverter
                scipy_conv = ScipyConverter()
                matrix = scipy_conv.convert(matrix, format='csr')
        
        # Convert scipy to cupy
        if sparse.issparse(matrix):
            if format == 'csr':
                cupy_matrix = self.cp.sparse.csr_matrix(matrix)
            elif format == 'csc':
                cupy_matrix = self.cp.sparse.csc_matrix(matrix)
            elif format == 'coo':
                cupy_matrix = self.cp.sparse.coo_matrix(matrix)
            else:
                raise ValueError(f"Format {format} not supported for CuPy")
        else:
            cupy_matrix = matrix
        
        # Convert dtype if specified
        if dtype is not None:
            cupy_matrix = cupy_matrix.astype(dtype)
        
        return cupy_matrix