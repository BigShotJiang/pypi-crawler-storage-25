"""NumPy dense matrix converter"""

from typing import Any, Optional
import numpy as np
from scipy import sparse

from matrix_toolkit.converters.base import BaseConverter


class NumpyConverter(BaseConverter):
    """Converter for NumPy dense matrices"""
    
    def supported_formats(self) -> list:
        return ['dense', 'array']
    
    def convert(self, matrix: Any, format: str = 'dense', dtype: Optional[str] = None) -> Any:
        """
        Convert sparse matrix to dense NumPy array
        
        Args:
            matrix: Input matrix
            format: 'dense' or 'array'
            dtype: Target data type
        
        Returns:
            Dense NumPy array
        """
        self._validate_format(format)
        
        # Convert to dense
        if sparse.issparse(matrix):
            dense_matrix = matrix.toarray()
        elif isinstance(matrix, np.ndarray):
            dense_matrix = matrix
        else:
            # Try to convert from other backends
            try:
                import cupy as cp
                if isinstance(matrix, cp.ndarray):
                    dense_matrix = cp.asnumpy(matrix)
                elif hasattr(cp.sparse, 'issparse') and cp.sparse.issparse(matrix):
                    dense_matrix = matrix.get().toarray()
                else:
                    dense_matrix = np.array(matrix)
            except ImportError:
                dense_matrix = np.array(matrix)
        
        # Convert dtype if specified
        if dtype is not None:
            dense_matrix = dense_matrix.astype(dtype)
        
        return dense_matrix