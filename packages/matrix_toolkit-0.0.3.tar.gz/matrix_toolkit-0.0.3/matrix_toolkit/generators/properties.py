"""Matrix property checking functions"""

import numpy as np
from scipy import sparse
from typing import Any, Callable, Dict, List


class MatrixProperties:
    """Check various matrix properties"""
    
    @staticmethod
    def is_symmetric(matrix: Any, tol: float = 1e-10) -> bool:
        """Check if matrix is symmetric"""
        if not hasattr(matrix, 'shape') or matrix.shape[0] != matrix.shape[1]:
            return False
        
        if sparse.issparse(matrix):
            diff = matrix - matrix.T
            return diff.nnz == 0 or np.allclose(diff.data, 0, atol=tol)
        else:
            return np.allclose(matrix, matrix.T, atol=tol)
    
    @staticmethod
    def is_hermitian(matrix: Any, tol: float = 1e-10) -> bool:
        """Check if matrix is Hermitian"""
        if not hasattr(matrix, 'shape') or matrix.shape[0] != matrix.shape[1]:
            return False
        
        if sparse.issparse(matrix):
            diff = matrix - matrix.T.conj()
            return diff.nnz == 0 or np.allclose(diff.data, 0, atol=tol)
        else:
            return np.allclose(matrix, matrix.T.conj(), atol=tol)
    
    @staticmethod
    def is_positive_definite(matrix: Any, tol: float = 1e-10) -> bool:
        """Check if matrix is positive definite"""
        if not hasattr(matrix, 'shape') or matrix.shape[0] != matrix.shape[1]:
            return False
        
        # Only check small matrices (expensive operation)
        if matrix.shape[0] > 500:
            return None  # Unknown for large matrices
        
        try:
            if sparse.issparse(matrix):
                matrix_dense = matrix.toarray()
            else:
                matrix_dense = matrix
            
            eigenvalues = np.linalg.eigvals(matrix_dense)
            return np.all(eigenvalues.real > tol) and np.allclose(eigenvalues.imag, 0, atol=tol)
        except:
            return False
    
    @staticmethod
    def is_orthogonal(matrix: Any, tol: float = 1e-10) -> bool:
        """Check if matrix is orthogonal (Q^T Q = I)"""
        if not hasattr(matrix, 'shape') or matrix.shape[0] != matrix.shape[1]:
            return False
        
        if sparse.issparse(matrix):
            product = matrix.T @ matrix
            identity = sparse.eye(matrix.shape[0], format=matrix.format)
            diff = product - identity
            return diff.nnz == 0 or np.allclose(diff.data, 0, atol=tol)
        else:
            product = matrix.T @ matrix
            identity = np.eye(matrix.shape[0])
            return np.allclose(product, identity, atol=tol)
    
    @staticmethod
    def is_unitary(matrix: Any, tol: float = 1e-10) -> bool:
        """Check if matrix is unitary (Q^H Q = I)"""
        if not hasattr(matrix, 'shape') or matrix.shape[0] != matrix.shape[1]:
            return False
        
        if sparse.issparse(matrix):
            product = matrix.T.conj() @ matrix
            identity = sparse.eye(matrix.shape[0], format=matrix.format)
            diff = product - identity
            return diff.nnz == 0 or np.allclose(diff.data, 0, atol=tol)
        else:
            product = matrix.T.conj() @ matrix
            identity = np.eye(matrix.shape[0])
            return np.allclose(product, identity, atol=tol)
    
    @staticmethod
    def is_tridiagonal(matrix: Any, tol: float = 1e-10) -> bool:
        """Check if matrix is tridiagonal"""
        if not hasattr(matrix, 'shape'):
            return False
        
        n = matrix.shape[0]
        
        if sparse.issparse(matrix):
            # Check that all non-zeros are within bandwidth of 1
            coo = sparse.coo_matrix(matrix)
            return np.all(np.abs(coo.row - coo.col) <= 1)
        else:
            # Check that elements outside tridiagonal are zero
            for i in range(n):
                for j in range(n):
                    if abs(i - j) > 1:
                        if abs(matrix[i, j]) > tol:
                            return False
            return True
    
    @staticmethod
    def is_diagonal(matrix: Any, tol: float = 1e-10) -> bool:
        """Check if matrix is diagonal"""
        if not hasattr(matrix, 'shape'):
            return False
        
        if sparse.issparse(matrix):
            coo = sparse.coo_matrix(matrix)
            return np.all(coo.row == coo.col)
        else:
            return np.allclose(matrix, np.diag(np.diagonal(matrix)), atol=tol)
    
    @staticmethod
    def is_upper_triangular(matrix: Any, tol: float = 1e-10) -> bool:
        """Check if matrix is upper triangular"""
        if not hasattr(matrix, 'shape'):
            return False
        
        if sparse.issparse(matrix):
            coo = sparse.coo_matrix(matrix)
            return np.all(coo.row <= coo.col)
        else:
            return np.allclose(matrix, np.triu(matrix), atol=tol)
    
    @staticmethod
    def is_lower_triangular(matrix: Any, tol: float = 1e-10) -> bool:
        """Check if matrix is lower triangular"""
        if not hasattr(matrix, 'shape'):
            return False
        
        if sparse.issparse(matrix):
            coo = sparse.coo_matrix(matrix)
            return np.all(coo.row >= coo.col)
        else:
            return np.allclose(matrix, np.tril(matrix), atol=tol)
    
    @staticmethod
    def is_toeplitz(matrix: Any, tol: float = 1e-10) -> bool:
        """Check if matrix is Toeplitz"""
        if not hasattr(matrix, 'shape'):
            return False
        
        n = matrix.shape[0]
        
        if sparse.issparse(matrix):
            matrix = matrix.toarray()
        
        for i in range(n - 1):
            for j in range(n - 1):
                if abs(matrix[i, j] - matrix[i + 1, j + 1]) > tol:
                    return False
        
        return True
    
    @staticmethod
    def is_circulant(matrix: Any, tol: float = 1e-10) -> bool:
        """Check if matrix is circulant"""
        if not hasattr(matrix, 'shape') or matrix.shape[0] != matrix.shape[1]:
            return False
        
        n = matrix.shape[0]
        
        if sparse.issparse(matrix):
            matrix = matrix.toarray()
        
        # Check that each row is a cyclic shift of the first row
        first_row = matrix[0, :]
        for i in range(1, n):
            shifted = np.roll(first_row, i)
            if not np.allclose(matrix[i, :], shifted, atol=tol):
                return False
        
        return True
    
    @staticmethod
    def is_hankel(matrix: Any, tol: float = 1e-10) -> bool:
        """Check if matrix is Hankel (constant along anti-diagonals)"""
        if not hasattr(matrix, 'shape'):
            return False
        
        m, n = matrix.shape
        
        if sparse.issparse(matrix):
            matrix = matrix.toarray()
        
        for k in range(m + n - 1):
            # Get all elements on this anti-diagonal
            values = []
            for i in range(max(0, k - n + 1), min(m, k + 1)):
                j = k - i
                if 0 <= j < n:
                    values.append(matrix[i, j])
            
            if len(values) > 1:
                if not np.allclose(values, values[0], atol=tol):
                    return False
        
        return True
    
    @staticmethod
    def is_stochastic(matrix: Any, tol: float = 1e-10) -> bool:
        """Check if matrix is row stochastic (rows sum to 1, all non-negative)"""
        if not hasattr(matrix, 'shape'):
            return False
        
        if sparse.issparse(matrix):
            # Check non-negativity
            if np.any(matrix.data < -tol):
                return False
            
            # Check row sums
            row_sums = np.array(matrix.sum(axis=1)).flatten()
        else:
            if np.any(matrix < -tol):
                return False
            
            row_sums = matrix.sum(axis=1)
        
        return np.allclose(row_sums, 1.0, atol=tol)
    
    @staticmethod
    def is_doubly_stochastic(matrix: Any, tol: float = 1e-10) -> bool:
        """Check if matrix is doubly stochastic (rows and columns sum to 1)"""
        if not MatrixProperties.is_stochastic(matrix, tol):
            return False
        
        if sparse.issparse(matrix):
            col_sums = np.array(matrix.sum(axis=0)).flatten()
        else:
            col_sums = matrix.sum(axis=0)
        
        return np.allclose(col_sums, 1.0, atol=tol)
    
    @staticmethod
    def is_nilpotent(matrix: Any, max_power: int = 10, tol: float = 1e-10) -> bool:
        """Check if matrix is nilpotent (A^k = 0 for some k)"""
        if not hasattr(matrix, 'shape') or matrix.shape[0] != matrix.shape[1]:
            return False
        
        current = matrix.copy()
        
        for k in range(1, min(max_power, matrix.shape[0]) + 1):
            if sparse.issparse(current):
                if current.nnz == 0:
                    return True
                if np.allclose(current.data, 0, atol=tol):
                    return True
            else:
                if np.allclose(current, 0, atol=tol):
                    return True
            
            current = current @ matrix
        
        return False
    
    @staticmethod
    def is_involutory(matrix: Any, tol: float = 1e-10) -> bool:
        """Check if matrix is involutory (A^2 = I)"""
        if not hasattr(matrix, 'shape') or matrix.shape[0] != matrix.shape[1]:
            return False
        
        product = matrix @ matrix
        
        if sparse.issparse(product):
            identity = sparse.eye(matrix.shape[0], format=product.format)
            diff = product - identity
            return diff.nnz == 0 or np.allclose(diff.data, 0, atol=tol)
        else:
            identity = np.eye(matrix.shape[0])
            return np.allclose(product, identity, atol=tol)
    
    @classmethod
    def get_checker(cls, property_name: str) -> Callable:
        """Get property checker function by name"""
        property_map = {
            'symmetric': cls.is_symmetric,
            'hermitian': cls.is_hermitian,
            'positive definite': cls.is_positive_definite,
            'positive_definite': cls.is_positive_definite,
            'orthogonal': cls.is_orthogonal,
            'unitary': cls.is_unitary,
            'tridiagonal': cls.is_tridiagonal,
            'diagonal': cls.is_diagonal,
            'upper triangular': cls.is_upper_triangular,
            'lower triangular': cls.is_lower_triangular,
            'toeplitz': cls.is_toeplitz,
            'circulant': cls.is_circulant,
            'hankel': cls.is_hankel,
            'stochastic': cls.is_stochastic,
            'doubly stochastic': cls.is_doubly_stochastic,
            'nilpotent': cls.is_nilpotent,
            'involutory': cls.is_involutory,
        }
        
        return property_map.get(property_name.lower())
    
    @classmethod
    def list_all_properties(cls) -> List[str]:
        """List all supported properties"""
        return [
            'symmetric',
            'hermitian',
            'positive definite',
            'orthogonal',
            'unitary',
            'tridiagonal',
            'diagonal',
            'upper triangular',
            'lower triangular',
            'toeplitz',
            'circulant',
            'hankel',
            'stochastic',
            'doubly stochastic',
            'nilpotent',
            'involutory',
        ]