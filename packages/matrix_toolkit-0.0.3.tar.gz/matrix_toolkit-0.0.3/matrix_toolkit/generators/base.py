"""Base class for matrix generators"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Tuple
import numpy as np
from scipy import sparse


class MatrixGenerator(ABC):
    """Base class for matrix generators"""
    
    def __init__(self):
        self.properties_map = {}
    
    @abstractmethod
    def generate(self, *args, **kwargs) -> Any:
        """Generate a matrix"""
        pass
    
    def get_properties(self) -> List[str]:
        """Get list of properties for this matrix"""
        return self.properties_map.get(self.__class__.__name__, [])
    
    def check_properties(self, matrix: Any) -> Dict[str, bool]:
        """Check if generated matrix has expected properties"""
        from matrix_toolkit.generators.properties import MatrixProperties
        
        props = self.get_properties()
        results = {}
        
        for prop in props:
            checker = MatrixProperties.get_checker(prop)
            if checker:
                results[prop] = checker(matrix)
        
        return results


class MatrixRegistry:
    """Registry for all matrix generators"""
    
    _generators = {}
    
    @classmethod
    def register(cls, name: str, generator_class):
        """Register a matrix generator"""
        cls._generators[name] = generator_class
    
    @classmethod
    def get(cls, name: str):
        """Get a matrix generator by name"""
        if name not in cls._generators:
            raise ValueError(f"Matrix generator '{name}' not found")
        return cls._generators[name]()
    
    @classmethod
    def list_all(cls) -> List[str]:
        """List all registered generators"""
        return list(cls._generators.keys())
    
    @classmethod
    def generate(cls, name: str, *args, **kwargs):
        """Generate a matrix by name"""
        generator = cls.get(name)
        return generator.generate(*args, **kwargs)