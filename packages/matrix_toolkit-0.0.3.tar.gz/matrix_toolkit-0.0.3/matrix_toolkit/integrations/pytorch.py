"""PyTorch integration for matrix datasets"""

from typing import List, Optional, Callable, Any
import warnings


class TorchSparseDataset:
    """PyTorch Dataset wrapper for sparse matrices"""
    
    def __init__(
        self,
        matrices: List,
        labels: Optional[List] = None,
        transform: Optional[Callable] = None,
        target_transform: Optional[Callable] = None
    ):
        """
        Args:
            matrices: List of sparse matrices
            labels: Optional labels for each matrix
            transform: Optional transform to apply to matrices
            target_transform: Optional transform to apply to labels
        """
        try:
            import torch
            from torch.utils.data import Dataset
            self.torch = torch
            self.Dataset = Dataset
        except ImportError:
            raise ImportError("PyTorch not installed. Install with: pip install torch")
        
        self.matrices = matrices
        self.labels = labels
        self.transform = transform
        self.target_transform = target_transform
    
    def __len__(self):
        return len(self.matrices)
    
    def __getitem__(self, idx):
        matrix = self.matrices[idx]
        
        if self.transform:
            matrix = self.transform(matrix)
        
        if self.labels is not None:
            label = self.labels[idx]
            if self.target_transform:
                label = self.target_transform(label)
            return matrix, label
        
        return matrix


def to_torch_dataset(
    matrices: List,
    labels: Optional[List] = None,
    transform: Optional[Callable] = None,
    target_transform: Optional[Callable] = None
) -> Any:
    """
    Convert matrix collection to PyTorch Dataset
    
    Args:
        matrices: List of matrices
        labels: Optional labels
        transform: Optional transform function
        target_transform: Optional target transform function
    
    Returns:
        TorchSparseDataset instance
    """
    return TorchSparseDataset(matrices, labels, transform, target_transform)


def create_dataloader(
    dataset: TorchSparseDataset,
    batch_size: int = 32,
    shuffle: bool = True,
    num_workers: int = 0,
    **kwargs
):
    """
    Create PyTorch DataLoader from TorchSparseDataset
    
    Args:
        dataset: TorchSparseDataset instance
        batch_size: Batch size
        shuffle: Whether to shuffle data
        num_workers: Number of worker processes
        **kwargs: Additional arguments for DataLoader
    
    Returns:
        DataLoader instance
    """
    try:
        from torch.utils.data import DataLoader
    except ImportError:
        raise ImportError("PyTorch not installed")
    
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        **kwargs
    )