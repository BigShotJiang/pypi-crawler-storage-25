"""Scikit-learn integration"""

from typing import List, Optional, Tuple, Any
import numpy as np
from scipy import sparse


def to_sklearn_format(
    matrices: List,
    labels: Optional[List] = None,
    stack: bool = True
) -> Tuple[Any, Optional[Any]]:
    """
    Convert matrix collection to scikit-learn compatible format
    
    Args:
        matrices: List of matrices
        labels: Optional labels for supervised learning
        stack: Whether to stack matrices (True) or return list (False)
    
    Returns:
        (X, y) tuple where X is matrix data and y is labels
    """
    if stack:
        # Stack matrices into a single matrix
        # This assumes all matrices have the same shape
        if not matrices:
            return None, None
        
        # Check if all matrices have same shape
        shapes = [m.shape for m in matrices]
        if len(set(shapes)) > 1:
            raise ValueError(
                "Cannot stack matrices with different shapes. "
                "Set stack=False to return list."
            )
        
        # Stack based on matrix type
        if sparse.issparse(matrices[0]):
            # Stack sparse matrices
            X = sparse.vstack(matrices)
        else:
            # Stack dense matrices
            X = np.vstack([m.flatten() for m in matrices])
    else:
        X = matrices
    
    y = np.array(labels) if labels is not None else None
    
    return X, y


def prepare_for_classification(
    matrices: List,
    labels: List,
    feature_extraction: str = 'flatten'
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Prepare matrices for classification tasks
    
    Args:
        matrices: List of matrices
        labels: List of labels
        feature_extraction: Method to extract features
            - 'flatten': Flatten matrix to vector
            - 'statistics': Extract statistical features
            - 'spectral': Extract spectral features (eigenvalues)
    
    Returns:
        (X, y) tuple of feature matrix and labels
    """
    if feature_extraction == 'flatten':
        features = []
        for matrix in matrices:
            if sparse.issparse(matrix):
                features.append(matrix.toarray().flatten())
            else:
                features.append(matrix.flatten())
        X = np.vstack(features)
    
    elif feature_extraction == 'statistics':
        features = []
        for matrix in matrices:
            if sparse.issparse(matrix):
                data = matrix.data
            else:
                data = matrix.flatten()
            
            # Extract statistical features
            feat = [
                np.mean(data),
                np.std(data),
                np.min(data),
                np.max(data),
                np.median(data),
                matrix.shape[0],
                matrix.shape[1],
            ]
            
            if sparse.issparse(matrix):
                feat.append(matrix.nnz)
                feat.append(matrix.nnz / (matrix.shape[0] * matrix.shape[1]))
            
            features.append(feat)
        
        X = np.array(features)
    
    elif feature_extraction == 'spectral':
        features = []
        for matrix in matrices:
            if matrix.shape[0] != matrix.shape[1]:
                raise ValueError("Spectral features only available for square matrices")
            
            # Compute eigenvalues (only for small matrices)
            if matrix.shape[0] > 1000:
                raise ValueError("Matrix too large for spectral features")
            
            if sparse.issparse(matrix):
                matrix_dense = matrix.toarray()
            else:
                matrix_dense = matrix
            
            try:
                eigenvalues = np.linalg.eigvals(matrix_dense)
                # Use largest magnitude eigenvalues as features
                eigenvalues = np.sort(np.abs(eigenvalues))[::-1][:10]
                # Pad if necessary
                if len(eigenvalues) < 10:
                    eigenvalues = np.pad(eigenvalues, (0, 10 - len(eigenvalues)))
                features.append(eigenvalues)
            except:
                # If eigenvalue computation fails, use zeros
                features.append(np.zeros(10))
        
        X = np.array(features)
    
    else:
        raise ValueError(f"Unknown feature extraction method: {feature_extraction}")
    
    y = np.array(labels)
    
    return X, y