"""Tests for sampling strategies"""

import pytest
import pandas as pd
import numpy as np
from matrix_toolkit.datasets.samplers import (
    RandomSampler,
    StratifiedSampler,
    DiversitySampler
)


@pytest.fixture
def sample_data():
    """Create sample data for testing"""
    np.random.seed(42)
    data = pd.DataFrame({
        'name': [f'matrix_{i}' for i in range(100)],
        'rows': np.random.randint(100, 10000, 100),
        'cols': np.random.randint(100, 10000, 100),
        'nnz': np.random.randint(1000, 100000, 100),
        'group': np.random.choice(['physics', 'circuit', 'biology'], 100),
        'sparsity': np.random.uniform(0.8, 0.99, 100),
    })
    return data


def test_random_sampler(sample_data):
    """Test random sampling"""
    sampler = RandomSampler(seed=42)
    sampled = sampler.sample(sample_data, n=10)
    
    assert len(sampled) == 10
    assert set(sampled.columns) == set(sample_data.columns)


def test_stratified_sampler(sample_data):
    """Test stratified sampling"""
    sampler = StratifiedSampler(stratify_by='group', seed=42)
    sampled = sampler.sample(sample_data, n=30)
    
    assert len(sampled) <= 30
    # Check that all groups are represented
    assert len(sampled['group'].unique()) >= 2


def test_diversity_sampler_kmeans(sample_data):
    """Test diversity sampling with k-means"""
    try:
        sampler = DiversitySampler(
            diversity_features=['rows', 'sparsity'],
            method='kmeans',
            seed=42
        )
        sampled = sampler.sample(sample_data, n=10)
        
        assert len(sampled) == 10
    except ImportError:
        pytest.skip("scikit-learn not installed")


def test_diversity_sampler_maxmin(sample_data):
    """Test diversity sampling with max-min"""
    try:
        sampler = DiversitySampler(
            diversity_features=['rows', 'sparsity'],
            method='maxmin',
            seed=42
        )
        sampled = sampler.sample(sample_data, n=10)
        
        assert len(sampled) == 10
    except ImportError:
        pytest.skip("scikit-learn not installed")