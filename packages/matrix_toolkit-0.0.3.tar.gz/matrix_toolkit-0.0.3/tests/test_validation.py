"""Tests for validation utilities"""

import pytest
import numpy as np
from scipy import sparse
from matrix_toolkit.utils.validation import MatrixValidator


def test_validate_structure():
    """Test structure validation"""
    matrix = sparse.random(10, 10, density=0.3)
    
    result = MatrixValidator.validate_matrix(matrix, checks=['structure'])
    
    assert result['valid'] is True
    assert 'structure' in result['checks']
    assert result['checks']['structure']['passed'] is True


def test_validate_values():
    """Test value validation"""
    matrix = sparse.random(10, 10, density=0.3)
    
    result = MatrixValidator.validate_matrix(matrix, checks=['values'])
    
    assert 'values' in result['checks']


def test_validate_nan_detection():
    """Test NaN detection"""
    # Create matrix with NaN
    data = np.array([1.0, 2.0, np.nan, 4.0])
    row = np.array([0, 1, 2, 3])
    col = np.array([0, 1, 2, 3])
    matrix = sparse.coo_matrix((data, (row, col)), shape=(4, 4))
    
    result = MatrixValidator.validate_matrix(matrix, checks=['values'])
    
    assert result['checks']['values']['passed'] is False
    assert any('NaN' in str(w) for w in result['warnings'])


def test_symmetry_check():
    """Test symmetry checking"""
    # Create symmetric matrix
    A = np.random.rand(5, 5)
    symmetric = (A + A.T) / 2
    matrix = sparse.csr_matrix(symmetric)
    
    result = MatrixValidator.validate_matrix(matrix, checks=['symmetry'])
    
    assert 'symmetry' in result['checks']
    assert result['checks']['symmetry']['is_symmetric'] is True


def test_checksum():
    """Test checksum computation"""
    matrix1 = sparse.random(10, 10, density=0.3, random_state=42)
    matrix2 = sparse.random(10, 10, density=0.3, random_state=42)
    matrix3 = sparse.random(10, 10, density=0.3, random_state=43)
    
    checksum1 = MatrixValidator.compute_checksum(matrix1)
    checksum2 = MatrixValidator.compute_checksum(matrix2)
    checksum3 = MatrixValidator.compute_checksum(matrix3)
    
    assert checksum1 == checksum2
    assert checksum1 != checksum3