"""
Fixed PDE tests
"""

import pytest
import numpy as np
from scipy import sparse

from matrix_toolkit.pde import (
    PDEMatrixGenerator,
    PDEConfig,
    BoundaryCondition,
    PoissonEquation,
    HeatEquation,
    ConvectionDiffusionEquation,
    HelmholtzEquation,
)
from matrix_toolkit.pde.random_params import RandomParameterGenerator, LatinHypercubeSampler
from matrix_toolkit.anymatrix import MatrixProperties


class TestPDEEquations:
    """Test PDE equation classes"""
    
    def test_poisson_1d(self):
        """Test 1D Poisson equation"""
        config = PDEConfig(dimension=1, mesh_size=50)
        eq = PoissonEquation(config)
        
        A = eq.generate_matrix()
        assert A.shape == (50, 50)
        assert MatrixProperties.is_symmetric(A.toarray())
    
    def test_poisson_2d(self):
        """Test 2D Poisson equation"""
        config = PDEConfig(dimension=2, mesh_size=16)
        eq = PoissonEquation(config)
        
        A = eq.generate_matrix()
        assert A.shape == (256, 256)
        assert MatrixProperties.is_symmetric(A.toarray())
    
    def test_heat_equation(self):
        """Test heat equation"""
        config = PDEConfig(
            dimension=2,
            mesh_size=16,
            coefficients={'dt': 0.01, 'theta': 0.5}
        )
        eq = HeatEquation(config)
        
        M = eq.generate_matrix()
        assert M.shape == (256, 256)
    
    def test_convection_diffusion(self):
        """Test convection-diffusion"""
        config = PDEConfig(
            dimension=2,
            mesh_size=16,
            coefficients={
                'velocity': (1.0, 0.5),
                'diffusion': 0.1
            }
        )
        eq = ConvectionDiffusionEquation(config)
        
        A = eq.generate_matrix()
        assert A.shape == (256, 256)
    
    def test_helmholtz(self):
        """Test Helmholtz equation"""
        config = PDEConfig(
            dimension=2,
            mesh_size=16,
            coefficients={'wavenumber': 5.0}
        )
        eq = HelmholtzEquation(config)
        
        A = eq.generate_matrix()
        assert A.shape == (256, 256)
        assert MatrixProperties.is_symmetric(A.toarray())


class TestPDEMatrixGenerator:
    """Test main PDE matrix generator"""
    
    def test_random_parameter_generation(self):
        """Test random parameter generation"""
        config = PDEConfig(
            dimension=2,
            mesh_size=16,
            random_params=True,
            random_seed=42,
            param_ranges={'diffusion': (0.1, 10.0)}
        )
        gen = PDEMatrixGenerator('poisson', config)
        
        matrices = gen.generate(n_matrices=10, randomize=True)
        assert len(matrices) == 10
        
        # Check that matrices have different norms
        norms = [sparse.linalg.norm(A) for A in matrices]
        unique_norms = len(set([f"{n:.4f}" for n in norms]))
        
        # Should have at least a few different values
        assert unique_norms >= 5, f"Only {unique_norms} unique norms out of 10 matrices"


class TestAccuracy:
    """Test numerical accuracy"""
    
    def test_1d_poisson_accuracy(self):
        """Test 1D Poisson accuracy with manufactured solution"""
        from matrix_toolkit.pde.dim1d.generators import generate_1d_laplacian
        
        n = 100
        h = 1.0 / (n + 1)
        
        # Generate Laplacian
        L = generate_1d_laplacian(n, h)
        
        # Manufactured solution: u(x) = sin(πx)
        x = np.linspace(h, 1-h, n)
        u_exact = np.sin(np.pi * x)
        
        # RHS: -u''(x) = π² sin(πx)
        # L represents -d²/dx², so Lu = π² sin(πx)
        f = (np.pi**2) * np.sin(np.pi * x)
        
        # Solve
        u_numerical = sparse.linalg.spsolve(L, f)
        
        error = np.linalg.norm(u_numerical - u_exact, np.inf)
        
        # Second-order method: error ~ O(h²)
        # h ≈ 0.01, so error should be ~ 1e-4
        assert error < 1e-3, f"Error {error:.2e} too large"


if __name__ == '__main__':
    pytest.main([__file__, '-v'])