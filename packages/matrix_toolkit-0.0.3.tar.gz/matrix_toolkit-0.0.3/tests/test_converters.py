"""Tests for matrix converters"""

import pytest
import numpy as np
from scipy import sparse
from matrix_toolkit.converters.scipy_converter import ScipyConverter
from matrix_toolkit.converters.numpy_converter import NumpyConverter


def test_scipy_converter():
    """Test SciPy converter"""
    converter = ScipyConverter()
    
    # Create a simple sparse matrix
    matrix = sparse.random(10, 10, density=0.3, format='csr')
    
    # Test conversion to different formats
    csc = converter.convert(matrix, format='csc')
    assert csc.format == 'csc'
    
    coo = converter.convert(matrix, format='coo')
    assert coo.format == 'coo'


def test_numpy_converter():
    """Test NumPy converter"""
    converter = NumpyConverter()
    
    # Create a sparse matrix
    matrix = sparse.random(10, 10, density=0.3)
    
    # Convert to dense
    dense = converter.convert(matrix, format='dense')
    assert isinstance(dense, np.ndarray)
    assert dense.shape == (10, 10)


def test_dtype_conversion():
    """Test dtype conversion"""
    converter = ScipyConverter()
    
    matrix = sparse.random(10, 10, density=0.3, format='csr')
    
    # Convert to float32
    matrix_f32 = converter.convert(matrix, dtype='float32')
    assert matrix_f32.dtype == np.float32