"""Tests for storage module"""

import pytest
import tempfile
from pathlib import Path
from scipy import sparse
from matrix_toolkit.storage.saver import MatrixSaver
from matrix_toolkit.storage.loader import MatrixLoader


@pytest.fixture
def temp_dir():
    """Create temporary directory"""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


def test_save_load_npz(temp_dir):
    """Test saving and loading NPZ format"""
    saver = MatrixSaver()
    loader = MatrixLoader()
    
    # Create test matrices
    matrices = [sparse.random(10, 10, density=0.3) for _ in range(3)]
    
    # Save
    saver.save_collection(matrices, temp_dir, format='npz')
    
    # Load
    loaded_matrices = loader.load_collection(temp_dir, format='npz')
    
    assert len(loaded_matrices) == len(matrices)


def test_save_load_npz(temp_dir):
    """Test saving and loading NPZ format"""
    saver = MatrixSaver()
    loader = MatrixLoader()
    
    # Create test matrices
    matrices = [sparse.random(10, 10, density=0.3) for _ in range(3)]
    
    # Save
    saver.save_collection(matrices, temp_dir, format='npz')
    
    # Load without metadata to get just the list
    loaded_matrices = loader.load_collection(temp_dir, format='npz', load_metadata=False)
    
    assert len(loaded_matrices) == len(matrices)


def test_save_load_with_metadata(temp_dir):
    """Test saving and loading with metadata"""
    saver = MatrixSaver()
    loader = MatrixLoader()
    
    matrices = [sparse.random(10, 10, density=0.3) for _ in range(2)]
    
    # Save with metadata
    saver.save_collection(matrices, temp_dir, format='npz', metadata=True)
    
    # Load with metadata - returns tuple
    loaded_matrices, metadata = loader.load_collection(temp_dir, load_metadata=True)
    
    assert len(loaded_matrices) == len(matrices)
    assert metadata is not None
    assert len(metadata) == len(matrices)