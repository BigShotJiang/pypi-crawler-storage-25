"""Tests for dataset module"""

import pytest
import tempfile
from pathlib import Path
from matrix_toolkit.datasets.dataset import MatrixDataset


@pytest.fixture
def temp_dir():
    """Create temporary directory"""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


def test_dataset_creation():
    """Test dataset creation"""
    matrix_names = [f"matrix_{i}" for i in range(10)]
    
    dataset = MatrixDataset(
        name="test_dataset",
        matrix_names=matrix_names,
        split={'train': 0.7, 'val': 0.15, 'test': 0.15}
    )
    
    assert len(dataset) == 10
    assert len(dataset.splits) == 3
    assert 'train' in dataset.splits
    assert 'val' in dataset.splits
    assert 'test' in dataset.splits


def test_dataset_save_load(temp_dir):
    """Test dataset save and load"""
    matrix_names = [f"matrix_{i}" for i in range(5)]
    
    dataset = MatrixDataset(
        name="test_dataset",
        matrix_names=matrix_names,
        description="Test dataset"
    )
    
    # Save
    dataset.save(temp_dir)
    
    # Load
    loaded_dataset = MatrixDataset.load(temp_dir)
    
    assert loaded_dataset.name == dataset.name
    assert len(loaded_dataset) == len(dataset)
    assert loaded_dataset.description == dataset.description