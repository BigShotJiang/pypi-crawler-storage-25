"""Tests for integration modules"""

import pytest
import numpy as np
from scipy import sparse


def test_sklearn_integration():
    """Test scikit-learn integration"""
    from matrix_toolkit.integrations.sklearn import to_sklearn_format
    
    matrices = [sparse.random(10, 10, density=0.3) for _ in range(5)]
    labels = [0, 1, 0, 1, 0]
    
    X, y = to_sklearn_format(matrices, labels, stack=True)
    
    assert X is not None
    assert y is not None
    assert len(y) == 5


def test_sklearn_feature_extraction():
    """Test feature extraction for sklearn"""
    from matrix_toolkit.integrations.sklearn import prepare_for_classification
    
    matrices = [sparse.random(10, 10, density=0.3) for _ in range(5)]
    labels = [0, 1, 0, 1, 0]
    
    X, y = prepare_for_classification(matrices, labels, feature_extraction='statistics')
    
    assert X.shape[0] == 5
    assert y.shape[0] == 5


def test_pytorch_integration():
    """Test PyTorch integration"""
    try:
        from matrix_toolkit.integrations.pytorch import to_torch_dataset
        
        matrices = [sparse.random(10, 10, density=0.3) for _ in range(5)]
        labels = [0, 1, 0, 1, 0]
        
        dataset = to_torch_dataset(matrices, labels)
        
        assert len(dataset) == 5
        
        # Test __getitem__
        item = dataset[0]
        assert len(item) == 2  # matrix and label
        
    except ImportError:
        pytest.skip("PyTorch not installed")