"""Tests for MatrixFetcher"""

import pytest
import numpy as np
from scipy import sparse
from matrix_toolkit import MatrixFetcher


@pytest.fixture
def fetcher():
    """Create a MatrixFetcher instance"""
    return MatrixFetcher()


def test_fetcher_initialization(fetcher):
    """Test fetcher initialization"""
    assert fetcher is not None
    assert fetcher.config is not None
    assert fetcher.cache is not None
    assert fetcher.searcher is not None


def test_search(fetcher):
    """Test matrix search"""
    results = fetcher.search(rows=(100, 1000))
    
    # Result should be a DataFrame (even if empty)
    import pandas as pd
    assert isinstance(results, pd.DataFrame)
    
    # If empty, it's expected (no SuiteSparse data downloaded)
    # Just check the structure
    if len(results) > 0:
        assert 'rows' in results.columns or 'name' in results.columns


def test_metadata_extraction(fetcher):
    """Test metadata extraction"""
    from matrix_toolkit.utils.metadata import MetadataExtractor
    
    # Create a simple sparse matrix
    matrix = sparse.random(100, 100, density=0.1)
    metadata = MetadataExtractor.extract(matrix)
    
    assert 'shape' in metadata
    assert 'nnz' in metadata
    assert 'sparsity' in metadata
    assert metadata['shape'] == (100, 100)


def test_statistics(fetcher):
    """Test statistics computation"""
    stats = fetcher.statistics()
    assert isinstance(stats, dict)


def test_cache_operations():
    """Test cache operations"""
    from matrix_toolkit.core.cache import CacheManager
    
    cache = CacheManager()
    assert cache.cache_dir.exists()
    
    stats = cache.get_statistics()
    assert 'total_matrices' in stats
    assert 'total_size' in stats