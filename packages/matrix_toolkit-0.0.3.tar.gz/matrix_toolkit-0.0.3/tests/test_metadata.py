"""Tests for metadata utilities"""

import numpy as np
from scipy import sparse
from matrix_toolkit.utils.metadata import MetadataExtractor


def test_extract_sparse_metadata():
    """Test metadata extraction from sparse matrix"""
    matrix = sparse.random(100, 100, density=0.1, format='csr')
    
    metadata = MetadataExtractor.extract(matrix, matrix_name='test_matrix')
    
    assert metadata['name'] == 'test_matrix'
    assert metadata['shape'] == (100, 100)
    assert metadata['rows'] == 100
    assert metadata['cols'] == 100
    assert metadata['is_sparse'] is True
    assert metadata['format'] == 'csr'
    assert 'nnz' in metadata
    assert 'sparsity' in metadata
    assert 'density' in metadata


def test_extract_dense_metadata():
    """Test metadata extraction from dense matrix"""
    matrix = np.random.rand(10, 10)
    
    metadata = MetadataExtractor.extract(matrix)
    
    assert metadata['shape'] == (10, 10)
    assert metadata['is_sparse'] is False


def test_has_diagonal():
    """Test diagonal detection"""
    # Create matrix with diagonal
    matrix = sparse.diags([1, 2, 3, 4, 5], format='csr')
    
    has_diag = MetadataExtractor._has_diagonal(matrix)
    
    # NumPy returns np.bool_, need to compare properly
    assert has_diag == True 
    
    # Create matrix without diagonal
    data = np.array([1, 2, 3])
    row = np.array([0, 1, 2])
    col = np.array([1, 2, 3])
    matrix_no_diag = sparse.coo_matrix((data, (row, col)), shape=(5, 5))
    
    has_diag_no = MetadataExtractor._has_diagonal(matrix_no_diag)
    
    assert has_diag_no == False


def test_compare_metadata():
    """Test metadata comparison"""
    meta1 = {
        'rows': 100,
        'cols': 100,
        'nnz': 1000,
        'format': 'csr'
    }
    
    meta2 = {
        'rows': 100,
        'cols': 100,
        'nnz': 2000,
        'format': 'csr'
    }
    
    comparison = MetadataExtractor.compare_metadata(meta1, meta2)
    
    assert comparison['rows']['status'] == 'equal'
    assert comparison['nnz']['status'] == 'different'


