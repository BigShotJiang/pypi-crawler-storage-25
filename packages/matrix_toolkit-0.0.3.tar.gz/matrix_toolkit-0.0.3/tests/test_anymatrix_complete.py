"""Comprehensive tests for all anymatrix groups"""

import pytest
import numpy as np
from scipy import sparse

from matrix_toolkit.anymatrix import AnyMatrix, MatrixProperties


@pytest.fixture
def am():
    """Create AnyMatrix instance"""
    return AnyMatrix()


def test_all_groups_registered(am):
    """Test that all groups are registered"""
    groups = am.groups()
    
    expected_groups = ['core', 'gallery', 'hadamard', 'matlab', 'regtools']
    for group in expected_groups:
        assert group in groups, f"Group '{group}' not found"


def test_matrix_count(am):
    """Test total number of matrices"""
    counts = am.count()
    
    # Should have at least 60+ matrices total
    assert counts['total'] >= 60
    
    # Core should have the most
    assert counts['core'] >= 40
    
    print(f"\nMatrix counts by group:")
    for group, count in counts.items():
        print(f"  {group}: {count}")


def test_extended_core_matrices(am):
    """Test extended core matrices"""
    # Test a few key ones
    
    # Bidiagonal alternating
    A = am.generate('core/bidiag_alt', 5)
    assert A.shape == (5, 5)
    
    # Orthogonal Cauchy - now with proper parameters
    Q = am.generate('core/orthog_cauchy', 5)
    assert MatrixProperties.is_orthogonal(Q, tol=1e-8)
    
    # Indefinite matrix
    A = am.generate('core/indef', 10, 4)
    assert MatrixProperties.is_symmetric(A)
    
    # Vec permutation
    P = am.generate('core/vecperm', 3, 4)
    assert sparse.issparse(P)
    assert P.shape == (12, 12)


def test_hadamard_matrices(am):
    """Test Hadamard matrices"""
    # Standard Hadamard
    H = am.generate('hadamard/hadamard', 8)
    assert H.shape == (8, 8)
    assert MatrixProperties.is_orthogonal(H / np.sqrt(8))
    
    # Walsh matrix
    W = am.generate('hadamard/walsh', 16)
    assert W.shape == (16, 16)


def test_matlab_matrices(am):
    """Test MATLAB-style matrices"""
    # Magic square
    M = am.generate('matlab/magic', 5)
    assert M.shape == (5, 5)
    # Check magic property
    magic_sum = M.sum(axis=0)[0]
    assert np.allclose(M.sum(axis=0), magic_sum)
    assert np.allclose(M.sum(axis=1), magic_sum)
    
    # Hilbert matrix
    H = am.generate('matlab/hilbert', 5)
    assert MatrixProperties.is_symmetric(H)
    assert MatrixProperties.is_positive_definite(H)
    
    # Inverse Hilbert
    InvH = am.generate('matlab/invhilb', 5)
    # Check it's actually the inverse
    product = H @ InvH
    assert np.allclose(product, np.eye(5), atol=1e-10)
    
    # Pascal matrix
    P = am.generate('matlab/pascal', 6)
    assert MatrixProperties.is_symmetric(P)
    
    # Rosser matrix
    R = am.generate('matlab/rosser')
    assert R.shape == (8, 8)
    assert MatrixProperties.is_symmetric(R)
    
    # Wilkinson matrix
    W = am.generate('matlab/wilkinson', 21)
    assert MatrixProperties.is_symmetric(W)
    assert MatrixProperties.is_tridiagonal(W)


def test_regtools_matrices(am):
    """Test regularization matrices"""
    # Second derivative
    L = am.generate('regtools/deriv2', 100)
    assert sparse.issparse(L)
    assert MatrixProperties.is_symmetric(L.toarray())
    
    # Shaw problem
    A, b, x = am.generate('regtools/shaw', 50)
    assert A.shape == (50, 50)
    assert b.shape == (50,)
    assert x.shape == (50,)
    
    # Verify Ax ≈ b
    residual = np.linalg.norm(A @ x - b)
    assert residual < 1e-10
    
    # Phillips problem
    A, b, x = am.generate('regtools/phillips', 40)
    assert A.shape == (40, 40)
    
    # Gravity problem
    A, b, x = am.generate('regtools/gravity', 30)
    assert A.shape == (30, 30)


def test_stochastic_matrices(am):
    """Test various stochastic matrices"""
    stochastic_matrices = [
        'core/stoch_cesaro',
        'core/stoch_compan',  # Now with fixed parameters
        'core/stoch_revtri',
    ]
    
    for matrix_id in stochastic_matrices:
        A = am.generate(matrix_id, 10)
        assert MatrixProperties.is_stochastic(A), f"{matrix_id} should be stochastic"


def test_doubly_stochastic_matrices(am):
    """Test doubly stochastic matrices"""
    # Symmetric stochastic
    A = am.generate('core/symmstoch', 8)
    assert MatrixProperties.is_symmetric(A)
    assert MatrixProperties.is_doubly_stochastic(A)


def test_nilpotent_matrices(am):
    """Test nilpotent matrices"""
    nilpotent_matrices = [
        'core/nilpot_triang',   # Upper triangular
        'core/nilpot_tridiag',  # Upper bidiagonal (Jordan block)
        'core/creation',         # Creation operator
    ]
    
    for matrix_id in nilpotent_matrices:
        A = am.generate(matrix_id, 6)
        
        # For nilpotent matrix of size n, A^n = 0
        A_power = np.linalg.matrix_power(A, 6)
        
        assert np.allclose(A_power, 0, atol=1e-10), \
            f"{matrix_id} should be nilpotent (A^n = 0)"

def test_orthogonal_matrices(am):
    """Test orthogonal matrices"""
    orthogonal_matrices = [
        ('core/blockhouse', 8),
        ('core/hess_orth', 8),
        ('core/orthog_cauchy', 8),
    ]
    
    for matrix_id, size in orthogonal_matrices:
        try:
            Q = am.generate(matrix_id, size)
            if Q.shape[0] == Q.shape[1]:
                assert MatrixProperties.is_orthogonal(Q, tol=1e-8), \
                    f"{matrix_id} should be orthogonal"
        except Exception as e:
            print(f"Skipping {matrix_id}: {e}")


def test_companion_matrix(am):
    """Test companion matrix"""
    # Polynomial x^3 - 6x^2 + 11x - 6 = (x-1)(x-2)(x-3)
    c = np.array([-6, 11, -6, 1])
    C = am.generate('matlab/companion', c)
    
    # Eigenvalues should be roots: 1, 2, 3
    eigenvalues = np.linalg.eigvals(C)
    expected = np.array([1, 2, 3])
    
    assert np.allclose(sorted(eigenvalues.real), expected, atol=1e-10)


def test_totally_nonnegative(am):
    """Test totally nonnegative matrices"""
    for mode in [1, 2, 3]:
        A = am.generate('core/totally_nonneg', 5, mode)
        
        # All elements should be non-negative
        assert np.all(A >= 0)
        
        # Determinant should be non-negative
        det = np.linalg.det(A)
        assert det >= -1e-10, f"Determinant should be non-negative, got {det}"


def test_sparse_matrices(am):
    """Test matrices that should be sparse"""
    sparse_matrices = [
        ('core/perfect_shuffle', 50),
        ('core/collatz', 50),
        ('core/cross', 50),
        ('core/vecperm', (5, 10)),  # Takes two parameters
    ]
    
    for item in sparse_matrices:
        if isinstance(item, tuple) and len(item) == 2:
            matrix_id, args = item
            if isinstance(args, tuple):
                A = am.generate(matrix_id, *args)
            else:
                A = am.generate(matrix_id, args)
        else:
            matrix_id = item
            A = am.generate(matrix_id, 50)
        
        assert sparse.issparse(A), f"{matrix_id} should be sparse"


def test_search_functionality(am):
    """Test advanced search"""
    # Find all symmetric positive definite matrices
    sym_pd = am.search(['symmetric', 'positive definite'])
    assert len(sym_pd) > 0
    
    print(f"\nFound {len(sym_pd)} symmetric positive definite matrices")


def test_properties_consistency(am):
    """Test that declared properties are actually satisfied"""
    # Sample some matrices and verify their properties
    test_cases = [
        ('core/beta', 10, ['symmetric', 'positive definite']),
        ('core/fourier', 8, ['unitary']),
        ('gallery/lehmer', 6, ['symmetric', 'positive definite']),
        ('matlab/pascal', 5, ['symmetric', 'positive definite']),
    ]
    
    for matrix_id, size, expected_props in test_cases:
        A = am.generate(matrix_id, size)
        results = MatrixProperties.check_properties(A, expected_props, tol=1e-9)
        
        for prop, result in results.items():
            if result is not None:
                assert result, f"{matrix_id} should be {prop}"


def test_generate_with_different_parameters(am):
    """Test matrices with various parameters"""
    # KMS with different rho
    for rho in [0.2, 0.5, 0.9]:
        K = am.generate('gallery/kms', 5, rho)
        assert MatrixProperties.is_toeplitz(K)
    
    # Indefinite with different k
    for k in [1, 3, 5]:
        A = am.generate('core/indef', 10, k)
        assert MatrixProperties.is_symmetric(A)


if __name__ == '__main__':
    pytest.main([__file__, '-v'])