"""
Tests for PDE matrix generation module
"""

import pytest
import numpy as np
from scipy import sparse

from matrix_toolkit.pde import (
    PDEMatrixGenerator,
    PDEConfig,
    BoundaryCondition,
    PoissonEquation,
    HeatEquation,
    ConvectionDiffusionEquation,
    HelmholtzEquation,
)
from matrix_toolkit.pde.random_params import RandomParameterGenerator, LatinHypercubeSampler
from matrix_toolkit.anymatrix import MatrixProperties


class TestPDEConfig:
    """Test PDE configuration"""
    
    def test_config_creation(self):
        """Test basic config creation"""
        config = PDEConfig(dimension=2, mesh_size=32)
        assert config.dimension == 2
        assert config.mesh_size == (32, 32)
    
    def test_mesh_size_expansion(self):
        """Test mesh size expansion to match dimension"""
        config = PDEConfig(dimension=3, mesh_size=10)
        assert config.mesh_size == (10, 10, 10)
    
    def test_domain_expansion(self):
        """Test domain expansion"""
        config = PDEConfig(dimension=2, domain=(0.0, 1.0))
        assert config.domain == (0.0, 1.0, 0.0, 1.0)
    
    def test_mesh_spacing(self):
        """Test mesh spacing calculation"""
        config = PDEConfig(dimension=2, mesh_size=10, domain=(0.0, 1.0))
        h = config.get_mesh_spacing()
        assert len(h) == 2
        assert np.allclose(h[0], 1.0 / 9)
    
    def test_total_dofs(self):
        """Test total DOFs calculation"""
        config = PDEConfig(dimension=2, mesh_size=(10, 20))
        assert config.total_dofs() == 200


class Test1DMatrices:
    """Test 1D matrix generation"""
    
    def test_1d_laplacian_shape(self):
        """Test 1D Laplacian shape"""
        from matrix_toolkit.pde.dim1d.generators import generate_1d_laplacian
        
        A = generate_1d_laplacian(100)
        assert A.shape == (100, 100)
        assert sparse.issparse(A)
    
    def test_1d_laplacian_symmetry(self):
        """Test 1D Laplacian is symmetric"""
        from matrix_toolkit.pde.dim1d.generators import generate_1d_laplacian
        
        A = generate_1d_laplacian(50)
        assert MatrixProperties.is_symmetric(A.toarray(), tol=1e-10)
    
    def test_1d_laplacian_tridiagonal(self):
        """Test 1D Laplacian is tridiagonal"""
        from matrix_toolkit.pde.dim1d.generators import generate_1d_laplacian
        
        A = generate_1d_laplacian(50)
        assert MatrixProperties.is_tridiagonal(A.toarray(), tol=1e-10)
    
    def test_1d_convection_diffusion(self):
        """Test 1D convection-diffusion"""
        from matrix_toolkit.pde.dim1d.generators import generate_1d_convection_diffusion
        
        A = generate_1d_convection_diffusion(100, velocity=1.0, diffusion=0.1)
        assert A.shape == (100, 100)
        # Not symmetric due to convection
        assert not MatrixProperties.is_symmetric(A.toarray(), tol=1e-10)
    
    def test_1d_heat(self):
        """Test 1D heat equation matrix"""
        from matrix_toolkit.pde.dim1d.generators import generate_1d_heat
        
        M = generate_1d_heat(50, dt=0.01)
        assert M.shape == (50, 50)
        assert MatrixProperties.is_symmetric(M.toarray(), tol=1e-10)


class Test2DMatrices:
    """Test 2D matrix generation"""
    
    def test_2d_laplacian_shape(self):
        """Test 2D Laplacian shape"""
        from matrix_toolkit.pde.dim2d.generators import generate_2d_laplacian
        
        A = generate_2d_laplacian(10, 10)
        assert A.shape == (100, 100)
    
    def test_2d_laplacian_symmetry(self):
        """Test 2D Laplacian is symmetric"""
        from matrix_toolkit.pde.dim2d.generators import generate_2d_laplacian
        
        A = generate_2d_laplacian(8, 8)
        assert MatrixProperties.is_symmetric(A.toarray(), tol=1e-10)
    
    def test_2d_laplacian_sparsity(self):
        """Test 2D Laplacian sparsity"""
        from matrix_toolkit.pde.dim2d.generators import generate_2d_laplacian
        
        n = 20
        A = generate_2d_laplacian(n, n)
        # 5-point stencil: max 5 nnz per row
        assert A.nnz <= 5 * n * n
    
    def test_2d_convection_diffusion(self):
        """Test 2D convection-diffusion"""
        from matrix_toolkit.pde.dim2d.generators import generate_2d_convection_diffusion
        
        A = generate_2d_convection_diffusion(
            16, 16,
            velocity=(1.0, 0.5),
            diffusion=0.1
        )
        assert A.shape == (256, 256)
    
    def test_2d_helmholtz(self):
        """Test 2D Helmholtz equation"""
        from matrix_toolkit.pde.dim2d.generators import generate_2d_helmholtz
        
        A = generate_2d_helmholtz(16, 16, wavenumber=5.0)
        assert A.shape == (256, 256)
        # Should be symmetric
        assert MatrixProperties.is_symmetric(A.toarray(), tol=1e-10)


class Test3DMatrices:
    """Test 3D matrix generation"""
    
    def test_3d_laplacian_shape(self):
        """Test 3D Laplacian shape"""
        from matrix_toolkit.pde.dim3d.generators import generate_3d_laplacian
        
        A = generate_3d_laplacian(8, 8, 8)
        assert A.shape == (512, 512)
    
    def test_3d_laplacian_symmetry(self):
        """Test 3D Laplacian is symmetric"""
        from matrix_toolkit.pde.dim3d.generators import generate_3d_laplacian
        
        A = generate_3d_laplacian(5, 5, 5)
        assert MatrixProperties.is_symmetric(A.toarray(), tol=1e-10)
    
    def test_3d_laplacian_sparsity(self):
        """Test 3D Laplacian sparsity (7-point stencil)"""
        from matrix_toolkit.pde.dim3d.generators import generate_3d_laplacian
        
        n = 10
        A = generate_3d_laplacian(n, n, n)
        # 7-point stencil
        assert A.nnz <= 7 * n * n * n
    
    def test_3d_convection_diffusion(self):
        """Test 3D convection-diffusion"""
        from matrix_toolkit.pde.dim3d.generators import generate_3d_convection_diffusion
        
        A = generate_3d_convection_diffusion(
            8, 8, 8,
            velocity=(1.0, 0.5, 0.2),
            diffusion=0.1
        )
        assert A.shape == (512, 512)


class TestPDEEquations:
    """Test PDE equation classes"""
    
    def test_poisson_1d(self):
        """Test 1D Poisson equation"""
        config = PDEConfig(dimension=1, mesh_size=50)
        eq = PoissonEquation(config)
        
        A = eq.generate_matrix()
        assert A.shape == (50, 50)
        assert MatrixProperties.is_symmetric(A.toarray())
    
    def test_poisson_2d(self):
        """Test 2D Poisson equation"""
        config = PDEConfig(dimension=2, mesh_size=16)
        eq = PoissonEquation(config)
        
        A = eq.generate_matrix()
        assert A.shape == (256, 256)
        assert MatrixProperties.is_symmetric(A.toarray())
    
    def test_poisson_3d(self):
        """Test 3D Poisson equation"""
        config = PDEConfig(dimension=3, mesh_size=8)
        eq = PoissonEquation(config)
        
        A = eq.generate_matrix()
        assert A.shape == (512, 512)
        assert MatrixProperties.is_symmetric(A.toarray())
    
    def test_heat_equation(self):
        """Test heat equation"""
        config = PDEConfig(
            dimension=2,
            mesh_size=16,
            coefficients={'dt': 0.01, 'theta': 0.5}
        )
        eq = HeatEquation(config)
        
        M = eq.generate_matrix()
        assert M.shape == (256, 256)
    
    def test_convection_diffusion(self):
        """Test convection-diffusion"""
        config = PDEConfig(
            dimension=2,
            mesh_size=16,
            coefficients={
                'velocity': (1.0, 0.5),
                'diffusion': 0.1
            }
        )
        eq = ConvectionDiffusionEquation(config)
        
        A = eq.generate_matrix()
        assert A.shape == (256, 256)
    
    def test_helmholtz(self):
        """Test Helmholtz equation"""
        config = PDEConfig(
            dimension=2,
            mesh_size=16,
            coefficients={'wavenumber': 5.0}
        )
        eq = HelmholtzEquation(config)
        
        A = eq.generate_matrix()
        assert A.shape == (256, 256)
        assert MatrixProperties.is_symmetric(A.toarray())


class TestPDEMatrixGenerator:
    """Test main PDE matrix generator"""
    
    def test_generator_creation(self):
        """Test generator creation"""
        config = PDEConfig(dimension=2, mesh_size=32)
        gen = PDEMatrixGenerator('poisson', config)
        assert gen.equation_type == 'poisson'
    
    def test_single_matrix_generation(self):
        """Test single matrix generation"""
        config = PDEConfig(dimension=2, mesh_size=16)
        gen = PDEMatrixGenerator('poisson', config)
        
        A = gen.generate()
        assert A.shape == (256, 256)
    
    def test_batch_generation(self):
        """Test batch generation"""
        config = PDEConfig(dimension=2, mesh_size=16)
        gen = PDEMatrixGenerator('poisson', config)
        
        matrices = gen.generate(n_matrices=5)
        assert len(matrices) == 5
        assert all(A.shape == (256, 256) for A in matrices)
    
    def test_random_parameter_generation(self):
        """Test random parameter generation"""
        config = PDEConfig(
            dimension=2,
            mesh_size=16,
            random_params=True,
            random_seed=42,
            param_ranges={'diffusion': (0.1, 10.0)}
        )
        gen = PDEMatrixGenerator('poisson', config)
        
        matrices = gen.generate(n_matrices=10, randomize=True)
        assert len(matrices) == 10
        
        # Matrices should be different (due to different diffusion coeffs)
        # Check that not all matrices are identical
        norms = [sparse.linalg.norm(A) for A in matrices]
        assert len(set([f"{n:.6f}" for n in norms])) > 1
    
    def test_backend_scipy(self):
        """Test SciPy backend"""
        config = PDEConfig(
            dimension=2,
            mesh_size=16,
            backend='scipy',
            format='csr'
        )
        gen = PDEMatrixGenerator('poisson', config)
        A = gen.generate()
        
        assert sparse.issparse(A)
        assert A.format == 'csr'
    
    def test_backend_numpy(self):
        """Test NumPy backend"""
        config = PDEConfig(
            dimension=2,
            mesh_size=16,
            backend='numpy',
            format='dense'
        )
        gen = PDEMatrixGenerator('poisson', config)
        A = gen.generate()
        
        assert isinstance(A, np.ndarray)
        assert A.shape == (256, 256)
    
    def test_different_equations(self):
        """Test different equation types"""
        equations = ['poisson', 'heat', 'convection_diffusion', 'helmholtz']
        
        for eq_type in equations:
            config = PDEConfig(dimension=2, mesh_size=16)
            gen = PDEMatrixGenerator(eq_type, config)
            A = gen.generate()
            assert A.shape == (256, 256)


class TestRandomParameters:
    """Test random parameter generation"""
    
    def test_random_parameter_generator(self):
        """Test RandomParameterGenerator"""
        gen = RandomParameterGenerator()
        gen.add_parameter('diffusion', 'uniform', low=0.1, high=10.0)
        gen.add_parameter('velocity', 'normal', mean=1.0, std=0.5)
        
        samples = gen.sample(n=100, seed=42)
        assert len(samples) == 100
        
        # Check ranges
        diffusions = [s['diffusion'] for s in samples]
        assert all(0.1 <= d <= 10.0 for d in diffusions)
    
    def test_latin_hypercube_sampler(self):
        """Test Latin Hypercube Sampling"""
        sampler = LatinHypercubeSampler()
        sampler.add_parameter('param1', low=0.0, high=1.0)
        sampler.add_parameter('param2', low=-1.0, high=1.0)
        
        samples = sampler.sample(n=50, seed=42)
        assert len(samples) == 50
        
        # Check coverage (samples should be well-distributed)
        param1_vals = [s['param1'] for s in samples]
        param2_vals = [s['param2'] for s in samples]
        
        # Values should span the range
        assert min(param1_vals) < 0.2
        assert max(param1_vals) > 0.8
        assert min(param2_vals) < -0.6
        assert max(param2_vals) > 0.6


class TestBoundaryConditions:
    """Test different boundary conditions"""
    
    def test_dirichlet_bc(self):
        """Test Dirichlet boundary conditions"""
        from matrix_toolkit.pde.dim1d.generators import generate_1d_laplacian
        
        A = generate_1d_laplacian(50, boundary=BoundaryCondition.DIRICHLET)
        assert A.shape == (50, 50)
    
    def test_neumann_bc(self):
        """Test Neumann boundary conditions"""
        from matrix_toolkit.pde.dim1d.generators import generate_1d_laplacian
        
        A = generate_1d_laplacian(50, boundary=BoundaryCondition.NEUMANN)
        assert A.shape == (50, 50)
        # Neumann BC modifies boundary rows
    
    def test_periodic_bc(self):
        """Test periodic boundary conditions"""
        from matrix_toolkit.pde.dim1d.generators import generate_1d_laplacian
        
        A = generate_1d_laplacian(50, boundary=BoundaryCondition.PERIODIC)
        assert A.shape == (50, 50)
        # Check wrap-around connections
        assert A[0, -1] != 0  # Connection from first to last
        assert A[-1, 0] != 0  # Connection from last to first


class TestAccuracy:
    """Test numerical accuracy"""
    
    def test_1d_poisson_accuracy(self):
        """Test 1D Poisson accuracy with manufactured solution"""
        from matrix_toolkit.pde.dim1d.generators import generate_1d_laplacian
        
        n = 100
        h = 1.0 / (n + 1)
        
        # Generate Laplacian directly
        L = generate_1d_laplacian(n, h)
        
        # Manufactured solution: u(x) = sin(πx)
        x = np.linspace(h, 1-h, n)
        u_exact = np.sin(np.pi * x)
        
        # -u''(x) = π² sin(πx)
        # L u should equal π² sin(πx)
        f = (np.pi**2) * np.sin(np.pi * x)
        
        # Solve L u = f
        u_numerical = sparse.linalg.spsolve(L, f)
        
        error = np.linalg.norm(u_numerical - u_exact, np.inf)
        
        # Second-order accuracy: error ~ C h²
        # For h ≈ 0.01, expect error ~ 1e-4
        assert error < 5e-4, f"Error {error:.2e} too large for h={h:.2e}"
    
    def test_2d_poisson_accuracy(self):
        """Test 2D Poisson accuracy"""
        config = PDEConfig(dimension=2, mesh_size=32)
        gen = PDEMatrixGenerator('poisson', config)
        A = gen.generate()
        
        # Simple test: constant RHS should give reasonable solution
        n = 32 * 32
        h = 1.0 / 33
        f = np.ones(n) * h**2
        
        u = sparse.linalg.spsolve(A, f)
        
        # Solution should be positive and bounded
        assert np.all(u > 0)
        assert np.max(u) < 1.0


if __name__ == '__main__':
    pytest.main([__file__, '-v'])