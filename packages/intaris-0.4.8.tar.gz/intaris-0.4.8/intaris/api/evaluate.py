"""POST /evaluate endpoint for tool call safety evaluation."""

from __future__ import annotations

import asyncio
import functools
import logging
from datetime import datetime
from datetime import timezone as tz

from fastapi import APIRouter, Depends, HTTPException, Request

from intaris.api.deps import SessionContext, get_session_context
from intaris.api.schemas import EvaluateRequest, EvaluateResponse

logger = logging.getLogger(__name__)

router = APIRouter()


async def _emit_unresolved_escalation(
    *,
    http_request: Request,
    user_id: str,
    session_id: str,
    agent_id: str | None,
    tool: str,
    result: dict,
    event_type: str = "escalation",
    notify_channels: bool = True,
) -> None:
    """Emit escalation side effects once final human review is required."""

    webhook = getattr(http_request.app.state, "webhook", None)
    if webhook is not None and webhook.is_configured():
        asyncio.create_task(
            webhook.send_escalation(
                call_id=result["call_id"],
                session_id=session_id,
                user_id=user_id,
                agent_id=agent_id,
                tool=tool,
                args_redacted=result.get("args_redacted"),
                risk=result.get("risk"),
                reasoning=result.get("reasoning"),
            )
        )

    dispatcher = getattr(http_request.app.state, "notification_dispatcher", None)
    if dispatcher is None or not notify_channels:
        return

    from intaris.notifications.providers import Notification

    notification = Notification(
        event_type=event_type,
        call_id=result["call_id"],
        session_id=session_id,
        user_id=user_id,
        agent_id=agent_id,
        tool=tool,
        args_redacted=result.get("args_redacted"),
        risk=result.get("risk"),
        reasoning=result.get("reasoning"),
        ui_url=None,
        approve_url=None,
        deny_url=None,
        timestamp=datetime.now(tz.utc).isoformat(),
    )
    asyncio.create_task(
        dispatcher.notify(
            user_id=user_id,
            notification=notification,
        )
    )


@router.post("/evaluate", response_model=EvaluateResponse)
async def evaluate(
    request: EvaluateRequest,
    http_request: Request,
    ctx: SessionContext = Depends(get_session_context),
) -> EvaluateResponse:
    """Evaluate a tool call for safety and intention alignment.

    Runs the full evaluation pipeline:
    1. Rate limit check
    2. Classify (read-only allowlist -> auto-approve)
    3. Critical pattern check (-> auto-deny)
    4. LLM safety evaluation (-> decision matrix)
    5. Audit logging
    6. Session counter update
    7. Webhook notification (async, fire-and-forget) on escalation
    8. EventBus publish

    Returns the decision with reasoning, risk level, and latency.
    """
    from intaris.server import _get_evaluator

    # Rate limit check
    rate_limiter = getattr(http_request.app.state, "rate_limiter", None)
    if rate_limiter is not None:
        if not rate_limiter.check_and_record(ctx.user_id, request.session_id):
            raise HTTPException(
                status_code=429,
                detail="Rate limit exceeded: max evaluations per session per minute",
            )

    # Wait for any pending intention update (barrier pattern).
    # If a user message triggered an intention update via POST /reasoning,
    # we wait for it to complete before evaluating. This ensures the
    # evaluator sees the freshest user-stated intention.
    #
    # The barrier tracks user message timestamps server-side: if a
    # /reasoning call recently triggered an update, wait() detects the
    # race automatically without relying on client hints.
    barrier = getattr(http_request.app.state, "intention_barrier", None)
    if barrier is not None:
        await barrier.wait(ctx.user_id, request.session_id)

    # Wait for any pending alignment check (barrier pattern).
    # If a child session was just created or its intention was updated,
    # the alignment check runs async and we wait for it here. This
    # ensures no tool calls execute before alignment is verified.
    alignment_barrier = getattr(http_request.app.state, "alignment_barrier", None)
    if alignment_barrier is not None:
        await alignment_barrier.wait(ctx.user_id, request.session_id)

    try:
        request_started = asyncio.get_running_loop().time()
        evaluator = _get_evaluator()
        # agent_id: request body overrides header if provided
        agent_id = request.agent_id or ctx.agent_id

        # Run the synchronous evaluator in a thread executor to avoid
        # blocking the asyncio event loop. The evaluator makes synchronous
        # LLM calls (via the OpenAI SDK) that can take up to 4 seconds.
        # Without run_in_executor, these block the event loop and prevent
        # concurrent request processing — including /reasoning calls that
        # the intention barrier is waiting for.
        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(
            None,
            functools.partial(
                evaluator.evaluate,
                user_id=ctx.user_id,
                session_id=request.session_id,
                agent_id=agent_id,
                tool=request.tool,
                args=request.args,
                context=request.context,
            ),
        )

        judge_reviewer = getattr(http_request.app.state, "judge_reviewer", None)
        dispatcher = getattr(http_request.app.state, "notification_dispatcher", None)
        judge_waited = False

        if result.get("decision") == "escalate":
            if judge_reviewer is not None and judge_reviewer.is_enabled:
                judge_waited = True
                outcome = await judge_reviewer.review_for_evaluate(
                    call_id=result["call_id"],
                    user_id=ctx.user_id,
                    session_id=request.session_id,
                    agent_id=agent_id,
                )
                result["decision"] = outcome.decision
                result["reasoning"] = outcome.reasoning
                result["risk"] = outcome.risk
                result["latency_ms"] = int(
                    (asyncio.get_running_loop().time() - request_started) * 1000
                )
                if outcome.decision == "escalate":
                    await _emit_unresolved_escalation(
                        http_request=http_request,
                        user_id=ctx.user_id,
                        session_id=request.session_id,
                        agent_id=agent_id,
                        tool=request.tool,
                        result=result,
                        event_type=outcome.notification_event_type or "escalation",
                        notify_channels=getattr(
                            judge_reviewer, "notify_mode", "deny_only"
                        )
                        == "always",
                    )
            else:
                await _emit_unresolved_escalation(
                    http_request=http_request,
                    user_id=ctx.user_id,
                    session_id=request.session_id,
                    agent_id=agent_id,
                    tool=request.tool,
                    result=result,
                )

        # Fire-and-forget notification on session suspension
        if dispatcher is not None and result.get("session_status") == "suspended":
            from intaris.notifications.providers import Notification

            notification = Notification(
                event_type="session_suspended",
                call_id=result["call_id"],
                session_id=request.session_id,
                user_id=ctx.user_id,
                agent_id=agent_id,
                tool=request.tool,
                args_redacted=result.get("args_redacted"),
                risk=result.get("risk"),
                reasoning=result.get("status_reason") or result.get("reasoning"),
                ui_url=None,
                approve_url=None,
                deny_url=None,
                timestamp=datetime.now(tz.utc).isoformat(),
            )
            asyncio.create_task(
                dispatcher.notify(
                    user_id=ctx.user_id,
                    notification=notification,
                )
            )

        # Fire-and-forget notification on denial
        if (
            dispatcher is not None
            and result.get("decision") == "deny"
            and not judge_waited
        ):
            from intaris.notifications.providers import Notification

            notification = Notification(
                event_type="denial",
                call_id=result["call_id"],
                session_id=request.session_id,
                user_id=ctx.user_id,
                agent_id=agent_id,
                tool=request.tool,
                args_redacted=result.get("args_redacted"),
                risk=result.get("risk"),
                reasoning=result.get("reasoning"),
                ui_url=None,
                approve_url=None,
                deny_url=None,
                timestamp=datetime.now(tz.utc).isoformat(),
            )
            asyncio.create_task(
                dispatcher.notify(
                    user_id=ctx.user_id,
                    notification=notification,
                )
            )

        # Publish event to EventBus
        event_bus = getattr(http_request.app.state, "event_bus", None)
        if event_bus is not None:
            event_bus.publish(
                {
                    "type": "evaluated",
                    "call_id": result["call_id"],
                    "session_id": request.session_id,
                    "user_id": ctx.user_id,
                    "agent_id": agent_id,
                    "decision": result["decision"],
                    "risk": result.get("risk"),
                    "path": result["path"],
                    "latency_ms": result["latency_ms"],
                    "tool": request.tool,
                    "record_type": "tool_call",
                    "classification": result.get("classification"),
                    "timestamp": datetime.now(tz.utc).isoformat(),
                }
            )

        # Auto-append evaluation event to event store (session recording)
        event_store = getattr(http_request.app.state, "event_store", None)
        if event_store is not None:
            try:
                event_store.append(
                    ctx.user_id,
                    request.session_id,
                    [
                        {
                            "type": "evaluation",
                            "data": {
                                "call_id": result["call_id"],
                                "tool": request.tool,
                                "args_redacted": result.get("args_redacted"),
                                "classification": result.get("classification"),
                                "decision": result["decision"],
                                "risk": result.get("risk"),
                                "reasoning": result.get("reasoning"),
                                "path": result["path"],
                                "latency_ms": result["latency_ms"],
                                "injection_detected": result.get(
                                    "injection_detected", False
                                ),
                                "agent_id": agent_id,
                            },
                        }
                    ],
                    source="intaris",
                )
            except Exception:
                logger.debug("Failed to auto-append evaluation event", exc_info=True)

        # Volume-triggered summary: enqueue a summary task when the
        # session's total calls hit the configured threshold.
        bg_worker = getattr(http_request.app.state, "background_worker", None)
        if bg_worker is not None and bg_worker.analyzer_ready:
            try:
                from intaris.config import load_config

                cfg = load_config()
                threshold = cfg.analysis.summary_volume_threshold
                if threshold > 0:
                    # Get current total from the session (just incremented)
                    from intaris.server import _get_db
                    from intaris.session import SessionStore

                    _db = _get_db()
                    if _db is not None:
                        _sess = SessionStore(_db).get(
                            request.session_id, user_id=ctx.user_id
                        )
                        total = _sess.get("total_calls", 0)
                        if total > 0 and total % threshold == 0:
                            tq = bg_worker._task_queue
                            if not tq.cancel_duplicate(
                                "summary",
                                ctx.user_id,
                                request.session_id,
                            ) and not tq.recently_completed(
                                "summary",
                                ctx.user_id,
                                request.session_id,
                                cooldown_seconds=60,
                            ):
                                tq.enqueue(
                                    "summary",
                                    ctx.user_id,
                                    session_id=request.session_id,
                                    payload={"trigger": "volume"},
                                    priority=1,
                                )
                                logger.debug(
                                    "Volume-triggered summary: session=%s total=%d",
                                    request.session_id,
                                    total,
                                )
            except Exception:
                logger.debug("Failed to check volume trigger", exc_info=True)

        return EvaluateResponse(**result)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e)) from e
    except Exception as e:
        try:
            from intaris.llm import LLMTemporaryError

            if isinstance(e, LLMTemporaryError):
                raise HTTPException(status_code=503, detail=e.user_message) from e
        except HTTPException:
            raise
        except Exception:
            pass
        logger.exception("Error in /evaluate")
        raise HTTPException(
            status_code=500,
            detail="Internal error during evaluation",
        )
