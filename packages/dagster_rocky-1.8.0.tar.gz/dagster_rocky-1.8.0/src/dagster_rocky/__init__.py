"""dagster-rocky: Dagster integration for the Rocky SQL transformation engine."""

from .assets import load_rocky_assets
from .automation import rocky_cron_automation, rocky_eager_automation
from .branch_deploy import (
    BranchDeploymentInfo,
    branch_deploy_shadow_suffix,
    branch_deployment_info,
    is_branch_deployment,
)
from .checks import (
    check_metadata,
    cost_metadata_from_optimize,
    emit_check_results,
    emit_materializations,
)
from .column_lineage import build_column_lineage
from .component import RockyComponent, RockyMetadataSet, RockyTableProps
from .contracts import (
    CONTRACT_COLUMN_CONSTRAINTS_CHECK,
    CONTRACT_PROTECTED_COLUMNS_CHECK,
    CONTRACT_REQUIRED_COLUMNS_CHECK,
    ContractParseError,
    ContractRules,
    contract_check_results_from_diagnostics,
    contract_check_specs_for_model,
    discover_contract_rules,
)
from .dag_assets import (
    DagAssetGroup,
    build_dag_multi_assets,
    build_dag_specs,
    split_dag_specs_by_group,
)
from .derived_models import (
    ModelGroup,
    build_model_specs,
    split_model_specs_by_partition_shape,
)
from .freshness import (
    freshness_policy_from_checks,
    freshness_policy_from_model,
    per_model_freshness_policies,
)
from .health import HealthcheckResult, rocky_healthcheck
from .observability import (
    ANOMALY_CHECK_NAME,
    anomaly_check_results,
    drift_observations,
    optimize_metadata_for_keys,
)
from .partitions import (
    dagster_to_rocky_partition_key,
    partition_key_arg,
    partition_range_args,
    partitions_def_for_model_detail,
    partitions_def_for_time_interval,
    rocky_to_dagster_partition_key,
)
from .resource import MIN_ROCKY_VERSION, RockyResource
from .scaffold import init_rocky_project
from .schedules import build_rocky_schedule
from .sensor import rocky_source_sensor
from .translator import RockyDagsterTranslator
from .types import (
    AdapterTestResult,
    AiExplainResult,
    AiExplanation,
    AiResult,
    AiSyncProposal,
    AiSyncResult,
    AiTestAssertion,
    AiTestModelResult,
    AiTestResult,
    AnomalyResult,
    CheckResult,
    ChecksConfig,
    CiResult,
    ColumnDef,
    ColumnLineageResult,
    CompileResult,
    ConformanceResult,
    ContractResult,
    ContractViolation,
    DagEdge,
    DagNode,
    DagResult,
    Diagnostic,
    DiscoverResult,
    DoctorResult,
    DriftActionKind,
    DriftDetectResult,
    DriftedColumn,
    DriftInfo,
    DriftTableResult,
    ExecutionSummary,
    FreshnessConfig,
    HealthCheck,
    HealthStatus,
    HistoryResult,
    LineageEdge,
    MaterializationCost,
    MaterializationInfo,
    MetricsResult,
    MetricsSnapshot,
    ModelExecution,
    ModelHistoryResult,
    ModelLineageResult,
    ModelValidation,
    OptimizeResult,
    PartitionInfo,
    PartitionSummary,
    PermissionInfo,
    PlanResult,
    QualifiedColumn,
    QualityMetrics,
    QualitySnapshot,
    RunRecord,
    RunResult,
    Severity,
    SourceInfo,
    SourceSpan,
    StateResult,
    TableInfo,
    TestResult,
    TransformKind,
    ValidateMigrationResult,
    parse_rocky_output,
)

__all__ = [
    # Core
    "RockyComponent",
    "RockyMetadataSet",
    "RockyTableProps",
    "RockyResource",
    "MIN_ROCKY_VERSION",
    "RockyDagsterTranslator",
    "load_rocky_assets",
    "emit_check_results",
    "emit_materializations",
    "check_metadata",
    "cost_metadata_from_optimize",
    "parse_rocky_output",
    # Freshness + automation (T1.1, T1.2, T5.2)
    "freshness_policy_from_checks",
    "freshness_policy_from_model",
    "per_model_freshness_policies",
    "rocky_eager_automation",
    "rocky_cron_automation",
    # Sensor + schedule (T1.3, T1.5)
    "rocky_source_sensor",
    "build_rocky_schedule",
    # Observability (T4.1, T4.2, T4.4)
    "ANOMALY_CHECK_NAME",
    "drift_observations",
    "anomaly_check_results",
    "optimize_metadata_for_keys",
    # Contracts (T4.3)
    "CONTRACT_REQUIRED_COLUMNS_CHECK",
    "CONTRACT_PROTECTED_COLUMNS_CHECK",
    "CONTRACT_COLUMN_CONSTRAINTS_CHECK",
    "ContractRules",
    "ContractParseError",
    "discover_contract_rules",
    "contract_check_specs_for_model",
    "contract_check_results_from_diagnostics",
    # DAG-driven asset builder
    "DagAssetGroup",
    "build_dag_multi_assets",
    "build_dag_specs",
    "split_dag_specs_by_group",
    "DagResult",
    "DagNode",
    "DagEdge",
    # Derived-model surfacing (Tier 4 / Tier 3 wiring)
    "ModelGroup",
    "build_model_specs",
    "split_model_specs_by_partition_shape",
    # Partitions (T3)
    "partitions_def_for_time_interval",
    "partitions_def_for_model_detail",
    "rocky_to_dagster_partition_key",
    "dagster_to_rocky_partition_key",
    "partition_key_arg",
    "partition_range_args",
    # Column lineage (T4.6)
    "build_column_lineage",
    # Health (T5.5)
    "HealthcheckResult",
    "rocky_healthcheck",
    # Project bootstrap (T5.1)
    "init_rocky_project",
    # Branch deployment detection (T5.3, descoped)
    "BranchDeploymentInfo",
    "is_branch_deployment",
    "branch_deployment_info",
    "branch_deploy_shadow_suffix",
    # Discover
    "SourceInfo",
    "TableInfo",
    "DiscoverResult",
    "ChecksConfig",
    "FreshnessConfig",
    # Run
    "RunResult",
    "MaterializationInfo",
    "PartitionInfo",
    "PartitionSummary",
    "CheckResult",
    "ExecutionSummary",
    "MetricsSnapshot",
    "PermissionInfo",
    "DriftInfo",
    "AnomalyResult",
    "ContractResult",
    "ContractViolation",
    # Plan / State
    "PlanResult",
    "StateResult",
    # Compile
    "CompileResult",
    "Diagnostic",
    "Severity",
    "SourceSpan",
    # Lineage
    "ModelLineageResult",
    "ColumnLineageResult",
    "LineageEdge",
    "QualifiedColumn",
    "ColumnDef",
    "TransformKind",
    # Test / CI
    "TestResult",
    "CiResult",
    # History
    "HistoryResult",
    "ModelHistoryResult",
    "RunRecord",
    "ModelExecution",
    # Metrics
    "MetricsResult",
    "QualitySnapshot",
    "QualityMetrics",
    # Optimize
    "OptimizeResult",
    "MaterializationCost",
    # AI Level 3
    "AiResult",
    "AiSyncResult",
    "AiSyncProposal",
    "AiExplainResult",
    "AiExplanation",
    "AiTestResult",
    "AiTestModelResult",
    "AiTestAssertion",
    # Migration
    "ValidateMigrationResult",
    "ModelValidation",
    # Adapter conformance
    "ConformanceResult",
    "AdapterTestResult",
    # Doctor
    "DoctorResult",
    "HealthCheck",
    "HealthStatus",
    # Drift
    "DriftDetectResult",
    "DriftTableResult",
    "DriftedColumn",
    "DriftActionKind",
]
