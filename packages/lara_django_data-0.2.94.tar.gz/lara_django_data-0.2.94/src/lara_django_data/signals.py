"""
_____________________________________________________________________.

:PROJECT: LARAsuite

*lara_django_data signals handler *

:details: lara_django_data signals handler.

:authors: mark doerr <mark.doerr@uni-greifswald.de>
________________________________________________________________________
"""

# get settings from django.conf
import logging

from django.apps import apps
from django.conf import settings
from django.contrib.postgres.search import SearchVector
from django.db.models.signals import post_save
from django.dispatch import receiver
from lara_django_base.decorators import postgres_only

from lara_django_data.tasks import evaluate_procdure_task, visualisation_deploy_task, visualisation_procdure_task

from .models import Data, Evaluation, ExtraData, Visualisation
from .semantics import insert_semantic_data

logger = logging.getLogger("django")


@receiver(post_save, sender=Visualisation)
@postgres_only
def update_visualisation_search_vector(sender, instance, **kwargs):
    sender.objects.filter(pk=instance.pk).update(
        search_vector=(
            SearchVector("name", weight="A")
            + SearchVector("name_display", weight="B")
            + SearchVector("description", weight="C")
        )
    )


@receiver(post_save, sender=Evaluation)
@postgres_only
def update_evaluation_search_vector(sender, instance, **kwargs):
    sender.objects.filter(pk=instance.pk).update(
        search_vector=(
            SearchVector("name", weight="A")
            + SearchVector("name_display", weight="B")
            + SearchVector("description", weight="C")
            + SearchVector("caption", weight="D")
        )
    )


@receiver(post_save, sender=Data)
@postgres_only
def update_data_search_vector(sender, instance, **kwargs):
    sender.objects.filter(pk=instance.pk).update(
        search_vector=(
            SearchVector("name", weight="A")
            + SearchVector("name_display", weight="B")
            + SearchVector("name_full", weight="C")
            + SearchVector("description", weight="D")
            + SearchVector("remarks", weight="E")
        )
    )


@receiver(post_save, sender=Evaluation)
def evaluate_data(sender, instance, **kwargs):
    """evaluation is triggered, if there is a procedure associated with the evaluation"""
    if instance.eval_procedure_instance is not None:
        try:
            procedure_eval = instance.eval_procedure_instance.procedure_json["python"]["src"]
        except AttributeError:
            logger.exception("ERROR: no procedure associated with evaluation: %s", instance.name)

        else:
            # Call the task asynchronously
            evaluate_procdure_task.delay(procedure_eval)


@receiver(post_save, sender=Data)
def visualise_data(sender, instance, **kwargs):
    """visualisation is triggered, if there is a procedure associated with the evaluation"""
    logger.info(f"post_save signal received for Data instance: {instance.name}")
    if instance.visualisations.exists():  # and instance.visualisations.first().plotting_procedure_instance is not None:
        # TODO: if there are multiple visualisations, iterate over them and trigger visualisation for each of them

        for visualisation in instance.visualisations.all():
            logger.info(f"visualisation associated with data instance: {visualisation.name}")
            procedure_vis_json = getattr(
                getattr(visualisation, "plotting_procedure_instance", None), "procedure_json", None
            )
            if procedure_vis_json is None:
                logger.warning(f"No procedure_json found for visualisation: {visualisation.name}")
                continue

            procedure_vis_parameters_json = getattr(
                getattr(visualisation, "plotting_procedure_instance", None), "parameters", {}
            )
            procedure_vis_parameters_json["data_source"] = instance.name
            # remove namespace
            procedure_vis_parameters_json["namespace_uri"] = instance.namespace.uri if instance.namespace else None
            flow_name = procedure_vis_json.get("flow_name")
            procedure_vis_json["deployment_name"] = procedure_vis_json.get(
                "deployment_name", f"{flow_name}/vis-{visualisation.visualisation_id}-deployment"
            )
            # Call the task asynchronously
            visualisation_procdure_task.delay(
                procedure_vis_json=procedure_vis_json, parameters_local=procedure_vis_parameters_json
            )


@receiver(post_save, sender=Visualisation)
def deploy_visualisation(sender, instance, **kwargs):
    """Deploy a visualisation."""
    if instance.plotting_procedure_instance is not None:
        try:
            # procedure_vis = instance.plotting_procedure_instance.procedure_json["python"][
            #     "src"
            # ]
            procedure_vis_json = instance.plotting_procedure_instance.procedure_json
            # if instance.plotting_procedure_instance.parameters_json is not None:
            #     procedure_vis_parameters_json = instance.plotting_procedure_instance.parameters_json
            # else:

            procedure_vis_json["deployment_name"] = procedure_vis_json.get(
                "deployment_name", f"vis-{instance.visualisation_id}-deployment"
            )
            procedure_vis_parameters_json = getattr(
                getattr(instance, "plotting_procedure_instance", None), "parameters_json", {}
            )

        except AttributeError:
            logger.exception("ERROR: no procedure associated with evaluation: %s", instance.name)

        else:
            # Call the task asynchronously
            visualisation_deploy_task.delay(
                procedure_vis_json=procedure_vis_json, parameters_local=procedure_vis_parameters_json
            )


@receiver(post_save, sender=Data)
@postgres_only
def update_search_vector(sender, instance, **kwargs):
    sender.objects.filter(pk=instance.pk).update(
        search_vector=(
            SearchVector("name", weight="A")
            + SearchVector("name_display", weight="B")
            + SearchVector("name_full", weight="C")
            + SearchVector("description", weight="D")
            + SearchVector("remarks", weight="E")
        )
    )


# def pre_save_handler(sender, instance, **kwargs):
#     """post_save signal handler:
#     metadata is converted to semantic data = owlready2 Dataa object,
#     then triples are extracted from RDF graph
#     and written to triple store using SPARQL
#     """
#     logging.debug(f"post_save_handler1: {sender}, {instance}, ")  # {created}

#     # if created use mapping to write semantic data to triple store
#     if instance.__class__.__name__ == "Data":  # and created:
#         # insert_semantics(sender, instance, created, **kwargs)
#         logging.info(f"post_save_handler: inserting semantic data for instance: {instance.name}")
#         # insert_semantic_data(sender, instance, **kwargs)


def post_delete_handler(sender, instance, using, origin, **kwargs):
    """post_delete signal handler:
    triples are extracted from RDF graph
    and deleted from triple store using SPARQL
    """
    print(f"!!! Warning - deleting - post_delete_handler: {sender}, {instance}, {using}, {origin}, {kwargs}")
    # waiting_task.delay()


# from django.db.models.signals import post_delete from django.dispatch import receiver @receiver(post_delete, sender=Post) def delete_post_image(sender, instance, **kwargs): instance.image.delete(False)

# from django.db.models.signals import post_delete
# from django.dispatch import receiver

# @receiver(post_delete, sender=Post)
# def delete_post_image(sender, instance, **kwargs):
#     instance.image.delete(False)
# from django.dispatch import receiver
# from django.db.models.signals import post_save
# from lara_django_base.decorators import postgres_only

# from .semantics import insert_semantic_data

# logger = logging.getLogger("lara_signals")


# @receiver(post_save, sender=Evaluation)
# def semantics_data_handler(sender, instance, created, **kwargs):
#     """Semantic data post_save signal handler.

#        This function is triggered after an instance of the Evaluation model is saved.
#        It calls the insert_semantics function to handle the semantic data insertion
#        into the triplestore, running asynchronously as celery task.
#     """
#     logger.debug("post_save_handler1: %s, %s ", sender, instance)

#     insert_semantic_data(sender, instance, **kwargs)


# @receiver(post_save, sender=Evaluation)
# @postgres_only
# def update_search_vector(sender, instance, **kwargs):
#     sender.objects.filter(pk=instance.pk).update(
#         search_vector=(
#             SearchVector('name', weight='A') +
#             SearchVector('name_display', weight='B') +
#             SearchVector('description', weight='C') +
#             SearchVector('caption', weight='D')
#         )
#     )
