"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_data urls *

:details: lara_django_data urls module.
         - add app specific urls here
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

from django.conf import settings
from django.conf.urls.static import static
from django.urls import include
from django.urls import path
from django.views.generic import TemplateView
from django_socio_grpc.settings import grpc_settings

from . import views

# Add your {cookiecutter.project_slug}} urls here.


# !! this sets the apps namespace to be used in the template
app_name = "lara_django_data"

# companies and institutions should also be added
# the 'name' attribute is used in templates to address the url independent of the view

urlpatterns = [
    path("data/list/", views.DataSingleTableView.as_view(), name="data-list"),
    path("data/create/", views.DataCreateView.as_view(), name="data-create"),
    path("data/update/<uuid:pk>", views.DataUpdateView.as_view(), name="data-update"),
    path("data/delete/<uuid:pk>", views.DataDeleteView.as_view(), name="data-delete"),
    path("data/<uuid:pk>/", views.DataDetailView.as_view(), name="data-detail"),
    path(
        "eval/evaluate/<uuid:pk>",
        views.evaluate_data,
        name="eval-evaluate",
    ),
    # visualisation
    path("vis/visualise/<uuid:pk>", views.visualise_data, name="vis-visualise"),
    path("", views.DataSingleTableView.as_view(), name="data-root"),
    # path('', views.IndexView.as_view(), name='index'),
]


grpc_settings.user_settings["GRPC_HANDLERS"] += [
    "lara_django_data.grpc.handlers.grpc_handlers"
]
