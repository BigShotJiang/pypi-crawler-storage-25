"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_data admin *

:details: lara_django_data admin module admin backend configuration.


.. note:: -
.. todo:: - run "lara-django-dev forms_generator -c lara_django_data > forms.py" to update this file
________________________________________________________________________
"""

# django crispy forms s. https://github.com/django-crispy-forms/django-crispy-forms for []
# generated with django-extensions forms_generator -c  [] > forms.py (LARA-version)

from typing import ClassVar

from django import forms
from django.forms.renderers import TemplatesSetting

from .models import Data, Evaluation, ExtraData, Visualisation


class CustomFormRenderer(TemplatesSetting):
    """Custom form renderer for consistent field rendering."""

    field_template_name = "lara_django_data/forms/field_group.html"


class SearchableSelectMultiple(forms.SelectMultiple):
    """Custom widget for searchable multi-select using Alpine.js."""

    template_name = "lara_django_data/widgets/searchable_select_multiple.html"

    def __init__(self, attrs=None):
        """Initialize the searchable select multiple widget."""
        default_attrs = {"class": "searchable-select-multiple"}
        if attrs:
            default_attrs.update(attrs)
        super().__init__(attrs=default_attrs)


## -------------- ExtraData -------------- ##


class ExtraDataCreateForm(forms.ModelForm):
    """Form for creating a new extra data with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = ExtraData

        fields = (
            "name",
            "name_display",
            "name_full",
            "namespace",
            "version",
            "data_type",
            "media_type",
            "hash_sha256",
            "data_json",
            "iri",
            "url",
            "description",
            "file",
            "image",
        )

        # Categorize fields by widget type
        text_fields_required: ClassVar = ("name",)

        text_fields: ClassVar = (
            "name_display",
            "name_full",
            "version",
            "hash_sha256",
        )

        textarea_fields: ClassVar = (
            "description",
            "data_json",
        )

        url_fields: ClassVar = ("iri", "url")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "data_type": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "media_type": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "file": forms.ClearableFileInput(attrs={"class": "file-input file-input-sm file-input-bordered w-full"}),
            "image": forms.ClearableFileInput(attrs={"class": "file-input file-input-sm file-input-bordered w-full"}),
        }


class ExtraDataUpdateForm(forms.ModelForm):
    """Form for updating an existing extra data with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = ExtraData

        fields = (
            "name",
            "name_display",
            "name_full",
            "namespace",
            "version",
            "data_type",
            "media_type",
            "hash_sha256",
            "data_json",
            "iri",
            "url",
            "description",
            "file",
            "image",
        )

        # Categorize fields by widget type
        text_fields_required: ClassVar = ("name",)

        text_fields: ClassVar = (
            "name_display",
            "name_full",
            "version",
            "hash_sha256",
        )

        textarea_fields: ClassVar = (
            "description",
            "data_json",
        )

        url_fields: ClassVar = ("iri", "url")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "data_type": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "media_type": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "file": forms.ClearableFileInput(attrs={"class": "file-input file-input-sm file-input-bordered w-full"}),
            "image": forms.ClearableFileInput(attrs={"class": "file-input file-input-sm file-input-bordered w-full"}),
        }



## -------------- Visualisation -------------- ##


class VisualisationCreateForm(forms.ModelForm):
    """Form for creating a new visualisation with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Visualisation

        fields = (
            "name",
            "name_display",
            "namespace",
            "version",
            "data_type",
            "plotting_method_instance",
            "plotting_procedure_instance",
            "rendering_components",
            "iri",
            "tags",
            "caption",
            "resources_external",
            "thumbnail",
            "image",
            "description",
            "order",
        )

        # Categorize fields by widget type
        text_fields_required: ClassVar = ("name",)

        text_fields: ClassVar = (
            "name_display",
            "version",
        )

        textarea_fields: ClassVar = (
            "rendering_components",
            "caption",
            "thumbnail",
            "description",
        )

        number_fields: ClassVar = ("order",)

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{
                field: forms.NumberInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in number_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "data_type": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "plotting_method_instance": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "plotting_procedure_instance": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "tags": SearchableSelectMultiple(),
            "resources_external": SearchableSelectMultiple(),
            "image": forms.ClearableFileInput(attrs={"class": "file-input file-input-sm file-input-bordered w-full"}),
        }


class VisualisationUpdateForm(forms.ModelForm):
    """Form for updating an existing visualisation with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Visualisation

        fields = (
            "name",
            "name_display",
            "namespace",
            "version",
            "data_type",
            "plotting_method_instance",
            "plotting_procedure_instance",
            "rendering_components",
            "iri",
            "tags",
            "caption",
            "resources_external",
            "thumbnail",
            "image",
            "description",
            "order",
        )

        # Categorize fields by widget type
        text_fields_required: ClassVar = ("name",)

        text_fields: ClassVar = (
            "name_display",
            "version",
        )

        textarea_fields: ClassVar = (
            "rendering_components",
            "caption",
            "thumbnail",
            "description",
        )

        number_fields: ClassVar = ("order",)

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{
                field: forms.NumberInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in number_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "data_type": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "plotting_method_instance": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "plotting_procedure_instance": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "tags": SearchableSelectMultiple(),
            "resources_external": SearchableSelectMultiple(),
            "image": forms.ClearableFileInput(attrs={"class": "file-input file-input-sm file-input-bordered w-full"}),
        }



## -------------- Data -------------- ##


class DataCreateForm(forms.ModelForm):
    """Form for creating a new data with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Data

        fields = (
            "name",
            "name_display",
            "name_full",
            "version",
            "data_type",
            "media_type",
            "namespace",
            "hash_sha256",
            "hash_blockchain",
            "users",
            "groups",
            "acl",
            "licenses",
            "datetime_created",
            "datetime_last_modified",
            "method_instance",
            "procedure_instance",
            "process_instance",
            "data_json",
            "metadata",
            "visualisations",
            "data_extra",
            "iri",
            "pid",
            "doi",
            "pac_id",
            "resources_external",
            "file",
            "thumbnail",
            "tags",
            "description",
            "remarks",
        )

        # Categorize fields by widget type
        text_fields_required: ClassVar = ("name",)

        text_fields: ClassVar = (
            "name_display",
            "name_full",
            "version",
            "hash_sha256",
            "hash_blockchain",
        )

        textarea_fields: ClassVar = (
            "data_json",
            "metadata",
            "acl",
            "licenses",
            "thumbnail",
            "description",
            "remarks",
        )

        datetime_fields: ClassVar = ("datetime_created", "datetime_last_modified")

        url_fields: ClassVar = ("iri", "pid", "doi", "pac_id")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{
                field: forms.DateTimeInput(
                    attrs={"class": "input input-sm input-bordered w-full", "type": "datetime-local"}
                )
                for field in datetime_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "data_type": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "media_type": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "method_instance": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "procedure_instance": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "process_instance": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "users": SearchableSelectMultiple(),
            "groups": SearchableSelectMultiple(),
            "visualisations": SearchableSelectMultiple(),
            "data_extra": SearchableSelectMultiple(),
            "resources_external": SearchableSelectMultiple(),
            "tags": SearchableSelectMultiple(),
            "file": forms.ClearableFileInput(attrs={"class": "file-input file-input-sm file-input-bordered w-full"}),
        }


class DataUpdateForm(forms.ModelForm):
    """Form for updating an existing data with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Data

        fields = (
            "name",
            "name_display",
            "name_full",
            "version",
            "data_type",
            "media_type",
            "namespace",
            "hash_sha256",
            "hash_blockchain",
            "users",
            "groups",
            "acl",
            "licenses",
            "datetime_created",
            "datetime_last_modified",
            "method_instance",
            "procedure_instance",
            "process_instance",
            "data_json",
            "metadata",
            "visualisations",
            "data_extra",
            "iri",
            "pid",
            "doi",
            "pac_id",
            "resources_external",
            "file",
            "thumbnail",
            "tags",
            "description",
            "remarks",
        )

        # Categorize fields by widget type
        text_fields_required: ClassVar = ("name",)

        text_fields: ClassVar = (
            "name_display",
            "name_full",
            "version",
            "hash_sha256",
            "hash_blockchain",
        )

        textarea_fields: ClassVar = (
            "data_json",
            "metadata",
            "acl",
            "licenses",
            "thumbnail",
            "description",
            "remarks",
        )

        datetime_fields: ClassVar = ("datetime_created", "datetime_last_modified")

        url_fields: ClassVar = ("iri", "pid", "doi", "pac_id")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{
                field: forms.DateTimeInput(
                    attrs={"class": "input input-sm input-bordered w-full", "type": "datetime-local"}
                )
                for field in datetime_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "data_type": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "media_type": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "method_instance": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "procedure_instance": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "process_instance": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "users": SearchableSelectMultiple(),
            "groups": SearchableSelectMultiple(),
            "visualisations": SearchableSelectMultiple(),
            "data_extra": SearchableSelectMultiple(),
            "resources_external": SearchableSelectMultiple(),
            "tags": SearchableSelectMultiple(),
            "file": forms.ClearableFileInput(attrs={"class": "file-input file-input-sm file-input-bordered w-full"}),
        }



## -------------- Evaluation -------------- ##


class EvaluationCreateForm(forms.ModelForm):
    """Form for creating a new evaluation with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Evaluation

        fields = (
            "name",
            "name_display",
            "namespace",
            "version",
            "hash_sha256",
            "parameters",
            "parent_evals",
            "eval_method_instance",
            "eval_procedure_instance",
            "data_eval",
            "data_results",
            "visualisations",
            "iri",
            "pid",
            "doi",
            "resources_external",
            "tags",
            "caption",
            "description",
            "datetime_created",
            "datetime_last_modified",
        )

        # Categorize fields by widget type
        text_fields_required: ClassVar = ("name",)

        text_fields: ClassVar = (
            "name_display",
            "version",
            "hash_sha256",
        )

        textarea_fields: ClassVar = (
            "parameters",
            "caption",
            "description",
        )

        datetime_fields: ClassVar = ("datetime_created", "datetime_last_modified")

        url_fields: ClassVar = ("iri", "pid", "doi")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{
                field: forms.DateTimeInput(
                    attrs={"class": "input input-sm input-bordered w-full", "type": "datetime-local"}
                )
                for field in datetime_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "eval_method_instance": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "eval_procedure_instance": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "parent_evals": SearchableSelectMultiple(),
            "data_eval": SearchableSelectMultiple(),
            "data_results": SearchableSelectMultiple(),
            "visualisations": SearchableSelectMultiple(),
            "resources_external": SearchableSelectMultiple(),
            "tags": SearchableSelectMultiple(),
        }



class EvaluationUpdateForm(forms.ModelForm):
    """Form for updating an existing evaluation with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Evaluation

        fields = (
            "name",
            "name_display",
            "namespace",
            "version",
            "hash_sha256",
            "parameters",
            "parent_evals",
            "eval_method_instance",
            "eval_procedure_instance",
            "data_eval",
            "data_results",
            "visualisations",
            "iri",
            "pid",
            "doi",
            "resources_external",
            "tags",
            "caption",
            "description",
            "datetime_created",
            "datetime_last_modified",
        )

        # Categorize fields by widget type
        text_fields_required: ClassVar = ("name",)

        text_fields: ClassVar = (
            "name_display",
            "version",
            "hash_sha256",
        )

        textarea_fields: ClassVar = (
            "parameters",
            "caption",
            "description",
        )

        datetime_fields: ClassVar = ("datetime_created", "datetime_last_modified")

        url_fields: ClassVar = ("iri", "pid", "doi")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{
                field: forms.DateTimeInput(
                    attrs={"class": "input input-sm input-bordered w-full", "type": "datetime-local"}
                )
                for field in datetime_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "namespace": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "eval_method_instance": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "eval_procedure_instance": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "parent_evals": SearchableSelectMultiple(),
            "data_eval": SearchableSelectMultiple(),
            "data_results": SearchableSelectMultiple(),
            "visualisations": SearchableSelectMultiple(),
            "resources_external": SearchableSelectMultiple(),
            "tags": SearchableSelectMultiple(),
        }


