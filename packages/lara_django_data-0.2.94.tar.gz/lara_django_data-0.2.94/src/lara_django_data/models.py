"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_data models *

:details: lara_django_data database models.
          The data table is generically used to store many kinds of data.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - remove unwanted models/fields
           - add gRPC interface
          - in long the term
           a Blockchain kind of data storage might be implemented
           for better reliability.
________________________________________________________________________
"""

import hashlib
import json
import uuid

from django.conf import settings
from django.contrib.postgres.indexes import GinIndex
from django.contrib.postgres.search import SearchVectorField
from django.db import models
from django.utils import timezone
from lara_django_base.models import BlockchainHashesAbstr
from lara_django_base.models import DataType
from lara_django_base.models import ExternalResource
from lara_django_base.models import ExtraDataAbstr
from lara_django_base.models import MediaType
from lara_django_base.models import Namespace
from lara_django_base.models import Tag
from lara_django_people.models import Entity
from lara_django_people.models import Group
from lara_django_people.models import ItemSubsetAbstr
from lara_django_processes.models import MethodInstance
from lara_django_processes.models import ProcedureInstance
from lara_django_processes.models import ProcessInstance

settings.FIXTURES += []


class ExtraData(ExtraDataAbstr):
    """
    This class can be used to extend data, by extra information,
    e.g. more telephone numbers, customer numbers, ...
    """

    model_curi = "lara:data/ExtraData"
    extradata_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    file = models.FileField(upload_to="data", blank=True, null=True, help_text="rel. path/filename")
    image = models.ImageField(
        upload_to="data/images/",
        blank=True,
        null=True,
        help_text="location room map rel. path/filename to image",
    )

    def save(self, *args, **kwargs):
        """
        Here we generate some default values for name_full
        """

        if self.version is None or self.version == "":
            self.version = "0.0.1"

        if self.hash_sha256 is None:
            if self.data_json is not None:
                to_hash = json.dumps(self.data_json)  # +  str(self.UUID) +
                self.hash_sha256 = hashlib.sha256(to_hash.encode("utf-8")).hexdigest()
            else:
                self.hash_sha256 = hashlib.sha256(str(self.extradata_id).encode("utf-8")).hexdigest()

        if self.name is None or self.name == "":
            if self.name_display is not None and self.name_display != "":
                self.name = f"{self.name_display.replace(' ', '_').lower().strip()}_{self.version}"
            else:
                self.name = "_".join(
                    (
                        timezone.now().strftime("%Y%m%d_%H%M%S"),
                        "extra_data",
                        self.version,
                    )
                )
        else:
            self.name = self.name.replace(" ", "_").lower().strip()
        if self.name_full is None or self.name_full == "":
            if self.namespace is not None and self.version is not None:
                self.name_full = f"{self.namespace.uri}/" + "_".join((self.name.replace(" ", "_"), self.version))
            else:
                self.name_full = "_".join((self.name.replace(" ", "_"), self.version))

        if self.namespace and not self.iri:
            netloc = self.namespace.parse_uri().netloc
            path = self.namespace.parse_uri().path

            self.iri = f"{settings.LARA_PREFIXES['lara']}data/ExtraData/{netloc}{path}/{self.name.replace(' ', '_').lower().strip()}_{str(self.extradata_id)[:8]}"

        if self.datetime_created is None:
            self.datetime_created = timezone.now()

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)


class BlockchainHashes(BlockchainHashesAbstr):
    """
    This class can be used to store hashes of data, which are stored in a blockchain.
    The hashes can be used to verify the integrity of the data.
    The hashes are stored in a separate table, to avoid circular dependencies.
    """

    model_curi = "lara:data/BlockchainHashes"


class Data(models.Model):
    """
    Generic data class. All data, like data from experiments, measurements or evaluations will be stored here.
    There are also references to the way, how the data is produced, evaluated and visualised.
    The data contains a reference to the process which generated the data.
    For versioning semantic versioning (https://semver.org/lang/en/) shall be used.
    .. todo:: - check, whether UUID is required, if hash is there...
              - Blockchain data
    """

    model_curi = "lara:data/Data"
    data_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    data_type = models.ForeignKey(
        DataType,
        related_name="%(app_label)s_%(class)s_data_types_related",
        related_query_name="%(app_label)s_%(class)s_data_types_related_query",
        on_delete=models.CASCADE,
        blank=True,
        null=True,
        help_text="data type of this data item, e.g.  FASTA, AB1, AnIML, ...",
    )
    media_type = models.ForeignKey(
        MediaType,
        related_name="%(app_label)s_%(class)s_data_types_related",
        related_query_name="%(app_label)s_%(class)s_data_types_related_query",
        on_delete=models.CASCADE,
        blank=True,
        null=True,
        help_text="IANA data media type of this data item, e.g. txt/xml, txt/csv, ......",
    )
    namespace = models.ForeignKey(
        Namespace,
        related_name="%(app_label)s_%(class)s_namespaces_related",
        related_query_name="%(app_label)s_%(class)s_namespaces_related_query",
        on_delete=models.CASCADE,
        null=True,  # blank=True,
        # to_field='name',
        help_text="namespace of data",
    )

    name = models.TextField(blank=True, help_text="name of the data")
    version = models.TextField(
        blank=True,
        null=True,
        help_text="maj.min.patch version of this data set, e.g. 0.0.1",
    )
    name_display = models.TextField(
        blank=True,
        null=True,
        help_text="human readable name of the data, e.g. for display in figures, tables, ...",
    )
    name_full = models.TextField(
        unique=True,
        blank=True,
        null=True,
        help_text="fully qualified name of the data, including namespace and version; the name_full should only contain ASCII-alpha-numeric characters, no white-spaces, '-', '_' and '.' .",
    )
    # it might be more memory efficient to store the hash in binary format
    hash_sha256 = models.CharField(
        max_length=256,
        unique=True,
        blank=True,
        null=True,
        default=None,
        help_text="SHA256 hash of all data, to ensure data integrity",
    )
    hash_blockchain = models.CharField(
        max_length=512,
        unique=True,
        blank=True,
        null=True,
        default=None,
        help_text="SHA256 hash of all data, to ensure data integrity",
    )
    users = models.ManyToManyField(
        Entity,
        related_name="%(app_label)s_%(class)s_users_related",
        related_query_name="%(app_label)s_%(class)s_users_related_query",
        blank=True,
        help_text="entities, who can access/use this data - contributors/roles and fine grained access control shall be handled via acl and metadata.",
    )
    groups = models.ManyToManyField(
        Group,
        related_name="%(app_label)s_%(class)s_groups_related",
        related_query_name="%(app_label)s_%(class)s_groups_related_query",
        blank=True,
        help_text="groups accessing/using this data",
    )
    acl = models.JSONField(
        blank=True,
        null=True,
        help_text="access control list - fine grained data access control",
    )
    licenses = models.JSONField(
        blank=True,
        null=True,
        help_text="licenses of this data - with a JSON object, fine grained licenses can be defined, like embargo times, commercial use, academic use, ...",
    )
    datetime_created = models.DateTimeField(blank=True, null=True, help_text="date and time when data was created")
    datetime_last_modified = models.DateTimeField(
        blank=True, null=True, help_text="date and time when data was last modified"
    )
    method_instance = models.ForeignKey(
        MethodInstance,
        related_name="%(app_label)s_%(class)s_methods_related",
        related_query_name="%(app_label)s_%(class)s_methods_related_query",
        on_delete=models.CASCADE,
        blank=True,
        null=True,
        help_text="measurement or evaluation method, like SeqDNA, SeqProtein, SPabs, ...",
    )
    procedure_instance = models.ForeignKey(
        ProcedureInstance,
        related_name="%(app_label)s_%(class)s_procedures_related",
        related_query_name="%(app_label)s_%(class)s_procedures_related_query",
        on_delete=models.CASCADE,
        blank=True,
        null=True,
        help_text="measurement or evaluation procedure, like SeqDNA, SeqProtein, SPabs, ...",
    )
    process_instance = models.ForeignKey(
        ProcessInstance,
        related_name="%(app_label)s_%(class)s_processes_related",
        related_query_name="%(app_label)s_%(class)s_processes_related_query",
        on_delete=models.CASCADE,
        blank=True,
        null=True,
        help_text="process that generated the data, the process contains the procedures.",
    )

    data_json = models.JSONField(blank=True, null=True, help_text="JSON representation of the data")
    metadata = models.JSONField(
        blank=True,
        null=True,
        help_text="metadata in JSON-LD format, like units, visualisation factor/unit",
    )
    visualisations = models.ManyToManyField(
        "Visualisation",
        related_name="%(app_label)s_%(class)s_visualisation_related",
        related_query_name="%(app_label)s_%(class)s_visualisations_related_query",
        blank=True,
        help_text="visualisations of the data",
    )
    data_extra = models.ManyToManyField(
        ExtraData,
        related_name="%(app_label)s_%(class)s_data_extra_related",
        related_query_name="%(app_label)s_%(class)s_data_extra_related_query",
        blank=True,
        help_text="extra data, like additional information about data or the evaluation ...",
    )
    iri = models.URLField(
        blank=True,
        null=True,
        unique=True,
        max_length=512,
        help_text="International Resource Identifier to instance of OWL class: is used for semantic representation ",
    )
    pid = models.URLField(
        blank=True,
        null=True,
        unique=True,
        max_length=512,
        help_text="Persitent Identifier [PID/handle URI](https://www.handle.net/)",
    )
    doi = models.URLField(blank=True, null=True, help_text="Digital Object Identifier to the data")
    # PAC-ID:  https://github.com/ApiniLabs/PAC-ID
    pac_id = models.URLField(
        blank=True,
        null=True,
        unique=True,
        help_text="Publicly Addressable Content IDentifier is a globally unique identifier that operates independently of a central registry.",
    )
    resources_external = models.ManyToManyField(
        ExternalResource,
        related_name="%(app_label)s_%(class)s_external_resources_related",
        related_query_name="%(app_label)s_%(class)s_external_resources_related_query",
        blank=True,
        help_text="external resources, like literature, websites, manuals, ...",
    )
    file = models.FileField(
        upload_to="lara_data/",
        blank=True,
        null=True,
        help_text="rel. path/filename of dataset in filesystem or object storage",
    )
    thumbnail = models.TextField(blank=True, null=True, help_text="XML/SVG thumbnail / symbolising the data")
    tags = models.ManyToManyField(
        Tag,
        related_name="%(app_label)s_%(class)s_tags_related",
        related_query_name="%(app_label)s_%(class)s_tags_related_query",
        blank=True,
        help_text="tags",
    )
    description = models.TextField(blank=True, null=True, help_text="description of the data")
    remarks = models.TextField(blank=True, null=True, help_text="remarks about the data")
    search_vector = SearchVectorField(null=True)

    class Meta:
        verbose_name_plural = "Data"
        indexes = (GinIndex(fields=["search_vector"], name="description_search_idx"),)

    def __str__(self):
        return self.name or ""

    def __repr__(self):
        return self.name_display or ""

    # def save(self, force_insert=None, using=None): #force_insert=force_insert, using=using
    def save(self, *args, **kwargs):
        """
        Here we generate some default values for name_full
        """

        if self.version is None or self.version == "":
            self.version = "0.0.1"

        if self.hash_sha256 is None:
            if self.data_json is not None:
                to_hash = json.dumps(self.data_json)  # +  str(self.UUID) +
                self.hash_sha256 = hashlib.sha256(to_hash.encode("utf-8")).hexdigest()
            else:
                self.hash_sha256 = hashlib.sha256(str(self.iri).encode("utf-8")).hexdigest()

        if (self.name_display is not None or self.name_display != "") and (self.name is None or self.name == ""):
            self.name = self.name_display.strip().replace(" ", "_").lower() + f"_{self.version}"

        if self.name is None or self.name == "":
            if self.name_display is not None and self.name_display != "":
                self.name = f"{self.name_display.replace(' ', '_').lower().strip()}_{self.version}"
            else:
                self.name = "_".join(
                    (
                        timezone.now().strftime("%Y%m%d_%H%M%S"),
                        "data",
                        self.version,
                    )
                )
        else:
            self.name = self.name.replace(" ", "_").lower().strip()
        if self.name_full is None or self.name_full == "":
            if self.namespace is not None and self.version is not None:
                self.name_full = f"{self.namespace.uri}/" + self.name.replace(" ", "_")
            else:
                self.name_full = "_".join((self.name.replace(" ", "_"), self.version))

        if self.datetime_created is None:
            self.datetime_created = timezone.now()

        self.datetime_last_modified = timezone.now()

        if self.namespace is not None and self.iri is None:
            netloc = self.namespace.parse_uri().netloc
            path = self.namespace.parse_uri().path

            self.iri = f"{settings.LARA_PREFIXES['lara']}data/Data/{netloc}{path}/{self.name.replace(' ', '_').lower().strip()}_{str(self.data_id)[:8]}"

        super().save(*args, **kwargs)

    # def to_protobuf(self):
    #    return page_pb2.Data(name=self.name, data_json=self.data_json)


class DataSubset(ItemSubsetAbstr):
    """User or group defined subset of multi-step reactions."""

    model_curi = "lara:data/DataSubset"
    datasubset_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    data = models.ManyToManyField(
        Data,
        related_name="%(app_label)s_%(class)s_data_related",
        related_query_name="%(app_label)s_%(class)s_data_related_query",
        blank=True,
        help_text="data items",
        through="OrderedDataDataSubset",
    )


class OrderedDataDataSubset(models.Model):
    """Through model for the many-to-many relationship between DataSubset and Data.
    This class can be used to store the order of data in a subset"""

    model_curi = "lara:data/OrderedDataDataSubset"

    ordereddatadatasubset_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    data = models.ForeignKey(
        Data,
        related_name="%(app_label)s_%(class)s_data_related",
        related_query_name="%(app_label)s_%(class)s_data",
        on_delete=models.CASCADE,
        help_text="data in the subset",
    )

    data_subset = models.ForeignKey(
        DataSubset,
        related_name="%(app_label)s_%(class)s_datasubset_related",
        related_query_name="%(app_label)s_%(class)s_datasubset",
        on_delete=models.CASCADE,
        help_text="subset of data",
    )

    order = models.IntegerField(help_text="order of data in subset")

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["data", "data_subset"],
                name="%(app_label)s_%(class)s_data_datasubset_unique",
            ),
        ]
        ordering = ("order",)


class Evaluation(models.Model):
    """
    This class can be used to describe evaluation information.
    The name_full should only contain ASCII-alpha-numeric characters, no white-spaces, '-', '_' and '.' .
    For versioning semantic versioning (https://semver.org/lang/en/) shall be used.
     .. todo::
         - auto hashing
         - ensure that data and results cannot be modified ? (by hash checking)
         - method versioning
         - due to an unknown reason it is impossible to feedback on experiments (generates circular dependancy error).
           This should be fixed in a later version of the database
    """

    model_curi = "lara:data/Evaluation"
    evaluation_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    namespace = models.ForeignKey(
        Namespace,
        related_name="%(app_label)s_%(class)s_namespaces_related",
        related_query_name="%(app_label)s_%(class)s_namespaces_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="namespace of evaluation",
    )
    name_display = models.TextField(
        blank=True,
        null=True,
        help_text="human readable name of the evaluation, e.g. for display in figures, tables, ...",
    )
    name = models.TextField(unique=True, blank=True, help_text="name of the evaluation")

    version = models.TextField(
        blank=True,
        null=True,
        help_text="maj.min.patch version of this visualisation, e.g. 0.0.1",
    )

    hash_sha256 = models.CharField(
        max_length=256,
        unique=True,
        blank=True,
        null=True,
        default=None,
        help_text="SHA256 hash of all hashes of eval methods and data",
    )
    # parameters need to have a JSON scheme (!)
    parameters = models.JSONField(
        blank=True,
        null=True,
        help_text="parameters used for evaluation, e.g. left and right limits, etc.",
    )
    #  check if linked list can be used here ?
    # -> ltree will be modelled with the PostgreSQL ltree https://pypi.org/project/django-ltree/
    parent_evals = models.ManyToManyField(
        "self",
        related_query_name="%(app_label)s_%(class)s_parent_evals_related",
        blank=True,
        help_text="to define a tree/network of evaluations and to go back in the evaluation process",
    )
    # dependencies
    # eval tree/graph/network
    eval_method_instance = models.ForeignKey(
        MethodInstance,
        related_name="%(app_label)s_%(class)s_eval_methods_related",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="evaluation method",
    )
    eval_procedure_instance = models.ForeignKey(
        ProcedureInstance,
        related_name="%(app_label)s_%(class)s_eval_procs_related",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="evaluation procedure",
    )
    data_eval = models.ManyToManyField(
        Data,
        related_name="%(app_label)s_%(class)s_data_eval_related",
        related_query_name="%(app_label)s_%(class)s_data_eval_related_query",
        blank=True,
        help_text="all data that is used for this evaluation",
    )
    data_results = models.ManyToManyField(
        Data,
        related_name="%(app_label)s_%(class)s_data_results_related",
        related_query_name="%(app_label)s_%(class)s_data_results_related_query",
        blank=True,
        help_text="all data that is generated by this evaluation",
    )
    visualisations = models.ManyToManyField(
        "Visualisation",
        related_name="%(app_label)s_%(class)s_visualisations_related",
        related_query_name="%(app_label)s_%(class)s_visualisations_related_query",
        blank=True,
        help_text="visualisations of this evaluated data",
    )
    iri = models.URLField(
        blank=True,
        null=True,
        unique=True,
        help_text="International Resource Identifier - IRI: is used for semantic representation ",
    )
    pid = models.URLField(
        blank=True,
        null=True,
        unique=True,
        help_text="Persitent Identifier [PID/handle URI](https://www.handle.net/)",
    )
    doi = models.URLField(blank=True, null=True, help_text="Digital Object Identifier to the data")
    resources_external = models.ManyToManyField(
        ExternalResource,
        related_name="%(app_label)s_%(class)s_external_resources_related",
        related_query_name="%(app_label)s_%(class)s_external_resources_related_query",
        blank=True,
        help_text="external resources, like literature, websites, manuals, ...",
    )
    tags = models.ManyToManyField(
        Tag,
        related_name="%(app_label)s_%(class)s_tags_related",
        related_query_name="%(app_label)s_%(class)s_tags_related_query",
        blank=True,
        help_text="tags, characterising the evaluation",
    )
    caption = models.JSONField(blank=True, null=True, help_text="can be used as table caption")
    description = models.TextField(blank=True, null=True, help_text="description")
    datetime_created = models.DateTimeField(blank=True, null=True, help_text="date and time when data was created")
    datetime_last_modified = models.DateTimeField(
        blank=True, null=True, help_text="date and time when data was last modified"
    )
    search_vector = SearchVectorField(null=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["name", "namespace", "version"],
                name="%(app_label)s_%(class)s_name_namespace_version_unique",
            ),
        ]
        indexes = (GinIndex(fields=["search_vector"]),)

    def __str__(self):
        return self.name or ""

    def __repr__(self):
        return f"{self.name} {self.description}" or ""

    # def save(self, force_insert=None, using=None): #force_insert=force_insert, using=using
    def save(self, *args, **kwargs):
        """
        Here we generate some default values for name_full
        """

        if self.version is None or self.version == "":
            self.version = "0.0.1"

        if self.name is None or self.name == "":
            if self.name_display is not None and self.name_display != "":
                self.name = f"{self.name_display.replace(' ', '_').lower().strip()}_{self.version}"
            else:
                self.name = "_".join(
                    (
                        timezone.now().strftime("%Y%m%d_%H%M%S"),
                        "eval",
                        self.version,
                    )
                )
        else:
            self.name = self.name.replace(" ", "_").lower().strip()

        if self.namespace and not self.iri:
            netloc = self.namespace.parse_uri().netloc
            path = self.namespace.parse_uri().path

            self.iri = f"{settings.LARA_PREFIXES['lara']}data/Evaluation/{netloc}{path}/{self.name.replace(' ', '_').lower().strip()}_{self.evaluation_id!s}"  # noqa: E501

        if self.hash_sha256 is None:
            iri_hash = hashlib.sha256(str(self.iri).encode("utf-8")).hexdigest()
            # proc_hash = (
            #     self.eval_procedure_instance.hash_sha256
            #     if self.eval_procedure_instance.hash_sha256 is not None
            #     else hashlib.sha256(str(self.iri).encode("utf-8")).hexdigest()
            # )
            # data_eval_hash = "".join( [ datum.sha256  for datum in  self.data_eval.all() ] )
            to_hash = iri_hash  # + proc_hash + data_eval_hash + data_results_hash
            # -> to make it unique to every entry str(self.UUID) +
            self.hash_sha256 = hashlib.sha256(to_hash.encode("utf-8")).hexdigest()

        if self.datetime_created is None:
            self.datetime_created = timezone.now()

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)


class Visualisation(models.Model):
    """
    Information and MetaInformation about visualisation of Data shall be stored here, like the method/procedure of plotting.
    This can be used to specify default visualisation routines for certain data types,
    e.g. bacterial growth data can be plotted with a 2D growth plot or heatmap.
    The name_full should only contain ASCII-alpha-numeric characters, no white-spaces, '-', '_' and '.' .
    For versioning semantic versioning (https://semver.org/lang/en/) shall be used.
    """

    model_curi = "lara:data/Visualisation"
    visualisation_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    namespace = models.ForeignKey(
        Namespace,
        related_name="%(app_label)s_%(class)s_namespaces_related",
        related_query_name="%(app_label)s_%(class)s_namespaces_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="namespace of visualisation",
    )
    name_display = models.TextField(
        blank=True,
        null=True,
        help_text="human readable name of the visualisation, e.g. for display in figures, tables, ...",
    )
    name = models.TextField(unique=True, blank=True, help_text="name of the visualisation")
    version = models.TextField(
        blank=True,
        null=True,
        help_text="maj.min.patch version of this visualisation, e.g. 0.0.1",
    )
    data_type = models.ForeignKey(
        DataType,
        related_name="%(app_label)s_%(class)s_data_type_related",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="associate a data type to this method",
    )
    plotting_method_instance = models.ForeignKey(
        MethodInstance,
        related_name="%(app_label)s_%(class)s_plotting_methods_related",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="plotting method to generate a visualisation",
    )
    plotting_procedure_instance = models.ForeignKey(
        ProcedureInstance,
        related_name="%(app_label)s_%(class)s_plotting_procedures_related",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="plotting procedure to generate a visualisation",
    )
    rendering_components = models.JSONField(
        blank=True,
        null=True,
        help_text="custom html/css/javascript framework components, like Vue.js components or templates for rendering",
    )
    iri = models.URLField(
        blank=True,
        null=True,
        unique=True,
        max_length=512,
        help_text="International Resource Identifier - IRI: is used for semantic representation ",
    )
    tags = models.ManyToManyField(
        Tag,
        related_name="%(app_label)s_%(class)s_tags_related",
        related_query_name="%(app_label)s_%(class)s_tags_related_query",
        blank=True,
        help_text="tags to classify the visualisation",
    )
    caption = models.JSONField(blank=True, null=True, help_text="figure or table caption")
    resources_external = models.ManyToManyField(
        ExternalResource,
        related_name="%(app_label)s_%(class)s_external_resources_related",
        related_query_name="%(app_label)s_%(class)s_external_resources_related_query",
        blank=True,
        help_text="external resources, like literature, websites, manuals, ...",
    )
    thumbnail = models.TextField(blank=True, null=True, help_text="XML/SVG thumbnail / symbolising the data")
    image = models.ImageField(
        upload_to="data/images/",
        blank=True,
        null=True,
        help_text="location path/filename to image",
    )
    description = models.TextField(blank=True, null=True, help_text="description of the visualisation")
    datetime_created = models.DateTimeField(blank=True, null=True, help_text="date and time when data was created")
    datetime_last_modified = models.DateTimeField(
        blank=True, null=True, help_text="date and time when data was last modified"
    )
    order = models.IntegerField(blank=True, null=True, help_text="order of visualisation in a list")
    search_vector = SearchVectorField(null=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["name", "namespace", "version"],
                name="%(app_label)s_%(class)s_name_namespace_version_unique",
            ),
        ]
        indexes = (GinIndex(fields=["search_vector"], name="visualisation_description_idx"),)

    def __str__(self):
        return self.name or ""

    def __repr__(self):
        return self.name_display or ""

    # def save(self, force_insert=None, using=None): #force_insert=force_insert, using=using
    def save(self, *args, **kwargs):
        """
        Here we generate some default values for name_full
        """

        if self.version is None or self.version == "":
            self.version = "0.0.1"

        if self.name is None or self.name == "":
            if self.name_display is not None and self.name_display != "":
                self.name = f"{self.name_display.replace(' ', '_').lower().strip()}_{self.version}"
            else:
                self.name = "_".join(
                    (
                        timezone.now().strftime("%Y%m%d_%H%M%S"),
                        "vis",
                        self.version,
                    )
                )
        else:
            self.name = self.name.replace(" ", "_").lower().strip()

        if self.namespace and not self.iri:
            netloc = self.namespace.parse_uri().netloc
            path = self.namespace.parse_uri().path

            self.iri = f"{settings.LARA_PREFIXES['lara']}data/Visualisation/{netloc}{path}/{self.name.replace(' ', '_').lower().strip()}_{str(self.visualisation_id)[:8]}"

        if self.datetime_created is None:
            self.datetime_created = timezone.now()

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)
