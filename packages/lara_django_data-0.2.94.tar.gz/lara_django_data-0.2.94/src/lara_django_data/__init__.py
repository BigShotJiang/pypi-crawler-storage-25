from importlib.metadata import version as get_version

__version__ = get_version(__package__)

__version_info__ = tuple(
    int(num) if num.isdigit() else num
    for num in __version__.replace("-", ".", 1).split(".")
)
