"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_data views *

:details: lara_django_data views module.
         - add app specific urls here
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

import logging
import sys
from dataclasses import dataclass
from dataclasses import field

from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.shortcuts import get_object_or_404
from django.shortcuts import redirect
from django.shortcuts import render
from django.urls import reverse
from django.views.generic import CreateView
from django.views.generic import DeleteView
from django.views.generic import DetailView
from django.views.generic import ListView
from django.views.generic import UpdateView
from django_filters.views import FilterView
from django_tables2 import SingleTableView
from django_tables2.export.views import ExportMixin

from lara_django_data.tasks import evaluate_procdure_task
from .apps import LaraDjangoDataConfig

from lara_django_projects.models import Project

from .filters import DataFilterSet
from .forms import DataCreateForm
from .forms import DataUpdateForm
from .models import Data
from .models import Evaluation
from .tables import DataTable

# Create your  lara_django_data views here.

logger = logging.getLogger("django")


@dataclass
class DataMenu:
    menu_items: list[dict] = field(
        default_factory=lambda: [
            {"name": "Data", "path": "lara_django_data:data-list"},
        ]
    )

@dataclass
class SidebarMenu:
    menu_items: list[dict] = field(
        default_factory=lambda: [
            {"name": "Home", "path": "/", "icon": "home", "hover_class": "hover:bg-gray-500"},
            {"name": "Dashboard", "path": "/dashboard/", "icon": "dashboard", "hover_class": "hover:bg-gray-500"},
            {"name": "Apps", "path": "/apps/", "icon": "apps", "hover_class": "hover:bg-gray-500"},
            {"name": "Projects", "path": "/projects/", "icon": "projects", "hover_class": "hover:bg-red-500"},
            {"name": "Processes", "path": "/processes/", "icon": "processes", "hover_class": "hover:bg-orange-500"},
            {"name": "Data", "path": "/data/", "icon": "data", "hover_class": "hover:bg-sky-500"},
            {
                "name": "Devices",
                "path": "/material/device/list/",
                "icon": "devices",
                "hover_class": "hover:bg-amber-500",
            },
            {"name": "Parts", "path": "/material/part/list/", "icon": "parts", "hover_class": "hover:bg-amber-500"},
            {
                "name": "Labware",
                "path": "/material/labware/list/",
                "icon": "labware",
                "hover_class": "hover:bg-amber-500",
            },
            {"name": "Substances", "path": "/substances/", "icon": "substances", "hover_class": "hover:bg-teal-500"},
            {"name": "Organisms", "path": "/organisms/", "icon": "organisms", "hover_class": "hover:bg-lime-500"},
            {"name": "People", "path": "/people/", "icon": "people", "hover_class": "hover:bg-blue-500"},
        ]
    )


@dataclass
class BreadcrumbMenu:
    menu_items: list[dict] = field(
        default_factory=lambda: [
            {"name": "Home", "path": "/", "icon": "home", "hover_class": "hover:bg-gray-100 text-underline"},
            {"name": "Project1", "path": "/projects/", "icon": "folder", "hover_class": "hover:bg-gray-100 text-underline"},
        ]
    )

    def update_paths(self, path_map: dict):
        """
        Update the 'path' of menu_items based on a path_map dictionary.

        path_map should be a dict where keys are menu item names and values are new paths.
        """
        for item in self.menu_items:
            if item["name"] in path_map:
                item["path"] = path_map[item["name"]]

        return self

class DataTemplateSettingsMixin:
    """Mixin to provide common template settings for project views."""

    def get_context_data(self, **kwargs):  # noqa: D102
        context = super().get_context_data(**kwargs)
        projects = Project.objects.exclude(parent=None)
        context["projects"] = projects
        context["projects_latest"] = projects.order_by("-datetime_last_modified")  # projects_latest
        context["menu_items"] = DataMenu().menu_items
        context["app_color"] = LaraDjangoDataConfig.lara_app_color
        context["sidebar_menu_items"] = SidebarMenu().menu_items
        # context["sparql_server_url"] = f"http://{settings.VIRTUOSO_HOST}:{settings.VIRTUOSO_ADMIN_PORT}/sparql/"

        return context


class DataSingleTableView(DataTemplateSettingsMixin, SingleTableView, FilterView, ExportMixin):
    model = Data
    table_class = DataTable
    filterset_class = DataFilterSet

    export_formats = ("csv",)

    # fields = ('name', 'name_full', 'URL', 'pid', 'iri', 'manufacturer', 'model_no', 'product_type', 'type_barcode', 'product_no', 'weight', 'specifications', 'spec_json', 'spec_doc', 'brochure', 'quickstart', 'manual', 'service_manual', 'thumbnail', 'image', 'description', 'data_id', 'data_class', 'shape')

    template_name = "lara_django_data/list.html"
    success_url = "/data/data/list"

    def get_queryset(self):
        return super().get_queryset()  # .select_related("entity_class")

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Data - List"
        context["create_link"] = "lara_django_data:data-create"
        context["menu_items"] = DataMenu().menu_items
        return context


class DataDetailView(DataTemplateSettingsMixin, DetailView):
    model = Data

    template_name = "lara_django_data/data_detail.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Data - Details"
        context["update_link"] = "lara_django_data:data-update"
        context["menu_items"] = DataMenu().menu_items
        return context


class DataCreateView(CreateView):
    model = Data

    template_name = "lara_django_data/create_form.html"
    form_class = DataCreateForm
    success_url = "/data/data/list"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Data - Create"
        return context


class DataUpdateView(UpdateView):
    model = Data

    template_name = "lara_django_data/update_form.html"
    form_class = DataUpdateForm
    success_url = "/data/data/list"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Data - Update"
        context["delete_link"] = "lara_django_data:data-delete"
        return context


class DataDeleteView(DeleteView):
    model = Data

    template_name = "lara_django_data/delete_form.html"
    success_url = "/data/data/list"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Data - Delete"
        context["delete_link"] = "lara_django_data:data-delete"
        return context


def evaluate_data(request, pk):

    evaluation = get_object_or_404(Evaluation, pk=pk)

    try:
        procedure_eval = evaluation.eval_procedure_instance.procedure_json["python"][
            "src"
        ]
    except AttributeError:
        logger.exception(
            "ERROR: no procedure associated with evaluation: %s", evaluation.name
        )

    else:
        # Call the task asynchronously
        evaluate_procdure_task.delay(procedure_eval)

        # return a "success" message
        return HttpResponse(
            f"Evaluation {evaluation.name} started with procedure: {procedure_eval}"
        )

        # return render(request, 'lara_django_data/evaluate.html', {'evaluation': evaluation, 'data': data})


def visualise_data(request, pk):

    visualisation = get_object_or_404(Evaluation, pk=pk)

    try:
        procedure_eval = visualisation.plotting_procedure_instance.procedure_json["python"][
            "src"
        ]
    except AttributeError:
        logger.exception(
            "ERROR: no procedure associated with evaluation: %s", visualisation.name
        )

    else:
        # Call the task asynchronously
        evaluate_procdure_task.delay(procedure_eval)

        # return a "success" message
        return HttpResponse(
            f"Evaluation {visualisation.name} started with procedure: {procedure_eval}"
        )

        # return render(request, 'lara_django_data/evaluate.html', {'evaluation': evaluation, 'data': data})

## old


class IndexView(ListView):
    model = Data
    template_name = "lara_data/index.html"

    def get_queryset(self):
        """Return the lastest 25 data sets."""
        return Data.objects.order_by("-datetime_start")[:25]


class DataListView(ListView):
    model = Data

    def get_context_data(self, **kwargs):
        context = super(DataListView, self).get_context_data(**kwargs)

        context["table_caption"] = "List of all data"
        return context


def searchForm(request):
    return render(request, "lara_data/search.html", context={})


def search(request):
    search_string = request.POST["search"]

    try:
        data_list = []
        curr_data = Data.objects.get(device__name=search_string)
        data_list.append(curr_data)

    except ValueError as err:
        sys.stderr.write("{}".format(err))
        # ~ return render(request, 'polls/detail.html', {
        # ~ 'question': question,
        # ~ 'error_message': "You didn't select a choice.",
        # ~ })
    else:
        context = {"data_list": data_list}
        return render(request, "lara_data/results.html", context)
        # return HttpResponseRedirect(reverse('lara_data:results', args=(lara_device_list,)))


def results(request, data_list):
    # question = get_object_or_404(Question, pk=question_id)
    context = {"data_list": data_list}
    return render(request, "lara_data/results.html", context)


class DataDetailsView(DetailView):
    model = Data


def dataDetails(request, data_id):
    curr_data = get_object_or_404(Data, pk=data_id)
    context = {"data": curr_data}
    return render(request, "lara_data/data.html", context)
