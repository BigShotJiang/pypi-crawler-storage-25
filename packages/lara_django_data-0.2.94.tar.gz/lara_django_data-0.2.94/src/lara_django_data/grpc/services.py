## generated with django-socio-grpc generateprpcinterface lara_django_data  (LARA-version)

# to generate the corresponding .proto fiile run:
# lara-django-dev generateproto -v 3 -nopb2 -d protos
# copy the generated .proto file to api/proto/lara_django_data_grpc/v1/lara_django_data.proto
# cd api and run:
# buf generate proto
# this will generate the new gRPC api (in api/grpc/python/grpc/lara_django_data_grpc/v1/lara_django_data_pb2.py )

import asyncio
import io
import grpc
import logging

from django_socio_grpc import generics, mixins
from django_socio_grpc.decorators import grpc_action
from asgiref.sync import sync_to_async

from django_filters.rest_framework import DjangoFilterBackend
from django_socio_grpc.grpc_actions.placeholders import LookupField

from lara_django_base.grpc.mixins import (
    AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,
)

from .serializers import (
    ExtraDataProtoSerializer,
    VisualisationProtoSerializer,
    DataProtoSerializer,
    DataSubsetProtoSerializer,
    DataByNameProtoSerializer,
    EvaluationProtoSerializer,
)

from ..filters import (
    ExtraDataFilterSet,
    DataFilterSet,
    EvaluationFilterSet,
    VisualisationFilterSet,
)

from lara_django_data.models import (
    ExtraData,
    Visualisation,
    Data,
    DataSubset,
    Evaluation,
)

import lara_django_data_grpc.v1.lara_django_data_pb2 as lara_django_data_pb2

logger = logging.getLogger(__name__)


class ExtraDataService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    pb2 = lara_django_data_pb2
    queryset = ExtraData.objects.all()
    serializer_class = ExtraDataProtoSerializer
    filterset_class = ExtraDataFilterSet


class VisualisationService(
    generics.AsyncModelService,
    AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,
):
    pb2 = lara_django_data_pb2
    queryset = Visualisation.objects.all()
    serializer_class = VisualisationProtoSerializer
    filterset_class = VisualisationFilterSet


class DataService(
    generics.AsyncModelService,
    mixins.AsyncStreamModelMixin,
    AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,
):
    pb2 = lara_django_data_pb2
    # model = Data
    queryset = Data.objects.all().order_by("name")
    serializer_class = DataProtoSerializer
    # filter_backends = [DjangoFilterBackend]

    filterset_class = DataFilterSet
    # filterset_fields = ["name", "name_full"]
    search_fields = ["name", "name_display"]

    # def get_lookup_request_field(self, queryset=None):
    #     if self.action == "RetrieveByName":
    #         return "name"
    #     elif self.action == "RetrieveByFullName":
    #         return "name_full"
    #     #elif self.action == "SearchData":
    #     #    return "name_full"
    #     return super().get_lookup_request_field(queryset=queryset)

    # @grpc_action(
    #     request=[{"name": "name", "type": "string"},
    #              {"name": "data_chunk", "type": "bytes"}],
    #     request_stream=True
    # )
    # def CreateFS(self, request, context):
    #     """Creates file in file storage"""

    # data list stream
    # @grpc_action(
    #     response=[
    #         {
    #             "name": "results",
    #             "type": "DataResponse",
    #             "cardinality": "repeated",
    #         }
    #     ],
    #     response_stream=True,
    # )
    # async def ListStream(self, request, context):
    #     queryset = self.filter_queryset(self.get_queryset())
    #     # serializer = self.get_serializer(queryset, many=True)
    #     # for item in serializer.message.data_list:
    #     #     yield item
    #     for item in queryset:
    #         serializer = await self.get_serializer(item)
    #         yield serializer.message


# class DataSearchService(
#         mixins.ListModelMixin,
#         mixins.RetrieveModelMixin,
#         generics.GenericService,
#     ):
#     filter_backends = [DjangoFilterBackend]

#     @grpc_action(
#         request=[{"name": "name", "type": "string"}],
#         use_response_list=True,
#         response=DataProtoSerializer
#     )
#     def RetrieveByName(self, request, context):

#         print("##### +++++ request:", request)
#         print("##### +++++ request n :", request.name)
#         #queryset = self.filter_queryset(self.get_queryset())
#         #queryset = Data.objects.filter(name=request.name)

#         # for item in queryset:
#         #     print("##### +++++ queryset:", item.name)

#         #instance = Data.objects.get(name=request.name)
#         #serializer = self.get_serializer(instance)

#         # return serializer.message
#         queryset = Data.objects.filter(name=request.name)
#         serializer = self.get_serializer(queryset, many=True)

#         return serializer.message


#     @grpc_action(
#         request=[{"name": "name_full", "type": "string"}],
#         response=DataProtoSerializer
#     )
#     def RetrieveByFullName(self, request, context):

#         print("##### +++++ request:", request)
#         print("##### +++++ request n :", request.name_full)
#         #queryset = self.filter_queryset(self.get_queryset())
#         #queryset = Data.objects.filter(name=request.name)

#         instance = Data.objects.get(name_full=request.name_full)
#         serializer = self.get_serializer(instance)

#         return serializer.message

#     @grpc_action(
#         request=[{"name": "name", "type": "string"},
#                  {"name": "name_full", "type": "string"}],
#         use_response_list=True,
#         response=DataProtoSerializer
#     )
#     def SearchData(self, request, context):
#         print("##### +++++ request:", request)
#         print("##### +++++ context:", context)
#         queryset = self.filter_queryset(self.get_queryset())
#         serializer = self.get_serializer(queryset, many=True)
#         return serializer.message


class DataSubsetService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = DataSubset.objects.all()
    serializer_class = DataSubsetProtoSerializer
    # filterset = DataSubsetFilterSet


class EvaluationService(
    generics.AsyncModelService,
    mixins.AsyncStreamModelMixin,
    AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,
):
    pb2 = lara_django_data_pb2
    queryset = Evaluation.objects.all()
    serializer_class = EvaluationProtoSerializer
    filterset_class = EvaluationFilterSet
