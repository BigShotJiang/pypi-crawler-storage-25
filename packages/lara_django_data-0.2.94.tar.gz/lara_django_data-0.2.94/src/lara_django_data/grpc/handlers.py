# generated with django-socio-grpc generateprpcinterface lara_django_data  (LARA-version)

# import logging
from django_socio_grpc.services.app_handler_registry import AppHandlerRegistry
from lara_django_data.grpc.services import (
    ExtraDataService,
    VisualisationService,
    DataService,
    DataSubsetService,
    EvaluationService,
)


def grpc_handlers(server):
    app_registry = AppHandlerRegistry("lara_django_data", server)

    # monkey patching to import the grpc module from the API
    app_registry.get_grpc_module = lambda: "lara_django_data_grpc.v1"

    app_registry.register(ExtraDataService)

    app_registry.register(VisualisationService)

    app_registry.register(DataService)

    app_registry.register(DataSubsetService)

    app_registry.register(EvaluationService)
