## generated with django-socio-grpc generateprpcinterface lara_django_data  (LARA-version)

import logging
from google.protobuf.message import Message
from rest_framework.serializers import UUIDField, PrimaryKeyRelatedField
from django_socio_grpc import proto_serializers

from lara_django_base.models import Namespace, DataType, ExtraDataAbstr, MediaType, Namespace, Tag, ExternalResource

from lara_django_data.models import ExtraData, Visualisation, Data, DataSubset, Evaluation

from lara_django_people.models import Entity, Group
from lara_django_processes.models import Method, Process, Procedure, MethodInstance, ProcessInstance, ProcedureInstance

from lara_django_people.grpc.serializers import EntityProtoSerializer

import lara_django_data_grpc.v1.lara_django_data_pb2 as lara_django_data_pb2


class ExtraDataProtoSerializer(proto_serializers.ModelProtoSerializer):
    data_type = PrimaryKeyRelatedField(
        queryset=DataType.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    media_type = PrimaryKeyRelatedField(
        queryset=MediaType.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )

    class Meta:
        model = ExtraData
        proto_class = lara_django_data_pb2.ExtraDataResponse

        proto_class_list = lara_django_data_pb2.ExtraDataListResponse

        fields = "__all__"  # [data_type', namespace', URI', text', XML', JSON', bin', media_type', IRI', URL', description', file', image']


class VisualisationProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
    )
    data_type = PrimaryKeyRelatedField(
        queryset=DataType.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    plotting_method_instance = PrimaryKeyRelatedField(
        queryset=MethodInstance.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    plotting_procedure_instance = PrimaryKeyRelatedField(
        queryset=ProcedureInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True, required=False, allow_null=True
    )
    resources_external = PrimaryKeyRelatedField(
        queryset=ExternalResource.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    class Meta:
        model = Visualisation
        proto_class = lara_django_data_pb2.VisualisationResponse

        proto_class_list = lara_django_data_pb2.VisualisationListResponse

        fields = "__all__"  # [namespace', name', version', name_full', data_type', plotting_method_instance', plotting_procedure_instance', rendering_html_template', rendering_css_template', rendering_component', IRI', caption', thumbnail', description']


class DataProtoSerializer(proto_serializers.ModelProtoSerializer):
    data_type = PrimaryKeyRelatedField(
        queryset=DataType.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    media_type = PrimaryKeyRelatedField(
        queryset=MediaType.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )

    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
    )

    method_instance = PrimaryKeyRelatedField(
        queryset=MethodInstance.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    process_instance = PrimaryKeyRelatedField(
        queryset=ProcessInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    procedure_instance = PrimaryKeyRelatedField(
        queryset=ProcedureInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )

    users = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    groups = PrimaryKeyRelatedField(
        queryset=Group.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    visualisations = PrimaryKeyRelatedField(
        queryset=Visualisation.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True, required=False, allow_null=True
    )
    resources_external = PrimaryKeyRelatedField(
        queryset=ExternalResource.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    # work-around for optional fields, s. https://github.com/socotecio/django-socio-grpc/issues/171
    # def message_to_data(self, message: Message) -> dict:
    #     data = super().message_to_data(message)
    #     optional_fields = filter(lambda field: field.has_presence, message.DESCRIPTOR.fields)
    #     optional_field_names = [field.name for field in optional_fields]
    #     for field_name, field in self.fields.items():
    #         if (
    #             field_name in data
    #             and field_name in optional_field_names
    #             and not message.HasField(field_name)
    #             and not field.allow_null
    #         ):
    #             del data[field_name]
    #     return data

    class Meta:
        model = Data
        proto_class = lara_django_data_pb2.DataResponse

        proto_class_list = lara_django_data_pb2.DataListResponse

        # fields = ['data_id', 'data_type', 'media_type', 'namespace', 'name', 'version', 'name_full', 'hash_sha256',
        #           'datetime_created', 'method_instance', 'process_instance', 'procedure_instance','visualisations', 'data_json', 'data_extra', 'metadata',
        #           'iri', 'pid', 'doi', 'users', 'groups', 'file', 'resources_external', 'thumbnail', 'tags', 'description']

        fields = "__all__"  # [data_type', media_type', namespace', name', version', name_full',  hash_sha256', datetime_created', method', process', data_json', metadata', URI', IRI', handle', doi', file', literature', thumbnail', description']


class DataByNameProtoSerializer(proto_serializers.ModelProtoSerializer):
    # namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"), )
    results = DataProtoSerializer(many=True)

    class Meta:
        model = Data

        proto_class = lara_django_data_pb2.DataResponse

        proto_class_list = lara_django_data_pb2.DataListResponse

        # fields = '__all__' # [data_type', media_type', namespace', name', version', name_full', hash_sha256', datetime_created', method', process', data_json', metadata', URI', IRI', handle', doi', file', literature', thumbnail', description']

        fields = [
            "results",
            "data_id",
            "data_type",
            "media_type",
            "namespace",
            "name",
            "version",
            "name_full",
            "hash_sha256",
            "datetime_created",
            "method",
            "process",
            "data_json",
            "metadata",
            "iri",
            "pid",
            "doi",
            "file",
            "resources_external",
            "thumbnail",
            "description",
        ]


class DataSubsetProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
    )
    entity = PrimaryKeyRelatedField(queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    group = PrimaryKeyRelatedField(
        queryset=Group.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    data = PrimaryKeyRelatedField(
        queryset=Data.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True, required=False, allow_null=True
    )

    class Meta:
        model = DataSubset
        proto_class = lara_django_data_pb2.DataSubsetResponse

        proto_class_list = lara_django_data_pb2.DataSubsetListResponse

        fields = "__all__"


class EvaluationProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
    )
    eval_method_instance = PrimaryKeyRelatedField(
        queryset=MethodInstance.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    eval_procedure_instance = PrimaryKeyRelatedField(
        queryset=ProcedureInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    parent_evals = PrimaryKeyRelatedField(
        queryset=Evaluation.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    data_eval = PrimaryKeyRelatedField(
        queryset=Data.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    data_results = PrimaryKeyRelatedField(
        queryset=Data.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    visualisations = PrimaryKeyRelatedField(
        queryset=Visualisation.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True, required=False, allow_null=True
    )
    resources_external = PrimaryKeyRelatedField(
        queryset=ExternalResource.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    class Meta:
        model = Evaluation
        proto_class = lara_django_data_pb2.EvaluationResponse

        proto_class_list = lara_django_data_pb2.EvaluationListResponse

        fields = "__all__"  # [namespace', name', name_full', version', hash_sha256', parameters', eval_method', eval_procedure', URI', IRI', handle', doi', literature', caption', description']
