## generated with django-socio-grpc generateprpcinterface lara_django_data  (LARA-version)

# to generate the corresponding .proto fiile run:
# lara-django-dev generateproto -v 3 -nopb2 -d protos
# copy the generated .proto file to api/proto/lara_django_data_grpc/v1/lara_django_data.proto
# cd api and run:
# buf generate proto
# this will generate the new gRPC api (in api/grpc/python/grpc/lara_django_data_grpc/v1/lara_django_data_pb2.py )

import asyncio
import io
import grpc
import logging

from django_socio_grpc import generics, mixins
from django_socio_grpc.decorators import grpc_action
from asgiref.sync import sync_to_async

from django_filters.rest_framework import DjangoFilterBackend
from django_socio_grpc.grpc_actions.placeholders import LookupField

from .serializers import (
    ExtraDataProtoSerializer,
    VisualisationProtoSerializer,
    DataProtoSerializer,
    DataSubsetProtoSerializer,
    DataByNameProtoSerializer,
    EvaluationProtoSerializer,
)

from ..filters import ExtraDataFilterSet, DataFilterSet, EvaluationFilterSet, VisualisationFilterSet

from ..tasks import extract_metadata_from_parquet_file

from lara_django_data.models import ExtraData, Visualisation, Data, DataSubset, Evaluation

import lara_django_data_grpc.v1.lara_django_data_pb2 as lara_django_data_pb2

logger = logging.getLogger(__name__)

class ExtraDataService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = ExtraData.objects.all()
    serializer_class = ExtraDataProtoSerializer
    filterset_class = ExtraDataFilterSet


class VisualisationService(generics.AsyncModelService):
    queryset = Visualisation.objects.all()
    serializer_class = VisualisationProtoSerializer
    filterset_class = VisualisationFilterSet


class DataService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = Data.objects.all().order_by("name_full")
    serializer_class = DataProtoSerializer
    # filter_backends = [DjangoFilterBackend]

    filterset_class = DataFilterSet
    # filterset_fields = ["name", "name_full"]
    search_fields = ["name", "name_full"]

    # def get_lookup_request_field(self, queryset=None):
    #     if self.action == "RetrieveByName":
    #         return "name"
    #     elif self.action == "RetrieveByFullName":
    #         return "name_full"
    #     #elif self.action == "SearchData":
    #     #    return "name_full"
    #     return super().get_lookup_request_field(queryset=queryset)

    # @grpc_action(
    #     request=[{"name": "name", "type": "string"},
    #              {"name": "data_chunk", "type": "bytes"}],
    #     request_stream=True
    # )
    # def CreateFS(self, request, context):
    #     """Creates file in file storage"""

    # data list stream
    # @grpc_action(
    #     response=[
    #         {
    #             "name": "results",
    #             "type": "DataResponse",
    #             "cardinality": "repeated",
    #         }
    #     ],
    #     response_stream=True,
    # )
    # async def ListStream(self, request, context):
    #     queryset = self.filter_queryset(self.get_queryset())
    #     # serializer = self.get_serializer(queryset, many=True)
    #     # for item in serializer.message.data_list:
    #     #     yield item
    #     for item in queryset:
    #         serializer = await self.get_serializer(item)
    #         yield serializer.message

    @grpc_action(
        request=[{"name": "filename", "type": "string"},
                 {"name": "update_item_id", "type": "string"},
                 {"name": "data", "type": "bytes"}],
        request_name="FileChunk",
        response=[{"name": "success", "type": "bool"}],
        response_name="UploadStatus",
        request_stream=True,
    )
    async def UploadData(self, request, context):
        # logger.info(f"File upload started:")

        filename = ""
        try:
            with io.BytesIO() as f:
                async for file_chunk in request:
                    filename = file_chunk.filename
                    # logger.info("Reading file chunk:", len(file_chunk.data))
                    f.write(file_chunk.data)
            
                queryset = self.get_queryset()

                data = await sync_to_async(queryset.get)(data_id=file_chunk.update_item_id) 

                # logger.info("--- data found:", data.name_full)
                res = await sync_to_async(data.file.save)(filename, f, save=True)
                
                f.seek(0)
                file_content = f.getvalue()
                if filename.endswith(".parquet"):
                    extract_metadata_from_parquet_file.delay(file_content)
            
            # logger.info(f"File upload successful: {len(file_content)} bytes")
            return lara_django_data_pb2.UploadStatus(success=True)

        except Exception as e:
            logger.exception(f"Document ({filename}) upload has failed {e}")
            return lara_django_data_pb2.UploadStatus(success=True)
        
    @grpc_action(
        request=[{"name": "item_id", "type": "string"},
                 {"name": "chunk_size", "type": "uint64"},],
        request_name="FileDownloadInfo",
        response=[{"name": "filename", "type": "string"},
                  {"name": "data", "type": "bytes"},
                  {"name": "success", "type": "bool"}],
        response_name="FileDownloadChunk",
        response_stream=True,
    )
    async def DownloadData(self, request, context):
        CHUNK_SIZE = 1024 * 1024  # 1 MB

        logger.info(f"File download started:")

        filename = ""
        print("##### +++++ request:", request.item_id, request.chunk_size)

        queryset = self.get_queryset()
        instance = await sync_to_async(queryset.get)(data_id=request.item_id)
        file_field = instance.file
        filename = file_field.name

        try:
            with file_field.open("rb") as f:
                while True:
                    chunk = f.read(CHUNK_SIZE)
                    if not chunk:
                        break
                    yield lara_django_data_pb2.FileDownloadChunk(filename=filename, data=chunk, success=True)

            logger.info(f"File download successful: {filename}")
        except Data.DoesNotExist:
            context.abort(grpc.StatusCode.NOT_FOUND, "File not found.")
        except Exception as e:
            logger.exception(f"Document ({filename}) upload has failed {e}")
            #return lara_django_data_pb2.UploadStatus(success=False)
            context.abort(grpc.StatusCode.INTERNAL, str(e))


# class DataSearchService(
#         mixins.ListModelMixin,
#         mixins.RetrieveModelMixin,
#         generics.GenericService,
#     ):
#     filter_backends = [DjangoFilterBackend]

#     @grpc_action(
#         request=[{"name": "name", "type": "string"}],
#         use_response_list=True,
#         response=DataProtoSerializer
#     )
#     def RetrieveByName(self, request, context):

#         print("##### +++++ request:", request)
#         print("##### +++++ request n :", request.name)
#         #queryset = self.filter_queryset(self.get_queryset())
#         #queryset = Data.objects.filter(name=request.name)

#         # for item in queryset:
#         #     print("##### +++++ queryset:", item.name)

#         #instance = Data.objects.get(name=request.name)
#         #serializer = self.get_serializer(instance)

#         # return serializer.message
#         queryset = Data.objects.filter(name=request.name)
#         serializer = self.get_serializer(queryset, many=True)

#         return serializer.message


#     @grpc_action(
#         request=[{"name": "name_full", "type": "string"}],
#         response=DataProtoSerializer
#     )
#     def RetrieveByFullName(self, request, context):

#         print("##### +++++ request:", request)
#         print("##### +++++ request n :", request.name_full)
#         #queryset = self.filter_queryset(self.get_queryset())
#         #queryset = Data.objects.filter(name=request.name)

#         instance = Data.objects.get(name_full=request.name_full)
#         serializer = self.get_serializer(instance)

#         return serializer.message

#     @grpc_action(
#         request=[{"name": "name", "type": "string"},
#                  {"name": "name_full", "type": "string"}],
#         use_response_list=True,
#         response=DataProtoSerializer
#     )
#     def SearchData(self, request, context):
#         print("##### +++++ request:", request)
#         print("##### +++++ context:", context)
#         queryset = self.filter_queryset(self.get_queryset())
#         serializer = self.get_serializer(queryset, many=True)
#         return serializer.message

class DataSubsetService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = DataSubset.objects.all()
    serializer_class = DataSubsetProtoSerializer
    # filterset = DataSubsetFilterSet

class EvaluationService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = Evaluation.objects.all()
    serializer_class = EvaluationProtoSerializer
    filterset_class = EvaluationFilterSet
