"""
_____________________________________________________________________.

:PROJECT: LARAsuite

*lara_django_data Model Context Protocol (MCP) handler *

:details: lara_django_data Model Context Protocol (MCP) handler.

:authors: mark doerr <mark.doerr@uni-greifswald.de>

________________________________________________________________________
"""

from mcp_server import ModelQueryToolset

from .models import (
    BlockchainHashes,
    Data,
    DataSubset,
    Evaluation,
    ExtraData,
    OrderedDataDataSubset,
    Visualisation,
)


class ExtraDataQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `ExtraData`."""

    model = ExtraData


class BlockchainHashesQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `BlockchainHashes`."""

    model = BlockchainHashes


class DataQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `Data`."""

    model = Data


class DataSubsetQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `DataSubset`."""

    model = DataSubset


class OrderedDataDataSubsetQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `OrderedDataDataSubset`."""

    model = OrderedDataDataSubset


class EvaluationQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `Evaluation`."""

    model = Evaluation


class VisualisationQueryTool(ModelQueryToolset):
    """MCP query tool exposing read/query operations for `Visualisation`."""

    model = Visualisation
