"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_data admin *

:details: lara_django_data admin module admin backend configuration.
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - run "lara-django-dev tables_generator lara_django_data >> tables.py" to update this file
________________________________________________________________________
"""

# django Tests s. https://docs.djangoproject.com/en/4.1/topics/testing/overview/ for lara_django_data
# generated with django-extensions tests_generator  lara_django_data > tests.py (LARA-version)

import logging
from django.utils.html import format_html

import django_tables2 as tables


from .models import ExtraData, Visualisation, Data, Evaluation


class ExtraDataTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_data:extradata-detail', [tables.A('pk')]))

    class Meta:
        model = ExtraData

        fields = (
            "data_type",
            "namespace",
            "uri",
            "data_json",
            "media_type",
            "iri",
            "url",
            "description",
            "file",
            "image",
        )


class VisualisationTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_data:visualisation-detail', [tables.A('pk')]))

    class Meta:
        model = Visualisation

        fields = (
            "namespace",
            "name",
            "version",
            "data_type",
            "plotting_method",
            "plotting_procedure",
            "iri",
            "caption",
            "thumbnail",
            "description",
        )


class DataTable(tables.Table):
    # adding link to column <column-to-be-linked>
    name = tables.Column(linkify=("lara_django_data:data-detail", [tables.A("pk")]))

    edit = tables.Column(
        empty_values=(),
        verbose_name="Edit",
        default="Edit",
        linkify={
            "viewname": "lara_django_data:data-update",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"class": "btn btn-warning btn-sm"}},
    )

    delete = tables.Column(
        empty_values=(),
        verbose_name="Delete",
        default="Delete",
        linkify={
            "viewname": "lara_django_data:data-delete",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"role": "button", "class": "inline-block rounded bg-red-500 text-neutral-50 hover:bg-red-600  focus:bg-red-800  active:bg-red-700  px-6 pb-2 pt-2.5 text-xs font-medium uppercase leading-normal transition duration-150 ease-in-out focus:outline-none focus:ring-0"}},
    )

    def render_edit(self):
        return format_html('<svg class="i fill-white" width="18" height="18" role="img" aria-label="edit"><use xlink:href="/static/lara_django_base/icons/symbols.svg#edit"></use></svg>')

    def render_delete(self):
        return format_html('<svg class="i fill-white" width="18" height="18" role="img" aria-label="delete"><use xlink:href="/static/lara_django_base/icons/symbols.svg#delete"></use></svg>')

    class Meta:
        model = Data

        fields = (
            "thumbnail",
            "name",
            "namespace",
            "version",
            "data_type",
            "datetime_created",
            "method",
            "process",
            "file",
            "description",
            "edit",
            "delete",
        )


class EvaluationTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_data:evaluation-detail', [tables.A('pk')]))

    class Meta:
        model = Evaluation

        fields = (
            "namespace",
            "name",
            "version",
            "hash_sha256",
            "parameters",
            "eval_method",
            "eval_procedure",
            "uri",
            "iri",
            "caption",
            "description",
        )
