"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_data admin *

:details: lara_django_data admin module admin backend configuration.
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - run "lara-django-dev admin_generator lara_django_data >> admin.py" to update this file
________________________________________________________________________
"""

# -*- coding: utf-8 -*-
from django.contrib import admin

from .models import ExtraData, Visualisation, Data, Evaluation


@admin.register(ExtraData)
class ExtraDataAdmin(admin.ModelAdmin):
    list_display = (
        "name_full",
        "namespace",
        "data_type",
        "description",
        "media_type",
        "file",
        "image",
        "extradata_id",
    )
    list_filter = ("data_type", "namespace", "media_type")


@admin.register(Visualisation)
class VisualisationAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "namespace",
        "version",
        "data_type",
        "description",
        "visualisation_id",
    )
    list_filter = (
        "namespace",
        "data_type",
        "plotting_method_instance",
        "plotting_procedure_instance",
    )
    raw_id_fields = ("tags",)
    search_fields = ()


@admin.register(Data)
class DataAdmin(admin.ModelAdmin):
    list_display = (
        "name_full",
        "name",
        "namespace",
        "data_type",
        "version",
        "datetime_created",
        "file",
        "description",
        "data_id",
    )
    list_filter = (
        "data_type",
        "media_type",
        "namespace",
        "datetime_created",
        "process_instance",
    )
    raw_id_fields = ("visualisations", "tags", "users", "groups", "data_extra")
    search_fields = ()


@admin.register(Evaluation)
class EvaluationAdmin(admin.ModelAdmin):
    list_display = (
        "namespace",
        "name",
        "version",
        "eval_method_instance",
        "eval_procedure_instance",
        "caption",
        "description",
        "evaluation_id",
    )
    list_filter = ("namespace", "eval_method_instance", "eval_procedure_instance")
    raw_id_fields = (
        "parent_evals",
        "data_eval",
        "data_results",
        "visualisations",
        "tags",
    )
    search_fields = ()
