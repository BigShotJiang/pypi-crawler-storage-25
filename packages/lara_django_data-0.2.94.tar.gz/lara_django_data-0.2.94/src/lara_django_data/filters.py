"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_data filter app *

:details: lara_django_data filter app. 
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

from django_filters.rest_framework import FilterSet, CharFilter, DateRangeFilter

from .models import ExtraData, Visualisation, Evaluation, Data


class ExtraDataFilterSet(FilterSet):
    class Meta:
        model = ExtraData
        fields = {
            "namespace__uri": ["exact", "contains"],
            "name_display": ["exact", "contains"],
            "name": ["exact", "contains"],
            "name_full": ["exact", "contains"],
            "iri": ["exact", "contains"],
            "url": ["exact", "contains"],
            "datetime_created": ["lt", "gt", "exact", "range"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
            "description": ["exact", "contains"],
        }


class VisualisationFilterSet(FilterSet):
    class Meta:
        model = Visualisation
        fields = {
            "namespace__uri": ["exact", "contains"],
            # "name_display": ["exact", "contains"],
            "name": ["exact", "contains"],
            "version": ["exact", "contains"],
            "iri": ["exact", "contains"],
            # "url": ["exact", "contains"],
            # "caption": ["exact", "contains"],
            "description": ["exact", "contains"],
        }


class EvaluationFilterSet(FilterSet):
    class Meta:
        model = Evaluation
        fields = {
            # "name_display": ["exact", "contains"],
            "name": ["exact", "contains"],
            "namespace__uri": ["exact", "contains"],
            "version": ["exact", "contains"],
            "iri": ["exact", "contains"],
            # "url": ["exact", "contains"],
            "pid": ["exact", "contains"],
            "doi": ["exact", "contains"],
            # "caption": ["exact", "contains"],
            "description": ["exact", "contains"],
        }


class DataFilterSet(FilterSet):
    # name = CharFilter(field_name="name", lookup_expr="contains")
    # name__exact = CharFilter(field_name="name", lookup_expr="exact")
    # name_full = CharFilter(field_name="name_full", lookup_expr="contains")
    # name_display = CharFilter(field_name="name_display", lookup_expr="contains")

    class Meta:
        model = Data
        # fields = ['name', 'name__exact', 'name_full', 'name_display',] # 'name', 'name_full', 'name_display', 'description', 'data_type', 'media_type', 'namespace', 'method', 'process', 'procedure', 'users', 'groups', '
        fields = {
            "name": ["exact", "contains"],
            "name_full": ["exact", "contains"],
            "name_display": ["exact", "contains"],
            "namespace__uri": ["exact", "contains"],
            "version": ["exact", "contains"],
            "iri": ["exact", "contains"],
            "pid": ["exact", "contains"],
            "doi": ["exact", "contains"],
            "description": ["exact", "contains"],
            "remarks": ["exact", "contains"],
            "datetime_created": ["lt", "gt", "exact", "contains"],
            "datetime_last_modified": ["lt", "gt", "exact", "contains"],
        }
