"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_data app *

:details: lara_django_data app configuration. 
         This provides a generic django app configuration mechanism.
         For more details see:
         https://docs.djangoproject.com/en/4.0/ref/applications/
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

from django.apps import AppConfig

#from django.db.models.signals import pre_save, post_save


class LaraDjangoDataConfig(AppConfig):
    name = 'lara_django_data'
    url_path = 'data/'
    # enter a verbose name for your app: lara_django_data here - this will be used in the admin interface
    verbose_name = 'LARA-django Data'
    # lara_app_icon = 'lara_django_data_icon.svg'  # this will be used to display an icon, e.g. in the main LARA menu.
    lara_app_color = 'sky'  # this will be used to highlight the app in the main LARA sidebar and app page
    lara_app_icon = "lara_data_icon.svg"
    verbose_name_short = "Data"
    lara_app_description = "Data and Evaluations"
    lara_class_apps = [
        {
            "name": "Data",
            "path":  "lara_django_data:data-list", # "/projects/project/list",
            "icon": "lara_projects_icon.svg",
            "color": lara_app_color,
        },
        {
            "name": "Evaluations",
            "path": "lara_django_data:data-list",
            "icon": "lara_experiments_icon.svg",
            "color": lara_app_color,
        }
    ]
    lara_instance_apps = []

    def ready(self):
        from . import signals

        #pre_save.connect(signals.pre_save_handler,  dispatch_uid='lara_django_data.post_save' )

        # add urlpatterns 
        from django.urls import path, include
        from lara_django.urls import urlpatterns

        urlpatterns += [ 
            path(self.url_path, include('lara_django_data.urls', namespace='lara_django_data')),
        ]


