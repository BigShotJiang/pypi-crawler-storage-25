"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_data celery tasks*

:details: lara_django_data celery tasks.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

from __future__ import absolute_import
from __future__ import unicode_literals

import logging
import time

from celery import current_task
from celery import shared_task
from celery.utils.log import get_task_logger
from django.apps import apps
from rdflib import URIRef

from prefect import flow
from prefect.deployments import run_deployment

logger = logging.getLogger("celery.task")


@shared_task
def semantic_data_to_triplestore(name, parameters, graph_urn):
    """semantic_data_to_triplestore celery task:
    metadata is converted to semantic data = owlready2 Dataa object,
    then triples are extracted from RDF graph
    and written to triple store using SPARQL
    """

    # insert_semantics(sender, instance, **kwargs)
    # print(f"semantic_data_to_triplestore: {current_task.request.id}")
    # print(f"semantic_data_to_triplestore: {parameters}")

    lara_onto = apps.get_app_config("lara_django_base").lara_onto
    lara_onto_graph = apps.get_app_config("lara_django_base").lara_onto_graph

    # curr_data = emmo.OSO_Data(name, **parameters)

    curr_data = lara_onto.Data(name, **parameters)

    triples_str = ""
    for triple in lara_onto_graph.triples((URIRef(curr_data.iri), None, None)):
        triples_str += triple[0].n3() + " " + triple[1].n3() + " " + triple[2].n3() + " .\n"

    query = f"""INSERT INTO <{graph_urn}> {{ {triples_str} }}"""

    # logging.debug
    print(f"+++ insert query:\n {query}")

    insert_query(query)

    # instance.iri = curr_data.iri
    # print(f"!!!!!!!! -------- semantic_data_to_triplestore:")
    # instance name
    #  logger.info(f"semantic_data_to_triplestore: {instance.name}")
    #  logger.info(f"semantic_data_to_triplestore: {current_task.request.id}")

    # return f"semantic_data_to_triplestore: {current_task.request.id}"
    return True


@shared_task
def evaluate_procdure_task(
    procedure_eval: str = "", parameters_global: dict | None = None, parameters_local: dict | None = None
):
    """
    evaluate_procdure_task celery task:
    evaluation is triggered, if there is a procedure associated with the evaluation
    """
    # now execute the procedure as a task
    logger.warning("evaluationg ...")

    logger.info(f"evaluate_procdure_task: {current_task.request.id} - {procedure_eval}")

    if parameters_global is None:
        parameters_global = dict(logger=logger)
    else:
        parameters_global["logger"] = logger
    try:
        # Execute the code within the local namespace
        exec(procedure_eval, parameters_global, parameters_local)

    except Exception:
        logger.exception("!!! Error during evaluation:")

    # Retrieve the result from the local namespace
    # result = local_namespace.get('result')
    # return result
    logger.warning("evaluation done ...")


@shared_task
def visualisation_deploy_task(
    procedure_vis_json: str = "", parameters_global: dict | None = None, parameters_local: dict | None = None
):
    """
    evaluate_procdure_task celery task:
    evaluation is triggered, if there is a procedure associated with the evaluation
    """
    # now execute the procedure as a task
    logger.info("visualising ...")

    logger.info(f"visualisation_deploy_task: {current_task.request.id} - {procedure_vis_json}")

    if parameters_global is None:
        parameters_global = dict(logger=logger)
    else:
        parameters_global["logger"] = logger
    try:
        # Execute the code within the local namespace
        # exec(procedure_vis, parameters_global, parameters_local)
        logger.info("visualisation_deploy_task: executing visualisation procedure ...")
        logger.info(
            f"##### ---------> deploy prefect flow: {procedure_vis_json['url_git']} with parameters: {parameters_local}"
        )

        flow.from_source(
            source=procedure_vis_json.get("url_git"),
            entrypoint=procedure_vis_json.get("entrypoint", "main"),
        ).deploy(
            name=procedure_vis_json.get("deployment_name"),
            parameters=parameters_local,
            tags=["on-demand"],
            work_pool_name=procedure_vis_json.get("work_pool_name", "lara-django-default-workpool"),
        )

    except KeyError:
        logger.exception("!!! Error during visualisation: missing url_git key in procedure_vis_json")

    # Retrieve the result from the local namespace
    # result = local_namespace.get('result')
    # return result
    logger.warning("visualisation deploy done ...")


@shared_task
def visualisation_procdure_task(
    procedure_vis_json: str = "", parameters_global: dict | None = None, parameters_local: dict | None = None
):
    """
    evaluate_procdure_task celery task:
    evaluation is triggered, if there is a procedure associated with the evaluation
    """
    # now execute the procedure as a task
    logger.warning("visualising ...")

    logger.info(f"visualisation_procdure_task: {current_task.request.id} - {procedure_vis_json}")

    if parameters_global is None:
        parameters_global = dict(logger=logger)
    else:
        parameters_global["logger"] = logger
    try:
        # Execute the code within the local namespace
        # exec(procedure_vis, parameters_global, parameters_local)
        logger.info(f"visualisation_procdure_task: executing visualisation procedure {procedure_vis_json.get('url_git')} ...")
        logger.info(f"##### ---------> run prefect flow: {procedure_vis_json['url_git']}")
        deployment_name = procedure_vis_json.get("deployment_name")
        logger.info(f"visualisation_procdure_task - deployment_name: {deployment_name}")
        logger.info(f"data_source - {parameters_local.get('data_source')}")
        run_deployment(
            name=deployment_name,
            parameters=parameters_local,
            tags=["on-demand"],
        )

    except KeyError:
        logger.exception("!!! Error during visualisation: missing url_git key in procedure_vis_json")

    # Retrieve the result from the local namespace
    # result = local_namespace.get('result')
    # return result
    logger.warning("visualising done ...")


@shared_task
def waiting_task():
    """waiting_task celery task:
    metadata is converted to semantic data = owlready2 Dataa object,
    then triples are extracted from RDF graph
    and written to triple store using SPARQL
    """

    time.sleep(5)
    print(f"waiting_task:  - done")

    #  print(f"waiting_task: {current_task.request.id} - waiting 5 seconds ...")
    #  logger.info(f"waiting_task: {current_task.request.id} - waiting 5 seconds ...")
    #  time.sleep(5)
    #  print(f"waiting_task: {current_task.request.id} - done")
    #  logger.info(f"waiting_task: {current_task.request.id} - done")

    #  return f"waiting_task: {current_task.request.id}"


def insert_query(query):
    """insert metadata into triple store using SPARQL"""

    sparql = apps.get_app_config("lara_django_base").sparql

    sparql.setMethod("POST")

    try:
        sparql.setQuery(query)
        qres = sparql.query().convert()
        logging.debug(f"+++ insert result: {qres}")

    except Exception as e:
        logging.error(f"+++ insert query error: {e}")
