import csv
import sqlite3 as sql

database_file = 'conf.db'

conn = sql.connect(database_file)

data = [
    {
        'table_name': 'Orders',
        'file_path': 'orderscsv.csv',
        'columns': ['date_create', 'id_status_orders', 'name_conf','visitors', 'hardware', 'id_status_pay'],
        'separator': ','
    },
    {
        'table_name': 'Roles',
        'file_path': 'role.csv',
        'columns': ['name_role'],
        'separator': ','
    },
    {
        'table_name': 'StatusOrders',
        'file_path': 'status_orders.csv',
        'columns': ['name_status'],
        'separator': ','
    },
    {
        'table_name': 'StatusPay',
        'file_path': 'status_paycsv.csv',
        'columns': ['name_status_pay'],
        'separator': ','
    },
    {
        'table_name': 'Users',
        'file_path': 'users.csv',
        'columns': ['fio', 'id_role', 'login', 'password'],
        'separator': ','
    }
]

for item in data:
    table_name = item['table_name']
    file_path = item['file_path']
    columns = item['columns']
    separator = item['separator']
    
    with open(file_path, 'r', encoding='utf-8') as f:
        reader = csv.reader(f, delimiter=separator)
        
        next(reader, None)
        
        insert_query = f'INSERT INTO {table_name} ({",".join(columns)}) VALUES ({",".join(["?"] * len(columns))})'
        
        cursor = conn.cursor()
        for row in reader:
            cursor.execute(insert_query, row)
            
        conn.commit()
        
conn.close()
