import sqlite3 as sql

def get_connection():
    conn = sql.connect('conf.db')
    cursor = conn.cursor()
    
    cursor.execute('CREATE TABLE IF NOT EXISTS Roles (id_role INTEGER PRIMARY KEY AUTOINCREMENT, name_role TEXT NOT NULL)')
    cursor.execute('CREATE TABLE IF NOT EXISTS StatusPay (id_status_pay INTEGER PRIMARY KEY AUTOINCREMENT, name_status_pay TEXT NOT NULL)')
    cursor.execute('CREATE TABLE IF NOT EXISTS StatusOrders (id_status_orders INTEGER PRIMARY KEY AUTOINCREMENT, name_status TEXT NOT NULL)')
    cursor.execute('''CREATE TABLE IF NOT EXISTS Orders (
        id_orders INTEGER PRIMARY KEY AUTOINCREMENT,
        date_create DATE NOT NULL,
        id_status_orders INTEGER NOT NULL,
        name_conf TEXT NOT NULL,
        visitors INTEGER NOT NULL,
        hardware TEXT NOT NULL,
        id_status_pay INTEGER NOT NULL,
        FOREIGN KEY (id_status_orders) REFERENCES StatusOrders (id_status_orders),
        FOREIGN KEY (id_status_pay) REFERENCES StatusPay (id_status_pay)
    )''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS Users (
        id_users INTEGER PRIMARY KEY AUTOINCREMENT,
        fio TEXT NOT NULL,
        id_role INTEGER NOT NULL,
        login TEXT NOT NULL,
        password TEXT NOT NULL,
        FOREIGN KEY (id_role) REFERENCES Roles (id_role)
    )''')
    
    if cursor.execute("SELECT COUNT(*) FROM Roles").fetchone()[0] == 0:
        cursor.executemany("INSERT INTO Roles (name_role) VALUES (?)", [('admin',), ('user',), ('manager',)])
        cursor.executemany("INSERT INTO StatusPay (name_status_pay) VALUES (?)", [('Не оплачен',), ('Частично оплачен',), ('Оплачен полностью',)])
        cursor.executemany("INSERT INTO StatusOrders (name_status) VALUES (?)", [('Новый',), ('В обработке',), ('Завершён',), ('Отменён',)])
        cursor.execute("INSERT INTO Users (fio, id_role, login, password) VALUES (?,?,?,?)", ('Администратор', 1, 'admin', '123'))
        cursor.execute("INSERT INTO Users (fio, id_role, login, password) VALUES (?,?,?,?)", ('Обычный Пользователь', 2, 'user', '123'))
        cursor.execute("INSERT INTO Users (fio, id_role, login, password) VALUES (?,?,?,?)", ('Менеджер', 3, 'manager', '123'))
        conn.commit()
    
    return conn