from PyQt5.QtWidgets import QMainWindow, QTabWidget
from admin_tools import UniversalAdminTab

class AdminWindow(QMainWindow):
    def __init__(self, connection, user_info):
        super().__init__()
        self.setWindowTitle(f"Администратор - {user_info[1]}")
        self.setGeometry(100, 100, 1000, 700)
        self.setStyleSheet("""
            QMainWindow { background-color: #f0f0f0; }
            QTabWidget::pane { border: 1px solid #ccc; background: white; }
            QTabBar::tab { background: #e0e0e0; padding: 6px 12px; margin-right: 2px; border-radius: 4px; }
            QTabBar::tab:selected { background: #4CAF50; color: white; }
        """)
        tabs = QTabWidget()
        self.setCentralWidget(tabs)
        
        tabs.addTab(UniversalAdminTab(connection, 'Roles', [{'name':'name_role','label':'Роль','type':'text'}], 'id_role'), "Роли")
        tabs.addTab(UniversalAdminTab(connection, 'StatusPay', [{'name':'name_status_pay','label':'Статус оплаты','type':'text'}], 'id_status_pay'), "Статусы оплаты")
        tabs.addTab(UniversalAdminTab(connection, 'StatusOrders', [{'name':'name_status','label':'Статус заказа','type':'text'}], 'id_status_orders'), "Статусы заказов")
        
        users_columns = [
            {'name':'fio','label':'ФИО','type':'text'},
            {'name':'login','label':'Логин','type':'text'},
            {'name':'password','label':'Пароль','type':'text'},
            {'name':'id_role','label':'Роль','type':'combobox','fk_table':'Roles','fk_display':'name_role','fk_value':'id_role'}
        ]
        tabs.addTab(UniversalAdminTab(connection, 'Users', users_columns, 'id_users'), "Пользователи")
        
        orders_columns = [
            {'name':'date_create','label':'Дата','type':'date'},
            {'name':'id_status_orders','label':'Статус заказа','type':'combobox','fk_table':'StatusOrders','fk_display':'name_status','fk_value':'id_status_orders'},
            {'name':'name_conf','label':'Конференция','type':'text'},
            {'name':'visitors','label':'Посетители','type':'int'},
            {'name':'hardware','label':'Оборудование','type':'text'},
            {'name':'id_status_pay','label':'Статус оплаты','type':'combobox','fk_table':'StatusPay','fk_display':'name_status_pay','fk_value':'id_status_pay'}
        ]
        tabs.addTab(UniversalAdminTab(connection, 'Orders', orders_columns, 'id_orders'), "Заказы")