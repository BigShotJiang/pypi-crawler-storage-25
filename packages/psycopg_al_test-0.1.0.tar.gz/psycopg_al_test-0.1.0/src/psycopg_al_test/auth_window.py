from PyQt5.QtWidgets import QMainWindow, QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox
from PyQt5.QtCore import Qt
from database import get_connection
from admin_window import AdminWindow
from manager_window import ManagerWindow
from guest_window import GuestWindow

class AuthWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Авторизация')
        self.setGeometry(300, 300, 350, 220)
        self.setStyleSheet("""
            QMainWindow { background-color: #f5f5f5; }
            QLabel { font-size: 13px; }
            QLineEdit {
                padding: 6px;
                border: 1px solid #ccc;
                border-radius: 4px;
            }
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                padding: 8px;
                border-radius: 4px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover { background-color: #45a049; }
        """)
        
        self.connection = get_connection()
        self.cursor = self.connection.cursor()
        
        central_widget = QWidget()
        layout = QVBoxLayout()
        layout.setSpacing(10)
        
        layout.addWidget(QLabel('Логин:'))
        self.login_input = QLineEdit()
        layout.addWidget(self.login_input)
        
        layout.addWidget(QLabel('Пароль:'))
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.Password)
        layout.addWidget(self.password_input)
        
        self.login_button = QPushButton('Войти')
        self.login_button.clicked.connect(self.check_credentials)
        layout.addWidget(self.login_button)
        
        self.status_label = QLabel('')
        self.status_label.setStyleSheet("color: red;")
        layout.addWidget(self.status_label)
        
        central_widget.setLayout(layout)
        self.setCentralWidget(central_widget)
    
    def check_credentials(self):
        login = self.login_input.text().strip()
        password = self.password_input.text().strip()
        if not login or not password:
            QMessageBox.warning(self, 'Ошибка', 'Заполните оба поля')
            return
        
        self.cursor.execute("SELECT id_users, fio, name_role FROM Users JOIN Roles ON Users.id_role = Roles.id_role WHERE login=? AND password=?", (login, password))
        user = self.cursor.fetchone()
        
        if user:
            user_id, full_name, role = user
            if role == 'admin':
                self.admin_window = AdminWindow(self.connection, (user_id, full_name, role))
                self.admin_window.show()
                self.close()
            elif role == 'manager':
                self.manager_window = ManagerWindow(self.connection, (user_id, full_name, role))
                self.manager_window.show()
                self.close()
            else:
                self.guest_window = GuestWindow(self.connection, (user_id, full_name, role))
                self.guest_window.show()
                self.close()
        else:
            self.status_label.setText('Неверный логин или пароль')
            self.password_input.clear()