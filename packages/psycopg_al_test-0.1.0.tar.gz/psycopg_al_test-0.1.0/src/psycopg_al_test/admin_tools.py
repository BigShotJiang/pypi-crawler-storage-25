from PyQt5.QtWidgets import *
from PyQt5.QtCore import QDate
from PyQt5.QtGui import QIntValidator

class UniversalAdminTab(QWidget):
    def __init__(self, connection, table_name, columns, primary_key='id', read_only=False):
        super().__init__()
        self.connection = connection
        self.cursor = connection.cursor()
        self.table_name = table_name
        self.columns = columns
        self.primary_key = primary_key
        self.read_only = read_only
        self.current_id = None
        self.setup_ui()
        self.load_data()
    
    def setup_ui(self):
        self.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                padding: 6px 12px;
                border-radius: 4px;
                font-size: 12px;
            }
            QPushButton:hover { background-color: #45a049; }
            QPushButton:pressed { background-color: #3d8b40; }
            QLineEdit, QComboBox, QDateEdit {
                padding: 4px;
                border: 1px solid #ccc;
                border-radius: 4px;
            }
            QTableWidget {
                gridline-color: #ddd;
                selection-background-color: #4CAF50;
            }
            QHeaderView::section {
                background-color: #f0f0f0;
                padding: 4px;
                border: 1px solid #ddd;
                font-weight: bold;
            }
        """)
        
        main_layout = QVBoxLayout()
        
        self.table_widget = QTableWidget()
        self.table_widget.setAlternatingRowColors(True)
        self.table_widget.setSelectionBehavior(QTableWidget.SelectRows)
        self.table_widget.setEditTriggers(QTableWidget.NoEditTriggers)
        if not self.read_only:
            self.table_widget.itemSelectionChanged.connect(self.on_row_selected)
        main_layout.addWidget(self.table_widget)
        
        form_layout = QVBoxLayout()
        self.input_widgets = {}
        for column in self.columns:
            row_layout = QHBoxLayout()
            row_layout.addWidget(QLabel(column['label'] + ':'))
            if column['type'] == 'date':
                widget = QDateEdit()
                widget.setDate(QDate.currentDate())
                widget.setCalendarPopup(True)
            elif column['type'] == 'combobox':
                widget = QComboBox()
                self.load_combobox(widget, column)
            elif column['type'] == 'int':
                widget = QLineEdit()
                widget.setValidator(QIntValidator())
            else:
                widget = QLineEdit()
            self.input_widgets[column['name']] = widget
            row_layout.addWidget(widget)
            form_layout.addLayout(row_layout)
        
        buttons_layout = QHBoxLayout()
        self.add_button = QPushButton("Добавить")
        self.edit_button = QPushButton("Редактировать")
        self.delete_button = QPushButton("Удалить")
        self.clear_button = QPushButton("Очистить")
        self.refresh_button = QPushButton("Обновить")
        
        self.delete_button.setStyleSheet("background-color: #f44336;")
        self.delete_button.setStyleSheet("""
            QPushButton { background-color: #f44336; }
            QPushButton:hover { background-color: #d32f2f; }
        """)
        
        if self.read_only:
            self.add_button.setVisible(False)
            self.edit_button.setVisible(False)
            self.delete_button.setVisible(False)
            self.clear_button.setVisible(False)
            self.table_widget.setSelectionMode(QTableWidget.NoSelection)
            buttons_layout.addWidget(self.refresh_button)
            self.refresh_button.clicked.connect(self.load_data)
        else:
            buttons_layout.addWidget(self.add_button)
            buttons_layout.addWidget(self.edit_button)
            buttons_layout.addWidget(self.delete_button)
            buttons_layout.addWidget(self.clear_button)
            buttons_layout.addWidget(self.refresh_button)
            self.add_button.clicked.connect(self.add_record)
            self.edit_button.clicked.connect(self.edit_record)
            self.delete_button.clicked.connect(self.delete_record)
            self.clear_button.clicked.connect(self.clear_form)
            self.refresh_button.clicked.connect(self.load_data)
        
        form_layout.addLayout(buttons_layout)
        main_layout.addLayout(form_layout)
        self.setLayout(main_layout)
    
    def load_combobox(self, combobox, column):
        foreign_table = column.get('fk_table')
        if not foreign_table:
            return
        self.cursor.execute(f"SELECT {column['fk_value']}, {column['fk_display']} FROM {foreign_table}")
        for value, text in self.cursor.fetchall():
            combobox.addItem(text, value)
    
    def load_data(self):
        fields = [self.primary_key] + [col['name'] for col in self.columns]
        self.cursor.execute(f"SELECT {', '.join(fields)} FROM {self.table_name}")
        rows = self.cursor.fetchall()
        self.table_widget.setRowCount(len(rows))
        self.table_widget.setColumnCount(len(fields))
        self.table_widget.setHorizontalHeaderLabels(['ID'] + [col['label'] for col in self.columns])
        for row_index, row_data in enumerate(rows):
            for col_index, value in enumerate(row_data):
                self.table_widget.setItem(row_index, col_index, QTableWidgetItem(str(value)))
        self.table_widget.resizeColumnsToContents()
    
    def get_form_values(self):
        values = {}
        for column in self.columns:
            widget = self.input_widgets[column['name']]
            if column['type'] == 'date':
                values[column['name']] = widget.date().toString("yyyy-MM-dd")
            elif column['type'] == 'combobox':
                values[column['name']] = widget.currentData()
            elif column['type'] == 'int':
                text = widget.text().strip()
                values[column['name']] = int(text) if text else None
            else:
                values[column['name']] = widget.text().strip()
        return values
    
    def set_form_values(self, values):
        for column in self.columns:
            widget = self.input_widgets[column['name']]
            value = values.get(column['name'])
            if value is None:
                continue
            if column['type'] == 'date':
                widget.setDate(QDate.fromString(value, "yyyy-MM-dd"))
            elif column['type'] == 'combobox':
                index = widget.findData(value)
                if index >= 0:
                    widget.setCurrentIndex(index)
            else:
                widget.setText(str(value))
    
    def clear_form(self):
        for column in self.columns:
            widget = self.input_widgets[column['name']]
            if column['type'] == 'text':
                widget.clear()
            elif column['type'] == 'int':
                widget.clear()
            elif column['type'] == 'date':
                widget.setDate(QDate.currentDate())
            elif column['type'] == 'combobox' and widget.count() > 0:
                widget.setCurrentIndex(0)
        self.current_id = None
    
    def on_row_selected(self):
        selected_items = self.table_widget.selectedItems()
        if not selected_items:
            return
        row = selected_items[0].row()
        self.current_id = int(self.table_widget.item(row, 0).text())
        field_names = [col['name'] for col in self.columns]
        self.cursor.execute(f"SELECT {', '.join(field_names)} FROM {self.table_name} WHERE {self.primary_key}=?", (self.current_id,))
        record = self.cursor.fetchone()
        if record:
            self.set_form_values(dict(zip(field_names, record)))
    
    def validate_form(self):
        errors = []
        for column in self.columns:
            value = self.get_form_values().get(column['name'])
            if column['type'] == 'int':
                if value is None or value == '':
                    errors.append(f"Поле '{column['label']}' не заполнено")
            elif column['type'] == 'combobox':
                if value is None or value == 0:
                    errors.append(f"Поле '{column['label']}' не выбрано")
            else:
                if not value or value.strip() == '':
                    errors.append(f"Поле '{column['label']}' не заполнено")
        return errors
    
    def add_record(self):
        errors = self.validate_form()
        if errors:
            QMessageBox.warning(self, "Ошибка", "\n".join(errors))
            return
        values = self.get_form_values()
        query = f"INSERT INTO {self.table_name} ({', '.join(values.keys())}) VALUES ({','.join(['?']*len(values))})"
        self.cursor.execute(query, tuple(values.values()))
        self.connection.commit()
        self.load_data()
        self.clear_form()
        QMessageBox.information(self, "Успех", "Запись добавлена")
    
    def edit_record(self):
        if self.current_id is None:
            QMessageBox.warning(self, "Ошибка", "Выберите запись")
            return
        errors = self.validate_form()
        if errors:
            QMessageBox.warning(self, "Ошибка", "\n".join(errors))
            return
        values = self.get_form_values()
        set_clause = ', '.join(f"{key}=?" for key in values)
        query = f"UPDATE {self.table_name} SET {set_clause} WHERE {self.primary_key}=?"
        self.cursor.execute(query, tuple(values.values()) + (self.current_id,))
        self.connection.commit()
        self.load_data()
        self.clear_form()
        QMessageBox.information(self, "Успех", "Запись изменена")
    
    def delete_record(self):
        if self.current_id is None:
            QMessageBox.warning(self, "Ошибка", "Выберите запись")
            return
        reply = QMessageBox.question(self, "Подтверждение", "Удалить запись?", QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            self.cursor.execute(f"DELETE FROM {self.table_name} WHERE {self.primary_key}=?", (self.current_id,))
            self.connection.commit()
            self.load_data()
            self.clear_form()