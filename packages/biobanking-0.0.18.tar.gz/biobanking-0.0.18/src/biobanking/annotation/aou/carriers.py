import re
import io
import math
import gcsfs
import numpy as np
import pandas as pd
from itertools import product
from tqdm.auto import tqdm

from biobanking.utils.config import AllofUs

MASK_ID_PATTERN = re.compile(
    r"(?P<gene>[^.]+)\.(?P<mask>[^.]+)\.(?P<aaf_bin>0\.\d+|singleton)$"
)

_PLINK_BED_MAGIC = b"\x6c\x1b\x01"


class CarrierCounter(AllofUs):

    def __init__(self):
        super().__init__()
        self.carriers_base = f"{self.bucket}/data/annotations/carriers"

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _mask_gcs_paths(self, burden_type: str, chrm: int | str) -> dict[str, str]:
        prefix = f"data/associations/masks/{burden_type}/chr{chrm}/"
        files = self.list_gcs_files(prefix)
        paths = {}
        for f in files:
            if f.endswith(".bed"):
                paths["bed"] = f
            elif f.endswith(".bim"):
                paths["bim"] = f
            elif f.endswith(".fam"):
                paths["fam"] = f
        return paths

    def _read_bim(self, gcs_path: str) -> pd.DataFrame:
        fs = gcsfs.GCSFileSystem()
        with fs.open(gcs_path, "rb") as f:
            return pd.read_csv(
                io.BytesIO(f.read()), sep="\t", header=None,
                names=["chrom", "snp", "cm", "pos", "a1", "a2"]
            )

    def _read_fam(self, gcs_path: str) -> pd.DataFrame:
        fs = gcsfs.GCSFileSystem()
        with fs.open(gcs_path, "rb") as f:
            return pd.read_csv(
                io.BytesIO(f.read()), sep=r"\s+", header=None,
                names=["fid", "iid", "father", "mother", "sex", "pheno"]
            )

    def _extract_carriers(
        self, bed_gcs_path: str, bim: pd.DataFrame, fam: pd.DataFrame
    ) -> pd.DataFrame:
        """
        Parse a PLINK variant-major BED from GCS and return a long-format
        DataFrame of (gene, mask_type, aaf_bin, sample_id) for every carrier.

        PLINK BED 2-bit encoding (LSB-first), counting copies of A1 (effect allele):
          00 = hom-A1  (dosage 2) — carrier
          01 = missing            — not a carrier
          10 = het     (dosage 1) — carrier
          11 = hom-A2  (dosage 0) — not a carrier
        Carrier check: low bit of each pair (bits[:, 0]) equals 0.
        """
        n_samples = len(fam)
        n_variants = len(bim)
        bytes_per_var = math.ceil(n_samples / 4)
        sample_ids = fam["iid"].values

        fs = gcsfs.GCSFileSystem()
        with fs.open(bed_gcs_path, "rb") as f:
            raw = np.frombuffer(f.read(), dtype=np.uint8)

        if bytes(raw[:3]) != _PLINK_BED_MAGIC:
            raise ValueError(f"Not a valid PLINK variant-major BED file: {bed_gcs_path}")

        # Shape: (n_variants, bytes_per_var) — one row per gene mask
        bed = raw[3:].reshape(n_variants, bytes_per_var)

        # Parse all valid mask IDs from BIM upfront to build Categorical codes.
        # Storing gene/mask/aaf_bin as integer codes + numpy arrays costs ~10
        # bytes/record vs ~150 bytes for Python tuples — critical for high
        # carrier-rate masks with 400k samples.
        parsed = bim["snp"].str.extract(MASK_ID_PATTERN)
        gene_cat = pd.Categorical(parsed["gene"])
        mask_cat = pd.Categorical(parsed["mask"])
        aaf_cat  = pd.Categorical(parsed["aaf_bin"])

        gene_chunks: list[np.ndarray] = []
        mask_chunks: list[np.ndarray] = []
        aaf_chunks:  list[np.ndarray] = []
        sid_chunks:  list[np.ndarray] = []
        zyg_chunks:  list[np.ndarray] = []

        for vi in range(n_variants):
            gene_code = gene_cat.codes[vi]
            if gene_code == -1 or aaf_cat.categories[aaf_cat.codes[vi]] == "singleton":
                continue

            # Unpack bits LSB-first, trim padding, reshape to (n_samples, 2)
            bits = (
                np.unpackbits(bed[vi], bitorder="little")
                [: n_samples * 2]
                .reshape(n_samples, 2)
            )
            # Carrier = low bit is 0: catches hom-A1 (00) and het (10).
            # hom-A2 (11) is non-carrier; missing (01) is excluded.
            carrier_mask = ~bits[:, 0].astype(bool)
            carrier_ids = sample_ids[carrier_mask]
            n = len(carrier_ids)
            if n == 0:
                continue

            # Among carriers: high bit 0 = hom-A1 (homz), high bit 1 = het (hetz)
            # Stored as int8 codes: 0=homz, 1=hetz (matches Categorical below)
            zyg = bits[carrier_mask, 1].astype(np.int8)

            gene_chunks.append(np.full(n, gene_code,            dtype=np.int16))
            mask_chunks.append(np.full(n, mask_cat.codes[vi],   dtype=np.int8))
            aaf_chunks.append( np.full(n, aaf_cat.codes[vi],    dtype=np.int8))
            sid_chunks.append(carrier_ids)
            zyg_chunks.append(zyg)

        if not sid_chunks:
            return pd.DataFrame(columns=["gene", "mask_type", "aaf_bin", "sample_id", "zygosity"])

        return pd.DataFrame({
            "gene":      pd.Categorical.from_codes(np.concatenate(gene_chunks), categories=gene_cat.categories),
            "mask_type": pd.Categorical.from_codes(np.concatenate(mask_chunks), categories=mask_cat.categories),
            "aaf_bin":   pd.Categorical.from_codes(np.concatenate(aaf_chunks),  categories=aaf_cat.categories),
            "sample_id": np.concatenate(sid_chunks),
            "zygosity":  pd.Categorical.from_codes(np.concatenate(zyg_chunks),  categories=["homz", "hetz"]),
        })

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def compute_carriers_for_chrm(
        self,
        chrm: int | str,
        burden_type: str = "plof",
        overwrite: bool = False,
    ) -> pd.DataFrame:
        """Compute carrier table for one chromosome and save to GCS as parquet."""
        out_path = f"{self.carriers_base}/{burden_type}/chr{chrm}_carriers.parquet"

        if not overwrite:
            fs = gcsfs.GCSFileSystem()
            if fs.exists(out_path):
                return pd.read_parquet(out_path)

        gcs_paths = self._mask_gcs_paths(burden_type, chrm)
        missing = [ext for ext in ("bed", "bim", "fam") if ext not in gcs_paths]
        if missing:
            raise FileNotFoundError(
                f"Missing mask files for chr{chrm} ({burden_type}): {missing}"
            )

        bim = self._read_bim(gcs_paths["bim"])
        fam = self._read_fam(gcs_paths["fam"])
        df = self._extract_carriers(gcs_paths["bed"], bim, fam)

        df.to_parquet(out_path, index=False)
        print(f"chr{chrm}: {df['gene'].nunique()} genes, {len(df)} carrier records → {out_path}")
        return df

    def compute_all_carriers(
        self,
        burden_type: str = "plof",
        chrs: list[int] | None = None,
        overwrite: bool = False,
    ) -> pd.DataFrame:
        """Compute and save carrier tables for all chromosomes."""
        if chrs is None:
            chrs = list(range(1, 23))
        frames = []
        for chrm in tqdm(chrs, desc="Processing chromosomes"):
            try:
                frames.append(
                    self.compute_carriers_for_chrm(chrm, burden_type=burden_type, overwrite=overwrite)
                )
            except FileNotFoundError as e:
                print(f"Warning: {e}")
        return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame(
            columns=["gene", "mask_type", "aaf_bin", "sample_id", "zygosity"]
        )

    def load_carriers(
        self,
        burden_type: str = "plof",
        chrs: list[int] | None = None,
        genes: list[str] | None = None,
    ) -> pd.DataFrame:
        """Load pre-computed carrier parquet files from GCS."""
        if chrs is None:
            chrs = list(range(1, 23))
        frames = []
        for chrm in chrs:
            path = f"{self.carriers_base}/{burden_type}/chr{chrm}_carriers.parquet"
            try:
                df = pd.read_parquet(path)
                if genes is not None:
                    df = df[df["gene"].isin(genes)]
                frames.append(df)
            except Exception:
                pass
        return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame(
            columns=["gene", "mask_type", "aaf_bin", "sample_id", "zygosity"]
        )

    def count_carriers(
        self,
        burden_type: str = "plof",
        chrs: list[int] | None = None,
        genes: list[str] | None = None,
    ) -> pd.DataFrame:
        """Return carrier counts per (gene, mask_type, aaf_bin, zygosity) from saved files."""
        df = self.load_carriers(burden_type=burden_type, chrs=chrs, genes=genes)
        if df.empty:
            return df
        return (
            df.groupby(["gene", "mask_type", "aaf_bin", "zygosity"], observed=True)
            .size()
            .reset_index(name="n_carriers")
            .sort_values(["gene", "mask_type", "aaf_bin", "zygosity"])
            .reset_index(drop=True)
        )

    def get_combination_carriers(
        self,
        genes: list[str],
        mask_type: str | list[str] | None = "pLoF_strict",
        aaf_bin: str | list[str] | None = "0.01",
        burden_type: str = "plof",
    ) -> pd.DataFrame:
        """Return rows for samples that carry rare variants in ALL specified genes.

        mask_type / aaf_bin each accept a single value, a list of values, or
        None (no filter — include all). A sample qualifies as a co-carrier if
        it appears in every gene under at least one of the allowed combinations.
        Result is long-format: (gene, mask_type, aaf_bin, sample_id, zygosity).
        """
        if len(genes) < 2:
            raise ValueError("Provide at least two genes for combination analysis.")

        df = self.load_carriers(burden_type=burden_type, genes=genes)
        if df.empty:
            return df

        if mask_type is not None:
            mt = [mask_type] if isinstance(mask_type, str) else mask_type
            df = df[df["mask_type"].isin(mt)]

        if aaf_bin is not None:
            ab = [aaf_bin] if isinstance(aaf_bin, str) else aaf_bin
            df = df[df["aaf_bin"].isin(ab)]

        if df.empty:
            return df

        # Build per-gene sample sets in one groupby pass
        grouped = df.groupby("gene", observed=True)["sample_id"].agg(set)
        gene_sets = [grouped[g] for g in genes if g in grouped.index]
        if len(gene_sets) < len(genes):
            return df.iloc[:0]

        co_carriers = gene_sets[0]
        for s in gene_sets[1:]:
            co_carriers &= s

        return df[df["sample_id"].isin(co_carriers)].reset_index(drop=True)

    def count_combination_carriers(
        self,
        genes: list[str],
        mask_type: str | list[str] | None = "pLoF_strict",
        aaf_bin: str | list[str] | None = "0.01",
        burden_type: str = "plof",
    ) -> pd.DataFrame:
        """Return co-carrier counts for every cross-combination of per-gene mask/aaf.

        Each row represents one assignment of (mask_type, aaf_bin) per gene —
        i.e. the full Cartesian product across genes. For example with two genes
        and two mask types each, you get 4 rows.

        Columns: gene1, mask_type_1, aaf_bin_1, ..., geneN, mask_type_N, aaf_bin_N,
                 hetz_co (all genes hetz), homz_co (≥1 gene homz), total_co.
        """
        if len(genes) < 2:
            raise ValueError("Provide at least two genes for combination analysis.")

        df = self.load_carriers(burden_type=burden_type, genes=genes)
        if df.empty:
            return pd.DataFrame()

        if mask_type is not None:
            mt = [mask_type] if isinstance(mask_type, str) else mask_type
            df = df[df["mask_type"].isin(mt)]
        if aaf_bin is not None:
            ab = [aaf_bin] if isinstance(aaf_bin, str) else aaf_bin
            df = df[df["aaf_bin"].isin(ab)]

        if df.empty:
            return pd.DataFrame()

        df = df.copy()
        df["mask_type"] = df["mask_type"].astype(str)
        df["aaf_bin"]   = df["aaf_bin"].astype(str)
        df["gene"]      = df["gene"].astype(str)
        df["zygosity"]  = df["zygosity"].astype(str)

        # Build per-gene lookup in one groupby pass: gene -> (mask, aaf) -> {sample_id: zygosity}
        gene_lookup: dict[str, dict[tuple, dict]] = {}
        for (gene, mt_val, ab_val), grp in df.groupby(["gene", "mask_type", "aaf_bin"], observed=True):
            gene_lookup.setdefault(gene, {})[(mt_val, ab_val)] = dict(zip(grp["sample_id"], grp["zygosity"]))
        del df

        # Cartesian product: one (mask, aaf) choice per gene
        records = []
        for combo in product(*[gene_lookup[g].keys() for g in genes]):
            sample_sets = [set(gene_lookup[g][combo[i]]) for i, g in enumerate(genes)]
            co = sample_sets[0]
            for s in sample_sets[1:]:
                co &= s

            hetz_co = homz_co = mixed_co = 0
            for sid in co:
                zygs = [gene_lookup[g][combo[i]][sid] for i, g in enumerate(genes)]
                if all(z == "hetz" for z in zygs):
                    hetz_co += 1
                elif all(z == "homz" for z in zygs):
                    homz_co += 1
                else:
                    mixed_co += 1

            row: dict = {}
            for i, g in enumerate(genes):
                row[f"gene{i + 1}"]       = g
                row[f"mask_type_{i + 1}"] = combo[i][0]
                row[f"aaf_bin_{i + 1}"]   = combo[i][1]
            row["hetz_co"]  = hetz_co
            row["homz_co"]  = homz_co
            row["mixed_co"] = mixed_co
            row["total_co"] = hetz_co + homz_co + mixed_co
            records.append(row)

        return pd.DataFrame(records)
