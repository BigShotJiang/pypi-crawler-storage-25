import os
import subprocess
import json
import multiprocessing as mp
import pandas as pd
import math
import random
from importlib.resources import as_file, files
from tqdm.auto import tqdm
from biobanking.association.helpers import (
    save_files_in_regenie_fmt, rint_normalization
)
from biobanking.utils.config import AllofUs

class REGENIE(AllofUs):
    def __init__(self):
        super().__init__()

    @staticmethod
    def _process_regenie_df_impl(df: pd.DataFrame) -> pd.DataFrame:
        id_pattern = r"(?P<gene>[^.]+)\.(?P<mask>[^.]+)\.(?P<aaf_bin>0\.\d+|singleton)$"
        parsed = df["ID"].str.extract(id_pattern)
        test_values = df["TEST"] if "TEST" in df.columns else pd.Series(pd.NA, index=df.index)
        df = df.assign(
            id=df["ID"],
            gene=parsed["gene"],
            mask=parsed["mask"],
            aaf_bin=parsed["aaf_bin"],
            test=test_values,
            pvalue=10 ** (-df["LOG10P"])
        )
        df = df.loc[
            :, ["id", "gene", "CHROM", "pvalue", "BETA", "SE", "CHISQ", "mask", "aaf_bin", "test", "N"]
        ].rename(columns=str.lower)
        return df.dropna(subset=["gene", "pvalue"])

    @staticmethod
    def _load_workflow_results(workflow_job: tuple[str, str, str, list[str]]) -> pd.DataFrame | None:
        run_label, step2_category, step2_mode, all_filepaths = workflow_job
        frames = []
        for fp in all_filepaths:
            if ("glob" not in fp) or (not fp.endswith(".txt")):
                continue
            filename = os.path.basename(fp)
            pheno = os.path.splitext(filename)[0]
            df = pd.read_csv(fp, sep=r"\s+", engine="python")
            df = REGENIE._process_regenie_df_impl(df)
            df["pheno"] = pheno
            df["run_label"] = run_label
            df["step2_category"] = step2_category
            df["step2_mode"] = step2_mode
            frames.append(df)

        if not frames:
            return None
        return pd.concat(frames, ignore_index=True)

    @staticmethod
    def _load_mask_outputs_impl(workflow_job: tuple[str, list[str]]) -> list[tuple[str, str]]:
        _, all_filepaths = workflow_job
        mask_files = []
        for fp in all_filepaths:
            if "glob" not in fp:
                continue
            if fp.endswith(("_masks.bed", "_masks.bim", "_masks.fam")):
                filename = os.path.basename(fp)
                chrom = filename.split("_masks.")[0].split("chr")[-1]
                mask_files.append((chrom, fp))
        return mask_files

    def prepare_covariate_file(self):
        cov_df = pd.read_csv(f"{self.bucket}/data/phenotypes/individuals.csv.gz")
        cov_df = cov_df.loc[
            (cov_df.duplicates==False)&
            (cov_df.qc_failed==False)&
            (cov_df.sex_at_birth.notna())
        ].copy()
        # assign sex
        cov_df["genetic_sex"] = cov_df.sex_at_birth.astype(int)
        # calculate age related covariates
        cov_df["age_2"] = cov_df.age**2
        cov_df["age_sex"] = cov_df.age*cov_df.genetic_sex
        # save in regenie fomrat
        save_file = f"{self.bucket}/data/associations/phenotypes/covariates.tsv.gz"
        save_files_in_regenie_fmt(
            cov_df, save_file, phenos=[], 
            covariates=[
                'genetic_sex', 'age', 'age_2', 'age_sex', 'ancestry_pred_other', 
                'genetic_pca1', 'genetic_pca2', 'genetic_pca3', 'genetic_pca4', 
                'genetic_pca5', 'genetic_pca6', 'genetic_pca7', 'genetic_pca8', 
                'genetic_pca9', 'genetic_pca10'
                ]
            )
        return

    def split_traits_evenly(self, traits, max_traits_per_file=50):
        ntraits = len(traits)
        if ntraits == 0:
            raise ValueError("No traits were provided or found in the phenotype table.")
        nparts = math.ceil(ntraits / max_traits_per_file)
        chunk_size = math.ceil(ntraits / nparts)
        return [traits[i:i + chunk_size] for i in range(0, ntraits, chunk_size)]

    def prepare_traits(self, filename, traits=None, id_col="person_id", isbinary=True, max_traits_per_file=50):
        pheno_df = pd.read_csv(f"{self.bucket}/data/phenotypes/{filename}.csv.gz")
        if not isbinary:
            cov_df = pd.read_csv(f"{self.bucket}/data/phenotypes/individuals.csv.gz")
        if traits is None:
            traits = [c for c in pheno_df.columns if c != id_col]
        if not traits:
            raise ValueError("No traits were provided or found in the phenotype table.")
        if isbinary:
            case_counts = pheno_df.loc[:, traits].apply(pd.to_numeric, errors="coerce").fillna(0).sum(axis=0)
            traits = [trait for trait in traits if case_counts.get(trait, 0) >= 50]
            if not traits:
                raise ValueError("No binary traits have at least 50 cases.")
        else:
            uniq_counts = pheno_df.loc[:, traits].apply(pd.to_numeric, errors="coerce").nunique(axis=0)
            traits = [trait for trait in traits if uniq_counts.get(trait, 0) >= 50]
            if not traits:
                raise ValueError("No continuous traits have at least 50 unique values.")
            pheno_df = pheno_df.merge(cov_df, on=id_col)
            for trait in traits:
                pheno_df[f"{trait}"] = pheno_df.groupby(
                    ["ancestry_pred_other", "sex_at_birth"]
                    )[trait].transform(rint_normalization)

        trait_chunks = self.split_traits_evenly(traits, max_traits_per_file=max_traits_per_file)
        for i, straits in enumerate(trait_chunks):
            if len(trait_chunks) > 1:
                save_file = f"{self.bucket}/data/associations/phenotypes/{filename}_{i}.tsv.gz"
            else:
                save_file = f"{self.bucket}/data/associations/phenotypes/{filename}.tsv.gz"
            save_files_in_regenie_fmt(
                pheno_df, save_file, sample_id_col=id_col, phenos=straits, covariates=[]
            )
        return

    def create_regenie_burden_files_helper(self, burden_df, mask_definitions):
        # need to add chr prefix to variants  as in all of us chr stays
        burden_df = burden_df.copy()
        burden_df["variants"] = burden_df.locus + ":" + burden_df.alleles.str.replace("_", ":")
        # create annotation df
        annot_df = burden_df.loc[:, ["variants", "gene", "consequence"]]
        annot_df = annot_df.rename(columns={"consequence": "annotation"})
        valid_annotations = {
            annotation
            for categories in mask_definitions.values()
            for annotation in categories
        }
        annot_df = annot_df.loc[annot_df["annotation"].isin(valid_annotations)]
        # Only keep required columns
        annot_df = annot_df.loc[:, ["variants", "gene", "annotation"]]
        # this gets rid of duplicates due to transcripts of same gene with same consequence
        annot_df = annot_df.dropna().drop_duplicates()
        # create set list df
        set_source_df = annot_df.loc[:, ["gene", "variants"]].drop_duplicates()
        set_df = set_source_df.groupby("gene").agg({"variants": lambda x: ",".join(x)})
        set_df[["chrm", "location"]] = set_df.variants.apply(lambda x: pd.Series(dict(zip(["chrm", "location"], x.split(",")[0].split(":")[:2]))))
        set_df = set_df.reset_index().loc[:, ["gene", "chrm", "location", "variants"]]
        # create aaf df
        aaf_df = burden_df.loc[:, ["variants", "maf"]]
        aaf_df = aaf_df.dropna().drop_duplicates()
        mask_df = pd.DataFrame(
            {
                "mask_name": list(mask_definitions.keys()),
                "categories": [
                    ",".join(categories)
                    for categories in mask_definitions.values()
                ],
            }
        )
        return annot_df, set_df, aaf_df, mask_df

    def create_regenie_burden_files(
        self,
        burden_type="plof",
        mask_definitions={
            "pLoF_strict": [
                "frameshift_variant",
                "stop_gained",
                "splice_acceptor_variant",
                "splice_donor_variant",
            ],
            "pLoF_lenient": [
                "frameshift_variant",
                "stop_gained",
                "splice_acceptor_variant",
                "splice_donor_variant",
                "start_lost",
                "stop_lost",
            ],
        },
    ):
        for chrm in list(range(1, 23))+["X"]:
            exome_df = pd.read_csv(f"{self.bucket}/data/exome/annot/chr{chrm}_{burden_type}.tsv.gz", sep="\t")
            annot_df, set_df, aaf_df, mask_df = self.create_regenie_burden_files_helper(
                exome_df,
                mask_definitions=mask_definitions,
            )
            annot_df_name = f"chr{chrm}_annotations_{burden_type}.tsv.gz"
            set_df_name = f"chr{chrm}_sets_{burden_type}.tsv.gz"
            aaf_df_name = f"chr{chrm}_aafs_{burden_type}.tsv.gz"
            mask_df_name = f"chr{chrm}_masks_{burden_type}.tsv.gz"
            proj_dir = f"{self.bucket}/data/associations/burden/"

            for df, name in zip(
                [annot_df, set_df, aaf_df, mask_df],
                [annot_df_name, set_df_name, aaf_df_name, mask_df_name]
            ):
                df.to_csv(os.path.join(proj_dir, name), sep='\t', index=False, header=False)
        return

    # REGENIE job submission
    def _metadata_bucket_path(self, workflow_json):
        return f"{self.bucket}/data/associations/workflows/{os.path.basename(workflow_json)}"

    def _load_workflow_metadata(self, workflow_json):
        workflow_dict = {}
        if os.path.exists(workflow_json):
            with open(workflow_json, "r") as f:
                workflow_dict = json.load(f)
        else:
            from google.cloud import storage

            storage_client = storage.Client()
            bucket_obj = storage_client.bucket(self.bucket.lstrip("gs://"))
            blob_name = self._metadata_bucket_path(workflow_json).replace(f"{self.bucket}/", "", 1)
            blob = bucket_obj.blob(blob_name)
            if blob.exists():
                workflow_dict = json.loads(blob.download_as_text())
        return workflow_dict

    def _save_workflow_metadata(self, workflow_json, workflow_dict):
        with open(workflow_json, "w") as f:
            json.dump(workflow_dict, f, indent=4)

        from google.cloud import storage

        storage_client = storage.Client()
        bucket_obj = storage_client.bucket(self.bucket.lstrip("gs://"))
        blob_name = self._metadata_bucket_path(workflow_json).replace(f"{self.bucket}/", "", 1)
        bucket_obj.blob(blob_name).upload_from_filename(workflow_json)
        return

    def _stage_extract_file(self, extract_file, step2_category, step2_mode, run_label, phase_prefix=None):
        if not extract_file:
            return ""
        if str(extract_file).startswith("gs://"):
            return extract_file
        if not os.path.exists(extract_file):
            raise FileNotFoundError(f"extract_file not found: {extract_file}")

        from google.cloud import storage

        safe_phase = phase_prefix if phase_prefix else "shared"
        basename = os.path.basename(extract_file)
        staged = (
            f"{self.bucket}/data/associations/inputs/{step2_category}/{step2_mode}/"
            f"{safe_phase}/{run_label}/{basename}"
        )

        storage_client = storage.Client()
        bucket_obj = storage_client.bucket(self.bucket.lstrip("gs://"))
        blob_name = staged.replace(f"{self.bucket}/", "", 1)
        bucket_obj.blob(blob_name).upload_from_filename(extract_file)
        return staged

    @staticmethod
    def _ensure_workflow_entry(workflow_dict, phase_prefix):
        phase_entry = workflow_dict.setdefault(phase_prefix, {})
        phase_entry.setdefault("step1", {})
        phase_entry.setdefault(
            "step2",
            {"burden": {}, "skato": {}, "mask": {}, "interaction": {}}
        )
        return phase_entry

    def _resolve_step2_mode(self, step2_category, burden_type, step2_mode=""):
        if step2_mode:
            return step2_mode
        return burden_type

    @staticmethod
    def build_mask_id(gene, mask="pLoF_strict", aaf_bin="0.01", interaction_model=""):
        mask_id = f"{gene}.{mask}.{aaf_bin}"
        if interaction_model:
            mask_id = f"{mask_id}[{interaction_model}]"
        return mask_id

    def get_step1_workflow_id(self, phase_prefix, workflow_json="workflow_metadata.json"):
        workflow_dict = self._load_workflow_metadata(workflow_json)
        return workflow_dict.get(phase_prefix, {}).get("step1", {}).get("workflow_id", "")

    def _load_mask_sample_df(self, chrm=1):
        sample_df = pd.read_csv(
            f"{self.bucket}/data/bgen/chr{chrm}.sample",
            sep=r"\s+",
            skiprows=2,
            names=["sample_id_1", "sample_id_2", "missing"],
            dtype={"sample_id_1": str}
        )
        return sample_df.loc[:, ["sample_id_1"]].rename(columns={"sample_id_1": "sample_id"})

    def prepare_mask_phenotype_file(self, burden_type="plof", chrm=1):
        save_file = f"{self.bucket}/data/associations/masks/{burden_type}/dummy.tsv.gz"

        sample_df = self._load_mask_sample_df(chrm=chrm)
        rng = random.Random(42)
        sample_df["dummy"] = [rng.gauss(0.0, 1.0) for _ in range(len(sample_df))]
        save_files_in_regenie_fmt(
            sample_df,
            save_file,
            sample_id_col="sample_id",
            phenos=["dummy"],
            covariates=[]
        )
        return save_file

    def create_input_dict(
        self,
        phase_prefix=None,
        run_step1=True,
        isbinary=False,
        burden_type="plof",
        step2_category="burden",
        step2_mode="",
        run_label="default",
        workflow_json="workflow_metadata.json",
        step1_workflow_id="",
        ignore_pred=None,
        extract_setlist="",
        interaction_snp="",
        anchor_chrm=None,
        extract_file="",
        interaction_file_reffirst=False,
        no_condtl=False,
        force_condtl=False,
        chrs=None,
        phenotype_file="",
        covariate_file="",
        prefix="",
        pheno_col_list=None,
        json_filename=""
    ):
        step2_mode = self._resolve_step2_mode(step2_category, burden_type, step2_mode)
        interaction_mode = step2_category == "interaction"
        if interaction_mode and extract_file:
            extract_file = self._stage_extract_file(
                extract_file,
                step2_category=step2_category,
                step2_mode=step2_mode,
                run_label=run_label,
                phase_prefix=phase_prefix
            )
        burden_mode = step2_category in {"burden", "skato", "mask"}
        mask_mode = step2_category == "mask"
        if step2_category != "mask" and not phase_prefix:
            raise ValueError("phase_prefix is required for burden and interaction runs.")
        if not json_filename:
            json_parts = [step2_category, step2_mode] if not phase_prefix else [phase_prefix, step2_category, step2_mode]
            if run_label != "default":
                json_parts.append(run_label)
            json_filename = "_".join([p for p in json_parts if p]) + ".json"
        if chrs is None:
            chrs = [str(i) for i in range(1, 23)]
        else:
            chrs = [str(chrm) for chrm in chrs]

        input_dict = dict()
        skip_association = mask_mode
        write_mask = mask_mode
        if ignore_pred is None:
            ignore_pred = mask_mode

        input_dict["regenie_workflow.run_step1"] = run_step1
        input_dict["regenie_workflow.interaction_mode"] = interaction_mode
        input_dict["regenie_workflow.isbinary"] = isbinary
        input_dict["regenie_workflow.skip_association"] = skip_association
        input_dict["regenie_workflow.write_mask"] = write_mask
        input_dict["regenie_workflow.ignore_pred"] = ignore_pred
        input_dict["regenie_workflow.vc_tests"] = "skato" if step2_category == "skato" else ""
        if not phenotype_file:
            if step2_category == "mask":
                phenotype_file = self.prepare_mask_phenotype_file(burden_type=burden_type, chrm=int(chrs[0]))
            else:
                phenotype_file = f"{self.bucket}/data/associations/phenotypes/{phase_prefix}.tsv.gz"
        input_dict["regenie_workflow.phenotype_file"] = phenotype_file
        if covariate_file:
            input_dict["regenie_workflow.covariate_file"] = covariate_file
        elif step2_category != "mask":
            input_dict["regenie_workflow.covariate_file"] = f"{self.bucket}/data/associations/phenotypes/covariates.tsv.gz"

        if pheno_col_list is not None:
            phenos = pheno_col_list
        elif step2_category == "mask":
            phenos = ["dummy"]
        else:
            pheno_df = pd.read_csv(phenotype_file, sep="\t", nrows=0)
            phenos = [c for c in pheno_df.columns if c not in ["FID", "IID"]]

        input_dict["regenie_workflow.phenoColList"] = phenos
        input_dict["regenie_workflow.phenoColString"] = ",".join(phenos)
        if run_step1:
            input_dict["regenie_workflow.bed_file"] = f"{self.bucket}/data/array/arrays.bed"
            input_dict["regenie_workflow.bim_file"] = f"{self.bucket}/data/array/arrays.bim"
            input_dict["regenie_workflow.fam_file"] = f"{self.bucket}/data/array/arrays.fam"
            input_dict["regenie_workflow.keep_variant_file"] = f"{self.bucket}/data/array/qc/final_array_snps_GRCh38_qc_pass_pruned.prune.in"
            input_dict["regenie_workflow.keep_sample_file"] = f"{self.bucket}/data/array/qc/final_array_snps_GRCh38_qc_pass.id"
        if not prefix:
            prefix = phase_prefix if phase_prefix else f"{step2_mode}_{run_label}"
        input_dict["regenie_workflow.prefix"] = prefix

        input_dict["regenie_workflow.chrs"] = chrs

        # Step 2 burden/mask inputs
        if burden_mode:
            input_dict["regenie_workflow.bgen_files"] = [f"{self.bucket}/data/bgen/chr{chrm}.bgen" for chrm in chrs]
            input_dict["regenie_workflow.sample_files"] = [f"{self.bucket}/data/bgen/chr{chrm}.sample" for chrm in chrs]
            input_dict["regenie_workflow.index_files"] = [f"{self.bucket}/data/bgen/chr{chrm}.bgen.bgi" for chrm in chrs]
            input_dict["regenie_workflow.set_files"] = [f"{self.bucket}/data/associations/burden/chr{chrm}_sets_{burden_type}.tsv.gz" for chrm in chrs]
            input_dict["regenie_workflow.anno_files"] = [f"{self.bucket}/data/associations/burden/chr{chrm}_annotations_{burden_type}.tsv.gz" for chrm in chrs]
            input_dict["regenie_workflow.aaf_files"] = [f"{self.bucket}/data/associations/burden/chr{chrm}_aafs_{burden_type}.tsv.gz" for chrm in chrs]
            input_dict["regenie_workflow.mask_files"] = [f"{self.bucket}/data/associations/burden/chr{chrm}_masks_{burden_type}.tsv.gz" for chrm in chrs]
            if extract_setlist:
                input_dict["regenie_workflow.extract_setlist"] = extract_setlist

        # Step 2 interaction inputs
        if interaction_mode:
            if anchor_chrm is None:
                raise ValueError("interaction runs require anchor_chrm.")
            if not interaction_snp:
                raise ValueError("interaction runs require interaction_snp.")
            input_dict["regenie_workflow.interaction_snp"] = interaction_snp
            input_dict["regenie_workflow.interaction_bed"] = f"{self.bucket}/data/associations/masks/{burden_type}/chr{anchor_chrm}/chr{anchor_chrm}_masks.bed"
            input_dict["regenie_workflow.interaction_bim"] = f"{self.bucket}/data/associations/masks/{burden_type}/chr{anchor_chrm}/chr{anchor_chrm}_masks.bim"
            input_dict["regenie_workflow.interaction_fam"] = f"{self.bucket}/data/associations/masks/{burden_type}/chr{anchor_chrm}/chr{anchor_chrm}_masks.fam"
            input_dict["regenie_workflow.target_bed_files"] = [f"{self.bucket}/data/associations/masks/{burden_type}/chr{chrm}/chr{chrm}_masks.bed" for chrm in chrs]
            input_dict["regenie_workflow.target_bim_files"] = [f"{self.bucket}/data/associations/masks/{burden_type}/chr{chrm}/chr{chrm}_masks.bim" for chrm in chrs]
            input_dict["regenie_workflow.target_fam_files"] = [f"{self.bucket}/data/associations/masks/{burden_type}/chr{chrm}/chr{chrm}_masks.fam" for chrm in chrs]
            if extract_file:
                input_dict["regenie_workflow.extract_file"] = extract_file
            if interaction_file_reffirst:
                input_dict["regenie_workflow.interaction_file_reffirst"] = interaction_file_reffirst
            if no_condtl:
                input_dict["regenie_workflow.no_condtl"] = no_condtl
            if force_condtl:
                input_dict["regenie_workflow.force_condtl"] = force_condtl

        if (not run_step1) and (not ignore_pred):
            if not step1_workflow_id:
                step1_workflow_id = self.get_step1_workflow_id(phase_prefix, workflow_json=workflow_json)
            assert step1_workflow_id

            pred_file = f"{self.bucket}/cromwell-execution/regenie_workflow/{step1_workflow_id}/call-regenie_step1/{phase_prefix}_pheno_pred.list"
            input_dict["regenie_workflow.pred_file"] = pred_file

            loco_file_prefix = f"cromwell-execution/regenie_workflow/{step1_workflow_id}/call-regenie_step1/"
            input_dict["regenie_workflow.loco_files"] = [f for f in self.list_gcs_files(loco_file_prefix) if f.endswith("loco")]

        with open(json_filename, "w") as f:
            json.dump(input_dict, f, indent=4)

        return json_filename

    def create_burden_input_dict(
        self,
        phase_prefix,
        run_step1=True,
        isbinary=False,
        burden_type="plof",
        step2_category="burden",
        run_label="default",
        workflow_json="workflow_metadata.json",
        step1_workflow_id="",
        chrs=None,
        json_filename=""
    ):
        if step2_category not in {"burden", "skato"}:
            raise ValueError("create_burden_input_dict only supports step2_category='burden' or 'skato'.")
        return self.create_input_dict(
            phase_prefix=phase_prefix,
            run_step1=run_step1,
            isbinary=isbinary,
            burden_type=burden_type,
            step2_category=step2_category,
            step2_mode=burden_type,
            run_label=run_label,
            workflow_json=workflow_json,
            step1_workflow_id=step1_workflow_id,
            chrs=chrs,
            json_filename=json_filename
        )

    def create_mask_input_dict(
        self,
        chrm=None,
        gene=None,
        isbinary=False,
        burden_type="plof",
        workflow_json="workflow_metadata.json",
        run_label="",
        json_filename=""
    ):
        if chrm is None:
            if gene:
                raise ValueError("gene-restricted mask creation requires a chromosome.")
            chrs = list(range(1, 23))
        else:
            chrs = [int(chrm)]

        phenotype_file = self.prepare_mask_phenotype_file(burden_type=burden_type, chrm=chrs[0])
        if not run_label:
            if chrm is None:
                run_label = "all_chr"
            else:
                run_label = f"chr{chrm}" if not gene else f"chr{chrm}_{gene}"
        extract_setlist = gene or ""
        return self.create_input_dict(
            phase_prefix=None,
            run_step1=False,
            isbinary=isbinary,
            burden_type=burden_type,
            step2_category="mask",
            step2_mode=burden_type,
            run_label=run_label,
            workflow_json=workflow_json,
            extract_setlist=extract_setlist,
            chrs=chrs,
            phenotype_file=phenotype_file,
            prefix=f"{burden_type}_{run_label}",
            pheno_col_list=["dummy"],
            json_filename=json_filename
        )

    def create_interaction_input_dict(
        self,
        phase_prefix,
        anchor_gene,
        anchor_chrm,
        chrs,
        target_gene="",
        extract_file="",
        ignore_pred=False,
        run_step1=True,
        isbinary=False,
        burden_type="plof",
        mask="pLoF_strict",
        aaf_bin="0.01",
        interaction_model="dom",
        run_label="",
        workflow_json="workflow_metadata.json",
        step1_workflow_id="",
        interaction_file_reffirst=False,
        no_condtl=False,
        force_condtl=False,
        json_filename=""
    ):
        interaction_snp = self.build_mask_id(
            anchor_gene, mask=mask, aaf_bin=aaf_bin, interaction_model=interaction_model
        )

        if not run_label:
            run_label = f"{anchor_gene}_vs_{target_gene}" if target_gene else f"{anchor_gene}_vs_chr{chrs[0]}"

        return self.create_input_dict(
            phase_prefix=phase_prefix,
            run_step1=run_step1,
            isbinary=isbinary,
            burden_type=burden_type,
            step2_category="interaction",
            step2_mode=burden_type,
            run_label=run_label,
            workflow_json=workflow_json,
            step1_workflow_id=step1_workflow_id,
            ignore_pred=ignore_pred,
            interaction_snp=interaction_snp,
            anchor_chrm=anchor_chrm,
            chrs=[chrs] if isinstance(chrs, (str, int)) else chrs,
            extract_file=extract_file,
            interaction_file_reffirst=interaction_file_reffirst,
            no_condtl=no_condtl,
            force_condtl=force_condtl,
            json_filename=json_filename
        )

    def read_cromshell_output(self, result):
        submission_info = self._parse_cromshell_json(result)
        workflow_id = submission_info.get("id")
        return workflow_id

    def track_workflow_id(
        self,
        phase_prefix,
        workflow_json,
        result,
        run_step1=False,
        step2_category="burden",
        step2_mode="plof",
        run_label="default"
    ):
        if result.returncode == 0:
            workflow_dict = self._load_workflow_metadata(workflow_json)
            workflow_id = self.read_cromshell_output(result)

            if workflow_id:
                if step2_category == "mask":
                    workflow_dict.setdefault("mask", {}).setdefault(step2_mode, {})[run_label] = {"workflow_id": workflow_id}
                else:
                    phase_entry = self._ensure_workflow_entry(workflow_dict, phase_prefix)
                    if run_step1:
                        phase_entry["step1"] = {"workflow_id": workflow_id}
                    mode_runs = phase_entry["step2"].setdefault(step2_category, {}).setdefault(step2_mode, [])
                    updated = False
                    for run in mode_runs:
                        if run.get("run_label") == run_label:
                            run["workflow_id"] = workflow_id
                            updated = True
                            break
                    if not updated:
                        mode_runs.append({"run_label": run_label, "workflow_id": workflow_id})
                self._save_workflow_metadata(workflow_json, workflow_dict)
            else:
                label = phase_prefix if phase_prefix else f"{step2_category}:{step2_mode}:{run_label}"
                print(f"Warning: No workflow ID found in JSON output for {label}. File not updated.")
                print(result.stdout)

        else:
            label = phase_prefix if phase_prefix else f"{step2_category}:{step2_mode}:{run_label}"
            print(f"Submission failed for {label}:")
            print(result.stderr)
        return

    def submit_and_track_workflow(
        self,
        json_filename,
        phase_prefix=None,
        workflow_json="workflow_metadata.json",
        run_step1=False,
        step2_category="burden",
        step2_mode="plof",
        run_label="default"
    ):
        result = subprocess.run(
            ["cromshell", "submit", "regenie.wdl", json_filename],
            capture_output=True,
            text=True
        )
        self.track_workflow_id(
            phase_prefix=phase_prefix,
            workflow_json=workflow_json,
            result=result,
            run_step1=run_step1,
            step2_category=step2_category,
            step2_mode=step2_mode,
            run_label=run_label
        )
        return

    # Save cromwell results
    def process_burden_df(self, df: pd.DataFrame) -> pd.DataFrame:
        return REGENIE._process_regenie_df_impl(df)

    @staticmethod
    def _add_phecode_descriptions(meta_df: pd.DataFrame) -> pd.DataFrame:
        labels_resource = files("biobanking").joinpath("assets/phecodeX_R_labels.csv")
        with as_file(labels_resource) as labels_path:
            labels_df = pd.read_csv(labels_path, usecols=["phenotype", "description"], dtype={"phenotype": str})
        labels_df = labels_df.drop_duplicates(subset=["phenotype"])
        pheno_to_description = labels_df.set_index("phenotype")["description"]
        meta_df["description"] = meta_df["pheno"].astype(str).map(pheno_to_description)
        return meta_df

    @staticmethod
    def _parse_cromshell_json(result):
        lines = result.stdout.strip().splitlines()
        start = end = None
        for i, line in enumerate(lines):
            if line.startswith("{"):
                start = i
                break
        for i in range(len(lines) - 1, -1, -1):
            if lines[i].endswith("}"):
                end = i
                break
        if start is None or end is None or end < start:
            return {}
        return json.loads("".join(lines[start:end + 1]))

    def _collect_workflow_runs(
        self,
        workflow_json="workflow_metadata.json",
        phase_prefix=None,
        step2_category="burden",
        step2_mode="plof",
        run_label=None
    ):
        workflow_dict = self._load_workflow_metadata(workflow_json)

        if step2_category == "mask":
            mask_runs = workflow_dict.get("mask", {}).get(step2_mode, {})
            runs = []
            for label, info in mask_runs.items():
                if not info.get("workflow_id"):
                    continue
                if run_label is not None and label != run_label:
                    continue
                runs.append(("mask", {"run_label": label, "workflow_id": info["workflow_id"]}))
            return runs

        if not phase_prefix:
            raise ValueError("phase_prefix is required for burden and interaction workflows.")

        matching_prefixes = [key for key in workflow_dict.keys() if str(key).startswith(phase_prefix)]
        if not matching_prefixes:
            return []

        workflow_runs = []
        for matched_prefix in matching_prefixes:
            runs = [
                run
                for run in workflow_dict.get(matched_prefix, {}).get("step2", {}).get(step2_category, {}).get(step2_mode, [])
                if run.get("workflow_id") and (run_label is None or run.get("run_label") == run_label)
            ]
            workflow_runs.extend((matched_prefix, run) for run in runs)
        return workflow_runs

    def track_cromwell_results(
        self,
        phase_prefix=None,
        workflow_json="workflow_metadata.json",
        step2_category="burden",
        step2_mode="plof",
        run_label=None
    ):
        workflow_runs = self._collect_workflow_runs(
            workflow_json=workflow_json,
            phase_prefix=phase_prefix,
            step2_category=step2_category,
            step2_mode=step2_mode,
            run_label=run_label,
        )

        if not workflow_runs:
            scope = f"prefix '{phase_prefix}'" if phase_prefix else "mask workflows"
            if run_label is not None:
                scope += f" and run_label '{run_label}'"
            print(f"No workflows found for {scope} in {workflow_json}.")
            return pd.DataFrame(columns=["phase_prefix", "step2_category", "step2_mode", "run_label", "workflow_id", "status"])

        status_rows = []
        for matched_prefix, run in workflow_runs:
            workflow_id = run["workflow_id"]
            result = subprocess.run(
                ["cromshell", "status", workflow_id],
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                info = self._parse_cromshell_json(result)
                status = info.get("status", "Unknown")
            else:
                status = "Error"
            status_rows.append({
                "phase_prefix": matched_prefix,
                "step2_category": step2_category,
                "step2_mode": step2_mode,
                "run_label": run.get("run_label", "default"),
                "workflow_id": workflow_id,
                "status": status,
            })

        status_df = pd.DataFrame(status_rows)
        if not status_df.empty:
            for row in status_df.itertuples(index=False):
                print(f"{row.phase_prefix}:{row.run_label} {row.status}")
        return status_df

    def save_cromwell_results(
        self,
        phase_prefix=None,
        workflow_json="workflow_metadata.json",
        n_workers=None,
        phecodes=False,
        step2_category="burden",
        step2_mode="plof",
        run_label=None
    ):
        if step2_category == "mask":
            return self._save_mask_outputs(
                workflow_json=workflow_json,
                step2_mode=step2_mode
            )

        workflow_runs = self._collect_workflow_runs(
            workflow_json=workflow_json,
            phase_prefix=phase_prefix,
            step2_category=step2_category,
            step2_mode=step2_mode,
            run_label=run_label,
        )

        if not workflow_runs:
            scope = f"prefix '{phase_prefix}'"
            if run_label is not None:
                scope += f" and run_label '{run_label}'"
            print(f"No workflows found for {scope} in {workflow_json}.")
            return

        workflow_jobs = []
        for matched_prefix, run in workflow_runs:
            wid = run["workflow_id"]
            merge_call = "call-merge_regenie_outputs_interaction" if step2_category == "interaction" else "call-merge_regenie_outputs_burden"
            wprefix = f"cromwell-execution/regenie_workflow/{wid}/{merge_call}/"
            all_filepaths = self.list_gcs_files(wprefix)
            workflow_jobs.append((run.get("run_label", "default"), step2_category, step2_mode, all_filepaths))

        if n_workers is None:
            n_workers = min(len(workflow_jobs), max(1, (os.cpu_count() or 1) - 1))
        n_workers = max(1, n_workers)

        if n_workers == 1:
            iterator = map(REGENIE._load_workflow_results, workflow_jobs)
            workflow_results = list(
                tqdm(
                    iterator,
                    total=len(workflow_jobs),
                    desc=f"Workflows ({phase_prefix})",
                    unit="workflow"
                )
            )
        else:
            with mp.Pool(processes=n_workers) as pool:
                iterator = pool.imap_unordered(REGENIE._load_workflow_results, workflow_jobs)
                workflow_results = list(
                    tqdm(
                        iterator,
                        total=len(workflow_jobs),
                        desc=f"Workflows ({phase_prefix})",
                        unit="workflow"
                    )
                )

        meta_frames = [df for df in workflow_results if df is not None and not df.empty]
        if not meta_frames:
            print(f"No result files found for prefix '{phase_prefix}'.")
            return

        meta_df = pd.concat(meta_frames, ignore_index=True)
        del meta_frames
        print(f"Total associations loaded for prefix '{phase_prefix}': {len(meta_df)}")
        if phecodes:
            meta_df = REGENIE._add_phecode_descriptions(meta_df)
        if step2_category == "interaction":
            self._save_interaction_results(meta_df, phase_prefix, step2_mode)
        else:
            self._save_burden_results(meta_df, phase_prefix, step2_category, step2_mode)
        return

    def _save_burden_results(self, meta_df, phase_prefix, step2_category, step2_mode):
        meta_df.to_parquet(
            f"{self.bucket}/data/associations/results/{step2_category}/{step2_mode}/{phase_prefix}/meta_results.parquet",
            index=False
        )
        print(f"Meta results saved for prefix '{phase_prefix}' with {len(meta_df)} associations.")
        for (chrom, gene), gdf in meta_df.groupby(["chrom", "gene"], sort=False):
            chrm = f"chr{chrom}"
            out_path = f"{self.bucket}/data/associations/results/{step2_category}/{step2_mode}/{phase_prefix}/{chrm}/{gene}.csv.gz"
            gdf.to_csv(out_path, index=False, compression="gzip")
        return

    def _save_interaction_results(self, meta_df, phase_prefix, step2_mode):
        for run_label, rdf in meta_df.groupby("run_label", sort=False):
            base_dir = f"{self.bucket}/data/associations/results/interaction/{step2_mode}/{phase_prefix}/{run_label}"
            rdf.to_parquet(f"{base_dir}/meta_results.parquet", index=False)
            for chrom, cdf in rdf.groupby("chrom", sort=False):
                out_path = f"{base_dir}/chr{chrom}.csv.gz"
                cdf.to_csv(out_path, index=False, compression="gzip")
            print(f"Interaction results saved for prefix '{phase_prefix}', run '{run_label}' with {len(rdf)} rows.")
        return

    def _save_mask_outputs(self, workflow_json="workflow_metadata.json", step2_mode="plof"):
        workflow_dict = self._load_workflow_metadata(workflow_json)
        mask_runs = workflow_dict.get("mask", {}).get(step2_mode, {})
        if not mask_runs:
            print(f"No mask workflows found for mode '{step2_mode}' in {workflow_json}.")
            return

        workflow_jobs = []
        for run_info in mask_runs.values():
            wid = run_info.get("workflow_id")
            if not wid:
                continue
            wprefix = f"cromwell-execution/regenie_workflow/{wid}/call-regenie_step2_burden/"
            all_filepaths = self.list_gcs_files(wprefix)
            workflow_jobs.append((wid, all_filepaths))

        discovered = []
        for workflow_job in workflow_jobs:
            discovered.extend(REGENIE._load_mask_outputs_impl(workflow_job))
        if not discovered:
            print(f"No mask outputs found for mode '{step2_mode}'.")
            return

        from google.cloud import storage

        storage_client = storage.Client()
        bucket_obj = storage_client.bucket(self.bucket.lstrip("gs://"))
        copied = 0
        for chrom, src_path in discovered:
            src_blob_name = src_path.replace(f"{self.bucket}/", "", 1)
            src_blob = bucket_obj.blob(src_blob_name)
            _, ext = os.path.splitext(src_blob_name)
            dst_blob_name = f"data/associations/masks/{step2_mode}/chr{chrom}/chr{chrom}_masks{ext}"
            bucket_obj.copy_blob(src_blob, bucket_obj, dst_blob_name)
            copied += 1

        print(f"Saved {copied} mask files to {self.bucket}/data/associations/masks/{step2_mode}/")
        return
