from pathlib import Path
import re
import textwrap
from typing import Iterable

import matplotlib.pyplot as plt
from matplotlib import transforms
import numpy as np
import pandas as pd


PathLike = str | Path


def _as_list(value: str | Iterable[str] | None) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    return list(value)


def _load_csv_results(data: pd.DataFrame | PathLike | Iterable[PathLike]) -> pd.DataFrame:
    if isinstance(data, pd.DataFrame):
        return data.copy()

    if isinstance(data, (str, Path)):
        paths = [data]
    else:
        paths = list(data)

    if not paths:
        raise ValueError("No burden result files were provided.")

    frames = []
    for path in paths:
        path = Path(path)
        suffixes = path.suffixes
        if suffixes[-2:] != [".csv", ".gz"] and suffixes[-1:] != [".csv"]:
            raise ValueError(f"Burden forest plots currently support CSV inputs only: {path}")
        frames.append(pd.read_csv(path))

    if not frames:
        raise ValueError("No burden result rows could be loaded.")
    return pd.concat(frames, ignore_index=True)


def _load_excel_reference(data: pd.DataFrame | PathLike | None) -> pd.DataFrame:
    if isinstance(data, pd.DataFrame):
        return data.copy()
    if data is None:
        raise ValueError("Carrier count annotations require an explicit dataframe or Excel filepath.")

    def _read_excel(path: Path) -> pd.DataFrame:
        try:
            return pd.read_excel(path)
        except ImportError as exc:
            raise ImportError(
                f"Reading Excel carrier counts requires the optional 'openpyxl' dependency: {path}"
            ) from exc

    return _read_excel(Path(data))


def _normalize_string(value: object) -> str:
    if pd.isna(value):
        return ""
    if isinstance(value, (int, np.integer)):
        return str(int(value))
    if isinstance(value, (float, np.floating)):
        return f"{float(value):g}"
    return str(value).strip()


def _normalize_gene(value: object) -> str:
    return _normalize_string(value).upper()


def _prepare_gene_carrier_counts(data: pd.DataFrame | PathLike | None) -> pd.DataFrame:
    df = _load_excel_reference(data)
    required = ["gene", "mask_type", "aaf_bin", "n_carriers"]
    missing = [col for col in required if col not in df.columns]
    if missing:
        raise ValueError(f"Missing required gene carrier count columns: {missing}")

    prepared = df.copy()
    prepared["gene_key"] = prepared["gene"].map(_normalize_gene)
    prepared["mask_key"] = prepared["mask_type"].map(_normalize_string)
    prepared["aaf_key"] = prepared["aaf_bin"].map(_normalize_string)
    prepared["n_carriers"] = pd.to_numeric(prepared["n_carriers"], errors="coerce")

    grouped = (
        prepared.groupby(["gene_key", "mask_key", "aaf_key"], observed=True)["n_carriers"]
        .sum(min_count=1)
        .reset_index(name="n_carriers_total")
    )
    grouped["n_carriers_total"] = grouped["n_carriers_total"].round().astype("Int64")
    return grouped


def _prepare_combo_carrier_counts(data: pd.DataFrame | PathLike | None) -> pd.DataFrame:
    df = _load_excel_reference(data)
    required = ["gene1", "mask_type_1", "aaf_bin_1", "gene2", "mask_type_2", "aaf_bin_2", "total_co"]
    missing = [col for col in required if col not in df.columns]
    if missing:
        raise ValueError(f"Missing required combo carrier count columns: {missing}")

    prepared = df.copy()
    prepared["gene1_key"] = prepared["gene1"].map(_normalize_gene)
    prepared["mask1_key"] = prepared["mask_type_1"].map(_normalize_string)
    prepared["aaf1_key"] = prepared["aaf_bin_1"].map(_normalize_string)
    prepared["gene2_key"] = prepared["gene2"].map(_normalize_gene)
    prepared["mask2_key"] = prepared["mask_type_2"].map(_normalize_string)
    prepared["aaf2_key"] = prepared["aaf_bin_2"].map(_normalize_string)
    prepared["total_co"] = pd.to_numeric(prepared["total_co"], errors="coerce").round().astype("Int64")
    return prepared


def _lookup_gene_carrier_total(gene_counts: pd.DataFrame, gene: object, mask: object, aaf_bin: object):
    matches = gene_counts.loc[
        (gene_counts["gene_key"] == _normalize_gene(gene))
        & (gene_counts["mask_key"] == _normalize_string(mask))
        & (gene_counts["aaf_key"] == _normalize_string(aaf_bin)),
        "n_carriers_total",
    ]
    if matches.empty:
        return pd.NA
    return matches.iloc[0]


def _lookup_combo_carrier_total(
    combo_counts: pd.DataFrame,
    anchor_gene: object,
    anchor_mask: object,
    anchor_aaf_bin: object,
    target_gene: object,
    target_mask: object,
    target_aaf_bin: object,
):
    matches = combo_counts.loc[
        (combo_counts["gene1_key"] == _normalize_gene(anchor_gene))
        & (combo_counts["mask1_key"] == _normalize_string(anchor_mask))
        & (combo_counts["aaf1_key"] == _normalize_string(anchor_aaf_bin))
        & (combo_counts["gene2_key"] == _normalize_gene(target_gene))
        & (combo_counts["mask2_key"] == _normalize_string(target_mask))
        & (combo_counts["aaf2_key"] == _normalize_string(target_aaf_bin)),
        "total_co",
    ]
    if matches.empty:
        return pd.NA
    return matches.iloc[0]


def _format_count(value: object) -> str:
    if pd.isna(value):
        return "NA"
    return str(int(value))


def _format_pvalue(pvalue: float) -> str:
    if pd.isna(pvalue):
        return "NA"
    if pvalue == 0:
        return r"$0.00 \times 10^{0}$"
    coeff, exp = f"{pvalue:.2e}".split("e")
    return rf"${coeff} \times 10^{{{int(exp)}}}$"


def _format_effect_ci(effect: float, ci_low: float, ci_high: float) -> str:
    if pd.isna(effect) or pd.isna(ci_low) or pd.isna(ci_high):
        return "NA"
    return f"{effect:.2f} ({ci_low:.2f}, {ci_high:.2f})"


def _format_pheno_label(value: object, wrap_width: int = 20, max_length: int = 40) -> tuple[str, int]:
    text = re.sub(r"_+", " ", str(value)).strip()
    if len(text) > max_length:
        text = text[: max_length - 3].rstrip() + "..."
    if len(text) <= wrap_width:
        return text, 9
    wrapped = textwrap.wrap(
        text,
        width=wrap_width,
        max_lines=2,
        placeholder="...",
        break_long_words=True,
        break_on_hyphens=False,
    )
    return "\n".join(wrapped), 8


def _resolve_first_present_column(df: pd.DataFrame, candidates: Iterable[str], label: str) -> str:
    for candidate in candidates:
        if candidate in df.columns:
            return candidate
    raise ValueError(f"Could not find a column for {label}. Tried: {list(candidates)}")


def _describe_interaction_test(test: str, anchor_label: str = "anchor", target_label: str = "target") -> str:
    if pd.isna(test):
        return "Unknown interaction term"
    if test == "ADD":
        return f"Marginal additive effect of {target_label}"
    if test == "ADD-CONDTL":
        return f"Conditional main effect of {target_label}"
    if test == "ADD-INT_SNP":
        return f"Main effect :: {target_label}"
    if test.startswith("ADD-INT_SNPx"):
        return "Interaction Effect"
    if re.fullmatch(r"ADD-INT_\d+DF", str(test)):
        return "Joint Effect"
    if str(test).startswith("ADD-INT_"):
        return f"Main effect :: {anchor_label}"
    return str(test)


def _interaction_test_category(test: str) -> str:
    test = str(test)
    if test == "ADD-INT_SNP":
        return "target_main"
    if test.startswith("ADD-INT_SNPx"):
        return "interaction"
    if re.fullmatch(r"ADD-INT_\d+DF", test):
        return "joint"
    if test.startswith("ADD-INT_"):
        return "anchor_main"
    if test == "ADD-CONDTL":
        return "conditional_main"
    if test == "ADD":
        return "marginal"
    return "other"


def _expected_interaction_run_label(anchor_gene: str, target_gene: str) -> str:
    return f"{anchor_gene}_vs_{target_gene}"


def _is_expected_interaction_test(test: object, anchor_gene: str, anchor_mask: str, anchor_aaf_bin: str) -> bool:
    test = _normalize_string(test)
    anchor_id = f"{anchor_gene}.{anchor_mask}.{anchor_aaf_bin}"
    if test in {"ADD", "ADD-CONDTL", "ADD-INT_SNP"}:
        return True
    if test == f"ADD-INT_{anchor_id}":
        return True
    if test == f"ADD-INT_SNPx{anchor_id}":
        return True
    return bool(re.fullmatch(r"ADD-INT_\d+DF", test))


def _has_complete_interaction_terms(categories: Iterable[object]) -> bool:
    required = {"target_main", "anchor_main", "interaction", "joint"}
    observed = {str(value) for value in categories}
    return required.issubset(observed)


def _resolve_interaction_pheno_rank_categories(rank_by: str) -> tuple[str, ...]:
    rank_by = str(rank_by)
    if rank_by == "joint":
        return ("joint",)
    if rank_by == "interaction":
        return ("interaction",)
    raise ValueError("pheno_rank_by must be either 'joint' or 'interaction'.")


def _rank_interaction_phenotypes(
    df: pd.DataFrame,
    *,
    pheno_col: str,
    pvalue_col: str,
    rank_categories: Iterable[str],
) -> pd.Series:
    rank_categories = tuple(rank_categories)
    rank_df = df.loc[df["test_category"].isin(rank_categories)].copy()
    if rank_df.empty:
        categories = ", ".join(rank_categories)
        raise ValueError(f"No phenotype-ranking interaction rows are available for categories: {categories}.")
    return rank_df.groupby(pheno_col, sort=False)[pvalue_col].min().sort_values()


def _find_burden_row(
    burden_df: pd.DataFrame,
    *,
    gene: str,
    pheno: object,
    mask: object,
    aaf_bin: object,
    gene_col: str,
    pheno_col: str,
    mask_col: str,
    aaf_bin_col: str,
) -> pd.Series:
    gene_key = _normalize_gene(gene)
    pheno_key = _normalize_string(pheno)
    mask_key = _normalize_string(mask)
    aaf_key = _normalize_string(aaf_bin)
    matches = burden_df.loc[
        (burden_df["_gene_key"] == gene_key)
        & (burden_df["_pheno_key"] == pheno_key)
        & (burden_df["_mask_key"] == mask_key)
        & (burden_df["_aaf_key"] == aaf_key)
    ].copy()
    if matches.empty:
        raise ValueError(
            "Could not find burden row for "
            f"{gene} / {pheno_col}={pheno} / {mask_col}={mask} / {aaf_bin_col}={aaf_bin}."
        )
    return matches.iloc[0]


def _prepare_interaction_burden_rows(
    selected: pd.DataFrame,
    burden_data: pd.DataFrame | PathLike | Iterable[PathLike],
    *,
    anchor_gene: str,
    target_gene: str,
    anchor_mask: str,
    anchor_aaf_bin: str,
    gene_col: str,
    pheno_col: str,
    test_col: str,
    effect_col: str,
    se_col: str,
    pvalue_col: str,
    mask_col: str,
    aaf_bin_col: str,
    ci_z: float,
) -> pd.DataFrame:
    burden_df = _load_csv_results(burden_data)
    required = [gene_col, pheno_col, pvalue_col, mask_col, aaf_bin_col]
    missing = [col for col in required if col not in burden_df.columns]
    if missing:
        raise ValueError(f"Missing required burden result columns for interaction plot annotations: {missing}")

    burden_effect_col = _resolve_first_present_column(
        burden_df,
        [effect_col, effect_col.lower(), effect_col.upper(), "beta", "BETA"],
        "burden effect size",
    )
    burden_se_col = _resolve_first_present_column(
        burden_df,
        [se_col, se_col.lower(), se_col.upper(), "se", "SE"],
        "burden standard error",
    )
    if test_col in burden_df.columns:
        burden_df = burden_df.loc[burden_df[test_col] == "ADD"].copy()

    burden_df = burden_df.copy()
    burden_df["_gene_key"] = burden_df[gene_col].map(_normalize_gene)
    burden_df["_pheno_key"] = burden_df[pheno_col].map(_normalize_string)
    burden_df["_mask_key"] = burden_df[mask_col].map(_normalize_string)
    burden_df["_aaf_key"] = burden_df[aaf_bin_col].map(_normalize_string)

    rows = []
    base_columns = selected.columns.tolist()
    for pheno_name, pheno_df in selected.groupby(pheno_col, sort=False):
        target_context = pheno_df.loc[pheno_df["test_category"] == "target_main"]
        if target_context.empty:
            target_context = pheno_df.loc[pheno_df["test_category"].isin(["interaction", "joint"])]
        if target_context.empty:
            target_context = pheno_df
        target_mask = target_context.iloc[0][mask_col]
        target_aaf_bin = target_context.iloc[0][aaf_bin_col]

        burden_specs = [
            ("target_burden", target_gene, target_mask, target_aaf_bin),
            ("anchor_burden", anchor_gene, anchor_mask, anchor_aaf_bin),
        ]
        for category, gene, mask, aaf_bin in burden_specs:
            burden_row = _find_burden_row(
                burden_df,
                gene=gene,
                pheno=pheno_name,
                mask=mask,
                aaf_bin=aaf_bin,
                gene_col=gene_col,
                pheno_col=pheno_col,
                mask_col=mask_col,
                aaf_bin_col=aaf_bin_col,
            )
            effect = pd.to_numeric(burden_row[burden_effect_col], errors="coerce")
            se = pd.to_numeric(burden_row[burden_se_col], errors="coerce")
            pvalue = pd.to_numeric(burden_row[pvalue_col], errors="coerce")
            ci_low = effect - ci_z * se
            ci_high = effect + ci_z * se
            out = {col: pd.NA for col in base_columns}
            out.update(
                {
                    gene_col: gene,
                    pheno_col: pheno_name,
                    test_col: "ADD",
                    effect_col: effect,
                    se_col: se,
                    pvalue_col: pvalue,
                    mask_col: mask,
                    aaf_bin_col: aaf_bin,
                    "term": f"Burden :: {gene}",
                    "test_category": category,
                    "ci_low": ci_low,
                    "ci_high": ci_high,
                    "effect_fmt": _format_effect_ci(effect, ci_low, ci_high),
                    "pvalue_fmt": _format_pvalue(pvalue),
                    "_pheno_order": pheno_df.iloc[0]["_pheno_order"],
                    "_term_order": 0 if category == "target_burden" else 1,
                    "_joint_df": 0,
                }
            )
            for optional_col in base_columns:
                if optional_col in burden_row.index and pd.isna(out[optional_col]):
                    out[optional_col] = burden_row[optional_col]
            rows.append(out)

    if not rows:
        return selected
    burden_rows = pd.DataFrame(rows, columns=base_columns)
    selected = selected.copy()
    selected["_term_order"] = selected["_term_order"] + 2
    return pd.concat([burden_rows, selected], ignore_index=True)


def plot_burden_forest(
    data: pd.DataFrame | PathLike | Iterable[PathLike],
    gene: str | Iterable[str] | None = None,
    pheno: str | Iterable[str] | None = None,
    top_n: int | None = None,
    pvalue_threshold: float = 0.05,
    gene_col: str = "gene",
    pheno_col: str = "pheno",
    effect_col: str = "beta",
    se_col: str = "se",
    pvalue_col: str = "pvalue",
    mask_col: str = "mask",
    aaf_bin_col: str = "aaf_bin",
    test_col: str = "test",
    test: str | None = "ADD",
    mask: str | None = "best",
    aaf_bin: str | None = None,
    ci_z: float = 1.96,
    figsize: tuple[float, float] | None = None,
    title: str | None = None,
    xlabel: str = "Effect size",
    point_color: str = "#1f5aa6",
    error_color: str = "#4a4a4a",
    reference_line_color: str = "#999999",
    alternate_row_color: str = "#f5f5f5",
    ax=None,
):
    """Create a generalized forest plot for burden association CSV results.

    Mode is inferred from ``gene`` and ``pheno``:
    - single phenotype: ``pheno`` is a single string and ``gene`` is None
    - single gene: ``gene`` is a single string and ``pheno`` is None
    - multi mode: any case where at least one of ``gene`` or ``pheno`` contains multiple values,
      or both are provided together

    In multi mode, rows are filtered by the supplied gene/pheno lists independently, then shown
    as gene | phenotype labels.

    By default, ``mask="best"`` keeps the single most significant row for each unique
    gene/phenotype pair after all other filters are applied.
    """
    df = _load_csv_results(data)

    required = [gene_col, pheno_col, effect_col, se_col, pvalue_col]
    missing = [col for col in required if col not in df.columns]
    if missing:
        raise ValueError(f"Missing required burden result columns: {missing}")

    genes = _as_list(gene)
    phenos = _as_list(pheno)

    work_df = df.copy()

    if test is not None:
        if test_col not in work_df.columns:
            raise ValueError(f"Column '{test_col}' is required when test filtering is used.")
        work_df = work_df.loc[work_df[test_col] == test].copy()

    if mask not in {None, "best"}:
        if mask_col not in work_df.columns:
            raise ValueError(f"Column '{mask_col}' is required when mask filtering is used.")
        work_df = work_df.loc[work_df[mask_col] == mask].copy()

    if aaf_bin is not None:
        if aaf_bin_col not in work_df.columns:
            raise ValueError(f"Column '{aaf_bin_col}' is required when aaf_bin filtering is used.")
        work_df = work_df.loc[work_df[aaf_bin_col] == aaf_bin].copy()

    if pvalue_threshold is not None:
        work_df = work_df.loc[work_df[pvalue_col] <= pvalue_threshold].copy()

    if genes:
        work_df = work_df.loc[work_df[gene_col].isin(genes)].copy()
    if phenos:
        work_df = work_df.loc[work_df[pheno_col].isin(phenos)].copy()

    if mask == "best":
        work_df = (
            work_df.sort_values([pvalue_col, effect_col], ascending=[True, False])
            .drop_duplicates(subset=[gene_col, pheno_col], keep="first")
            .copy()
        )

    single_gene_mode = len(genes) == 1 and not phenos
    single_pheno_mode = len(phenos) == 1 and not genes
    multi_mode = not single_gene_mode and not single_pheno_mode

    if work_df.empty:
        raise ValueError("No burden rows remain after filtering.")

    if single_pheno_mode:
        selected = work_df.sort_values([pvalue_col, effect_col], ascending=[True, False]).copy()
        selected["forest_label"] = selected[gene_col].astype(str)
        label_header = "Gene"
        if title is None:
            title = f"Top burden associations for {phenos[0]}"
    elif single_gene_mode:
        selected = work_df.sort_values([pvalue_col, effect_col], ascending=[True, False]).copy()
        selected["forest_label"] = selected[pheno_col].astype(str)
        label_header = "Phenotype"
        if title is None:
            title = f"Top phenotypes for {genes[0]}"
    else:
        selected = work_df.sort_values([gene_col, pheno_col, pvalue_col, effect_col], ascending=[True, True, True, False]).copy()
        selected["forest_label"] = selected[gene_col].astype(str) + " | " + selected[pheno_col].astype(str)
        label_header = "Gene | Phenotype"
        if title is None:
            title = "Selected burden associations"

    if top_n is not None:
        selected = selected.head(top_n).copy()

    if selected.empty:
        raise ValueError("No burden rows remain after applying top_n.")

    selected["ci_low"] = selected[effect_col] - ci_z * selected[se_col]
    selected["ci_high"] = selected[effect_col] + ci_z * selected[se_col]
    selected["pvalue_fmt"] = selected[pvalue_col].map(_format_pvalue)
    selected["effect_fmt"] = selected.apply(
        lambda row: f"{row[effect_col]:.2f} ({row['ci_low']:.2f}, {row['ci_high']:.2f})",
        axis=1,
    )
    selected = selected.sort_values(effect_col, ascending=False).reset_index(drop=True)

    n_rows = len(selected)
    if figsize is None:
        row_height = 0.6 if not single_pheno_mode else 0.5
        figsize = (7, min(6, max(2.5, n_rows * row_height)))

    created_fig = False
    if ax is None:
        fig, ax = plt.subplots(figsize=figsize)
        created_fig = True
    else:
        fig = ax.figure

    y = np.arange(n_rows)
    xerr = np.vstack([
        selected[effect_col] - selected["ci_low"],
        selected["ci_high"] - selected[effect_col],
    ])

    for idx in range(n_rows):
        if idx % 2 == 1:
            ax.axhspan(idx - 0.5, idx + 0.5, color=alternate_row_color, zorder=0)

    ax.errorbar(
        selected[effect_col],
        y,
        xerr=xerr,
        fmt="o",
        color=point_color,
        ecolor=error_color,
        elinewidth=1.6,
        capsize=3,
        markersize=6,
        zorder=3,
    )
    ax.axvline(0, color=reference_line_color, linestyle="--", linewidth=1)

    ax.set_yticks(y)
    ax.set_yticklabels([""] * n_rows)
    ax.tick_params(axis="y", length=0)
    ax.set_xlabel(xlabel)
    ax.set_ylabel("")
    ax.set_title(title)
    ax.set_ylim(n_rows - 0.5, -1.2)

    x_min = min(selected["ci_low"].min(), 0)
    x_max = max(selected["ci_high"].max(), 0)
    x_pad = max((x_max - x_min) * 0.12, 0.2)
    ax.set_xlim(x_min - x_pad, x_max + x_pad)

    row_transform = transforms.blended_transform_factory(ax.transAxes, ax.transData)
    header_y = -0.9

    if multi_mode:
        table_columns = [("Gene", -0.46, gene_col), ("Phenotype", -0.22, pheno_col)]
        left_margin = 0.38
    elif single_pheno_mode:
        table_columns = [(label_header, -0.28, gene_col)]
        left_margin = 0.24
    else:
        table_columns = [(label_header, -0.28, pheno_col)]
        left_margin = 0.24

    for header, xpos, col in table_columns:
        ax.text(
            xpos,
            header_y,
            header,
            transform=row_transform,
            fontsize=9,
            fontweight="bold",
            ha="left",
            va="center",
            clip_on=False,
        )
        for idx, row in selected.iterrows():
            value = str(row[col])
            fontsize = 9
            if col == pheno_col:
                value, fontsize = _format_pheno_label(row[col])
            ax.text(
                xpos,
                idx,
                value,
                transform=row_transform,
                fontsize=fontsize,
                ha="left",
                va="center",
                linespacing=0.95,
                clip_on=False,
            )

    effect_x = 1.03
    pvalue_x = 1.38
    ax.text(
        effect_x,
        header_y,
        "Effect (95% CI)",
        transform=row_transform,
        fontsize=9,
        fontweight="bold",
        ha="left",
        va="center",
        clip_on=False,
    )
    ax.text(
        pvalue_x,
        header_y,
        "p-value",
        transform=row_transform,
        fontsize=9,
        fontweight="bold",
        ha="left",
        va="center",
        clip_on=False,
    )
    for idx, row in selected.iterrows():
        ax.text(
            effect_x,
            idx,
            row["effect_fmt"],
            transform=row_transform,
            fontsize=9,
            ha="left",
            va="center",
            clip_on=False,
        )
        ax.text(
            pvalue_x,
            idx,
            row["pvalue_fmt"],
            transform=row_transform,
            fontsize=9,
            ha="left",
            va="center",
            clip_on=False,
        )

    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_visible(False)
    ax.grid(axis="x", color="#dddddd", linewidth=0.8, alpha=0.8)

    if created_fig:
        fig.subplots_adjust(left=left_margin, right=0.68, top=0.90, bottom=0.12)
        fig.tight_layout()

    return fig, ax, selected


def plot_interaction_forest(
    data: pd.DataFrame | PathLike | Iterable[PathLike],
    anchor_gene: str,
    target_gene: str,
    pheno: str | Iterable[str] | None = None,
    top_n: int | None = None,
    burden_data: pd.DataFrame | PathLike | Iterable[PathLike] | None = None,
    run_label: str | None = None,
    include_tests: Iterable[str] | None = None,
    exclude_tests: Iterable[str] = ("ADD", "ADD-CONDTL"),
    pvalue_threshold: float | None = 0.05,
    threshold_categories: Iterable[str] | None = ("interaction", "joint"),
    pheno_rank_by: str = "joint",
    gene_col: str = "gene",
    pheno_col: str = "pheno",
    run_label_col: str = "run_label",
    test_col: str = "test",
    effect_col: str = "BETA",
    se_col: str = "SE",
    pvalue_col: str = "pvalue",
    mask_col: str = "mask",
    aaf_bin_col: str = "aaf_bin",
    anchor_mask: str = "pLoF_strict",
    anchor_aaf_bin: str = "0.01",
    require_complete_terms: bool = False,
    show_carrier_counts: bool | None = None,
    gene_carrier_counts: pd.DataFrame | PathLike | None = None,
    combo_carrier_counts: pd.DataFrame | PathLike | None = None,
    ci_z: float = 1.96,
    figsize: tuple[float, float] | None = None,
    title: str | None = None,
    xlabel: str = "Effect size",
    point_color: str = "#1f5aa6",
    error_color: str = "#4a4a4a",
    reference_line_color: str = "#999999",
    alternate_row_color: str = "#f5f5f5",
    ax=None,
):
    """Create an interaction forest plot for one anchor/target gene pair.

    Rows correspond to REGENIE interaction-model terms. By default, plain marginal
    ``ADD`` and ``ADD-CONDTL`` rows are excluded so the plot emphasizes the
    interaction-model outputs. When ``pheno`` is omitted, phenotypes are filtered
    by ``pvalue_threshold`` using only the selected threshold-driving interaction
    test categories per phenotype, and each selected phenotype is shown as a
    grouped block of term rows. Phenotype blocks can then be ranked by either
    the joint-effect or interaction-effect p-value and optionally truncated via
    ``top_n``. When ``burden_data`` is provided, each phenotype block is
    prepended with marginal burden rows for the anchor and target genes.
    When ``require_complete_terms`` is enabled,
    phenotypes are kept only if they contain target-main, anchor-main,
    interaction, and joint rows. Carrier counts are optional and are only added
    when explicit carrier count inputs are supplied, or when
    ``show_carrier_counts=True`` with both carrier inputs provided.
    """
    df = _load_csv_results(data)

    required = [gene_col, pheno_col, test_col, pvalue_col]
    missing = [col for col in required if col not in df.columns]
    if missing:
        raise ValueError(f"Missing required interaction result columns: {missing}")

    work_df = df.copy()
    effect_col = _resolve_first_present_column(work_df, [effect_col, effect_col.lower(), effect_col.upper(), "beta", "BETA"], "effect size")
    se_col = _resolve_first_present_column(work_df, [se_col, se_col.lower(), se_col.upper(), "se", "SE"], "standard error")
    work_df = work_df.loc[work_df[gene_col] == target_gene].copy()
    phenos = _as_list(pheno)
    if phenos:
        work_df = work_df.loc[work_df[pheno_col].isin(phenos)].copy()

    expected_run_label = run_label or _expected_interaction_run_label(anchor_gene, target_gene)
    if run_label_col not in work_df.columns:
        raise ValueError(
            f"Column '{run_label_col}' is required for interaction plots so anchor/target provenance can be verified."
        )
    work_df = work_df.loc[work_df[run_label_col].astype(str) == expected_run_label].copy()

    work_df = work_df.loc[
        work_df[test_col].map(
            lambda value: _is_expected_interaction_test(value, anchor_gene, anchor_mask, anchor_aaf_bin)
        )
    ].copy()

    if include_tests is not None:
        include_tests = set(include_tests)
        work_df = work_df.loc[work_df[test_col].isin(include_tests)].copy()
    else:
        exclude_tests = set(exclude_tests)
        work_df = work_df.loc[~work_df[test_col].isin(exclude_tests)].copy()

    if work_df.empty:
        raise ValueError("No interaction rows remain after filtering.")

    work_df["term"] = work_df[test_col].map(lambda value: _describe_interaction_test(value, anchor_gene, target_gene))
    work_df["test_category"] = work_df[test_col].map(_interaction_test_category)

    if require_complete_terms:
        complete_phenos = (
            work_df.groupby(pheno_col, sort=False)["test_category"]
            .agg(_has_complete_interaction_terms)
            .loc[lambda ser: ser]
            .index
        )
        if len(complete_phenos) == 0:
            raise ValueError("No phenotypes remain after requiring complete interaction-term sets.")
        work_df = work_df.loc[work_df[pheno_col].isin(complete_phenos)].copy()

    rank_categories = _resolve_interaction_pheno_rank_categories(pheno_rank_by)
    if phenos:
        work_df = work_df.sort_values([pheno_col, pvalue_col, test_col]).drop_duplicates(subset=[pheno_col, test_col], keep="first").copy()
        pheno_rank = _rank_interaction_phenotypes(
            work_df,
            pheno_col=pheno_col,
            pvalue_col=pvalue_col,
            rank_categories=rank_categories,
        )
    else:
        if pvalue_threshold is None:
            raise ValueError("pvalue_threshold is required when pheno is not specified.")
        threshold_categories = tuple(threshold_categories) if threshold_categories is not None else ("interaction", "joint")
        threshold_df = work_df.loc[
            work_df["test_category"].isin(threshold_categories)
        ].copy()
        if threshold_df.empty:
            raise ValueError("No threshold-driving interaction rows are available for phenotype filtering.")
        pheno_hits = (
            threshold_df.groupby(pheno_col, sort=False)[pvalue_col]
            .min()
            .loc[lambda ser: ser <= pvalue_threshold]
            .sort_values()
        )
        if pheno_hits.empty:
            raise ValueError("No phenotypes remain after applying the interaction-term p-value threshold.")
        work_df = work_df.loc[work_df[pheno_col].isin(pheno_hits.index)].copy()
        work_df = work_df.sort_values([pheno_col, pvalue_col, test_col]).drop_duplicates(subset=[pheno_col, test_col], keep="first").copy()
        pheno_rank = _rank_interaction_phenotypes(
            work_df,
            pheno_col=pheno_col,
            pvalue_col=pvalue_col,
            rank_categories=rank_categories,
        )

    if top_n is not None:
        pheno_rank = pheno_rank.head(top_n)
        if pheno_rank.empty:
            raise ValueError("No phenotypes remain after applying top_n.")
        work_df = work_df.loc[work_df[pheno_col].isin(pheno_rank.index)].copy()

    work_df[effect_col] = pd.to_numeric(work_df[effect_col], errors="coerce")
    work_df[se_col] = pd.to_numeric(work_df[se_col], errors="coerce")
    work_df["ci_low"] = work_df[effect_col] - ci_z * work_df[se_col]
    work_df["ci_high"] = work_df[effect_col] + ci_z * work_df[se_col]

    work_df["effect_fmt"] = work_df.apply(
        lambda row: _format_effect_ci(
            row.get(effect_col, np.nan),
            row["ci_low"],
            row["ci_high"],
        ),
        axis=1,
    )
    work_df["pvalue_fmt"] = work_df[pvalue_col].map(_format_pvalue)

    term_order = {
        f"Main effect :: {target_gene}": 0,
        f"Main effect :: {anchor_gene}": 1,
        "Interaction Effect": 2,
        "Joint Effect": 3,
    }
    pheno_order_map = {str(name): idx for idx, name in enumerate(pheno_rank.index)}
    selected = (
        work_df.assign(
            _pheno_order=work_df[pheno_col].astype(str).map(lambda value: pheno_order_map.get(value, len(pheno_order_map))),
            _term_order=work_df["term"].map(lambda value: term_order.get(value, 99)),
            _joint_df=work_df[test_col].map(
                lambda value: int(re.search(r"(\d+)DF", str(value)).group(1))
                if re.fullmatch(r"ADD-INT_\d+DF", str(value))
                else 0
            ),
        )
        .sort_values(["_pheno_order", pheno_col, "_term_order", "_joint_df", pvalue_col, test_col])
        .reset_index(drop=True)
    )

    if burden_data is not None:
        selected = _prepare_interaction_burden_rows(
            selected,
            burden_data,
            anchor_gene=anchor_gene,
            target_gene=target_gene,
            anchor_mask=anchor_mask,
            anchor_aaf_bin=anchor_aaf_bin,
            gene_col=gene_col,
            pheno_col=pheno_col,
            test_col=test_col,
            effect_col=effect_col,
            se_col=se_col,
            pvalue_col=pvalue_col,
            mask_col=mask_col,
            aaf_bin_col=aaf_bin_col,
            ci_z=ci_z,
        )
        selected = selected.sort_values(
            ["_pheno_order", pheno_col, "_term_order", "_joint_df", pvalue_col, test_col]
        ).reset_index(drop=True)

    carrier_inputs_provided = gene_carrier_counts is not None or combo_carrier_counts is not None
    if show_carrier_counts is None:
        show_carrier_counts = carrier_inputs_provided
    if show_carrier_counts and not (gene_carrier_counts is not None and combo_carrier_counts is not None):
        raise ValueError(
            "Carrier counts require both 'gene_carrier_counts' and 'combo_carrier_counts' to be provided."
        )

    if show_carrier_counts:
        if mask_col not in selected.columns or aaf_bin_col not in selected.columns:
            raise ValueError(
                f"Carrier counts require '{mask_col}' and '{aaf_bin_col}' columns in the interaction results."
            )
        gene_counts = _prepare_gene_carrier_counts(gene_carrier_counts)
        combo_counts = _prepare_combo_carrier_counts(combo_carrier_counts)
        anchor_total = _lookup_gene_carrier_total(gene_counts, anchor_gene, anchor_mask, anchor_aaf_bin)
        selected["anchor_n_carriers"] = pd.Series([anchor_total] * len(selected), dtype="Int64")
        selected["target_n_carriers"] = selected.apply(
            lambda row: _lookup_gene_carrier_total(gene_counts, row[gene_col], row[mask_col], row[aaf_bin_col]),
            axis=1,
        ).astype("Int64")
        selected["combo_n_carriers"] = selected.apply(
            lambda row: _lookup_combo_carrier_total(
                combo_counts,
                anchor_gene=anchor_gene,
                anchor_mask=anchor_mask,
                anchor_aaf_bin=anchor_aaf_bin,
                target_gene=row[gene_col],
                target_mask=row[mask_col],
                target_aaf_bin=row[aaf_bin_col],
            ),
            axis=1,
        ).astype("Int64")
        selected["carriers"] = selected.apply(
            lambda row: row["target_n_carriers"]
            if row["test_category"] in {"target_burden", "target_main"}
            else row["anchor_n_carriers"]
            if row["test_category"] in {"anchor_burden", "anchor_main"}
            else row["combo_n_carriers"]
            if row["test_category"] == "interaction"
            else pd.NA,
            axis=1,
        ).astype("Int64")

    n_rows = len(selected)
    if figsize is None:
        row_height = 0.3
        figsize = (7, min(9, max(2.5, n_rows * row_height)))

    created_fig = False
    if ax is None:
        fig, ax = plt.subplots(figsize=figsize)
        created_fig = True
    else:
        fig = ax.figure

    pheno_labels = selected[pheno_col].astype(str).tolist()
    y_positions: list[float] = []
    curr_y = 0.0
    prev_pheno = None
    for pheno_name in pheno_labels:
        if prev_pheno is not None and pheno_name != prev_pheno:
            curr_y += 0.35
        y_positions.append(curr_y)
        curr_y += 1.0
        prev_pheno = pheno_name
    y = np.array(y_positions)
    valid_effects = selected[effect_col].notna() & selected["ci_low"].notna() & selected["ci_high"].notna()

    for idx, ypos in enumerate(y):
        if idx % 2 == 1:
            ax.axhspan(ypos - 0.5, ypos + 0.5, color=alternate_row_color, zorder=0)

    if valid_effects.any():
        valid = selected.loc[valid_effects].copy()
        valid_y = y[valid_effects.to_numpy()]
        xerr = np.vstack([
            valid[effect_col] - valid["ci_low"],
            valid["ci_high"] - valid[effect_col],
        ])
        ax.errorbar(
            valid[effect_col],
            valid_y,
            xerr=xerr,
            fmt="o",
            color=point_color,
            ecolor=error_color,
            elinewidth=1.6,
            capsize=3,
            markersize=6,
            zorder=3,
        )
        x_min = min(valid["ci_low"].min(), 0)
        x_max = max(valid["ci_high"].max(), 0)
    else:
        x_min, x_max = -1.0, 1.0

    ax.axvline(0, color=reference_line_color, linestyle="--", linewidth=1)
    ax.set_yticks(y)
    ax.set_yticklabels([""] * n_rows)
    ax.tick_params(axis="y", length=0)
    ax.set_xlabel(xlabel)
    ax.set_ylabel("")
    if title is None:
        if phenos and len(phenos) == 1:
            title = f"Interaction terms for {anchor_gene} x {target_gene} on {phenos[0]}"
        elif phenos:
            title = f"Interaction terms for {anchor_gene} x {target_gene}"
        else:
            title = f"Interaction terms for {anchor_gene} x {target_gene} across phenotypes"
    ax.set_title(title)
    ax.set_ylim(y[-1] + 0.5, -1.2)

    x_pad = max((x_max - x_min) * 0.12, 0.2)
    ax.set_xlim(x_min - x_pad, x_max + x_pad)

    row_transform = transforms.blended_transform_factory(ax.transAxes, ax.transData)
    header_y = -0.9

    if phenos and len(phenos) == 1:
        table_columns = [
            {"header": "Term", "xpos": -0.82, "col": "term", "blank_repeats": False},
        ]
        left_margin = 0.52
    else:
        table_columns = [
            {"header": "Phenotype", "xpos": -1.10, "col": pheno_col, "blank_repeats": True},
            {"header": "Term", "xpos": -0.76, "col": "term", "blank_repeats": False},
        ]
        left_margin = 0.66
    if show_carrier_counts:
        table_columns.extend(
            [
                {"header": "Carriers", "xpos": -0.24, "col": "carriers", "blank_repeats": False, "formatter": _format_count},
            ]
        )
    for column in table_columns:
        header = column["header"]
        xpos = column["xpos"]
        col = column["col"]
        ax.text(
            xpos,
            header_y,
            header,
            transform=row_transform,
            fontsize=9,
            fontweight="bold",
            ha="left",
            va="center",
            clip_on=False,
        )
        previous_value = None
        previous_pheno = None
        for idx, row in selected.iterrows():
            formatter = column.get("formatter", str)
            value = formatter(row[col])
            fontsize = 9
            current_pheno = str(row[pheno_col])
            if col == pheno_col and previous_value == value:
                value = ""
            elif col == pheno_col:
                value, fontsize = _format_pheno_label(row[col])
            elif column.get("blank_repeats") and previous_value == value and previous_pheno == current_pheno:
                value = ""
            ax.text(
                xpos,
                y[idx],
                value,
                transform=row_transform,
                fontsize=fontsize,
                ha="left",
                va="center",
                linespacing=0.95,
                clip_on=False,
            )
            previous_value = formatter(row[col])
            previous_pheno = current_pheno

    effect_x = 1.03
    pvalue_x = 1.38
    ax.text(
        effect_x,
        header_y,
        "Effect (95% CI)",
        transform=row_transform,
        fontsize=9,
        fontweight="bold",
        ha="left",
        va="center",
        clip_on=False,
    )
    ax.text(
        pvalue_x,
        header_y,
        "p-value",
        transform=row_transform,
        fontsize=9,
        fontweight="bold",
        ha="left",
        va="center",
        clip_on=False,
    )
    for idx, row in selected.iterrows():
        ax.text(
            effect_x,
            y[idx],
            row["effect_fmt"],
            transform=row_transform,
            fontsize=9,
            ha="left",
            va="center",
            clip_on=False,
        )
        ax.text(
            pvalue_x,
            y[idx],
            row["pvalue_fmt"],
            transform=row_transform,
            fontsize=9,
            ha="left",
            va="center",
            clip_on=False,
        )

    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_visible(False)
    ax.grid(axis="x", color="#dddddd", linewidth=0.8, alpha=0.8)

    if created_fig:
        fig.subplots_adjust(left=left_margin, right=0.68, top=0.90, bottom=0.12)
        fig.tight_layout()

    return fig, ax, selected.drop(columns=["_pheno_order", "_term_order", "_joint_df"])
