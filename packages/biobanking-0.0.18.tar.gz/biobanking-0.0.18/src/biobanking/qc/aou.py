import os
import hail as hl

from biobanking.utils.config import AllofUs


class WGSQualityControl(AllofUs):

    def __init__(self):
        super().__init__()
        self.wgs_mt_path = os.getenv("WGS_EXOME_SPLIT_HAIL_PATH")
        self.auxiliary_path = (
            "gs://fc-aou-datasets-controlled/v8/wgs/short_read/snpindel/aux"
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _apply_variant_qc(
        self,
        mt: hl.MatrixTable,
        min_call_rate: float = 0.9,
        min_hwe_p: float = 1e-15,
    ) -> hl.MatrixTable:
        mt = mt.filter_entries(mt.GQ > 20)
        mt = hl.variant_qc(mt)
        db = hl.experimental.DB(region="us-central1", cloud="gcp")
        mt = db.annotate_rows_db(mt, "Ensembl_homo_sapiens_low_complexity_regions")
        mt = mt.filter_rows(
            (mt.Ensembl_homo_sapiens_low_complexity_regions == False)
            & (mt.variant_qc.call_rate > min_call_rate)
            & (mt.variant_qc.p_value_hwe > min_hwe_p)
            & (mt.variant_qc.AC[1] > 0)
        )
        return mt

    def _apply_sample_qc(
        self,
        mt: hl.MatrixTable,
        remove_flagged: bool = True,
        remove_related: bool = True,
        remove_non_binary_sex: bool = False,
    ) -> hl.MatrixTable:
        if remove_flagged:
            flagged = hl.import_table(
                f"{self.auxiliary_path}/qc/flagged_samples.tsv"
            ).key_by("s")
            mt = mt.anti_join_cols(flagged)

        if remove_non_binary_sex:
            metrics = hl.import_table(
                f"{self.auxiliary_path}/qc/genomic_metrics.tsv"
            )
            non_binary = metrics.filter(
                (metrics.sex_at_birth != "Male") & (metrics.sex_at_birth != "Female")
            ).annotate(s=metrics.research_id).key_by("s")
            mt = mt.anti_join_cols(non_binary)

        if remove_related:
            relatedness = hl.import_table(
                f"{self.auxiliary_path}/relatedness/relatedness.tsv",
                types={"kin": hl.tfloat64},
            )
            related = relatedness.filter(relatedness.kin > 0.354).annotate(
                s=relatedness["i.s"]
            ).key_by("s")
            mt = mt.anti_join_cols(related)

        return mt

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run_qc_for_chrm(
        self,
        chrm: int | str,
        min_call_rate: float = 0.9,
        min_hwe_p: float = 1e-15,
        remove_flagged: bool = True,
        remove_related: bool = True,
        remove_non_binary_sex: bool = False,
        overwrite: bool = False,
    ) -> hl.MatrixTable:
        """Run variant and sample QC for one chromosome and write to GCS."""
        out_path = f"{self.bucket}/data/exome/qc/chr{chrm}_qc_passed.mt"
        if not overwrite and hl.hadoop_exists(out_path):
            return hl.read_matrix_table(out_path)

        mt = hl.read_matrix_table(self.wgs_mt_path)
        mt = mt.filter_rows(mt.locus.contig == f"chr{chrm}")
        mt = self._apply_variant_qc(mt, min_call_rate=min_call_rate, min_hwe_p=min_hwe_p)
        mt = self._apply_sample_qc(
            mt,
            remove_flagged=remove_flagged,
            remove_related=remove_related,
            remove_non_binary_sex=remove_non_binary_sex,
        )
        mt.write(out_path, overwrite=overwrite)
        return mt

    def run_qc_all_chrms(
        self,
        chrs: list[int | str] | None = None,
        min_call_rate: float = 0.9,
        min_hwe_p: float = 1e-15,
        remove_flagged: bool = True,
        remove_related: bool = True,
        remove_non_binary_sex: bool = False,
        overwrite: bool = False,
    ) -> None:
        """Run variant and sample QC for all chromosomes."""
        if chrs is None:
            chrs = list(range(1, 23)) + ["X"]
        for chrm in chrs:
            self.run_qc_for_chrm(
                chrm,
                min_call_rate=min_call_rate,
                min_hwe_p=min_hwe_p,
                remove_flagged=remove_flagged,
                remove_related=remove_related,
                remove_non_binary_sex=remove_non_binary_sex,
                overwrite=overwrite,
            )

    def export_plink_for_chrm(self, chrm: int | str, overwrite: bool = False) -> None:
        """Export QC-passed MT for one chromosome to PLINK BED format."""
        mt_path  = f"{self.bucket}/data/exome/qc/chr{chrm}_qc_passed.mt"
        out_path = f"{self.bucket}/data/exome/plink/chr{chrm}_qc_passed"
        if not overwrite and hl.hadoop_exists(f"{out_path}.bed"):
            return
        mt = hl.read_matrix_table(mt_path)
        hl.export_plink(mt, out_path, ind_id=mt.s, fam_id=mt.s)

    def export_plink_all_chrms(
        self,
        chrs: list[int | str] | None = None,
        overwrite: bool = False,
    ) -> None:
        """Export QC-passed MTs for all chromosomes to PLINK BED format."""
        if chrs is None:
            chrs = list(range(1, 23)) + ["X"]
        for chrm in chrs:
            self.export_plink_for_chrm(chrm, overwrite=overwrite)

    def export_bgen_for_chrm(self, chrm: int | str, overwrite: bool = False) -> None:
        """Export QC-passed MT for one chromosome to BGEN v1.2 format.

        Hard calls are converted to genotype probabilities so the output is
        compatible with REGENIE's --bgen input. Missing genotypes (those that
        failed GQ>20) receive uniform probabilities [1/3, 1/3, 1/3], which
        REGENIE treats as missing.
        """
        mt_path  = f"{self.bucket}/data/exome/qc/chr{chrm}_qc_passed.mt"
        out_path = f"{self.bucket}/data/exome/bgen/chr{chrm}_qc_passed"
        if not overwrite and hl.hadoop_exists(f"{out_path}.bgen"):
            return
        mt = hl.read_matrix_table(mt_path)
        gp = (
            hl.case()
            .when(hl.is_missing(mt.GT), [1 / 3, 1 / 3, 1 / 3])
            .when(mt.GT.is_hom_ref(),   [1.0,   0.0,   0.0  ])
            .when(mt.GT.is_het(),        [0.0,   1.0,   0.0  ])
            .when(mt.GT.is_hom_var(),   [0.0,   0.0,   1.0  ])
            .default(                    [1 / 3, 1 / 3, 1 / 3])
        )
        # varid matches the chr:pos:ref:alt format used in REGENIE annotation/set files
        varid = (
            hl.str(mt.locus.contig) + ":" +
            hl.str(mt.locus.position) + ":" +
            mt.alleles[0] + ":" +
            mt.alleles[1]
        )
        hl.export_bgen(mt, out_path, gp=gp, varid=varid)

    def export_bgen_all_chrms(
        self,
        chrs: list[int | str] | None = None,
        overwrite: bool = False,
    ) -> None:
        """Export QC-passed MTs for all chromosomes to BGEN v1.2 format."""
        if chrs is None:
            chrs = list(range(1, 23)) + ["X"]
        for chrm in chrs:
            self.export_bgen_for_chrm(chrm, overwrite=overwrite)
