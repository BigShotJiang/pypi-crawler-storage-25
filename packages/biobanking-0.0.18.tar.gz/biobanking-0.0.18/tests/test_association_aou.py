import json

import pandas as pd
import pytest

from biobanking.association.aou import REGENIE


def test_process_regenie_df_parses_generic_mask_ids():
    df = pd.DataFrame(
        {
            "ID": [
                "GENE1.pLoF_strict.0.01",
                "GENE2.missense.0.001",
                "GENE3.plof_deleterious_missense.singleton",
            ],
            "CHROM": [1, 2, 3],
            "LOG10P": [2.0, 3.0, 4.0],
            "BETA": [0.1, 0.2, 0.3],
            "SE": [0.01, 0.02, 0.03],
            "CHISQ": [1.0, 2.0, 3.0],
            "N": [100, 200, 300],
            "TEST": ["ADD", "SKATO", "ADD"],
        }
    )

    parsed = REGENIE._process_regenie_df_impl(df)

    assert parsed["gene"].tolist() == ["GENE1", "GENE2", "GENE3"]
    assert parsed["mask"].tolist() == ["pLoF_strict", "missense", "plof_deleterious_missense"]
    assert parsed["aaf_bin"].tolist() == ["0.01", "0.001", "singleton"]
    assert parsed["test"].tolist() == ["ADD", "SKATO", "ADD"]


def test_create_regenie_burden_files_helper_uses_default_plof_mask_definitions():
    regenie = REGENIE()
    mask_definitions = REGENIE.create_regenie_burden_files.__defaults__[1]
    original = {key: list(value) for key, value in mask_definitions.items()}
    burden_df = pd.DataFrame(
        {
            "locus": ["chr1:10", "chr1:20", "chr1:30"],
            "alleles": ["A_T", "G_C", "C_A"],
            "gene": ["GENE1", "GENE1", "GENE2"],
            "consequence": ["frameshift_variant", "start_lost", "missense_variant"],
            "maf": [0.001, 0.002, 0.003],
        }
    )

    annot_df, set_df, aaf_df, mask_df = regenie.create_regenie_burden_files_helper(
        burden_df,
        mask_definitions=mask_definitions,
    )

    assert mask_df.to_dict("records") == [
        {
            "mask_name": "pLoF_strict",
            "categories": "frameshift_variant,stop_gained,splice_acceptor_variant,splice_donor_variant",
        },
        {
            "mask_name": "pLoF_lenient",
            "categories": "frameshift_variant,stop_gained,splice_acceptor_variant,splice_donor_variant,start_lost,stop_lost",
        },
    ]
    assert annot_df["annotation"].tolist() == ["frameshift_variant", "start_lost"]
    assert set_df["gene"].tolist() == ["GENE1"]
    assert aaf_df["variants"].tolist() == ["chr1:10:A:T", "chr1:20:G:C", "chr1:30:C:A"]
    assert {key: list(value) for key, value in mask_definitions.items()} == original


def test_create_regenie_burden_files_helper_deduplicates_set_variants():
    regenie = REGENIE()
    burden_df = pd.DataFrame(
        {
            "locus": ["chr1:10", "chr1:10"],
            "alleles": ["A_T", "A_T"],
            "gene": ["GENE1", "GENE1"],
            "consequence": ["frameshift_variant", "stop_gained"],
            "maf": [0.001, 0.001],
        }
    )

    annot_df, set_df, _, _ = regenie.create_regenie_burden_files_helper(
        burden_df,
        mask_definitions={"plof": ["frameshift_variant", "stop_gained"]},
    )

    assert annot_df["annotation"].tolist() == ["frameshift_variant", "stop_gained"]
    assert set_df["variants"].tolist() == ["chr1:10:A:T"]


def test_create_regenie_burden_files_helper_supports_custom_missense_masks():
    regenie = REGENIE()
    mask_definitions = {"missense": ["missense_variant"]}
    burden_df = pd.DataFrame(
        {
            "locus": ["chr10:10", "chr10:20"],
            "alleles": ["A_T", "G_C"],
            "gene": ["GENE1", "GENE2"],
            "consequence": ["missense_variant", "synonymous_variant"],
            "maf": [0.001, 0.002],
        }
    )

    annot_df, set_df, _, mask_df = regenie.create_regenie_burden_files_helper(
        burden_df,
        mask_definitions=mask_definitions,
    )

    assert annot_df.to_dict("records") == [
        {"variants": "chr10:10:A:T", "gene": "GENE1", "annotation": "missense_variant"}
    ]
    assert set_df.to_dict("records") == [
        {"gene": "GENE1", "chrm": "chr10", "location": "10", "variants": "chr10:10:A:T"}
    ]
    assert mask_df.to_dict("records") == [
        {"mask_name": "missense", "categories": "missense_variant"}
    ]


def _write_minimal_pheno(bucket, phase_prefix="measurements_0"):
    pheno_dir = bucket / "data" / "associations" / "phenotypes"
    pheno_dir.mkdir(parents=True)
    pd.DataFrame({"FID": ["1"], "IID": ["1"], "trait": [1.0]}).to_csv(
        pheno_dir / f"{phase_prefix}.tsv.gz",
        sep="\t",
        index=False,
    )


def test_create_burden_input_dict_writes_burden_and_skato_json(tmp_path):
    _write_minimal_pheno(tmp_path)
    regenie = REGENIE()
    regenie.bucket = str(tmp_path)

    burden_json = tmp_path / "burden.json"
    skato_json = tmp_path / "skato.json"
    regenie.create_burden_input_dict(
        phase_prefix="measurements_0",
        burden_type="missense",
        chrs=[10],
        json_filename=str(burden_json),
    )
    regenie.create_burden_input_dict(
        phase_prefix="measurements_0",
        burden_type="missense",
        step2_category="skato",
        chrs=[10],
        json_filename=str(skato_json),
    )

    burden = json.loads(burden_json.read_text())
    skato = json.loads(skato_json.read_text())
    assert burden["regenie_workflow.vc_tests"] == ""
    assert burden["regenie_workflow.set_files"] == [f"{tmp_path}/data/associations/burden/chr10_sets_missense.tsv.gz"]
    assert skato["regenie_workflow.vc_tests"] == "skato"
    assert skato["regenie_workflow.set_files"] == [f"{tmp_path}/data/associations/burden/chr10_sets_missense.tsv.gz"]


def test_create_burden_input_dict_rejects_non_burden_categories():
    regenie = REGENIE()

    with pytest.raises(ValueError, match="burden.*skato"):
        regenie.create_burden_input_dict(
            phase_prefix="measurements_0",
            step2_category="interaction",
        )


def test_create_interaction_input_dict_uses_burden_type_as_step2_mode(tmp_path):
    _write_minimal_pheno(tmp_path)
    regenie = REGENIE()
    regenie.bucket = str(tmp_path)
    out_json = tmp_path / "interaction.json"

    regenie.create_interaction_input_dict(
        phase_prefix="measurements_0",
        anchor_gene="INHBE",
        anchor_chrm=12,
        chrs=[1],
        target_gene="LDLR",
        run_step1=False,
        ignore_pred=True,
        step1_workflow_id="step1-id",
        burden_type="plof",
        run_label="INHBE_vs_LDLR",
        json_filename=str(out_json),
    )

    payload = json.loads(out_json.read_text())
    assert payload["regenie_workflow.vc_tests"] == ""
    assert payload["regenie_workflow.interaction_bed"] == f"{tmp_path}/data/associations/masks/plof/chr12/chr12_masks.bed"
    assert payload["regenie_workflow.target_bed_files"] == [f"{tmp_path}/data/associations/masks/plof/chr1/chr1_masks.bed"]
