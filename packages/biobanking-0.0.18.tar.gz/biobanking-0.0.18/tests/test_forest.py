import matplotlib
import pandas as pd
import pytest

matplotlib.use("Agg")

from biobanking.plotting.forest import (
    _expected_interaction_run_label,
    _is_expected_interaction_test,
    _lookup_combo_carrier_total,
    _lookup_gene_carrier_total,
    _prepare_combo_carrier_counts,
    _prepare_gene_carrier_counts,
    plot_interaction_forest,
)


def test_prepare_gene_carrier_counts_sums_hetz_and_homz():
    carrier_df = pd.DataFrame(
        {
            "gene": ["ANCHOR1", "ANCHOR1", "TARGET1"],
            "mask_type": ["pLoF_strict", "pLoF_strict", "pLoF_lenient"],
            "aaf_bin": [0.01, 0.01, 0.001],
            "zygosity": ["hetz", "homz", "hetz"],
            "n_carriers": [11, 2, 7],
        }
    )

    prepared = _prepare_gene_carrier_counts(carrier_df)

    assert _lookup_gene_carrier_total(prepared, "anchor1", "pLoF_strict", "0.01") == 13
    assert _lookup_gene_carrier_total(prepared, "TARGET1", "pLoF_lenient", 0.001) == 7


def test_prepare_combo_carrier_counts_uses_anchor_orientation_and_missing_returns_na():
    combo_df = pd.DataFrame(
        {
            "gene1": ["ANCHOR1"],
            "mask_type_1": ["pLoF_strict"],
            "aaf_bin_1": [0.01],
            "gene2": ["TARGET1"],
            "mask_type_2": ["pLoF_lenient"],
            "aaf_bin_2": [0.001],
            "total_co": [4],
        }
    )

    prepared = _prepare_combo_carrier_counts(combo_df)

    assert _lookup_combo_carrier_total(
        prepared,
        anchor_gene="anchor1",
        anchor_mask="pLoF_strict",
        anchor_aaf_bin="0.01",
        target_gene="target1",
        target_mask="pLoF_lenient",
        target_aaf_bin="0.001",
    ) == 4
    assert pd.isna(
        _lookup_combo_carrier_total(
            prepared,
            anchor_gene="target1",
            anchor_mask="pLoF_lenient",
            anchor_aaf_bin="0.001",
            target_gene="anchor1",
            target_mask="pLoF_strict",
            target_aaf_bin="0.01",
        )
    )


def test_expected_interaction_helpers_match_only_anchor_specific_tests():
    assert _expected_interaction_run_label("INHBE", "ANGPTL3") == "INHBE_vs_ANGPTL3"
    assert _is_expected_interaction_test("ADD", "INHBE", "pLoF_strict", "0.01")
    assert _is_expected_interaction_test("ADD-INT_SNP", "INHBE", "pLoF_strict", "0.01")
    assert _is_expected_interaction_test("ADD-INT_2DF", "INHBE", "pLoF_strict", "0.01")
    assert _is_expected_interaction_test("ADD-INT_INHBE.pLoF_strict.0.01", "INHBE", "pLoF_strict", "0.01")
    assert _is_expected_interaction_test("ADD-INT_SNPxINHBE.pLoF_strict.0.01", "INHBE", "pLoF_strict", "0.01")
    assert not _is_expected_interaction_test("ADD-INT_PCSK9.pLoF_strict.0.01", "INHBE", "pLoF_strict", "0.01")
    assert not _is_expected_interaction_test("ADD-INT_SNPxPCSK9.pLoF_strict.0.01", "INHBE", "pLoF_strict", "0.01")


def test_plot_interaction_forest_adds_carrier_count_columns_single_pheno():
    results = pd.DataFrame(
        {
            "gene": ["TARGET1", "TARGET1", "TARGET1"],
            "pheno": ["PHENO1", "PHENO1", "PHENO1"],
            "test": ["ADD-INT_SNP", "ADD-INT_SNPx1", "ADD-INT_2DF"],
            "pvalue": [0.02, 0.01, 0.03],
            "BETA": [0.2, 0.5, 0.4],
            "SE": [0.1, 0.2, 0.15],
            "mask": ["pLoF_lenient", "pLoF_lenient", "pLoF_lenient"],
            "aaf_bin": ["0.001", "0.001", "0.001"],
        }
    )
    gene_counts = pd.DataFrame(
        {
            "gene": ["ANCHOR1", "ANCHOR1", "TARGET1", "TARGET1"],
            "mask_type": ["pLoF_strict", "pLoF_strict", "pLoF_lenient", "pLoF_lenient"],
            "aaf_bin": [0.01, 0.01, 0.001, 0.001],
            "zygosity": ["hetz", "homz", "hetz", "homz"],
            "n_carriers": [10, 2, 6, 1],
        }
    )
    combo_counts = pd.DataFrame(
        {
            "gene1": ["ANCHOR1"],
            "mask_type_1": ["pLoF_strict"],
            "aaf_bin_1": [0.01],
            "gene2": ["TARGET1"],
            "mask_type_2": ["pLoF_lenient"],
            "aaf_bin_2": [0.001],
            "total_co": [3],
        }
    )

    fig, ax, selected = plot_interaction_forest(
        results,
        anchor_gene="ANCHOR1",
        target_gene="TARGET1",
        pheno="PHENO1",
        gene_carrier_counts=gene_counts,
        combo_carrier_counts=combo_counts,
    )

    assert fig is not None
    assert ax is not None
    assert selected["anchor_n_carriers"].tolist() == [12, 12, 12]
    assert selected["target_n_carriers"].tolist() == [7, 7, 7]
    assert selected["combo_n_carriers"].tolist() == [3, 3, 3]
    assert selected["carriers"].iloc[0] == 7
    assert selected["carriers"].iloc[1] == 3
    assert pd.isna(selected["carriers"].iloc[2])


def test_plot_interaction_forest_supports_non_default_anchor_mask_and_multi_pheno():
    results = pd.DataFrame(
        {
            "gene": ["TARGET1", "TARGET1", "TARGET1", "TARGET1"],
            "pheno": ["PHENO1", "PHENO1", "PHENO2", "PHENO2"],
            "test": ["ADD-INT_SNP", "ADD-INT_SNPx1", "ADD-INT_SNP", "ADD-INT_SNPx1"],
            "pvalue": [0.03, 0.01, 0.02, 0.005],
            "BETA": [0.2, 0.5, 0.1, 0.6],
            "SE": [0.1, 0.2, 0.1, 0.25],
            "mask": ["pLoF_lenient", "pLoF_lenient", "pLoF_strict", "pLoF_strict"],
            "aaf_bin": ["0.001", "0.001", "0.01", "0.01"],
        }
    )
    gene_counts = pd.DataFrame(
        {
            "gene": ["ANCHOR1", "ANCHOR1", "TARGET1", "TARGET1", "TARGET1", "TARGET1"],
            "mask_type": ["pLoF_lenient", "pLoF_lenient", "pLoF_lenient", "pLoF_lenient", "pLoF_strict", "pLoF_strict"],
            "aaf_bin": [0.001, 0.001, 0.001, 0.001, 0.01, 0.01],
            "zygosity": ["hetz", "homz", "hetz", "homz", "hetz", "homz"],
            "n_carriers": [5, 1, 6, 1, 8, 2],
        }
    )
    combo_counts = pd.DataFrame(
        {
            "gene1": ["ANCHOR1", "ANCHOR1"],
            "mask_type_1": ["pLoF_lenient", "pLoF_lenient"],
            "aaf_bin_1": [0.001, 0.001],
            "gene2": ["TARGET1", "TARGET1"],
            "mask_type_2": ["pLoF_lenient", "pLoF_strict"],
            "aaf_bin_2": [0.001, 0.01],
            "total_co": [2, 4],
        }
    )

    _, _, selected = plot_interaction_forest(
        results,
        anchor_gene="ANCHOR1",
        target_gene="TARGET1",
        pheno=["PHENO1", "PHENO2"],
        anchor_mask="pLoF_lenient",
        anchor_aaf_bin="0.001",
        gene_carrier_counts=gene_counts,
        combo_carrier_counts=combo_counts,
    )

    pheno1 = selected.loc[selected["pheno"] == "PHENO1"]
    pheno2 = selected.loc[selected["pheno"] == "PHENO2"]
    assert pheno1["anchor_n_carriers"].tolist() == [6, 6]
    assert pheno1["target_n_carriers"].tolist() == [7, 7]
    assert pheno1["combo_n_carriers"].tolist() == [2, 2]
    assert pheno1["carriers"].tolist() == [7, 2]
    assert pheno2["target_n_carriers"].tolist() == [10, 10]
    assert pheno2["combo_n_carriers"].tolist() == [4, 4]
    assert pheno2["carriers"].tolist() == [10, 4]


def test_plot_interaction_forest_requires_target_mask_and_aaf_for_carrier_counts():
    results = pd.DataFrame(
        {
            "gene": ["TARGET1"],
            "pheno": ["PHENO1"],
            "run_label": ["ANCHOR1_vs_TARGET1"],
            "test": ["ADD-INT_SNPxANCHOR1.pLoF_strict.0.01"],
            "pvalue": [0.01],
            "BETA": [0.5],
            "SE": [0.2],
        }
    )

    with pytest.raises(ValueError, match="Carrier counts require 'mask' and 'aaf_bin' columns"):
        plot_interaction_forest(
            results,
            anchor_gene="ANCHOR1",
            target_gene="TARGET1",
            pheno="PHENO1",
            gene_carrier_counts=pd.DataFrame(
                {
                    "gene": ["ANCHOR1"],
                    "mask_type": ["pLoF_strict"],
                    "aaf_bin": [0.01],
                    "zygosity": ["hetz"],
                    "n_carriers": [1],
                }
            ),
            combo_carrier_counts=pd.DataFrame(
                {
                    "gene1": ["ANCHOR1"],
                    "mask_type_1": ["pLoF_strict"],
                    "aaf_bin_1": [0.01],
                    "gene2": ["TARGET1"],
                    "mask_type_2": ["pLoF_lenient"],
                    "aaf_bin_2": [0.001],
                    "total_co": [1],
                }
            ),
        )


def test_plot_interaction_forest_skips_carrier_annotations_when_inputs_not_provided():
    results = pd.DataFrame(
        {
            "gene": ["TARGET1"],
            "pheno": ["PHENO1"],
            "run_label": ["ANCHOR1_vs_TARGET1"],
            "test": ["ADD-INT_SNPxANCHOR1.pLoF_strict.0.01"],
            "pvalue": [0.01],
            "BETA": [0.5],
            "SE": [0.2],
        }
    )

    _, _, selected = plot_interaction_forest(
        results,
        anchor_gene="ANCHOR1",
        target_gene="TARGET1",
        pheno="PHENO1",
    )

    assert "anchor_n_carriers" not in selected.columns
    assert "target_n_carriers" not in selected.columns
    assert "combo_n_carriers" not in selected.columns
    assert "carriers" not in selected.columns


def test_plot_interaction_forest_requires_both_carrier_inputs():
    results = pd.DataFrame(
        {
            "gene": ["TARGET1"],
            "pheno": ["PHENO1"],
            "run_label": ["ANCHOR1_vs_TARGET1"],
            "test": ["ADD-INT_SNPxANCHOR1.pLoF_strict.0.01"],
            "pvalue": [0.01],
            "BETA": [0.5],
            "SE": [0.2],
            "mask": ["pLoF_lenient"],
            "aaf_bin": ["0.001"],
        }
    )

    with pytest.raises(ValueError, match="Carrier counts require both 'gene_carrier_counts' and 'combo_carrier_counts'"):
        plot_interaction_forest(
            results,
            anchor_gene="ANCHOR1",
            target_gene="TARGET1",
            pheno="PHENO1",
            gene_carrier_counts=pd.DataFrame(
                {
                    "gene": ["ANCHOR1"],
                    "mask_type": ["pLoF_strict"],
                    "aaf_bin": [0.01],
                    "zygosity": ["hetz"],
                    "n_carriers": [1],
                }
            ),
        )


def test_plot_interaction_forest_filters_to_expected_run_label_by_default():
    results = pd.DataFrame(
        {
            "gene": ["ANGPTL3"] * 6,
            "pheno": ["PHENO1"] * 6,
            "run_label": [
                "PCSK9_vs_ANGPTL3",
                "PCSK9_vs_ANGPTL3",
                "PCSK9_vs_ANGPTL3",
                "INHBE_vs_ANGPTL3",
                "INHBE_vs_ANGPTL3",
                "INHBE_vs_ANGPTL3",
            ],
            "test": [
                "ADD-INT_SNP",
                "ADD-INT_SNPxPCSK9.pLoF_strict.0.01",
                "ADD-INT_2DF",
                "ADD-INT_SNP",
                "ADD-INT_SNPxINHBE.pLoF_strict.0.01",
                "ADD-INT_2DF",
            ],
            "pvalue": [0.02, 0.01, 0.03, 0.04, 0.005, 0.02],
            "BETA": [0.2, 0.5, 0.4, 0.3, 0.7, 0.1],
            "SE": [0.1, 0.2, 0.15, 0.12, 0.2, 0.11],
            "mask": ["pLoF_strict"] * 6,
            "aaf_bin": ["0.01"] * 6,
        }
    )

    _, _, selected = plot_interaction_forest(
        results,
        anchor_gene="INHBE",
        target_gene="ANGPTL3",
        pheno="PHENO1",
    )

    assert set(selected["run_label"]) == {"INHBE_vs_ANGPTL3"}
    assert set(selected["test"]) == {"ADD-INT_SNP", "ADD-INT_SNPxINHBE.pLoF_strict.0.01", "ADD-INT_2DF"}


def test_plot_interaction_forest_can_require_complete_term_sets():
    results = pd.DataFrame(
        {
            "gene": ["TARGET1"] * 7,
            "pheno": ["PHENO1", "PHENO1", "PHENO1", "PHENO1", "PHENO2", "PHENO2", "PHENO2"],
            "run_label": ["ANCHOR1_vs_TARGET1"] * 7,
            "test": [
                "ADD-INT_SNP",
                "ADD-INT_ANCHOR1.pLoF_strict.0.01",
                "ADD-INT_SNPxANCHOR1.pLoF_strict.0.01",
                "ADD-INT_2DF",
                "ADD-INT_SNP",
                "ADD-INT_SNPxANCHOR1.pLoF_strict.0.01",
                "ADD-INT_2DF",
            ],
            "pvalue": [0.03, 0.04, 0.01, 0.02, 0.01, 0.005, 0.02],
            "BETA": [0.2, 0.1, 0.5, 0.4, 0.3, 0.7, 0.1],
            "SE": [0.1, 0.12, 0.2, 0.15, 0.12, 0.2, 0.11],
            "mask": ["pLoF_strict"] * 7,
            "aaf_bin": ["0.01"] * 7,
        }
    )

    _, _, selected_default = plot_interaction_forest(
        results,
        anchor_gene="ANCHOR1",
        target_gene="TARGET1",
        pheno=["PHENO1", "PHENO2"],
    )
    assert set(selected_default["pheno"]) == {"PHENO1", "PHENO2"}

    _, _, selected_strict = plot_interaction_forest(
        results,
        anchor_gene="ANCHOR1",
        target_gene="TARGET1",
        pheno=["PHENO1", "PHENO2"],
        require_complete_terms=True,
    )
    assert set(selected_strict["pheno"]) == {"PHENO1"}


def test_plot_interaction_forest_can_prepend_anchor_and_target_burden_rows():
    results = pd.DataFrame(
        {
            "gene": ["TARGET1"] * 4,
            "pheno": ["PHENO1"] * 4,
            "run_label": ["ANCHOR1_vs_TARGET1"] * 4,
            "test": [
                "ADD-INT_SNP",
                "ADD-INT_ANCHOR1.pLoF_strict.0.01",
                "ADD-INT_SNPxANCHOR1.pLoF_strict.0.01",
                "ADD-INT_2DF",
            ],
            "pvalue": [0.02, 0.03, 0.01, 0.04],
            "BETA": [0.2, 0.1, 0.5, 0.4],
            "SE": [0.1, 0.12, 0.2, 0.15],
            "mask": ["pLoF_lenient"] * 4,
            "aaf_bin": ["0.001"] * 4,
        }
    )
    burden = pd.DataFrame(
        {
            "gene": ["ANCHOR1", "TARGET1"],
            "pheno": ["PHENO1", "PHENO1"],
            "pvalue": [0.20, 0.03],
            "beta": [0.10, 0.40],
            "se": [0.05, 0.10],
            "mask": ["pLoF_strict", "pLoF_lenient"],
            "aaf_bin": [0.01, 0.001],
            "n": [100, 100],
        }
    )
    gene_counts = pd.DataFrame(
        {
            "gene": ["ANCHOR1", "ANCHOR1", "TARGET1", "TARGET1"],
            "mask_type": ["pLoF_strict", "pLoF_strict", "pLoF_lenient", "pLoF_lenient"],
            "aaf_bin": [0.01, 0.01, 0.001, 0.001],
            "zygosity": ["hetz", "homz", "hetz", "homz"],
            "n_carriers": [10, 2, 6, 1],
        }
    )
    combo_counts = pd.DataFrame(
        {
            "gene1": ["ANCHOR1"],
            "mask_type_1": ["pLoF_strict"],
            "aaf_bin_1": [0.01],
            "gene2": ["TARGET1"],
            "mask_type_2": ["pLoF_lenient"],
            "aaf_bin_2": [0.001],
            "total_co": [3],
        }
    )

    fig, _, selected = plot_interaction_forest(
        results,
        anchor_gene="ANCHOR1",
        target_gene="TARGET1",
        pheno="PHENO1",
        burden_data=burden,
        gene_carrier_counts=gene_counts,
        combo_carrier_counts=combo_counts,
    )

    assert selected["term"].tolist() == [
        "Burden :: TARGET1",
        "Burden :: ANCHOR1",
        "Main effect :: TARGET1",
        "Main effect :: ANCHOR1",
        "Interaction Effect",
        "Joint Effect",
    ]
    assert selected["test_category"].tolist() == [
        "target_burden",
        "anchor_burden",
        "target_main",
        "anchor_main",
        "interaction",
        "joint",
    ]
    assert selected["carriers"].astype("Int64").tolist()[:5] == [7, 12, 7, 12, 3]
    assert pd.isna(selected["carriers"].iloc[5])
    assert fig.get_size_inches()[1] >= 2.5


def test_plot_interaction_forest_top_n_ranks_phenotypes_by_joint_effect_by_default():
    results = pd.DataFrame(
        {
            "gene": ["TARGET1"] * 12,
            "pheno": ["PHENO1"] * 4 + ["PHENO2"] * 4 + ["PHENO3"] * 4,
            "run_label": ["ANCHOR1_vs_TARGET1"] * 12,
            "test": [
                "ADD-INT_SNP",
                "ADD-INT_ANCHOR1.pLoF_strict.0.01",
                "ADD-INT_SNPxANCHOR1.pLoF_strict.0.01",
                "ADD-INT_2DF",
            ]
            * 3,
            "pvalue": [
                0.03,
                0.04,
                0.02,
                0.005,
                0.04,
                0.05,
                0.01,
                0.02,
                0.02,
                0.03,
                0.03,
                0.01,
            ],
            "BETA": [0.2] * 12,
            "SE": [0.1] * 12,
            "mask": ["pLoF_strict"] * 12,
            "aaf_bin": ["0.01"] * 12,
        }
    )

    _, _, selected = plot_interaction_forest(
        results,
        anchor_gene="ANCHOR1",
        target_gene="TARGET1",
        top_n=2,
        pvalue_threshold=0.05,
    )

    assert selected["pheno"].drop_duplicates().tolist() == ["PHENO1", "PHENO3"]
    assert selected.groupby("pheno").size().to_dict() == {"PHENO1": 4, "PHENO3": 4}


def test_plot_interaction_forest_top_n_can_rank_by_interaction_effect():
    results = pd.DataFrame(
        {
            "gene": ["TARGET1"] * 12,
            "pheno": ["PHENO1"] * 4 + ["PHENO2"] * 4 + ["PHENO3"] * 4,
            "run_label": ["ANCHOR1_vs_TARGET1"] * 12,
            "test": [
                "ADD-INT_SNP",
                "ADD-INT_ANCHOR1.pLoF_strict.0.01",
                "ADD-INT_SNPxANCHOR1.pLoF_strict.0.01",
                "ADD-INT_2DF",
            ]
            * 3,
            "pvalue": [
                0.03,
                0.04,
                0.02,
                0.005,
                0.04,
                0.05,
                0.01,
                0.02,
                0.02,
                0.03,
                0.03,
                0.01,
            ],
            "BETA": [0.2] * 12,
            "SE": [0.1] * 12,
            "mask": ["pLoF_strict"] * 12,
            "aaf_bin": ["0.01"] * 12,
        }
    )

    _, _, selected = plot_interaction_forest(
        results,
        anchor_gene="ANCHOR1",
        target_gene="TARGET1",
        top_n=2,
        pvalue_threshold=0.05,
        pheno_rank_by="interaction",
    )

    assert selected["pheno"].drop_duplicates().tolist() == ["PHENO2", "PHENO1"]
    assert selected.groupby("pheno").size().to_dict() == {"PHENO1": 4, "PHENO2": 4}


def test_plot_interaction_forest_raises_when_run_label_column_missing():
    results = pd.DataFrame(
        {
            "gene": ["TARGET1"],
            "pheno": ["PHENO1"],
            "test": ["ADD-INT_SNPxANCHOR1.pLoF_strict.0.01"],
            "pvalue": [0.01],
            "BETA": [0.5],
            "SE": [0.2],
            "mask": ["pLoF_lenient"],
            "aaf_bin": ["0.001"],
        }
    )

    with pytest.raises(ValueError, match="Column 'run_label' is required for interaction plots"):
        plot_interaction_forest(
            results,
            anchor_gene="ANCHOR1",
            target_gene="TARGET1",
            pheno="PHENO1",
        )
