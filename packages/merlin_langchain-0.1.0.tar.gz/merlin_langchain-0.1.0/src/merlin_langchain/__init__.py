"""merlin-langchain: dedup adapter for LangChain.

    pip install merlin-langchain

Drop-in `MerlinBufferMemory` (subclass of `langchain_classic.base_memory.BaseMemory`)
that dedupes the rendered prompt-string before it reaches the LLM, plus a
`merlin_format_log_to_str` replacement for the ReAct scratchpad formatter.

When the Merlin binary is unavailable or its daily cap is exhausted, both
helpers transparently fall back to the user's default LangChain behavior
with auto-retry every hour (configurable via MERLIN_RETRY_AFTER_S env-var).
"""
from ._dedup_helper import dedup_text
from .scratchpad import merlin_format_log_to_str

try:
    from .memory import MerlinBufferMemory
    __all__ = ["dedup_text", "merlin_format_log_to_str", "MerlinBufferMemory"]
except ImportError:
    # langchain_classic / langchain_core not installed -
    # scratchpad helper still works.
    __all__ = ["dedup_text", "merlin_format_log_to_str"]

__version__ = "0.1.0"
