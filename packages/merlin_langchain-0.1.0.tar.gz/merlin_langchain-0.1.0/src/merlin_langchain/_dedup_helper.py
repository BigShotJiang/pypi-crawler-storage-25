"""Synchronous wrapper around the Merlin community binary.

Design choices (see langchain_fix2.md sec 1.1 for the discussion):

* Input goes via **stdin** (no input tempfile, saves one disk-write).
* Output uses `--output-dedup=PATH` to a tempfile: stdout is reserved for
  the binary's stats-JSON and stderr for the banner, so dedup-lines cannot
  share stdout.
* Tail extraction uses `rsplit("\\n", N)` so a 50 MB input doesn't
  explode into a list of every line just to keep the last 2.
* Binary path is platform-aware: `.exe` suffix only on Windows.
* `extra_env` lets the caller redirect the binary's state.bin location
  by overriding USERPROFILE (Windows) / HOME (Unix). Used by isolated
  demos and tests that should not pollute the user's daily 200 MB cap.
* Fail-safe = **elegant revert to the user's default LangChain behavior**.
  Any failure (binary missing, cap exhausted, exception) returns the
  original text unchanged. No Python-side fallback dedup. Merlin is a
  performance optimizer; when the optimizer cannot run, the system
  reverts to the baseline the user already accepted on day-1 (vanilla
  LangChain). `stats['error']` is populated so the caller can log it.
  This function NEVER raises.

The wrapper is **synchronous and not thread-safe-for-throughput** in the
sense that 50 concurrent calls = 50 concurrent subprocesses, which most
OSes will not love. For high-concurrency servers (LangServe / FastAPI),
run one agent worker per process.

Known limitation: SIGKILL/OOM kills bypass the `finally` cleanup and may
leave `*.dedup` tempfiles behind. Sweep on a schedule if you run 24/7.
"""
from __future__ import annotations

import os
import platform
import subprocess
import tempfile
import time
from pathlib import Path
from typing import Tuple


def _binary_path() -> str:
    """Resolve the Merlin binary path.

    Order: $MERLIN_BINARY env-var, else ~/.merlin/merlin[.exe]. On non-Windows
    the .exe suffix is dropped automatically.
    """
    explicit = os.environ.get("MERLIN_BINARY")
    if explicit:
        return explicit
    ext = ".exe" if platform.system() == "Windows" else ""
    return str(Path.home() / ".merlin" / f"merlin{ext}")


def dedup_text(text: str, keep_tail_lines: int = 2,
               extra_env: dict | None = None) -> Tuple[str, dict]:
    """Dedupe `text` via the Merlin binary.

    Args:
        text: input string (UTF-8).
        keep_tail_lines: number of trailing lines that are NEVER deduped.
            These are sliced off before dedup and re-appended after, so the
            most-recent context is byte-exact preserved.
        extra_env: optional dict merged INTO the subprocess env. Use this
            to redirect the binary's state.bin location by overriding
            USERPROFILE (Windows) / HOME (Unix) - useful for isolated
            demos and tests that should not pollute the user's daily cap.

    Returns:
        (deduped_text, stats) where stats has keys:
            input_bytes, output_bytes, dedup_ratio, duration_us, error

    On any failure: returns (original_text, stats_with_error). The caller's
    LangChain pipeline behaves identically to a Merlin-free install.
    """
    input_bytes = len(text.encode("utf-8"))
    stats = {
        "input_bytes": input_bytes,
        "output_bytes": input_bytes,
        "dedup_ratio": 0.0,
        "duration_us": 0,
        "error": None,
    }
    if not text:
        return text, stats

    binary = _binary_path()
    if not os.path.exists(binary):
        stats["error"] = f"binary not found at {binary}"
        return text, stats

    # rsplit with a max-splits cap: only carves off the last `keep_tail_lines`
    # boundaries from the back. Does NOT allocate a list of every line.
    parts = text.rsplit("\n", keep_tail_lines)
    if len(parts) <= keep_tail_lines:
        return text, stats
    body = parts[0]
    tail = "\n".join(parts[1:])

    env = None
    if extra_env:
        env = os.environ.copy()
        env.update(extra_env)

    out_path = None
    try:
        out_fd, out_path = tempfile.mkstemp(suffix=".dedup")
        os.close(out_fd)

        t0 = time.perf_counter_ns()
        r = subprocess.run(
            [binary, f"--output-dedup={out_path}"],
            input=body.encode("utf-8"),
            capture_output=True,
            timeout=30,
            env=env,
        )
        t1 = time.perf_counter_ns()
        stats["duration_us"] = (t1 - t0) // 1000

        if r.returncode != 0:
            stats["error"] = f"binary exit {r.returncode}: {r.stderr[:200]!r}"
            return text, stats

        if not os.path.exists(out_path) or os.path.getsize(out_path) == 0:
            stats["error"] = "no dedup output (cap exceeded / skipped)"
            return text, stats

        with open(out_path, "rb") as f:
            deduped_body = f.read().decode("utf-8", errors="replace")

        if deduped_body and not deduped_body.endswith("\n"):
            deduped_body += "\n"
        result = deduped_body + tail

        output_bytes = len(result.encode("utf-8"))
        stats["output_bytes"] = output_bytes
        stats["dedup_ratio"] = 1.0 - (output_bytes / max(input_bytes, 1))
        return result, stats
    except Exception as e:
        stats["error"] = f"exception: {type(e).__name__}: {e}"
        return text, stats
    finally:
        if out_path:
            try:
                os.unlink(out_path)
            except OSError:
                pass
