"""Drop-in replacement for `langchain.agents.format_scratchpad.format_log_to_str`."""
from __future__ import annotations

from typing import Any, List, Tuple

from ._dedup_helper import dedup_text


def merlin_format_log_to_str(
    intermediate_steps: List[Tuple[Any, str]],
    observation_prefix: str = "Observation: ",
    llm_prefix: str = "Thought: ",
    keep_tail_lines: int = 4,
) -> str:
    """Format intermediate steps as a ReAct scratchpad, deduped via Merlin.

    Identical interface to LangChain's `format_log_to_str`, except the result
    has byte-exact duplicate lines stripped (the last `keep_tail_lines` lines
    are always preserved untouched - typically the last action+observation).
    """
    thoughts = ""
    for action, observation in intermediate_steps:
        thoughts += action.log
        thoughts += f"\n{observation_prefix}{observation}\n{llm_prefix}"
    deduped, _stats = dedup_text(thoughts, keep_tail_lines=keep_tail_lines)
    return deduped
