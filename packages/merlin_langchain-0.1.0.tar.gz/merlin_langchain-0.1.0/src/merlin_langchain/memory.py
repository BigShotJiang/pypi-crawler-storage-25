"""Drop-in BufferMemory voor LangChain dat de gerenderde string via Merlin dedupes.

Inherits van `langchain_classic.base_memory.BaseMemory` zodat LangChain's
Pydantic-validatie van Chain.memory passes. Back-off + auto-recovery voor
long-running servers (LangServe / FastAPI). Async surface met exacte
base-class signatures voor mypy strict-mode.
"""
from __future__ import annotations

import asyncio
import logging
import os
import time
from typing import Any

from langchain_classic.base_memory import BaseMemory
from langchain_core.chat_history import InMemoryChatMessageHistory
from langchain_core.messages import get_buffer_string
from pydantic import ConfigDict, Field, PrivateAttr

from ._dedup_helper import dedup_text

_logger = logging.getLogger("merlin.langchain")

# How long (seconds) to skip the binary subprocess after a failure before
# probing again. Override via env. Minimum 60s to prevent subprocess spam
# during a real binary outage. Default 1h = catches midnight UTC cap
# rollover within an hour without restart.
_RETRY_AFTER_S = max(60, int(os.environ.get("MERLIN_RETRY_AFTER_S", "3600")))


class MerlinBufferMemory(BaseMemory):
    """Drop-in LangChain memory that dedupes the rendered prompt-string
    via the Merlin community binary. Inherits from `BaseMemory`, so it
    passes Pydantic validation in `Chain.memory` slots.

    Behavior when Merlin's binary is unavailable or cap-exhausted:
    - Returns the un-deduped string (= vanilla LangChain behavior).
    - Logs a single WARNING when fallback first kicks in.
    - Suppresses subsequent dedup attempts for `MERLIN_RETRY_AFTER_S`
      seconds; auto-retries once that elapses.
    - When the binary recovers, logs INFO "Merlin recovered" and resumes
      optimization. Self-heals across midnight UTC cap rollover without
      requiring a process restart.

    Async surface (aload/asave/aclear) delegates to the synchronous
    variants via `asyncio.to_thread`, keeping the event loop responsive.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    # ---- Public Pydantic fields ----
    memory_key: str = "history"
    human_prefix: str = "Human"
    ai_prefix: str = "AI"
    keep_tail_lines: int = 2
    input_key: str | None = None
    output_key: str | None = None
    return_messages: bool = False  # parity with ConversationBufferMemory

    chat_memory: InMemoryChatMessageHistory = Field(
        default_factory=InMemoryChatMessageHistory,
        exclude=True,
    )

    # ---- Private state (NOT Pydantic fields, NOT serialized) ----
    _last_stats: dict[str, Any] = PrivateAttr(default_factory=dict)
    _merlin_next_retry: float = PrivateAttr(default=0.0)
    _was_in_fallback: bool = PrivateAttr(default=False)
    _extra_env: dict[str, str] | None = PrivateAttr(default=None)

    def __init__(self, **data: Any) -> None:
        # Allow extra_env as constructor kwarg without being a Pydantic field.
        extra_env = data.pop("extra_env", None)
        super().__init__(**data)
        if extra_env is not None:
            self._extra_env = dict(extra_env)

    # ---- Required BaseMemory abstract surface ----

    @property
    def memory_variables(self) -> list[str]:
        return [self.memory_key]

    @property
    def merlin_active(self) -> bool:
        """True iff the most recent dedup call succeeded (no error)."""
        return bool(self._last_stats) and self._last_stats.get("error") is None

    def _buffer_as_string(self) -> str:
        return get_buffer_string(
            self.chat_memory.messages,
            human_prefix=self.human_prefix,
            ai_prefix=self.ai_prefix,
        )

    def _maybe_dedup(self, raw: str) -> str:
        """Attempt dedup, honoring the retry-after cooldown."""
        now = time.monotonic()
        if now < self._merlin_next_retry:
            return raw  # in cooldown; skip subprocess entirely

        deduped, stats = dedup_text(
            raw,
            keep_tail_lines=self.keep_tail_lines,
            extra_env=self._extra_env,
        )
        self._last_stats = stats

        if stats.get("error"):
            self._merlin_next_retry = now + _RETRY_AFTER_S
            if not self._was_in_fallback:
                _logger.warning(
                    "Merlin dedup unavailable (%s) - falling back to "
                    "vanilla LangChain. Will retry in %ds. If this is "
                    "the daily cap it auto-resets at UTC midnight.",
                    stats["error"], _RETRY_AFTER_S,
                )
                self._was_in_fallback = True
            return raw

        if self._was_in_fallback:
            _logger.info("Merlin dedup recovered - resuming optimization")
            self._was_in_fallback = False
        self._merlin_next_retry = 0.0
        return deduped

    # ---- Synchronous LangChain memory surface ----
    # Signatures MUST match BaseMemory exactly for mypy strict-mode.

    def load_memory_variables(self, inputs: dict[str, Any]) -> dict[str, Any]:
        if self.return_messages:
            self._last_stats = {}
            return {self.memory_key: list(self.chat_memory.messages)}
        raw = self._buffer_as_string()
        if not isinstance(raw, str) or not raw:
            self._last_stats = {}
            return {self.memory_key: raw}
        return {self.memory_key: self._maybe_dedup(raw)}

    def save_context(self, inputs: dict[str, Any], outputs: dict[str, str]) -> None:
        in_v = self._pick_value(inputs, self.input_key)
        out_v = self._pick_value(outputs, self.output_key)
        if in_v is not None:
            self.chat_memory.add_user_message(in_v)
        if out_v is not None:
            self.chat_memory.add_ai_message(out_v)

    def clear(self) -> None:
        self.chat_memory.clear()
        self._last_stats = {}
        self._merlin_next_retry = 0.0
        self._was_in_fallback = False

    # ---- Async LangChain memory surface ----

    async def aload_memory_variables(self, inputs: dict[str, Any]) -> dict[str, Any]:
        return await asyncio.to_thread(self.load_memory_variables, inputs)

    async def asave_context(
        self, inputs: dict[str, Any], outputs: dict[str, str]
    ) -> None:
        await asyncio.to_thread(self.save_context, inputs, outputs)

    async def aclear(self) -> None:
        await asyncio.to_thread(self.clear)

    @staticmethod
    def _pick_value(d: dict[str, Any], key: str | None) -> str | None:
        if key is not None:
            v = d.get(key)
            return v if isinstance(v, str) else None
        str_items = [(k, v) for k, v in d.items() if isinstance(v, str)]
        if len(str_items) == 1:
            return str_items[0][1]
        return None
