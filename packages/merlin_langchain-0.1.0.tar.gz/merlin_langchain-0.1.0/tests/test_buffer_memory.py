"""Tests for MerlinBufferMemory - skipped if langchain_core not installed."""
import asyncio
import inspect
import time

import pytest

pytest.importorskip("langchain_core")
pytest.importorskip("langchain_classic")

from merlin_langchain import MerlinBufferMemory  # noqa: E402
from langchain_classic.base_memory import BaseMemory  # noqa: E402


def test_messages_list_preserved():
    mem = MerlinBufferMemory(memory_key="history")
    mem.chat_memory.add_user_message("hello")
    mem.chat_memory.add_ai_message("world")
    assert len(mem.chat_memory.messages) == 2
    assert mem.chat_memory.messages[0].content == "hello"
    assert mem.chat_memory.messages[1].content == "world"


def test_load_memory_returns_string():
    mem = MerlinBufferMemory(memory_key="history")
    mem.chat_memory.add_user_message("alpha bravo")
    mem.chat_memory.add_ai_message("charlie delta")
    out = mem.load_memory_variables({})
    assert "history" in out
    assert isinstance(out["history"], str)
    assert "alpha" in out["history"]
    assert "delta" in out["history"]


def test_clear_works():
    mem = MerlinBufferMemory(memory_key="history")
    mem.chat_memory.add_user_message("x")
    mem.clear()
    assert mem.chat_memory.messages == []


def test_save_context_records_both_sides():
    mem = MerlinBufferMemory(memory_key="history", input_key="input", output_key="output")
    mem.save_context({"input": "user said this"}, {"output": "AI replied with that"})
    assert len(mem.chat_memory.messages) == 2
    out = mem.load_memory_variables({})
    assert "user said this" in out["history"]
    assert "AI replied with that" in out["history"]


def test_save_context_autodetect_single_str_value():
    mem = MerlinBufferMemory(memory_key="history")
    mem.save_context({"input": "hi"}, {"output": "hello"})
    assert len(mem.chat_memory.messages) == 2


def test_memory_variables_property():
    mem = MerlinBufferMemory(memory_key="chat_hist")
    assert mem.memory_variables == ["chat_hist"]


# ---- Pydantic / BaseMemory inheritance regression ----

def test_passes_pydantic_basememory_validation():
    """LangChain's Chain.memory slot is a Pydantic field typed as BaseMemory.
    Our class MUST inherit from BaseMemory or instantiation through any
    Chain will fail with ValidationError."""
    mem = MerlinBufferMemory(memory_key="h")
    assert isinstance(mem, BaseMemory)
    from pydantic import BaseModel, ConfigDict
    class _DummyChain(BaseModel):
        model_config = ConfigDict(arbitrary_types_allowed=True)
        memory: BaseMemory
    _DummyChain(memory=mem)


def test_signature_compatibility_with_basememory():
    """Liskov: parameter names + ordering of overrides must match the base."""
    for name in ("load_memory_variables", "save_context", "clear",
                 "aload_memory_variables", "asave_context", "aclear"):
        base_sig = inspect.signature(getattr(BaseMemory, name))
        ours_sig = inspect.signature(getattr(MerlinBufferMemory, name))
        assert list(base_sig.parameters) == list(ours_sig.parameters), \
            f"{name} param mismatch: base={list(base_sig.parameters)} " \
            f"ours={list(ours_sig.parameters)}"


# ---- Fail-safe + back-off behavior ----

def test_merlin_active_flag_reflects_fallback(monkeypatch):
    monkeypatch.setenv("MERLIN_BINARY", "/nope.exe")
    mem = MerlinBufferMemory(memory_key="h")
    mem.chat_memory.add_user_message("hello world this is a longer line for dedup\n" * 10)
    mem.chat_memory.add_user_message("more text\n" * 10)
    out = mem.load_memory_variables({})
    assert out["h"]
    assert mem.merlin_active is False


def test_retry_back_off_sets_cooldown(monkeypatch):
    """After failure, _merlin_next_retry must be set into the future."""
    monkeypatch.setenv("MERLIN_BINARY", "/nope.exe")
    mem = MerlinBufferMemory(memory_key="h")
    mem.chat_memory.add_user_message("hi this needs at least one full line\n" * 5)
    mem.chat_memory.add_user_message("more\n" * 5)
    mem.load_memory_variables({})
    assert mem._merlin_next_retry > time.monotonic()


def test_cooldown_skips_subprocess_on_repeated_calls(monkeypatch):
    """Within the cooldown window, _maybe_dedup must short-circuit and
    return raw text without calling dedup_text again."""
    monkeypatch.setenv("MERLIN_BINARY", "/nope.exe")
    mem = MerlinBufferMemory(memory_key="h")
    mem.chat_memory.add_user_message("a longer message line here\n" * 3)
    mem.chat_memory.add_user_message("another one\n" * 3)
    mem.load_memory_variables({})
    assert mem._merlin_next_retry > 0

    calls = {"n": 0}
    import merlin_langchain._dedup_helper as helper
    real = helper.dedup_text
    def spy(text, **kw):
        calls["n"] += 1
        return real(text, **kw)
    import merlin_langchain.memory as mod
    monkeypatch.setattr(mod, "dedup_text", spy)
    mem.load_memory_variables({})
    assert calls["n"] == 0, "dedup_text should NOT have been called during cooldown"


# ---- Async surface ----

def test_async_methods_delegate_correctly():
    mem = MerlinBufferMemory(memory_key="h")
    asyncio.run(mem.asave_context({"input": "hi"}, {"output": "hello"}))
    out = asyncio.run(mem.aload_memory_variables({}))
    assert "hi" in out["h"]
    assert "hello" in out["h"]
    asyncio.run(mem.aclear())
    assert mem.chat_memory.messages == []
