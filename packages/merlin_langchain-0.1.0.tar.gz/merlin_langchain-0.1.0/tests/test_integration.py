"""Comparative test: Merlin scratchpad vs naive scratchpad on a redundant workload."""
import os

import pytest

from merlin_langchain import merlin_format_log_to_str
from merlin_langchain._dedup_helper import _binary_path

HAS_BINARY = os.path.exists(_binary_path())


class FakeAction:
    def __init__(self, log: str):
        self.log = log


def baseline_format(steps, obs_prefix="Observation: ", llm_prefix="Thought: "):
    """Mirror of langchain's format_log_to_str (no dedup)."""
    out = ""
    for action, obs in steps:
        out += action.log + f"\n{obs_prefix}{obs}\n{llm_prefix}"
    return out


@pytest.mark.skipif(not HAS_BINARY, reason="no binary - comparative test needs it")
def test_5_turn_react_loop_shrinks_at_least_30_pct():
    boilerplate = "Search results: example.com header header header content content. " * 50
    steps = [(FakeAction(log=f"Thought: turn {i}\nAction: search\n"), boilerplate) for i in range(5)]
    baseline = baseline_format(steps)
    merlin = merlin_format_log_to_str(steps, keep_tail_lines=4)
    # functional: last turn's content survives
    assert "turn 4" in merlin
    # size: >=30% smaller
    ratio = 1 - (len(merlin) / len(baseline))
    assert ratio > 0.30, f"only saved {ratio:.1%} (baseline={len(baseline)}, merlin={len(merlin)})"


def test_functional_equivalence_unique_workload():
    # If every step is unique, output should be roughly the same size.
    steps = [(FakeAction(log=f"Thought: very unique step {i}\n"), f"unique obs {i}") for i in range(5)]
    baseline = baseline_format(steps)
    merlin = merlin_format_log_to_str(steps, keep_tail_lines=4)
    assert "very unique step 0" in merlin
    assert "very unique step 4" in merlin
    # tolerate small differences from trailing-newline handling
    assert abs(len(merlin) - len(baseline)) <= 5
