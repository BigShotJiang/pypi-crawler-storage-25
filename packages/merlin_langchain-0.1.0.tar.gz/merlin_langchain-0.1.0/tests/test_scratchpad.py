"""Tests for merlin_format_log_to_str - no langchain dependency."""
from merlin_langchain import merlin_format_log_to_str


class FakeAction:
    def __init__(self, log: str):
        self.log = log


def test_empty_steps():
    assert merlin_format_log_to_str([]) == ""


def test_basic_format_preserves_content():
    steps = [(FakeAction(log="Thought: try X\nAction: search"), "RESULT_42")]
    out = merlin_format_log_to_str(steps)
    assert "try X" in out
    assert "RESULT_42" in out


def test_last_turn_thought_marker_preserved():
    boilerplate = "Same boilerplate observation returned every turn. " * 30
    steps = [(FakeAction(log=f"Thought: step_id_{i}\n"), boilerplate) for i in range(10)]
    out = merlin_format_log_to_str(steps, keep_tail_lines=4)
    assert "step_id_9" in out  # last step's thought must survive
