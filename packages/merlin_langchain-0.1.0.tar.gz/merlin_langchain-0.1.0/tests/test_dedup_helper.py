"""Unit tests for _dedup_helper.dedup_text - work with or without binary."""
import os

import pytest

from merlin_langchain._dedup_helper import dedup_text, _binary_path

BINARY = _binary_path()
HAS_BINARY = os.path.exists(BINARY)
skip_no_binary = pytest.mark.skipif(not HAS_BINARY, reason=f"no binary at {BINARY}")


def test_empty_input():
    out, stats = dedup_text("")
    assert out == ""
    assert stats["input_bytes"] == 0
    assert stats["dedup_ratio"] == 0.0


def test_missing_binary_returns_original_unchanged(monkeypatch):
    """Cap exhausted / binary missing must return EXACTLY the input text -
    no python-side dedup, no truncation, no tampering. The user's LLM sees
    exactly what vanilla LangChain would have produced."""
    monkeypatch.setenv("MERLIN_BINARY", "/path/that/does/not/exist.exe")
    text = "alpha\nbeta\nalpha\ngamma\nalpha\n"
    out, stats = dedup_text(text)
    assert out == text  # bytewise identical
    assert stats["error"] is not None
    assert "not found" in stats["error"]
    assert stats["dedup_ratio"] == 0.0
    assert stats["output_bytes"] == stats["input_bytes"]
    # Critical: no `fallback_used` field (we removed Python fallback).
    assert "fallback_used" not in stats


def test_keep_tail_returns_original_when_too_short():
    text = "a\nb\n"
    out, stats = dedup_text(text, keep_tail_lines=5)
    assert out == text
    assert stats["error"] is None


@skip_no_binary
def test_duplicates_get_deduped():
    line = "this is a duplicate line with enough length to register " * 3
    text = (line + "\n") * 60 + "UNIQUE_TAIL_LINE_A\nUNIQUE_TAIL_LINE_B\n"
    out, stats = dedup_text(text, keep_tail_lines=2)
    if stats["error"] is not None:
        pytest.skip(f"binary refused: {stats['error']}")
    assert stats["output_bytes"] < stats["input_bytes"]
    assert "UNIQUE_TAIL_LINE_A" in out
    assert "UNIQUE_TAIL_LINE_B" in out


@skip_no_binary
def test_all_unique_lines_minimal_reduction():
    lines = [f"unique distinct line number {i:04d} with reasonable padding text" for i in range(120)]
    text = "\n".join(lines) + "\n"
    out, stats = dedup_text(text, keep_tail_lines=2)
    if stats["error"] is not None:
        pytest.skip(f"binary refused: {stats['error']}")
    assert stats["dedup_ratio"] < 0.10


@skip_no_binary
def test_tail_lines_byte_exact():
    body = ("duplicate filler line for dedup engine processing test " * 4 + "\n") * 40
    tail = "TAIL_LINE_1_unique_marker_xyz\nTAIL_LINE_2_unique_marker_xyz"
    text = body + tail
    out, stats = dedup_text(text, keep_tail_lines=2)
    if stats["error"] is not None:
        pytest.skip(f"binary refused: {stats['error']}")
    assert out.endswith(tail) or out.endswith(tail + "\n")


@skip_no_binary
def test_extra_env_redirects_state_path(tmp_path):
    """extra_env must override USERPROFILE/HOME for the subprocess only,
    so the binary writes its state.bin into a tempdir without polluting
    the user's real ~/.merlin/."""
    fake_home = tmp_path / "fake_home"
    fake_home.mkdir()
    text = ("repeating line for dedup verification " * 4 + "\n") * 30 + "tail\n"
    out, stats = dedup_text(
        text,
        keep_tail_lines=1,
        extra_env={"USERPROFILE": str(fake_home), "HOME": str(fake_home)},
    )
    if stats["error"] is not None:
        pytest.skip(f"binary refused: {stats['error']}")
    assert (fake_home / ".merlin" / "state.bin").exists()
