# veri-sdk

Python SDK for [Veri](https://veri.studio) — RL post-training platform.

## Install

```bash
uv pip install veri-sdk
# or
pip install veri-sdk
```

## Quickstart

```python
from veri_sdk import Client

client = Client(api_key="your-api-key", base_url="https://api.veri.studio")

# Upload a dataset
dataset = client.datasets.upload("training_data.jsonl", name="my-dataset")

# Upload a reward function
reward = client.reward_functions.upload("reward.py", name="math-reward")

# Start a GRPO training job
job = client.training_jobs.create(
    base_model="Qwen/Qwen3-4B",
    dataset_id=dataset.id,
    reward_function_id=reward.id,
    output_name="my-fine-tuned-model",
    hyperparameters={
        "learning_rate": 1e-6,
        "max_steps": 100,
        "rollouts_per_prompt": 4,
        "max_response_length": 512,
    },
)

print(f"Job {job.id} — status: {job.status}")

# Wait for completion
job.wait(poll_interval=15)
print(f"Done! Status: {job.status}")

# Download checkpoint
if job.download_url:
    job.download("./checkpoints")
```

## Data Sources

```python
# Upload JSONL file
dataset = client.datasets.upload("data.jsonl")

# Connect to S3
dataset = client.datasets.connect(
    name="my-s3-data",
    source_type="s3",
    source_uri="s3://my-bucket/data.jsonl",
    credentials={"aws_access_key_id": "...", "aws_secret_access_key": "..."},
)

# Connect to HuggingFace
dataset = client.datasets.connect(
    name="gsm8k",
    source_type="hf",
    hf_dataset="gsm8k",
    hf_config={"split": "train", "column_mapping": {"question": "prompt"}},
)

# Connect to a database
dataset = client.datasets.connect(
    name="prod-prompts",
    source_type="postgres",
    db_connection="postgres://user:pass@host/db",
    db_query="SELECT prompt, answer FROM training_data",
)

# Validate before connecting
result = client.datasets.validate(
    source_type="hf", hf_dataset="gsm8k", hf_config={"split": "train"}
)
print(f"Valid: {result['valid']}, Rows: {result['num_rows']}")
```

## GPU Selection

```python
# Specify the GPU config explicitly.
job = client.training_jobs.create(
    base_model="Qwen/Qwen3-4B",
    gpu_type="A100-80GB",
    gpu_count=2,
    ...
)
```

## Checkpoint Destination

```python
# Default: Veri-managed storage
job = client.training_jobs.create(...)

# Your own S3 bucket
job = client.training_jobs.create(
    ...,
    checkpoint_destination={
        "type": "s3",
        "uri": "s3://my-bucket/checkpoints/",
    },
)
```

## List & Manage

```python
# List your datasets
datasets = client.datasets.list()

# List jobs by status
running_jobs = client.training_jobs.list(status="running")

# Cancel a job
client.training_jobs.cancel(job.id)
```
