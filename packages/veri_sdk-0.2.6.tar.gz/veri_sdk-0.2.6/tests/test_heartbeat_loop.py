"""VS-218 Part D-3 — SDK heartbeat loop + --detach flag.

The loop pings POST /heartbeat every ~30s while a `veri train` is
waiting. If we stop pinging (Ctrl+C → Part B fires the explicit cancel
first; SIGKILL/network drop → reconciler reaps after timeout), the pod
dies. With --detach, neither the heartbeat loop nor the wait runs —
the SDK exits immediately after submission and the server treats the
job as unowned.
"""

from __future__ import annotations

from unittest.mock import MagicMock, call

import pytest

from veri_sdk._decorators import _heartbeat_loop


@pytest.mark.asyncio
async def test_heartbeat_loop_pings_until_terminal(monkeypatch):
    """The loop fires heartbeat() once per tick until status hits terminal."""
    monkeypatch.setattr("veri_sdk._decorators._HEARTBEAT_INTERVAL_SECONDS", 0.0)

    job = MagicMock()
    job.id = "tj_abc"
    job.status = "running"

    call_count = {"n": 0}

    def fake_heartbeat(job_id):
        call_count["n"] += 1
        if call_count["n"] >= 3:
            job.status = "completed"  # flip to terminal so loop exits
        return {"status": job.status}

    client = MagicMock()
    client.training_jobs.heartbeat.side_effect = fake_heartbeat

    async def noop(_msg):
        pass

    await _heartbeat_loop(job, client, safe_log=noop)

    assert call_count["n"] == 3
    client.training_jobs.heartbeat.assert_has_calls(
        [call("tj_abc"), call("tj_abc"), call("tj_abc")]
    )


@pytest.mark.asyncio
async def test_heartbeat_loop_swallows_errors(monkeypatch):
    """A single failed ping must not break the loop — the reconciler's
    timeout (default 300s) is much longer than any transient API blip."""
    monkeypatch.setattr("veri_sdk._decorators._HEARTBEAT_INTERVAL_SECONDS", 0.0)

    job = MagicMock()
    job.id = "tj_xyz"
    job.status = "running"

    call_count = {"n": 0}

    def fake_heartbeat(job_id):
        call_count["n"] += 1
        if call_count["n"] == 1:
            raise RuntimeError("transient network blip")
        if call_count["n"] >= 2:
            job.status = "completed"
        return {"status": job.status}

    client = MagicMock()
    client.training_jobs.heartbeat.side_effect = fake_heartbeat

    async def noop(_msg):
        pass

    # Must not propagate the RuntimeError.
    await _heartbeat_loop(job, client, safe_log=noop)
    assert call_count["n"] == 2


@pytest.mark.asyncio
async def test_heartbeat_loop_exits_immediately_when_already_terminal(monkeypatch):
    """No-op when the job is already in a terminal state — covers the
    race where status flips between the create call and the loop start."""
    monkeypatch.setattr("veri_sdk._decorators._HEARTBEAT_INTERVAL_SECONDS", 0.0)

    job = MagicMock()
    job.id = "tj_done"
    job.status = "completed"

    client = MagicMock()

    async def noop(_msg):
        pass

    await _heartbeat_loop(job, client, safe_log=noop)
    client.training_jobs.heartbeat.assert_not_called()
