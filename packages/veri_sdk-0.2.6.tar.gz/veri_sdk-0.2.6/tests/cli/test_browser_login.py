"""Tests for veri_sdk.cli.utils.browser_login — local listener + state verification."""

from __future__ import annotations

import json
import threading
import time
import urllib.error
import urllib.request
from unittest.mock import MagicMock

import pytest

from veri_sdk.cli.utils import browser_login


def _post_token(port: int, state: str, token: str = "vk_test_xyz") -> int:
    """Simulate the dashboard POSTing the token back. Returns response status."""
    body = json.dumps({"state": state, "token": token}).encode()
    req = urllib.request.Request(
        f"http://127.0.0.1:{port}/",
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req) as resp:
        return resp.status


def test_listener_captures_valid_token(monkeypatch):
    """Happy path: a POST with the right state token is captured + returned."""
    captured_url = {}

    def fake_open(url):
        captured_url["url"] = url
        # Extract the port + state from the URL, simulate the dashboard POST.
        from urllib.parse import urlparse, parse_qs

        qs = parse_qs(urlparse(url).query)
        port = int(qs["port"][0])
        state = qs["state"][0]
        threading.Thread(
            target=lambda: (time.sleep(0.05), _post_token(port, state)),
            daemon=True,
        ).start()
        return True

    monkeypatch.setattr(browser_login.webbrowser, "open", fake_open)

    token = browser_login.browser_login(
        "https://api.veri.studio",
        timeout=5,
    )
    assert token == "vk_test_xyz"
    assert "/cli-login?" in captured_url["url"]
    assert "port=" in captured_url["url"]
    assert "state=" in captured_url["url"]


def test_listener_rejects_wrong_state(monkeypatch):
    """A POST with the wrong state must not capture; the listener should keep waiting."""
    captured_port: dict = {}

    def fake_open(url):
        from urllib.parse import urlparse, parse_qs

        qs = parse_qs(urlparse(url).query)
        port = int(qs["port"][0])
        captured_port["port"] = port

        # First POST with a BAD state — should be rejected.
        def attacker():
            time.sleep(0.05)
            try:
                _post_token(port, state="wrong_state", token="vk_attacker")
            except urllib.error.HTTPError:
                pass
            # Then a POST with the RIGHT state.
            time.sleep(0.05)
            _post_token(port, qs["state"][0], token="vk_legit")

        threading.Thread(target=attacker, daemon=True).start()
        return True

    monkeypatch.setattr(browser_login.webbrowser, "open", fake_open)
    token = browser_login.browser_login("https://api.veri.studio", timeout=5)
    assert token == "vk_legit"


def test_listener_times_out(monkeypatch):
    """If nothing POSTs within timeout, raise TimeoutError."""
    monkeypatch.setattr(browser_login.webbrowser, "open", lambda url: True)
    with pytest.raises(TimeoutError):
        browser_login.browser_login("https://api.veri.studio", timeout=0.5)


def test_dashboard_url_is_correct_for_api_subdomain(monkeypatch):
    """`api.veri.studio` → `veri.studio` for the dashboard."""
    captured = {}
    monkeypatch.setattr(
        browser_login.webbrowser, "open", lambda url: captured.update({"url": url}) or True
    )
    monkeypatch.setattr(browser_login, "_wait_for_token", lambda *_, **__: "vk_dummy")
    browser_login.browser_login("https://api.veri.studio", timeout=1)
    assert "https://veri.studio/cli-login" in captured["url"]


def test_dashboard_url_for_localhost(monkeypatch):
    """`localhost` URL is preserved (no `api.` to strip)."""
    captured = {}
    monkeypatch.setattr(
        browser_login.webbrowser, "open", lambda url: captured.update({"url": url}) or True
    )
    monkeypatch.setattr(browser_login, "_wait_for_token", lambda *_, **__: "vk_dummy")
    browser_login.browser_login("http://localhost:3000", timeout=1)
    assert "http://localhost:3000/cli-login" in captured["url"]


def test_url_includes_hostname(monkeypatch):
    """Hostname is in the URL so the dashboard can show 'Authorize CLI on <host>'."""
    captured = {}
    monkeypatch.setattr(
        browser_login.webbrowser, "open", lambda url: captured.update({"url": url}) or True
    )
    monkeypatch.setattr(browser_login, "_wait_for_token", lambda *_, **__: "vk_dummy")
    browser_login.browser_login("https://api.veri.studio", timeout=1)
    assert "hostname=" in captured["url"]


def test_cors_preflight_responds_200(monkeypatch):
    """OPTIONS preflight from a different origin must succeed."""
    server, port, _state = browser_login._spawn_listener(MagicMock())
    try:
        req = urllib.request.Request(
            f"http://127.0.0.1:{port}/",
            method="OPTIONS",
            headers={
                "Origin": "https://veri.studio",
                "Access-Control-Request-Method": "POST",
            },
        )
        with urllib.request.urlopen(req) as resp:
            assert resp.status == 204
            assert resp.headers.get("Access-Control-Allow-Origin") == "*"
    finally:
        server.shutdown()
