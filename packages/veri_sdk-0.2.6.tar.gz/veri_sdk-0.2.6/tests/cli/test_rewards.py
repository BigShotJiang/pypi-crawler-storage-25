"""Tests for veri_sdk.cli.commands.rewards — upload/list/get/delete."""

from __future__ import annotations

import json
from unittest.mock import MagicMock

from typer.testing import CliRunner

from veri_sdk.cli.commands import rewards as rw_mod
from veri_sdk.cli.main import app
from veri_sdk.cli.utils.reward_check import check_reward_file

runner = CliRunner()


def _stub_client(monkeypatch) -> MagicMock:
    client = MagicMock()
    monkeypatch.setattr(rw_mod, "get_client", lambda: client)
    return client


def _make_reward(id_="rf_abc", name="my-rw"):
    rw = MagicMock()
    rw.id = id_
    rw.name = name
    rw.format = "trl"
    return rw


# ---------- reward_check helper ----------

def test_check_passes_on_valid_python_with_function(tmp_path):
    f = tmp_path / "reward.py"
    f.write_text("def reward(prompts, completions, **kw):\n    return [1.0]\n")
    ok, errors = check_reward_file(f)
    assert ok
    assert errors == []


def test_check_fails_on_syntax_error(tmp_path):
    f = tmp_path / "bad.py"
    f.write_text("def reward( oops syntax\n")
    ok, errors = check_reward_file(f)
    assert not ok
    assert any("syntax" in e.lower() for e in errors)


def test_check_fails_when_no_function_defined(tmp_path):
    f = tmp_path / "no_fn.py"
    f.write_text("X = 1\nY = 2\n")
    ok, errors = check_reward_file(f)
    assert not ok
    assert any("function" in e.lower() for e in errors)


# ---------- upload ----------

def test_upload_auto_runs_check(tmp_path, monkeypatch):
    client = _stub_client(monkeypatch)
    client.reward_functions.upload.return_value = _make_reward()
    f = tmp_path / "reward.py"
    f.write_text("def reward(p, c, **kw):\n    return [1.0]\n")

    result = runner.invoke(app, ["rewards", "upload", str(f)])
    assert result.exit_code == 0, result.stdout + result.stderr
    client.reward_functions.upload.assert_called_once()


def test_upload_fails_on_bad_python(tmp_path, monkeypatch):
    client = _stub_client(monkeypatch)
    f = tmp_path / "bad.py"
    f.write_text("def syntax bug here\n")

    result = runner.invoke(app, ["rewards", "upload", str(f)])
    assert result.exit_code != 0
    client.reward_functions.upload.assert_not_called()


def test_upload_skip_validation_skips_check(tmp_path, monkeypatch):
    client = _stub_client(monkeypatch)
    client.reward_functions.upload.return_value = _make_reward()
    f = tmp_path / "bad.py"
    f.write_text("not even python\n")

    result = runner.invoke(app, ["rewards", "upload", str(f), "--skip-validation"])
    assert result.exit_code == 0, result.stdout
    client.reward_functions.upload.assert_called_once()


def test_upload_quiet_emits_only_id(tmp_path, monkeypatch):
    client = _stub_client(monkeypatch)
    client.reward_functions.upload.return_value = _make_reward(id_="rf_xyz")
    f = tmp_path / "reward.py"
    f.write_text("def reward(p, c, **kw):\n    return [1.0]\n")

    result = runner.invoke(app, ["rewards", "upload", str(f), "--quiet"])
    assert result.exit_code == 0
    assert result.stdout.strip() == "rf_xyz"


# ---------- list / get / delete ----------

def test_list(monkeypatch):
    client = _stub_client(monkeypatch)
    client.reward_functions.list.return_value = [
        _make_reward(id_="rf_a", name="alpha"),
        _make_reward(id_="rf_b", name="beta"),
    ]
    result = runner.invoke(app, ["rewards", "list", "--format", "json"])
    assert result.exit_code == 0, result.stdout
    rows = json.loads(result.stdout)
    assert {r["id"] for r in rows} == {"rf_a", "rf_b"}


def test_get(monkeypatch):
    client = _stub_client(monkeypatch)
    client.reward_functions.get.return_value = _make_reward(id_="rf_xyz")
    result = runner.invoke(app, ["rewards", "get", "rf_xyz", "--format", "json"])
    assert result.exit_code == 0
    assert json.loads(result.stdout)["id"] == "rf_xyz"


def test_delete(monkeypatch):
    client = _stub_client(monkeypatch)
    result = runner.invoke(app, ["rewards", "delete", "rf_xyz"])
    assert result.exit_code == 0
    client.reward_functions.delete.assert_called_once_with("rf_xyz")
