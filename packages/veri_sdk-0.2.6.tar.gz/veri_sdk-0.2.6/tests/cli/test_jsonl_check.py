"""Tests for veri_sdk.cli.utils.jsonl_check — structural JSONL validation."""

from __future__ import annotations

from veri_sdk.cli.utils.jsonl_check import CheckResult, check_jsonl


def test_valid_jsonl_passes(tmp_path):
    f = tmp_path / "ok.jsonl"
    f.write_text('{"prompt": "hi", "answer": "ok"}\n{"prompt": "yo", "answer": "go"}\n')
    result = check_jsonl(f)
    assert result.ok
    assert result.row_count == 2
    assert result.errors == []


def test_empty_file_fails(tmp_path):
    f = tmp_path / "empty.jsonl"
    f.write_text("")
    result = check_jsonl(f)
    assert not result.ok
    assert result.row_count == 0
    assert any("empty" in e.lower() for e in result.errors)


def test_blank_lines_ignored(tmp_path):
    f = tmp_path / "blanks.jsonl"
    f.write_text('{"a": 1}\n\n  \n{"a": 2}\n')
    result = check_jsonl(f)
    assert result.ok
    assert result.row_count == 2


def test_invalid_json_reported_with_line_number(tmp_path):
    f = tmp_path / "bad.jsonl"
    f.write_text('{"a": 1}\nnot json\n{"a": 3}\n')
    result = check_jsonl(f)
    assert not result.ok
    assert any("line 2" in e for e in result.errors)


def test_non_dict_row_reported(tmp_path):
    f = tmp_path / "list.jsonl"
    f.write_text('[1, 2, 3]\n{"a": 1}\n')
    result = check_jsonl(f)
    assert not result.ok
    assert any("line 1" in e and "object" in e.lower() for e in result.errors)


def test_duplicate_ids_reported(tmp_path):
    f = tmp_path / "dup.jsonl"
    f.write_text(
        '{"id": "a", "x": 1}\n'
        '{"id": "b", "x": 2}\n'
        '{"id": "a", "x": 3}\n'
    )
    result = check_jsonl(f)
    assert not result.ok
    assert any("duplicate" in e.lower() and "a" in e for e in result.errors)


def test_required_columns_pass(tmp_path):
    f = tmp_path / "ok.jsonl"
    f.write_text('{"prompt": "hi", "answer": "ok"}\n')
    result = check_jsonl(f, required_columns=["prompt", "answer"])
    assert result.ok


def test_required_columns_missing_reported(tmp_path):
    f = tmp_path / "bad.jsonl"
    f.write_text('{"prompt": "hi"}\n')
    result = check_jsonl(f, required_columns=["prompt", "answer"])
    assert not result.ok
    assert any("answer" in e for e in result.errors)


def test_max_errors_caps_output(tmp_path):
    f = tmp_path / "manybad.jsonl"
    lines = "\n".join("not json" for _ in range(50))
    f.write_text(lines + "\n")
    result = check_jsonl(f, max_errors=5)
    assert not result.ok
    # Should cap reported errors at max_errors + a "truncated" note.
    assert len(result.errors) <= 6  # 5 errors + 1 truncation message


def test_check_result_summary_human_readable():
    r = CheckResult(row_count=10, errors=[])
    assert "10" in r.summary()


def test_no_id_column_no_dup_check(tmp_path):
    """When rows have no `id` field, dup-check is skipped (no false positives)."""
    f = tmp_path / "noid.jsonl"
    f.write_text('{"x": 1}\n{"x": 1}\n')
    result = check_jsonl(f)
    assert result.ok
