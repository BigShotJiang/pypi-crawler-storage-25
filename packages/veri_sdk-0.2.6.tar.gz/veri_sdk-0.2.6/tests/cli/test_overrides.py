"""Tests for veri_sdk.cli.utils.overrides — the --set / --set-string TOML merger."""

from __future__ import annotations

import pytest

from veri_sdk.cli.utils.overrides import OverrideError, apply_overrides


def test_simple_scalar_set():
    cfg = {}
    apply_overrides(cfg, set_pairs=["base_model=Qwen/Qwen3-8B"])
    assert cfg == {"base_model": "Qwen/Qwen3-8B"}


def test_nested_dotted_path_creates_tables():
    cfg = {}
    apply_overrides(cfg, set_pairs=["model.base=Qwen/Qwen3-8B"])
    assert cfg == {"model": {"base": "Qwen/Qwen3-8B"}}


def test_deeply_nested_path():
    cfg = {}
    apply_overrides(cfg, set_pairs=["a.b.c.d=1"])
    assert cfg == {"a": {"b": {"c": {"d": 1}}}}


def test_overrides_into_existing_table():
    cfg = {"model": {"base": "old"}, "method": {"lr": 1e-6}}
    apply_overrides(
        cfg,
        set_pairs=["model.base=new", "method.lr=2e-6", "method.steps=100"],
    )
    assert cfg == {
        "model": {"base": "new"},
        "method": {"lr": 2e-6, "steps": 100},
    }


@pytest.mark.parametrize(
    "raw,expected",
    [
        ("x=1", 1),
        ("x=1.5", 1.5),
        ("x=2e-6", 2e-6),
        ("x=true", True),
        ("x=false", False),
        ("x=null", None),
        ("x=none", None),
        ("x=hello", "hello"),
        ("x='quoted'", "quoted"),
        ('x="double"', "double"),
        ("x=[1,2,3]", [1, 2, 3]),
    ],
)
def test_type_coercion(raw, expected):
    cfg = {}
    apply_overrides(cfg, set_pairs=[raw])
    assert cfg["x"] == expected


def test_set_string_forces_string_type():
    cfg = {}
    apply_overrides(cfg, set_string_pairs=["version=1.0", "count=42", "enabled=true"])
    assert cfg == {"version": "1.0", "count": "42", "enabled": "true"}


def test_repeated_set_builds_list():
    cfg = {}
    apply_overrides(cfg, set_pairs=["tags=foo", "tags=bar", "tags=baz"])
    assert cfg == {"tags": ["foo", "bar", "baz"]}


def test_scalar_then_subkey_conflict_raises():
    with pytest.raises(OverrideError, match="scalar"):
        apply_overrides({}, set_pairs=["foo=1", "foo.bar=2"])


def test_subkey_then_overwrite_scalar_on_table_raises():
    with pytest.raises(OverrideError, match="table"):
        apply_overrides({}, set_pairs=["foo.bar=1", "foo=2"])


def test_missing_equals_raises():
    with pytest.raises(OverrideError, match="key=value"):
        apply_overrides({}, set_pairs=["nopaste"])


def test_empty_key_raises():
    with pytest.raises(OverrideError, match="empty key"):
        apply_overrides({}, set_pairs=["=value"])


def test_value_with_equals_in_it_preserved():
    """e.g. base64 strings or env-var-style values with `=` in them."""
    cfg = {}
    apply_overrides(cfg, set_pairs=["secret.key=abc=def="])
    assert cfg == {"secret": {"key": "abc=def="}}


def test_set_string_and_set_dont_interact():
    cfg = {}
    apply_overrides(
        cfg,
        set_pairs=["a=1"],
        set_string_pairs=["b=1"],
    )
    assert cfg == {"a": 1, "b": "1"}
