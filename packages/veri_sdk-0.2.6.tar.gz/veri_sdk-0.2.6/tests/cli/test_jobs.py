"""Tests for veri_sdk.cli.commands.jobs."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock

from typer.testing import CliRunner

from veri_sdk.cli.commands import jobs as jobs_mod
from veri_sdk.cli.main import app

runner = CliRunner()


def _stub_client(monkeypatch) -> MagicMock:
    client = MagicMock()
    monkeypatch.setattr(jobs_mod, "get_client", lambda: client)
    return client


def _make_job(id_="job_abc", status="queued"):
    j = MagicMock()
    j.id = id_
    j.status = status
    j.base_model = "Qwen/Qwen3-4B"
    j.dashboard_url = f"https://dash/{id_}"
    j.download_url = None
    j.error = None
    j.error_message = None
    j.cost_usd = 0.0
    return j


def _train_toml(tmp_path: Path, kind: str = "train") -> Path:
    f = tmp_path / "train.toml"
    f.write_text(f"""\
kind = "{kind}"
[job]
name = "test-run"
output_model = "tuned-model"
[model]
base = "Qwen/Qwen3-4B"
[dataset]
id = "ds_abc"
[reward]
id = "rf_abc"
[method]
type = "grpo"
learning_rate = 1e-6
max_steps = 100
[resources]
gpu_type = "A100-80GB"
gpu_count = 2
""")
    return f


# ---------- create from config ----------

def test_create_from_config_calls_sdk(tmp_path, monkeypatch):
    client = _stub_client(monkeypatch)
    client.training_jobs.create.return_value = _make_job()
    f = _train_toml(tmp_path)

    result = runner.invoke(app, ["jobs", "create", str(f)])
    assert result.exit_code == 0, result.stdout + result.stderr
    _, kwargs = client.training_jobs.create.call_args
    assert kwargs["base_model"] == "Qwen/Qwen3-4B"
    assert kwargs["dataset_id"] == "ds_abc"
    assert kwargs["reward_function_id"] == "rf_abc"
    assert kwargs["output_name"] == "tuned-model"
    assert kwargs["gpu_type"] == "A100-80GB"
    assert kwargs["gpu_count"] == 2
    assert kwargs["method"] == "grpo"
    assert kwargs["hyperparameters"]["learning_rate"] == 1e-6
    assert kwargs["hyperparameters"]["max_steps"] == 100


def test_create_wrong_kind_rejected(tmp_path, monkeypatch):
    client = _stub_client(monkeypatch)
    f = _train_toml(tmp_path, kind="deploy")
    result = runner.invoke(app, ["jobs", "create", str(f)])
    assert result.exit_code != 0
    client.training_jobs.create.assert_not_called()


def test_create_missing_kind_rejected(tmp_path, monkeypatch):
    client = _stub_client(monkeypatch)
    f = tmp_path / "no-kind.toml"
    f.write_text('[job]\nname = "x"\n')
    result = runner.invoke(app, ["jobs", "create", str(f)])
    assert result.exit_code != 0
    client.training_jobs.create.assert_not_called()


def test_create_applies_set_overrides(tmp_path, monkeypatch):
    client = _stub_client(monkeypatch)
    client.training_jobs.create.return_value = _make_job()
    f = _train_toml(tmp_path)

    runner.invoke(
        app,
        [
            "jobs",
            "create",
            str(f),
            "--set",
            "model.base=Qwen/Qwen3-8B",
            "--set",
            "resources.gpu_count=4",
        ],
    )
    _, kwargs = client.training_jobs.create.call_args
    assert kwargs["base_model"] == "Qwen/Qwen3-8B"
    assert kwargs["gpu_count"] == 4


def test_create_dry_run_does_not_submit(tmp_path, monkeypatch):
    client = _stub_client(monkeypatch)
    client.cost.estimate.return_value = {"estimated_cost_usd": 12.34, "duration_minutes": 60}
    f = _train_toml(tmp_path)

    result = runner.invoke(app, ["jobs", "create", str(f), "--dry-run"])
    assert result.exit_code == 0, result.stdout
    client.training_jobs.create.assert_not_called()
    client.cost.estimate.assert_called_once()


def test_create_convenience_flag_overrides(tmp_path, monkeypatch):
    """--base-model expands to --set model.base=..."""
    client = _stub_client(monkeypatch)
    client.training_jobs.create.return_value = _make_job()
    f = _train_toml(tmp_path)

    runner.invoke(app, ["jobs", "create", str(f), "--base-model", "Qwen/Qwen3-14B"])
    _, kwargs = client.training_jobs.create.call_args
    assert kwargs["base_model"] == "Qwen/Qwen3-14B"


# ---------- list / get / cancel / download ----------

def test_list(monkeypatch):
    client = _stub_client(monkeypatch)
    client.training_jobs.list.return_value = [_make_job(id_="job_a"), _make_job(id_="job_b")]
    result = runner.invoke(app, ["jobs", "list", "--format", "json"])
    assert result.exit_code == 0
    rows = json.loads(result.stdout)
    assert {r["id"] for r in rows} == {"job_a", "job_b"}


def test_list_filters_by_status(monkeypatch):
    client = _stub_client(monkeypatch)
    client.training_jobs.list.return_value = []
    runner.invoke(app, ["jobs", "list", "--status", "running"])
    _, kwargs = client.training_jobs.list.call_args
    assert kwargs["status"] == "running"


def test_get(monkeypatch):
    client = _stub_client(monkeypatch)
    client.training_jobs.get.return_value = _make_job(id_="job_xyz")
    result = runner.invoke(app, ["jobs", "get", "job_xyz", "--format", "json"])
    assert result.exit_code == 0
    assert json.loads(result.stdout)["id"] == "job_xyz"


def test_cancel(monkeypatch):
    client = _stub_client(monkeypatch)
    client.training_jobs.cancel.return_value = _make_job(id_="job_xyz", status="cancelled")
    result = runner.invoke(app, ["jobs", "cancel", "job_xyz"])
    assert result.exit_code == 0
    client.training_jobs.cancel.assert_called_once_with("job_xyz")


def test_download_calls_job_download(monkeypatch, tmp_path):
    client = _stub_client(monkeypatch)
    job = _make_job()
    job.download_url = "https://example.com/checkpoint"
    job.download.return_value = str(tmp_path / "out")
    client.training_jobs.get.return_value = job

    result = runner.invoke(app, ["jobs", "download", "job_abc", "--output-dir", str(tmp_path)])
    assert result.exit_code == 0
    job.download.assert_called_once()


def test_estimate(monkeypatch, tmp_path):
    client = _stub_client(monkeypatch)
    client.cost.estimate.return_value = {"estimated_cost_usd": 4.56, "duration_minutes": 30}
    f = _train_toml(tmp_path)
    result = runner.invoke(app, ["jobs", "estimate", str(f), "--format", "json"])
    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["estimated_cost_usd"] == 4.56
