"""Tests for the hero `veri run` dispatcher."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock

from typer.testing import CliRunner

from veri_sdk.cli.commands import deployments as dep_mod
from veri_sdk.cli.commands import evals as ev_mod
from veri_sdk.cli.commands import jobs as jobs_mod
from veri_sdk.cli.main import app

runner = CliRunner()


def _stub_all(monkeypatch) -> MagicMock:
    client = MagicMock()
    for mod in (jobs_mod, dep_mod, ev_mod):
        monkeypatch.setattr(mod, "get_client", lambda c=client: c)
    return client


def _write_config(tmp_path: Path, kind: str) -> Path:
    """Write a minimal but valid config for the given kind."""
    if kind == "train":
        body = """\
kind = "train"
[job]
name = "x"
output_model = "y"
[model]
base = "Qwen/Qwen3-4B"
[dataset]
id = "ds_abc"
[reward]
id = "rf_abc"
[method]
type = "grpo"
[resources]
gpu_type = "A100-80GB"
gpu_count = 1
"""
    elif kind == "deploy":
        body = """\
kind = "deploy"
[deployment]
name = "x"
model = "job_abc"
source = "training_job"
[resources]
gpu_type = "A100-80GB"
gpu_count = 1
"""
    elif kind == "eval":
        body = """\
kind = "eval"
[eval]
name = "x"
dataset_id = "ds_abc"
[[scorers]]
type = "exact-match"
weight = 1.0
"""
    else:
        body = '[some]\nthing = 1\n'
    f = tmp_path / f"{kind or 'none'}.toml"
    f.write_text(body)
    return f


def test_run_train_calls_jobs_create(tmp_path, monkeypatch):
    client = _stub_all(monkeypatch)
    client.training_jobs.create.return_value = MagicMock(
        id="job_x", status="queued", base_model="Qwen/Qwen3-4B",
        dashboard_url=None, download_url=None, error=None, cost_usd=0.0,
    )
    f = _write_config(tmp_path, "train")
    result = runner.invoke(app, ["run", str(f)])
    assert result.exit_code == 0, result.stdout + result.stderr
    client.training_jobs.create.assert_called_once()
    client.deployments.create.assert_not_called()
    client.evals.create.assert_not_called()


def test_run_deploy_calls_deployments_create(tmp_path, monkeypatch):
    client = _stub_all(monkeypatch)
    client.deployments.create.return_value = MagicMock(
        id="dep_x", name="x", status="serving", model="job_abc",
        source="training_job", endpoint_url=None,
        gpu={"gpu_type": "A100-80GB", "gpu_count": 1}, provider=None,
        cost_per_hour_usd=1.0, total_cost_usd=0.0, total_requests=0, error=None,
    )
    f = _write_config(tmp_path, "deploy")
    result = runner.invoke(app, ["run", str(f)])
    assert result.exit_code == 0, result.stdout + result.stderr
    client.deployments.create.assert_called_once()


def test_run_eval_calls_evals_create(tmp_path, monkeypatch):
    client = _stub_all(monkeypatch)
    client.evals.create.return_value = MagicMock(
        id="eval_x", name="x", dataset_id="ds_abc",
        scorers=[{"type": "exact-match", "weight": 1.0}], created_at=None,
    )
    f = _write_config(tmp_path, "eval")
    result = runner.invoke(app, ["run", str(f)])
    assert result.exit_code == 0, result.stdout + result.stderr
    client.evals.create.assert_called_once()


def test_run_missing_kind_errors(tmp_path, monkeypatch):
    _stub_all(monkeypatch)
    f = tmp_path / "nokind.toml"
    f.write_text("[stuff]\nthing = 1\n")
    result = runner.invoke(app, ["run", str(f)])
    assert result.exit_code != 0
    combined = result.stdout + result.stderr
    assert "kind" in combined.lower()


def test_run_unknown_kind_errors(tmp_path, monkeypatch):
    _stub_all(monkeypatch)
    f = tmp_path / "bad.toml"
    f.write_text('kind = "bogus"\n')
    result = runner.invoke(app, ["run", str(f)])
    assert result.exit_code != 0


def test_run_no_args_shows_help():
    result = runner.invoke(app, ["run"])
    # Command with required arg missing → exit 2, usage printed.
    assert result.exit_code == 2
    combined = result.stdout + result.stderr
    assert "Usage" in combined or "Missing argument" in combined


def test_run_forwards_set_overrides(tmp_path, monkeypatch):
    client = _stub_all(monkeypatch)
    client.training_jobs.create.return_value = MagicMock(
        id="job_x", status="queued", base_model="Qwen/Qwen3-8B",
        dashboard_url=None, download_url=None, error=None, cost_usd=0.0,
    )
    f = _write_config(tmp_path, "train")
    result = runner.invoke(app, ["run", str(f), "--set", "model.base=Qwen/Qwen3-8B"])
    assert result.exit_code == 0, result.stdout
    _, kwargs = client.training_jobs.create.call_args
    assert kwargs["base_model"] == "Qwen/Qwen3-8B"
