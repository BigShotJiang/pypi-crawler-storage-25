"""Tests for veri_sdk.cli.commands.init — project scaffold."""

from __future__ import annotations

import tomlkit
from typer.testing import CliRunner

from veri_sdk.cli.main import app

runner = CliRunner()


def _expected_files() -> set[str]:
    return {
        "veri.toml",
        "reward.py",
        ".gitignore",
        "AGENTS.md",
        "CLAUDE.md",
        "configs/train.toml",
        "configs/deploy.toml",
        "configs/eval.toml",
        "datasets/README.md",
    }


def test_init_in_subdir(tmp_path):
    target = tmp_path / "my-project"
    result = runner.invoke(app, ["init", str(target)])
    assert result.exit_code == 0, result.stdout + result.stderr
    found = {str(p.relative_to(target)) for p in target.rglob("*") if p.is_file()}
    assert _expected_files() <= found


def test_init_in_cwd_when_no_name(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    result = runner.invoke(app, ["init"])
    assert result.exit_code == 0, result.stdout + result.stderr
    found = {str(p.relative_to(tmp_path)) for p in tmp_path.rglob("*") if p.is_file()}
    assert _expected_files() <= found


def test_init_errors_on_nonempty_target(tmp_path):
    (tmp_path / "stuff").mkdir()
    (tmp_path / "stuff" / "preexisting.txt").write_text("hi")
    result = runner.invoke(app, ["init", str(tmp_path / "stuff")])
    assert result.exit_code != 0
    combined = result.stdout + result.stderr
    assert "not empty" in combined.lower() or "exists" in combined.lower()


def test_init_force_overrides_nonempty(tmp_path):
    (tmp_path / "preexisting.txt").write_text("hi")
    result = runner.invoke(app, ["init", str(tmp_path), "--force"])
    assert result.exit_code == 0, result.stdout + result.stderr
    assert (tmp_path / "veri.toml").exists()
    # Existing file is preserved (we only add ours, don't wipe).
    assert (tmp_path / "preexisting.txt").exists()


def test_init_force_preserves_files_with_template_names(tmp_path):
    # Regression: --force used to silently overwrite files whose names
    # collided with template files (e.g. .gitignore, AGENTS.md).
    (tmp_path / "AGENTS.md").write_text("PRESERVE_ME")
    (tmp_path / ".gitignore").write_text("PRESERVE_ME_TOO")
    result = runner.invoke(app, ["init", str(tmp_path), "--force"])
    assert result.exit_code == 0, result.stdout + result.stderr
    assert (tmp_path / "AGENTS.md").read_text() == "PRESERVE_ME"
    assert (tmp_path / ".gitignore").read_text() == "PRESERVE_ME_TOO"
    # Sibling template files we didn't pre-create should still land.
    assert (tmp_path / "veri.toml").exists()
    assert "Skipped 2 files" in result.stdout


def test_generated_configs_have_correct_kind(tmp_path):
    target = tmp_path / "p"
    runner.invoke(app, ["init", str(target)])
    train = tomlkit.parse((target / "configs" / "train.toml").read_text()).unwrap()
    deploy = tomlkit.parse((target / "configs" / "deploy.toml").read_text()).unwrap()
    eval_ = tomlkit.parse((target / "configs" / "eval.toml").read_text()).unwrap()
    assert train["kind"] == "train"
    assert deploy["kind"] == "deploy"
    assert eval_["kind"] == "eval"


def test_claude_md_points_to_agents_md(tmp_path):
    target = tmp_path / "p"
    runner.invoke(app, ["init", str(target)])
    claude = (target / "CLAUDE.md").read_text()
    assert "AGENTS.md" in claude


def test_veri_toml_has_project_name(tmp_path):
    target = tmp_path / "my-project"
    runner.invoke(app, ["init", str(target)])
    veri_toml = tomlkit.parse((target / "veri.toml").read_text()).unwrap()
    assert veri_toml["project"]["name"] == "my-project"
