"""Tests for veri_sdk.cli.commands.evals."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock

from typer.testing import CliRunner

from veri_sdk.cli.commands import evals as ev_mod
from veri_sdk.cli.main import app

runner = CliRunner()


def _stub_client(monkeypatch) -> MagicMock:
    client = MagicMock()
    monkeypatch.setattr(ev_mod, "get_client", lambda: client)
    return client


def _make_eval(id_="eval_abc", name="my-eval"):
    e = MagicMock()
    e.id = id_
    e.name = name
    e.dataset_id = "ds_test"
    e.scorers = [{"type": "exact-match", "weight": 1.0}]
    e.created_at = "2026-05-12T00:00:00Z"
    return e


def _make_run(id_="run_abc", status="completed"):
    r = MagicMock()
    r.id = id_
    r.eval_id = "eval_abc"
    r.model = "my-model"
    r.status = status
    r.processed_items = 100
    r.total_items = 100
    r.results = {"score": 0.85}
    r.error_message = None
    r.created_at = "2026-05-12T00:00:00Z"
    r.completed_at = "2026-05-12T00:01:00Z"
    return r


def _eval_toml(tmp_path: Path, kind: str = "eval") -> Path:
    f = tmp_path / "eval.toml"
    f.write_text(f"""\
kind = "{kind}"
[eval]
name = "first-eval"
dataset_id = "ds_test"

[[scorers]]
type = "exact-match"
weight = 1.0

[run]
model = "dep_abc"
num_samples = 100
""")
    return f


def test_create_from_config(tmp_path, monkeypatch):
    client = _stub_client(monkeypatch)
    client.evals.create.return_value = _make_eval()
    f = _eval_toml(tmp_path)
    result = runner.invoke(app, ["evals", "create", str(f)])
    assert result.exit_code == 0, result.stdout + result.stderr
    _, kwargs = client.evals.create.call_args
    assert kwargs["name"] == "first-eval"
    assert kwargs["dataset_id"] == "ds_test"
    assert kwargs["scorers"] == [{"type": "exact-match", "weight": 1.0}]


def test_create_wrong_kind_rejected(tmp_path, monkeypatch):
    client = _stub_client(monkeypatch)
    f = _eval_toml(tmp_path, kind="train")
    result = runner.invoke(app, ["evals", "create", str(f)])
    assert result.exit_code != 0
    client.evals.create.assert_not_called()


def test_create_quick_inline(monkeypatch):
    client = _stub_client(monkeypatch)
    client.evals.create.return_value = _make_eval()
    result = runner.invoke(
        app,
        [
            "evals",
            "create",
            "--quick",
            "--dataset",
            "ds_test",
            "--model",
            "my-model",
            "--name",
            "q-eval",
        ],
    )
    assert result.exit_code == 0, result.stdout
    _, kwargs = client.evals.create.call_args
    assert kwargs["dataset_id"] == "ds_test"
    # Default scorer is exact-match.
    assert kwargs["scorers"][0]["type"] == "exact-match"


def test_create_quick_requires_dataset_and_model():
    result = runner.invoke(app, ["evals", "create", "--quick", "--name", "x"])
    assert result.exit_code != 0


def test_list(monkeypatch):
    client = _stub_client(monkeypatch)
    client.evals.list.return_value = [_make_eval(id_="eval_a"), _make_eval(id_="eval_b")]
    result = runner.invoke(app, ["evals", "list", "--format", "json"])
    assert result.exit_code == 0
    rows = json.loads(result.stdout)
    assert {r["id"] for r in rows} == {"eval_a", "eval_b"}


def test_get(monkeypatch):
    client = _stub_client(monkeypatch)
    client.evals.get.return_value = _make_eval(id_="eval_xyz")
    result = runner.invoke(app, ["evals", "get", "eval_xyz", "--format", "json"])
    assert result.exit_code == 0
    assert json.loads(result.stdout)["id"] == "eval_xyz"


def test_delete(monkeypatch):
    client = _stub_client(monkeypatch)
    result = runner.invoke(app, ["evals", "delete", "eval_xyz"])
    assert result.exit_code == 0
    client.evals.delete.assert_called_once_with("eval_xyz")


def test_runs_list(monkeypatch):
    client = _stub_client(monkeypatch)
    client.evals.runs.list.return_value = [_make_run(id_="run_a"), _make_run(id_="run_b")]
    result = runner.invoke(app, ["evals", "runs", "list", "eval_abc", "--format", "json"])
    assert result.exit_code == 0
    rows = json.loads(result.stdout)
    assert {r["id"] for r in rows} == {"run_a", "run_b"}


def test_runs_get(monkeypatch):
    client = _stub_client(monkeypatch)
    client.evals.runs.get.return_value = _make_run(id_="run_xyz")
    result = runner.invoke(
        app,
        ["evals", "runs", "get", "eval_abc", "run_xyz", "--format", "json"],
    )
    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["id"] == "run_xyz"


def test_runs_items(monkeypatch):
    client = _stub_client(monkeypatch)
    item = MagicMock()
    item.id = "item_1"
    item.run_id = "run_xyz"
    item.item_index = 0
    item.input = "hello"
    item.output = "hi"
    item.label = "hi"
    item.scores = {"exact_match": 1.0}
    item.latency_ms = 150
    client.evals.runs.items.return_value = [item]
    result = runner.invoke(
        app,
        ["evals", "runs", "items", "eval_abc", "run_xyz", "--format", "json"],
    )
    assert result.exit_code == 0
    rows = json.loads(result.stdout)
    assert rows[0]["id"] == "item_1"
    assert rows[0]["scores"]["exact_match"] == 1.0
