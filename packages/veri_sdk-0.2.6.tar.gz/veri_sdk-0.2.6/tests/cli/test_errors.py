"""Tests for veri_sdk.cli.utils.errors — suggestion helper + exit codes."""

from __future__ import annotations

import pytest
import typer

from veri_sdk.cli.utils.errors import (
    EXIT_API_ERROR,
    EXIT_AUTH_ERROR,
    EXIT_USER_ERROR,
    fail,
    suggest,
)


def test_suggest_finds_close_match():
    ids = ["job_abc", "job_def", "job_ghi"]
    assert suggest("job_abx", ids) == "job_abc"


def test_suggest_returns_none_when_nothing_close():
    ids = ["job_abc", "job_def"]
    assert suggest("xyz_completely_different", ids) is None


def test_suggest_respects_cutoff():
    ids = ["abc"]
    assert suggest("xyz", ids, cutoff=0.95) is None


def test_fail_raises_with_correct_code():
    with pytest.raises(typer.Exit) as exc:
        fail("bad input", code=EXIT_USER_ERROR)
    assert exc.value.exit_code == EXIT_USER_ERROR


def test_fail_auth_uses_code_4():
    with pytest.raises(typer.Exit) as exc:
        fail("not logged in", code=EXIT_AUTH_ERROR)
    assert exc.value.exit_code == EXIT_AUTH_ERROR


def test_fail_api_uses_code_2():
    with pytest.raises(typer.Exit) as exc:
        fail("server 500", code=EXIT_API_ERROR)
    assert exc.value.exit_code == EXIT_API_ERROR


def test_fail_writes_to_stderr(capsys):
    with pytest.raises(typer.Exit):
        fail("oh no", code=1)
    captured = capsys.readouterr()
    assert "oh no" in captured.err
    assert captured.out == ""
