"""Tests for veri_sdk.cli.commands.volumes — CLI sub-app + SDK plumbing.

Pattern mirrors tests/cli/test_datasets.py: stub get_client() with a MagicMock
and exercise each subcommand via Typer's CliRunner.
"""
from __future__ import annotations

import json
from unittest.mock import MagicMock

from typer.testing import CliRunner

from veri_sdk.cli.commands import volumes as vol_mod
from veri_sdk.cli.main import app
from veri_sdk.cli.utils import display

runner = CliRunner()


def _stub_client(monkeypatch) -> MagicMock:
    client = MagicMock()
    monkeypatch.setattr(vol_mod, "get_client", lambda: client)
    return client


def _make_volume(
    id_="vol_abc",
    name="my-data",
    total_bytes=0,
    file_count=0,
    updated_at="2026-05-14T00:00:00Z",
):
    v = MagicMock()
    v.id = id_
    v.name = name
    v.total_bytes = total_bytes
    v.file_count = file_count
    v.updated_at = updated_at
    return v


def _make_file(path="/a.txt", size_bytes=42, modified_at="2026-05-14T00:00:00Z"):
    f = MagicMock()
    f.path = path
    f.size_bytes = size_bytes
    f.modified_at = modified_at
    return f


# ---------- format_bytes helper ----------


def test_format_bytes_humanizes_sizes():
    """Inline coverage of the helper since other CLI tests rely on it."""
    assert display.format_bytes(0) == "0 B"
    assert display.format_bytes(1023) == "1023 B"
    assert display.format_bytes(1024) == "1.0 KiB"
    assert display.format_bytes(1024 * 1024) == "1.0 MiB"
    assert display.format_bytes(1_500_000_000) == "1.4 GiB"


# ---------- create ----------


def test_create_calls_client(monkeypatch):
    client = _stub_client(monkeypatch)
    client.volumes.create.return_value = _make_volume(id_="vol_xyz", name="my-data")
    result = runner.invoke(app, ["volumes", "create", "my-data"])
    assert result.exit_code == 0, result.stdout
    client.volumes.create.assert_called_once_with("my-data")


def test_create_quiet_emits_only_id(monkeypatch):
    client = _stub_client(monkeypatch)
    client.volumes.create.return_value = _make_volume(id_="vol_z")
    result = runner.invoke(app, ["volumes", "create", "n", "--quiet"])
    assert result.exit_code == 0
    assert result.stdout.strip() == "vol_z"


# ---------- list / get ----------


def test_list_renders_rows(monkeypatch):
    client = _stub_client(monkeypatch)
    client.volumes.list.return_value = [
        _make_volume(id_="vol_a", name="alpha", total_bytes=2048, file_count=3),
        _make_volume(id_="vol_b", name="beta"),
    ]
    result = runner.invoke(app, ["volumes", "list", "--format", "json"])
    assert result.exit_code == 0, result.stdout
    rows = json.loads(result.stdout)
    assert {r["name"] for r in rows} == {"alpha", "beta"}
    # format_bytes is applied for the rendered size column.
    alpha = next(r for r in rows if r["name"] == "alpha")
    assert alpha["size"] == "2.0 KiB"
    assert alpha["files"] == 3


def test_get_renders_single(monkeypatch):
    client = _stub_client(monkeypatch)
    client.volumes.get.return_value = _make_volume(
        id_="vol_z", name="z", total_bytes=10 * 1024 * 1024, file_count=2
    )
    result = runner.invoke(app, ["volumes", "get", "z", "--format", "json"])
    assert result.exit_code == 0
    row = json.loads(result.stdout)
    assert row["id"] == "vol_z"
    assert row["size"] == "10.0 MiB"


# ---------- delete confirmation ----------


def test_delete_with_yes_skips_prompt(monkeypatch):
    client = _stub_client(monkeypatch)
    client.volumes.get.return_value = _make_volume(name="trash", file_count=5)
    result = runner.invoke(app, ["volumes", "delete", "trash", "--yes"])
    assert result.exit_code == 0, result.stdout
    client.volumes.delete.assert_called_once_with("trash")


def test_delete_requires_typed_name(monkeypatch):
    """Mismatched confirmation → user error, no delete call."""
    client = _stub_client(monkeypatch)
    client.volumes.get.return_value = _make_volume(name="careful", file_count=10)
    # Typer prompts on stdin; supply the wrong name.
    result = runner.invoke(app, ["volumes", "delete", "careful"], input="wrong\n")
    assert result.exit_code != 0
    client.volumes.delete.assert_not_called()


def test_delete_with_matching_prompt_proceeds(monkeypatch):
    client = _stub_client(monkeypatch)
    client.volumes.get.return_value = _make_volume(name="okdelete", file_count=0)
    result = runner.invoke(app, ["volumes", "delete", "okdelete"], input="okdelete\n")
    assert result.exit_code == 0, result.stdout
    client.volumes.delete.assert_called_once_with("okdelete")


# ---------- upload ----------


def test_upload_calls_upload_file(monkeypatch, tmp_path):
    client = _stub_client(monkeypatch)
    vol = _make_volume(name="my-data")
    client.volumes.get.return_value = vol
    local = tmp_path / "data.jsonl"
    local.write_bytes(b'{"a":1}\n')

    result = runner.invoke(app, ["volumes", "upload", "my-data", str(local)])
    assert result.exit_code == 0, result.stdout
    vol.upload_file.assert_called_once()
    args, _ = vol.upload_file.call_args
    assert args[0] == str(local)
    # Default remote = /<filename>.
    assert args[1] == "/data.jsonl"


def test_upload_with_to_flag(monkeypatch, tmp_path):
    client = _stub_client(monkeypatch)
    vol = _make_volume(name="my-data")
    client.volumes.get.return_value = vol
    local = tmp_path / "x.bin"
    local.write_bytes(b"x")

    result = runner.invoke(
        app, ["volumes", "upload", "my-data", str(local), "--to", "/nested/y.bin"]
    )
    assert result.exit_code == 0, result.stdout
    args, _ = vol.upload_file.call_args
    assert args[1] == "/nested/y.bin"


def test_upload_dir_calls_upload_dir(monkeypatch, tmp_path):
    client = _stub_client(monkeypatch)
    vol = _make_volume(name="my-data")
    client.volumes.get.return_value = vol
    (tmp_path / "a.txt").write_bytes(b"a")

    result = runner.invoke(
        app, ["volumes", "upload-dir", "my-data", str(tmp_path), "--to", "/data"]
    )
    assert result.exit_code == 0, result.stdout
    vol.upload_dir.assert_called_once()
    args, kwargs = vol.upload_dir.call_args
    assert args[0] == str(tmp_path)
    assert kwargs["remote"] == "/data"
    # Progress bar wired: callback passed even when the stub doesn't render.
    assert "progress_callback" in kwargs


def test_upload_wires_progress_callback(monkeypatch, tmp_path):
    """upload passes a progress_callback so the SDK can drive rich.progress.

    The CLI stubs upload_file but we still verify the kwarg is there — that's
    the contract between the CLI and the SDK from VS-226's progress addition.
    """
    client = _stub_client(monkeypatch)
    vol = _make_volume(name="my-data")
    client.volumes.get.return_value = vol
    local = tmp_path / "data.jsonl"
    local.write_bytes(b'{"a":1}\n')

    result = runner.invoke(app, ["volumes", "upload", "my-data", str(local)])
    assert result.exit_code == 0, result.stdout
    _, kwargs = vol.upload_file.call_args
    assert "progress_callback" in kwargs
    # Sanity: callback is callable.
    assert callable(kwargs["progress_callback"])


def test_upload_skips_progress_bar_under_quiet(monkeypatch, tmp_path):
    """--quiet should suppress the progress bar (no callback passed)."""
    client = _stub_client(monkeypatch)
    vol = _make_volume(name="my-data")
    client.volumes.get.return_value = vol
    local = tmp_path / "data.jsonl"
    local.write_bytes(b'{"a":1}\n')

    result = runner.invoke(app, ["volumes", "upload", "my-data", str(local), "--quiet"])
    assert result.exit_code == 0, result.stdout
    _, kwargs = vol.upload_file.call_args
    # No callback under --quiet — SDK is invoked plainly.
    assert "progress_callback" not in kwargs or kwargs["progress_callback"] is None


# ---------- ls / rm ----------


def test_ls_renders_files(monkeypatch):
    client = _stub_client(monkeypatch)
    vol = _make_volume(name="my-data")
    vol.list_files.return_value = [
        _make_file(path="/a.txt", size_bytes=12),
        _make_file(path="/nested/b.txt", size_bytes=2048),
    ]
    client.volumes.get.return_value = vol

    result = runner.invoke(app, ["volumes", "ls", "my-data", "--format", "json"])
    assert result.exit_code == 0, result.stdout
    rows = json.loads(result.stdout)
    assert {r["path"] for r in rows} == {"/a.txt", "/nested/b.txt"}
    sizes = {r["path"]: r["size"] for r in rows}
    assert sizes["/nested/b.txt"] == "2.0 KiB"


def test_rm_calls_delete_http(monkeypatch):
    client = _stub_client(monkeypatch)
    # rm uses client._http.delete directly.
    resp = MagicMock()
    resp.is_success = True
    resp.status_code = 204
    client._http.delete.return_value = resp

    result = runner.invoke(app, ["volumes", "rm", "my-data", "a.txt"])
    assert result.exit_code == 0, result.stdout
    client._http.delete.assert_called_once_with("/v1/volumes/my-data/files/a.txt")


# ---------- group help ----------


def test_volumes_group_no_args_shows_help():
    result = runner.invoke(app, ["volumes"])
    assert result.exit_code in (0, 2)
    combined = result.stdout + result.stderr
    assert "create" in combined
    assert "upload" in combined
    assert "delete" in combined
