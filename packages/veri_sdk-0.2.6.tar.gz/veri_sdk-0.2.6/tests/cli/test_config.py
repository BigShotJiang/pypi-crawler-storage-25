"""Tests for veri_sdk.cli.utils.config — XDG path resolution and legacy migration."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from veri_sdk.cli.utils import config


def test_env_var_overrides_config_path(tmp_path, monkeypatch):
    target = tmp_path / "custom.toml"
    monkeypatch.setenv("VERI_CONFIG_PATH", str(target))
    assert config.config_path() == target


def test_load_returns_empty_when_no_config(tmp_path, monkeypatch):
    monkeypatch.setenv("VERI_CONFIG_PATH", str(tmp_path / "nope.toml"))
    monkeypatch.delenv("VERI_API_KEY", raising=False)
    profile = config.load()
    # Default api_url is filled in even when nothing else is set.
    assert profile == {"api_url": config.DEFAULT_API_URL}


def test_save_then_load_roundtrip(tmp_path, monkeypatch):
    monkeypatch.setenv("VERI_CONFIG_PATH", str(tmp_path / "config.toml"))
    monkeypatch.delenv("VERI_API_KEY", raising=False)
    monkeypatch.delenv("VERI_API_URL", raising=False)

    config.save(api_key="vk_test_abc", api_url="http://localhost:8000")
    profile = config.load()
    assert profile["api_key"] == "vk_test_abc"
    assert profile["api_url"] == "http://localhost:8000"


def test_env_vars_override_file(tmp_path, monkeypatch):
    monkeypatch.setenv("VERI_CONFIG_PATH", str(tmp_path / "config.toml"))
    config.save(api_key="vk_file", api_url="http://from-file")
    monkeypatch.setenv("VERI_API_KEY", "vk_env_wins")
    monkeypatch.setenv("VERI_API_URL", "http://from-env")
    profile = config.load()
    assert profile["api_key"] == "vk_env_wins"
    assert profile["api_url"] == "http://from-env"


def test_clear_removes_file(tmp_path, monkeypatch):
    monkeypatch.setenv("VERI_CONFIG_PATH", str(tmp_path / "config.toml"))
    config.save(api_key="vk_x")
    assert config.clear() is True
    assert config.clear() is False  # idempotent
    assert not config.config_path().exists()


def test_no_auto_migration_when_custom_config_path(tmp_path, monkeypatch):
    """Custom VERI_CONFIG_PATH must NOT touch ~/.veri/credentials.json — that
    file may be the user's real credentials. Migration only runs when writing
    to the default XDG path."""
    monkeypatch.setenv("VERI_CONFIG_PATH", str(tmp_path / "custom.toml"))
    # Pretend a legacy file exists.
    legacy = tmp_path / "fake_legacy"
    monkeypatch.setattr(config, "legacy_path", lambda: legacy)
    legacy.write_text(json.dumps({"api_key": "vk_legacy", "api_url": "http://legacy"}))

    profile = config.load()
    # Custom path is empty; legacy file untouched.
    assert "api_key" not in profile
    assert legacy.exists(), "legacy file must not be renamed when VERI_CONFIG_PATH is set"


def test_auto_migration_when_default_path(tmp_path, monkeypatch):
    """When config_path is the default XDG path AND legacy file exists, migrate."""
    monkeypatch.delenv("VERI_CONFIG_PATH", raising=False)
    monkeypatch.delenv("XDG_CONFIG_HOME", raising=False)
    monkeypatch.delenv("VERI_API_KEY", raising=False)
    monkeypatch.delenv("VERI_API_URL", raising=False)

    # Redirect both the legacy path and the destination into tmp_path.
    legacy = tmp_path / "veri" / "credentials.json"
    legacy.parent.mkdir(parents=True)
    legacy.write_text(json.dumps({"api_key": "vk_legacy", "api_url": "http://legacy"}))
    monkeypatch.setattr(config, "legacy_path", lambda: legacy)
    dest = tmp_path / "config.toml"
    monkeypatch.setattr(config, "config_path", lambda: dest)
    # _config_path_is_default returns True because no env vars are set.
    monkeypatch.setattr(config, "_config_path_is_default", lambda: True)

    profile = config.load()
    assert profile["api_key"] == "vk_legacy"
    assert profile["api_url"] == "http://legacy"
    assert dest.exists()
    assert not legacy.exists(), "legacy file should be renamed to .bak"
    assert legacy.with_suffix(".json.bak").exists()
