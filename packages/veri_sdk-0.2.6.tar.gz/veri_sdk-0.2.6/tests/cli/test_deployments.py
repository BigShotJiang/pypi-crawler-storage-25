"""Tests for veri_sdk.cli.commands.deployments."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock

from typer.testing import CliRunner

from veri_sdk.cli.commands import deployments as dep_mod
from veri_sdk.cli.main import app

runner = CliRunner()


def _stub_client(monkeypatch) -> MagicMock:
    client = MagicMock()
    monkeypatch.setattr(dep_mod, "get_client", lambda: client)
    return client


def _make_deploy(id_="dep_abc", status="serving"):
    d = MagicMock()
    d.id = id_
    d.status = status
    d.name = "my-endpoint"
    d.model = "job_xyz"
    d.source = "training_job"
    d.endpoint_url = f"https://api/{id_}"
    d.gpu = {"gpu_type": "A100-80GB", "gpu_count": 1}
    d.provider = None
    d.cost_per_hour_usd = 1.0
    d.total_cost_usd = 5.0
    d.total_requests = 10
    d.error = None
    return d


def _deploy_toml(tmp_path: Path, kind: str = "deploy") -> Path:
    f = tmp_path / "deploy.toml"
    f.write_text(f"""\
kind = "{kind}"
[deployment]
name = "my-endpoint"
model = "job_xyz"
source = "training_job"
[resources]
gpu_type = "A100-80GB"
gpu_count = 1
""")
    return f


def test_create_from_config(tmp_path, monkeypatch):
    client = _stub_client(monkeypatch)
    client.deployments.create.return_value = _make_deploy()
    f = _deploy_toml(tmp_path)

    result = runner.invoke(app, ["deployments", "create", str(f)])
    assert result.exit_code == 0, result.stdout + result.stderr
    _, kwargs = client.deployments.create.call_args
    assert kwargs["model"] == "job_xyz"
    assert kwargs["name"] == "my-endpoint"
    assert kwargs["gpu"] == {"gpu_type": "A100-80GB", "gpu_count": 1}


def test_create_wrong_kind_rejected(tmp_path, monkeypatch):
    client = _stub_client(monkeypatch)
    f = _deploy_toml(tmp_path, kind="train")
    result = runner.invoke(app, ["deployments", "create", str(f)])
    assert result.exit_code != 0
    client.deployments.create.assert_not_called()


def test_create_inline_from_training_job(monkeypatch):
    client = _stub_client(monkeypatch)
    client.deployments.create.return_value = _make_deploy()
    result = runner.invoke(
        app,
        [
            "deployments",
            "create",
            "--model",
            "job_xyz",
            "--name",
            "quick",
            "--gpu-type",
            "A100-80GB",
            "--gpu-count",
            "1",
        ],
    )
    assert result.exit_code == 0, result.stdout
    _, kwargs = client.deployments.create.call_args
    assert kwargs["model"] == "job_xyz"
    assert kwargs["source"] == "training_job"


def test_create_inline_from_hf(monkeypatch):
    client = _stub_client(monkeypatch)
    client.deployments.create.return_value = _make_deploy()
    runner.invoke(
        app,
        [
            "deployments",
            "create",
            "--from-hf",
            "Qwen/Qwen3-4B",
            "--name",
            "hf-quick",
            "--gpu-type",
            "A100-80GB",
        ],
    )
    _, kwargs = client.deployments.create.call_args
    assert kwargs["model"] == "Qwen/Qwen3-4B"
    assert kwargs["source"] == "huggingface"


def test_list(monkeypatch):
    client = _stub_client(monkeypatch)
    client.deployments.list.return_value = [_make_deploy(id_="dep_a"), _make_deploy(id_="dep_b")]
    result = runner.invoke(app, ["deployments", "list", "--format", "json"])
    assert result.exit_code == 0
    rows = json.loads(result.stdout)
    assert {r["id"] for r in rows} == {"dep_a", "dep_b"}


def test_get(monkeypatch):
    client = _stub_client(monkeypatch)
    client.deployments.get.return_value = _make_deploy(id_="dep_xyz")
    result = runner.invoke(app, ["deployments", "get", "dep_xyz", "--format", "json"])
    assert result.exit_code == 0
    assert json.loads(result.stdout)["id"] == "dep_xyz"


def test_stop(monkeypatch):
    client = _stub_client(monkeypatch)
    client.deployments.stop.return_value = _make_deploy(id_="dep_xyz", status="stopped")
    result = runner.invoke(app, ["deployments", "stop", "dep_xyz"])
    assert result.exit_code == 0
    client.deployments.stop.assert_called_once_with("dep_xyz")


def test_chat_oneshot(monkeypatch):
    client = _stub_client(monkeypatch)
    client.deployments.chat.return_value = {
        "choices": [{"message": {"content": "hi back"}}]
    }
    result = runner.invoke(
        app,
        ["deployments", "chat", "dep_xyz", "--message", "hello", "--model", "my-model"],
    )
    assert result.exit_code == 0
    _, kwargs = client.deployments.chat.call_args
    assert kwargs["messages"] == [{"role": "user", "content": "hello"}]
    assert "hi back" in result.stdout


def test_metrics(monkeypatch):
    client = _stub_client(monkeypatch)
    client.deployments.metrics.return_value = {"rps": 10.0, "p50_latency_ms": 200}
    result = runner.invoke(app, ["deployments", "metrics", "dep_xyz", "--format", "json"])
    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["rps"] == 10.0


def test_requests(monkeypatch):
    client = _stub_client(monkeypatch)
    client.deployments.requests.return_value = [
        {"id": "req_1", "status_code": 200, "latency_ms": 150},
        {"id": "req_2", "status_code": 200, "latency_ms": 180},
    ]
    result = runner.invoke(app, ["deployments", "requests", "dep_xyz", "--format", "json"])
    assert result.exit_code == 0
    rows = json.loads(result.stdout)
    assert {r["id"] for r in rows} == {"req_1", "req_2"}
