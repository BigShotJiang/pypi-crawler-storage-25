"""Tests for veri_sdk.cli.commands.auth — login flow modes."""

from __future__ import annotations

from typer.testing import CliRunner

from veri_sdk.cli.commands import auth as auth_mod
from veri_sdk.cli.main import app

runner = CliRunner()


def test_login_with_token_skips_browser(monkeypatch, tmp_path):
    """`--token vk_...` writes config directly; no browser, no prompt."""
    monkeypatch.setenv("VERI_CONFIG_PATH", str(tmp_path / "config.toml"))
    monkeypatch.delenv("VERI_API_KEY", raising=False)
    # If anything tries to open a browser or call the listener, fail loudly.
    monkeypatch.setattr(auth_mod.bl, "browser_login", lambda *a, **k: (_ for _ in ()).throw(AssertionError("should not run")))
    monkeypatch.setattr(auth_mod.webbrowser, "open", lambda url: (_ for _ in ()).throw(AssertionError("should not open browser")))
    # Verification call: pretend the API is offline so login still completes.
    monkeypatch.setattr(auth_mod.httpx, "get", lambda *a, **k: (_ for _ in ()).throw(auth_mod.httpx.HTTPError("offline")))

    result = runner.invoke(app, ["login", "--token", "vk_test_abc"])
    assert result.exit_code == 0, result.stdout + result.stderr
    saved = (tmp_path / "config.toml").read_text()
    assert "vk_test_abc" in saved


def test_login_default_uses_browser_flow(monkeypatch, tmp_path):
    """Default `veri login` runs the browser-login helper."""
    monkeypatch.setenv("VERI_CONFIG_PATH", str(tmp_path / "config.toml"))
    monkeypatch.delenv("VERI_API_KEY", raising=False)
    calls = {"n": 0}

    def fake_browser_login(api_url, **kw):
        calls["n"] += 1
        return "vk_browser_captured"

    monkeypatch.setattr(auth_mod.bl, "browser_login", fake_browser_login)
    monkeypatch.setattr(
        auth_mod.httpx, "get",
        lambda *a, **k: (_ for _ in ()).throw(auth_mod.httpx.HTTPError("offline")),
    )

    result = runner.invoke(app, ["login"])
    assert result.exit_code == 0, result.stdout + result.stderr
    assert calls["n"] == 1
    assert "vk_browser_captured" in (tmp_path / "config.toml").read_text()


def test_login_browser_timeout_falls_back_to_paste(monkeypatch, tmp_path):
    """On TimeoutError from the listener, drop to paste prompt."""
    monkeypatch.setenv("VERI_CONFIG_PATH", str(tmp_path / "config.toml"))
    monkeypatch.delenv("VERI_API_KEY", raising=False)

    def timing_out(*_a, **_kw):
        raise TimeoutError("timed out")

    monkeypatch.setattr(auth_mod.bl, "browser_login", timing_out)
    monkeypatch.setattr(
        auth_mod.httpx, "get",
        lambda *a, **k: (_ for _ in ()).throw(auth_mod.httpx.HTTPError("offline")),
    )

    # Provide pasted token via stdin.
    result = runner.invoke(app, ["login"], input="vk_pasted_fallback\n")
    assert result.exit_code == 0, result.stdout + result.stderr
    assert "vk_pasted_fallback" in (tmp_path / "config.toml").read_text()


def test_login_paste_flag_skips_browser_login(monkeypatch, tmp_path):
    """`--paste` uses the legacy paste flow; never calls browser_login()."""
    monkeypatch.setenv("VERI_CONFIG_PATH", str(tmp_path / "config.toml"))
    monkeypatch.delenv("VERI_API_KEY", raising=False)
    monkeypatch.setattr(
        auth_mod.bl, "browser_login",
        lambda *a, **k: (_ for _ in ()).throw(AssertionError("paste mode shouldn't call browser_login")),
    )
    monkeypatch.setattr(auth_mod.webbrowser, "open", lambda url: True)
    monkeypatch.setattr(
        auth_mod.httpx, "get",
        lambda *a, **k: (_ for _ in ()).throw(auth_mod.httpx.HTTPError("offline")),
    )

    result = runner.invoke(app, ["login", "--paste"], input="vk_paste_only\n")
    assert result.exit_code == 0
    assert "vk_paste_only" in (tmp_path / "config.toml").read_text()


def test_login_no_browser_implies_paste(monkeypatch, tmp_path):
    """`--no-browser` skips webbrowser.open AND the browser-login listener."""
    monkeypatch.setenv("VERI_CONFIG_PATH", str(tmp_path / "config.toml"))
    monkeypatch.delenv("VERI_API_KEY", raising=False)

    monkeypatch.setattr(
        auth_mod.bl, "browser_login",
        lambda *a, **k: (_ for _ in ()).throw(AssertionError("should not call")),
    )

    def fail_browser(url):
        raise AssertionError("should not open browser")

    monkeypatch.setattr(auth_mod.webbrowser, "open", fail_browser)
    monkeypatch.setattr(
        auth_mod.httpx, "get",
        lambda *a, **k: (_ for _ in ()).throw(auth_mod.httpx.HTTPError("offline")),
    )

    result = runner.invoke(app, ["login", "--no-browser"], input="vk_headless\n")
    assert result.exit_code == 0
    assert "vk_headless" in (tmp_path / "config.toml").read_text()


def test_login_rejects_non_vk_prefix(monkeypatch, tmp_path):
    """Pasted/captured tokens missing the vk_ prefix must error out."""
    monkeypatch.setenv("VERI_CONFIG_PATH", str(tmp_path / "config.toml"))
    monkeypatch.delenv("VERI_API_KEY", raising=False)

    result = runner.invoke(app, ["login", "--token", "bogus"])
    assert result.exit_code != 0
    assert "vk_" in (result.stdout + result.stderr)
