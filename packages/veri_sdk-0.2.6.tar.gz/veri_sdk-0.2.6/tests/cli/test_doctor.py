"""Tests for veri_sdk.cli.commands.doctor — diagnostic checks."""

from __future__ import annotations

from importlib.metadata import version as _pkg_version

from typer.testing import CliRunner

from veri_sdk.cli.commands import doctor as doctor_mod
from veri_sdk.cli.main import app

runner = CliRunner()

_SDK_VERSION = _pkg_version("veri-sdk")


def test_version_prints_sdk_version():
    result = runner.invoke(app, ["version"])
    assert result.exit_code == 0
    # Should mention veri-sdk version + python version.
    assert _SDK_VERSION in result.stdout
    assert "python" in result.stdout.lower()


def test_version_json_format():
    result = runner.invoke(app, ["version", "--format", "json"])
    assert result.exit_code == 0
    import json
    payload = json.loads(result.stdout)
    assert payload["sdk_version"] == _SDK_VERSION
    assert "python_version" in payload
    assert "platform" in payload


def test_doctor_passes_when_everything_healthy(monkeypatch, tmp_path):
    """All checks return OK → exit 0, every check shows pass status."""
    cfg = tmp_path / "config.toml"
    monkeypatch.setenv("VERI_CONFIG_PATH", str(cfg))
    monkeypatch.setenv("VERI_API_KEY", "vk_test")
    # Skip the live network check.
    monkeypatch.setattr(doctor_mod, "_check_network", lambda url: ("pass", "200 OK"))

    result = runner.invoke(app, ["doctor"])
    assert result.exit_code == 0


def test_doctor_reports_missing_credentials(monkeypatch, tmp_path):
    monkeypatch.setenv("VERI_CONFIG_PATH", str(tmp_path / "absent.toml"))
    monkeypatch.delenv("VERI_API_KEY", raising=False)
    monkeypatch.setattr(doctor_mod, "_check_network", lambda url: ("pass", "200 OK"))

    result = runner.invoke(app, ["doctor"])
    # Doctor itself doesn't fail-exit on issues — it reports them. Exit 0 is fine;
    # we look for the issue in output.
    assert result.exit_code == 0
    assert "credentials" in result.stdout.lower() or "not logged in" in result.stdout.lower()


def test_doctor_json_emits_check_list(monkeypatch, tmp_path):
    monkeypatch.setenv("VERI_CONFIG_PATH", str(tmp_path / "config.toml"))
    monkeypatch.setenv("VERI_API_KEY", "vk_test")
    monkeypatch.setattr(doctor_mod, "_check_network", lambda url: ("pass", "ok"))

    result = runner.invoke(app, ["doctor", "--format", "json"])
    assert result.exit_code == 0
    import json
    rows = json.loads(result.stdout)
    assert isinstance(rows, list)
    # Expect a check for each of: python, sdk, config, credentials, network.
    check_names = {row["check"] for row in rows}
    assert {"python", "sdk", "config", "credentials", "network"} <= check_names


def test_doctor_network_failure_reported(monkeypatch, tmp_path):
    monkeypatch.setenv("VERI_CONFIG_PATH", str(tmp_path / "config.toml"))
    monkeypatch.setenv("VERI_API_KEY", "vk_test")
    monkeypatch.setattr(doctor_mod, "_check_network", lambda url: ("fail", "connection refused"))

    result = runner.invoke(app, ["doctor", "--format", "json"])
    assert result.exit_code == 0
    import json
    rows = json.loads(result.stdout)
    network = next(r for r in rows if r["check"] == "network")
    assert network["status"] == "fail"
