"""Tests for gpu / cost / billing CLI groups."""

from __future__ import annotations

import json
from unittest.mock import MagicMock

from typer.testing import CliRunner

from veri_sdk.cli.commands import billing as billing_mod
from veri_sdk.cli.commands import cost as cost_mod
from veri_sdk.cli.commands import gpu as gpu_mod
from veri_sdk.cli.main import app

runner = CliRunner()


def _stub_all(monkeypatch) -> MagicMock:
    client = MagicMock()
    for mod in (gpu_mod, cost_mod, billing_mod):
        monkeypatch.setattr(mod, "get_client", lambda c=client: c)
    return client


# ---------- gpu ----------

def test_gpu_list(monkeypatch):
    client = _stub_all(monkeypatch)
    client.cost.rates.return_value = {
        "rates": [
            {"gpu_type": "A100-80GB", "provider": "primeintellect", "usd_per_hour": 1.5},
            {"gpu_type": "H100", "provider": "primeintellect", "usd_per_hour": 3.0},
        ]
    }
    result = runner.invoke(app, ["gpu", "list", "--format", "json"])
    assert result.exit_code == 0, result.stdout
    rows = json.loads(result.stdout)
    assert any(r["gpu_type"] == "A100-80GB" for r in rows)


def test_gpu_compare(monkeypatch):
    client = _stub_all(monkeypatch)
    client.cost.compare.return_value = {
        "providers": [{"name": "p1", "usd": 1.5}, {"name": "p2", "usd": 2.0}]
    }
    result = runner.invoke(
        app,
        ["gpu", "compare", "--type", "A100-80GB", "--count", "2", "--hours", "4", "--format", "json"],
    )
    assert result.exit_code == 0, result.stdout
    client.cost.compare.assert_called_once()
    _, kwargs = client.cost.compare.call_args
    assert kwargs["gpu_type"] == "A100-80GB"
    assert kwargs["gpu_count"] == 2
    assert kwargs["duration_minutes"] == 240


# ---------- cost ----------

def test_cost_estimate(monkeypatch):
    client = _stub_all(monkeypatch)
    client.cost.estimate.return_value = {"estimated_cost_usd": 6.0, "duration_minutes": 60}
    result = runner.invoke(
        app,
        ["cost", "estimate", "--gpu-type", "A100-80GB", "--gpu-count", "2", "--hours", "1", "--format", "json"],
    )
    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["estimated_cost_usd"] == 6.0
    _, kwargs = client.cost.estimate.call_args
    assert kwargs["gpu_type"] == "A100-80GB"
    assert kwargs["gpu_count"] == 2
    assert kwargs["duration_minutes"] == 60


def test_cost_summary(monkeypatch):
    client = _stub_all(monkeypatch)
    client.cost.summary.return_value = {"total_usd": 123.45, "days": 30}
    result = runner.invoke(app, ["cost", "summary", "--days", "30", "--format", "json"])
    assert result.exit_code == 0
    assert json.loads(result.stdout)["total_usd"] == 123.45


# ---------- billing ----------

def test_billing_balance(monkeypatch):
    client = _stub_all(monkeypatch)
    client.billing.balance.return_value = {"balance_usd": 50.0, "plan": "pro"}
    result = runner.invoke(app, ["billing", "balance", "--format", "json"])
    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["balance_usd"] == 50.0


def test_billing_burn_rate(monkeypatch):
    client = _stub_all(monkeypatch)
    client.billing.burn_rate.return_value = {"burn_usd_per_day": 5.0, "days_remaining": 10}
    result = runner.invoke(app, ["billing", "burn-rate", "--format", "json"])
    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["burn_usd_per_day"] == 5.0


def test_billing_transactions(monkeypatch):
    client = _stub_all(monkeypatch)
    client.billing.transactions.return_value = {
        "data": [
            {"id": "txn_1", "amount_usd": -10.0, "kind": "training"},
            {"id": "txn_2", "amount_usd": 100.0, "kind": "topup"},
        ]
    }
    result = runner.invoke(app, ["billing", "transactions", "--format", "json"])
    assert result.exit_code == 0
