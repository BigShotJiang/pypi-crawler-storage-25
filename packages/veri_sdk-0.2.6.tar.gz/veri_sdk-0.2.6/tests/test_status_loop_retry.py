"""Tests for the SDK's resilient polling.

Reproduces the 2026-05-14 incident (job 02a61581b6f1): control-plane GET took
>60s due to synchronous backend I/O, httpx ReadTimeout fired, and the local
process crashed with a traceback. The fix wraps polling in retry-with-backoff
for transient errors; permanent errors (4xx) still propagate.
"""

from __future__ import annotations

from unittest.mock import MagicMock

import httpx
import pytest

from veri_sdk._decorators import _poll_with_retry


def _make_response(status_code: int) -> httpx.Response:
    return httpx.Response(
        status_code=status_code,
        request=httpx.Request("GET", "https://api.veri.studio/v1/training_jobs/x"),
    )


async def _noop_log(_msg: str) -> None:
    pass


@pytest.mark.asyncio
async def test_poll_retries_read_timeout_then_succeeds(monkeypatch):
    """The 2026-05-14 case directly: one ReadTimeout, then success."""
    monkeypatch.setattr("veri_sdk._decorators._POLL_BACKOFF_INITIAL", 0.0)

    expected = MagicMock(status="running")
    calls = {"n": 0}

    def get(_job_id: str):
        calls["n"] += 1
        if calls["n"] == 1:
            raise httpx.ReadTimeout("The read operation timed out")
        return expected

    client = MagicMock()
    client.training_jobs.get = get

    result = await _poll_with_retry(client, "job-x", safe_log=_noop_log)

    assert result is expected
    assert calls["n"] == 2


@pytest.mark.asyncio
async def test_poll_retries_5xx_then_succeeds(monkeypatch):
    """Gateway 502 (control plane redeploy, upstream blip) — must retry.

    Post VS-218 Part A: client.training_jobs.get() raises VeriServerError
    on 5xx, not httpx.HTTPStatusError. _poll_with_retry must catch the
    typed exception or the retry path is dead."""
    from veri_sdk.client import VeriServerError

    monkeypatch.setattr("veri_sdk._decorators._POLL_BACKOFF_INITIAL", 0.0)

    expected = MagicMock(status="completed")
    calls = {"n": 0}

    def get(_job_id: str):
        calls["n"] += 1
        if calls["n"] == 1:
            raise VeriServerError("502 Bad Gateway")
        return expected

    client = MagicMock()
    client.training_jobs.get = get

    result = await _poll_with_retry(client, "job-x", safe_log=_noop_log)

    assert result is expected
    assert calls["n"] == 2


@pytest.mark.asyncio
async def test_poll_propagates_4xx(monkeypatch):
    """4xx is permanent — auth drift, bad token. Must not retry forever.

    Post VS-218 Part A: 4xx surfaces as a typed VeriError subclass
    (VeriAuthError for 401, VeriRequestError for 400, etc.) — none of
    which should be retried."""
    from veri_sdk.client import VeriAuthError

    monkeypatch.setattr("veri_sdk._decorators._POLL_BACKOFF_INITIAL", 0.0)

    def get(_job_id: str):
        raise VeriAuthError("Token expired (run `veri login`)")

    client = MagicMock()
    client.training_jobs.get = get

    with pytest.raises(VeriAuthError):
        await _poll_with_retry(client, "job-x", safe_log=_noop_log)


@pytest.mark.asyncio
async def test_poll_retries_connect_error(monkeypatch):
    """Local network drop — laptop sleep/wake, wifi flip, etc."""
    monkeypatch.setattr("veri_sdk._decorators._POLL_BACKOFF_INITIAL", 0.0)

    expected = MagicMock(status="running")
    calls = {"n": 0}

    def get(_job_id: str):
        calls["n"] += 1
        if calls["n"] == 1:
            raise httpx.ConnectError("Connection refused")
        return expected

    client = MagicMock()
    client.training_jobs.get = get

    result = await _poll_with_retry(client, "job-x", safe_log=_noop_log)

    assert result is expected
    assert calls["n"] == 2


@pytest.mark.asyncio
async def test_poll_backoff_caps(monkeypatch):
    """Successive failures don't run the delay to infinity — cap matters
    because a real backend outage could last minutes; we want bounded
    delay so reconnect happens promptly once the API recovers."""
    monkeypatch.setattr("veri_sdk._decorators._POLL_BACKOFF_INITIAL", 1.0)
    monkeypatch.setattr("veri_sdk._decorators._POLL_BACKOFF_MAX", 4.0)

    sleeps: list[float] = []

    async def _record_sleep(d: float) -> None:
        sleeps.append(d)

    monkeypatch.setattr("veri_sdk._decorators.asyncio.sleep", _record_sleep)

    expected = MagicMock(status="running")
    calls = {"n": 0}

    def get(_job_id: str):
        calls["n"] += 1
        if calls["n"] <= 6:
            raise httpx.ReadTimeout("slow")
        return expected

    client = MagicMock()
    client.training_jobs.get = get

    await _poll_with_retry(client, "job-x", safe_log=_noop_log)

    # Each sleep includes up to 25% jitter, so check the underlying delay
    # via the cap: once we hit max, every subsequent sleep stays at or
    # under (max + 25% jitter).
    assert sleeps[-1] <= 4.0 * 1.25
    assert max(sleeps) <= 4.0 * 1.25
