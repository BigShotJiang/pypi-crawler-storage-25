"""Extract runnable code blocks from Mintlify .mdx pages.

Walks every .mdx under a docs root, finds fenced code blocks, applies skip
rules, and yields `CodeBlock` records. Tier 1 of the doc-test harness uses
these to drive subprocess execution; Tier 2 uses them to find documented
endpoints whose response shapes need contract validation.
"""

from __future__ import annotations

import re
import textwrap
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Literal

# A fenced block looks like:
#     ```python expandable
#     ...
#     ```
# The info string after the lang token is optional; Mintlify uses it for
# tabs ("```python Python (SDK)") and for `expandable` long-example markers.
#
# Leading whitespace on the opening fence is allowed so we capture blocks
# nested inside Mintlify components (`<Step>`, `<CodeGroup>`, `<Tabs>`, ...)
# which indent their contents. The body is dedented after extraction so the
# Python or bash inside is runnable as-is.
_FENCE = re.compile(
    r"^(?P<indent>[ \t]*)```(?P<lang>[A-Za-z0-9_+-]+)(?P<info>[^\n]*)\n"
    r"(?P<body>.*?)\n[ \t]*```",
    re.MULTILINE | re.DOTALL,
)

# GPU-spend markers. If a block contains any of these, skip it — Tier 1 must
# never spend credit. The 3 cost-bearing quickstarts are Tier 4 (manual).
_GPU_SPEND_MARKERS = (
    "training_jobs.create",
    "deployments.create",
    "evals.runs.create",
    "veri run grpo",
    "veri run deploy",
    "veri jobs create",
    "veri deployments create",
    "veri evals create",
    "gpu_count",
    "gpu_type",
)

# Inline opt-out, placed on the line immediately above a fence. Two forms:
#   <!-- skip-test: reason -->         (plain markdown context)
#   {/* skip-test: reason */}          (inside MDX/JSX components — <Step>,
#                                       <CodeGroup>, <Tabs>, etc. — where
#                                       HTML comments break Mintlify's parse)
_SKIP_COMMENT = re.compile(
    r"(?:<!--|\{/\*)\s*skip-test(?::\s*(?P<reason>[^\n]+?))?\s*(?:-->|\*/\})"
)

# Page-level directive — placed anywhere in an .mdx (conventionally near the
# top). Tells the harness this page can only be tested with VERI_DOCTEST_GPU_OK=1
# because its workflow burns GPU credit. Both Tier 1 and Tier 1.5 page-skip
# it in default (non-GPU) mode, and a Tier 4 manual pass picks it up.
_PAGE_GPU_REQUIRED = re.compile(
    r"(?:<!--|\{/\*)\s*doctest-page-gpu-required\s*(?:-->|\*/\})"
)


def page_requires_gpu(path: Path) -> bool:
    """True if the page declares it can only be tested end-to-end with GPU mode."""
    return bool(_PAGE_GPU_REQUIRED.search(path.read_text()))


SkipReason = Literal[
    "expandable",
    "gpu_spend",
    "skip_comment",
    "non_runnable_lang",
    "placeholder",
]


@dataclass(frozen=True)
class CodeBlock:
    path: Path
    lang: str          # "python", "bash", "toml", etc.
    info: str          # everything after the lang token: tab name, "expandable", ...
    body: str
    line_start: int    # 1-indexed line of the opening fence
    skip: SkipReason | None
    skip_detail: str | None  # human-readable reason if skip is set


def iter_pages(docs_root: Path) -> Iterable[Path]:
    """Yield every .mdx page under `docs_root`, sorted for stable test IDs."""
    yield from sorted(docs_root.rglob("*.mdx"))


def extract_blocks(path: Path) -> list[CodeBlock]:
    """Return every fenced code block in `path` with skip annotations applied."""
    text = path.read_text()
    blocks: list[CodeBlock] = []

    # Pre-compute line offsets so we can map char offset → 1-indexed line.
    line_starts = [0]
    for i, ch in enumerate(text):
        if ch == "\n":
            line_starts.append(i + 1)

    def line_of(char_offset: int) -> int:
        # Binary-search-free: linear is fine, files are small.
        for i, start in enumerate(line_starts):
            if start > char_offset:
                return i
        return len(line_starts)

    for match in _FENCE.finditer(text):
        lang = match.group("lang").lower()
        info = match.group("info").strip()
        # Dedent so a Step-indented Python block is runnable without
        # `IndentationError: unexpected indent`. Mintlify renders these
        # blocks dedented in the user-facing docs; we mirror that.
        body = textwrap.dedent(match.group("body"))
        line_start = line_of(match.start())

        # Look at the line immediately above the fence for a skip comment.
        prefix_end = match.start()
        prefix_start = max(0, text.rfind("\n", 0, prefix_end - 1) + 1)
        prev_line = text[prefix_start:prefix_end].strip()
        skip_match = _SKIP_COMMENT.search(prev_line)

        skip: SkipReason | None = None
        skip_detail: str | None = None

        # Order matters: pick the most restrictive applicable reason so an
        # expandable-and-GPU-spend block is correctly gated by the GPU env
        # var, not silently included by Tier 1.5's expandable allowance.
        if lang not in ("python", "bash", "shell", "sh"):
            skip = "non_runnable_lang"
            skip_detail = f"lang={lang!r}"
        elif skip_match:
            skip = "skip_comment"
            skip_detail = (skip_match.group("reason") or "").strip() or None
        elif "vk_your_key_here" in body or "<job-id>" in body or "your_key" in body:
            skip = "placeholder"
            skip_detail = "contains placeholder values that must be substituted"
        elif any(marker in body for marker in _GPU_SPEND_MARKERS):
            skip = "gpu_spend"
            hit = next(m for m in _GPU_SPEND_MARKERS if m in body)
            skip_detail = f"contains GPU-spend marker {hit!r}"
        elif "expandable" in info.lower().split():
            skip = "expandable"
            skip_detail = "marked expandable in fence info"

        blocks.append(
            CodeBlock(
                path=path,
                lang=lang,
                info=info,
                body=body,
                line_start=line_start,
                skip=skip,
                skip_detail=skip_detail,
            )
        )

    return blocks


def runnable_blocks(docs_root: Path) -> list[CodeBlock]:
    """Convenience: every block under `docs_root` whose `skip` is None."""
    out: list[CodeBlock] = []
    for page in iter_pages(docs_root):
        for block in extract_blocks(page):
            if block.skip is None:
                out.append(block)
    return out
