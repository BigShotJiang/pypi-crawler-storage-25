"""Shared fixtures for the doc-test harness.

Tier 1 + 2 of the doc-test harness (see <issue>VS-204</issue>) run snippets
extracted from `docs/documentation/**/*.mdx` against a live control plane.
For local development that means pointing at `http://localhost:8000` after
running `veri login --token vk_... --url http://localhost:8000`. CI will
spawn the control plane as a service container before invoking pytest.

Both tiers skip cleanly with a clear message if the control plane isn't
reachable, so a stock `pytest` run on a fresh checkout reports skips, not
errors.
"""

from __future__ import annotations

import os
from pathlib import Path

import httpx
import pytest


@pytest.fixture(scope="session")
def docs_root() -> Path:
    """Absolute path to the .mdx docs root."""
    # sdk/tests/docs/conftest.py → repo root → docs/documentation
    here = Path(__file__).resolve()
    root = here.parents[3] / "docs" / "documentation"
    if not root.exists():
        pytest.skip(
            f"Docs root not found at {root}. Run "
            "`git submodule update --init docs/documentation` to fetch the docs.",
            allow_module_level=True,
        )
    return root


@pytest.fixture(scope="session")
def control_plane_url() -> str:
    """Base URL of the control plane the snippets will hit.

    Override with `VERI_DOCTEST_API_URL`. Defaults to localhost.
    """
    return os.environ.get("VERI_DOCTEST_API_URL", "http://localhost:8000")


@pytest.fixture(scope="session")
def control_plane_key() -> str:
    """API key the snippets will use.

    Override with `VERI_DOCTEST_API_KEY`. Defaults to the local dev key.
    """
    return os.environ.get("VERI_DOCTEST_API_KEY", "")


@pytest.fixture(scope="session", autouse=True)
def _require_control_plane(control_plane_url: str) -> None:
    """Skip the whole module if the control plane isn't reachable.

    Doctest is meant to fail loudly on doc/code drift, not on the operator
    forgetting to start a server. The skip message tells them what to do.
    """
    try:
        resp = httpx.get(f"{control_plane_url.rstrip('/')}/health", timeout=2)
    except httpx.HTTPError as exc:
        pytest.skip(
            f"Control plane not reachable at {control_plane_url} ({exc}). "
            "Start it (`uvicorn control_plane.main:app --port 8000`) or set "
            "VERI_DOCTEST_API_URL to a different host.",
            allow_module_level=True,
        )
        return  # unreachable, but pleases type checkers — pytest.skip raises
    if resp.status_code >= 500:
        pytest.skip(
            f"Control plane at {control_plane_url} returned {resp.status_code} "
            f"on /health.",
            allow_module_level=True,
        )
