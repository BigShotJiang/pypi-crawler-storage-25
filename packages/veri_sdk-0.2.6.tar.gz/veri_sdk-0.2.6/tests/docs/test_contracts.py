"""Tier 2 — assert documented response shapes match what the API actually returns.

Tier 1 (`test_snippets.py`) catches snippets that crash. Tier 2 catches the
subtler bug class: snippet runs fine, but the documented field name is wrong
or the envelope is the wrong shape — exactly the `data.items` vs `{ data }`
mismatch that bit us in the dashboard API keys page.

Each contract is a (endpoint, doc-claimed key path) pair. The test hits the
endpoint against the local control plane and asserts every claimed key is
present. Missing keys fail with a clear message so the doc author sees both
the page reference and the actual response.

Add new contracts here as new endpoints are documented.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx
import pytest


@dataclass(frozen=True)
class Contract:
    """A single API endpoint × documented response shape."""

    method: str            # "GET" / "POST" / etc.
    path: str              # "/v1/api_keys"
    expected_keys: tuple[str, ...]
    doc_page: str          # "/account/api-keys" — for failure messages
    body: dict[str, Any] | None = None  # POST/PUT body, if any


# Each entry is one assertion per documented endpoint. Keep the list small and
# accurate; add to it as new pages document new endpoints.
#
# `expected_keys` are top-level keys that the doc claims will be present.
# Lists are documented as the OpenAI-style envelope `{ object: "list", data: [...], has_more }`.
CONTRACTS: tuple[Contract, ...] = (
    Contract(
        method="GET",
        path="/v1/api_keys",
        expected_keys=("object", "data", "has_more"),
        doc_page="/account/api-keys",
    ),
    Contract(
        method="GET",
        path="/v1/datasets",
        expected_keys=("object", "data", "has_more"),
        doc_page="/fine-tuning/datasets",
    ),
    Contract(
        method="GET",
        path="/v1/training_jobs",
        expected_keys=("object", "data", "has_more"),
        doc_page="/fine-tuning/api",
    ),
    Contract(
        method="GET",
        path="/v1/deployments",
        expected_keys=("object", "data", "has_more"),
        doc_page="/deployments/api",
    ),
    Contract(
        method="GET",
        path="/v1/evals",
        expected_keys=("object", "data", "has_more"),
        doc_page="/evaluations/api",
    ),
    Contract(
        method="GET",
        path="/v1/billing/balance",
        expected_keys=("balance_usd",),
        doc_page="/account/billing",
    ),
    Contract(
        method="GET",
        path="/v1/billing/burn_rate",
        expected_keys=("balance_usd", "burn_rate_usd_per_hour", "active_jobs"),
        doc_page="/account/billing",
    ),
    Contract(
        method="GET",
        path="/v1/billing/transactions",
        expected_keys=("object", "data", "has_more"),
        doc_page="/account/billing",
    ),
)


def _id(c: Contract) -> str:
    return f"{c.method} {c.path}"


@pytest.mark.parametrize("contract", CONTRACTS, ids=[_id(c) for c in CONTRACTS])
def test_response_shape(
    contract: Contract,
    control_plane_url: str,
    control_plane_key: str,
) -> None:
    if not control_plane_key:
        pytest.skip(
            "No API key configured. Set VERI_DOCTEST_API_KEY to a vk_... key "
            "from the local control plane."
        )

    headers = {"Authorization": f"Bearer {control_plane_key}"}
    url = f"{control_plane_url.rstrip('/')}{contract.path}"

    resp = httpx.request(
        contract.method,
        url,
        headers=headers,
        json=contract.body,
        timeout=10,
    )

    if resp.status_code >= 500:
        pytest.fail(
            f"{contract.method} {contract.path} returned {resp.status_code}\n"
            f"Body: {resp.text}"
        )
    if resp.status_code in (401, 403):
        pytest.fail(
            f"{contract.method} {contract.path} returned {resp.status_code}: "
            f"the API key in VERI_DOCTEST_API_KEY isn't valid against "
            f"{control_plane_url}."
        )
    if resp.status_code >= 400:
        pytest.fail(
            f"{contract.method} {contract.path} returned {resp.status_code}\n"
            f"Documented at {contract.doc_page}\n"
            f"Body: {resp.text}"
        )

    payload = resp.json()
    if not isinstance(payload, dict):
        pytest.fail(
            f"{contract.method} {contract.path} returned non-object payload: "
            f"{type(payload).__name__}\n"
            f"Documented at {contract.doc_page} as having keys "
            f"{contract.expected_keys}.\n"
            f"Got: {payload!r}"
        )

    missing = [k for k in contract.expected_keys if k not in payload]
    if missing:
        pytest.fail(
            f"{contract.method} {contract.path} response is missing "
            f"documented keys: {missing}\n"
            f"Documented at {contract.doc_page}\n"
            f"Got keys: {sorted(payload.keys())}"
        )
