"""Tier 1 — execute every runnable doc snippet against the local control plane.

Each snippet runs in its own subprocess with a fresh `Client()` configured to
talk to the local control plane. Failures point back at the page + line where
the snippet lives so a doc author can fix the source directly.

Skipped categories (see `extract.py` for rules):

* `non_runnable_lang` — toml/json/yaml/text/etc.
* `gpu_spend` — anything that would burn credits (Tier 4 covers these manually)
* `placeholder` — contains `vk_your_key_here` or `<job-id>` etc.
* `expandable` — long examples marked for collapse in the rendered docs
* `skip_comment` — page author wrote `<!-- skip-test: ... -->` above the fence

Run:
    cd sdk && uv run pytest tests/docs/test_snippets.py -v
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

from .extract import CodeBlock, extract_blocks, iter_pages, page_requires_gpu


def _block_id(block: CodeBlock) -> str:
    """Pytest test ID — short enough to fit in `-v` output, precise enough to grep."""
    rel = block.path.name
    parent = block.path.parent.name
    if parent and parent != "documentation":
        rel = f"{parent}/{rel}"
    return f"{rel}:{block.line_start}:{block.lang}"


def _collect(docs_root: Path) -> list[CodeBlock]:
    """Every runnable block, minus those on pages declared GPU-only when
    VERI_DOCTEST_GPU_OK is not set. Mirrors the page-level skip Tier 1.5
    applies so a single test mode (default vs GPU) reports a consistent
    set of expectations across both tiers."""
    gpu_ok = os.environ.get("VERI_DOCTEST_GPU_OK") == "1"
    out: list[CodeBlock] = []
    for page in iter_pages(docs_root):
        if not gpu_ok and page_requires_gpu(page):
            continue
        for block in extract_blocks(page):
            if block.skip is None:
                out.append(block)
    return out


def pytest_generate_tests(metafunc: pytest.Metafunc) -> None:
    """Parametrize over every runnable block in the docs tree.

    We compute the docs root the same way the fixture does, so collection
    happens before the fixture (and the skip in conftest) takes effect. If
    the docs aren't checked out, parametrize over an empty list — the module
    will still skip via the conftest fixture.
    """
    if "block" not in metafunc.fixturenames:
        return
    here = Path(__file__).resolve()
    root = here.parents[3] / "docs" / "documentation"
    blocks = _collect(root) if root.exists() else []
    metafunc.parametrize("block", blocks, ids=[_block_id(b) for b in blocks])


def _wrap_python(body: str) -> str:
    """Inject `from veri_sdk import Client; client = Client()` if needed.

    Most snippets reference `client` without constructing it (the docs assume
    you've done it once at the top of the page). Subprocess execution is
    isolated, so we synthesize the construction before the snippet body.
    """
    needs_client = "client" in body and "Client()" not in body and "= Client(" not in body
    needs_import = "from veri_sdk import" not in body and "import veri_sdk" not in body
    prefix = ""
    if needs_import:
        prefix += "from veri_sdk import Client\n"
    if needs_client:
        prefix += "client = Client()\n"
    return prefix + body


def _run(block: CodeBlock, env: dict[str, str], cwd: str) -> subprocess.CompletedProcess[str]:
    if block.lang == "python":
        code = _wrap_python(block.body)
        return subprocess.run(
            [sys.executable, "-c", code],
            capture_output=True,
            text=True,
            env=env,
            cwd=cwd,
            timeout=30,
        )
    if block.lang in ("bash", "shell", "sh"):
        return subprocess.run(
            ["bash", "-c", block.body],
            capture_output=True,
            text=True,
            env=env,
            cwd=cwd,
            timeout=30,
        )
    raise RuntimeError(f"Unhandled lang {block.lang!r} reached _run; check extract.py")


def test_snippet(
    block: CodeBlock,
    control_plane_url: str,
    control_plane_key: str,
    tmp_path: Path,
) -> None:
    """A passing test means the snippet runs to completion without error.

    We don't assert on stdout shape here (Tier 2 does that). We just want to
    know that as of this commit, the snippet doesn't blow up against the API.
    """
    if block.lang in ("bash", "shell", "sh") and not shutil.which("veri"):
        pytest.skip("`veri` CLI not installed in this environment")
    if block.lang == "python":
        try:
            import veri_sdk  # noqa: F401
        except ImportError:
            pytest.skip("veri-sdk not importable in this environment")

    env = os.environ.copy()
    env["VERI_API_URL"] = control_plane_url
    if control_plane_key:
        env["VERI_API_KEY"] = control_plane_key

    proc = _run(block, env, cwd=str(tmp_path))

    if proc.returncode != 0:
        rel = block.path
        try:
            rel = block.path.relative_to(Path(__file__).resolve().parents[3])
        except ValueError:
            pass
        pytest.fail(
            f"\n{rel}:{block.line_start} ({block.lang}) failed with exit code "
            f"{proc.returncode}\n\n"
            f"--- snippet ---\n{block.body}\n\n"
            f"--- stdout ---\n{proc.stdout}\n\n"
            f"--- stderr ---\n{proc.stderr}\n"
        )
