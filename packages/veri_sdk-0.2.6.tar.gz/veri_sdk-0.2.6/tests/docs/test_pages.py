"""Tier 1.5 — execute each doc page end-to-end as a single workflow.

Tier 1 (`test_snippets.py`) runs each fenced block in its own subprocess so a
block that depends on state from a prior block fails with `NameError`. Tier
1.5 composes every runnable Python block in a page into one subprocess and
runs every bash block sequentially with a shared cwd, so a multi-step page
(define → submit → wait → download) is tested as the workflow a reader
experiences.

Process model:

* One Python subprocess per page (all python blocks composed into one script
  with sentinel comments mapping back to .mdx lines).
* One bash subprocess per bash block, with shared cwd = per-page tempdir.
* Subprocess boundary kills any threads / asyncio tasks / sockets / global
  config the page leaked, so pages don't pollute each other.

Cross-lang state sharing (Python sets a var, bash reads $VAR) is out of
scope. Mark such pages with `<!-- skip-test: -->` on the dependent block.

Skip policy differs from Tier 1:

* `non_runnable_lang`, `placeholder`, `skip_comment` — still skipped.
* `expandable` — INCLUDED. These are render hints, not "don't test."
* `gpu_spend` — included only when `VERI_DOCTEST_GPU_OK=1`. Default off so
  CI stays free; flip on for a Tier 4 manual pass before release.

Run:
    cd sdk && uv run pytest tests/docs/test_pages.py -v
    VERI_DOCTEST_GPU_OK=1 ... tests/docs/test_pages.py -v   # include GPU blocks
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

from .extract import CodeBlock, extract_blocks, iter_pages, page_requires_gpu


# Match "File "<string>", line N" in a Python traceback so we can recover the
# deepest failing line and map it back through the offset table.
_TRACEBACK_LINE = re.compile(r'File "<string>", line (\d+)')


def _python_executable() -> str:
    """Prefer the sdk venv's interpreter over sys.executable.

    `uv run pytest` can resolve to a miniconda/system pytest whose
    sys.executable points at an interpreter without veri-sdk installed.
    Subprocesses spawned with that interpreter then fail to `import veri_sdk`
    even though the test module itself imports cleanly.
    """
    here = Path(__file__).resolve()
    sdk_venv = here.parents[2] / ".venv" / "bin" / "python3"
    if sdk_venv.exists():
        return str(sdk_venv)
    return sys.executable


def _page_id(page: Path, docs_root: Path) -> str:
    try:
        return str(page.relative_to(docs_root))
    except ValueError:
        return str(page)


def _include_for_page_test(block: CodeBlock, *, gpu_ok: bool) -> bool:
    """Tier 1.5 skip policy. See module docstring."""
    if block.skip is None:
        return True
    if block.skip == "expandable":
        return True
    if block.skip == "gpu_spend" and gpu_ok:
        return True
    return False


def _compose_python(blocks: list[CodeBlock]) -> tuple[str, list[tuple[int, int]]]:
    """Concat python blocks into one script. Returns (script, offsets).

    `offsets` is a list of (composed_first_line, mdx_line) entries in order.
    To map a failing composed line back to its mdx origin, find the entry
    with the largest composed_first_line <= target.
    """
    parts: list[str] = []
    offsets: list[tuple[int, int]] = []
    composed_line = 1
    for block in blocks:
        sentinel = f"# === doctest:mdx:{block.line_start} ==="
        parts.append(sentinel)
        offsets.append((composed_line, block.line_start))
        composed_line += 1
        body_lines = block.body.split("\n")
        parts.extend(body_lines)
        composed_line += len(body_lines)
    return "\n".join(parts) + "\n", offsets


def _map_back(composed_line: int, offsets: list[tuple[int, int]]) -> int | None:
    best: int | None = None
    for composed_first, mdx_line in offsets:
        if composed_first <= composed_line:
            best = mdx_line
        else:
            break
    return best


def pytest_generate_tests(metafunc: pytest.Metafunc) -> None:
    if "page" not in metafunc.fixturenames:
        return
    here = Path(__file__).resolve()
    docs_root = here.parents[3] / "docs" / "documentation"
    if not docs_root.exists():
        metafunc.parametrize("page", [])
        return
    pages = list(iter_pages(docs_root))
    metafunc.parametrize("page", pages, ids=[_page_id(p, docs_root) for p in pages])


def test_page_end_to_end(
    page: Path,
    control_plane_url: str,
    control_plane_key: str,
    docs_root: Path,
    tmp_path: Path,
) -> None:
    """Run every runnable block in `page` as one composed workflow.

    On failure, points at the originating .mdx:line so a doc author can fix
    the source directly.
    """
    gpu_ok = os.environ.get("VERI_DOCTEST_GPU_OK") == "1"
    if page_requires_gpu(page) and not gpu_ok:
        pytest.skip(
            f"{page.name} is marked doctest-page-gpu-required — "
            "run with VERI_DOCTEST_GPU_OK=1 (Tier 4 manual pass)."
        )
    blocks = [b for b in extract_blocks(page) if _include_for_page_test(b, gpu_ok=gpu_ok)]
    if not blocks:
        pytest.skip(f"No runnable blocks in {page.name}")

    py_blocks = [b for b in blocks if b.lang == "python"]
    sh_blocks = [b for b in blocks if b.lang in ("bash", "shell", "sh")]

    if sh_blocks and not shutil.which("veri"):
        pytest.skip("`veri` CLI not installed in this environment")
    if py_blocks:
        try:
            import veri_sdk  # noqa: F401
        except ImportError:
            pytest.skip("veri-sdk not importable in this environment")

    env = os.environ.copy()
    env["VERI_API_URL"] = control_plane_url
    if control_plane_key:
        env["VERI_API_KEY"] = control_plane_key

    rel = page.relative_to(docs_root)
    # When GPU mode is on the same page may take many minutes (training jobs);
    # otherwise 5 min is comfortably above any non-GPU snippet's wall time.
    timeout = 3600 if gpu_ok else 300

    if py_blocks:
        script, offsets = _compose_python(py_blocks)
        proc = subprocess.run(
            [_python_executable(), "-c", script],
            capture_output=True,
            text=True,
            env=env,
            cwd=str(tmp_path),
            timeout=timeout,
        )
        if proc.returncode != 0:
            composed_lines = [int(m.group(1)) for m in _TRACEBACK_LINE.finditer(proc.stderr)]
            composed_line = max(composed_lines) if composed_lines else None
            mdx_line = _map_back(composed_line, offsets) if composed_line else None
            origin = f"{rel}:{mdx_line}" if mdx_line else f"{rel} (line unknown)"
            pytest.fail(
                f"\n{origin} — Python workflow failed (exit {proc.returncode})\n\n"
                f"--- composed script ---\n{script}\n"
                f"--- stdout ---\n{proc.stdout}\n\n"
                f"--- stderr ---\n{proc.stderr}\n"
            )

    if sh_blocks:
        for block in sh_blocks:
            proc = subprocess.run(
                ["bash", "-c", block.body],
                capture_output=True,
                text=True,
                env=env,
                cwd=str(tmp_path),
                timeout=timeout,
            )
            if proc.returncode != 0:
                pytest.fail(
                    f"\n{rel}:{block.line_start} (bash) failed with exit {proc.returncode}\n\n"
                    f"--- snippet ---\n{block.body}\n\n"
                    f"--- stdout ---\n{proc.stdout}\n\n"
                    f"--- stderr ---\n{proc.stderr}\n"
                )
