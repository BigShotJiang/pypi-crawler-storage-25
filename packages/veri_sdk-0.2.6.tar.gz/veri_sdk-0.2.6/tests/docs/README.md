# Doc-test harness

Catches doc-vs-code drift on every PR. See Linear `VS-204` for design.

## Tier 1 — Snippet runner (`test_snippets.py`)

Walks every `.mdx` under `docs/documentation/`, extracts fenced `python` /
`bash` blocks, runs each in an isolated subprocess against a live control
plane, and fails if the snippet errors.

Skip rules (in `extract.py`):

- `non_runnable_lang` — toml/json/yaml/text/etc.
- `gpu_spend` — anything that would burn credits (Tier 4 covers these manually)
- `placeholder` — contains `vk_your_key_here`, `<job-id>`, etc.
- `expandable` — long examples marked for collapse in the rendered docs
- `skip_comment` — page author wrote `<!-- skip-test: reason -->` immediately above the fence

## Tier 1.5 — Page workflows (`test_pages.py`)

Where Tier 1 runs each fenced block in isolation (catching "this snippet
won't parse"), Tier 1.5 composes every runnable Python block in a page into
one subprocess and runs every bash block sequentially with a shared cwd, so
a multi-step page is tested as the workflow a reader experiences. Catches
"Step 4 references `dep` from Step 2" — the bug class Tier 1 can't see.

Subprocess-per-page: state shared within a page (composed Python script);
fresh process between pages (sys.modules, threads, sockets all torn down at
the boundary).

GPU-spend blocks are skipped by default. Set `VERI_DOCTEST_GPU_OK=1` to
include them — typically used in a Tier 4 manual pass before release.

```bash
cd sdk
VERI_DOCTEST_API_KEY=vk_your_key uv run pytest tests/docs/test_pages.py -v
# include GPU-spending blocks (burns credit):
VERI_DOCTEST_GPU_OK=1 VERI_DOCTEST_API_KEY=vk_... uv run pytest tests/docs/test_pages.py -v
```

## Tier 2 — Contract checks (`test_contracts.py`)

For each documented endpoint, asserts the response has the documented
top-level keys. Catches the subtler bug class where a snippet runs fine but
the doc claims the wrong field name (e.g., `data.items` vs `data.data`).

Add a `Contract(...)` row when documenting a new endpoint.

## Run locally

```bash
# Start the control plane
uvicorn control_plane.main:app --port 8000 &

# Mint or reuse a vk_... API key against it
veri login --token vk_your_key --url http://localhost:8000

# Run both tiers
cd sdk
VERI_DOCTEST_API_KEY=vk_your_key uv run pytest tests/docs/ -v
```

Override target with:

- `VERI_DOCTEST_API_URL` (default: `http://localhost:8000`)
- `VERI_DOCTEST_API_KEY` (no default — most contract tests skip without it)

## Why subprocess execution

Each snippet gets a fresh `Client()` so isolation is guaranteed. Multi-block
flows (e.g., snippet B references `dep` from snippet A) won't work — that's
intentional. If a doc requires sequential execution, mark the dependent
blocks `<!-- skip-test: depends on previous block -->` and rely on Tier 4
(manual GPU pass) to cover them.

## Adding a skip

If a snippet is intentionally non-runnable (pseudocode, depends on prior
state, requires user input), add the HTML comment immediately above the
fence:

````markdown
<!-- skip-test: depends on `dep` from previous step -->
```python
dep.stop()
```
````
