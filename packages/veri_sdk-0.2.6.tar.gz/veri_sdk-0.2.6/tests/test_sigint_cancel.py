"""VS-218 Part B — SIGINT auto-cancels the running training job.

Default behavior: Ctrl+C means stop. Users who want server-owned
runs ("submit, close laptop") opt in with `veri train --detach`.

The fast path here is the explicit cancel API call (~5s end-to-end).
Part D adds the heartbeat safety net for non-graceful SDK death
(SIGKILL, network drop, laptop sleep).
"""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from veri_sdk._decorators import _stream_wait
from veri_sdk.client import VeriError, VeriRequestError


def _fake_job(job_id: str = "tj_abc") -> MagicMock:
    job = MagicMock()
    job.id = job_id
    job.status = "running"
    job.error_message = None
    job.cost_usd = None
    return job


def test_sigint_calls_cancel_api(monkeypatch):
    """KeyboardInterrupt during the wait loop fires client.training_jobs.cancel."""
    job = _fake_job()
    client = MagicMock()

    # Simulate Ctrl+C while we're waiting on the streamed status.
    def raise_keyboard_interrupt(*_a, **_k):
        raise KeyboardInterrupt

    monkeypatch.setattr(
        "veri_sdk._decorators._stream_wait_async",
        raise_keyboard_interrupt,
    )

    result = _stream_wait(job, client, log=lambda *_a, **_k: None)

    client.training_jobs.cancel.assert_called_once_with("tj_abc")
    # Job state reflects the cancel; SDK exits cleanly.
    assert result is job
    assert job.status == "cancelled"


def test_sigint_swallows_cancel_failure(monkeypatch):
    """If the cancel API itself errors (job already terminal, network drop,
    auth blip), the SDK must still exit cleanly. Part D's heartbeat
    timeout is the safety net for genuinely lost cancel calls."""
    job = _fake_job()
    client = MagicMock()
    client.training_jobs.cancel.side_effect = VeriRequestError(
        "Job is already failed"
    )

    monkeypatch.setattr(
        "veri_sdk._decorators._stream_wait_async",
        lambda *_a, **_k: (_ for _ in ()).throw(KeyboardInterrupt),
    )

    # Must not propagate the VeriError. The user pressed Ctrl+C; they
    # don't care that the cancel call failed.
    result = _stream_wait(job, client, log=lambda *_a, **_k: None)
    assert result is job
    assert job.status == "cancelled"


def test_normal_completion_does_not_cancel(monkeypatch):
    """Regression guard: when the wait returns normally, do NOT call cancel."""
    job = _fake_job()
    job.status = "completed"
    client = MagicMock()

    async def fake_async(j, c, *, log):
        return j

    monkeypatch.setattr(
        "veri_sdk._decorators._stream_wait_async",
        fake_async,
    )

    _stream_wait(job, client, log=lambda *_a, **_k: None)

    client.training_jobs.cancel.assert_not_called()
    assert job.status == "completed"


def test_sigint_messages_include_job_id_and_detach_hint(monkeypatch):
    """User-facing output should name the job and explain how to keep
    future runs alive."""
    job = _fake_job("tj_xyz")
    client = MagicMock()

    monkeypatch.setattr(
        "veri_sdk._decorators._stream_wait_async",
        lambda *_a, **_k: (_ for _ in ()).throw(KeyboardInterrupt),
    )

    lines: list[str] = []
    _stream_wait(job, client, log=lambda msg: lines.append(msg))
    joined = "\n".join(lines)

    assert "tj_xyz" in joined
    assert "--detach" in joined
