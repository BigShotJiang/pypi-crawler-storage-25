"""VS-218 Part A — VeriError hierarchy and _raise helper.

Server returns structured error bodies (e.g. `{"error": {"message": "..."}}`)
but every method in client.py was calling resp.raise_for_status() which
discards them. Users saw `HTTPStatusError: Client error '400'` with no
actionable message. _raise extracts the message and routes to a typed
exception per status code.
"""

from __future__ import annotations

import httpx
import pytest

from veri_sdk.client import (
    VeriAuthError,
    VeriError,
    VeriNotFoundError,
    VeriRequestError,
    VeriServerError,
    _raise,
)


def _resp(status: int, json_body=None, text_body: str = "") -> httpx.Response:
    if json_body is not None:
        return httpx.Response(
            status,
            json=json_body,
            request=httpx.Request("GET", "https://api.example/x"),
        )
    return httpx.Response(
        status,
        text=text_body,
        request=httpx.Request("GET", "https://api.example/x"),
    )


# -------------------- body-shape extraction --------------------

def test_raise_extracts_message_from_nested_error_body():
    """The canonical server shape: {"error": {"message": "..."}}."""
    resp = _resp(400, json_body={"error": {"message": "Job is already failed"}})
    with pytest.raises(VeriRequestError) as exc:
        _raise(resp)
    assert "Job is already failed" in str(exc.value)


def test_raise_extracts_message_from_flat_message_body():
    """Some endpoints return {"message": "..."} without the error wrapper."""
    resp = _resp(400, json_body={"message": "Invalid dataset name"})
    with pytest.raises(VeriRequestError) as exc:
        _raise(resp)
    assert "Invalid dataset name" in str(exc.value)


def test_raise_falls_back_to_plain_text_body():
    resp = _resp(500, text_body="upstream timeout")
    with pytest.raises(VeriServerError) as exc:
        _raise(resp)
    assert "upstream timeout" in str(exc.value)


def test_raise_handles_empty_body():
    """No body at all — at minimum surface the status code."""
    resp = _resp(503, text_body="")
    with pytest.raises(VeriServerError) as exc:
        _raise(resp)
    assert "503" in str(exc.value)


# -------------------- typed routing per status code --------------------

def test_raise_400_to_request_error():
    with pytest.raises(VeriRequestError):
        _raise(_resp(400, json_body={"error": {"message": "bad"}}))


def test_raise_401_to_auth_error_with_login_hint():
    """401 should mention `veri login` so users know how to recover."""
    resp = _resp(401, json_body={"error": {"message": "Token expired"}})
    with pytest.raises(VeriAuthError) as exc:
        _raise(resp)
    assert "veri login" in str(exc.value).lower()


def test_raise_404_to_not_found_error():
    with pytest.raises(VeriNotFoundError):
        _raise(_resp(404, json_body={"error": {"message": "Job not found"}}))


def test_raise_500_to_server_error():
    with pytest.raises(VeriServerError):
        _raise(_resp(500, text_body="oops"))


def test_raise_503_to_server_error():
    with pytest.raises(VeriServerError):
        _raise(_resp(503, text_body="maintenance"))


def test_raise_2xx_is_noop():
    """Success responses must not raise."""
    _raise(_resp(200, json_body={"ok": True}))


def test_subclasses_are_veri_errors():
    """Callers should be able to `except VeriError:` and catch them all."""
    for cls in (VeriRequestError, VeriAuthError, VeriNotFoundError, VeriServerError):
        assert issubclass(cls, VeriError)
