"""Tests for the SDK Volumes surface (VS-226).

`Client.volumes.*` namespace CRUD + Volume instance methods. Multipart
upload uses presigned S3 URLs returned by the control plane — these
tests respx-mock both the control plane and the S3 URLs.
"""
from __future__ import annotations

import io
from pathlib import Path
from unittest.mock import patch

import httpx
import pytest
import respx

from veri_sdk.client import (
    Client,
    Volume,
    VolumeFile,
    _VOLUME_SINGLE_PUT_LIMIT,
    VeriError,
    VeriNotFoundError,
)


# ---------- Fixtures ----------


@pytest.fixture
def client() -> Client:
    return Client(api_key="test-key", base_url="http://test")


@pytest.fixture
def volume_payload() -> dict:
    return {
        "object": "volume",
        "id": "vol_abc123",
        "name": "my-data",
        "total_bytes": 0,
        "file_count": 0,
        "created_at": "2026-05-14T00:00:00Z",
        "updated_at": "2026-05-14T00:00:00Z",
    }


# ---------- CRUD via Client.volumes.* ----------


@respx.mock
def test_volumes_create_returns_volume(client, volume_payload):
    respx.post("http://test/v1/volumes").mock(
        return_value=httpx.Response(201, json=volume_payload)
    )
    vol = client.volumes.create("my-data")
    assert isinstance(vol, Volume)
    assert vol.id == "vol_abc123"
    assert vol.name == "my-data"
    assert vol._client is client


@respx.mock
def test_volumes_get_returns_volume(client, volume_payload):
    respx.get("http://test/v1/volumes/my-data").mock(
        return_value=httpx.Response(200, json=volume_payload)
    )
    vol = client.volumes.get("my-data")
    assert vol.name == "my-data"
    assert vol._client is client


@respx.mock
def test_volumes_get_missing_raises_notfound(client):
    respx.get("http://test/v1/volumes/missing").mock(
        return_value=httpx.Response(404, json={"error": {"message": "Volume not found"}})
    )
    with pytest.raises(VeriNotFoundError):
        client.volumes.get("missing")


@respx.mock
def test_volumes_list_parses_data_envelope(client, volume_payload):
    respx.get("http://test/v1/volumes").mock(
        return_value=httpx.Response(
            200,
            json={"object": "list", "data": [volume_payload], "has_more": False},
        )
    )
    vols = client.volumes.list()
    assert len(vols) == 1
    assert vols[0].id == "vol_abc123"
    assert vols[0]._client is client


@respx.mock
def test_volumes_delete_returns_none(client):
    respx.delete("http://test/v1/volumes/old").mock(
        return_value=httpx.Response(204)
    )
    assert client.volumes.delete("old") is None


# ---------- Volume.upload_file — single-PUT path ----------


@respx.mock
def test_upload_file_single_put_under_threshold(client, volume_payload, tmp_path):
    """File < 5 GiB: server returns a single presigned URL, SDK PUTs once."""
    local = tmp_path / "small.bin"
    local.write_bytes(b"hello world")

    init_route = respx.post(
        f"http://test/v1/volumes/my-data/upload-url"
    ).mock(
        return_value=httpx.Response(
            200, json={"type": "single", "url": "https://s3.fake/put?sig=a"}
        )
    )
    s3_route = respx.put("https://s3.fake/put?sig=a").mock(
        return_value=httpx.Response(200, headers={"ETag": '"abc"'})
    )

    vol = Volume(id="vol_x", name="my-data", _client=client)
    vol.upload_file(str(local), "/small.bin")

    assert init_route.called
    assert s3_route.called
    # Server saw the right size_bytes.
    sent = init_route.calls.last.request.read()
    import json as _j
    assert _j.loads(sent)["size_bytes"] == 11
    assert _j.loads(sent)["path"] == "/small.bin"


@respx.mock
def test_upload_file_raises_when_s3_put_fails(client, tmp_path):
    local = tmp_path / "x.bin"
    local.write_bytes(b"data")
    respx.post("http://test/v1/volumes/my-data/upload-url").mock(
        return_value=httpx.Response(
            200, json={"type": "single", "url": "https://s3.fake/put"}
        )
    )
    respx.put("https://s3.fake/put").mock(return_value=httpx.Response(403))

    vol = Volume(id="v", name="my-data", _client=client)
    with pytest.raises(VeriError, match="HTTP 403"):
        vol.upload_file(str(local), "/x.bin")


# ---------- Volume.upload_file — multipart path ----------


@respx.mock
def test_upload_file_multipart_uploads_all_parts_and_completes(client, tmp_path):
    """File > 5 GiB triggers multipart. Verify the SDK:
      1) calls init with size_bytes,
      2) requests per-part URLs for every part,
      3) PUTs each part to its presigned URL,
      4) POSTs /complete with the ETags it collected.

    We can't actually allocate 6 GiB on disk in CI — patch Path.stat to
    return a fake size, then patch open() to return a small slice for any
    offset/length read.
    """
    local = tmp_path / "big.bin"
    local.write_bytes(b"x" * 100)  # placeholder; we lie about its size below

    # Fake out the file size. SDK divides into part_size=8 byte chunks
    # so we get exactly 3 parts (24 bytes total).
    FAKE_SIZE = 24
    PART_SIZE = 8

    respx.post("http://test/v1/volumes/my-data/upload-url").mock(
        return_value=httpx.Response(200, json={
            "type": "multipart_init",
            "upload_id": "u-1",
            "path": "/big.bin",
            "part_size": PART_SIZE,
            "complete_url": "/v1/volumes/my-data/upload-url/complete",
        })
    )
    respx.post("http://test/v1/volumes/my-data/upload-url/part").mock(
        return_value=httpx.Response(200, json={"url": "https://s3.fake/part"})
    )
    s3_put = respx.put("https://s3.fake/part").mock(
        return_value=httpx.Response(200, headers={"ETag": '"part-etag"'})
    )
    complete_route = respx.post(
        "http://test/v1/volumes/my-data/upload-url/complete"
    ).mock(return_value=httpx.Response(200, json={
        "object": "volume.file",
        "path": "/big.bin",
        "size_bytes": FAKE_SIZE,
        "etag": "merged",
    }))

    with patch("veri_sdk.client._VOLUME_SINGLE_PUT_LIMIT", 16):
        # Force multipart by setting threshold below FAKE_SIZE.
        # Also patch Path.stat so the SDK believes the file is 24 bytes.
        from os import stat_result as _sr
        real_stat = Path.stat

        def fake_stat(self, *a, **kw):
            r = real_stat(self, *a, **kw)
            if self == local:
                # Build a stat_result with the right size; everything else copied.
                return _sr((r.st_mode, r.st_ino, r.st_dev, r.st_nlink, r.st_uid,
                            r.st_gid, FAKE_SIZE, r.st_atime, r.st_mtime, r.st_ctime))
            return r
        with patch.object(Path, "stat", fake_stat):
            vol = Volume(id="v", name="my-data", _client=client)
            vol.upload_file(str(local), "/big.bin")

    assert s3_put.call_count == 3  # 24 bytes / 8 byte parts
    assert complete_route.called
    # The /complete body must list all 3 parts with their ETags.
    import json as _j
    body = _j.loads(complete_route.calls.last.request.read())
    assert body["upload_id"] == "u-1"
    assert body["path"] == "/big.bin"
    nums = sorted(p["number"] for p in body["parts"])
    assert nums == [1, 2, 3]
    assert all(p["etag"] == "part-etag" for p in body["parts"])


@respx.mock
def test_upload_file_multipart_aborts_on_part_failure(client, tmp_path):
    """If any part PUT fails, SDK should send /abort and re-raise."""
    local = tmp_path / "big.bin"
    local.write_bytes(b"x" * 100)

    PART_SIZE = 8
    FAKE_SIZE = 16  # 2 parts

    respx.post("http://test/v1/volumes/my-data/upload-url").mock(
        return_value=httpx.Response(200, json={
            "type": "multipart_init",
            "upload_id": "u-fail",
            "path": "/big.bin",
            "part_size": PART_SIZE,
            "complete_url": "/v1/volumes/my-data/upload-url/complete",
        })
    )
    respx.post("http://test/v1/volumes/my-data/upload-url/part").mock(
        return_value=httpx.Response(200, json={"url": "https://s3.fake/part"})
    )
    respx.put("https://s3.fake/part").mock(return_value=httpx.Response(500))
    abort_route = respx.post(
        "http://test/v1/volumes/my-data/upload-url/abort"
    ).mock(return_value=httpx.Response(204))

    real_stat = Path.stat

    def fake_stat(self, *a, **kw):
        r = real_stat(self, *a, **kw)
        if self == local:
            from os import stat_result as _sr
            return _sr((r.st_mode, r.st_ino, r.st_dev, r.st_nlink, r.st_uid,
                        r.st_gid, FAKE_SIZE, r.st_atime, r.st_mtime, r.st_ctime))
        return r

    with patch.object(Path, "stat", fake_stat):
        vol = Volume(id="v", name="my-data", _client=client)
        with pytest.raises(VeriError):
            vol.upload_file(str(local), "/big.bin")

    assert abort_route.called


# ---------- progress_callback ----------


@respx.mock
def test_upload_file_single_calls_progress_callback_once(client, tmp_path):
    """Single-PUT path fires the callback once on completion with (size, size)."""
    local = tmp_path / "small.bin"
    local.write_bytes(b"hello world")  # 11 bytes

    respx.post("http://test/v1/volumes/my-data/upload-url").mock(
        return_value=httpx.Response(
            200, json={"type": "single", "url": "https://s3.fake/put"}
        )
    )
    respx.put("https://s3.fake/put").mock(
        return_value=httpx.Response(200, headers={"ETag": '"e"'})
    )

    seen: list[tuple[int, int]] = []

    vol = Volume(id="v", name="my-data", _client=client)
    vol.upload_file(str(local), "/small.bin", progress_callback=lambda d, t: seen.append((d, t)))

    assert seen == [(11, 11)]


@respx.mock
def test_upload_file_multipart_progress_advances_to_total(client, tmp_path):
    """Multipart fires the callback after each part with monotonic bytes_done."""
    local = tmp_path / "big.bin"
    local.write_bytes(b"x" * 100)

    PART_SIZE = 8
    FAKE_SIZE = 24  # 3 parts

    respx.post("http://test/v1/volumes/my-data/upload-url").mock(
        return_value=httpx.Response(200, json={
            "type": "multipart_init",
            "upload_id": "u",
            "path": "/big.bin",
            "part_size": PART_SIZE,
            "complete_url": "/v1/volumes/my-data/upload-url/complete",
        })
    )
    respx.post("http://test/v1/volumes/my-data/upload-url/part").mock(
        return_value=httpx.Response(200, json={"url": "https://s3.fake/part"})
    )
    respx.put("https://s3.fake/part").mock(
        return_value=httpx.Response(200, headers={"ETag": '"e"'})
    )
    respx.post("http://test/v1/volumes/my-data/upload-url/complete").mock(
        return_value=httpx.Response(200, json={
            "object": "volume.file", "path": "/big.bin",
            "size_bytes": FAKE_SIZE, "etag": "m",
        })
    )

    from os import stat_result as _sr
    real_stat = Path.stat

    def fake_stat(self, *a, **kw):
        r = real_stat(self, *a, **kw)
        if self == local:
            return _sr((r.st_mode, r.st_ino, r.st_dev, r.st_nlink, r.st_uid,
                        r.st_gid, FAKE_SIZE, r.st_atime, r.st_mtime, r.st_ctime))
        return r

    seen: list[tuple[int, int]] = []

    with patch.object(Path, "stat", fake_stat):
        vol = Volume(id="v", name="my-data", _client=client)
        vol.upload_file(
            str(local), "/big.bin",
            progress_callback=lambda d, t: seen.append((d, t)),
        )

    # 3 parts → 3 callback firings. Order may vary due to ThreadPoolExecutor
    # but each successive snapshot must be strictly greater than the prior.
    assert len(seen) == 3
    assert {t for _, t in seen} == {FAKE_SIZE}  # total constant
    bytes_seen = sorted(d for d, _ in seen)
    assert bytes_seen == [8, 16, 24]


@respx.mock
def test_upload_dir_progress_callback_sums_across_files(client, tmp_path):
    """upload_dir wraps per-file callbacks into a single cumulative counter
    so the bar shows overall %."""
    (tmp_path / "a.txt").write_bytes(b"AAA")           # 3 bytes
    (tmp_path / "nested").mkdir()
    (tmp_path / "nested" / "b.txt").write_bytes(b"BBBBBBB")  # 7 bytes
    # Total: 10 bytes

    respx.post("http://test/v1/volumes/my-data/upload-url").mock(
        return_value=httpx.Response(
            200, json={"type": "single", "url": "https://s3.fake/put"}
        )
    )
    respx.put("https://s3.fake/put").mock(
        return_value=httpx.Response(200, headers={"ETag": '"e"'})
    )

    seen: list[tuple[int, int]] = []

    vol = Volume(id="v", name="my-data", _client=client)
    vol.upload_dir(
        str(tmp_path), remote="/data",
        progress_callback=lambda d, t: seen.append((d, t)),
    )

    # 2 files → 2 final callback firings. Total stays at 10 across all calls.
    assert len(seen) == 2
    assert {t for _, t in seen} == {10}
    # Final snapshot must equal the total — every byte accounted for.
    assert max(d for d, _ in seen) == 10


# ---------- Volume.upload_bytes ----------


@respx.mock
def test_upload_bytes_single_put(client):
    respx.post("http://test/v1/volumes/my-data/upload-url").mock(
        return_value=httpx.Response(
            200, json={"type": "single", "url": "https://s3.fake/put"}
        )
    )
    s3 = respx.put("https://s3.fake/put").mock(
        return_value=httpx.Response(200, headers={"ETag": '"e"'})
    )
    vol = Volume(id="v", name="my-data", _client=client)
    vol.upload_bytes(b"in-memory data", "/inline.bin")
    assert s3.called


def test_upload_bytes_rejects_too_large(client):
    """upload_bytes is single-PUT only — refuses payloads above the 5 GiB
    threshold rather than silently OOMing."""
    vol = Volume(id="v", name="my-data", _client=client)
    # Don't actually allocate 5 GiB — patch the limit lower.
    with patch("veri_sdk.client._VOLUME_SINGLE_PUT_LIMIT", 10):
        with pytest.raises(ValueError, match="single-PUT only"):
            vol.upload_bytes(b"too-big-payload!", "/oops.bin")


# ---------- Volume.upload_dir ----------


@respx.mock
def test_upload_dir_walks_recursively(client, tmp_path):
    """upload_dir uploads every file under the local root, preserving
    relative paths under the remote prefix."""
    (tmp_path / "a.txt").write_bytes(b"A")
    (tmp_path / "nested").mkdir()
    (tmp_path / "nested" / "b.txt").write_bytes(b"B")

    init = respx.post("http://test/v1/volumes/my-data/upload-url").mock(
        return_value=httpx.Response(
            200, json={"type": "single", "url": "https://s3.fake/put"}
        )
    )
    respx.put("https://s3.fake/put").mock(
        return_value=httpx.Response(200, headers={"ETag": '"e"'})
    )

    vol = Volume(id="v", name="my-data", _client=client)
    vol.upload_dir(str(tmp_path), remote="/data")

    # Both files got an init call.
    assert init.call_count == 2
    import json as _j
    paths = {
        _j.loads(c.request.read())["path"]
        for c in init.calls
    }
    assert paths == {"/data/a.txt", "/data/nested/b.txt"}


def test_upload_dir_rejects_non_directory(client, tmp_path):
    f = tmp_path / "file.txt"
    f.write_bytes(b"x")
    vol = Volume(id="v", name="my-data", _client=client)
    with pytest.raises(ValueError, match="not a directory"):
        vol.upload_dir(str(f))


# ---------- Volume.list_files + delete ----------


@respx.mock
def test_list_files_returns_volume_files(client):
    respx.get("http://test/v1/volumes/my-data/files").mock(
        return_value=httpx.Response(200, json={
            "object": "list",
            "data": [
                {
                    "path": "/a.txt",
                    "size_bytes": 12,
                    "modified_at": "2026-05-14T00:00:00Z",
                    "etag": "abc",
                },
                {
                    "path": "/nested/b.txt",
                    "size_bytes": 34,
                    "modified_at": "2026-05-14T00:00:00Z",
                    "etag": "def",
                },
            ],
            "has_more": False,
        })
    )
    vol = Volume(id="v", name="my-data", _client=client)
    files = vol.list_files()
    assert len(files) == 2
    assert isinstance(files[0], VolumeFile)
    assert {f.path for f in files} == {"/a.txt", "/nested/b.txt"}


@respx.mock
def test_volume_delete_calls_api(client):
    respx.delete("http://test/v1/volumes/my-data").mock(
        return_value=httpx.Response(204)
    )
    vol = Volume(id="v", name="my-data", _client=client)
    vol.delete()  # no return, no error


# ---------- Client wiring ----------


def test_client_exposes_volumes_namespace(client):
    """Client.volumes attribute is wired up."""
    assert hasattr(client, "volumes")
    assert client.volumes.create  # callable shape


# ---------- datasets.from_volume (VS-228) ----------


@respx.mock
def test_datasets_from_volume_posts_connect_with_volume_fields(client):
    """from_volume() is sugar over .connect() — verifies the body has
    source_type=volume + volume + volume_path."""
    route = respx.post("http://test/v1/datasets/connect").mock(
        return_value=httpx.Response(
            201,
            json={
                "object": "dataset",
                "id": "ds_vol1",
                "name": "corpus-train.jsonl",
                "source_type": "volume",
                "source_uri": None,
                "huggingface_dataset": None,
                "created_at": "2026-05-14T00:00:00Z",
            },
        )
    )
    ds = client.datasets.from_volume(volume="corpus", path="/train.jsonl")
    assert ds.id == "ds_vol1"
    assert ds.source_type == "volume"

    import json as _j
    body = _j.loads(route.calls.last.request.read())
    assert body["source_type"] == "volume"
    assert body["volume"] == "corpus"
    assert body["volume_path"] == "/train.jsonl"
    # Auto-derived name when not supplied: "{volume}-{path-without-leading-slash, / → -}".
    assert body["name"] == "corpus-train.jsonl"


@respx.mock
def test_datasets_from_volume_uses_explicit_name(client):
    respx.post("http://test/v1/datasets/connect").mock(
        return_value=httpx.Response(
            201,
            json={
                "object": "dataset", "id": "ds_x", "name": "my-name",
                "source_type": "volume", "source_uri": None,
                "huggingface_dataset": None,
                "created_at": "2026-05-14T00:00:00Z",
            },
        )
    )
    ds = client.datasets.from_volume(
        volume="corpus", path="/nested/deep/file.jsonl", name="my-name"
    )
    assert ds.name == "my-name"
