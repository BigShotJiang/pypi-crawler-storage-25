"""veri deployments — inference endpoint management.

Phase-1: create (config or inline), list, get, stop, chat, metrics, requests.
Phase-2 (deferred): logs, start, scale, rollback, history, load-lora.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer

from ..utils import display, errors
from ..utils.client import get_client
from ..utils.overrides import KindMismatchError, apply_overrides, load_kinded_config
from ..utils.typer_ext import VeriTyper

app = VeriTyper(name="deployments", help="Manage inference deployments.")

_COLUMNS = [
    ("id", "cyan"),
    ("name", ""),
    ("status", ""),
    ("model", ""),
    ("endpoint_url", "dim"),
    ("cost_per_hour_usd", "magenta"),
]


def _deploy_to_dict(d) -> dict:
    return {
        "id": d.id,
        "name": d.name,
        "status": d.status,
        "model": d.model,
        "source": d.source,
        "endpoint_url": d.endpoint_url or "",
        "gpu": d.gpu,
        "provider": d.provider or "",
        "cost_per_hour_usd": d.cost_per_hour_usd,
        "total_cost_usd": d.total_cost_usd,
        "total_requests": d.total_requests,
        "error": d.error or "",
    }


def _config_to_create_kwargs(cfg: dict) -> dict:
    try:
        name = cfg["deployment"]["name"]
        model = cfg["deployment"]["model"]
        gpu_type = cfg["resources"]["gpu_type"]
        gpu_count = cfg["resources"]["gpu_count"]
    except KeyError as e:
        raise errors.fail(
            f"missing required config field: {e.args[0]}. "
            f"Required: deployment.name, deployment.model, resources.gpu_type, resources.gpu_count"
        )
    source = cfg.get("deployment", {}).get("source", "training_job")
    provider = (cfg.get("provider") or {}).get("name")
    kwargs = {
        "model": model,
        "name": name,
        "gpu": {"gpu_type": gpu_type, "gpu_count": gpu_count},
        "source": source,
    }
    if provider:
        kwargs["provider"] = provider
    return kwargs


@app.command("create")
def create(
    config: Optional[Path] = typer.Argument(None, help="kind=\"deploy\" config."),
    set_: list[str] = typer.Option([], "--set"),
    set_string: list[str] = typer.Option([], "--set-string"),
    # Inline-form flags
    model: Optional[str] = typer.Option(None, "--model", help="Training job ID."),
    from_hf: Optional[str] = typer.Option(None, "--from-hf", help="HuggingFace repo."),
    name: Optional[str] = typer.Option(None, "--name"),
    gpu_type: Optional[str] = typer.Option(None, "--gpu-type"),
    gpu_count: int = typer.Option(1, "--gpu-count"),
) -> None:
    """Create an inference deployment. Config kind must be \"deploy\"."""
    if model and from_hf:
        raise errors.fail("--model and --from-hf are mutually exclusive.")

    if config is None:
        # Inline form
        if not (model or from_hf):
            raise errors.fail("inline form requires --model or --from-hf (or pass a config file).")
        if not gpu_type:
            raise errors.fail("--gpu-type is required in inline form.")
        cfg: dict = {
            "kind": "deploy",
            "deployment": {
                "name": name or "quick-deploy",
                "model": model or from_hf,
                "source": "training_job" if model else "huggingface",
            },
            "resources": {"gpu_type": gpu_type, "gpu_count": gpu_count},
        }
        apply_overrides(cfg, set_pairs=set_, set_string_pairs=set_string)
    else:
        if not config.exists():
            raise errors.fail(f"config file not found: {config}")
        # Convenience flags expand into --set BEFORE loading.
        expanded = list(set_)
        for flag_value, key in (
            (name, "deployment.name"),
            (model, "deployment.model"),
            (gpu_type, "resources.gpu_type"),
        ):
            if flag_value is not None:
                expanded.append(f"{key}={flag_value}")
        try:
            cfg = load_kinded_config(config, "deploy", expanded, set_string)
        except KindMismatchError as e:
            raise errors.fail(str(e))

    kwargs = _config_to_create_kwargs(cfg)
    client = get_client()
    dep = client.deployments.create(**kwargs)
    if display.is_quiet():
        display.render_id(dep.id)
    else:
        display.echo(f"Created {dep.id}.")
        display.render(_deploy_to_dict(dep), columns=_COLUMNS)


@app.command("list")
def list_deployments(
    limit: int = typer.Option(20, "--limit"),
    after: Optional[str] = typer.Option(None, "--after"),
    status: Optional[str] = typer.Option(None, "--status"),
) -> None:
    """List deployments."""
    client = get_client()
    items = client.deployments.list(limit=limit, after=after, status=status)
    display.render([_deploy_to_dict(d) for d in items], columns=_COLUMNS, title="deployments")


@app.command("get")
def get(dep_id: str = typer.Argument(..., metavar="ID")) -> None:
    """Show one deployment."""
    client = get_client()
    try:
        dep = client.deployments.get(dep_id)
    except Exception as e:
        raise errors.fail(f"Could not fetch deployment {dep_id}: {e}", code=errors.EXIT_API_ERROR)
    display.render(_deploy_to_dict(dep), columns=_COLUMNS)


@app.command("stop")
def stop(dep_id: str = typer.Argument(..., metavar="ID")) -> None:
    """Pause a deployment (billing pauses; container scaled to zero)."""
    client = get_client()
    client.deployments.stop(dep_id)
    display.echo(f"Stopped {dep_id}.")
    if display.is_quiet():
        display.render_id(dep_id)


@app.command("chat")
def chat(
    dep_id: str = typer.Argument(..., metavar="ID"),
    message: str = typer.Option(..., "--message", "-m"),
    model: Optional[str] = typer.Option(None, "--model"),
    temperature: float = typer.Option(1.0, "--temperature"),
    max_tokens: Optional[int] = typer.Option(None, "--max-tokens"),
) -> None:
    """Send a single chat message to the endpoint."""
    client = get_client()
    if not model:
        dep = client.deployments.get(dep_id)
        model = dep.name
    payload = client.deployments.chat(
        dep_id,
        messages=[{"role": "user", "content": message}],
        model=model,
        temperature=temperature,
        max_tokens=max_tokens,
    )
    if display.get_format() == "table":
        try:
            content = payload["choices"][0]["message"]["content"]
            display.echo(content)
        except (KeyError, IndexError):
            display.render(payload)
    else:
        display.render(payload)


@app.command("metrics")
def metrics(dep_id: str = typer.Argument(..., metavar="ID")) -> None:
    """Show RPS, latency, GPU utilization."""
    client = get_client()
    display.render(client.deployments.metrics(dep_id))


@app.command("requests")
def list_requests(
    dep_id: str = typer.Argument(..., metavar="ID"),
    limit: int = typer.Option(50, "--limit"),
    after: Optional[str] = typer.Option(None, "--after"),
) -> None:
    """Show recent inference requests."""
    client = get_client()
    rows = client.deployments.requests(dep_id, limit=limit, after=after)
    display.render(rows, columns=[("id", "cyan"), ("status_code", ""), ("latency_ms", "magenta")])
