"""veri init — scaffold a new Veri project.

Copies the bundled `templates/minimal/` tree into the target directory and
substitutes `{project_name}` in veri.toml. Refuses non-empty targets unless
`--force` is passed.
"""

from __future__ import annotations

from importlib.resources import files
from pathlib import Path
from typing import Optional

import typer

from ..utils import display, errors

_TEMPLATE_PACKAGE = "veri_sdk.cli.templates.minimal"


def _is_empty(target: Path) -> bool:
    if not target.exists():
        return True
    return not any(target.iterdir())


def _copy_template(target: Path, project_name: str) -> tuple[int, int]:
    """Copy all files from the bundled minimal template into `target`.

    Substitutes {project_name} in any file. Existing files at the destination
    are left untouched. Returns (written, skipped) counts.
    """
    source = files(_TEMPLATE_PACKAGE)
    written = 0
    skipped = 0
    # Walk recursively. Traversable doesn't have rglob, so we recurse manually.
    stack = [(source, target)]
    while stack:
        src_dir, dst_dir = stack.pop()
        dst_dir.mkdir(parents=True, exist_ok=True)
        for child in src_dir.iterdir():
            dst = dst_dir / child.name
            if child.is_dir():
                stack.append((child, dst))
            else:
                if dst.exists():
                    skipped += 1
                    continue
                content = child.read_text()
                if "{project_name}" in content:
                    content = content.replace("{project_name}", project_name)
                dst.write_text(content)
                written += 1
    return written, skipped


def init(
    name: Optional[str] = typer.Argument(
        None,
        help="Project directory name. Omit to scaffold into the current directory.",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        help="Scaffold into a non-empty directory (existing files are kept).",
    ),
) -> None:
    """Scaffold a Veri project: veri.toml + configs/ + reward.py + AGENTS.md."""
    if name:
        target = Path(name).resolve()
        project_name = target.name
    else:
        target = Path.cwd()
        project_name = target.name

    if target.exists() and not _is_empty(target) and not force:
        raise errors.fail(
            f"Target directory is not empty: {target}. "
            "Pass --force to scaffold alongside existing files.",
        )

    written, skipped = _copy_template(target, project_name)

    display.echo(f"Scaffolded {written} files into {target}.")
    if skipped:
        display.echo(f"Skipped {skipped} files that already existed.")
    display.echo("")
    display.echo("Next steps:")
    display.echo(f"  cd {target.name}" if name else "  # you're already in the project dir")
    display.echo("  veri login                          # save your API key")
    display.echo("  $EDITOR reward.py configs/train.toml")
    display.echo("  veri run configs/train.toml --dry-run")
