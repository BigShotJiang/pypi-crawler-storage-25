"""veri volumes — create, upload, list files, delete persistent storage."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    TextColumn,
    TimeRemainingColumn,
    TransferSpeedColumn,
)

from ..utils import display, errors
from ..utils.client import get_client
from ..utils.typer_ext import VeriTyper

app = VeriTyper(
    name="volumes",
    help="Manage persistent named storage — create, upload, list, delete.",
)

_VOLUME_COLUMNS = [
    ("name", "cyan"),
    ("id", "dim"),
    ("size", ""),
    ("files", ""),
    ("updated_at", "dim"),
]

_FILE_COLUMNS = [
    ("path", "cyan"),
    ("size", ""),
    ("modified_at", "dim"),
]


def _volume_to_dict(v) -> dict:
    return {
        "id": v.id,
        "name": v.name,
        "size": display.format_bytes(v.total_bytes),
        "files": v.file_count,
        "updated_at": v.updated_at or "",
    }


def _file_to_dict(f) -> dict:
    return {
        "path": f.path,
        "size": display.format_bytes(f.size_bytes),
        "modified_at": f.modified_at or "",
    }


def _progress_bar(description: str) -> Progress:
    """Rich progress bar tuned for byte transfers (rate + ETA + DownloadColumn)."""
    return Progress(
        TextColumn(f"[bold cyan]{description}"),
        BarColumn(),
        DownloadColumn(),
        TransferSpeedColumn(),
        TimeRemainingColumn(),
        transient=True,  # erase the bar on completion
    )


def _show_progress_bar() -> bool:
    """Suppress the bar under --quiet or --format other than table."""
    return not display.is_quiet() and display.get_format() == "table"


# ---------- CRUD ----------


@app.command("create")
def create(
    name: str = typer.Argument(..., metavar="NAME"),
) -> None:
    """Create a volume. Idempotent — re-running with the same name is safe."""
    client = get_client()
    vol = client.volumes.create(name)
    if display.is_quiet():
        display.render_id(vol.id)
    else:
        display.echo(f"Created {vol.name} ({vol.id}).")
        display.render(_volume_to_dict(vol), columns=_VOLUME_COLUMNS)


@app.command("list")
def list_volumes(
    limit: int = typer.Option(20, "--limit"),
    after: Optional[str] = typer.Option(None, "--after"),
) -> None:
    """List volumes."""
    client = get_client()
    items = client.volumes.list(limit=limit, after=after)
    display.render(
        [_volume_to_dict(v) for v in items],
        columns=_VOLUME_COLUMNS,
        title="volumes",
    )


@app.command("get")
def get(
    name: str = typer.Argument(..., metavar="NAME"),
) -> None:
    """Show one volume."""
    client = get_client()
    vol = client.volumes.get(name)
    display.render(_volume_to_dict(vol), columns=_VOLUME_COLUMNS)


@app.command("delete")
def delete(
    name: str = typer.Argument(..., metavar="NAME"),
    yes: bool = typer.Option(
        False, "--yes", "-y", help="Skip the confirmation prompt (for scripting)."
    ),
) -> None:
    """Delete a volume. Drops the row immediately; S3 prefix is reaped async.

    Prompts for the volume name to confirm unless --yes is passed. The data
    is gone the instant the command returns — there is no undo.
    """
    client = get_client()
    vol = client.volumes.get(name)
    if not yes:
        if vol.file_count > 0:
            Console(stderr=True).print(
                f"[yellow]Volume [bold]{vol.name}[/bold] has "
                f"[bold]{vol.file_count}[/bold] files "
                f"({display.format_bytes(vol.total_bytes)}). "
                "This will be deleted.[/yellow]"
            )
        typed = typer.prompt(f"Type the volume name to confirm")
        if typed != vol.name:
            raise errors.fail(
                f"Confirmation did not match (expected {vol.name!r}). Aborting.",
                code=errors.EXIT_USER_ERROR,
            )
    client.volumes.delete(name)
    if display.is_quiet():
        display.render_id(vol.id)
    else:
        display.echo(f"Deleted {vol.name}.")


# ---------- Files ----------


@app.command("upload")
def upload(
    volume: str = typer.Argument(..., metavar="VOLUME"),
    local: Path = typer.Argument(
        ..., exists=True, dir_okay=False, readable=True, metavar="LOCAL"
    ),
    to: str = typer.Option(
        "", "--to", help="Remote path inside the volume. Defaults to /<filename>."
    ),
) -> None:
    """Upload one file to a volume. Auto-multipart for files > 5 GiB.

    Renders a `rich.progress` byte-transfer bar (multipart parts complete in
    parallel; bar advances per-part). Suppressed under --quiet or --format
    json/jsonl/csv.
    """
    remote = to or f"/{local.name}"
    if not remote.startswith("/"):
        remote = "/" + remote
    client = get_client()
    vol = client.volumes.get(volume)

    if _show_progress_bar():
        with _progress_bar(local.name) as progress:
            task = progress.add_task("upload", total=local.stat().st_size)
            vol.upload_file(
                str(local),
                remote,
                progress_callback=lambda done, total: progress.update(
                    task, completed=done, total=total
                ),
            )
    else:
        vol.upload_file(str(local), remote)

    if display.is_quiet():
        display.render_id(remote)
    else:
        display.echo(f"Uploaded {local} → {volume}:{remote}.")


@app.command("upload-dir")
def upload_dir(
    volume: str = typer.Argument(..., metavar="VOLUME"),
    local: Path = typer.Argument(
        ..., exists=True, file_okay=False, dir_okay=True, readable=True, metavar="LOCAL_DIR"
    ),
    to: str = typer.Option(
        "/", "--to", help="Remote prefix inside the volume. Defaults to /."
    ),
) -> None:
    """Recursively upload a local directory (up to 8 files concurrent).

    Progress bar sums byte totals across all files up front, then advances
    as parts complete on any file. Same suppression rules as `upload`.
    """
    client = get_client()
    vol = client.volumes.get(volume)

    if _show_progress_bar():
        total_bytes = sum(
            p.stat().st_size for p in local.rglob("*") if p.is_file()
        )
        with _progress_bar(local.name + "/") as progress:
            task = progress.add_task("upload-dir", total=total_bytes)
            vol.upload_dir(
                str(local),
                remote=to,
                progress_callback=lambda done, total: progress.update(
                    task, completed=done, total=total
                ),
            )
    else:
        vol.upload_dir(str(local), remote=to)

    display.echo(f"Uploaded {local}/ → {volume}:{to}.")


@app.command("ls")
def ls(
    volume: str = typer.Argument(..., metavar="VOLUME"),
    prefix: str = typer.Argument("", metavar="[PATH]"),
) -> None:
    """List files inside a volume."""
    client = get_client()
    vol = client.volumes.get(volume)
    files = vol.list_files(prefix=prefix)
    display.render(
        [_file_to_dict(f) for f in files],
        columns=_FILE_COLUMNS,
        title=f"{volume}{(':' + prefix) if prefix else ''}",
    )


@app.command("rm")
def rm(
    volume: str = typer.Argument(..., metavar="VOLUME"),
    path: str = typer.Argument(..., metavar="PATH"),
) -> None:
    """Delete one file from a volume."""
    client = get_client()
    # Use the SDK's low-level HTTP client — there's no Volume.delete_file
    # method yet (intentional: file deletion is rare enough that the CLI
    # is the only caller). Keep this thin so it stays in sync with the API.
    remote = path if path.startswith("/") else "/" + path
    resp = client._http.delete(
        f"/v1/volumes/{volume}/files{remote}"
    )
    from veri_sdk.client import _raise

    _raise(resp)
    if display.is_quiet():
        display.render_id(remote)
    else:
        display.echo(f"Deleted {volume}:{remote}.")
