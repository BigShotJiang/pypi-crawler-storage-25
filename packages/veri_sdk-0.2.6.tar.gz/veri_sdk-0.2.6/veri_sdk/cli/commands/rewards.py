"""veri rewards — upload, list, get, delete.

`rewards test` is deferred to Phase-2 (depends on SDK exposing dataset row
iteration). Auto-validation on upload is AST-only — see reward_check.py
for the honest scope.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer
from rich.console import Console

from ..utils import display, errors
from ..utils.client import get_client
from ..utils.reward_check import check_reward_file
from ..utils.typer_ext import VeriTyper

app = VeriTyper(name="rewards", help="Manage reward functions.")

_COLUMNS = [("id", "cyan"), ("name", ""), ("format", "magenta")]


def _to_dict(rw) -> dict:
    return {"id": rw.id, "name": rw.name, "format": rw.format}


@app.command("upload")
def upload(
    path: Path = typer.Argument(..., exists=True, dir_okay=False, readable=True),
    name: Optional[str] = typer.Option(None, "--name"),
    format: str = typer.Option("trl", "--format", help="Reward function format."),
    skip_validation: bool = typer.Option(
        False, "--skip-validation", help="Skip the AST structural check."
    ),
) -> None:
    """Register a reward function. Auto-runs an AST check (file parses + has ≥1 function)."""
    if not skip_validation:
        ok, errs = check_reward_file(path)
        if not ok:
            console = Console(stderr=True)
            console.print("[red]Reward check failed:[/red]")
            for e in errs:
                console.print(f"  • {e}")
            console.print("\nUse --skip-validation to upload anyway.")
            raise typer.Exit(errors.EXIT_USER_ERROR)
        display.echo("Structural check OK.")

    client = get_client()
    rw = client.reward_functions.upload(str(path), name=name, format=format)
    if display.is_quiet():
        display.render_id(rw.id)
    else:
        display.echo(f"Uploaded {rw.id}.")
        display.render(_to_dict(rw), columns=_COLUMNS)


@app.command("list")
def list_rewards(
    limit: int = typer.Option(20, "--limit"),
    after: Optional[str] = typer.Option(None, "--after"),
) -> None:
    """List reward functions."""
    client = get_client()
    items = client.reward_functions.list(limit=limit, after=after)
    display.render([_to_dict(r) for r in items], columns=_COLUMNS, title="rewards")


@app.command("get")
def get(
    reward_id: str = typer.Argument(..., metavar="ID"),
) -> None:
    """Show one reward function."""
    client = get_client()
    try:
        rw = client.reward_functions.get(reward_id)
    except Exception as e:
        raise errors.fail(f"Could not fetch reward {reward_id}: {e}", code=errors.EXIT_API_ERROR)
    display.render(_to_dict(rw), columns=_COLUMNS)


@app.command("delete")
def delete(
    reward_id: str = typer.Argument(..., metavar="ID"),
) -> None:
    """Delete a reward function."""
    client = get_client()
    client.reward_functions.delete(reward_id)
    display.echo(f"Deleted {reward_id}.")
    if display.is_quiet():
        display.render_id(reward_id)
