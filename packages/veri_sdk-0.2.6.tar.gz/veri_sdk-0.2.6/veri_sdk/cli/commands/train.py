"""veri train <script.py> — execute a script with @training_job decorators.

Modal-style entry point: the CLI imports the user's script, walks the
registered @training_job (and optional @local_entrypoint) and orchestrates
upload + submission + waiting. The decorator itself is metadata only; this
command is where actual work happens.

Use the SDK directly (`client.training_jobs.create(...)`) for anything more
complex than a single-shot run.
"""

from __future__ import annotations

import importlib.util
import os
import sys
from pathlib import Path
from typing import Optional

import typer

from ..._decorators import _CLI_DRIVING_ENV, _LOCAL_ENTRYPOINTS, _TRAINING_JOBS
from ..utils import errors


def train(
    script: Path = typer.Argument(
        ...,
        exists=True,
        dir_okay=False,
        readable=True,
        help="Python file with one or more @training_job decorators.",
    ),
    function: Optional[str] = typer.Option(
        None,
        "--function",
        "-f",
        help="Pick a specific @training_job by function name when the script defines more than one.",
    ),
    detach: bool = typer.Option(
        False,
        "--detach",
        "-d",
        help=(
            "Submit the job and exit immediately. By default `veri train` "
            "stays attached and Ctrl+C cancels the GPU; --detach runs the "
            "job server-side until it completes naturally or you cancel it "
            "with `veri jobs cancel`."
        ),
    ),
) -> None:
    """Run the @training_job in `script` end-to-end (upload, submit, wait, download)."""
    _import_user_script(script)

    if _LOCAL_ENTRYPOINTS:
        if len(_LOCAL_ENTRYPOINTS) > 1:
            errors.fail(
                f"Multiple @local_entrypoint decorators in {script}. Only one is allowed."
            )
        _LOCAL_ENTRYPOINTS[0]()
        return

    if not _TRAINING_JOBS:
        errors.fail(
            f"No @training_job decorator found in {script}. "
            "Add `from veri_sdk import training_job` and decorate a reward function."
        )

    if function:
        candidates = [j for j in _TRAINING_JOBS if j.fn.__name__ == function]
        if not candidates:
            available = ", ".join(j.fn.__name__ for j in _TRAINING_JOBS)
            errors.fail(
                f"No @training_job named {function!r} in {script}. Available: {available}"
            )
        chosen = candidates[0]
    elif len(_TRAINING_JOBS) > 1:
        names = ", ".join(j.fn.__name__ for j in _TRAINING_JOBS)
        errors.fail(
            f"Multiple @training_job decorators in {script} ({names}). "
            "Pick one with --function."
        )
    else:
        chosen = _TRAINING_JOBS[0]

    chosen.train(detach=detach)


def _import_user_script(script: Path) -> None:
    """Import `script` as a module so its decorators register."""
    # Mark this run as CLI-driven so the decorator's atexit hint suppresses.
    os.environ[_CLI_DRIVING_ENV] = "1"
    spec = importlib.util.spec_from_file_location("__veri_user_script__", script)
    if spec is None or spec.loader is None:
        errors.fail(f"Could not load {script} as a Python module.")
    module = importlib.util.module_from_spec(spec)
    sys.modules["__veri_user_script__"] = module
    spec.loader.exec_module(module)
