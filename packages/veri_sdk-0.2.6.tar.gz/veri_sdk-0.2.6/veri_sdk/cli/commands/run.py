"""veri run — hero verb. Reads the `kind` field and dispatches.

A thin shortcut over the explicit `veri jobs create`, `veri deployments create`,
`veri evals create`. The contract is plural-noun-verb; `run` exists to save 13
characters on the most-common path.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import tomlkit
import typer

from ..utils import errors
from .deployments import create as deployments_create
from .evals import create as evals_create
from .jobs import create as jobs_create


_VALID_KINDS = ("train", "deploy", "eval")


def run(
    config: Path = typer.Argument(
        ...,
        exists=True,
        dir_okay=False,
        readable=True,
        help="Config file with required `kind = train|deploy|eval`.",
    ),
    set_: list[str] = typer.Option([], "--set"),
    set_string: list[str] = typer.Option([], "--set-string"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Train-only; forwarded to jobs.create."),
    follow: bool = typer.Option(False, "--follow", "-f", help="Train-only; forwarded to jobs.create."),
) -> None:
    """Run a config. Dispatches on `kind` to jobs/deployments/evals create."""
    doc = tomlkit.parse(config.read_text()).unwrap()
    kind = doc.get("kind")
    if kind is None:
        raise errors.fail(
            f"config '{config}' is missing required `kind` field. "
            f"Add one of: kind = \"train\" | \"deploy\" | \"eval\""
        )
    if kind not in _VALID_KINDS:
        raise errors.fail(
            f"config '{config}' has kind = {kind!r}; expected one of {_VALID_KINDS}",
            suggestion=errors.suggest(str(kind), _VALID_KINDS) or None,
        )

    if kind == "train":
        jobs_create(
            config=config,
            set_=set_,
            set_string=set_string,
            base_model=None,
            gpu_type=None,
            gpu_count=None,
            dataset=None,
            reward=None,
            dry_run=dry_run,
            follow=follow,
        )
    elif kind == "deploy":
        deployments_create(
            config=config,
            set_=set_,
            set_string=set_string,
            model=None,
            from_hf=None,
            name=None,
            gpu_type=None,
            gpu_count=1,
        )
    elif kind == "eval":
        evals_create(
            config=config,
            set_=set_,
            set_string=set_string,
            quick=False,
            name=None,
            dataset=None,
            model=None,
            scorer="exact-match",
            num_samples=100,
        )
