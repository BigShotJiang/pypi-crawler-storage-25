"""veri jobs — submit + manage training jobs.

Phase-1 scope: create (config or inline), list, get, cancel, download, estimate.
Phase-2 (backend-dependent): logs --follow, metrics --export, ssh, resume.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer

from ..utils import display, errors
from ..utils.client import get_client
from ..utils.overrides import KindMismatchError, apply_overrides, load_kinded_config
from ..utils.typer_ext import VeriTyper

app = VeriTyper(name="jobs", help="Manage training jobs.")

_COLUMNS = [
    ("id", "cyan"),
    ("status", ""),
    ("base_model", ""),
    ("cost_usd", "magenta"),
    ("dashboard_url", "dim"),
]


def _job_to_dict(j) -> dict:
    return {
        "id": j.id,
        "status": j.status,
        "base_model": j.base_model,
        "cost_usd": j.cost_usd,
        "dashboard_url": j.dashboard_url or "",
        "download_url": getattr(j, "download_url", None) or "",
        "error_message": getattr(j, "error_message", None) or "",
    }


def _config_to_create_kwargs(cfg: dict) -> dict:
    """Map a kind="train" TOML config to client.training_jobs.create kwargs."""
    try:
        base_model = cfg["model"]["base"]
        dataset_id = cfg["dataset"]["id"]
        gpu_type = cfg["resources"]["gpu_type"]
        gpu_count = cfg["resources"]["gpu_count"]
    except KeyError as e:
        raise errors.fail(
            f"missing required config field: {e.args[0]}. "
            f"Required: model.base, dataset.id, resources.gpu_type, resources.gpu_count"
        )

    method_cfg = dict(cfg.get("method") or {})
    method_type = method_cfg.pop("type", "grpo")
    hyperparameters = method_cfg  # whatever's left under [method] = hyperparameters

    output_name = (cfg.get("job") or {}).get("output_model", "default")
    reward_id = (cfg.get("reward") or {}).get("id")
    provider = (cfg.get("provider") or {}).get("name")
    checkpoint_destination = cfg.get("checkpoint")

    kwargs = {
        "base_model": base_model,
        "dataset_id": dataset_id,
        "output_name": output_name,
        "gpu_type": gpu_type,
        "gpu_count": gpu_count,
        "method": method_type,
        "hyperparameters": hyperparameters,
    }
    if reward_id:
        kwargs["reward_function_id"] = reward_id
    if provider:
        kwargs["provider"] = provider
    if checkpoint_destination:
        kwargs["checkpoint_destination"] = checkpoint_destination
    return kwargs


@app.command("create")
def create(
    config: Optional[Path] = typer.Argument(
        None,
        exists=False,
        help="Path to a kind=\"train\" config. Inline form available via flags.",
    ),
    # Override syntax
    set_: list[str] = typer.Option([], "--set"),
    set_string: list[str] = typer.Option([], "--set-string"),
    # Convenience flags (expand to --set internally)
    base_model: Optional[str] = typer.Option(None, "--base-model", help="Override model.base."),
    gpu_type: Optional[str] = typer.Option(None, "--gpu-type", help="Override resources.gpu_type."),
    gpu_count: Optional[int] = typer.Option(None, "--gpu-count", help="Override resources.gpu_count."),
    dataset: Optional[str] = typer.Option(None, "--dataset", help="Override dataset.id."),
    reward: Optional[str] = typer.Option(None, "--reward", help="Override reward.id."),
    # Flow control
    dry_run: bool = typer.Option(False, "--dry-run", help="Estimate cost, don't submit."),
    follow: bool = typer.Option(
        False, "--follow", "-f",
        help="Submit + immediately tail logs. (Logs Phase-2; flag accepted but no-op for now.)",
    ),
) -> None:
    """Submit a training job. Config file required unless using inline form."""
    # Expand convenience flags into --set so they flow through one merge path.
    expanded = list(set_)
    for flag_name, flag_value, key in (
        ("--base-model", base_model, "model.base"),
        ("--gpu-type", gpu_type, "resources.gpu_type"),
        ("--gpu-count", gpu_count, "resources.gpu_count"),
        ("--dataset", dataset, "dataset.id"),
        ("--reward", reward, "reward.id"),
    ):
        if flag_value is not None:
            expanded.append(f"{key}={flag_value}")

    if config is None:
        # Inline form: build a minimal config from flags.
        cfg: dict = {"kind": "train", "model": {}, "dataset": {}, "resources": {}, "reward": {}, "method": {}}
        apply_overrides(cfg, set_pairs=expanded, set_string_pairs=set_string)
        if not cfg.get("model", {}).get("base") or not cfg.get("dataset", {}).get("id"):
            raise errors.fail(
                "inline form requires --base-model AND --dataset (use --reward for RL methods)."
            )
    else:
        if not config.exists():
            raise errors.fail(f"config file not found: {config}")
        try:
            cfg = load_kinded_config(
                config,
                expected_kind="train",
                set_pairs=expanded,
                set_string_pairs=set_string,
            )
        except KindMismatchError as e:
            raise errors.fail(str(e))

    create_kwargs = _config_to_create_kwargs(cfg)

    client = get_client()

    if dry_run:
        cost = client.cost.estimate(
            gpu_type=create_kwargs["gpu_type"],
            gpu_count=create_kwargs["gpu_count"],
            duration_minutes=int(create_kwargs["hyperparameters"].get("max_steps", 100) * 1),
        )
        display.echo("[bold]Dry run[/bold] — no job submitted.")
        display.render(cost)
        return

    job = client.training_jobs.create(**create_kwargs)
    if follow:
        display.echo(
            "[yellow]--follow ignored:[/yellow] log streaming lands in Phase-2.",
            err=True,
        )
    if display.is_quiet():
        display.render_id(job.id)
    else:
        display.echo(f"Submitted {job.id}.")
        display.render(_job_to_dict(job), columns=_COLUMNS)


@app.command("list")
def list_jobs(
    limit: int = typer.Option(20, "--limit"),
    after: Optional[str] = typer.Option(None, "--after"),
    status: Optional[str] = typer.Option(None, "--status"),
    method: Optional[str] = typer.Option(None, "--method"),
) -> None:
    """List training jobs."""
    client = get_client()
    items = client.training_jobs.list(limit=limit, after=after, status=status, method=method)
    display.render([_job_to_dict(j) for j in items], columns=_COLUMNS, title="training jobs")


@app.command("get")
def get(job_id: str = typer.Argument(..., metavar="ID")) -> None:
    """Show one training job."""
    client = get_client()
    try:
        job = client.training_jobs.get(job_id)
    except Exception as e:
        raise errors.fail(f"Could not fetch job {job_id}: {e}", code=errors.EXIT_API_ERROR)
    display.render(_job_to_dict(job), columns=_COLUMNS)


@app.command("cancel")
def cancel(job_id: str = typer.Argument(..., metavar="ID")) -> None:
    """Cancel a running training job."""
    client = get_client()
    client.training_jobs.cancel(job_id)
    display.echo(f"Cancelled {job_id}.")
    if display.is_quiet():
        display.render_id(job_id)


@app.command("download")
def download(
    job_id: str = typer.Argument(..., metavar="ID"),
    output_dir: Path = typer.Option(Path("."), "--output-dir"),
) -> None:
    """Download a completed job's checkpoint."""
    client = get_client()
    job = client.training_jobs.get(job_id)
    if not getattr(job, "download_url", None):
        raise errors.fail(
            f"job {job_id} has no download URL (status: {job.status}).",
            code=errors.EXIT_USER_ERROR,
        )
    path = job.download(str(output_dir))
    display.echo(f"Downloaded to {path}.")
    if display.is_quiet():
        display.render_id(str(path))


@app.command("estimate")
def estimate(
    config: Path = typer.Argument(..., exists=True, dir_okay=False),
    set_: list[str] = typer.Option([], "--set"),
    set_string: list[str] = typer.Option([], "--set-string"),
) -> None:
    """Estimate the cost of submitting <config>. Doesn't submit."""
    try:
        cfg = load_kinded_config(config, "train", set_, set_string)
    except KindMismatchError as e:
        raise errors.fail(str(e))
    kwargs = _config_to_create_kwargs(cfg)
    client = get_client()
    cost = client.cost.estimate(
        gpu_type=kwargs["gpu_type"],
        gpu_count=kwargs["gpu_count"],
        duration_minutes=int(kwargs["hyperparameters"].get("max_steps", 100)),
    )
    display.render(cost)
