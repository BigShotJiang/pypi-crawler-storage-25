"""veri evals — evaluation runs.

Phase-1: create (config or --quick inline), list, get, delete, runs subcommand.
Phase-2: compare, tui.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer

from ..utils import display, errors
from ..utils.client import get_client
from ..utils.overrides import KindMismatchError, load_kinded_config
from ..utils.typer_ext import VeriTyper

app = VeriTyper(name="evals", help="Manage evaluations.")
runs_app = VeriTyper(name="runs", help="Inspect eval runs.")
app.add_typer(runs_app, name="runs")

_EVAL_COLUMNS = [("id", "cyan"), ("name", ""), ("dataset_id", ""), ("created_at", "dim")]
_RUN_COLUMNS = [
    ("id", "cyan"),
    ("eval_id", "dim"),
    ("model", ""),
    ("status", ""),
    ("processed_items", "magenta"),
    ("total_items", "magenta"),
]
_ITEM_COLUMNS = [
    ("id", "cyan"),
    ("item_index", "magenta"),
    ("output", ""),
    ("label", ""),
    ("latency_ms", "dim"),
]


def _eval_to_dict(e) -> dict:
    return {
        "id": e.id,
        "name": e.name,
        "dataset_id": e.dataset_id,
        "scorers": e.scorers,
        "created_at": e.created_at or "",
    }


def _run_to_dict(r) -> dict:
    return {
        "id": r.id,
        "eval_id": r.eval_id,
        "model": r.model,
        "status": r.status,
        "processed_items": r.processed_items,
        "total_items": r.total_items,
        "results": r.results,
        "error_message": r.error_message or "",
        "created_at": r.created_at or "",
        "completed_at": r.completed_at or "",
    }


def _item_to_dict(item) -> dict:
    return {
        "id": item.id,
        "item_index": item.item_index,
        "input": item.input,
        "output": item.output,
        "label": item.label or "",
        "scores": item.scores,
        "latency_ms": item.latency_ms,
    }


@app.command("create")
def create(
    config: Optional[Path] = typer.Argument(None, help="kind=\"eval\" config."),
    set_: list[str] = typer.Option([], "--set"),
    set_string: list[str] = typer.Option([], "--set-string"),
    quick: bool = typer.Option(False, "--quick", help="Inline form — skip writing a TOML."),
    name: Optional[str] = typer.Option(None, "--name"),
    dataset: Optional[str] = typer.Option(None, "--dataset"),
    model: Optional[str] = typer.Option(None, "--model"),
    scorer: str = typer.Option("exact-match", "--scorer", help="Inline scorer type."),
    num_samples: int = typer.Option(100, "--n"),
) -> None:
    """Create + (implicitly) start an eval. Config kind must be \"eval\"."""
    if quick or config is None:
        if not (dataset and model):
            raise errors.fail("inline / --quick requires --dataset AND --model.")
        scorers = [{"type": scorer, "weight": 1.0}]
        client = get_client()
        e = client.evals.create(name=name or f"quick-{scorer}", dataset_id=dataset, scorers=scorers)
        # Kick off the run.
        client.evals.runs.create(eval_id=e.id, model=model, num_samples=num_samples)
        if display.is_quiet():
            display.render_id(e.id)
        else:
            display.echo(f"Created {e.id} and started run against {model}.")
            display.render(_eval_to_dict(e), columns=_EVAL_COLUMNS)
        return

    if not config.exists():
        raise errors.fail(f"config file not found: {config}")
    try:
        cfg = load_kinded_config(config, "eval", set_, set_string)
    except KindMismatchError as e:
        raise errors.fail(str(e))
    try:
        eval_name = cfg["eval"]["name"]
        dataset_id = cfg["eval"]["dataset_id"]
        scorers = cfg["scorers"]
    except KeyError as e:
        raise errors.fail(f"missing required field: {e.args[0]}")
    if not scorers:
        raise errors.fail("at least one [[scorers]] entry is required.")

    client = get_client()
    e = client.evals.create(name=eval_name, dataset_id=dataset_id, scorers=scorers)
    # Optionally start a run if [run] is present.
    run_cfg = cfg.get("run")
    if run_cfg and run_cfg.get("model"):
        client.evals.runs.create(
            eval_id=e.id,
            model=run_cfg["model"],
            num_samples=run_cfg.get("num_samples"),
        )
        if not display.is_quiet():
            display.echo(f"Started run against {run_cfg['model']}.")

    if display.is_quiet():
        display.render_id(e.id)
    else:
        display.echo(f"Created {e.id}.")
        display.render(_eval_to_dict(e), columns=_EVAL_COLUMNS)


@app.command("list")
def list_evals(
    limit: int = typer.Option(20, "--limit"),
    after: Optional[str] = typer.Option(None, "--after"),
) -> None:
    """List evals."""
    client = get_client()
    items = client.evals.list(limit=limit, after=after)
    display.render([_eval_to_dict(e) for e in items], columns=_EVAL_COLUMNS, title="evals")


@app.command("get")
def get(eval_id: str = typer.Argument(..., metavar="ID")) -> None:
    """Show one eval."""
    client = get_client()
    try:
        e = client.evals.get(eval_id)
    except Exception as exc:
        raise errors.fail(f"Could not fetch eval {eval_id}: {exc}", code=errors.EXIT_API_ERROR)
    display.render(_eval_to_dict(e), columns=_EVAL_COLUMNS)


@app.command("delete")
def delete(eval_id: str = typer.Argument(..., metavar="ID")) -> None:
    """Delete an eval."""
    client = get_client()
    client.evals.delete(eval_id)
    display.echo(f"Deleted {eval_id}.")
    if display.is_quiet():
        display.render_id(eval_id)


# ---------- runs subcommand ----------

@runs_app.command("list")
def runs_list(
    eval_id: str = typer.Argument(..., metavar="EVAL_ID"),
    limit: int = typer.Option(20, "--limit"),
    after: Optional[str] = typer.Option(None, "--after"),
) -> None:
    """List runs of an eval."""
    client = get_client()
    items = client.evals.runs.list(eval_id, limit=limit, after=after)
    display.render([_run_to_dict(r) for r in items], columns=_RUN_COLUMNS, title=f"runs of {eval_id}")


@runs_app.command("get")
def runs_get(
    eval_id: str = typer.Argument(..., metavar="EVAL_ID"),
    run_id: str = typer.Argument(..., metavar="RUN_ID"),
) -> None:
    """Show one run."""
    client = get_client()
    r = client.evals.runs.get(eval_id, run_id)
    display.render(_run_to_dict(r), columns=_RUN_COLUMNS)


@runs_app.command("items")
def runs_items(
    eval_id: str = typer.Argument(..., metavar="EVAL_ID"),
    run_id: str = typer.Argument(..., metavar="RUN_ID"),
    limit: int = typer.Option(50, "--limit"),
    after: Optional[str] = typer.Option(None, "--after"),
) -> None:
    """List per-item outputs from a run."""
    client = get_client()
    items = client.evals.runs.items(eval_id, run_id, limit=limit, after=after)
    display.render([_item_to_dict(it) for it in items], columns=_ITEM_COLUMNS)
