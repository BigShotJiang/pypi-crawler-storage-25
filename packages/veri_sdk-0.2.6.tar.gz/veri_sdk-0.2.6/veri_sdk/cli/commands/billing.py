"""veri billing — balance, burn rate, transactions."""

from __future__ import annotations

import typer

from ..utils import display
from ..utils.client import get_client
from ..utils.typer_ext import VeriTyper

app = VeriTyper(name="billing", help="Account balance + burn rate + transactions.")


@app.command("balance")
def balance() -> None:
    """Show current credit balance."""
    client = get_client()
    display.render(client.billing.balance())


@app.command("burn-rate")
def burn_rate() -> None:
    """Show current burn rate and estimated time to exhaustion."""
    client = get_client()
    display.render(client.billing.burn_rate())


@app.command("transactions")
def transactions(limit: int = typer.Option(20, "--limit")) -> None:
    """List recent billing transactions."""
    client = get_client()
    payload = client.billing.transactions(limit=limit)
    rows = payload.get("data", payload) if isinstance(payload, dict) else payload
    display.render(rows)
