"""veri gpu — list GPU types and compare costs across providers."""

from __future__ import annotations

import typer

from ..utils import display
from ..utils.client import get_client
from ..utils.typer_ext import VeriTyper

app = VeriTyper(name="gpu", help="GPU types and cost comparison.")


@app.command("list")
def list_gpus() -> None:
    """List available GPU SKUs across providers, with current $/hr."""
    client = get_client()
    payload = client.cost.rates()
    rows = payload.get("rates", payload) if isinstance(payload, dict) else payload
    display.render(
        rows,
        columns=[
            ("gpu_type", "cyan"),
            ("provider", ""),
            ("usd_per_hour", "magenta"),
        ],
        title="GPU rates",
    )


@app.command("compare")
def compare(
    type_: str = typer.Option(..., "--type", "--gpu-type", help="GPU SKU."),
    count: int = typer.Option(1, "--count", "--gpu-count"),
    hours: float = typer.Option(1.0, "--hours", help="Duration in hours."),
) -> None:
    """Compare cost across providers for a given GPU config."""
    client = get_client()
    payload = client.cost.compare(
        gpu_type=type_,
        gpu_count=count,
        duration_minutes=int(hours * 60),
    )
    display.render(payload)
