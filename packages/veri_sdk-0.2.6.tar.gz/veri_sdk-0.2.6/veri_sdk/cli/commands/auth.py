"""Auth + config commands: login, logout, whoami, config show/set."""

from __future__ import annotations

import webbrowser
from typing import Optional

import httpx
import typer

from ..utils import browser_login as bl
from ..utils import config, display, errors, overrides
from ..utils.typer_ext import VeriTyper


def _paste_flow(api_url: str, open_browser: bool) -> str:
    """Open the API-keys page (optionally) and prompt for paste. Returns the token."""
    keys_url = api_url.replace("api.", "", 1).rstrip("/") + "/settings/api-keys"
    if open_browser:
        display.echo(f"Opening {keys_url} in your browser...")
        try:
            webbrowser.open(keys_url)
        except Exception:
            display.echo(f"  Could not open browser. Visit: {keys_url}", err=True)
    return (typer.prompt("API key", hide_input=True) or "").strip()


def login(
    token: Optional[str] = typer.Option(
        None,
        "--token",
        help="API key (vk_...). Skips the browser flow; for CI use.",
    ),
    api_url: str = typer.Option(
        config.DEFAULT_API_URL,
        "--url",
        help="API base URL.",
        hidden=True,
    ),
    paste: bool = typer.Option(
        False,
        "--paste",
        help="Use the manual paste flow (open API keys page, prompt for paste).",
    ),
    no_browser: bool = typer.Option(
        False,
        "--no-browser",
        help="Don't try to open the dashboard in a browser. Implies --paste.",
    ),
    timeout: float = typer.Option(
        bl.DEFAULT_TIMEOUT_SEC,
        "--timeout",
        help="Seconds to wait for browser authorization (default 300).",
    ),
) -> None:
    """Log in to Veri. Saves credentials to ~/.config/veri/config.toml.

    Default flow: opens dashboard /cli-login, captures the token via a local
    listener once the user authorizes. Falls back to manual paste on timeout.
    """
    if not token:
        if no_browser or paste:
            token = _paste_flow(api_url, open_browser=not no_browser)
        else:
            display.echo("Opening browser to authorize this CLI session...")
            display.echo("(Press Ctrl-C to cancel, or use `--paste` for manual entry.)")
            try:
                token = bl.browser_login(api_url, timeout=timeout)
            except TimeoutError as e:
                display.echo(f"[yellow]{e}[/yellow] Falling back to paste.", err=True)
                token = _paste_flow(api_url, open_browser=False)
            except KeyboardInterrupt:
                raise errors.fail("Login cancelled.")

    if not token or not token.startswith("vk_"):
        raise errors.fail("API key must start with 'vk_'.")

    # Verify the key with a cheap auth-required endpoint.
    try:
        resp = httpx.get(
            f"{api_url.rstrip('/')}/v1/billing/balance",
            headers={"Authorization": f"Bearer {token}"},
            timeout=10,
        )
    except httpx.HTTPError as e:
        # Don't hard-fail if the server is offline — save anyway with a warning.
        display.echo(
            f"[yellow]Warning:[/yellow] could not verify key against {api_url} ({e}).",
            err=True,
        )
    else:
        if resp.status_code in (401, 403):
            raise errors.fail("Invalid API key.", code=errors.EXIT_AUTH_ERROR)

    saved_at = config.save(api_key=token, api_url=api_url)
    display.echo(f"Logged in. Credentials saved to {saved_at}.")


def logout() -> None:
    """Remove stored credentials."""
    if config.clear():
        display.echo("Credentials removed.")
    else:
        display.echo("Not logged in (no credentials found).")


def whoami() -> None:
    """Show the active profile: user, org, balance, rate-limit headroom, versions."""
    profile = config.load()
    if not profile.get("api_key"):
        raise errors.fail(
            "Not logged in. Run 'veri login' or set VERI_API_KEY.",
            code=errors.EXIT_AUTH_ERROR,
        )

    api_url = profile["api_url"]
    masked_key = f"{profile['api_key'][:12]}…{profile['api_key'][-4:]}"

    # Pull balance + rate-limit headers via a single billing/balance call.
    info: dict = {
        "api_url": api_url,
        "api_key": masked_key,
        "config_path": str(config.config_path()),
        "active_profile": config.ACTIVE_PROFILE,
    }
    try:
        resp = httpx.get(
            f"{api_url.rstrip('/')}/v1/billing/balance",
            headers={"Authorization": f"Bearer {profile['api_key']}"},
            timeout=10,
        )
        if resp.status_code == 200:
            body = resp.json()
            info["balance_usd"] = body.get("balance_usd")
            info["org_id"] = body.get("org_id") or profile.get("org_id")
            info["plan"] = body.get("plan")
            # Rate-limit headroom if the server emits standard headers.
            for h in ("x-ratelimit-remaining", "x-ratelimit-reset"):
                if h in resp.headers:
                    info[h.replace("-", "_")] = resp.headers[h]
        elif resp.status_code in (401, 403):
            info["status"] = "invalid_or_expired_token"
        else:
            info["status"] = f"api_error_{resp.status_code}"
    except httpx.HTTPError as e:
        info["status"] = f"network_error: {e}"

    # Add CLI + SDK versions.
    try:
        from importlib.metadata import version as _v

        info["sdk_version"] = _v("veri-sdk")
    except Exception:
        info["sdk_version"] = "unknown"

    if display.get_format() == "table":
        display.render(
            [{"key": k, "value": str(v)} for k, v in info.items()],
            columns=[("key", "cyan"), ("value", "")],
            title="whoami",
        )
    else:
        display.render(info)


# ---------------------------------------------------------------------------
# `veri config show / set` sub-app
# ---------------------------------------------------------------------------

config_app = VeriTyper(name="config", help="Inspect or edit local Veri config.")


@config_app.command("show")
def config_show() -> None:
    """Print the active profile (API key masked)."""
    profile = config.load()
    if not profile:
        raise errors.fail(
            "No config found. Run 'veri login' first.",
            code=errors.EXIT_AUTH_ERROR,
        )
    if profile.get("api_key"):
        profile = dict(profile)
        profile["api_key"] = f"{profile['api_key'][:12]}…{profile['api_key'][-4:]}"
    display.render(profile)


@config_app.command("set")
def config_set(
    key_value: str = typer.Argument(
        ...,
        metavar="KEY=VALUE",
        help="Config field to set. Dotted paths like profiles.default.api_url=https://...",
    ),
) -> None:
    """Edit a config field. Same --set-style syntax as other commands."""
    if "=" not in key_value:
        raise errors.fail(
            f"Expected KEY=VALUE, got: {key_value!r}",
            suggestion="profiles.default.api_url=https://api.veri.studio",
        )

    cfg_path = config.config_path()
    cfg_path.parent.mkdir(parents=True, exist_ok=True)
    import tomlkit

    if cfg_path.exists():
        doc = tomlkit.parse(cfg_path.read_text()).unwrap()
    else:
        doc = {"active_profile": config.ACTIVE_PROFILE, "profiles": {}}

    try:
        overrides.apply_overrides(doc, set_pairs=[key_value])
    except overrides.OverrideError as e:
        raise errors.fail(str(e))

    out = tomlkit.document()
    for k, v in doc.items():
        out[k] = v
    cfg_path.write_text(tomlkit.dumps(out))
    cfg_path.chmod(0o600)
    display.echo(f"Updated {key_value.split('=')[0]} in {cfg_path}.")
