"""veri version + veri doctor — diagnostics for self-help.

doctor runs a list of checks, each returning ("pass" | "warn" | "fail", message).
Output is a table by default, JSONL via --format json. Doctor never exit-fails;
it reports. The user reads the table and acts on issues.
"""

from __future__ import annotations

import importlib.metadata
import platform
import sys
from typing import Literal

import httpx

from ..utils import config, display

CheckStatus = Literal["pass", "warn", "fail"]


def _check_python() -> tuple[CheckStatus, str]:
    major, minor = sys.version_info[:2]
    if (major, minor) < (3, 10):
        return "fail", f"Python {major}.{minor} — Veri requires >=3.10"
    return "pass", f"Python {major}.{minor}.{sys.version_info.micro}"


def _check_sdk() -> tuple[CheckStatus, str]:
    try:
        v = importlib.metadata.version("veri-sdk")
        return "pass", f"veri-sdk {v}"
    except importlib.metadata.PackageNotFoundError:
        return "fail", "veri-sdk not installed (this should never happen)"


def _check_config() -> tuple[CheckStatus, str]:
    path = config.config_path()
    if not path.exists():
        return "warn", f"No config at {path} (run 'veri login')"
    try:
        config.load()
        return "pass", str(path)
    except Exception as e:
        return "fail", f"Config at {path} is unparseable: {e}"


def _check_credentials() -> tuple[CheckStatus, str]:
    profile = config.load()
    api_key = profile.get("api_key")
    if not api_key:
        return "warn", "No credentials (run 'veri login' or set VERI_API_KEY)"
    masked = f"{api_key[:12]}…{api_key[-4:]}"
    return "pass", f"API key {masked}"


def _check_network(url: str) -> tuple[CheckStatus, str]:
    """Reach the API root. 2xx or 401/403 both mean 'server up'."""
    try:
        resp = httpx.get(f"{url.rstrip('/')}/health", timeout=5, follow_redirects=True)
    except httpx.HTTPError as e:
        return "fail", f"Cannot reach {url}: {e}"
    if resp.status_code < 500:
        return "pass", f"{url} → HTTP {resp.status_code}"
    return "fail", f"{url} → HTTP {resp.status_code}"


def _run_all_checks() -> list[dict]:
    checks: list[tuple[str, tuple[CheckStatus, str]]] = [
        ("python", _check_python()),
        ("sdk", _check_sdk()),
        ("config", _check_config()),
        ("credentials", _check_credentials()),
    ]
    profile = config.load()
    api_url = profile.get("api_url", config.DEFAULT_API_URL)
    checks.append(("network", _check_network(api_url)))

    return [
        {"check": name, "status": status, "message": message}
        for name, (status, message) in checks
    ]


_STATUS_STYLE = {"pass": "green", "warn": "yellow", "fail": "red"}


def doctor() -> None:
    """Diagnose your Veri install. Reports each check; exits 0 regardless."""
    rows = _run_all_checks()
    if display.get_format() == "table":
        styled = [
            {
                "check": r["check"],
                "status": f"[{_STATUS_STYLE[r['status']]}]{r['status']}[/{_STATUS_STYLE[r['status']]}]",
                "message": r["message"],
            }
            for r in rows
        ]
        display.render(
            styled,
            columns=[("check", "cyan"), ("status", ""), ("message", "")],
            title="veri doctor",
        )
    else:
        display.render(rows)


def version() -> None:
    """Print SDK + Python + platform info."""
    info = {
        "sdk_version": importlib.metadata.version("veri-sdk"),
        "python_version": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        "platform": platform.platform(),
    }
    if display.get_format() == "table":
        display.render(
            [{"field": k, "value": v} for k, v in info.items()],
            columns=[("field", "cyan"), ("value", "")],
            title="veri version",
        )
    else:
        display.render(info)
