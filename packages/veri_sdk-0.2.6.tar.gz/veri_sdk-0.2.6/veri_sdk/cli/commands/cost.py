"""veri cost — quick cost estimates + spend summary."""

from __future__ import annotations

from typing import Optional

import typer

from ..utils import display
from ..utils.client import get_client
from ..utils.typer_ext import VeriTyper

app = VeriTyper(name="cost", help="Cost estimates + spend summary.")


@app.command("estimate")
def estimate(
    gpu_type: str = typer.Option(..., "--gpu-type"),
    gpu_count: int = typer.Option(1, "--gpu-count"),
    hours: float = typer.Option(1.0, "--hours"),
    provider: Optional[str] = typer.Option(None, "--provider"),
) -> None:
    """Estimate the cost of a hypothetical GPU lease."""
    client = get_client()
    payload = client.cost.estimate(
        gpu_type=gpu_type,
        gpu_count=gpu_count,
        duration_minutes=int(hours * 60),
        provider=provider,
    )
    display.render(payload)


@app.command("summary")
def summary(days: int = typer.Option(30, "--days")) -> None:
    """Recent spend summary."""
    client = get_client()
    display.render(client.cost.summary(days=days))
