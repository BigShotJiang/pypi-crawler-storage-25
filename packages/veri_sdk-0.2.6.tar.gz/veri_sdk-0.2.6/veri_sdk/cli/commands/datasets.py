"""veri datasets — upload, connect, check, list, get, delete, preview."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console

from ..utils import display, errors
from ..utils.client import get_client
from ..utils.jsonl_check import check_jsonl
from ..utils.typer_ext import VeriTyper

app = VeriTyper(name="datasets", help="Manage datasets — upload, connect, list, inspect.")

_DATASET_COLUMNS = [
    ("id", "cyan"),
    ("name", ""),
    ("source_type", "magenta"),
    ("source_uri", "dim"),
    ("huggingface_dataset", "dim"),
]


def _dataset_to_dict(d) -> dict:
    return {
        "id": d.id,
        "name": d.name,
        "source_type": d.source_type,
        "source_uri": d.source_uri or "",
        "huggingface_dataset": d.huggingface_dataset or "",
    }


@app.command("upload")
def upload(
    path: Path = typer.Argument(..., exists=True, dir_okay=False, readable=True),
    name: Optional[str] = typer.Option(None, "--name", help="Display name. Defaults to filename stem."),
    skip_validation: bool = typer.Option(
        False, "--skip-validation", help="Skip the structural JSONL check."
    ),
    deep_check: bool = typer.Option(
        False, "--deep-check", help="Reserved — requires a tokenizer; not enabled yet."
    ),
) -> None:
    """Upload a JSONL dataset. Auto-runs a structural check first."""
    if not skip_validation:
        result = check_jsonl(path)
        if not result.ok:
            console = Console(stderr=True)
            console.print(f"[red]Validation failed:[/red] {result.summary()}")
            for err in result.errors:
                console.print(f"  • {err}")
            console.print("\nUse --skip-validation to upload anyway.")
            raise typer.Exit(errors.EXIT_USER_ERROR)
        display.echo(f"Structural check OK — {result.row_count} rows.")
    if deep_check:
        display.echo(
            "[yellow]--deep-check is not yet implemented[/yellow] (needs tokenizer + base model)",
            err=True,
        )

    client = get_client()
    dataset = client.datasets.upload(str(path), name=name)
    if display.is_quiet():
        display.render_id(dataset.id)
    else:
        display.echo(f"Uploaded {dataset.id}.")
        display.render(_dataset_to_dict(dataset), columns=_DATASET_COLUMNS)


@app.command("check")
def check(
    path: Path = typer.Argument(..., exists=True, dir_okay=False, readable=True),
    deep_check: bool = typer.Option(
        False, "--deep-check", help="Reserved — requires a tokenizer; not enabled yet."
    ),
) -> None:
    """Structurally validate a JSONL file. Doesn't upload."""
    result = check_jsonl(path)
    if display.get_format() == "table":
        Console().print(result.summary())
        for err in result.errors:
            Console().print(f"  • {err}")
    else:
        display.render({
            "ok": result.ok,
            "row_count": result.row_count,
            "errors": result.errors,
        })
    if not result.ok:
        raise typer.Exit(errors.EXIT_USER_ERROR)


@app.command("preview")
def preview(
    path: Path = typer.Argument(..., exists=True, dir_okay=False, readable=True),
    n: int = typer.Option(5, "--n", help="Number of rows to show."),
) -> None:
    """Print the first N rows of a local JSONL file (use `get` for registered datasets)."""
    rows: list[dict] = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            stripped = line.strip()
            if not stripped:
                continue
            try:
                rows.append(json.loads(stripped))
            except json.JSONDecodeError:
                continue
            if len(rows) >= n:
                break
    display.render(rows)


@app.command("list")
def list_datasets(
    limit: int = typer.Option(20, "--limit"),
    after: Optional[str] = typer.Option(None, "--after"),
) -> None:
    """List datasets."""
    client = get_client()
    items = client.datasets.list(limit=limit, after=after)
    display.render([_dataset_to_dict(d) for d in items], columns=_DATASET_COLUMNS, title="datasets")


@app.command("get")
def get(
    dataset_id: str = typer.Argument(..., metavar="ID"),
) -> None:
    """Show one dataset."""
    client = get_client()
    try:
        dataset = client.datasets.get(dataset_id)
    except Exception as e:
        raise errors.fail(f"Could not fetch dataset {dataset_id}: {e}", code=errors.EXIT_API_ERROR)
    display.render(_dataset_to_dict(dataset), columns=_DATASET_COLUMNS)


@app.command("delete")
def delete(
    dataset_id: str = typer.Argument(..., metavar="ID"),
) -> None:
    """Delete a dataset."""
    client = get_client()
    client.datasets.delete(dataset_id)
    display.echo(f"Deleted {dataset_id}.")
    if display.is_quiet():
        display.render_id(dataset_id)


@app.command("connect-hf")
def connect_hf(
    repo: str = typer.Argument(..., metavar="REPO", help="HF dataset, e.g. openai/gsm8k"),
    name: Optional[str] = typer.Option(None, "--name"),
    config_name: Optional[str] = typer.Option(None, "--config", help="HF dataset config (subset)."),
    split: str = typer.Option("train", "--split"),
    map_: list[str] = typer.Option(
        [],
        "--map",
        help="Column mapping: --map old=new (repeatable). e.g. --map question=prompt",
    ),
) -> None:
    """Connect a HuggingFace dataset without uploading."""
    hf_config: dict = {"split": split}
    if config_name:
        hf_config["config_name"] = config_name
    if map_:
        col_map = {}
        for entry in map_:
            if "=" not in entry:
                raise errors.fail(f"--map expects old=new, got: {entry!r}")
            old, _, new = entry.partition("=")
            col_map[old] = new
        hf_config["column_mapping"] = col_map

    client = get_client()
    dataset = client.datasets.connect(
        name=name or repo.replace("/", "-"),
        source_type="hf",
        huggingface_dataset=repo,
        huggingface_config=hf_config,
    )
    display.echo(f"Connected {dataset.id}.")
    display.render(_dataset_to_dict(dataset), columns=_DATASET_COLUMNS)


# connect-s3 and connect-postgres were removed (VS-211). The worker has no
# fetch path for non-upload/non-hf sources, so the commands advertised vapor.
