"""Veri CLI root app.

Wiring only. Each resource group lives under cli/commands/<name>.py. Foundation
utilities (--set parser, --format renderer, config loader, error helpers) live
under cli/utils/.

Entry point declared in pyproject.toml as `veri = "veri_sdk.cli.main:app"`.
"""

from __future__ import annotations

import typer

from .commands import (
    auth,
    billing,
    cost,
    datasets,
    deployments,
    doctor as doctor_cmd,
    evals,
    gpu,
    init as init_cmd,
    jobs,
    rewards,
    run as run_cmd,
    train as train_cmd,
    volumes,
)
from .utils.typer_ext import VeriTyper

app = VeriTyper(
    name="veri",
    help="Veri — RL post-training platform CLI.",
)


def _version_callback(value: bool) -> None:
    if value:
        doctor_cmd.version()
        raise typer.Exit()


@app.callback()
def _root(
    version: bool = typer.Option(
        None,
        "--version",
        "-v",
        callback=_version_callback,
        is_eager=True,
        help="Show SDK version and exit. Same output as `veri version`.",
    ),
) -> None:
    """Veri — RL post-training platform CLI."""
    return None


# Top-level auth commands (no group prefix).
app.command("login")(auth.login)
app.command("logout")(auth.logout)
app.command("whoami")(auth.whoami)
app.command("doctor")(doctor_cmd.doctor)
app.command("version")(doctor_cmd.version)
app.command("init")(init_cmd.init)
app.command("run")(run_cmd.run)
app.command("train")(train_cmd.train)

# Resource-group sub-apps.
app.add_typer(auth.config_app, name="config")
app.add_typer(datasets.app, name="datasets")
app.add_typer(rewards.app, name="rewards")
app.add_typer(jobs.app, name="jobs")
app.add_typer(deployments.app, name="deployments")
app.add_typer(evals.app, name="evals")
app.add_typer(gpu.app, name="gpu")
app.add_typer(cost.app, name="cost")
app.add_typer(billing.app, name="billing")
app.add_typer(volumes.app, name="volumes")


if __name__ == "__main__":  # pragma: no cover
    app()
