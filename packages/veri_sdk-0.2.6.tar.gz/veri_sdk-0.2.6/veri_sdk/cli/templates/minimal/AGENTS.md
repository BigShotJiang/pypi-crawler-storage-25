# AGENTS.md

Project layout for coding agents (Cursor, Claude Code, OpenHands, etc.).

## Directory contract

- `veri.toml` — project-level defaults (GPU type, base model). Inherited by all configs.
- `configs/train.toml` — training run config (`kind = "train"`).
- `configs/deploy.toml` — inference deployment config (`kind = "deploy"`).
- `configs/eval.toml` — eval run config (`kind = "eval"`).
- `reward.py` — reward function for RL training. See file for the TRL signature.
- `datasets/` — local JSONL datasets (or use `veri datasets connect-hf|connect-s3` to register external ones).
- `.veri/` — gitignored local state (cached job IDs, last-run info).

## How to run

```bash
veri run configs/train.toml        # submit a training job (kind dispatches)
veri jobs logs <id> --follow       # tail logs
veri run configs/eval.toml         # run the eval against a deployment
veri run configs/deploy.toml       # bring up an inference endpoint
```

## Conventions

- All TOML configs start with `kind = "..."` so `veri run` knows what to dispatch.
- Override config values from CLI with `--set <dotted.key>=<value>`. Use `--set-string` to force string type for numeric-looking values.
- Use `--dry-run` on `veri jobs create` to validate + estimate cost before billing.
- Default output is a Rich table. Pass `--format json` for machine output, `--quiet` for pipe-friendly ID-only output.
