# datasets/

Drop your JSONL files here, or register an external dataset with `veri datasets`.

## Upload a local JSONL

```bash
veri datasets upload train.jsonl --name my-train
```

`upload` auto-runs a structural check (schema, row count, duplicate IDs).
Use `--skip-validation` to override, `--deep-check` to also analyze token-length
distribution (requires a base model).

## Connect external sources without uploading

```bash
veri datasets connect-hf openai/gsm8k --split train
veri datasets connect-s3 s3://my-bucket/train.jsonl
veri datasets connect-postgres "postgres://..." --query "SELECT prompt, answer FROM ..."
```

## Reference a dataset in configs/train.toml

```toml
[dataset]
id = "ds_abc123"           # use a registered dataset
# OR
path = "./datasets/train.jsonl"  # local — auto-uploaded on submit
# OR
hf = "openai/gsm8k"        # connect on submit
```
