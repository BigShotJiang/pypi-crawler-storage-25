"""Client-side structural validation for JSONL datasets.

Scope: structure only. Each line parses as JSON, rows are objects, count > 0,
no duplicate `id` values (when an `id` column exists). Required columns can
be enforced via `required_columns`. Anything tokenizer-dependent (length
distribution, prompt-completion shape) is NOT here — those need a model and
belong behind `--deep-check`.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class CheckResult:
    row_count: int = 0
    errors: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.errors

    def summary(self) -> str:
        if self.ok:
            return f"OK — {self.row_count} rows."
        return f"{len(self.errors)} issue(s), {self.row_count} rows."


def check_jsonl(
    path: Path,
    *,
    required_columns: list[str] | None = None,
    max_errors: int = 20,
) -> CheckResult:
    """Validate a JSONL file structurally.

    Stops collecting new errors once `max_errors` is reached (still continues
    reading to count rows correctly, then appends a truncation message).
    """
    result = CheckResult()
    seen_ids: set[str] = set()
    truncated = False

    def add_error(msg: str) -> None:
        nonlocal truncated
        if len(result.errors) >= max_errors:
            truncated = True
            return
        result.errors.append(msg)

    with path.open("r", encoding="utf-8") as f:
        for lineno, raw in enumerate(f, start=1):
            stripped = raw.strip()
            if not stripped:
                continue

            try:
                row = json.loads(stripped)
            except json.JSONDecodeError as e:
                add_error(f"line {lineno}: invalid JSON ({e.msg})")
                continue

            if not isinstance(row, dict):
                add_error(f"line {lineno}: row must be a JSON object, got {type(row).__name__}")
                continue

            result.row_count += 1

            if required_columns:
                missing = [c for c in required_columns if c not in row]
                if missing:
                    add_error(f"line {lineno}: missing required columns: {', '.join(missing)}")

            row_id = row.get("id")
            if row_id is not None:
                if row_id in seen_ids:
                    add_error(f"line {lineno}: duplicate id {row_id!r}")
                else:
                    seen_ids.add(row_id)

    if result.row_count == 0 and not result.errors:
        result.errors.append("file is empty (no rows after stripping blank lines)")

    if truncated:
        result.errors.append(f"... (truncated; more issues exist beyond first {max_errors})")

    return result
