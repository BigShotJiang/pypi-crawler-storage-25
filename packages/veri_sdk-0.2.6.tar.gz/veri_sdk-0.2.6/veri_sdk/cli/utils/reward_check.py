"""AST-based structural check for reward function files.

Scope: file parses as Python, defines at least one function. Nothing more —
checking specific signatures (TRL vs DPO vs custom) is too brittle without
actually importing, and importing arbitrary user code in the CLI process is
worse. Honest scope > false confidence.
"""

from __future__ import annotations

import ast
from pathlib import Path


def check_reward_file(path: Path) -> tuple[bool, list[str]]:
    """Return (ok, errors). On success, errors is empty."""
    try:
        source = path.read_text()
    except OSError as e:
        return False, [f"could not read {path}: {e}"]

    try:
        tree = ast.parse(source, filename=str(path))
    except SyntaxError as e:
        return False, [f"syntax error at line {e.lineno}: {e.msg}"]

    has_function = any(
        isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        for node in ast.walk(tree)
    )
    if not has_function:
        return False, ["no function defined — reward files must declare at least one function"]

    return True, []
