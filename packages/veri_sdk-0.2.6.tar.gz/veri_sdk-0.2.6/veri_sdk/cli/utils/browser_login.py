"""Modal-style browser login.

Flow:
    1. CLI binds a local HTTP listener on 127.0.0.1:<random-port>.
    2. CLI opens the dashboard's /cli-login page with {port, state, hostname}
       as query parameters.
    3. User signs in to the dashboard (Clerk middleware) and clicks "Authorize".
    4. Dashboard creates a fresh API key, then POSTs {token, state} to
       http://127.0.0.1:<port>.
    5. CLI verifies state matches what it generated, returns the token.

Security model:
    - Listener binds 127.0.0.1 only (no external reach).
    - Random state token (256 bits) per session prevents another browser tab
      from injecting a key into a CLI listener it doesn't own.
    - Token never leaves the local machine after the dashboard POSTs it.
    - 5-minute default timeout; configurable.

CORS: the dashboard runs on a different origin (veri.studio) than the
listener (127.0.0.1:N), so the listener must respond to OPTIONS preflight
with permissive CORS headers. Acceptable because the listener is short-lived
and bound to loopback.
"""

from __future__ import annotations

import json
import secrets
import socket
import socketserver
import threading
import time
import urllib.parse
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Optional

DEFAULT_TIMEOUT_SEC = 300.0  # 5 minutes


def _make_handler(state: str, holder: dict):
    """Build a request handler that captures POSTed {token, state}.

    `holder` is a mutable dict the handler writes to. The caller polls it.
    """

    class _Handler(BaseHTTPRequestHandler):
        def _cors_headers(self) -> None:
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")

        def do_OPTIONS(self):  # noqa: N802 — http.server expected name
            self.send_response(204)
            self._cors_headers()
            self.end_headers()

        def do_POST(self):  # noqa: N802
            length = int(self.headers.get("Content-Length", 0))
            try:
                body = json.loads(self.rfile.read(length).decode())
            except (json.JSONDecodeError, UnicodeDecodeError):
                self.send_response(400)
                self._cors_headers()
                self.end_headers()
                return

            if not isinstance(body, dict) or body.get("state") != state:
                # Wrong state token — reject. Don't capture.
                self.send_response(403)
                self._cors_headers()
                self.end_headers()
                return

            token = body.get("token")
            if not isinstance(token, str) or not token:
                self.send_response(400)
                self._cors_headers()
                self.end_headers()
                return

            holder["token"] = token
            self.send_response(200)
            self._cors_headers()
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(
                b"<!doctype html><meta charset='utf-8'>"
                b"<title>Veri CLI authorized</title>"
                b"<body style='font-family:system-ui;padding:48px;color:#200D0D'>"
                b"<h2>Authorized.</h2>"
                b"<p>You can close this tab.</p>"
                b"</body>"
            )

        def log_message(self, *args, **kwargs):  # silence
            pass

    return _Handler


def _spawn_listener(holder: dict) -> tuple[HTTPServer, int, str]:
    """Bind a local listener on 127.0.0.1:0, return (server, port, state)."""
    state = secrets.token_urlsafe(32)
    handler_cls = _make_handler(state, holder)
    # Allow port reuse to avoid TIME_WAIT collisions when running tests serially.
    socketserver.TCPServer.allow_reuse_address = True
    server = HTTPServer(("127.0.0.1", 0), handler_cls)
    port = server.server_address[1]
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server, port, state


def _dashboard_origin(api_url: str) -> str:
    """`https://api.veri.studio` → `https://veri.studio`. Other URLs untouched."""
    return api_url.replace("api.", "", 1).rstrip("/")


def _wait_for_token(
    server: HTTPServer,
    holder: dict,
    timeout: float,
) -> str:
    """Poll holder until token arrives or timeout. Shuts down server before returning."""
    deadline = time.time() + timeout
    try:
        while time.time() < deadline:
            if "token" in holder:
                return holder["token"]
            time.sleep(0.1)
        raise TimeoutError(
            f"Browser login timed out after {timeout:.0f}s. "
            f"Use `veri login --token vk_...` to paste manually."
        )
    finally:
        server.shutdown()


def browser_login(
    api_url: str,
    *,
    timeout: float = DEFAULT_TIMEOUT_SEC,
    hostname: Optional[str] = None,
) -> str:
    """Run the full browser-login flow. Returns the captured API key.

    Raises TimeoutError if the user doesn't complete the flow in time.
    """
    holder: dict = {}
    server, port, state = _spawn_listener(holder)

    host = hostname or socket.gethostname()
    qs = urllib.parse.urlencode({"port": port, "state": state, "hostname": host})
    login_url = f"{_dashboard_origin(api_url)}/cli-login?{qs}"

    try:
        webbrowser.open(login_url)
    except Exception:
        pass  # `_wait_for_token` will time out; user can run with --token

    return _wait_for_token(server, holder, timeout)
