"""CLIError + 'did you mean X?' suggestions via difflib.

Exit codes:
    0   success
    1   user error (bad flag, validation)
    2   API error (4xx/5xx)
    3   network error (timeout, DNS, connection refused)
    4   auth error (401/403, missing credentials)
    130 SIGINT
"""

from __future__ import annotations

import difflib
from typing import Iterable, NoReturn

import typer
from rich.console import Console

EXIT_OK = 0
EXIT_USER_ERROR = 1
EXIT_API_ERROR = 2
EXIT_NETWORK_ERROR = 3
EXIT_AUTH_ERROR = 4


def suggest(bad: str, candidates: Iterable[str], cutoff: float = 0.6) -> str | None:
    """Return the closest match for `bad` among `candidates`, or None."""
    matches = difflib.get_close_matches(bad, list(candidates), n=1, cutoff=cutoff)
    return matches[0] if matches else None


def fail(
    message: str,
    *,
    code: int = EXIT_USER_ERROR,
    suggestion: str | None = None,
) -> "NoReturn":
    """Print error to stderr, optionally with a 'did you mean?' line, and exit."""
    console = Console(stderr=True)
    console.print(f"[red]Error:[/red] {message}")
    if suggestion:
        console.print(f"  [dim]Did you mean '{suggestion}'?[/dim]")
    raise typer.Exit(code)


def fail_unknown_id(
    bad_id: str,
    recent_ids: Iterable[str],
    *,
    resource: str = "resource",
    code: int = EXIT_USER_ERROR,
) -> "typer.Exit":
    s = suggest(bad_id, recent_ids)
    return fail(f"{resource} '{bad_id}' not found.", code=code, suggestion=s)
