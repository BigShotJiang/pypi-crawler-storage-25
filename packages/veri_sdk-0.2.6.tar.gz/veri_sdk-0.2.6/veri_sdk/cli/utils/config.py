"""XDG-correct config storage with one-time migration from legacy ~/.veri/credentials.json."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

import tomlkit
from platformdirs import user_config_dir

DEFAULT_API_URL = "https://api.veri.studio"
ACTIVE_PROFILE = "default"  # v1 hardcoded; multi-profile in Phase-2


def config_path() -> Path:
    """User config file path. Honors VERI_CONFIG_PATH > XDG_CONFIG_HOME > platformdirs default."""
    if override := os.environ.get("VERI_CONFIG_PATH"):
        return Path(override).expanduser()
    return Path(user_config_dir("veri")) / "config.toml"


def _config_path_is_default() -> bool:
    """True iff neither VERI_CONFIG_PATH nor XDG_CONFIG_HOME is set."""
    return not (os.environ.get("VERI_CONFIG_PATH") or os.environ.get("XDG_CONFIG_HOME"))


def legacy_path() -> Path:
    return Path.home() / ".veri" / "credentials.json"


def _migrated_marker() -> Path:
    return config_path().parent / ".migrated"


def _load_toml(path: Path) -> dict[str, Any]:
    return tomlkit.parse(path.read_text()).unwrap()


def load() -> dict[str, Any]:
    """Return active-profile config dict: {api_key, api_url, org_id?}.

    Migrates legacy ~/.veri/credentials.json on first run. Returns {} if no
    credentials are configured anywhere.
    """
    # Env vars take precedence over file.
    env_key = os.environ.get("VERI_API_KEY")
    env_url = os.environ.get("VERI_API_URL")

    cfg_path = config_path()
    profile: dict[str, Any] = {}

    if cfg_path.exists():
        doc = _load_toml(cfg_path)
        active = doc.get("active_profile", ACTIVE_PROFILE)
        profile = doc.get("profiles", {}).get(active, {}) or {}
    elif legacy_path().exists() and _config_path_is_default():
        # Only auto-migrate when writing to the default XDG path. If the user
        # set VERI_CONFIG_PATH or XDG_CONFIG_HOME explicitly, don't touch
        # their legacy file — they may be running tests / pointing at CI.
        profile = _migrate_legacy()

    if env_key:
        profile["api_key"] = env_key
    if env_url:
        profile["api_url"] = env_url
    profile.setdefault("api_url", DEFAULT_API_URL)
    return profile


def save(api_key: str, api_url: str = DEFAULT_API_URL, org_id: str | None = None) -> Path:
    """Write active-profile credentials to config. Returns the path written."""
    cfg_path = config_path()
    cfg_path.parent.mkdir(parents=True, exist_ok=True)

    if cfg_path.exists():
        doc = tomlkit.parse(cfg_path.read_text())
    else:
        doc = tomlkit.document()
        doc["active_profile"] = ACTIVE_PROFILE

    profiles = doc.get("profiles")
    if profiles is None:
        profiles = tomlkit.table()
        doc["profiles"] = profiles

    profile = tomlkit.table()
    profile["api_key"] = api_key
    profile["api_url"] = api_url
    if org_id:
        profile["org_id"] = org_id
    profiles[ACTIVE_PROFILE] = profile

    cfg_path.write_text(tomlkit.dumps(doc))
    cfg_path.chmod(0o600)
    return cfg_path


def clear() -> bool:
    """Remove the config file. Returns True if a file was removed."""
    cfg_path = config_path()
    if cfg_path.exists():
        cfg_path.unlink()
        return True
    return False


def _migrate_legacy() -> dict[str, Any]:
    """Move ~/.veri/credentials.json into the new TOML location. Idempotent."""
    legacy = legacy_path()
    creds = json.loads(legacy.read_text())
    api_key = creds.get("api_key", "")
    api_url = creds.get("api_url", DEFAULT_API_URL)

    save(api_key=api_key, api_url=api_url)
    backup = legacy.with_suffix(".json.bak")
    legacy.rename(backup)

    marker = _migrated_marker()
    already_migrated = marker.exists()
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.touch()

    if not already_migrated and not _suppress_banner():
        from .display import stderr  # late import to avoid cycle on first run

        stderr().print(
            f"[yellow]Migrated[/yellow] {legacy} → {config_path()} "
            f"(old file kept as {backup.name})"
        )

    return {"api_key": api_key, "api_url": api_url}


def _suppress_banner() -> bool:
    """Don't print the migration banner if we're piping JSON or running quiet."""
    try:
        from .display import get_format, is_quiet  # late import: utils not yet imported on first call
    except ImportError:
        return False
    return is_quiet() or get_format() != "table"
