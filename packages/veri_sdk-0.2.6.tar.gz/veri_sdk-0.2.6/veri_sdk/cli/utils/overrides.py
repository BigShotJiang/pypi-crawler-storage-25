"""--set <dotted.key>=<value> dotted-key TOML merger.

Used by `veri jobs create`, `veri config set`, and anywhere else the CLI
overrides nested TOML values from flags.

Type coercion: `ast.literal_eval` first (handles ints/floats/lists/None/bools),
fall back to string. Conflict detection rejects e.g. `--set foo=1 --set foo.bar=2`.
Repeated `--set tags=a --set tags=b` builds a list.
`--set-string foo=1` forces string type.
"""

from __future__ import annotations

import ast
from pathlib import Path
from typing import Any

import tomlkit


class OverrideError(ValueError):
    """Raised when --set arguments conflict or are malformed."""


def _coerce(value: str) -> Any:
    try:
        return ast.literal_eval(value)
    except (ValueError, SyntaxError):
        low = value.lower()
        if low == "true":
            return True
        if low == "false":
            return False
        if low in ("none", "null"):
            return None
        return value


def _apply(
    cfg: dict[str, Any],
    raw: str,
    coerce_fn,
    seen: dict[tuple[str, ...], str],
) -> None:
    if "=" not in raw:
        raise OverrideError(f"--set expects key=value, got: {raw!r}")
    key, _, val = raw.partition("=")
    if not key:
        raise OverrideError(f"--set has empty key: {raw!r}")
    path = tuple(key.split("."))

    # Reject scalar-vs-table conflicts (e.g. --set foo=1 then --set foo.bar=2).
    for i in range(1, len(path)):
        prefix = path[:i]
        if seen.get(prefix) == "scalar":
            raise OverrideError(
                f"--set conflict: '{'.'.join(prefix)}' is set as a scalar; "
                f"can't also set sub-key '{key}'"
            )

    node = cfg
    for part in path[:-1]:
        if not isinstance(node.get(part), dict):
            node[part] = {}
        node = node[part]

    leaf = path[-1]
    coerced = coerce_fn(val)

    if path in seen:
        existing = node.get(leaf)
        node[leaf] = (existing if isinstance(existing, list) else [existing]) + [coerced]
        seen[path] = "list"
    else:
        # If the leaf already exists as a table and we're trying to set a scalar,
        # that's also a conflict.
        if isinstance(node.get(leaf), dict):
            raise OverrideError(
                f"--set conflict: '{key}' is already a table; can't overwrite with a scalar"
            )
        node[leaf] = coerced
        seen[path] = "list" if isinstance(coerced, list) else "scalar"


def apply_overrides(
    cfg: dict[str, Any],
    set_pairs: list[str] | None = None,
    set_string_pairs: list[str] | None = None,
) -> dict[str, Any]:
    """Apply --set / --set-string flags to a parsed-TOML dict. Returns cfg (mutated)."""
    seen: dict[tuple[str, ...], str] = {}
    for raw in set_pairs or []:
        _apply(cfg, raw, _coerce, seen)
    for raw in set_string_pairs or []:
        _apply(cfg, raw, str, seen)
    return cfg


def load_config(
    path: Path,
    set_pairs: list[str] | None = None,
    set_string_pairs: list[str] | None = None,
) -> dict[str, Any]:
    """Load a TOML config file and apply --set / --set-string overrides."""
    doc = tomlkit.parse(path.read_text())
    return apply_overrides(doc.unwrap(), set_pairs, set_string_pairs)


class KindMismatchError(ValueError):
    """Raised when a config's `kind` doesn't match the command's expectation."""


def load_kinded_config(
    path: Path,
    expected_kind: str,
    set_pairs: list[str] | None = None,
    set_string_pairs: list[str] | None = None,
) -> dict[str, Any]:
    """Load a TOML config, enforce `kind = "<expected>"`, apply overrides."""
    cfg = load_config(path, set_pairs, set_string_pairs)
    kind = cfg.get("kind")
    if kind is None:
        raise KindMismatchError(
            f"config '{path}' is missing required `kind` field. "
            f"Expected: kind = \"{expected_kind}\""
        )
    if kind != expected_kind:
        raise KindMismatchError(
            f"config '{path}' has kind = {kind!r}, expected {expected_kind!r}"
        )
    return cfg
