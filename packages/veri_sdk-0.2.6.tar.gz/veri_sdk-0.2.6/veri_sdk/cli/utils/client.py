"""Build an authenticated veri_sdk.Client from the active profile."""

from __future__ import annotations

from ...client import Client
from . import config
from .errors import EXIT_AUTH_ERROR, fail


def get_client() -> Client:
    """Construct a Client using credentials from env vars or ~/.config/veri/config.toml.

    Exits with code 4 (auth) if no credentials are found.
    """
    profile = config.load()
    api_key = profile.get("api_key")
    if not api_key:
        raise fail(
            "Not logged in. Run 'veri login' or set VERI_API_KEY.",
            code=EXIT_AUTH_ERROR,
        )
    return Client(api_key=api_key, base_url=profile.get("api_url"))
