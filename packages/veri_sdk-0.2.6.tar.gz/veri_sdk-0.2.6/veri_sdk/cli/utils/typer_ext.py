"""VeriTyper — Typer subclass that injects --format/--json/--quiet onto every command.

Pattern adapted from prime_cli/utils/plain.py. Click options are spliced into
each command/group at construction time with is_eager=True callbacks that stash
values into ctx.meta, where utils.display reads them.
"""

from __future__ import annotations

import click
import typer
from typer.core import TyperCommand, TyperGroup

_FORMAT_CHOICES = click.Choice(["table", "json", "jsonl", "csv"])


def _stash_format(ctx: click.Context, _param: click.Parameter, value):
    if value is not None:
        ctx.meta["format"] = value
    return value


def _stash_json_alias(ctx: click.Context, _param: click.Parameter, value: bool):
    if value:
        ctx.meta["format"] = "json"
    return value


def _stash_quiet(ctx: click.Context, _param: click.Parameter, value: bool):
    if value:
        ctx.meta["quiet"] = True
    return value


def _build_global_options() -> list[click.Option]:
    return [
        click.Option(
            ["--format", "-o"],
            type=_FORMAT_CHOICES,
            default=None,
            is_eager=True,
            expose_value=False,
            callback=_stash_format,
            help="Output format (default: table).",
        ),
        click.Option(
            ["--json"],
            is_flag=True,
            default=False,
            is_eager=True,
            expose_value=False,
            callback=_stash_json_alias,
            help="Alias for --format json.",
        ),
        click.Option(
            ["--quiet", "-q"],
            is_flag=True,
            default=False,
            is_eager=True,
            expose_value=False,
            callback=_stash_quiet,
            help="Pipe-friendly: suppress banners and decoration.",
        ),
    ]


def _splice_globals(cmd: click.Command) -> None:
    existing = {p.name for p in cmd.params}
    for opt in _build_global_options():
        if opt.name not in existing:
            cmd.params.append(opt)


class _VeriGroup(TyperGroup):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _splice_globals(self)


class _VeriCommand(TyperCommand):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _splice_globals(self)


class VeriTyper(typer.Typer):
    """typer.Typer with --format/--json/--quiet visible on every command."""

    def __init__(self, *args, **kwargs):
        kwargs.setdefault("cls", _VeriGroup)
        kwargs.setdefault("no_args_is_help", True)
        kwargs.setdefault("context_settings", {"help_option_names": ["-h", "--help"]})
        super().__init__(*args, **kwargs)

    def command(self, *args, **kwargs):
        kwargs.setdefault("cls", _VeriCommand)
        return super().command(*args, **kwargs)
