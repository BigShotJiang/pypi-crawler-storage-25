"""Veri Python SDK client."""

from __future__ import annotations

import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable

import httpx


# VS-218 Part A — typed error surface so users see the server's actual
# message instead of `HTTPStatusError: Client error '400'`.

class VeriError(Exception):
    """Base class for every error raised by the Veri SDK."""


class VeriRequestError(VeriError):
    """4xx with no more specific subclass — typically 400 Bad Request."""


class VeriAuthError(VeriError):
    """401 Unauthorized — credentials missing or expired."""


class VeriNotFoundError(VeriError):
    """404 Not Found."""


class VeriServerError(VeriError):
    """5xx — the request was valid but the server failed."""


def _raise(resp: httpx.Response) -> None:
    """Convert an httpx response into a typed VeriError if it's a failure.

    Prefers the server's structured message (`error.message`, then `message`,
    then plain text). Routes by status code so callers can catch specifically
    (e.g. `except VeriAuthError:` to re-prompt for login). Success responses
    pass through unchanged.
    """
    if resp.is_success:
        return
    msg = ""
    try:
        body = resp.json()
        if isinstance(body, dict):
            err = body.get("error")
            if isinstance(err, dict):
                msg = err.get("message") or ""
            elif isinstance(err, str):
                msg = err
            if not msg:
                msg = body.get("message") or ""
    except (ValueError, httpx.DecodingError):
        pass
    if not msg:
        msg = (resp.text or "").strip()
    if not msg:
        msg = f"HTTP {resp.status_code}"

    if resp.status_code == 401:
        raise VeriAuthError(f"{msg} (run `veri login` if your token expired)")
    if resp.status_code == 404:
        raise VeriNotFoundError(msg)
    if 500 <= resp.status_code < 600:
        raise VeriServerError(msg)
    if 400 <= resp.status_code < 500:
        raise VeriRequestError(msg)
    raise VeriError(msg)


@dataclass
class Dataset:
    id: str
    name: str
    source_type: str = "upload"
    source_uri: str | None = None
    huggingface_dataset: str | None = None


@dataclass
class RewardFunction:
    id: str
    name: str
    format: str = "trl"


@dataclass
class TrainingJob:
    id: str
    status: str
    base_model: str
    dashboard_url: str | None
    download_url: str | None
    error: dict | None
    cost_usd: float | None
    _client: "Client"

    @property
    def error_message(self) -> str | None:
        if self.error:
            return self.error.get("message")
        return None

    def wait(self, poll_interval: int = 10, timeout: int = 86400) -> "TrainingJob":
        """Poll until job completes or fails."""
        start = time.time()
        while time.time() - start < timeout:
            job = self._client.training_jobs.get(self.id)
            self.status = job.status
            self.dashboard_url = job.dashboard_url
            self.download_url = job.download_url
            self.error = job.error

            if self.status in ("completed", "failed", "cancelled"):
                return self
            time.sleep(poll_interval)
        raise TimeoutError(f"Job {self.id} did not complete within {timeout}s")

    def download(self, output_dir: str) -> str:
        """Download the final HF checkpoint."""
        if not self.download_url:
            raise ValueError("No download URL — job may not be completed")
        resp = httpx.get(self.download_url, follow_redirects=True)
        _raise(resp)
        out = Path(output_dir) / f"{self.id}"
        out.mkdir(parents=True, exist_ok=True)
        (out / "model.safetensors").write_bytes(resp.content)
        return str(out)


@dataclass
class Deployment:
    id: str
    status: str
    name: str
    model: str
    source: str
    endpoint_url: str | None
    gpu: dict | None
    provider: str | None
    cost_per_hour_usd: float | None
    total_cost_usd: float | None
    total_requests: int
    error: str | None
    _client: "Client"

    def wait(self, poll_interval: int = 10, timeout: int = 3600) -> "Deployment":
        """Poll until deployment is serving (or reaches a terminal failure state)."""
        start = time.time()
        while time.time() - start < timeout:
            dep = self._client.deployments.get(self.id)
            self.status = dep.status
            self.endpoint_url = dep.endpoint_url
            self.error = dep.error
            if self.status in ("serving", "failed", "stopped"):
                return self
            time.sleep(poll_interval)
        raise TimeoutError(f"Deployment {self.id} did not reach serving within {timeout}s")

    def stop(self) -> "Deployment":
        return self._client.deployments.stop(self.id)

    def chat(
        self,
        messages: list[dict],
        *,
        model: str | None = None,
        temperature: float = 1.0,
        max_tokens: int | None = None,
    ) -> dict:
        """Send an OpenAI-compatible chat/completions request to this deployment."""
        return self._client.deployments.chat(
            self.id,
            messages=messages,
            model=model or self.name,
            temperature=temperature,
            max_tokens=max_tokens,
        )

    def metrics(self) -> dict:
        return self._client.deployments.metrics(self.id)

    def requests(self, limit: int = 50, after: str | None = None) -> list[dict]:
        return self._client.deployments.requests(self.id, limit=limit, after=after)


class _Datasets:
    def __init__(self, http: httpx.Client):
        self._http = http

    def upload(self, path: str, name: str | None = None) -> Dataset:
        p = Path(path)
        name = name or p.stem
        with open(p, "rb") as f:
            resp = self._http.post(
                "/v1/datasets",
                data={"name": name},
                files={"file": (p.name, f, "application/jsonl")},
            )
        _raise(resp)
        return self._parse(resp.json())

    def get(self, dataset_id: str) -> Dataset:
        resp = self._http.get(f"/v1/datasets/{dataset_id}")
        _raise(resp)
        return self._parse(resp.json())

    def list(self, limit: int = 20, after: str | None = None) -> list[Dataset]:
        params: dict = {"limit": limit}
        if after:
            params["after"] = after
        resp = self._http.get("/v1/datasets", params=params)
        _raise(resp)
        return [self._parse(d) for d in resp.json()["data"]]

    def connect(
        self,
        name: str,
        source_type: str = "hf",
        huggingface_dataset: str | None = None,
        huggingface_config: dict | None = None,
        volume: str | None = None,
        volume_path: str | None = None,
        credentials: dict | None = None,
    ) -> Dataset:
        """Connect a data source as a Dataset.

        `source_type="hf"`: HuggingFace Hub.
        `source_type="volume"`: file inside an existing Veri Volume (VS-228);
        worker mounts the volume and reads from /mnt/<volume><volume_path>.
        S3 / GCS / Azure / SQL sources were removed (VS-211).
        """
        body: dict = {"name": name, "source_type": source_type}
        if huggingface_dataset:
            body["huggingface_dataset"] = huggingface_dataset
        if huggingface_config:
            body["huggingface_config"] = huggingface_config
        if volume:
            body["volume"] = volume
        if volume_path:
            body["volume_path"] = volume_path
        if credentials:
            body["credentials"] = credentials
        resp = self._http.post("/v1/datasets/connect", json=body)
        _raise(resp)
        return self._parse(resp.json())

    def from_volume(
        self,
        volume: str,
        path: str,
        name: str | None = None,
    ) -> Dataset:
        """Create a Dataset that points at a file inside an existing Volume.

        Sugar over `.connect(source_type="volume", ...)`. Default name is
        `<volume>-<path-slug>` (e.g. `corpus-train-jsonl`).
        """
        derived = name or f"{volume}-{path.lstrip('/').replace('/', '-')}"
        return self.connect(
            name=derived,
            source_type="volume",
            volume=volume,
            volume_path=path,
        )

    def validate(self, **kwargs) -> dict:
        resp = self._http.post("/v1/datasets/connect/validate", json=kwargs)
        _raise(resp)
        return resp.json()

    def delete(self, dataset_id: str) -> None:
        resp = self._http.delete(f"/v1/datasets/{dataset_id}")
        _raise(resp)

    def _parse(self, d: dict) -> Dataset:
        return Dataset(
            id=d["id"], name=d["name"],
            source_type=d.get("source_type", "upload"),
            source_uri=d.get("source_uri"),
            huggingface_dataset=d.get("huggingface_dataset"),
        )


class _RewardFunctions:
    def __init__(self, http: httpx.Client):
        self._http = http

    def upload(self, path: str, name: str | None = None, format: str = "trl") -> RewardFunction:
        p = Path(path)
        name = name or p.stem
        with open(p, "rb") as f:
            resp = self._http.post(
                "/v1/reward_functions",
                data={"name": name, "format": format},
                files={"file": (p.name, f, "text/x-python")},
            )
        _raise(resp)
        d = resp.json()
        return RewardFunction(id=d["id"], name=d["name"], format=d.get("format", "trl"))

    def get(self, reward_id: str) -> RewardFunction:
        resp = self._http.get(f"/v1/reward_functions/{reward_id}")
        _raise(resp)
        d = resp.json()
        return RewardFunction(id=d["id"], name=d["name"], format=d.get("format", "trl"))

    def list(self, limit: int = 20, after: str | None = None) -> list[RewardFunction]:
        params: dict = {"limit": limit}
        if after:
            params["after"] = after
        resp = self._http.get("/v1/reward_functions", params=params)
        _raise(resp)
        return [
            RewardFunction(id=d["id"], name=d["name"], format=d.get("format", "trl"))
            for d in resp.json()["data"]
        ]

    def delete(self, reward_id: str) -> None:
        resp = self._http.delete(f"/v1/reward_functions/{reward_id}")
        _raise(resp)


class _TrainingJobs:
    def __init__(self, http: httpx.Client, client: "Client"):
        self._http = http
        self._client = client

    def create(
        self,
        base_model: str,
        dataset_id: str,
        output_name: str = "default",
        *,
        gpu_type: str,
        gpu_count: int,
        reward_function_id: str | None = None,
        method: str = "grpo",
        hyperparameters: dict | None = None,
        provider: str | None = None,
        checkpoint_destination: dict | None = None,
        requires_heartbeat: bool = True,
        volume: str | None = None,
    ) -> TrainingJob:
        body: dict = {
            "base_model": base_model,
            "dataset_id": dataset_id,
            "output_name": output_name,
            "method": method,
            "hyperparameters": hyperparameters or {},
            "gpu": {"gpu_type": gpu_type, "gpu_count": gpu_count},
            "checkpoint_destination": checkpoint_destination or {"type": "veri"},
            "requires_heartbeat": requires_heartbeat,
        }
        if reward_function_id:
            body["reward_function_id"] = reward_function_id
        if provider:
            body["provider"] = provider
        if volume:
            body["volume"] = volume
        resp = self._http.post("/v1/training_jobs", json=body)
        _raise(resp)
        return self._parse(resp.json())

    def get(self, job_id: str) -> TrainingJob:
        resp = self._http.get(f"/v1/training_jobs/{job_id}")
        _raise(resp)
        return self._parse(resp.json())

    def list(self, limit: int = 20, after: str | None = None, status: str | None = None, method: str | None = None) -> list[TrainingJob]:
        params: dict = {"limit": limit}
        if after:
            params["after"] = after
        if status:
            params["status"] = status
        if method:
            params["method"] = method
        resp = self._http.get("/v1/training_jobs", params=params)
        _raise(resp)
        return [self._parse(d) for d in resp.json()["data"]]

    def cancel(self, job_id: str) -> TrainingJob:
        resp = self._http.post(f"/v1/training_jobs/{job_id}/cancel")
        _raise(resp)
        return self._parse(resp.json())

    def heartbeat(self, job_id: str) -> dict:
        """VS-218 Part D: ping the server's liveness endpoint.

        Called every ~30s by the SDK's _heartbeat_loop while a `veri train`
        is waiting. If we stop pinging, the reconciler reaps the pod
        after settings.heartbeat_timeout_seconds (default 300s).
        """
        resp = self._http.post(f"/v1/training_jobs/{job_id}/heartbeat")
        _raise(resp)
        return resp.json()

    def _parse(self, d: dict) -> TrainingJob:
        return TrainingJob(
            id=d["id"],
            status=d["status"],
            base_model=d["base_model"],
            dashboard_url=d.get("dashboard_url"),
            download_url=d.get("download_url"),
            error=d.get("error"),
            cost_usd=d.get("cost_usd"),
            _client=self._client,
        )


class _Cost:
    def __init__(self, http: httpx.Client):
        self._http = http

    def estimate(
        self,
        gpu_type: str,
        gpu_count: int = 1,
        duration_minutes: int = 60,
        provider: str | None = None,
        markup: float = 1.3,
    ) -> dict:
        """Estimate job cost before submission."""
        params = {
            "gpu_type": gpu_type,
            "gpu_count": gpu_count,
            "duration_minutes": duration_minutes,
            "markup": markup,
        }
        if provider:
            params["provider"] = provider
        resp = self._http.get("/v1/cost/estimate", params=params)
        _raise(resp)
        return resp.json()

    def rates(self) -> dict:
        """Get all GPU rates across providers."""
        resp = self._http.get("/v1/cost/rates")
        _raise(resp)
        return resp.json()

    def summary(self, days: int = 30) -> dict:
        """Get spend summary for the authenticated user."""
        resp = self._http.get("/v1/cost/summary", params={"days": days})
        _raise(resp)
        return resp.json()

    def compare(self, gpu_type: str, gpu_count: int = 1, duration_minutes: int = 60) -> dict:
        """Compare cost across providers for a given GPU config."""
        resp = self._http.get("/v1/cost/compare", params={
            "gpu_type": gpu_type, "gpu_count": gpu_count, "duration_minutes": duration_minutes,
        })
        _raise(resp)
        return resp.json()


class _Deployments:
    def __init__(self, http: httpx.Client, client: "Client"):
        self._http = http
        self._client = client

    def create(
        self,
        model: str,
        name: str,
        *,
        gpu: dict,
        source: str = "training_job",
        provider: str | None = None,
    ) -> Deployment:
        """Create an inference deployment.

        Args:
            model: Training job ID (when source="training_job") or HuggingFace
                model name (when source="huggingface").
            name: Display name for the endpoint.
            gpu: {"gpu_type": str, "gpu_count": int}.
            source: "training_job" or "huggingface".
            provider: Optional compute provider; auto-selects if omitted.
        """
        body: dict = {
            "model": model,
            "name": name,
            "source": source,
            "gpu": gpu,
        }
        if provider:
            body["provider"] = provider
        resp = self._http.post("/v1/deployments", json=body)
        _raise(resp)
        return self._parse(resp.json())

    def get(self, deployment_id: str) -> Deployment:
        resp = self._http.get(f"/v1/deployments/{deployment_id}")
        _raise(resp)
        return self._parse(resp.json())

    def list(
        self,
        limit: int = 20,
        after: str | None = None,
        status: str | None = None,
    ) -> list[Deployment]:
        params: dict = {"limit": limit}
        if after:
            params["after"] = after
        if status:
            params["status"] = status
        resp = self._http.get("/v1/deployments", params=params)
        _raise(resp)
        return [self._parse(d) for d in resp.json()["data"]]

    def stop(self, deployment_id: str) -> Deployment:
        resp = self._http.post(f"/v1/deployments/{deployment_id}/stop")
        _raise(resp)
        return self._parse(resp.json())

    def chat(
        self,
        deployment_id: str,
        messages: list[dict],
        *,
        model: str,
        temperature: float = 1.0,
        max_tokens: int | None = None,
    ) -> dict:
        body: dict = {"model": model, "messages": messages, "temperature": temperature}
        if max_tokens is not None:
            body["max_tokens"] = max_tokens
        resp = self._http.post(
            f"/v1/deployments/{deployment_id}/chat/completions", json=body
        )
        _raise(resp)
        return resp.json()

    def metrics(self, deployment_id: str) -> dict:
        resp = self._http.get(f"/v1/deployments/{deployment_id}/metrics")
        _raise(resp)
        return resp.json()

    def requests(
        self, deployment_id: str, limit: int = 50, after: str | None = None
    ) -> list[dict]:
        params: dict = {"limit": limit}
        if after:
            params["after"] = after
        resp = self._http.get(
            f"/v1/deployments/{deployment_id}/requests", params=params
        )
        _raise(resp)
        return resp.json()["data"]

    def _parse(self, d: dict) -> Deployment:
        return Deployment(
            id=d["id"],
            status=d["status"],
            name=d["name"],
            model=d["model"],
            source=d["source"],
            endpoint_url=d.get("endpoint_url"),
            gpu=d.get("gpu"),
            provider=d.get("provider"),
            cost_per_hour_usd=d.get("cost_per_hour_usd"),
            total_cost_usd=d.get("total_cost_usd"),
            total_requests=d.get("total_requests", 0),
            error=d.get("error"),
            _client=self._client,
        )


class _Billing:
    def __init__(self, http: httpx.Client):
        self._http = http

    def balance(self) -> dict:
        """Get current credit balance."""
        resp = self._http.get("/v1/billing/balance")
        _raise(resp)
        return resp.json()

    def transactions(self, limit: int = 20) -> dict:
        """Get recent billing transactions."""
        resp = self._http.get("/v1/billing/transactions", params={"limit": limit})
        _raise(resp)
        return resp.json()

    def burn_rate(self) -> dict:
        """Get current burn rate and estimated time remaining."""
        resp = self._http.get("/v1/billing/burn_rate")
        _raise(resp)
        return resp.json()


@dataclass
class Eval:
    id: str
    name: str
    dataset_id: str
    scorers: list[dict]
    created_at: str | None = None


@dataclass
class EvalRun:
    id: str
    eval_id: str
    model: str
    status: str
    processed_items: int | None = None
    total_items: int | None = None
    results: dict | None = None
    error_message: str | None = None
    created_at: str | None = None
    completed_at: str | None = None
    _client: "Client | None" = None

    def wait(self, poll_interval: float = 5.0, timeout: float | None = None) -> "EvalRun":
        if self._client is None:
            raise RuntimeError("EvalRun is detached from a Client; call client.evals.runs.wait() instead.")
        return self._client.evals.runs.wait(
            self.eval_id, self.id, poll_interval=poll_interval, timeout=timeout
        )


@dataclass
class EvalRunItem:
    id: str
    run_id: str
    item_index: int
    input: str
    output: str
    label: str | None
    scores: dict
    latency_ms: float | None = None


class _EvalRuns:
    def __init__(self, http: httpx.Client, client: "Client"):
        self._http = http
        self._client = client

    def create(
        self,
        eval_id: str,
        model: str,
        *,
        num_samples: int | None = None,
        generation_params: dict | None = None,
    ) -> EvalRun:
        body: dict = {"model": model}
        if num_samples is not None:
            body["num_samples"] = num_samples
        if generation_params is not None:
            body["generation_params"] = generation_params
        resp = self._http.post(f"/v1/evals/{eval_id}/runs", json=body)
        _raise(resp)
        return self._parse(resp.json())

    def get(self, eval_id: str, run_id: str) -> EvalRun:
        resp = self._http.get(f"/v1/evals/{eval_id}/runs/{run_id}")
        _raise(resp)
        return self._parse(resp.json())

    def list(
        self, eval_id: str, limit: int = 20, after: str | None = None
    ) -> list[EvalRun]:
        params: dict = {"limit": limit}
        if after:
            params["after"] = after
        resp = self._http.get(f"/v1/evals/{eval_id}/runs", params=params)
        _raise(resp)
        return [self._parse(d) for d in resp.json()["data"]]

    def items(
        self,
        eval_id: str,
        run_id: str,
        limit: int = 50,
        after: str | None = None,
    ) -> list[EvalRunItem]:
        params: dict = {"limit": limit}
        if after is not None:
            params["after"] = after
        resp = self._http.get(f"/v1/evals/{eval_id}/runs/{run_id}/items", params=params)
        _raise(resp)
        return [
            EvalRunItem(
                id=d["id"],
                run_id=d["run_id"],
                item_index=d["item_index"],
                input=d["input"],
                output=d["output"],
                label=d.get("label"),
                scores=d.get("scores") or {},
                latency_ms=d.get("latency_ms"),
            )
            for d in resp.json()["data"]
        ]

    def cancel(self, eval_id: str, run_id: str) -> EvalRun:
        resp = self._http.post(f"/v1/evals/{eval_id}/runs/{run_id}/cancel")
        _raise(resp)
        return self._parse(resp.json())

    def wait(
        self,
        eval_id: str,
        run_id: str,
        poll_interval: float = 5.0,
        timeout: float | None = None,
    ) -> EvalRun:
        """Poll GET /v1/evals/{id}/runs/{run_id} until terminal."""
        start = time.time()
        terminal = {"completed", "failed", "cancelled"}
        while True:
            run = self.get(eval_id, run_id)
            if run.status in terminal:
                return run
            if timeout is not None and (time.time() - start) > timeout:
                raise TimeoutError(
                    f"Run {run_id} did not reach terminal state within {timeout}s "
                    f"(last status: {run.status})"
                )
            time.sleep(poll_interval)

    def _parse(self, d: dict) -> EvalRun:
        return EvalRun(
            id=d["id"],
            eval_id=d["eval_id"],
            model=d["model"],
            status=d["status"],
            processed_items=d.get("processed_items"),
            total_items=d.get("total_items"),
            results=d.get("results"),
            error_message=d.get("error_message"),
            created_at=d.get("created_at"),
            completed_at=d.get("completed_at"),
            _client=self._client,
        )


class _Evals:
    def __init__(self, http: httpx.Client, client: "Client"):
        self._http = http
        self._client = client
        self.runs = _EvalRuns(http, client)

    def create(
        self,
        name: str,
        dataset_id: str,
        scorers: list[dict],
        *,
        generation_params: dict | None = None,
    ) -> Eval:
        body: dict = {"name": name, "dataset_id": dataset_id, "scorers": scorers}
        if generation_params is not None:
            body["generation_params"] = generation_params
        resp = self._http.post("/v1/evals", json=body)
        _raise(resp)
        return self._parse(resp.json())

    def get(self, eval_id: str) -> Eval:
        resp = self._http.get(f"/v1/evals/{eval_id}")
        _raise(resp)
        return self._parse(resp.json())

    def list(self, limit: int = 20, after: str | None = None) -> list[Eval]:
        params: dict = {"limit": limit}
        if after:
            params["after"] = after
        resp = self._http.get("/v1/evals", params=params)
        _raise(resp)
        return [self._parse(d) for d in resp.json()["data"]]

    def delete(self, eval_id: str) -> None:
        resp = self._http.delete(f"/v1/evals/{eval_id}")
        _raise(resp)

    def _parse(self, d: dict) -> Eval:
        return Eval(
            id=d["id"],
            name=d["name"],
            dataset_id=d["dataset_id"],
            scorers=d.get("scorers") or [],
            created_at=d.get("created_at"),
        )


# ---- Volumes (VS-226) ----
#
# Server-side URL signing means the SDK only needs parallel HTTP PUTs.
# We use httpx + ThreadPoolExecutor instead of boto3.S3Transfer because:
#   1. URLs are already signed by the server — no SigV4 work for the client
#   2. boto3 + botocore + s3transfer = ~15 MB of deps for `pip install veri-sdk`
#   3. ThreadPoolExecutor is stdlib; httpx is already a core dep
# S3 multipart limits: 5 GiB single-PUT cap, 1..10,000 parts, 5 MiB min part.

_VOLUME_SINGLE_PUT_LIMIT = 5 * 1024 * 1024 * 1024   # 5 GiB
_VOLUME_UPLOAD_PARALLELISM = 8                       # threads for upload_dir + parts


@dataclass
class VolumeFile:
    """One file inside a volume — what `list_files()` returns."""
    path: str
    size_bytes: int
    modified_at: datetime | None = None
    etag: str = ""


@dataclass
class Volume:
    id: str
    name: str
    total_bytes: int = 0
    file_count: int = 0
    created_at: datetime | None = None
    updated_at: datetime | None = None
    _client: "Client" = field(default=None, repr=False)  # type: ignore[assignment]

    def upload_file(
        self,
        local: str,
        remote: str,
        *,
        progress_callback: Callable[[int, int], None] | None = None,
    ) -> None:
        """Upload one local file. Single-PUT if <=5 GiB, multipart otherwise.

        `remote` must start with `/` and may contain nested directories
        (e.g. `/data/train.jsonl`).

        `progress_callback(bytes_uploaded, total_bytes)` is invoked after each
        part finishes (multipart) or once on completion (single-PUT). The
        callback runs on the executor thread; the CLI wires it to
        `rich.progress` which is thread-safe.
        """
        assert self._client is not None, "Volume must be attached to a Client"
        path = Path(local)
        size = path.stat().st_size

        init = self._client._http.post(
            f"/v1/volumes/{self.name}/upload-url",
            json={"path": remote, "size_bytes": size},
        )
        _raise(init)
        init_body = init.json()

        if init_body["type"] == "single":
            with open(path, "rb") as fh:
                put = httpx.put(init_body["url"], content=fh, timeout=None)
            if put.status_code >= 300:
                raise VeriError(
                    f"S3 PUT failed for {remote}: HTTP {put.status_code} {put.text[:200]}"
                )
            if progress_callback:
                progress_callback(size, size)
            return

        # Multipart: slice the file, upload parts in parallel, complete.
        upload_id = init_body["upload_id"]
        part_size = init_body["part_size"]
        complete_url = init_body["complete_url"]
        num_parts = (size + part_size - 1) // part_size

        # Thread-safe accumulator for the progress callback. Per-part bytes
        # are summed under the lock so the callback always sees monotonic
        # values even with 8 concurrent part completions.
        progress_lock = threading.Lock()
        bytes_done = 0

        def _upload_part(part_number: int) -> dict:
            nonlocal bytes_done
            offset = (part_number - 1) * part_size
            length = min(part_size, size - offset)
            with open(path, "rb") as fh:
                fh.seek(offset)
                data = fh.read(length)
            url_resp = self._client._http.post(
                f"/v1/volumes/{self.name}/upload-url/part",
                json={"path": remote, "upload_id": upload_id, "part_number": part_number},
            )
            _raise(url_resp)
            put = httpx.put(url_resp.json()["url"], content=data, timeout=None)
            if put.status_code >= 300:
                raise VeriError(
                    f"S3 part {part_number} PUT failed: HTTP {put.status_code}"
                )
            etag = put.headers.get("ETag", "").strip('"')
            if not etag:
                raise VeriError(f"S3 part {part_number} response missing ETag")
            if progress_callback:
                with progress_lock:
                    bytes_done += length
                    snapshot = bytes_done
                progress_callback(snapshot, size)
            return {"number": part_number, "etag": etag}

        parts: list[dict] = []
        try:
            with ThreadPoolExecutor(max_workers=_VOLUME_UPLOAD_PARALLELISM) as pool:
                futures = [pool.submit(_upload_part, n) for n in range(1, num_parts + 1)]
                for fut in as_completed(futures):
                    parts.append(fut.result())
        except Exception:
            # Best-effort abort so we don't leave dangling parts. The 7-day
            # AbortIncompleteMultipartUpload lifecycle rule on the bucket
            # backstops this if the SDK crashes too.
            try:
                self._client._http.post(
                    f"/v1/volumes/{self.name}/upload-url/abort",
                    json={"path": remote, "upload_id": upload_id},
                )
            except Exception:
                pass
            raise

        complete = self._client._http.post(
            complete_url,
            json={"path": remote, "upload_id": upload_id, "parts": parts},
        )
        _raise(complete)

    def upload_bytes(self, data: bytes, remote: str) -> None:
        """In-memory upload for small files. Always single-PUT — multi-GB
        bytes in RAM is not a path we want to encourage."""
        assert self._client is not None
        if len(data) > _VOLUME_SINGLE_PUT_LIMIT:
            raise ValueError(
                f"upload_bytes is single-PUT only (max {_VOLUME_SINGLE_PUT_LIMIT} bytes). "
                f"Write to disk and use upload_file() for {len(data):,} bytes."
            )
        init = self._client._http.post(
            f"/v1/volumes/{self.name}/upload-url",
            json={"path": remote, "size_bytes": len(data)},
        )
        _raise(init)
        url = init.json()["url"]
        put = httpx.put(url, content=data, timeout=None)
        if put.status_code >= 300:
            raise VeriError(f"S3 PUT failed for {remote}: HTTP {put.status_code}")

    def upload_dir(
        self,
        local: str,
        remote: str = "/",
        *,
        progress_callback: Callable[[int, int], None] | None = None,
    ) -> None:
        """Recursively upload a local directory. Up to 8 files concurrent.

        Per-file failures abort the whole batch — partial uploads aren't
        useful for training-data sync. Re-running is safe (S3 PUT is
        idempotent on the same key).

        `progress_callback(bytes_done, total_bytes)` reports cumulative bytes
        across all files. Per-file totals are summed up front via `stat()`
        so the bar can render a meaningful overall percentage.
        """
        assert self._client is not None
        root = Path(local)
        if not root.is_dir():
            raise ValueError(f"{local} is not a directory")
        remote_prefix = "/" + remote.strip("/")
        if remote_prefix == "/":
            remote_prefix = ""

        files: list[tuple[Path, str, int]] = []
        for path in root.rglob("*"):
            if path.is_file():
                rel = path.relative_to(root).as_posix()
                files.append((path, f"{remote_prefix}/{rel}", path.stat().st_size))

        total_bytes = sum(s for _, _, s in files)
        progress_lock = threading.Lock()
        bytes_done = 0

        def _per_file_callback() -> Callable[[int, int], None] | None:
            """Build a per-file callback that translates file-local bytes to
            the dir-level cumulative counter."""
            cb = progress_callback
            if cb is None:
                return None
            file_last = 0

            def _cb(bytes_in_file: int, _: int) -> None:
                nonlocal file_last, bytes_done
                with progress_lock:
                    delta = bytes_in_file - file_last
                    file_last = bytes_in_file
                    bytes_done += delta
                    snapshot = bytes_done
                cb(snapshot, total_bytes)

            return _cb

        with ThreadPoolExecutor(max_workers=_VOLUME_UPLOAD_PARALLELISM) as pool:
            futures = [
                pool.submit(
                    self.upload_file,
                    str(p),
                    r,
                    progress_callback=_per_file_callback(),
                )
                for p, r, _ in files
            ]
            for fut in as_completed(futures):
                fut.result()  # surfaces exceptions

    def list_files(self, prefix: str = "") -> list[VolumeFile]:
        """List files in the volume. Paginates server-side automatically."""
        assert self._client is not None
        out: list[VolumeFile] = []
        params: dict = {"limit": 1000}
        if prefix:
            params["prefix"] = prefix
        while True:
            resp = self._client._http.get(
                f"/v1/volumes/{self.name}/files", params=params
            )
            _raise(resp)
            body = resp.json()
            for f in body["data"]:
                out.append(VolumeFile(
                    path=f["path"],
                    size_bytes=f["size_bytes"],
                    modified_at=f.get("modified_at"),
                    etag=f.get("etag", ""),
                ))
            if not body.get("has_more"):
                return out
            # Server uses prefix-scoped listing; for the SDK's "show me everything"
            # case the page boundary is implicit in S3's pagination. The control
            # plane currently returns one full page (up to 1000) per request and
            # doesn't surface a cursor — we'll wire continuation when count > 1000
            # becomes a real concern. For now: break to avoid an infinite loop
            # if the server signals has_more without a cursor mechanism.
            break
        return out

    def delete(self) -> None:
        """Delete this volume (and queue its S3 prefix for cleanup)."""
        assert self._client is not None
        resp = self._client._http.delete(f"/v1/volumes/{self.name}")
        _raise(resp)


class _Volumes:
    def __init__(self, client: "Client"):
        self._client = client
        self._http = client._http

    def create(self, name: str) -> Volume:
        """Create a volume. Idempotent — re-create returns the existing row."""
        resp = self._http.post("/v1/volumes", json={"name": name})
        _raise(resp)
        return self._parse(resp.json())

    def get(self, name: str) -> Volume:
        resp = self._http.get(f"/v1/volumes/{name}")
        _raise(resp)
        return self._parse(resp.json())

    def list(self, limit: int = 20, after: str | None = None) -> list[Volume]:
        params: dict = {"limit": limit}
        if after:
            params["after"] = after
        resp = self._http.get("/v1/volumes", params=params)
        _raise(resp)
        return [self._parse(v) for v in resp.json()["data"]]

    def delete(self, name: str) -> None:
        resp = self._http.delete(f"/v1/volumes/{name}")
        _raise(resp)

    def _parse(self, d: dict) -> Volume:
        return Volume(
            id=d["id"],
            name=d["name"],
            total_bytes=d.get("total_bytes", 0),
            file_count=d.get("file_count", 0),
            created_at=d.get("created_at"),
            updated_at=d.get("updated_at"),
            _client=self._client,
        )


class Client:
    def __init__(self, api_key: str | None = None, base_url: str | None = None):
        # Auto-load from the same config the CLI writes to.
        # Honors VERI_API_KEY / VERI_API_URL env vars and the active profile in
        # ~/.config/veri/config.toml (or platform equivalent).
        if not api_key or not base_url:
            from veri_sdk.cli.utils import config as _config
            profile = _config.load()
            api_key = api_key or profile.get("api_key")
            base_url = base_url or profile.get("api_url")
        if not api_key:
            raise ValueError(
                "No API key provided. Either pass api_key= or run 'veri login' first."
            )
        base_url = base_url or "https://api.veri.studio"
        self.api_url = base_url

        self._http = httpx.Client(
            base_url=base_url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=60,
        )
        self.datasets = _Datasets(self._http)
        self.reward_functions = _RewardFunctions(self._http)
        self.training_jobs = _TrainingJobs(self._http, self)
        self.deployments = _Deployments(self._http, self)
        self.evals = _Evals(self._http, self)
        self.cost = _Cost(self._http)
        self.billing = _Billing(self._http)
        self.volumes = _Volumes(self)
