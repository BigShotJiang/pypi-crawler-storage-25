import os
from enum import StrEnum
from logging import Logger
from typing import Any, cast

import filetype as filetype
import requests
from pydantic import BaseModel, Field
from pymultirole_plugins.v1.converter import ConverterBase, ConverterParameters
from pymultirole_plugins.v1.schema import Document
from starlette.datastructures import UploadFile

from .openai_utils import NO_DEPLOYED_MODELS, create_asr_model_enum, set_openai

logger = Logger("pymultirole")


class OpenAIAudioBaseParameters(ConverterParameters):
    model_str: str = Field(
        None,
        description="""Override the model selection by specifying a model identifier string directly. When set, this takes precedence over the model dropdown.""",
        json_schema_extra={"extra": "advanced"},
    )
    model: str = Field(None, json_schema_extra={"extra": "internal"})
    language: str = Field(
        None,
        description="""The language of the input audio in ISO-639-1 format (e.g. `en`, `fr`, `de`).
    Supplying the input language improves transcription accuracy and reduces latency.""",
    )
    prompt: str = Field(
        None,
        description="""An optional text to guide the model's style or continue a previous audio segment.
    The prompt should be in the same language as the audio. Useful for setting context, correcting specific words, or maintaining a consistent style across segments.""",
        json_schema_extra={"extra": "multiline,advanced"},
    )
    temperature: float = Field(
        0.0,
        description="""The sampling temperature, between 0 and 1.
    Higher values like 0.8 will make the output more random, while lower values like 0.2 will make it more focused and deterministic.
    If set to 0, the model will use log probability to automatically increase the temperature until certain thresholds are hit.""",
        json_schema_extra={"extra": "advanced"},
    )


class OpenAIAudioModel(StrEnum):
    whisper_1 = "whisper-1"
    gpt_4o_transcribe = "gpt-4o-transcribe"
    gpt_4o_mini_transcribe = "gpt-4o-mini-transcribe"


class OpenAIAudioParameters(OpenAIAudioBaseParameters):
    model: OpenAIAudioModel = Field(
        OpenAIAudioModel.whisper_1,
        description="""The [OpenAI model](https://platform.openai.com/docs/models) used for speech-to-text transcription.""",
        json_schema_extra={"extra": "pipeline-naming-hint"},
    )


DEEPINFRA_PREFIX = "DEEPINFRA_"
DEEPINFRA_ASR_MODEL_ENUM, DEEPINFRA_DEFAULT_ASR_MODEL = create_asr_model_enum(
    "DeepInfraAudioModel", prefix=DEEPINFRA_PREFIX
)


class DeepInfraOpenAIAudioParameters(OpenAIAudioBaseParameters):
    model: DEEPINFRA_ASR_MODEL_ENUM = Field(
        None,
        description="""The [DeepInfra 'OpenAI compatible' model](https://deepinfra.com/models?type=automatic-speech-recognition) used for speech-to-text transcription.
    The available models are fetched from your [DeepInfra dashboard](https://deepinfra.com/dash).""",
        json_schema_extra={"extra": "pipeline-naming-hint"},
    )


AZURE_PREFIX = "AZURE_"


class AzureOpenAIAudioParameters(OpenAIAudioBaseParameters):
    model: OpenAIAudioModel = Field(
        OpenAIAudioModel.whisper_1,
        description="""The [Azure OpenAI model](https://learn.microsoft.com/en-us/azure/ai-services/openai/concepts/models) used for speech-to-text transcription.""",
        json_schema_extra={"extra": "pipeline-naming-hint"},
    )


class OpenAIAudioConverterBase(ConverterBase):
    """Convert audio and video files to text documents using speech-to-text transcription.
    Supported formats include WAV, MP3, MP4, WEBM, M4A and other common audio/video formats."""

    PREFIX: str = ""

    def compute_args(self, params: OpenAIAudioBaseParameters, prompt: str) -> dict[str, Any]:
        kwargs = {
            "model": params.model_str,
            "language": params.language,
            "prompt": prompt,
            "temperature": params.temperature,
            "response_format": "text",
        }
        return kwargs

    def convert(self, source: UploadFile, parameters: ConverterParameters) -> list[Document]:
        params: OpenAIAudioBaseParameters = cast(OpenAIAudioBaseParameters, parameters)
        OPENAI_MODEL = os.getenv(self.PREFIX + "OPENAI_MODEL", None)
        if OPENAI_MODEL:
            params.model_str = OPENAI_MODEL

        kind = filetype.guess(source.file)
        source.file.seek(0)
        doc: Document = None
        if kind is not None and (kind.mime.startswith("audio") or kind.mime.startswith("video")):
            kwargs = self.compute_args(params, params.prompt)
            if kwargs["model"] != NO_DEPLOYED_MODELS:
                try:
                    result = self.compute_result(source, **kwargs)
                    doc = Document(identifier=source.filename, text=result)
                    doc.properties = {"fileName": source.filename}
                except BaseException as err:
                    raise err
        if doc is None:
            raise TypeError(f"Conversion of audio file {source.filename} failed")
        return [doc]

    @classmethod
    def get_model(cls) -> type[BaseModel]:
        return OpenAIAudioBaseParameters


class OpenAIAudioConverter(OpenAIAudioConverterBase):
    """Convert audio to text using the [OpenAI Audio Transcription](https://platform.openai.com/docs/guides/speech-to-text) API.
    Requires the `OPENAI_API_KEY` environment variable to be set."""

    def convert(self, source: UploadFile, parameters: ConverterParameters) -> list[Document]:
        params: OpenAIAudioParameters = cast(OpenAIAudioParameters, parameters)
        model_str = params.model_str if bool(params.model_str and params.model_str.strip()) else None
        model = params.model.value if params.model is not None else None
        params.model_str = model_str or model
        return super().convert(source, params)

    def compute_result(self, source: UploadFile, **kwargs):
        client = set_openai(self.PREFIX)
        kwargs["file"] = (source.filename, source.file, source.content_type)
        response = client.audio.transcriptions.create(**kwargs)
        return response

    @classmethod
    def get_model(cls) -> type[BaseModel]:
        return OpenAIAudioParameters


class AzureOpenAIAudioConverter(OpenAIAudioConverterBase):
    """Convert audio to text using the [Azure OpenAI Audio Transcription](https://learn.microsoft.com/en-us/azure/ai-services/openai/whisper-quickstart) API.
    Requires `AZURE_OPENAI_API_KEY`, `AZURE_OPENAI_API_BASE`, and `AZURE_OPENAI_API_VERSION` environment variables."""

    PREFIX = AZURE_PREFIX

    def convert(self, source: UploadFile, parameters: ConverterParameters) -> list[Document]:
        params: AzureOpenAIAudioParameters = cast(AzureOpenAIAudioParameters, parameters)
        model_str = params.model_str if bool(params.model_str and params.model_str.strip()) else None
        model = params.model.value if params.model is not None else None
        params.model_str = model_str or model
        return super().convert(source, params)

    def compute_result(self, source: UploadFile, **kwargs):
        client = set_openai(self.PREFIX)
        kwargs["file"] = (source.filename, source.file, source.content_type)
        response = client.audio.transcriptions.create(**kwargs)
        return response

    @classmethod
    def get_model(cls) -> type[BaseModel]:
        return OpenAIAudioParameters


class DeepInfraOpenAIAudioConverter(OpenAIAudioConverterBase):
    """Convert audio to text using the [DeepInfra Audio Transcription](https://deepinfra.com/docs/tutorials/whisper) API.
    Requires the `DEEPINFRA_OPENAI_API_KEY` environment variable to be set."""

    PREFIX = DEEPINFRA_PREFIX

    def convert(self, source: UploadFile, parameters: ConverterParameters) -> list[Document]:
        params: DeepInfraOpenAIAudioParameters = cast(DeepInfraOpenAIAudioParameters, parameters)
        model_str = params.model_str if bool(params.model_str and params.model_str.strip()) else None
        model = params.model.value if params.model is not None else None
        params.model_str = model_str or model
        return super().convert(source, params)

    def compute_result(self, source: UploadFile, **kwargs):
        client = set_openai(self.PREFIX)
        deepinfra_url = client.base_url
        inference_url = f"{deepinfra_url.scheme}://{deepinfra_url.host}/v1/inference/{kwargs['model']}"
        response = requests.post(
            inference_url,
            files={"audio": (source.filename, source.file, source.content_type)},
            data={
                "task": "transcribe",
                "language": kwargs["language"],
                "temperature": kwargs["temperature"],
                "initial_prompt": kwargs["prompt"],
            },
            headers={"Accept": "application/json", "Authorization": f"Bearer {client.api_key}"},
        )
        if response.ok:
            result = response.json()
            return result["text"]

    @classmethod
    def get_model(cls) -> type[BaseModel]:
        return DeepInfraOpenAIAudioParameters
