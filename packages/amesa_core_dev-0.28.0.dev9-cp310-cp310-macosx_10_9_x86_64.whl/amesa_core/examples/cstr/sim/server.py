# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

import asyncio
import os
from argparse import ArgumentParser

from amesa_core.examples.cstr.sim.server_impl import ServerImpl
from amesa_core.networking.sim import server as server_make


async def start(host, port, protocol, env_init):
    server = server_make.make(
        server_impl=ServerImpl,
        host=host,
        port=port,
        protocol=protocol,
        env_init=env_init,
    )
    await server.start()
    while True:
        await asyncio.sleep(1)


if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("--host", type=str, default=os.environ.get("HOST") or "[::]")
    parser.add_argument("--port", type=int, default=os.environ.get("PORT") or 1337)
    parser.add_argument("--protocol", default="grpc")
    parser.add_argument("--env_init", type=str, default="{}")
    args = parser.parse_args()
    args.env_init = eval(args.env_init)
    asyncio.run(start(args.host, args.port, args.protocol, args.env_init))
