# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

"""CSTR agent factory for integration tests."""

import math
from typing import Dict

import numpy as np

from amesa_core import Agent, Scenario, Sensor, Skill, SkillTeacher


class BaseCSTR(SkillTeacher):
    def __init__(self):
        self.obs_history = None
        self.reward_history = []
        self.error_history = []
        self.count = 0
        self.title = "CSTR Live Control"

    async def transform_sensors(self, sensors, action):
        return sensors

    async def transform_action(self, transformed_sensors: Dict, action):
        return action

    async def filtered_sensor_space(self):
        return ["T", "Tc", "Ca", "Cref", "Tref"]

    async def compute_reward(self, transformed_sensors: Dict, action, sim_reward):
        if self.obs_history is None:
            self.obs_history = [transformed_sensors]
            return 0
        self.obs_history.append(transformed_sensors)
        cref = transformed_sensors["Cref"]
        ca = transformed_sensors["Ca"]
        if hasattr(cref, "__len__"):
            cref = float(np.asarray(cref).flat[0])
        if hasattr(ca, "__len__"):
            ca = float(np.asarray(ca).flat[0])
        error = (cref - ca) ** 2
        self.error_history.append(error)
        rms = math.sqrt(np.mean(self.error_history))
        reward = 1 / rms
        self.reward_history.append(reward)
        self.count += 1
        return reward

    async def compute_action_mask(self, transformed_sensors: Dict, action):
        return None

    async def compute_success_criteria(self, transformed_sensors: Dict, action):
        return False

    async def compute_termination(self, transformed_sensors: Dict, action):
        return False


class SS1Teacher(BaseCSTR):
    def __init__(self):
        super().__init__()
        self.title = "CSTR Live Control - SS1 skill"


class SS2Teacher(BaseCSTR):
    def __init__(self):
        super().__init__()
        self.title = "CSTR Live Control - SS2 skill"


class SS3Teacher(BaseCSTR):
    def __init__(self):
        super().__init__()
        self.title = "CSTR Live Control - SS3 skill"


class TransitionTeacher(BaseCSTR):
    def __init__(self):
        super().__init__()
        self.title = "CSTR Live Control - Transition skill"


class CSTRSelectorTeacher(BaseCSTR):
    def __init__(self):
        super().__init__()
        self.title = "CSTR Live Control - Selector skill"


def create_cstr_agent() -> Agent:
    """Create CSTR agent with selector and child skills (ss1, ss2, ss3, transition)."""
    agent = Agent()
    agent.add_sensors(
        [
            Sensor("T", "", lambda sensors: sensors["T"]),
            Sensor("Tc", "", lambda sensors: sensors["Tc"]),
            Sensor("Ca", "", lambda sensors: sensors["Ca"]),
            Sensor("Cref", "", lambda sensors: sensors["Cref"]),
            Sensor("Tref", "", lambda sensors: sensors["Tref"]),
        ]
    )
    ss1_scenarios = [{"Cref_signal": "ss1"}]
    ss2_scenarios = [{"Cref_signal": "ss2"}]
    transition_scenarios = [{"Cref_signal": "transition"}]
    selector_scenarios = [{"Cref_signal": "complete"}]

    ss1_skill = Skill("ss1", SS1Teacher)
    for s in ss1_scenarios:
        ss1_skill.add_scenario(Scenario(s))

    ss2_skill = Skill("ss2", SS2Teacher)
    for s in ss2_scenarios:
        ss2_skill.add_scenario(Scenario(s))

    ss3_skill = Skill("ss3", SS3Teacher)
    for s in ss2_scenarios:
        ss3_skill.add_scenario(Scenario(s))

    transition_skill = Skill("transition", TransitionTeacher)
    for s in transition_scenarios:
        transition_skill.add_scenario(Scenario(s))

    selector_skill = Skill("selector", CSTRSelectorTeacher)
    for s in selector_scenarios:
        selector_skill.add_scenario(Scenario(s))

    agent.add_skill(ss1_skill)
    agent.add_skill(ss2_skill)
    agent.add_skill(ss3_skill)
    agent.add_skill(transition_skill)
    agent.add_selector_skill(
        selector_skill,
        [ss1_skill, transition_skill, ss2_skill, ss3_skill],
        fixed_order=False,
        repeat=False,
    )
    agent.build_graph()
    return agent
