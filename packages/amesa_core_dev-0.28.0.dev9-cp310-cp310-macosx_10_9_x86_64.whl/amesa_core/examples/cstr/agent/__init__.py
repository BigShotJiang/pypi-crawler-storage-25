# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

from amesa_core.examples.cstr.agent.cstr_agent import create_cstr_agent
