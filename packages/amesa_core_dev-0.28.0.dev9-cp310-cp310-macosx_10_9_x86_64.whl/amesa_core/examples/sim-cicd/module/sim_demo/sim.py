# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

import random
import time
from typing import Any, Dict, SupportsFloat, Tuple

import gymnasium as gym
import numpy as np

MAX_COUNTER = 10


class Sim(gym.Env):
    def __init__(self, env_init: dict = {}):
        self.space_type = env_init.get("space_type", "discrete")
        self.sleep_timer = env_init.get("sleep_timer", None)
        self.counter = 0
        self.steps = 0

        if self.space_type == "discrete":
            self.sensor_space = gym.spaces.Discrete(MAX_COUNTER + 1)
            self.action_space = gym.spaces.Discrete(2)
        elif self.space_type == "multidiscrete":
            self.sensor_space = gym.spaces.MultiDiscrete([MAX_COUNTER + 1])
            self.action_space = gym.spaces.MultiDiscrete([2, 3])
        elif self.space_type == "multibinary":
            self.sensor_space = gym.spaces.MultiBinary(7)
            self.action_space = gym.spaces.MultiDiscrete([2, 3])
        elif self.space_type == "box":
            self.sensor_space = gym.spaces.Box(
                low=np.array([0]), high=np.array([MAX_COUNTER]), dtype=np.float32
            )
            self.action_space = gym.spaces.Box(
                low=np.array([0]), high=np.array([1]), dtype=np.float32
            )
        else:
            raise ValueError(f"Unknown space type {self.space_type}")

    def get_action_mask(self):
        if self.space_type == "discrete":
            mask = random.choice([np.array([0, 1]), np.array([1, 0])])
        elif self.space_type in ["multidiscrete", "multibinary"]:
            mask1 = random.choice([np.array([0, 1]), np.array([1, 0])])
            mask2 = random.choice([np.array([0, 1, 1]), np.array([1, 1, 0])])
            mask = tuple([mask1, mask2])
        else:
            mask = [1, 1]
        return {"action_mask": mask}

    def step(self, action) -> Tuple[Any, SupportsFloat, bool, bool, Dict[str, Any]]:
        self.steps += 1
        self._process_action(action)
        sensors = self._get_sensor()

        done = self.steps == MAX_COUNTER
        reward = 1 if done else 0
        info = self.get_action_mask()

        if self.sleep_timer:
            time.sleep(self.sleep_timer)

        return sensors, reward, done, False, info

    def reset(self):
        self.counter = 0
        self.steps = 0
        return self._get_sensor(), self.get_action_mask()

    def _process_action(self, action):
        assert self.action_space.contains(action), f"Invalid action {action}"
        if self.space_type in ["discrete", "multibinary"]:
            value_to_add = 1 if action == 0 else -1
        elif self.space_type == "multidiscrete":
            value_to_add = 1 if action[0] == 0 else -1
        elif self.space_type == "box":
            value_to_add = 1 if action[0] <= 0.5 else -1
        else:
            value_to_add = 1
        self.counter = max(0, min(MAX_COUNTER, self.counter + value_to_add))

    def _get_sensor(self):
        if self.space_type == "discrete":
            return self.counter
        if self.space_type == "multidiscrete":
            return np.array([self.counter], dtype=np.int64)
        if self.space_type == "multibinary":
            bits = list(map(int, f"{self.counter:07b}"))
            return np.array(bits, dtype=np.int8)
        if self.space_type == "box":
            return np.array([self.counter], dtype=np.float32)
        return self.sensor_space.sample()
