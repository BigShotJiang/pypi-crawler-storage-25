# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

from typing import Any, Dict, SupportsFloat, Tuple

import gymnasium as gym
from amesa_core.agent.scenario import Scenario
from amesa_core.networking.sim.server_amesa import ServerAmesa
from gymnasium.envs.registration import EnvSpec

from .sim import Sim


class SimImpl(ServerAmesa):
    def __init__(self):
        self.env = None

    async def make(self, env_id: str, env_init: dict) -> EnvSpec:
        self.env = Sim(env_init or {})
        return {"id": "sim-demo", "max_episode_steps": 1000}

    async def sensor_space_info(self) -> gym.Space:
        return self.env.sensor_space

    async def action_space_info(self) -> gym.Space:
        return self.env.action_space

    async def action_space_sample(self) -> Any:
        return self.env.action_space.sample()

    async def reset(self) -> Tuple[Any, Dict[str, Any]]:
        return self.env.reset()

    async def step(
        self, action
    ) -> Tuple[Any, SupportsFloat, bool, bool, Dict[str, Any]]:
        return self.env.step(action)

    async def close(self):
        self.env = None

    async def set_scenario(self, scenario):
        pass

    async def get_scenario(self):
        return Scenario({"dummy": 0})

    async def get_render(self):
        if self.env is None:
            return ""
        return f"Counter: {self.env.counter}"
