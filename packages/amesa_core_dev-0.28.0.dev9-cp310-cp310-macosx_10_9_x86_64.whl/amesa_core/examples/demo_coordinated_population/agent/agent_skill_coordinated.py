# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

from amesa_core.agent.agent import Agent
from amesa_core.examples.demo_coordinated_population import coordinated_skill, sensors

agent = Agent()
agent.add_sensors(sensors)
agent.add_coordinated_skill(coordinated_skill)
