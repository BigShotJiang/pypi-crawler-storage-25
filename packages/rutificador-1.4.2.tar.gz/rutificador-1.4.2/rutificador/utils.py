# SECURITY-CRITICAL
"""Funciones utilitarias para Rutificador."""

import logging
import re
import time
import unicodedata
from functools import lru_cache, wraps
from itertools import cycle
from typing import Any, Callable, Optional, TypeVar

from .config import CONFIGURACION_POR_DEFECTO, ConfiguracionRut
from .exceptions import ErrorValidacionRut

logger = logging.getLogger(__name__)

# Tipo genérico para el valor de retorno de funciones decoradas
R = TypeVar("R")

# Tabla de traducción para eliminar separadores de miles de forma eficiente
_PUNTOS_TRADUCCION = str.maketrans("", "", ".")


def configurar_registro(
    level: int = logging.WARNING,
    formato: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handler: Optional[logging.Handler] = None,
) -> None:
    """Configura un logger dedicado para la librería sin sobrescribir el global."""
    logger_principal = logging.getLogger("rutificador")
    logger_principal.setLevel(level)
    logger_principal.propagate = False

    formatter = logging.Formatter(formato)

    if handler is not None:
        handler.setFormatter(formatter)
        setattr(handler, "_rutificador", True)
        logger_principal.handlers = [
            existente
            for existente in logger_principal.handlers
            if not getattr(existente, "_rutificador", False)
        ]
        logger_principal.addHandler(handler)
    else:
        existente = next(
            (h for h in logger_principal.handlers if getattr(h, "_rutificador", False)),
            None,
        )
        if existente is None:
            existente = logging.StreamHandler()
            setattr(existente, "_rutificador", True)
            logger_principal.addHandler(existente)
        existente.setFormatter(formatter)

    logger.setLevel(level)
    logger_principal.info(
        "Registro configurado al nivel: %s", logging.getLevelName(level)
    )


def asegurar_cadena_no_vacia(valor: Any, nombre: str) -> str:
    """Verifica que ``valor`` sea una cadena no vacía."""
    if not isinstance(valor, str):
        raise ErrorValidacionRut(
            f"{nombre} debe ser una cadena, se recibió: {type(valor).__name__}",
            codigo_error="ERROR_TIPO",
        )
    valor = valor.strip()
    if not valor:
        raise ErrorValidacionRut(
            f"{nombre} no puede estar vacío", codigo_error="CADENA_VACIA"
        )
    return valor


def asegurar_booleano(valor: Any, nombre: str) -> bool:
    """Verifica que ``valor`` sea booleano."""
    if not isinstance(valor, bool):
        raise ErrorValidacionRut(
            f"{nombre} debe ser booleano, se recibió: {type(valor).__name__}",
            codigo_error="ERROR_TIPO",
        )
    return valor


def monitor_de_rendimiento(func: Callable[..., R]) -> Callable[..., R]:
    """Decora una función midiendo y registrando su rendimiento.

    Args:
        func: Función a envolver.

    Returns:
        Función envuelta que preserva el tipo de retorno original mientras
        registra el tiempo de ejecución.
    """

    @wraps(func)
    def envoltura(*args: Any, **kwargs: Any) -> R:
        tiempo_inicio = time.perf_counter()
        try:
            resultado: R = func(*args, **kwargs)
            tiempo_ejecucion = time.perf_counter() - tiempo_inicio
            logger.debug("%s ejecutada en %.4fs", func.__name__, tiempo_ejecucion)
            return resultado
        except Exception as exc:  # pragma: no cover - se relanza con registro
            tiempo_ejecucion = time.perf_counter() - tiempo_inicio
            logger.error(
                "%s falló tras %.4fs: %s", func.__name__, tiempo_ejecucion, exc
            )
            raise

    return envoltura


@lru_cache(maxsize=1024)
@monitor_de_rendimiento
def calcular_digito_verificador(
    base_numerica: str, configuracion: ConfiguracionRut = CONFIGURACION_POR_DEFECTO
) -> str:
    """Calcula el dígito verificador para una base de RUT dada.

    Args:
        base_numerica: Parte numérica del RUT sin el dígito verificador.
        configuracion: Parámetros de configuración que controlan el cálculo.

    Returns:
        El dígito verificador en minúsculas. Si el dígito calculado es 10,
        se retorna ``"k"``.

    Raises:
        ErrorValidacionRut: Si ``base_numerica`` no es una cadena numérica válida.
    """
    if not isinstance(base_numerica, str):
        raise ErrorValidacionRut(
            f"La base numérica debe ser una cadena, se recibió: "
            f"{type(base_numerica).__name__}",
            codigo_error="ERROR_TIPO",
        )
    if not base_numerica or not base_numerica.strip():
        raise ErrorValidacionRut(
            "La base numérica no puede estar vacía",
            codigo_error="BASE_VACIA",
        )
    base_numerica = base_numerica.strip()
    if not base_numerica.isdigit():
        raise ErrorValidacionRut(
            f"La base numérica '{base_numerica}' debe contener solo dígitos",
            codigo_error="DIGITOS_INVALIDOS",
        )
    # Se utiliza itertools.cycle para evitar operaciones costosas de módulo
    # dentro del bucle y mantener eficiente la implementación para bases grandes.

    factores = cycle(configuracion.factores_verificacion)
    suma_parcial = sum(int(d) * f for d, f in zip(reversed(base_numerica), factores))
    digito_verificador = (
        configuracion.modulo - suma_parcial % configuracion.modulo
    ) % configuracion.modulo
    return str(digito_verificador) if digito_verificador < 10 else "k"


def normalizar_base_rut(base: str) -> str:
    """Normaliza una base de RUT eliminando puntos y ceros iniciales."""
    if not isinstance(base, str):
        raise ErrorValidacionRut(
            f"La base debe ser una cadena, se recibió: {type(base).__name__}",
            codigo_error="ERROR_TIPO",
        )
    base_normalizada = base.translate(_PUNTOS_TRADUCCION).lstrip("0")
    return base_normalizada if base_normalizada else "0"


def _limpiar_entrada(valor: str) -> tuple[str, bool]:
    """Limpia la entrada de RUT (Unicode, espacios, guiones).

    Args:
        valor: Cadena a limpiar.

    Returns:
        Tupla con (cadena_limpia, hubo_cambios).
    """
    if not isinstance(valor, str):
        return valor, False

    cadena_original = valor
    # Normalización Unicode NFKC
    cadena = unicodedata.normalize("NFKC", cadena_original)
    # Limpieza de espacios
    cadena = re.sub(r"\s+", "", cadena)
    # Normalización de guiones
    cadena = (
        cadena.replace("_", "-")
        .replace("–", "-")
        .replace("—", "-")
        .replace("−", "-")  # Minus sign unicode
    )

    return cadena, cadena != cadena_original


__all__ = [
    "monitor_de_rendimiento",
    "calcular_digito_verificador",
    "normalizar_base_rut",
    "configurar_registro",
    "asegurar_cadena_no_vacia",
    "asegurar_booleano",
]
