"""plugin-kit-ai Python wrapper package."""

__version__ = "1.1.0"
