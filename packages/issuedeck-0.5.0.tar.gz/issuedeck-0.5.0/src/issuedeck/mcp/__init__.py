"""issuedeck MCP stdio server."""
