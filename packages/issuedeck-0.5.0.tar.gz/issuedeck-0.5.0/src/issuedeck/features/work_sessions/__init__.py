"""Agent work sessions feature."""

