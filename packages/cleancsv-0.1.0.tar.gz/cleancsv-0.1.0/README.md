# cleancsv

Clean and standardize CSV files automatically with one line of code.

## Install

```
pip install cleancsv
```

## Usage

```python
from cleancsv import clean, summary

# Show a quick summary
summary("data.csv")

# Clean the file (saves as data_clean.csv)
clean("data.csv")

# Custom output path
clean("data.csv", output="result.csv")
```

## What it does

- Removes completely empty rows
- Standardizes column names (lowercase, underscores)
- Strips extra whitespace from cells
- Detects and reports null values per column
- Auto-detects UTF-8 or latin-1 encoding

---

# cleancsv (Português)

Limpe arquivos CSV automaticamente com uma linha de código.

```python
from cleancsv import clean
clean("dados.csv")  # gera dados_clean.csv
```