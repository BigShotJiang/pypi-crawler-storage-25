import csv
import os
from pathlib import Path


def clean(filepath: str, output: str = None, verbose: bool = True) -> str:
    """
    Limpa um arquivo CSV automaticamente.

    - Remove linhas completamente vazias
    - Padroniza nomes de colunas (minúsculo, sem espaços)
    - Remove espaços extras nas células
    - Salva o resultado em um novo arquivo

    Args:
        filepath: Caminho do CSV de entrada
        output:   Caminho do CSV de saída (padrão: arquivo_clean.csv)
        verbose:  Mostra relatório no terminal

    Returns:
        Caminho do arquivo limpo
    """
    path = Path(filepath)
    if not path.exists():
        raise FileNotFoundError(f"Arquivo não encontrado: {filepath}")

    # Detectar encoding automaticamente
    encoding = _detect_encoding(filepath)

    with open(filepath, "r", encoding=encoding, errors="replace") as f:
        reader = csv.DictReader(f)
        original_cols = reader.fieldnames or []
        rows = list(reader)

    # Padronizar nomes das colunas
    col_map = {c: c.strip().lower().replace(" ", "_") for c in original_cols}
    clean_cols = list(col_map.values())

    # Limpar células e remover linhas vazias
    clean_rows = []
    removed = 0
    nulls = {c: 0 for c in clean_cols}

    for row in rows:
        new_row = {}
        for orig, clean_col in col_map.items():
            val = (row.get(orig) or "").strip()
            new_row[clean_col] = val
            if not val:
                nulls[clean_col] += 1

        # Remover linha se TODAS as células estiverem vazias
        if any(v for v in new_row.values()):
            clean_rows.append(new_row)
        else:
            removed += 1

    # Definir arquivo de saída
    if not output:
        output = str(path.parent / f"{path.stem}_clean{path.suffix}")

    with open(output, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=clean_cols)
        writer.writeheader()
        writer.writerows(clean_rows)

    if verbose:
        print(f"\n✅ cleancsv — Relatório")
        print(f"   Linhas originais : {len(rows)}")
        print(f"   Linhas removidas : {removed}")
        print(f"   Linhas salvas    : {len(clean_rows)}")
        print(f"   Arquivo limpo    : {output}\n")
        if any(v > 0 for v in nulls.values()):
            print("   ⚠ Valores nulos por coluna:")
            for col, count in nulls.items():
                if count > 0:
                    print(f"      {col}: {count}")
            print()

    return output


def summary(filepath: str):
    """Mostra um resumo rápido do CSV sem modificá-lo."""
    path = Path(filepath)
    encoding = _detect_encoding(filepath)

    with open(filepath, "r", encoding=encoding, errors="replace") as f:
        reader = csv.DictReader(f)
        cols = reader.fieldnames or []
        rows = list(reader)

    print(f"\n📊 Resumo: {path.name}")
    print(f"   Linhas   : {len(rows)}")
    print(f"   Colunas  : {len(cols)}")
    print(f"   Encoding : {encoding}\n")
    print("   Colunas encontradas:")
    for col in cols:
        nulls = sum(1 for r in rows if not (r.get(col) or "").strip())
        print(f"      {col:20} → {nulls} nulos")
    print()


def _detect_encoding(filepath: str) -> str:
    """Detecta UTF-8 ou latin-1 automaticamente."""
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            f.read()
        return "utf-8"
    except UnicodeDecodeError:
        return "latin-1"