"""Exception classes for the Gildea SDK."""


class GildeaError(Exception):
    """Base exception for all Gildea SDK errors."""

    def __init__(self, message, *, code=None, status=None):
        super().__init__(message)
        self.code = code
        self.status = status


class AuthenticationError(GildeaError):
    """Raised on 401/403 responses or missing API key."""


class NotFoundError(GildeaError):
    """Raised on 404 responses."""


class RateLimitError(GildeaError):
    """Raised on 429 responses."""

    def __init__(self, message, *, code=None, status=None, retry_after=None):
        super().__init__(message, code=code, status=status)
        self.retry_after = retry_after


class BadRequestError(GildeaError):
    """Raised on 400 responses."""


class APIError(GildeaError):
    """Raised on 5xx or other unexpected responses."""
