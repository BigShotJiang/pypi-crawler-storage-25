"""Main Gildea client."""

from __future__ import annotations

import os

import httpx

from .exceptions import AuthenticationError
from .pagination import _request
from .resources import EntitiesResource, SearchResource, SignalsResource, ThemesResource


class Gildea:
    """Synchronous client for the Gildea AI market intelligence API."""

    def __init__(self, api_key=None, base_url="https://api.gildea.ai", timeout=30.0):
        self.api_key = api_key or os.environ.get("GILDEA_API_KEY")
        if not self.api_key:
            raise AuthenticationError(
                "No API key provided. Set GILDEA_API_KEY or pass api_key=."
            )
        self._client = httpx.Client(
            base_url=base_url,
            headers={"X-API-Key": self.api_key},
            timeout=timeout,
        )
        self.signals = SignalsResource(self._client)
        self.entities = EntitiesResource(self._client)
        self.themes = ThemesResource(self._client)
        self._search = SearchResource(self._client)

    def search(self, query=None, *, similar_to=None, **kwargs):
        """Search across all verified text units.

        Two modes: pass ``query`` for hybrid semantic + keyword search,
        or ``similar_to`` with a text unit ID for pure vector similarity.
        Exactly one is required.
        """
        return self._search.query(query, similar_to=similar_to, **kwargs)

    def embed(self, text):
        """Embed text into Gildea's vector space (BAAI/bge-base-en-v1.5, 768-dim).

        Returns a dict with ``embedding`` (list of floats), ``embedding_model``
        (identifier), and ``dimensions`` (int). Max input length: 2000 characters.

        Use the returned vector to compute cosine similarity against text unit
        embeddings retrieved via ``signals.get(id, include="embeddings")``.
        """
        return _request(self._client, "POST", "/v1/embed", json={"text": text})

    def close(self):
        """Close the underlying HTTP connection."""
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
