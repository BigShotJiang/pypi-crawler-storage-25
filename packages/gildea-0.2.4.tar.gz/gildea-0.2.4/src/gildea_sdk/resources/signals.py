"""Signals resource."""

from __future__ import annotations

from ..pagination import _clean, _paginate, _quote, _request


class SignalsResource:
    def __init__(self, client):
        self._client = client

    def list(
        self,
        *,
        entity=None,
        theme=None,
        q=None,
        content_type=None,
        published_after=None,
        published_before=None,
        cursor=None,
        limit=25,
    ):
        params = _clean(
            {
                "entity": entity,
                "theme": theme,
                "q": q,
                "content_type": content_type,
                "published_after": published_after,
                "published_before": published_before,
                "cursor": cursor,
                "limit": limit,
            }
        )
        return _request(self._client, "GET", "/v1/signals", params=params)

    def get(self, signal_id, *, include=None, verification_detail=None):
        path = f"/v1/signals/{_quote(signal_id)}"
        params = _clean(
            {"include": include, "verification_detail": verification_detail}
        )
        return _request(self._client, "GET", path, params=params)

    def list_all(self, **kwargs):
        """Auto-paginating iterator that yields every signal matching the filters."""
        return _paginate(self._client, "/v1/signals", kwargs)
