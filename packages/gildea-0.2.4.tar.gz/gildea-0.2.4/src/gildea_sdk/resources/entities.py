"""Entities resource."""

from __future__ import annotations

from ..pagination import _clean, _paginate, _quote, _request


class EntitiesResource:
    def __init__(self, client):
        self._client = client

    def list(
        self,
        *,
        theme=None,
        type_primary=None,
        q=None,
        sort="signal_count",
        cursor=None,
        limit=25,
        direction=None,
        confidence=None,
        stability=None,
        scale=None,
        notability=None,
    ):
        params = _clean(
            {
                "theme": theme,
                "type_primary": type_primary,
                "q": q,
                "sort": sort,
                "cursor": cursor,
                "limit": limit,
                "direction": direction,
                "confidence": confidence,
                "stability": stability,
                "scale": scale,
                "notability": notability,
            }
        )
        return _request(self._client, "GET", "/v1/entities", params=params)

    def get(self, name_or_id):
        path = f"/v1/entities/{_quote(name_or_id)}"
        return _request(self._client, "GET", path)

    def list_all(self, **kwargs):
        """Auto-paginating iterator that yields every entity matching the filters."""
        return _paginate(self._client, "/v1/entities", kwargs)
