"""Themes resource."""

from __future__ import annotations

from ..pagination import _clean, _quote, _request


class ThemesResource:
    def __init__(self, client):
        self._client = client

    def list(self, *, axis=None):
        params = _clean({"axis": axis})
        return _request(self._client, "GET", "/v1/themes", params=params)

    def get(self, axis, label):
        path = f"/v1/themes/{_quote(axis)}/{_quote(label)}"
        return _request(self._client, "GET", path)
