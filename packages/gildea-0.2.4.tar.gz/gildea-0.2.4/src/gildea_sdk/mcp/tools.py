"""MCP tool implementations — thin HTTP proxies to the REST API."""

from __future__ import annotations

from typing import Any
from urllib.parse import quote

import httpx


async def search_text_units(
    client: httpx.AsyncClient,
    *,
    q: str | None = None,
    similar_to: str | None = None,
    unit_type: str | None = None,
    entity: str | None = None,
    theme: str | None = None,
    published_after: str | None = None,
    published_before: str | None = None,
    recency_boost: float | None = None,
    verification_detail: str | None = None,
    limit: int = 10,
) -> dict[str, Any]:
    params: dict[str, Any] = {"limit": limit}
    if q:
        params["q"] = q
    if similar_to:
        params["similar_to"] = similar_to
    if unit_type:
        params["unit_type"] = unit_type
    if entity:
        params["entity"] = entity
    if theme:
        params["theme"] = theme
    if published_after:
        params["published_after"] = published_after
    if published_before:
        params["published_before"] = published_before
    if recency_boost is not None:
        params["recency_boost"] = recency_boost
    if verification_detail:
        params["verification_detail"] = verification_detail
    resp = await client.get("/v1/search", params=params)
    resp.raise_for_status()
    return resp.json()


async def list_signals(
    client: httpx.AsyncClient,
    *,
    entity: str | None = None,
    theme: str | None = None,
    q: str | None = None,
    content_type: str | None = None,
    published_after: str | None = None,
    published_before: str | None = None,
    limit: int = 25,
) -> dict[str, Any]:
    params: dict[str, Any] = {"limit": limit}
    if entity:
        params["entity"] = entity
    if theme:
        params["theme"] = theme
    if q:
        params["q"] = q
    if content_type:
        params["content_type"] = content_type
    if published_after:
        params["published_after"] = published_after
    if published_before:
        params["published_before"] = published_before
    resp = await client.get("/v1/signals", params=params)
    resp.raise_for_status()
    return resp.json()


async def get_signal_detail(
    client: httpx.AsyncClient,
    *,
    signal_id: str,
    include: str | None = None,
    verification_detail: str | None = None,
) -> dict[str, Any]:
    params: dict[str, str] = {}
    if include:
        params["include"] = include
    if verification_detail:
        params["verification_detail"] = verification_detail
    resp = await client.get(f"/v1/signals/{quote(signal_id, safe='')}", params=params)
    resp.raise_for_status()
    return resp.json()


async def get_entity_profile(
    client: httpx.AsyncClient,
    *,
    name_or_id: str,
) -> dict[str, Any]:
    resp = await client.get(f"/v1/entities/{quote(name_or_id, safe='')}")
    resp.raise_for_status()
    return resp.json()


async def list_entities(
    client: httpx.AsyncClient,
    *,
    q: str | None = None,
    theme: str | None = None,
    type_primary: str | None = None,
    sort: str = "signal_count",
    limit: int = 25,
    direction: str | None = None,
    confidence: str | None = None,
    stability: str | None = None,
    scale: str | None = None,
    notability: str | None = None,
) -> dict[str, Any]:
    params: dict[str, Any] = {"sort": sort, "limit": limit}
    if q:
        params["q"] = q
    if theme:
        params["theme"] = theme
    if type_primary:
        params["type_primary"] = type_primary
    if direction:
        params["direction"] = direction
    if confidence:
        params["confidence"] = confidence
    if stability:
        params["stability"] = stability
    if scale:
        params["scale"] = scale
    if notability:
        params["notability"] = notability
    resp = await client.get("/v1/entities", params=params)
    resp.raise_for_status()
    return resp.json()


async def get_themes(
    client: httpx.AsyncClient,
    *,
    axis: str | None = None,
) -> dict[str, Any]:
    params: dict[str, str] = {}
    if axis:
        params["axis"] = axis
    resp = await client.get("/v1/themes", params=params)
    resp.raise_for_status()
    return resp.json()


async def get_theme_detail(
    client: httpx.AsyncClient,
    *,
    axis: str,
    label: str,
) -> dict[str, Any]:
    resp = await client.get(
        f"/v1/themes/{quote(axis, safe='')}/{quote(label, safe='')}"
    )
    resp.raise_for_status()
    return resp.json()
