"""Allow running MCP server as: python -m gildea_sdk.mcp"""

from gildea_sdk.mcp.server import main

main()
