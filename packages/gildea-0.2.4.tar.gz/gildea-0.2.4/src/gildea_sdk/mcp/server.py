"""MCP server for Gildea market intelligence data.

Modes:
    stdio (default): python -m gildea_sdk.mcp
    sse:             python -m gildea_sdk.mcp --sse
    sse (custom):    python -m gildea_sdk.mcp --sse --port 8001

Configuration via environment variables:
    GILDEA_API_KEY       - Required. API key for authentication.
    GILDEA_API_BASE_URL  - Base URL for the REST API (default: https://api.gildea.ai)
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os

import httpx
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from gildea_sdk.mcp import tools

server = Server("gildea")
_http_client: httpx.AsyncClient | None = None


def _json_result(data: dict) -> list[TextContent]:
    return [TextContent(type="text", text=json.dumps(data, default=str, indent=2))]


def _error_result(error: str) -> list[TextContent]:
    return _json_result({"error": error})


def _ensure_client() -> httpx.AsyncClient:
    global _http_client
    if _http_client is None:
        api_key = os.getenv("GILDEA_API_KEY", "")
        base_url = os.getenv("GILDEA_API_BASE_URL", "https://api.gildea.ai")
        if not api_key:
            raise ValueError("GILDEA_API_KEY environment variable is required")
        _http_client = httpx.AsyncClient(
            base_url=base_url,
            headers={"X-API-Key": api_key},
            timeout=30.0,
        )
    return _http_client


@server.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="search_text_units",
            description="Semantic search across all of Gildea's verified extractions — thesis sentences, arguments, summaries, and claims. Text units are Gildea's own analytical extractions from source material, independently verified for factual accuracy. They are not direct quotes. Two modes: q='search query' finds text units matching a natural language question; similar_to='unit_id' finds text units semantically similar to a known unit (best for consensus mapping and cross-source synthesis). Use cases: 'What do multiple sources say about X?' → q with broad query. 'Who else is saying something like this claim?' → similar_to with unit ID. Returns sentence-level results with source attribution. Set recency_boost (0-1) to favor newer signals. Set verification_detail=full for complete verification metadata.",
            inputSchema={
                "type": "object",
                "properties": {
                    "q": {"type": "string", "description": "Search query text. Required unless similar_to is provided."},
                    "similar_to": {"type": "string", "description": "Text unit ID to find similar units for. Uses the unit's stored embedding for pure vector similarity search. Required unless q is provided."},
                    "unit_type": {
                        "type": "string",
                        "enum": [
                            "thesis_sentence",
                            "argument_sentence",
                            "summary_sentence",
                            "analysis_claim",
                            "event_claim",
                        ],
                        "description": "Filter by text unit type",
                    },
                    "entity": {"type": "string", "description": "Filter by entity ID"},
                    "theme": {"type": "string", "description": "Filter by theme label"},
                    "published_after": {"type": "string", "description": "ISO 8601 date — only results published after this date"},
                    "published_before": {"type": "string", "description": "ISO 8601 date — only results published before this date"},
                    "recency_boost": {
                        "type": "number",
                        "description": "Recency weight (0=none, 1=max). Boosts newer signals in ranking.",
                        "default": 0.0,
                        "minimum": 0,
                        "maximum": 1,
                    },
                    "verification_detail": {
                        "type": "string",
                        "enum": ["full"],
                        "description": "Include full verification metadata",
                    },
                    "limit": {"type": "integer", "default": 10, "maximum": 25},
                },
                "oneOf": [
                    {"required": ["q"]},
                    {"required": ["similar_to"]},
                ],
            },
        ),
        Tool(
            name="list_signals",
            description="Find intelligence signals about the AI economy from 500+ expert sources. Each signal is a structured analysis or event report that has been decomposed into verified components (thesis → arguments → claims for analysis; summary → claims for events). This endpoint returns signal metadata — use get_signal_detail to access the full verified decomposition tree. All filters are optional. Without filters, returns the most recent signals sorted by date. Use cases: 'What's happening with [company]?' → filter by entity. 'What's new in AI regulation?' → filter by theme. 'Anything about open source models?' → text query. 'What's new today?' → no filter, most recent. Each result includes title, source, date, tags (value chain + market force), mentioned entities, and count of verified text units.",
            inputSchema={
                "type": "object",
                "properties": {
                    "entity": {"type": "string", "description": "Entity ID filter"},
                    "theme": {"type": "string", "description": "Theme label filter"},
                    "q": {"type": "string", "description": "Text search query"},
                    "content_type": {"type": "string", "enum": ["analysis", "event"]},
                    "published_after": {"type": "string", "description": "ISO date"},
                    "published_before": {"type": "string", "description": "ISO date"},
                    "limit": {"type": "integer", "default": 25, "maximum": 50},
                },
            },
        ),
        Tool(
            name="get_signal_detail",
            description="Get the full verified reasoning chain for a signal. This is where Gildea's value lives. Analysis signals decompose into: thesis → supporting arguments → verified claims. Event signals decompose into: summary → verified claims. Each piece has been independently verified against source evidence. Use this tool liberally — it's the difference between showing a user metadata and showing them the actual verified intelligence. Set include=evidence to see the source snippets each claim was verified against. Set verification_detail=full for complete verification metadata.",
            inputSchema={
                "type": "object",
                "properties": {
                    "signal_id": {"type": "string", "description": "Signal ID"},
                    "include": {
                        "type": "string",
                        "enum": ["evidence"],
                        "description": "Include evidence snippets",
                    },
                    "verification_detail": {
                        "type": "string",
                        "enum": ["full"],
                        "description": "Include full verification metadata",
                    },
                },
                "required": ["signal_id"],
            },
        ),
        Tool(
            name="get_entity_profile",
            description="Get an intelligence profile for a company, person, or product. Returns: whether the entity is rising, stable, or declining in expert coverage; how much attention it's getting relative to others (scale); whether the trend is statistically significant; and a notability assessment. Use this to understand an entity's trajectory before diving into specific signals. Accepts display name (e.g. 'NVIDIA') or entity ID. Note: entities with fewer than 8 mentions in the 12-week window return limited trend data.",
            inputSchema={
                "type": "object",
                "properties": {
                    "name_or_id": {
                        "type": "string",
                        "description": "Entity name (fuzzy matched) or entity UUID",
                    },
                },
                "required": ["name_or_id"],
            },
        ),
        Tool(
            name="list_entities",
            description="Discover which companies, people, and products are getting expert attention in the AI economy. Filter by trend direction (Rising/Stable/Declining), notability level, coverage scale, and more. Use this for discovery — finding what's worth paying attention to. Common patterns: 'What's trending?' → direction=Rising, confidence=Significant. 'What should I watch?' → notability=High. 'Any new entrants?' → direction=New.",
            inputSchema={
                "type": "object",
                "properties": {
                    "q": {"type": "string", "description": "Fuzzy name search"},
                    "theme": {"type": "string", "description": "Filter by theme label"},
                    "type_primary": {
                        "type": "string",
                        "description": "Filter by entity type: 'organization', 'person', 'product', 'model', 'hardware', 'software', 'framework', 'dataset', 'benchmark', 'regulation_policy', 'publication', 'event', 'concept', 'distribution_channel', 'location'.",
                    },
                    "sort": {
                        "type": "string",
                        "enum": ["signal_count", "first_seen", "trend"],
                        "default": "signal_count",
                    },
                    "direction": {
                        "type": "string",
                        "enum": ["Rising", "Stable", "Declining", "New"],
                        "description": "Filter by trend direction",
                    },
                    "confidence": {
                        "type": "string",
                        "enum": ["Significant", "Insignificant"],
                        "description": "Filter by trend statistical significance",
                    },
                    "stability": {
                        "type": "string",
                        "enum": ["Volatile", "Steady"],
                        "description": "Filter by coverage consistency",
                    },
                    "scale": {
                        "type": "string",
                        "enum": ["Large", "Medium", "Small"],
                        "description": "Filter by share-of-voice scale",
                    },
                    "notability": {
                        "type": "string",
                        "enum": ["High", "Medium", "Low", "Negligible"],
                        "description": "Filter by notability — how much this entity warrants attention right now",
                    },
                    "limit": {"type": "integer", "default": 25, "maximum": 50},
                },
            },
        ),
        Tool(
            name="get_themes",
            description="List all taxonomy themes across two axes that categorize the AI economy. Value chain axis (where in the stack): Infrastructure, Foundation Models, Orchestration, Data & Labeling, Applications, Distribution. Market force axis (what's driving change): Capital & Investment, Regulatory & Legal, Competitive Dynamics, Talent & Labor, Geopolitical Strategy, Trust & Societal Impact. Each theme includes signal counts, trend direction, and notability. Use get_theme_detail for full trend analytics and co-occurring themes.",
            inputSchema={
                "type": "object",
                "properties": {
                    "axis": {
                        "type": "string",
                        "enum": ["value_chain", "market_force"],
                        "description": "Filter by taxonomy axis",
                    },
                },
            },
        ),
        Tool(
            name="get_theme_detail",
            description="Get a specific theme's full trend analytics and co-occurring themes from both axes. Returns trend direction, statistical confidence, stability, notability with reasoning, and which themes from the other axis most frequently co-occur. Use this to understand how themes interconnect. Example: 'Foundation Models' co-occurring heavily with 'Competitive Dynamics' signals a competitive landscape shift in the model layer.",
            inputSchema={
                "type": "object",
                "properties": {
                    "axis": {"type": "string", "enum": ["value_chain", "market_force"]},
                    "label": {"type": "string", "description": "Theme label"},
                },
                "required": ["axis", "label"],
            },
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    try:
        client = _ensure_client()
    except ValueError as e:
        return _error_result(f"Authentication failed: {e}")

    handlers = {
        "search_text_units": lambda: tools.search_text_units(client, **arguments),
        "list_signals": lambda: tools.list_signals(client, **arguments),
        "get_signal_detail": lambda: tools.get_signal_detail(client, **arguments),
        "get_entity_profile": lambda: tools.get_entity_profile(client, **arguments),
        "list_entities": lambda: tools.list_entities(client, **arguments),
        "get_themes": lambda: tools.get_themes(client, **arguments),
        "get_theme_detail": lambda: tools.get_theme_detail(client, **arguments),
    }

    handler = handlers.get(name)
    if not handler:
        return _error_result(f"Unknown tool: {name}")

    try:
        result = await handler()
        return _json_result(result)
    except httpx.HTTPStatusError as e:
        status = e.response.status_code
        try:
            body = e.response.json()
            message = body.get("error", {}).get("message", e.response.text)
        except Exception:
            message = e.response.text
        if status in (401, 403):
            return _error_result(f"Authentication failed: {message}")
        if status == 429:
            return _error_result(f"Rate limit exceeded: {message}")
        if status == 400:
            return _error_result(message)
        return _error_result(f"API error: {message}")
    except httpx.RequestError as e:
        return _error_result(f"API connection error: {e}")


# --- Transport modes ---


async def _run_stdio() -> None:
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream, write_stream, server.create_initialization_options()
        )


def _create_sse_app(host: str, port: int):
    """Create a Starlette app that serves the MCP server over SSE."""
    from mcp.server.sse import SseServerTransport
    from starlette.applications import Starlette
    from starlette.routing import Mount, Route

    sse_transport = SseServerTransport("/messages/")

    async def handle_sse(scope, receive, send):
        async with sse_transport.connect_sse(scope, receive, send) as (
            read_stream,
            write_stream,
        ):
            await server.run(
                read_stream, write_stream, server.create_initialization_options()
            )

    return Starlette(
        routes=[
            Route("/sse", app=handle_sse),
            Mount("/messages/", app=sse_transport.handle_post_message),
        ],
    )


def _run_sse(host: str, port: int) -> None:
    import uvicorn

    app = _create_sse_app(host, port)
    uvicorn.run(app, host=host, port=port)


def main() -> None:
    parser = argparse.ArgumentParser(description="Gildea MCP Server")
    parser.add_argument(
        "--sse", action="store_true", help="Run in SSE mode (HTTP server)"
    )
    parser.add_argument("--host", default="0.0.0.0", help="SSE host (default: 0.0.0.0)")
    parser.add_argument(
        "--port", type=int, default=8001, help="SSE port (default: 8001)"
    )
    args = parser.parse_args()

    if args.sse:
        _run_sse(args.host, args.port)
    else:
        asyncio.run(_run_stdio())


if __name__ == "__main__":
    main()
