"""Gildea Python SDK — client for the Gildea AI market intelligence API."""

from .client import Gildea
from .exceptions import (
    APIError,
    AuthenticationError,
    BadRequestError,
    GildeaError,
    NotFoundError,
    RateLimitError,
)

__all__ = [
    "Gildea",
    "GildeaError",
    "AuthenticationError",
    "NotFoundError",
    "RateLimitError",
    "BadRequestError",
    "APIError",
]
