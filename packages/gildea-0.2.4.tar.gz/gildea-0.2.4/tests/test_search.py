"""Tests for the search resource."""

import pytest


SEARCH_RESPONSE = {
    "data": [
        {
            "unit_id": "clm_01J123",
            "unit_type": "analysis_claim",
            "text": "NVIDIA increased H200 shipments",
            "signal_id": "sig_01J456",
            "score": 0.82,
        }
    ],
    "query": "AI chip supply chain",
}

SIMILAR_RESPONSE = {
    "data": [
        {
            "unit_id": "clm_01J789",
            "unit_type": "analysis_claim",
            "text": "AMD ramped MI300X production",
            "signal_id": "sig_01J012",
            "score": 0.75,
        }
    ],
    "similar_to": "clm_01J123",
}


def _sent_params(httpx_mock):
    """Extract query params from the single request httpx_mock captured."""
    request = httpx_mock.get_request()
    return dict(request.url.params)


class TestSearch:
    def test_basic_search(self, mock_client, httpx_mock):
        httpx_mock.add_response(json=SEARCH_RESPONSE)
        result = mock_client.search("AI chip supply chain")
        assert result["data"][0]["unit_type"] == "analysis_claim"
        params = _sent_params(httpx_mock)
        assert params["q"] == "AI chip supply chain"
        assert "similar_to" not in params

    def test_search_with_filters(self, mock_client, httpx_mock):
        httpx_mock.add_response(json=SEARCH_RESPONSE)
        mock_client.search(
            "AI chip supply chain",
            unit_type="analysis_claim",
            entity="NVIDIA",
            theme="AI Infrastructure",
            recency_boost=0.5,
            verification_detail="full",
            limit=5,
        )
        params = _sent_params(httpx_mock)
        assert params["q"] == "AI chip supply chain"
        assert params["unit_type"] == "analysis_claim"
        assert params["entity"] == "NVIDIA"
        assert params["theme"] == "AI Infrastructure"
        assert params["recency_boost"] == "0.5"
        assert params["verification_detail"] == "full"
        assert params["limit"] == "5"

    def test_similar_to_search(self, mock_client, httpx_mock):
        httpx_mock.add_response(json=SIMILAR_RESPONSE)
        result = mock_client.search(similar_to="clm_01J123")
        assert result["similar_to"] == "clm_01J123"
        params = _sent_params(httpx_mock)
        assert params["similar_to"] == "clm_01J123"
        assert "q" not in params

    def test_similar_to_via_resource(self, mock_client, httpx_mock):
        httpx_mock.add_response(json=SIMILAR_RESPONSE)
        mock_client._search.query(similar_to="clm_01J123", limit=5)
        params = _sent_params(httpx_mock)
        assert params["similar_to"] == "clm_01J123"
        assert params["limit"] == "5"
        assert "q" not in params

    def test_similar_to_with_filters(self, mock_client, httpx_mock):
        httpx_mock.add_response(json=SIMILAR_RESPONSE)
        mock_client.search(
            similar_to="clm_01J123",
            unit_type="analysis_claim",
            entity="NVIDIA",
            limit=5,
        )
        params = _sent_params(httpx_mock)
        assert params["similar_to"] == "clm_01J123"
        assert params["unit_type"] == "analysis_claim"
        assert params["entity"] == "NVIDIA"
        assert "q" not in params

    def test_requires_q_or_similar_to(self, mock_client):
        with pytest.raises(ValueError, match="Exactly one"):
            mock_client.search()

    def test_rejects_both_q_and_similar_to(self, mock_client):
        with pytest.raises(ValueError, match="Exactly one"):
            mock_client.search("query", similar_to="clm_01J123")

    def test_published_after(self, mock_client, httpx_mock):
        httpx_mock.add_response(json=SEARCH_RESPONSE)
        mock_client.search("AI chips", published_after="2026-01-01")
        params = _sent_params(httpx_mock)
        assert params["published_after"] == "2026-01-01"

    def test_published_before(self, mock_client, httpx_mock):
        httpx_mock.add_response(json=SEARCH_RESPONSE)
        mock_client.search("AI chips", published_before="2026-03-01")
        params = _sent_params(httpx_mock)
        assert params["published_before"] == "2026-03-01"

    def test_date_range(self, mock_client, httpx_mock):
        httpx_mock.add_response(json=SEARCH_RESPONSE)
        mock_client.search(
            "AI chips",
            published_after="2026-01-01",
            published_before="2026-03-01",
        )
        params = _sent_params(httpx_mock)
        assert params["published_after"] == "2026-01-01"
        assert params["published_before"] == "2026-03-01"

    def test_similar_to_with_date_filters(self, mock_client, httpx_mock):
        httpx_mock.add_response(json=SIMILAR_RESPONSE)
        mock_client.search(
            similar_to="clm_01J123",
            published_after="2026-01-01",
            published_before="2026-03-01",
        )
        params = _sent_params(httpx_mock)
        assert params["similar_to"] == "clm_01J123"
        assert params["published_after"] == "2026-01-01"
        assert params["published_before"] == "2026-03-01"
        assert "q" not in params
