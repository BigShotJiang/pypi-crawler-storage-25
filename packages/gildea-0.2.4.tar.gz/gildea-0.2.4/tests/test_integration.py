"""Integration tests that hit the real Gildea API.

Skipped automatically when GILDEA_API_KEY is not set.

Usage:
    GILDEA_API_KEY=gld_... pytest sdk/tests/test_integration.py -v
    GILDEA_API_KEY=gld_... GILDEA_BASE_URL=http://localhost:8000 pytest sdk/tests/test_integration.py -v
"""

import os
import time

import pytest

from gildea_sdk import (
    Gildea,
    AuthenticationError,
    NotFoundError,
)

SKIP_REASON = "GILDEA_API_KEY not set — skipping integration tests"
pytestmark = pytest.mark.skipif(
    not os.environ.get("GILDEA_API_KEY"), reason=SKIP_REASON
)


@pytest.fixture(scope="module")
def client():
    base_url = os.environ.get("GILDEA_BASE_URL", "https://api.gildea.ai")
    c = Gildea(base_url=base_url)
    yield c
    c.close()


@pytest.fixture(autouse=True)
def rate_limit_pause():
    """Small delay between tests to stay under 30 rpm."""
    yield
    time.sleep(3)


# ── Signals ──────────────────────────────────────────────────────────


class TestSignals:
    def test_list_with_q(self, client):
        resp = client.signals.list(q="AI", limit=3)
        assert "data" in resp
        assert isinstance(resp["data"], list)
        assert "has_more" in resp
        if resp["data"]:
            sig = resp["data"][0]
            assert "signal_id" in sig
            assert "title" in sig
            assert "content_type" in sig
            assert "published_at" in sig
            assert "tags" in sig
            assert "entities" in sig
            assert "verified_text_unit_count" in sig

    def test_list_with_entity_filter(self, client):
        resp = client.signals.list(entity="NVIDIA", limit=3)
        assert "data" in resp

    def test_list_with_theme_filter(self, client):
        themes = client.themes.list(axis="value_chain")
        if not themes["data"]:
            pytest.skip("No themes available")
        label = themes["data"][0]["label"]
        resp = client.signals.list(theme=label, limit=3)
        assert "data" in resp

    def test_list_with_content_type_filter(self, client):
        resp = client.signals.list(q="AI", content_type="analysis", limit=3)
        assert "data" in resp
        for sig in resp["data"]:
            assert sig["content_type"] == "analysis"

    def test_list_with_date_filters(self, client):
        resp = client.signals.list(
            q="AI",
            published_after="2026-01-01",
            published_before="2026-12-31",
            limit=3,
        )
        assert "data" in resp

    def test_get_basic(self, client):
        listing = client.signals.list(q="AI", limit=1)
        if not listing["data"]:
            pytest.skip("No signals available")
        signal_id = listing["data"][0]["signal_id"]

        detail = client.signals.get(signal_id)
        assert detail["signal_id"] == signal_id
        assert "decomposition" in detail
        assert "tags" in detail
        assert "entities" in detail

    def test_get_with_evidence_and_verification_detail(self, client):
        listing = client.signals.list(q="AI", limit=1)
        if not listing["data"]:
            pytest.skip("No signals available")
        signal_id = listing["data"][0]["signal_id"]

        detail = client.signals.get(
            signal_id, include="evidence", verification_detail="full"
        )
        assert detail["signal_id"] == signal_id

    def test_get_nonexistent_raises_not_found(self, client):
        with pytest.raises(NotFoundError):
            client.signals.get("sig_00000000000000000000000000")

    def test_list_all_paginates(self, client):
        items = []
        for item in client.signals.list_all(q="AI", limit=2):
            items.append(item)
            if len(items) >= 5:
                break
        assert len(items) > 0
        assert "signal_id" in items[0]


# ── Entities ─────────────────────────────────────────────────────────


class TestEntities:
    def test_list_with_q(self, client):
        resp = client.entities.list(q="AI", limit=3)
        assert "data" in resp
        assert isinstance(resp["data"], list)
        if resp["data"]:
            ent = resp["data"][0]
            assert "entity_id" in ent
            assert "display_name" in ent
            assert "type_primary" in ent
            assert "signal_count" in ent

    def test_list_by_type(self, client):
        resp = client.entities.list(type_primary="organization", q="AI", limit=3)
        assert "data" in resp
        for ent in resp["data"]:
            assert ent["type_primary"] == "organization"

    def test_list_sort_signal_count(self, client):
        resp = client.entities.list(q="AI", sort="signal_count", limit=3)
        assert "data" in resp
        counts = [e["signal_count"] for e in resp["data"]]
        assert counts == sorted(counts, reverse=True)

    def test_list_sort_first_seen(self, client):
        resp = client.entities.list(q="AI", sort="first_seen", limit=3)
        assert "data" in resp

    def test_list_sort_trend(self, client):
        resp = client.entities.list(q="AI", sort="trend", limit=3)
        assert "data" in resp

    def test_list_with_theme_filter(self, client):
        themes = client.themes.list(axis="value_chain")
        if not themes["data"]:
            pytest.skip("No themes available")
        label = themes["data"][0]["label"]
        resp = client.entities.list(theme=label, limit=3)
        assert "data" in resp

    def test_get_by_name(self, client):
        listing = client.entities.list(q="AI", limit=1)
        if not listing["data"]:
            pytest.skip("No entities available")
        name = listing["data"][0]["display_name"]

        detail = client.entities.get(name)
        assert "entity_id" in detail
        assert "display_name" in detail
        assert "related_entities" in detail

    def test_get_by_id(self, client):
        listing = client.entities.list(q="AI", limit=1)
        if not listing["data"]:
            pytest.skip("No entities available")
        entity_id = listing["data"][0]["entity_id"]

        detail = client.entities.get(entity_id)
        assert detail["entity_id"] == entity_id

    def test_list_direction_filter(self, client):
        resp = client.entities.list(direction="Rising", sort="trend", limit=5)
        assert "data" in resp
        for ent in resp["data"]:
            assert ent.get("direction") == "Rising"

    def test_list_composable_filters(self, client):
        resp = client.entities.list(
            direction="Rising", confidence="Significant", sort="trend", limit=5
        )
        assert "data" in resp
        for ent in resp["data"]:
            assert ent.get("direction") == "Rising"
            assert ent.get("confidence") == "Significant"

    def test_list_scale_filter(self, client):
        resp = client.entities.list(scale="Large", limit=5)
        assert "data" in resp
        for ent in resp["data"]:
            assert ent.get("scale") == "Large"

    def test_list_all_paginates(self, client):
        items = []
        for item in client.entities.list_all(q="AI", limit=2):
            items.append(item)
            if len(items) >= 5:
                break
        assert len(items) > 0
        assert "entity_id" in items[0]


# ── Themes ───────────────────────────────────────────────────────────


class TestThemes:
    def test_list_all_themes(self, client):
        resp = client.themes.list()
        assert "data" in resp
        assert isinstance(resp["data"], list)
        assert len(resp["data"]) > 0
        theme = resp["data"][0]
        assert "axis" in theme
        assert "label" in theme
        assert "signal_count" in theme

    def test_list_value_chain(self, client):
        resp = client.themes.list(axis="value_chain")
        assert "data" in resp
        for theme in resp["data"]:
            assert theme["axis"] == "value_chain"

    def test_list_market_force(self, client):
        resp = client.themes.list(axis="market_force")
        assert "data" in resp
        for theme in resp["data"]:
            assert theme["axis"] == "market_force"

    def test_get_value_chain_theme(self, client):
        listing = client.themes.list(axis="value_chain")
        if not listing["data"]:
            pytest.skip("No value_chain themes available")
        theme = listing["data"][0]

        detail = client.themes.get(theme["axis"], theme["label"])
        assert detail["axis"] == theme["axis"]
        assert detail["label"] == theme["label"]
        assert "related_themes" in detail

    def test_get_market_force_theme(self, client):
        listing = client.themes.list(axis="market_force")
        if not listing["data"]:
            pytest.skip("No market_force themes available")
        theme = listing["data"][0]

        detail = client.themes.get(theme["axis"], theme["label"])
        assert detail["axis"] == "market_force"


# ── Search ───────────────────────────────────────────────────────────


class TestSearch:
    def test_basic_search(self, client):
        resp = client.search("AI", limit=5)
        assert "data" in resp
        assert "query" in resp
        assert isinstance(resp["data"], list)
        if resp["data"]:
            entry = resp["data"][0]
            assert "unit" in entry
            assert "unit_id" in entry["unit"]
            assert "unit_type" in entry["unit"]
            assert "text" in entry["unit"]
            assert "relevance_score" in entry
            assert "citation" in entry
            assert "verification" in entry

    def test_search_by_unit_type(self, client):
        resp = client.search("AI", unit_type="analysis_claim", limit=3)
        assert "data" in resp
        for entry in resp["data"]:
            assert entry["unit"]["unit_type"] == "analysis_claim"

    def test_search_with_entity_filter(self, client):
        # Get a real entity ID first
        entities = client.entities.list(q="AI", limit=1)
        if not entities["data"]:
            pytest.skip("No entities available")
        entity_id = entities["data"][0]["entity_id"]

        resp = client.search("AI", entity=entity_id, limit=3)
        assert "data" in resp

    def test_search_with_theme_filter(self, client):
        themes = client.themes.list(axis="value_chain")
        if not themes["data"]:
            pytest.skip("No themes available")
        label = themes["data"][0]["label"]

        resp = client.search("AI", theme=label, limit=3)
        assert "data" in resp

    def test_search_with_recency_boost(self, client):
        resp = client.search("AI", recency_boost=0.5, limit=3)
        assert "data" in resp

    def test_search_with_verification_detail(self, client):
        resp = client.search("AI", verification_detail="full", limit=3)
        assert "data" in resp
        if resp["data"]:
            v = resp["data"][0]["verification"]
            assert "final_verdict" in v
            assert "scoring_mode" in v

    def test_search_similar_to(self, client):
        # Get a real unit ID from a q search first
        seed = client.search("AI", limit=1)
        if not seed["data"]:
            pytest.skip("No search results to seed similar_to")
        unit_id = seed["data"][0]["unit"]["unit_id"]

        resp = client.search(similar_to=unit_id, limit=3)
        assert "data" in resp
        assert resp.get("similar_to") == unit_id
        assert isinstance(resp["data"], list)
        if resp["data"]:
            entry = resp["data"][0]
            assert "unit" in entry
            assert "relevance_score" in entry

    def test_search_similar_to_with_date_filter(self, client):
        seed = client.search("AI", limit=1)
        if not seed["data"]:
            pytest.skip("No search results to seed similar_to")
        unit_id = seed["data"][0]["unit"]["unit_id"]

        resp = client.search(
            similar_to=unit_id,
            published_after="2025-01-01",
            limit=3,
        )
        assert "data" in resp
        assert resp.get("similar_to") == unit_id

    def test_search_with_published_after(self, client):
        resp = client.search("AI", published_after="2026-01-01", limit=3)
        assert "data" in resp
        for entry in resp["data"]:
            assert entry["citation"]["published_at"] >= "2026-01-01"

    def test_search_with_date_range(self, client):
        resp = client.search(
            "AI",
            published_after="2026-01-01",
            published_before="2026-03-01",
            limit=3,
        )
        assert "data" in resp
        for entry in resp["data"]:
            pub = entry["citation"]["published_at"]
            assert pub >= "2026-01-01"
            assert pub < "2026-03-01"


# ── Error handling ───────────────────────────────────────────────────


class TestErrors:
    def test_search_requires_q_or_similar_to(self, client):
        with pytest.raises(ValueError, match="Exactly one"):
            client.search()

    def test_nonexistent_signal_raises_not_found(self, client):
        with pytest.raises(NotFoundError):
            client.signals.get("sig_00000000000000000000000000")

    def test_invalid_api_key_raises_auth_error(self):
        base_url = os.environ.get("GILDEA_BASE_URL", "https://api.gildea.ai")
        bad_client = Gildea(api_key="gld_invalid_key_000", base_url=base_url)
        with pytest.raises(AuthenticationError):
            bad_client.signals.list(q="AI", limit=1)
        bad_client.close()
