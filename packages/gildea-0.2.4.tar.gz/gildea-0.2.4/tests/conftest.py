"""Shared fixtures for SDK tests."""

import pytest
import httpx

from gildea_sdk import Gildea


@pytest.fixture
def mock_client(monkeypatch):
    """Return a Gildea client with a mocked httpx.Client."""
    monkeypatch.setenv("GILDEA_API_KEY", "test-key-123")
    return Gildea(api_key="test-key-123", base_url="https://test.gildea.ai")


def make_response(status_code=200, json_data=None, headers=None):
    """Build an httpx.Response for testing."""
    return httpx.Response(
        status_code=status_code,
        json=json_data or {},
        headers=headers or {},
        request=httpx.Request("GET", "https://test.gildea.ai/v1/test"),
    )
