"""Tests for error handling and exception mapping."""

import httpx
import pytest

from gildea_sdk import (
    AuthenticationError,
    BadRequestError,
    NotFoundError,
    RateLimitError,
    APIError,
)
from gildea_sdk.pagination import _request


def _make_client():
    """Create a bare httpx.Client for testing _request directly."""
    return httpx.Client(base_url="https://test.gildea.ai")


class TestErrorMapping:
    def test_401_raises_authentication_error(self, httpx_mock):
        httpx_mock.add_response(
            status_code=401,
            json={"error": {"code": "unauthorized", "message": "Invalid API key", "status": 401}},
        )
        client = _make_client()
        with pytest.raises(AuthenticationError, match="Invalid API key") as exc_info:
            _request(client, "GET", "/v1/signals")
        assert exc_info.value.status == 401
        assert exc_info.value.code == "unauthorized"
        client.close()

    def test_403_raises_authentication_error(self, httpx_mock):
        httpx_mock.add_response(
            status_code=403,
            json={"error": {"code": "forbidden", "message": "Access denied", "status": 403}},
        )
        client = _make_client()
        with pytest.raises(AuthenticationError):
            _request(client, "GET", "/v1/signals")
        client.close()

    def test_404_raises_not_found_error(self, httpx_mock):
        httpx_mock.add_response(
            status_code=404,
            json={"error": {"code": "not_found", "message": "Signal not found", "status": 404}},
        )
        client = _make_client()
        with pytest.raises(NotFoundError, match="Signal not found") as exc_info:
            _request(client, "GET", "/v1/signals/bad_id")
        assert exc_info.value.status == 404
        client.close()

    def test_429_raises_rate_limit_error_with_retry_after(self, httpx_mock):
        httpx_mock.add_response(
            status_code=429,
            json={"error": {"code": "rate_limited", "message": "Too many requests", "status": 429}},
            headers={"Retry-After": "30"},
        )
        client = _make_client()
        with pytest.raises(RateLimitError) as exc_info:
            _request(client, "GET", "/v1/signals")
        assert exc_info.value.retry_after == 30
        assert exc_info.value.status == 429
        client.close()

    def test_429_without_retry_after(self, httpx_mock):
        httpx_mock.add_response(
            status_code=429,
            json={"error": {"code": "rate_limited", "message": "Too many requests", "status": 429}},
        )
        client = _make_client()
        with pytest.raises(RateLimitError) as exc_info:
            _request(client, "GET", "/v1/signals")
        assert exc_info.value.retry_after is None
        client.close()

    def test_400_raises_bad_request_error(self, httpx_mock):
        httpx_mock.add_response(
            status_code=400,
            json={"error": {"code": "bad_request", "message": "Missing required param", "status": 400}},
        )
        client = _make_client()
        with pytest.raises(BadRequestError, match="Missing required param"):
            _request(client, "GET", "/v1/signals")
        client.close()

    def test_500_raises_api_error(self, httpx_mock):
        httpx_mock.add_response(
            status_code=500,
            json={"error": {"code": "internal_error", "message": "Server error", "status": 500}},
        )
        client = _make_client()
        with pytest.raises(APIError, match="Server error") as exc_info:
            _request(client, "GET", "/v1/signals")
        assert exc_info.value.status == 500
        client.close()
