# Jentic API Tools - Storage

Pluggable storage backends for persisting OpenAPI pipeline artifacts to filesystem, S3, GitHub repositories, or SQL databases.

## Key Features

The storage package provides a `StorageBackend` abstract base class implemented by four backends: `FilesystemStorage` (default), `S3Storage`, `GitHubStorage`, and `DatabaseStorage`. A `StorageContext` context manager handles the lifecycle of temporary working directories during pipeline processing and persists results to the configured backend on exit. Helper functions create storage contexts from request metadata or environment variables, with fallback support. S3, GitHub, and database backends are imported on demand to avoid requiring their dependencies when unused.

## Dependencies

Internal: `jentic.apitools.common`. External: sqlalchemy, PyGithub. Optional: boto3 (for S3).

## Installation

```bash
pip install jentic-apitools-storage
```

## Quick Start

```python
from jentic.apitools.storage import StorageConfig, StorageType, StorageContext

config = StorageConfig(storage_type=StorageType.FILESYSTEM, base_path="./artifacts")
with StorageContext(config) as ctx:
    # Pipeline writes to ctx.working_dir
    pass
```

## Testing

```bash
pytest tests -v
```
