"""Storage abstraction layer for OpenAPI import pipeline.

This module provides a DAO-like pattern for persisting artifacts to different backends
(filesystem, S3, database, GitHub) while maintaining compatibility with tools that expect
file:// or http:// URIs during processing.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from enum import Enum
from typing import Any, Optional


__all__ = [
    "StorageBackend",
    "StorageType",
    "StorageConfig",
]


class StorageType(str, Enum):
    """Supported storage backend types."""

    FILESYSTEM = "filesystem"
    S3 = "s3"
    DATABASE = "database"
    GITHUB = "github"


class StorageConfig:
    """Configuration for storage backends."""

    def __init__(
        self,
        storage_type: StorageType = StorageType.FILESYSTEM,
        base_path: Optional[str] = None,
        **kwargs: Any,
    ):
        """Initialize storage configuration.

        Args:
            storage_type: Type of storage backend
            base_path: Base path/prefix for storage (filesystem path, S3 prefix, DB table, etc.)
            **kwargs: Backend-specific configuration (e.g., bucket, credentials, etc.)
        """
        self.storage_type = storage_type
        self.base_path = base_path
        self.config = kwargs


class StorageBackend(ABC):
    """Abstract base class for storage backends.

    Each backend must support:
    1. Writing content to storage
    2. Reading content from storage
    3. Providing resolvable URIs for tools during processing
    4. Cleaning up resources
    """

    def __init__(self, config: StorageConfig):
        """Initialize storage backend.

        Args:
            config: Storage configuration
        """
        self.config = config

    @abstractmethod
    def write_file(self, relative_path: str, content: str | bytes, encoding: str = "utf-8") -> None:
        """Write content to storage.

        Args:
            relative_path: Path relative to base_path (e.g., "vendor/api/version/openapi.json")
            content: File content as string or bytes
            encoding: Text encoding if content is string
        """
        pass

    @abstractmethod
    def read_file(self, relative_path: str, encoding: str = "utf-8") -> str | bytes:
        """Read content from storage.

        Args:
            relative_path: Path relative to base_path
            encoding: Text encoding for text files

        Returns:
            File content
        """
        pass

    @abstractmethod
    def exists(self, relative_path: str) -> bool:
        """Check if a file exists in storage.

        Args:
            relative_path: Path relative to base_path

        Returns:
            True if file exists
        """
        pass

    @abstractmethod
    def delete_file(self, relative_path: str) -> None:
        """Delete a file from storage.

        Args:
            relative_path: Path relative to base_path
        """
        pass

    @abstractmethod
    def get_public_url(self, relative_path: str) -> str | None:
        """Get public URL for accessing the file (if applicable).

        Args:
            relative_path: Path relative to base_path

        Returns:
            Public URL or None if not applicable
        """
        pass

    @abstractmethod
    def cleanup(self) -> None:
        """Clean up any resources (temp files, connections, etc.)."""
        pass
