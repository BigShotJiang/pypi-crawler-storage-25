"""Storage abstraction layer."""

from jentic.apitools.storage.base import StorageBackend, StorageConfig, StorageType
from jentic.apitools.storage.context import StorageContext, create_storage_backend, storage_context
from jentic.apitools.storage.filesystem import FilesystemStorage
from jentic.apitools.storage.helpers import (
    create_storage_context_from_oas_request_meta,
    create_storage_context_with_fallback,
    get_storage_config_from_env,
)


__all__ = [
    "StorageBackend",
    "StorageConfig",
    "StorageType",
    "FilesystemStorage",
    "StorageContext",
    "create_storage_backend",
    "storage_context",
    "create_storage_context_from_oas_request_meta",
    "get_storage_config_from_env",
    "create_storage_context_with_fallback",
]


# Optional backends (imported on demand)
def get_s3_storage():
    from jentic.apitools.storage.s3 import S3Storage

    return S3Storage


def get_database_storage():
    from jentic.apitools.storage.database import DatabaseStorage

    return DatabaseStorage


def get_github_storage():
    from jentic.apitools.storage.github import GitHubStorage

    return GitHubStorage
