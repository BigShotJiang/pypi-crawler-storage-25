"""GitHub repository storage backend."""

from __future__ import annotations

import base64
import tempfile
from pathlib import Path
from typing import Dict, Optional

from jentic.apitools.common.utils.logging import get_module_logger
from jentic.apitools.storage.base import StorageBackend, StorageConfig


logger = get_module_logger(__name__)

__all__ = ["GitHubStorage"]


class GitHubStorage(StorageBackend):
    """Storage backend that writes to a GitHub repository.

    During processing, files are written to a local temp directory.
    On finalization, they can be committed and pushed to GitHub.

    This backend maintains compatibility with the existing vcs.py utilities.
    """

    def __init__(self, config: StorageConfig):
        """Initialize GitHub storage.

        Args:
            config: Storage configuration with:
                - repo: Repository in format "owner/repo"
                - branch: Target branch
                - prefix: Optional path prefix within repo (e.g., "apis/openapi")
                - token: GitHub personal access token (optional, uses environment)
                - commit_message: Default commit message template
        """
        super().__init__(config)

        # Import PyGithub here to make it optional
        try:
            from github import Auth, Github, GithubException, InputGitTreeElement

            self.Github = Github
            self.GithubException = GithubException
            self.Auth = Auth
            self.InputGitTreeElement = InputGitTreeElement
        except ImportError:
            raise ImportError(
                "PyGithub is required for GitHub storage. Install with: pip install PyGithub"
            )

        self.repo_name = config.config.get("repo") or ""
        if not self.repo_name:
            raise ValueError("GitHub storage requires 'repo' in config (format: owner/repo)")

        self.branch = config.config.get("branch", "main")
        self.prefix = config.config.get("prefix", "")
        self.token = config.config.get("token")
        self.commit_message_template = config.config.get(
            "commit_message", "chore: update OpenAPI artifacts for {path}"
        )

        # Initialize GitHub client
        if self.token:
            auth = self.Auth.Token(self.token)
            self.github = self.Github(auth=auth)
        else:
            # Will use GITHUB_TOKEN environment variable
            self.github = self.Github()

        try:
            self.repo = self.github.get_repo(self.repo_name)
            logger.debug(f"Connected to GitHub repo: {self.repo_name}")
        except self.GithubException as e:
            raise ValueError(f"Failed to access GitHub repo {self.repo_name}: {e}")

        # Local staging area for files before commit
        self.temp_dir = Path(tempfile.mkdtemp(prefix="github_storage_"))
        self.staged_files: Dict[str, bytes | None] = {}  # Track files to commit
        logger.debug(
            f"Initialized GitHubStorage: repo={self.repo_name}, branch={self.branch}, temp={self.temp_dir}"
        )

    def _get_repo_path(self, relative_path: str) -> str:
        """Get full repository path from relative path."""
        if self.prefix:
            return f"{self.prefix.rstrip('/')}/{relative_path}"
        return relative_path

    def _get_local_path(self, relative_path: str) -> Path:
        """Get local temp path for staging."""
        return self.temp_dir / relative_path

    def write_file(self, relative_path: str, content: str | bytes, encoding: str = "utf-8") -> None:
        """Write content to local staging area (will be committed on finalize).

        Args:
            relative_path: Path relative to base_path
            content: File content
            encoding: Text encoding if content is string
        """
        # Write to local staging
        local_path = self._get_local_path(relative_path)
        local_path.parent.mkdir(parents=True, exist_ok=True)

        if isinstance(content, str):
            local_path.write_text(content, encoding=encoding)
            content_bytes = content.encode(encoding)
        else:
            local_path.write_bytes(content)
            content_bytes = content

        # Stage for commit
        repo_path = self._get_repo_path(relative_path)
        self.staged_files[repo_path] = content_bytes
        logger.debug(f"Staged file for GitHub: {repo_path}")

    def read_file(self, relative_path: str, encoding: str = "utf-8") -> str | bytes:
        """Read content from local staging, or fetch from GitHub if needed.

        Args:
            relative_path: Path relative to base_path
            encoding: Text encoding for text files

        Returns:
            File content
        """
        # Try local staging first
        local_path = self._get_local_path(relative_path)
        if local_path.exists():
            try:
                return local_path.read_text(encoding=encoding)
            except UnicodeDecodeError:
                return local_path.read_bytes()

        # Fetch from GitHub
        repo_path = self._get_repo_path(relative_path)
        try:
            file_content = self.repo.get_contents(repo_path, ref=self.branch)
            if isinstance(file_content, list):
                raise ValueError(f"Path is a directory: {repo_path}")

            content_bytes = base64.b64decode(file_content.content)

            # Cache locally
            local_path.parent.mkdir(parents=True, exist_ok=True)
            local_path.write_bytes(content_bytes)

            # Try to decode as text
            try:
                return content_bytes.decode(encoding)
            except UnicodeDecodeError:
                return content_bytes

        except self.GithubException as e:
            if e.status == 404:
                raise FileNotFoundError(f"File not found in GitHub: {repo_path}")
            raise

    def exists(self, relative_path: str) -> bool:
        """Check if file exists in local staging or GitHub.

        Args:
            relative_path: Path relative to base_path

        Returns:
            True if file exists
        """
        # Check local staging
        if self._get_local_path(relative_path).exists():
            return True

        # Check if staged for commit
        repo_path = self._get_repo_path(relative_path)
        if repo_path in self.staged_files:
            return True

        # Check GitHub
        try:
            self.repo.get_contents(repo_path, ref=self.branch)
            return True
        except self.GithubException:
            return False

    def delete_file(self, relative_path: str) -> None:
        """Delete file from local staging (mark for deletion on commit).

        Args:
            relative_path: Path relative to base_path
        """
        # Delete from local staging
        local_path = self._get_local_path(relative_path)
        if local_path.exists():
            if local_path.is_dir():
                import shutil

                shutil.rmtree(local_path)
            else:
                local_path.unlink()

        # Mark for deletion (store None as content)
        repo_path = self._get_repo_path(relative_path)
        self.staged_files[repo_path] = None
        logger.debug(f"Marked for deletion in GitHub: {repo_path}")

    def get_public_url(self, relative_path: str) -> str | None:
        """Get GitHub raw URL for the file.

        Args:
            relative_path: Path relative to base_path

        Returns:
            GitHub raw URL
        """
        repo_path = self._get_repo_path(relative_path)
        owner, repo = self.repo_name.split("/")
        return f"https://raw.githubusercontent.com/{owner}/{repo}/{self.branch}/{repo_path}"

    def get_local_uri(self, relative_path: str) -> str:
        """Get file:// URI for local staged file (for tool compatibility).

        Args:
            relative_path: Path relative to base_path

        Returns:
            file:// URI
        """
        local_path = self._get_local_path(relative_path)
        return local_path.as_uri()

    def commit_and_push(self, commit_message: Optional[str] = None) -> str:
        """Commit all staged files to GitHub.

        Args:
            commit_message: Commit message (uses template if not provided)

        Returns:
            Commit SHA
        """
        if not self.staged_files or self.staged_files == {}:
            logger.info("No files staged for commit")
            return ""

        # Use default message if not provided
        if not commit_message:
            file_count = len(self.staged_files)
            commit_message = f"chore: update {file_count} OpenAPI artifact(s)"

        # Get the current commit SHA of the branch
        try:
            ref = self.repo.get_git_ref(f"heads/{self.branch}")
            base_sha = ref.object.sha
            logger.debug(f"Branch {self.branch} exists, base SHA: {base_sha}")
        except self.GithubException:
            # Branch doesn't exist, create it
            logger.info(f"Branch {self.branch} doesn't exist, creating from default branch")
            default_branch = self.repo.default_branch
            base_ref = self.repo.get_git_ref(f"heads/{default_branch}")
            base_sha = base_ref.object.sha
            ref = self.repo.create_git_ref(f"refs/heads/{self.branch}", base_sha)
            logger.info(f"Created branch {self.branch} from {default_branch} (SHA: {base_sha})")

        # Get base tree
        base_commit = self.repo.get_git_commit(base_sha)
        base_tree = base_commit.tree

        # Create blobs and tree elements for staged files
        tree_elements = []
        for repo_path, content_bytes in self.staged_files.items():
            if content_bytes is None:
                # Deletion: don't include in new tree
                continue

            # Create blob
            blob = self.repo.create_git_blob(
                base64.b64encode(content_bytes).decode("utf-8"), "base64"
            )

            # Create InputGitTreeElement object
            tree_element = self.InputGitTreeElement(
                path=repo_path,
                mode="100644",  # Regular file
                type="blob",
                sha=blob.sha,
            )
            tree_elements.append(tree_element)

        # Create new tree
        new_tree = self.repo.create_git_tree(tree_elements, base_tree)

        # Create commit
        new_commit = self.repo.create_git_commit(commit_message, new_tree, [base_commit])

        # Update branch reference
        ref.edit(new_commit.sha)

        logger.info(
            f"Committed {len(tree_elements)} file(s) to {self.repo_name}:{self.branch} - {new_commit.sha}"
        )
        self.staged_files.clear()

        return new_commit.sha

    def cleanup(self) -> None:
        """Commit staged files and clean up temporary directory."""
        # Commit any staged files before cleanup
        if self.staged_files:
            logger.info(f"Committing {len(self.staged_files)} staged file(s) to GitHub")
            try:
                self.commit_and_push()
            except Exception as e:
                logger.error(f"Failed to commit to GitHub: {e}")
                raise

        # Clean up temp directory
        import shutil

        if self.temp_dir.exists():
            shutil.rmtree(self.temp_dir)
            logger.debug(f"Cleaned up temp directory: {self.temp_dir}")
