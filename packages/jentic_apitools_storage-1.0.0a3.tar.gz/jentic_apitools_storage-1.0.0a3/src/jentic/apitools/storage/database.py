"""Database storage backend for storing OpenAPI artifacts in a database."""

from __future__ import annotations

import tempfile
from pathlib import Path

from jentic.apitools.common.utils.logging import get_module_logger
from jentic.apitools.storage.base import StorageBackend, StorageConfig


logger = get_module_logger(__name__)

__all__ = ["DatabaseStorage"]


class DatabaseStorage(StorageBackend):
    """Storage backend that writes to a database.

    Stores files as BLOBs or TEXT fields in a database table.
    During processing, files are cached locally for tool compatibility.

    Schema example:
        CREATE TABLE openapi_artifacts (
            id SERIAL PRIMARY KEY,
            path VARCHAR(512) UNIQUE NOT NULL,
            content BYTEA,
            content_type VARCHAR(100),
            created_at TIMESTAMP DEFAULT NOW(),
            updated_at TIMESTAMP DEFAULT NOW()
        );
    """

    def __init__(self, config: StorageConfig):
        """Initialize database storage.

        Args:
            config: Storage configuration with:
                - connection_string: Database connection string
                - table_name: Table name for storing artifacts (default: "openapi_artifacts")
                - prefix: Optional prefix for paths
        """
        super().__init__(config)

        # Import database library here to make it optional
        try:
            import sqlalchemy
            from sqlalchemy import (
                Column,
                DateTime,
                LargeBinary,
                MetaData,
                String,
                Table,
                create_engine,
                text,
            )
            from sqlalchemy.dialects.postgresql import insert as pg_insert

            self.sqlalchemy = sqlalchemy
            self.create_engine = create_engine
            self.Table = Table
            self.Column = Column
            self.String = String
            self.LargeBinary = LargeBinary
            self.MetaData = MetaData
            self.DateTime = DateTime
            self.text = text
            self.pg_insert = pg_insert
        except ImportError:
            raise ImportError(
                "sqlalchemy is required for database storage. Install with: pip install sqlalchemy psycopg2-binary"
            )

        self.connection_string = config.config.get("connection_string")
        if not self.connection_string:
            raise ValueError("Database storage requires 'connection_string' in config")

        self.table_name = config.config.get("table_name", "openapi_artifacts")
        self.prefix = config.config.get("prefix", "")

        # Initialize database connection
        self.engine = self.create_engine(self.connection_string)

        # Define table schema
        self.metadata = self.MetaData()
        self.artifacts_table = self.Table(
            self.table_name,
            self.metadata,
            self.Column("id", self.sqlalchemy.Integer, primary_key=True, autoincrement=True),
            self.Column("path", self.String(512), unique=True, nullable=False),
            self.Column("content", self.LargeBinary, nullable=False),
            self.Column("content_type", self.String(100)),
            self.Column("created_at", self.DateTime, server_default=self.text("NOW()")),
            self.Column(
                "updated_at",
                self.DateTime,
                server_default=self.text("NOW()"),
                onupdate=self.text("NOW()"),
            ),
        )

        # Create table if it doesn't exist
        self.metadata.create_all(self.engine)

        # Local cache for files (synced to DB on write)
        self.temp_dir = Path(tempfile.mkdtemp(prefix="db_storage_"))
        logger.debug(f"Initialized DatabaseStorage: table={self.table_name}, temp={self.temp_dir}")

    def _get_db_path(self, relative_path: str) -> str:
        """Get full database path from relative path."""
        if self.prefix:
            return f"{self.prefix.rstrip('/')}/{relative_path}"
        return relative_path

    def _get_local_path(self, relative_path: str) -> Path:
        """Get local temp path for caching."""
        return self.temp_dir / relative_path

    def _infer_content_type(self, relative_path: str) -> str:
        """Infer content type from file extension."""
        suffix = Path(relative_path).suffix.lower()
        content_types = {
            ".json": "application/json",
            ".yaml": "application/yaml",
            ".yml": "application/yaml",
            ".txt": "text/plain",
            ".md": "text/markdown",
        }
        return content_types.get(suffix, "application/octet-stream")

    def write_file(self, relative_path: str, content: str | bytes, encoding: str = "utf-8") -> None:
        """Write content to local cache and database.

        Args:
            relative_path: Path relative to base_path
            content: File content
            encoding: Text encoding if content is string
        """
        # Write to local cache first
        local_path = self._get_local_path(relative_path)
        local_path.parent.mkdir(parents=True, exist_ok=True)

        if isinstance(content, str):
            local_path.write_text(content, encoding=encoding)
            content_bytes = content.encode(encoding)
        else:
            local_path.write_bytes(content)
            content_bytes = content

        # Write to database
        db_path = self._get_db_path(relative_path)
        content_type = self._infer_content_type(relative_path)

        with self.engine.connect() as conn:
            # Use upsert (INSERT ... ON CONFLICT UPDATE for PostgreSQL)
            try:
                stmt = self.pg_insert(self.artifacts_table).values(
                    path=db_path, content=content_bytes, content_type=content_type
                )
                stmt = stmt.on_conflict_do_update(
                    index_elements=["path"],
                    set_={"content": content_bytes, "content_type": content_type},
                )
                conn.execute(stmt)
                conn.commit()
                logger.debug(f"Wrote to database: {db_path}")
            except Exception:
                # Fallback for non-PostgreSQL databases
                logger.debug(f"Using fallback upsert for {db_path}")
                # Try delete + insert
                delete_stmt = self.artifacts_table.delete().where(
                    self.artifacts_table.c.path == db_path
                )
                conn.execute(delete_stmt)
                insert_stmt = self.artifacts_table.insert().values(
                    path=db_path, content=content_bytes, content_type=content_type
                )
                conn.execute(insert_stmt)
                conn.commit()

    def read_file(self, relative_path: str, encoding: str = "utf-8") -> str | bytes:
        """Read content from local cache, or query database if needed.

        Args:
            relative_path: Path relative to base_path
            encoding: Text encoding for text files

        Returns:
            File content
        """
        # Try local cache first
        local_path = self._get_local_path(relative_path)
        if local_path.exists():
            try:
                return local_path.read_text(encoding=encoding)
            except UnicodeDecodeError:
                return local_path.read_bytes()

        # Query database
        db_path = self._get_db_path(relative_path)
        with self.engine.connect() as conn:
            stmt = self.artifacts_table.select().where(self.artifacts_table.c.path == db_path)
            result = conn.execute(stmt).fetchone()

            if result is None:
                raise FileNotFoundError(f"File not found in database: {db_path}")

            content_bytes = (
                bytes(result.content) if hasattr(result.content, "__iter__") else result.content
            )

            # Cache locally
            local_path.parent.mkdir(parents=True, exist_ok=True)
            local_path.write_bytes(content_bytes)

            # Try to decode as text
            try:
                return content_bytes.decode(encoding)
            except UnicodeDecodeError:
                return content_bytes

    def exists(self, relative_path: str) -> bool:
        """Check if file exists in local cache or database.

        Args:
            relative_path: Path relative to base_path

        Returns:
            True if file exists
        """
        # Check local cache
        if self._get_local_path(relative_path).exists():
            return True

        # Check database using parameterized query via SQLAlchemy table object
        db_path = self._get_db_path(relative_path)
        with self.engine.connect() as conn:
            stmt = self.sqlalchemy.select(self.sqlalchemy.literal(1)).where(
                self.artifacts_table.c.path == db_path
            )
            result = conn.execute(stmt).fetchone()
            return result is not None

    def delete_file(self, relative_path: str) -> None:
        """Delete file from local cache and database.

        Args:
            relative_path: Path relative to base_path
        """
        # Delete from local cache
        local_path = self._get_local_path(relative_path)
        if local_path.exists():
            if local_path.is_dir():
                import shutil

                shutil.rmtree(local_path)
            else:
                local_path.unlink()

        # Delete from database
        db_path = self._get_db_path(relative_path)
        with self.engine.connect() as conn:
            stmt = self.artifacts_table.delete().where(self.artifacts_table.c.path == db_path)
            conn.execute(stmt)
            conn.commit()
            logger.debug(f"Deleted from database: {db_path}")

    def get_public_url(self, relative_path: str) -> str | None:
        """Database storage doesn't have public URLs.

        Returns:
            None (database storage doesn't provide public URLs)
        """
        return None

    def get_local_uri(self, relative_path: str) -> str:
        """Get file:// URI for local cached file (for tool compatibility).

        Args:
            relative_path: Path relative to base_path

        Returns:
            file:// URI
        """
        local_path = self._get_local_path(relative_path)
        # Ensure file is cached locally
        if not local_path.exists():
            _ = self.read_file(relative_path)
        return local_path.as_uri()

    def cleanup(self) -> None:
        """Clean up temporary directory and close database connection."""
        import shutil

        if self.temp_dir.exists():
            shutil.rmtree(self.temp_dir)
            logger.debug(f"Cleaned up temp directory: {self.temp_dir}")

        if hasattr(self, "engine"):
            self.engine.dispose()
            logger.debug("Closed database connection")
