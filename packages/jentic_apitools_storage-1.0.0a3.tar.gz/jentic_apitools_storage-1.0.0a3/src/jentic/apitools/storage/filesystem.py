"""Filesystem storage backend."""

from __future__ import annotations

import shutil
from pathlib import Path

from jentic.apitools.common.utils.logging import get_module_logger
from jentic.apitools.storage.base import StorageBackend, StorageConfig


logger = get_module_logger(__name__)

__all__ = ["FilesystemStorage"]


class FilesystemStorage(StorageBackend):
    """Storage backend that writes to local filesystem."""

    def __init__(self, config: StorageConfig):
        """Initialize filesystem storage.

        Args:
            config: Storage configuration with base_path as root directory
        """
        super().__init__(config)
        self.base_path = Path(config.base_path or ".").resolve()
        self.base_path.mkdir(parents=True, exist_ok=True)
        logger.debug(f"Initialized FilesystemStorage at {self.base_path}")

    def _safe_path(self, relative_path: str) -> Path:
        """Resolve *relative_path* and ensure it stays within *base_path*."""
        full = (self.base_path / relative_path).resolve()
        if not full.is_relative_to(self.base_path):
            raise ValueError(f"Path escapes storage boundary: {relative_path}")
        return full

    def write_file(self, relative_path: str, content: str | bytes, encoding: str = "utf-8") -> None:
        """Write content to filesystem.

        Args:
            relative_path: Path relative to base_path
            content: File content
            encoding: Text encoding if content is string
        """
        full_path = self._safe_path(relative_path)
        full_path.parent.mkdir(parents=True, exist_ok=True)

        if isinstance(content, str):
            full_path.write_text(content, encoding=encoding)
        else:
            full_path.write_bytes(content)

        logger.debug(f"Wrote file to {full_path}")

    def read_file(self, relative_path: str, encoding: str = "utf-8") -> str | bytes:
        """Read content from filesystem.

        Args:
            relative_path: Path relative to base_path
            encoding: Text encoding for text files

        Returns:
            File content
        """
        full_path = self._safe_path(relative_path)
        try:
            return full_path.read_text(encoding=encoding)
        except UnicodeDecodeError:
            return full_path.read_bytes()

    def exists(self, relative_path: str) -> bool:
        """Check if file exists.

        Args:
            relative_path: Path relative to base_path

        Returns:
            True if file exists
        """
        return self._safe_path(relative_path).exists()

    def delete_file(self, relative_path: str) -> None:
        """Delete file from filesystem.

        Args:
            relative_path: Path relative to base_path
        """
        full_path = self._safe_path(relative_path)
        if full_path.exists():
            if full_path.is_dir():
                shutil.rmtree(full_path)
            else:
                full_path.unlink()
            logger.debug(f"Deleted {full_path}")

    def get_public_url(self, relative_path: str) -> str | None:
        """Get file:// URL for the file.

        Args:
            relative_path: Path relative to base_path

        Returns:
            file:// URL
        """
        full_path = self._safe_path(relative_path)
        return full_path.as_uri()

    def cleanup(self) -> None:
        """Cleanup (no-op for filesystem)."""
        pass

    def get_absolute_path(self, relative_path: str) -> Path:
        """Get absolute filesystem path.

        Args:
            relative_path: Path relative to base_path

        Returns:
            Absolute Path object
        """
        return self._safe_path(relative_path)
