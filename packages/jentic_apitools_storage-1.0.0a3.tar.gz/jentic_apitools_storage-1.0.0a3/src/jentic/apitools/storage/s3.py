"""S3 storage backend."""

from __future__ import annotations

import tempfile
from pathlib import Path

from jentic.apitools.common.utils.logging import get_module_logger
from jentic.apitools.storage.base import StorageBackend, StorageConfig


logger = get_module_logger(__name__)

__all__ = ["S3Storage"]


class S3Storage(StorageBackend):
    """Storage backend that writes to AWS S3 (or S3-compatible storage).

    During processing, files are written to a local temp directory for tool compatibility.
    On finalization, they are uploaded to S3.
    """

    def __init__(self, config: StorageConfig):
        """Initialize S3 storage.

        Args:
            config: Storage configuration with:
                - bucket: S3 bucket name
                - region: AWS region (optional)
                - prefix: S3 key prefix (optional)
                - endpoint_url: Custom endpoint for S3-compatible storage (optional)
                - access_key_id: AWS access key (optional, uses boto3 default chain)
                - secret_access_key: AWS secret key (optional)
        """
        super().__init__(config)

        # Import boto3 here to make it optional
        try:
            import boto3
            from botocore.exceptions import ClientError

            self.boto3 = boto3
            self.ClientError = ClientError
        except ImportError:
            raise ImportError("boto3 is required for S3 storage. Install with: pip install boto3")

        self.bucket = config.config.get("bucket")
        if not self.bucket:
            raise ValueError("S3 storage requires 'bucket' in config")

        self.prefix = config.config.get("prefix", "")
        self.region = config.config.get("region")
        self.endpoint_url = config.config.get("endpoint_url")
        self.public_url_base = config.config.get("public_url_base")

        # Initialize S3 client
        session_kwargs = {}
        if config.config.get("access_key_id"):
            session_kwargs["aws_access_key_id"] = config.config["access_key_id"]
        if config.config.get("secret_access_key"):
            session_kwargs["aws_secret_access_key"] = config.config["secret_access_key"]
        if self.region:
            session_kwargs["region_name"] = self.region

        client_kwargs = {}
        if self.endpoint_url:
            client_kwargs["endpoint_url"] = self.endpoint_url

        self.s3_client = self.boto3.client("s3", **session_kwargs, **client_kwargs)

        # Local cache for files (synced to S3 on write)
        self.temp_dir = Path(tempfile.mkdtemp(prefix="s3_storage_"))
        logger.debug(
            f"Initialized S3Storage: bucket={self.bucket}, prefix={self.prefix}, temp={self.temp_dir}"
        )

    def _get_s3_key(self, relative_path: str) -> str:
        """Get full S3 key from relative path."""
        if self.prefix:
            return f"{self.prefix.rstrip('/')}/{relative_path}"
        return relative_path

    def _get_local_path(self, relative_path: str) -> Path:
        """Get local temp path for caching."""
        return self.temp_dir / relative_path

    def write_file(self, relative_path: str, content: str | bytes, encoding: str = "utf-8") -> None:
        """Write content to local cache and upload to S3.

        Args:
            relative_path: Path relative to base_path
            content: File content
            encoding: Text encoding if content is string
        """
        # Write to local cache first
        local_path = self._get_local_path(relative_path)
        local_path.parent.mkdir(parents=True, exist_ok=True)

        if isinstance(content, str):
            local_path.write_text(content, encoding=encoding)
            content_bytes = content.encode(encoding)
        else:
            local_path.write_bytes(content)
            content_bytes = content

        # Upload to S3
        s3_key = self._get_s3_key(relative_path)
        try:
            self.s3_client.put_object(Bucket=self.bucket, Key=s3_key, Body=content_bytes)
            logger.debug(f"Uploaded to s3://{self.bucket}/{s3_key}")
        except self.ClientError as e:
            logger.error(f"Failed to upload to S3: {e}")
            raise

    def read_file(self, relative_path: str, encoding: str = "utf-8") -> str | bytes:
        """Read content from local cache, or download from S3 if needed.

        Args:
            relative_path: Path relative to base_path
            encoding: Text encoding for text files

        Returns:
            File content
        """
        # Try local cache first
        local_path = self._get_local_path(relative_path)
        if local_path.exists():
            try:
                return local_path.read_text(encoding=encoding)
            except UnicodeDecodeError:
                return local_path.read_bytes()

        # Download from S3
        s3_key = self._get_s3_key(relative_path)
        try:
            response = self.s3_client.get_object(Bucket=self.bucket, Key=s3_key)
            content_bytes = response["Body"].read()

            # Cache locally
            local_path.parent.mkdir(parents=True, exist_ok=True)
            local_path.write_bytes(content_bytes)

            # Try to decode as text
            try:
                return content_bytes.decode(encoding)
            except UnicodeDecodeError:
                return content_bytes

        except self.ClientError as e:
            logger.error(f"Failed to read from S3: {e}")
            raise

    def exists(self, relative_path: str) -> bool:
        """Check if file exists in local cache or S3.

        Args:
            relative_path: Path relative to base_path

        Returns:
            True if file exists
        """
        # Check local cache
        if self._get_local_path(relative_path).exists():
            return True

        # Check S3
        s3_key = self._get_s3_key(relative_path)
        try:
            self.s3_client.head_object(Bucket=self.bucket, Key=s3_key)
            return True
        except self.ClientError:
            return False

    def delete_file(self, relative_path: str) -> None:
        """Delete file from local cache and S3.

        Args:
            relative_path: Path relative to base_path
        """
        # Delete from local cache
        local_path = self._get_local_path(relative_path)
        if local_path.exists():
            if local_path.is_dir():
                import shutil

                shutil.rmtree(local_path)
            else:
                local_path.unlink()

        # Delete from S3
        s3_key = self._get_s3_key(relative_path)
        try:
            self.s3_client.delete_object(Bucket=self.bucket, Key=s3_key)
            logger.debug(f"Deleted s3://{self.bucket}/{s3_key}")
        except self.ClientError as e:
            logger.warning(f"Failed to delete from S3: {e}")

    def get_public_url(self, relative_path: str) -> str | None:
        """Get public URL for S3 object.

        Args:
            relative_path: Path relative to base_path

        Returns:
            Public URL if public_url_base is configured, else presigned URL
        """
        s3_key = self._get_s3_key(relative_path)

        if self.public_url_base:
            # Use configured public URL base
            return f"{self.public_url_base.rstrip('/')}/{s3_key}"

        # Generate presigned URL (expires in 1 hour)
        try:
            url = self.s3_client.generate_presigned_url(
                "get_object", Params={"Bucket": self.bucket, "Key": s3_key}, ExpiresIn=3600
            )
            return url
        except self.ClientError as e:
            logger.error(f"Failed to generate presigned URL: {e}")
            return None

    def get_local_uri(self, relative_path: str) -> str:
        """Get file:// URI for local cached file (for tool compatibility).

        Args:
            relative_path: Path relative to base_path

        Returns:
            file:// URI
        """
        local_path = self._get_local_path(relative_path)
        return local_path.as_uri()

    def cleanup(self) -> None:
        """Clean up temporary directory."""
        import shutil

        if self.temp_dir.exists():
            shutil.rmtree(self.temp_dir)
            logger.debug(f"Cleaned up temp directory: {self.temp_dir}")
