"""Helper utilities for storage integration."""

from __future__ import annotations

import atexit
import tempfile
from pathlib import Path
from typing import Callable, Optional, Tuple

from jentic.apitools.common.models import OASRequestMeta
from jentic.apitools.common.utils.logging import get_module_logger
from jentic.apitools.storage.base import StorageConfig, StorageType
from jentic.apitools.storage.context import StorageContext


logger = get_module_logger(__name__)

__all__ = [
    "create_storage_context_from_oas_request_meta",
    "get_storage_config_from_env",
]


def create_storage_context_from_oas_request_meta(
    oas_request_meta: OASRequestMeta, persist_on_exit: bool = True
) -> StorageContext:
    """Create StorageContext from OASRequestMeta.

    This is the main helper for integrating StorageContext into process_openapi.

    Args:
        oas_request_meta: Import data with optional storage_config
        persist_on_exit: Whether to persist to storage backend on successful exit

    Returns:
        StorageContext ready for use

    Example:
        with create_storage_context_from_oas_request_meta(oas_request_meta) as ctx:
            output_dir = ctx.working_dir
            # ... existing code unchanged ...
    """
    if oas_request_meta.storage_config:
        # Use explicit storage configuration
        storage_config = StorageConfig(
            storage_type=StorageType(oas_request_meta.storage_config.storage_type),
            base_path=oas_request_meta.storage_config.base_path,
            **oas_request_meta.storage_config.config,
        )
        logger.info(f"Using {storage_config.storage_type} storage backend")
    else:
        # Backward compatible: use output_dir with filesystem storage
        exec_dir = Path.cwd().resolve()
        request_output_dir = oas_request_meta.output_dir
        assert request_output_dir is not None, (
            "output_dir must be provided when using filesystem storage"
        )

        output_dir, cleanup = _prepare_output_dir(Path(request_output_dir), exec_dir=exec_dir)

        storage_config = StorageConfig(
            storage_type=StorageType.FILESYSTEM, base_path=str(output_dir)
        )
        logger.debug(f"Using filesystem storage at {output_dir}")

    return StorageContext(storage_config, persist_on_exit=persist_on_exit)


def get_storage_config_from_env() -> Optional[StorageConfig]:
    """Create StorageConfig from environment variables.

    Useful for deployment scenarios where storage is configured via environment.

    Environment variables:
        STORAGE_TYPE: "filesystem", "s3", "database", or "github"
        STORAGE_BASE_PATH: Base path/prefix

        For S3:
            S3_BUCKET: Bucket name
            S3_REGION: AWS region
            S3_PREFIX: Key prefix
            S3_ENDPOINT_URL: Custom endpoint (optional)
            AWS_ACCESS_KEY_ID: Access key (optional, uses boto3 default chain)
            AWS_SECRET_ACCESS_KEY: Secret key (optional)

        For Database:
            DB_CONNECTION_STRING: Database connection string
            DB_TABLE_NAME: Table name (default: openapi_artifacts)
            DB_PREFIX: Path prefix

        For GitHub:
            GITHUB_REPO: Repository (owner/repo)
            GITHUB_BRANCH: Branch name
            GITHUB_TOKEN: Access token
            GITHUB_PREFIX: Path prefix within repo

    Returns:
        StorageConfig if environment variables are set, None otherwise

    Example:
        # Set environment:
        export STORAGE_TYPE=s3
        export S3_BUCKET=my-bucket
        export S3_REGION=us-east-1

        # In code:
        storage_config = get_storage_config_from_env()
        if storage_config:
            with StorageContext(storage_config) as ctx:
                ...
    """
    import os

    storage_type_str = os.getenv("STORAGE_TYPE", "").lower()
    if not storage_type_str:
        return None

    try:
        storage_type = StorageType(storage_type_str)
    except ValueError:
        logger.warning(f"Invalid STORAGE_TYPE: {storage_type_str}")
        return None

    base_path = os.getenv("STORAGE_BASE_PATH")
    config = {}

    if storage_type == StorageType.S3:
        config["bucket"] = os.getenv("S3_BUCKET")
        if not config["bucket"]:
            logger.error("S3_BUCKET environment variable is required for S3 storage")
            return None

        if region := os.getenv("S3_REGION"):
            config["region"] = region
        if prefix := os.getenv("S3_PREFIX"):
            config["prefix"] = prefix
        if endpoint_url := os.getenv("S3_ENDPOINT_URL"):
            config["endpoint_url"] = endpoint_url
        if access_key := os.getenv("AWS_ACCESS_KEY_ID"):
            config["access_key_id"] = access_key
        if secret_key := os.getenv("AWS_SECRET_ACCESS_KEY"):
            config["secret_access_key"] = secret_key
        if public_url_base := os.getenv("S3_PUBLIC_URL_BASE"):
            config["public_url_base"] = public_url_base

    elif storage_type == StorageType.DATABASE:
        config["connection_string"] = os.getenv("DB_CONNECTION_STRING")
        if not config["connection_string"]:
            logger.error(
                "DB_CONNECTION_STRING environment variable is required for database storage"
            )
            return None

        if table_name := os.getenv("DB_TABLE_NAME"):
            config["table_name"] = table_name
        if prefix := os.getenv("DB_PREFIX"):
            config["prefix"] = prefix

    elif storage_type == StorageType.GITHUB:
        config["repo"] = os.getenv("GITHUB_REPO")
        if not config["repo"]:
            logger.error("GITHUB_REPO environment variable is required for GitHub storage")
            return None

        if branch := os.getenv("GITHUB_BRANCH"):
            config["branch"] = branch
        if token := os.getenv("GITHUB_TOKEN"):
            config["token"] = token
        if prefix := os.getenv("GITHUB_PREFIX"):
            config["prefix"] = prefix

    elif storage_type == StorageType.FILESYSTEM:
        if not base_path:
            logger.error("STORAGE_BASE_PATH is required for filesystem storage")
            return None

    logger.info(f"Loaded storage configuration from environment: {storage_type}")
    return StorageConfig(storage_type=storage_type, base_path=base_path, **config)


def create_storage_context_with_fallback(
    oas_request_meta: OASRequestMeta, persist_on_exit: bool = True
) -> StorageContext:
    """Create StorageContext with environment variable fallback.

    Priority:
    1. oas_request_meta.storage_config (explicit configuration)
    2. Environment variables (STORAGE_TYPE, etc.)
    3. oas_request_meta.output_dir (backward compatible)

    Args:
        oas_request_meta: Import data
        persist_on_exit: Whether to persist on exit

    Returns:
        StorageContext
    """
    if oas_request_meta.storage_config:
        # Explicit config takes precedence
        logger.info(
            f"Using EXPLICIT storage_config from oas_request_meta: {oas_request_meta.storage_config.storage_type}"
        )
        logger.debug(f"Base path: {oas_request_meta.storage_config.base_path}")
        return create_storage_context_from_oas_request_meta(oas_request_meta, persist_on_exit)

    # Try environment variables
    env_storage_config = get_storage_config_from_env()
    if env_storage_config:
        logger.info(f"Using ENVIRONMENT storage configuration: {env_storage_config.storage_type}")
        logger.info(f"Base path from environment: {env_storage_config.base_path}")
        logger.warning(
            f"NOTE: oas_request_meta.output_dir ({oas_request_meta.output_dir}) is IGNORED because environment variables take precedence"
        )
        return StorageContext(env_storage_config, persist_on_exit=persist_on_exit)

    # Fall back to output_dir (backward compatible)
    logger.info(
        f"Using FALLBACK storage configuration from oas_request_meta.output_dir: {oas_request_meta.output_dir}"
    )
    return create_storage_context_from_oas_request_meta(oas_request_meta, persist_on_exit)


def is_within(child: Path, parent: Path) -> bool:
    """
    True if `child` is inside `parent` after resolving symlinks.
    """
    try:
        child_resolved = child.resolve(strict=False)
        parent_resolved = parent.resolve(strict=False)

        # A path is not considered "within" itself; identical paths should return False.
        # This prevents a directory from being considered as its own child for safety checks.
        if child_resolved == parent_resolved:
            return False
        child_resolved.relative_to(parent_resolved)
        return True
    except Exception:
        return False


def _prepare_output_dir(
    output_dir: Path | None,
    *,
    exec_dir: str | Path,
    default_subdir_name: str = "__data__/outputs",  # used when we must fall back to exec_dir
    temp_prefix: str = "jentic-",
) -> Tuple[Path, Callable[[], None]]:
    """
    Decide and prepare where to write outputs.

    Rules:
      - If `output_dir` is provided and resolves inside `exec_dir` OR inside the system temp dir → use it.
      - If `output_dir` is None → create a new private temp directory + auto-delete at process exit.
      - Otherwise → fall back to `<exec_dir>/<default_subdir_name>`, creating it if needed.

    Returns:
      (chosen_path, cleanup_callable)

    Notes:
      - The cleanup callable is a no-op unless we created a private temp dir.
      - We do *not* auto-delete user-specified paths (even if they’re in temp).
    """
    exec_dir_path = Path(exec_dir).resolve(strict=False)
    sys_tmp_path = Path(tempfile.gettempdir()).resolve(strict=False)

    # 1) No output_dir provided → create private temp dir (auto-clean)
    if output_dir is None:
        tmp = tempfile.TemporaryDirectory(prefix=temp_prefix, dir=sys_tmp_path)  # keep reference!
        tmp_path = Path(tmp.name).resolve(strict=False)

        # Ensure deletion at exit (holding the object is already enough, but belt & suspenders)
        def _cleanup() -> None:
            try:
                tmp.cleanup()
            except Exception as e:
                logger.warning("Failed to cleanup temp dir %s: %s", tmp_path, e)

        # Also register with atexit (in case caller forgets to run cleanup)
        atexit.register(_cleanup)

        logger.debug("Using private temp output dir: %s", tmp_path)
        return tmp_path, _cleanup

    # 2) User provided an output_dir → normalize and check
    requested = Path(output_dir).expanduser().resolve(strict=False)
    allowed = is_within(requested, exec_dir_path) or is_within(requested, sys_tmp_path)

    if allowed:
        requested.mkdir(parents=True, exist_ok=True)
        logger.debug("Using user-provided output dir: %s", requested)
        # For user-provided dirs, no auto-cleanup by default
        return requested, (lambda: None)

    # 3) Not allowed → fall back to exec_dir/<default_subdir_name>
    fallback = (exec_dir_path / default_subdir_name).resolve(strict=False)
    fallback.mkdir(parents=True, exist_ok=True)
    logger.warning(
        "Output dir %s is outside of allowed roots (%s, %s); falling back to %s",
        requested,
        exec_dir_path,
        sys_tmp_path,
        fallback,
    )
    return fallback, (lambda: None)
