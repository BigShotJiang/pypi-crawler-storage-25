"""Storage context for managing OpenAPI import pipeline storage.

This module provides a context manager that:
1. Creates a temporary working directory for processing (file:// URIs for tool compatibility)
2. Provides a Path-like interface that works with existing code
3. Persists artifacts to the configured storage backend on success
4. Cleans up temporary files
"""

from __future__ import annotations

import shutil
import tempfile
from contextlib import contextmanager
from pathlib import Path
from typing import Optional, Union

from jentic.apitools.common.utils.logging import get_module_logger
from jentic.apitools.storage.base import StorageBackend, StorageConfig, StorageType


logger = get_module_logger(__name__)

__all__ = [
    "StorageContext",
    "create_storage_backend",
]


def create_storage_backend(config: StorageConfig) -> StorageBackend:
    """Factory function to create storage backend from config.

    Args:
        config: Storage configuration

    Returns:
        Appropriate StorageBackend instance
    """
    if config.storage_type == StorageType.FILESYSTEM:
        from jentic.apitools.storage.filesystem import FilesystemStorage

        return FilesystemStorage(config)
    elif config.storage_type == StorageType.S3:
        from jentic.apitools.storage.s3 import S3Storage

        return S3Storage(config)
    elif config.storage_type == StorageType.DATABASE:
        from jentic.apitools.storage.database import DatabaseStorage

        return DatabaseStorage(config)
    elif config.storage_type == StorageType.GITHUB:
        from jentic.apitools.storage.github import GitHubStorage

        return GitHubStorage(config)
    else:
        raise ValueError(f"Unknown storage type: {config.storage_type}")


class StorageContext:
    """Context manager for OpenAPI import pipeline storage.

    Provides a temporary working directory during processing that maintains
    compatibility with tools expecting file:// URIs. On success, artifacts
    are persisted to the configured storage backend.

    Example usage:
        with StorageContext(storage_config) as ctx:
            # Use ctx.get_path() to get Path objects
            spec_path = ctx.get_path("vendor/api/version/openapi.json")
            spec_path.write_text(spec_content)

            # Tools can use file:// URIs
            validator.validate(str(spec_path.as_uri()))

            # On successful exit, files are persisted to storage backend
    """

    def __init__(
        self,
        storage_config: Optional[StorageConfig] = None,
        working_dir: Optional[Union[str, Path]] = None,
        persist_on_exit: bool = True,
    ):
        """Initialize storage context.

        Args:
            storage_config: Storage backend configuration (defaults to filesystem)
            working_dir: Optional working directory (creates temp dir if not provided)
            persist_on_exit: Whether to persist to storage backend on successful exit
        """
        self.storage_config = storage_config or StorageConfig(StorageType.FILESYSTEM)
        self.persist_on_exit = persist_on_exit

        # Create storage backend
        self.storage = create_storage_backend(self.storage_config)

        # Working directory for processing
        if working_dir:
            self.working_dir = Path(working_dir)
            self.working_dir.mkdir(parents=True, exist_ok=True)
            self._owns_working_dir = False
        else:
            self.working_dir = Path(tempfile.mkdtemp(prefix="jentic.apitools_import_"))
            self._owns_working_dir = True

        logger.debug(
            f"Initialized StorageContext: working_dir={self.working_dir}, storage={type(self.storage).__name__}"
        )

    def get_path(self, relative_path: str) -> Path:
        """Get Path object for a file in the working directory.

        This provides compatibility with existing code that uses Path objects.

        Args:
            relative_path: Path relative to working directory

        Returns:
            Path object in working directory
        """
        return self.working_dir / relative_path

    def get_uri(self, relative_path: str) -> str:
        """Get file:// URI for a file in the working directory.

        Args:
            relative_path: Path relative to working directory

        Returns:
            file:// URI
        """
        return (self.working_dir / relative_path).as_uri()

    def write_file(self, relative_path: str, content: str | bytes, encoding: str = "utf-8") -> Path:
        """Write content to working directory.

        Args:
            relative_path: Path relative to working directory
            content: File content
            encoding: Text encoding if content is string

        Returns:
            Path to written file
        """
        path = self.get_path(relative_path)
        path.parent.mkdir(parents=True, exist_ok=True)

        if isinstance(content, str):
            path.write_text(content, encoding=encoding)
        else:
            path.write_bytes(content)

        return path

    def read_file(self, relative_path: str, encoding: str = "utf-8") -> str | bytes:
        """Read content from working directory.

        Args:
            relative_path: Path relative to working directory
            encoding: Text encoding for text files

        Returns:
            File content
        """
        path = self.get_path(relative_path)
        try:
            return path.read_text(encoding=encoding)
        except UnicodeDecodeError:
            return path.read_bytes()

    def persist(self, cleanup_working_dir: bool = False) -> None:
        """Persist all files from working directory to storage backend.

        Args:
            cleanup_working_dir: Whether to delete working directory after persisting
        """
        import os

        logger.info(f"Persisting artifacts to {type(self.storage).__name__}")
        logger.debug(f"Working directory: {self.working_dir}")
        logger.debug(f"Storage base_path: {getattr(self.storage, 'base_path', 'N/A')}")

        # Walk working directory and persist all files (using os.walk for Python < 3.12 compatibility)
        file_count = 0
        for root, dirs, files in os.walk(self.working_dir):
            for file in files:
                file_path = Path(root) / file
                relative_path = file_path.relative_to(self.working_dir)

                # Read content
                try:
                    content = file_path.read_bytes()

                    # Write to storage
                    logger.debug(f"Persisting {relative_path} to storage")
                    self.storage.write_file(str(relative_path), content)
                    file_count += 1
                except Exception as e:
                    logger.error(f"Failed to persist {relative_path}: {e}")
                    raise

        logger.info(f"Persisted {file_count} file(s) to storage")

        # Cleanup if requested
        if cleanup_working_dir and self._owns_working_dir:
            self.cleanup_working_dir()

    def cleanup_working_dir(self) -> None:
        """Clean up working directory."""
        if self._owns_working_dir and self.working_dir.exists():
            shutil.rmtree(self.working_dir)
            logger.debug(f"Cleaned up working directory: {self.working_dir}")

    def cleanup_storage(self) -> None:
        """Clean up storage backend resources."""
        self.storage.cleanup()

    def __enter__(self) -> StorageContext:
        """Enter context manager."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Exit context manager.

        On successful exit (no exception), persist to storage backend.
        Always cleanup resources.  If persist fails, its exception is
        preserved even when cleanup_storage also raises.
        """
        persist_error: Exception | None = None
        try:
            if exc_type is None and self.persist_on_exit:
                # Success - persist artifacts
                self.persist(cleanup_working_dir=True)
            else:
                # Failure or persist_on_exit=False - just cleanup
                if self._owns_working_dir:
                    self.cleanup_working_dir()
        except Exception as exc:
            persist_error = exc
        finally:
            # Always cleanup storage resources
            try:
                self.cleanup_storage()
            except Exception as cleanup_exc:
                logger.warning("Storage cleanup failed: %s", cleanup_exc)
                if persist_error is None:
                    persist_error = cleanup_exc
        if persist_error is not None:
            raise persist_error


@contextmanager
def storage_context(
    storage_config: Optional[StorageConfig] = None,
    working_dir: Optional[Union[str, Path]] = None,
    persist_on_exit: bool = True,
):
    """Context manager factory for StorageContext.

    Args:
        storage_config: Storage backend configuration
        working_dir: Optional working directory
        persist_on_exit: Whether to persist on successful exit

    Yields:
        StorageContext instance
    """
    ctx = StorageContext(storage_config, working_dir, persist_on_exit)
    try:
        yield ctx
    finally:
        pass  # Cleanup handled by StorageContext.__exit__
