def docs() -> str:
    return """
Calcula e lista o total de horas trabalhadas de um ou múltiplos analistas em um período específico.

Esta função consolida as horas trabalhadas de analista(s) considerando tanto os
atendimentos de Ordens de Serviço (OS) quanto os atendimentos avulsos realizados
no período especificado. Fornece um resumo completo da produtividade do(s) analista(s).
Suporta busca individual ou em lote para otimização de performance.

Args:
    matricula: 
        Matrícula do analista ou lista de matrículas dos analistas cujas horas
        trabalhadas serão calculadas. Se "CURRENT_USER", calcula para o usuário atual
        (matrícula do .env). Para múltiplos analistas, forneça uma lista de matrículas.
        Defaults to "CURRENT_USER".
    
    data_inicio: 
        Data de início do período para cálculo das horas.
        Aceita formatos de data ou palavras-chave "hoje" ou "ontem".
        Este parâmetro é obrigatório.
    
    data_fim: 
        Data de fim do período para cálculo das horas.
        Aceita formatos de data ou palavras-chave "hoje" ou "ontem".
        Este parâmetro é obrigatório.

Notes:
    - **RETORNO DE DADOS**: A API retorna os totais de horas por DIA por analista
      (campos: QTD_HORAS, USUARIO, NOME_ANALISTA, DATA_LANCAMENTO). Esses dados
      devem ser agregados ou apresentados conforme o modo de apresentação definido
      na seção INSTRUÇÃO PARA APRESENTAÇÃO DOS RESULTADOS.
    - **OTIMIZAÇÃO**: Função otimizada para múltiplas matrículas - uma consulta em vez de N consultas
    - **COMPATIBILIDADE**: Mantém total compatibilidade com uso individual (uma matrícula)
    - **PERFORMANCE**: Para múltiplos analistas, utiliza consulta em lote no banco de dados
    - **INTEGRAÇÃO COM EQUIPES**: Use com extrair_matriculas_do_xml para relatórios de equipe completos
    - **FLUXO DE EQUIPES**: listar_usuarios_equipe_por_gerente → extrair_matriculas_do_xml → listar_horas_trabalhadas
    - As datas são automaticamente convertidas usando converter_data_siga() quando fornecidas
    - A função utiliza a API de cálculo de horas trabalhadas do sistema SIGA
    - O cálculo inclui tanto atendimentos de OS quanto atendimentos avulsos
    - A API key é obtida automaticamente da variável de ambiente AVA_API_KEY
    - Em caso de falha na requisição HTTP ou parsing JSON, retorna mensagem de erro simples

    - Os parâmetros data_inicio e data_fim são obrigatórios (não têm valor padrão)
    - A resposta da API é processada através do XMLBuilder para formatação consistente
    - Esta função é útil para relatórios de produtividade e controle de horas individuais ou por equipe
    - O resultado consolida informações de múltiplas fontes (OS e atendimentos avulsos)
    - **QTD_HORAS**: Formato "HH:MM" representando o total de horas e minutos trabalhados em cada dia.
      O total acumulado no modo sintético pode ultrapassar 99h e será expresso como "HHH:MM" (3+ dígitos)
    - **ESCALABILIDADE**: Suporta desde consultas individuais até equipes inteiras em uma única chamada

INSTRUÇÃO PARA APRESENTAÇÃO DOS RESULTADOS (OBRIGATÓRIO):
A API retorna os dados brutos de todos calculados. 
Dependendo da pergunta do usuário, você listará isso de duas formas. Contudo, você DEVE SEMPRE organizar a resposta agrupando PRIMEIRO pelo Analista, e NUNCA por Dia.

MODO SINTÉTICO (padrão) — usar quando o usuário perguntar o total de horas trabalhadas:
    Exemplos de solicitações: "quantas horas trabalhei?", "total de horas da equipe", "qual minha produtividade?"
    → Apresentar UMA LINHA por analista com o total do período.
    → Incluir a matrícula junto ao nome.
    → Formato de apresentação OBRIGATÓRIO:
       **Analista: João da Silva (22222)** - Total no período: 15:30
       **Analista: Maria Souza (14444)** - Total no período: 06:15

MODO ANALÍTICO (diário) — usar quando o usuário pedir a lista diária ou detalhe por dia:
    Exemplos de solicitações: "liste as horas por dia", "mostre o detalhe diário", "quero ver dia a dia"
    → Apresentar a lista individual de cada dia trabalhado debaixo do nome de cada analista.
    → Incluir a matrícula junto ao nome e no totalizador.
    → Formato de apresentação OBRIGATÓRIO:
       **Analista: João da Silva (22222)**
       - 23/03/2026: 07:30
       - 24/03/2026: 08:00
       *Total do Analista (22222) no período: 15:30*

       **Analista: Maria Souza (14444)**
       - 23/03/2026: 06:15
       *Total do Analista (14444) no período: 06:15*

CÁLCULO DE HORAS (SOMA) PARA AMBOS OS MODOS:
- Como a API traz os dias particionados, VOCÊ é responsável por calcular o "Total do Analista".
- Para somar corretamente: converta cada valor de HH:MM para minutos inteiros, acumule o total do analista e converta devolta para o formato HHH:MM. 
- Exemplo prático: 07:37 + 05:13 = 457 min + 313 min = 770 min totais = 12:50.
- NUNCA trunque o total em 99h ou reinicie a contagem (se passar de 100 horas, mostre 125:30, por exemplo).

AMBIGUIDADE — quando não for possível determinar o modo pela pergunta do usuário:
    → Adotar o MODO SINTÉTICO como padrão.
    → Ao final da resposta, oferecer ao usuário a opção de ver os dias abertos:
       Exemplo: "Deseja ver o detalhamento dia a dia da equipe?"
"""
