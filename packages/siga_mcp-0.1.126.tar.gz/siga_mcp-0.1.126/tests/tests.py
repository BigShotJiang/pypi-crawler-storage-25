import asyncio
import sys
import os

# Adicionar o diretório pai ao path para importar o módulo siga_mcp
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from siga_mcp.tools.genericas import listar_horas_trabalhadas

# Carrega ambiente
from dotenv import load_dotenv

load_dotenv()


async def main() -> str:
    """
    Teste da função listar_horas_trabalhadas.
    Cenário 1: matrícula única
    Cenário 2: múltiplas matrículas
    """

    # -------------------------------------------------------
    # Cenário 1 — Matrícula única
    # -------------------------------------------------------
    print("\n" + "*" * 50)
    print("CENÁRIO 1 — listar_horas_trabalhadas (matrícula única)")
    print("*" * 50 + "\n")

    try:
        resultado_1 = await listar_horas_trabalhadas(
            matricula="24142",
            data_inicio="01/03/2026",
            data_fim="31/03/2026",
        )
        print("[DEBUG] Resultado 1:")
        print("-" * 50)
        print(resultado_1)
        print("-" * 50)
    except Exception as e:
        import traceback

        print(f"Erro no Cenário 1: {e}")
        traceback.print_exc()

    # -------------------------------------------------------
    # Cenário 2 — Múltiplas matrículas
    # -------------------------------------------------------
    print("\n" + "*" * 50)
    print("CENÁRIO 2 — listar_horas_trabalhadas (múltiplas matrículas)")
    print("*" * 50 + "\n")

    try:
        resultado_2 = await listar_horas_trabalhadas(
            matricula=["24142", "14864"],
            data_inicio="01/03/2026",
            data_fim="31/03/2026",
        )
        print("[DEBUG] Resultado 2:")
        print("-" * 50)
        print(resultado_2)
        print("-" * 50)
    except Exception as e:
        import traceback

        print(f"Erro no Cenário 2: {e}")
        traceback.print_exc()

    return "TESTES FINALIZADOS"


if __name__ == "__main__":
    resultado = asyncio.run(main())
    print(f"\n{resultado}")
