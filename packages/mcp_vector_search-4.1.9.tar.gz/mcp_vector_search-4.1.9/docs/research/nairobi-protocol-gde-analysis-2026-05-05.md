# Nairobi Protocol — Geometric Determinism Engine (GDE): Research Analysis

**Date:** 2026-05-05
**Repository:** https://github.com/tkimingi25-spec/Nairobi_Protocol-GDE-
**Author:** Tom Kimingi — RRD Kenya
**DOI:** https://doi.org/10.5281/zenodo.20036883
**Analyzed by:** Research Agent for mcp-vector-search

---

## Executive Summary

The Nairobi Protocol / GDE is a deterministic retrieval engine built in Mojo that attempts to replace probabilistic vector search (e.g., RAG with cosine similarity) with O(1) geometric address calculation. It maps text into a 24-dimensional geometric hash and uses that hash to directly compute a memory-mapped byte offset into a large address space — bypassing any scan. The benchmark claims show 345x speedup over cosine-scan RAG on a 10,000-entry knowledge base.

This is an independent open-source research project from Nairobi, Kenya (2026), formally published with a Zenodo DOI, and is genuinely novel in its framing and implementation approach — though it comes with significant technical caveats worth understanding carefully.

---

## 1. What the Project Is and Its Purpose

The GDE is positioned as an alternative to vector database search. Its central claim is:

> "Replace O(n) vector scanning with O(1) geometric addressing."

Instead of embedding a query into a vector space and then scanning all stored vectors for the closest match (what FAISS, ChromaDB, LanceDB etc. do), GDE computes a deterministic byte offset from the input text directly, then seeks to that exact location in a memory-mapped file. The same input always produces the same offset — across hardware architectures, to 14 decimal places.

**Mission framing:** The author explicitly frames this as a democratization technology — enabling AI retrieval on a 4GB laptop in Nairobi without GPU infrastructure or cloud dependency. This is a genuine and interesting design constraint that shapes the entire technical direction.

**Technology stack:**
- Mojo (systems language from Modular, Python-compatible, SIMD-native)
- Python (knowledge base generation, benchmark orchestration, ontology layer)
- networkx (DAG-based ontology graphs)
- SQLite (knowledge graph persistence)
- pixi (conda-based environment manager with Modular/MAX channel)
- Sparse file mmap (the core I/O primitive)

---

## 2. Architecture and Technical Approach

The system has three clearly layered stages:

### Layer 0 — Refinery (Python)
Semantic preprocessing using a knowledge graph.

- `ontology_parser.py`: Builds a SQLite-backed directed acyclic graph (DAG) of concept relationships using networkx. Normalizes labels, stores parent/child edges with integer IDs.
- `contrast_lca.py`: Implements **Contrastive Lowest Common Ancestor (LCA)** scoring. Given two nodes in the ontology DAG, it finds their lowest common ancestor, computes depth differentials, and generates a `ContrastiveCoordinates` struct with `logic_depth` and `geometric_resonance` properties. The formula is:
  ```
  contrast_penalty = |left_depth - lca_depth| + |right_depth - lca_depth| + 0.5 * |left_depth - right_depth|
  geometric_resonance = 1.0 - (penalty / baseline)
  ```
  This is essentially a graph-theoretic similarity metric that quantifies how "far apart" two concepts are through their shared ancestor.

### Layer 1 — Gateway (Mojo)
Geometric hashing and coordinate persistence.

- `phonological.mojo`: The core hash function. Converts text to a 24-dimensional float64 SIMD vector using a **Discrete Cosine Transform (DCT)** of the character byte values:
  ```
  hash[k] = scale * sum(signal[n] * cos(PI * k * (n + 0.5) / SIGNAL_LEN))
  ```
  This is literally DCT-II (the same transform used in JPEG compression). Character bytes are treated as a 32-sample signal; 24 DCT coefficients are extracted as the hash vector. Distance between hashes uses L2 (Euclidean).

- `spectral.mojo`: Computes a Laplacian graph signature from node degree values — square-root-normalized, L2-unit-normalized. This is used for graph structural encoding.

- `wavelet.mojo`: Encodes graph depth using exponential decay (`exp(-depth)`) — shallow nodes get higher magnitude, deep nodes decay toward zero. L2-normalized. This is a simple hierarchical position encoding.

- `persistence.mojo`: Saves/retrieves HashVectors to flat files with an `.idx` sidecar for byte-offset lookup. Uses `file.seek()` for direct positional access.

### Layer 2 — Execution (Mojo)
Memory-mapped retrieval.

- `coordinate_bridge.mojo`: Implements the core Nairobi Protocol formula:
  ```
  Offset = sum(|vi| * wi) + Base Address
  wi = (i + 1) * 2654435761  (Knuth multiplicative constant)
  ```
  The 24 DCT coefficients are weighted by dimension-scaled Knuth constants, absolute-valued, summed, and modulo'd into a 100GB address space. This is the O(1) lookup.

- `atlas_manager.mojo`: Tracks mmap page state across the address space.

- `logic_kernels.mojo`: SIMD distance operations.

**The key insight:** Since the hash is deterministic, the offset is deterministic. There is no scan — the address is *calculated*, not *searched for*.

---

## 3. Key Implementation Patterns and Algorithms

### 3.1 DCT-Based Text Hashing (phonological.mojo)
The `universal_geometric_hash()` function applies DCT-II to character byte values. This is a well-understood signal processing transform with nice properties:
- Energy compaction: most signal energy goes into low-frequency coefficients
- Deterministic and reversible
- Hardware-accelerated (SIMD cosine operations)
- Cross-platform consistent (the DCT formula is mathematically fixed)

The choice of DCT over neural embeddings is deliberate: it requires no model weights, no inference, and produces the same output on any CPU.

**Limitation:** DCT of character bytes is purely orthographic — "neural" and "neuron" will be close, but "king" and "monarch" will not be. There is no semantic content in these vectors.

### 3.2 Knuth Multiplicative Hashing for Address Distribution
The weight formula `wi = (i+1) * 2654435761` (the Knuth multiplicative constant, derived from the golden ratio: `2^32 / phi`) is chosen specifically to spread values across the address space with minimal collision clustering. This is a well-known technique in hash table design — using a near-golden-ratio multiplier produces excellent uniform distribution.

The GDE combines this with DCT coordinate components to map into a 100GB sparse address space with zero collisions across 10,000 entries.

### 3.3 Sparse File mmap for Zero-Allocation Address Spaces
The stress tests use `truncate -s 100G` to create a 100GB sparse file (allocates no actual disk space, only metadata). The mmap then provides a 100GB virtual address space. Seeks to calculated offsets touch only 2 bytes worth of actual disk allocation across 1M seeks. This is a creative use of the OS's sparse file support.

The benchmark of 524,659 seeks/second across a 100GB virtual space on WSL2 is the real engineering result.

### 3.4 Contrastive LCA Coordinates (contrast_lca.py)
This is the most theoretically interesting component. It uses graph-theoretic LCA (Lowest Common Ancestor) on an ontology DAG to produce a two-dimensional coordinate:
- `logic_depth`: The LCA's depth in the graph (measures how specific the common ancestor is)
- `geometric_resonance`: A normalized score from 0-1 measuring semantic proximity via graph distance

This is similar to Wu-Palmer similarity from WordNet, but with the contrastive penalty term that accounts for asymmetric depth differences.

### 3.5 Wavelet Depth Encoding
The hierarchical wavelet uses `exp(-depth)` as a position encoding — exactly analogous to sinusoidal position encodings in transformer models, but simplified to exponential decay. This could be combined with the DCT hash to give the system some sense of concept hierarchy without LLM inference.

---

## 4. The Benchmark — Understanding What It Actually Measures

The 345x speedup claim requires careful interpretation:

**What GDE is benchmarking:**
- RAG: `char_vector(query)` then linear scan of 10,000 entries with cosine similarity
- GDE: `char_vector(query)` then `coordinate_to_offset()` then dictionary `.get()`

**The catch:** Both systems use the *same* `char_vector()` function (DCT of character bytes). The "RAG" baseline is not using neural embeddings — it's using the same character-level DCT hash and scanning it with cosine similarity. The speedup is therefore:

> Dictionary hash lookup (O(1)) vs linear scan (O(n)) — using the same vector representation

This is a valid and real speedup, but it is essentially measuring hash table lookup vs linear scan, not "GDE vs semantic RAG." A FAISS flat index or approximate nearest neighbor index on real neural embeddings would paint a different picture.

The more interesting result is the mmap benchmark: 524,659 deterministic seeks/second across a virtual 100GB address space, with ~2 bytes of actual disk allocation.

---

## 5. Code Quality and Organization Observations

**Strengths:**
- Layered architecture with clear separation (refinery / gateway / execution)
- Clean Mojo SIMD usage — `SIMD[DType.float64, 24]` as a first-class type for the hash vector
- Good use of Mojo's `comptime` constants for dimension sizes
- Python components use modern dataclasses with `slots=True` for performance
- The ontology parser is well-structured with proper SQLite schema management
- Tests and benchmarks are separated cleanly
- `pixi.toml` is minimal and correct

**Weaknesses:**
- The benchmark comparison is misleading: "RAG" baseline is not semantic RAG, just a character-level linear scan
- `persistence.mojo` uses flat text files with string parsing for vector storage — inefficient for scale (should use binary format)
- No handling of hash collisions in a production context (acknowledged as pending in the status table)
- The 4GB laptop cross-hardware test is listed as "Pending" — the core portability claim is unverified
- Collision testing at 1M entries is pending — the 0-collision result is only verified at 10K entries
- The spectral and wavelet layers exist as standalone modules but are not yet integrated into the main retrieval pipeline
- No query latency percentile data (only averages reported)

**Overall code quality:** The Mojo code is idiomatic, clean, and well-organized for a research prototype. The Python layer is production-quality. The project is honest about its limitations in the status table.

---

## 6. Insights Relevant to mcp-vector-search

### 6.1 DCT as a Fast, Deterministic Pre-Hash Layer

**Applicable pattern:** Before doing expensive embedding model inference, GDE's DCT hash could serve as a fast pre-filter or cache key. For mcp-vector-search, when a user searches for a code symbol, the symbol name could be DCT-hashed to quickly identify "orthographically close" candidates (same function family, similar variable names) before semantic ranking. This is essentially a phonetic/orthographic similarity layer that's O(1) and zero-dependency.

**Implementation note:** The DCT-II over character bytes is ~10 lines of Python. It would add zero latency for cache lookups based on exact or near-exact string matches.

### 6.2 Contrastive LCA for Knowledge Graph Scoring

**Applicable pattern:** mcp-vector-search already builds a knowledge graph (KG) of code relationships. The `contrast_lca.py` scoring model is directly applicable for ranking KG traversal results. When a user queries for a concept and the KG returns related nodes, LCA-based geometric resonance could score the relevance of each related node to the query concept.

Specifically: if the KG has a hierarchy like `module -> class -> method`, the LCA depth between two methods tells you whether they share a class parent (close) or only a module parent (distant). This is richer than flat cosine similarity for structural code relationships.

### 6.3 Sparse File mmap for Large Index Address Spaces

**Applicable pattern:** mcp-vector-search currently uses LanceDB/ChromaDB for vector storage. The GDE's sparse mmap approach demonstrates that for deterministic-key lookups (e.g., exact file paths, exact symbol names), you can bypass the vector database entirely and seek directly to pre-computed offsets. For the KG's structural data (not the vector embeddings), a sparse mmap index could offer extremely fast exact-match lookups.

### 6.4 Wavelet Depth Encoding for Code Hierarchy

**Applicable pattern:** The `exp(-depth)` wavelet encoding is directly applicable to code structure. In a codebase AST:
- `depth=0`: module (high magnitude, broad concept)
- `depth=1`: class (medium)
- `depth=2`: method (lower)
- `depth=3`: local variable (very low)

This encoding could be concatenated with embedding vectors to give the search model positional awareness of where in the code hierarchy a symbol lives — without requiring additional model training.

### 6.5 Knuth Weight Distribution for Multi-Dimensional Indexing

**Applicable pattern:** The Knuth multiplicative constant `2654435761` for dimension weighting is a useful technique for combining multi-dimensional coordinates into a single scalar with good distribution properties. For mcp-vector-search's hybrid search (BM25 + dense vectors), a similar weighted combination could produce a single composite score with mathematically guaranteed spread.

### 6.6 Benchmark Design Lesson

**Cautionary note:** The GDE benchmark's misleading comparison (DCT scan vs DCT hash lookup, not neural RAG vs GDE) is a useful reminder that benchmarks in this domain need careful design. For mcp-vector-search benchmarks, always specify:
1. The embedding model used (or lack thereof)
2. The index type (flat, IVF, HNSW, etc.)
3. Whether the comparison is recall@k matched or just latency

---

## 7. Novel or Interesting Aspects

1. **Geometry-as-index**: The core idea of using a deterministic geometric transformation to compute storage addresses (rather than search for them) is genuinely novel in the retrieval literature. It solves the exact-match problem differently than hash tables do — using signal processing geometry rather than arbitrary hash functions.

2. **Cross-hardware determinism**: The DCT-based hash achieves 14-decimal-place consistency across architectures (x86 and ARM tested). This is a meaningful property for distributed systems where indices need to be pre-computed on one machine and used on another.

3. **100GB virtual addressing with 2-byte physical allocation**: The sparse mmap demonstration is an elegant systems engineering result — showing that "address space size" and "storage consumed" can be decoupled almost completely for deterministic workloads.

4. **Physics-inspired framing**: The author frames semantic similarity through "geometric resonance" and "spectral signatures" — borrowing from physics. While currently theoretical/incomplete, this framing has potential for combining acoustic phonology, graph spectral theory, and wavelet analysis into a unified non-neural representation.

5. **Developing-world constraint design**: Building for 4GB RAM, no GPU, offline — these constraints produce an engineering direction (mmap + deterministic math) that is genuinely different from mainstream AI infrastructure, and arguably more resilient.

---

## 8. Critical Assessment

**What works:**
- The mmap sparse file addressing technique is real and fast
- Zero collisions at 10K entries is a valid proof of concept
- The contrastive LCA scoring is mathematically sound
- DCT hashing is deterministic and cross-platform

**What doesn't work (yet) or is overstated:**
- The 345x speedup is hash lookup vs linear scan, not deterministic vs semantic search
- DCT of character bytes has no semantic content — "happy" and "joyful" will have very different offsets
- The spectral/wavelet layers are implemented but not connected to the main pipeline
- Collision behavior at 1M+ entries is unknown
- The system currently only supports exact retrieval (the query must be in the knowledge base)
- No fuzzy matching, no approximate nearest neighbor

**Compared to mcp-vector-search:** mcp-vector-search uses dense neural embeddings (CodeBERT/MiniLM) that capture semantic meaning — "function" and "method" are close in embedding space. GDE's DCT hash would not capture this. The GDE is solving a different problem: extremely fast exact-match retrieval in deterministic environments.

---

## 9. Summary Recommendations for mcp-vector-search

| GDE Component | Applicability to mcp-vector-search | Priority |
|---|---|---|
| DCT pre-hash as cache key | High — fast exact-symbol cache lookup | Medium |
| Contrastive LCA scoring | High — directly applicable to KG traversal ranking | High |
| Sparse mmap for KG structure | Medium — depends on KG access patterns | Low |
| Wavelet depth encoding | Medium — code hierarchy position encoding | Medium |
| Knuth weight distribution | Low — useful for composite score normalization | Low |
| Overall architecture | Low — mcp-vector-search needs semantic embeddings, not DCT | N/A |

The most immediately useful takeaway is the **Contrastive LCA scoring** from `contrast_lca.py` — it could be adopted directly to improve ranking of knowledge graph traversal results in mcp-vector-search with minimal implementation effort.

---

*Research saved to: docs/research/nairobi-protocol-gde-analysis-2026-05-05.md*
