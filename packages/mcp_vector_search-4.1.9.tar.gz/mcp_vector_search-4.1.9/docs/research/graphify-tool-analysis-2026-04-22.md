# Graphify Tool Analysis

**Date:** 2026-04-22
**Topic:** Graphify — Knowledge Graph Skill for AI Coding Assistants
**Scope:** What it is, technical approach, "70x fewer tokens" claim, benchmarks, community reception, limitations

---

## What Is Graphify?

Graphify is an open-source Python tool and AI coding assistant skill created by Safi Shamsi, released on April 3, 2026 under the MIT license. It was directly inspired by a post from Andrej Karpathy on April 2, 2026, where he described his `raw/` folder workflow for LLM context and challenged the community to build a proper product around it. Graphify shipped within 48 hours and crossed 22,000 GitHub stars in under ten days (31,600+ stars as of ~April 21, 2026, global rank #948 on star-history).

The core idea: instead of an AI assistant re-reading raw files on every query, Graphify builds a knowledge graph once and stores it on disk. Subsequent queries traverse the compact graph rather than the full file set.

**GitHub:** https://github.com/safishamsi/graphify
**Website:** https://graphify.net

---

## Technical Approach

### Three-Pass Extraction Pipeline

1. **Deterministic AST pass** — Tree-sitter parses source code locally, extracting classes, functions, imports, call graphs, docstrings, and rationale comments. No LLM involved; no code leaves the machine. Supports 25 languages (Python, JS, TS, Go, Rust, Java, C, C++, Ruby, C#, Kotlin, Scala, PHP, Swift, Lua, Zig, PowerShell, Elixir, Objective-C, Julia, Verilog, SystemVerilog, Vue, Svelte, Dart).

2. **Local audio/video transcription** — faster-whisper transcribes video and audio files locally using a domain-aware prompt derived from the graph's high-connectivity ("god") nodes. Audio never leaves the machine.

3. **LLM semantic extraction (parallel subagents)** — Claude subagents process docs, PDFs, images, and transcripts to extract concepts, relationships, and design rationale. This is the only step that sends content to an external API (using your existing model API key, never raw source code).

### Graph Construction

- Built on **NetworkX**, clustered with **Leiden community detection** (graph-topology-based, no embeddings).
- Nodes represent concepts: classes, functions, design decisions, paper sections, diagrams.
- Edges represent relationships: `calls`, `imports`, `rationale_for`, `semantically_similar_to`.
- Edge confidence tags: `EXTRACTED` (1.0, from AST), `INFERRED` (0.0–1.0, from LLM), `AMBIGUOUS` (flagged for human review).
- Supports hyperedges (3+ node relationships).
- SHA256 cache: only reprocesses changed files on incremental runs.

### Query Mechanism

At query time, a BFS traversal extracts the relevant subgraph containing only nodes and edges needed to answer the question. This compact subgraph — not the full raw files — is passed to the AI assistant.

### Output Artifacts

- `graph.html` — interactive D3-based visualization with search, filter, community navigation.
- `GRAPH_REPORT.md` — plain-language audit listing "god nodes," surprising connections, suggested questions.
- `graph.json` — queryable persistent graph with SHA256 cache.

### Integration

Installed as a slash command (`/graphify`) for Claude Code, Codex, OpenCode, Cursor, Gemini CLI, GitHub Copilot CLI, and others. For Claude Code specifically, a `PreToolUse` hook fires before every Glob and Grep call, directing Claude to consult `GRAPH_REPORT.md` first.

Git hooks (`graphify hook install`) rebuild the graph automatically after every commit and branch switch.

---

## The "70x Fewer Tokens" Claim

### The Number

The precise figure cited is **71.5x fewer tokens per query**, sometimes rounded to "70x" in marketing.

### Comparison Basis

- **Baseline (naive):** AI assistant reads raw files from scratch for each query — approximately **~123k tokens** per query on the benchmark corpus.
- **With Graphify:** AI assistant queries the compact graph — approximately **~1.7k tokens** per query.
- **Ratio:** 123k / 1.7k ≈ 71.5x.

### Benchmark Corpus

The benchmark was run on a **52-file mixed corpus** (code + papers + images). This is the only reported test corpus; no standard benchmark dataset was used.

### Key Caveat: Upfront Cost

The first run (graph construction) costs tokens — potentially substantial for large repositories with many PDFs and images. The 71.5x saving applies to **subsequent queries**, not the initial build. The SHA256 cache makes re-runs cheap, but the first run is not.

### Independence of the Benchmark

No independent third-party replication of the 71.5x figure exists as of the research date. The number comes from the project's own documentation and promotional content. There is no controlled comparison against RAG-based alternatives or other code intelligence tools on a shared test set.

---

## Community Reception

- **GitHub stars:** 31,600+ in under three weeks of existence; global rank #948.
- **Forks:** 3,500+.
- Active issue tracker with hundreds of issues (issues #477–#480 opened on April 21, 2026 alone).
- Covered in Medium, Analytics Vidhya, PyShine, Flowtivity, emelia.io, CLSkills Hub, roborhythms, and toolhunter.cc within days of launch.
- Inspired derivative projects (e.g., `claude-code-memory-setup` on GitHub combining Graphify + Obsidian for persistent memory).
- No significant Hacker News or Reddit threads surfaced in research; community discussion concentrated on GitHub Issues and Discussions.

---

## Limitations and Criticisms

### From Community Code Review (GitHub Issue #63)

- **Scalability:** Largest identified risk is not code quality but growth: centralization in extraction logic, subtle schema inconsistencies, and tension between directional semantics and an undirected graph core.
- **Configuration rigidity:** Assumes `graphify-out/` directory relative to project root; no central config file for alternate layouts.
- **SSRF risk:** `validate_url()` resolves hostname before fetch, but the actual HTTP request may resolve again — flagged as a residual SSRF risk.
- **Symlink inconsistency:** Documentation claims `followlinks=False` throughout `detect.py`, but one code path uses `Path.rglob()` which may follow symlinks.
- **Large-graph bug:** `_rebuild_code` (used in watch/update/git hook) failed on graphs with more than 5,000 nodes due to a `ValueError` in `to_html`.
- **Node ID mismatch (fixed):** AST/semantic node ID mismatch caused edges to be dropped when the LLM generated slightly different casing or punctuation than the AST extractor; patched in `build_from_json`.

### Benchmark Methodology Gaps

- No controlled experimental design documented.
- No comparison against RAG-based alternatives or embedding-based code search.
- Single test corpus (52 files); no scaling data for large repos (hundreds of files).
- Upper limit of file count is an open question; community reports attempted ~642 large markdown files with unresolved scalability concerns.

### Strategic Tension

- Open community question: remain a compact local tool vs. evolve into an extensible platform. This choice will shape architecture significantly.
- Generated artifacts (wiki, report) are not yet treated as stable machine-consumable interfaces.

### Privacy Nuance

- Code stays local (Tree-sitter). Docs, PDFs, images, and transcripts are sent to the model API. This is a meaningful tradeoff for teams with sensitive design documentation.

---

## Summary Assessment

Graphify is a technically coherent, rapidly adopted tool that solves a real problem: the token and latency cost of re-reading large codebases on every AI query. Its technical approach — combining deterministic AST parsing with LLM-powered semantic extraction and graph-topology clustering — is well-grounded. The 71.5x token reduction figure is plausible given the mechanism, but comes from a single self-reported benchmark on a 52-file corpus with no independent replication. The tool is barely three weeks old (v0.4.2, ~130 commits), moving fast, and carrying the architectural debt of rapid growth. For teams already using Claude Code or similar CLI-first AI assistants on mixed-media repositories, it is worth evaluating — with the caveat that the first-run API cost can be significant and the benchmark does not yet reflect large-scale real-world repos.

---

## Sources

- https://github.com/safishamsi/graphify
- https://graphify.net/
- https://pyshine.com/Graphify-AI-Knowledge-Graph-From-Any-Codebase/
- https://graphify.net/knowledge-graph-for-ai-coding-assistants.html
- https://emelia.io/hub/knowledge-graph-graphify-guide
- https://medium.com/@mustafa.gencc94/graphify-build-a-knowledge-graph-from-your-entire-codebase-without-sending-your-code-to-anyone-1b6924474b50
- https://flowtivity.ai/blog/graphify-knowledge-graph-coding-assistant/
- https://clskillshub.com/blog/graphify-claude-code-integration
- https://www.analyticsvidhya.com/blog/2026/04/graphify-guide/
- https://github.com/safishamsi/graphify/issues/63
- https://github.com/safishamsi/graphify/issues/162
- https://www.youtube.com/watch?v=Ll_wtUG-Wn8
