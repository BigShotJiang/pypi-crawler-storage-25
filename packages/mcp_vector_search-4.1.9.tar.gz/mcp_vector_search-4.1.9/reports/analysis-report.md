# Analysis Report

## Results from Semantic Search

1. **docs/research/issue-17-diff-aware-analysis-research.md**
2. **docs/development/root-node-filtering-fix.md**
3. **docs/research/treemap-sunburst-drill-down-color-issues-2026-02-20.md**
4. **docs/research/incremental-indexing-analysis-2026-02-25.md**
5. **docs/research/chunking-pipeline-performance-audit-2026-03-01.md**