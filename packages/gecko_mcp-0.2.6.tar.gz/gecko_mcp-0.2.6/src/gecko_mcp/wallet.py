"""Wallet facade for the gecko-mcp CLI — frames.ag AgentWallet (v3).

We do NOT hold private keys. The frames.ag skill (`https://frames.ag/skill.md`)
owns the connect flow and caches credentials at `~/.agentwallet/config.json`.
This module reads that canonical path and proxies wallet operations to
`frames.ag/api/wallets/{username}/...`.

Self-custody fallback (v2) lives in `wallet_self_custody.py` and is unused by
default; switch by setting `GECKO_WALLET_PROVIDER=self`.

Security:
- The apiToken is treated as a password. It is never logged, echoed, or
  included in error messages.
- We read `~/.agentwallet/config.json` once per command invocation.
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any

import click
import httpx
from gecko_core.wallet import (
    DEFAULT_CONFIG_PATH as _SHARED_CONFIG_PATH,
)
from gecko_core.wallet import (
    read_agent_config as _read_agent_config_shared,
)

from gecko_mcp.wallet_self_custody import (
    WALLET_PATH,
    get_keypair_for_signing,
)

# Re-export for back-compat with code/tests that import CONFIG_PATH from here.
CONFIG_PATH = _SHARED_CONFIG_PATH
FRAMES_BASE = os.environ.get("FRAMES_AG_BASE_URL", "https://frames.ag/api")
DEFAULT_TIMEOUT = 30.0

_GECKO_CONFIG_PATH = Path.home() / ".gecko" / "config.toml"


def _read_gecko_config() -> dict[str, str]:
    """Read ~/.gecko/config.toml into a flat dict (key=value pairs only)."""
    if not _GECKO_CONFIG_PATH.exists():
        return {}
    result: dict[str, str] = {}
    for line in _GECKO_CONFIG_PATH.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" in line:
            k, _, v = line.partition("=")
            result[k.strip()] = v.strip().strip('"').strip("'")
    return result


def _write_gecko_config(data: dict[str, str]) -> None:
    _GECKO_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    lines = [f'{k} = "{v}"' for k, v in data.items()]
    _GECKO_CONFIG_PATH.write_text("\n".join(lines) + "\n")


def _wallet_provider() -> str:
    """Return the effective wallet provider: 'frames' or 'self'."""
    env = os.environ.get("GECKO_WALLET_PROVIDER")
    if env:
        return env
    cfg = _read_gecko_config()
    return cfg.get("GECKO_WALLET_PROVIDER", "frames")


__all__ = [
    "CONFIG_PATH",
    "FRAMES_BASE",
    "WALLET_PATH",
    "FramesAGWallet",
    "WalletNotConfiguredError",
    "_wallet_provider",
    "get_keypair_for_signing",
    "wallet",
]


class WalletNotConfiguredError(RuntimeError):
    pass


def _read_config() -> dict[str, Any]:
    """Wrap the shared `gecko_core.wallet` parser with the MCP-side error
    semantics (raise WalletNotConfiguredError when missing, with the existing
    user-facing hint). Single source of truth lives in gecko-core so doctor
    and MCP can't drift on what counts as a valid config (S9-DOCTOR-01).
    """
    cfg = _read_agent_config_shared(CONFIG_PATH)
    if cfg is None:
        raise WalletNotConfiguredError(
            f"No frames.ag credentials at {CONFIG_PATH}. "
            "Run `gecko-mcp wallet new` to connect (delegates to frames.ag's skill)."
        )
    return cfg


def _client(config: dict[str, Any]) -> httpx.Client:
    token = config["apiToken"]
    return httpx.Client(
        base_url=FRAMES_BASE,
        headers={"Authorization": f"Bearer {token}"},
        timeout=DEFAULT_TIMEOUT,
    )


def _username(config: dict[str, Any]) -> str:
    return str(config["username"])


def _frames_error_message(exc: httpx.HTTPStatusError) -> str:
    """Map frames.ag error codes to user-actionable messages.

    Codes are listed in https://frames.ag/skill.md and we surface them verbatim
    rather than paraphrasing — agents and users both deserve the real reason.
    """
    try:
        body = exc.response.json()
    except Exception:
        return f"frames.ag returned {exc.response.status_code}"
    code = body.get("code") or body.get("error") or ""
    message = body.get("message") or ""
    hints = {
        "POLICY_DENIED": "Your spending policy denied this payment. Update with `gecko-mcp wallet policy --max-per-tx <USD>`.",
        "WALLET_FROZEN": "Your frames.ag wallet is frozen. Visit https://frames.ag to resolve.",
        "insufficient_funds": "Wallet balance insufficient. Fund at https://frames.ag/u/<username>.",
        "PAYMENT_REJECTED": "Target API rejected the payment (target-side issue).",
        "INVALID_URL": "URL is malformed, points to localhost, or an internal IP.",
        "TARGET_TIMEOUT": "Target API timed out.",
        "TARGET_ERROR": "Target API returned a 5xx error.",
        "NO_PAYMENT_OPTION": "No compatible payment network for this endpoint.",
    }
    hint = hints.get(code, "")
    parts = [code or "frames.ag error", message, hint]
    return " — ".join(p for p in parts if p)


# ---------------------------------------------------------------------------
# Click commands
# ---------------------------------------------------------------------------


@click.group()
def wallet() -> None:
    """Manage the agent wallet that pays for Gecko sessions via x402.

    Wallet custody is delegated to frames.ag's AgentWallet — server-custodial,
    x402-native, policy-controlled. We don't hold private keys here.
    """


def _frames_connect(email: str) -> dict[str, Any]:
    """Walk the frames.ag Email+OTP connect flow entirely in-process.

    Steps:
      1. POST /api/connect/start   → receive username, trigger OTP email
      2. Prompt user for 6-digit OTP in the terminal
      3. POST /api/connect/complete → receive apiToken, evmAddress, solanaAddress

    Returns the credential dict ready to write to CONFIG_PATH.
    Raises click.ClickException on any HTTP or validation error (message is
    surfaced verbatim — we don't rephrase frames.ag errors).
    """
    with httpx.Client(base_url=FRAMES_BASE, timeout=DEFAULT_TIMEOUT) as http:
        # Step 1: initiate OTP
        try:
            r = http.post("/connect/start", json={"email": email})
            r.raise_for_status()
        except httpx.HTTPStatusError as exc:
            raise click.ClickException(
                f"frames.ag /connect/start failed: {_frames_error_message(exc)}"
            ) from exc
        except httpx.HTTPError as exc:
            raise click.ClickException(f"frames.ag unreachable: {exc}") from exc

        body = r.json()
        username: str = body.get("username") or body.get("user", {}).get("username", "")
        if not username:
            raise click.ClickException(
                f"frames.ag returned no username in /connect/start response: {body}"
            )

        click.echo(f"  Check your inbox for a 6-digit code sent to {email}")
        otp = click.prompt("  Enter the 6-digit code", prompt_suffix=": ").strip()
        if not otp or not otp.isdigit() or len(otp) != 6:
            raise click.ClickException("OTP must be exactly 6 digits.")

        # Step 2: verify OTP and receive credentials
        try:
            r2 = http.post(
                "/connect/complete",
                json={"username": username, "email": email, "otp": otp},
            )
            r2.raise_for_status()
        except httpx.HTTPStatusError as exc:
            raise click.ClickException(
                f"frames.ag /connect/complete failed: {_frames_error_message(exc)}"
            ) from exc
        except httpx.HTTPError as exc:
            raise click.ClickException(f"frames.ag unreachable during OTP verify: {exc}") from exc

        creds = r2.json()
        api_token: str = creds.get("apiToken", "")
        evm_address: str = creds.get("evmAddress", "")
        solana_address: str = creds.get("solanaAddress", "")

        if not api_token:
            raise click.ClickException(
                "frames.ag returned no apiToken in /connect/complete response"
            )

    return {
        "username": username,
        "solanaAddress": solana_address,
        "evmAddress": evm_address,
        "apiToken": api_token,
    }


def _write_frames_config(config: dict[str, Any]) -> None:
    """Write credential dict to CONFIG_PATH with chmod 600."""
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(config, indent=2))
    CONFIG_PATH.chmod(0o600)


@wallet.command()
@click.option("--email", default=None, help="Email address to register / connect with.")
def new(email: str | None) -> None:
    """Connect to frames.ag via Email+OTP — no browser required.

    Sends a 6-digit OTP to your email, then writes credentials to
    ~/.agentwallet/config.json (chmod 600). Completes in under 60 seconds.
    """
    if CONFIG_PATH.exists():
        try:
            config = _read_config()
        except Exception as exc:
            click.secho(
                f"Existing config at {CONFIG_PATH} is unreadable: {exc}", fg="red", err=True
            )
            sys.exit(1)
        click.secho("Already connected to frames.ag.", fg="green")
        click.echo(f"  username:        @{config.get('username', '?')}")
        click.echo(f"  solana address:  {config.get('solanaAddress', '?')}")
        click.echo(f"  evm address:     {config.get('evmAddress', '?')}")
        click.echo()
        click.echo(f"Fund at https://frames.ag/u/{config.get('username', '<username>')}")
        click.echo("To reconnect with a different account, delete:")
        click.echo(f"  {CONFIG_PATH}")
        return

    click.secho("Connecting to frames.ag AgentWallet...", fg="cyan")
    click.echo()

    if email is None:
        email = click.prompt("  Enter your email").strip()

    if not email or "@" not in email:
        click.secho("Invalid email address.", fg="red", err=True)
        sys.exit(1)

    try:
        config = _frames_connect(email)
    except click.ClickException as exc:
        click.secho(str(exc.format_message()), fg="red", err=True)
        sys.exit(1)

    _write_frames_config(config)

    username = config.get("username", "?")
    solana_address = config.get("solanaAddress", "?")

    click.echo()
    click.secho("Wallet ready", fg="green")
    click.echo(f"  username:       @{username}")
    click.echo(f"  solana address: {solana_address}")
    click.echo()
    click.echo(f"Fund at https://frames.ag/u/{username} or https://app.geckovision.tech/onramp")
    click.echo()
    click.echo("Next: gecko-mcp doctor")


@wallet.command()
@click.option("--chain", type=click.Choice(["solana", "evm", "both"]), default="both")
def address(chain: str) -> None:
    """Print the wallet address(es). Safe to share."""
    config = _read_config()
    if chain in ("solana", "both"):
        click.echo(f"solana: {config.get('solanaAddress', '<missing>')}")
    if chain in ("evm", "both"):
        click.echo(f"evm:    {config.get('evmAddress', '<missing>')}")


@wallet.command()
def balance() -> None:
    """Show USDC balance per chain."""
    config = _read_config()
    with _client(config) as http:
        try:
            r = http.get(f"/wallets/{_username(config)}/balances")
            r.raise_for_status()
        except httpx.HTTPStatusError as exc:
            click.secho(_frames_error_message(exc), fg="red", err=True)
            sys.exit(1)
        except httpx.HTTPError as exc:
            click.secho(f"frames.ag unreachable: {exc}", fg="red", err=True)
            sys.exit(1)
    body = r.json()
    click.echo(json.dumps(body, indent=2))


@wallet.command()
@click.option("--limit", default=20, type=int)
def activity(limit: int) -> None:
    """Recent wallet activity."""
    config = _read_config()
    with _client(config) as http:
        try:
            r = http.get(f"/wallets/{_username(config)}/activity", params={"limit": limit})
            r.raise_for_status()
        except httpx.HTTPStatusError as exc:
            click.secho(_frames_error_message(exc), fg="red", err=True)
            sys.exit(1)
    click.echo(json.dumps(r.json(), indent=2))


@wallet.command()
def stats() -> None:
    """Aggregate spend, rank, streak."""
    config = _read_config()
    with _client(config) as http:
        try:
            r = http.get(f"/wallets/{_username(config)}/stats")
            r.raise_for_status()
        except httpx.HTTPStatusError as exc:
            click.secho(_frames_error_message(exc), fg="red", err=True)
            sys.exit(1)
    click.echo(json.dumps(r.json(), indent=2))


@wallet.command()
@click.option("--show", is_flag=True, default=False, help="Show current policy")
@click.option("--max-per-tx", type=float, default=None, help="Update max_per_tx_usd")
@click.option("--allow-chains", type=str, default=None, help="Comma-separated chains")
def policy(show: bool, max_per_tx: float | None, allow_chains: str | None) -> None:
    """Show or update spending policy."""
    config = _read_config()
    path = f"/wallets/{_username(config)}/policy"
    with _client(config) as http:
        try:
            if max_per_tx is None and allow_chains is None:
                r = http.get(path)
            else:
                update: dict[str, Any] = {}
                if max_per_tx is not None:
                    update["max_per_tx_usd"] = max_per_tx
                if allow_chains is not None:
                    update["allow_chains"] = [
                        c.strip() for c in allow_chains.split(",") if c.strip()
                    ]
                r = http.patch(path, json=update)
            r.raise_for_status()
        except httpx.HTTPStatusError as exc:
            click.secho(_frames_error_message(exc), fg="red", err=True)
            sys.exit(1)
    click.echo(json.dumps(r.json(), indent=2))


@wallet.command(name="pay")
@click.argument("url")
@click.option("--method", default="POST")
@click.option("--body", default=None, help="JSON body for the target request")
@click.option("--max-payment", default=None, help="Max USD willing to pay (e.g. '0.05')")
def pay(url: str, method: str, body: str | None, max_payment: str | None) -> None:
    """Generic x402 fetch. Frames.ag handles 402 detection, signing, and retry."""
    config = _read_config()
    payload: dict[str, Any] = {"url": url, "method": method}
    if body:
        try:
            payload["body"] = json.loads(body)
        except json.JSONDecodeError as exc:
            click.secho(f"--body is not valid JSON: {exc}", fg="red", err=True)
            sys.exit(1)
    if max_payment:
        payload["maxPayment"] = max_payment

    with _client(config) as http:
        try:
            r = http.post(
                f"/wallets/{_username(config)}/actions/x402/fetch",
                json=payload,
            )
            r.raise_for_status()
        except httpx.HTTPStatusError as exc:
            click.secho(_frames_error_message(exc), fg="red", err=True)
            sys.exit(1)
    click.echo(json.dumps(r.json(), indent=2))


@wallet.command(name="doctor")
def wallet_doctor() -> None:
    """Verify credentials cached, frames.ag reachable, balance > 0."""
    if not CONFIG_PATH.exists():
        click.secho(f"❌ no credentials at {CONFIG_PATH}", fg="red", err=True)
        click.echo("   run `gecko-mcp wallet new`")
        sys.exit(1)
    click.secho(f"✅ credentials cached at {CONFIG_PATH}", fg="green")

    config = _read_config()
    with _client(config) as http:
        try:
            r = http.get(f"/wallets/{_username(config)}/balances")
            r.raise_for_status()
        except httpx.HTTPError as exc:
            click.secho(f"❌ frames.ag unreachable: {exc}", fg="red", err=True)
            sys.exit(1)
    click.secho("✅ frames.ag reachable", fg="green")

    body = r.json()
    click.echo(f"   balances: {json.dumps(body)}")


@wallet.command(name="switch")
@click.argument("provider", type=click.Choice(["frames", "self"]))
def wallet_switch(provider: str) -> None:
    """Switch wallet provider (frames = frames.ag, self = local keypair).

    Writes GECKO_WALLET_PROVIDER to ~/.gecko/config.toml so the choice
    survives shell restarts and is picked up by quickstart and doctor.
    """
    cfg = _read_gecko_config()
    cfg["GECKO_WALLET_PROVIDER"] = provider
    _write_gecko_config(cfg)

    if provider == "self":
        from gecko_mcp.wallet_self_custody import WALLET_PATH

        if WALLET_PATH.exists():
            click.secho(f"Switched to self-custody wallet at {WALLET_PATH}", fg="green")
        else:
            click.secho("Switched to self-custody mode.", fg="green")
            click.echo(f"No wallet found at {WALLET_PATH}. Create one with:")
            click.secho("  gecko-mcp wallet new", bold=True)
    else:
        if CONFIG_PATH.exists():
            click.secho("Switched to frames.ag wallet.", fg="green")
        else:
            click.secho("Switched to frames.ag mode.", fg="green")
            click.echo(f"No frames.ag credentials at {CONFIG_PATH}. Set up with:")
            click.secho("  gecko-mcp wallet new", bold=True)

    click.echo(f"Provider saved to {_GECKO_CONFIG_PATH}")


# ---------------------------------------------------------------------------
# Programmatic access (used by gecko-mcp.api_client / server)
# ---------------------------------------------------------------------------


class FramesAGWallet:
    """Async facade used by gecko-mcp's API client when it needs to sign x402 calls."""

    def __init__(self) -> None:
        self.config = _read_config()
        self._http = self._build_client()

    def _build_client(self) -> httpx.AsyncClient:
        """Build a fresh httpx client tuned for frames.ag's edge.

        Why these settings:
        - ``max_keepalive_connections=0`` — gecko-mcp serve is a long-lived
          subprocess. frames.ag is fronted by Vercel; idle pooled sockets
          get silently dropped on their side and surface as 502 Bad Gateway
          on the next reuse. Curl and short-lived python -c calls always
          open fresh TCP and never see this. Disabling keepalive costs
          ~150ms per request — a fair price to avoid phantom 502s.
        - ``Connection: close`` — same reason, belt-and-suspenders. Some
          intermediate proxies honor the header even when the client pool
          would otherwise reuse the socket.
        - ``http2=False`` — explicit HTTP/1.1; httpx defaults to HTTP/1.1
          unless installed with the http2 extra, but pinning makes our
          behavior independent of which extras the install picked up.
        - ``User-Agent`` — identifiable in frames.ag's edge logs if we
          need to escalate; default ``python-httpx/...`` is generic enough
          to be lumped with bots.
        """
        return httpx.AsyncClient(
            base_url=FRAMES_BASE,
            headers={
                "Authorization": f"Bearer {self.config['apiToken']}",
                "Connection": "close",
                "User-Agent": "gecko-mcp/0.1 (+https://geckovision.tech)",
                "Accept": "application/json",
            },
            timeout=120.0,
            limits=httpx.Limits(max_keepalive_connections=0, max_connections=10),
            http2=False,
        )

    @property
    def username(self) -> str:
        return str(self.config["username"])

    @property
    def solana_address(self) -> str:
        return str(self.config.get("solanaAddress", ""))

    @property
    def evm_address(self) -> str:
        return str(self.config.get("evmAddress", ""))

    async def aclose(self) -> None:
        await self._http.aclose()

    async def balance(self) -> dict[str, Any]:
        r = await self._http.get(f"/wallets/{self.username}/balances")
        r.raise_for_status()
        return r.json()  # type: ignore[no-any-return]

    async def x402_fetch(
        self,
        url: str,
        method: str = "POST",
        body: dict[str, Any] | None = None,
        max_payment_usd: str | None = None,
        *,
        max_attempts: int = 3,
    ) -> dict[str, Any]:
        """One-step x402 — frames.ag handles 402 detection, signing, retry.

        Retries up to ``max_attempts`` on 502/503/504 from frames.ag's gateway
        with linear backoff (1s, 2s). On each 5xx, the underlying httpx
        client is closed and rebuilt — otherwise a stale-pool 502 just
        reuses the same poisoned socket on the retry. 4xx errors raise
        immediately (don't waste backoff on auth failures).
        """
        import asyncio as _asyncio

        payload: dict[str, Any] = {"url": url, "method": method}
        if body is not None:
            payload["body"] = body
        if max_payment_usd is not None:
            payload["maxPayment"] = max_payment_usd

        last_status: int = 0
        for attempt in range(max_attempts):
            r = await self._http.post(
                f"/wallets/{self.username}/actions/x402/fetch",
                json=payload,
            )
            if r.status_code < 500 or r.status_code >= 600:
                # 2xx/3xx/4xx — raise_for_status will distinguish.
                r.raise_for_status()
                return r.json()  # type: ignore[no-any-return]

            last_status = r.status_code
            if attempt + 1 < max_attempts:
                # Tear down the client so the retry uses a fresh TCP+TLS
                # handshake. Without this, a stale-keepalive 502 cascades
                # across all retries.
                await self._http.aclose()
                self._http = self._build_client()
                await _asyncio.sleep(attempt + 1)

        # Exhausted retries — raise the most recent response so the caller
        # sees the body (helps debug what frames.ag's gateway is saying).
        r.raise_for_status()  # always raises since 5xx
        raise RuntimeError(f"unreachable — frames.ag returned {last_status}")
