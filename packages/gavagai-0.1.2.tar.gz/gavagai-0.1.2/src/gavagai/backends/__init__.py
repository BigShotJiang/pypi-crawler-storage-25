"""Adapters that turn third-party SAE objects into uniform decoder matrices.

The core score path operates on plain numpy decoder matrices. Backends know
how to extract those matrices from concrete SAE implementations (SAELens,
raw .safetensors, dict-shaped checkpoints, …).
"""

from gavagai.backends.saelens_adapter import extract_decoder, load_decoder_from_path

__all__ = ["extract_decoder", "load_decoder_from_path"]
