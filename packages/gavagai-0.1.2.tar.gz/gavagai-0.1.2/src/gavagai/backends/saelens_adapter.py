"""Adapter to extract decoder weights from a SAELens SAE or compatible objects.

We accept four shapes without requiring sae-lens at import time:

1. SAELens `SAE` instance with `.W_dec` torch tensor.
2. Plain dict with key "W_dec" (e.g. raw safetensors dump).
3. Object with a `.decoder.weight` attribute (PyTorch convention).
4. Numpy array passed directly (no extraction needed).

All extractions return numpy arrays of shape (n_features, d_model).
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np


def _to_numpy(obj: Any) -> np.ndarray:
    """Best-effort conversion to numpy without forcing torch import."""
    if isinstance(obj, np.ndarray):
        return obj
    # torch tensor
    if hasattr(obj, "detach") and hasattr(obj, "cpu") and hasattr(obj, "numpy"):
        return obj.detach().cpu().numpy()
    # generic iterable
    try:
        return np.asarray(obj)
    except Exception as e:
        raise TypeError(f"cannot convert object of type {type(obj)} to numpy") from e


def extract_decoder(sae: Any) -> np.ndarray:
    """Return the SAE decoder matrix as (n_features, d_model) numpy array."""
    if isinstance(sae, np.ndarray):
        if sae.ndim != 2:
            raise ValueError(f"expected 2-D decoder matrix, got shape {sae.shape}")
        return sae

    if isinstance(sae, dict):
        for key in ("W_dec", "decoder_weight", "decoder.weight"):
            if key in sae:
                return _to_numpy(sae[key])
        raise KeyError(
            f"dict-shaped SAE missing decoder key; tried W_dec/decoder_weight/decoder.weight; "
            f"got keys: {sorted(sae)[:10]}"
        )

    if hasattr(sae, "W_dec"):
        return _to_numpy(sae.W_dec)

    if hasattr(sae, "decoder") and hasattr(sae.decoder, "weight"):
        # PyTorch nn.Linear: weight is (out, in) so decoder.weight has
        # shape (d_model, n_features). We transpose to match convention.
        w = _to_numpy(sae.decoder.weight)
        return w.T

    raise TypeError(
        f"object of type {type(sae).__name__} is not a recognized SAE; "
        f"pass a numpy array, dict with W_dec, or SAELens SAE instance"
    )


def load_decoder_from_path(path: str | Path) -> np.ndarray:
    """Load a decoder matrix from a .npz, .npy, or .safetensors file.

    .safetensors loading is delegated to the `safetensors` package, which we
    import lazily so the core install stays small.
    """
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"{p}")
    suffix = p.suffix.lower()
    if suffix == ".npy":
        return np.load(p)
    if suffix == ".npz":
        with np.load(p) as data:
            keys = list(data.keys())
            for k in ("W_dec", "W", "decoder_weight"):
                if k in keys:
                    return data[k].copy()
            raise KeyError(
                f"{p} contains keys {keys!r} but none of "
                "W_dec / W / decoder_weight. Refusing to guess which tensor is "
                "the decoder. Re-save with a recognised key, or load the file "
                "yourself and pass the numpy array to gavagai_score directly."
            )
    if suffix == ".safetensors":
        try:
            from safetensors.numpy import load_file
        except ImportError as e:
            raise ImportError("safetensors not installed; pip install safetensors") from e
        tensors = load_file(str(p))
        for key in ("W_dec", "decoder_weight"):
            if key in tensors:
                return tensors[key]
        raise KeyError(
            f"{p} contains keys {list(tensors)!r} but none of W_dec / decoder_weight. "
            "Refusing to guess which tensor is the decoder."
        )
    raise ValueError(f"unsupported decoder file extension {suffix}")
