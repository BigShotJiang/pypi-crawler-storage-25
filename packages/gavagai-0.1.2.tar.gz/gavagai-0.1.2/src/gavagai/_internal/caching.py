"""Lightweight on-disk caching for SAE decoder matrices.

Keyed by a content hash of the source object's identifying attributes
(name, layer, n_features, d_model). Cache files are .npz and the cache
directory defaults to ``~/.cache/gavagai``.

Status (v0.1.x): the score pipeline does **not** use this module yet — it
ships preemptively so v0.2 holism extensions can opt in without a public
API change. The key derivation does not include checkpoint content hashes,
so callers must guarantee uniqueness of ``(name, layer, n_features, d_model)``
across versions. The module is intentionally not exported from
``gavagai.__init__``.
"""

from __future__ import annotations

import hashlib
import os
from pathlib import Path

import numpy as np

_DEFAULT_CACHE = Path(os.environ.get("GAVAGAI_CACHE", str(Path.home() / ".cache" / "gavagai")))


def _cache_dir() -> Path:
    _DEFAULT_CACHE.mkdir(parents=True, exist_ok=True)
    return _DEFAULT_CACHE


def key_for(name: str, layer: int | str, n_features: int, d_model: int) -> str:
    raw = f"{name}|{layer}|{n_features}|{d_model}".encode()
    return hashlib.sha256(raw).hexdigest()[:24]


def load(cache_key: str) -> np.ndarray | None:
    path = _cache_dir() / f"{cache_key}.npz"
    if not path.exists():
        return None
    with np.load(path) as data:
        return data["W"].copy()


def store(cache_key: str, weight: np.ndarray) -> Path:
    path = _cache_dir() / f"{cache_key}.npz"
    np.savez_compressed(path, W=weight)
    return path
