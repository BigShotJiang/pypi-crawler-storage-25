"""Pure-numpy primitives used by the score pipeline.

Kept torch-free so the core package installs without GPU dependencies.
SAELens / torch enter only through `backends.saelens_adapter`.
"""

from __future__ import annotations

import numpy as np


def cosine_matrix(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Cosine similarity between rows of `a` and rows of `b`.

    Parameters
    ----------
    a : ndarray of shape (n_a, d)
    b : ndarray of shape (n_b, d)

    Returns
    -------
    ndarray of shape (n_a, n_b), values in [-1, 1].
    """
    if a.ndim != 2 or b.ndim != 2:
        raise ValueError(f"expected 2-D arrays, got shapes {a.shape} and {b.shape}")
    if a.shape[1] != b.shape[1]:
        raise ValueError(f"feature dimension mismatch: {a.shape[1]} != {b.shape[1]}")
    a_norm = np.linalg.norm(a, axis=1, keepdims=True)
    b_norm = np.linalg.norm(b, axis=1, keepdims=True)
    a_norm = np.where(a_norm == 0, 1.0, a_norm)
    b_norm = np.where(b_norm == 0, 1.0, b_norm)
    a_unit = a / a_norm
    b_unit = b / b_norm
    return a_unit @ b_unit.T


def threshold_adjacency(sim: np.ndarray, epsilon: float) -> np.ndarray:
    """Convert similarity matrix to boolean adjacency.

    Two features are considered equivalent iff (1 - cosine_sim) <= epsilon,
    i.e. cosine_sim >= 1 - epsilon. We treat the similarity as a generic
    "higher is closer" metric in [-1, 1] or [0, 1].
    """
    if not 0.0 <= epsilon <= 2.0:
        raise ValueError(f"epsilon must be in [0, 2], got {epsilon}")
    threshold = 1.0 - epsilon
    return sim >= threshold


def count_equivalent_translations(adjacency: np.ndarray, cap: int = 1000) -> int:
    """Count matchings consistent with the adjacency, capped at `cap`.

    Specifically, we count distinct injective assignments of *active* rows
    (those with at least one candidate) to columns, where each active row
    must be matched to one of its candidates and no column is used twice.

    Semantics (Quinean):
        * Empty adjacency = no observational link between the two SAEs ⇒
          radical indeterminacy (return `cap`).
        * Unique compatible assignment (e.g. identity adjacency) ⇒ return 1.
        * Many compatible assignments ⇒ return min(actual count, cap).
        * No compatible assignment (Hall's condition violated — active rows
          collectively demand more distinct columns than they share) ⇒
          return 0. Callers should treat 0 as maximal indeterminacy
          (`indeterminacy_score(0)` does so); the previous version
          incorrectly floored this to 1, claiming a deterministic
          translation where none exists.

    Algorithm: iterative DFS (explicit stack) over active rows, pruned by
    `cap` so worst-case work is bounded. Iterative form avoids Python's
    recursion limit, which matters for production SAEs with 10^4-10^5
    features.
    """
    if adjacency.size == 0:
        return cap
    if not adjacency.any():
        return cap

    deg_a = adjacency.sum(axis=1).astype(np.int64)
    active_rows = np.where(deg_a > 0)[0]
    if active_rows.size == 0:
        return cap

    n_a, n_b = adjacency.shape
    # Pivot on the smaller side to minimise the search depth. Matchings are
    # symmetric so the count is invariant under transpose.
    if n_b < active_rows.size:
        return count_equivalent_translations(adjacency.T, cap=cap)

    candidates: list[list[int]] = [np.where(adjacency[i])[0].tolist() for i in active_rows]
    n_rows = len(candidates)

    used = [False] * n_b
    chosen = [-1] * n_rows
    pos = [0] * n_rows
    depth = 0
    count = 0

    while True:
        if depth == n_rows:
            count += 1
            if count >= cap:
                return cap
            depth -= 1
            used[chosen[depth]] = False
            chosen[depth] = -1
            pos[depth] += 1
            continue

        cands = candidates[depth]
        advanced = False
        while pos[depth] < len(cands):
            j = cands[pos[depth]]
            if not used[j]:
                used[j] = True
                chosen[depth] = j
                depth += 1
                if depth < n_rows:
                    pos[depth] = 0
                advanced = True
                break
            pos[depth] += 1

        if advanced:
            continue

        depth -= 1
        if depth < 0:
            break
        used[chosen[depth]] = False
        chosen[depth] = -1
        pos[depth] += 1

    return min(count, cap)


# Score used when no compatible assignment exists (Hall failure). We pin it
# to the cap-saturation value so it sits at the top of the [0, 1) range
# without exceeding it.
_HALL_FAILURE_SCORE = 1.0 - 1.0 / (1.0 + float(np.log(1000)))


def indeterminacy_score(n_equivalent: int) -> float:
    """Compress matching count to ``[0, 1)`` via ``1 - 1/(1 + log(n))``.

    * ``n == 1`` → 0 (deterministic translation).
    * ``n ≈ e`` → ~0.5.
    * ``n → ∞`` → asymptotes at 1 from below.
    * ``n <= 0`` → returned at the cap-saturation value (~0.876 with the
      default cap of 1000), because no assignment exists and the data
      cannot pin down any single manual.
    """
    n = int(n_equivalent)
    if n <= 0:
        return _HALL_FAILURE_SCORE
    if n == 1:
        return 0.0
    return 1.0 - 1.0 / (1.0 + float(np.log(n)))


def bootstrap_score_ci(
    sim: np.ndarray,
    epsilon: float,
    n_resamples: int = 200,
    seed: int = 0,
    cap: int = 1000,
) -> tuple[float, float]:
    """Bootstrap a 95% CI for the indeterminacy score by resampling feature rows."""
    rng = np.random.default_rng(seed)
    n_a, n_b = sim.shape
    if n_a == 0 or n_b == 0:
        return (0.0, 0.0)
    scores = np.empty(n_resamples, dtype=np.float64)
    for k in range(n_resamples):
        idx_a = rng.integers(0, n_a, size=n_a)
        idx_b = rng.integers(0, n_b, size=n_b)
        sub = sim[np.ix_(idx_a, idx_b)]
        adj = threshold_adjacency(sub, epsilon)
        n_eq = count_equivalent_translations(adj, cap=cap)
        scores[k] = indeterminacy_score(n_eq)
    low = float(np.quantile(scores, 0.025))
    high = float(np.quantile(scores, 0.975))
    return low, high


def top_k_pairs(
    sim: np.ndarray, adjacency: np.ndarray, k: int = 10
) -> list[tuple[int, int, float]]:
    """Return the top-k highest-similarity candidate pairs that satisfy adjacency."""
    if sim.size == 0:
        return []
    masked = np.where(adjacency, sim, -np.inf)
    flat = masked.ravel()
    if not np.any(np.isfinite(flat)):
        return []
    k = min(k, int(np.sum(np.isfinite(flat))))
    idx = np.argpartition(-flat, k - 1)[:k]
    idx = idx[np.argsort(-flat[idx])]
    n_b = sim.shape[1]
    return [(int(i // n_b), int(i % n_b), float(flat[i])) for i in idx]
