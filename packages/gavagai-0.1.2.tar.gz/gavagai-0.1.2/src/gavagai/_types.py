"""Internal types. Not part of the public API.

`IndeterminateMap` encodes the Quine commitment: a translation between two
feature dictionaries is never a single function, but a *set* of empirically
equivalent functions (the equivalence class). The public `gavagai_score`
collapses this set to a scalar, but internally we keep the class explicit so
future versions (v0.2 holism, v0.3 commitment) can act on its structure.

v0.1 status: `IndeterminateMap` is built only via the advanced
`gavagai.score.indeterminate_map(...)` entry point; the main scoring path
operates directly on the adjacency matrix for speed. It will be moved onto
the main path in v0.2 when holism propagation lands.
"""

from __future__ import annotations

from collections.abc import Iterator
from dataclasses import dataclass, field

import numpy as np


@dataclass(frozen=True)
class IndeterminateMap:
    """An equivalence class of feature-index mappings between two SAEs.

    Attributes
    ----------
    n_a, n_b
        Sizes of the source and target feature dictionaries.
    candidate_pairs
        Boolean adjacency of shape (n_a, n_b). True at (i, j) iff feature i in
        SAE A is empirically equivalent to feature j in SAE B under the chosen
        equivalence relation.
    similarities
        Continuous-valued similarity matrix used to derive candidate_pairs.
        Shape (n_a, n_b), values in [-1, 1] or [0, 1] depending on metric.
    epsilon
        Tolerance used to threshold similarities into adjacency.
    """

    n_a: int
    n_b: int
    candidate_pairs: np.ndarray
    similarities: np.ndarray
    epsilon: float

    def degree_a(self) -> np.ndarray:
        """Out-degree of each source feature (how many B-features it matches)."""
        return self.candidate_pairs.sum(axis=1)

    def degree_b(self) -> np.ndarray:
        """In-degree of each target feature (how many A-features match it)."""
        return self.candidate_pairs.sum(axis=0)

    def is_deterministic(self) -> bool:
        """True iff every source feature has exactly one candidate target."""
        d = self.degree_a()
        return bool(np.all(d == 1)) and bool(np.all(self.degree_b() == 1))

    def total_candidate_edges(self) -> int:
        return int(self.candidate_pairs.sum())


@dataclass
class GavagaiDetails:
    """Optional rich result returned when `gavagai_score(..., return_details=True)`.

    ``coverage_a`` / ``coverage_b`` disambiguate two distinct sources of high
    indeterminacy: low coverage (the data does not link the SAEs at all) vs.
    high branching (many distinct mappings remain consistent with the data).
    ``cap_reached`` flags whether the matching count saturated the cap, in
    which case the reported score is a lower bound on the true indeterminacy.
    """

    n_equivalent_translations: int
    ci_low: float
    ci_high: float
    sample_mappings: list[tuple[int, int, float]] = field(default_factory=list)
    epsilon: float = 0.0
    equivalence: str = "cosine"
    n_a: int = 0
    n_b: int = 0
    coverage_a: float = 0.0
    coverage_b: float = 0.0
    cap_reached: bool = False

    def __iter__(self) -> Iterator[object]:
        # Allow tuple unpacking: score, details = gavagai_score(..., return_details=True)
        return iter(
            (
                self.n_equivalent_translations,
                self.ci_low,
                self.ci_high,
                self.sample_mappings,
                self.epsilon,
                self.equivalence,
                self.n_a,
                self.n_b,
                self.coverage_a,
                self.coverage_b,
                self.cap_reached,
            )
        )
