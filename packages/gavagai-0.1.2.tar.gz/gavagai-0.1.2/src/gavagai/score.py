"""Public gavagai_score entry point."""

from __future__ import annotations

from typing import Any, Literal, overload  # noqa: F401

import numpy as np

from gavagai import equivalence as eq_module
from gavagai._internal.numerics import (
    bootstrap_score_ci,
    count_equivalent_translations,
    indeterminacy_score,
    threshold_adjacency,
    top_k_pairs,
)
from gavagai._types import GavagaiDetails, IndeterminateMap
from gavagai.backends.saelens_adapter import extract_decoder

_MATCHING_CAP = 1000
_DEFAULT_EPSILON = 0.1
_DEFAULT_BOOTSTRAP = 200


@overload
def gavagai_score(
    sae_a: Any,
    sae_b: Any,
    *,
    equivalence: str = ...,
    epsilon: float = ...,
    return_details: Literal[False] = False,
    activations_a: np.ndarray | None = ...,
    activations_b: np.ndarray | None = ...,
    activation_threshold: float | str = ...,
    activation_topk: int | None = ...,
    ablation_kl: np.ndarray | None = ...,
    bootstrap_resamples: int = ...,
    seed: int = ...,
) -> float: ...


@overload
def gavagai_score(
    sae_a: Any,
    sae_b: Any,
    *,
    equivalence: str = ...,
    epsilon: float = ...,
    return_details: Literal[True],
    activations_a: np.ndarray | None = ...,
    activations_b: np.ndarray | None = ...,
    activation_threshold: float | str = ...,
    activation_topk: int | None = ...,
    ablation_kl: np.ndarray | None = ...,
    bootstrap_resamples: int = ...,
    seed: int = ...,
) -> tuple[float, GavagaiDetails]: ...


def gavagai_score(
    sae_a: Any,
    sae_b: Any,
    *,
    equivalence: str = "cosine",
    epsilon: float = _DEFAULT_EPSILON,
    return_details: bool = False,
    activations_a: np.ndarray | None = None,
    activations_b: np.ndarray | None = None,
    activation_threshold: float | str = "median",
    activation_topk: int | None = None,
    ablation_kl: np.ndarray | None = None,
    bootstrap_resamples: int = _DEFAULT_BOOTSTRAP,
    seed: int = 0,
) -> float | tuple[float, GavagaiDetails]:
    """Quantify translation indeterminacy between two SAE feature dictionaries.

    Parameters
    ----------
    sae_a, sae_b
        SAE objects. Accepted forms: SAELens `SAE` instance, dict with
        `W_dec` key, object with `.decoder.weight`, or numpy decoder matrix
        of shape (n_features, d_model).
    equivalence
        Which equivalence relation to use: "cosine" (default), "activation",
        or "behavior". See `gavagai.equivalence` for semantics.
    epsilon
        Tolerance: two features are equivalent iff similarity >= 1 - epsilon.
        Smaller epsilon → stricter → fewer equivalences → lower score.
    return_details
        If True, returns (score, GavagaiDetails) for diagnostics.
    activations_a, activations_b
        Required when equivalence="activation". Shape (n_tokens, n_features_*).
    ablation_kl
        Required when equivalence="behavior". Shape (n_features_a, n_features_b).
    bootstrap_resamples
        Number of bootstrap resamples for CI. Set to 0 to skip CI computation.
    seed
        Random seed for bootstrap reproducibility.

    Returns
    -------
    float in [0, 1):
        0 → deterministic translation (single bijection consistent with the data).
        Approaches 1 as the matching count grows; saturates at
        ``1 - 1/(1 + log(cap))`` ≈ 0.876 with the default cap of 1000. Use
        ``return_details=True`` and inspect ``cap_reached`` to detect saturation.
    """
    decoder_a = extract_decoder(sae_a)
    decoder_b = extract_decoder(sae_b)

    if decoder_a.shape[1] != decoder_b.shape[1]:
        raise ValueError(
            f"decoder d_model mismatch: {decoder_a.shape[1]} vs {decoder_b.shape[1]}; "
            f"gavagai_score compares SAEs trained on aligned residual streams."
        )

    relation = eq_module.get(equivalence)

    # Some relations need extra kwargs; pass them only if the relation accepts them.
    kwargs: dict[str, Any] = {}
    if equivalence == "activation":
        kwargs["activations_a"] = activations_a
        kwargs["activations_b"] = activations_b
        kwargs["activation_threshold"] = activation_threshold
        kwargs["activation_topk"] = activation_topk
    elif equivalence == "behavior":
        kwargs["ablation_kl"] = ablation_kl

    sim = relation.similarity(decoder_a, decoder_b, **kwargs)
    adjacency = threshold_adjacency(sim, epsilon)
    n_equiv = count_equivalent_translations(adjacency, cap=_MATCHING_CAP)
    score = indeterminacy_score(n_equiv)

    if not return_details:
        return score

    if bootstrap_resamples > 0:
        ci_low, ci_high = bootstrap_score_ci(
            sim, epsilon, n_resamples=bootstrap_resamples, seed=seed, cap=_MATCHING_CAP
        )
    else:
        ci_low = ci_high = score

    cov_a = float((adjacency.sum(axis=1) > 0).mean()) if adjacency.size else 0.0
    cov_b = float((adjacency.sum(axis=0) > 0).mean()) if adjacency.size else 0.0
    details = GavagaiDetails(
        n_equivalent_translations=n_equiv,
        ci_low=ci_low,
        ci_high=ci_high,
        sample_mappings=top_k_pairs(sim, adjacency, k=10),
        epsilon=epsilon,
        equivalence=equivalence,
        n_a=decoder_a.shape[0],
        n_b=decoder_b.shape[0],
        coverage_a=cov_a,
        coverage_b=cov_b,
        cap_reached=(n_equiv >= _MATCHING_CAP),
    )
    return score, details


def _indeterminate_map(
    sae_a: Any,
    sae_b: Any,
    *,
    equivalence: str = "cosine",
    epsilon: float = _DEFAULT_EPSILON,
    activations_a: np.ndarray | None = None,
    activations_b: np.ndarray | None = None,
    activation_threshold: float | str = "median",
    activation_topk: int | None = None,
    ablation_kl: np.ndarray | None = None,
) -> IndeterminateMap:
    """Return the full IndeterminateMap. Internal; exposed without underscore
    prefix removed for v0.2 stability when holism propagation lands."""
    decoder_a = extract_decoder(sae_a)
    decoder_b = extract_decoder(sae_b)
    relation = eq_module.get(equivalence)
    kwargs: dict[str, Any] = {}
    if equivalence == "activation":
        kwargs["activations_a"] = activations_a
        kwargs["activations_b"] = activations_b
        kwargs["activation_threshold"] = activation_threshold
        kwargs["activation_topk"] = activation_topk
    elif equivalence == "behavior":
        kwargs["ablation_kl"] = ablation_kl
    sim = relation.similarity(decoder_a, decoder_b, **kwargs)
    adjacency = threshold_adjacency(sim, epsilon)
    return IndeterminateMap(
        n_a=decoder_a.shape[0],
        n_b=decoder_b.shape[0],
        candidate_pairs=adjacency,
        similarities=sim,
        epsilon=epsilon,
    )


# Backwards-compat alias for any out-of-tree code that imported the v0.1.0/v0.1.1 name.
indeterminate_map = _indeterminate_map
