"""CI-side glue: CLI lint and GitHub Action entry point."""

from gavagai.ci.lint import main

__all__ = ["main"]
