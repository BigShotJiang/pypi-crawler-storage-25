"""`gavagai-lint` CLI: gate model-mutating commits by translation indeterminacy.

Typical use is in CI on a Hugging Face push, abliteration patch, or
fine-tuning step: load the SAE encodings of `before` and `after` and refuse
to merge if the indeterminacy score crosses a threshold.

Exit codes:
    0 : score < threshold (acceptable indeterminacy)
    1 : score >= threshold (rejection)
    2 : usage / load error
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from gavagai._types import GavagaiDetails  # noqa: F401
from gavagai.backends.saelens_adapter import load_decoder_from_path
from gavagai.score import gavagai_score


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="gavagai-lint",
        description=(
            "Reject commits whose translation indeterminacy between two SAE "
            "encodings exceeds a threshold. Designed for use in CI gates "
            "before model uploads or abliteration releases."
        ),
    )
    p.add_argument(
        "--before",
        required=True,
        help="Path to the baseline decoder (.npy, .npz, or .safetensors).",
    )
    p.add_argument(
        "--after",
        required=True,
        help="Path to the new decoder.",
    )
    p.add_argument(
        "--threshold",
        type=float,
        default=0.5,
        help="Maximum allowed indeterminacy score (default: 0.5).",
    )
    p.add_argument(
        "--epsilon",
        type=float,
        default=0.1,
        help="Equivalence tolerance (default: 0.1).",
    )
    p.add_argument(
        "--equivalence",
        choices=["cosine", "activation", "behavior"],
        default="cosine",
        help="Equivalence relation (default: cosine).",
    )
    p.add_argument(
        "--json",
        dest="emit_json",
        action="store_true",
        help="Emit a machine-readable JSON report on stdout.",
    )
    p.add_argument(
        "--quiet",
        action="store_true",
        help="Suppress human-readable output.",
    )
    return p


def _emit_text(score: float, details: GavagaiDetails, threshold: float, passed: bool) -> None:
    verdict = "PASS" if passed else "FAIL"
    print(f"gavagai-lint: {verdict}")
    print(f"  score    : {score:.4f}")
    print(f"  threshold: {threshold:.4f}")
    print(f"  n_equivalent_translations: {details.n_equivalent_translations}")
    print(f"  95% CI   : [{details.ci_low:.4f}, {details.ci_high:.4f}]")
    print(f"  coverage : a={details.coverage_a:.3f}, b={details.coverage_b:.3f}")
    if details.cap_reached:
        print("  note     : matching count saturated cap (score is a lower bound)")


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    before_path = Path(args.before)
    after_path = Path(args.after)
    try:
        decoder_before = load_decoder_from_path(before_path)
        decoder_after = load_decoder_from_path(after_path)
    except (FileNotFoundError, ValueError, ImportError) as e:
        print(f"gavagai-lint: load error: {e}", file=sys.stderr)
        return 2

    result = gavagai_score(
        decoder_before,
        decoder_after,
        equivalence=args.equivalence,
        epsilon=args.epsilon,
        return_details=True,
    )
    assert isinstance(result, tuple)
    score, details = result

    passed = score < args.threshold

    if args.emit_json:
        report = {
            "score": score,
            "threshold": args.threshold,
            "passed": passed,
            "epsilon": args.epsilon,
            "equivalence": args.equivalence,
            "n_equivalent_translations": details.n_equivalent_translations,
            "ci_low": details.ci_low,
            "ci_high": details.ci_high,
            "coverage_a": details.coverage_a,
            "coverage_b": details.coverage_b,
            "cap_reached": details.cap_reached,
            "before": str(before_path),
            "after": str(after_path),
        }
        print(json.dumps(report, indent=2))
    elif not args.quiet:
        _emit_text(score, details, args.threshold, passed)

    return 0 if passed else 1


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
