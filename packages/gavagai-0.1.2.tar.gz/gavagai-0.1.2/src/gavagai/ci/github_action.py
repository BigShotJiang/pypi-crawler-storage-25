"""GitHub Action shim that wraps `gavagai-lint` and emits step-summary output.

The composite action in `.github/actions/gavagai/action.yml` calls this
module so the action body stays declarative.
"""

from __future__ import annotations

import os
from pathlib import Path

from gavagai.ci.lint import main as lint_main


def main(argv: list[str] | None = None) -> int:
    exit_code = lint_main(argv)
    summary_path = os.environ.get("GITHUB_STEP_SUMMARY")
    if summary_path:
        verdict = "✅ PASS" if exit_code == 0 else "❌ FAIL"
        Path(summary_path).write_text(
            f"## gavagai-lint\n\n{verdict} (exit {exit_code})\n",
            encoding="utf-8",
        )
    return exit_code


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
