"""Cosine equivalence on decoder rows.

Default relation. Cheap, model-free, and corresponds to the SAE literature's
standard "feature similarity" definition (decoder direction overlap).
"""

from __future__ import annotations

import numpy as np

from gavagai._internal.numerics import cosine_matrix


class CosineEquivalence:
    name = "cosine"

    def similarity(
        self,
        decoder_a: np.ndarray,
        decoder_b: np.ndarray,
        *,
        activations_a: np.ndarray | None = None,
        activations_b: np.ndarray | None = None,
    ) -> np.ndarray:
        return cosine_matrix(decoder_a, decoder_b)
