"""Activation-overlap equivalence.

Two features count as equivalent if they fire on overlapping token sets
across a fixed input batch. This is the empirical Quinean stimulus-meaning
analog: same response profile under the same stimuli.

A naive ``activations > 0`` binarisation collapses to Jaccard ≡ 1 on dense
post-ReLU outputs (every token fires every feature, weakly), which silently
destroys the relation. We therefore require an explicit ``activation_threshold``
strategy: a scalar threshold, the literal string ``"median"`` (per-feature
median, which works for SAE pre-sparsity activations), or the string
``"topk"`` paired with ``activation_topk`` (keep the top-k tokens per
feature). Default is ``"median"``.
"""

from __future__ import annotations

import numpy as np


def _binarise(
    acts: np.ndarray,
    threshold: float | str,
    topk: int | None,
) -> np.ndarray:
    if isinstance(threshold, str):
        if threshold == "median":
            # Per-feature median; "fires" iff activation strictly above it.
            med = np.median(acts, axis=0, keepdims=True)
            return (acts > med).astype(np.float64)
        if threshold == "topk":
            if topk is None or topk <= 0:
                raise ValueError("activation_threshold='topk' requires activation_topk > 0")
            k = min(int(topk), acts.shape[0])
            # Keep the top-k tokens per feature.
            mask = np.zeros_like(acts, dtype=np.float64)
            idx = np.argpartition(-acts, kth=k - 1, axis=0)[:k, :]
            cols = np.arange(acts.shape[1])
            mask[idx, cols] = 1.0
            return mask
        raise ValueError(
            f"activation_threshold string must be 'median' or 'topk', got {threshold!r}"
        )
    return (acts > float(threshold)).astype(np.float64)


class ActivationEquivalence:
    name = "activation"

    def similarity(
        self,
        decoder_a: np.ndarray,
        decoder_b: np.ndarray,
        *,
        activations_a: np.ndarray | None = None,
        activations_b: np.ndarray | None = None,
        activation_threshold: float | str = "median",
        activation_topk: int | None = None,
    ) -> np.ndarray:
        if activations_a is None or activations_b is None:
            raise ValueError(
                "ActivationEquivalence requires both activations_a and activations_b; "
                "pass them via gavagai_score(..., activations_a=..., activations_b=...)"
            )
        fires_a = _binarise(activations_a, activation_threshold, activation_topk)
        fires_b = _binarise(activations_b, activation_threshold, activation_topk)
        if fires_a.shape[0] != fires_b.shape[0]:
            raise ValueError(
                f"activation token count mismatch: {fires_a.shape[0]} vs {fires_b.shape[0]}"
            )
        # Jaccard similarity per feature pair.
        inter = fires_a.T @ fires_b
        sums_a = fires_a.sum(axis=0)[:, None]
        sums_b = fires_b.sum(axis=0)[None, :]
        union = sums_a + sums_b - inter
        union = np.where(union == 0, 1.0, union)
        return inter / union
