"""Protocol for equivalence relations."""

from __future__ import annotations

from typing import Protocol

import numpy as np


class EquivalenceRelation(Protocol):
    """A way to decide whether two features count as the same.

    Implementations must produce a similarity matrix in [-1, 1] or [0, 1]
    where larger means "more equivalent". The actual ε-thresholding is done
    by `_internal.numerics.threshold_adjacency`, so implementations only
    need to return the raw similarity.
    """

    name: str

    def similarity(
        self,
        decoder_a: np.ndarray,
        decoder_b: np.ndarray,
        *,
        activations_a: np.ndarray | None = None,
        activations_b: np.ndarray | None = None,
    ) -> np.ndarray:
        """Return shape (n_features_a, n_features_b) similarity."""
        ...
