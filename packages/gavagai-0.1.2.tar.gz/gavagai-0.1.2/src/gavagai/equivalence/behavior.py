"""Behavior equivalence — downstream-KL distance between ablations.

For each feature pair (i, j), we approximate equivalence by the inverse
distance between the model's output distribution after zero-ablating feature
i of SAE A vs feature j of SAE B. v0.1 ships a *placeholder* numpy
implementation that uses the supplied `ablation_kl` matrix directly, so the
core package stays torch-free. Real torch-driven ablation is shipped in
`gavagai[behavior]` extras in a follow-up (v0.1.x).
"""

from __future__ import annotations

import numpy as np


class BehaviorEquivalence:
    name = "behavior"

    def similarity(
        self,
        decoder_a: np.ndarray,
        decoder_b: np.ndarray,
        *,
        activations_a: np.ndarray | None = None,
        activations_b: np.ndarray | None = None,
        ablation_kl: np.ndarray | None = None,
    ) -> np.ndarray:
        if ablation_kl is None:
            raise ValueError(
                "BehaviorEquivalence requires a precomputed ablation_kl matrix "
                "of shape (n_features_a, n_features_b). v0.1 does not run "
                "ablation internally; compute it with sae-lens / TransformerLens "
                "and pass it via gavagai_score(..., ablation_kl=...)."
            )
        kl = np.asarray(ablation_kl, dtype=np.float64)
        if not np.isfinite(kl).all():
            raise ValueError("ablation_kl contains non-finite entries (nan/inf)")
        # KL is non-negative; clip floating noise that may dip below 0 so the
        # conversion to similarity stays in (0, 1].
        kl = np.clip(kl, 0.0, None)
        return 1.0 / (1.0 + kl)
