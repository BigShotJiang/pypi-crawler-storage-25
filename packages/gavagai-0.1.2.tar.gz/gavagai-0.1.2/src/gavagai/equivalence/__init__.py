"""Equivalence relations between SAE features.

Each relation answers: "are these two features the same up to ε?"
The Quine-style point is that the answer depends on the relation chosen,
and gavagai never hides which relation produced the score.
"""

from gavagai.equivalence.activation import ActivationEquivalence
from gavagai.equivalence.base import EquivalenceRelation
from gavagai.equivalence.behavior import BehaviorEquivalence
from gavagai.equivalence.cosine import CosineEquivalence

_REGISTRY: dict[str, type[EquivalenceRelation]] = {
    "cosine": CosineEquivalence,
    "activation": ActivationEquivalence,
    "behavior": BehaviorEquivalence,
}


def get(name: str) -> EquivalenceRelation:
    """Return an EquivalenceRelation instance by name."""
    try:
        cls = _REGISTRY[name]
    except KeyError as e:
        raise ValueError(
            f"unknown equivalence relation {name!r}; available: {sorted(_REGISTRY)}"
        ) from e
    return cls()


__all__ = [
    "EquivalenceRelation",
    "CosineEquivalence",
    "ActivationEquivalence",
    "BehaviorEquivalence",
    "get",
]
