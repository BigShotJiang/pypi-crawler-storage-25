"""gavagai — translation indeterminacy for SAE features.

Public surface is intentionally narrow. Internal types are not re-exported.
"""

from gavagai._version import __version__
from gavagai.score import GavagaiDetails, gavagai_score

__all__ = ["__version__", "gavagai_score", "GavagaiDetails"]
