"""CLI smoke tests for gavagai-lint."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pytest

from gavagai.ci.lint import main as lint_main
from tests.fixtures import random_decoder, shifted_decoder


@pytest.fixture
def decoder_files(tmp_path: Path) -> tuple[Path, Path]:
    before = tmp_path / "before.npz"
    after = tmp_path / "after.npz"
    w = random_decoder(10, 16, seed=0)
    w2 = shifted_decoder(w, noise=0.001, seed=1)
    np.savez(before, W_dec=w)
    np.savez(after, W_dec=w2)
    return before, after


class TestCLI:
    def test_pass_low_score(self, decoder_files: tuple[Path, Path]) -> None:
        before, after = decoder_files
        rc = lint_main(
            ["--before", str(before), "--after", str(after), "--threshold", "0.5", "--quiet"]
        )
        assert rc == 0

    def test_fail_high_score(self, tmp_path: Path) -> None:
        before = tmp_path / "before.npz"
        after = tmp_path / "after.npz"
        np.savez(before, W_dec=random_decoder(10, 16, seed=2))
        np.savez(after, W_dec=random_decoder(10, 16, seed=3))
        rc = lint_main(
            [
                "--before",
                str(before),
                "--after",
                str(after),
                "--threshold",
                "0.1",
                "--epsilon",
                "0.3",
                "--quiet",
            ]
        )
        assert rc == 1

    def test_json_output(
        self, decoder_files: tuple[Path, Path], capsys: pytest.CaptureFixture[str]
    ) -> None:
        before, after = decoder_files
        lint_main(
            [
                "--before",
                str(before),
                "--after",
                str(after),
                "--threshold",
                "0.5",
                "--json",
            ]
        )
        out = capsys.readouterr().out
        payload = json.loads(out)
        assert "score" in payload
        assert "passed" in payload
        assert payload["before"] == str(before)

    def test_missing_file_returns_2(self) -> None:
        rc = lint_main(["--before", "/no/such.npz", "--after", "/no/such.npz", "--quiet"])
        assert rc == 2

    def test_unknown_relation_via_choices(self, decoder_files: tuple[Path, Path]) -> None:
        before, after = decoder_files
        with pytest.raises(SystemExit):
            lint_main(
                [
                    "--before",
                    str(before),
                    "--after",
                    str(after),
                    "--equivalence",
                    "banana",
                ]
            )
