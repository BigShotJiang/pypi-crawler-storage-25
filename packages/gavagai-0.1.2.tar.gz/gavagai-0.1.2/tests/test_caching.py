"""Tests for `_internal.caching`."""

from __future__ import annotations

from pathlib import Path

import numpy as np

from gavagai._internal import caching


def test_key_for_is_stable() -> None:
    k1 = caching.key_for("gemma-2-2b", 12, 16384, 2304)
    k2 = caching.key_for("gemma-2-2b", 12, 16384, 2304)
    assert k1 == k2


def test_key_for_changes_on_different_input() -> None:
    k1 = caching.key_for("gemma-2-2b", 12, 16384, 2304)
    k2 = caching.key_for("gemma-2-2b", 13, 16384, 2304)
    assert k1 != k2


def test_store_and_load_roundtrip(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setattr(caching, "_DEFAULT_CACHE", tmp_path)
    w = np.random.default_rng(0).standard_normal((4, 8))
    key = caching.key_for("test", 0, 4, 8)
    assert caching.load(key) is None
    caching.store(key, w)
    loaded = caching.load(key)
    np.testing.assert_array_equal(loaded, w)


def test_cache_dir_env_var(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setattr(caching, "_DEFAULT_CACHE", tmp_path / "custom")
    key = caching.key_for("env", 0, 4, 8)
    w = np.zeros((2, 2))
    path = caching.store(key, w)
    assert path.parent == tmp_path / "custom"
