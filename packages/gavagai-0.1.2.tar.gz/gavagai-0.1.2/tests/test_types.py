"""Tests for internal types."""

from __future__ import annotations

import numpy as np

from gavagai._types import GavagaiDetails, IndeterminateMap


class TestIndeterminateMap:
    def _make(self, adjacency: np.ndarray) -> IndeterminateMap:
        return IndeterminateMap(
            n_a=adjacency.shape[0],
            n_b=adjacency.shape[1],
            candidate_pairs=adjacency,
            similarities=adjacency.astype(np.float64),
            epsilon=0.1,
        )

    def test_is_deterministic_identity(self) -> None:
        assert self._make(np.eye(5, dtype=bool)).is_deterministic()

    def test_not_deterministic_when_extra_edges(self) -> None:
        a = np.eye(5, dtype=bool)
        a[0, 1] = True
        assert not self._make(a).is_deterministic()

    def test_degree_counts(self) -> None:
        adj = np.array([[True, True], [False, True]])
        im = self._make(adj)
        assert list(im.degree_a()) == [2, 1]
        assert list(im.degree_b()) == [1, 2]

    def test_total_candidate_edges(self) -> None:
        adj = np.ones((4, 5), dtype=bool)
        assert self._make(adj).total_candidate_edges() == 20


class TestGavagaiDetails:
    def test_default_init(self) -> None:
        d = GavagaiDetails(n_equivalent_translations=3, ci_low=0.1, ci_high=0.5)
        assert d.n_equivalent_translations == 3
        assert d.sample_mappings == []
        assert d.epsilon == 0.0

    def test_tuple_unpacking(self) -> None:
        d = GavagaiDetails(
            n_equivalent_translations=5,
            ci_low=0.2,
            ci_high=0.7,
            sample_mappings=[(0, 1, 0.9)],
            epsilon=0.1,
            equivalence="cosine",
            n_a=10,
            n_b=10,
        )
        n_eq, lo, hi, mappings, eps, equiv, n_a, n_b, cov_a, cov_b, capped = d
        assert n_eq == 5
        assert lo == 0.2
        assert hi == 0.7
        assert mappings == [(0, 1, 0.9)]
        assert equiv == "cosine"
        assert cov_a == 0.0
        assert cov_b == 0.0
        assert capped is False
