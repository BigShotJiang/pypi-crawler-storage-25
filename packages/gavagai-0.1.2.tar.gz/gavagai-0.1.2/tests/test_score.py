"""Tests for the public gavagai_score API."""

from __future__ import annotations

import numpy as np
import pytest

from gavagai import GavagaiDetails, gavagai_score
from gavagai.score import indeterminate_map
from tests.fixtures import MockSAE, permuted_decoder, random_decoder, shifted_decoder


class TestIdentityCase:
    def test_score_self_is_zero(self) -> None:
        w = random_decoder(20, 32, seed=1)
        assert gavagai_score(w, w) == 0.0

    def test_mock_sae_self_is_zero(self) -> None:
        w = random_decoder(15, 24)
        assert gavagai_score(MockSAE(W_dec=w), MockSAE(W_dec=w)) == 0.0

    def test_dict_form_self_is_zero(self) -> None:
        w = random_decoder(10, 16)
        assert gavagai_score({"W_dec": w}, {"W_dec": w}) == 0.0


class TestNearIdenticalCase:
    def test_small_noise_keeps_score_low(self) -> None:
        w = random_decoder(20, 32, seed=2)
        w2 = shifted_decoder(w, noise=0.005, seed=3)
        s = gavagai_score(w, w2, epsilon=0.05)
        assert s < 0.3, f"small noise should yield small indeterminacy, got {s}"


class TestPermutationInvariance:
    def test_permuted_score_low(self) -> None:
        w = random_decoder(15, 32, seed=4)
        w_perm, _ = permuted_decoder(w, seed=5)
        s = gavagai_score(w, w_perm, epsilon=0.05)
        assert s < 0.3, f"pure permutation should be near deterministic, got {s}"


class TestRandomCase:
    def test_random_decoders_high_indeterminacy(self) -> None:
        a = random_decoder(15, 32, seed=10)
        b = random_decoder(15, 32, seed=11)
        s = gavagai_score(a, b, epsilon=0.3)
        # Independent random decoders should produce high indeterminacy.
        assert s > 0.5


class TestReturnDetails:
    def test_returns_dataclass(self) -> None:
        w = random_decoder(10, 16, seed=20)
        score, details = gavagai_score(w, w, return_details=True, bootstrap_resamples=20)
        assert isinstance(details, GavagaiDetails)
        assert details.n_a == 10
        assert details.n_b == 10
        assert details.epsilon == 0.1
        assert details.equivalence == "cosine"

    def test_details_unpack_as_iterable(self) -> None:
        w = random_decoder(8, 16, seed=21)
        score, details = gavagai_score(w, w, return_details=True, bootstrap_resamples=10)
        items = list(details)
        assert len(items) == 11

    def test_coverage_and_cap_flag(self) -> None:
        w = random_decoder(8, 16, seed=25)
        score, details = gavagai_score(w, w, return_details=True, bootstrap_resamples=0)
        assert 0.0 <= details.coverage_a <= 1.0
        assert 0.0 <= details.coverage_b <= 1.0
        assert details.cap_reached is False  # self-comparison ⇒ deterministic

    def test_ci_bounds_score(self) -> None:
        a = random_decoder(10, 16, seed=22)
        b = random_decoder(10, 16, seed=23)
        score, details = gavagai_score(
            a, b, return_details=True, bootstrap_resamples=30, epsilon=0.3
        )
        assert 0.0 <= details.ci_low <= details.ci_high <= 1.0

    def test_bootstrap_zero_skips(self) -> None:
        w = random_decoder(5, 8, seed=24)
        score, details = gavagai_score(w, w, return_details=True, bootstrap_resamples=0)
        assert details.ci_low == score
        assert details.ci_high == score


class TestEquivalenceRelations:
    def test_unknown_relation_raises(self) -> None:
        w = random_decoder(5, 8)
        with pytest.raises(ValueError, match="unknown equivalence"):
            gavagai_score(w, w, equivalence="banana")

    def test_activation_requires_activations(self) -> None:
        w = random_decoder(5, 8)
        with pytest.raises(ValueError, match="activations"):
            gavagai_score(w, w, equivalence="activation")

    def test_behavior_requires_ablation_kl(self) -> None:
        w = random_decoder(5, 8)
        with pytest.raises(ValueError, match="ablation_kl"):
            gavagai_score(w, w, equivalence="behavior")

    def test_activation_with_inputs(self) -> None:
        rng = np.random.default_rng(0)
        w_a = random_decoder(6, 8, seed=30)
        w_b = random_decoder(6, 8, seed=31)
        acts_a = rng.uniform(-1, 1, size=(100, 6))
        # Same activation pattern → near-deterministic
        score = gavagai_score(
            w_a,
            w_b,
            equivalence="activation",
            activations_a=acts_a,
            activations_b=acts_a,
            epsilon=0.05,
        )
        assert score < 0.3

    def test_behavior_with_ablation(self) -> None:
        w = random_decoder(5, 8, seed=33)
        # KL matrix near-diagonal-zero → most similar
        kl = np.full((5, 5), 10.0)
        np.fill_diagonal(kl, 0.0)
        score = gavagai_score(w, w, equivalence="behavior", ablation_kl=kl, epsilon=0.5)
        assert score == 0.0


class TestDimMismatch:
    def test_d_model_mismatch_raises(self) -> None:
        a = random_decoder(5, 8)
        b = random_decoder(5, 16)
        with pytest.raises(ValueError, match="d_model mismatch"):
            gavagai_score(a, b)


class TestIndeterminateMap:
    def test_returns_indeterminate_map(self) -> None:
        w = random_decoder(8, 16, seed=40)
        im = indeterminate_map(w, w)
        assert im.n_a == 8
        assert im.n_b == 8
        assert im.is_deterministic()
        assert im.total_candidate_edges() == 8

    def test_degrees(self) -> None:
        w = random_decoder(6, 8, seed=41)
        im = indeterminate_map(w, w)
        assert im.degree_a().sum() == im.degree_b().sum()


class TestEpsilonEffect:
    def test_larger_epsilon_yields_higher_score(self) -> None:
        a = random_decoder(10, 16, seed=50)
        b = random_decoder(10, 16, seed=51)
        s_tight = gavagai_score(a, b, epsilon=0.05)
        s_loose = gavagai_score(a, b, epsilon=1.0)
        assert s_loose >= s_tight
