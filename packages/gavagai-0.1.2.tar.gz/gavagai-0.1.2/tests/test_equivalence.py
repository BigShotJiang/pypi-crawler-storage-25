"""Equivalence relation tests."""

from __future__ import annotations

import numpy as np
import pytest

from gavagai.equivalence import (
    ActivationEquivalence,
    BehaviorEquivalence,
    CosineEquivalence,
    get,
)
from tests.fixtures import random_decoder


class TestRegistry:
    def test_get_cosine(self) -> None:
        assert isinstance(get("cosine"), CosineEquivalence)

    def test_get_activation(self) -> None:
        assert isinstance(get("activation"), ActivationEquivalence)

    def test_get_behavior(self) -> None:
        assert isinstance(get("behavior"), BehaviorEquivalence)

    def test_get_unknown(self) -> None:
        with pytest.raises(ValueError, match="unknown"):
            get("phlogiston")


class TestCosineEquivalence:
    def test_self_similarity_one_on_diagonal(self) -> None:
        w = random_decoder(5, 8, seed=0)
        sim = CosineEquivalence().similarity(w, w)
        np.testing.assert_allclose(np.diag(sim), 1.0)

    def test_shape(self) -> None:
        a = random_decoder(7, 16)
        b = random_decoder(11, 16)
        sim = CosineEquivalence().similarity(a, b)
        assert sim.shape == (7, 11)


class TestActivationEquivalence:
    def test_requires_activations(self) -> None:
        w = random_decoder(3, 4)
        with pytest.raises(ValueError, match="activations"):
            ActivationEquivalence().similarity(w, w)

    def test_jaccard_basic(self) -> None:
        a = np.array([[1.0, 0.0], [0.0, 1.0]])
        b = np.array([[1.0, 0.0], [0.0, 1.0]])
        sim = ActivationEquivalence().similarity(
            np.zeros((2, 1)),
            np.zeros((2, 1)),
            activations_a=a,
            activations_b=b,
        )
        # Diagonal should be 1.0 (perfect overlap).
        np.testing.assert_allclose(np.diag(sim), 1.0)

    def test_token_count_mismatch(self) -> None:
        a = np.zeros((10, 3))
        b = np.zeros((5, 3))
        with pytest.raises(ValueError, match="token count mismatch"):
            ActivationEquivalence().similarity(
                np.zeros((3, 4)),
                np.zeros((3, 4)),
                activations_a=a,
                activations_b=b,
            )

    def test_dense_post_relu_not_degenerate(self) -> None:
        # Regression: dense uniform-positive activations used to collapse to
        # Jaccard ≡ 1 under the old `>0` binarisation. With the new median
        # threshold the relation must distinguish off-diagonal pairs.
        rng = np.random.default_rng(0)
        acts = rng.uniform(0.01, 1.0, size=(200, 8))
        sim = ActivationEquivalence().similarity(
            np.zeros((8, 1)),
            np.zeros((8, 1)),
            activations_a=acts,
            activations_b=acts,
        )
        np.testing.assert_allclose(np.diag(sim), 1.0)
        off_diag = sim - np.diag(np.diag(sim))
        assert off_diag.max() < 1.0, "off-diagonal must not collapse to 1"

    def test_topk_threshold_strategy(self) -> None:
        rng = np.random.default_rng(1)
        acts = rng.uniform(0.0, 1.0, size=(50, 4))
        sim = ActivationEquivalence().similarity(
            np.zeros((4, 1)),
            np.zeros((4, 1)),
            activations_a=acts,
            activations_b=acts,
            activation_threshold="topk",
            activation_topk=5,
        )
        np.testing.assert_allclose(np.diag(sim), 1.0)

    def test_topk_requires_k(self) -> None:
        with pytest.raises(ValueError, match="activation_topk"):
            ActivationEquivalence().similarity(
                np.zeros((2, 1)),
                np.zeros((2, 1)),
                activations_a=np.eye(2),
                activations_b=np.eye(2),
                activation_threshold="topk",
            )


class TestBehaviorEquivalence:
    def test_requires_ablation_kl(self) -> None:
        w = random_decoder(3, 4)
        with pytest.raises(ValueError, match="ablation_kl"):
            BehaviorEquivalence().similarity(w, w)

    def test_zero_kl_yields_one(self) -> None:
        kl = np.zeros((2, 2))
        sim = BehaviorEquivalence().similarity(np.zeros((2, 1)), np.zeros((2, 1)), ablation_kl=kl)
        np.testing.assert_allclose(sim, 1.0)

    def test_negative_kl_clipped(self) -> None:
        # Regression: floating noise may produce tiny negative KL estimates.
        # The old `1/(1+kl)` produced inf; we now clip to ≥0 first.
        kl = np.array([[-1e-9, 0.0], [0.0, -1e-9]])
        sim = BehaviorEquivalence().similarity(np.zeros((2, 1)), np.zeros((2, 1)), ablation_kl=kl)
        assert np.isfinite(sim).all()
        np.testing.assert_allclose(sim, 1.0)

    def test_non_finite_kl_rejected(self) -> None:
        kl = np.array([[0.0, np.nan], [0.0, 0.0]])
        with pytest.raises(ValueError, match="non-finite"):
            BehaviorEquivalence().similarity(np.zeros((2, 1)), np.zeros((2, 1)), ablation_kl=kl)
