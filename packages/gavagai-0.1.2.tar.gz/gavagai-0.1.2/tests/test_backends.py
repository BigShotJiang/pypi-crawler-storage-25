"""Backend adapter tests."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pytest

from gavagai.backends.saelens_adapter import extract_decoder, load_decoder_from_path
from tests.fixtures import MockSAE, random_decoder


class TestExtractDecoder:
    def test_numpy_passthrough(self) -> None:
        w = random_decoder(5, 8)
        assert extract_decoder(w) is w

    def test_mock_sae_w_dec(self) -> None:
        w = random_decoder(5, 8)
        out = extract_decoder(MockSAE(W_dec=w))
        np.testing.assert_array_equal(out, w)

    def test_dict_w_dec(self) -> None:
        w = random_decoder(5, 8)
        out = extract_decoder({"W_dec": w})
        np.testing.assert_array_equal(out, w)

    def test_dict_decoder_weight(self) -> None:
        w = random_decoder(5, 8)
        out = extract_decoder({"decoder_weight": w})
        np.testing.assert_array_equal(out, w)

    def test_dict_missing_key(self) -> None:
        with pytest.raises(KeyError, match="W_dec"):
            extract_decoder({"banana": np.zeros((3, 4))})

    def test_decoder_weight_transposed(self) -> None:
        # nn.Linear convention: weight shape (out, in)
        class Decoder:
            weight = np.arange(24, dtype=np.float64).reshape(8, 3)

        class Box:
            decoder = Decoder()

        out = extract_decoder(Box())
        assert out.shape == (3, 8)

    def test_unknown_type(self) -> None:
        with pytest.raises(TypeError, match="not a recognized SAE"):
            extract_decoder("a string is not an SAE")

    def test_1d_numpy_rejected(self) -> None:
        with pytest.raises(ValueError, match="2-D"):
            extract_decoder(np.zeros(5))


class TestLoadDecoderFromPath:
    def test_npz_with_w_dec(self, tmp_path: Path) -> None:
        w = random_decoder(4, 6)
        p = tmp_path / "sae.npz"
        np.savez(p, W_dec=w)
        out = load_decoder_from_path(p)
        np.testing.assert_array_equal(out, w)

    def test_npz_with_w(self, tmp_path: Path) -> None:
        w = random_decoder(4, 6)
        p = tmp_path / "sae.npz"
        np.savez(p, W=w)
        out = load_decoder_from_path(p)
        np.testing.assert_array_equal(out, w)

    def test_npy(self, tmp_path: Path) -> None:
        w = random_decoder(4, 6)
        p = tmp_path / "sae.npy"
        np.save(p, w)
        out = load_decoder_from_path(p)
        np.testing.assert_array_equal(out, w)

    def test_missing_file(self) -> None:
        with pytest.raises(FileNotFoundError):
            load_decoder_from_path("/no/such/path.npy")

    def test_unsupported_extension(self, tmp_path: Path) -> None:
        p = tmp_path / "sae.txt"
        p.write_text("not a tensor")
        with pytest.raises(ValueError, match="unsupported"):
            load_decoder_from_path(p)
