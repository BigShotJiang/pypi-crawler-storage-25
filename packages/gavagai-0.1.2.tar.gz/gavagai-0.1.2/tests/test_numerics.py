"""Unit tests for `_internal.numerics`."""

from __future__ import annotations

import numpy as np
import pytest

from gavagai._internal.numerics import (
    bootstrap_score_ci,
    cosine_matrix,
    count_equivalent_translations,
    indeterminacy_score,
    threshold_adjacency,
    top_k_pairs,
)


class TestCosineMatrix:
    def test_identity_yields_diagonal_ones(self) -> None:
        a = np.eye(4)
        s = cosine_matrix(a, a)
        np.testing.assert_allclose(np.diag(s), 1.0)

    def test_shape_correct(self) -> None:
        rng = np.random.default_rng(0)
        a = rng.standard_normal((7, 16))
        b = rng.standard_normal((11, 16))
        assert cosine_matrix(a, b).shape == (7, 11)

    def test_values_in_unit_interval(self) -> None:
        rng = np.random.default_rng(0)
        a = rng.standard_normal((10, 8))
        b = rng.standard_normal((10, 8))
        s = cosine_matrix(a, b)
        assert s.min() >= -1 - 1e-9
        assert s.max() <= 1 + 1e-9

    def test_zero_vector_does_not_crash(self) -> None:
        a = np.zeros((1, 4))
        b = np.ones((1, 4))
        s = cosine_matrix(a, b)
        assert np.isfinite(s).all()

    def test_dim_mismatch_raises(self) -> None:
        with pytest.raises(ValueError, match="dimension mismatch"):
            cosine_matrix(np.zeros((3, 4)), np.zeros((3, 5)))

    def test_non_2d_raises(self) -> None:
        with pytest.raises(ValueError, match="2-D arrays"):
            cosine_matrix(np.zeros(3), np.zeros((3, 4)))


class TestThresholdAdjacency:
    def test_basic(self) -> None:
        sim = np.array([[0.95, 0.5], [0.4, 0.95]])
        adj = threshold_adjacency(sim, 0.1)
        assert adj[0, 0]
        assert not adj[0, 1]
        assert not adj[1, 0]
        assert adj[1, 1]

    def test_epsilon_zero_strict(self) -> None:
        sim = np.array([[0.99, 1.0]])
        adj = threshold_adjacency(sim, 0.0)
        assert not adj[0, 0]
        assert adj[0, 1]

    def test_epsilon_out_of_range_raises(self) -> None:
        with pytest.raises(ValueError, match="epsilon"):
            threshold_adjacency(np.zeros((2, 2)), -0.5)
        with pytest.raises(ValueError, match="epsilon"):
            threshold_adjacency(np.zeros((2, 2)), 3.0)


class TestCountEquivalentTranslations:
    def test_identity_adjacency_is_deterministic(self) -> None:
        adj = np.eye(6, dtype=bool)
        assert count_equivalent_translations(adj) == 1

    def test_full_adjacency_counts_factorial(self) -> None:
        adj = np.ones((5, 5), dtype=bool)
        # 5! = 120
        assert count_equivalent_translations(adj, cap=1000) == 120

    def test_cap_is_respected(self) -> None:
        adj = np.ones((6, 6), dtype=bool)
        assert count_equivalent_translations(adj, cap=50) == 50

    def test_empty_adjacency_signals_max(self) -> None:
        adj = np.zeros((4, 4), dtype=bool)
        assert count_equivalent_translations(adj, cap=999) == 999

    def test_zero_size_signals_max(self) -> None:
        adj = np.zeros((0, 0), dtype=bool)
        assert count_equivalent_translations(adj, cap=100) == 100

    def test_unique_match_with_partial_adjacency(self) -> None:
        # Every row has exactly one candidate, all distinct → 1 matching.
        adj = np.zeros((4, 4), dtype=bool)
        for i in range(4):
            adj[i, (i + 1) % 4] = True
        assert count_equivalent_translations(adj) == 1

    def test_two_matchings(self) -> None:
        # Row 0 → {0,1}, row 1 → {0,1} → 2 matchings.
        adj = np.array(
            [[True, True, False], [True, True, False], [False, False, True]],
            dtype=bool,
        )
        assert count_equivalent_translations(adj) == 2

    def test_large_n_does_not_recurse(self) -> None:
        # Regression: realistic SAEs have 10^4-10^5 features. The previous
        # recursive DFS crashed Python's recursion limit at n≥2000.
        n = 8000
        adj = np.eye(n, dtype=bool)
        assert count_equivalent_translations(adj, cap=10) == 1

    def test_asymmetric_3x5_all_ones(self) -> None:
        # 3 rows pick distinct cols from 5 ⇒ 5*4*3 = 60 matchings.
        adj = np.ones((3, 5), dtype=bool)
        assert count_equivalent_translations(adj, cap=1000) == 60

    def test_transpose_invariance_square(self) -> None:
        # Matching count is invariant under transpose only for square
        # adjacency. (The pivot trick used by the implementation flips the
        # shape when convenient, but only on square inputs is the user-level
        # semantics symmetric.)
        rng = np.random.default_rng(7)
        adj = rng.random((6, 6)) < 0.5
        a = count_equivalent_translations(adj, cap=1000)
        b = count_equivalent_translations(adj.T, cap=1000)
        assert a == b

    def test_hall_condition_failure_returns_zero(self) -> None:
        # Two active rows share the only available column ⇒ no injective
        # assignment exists. Must report 0 (previously floored to 1, which
        # falsely signalled a deterministic translation).
        adj = np.array([[True, False], [True, False]], dtype=bool)
        assert count_equivalent_translations(adj) == 0

    def test_partial_dead_rows_count_active_only(self) -> None:
        # Row 1 has no candidates and is dropped; active rows 0 and 2 have a
        # unique distinct assignment ⇒ count = 1.
        adj = np.array(
            [[True, False, False], [False, False, False], [False, True, False]],
            dtype=bool,
        )
        assert count_equivalent_translations(adj) == 1


class TestIndeterminacyScore:
    def test_one_is_zero(self) -> None:
        assert indeterminacy_score(1) == 0.0

    def test_monotone(self) -> None:
        vals = [indeterminacy_score(n) for n in [1, 2, 10, 100, 1000]]
        for a, b in zip(vals, vals[1:], strict=False):
            assert a < b

    def test_bounded_in_unit_interval(self) -> None:
        for n in [1, 5, 50, 500, 10000]:
            s = indeterminacy_score(n)
            assert 0.0 <= s < 1.0

    def test_zero_maps_to_saturation(self) -> None:
        # n=0 = Hall's condition violated = no compatible translation manual.
        # We treat this as maximal-but-bounded indeterminacy (cap-equivalent).
        s = indeterminacy_score(0)
        s_cap = indeterminacy_score(1000)
        assert s == s_cap
        assert s > 0.8


class TestBootstrap:
    def test_returns_within_unit_interval(self) -> None:
        rng = np.random.default_rng(0)
        sim = rng.uniform(-0.5, 0.5, size=(20, 20))
        lo, hi = bootstrap_score_ci(sim, 0.5, n_resamples=20)
        assert 0.0 <= lo <= hi <= 1.0

    def test_empty_returns_zero(self) -> None:
        sim = np.zeros((0, 0))
        lo, hi = bootstrap_score_ci(sim, 0.1, n_resamples=10)
        assert lo == 0.0 and hi == 0.0


class TestTopKPairs:
    def test_returns_sorted(self) -> None:
        sim = np.array([[0.1, 0.9], [0.8, 0.2]])
        adj = sim > 0.3
        pairs = top_k_pairs(sim, adj, k=2)
        assert pairs[0][2] >= pairs[1][2]

    def test_respects_adjacency(self) -> None:
        sim = np.array([[0.99, 0.5]])
        adj = np.array([[False, True]])
        pairs = top_k_pairs(sim, adj, k=2)
        assert len(pairs) == 1
        assert pairs[0][:2] == (0, 1)

    def test_empty(self) -> None:
        assert top_k_pairs(np.zeros((0, 0)), np.zeros((0, 0), dtype=bool)) == []
