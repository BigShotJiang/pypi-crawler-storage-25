"""Dataset object returned by the LabelSets SDK."""
from __future__ import annotations

from typing import TYPE_CHECKING, Any, Iterator

if TYPE_CHECKING:
    from .client import Client


class Dataset:
    """Represents a LabelSets dataset.

    Attributes:
        id:            UUID of the dataset
        title:         Human-readable title
        description:   Full description (markdown)
        category:      Category (e.g. "Computer Vision")
        format:        Primary annotation format (e.g. "yolo", "coco")
        item_count:    Number of labeled items
        price:         Price in USD (0 if free)
        quality_score: Validation quality score (0–1)
        license_type:  License string
        tags:          List of tag strings
        seller:        Dict with seller info
        sample_url:    URL to download a free sample (if available)
        hf_repo_id:    HuggingFace Hub repo ID (if mirrored)
        benchmark:     Benchmark scores dict (if available)
    """

    def __init__(self, data: dict, client: "Client | None" = None) -> None:
        self._data   = data
        self._client = client

        self.id            = data.get("id", "")
        self.title         = data.get("title", "")
        self.description   = data.get("full_desc") or data.get("short_desc", "")
        self.category      = data.get("category", "")
        self.format        = data.get("detected_format") or data.get("primary_format", "")
        self.item_count    = data.get("item_count")
        self.price         = float(data.get("price") or 0)
        self.quality_score = float(data.get("quality_score") or 0)
        self.license_type  = data.get("license_type", "Commercial")
        self.tags          = data.get("tags") or []
        self.seller        = data.get("profiles") or data.get("seller") or {}
        self.sample_url    = data.get("sample_url")
        self.hf_repo_id    = data.get("hf_repo_id")
        self.benchmark     = data.get("benchmark_score")
        self.compliance    = data.get("compliance_badges") or []
        self.thumbnail_url = data.get("thumbnail_url")
        self.slug          = data.get("slug_url") or data.get("slug")

    def __repr__(self) -> str:
        items = f"{self.item_count:,}" if self.item_count else "?"
        return f"<Dataset id={self.id!r} title={self.title!r} format={self.format!r} items={items} price=${self.price:.0f}>"

    @property
    def page_url(self) -> str:
        """Public URL for this dataset's listing page."""
        if self.slug:
            return f"https://labelsets.ai/datasets/{self.slug}"
        return f"https://labelsets.ai/dataset.html?id={self.id}"

    def download(self, dest: str = ".", *, format: str | None = None, show_progress: bool = True) -> str:
        """Download this dataset to a local directory.

        Requires the dataset to be purchased. Returns the path to the downloaded file.

        Args:
            dest:          Directory to save the file
            format:        Convert format (e.g. "yolo", "coco") if conversion is available
            show_progress: Show download progress bar

        Example::

            ds = labelsets.get("abc123")
            path = ds.download("./training-data/", format="yolo")
            print(f"Saved to {path}")
        """
        if not self._client:
            raise RuntimeError("Dataset has no client — use labelsets.get() to fetch it")
        return self._client.download(self.id, dest=dest, format=format, show_progress=show_progress)

    def stream(self, batch_size: int = 32) -> Iterator[dict]:
        """Stream dataset samples as dicts without downloading the full archive.

        Yields batches of ``{"id": ..., "image_url": ..., "annotations": [...]}``
        for image datasets, or ``{"text": ..., "label": ...}`` for text datasets.

        This calls the LabelSets streaming API and requires a Pro or Team subscription.

        Args:
            batch_size: Number of samples per yielded batch

        Example::

            for batch in ds.stream(batch_size=64):
                images    = [load_image(s["image_url"]) for s in batch]
                labels    = [s["annotations"] for s in batch]
                loss = model.train_step(images, labels)
        """
        if not self._client:
            raise RuntimeError("Dataset has no client")
        import requests
        offset = 0
        while True:
            data = self._client._get(
                f"/api/sdk/datasets/{self.id}/stream",
                {"offset": offset, "limit": batch_size},
            )
            items = data.get("items", [])
            if not items:
                break
            yield items
            if len(items) < batch_size:
                break
            offset += batch_size

    def to_huggingface(self, repo_id: str, token: str | None = None) -> Any:
        """Push this dataset to a HuggingFace Hub repository.

        Requires ``pip install datasets huggingface-hub`` and HF_TOKEN env var.

        Args:
            repo_id: HuggingFace repository ID (e.g. "yourname/my-dataset")
            token:   HuggingFace API token (defaults to HF_TOKEN env var)

        Example::

            ds.to_huggingface("myname/urban-driving-50k")
        """
        try:
            from huggingface_hub import HfApi
        except ImportError:
            raise ImportError("Run: pip install huggingface-hub")

        import os
        token = token or os.environ.get("HF_TOKEN")
        api   = HfApi(token=token)
        api.create_repo(repo_id=repo_id, repo_type="dataset", exist_ok=True)

        # Download first, then push
        path = self.download("/tmp/ls_hf_export/")
        api.upload_file(path_or_fileobj=path, path_in_repo=path.split("/")[-1], repo_id=repo_id, repo_type="dataset")

        # Record export in LabelSets
        if self._client:
            try:
                self._client._post(f"/api/datasets/{self.id}/hf-export", {"hf_repo_id": repo_id})
            except Exception:
                pass

        return f"https://huggingface.co/datasets/{repo_id}"

    def to_dict(self) -> dict:
        """Return all dataset metadata as a plain dict."""
        return self._data.copy()

    def to_pytorch(self, split: float = 0.8, download_dir: str = "./data"):
        """Download and wrap as PyTorch Dataset objects (train/val split).

        Requires ``pip install torch torchvision``.

        Args:
            split:        Train fraction (0–1)
            download_dir: Where to save the downloaded data

        Returns:
            Tuple of (train_dataset, val_dataset)

        Example::

            train_ds, val_ds = ds.to_pytorch(split=0.8)
            loader = DataLoader(train_ds, batch_size=32, shuffle=True)
        """
        try:
            from torch.utils.data import Dataset as TorchDataset
        except ImportError:
            raise ImportError("Run: pip install torch torchvision")

        path = self.download(download_dir)

        class _LS(TorchDataset):
            def __init__(self_, items):
                self_._items = items
            def __len__(self_):
                return len(self_._items)
            def __getitem__(self_, idx):
                return self_._items[idx]

        # Minimal: return path-based datasets for zip
        # Full integration requires format-specific parsing
        print(f"Downloaded to {path}. Wrap with your format-specific loader.")
        return path
