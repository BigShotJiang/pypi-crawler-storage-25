"""Command-line interface for the LabelSets LQS SDK.

Installed as ``lqs`` and ``labelsets`` entry points via pyproject.toml.

Subcommands
-----------
- ``lqs score-url <URL>``       — score a HF / Zenodo / Kaggle dataset by URL
- ``lqs verify <CERT_HASH>``    — verify a cert against the public registry
- ``lqs public-key``            — print the LabelSets Ed25519 public key (PEM)
- ``lqs --version``             — print installed SDK version

All commands are network-dependent and hit public endpoints (no API key
required for verify / score-url / public-key).

Examples
--------
::

    $ lqs score-url https://huggingface.co/datasets/rajpurkar/squad
    LQS 85 · gold · confidence 0.4
    cert_hash  f92b6e035715439f27e03851092d74d351703b0aab529a34d5aa9a302cc45f97
    verify at  https://labelsets.ai/verify?hash=f92b6e03...

    $ lqs verify f92b6e035715439f27e03851092d74d351703b0aab529a34d5aa9a302cc45f97
    ✓ valid · composite 85 · tier gold · signed by aa4c070af907e2ea
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from typing import NoReturn

from . import __version__
from .lqs import Scorer, offline_verify

DEFAULT_API = os.environ.get(
    'LABELSETS_API_URL',
    'https://initialdeploy-production.up.railway.app',
)


def _fail(msg: str, code: int = 1) -> NoReturn:
    sys.stderr.write(f'lqs: {msg}\n')
    sys.exit(code)


def _cmd_score_url(args: argparse.Namespace) -> int:
    scorer = Scorer(base_url=args.api)
    try:
        result = scorer.score_url(args.url, source=args.source)
    except Exception as e:
        _fail(f'score failed: {e}')
    if args.json:
        print(json.dumps(result.raw, indent=2))
        return 0
    print(f'LQS {result.composite} · {result.tier} · confidence {result.confidence}')
    print(f'source     {result.source} · {result.source_id}')
    print(f'cert_hash  {result.cert_hash}')
    print(f'key_source {result.cert.get("key_source", "?")} · algorithm Ed25519')
    print(f'elapsed    {result.elapsed_ms}ms{" · cached" if result.cached else ""}')
    if result.dims:
        print('dims:')
        for k, v in sorted(result.dims.items()):
            print(f'  {k:22s} {v}')
    print(f'verify at  https://labelsets.ai/verify?hash={result.cert_hash}')
    return 0


def _cmd_verify(args: argparse.Namespace) -> int:
    import urllib.request
    # Fetch the cert envelope via the public verify endpoint
    req = urllib.request.Request(
        f'{args.api}/api/verify-lqs-cert/{args.cert_hash}',
        headers={'User-Agent': f'labelsets-cli/{__version__}'},
    )
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            body = json.loads(r.read().decode('utf-8'))
    except Exception as e:
        _fail(f'fetch failed: {e}')

    status = body.get('status', 'unknown')
    cert = body.get('cert') or {}
    if status == 'not_found':
        _fail(f'cert not found: {args.cert_hash}', code=2)
    if status == 'revoked':
        rev = body.get('revocation') or {}
        print(f'✗ REVOKED · {args.cert_hash}')
        print(f'  reason: {rev.get("reason", "?")} · at {rev.get("revoked_at", "?")}')
        return 3

    # Offline-verify the signature against the PUBLIC key we fetch once
    try:
        with urllib.request.urlopen(f'{args.api}/api/lqs-public-key', timeout=10) as r:
            pk = json.loads(r.read().decode('utf-8')).get('public_key_pem', '')
    except Exception as e:
        _fail(f'could not fetch public key: {e}')

    envelope = {
        'payload': cert.get('payload'),
        'signature_b64': cert.get('signature_b64'),
        'cert_hash': cert.get('cert_hash'),
    }
    try:
        result = offline_verify(envelope, pk)
    except Exception as e:
        _fail(f'verification failed: {e}')

    if result.valid:
        p = cert.get('payload') or {}
        print(f'✓ valid · composite {p.get("composite", "?")} · tier {p.get("tier", "?")}')
        print(f'  signed by public_key_id {cert.get("public_key_id", "?")}')
        print(f'  issued_at {cert.get("issued_at", "?")} · scorer_version {p.get("scorer_version", "?")}')
        return 0
    print(f'✗ INVALID · {result.verification_reason}')
    return 3


def _cmd_public_key(args: argparse.Namespace) -> int:
    import urllib.request
    try:
        with urllib.request.urlopen(f'{args.api}/api/lqs-public-key', timeout=10) as r:
            body = json.loads(r.read().decode('utf-8'))
    except Exception as e:
        _fail(f'fetch failed: {e}')
    pem = body.get('public_key_pem', '')
    if not pem:
        _fail('server returned no public key')
    print(pem, end='')
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog='lqs',
        description='LabelSets LQS — dataset quality scoring + cert verification.',
    )
    p.add_argument('--version', action='version', version=f'labelsets {__version__}')
    p.add_argument('--api', default=DEFAULT_API, help=f'API base URL (default: {DEFAULT_API})')
    sub = p.add_subparsers(dest='cmd', required=True)

    # score-url
    s = sub.add_parser('score-url', help='score a HF / Zenodo / Kaggle dataset by URL')
    s.add_argument('url', help='dataset URL or canonical slug')
    s.add_argument('--source', choices=['hf', 'zenodo', 'kaggle'],
                   help='disambiguate bare slugs (e.g. owner/name defaults to hf)')
    s.add_argument('--json', action='store_true', help='emit full JSON response')
    s.set_defaults(func=_cmd_score_url)

    # verify
    v = sub.add_parser('verify', help='verify a cert by its SHA-256 hash')
    v.add_argument('cert_hash', help='64-char hex SHA-256 digest')
    v.set_defaults(func=_cmd_verify)

    # public-key
    k = sub.add_parser('public-key', help='print the LabelSets Ed25519 public key (PEM)')
    k.set_defaults(func=_cmd_public_key)

    return p


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == '__main__':
    raise SystemExit(main())
