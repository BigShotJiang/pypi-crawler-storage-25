"""
LabelSets Python SDK
====================
The official client for the LabelSets AI training data marketplace.

Quick start::

    import labelsets

    # Authenticate
    labelsets.login("ls_your_api_key_here")

    # Search and download
    results = labelsets.search("urban driving pedestrians", format="yolo", min_items=10000)
    for ds in results:
        print(ds.title, ds.price)

    ds = labelsets.get("dataset-id-or-slug")
    ds.download("./data/", format="yolo")

    # Stream without downloading
    for batch in ds.stream(batch_size=64):
        train(batch["images"], batch["labels"])
"""

from .client import Client
from .dataset import Dataset
from .search import SearchResults
from .lqs import (
    LQSVerification,
    LQSNamespace,
    Scorer,
    ScoreResult,
    canonicalize as lqs_canonicalize,
    offline_verify as lqs_offline_verify,
)

__version__ = "0.3.0"
__all__ = ["Client", "Dataset", "SearchResults", "login", "get_client",
           "search", "get", "list_datasets", "bundles",
           # LQS v3.1 verification + scoring
           "LQSVerification", "LQSNamespace",
           "Scorer", "ScoreResult",
           "verify_lqs_cert", "lqs_canonicalize", "lqs_offline_verify",
           "get_lqs_public_key"]

# Module-level convenience API backed by a default client
_default_client: "Client | None" = None


def login(api_key: str, base_url: str = "https://initialdeploy-production.up.railway.app") -> "Client":
    """Authenticate with an API key. Returns and sets the default client.

    Args:
        api_key:  Your LabelSets API key (create one at labelsets.ai/dashboard-seller.html)
        base_url: Override the API base URL (useful for self-hosted instances)

    Returns:
        Authenticated :class:`Client` instance

    Example::

        import labelsets
        labelsets.login("ls_your_key_here")
    """
    global _default_client
    _default_client = Client(api_key=api_key, base_url=base_url)
    return _default_client


def get_client() -> "Client":
    """Return the default authenticated client, raising if not logged in."""
    if _default_client is None:
        raise RuntimeError(
            "Not authenticated. Call labelsets.login('your_api_key') first, "
            "or set the LABELSETS_API_KEY environment variable."
        )
    return _default_client


# ── LQS v3.1 verification — no-auth helpers ────────────────────────────────
# These hit the PUBLIC /api/verify-lqs-cert and /api/lqs-public-key endpoints
# and therefore do not require an API key. Useful for auditors, regulators,
# third-party buyers who haven't signed up but still need to verify a cert.

def verify_lqs_cert(
    cert_hash: str,
    base_url: str = "https://initialdeploy-production.up.railway.app",
) -> LQSVerification:
    """Verify a LabelSets LQS cert by its SHA-256 hash. Public — no auth.

    Example::

        import labelsets
        result = labelsets.verify_lqs_cert("27a8060ab73c6d9c...")
        if result.valid:
            print(f"LQS {result.composite} ({result.tier})")
        elif result.revoked:
            print(f"Revoked: {result.revocation_reason}")
    """
    import requests
    import re
    if not cert_hash or not re.fullmatch(r'[0-9a-fA-F]{64}', cert_hash):
        return LQSVerification(
            valid=False, status='invalid_hash',
            verification_reason='cert_hash must be 64-char hex SHA-256 digest',
        )
    url = base_url.rstrip('/') + f'/api/verify-lqs-cert/{cert_hash}'
    resp = requests.get(url, timeout=30)
    resp.raise_for_status()
    return LQSVerification.from_api_response(resp.json())


def get_lqs_public_key(base_url: str = "https://initialdeploy-production.up.railway.app") -> str:
    """Fetch the current LabelSets LQS signing public key (PEM). Public — no auth."""
    import requests
    url = base_url.rstrip('/') + '/api/lqs-public-key'
    resp = requests.get(url, timeout=30)
    resp.raise_for_status()
    return resp.json().get('public_key_pem', '')


def search(
    query: str = "",
    *,
    category: str | None = None,
    format: str | None = None,
    min_items: int | None = None,
    max_price: float | None = None,
    license: str | None = None,
    quality_min: float | None = None,
    sort: str = "popular",
    limit: int = 20,
    natural_language: bool = False,
) -> "SearchResults":
    """Search the LabelSets catalog.

    Args:
        query:            Text search query
        category:         One of "Computer Vision", "NLP / Text", "Autonomous Vehicles", etc.
        format:           One of "coco", "yolo", "voc", "kitti", "labelme", "csv", "parquet", "audio"
        min_items:        Minimum number of labeled items
        max_price:        Maximum price in USD
        license:          "Commercial", "Research", "CC BY", "CC BY-NC", "MIT"
        quality_min:      Minimum quality score (0–1). Use 0.9 for top-rated.
        sort:             "popular", "recent", "price_asc", "price_desc", "quality"
        limit:            Max results (up to 100)
        natural_language: If True, parse query with Claude AI (requires Pro plan)

    Returns:
        :class:`SearchResults` — iterable list of :class:`Dataset` objects

    Example::

        results = labelsets.search(
            "urban driving pedestrians rain",
            format="yolo",
            min_items=5000,
            max_price=500,
        )
        for ds in results:
            print(f"{ds.title}: ${ds.price} ({ds.item_count:,} items)")
    """
    return get_client().search(
        query=query, category=category, format=format, min_items=min_items,
        max_price=max_price, license=license, quality_min=quality_min,
        sort=sort, limit=limit, natural_language=natural_language,
    )


def get(dataset_id: str) -> "Dataset":
    """Fetch a single dataset by ID or slug.

    Args:
        dataset_id: UUID or URL slug of the dataset

    Returns:
        :class:`Dataset` object

    Example::

        ds = labelsets.get("abc123-...")
        print(ds.title, ds.format, ds.item_count)
        ds.download("./my-data/")
    """
    return get_client().get(dataset_id)


def list_datasets(seller_id: str | None = None, limit: int = 20) -> "SearchResults":
    """List published datasets, optionally filtered by seller."""
    return get_client().list_datasets(seller_id=seller_id, limit=limit)


def bundles(limit: int = 10) -> list:
    """List curated dataset bundles."""
    return get_client().bundles(limit=limit)
