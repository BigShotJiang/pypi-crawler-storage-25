"""SearchResults container returned by the LabelSets SDK."""
from __future__ import annotations

from typing import TYPE_CHECKING, Iterator

if TYPE_CHECKING:
    from .client import Client
    from .dataset import Dataset


class SearchResults:
    """Iterable container of :class:`Dataset` objects returned by a search.

    Supports iteration, indexing, ``len()``, and ``repr()``.

    Example::

        results = labelsets.search("pedestrian detection", format="yolo")
        print(f"Found {len(results)} datasets")
        for ds in results:
            print(ds.title, ds.price)
        first = results[0]
    """

    def __init__(self, data: dict | list, client: "Client | None" = None) -> None:
        from .dataset import Dataset

        if isinstance(data, list):
            raw = data
            self.total = len(data)
        else:
            raw        = data.get("datasets") or data.get("data") or data.get("results") or []
            self.total = data.get("total") or len(raw)

        self._datasets = [Dataset(d, client=client) for d in raw]

    def __len__(self) -> int:
        return len(self._datasets)

    def __iter__(self) -> Iterator["Dataset"]:
        return iter(self._datasets)

    def __getitem__(self, idx: int) -> "Dataset":
        return self._datasets[idx]

    def __repr__(self) -> str:
        return f"<SearchResults count={len(self._datasets)} total={self.total}>"

    def filter(self, **kwargs) -> "SearchResults":
        """Client-side filter on already-fetched results.

        Example::

            cheap = results.filter(max_price=100)
            verified = results.filter(min_quality=0.85)
        """
        filtered = self._datasets
        if "max_price" in kwargs:
            filtered = [d for d in filtered if d.price <= kwargs["max_price"]]
        if "min_quality" in kwargs:
            filtered = [d for d in filtered if d.quality_score >= kwargs["min_quality"]]
        if "format" in kwargs:
            filtered = [d for d in filtered if kwargs["format"].lower() in (d.format or "").lower()]
        if "license" in kwargs:
            filtered = [d for d in filtered if kwargs["license"].lower() in (d.license_type or "").lower()]
        result = SearchResults.__new__(SearchResults)
        result._datasets = filtered
        result.total     = len(filtered)
        return result

    def sort_by(self, key: str = "popular") -> "SearchResults":
        """Sort results client-side.

        Args:
            key: "popular", "price_asc", "price_desc", "quality", "recent"
        """
        sorters = {
            "popular":    lambda d: -(d._data.get("total_sales") or 0),
            "price_asc":  lambda d: d.price,
            "price_desc": lambda d: -d.price,
            "quality":    lambda d: -d.quality_score,
        }
        fn = sorters.get(key, sorters["popular"])
        result = SearchResults.__new__(SearchResults)
        result._datasets = sorted(self._datasets, key=fn)
        result.total     = self.total
        return result

    def to_list(self) -> list[dict]:
        """Return a plain list of dicts (all metadata)."""
        return [d.to_dict() for d in self._datasets]

    def to_dataframe(self):
        """Convert to a pandas DataFrame (requires pandas).

        Example::

            df = results.to_dataframe()
            df[["title","price","quality_score","item_count"]].sort_values("quality_score")
        """
        try:
            import pandas as pd
        except ImportError:
            raise ImportError("Run: pip install pandas")
        rows = []
        for d in self._datasets:
            rows.append({
                "id":            d.id,
                "title":         d.title,
                "category":      d.category,
                "format":        d.format,
                "item_count":    d.item_count,
                "price":         d.price,
                "quality_score": d.quality_score,
                "license_type":  d.license_type,
                "tags":          ", ".join(d.tags or []),
                "url":           d.page_url,
            })
        return pd.DataFrame(rows)
