"""Core API client for LabelSets."""
from __future__ import annotations

import os
import time
from typing import Any, Iterator

import requests

from .dataset import Dataset
from .search import SearchResults

_DEFAULT_BASE = "https://initialdeploy-production.up.railway.app"
_TIMEOUT = 30


class Client:
    """Authenticated LabelSets API client.

    Typically you don't construct this directly — use :func:`labelsets.login`.

    Args:
        api_key:  Your LabelSets API key
        base_url: API base URL (override for self-hosted instances)
    """

    def __init__(self, api_key: str | None = None, base_url: str = _DEFAULT_BASE) -> None:
        self.api_key  = api_key or os.environ.get("LABELSETS_API_KEY", "")
        self.base_url = base_url.rstrip("/")
        if not self.api_key:
            raise ValueError(
                "No API key provided. Pass api_key= or set the LABELSETS_API_KEY env var."
            )
        # LQS v3.1 verification namespace (cert verify + offline verify +
        # public-key fetch). Instantiated lazily to avoid a circular import
        # hit at SDK load time.
        self._lqs = None

    @property
    def lqs(self):
        """LQS v3.1 cert verification namespace — see :mod:`labelsets.lqs`."""
        if self._lqs is None:
            from .lqs import LQSNamespace
            self._lqs = LQSNamespace(self)
        return self._lqs

    # ─── Internal ────────────────────────────────────────────────────────────

    @property
    def _headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json", "X-SDK-Version": "0.1.0"}

    def _get(self, path: str, params: dict | None = None) -> Any:
        url  = self.base_url + path
        resp = requests.get(url, headers=self._headers, params=params or {}, timeout=_TIMEOUT)
        self._raise(resp)
        return resp.json()

    def _post(self, path: str, json: dict | None = None) -> Any:
        url  = self.base_url + path
        resp = requests.post(url, headers=self._headers, json=json or {}, timeout=_TIMEOUT)
        self._raise(resp)
        return resp.json()

    @staticmethod
    def _raise(resp: requests.Response) -> None:
        if not resp.ok:
            try:
                msg = resp.json().get("error", resp.text)
            except Exception:
                msg = resp.text
            raise LabelSetsError(f"API error {resp.status_code}: {msg}")

    # ─── Dataset search + retrieval ──────────────────────────────────────────

    def search(
        self,
        query: str = "",
        *,
        category: str | None = None,
        format: str | None = None,
        min_items: int | None = None,
        max_price: float | None = None,
        license: str | None = None,
        quality_min: float | None = None,
        sort: str = "popular",
        limit: int = 20,
        natural_language: bool = False,
    ) -> SearchResults:
        """Search the catalog. See :func:`labelsets.search` for full docs."""
        params: dict = {"sort": sort, "limit": min(limit, 100)}
        if query:           params["q"]           = query
        if category:        params["category"]    = category
        if format:          params["format"]      = format
        if min_items:       params["min_items"]   = min_items
        if max_price:       params["max_price"]   = max_price
        if license:         params["license"]     = license
        if quality_min:     params["quality_min"] = quality_min

        if natural_language and query:
            try:
                nl = self._post("/api/search/nl", {"query": query})
                filters = nl.get("filters", {})
                if filters.get("keywords"):   params["q"]           = filters["keywords"]
                if filters.get("category"):   params["category"]    = filters["category"]
                if filters.get("format"):     params["format"]      = filters["format"]
                if filters.get("max_price"):  params["max_price"]   = filters["max_price"]
                if filters.get("license"):    params["license"]     = filters["license"]
                if filters.get("quality_min"):params["quality_min"] = filters["quality_min"]
            except Exception:
                pass  # fall back to keyword search

        data = self._get("/api/sdk/search", params)
        return SearchResults(data, client=self)

    def get(self, dataset_id: str) -> Dataset:
        """Fetch a dataset by ID or slug."""
        data = self._get(f"/api/sdk/datasets/{dataset_id}")
        return Dataset(data, client=self)

    def list_datasets(self, seller_id: str | None = None, limit: int = 20) -> SearchResults:
        """List published datasets."""
        params: dict = {"limit": limit}
        if seller_id: params["seller_id"] = seller_id
        data = self._get("/api/sdk/search", params)
        return SearchResults(data, client=self)

    def bundles(self, limit: int = 10) -> list[dict]:
        """List curated dataset bundles."""
        return self._get("/api/bundles") or []

    # ─── Download ────────────────────────────────────────────────────────────

    def download(
        self,
        dataset_id: str,
        dest: str = ".",
        *,
        format: str | None = None,
        show_progress: bool = True,
    ) -> str:
        """Download a purchased dataset.

        Args:
            dataset_id:    Dataset UUID (must be purchased)
            dest:          Local directory to save to
            format:        Convert to this format if supported ("yolo", "coco", etc.)
            show_progress: Show tqdm progress bar

        Returns:
            Path to the downloaded file
        """
        import os, pathlib
        data = self._get(f"/api/sdk/download/{dataset_id}", {"format": format} if format else None)
        url  = data.get("url")
        name = data.get("filename", f"{dataset_id}.zip")
        if not url:
            raise LabelSetsError("No download URL returned — is the dataset purchased?")

        dest_path = pathlib.Path(dest)
        dest_path.mkdir(parents=True, exist_ok=True)
        out_file  = dest_path / name

        resp = requests.get(url, stream=True, timeout=600)
        resp.raise_for_status()
        total = int(resp.headers.get("Content-Length", 0))

        if show_progress:
            try:
                from tqdm import tqdm
                with tqdm(total=total, unit="B", unit_scale=True, desc=name) as bar:
                    with open(out_file, "wb") as f:
                        for chunk in resp.iter_content(8192):
                            f.write(chunk)
                            bar.update(len(chunk))
            except ImportError:
                with open(out_file, "wb") as f:
                    for chunk in resp.iter_content(8192):
                        f.write(chunk)
        else:
            with open(out_file, "wb") as f:
                for chunk in resp.iter_content(8192):
                    f.write(chunk)

        return str(out_file)


class LabelSetsError(Exception):
    """Raised when the LabelSets API returns an error."""
