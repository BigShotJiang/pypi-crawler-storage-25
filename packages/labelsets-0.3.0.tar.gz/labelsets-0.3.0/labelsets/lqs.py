"""LQS v3.1 cert verification.

Exposes three operations against the LabelSets LQS cert system:

1. :func:`fetch_cert` — look up a cert by its SHA-256 hash via the public
   /api/verify-lqs-cert endpoint. Returns a :class:`LQSVerification`.

2. :func:`offline_verify` — given a cert payload + signature + a public key,
   verify the Ed25519 signature WITHOUT network access. Useful for
   air-gapped procurement environments.

3. :func:`get_public_key` — fetch the current LabelSets public signing key.
   Cache-friendly (the key rotates rarely).

Both :func:`fetch_cert` and :func:`offline_verify` ultimately return the same
:class:`LQSVerification` shape so downstream code can treat them uniformly.

CANONICALIZATION: signatures are computed over a specific JSON serialization
(keys sorted alphabetically, no whitespace, UTF-8 encoded). The
:func:`canonicalize` function here MUST match the one in
``validation/workers/lqs-cert.js`` and ``api/lqs-cert-verify.js`` on the
server side — any drift breaks all verification.

Example
-------
::

    import labelsets

    cli = labelsets.login("ls_xxx")
    result = cli.lqs.verify_cert("27a8060ab73c6d9c0d1279704ba8c04e265cec2ac557486ad78b14ee915b25ce")
    if result.valid:
        print(f"LQS {result.composite} tier={result.tier} confirmed via cert")
    else:
        print(f"Cert status: {result.status} — {result.verification_reason}")
"""
from __future__ import annotations

import base64
import hashlib
import json
from dataclasses import dataclass, field
from typing import Any


# ── Canonical JSON ──────────────────────────────────────────────────────────
# Direct port of validation/workers/lqs-cert.js:canonicalize + api/lqs-cert-verify.js:canonicalize.
# Sort object keys, no whitespace, arrays preserved in order. Any drift between this
# function and the signer side breaks verification — do NOT optimize this silently.

def canonicalize(obj: Any) -> str:
    """Canonicalize a JSON value for signing. Matches the JS implementation byte-for-byte."""
    if obj is None:
        return 'null'
    if isinstance(obj, bool):
        return 'true' if obj else 'false'
    if isinstance(obj, (int, float)):
        return json.dumps(obj, ensure_ascii=False)
    if isinstance(obj, str):
        return json.dumps(obj, ensure_ascii=False)
    if isinstance(obj, list):
        return '[' + ','.join(canonicalize(v) for v in obj) + ']'
    if isinstance(obj, dict):
        parts = []
        for k in sorted(obj.keys()):
            parts.append(json.dumps(k, ensure_ascii=False) + ':' + canonicalize(obj[k]))
        return '{' + ','.join(parts) + '}'
    return 'null'  # functions, undefined, etc.


# ── Verification result dataclass ───────────────────────────────────────────

@dataclass
class LQSVerification:
    """Result of verifying a LabelSets LQS cert.

    Fields:
      valid: True iff (signature OK) AND (not revoked) AND (cert found)
      status: one of valid | revoked | tampered | not_found | unverified
      cert_hash: 64-char SHA-256 hex digest
      composite: the cited LQS composite score (from cert payload)
      composite_ci_95: { "low": int, "high": int, "se": float } or None
      tier: cert's quality tier (platinum|gold|silver|bronze or similar)
      confidence: cert's confidence (high|medium|low)
      scored_at: ISO-8601 timestamp the score was produced
      scorer_version: e.g. "3.1"
      cert_version: e.g. "1.0"
      revoked: True if cert is in the revocation registry
      revocation_reason: free-form reason (if revoked)
      verification_reason: explanation when valid=False
      raw: full API response for debugging
    """
    valid: bool
    status: str
    cert_hash: str | None = None
    composite: int | None = None
    composite_ci_95: dict | None = None
    tier: str | None = None
    confidence: str | None = None
    scored_at: str | None = None
    scorer_version: str | None = None
    cert_version: str | None = None
    public_key_id: str | None = None
    revoked: bool = False
    revocation_reason: str | None = None
    verification_reason: str | None = None
    raw: dict = field(default_factory=dict)

    @classmethod
    def from_api_response(cls, body: dict) -> 'LQSVerification':
        cert = body.get('cert') or {}
        payload = cert.get('payload') or {}
        rev = body.get('revocation') or None
        ver = body.get('verification') or {}
        return cls(
            valid=bool(body.get('valid')),
            status=body.get('status', 'unknown'),
            cert_hash=cert.get('cert_hash'),
            composite=payload.get('composite'),
            composite_ci_95=payload.get('composite_ci_95'),
            tier=payload.get('tier'),
            confidence=payload.get('confidence'),
            scored_at=cert.get('scored_at'),
            scorer_version=cert.get('scorer_version'),
            cert_version=cert.get('cert_version'),
            public_key_id=cert.get('public_key_id'),
            revoked=rev is not None,
            revocation_reason=(rev or {}).get('reason'),
            verification_reason=ver.get('reason'),
            raw=body,
        )


# ── Ed25519 signature verification (offline) ────────────────────────────────

def _ed25519_verify(message: bytes, signature: bytes, public_key_pem: str) -> bool:
    """Ed25519 verification using the `cryptography` library if installed.

    Raises ImportError with a clear message if `cryptography` is missing.
    """
    try:
        from cryptography.hazmat.primitives.serialization import load_pem_public_key
        from cryptography.exceptions import InvalidSignature
    except ImportError as e:
        raise ImportError(
            "`cryptography` is required for offline LQS cert verification. "
            "Install with: pip install cryptography"
        ) from e

    pk = load_pem_public_key(public_key_pem.encode('utf-8'))
    try:
        pk.verify(signature, message)
        return True
    except InvalidSignature:
        return False


def offline_verify(cert: dict, public_key_pem: str) -> LQSVerification:
    """Verify a cert's Ed25519 signature WITHOUT network access.

    Args:
      cert: Full cert dict with keys {payload, signature_b64, cert_hash}.
      public_key_pem: PEM-encoded Ed25519 public key.

    Returns:
      LQSVerification with status='valid' | 'tampered' | 'malformed'.
    """
    payload = cert.get('payload')
    sig_b64 = cert.get('signature_b64')
    if payload is None or not sig_b64:
        return LQSVerification(
            valid=False, status='malformed',
            verification_reason='missing payload or signature',
            raw=cert,
        )
    canonical = canonicalize(payload)
    canonical_bytes = canonical.encode('utf-8')
    sig = base64.b64decode(sig_b64)

    ok = _ed25519_verify(canonical_bytes, sig, public_key_pem)
    derived_hash = hashlib.sha256(canonical_bytes).hexdigest()
    attached_hash = cert.get('cert_hash')

    if not ok:
        return LQSVerification(
            valid=False, status='tampered',
            cert_hash=derived_hash,
            composite=payload.get('composite'),
            tier=payload.get('tier'),
            verification_reason='signature mismatch — payload tampered or wrong public key',
            raw=cert,
        )
    if attached_hash and attached_hash != derived_hash:
        return LQSVerification(
            valid=False, status='tampered',
            cert_hash=derived_hash,
            composite=payload.get('composite'),
            tier=payload.get('tier'),
            verification_reason='cert_hash does not match re-derived hash',
            raw=cert,
        )
    return LQSVerification(
        valid=True, status='valid',
        cert_hash=derived_hash,
        composite=payload.get('composite'),
        composite_ci_95=payload.get('composite_ci_95'),
        tier=payload.get('tier'),
        confidence=payload.get('confidence'),
        scored_at=payload.get('scored_at'),
        scorer_version=payload.get('scorer_version'),
        cert_version=payload.get('v'),
        verification_reason=None,
        raw=cert,
    )


# ── LQS namespace exposed on Client ─────────────────────────────────────────

class LQSNamespace:
    """LQS verification methods bound to a :class:`Client`.

    Access via ``client.lqs`` — e.g. ``client.lqs.verify_cert(hash)``.
    """

    def __init__(self, client):
        self._client = client

    # ── Online verification ──
    def verify_cert(self, cert_hash: str) -> LQSVerification:
        """Verify a cert via the public /api/verify-lqs-cert endpoint.

        Network-dependent; returns LQSVerification with the full
        issuer+revocation+verification breakdown.
        """
        if not cert_hash or not _is_hex64(cert_hash):
            return LQSVerification(
                valid=False, status='invalid_hash',
                verification_reason='cert_hash must be a 64-char hex SHA-256 digest',
                raw={},
            )
        path = f'/api/verify-lqs-cert/{cert_hash}'
        body = self._client._get(path)
        return LQSVerification.from_api_response(body)

    # ── Public key ──
    def get_public_key(self) -> str:
        """Fetch the current LabelSets LQS signing public key (PEM)."""
        body = self._client._get('/api/lqs-public-key')
        return body.get('public_key_pem', '')

    # ── Offline verification ──
    def offline_verify(self, cert: dict, public_key_pem: str | None = None) -> LQSVerification:
        """Verify a cert WITHOUT network access.

        If public_key_pem is None, we fetch and cache the current public
        key from the API once. For truly air-gapped usage, pass a cached
        public key explicitly.
        """
        if public_key_pem is None:
            public_key_pem = self.get_public_key()
        return offline_verify(cert, public_key_pem)


def _is_hex64(s: str) -> bool:
    return isinstance(s, str) and len(s) == 64 and all(c in '0123456789abcdefABCDEF' for c in s)


# ── Scorer ──────────────────────────────────────────────────────────────────
# Top-level client for scoring datasets. Three modes:
#   1. score_url(url)  — hit /api/lqs/score-by-url (HF / Zenodo / Kaggle). Works today.
#   2. score(path)     — local file scoring (Q4 2026, pending OSS scorer release).
#                         Today this raises NotImplementedError with a clear upgrade path.
#   3. verify(cert)    — offline verify via offline_verify(); shortcut.
#
# No API key required for URL scoring — the endpoint is public, IP rate-limited.

import requests as _requests  # noqa: E402  (used only by Scorer)


@dataclass
class ScoreResult:
    """Result of a single scoring operation.

    Fields mirror the /api/lqs/score-by-url response so downstream code that
    reads a REST response can read a ScoreResult the same way.
    """
    source: str                      # 'hf' | 'zenodo' | 'kaggle'
    source_id: str
    source_url: str
    composite: float
    tier: str                        # 'platinum' | 'gold' | 'silver' | 'bronze'
    confidence: float
    dims: dict                       # per-dim score map
    meta: dict                       # name / maintainer / license / modality / etc.
    cert: dict                       # { payload, signature_b64, cert_hash, public_key_id }
    cached: bool
    elapsed_ms: int
    raw: dict = field(default_factory=dict, repr=False)

    @classmethod
    def from_api_response(cls, d: dict) -> 'ScoreResult':
        score_field = d.get('score') or {}
        # score_field is the full scored object with nested {score: {composite,...}, meta, ...}
        inner = score_field.get('score') or {}
        meta = score_field.get('meta') or {}
        return cls(
            source=d.get('source') or 'hf',
            source_id=d.get('source_id') or d.get('hf_id') or '',
            source_url=d.get('source_url') or d.get('hf_url') or '',
            composite=float(inner.get('composite') or 0),
            tier=inner.get('tier') or 'unknown',
            confidence=float(inner.get('confidence') or 0),
            dims=inner.get('dims') or {},
            meta=meta,
            cert=d.get('cert') or {},
            cached=bool(d.get('cached')),
            elapsed_ms=int(d.get('elapsed_ms') or 0),
            raw=d,
        )

    @property
    def cert_hash(self) -> str:
        return self.cert.get('cert_hash', '')

    def verify(self, public_key_pem: str | None = None) -> LQSVerification:
        """Offline-verify this result's cert. Fetches the public key once if
        not provided (for true air-gap use, cache a public key locally)."""
        envelope = {
            'payload': self.cert.get('payload'),
            'signature_b64': self.cert.get('signature_b64'),
            'cert_hash': self.cert.get('cert_hash'),
        }
        if public_key_pem is None:
            # Use the base URL from the scorer that produced us if available
            pk = _requests.get(
                'https://initialdeploy-production.up.railway.app/api/lqs-public-key',
                timeout=10,
            ).json().get('public_key_pem', '')
        else:
            pk = public_key_pem
        return offline_verify(envelope, pk)


class Scorer:
    """Dataset scorer — hits LabelSets' public scoring API.

    Basic usage::

        from labelsets import Scorer
        scorer = Scorer()

        # URL scoring (HF / Zenodo / Kaggle) — works today
        result = scorer.score_url('https://huggingface.co/datasets/rajpurkar/squad')
        print(result.composite, result.tier, result.confidence)

        # Verify the cert offline — no server contact for the verification step
        verified = result.verify()
        assert verified.valid

        # Local file scoring — Q4 2026 pending OSS scorer release
        # scorer.score('./my_dataset.parquet')  # raises NotImplementedError today
    """

    DEFAULT_BASE_URL = 'https://initialdeploy-production.up.railway.app'

    def __init__(self, base_url: str | None = None, timeout: float = 30.0):
        self.base_url = (base_url or self.DEFAULT_BASE_URL).rstrip('/')
        self.timeout = timeout

    # ── URL scoring — public API, no auth ──
    def score_url(self, url: str, source: str | None = None) -> ScoreResult:
        """Score a public dataset by URL. Supports HuggingFace, Zenodo, Kaggle.

        Args:
            url: Full URL or canonical slug (e.g. 'owner/name' for HF, numeric
                id for Zenodo). Server auto-detects the platform.
            source: Explicit platform hint ('hf' | 'zenodo' | 'kaggle'). Only
                needed to disambiguate bare slugs like 'owner/name' which
                otherwise default to HF.

        Returns:
            :class:`ScoreResult` with composite, tier, confidence, dims,
            cert, etc.

        Raises:
            requests.HTTPError on 4xx/5xx responses (e.g. 400 for malformed
            input, 404 for dataset-not-found, 503 for rate-limit).

        Example::

            scorer = Scorer()
            result = scorer.score_url('openai/gsm8k')
            print(f"LQS {result.composite} · {result.tier} · confidence {result.confidence}")
            # → LQS 81.0 · gold · confidence 0.4
        """
        if not url or not isinstance(url, str):
            raise ValueError('url must be a non-empty string')
        body: dict[str, Any] = {'url': url} if url.startswith('http') else {'id': url}
        if source:
            body['source'] = source
        r = _requests.post(
            f'{self.base_url}/api/lqs/score-by-url',
            json=body,
            timeout=self.timeout,
            headers={'User-Agent': f'labelsets-python-sdk'},
        )
        if not r.ok:
            try:
                detail = r.json().get('error')
            except Exception:
                detail = r.text[:200]
            raise _requests.HTTPError(
                f'{r.status_code} {r.reason}: {detail}', response=r,
            )
        return ScoreResult.from_api_response(r.json())

    # ── Local file scoring — Q4 2026 ──
    def score(self, path):
        """Score a local file.

        **Not yet available (Q4 2026).** The file-based scorer ships with the
        OSS release; see https://labelsets.ai/open-source. For now, use
        :meth:`score_url` against a dataset on HF / Zenodo / Kaggle, or use
        the upload flow at https://labelsets.ai/upload for full file-based
        scoring (hosted).
        """
        raise NotImplementedError(
            "Local file scoring arrives with the open-source scorer in Q4 2026. "
            "Today: use Scorer.score_url(url) for HF/Zenodo/Kaggle public datasets, "
            "or upload at https://labelsets.ai/upload for hosted file-based scoring. "
            "Track progress: https://labelsets.ai/open-source"
        )

    # ── Contamination-only mode — Q4 2026 ──
    def contamination(self, data):
        """Check dataset for overlap with public evaluation benchmarks.

        **Not yet available (Q4 2026).** The contamination detector is part
        of the OSS scorer release. Until then, the full composite LQS score
        includes the contamination_clean dimension — use :meth:`score_url`
        and inspect ``result.dims['contamination_clean']``.
        """
        raise NotImplementedError(
            "Standalone contamination mode ships Q4 2026 with the OSS scorer. "
            "Today: Scorer.score_url(url) returns contamination_clean as one "
            "dimension in result.dims. Track: https://labelsets.ai/open-source"
        )


__all__ = [
    'LQSVerification',
    'LQSNamespace',
    'Scorer',
    'ScoreResult',
    'canonicalize',
    'offline_verify',
]
