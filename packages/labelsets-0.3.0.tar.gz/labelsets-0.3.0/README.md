# LabelSets Python SDK

The official Python client for the [LabelSets](https://labelsets.ai) AI training data marketplace.

```bash
pip install labelsets
```

## Quick start

```python
import labelsets

# Authenticate with your API key (get one at labelsets.ai/dashboard-seller.html)
labelsets.login("ls_your_api_key_here")

# Search the catalog
results = labelsets.search(
    "urban driving pedestrians rain",
    format="yolo",
    min_items=5000,
    max_price=500,
)
print(f"Found {len(results)} datasets")

# Inspect results
for ds in results:
    print(f"  {ds.title}: ${ds.price:.0f} ({ds.item_count:,} items, quality={ds.quality_score:.0%})")

# Get a specific dataset
ds = results[0]
print(ds.format, ds.license_type, ds.compliance)

# Download (must be purchased first at labelsets.ai)
path = ds.download("./training-data/")

# Natural language search (Pro plan)
results = labelsets.search(
    "HIPAA-compliant chest X-ray datasets with radiologist labels, at least 5000 images",
    natural_language=True,
)

# Convert results to pandas DataFrame
df = results.to_dataframe()
df[["title", "price", "quality_score"]].sort_values("quality_score", ascending=False)
```

## Environment variable auth

```bash
export LABELSETS_API_KEY="ls_your_key_here"
```

```python
import labelsets
# No login() call needed when env var is set
results = labelsets.search("medical imaging")
```

## Stream without downloading

```python
ds = labelsets.get("dataset-id")
for batch in ds.stream(batch_size=64):
    images = [item["image_url"] for item in batch]
    labels = [item["annotations"] for item in batch]
    model.train_step(images, labels)
```

## HuggingFace integration

```python
# Export to HuggingFace Hub
ds = labelsets.get("dataset-id")
url = ds.to_huggingface("yourname/my-dataset")
print(f"Published at {url}")

# Import from HuggingFace
import labelsets
meta = labelsets.get_client()._get("/api/hf/import", {"repo_id": "roboflow/coco-128"})
```

## Organizations (Team plan)

```python
# All purchases under your org are shared with team members
# Manage at labelsets.ai/org.html
```

## Installation options

```bash
# Basic (search, download)
pip install labelsets

# With PyTorch helpers
pip install "labelsets[torch]"

# With HuggingFace integration
pip install "labelsets[hf]"

# Everything
pip install "labelsets[all]"
```

## API reference

| Function | Description |
|----------|-------------|
| `labelsets.login(key)` | Authenticate |
| `labelsets.search(query, **filters)` | Search catalog |
| `labelsets.get(id)` | Fetch one dataset |
| `labelsets.list_datasets()` | List all published datasets |
| `labelsets.bundles()` | List curated bundles |
| `dataset.download(dest)` | Download purchased dataset |
| `dataset.stream(batch_size)` | Stream samples |
| `dataset.to_huggingface(repo_id)` | Push to HF Hub |
| `results.to_dataframe()` | Convert to pandas DataFrame |
| `results.filter(max_price=100)` | Client-side filter |

## Links

- [Marketplace](https://labelsets.ai/listings.html)
- [How it works & API keys](https://labelsets.ai/how-it-works.html)
- [Request a dataset](https://labelsets.ai/requests.html)
- [Support](mailto:support@labelsets.ai)
