import httpx
import pytest
import respx

from pendra import AsyncPendra
from pendra._exceptions import APIConnectionError, APIStatusError, AuthenticationError, RateLimitError
from pendra.types.chat import ChatCompletion

COMPLETIONS_URL = "https://test.pendra.ai/api/v1/chat/completions"

SAMPLE_RESPONSE = {
    "id": "chatcmpl-async-1",
    "object": "chat.completion",
    "created": 1700000000,
    "model": "llama3.2",
    "choices": [
        {
            "index": 0,
            "message": {"role": "assistant", "content": "Async hello!"},
            "finish_reason": "stop",
        }
    ],
    "usage": {"prompt_tokens": 5, "completion_tokens": 3, "total_tokens": 8},
}

MESSAGES = [{"role": "user", "content": "Hi"}]


class TestAsyncChatCompletions:
    @pytest.mark.asyncio
    @respx.mock
    async def test_create_success(self, async_client):
        respx.post(COMPLETIONS_URL).respond(json=SAMPLE_RESPONSE)
        result = await async_client.chat.completions.create(model="llama3.2", messages=MESSAGES)
        assert isinstance(result, ChatCompletion)
        assert result.id == "chatcmpl-async-1"
        assert result.choices[0].message.content == "Async hello!"

    @pytest.mark.asyncio
    @respx.mock
    async def test_401_raises_authentication_error(self, async_client):
        respx.post(COMPLETIONS_URL).respond(status_code=401)
        with pytest.raises(AuthenticationError):
            await async_client.chat.completions.create(model="llama3.2", messages=MESSAGES)

    @pytest.mark.asyncio
    @respx.mock
    async def test_429_raises_rate_limit_error(self, async_client):
        respx.post(COMPLETIONS_URL).respond(status_code=429)
        with pytest.raises(RateLimitError):
            await async_client.chat.completions.create(model="llama3.2", messages=MESSAGES)

    @pytest.mark.asyncio
    @respx.mock
    async def test_500_raises_api_status_error(self, async_client):
        respx.post(COMPLETIONS_URL).respond(status_code=500, json={"detail": "Server error"})
        with pytest.raises(APIStatusError) as exc_info:
            await async_client.chat.completions.create(model="llama3.2", messages=MESSAGES)
        assert exc_info.value.status_code == 500
