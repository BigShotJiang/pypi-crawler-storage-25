import respx
import pytest

from pendra.resources.models import Model

MODELS_URL = "https://test.pendra.ai/api/v1/models"

SAMPLE_MODELS = {
    "data": [
        {"id": "llama3.2", "object": "model", "created": 1700000000, "owned_by": "meta"},
        {"id": "mistral-7b", "object": "model", "created": 1700000001, "owned_by": "mistral"},
    ]
}


class TestSyncModels:
    @respx.mock
    def test_list_success(self, sync_client):
        respx.get(MODELS_URL).respond(json=SAMPLE_MODELS)
        models = sync_client.models.list()
        assert len(models) == 2
        assert all(isinstance(m, Model) for m in models)
        assert models[0].id == "llama3.2"
        assert models[1].owned_by == "mistral"

    @respx.mock
    def test_list_empty(self, sync_client):
        respx.get(MODELS_URL).respond(json={"data": []})
        models = sync_client.models.list()
        assert models == []

    @respx.mock
    def test_list_401(self, sync_client):
        respx.get(MODELS_URL).respond(status_code=401)
        with pytest.raises(Exception):
            sync_client.models.list()
