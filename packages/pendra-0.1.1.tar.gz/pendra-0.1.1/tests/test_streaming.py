import json
from unittest.mock import MagicMock

import pytest

from pendra._streaming import Stream
from pendra.types.chat import ChatCompletionChunk


CHUNK_1 = {
    "id": "chatcmpl-stream-1",
    "object": "chat.completion.chunk",
    "created": 1700000000,
    "model": "llama3.2",
    "choices": [{"index": 0, "delta": {"role": "assistant", "content": "Hello"}, "finish_reason": None}],
}

CHUNK_2 = {
    "id": "chatcmpl-stream-1",
    "object": "chat.completion.chunk",
    "created": 1700000000,
    "model": "llama3.2",
    "choices": [{"index": 0, "delta": {"content": " world"}, "finish_reason": "stop"}],
}


def _make_stream(lines: list[str]) -> Stream:
    """Build a Stream from a list of raw SSE lines."""
    response = MagicMock()
    response.iter_lines.return_value = iter(lines)
    response.close = MagicMock()
    ctx = MagicMock()
    ctx.__exit__ = MagicMock()
    return Stream(ctx, response)


class TestStreamParsing:
    def test_yields_chunks(self):
        lines = [
            f"data: {json.dumps(CHUNK_1)}",
            f"data: {json.dumps(CHUNK_2)}",
            "data: [DONE]",
        ]
        stream = _make_stream(lines)
        chunks = list(stream)
        assert len(chunks) == 2
        assert all(isinstance(c, ChatCompletionChunk) for c in chunks)
        assert chunks[0].choices[0].delta.content == "Hello"
        assert chunks[1].choices[0].delta.content == " world"

    def test_skips_blank_lines(self):
        lines = [
            "",
            f"data: {json.dumps(CHUNK_1)}",
            "",
            "data: [DONE]",
        ]
        stream = _make_stream(lines)
        chunks = list(stream)
        assert len(chunks) == 1

    def test_skips_non_data_lines(self):
        lines = [
            ": keep-alive",
            f"data: {json.dumps(CHUNK_1)}",
            "event: ping",
            "data: [DONE]",
        ]
        stream = _make_stream(lines)
        chunks = list(stream)
        assert len(chunks) == 1

    def test_skips_malformed_json(self):
        lines = [
            "data: {not valid json",
            f"data: {json.dumps(CHUNK_1)}",
            "data: [DONE]",
        ]
        stream = _make_stream(lines)
        chunks = list(stream)
        assert len(chunks) == 1

    def test_done_stops_iteration(self):
        lines = [
            f"data: {json.dumps(CHUNK_1)}",
            "data: [DONE]",
            f"data: {json.dumps(CHUNK_2)}",  # should not be reached
        ]
        stream = _make_stream(lines)
        chunks = list(stream)
        assert len(chunks) == 1

    def test_context_manager(self):
        stream = _make_stream(["data: [DONE]"])
        with stream:
            pass
        stream._response.close.assert_called_once()
