import respx
import pytest

from pendra.resources.models import Model

MODELS_URL = "https://test.pendra.ai/api/v1/models"

SAMPLE_MODELS = {
    "data": [
        {"id": "llama3.2", "object": "model", "created": 1700000000, "owned_by": "meta"},
    ]
}


class TestAsyncModels:
    @pytest.mark.asyncio
    @respx.mock
    async def test_list_success(self, async_client):
        respx.get(MODELS_URL).respond(json=SAMPLE_MODELS)
        models = await async_client.models.list()
        assert len(models) == 1
        assert isinstance(models[0], Model)
        assert models[0].id == "llama3.2"

    @pytest.mark.asyncio
    @respx.mock
    async def test_list_empty(self, async_client):
        respx.get(MODELS_URL).respond(json={"data": []})
        models = await async_client.models.list()
        assert models == []
