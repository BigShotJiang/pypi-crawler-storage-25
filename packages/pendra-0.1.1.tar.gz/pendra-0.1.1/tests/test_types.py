from pendra.types.chat import (
    ChatCompletion,
    ChatCompletionChunk,
    ChatCompletionMessage,
    Choice,
    ChoiceDelta,
    StreamChoice,
    Usage,
)
from pendra.resources.models import Model


class TestUsage:
    def test_from_dict(self):
        u = Usage.from_dict({"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15})
        assert u.prompt_tokens == 10
        assert u.total_tokens == 15

    def test_defaults(self):
        u = Usage.from_dict({})
        assert u.prompt_tokens == 0


class TestChatCompletion:
    def test_from_dict_full(self):
        data = {
            "id": "cc-1",
            "object": "chat.completion",
            "created": 1700000000,
            "model": "llama3.2",
            "choices": [
                {"index": 0, "message": {"role": "assistant", "content": "Hi"}, "finish_reason": "stop"}
            ],
            "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
        }
        cc = ChatCompletion.from_dict(data)
        assert cc.id == "cc-1"
        assert cc.model == "llama3.2"
        assert len(cc.choices) == 1
        assert cc.choices[0].message.content == "Hi"
        assert cc.usage.total_tokens == 2

    def test_from_dict_no_usage(self):
        data = {
            "id": "cc-2",
            "model": "llama3.2",
            "choices": [
                {"index": 0, "message": {"role": "assistant", "content": "Hey"}, "finish_reason": "stop"}
            ],
        }
        cc = ChatCompletion.from_dict(data)
        assert cc.usage is None


class TestChatCompletionChunk:
    def test_from_dict(self):
        data = {
            "id": "chunk-1",
            "object": "chat.completion.chunk",
            "created": 1700000000,
            "model": "llama3.2",
            "choices": [
                {"index": 0, "delta": {"role": "assistant", "content": "Hel"}, "finish_reason": None}
            ],
        }
        chunk = ChatCompletionChunk.from_dict(data)
        assert chunk.id == "chunk-1"
        assert chunk.choices[0].delta.content == "Hel"


class TestModel:
    def test_from_dict(self):
        m = Model.from_dict({"id": "llama3.2", "object": "model", "created": 100, "owned_by": "meta"})
        assert m.id == "llama3.2"
        assert m.owned_by == "meta"

    def test_defaults(self):
        m = Model.from_dict({"id": "test"})
        assert m.object == "model"
        assert m.created == 0
        assert m.owned_by == "pendra"
