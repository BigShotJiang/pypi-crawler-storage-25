import respx
import httpx
import pytest

from pendra import Pendra
from pendra._exceptions import APIConnectionError, APIStatusError, AuthenticationError, RateLimitError
from pendra.types.chat import ChatCompletion

COMPLETIONS_URL = "https://test.pendra.ai/api/v1/chat/completions"

SAMPLE_RESPONSE = {
    "id": "chatcmpl-1",
    "object": "chat.completion",
    "created": 1700000000,
    "model": "llama3.2",
    "choices": [
        {
            "index": 0,
            "message": {"role": "assistant", "content": "Hello!"},
            "finish_reason": "stop",
        }
    ],
    "usage": {"prompt_tokens": 5, "completion_tokens": 3, "total_tokens": 8},
}

MESSAGES = [{"role": "user", "content": "Hi"}]


class TestSyncChatCompletions:
    @respx.mock
    def test_create_success(self, sync_client):
        respx.post(COMPLETIONS_URL).respond(json=SAMPLE_RESPONSE)
        result = sync_client.chat.completions.create(model="llama3.2", messages=MESSAGES)
        assert isinstance(result, ChatCompletion)
        assert result.id == "chatcmpl-1"
        assert result.choices[0].message.content == "Hello!"

    @respx.mock
    def test_forwards_params(self, sync_client):
        route = respx.post(COMPLETIONS_URL).respond(json=SAMPLE_RESPONSE)
        sync_client.chat.completions.create(
            model="llama3.2",
            messages=MESSAGES,
            temperature=0.7,
            max_tokens=100,
            top_p=0.9,
            stop=["END"],
        )
        body = route.calls[0].request.content
        import json
        payload = json.loads(body)
        assert payload["temperature"] == 0.7
        assert payload["max_tokens"] == 100
        assert payload["top_p"] == 0.9
        assert payload["stop"] == ["END"]

    @respx.mock
    def test_401_raises_authentication_error(self, sync_client):
        respx.post(COMPLETIONS_URL).respond(status_code=401)
        with pytest.raises(AuthenticationError):
            sync_client.chat.completions.create(model="llama3.2", messages=MESSAGES)

    @respx.mock
    def test_429_raises_rate_limit_error(self, sync_client):
        respx.post(COMPLETIONS_URL).respond(status_code=429)
        with pytest.raises(RateLimitError):
            sync_client.chat.completions.create(model="llama3.2", messages=MESSAGES)

    @respx.mock
    def test_500_raises_api_status_error(self, sync_client):
        respx.post(COMPLETIONS_URL).respond(status_code=500, json={"detail": "Internal error"})
        with pytest.raises(APIStatusError) as exc_info:
            sync_client.chat.completions.create(model="llama3.2", messages=MESSAGES)
        assert exc_info.value.status_code == 500

    @respx.mock
    def test_connection_error(self, sync_client):
        respx.post(COMPLETIONS_URL).mock(side_effect=httpx.ConnectError("refused"))
        with pytest.raises(APIConnectionError):
            sync_client.chat.completions.create(model="llama3.2", messages=MESSAGES)
