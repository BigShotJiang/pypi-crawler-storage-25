# pendra-python

Official Python SDK for [Pendra](https://pendra.ai) — UK-based, privacy-first LLM inference.

Your data is processed in the UK, never stored, never shared with US cloud providers.

## Installation

```bash
pip install pendra
```

## Quick Start

```python
import pendra

client = pendra.Pendra(
    api_key="pdr_sk_...",          # or set PENDRA_API_KEY env var
    base_url="http://localhost",    # your self-hosted instance
)

response = client.chat.completions.create(
    model="llama3.2",
    messages=[
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "What is the capital of the UK?"},
    ],
)

print(response.choices[0].message.content)
# → London is the capital of the United Kingdom.
```

## Streaming

```python
with client.chat.completions.create(
    model="llama3.2",
    messages=[{"role": "user", "content": "Write me a short poem about London."}],
    stream=True,
) as stream:
    for chunk in stream:
        print(chunk.choices[0].delta.content or "", end="", flush=True)
```

## Async

```python
import asyncio
import pendra

async def main():
    async with pendra.AsyncPendra(api_key="pdr_sk_...") as client:
        # Non-streaming
        response = await client.chat.completions.create(
            model="llama3.2",
            messages=[{"role": "user", "content": "Hello!"}],
        )
        print(response.choices[0].message.content)

        # Streaming
        stream = await client.chat.completions.create(
            model="llama3.2",
            messages=[{"role": "user", "content": "Count to 5"}],
            stream=True,
        )
        async for chunk in stream:
            print(chunk.choices[0].delta.content or "", end="", flush=True)

asyncio.run(main())
```

## List Models

```python
models = client.models.list()
for model in models:
    print(model.id)
```

## Environment Variables

| Variable | Description |
|----------|-------------|
| `PENDRA_API_KEY` | Your Pendra API key (`pdr_sk_...`) |

## OpenAI Compatibility

The Pendra SDK is fully compatible with the OpenAI Python SDK interface. To migrate:

```python
# Before
from openai import OpenAI
client = OpenAI(api_key="sk-...")

# After
from pendra import Pendra
client = Pendra(api_key="pdr_sk_...", base_url="https://your-pendra-instance.com")
```

The `client.chat.completions.create()` interface is identical.

## Self-Hosting

Pendra is fully open source. Run your own instance:

```bash
git clone https://github.com/pendra-ai/pendra
cd pendra
cp .env.example .env
docker compose up -d
```

## Licence

MIT
