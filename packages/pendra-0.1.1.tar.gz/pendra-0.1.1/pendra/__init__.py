"""Pendra Python SDK — UK-based LLM inference, OpenAI-compatible."""

from ._client import AsyncPendra, Pendra
from ._exceptions import (
    APIConnectionError,
    APIError,
    APIStatusError,
    AuthenticationError,
    RateLimitError,
)

__version__ = "0.1.1"

__all__ = [
    "Pendra",
    "AsyncPendra",
    "APIError",
    "APIStatusError",
    "APIConnectionError",
    "AuthenticationError",
    "RateLimitError",
]
