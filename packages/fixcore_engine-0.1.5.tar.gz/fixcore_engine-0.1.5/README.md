<img src="fixcore_logo.svg" alt="FIXcore" width="340" />

Pure Python FIX protocol engine — mirrors the QuickFIX architecture (QuickFIX/n, QuickFIX/J).

## Features

- Full FIX 4.2 session layer (Logon, Logout, Heartbeat, ResendRequest, SequenceReset, Reject)
- Message encoding/decoding with DataDictionary validation
- Repeating groups
- Async transport: `SocketAcceptor` + `SocketInitiator` with auto-reconnect
- `FileStore` and `MemoryStore` persistence
- `MessageCracker` dispatch mixin
- Lightweight browser GUI via aiohttp (`tools/fix_gui.py`) — session management, message builder, live message log

## Quick start

```bash
pip install fixcore-engine
pip install "fixcore-engine[gui]"  # includes aiohttp for the GUI
```

## Development

```bash
pip install -e ".[dev,gui]"
pytest
python tools/fix_gui.py
```
