"""MessageStore factory — creates a store per session."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path

from fixcore.session.session_id import SessionID
from fixcore.store.base import MessageStore


class StoreFactory(ABC):
    @abstractmethod
    def create(self, session_id: SessionID) -> MessageStore: ...


class MemoryStoreFactory(StoreFactory):
    """Creates a fresh in-memory store for each session (non-persistent)."""

    def create(self, session_id: SessionID) -> MessageStore:
        from fixcore.store.memory import MemoryStore
        return MemoryStore()


class FileStoreFactory(StoreFactory):
    """Creates a FileStore for each session under *store_dir*."""

    def __init__(self, store_dir: str | Path) -> None:
        self._dir = Path(store_dir)

    def create(self, session_id: SessionID) -> MessageStore:
        from fixcore.store.file_store import FileStore
        return FileStore(self._dir, session_id)
