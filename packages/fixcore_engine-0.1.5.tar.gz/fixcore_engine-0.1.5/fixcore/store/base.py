"""MessageStore abstract base class."""

from __future__ import annotations

from abc import ABC, abstractmethod


class MessageStore(ABC):
    """Persists sent messages and tracks sequence numbers for a single session."""

    @abstractmethod
    def get(self, begin_seq: int, end_seq: int) -> list[bytes]:
        """Return stored messages with sequence numbers in [begin_seq, end_seq]."""

    @abstractmethod
    def set(self, seq_num: int, message: bytes) -> None:
        """Store *message* at *seq_num*."""

    @abstractmethod
    def next_sender_msg_seq_num(self) -> int:
        """Return the next outbound sequence number."""

    @abstractmethod
    def next_target_msg_seq_num(self) -> int:
        """Return the next expected inbound sequence number."""

    @abstractmethod
    def incr_next_sender_msg_seq_num(self) -> None:
        """Increment the outbound sequence number by 1."""

    @abstractmethod
    def incr_next_target_msg_seq_num(self) -> None:
        """Increment the expected inbound sequence number by 1."""

    @abstractmethod
    def set_next_sender_msg_seq_num(self, seq_num: int) -> None:
        """Override the outbound sequence number."""

    @abstractmethod
    def set_next_target_msg_seq_num(self, seq_num: int) -> None:
        """Override the expected inbound sequence number."""

    @abstractmethod
    def reset(self) -> None:
        """Clear all stored messages and reset sequence numbers to 1."""

    @abstractmethod
    def refresh(self) -> None:
        """Reload state from the underlying store (no-op for in-memory)."""
