"""File-backed MessageStore — persists messages and sequence numbers to disk.

Layout (one set of files per session, under *store_dir*)::

    FIX.4.2-CLIENT-SERVER.body      — raw FIX messages, newline-separated
    FIX.4.2-CLIENT-SERVER.index     — "seq_num=offset,length\\n" per stored message
    FIX.4.2-CLIENT-SERVER.seqnums   — "sender=N\\ntarget=M\\n"

The index is held in memory after init for O(1) random access.  The body and
index files are append-only; ``reset()`` truncates them.
"""

from __future__ import annotations

import os
from pathlib import Path

from fixcore.session.session_id import SessionID
from fixcore.store.base import MessageStore


def _session_prefix(session_id: SessionID) -> str:
    """Convert a SessionID to a safe filesystem name."""
    return (
        f"{session_id.begin_string}-"
        f"{session_id.sender_comp_id}-"
        f"{session_id.target_comp_id}"
        + (f"-{session_id.qualifier}" if session_id.qualifier else "")
    )


class FileStore(MessageStore):
    """Durable MessageStore backed by three flat files per session.

    Parameters
    ----------
    store_dir:
        Directory where session files are written.  Created if absent.
    session_id:
        Identifies the session; used to derive file names.
    """

    def __init__(self, store_dir: str | Path, session_id: SessionID) -> None:
        self._dir = Path(store_dir)
        self._dir.mkdir(parents=True, exist_ok=True)

        prefix = self._dir / _session_prefix(session_id)
        self._body_path = Path(f"{prefix}.body")
        self._index_path = Path(f"{prefix}.index")
        self._seqnums_path = Path(f"{prefix}.seqnums")

        # In-memory index: seq_num → (byte_offset, length)
        self._index: dict[int, tuple[int, int]] = {}

        self._next_sender: int = 1
        self._next_target: int = 1

        self._init_files()

    # ------------------------------------------------------------------
    # Initialisation
    # ------------------------------------------------------------------

    def _init_files(self) -> None:
        """Create files if absent, then load persisted state."""
        for path in (self._body_path, self._index_path, self._seqnums_path):
            if not path.exists():
                path.touch()

        self._load_seqnums()
        self._load_index()

    def _load_seqnums(self) -> None:
        text = self._seqnums_path.read_text()
        self._next_sender = 1
        self._next_target = 1
        for line in text.splitlines():
            if line.startswith("sender="):
                self._next_sender = int(line[7:])
            elif line.startswith("target="):
                self._next_target = int(line[7:])

    def _load_index(self) -> None:
        self._index.clear()
        for line in self._index_path.read_text().splitlines():
            if not line:
                continue
            # format: seq_num=offset,length
            eq = line.index("=")
            seq = int(line[:eq])
            offset_str, length_str = line[eq + 1:].split(",")
            self._index[seq] = (int(offset_str), int(length_str))

    def _flush_seqnums(self) -> None:
        self._seqnums_path.write_text(
            f"sender={self._next_sender}\ntarget={self._next_target}\n"
        )

    # ------------------------------------------------------------------
    # MessageStore interface
    # ------------------------------------------------------------------

    def get(self, begin_seq: int, end_seq: int) -> list[bytes]:
        results: list[bytes] = []
        with self._body_path.open("rb") as fh:
            for seq in range(begin_seq, end_seq + 1):
                entry = self._index.get(seq)
                if entry is None:
                    continue
                offset, length = entry
                fh.seek(offset)
                results.append(fh.read(length))
        return results

    def set(self, seq_num: int, message: bytes) -> None:
        # Append message to body (newline-terminated for human readability)
        with self._body_path.open("ab") as fh:
            offset = fh.seek(0, os.SEEK_END)
            fh.write(message)
            fh.write(b"\n")
            length = len(message)

        # Append index entry
        with self._index_path.open("a") as fh:
            fh.write(f"{seq_num}={offset},{length}\n")

        self._index[seq_num] = (offset, length)

    def next_sender_msg_seq_num(self) -> int:
        return self._next_sender

    def next_target_msg_seq_num(self) -> int:
        return self._next_target

    def incr_next_sender_msg_seq_num(self) -> None:
        self._next_sender += 1
        self._flush_seqnums()

    def incr_next_target_msg_seq_num(self) -> None:
        self._next_target += 1
        self._flush_seqnums()

    def set_next_sender_msg_seq_num(self, seq_num: int) -> None:
        self._next_sender = seq_num
        self._flush_seqnums()

    def set_next_target_msg_seq_num(self, seq_num: int) -> None:
        self._next_target = seq_num
        self._flush_seqnums()

    def reset(self) -> None:
        self._body_path.write_bytes(b"")
        self._index_path.write_text("")
        self._index.clear()
        self._next_sender = 1
        self._next_target = 1
        self._flush_seqnums()

    def refresh(self) -> None:
        """Reload all state from disk (e.g. after external modification)."""
        self._load_seqnums()
        self._load_index()
