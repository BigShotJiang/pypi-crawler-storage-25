"""In-memory MessageStore implementation."""

from __future__ import annotations

from fixcore.store.base import MessageStore


class MemoryStore(MessageStore):
    """Non-persistent store — useful for testing and ephemeral sessions."""

    def __init__(self) -> None:
        self._messages: dict[int, bytes] = {}
        self._next_sender: int = 1
        self._next_target: int = 1

    def get(self, begin_seq: int, end_seq: int) -> list[bytes]:
        return [
            self._messages[seq]
            for seq in range(begin_seq, end_seq + 1)
            if seq in self._messages
        ]

    def set(self, seq_num: int, message: bytes) -> None:
        self._messages[seq_num] = message

    def next_sender_msg_seq_num(self) -> int:
        return self._next_sender

    def next_target_msg_seq_num(self) -> int:
        return self._next_target

    def incr_next_sender_msg_seq_num(self) -> None:
        self._next_sender += 1

    def incr_next_target_msg_seq_num(self) -> None:
        self._next_target += 1

    def set_next_sender_msg_seq_num(self, seq_num: int) -> None:
        self._next_sender = seq_num

    def set_next_target_msg_seq_num(self, seq_num: int) -> None:
        self._next_target = seq_num

    def reset(self) -> None:
        self._messages.clear()
        self._next_sender = 1
        self._next_target = 1

    def refresh(self) -> None:
        pass  # nothing to reload
