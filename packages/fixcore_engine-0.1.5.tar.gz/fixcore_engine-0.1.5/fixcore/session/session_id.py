"""SessionID — immutable identifier for a FIX session."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class SessionID:
    """Uniquely identifies a FIX session.

    Attributes
    ----------
    begin_string:
        FIX version, e.g. ``"FIX.4.2"``, ``"FIX.4.4"``, ``"FIXT.1.1"``.
    sender_comp_id:
        SenderCompID of the local party.
    target_comp_id:
        TargetCompID of the remote party.
    qualifier:
        Optional disambiguator when two sessions share the same
        BeginString/SenderCompID/TargetCompID triple.
    """

    begin_string: str
    sender_comp_id: str
    target_comp_id: str
    qualifier: str = ""

    def __str__(self) -> str:
        base = f"{self.begin_string}:{self.sender_comp_id}->{self.target_comp_id}"
        return f"{base}:{self.qualifier}" if self.qualifier else base
