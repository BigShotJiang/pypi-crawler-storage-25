"""SessionSettings — parse QuickFIX-style INI configuration."""

from __future__ import annotations

import configparser
from pathlib import Path
from typing import Any

from fixcore.session.session_id import SessionID

_DEFAULT_SECTION = "DEFAULT"
_SESSION_SECTION_PREFIX = "SESSION"


class SessionSettings:
    """Holds per-session and default configuration values.

    Parses a QuickFIX-compatible INI file of the form::

        [DEFAULT]
        ConnectionType=initiator
        HeartBtInt=30
        ResetOnLogon=N

        [SESSION]
        BeginString=FIX.4.2
        SenderCompID=CLIENT
        TargetCompID=SERVER
        SocketConnectHost=127.0.0.1
        SocketConnectPort=9878

    Multiple ``[SESSION]`` blocks are allowed; each must define
    ``BeginString``, ``SenderCompID``, and ``TargetCompID``.
    """

    def __init__(self) -> None:
        self._defaults: dict[str, str] = {}
        # session_id → settings dict
        self._sessions: dict[SessionID, dict[str, str]] = {}

    # ------------------------------------------------------------------
    # Parsing
    # ------------------------------------------------------------------

    @classmethod
    def from_file(cls, path: str | Path) -> "SessionSettings":
        settings = cls()
        text = Path(path).read_text()
        parser = configparser.RawConfigParser()
        parser.optionxform = str  # preserve case
        import io
        parser.read_file(io.StringIO(cls._preprocess(text)))

        if parser.has_section(_DEFAULT_SECTION) or parser.defaults():
            settings._defaults = dict(parser.defaults())

        for section in parser.sections():
            if section.upper().startswith(_SESSION_SECTION_PREFIX):
                items = dict(parser.items(section))
                session_id = SessionID(
                    begin_string=items["BeginString"],
                    sender_comp_id=items["SenderCompID"],
                    target_comp_id=items["TargetCompID"],
                    qualifier=items.get("SessionQualifier", ""),
                )
                settings._sessions[session_id] = items

        return settings

    @staticmethod
    def _preprocess(text: str) -> str:
        """Rename duplicate [SESSION] headers to [SESSION_0], [SESSION_1], ...

        configparser rejects duplicate section names; QuickFIX configs routinely
        have multiple [SESSION] blocks.
        """
        lines = text.splitlines(keepends=True)
        result: list[str] = []
        session_count = 0
        for line in lines:
            if line.strip().upper() == "[SESSION]":
                line = f"[SESSION_{session_count}]\n"
                session_count += 1
            result.append(line)
        return "".join(result)

    @classmethod
    def from_string(cls, text: str) -> "SessionSettings":
        """Parse from a configuration string (useful in tests)."""
        import io

        settings = cls()
        parser = configparser.RawConfigParser()
        parser.optionxform = str
        parser.read_file(io.StringIO(cls._preprocess(text)))

        settings._defaults = dict(parser.defaults())

        for section in parser.sections():
            if section.upper().startswith(_SESSION_SECTION_PREFIX):
                items = dict(parser.items(section))
                session_id = SessionID(
                    begin_string=items["BeginString"],
                    sender_comp_id=items["SenderCompID"],
                    target_comp_id=items["TargetCompID"],
                    qualifier=items.get("SessionQualifier", ""),
                )
                settings._sessions[session_id] = items

        return settings

    # ------------------------------------------------------------------
    # Access
    # ------------------------------------------------------------------

    def get(self, session_id: SessionID, key: str) -> str:
        """Return the value for *key* in *session_id*'s section.

        Falls back to the DEFAULT section.  Raises KeyError if not found.
        """
        session = self._sessions.get(session_id, {})
        if key in session:
            return session[key]
        if key in self._defaults:
            return self._defaults[key]
        raise KeyError(f"Setting {key!r} not found for {session_id}")

    def get_or(self, session_id: SessionID, key: str, default: Any = None) -> Any:
        try:
            return self.get(session_id, key)
        except KeyError:
            return default

    def get_bool(self, session_id: SessionID, key: str, default: bool = False) -> bool:
        val = self.get_or(session_id, key)
        if val is None:
            return default
        return val.strip().upper() in ("Y", "YES", "TRUE", "1")

    def get_int(self, session_id: SessionID, key: str, default: int = 0) -> int:
        val = self.get_or(session_id, key)
        return int(val) if val is not None else default

    @property
    def session_ids(self) -> list[SessionID]:
        return list(self._sessions.keys())
