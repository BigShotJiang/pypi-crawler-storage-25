"""Session state enum and FIX session-layer constants."""

from enum import Enum, auto


class SessionState(Enum):
    DISCONNECTED = auto()
    LOGON_TIMEOUT = auto()   # connected, Logon sent (initiator) or awaited (acceptor)
    LOGGED_ON = auto()
    LOGOUT_TIMEOUT = auto()  # Logout sent, waiting for counterparty Logout


# ---------------------------------------------------------------------------
# Tag constants used by the session layer
# ---------------------------------------------------------------------------

TAG_BEGIN_STRING = 8
TAG_BODY_LENGTH = 9
TAG_MSG_TYPE = 35
TAG_CHECKSUM = 10

TAG_MSG_SEQ_NUM = 34
TAG_SENDER_COMP_ID = 49
TAG_TARGET_COMP_ID = 56
TAG_SENDING_TIME = 52
TAG_POSS_DUP_FLAG = 43
TAG_ORIG_SENDING_TIME = 122

TAG_ENCRYPT_METHOD = 98
TAG_HEART_BT_INT = 108
TAG_RESET_SEQ_NUM_FLAG = 141
TAG_TEST_REQ_ID = 112

TAG_BEGIN_SEQ_NO = 7
TAG_END_SEQ_NO = 16
TAG_NEW_SEQ_NO = 36
TAG_GAP_FILL_FLAG = 123

TAG_REF_SEQ_NUM = 45
TAG_REF_TAG_ID = 371
TAG_REF_MSG_TYPE = 372
TAG_SESSION_REJECT_REASON = 373
TAG_TEXT = 58

# ---------------------------------------------------------------------------
# Message type constants
# ---------------------------------------------------------------------------

MSG_HEARTBEAT = "0"
MSG_TEST_REQUEST = "1"
MSG_RESEND_REQUEST = "2"
MSG_REJECT = "3"
MSG_SEQUENCE_RESET = "4"
MSG_LOGOUT = "5"
MSG_LOGON = "A"

ADMIN_MSG_TYPES: frozenset[str] = frozenset({
    MSG_HEARTBEAT, MSG_TEST_REQUEST, MSG_RESEND_REQUEST,
    MSG_REJECT, MSG_SEQUENCE_RESET, MSG_LOGOUT, MSG_LOGON,
})
