"""Log / LogFactory abstract base classes."""

from __future__ import annotations

from abc import ABC, abstractmethod

from fixcore.session.session_id import SessionID


class Log(ABC):
    @abstractmethod
    def on_incoming(self, message: str) -> None:
        """Log a raw incoming message."""

    @abstractmethod
    def on_outgoing(self, message: str) -> None:
        """Log a raw outgoing message."""

    @abstractmethod
    def on_event(self, text: str) -> None:
        """Log a session event (connect, disconnect, error, etc.)."""


class LogFactory(ABC):
    @abstractmethod
    def create(self, session_id: SessionID) -> Log:
        """Return a Log instance for *session_id*."""
