"""File-backed Log implementation — appends timestamped entries to a log file."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from fixcore.log.base import Log, LogFactory
from fixcore.session.session_id import SessionID


def _session_filename(session_id: SessionID) -> str:
    return (
        f"{session_id.begin_string}-"
        f"{session_id.sender_comp_id}-"
        f"{session_id.target_comp_id}"
        + (f"-{session_id.qualifier}" if session_id.qualifier else "")
        + ".log"
    )


def _now() -> str:
    return datetime.now(tz=timezone.utc).strftime("%Y%m%d-%H:%M:%S.%f")[:-3]


class FileLog(Log):
    """Writes incoming messages, outgoing messages, and session events to a
    single append-only log file.

    Log line format::

        20240101-12:00:00.000 : <incoming>  8=FIX.4.2|9=...|
        20240101-12:00:00.001 : <outgoing>  8=FIX.4.2|9=...|
        20240101-12:00:00.002 : --event--   Logon complete
    """

    def __init__(self, log_dir: str | Path, session_id: SessionID) -> None:
        log_path = Path(log_dir) / _session_filename(session_id)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        self._fh = log_path.open("a", encoding="utf-8", buffering=1)  # line-buffered

    def on_incoming(self, message: str) -> None:
        self._fh.write(f"{_now()} : <incoming>  {message}\n")

    def on_outgoing(self, message: str) -> None:
        self._fh.write(f"{_now()} : <outgoing>  {message}\n")

    def on_event(self, text: str) -> None:
        self._fh.write(f"{_now()} : --event--   {text}\n")

    def close(self) -> None:
        """Flush and close the underlying file handle."""
        self._fh.flush()
        self._fh.close()

    def __del__(self) -> None:
        try:
            self._fh.close()
        except Exception:
            pass


class FileLogFactory(LogFactory):
    """Creates a :class:`FileLog` for each session under *log_dir*."""

    def __init__(self, log_dir: str | Path) -> None:
        self._log_dir = Path(log_dir)

    def create(self, session_id: SessionID) -> FileLog:
        return FileLog(self._log_dir, session_id)
