"""Screen (stdout) log implementation."""

from __future__ import annotations

import sys
from datetime import datetime, timezone

from fixcore.log.base import Log, LogFactory
from fixcore.session.session_id import SessionID


def _now() -> str:
    return datetime.now(tz=timezone.utc).strftime("%Y%m%d-%H:%M:%S.%f")[:-3]


class ScreenLog(Log):
    def __init__(self, session_id: SessionID) -> None:
        self._prefix = str(session_id)

    def on_incoming(self, message: str) -> None:
        print(f"{_now()} {self._prefix} <  {message}", file=sys.stdout)

    def on_outgoing(self, message: str) -> None:
        print(f"{_now()} {self._prefix}  > {message}", file=sys.stdout)

    def on_event(self, text: str) -> None:
        print(f"{_now()} {self._prefix} -- {text}", file=sys.stdout)


class ScreenLogFactory(LogFactory):
    def create(self, session_id: SessionID) -> ScreenLog:
        return ScreenLog(session_id)
