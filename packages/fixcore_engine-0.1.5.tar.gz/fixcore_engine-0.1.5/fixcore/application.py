"""Application interface — users subclass this to implement their trading logic."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from fixcore.message.message import Message
    from fixcore.session.session_id import SessionID


class Application(ABC):
    """Abstract base for FIX application callbacks.

    All methods are called from within the asyncio event loop.  Blocking
    implementations must delegate to ``asyncio.get_event_loop().run_in_executor``
    to avoid stalling other sessions.
    """

    @abstractmethod
    def on_create(self, session_id: SessionID) -> None:
        """Called when a session is created."""

    @abstractmethod
    def on_logon(self, session_id: SessionID) -> None:
        """Called after a successful Logon exchange."""

    @abstractmethod
    def on_logout(self, session_id: SessionID) -> None:
        """Called after a session logs out or disconnects."""

    @abstractmethod
    def to_admin(self, message: Message, session_id: SessionID) -> None:
        """Called before an admin message is sent; may mutate *message* in place."""

    @abstractmethod
    def to_app(self, message: Message, session_id: SessionID) -> None:
        """Called before an application message is sent; may mutate *message* in place."""

    @abstractmethod
    def from_admin(self, message: Message, session_id: SessionID) -> None:
        """Called when an admin message is received."""

    @abstractmethod
    def from_app(self, message: Message, session_id: SessionID) -> None:
        """Called when an application message is received."""
