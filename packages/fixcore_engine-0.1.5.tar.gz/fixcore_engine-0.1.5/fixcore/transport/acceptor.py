"""SocketAcceptor — listens for inbound FIX connections."""

from __future__ import annotations

import asyncio

from fixcore.application import Application
from fixcore.log.base import LogFactory
from fixcore.message.message import Message
from fixcore.session.session import Session
from fixcore.session.session_id import SessionID
from fixcore.session.session_settings import SessionSettings
from fixcore.session.state import TAG_BEGIN_STRING, TAG_SENDER_COMP_ID, TAG_TARGET_COMP_ID
from fixcore.store.factory import StoreFactory
from fixcore.transport.framer import MessageFramer


class SocketAcceptor:
    """Listens on a TCP port and routes incoming connections to the correct Session.

    One :class:`~fixcore.session.Session` is pre-created per configured
    acceptor session.  When a connection arrives, the first FIX message
    (expected to be a Logon) is used to look up the matching session by
    BeginString/SenderCompID/TargetCompID.

    Usage::

        acceptor = SocketAcceptor(settings, app, store_factory, log_factory)
        async with acceptor:
            await asyncio.sleep(3600)   # serve for an hour
    """

    def __init__(
        self,
        settings: SessionSettings,
        application: Application,
        store_factory: StoreFactory,
        log_factory: LogFactory,
    ) -> None:
        self._settings = settings
        self._app = application
        self._store_factory = store_factory
        self._log_factory = log_factory

        self._sessions: dict[SessionID, Session] = {}
        self._server: asyncio.Server | None = None
        self._connection_tasks: set[asyncio.Task[None]] = set()

        for sid in settings.session_ids:
            conn_type = settings.get_or(sid, "ConnectionType", "acceptor").lower()
            if conn_type == "acceptor":
                self._sessions[sid] = Session(
                    sid, settings, application,
                    store_factory.create(sid),
                    log_factory.create(sid),
                )

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Start the TCP server.  Binds to SocketAcceptPort (default 9878)."""
        # Use the first acceptor session to get host/port
        sid = next(iter(self._sessions))
        host = self._settings.get_or(sid, "SocketAcceptHost", "0.0.0.0")
        port = int(self._settings.get_or(sid, "SocketAcceptPort", "9878"))

        self._server = await asyncio.start_server(
            self._handle_connection, host, port
        )

    async def stop(self) -> None:
        """Stop accepting new connections and close all active sessions."""
        # Cancel all in-flight connection handlers (triggers their finally blocks)
        for task in list(self._connection_tasks):
            task.cancel()
        if self._connection_tasks:
            await asyncio.gather(*self._connection_tasks, return_exceptions=True)
            self._connection_tasks.clear()

        if self._server is not None:
            self._server.close()
            await self._server.wait_closed()
            self._server = None

    async def __aenter__(self) -> "SocketAcceptor":
        await self.start()
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.stop()

    @property
    def sessions(self) -> dict[SessionID, Session]:
        return dict(self._sessions)

    # ------------------------------------------------------------------
    # Connection handler
    # ------------------------------------------------------------------

    async def _handle_connection(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        framer = MessageFramer()
        session: Session | None = None
        task = asyncio.current_task()
        if task is not None:
            self._connection_tasks.add(task)

        async def send_fn(data: bytes) -> None:
            writer.write(data)
            await writer.drain()

        try:
            while True:
                try:
                    data = await reader.read(4096)
                except (ConnectionResetError, asyncio.IncompleteReadError, asyncio.CancelledError):
                    break
                if not data:
                    break

                for raw_msg in framer.feed(data):
                    if session is None:
                        session = self._find_session(raw_msg)
                        if session is None:
                            # Unknown session — close connection
                            return
                        await session.on_connect(send_fn)

                    await session.on_data(raw_msg)

        finally:
            task = asyncio.current_task()
            if task is not None:
                self._connection_tasks.discard(task)
            if session is not None:
                await session.on_disconnect()
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass

    def _find_session(self, raw_msg: bytes) -> Session | None:
        """Match an incoming message to a pre-configured session."""
        try:
            msg = Message.decode(raw_msg)
        except ValueError:
            return None

        begin = msg.header.get_or(TAG_BEGIN_STRING)
        sender = msg.header.get_or(TAG_SENDER_COMP_ID)
        target = msg.header.get_or(TAG_TARGET_COMP_ID)

        for sid, session in self._sessions.items():
            if (
                sid.begin_string == begin
                and sid.sender_comp_id == target   # our sender == their target
                and sid.target_comp_id == sender   # our target == their sender
            ):
                return session
        return None
