"""SocketInitiator — manages outbound FIX connections with auto-reconnect."""

from __future__ import annotations

import asyncio
import logging

from fixcore.application import Application

logger = logging.getLogger(__name__)
from fixcore.log.base import LogFactory
from fixcore.session.session import Session
from fixcore.session.session_id import SessionID
from fixcore.session.session_settings import SessionSettings
from fixcore.store.factory import StoreFactory
from fixcore.transport.framer import MessageFramer


class SocketInitiator:
    """Dials outbound TCP connections for each configured initiator session.

    Each session runs in its own :func:`asyncio.create_task` loop.  On
    disconnect the loop waits ``ReconnectInterval`` seconds (default 10) and
    tries again until :meth:`stop` is called.

    Usage::

        initiator = SocketInitiator(settings, app, store_factory, log_factory)
        async with initiator:
            await asyncio.sleep(3600)
    """

    def __init__(
        self,
        settings: SessionSettings,
        application: Application,
        store_factory: StoreFactory,
        log_factory: LogFactory,
    ) -> None:
        self._settings = settings
        self._app = application
        self._store_factory = store_factory
        self._log_factory = log_factory

        self._sessions: dict[SessionID, Session] = {}
        self._tasks: list[asyncio.Task[None]] = []
        self._stop_event = asyncio.Event()
        self._no_reconnect = asyncio.Event()

        for sid in settings.session_ids:
            conn_type = settings.get_or(sid, "ConnectionType", "initiator").lower()
            if conn_type == "initiator":
                self._sessions[sid] = Session(
                    sid, settings, application,
                    store_factory.create(sid),
                    log_factory.create(sid),
                )

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Launch a connect-loop task for each configured initiator session."""
        self._stop_event.clear()
        self._no_reconnect.clear()
        logger.info("SocketInitiator starting %d session(s)", len(self._sessions))
        for sid, session in self._sessions.items():
            task = asyncio.create_task(
                self._connect_loop(sid, session),
                name=f"initiator-{sid}",
            )
            self._tasks.append(task)
            logger.debug("Connect-loop task created for %s", sid)

    async def stop(self) -> None:
        """Signal all connect loops to exit and wait for them to finish."""
        self._stop_event.set()
        for task in self._tasks:
            task.cancel()
        if self._tasks:
            await asyncio.gather(*self._tasks, return_exceptions=True)
            self._tasks.clear()

    async def logout(self) -> None:
        """Send FIX Logout for all active sessions and disable auto-reconnect.

        The connect loop will exit cleanly after the connection drops rather
        than sleeping and retrying.  Call :meth:`start` to reconnect later.
        """
        self._no_reconnect.set()
        for session in self._sessions.values():
            if session.is_logged_on:
                await session.send_logout()

    async def __aenter__(self) -> "SocketInitiator":
        await self.start()
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.stop()

    @property
    def sessions(self) -> dict[SessionID, Session]:
        return dict(self._sessions)

    # ------------------------------------------------------------------
    # Per-session connect loop
    # ------------------------------------------------------------------

    async def _connect_loop(self, sid: SessionID, session: Session) -> None:
        host = self._settings.get(sid, "SocketConnectHost")
        port = int(self._settings.get(sid, "SocketConnectPort"))
        reconnect = self._settings.get_int(sid, "ReconnectInterval", 10)

        logger.info("[%s] Connect loop started — target %s:%s", sid, host, port)
        while not self._stop_event.is_set():
            logger.debug("[%s] Attempting connection to %s:%s", sid, host, port)
            try:
                reader, writer = await asyncio.open_connection(host, port)
            except OSError as exc:
                logger.warning("[%s] Connection failed: %s — retrying in %ss", sid, exc, reconnect)
                await self._interruptible_sleep(reconnect)
                continue

            logger.info("[%s] TCP connected to %s:%s", sid, host, port)
            framer = MessageFramer()

            async def send_fn(data: bytes, _w: asyncio.StreamWriter = writer) -> None:
                _w.write(data)
                await _w.drain()

            await session.on_connect(send_fn)
            logger.debug("[%s] on_connect complete — Logon sent", sid)

            try:
                while not self._stop_event.is_set():
                    try:
                        data = await reader.read(4096)
                    except (ConnectionResetError, asyncio.IncompleteReadError,
                            asyncio.CancelledError) as exc:
                        logger.info("[%s] Read interrupted: %s", sid, type(exc).__name__)
                        break
                    if not data:
                        logger.info("[%s] Connection closed by peer", sid)
                        break

                    logger.debug("[%s] Received %d bytes", sid, len(data))
                    for raw_msg in framer.feed(data):
                        await session.on_data(raw_msg)

            finally:
                logger.info("[%s] Disconnecting", sid)
                await session.on_disconnect()
                try:
                    writer.close()
                    await writer.wait_closed()
                except Exception:
                    pass
                framer.reset()

            if not self._stop_event.is_set() and not self._no_reconnect.is_set():
                logger.info("[%s] Waiting %ss before reconnect", sid, reconnect)
                await self._interruptible_sleep(reconnect)

    async def _interruptible_sleep(self, seconds: float) -> None:
        """Sleep for *seconds* but wake immediately if stop is requested."""
        try:
            await asyncio.wait_for(self._stop_event.wait(), timeout=seconds)
        except asyncio.TimeoutError:
            pass
