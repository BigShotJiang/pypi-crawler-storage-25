"""MessageFramer — splits a raw TCP byte stream into complete FIX messages.

FIX message structure on the wire::

    8=FIX.4.2\\x01          ← BeginString  (variable length)
    9=<body_length>\\x01    ← BodyLength   (variable length)
    35=A\\x01...            ← body         (exactly body_length bytes)
    10=NNN\\x01             ← CheckSum     (always exactly 7 bytes: "10=" + 3 digits + SOH)

Framing algorithm:
1. Scan for ``8=`` to sync to the start of a message.
2. Parse ``9=<N>\\x01`` to read BodyLength.
3. Wait until the buffer holds prefix + N + 7 bytes.
4. Slice out the complete message and repeat.
"""

from __future__ import annotations

# CheckSum field is always "10=NNN\x01" — exactly 7 bytes.
_CHECKSUM_LEN = 7


class MessageFramer:
    """Stateful byte-stream framer for FIX messages.

    Feed raw bytes in any chunk size; complete messages are returned.

    Example::

        framer = MessageFramer()
        for raw_msg in framer.feed(socket_data):
            process(raw_msg)
    """

    def __init__(self) -> None:
        self._buf: bytearray = bytearray()

    def feed(self, data: bytes) -> list[bytes]:
        """Append *data* to the internal buffer and return all complete messages."""
        self._buf.extend(data)
        messages: list[bytes] = []
        while True:
            msg = self._try_extract()
            if msg is None:
                break
            messages.append(msg)
        return messages

    def reset(self) -> None:
        """Discard all buffered bytes."""
        self._buf.clear()

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _try_extract(self) -> bytes | None:
        buf = self._buf

        # ── 1. Sync to BeginString ────────────────────────────────────
        start = buf.find(b"8=")
        if start == -1:
            # Keep a trailing '8' — it may be the first byte of '8=' once more data arrives
            if buf and buf[-1] == ord("8"):
                del buf[:-1]
            else:
                buf.clear()
            return None
        if start > 0:
            del buf[:start]  # discard garbage before 8=

        # ── 2. Find end of BeginString field ─────────────────────────
        bs_soh = buf.find(b"\x01")
        if bs_soh == -1:
            return None  # incomplete BeginString

        # ── 3. Parse BodyLength field (must immediately follow) ───────
        bl_start = bs_soh + 1
        if len(buf) < bl_start + 3:  # need at least "9=X"
            return None

        if buf[bl_start : bl_start + 2] != b"9=":
            # Malformed — skip past this "8=" and retry
            del buf[:2]
            return None

        bl_soh = buf.find(b"\x01", bl_start + 2)
        if bl_soh == -1:
            return None  # incomplete BodyLength field

        try:
            body_length = int(buf[bl_start + 2 : bl_soh])
        except ValueError:
            # Corrupt BodyLength — drop up to and including this SOH
            del buf[: bl_soh + 1]
            return None

        # ── 4. Wait for full message ──────────────────────────────────
        body_start = bl_soh + 1
        total = body_start + body_length + _CHECKSUM_LEN

        if len(buf) < total:
            return None

        msg = bytes(buf[:total])
        del buf[:total]
        return msg
