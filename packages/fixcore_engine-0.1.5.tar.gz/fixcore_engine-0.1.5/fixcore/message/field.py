"""FIX field and field-map primitives."""

from __future__ import annotations

from collections import OrderedDict
from typing import Iterator


class Field:
    """A single tag=value pair."""

    __slots__ = ("tag", "value")

    def __init__(self, tag: int, value: str) -> None:
        self.tag = tag
        self.value = value

    def __repr__(self) -> str:
        return f"Field({self.tag}={self.value!r})"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Field):
            return NotImplemented
        return self.tag == other.tag and self.value == other.value


class FieldMap:
    """Ordered collection of FIX fields (tag → value).

    Preserves insertion order.  Repeated tags are allowed (e.g. repeating
    groups) and stored in order of insertion.
    """

    def __init__(self) -> None:
        # tag → list[str] to support repeating tags
        self._fields: OrderedDict[int, list[str]] = OrderedDict()

    # ------------------------------------------------------------------
    # Mutation
    # ------------------------------------------------------------------

    def set_field(self, tag: int, value: str) -> None:
        """Set *tag* to *value*, replacing any existing value(s)."""
        self._fields[tag] = [value]

    def append_field(self, tag: int, value: str) -> None:
        """Append *value* for *tag* (used for repeating groups)."""
        if tag in self._fields:
            self._fields[tag].append(value)
        else:
            self._fields[tag] = [value]

    def remove_field(self, tag: int) -> None:
        self._fields.pop(tag, None)

    # ------------------------------------------------------------------
    # Access
    # ------------------------------------------------------------------

    def get_field(self, tag: int) -> str:
        """Return the first value for *tag*; raises KeyError if absent."""
        return self._fields[tag][0]

    def get_field_or(self, tag: int, default: str = "") -> str:
        vals = self._fields.get(tag)
        return vals[0] if vals else default

    def has_field(self, tag: int) -> bool:
        return tag in self._fields

    # ------------------------------------------------------------------
    # Iteration
    # ------------------------------------------------------------------

    def __iter__(self) -> Iterator[Field]:
        """Yield all fields in insertion order, expanding repeated tags."""
        for tag, values in self._fields.items():
            for value in values:
                yield Field(tag, value)

    def __len__(self) -> int:
        return sum(len(v) for v in self._fields.values())

    def __repr__(self) -> str:
        pairs = ", ".join(f"{t}={v!r}" for t, vs in self._fields.items() for v in vs)
        return f"{self.__class__.__name__}({pairs})"


class Group:
    """One repeating group instance.

    Holds the member fields for a single row within a FIX repeating group
    (e.g. one entry in ``NoMsgTypes`` or one leg in ``NoLegs``).

    Usage::

        g = Group()
        g.set_field(372, "D")   # RefMsgType
        g.set_field(385, "S")   # MsgDirection
        msg.add_group(384, g)   # NoMsgTypes count tag

    Nested groups are supported via :meth:`add_group` / :meth:`get_groups`.
    """

    def __init__(self) -> None:
        self._fields: dict[int, str] = {}
        # Insertion order for both simple fields and nested-group count tags
        self._order: list[int] = []
        self._groups: dict[int, list["Group"]] = {}

    # ------------------------------------------------------------------
    # Simple field access (mirrors Message body API)
    # ------------------------------------------------------------------

    def set_field(self, tag: int, value: str) -> None:
        if tag not in self._fields:
            self._order.append(tag)
        self._fields[tag] = value

    def get_field(self, tag: int) -> str:
        """Return the value for *tag*; raises KeyError if absent."""
        return self._fields[tag]

    def get_field_or(self, tag: int, default: str = "") -> str:
        return self._fields.get(tag, default)

    def has_field(self, tag: int) -> bool:
        return tag in self._fields

    # ------------------------------------------------------------------
    # Nested groups
    # ------------------------------------------------------------------

    def add_group(self, count_tag: int, instance: "Group") -> None:
        """Append a nested group instance and update the count field."""
        if count_tag not in self._groups:
            self._order.append(count_tag)
            self._groups[count_tag] = []
        self._groups[count_tag].append(instance)
        self._fields[count_tag] = str(len(self._groups[count_tag]))

    def get_groups(self, count_tag: int) -> "list[Group]":
        return self._groups.get(count_tag, [])

    def __repr__(self) -> str:
        pairs = ", ".join(f"{t}={v!r}" for t, v in self._fields.items())
        return f"Group({pairs})"
