"""FIX message exceptions."""


class InvalidMessage(Exception):
    """Raised when a FIX message fails DataDictionary validation."""


class UnsupportedVersion(Exception):
    """Raised when a message's BeginString has no matching DataDictionary."""


class FieldNotFound(KeyError):
    """Raised when a required field is absent from a message."""


class UnsupportedMessageType(Exception):
    """Raised by MessageCracker.on_message when no handler is registered for a MsgType."""

    def __init__(self, msg_type: str) -> None:
        super().__init__(f"No handler for MsgType {msg_type!r}")
        self.msg_type = msg_type
