"""DataDictionary — loads a QuickFIX XML spec and validates FIX messages."""

from __future__ import annotations

import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path

from fixcore.message.exceptions import InvalidMessage

# Imported here to avoid circular import at module level; also used as constants
TAG_BODY_LENGTH = 9
TAG_CHECKSUM = 10


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class FieldDef:
    """Definition of a single FIX field."""
    number: int
    name: str
    type: str                              # STRING, INT, PRICE, QTY, CHAR, …
    values: dict[str, str] = field(default_factory=dict)  # enum → description


@dataclass
class GroupDef:
    """Definition of a repeating group."""
    number_tag: int                        # NoXxx counter tag (e.g. 78 NoAllocs)
    delimiter: int                         # first expected tag inside each instance
    members: list[int]                     # ordered member tags
    nested_groups: dict[int, "GroupDef"] = field(default_factory=dict)


@dataclass
class MessageDef:
    """Definition of a FIX message type."""
    name: str
    msg_type: str                          # e.g. "D", "0", "A"
    msg_cat: str                           # "admin" | "app"
    required: set[int] = field(default_factory=set)
    optional: set[int] = field(default_factory=set)
    groups: dict[int, GroupDef] = field(default_factory=dict)

    @property
    def all_fields(self) -> set[int]:
        return self.required | self.optional


# ---------------------------------------------------------------------------
# DataDictionary
# ---------------------------------------------------------------------------

class DataDictionary:
    """Parses a QuickFIX-format XML spec and validates Message objects.

    Usage::

        dd = DataDictionary.from_xml("specs/FIX42.xml")
        dd.validate(message)          # raises InvalidMessage on failure
    """

    def __init__(self) -> None:
        self._version: str = ""
        self._fields_by_number: dict[int, FieldDef] = {}
        self._fields_by_name: dict[str, int] = {}          # name → tag number
        self._messages: dict[str, MessageDef] = {}         # msg_type → MessageDef
        self._header: dict[int, bool] = {}                 # tag → required
        self._trailer: dict[int, bool] = {}

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    @classmethod
    def from_xml(cls, path: str | Path) -> "DataDictionary":
        """Load a DataDictionary from a QuickFIX XML spec file."""
        tree = ET.parse(str(path))
        root = tree.getroot()
        dd = cls()
        dd._version = _build_version(root)
        dd._load_fields(root)
        dd._load_header(root)
        dd._load_trailer(root)
        dd._load_messages(root)
        return dd

    @classmethod
    def from_string(cls, xml_text: str) -> "DataDictionary":
        """Load a DataDictionary from an XML string (useful in tests)."""
        root = ET.fromstring(xml_text)
        dd = cls()
        dd._version = _build_version(root)
        dd._load_fields(root)
        dd._load_header(root)
        dd._load_trailer(root)
        dd._load_messages(root)
        return dd

    # ------------------------------------------------------------------
    # Internal loaders
    # ------------------------------------------------------------------

    def _load_fields(self, root: ET.Element) -> None:
        fields_el = root.find("fields")
        if fields_el is None:
            return
        for f in fields_el.findall("field"):
            number = int(f.get("number", 0))
            name = f.get("name", "")
            ftype = f.get("type", "STRING").upper()
            values = {
                v.get("enum", ""): v.get("description", "")
                for v in f.findall("value")
            }
            fd = FieldDef(number=number, name=name, type=ftype, values=values)
            self._fields_by_number[number] = fd
            self._fields_by_name[name] = number

    def _load_header(self, root: ET.Element) -> None:
        header_el = root.find("header")
        if header_el is None:
            return
        for f in header_el.findall("field"):
            tag = self._resolve_tag(f.get("name", ""))
            if tag is not None:
                self._header[tag] = f.get("required", "N").upper() == "Y"

    def _load_trailer(self, root: ET.Element) -> None:
        trailer_el = root.find("trailer")
        if trailer_el is None:
            return
        for f in trailer_el.findall("field"):
            tag = self._resolve_tag(f.get("name", ""))
            if tag is not None:
                self._trailer[tag] = f.get("required", "N").upper() == "Y"

    def _load_messages(self, root: ET.Element) -> None:
        messages_el = root.find("messages")
        if messages_el is None:
            return
        for msg_el in messages_el.findall("message"):
            msg_type = msg_el.get("msgtype", "")
            name = msg_el.get("name", "")
            cat = msg_el.get("msgcat", "app").lower()
            msg_def = MessageDef(name=name, msg_type=msg_type, msg_cat=cat)
            self._parse_fields_and_groups(msg_el, msg_def.required, msg_def.optional, msg_def.groups)
            self._messages[msg_type] = msg_def

    def _parse_fields_and_groups(
        self,
        parent: ET.Element,
        required: set[int],
        optional: set[int],
        groups: dict[int, GroupDef],
    ) -> None:
        for child in parent:
            if child.tag == "field":
                tag = self._resolve_tag(child.get("name", ""))
                if tag is None:
                    continue
                if child.get("required", "N").upper() == "Y":
                    required.add(tag)
                else:
                    optional.add(tag)
            elif child.tag == "group":
                tag = self._resolve_tag(child.get("name", ""))
                if tag is None:
                    continue
                req = child.get("required", "N").upper() == "Y"
                if req:
                    required.add(tag)
                else:
                    optional.add(tag)
                group_def = self._parse_group(tag, child)
                groups[tag] = group_def

    def _parse_group(self, number_tag: int, group_el: ET.Element) -> GroupDef:
        members: list[int] = []
        nested: dict[int, GroupDef] = {}
        delimiter: int = 0
        for child in group_el:
            if child.tag == "field":
                tag = self._resolve_tag(child.get("name", ""))
                if tag is not None:
                    if delimiter == 0:
                        delimiter = tag
                    members.append(tag)
            elif child.tag == "group":
                tag = self._resolve_tag(child.get("name", ""))
                if tag is not None:
                    if delimiter == 0:
                        delimiter = tag
                    members.append(tag)
                    nested[tag] = self._parse_group(tag, child)
        return GroupDef(number_tag=number_tag, delimiter=delimiter, members=members, nested_groups=nested)

    def _resolve_tag(self, name: str) -> int | None:
        return self._fields_by_name.get(name)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @property
    def version(self) -> str:
        return self._version

    def field_def(self, tag: int) -> FieldDef:
        """Return FieldDef for *tag*; raises KeyError if unknown."""
        return self._fields_by_number[tag]

    def field_tag(self, name: str) -> int:
        """Return the tag number for field *name*; raises KeyError if unknown."""
        return self._fields_by_name[name]

    def message_def(self, msg_type: str) -> MessageDef:
        """Return MessageDef for *msg_type*; raises KeyError if unknown."""
        return self._messages[msg_type]

    def is_header_field(self, tag: int) -> bool:
        return tag in self._header

    def is_trailer_field(self, tag: int) -> bool:
        return tag in self._trailer

    def validate(self, message: "Message") -> None:  # type: ignore[name-defined]
        """Validate *message* against this DataDictionary.

        Checks:
        - MsgType is known
        - All required header fields are present
        - All required body fields are present
        - All required trailer fields are present

        Raises :exc:`InvalidMessage` on the first violation found.
        """
        from fixcore.message.message import Message  # local to avoid circular

        msg_type = message.msg_type
        if not msg_type:
            raise InvalidMessage("Missing MsgType (tag 35)")

        msg_def = self._messages.get(msg_type)
        if msg_def is None:
            raise InvalidMessage(f"Unknown MsgType: {msg_type!r}")

        # BodyLength and CheckSum are computed by the engine on encode — skip them
        COMPUTED_TAGS = {TAG_BODY_LENGTH, TAG_CHECKSUM}

        # Required header fields
        for tag, required in self._header.items():
            if tag in COMPUTED_TAGS:
                continue
            if required and not message.header.has(tag):
                name = self._fields_by_number.get(tag, FieldDef(tag, str(tag), "STRING")).name
                raise InvalidMessage(f"Missing required header field: {name} ({tag})")

        # Required body fields
        for tag in msg_def.required:
            if not message.has_field(tag):
                name = self._fields_by_number.get(tag, FieldDef(tag, str(tag), "STRING")).name
                raise InvalidMessage(
                    f"Missing required field: {name} ({tag}) in {msg_def.name}"
                )

        # Required trailer fields
        for tag, required in self._trailer.items():
            if tag in COMPUTED_TAGS:
                continue
            if required and not message.trailer.has(tag):
                name = self._fields_by_number.get(tag, FieldDef(tag, str(tag), "STRING")).name
                raise InvalidMessage(f"Missing required trailer field: {name} ({tag})")

    def validate_field_value(self, tag: int, value: str) -> bool:
        """Return True if *value* is a valid enum for *tag*, or if *tag* has no enum."""
        fd = self._fields_by_number.get(tag)
        if fd is None or not fd.values:
            return True
        return value in fd.values


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _build_version(root: ET.Element) -> str:
    fix_type = root.get("type", "FIX")
    major = root.get("major", "4")
    minor = root.get("minor", "2")
    sp = root.get("servicepack", "")
    version = f"{fix_type}.{major}.{minor}"
    if sp and sp != "0":
        version += f"SP{sp}"
    return version
