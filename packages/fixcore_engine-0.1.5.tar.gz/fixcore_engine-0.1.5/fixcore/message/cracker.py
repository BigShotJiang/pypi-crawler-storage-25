"""MessageCracker — mixin that dispatches fromApp messages to typed handler methods.

Usage::

    class MyApp(Application, MessageCracker):
        def from_app(self, message: Message, session_id: SessionID) -> None:
            self.crack(message, session_id)

        def on_new_order_single(self, message: Message, session_id: SessionID) -> None:
            clord_id = message.get_field(11)
            ...

        def on_execution_report(self, message: Message, session_id: SessionID) -> None:
            ...

Handler method names follow the convention ``on_<snake_case_message_name>``.  If
no matching method is found, :meth:`on_message` is called, which raises
:exc:`~fixcore.message.exceptions.UnsupportedMessageType` by default.

Custom / venue-specific message types can be registered at class or instance
level::

    MessageCracker.register("U1", "on_custom_order")   # class-level
"""

from __future__ import annotations

from fixcore.message.exceptions import UnsupportedMessageType
from fixcore.message.message import Message
from fixcore.session.session_id import SessionID


# ---------------------------------------------------------------------------
# MsgType → handler method name registry
# ---------------------------------------------------------------------------

# FIX 4.2 / 4.4 application messages
_REGISTRY: dict[str, str] = {
    # Orders
    "D": "on_new_order_single",
    "F": "on_order_cancel_request",
    "G": "on_order_cancel_replace_request",
    "H": "on_order_status_request",
    "Q": "on_dont_know_trade",
    # Executions / responses
    "8": "on_execution_report",
    "9": "on_order_cancel_reject",
    # Lists
    "E": "on_new_order_list",
    "K": "on_list_cancel_request",
    "L": "on_list_execute",
    "M": "on_list_status_request",
    "N": "on_list_status",
    # Market data
    "V": "on_market_data_request",
    "W": "on_market_data_snapshot_full_refresh",
    "X": "on_market_data_incremental_refresh",
    "Y": "on_market_data_request_reject",
    # Quotes
    "R": "on_quote_request",
    "S": "on_quote",
    "Z": "on_quote_cancel",
    "a": "on_quote_status_request",
    "b": "on_mass_quote_acknowledgement",
    "i": "on_mass_quote",
    # Security / reference data
    "c": "on_security_definition_request",
    "d": "on_security_definition",
    "e": "on_security_status_request",
    "f": "on_security_status",
    "g": "on_trading_session_status_request",
    "h": "on_trading_session_status",
    # Allocation / settlement
    "J": "on_allocation",
    "P": "on_allocation_ack",
    "T": "on_settlement_instructions",
    # News / email
    "B": "on_news",
    "C": "on_email",
    # Business / application reject
    "j": "on_business_message_reject",
    # FIX 4.4 / 5.0 additions
    "AB": "on_new_order_multileg",
    "AC": "on_multileg_order_cancel_replace",
    "AD": "on_trade_capture_report_request",
    "AE": "on_trade_capture_report",
    "AF": "on_order_mass_status_request",
    "AG": "on_quote_request_reject",
    "AH": "on_rfq_request",
    "AI": "on_quote_status_report",
    "AJ": "on_quote_response",
    "AK": "on_confirmation",
    "AL": "on_position_maintenance_request",
    "AM": "on_position_maintenance_report",
    "AN": "on_request_for_positions",
    "AO": "on_request_for_positions_ack",
    "AP": "on_position_report",
    "AQ": "on_trade_capture_report_request_ack",
    "AR": "on_trade_capture_report_ack",
    "AS": "on_allocation_report",
    "AT": "on_allocation_report_ack",
    "AU": "on_confirmation_ack",
    "AV": "on_settlement_instruction_request",
    "AW": "on_assignment_report",
    "AX": "on_collateral_request",
    "AY": "on_collateral_assignment",
    "AZ": "on_collateral_response",
}


class MessageCracker:
    """Mixin providing MsgType-based dispatch for :meth:`Application.from_app`.

    Combine with :class:`~fixcore.application.Application`::

        class MyApp(Application, MessageCracker):
            def from_app(self, message, session_id):
                self.crack(message, session_id)

            def on_new_order_single(self, message, session_id):
                ...
    """

    # Instance-level overrides (populated by register_instance or subclass __init__)
    _instance_registry: dict[str, str]

    # ------------------------------------------------------------------
    # Dispatch
    # ------------------------------------------------------------------

    def crack(self, message: Message, session_id: SessionID) -> None:
        """Dispatch *message* to the appropriate typed handler.

        Resolution order:
        1. Instance registry (set via :meth:`register_instance`)
        2. Class-level registry (set via :meth:`register`)
        3. :meth:`on_message` fallback
        """
        msg_type = message.msg_type

        # Instance overrides take precedence
        instance_reg = getattr(self, "_instance_registry", {})
        handler_name = instance_reg.get(msg_type) or _REGISTRY.get(msg_type)

        if handler_name:
            handler = getattr(self, handler_name, None)
            if handler is not None:
                handler(message, session_id)
                return

        self.on_message(message, session_id)

    def on_message(self, message: Message, session_id: SessionID) -> None:
        """Fallback called when no specific handler is found.

        Raises :exc:`~fixcore.message.exceptions.UnsupportedMessageType`
        by default.  Override to handle all unknown message types generically.
        """
        raise UnsupportedMessageType(message.msg_type)

    # ------------------------------------------------------------------
    # Registration helpers
    # ------------------------------------------------------------------

    @classmethod
    def register(cls, msg_type: str, handler_name: str) -> None:
        """Register a class-wide handler for *msg_type*.

        Example::

            MessageCracker.register("U1", "on_custom_order")
        """
        _REGISTRY[msg_type] = handler_name

    def register_instance(self, msg_type: str, handler_name: str) -> None:
        """Register a handler for *msg_type* on this instance only."""
        if not hasattr(self, "_instance_registry"):
            self._instance_registry = {}
        self._instance_registry[msg_type] = handler_name

    # ------------------------------------------------------------------
    # Default typed handlers (all call on_message — override to handle)
    # ------------------------------------------------------------------

    def on_new_order_single(self, message: Message, session_id: SessionID) -> None:
        self.on_message(message, session_id)

    def on_execution_report(self, message: Message, session_id: SessionID) -> None:
        self.on_message(message, session_id)

    def on_order_cancel_request(self, message: Message, session_id: SessionID) -> None:
        self.on_message(message, session_id)

    def on_order_cancel_reject(self, message: Message, session_id: SessionID) -> None:
        self.on_message(message, session_id)

    def on_order_cancel_replace_request(self, message: Message, session_id: SessionID) -> None:
        self.on_message(message, session_id)

    def on_order_status_request(self, message: Message, session_id: SessionID) -> None:
        self.on_message(message, session_id)

    def on_market_data_request(self, message: Message, session_id: SessionID) -> None:
        self.on_message(message, session_id)

    def on_market_data_snapshot_full_refresh(self, message: Message, session_id: SessionID) -> None:
        self.on_message(message, session_id)

    def on_market_data_incremental_refresh(self, message: Message, session_id: SessionID) -> None:
        self.on_message(message, session_id)

    def on_market_data_request_reject(self, message: Message, session_id: SessionID) -> None:
        self.on_message(message, session_id)

    def on_quote_request(self, message: Message, session_id: SessionID) -> None:
        self.on_message(message, session_id)

    def on_quote(self, message: Message, session_id: SessionID) -> None:
        self.on_message(message, session_id)

    def on_news(self, message: Message, session_id: SessionID) -> None:
        self.on_message(message, session_id)

    def on_business_message_reject(self, message: Message, session_id: SessionID) -> None:
        self.on_message(message, session_id)


# ---------------------------------------------------------------------------
# Auto-generate default handlers for any registered handler name that doesn't
# already have an explicit implementation on the class.
# ---------------------------------------------------------------------------

def _make_default_handler(name: str):  # noqa: ANN202
    def handler(self: MessageCracker, message: Message, session_id: SessionID) -> None:
        self.on_message(message, session_id)
    handler.__name__ = name
    handler.__qualname__ = f"MessageCracker.{name}"
    return handler


for _handler_name in set(_REGISTRY.values()):
    if not hasattr(MessageCracker, _handler_name):
        setattr(MessageCracker, _handler_name, _make_default_handler(_handler_name))
