"""FIX Message — Header / Body / Trailer with encode/decode."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from fixcore.message.data_dictionary import DataDictionary, GroupDef
    from fixcore.message.field import Group

SOH = b"\x01"
SOH_INT = 0x01

# Standard header/trailer tags
TAG_BEGIN_STRING = 8
TAG_BODY_LENGTH = 9
TAG_MSG_TYPE = 35
TAG_CHECKSUM = 10

# Standard FIX header tags — routed to Header during decode
HEADER_TAGS: frozenset[int] = frozenset({
    8,   # BeginString
    9,   # BodyLength
    35,  # MsgType
    49,  # SenderCompID
    56,  # TargetCompID
    34,  # MsgSeqNum
    52,  # SendingTime
    43,  # PossDupFlag
    97,  # PossResend
    122, # OrigSendingTime
    115, # OnBehalfOfCompID
    128, # DeliverToCompID
    129, # DeliverToSubID
    142, # SenderLocationID
    143, # TargetLocationID
    144, # OnBehalfOfLocationID
    145, # DeliverToLocationID
    50,  # SenderSubID
    57,  # TargetSubID
    116, # OnBehalfOfSubID
})


class Header:
    """Thin wrapper — tag ordering for the standard header is enforced on encode."""

    # Tags that must appear first (in order) per FIX spec
    LEADING_TAGS = (TAG_BEGIN_STRING, TAG_BODY_LENGTH, TAG_MSG_TYPE)

    def __init__(self) -> None:
        self._fields: dict[int, str] = {}
        self._order: list[int] = []

    def set(self, tag: int, value: str) -> None:
        if tag not in self._fields:
            self._order.append(tag)
        self._fields[tag] = value

    def get(self, tag: int) -> str:
        return self._fields[tag]

    def get_or(self, tag: int, default: str = "") -> str:
        return self._fields.get(tag, default)

    def has(self, tag: int) -> bool:
        return tag in self._fields

    def remove_field(self, tag: int) -> None:
        self._fields.pop(tag, None)
        if tag in self._order:
            self._order.remove(tag)

    def items(self) -> list[tuple[int, str]]:
        """Return fields in FIX-spec order: leading tags first, then the rest."""
        leading = [(t, self._fields[t]) for t in self.LEADING_TAGS if t in self._fields]
        rest = [
            (t, self._fields[t])
            for t in self._order
            if t not in self.LEADING_TAGS
        ]
        return leading + rest


class Trailer:
    def __init__(self) -> None:
        self._fields: dict[int, str] = {}

    def set(self, tag: int, value: str) -> None:
        self._fields[tag] = value

    def get(self, tag: int) -> str:
        return self._fields[tag]

    def has(self, tag: int) -> bool:
        return tag in self._fields

    def items(self) -> list[tuple[int, str]]:
        # Checksum must always be last
        result = [(t, v) for t, v in self._fields.items() if t != TAG_CHECKSUM]
        if TAG_CHECKSUM in self._fields:
            result.append((TAG_CHECKSUM, self._fields[TAG_CHECKSUM]))
        return result


class Message:
    """A complete FIX message.

    Encoding
    --------
    Call ``encode()`` to produce the wire bytes.  BodyLength (tag 9) and
    CheckSum (tag 10) are computed automatically — any values set by the
    caller are overwritten.

    Decoding
    --------
    Call ``Message.decode(raw)`` to parse raw bytes (SOH-delimited) into a
    Message instance.  BodyLength and CheckSum are validated.
    """

    def __init__(self) -> None:
        self.header = Header()
        self.body: dict[int, str] = {}
        self._body_order: list[int] = []
        self._body_groups: dict[int, list[Group]] = {}
        self.trailer = Trailer()

    # ------------------------------------------------------------------
    # Body helpers
    # ------------------------------------------------------------------

    def set_field(self, tag: int, value: str) -> None:
        if tag not in self.body:
            self._body_order.append(tag)
        self.body[tag] = value

    def get_field(self, tag: int) -> str:
        return self.body[tag]

    def get_field_or(self, tag: int, default: str = "") -> str:
        return self.body.get(tag, default)

    def has_field(self, tag: int) -> bool:
        return tag in self.body

    # ------------------------------------------------------------------
    # Repeating group API
    # ------------------------------------------------------------------

    def add_group(self, count_tag: int, instance: Group) -> None:
        """Append a repeating group instance and keep the count field in sync."""
        self._body_groups.setdefault(count_tag, []).append(instance)
        self.set_field(count_tag, str(len(self._body_groups[count_tag])))

    def get_groups(self, count_tag: int) -> list[Group]:
        """Return all instances for *count_tag* (empty list if none)."""
        return self._body_groups.get(count_tag, [])

    def group_count(self, count_tag: int) -> int:
        return len(self._body_groups.get(count_tag, []))

    # ------------------------------------------------------------------
    # Encode
    # ------------------------------------------------------------------

    def encode(self) -> bytes:
        """Serialise to wire format, computing BodyLength and CheckSum."""
        body_parts: list[bytes] = []

        # tag 35 first (part of header but counted in body length)
        if self.header.has(TAG_MSG_TYPE):
            body_parts.append(_field_bytes(TAG_MSG_TYPE, self.header.get(TAG_MSG_TYPE)))

        # remaining header fields (excluding 8, 9, 35)
        for tag, value in self.header.items():
            if tag not in (TAG_BEGIN_STRING, TAG_BODY_LENGTH, TAG_MSG_TYPE):
                body_parts.append(_field_bytes(tag, value))

        # body — group-aware
        for tag in self._body_order:
            if tag in self._body_groups:
                # Emit count then each instance's fields (recursive for nesting)
                body_parts.append(_field_bytes(tag, str(len(self._body_groups[tag]))))
                for instance in self._body_groups[tag]:
                    body_parts.extend(_encode_group_instance(instance))
            else:
                body_parts.append(_field_bytes(tag, self.body[tag]))

        # trailer (excluding checksum)
        for tag, value in self.trailer.items():
            if tag != TAG_CHECKSUM:
                body_parts.append(_field_bytes(tag, value))

        body_bytes = b"".join(body_parts)
        body_length = len(body_bytes)

        prefix = (
            _field_bytes(TAG_BEGIN_STRING, self.header.get(TAG_BEGIN_STRING))
            + _field_bytes(TAG_BODY_LENGTH, str(body_length))
        )

        checksum = _checksum(prefix + body_bytes)
        suffix = _field_bytes(TAG_CHECKSUM, f"{checksum:03d}")

        return prefix + body_bytes + suffix

    # ------------------------------------------------------------------
    # Decode
    # ------------------------------------------------------------------

    @classmethod
    def decode(
        cls,
        raw: bytes,
        data_dictionary: DataDictionary | None = None,
    ) -> "Message":
        """Parse *raw* SOH-delimited bytes into a Message.

        Raises ValueError on malformed input or checksum/body-length mismatch.

        If *data_dictionary* is supplied, repeating groups are extracted and
        stored via :meth:`add_group` / :meth:`get_groups`.  Without it the
        body is populated as flat fields (backward-compatible behaviour).
        """
        fields = _parse_fields(raw)
        if not fields:
            raise ValueError("Empty message")

        msg = cls()

        # Separate header/trailer from body fields
        body_fields: list[tuple[int, str]] = []
        for tag, value in fields:
            if tag in HEADER_TAGS:
                msg.header.set(tag, value)
            elif tag == TAG_CHECKSUM:
                msg.trailer.set(tag, value)
            else:
                body_fields.append((tag, value))

        if data_dictionary is not None:
            # Group-aware body parse
            msg_type = msg.header.get_or(TAG_MSG_TYPE)
            try:
                msg_def = data_dictionary.message_def(msg_type)
                group_defs: dict[int, GroupDef] = msg_def.groups
            except Exception:
                group_defs = {}
            _populate_body(msg, body_fields, group_defs)
        else:
            # Flat parse — backward compatible
            for tag, value in body_fields:
                msg.set_field(tag, value)

        _validate(raw, msg)
        return msg

    # ------------------------------------------------------------------
    # Convenience
    # ------------------------------------------------------------------

    @property
    def msg_type(self) -> str:
        return self.header.get_or(TAG_MSG_TYPE)

    def __repr__(self) -> str:
        raw = self.encode()
        return raw.replace(SOH, b"|").decode("latin-1")


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _encode_group_instance(group: Group) -> list[bytes]:
    """Recursively serialise one repeating group instance to a list of bytes."""
    parts: list[bytes] = []
    for tag in group._order:
        if tag in group._groups:
            parts.append(_field_bytes(tag, str(len(group._groups[tag]))))
            for nested in group._groups[tag]:
                parts.extend(_encode_group_instance(nested))
        else:
            parts.append(_field_bytes(tag, group._fields[tag]))
    return parts


def _populate_body(
    msg: Message,
    body_fields: list[tuple[int, str]],
    group_defs: dict[int, GroupDef],
) -> None:
    """Populate msg body from *body_fields*, extracting groups where defined."""
    pos = 0
    while pos < len(body_fields):
        tag, value = body_fields[pos]
        if tag in group_defs:
            count = int(value) if value.isdigit() else 0
            pos += 1
            instances, pos = _extract_groups(body_fields, pos, group_defs[tag], count)
            # Store count so has_field / get_field still work
            msg.set_field(tag, str(count))
            for inst in instances:
                msg._body_groups.setdefault(tag, []).append(inst)
        else:
            msg.set_field(tag, value)
            pos += 1


def _extract_groups(
    flat: list[tuple[int, str]],
    pos: int,
    group_def: GroupDef,
    count: int,
) -> tuple[list[Group], int]:
    """Extract *count* group instances from *flat* starting at *pos*.

    Returns ``(instances, new_pos)``.
    """
    from fixcore.message.field import Group  # local import avoids circular

    instances: list[Group] = []
    for _ in range(count):
        if pos >= len(flat):
            break
        tag, value = flat[pos]
        # Each instance must start with the delimiter tag
        if tag != group_def.delimiter:
            break
        instance = Group()
        instance.set_field(tag, value)
        pos += 1

        # Consume member tags until the delimiter appears again (next instance)
        # or we hit a tag that doesn't belong to this group
        all_members = set(group_def.members) | set(group_def.nested_groups)
        while pos < len(flat):
            tag, value = flat[pos]
            if tag == group_def.delimiter:
                break  # start of next instance
            if tag not in all_members:
                break  # tag belongs to parent scope
            if tag in group_def.nested_groups:
                nested_count = int(value) if value.isdigit() else 0
                pos += 1
                nested_insts, pos = _extract_groups(
                    flat, pos, group_def.nested_groups[tag], nested_count
                )
                instance._fields[tag] = str(nested_count)
                instance._order.append(tag)
                instance._groups[tag] = nested_insts
            else:
                instance.set_field(tag, value)
                pos += 1

        instances.append(instance)

    return instances, pos


def _field_bytes(tag: int, value: str) -> bytes:
    return f"{tag}={value}".encode("latin-1") + SOH


def _checksum(data: bytes) -> int:
    return sum(data) % 256


def _parse_fields(raw: bytes) -> list[tuple[int, str]]:
    fields: list[tuple[int, str]] = []
    for part in raw.split(SOH):
        if not part:
            continue
        sep = part.find(b"=")
        if sep == -1:
            raise ValueError(f"Malformed field (no '='): {part!r}")
        tag = int(part[:sep])
        value = part[sep + 1 :].decode("latin-1")
        fields.append((tag, value))
    return fields


def _validate(raw: bytes, msg: Message) -> None:
    # Validate checksum
    checksum_idx = raw.rfind(b"\x0110=")
    if checksum_idx == -1:
        raise ValueError("Missing CheckSum field (tag 10)")
    computed = _checksum(raw[: checksum_idx + 1])  # include the leading SOH
    declared = int(msg.trailer.get(TAG_CHECKSUM))
    if computed != declared:
        raise ValueError(f"CheckSum mismatch: computed {computed:03d}, got {declared:03d}")

    # Validate body length
    if msg.header.has(TAG_BODY_LENGTH):
        declared_len = int(msg.header.get(TAG_BODY_LENGTH))
        # body length = bytes from tag 35 up to (not including) tag 10 field
        start = raw.find(b"35=")
        end = raw.rfind(b"\x0110=") + 1  # include the SOH before tag 10
        actual_len = end - start
        if actual_len != declared_len:
            raise ValueError(
                f"BodyLength mismatch: declared {declared_len}, actual {actual_len}"
            )
