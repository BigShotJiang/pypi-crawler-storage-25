"""FIX Engine GUI — aiohttp backend + browser frontend.

Starts a local HTTP server, opens the default browser, and drives the
FIX engine from the same asyncio event loop (no threading needed).

Run:
    fixcore-gui
    fixcore-gui --port 8765
"""

from __future__ import annotations

import asyncio
import json
import subprocess
import sys
import webbrowser
from pathlib import Path
from typing import Any

try:
    from aiohttp import web
except ImportError:
    print("aiohttp is required:  pip install \"fixcore-engine[gui]\"")
    sys.exit(1)

from fixcore.application import Application
from fixcore.log.base import Log, LogFactory
from fixcore.message.message import Message
from fixcore.session.session_id import SessionID
from fixcore.session.session_settings import SessionSettings
from fixcore.store.factory import FileStoreFactory, MemoryStoreFactory
from fixcore.transport.acceptor import SocketAcceptor
from fixcore.transport.initiator import SocketInitiator

# ---------------------------------------------------------------------------
# WebSocket connections — used to push engine events to the browser
# ---------------------------------------------------------------------------

_ws_connections: set[web.WebSocketResponse] = set()


def _push_event(event_type: str, **kwargs: Any) -> None:
    """Push a JSON event to all connected browser tabs."""
    if not _ws_connections:
        return
    payload = json.dumps({"type": event_type, **kwargs})
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return
    for ws in list(_ws_connections):
        loop.create_task(ws.send_str(payload))


# ---------------------------------------------------------------------------
# Bridge: Application + Log callbacks → browser via WebSocket
# ---------------------------------------------------------------------------

def _sid_key(sid: SessionID) -> str:
    return f"{sid.sender_comp_id}/{sid.target_comp_id}/{sid.begin_string}"


class GUIApplication(Application):
    def on_create(self, sid: SessionID) -> None:
        pass

    def on_logon(self, sid: SessionID) -> None:
        _push_event("logon", sid=_sid_key(sid))

    def on_logout(self, sid: SessionID) -> None:
        _push_event("logout", sid=_sid_key(sid))

    def to_admin(self, msg: Message, sid: SessionID) -> None:
        pass

    def to_app(self, msg: Message, sid: SessionID) -> None:
        pass

    def from_admin(self, msg: Message, sid: SessionID) -> None:
        pass

    def from_app(self, msg: Message, sid: SessionID) -> None:
        _push_event("msg_in", sid=_sid_key(sid), msg_type=msg.msg_type)


class GUILog(Log):
    def __init__(self, sid: SessionID) -> None:
        self._sid = _sid_key(sid)

    def on_incoming(self, raw: str) -> None:
        _push_event("raw_in", sid=self._sid, raw=raw.replace("\x01", "|"))

    def on_outgoing(self, raw: str) -> None:
        _push_event("raw_out", sid=self._sid, raw=raw.replace("\x01", "|"))

    def on_event(self, text: str) -> None:
        _push_event("session_event", sid=self._sid, text=text)


class GUILogFactory(LogFactory):
    def create(self, sid: SessionID) -> Log:
        return GUILog(sid)


# ---------------------------------------------------------------------------
# Session registry
# ---------------------------------------------------------------------------

_sessions: dict[str, dict[str, Any]] = {}


def _build_cfg(config: dict[str, Any]) -> str:
    conn = config.get("connection_type", "initiator")
    lines = [
        "[DEFAULT]",
        f"ConnectionType={conn}",
        f"HeartBtInt={config.get('heartbt_int', 30)}",
        "ReconnectInterval=5",
        "",
        "[SESSION]",
        f"BeginString={config.get('begin_string', 'FIX.4.2')}",
        f"SenderCompID={config['sender_comp_id']}",
        f"TargetCompID={config['target_comp_id']}",
    ]
    if conn == "initiator":
        lines += [
            f"SocketConnectHost={config.get('host', '127.0.0.1')}",
            f"SocketConnectPort={config.get('port', 9878)}",
        ]
    else:
        lines += [
            f"SocketAcceptHost={config.get('host', '0.0.0.0')}",
            f"SocketAcceptPort={config.get('port', 9878)}",
        ]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# HTTP / WebSocket handlers
# ---------------------------------------------------------------------------

GUI_DIR = Path(__file__).parent / "gui_ui"
SESSIONS_FILE = Path("fix_sessions.json")


def _open_browser(url: str) -> None:
    """Open *url* in the default browser, handling WSL2 gracefully."""
    try:
        wsl = "microsoft" in Path("/proc/version").read_text().lower()
    except OSError:
        wsl = False
    if wsl:
        subprocess.Popen(["cmd.exe", "/c", "start", url],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    else:
        webbrowser.open(url)


async def handle_index(request: web.Request) -> web.FileResponse:
    return web.FileResponse(GUI_DIR / "index.html")


async def handle_static(request: web.Request) -> web.FileResponse:
    name = request.match_info["name"]
    filepath = (GUI_DIR / name).resolve()
    try:
        filepath.relative_to(GUI_DIR.resolve())
    except ValueError:
        raise web.HTTPForbidden()
    if not filepath.exists():
        raise web.HTTPNotFound()
    return web.FileResponse(filepath)


async def handle_ws(request: web.Request) -> web.WebSocketResponse:
    ws = web.WebSocketResponse()
    await ws.prepare(request)
    _ws_connections.add(ws)
    try:
        async for _ in ws:
            pass  # we only push; ignore inbound frames
    finally:
        _ws_connections.discard(ws)
    return ws


async def handle_api(request: web.Request) -> web.Response:
    method = request.match_info["method"]
    body: dict[str, Any] = {}
    if request.content_length:
        try:
            body = await request.json()
        except Exception:
            pass
    result = await _dispatch(method, body)
    return web.json_response(result)


# ---------------------------------------------------------------------------
# API dispatch
# ---------------------------------------------------------------------------

async def _dispatch(method: str, body: dict[str, Any]) -> Any:
    if method == "get_version":
        return "fixcore 0.1"
    if method == "get_sessions":
        return _get_sessions()
    if method == "create_session":
        return await _create_session(body)
    if method == "remove_session":
        return await _remove_session(body.get("sid_key", ""))
    if method == "logon":
        return await _logon(body.get("sid_key", ""))
    if method == "logout":
        return await _logout(body.get("sid_key", ""))
    if method == "reset_seq_nums":
        return _reset_seq_nums(body.get("sid_key", ""))
    if method == "send_message":
        return await _send_message(
            body.get("sid_key", ""),
            body.get("msg_type", ""),
            body.get("fields", []),
        )
    if method == "update_session":
        return await _update_session(body.get("old_key", ""), body)
    if method == "stop":
        return await _stop(body.get("sid_key", ""))
    return {"ok": False, "error": f"Unknown method: {method!r}"}


# ---------------------------------------------------------------------------
# Business logic
# ---------------------------------------------------------------------------

def _save_sessions_config() -> None:
    """Persist all current session configs to SESSIONS_FILE."""
    configs = [entry["config"] for entry in _sessions.values()]
    SESSIONS_FILE.write_text(json.dumps(configs, indent=2))


async def _restore_sessions() -> None:
    """Load and recreate sessions from SESSIONS_FILE on startup."""
    if not SESSIONS_FILE.exists():
        return
    try:
        configs = json.loads(SESSIONS_FILE.read_text())
    except Exception as exc:
        print(f"[warn] Could not read {SESSIONS_FILE}: {exc}")
        return
    for config in configs:
        result = await _create_session(config)
        if not result.get("ok"):
            print(f"[warn] Could not restore session: {result.get('error')}")


def _get_sessions() -> list[dict[str, Any]]:
    result = []
    for key, entry in _sessions.items():
        transport = entry.get("transport")
        session = None
        if transport is not None:
            d = transport.sessions
            if d:
                session = next(iter(d.values()))
        state = "DISCONNECTED"
        sender_seq = 1
        target_seq = 1
        if session is not None:
            state = session.state.name
            try:
                sender_seq = session._store.next_sender_msg_seq_num()
                target_seq = session._store.next_target_msg_seq_num()
            except Exception:
                pass
        cfg = entry["config"]
        result.append({
            "key": key,
            "label": f"{cfg['sender_comp_id']} \u2192 {cfg['target_comp_id']}",
            "begin_string": cfg.get("begin_string", "FIX.4.2"),
            "connection_type": cfg.get("connection_type", "initiator"),
            "sender_comp_id": cfg.get("sender_comp_id", ""),
            "target_comp_id": cfg.get("target_comp_id", ""),
            "host": cfg.get("host", ""),
            "port": cfg.get("port", 0),
            "heartbt_int": cfg.get("heartbt_int", 30),
            "store": cfg.get("store", "memory"),
            "state": state,
            "sender_seq": sender_seq,
            "target_seq": target_seq,
            "started": entry.get("started", False),
        })
    return result


async def _create_session(config: dict[str, Any]) -> dict[str, Any]:
    sender = config.get("sender_comp_id", "").strip()
    target = config.get("target_comp_id", "").strip()
    begin = config.get("begin_string", "FIX.4.2")
    if not sender or not target:
        return {"ok": False, "error": "SenderCompID and TargetCompID are required"}
    key = f"{sender}/{target}/{begin}"
    if key in _sessions:
        return {"ok": False, "error": f"Session {key!r} already exists"}
    try:
        settings = SessionSettings.from_string(_build_cfg(config))
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    store_type = config.get("store", "memory")
    if store_type == "file":
        store_dir = Path("fix_store")
        store_dir.mkdir(exist_ok=True)
        store_factory: Any = FileStoreFactory(store_dir)
    else:
        store_factory = MemoryStoreFactory()
    app = GUIApplication()
    log_factory = GUILogFactory()
    conn = config.get("connection_type", "initiator")
    transport: SocketInitiator | SocketAcceptor
    if conn == "initiator":
        transport = SocketInitiator(settings, app, store_factory, log_factory)
    else:
        transport = SocketAcceptor(settings, app, store_factory, log_factory)
    _sessions[key] = {"config": config, "transport": transport, "started": False}
    try:
        await transport.start()
        _sessions[key]["started"] = True
    except Exception as exc:
        del _sessions[key]
        return {"ok": False, "error": f"Failed to start: {exc}"}
    _save_sessions_config()
    return {"ok": True, "key": key}


async def _remove_session(sid_key: str) -> dict[str, Any]:
    entry = _sessions.get(sid_key)
    if entry is None:
        return {"ok": False, "error": "Unknown session"}
    transport = entry.get("transport")
    if transport and entry.get("started"):
        try:
            await transport.stop()
        except Exception:
            pass
    del _sessions[sid_key]
    _save_sessions_config()
    return {"ok": True}


async def _update_session(old_key: str, config: dict[str, Any]) -> dict[str, Any]:
    entry = _sessions.get(old_key)
    if entry is None:
        return {"ok": False, "error": "Unknown session"}
    transport = entry.get("transport")
    if transport and entry.get("started"):
        try:
            await transport.stop()
        except Exception:
            pass
    del _sessions[old_key]
    return await _create_session(config)


async def _logon(sid_key: str) -> dict[str, Any]:
    entry = _sessions.get(sid_key)
    if entry is None:
        return {"ok": False, "error": "Unknown session"}
    transport = entry.get("transport")
    if transport is None:
        return {"ok": False, "error": "No transport"}
    try:
        if entry.get("started"):
            await transport.stop()
        await transport.start()
        entry["started"] = True
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    return {"ok": True}


async def _logout(sid_key: str) -> dict[str, Any]:
    """Graceful FIX logout — sends Logout message and disables auto-reconnect."""
    entry = _sessions.get(sid_key)
    if entry is None:
        return {"ok": False, "error": "Unknown session"}
    transport = entry.get("transport")
    if transport is None:
        return {"ok": False, "error": "No transport"}
    try:
        if isinstance(transport, SocketInitiator):
            await transport.logout()
        else:
            session = next(iter(transport.sessions.values()), None)
            if session and session.is_logged_on:
                await session.send_logout()
        entry["started"] = False
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    return {"ok": True}


async def _stop(sid_key: str) -> dict[str, Any]:
    """Hard stop — kills the transport immediately without sending FIX Logout."""
    entry = _sessions.get(sid_key)
    if entry is None:
        return {"ok": False, "error": "Unknown session"}
    transport = entry.get("transport")
    if transport is None:
        return {"ok": False, "error": "No transport"}
    try:
        await transport.stop()
        entry["started"] = False
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    return {"ok": True}


def _reset_seq_nums(sid_key: str) -> dict[str, Any]:
    entry = _sessions.get(sid_key)
    if entry is None:
        return {"ok": False, "error": "Unknown session"}
    transport = entry.get("transport")
    if transport is None:
        return {"ok": False, "error": "No transport"}
    session = next(iter(transport.sessions.values()), None)
    if session is None:
        return {"ok": False, "error": "No session"}
    if session.is_logged_on:
        return {"ok": False, "error": "Disconnect before resetting sequence numbers"}
    try:
        session._store.reset()
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    return {"ok": True}


async def _send_message(
    sid_key: str, msg_type: str, fields: list[dict[str, str]]
) -> dict[str, Any]:
    entry = _sessions.get(sid_key)
    if entry is None:
        return {"ok": False, "error": "Unknown session"}
    transport = entry.get("transport")
    if transport is None:
        return {"ok": False, "error": "No transport"}
    session = next(iter(transport.sessions.values()), None)
    if session is None or not session.is_logged_on:
        return {"ok": False, "error": "Not logged on"}
    msg = Message()
    msg.header.set(35, msg_type)
    for f in fields:
        try:
            tag = int(f["tag"])
            val = str(f["value"])
            msg.set_field(tag, val)
        except (KeyError, ValueError) as exc:
            return {"ok": False, "error": f"Bad field {f!r}: {exc}"}
    try:
        await session.send_app(msg)
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    return {"ok": True}


# ---------------------------------------------------------------------------
# Server startup
# ---------------------------------------------------------------------------

async def main(port: int) -> None:
    app = web.Application()
    app.router.add_get("/", handle_index)
    app.router.add_get("/ws", handle_ws)
    app.router.add_post("/api/{method}", handle_api)
    app.router.add_get("/{name:.+}", handle_static)

    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", port)
    await site.start()

    await _restore_sessions()

    url = f"http://127.0.0.1:{port}"
    print(f"FIXcore GUI running at {url}  (Ctrl+C to stop)")
    _open_browser(url)

    try:
        await asyncio.Event().wait()
    except asyncio.CancelledError:
        pass
    finally:
        for entry in list(_sessions.values()):
            t = entry.get("transport")
            if t and entry.get("started"):
                try:
                    await t.stop()
                except Exception:
                    pass
        await runner.cleanup()


def run() -> None:
    """Console script entry point — invoked by `fixcore-gui`."""
    port = 8765
    for i, arg in enumerate(sys.argv[1:], 1):
        if arg == "--port" and i < len(sys.argv):
            port = int(sys.argv[i + 1])
        elif arg.startswith("--port="):
            port = int(arg.split("=", 1)[1])
    try:
        asyncio.run(main(port))
    except KeyboardInterrupt:
        print("\nShutting down.")


if __name__ == "__main__":
    run()
