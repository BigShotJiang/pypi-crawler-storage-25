/* quickfix-py GUI — vanilla JS, no framework, no build step */

'use strict';

// ── State ─────────────────────────────────────────────────────────────────
let activeSid = null;
let logFilter = 'all';
let logEntries = [];
let lastSessions = [];   // cache of latest get_sessions response
let editMode = false;    // true when modal is open for editing (not creating)
let editOldKey = null;   // key of the session being edited
let clordIdSeq = 0;      // counter for auto-generated ClOrdID (tag 11)

// ── API helpers ───────────────────────────────────────────────────────────
function $id(id) { return document.getElementById(id); }

async function apiCall(method, params = {}) {
  const res = await fetch(`/api/${method}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  return res.json();
}

function nowStr() {
  const d = new Date();
  return d.toTimeString().slice(0, 8) + '.' +
    String(d.getMilliseconds()).padStart(3, '0');
}

function showToast(msg, type = '') {
  const t = $id('toast');
  t.textContent = msg;
  t.className = 'toast ' + type;
  t.classList.remove('hidden');
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.add('hidden'), 3000);
}

// ── WebSocket — real-time events from Python ──────────────────────────────
function connectWS() {
  const ws = new WebSocket(`ws://127.0.0.1:${location.port}/ws`);
  ws.onmessage = (e) => {
    try {
      handleEngineEvent(JSON.parse(e.data));
    } catch (_) {}
  };
  ws.onclose = () => setTimeout(connectWS, 1500);
}

function handleEngineEvent(data) {
  switch (data.type) {
    case 'logon':
      addLogEntry('evt', data.sid, '● Session logged on');
      refreshSessions();
      break;
    case 'logout':
      addLogEntry('evt', data.sid, '○ Session logged out');
      refreshSessions();
      break;
    case 'raw_in':
      addLogEntry('in', data.sid, data.raw);
      break;
    case 'raw_out':
      addLogEntry('out', data.sid, data.raw);
      break;
    case 'session_event':
      addLogEntry('evt', data.sid, data.text);
      break;
  }
}

// ── Init ──────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  connectWS();
  apiCall('get_version').then(v => { $id('version').textContent = v; });
  startPolling();
  loadLog();
  rebuildLog();
  updateAutoClordidVisibility();
  updateClordidPreview();
  $id('chk-auto-clordid').addEventListener('change', () => {
    updateClordidPreview();
  });
  $id('inp-clordid-prefix').addEventListener('input', updateClordidPreview);

  $id('btn-close-detail').addEventListener('click', closeMsgDetail);
  $id('log-entries').addEventListener('click', e => {
    const row = e.target.closest('.log-entry');
    if (!row || !row._logEntry) return;
    if (row === selectedLogRow) { closeMsgDetail(); return; }
    showMsgDetail(row, row._logEntry);
  });
});

// ── Polling (seq nums + state) ────────────────────────────────────────────
function startPolling() {
  setInterval(() => {
    apiCall('get_sessions').then(sessions => {
      lastSessions = sessions;
      renderSessionList(sessions);
      if (activeSid) {
        const s = sessions.find(x => x.key === activeSid);
        if (s) renderSessionDetail(s);
      }
    });
  }, 600);
}

function refreshSessions() {
  apiCall('get_sessions').then(sessions => {
    lastSessions = sessions;
    renderSessionList(sessions);
    if (activeSid) {
      const s = sessions.find(x => x.key === activeSid);
      if (s) renderSessionDetail(s);
    }
  });
}

// ── Render session sidebar ────────────────────────────────────────────────
function renderSessionList(sessions) {
  const list = $id('session-list');
  const scrollTop = list.scrollTop;

  const existing = {};
  list.querySelectorAll('.session-item').forEach(el => {
    existing[el.dataset.key] = el;
  });

  const keys = sessions.map(s => s.key);
  Object.keys(existing).forEach(k => {
    if (!keys.includes(k)) existing[k].remove();
  });

  sessions.forEach(s => {
    let el = existing[s.key];
    if (!el) {
      el = document.createElement('li');
      el.className = 'session-item';
      el.dataset.key = s.key;
      el.addEventListener('click', () => selectSession(s.key));
      list.appendChild(el);
    }
    el.classList.toggle('active', s.key === activeSid);
    el.innerHTML = `<span class="dot ${dotClass(s.state)}"></span>
      <span class="session-name">${escHtml(s.label)}</span>`;
  });

  list.scrollTop = scrollTop;
}

function dotClass(state) {
  switch (state) {
    case 'LOGGED_ON':      return 'dot-on';
    case 'LOGON_TIMEOUT':  return 'dot-logon';
    case 'LOGOUT_TIMEOUT': return 'dot-logout';
    default:               return 'dot-off';
  }
}

function selectSession(key) {
  activeSid = key;
  refreshSessions();
  rebuildLog();
}

function renderSessionDetail(s) {
  $id('no-session').classList.add('hidden');
  $id('session-detail').classList.remove('hidden');

  $id('detail-label').textContent = s.label;
  const badge = $id('detail-state');
  badge.textContent = s.state.replace(/_/g, ' ');
  badge.className = 'state-badge state-' + s.state;

  $id('detail-begin').textContent = s.begin_string;
  $id('detail-type').textContent = s.connection_type;
  $id('detail-host').textContent = `${s.host}:${s.port}`;
  $id('detail-sender-seq').textContent = s.sender_seq;
  $id('detail-target-seq').textContent = s.target_seq;
}

// ── New Session modal ─────────────────────────────────────────────────────
function openNewModal() {
  editMode = false;
  editOldKey = null;
  $id('modal-title').textContent = 'New Session';
  $id('btn-modal-create').textContent = 'Create & Connect';
  // Reset to defaults
  $id('f-conn-type').value = 'initiator';
  $id('f-begin').value     = 'FIX.4.2';
  $id('f-sender').value    = '';
  $id('f-target').value    = '';
  $id('f-host').value      = '127.0.0.1';
  $id('f-port').value      = '9878';
  $id('f-heartbt').value   = '30';
  $id('f-store').value     = 'memory';
  $id('modal-error').classList.add('hidden');
  $id('modal-overlay').classList.remove('hidden');
  $id('f-sender').focus();
}

function openEditModal(sid) {
  const s = lastSessions.find(x => x.key === sid);
  if (!s) { showToast('Session data not loaded yet', 'error'); return; }
  editMode = true;
  editOldKey = sid;
  $id('modal-title').textContent = 'Edit Session';
  $id('btn-modal-create').textContent = 'Save & Reconnect';
  $id('f-conn-type').value = s.connection_type || 'initiator';
  $id('f-begin').value     = s.begin_string    || 'FIX.4.2';
  $id('f-sender').value    = s.sender_comp_id  || '';
  $id('f-target').value    = s.target_comp_id  || '';
  $id('f-host').value      = s.host            || '127.0.0.1';
  $id('f-port').value      = String(s.port     || 9878);
  $id('f-heartbt').value   = String(s.heartbt_int || 30);
  $id('f-store').value     = s.store           || 'memory';
  $id('modal-error').classList.add('hidden');
  $id('modal-overlay').classList.remove('hidden');
  $id('f-sender').focus();
}

$id('btn-new-session').addEventListener('click', openNewModal);

$id('btn-modal-cancel').addEventListener('click', () => {
  $id('modal-overlay').classList.add('hidden');
  editMode = false; editOldKey = null;
});

$id('modal-overlay').addEventListener('click', e => {
  if (e.target === $id('modal-overlay')) {
    $id('modal-overlay').classList.add('hidden');
    editMode = false; editOldKey = null;
  }
});

$id('btn-modal-create').addEventListener('click', () => {
  const config = {
    connection_type: $id('f-conn-type').value,
    begin_string:    $id('f-begin').value,
    sender_comp_id:  $id('f-sender').value.trim(),
    target_comp_id:  $id('f-target').value.trim(),
    host:            $id('f-host').value.trim() || '127.0.0.1',
    port:            parseInt($id('f-port').value) || 9878,
    heartbt_int:     parseInt($id('f-heartbt').value) || 30,
    store:           $id('f-store').value,
  };

  const btn = $id('btn-modal-create');
  btn.disabled = true;

  if (editMode) {
    btn.textContent = 'Saving…';
    apiCall('update_session', { ...config, old_key: editOldKey }).then(res => {
      btn.disabled = false;
      btn.textContent = 'Save & Reconnect';
      if (res.ok) {
        $id('modal-overlay').classList.add('hidden');
        activeSid = res.key;
        refreshSessions();
        showToast('Session updated', 'success');
      } else {
        const errEl = $id('modal-error');
        errEl.textContent = res.error;
        errEl.classList.remove('hidden');
      }
    });
  } else {
    btn.textContent = 'Connecting…';
    apiCall('create_session', config).then(res => {
      btn.disabled = false;
      btn.textContent = 'Create & Connect';
      if (res.ok) {
        $id('modal-overlay').classList.add('hidden');
        activeSid = res.key;
        refreshSessions();
        showToast('Session created', 'success');
      } else {
        const errEl = $id('modal-error');
        errEl.textContent = res.error;
        errEl.classList.remove('hidden');
      }
    });
  }
});

// ── Session action buttons ────────────────────────────────────────────────
$id('btn-logon').addEventListener('click', () => {
  if (!activeSid) return;
  apiCall('logon', { sid_key: activeSid }).then(res => {
    if (!res.ok) showToast('Logon: ' + res.error, 'error');
    else showToast('Connecting…');
  });
});

$id('btn-logout').addEventListener('click', () => {
  if (!activeSid) return;
  apiCall('logout', { sid_key: activeSid }).then(res => {
    if (!res.ok) showToast('Logout: ' + res.error, 'error');
    else showToast('Logout sent');
    refreshSessions();
  });
});

$id('btn-stop').addEventListener('click', () => {
  if (!activeSid) return;
  apiCall('stop', { sid_key: activeSid }).then(res => {
    if (!res.ok) showToast('Stop: ' + res.error, 'error');
    else { showToast('Session stopped'); refreshSessions(); }
  });
});

$id('btn-edit').addEventListener('click', () => {
  if (!activeSid) return;
  openEditModal(activeSid);
});

$id('btn-reset').addEventListener('click', () => {
  if (!activeSid) return;
  apiCall('reset_seq_nums', { sid_key: activeSid }).then(res => {
    if (!res.ok) showToast('Reset: ' + res.error, 'error');
    else { showToast('Sequence numbers reset', 'success'); refreshSessions(); }
  });
});

$id('btn-remove').addEventListener('click', () => {
  if (!activeSid) return;
  if (!confirm(`Remove session ${activeSid}?`)) return;
  apiCall('remove_session', { sid_key: activeSid }).then(res => {
    if (!res.ok) { showToast('Remove: ' + res.error, 'error'); return; }
    activeSid = null;
    $id('session-detail').classList.add('hidden');
    $id('no-session').classList.remove('hidden');
    refreshSessions();
    showToast('Session removed');
  });
});

// ── Auto ClOrdID helpers ──────────────────────────────────────────────────
function updateAutoClordidVisibility() {
  const msgType = $id('msg-type-select').value;
  const row = $id('row-auto-clordid');
  if (msgType === 'D') {
    row.classList.remove('hidden');
  } else {
    row.classList.add('hidden');
  }
}

function updateClordidPreview() {
  const preview = $id('clordid-preview');
  if (!$id('chk-auto-clordid').checked) { preview.textContent = ''; return; }
  const prefix = $id('inp-clordid-prefix').value || '';
  preview.textContent = '\u2192 ' + prefix + String(clordIdSeq + 1).padStart(6, '0');
}

function generateClordId() {
  clordIdSeq++;
  const prefix = $id('inp-clordid-prefix').value || '';
  return prefix + String(clordIdSeq).padStart(6, '0');
}

// ── Send panel collapse ───────────────────────────────────────────────────
const SEND_COLLAPSED_KEY = 'fixcore_send_collapsed';

function setSendCollapsed(collapsed) {
  $id('panel-send').classList.toggle('panel-send-collapsed', collapsed);
  try { localStorage.setItem(SEND_COLLAPSED_KEY, collapsed ? '1' : '0'); } catch (_) {}
}

$id('btn-toggle-send').addEventListener('click', () => {
  const collapsed = !$id('panel-send').classList.contains('panel-send-collapsed');
  setSendCollapsed(collapsed);
});

// Restore collapse state on load
try {
  if (localStorage.getItem(SEND_COLLAPSED_KEY) === '1') setSendCollapsed(true);
} catch (_) {}

// ── Message builder ───────────────────────────────────────────────────────
const MSG_TYPE_DEFAULTS = {
  'D': [{tag:'11',value:'ORD0001'},{tag:'55',value:'AAPL'},{tag:'54',value:'1'},
        {tag:'40',value:'2'},{tag:'44',value:'150.00'},{tag:'38',value:'100'},
        {tag:'60',value:'20240101-09:30:00'},{tag:'21',value:'1'}],
  'F': [{tag:'11',value:'ORD0001'},{tag:'41',value:'ORD0001'},{tag:'55',value:'AAPL'}],
  'V': [{tag:'262',value:'REQ001'},{tag:'263',value:'1'},{tag:'264',value:'1'}],
  '8': [{tag:'17',value:'EXEC001'},{tag:'11',value:'ORD0001'},{tag:'55',value:'AAPL'},
        {tag:'54',value:'1'},{tag:'38',value:'100'},{tag:'14',value:'0'},
        {tag:'151',value:'100'},{tag:'150',value:'0'},{tag:'39',value:'0'}],
};

function renderFieldsTable(fields) {
  const tbody = $id('fields-body');
  tbody.innerHTML = '';
  fields.forEach((f, i) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><input class="field-input tag-input" value="${escHtml(f.tag)}" placeholder="tag" /></td>
      <td><input class="field-input val-input" value="${escHtml(f.value)}" placeholder="value" /></td>
      <td><button class="btn-remove-field">×</button></td>`;
    tbody.appendChild(tr);
  });
}

function getFields() {
  const fields = [];
  $id('fields-body').querySelectorAll('tr').forEach(tr => {
    const tag = tr.querySelector('.tag-input').value.trim();
    const val = tr.querySelector('.val-input').value;
    if (tag) fields.push({ tag, value: val });
  });
  return fields;
}

$id('msg-type-select').addEventListener('change', function () {
  const custom = $id('msg-type-custom');
  if (this.value === 'custom') {
    custom.classList.remove('hidden');
    renderFieldsTable([{ tag: '', value: '' }]);
  } else {
    custom.classList.add('hidden');
    renderFieldsTable(MSG_TYPE_DEFAULTS[this.value] || [{ tag: '', value: '' }]);
  }
  updateAutoClordidVisibility();
});

renderFieldsTable(MSG_TYPE_DEFAULTS['D']);

$id('fields-body').addEventListener('click', e => {
  if (e.target.classList.contains('btn-remove-field'))
    e.target.closest('tr').remove();
});

$id('btn-add-field').addEventListener('click', () => {
  const tbody = $id('fields-body');
  const tr = document.createElement('tr');
  tr.innerHTML = `
    <td><input class="field-input tag-input" value="" placeholder="tag" /></td>
    <td><input class="field-input val-input" value="" placeholder="value" /></td>
    <td><button class="btn-remove-field">×</button></td>`;
  tbody.appendChild(tr);
  tr.querySelector('.tag-input').focus();
});

$id('btn-send').addEventListener('click', () => {
  if (!activeSid) { showToast('Select a session first', 'error'); return; }
  const sel = $id('msg-type-select');
  const msgType = sel.value === 'custom'
    ? $id('msg-type-custom').value.trim()
    : sel.value;
  if (!msgType) { showToast('Enter a MsgType', 'error'); return; }
  let fields = getFields();
  if (msgType === 'D' && $id('chk-auto-clordid').checked) {
    const clordId = generateClordId();
    const idx = fields.findIndex(f => f.tag === '11');
    if (idx >= 0) {
      fields[idx] = { tag: '11', value: clordId };
    } else {
      fields = [{ tag: '11', value: clordId }, ...fields];
    }
    updateClordidPreview();
  }
  apiCall('send_message', {
    sid_key: activeSid,
    msg_type: msgType,
    fields,
  }).then(res => {
    if (!res.ok) showToast('Send: ' + res.error, 'error');
    else showToast('Message sent', 'success');
  });
});

// ── Paste FIX modal ───────────────────────────────────────────────────────

// Tags managed automatically by the session layer — omit from the send form.
const SKIP_TAGS = new Set([8, 9, 10, 34, 49, 52, 56]);

function parseRawFix(raw) {
  // Accept actual SOH (0x01) or pipe as delimiter; trim whitespace/newlines
  const parts = raw.replace(/\x01/g, '|').split('|');
  const fields = [];
  for (const part of parts) {
    const eq = part.indexOf('=');
    if (eq < 1) continue;
    const tag = part.slice(0, eq).trim();
    const value = part.slice(eq + 1);
    if (/^\d+$/.test(tag)) fields.push({ tag, value });
  }
  return fields;
}

function importRawFix(raw) {
  const fields = parseRawFix(raw);
  if (!fields.length) return 'No valid tag=value fields found.';

  // Extract MsgType (35) to set the selector
  const msgTypeField = fields.find(f => f.tag === '35');
  const msgType = msgTypeField ? msgTypeField.value : null;

  // Body fields: skip header/trailer/session-managed tags
  const bodyFields = fields.filter(f => !SKIP_TAGS.has(parseInt(f.tag, 10)) && f.tag !== '35');

  if (msgType) {
    const sel = $id('msg-type-select');
    const opt = [...sel.options].find(o => o.value === msgType);
    if (opt) {
      sel.value = msgType;
      $id('msg-type-custom').classList.add('hidden');
    } else {
      sel.value = 'custom';
      $id('msg-type-custom').classList.remove('hidden');
      $id('msg-type-custom').value = msgType;
    }
  }

  renderFieldsTable(bodyFields);
  return null; // no error
}

$id('btn-paste-fix').addEventListener('click', () => {
  $id('paste-fix-input').value = '';
  $id('paste-modal-error').classList.add('hidden');
  $id('paste-modal-overlay').classList.remove('hidden');
  $id('paste-fix-input').focus();
});

$id('btn-paste-cancel').addEventListener('click', () => {
  $id('paste-modal-overlay').classList.add('hidden');
});

$id('paste-modal-overlay').addEventListener('click', e => {
  if (e.target === $id('paste-modal-overlay'))
    $id('paste-modal-overlay').classList.add('hidden');
});

$id('btn-paste-import').addEventListener('click', () => {
  const raw = $id('paste-fix-input').value.trim();
  if (!raw) return;
  const err = importRawFix(raw);
  if (err) {
    const el = $id('paste-modal-error');
    el.textContent = err;
    el.classList.remove('hidden');
  } else {
    $id('paste-modal-overlay').classList.add('hidden');
    showToast('Fields imported', 'success');
  }
});

// Allow Ctrl+Enter to import from the textarea
$id('paste-fix-input').addEventListener('keydown', e => {
  if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
    e.preventDefault();
    $id('btn-paste-import').click();
  }
});

// ── FIX tag reference ─────────────────────────────────────────────────────
const FIX_TAG_NAMES = {
  1:'Account', 6:'AvgPx', 7:'BeginSeqNo', 8:'BeginString', 9:'BodyLength',
  10:'CheckSum', 11:'ClOrdID', 14:'CumQty', 15:'Currency', 16:'EndSeqNo',
  31:'LastPx', 32:'LastQty',
  17:'ExecID', 18:'ExecInst', 20:'ExecTransType', 21:'HandlInst',
  34:'MsgSeqNum', 35:'MsgType', 36:'NewSeqNo', 37:'OrderID', 38:'OrderQty',
  39:'OrdStatus', 40:'OrdType', 41:'OrigClOrdID', 43:'PossDupFlag',
  44:'Price', 45:'RefSeqNum', 49:'SenderCompID', 50:'SenderSubID',
  52:'SendingTime', 54:'Side', 55:'Symbol', 56:'TargetCompID',
  57:'TargetSubID', 58:'Text', 60:'TransactTime', 97:'PossResend',
  98:'EncryptMethod', 108:'HeartBtInt', 110:'MinQty', 111:'MaxFloor',
  112:'TestReqID', 114:'LocateReqd', 122:'OrigSendingTime', 123:'GapFillFlag',
  126:'ExpireTime', 131:'QuoteReqID', 140:'PrevClosePx', 146:'NoRelatedSym',
  150:'ExecType', 151:'LeavesQty', 167:'SecurityType', 200:'MaturityMonthYear',
  202:'StrikePrice', 207:'SecurityExchange', 262:'MDReqID',
  263:'SubscriptionRequestType', 264:'MarketDepth', 267:'NoMDEntryTypes',
  268:'NoMDEntries', 269:'MDEntryType', 270:'MDEntryPx', 271:'MDEntrySize',
};

const FIX_ENUM_VALUES = {
  35: {'0':'Heartbeat','1':'TestRequest','2':'ResendRequest','3':'Reject',
       '4':'SequenceReset','5':'Logout','8':'ExecutionReport',
       '9':'OrderCancelReject','A':'Logon','D':'NewOrderSingle',
       'F':'OrderCancelRequest','G':'OrderCancelReplaceRequest',
       'H':'OrderStatusRequest','V':'MarketDataRequest',
       'W':'MarketDataSnapshot','X':'MarketDataIncremental','Y':'MarketDataRequestReject'},
  39: {'0':'New','1':'PartiallyFilled','2':'Filled','3':'DoneForDay',
       '4':'Canceled','5':'Replaced','6':'PendingCancel','7':'Stopped',
       '8':'Rejected','9':'Suspended','A':'PendingNew','C':'Expired'},
  40: {'1':'Market','2':'Limit','3':'Stop','4':'StopLimit','5':'MarketOnClose'},
  54: {'1':'Buy','2':'Sell','3':'BuyMinus','4':'SellPlus','5':'SellShort','6':'SellShortExempt'},
  98: {'0':'None','1':'Value','2':'DES','3':'PKCS','4':'PGP','5':'PCSDSS','6':'PEM'},
  150:{'0':'New','1':'PartialFill','2':'Fill','3':'DoneForDay','4':'Canceled',
       '5':'Replace','6':'PendingCancel','7':'Stopped','8':'Rejected',
       'D':'Restated','E':'Trade','F':'TradeCorrect','G':'TradeCancel','H':'OrderStatus'},
};

function fixTagName(tag) { return FIX_TAG_NAMES[parseInt(tag)] || ''; }
function fixEnumVal(tag, val) {
  const map = FIX_ENUM_VALUES[parseInt(tag)];
  return map ? (map[val] || val) : val;
}

// ── Message detail panel ──────────────────────────────────────────────────
let selectedLogRow = null;

function showMsgDetail(row, entry) {
  if (selectedLogRow) selectedLogRow.classList.remove('selected');
  selectedLogRow = row;
  row.classList.add('selected');

  const content = $id('msg-detail-content');
  content.innerHTML = '';

  // Meta info
  const meta = document.createElement('div');
  meta.className = 'msg-detail-meta';
  meta.innerHTML = `<strong>${dirArrow(entry.dir)} ${entry.dir.toUpperCase()}</strong>
    &nbsp;${escHtml(entry.time)}
    &nbsp;<span title="${escHtml(entry.sid)}">${escHtml(shortSid(entry.sid))}</span>`;
  content.appendChild(meta);

  // Parse fields
  entry.raw.split('|').filter(Boolean).forEach(part => {
    const eq = part.indexOf('=');
    if (eq < 1) return;
    const tag = part.slice(0, eq).trim();
    const val = part.slice(eq + 1);
    const name = fixTagName(tag);
    const display = fixEnumVal(tag, val);

    const row = document.createElement('div');
    row.className = 'msg-detail-row';
    row.innerHTML =
      `<span class="detail-tag">${escHtml(tag)}</span>` +
      `<span class="detail-name" title="${escHtml(name)}">${escHtml(name)}</span>` +
      `<span class="detail-val" title="${escHtml(val)}">${escHtml(display)}</span>`;
    content.appendChild(row);
  });

  $id('msg-detail-panel').classList.remove('hidden');
}

function closeMsgDetail() {
  if (selectedLogRow) { selectedLogRow.classList.remove('selected'); selectedLogRow = null; }
  $id('msg-detail-panel').classList.add('hidden');
}


// ── Message log ───────────────────────────────────────────────────────────
const LOG_STORAGE_KEY = 'fixcore_log';

function saveLog() {
  try { localStorage.setItem(LOG_STORAGE_KEY, JSON.stringify(logEntries)); } catch (_) {}
}

function loadLog() {
  try {
    const raw = localStorage.getItem(LOG_STORAGE_KEY);
    if (raw) logEntries = JSON.parse(raw);
  } catch (_) {}
}

function addLogEntry(dir, sid, raw) {
  const entry = { dir, sid, raw, time: nowStr() };
  logEntries.push(entry);
  if (logEntries.length > 2000) logEntries.shift();
  saveLog();
  appendLogRow(entry);
}

function appendLogRow(entry) {
  if (!matchesFilter(entry)) return;
  const container = $id('log-entries');
  const atBottom = container.scrollHeight - container.scrollTop - container.clientHeight < 40;

  const row = document.createElement('div');
  row.className = `log-entry ${entry.dir}`;
  row.dataset.dir = entry.dir;
  row._logEntry = entry;
  row.innerHTML = `
    <span class="log-time">${escHtml(entry.time)}</span>
    <span class="log-dir">${dirArrow(entry.dir)}</span>
    <span class="log-sid" title="${escHtml(entry.sid)}">${shortSid(entry.sid)}</span>
    <span class="log-msg">${escHtml(entry.raw)}</span>`;
  container.appendChild(row);

  if (atBottom) container.scrollTop = container.scrollHeight;
  while (container.childElementCount > 500)
    container.removeChild(container.firstElementChild);
}

function dirArrow(dir) {
  if (dir === 'out') return '▶';
  if (dir === 'in')  return '◀';
  return '—';
}

function shortSid(sid) {
  const parts = sid.split('/');
  return parts.length >= 2
    ? parts[0].slice(0, 6) + '/' + parts[1].slice(0, 6)
    : sid.slice(0, 12);
}

const SESSION_MSG_TYPES = new Set(['0','1','2','3','4','5','A']);

function getMsgType(raw) {
  const m = raw.match(/\b35=([^|]+)/);
  return m ? m[1].trim() : null;
}

function matchesFilter(entry) {
  if (activeSid && entry.sid !== activeSid) return false;
  if (logFilter === 'all')   return true;
  if (logFilter === 'app') {
    if (entry.dir === 'evt') return false;
    const mt = getMsgType(entry.raw);
    return mt !== null && !SESSION_MSG_TYPES.has(mt);
  }
  if (logFilter === 'in')    return entry.dir === 'in';
  if (logFilter === 'out')   return entry.dir === 'out';
  if (logFilter === 'event') return entry.dir === 'evt';
  return true;
}

function rebuildLog() {
  const container = $id('log-entries');
  container.innerHTML = '';
  logEntries.forEach(e => appendLogRow(e));
  container.scrollTop = container.scrollHeight;
}

$id('panel-log').querySelectorAll('.filter-btn').forEach(btn => {
  btn.addEventListener('click', function () {
    $id('panel-log').querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    this.classList.add('active');
    logFilter = this.dataset.filter;
    rebuildLog();
  });
});

$id('btn-clear-log').addEventListener('click', () => {
  logEntries = [];
  localStorage.removeItem(LOG_STORAGE_KEY);
  $id('log-entries').innerHTML = '';
  closeMsgDetail();
});

// ── Keyboard shortcuts ────────────────────────────────────────────────────
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    $id('modal-overlay').classList.add('hidden');
    $id('paste-modal-overlay').classList.add('hidden');
    editMode = false; editOldKey = null;
    closeMsgDetail();
  }
  if ((e.ctrlKey || e.metaKey) && e.key === 'n') {
    e.preventDefault();
    $id('btn-new-session').click();
  }
});

// ── Utility ───────────────────────────────────────────────────────────────
function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
