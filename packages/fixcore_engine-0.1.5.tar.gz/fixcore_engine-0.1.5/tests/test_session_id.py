"""Tests for SessionID and SessionSettings."""

from fixcore.session.session_id import SessionID
from fixcore.session.session_settings import SessionSettings

_CONFIG = """
[DEFAULT]
ConnectionType=initiator
HeartBtInt=30
ResetOnLogon=N

[SESSION]
BeginString=FIX.4.2
SenderCompID=CLIENT
TargetCompID=SERVER
SocketConnectHost=127.0.0.1
SocketConnectPort=9878
"""


class TestSessionID:
    def test_equality(self):
        a = SessionID("FIX.4.2", "CLIENT", "SERVER")
        b = SessionID("FIX.4.2", "CLIENT", "SERVER")
        assert a == b

    def test_inequality(self):
        a = SessionID("FIX.4.2", "CLIENT", "SERVER")
        b = SessionID("FIX.4.4", "CLIENT", "SERVER")
        assert a != b

    def test_hashable(self):
        sid = SessionID("FIX.4.2", "CLIENT", "SERVER")
        d = {sid: "value"}
        assert d[sid] == "value"

    def test_str(self):
        sid = SessionID("FIX.4.2", "CLIENT", "SERVER")
        assert str(sid) == "FIX.4.2:CLIENT->SERVER"

    def test_str_with_qualifier(self):
        sid = SessionID("FIX.4.2", "CLIENT", "SERVER", "Q1")
        assert str(sid) == "FIX.4.2:CLIENT->SERVER:Q1"


class TestSessionSettings:
    def _settings(self) -> tuple[SessionSettings, SessionID]:
        s = SessionSettings.from_string(_CONFIG)
        sid = SessionID("FIX.4.2", "CLIENT", "SERVER")
        return s, sid

    def test_parses_session_ids(self):
        s, sid = self._settings()
        assert sid in s.session_ids

    def test_get_session_value(self):
        s, sid = self._settings()
        assert s.get(sid, "SocketConnectHost") == "127.0.0.1"
        assert s.get(sid, "SocketConnectPort") == "9878"

    def test_get_default_value(self):
        s, sid = self._settings()
        assert s.get_int(sid, "HeartBtInt") == 30

    def test_get_bool_false(self):
        s, sid = self._settings()
        assert s.get_bool(sid, "ResetOnLogon") is False

    def test_missing_key_raises(self):
        import pytest

        s, sid = self._settings()
        with pytest.raises(KeyError):
            s.get(sid, "NonExistentKey")
