"""Tests for MessageCracker dispatch."""

from __future__ import annotations

import pytest

from fixcore.application import Application
from fixcore.message.cracker import MessageCracker
from fixcore.message.exceptions import UnsupportedMessageType
from fixcore.message.message import Message, TAG_BEGIN_STRING, TAG_MSG_TYPE
from fixcore.session.session_id import SessionID
from fixcore.session.state import TAG_SENDER_COMP_ID, TAG_TARGET_COMP_ID, TAG_MSG_SEQ_NUM, TAG_SENDING_TIME

SID = SessionID("FIX.4.2", "CLIENT", "SERVER")


def _msg(msg_type: str, **fields: str) -> Message:
    m = Message()
    m.header.set(TAG_BEGIN_STRING, "FIX.4.2")
    m.header.set(TAG_MSG_TYPE, msg_type)
    m.header.set(TAG_SENDER_COMP_ID, "CLIENT")
    m.header.set(TAG_TARGET_COMP_ID, "SERVER")
    m.header.set(TAG_MSG_SEQ_NUM, "1")
    m.header.set(TAG_SENDING_TIME, "20240101-00:00:00")
    for tag_str, val in fields.items():
        m.set_field(int(tag_str), val)
    return m


# ---------------------------------------------------------------------------
# Minimal concrete app using the cracker
# ---------------------------------------------------------------------------

class CrackingApp(Application, MessageCracker):
    def __init__(self) -> None:
        self.received: list[tuple[str, Message]] = []

    def on_create(self, sid: SessionID) -> None: pass
    def on_logon(self, sid: SessionID) -> None: pass
    def on_logout(self, sid: SessionID) -> None: pass
    def to_admin(self, msg: Message, sid: SessionID) -> None: pass
    def to_app(self, msg: Message, sid: SessionID) -> None: pass
    def from_admin(self, msg: Message, sid: SessionID) -> None: pass

    def from_app(self, msg: Message, sid: SessionID) -> None:
        self.crack(msg, sid)

    def on_new_order_single(self, msg: Message, sid: SessionID) -> None:
        self.received.append(("NOS", msg))

    def on_execution_report(self, msg: Message, sid: SessionID) -> None:
        self.received.append(("ER", msg))

    def on_order_cancel_request(self, msg: Message, sid: SessionID) -> None:
        self.received.append(("OCR", msg))


# ---------------------------------------------------------------------------
# Dispatch tests
# ---------------------------------------------------------------------------

class TestDispatch:
    def test_new_order_single_dispatched(self):
        app = CrackingApp()
        app.from_app(_msg("D"), SID)
        assert app.received == [("NOS", app.received[0][1])]

    def test_execution_report_dispatched(self):
        app = CrackingApp()
        app.from_app(_msg("8"), SID)
        assert app.received[0][0] == "ER"

    def test_order_cancel_request_dispatched(self):
        app = CrackingApp()
        app.from_app(_msg("F"), SID)
        assert app.received[0][0] == "OCR"

    def test_message_object_passed_through(self):
        app = CrackingApp()
        m = _msg("D", **{"11": "ORD001"})
        app.from_app(m, SID)
        _, received_msg = app.received[0]
        assert received_msg.get_field(11) == "ORD001"

    def test_session_id_not_required_in_handler(self):
        # Handlers receive session_id; verify it's the correct one
        received_sids: list[SessionID] = []

        class SidCapture(Application, MessageCracker):
            def on_create(self, s): pass
            def on_logon(self, s): pass
            def on_logout(self, s): pass
            def to_admin(self, m, s): pass
            def to_app(self, m, s): pass
            def from_admin(self, m, s): pass
            def from_app(self, m, s): self.crack(m, s)
            def on_new_order_single(self, m, s): received_sids.append(s)

        app = SidCapture()
        app.from_app(_msg("D"), SID)
        assert received_sids == [SID]


# ---------------------------------------------------------------------------
# Unknown / unhandled message types
# ---------------------------------------------------------------------------

class TestUnknownMessageType:
    def test_unknown_type_raises_unsupported(self):
        app = CrackingApp()
        with pytest.raises(UnsupportedMessageType) as exc_info:
            app.crack(_msg("ZZ"), SID)
        assert exc_info.value.msg_type == "ZZ"

    def test_unhandled_known_type_raises_unsupported(self):
        # "V" (MarketDataRequest) is in the registry but CrackingApp doesn't override it
        # The default typed handler calls on_message which raises
        app = CrackingApp()
        with pytest.raises(UnsupportedMessageType) as exc_info:
            app.crack(_msg("V"), SID)
        assert exc_info.value.msg_type == "V"

    def test_on_message_override_catches_all(self):
        caught: list[str] = []

        class CatchAll(Application, MessageCracker):
            def on_create(self, s): pass
            def on_logon(self, s): pass
            def on_logout(self, s): pass
            def to_admin(self, m, s): pass
            def to_app(self, m, s): pass
            def from_admin(self, m, s): pass
            def from_app(self, m, s): self.crack(m, s)
            def on_message(self, m, s): caught.append(m.msg_type)

        app = CatchAll()
        app.from_app(_msg("ZZ"), SID)
        app.from_app(_msg("YY"), SID)
        assert caught == ["ZZ", "YY"]


# ---------------------------------------------------------------------------
# Class-level registration
# ---------------------------------------------------------------------------

class TestClassRegistration:
    def test_register_custom_msg_type(self):
        received: list[Message] = []

        class CustomApp(Application, MessageCracker):
            def on_create(self, s): pass
            def on_logon(self, s): pass
            def on_logout(self, s): pass
            def to_admin(self, m, s): pass
            def to_app(self, m, s): pass
            def from_admin(self, m, s): pass
            def from_app(self, m, s): self.crack(m, s)
            def on_custom_rfq(self, m, s): received.append(m)

        MessageCracker.register("U9", "on_custom_rfq")
        try:
            app = CustomApp()
            app.crack(_msg("U9"), SID)
            assert len(received) == 1
        finally:
            # Clean up so other tests aren't affected
            from fixcore.message.cracker import _REGISTRY
            _REGISTRY.pop("U9", None)


# ---------------------------------------------------------------------------
# Instance-level registration
# ---------------------------------------------------------------------------

class TestInstanceRegistration:
    def test_instance_register_overrides_class(self):
        instance_received: list[Message] = []

        class OverrideApp(Application, MessageCracker):
            def on_create(self, s): pass
            def on_logon(self, s): pass
            def on_logout(self, s): pass
            def to_admin(self, m, s): pass
            def to_app(self, m, s): pass
            def from_admin(self, m, s): pass
            def from_app(self, m, s): self.crack(m, s)

            # Override "D" at instance level with a different handler
            def my_nos_handler(self, m, s): instance_received.append(m)
            def on_new_order_single(self, m, s): raise AssertionError("Should not be called")

        app = OverrideApp()
        app.register_instance("D", "my_nos_handler")
        app.crack(_msg("D"), SID)
        assert len(instance_received) == 1

    def test_instance_registration_does_not_affect_other_instances(self):
        class SimpleApp(Application, MessageCracker):
            def on_create(self, s): pass
            def on_logon(self, s): pass
            def on_logout(self, s): pass
            def to_admin(self, m, s): pass
            def to_app(self, m, s): pass
            def from_admin(self, m, s): pass
            def from_app(self, m, s): self.crack(m, s)
            def on_new_order_single(self, m, s): pass

        app1 = SimpleApp()
        app2 = SimpleApp()
        app1.register_instance("D", "on_new_order_single")

        # app2 should not have the instance registry
        assert not hasattr(app2, "_instance_registry") or "D" not in getattr(app2, "_instance_registry", {})


# ---------------------------------------------------------------------------
# All registry entries map to callable methods on a full implementation
# ---------------------------------------------------------------------------

class TestRegistryCoverage:
    def test_all_default_handlers_callable(self):
        """Every entry in _REGISTRY should resolve to a method on MessageCracker."""
        from fixcore.message.cracker import _REGISTRY

        cracker = MessageCracker()
        for msg_type, handler_name in _REGISTRY.items():
            assert hasattr(cracker, handler_name), (
                f"Missing default handler {handler_name!r} for MsgType {msg_type!r}"
            )
