"""Tests for DataDictionary — XML loading, field/message lookup, validation."""

from pathlib import Path

import pytest

from fixcore.message.data_dictionary import DataDictionary
from fixcore.message.exceptions import InvalidMessage
from fixcore.message.message import Message, TAG_BEGIN_STRING, TAG_MSG_TYPE

SPECS = Path(__file__).parent.parent / "specs"

# ---------------------------------------------------------------------------
# Minimal inline spec used for most tests (fast, no file I/O)
# ---------------------------------------------------------------------------

MINI_SPEC = """<?xml version="1.0"?>
<fix major="4" minor="2" type="FIX">
  <header>
    <field name="BeginString"  required="Y"/>
    <field name="BodyLength"   required="Y"/>
    <field name="MsgType"      required="Y"/>
    <field name="SenderCompID" required="Y"/>
    <field name="TargetCompID" required="Y"/>
    <field name="MsgSeqNum"    required="Y"/>
    <field name="SendingTime"  required="Y"/>
  </header>
  <trailer>
    <field name="CheckSum"     required="Y"/>
  </trailer>
  <messages>
    <message name="Heartbeat" msgtype="0" msgcat="admin">
      <field name="TestReqID" required="N"/>
    </message>
    <message name="Logon" msgtype="A" msgcat="admin">
      <field name="EncryptMethod" required="Y"/>
      <field name="HeartBtInt"    required="Y"/>
    </message>
    <message name="NewOrderSingle" msgtype="D" msgcat="app">
      <field name="ClOrdID"      required="Y"/>
      <field name="Symbol"       required="Y"/>
      <field name="Side"         required="Y"/>
      <field name="OrdType"      required="Y"/>
      <field name="TransactTime" required="Y"/>
      <field name="HandlInst"    required="Y"/>
      <field name="Price"        required="N"/>
    </message>
  </messages>
  <fields>
    <field number="8"   name="BeginString"   type="STRING"/>
    <field number="9"   name="BodyLength"    type="LENGTH"/>
    <field number="10"  name="CheckSum"      type="STRING"/>
    <field number="34"  name="MsgSeqNum"     type="SEQNUM"/>
    <field number="35"  name="MsgType"       type="STRING"/>
    <field number="49"  name="SenderCompID"  type="STRING"/>
    <field number="52"  name="SendingTime"   type="UTCTIMESTAMP"/>
    <field number="56"  name="TargetCompID"  type="STRING"/>
    <field number="108" name="HeartBtInt"    type="INT"/>
    <field number="112" name="TestReqID"     type="STRING"/>
    <field number="98"  name="EncryptMethod" type="INT">
      <value enum="0" description="NONE"/>
    </field>
    <field number="11"  name="ClOrdID"       type="STRING"/>
    <field number="21"  name="HandlInst"     type="CHAR">
      <value enum="1" description="AUTOMATED"/>
      <value enum="2" description="SEMI_AUTO"/>
      <value enum="3" description="MANUAL"/>
    </field>
    <field number="40"  name="OrdType"       type="CHAR">
      <value enum="1" description="MARKET"/>
      <value enum="2" description="LIMIT"/>
    </field>
    <field number="44"  name="Price"         type="PRICE"/>
    <field number="54"  name="Side"          type="CHAR">
      <value enum="1" description="BUY"/>
      <value enum="2" description="SELL"/>
    </field>
    <field number="55"  name="Symbol"        type="STRING"/>
    <field number="60"  name="TransactTime"  type="UTCTIMESTAMP"/>
  </fields>
</fix>"""


def _dd() -> DataDictionary:
    return DataDictionary.from_string(MINI_SPEC)


def _full_header(msg: Message, msg_type: str) -> None:
    """Set all required header fields on *msg*."""
    msg.header.set(TAG_BEGIN_STRING, "FIX.4.2")
    msg.header.set(TAG_MSG_TYPE, msg_type)
    msg.header.set(49, "SENDER")
    msg.header.set(56, "TARGET")
    msg.header.set(34, "1")
    msg.header.set(52, "20240101-00:00:00")


# ---------------------------------------------------------------------------
# Version
# ---------------------------------------------------------------------------

class TestVersion:
    def test_version_string(self):
        assert _dd().version == "FIX.4.2"


# ---------------------------------------------------------------------------
# Field lookup
# ---------------------------------------------------------------------------

class TestFieldLookup:
    def test_field_by_number(self):
        fd = _dd().field_def(49)
        assert fd.name == "SenderCompID"
        assert fd.type == "STRING"

    def test_field_by_name(self):
        assert _dd().field_tag("SenderCompID") == 49

    def test_unknown_field_raises(self):
        with pytest.raises(KeyError):
            _dd().field_def(9999)

    def test_enum_values_loaded(self):
        fd = _dd().field_def(54)  # Side
        assert fd.values["1"] == "BUY"
        assert fd.values["2"] == "SELL"

    def test_is_header_field(self):
        dd = _dd()
        assert dd.is_header_field(49)   # SenderCompID
        assert not dd.is_header_field(55)  # Symbol


# ---------------------------------------------------------------------------
# Message lookup
# ---------------------------------------------------------------------------

class TestMessageLookup:
    def test_known_message(self):
        md = _dd().message_def("D")
        assert md.name == "NewOrderSingle"
        assert md.msg_cat == "app"

    def test_required_fields(self):
        md = _dd().message_def("D")
        dd = _dd()
        required_names = {dd.field_def(t).name for t in md.required}
        assert "ClOrdID" in required_names
        assert "Symbol" in required_names

    def test_optional_fields(self):
        md = _dd().message_def("D")
        dd = _dd()
        optional_names = {dd.field_def(t).name for t in md.optional}
        assert "Price" in optional_names

    def test_unknown_message_raises(self):
        with pytest.raises(KeyError):
            _dd().message_def("ZZ")


# ---------------------------------------------------------------------------
# Validation — valid messages
# ---------------------------------------------------------------------------

class TestValidation:
    def _make_logon(self) -> Message:
        msg = Message()
        _full_header(msg, "A")
        msg.set_field(98, "0")   # EncryptMethod
        msg.set_field(108, "30") # HeartBtInt
        return msg

    def _make_nos(self) -> Message:
        msg = Message()
        _full_header(msg, "D")
        msg.set_field(11, "ORD001")          # ClOrdID
        msg.set_field(21, "1")               # HandlInst
        msg.set_field(55, "AAPL")            # Symbol
        msg.set_field(54, "1")               # Side — Buy
        msg.set_field(40, "2")               # OrdType — Limit
        msg.set_field(60, "20240101-09:30:00")  # TransactTime
        return msg

    def test_valid_logon_passes(self):
        _dd().validate(self._make_logon())  # no exception

    def test_valid_nos_passes(self):
        _dd().validate(self._make_nos())    # no exception

    def test_missing_msg_type_raises(self):
        msg = Message()
        with pytest.raises(InvalidMessage, match="MsgType"):
            _dd().validate(msg)

    def test_unknown_msg_type_raises(self):
        msg = Message()
        msg.header.set(TAG_MSG_TYPE, "ZZ")
        with pytest.raises(InvalidMessage, match="Unknown MsgType"):
            _dd().validate(msg)

    def test_missing_required_header_field_raises(self):
        msg = self._make_logon()
        msg.header.remove_field(49)  # remove SenderCompID
        with pytest.raises(InvalidMessage, match="SenderCompID"):
            _dd().validate(msg)

    def test_missing_required_body_field_raises(self):
        msg = self._make_nos()
        msg.body.pop(11)   # remove ClOrdID
        msg._body_order.remove(11)
        with pytest.raises(InvalidMessage, match="ClOrdID"):
            _dd().validate(msg)

    def test_heartbeat_no_required_body_fields(self):
        msg = Message()
        _full_header(msg, "0")
        _dd().validate(msg)  # Heartbeat has no required body fields


# ---------------------------------------------------------------------------
# Enum validation
# ---------------------------------------------------------------------------

class TestEnumValidation:
    def test_valid_enum(self):
        assert _dd().validate_field_value(54, "1")  # Side=BUY

    def test_invalid_enum(self):
        assert not _dd().validate_field_value(54, "X")

    def test_no_enum_always_valid(self):
        assert _dd().validate_field_value(55, "anything")  # Symbol has no enum


# ---------------------------------------------------------------------------
# Full FIX42.xml spec file
# ---------------------------------------------------------------------------

class TestFIX42Spec:
    def test_loads_without_error(self):
        dd = DataDictionary.from_xml(SPECS / "FIX42.xml")
        assert dd.version == "FIX.4.2"

    def test_session_messages_present(self):
        dd = DataDictionary.from_xml(SPECS / "FIX42.xml")
        for mt in ("0", "1", "2", "3", "4", "5", "A"):
            assert dd.message_def(mt) is not None

    def test_nos_required_fields(self):
        dd = DataDictionary.from_xml(SPECS / "FIX42.xml")
        md = dd.message_def("D")
        names = {dd.field_def(t).name for t in md.required}
        assert names == {"ClOrdID", "HandlInst", "Symbol", "Side", "TransactTime", "OrdType"}

    def test_logon_group_defined(self):
        dd = DataDictionary.from_xml(SPECS / "FIX42.xml")
        md = dd.message_def("A")
        # NoMsgTypes group should be parsed
        tag = dd.field_tag("NoMsgTypes")
        assert tag in md.groups
