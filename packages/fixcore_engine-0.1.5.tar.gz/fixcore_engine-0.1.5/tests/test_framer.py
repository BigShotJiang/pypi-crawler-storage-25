"""Tests for MessageFramer — stream framing correctness."""

from fixcore.message.message import Message, TAG_BEGIN_STRING, TAG_MSG_TYPE
from fixcore.session.state import TAG_SENDER_COMP_ID, TAG_TARGET_COMP_ID, TAG_MSG_SEQ_NUM, TAG_SENDING_TIME
from fixcore.transport.framer import MessageFramer


def _make_raw(msg_type: str, seq: int = 1) -> bytes:
    msg = Message()
    msg.header.set(TAG_BEGIN_STRING, "FIX.4.2")
    msg.header.set(TAG_MSG_TYPE, msg_type)
    msg.header.set(TAG_SENDER_COMP_ID, "CLIENT")
    msg.header.set(TAG_TARGET_COMP_ID, "SERVER")
    msg.header.set(TAG_MSG_SEQ_NUM, str(seq))
    msg.header.set(TAG_SENDING_TIME, "20240101-00:00:00")
    return msg.encode()


class TestFramerSingleMessage:
    def test_complete_message_in_one_feed(self):
        framer = MessageFramer()
        raw = _make_raw("0")
        msgs = framer.feed(raw)
        assert len(msgs) == 1
        assert msgs[0] == raw

    def test_decoded_message_is_valid(self):
        framer = MessageFramer()
        raw = _make_raw("A")
        msgs = framer.feed(raw)
        decoded = Message.decode(msgs[0])
        assert decoded.msg_type == "A"


class TestFramerPartialReads:
    def test_split_in_header(self):
        framer = MessageFramer()
        raw = _make_raw("0")
        # Split after "8=FIX.4.2\x01"
        split = 10
        assert framer.feed(raw[:split]) == []
        msgs = framer.feed(raw[split:])
        assert len(msgs) == 1
        assert msgs[0] == raw

    def test_split_byte_by_byte(self):
        framer = MessageFramer()
        raw = _make_raw("A")
        msgs = []
        for byte in raw:
            msgs.extend(framer.feed(bytes([byte])))
        assert len(msgs) == 1
        assert msgs[0] == raw

    def test_split_in_body(self):
        framer = MessageFramer()
        raw = _make_raw("D")
        mid = len(raw) // 2
        assert framer.feed(raw[:mid]) == []
        msgs = framer.feed(raw[mid:])
        assert len(msgs) == 1

    def test_split_just_before_checksum(self):
        framer = MessageFramer()
        raw = _make_raw("0")
        # Split 7 bytes from end (checksum field)
        assert framer.feed(raw[:-7]) == []
        msgs = framer.feed(raw[-7:])
        assert len(msgs) == 1

    def test_split_inside_checksum(self):
        framer = MessageFramer()
        raw = _make_raw("0")
        assert framer.feed(raw[:-3]) == []
        msgs = framer.feed(raw[-3:])
        assert len(msgs) == 1


class TestFramerMultipleMessages:
    def test_two_messages_in_one_feed(self):
        framer = MessageFramer()
        raw1 = _make_raw("0", seq=1)
        raw2 = _make_raw("0", seq=2)
        msgs = framer.feed(raw1 + raw2)
        assert len(msgs) == 2
        assert msgs[0] == raw1
        assert msgs[1] == raw2

    def test_five_messages_in_one_feed(self):
        framer = MessageFramer()
        raws = [_make_raw("0", seq=i) for i in range(1, 6)]
        msgs = framer.feed(b"".join(raws))
        assert len(msgs) == 5

    def test_messages_split_across_feeds(self):
        framer = MessageFramer()
        raw1 = _make_raw("A", seq=1)
        raw2 = _make_raw("0", seq=2)
        combined = raw1 + raw2
        mid = len(raw1) + len(raw2) // 2
        msgs = framer.feed(combined[:mid])
        msgs += framer.feed(combined[mid:])
        assert len(msgs) == 2


class TestFramerGarbage:
    def test_leading_garbage_skipped(self):
        framer = MessageFramer()
        raw = _make_raw("0")
        msgs = framer.feed(b"GARBAGE\xff\x00" + raw)
        assert len(msgs) == 1
        assert msgs[0] == raw

    def test_empty_feed_returns_empty(self):
        framer = MessageFramer()
        assert framer.feed(b"") == []

    def test_reset_clears_partial_buffer(self):
        framer = MessageFramer()
        raw = _make_raw("0")
        framer.feed(raw[:10])  # partial
        framer.reset()
        # Now feed a complete message — should get exactly one
        msgs = framer.feed(raw)
        assert len(msgs) == 1


class TestFramerDifferentMessageTypes:
    def test_heartbeat(self):
        framer = MessageFramer()
        assert len(framer.feed(_make_raw("0"))) == 1

    def test_logon(self):
        framer = MessageFramer()
        assert len(framer.feed(_make_raw("A"))) == 1

    def test_new_order_single(self):
        framer = MessageFramer()
        msg = Message()
        msg.header.set(TAG_BEGIN_STRING, "FIX.4.2")
        msg.header.set(TAG_MSG_TYPE, "D")
        msg.header.set(TAG_SENDER_COMP_ID, "CLIENT")
        msg.header.set(TAG_TARGET_COMP_ID, "SERVER")
        msg.header.set(TAG_MSG_SEQ_NUM, "1")
        msg.header.set(TAG_SENDING_TIME, "20240101-00:00:00")
        msg.set_field(11, "ORD001")
        msg.set_field(55, "AAPL")
        msg.set_field(54, "1")
        msg.set_field(40, "2")
        msg.set_field(44, "150.00")
        msg.set_field(38, "100")
        raw = msg.encode()
        msgs = framer.feed(raw)
        assert len(msgs) == 1
        decoded = Message.decode(msgs[0])
        assert decoded.msg_type == "D"
        assert decoded.get_field(55) == "AAPL"
