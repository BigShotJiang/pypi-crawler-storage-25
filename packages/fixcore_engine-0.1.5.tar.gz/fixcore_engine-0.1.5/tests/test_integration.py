"""Integration tests — full vertical stack end-to-end.

Each test exercises a meaningful slice of the engine that requires multiple
layers working together and is not covered by any single unit-test file.

Scenarios
---------
1. MessageCracker dispatch over a live TCP loopback — NOS sent by initiator,
   acceptor cracks it and sends back an ExecutionReport; initiator cracks the ER.
2. FileStore persistence across reconnect — sequence numbers survive disconnect.
3. In-memory gap-fill — two sessions wired directly; ResendRequest triggers
   correct retransmit of app messages and gap-fill of admin messages.
4. Two concurrent sessions on one acceptor.
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Callable

import pytest

from fixcore.application import Application
from fixcore.log.base import Log, LogFactory
from fixcore.log.file_log import FileLog, FileLogFactory
from fixcore.message.cracker import MessageCracker
from fixcore.message.exceptions import UnsupportedMessageType
from fixcore.message.message import Message, TAG_BEGIN_STRING, TAG_MSG_TYPE
from fixcore.session.session import Session
from fixcore.session.session_id import SessionID
from fixcore.session.session_settings import SessionSettings
from fixcore.session.state import (
    MSG_HEARTBEAT,
    MSG_RESEND_REQUEST,
    MSG_SEQUENCE_RESET,
    TAG_BEGIN_SEQ_NO,
    TAG_END_SEQ_NO,
    TAG_GAP_FILL_FLAG,
    TAG_MSG_SEQ_NUM,
    TAG_POSS_DUP_FLAG,
    TAG_SENDER_COMP_ID,
    TAG_SENDING_TIME,
    TAG_TARGET_COMP_ID,
)
from fixcore.store.factory import FileStoreFactory, MemoryStoreFactory
from fixcore.store.memory import MemoryStore
from fixcore.transport.acceptor import SocketAcceptor
from fixcore.transport.initiator import SocketInitiator


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

class NullLog(Log):
    def on_incoming(self, m: str) -> None: pass
    def on_outgoing(self, m: str) -> None: pass
    def on_event(self, t: str) -> None: pass


class NullLogFactory(LogFactory):
    def create(self, sid: SessionID) -> Log:
        return NullLog()


async def _free_port() -> int:
    import socket
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


async def _wait_for(condition: Callable[[], bool], timeout: float = 5.0) -> None:
    deadline = asyncio.get_event_loop().time() + timeout
    while not condition():
        if asyncio.get_event_loop().time() > deadline:
            raise TimeoutError("Condition not met within timeout")
        await asyncio.sleep(0.05)


def _nos(seq: int = 1) -> Message:
    """Build a minimal NewOrderSingle."""
    m = Message()
    m.header.set(TAG_BEGIN_STRING, "FIX.4.2")
    m.header.set(TAG_MSG_TYPE, "D")
    m.set_field(11, f"ORD{seq:04d}")   # ClOrdID
    m.set_field(55, "AAPL")            # Symbol
    m.set_field(54, "1")               # Side=Buy
    m.set_field(40, "2")               # OrdType=Limit
    m.set_field(44, "150.00")          # Price
    m.set_field(38, "100")             # OrderQty
    m.set_field(60, "20240101-09:30:00")  # TransactTime
    m.set_field(21, "1")               # HandlInst
    return m


def _er(cl_ord_id: str) -> Message:
    """Build a minimal ExecutionReport."""
    m = Message()
    m.header.set(TAG_BEGIN_STRING, "FIX.4.2")
    m.header.set(TAG_MSG_TYPE, "8")
    m.set_field(37, "ORD-SERVER-001")  # OrderID
    m.set_field(17, "EXEC-001")        # ExecID
    m.set_field(20, "0")               # ExecTransType=New
    m.set_field(150, "0")              # ExecType=New
    m.set_field(39, "0")               # OrdStatus=New
    m.set_field(11, cl_ord_id)         # ClOrdID
    m.set_field(55, "AAPL")            # Symbol
    m.set_field(54, "1")               # Side=Buy
    m.set_field(151, "100")            # LeavesQty
    m.set_field(14, "0")               # CumQty
    m.set_field(6, "0")                # AvgPx
    return m


def _cfg_acceptor(port: int) -> str:
    return f"""
[DEFAULT]
ConnectionType=acceptor
HeartBtInt=30

[SESSION]
BeginString=FIX.4.2
SenderCompID=SERVER
TargetCompID=CLIENT
SocketAcceptHost=127.0.0.1
SocketAcceptPort={port}
"""


def _cfg_initiator(port: int, sender: str = "CLIENT", target: str = "SERVER") -> str:
    return f"""
[DEFAULT]
ConnectionType=initiator
HeartBtInt=30
ReconnectInterval=1

[SESSION]
BeginString=FIX.4.2
SenderCompID={sender}
TargetCompID={target}
SocketConnectHost=127.0.0.1
SocketConnectPort={port}
"""


# ---------------------------------------------------------------------------
# 1. MessageCracker dispatch over live TCP — NOS → ER exchange
# ---------------------------------------------------------------------------

class TestCrackerFlow:
    """Full NOS → ER round-trip using MessageCracker on both sides."""

    async def test_nos_triggers_er(self):
        port = await _free_port()
        nos_received: list[Message] = []
        er_received: list[Message] = []

        class AcceptorApp(Application, MessageCracker):
            """Receives NOS, replies with ER."""
            _session: Session | None = None

            def on_create(self, sid): pass
            def on_logon(self, sid): pass
            def on_logout(self, sid): pass
            def to_admin(self, m, sid): pass
            def to_app(self, m, sid): pass
            def from_admin(self, m, sid): pass

            def from_app(self, m: Message, sid: SessionID) -> None:
                self.crack(m, sid)

            def on_new_order_single(self, m: Message, sid: SessionID) -> None:
                nos_received.append(m)
                # Echo back an ExecutionReport
                if self._session:
                    asyncio.create_task(
                        self._session.send_app(_er(m.get_field(11)))
                    )

        class InitiatorApp(Application, MessageCracker):
            def on_create(self, sid): pass
            def on_logon(self, sid): pass
            def on_logout(self, sid): pass
            def to_admin(self, m, sid): pass
            def to_app(self, m, sid): pass
            def from_admin(self, m, sid): pass

            def from_app(self, m: Message, sid: SessionID) -> None:
                self.crack(m, sid)

            def on_execution_report(self, m: Message, sid: SessionID) -> None:
                er_received.append(m)

        acc_app = AcceptorApp()
        ini_app = InitiatorApp()
        store = MemoryStoreFactory()
        logs = NullLogFactory()

        acceptor = SocketAcceptor(
            SessionSettings.from_string(_cfg_acceptor(port)),
            acc_app, store, logs,
        )
        initiator = SocketInitiator(
            SessionSettings.from_string(_cfg_initiator(port)),
            ini_app, store, logs,
        )

        async with acceptor, initiator:
            ini_sid = SessionID("FIX.4.2", "CLIENT", "SERVER")
            await _wait_for(lambda: initiator.sessions[ini_sid].is_logged_on)

            # Give acceptor app access to its session for sending the ER
            acc_sid = SessionID("FIX.4.2", "SERVER", "CLIENT")
            acc_app._session = acceptor.sessions[acc_sid]

            await initiator.sessions[ini_sid].send_app(_nos())
            await _wait_for(lambda: bool(er_received))

        assert len(nos_received) == 1
        assert nos_received[0].get_field(55) == "AAPL"
        assert len(er_received) == 1
        assert er_received[0].get_field(39) == "0"  # OrdStatus=New

    async def test_unhandled_message_type_raises(self):
        """crack() with no handler raises UnsupportedMessageType."""
        class MinimalApp(Application, MessageCracker):
            def on_create(self, s): pass
            def on_logon(self, s): pass
            def on_logout(self, s): pass
            def to_admin(self, m, s): pass
            def to_app(self, m, s): pass
            def from_admin(self, m, s): pass
            def from_app(self, m, s): self.crack(m, s)

        app = MinimalApp()
        m = Message()
        m.header.set(TAG_MSG_TYPE, "ZZ")
        sid = SessionID("FIX.4.2", "C", "S")
        with pytest.raises(UnsupportedMessageType):
            app.from_app(m, sid)


# ---------------------------------------------------------------------------
# 2. FileStore persistence — sequence numbers survive reconnect
# ---------------------------------------------------------------------------

class TestFileStorePersistence:
    async def test_seq_nums_continue_after_reconnect(self, tmp_path: Path):
        port = await _free_port()
        logons: list[int] = []  # capture seq num of each received logon

        class TrackingApp(Application):
            def on_create(self, s): pass
            def on_logon(self, s): logons.append(1)
            def on_logout(self, s): pass
            def to_admin(self, m, s): pass
            def to_app(self, m, s): pass
            def from_admin(self, m, s): pass
            def from_app(self, m, s): pass

        store = FileStoreFactory(tmp_path / "stores")
        logs = NullLogFactory()
        ini_sid = SessionID("FIX.4.2", "CLIENT", "SERVER")

        # ── First connection ──────────────────────────────────────────
        acceptor = SocketAcceptor(
            SessionSettings.from_string(_cfg_acceptor(port)),
            TrackingApp(), store, logs,
        )
        initiator = SocketInitiator(
            SessionSettings.from_string(_cfg_initiator(port)),
            TrackingApp(), store, logs,
        )

        await acceptor.start()
        await initiator.start()
        await _wait_for(lambda: initiator.sessions[ini_sid].is_logged_on)

        # Send two app messages so sender seq advances to 4 (1=Logon, 2=NOS, 3=NOS)
        await initiator.sessions[ini_sid].send_app(_nos(1))
        await initiator.sessions[ini_sid].send_app(_nos(2))
        await asyncio.sleep(0.1)

        sender_seq_before = initiator.sessions[ini_sid]._store.next_sender_msg_seq_num()

        await initiator.stop()
        await acceptor.stop()
        await asyncio.sleep(0.1)

        # ── Second connection — new instances, same FileStore ─────────
        acceptor2 = SocketAcceptor(
            SessionSettings.from_string(_cfg_acceptor(port)),
            TrackingApp(), store, logs,
        )
        initiator2 = SocketInitiator(
            SessionSettings.from_string(_cfg_initiator(port)),
            TrackingApp(), store, logs,
        )

        await acceptor2.start()
        await initiator2.start()
        await _wait_for(lambda: initiator2.sessions[ini_sid].is_logged_on)

        sender_seq_after = initiator2.sessions[ini_sid]._store.next_sender_msg_seq_num()

        await initiator2.stop()
        await acceptor2.stop()

        # Sender seq on reconnect should be higher than after first session
        assert sender_seq_after > sender_seq_before

    async def test_filelog_written_to_disk(self, tmp_path: Path):
        port = await _free_port()
        log_dir = tmp_path / "logs"
        store = MemoryStoreFactory()
        log_factory = FileLogFactory(log_dir)

        class NullApp(Application):
            def on_create(self, s): pass
            def on_logon(self, s): pass
            def on_logout(self, s): pass
            def to_admin(self, m, s): pass
            def to_app(self, m, s): pass
            def from_admin(self, m, s): pass
            def from_app(self, m, s): pass

        acceptor = SocketAcceptor(
            SessionSettings.from_string(_cfg_acceptor(port)),
            NullApp(), store, log_factory,
        )
        initiator = SocketInitiator(
            SessionSettings.from_string(_cfg_initiator(port)),
            NullApp(), store, log_factory,
        )

        async with acceptor, initiator:
            ini_sid = SessionID("FIX.4.2", "CLIENT", "SERVER")
            await _wait_for(lambda: initiator.sessions[ini_sid].is_logged_on)
            await initiator.sessions[ini_sid].send_app(_nos())
            await asyncio.sleep(0.1)

        # Both session log files should exist and contain content
        log_files = list(log_dir.glob("*.log"))
        assert len(log_files) >= 1
        for lf in log_files:
            content = lf.read_text()
            assert len(content) > 0
            assert "<incoming>" in content or "<outgoing>" in content


# ---------------------------------------------------------------------------
# 3. In-memory gap fill — ResendRequest → retransmit/gap-fill
# ---------------------------------------------------------------------------

class InMemoryWire:
    """Connects two sessions in memory without TCP."""

    def __init__(self) -> None:
        self.a: Session | None = None
        self.b: Session | None = None
        self.a_sent: list[bytes] = []
        self.b_sent: list[bytes] = []

    async def connect(self, session_a: Session, session_b: Session) -> None:
        self.a = session_a
        self.b = session_b

        async def a_send(raw: bytes) -> None:
            self.a_sent.append(raw)
            if self.b:
                await self.b.on_data(raw)

        async def b_send(raw: bytes) -> None:
            self.b_sent.append(raw)
            if self.a:
                await self.a.on_data(raw)

        # Acceptor must be connected first so it can respond when the
        # initiator fires its Logon immediately on on_connect().
        if getattr(session_a, "_is_initiator", True):
            await session_b.on_connect(b_send)
            await session_a.on_connect(a_send)
        else:
            await session_a.on_connect(a_send)
            await session_b.on_connect(b_send)


def _make_session(cfg: str, sid: SessionID, store=None) -> Session:
    settings = SessionSettings.from_string(cfg)
    if store is None:
        store = MemoryStore()

    class _App(Application):
        def on_create(self, s): pass
        def on_logon(self, s): pass
        def on_logout(self, s): pass
        def to_admin(self, m, s): pass
        def to_app(self, m, s): pass
        def from_admin(self, m, s): pass
        def from_app(self, m, s): pass

    return Session(sid, settings, _App(), store, NullLog())


_INI_CFG = """
[DEFAULT]
ConnectionType=initiator
HeartBtInt=30

[SESSION]
BeginString=FIX.4.2
SenderCompID=CLIENT
TargetCompID=SERVER
SocketConnectHost=127.0.0.1
SocketConnectPort=9999
"""

_ACC_CFG = """
[DEFAULT]
ConnectionType=acceptor
HeartBtInt=30

[SESSION]
BeginString=FIX.4.2
SenderCompID=SERVER
TargetCompID=CLIENT
SocketAcceptHost=127.0.0.1
SocketAcceptPort=9999
"""

SID_C = SessionID("FIX.4.2", "CLIENT", "SERVER")
SID_S = SessionID("FIX.4.2", "SERVER", "CLIENT")


class TestGapFill:
    async def _logged_on_pair(self) -> tuple[Session, Session]:
        ini = _make_session(_INI_CFG, SID_C)
        acc = _make_session(_ACC_CFG, SID_S)
        wire = InMemoryWire()
        await wire.connect(ini, acc)
        # Initiator sends Logon → Acceptor responds → both LOGGED_ON
        assert ini.is_logged_on
        assert acc.is_logged_on
        return ini, acc

    async def test_app_message_retransmitted_with_poss_dup(self):
        """When acceptor sends ResendRequest, initiator re-sends stored app msg."""
        ini, acc = await self._logged_on_pair()

        # Initiator sends a NOS (seq 2)
        await ini.send_app(_nos())
        assert ini._store.next_sender_msg_seq_num() == 3

        # Build a ResendRequest from acceptor asking to resend [2, 2]
        resend = Message()
        resend.header.set(TAG_BEGIN_STRING, "FIX.4.2")
        resend.header.set(TAG_MSG_TYPE, MSG_RESEND_REQUEST)
        resend.header.set(TAG_SENDER_COMP_ID, "SERVER")
        resend.header.set(TAG_TARGET_COMP_ID, "CLIENT")
        resend.header.set(TAG_MSG_SEQ_NUM, str(acc._store.next_sender_msg_seq_num()))
        resend.header.set(TAG_SENDING_TIME, "20240101-00:00:00")
        resend.set_field(TAG_BEGIN_SEQ_NO, "2")
        resend.set_field(TAG_END_SEQ_NO, "2")

        # Capture what initiator sends in response
        retransmitted: list[Message] = []

        async def capture(raw: bytes) -> None:
            retransmitted.append(Message.decode(raw))

        ini._send_fn = capture
        await ini.on_data(resend.encode())

        # Should receive the NOS with PossDupFlag=Y
        app_msgs = [m for m in retransmitted if m.msg_type == "D"]
        assert len(app_msgs) == 1
        assert app_msgs[0].header.get_or(TAG_POSS_DUP_FLAG) == "Y"
        assert app_msgs[0].get_field(55) == "AAPL"

        await ini.on_disconnect()
        await acc.on_disconnect()

    async def test_admin_messages_gap_filled(self):
        """Resend of admin-only range produces SequenceReset-GapFill, not retransmit."""
        ini, acc = await self._logged_on_pair()

        # Initiator sends a Heartbeat (seq 2 — admin)
        await ini._send_heartbeat()
        assert ini._store.next_sender_msg_seq_num() == 3

        resend = Message()
        resend.header.set(TAG_BEGIN_STRING, "FIX.4.2")
        resend.header.set(TAG_MSG_TYPE, MSG_RESEND_REQUEST)
        resend.header.set(TAG_SENDER_COMP_ID, "SERVER")
        resend.header.set(TAG_TARGET_COMP_ID, "CLIENT")
        resend.header.set(TAG_MSG_SEQ_NUM, str(acc._store.next_sender_msg_seq_num()))
        resend.header.set(TAG_SENDING_TIME, "20240101-00:00:00")
        resend.set_field(TAG_BEGIN_SEQ_NO, "2")
        resend.set_field(TAG_END_SEQ_NO, "2")

        retransmitted: list[Message] = []

        async def capture(raw: bytes) -> None:
            retransmitted.append(Message.decode(raw))

        ini._send_fn = capture
        await ini.on_data(resend.encode())

        seq_resets = [m for m in retransmitted if m.msg_type == MSG_SEQUENCE_RESET]
        assert len(seq_resets) >= 1
        assert seq_resets[0].get_field_or(TAG_GAP_FILL_FLAG) == "Y"

        await ini.on_disconnect()
        await acc.on_disconnect()

    async def test_mixed_resend_app_and_admin(self):
        """Mixed range: admin messages gap-filled, app messages retransmitted."""
        ini, acc = await self._logged_on_pair()

        # seq 2: Heartbeat (admin)
        await ini._send_heartbeat()
        # seq 3: NOS (app)
        await ini.send_app(_nos())
        # seq 4: Heartbeat (admin)
        await ini._send_heartbeat()

        resend = Message()
        resend.header.set(TAG_BEGIN_STRING, "FIX.4.2")
        resend.header.set(TAG_MSG_TYPE, MSG_RESEND_REQUEST)
        resend.header.set(TAG_SENDER_COMP_ID, "SERVER")
        resend.header.set(TAG_TARGET_COMP_ID, "CLIENT")
        resend.header.set(TAG_MSG_SEQ_NUM, str(acc._store.next_sender_msg_seq_num()))
        resend.header.set(TAG_SENDING_TIME, "20240101-00:00:00")
        resend.set_field(TAG_BEGIN_SEQ_NO, "2")
        resend.set_field(TAG_END_SEQ_NO, "4")

        retransmitted: list[Message] = []

        async def capture(raw: bytes) -> None:
            retransmitted.append(Message.decode(raw))

        ini._send_fn = capture
        await ini.on_data(resend.encode())

        types = [m.msg_type for m in retransmitted]
        # Should have at least one SequenceReset-GapFill and one NOS
        assert MSG_SEQUENCE_RESET in types
        assert "D" in types

        nos_msg = next(m for m in retransmitted if m.msg_type == "D")
        assert nos_msg.header.get_or(TAG_POSS_DUP_FLAG) == "Y"

        await ini.on_disconnect()
        await acc.on_disconnect()


# ---------------------------------------------------------------------------
# 4. Two concurrent sessions on one acceptor
# ---------------------------------------------------------------------------

class TestMultipleSessions:
    async def test_two_initiators_on_one_acceptor(self):
        """Acceptor handles two simultaneous sessions from different initiators."""
        port = await _free_port()
        logons: dict[str, int] = {}

        class TrackingApp(Application):
            def on_create(self, s): pass
            def on_logon(self, sid: SessionID): logons[sid.target_comp_id] = logons.get(sid.target_comp_id, 0) + 1
            def on_logout(self, s): pass
            def to_admin(self, m, s): pass
            def to_app(self, m, s): pass
            def from_admin(self, m, s): pass
            def from_app(self, m, s): pass

        acc_cfg = f"""
[DEFAULT]
ConnectionType=acceptor
HeartBtInt=30

[SESSION]
BeginString=FIX.4.2
SenderCompID=SERVER
TargetCompID=CLIENT1
SocketAcceptHost=127.0.0.1
SocketAcceptPort={port}

[SESSION]
BeginString=FIX.4.2
SenderCompID=SERVER
TargetCompID=CLIENT2
SocketAcceptHost=127.0.0.1
SocketAcceptPort={port}
"""

        store = MemoryStoreFactory()
        logs = NullLogFactory()

        acceptor = SocketAcceptor(
            SessionSettings.from_string(acc_cfg),
            TrackingApp(), store, logs,
        )

        ini1 = SocketInitiator(
            SessionSettings.from_string(_cfg_initiator(port, "CLIENT1", "SERVER")),
            TrackingApp(), store, logs,
        )
        ini2 = SocketInitiator(
            SessionSettings.from_string(_cfg_initiator(port, "CLIENT2", "SERVER")),
            TrackingApp(), store, logs,
        )

        async with acceptor, ini1, ini2:
            sid1 = SessionID("FIX.4.2", "CLIENT1", "SERVER")
            sid2 = SessionID("FIX.4.2", "CLIENT2", "SERVER")

            await _wait_for(
                lambda: ini1.sessions[sid1].is_logged_on and ini2.sessions[sid2].is_logged_on
            )

            # Both initiators are logged on simultaneously
            assert ini1.sessions[sid1].is_logged_on
            assert ini2.sessions[sid2].is_logged_on

            # Each can send independently
            await ini1.sessions[sid1].send_app(_nos(1))
            await ini2.sessions[sid2].send_app(_nos(2))
            await asyncio.sleep(0.1)

    async def test_sessions_are_isolated(self):
        """Messages from CLIENT1 are not delivered to CLIENT2's session."""
        port = await _free_port()
        received: dict[str, list[Message]] = {"CLIENT1": [], "CLIENT2": []}

        class RoutingApp(Application):
            def __init__(self, name: str):
                self._name = name

            def on_create(self, s): pass
            def on_logon(self, s): pass
            def on_logout(self, s): pass
            def to_admin(self, m, s): pass
            def to_app(self, m, s): pass
            def from_admin(self, m, s): pass

            def from_app(self, m: Message, sid: SessionID) -> None:
                received[self._name].append(m)

        acc_cfg = f"""
[DEFAULT]
ConnectionType=acceptor
HeartBtInt=30

[SESSION]
BeginString=FIX.4.2
SenderCompID=SERVER
TargetCompID=CLIENT1
SocketAcceptHost=127.0.0.1
SocketAcceptPort={port}

[SESSION]
BeginString=FIX.4.2
SenderCompID=SERVER
TargetCompID=CLIENT2
SocketAcceptHost=127.0.0.1
SocketAcceptPort={port}
"""

        store = MemoryStoreFactory()
        logs = NullLogFactory()

        # Each acceptor session needs its own Application — use a factory trick
        # by giving the acceptor a router app that tracks which session received what
        class RouterApp(Application):
            def on_create(self, s): pass
            def on_logon(self, s): pass
            def on_logout(self, s): pass
            def to_admin(self, m, s): pass
            def to_app(self, m, s): pass
            def from_admin(self, m, s): pass
            def from_app(self, m: Message, sid: SessionID) -> None:
                # Route by TargetCompID (i.e. which client sent this)
                received[sid.target_comp_id].append(m)

        acceptor = SocketAcceptor(
            SessionSettings.from_string(acc_cfg),
            RouterApp(), store, logs,
        )
        ini1 = SocketInitiator(
            SessionSettings.from_string(_cfg_initiator(port, "CLIENT1", "SERVER")),
            RouterApp(), store, logs,
        )
        ini2 = SocketInitiator(
            SessionSettings.from_string(_cfg_initiator(port, "CLIENT2", "SERVER")),
            RouterApp(), store, logs,
        )

        async with acceptor, ini1, ini2:
            sid1 = SessionID("FIX.4.2", "CLIENT1", "SERVER")
            sid2 = SessionID("FIX.4.2", "CLIENT2", "SERVER")
            await _wait_for(
                lambda: ini1.sessions[sid1].is_logged_on and ini2.sessions[sid2].is_logged_on
            )

            await ini1.sessions[sid1].send_app(_nos(1))
            await ini2.sessions[sid2].send_app(_nos(2))
            await _wait_for(lambda: len(received["CLIENT1"]) > 0 and len(received["CLIENT2"]) > 0)

        # Each session received only its own messages
        assert all(m.get_field(11) == "ORD0001" for m in received["CLIENT1"])
        assert all(m.get_field(11) == "ORD0002" for m in received["CLIENT2"])
