"""Tests for FileStore — persistence, recovery, and sequence number durability."""

import pytest

from fixcore.session.session_id import SessionID
from fixcore.store.file_store import FileStore, _session_prefix


SID = SessionID("FIX.4.2", "CLIENT", "SERVER")
SID_Q = SessionID("FIX.4.2", "CLIENT", "SERVER", "Q1")

RAW_MSG_1 = b"8=FIX.4.2\x019=20\x0135=0\x0149=CLIENT\x0156=SERVER\x0110=123\x01"
RAW_MSG_2 = b"8=FIX.4.2\x019=20\x0135=0\x0149=CLIENT\x0156=SERVER\x0110=124\x01"
RAW_MSG_3 = b"8=FIX.4.2\x019=20\x0135=D\x0149=CLIENT\x0156=SERVER\x0110=125\x01"


# ---------------------------------------------------------------------------
# Filename helper
# ---------------------------------------------------------------------------

class TestSessionPrefix:
    def test_basic(self):
        assert _session_prefix(SID) == "FIX.4.2-CLIENT-SERVER"

    def test_with_qualifier(self):
        assert _session_prefix(SID_Q) == "FIX.4.2-CLIENT-SERVER-Q1"


# ---------------------------------------------------------------------------
# FileStore basics
# ---------------------------------------------------------------------------

class TestFileStoreBasics:
    def test_initial_seq_nums(self, tmp_path):
        store = FileStore(tmp_path, SID)
        assert store.next_sender_msg_seq_num() == 1
        assert store.next_target_msg_seq_num() == 1

    def test_files_created(self, tmp_path):
        FileStore(tmp_path, SID)
        assert (tmp_path / "FIX.4.2-CLIENT-SERVER.body").exists()
        assert (tmp_path / "FIX.4.2-CLIENT-SERVER.index").exists()
        assert (tmp_path / "FIX.4.2-CLIENT-SERVER.seqnums").exists()

    def test_set_and_get_single(self, tmp_path):
        store = FileStore(tmp_path, SID)
        store.set(1, RAW_MSG_1)
        assert store.get(1, 1) == [RAW_MSG_1]

    def test_set_and_get_range(self, tmp_path):
        store = FileStore(tmp_path, SID)
        store.set(1, RAW_MSG_1)
        store.set(2, RAW_MSG_2)
        store.set(3, RAW_MSG_3)
        assert store.get(1, 3) == [RAW_MSG_1, RAW_MSG_2, RAW_MSG_3]

    def test_get_partial_range(self, tmp_path):
        store = FileStore(tmp_path, SID)
        store.set(1, RAW_MSG_1)
        store.set(3, RAW_MSG_3)  # gap at 2
        assert store.get(1, 3) == [RAW_MSG_1, RAW_MSG_3]

    def test_get_beyond_stored_range(self, tmp_path):
        store = FileStore(tmp_path, SID)
        store.set(1, RAW_MSG_1)
        assert store.get(1, 5) == [RAW_MSG_1]


# ---------------------------------------------------------------------------
# Sequence number persistence
# ---------------------------------------------------------------------------

class TestSeqNumPersistence:
    def test_incr_sender_persists(self, tmp_path):
        store = FileStore(tmp_path, SID)
        store.incr_next_sender_msg_seq_num()
        store.incr_next_sender_msg_seq_num()

        store2 = FileStore(tmp_path, SID)
        assert store2.next_sender_msg_seq_num() == 3

    def test_incr_target_persists(self, tmp_path):
        store = FileStore(tmp_path, SID)
        store.incr_next_target_msg_seq_num()

        store2 = FileStore(tmp_path, SID)
        assert store2.next_target_msg_seq_num() == 2

    def test_set_sender_seq_persists(self, tmp_path):
        store = FileStore(tmp_path, SID)
        store.set_next_sender_msg_seq_num(42)

        store2 = FileStore(tmp_path, SID)
        assert store2.next_sender_msg_seq_num() == 42

    def test_set_target_seq_persists(self, tmp_path):
        store = FileStore(tmp_path, SID)
        store.set_next_target_msg_seq_num(99)

        store2 = FileStore(tmp_path, SID)
        assert store2.next_target_msg_seq_num() == 99


# ---------------------------------------------------------------------------
# Message persistence across restarts
# ---------------------------------------------------------------------------

class TestMessagePersistence:
    def test_messages_survive_restart(self, tmp_path):
        store = FileStore(tmp_path, SID)
        store.set(1, RAW_MSG_1)
        store.set(2, RAW_MSG_2)

        store2 = FileStore(tmp_path, SID)
        assert store2.get(1, 2) == [RAW_MSG_1, RAW_MSG_2]

    def test_new_messages_appended_after_restart(self, tmp_path):
        store = FileStore(tmp_path, SID)
        store.set(1, RAW_MSG_1)

        store2 = FileStore(tmp_path, SID)
        store2.set(2, RAW_MSG_2)
        assert store2.get(1, 2) == [RAW_MSG_1, RAW_MSG_2]


# ---------------------------------------------------------------------------
# Reset
# ---------------------------------------------------------------------------

class TestReset:
    def test_reset_clears_messages(self, tmp_path):
        store = FileStore(tmp_path, SID)
        store.set(1, RAW_MSG_1)
        store.reset()
        assert store.get(1, 1) == []

    def test_reset_resets_seq_nums_to_1(self, tmp_path):
        store = FileStore(tmp_path, SID)
        store.set_next_sender_msg_seq_num(50)
        store.reset()
        assert store.next_sender_msg_seq_num() == 1
        assert store.next_target_msg_seq_num() == 1

    def test_reset_persists_seq_nums(self, tmp_path):
        store = FileStore(tmp_path, SID)
        store.set_next_sender_msg_seq_num(50)
        store.reset()

        store2 = FileStore(tmp_path, SID)
        assert store2.next_sender_msg_seq_num() == 1


# ---------------------------------------------------------------------------
# Refresh
# ---------------------------------------------------------------------------

class TestRefresh:
    def test_refresh_picks_up_external_changes(self, tmp_path):
        store1 = FileStore(tmp_path, SID)
        store1.set(1, RAW_MSG_1)
        store1.set_next_sender_msg_seq_num(10)

        store2 = FileStore(tmp_path, SID)
        store2.refresh()
        assert store2.next_sender_msg_seq_num() == 10
        assert store2.get(1, 1) == [RAW_MSG_1]


# ---------------------------------------------------------------------------
# Store dir created automatically
# ---------------------------------------------------------------------------

class TestStoreDirCreation:
    def test_nested_dir_created(self, tmp_path):
        nested = tmp_path / "a" / "b" / "c"
        store = FileStore(nested, SID)
        assert nested.exists()
        assert store.next_sender_msg_seq_num() == 1
