"""Tests for FileLog — log file creation, format, and factory."""

from pathlib import Path

from fixcore.log.file_log import FileLog, FileLogFactory, _session_filename
from fixcore.session.session_id import SessionID


SID = SessionID("FIX.4.2", "CLIENT", "SERVER")
SID_Q = SessionID("FIX.4.2", "CLIENT", "SERVER", "Q1")


class TestFilename:
    def test_basic_filename(self):
        assert _session_filename(SID) == "FIX.4.2-CLIENT-SERVER.log"

    def test_qualifier_in_filename(self):
        assert _session_filename(SID_Q) == "FIX.4.2-CLIENT-SERVER-Q1.log"


class TestFileLog:
    def _log(self, tmp_path: Path) -> tuple[FileLog, Path]:
        log_file = tmp_path / _session_filename(SID)
        log = FileLog(tmp_path, SID)
        return log, log_file

    def test_log_file_created(self, tmp_path):
        log, log_file = self._log(tmp_path)
        log.close()
        assert log_file.exists()

    def test_incoming_written(self, tmp_path):
        log, log_file = self._log(tmp_path)
        log.on_incoming("8=FIX.4.2|35=0|")
        log.close()
        content = log_file.read_text()
        assert "<incoming>" in content
        assert "8=FIX.4.2|35=0|" in content

    def test_outgoing_written(self, tmp_path):
        log, log_file = self._log(tmp_path)
        log.on_outgoing("8=FIX.4.2|35=A|")
        log.close()
        content = log_file.read_text()
        assert "<outgoing>" in content
        assert "8=FIX.4.2|35=A|" in content

    def test_event_written(self, tmp_path):
        log, log_file = self._log(tmp_path)
        log.on_event("Logon complete")
        log.close()
        content = log_file.read_text()
        assert "--event--" in content
        assert "Logon complete" in content

    def test_multiple_entries_appended(self, tmp_path):
        log, log_file = self._log(tmp_path)
        log.on_event("connect")
        log.on_incoming("msg1")
        log.on_outgoing("msg2")
        log.on_event("disconnect")
        log.close()
        lines = [l for l in log_file.read_text().splitlines() if l]
        assert len(lines) == 4

    def test_appends_across_instances(self, tmp_path):
        log1, log_file = self._log(tmp_path)
        log1.on_event("first run")
        log1.close()

        log2 = FileLog(tmp_path, SID)
        log2.on_event("second run")
        log2.close()

        content = log_file.read_text()
        assert "first run" in content
        assert "second run" in content

    def test_timestamp_format(self, tmp_path):
        log, log_file = self._log(tmp_path)
        log.on_event("test")
        log.close()
        line = log_file.read_text().strip()
        # Format: YYYYMMDD-HH:MM:SS.mmm : ...
        ts = line.split(" : ")[0]
        assert len(ts) == 21          # "20240101-12:00:00.000"
        assert ts[8] == "-"
        assert ts[11] == ":"

    def test_log_dir_created_automatically(self, tmp_path):
        nested = tmp_path / "logs" / "fix"
        log = FileLog(nested, SID)
        log.on_event("hello")
        log.close()
        assert (nested / _session_filename(SID)).exists()


class TestFileLogFactory:
    def test_creates_file_log(self, tmp_path):
        factory = FileLogFactory(tmp_path)
        log = factory.create(SID)
        assert isinstance(log, FileLog)
        log.close()

    def test_different_sessions_different_files(self, tmp_path):
        factory = FileLogFactory(tmp_path)
        log1 = factory.create(SID)
        log2 = factory.create(SID_Q)
        log1.on_event("session1")
        log2.on_event("session2")
        log1.close()
        log2.close()
        assert (tmp_path / _session_filename(SID)).read_text().count("session1") == 1
        assert (tmp_path / _session_filename(SID_Q)).read_text().count("session2") == 1
