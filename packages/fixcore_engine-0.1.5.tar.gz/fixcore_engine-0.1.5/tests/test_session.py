"""Tests for the Session state machine."""

from __future__ import annotations

import asyncio
from typing import Any

import pytest

from fixcore.application import Application
from fixcore.log.base import Log
from fixcore.message.message import Message
from fixcore.session.session import Session
from fixcore.session.session_id import SessionID
from fixcore.session.session_settings import SessionSettings
from fixcore.session.state import (
    MSG_HEARTBEAT,
    MSG_LOGON,
    MSG_LOGOUT,
    MSG_REJECT,
    MSG_RESEND_REQUEST,
    MSG_SEQUENCE_RESET,
    MSG_TEST_REQUEST,
    TAG_BEGIN_SEQ_NO,
    TAG_BEGIN_STRING,
    TAG_ENCRYPT_METHOD,
    TAG_END_SEQ_NO,
    TAG_GAP_FILL_FLAG,
    TAG_HEART_BT_INT,
    TAG_MSG_SEQ_NUM,
    TAG_MSG_TYPE,
    TAG_NEW_SEQ_NO,
    TAG_POSS_DUP_FLAG,
    TAG_REF_SEQ_NUM,
    TAG_RESET_SEQ_NUM_FLAG,
    TAG_SENDER_COMP_ID,
    TAG_SENDING_TIME,
    TAG_TARGET_COMP_ID,
    TAG_TEST_REQ_ID,
    TAG_TEXT,
    SessionState,
)
from fixcore.store.memory import MemoryStore

# ---------------------------------------------------------------------------
# Test doubles
# ---------------------------------------------------------------------------

class NullLog(Log):
    def on_incoming(self, message: str) -> None: pass
    def on_outgoing(self, message: str) -> None: pass
    def on_event(self, text: str) -> None: pass


class RecordingApp(Application):
    def __init__(self) -> None:
        self.created: list[SessionID] = []
        self.logons: list[SessionID] = []
        self.logouts: list[SessionID] = []
        self.from_admin_msgs: list[Message] = []
        self.from_app_msgs: list[Message] = []
        self.to_admin_hook: Any = None  # optional callable(msg) → None

    def on_create(self, session_id: SessionID) -> None:
        self.created.append(session_id)

    def on_logon(self, session_id: SessionID) -> None:
        self.logons.append(session_id)

    def on_logout(self, session_id: SessionID) -> None:
        self.logouts.append(session_id)

    def to_admin(self, message: Message, session_id: SessionID) -> None:
        if self.to_admin_hook:
            self.to_admin_hook(message)

    def to_app(self, message: Message, session_id: SessionID) -> None:
        pass

    def from_admin(self, message: Message, session_id: SessionID) -> None:
        self.from_admin_msgs.append(message)

    def from_app(self, message: Message, session_id: SessionID) -> None:
        self.from_app_msgs.append(message)


class MessageSink:
    """Captures raw bytes sent by the Session and decodes them."""

    def __init__(self) -> None:
        self.raw: list[bytes] = []

    async def __call__(self, data: bytes) -> None:
        self.raw.append(data)

    def decoded(self) -> list[Message]:
        return [Message.decode(r) for r in self.raw]

    def last(self) -> Message:
        return Message.decode(self.raw[-1])

    def msg_types(self) -> list[str]:
        return [Message.decode(r).msg_type for r in self.raw]

    def clear(self) -> None:
        self.raw.clear()


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

INITIATOR_CFG = """
[DEFAULT]
ConnectionType=initiator
HeartBtInt=30
LogonTimeout=10
LogoutTimeout=10

[SESSION]
BeginString=FIX.4.2
SenderCompID=CLIENT
TargetCompID=SERVER
"""

ACCEPTOR_CFG = """
[DEFAULT]
ConnectionType=acceptor
HeartBtInt=30

[SESSION]
BeginString=FIX.4.2
SenderCompID=SERVER
TargetCompID=CLIENT
"""

SID_CLIENT = SessionID("FIX.4.2", "CLIENT", "SERVER")
SID_SERVER = SessionID("FIX.4.2", "SERVER", "CLIENT")


def _make_session(cfg: str, sid: SessionID) -> tuple[Session, RecordingApp, MessageSink]:
    settings = SessionSettings.from_string(cfg)
    app = RecordingApp()
    store = MemoryStore()
    log = NullLog()
    session = Session(sid, settings, app, store, log)
    sink = MessageSink()
    return session, app, sink


def _make_incoming(
    msg_type: str,
    sender: str,
    target: str,
    seq_num: int,
    begin_string: str = "FIX.4.2",
    **fields: str,
) -> bytes:
    """Build a valid incoming FIX message (correctly checksummed)."""
    msg = Message()
    msg.header.set(TAG_BEGIN_STRING, begin_string)
    msg.header.set(TAG_MSG_TYPE, msg_type)
    msg.header.set(TAG_SENDER_COMP_ID, sender)
    msg.header.set(TAG_TARGET_COMP_ID, target)
    msg.header.set(TAG_MSG_SEQ_NUM, str(seq_num))
    msg.header.set(TAG_SENDING_TIME, "20240101-00:00:00")
    for tag_str, value in fields.items():
        msg.set_field(int(tag_str), value)
    return msg.encode()


def _logon_bytes(sender: str, target: str, seq: int = 1, **kw: str) -> bytes:
    return _make_incoming(MSG_LOGON, sender, target, seq,
                          **{str(TAG_ENCRYPT_METHOD): "0", str(TAG_HEART_BT_INT): "30", **kw})


# ---------------------------------------------------------------------------
# on_create callback
# ---------------------------------------------------------------------------

class TestOnCreate:
    def test_on_create_called(self):
        session, app, _ = _make_session(INITIATOR_CFG, SID_CLIENT)
        assert SID_CLIENT in app.created


# ---------------------------------------------------------------------------
# Initiator: sends Logon on connect
# ---------------------------------------------------------------------------

class TestInitiatorLogon:
    async def test_sends_logon_on_connect(self):
        session, app, sink = _make_session(INITIATOR_CFG, SID_CLIENT)
        await session.on_connect(sink)
        assert sink.msg_types() == [MSG_LOGON]
        logon = sink.last()
        assert logon.get_field(TAG_ENCRYPT_METHOD) == "0"
        assert logon.get_field(TAG_HEART_BT_INT) == "30"
        await session.on_disconnect()

    async def test_logon_header_stamped(self):
        session, _, sink = _make_session(INITIATOR_CFG, SID_CLIENT)
        await session.on_connect(sink)
        logon = sink.last()
        assert logon.header.get(TAG_SENDER_COMP_ID) == "CLIENT"
        assert logon.header.get(TAG_TARGET_COMP_ID) == "SERVER"
        assert logon.header.get(TAG_MSG_SEQ_NUM) == "1"
        await session.on_disconnect()

    async def test_state_is_logon_timeout_after_connect(self):
        session, _, sink = _make_session(INITIATOR_CFG, SID_CLIENT)
        await session.on_connect(sink)
        assert session.state == SessionState.LOGON_TIMEOUT
        await session.on_disconnect()

    async def test_becomes_logged_on_after_logon_response(self):
        session, app, sink = _make_session(INITIATOR_CFG, SID_CLIENT)
        await session.on_connect(sink)
        await session.on_data(_logon_bytes("SERVER", "CLIENT"))
        assert session.state == SessionState.LOGGED_ON
        assert SID_CLIENT in app.logons
        await session.on_disconnect()


# ---------------------------------------------------------------------------
# Acceptor: waits for Logon, responds
# ---------------------------------------------------------------------------

class TestAcceptorLogon:
    async def test_does_not_send_logon_on_connect(self):
        session, _, sink = _make_session(ACCEPTOR_CFG, SID_SERVER)
        await session.on_connect(sink)
        assert sink.msg_types() == []
        await session.on_disconnect()

    async def test_responds_with_logon(self):
        session, app, sink = _make_session(ACCEPTOR_CFG, SID_SERVER)
        await session.on_connect(sink)
        await session.on_data(_logon_bytes("CLIENT", "SERVER"))
        assert MSG_LOGON in sink.msg_types()
        assert session.state == SessionState.LOGGED_ON
        assert SID_SERVER in app.logons
        await session.on_disconnect()


# ---------------------------------------------------------------------------
# Sequence number management
# ---------------------------------------------------------------------------

class TestSeqNums:
    async def _logged_on(self) -> tuple[Session, RecordingApp, MessageSink]:
        session, app, sink = _make_session(INITIATOR_CFG, SID_CLIENT)
        await session.on_connect(sink)
        await session.on_data(_logon_bytes("SERVER", "CLIENT"))
        sink.clear()
        return session, app, sink

    async def test_seq_num_increments_on_send(self):
        session, _, sink = await self._logged_on()
        msg = Message()
        msg.header.set(TAG_MSG_TYPE, "D")
        msg.set_field(11, "ORD001")
        await session.send_app(msg)
        sent = sink.last()
        assert sent.header.get(TAG_MSG_SEQ_NUM) == "2"
        await session.on_disconnect()

    async def test_high_seq_num_triggers_resend_request(self):
        session, _, sink = await self._logged_on()
        # Send seq=5 when expected=2
        raw = _make_incoming(MSG_HEARTBEAT, "SERVER", "CLIENT", 5)
        await session.on_data(raw)
        types = sink.msg_types()
        assert MSG_RESEND_REQUEST in types
        resend = next(m for m in sink.decoded() if m.msg_type == MSG_RESEND_REQUEST)
        assert resend.get_field(TAG_BEGIN_SEQ_NO) == "2"
        assert resend.get_field(TAG_END_SEQ_NO) == "0"
        await session.on_disconnect()

    async def test_low_seq_num_triggers_logout(self):
        session, _, sink = await self._logged_on()
        # Send seq=1 when expected=2 (already consumed 1 at logon)
        raw = _make_incoming(MSG_HEARTBEAT, "SERVER", "CLIENT", 1)
        await session.on_data(raw)
        assert MSG_LOGOUT in sink.msg_types()
        logout = next(m for m in sink.decoded() if m.msg_type == MSG_LOGOUT)
        assert "too low" in logout.get_field_or(TAG_TEXT, "")
        await session.on_disconnect()

    async def test_poss_dup_low_seq_num_silently_ignored(self):
        session, _, sink = await self._logged_on()
        raw = _make_incoming(
            MSG_HEARTBEAT, "SERVER", "CLIENT", 1,
            **{str(TAG_POSS_DUP_FLAG): "Y"}
        )
        await session.on_data(raw)
        assert MSG_LOGOUT not in sink.msg_types()
        await session.on_disconnect()


# ---------------------------------------------------------------------------
# TestRequest / Heartbeat
# ---------------------------------------------------------------------------

class TestHeartbeat:
    async def _logged_on(self) -> tuple[Session, RecordingApp, MessageSink]:
        session, app, sink = _make_session(INITIATOR_CFG, SID_CLIENT)
        await session.on_connect(sink)
        await session.on_data(_logon_bytes("SERVER", "CLIENT"))
        sink.clear()
        return session, app, sink

    async def test_test_request_triggers_heartbeat_response(self):
        session, _, sink = await self._logged_on()
        raw = _make_incoming(
            MSG_TEST_REQUEST, "SERVER", "CLIENT", 2,
            **{str(TAG_TEST_REQ_ID): "ABC123"}
        )
        await session.on_data(raw)
        assert MSG_HEARTBEAT in sink.msg_types()
        hb = next(m for m in sink.decoded() if m.msg_type == MSG_HEARTBEAT)
        assert hb.get_field(TAG_TEST_REQ_ID) == "ABC123"
        await session.on_disconnect()

    async def test_heartbeat_clears_test_req_id(self):
        session, _, sink = await self._logged_on()
        # Simulate a pending test request
        session._test_req_id = "PING1"
        raw = _make_incoming(
            MSG_HEARTBEAT, "SERVER", "CLIENT", 2,
            **{str(TAG_TEST_REQ_ID): "PING1"}
        )
        await session.on_data(raw)
        assert session._test_req_id is None
        await session.on_disconnect()


# ---------------------------------------------------------------------------
# Logout
# ---------------------------------------------------------------------------

class TestLogout:
    async def _logged_on(self) -> tuple[Session, RecordingApp, MessageSink]:
        session, app, sink = _make_session(INITIATOR_CFG, SID_CLIENT)
        await session.on_connect(sink)
        await session.on_data(_logon_bytes("SERVER", "CLIENT"))
        sink.clear()
        return session, app, sink

    async def test_send_logout_changes_state(self):
        session, _, sink = await self._logged_on()
        await session.send_logout("End of day")
        assert session.state == SessionState.LOGOUT_TIMEOUT
        logout = sink.last()
        assert logout.msg_type == MSG_LOGOUT
        assert logout.get_field(TAG_TEXT) == "End of day"
        await session.on_disconnect()

    async def test_counterparty_logout_echoed(self):
        session, app, sink = await self._logged_on()
        raw = _make_incoming(MSG_LOGOUT, "SERVER", "CLIENT", 2)
        await session.on_data(raw)
        assert MSG_LOGOUT in sink.msg_types()
        assert SID_CLIENT in app.logouts
        await session.on_disconnect()

    async def test_logout_response_completes_initiator_logout(self):
        session, app, sink = await self._logged_on()
        await session.send_logout()
        assert session.state == SessionState.LOGOUT_TIMEOUT
        await session.on_data(_make_incoming(MSG_LOGOUT, "SERVER", "CLIENT", 2))
        assert session.state == SessionState.DISCONNECTED
        await session.on_disconnect()


# ---------------------------------------------------------------------------
# SequenceReset
# ---------------------------------------------------------------------------

class TestSequenceReset:
    async def _logged_on(self) -> tuple[Session, RecordingApp, MessageSink]:
        session, app, sink = _make_session(INITIATOR_CFG, SID_CLIENT)
        await session.on_connect(sink)
        await session.on_data(_logon_bytes("SERVER", "CLIENT"))
        sink.clear()
        return session, app, sink

    async def test_gap_fill_advances_expected_seq(self):
        session, _, _ = await self._logged_on()
        raw = _make_incoming(
            MSG_SEQUENCE_RESET, "SERVER", "CLIENT", 2,
            **{str(TAG_GAP_FILL_FLAG): "Y", str(TAG_NEW_SEQ_NO): "10"}
        )
        await session.on_data(raw)
        assert session._store.next_target_msg_seq_num() == 10
        await session.on_disconnect()

    async def test_sequence_reset_sets_expected_seq(self):
        session, _, _ = await self._logged_on()
        raw = _make_incoming(
            MSG_SEQUENCE_RESET, "SERVER", "CLIENT", 2,
            **{str(TAG_GAP_FILL_FLAG): "N", str(TAG_NEW_SEQ_NO): "5"}
        )
        await session.on_data(raw)
        assert session._store.next_target_msg_seq_num() == 5
        await session.on_disconnect()


# ---------------------------------------------------------------------------
# ResendRequest — gap-fill of stored admin messages
# ---------------------------------------------------------------------------

class TestResend:
    async def test_resend_request_gap_fills_admin_messages(self):
        """When asked to resend admin messages, send a SequenceReset-GapFill."""
        session, _, sink = _make_session(INITIATOR_CFG, SID_CLIENT), None, None
        session, _, sink = _make_session(INITIATOR_CFG, SID_CLIENT)

        await session.on_connect(sink)
        # Send a heartbeat to store it (seq=2)
        await session.on_data(_logon_bytes("SERVER", "CLIENT"))
        sink.clear()
        await session._send_heartbeat()  # seq=2 — admin, will be gap-filled
        sink.clear()

        # Counterparty asks to resend [2,2]
        raw = _make_incoming(
            MSG_RESEND_REQUEST, "SERVER", "CLIENT", 2,
            **{str(TAG_BEGIN_SEQ_NO): "2", str(TAG_END_SEQ_NO): "2"}
        )
        await session.on_data(raw)

        # Should see a SequenceReset-GapFill
        assert MSG_SEQUENCE_RESET in sink.msg_types()
        seq_reset = next(m for m in sink.decoded() if m.msg_type == MSG_SEQUENCE_RESET)
        assert seq_reset.get_field(TAG_GAP_FILL_FLAG) == "Y"
        await session.on_disconnect()


# ---------------------------------------------------------------------------
# Application callbacks
# ---------------------------------------------------------------------------

class TestApplicationCallbacks:
    async def test_from_app_called_for_app_messages(self):
        session, app, sink = _make_session(INITIATOR_CFG, SID_CLIENT)
        await session.on_connect(sink)
        await session.on_data(_logon_bytes("SERVER", "CLIENT"))

        raw = _make_incoming("D", "SERVER", "CLIENT", 2,
                              **{"11": "ORD001", "55": "AAPL", "54": "1"})
        await session.on_data(raw)
        assert len(app.from_app_msgs) == 1
        assert app.from_app_msgs[0].msg_type == "D"
        await session.on_disconnect()

    async def test_from_admin_called_for_admin_messages(self):
        session, app, sink = _make_session(INITIATOR_CFG, SID_CLIENT)
        await session.on_connect(sink)
        await session.on_data(_logon_bytes("SERVER", "CLIENT"))
        assert len(app.from_admin_msgs) == 0  # Logon handled internally

        raw = _make_incoming(MSG_HEARTBEAT, "SERVER", "CLIENT", 2)
        await session.on_data(raw)
        assert len(app.from_admin_msgs) == 1
        await session.on_disconnect()

    async def test_to_admin_hook_can_modify_logon(self):
        session, app, sink = _make_session(INITIATOR_CFG, SID_CLIENT)

        def add_username(msg: Message) -> None:
            if msg.msg_type == MSG_LOGON:
                msg.set_field(553, "myuser")  # Username tag

        app.to_admin_hook = add_username
        await session.on_connect(sink)
        logon = sink.last()
        assert logon.get_field(553) == "myuser"
        await session.on_disconnect()

    async def test_on_disconnect_calls_on_logout(self):
        session, app, sink = _make_session(INITIATOR_CFG, SID_CLIENT)
        await session.on_connect(sink)
        await session.on_data(_logon_bytes("SERVER", "CLIENT"))
        assert session.is_logged_on
        await session.on_disconnect()
        assert SID_CLIENT in app.logouts


# ---------------------------------------------------------------------------
# ResetOnLogon
# ---------------------------------------------------------------------------

class TestResetOnLogon:
    async def test_reset_on_logon_resets_store(self):
        cfg = INITIATOR_CFG + "ResetOnLogon=Y\n"
        session, _, sink = _make_session(cfg, SID_CLIENT)
        # Manually advance seq nums
        session._store.set_next_sender_msg_seq_num(10)
        session._store.set_next_target_msg_seq_num(10)

        await session.on_connect(sink)
        # Store should be reset; first message is Logon at seq=1
        logon = sink.last()
        assert logon.header.get(TAG_MSG_SEQ_NUM) == "1"
        await session.on_disconnect()


# ---------------------------------------------------------------------------
# send_app guard
# ---------------------------------------------------------------------------

class TestSendAppGuard:
    async def test_send_app_raises_if_not_logged_on(self):
        session, _, sink = _make_session(INITIATOR_CFG, SID_CLIENT)
        await session.on_connect(sink)
        # Still in LOGON_TIMEOUT — not logged on
        msg = Message()
        msg.header.set(TAG_MSG_TYPE, "D")
        with pytest.raises(RuntimeError, match="not logged on"):
            await session.send_app(msg)
        await session.on_disconnect()
