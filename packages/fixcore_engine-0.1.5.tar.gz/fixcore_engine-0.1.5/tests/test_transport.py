"""Transport layer tests — loopback acceptor ↔ initiator over a real TCP socket."""

from __future__ import annotations

import asyncio

import pytest

from fixcore.application import Application
from fixcore.log.base import Log, LogFactory
from fixcore.message.message import Message
from fixcore.session.session_id import SessionID
from fixcore.session.session_settings import SessionSettings
from fixcore.session.state import SessionState
from fixcore.store.factory import MemoryStoreFactory
from fixcore.transport.acceptor import SocketAcceptor
from fixcore.transport.initiator import SocketInitiator


# ---------------------------------------------------------------------------
# Test doubles
# ---------------------------------------------------------------------------

class NullLog(Log):
    def on_incoming(self, m: str) -> None: pass
    def on_outgoing(self, m: str) -> None: pass
    def on_event(self, t: str) -> None: pass


class NullLogFactory(LogFactory):
    def create(self, sid: SessionID) -> Log:
        return NullLog()


class RecordingApp(Application):
    def __init__(self) -> None:
        self.logons: list[SessionID] = []
        self.logouts: list[SessionID] = []
        self.from_app_msgs: list[Message] = []

    def on_create(self, sid: SessionID) -> None: pass
    def on_logon(self, sid: SessionID) -> None: self.logons.append(sid)
    def on_logout(self, sid: SessionID) -> None: self.logouts.append(sid)
    def to_admin(self, msg: Message, sid: SessionID) -> None: pass
    def to_app(self, msg: Message, sid: SessionID) -> None: pass
    def from_admin(self, msg: Message, sid: SessionID) -> None: pass
    def from_app(self, msg: Message, sid: SessionID) -> None:
        self.from_app_msgs.append(msg)


# ---------------------------------------------------------------------------
# Configuration helpers
# ---------------------------------------------------------------------------

def _acceptor_cfg(port: int) -> str:
    return f"""
[DEFAULT]
ConnectionType=acceptor
HeartBtInt=30

[SESSION]
BeginString=FIX.4.2
SenderCompID=SERVER
TargetCompID=CLIENT
SocketAcceptHost=127.0.0.1
SocketAcceptPort={port}
"""


def _initiator_cfg(port: int) -> str:
    return f"""
[DEFAULT]
ConnectionType=initiator
HeartBtInt=30
ReconnectInterval=1

[SESSION]
BeginString=FIX.4.2
SenderCompID=CLIENT
TargetCompID=SERVER
SocketConnectHost=127.0.0.1
SocketConnectPort={port}
"""


async def _free_port() -> int:
    """Ask the OS for a free TCP port."""
    import socket
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


async def _wait_for(condition: "Callable[[], bool]", timeout: float = 5.0) -> None:
    deadline = asyncio.get_event_loop().time() + timeout
    while not condition():
        if asyncio.get_event_loop().time() > deadline:
            raise TimeoutError("Condition not met within timeout")
        await asyncio.sleep(0.05)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestLoopbackLogon:
    async def test_initiator_and_acceptor_reach_logged_on(self):
        port = await _free_port()
        acc_app = RecordingApp()
        ini_app = RecordingApp()
        store_factory = MemoryStoreFactory()
        log_factory = NullLogFactory()

        acceptor = SocketAcceptor(
            SessionSettings.from_string(_acceptor_cfg(port)),
            acc_app, store_factory, log_factory,
        )
        initiator = SocketInitiator(
            SessionSettings.from_string(_initiator_cfg(port)),
            ini_app, store_factory, log_factory,
        )

        async with acceptor:
            async with initiator:
                # Wait for both sides to log on
                await _wait_for(lambda: bool(ini_app.logons) and bool(acc_app.logons))

                ini_sid = SessionID("FIX.4.2", "CLIENT", "SERVER")
                acc_sid = SessionID("FIX.4.2", "SERVER", "CLIENT")
                assert ini_sid in ini_app.logons
                assert acc_sid in acc_app.logons

    async def test_sessions_are_logged_on(self):
        port = await _free_port()
        store_factory = MemoryStoreFactory()
        log_factory = NullLogFactory()

        acceptor = SocketAcceptor(
            SessionSettings.from_string(_acceptor_cfg(port)),
            RecordingApp(), store_factory, log_factory,
        )
        initiator = SocketInitiator(
            SessionSettings.from_string(_initiator_cfg(port)),
            RecordingApp(), store_factory, log_factory,
        )

        async with acceptor:
            async with initiator:
                ini_sid = SessionID("FIX.4.2", "CLIENT", "SERVER")
                await _wait_for(
                    lambda: initiator.sessions[ini_sid].is_logged_on
                )
                assert initiator.sessions[ini_sid].is_logged_on


class TestLoopbackAppMessage:
    async def test_app_message_delivered(self):
        port = await _free_port()
        acc_app = RecordingApp()
        ini_app = RecordingApp()
        store_factory = MemoryStoreFactory()
        log_factory = NullLogFactory()

        acceptor = SocketAcceptor(
            SessionSettings.from_string(_acceptor_cfg(port)),
            acc_app, store_factory, log_factory,
        )
        initiator = SocketInitiator(
            SessionSettings.from_string(_initiator_cfg(port)),
            ini_app, store_factory, log_factory,
        )

        async with acceptor:
            async with initiator:
                ini_sid = SessionID("FIX.4.2", "CLIENT", "SERVER")
                await _wait_for(lambda: initiator.sessions[ini_sid].is_logged_on)

                # Send a NewOrderSingle from initiator → acceptor
                nos = Message()
                nos.header.set(35, "D")
                nos.set_field(11, "ORD001")
                nos.set_field(55, "AAPL")
                nos.set_field(54, "1")
                nos.set_field(40, "2")
                nos.set_field(38, "100")
                nos.set_field(44, "150.00")
                nos.set_field(60, "20240101-09:30:00")
                nos.set_field(21, "1")

                await initiator.sessions[ini_sid].send_app(nos)

                await _wait_for(lambda: bool(acc_app.from_app_msgs))
                assert acc_app.from_app_msgs[0].msg_type == "D"
                assert acc_app.from_app_msgs[0].get_field(55) == "AAPL"


class TestLoopbackLogout:
    async def test_graceful_logout(self):
        port = await _free_port()
        acc_app = RecordingApp()
        ini_app = RecordingApp()
        store_factory = MemoryStoreFactory()
        log_factory = NullLogFactory()

        acceptor = SocketAcceptor(
            SessionSettings.from_string(_acceptor_cfg(port)),
            acc_app, store_factory, log_factory,
        )
        initiator = SocketInitiator(
            SessionSettings.from_string(_initiator_cfg(port)),
            ini_app, store_factory, log_factory,
        )

        async with acceptor:
            async with initiator:
                ini_sid = SessionID("FIX.4.2", "CLIENT", "SERVER")
                await _wait_for(lambda: initiator.sessions[ini_sid].is_logged_on)

                await initiator.sessions[ini_sid].send_logout("End of day")

                # Both sides should receive on_logout callback
                await _wait_for(lambda: bool(ini_app.logouts) and bool(acc_app.logouts))
                assert ini_sid in ini_app.logouts


class TestReconnect:
    async def test_initiator_reconnects_after_disconnect(self):
        port = await _free_port()
        ini_app = RecordingApp()
        store_factory = MemoryStoreFactory()
        log_factory = NullLogFactory()

        acceptor = SocketAcceptor(
            SessionSettings.from_string(_acceptor_cfg(port)),
            RecordingApp(), store_factory, log_factory,
        )
        initiator = SocketInitiator(
            SessionSettings.from_string(_initiator_cfg(port)),
            ini_app, store_factory, log_factory,
        )

        await acceptor.start()
        await initiator.start()
        try:
            # Wait for first logon
            await _wait_for(lambda: bool(ini_app.logons))
            first_logon_count = len(ini_app.logons)

            # Stop acceptor — forces TCP disconnect
            await acceptor.stop()
            await _wait_for(lambda: bool(ini_app.logouts), timeout=5.0)

            # Restart acceptor — initiator should reconnect automatically
            await acceptor.start()
            await _wait_for(
                lambda: len(ini_app.logons) > first_logon_count,
                timeout=5.0,
            )
            assert len(ini_app.logons) > first_logon_count
        finally:
            await initiator.stop()
            await acceptor.stop()
