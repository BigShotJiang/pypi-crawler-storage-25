"""Tests for MemoryStore."""

from fixcore.store.memory import MemoryStore


class TestMemoryStore:
    def test_initial_seq_nums(self):
        store = MemoryStore()
        assert store.next_sender_msg_seq_num() == 1
        assert store.next_target_msg_seq_num() == 1

    def test_incr_sender(self):
        store = MemoryStore()
        store.incr_next_sender_msg_seq_num()
        assert store.next_sender_msg_seq_num() == 2

    def test_set_and_get(self):
        store = MemoryStore()
        store.set(1, b"msg1")
        store.set(2, b"msg2")
        store.set(3, b"msg3")
        assert store.get(1, 3) == [b"msg1", b"msg2", b"msg3"]

    def test_get_partial_range(self):
        store = MemoryStore()
        store.set(1, b"msg1")
        store.set(3, b"msg3")
        assert store.get(1, 3) == [b"msg1", b"msg3"]

    def test_reset_clears_state(self):
        store = MemoryStore()
        store.set(1, b"msg1")
        store.incr_next_sender_msg_seq_num()
        store.reset()
        assert store.next_sender_msg_seq_num() == 1
        assert store.get(1, 1) == []
