"""Tests for message encoding / decoding."""

from fixcore.message.message import Message, TAG_BEGIN_STRING, TAG_MSG_TYPE, TAG_CHECKSUM, TAG_BODY_LENGTH


def _make_heartbeat() -> Message:
    msg = Message()
    msg.header.set(TAG_BEGIN_STRING, "FIX.4.2")
    msg.header.set(TAG_MSG_TYPE, "0")  # Heartbeat
    msg.header.set(49, "SENDER")       # SenderCompID
    msg.header.set(56, "TARGET")       # TargetCompID
    msg.header.set(34, "1")            # MsgSeqNum
    msg.header.set(52, "20240101-00:00:00")  # SendingTime
    return msg


class TestEncode:
    def test_encode_produces_bytes(self):
        raw = _make_heartbeat().encode()
        assert isinstance(raw, bytes)
        assert raw.endswith(b"\x01")

    def test_begin_string_is_first(self):
        raw = _make_heartbeat().encode()
        assert raw.startswith(b"8=FIX.4.2\x01")

    def test_checksum_is_last(self):
        raw = _make_heartbeat().encode()
        # last field before final SOH should be 10=NNN
        last_field = raw.rstrip(b"\x01").split(b"\x01")[-1]
        assert last_field.startswith(b"10=")
        assert len(last_field) == 6  # "10=NNN"

    def test_checksum_value_correct(self):
        raw = _make_heartbeat().encode()
        checksum_field = raw.rstrip(b"\x01").split(b"\x01")[-1]
        declared = int(checksum_field[3:])
        # checksum covers everything up to and including SOH before tag 10
        idx = raw.rfind(b"\x0110=")
        computed = sum(raw[: idx + 1]) % 256
        assert declared == computed

    def test_body_length_correct(self):
        raw = _make_heartbeat().encode()
        fields = {
            int(f.split(b"=")[0]): f.split(b"=", 1)[1]
            for f in raw.split(b"\x01")
            if b"=" in f
        }
        declared_len = int(fields[9])
        start = raw.find(b"35=")
        end = raw.rfind(b"\x0110=") + 1
        assert end - start == declared_len


class TestDecode:
    def test_roundtrip(self):
        original = _make_heartbeat()
        raw = original.encode()
        decoded = Message.decode(raw)
        assert decoded.msg_type == "0"
        assert decoded.header.get(49) == "SENDER"
        assert decoded.header.get(56) == "TARGET"

    def test_invalid_checksum_raises(self):
        import pytest

        raw = _make_heartbeat().encode()
        # corrupt the checksum digit
        corrupted = raw[:-5] + b"10=999\x01"
        with pytest.raises(ValueError, match="CheckSum"):
            Message.decode(corrupted)


class TestGroups:
    """Repeating group encode / decode tests using Logon NoMsgTypes group.

    Tags: NoMsgTypes=384 (count), RefMsgType=372 (delimiter), MsgDirection=385.
    """

    def _logon_with_groups(self) -> Message:
        from fixcore.message.field import Group

        msg = Message()
        msg.header.set(TAG_BEGIN_STRING, "FIX.4.2")
        msg.header.set(TAG_MSG_TYPE, "A")
        msg.header.set(49, "CLIENT")
        msg.header.set(56, "SERVER")
        msg.header.set(34, "1")
        msg.header.set(52, "20240101-00:00:00")
        msg.set_field(98, "0")   # EncryptMethod
        msg.set_field(108, "30") # HeartBtInt

        g1 = Group()
        g1.set_field(372, "D")   # RefMsgType
        g1.set_field(385, "S")   # MsgDirection
        msg.add_group(384, g1)

        g2 = Group()
        g2.set_field(372, "8")
        g2.set_field(385, "R")
        msg.add_group(384, g2)

        return msg

    def test_add_group_updates_count(self):
        from fixcore.message.field import Group

        msg = Message()
        msg.header.set(TAG_BEGIN_STRING, "FIX.4.2")
        msg.header.set(TAG_MSG_TYPE, "A")
        g = Group()
        g.set_field(372, "D")
        msg.add_group(384, g)
        assert msg.get_field(384) == "1"
        g2 = Group()
        g2.set_field(372, "8")
        msg.add_group(384, g2)
        assert msg.get_field(384) == "2"

    def test_group_count(self):
        msg = self._logon_with_groups()
        assert msg.group_count(384) == 2

    def test_encode_group_count_tag_in_body(self):
        raw = self._logon_with_groups().encode()
        assert b"384=2\x01" in raw

    def test_encode_multiple_instances_correct_order(self):
        raw = self._logon_with_groups().encode()
        idx_count = raw.index(b"384=2\x01")
        idx_d     = raw.index(b"372=D\x01")
        idx_s     = raw.index(b"385=S\x01")
        idx_8     = raw.index(b"372=8\x01")
        idx_r     = raw.index(b"385=R\x01")
        # count < inst1-delimiter < inst1-member < inst2-delimiter < inst2-member
        assert idx_count < idx_d < idx_s < idx_8 < idx_r

    def test_decode_without_dd_flat_fallback(self):
        """decode() without DataDictionary populates body as flat tags (backward compat)."""
        raw = self._logon_with_groups().encode()
        msg = Message.decode(raw)
        # Count tag present as plain field
        assert msg.has_field(384)
        assert msg.get_field(384) == "2"
        # Group instances appear as flat repeated delimiter tag (first value wins)
        assert msg.has_field(372)

    def test_decode_with_dd_extracts_groups(self):
        from pathlib import Path
        from fixcore.message.data_dictionary import DataDictionary

        dd = DataDictionary.from_xml(Path("specs/FIX42.xml"))
        raw = self._logon_with_groups().encode()
        msg = Message.decode(raw, data_dictionary=dd)

        assert msg.group_count(384) == 2
        groups = msg.get_groups(384)
        assert groups[0].get_field(372) == "D"
        assert groups[0].get_field(385) == "S"
        assert groups[1].get_field(372) == "8"
        assert groups[1].get_field(385) == "R"

    def test_roundtrip_with_groups(self):
        from pathlib import Path
        from fixcore.message.data_dictionary import DataDictionary

        dd = DataDictionary.from_xml(Path("specs/FIX42.xml"))
        original = self._logon_with_groups()
        raw = original.encode()
        decoded = Message.decode(raw, data_dictionary=dd)

        assert decoded.group_count(384) == original.group_count(384)
        orig_groups = original.get_groups(384)
        dec_groups = decoded.get_groups(384)
        for o, d in zip(orig_groups, dec_groups):
            assert d.get_field(372) == o.get_field(372)
            assert d.get_field(385) == o.get_field(385)

    def test_empty_group(self):
        """Count tag = 0 produces no instances on decode."""
        from pathlib import Path
        from fixcore.message.data_dictionary import DataDictionary

        dd = DataDictionary.from_xml(Path("specs/FIX42.xml"))
        msg = Message()
        msg.header.set(TAG_BEGIN_STRING, "FIX.4.2")
        msg.header.set(TAG_MSG_TYPE, "A")
        msg.header.set(49, "C")
        msg.header.set(56, "S")
        msg.header.set(34, "1")
        msg.header.set(52, "20240101-00:00:00")
        msg.set_field(98, "0")
        msg.set_field(108, "30")
        msg.set_field(384, "0")  # zero-count group

        raw = msg.encode()
        decoded = Message.decode(raw, data_dictionary=dd)
        assert decoded.group_count(384) == 0
        assert decoded.get_groups(384) == []


class TestFieldMap:
    def test_set_get(self):
        from fixcore.message.field import FieldMap

        fm = FieldMap()
        fm.set_field(1, "hello")
        assert fm.get_field(1) == "hello"
        assert fm.has_field(1)

    def test_iteration_order(self):
        from fixcore.message.field import FieldMap

        fm = FieldMap()
        for tag in (35, 49, 56, 34):
            fm.set_field(tag, str(tag))
        tags = [f.tag for f in fm]
        assert tags == [35, 49, 56, 34]
