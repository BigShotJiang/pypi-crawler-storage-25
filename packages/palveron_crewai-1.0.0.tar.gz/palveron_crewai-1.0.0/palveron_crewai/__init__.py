"""
palveron-crewai — PALVERON Governance Adapter for CrewAI
====================================================

Enterprise AI governance for CrewAI workflows. Every task output gets checked
against your PALVERON policies before it flows to the next task.

Two integration patterns:

1. **Task Guardrail** — validates and blocks task outputs::

    from palveron_crewai import palveron_guardrail

    task = Task(
        description="...",
        agent=agent,
        guardrail=palveron_guardrail(api_key="pv_live_xxx"),
    )

2. **Step Callback** — governs every agent step across the crew::

    from palveron_crewai import PalveronStepCallback

    crew = Crew(
        agents=[...],
        tasks=[...],
        step_callback=PalveronStepCallback(api_key="pv_live_xxx"),
    )
"""

from __future__ import annotations

import logging
import time
from typing import Any, Callable, Optional, Tuple, Union

from palveron import Palveron, VerifyRequest, PalveronError

__version__ = "0.1.0"
__all__ = [
    "palveron_guardrail",
    "PalveronStepCallback",
    "PalveronCrewGovernance",
]

logger = logging.getLogger("palveron_crewai")


# ── Task Guardrail Factory ───────────────────────────────────


def palveron_guardrail(
    api_key: str,
    *,
    base_url: str = "https://gateway.palveron.com",
    fail_open: bool = False,
    metadata: Optional[dict[str, Any]] = None,
) -> Callable[..., Tuple[bool, Any]]:
    """
    Create a PALVERON governance guardrail for CrewAI tasks.

    Returns a function compatible with CrewAI's ``guardrail`` parameter.
    The function receives a ``TaskOutput`` and returns ``(True, output)``
    if allowed, or ``(False, feedback)`` if blocked.

    Args:
        api_key: PALVERON project or agent API key.
        base_url: Gateway URL (default: https://gateway.palveron.com).
        fail_open: Allow outputs when gateway is unreachable (default: False).
        metadata: Extra metadata attached to every governance trace.

    Example::

        from crewai import Task
        from palveron_crewai import palveron_guardrail

        task = Task(
            description="Write a customer report",
            expected_output="A report with customer insights",
            agent=analyst_agent,
            guardrail=palveron_guardrail(api_key="pv_live_xxx"),
            guardrail_max_retries=2,
        )

    Returns:
        A guardrail function for CrewAI Task.
    """
    client = Palveron(api_key=api_key, base_url=base_url)
    base_meta = metadata or {}

    def _guardrail(task_output: Any) -> Tuple[bool, Any]:
        # Extract text from TaskOutput
        text = _extract_output_text(task_output)
        if not text:
            return (True, task_output)

        try:
            result = client.verify(
                VerifyRequest(
                    prompt=text,
                    metadata={
                        **base_meta,
                        "source": "crewai",
                        "event": "task_guardrail",
                    },
                )
            )

            if result.is_blocked:
                feedback = (
                    f"Output blocked by PALVERON governance policy. "
                    f"Reason: {result.reason}. "
                    f"Trace: {result.trace_id}. "
                    f"Please revise your output to comply with the policy."
                )
                logger.warning(
                    "🚫 PALVERON BLOCKED task output — %s (trace: %s)",
                    result.reason, result.trace_id,
                )
                return (False, feedback)

            if result.decision.value == "MODIFIED":
                logger.info(
                    "✏️ PALVERON MODIFIED task output — PII redacted (trace: %s)",
                    result.trace_id,
                )
                # Return the sanitized output
                return (True, result.output)

            logger.debug(
                "✅ PALVERON ALLOWED task output (trace: %s, %dms)",
                result.trace_id, result.latency_ms,
            )
            return (True, task_output)

        except PalveronError as e:
            if fail_open:
                logger.warning("⚠️ PALVERON gateway error, fail-open: %s", e)
                return (True, task_output)
            else:
                logger.error("🚫 PALVERON gateway error, fail-closed: %s", e)
                return (False, f"Governance check failed (fail-closed): {e}")

        except Exception as e:
            if fail_open:
                logger.warning("⚠️ Unexpected error in PALVERON guardrail, fail-open: %s", e)
                return (True, task_output)
            else:
                return (False, f"Governance error: {e}")

    return _guardrail


# ── Step Callback ────────────────────────────────────────────


class PalveronStepCallback:
    """
    CrewAI step callback that governs every agent step.

    Attach to a Crew to get governance checks on all agent outputs,
    not just specific tasks.

    Example::

        from crewai import Crew
        from palveron_crewai import PalveronStepCallback

        callback = PalveronStepCallback(api_key="pv_live_xxx")

        crew = Crew(
            agents=[researcher, writer],
            tasks=[research_task, write_task],
            step_callback=callback,
        )

        # Every agent step is now governed
        result = crew.kickoff(inputs={"topic": "AI Safety"})

        # Access governance records
        print(f"Checked: {callback.check_count}, Blocked: {callback.blocked_count}")
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = "https://gateway.palveron.com",
        fail_open: bool = False,
        metadata: Optional[dict[str, Any]] = None,
    ):
        self._client = Palveron(api_key=api_key, base_url=base_url)
        self._fail_open = fail_open
        self._base_metadata = metadata or {}
        self._check_count = 0
        self._blocked_count = 0
        self._trace_ids: list[str] = []

    def __call__(self, step_output: Any) -> None:
        """Called by CrewAI after each agent step."""
        text = _extract_output_text(step_output)
        if not text:
            return

        self._check_count += 1

        try:
            result = self._client.verify(
                VerifyRequest(
                    prompt=text,
                    metadata={
                        **self._base_metadata,
                        "source": "crewai",
                        "event": "step_callback",
                    },
                )
            )

            if result.trace_id:
                self._trace_ids.append(result.trace_id)

            if result.is_blocked:
                self._blocked_count += 1
                logger.warning(
                    "🚫 PALVERON BLOCKED agent step — %s (trace: %s)",
                    result.reason, result.trace_id,
                )
            elif result.decision.value == "MODIFIED":
                logger.info(
                    "✏️ PALVERON MODIFIED agent step — PII redacted (trace: %s)",
                    result.trace_id,
                )
            else:
                logger.debug(
                    "✅ PALVERON ALLOWED agent step (trace: %s)",
                    result.trace_id,
                )

        except Exception as e:
            if self._fail_open:
                logger.warning("⚠️ PALVERON step callback error, fail-open: %s", e)
            else:
                logger.error("🚫 PALVERON step callback error: %s", e)

    @property
    def check_count(self) -> int:
        return self._check_count

    @property
    def blocked_count(self) -> int:
        return self._blocked_count

    @property
    def trace_ids(self) -> list[str]:
        return list(self._trace_ids)


# ── Convenience: Combined Governance ─────────────────────────


class PalveronCrewGovernance:
    """
    Convenience class that creates both guardrail functions and step callbacks
    from a single configuration.

    Example::

        from palveron_crewai import PalveronCrewGovernance

        gov = PalveronCrewGovernance(api_key="pv_live_xxx")

        # Use as task guardrail
        task = Task(..., guardrail=gov.task_guardrail())

        # Use as step callback
        crew = Crew(..., step_callback=gov.step_callback())

        # After execution
        print(gov.summary())
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = "https://gateway.palveron.com",
        fail_open: bool = False,
        metadata: Optional[dict[str, Any]] = None,
    ):
        self._api_key = api_key
        self._base_url = base_url
        self._fail_open = fail_open
        self._metadata = metadata or {}
        self._step_cb: Optional[PalveronStepCallback] = None

    def task_guardrail(self) -> Callable[..., Tuple[bool, Any]]:
        """Create a guardrail function for a CrewAI Task."""
        return palveron_guardrail(
            api_key=self._api_key,
            base_url=self._base_url,
            fail_open=self._fail_open,
            metadata=self._metadata,
        )

    def step_callback(self) -> PalveronStepCallback:
        """Create a step callback for a CrewAI Crew."""
        self._step_cb = PalveronStepCallback(
            api_key=self._api_key,
            base_url=self._base_url,
            fail_open=self._fail_open,
            metadata=self._metadata,
        )
        return self._step_cb

    def summary(self) -> dict[str, Any]:
        """Governance summary after crew execution."""
        if self._step_cb:
            return {
                "checks": self._step_cb.check_count,
                "blocked": self._step_cb.blocked_count,
                "trace_ids": self._step_cb.trace_ids,
            }
        return {"checks": 0, "blocked": 0, "trace_ids": []}


# ── Helpers ──────────────────────────────────────────────────


def _extract_output_text(output: Any) -> str:
    """Extract text content from various CrewAI output types."""
    if isinstance(output, str):
        return output

    # CrewAI TaskOutput
    if hasattr(output, "raw"):
        return str(output.raw)

    # CrewAI AgentFinish or similar
    if hasattr(output, "output"):
        return str(output.output)

    # Dict with common keys
    if isinstance(output, dict):
        for key in ("raw", "output", "text", "result", "content"):
            if key in output:
                return str(output[key])

    # Fallback
    text = str(output)
    return text if len(text) > 10 else ""  # Skip trivially short outputs
