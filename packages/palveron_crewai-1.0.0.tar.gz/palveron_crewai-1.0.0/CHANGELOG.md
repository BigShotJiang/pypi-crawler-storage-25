# Changelog

All notable changes to `palveron-crewai` will be documented in this file.

This project follows [Semantic Versioning](https://semver.org/).

## [1.0.0] — 2026-05-17

### Added
- Initial public release of `palveron-crewai` on PyPI
- `PalveronGovernance` plugin — task-level governance hook for every
  CrewAI agent action
- Per-crew, per-task, per-agent audit trails with trace IDs that link
  back to the Palveron dashboard
- Automatic blocking of disallowed tool invocations, with the policy
  reason surfaced as a CrewAI task exception
- MCP-style `RequestContext` propagation so multi-agent chains keep
  their context across the full audit trail
- Compatible with the synchronous `Palveron` and the async `AsyncPalveron`
  clients from `palveron-sdk`
- Full type hints (PEP 561 compliant via `py.typed`)
