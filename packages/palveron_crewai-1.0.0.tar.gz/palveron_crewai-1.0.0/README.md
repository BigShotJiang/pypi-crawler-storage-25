# palveron-crewai

PALVERON AI Governance adapter for **CrewAI** — task guardrails, step callbacks, and audit trails for every crew execution.

[![PyPI](https://img.shields.io/pypi/v/palveron-crewai.svg?style=flat-square)](https://pypi.org/project/palveron-crewai/)
[![License](https://img.shields.io/badge/license-Apache%202.0-blue.svg?style=flat-square)](https://opensource.org/licenses/Apache-2.0)

---

Add one guardrail function. Every task output gets checked against your [PALVERON](https://palveron.com) governance policies. PII is caught. Blocked outputs trigger retries. Everything gets an audit trail.

## Installation

```bash
pip install palveron-crewai
```

## Quick Start: Task Guardrail

```python
from crewai import Agent, Task, Crew
from palveron_crewai import palveron_guardrail

# Create PALVERON guardrail
guardrail = palveron_guardrail(api_key="pv_live_xxx")

# Attach to any task
report_task = Task(
    description="Write a customer analysis report",
    expected_output="A report with customer insights",
    agent=analyst_agent,
    guardrail=guardrail,           # ← PALVERON governance
    guardrail_max_retries=2,       # Retry if blocked
)
```

If the agent's output contains PII, secrets, or violates your policies, CrewAI automatically retries the task with PALVERON feedback.

## Quick Start: Step Callback

```python
from palveron_crewai import PalveronStepCallback

callback = PalveronStepCallback(api_key="pv_live_xxx")

crew = Crew(
    agents=[researcher, writer],
    tasks=[research_task, write_task],
    step_callback=callback,  # ← Every step governed
)

result = crew.kickoff(inputs={"topic": "AI Safety"})

# Governance summary
print(f"Checked: {callback.check_count}, Blocked: {callback.blocked_count}")
print(f"Traces: {callback.trace_ids}")
```

## Combined Governance

```python
from palveron_crewai import PalveronCrewGovernance

gov = PalveronCrewGovernance(api_key="pv_live_xxx")

task = Task(..., guardrail=gov.task_guardrail())
crew = Crew(..., step_callback=gov.step_callback())

result = crew.kickoff(inputs={...})
print(gov.summary())  # {"checks": 12, "blocked": 1, "trace_ids": [...]}
```

## Configuration

```python
guardrail = palveron_guardrail(
    api_key="pv_live_xxx",
    base_url="https://gateway.internal.corp:8080",  # On-prem
    fail_open=False,          # Block on gateway errors (default)
    metadata={"team": "ml"},  # Extra metadata on traces
)
```

## How It Works

| Decision | Guardrail Behavior |
|----------|-------------------|
| `ALLOWED` | `(True, output)` — task proceeds |
| `MODIFIED` | `(True, sanitized_output)` — proceeds with PII redacted |
| `BLOCKED` | `(False, feedback)` — CrewAI retries with PALVERON feedback |

## Links

- [Documentation](https://docs.palveron.com/integrations/crewai)
- [PALVERON Dashboard](https://app.palveron.com)
- [GitHub](https://github.com/palveron/palveron-crewai)

## License

[Apache 2.0](./LICENSE)
