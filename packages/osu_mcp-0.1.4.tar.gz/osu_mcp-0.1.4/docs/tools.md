# osu-mcp Tools Reference

12 tools across 5 domains. All accept JSON-serializable inputs validated by pydantic and return JSON-serializable outputs.

## Type aliases

```
Mode           = "osu" | "taiko" | "fruits" | "mania"
ScoreType      = "best" | "recent" | "firsts"
RankingType    = "pp" | "score" | "charts"
UserMetric     = "pp" | "accuracy" | "play_count" | "ranked_score" |
                 "total_score" | "level" | "global_rank" | "country_rank"
BeatmapStatus  = "ranked" | "approved" | "qualified" | "loved" |
                 "pending" | "graveyard"
CountryCode    = string (ISO 3166-1 alpha-2, e.g. "EC", "JP")
ModCode        = string (HD, HR, DT, FL, EZ, NF, SD, PF, NC, HT, RX, AP, SO, TD)
```

## Users

### `get_user_summary`
**Input:** `{ user_id_or_name: string, mode?: Mode, include?: ("recent"|"best"|"firsts")[] }`
**Output:** UserSummary (id, username, country_code, pp, accuracy, play_count, ranked_score, level, global_rank, country_rank, avatar_url, joined_at) + optional embedded score arrays.

### `compare_users`
**Input:** `{ users: string[] (2-5), mode: Mode, metrics: UserMetric[] }`
**Output:** `{ count: int, users: [{ username, id, country_code, metrics: { ...selected } }] }`

## Scores

### `get_user_scores`
**Input:** `{ user_id: int, type: ScoreType, mode: Mode, limit?: int (1-100, default 10) }`
**Output:** `{ count: int, scores: ScoreSummary[] }`

### `get_score_details`
**Input:** `{ score_id: int, mode: Mode }`
**Output:** ScoreSummary

## Beatmaps

### `search_beatmaps`
**Input:** `{ query: string, mode?: Mode, status?: BeatmapStatus, difficulty_range?: [min,max], length_range?: [min,max], bpm_range?: [min,max], limit?: int (1-50, default 20) }`
**Output:** `{ count: int, beatmapsets: BeatmapsetSummary[] }`

### `get_beatmap_details`
**Input:** `{ beatmap_id: int }`
**Output:** BeatmapSummary (id, version, difficulty_rating, ar, od, cs, hp, bpm, total_length, max_combo, status)

### `get_beatmap_scores`
**Input:** `{ beatmap_id: int, mode?: Mode, mods?: ModCode[], limit?: int (1-100, default 50) }`
**Output:** `{ count: int, scores: [{ id, user_id, score, pp, accuracy, max_combo, rank, mods }] }`

### `get_beatmapset`
**Input:** `{ beatmapset_id: int }`
**Output:** BeatmapsetSummary + `beatmaps: [{ id, version, difficulty_rating }]`

## Rankings

### `get_rankings`
**Input:** `{ type: RankingType, mode: Mode, country?: CountryCode, page?: int (1-200) }`
**Output:** `{ count: int, type, mode, entries: RankingEntry[] }`

### `get_country_top`
**Input:** `{ country_code: CountryCode, mode: Mode, limit?: int (1-100, default 50) }`
**Output:** `{ count: int, country_code, mode, entries: RankingEntry[] }`

## Meta

### `get_news_posts`
**Input:** `{ limit?: int (1-50, default 10), year?: int }`
**Output:** `{ count: int, posts: [{ id, title, slug, published_at, author }] }`

### `get_seasonal_backgrounds`
**Input:** `{}` (no parameters)
**Output:** `{ count: int, ends_at: string, backgrounds: [{ url, artist }] }`
