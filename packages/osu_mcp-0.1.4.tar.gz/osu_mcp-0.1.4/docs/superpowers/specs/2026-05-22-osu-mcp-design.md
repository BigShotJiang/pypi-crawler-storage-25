# osu-mcp v0.1 — Design Spec

**Fecha:** 2026-05-22
**Estado:** Aprobado para implementación
**Autor:** Imanol Miranda

---

## 1. Overview

`osu-mcp` es un servidor MCP (Model Context Protocol) que expone la osu! API v2 como tools consumibles desde Claude Desktop u otros clientes MCP. Es el cimiento reutilizable para una serie de proyectos derivados (Analizador de replays, Skill Match Recommender, Auto-modder IA, reportes de meta).

**Objetivo v0.1:** publicar un paquete PyPI (`osu-mcp`) con 12 tools que cubren los 3 ejes de uso primarios: progreso personal, análisis comparativo, exploración de beatmaps. Repo público en GitHub con README, GIF demo, tests, CI, y workflow de release.

**No-goals v0.1:**
- Parser de archivos `.osr` (replays binarios) — eso es el proyecto #21.
- Parser estructural de archivos `.osu` — eso es #24.
- OAuth2 Authorization Code (acceso a data privada del user logueado) — Client Credentials es suficiente.
- Cache persistente entre restarts — cache LRU in-memory es suficiente para v0.1.
- Multiplayer / forum / chat endpoints — fuera de alcance, agregables en v0.2+.

## 2. Decisiones lockeadas

| Decisión | Valor | Razón |
|---|---|---|
| Lenguaje | Python 3.11+ | Stack del usuario; permite `ossapi` |
| Cliente API | `ossapi` | Lib más madura de osu! API v2 (~30 endpoints, tipos completos, auth manejada) |
| MCP SDK | `mcp` (Python oficial) | SDK oficial mantenido por Anthropic |
| Transport | stdio (JSON-RPC) | Estándar MCP, integra con Claude Desktop sin servidor HTTP |
| Auth | OAuth2 Client Credentials | Suficiente para data pública (los 3 use cases v0.1 son data pública) |
| Distribución | PyPI + GitHub público | Polish portafolio; `uv tool install osu-mcp` |
| Tool granularity | Medium-grained, ~12 tools | Balance entre cobertura y UX para Claude |
| Modos osu! | Los 4 (standard/taiko/catch/mania) | ossapi los maneja con un parámetro `mode` |
| Build tool | `uv` + `hatchling` | Stack moderno; ya usado por el autor |
| Testing | pytest + pytest-mock + coverage.py | Estándar Python |
| Lint/Type | ruff + mypy `--strict` | Estándar moderno Python |
| Licencia | MIT | Permisiva, alinea con resto del ecosistema MCP |

## 3. Arquitectura

### Layout del repo

```
osu-mcp/
├── pyproject.toml              # uv build, deps, entry point
├── README.md                   # Setup + ejemplos + GIF demo
├── LICENSE                     # MIT
├── CHANGELOG.md                # Keep-a-changelog format
├── .github/workflows/
│   ├── test.yml                # pytest + ruff + mypy en push/PR
│   └── publish.yml             # PyPI release en tag v*
├── src/osu_mcp/
│   ├── __init__.py             # __version__
│   ├── server.py               # MCP entry: registra tools, stdio loop
│   ├── config.py               # Carga client_id/secret (env → ~/.config → error)
│   ├── client.py               # ossapi wrapper + cache LRU + retry/backoff
│   ├── errors.py               # Excepciones tipadas → códigos MCP
│   ├── models.py               # Pydantic v2 schemas (inputs/outputs)
│   └── tools/
│       ├── __init__.py         # @register_tool decorator + registry
│       ├── users.py            # get_user_summary, compare_users
│       ├── scores.py           # get_user_scores, get_score_details
│       ├── beatmaps.py         # search/details/scores/set
│       ├── rankings.py         # get_rankings, get_country_top
│       └── meta.py             # get_news_posts, get_seasonal_backgrounds
├── tests/
│   ├── unit/                   # Mock ossapi, ≥85% cobertura
│   ├── integration/            # Opt-in (env OSU_RUN_INTEGRATION=1)
│   ├── smoke/                  # tools/list end-to-end via subprocess
│   └── fixtures/               # Sample JSON responses
└── docs/
    ├── superpowers/specs/      # Este documento
    └── tools.md                # Reference auto-gen desde docstrings
```

### Diagrama de componentes

```
┌──────────────────────────────────────────────┐
│              Claude Desktop                   │
└──────────────────┬───────────────────────────┘
                   │ stdio (JSON-RPC)
                   │ tools/list, tools/call
                   ▼
┌──────────────────────────────────────────────┐
│  server.py        — MCP server entry          │
│  ├─ register_tool decorator collects tools    │
│  └─ stdio loop routes calls                   │
└──────────────────┬───────────────────────────┘
                   │ validated input (pydantic)
                   ▼
┌──────────────────────────────────────────────┐
│  tools/*.py       — Domain modules            │
│  ├─ users.py      ├─ scores.py                │
│  ├─ beatmaps.py   ├─ rankings.py              │
│  └─ meta.py                                   │
└──────────────────┬───────────────────────────┘
                   │ client.method(**kwargs)
                   ▼
┌──────────────────────────────────────────────┐
│  client.py        — ossapi singleton          │
│  ├─ LRU cache (TTL configurable por método)   │
│  ├─ Retry exp en 429/5xx                      │
│  └─ Token refresh transparente                │
└──────────────────┬───────────────────────────┘
                   │
                   ▼
              ossapi → osu! API v2 (HTTPS)
```

## 4. Componentes

### `server.py`
- Entry point: `osu-mcp = osu_mcp.server:main` en `pyproject.toml`.
- Al startup: carga config, inicializa client, importa `tools/` (cada módulo registra tools al importarse).
- Ejecuta `mcp.server.Server` con stdio transport.
- Handler de `tools/list` devuelve schemas pydantic convertidos a JSONSchema.
- Handler de `tools/call` resuelve por nombre y delega.

### `client.py`
- Singleton `OsuClient` que envuelve `ossapi.Ossapi`.
- **Cache**: `cachetools.TTLCache` per-method. Key = `(method_name, sorted_kwargs_tuple)`. TTL default 5min, configurable por método:
  - `get_user_summary` → 5min
  - `search_beatmaps` → 5min
  - `get_beatmap_details` → 1h (mapas no cambian)
  - `get_rankings` → 15min
  - `get_seasonal_backgrounds` → 24h
  - Bypass con kwarg `bypass_cache=True`.
- **Retry**: en 429 y 5xx, exponencial 1s → 2s → 4s (3 intentos). En network errors, 1 retry tras 2s.
- **Auth**: `ossapi` maneja token refresh; nuestro código solo provee creds al init.

### `tools/<dominio>.py`
- Cada módulo expone funciones decoradas con `@register_tool(name, description, input_model, output_model)`.
- Flujo de un tool:
  1. Recibe dict de inputs de Claude.
  2. Valida con `input_model` (pydantic).
  3. Llama método de `client`.
  4. Transforma respuesta a `output_model` (recortando campos no útiles).
  5. Devuelve dict serializable.
- Tools no lanzan excepciones genéricas — todo error tipado va al handler central de `server.py` que lo mapea a código MCP.

### `models.py`
- Pydantic v2 models. Dos categorías:
  - **Inputs**: validan parámetros que llegan de Claude. Defaults sensatos. `Literal[...]` para enums (mode, score_type, etc.).
  - **Outputs**: schemas recortados de la respuesta de ossapi. Objetivo: minimizar tokens en cada response a Claude (no devolver el JSON crudo con 50+ campos cuando solo 8 son útiles).
- Ejemplo de output recorte: el endpoint `/users/{id}` devuelve ~80 campos. Nuestro `UserSummaryOutput` expone 12: `id, username, country_code, pp, accuracy, play_count, ranked_score, level, global_rank, country_rank, avatar_url, joined_at`.

### `config.py`
- Búsqueda de creds en orden:
  1. Env vars `OSU_CLIENT_ID` y `OSU_CLIENT_SECRET`.
  2. Archivo `~/.config/osu-mcp/config.toml` (Linux/Mac) o `%APPDATA%\osu-mcp\config.toml` (Windows).
  3. Si nada: raise `ConfigError` con instrucciones precisas (URL `https://osu.ppy.sh/home/account/edit`, formato del config.toml, comando para set env vars).

### `errors.py`
- Jerarquía de excepciones tipadas:
  ```
  OsuMcpError (base)
  ├── ConfigError           → MCP -32000 (server error)
  ├── AuthError             → MCP -32001
  ├── RateLimitError        → MCP -32002 (con retry_after_seconds)
  ├── NotFoundError         → MCP -32003 (con resource, params)
  ├── ValidationError       → MCP -32004 (con field, message)
  ├── ApiError              → MCP -32005 (5xx upstream)
  └── NetworkError          → MCP -32006
  ```
- Handler central en `server.py` mapea cada excepción a la respuesta MCP correcta.

## 5. Los 12 tools

### Type aliases compartidos

```python
Mode = Literal["osu", "taiko", "fruits", "mania"]            # ossapi usa "fruits", no "catch"
ScoreType = Literal["best", "recent", "firsts"]
RankingType = Literal["pp", "score", "charts"]
UserMetric = Literal["pp", "accuracy", "play_count", "ranked_score", "total_score", "level", "global_rank", "country_rank"]
BeatmapStatus = Literal["ranked", "approved", "qualified", "loved", "pending", "graveyard"]
CountryCode = str  # ISO 3166-1 alpha-2 (e.g., "EC", "JP"), validado con `pycountry` o regex
ModCode = str      # 2-letra (HD, HR, DT, FL, EZ, NF, SD, PF, NC, HT, RX, AP, SO, TD)
```

### Tabla de tools

| # | Nombre | Módulo | Inputs principales | Propósito |
|---|---|---|---|---|
| 1 | `get_user_summary` | users.py | `user_id_or_name: str`, `mode: Mode = "osu"`, `include: list[Literal["recent","best","firsts"]] = []` | Profile + stats; opcionalmente embebe N scores recientes/mejores/firsts |
| 2 | `compare_users` | users.py | `users: list[str]` (2-5), `mode: Mode`, `metrics: list[UserMetric]` | Side-by-side de stats elegidas |
| 3 | `get_user_scores` | scores.py | `user_id: int`, `type: ScoreType`, `mode: Mode`, `limit: int = 10` (1-100) | Lista de scores con filtros |
| 4 | `get_score_details` | scores.py | `score_id: int`, `mode: Mode` | Un score con todos sus atributos |
| 5 | `search_beatmaps` | beatmaps.py | `query: str`, `mode?: Mode`, `status?: BeatmapStatus`, `difficulty_range?: tuple[float,float]`, `length_range?: tuple[int,int]`, `bpm_range?: tuple[int,int]`, `limit: int = 20` (1-50) | Búsqueda con filtros combinables |
| 6 | `get_beatmap_details` | beatmaps.py | `beatmap_id: int` | Beatmap + AR/OD/CS/HP + max_combo + difficulty_attributes |
| 7 | `get_beatmap_scores` | beatmaps.py | `beatmap_id: int`, `mode?: Mode`, `mods?: list[ModCode]`, `limit: int = 50` (1-100) | Top scores en un beatmap |
| 8 | `get_beatmapset` | beatmaps.py | `beatmapset_id: int` | Mapset completo (todos los diffs + metadata creator) |
| 9 | `get_rankings` | rankings.py | `type: RankingType`, `mode: Mode`, `country?: CountryCode`, `page: int = 1` (1-200) | Rankings global o por país |
| 10 | `get_country_top` | rankings.py | `country_code: CountryCode`, `mode: Mode`, `limit: int = 50` (1-100) | Shortcut: top N de un país (e.g., "EC" para Ecuador) |
| 11 | `get_news_posts` | meta.py | `limit: int = 10` (1-50), `year?: int` | News posts (base para #27 reportes meta) |
| 12 | `get_seasonal_backgrounds` | meta.py | — | Backgrounds estacionales actuales; demuestra cobertura wide |

**Convenciones de output:**
- Todos los tools devuelven un dict JSON-serializable.
- Cuando aplica, incluyen un campo `_cached: bool` indicando si vino del cache (debug).
- Listas siempre tienen un campo `count: int` adicional para que Claude sepa cuánto trajo sin contar elementos.
- Output models recortan campos: target ≤15 campos por entidad para minimizar tokens en cada response.

## 6. Data flow

```
1. Claude Desktop manda tools/call:
   { "name": "get_user_summary",
     "arguments": { "user_id_or_name": "Cookiezi", "mode": "osu" } }

2. server.py:
   - Lookup en registry → tools/users.py::get_user_summary_impl
   - Valida arguments con UserSummaryInput pydantic
   - Llama get_user_summary_impl(input)

3. tools/users.py::get_user_summary_impl:
   - Llama client.get_user("Cookiezi", mode="osu")

4. client.py::get_user:
   - Cache lookup: ("get_user", "Cookiezi", "osu")
     - Hit: devuelve cached, marca _cached=True
     - Miss: ossapi.user("Cookiezi", mode="osu") → cache.set → devuelve fresh
   - Si 429/5xx en ossapi: retry exp 1s → 2s → 4s
   - Si auth expira: ossapi refresca token transparente

5. tools/users.py:
   - Toma respuesta de ossapi (UserExtended)
   - Recorta a UserSummaryOutput pydantic
   - Devuelve dict

6. server.py:
   - Empaqueta como respuesta MCP
   - stdio JSON-RPC → Claude Desktop
```

## 7. Error handling

| Categoría | Trigger | Acción | Resultado |
|---|---|---|---|
| `ConfigError` | Creds faltantes al startup | No retry. Log + raise. Server no arranca. | Mensaje claro con setup instructions |
| `AuthError` | 401 de osu! API | No retry (creds inválidas). Log. | MCP -32001 con hint "verificá CLIENT_ID/SECRET" |
| `RateLimitError` | 429 tras 3 retries | Backoff exp 1s/2s/4s, después raise | MCP -32002 con `retry_after_seconds` |
| `NotFoundError` | 404 | No retry | MCP -32003 con `resource`, `params` para que Claude reformule |
| `ValidationError` | Input pydantic inválido | No retry | MCP -32004 con `field`, `message` |
| `NetworkError` | timeout/DNS | 1 retry tras 2s | MCP -32006 si persiste |
| `ApiError` | 5xx tras 3 retries | Backoff exp | MCP -32005 con hint "API down" |

**Principio:** zero `try: ... except Exception:` genérico en el código. Cada excepción tipada → un código MCP específico. Esto permite que Claude entienda qué pasó y reformule (e.g., en NotFoundError, sabe que el user_id no existe; en ValidationError, sabe qué campo arreglar).

## 8. Testing

### Estructura

```
tests/
├── conftest.py                 # Fixtures globales (mock client, sample creds)
├── unit/
│   ├── test_client.py          # Cache, retry, token refresh
│   ├── test_config.py          # Env var loading, config.toml fallback
│   ├── test_errors.py          # Exception → MCP code mapping
│   ├── test_models.py          # Pydantic validation
│   └── tools/
│       ├── test_users.py
│       ├── test_scores.py
│       ├── test_beatmaps.py
│       └── test_rankings.py
├── integration/
│   ├── test_auth.py            # Real OAuth2 handshake
│   ├── test_endpoints.py       # 2-3 endpoints contra API real
│   └── test_rate_limit.py      # Comportamiento real ante rate limiting
├── smoke/
│   └── test_server_startup.py  # Subprocess + tools/list end-to-end
└── fixtures/
    ├── user_summary.json
    ├── user_scores_best.json
    ├── beatmap_details.json
    ├── beatmapset.json
    └── rankings.json
```

### Niveles

**Unit** — sin red, sin creds:
- Mock `ossapi.Ossapi` con `pytest-mock`.
- Cobertura por módulo:
  - `client.py`: cache hit/miss/TTL/bypass, retry en 429/5xx con backoff verificado, network error con 1 retry, token refresh transparente.
  - `tools/*.py`: input validation (pydantic happy/sad), transformación de fixture JSON → output schema, edge cases (empty lists, optional fields).
  - `models.py`: cada Input model con datos válidos/inválidos.
  - `errors.py`: cada excepción → código MCP correcto.
- Objetivo: **≥85% cobertura** medida con `coverage.py` (excluye `__init__.py` y `server.py`).

**Integration** — opt-in:
- Activación: `pytest tests/integration --integration` (custom pytest flag) o env `OSU_RUN_INTEGRATION=1`.
- Requiere creds en env vars.
- Tests rate-limited: `sleep(1)` entre tests + `pytest-rerunfailures` con 1 reintento si 429.
- Cubren: auth handshake (token request real), 2-3 endpoints representativos (get_user_summary, search_beatmaps, get_rankings), comportamiento real ante 429 forzado (skipped si no se puede triggerar).
- **No corren en CI** por defecto (necesitan creds). README documenta cómo correrlos local.

**Smoke** — sin creds:
- `test_server_startup.py`: arranca `osu-mcp` como subprocess con env vars dummy (cliente fake), manda `tools/list` JSON-RPC por stdin, parsea respuesta de stdout, verifica:
  - 12 tools devueltos
  - Cada tool tiene `name`, `description`, `inputSchema`
  - inputSchemas son JSONSchema válidos
- Corre en CI.

## 9. CI/CD

### `.github/workflows/test.yml`

Trigger: push a `main`, PRs a `main`.

Matrix: Python {3.11, 3.12} × OS {ubuntu-latest, macos-latest, windows-latest}.

Steps:
1. Checkout
2. Setup Python
3. Install `uv`
4. `uv sync --all-extras --dev`
5. `uv run ruff check .`
6. `uv run mypy --strict src/`
7. `uv run pytest tests/unit tests/smoke --cov=osu_mcp --cov-report=xml`
8. Upload coverage a Codecov

### `.github/workflows/publish.yml`

Trigger: push de tag `v*.*.*` (e.g., `v0.1.0`).

Steps:
1. Checkout
2. Setup Python 3.12
3. `uv build`
4. `uv publish` con OIDC trusted publisher (configurado en PyPI; sin tokens en repo)
5. Crear GitHub Release con cuerpo extraído de `CHANGELOG.md` para esa versión

### Auxiliares en CI

- **Codecov badge** en README.
- **Ruff/mypy** como required checks en branch protection de `main`.
- **Renovate** (o Dependabot) para PRs de actualización de deps.

## 10. Roadmap inmediato (post-v0.1)

Fuera de alcance v0.1 pero anticipado para que el diseño no se quede corto:

- **v0.2 — Cache persistente** con `diskcache` (sin tocar la API pública del client).
- **v0.2 — Más endpoints**: multiplayer rooms (para detectar lobbies activos), forum posts, wiki search.
- **v0.3 — Authorization Code flow**: opcional para usuarios que quieren acceder a data privada (DMs, friends list, favorite beatmaps). Setup más complejo (callback server local).
- **v0.3 — Tools high-level (estilo enfoque C)** construidos sobre los 12 actuales: `analyze_user_progress`, `find_skill_matched_beatmaps`. Solo si se valida que Claude sufre con los medium-grained actuales.
- **v0.4 — Resources MCP**: exponer beatmap covers como resources (no solo URLs en outputs).

## 11. Open questions (para writing-plans)

- ¿Logging: `structlog` o `logging` estándar? → Decidir al implementar config.
- ¿Pre-commit hooks (ruff/mypy local)? → Recomendado, no bloqueante.
- ¿GIF demo del README: grabado con qué tool? → Decidir cuando lleguemos a docs (probablemente `vhs` o `ScreenToGif`).
- ¿Nombre PyPI: `osu-mcp` o `osu-api-mcp`? → Verificar disponibilidad en PyPI antes de publicar v0.1.0.

---

**Aprobado por:** Imanol (2026-05-22, sesión de brainstorming con Claude)
**Siguiente paso:** `writing-plans` skill → implementation plan.
