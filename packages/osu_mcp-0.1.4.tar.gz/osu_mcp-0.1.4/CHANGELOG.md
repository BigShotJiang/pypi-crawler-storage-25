# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.4] — 2026-05-23

### Fixed
- MCP Registry namespace must match the GitHub username casing exactly.
  Updated `server.json` name and the README's `mcp-name` verification
  comment from `io.github.osyanne/osu-mcp` to `io.github.Osyanne/osu-mcp`.
  Trimmed `server.json` `description` to fit the registry's 100-char limit.

## [0.1.3] — 2026-05-23

### Added
- `server.json` at repo root for publication to the official MCP Server
  Registry (https://registry.modelcontextprotocol.io/).
- `mcp-name: io.github.osyanne/osu-mcp` verification line in the README
  (rendered as an HTML comment) so the registry's ownership verification
  check passes against the live PyPI README.
- `smithery.yaml` at repo root for Smithery deployment configuration.

### Changed
- README: removed the v0.1 "demo GIF placeholder" line.

## [0.1.2] — 2026-05-23

### Fixed

Twelve compatibility bugs with `ossapi` 5.x — the shipped v0.1.1 release
was effectively unusable for any user with non-trivial play history.

- **Mods returned as `NonLegacyMod` objects, not strings.** JSON
  serialization failed across `_score_to_summary`, `_score_brief`, and
  `get_beatmap_scores`. Added `mod_to_acronym` helper + field validator
  on `ScoreSummary.mods` (defense in depth).
- **`RankingType` literal `"pp"` is not a valid ossapi value.** The
  canonical enum is `charts/country/performance/score`. Renamed the
  literal and tool description to `"performance"`.
- **`search_beatmaps` passed `GameMode` string where ossapi expects
  `BeatmapsetSearchMode | int`.** Added a translation map
  (`fruits→CATCH`).
- **`search_beatmaps` forwarded a `limit` kwarg ossapi rejects**
  (cursor pagination). Drop the kwarg and slice client-side.
- **`OsuClient.get_score` forwarded `mode` to `Ossapi.score(score_id)`**
  which takes no mode arg. Drop forwarding (the new `/scores/{id}`
  endpoint is mode-agnostic).
- **`rank` serialized as `"Grade.S"` instead of `"S"`** via the default
  enum `__str__`. Added `grade_to_str` helper using `.name` + a
  `ScoreSummary.rank` validator.
- **`_score_brief` and `get_beatmap_scores` didn't coerce `Grade`,**
  raising `TypeError` at JSON encode. Use `grade_to_str` at the
  raw-dict call sites.
- **`score` field always `0`.** ossapi renamed the field to
  `total_score` (lazer). Fallback through
  `total_score → classic_total_score → score`.
- **`created_at` always `""`.** ossapi renamed to `ended_at`. Fallback
  through both fields + a `_stringify_datetime` helper that converts
  `datetime` objects to ISO-8601 strings.
- **`status` serialized as `"RankStatus.APPROVED"`** for beatmap[set]s.
  Added `status_to_str` helper (`.name.lower()`) + validators on
  `BeatmapSummary` and `BeatmapsetSummary`.
- **`get_rankings` forwarded a `page` kwarg ossapi rejects**
  (cursor pagination). Dropped the input field and kwarg; cursor-based
  pagination is out of scope for v0.1.
- **`OsuClient` retry loop didn't catch
  `ValueError("api returned an error of \`None\`")`** that ossapi
  raises for restricted/deleted accounts. Mapped to `NotFoundError`
  so callers handle the case cleanly.

### Tests
- 99 unit + 1 smoke tests (was 72 + 1) — 11 new regression tests
  covering each `NonLegacyMod` / `Grade` / `RankStatus` / field-rename
  path.
- 5/5 integration tests pass against the real osu! API.
- mypy strict and ruff clean.
- Verified end-to-end against the live API with user KingLeyend
  (id `20683878`): all 12 registered tools return JSON-serializable
  output.

## [0.1.1] — 2026-05-23

### Fixed
- **Critical:** every tool's `inputSchema` collapsed to `{properties: {kwargs: {}}}`,
  making the server unusable from MCP clients (any call returned a Pydantic
  validation error for missing top-level fields). The `_bind_tool` wrapper
  declared `**kwargs` as its signature, which FastMCP's `inspect.signature`-based
  introspection collapsed into a single generic field, while the inner pydantic
  models still expected the real top-level fields with `extra='forbid'`. Fixed
  by mirroring each `input_model.model_fields` entry onto the wrapper's
  `__signature__` as a keyword-only parameter so FastMCP publishes the real
  schema and routes calls correctly. The smoke test now spot-checks
  representative tools (`get_user_scores`, `compare_users`,
  `get_seasonal_backgrounds`) to make sure this regression cannot ship again.

## [0.1.0] — 2026-05-22

### Added
- 12 tools across 5 domain modules (users, scores, beatmaps, rankings, meta).
- OAuth2 Client Credentials auth via `OSU_CLIENT_ID` / `OSU_CLIENT_SECRET` env vars
  or TOML config file.
- TTL LRU cache (in-memory) per method with configurable TTLs and `bypass_cache` kwarg.
- Exponential backoff retry (1s/2s/4s) for 429 rate-limit and 5xx server errors;
  one retry for network errors.
- FastMCP-based stdio server with pydantic input validation.
- Typed exception hierarchy mapped to MCP JSON-RPC error codes (-32000..-32006).
- `OSU_MCP_SKIP_CLIENT_INIT=1` test-mode env var to launch the server without
  real osu! credentials (for protocol-level smoke tests).
- CI matrix on Python 3.11/3.12 × ubuntu/macos/windows.
- PyPI publish via trusted publisher on tag push.
