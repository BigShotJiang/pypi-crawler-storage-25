"""MCP server entry point: registers tools and runs stdio loop."""
from __future__ import annotations

import logging
import os
import sys
from inspect import Parameter, Signature
from typing import Any

from mcp.server.fastmcp import FastMCP
from pydantic import BaseModel
from pydantic import ValidationError as PydanticValidationError

from osu_mcp.client import OsuClient
from osu_mcp.config import load_config
from osu_mcp.errors import OsuMcpError, ValidationError
from osu_mcp.tools import REGISTRY, ToolSpec
from osu_mcp.tools import beatmaps as _beatmaps  # noqa: F401
from osu_mcp.tools import meta as _meta  # noqa: F401
from osu_mcp.tools import rankings as _rankings  # noqa: F401
from osu_mcp.tools import scores as _scores  # noqa: F401
from osu_mcp.tools import users as _users  # noqa: F401

log = logging.getLogger(__name__)


def _make_mcp(client: OsuClient) -> FastMCP:
    mcp = FastMCP("osu-mcp")
    for spec_name, spec in REGISTRY.items():
        _bind_tool(mcp, spec_name, spec, client)
    return mcp


def _signature_from_model(model: type[BaseModel]) -> Signature:
    # FastMCP introspects __signature__ to build the tool's JSON schema. A bare
    # **kwargs wrapper collapses the schema to {kwargs: Any} and hides every real
    # field; mirror the pydantic fields as keyword-only params instead.
    params: list[Parameter] = []
    for fname, finfo in model.model_fields.items():
        if finfo.is_required():
            default: Any = Parameter.empty
        elif finfo.default_factory is not None:
            default = finfo.default_factory()  # type: ignore[call-arg]
        else:
            default = finfo.default
        params.append(
            Parameter(
                fname,
                Parameter.KEYWORD_ONLY,
                default=default,
                annotation=finfo.annotation,
            )
        )
    return Signature(params, return_annotation=dict[str, Any])


def _bind_tool(mcp: Any, name: str, spec: ToolSpec, client: Any) -> None:
    """Register one tool with FastMCP, using the pydantic input model as the schema."""
    input_model = spec.input_model
    handler = spec.handler

    def _wrapper(**kwargs: Any) -> dict[str, Any]:
        try:
            args = input_model(**kwargs)
        except PydanticValidationError as e:
            first_err = e.errors()[0]
            raise ValidationError(
                str(e),
                field=".".join(str(p) for p in first_err["loc"]),
                reason=first_err["msg"],
            ) from e
        return handler(args, client)

    sig = _signature_from_model(input_model)
    _wrapper.__signature__ = sig  # type: ignore[attr-defined]
    _wrapper.__annotations__ = {
        p.name: p.annotation for p in sig.parameters.values()
    } | {"return": dict[str, Any]}
    _wrapper.__name__ = name
    _wrapper.__doc__ = spec.description
    mcp.tool(name=name, description=spec.description)(_wrapper)


def main() -> None:
    """Entry point: load config, init client, run MCP stdio server."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        stream=sys.stderr,
    )
    if os.environ.get("OSU_MCP_SKIP_CLIENT_INIT") == "1":
        log.warning("OSU_MCP_SKIP_CLIENT_INIT=1: using stub client (smoke-test mode)")
        client: Any = _StubClient()
    else:
        try:
            cfg = load_config()
            client = OsuClient(cfg)
        except OsuMcpError as e:
            log.error("startup failed: %s", e)
            sys.stderr.write(f"\nstartup failed:\n{e}\n")
            sys.exit(1)

    mcp = _make_mcp(client)
    log.info("osu-mcp v0.1.1 ready; %d tools registered", len(REGISTRY))
    mcp.run()


class _StubClient:
    """Stub used only when OSU_MCP_SKIP_CLIENT_INIT=1 — lets the server start
    without real osu! credentials for protocol-level smoke tests."""

    def __getattr__(self, name: str) -> Any:
        def _raise(*_args: Any, **_kwargs: Any) -> Any:
            raise RuntimeError(
                f"stub client: real client not initialized; cannot call {name!r}"
            )
        return _raise


if __name__ == "__main__":
    main()
