"""osu-mcp: MCP server exposing osu! API v2 as tools."""

__version__ = "0.1.0"
