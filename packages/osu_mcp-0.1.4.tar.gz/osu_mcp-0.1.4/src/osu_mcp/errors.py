"""Typed exception hierarchy with MCP error code mapping."""
from __future__ import annotations

from typing import Any


class OsuMcpError(Exception):
    """Base for all osu-mcp errors."""


class ConfigError(OsuMcpError):
    """Missing or invalid configuration (e.g., creds not found)."""


class AuthError(OsuMcpError):
    """OAuth2 auth failed (invalid creds, revoked token, etc.)."""


class RateLimitError(OsuMcpError):
    """osu! API returned 429 after retries were exhausted."""

    def __init__(self, message: str, *, retry_after_seconds: int) -> None:
        super().__init__(message)
        self.retry_after_seconds = retry_after_seconds


class NotFoundError(OsuMcpError):
    """Requested resource not found (404 from osu! API)."""

    def __init__(self, message: str, *, resource: str, params: dict[str, Any]) -> None:
        super().__init__(message)
        self.resource = resource
        self.params = params


class ValidationError(OsuMcpError):
    """Input failed pydantic validation."""

    def __init__(self, message: str, *, field: str, reason: str) -> None:
        super().__init__(message)
        self.field = field
        self.reason = reason


class ApiError(OsuMcpError):
    """osu! API 5xx after retries were exhausted."""


class NetworkError(OsuMcpError):
    """Network failure (timeout, DNS, connection refused) after retry."""


_CODE_MAP: dict[type[Exception], int] = {
    ConfigError: -32000,
    AuthError: -32001,
    RateLimitError: -32002,
    NotFoundError: -32003,
    ValidationError: -32004,
    ApiError: -32005,
    NetworkError: -32006,
}


def to_mcp_error(exc: Exception) -> dict[str, Any]:
    """Map a Python exception to an MCP JSON-RPC error dict."""
    code = _CODE_MAP.get(type(exc), -32099)
    payload: dict[str, Any] = {
        "code": code,
        "message": str(exc),
    }
    data: dict[str, Any] = {}
    if isinstance(exc, RateLimitError):
        data["retry_after_seconds"] = exc.retry_after_seconds
    elif isinstance(exc, NotFoundError):
        data["resource"] = exc.resource
        data["params"] = exc.params
    elif isinstance(exc, ValidationError):
        data["field"] = exc.field
        data["reason"] = exc.reason
    if data:
        payload["data"] = data
    return payload
