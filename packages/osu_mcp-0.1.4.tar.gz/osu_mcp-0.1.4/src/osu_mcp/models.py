"""Pydantic schemas: tool inputs (validated) and outputs (token-tight)."""
from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator


def mod_to_acronym(m: Any) -> str:
    """Coerce a mod value to its short acronym (e.g. ``"DT"``).

    ossapi 5.x returns mods as ``NonLegacyMod`` objects exposing ``.acronym``;
    earlier versions yielded plain strings. We accept either and never raise —
    unknown shapes fall back to ``str(m)``.
    """
    if isinstance(m, str):
        return m
    acronym = getattr(m, "acronym", None)
    if acronym is not None:
        return str(acronym)
    return str(m)


def status_to_str(s: Any) -> str:
    """Coerce a RankStatus enum (or any value) to the lowercase API string.

    ossapi 5.x exposes ``RankStatus`` whose ``str(...)`` produces
    ``"RankStatus.APPROVED"``. The osu! API canonical form is the lowercase
    name (``"approved"``, ``"ranked"``, ``"graveyard"`` …).
    """
    if isinstance(s, str):
        return s
    name = getattr(s, "name", None)
    if name is not None:
        return str(name).lower()
    return str(s)


def grade_to_str(g: Any) -> str:
    """Coerce a rank/grade value to the user-recognized short name (``S``/``SS``/``SH``…).

    ossapi 5.x returns ``rank`` as a ``Grade`` enum where ``.value`` uses legacy
    single-letter API codes (``"X"`` for SS, ``"XH"`` for SSH). The ``.name``
    field exposes the player-vocabulary form (``"SS"``, ``"SSH"``). Prefer
    ``.name`` for clarity in LLM consumers.
    """
    if isinstance(g, str):
        return g
    name = getattr(g, "name", None)
    if name is not None:
        return str(name)
    return str(g)


def _stringify_datetime(v: Any) -> str:
    """Coerce a datetime-like value to an ISO-8601 string."""
    if v is None:
        return ""
    if isinstance(v, str):
        return v
    iso = getattr(v, "isoformat", None)
    if callable(iso):
        return str(iso())
    return str(v)

Mode = Literal["osu", "taiko", "fruits", "mania"]
ScoreType = Literal["best", "recent", "firsts"]
RankingType = Literal["performance", "score", "charts"]
UserMetric = Literal[
    "pp", "accuracy", "play_count", "ranked_score",
    "total_score", "level", "global_rank", "country_rank",
]
BeatmapStatus = Literal[
    "ranked", "approved", "qualified", "loved", "pending", "graveyard",
]
IncludeKind = Literal["recent", "best", "firsts"]


# ---------- Inputs ----------

class _StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class GetUserSummaryInput(_StrictModel):
    user_id_or_name: str = Field(min_length=1)
    mode: Mode = "osu"
    include: list[IncludeKind] = Field(default_factory=list)


class CompareUsersInput(_StrictModel):
    users: list[str] = Field(min_length=2, max_length=5)
    mode: Mode
    metrics: list[UserMetric] = Field(min_length=1)


class GetUserScoresInput(_StrictModel):
    user_id: int = Field(gt=0)
    type: ScoreType
    mode: Mode
    limit: int = Field(default=10, ge=1, le=100)


class GetScoreDetailsInput(_StrictModel):
    score_id: int = Field(gt=0)
    mode: Mode


class SearchBeatmapsInput(_StrictModel):
    query: str = Field(min_length=1)
    mode: Mode | None = None
    status: BeatmapStatus | None = None
    difficulty_range: tuple[float, float] | None = None
    length_range: tuple[int, int] | None = None
    bpm_range: tuple[int, int] | None = None
    limit: int = Field(default=20, ge=1, le=50)

    @field_validator("difficulty_range", "length_range", "bpm_range")
    @classmethod
    def _validate_range(
        cls, v: tuple[float, float] | tuple[int, int] | None
    ) -> tuple[float, float] | tuple[int, int] | None:
        if v is not None and v[0] > v[1]:
            raise ValueError("min must be <= max")
        return v


class GetBeatmapDetailsInput(_StrictModel):
    beatmap_id: int = Field(gt=0)


class GetBeatmapScoresInput(_StrictModel):
    beatmap_id: int = Field(gt=0)
    mode: Mode | None = None
    mods: list[str] | None = None
    limit: int = Field(default=50, ge=1, le=100)


class GetBeatmapsetInput(_StrictModel):
    beatmapset_id: int = Field(gt=0)


class GetRankingsInput(_StrictModel):
    type: RankingType
    mode: Mode
    country: str | None = Field(default=None, min_length=2, max_length=2)
    # Note: ossapi rankings use cursor-based pagination; multi-page fetch is
    # out of scope for v0.1.x. Each call returns the first page (~50 entries).


class GetCountryTopInput(_StrictModel):
    country_code: str = Field(min_length=2, max_length=2)
    mode: Mode
    limit: int = Field(default=50, ge=1, le=100)


class GetNewsPostsInput(_StrictModel):
    limit: int = Field(default=10, ge=1, le=50)
    year: int | None = Field(default=None, ge=2007, le=2100)


class GetSeasonalBackgroundsInput(_StrictModel):
    pass  # no parameters


# ---------- Outputs ----------

class UserSummaryOutput(BaseModel):
    id: int
    username: str
    country_code: str
    pp: float
    accuracy: float
    play_count: int
    ranked_score: int
    level: int
    global_rank: int | None
    country_rank: int | None
    avatar_url: str
    joined_at: str


class ScoreSummary(BaseModel):
    id: int
    beatmap_id: int
    beatmapset_title: str
    score: int
    pp: float | None
    accuracy: float
    max_combo: int
    rank: str
    mods: list[str]
    created_at: str

    @field_validator("mods", mode="before")
    @classmethod
    def _coerce_mods(cls, v: Any) -> list[str]:
        if v is None:
            return []
        return [mod_to_acronym(m) for m in v]

    @field_validator("rank", mode="before")
    @classmethod
    def _coerce_rank(cls, v: Any) -> str:
        return grade_to_str(v)

    @field_validator("created_at", mode="before")
    @classmethod
    def _coerce_created_at(cls, v: Any) -> str:
        return _stringify_datetime(v)


class BeatmapSummary(BaseModel):
    id: int
    beatmapset_id: int
    version: str
    difficulty_rating: float
    ar: float
    od: float
    cs: float
    hp: float
    bpm: float
    total_length: int
    max_combo: int | None
    status: str

    @field_validator("status", mode="before")
    @classmethod
    def _coerce_status(cls, v: Any) -> str:
        return status_to_str(v)


class BeatmapsetSummary(BaseModel):
    id: int
    title: str
    artist: str
    creator: str
    status: str
    bpm: float
    play_count: int
    difficulty_count: int

    @field_validator("status", mode="before")
    @classmethod
    def _coerce_status(cls, v: Any) -> str:
        return status_to_str(v)


class RankingEntry(BaseModel):
    rank: int
    user_id: int
    username: str
    country_code: str
    pp: float
    accuracy: float
    play_count: int
