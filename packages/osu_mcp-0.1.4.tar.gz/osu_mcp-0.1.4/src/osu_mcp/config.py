"""Configuration loading: env vars → ~/.config/osu-mcp/config.toml → ConfigError."""
from __future__ import annotations

import os
import tomllib
from dataclasses import dataclass
from pathlib import Path

from osu_mcp.errors import ConfigError

_SETUP_INSTRUCTIONS = """\
osu-mcp could not find your osu! API credentials.

Create an OAuth2 client at https://osu.ppy.sh/home/account/edit (under "OAuth"),
then provide them in ONE of these ways:

1. Environment variables (recommended):
    OSU_CLIENT_ID=<your-numeric-client-id>
    OSU_CLIENT_SECRET=<your-client-secret>

2. Config file at one of:
    Linux/Mac: ~/.config/osu-mcp/config.toml
    Windows:   %APPDATA%/osu-mcp/config.toml

   With contents:
    client_id = 12345
    client_secret = "your-secret"
"""


@dataclass(frozen=True)
class OsuConfig:
    """Credentials for osu! API v2 OAuth2 Client Credentials flow."""
    client_id: int
    client_secret: str


def _default_config_dir() -> Path:
    """Return the OS-appropriate config directory."""
    if os.name == "nt":  # Windows
        base = os.environ.get("APPDATA", str(Path.home() / "AppData" / "Roaming"))
        return Path(base)
    return Path.home() / ".config"


def _try_env() -> OsuConfig | None:
    cid = os.environ.get("OSU_CLIENT_ID")
    csec = os.environ.get("OSU_CLIENT_SECRET")
    if cid is None or csec is None:
        return None
    try:
        cid_int = int(cid)
    except ValueError as e:
        raise ConfigError(
            f"OSU_CLIENT_ID must be an integer, got: {cid!r}"
        ) from e
    return OsuConfig(client_id=cid_int, client_secret=csec)


def _try_toml(config_dir: Path) -> OsuConfig | None:
    toml_path = config_dir / "osu-mcp" / "config.toml"
    if not toml_path.exists():
        return None
    with toml_path.open("rb") as f:
        data = tomllib.load(f)
    if "client_id" not in data or "client_secret" not in data:
        raise ConfigError(
            f"{toml_path} is missing required keys 'client_id' and 'client_secret'"
        )
    return OsuConfig(
        client_id=int(data["client_id"]),
        client_secret=str(data["client_secret"]),
    )


def load_config(config_dir: Path | None = None) -> OsuConfig:
    """Load creds. Env vars take precedence over TOML file."""
    if (cfg := _try_env()) is not None:
        return cfg
    if (cfg := _try_toml(config_dir or _default_config_dir())) is not None:
        return cfg
    raise ConfigError(_SETUP_INSTRUCTIONS)
