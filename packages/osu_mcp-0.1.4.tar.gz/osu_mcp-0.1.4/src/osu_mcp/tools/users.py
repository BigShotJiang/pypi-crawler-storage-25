"""User-related tools: get_user_summary, compare_users."""
from __future__ import annotations

from typing import Any

from osu_mcp.models import (
    CompareUsersInput,
    GetUserSummaryInput,
    UserSummaryOutput,
    grade_to_str,
    mod_to_acronym,
)
from osu_mcp.tools import register_tool


def _to_summary(user: Any) -> dict[str, Any]:
    stats = user.statistics
    level = stats.level.current if hasattr(stats.level, "current") else stats.level
    out = UserSummaryOutput(
        id=user.id,
        username=user.username,
        country_code=user.country_code,
        pp=float(stats.pp),
        accuracy=float(stats.hit_accuracy),
        play_count=int(stats.play_count),
        ranked_score=int(stats.ranked_score),
        level=int(level),
        global_rank=stats.global_rank,
        country_rank=stats.country_rank,
        avatar_url=user.avatar_url,
        joined_at=str(user.join_date),
    )
    return out.model_dump()


def _score_brief(s: Any) -> dict[str, Any]:
    raw_rank = getattr(s, "rank", None)
    return {
        "id": s.id,
        "beatmap_id": s.beatmap.id if hasattr(s, "beatmap") else None,
        "pp": getattr(s, "pp", None),
        "accuracy": getattr(s, "accuracy", None),
        "rank": grade_to_str(raw_rank) if raw_rank is not None else None,
        "mods": [mod_to_acronym(m) for m in (getattr(s, "mods", None) or [])],
    }


@register_tool(
    name="get_user_summary",
    description=(
        "Get an osu! user's profile + stats. user_id_or_name can be numeric ID or "
        "username. Optionally embed recent/best/firsts scores via the include list."
    ),
    input_model=GetUserSummaryInput,
)
def get_user_summary(args: GetUserSummaryInput, client: Any) -> dict[str, Any]:
    user = client.get_user(args.user_id_or_name, mode=args.mode)
    result = _to_summary(user)
    result["_cached"] = False
    if args.include:
        if "recent" in args.include:
            result["recent"] = [
                _score_brief(s) for s in client.get_user_scores(
                    user.id, type="recent", mode=args.mode, limit=5
                )
            ]
        if "best" in args.include:
            result["best"] = [
                _score_brief(s) for s in client.get_user_scores(
                    user.id, type="best", mode=args.mode, limit=5
                )
            ]
        if "firsts" in args.include:
            result["firsts"] = [
                _score_brief(s) for s in client.get_user_scores(
                    user.id, type="firsts", mode=args.mode, limit=5
                )
            ]
    return result


@register_tool(
    name="compare_users",
    description=(
        "Side-by-side comparison of 2-5 osu! users on the chosen metrics. "
        "Useful for 'how do I stack up against X' or 'top N hispanics' analyses."
    ),
    input_model=CompareUsersInput,
)
def compare_users(args: CompareUsersInput, client: Any) -> dict[str, Any]:
    rows = []
    for user_ref in args.users:
        user = client.get_user(user_ref, mode=args.mode)
        full = _to_summary(user)
        rows.append({
            "username": full["username"],
            "id": full["id"],
            "country_code": full["country_code"],
            "metrics": {m: full.get(m) for m in args.metrics},
        })
    return {"count": len(rows), "users": rows}
