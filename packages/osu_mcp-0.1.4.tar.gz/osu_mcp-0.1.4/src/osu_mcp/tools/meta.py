"""Meta tools: news posts and seasonal backgrounds."""
from __future__ import annotations

from typing import Any

from osu_mcp.models import GetNewsPostsInput, GetSeasonalBackgroundsInput
from osu_mcp.tools import register_tool


@register_tool(
    name="get_news_posts",
    description=(
        "Get recent osu! news posts. Useful for tracking meta announcements, "
        "ranked updates, tournament summaries. Optionally filter by year."
    ),
    input_model=GetNewsPostsInput,
)
def get_news_posts(args: GetNewsPostsInput, client: Any) -> dict[str, Any]:
    kwargs: dict[str, Any] = {"limit": args.limit}
    if args.year is not None:
        kwargs["year"] = args.year
    res = client.get_news_posts(**kwargs)
    posts = list(getattr(res, "news_posts", []) or [])
    out = [
        {
            "id": getattr(p, "id", None),
            "title": str(getattr(p, "title", "")),
            "slug": str(getattr(p, "slug", "")),
            "published_at": str(getattr(p, "published_at", "")),
            "author": str(getattr(p, "author", "")),
        }
        for p in posts
    ]
    return {"count": len(out), "posts": out}


@register_tool(
    name="get_seasonal_backgrounds",
    description="Get currently active seasonal backgrounds (rotates ~quarterly).",
    input_model=GetSeasonalBackgroundsInput,
)
def get_seasonal_backgrounds(
    args: GetSeasonalBackgroundsInput, client: Any
) -> dict[str, Any]:
    res = client.get_seasonal_backgrounds()
    bgs = list(getattr(res, "backgrounds", []) or [])
    out = [
        {
            "url": str(getattr(b, "url", "")),
            "artist": str(getattr(getattr(b, "user", None), "username", "")),
        }
        for b in bgs
    ]
    return {
        "count": len(out),
        "ends_at": str(getattr(res, "ends_at", "")),
        "backgrounds": out,
    }
