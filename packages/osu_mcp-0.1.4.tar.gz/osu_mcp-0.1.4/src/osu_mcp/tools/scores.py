"""Score-related tools: get_user_scores, get_score_details."""
from __future__ import annotations

from typing import Any

from osu_mcp.models import (
    GetScoreDetailsInput,
    GetUserScoresInput,
    ScoreSummary,
)
from osu_mcp.tools import register_tool


def _score_to_summary(s: Any) -> dict[str, Any]:
    bset = getattr(s, "beatmapset", None)
    bmap = getattr(s, "beatmap", None)
    # ossapi 5.x (lazer) renamed `score`→`total_score`, `created_at`→`ended_at`.
    # Fall back through both for compat across versions.
    total = (
        getattr(s, "total_score", None)
        or getattr(s, "classic_total_score", None)
        or getattr(s, "score", None)
        or 0
    )
    when = (
        getattr(s, "ended_at", None)
        or getattr(s, "created_at", None)
    )
    out = ScoreSummary(
        id=s.id,
        beatmap_id=bmap.id if bmap else 0,
        beatmapset_title=bset.title if bset else "",
        score=int(total),
        pp=getattr(s, "pp", None),
        accuracy=float(getattr(s, "accuracy", 0.0)),
        max_combo=int(getattr(s, "max_combo", 0)),
        # Validators coerce these: rank (Grade enum), mods (NonLegacyMod),
        # created_at (datetime). Annotated types stay strict for consumers.
        rank=getattr(s, "rank", ""),
        mods=getattr(s, "mods", None),  # type: ignore[arg-type]
        created_at=when,  # type: ignore[arg-type]
    )
    return out.model_dump()


@register_tool(
    name="get_user_scores",
    description=(
        "List a user's scores by type: 'best' (top by pp), 'recent' (last 24h), "
        "or 'firsts' (#1 placements). Returns up to `limit` scores (1-100)."
    ),
    input_model=GetUserScoresInput,
)
def get_user_scores(args: GetUserScoresInput, client: Any) -> dict[str, Any]:
    scores = client.get_user_scores(
        args.user_id, type=args.type, mode=args.mode, limit=args.limit
    )
    summaries = [_score_to_summary(s) for s in scores]
    return {"count": len(summaries), "scores": summaries}


@register_tool(
    name="get_score_details",
    description="Fetch a specific score by ID and mode, with full attributes.",
    input_model=GetScoreDetailsInput,
)
def get_score_details(args: GetScoreDetailsInput, client: Any) -> dict[str, Any]:
    s = client.get_score(args.score_id, mode=args.mode)
    return _score_to_summary(s)
