"""Beatmap-related tools."""
from __future__ import annotations

from typing import Any

from ossapi.enums import BeatmapsetSearchMode

from osu_mcp.models import (
    BeatmapsetSummary,
    BeatmapSummary,
    GetBeatmapDetailsInput,
    GetBeatmapScoresInput,
    GetBeatmapsetInput,
    SearchBeatmapsInput,
    grade_to_str,
    mod_to_acronym,
)
from osu_mcp.tools import register_tool

# GameMode string → BeatmapsetSearchMode (search uses a different enum).
_SEARCH_MODE_MAP: dict[str, BeatmapsetSearchMode] = {
    "osu": BeatmapsetSearchMode.OSU,
    "taiko": BeatmapsetSearchMode.TAIKO,
    "fruits": BeatmapsetSearchMode.CATCH,  # API name diverges
    "mania": BeatmapsetSearchMode.MANIA,
}


def _bmap_to_summary(b: Any) -> dict[str, Any]:
    return BeatmapSummary(
        id=b.id,
        beatmapset_id=getattr(b, "beatmapset_id", 0),
        version=str(getattr(b, "version", "")),
        difficulty_rating=float(getattr(b, "difficulty_rating", 0)),
        ar=float(getattr(b, "ar", 0)),
        od=float(getattr(b, "accuracy", 0)),
        cs=float(getattr(b, "cs", 0)),
        hp=float(getattr(b, "drain", 0)),
        bpm=float(getattr(b, "bpm", 0)),
        total_length=int(getattr(b, "total_length", 0)),
        max_combo=getattr(b, "max_combo", None),
        status=getattr(b, "status", ""),  # validator coerces RankStatus enum
    ).model_dump()


def _bset_to_summary(bs: Any) -> dict[str, Any]:
    beatmaps_list = getattr(bs, "beatmaps", None) or []
    return BeatmapsetSummary(
        id=bs.id,
        title=str(getattr(bs, "title", "")),
        artist=str(getattr(bs, "artist", "")),
        creator=str(getattr(bs, "creator", "")),
        status=getattr(bs, "status", ""),  # validator coerces RankStatus enum
        bpm=float(getattr(bs, "bpm", 0)),
        play_count=int(getattr(bs, "play_count", 0)),
        difficulty_count=len(beatmaps_list),
    ).model_dump()


@register_tool(
    name="search_beatmaps",
    description=(
        "Search beatmapsets by query string with optional filters: mode, status, "
        "difficulty/length/bpm ranges. Returns up to `limit` (default 20, max 50)."
    ),
    input_model=SearchBeatmapsInput,
)
def search_beatmaps(args: SearchBeatmapsInput, client: Any) -> dict[str, Any]:
    # ossapi.search_beatmapsets has no `limit` kwarg (cursor pagination) and
    # expects BeatmapsetSearchMode, not the GameMode string.
    kwargs: dict[str, Any] = {"query": args.query}
    if args.mode is not None:
        kwargs["mode"] = _SEARCH_MODE_MAP[args.mode]
    if args.status is not None:
        kwargs["status"] = args.status
    result = client.search_beatmapsets(**kwargs)
    summaries = [_bset_to_summary(bs) for bs in result.beatmapsets[: args.limit]]
    return {"count": len(summaries), "beatmapsets": summaries}


@register_tool(
    name="get_beatmap_details",
    description="Get a beatmap by ID with difficulty attributes (AR/OD/CS/HP, BPM, length).",
    input_model=GetBeatmapDetailsInput,
)
def get_beatmap_details(args: GetBeatmapDetailsInput, client: Any) -> dict[str, Any]:
    b = client.get_beatmap(args.beatmap_id)
    return _bmap_to_summary(b)


@register_tool(
    name="get_beatmap_scores",
    description=(
        "Get top scores on a specific beatmap. Filter by mods (HD/HR/DT/etc) "
        "and mode (defaults to map's mode)."
    ),
    input_model=GetBeatmapScoresInput,
)
def get_beatmap_scores(args: GetBeatmapScoresInput, client: Any) -> dict[str, Any]:
    kwargs: dict[str, Any] = {"limit": args.limit}
    if args.mode is not None:
        kwargs["mode"] = args.mode
    if args.mods is not None:
        kwargs["mods"] = args.mods
    res = client.get_beatmap_scores(args.beatmap_id, **kwargs)
    scores_iter = getattr(res, "scores", []) or []
    out = []
    for s in scores_iter:
        raw_rank = getattr(s, "rank", None)
        out.append({
            "id": getattr(s, "id", None),
            "user_id": getattr(s, "user_id", None),
            "score": (
                getattr(s, "total_score", None)
                or getattr(s, "classic_total_score", None)
                or getattr(s, "score", None)
            ),
            "pp": getattr(s, "pp", None),
            "accuracy": getattr(s, "accuracy", None),
            "max_combo": getattr(s, "max_combo", None),
            "rank": grade_to_str(raw_rank) if raw_rank is not None else None,
            "mods": [mod_to_acronym(m) for m in (getattr(s, "mods", None) or [])],
        })
    return {"count": len(out), "scores": out}


@register_tool(
    name="get_beatmapset",
    description="Get a full beatmapset (all difficulties) by set ID.",
    input_model=GetBeatmapsetInput,
)
def get_beatmapset(args: GetBeatmapsetInput, client: Any) -> dict[str, Any]:
    bs = client.get_beatmapset(args.beatmapset_id)
    summary = _bset_to_summary(bs)
    summary["beatmaps"] = [
        {
            "id": b.id,
            "version": str(getattr(b, "version", "")),
            "difficulty_rating": float(getattr(b, "difficulty_rating", 0)),
        }
        for b in (getattr(bs, "beatmaps", None) or [])
    ]
    return summary
