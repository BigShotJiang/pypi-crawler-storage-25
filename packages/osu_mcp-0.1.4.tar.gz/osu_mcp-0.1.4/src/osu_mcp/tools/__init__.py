"""Tool registry: @register_tool decorator stores ToolSpec entries in REGISTRY."""
from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, Protocol

from pydantic import BaseModel


class ToolHandler(Protocol):
    """Tool handler signature: takes a validated input model and the client."""
    def __call__(self, args: BaseModel, client: Any) -> dict[str, Any]: ...


@dataclass(frozen=True)
class ToolSpec:
    name: str
    description: str
    input_model: type[BaseModel]
    handler: Callable[[BaseModel, Any], dict[str, Any]]


REGISTRY: dict[str, ToolSpec] = {}


def register_tool(
    *, name: str, description: str, input_model: type[BaseModel]
) -> Callable[[Callable[..., dict[str, Any]]], Callable[..., dict[str, Any]]]:
    """Decorator that adds a tool to REGISTRY."""

    def decorator(
        fn: Callable[..., dict[str, Any]],
    ) -> Callable[..., dict[str, Any]]:
        if name in REGISTRY:
            raise ValueError(f"tool {name!r} is already registered")
        REGISTRY[name] = ToolSpec(
            name=name,
            description=description,
            input_model=input_model,
            handler=fn,
        )
        return fn

    return decorator
