"""Ranking-related tools."""
from __future__ import annotations

from typing import Any

from osu_mcp.models import GetCountryTopInput, GetRankingsInput, RankingEntry
from osu_mcp.tools import register_tool


def _entry_to_dict(r: Any, rank: int) -> dict[str, Any]:
    user = r.user
    return RankingEntry(
        rank=rank,
        user_id=user.id,
        username=user.username,
        country_code=user.country_code,
        pp=float(getattr(r, "pp", 0)),
        accuracy=float(getattr(r, "hit_accuracy", 0)),
        play_count=int(getattr(r, "play_count", 0)),
    ).model_dump()


@register_tool(
    name="get_rankings",
    description=(
        "Get osu! rankings. type='performance' (global/country pp leaderboard), "
        "'score', or 'charts' (monthly tournaments). Filter by `country` "
        "(ISO 3166-1 alpha-2)."
    ),
    input_model=GetRankingsInput,
)
def get_rankings(args: GetRankingsInput, client: Any) -> dict[str, Any]:
    # ossapi.ranking uses cursor pagination, not page indices. v0.1.x exposes
    # only the first page.
    kwargs: dict[str, Any] = {}
    if args.country is not None:
        kwargs["country"] = args.country
    res = client.get_ranking(args.mode, args.type, **kwargs)
    rows = list(getattr(res, "ranking", []) or [])
    entries = [_entry_to_dict(r, i + 1) for i, r in enumerate(rows)]
    return {
        "count": len(entries),
        "type": args.type,
        "mode": args.mode,
        "entries": entries,
    }


@register_tool(
    name="get_country_top",
    description=(
        "Shortcut: top N players of a country in pp ranking for a given mode. "
        "country_code is ISO 3166-1 alpha-2 (e.g., 'EC' for Ecuador, 'JP' for Japan)."
    ),
    input_model=GetCountryTopInput,
)
def get_country_top(args: GetCountryTopInput, client: Any) -> dict[str, Any]:
    res = client.get_ranking(args.mode, "performance", country=args.country_code)
    rows = list(getattr(res, "ranking", []) or [])[: args.limit]
    entries = [_entry_to_dict(r, i + 1) for i, r in enumerate(rows)]
    return {
        "count": len(entries),
        "country_code": args.country_code,
        "mode": args.mode,
        "entries": entries,
    }
