"""Wrapper around ossapi.Ossapi with TTL LRU cache and retry/backoff."""
from __future__ import annotations

import logging
import re
import time
from collections.abc import Callable
from typing import Any, TypeVar

from cachetools import TTLCache
from ossapi import Ossapi

from osu_mcp.config import OsuConfig
from osu_mcp.errors import ApiError, AuthError, NetworkError, NotFoundError, RateLimitError

log = logging.getLogger(__name__)

T = TypeVar("T")

_RATE_LIMIT_PATTERN = re.compile(r"\b429\b")
_NOT_FOUND_PATTERN = re.compile(r"\b404\b")
_SERVER_ERROR_PATTERN = re.compile(r"\b5\d\d\b")
# ossapi raises a bare ValueError when the API returns ``{"error": null}`` —
# typically a restricted/deleted account. Map to NotFoundError.
_API_NULL_ERROR_PATTERN = re.compile(r"api returned an error", re.IGNORECASE)
_BACKOFF_SECONDS = (1, 2, 4)  # 3 retries
_NETWORK_BACKOFF = 2

# TTLs (seconds) per logical method. Default 300.
_TTLS: dict[str, int] = {
    "get_user": 300,
    "get_user_scores": 300,
    "get_score": 3600,
    "search_beatmapsets": 300,
    "get_beatmap": 3600,
    "get_beatmap_scores": 600,
    "get_beatmapset": 3600,
    "get_ranking": 900,
    "get_news_posts": 600,
    "get_seasonal_backgrounds": 86400,
}
_MAX_PER_METHOD = 256


def _make_key(args: tuple[Any, ...], kwargs: dict[str, Any]) -> tuple[Any, ...]:
    return (args, tuple(sorted(kwargs.items())))


class OsuClient:
    """Singleton wrapper. Init once at server startup; reused across tool calls."""

    def __init__(self, cfg: OsuConfig) -> None:
        self._cfg = cfg
        try:
            self._inner = Ossapi(cfg.client_id, cfg.client_secret)
        except Exception as e:
            raise AuthError(f"failed to init ossapi: {e}") from e
        self._caches: dict[str, TTLCache[tuple[Any, ...], Any]] = {
            name: TTLCache(maxsize=_MAX_PER_METHOD, ttl=ttl)
            for name, ttl in _TTLS.items()
        }
        log.info("ossapi client initialized with TTL caches")

    def _call_cached(
        self,
        method_name: str,
        fn: Callable[..., T],
        *args: Any,
        bypass_cache: bool = False,
        **kwargs: Any,
    ) -> T:
        cache = self._caches[method_name]
        key = _make_key(args, kwargs)
        if not bypass_cache and key in cache:
            log.debug("cache HIT %s %s", method_name, key)
            return cache[key]  # type: ignore[no-any-return]
        log.debug("cache MISS %s %s", method_name, key)
        result = self._call_with_retry(fn, args, kwargs)
        cache[key] = result
        return result

    def _call_with_retry(
        self,
        fn: Callable[..., T],
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> T:
        last_exc: Exception | None = None
        for attempt in range(len(_BACKOFF_SECONDS) + 1):
            try:
                return fn(*args, **kwargs)
            except ConnectionError as e:
                if attempt == 0:
                    log.warning("network error, retrying in %ss: %s", _NETWORK_BACKOFF, e)
                    time.sleep(_NETWORK_BACKOFF)
                    last_exc = e
                    continue
                raise NetworkError(f"network failure: {e}") from e
            except Exception as e:
                msg = str(e)
                if _NOT_FOUND_PATTERN.search(msg) or _API_NULL_ERROR_PATTERN.search(msg):
                    raise NotFoundError(
                        f"not found: {msg}",
                        resource=getattr(fn, "__name__", repr(fn)),
                        params=dict(kwargs),
                    ) from e
                if _RATE_LIMIT_PATTERN.search(msg):
                    if attempt < len(_BACKOFF_SECONDS):
                        wait = _BACKOFF_SECONDS[attempt]
                        log.warning("rate limited, retrying in %ss (attempt %d)", wait, attempt + 1)
                        time.sleep(wait)
                        last_exc = e
                        continue
                    raise RateLimitError(
                        f"rate limit exhausted after {len(_BACKOFF_SECONDS)} retries",
                        retry_after_seconds=sum(_BACKOFF_SECONDS),
                    ) from e
                if _SERVER_ERROR_PATTERN.search(msg):
                    if attempt < len(_BACKOFF_SECONDS):
                        wait = _BACKOFF_SECONDS[attempt]
                        log.warning("upstream 5xx, retrying in %ss (attempt %d)", wait, attempt + 1)
                        time.sleep(wait)
                        last_exc = e
                        continue
                    raise ApiError(f"upstream 5xx persisted: {msg}") from e
                raise  # unknown exception class — surface as-is
        # Should be unreachable, but mypy wants a return
        raise ApiError(f"retry loop exhausted unexpectedly: {last_exc}")

    # ---- public methods ----

    def get_user(
        self,
        user_id_or_name: str | int,
        *,
        mode: str = "osu",
        bypass_cache: bool = False,
    ) -> Any:
        return self._call_cached(
            "get_user",
            self._inner.user,
            user_id_or_name,
            mode=mode,
            bypass_cache=bypass_cache,
        )

    def get_user_scores(
        self,
        user_id: int,
        *,
        type: str,
        mode: str,
        limit: int = 10,
        bypass_cache: bool = False,
    ) -> Any:
        return self._call_cached(
            "get_user_scores",
            self._inner.user_scores,
            user_id,
            type=type,
            mode=mode,
            limit=limit,
            bypass_cache=bypass_cache,
        )

    def get_score(
        self, score_id: int, *, mode: str | None = None, bypass_cache: bool = False
    ) -> Any:
        # `mode` is accepted for API symmetry with the tool input model but
        # Ossapi.score(score_id) takes no mode kwarg (the new /scores/{id}
        # endpoint is mode-agnostic). Cache key still keys by score_id only.
        del mode
        return self._call_cached(
            "get_score",
            self._inner.score,
            score_id,
            bypass_cache=bypass_cache,
        )

    def search_beatmapsets(self, *, bypass_cache: bool = False, **kwargs: Any) -> Any:
        return self._call_cached(
            "search_beatmapsets",
            self._inner.search_beatmapsets,
            bypass_cache=bypass_cache,
            **kwargs,
        )

    def get_beatmap(self, beatmap_id: int, *, bypass_cache: bool = False) -> Any:
        return self._call_cached(
            "get_beatmap",
            self._inner.beatmap,
            beatmap_id,
            bypass_cache=bypass_cache,
        )

    def get_beatmap_scores(
        self, beatmap_id: int, *, bypass_cache: bool = False, **kwargs: Any
    ) -> Any:
        return self._call_cached(
            "get_beatmap_scores",
            self._inner.beatmap_scores,
            beatmap_id,
            bypass_cache=bypass_cache,
            **kwargs,
        )

    def get_beatmapset(
        self, beatmapset_id: int, *, bypass_cache: bool = False
    ) -> Any:
        return self._call_cached(
            "get_beatmapset",
            self._inner.beatmapset,
            beatmapset_id,
            bypass_cache=bypass_cache,
        )

    def get_ranking(
        self, mode: str, type: str, *, bypass_cache: bool = False, **kwargs: Any
    ) -> Any:
        return self._call_cached(
            "get_ranking",
            self._inner.ranking,
            mode,
            type,
            bypass_cache=bypass_cache,
            **kwargs,
        )

    def get_news_posts(self, *, bypass_cache: bool = False, **kwargs: Any) -> Any:
        return self._call_cached(
            "get_news_posts",
            self._inner.news_listing,
            bypass_cache=bypass_cache,
            **kwargs,
        )

    def get_seasonal_backgrounds(self, *, bypass_cache: bool = False) -> Any:
        return self._call_cached(
            "get_seasonal_backgrounds",
            self._inner.seasonal_backgrounds,
            bypass_cache=bypass_cache,
        )
