"""End-to-end smoke test: launch server, send tools/list, verify 12 tools."""
from __future__ import annotations

import json
import os
import subprocess
import sys
from typing import Any

import pytest


def _send_jsonrpc(proc: subprocess.Popen, payload: dict[str, Any]) -> dict[str, Any]:
    assert proc.stdin is not None
    assert proc.stdout is not None
    proc.stdin.write((json.dumps(payload) + "\n").encode())
    proc.stdin.flush()
    line = proc.stdout.readline()
    return json.loads(line) if line else {}


def _send_notification(proc: subprocess.Popen, payload: dict[str, Any]) -> None:
    assert proc.stdin is not None
    proc.stdin.write((json.dumps(payload) + "\n").encode())
    proc.stdin.flush()


@pytest.mark.timeout(15)
def test_server_starts_and_lists_twelve_tools() -> None:
    """Spawn the server with OSU_MCP_SKIP_CLIENT_INIT=1 and call tools/list."""
    env = {
        **os.environ,
        "OSU_MCP_SKIP_CLIENT_INIT": "1",
        "PYTHONIOENCODING": "utf-8",
    }
    proc = subprocess.Popen(
        [sys.executable, "-m", "osu_mcp.server"],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    try:
        init_resp = _send_jsonrpc(proc, {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "smoke-test", "version": "0.1"},
            },
        })
        assert init_resp.get("id") == 1, f"initialize failed: {init_resp}"

        _send_notification(proc, {
            "jsonrpc": "2.0",
            "method": "notifications/initialized",
        })

        list_resp = _send_jsonrpc(proc, {
            "jsonrpc": "2.0",
            "id": 2,
            "method": "tools/list",
            "params": {},
        })
        tools = list_resp["result"]["tools"]
        names = {t["name"] for t in tools}
        expected = {
            "get_user_summary", "compare_users",
            "get_user_scores", "get_score_details",
            "search_beatmaps", "get_beatmap_details",
            "get_beatmap_scores", "get_beatmapset",
            "get_rankings", "get_country_top",
            "get_news_posts", "get_seasonal_backgrounds",
        }
        assert names == expected
        by_name = {t["name"]: t for t in tools}
        for t in tools:
            assert "inputSchema" in t
            schema = t["inputSchema"]
            assert schema["type"] == "object"
            # Guard against the v0.1.0 regression where every schema collapsed to
            # {properties: {kwargs: {}}} due to a **kwargs wrapper signature.
            props = schema.get("properties", {})
            assert "kwargs" not in props, (
                f"tool {t['name']!r} published a generic 'kwargs' schema: {schema!r}"
            )

        # Spot-check that representative tools advertise their real fields.
        user_scores = by_name["get_user_scores"]["inputSchema"]
        assert {"user_id", "type", "mode"} <= set(user_scores["properties"])
        assert {"user_id", "type", "mode"} <= set(user_scores.get("required", []))

        compare = by_name["compare_users"]["inputSchema"]
        assert {"users", "mode", "metrics"} <= set(compare["properties"])

        seasonal = by_name["get_seasonal_backgrounds"]["inputSchema"]
        assert "kwargs" not in seasonal.get("properties", {})
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
