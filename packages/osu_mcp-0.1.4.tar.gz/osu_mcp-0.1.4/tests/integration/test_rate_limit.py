"""Integration: verify 429 backoff against real API (may not always reproduce)."""
from __future__ import annotations

import contextlib
import os

import pytest

from osu_mcp.client import OsuClient
from osu_mcp.config import OsuConfig
from osu_mcp.errors import NotFoundError

pytestmark = pytest.mark.integration


def test_burst_requests_dont_crash() -> None:
    cid = os.environ.get("OSU_CLIENT_ID")
    csec = os.environ.get("OSU_CLIENT_SECRET")
    if not cid or not csec or csec == "fake":
        pytest.skip("integration: OSU_CLIENT_ID/SECRET not set with real values")
    client = OsuClient(OsuConfig(client_id=int(cid), client_secret=csec))
    # Hit known-existing users to avoid 404 noise (some low sequential IDs
    # belong to deleted/restricted accounts). The point is exercising bursts,
    # not enumerating ID space. Restricted/deleted ones we encounter are
    # tolerated — they still prove the bursts didn't crash.
    known_users = [2, 39, 124493, 2070907, 4504101, 9018118, 7562902,
                   1023489, 3717598, 20683878]
    for uid in known_users:
        with contextlib.suppress(NotFoundError):
            client.get_user(uid, mode="osu", bypass_cache=True)
