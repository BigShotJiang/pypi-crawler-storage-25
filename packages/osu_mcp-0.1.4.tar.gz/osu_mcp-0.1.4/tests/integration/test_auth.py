"""Integration: real OAuth2 Client Credentials handshake against osu! API."""
from __future__ import annotations

import os

import pytest

from osu_mcp.client import OsuClient
from osu_mcp.config import OsuConfig

pytestmark = pytest.mark.integration


@pytest.fixture
def real_config() -> OsuConfig:
    cid = os.environ.get("OSU_CLIENT_ID")
    csec = os.environ.get("OSU_CLIENT_SECRET")
    if not cid or not csec or csec == "fake":
        pytest.skip("integration: OSU_CLIENT_ID/SECRET not set with real values")
    return OsuConfig(client_id=int(cid), client_secret=csec)


def test_real_auth_handshake(real_config: OsuConfig) -> None:
    client = OsuClient(real_config)
    user = client.get_user("peppy", mode="osu")
    assert user.username == "peppy"
