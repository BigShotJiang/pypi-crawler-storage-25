"""Integration: hit 3 representative endpoints with real creds."""
from __future__ import annotations

import os
import time

import pytest

from osu_mcp.client import OsuClient
from osu_mcp.config import OsuConfig

pytestmark = pytest.mark.integration


@pytest.fixture
def client() -> OsuClient:
    cid = os.environ.get("OSU_CLIENT_ID")
    csec = os.environ.get("OSU_CLIENT_SECRET")
    if not cid or not csec or csec == "fake":
        pytest.skip("integration: OSU_CLIENT_ID/SECRET not set with real values")
    return OsuClient(OsuConfig(client_id=int(cid), client_secret=csec))


def test_get_user_real(client: OsuClient) -> None:
    user = client.get_user("peppy")
    assert user.id == 2


def test_search_beatmaps_real(client: OsuClient) -> None:
    time.sleep(1)
    res = client.search_beatmapsets(query="big black")
    assert hasattr(res, "beatmapsets")


def test_rankings_real(client: OsuClient) -> None:
    time.sleep(1)
    res = client.get_ranking("osu", "performance")
    assert hasattr(res, "ranking")
