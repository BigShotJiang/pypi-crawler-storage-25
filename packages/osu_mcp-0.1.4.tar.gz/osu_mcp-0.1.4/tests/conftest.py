"""Shared pytest fixtures."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock

import pytest

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.fixture
def fixture_loader():  # type: ignore[return]
    def _load(name: str) -> dict[str, Any]:
        return json.loads((FIXTURES / name).read_text(encoding="utf-8"))
    return _load


@pytest.fixture
def mock_osu_client() -> MagicMock:
    """A MagicMock standing in for OsuClient."""
    return MagicMock()
