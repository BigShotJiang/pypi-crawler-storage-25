"""Tests for osu_mcp.client — wraps ossapi with cache + retry."""
from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from osu_mcp.client import OsuClient
from osu_mcp.config import OsuConfig
from osu_mcp.errors import (
    ApiError,
    AuthError,
    NetworkError,
    NotFoundError,
    RateLimitError,
)


class TestClientInit:
    def test_init_creates_ossapi_with_creds(self) -> None:
        cfg = OsuConfig(client_id=1, client_secret="s")
        with patch("osu_mcp.client.Ossapi") as ossapi_cls:
            client = OsuClient(cfg)
            ossapi_cls.assert_called_once_with(1, "s")
            assert client._cfg is cfg  # noqa: SLF001

    def test_init_translates_auth_failure(self) -> None:
        cfg = OsuConfig(client_id=1, client_secret="s")
        with (
            patch("osu_mcp.client.Ossapi", side_effect=Exception("401 invalid_client")),
            pytest.raises(AuthError, match="invalid_client"),
        ):
            OsuClient(cfg)


class TestThinPassthrough:
    def test_get_user_calls_ossapi_user(self) -> None:
        cfg = OsuConfig(client_id=1, client_secret="s")
        with patch("osu_mcp.client.Ossapi") as ossapi_cls:
            inner = ossapi_cls.return_value
            inner.user.return_value = MagicMock(id=2, username="peppy")
            client = OsuClient(cfg)
            res = client.get_user("peppy", mode="osu")
            inner.user.assert_called_once()
            assert res.username == "peppy"

    def test_get_score_does_not_forward_mode_to_ossapi(self) -> None:
        """Regression: Ossapi.score(score_id) does NOT accept a `mode` kwarg.

        The mode parameter is retained on the wrapper for API symmetry but
        must not be forwarded to ossapi or the call TypeErrors.
        """
        cfg = OsuConfig(client_id=1, client_secret="s")
        with patch("osu_mcp.client.Ossapi") as ossapi_cls:
            inner = ossapi_cls.return_value
            inner.score.return_value = MagicMock(id=12345)
            client = OsuClient(cfg)
            client.get_score(12345, mode="osu")
            args, kwargs = inner.score.call_args
            assert "mode" not in kwargs, (
                f"mode must not be forwarded to Ossapi.score; got {kwargs!r}"
            )


class TestCache:
    def test_repeated_call_uses_cache(self) -> None:
        cfg = OsuConfig(client_id=1, client_secret="s")
        with patch("osu_mcp.client.Ossapi") as ossapi_cls:
            inner = ossapi_cls.return_value
            inner.user.return_value = MagicMock(id=2)
            client = OsuClient(cfg)
            client.get_user("peppy", mode="osu")
            client.get_user("peppy", mode="osu")
            assert inner.user.call_count == 1  # second call hit cache

    def test_different_args_bypass_cache(self) -> None:
        cfg = OsuConfig(client_id=1, client_secret="s")
        with patch("osu_mcp.client.Ossapi") as ossapi_cls:
            inner = ossapi_cls.return_value
            inner.user.return_value = MagicMock()
            client = OsuClient(cfg)
            client.get_user("peppy", mode="osu")
            client.get_user("peppy", mode="taiko")
            assert inner.user.call_count == 2

    def test_bypass_cache_kwarg_skips_cache(self) -> None:
        cfg = OsuConfig(client_id=1, client_secret="s")
        with patch("osu_mcp.client.Ossapi") as ossapi_cls:
            inner = ossapi_cls.return_value
            inner.user.return_value = MagicMock()
            client = OsuClient(cfg)
            client.get_user("peppy", mode="osu")
            client.get_user("peppy", mode="osu", bypass_cache=True)
            assert inner.user.call_count == 2

    def test_seasonal_backgrounds_uses_24h_ttl(self) -> None:
        # The cache TTL config should differ per method; just verify the cache exists.
        cfg = OsuConfig(client_id=1, client_secret="s")
        with patch("osu_mcp.client.Ossapi") as ossapi_cls:
            inner = ossapi_cls.return_value
            inner.seasonal_backgrounds.return_value = MagicMock()
            client = OsuClient(cfg)
            client.get_seasonal_backgrounds()
            client.get_seasonal_backgrounds()
            assert inner.seasonal_backgrounds.call_count == 1


class TestRetry:
    def test_429_retries_then_succeeds(self, mocker) -> None:  # type: ignore[no-untyped-def]
        cfg = OsuConfig(client_id=1, client_secret="s")
        with patch("osu_mcp.client.Ossapi") as ossapi_cls:
            inner = ossapi_cls.return_value
            err_429 = Exception("429 Too Many Requests")
            inner.user.side_effect = [err_429, err_429, MagicMock(username="ok")]
            mocker.patch("osu_mcp.client.time.sleep")  # no real sleeps
            client = OsuClient(cfg)
            res = client.get_user("peppy")
            assert res.username == "ok"
            assert inner.user.call_count == 3

    def test_429_exhausts_retries_raises_rate_limit(self, mocker) -> None:  # type: ignore[no-untyped-def]
        cfg = OsuConfig(client_id=1, client_secret="s")
        with patch("osu_mcp.client.Ossapi") as ossapi_cls:
            inner = ossapi_cls.return_value
            inner.user.side_effect = Exception("429 limit")
            mocker.patch("osu_mcp.client.time.sleep")
            client = OsuClient(cfg)
            with pytest.raises(RateLimitError):
                client.get_user("peppy")
            assert inner.user.call_count == 4  # initial + 3 retries

    def test_5xx_retries(self, mocker) -> None:  # type: ignore[no-untyped-def]
        cfg = OsuConfig(client_id=1, client_secret="s")
        with patch("osu_mcp.client.Ossapi") as ossapi_cls:
            inner = ossapi_cls.return_value
            inner.user.side_effect = Exception("503 service unavailable")
            mocker.patch("osu_mcp.client.time.sleep")
            client = OsuClient(cfg)
            with pytest.raises(ApiError):
                client.get_user("peppy")
            assert inner.user.call_count == 4

    def test_404_no_retry(self) -> None:
        cfg = OsuConfig(client_id=1, client_secret="s")
        with patch("osu_mcp.client.Ossapi") as ossapi_cls:
            inner = ossapi_cls.return_value
            inner.user.side_effect = Exception("404 not found")
            client = OsuClient(cfg)
            with pytest.raises(NotFoundError):
                client.get_user("nope")
            assert inner.user.call_count == 1  # no retry

    def test_restricted_account_mapped_to_not_found(self) -> None:
        """ossapi raises a bare ValueError("api returned an error of `None`")
        when the API returns {"error": null} (restricted/deleted account).
        We must map this to NotFoundError so callers can handle it cleanly.
        """
        cfg = OsuConfig(client_id=1, client_secret="s")
        with patch("osu_mcp.client.Ossapi") as ossapi_cls:
            inner = ossapi_cls.return_value
            inner.user.side_effect = ValueError(
                "api returned an error of `None` for a request to "
                "https://osu.ppy.sh/api/v2/users/39/osu"
            )
            client = OsuClient(cfg)
            with pytest.raises(NotFoundError):
                client.get_user(39)
            assert inner.user.call_count == 1  # no retry on restricted

    def test_network_error_one_retry(self, mocker) -> None:  # type: ignore[no-untyped-def]
        cfg = OsuConfig(client_id=1, client_secret="s")
        with patch("osu_mcp.client.Ossapi") as ossapi_cls:
            inner = ossapi_cls.return_value
            inner.user.side_effect = ConnectionError("dns fail")
            mocker.patch("osu_mcp.client.time.sleep")
            client = OsuClient(cfg)
            with pytest.raises(NetworkError):
                client.get_user("peppy")
            assert inner.user.call_count == 2  # initial + 1 retry
