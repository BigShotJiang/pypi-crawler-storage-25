"""Tests for osu_mcp.models — type aliases + pydantic schemas."""
import json
from datetime import UTC, datetime

import pytest
from ossapi.enums import Grade
from ossapi.models import NonLegacyMod
from pydantic import ValidationError as PydanticValidationError

from osu_mcp.models import (
    CompareUsersInput,
    GetRankingsInput,
    GetUserScoresInput,
    GetUserSummaryInput,
    Mode,
    ScoreSummary,
    SearchBeatmapsInput,
    UserSummaryOutput,
)


class TestModeEnum:
    @pytest.mark.parametrize("mode", ["osu", "taiko", "fruits", "mania"])
    def test_accepts_valid_modes(self, mode: str) -> None:
        m: Mode = mode  # type: ignore[assignment]
        assert m == mode

    # Mode is a Literal type — runtime validation happens via pydantic in input models


class TestGetUserSummaryInput:
    def test_minimal_valid_input(self) -> None:
        inp = GetUserSummaryInput(user_id_or_name="peppy")
        assert inp.user_id_or_name == "peppy"
        assert inp.mode == "osu"
        assert inp.include == []

    def test_include_accepts_known_values(self) -> None:
        inp = GetUserSummaryInput(user_id_or_name="2", include=["recent", "best"])
        assert "recent" in inp.include

    def test_include_rejects_unknown_values(self) -> None:
        with pytest.raises(PydanticValidationError):
            GetUserSummaryInput(user_id_or_name="x", include=["nope"])  # type: ignore[list-item]

    def test_mode_rejects_unknown(self) -> None:
        with pytest.raises(PydanticValidationError):
            GetUserSummaryInput(user_id_or_name="x", mode="catch")  # type: ignore[arg-type]


class TestCompareUsersInput:
    def test_requires_at_least_two_users(self) -> None:
        with pytest.raises(PydanticValidationError):
            CompareUsersInput(users=["a"], mode="osu", metrics=["pp"])

    def test_rejects_more_than_five_users(self) -> None:
        with pytest.raises(PydanticValidationError):
            CompareUsersInput(
                users=["a", "b", "c", "d", "e", "f"], mode="osu", metrics=["pp"]
            )

    def test_rejects_unknown_metric(self) -> None:
        with pytest.raises(PydanticValidationError):
            CompareUsersInput(users=["a", "b"], mode="osu", metrics=["nope"])  # type: ignore[list-item]


class TestGetRankingsInput:
    """Regression: ossapi.RankingType has {charts, country, performance, score}.
    'pp' is not a valid value — must be 'performance'.
    """

    def test_accepts_performance(self) -> None:
        inp = GetRankingsInput(type="performance", mode="osu")
        assert inp.type == "performance"

    def test_rejects_pp_legacy_alias(self) -> None:
        with pytest.raises(PydanticValidationError):
            GetRankingsInput(type="pp", mode="osu")  # type: ignore[arg-type]


class TestGetUserScoresInput:
    def test_limit_bounds(self) -> None:
        # min=1, max=100
        GetUserScoresInput(user_id=1, type="best", mode="osu", limit=1)
        GetUserScoresInput(user_id=1, type="best", mode="osu", limit=100)
        with pytest.raises(PydanticValidationError):
            GetUserScoresInput(user_id=1, type="best", mode="osu", limit=0)
        with pytest.raises(PydanticValidationError):
            GetUserScoresInput(user_id=1, type="best", mode="osu", limit=101)


class TestSearchBeatmapsInput:
    def test_difficulty_range_validates_tuple_order(self) -> None:
        SearchBeatmapsInput(query="x", difficulty_range=(2.0, 6.0))
        with pytest.raises(PydanticValidationError, match="min must be <= max"):
            SearchBeatmapsInput(query="x", difficulty_range=(6.0, 2.0))


class TestScoreSummaryMods:
    """ossapi 5.x returns mods as NonLegacyMod objects with .acronym, not str.

    ScoreSummary must coerce them to acronym strings so downstream JSON
    serialization works.
    """

    @staticmethod
    def _kwargs(**overrides: object) -> dict[str, object]:
        base: dict[str, object] = {
            "id": 1,
            "beatmap_id": 2,
            "beatmapset_title": "t",
            "score": 0,
            "pp": None,
            "accuracy": 0.0,
            "max_combo": 0,
            "rank": "S",
            "mods": [],
            "created_at": "2026-01-01T00:00:00+00:00",
        }
        base.update(overrides)
        return base

    def test_strings_pass_through_unchanged(self) -> None:
        out = ScoreSummary(**self._kwargs(mods=["HD", "HR"]))  # type: ignore[arg-type]
        assert out.mods == ["HD", "HR"]

    def test_coerces_objects_with_acronym(self) -> None:
        out = ScoreSummary(
            **self._kwargs(mods=[NonLegacyMod(acronym="DT")])  # type: ignore[arg-type]
        )
        assert out.mods == ["DT"]

    def test_accepts_mixed_list(self) -> None:
        out = ScoreSummary(
            **self._kwargs(
                mods=["HD", NonLegacyMod(acronym="DT")]  # type: ignore[arg-type]
            )
        )
        assert out.mods == ["HD", "DT"]

    def test_empty_list(self) -> None:
        out = ScoreSummary(**self._kwargs(mods=[]))  # type: ignore[arg-type]
        assert out.mods == []

    def test_model_dump_is_json_serializable(self) -> None:
        out = ScoreSummary(
            **self._kwargs(mods=[NonLegacyMod(acronym="DT")])  # type: ignore[arg-type]
        )
        # Round-trip through JSON must succeed (catches raw NonLegacyMod leak).
        json.dumps(out.model_dump())


class TestScoreSummaryRank:
    """Regression: ossapi 5.x returns `rank` as a Grade enum, not a string."""

    @staticmethod
    def _kwargs(**overrides: object) -> dict[str, object]:
        base: dict[str, object] = {
            "id": 1, "beatmap_id": 2, "beatmapset_title": "t",
            "score": 0, "pp": None, "accuracy": 0.0, "max_combo": 0,
            "rank": "S", "mods": [], "created_at": "2026-01-01T00:00:00+00:00",
        }
        base.update(overrides)
        return base

    def test_str_rank_passes_through(self) -> None:
        out = ScoreSummary(**self._kwargs(rank="S"))  # type: ignore[arg-type]
        assert out.rank == "S"

    def test_grade_enum_uses_name_not_str(self) -> None:
        out = ScoreSummary(**self._kwargs(rank=Grade.S))  # type: ignore[arg-type]
        # str(Grade.S) is 'Grade.S', .name is 'S' — we want the short name.
        assert out.rank == "S"

    def test_grade_ss_uses_ss_not_x(self) -> None:
        """Grade.SS has value='X' (API legacy) but name='SS' (user-recognized)."""
        out = ScoreSummary(**self._kwargs(rank=Grade.SS))  # type: ignore[arg-type]
        assert out.rank == "SS"


class TestScoreSummaryCreatedAt:
    """Regression: ossapi returns datetime, not str."""

    @staticmethod
    def _kwargs(**overrides: object) -> dict[str, object]:
        base: dict[str, object] = {
            "id": 1, "beatmap_id": 2, "beatmapset_title": "t",
            "score": 0, "pp": None, "accuracy": 0.0, "max_combo": 0,
            "rank": "S", "mods": [], "created_at": "2026-01-01T00:00:00+00:00",
        }
        base.update(overrides)
        return base

    def test_datetime_coerces_to_iso_string(self) -> None:
        dt = datetime(2026, 5, 23, 10, 30, tzinfo=UTC)
        out = ScoreSummary(**self._kwargs(created_at=dt))  # type: ignore[arg-type]
        assert out.created_at.startswith("2026-05-23T10:30:00")


class TestUserSummaryOutput:
    def test_serializes_with_required_fields_only(self) -> None:
        out = UserSummaryOutput(
            id=2,
            username="peppy",
            country_code="AU",
            pp=12345.6,
            accuracy=98.5,
            play_count=50000,
            ranked_score=123456789,
            level=105,
            global_rank=42,
            country_rank=1,
            avatar_url="https://a.ppy.sh/2",
            joined_at="2007-06-26T01:01:01+00:00",
        )
        dumped = out.model_dump()
        assert dumped["username"] == "peppy"
        assert len(dumped) <= 15  # token-tight output
