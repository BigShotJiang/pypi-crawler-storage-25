"""Tests for the tool registry / @register_tool decorator."""
from __future__ import annotations

from typing import Any

import pytest
from pydantic import BaseModel

from osu_mcp.tools import REGISTRY, ToolSpec, register_tool


class DummyInput(BaseModel):
    x: int


class TestRegistry:
    _saved: dict[str, Any] = {}

    def setup_method(self) -> None:
        self._saved = dict(REGISTRY)
        REGISTRY.clear()

    def teardown_method(self) -> None:
        REGISTRY.clear()
        REGISTRY.update(self._saved)

    def test_register_tool_adds_to_registry(self) -> None:
        @register_tool(
            name="dummy", description="test tool", input_model=DummyInput
        )
        def handler(args: DummyInput, client: Any) -> dict[str, Any]:
            return {"x_squared": args.x ** 2}

        assert "dummy" in REGISTRY
        spec = REGISTRY["dummy"]
        assert isinstance(spec, ToolSpec)
        assert spec.name == "dummy"
        assert spec.description == "test tool"
        assert spec.input_model is DummyInput

    def test_duplicate_name_raises(self) -> None:
        @register_tool(name="dup", description="d", input_model=DummyInput)
        def h1(args: DummyInput, client: Any) -> dict[str, Any]:
            return {}

        with pytest.raises(ValueError, match="already registered"):
            @register_tool(name="dup", description="d2", input_model=DummyInput)
            def h2(args: DummyInput, client: Any) -> dict[str, Any]:
                return {}
