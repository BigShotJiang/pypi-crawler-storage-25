"""Tests for tools/beatmaps.py."""
from __future__ import annotations

import json
from types import SimpleNamespace
from typing import Any

from ossapi.enums import BeatmapsetSearchMode, Grade, RankStatus
from ossapi.models import NonLegacyMod

from osu_mcp.models import (
    GetBeatmapDetailsInput,
    GetBeatmapScoresInput,
    GetBeatmapsetInput,
    SearchBeatmapsInput,
)
from osu_mcp.tools import REGISTRY
from osu_mcp.tools import beatmaps as _beatmaps  # noqa: F401


def _ns(d: Any) -> Any:
    if isinstance(d, dict):
        return SimpleNamespace(**{k: _ns(v) for k, v in d.items()})
    if isinstance(d, list):
        return [_ns(x) for x in d]
    return d


class TestSearchBeatmaps:
    def test_basic_search(self, mock_osu_client: Any) -> None:
        mock_osu_client.search_beatmapsets.return_value = SimpleNamespace(
            beatmapsets=[_ns({"id": 100, "title": "x", "artist": "y", "creator": "z",
                              "status": "ranked", "bpm": 180.0, "play_count": 1,
                              "beatmaps": []})]
        )
        spec = REGISTRY["search_beatmaps"]
        result = spec.handler(SearchBeatmapsInput(query="big black"), mock_osu_client)
        assert result["count"] == 1
        assert result["beatmapsets"][0]["title"] == "x"

    def test_filters_passed_through(self, mock_osu_client: Any) -> None:
        mock_osu_client.search_beatmapsets.return_value = SimpleNamespace(beatmapsets=[])
        spec = REGISTRY["search_beatmaps"]
        spec.handler(
            SearchBeatmapsInput(query="x", mode="taiko", status="ranked"),
            mock_osu_client,
        )
        kwargs = mock_osu_client.search_beatmapsets.call_args.kwargs
        assert kwargs.get("query") == "x"

    def test_translates_mode_str_to_search_mode_enum(
        self, mock_osu_client: Any
    ) -> None:
        """Regression: ossapi.search_beatmapsets expects BeatmapsetSearchMode|int,
        not the GameMode string. Pass the enum int (OSU=0, TAIKO=1, CATCH=2, MANIA=3).
        """
        mock_osu_client.search_beatmapsets.return_value = SimpleNamespace(beatmapsets=[])
        spec = REGISTRY["search_beatmaps"]
        spec.handler(
            SearchBeatmapsInput(query="x", mode="taiko"), mock_osu_client
        )
        kwargs = mock_osu_client.search_beatmapsets.call_args.kwargs
        assert kwargs.get("mode") == BeatmapsetSearchMode.TAIKO

    def test_translates_fruits_to_catch(self, mock_osu_client: Any) -> None:
        """GameMode 'fruits' → BeatmapsetSearchMode.CATCH (different name)."""
        mock_osu_client.search_beatmapsets.return_value = SimpleNamespace(beatmapsets=[])
        spec = REGISTRY["search_beatmaps"]
        spec.handler(
            SearchBeatmapsInput(query="x", mode="fruits"), mock_osu_client
        )
        kwargs = mock_osu_client.search_beatmapsets.call_args.kwargs
        assert kwargs.get("mode") == BeatmapsetSearchMode.CATCH

    def test_coerces_rank_status_enum(self, mock_osu_client: Any) -> None:
        """Regression: ossapi returns `status` as RankStatus enum, not str.
        str(RankStatus.APPROVED) is 'RankStatus.APPROVED' — must use name.lower().
        """
        mock_osu_client.search_beatmapsets.return_value = SimpleNamespace(
            beatmapsets=[SimpleNamespace(
                id=1, title="t", artist="a", creator="c",
                status=RankStatus.APPROVED, bpm=180.0, play_count=1, beatmaps=[],
            )]
        )
        spec = REGISTRY["search_beatmaps"]
        result = spec.handler(SearchBeatmapsInput(query="x"), mock_osu_client)
        assert result["beatmapsets"][0]["status"] == "approved"

    def test_does_not_forward_limit_kwarg(self, mock_osu_client: Any) -> None:
        """Regression: ossapi.search_beatmapsets has no `limit` kwarg.
        Slice client-side instead.
        """
        mock_osu_client.search_beatmapsets.return_value = SimpleNamespace(
            beatmapsets=[
                SimpleNamespace(id=i, title=f"t{i}", artist="a", creator="c",
                                status="ranked", bpm=180.0, play_count=1, beatmaps=[])
                for i in range(30)
            ]
        )
        spec = REGISTRY["search_beatmaps"]
        result = spec.handler(
            SearchBeatmapsInput(query="x", limit=5), mock_osu_client
        )
        kwargs = mock_osu_client.search_beatmapsets.call_args.kwargs
        assert "limit" not in kwargs, (
            f"limit must not be forwarded; got kwargs={kwargs}"
        )
        assert result["count"] == 5, "must slice client-side to honor limit"


class TestGetBeatmapDetails:
    def test_returns_attrs(self, fixture_loader: Any, mock_osu_client: Any) -> None:
        data = fixture_loader("beatmap_details.json")
        mock_osu_client.get_beatmap.return_value = _ns(data)
        spec = REGISTRY["get_beatmap_details"]
        result = spec.handler(GetBeatmapDetailsInput(beatmap_id=999), mock_osu_client)
        assert result["id"] == 999
        assert result["ar"] == 9.0
        assert result["bpm"] == 180.0


class TestGetBeatmapScores:
    def test_returns_top_scores(self, mock_osu_client: Any) -> None:
        mock_osu_client.get_beatmap_scores.return_value = SimpleNamespace(
            scores=[_ns({"id": 1, "user_id": 2, "score": 1000, "pp": 700.0,
                         "accuracy": 0.99, "max_combo": 1234, "rank": "S",
                         "mods": []})]
        )
        spec = REGISTRY["get_beatmap_scores"]
        result = spec.handler(
            GetBeatmapScoresInput(beatmap_id=999, mode="osu"), mock_osu_client
        )
        assert result["count"] == 1
        assert result["scores"][0]["pp"] == 700.0

    def test_normalizes_non_legacy_mods(self, mock_osu_client: Any) -> None:
        """Regression: beatmap scores with NonLegacyMod must JSON-serialize."""
        mock_osu_client.get_beatmap_scores.return_value = SimpleNamespace(
            scores=[SimpleNamespace(
                id=1, user_id=2, score=1000, pp=700.0,
                accuracy=0.99, max_combo=1234, rank="S",
                mods=[NonLegacyMod(acronym="DT"), "HD"],
            )]
        )
        spec = REGISTRY["get_beatmap_scores"]
        result = spec.handler(
            GetBeatmapScoresInput(beatmap_id=999, mode="osu"), mock_osu_client
        )
        assert result["scores"][0]["mods"] == ["DT", "HD"]
        json.dumps(result)

    def test_serializes_grade_enum_rank(self, mock_osu_client: Any) -> None:
        """Regression: beatmap scores rank is Grade enum, must coerce to short name."""
        mock_osu_client.get_beatmap_scores.return_value = SimpleNamespace(
            scores=[SimpleNamespace(
                id=1, user_id=2, score=1000, pp=700.0,
                accuracy=0.99, max_combo=1234, rank=Grade.SH, mods=[],
            )]
        )
        spec = REGISTRY["get_beatmap_scores"]
        result = spec.handler(
            GetBeatmapScoresInput(beatmap_id=999, mode="osu"), mock_osu_client
        )
        assert result["scores"][0]["rank"] == "SH"
        json.dumps(result)


class TestGetBeatmapset:
    def test_returns_set_with_diffs(
        self, fixture_loader: Any, mock_osu_client: Any
    ) -> None:
        data = fixture_loader("beatmapset.json")
        mock_osu_client.get_beatmapset.return_value = _ns(data)
        spec = REGISTRY["get_beatmapset"]
        result = spec.handler(GetBeatmapsetInput(beatmapset_id=100), mock_osu_client)
        assert result["title"] == "Big Black"
        assert result["difficulty_count"] == 2
