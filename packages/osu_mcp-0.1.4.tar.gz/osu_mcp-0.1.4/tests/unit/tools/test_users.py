"""Tests for tools/users.py — get_user_summary and compare_users."""
from __future__ import annotations

import json
from types import SimpleNamespace
from typing import Any

from ossapi.enums import Grade
from ossapi.models import NonLegacyMod

from osu_mcp.models import CompareUsersInput, GetUserSummaryInput
from osu_mcp.tools import REGISTRY
from osu_mcp.tools import users as _users  # noqa: F401 — imports trigger registration


def _make_user_namespace(data: dict[str, Any]) -> SimpleNamespace:
    """Convert dict-shaped fixture into ossapi-like nested namespace."""
    def to_ns(v: Any) -> Any:
        if isinstance(v, dict):
            return SimpleNamespace(**{k: to_ns(vv) for k, vv in v.items()})
        return v
    return to_ns(data)


class TestGetUserSummary:
    def test_returns_recortado_dict(self, fixture_loader: Any, mock_osu_client: Any) -> None:
        user_data = fixture_loader("user_summary.json")
        mock_osu_client.get_user.return_value = _make_user_namespace(user_data)
        spec = REGISTRY["get_user_summary"]
        result = spec.handler(GetUserSummaryInput(user_id_or_name="peppy"), mock_osu_client)

        assert result["username"] == "peppy"
        assert result["country_code"] == "AU"
        assert result["pp"] == 12345.6
        assert result["global_rank"] == 42
        assert "_cached" in result
        assert len(result) <= 16

    def test_include_recent_embeds_scores(
        self, fixture_loader: Any, mock_osu_client: Any
    ) -> None:
        user_data = fixture_loader("user_summary.json")
        mock_osu_client.get_user.return_value = _make_user_namespace(user_data)
        mock_osu_client.get_user_scores.return_value = []
        spec = REGISTRY["get_user_summary"]
        result = spec.handler(
            GetUserSummaryInput(user_id_or_name="2", include=["recent"]),
            mock_osu_client,
        )
        assert "recent" in result
        mock_osu_client.get_user_scores.assert_called_once()

    def test_include_best_normalizes_non_legacy_mods(
        self, fixture_loader: Any, mock_osu_client: Any
    ) -> None:
        """Regression: embedded best scores must JSON-serialize even with NonLegacyMod."""
        user_data = fixture_loader("user_summary.json")
        mock_osu_client.get_user.return_value = _make_user_namespace(user_data)
        score_ns = SimpleNamespace(
            id=1,
            beatmap=SimpleNamespace(id=999),
            pp=727.0,
            accuracy=0.99,
            rank="S",
            mods=[NonLegacyMod(acronym="DT"), "HD"],
        )
        mock_osu_client.get_user_scores.return_value = [score_ns]
        spec = REGISTRY["get_user_summary"]
        result = spec.handler(
            GetUserSummaryInput(user_id_or_name="2", include=["best"]),
            mock_osu_client,
        )
        assert result["best"][0]["mods"] == ["DT", "HD"]
        # Must be JSON-serializable end-to-end (catches raw NonLegacyMod leak).
        json.dumps(result)

    def test_include_best_serializes_grade_enum_rank(
        self, fixture_loader: Any, mock_osu_client: Any
    ) -> None:
        """Regression: ossapi returns rank as Grade enum, not str.
        _score_brief must coerce to keep JSON serializable.
        """
        user_data = fixture_loader("user_summary.json")
        mock_osu_client.get_user.return_value = _make_user_namespace(user_data)
        score_ns = SimpleNamespace(
            id=1, beatmap=SimpleNamespace(id=999),
            pp=200.0, accuracy=0.99, rank=Grade.S, mods=[],
        )
        mock_osu_client.get_user_scores.return_value = [score_ns]
        spec = REGISTRY["get_user_summary"]
        result = spec.handler(
            GetUserSummaryInput(user_id_or_name="2", include=["best"]),
            mock_osu_client,
        )
        assert result["best"][0]["rank"] == "S"
        json.dumps(result)  # full round-trip


class TestCompareUsers:
    def test_returns_side_by_side(
        self, fixture_loader: Any, mock_osu_client: Any
    ) -> None:
        user_data = fixture_loader("user_summary.json")
        user2 = dict(user_data)
        user2["id"] = 3
        user2["username"] = "cookiezi"
        mock_osu_client.get_user.side_effect = [
            _make_user_namespace(user_data),
            _make_user_namespace(user2),
        ]
        spec = REGISTRY["compare_users"]
        result = spec.handler(
            CompareUsersInput(
                users=["peppy", "cookiezi"], mode="osu", metrics=["pp", "accuracy"]
            ),
            mock_osu_client,
        )
        assert result["count"] == 2
        assert len(result["users"]) == 2
        assert result["users"][0]["metrics"]["pp"] == 12345.6
        assert "accuracy" in result["users"][0]["metrics"]
