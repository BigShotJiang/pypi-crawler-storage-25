"""Tests for tools/scores.py."""
from __future__ import annotations

import json
from types import SimpleNamespace
from typing import Any

from ossapi.enums import Grade
from ossapi.models import NonLegacyMod

from osu_mcp.models import GetScoreDetailsInput, GetUserScoresInput
from osu_mcp.tools import REGISTRY
from osu_mcp.tools import scores as _scores  # noqa: F401


def _ns(d: Any) -> Any:
    if isinstance(d, dict):
        return SimpleNamespace(**{k: _ns(v) for k, v in d.items()})
    if isinstance(d, list):
        return [_ns(x) for x in d]
    return d


class TestGetUserScores:
    def test_returns_list_with_count(
        self, fixture_loader: Any, mock_osu_client: Any
    ) -> None:
        data = fixture_loader("user_scores_best.json")
        mock_osu_client.get_user_scores.return_value = _ns(data)
        spec = REGISTRY["get_user_scores"]
        result = spec.handler(
            GetUserScoresInput(user_id=2, type="best", mode="osu", limit=10),
            mock_osu_client,
        )
        assert result["count"] == 1
        assert result["scores"][0]["pp"] == 727.0
        assert result["scores"][0]["beatmapset_title"] == "Big Black"

    def test_passes_limit_to_client(self, mock_osu_client: Any) -> None:
        mock_osu_client.get_user_scores.return_value = []
        spec = REGISTRY["get_user_scores"]
        spec.handler(
            GetUserScoresInput(user_id=2, type="recent", mode="osu", limit=50),
            mock_osu_client,
        )
        kwargs = mock_osu_client.get_user_scores.call_args.kwargs
        assert kwargs["limit"] == 50
        assert kwargs["type"] == "recent"


class TestGetScoreDetails:
    def test_returns_score_dict(
        self, fixture_loader: Any, mock_osu_client: Any
    ) -> None:
        data = fixture_loader("user_scores_best.json")[0]
        mock_osu_client.get_score.return_value = _ns(data)
        spec = REGISTRY["get_score_details"]
        result = spec.handler(
            GetScoreDetailsInput(score_id=12345, mode="osu"), mock_osu_client
        )
        assert result["id"] == 12345
        assert result["pp"] == 727.0


class TestModsNormalization:
    """Regression: ossapi 5.x returns mods as NonLegacyMod objects."""

    def test_user_scores_normalizes_non_legacy_mod(
        self, fixture_loader: Any, mock_osu_client: Any
    ) -> None:
        data = fixture_loader("user_scores_best.json")
        ns = _ns(data)
        # Replace mods with the real NonLegacyMod objects the API now returns.
        ns[0].mods = [NonLegacyMod(acronym="HD"), NonLegacyMod(acronym="DT")]
        mock_osu_client.get_user_scores.return_value = ns
        spec = REGISTRY["get_user_scores"]
        result = spec.handler(
            GetUserScoresInput(user_id=2, type="best", mode="osu", limit=10),
            mock_osu_client,
        )
        assert result["scores"][0]["mods"] == ["HD", "DT"]
        json.dumps(result)  # must be JSON-serializable


class TestScoreFieldMapping:
    """Regression: ossapi 5.x renamed fields.
    score → total_score, created_at → ended_at, rank → Grade enum.
    """

    def test_uses_total_score_when_score_missing(
        self, mock_osu_client: Any
    ) -> None:
        score_ns = SimpleNamespace(
            id=1,
            beatmap=SimpleNamespace(id=999),
            beatmapset=SimpleNamespace(title="t"),
            total_score=1234567,  # new lazer field
            pp=200.0, accuracy=0.99, max_combo=300,
            rank=Grade.S, mods=[], ended_at="2026-01-01T00:00:00+00:00",
        )
        mock_osu_client.get_user_scores.return_value = [score_ns]
        spec = REGISTRY["get_user_scores"]
        result = spec.handler(
            GetUserScoresInput(user_id=2, type="best", mode="osu", limit=1),
            mock_osu_client,
        )
        assert result["scores"][0]["score"] == 1234567, (
            "must use total_score when score field is absent"
        )
        assert result["scores"][0]["rank"] == "S"
        assert result["scores"][0]["created_at"] == "2026-01-01T00:00:00+00:00"

    def test_grade_enum_serializes_as_short_name(
        self, mock_osu_client: Any
    ) -> None:
        score_ns = SimpleNamespace(
            id=1, beatmap=SimpleNamespace(id=999),
            beatmapset=SimpleNamespace(title="t"),
            total_score=1, pp=None, accuracy=0.0, max_combo=0,
            rank=Grade.SS, mods=[], ended_at="2026-01-01T00:00:00+00:00",
        )
        mock_osu_client.get_user_scores.return_value = [score_ns]
        spec = REGISTRY["get_user_scores"]
        result = spec.handler(
            GetUserScoresInput(user_id=2, type="best", mode="osu", limit=1),
            mock_osu_client,
        )
        assert result["scores"][0]["rank"] == "SS"
        json.dumps(result)
