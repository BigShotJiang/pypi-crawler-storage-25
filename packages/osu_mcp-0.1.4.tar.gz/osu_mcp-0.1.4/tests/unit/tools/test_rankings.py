"""Tests for tools/rankings.py."""
from __future__ import annotations

from types import SimpleNamespace
from typing import Any

from osu_mcp.models import GetCountryTopInput, GetRankingsInput
from osu_mcp.tools import REGISTRY
from osu_mcp.tools import rankings as _rankings  # noqa: F401


def _ns(d: Any) -> Any:
    if isinstance(d, dict):
        return SimpleNamespace(**{k: _ns(v) for k, v in d.items()})
    if isinstance(d, list):
        return [_ns(x) for x in d]
    return d


class TestGetRankings:
    def test_basic_performance_ranking(
        self, fixture_loader: Any, mock_osu_client: Any
    ) -> None:
        data = fixture_loader("rankings.json")
        mock_osu_client.get_ranking.return_value = _ns(data)
        spec = REGISTRY["get_rankings"]
        result = spec.handler(
            GetRankingsInput(type="performance", mode="osu"), mock_osu_client
        )
        assert result["count"] == 1
        assert result["entries"][0]["username"] == "peppy"
        assert result["entries"][0]["pp"] == 12345.6

    def test_country_filter(
        self, fixture_loader: Any, mock_osu_client: Any
    ) -> None:
        data = fixture_loader("rankings.json")
        mock_osu_client.get_ranking.return_value = _ns(data)
        spec = REGISTRY["get_rankings"]
        spec.handler(
            GetRankingsInput(type="performance", mode="osu", country="EC"),
            mock_osu_client,
        )
        kwargs = mock_osu_client.get_ranking.call_args.kwargs
        assert kwargs.get("country") == "EC"

    def test_forwards_performance_string_to_client(
        self, fixture_loader: Any, mock_osu_client: Any
    ) -> None:
        """Regression: ossapi RankingType enum requires 'performance', not 'pp'."""
        data = fixture_loader("rankings.json")
        mock_osu_client.get_ranking.return_value = _ns(data)
        spec = REGISTRY["get_rankings"]
        spec.handler(
            GetRankingsInput(type="performance", mode="osu"), mock_osu_client
        )
        args, _ = mock_osu_client.get_ranking.call_args
        assert "performance" in args, (
            f"expected 'performance' in positional args, got {args!r}"
        )
        assert "pp" not in args

    def test_does_not_forward_page_kwarg(
        self, fixture_loader: Any, mock_osu_client: Any
    ) -> None:
        """Regression: Ossapi.ranking() does NOT accept a `page` kwarg
        (cursor-based pagination only). Must not forward it.
        """
        data = fixture_loader("rankings.json")
        mock_osu_client.get_ranking.return_value = _ns(data)
        spec = REGISTRY["get_rankings"]
        spec.handler(
            GetRankingsInput(type="performance", mode="osu"), mock_osu_client
        )
        kwargs = mock_osu_client.get_ranking.call_args.kwargs
        assert "page" not in kwargs, (
            f"page must not be forwarded; got kwargs={kwargs}"
        )


class TestGetCountryTop:
    def test_calls_pp_ranking_with_country(
        self, fixture_loader: Any, mock_osu_client: Any
    ) -> None:
        data = fixture_loader("rankings.json")
        mock_osu_client.get_ranking.return_value = _ns(data)
        spec = REGISTRY["get_country_top"]
        result = spec.handler(
            GetCountryTopInput(country_code="EC", mode="osu", limit=10),
            mock_osu_client,
        )
        kwargs = mock_osu_client.get_ranking.call_args.kwargs
        assert kwargs.get("country") == "EC"
        assert result["country_code"] == "EC"
