"""Tests for tools/meta.py."""
from __future__ import annotations

from types import SimpleNamespace
from typing import Any

from osu_mcp.models import GetNewsPostsInput, GetSeasonalBackgroundsInput
from osu_mcp.tools import REGISTRY
from osu_mcp.tools import meta as _meta  # noqa: F401


def _ns(d: Any) -> Any:
    if isinstance(d, dict):
        return SimpleNamespace(**{k: _ns(v) for k, v in d.items()})
    if isinstance(d, list):
        return [_ns(x) for x in d]
    return d


class TestGetNewsPosts:
    def test_returns_post_list(self, mock_osu_client: Any) -> None:
        mock_osu_client.get_news_posts.return_value = _ns({
            "news_posts": [
                {"id": 1, "title": "Update", "slug": "update",
                 "published_at": "2026-05-01", "author": "appy"}
            ]
        })
        spec = REGISTRY["get_news_posts"]
        result = spec.handler(GetNewsPostsInput(limit=5), mock_osu_client)
        assert result["count"] == 1
        assert result["posts"][0]["title"] == "Update"


class TestGetSeasonalBackgrounds:
    def test_returns_backgrounds(self, mock_osu_client: Any) -> None:
        mock_osu_client.get_seasonal_backgrounds.return_value = _ns({
            "ends_at": "2026-06-01",
            "backgrounds": [
                {"url": "https://x/1.jpg", "user": {"username": "art1"}}
            ]
        })
        spec = REGISTRY["get_seasonal_backgrounds"]
        result = spec.handler(GetSeasonalBackgroundsInput(), mock_osu_client)
        assert result["count"] == 1
        assert result["backgrounds"][0]["url"] == "https://x/1.jpg"
