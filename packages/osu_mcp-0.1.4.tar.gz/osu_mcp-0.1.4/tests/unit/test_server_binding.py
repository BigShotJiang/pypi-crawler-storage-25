"""Tests for _bind_tool: verify FastMCP introspects the input model's fields.

Regression for v0.1.0 bug where the wrapper used **kwargs as its signature,
causing FastMCP to publish a schema {properties: {kwargs: {}}} that hid the
real fields. Clients could not call any tool successfully.
"""
from __future__ import annotations

from typing import Any

import pytest
from mcp.server.fastmcp import FastMCP
from pydantic import BaseModel, ConfigDict, Field

from osu_mcp.errors import ValidationError as OsuValidationError
from osu_mcp.server import _bind_tool
from osu_mcp.tools import REGISTRY, ToolSpec


class _StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class SampleInput(_StrictModel):
    user_id: int = Field(gt=0)
    type: str
    mode: str = "osu"
    limit: int = Field(default=10, ge=1, le=100)


class SampleInputWithFactory(_StrictModel):
    name: str
    tags: list[str] = Field(default_factory=list)


class EmptyInput(_StrictModel):
    pass


@pytest.fixture(autouse=True)
def _isolate_registry() -> Any:
    saved = dict(REGISTRY)
    REGISTRY.clear()
    yield
    REGISTRY.clear()
    REGISTRY.update(saved)


def _bind(spec_name: str, model: type[BaseModel]) -> Any:
    """Bind a tool with a dummy handler and return its FastMCP Tool object."""
    def fake_handler(args: BaseModel, client: Any) -> dict[str, Any]:
        return {"echoed": args.model_dump()}

    spec = ToolSpec(
        name=spec_name,
        description="sample",
        input_model=model,
        handler=fake_handler,
    )
    mcp = FastMCP("test")
    _bind_tool(mcp, spec_name, spec, client=None)
    tool = mcp._tool_manager.get_tool(spec_name)
    assert tool is not None, f"tool {spec_name!r} not registered"
    return tool


class TestSchemaIntrospection:
    """Schema published to MCP clients must list the input model's fields."""

    def test_schema_does_not_collapse_to_kwargs(self) -> None:
        tool = _bind("sample", SampleInput)
        props = tool.parameters["properties"]
        assert "kwargs" not in props, (
            f"schema collapsed to generic kwargs: {tool.parameters!r}"
        )

    def test_schema_lists_required_fields(self) -> None:
        tool = _bind("sample", SampleInput)
        props = tool.parameters["properties"]
        assert "user_id" in props
        assert "type" in props
        assert "mode" in props
        assert "limit" in props

    def test_required_set_matches_pydantic_required(self) -> None:
        tool = _bind("sample", SampleInput)
        required = set(tool.parameters.get("required", []))
        assert required == {"user_id", "type"}

    def test_empty_model_has_no_properties(self) -> None:
        tool = _bind("noargs", EmptyInput)
        props = tool.parameters.get("properties", {})
        assert "kwargs" not in props
        assert props == {} or all(k != "kwargs" for k in props)

    def test_default_factory_field_is_not_required(self) -> None:
        tool = _bind("factory", SampleInputWithFactory)
        required = set(tool.parameters.get("required", []))
        assert "name" in required
        assert "tags" not in required


class TestRuntimeBehavior:
    """The wrapper must still validate input through the pydantic model."""

    def test_valid_input_reaches_handler(self) -> None:
        tool = _bind("sample", SampleInput)
        result = tool.fn(user_id=42, type="recent", mode="osu", limit=5)
        assert result == {
            "echoed": {"user_id": 42, "type": "recent", "mode": "osu", "limit": 5}
        }

    def test_optional_field_uses_default(self) -> None:
        tool = _bind("sample", SampleInput)
        result = tool.fn(user_id=1, type="best")
        assert result["echoed"]["mode"] == "osu"
        assert result["echoed"]["limit"] == 10

    def test_invalid_input_raises_osu_validation_error(self) -> None:
        tool = _bind("sample", SampleInput)
        with pytest.raises(OsuValidationError) as exc:
            tool.fn(user_id=-1, type="recent", mode="osu")
        assert exc.value.field == "user_id"
