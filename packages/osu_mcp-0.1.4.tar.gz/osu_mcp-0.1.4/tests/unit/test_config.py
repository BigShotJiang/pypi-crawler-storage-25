"""Tests for osu_mcp.config — credential loading from env and TOML."""
from pathlib import Path

import pytest

from osu_mcp.config import load_config
from osu_mcp.errors import ConfigError


class TestEnvVars:
    def test_loads_from_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("OSU_CLIENT_ID", "12345")
        monkeypatch.setenv("OSU_CLIENT_SECRET", "secret-xyz")
        cfg = load_config()
        assert cfg.client_id == 12345
        assert cfg.client_secret == "secret-xyz"

    def test_env_id_must_be_int(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("OSU_CLIENT_ID", "not-a-number")
        monkeypatch.setenv("OSU_CLIENT_SECRET", "x")
        with pytest.raises(ConfigError, match="OSU_CLIENT_ID must be an integer"):
            load_config()


class TestTomlFallback:
    def test_loads_from_toml(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("OSU_CLIENT_ID", raising=False)
        monkeypatch.delenv("OSU_CLIENT_SECRET", raising=False)
        toml_dir = tmp_path / "osu-mcp"
        toml_dir.mkdir()
        toml_path = toml_dir / "config.toml"
        toml_path.write_text('client_id = 999\nclient_secret = "from-toml"\n', encoding="utf-8")
        cfg = load_config(config_dir=tmp_path)
        assert cfg.client_id == 999
        assert cfg.client_secret == "from-toml"

    def test_env_overrides_toml(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("OSU_CLIENT_ID", "1")
        monkeypatch.setenv("OSU_CLIENT_SECRET", "env")
        (tmp_path / "osu-mcp").mkdir()
        (tmp_path / "osu-mcp" / "config.toml").write_text(
            'client_id = 999\nclient_secret = "toml"\n', encoding="utf-8"
        )
        cfg = load_config(config_dir=tmp_path)
        assert cfg.client_id == 1
        assert cfg.client_secret == "env"


class TestMissingConfig:
    def test_raises_config_error_with_setup_instructions(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.delenv("OSU_CLIENT_ID", raising=False)
        monkeypatch.delenv("OSU_CLIENT_SECRET", raising=False)
        with pytest.raises(ConfigError) as excinfo:
            load_config(config_dir=tmp_path)
        msg = str(excinfo.value)
        assert "OSU_CLIENT_ID" in msg
        assert "osu.ppy.sh/home/account/edit" in msg
