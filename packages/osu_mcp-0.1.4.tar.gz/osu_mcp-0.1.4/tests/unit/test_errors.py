"""Tests for osu_mcp.errors — typed exception hierarchy and MCP code mapping."""
from typing import Any
from unittest.mock import MagicMock

import pytest

from osu_mcp.errors import (
    ApiError,
    AuthError,
    ConfigError,
    NetworkError,
    NotFoundError,
    OsuMcpError,
    RateLimitError,
    ValidationError,
    to_mcp_error,
)
from osu_mcp.errors import ValidationError as OurValidationError
from osu_mcp.models import GetUserSummaryInput
from osu_mcp.server import _bind_tool
from osu_mcp.tools import ToolSpec


class TestExceptionHierarchy:
    def test_all_exceptions_inherit_from_base(self):
        for exc_cls in (
            ConfigError, AuthError, RateLimitError, NotFoundError,
            ValidationError, ApiError, NetworkError,
        ):
            assert issubclass(exc_cls, OsuMcpError)

    def test_base_is_exception(self):
        assert issubclass(OsuMcpError, Exception)


class TestErrorPayloads:
    def test_rate_limit_carries_retry_after(self):
        err = RateLimitError("hit limit", retry_after_seconds=42)
        assert err.retry_after_seconds == 42

    def test_not_found_carries_resource_and_params(self):
        err = NotFoundError("user not found", resource="user", params={"id": 999})
        assert err.resource == "user"
        assert err.params == {"id": 999}

    def test_validation_carries_field_and_message(self):
        err = ValidationError("bad input", field="user_id", reason="must be int")
        assert err.field == "user_id"
        assert err.reason == "must be int"


class TestMcpCodeMapping:
    @pytest.mark.parametrize(
        "exc,expected_code",
        [
            (ConfigError("x"), -32000),
            (AuthError("x"), -32001),
            (RateLimitError("x", retry_after_seconds=1), -32002),
            (NotFoundError("x", resource="r", params={}), -32003),
            (ValidationError("x", field="f", reason="r"), -32004),
            (ApiError("x"), -32005),
            (NetworkError("x"), -32006),
        ],
    )
    def test_each_error_maps_to_correct_mcp_code(self, exc, expected_code):
        mcp_err = to_mcp_error(exc)
        assert mcp_err["code"] == expected_code

    def test_unknown_exception_maps_to_generic_server_error(self):
        mcp_err = to_mcp_error(RuntimeError("unexpected"))
        assert mcp_err["code"] == -32099
        assert "unexpected" in mcp_err["message"]

    def test_rate_limit_includes_retry_after_in_data(self):
        mcp_err = to_mcp_error(RateLimitError("limit", retry_after_seconds=30))
        assert mcp_err["data"]["retry_after_seconds"] == 30


class TestServerWrapperErrorTranslation:
    def test_pydantic_error_becomes_validation_error(self) -> None:
        """Server wrapper must translate pydantic validation failures into
        our typed ValidationError so the MCP code mapping is correct."""
        captured: dict[str, Any] = {}

        class FakeMcp:
            def tool(self, **kwargs: Any) -> Any:
                def deco(fn: Any) -> Any:
                    captured["wrapper"] = fn
                    return fn
                return deco

        spec = ToolSpec(
            name="x",
            description="d",
            input_model=GetUserSummaryInput,
            handler=lambda args, client: {},
        )
        _bind_tool(FakeMcp(), "x", spec, MagicMock())
        wrapper = captured["wrapper"]

        with pytest.raises(OurValidationError) as ei:
            wrapper()  # missing required field
        assert ei.value.field
