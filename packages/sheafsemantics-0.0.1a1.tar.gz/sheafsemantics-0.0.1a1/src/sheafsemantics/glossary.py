from __future__ import annotations

from dataclasses import dataclass
import re

_NON_WORD = re.compile(r"[^a-z0-9]+")


@dataclass(frozen=True)
class Meaning:
    term: str
    definition: str
    aliases: tuple[str, ...] = ()


def canonical_term(text: str) -> str:
    return _NON_WORD.sub("-", text.strip().lower()).strip("-")


def build_index(meanings: list[Meaning]) -> dict[str, Meaning]:
    index: dict[str, Meaning] = {}
    for meaning in meanings:
        key = canonical_term(meaning.term)
        index[key] = meaning
        for alias in meaning.aliases:
            index[canonical_term(alias)] = meaning
    return index


def resolve_alias(meanings: list[Meaning], alias: str) -> Meaning | None:
    return build_index(meanings).get(canonical_term(alias))

