from .glossary import Meaning, build_index, canonical_term, resolve_alias
from .info import project_info

__all__ = ["Meaning", "build_index", "canonical_term", "project_info", "resolve_alias"]
__version__ = "0.0.1a1"

