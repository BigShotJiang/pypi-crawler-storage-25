def project_info() -> dict[str, str]:
    return {
        "name": "sheafsemantics",
        "stage": "bootstrap",
        "homepage": "https://sheaflab.com",
        "repository": "https://github.com/SheafLab/sheafsemantics-python",
    }

