import unittest

from sheafsemantics import Meaning, build_index, canonical_term, resolve_alias


class GlossaryTests(unittest.TestCase):
    def setUp(self) -> None:
        self.meanings = [
            Meaning("Boundary Locality", "Constraint on local boundaries.", ("local-boundary",)),
            Meaning("Receipt", "Traceable execution artifact.", ("trace-receipt",)),
        ]

    def test_canonical_term(self) -> None:
        self.assertEqual(canonical_term("Boundary Locality"), "boundary-locality")

    def test_build_index(self) -> None:
        index = build_index(self.meanings)
        self.assertIn("trace-receipt", index)

    def test_resolve_alias(self) -> None:
        self.assertEqual(resolve_alias(self.meanings, "local-boundary").term, "Boundary Locality")

