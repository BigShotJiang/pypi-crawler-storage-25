# sheafsemantics

`sheafsemantics` is the official Python package namespace for lightweight
semantic glossary helpers used by the SheafLab project.

This initial public release defines a compact object-language surface:
canonical term normalization, alias resolution, and glossary indexing.

