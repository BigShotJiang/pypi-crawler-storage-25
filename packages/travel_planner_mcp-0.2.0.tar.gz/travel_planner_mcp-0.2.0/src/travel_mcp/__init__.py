"""travel_mcp - Travel MCP server package."""

__version__ = "0.2.0"
