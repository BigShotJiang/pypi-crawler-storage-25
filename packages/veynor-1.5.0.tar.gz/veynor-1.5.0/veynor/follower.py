"""
veynor follow — whale-following daemon for Polymarket and Kalshi.

Polls the Veynor whale feed on an interval, detects new large trades,
and mirrors them on your connected exchange accounts.

Architecture:
  1. Poll /v1/whale-trades every --interval seconds
  2. Fingerprint each trade — skip if already seen
  3. Filter by min_notional, category, side
  4. Polymarket: look up the market to get token_id + neg_risk flag (avoids
     the "invalid signature" bug — neg_risk markets need a different exchange
     contract address for EIP-712 signing)
  5. Kalshi: extract ticker from market URL, map side (auto-detected via env)
  6. Execute market_buy via the appropriate trader
  7. Enforce daily spend cap — hard stop if exceeded

Deduplication key: (platform, market_name, side, notional)
Persisted to ~/.veynor_seen_trades.json so restarts don't re-fire.

Kalshi setup:
  export KALSHI_API_KEY_ID=<uuid>
  export KALSHI_PRIVATE_KEY_PATH=/path/to/key.pem
  OR export KALSHI_PRIVATE_KEY="-----BEGIN RSA PRIVATE KEY-----\\n..."

Usage:
    veynor follow --amount 2 --min-notional 15000
    veynor follow --amount 5 --category Politics --dry-run
    veynor follow --pct 2 --max-daily 50
    veynor follow --venues polymarket kalshi --amount 3
"""

from __future__ import annotations

import json
import os
import sys
import time
import hashlib
import uuid
from datetime import datetime, date
from pathlib import Path
from typing import Optional

# ── Seen-trade store ──────────────────────────────────────────────────────────

SEEN_PATH      = Path.home() / ".veynor_seen_trades.json"
POSITIONS_PATH = Path.home() / ".veynor_positions.json"


def _load_seen() -> set[str]:
    try:
        data = json.loads(SEEN_PATH.read_text())
        return set(data.get("fingerprints", []))
    except Exception:
        return set()


def _save_seen(seen: set[str]) -> None:
    try:
        # Keep only the last 5000 fingerprints to avoid unbounded growth
        trimmed = list(seen)[-5000:]
        SEEN_PATH.write_text(json.dumps({"fingerprints": trimmed}))
    except Exception:
        pass


def _fingerprint(trade: dict) -> str:
    # Stable fields: platform + market + side + notional (rounded to dollar).
    # Timestamp changes each scanner cycle (re-fetch updates it).
    # Price can shift slightly. Notional is the actual trade size — stable.
    # Two different trades on the same market will have different notionals.
    key = "|".join([
        str(trade.get("platform", "")),
        str(trade.get("market", "")),
        str(trade.get("side", "")),
        str(round(float(trade.get("notional", 0)))),
    ])
    return hashlib.md5(key.encode()).hexdigest()


# ── Daily spend tracker ───────────────────────────────────────────────────────

class DailySpend:
    """
    Simple in-memory daily spend tracker.
    Resets automatically when the calendar date changes.
    """
    def __init__(self, max_daily: float):
        self.max_daily  = max_daily
        self._date      = date.today()
        self._spent     = 0.0

    def _check_rollover(self) -> None:
        if date.today() != self._date:
            self._date  = date.today()
            self._spent = 0.0

    def can_spend(self, amount: float) -> bool:
        self._check_rollover()
        if self.max_daily <= 0:
            return True  # no cap
        return self._spent + amount <= self.max_daily

    def record(self, amount: float) -> None:
        self._check_rollover()
        self._spent += amount

    @property
    def spent(self) -> float:
        self._check_rollover()
        return self._spent

    @property
    def remaining(self) -> float:
        self._check_rollover()
        if self.max_daily <= 0:
            return float("inf")
        return max(0.0, self.max_daily - self._spent)


# ── Position store ───────────────────────────────────────────────────────────

class PositionStore:
    """
    Persistent store of open and closed positions.
    Saved to ~/.veynor_positions.json after every mutation.

    Position schema:
        id              str   UUID
        venue           str   "kalshi" | "polymarket"
        market          str   human-readable market name
        ticker          str   Kalshi ticker  (Kalshi only)
        token_id        str   Polymarket token_id  (Polymarket only)
        neg_risk        bool  Polymarket neg_risk flag
        side            str   "YES" | "NO"
        contracts       int   number of contracts  (Kalshi)
        amount_usd      float dollar amount placed  (Polymarket)
        entry_price_cents float  price at entry in cents (0-100)
        entry_time      str   ISO timestamp
        order_id        str   exchange order ID
        status          str   "open" | "closed"
        exit_price_cents float  price at exit in cents (set on close)
        exit_time       str   ISO timestamp (set on close)
        pnl_usd         float realized P&L in USD (set on close)
        exit_reason     str   "take-profit" | "stop-loss" | "time-limit" | "manual"
    """

    def __init__(self):
        self.positions: list[dict] = self._load()

    def _load(self) -> list:
        try:
            data = json.loads(POSITIONS_PATH.read_text())
            return data.get("positions", [])
        except Exception:
            return []

    def save(self) -> None:
        try:
            POSITIONS_PATH.write_text(
                json.dumps({"positions": self.positions}, indent=2)
            )
        except Exception:
            pass

    def add(self, position: dict) -> None:
        self.positions.append(position)
        self.save()

    def open_positions(self) -> list:
        return [p for p in self.positions if p.get("status") == "open"]

    def close(
        self,
        position_id: str,
        exit_price_cents: float,
        pnl_usd: float,
        exit_reason: str = "manual",
    ) -> None:
        for p in self.positions:
            if p["id"] == position_id:
                p["status"]           = "closed"
                p["exit_price_cents"] = round(exit_price_cents, 2)
                p["exit_time"]        = datetime.now().isoformat()
                p["pnl_usd"]          = round(pnl_usd, 4)
                p["exit_reason"]      = exit_reason
                break
        self.save()

    def summary(self) -> dict:
        """Return aggregate stats across all positions."""
        open_pos   = self.open_positions()
        closed     = [p for p in self.positions if p.get("status") == "closed"]
        net_pnl    = sum(p.get("pnl_usd", 0) for p in closed)
        wins       = [p for p in closed if (p.get("pnl_usd") or 0) > 0]
        return {
            "open":     len(open_pos),
            "closed":   len(closed),
            "win_rate": round(len(wins) / len(closed) * 100, 1) if closed else 0.0,
            "net_pnl":  round(net_pnl, 4),
        }


def _make_position(
    venue: str,
    market: str,
    side: str,
    entry_price_cents: float,
    order_id: str,
    contracts: int = 0,
    amount_usd: float = 0.0,
    ticker: str = "",
    token_id: str = "",
    neg_risk: bool = False,
) -> dict:
    return {
        "id":                str(uuid.uuid4()),
        "venue":             venue,
        "market":            market,
        "ticker":            ticker,
        "token_id":          token_id,
        "neg_risk":          neg_risk,
        "side":              side,
        "contracts":         contracts,
        "amount_usd":        round(amount_usd, 4),
        "entry_price_cents": round(entry_price_cents, 2),
        "entry_time":        datetime.now().isoformat(),
        "order_id":          order_id,
        "status":            "open",
        "exit_price_cents":  None,
        "exit_time":         None,
        "pnl_usd":           None,
        "exit_reason":       None,
    }


def _calc_pnl(pos: dict, exit_price_cents: float) -> float:
    """Compute realized P&L in USD given an exit price."""
    entry = pos.get("entry_price_cents", 50)
    move  = exit_price_cents - entry
    if pos["venue"] == "kalshi":
        contracts = pos.get("contracts", 1)
        return round(move * contracts / 100, 4)
    else:
        entry_frac   = entry / 100
        amount_usd   = pos.get("amount_usd", 0)
        shares       = amount_usd / entry_frac if entry_frac > 0 else 0
        return round((exit_price_cents / 100 - entry_frac) * shares, 4)


def _check_exits(
    positions:          "PositionStore",
    kalshi_trader,
    poly_trader,
    take_profit_cents:  Optional[float],
    stop_loss_cents:    Optional[float],
    max_hold_hours:     Optional[float],
    dry_run:            bool,
    echo,
    verbose:            bool,
    webhook_url:        Optional[str] = None,
) -> None:
    """
    Check all open positions for exit conditions and execute closes.
    Runs once per poll cycle before fetching new trades.
    """
    open_pos = positions.open_positions()
    if not open_pos:
        return

    now = datetime.now()

    for pos in open_pos:
        venue          = pos["venue"]
        pos_id         = pos["id"]
        side           = pos["side"]
        entry_price    = pos.get("entry_price_cents", 50)
        entry_time     = datetime.fromisoformat(pos["entry_time"])
        age_hours      = (now - entry_time).total_seconds() / 3600
        market_label   = pos.get("market", "")[:40]

        time_exit      = bool(max_hold_hours and age_hours >= max_hold_hours)
        current_cents  = None
        should_exit    = False
        exit_reason    = ""

        # ── Kalshi: get live price ────────────────────────────────────────────
        if venue == "kalshi" and kalshi_trader:
            try:
                ticker        = pos["ticker"]
                current_cents = float(kalshi_trader._best_price(ticker, side))
                price_move    = current_cents - entry_price

                if take_profit_cents and price_move >= take_profit_cents:
                    should_exit = True
                    exit_reason = f"take-profit (+{price_move:.0f}c)"
                elif stop_loss_cents and price_move <= -stop_loss_cents:
                    should_exit = True
                    exit_reason = f"stop-loss ({price_move:.0f}c)"
                elif time_exit:
                    should_exit = True
                    exit_reason = f"time-limit ({age_hours:.1f}h)"
            except Exception as e:
                if verbose:
                    echo(f"  [{_now()}] Price fetch failed for {pos_id[:8]}: {e}")
                if time_exit:
                    should_exit = True
                    exit_reason = f"time-limit ({age_hours:.1f}h)"
                    current_cents = entry_price  # fallback for P&L

        # ── Polymarket: time-based exit only (price via current_cents=None) ───
        elif venue == "polymarket" and poly_trader:
            if time_exit:
                should_exit   = True
                exit_reason   = f"time-limit ({age_hours:.1f}h)"
                current_cents = entry_price  # conservative: assume flat

        if not should_exit:
            if verbose and current_cents is not None:
                move = current_cents - entry_price
                echo(
                    f"  [{_now()}] Position {pos_id[:8]} | {side} {market_label}"
                    f" | entry {entry_price:.0f}c now {current_cents:.0f}c ({move:+.0f}c)"
                    f" | {age_hours:.1f}h"
                )
            continue

        # ── Execute exit ──────────────────────────────────────────────────────
        exit_price = current_cents if current_cents is not None else entry_price
        pnl        = _calc_pnl(pos, exit_price)
        contracts  = pos.get("contracts", 1)

        echo(
            f"  [{_now()}] EXIT [{exit_reason}] {side} '{market_label}'"
            f" | entry {entry_price:.0f}c exit {exit_price:.0f}c"
            f" | P&L: ${pnl:+.4f}"
        )

        if dry_run:
            echo(f"  [{_now()}] DRY RUN -- would close {contracts} contracts @ {exit_price:.0f}c")
            positions.close(pos_id, exit_price, pnl, exit_reason)
            continue

        try:
            if venue == "kalshi" and kalshi_trader:
                ticker      = pos["ticker"]
                sell_price  = max(1, min(99, int(exit_price)))
                result      = kalshi_trader._place_order(
                    ticker, "sell", contracts, sell_price, side=side.lower()
                )
                positions.close(pos_id, exit_price, pnl, exit_reason)
                msg = (
                    f"Veynor exited {side} '{market_label}' ({venue}) "
                    f"— {exit_reason} | entry {entry_price:.0f}c exit {exit_price:.0f}c "
                    f"| P&L: ${pnl:+.4f}"
                )
                echo(f"  [{_now()}] Kalshi sell placed: {result.get('order_id','?')} | P&L: ${pnl:+.4f}")
                _notify(webhook_url, "trade_exited", msg, {
                    "venue": venue, "market": market_label, "side": side,
                    "entry_price_cents": entry_price, "exit_price_cents": exit_price,
                    "contracts": contracts, "pnl_usd": pnl, "exit_reason": exit_reason,
                })
            elif venue == "polymarket" and poly_trader:
                token_id = pos.get("token_id", "")
                neg_risk = pos.get("neg_risk", False)
                if token_id:
                    result   = poly_trader.market_sell(token_id, contracts, neg_risk=neg_risk)
                    positions.close(pos_id, exit_price, pnl, exit_reason)
                    msg = (
                        f"Veynor exited {side} '{market_label}' ({venue}) "
                        f"— {exit_reason} | P&L: ${pnl:+.4f}"
                    )
                    echo(f"  [{_now()}] Polymarket sell placed: {result.get('order_id','?')} | P&L: ${pnl:+.4f}")
                    _notify(webhook_url, "trade_exited", msg, {
                        "venue": venue, "market": market_label, "side": side,
                        "entry_price_cents": entry_price, "exit_price_cents": exit_price,
                        "contracts": contracts, "pnl_usd": pnl, "exit_reason": exit_reason,
                    })
                else:
                    echo(f"  [{_now()}] No token_id for position {pos_id[:8]} — cannot exit.")
        except Exception as e:
            echo(f"  [{_now()}] Exit order failed for {pos_id[:8]}: {e}")
            _notify(webhook_url, "error", f"Veynor exit failed for '{market_label}': {e}", {
                "venue": venue, "market": market_label, "error": str(e),
            })


# ── Market lookup ─────────────────────────────────────────────────────────────

def _lookup_polymarket_token(
    client,
    market_name: str,
    side: str,
) -> tuple[Optional[str], bool]:
    """
    Search for a Polymarket market by name, return (token_id, neg_risk).
    side: "YES" or "NO" — determines which token_id to return.
    Returns (None, False) if not found.
    """
    try:
        results = client.search(market_name, venue="polymarket", limit=5)
        markets = results.get("polymarket", [])
        if not markets:
            return None, False

        best = markets[0]
        condition_id = best.get("condition_id")
        if not condition_id:
            return None, False

        details = client.market("polymarket", condition_id)
        m = details.get("market", {})

        neg_risk = bool(m.get("neg_risk", False))
        token_id = m.get("no_token_id") if side.upper() == "NO" else m.get("yes_token_id")
        return token_id, neg_risk
    except Exception:
        return None, False


def _lookup_kalshi_ticker(client, market_name: str) -> Optional[str]:
    """
    Search for a Kalshi market by name and return its ticker.
    Uses the Veynor search API — more reliable than URL extraction.
    Kalshi market objects use 'id' as the ticker field.
    """
    try:
        results = client.search(market_name, venue="kalshi", limit=5)
        markets = results.get("kalshi", [])
        if not markets:
            return None
        best = markets[0]
        ticker = (
            best.get("ticker")
            or best.get("id")
            or best.get("market_id")
            or best.get("condition_id")
        )
        return str(ticker).upper() if ticker else None
    except Exception:
        return None


def _kalshi_ticker_from_url(url: str) -> Optional[str]:
    """
    Fallback: extract Kalshi ticker from a market URL.
    Only reliable when the URL goes to the specific market contract level.
    """
    try:
        slug = url.rstrip("/").split("/")[-1]
        candidate = slug.upper()
        # Reject if it looks like a slug (contains words, no date pattern)
        # Valid tickers look like KXIPLGAME-26MAY18SRHCSK, not 'texas-republican-senate'
        if candidate and "-" in candidate and any(c.isdigit() for c in candidate):
            return candidate
        return None
    except Exception:
        return None


def _kalshi_side_from_feed(side: str) -> str:
    """
    Map whale feed side to Kalshi YES/NO.
    Feed shows "YES", "NO", "TEAM NAME", "NO TEAM NAME".
    "NO <something>" → NO side.
    Anything else (team name, YES) → YES side.
    """
    s = side.strip().upper()
    if s == "NO" or s.startswith("NO "):
        return "NO"
    return "YES"


# ── Main follower loop ────────────────────────────────────────────────────────

def run_follower(
    client,
    min_notional:       float = 10_000,
    amount:             Optional[float] = None,
    pct:                Optional[float] = None,
    category:           str = "All",
    max_daily:          float = 0.0,
    interval:           int = 30,
    dry_run:            bool = False,
    sides:              str = "YES",
    venues:             Optional[list] = None,
    kalshi_count:       Optional[int] = None,
    take_profit:        Optional[float] = None,
    stop_loss:          Optional[float] = None,
    max_hold_hours:     Optional[float] = None,
    webhook_url:        Optional[str] = None,
    max_open_positions: Optional[int] = None,    # skip new trades when >= N positions open
    max_position_size:  Optional[float] = None,  # hard cap on any single order in USD
    verbose:            bool = False,
    echo = print,
) -> None:
    """
    Core follower loop. Call from the CLI command — separated here so it
    can also be imported and run programmatically (e.g. in a script or agent).

    Kalshi is included automatically when KALSHI_API_KEY_ID is set.
    Pass venues=["polymarket"] to disable Kalshi even if credentials exist.
    """
    # ── Determine which venues to activate ───────────────────────────────────
    if venues is None:
        # Auto-detect: always include polymarket; add Kalshi if credentials exist
        kalshi_key_id = os.environ.get("KALSHI_API_KEY_ID") or os.environ.get("KALSHI_KEY_ID")
        active_venues = ["polymarket"]
        if kalshi_key_id:
            active_venues.append("kalshi")
    else:
        active_venues = [v.lower() for v in venues]

    # ── Init traders ──────────────────────────────────────────────────────────
    poly_trader   = None
    kalshi_trader = None

    if "polymarket" in active_venues:
        try:
            from .polymarket_trader import PolymarketTrader, PolymarketError
        except ImportError:
            echo("pip install veynor[trade] required for Polymarket following.", file=sys.stderr)
            sys.exit(1)
        poly_trader = PolymarketTrader()

    if "kalshi" in active_venues:
        try:
            from .kalshi_trader import KalshiTrader, KalshiError
            kalshi_trader = KalshiTrader()
        except Exception as e:
            echo(f"  Warning: could not init Kalshi trader: {e}. Kalshi trades will be skipped.")
            active_venues = [v for v in active_venues if v != "kalshi"]

    if not active_venues:
        echo("No venues active. Nothing to follow.", file=sys.stderr)
        sys.exit(1)

    daily_spend = DailySpend(max_daily)
    seen        = _load_seen()
    positions   = PositionStore()

    echo(f"\n  Veynor Whale Follower {'(DRY RUN) ' if dry_run else ''}-- starting up")
    echo(f"  Venues:        {', '.join(active_venues)}")
    echo(f"  Min notional:  ${min_notional:,.0f}")
    echo(f"  Sides:         {sides}")
    echo(f"  Category:      {category}")
    echo(f"  Poll interval: {interval}s")
    if max_daily > 0:
        echo(f"  Daily cap:     ${max_daily:.2f}")
    if take_profit:
        echo(f"  Take-profit:   +{take_profit:.0f}c")
    if stop_loss:
        echo(f"  Stop-loss:     -{stop_loss:.0f}c")
    if max_hold_hours:
        echo(f"  Max hold:      {max_hold_hours:.0f}h")
    if max_open_positions:
        echo(f"  Max positions: {max_open_positions}")
    if max_position_size:
        echo(f"  Max order:     ${max_position_size:.2f}")
    if webhook_url:
        domain = webhook_url.split("/")[2] if "/" in webhook_url else webhook_url
        echo(f"  Webhook:       {domain}")
    open_count = len(positions.open_positions())
    if open_count:
        echo(f"  Open positions: {open_count} (loaded from previous session)")
    echo()

    _notify(webhook_url, "follower_started", "Veynor whale follower started.", {
        "venues": active_venues, "min_notional": min_notional,
    })

    def _fetch_trades(limit: int = 60) -> list:
        """Fetch whale trades across all active venues."""
        all_trades = []
        for venue in active_venues:
            try:
                data = client.whales(
                    venue=venue,
                    min_notional=min_notional,
                    limit=limit,
                    category=category if category != "All" else None,
                )
                all_trades.extend(data.get("trades", []))
            except Exception as e:
                if verbose:
                    echo(f"  [{_now()}] Feed error ({venue}): {e}")
        return all_trades

    # Seed seen on first boot — don't act on existing feed
    try:
        seed_trades = _fetch_trades(limit=60)
        for t in seed_trades:
            seen.add(_fingerprint(t))
        _save_seen(seen)
        echo(f"  Seeded {len(seed_trades)} existing trades as seen. Watching for new flow...\n")
    except Exception as e:
        echo(f"  Warning: could not seed seen trades: {e}")

    while True:
        try:
            time.sleep(interval)

            # ── Check exit conditions on open positions ────────────────────────
            any_exit_rule = take_profit or stop_loss or max_hold_hours
            if any_exit_rule and positions.open_positions():
                _check_exits(
                    positions         = positions,
                    kalshi_trader     = kalshi_trader,
                    poly_trader       = poly_trader,
                    take_profit_cents = take_profit,
                    stop_loss_cents   = stop_loss,
                    max_hold_hours    = max_hold_hours,
                    dry_run           = dry_run,
                    echo              = echo,
                    verbose           = verbose,
                    webhook_url       = webhook_url,
                )

            # ── Fetch latest whale feed ───────────────────────────────────────
            trades = _fetch_trades(limit=60)
            if not trades and verbose:
                echo(f"  [{_now()}] Feed returned no trades.")

            # ── Find new trades ───────────────────────────────────────────────
            new_trades = []
            for t in trades:
                fp = _fingerprint(t)
                if fp not in seen:
                    new_trades.append((t, fp))

            if not new_trades:
                if verbose:
                    echo(f"  [{_now()}] No new trades. ({len(trades)} in feed)")
                continue

            echo(f"  [{_now()}] {len(new_trades)} new whale trade(s) detected")

            for trade, fp in new_trades:
                seen.add(fp)

                platform     = str(trade.get("platform", trade.get("venue", "polymarket"))).lower()
                market       = str(trade.get("market", ""))
                raw_side     = str(trade.get("side", "YES"))   # preserve for team matching
                side         = raw_side.upper()
                notional     = float(trade.get("notional", 0))
                price        = float(trade.get("price", 0))

                # Skip venues we're not following
                if platform not in active_venues:
                    continue

                # Normalise side for Kalshi — feed uses team names like "NEW YORK KNICKS"
                if platform == "kalshi":
                    side = _kalshi_side_from_feed(side)

                if sides != "ALL" and side != sides.upper():
                    echo(f"  [{_now()}] Skip {side} trade on '{market[:40]}' ({platform}, side filter)")
                    continue

                echo(f"  [{_now()}] New whale ({platform}): {side} ${notional:,.0f} on '{market[:50]}' @ {round(price*100)}c")
                if verbose and platform == "kalshi":
                    echo(f"  [{_now()}] Raw trade fields: { {k: v for k, v in trade.items()} }")

                # ── Resolve size ──────────────────────────────────────────────
                try:
                    if pct is not None:
                        if platform == "kalshi" and kalshi_trader:
                            bal  = kalshi_trader.get_balance()
                            cash = bal.get("cash_usd", 0)
                        else:
                            bal  = poly_trader.get_balance()
                            cash = bal.get("cash_usdc", 0)
                        trade_amount = round(cash * pct / 100, 2)
                    else:
                        trade_amount = amount or 2.0
                except Exception as e:
                    echo(f"  [{_now()}] Could not fetch balance: {e} -- using fixed $2")
                    trade_amount = 2.0

                # ── Risk controls ─────────────────────────────────────────────
                if max_open_positions is not None:
                    n_open = len(positions.open_positions())
                    if n_open >= max_open_positions:
                        echo(
                            f"  [{_now()}] Max open positions reached ({n_open}/{max_open_positions})."
                            f" Skipping '{market[:40]}'."
                        )
                        continue

                if max_position_size is not None and trade_amount > max_position_size:
                    echo(
                        f"  [{_now()}] Order size ${trade_amount:.2f} exceeds --max-position-size"
                        f" ${max_position_size:.2f}. Capping."
                    )
                    trade_amount = max_position_size

                # ── Daily cap check ───────────────────────────────────────────
                if not daily_spend.can_spend(trade_amount):
                    echo(f"  [{_now()}] Daily cap reached (${daily_spend.spent:.2f} / ${daily_spend.max_daily:.2f}). Skipping.")
                    _notify(webhook_url, "daily_cap_reached",
                        f"Veynor daily cap reached — ${daily_spend.spent:.2f} / ${daily_spend.max_daily:.2f} spent today. No more trades until midnight.",
                        {"spent_usd": daily_spend.spent, "cap_usd": daily_spend.max_daily}
                    )
                    continue

                # ── Execute: Kalshi path ──────────────────────────────────────
                if platform == "kalshi":
                    market_url = str(trade.get("url", ""))
                    echo(f"  [{_now()}] Looking up Kalshi market: '{market[:50]}'...")

                    # Primary: query Kalshi /markets API by series ticker from URL
                    ticker = None
                    if market_url and kalshi_trader:
                        ticker = kalshi_trader.find_ticker_by_slug(market_url, raw_side=raw_side)
                        if verbose:
                            echo(f"  [{_now()}] Series lookup: {ticker or 'no match'}")

                    # Fallback 1: Veynor search
                    if not ticker:
                        ticker = _lookup_kalshi_ticker(client, market)
                        if verbose and not ticker:
                            echo(f"  [{_now()}] Veynor search: no Kalshi result.")

                    # Fallback 2: URL slug (only if it contains a date pattern)
                    if not ticker:
                        ticker = _kalshi_ticker_from_url(market_url) if market_url else None

                    if not ticker:
                        echo(f"  [{_now()}] Could not resolve Kalshi ticker for '{market[:40]}'. Skipping.")
                        continue

                    echo(f"  [{_now()}] Kalshi ticker: {ticker}")

                    if dry_run:
                        if kalshi_count:
                            echo(f"  [{_now()}] DRY RUN -- would buy {kalshi_count} contracts of {side} on {ticker}")
                        else:
                            echo(f"  [{_now()}] DRY RUN -- would buy ${trade_amount:.2f} of {side} on {ticker}")
                        daily_spend.record(trade_amount)
                        continue

                    try:
                        from .kalshi_trader import KalshiError
                        if kalshi_count:
                            # Fixed contract count — bypass dollar sizing entirely
                            price_cents = kalshi_trader._best_price(ticker, side)
                            yes_p = max(1, min(99, 100 - price_cents)) if side == "NO" else max(1, min(99, price_cents))
                            result = kalshi_trader._place_order(ticker, "buy", kalshi_count, yes_p, side=side.lower())
                            trade_amount = round(kalshi_count * price_cents / 100, 2)
                        else:
                            price_cents = kalshi_trader._best_price(ticker, side)
                            result      = kalshi_trader.market_buy(ticker, side=side, amount_usd=trade_amount)
                        status   = result.get("status", "?")
                        order_id = result.get("order_id", "")
                        daily_spend.record(trade_amount)
                        echo(f"  [{_now()}] Kalshi order {status} -- ID: {order_id} | ${trade_amount:.2f} {side} on {ticker}")
                        if daily_spend.max_daily > 0:
                            echo(f"  [{_now()}] Daily spend: ${daily_spend.spent:.2f} / ${daily_spend.max_daily:.2f} (${daily_spend.remaining:.2f} left)")
                        # Record position
                        pos = _make_position(
                            venue             = "kalshi",
                            market            = market,
                            side              = side,
                            entry_price_cents = float(price_cents),
                            order_id          = order_id,
                            contracts         = kalshi_count or max(1, int(trade_amount * 100 / max(price_cents, 1))),
                            amount_usd        = trade_amount,
                            ticker            = ticker,
                        )
                        positions.add(pos)
                        _notify(webhook_url, "trade_entered",
                            f"Veynor entered {side} '{market[:50]}' (Kalshi) "
                            f"— {pos['contracts']} contracts @ {price_cents:.0f}c (${trade_amount:.2f})",
                            {
                                "venue": "kalshi", "market": market, "side": side,
                                "ticker": ticker, "contracts": pos["contracts"],
                                "entry_price_cents": float(price_cents),
                                "amount_usd": trade_amount, "order_id": order_id,
                            }
                        )
                    except Exception as e:
                        echo(f"  [{_now()}] Kalshi order failed: {e}")
                        _notify(webhook_url, "error",
                            f"Veynor Kalshi order failed for '{market[:50]}': {e}",
                            {"venue": "kalshi", "market": market, "error": str(e)}
                        )
                    continue

                # ── Execute: Polymarket path ──────────────────────────────────
                echo(f"  [{_now()}] Looking up Polymarket market...")
                token_id, neg_risk = _lookup_polymarket_token(client, market, side)

                if not token_id:
                    echo(f"  [{_now()}] Could not resolve token_id for '{market[:40]}'. Skipping.")
                    continue

                echo(f"  [{_now()}] token_id: {token_id[:20]}... neg_risk: {neg_risk}")

                if dry_run:
                    echo(f"  [{_now()}] DRY RUN -- would buy ${trade_amount:.2f} of {side} @ ~{round(price*100)}c")
                    daily_spend.record(trade_amount)
                    continue

                try:
                    result   = poly_trader.market_buy(token_id, trade_amount, neg_risk=neg_risk)
                    status   = result.get("status", "?")
                    order_id = result.get("order_id", "")
                    daily_spend.record(trade_amount)
                    echo(f"  [{_now()}] Poly order {status} -- ID: {order_id} | ${trade_amount:.2f} {side}")
                    if daily_spend.max_daily > 0:
                        echo(f"  [{_now()}] Daily spend: ${daily_spend.spent:.2f} / ${daily_spend.max_daily:.2f} (${daily_spend.remaining:.2f} left)")
                    # Record position
                    entry_price_cents = round(price * 100, 2)
                    shares = round(trade_amount / price, 4) if price > 0 else 0
                    pos = _make_position(
                        venue             = "polymarket",
                        market            = market,
                        side              = side,
                        entry_price_cents = entry_price_cents,
                        order_id          = order_id,
                        contracts         = int(shares),
                        amount_usd        = trade_amount,
                        token_id          = token_id,
                        neg_risk          = neg_risk,
                    )
                    positions.add(pos)
                    _notify(webhook_url, "trade_entered",
                        f"Veynor entered {side} '{market[:50]}' (Polymarket) "
                        f"— ${trade_amount:.2f} @ {round(price*100)}c",
                        {
                            "venue": "polymarket", "market": market, "side": side,
                            "entry_price_cents": entry_price_cents,
                            "amount_usd": trade_amount, "order_id": order_id,
                        }
                    )
                except Exception as e:
                    echo(f"  [{_now()}] Poly order failed: {e}")
                    _notify(webhook_url, "error",
                        f"Veynor Polymarket order failed for '{market[:50]}': {e}",
                        {"venue": "polymarket", "market": market, "error": str(e)}
                    )

            _save_seen(seen)

        except KeyboardInterrupt:
            echo(f"\n  Follower stopped. Daily spend: ${daily_spend.spent:.2f}")
            _save_seen(seen)
            break
        except Exception as e:
            echo(f"  [{_now()}] Unexpected error: {e}")
            time.sleep(5)


def _now() -> str:
    return datetime.now().strftime("%H:%M:%S")


# ── Webhook notifications ─────────────────────────────────────────────────────

def _notify(webhook_url: Optional[str], event: str, message: str, data: dict = {}) -> None:
    """
    POST a notification to a webhook URL.

    Works with:
      Slack     — hooks.slack.com  → uses {"text": ...}
      Discord   — discord.com/api/webhooks → uses {"content": ...}
      Generic   — any HTTP endpoint → receives full JSON payload

    Fires and forgets — failures are silently swallowed so a broken webhook
    never interrupts the follower loop.
    """
    if not webhook_url:
        return
    try:
        import requests as _req

        payload: dict = {
            "event":     event,
            "message":   message,
            "timestamp": datetime.now().isoformat(),
            **data,
        }

        # Slack and Discord need their own message field
        if "hooks.slack.com" in webhook_url:
            payload["text"] = message
        elif "discord.com" in webhook_url:
            payload["content"] = message

        _req.post(webhook_url, json=payload, timeout=5)
    except Exception:
        pass  # never let a webhook failure crash the follower
