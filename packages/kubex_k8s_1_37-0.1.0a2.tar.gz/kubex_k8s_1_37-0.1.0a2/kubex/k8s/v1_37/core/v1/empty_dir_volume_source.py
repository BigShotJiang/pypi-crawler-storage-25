from pydantic import Field

from kubex_core.models.base import BaseK8sModel


class EmptyDirVolumeSource(BaseK8sModel):
    """Represents an empty directory for a pod. Empty directory volumes support ownership management and SELinux relabeling."""

    medium: str | None = Field(
        default=None,
        alias="medium",
        description='medium represents what type of storage medium should back this directory. The default is "" which means to use the node\'s default medium. Must be an empty string (default) or Memory. More info: https://kubernetes.io/docs/concepts/storage/volumes#emptydir',
    )
    size_limit: str | None = Field(
        default=None,
        alias="sizeLimit",
        description="sizeLimit is the total amount of local storage required for this EmptyDir volume. The size limit is also applicable for memory medium. The maximum usage on memory medium EmptyDir would be the minimum value between the SizeLimit specified here and the sum of memory limits of all containers in a pod. The default is nil which means that the limit is undefined. More info: https://kubernetes.io/docs/concepts/storage/volumes#emptydir",
    )
