from pydantic import Field

from kubex_core.models.base import BaseK8sModel


class ExpressionWarning(BaseK8sModel):
    """ExpressionWarning is a warning information that targets a specific expression."""

    field_ref: str = Field(
        ...,
        alias="fieldRef",
        description='fieldRef is the path to the field that refers to the expression. For example, the reference to the expression of the first item of validations is "spec.validations[0].expression"',
    )
    warning: str = Field(
        ...,
        alias="warning",
        description="warning contains the content of type checking information in a human-readable form. Each line of the warning contains the type that the expression is checked against, followed by the type check error from the compiler.",
    )
