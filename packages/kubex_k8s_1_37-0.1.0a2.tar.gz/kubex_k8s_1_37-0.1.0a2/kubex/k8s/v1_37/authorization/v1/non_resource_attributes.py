from pydantic import Field

from kubex_core.models.base import BaseK8sModel


class NonResourceAttributes(BaseK8sModel):
    """NonResourceAttributes includes the authorization attributes available for non-resource requests to the Authorizer interface"""

    path: str | None = Field(
        default=None, alias="path", description="path is the URL path of the request"
    )
    verb: str | None = Field(
        default=None, alias="verb", description="verb is the standard HTTP verb"
    )
