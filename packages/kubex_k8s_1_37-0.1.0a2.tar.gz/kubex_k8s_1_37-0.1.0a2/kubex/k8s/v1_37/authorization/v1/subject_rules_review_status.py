from pydantic import Field

from kubex.k8s.v1_37.authorization.v1.non_resource_rule import NonResourceRule
from kubex.k8s.v1_37.authorization.v1.resource_rule import ResourceRule
from kubex_core.models.base import BaseK8sModel


class SubjectRulesReviewStatus(BaseK8sModel):
    """SubjectRulesReviewStatus contains the result of a rules check. This check can be incomplete depending on the set of authorizers the server is configured with and any errors experienced during evaluation. Because authorization rules are additive, if a rule appears in a list it's safe to assume the subject has that permission, even if that list is incomplete."""

    evaluation_error: str | None = Field(
        default=None,
        alias="evaluationError",
        description="evaluationError can appear in combination with Rules. It indicates an error occurred during rule evaluation, such as an authorizer that doesn't support rule evaluation, and that ResourceRules and/or NonResourceRules may be incomplete.",
    )
    incomplete: bool = Field(
        ...,
        alias="incomplete",
        description="incomplete is true when the rules returned by this call are incomplete. This is most commonly encountered when an authorizer, such as an external authorizer, doesn't support rules evaluation.",
    )
    non_resource_rules: list[NonResourceRule] = Field(
        ...,
        alias="nonResourceRules",
        description="nonResourceRules is the list of actions the subject is allowed to perform on non-resources. The list ordering isn't significant, may contain duplicates, and possibly be incomplete.",
    )
    resource_rules: list[ResourceRule] = Field(
        ...,
        alias="resourceRules",
        description="resourceRules is the list of actions the subject is allowed to perform on resources. The list ordering isn't significant, may contain duplicates, and possibly be incomplete.",
    )
