IntOrString = int | str
