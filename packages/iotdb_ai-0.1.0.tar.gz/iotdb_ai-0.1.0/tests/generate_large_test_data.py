"""
Generate large-scale test TsFile files for stress testing and benchmarking.

Creates additional test files beyond the basic set:
4. large_iot.tsfile:   100 devices × 5 fields = 500 series, 10K points each (5M total rows)
5-14. weather_shard_00~09.tsfile: 10 time-sharded files simulating time-partitioned storage
15. multi_tag.tsfile:  2 TAG columns (region + device_type), testing multi-tag path naming
16. no_tag.tsfile:     Table with no TAG columns, pure FIELD-only
17. sparse.tsfile:     Irregular timestamps with large gaps

Run: python tests/generate_large_test_data.py
"""

import os
import time
import numpy as np
import pandas as pd

from tsfile.utils import dataframe_to_tsfile

OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "data")
BASE_TS = 1769443200000  # 2026-01-28 00:00:00 UTC+8


def generate_large_iot(output_path, num_devices=100, points_per_device=10000):
    """
    Table: iot, TAG: device_id, FIELD: (temp, humidity, pressure, voltage, current)
    100 devices × 5 fields × 10K points = 500 series, 5M total rows.
    1-second interval per device.
    """
    np.random.seed(2026)
    field_names = ['temp', 'humidity', 'pressure', 'voltage', 'current']

    all_rows = []
    for dev_idx in range(num_devices):
        device_id = f"dev_{dev_idx:04d}"
        start = BASE_TS + dev_idx * 100  # slight offset per device
        times = start + np.arange(points_per_device, dtype=np.int64) * 1000

        df_dev = pd.DataFrame({
            'time': times,
            'device_id': device_id,
            'temp': np.random.uniform(15, 35, points_per_device).round(2),
            'humidity': np.random.uniform(30, 90, points_per_device).round(2),
            'pressure': np.random.uniform(990, 1030, points_per_device).round(2),
            'voltage': np.random.uniform(3.0, 4.2, points_per_device).round(3),
            'current': np.random.uniform(0.1, 2.5, points_per_device).round(3),
        })
        all_rows.append(df_dev)

    df = pd.concat(all_rows, ignore_index=True)
    dataframe_to_tsfile(df, output_path, table_name="iot", tag_column=["device_id"])
    total_series = num_devices * len(field_names)
    print(f"  Created {output_path}: {len(df)} rows, {total_series} series "
          f"({num_devices} devices × {len(field_names)} fields)")
    return total_series, points_per_device


def generate_weather_shards(output_dir, num_shards=10, points_per_shard=2880):
    """
    10 time-sharded files, each covering one day.
    Table: weather, TAG: location (Beijing/Shanghai/Guangzhou),
    FIELD: (humidity, temperature)
    Each shard: 3 locations × 288 points/day (5-min interval), 1 day per shard.
    10 shards = 10 days.
    Tests: parallel loading of many files + cross-file merge.
    """
    np.random.seed(7777)
    locations = ['Beijing', 'Shanghai', 'Guangzhou']
    paths = []

    points_per_day = 288  # 24h × 12 (every 5 minutes)
    for shard_idx in range(num_shards):
        shard_base = BASE_TS + shard_idx * 24 * 3600 * 1000  # one day per shard
        rows = []
        for loc in locations:
            times = shard_base + np.arange(points_per_day, dtype=np.int64) * 300000
            for t in times:
                rows.append({
                    'time': int(t),
                    'location': loc,
                    'humidity': round(np.random.uniform(30, 95), 2),
                    'temperature': round(np.random.uniform(-10, 40), 2),
                })

        df = pd.DataFrame(rows)
        fname = f"weather_shard_{shard_idx:02d}.tsfile"
        fpath = os.path.join(output_dir, fname)
        dataframe_to_tsfile(df, fpath, table_name="weather", tag_column=["location"])
        paths.append(fpath)
        print(f"  Created {fname}: {len(df)} rows (shard {shard_idx})")

    total_points_per_series = num_shards * points_per_day
    print(f"  Total: {num_shards} shards, {len(locations)} locations × 2 fields = "
          f"{len(locations) * 2} series, {total_points_per_series} points each after merge")
    return paths, locations, total_points_per_series


def generate_multi_tag(output_path):
    """
    Table: equipment, TAG: (region, device_type), FIELD: (reading, status_code)
    Regions: east/west/north, device_types: pump/valve
    6 TAG combinations × 2 fields = 12 series, 5000 points each.
    Tests multi-tag series_path naming: equipment.east.pump.reading
    """
    np.random.seed(3333)
    regions = ['east', 'west', 'north']
    device_types = ['pump', 'valve']

    rows = []
    for region in regions:
        for dtype in device_types:
            times = BASE_TS + np.arange(5000, dtype=np.int64) * 2000
            for t in times:
                rows.append({
                    'time': int(t),
                    'region': region,
                    'device_type': dtype,
                    'reading': round(np.random.uniform(0, 100), 2),
                    'status_code': round(np.random.uniform(0, 10), 1),
                })

    df = pd.DataFrame(rows)
    dataframe_to_tsfile(df, output_path, table_name="equipment",
                        tag_column=["region", "device_type"])
    print(f"  Created {output_path}: {len(df)} rows, 12 series (3 regions × 2 types × 2 fields)")


def generate_no_tag(output_path):
    """
    Table: metrics, no TAG columns, FIELD: (cpu, memory, disk_io)
    Single group, 20000 points, 1-sec interval.
    Tests tables without TAG columns.
    """
    np.random.seed(4444)
    n = 20000
    times = BASE_TS + np.arange(n, dtype=np.int64) * 1000

    df = pd.DataFrame({
        'time': times,
        'cpu': np.random.uniform(0, 100, n).round(2),
        'memory': np.random.uniform(20, 95, n).round(2),
        'disk_io': np.random.uniform(0, 500, n).round(2),
    })
    dataframe_to_tsfile(df, output_path, table_name="metrics")
    print(f"  Created {output_path}: {len(df)} rows, 3 series (no TAG)")


def generate_sparse(output_path):
    """
    Table: events, TAG: source, FIELD: (value, quality)
    source=A: 500 points with random gaps (irregular timestamps)
    source=B: 300 points with different random gaps
    Tests: irregular timestamps, sparse data, gap handling in loc queries.
    """
    np.random.seed(5555)

    # Source A: random gaps between 1s and 60s
    a_gaps = np.random.randint(1000, 60000, size=500)
    a_times = BASE_TS + np.cumsum(a_gaps)

    # Source B: random gaps between 5s and 120s, starting 30s after A
    b_gaps = np.random.randint(5000, 120000, size=300)
    b_times = BASE_TS + 30000 + np.cumsum(b_gaps)

    rows = []
    for t in a_times:
        rows.append({
            'time': int(t),
            'source': 'A',
            'value': round(np.random.normal(50, 15), 2),
            'quality': round(np.random.uniform(0.5, 1.0), 3),
        })
    for t in b_times:
        rows.append({
            'time': int(t),
            'source': 'B',
            'value': round(np.random.normal(75, 20), 2),
            'quality': round(np.random.uniform(0.3, 0.9), 3),
        })

    df = pd.DataFrame(rows)
    dataframe_to_tsfile(df, output_path, table_name="events", tag_column=["source"])
    print(f"  Created {output_path}: {len(df)} rows (A=500 irregular, B=300 irregular)")


if __name__ == "__main__":
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    print("=" * 60)
    print("Generating large-scale test data")
    print("=" * 60)

    t0 = time.time()

    # 1. Large IoT dataset (500 series)
    print("\n[1/5] Large IoT dataset...")
    iot_path = os.path.join(OUTPUT_DIR, "large_iot.tsfile")
    if os.path.exists(iot_path):
        os.remove(iot_path)
    generate_large_iot(iot_path)

    # 2. Time-sharded weather (10 files)
    print("\n[2/5] Time-sharded weather (10 shards)...")
    for i in range(10):
        p = os.path.join(OUTPUT_DIR, f"weather_shard_{i:02d}.tsfile")
        if os.path.exists(p):
            os.remove(p)
    generate_weather_shards(OUTPUT_DIR)

    # 3. Multi-tag
    print("\n[3/5] Multi-tag equipment...")
    mt_path = os.path.join(OUTPUT_DIR, "multi_tag.tsfile")
    if os.path.exists(mt_path):
        os.remove(mt_path)
    generate_multi_tag(mt_path)

    # 4. No-tag
    print("\n[4/5] No-tag metrics...")
    nt_path = os.path.join(OUTPUT_DIR, "no_tag.tsfile")
    if os.path.exists(nt_path):
        os.remove(nt_path)
    generate_no_tag(nt_path)

    # 5. Sparse irregular
    print("\n[5/5] Sparse irregular events...")
    sp_path = os.path.join(OUTPUT_DIR, "sparse.tsfile")
    if os.path.exists(sp_path):
        os.remove(sp_path)
    generate_sparse(sp_path)

    elapsed = time.time() - t0
    print(f"\nAll done in {elapsed:.1f}s. Files in: {OUTPUT_DIR}")
