"""
Benchmark: TsFileDataFrame vs PyArrow Dataset vs HuggingFace Dataset

Three multi-file management frameworks for time-series ML workloads:
  - TsFileDataFrame : time-series native, built-in time index & alignment
  - PyArrow Dataset : general-purpose lazy columnar, predicate pushdown
  - HuggingFace Dataset : ML ecosystem standard, memory-mapped Arrow

Four ML-oriented query scenarios:
  1. Training random sampling  — DataLoader random point access
  2. Training window sampling  — contiguous time window for LSTM/Transformer
  3. Inference time-range      — query by actual timestamp range
  4. Multi-sensor fusion       — time-aligned multi-series (same-device & cross-device)

Each framework uses its best practice; no one is artificially handicapped.

Usage:
    python tests/benchmark_tsfile_vs_hf.py --scales small
    python tests/benchmark_tsfile_vs_hf.py --scales small medium large --plot
    python tests/benchmark_tsfile_vs_hf.py --file-count-scaling --plot
"""

import os
import sys
import gc
import time
import argparse
from dataclasses import dataclass, field
from typing import List, Callable, Dict

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import pyarrow.dataset as pa_ds
from datasets import Dataset, disable_caching, disable_progress_bars

disable_caching()
disable_progress_bars()

_project_root = os.path.join(os.path.dirname(__file__), "..")
sys.path.insert(0, _project_root)
from iotdb_ai.tsfile.dataframe import TsFileDataFrame
from tsfile import (TsFileTableWriter, TableSchema, ColumnSchema,
                    ColumnCategory, TSDataType, Tablet)

# ── Constants ────────────────────────────────────────────────────────────────

BASE_TS = 1769443200000  # 2026-01-28 00:00:00 UTC+8
BENCHMARK_DIR = os.path.join(os.path.dirname(__file__), "benchmark_data_v2")
NUM_SHARDS = 5

SCALE_CONFIGS = {
    "small":  {"num_devices": 5,  "num_fields": 3, "points_per_device": 1_000},
    "medium": {"num_devices": 10, "num_fields": 5, "points_per_device": 10_000},
    "large":  {"num_devices": 50, "num_fields": 5, "points_per_device": 50_000},
}

FILE_COUNT_LIST = [1] + list(range(10, 101, 10))


# ── Measurement ──────────────────────────────────────────────────────────────

@dataclass
class BenchResult:
    name: str
    times: List[float] = field(default_factory=list)

    @property
    def mean(self):
        return float(np.mean(self.times)) if self.times else 0.0

    @property
    def std(self):
        return float(np.std(self.times)) if self.times else 0.0


def measure(func: Callable, warmup: int = 1, iterations: int = 5) -> List[float]:
    """Run func with warmup, return list of elapsed seconds."""
    for _ in range(warmup):
        r = func(); del r; gc.collect()
    times = []
    for _ in range(iterations):
        gc.collect()
        t0 = time.perf_counter()
        r = func()
        t1 = time.perf_counter()
        times.append(t1 - t0)
        del r
    return times


# ── Data Generation ──────────────────────────────────────────────────────────

def _generate_raw_data(cfg):
    """Generate deterministic raw numpy data for a given scale config."""
    np.random.seed(42)
    num_devices = cfg["num_devices"]
    num_fields = cfg["num_fields"]
    ppd = cfg["points_per_device"]
    field_names = [f"f{i}" for i in range(num_fields)]

    all_times, all_data = {}, {}
    for dev_idx in range(num_devices):
        device_id = f"dev_{dev_idx:04d}"
        all_times[device_id] = BASE_TS + np.arange(ppd, dtype=np.int64) * 1000
        all_data[device_id] = {
            fn: np.random.uniform(0, 100, ppd).round(2) for fn in field_names
        }
    return all_times, all_data, field_names


def _write_tsfile(all_times, all_data, field_names, output_path):
    """Write data to a single TsFile via Tablet API."""
    col_schemas = [ColumnSchema("device_id", TSDataType.STRING, ColumnCategory.TAG)]
    for fn in field_names:
        col_schemas.append(ColumnSchema(fn, TSDataType.DOUBLE, ColumnCategory.FIELD))
    schema = TableSchema("bench", col_schemas)

    col_names = ["device_id"] + field_names
    col_types = [TSDataType.STRING] + [TSDataType.DOUBLE] * len(field_names)

    with TsFileTableWriter(output_path, schema) as writer:
        for device_id, times in all_times.items():
            n = len(times)
            tablet = Tablet(col_names, col_types, n)
            tablet.set_table_name("bench")
            tablet.set_timestamp_list(times.tolist())
            for i in range(n):
                tablet.add_value_by_name("device_id", i, device_id)
                for fn in field_names:
                    tablet.add_value_by_name(fn, i, float(all_data[device_id][fn][i]))
            writer.write_table(tablet)


def _write_parquet(all_times, all_data, field_names, output_path):
    """Write data to a single Parquet file via PyArrow."""
    col_time = np.concatenate([all_times[d] for d in all_times])
    col_device = []
    for d, t in all_times.items():
        col_device.extend([d] * len(t))
    data_dict = {"time": col_time, "device_id": col_device}
    for fn in field_names:
        data_dict[fn] = np.concatenate([all_data[d][fn] for d in all_data])
    table = pa.table(data_dict)
    pq.write_table(table, output_path)


def generate_shard_data(scale_name, cfg, output_dir):
    """Generate time-sharded multi-file datasets (Group A)."""
    scale_dir = os.path.join(output_dir, scale_name)
    ts_dir = os.path.join(scale_dir, "tsfile")
    pq_dir = os.path.join(scale_dir, "parquet")
    os.makedirs(ts_dir, exist_ok=True)
    os.makedirs(pq_dir, exist_ok=True)

    ppd = cfg["points_per_device"]
    total_rows = cfg["num_devices"] * ppd
    print(f"\n  [{scale_name}] {total_rows:,} rows "
          f"({cfg['num_devices']} dev x {cfg['num_fields']} fields x {ppd:,} pts) "
          f"x {NUM_SHARDS} shards")

    # Check cache
    ts_paths = sorted(os.path.join(ts_dir, f) for f in os.listdir(ts_dir) if f.endswith(".tsfile"))
    pq_paths = sorted(os.path.join(pq_dir, f) for f in os.listdir(pq_dir) if f.endswith(".parquet"))
    if len(ts_paths) == NUM_SHARDS and len(pq_paths) == NUM_SHARDS:
        print(f"    Already generated ({NUM_SHARDS} shards)")
        return _make_paths_dict(ts_paths, pq_paths, cfg)

    all_times, all_data, field_names = _generate_raw_data(cfg)
    chunk_size = ppd // NUM_SHARDS
    t0_gen = time.perf_counter()
    ts_paths, pq_paths = [], []

    for shard_idx in range(NUM_SHARDS):
        start = shard_idx * chunk_size
        end = ppd if shard_idx == NUM_SHARDS - 1 else (shard_idx + 1) * chunk_size
        shard_times = {d: all_times[d][start:end] for d in all_times}
        shard_data = {d: {fn: all_data[d][fn][start:end] for fn in field_names} for d in all_data}

        ts_path = os.path.join(ts_dir, f"shard_{shard_idx:02d}.tsfile")
        pq_path = os.path.join(pq_dir, f"shard_{shard_idx:02d}.parquet")
        _write_tsfile(shard_times, shard_data, field_names, ts_path)
        _write_parquet(shard_times, shard_data, field_names, pq_path)
        ts_paths.append(ts_path)
        pq_paths.append(pq_path)

    elapsed = time.perf_counter() - t0_gen
    ts_mb = sum(os.path.getsize(p) for p in ts_paths) / (1024 * 1024)
    pq_mb = sum(os.path.getsize(p) for p in pq_paths) / (1024 * 1024)
    print(f"    Generated in {elapsed:.1f}s — TsFile {ts_mb:.1f}MB, Parquet {pq_mb:.1f}MB")
    return _make_paths_dict(ts_paths, pq_paths, cfg)


def generate_file_count_data(cfg, output_dir, file_counts):
    """Generate 1-device-per-file datasets for file-count scaling (Group B)."""
    np.random.seed(42)
    num_fields = cfg["num_fields"]
    ppd = cfg["points_per_device"]
    field_names = [f"f{i}" for i in range(num_fields)]
    max_dev = max(file_counts)

    all_dev_times, all_dev_data = {}, {}
    for i in range(max_dev):
        did = f"dev_{i:04d}"
        all_dev_times[did] = BASE_TS + np.arange(ppd, dtype=np.int64) * 1000
        all_dev_data[did] = {fn: np.random.uniform(0, 100, ppd).round(2) for fn in field_names}

    results = {}
    for n in file_counts:
        name = f"fc_{n:03d}"
        scale_dir = os.path.join(output_dir, name)
        ts_dir = os.path.join(scale_dir, "tsfile")
        pq_dir = os.path.join(scale_dir, "parquet")
        os.makedirs(ts_dir, exist_ok=True)
        os.makedirs(pq_dir, exist_ok=True)

        ts_paths = sorted(os.path.join(ts_dir, f) for f in os.listdir(ts_dir) if f.endswith(".tsfile"))
        pq_paths = sorted(os.path.join(pq_dir, f) for f in os.listdir(pq_dir) if f.endswith(".parquet"))
        if len(ts_paths) == n and len(pq_paths) == n:
            print(f"    [{name}] Already generated ({n} files)")
            results[n] = _make_paths_dict(ts_paths, pq_paths, {**cfg, "num_devices": n})
            continue

        print(f"    [{name}] Generating {n} files ...")
        t0 = time.perf_counter()
        ts_paths, pq_paths = [], []
        for i in range(n):
            did = f"dev_{i:04d}"
            t_map = {did: all_dev_times[did]}
            d_map = {did: all_dev_data[did]}
            ts_p = os.path.join(ts_dir, f"{did}.tsfile")
            pq_p = os.path.join(pq_dir, f"{did}.parquet")
            _write_tsfile(t_map, d_map, field_names, ts_p)
            _write_parquet(t_map, d_map, field_names, pq_p)
            ts_paths.append(ts_p)
            pq_paths.append(pq_p)
        print(f"      Done in {time.perf_counter() - t0:.1f}s")
        results[n] = _make_paths_dict(ts_paths, pq_paths, {**cfg, "num_devices": n})
    return results


def _make_paths_dict(ts_paths, pq_paths, cfg):
    field_names = [f"f{i}" for i in range(cfg["num_fields"])]
    return {"tsfile_shards": ts_paths, "parquet_shards": pq_paths,
            "field_names": field_names, "cfg": cfg}


# ── Correctness Verification ─────────────────────────────────────────────────

def verify_correctness(paths):
    """Quick verification that TsFile and Parquet return identical data."""
    cfg = paths["cfg"]
    ppd = cfg["points_per_device"]

    tsdf = TsFileDataFrame(paths["tsfile_shards"], show_progress=False)
    first_series = tsdf.list_timeseries()[0]
    ts_obj = tsdf[first_series]

    arrow_ds = pa_ds.dataset(paths["parquet_shards"], format="parquet")

    # 1. Point check: 10 random indices
    np.random.seed(999)
    for idx in np.random.randint(0, len(ts_obj), 10):
        ts_val = ts_obj[int(idx)]
        t = int(ts_obj.timestamps[idx])
        tbl = arrow_ds.to_table(
            filter=(pa_ds.field("time") == t) & (pa_ds.field("device_id") == "dev_0000"),
            columns=["f0"])
        pq_val = tbl.column("f0")[0].as_py()
        assert np.isclose(ts_val, pq_val, atol=1e-6), f"Point mismatch at idx={idx}"

    # 2. Time-range check: 10% of data
    num_pts = max(1, ppd // 10)
    start_ts, end_ts = BASE_TS, BASE_TS + (num_pts - 1) * 1000
    ts_result = tsdf.loc[start_ts:end_ts, [first_series]]
    ts_vals = ts_result.values[:, 0]

    tbl = arrow_ds.to_table(
        filter=(pa_ds.field("time") >= start_ts) & (pa_ds.field("time") <= end_ts)
                & (pa_ds.field("device_id") == "dev_0000"),
        columns=["time", "f0"])
    pq_vals = tbl.column("f0").to_numpy()
    assert len(ts_vals) == len(pq_vals), f"Length mismatch: {len(ts_vals)} vs {len(pq_vals)}"
    assert np.allclose(ts_vals, pq_vals, atol=1e-6), "Time-range value mismatch"

    tsdf.close()
    print("    Correctness verified ✓")


# ── Scenario 1: Training Random Sampling ─────────────────────────────────────

def bench_random_access(paths, iterations):
    """
    ML scenario: DataLoader random-samples individual data points for training.
    - TsFile  : ts_obj[idx]                          (time-index lookup per point)
    - Arrow   : dataset.to_table(filter=exact_time)   (predicate pushdown per point)
    - HF      : hf_dev[idx][field]                     (O(1) memory-mapped access)
    """
    first_field = paths["field_names"][0]

    tsdf = TsFileDataFrame(paths["tsfile_shards"], show_progress=False)
    first_series = tsdf.list_timeseries()[0]
    ts_obj = tsdf[first_series]

    arrow_ds_obj = pa_ds.dataset(paths["parquet_shards"], format="parquet")

    hf_ds = Dataset.from_parquet(paths["parquet_shards"])
    hf_dev = hf_ds.filter(lambda x: x["device_id"] == "dev_0000", num_proc=1)

    np.random.seed(123)
    n_queries = min(200, len(ts_obj))
    indices = np.random.randint(0, min(len(ts_obj), len(hf_dev)), size=n_queries)
    query_timestamps = ts_obj.timestamps[indices]

    def tsfile_fn():
        for idx in indices:
            _ = ts_obj[int(idx)]

    def arrow_fn():
        for t in query_timestamps:
            tbl = arrow_ds_obj.to_table(
                filter=(pa_ds.field("time") == int(t))
                        & (pa_ds.field("device_id") == "dev_0000"),
                columns=[first_field])
            _ = tbl.column(first_field)[0].as_py() if tbl.num_rows > 0 else None

    def hf_fn():
        for idx in indices:
            _ = hf_dev[int(idx)][first_field]

    ts_t = measure(tsfile_fn, warmup=1, iterations=iterations)
    ar_t = measure(arrow_fn, warmup=1, iterations=iterations)
    hf_t = measure(hf_fn, warmup=1, iterations=iterations)

    tsdf.close()
    return {
        "tsfile": BenchResult("TsFile", ts_t),
        "arrow": BenchResult("Arrow", ar_t),
        "hf": BenchResult("HF Dataset", hf_t),
        "num_queries": n_queries,
    }


# ── Scenario 2: Training Window Sampling ─────────────────────────────────────

def bench_window_sample(paths, iterations):
    """
    ML scenario: time-series model samples a contiguous window (LSTM / Transformer input).
    Window may cross shard boundaries.
    - TsFile  : ts_obj[start:start+win]
    - Arrow   : dataset.to_table(filter=time_range, columns=[...])
    - HF      : hf_dev[start:start+win][field]
    """
    cfg = paths["cfg"]
    ppd = cfg["points_per_device"]
    first_field = paths["field_names"][0]
    chunk_size = ppd // NUM_SHARDS

    tsdf = TsFileDataFrame(paths["tsfile_shards"], show_progress=False)
    first_series = tsdf.list_timeseries()[0]
    ts_obj = tsdf[first_series]
    timestamps = ts_obj.timestamps

    arrow_ds_obj = pa_ds.dataset(paths["parquet_shards"], format="parquet")

    hf_ds = Dataset.from_parquet(paths["parquet_shards"])
    hf_dev = hf_ds.filter(lambda x: x["device_id"] == "dev_0000", num_proc=1)

    window_sizes = [64, 256, 1024]
    ten_pct = max(1, ppd // 10)
    if ten_pct > 1024:
        window_sizes.append(ten_pct)

    results = {}
    for win in window_sizes:
        if win > len(ts_obj):
            continue
        # Start near shard boundary to test cross-file reads
        start = max(0, chunk_size - win // 2)
        end = start + win
        start_ts = int(timestamps[start])
        end_ts = int(timestamps[min(end - 1, len(timestamps) - 1)])

        def tsfile_fn(s=start, e=end):
            return ts_obj[s:e]

        def arrow_fn(st=start_ts, et=end_ts):
            return arrow_ds_obj.to_table(
                filter=(pa_ds.field("time") >= st) & (pa_ds.field("time") <= et)
                        & (pa_ds.field("device_id") == "dev_0000"),
                columns=["time", first_field])

        def hf_fn(s=start, e=end):
            return hf_dev[s:e][first_field]

        ts_t = measure(tsfile_fn, warmup=1, iterations=iterations)
        ar_t = measure(arrow_fn, warmup=1, iterations=iterations)
        hf_t = measure(hf_fn, warmup=1, iterations=iterations)

        label = f"{win:,}" + (" (10%)" if win == ten_pct else "")
        results[win] = {
            "tsfile": BenchResult("TsFile", ts_t),
            "arrow": BenchResult("Arrow", ar_t),
            "hf": BenchResult("HF Dataset", hf_t),
            "label": label,
        }

    tsdf.close()
    return results


# ── Scenario 3: Inference Time-Range Query ───────────────────────────────────

def bench_time_range(paths, iterations):
    """
    ML scenario: inference queries "last N minutes" of sensor data by timestamp.
    - TsFile  : tsdf.loc[t1:t2, [series]]          (native time index)
    - Arrow   : dataset.to_table(filter=time_range)  (row-group pushdown)
    - HF      : hf_ds.filter(lambda: time in range)  (full scan)
    """
    cfg = paths["cfg"]
    ppd = cfg["points_per_device"]
    first_field = paths["field_names"][0]

    tsdf = TsFileDataFrame(paths["tsfile_shards"], show_progress=False)
    first_series = tsdf.list_timeseries()[0]

    arrow_ds_obj = pa_ds.dataset(paths["parquet_shards"], format="parquet")

    hf_ds = Dataset.from_parquet(paths["parquet_shards"])

    selectivities = {"1%": 0.01, "10%": 0.10, "50%": 0.50}
    results = {}

    for sel_name, sel in selectivities.items():
        num_pts = max(1, int(ppd * sel))
        start_ts = BASE_TS
        end_ts = BASE_TS + (num_pts - 1) * 1000

        def tsfile_fn(s=start_ts, e=end_ts, sn=first_series):
            return tsdf.loc[s:e, [sn]]

        def arrow_fn(s=start_ts, e=end_ts):
            return arrow_ds_obj.to_table(
                filter=(pa_ds.field("time") >= s) & (pa_ds.field("time") <= e)
                        & (pa_ds.field("device_id") == "dev_0000"),
                columns=["time", first_field])

        def hf_fn(s=start_ts, e=end_ts):
            return hf_ds.filter(
                lambda x: x["time"] >= s and x["time"] <= e
                           and x["device_id"] == "dev_0000")

        ts_t = measure(tsfile_fn, warmup=1, iterations=iterations)
        ar_t = measure(arrow_fn, warmup=1, iterations=iterations)
        hf_t = measure(hf_fn, warmup=1, iterations=iterations)

        results[sel_name] = {
            "tsfile": BenchResult("TsFile", ts_t),
            "arrow": BenchResult("Arrow", ar_t),
            "hf": BenchResult("HF Dataset", hf_t),
            "num_points": num_pts,
        }

    tsdf.close()
    return results


# ── Scenario 4: Multi-Sensor Fusion Query ────────────────────────────────────

def bench_multi_sensor_fusion(paths, iterations):
    """
    ML scenario: multi-modal / multi-sensor fusion training requires
    time-aligned data from multiple sensors in one window.

    Sub-case A — Same-device multi-field (e.g. temperature + humidity + pressure):
      TsFile batches fields under same TAG in one read.
    Sub-case B — Cross-device same-field (e.g. temperature from 5 weather stations):
      TsFile auto-merges and aligns across files; Parquet needs manual join.
    """
    cfg = paths["cfg"]
    ppd = cfg["points_per_device"]
    field_names = paths["field_names"]

    tsdf = TsFileDataFrame(paths["tsfile_shards"], show_progress=False)
    all_series = tsdf.list_timeseries()

    arrow_ds_obj = pa_ds.dataset(paths["parquet_shards"], format="parquet")
    hf_ds = Dataset.from_parquet(paths["parquet_shards"])

    # 10% selectivity
    num_pts = max(1, int(ppd * 0.10))
    start_ts = BASE_TS
    end_ts = BASE_TS + (num_pts - 1) * 1000

    results = {}

    # ── Sub-case A: Same-device multi-field ──
    same_dev_series = [s for s in all_series if "dev_0000" in s]
    for n_fields in sorted({2, min(len(same_dev_series), 5)}):
        selected = same_dev_series[:n_fields]
        sel_fields = [s.split(".")[-1] for s in selected]
        key = f"same_dev_{n_fields}f"

        def tsfile_fn(s=start_ts, e=end_ts, sl=list(selected)):
            return tsdf.loc[s:e, sl]

        def arrow_fn(s=start_ts, e=end_ts, flds=list(sel_fields)):
            return arrow_ds_obj.to_table(
                filter=(pa_ds.field("time") >= s) & (pa_ds.field("time") <= e)
                        & (pa_ds.field("device_id") == "dev_0000"),
                columns=["time"] + flds)

        def hf_fn(s=start_ts, e=end_ts, flds=list(sel_fields)):
            filtered = hf_ds.filter(
                lambda x: x["time"] >= s and x["time"] <= e
                           and x["device_id"] == "dev_0000")
            return filtered.select_columns(["time"] + flds)

        ts_t = measure(tsfile_fn, warmup=1, iterations=iterations)
        ar_t = measure(arrow_fn, warmup=1, iterations=iterations)
        hf_t = measure(hf_fn, warmup=1, iterations=iterations)

        results[key] = {
            "tsfile": BenchResult("TsFile", ts_t),
            "arrow": BenchResult("Arrow", ar_t),
            "hf": BenchResult("HF Dataset", hf_t),
            "label": f"Same-device, {n_fields} fields",
            "num_points": num_pts, "num_series": n_fields,
        }

    # ── Sub-case B: Cross-device same-field ──
    cross_dev_series = [s for s in all_series if s.endswith(".f0")]
    for n_devs in sorted({2, min(len(cross_dev_series), 5)}):
        selected = cross_dev_series[:n_devs]
        device_ids = [s.split(".")[1] for s in selected]
        key = f"cross_dev_{n_devs}d"

        def tsfile_fn(s=start_ts, e=end_ts, sl=list(selected)):
            return tsdf.loc[s:e, sl]

        def arrow_fn(s=start_ts, e=end_ts, devs=list(device_ids)):
            frames = []
            for dev_id in devs:
                tbl = arrow_ds_obj.to_table(
                    filter=(pa_ds.field("time") >= s) & (pa_ds.field("time") <= e)
                            & (pa_ds.field("device_id") == dev_id),
                    columns=["time", "f0"])
                df = tbl.to_pandas().rename(columns={"f0": f"{dev_id}_f0"})
                frames.append(df.set_index("time"))
            aligned = frames[0]
            for f in frames[1:]:
                aligned = aligned.join(f, how="outer")
            return aligned

        def hf_fn(s=start_ts, e=end_ts, devs=list(device_ids)):
            frames = []
            for dev_id in devs:
                filtered = hf_ds.filter(
                    lambda x, d=dev_id: x["time"] >= s and x["time"] <= e
                                         and x["device_id"] == d)
                df = filtered.to_pandas()[["time", "f0"]].rename(
                    columns={"f0": f"{dev_id}_f0"}).set_index("time")
                frames.append(df)
            aligned = frames[0]
            for f in frames[1:]:
                aligned = aligned.join(f, how="outer")
            return aligned

        ts_t = measure(tsfile_fn, warmup=1, iterations=iterations)
        ar_t = measure(arrow_fn, warmup=1, iterations=iterations)
        hf_t = measure(hf_fn, warmup=1, iterations=iterations)

        results[key] = {
            "tsfile": BenchResult("TsFile", ts_t),
            "arrow": BenchResult("Arrow", ar_t),
            "hf": BenchResult("HF Dataset", hf_t),
            "label": f"Cross-device, {n_devs} devices, field f0",
            "num_points": num_pts, "num_series": n_devs,
        }

    tsdf.close()
    return results


# ── Group B: File-Count Scaling ──────────────────────────────────────────────

def bench_file_count_scaling(fc_paths_dict, iterations):
    """
    Test how each framework scales as the number of files grows (1 → 100).
    Each file = 1 device; per-device data is constant; total data grows.
    Runs a representative config of each scenario.
    """
    results = {}

    for n_files, paths in sorted(fc_paths_dict.items()):
        cfg = paths["cfg"]
        ppd = cfg["points_per_device"]
        first_field = paths["field_names"][0]
        pq_shards = paths["parquet_shards"]

        print(f"    [{n_files} files] ...")
        entry = {"n_files": n_files}

        # --- Setup (not timed per query) ---
        tsdf = TsFileDataFrame(paths["tsfile_shards"], show_progress=False)
        first_series = tsdf.list_timeseries()[0]
        ts_obj = tsdf[first_series]
        timestamps = ts_obj.timestamps

        arrow_ds_obj = pa_ds.dataset(pq_shards, format="parquet")

        hf_ds = Dataset.from_parquet(pq_shards)
        hf_dev = hf_ds.filter(lambda x: x["device_id"] == "dev_0000", num_proc=1)

        # --- 1. Random access (100 points) ---
        np.random.seed(123)
        n_q = min(100, len(ts_obj))
        indices = np.random.randint(0, min(len(ts_obj), len(hf_dev)), size=n_q)
        query_ts = timestamps[indices]

        def ts_pt():
            for i in indices: _ = ts_obj[int(i)]

        def ar_pt():
            for t in query_ts:
                arrow_ds_obj.to_table(
                    filter=(pa_ds.field("time") == int(t))
                            & (pa_ds.field("device_id") == "dev_0000"),
                    columns=[first_field])

        def hf_pt():
            for i in indices: _ = hf_dev[int(i)][first_field]

        entry["random_access"] = {
            "tsfile": BenchResult("TsFile", measure(ts_pt, 1, iterations)),
            "arrow": BenchResult("Arrow", measure(ar_pt, 1, iterations)),
            "hf": BenchResult("HF Dataset", measure(hf_pt, 1, iterations)),
            "num_queries": n_q,
        }

        # --- 2. Window sample (10% window) ---
        win = max(1, ppd // 10)
        st_ts = int(timestamps[0])
        et_ts = int(timestamps[min(win - 1, len(timestamps) - 1)])

        def ts_win(): return ts_obj[0:win]
        def ar_win():
            return arrow_ds_obj.to_table(
                filter=(pa_ds.field("time") >= st_ts) & (pa_ds.field("time") <= et_ts)
                        & (pa_ds.field("device_id") == "dev_0000"),
                columns=["time", first_field])
        def hf_win(): return hf_dev[0:win][first_field]

        entry["window_sample"] = {
            "tsfile": BenchResult("TsFile", measure(ts_win, 1, iterations)),
            "arrow": BenchResult("Arrow", measure(ar_win, 1, iterations)),
            "hf": BenchResult("HF Dataset", measure(hf_win, 1, iterations)),
        }

        # --- 3. Time-range query (10%) ---
        num_pts = max(1, ppd // 10)
        s_ts = BASE_TS
        e_ts = BASE_TS + (num_pts - 1) * 1000

        def ts_tr(): return tsdf.loc[s_ts:e_ts, [first_series]]
        def ar_tr():
            return arrow_ds_obj.to_table(
                filter=(pa_ds.field("time") >= s_ts) & (pa_ds.field("time") <= e_ts)
                        & (pa_ds.field("device_id") == "dev_0000"),
                columns=["time", first_field])
        def hf_tr():
            return hf_ds.filter(
                lambda x: x["time"] >= s_ts and x["time"] <= e_ts
                           and x["device_id"] == "dev_0000")

        entry["time_range"] = {
            "tsfile": BenchResult("TsFile", measure(ts_tr, 1, iterations)),
            "arrow": BenchResult("Arrow", measure(ar_tr, 1, iterations)),
            "hf": BenchResult("HF Dataset", measure(hf_tr, 1, iterations)),
        }

        # --- 4. Multi-sensor fusion (cross-device, up to 5 devices) ---
        all_series = tsdf.list_timeseries()
        cross_dev = [s for s in all_series if s.endswith(".f0")][:min(5, n_files)]
        dev_ids = [s.split(".")[1] for s in cross_dev]

        def ts_fuse(): return tsdf.loc[s_ts:e_ts, cross_dev]
        def ar_fuse():
            frames = []
            for dev_id in dev_ids:
                tbl = arrow_ds_obj.to_table(
                    filter=(pa_ds.field("time") >= s_ts) & (pa_ds.field("time") <= e_ts)
                            & (pa_ds.field("device_id") == dev_id),
                    columns=["time", "f0"])
                frames.append(tbl.to_pandas().rename(
                    columns={"f0": f"{dev_id}_f0"}).set_index("time"))
            aligned = frames[0]
            for f in frames[1:]: aligned = aligned.join(f, how="outer")
            return aligned
        def hf_fuse():
            frames = []
            for dev_id in dev_ids:
                filtered = hf_ds.filter(
                    lambda x, d=dev_id: x["time"] >= s_ts and x["time"] <= e_ts
                                         and x["device_id"] == d)
                frames.append(filtered.to_pandas()[["time", "f0"]].rename(
                    columns={"f0": f"{dev_id}_f0"}).set_index("time"))
            aligned = frames[0]
            for f in frames[1:]: aligned = aligned.join(f, how="outer")
            return aligned

        entry["multi_fusion"] = {
            "tsfile": BenchResult("TsFile", measure(ts_fuse, 1, iterations)),
            "arrow": BenchResult("Arrow", measure(ar_fuse, 1, iterations)),
            "hf": BenchResult("HF Dataset", measure(hf_fuse, 1, iterations)),
            "num_series": len(cross_dev),
        }

        tsdf.close()
        gc.collect()
        results[n_files] = entry

    return results


# ── Reporting ────────────────────────────────────────────────────────────────

FRAMEWORKS = ["tsfile", "arrow", "hf"]


def _fmt(seconds):
    if seconds < 0.001:
        return f"{seconds * 1e6:.0f} µs"
    elif seconds < 1.0:
        return f"{seconds * 1e3:.2f} ms"
    else:
        return f"{seconds:.3f} s"


def _print_row(data, keys=FRAMEWORKS):
    """Print one row: Name | Mean ± Std for each framework."""
    parts = []
    for k in keys:
        r = data[k]
        parts.append(f"{r.name:>12}: {_fmt(r.mean):>10} ± {_fmt(r.std):>8}")
    print(f"       " + "  |  ".join(parts))


def _header(title):
    print(f"\n{'=' * 78}")
    print(f"  {title}")
    print(f"{'=' * 78}")


def print_group_a(scale_name, cfg, results):
    total = cfg["num_devices"] * cfg["points_per_device"]
    _header(f"Group A: {scale_name} ({total:,} rows, "
            f"{cfg['num_devices']} dev × {cfg['num_fields']} fields, {NUM_SHARDS} shards)")

    # 1. Random access
    ra = results["random_access"]
    n = ra["num_queries"]
    print(f"\n  1. Training Random Sampling ({n} random points)")
    _print_row(ra)
    print(f"       Per-point: TsFile {_fmt(ra['tsfile'].mean / n)} | "
          f"Arrow {_fmt(ra['arrow'].mean / n)} | "
          f"HF {_fmt(ra['hf'].mean / n)}")

    # 2. Window sample
    ws = results["window_sample"]
    print(f"\n  2. Training Window Sampling (cross-shard)")
    for win_size, data in ws.items():
        print(f"     Window = {data['label']}:")
        _print_row(data)

    # 3. Time-range
    tr = results["time_range"]
    print(f"\n  3. Inference Time-Range Query")
    for sel, data in tr.items():
        print(f"     Selectivity {sel} ({data['num_points']:,} pts):")
        _print_row(data)

    # 4. Multi-sensor fusion
    mf = results["multi_fusion"]
    print(f"\n  4. Multi-Sensor Fusion")
    for key, data in mf.items():
        print(f"     {data['label']} ({data['num_points']:,} pts × {data['num_series']} series):")
        _print_row(data)


def print_group_b(fc_results, cfg):
    ppd = cfg["points_per_device"]
    _header(f"Group B: File-Count Scaling (1 dev/file, {ppd:,} pts/dev)")

    scenarios = [
        ("Random Access", "random_access"),
        ("Window Sample (10%)", "window_sample"),
        ("Time-Range (10%)", "time_range"),
        ("Multi-Sensor Fusion", "multi_fusion"),
    ]

    for title, key in scenarios:
        print(f"\n  {title}:")
        print(f"     {'Files':>6}  {'TsFile':>14}  {'Arrow':>14}  {'HF Dataset':>14}")
        print(f"     {'─' * 6}  {'─' * 14}  {'─' * 14}  {'─' * 14}")
        for n in sorted(fc_results.keys()):
            d = fc_results[n][key]
            print(f"     {n:>6}  {_fmt(d['tsfile'].mean):>14}  "
                  f"{_fmt(d['arrow'].mean):>14}  {_fmt(d['hf'].mean):>14}")


# ── Plotting ─────────────────────────────────────────────────────────────────

COLORS = {"tsfile": "#1f77b4", "arrow": "#2ca02c", "hf": "#ff7f0e"}
LABELS = {"tsfile": "TsFile", "arrow": "Arrow", "hf": "HF Dataset"}
MARKERS = {"tsfile": "o", "arrow": "^", "hf": "s"}


def plot_group_a(all_scale_results, output_dir):
    """Generate Group A charts: 2×2 subplots for 4 scenarios."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("  matplotlib not installed, skipping plots.")
        return

    os.makedirs(output_dir, exist_ok=True)
    scales = list(all_scale_results.keys())
    x = np.arange(len(scales))
    w = 0.25

    fig, axes = plt.subplots(2, 2, figsize=(14, 10))

    # 1. Random access (per-point, log scale)
    ax = axes[0, 0]
    for i, k in enumerate(FRAMEWORKS):
        vals = [all_scale_results[s]["random_access"][k].mean
                / all_scale_results[s]["random_access"]["num_queries"] * 1e6
                for s in scales]
        ax.bar(x + (i - 1) * w, vals, w, label=LABELS[k], color=COLORS[k])
    ax.set_ylabel("Per-point latency (µs)")
    ax.set_title("1. Training Random Sampling")
    ax.set_xticks(x); ax.set_xticklabels(scales)
    ax.set_yscale("log"); ax.legend(); ax.grid(axis="y", alpha=0.3)

    # 2. Window sample (largest window per scale)
    ax = axes[0, 1]
    for i, k in enumerate(FRAMEWORKS):
        vals = []
        for s in scales:
            ws = all_scale_results[s]["window_sample"]
            largest = max(ws.keys())
            vals.append(ws[largest][k].mean * 1e3)
        ax.bar(x + (i - 1) * w, vals, w, label=LABELS[k], color=COLORS[k])
    ax.set_ylabel("Latency (ms)")
    ax.set_title("2. Training Window Sampling")
    ax.set_xticks(x); ax.set_xticklabels(scales)
    ax.legend(); ax.grid(axis="y", alpha=0.3)

    # 3. Time-range (10%)
    ax = axes[1, 0]
    for i, k in enumerate(FRAMEWORKS):
        vals = [all_scale_results[s]["time_range"]["10%"][k].mean * 1e3 for s in scales]
        ax.bar(x + (i - 1) * w, vals, w, label=LABELS[k], color=COLORS[k])
    ax.set_ylabel("Latency (ms)")
    ax.set_title("3. Inference Time-Range (10%)")
    ax.set_xticks(x); ax.set_xticklabels(scales)
    ax.legend(); ax.grid(axis="y", alpha=0.3)

    # 4. Multi-sensor fusion (cross-device, max devices)
    ax = axes[1, 1]
    for i, k in enumerate(FRAMEWORKS):
        vals = []
        for s in scales:
            mf = all_scale_results[s]["multi_fusion"]
            cross_key = [ky for ky in mf if ky.startswith("cross_dev")]
            cross_key = sorted(cross_key)[-1] if cross_key else list(mf.keys())[-1]
            vals.append(mf[cross_key][k].mean * 1e3)
        ax.bar(x + (i - 1) * w, vals, w, label=LABELS[k], color=COLORS[k])
    ax.set_ylabel("Latency (ms)")
    ax.set_title("4. Multi-Sensor Fusion (cross-device)")
    ax.set_xticks(x); ax.set_xticklabels(scales)
    ax.legend(); ax.grid(axis="y", alpha=0.3)

    plt.suptitle("TsFileDataFrame vs Arrow Dataset vs HF Dataset — ML Workloads",
                 fontsize=13, y=1.01)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "group_a.png"), dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  Group A chart saved to {output_dir}/group_a.png")


def plot_group_b(fc_results, output_dir):
    """Generate Group B chart: 2×2 line plots (file count on x-axis)."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("  matplotlib not installed, skipping plots.")
        return

    os.makedirs(output_dir, exist_ok=True)
    file_counts = sorted(fc_results.keys())

    scenarios = [
        ("Training Random Sampling", "random_access"),
        ("Training Window (10%)", "window_sample"),
        ("Inference Time-Range (10%)", "time_range"),
        ("Multi-Sensor Fusion", "multi_fusion"),
    ]

    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    axes = axes.flatten()

    for ax_idx, (title, key) in enumerate(scenarios):
        ax = axes[ax_idx]
        for k in FRAMEWORKS:
            vals = [fc_results[n][key][k].mean * 1e3 for n in file_counts]
            ax.plot(file_counts, vals, marker=MARKERS[k], label=LABELS[k],
                    color=COLORS[k], linewidth=1.5)
        ax.set_xlabel("Number of Files")
        ax.set_ylabel("Latency (ms)")
        ax.set_title(title)
        ax.legend(fontsize=8)
        ax.grid(True, alpha=0.3)

    plt.suptitle("File-Count Scaling: 1 device/file, total data grows with file count",
                 fontsize=13, y=1.01)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "group_b.png"), dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  Group B chart saved to {output_dir}/group_b.png")


# ── Main ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Benchmark: TsFileDataFrame vs Arrow Dataset vs HF Dataset")
    parser.add_argument("--scales", nargs="+", default=["small"],
                        choices=["small", "medium", "large"])
    parser.add_argument("--iterations", type=int, default=5)
    parser.add_argument("--plot", action="store_true")
    parser.add_argument("--output-dir", default=BENCHMARK_DIR)
    parser.add_argument("--file-count-scaling", action="store_true",
                        help="Run file-count scaling experiment (Group B)")
    parser.add_argument("--fc-scale", default="medium",
                        choices=["small", "medium", "large"],
                        help="Data scale for file-count experiment")
    args = parser.parse_args()

    print("=" * 78)
    print("  TsFileDataFrame vs Arrow Dataset vs HF Dataset")
    print("  ML workload benchmark — each framework uses its best practice")
    print("=" * 78)

    # ── Group A ──
    all_scale_results = {}
    if not args.file_count_scaling:
        print("\n  Preparing data ...")
        scale_paths = {}
        for scale in args.scales:
            scale_paths[scale] = generate_shard_data(scale, SCALE_CONFIGS[scale], args.output_dir)

        for scale in args.scales:
            cfg = SCALE_CONFIGS[scale]
            paths = scale_paths[scale]
            total = cfg["num_devices"] * cfg["points_per_device"]
            print(f"\n  Running [{scale}] ({total:,} rows, {NUM_SHARDS} shards) ...")

            verify_correctness(paths)

            results = {}
            print("    [1/4] Training random sampling ...")
            results["random_access"] = bench_random_access(paths, args.iterations)

            print("    [2/4] Training window sampling ...")
            results["window_sample"] = bench_window_sample(paths, args.iterations)

            print("    [3/4] Inference time-range query ...")
            results["time_range"] = bench_time_range(paths, args.iterations)

            print("    [4/4] Multi-sensor fusion ...")
            results["multi_fusion"] = bench_multi_sensor_fusion(paths, args.iterations)

            all_scale_results[scale] = results
            print_group_a(scale, cfg, results)

        if args.plot:
            plot_group_a(all_scale_results, os.path.join(args.output_dir, "plots"))

    # ── Group B ──
    if args.file_count_scaling:
        fc_cfg = SCALE_CONFIGS[args.fc_scale]
        print(f"\n  Group B: File-Count Scaling")
        print(f"  Scale: {args.fc_scale}, File counts: {FILE_COUNT_LIST}")
        print(f"  Generating datasets ...")

        fc_paths = generate_file_count_data(fc_cfg, args.output_dir, FILE_COUNT_LIST)

        print(f"\n  Running file-count scaling benchmarks ...")
        fc_results = bench_file_count_scaling(fc_paths, args.iterations)
        print_group_b(fc_results, fc_cfg)

        if args.plot:
            plot_group_b(fc_results, os.path.join(args.output_dir, "plots"))

    print(f"\n{'=' * 78}")
    print(f"  Benchmark complete!")
    print(f"{'=' * 78}")


if __name__ == "__main__":
    main()
