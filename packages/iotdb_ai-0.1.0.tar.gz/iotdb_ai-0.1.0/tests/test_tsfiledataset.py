from iotdb_ai.tsfile.dataset import TsFileDataset
from iotdb_ai.tsfile.reader import TsFileReader

# 配置测试文件路径
TSFILE_PATH = "/Users/ycycse/WorkSpace/IoTDB-AI/tests/timebench.tsfile"


def test_single_variable_mode():
    """测试单变量模式"""
    print("=" * 50)
    print("Testing Single Variable Mode")
    print("=" * 50)

    dataset = TsFileDataset(
        tsfile_paths=TSFILE_PATH,
        length=120,
        window_stride=1
    )

    print(f"Dataset info: {dataset.get_info()}")
    print(f"Dataset length: {len(dataset)}")

    # 获取第一个样本
    data = dataset[0]
    print(f"Sample shape: {data.shape}")  # 应该是 (120,)
    print(f"Sample data (first 10): {data[:10]}")


def test_multi_variable_mode():
    """测试多变量模式"""
    print("\n" + "=" * 50)
    print("Testing Multi-Variable Mode")
    print("=" * 50)

    # 先读取文件获取可用的变量列表
    reader = TsFileReader(TSFILE_PATH)
    all_series = reader.get_all_series()
    print(f"Available series: {all_series}")

    if len(all_series) < 2:
        print("Not enough series for multi-variable test")
        return

    # 选择前3个变量（或全部如果少于3个）
    variables = all_series[:min(3, len(all_series))]
    print(f"Selected variables: {variables}")

    dataset = TsFileDataset(
        tsfile_paths=TSFILE_PATH,
        length=120,
        variables=variables,
        window_stride=1
    )

    print(f"Dataset info: {dataset.get_info()}")
    print(f"Dataset length: {len(dataset)}")

    # 获取第一个样本
    data = dataset[0]
    print(f"Sample shape: {data.shape}")  # 应该是 (num_variables, 120)
    print(f"Sample data:\n{data}")


if __name__ == "__main__":
    test_single_variable_mode()
    test_multi_variable_mode()
