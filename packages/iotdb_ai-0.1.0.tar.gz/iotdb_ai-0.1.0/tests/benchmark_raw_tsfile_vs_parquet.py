"""
Benchmark: TsFile Native Reader vs TsFileDataFrame vs Parquet

Two test scenarios:
  1. Single-series segment query — contiguous slice of one device/field
  2. Multi-series time-range query — time-aligned query across multiple series

Three layers:
  L0: Raw TsFile C++/Cython reader (tsfile.TsFileReader)
  L2: TsFileDataFrame (iotdb_ai.tsfile.dataframe)
  PQ: PyArrow Parquet (pyarrow.parquet)

Usage:
    python tests/benchmark_raw_tsfile_vs_parquet.py
    python tests/benchmark_raw_tsfile_vs_parquet.py --scale medium
    python tests/benchmark_raw_tsfile_vs_parquet.py --scale large --iterations 10
"""

import os
import sys
import gc
import time
import argparse
from dataclasses import dataclass, field
from typing import List, Callable

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

# ── Constants ────────────────────────────────────────────────────────────────

BASE_TS = 1769443200000  # 2026-01-28 00:00:00 UTC+8
BENCHMARK_DIR = os.path.join(os.path.dirname(__file__), "benchmark_data")

SCALE_CONFIGS = {
    "small":  {"num_fields": 3, "points_per_device": 1_000},
    "medium": {"num_fields": 5, "points_per_device": 10_000},
    "large":  {"num_fields": 5, "points_per_device": 50_000},
}

# ── Utilities ────────────────────────────────────────────────────────────────

@dataclass
class BenchResult:
    name: str
    times: List[float] = field(default_factory=list)

    @property
    def mean(self):
        return np.mean(self.times) if self.times else 0.0

    @property
    def std(self):
        return np.std(self.times) if self.times else 0.0


def measure(func: Callable, warmup: int = 1, iterations: int = 5):
    for _ in range(warmup):
        result = func()
        del result
        gc.collect()
    times = []
    for _ in range(iterations):
        gc.collect()
        t0 = time.perf_counter()
        result = func()
        t1 = time.perf_counter()
        times.append(t1 - t0)
        del result
    return times


def _fmt(seconds):
    if seconds < 0.001:
        return f"{seconds*1e6:.0f} us"
    elif seconds < 1.0:
        return f"{seconds*1e3:.2f} ms"
    else:
        return f"{seconds:.3f} s"


# ── Data Generation ─────────────────────────────────────────────────────────

def ensure_data(scale_name, output_dir):
    from tsfile.utils import dataframe_to_tsfile

    cfg = SCALE_CONFIGS[scale_name]
    scale_dir = os.path.join(output_dir, f"{scale_name}_single")
    os.makedirs(scale_dir, exist_ok=True)

    tsfile_path = os.path.join(scale_dir, "data.tsfile")
    parquet_path = os.path.join(scale_dir, "data.parquet")

    np.random.seed(42)
    ppd = cfg["points_per_device"]
    field_names = [f"f{i}" for i in range(cfg["num_fields"])]

    if not os.path.exists(tsfile_path) or not os.path.exists(parquet_path):
        print(f"  Generating {scale_name} data (single device, {ppd:,} rows)...")
        times = BASE_TS + np.arange(ppd, dtype=np.int64) * 1000
        df = pd.DataFrame({"time": times})
        for fn in field_names:
            df[fn] = np.random.uniform(0, 100, ppd).round(2)

        if not os.path.exists(tsfile_path):
            dataframe_to_tsfile(df, tsfile_path, table_name="bench")
        if not os.path.exists(parquet_path):
            import pyarrow as pa
            pq.write_table(pa.Table.from_pandas(df), parquet_path)

    return {
        "tsfile": tsfile_path, "parquet": parquet_path,
        "cfg": cfg, "field_names": field_names,
    }


# ── Output Verification ──────────────────────────────────────────────────────

def verify_outputs(paths):
    """Verify that L0, L2, and PQ return consistent shapes and values."""
    from tsfile import TsFileReader as CythonReader
    from iotdb_ai.tsfile.dataframe import TsFileDataFrame

    cfg = paths["cfg"]
    ppd = cfg["points_per_device"]
    field_names = paths["field_names"]
    field_name = "f0"
    table_name = "bench"

    tsfile_path = paths["tsfile"]
    parquet_path = paths["parquet"]

    l0_reader = CythonReader(tsfile_path)
    l2_tsdf = TsFileDataFrame(tsfile_path, show_progress=False)
    l2_all_series = l2_tsdf.list_timeseries()
    l2_first = [s for s in l2_all_series if s.endswith(f".{field_name}")][0]

    print(f"\n{'='*78}")
    print("  Output Verification")
    print(f"{'='*78}")

    errors = []

    # --- Single-series full query ---
    start_time = BASE_TS
    end_time = BASE_TS + (ppd - 1) * 1000

    # L0
    with l0_reader.query_table_batch(table_name, [field_name],
                                     start_time=start_time, end_time=end_time,
                                     batch_size=65536) as rs:
        batches = []
        while True:
            batch = rs.read_arrow_batch()
            if batch is None:
                break
            batches.append(batch)
    l0_vals = pa.concat_tables(batches).column(field_name).to_numpy()

    # L2
    l2_result = l2_tsdf.loc[start_time:end_time, [l2_first]]
    l2_vals = l2_result.iloc[:, -1].values  # last column is the value column

    # PQ
    pq_vals = pq.read_table(parquet_path,
                            filters=[("time", ">=", start_time), ("time", "<=", end_time)],
                            columns=["time", field_name], use_threads=False).column(field_name).to_numpy()

    # Check shapes
    _check(errors, "Single-series shape L0", l0_vals.shape, (ppd,))
    _check(errors, "Single-series shape PQ", pq_vals.shape, (ppd,))
    _check(errors, "Single-series len  L2", len(l2_vals), ppd)

    # Check values match (L0 vs PQ, first/last 5 elements)
    _check_values(errors, "Single L0 vs PQ head", l0_vals[:5], pq_vals[:5])
    _check_values(errors, "Single L0 vs PQ tail", l0_vals[-5:], pq_vals[-5:])
    _check_values(errors, "Single L2 vs PQ head", l2_vals[:5], pq_vals[:5])

    # --- Multi-series query (2 fields, 10% rows) ---
    n_cols = min(2, len(l2_all_series))
    selected_series = l2_all_series[:n_cols]
    selected_fields = [s.split(".")[-1] for s in selected_series]
    num_points = max(1, int(ppd * 0.1))
    end_time_multi = BASE_TS + (num_points - 1) * 1000

    with l0_reader.query_table_batch(table_name, selected_fields,
                                     start_time=start_time, end_time=end_time_multi,
                                     batch_size=65536) as rs:
        batches = []
        while True:
            batch = rs.read_arrow_batch()
            if batch is None:
                break
            batches.append(batch)
    l0_multi = pa.concat_tables(batches).select(selected_fields).to_pandas().values

    pq_multi = pq.read_table(parquet_path,
                             filters=[("time", ">=", start_time), ("time", "<=", end_time_multi)],
                             columns=["time"] + selected_fields, use_threads=False).to_pandas()[selected_fields].values

    _check(errors, "Multi-series shape L0", l0_multi.shape, (num_points, n_cols))
    _check(errors, "Multi-series shape PQ", pq_multi.shape, (num_points, n_cols))
    _check_values(errors, "Multi L0 vs PQ head", l0_multi[:3], pq_multi[:3])

    l0_reader.close()
    l2_tsdf.close()

    # Summary
    if errors:
        print(f"\n  FAILED — {len(errors)} error(s):")
        for e in errors:
            print(f"    ✗ {e}")
        print(f"{'='*78}\n")
        sys.exit(1)
    else:
        print("  All checks passed.")
        print(f"{'='*78}\n")


def _check(errors, label, actual, expected):
    if actual != expected:
        errors.append(f"{label}: expected {expected}, got {actual}")
    else:
        print(f"    ✓ {label}: {actual}")


def _check_values(errors, label, a, b, atol=1e-6):
    a, b = np.asarray(a, dtype=np.float64), np.asarray(b, dtype=np.float64)
    if a.shape != b.shape:
        errors.append(f"{label}: shape mismatch {a.shape} vs {b.shape}")
    elif not np.allclose(a, b, atol=atol):
        errors.append(f"{label}: values differ — max delta {np.max(np.abs(a - b)):.8f}")
    else:
        print(f"    ✓ {label}")


# ── Main Benchmark ──────────────────────────────────────────────────────────

def run_benchmark(paths, iterations):
    cfg = paths["cfg"]
    ppd = cfg["points_per_device"]
    field_names = paths["field_names"]
    field_name = "f0"
    table_name = "bench"

    tsfile_path = paths["tsfile"]
    parquet_path = paths["parquet"]

    ts_size = os.path.getsize(tsfile_path)
    pq_size = os.path.getsize(parquet_path)

    print(f"\n{'='*78}")
    print(f"  Scale: {ppd:,} rows x {cfg['num_fields']} fields (single device, no TAG)")
    print(f"  File sizes: TsFile {ts_size/(1024*1024):.1f} MB | "
          f"Parquet {pq_size/(1024*1024):.1f} MB")
    print(f"{'='*78}")

    from tsfile import TsFileReader as CythonReader
    from iotdb_ai.tsfile.dataframe import TsFileDataFrame

    # Open persistent readers
    l0_reader = CythonReader(tsfile_path)
    l2_tsdf = TsFileDataFrame(tsfile_path, show_progress=False)
    l2_all_series = l2_tsdf.list_timeseries()
    l2_first = [s for s in l2_all_series if s.endswith(f".{field_name}")][0]

    # ── TEST 1: Single-series segment query ──────────────────────────────
    #
    # Query a contiguous block of rows for a single field.
    # No TAG column — query_table returns only this device's data.
    # Varying selectivity: 10%, 50%, 100%.

    print(f"\n  [1] Single-series segment query (field={field_name})")

    for pct_label, pct in [("10%", 0.1), ("50%", 0.5), ("100%", 1.0)]:
        num_points = max(1, int(ppd * pct))
        start_time = BASE_TS
        end_time = BASE_TS + (num_points - 1) * 1000

        print(f"\n      --- {pct_label} ({num_points:,} rows) ---")

        # L0: Raw Cython reader
        def l0_seg(st=start_time, et=end_time):
            with l0_reader.query_table_batch(table_name, [field_name],
                                       start_time=st, end_time=et, batch_size=65536) as rs:
                batches = []
                while True:
                    batch = rs.read_arrow_batch()
                    if batch is None:
                        break
                    batches.append(batch)
            return pa.concat_tables(batches).column(field_name).to_numpy()

        # L2: TsFileDataFrame.loc
        def l2_seg(st=start_time, et=end_time, sn=l2_first):
            return l2_tsdf.loc[st:et, [sn]]

        # PQ: PyArrow with filter pushdown
        def pq_seg(st=start_time, et=end_time):
            return pq.read_table(parquet_path,
                                 filters=[("time", ">=", st), ("time", "<=", et)],
                                 columns=["time", field_name],use_threads=False).column(field_name).to_numpy()

        t_l0 = measure(l0_seg, warmup=0, iterations=iterations)
        t_l2 = measure(l2_seg, warmup=0, iterations=iterations)
        t_pq = measure(pq_seg, warmup=0, iterations=iterations)

        r_l0_pq = np.mean(t_l0) / np.mean(t_pq) if np.mean(t_pq) > 0 else float('inf')
        r_l2_pq = np.mean(t_l2) / np.mean(t_pq) if np.mean(t_pq) > 0 else float('inf')

        print(f"      L0 TsFile (Cython):      {_fmt(np.mean(t_l0)):>12} ± {_fmt(np.std(t_l0))}")
        print(f"      L2 TsFileDataFrame:      {_fmt(np.mean(t_l2)):>12} ± {_fmt(np.std(t_l2))}")
        print(f"      PQ Parquet (PyArrow):     {_fmt(np.mean(t_pq)):>12} ± {_fmt(np.std(t_pq))}")
        print(f"      L0/PQ = {r_l0_pq:.2f}x  |  L2/PQ = {r_l2_pq:.2f}x  |  L2/L0 = {np.mean(t_l2)/np.mean(t_l0):.2f}x")

    # ── TEST 2: Multi-series time-range query ────────────────────────────
    #
    # Query multiple fields in one time range (same device, multiple columns).
    # L0: one query_table call with multiple field columns
    # L2: tsdf.loc[t1:t2, [series1, series2, ...]]
    # PQ: pq.read_table with multiple columns

    print(f"\n\n  [2] Multi-series time-range query (multiple fields)")

    # All series are fields of the single device
    all_fields = [s.split(".")[-1] for s in l2_all_series]

    series_counts = [2, min(len(l2_all_series), 5)]
    if len(l2_all_series) >= 10:
        series_counts.append(10)
    series_counts = sorted(set(series_counts))

    for n_cols in series_counts:
        selected_series = l2_all_series[:n_cols]
        selected_fields = all_fields[:n_cols]

        for pct_label, pct in [("10%", 0.1), ("50%", 0.5)]:
            num_points = max(1, int(ppd * pct))
            start_time = BASE_TS
            end_time = BASE_TS + (num_points - 1) * 1000

            print(f"\n      --- {n_cols} fields x {pct_label} ({num_points:,} rows) ---")

            # L0: Raw Cython reader — single query_table with all field columns
            def l0_multi(st=start_time, et=end_time, flds=selected_fields):
                with l0_reader.query_table_batch(table_name, flds,
                                           start_time=st, end_time=et, batch_size=65536) as rs:
                    batches = []
                    while True:
                        batch = rs.read_arrow_batch()
                        if batch is None:
                            break
                        batches.append(batch)

                table = pa.concat_tables(batches)
                return table.select(flds).to_pandas().values

            # L2: TsFileDataFrame.loc — aligned multi-series query
            def l2_multi(st=start_time, et=end_time, sl=selected_series):
                return l2_tsdf.loc[st:et, sl]

            # PQ: PyArrow — read_table with column projection
            def pq_multi(st=start_time, et=end_time, flds=selected_fields):
                table = pq.read_table(parquet_path,
                                      filters=[("time", ">=", st), ("time", "<=", et)],
                                      columns=["time"] + flds, use_threads=False)
                return table.to_pandas().values

            t_l0 = measure(l0_multi, warmup=0, iterations=iterations)
            t_l2 = measure(l2_multi, warmup=0, iterations=iterations)
            t_pq = measure(pq_multi, warmup=0, iterations=iterations)

            r_l0_pq = np.mean(t_l0) / np.mean(t_pq) if np.mean(t_pq) > 0 else float('inf')
            r_l2_pq = np.mean(t_l2) / np.mean(t_pq) if np.mean(t_pq) > 0 else float('inf')

            print(f"      L0 TsFile (Cython):      {_fmt(np.mean(t_l0)):>12} ± {_fmt(np.std(t_l0))}")
            print(f"      L2 TsFileDataFrame:      {_fmt(np.mean(t_l2)):>12} ± {_fmt(np.std(t_l2))}")
            print(f"      PQ Parquet (PyArrow):     {_fmt(np.mean(t_pq)):>12} ± {_fmt(np.std(t_pq))}")
            print(f"      L0/PQ = {r_l0_pq:.2f}x  |  L2/PQ = {r_l2_pq:.2f}x  |  L2/L0 = {np.mean(t_l2)/np.mean(t_l0):.2f}x")

    # Cleanup
    l0_reader.close()
    l2_tsdf.close()

    print(f"\n{'='*78}")
    print(f"  Benchmark complete!")
    print(f"{'='*78}")


def main():
    parser = argparse.ArgumentParser(
        description="TsFile Native Reader vs TsFileDataFrame vs Parquet")
    parser.add_argument("--scale", default="small",
                        choices=["small", "medium", "large"])
    parser.add_argument("--iterations", type=int, default=5)
    parser.add_argument("--output-dir", default=BENCHMARK_DIR)
    args = parser.parse_args()

    print("=" * 78)
    print("  TsFile Native Reader vs TsFileDataFrame vs Parquet")
    print("  L0: Raw Cython  |  L2: TsFileDataFrame  |  PQ: PyArrow Parquet")
    print("=" * 78)

    paths = ensure_data(args.scale, args.output_dir)
    run_benchmark(paths, args.iterations)


if __name__ == "__main__":
    main()
