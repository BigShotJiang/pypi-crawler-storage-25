"""
Generate test TsFile files for TsFileDataFrame testing.

Creates 3 test files:
1. weather.tsfile: table=weather, TAG=location(Beijing/Shanghai), FIELD=(humidity, temperature)
2. sensor.tsfile: table=sensor, TAG=device_id(s1/s2), FIELD=(pressure, battery_level)
3. weather_extra.tsfile: table=weather, TAG=location(Beijing), FIELD=(humidity, temperature)
   - Same series as weather.tsfile Beijing but DIFFERENT time range (next day), for cross-file merge testing
"""

import os
import sys
import numpy as np
import pandas as pd

from tsfile.utils import dataframe_to_tsfile
from tsfile import to_dataframe

OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "data")

# Base timestamp: 2026-01-28 00:00:00 UTC+8 in milliseconds
BASE_TS = 1769443200000  # 2026-01-28 00:00:00 UTC+8


def generate_weather_tsfile(output_path):
    """
    Table: weather, TAG: location, FIELD: humidity, temperature
    Beijing: 288 points, 5-min interval (300000 ms), 2026-01-28 00:00 ~ 23:55
    Shanghai: 142 points, 10-min interval (600000 ms), 2026-01-28 00:10 ~ 23:50
    """
    np.random.seed(42)

    beijing_times = [BASE_TS + i * 300000 for i in range(288)]
    shanghai_base = BASE_TS + 600000  # 00:10
    shanghai_times = [shanghai_base + i * 600000 for i in range(142)]

    rows = []
    for t in beijing_times:
        rows.append({
            'time': t,
            'location': 'Beijing',
            'humidity': round(np.random.uniform(40, 90), 2),
            'temperature': round(np.random.uniform(-5, 10), 2),
        })
    for t in shanghai_times:
        rows.append({
            'time': t,
            'location': 'Shanghai',
            'humidity': round(np.random.uniform(50, 95), 2),
            'temperature': round(np.random.uniform(2, 15), 2),
        })

    df = pd.DataFrame(rows)
    dataframe_to_tsfile(df, output_path, table_name="weather", tag_column=["location"])
    print(f"  Created {output_path}: {len(df)} rows")
    return df


def generate_sensor_tsfile(output_path):
    """
    Table: sensor, TAG: device_id, FIELD: pressure, battery_level
    s1: 3600 points, 1-sec interval (1000 ms), 2026-01-28 08:00 ~ 09:00
    s2: 1800 points, 2-sec interval (2000 ms), 2026-01-28 08:00 ~ 09:00
    """
    np.random.seed(123)

    s1_base = BASE_TS + 8 * 3600 * 1000  # 08:00
    s1_times = [s1_base + i * 1000 for i in range(3600)]

    s2_base = s1_base
    s2_times = [s2_base + i * 2000 for i in range(1800)]

    rows = []
    for t in s1_times:
        rows.append({
            'time': t,
            'device_id': 's1',
            'pressure': round(np.random.uniform(990, 1030), 2),
            'battery_level': round(np.random.uniform(3.0, 4.2), 2),
        })
    for t in s2_times:
        rows.append({
            'time': t,
            'device_id': 's2',
            'pressure': round(np.random.uniform(980, 1020), 2),
            'battery_level': round(np.random.uniform(2.8, 4.0), 2),
        })

    df = pd.DataFrame(rows)
    dataframe_to_tsfile(df, output_path, table_name="sensor", tag_column=["device_id"])
    print(f"  Created {output_path}: {len(df)} rows")
    return df


def generate_weather_extra_tsfile(output_path):
    """
    Same table/TAG/FIELD as weather.tsfile, but Beijing data for the NEXT DAY.
    Beijing: 288 points, 5-min interval, 2026-01-29 00:00 ~ 23:55
    This tests cross-file merge of same-named series.
    """
    np.random.seed(999)

    next_day_base = BASE_TS + 24 * 3600 * 1000  # 2026-01-29 00:00:00
    beijing_times = [next_day_base + i * 300000 for i in range(288)]

    rows = []
    for t in beijing_times:
        rows.append({
            'time': t,
            'location': 'Beijing',
            'humidity': round(np.random.uniform(35, 85), 2),
            'temperature': round(np.random.uniform(-8, 8), 2),
        })

    df = pd.DataFrame(rows)
    dataframe_to_tsfile(df, output_path, table_name="weather", tag_column=["location"])
    print(f"  Created {output_path}: {len(df)} rows")
    return df


def verify_files():
    """Read back the created files and verify basic properties."""
    print("\nVerification:")

    # Verify weather.tsfile
    weather_path = os.path.join(OUTPUT_DIR, "weather.tsfile")
    df = to_dataframe(weather_path, table_name="weather")
    beijing_rows = df[df['location'] == 'Beijing']
    shanghai_rows = df[df['location'] == 'Shanghai']
    print(f"  weather.tsfile: {len(df)} rows total, Beijing={len(beijing_rows)}, Shanghai={len(shanghai_rows)}")
    assert len(beijing_rows) == 288, f"Expected 288 Beijing rows, got {len(beijing_rows)}"
    assert len(shanghai_rows) == 142, f"Expected 142 Shanghai rows, got {len(shanghai_rows)}"

    # Verify sensor.tsfile
    sensor_path = os.path.join(OUTPUT_DIR, "sensor.tsfile")
    df = to_dataframe(sensor_path, table_name="sensor")
    s1_rows = df[df['device_id'] == 's1']
    s2_rows = df[df['device_id'] == 's2']
    print(f"  sensor.tsfile: {len(df)} rows total, s1={len(s1_rows)}, s2={len(s2_rows)}")
    assert len(s1_rows) == 3600, f"Expected 3600 s1 rows, got {len(s1_rows)}"
    assert len(s2_rows) == 1800, f"Expected 1800 s2 rows, got {len(s2_rows)}"

    # Verify weather_extra.tsfile
    extra_path = os.path.join(OUTPUT_DIR, "weather_extra.tsfile")
    df = to_dataframe(extra_path, table_name="weather")
    beijing_rows = df[df['location'] == 'Beijing']
    print(f"  weather_extra.tsfile: {len(df)} rows total, Beijing={len(beijing_rows)}")
    assert len(beijing_rows) == 288, f"Expected 288 Beijing rows, got {len(beijing_rows)}"

    print("\nAll verifications passed!")


if __name__ == "__main__":
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # Clean up existing files
    for fname in ["weather.tsfile", "sensor.tsfile", "weather_extra.tsfile"]:
        fpath = os.path.join(OUTPUT_DIR, fname)
        if os.path.exists(fpath):
            os.remove(fpath)

    print("Generating test TsFile files...")
    generate_weather_tsfile(os.path.join(OUTPUT_DIR, "weather.tsfile"))
    generate_sensor_tsfile(os.path.join(OUTPUT_DIR, "sensor.tsfile"))
    generate_weather_extra_tsfile(os.path.join(OUTPUT_DIR, "weather_extra.tsfile"))

    verify_files()
    print("\nDone! Test files created in:", OUTPUT_DIR)
