import pyarrow.parquet as pq
import torch
from torch.utils.data import Dataset, DataLoader

class FlightDataset_parquet(Dataset):
    """
    更高效的 Parquet Dataset 实现
    通过指定 row_groups 来减少不必要的读取
    """

    def __init__(self, args,  Tag=None, transform=None):
        super().__init__()

        self.sel_len = args.seq_len
        self.transform = transform

        if Tag == 'training':
            parquet_path = "cache/training_small.parquet"
        elif Tag == 'val':
            parquet_path = "cache/test.parquet"
        elif Tag == 'test':
            parquet_path = "cache/test.parquet"
        else:
            raise ValueError(f'Invalid data_provider flag: {Tag}')

        # 获取 row group 信息
        self.parquet_file = pq.ParquetFile(parquet_path)

        # 只读取元数据获取总行数，不打开整个文件
        self.parquet_metadata = pq.read_metadata(parquet_path)
        self.total_rows = self.parquet_metadata.num_rows

        # 计算批次数量
        self.num_batches = self.total_rows // self.sel_len

        # 预计算每个 row group 的起始行
        self.row_group_offsets = []
        current_offset = 0
        for i in range(self.parquet_file.num_row_groups):
            row_group_metadata = self.parquet_file.metadata.row_group(i)
            num_rows = row_group_metadata.num_rows
            self.row_group_offsets.append((current_offset, num_rows))
            current_offset += num_rows

    def __len__(self):
        """返回批次数量"""
        return self.num_batches

    def __getitem__(self, idx):
        """
        更高效的实现：只读取包含目标行的 row groups
        """
        if idx >= self.num_batches:
            raise IndexError(f"索引 {idx} 超出范围，共有 {self.num_batches} 个批次")

        # 计算要读取的行范围
        start_row = idx * self.sel_len
        end_row = min((idx + 1) * self.sel_len, self.total_rows)
        # if start_row % 10000 == 0:
        #     print(start_row)

        # 确定需要读取哪些 row groups
        row_groups_to_read = []
        for rg_idx, (offset, num_rows) in enumerate(self.row_group_offsets):
            rg_end = offset + num_rows
            if not (rg_end <= start_row or offset >= end_row):
                row_groups_to_read.append(rg_idx)

        # 读取需要的 row groups
        table = self.parquet_file.read_row_groups(row_groups_to_read)

        # 计算在读取的数据中的偏移
        first_row_group_offset = self.row_group_offsets[row_groups_to_read[0]][0]
        slice_start = start_row - first_row_group_offset
        slice_end = end_row - first_row_group_offset

        # 提取指定范围的行
        batch_data = table.slice(offset=slice_start, length=slice_end - slice_start)

        # 转换为 DataFrame 然后 Tensor
        df_batch = batch_data.to_pandas()
        numpy_batch = df_batch.to_numpy()
        tensor_batch = torch.from_numpy(numpy_batch).float()

        if self.transform:
            tensor_batch = self.transform(tensor_batch)

        return tensor_batch

class Args(object):
    def __init__(self):
        self.seq_len = 1024

# 使用示例
if __name__ == "__main__":
    args = Args()
    dataset = FlightDataset_parquet(args=args, Tag='training')
    # 创建 DataLoader
    dataloader = DataLoader(
        dataset=dataset,
        batch_size=1024,
        shuffle=True,
        num_workers=4,
    )

    # 使用 DataLoader
    print(f"总批次数: {len(dataloader)}")

    # 迭代一个 epoch
    for batch_idx, batch_data in enumerate(dataloader):
        print(f"批次 {batch_idx}: 形状 {batch_data.shape}")

    # 获取数据集的元信息
    dataset = dataloader.dataset
    print(f"\n数据集信息:")
    print(f"总行数: {dataset.total_rows}")
    print(f"批次大小: {dataset.batch_size}")
    print(f"总批次数: {dataset.num_batches}")