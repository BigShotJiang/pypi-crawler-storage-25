"""
Test TsFileDataset with a real TsFile

This example demonstrates end-to-end usage with an actual TsFile.
"""

import torch
from torch.utils.data import DataLoader
from iotdb_ai import TsFileDataset


def test_basic_functionality():
    """Test basic dataset functionality"""
    print("=" * 60)
    print("Testing TsFileDataset with Real TsFile")
    print("=" * 60)
    
    # Create dataset
    print("\n1. Creating dataset...")
    dataset = TsFileDataset(
        tsfile_paths="tests/timebench.tsfile",  # Your TsFile path
        seq_len=96,      # Use past 96 time points
        pred_len=24,     # Predict next 24 points
        window_stride=10  # Slide 10 points each time
    )
    
    # Print dataset info
    info = dataset.get_info()
    print(f"   ✓ Dataset created")
    print(f"   - Series count: {info['series_count']}")
    print(f"   - Total windows: {info['total_windows']}")
    print(f"   - Input length: {info['seq_len']}")
    print(f"   - Prediction length: {info['pred_len']}")
    
    # Test single sample
    print("\n2. Testing single sample...")
    input_seq, target_seq = dataset[0]
    print(f"   ✓ Sample retrieved")
    print(f"   - Input shape: {input_seq.shape}")
    print(f"   - Target shape: {target_seq.shape}")
    print(f"   - Input range: [{input_seq.min():.2f}, {input_seq.max():.2f}]")
    print(f"   - Target range: [{target_seq.min():.2f}, {target_seq.max():.2f}]")
    
    # Test DataLoader
    print("\n3. Testing with DataLoader...")
    dataloader = DataLoader(
        dataset,
        batch_size=8,
        shuffle=True,
        num_workers=0  # Use 0 for Windows, 2-4 for Linux/Mac
    )
    
    batch_count = 0
    for inputs, targets in dataloader:
        print(f"   Batch {batch_count}: inputs={inputs.shape}, targets={targets.shape}")
        batch_count += 1
        if batch_count >= 3:  # Just test first 3 batches
            break
    
    print(f"   ✓ DataLoader works correctly")
    
    # Simple training simulation
    print("\n4. Simulating training loop...")
    model = torch.nn.Linear(96, 24)  # Simple model
    criterion = torch.nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    
    model.train()
    total_loss = 0
    for batch_idx, (inputs, targets) in enumerate(dataloader):
        # Forward pass
        outputs = model(inputs)
        loss = criterion(outputs, targets)
        
        # Backward pass
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        total_loss += loss.item()
        
        if batch_idx >= 5:  # Just test a few batches
            break
    
    avg_loss = total_loss / min(6, len(dataloader))
    print(f"   ✓ Training simulation completed")
    print(f"   - Average loss: {avg_loss:.4f}")
    
    print("\n" + "=" * 60)
    print("✓ All tests passed successfully!")
    print("=" * 60)


if __name__ == "__main__":
    try:
        test_basic_functionality()
    except FileNotFoundError as e:
        print(f"Error: {e}")
        print("\nPlease provide a valid TsFile path.")
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

