"""
TsFileDataset Basic Usage Examples
"""

import torch
from torch.utils.data import DataLoader
from iotdb_ai import TsFileDataset


def basic_example():
    """Basic usage example"""
    print("=" * 60)
    print("Basic Usage Example")
    print("=" * 60)
    
    # Create dataset
    dataset = TsFileDataset(
        tsfile_paths="data/example.tsfile",  # Replace with actual path
        seq_len=96,      # Input sequence length (e.g., past 4 days, 24 points per day)
        pred_len=24,     # Prediction length (e.g., next 1 day)
        window_stride=1  # Sliding window stride
    )
    
    # Print dataset info
    info = dataset.get_info()
    print(f"\nDataset Info:")
    print(f"  - Time series count: {info['series_count']}")
    print(f"  - Total windows: {info['total_windows']}")
    print(f"  - Input length: {info['seq_len']}")
    print(f"  - Prediction length: {info['pred_len']}")
    
    # Get a single sample
    input_seq, target_seq = dataset[0]
    print(f"\nSample shapes:")
    print(f"  - Input sequence: {input_seq.shape}")
    print(f"  - Target sequence: {target_seq.shape}")
    
    # Create DataLoader
    dataloader = DataLoader(
        dataset,
        batch_size=32,
        shuffle=True,
        num_workers=0  # Set to 0 for Windows users
    )
    
    # Iterate through data
    print(f"\nStarting data iteration...")
    for batch_idx, (inputs, targets) in enumerate(dataloader):
        print(f"  Batch {batch_idx}: inputs {inputs.shape}, targets {targets.shape}")
        if batch_idx >= 2:  # Show only first 3 batches
            break


def multi_file_example():
    """Multi-file usage example"""
    print("\n" + "=" * 60)
    print("Multi-File Usage Example")
    print("=" * 60)
    
    # Use multiple TsFile files
    dataset = TsFileDataset(
        tsfile_paths=[
            "data/file1.tsfile",
            "data/file2.tsfile",
            "data/file3.tsfile",
        ],
        seq_len=168,     # One week of hourly data
        pred_len=24,     # Predict next 24 hours
        window_stride=24  # Slide one day at a time
    )
    
    print(f"Total samples: {len(dataset)}")
    print(f"Time series count: {dataset.get_series_count()}")


def preload_example():
    """Preload mode example (use when memory is sufficient)"""
    print("\n" + "=" * 60)
    print("Preload Mode Example")
    print("=" * 60)
    
    # Enable preloading, all data loaded into memory at once
    dataset = TsFileDataset(
        tsfile_paths="data/example.tsfile",
        seq_len=96,
        pred_len=24,
        window_stride=1,
        preload=True  # Enable preloading
    )
    
    print(f"Data preloaded into memory")
    print(f"Total samples: {len(dataset)}")


def training_example():
    """Complete training example"""
    print("\n" + "=" * 60)
    print("Training Example")
    print("=" * 60)
    
    # Create dataset
    dataset = TsFileDataset(
        tsfile_paths="data/example.tsfile",
        seq_len=96,
        pred_len=24,
    )
    
    # Create DataLoader
    train_loader = DataLoader(
        dataset,
        batch_size=32,
        shuffle=True,
        num_workers=4,  # Multi-process loading
        pin_memory=True  # Speed up GPU transfer
    )
    
    # Simple model (example)
    class SimpleModel(torch.nn.Module):
        def __init__(self, seq_len, pred_len):
            super().__init__()
            self.linear = torch.nn.Linear(seq_len, pred_len)
        
        def forward(self, x):
            return self.linear(x)
    
    model = SimpleModel(96, 24)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    criterion = torch.nn.MSELoss()
    
    # Training loop
    print("\nStarting training...")
    model.train()
    for epoch in range(2):  # Train for 2 epochs as example
        total_loss = 0
        for batch_idx, (inputs, targets) in enumerate(train_loader):
            # Forward pass
            outputs = model(inputs)
            loss = criterion(outputs, targets)
            
            # Backward pass
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            
            total_loss += loss.item()
            
            if batch_idx % 10 == 0:
                print(f"  Epoch {epoch}, Batch {batch_idx}, Loss: {loss.item():.4f}")
        
        avg_loss = total_loss / len(train_loader)
        print(f"Epoch {epoch} finished, average loss: {avg_loss:.4f}")


if __name__ == "__main__":
    # Run examples
    # Note: Need to prepare TsFile files first
    
    try:
        basic_example()
    except FileNotFoundError:
        print("\nNote: Please prepare TsFile files first")
        print("You can export TsFile from IoTDB or use test data")
    
    # Other examples (need corresponding data files)
    # multi_file_example()
    # preload_example()
    # training_example()

