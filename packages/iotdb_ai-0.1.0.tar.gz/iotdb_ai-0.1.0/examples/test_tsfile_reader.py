"""
Test TsFileReader with official tsfile package

This example demonstrates how to use TsFileReader directly.
Note: You need a valid TsFile to run this example.
"""

from iotdb_ai.tsfile.reader import TsFileReader


def test_reader():
    """Test TsFileReader basic functionality"""
    
    # Replace with your actual TsFile path
    tsfile_path = "test.tsfile"
    
    try:
        # Create reader
        print("Opening TsFile...")
        reader = TsFileReader(tsfile_path)
        
        # Get all series
        series_list = reader.get_all_series()
        print(f"\nFound {len(series_list)} time series:")
        for i, series in enumerate(series_list[:5]):  # Show first 5
            print(f"  {i+1}. {series}")
        if len(series_list) > 5:
            print(f"  ... and {len(series_list) - 5} more")
        
        # Get series info
        if series_list:
            first_series = series_list[0]
            length = reader.get_series_length(first_series)
            print(f"\nFirst series: {first_series}")
            print(f"Data points: {length}")
            
            # Read data
            print("\nReading data...")
            data = reader.read_series(first_series)
            print(f"First 10 values: {data[:10]}")
            
            # Read range
            print("\nReading range [10:20]...")
            range_data = reader.read_series_range(first_series, 10, 20)
            print(f"Range values: {range_data}")
        
        # Close reader
        reader.close()
        print("\n✓ Test completed successfully!")
        
    except FileNotFoundError:
        print(f"\n✗ TsFile not found: {tsfile_path}")
        print("\nTo test this example:")
        print("  1. Export a TsFile from IoTDB")
        print("  2. Update tsfile_path in this script")
        print("  3. Run again")
    except Exception as e:
        print(f"\n✗ Error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    test_reader()

