"""
Baseline: Train a simple model using TsFileDataFrame with dataset_small data

Data characteristics (PVF dataset):
- 972 time series across 5 tsfiles
- Series format: pvf.<ps_id>.<sn>.<field> (e.g. pvf.10017.xxx.pac)
- Fields: pac, irradiance, surfacepressure, windspeed, etc.
- pac has ~47.7% NaN; some series contain garbage float64 values (~1e306)

Data cleaning:
- NaN/inf → 0.0
- Clip to float32 range before cast (prevents overflow → inf → NaN loss)
"""

import time
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from iotdb_ai import TsFileDataFrame
import numpy as np
import glob

F32_MAX = np.finfo(np.float32).max


class SimpleModel(nn.Module):
    def __init__(self, input_size=120):
        super().__init__()
        self.fc = nn.Sequential(
            nn.Linear(input_size, 64),
            nn.ReLU(),
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Linear(32, 1),
        )

    def forward(self, x):
        return self.fc(x)


def _clean_window(window: np.ndarray) -> np.ndarray:
    """NaN/inf → 0, clip to float32 range, reject garbage, cast to float32.

    PVF dataset contains garbage float64 values (~4.99e+306) that overflow
    to inf when cast to float32. The pipeline:
      1) NaN/inf → 0 (in float64)
      2) Clip to float32 safe range (in float64)
      3) Cast to float32
      4) Final safety: any residual inf/nan → 0 (defensive)
    """
    window = np.nan_to_num(window, nan=0.0, posinf=0.0, neginf=0.0)
    np.clip(window, -F32_MAX, F32_MAX, out=window)
    f32 = window.astype(np.float32)
    # Final safety: any remaining inf/nan in float32 → 0
    f32 = np.where(np.isfinite(f32), f32, np.float32(0.0))
    return f32


class TsFileWindowDataset(Dataset):
    """Wrap TsFileDataFrame as a PyTorch Dataset with sliding windows.

    Index build uses only metadata (len) — no data read at init time.
    Data cleaning (NaN, inf, float64 overflow) happens in __getitem__.
    """

    def __init__(self, tsdf, window_size=120, stride=60, field_filter=None):
        self.tsdf = tsdf
        self.window_size = window_size
        self.windows = []

        all_series = tsdf.list_timeseries()
        for series_name in all_series:
            # Optional: only use a specific field (e.g. "pac")
            if field_filter and not series_name.endswith(f".{field_filter}"):
                continue
            ts = tsdf[series_name]
            n = len(ts)
            if n < window_size:
                continue
            num_windows = (n - window_size) // stride + 1
            for w in range(num_windows):
                self.windows.append((series_name, w * stride))

        print(f"Index built: {len(self.windows)} windows "
              f"(field={field_filter or 'all'})")

    def __len__(self):
        return len(self.windows)

    def __getitem__(self, idx):
        series_name, start = self.windows[idx]
        ts = self.tsdf[series_name]
        window = ts[start : start + self.window_size]
        return torch.from_numpy(_clean_window(window))


def train():
    total_start = time.time()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}"
          + (f" ({torch.cuda.get_device_name(device)})" if device.type == "cuda" else ""))

    # ── 1. Data Loading ──────────────────────────────────────────────────────
    t_load = time.time()
    tsfile_paths = sorted(glob.glob("dataset_small/*.tsfile"))
    print(f"Found {len(tsfile_paths)} tsfiles")

    tsdf = TsFileDataFrame(tsfile_paths, show_progress=True)
    load_time = time.time() - t_load
    print(f"Total series: {len(tsdf)}")

    # ── 2. Index Build ───────────────────────────────────────────────────────
    t_index = time.time()
    dataset = TsFileWindowDataset(tsdf, window_size=120, stride=60,
                                  field_filter="pac")
    index_time = time.time() - t_index
    print(f"Dataset: {len(dataset)} windows")

    if len(dataset) == 0:
        print("No valid data, exiting.")
        tsdf.close()
        return

    loader = DataLoader(dataset, batch_size=32, shuffle=True,
                        num_workers=0, pin_memory=(device.type == "cuda"))

    model = SimpleModel(input_size=120).to(device)
    criterion = nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)

    # ── 3. Training ──────────────────────────────────────────────────────────
    skipped_batches = 0
    model.train()
    for epoch in range(3):
        total_loss = 0.0
        num_batches = 0
        epoch_skipped = 0
        t_epoch = time.time()

        for batch_idx, data in enumerate(loader):
            data = data.to(device)

            # Skip bad batches (inf/nan that somehow survived cleaning)
            if not torch.isfinite(data).all():
                epoch_skipped += 1
                continue

            optimizer.zero_grad()
            output = model(data)
            target = data.mean(dim=1, keepdim=True)
            loss = criterion(output, target)

            # Guard: skip step if loss is NaN/inf
            if not torch.isfinite(loss):
                epoch_skipped += 1
                continue

            loss.backward()
            # Gradient clipping to prevent explosion from large values
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()
            total_loss += loss.item()
            num_batches += 1

            if batch_idx % 100 == 0:
                print(f"  Epoch {epoch}, Batch {batch_idx}/{len(loader)}, "
                      f"Loss: {loss.item():.6f}")

        epoch_time = time.time() - t_epoch
        avg_loss = total_loss / max(num_batches, 1)
        skipped_batches += epoch_skipped
        print(f"Epoch {epoch} done — Avg Loss: {avg_loss:.6f}, "
              f"Time: {epoch_time:.1f}s, "
              f"Skipped: {epoch_skipped} batches")

    tsdf.close()
    total_time = time.time() - total_start

    # ── 4. Summary ───────────────────────────────────────────────────────────
    print("\n" + "=" * 60)
    print("Timing Summary")
    print("=" * 60)
    print(f"  TsFile loading (metadata):   {load_time:7.2f}s")
    print(f"  Index build (window index):  {index_time:7.2f}s")
    print(f"  Training (3 epochs):         {total_time - load_time - index_time:7.2f}s")
    print(f"  Total:                       {total_time:7.2f}s")
    print(f"  Skipped batches (bad data):  {skipped_batches}")
    print(f"  Dataset:  {len(dataset)} windows, "
          f"{len(loader)} batches/epoch")
    print("=" * 60)


if __name__ == "__main__":
    train()
