"""
TsFileDataFrame Usage Examples

Demonstrates how to use TsFileDataFrame for:
1. Browsing metadata (series list, stats)
2. Pre-training: random access with array-like slicing
3. Post-training: time-aligned multi-series queries
4. Integration with PyTorch training

Requires test data: python tests/generate_test_data.py
"""

import numpy as np
from iotdb_ai import TsFileDataFrame


def browse_metadata():
    """Load files and explore available time series."""
    print("=" * 60)
    print("1. Browse Metadata")
    print("=" * 60)

    tsdf = TsFileDataFrame([
        "tests/data/weather.tsfile",
        "tests/data/sensor.tsfile",
        "tests/data/weather_extra.tsfile",
    ], show_progress=False)

    # Print the overview table
    print(tsdf)
    print()

    # Total series count
    print(f"Total time series: {len(tsdf)}")
    print()

    # Filter by prefix
    print("Weather series:", tsdf.list_timeseries("weather"))
    print("Sensor s1 series:", tsdf.list_timeseries("sensor.s1"))
    print()

    # Access individual series stats
    ts = tsdf["weather.Beijing.humidity"]
    print(f"Series: {ts.name}")
    print(f"  Length: {len(ts)}")
    print(f"  Stats: {ts.stats}")

    tsdf.close()


def pretrain_random_access():
    """Pre-training scenario: random access to time series windows."""
    print("\n" + "=" * 60)
    print("2. Pre-training: Random Access")
    print("=" * 60)

    tsdf = TsFileDataFrame([
        "tests/data/weather.tsfile",
        "tests/data/sensor.tsfile",
    ], show_progress=False)

    num_series = len(tsdf)
    window_size = 100

    # Simulate random sampling like HuggingFace Datasets
    rng = np.random.default_rng(42)
    for i in range(5):
        # Pick a random series
        series_idx = rng.integers(0, num_series)
        ts = tsdf[series_idx]

        # Pick a random window
        if len(ts) <= window_size:
            continue
        start = rng.integers(0, len(ts) - window_size)
        window = ts[start:start + window_size]  # np.ndarray (100,)

        print(f"  Iteration {i}: series={ts.name}, "
              f"start={start}, window shape={window.shape}, "
              f"mean={window.mean():.2f}")

    tsdf.close()


def posttrain_aligned_query():
    """Post-training scenario: time-aligned multi-series analysis."""
    print("\n" + "=" * 60)
    print("3. Post-training: Aligned Query")
    print("=" * 60)

    tsdf = TsFileDataFrame([
        "tests/data/weather.tsfile",
    ], show_progress=False)

    # Get time range of Beijing data
    bj = tsdf["weather.Beijing.humidity"]
    start_time = bj.stats['start_time']
    # Query 2 hours of data
    end_time = start_time + 2 * 3600 * 1000

    # Aligned query: same tag group (Beijing) - perfectly aligned, no NaN
    data = tsdf.loc[start_time:end_time, [
        "weather.Beijing.humidity",
        "weather.Beijing.temperature",
    ]]
    print(f"Beijing humidity+temperature: shape={data.shape}, NaN count={np.isnan(data).sum()}")
    print(f"  First 3 rows:\n{data[:3]}")
    print()

    # Cross-tag query: different sample rates -> NaN where missing
    data = tsdf.loc[start_time:end_time, [
        "weather.Beijing.humidity",
        "weather.Shanghai.humidity",
    ]]
    nan_count = np.isnan(data).sum()
    print(f"Beijing vs Shanghai humidity: shape={data.shape}, NaN count={nan_count}")
    print(f"  (NaN expected: Beijing=5min interval, Shanghai=10min interval)")
    print()

    # Normalize like a typical post-training pipeline
    mean = np.nanmean(data, axis=0)
    std = np.nanstd(data, axis=0) + 1e-5
    normalized = (data - mean) / std
    print(f"Normalized: mean={np.nanmean(normalized, axis=0)}, std={np.nanstd(normalized, axis=0)}")

    tsdf.close()


def cross_file_merge():
    """Cross-file merge: same series spanning multiple files."""
    print("\n" + "=" * 60)
    print("4. Cross-file Merge")
    print("=" * 60)

    # weather.tsfile has Beijing 2026-01-28, weather_extra.tsfile has Beijing 2026-01-29
    tsdf = TsFileDataFrame([
        "tests/data/weather.tsfile",
        "tests/data/weather_extra.tsfile",
    ], show_progress=False)

    ts = tsdf["weather.Beijing.humidity"]
    print(f"Merged Beijing humidity: {len(ts)} points")
    print(f"  (288 from day1 + 288 from day2 = 576)")
    print(f"  First 3 values (day1): {ts[0:3]}")
    print(f"  Last 3 values (day2):  {ts[-3:]}")

    tsdf.close()


def pytorch_integration():
    """Integrate TsFileDataFrame with PyTorch training."""
    print("\n" + "=" * 60)
    print("5. PyTorch Integration")
    print("=" * 60)

    try:
        import torch
        from torch.utils.data import Dataset, DataLoader
    except ImportError:
        print("  PyTorch not available, skipping.")
        return

    class TsFileWindowDataset(Dataset):
        """Wrap TsFileDataFrame as a PyTorch Dataset for windowed access."""

        def __init__(self, tsdf, series_name, window_size, stride=1):
            self.ts = tsdf[series_name]
            self.window_size = window_size
            self.stride = stride
            self.num_windows = max(0, (len(self.ts) - window_size) // stride + 1)

        def __len__(self):
            return self.num_windows

        def __getitem__(self, idx):
            start = idx * self.stride
            window = self.ts[start:start + self.window_size]
            return torch.from_numpy(window.astype(np.float32))

    tsdf = TsFileDataFrame(["tests/data/sensor.tsfile"], show_progress=False)

    dataset = TsFileWindowDataset(tsdf, "sensor.s1.pressure", window_size=128, stride=64)
    loader = DataLoader(dataset, batch_size=16, shuffle=True)

    print(f"  Dataset: {len(dataset)} windows")
    print(f"  Batch count: {len(loader)}")

    for batch_idx, batch in enumerate(loader):
        print(f"  Batch {batch_idx}: shape={batch.shape}")
        if batch_idx >= 2:
            break

    tsdf.close()


if __name__ == "__main__":
    browse_metadata()
    pretrain_random_access()
    posttrain_aligned_query()
    cross_file_merge()
    pytorch_integration()
