"""
High-performance TsFile Dataset for PyTorch
"""

import os
from typing import List, Tuple, Union, Optional
import numpy as np
import torch
from torch.utils.data import Dataset


class TsFileDataset(Dataset):
    """
    Supports sliding window for time series AI tasks with optimized index structure
    for efficient data access.

    Args:
        tsfile_paths: TsFile file path(s), can be a single path or a list of paths
        length: Window length (total number of data points per sample)
        variables: Optional list of time series paths to include. If specified,
                   returns a matrix with shape (num_variables, length).
                   If None, uses all series independently (single variable mode).
        window_stride: Sliding window stride, default is 1
        preload: Whether to preload all data into memory, default is False

    Returns:
        - Single variable mode (variables=None): tensor of shape (length,)
        - Multi-variable mode (variables=[...]): tensor of shape (num_variables, length)

    Example:
        >>> # Single variable mode (default)
        >>> dataset = TsFileDataset(
        ...     tsfile_paths="data.tsfile",
        ...     length=120,
        ...     window_stride=1
        ... )
        >>> data = dataset[0]  # shape: (120,)
        >>>
        >>> # Multi-variable mode
        >>> dataset = TsFileDataset(
        ...     tsfile_paths="data.tsfile",
        ...     length=120,
        ...     variables=["table1.col1", "table1.col2", "table1.col3"],
        ...     window_stride=1
        ... )
        >>> data = dataset[0]  # shape: (3, 120)
    """
    
    def __init__(
        self,
        tsfile_paths: Union[str, List[str]],
        length: int,
        variables: Optional[List[str]] = None,
        window_stride: int = 1,
        preload: bool = False,
    ):
        super().__init__()

        # Parameter validation
        if length <= 0:
            raise ValueError("length must be positive")
        if window_stride <= 0:
            raise ValueError("window_stride must be positive")

        self.length = length
        self.variables = variables
        self.window_stride = window_stride
        self.preload = preload
        
        # Process file paths
        if isinstance(tsfile_paths, str):
            tsfile_paths = [tsfile_paths]
        
        self.tsfile_paths = []
        for path in tsfile_paths:
            if not os.path.exists(path):
                raise FileNotFoundError(f"TsFile not found: {path}")
            self.tsfile_paths.append(os.path.abspath(path))
        
        # Build index
        self._build_index()
        
        # Optional preloading
        if self.preload:
            self._preload_data()
    
    def _build_index(self):
        """
        Build efficient index structure

        Index structure depends on mode:
        - Single variable mode: Index each series independently
        - Multi-variable mode: Index windows across all specified variables together
        """
        from iotdb_ai.tsfile.reader import TsFileReader

        self.series_index = []
        total_windows = 0

        # Create readers for all files
        self._readers = {}
        for file_path in self.tsfile_paths:
            self._readers[file_path] = TsFileReader(file_path)

        if self.variables is not None:
            # Multi-variable mode: find common windows across all variables
            self._build_index_multi_variable()
        else:
            # Single variable mode: index each series independently
            self._build_index_single_variable()

        if self.total_windows == 0:
            raise ValueError("No valid time series found in the provided TsFiles")

    def _build_index_single_variable(self):
        """Build index for single variable mode (original behavior)"""
        total_windows = 0

        for file_path in self.tsfile_paths:
            reader = self._readers[file_path]
            series_list = reader.get_all_series()

            for series_path in series_list:
                data_length = reader.get_series_length(series_path)

                if data_length < self.length:
                    continue

                window_count = (data_length - self.length) // self.window_stride + 1

                if window_count > 0:
                    series_info = {
                        'file_path': file_path,
                        'series_path': series_path,
                        'data_length': data_length,
                        'window_count': window_count,
                        'window_start': total_windows,
                        'window_end': total_windows + window_count,
                        'reader': reader
                    }
                    self.series_index.append(series_info)
                    total_windows += window_count

        self.total_windows = total_windows

    def _build_index_multi_variable(self):
        """Build index for multi-variable mode"""
        # Find the reader and info for each variable
        self._variable_info = []

        for var_path in self.variables:
            found = False
            for file_path, reader in self._readers.items():
                if var_path in reader.series_info:
                    self._variable_info.append({
                        'series_path': var_path,
                        'reader': reader,
                        'data_length': reader.get_series_length(var_path)
                    })
                    found = True
                    break

            if not found:
                raise ValueError(f"Variable not found: {var_path}")

        # Find minimum length across all variables
        min_length = min(info['data_length'] for info in self._variable_info)

        if min_length < self.length:
            raise ValueError(
                f"Data length ({min_length}) is less than required window length ({self.length})"
            )

        # Calculate window count based on minimum length
        window_count = (min_length - self.length) // self.window_stride + 1
        self.total_windows = window_count
    
    def _preload_data(self):
        """Preload all data into memory using TsFileReader's cache"""
        if self.variables is not None:
            # Multi-variable mode
            print(f"Preloading {len(self.variables)} variables into memory...")
            for var_info in self._variable_info:
                var_info['reader'].cache_series_data(var_info['series_path'])
        else:
            # Single variable mode
            print(f"Preloading {len(self.series_index)} time series into memory...")
            for series_info in self.series_index:
                reader = series_info['reader']
                series_path = series_info['series_path']
                reader.cache_series_data(series_path)

        print(f"Preloading complete. Total windows: {self.total_windows}")
    
    def _locate_series(self, index: int) -> Tuple[dict, int]:
        """
        Locate the specific series and local window index based on global index
        
        Uses binary search to achieve O(log n) lookup complexity
        """
        left, right = 0, len(self.series_index) - 1
        
        while left <= right:
            mid = (left + right) // 2
            series_info = self.series_index[mid]
            
            if index < series_info['window_start']:
                right = mid - 1
            elif index >= series_info['window_end']:
                left = mid + 1
            else:
                # Found the corresponding series
                local_window_idx = index - series_info['window_start']
                return series_info, local_window_idx
        
        raise IndexError(f"Index {index} out of range")
    
    def __getitem__(self, index: int) -> torch.Tensor:
        """
        Get data sample at specified index

        Args:
            index: Global window index

        Returns:
            - Single variable mode: tensor of shape (length,)
            - Multi-variable mode: tensor of shape (num_variables, length)
        """
        if index < 0 or index >= self.total_windows:
            raise IndexError(f"Index {index} out of range [0, {self.total_windows})")

        if self.variables is not None:
            # Multi-variable mode
            return self._getitem_multi_variable(index)
        else:
            # Single variable mode
            return self._getitem_single_variable(index)

    def _getitem_single_variable(self, index: int) -> torch.Tensor:
        """Get data for single variable mode"""
        # Locate series and local index
        series_info, local_window_idx = self._locate_series(index)

        # Calculate data start position
        data_start = local_window_idx * self.window_stride
        data_end = data_start + self.length

        # Get data from reader (handles both cached and lazy loading)
        reader = series_info['reader']
        data_window = reader.read_series_range(
            series_info['series_path'],
            start=data_start,
            end=data_end
        )
        data_window = np.array(data_window, dtype=np.float32)

        return torch.from_numpy(data_window)

    def _getitem_multi_variable(self, index: int) -> torch.Tensor:
        """Get data for multi-variable mode"""
        # Calculate data start position
        data_start = index * self.window_stride
        data_end = data_start + self.length

        # Read data from all variables
        data_matrix = []
        for var_info in self._variable_info:
            reader = var_info['reader']
            data_window = reader.read_series_range(
                var_info['series_path'],
                start=data_start,
                end=data_end
            )
            data_matrix.append(data_window)

        # Stack into matrix: (num_variables, length)
        data_matrix = np.array(data_matrix, dtype=np.float32)

        return torch.from_numpy(data_matrix)
    
    def __len__(self) -> int:
        """Return total number of samples in the dataset"""
        return self.total_windows
    
    def get_series_count(self) -> int:
        """Return the number of time series"""
        if self.variables is not None:
            return len(self.variables)
        return len(self.series_index)

    def get_info(self) -> dict:
        """Return detailed information about the dataset"""
        info = {
            'total_windows': self.total_windows,
            'length': self.length,
            'window_stride': self.window_stride,
            'preload': self.preload,
            'files': self.tsfile_paths,
        }

        if self.variables is not None:
            info['mode'] = 'multi_variable'
            info['variables'] = self.variables
            info['num_variables'] = len(self.variables)
        else:
            info['mode'] = 'single_variable'
            info['series_count'] = len(self.series_index)

        return info

