"""
IoTDB AI Toolkit

High-performance time series machine learning toolkit, including:
- TsFileDataset: PyTorch Dataset for reading data directly from TsFile files
- TsFileDataFrame: Lazy-loaded unified view over multiple TsFile files
"""

from iotdb_ai.tsfile.dataset import TsFileDataset
from iotdb_ai.tsfile.dataframe import TsFileDataFrame

__version__ = "0.1.0"
__all__ = ["TsFileDataset", "TsFileDataFrame"]

