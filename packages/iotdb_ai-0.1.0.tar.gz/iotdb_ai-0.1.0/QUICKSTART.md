# IoTDB AI - 快速入门指南

本指南将帮助你快速开始使用 IoTDB AI Toolkit 进行时间序列模型训练。

## 前置要求

- Python >= 3.7
- PyTorch >= 1.7.0
- NumPy >= 1.19.0

## 安装

```bash
cd IoTDB-AI
pip install -e .
```

## 准备数据

### 方式1：从 IoTDB 导出 TsFile

如果你已经有 IoTDB 实例运行：

```bash
# 使用 IoTDB CLI 导出数据
./sbin/export-tsfile.sh -h 127.0.0.1 -p 6667 -u root -pw root \
  -s "root.sg1.**" -t "2024-01-01" -e "2024-12-31" -o "data.tsfile"
```

### 方式2：使用已有的 TsFile 文件

如果你已经有 TsFile 文件，可以直接使用。

## 第一个例子

创建 `train.py`：

```python
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from iotdb_ai import TsFileDataset

# 1. 创建数据集
dataset = TsFileDataset(
    tsfile_paths="data.tsfile",
    seq_len=96,      # 使用过去96个时间点
    pred_len=24,     # 预测未来24个时间点
    window_stride=1  # 每次移动1个时间点
)

print(f"数据集信息: {dataset.get_info()}")

# 2. 创建 DataLoader
train_loader = DataLoader(
    dataset,
    batch_size=32,
    shuffle=True,
    num_workers=4
)

# 3. 定义一个简单的模型
class SimpleForecaster(nn.Module):
    def __init__(self, seq_len, pred_len, hidden_size=128):
        super().__init__()
        self.lstm = nn.LSTM(1, hidden_size, batch_first=True)
        self.linear = nn.Linear(hidden_size, pred_len)
    
    def forward(self, x):
        # x shape: (batch, seq_len)
        x = x.unsqueeze(-1)  # (batch, seq_len, 1)
        out, _ = self.lstm(x)
        out = out[:, -1, :]  # 取最后一个时间步
        pred = self.linear(out)
        return pred

model = SimpleForecaster(seq_len=96, pred_len=24)
criterion = nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

# 4. 训练循环
print("开始训练...")
for epoch in range(10):
    total_loss = 0
    for batch_idx, (inputs, targets) in enumerate(train_loader):
        # 前向传播
        outputs = model(inputs)
        loss = criterion(outputs, targets)
        
        # 反向传播
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        total_loss += loss.item()
    
    avg_loss = total_loss / len(train_loader)
    print(f"Epoch {epoch+1}/10, Loss: {avg_loss:.4f}")

print("训练完成！")

# 5. 保存模型
torch.save(model.state_dict(), "forecaster.pth")
```

运行：

```bash
python train.py
```

## 常见使用场景

### 场景1：长序列预测

```python
# 使用7天数据预测未来1天
dataset = TsFileDataset(
    tsfile_paths="data.tsfile",
    seq_len=168,    # 7天 * 24小时
    pred_len=24,    # 1天
    window_stride=24  # 每次跳过1天，减少样本重叠
)
```

### 场景2：多文件训练

```python
# 训练集使用多个月份的数据
dataset = TsFileDataset(
    tsfile_paths=[
        "data/2024-01.tsfile",
        "data/2024-02.tsfile",
        "data/2024-03.tsfile",
    ],
    seq_len=96,
    pred_len=24,
)
```

### 场景3：小数据集快速训练

```python
# 小数据集全部加载到内存
dataset = TsFileDataset(
    tsfile_paths="data.tsfile",
    seq_len=96,
    pred_len=24,
    preload=True  # 关键：预加载
)

# 可以使用更多 workers
dataloader = DataLoader(dataset, batch_size=32, num_workers=8)
```

### 场景4：GPU 训练优化

```python
# GPU 训练配置
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = model.to(device)

dataloader = DataLoader(
    dataset,
    batch_size=64,
    shuffle=True,
    num_workers=4,
    pin_memory=True,  # 关键：加速 GPU 传输
    persistent_workers=True
)

for inputs, targets in dataloader:
    inputs = inputs.to(device)
    targets = targets.to(device)
    # ... 训练代码
```

## 性能调优

### 1. 选择合适的 batch_size

```python
# 测试不同的 batch_size
for batch_size in [16, 32, 64, 128]:
    dataloader = DataLoader(dataset, batch_size=batch_size)
    # 测试训练速度
```

### 2. 调整 num_workers

```python
# CPU 核心数的 2-4 倍通常效果最好
import multiprocessing
optimal_workers = min(multiprocessing.cpu_count() * 2, 8)

dataloader = DataLoader(dataset, num_workers=optimal_workers)
```

### 3. 使用合适的 window_stride

```python
# 大数据集：增大 stride 减少样本数
dataset = TsFileDataset(
    tsfile_paths="large_data.tsfile",
    seq_len=96,
    pred_len=24,
    window_stride=8  # 每次跳8个点
)
```

## 常见问题

### Q1: 找不到 TsFile 文件

**A:** 确保文件路径正确，使用绝对路径或相对于运行目录的路径。

```python
import os
file_path = os.path.abspath("data.tsfile")
dataset = TsFileDataset(tsfile_paths=file_path, ...)
```

### Q2: 内存不足

**A:** 使用懒加载模式（默认），不要设置 `preload=True`。

```python
# 默认懒加载，内存占用小
dataset = TsFileDataset(
    tsfile_paths="data.tsfile",
    seq_len=96,
    pred_len=24,
    window_stride=8  # 增大步长也可以减少内存
)
```

### Q3: 训练速度慢

**A:** 尝试以下优化：

1. 增加 `num_workers`
2. 使用 `pin_memory=True`（GPU训练）
3. 增大 `batch_size`
4. 小数据集使用 `preload=True`

```python
dataloader = DataLoader(
    dataset,
    batch_size=64,        # 增大
    num_workers=8,        # 增大
    pin_memory=True,      # GPU加速
    persistent_workers=True
)
```

### Q4: 如何查看数据集信息

**A:** 使用 `get_info()` 方法：

```python
dataset = TsFileDataset(...)
info = dataset.get_info()
print(f"时间序列数: {info['series_count']}")
print(f"总样本数: {info['total_windows']}")
print(f"文件列表: {info['files']}")
```

## 下一步

- 查看 `examples/` 目录获取更多示例
- 阅读 API 文档了解详细参数
- 参考架构文档理解实现细节

## 获取帮助

- 查看 [README.md](README.md) 了解更多功能
- 提交 Issue: https://github.com/apache/iotdb/issues
- 访问社区: https://iotdb.apache.org/

祝你使用愉快！🚀

