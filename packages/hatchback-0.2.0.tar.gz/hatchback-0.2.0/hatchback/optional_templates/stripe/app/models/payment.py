import uuid
from sqlalchemy import Column, DateTime, ForeignKey, Integer, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func

from app.config.database import Base


class Payment(Base):
    """A record of a payment / charge processed through Stripe."""

    __tablename__ = "payments"

    id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        unique=True,
        index=True,
    )
    tenant_id = Column(
        UUID(as_uuid=True), ForeignKey("tenants.id"), nullable=False, index=True
    )
    user_id = Column(
        UUID(as_uuid=True), ForeignKey("users.id"), nullable=True, index=True
    )
    subscription_id = Column(
        UUID(as_uuid=True), ForeignKey("subscriptions.id"), nullable=True, index=True
    )

    # Stripe identifiers
    stripe_payment_intent_id = Column(String(100), nullable=True, unique=True, index=True)
    stripe_checkout_session_id = Column(String(100), nullable=True, unique=True, index=True)
    stripe_invoice_id = Column(String(100), nullable=True, index=True)
    stripe_customer_id = Column(String(100), nullable=True, index=True)

    amount = Column(Integer, nullable=False, default=0)  # in smallest currency unit
    currency = Column(String(10), nullable=False, default="usd")

    # succeeded, processing, requires_payment_method, canceled, failed, refunded, ...
    status = Column(String(30), nullable=False, default="pending")

    description = Column(String(500), nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
