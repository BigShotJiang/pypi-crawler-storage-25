import uuid
from sqlalchemy import Boolean, Column, DateTime, Integer, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from app.config.database import Base


class Plan(Base):
    """A subscription/product plan, typically mirrored from a Stripe Price/Product."""

    __tablename__ = "plans"

    id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        unique=True,
        index=True,
    )
    name = Column(String(100), nullable=False)
    description = Column(String(500), nullable=True)

    # Stripe identifiers
    stripe_product_id = Column(String(100), nullable=True, index=True)
    stripe_price_id = Column(String(100), nullable=False, unique=True, index=True)

    # Pricing (stored in the smallest currency unit, e.g. cents)
    amount = Column(Integer, nullable=False, default=0)
    currency = Column(String(10), nullable=False, default="usd")
    interval = Column(String(20), nullable=True)  # "month", "year", or null for one-time

    is_active = Column(Boolean, default=True, nullable=False)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    subscriptions = relationship("Subscription", back_populates="plan")
