import logging
import os
from datetime import datetime, timezone
from uuid import UUID

import stripe
from sqlalchemy.orm import Session

from app.models.payment import Payment
from app.models.subscription import Subscription
from app.repositories.payment import PaymentRepository
from app.repositories.plan import PlanRepository
from app.repositories.subscription import SubscriptionRepository

logger = logging.getLogger(__name__)


def _to_datetime(ts):
    if ts is None:
        return None
    try:
        return datetime.fromtimestamp(int(ts), tz=timezone.utc)
    except (TypeError, ValueError):
        return None


class PaymentService:
    """Stripe integration + persistence of plans, subscriptions and payments."""

    def __init__(self, db: Session):
        self.db = db
        self.api_key = os.getenv("STRIPE_API_KEY")
        self.webhook_secret = os.getenv("STRIPE_WEBHOOK_SECRET")

        if not self.api_key:
            logger.warning(
                "STRIPE_API_KEY not set. Stripe payment endpoints will fail until it is configured."
            )
        stripe.api_key = self.api_key

        self.plan_repo = PlanRepository(db)
        self.subscription_repo = SubscriptionRepository(db)
        self.payment_repo = PaymentRepository(db)

    # ---------------------------------------------------------------- Stripe API

    def create_checkout_session(
        self,
        price_id: str,
        success_url: str,
        cancel_url: str,
        quantity: int = 1,
        mode: str = "payment",
        customer_email: str | None = None,
        metadata: dict | None = None,
    ):
        return stripe.checkout.Session.create(
            mode=mode,
            line_items=[{"price": price_id, "quantity": quantity}],
            success_url=success_url,
            cancel_url=cancel_url,
            customer_email=customer_email,
            metadata=metadata or {},
        )

    def create_customer(self, email: str, name: str | None = None, metadata: dict | None = None):
        return stripe.Customer.create(email=email, name=name, metadata=metadata or {})

    def construct_webhook_event(self, payload: bytes, signature: str):
        if not self.webhook_secret:
            raise RuntimeError("STRIPE_WEBHOOK_SECRET is not configured.")
        return stripe.Webhook.construct_event(
            payload=payload,
            sig_header=signature,
            secret=self.webhook_secret,
        )

    # --------------------------------------------------------------- Persistence

    def handle_webhook_event(self, event) -> None:
        """Persist relevant state from a verified Stripe webhook event."""
        event_type = event["type"]
        data = event["data"]["object"]

        if event_type == "checkout.session.completed":
            self._record_checkout_session(data)
        elif event_type in (
            "payment_intent.succeeded",
            "payment_intent.payment_failed",
            "payment_intent.canceled",
        ):
            self._record_payment_intent(data)
        elif event_type in (
            "customer.subscription.created",
            "customer.subscription.updated",
            "customer.subscription.deleted",
        ):
            self._record_subscription(data)
        else:
            logger.debug("Stripe event %s ignored (no persistence handler).", event_type)

    # -- internal helpers -----------------------------------------------------

    def _resolve_tenant_id(self, metadata: dict | None) -> UUID | None:
        if not metadata:
            return None
        tid = metadata.get("tenant_id")
        if not tid:
            return None
        try:
            return UUID(str(tid))
        except (ValueError, AttributeError):
            return None

    def _record_checkout_session(self, session_obj):
        session_id = session_obj.get("id")
        payment_intent_id = session_obj.get("payment_intent")
        metadata = session_obj.get("metadata") or {}
        tenant_id = self._resolve_tenant_id(metadata)
        if tenant_id is None:
            logger.warning(
                "checkout.session.completed received without tenant_id metadata (session=%s); skipping persist.",
                session_id,
            )
            return

        existing = self.payment_repo.get_by_stripe_checkout_session_id(session_id)
        payment_status = session_obj.get("payment_status")
        normalized_status = "succeeded" if payment_status == "paid" else (payment_status or "pending")

        if existing:
            existing.status = normalized_status
            if payment_intent_id and not existing.stripe_payment_intent_id:
                existing.stripe_payment_intent_id = payment_intent_id
            self.db.commit()
            return

        payment = Payment(
            tenant_id=tenant_id,
            stripe_checkout_session_id=session_id,
            stripe_payment_intent_id=payment_intent_id,
            stripe_customer_id=session_obj.get("customer"),
            amount=session_obj.get("amount_total") or 0,
            currency=(session_obj.get("currency") or "usd").lower(),
            status=normalized_status,
            description="Stripe Checkout Session",
        )
        self.payment_repo.create(payment)

    def _record_payment_intent(self, pi):
        pi_id = pi.get("id")
        metadata = pi.get("metadata") or {}
        tenant_id = self._resolve_tenant_id(metadata)

        existing = self.payment_repo.get_by_stripe_payment_intent_id(pi_id)
        if existing:
            existing.status = pi.get("status", existing.status)
            existing.amount = pi.get("amount") or existing.amount
            existing.currency = (pi.get("currency") or existing.currency).lower()
            self.db.commit()
            return

        if tenant_id is None:
            logger.warning(
                "payment_intent %s received without tenant_id metadata; skipping persist.", pi_id
            )
            return

        payment = Payment(
            tenant_id=tenant_id,
            stripe_payment_intent_id=pi_id,
            stripe_customer_id=pi.get("customer"),
            amount=pi.get("amount") or 0,
            currency=(pi.get("currency") or "usd").lower(),
            status=pi.get("status", "pending"),
            description=pi.get("description"),
        )
        self.payment_repo.create(payment)

    def _record_subscription(self, sub):
        sub_id = sub.get("id")
        metadata = sub.get("metadata") or {}
        tenant_id = self._resolve_tenant_id(metadata)

        # Resolve plan via the price id of the first item.
        plan = None
        items = (sub.get("items") or {}).get("data") or []
        if items:
            price_id = (items[0].get("price") or {}).get("id")
            if price_id:
                plan = self.plan_repo.get_by_stripe_price_id(price_id)

        existing = self.subscription_repo.get_by_stripe_subscription_id(sub_id)
        if existing:
            existing.status = sub.get("status", existing.status)
            existing.current_period_start = _to_datetime(sub.get("current_period_start")) or existing.current_period_start
            existing.current_period_end = _to_datetime(sub.get("current_period_end")) or existing.current_period_end
            existing.canceled_at = _to_datetime(sub.get("canceled_at")) or existing.canceled_at
            if plan and not existing.plan_id:
                existing.plan_id = plan.id
            self.db.commit()
            return

        if tenant_id is None:
            logger.warning(
                "subscription %s received without tenant_id metadata; skipping persist.", sub_id
            )
            return

        subscription = Subscription(
            tenant_id=tenant_id,
            plan_id=plan.id if plan else None,
            stripe_subscription_id=sub_id,
            stripe_customer_id=sub.get("customer"),
            status=sub.get("status", "incomplete"),
            current_period_start=_to_datetime(sub.get("current_period_start")),
            current_period_end=_to_datetime(sub.get("current_period_end")),
            canceled_at=_to_datetime(sub.get("canceled_at")),
        )
        self.subscription_repo.create(subscription)
