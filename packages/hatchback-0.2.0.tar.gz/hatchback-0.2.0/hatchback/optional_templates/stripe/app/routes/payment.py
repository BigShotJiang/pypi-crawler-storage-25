import logging

from fastapi import APIRouter, Depends, Header, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.config.database import get_db
from app.dependencies import get_current_active_user
from app.models.user import User
from app.repositories.payment import PaymentRepository
from app.repositories.plan import PlanRepository
from app.repositories.subscription import SubscriptionRepository
from app.services.payment import PaymentService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/payments", tags=["Payments"])


def get_payment_service(db: Session = Depends(get_db)) -> PaymentService:
    return PaymentService(db)


class CheckoutSessionRequest(BaseModel):
    price_id: str
    success_url: str
    cancel_url: str
    quantity: int = 1
    mode: str = "payment"


@router.get("/plans")
def list_plans(db: Session = Depends(get_db)):
    return PlanRepository(db).get_active()


@router.get("/subscriptions/me")
def my_subscriptions(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    return SubscriptionRepository(db).get_by_tenant(current_user.tenant_id)


@router.get("/me")
def my_payments(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    return PaymentRepository(db).get_by_tenant(current_user.tenant_id)


@router.post("/checkout-session")
def create_checkout_session(
    payload: CheckoutSessionRequest,
    payment_service: PaymentService = Depends(get_payment_service),
    current_user: User = Depends(get_current_active_user),
):
    try:
        session = payment_service.create_checkout_session(
            price_id=payload.price_id,
            success_url=payload.success_url,
            cancel_url=payload.cancel_url,
            quantity=payload.quantity,
            mode=payload.mode,
            customer_email=current_user.email,
            # IMPORTANT: tenant_id/user_id are propagated so the webhook can
            # link the resulting Stripe objects back to the right rows.
            metadata={
                "tenant_id": str(current_user.tenant_id),
                "user_id": str(current_user.id),
            },
        )
        return {"id": session.id, "url": session.url}
    except Exception as e:
        logger.exception("Failed to create Stripe checkout session")
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/webhook")
async def stripe_webhook(
    request: Request,
    stripe_signature: str = Header(None, alias="stripe-signature"),
    payment_service: PaymentService = Depends(get_payment_service),
):
    payload = await request.body()
    try:
        event = payment_service.construct_webhook_event(payload, stripe_signature)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid payload")
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Webhook error: {e}")

    logger.info("Received Stripe event: %s", event["type"])
    try:
        payment_service.handle_webhook_event(event)
    except Exception:
        logger.exception("Failed to persist Stripe event %s", event["type"])
        # Still return 200 so Stripe doesn't retry indefinitely on a bug;
        # change to 500 if you prefer Stripe to retry on persistence errors.

    return {"received": True}
