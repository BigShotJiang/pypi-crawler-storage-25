from app.models.plan import Plan
from app.repositories.base import BaseRepository


class PlanRepository(BaseRepository):
    def __init__(self, db):
        super().__init__(db, Plan)

    def get_by_stripe_price_id(self, stripe_price_id: str):
        return (
            self.db.query(self.model)
            .filter(self.model.stripe_price_id == stripe_price_id)
            .first()
        )

    def get_active(self):
        return self.db.query(self.model).filter(self.model.is_active.is_(True)).all()
