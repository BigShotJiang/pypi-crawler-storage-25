from uuid import UUID

from app.models.payment import Payment
from app.repositories.base import BaseRepository


class PaymentRepository(BaseRepository):
    def __init__(self, db):
        super().__init__(db, Payment)

    def get_by_stripe_payment_intent_id(self, stripe_payment_intent_id: str):
        return (
            self.db.query(self.model)
            .filter(self.model.stripe_payment_intent_id == stripe_payment_intent_id)
            .first()
        )

    def get_by_stripe_checkout_session_id(self, stripe_checkout_session_id: str):
        return (
            self.db.query(self.model)
            .filter(self.model.stripe_checkout_session_id == stripe_checkout_session_id)
            .first()
        )

    def get_by_tenant(self, tenant_id: UUID):
        return (
            self.db.query(self.model)
            .filter(self.model.tenant_id == tenant_id)
            .order_by(self.model.created_at.desc())
            .all()
        )
