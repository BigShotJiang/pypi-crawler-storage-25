from uuid import UUID

from app.models.subscription import Subscription
from app.repositories.base import BaseRepository


class SubscriptionRepository(BaseRepository):
    def __init__(self, db):
        super().__init__(db, Subscription)

    def get_by_stripe_subscription_id(self, stripe_subscription_id: str):
        return (
            self.db.query(self.model)
            .filter(self.model.stripe_subscription_id == stripe_subscription_id)
            .first()
        )

    def get_by_tenant(self, tenant_id: UUID):
        return (
            self.db.query(self.model)
            .filter(self.model.tenant_id == tenant_id)
            .all()
        )

    def get_active_for_tenant(self, tenant_id: UUID):
        return (
            self.db.query(self.model)
            .filter(
                self.model.tenant_id == tenant_id,
                self.model.status.in_(["active", "trialing"]),
            )
            .first()
        )
