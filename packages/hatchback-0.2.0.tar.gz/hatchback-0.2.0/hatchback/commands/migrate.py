import os
import glob
import re
import subprocess
from ..utils import console, get_venv_executable

def handle_migrate(args):
    # Use python -m alembic instead of calling alembic executable directly
    # This is more robust across different venv setups
    python_cmd = get_venv_executable("python")
    
    if args.action == "create":
        if not args.message:
            console.print("[bold red]Error: Migration message is required for 'create'. Use -m 'message'[/bold red]")
            return
        console.print(f"[bold green]Creating migration: {args.message}[/bold green]")
        try:
            subprocess.run([python_cmd, "-m", "alembic", "revision", "--autogenerate", "-m", args.message], check=True)
            
            versions_dir = "alembic/versions"
            if os.path.exists(versions_dir):
                files = [f for f in glob.glob(os.path.join(versions_dir, "*.py")) if not os.path.basename(f).startswith("__")]
                if files:
                    newest_file = max(files, key=os.path.getctime)
                    max_num = 0
                    for f in files:
                        if f == newest_file:
                            continue
                        match = re.match(r"^(\d+)_", os.path.basename(f))
                        if match:
                            max_num = max(max_num, int(match.group(1)))
                    
                    next_num = max_num + 1
                    new_revision = str(next_num)
                    
                    # Read file and extract old revision
                    with open(newest_file, "r") as f:
                        content = f.read()

                    old_revision_match = re.search(r"^revision(?:\s*:\s*str)?\s*=\s*['\"]([^'\"]+)['\"]", content, re.MULTILINE)
                    if old_revision_match:
                        old_revision = old_revision_match.group(1)
                        
                        # Replace revision ID inside the file
                        content = content.replace(f"Revision ID: {old_revision}", f"Revision ID: {new_revision}")
                        content = re.sub(
                            r"(revision(?:\s*:\s*str)?\s*=\s*)['\"][^'\"]+['\"]",
                            f"\\1'{new_revision}'",
                            content,
                            count=1
                        )
                        
                        # Update down_revision to point to previous sequential number (if exists)
                        if max_num > 0:
                            content = re.sub(
                                r"(down_revision(?:\s*:\s*[^=]+)?\s*=\s*)['\"][^'\"]+['\"]",
                                f"\\1'{max_num}'",
                                content,
                                count=1
                            )
                        
                        with open(newest_file, "w") as f:
                            f.write(content)

                    # Rename file
                    base_name = os.path.basename(newest_file)
                    parts = base_name.split("_", 1)
                    slug = parts[1] if len(parts) > 1 else base_name
                    new_name = f"{next_num}_{slug}"
                    os.rename(newest_file, os.path.join(versions_dir, new_name))
                    console.print(f"[bold green]Renamed migration file to: {new_name}[/bold green]")
        except Exception as e:
            console.print(f"[bold red]Error creating migration:[/bold red] {e}")
            
    elif args.action == "apply":
        console.print("[bold green]Applying migrations...[/bold green]")
        try:
            subprocess.run([python_cmd, "-m", "alembic", "upgrade", "head"], check=True)
        except Exception as e:
            console.print(f"[bold red]Error applying migrations:[/bold red] {e}")

    elif args.action == "downgrade":
        revision = getattr(args, "revision", "-1")
        console.print(f"[bold yellow]Downgrading migration: {revision}[/bold yellow]")
        try:
            subprocess.run([python_cmd, "-m", "alembic", "downgrade", revision], check=True)
            console.print(f"[bold green]✅ Downgrade to '{revision}' complete.[/bold green]")
        except Exception as e:
            console.print(f"[bold red]Error downgrading migration:[/bold red] {e}")
