import os
import shutil
import sys
import subprocess
import secrets
from rich.prompt import Prompt, Confirm
from rich.panel import Panel
from rich.text import Text
from ..utils import console, play_intro

def handle_init(args):
    play_intro()
    console.print(Panel(
        "Welcome to Hatchback!\n\n"
        "This tool will help you bootstrap a production-ready FastAPI application.\n",
        title="Guide", border_style="green"
    ))
    
    project_name = args.project_name
    if not project_name:
        project_name = Prompt.ask("[bold green]Enter project name[/bold green] (leave empty to use current directory)")

    db_name = Prompt.ask("[bold green]Enter database name[/bold green]", default="app_db")

    should_install = args.install if args.install or args.no_install else Confirm.ask("[bold green]Create virtual environment and install requirements?[/bold green]", default=True)
    
    use_uv = False
    if should_install:
        uv_path = shutil.which("uv")
        if args.use_uv:
            if not uv_path:
                console.print("[yellow]Warning: --use-uv specified but 'uv' not found. Falling back to pip.[/yellow]")
            else:
                use_uv = True
        elif uv_path:
             use_uv = Confirm.ask("[bold green]uv found! Use uv for faster installation?[/bold green]", default=True)

    should_include_docker = args.docker if args.docker or args.no_docker else Confirm.ask("[bold green]Include Docker files?[/bold green]", default=True)

    should_include_stripe = args.stripe if args.stripe or args.no_stripe else Confirm.ask("[bold green]Include Stripe payment integration?[/bold green]", default=False)

    # Adjust package_dir to point to the parent of 'commands' (i.e., hatchback)
    # __file__ is .../hatchback/commands/init.py
    # os.path.dirname(__file__) is .../hatchback/commands
    # os.path.dirname(...) is .../hatchback
    package_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    template_dir = os.path.join(package_dir, "template")
    target_dir = os.path.join(os.getcwd(), project_name) if project_name else os.getcwd()
    
    console.print(f"\n🚗 Revving up your new FastAPI + Postgres backend in [bold yellow]{target_dir}[/bold yellow]...")
    
    try:
        with console.status("[bold green]Configuring FastAPI structure...[/bold green]", spinner="dots"):
            shutil.copytree(template_dir, target_dir, dirs_exist_ok=True)
            if not should_include_docker:
                for f in ["Dockerfile", "docker-compose.yml", ".dockerignore"]:
                    f_path = os.path.join(target_dir, f)
                    if os.path.exists(f_path):
                        os.remove(f_path)
            
            # Create .env file with chosen DB name and generated secret key
            env_example_path = os.path.join(target_dir, ".env.example")
            env_path = os.path.join(target_dir, ".env")
            if os.path.exists(env_example_path):
                with open(env_example_path, "r") as f:
                    env_content = f.read()
                
                # Replace default DB name if it exists, or append it
                if "DATABASE_NAME=" in env_content:
                    env_content = env_content.replace("DATABASE_NAME=boilerplate_db", f"DATABASE_NAME={db_name}")
                else:
                    env_content += f"\nDATABASE_NAME={db_name}\n"
                
                # Generate and set SECRET_KEY
                secret_key = secrets.token_urlsafe(32)
                if "SECRET_KEY=" in env_content:
                    # Replace existing placeholder if any, though .env.example usually has it empty or default
                    # We'll just append if it's not clearly replaceable, but let's assume we append or replace
                    # For now, let's just append it if it's not there, or replace the line if we can find a pattern
                    # But simpler: just append it if not present, or replace the specific default line
                    pass 
                
                # Actually, let's just append it to ensure it's set
                env_content += f"\nSECRET_KEY={secret_key}\n"

                with open(env_path, "w") as f:
                    f.write(env_content)

            if should_include_stripe:
                _apply_stripe_integration(package_dir, target_dir)
        
        console.print("[bold green]✅ Configuring FastAPI structure...[/bold green]")
        if should_include_docker:
             console.print("[bold green]✅ Configuring Docker Compose services...[/bold green]")
        console.print("[bold green]✅ Configuring Alembic migrations environment...[/bold green]")
        if should_include_stripe:
            console.print("[bold green]✅ Configuring Stripe payment integration...[/bold green]")

        if should_install:
            venv_dir = os.path.join(target_dir, "venv")
            
            if use_uv:
                with console.status("[bold green]Creating virtual environment with uv...[/bold green]", spinner="dots"):
                    subprocess.run(["uv", "venv", venv_dir], check=True, capture_output=True)
            else:
                with console.status("[bold green]Creating virtual environment...[/bold green]", spinner="dots"):
                    subprocess.run([sys.executable, "-m", "venv", venv_dir], check=True)
            console.print("[bold green]✓ Virtual environment created.[/bold green]")
            
            with console.status("[bold green]Installing requirements...[/bold green]", spinner="dots"):
                if use_uv:
                    venv_python = os.path.join(venv_dir, "Scripts", "python.exe") if os.name == 'nt' else os.path.join(venv_dir, "bin", "python")
                    subprocess.run(["uv", "pip", "install", "-p", venv_python, "-r", os.path.join(target_dir, "requirements.txt")], check=True, capture_output=True)
                else:
                    pip_exe = os.path.join(venv_dir, "Scripts", "pip") if os.name == 'nt' else os.path.join(venv_dir, "bin", "pip")
                    subprocess.run([pip_exe, "install", "-r", os.path.join(target_dir, "requirements.txt")], check=True, capture_output=True)
            console.print("[bold green]✓ Dependencies installed.[/bold green]")
        
        db_started = False
        if should_include_docker:
            if Confirm.ask("[bold green]Start database container now?[/bold green]", default=True):
                try:
                    with console.status("[bold green]Starting database container...[/bold green]", spinner="dots"):
                        subprocess.run(["docker-compose", "up", "-d", "db"], cwd=target_dir, check=True, capture_output=True)
                    console.print("[bold green]✓ Database container started.[/bold green]")
                    db_started = True
                except subprocess.CalledProcessError:
                    console.print("[yellow]Warning: Failed to start Docker container. Make sure Docker is running.[/yellow]")
                except FileNotFoundError:
                    console.print("[yellow]Warning: docker-compose not found.[/yellow]")

        console.print(Panel("[bold green]✨ HATCHBACK COMPLETE! Your backend is ready to drive. ✨[/bold green]", expand=False))
        
        console.print("\n[bold blue]Hatchback CLI[/bold blue]")
        console.print("Usage: hatchback")
        console.print("\nAvailable commands:")
        console.print("  [green]init[/green]      Initialize a new project")
        console.print("  [green]run[/green]       Run the development server")
        console.print("  [green]migrate[/green]   Manage database migrations")
        console.print("  [green]make[/green]      Scaffold a new resource")
        console.print("  [green]remove[/green]    Remove a scaffolded resource")
        console.print("  [green]seed[/green]      Seed the database with initial data")
        console.print("  [green]inspect[/green]   Inspect existing DB and scaffold")
        console.print("  [green]upgrade[/green]   Sync latest skills and infra files")
        console.print("  [green]test[/green]      Run the test suite")
        console.print("\nRun 'hatchback --help' for more information.")
        
        next_steps = Text()
        next_steps.append("\n🚗 --- Next Steps --- 🚗\n", style="bold underline")
        if project_name: next_steps.append(f"- cd {project_name}\n")
        
        if should_include_docker and not db_started:
            next_steps.append("- docker-compose up -d db\n")
        elif not should_include_docker:
            next_steps.append("- (Ensure your Postgres database is running)\n")
            
        next_steps.append("- hatchback migrate create -m 'init'\n")
        next_steps.append("- hatchback migrate apply\n")
        next_steps.append("- hatchback seed\n")
        next_steps.append("- hatchback run\n")
        if should_include_stripe:
            next_steps.append("\n[bold]Stripe:[/bold] set STRIPE_API_KEY and STRIPE_WEBHOOK_SECRET in .env.\n")
            next_steps.append("Tables 'plans', 'subscriptions', 'payments' will be created by the initial migration above.\n")
        console.print(next_steps)
        
    except subprocess.CalledProcessError as e:
        console.print(f"[bold red]Error running command:[/bold red] {e.cmd}")
        if e.stderr:
            console.print(f"[red]{e.stderr.decode()}[/red]")
        if e.stdout:
            console.print(f"[dim]{e.stdout.decode()}[/dim]")
        sys.exit(1)
    except Exception as e:
        console.print(f"[bold red]Error initializing project:[/bold red] {e}")
        sys.exit(1)


def _apply_stripe_integration(package_dir: str, target_dir: str):
    """Copy the optional Stripe templates and wire them into the generated project."""
    stripe_src = os.path.join(package_dir, "optional_templates", "stripe")
    if not os.path.isdir(stripe_src):
        console.print("[yellow]Warning: Stripe template directory missing; skipping integration.[/yellow]")
        return

    # 1. Copy payment service + route files into the new project.
    shutil.copytree(stripe_src, target_dir, dirs_exist_ok=True)

    # 2. Append `stripe` to requirements.txt (if not already present).
    requirements_path = os.path.join(target_dir, "requirements.txt")
    if os.path.exists(requirements_path):
        with open(requirements_path, "r") as f:
            req_content = f.read()
        if "stripe" not in {line.strip().split("==")[0].split(">=")[0] for line in req_content.splitlines()}:
            if not req_content.endswith("\n"):
                req_content += "\n"
            req_content += "stripe\n"
            with open(requirements_path, "w") as f:
                f.write(req_content)

    # 3. Add Stripe env vars to .env (and .env.example for reference).
    for env_filename in (".env", ".env.example"):
        env_path = os.path.join(target_dir, env_filename)
        if not os.path.exists(env_path):
            continue
        with open(env_path, "r") as f:
            content = f.read()
        if "STRIPE_API_KEY=" not in content:
            if not content.endswith("\n"):
                content += "\n"
            content += "STRIPE_API_KEY=sk_test_your_stripe_key\n"
        if "STRIPE_WEBHOOK_SECRET=" not in content:
            content += "STRIPE_WEBHOOK_SECRET=whsec_your_webhook_secret\n"
        with open(env_path, "w") as f:
            f.write(content)

    # 4. Register the payment router in app/routes/__init__.py.
    routes_init = os.path.join(target_dir, "app", "routes", "__init__.py")
    if os.path.exists(routes_init):
        with open(routes_init, "r") as f:
            init_content = f.read()
        if "from .payment import router as payment_router" not in init_content:
            lines = init_content.splitlines()
            last_import_idx = -1
            for i, line in enumerate(lines):
                if line.startswith("from .") and "import router" in line:
                    last_import_idx = i
            if last_import_idx >= 0:
                lines.insert(last_import_idx + 1, "from .payment import router as payment_router")
            else:
                lines.insert(0, "from .payment import router as payment_router")

            # Append payment_router to the routers list.
            new_lines = []
            for line in lines:
                stripped = line.strip()
                if stripped.startswith("routers = [") and stripped.endswith("]") and "payment_router" not in stripped:
                    inside = stripped[len("routers = ["):-1].strip()
                    items = [s.strip() for s in inside.split(",") if s.strip()]
                    items.append("payment_router")
                    line = f"routers = [{', '.join(items)}]"
                new_lines.append(line)
            with open(routes_init, "w") as f:
                f.write("\n".join(new_lines) + "\n")

    # 5. Register new models so Alembic autogenerate picks them up.
    _register_in_init(
        os.path.join(target_dir, "app", "models", "__init__.py"),
        imports=[
            "from .plan import Plan",
            "from .subscription import Subscription",
            "from .payment import Payment",
        ],
        all_entries=["Plan", "Subscription", "Payment"],
    )

    # 6. Register new repositories.
    _register_in_init(
        os.path.join(target_dir, "app", "repositories", "__init__.py"),
        imports=[
            "from .plan import PlanRepository",
            "from .subscription import SubscriptionRepository",
            "from .payment import PaymentRepository",
        ],
        all_entries=["PlanRepository", "SubscriptionRepository", "PaymentRepository"],
    )


def _register_in_init(init_path: str, imports: list, all_entries: list):
    """Idempotently append `imports` and extend `__all__` in an __init__.py."""
    if not os.path.exists(init_path):
        return
    with open(init_path, "r") as f:
        content = f.read()

    for imp in imports:
        if imp not in content:
            if not content.endswith("\n"):
                content += "\n"
            # Insert before __all__ if present, else append.
            all_idx = content.find("__all__")
            if all_idx >= 0:
                content = content[:all_idx] + imp + "\n" + content[all_idx:]
            else:
                content += imp + "\n"

    # Update __all__ list if present.
    if "__all__" in content:
        import re
        match = re.search(r"__all__\s*=\s*\[([^\]]*)\]", content)
        if match:
            existing_raw = match.group(1)
            existing_items = [s.strip().strip('"').strip("'") for s in existing_raw.split(",") if s.strip()]
            for entry in all_entries:
                if entry not in existing_items:
                    existing_items.append(entry)
            new_all = ", ".join(f'"{e}"' for e in existing_items)
            content = content[: match.start()] + f"__all__ = [{new_all}]" + content[match.end():]

    with open(init_path, "w") as f:
        f.write(content)
