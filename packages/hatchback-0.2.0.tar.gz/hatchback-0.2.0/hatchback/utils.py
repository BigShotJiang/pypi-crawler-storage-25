import os
from rich.console import Console
from rich.text import Text
from rich.panel import Panel
from rich import box

console = Console()


# ANSI-Shadow block lettering for "HATCHBACK", stacked on two rows so it
# fits comfortably in an 80-column terminal (matches the look of the Claude
# Code / Copilot CLI splash screens).
_LOGO = r"""
██╗  ██╗  █████╗  ████████╗  ██████╗ ██╗  ██╗
██║  ██║ ██╔══██╗ ╚══██╔══╝ ██╔════╝ ██║  ██║
███████║ ███████║    ██║    ██║      ███████║
██╔══██║ ██╔══██║    ██║    ██║      ██╔══██║
██║  ██║ ██║  ██║    ██║    ╚██████╗ ██║  ██║
╚═╝  ╚═╝ ╚═╝  ╚═╝    ╚═╝     ╚═════╝ ╚═╝  ╚═╝
██████╗   █████╗   ██████╗ ██╗  ██╗
██╔══██╗ ██╔══██╗ ██╔════╝ ██║ ██╔╝
██████╔╝ ███████║ ██║      █████╔╝
██╔══██╗ ██╔══██║ ██║      ██╔═██╗
██████╔╝ ██║  ██║ ╚██████╗ ██║  ██╗
╚═════╝  ╚═╝  ╚═╝  ╚═════╝ ╚═╝  ╚═╝
"""


def play_intro():
    """Render the Hatchback CLI logo (static, no animation)."""
    body = Text()
    body.append("  Welcome to\n", style="dim")
    body.append(_LOGO, style="bold cyan")
    body.append("  The All-in-One Full-Stack Backend Solution\n", style="bold cyan")

    console.print(
        Panel(
            body,
            border_style="magenta",
            box=box.HEAVY,
            padding=(0, 2),
            expand=False,
        )
    )


def get_venv_executable(name):
    """Returns the path to the executable in the virtual environment if it exists."""
    if os.name == 'nt':
        path = os.path.join("venv", "Scripts", name + ".exe")
    else:
        path = os.path.join("venv", "bin", name)
    if os.path.exists(path):
        return path
    return name

def to_pascal_case(snake_str):
    return "".join(x.capitalize() for x in snake_str.lower().split("_"))
