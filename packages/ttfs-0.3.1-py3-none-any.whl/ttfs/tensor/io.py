import math
import enum
from typing import Any, Optional, Self
from ttfs.core.aggtype import (
    aggregate,
    aggregate_replace,
    aggregate_super_method,
    constexpr_function,
    get_scalar_tensor,
    triton_jit,
    gluon_jit_kernel,
    gluon_jit,
    triton_jit_kernel,
    is_not_none_may_constexpr,
)
import triton.language as tl
from triton.experimental.gluon import language as gl
from ttfs.core import sym
from ttfs.core import mp
from ttfs.core.ttdict import TTDict, TTOffsetDict, raw_ttdict
from ttfs.recorder.recorder import EventRecorder
from ttfs.tensor.blocked import (
    BlockedTensorDesc,
    BlockedTensorDescTMABase,
    BlockedTensorDescWithOffset,
)
from ttfs.tensor.mgr import TensorManagerBase
from triton.experimental.gluon.language.nvidia.blackwell import (
    tensor_memory_descriptor,
    mbarrier,
    allocate_tensor_memory
)
from triton.experimental.gluon.language.nvidia.hopper import tma, fence_async_shared
from triton.experimental.gluon.language.nvidia.ampere import async_copy as cp
from ttfs.gl.ops import async_copy_global_to_shared_ex as cp_async_copy_global_to_shared
from ttfs.core.logger import logger as LOGGER

@aggregate
class _IterVarDesc:
    value: tl.tensor
    multipler: tl.constexpr
    dim_names: tl.constexpr


@aggregate
class _TensorIterInfo:
    name: tl.constexpr
    multipler: tl.constexpr

@aggregate
class _InternalExtendIterInfo:
    iter_mode: tl.constexpr = "inline"
    offsets: Any = None
    smem_layout: tl.constexpr = None
    # store only means no smem (if pointer load) or single smem (TMA store).
    is_sync: tl.constexpr = False

    is_store: tl.constexpr = False
    # if not None, force bind this tensor to specific loop.
    smem_shape_override: tl.constexpr = None
    block_strides: TTDict | None = None

@aggregate
class _MainOffsetInfo:
    value: Any
    ext_key: tl.constexpr

@aggregate
class LoopInfo:
    dim: tl.constexpr 
    tensors_sym: tl.constexpr = ""
    stride: tl.constexpr = -1

@aggregate
class AsyncGroupInfo:
    name: tl.constexpr
    num_consumers: tl.constexpr = 1
    arrive_on_init: tl.constexpr = None
    num_stage: tl.constexpr = None
    # for standalone comms
    # user need to alloc their memory (currently smem or tmem).
    # note that first dim size must equal to num stage.
    init_phase: tl.constexpr = 0
    producer_only: tl.constexpr = False
    # if None, for legacy pipeline, use mbarrier for TMA only.
    # for ws pipeline, always use mbarrier. 
    use_mbarrier: tl.constexpr = None


@aggregate
class PipedCommInfoBase:
    num_consumers: tl.constexpr = 1
    arrive_on_init: tl.constexpr = None
    num_stage: tl.constexpr = None
    # for standalone comms
    # user need to alloc their memory (currently smem or tmem).
    # note that first dim size must equal to num stage.
    init_phase: tl.constexpr = 0
    producer_only: tl.constexpr = False
    # if None, for legacy pipeline, use mbarrier for TMA only.
    # for ws pipeline, always use mbarrier. 
    use_mbarrier: tl.constexpr = None
    

@aggregate
class PipedIterDescBase:
    desc: BlockedTensorDesc

@aggregate
class PipedIterInfoBase:
    iter_mode: tl.constexpr = "inline"
    offsets: Any = None
    smem_layout: tl.constexpr = None
    # store only means no smem (if pointer load) or single smem (TMA store).
    # is_sync: only used in legacy pipeline (with prefetch). for ws, no need to set this.
    is_sync: tl.constexpr = False

    is_store: tl.constexpr = False
    # if not None, force bind this tensor to specific loop.
    smem_shape_override: tl.constexpr = None
    # when we iter over a dim with a smaller block size, e.g. N * 192 with 128 block size, we may need this.
    # initially used with gather on [S, H * D] D == 192 2D tensor since TMA don't support 3D gather,
    # also triton don't support 192 tensor dim, so we split it into 128 + 64.
    block_strides: TTDict | None = None

@constexpr_function 
def _is_val_str(val):
    return isinstance(val, str)


@aggregate
class PipedIterInfo(PipedCommInfoBase, PipedIterInfoBase, PipedIterDescBase):
    pass

@aggregate(kw_only=True)
class PipedIterInfoV2(PipedIterInfo):
    desc: Optional[BlockedTensorDesc] = None

# PipedIterInfo()

@aggregate
class GatherInfo:
    inds: tl.tensor 
    dim: tl.constexpr # can be both int and sym (string)
    is_inds_local: tl.constexpr = False
    inds_mask: Optional[tl.tensor] = None

@aggregate(kw_only=True)
class _ExtXmemDesc(PipedCommInfoBase):
    block_shape: tl.constexpr
    dtype: tl.constexpr
    mem_type: tl.constexpr # smem or tmem
    layout: tl.constexpr
    disable_alloc: tl.constexpr = False

@triton_jit
def create_ext_xmem_desc(
    block_shape: tl.constexpr,
    dtype: tl.constexpr,
    mem_type: tl.constexpr, # smem or tmem
    layout: tl.constexpr,
):
    return _ExtXmemDesc(
        block_shape=block_shape,
        dtype=dtype,
        mem_type=mem_type,
        layout=layout,
    )

@triton_jit
def create_comm_only_desc():
    return _ExtXmemDesc(
        block_shape=[1],
        dtype=gl.float32,
        mem_type="smem",
        layout=gl.SwizzledSharedLayout(1, 1, 1, [0]),
    )

@triton_jit
def piped_cfg(
    num_stage: tl.constexpr,
    num_consumers: tl.constexpr = 1,
    arrive_on_init: tl.constexpr = None,
    init_phase: tl.constexpr = 0,
    producer_only: tl.constexpr = False,
    use_mbarrier: tl.constexpr = None,
    iter_mode: tl.constexpr = tl.constexpr("inline"),
    is_sync: tl.constexpr = False,
    is_store: tl.constexpr = False,
    smem_shape_override: tl.constexpr = None,
    smem_layout: tl.constexpr = None,
):
    return PipedIterInfoV2(
        num_stage=num_stage,
        num_consumers=num_consumers,
        arrive_on_init=arrive_on_init,
        init_phase=init_phase,
        producer_only=producer_only,
        use_mbarrier=use_mbarrier,
        iter_mode=iter_mode,
        is_sync=is_sync,
        is_store=is_store,
        smem_shape_override=smem_shape_override,
        smem_layout=smem_layout,
    )

@triton_jit
def sync_cfg(
    num_smem_buffer: tl.constexpr = 1,
    num_consumers: tl.constexpr = 1,
    arrive_on_init: tl.constexpr = None,
    init_phase: tl.constexpr = 0,
    producer_only: tl.constexpr = False,
    use_mbarrier: tl.constexpr = None,
    iter_mode: tl.constexpr = tl.constexpr("inline"),
    is_store: tl.constexpr = False,
    smem_shape_override: tl.constexpr = None,
    smem_layout: tl.constexpr = None,
):
    return PipedIterInfoV2(
        num_stage=num_smem_buffer,
        num_consumers=num_consumers,
        arrive_on_init=arrive_on_init,
        init_phase=init_phase,
        producer_only=producer_only,
        use_mbarrier=use_mbarrier,
        iter_mode=iter_mode,
        is_sync=True,
        is_store=is_store,
        smem_shape_override=smem_shape_override,
        smem_layout=smem_layout,
    )

@aggregate(kw_only=True)
class _GroupCommInfo:
    info: AsyncGroupInfo
    remain_group: tl.constexpr
    nbytes: tl.constexpr
    use_mbarrier: tl.constexpr
    is_store: tl.constexpr
    is_sync: tl.constexpr
    is_xmem: tl.constexpr
    is_tma: tl.constexpr
    producer_ready_bars: Any = None
    consumer_finish_bars: Any = None

    @triton_jit
    def wait_producer_ready_bar(self, idx, phase):
        tl.static_assert(self.use_mbarrier, "wait_producer only support mbarrier group")
        mbarrier.wait(self.producer_ready_bars.index(idx), phase)

    @triton_jit
    def get_profile_metadata(self):
        return raw_ttdict(
            nbytes=self.nbytes,
            num_stage=self.info.num_stage,
            num_consumers=self.info.num_consumers,
        )

@triton_jit 
def _modify_offset_cw_for_gather(scalar_offset_cws, inds, is_inds_local: tl.constexpr, inds_dim: tl.constexpr):
    if is_inds_local:
        scalar_offset_cws = [
            scalar_offset_cws[i]
            if i != inds_dim else 
            mp.TritonField(scalar_offset_cws[i].value + inds)
            for i in tl.tuple(
                sym.tuple_range(len(scalar_offset_cws)))
        ]
    else:
        scalar_offset_cws = [
            scalar_offset_cws[i]
            if i != inds_dim else 
            mp.TritonField(inds)
            for i in tl.tuple(
                sym.tuple_range(len(scalar_offset_cws)))
        ]
    return scalar_offset_cws


@aggregate(kw_only=True)
class IteratorGroupBase:
    # loop_key_to_iters: TTDict
    tensor_dim_name_to_iter_desc: TTDict
    # dict[iter_uniq_name, _IterDesc], iter_uniq_name is (dim_name, multipler)
    iter_counters: TTDict
    # store blocked tensor descs
    descs: TTDict
    # desc name to _InternalExtendIterInfo
    desc_info_dict: TTDict
    # we have three kind of pointer io
    # 1. use ptr + inline generated offsets. this can avoid store registers for ptrs/offsets, but need to do some calculation.
    # 2. use ptr + iter offsets. use 1 64 bit ptr register and offset registers, have some pointer add before load.
    # 3. use pointers. use more 64-bit registers, some pointer add during increment.
    # so when we load from pointers, we look for pointer_offsets first, then pointers,
    # finally use pointer stored in descs.

    pointer_offsets: TTDict

    pointers: TTDict
    # we may want to reuse iters from a for loop instead of create a new one.
    loop_iter_name: tl.constexpr = ""
    recorder: Optional[EventRecorder] = None
    record_waits: tl.constexpr = True
    record_pipeline_index: tl.constexpr = True

    @triton_jit
    def _get_num_prefetch_cw(self):
        return mp.TritonConstexprField(0)

    @triton_jit
    def prepare_recorder(self, part_idx: tl.constexpr, name: tl.constexpr = None):
        if self.recorder is not None:
            return aggregate_replace(
                self,
                recorder=self.recorder.prepare(part_idx, name=name)
            )
        else:
            return self

    @triton_jit
    def finalize_recorder(self):
        if self.recorder is not None:
            return aggregate_replace(
                self,
                recorder=self.recorder.finalize()
            )
        else:
            return self

    @triton_jit
    def record_raw_profile_event(self, is_start: tl.constexpr, args: TTDict = TTDict(), _frame_cnt: tl.constexpr = 3):
        if self.recorder is not None:
            return aggregate_replace(
                self,
                recorder=self.recorder.record_profile_event(is_start, args, _frame_cnt=_frame_cnt)
            )
        else:
            return self

    @triton_jit
    def record_start_profile_event(self, name: tl.constexpr, thread_name: tl.constexpr = None, remain_args: TTDict = TTDict(), 
            user_scalar: tl.tensor | None = None, _frame_cnt: tl.constexpr = 3):
        if self.recorder is not None:
            static_args = raw_ttdict(
                name=name,
                thread_name=thread_name,
            )
            return aggregate_replace(
                self,
                recorder=self.recorder.record_profile_event(True, static_args.update(remain_args, check_unique=True), _frame_cnt=_frame_cnt, user_scalar=user_scalar)
            )
        else:
            return self

    @triton_jit
    def _get_start_profile_ts(self):
        if self.recorder is not None:
            return self.recorder.get_start_profile_ts()
        else:
            return 0

    @triton_jit
    def record_end_profile_event(self, name: tl.constexpr, thread_name: tl.constexpr = None, remain_args: TTDict = TTDict(), _frame_cnt: tl.constexpr = 3,
            ext_start_ts=None, user_scalar: tl.tensor | None = None):
        if self.recorder is not None:
            static_args = raw_ttdict(
                name=name,
                thread_name=thread_name,
            )
            return aggregate_replace(
                self,
                recorder=self.recorder.record_profile_event(False, static_args.update(remain_args, check_unique=True), _frame_cnt=_frame_cnt, ext_start_ts=ext_start_ts,
                    user_scalar=user_scalar)
            )
        else:
            return self

    @triton_jit
    def record_debug_event(self, args: TTDict, _frame_cnt: tl.constexpr = 3):
        if self.recorder is not None and not self.recorder.is_profile_only_cw().value:
            return aggregate_replace(
                self,
                recorder=self.recorder.record_debug_event(args, _frame_cnt=_frame_cnt)
            )
        else:
            return self

    @triton_jit
    def record_tensor_event(self, ten, args: TTDict = TTDict(), _frame_cnt: tl.constexpr = 3):
        if self.recorder is not None and not self.recorder.is_profile_only_cw().value and self.recorder.allow_tensor_event_cw().value:
            return aggregate_replace(
                self,
                recorder=self.recorder.record_tensor_event(ten, args, _frame_cnt=_frame_cnt)
            )
        else:
            return self

    @triton_jit
    def _increment_one(
        self, n_block_cw, dim_names_sym: tl.constexpr, tensor_name: tl.constexpr
    ):
        desc = self.descs.getitem(tensor_name).value
        filtered_dim_names_sym: tl.constexpr = sym.filter_not_included_sym(
            dim_names_sym, desc.shape_sym
        )
        filtered_dim_names_sym_parts: tl.constexpr = sym.get_shape_names_from_sym(
            filtered_dim_names_sym
        )
        tl.static_assert(
            len(filtered_dim_names_sym_parts) <= 1,
            "after filtering dim names with desc shape, there should be only one dim name left for increment",
        )
        if desc.is_tma_desc().value or len(filtered_dim_names_sym_parts) == 0:
            # tma descs only use iters. they will be incremented outside.
            return self
        else:
            inc_dim_name: tl.constexpr = filtered_dim_names_sym_parts[0]
            offset_key: tl.constexpr = sym.create_tree_id(tensor_name, inc_dim_name)
            block_size_cw = desc.get_block_size_cw_by_dim_name(inc_dim_name)
            block_stride_cw = desc.get_block_stride_cw_by_dim_name(inc_dim_name)

            if self.pointer_offsets.is_name_exists(offset_key).value:
                values_cw = self.pointer_offsets.getitem(offset_key)
                if values_cw.value.ext_key == "":
                    new_pointer_offs = self.pointer_offsets.replaceitem(
                        tensor_name,
                        mp.TritonField(
                            values_cw.value.value
                            + (
                                block_size_cw.value
                                * n_block_cw.value
                                * block_stride_cw.value
                            )
                        ),
                    )
                    return aggregate_replace(
                        self, pointer_offsets=new_pointer_offs
                    )
                else:
                    return self
            elif self.pointers.is_name_exists(tensor_name).value:
                pointer_cw = self.pointers.getitem(tensor_name)
                new_pointer = self.pointers.replaceitem(
                    tensor_name,
                    mp.TritonField(
                        pointer_cw.value
                        + (
                            block_size_cw.value
                            * n_block_cw.value
                            * block_stride_cw.value
                        )
                    ),
                )
                return aggregate_replace(self, pointers=new_pointer)
            else:
                # ptr + inline offset, not handled here.
                return self

    @triton_jit
    def increment(
        self,
        loop_name: tl.constexpr,
        n_block: tl.constexpr = 1,
        inc_store_iters: tl.constexpr = True,
    ) -> "Self":
        tl.static_assert(
            self.iter_counters.is_name_exists(loop_name).value,
            f"iter counter for loop {loop_name} not found",
        )
        iter_item = self.iter_counters.getitem(loop_name).value
        # TODO check dim names is valid.
        res_counters = self.iter_counters.replaceitem(
            loop_name,
            mp.TritonField(
                _IterVarDesc(
                    value=iter_item.value + n_block * iter_item.multipler,
                    multipler=iter_item.multipler,
                    dim_names=iter_item.dim_names,
                )
            ),
        )
        res = aggregate_replace(
            self,
            iter_counters=res_counters,
        )
        dim_names_sym: tl.constexpr = sym.names_to_sym(iter_item.dim_names)
        for i in tl.static_range(len(self.descs.keys)):
            info = self.desc_info_dict.getitem(
                tl.constexpr(self.descs.keys[i])
            ).value
            if inc_store_iters or not info.is_sync:
                res = res._increment_one(
                    mp.TritonConstexprField(n_block),
                    dim_names_sym,
                    tl.constexpr(self.descs.keys[i]),
                )
        return res

    @triton_jit
    def set_iter(
        self, loop_name: tl.constexpr, value, inc_store_iters: tl.constexpr = True
    ) -> "Self":
        tl.static_assert(
            self.iter_counters.is_name_exists(loop_name).value,
            f"iter counter for loop {loop_name} not found",
        )
        iter_item = self.iter_counters.getitem(loop_name).value
        # TODO check dim names is valid.
        prev_iter = iter_item.value
        n_iter_diff = value - (prev_iter // iter_item.multipler)
        res_counters = self.iter_counters.replaceitem(
            loop_name,
            mp.TritonField(
                _IterVarDesc(
                    value=value * iter_item.multipler,
                    multipler=iter_item.multipler,
                    dim_names=iter_item.dim_names,
                )
            ),
        )
        res = aggregate_replace(
            self,
            iter_counters=res_counters,
        )
        dim_names_sym: tl.constexpr = sym.names_to_sym(iter_item.dim_names)
        for i in tl.static_range(len(self.descs.keys)):
            info = self.desc_info_dict.getitem(
                tl.constexpr(self.descs.keys[i])
            ).value
            if inc_store_iters or not info.is_sync:
                res = res._increment_one(
                    mp.TritonField(n_iter_diff),
                    dim_names_sym,
                    tl.constexpr(self.descs.keys[i]),
                )
        return res

    @triton_jit
    def _get_offset_from_pointer_offs(self, desc, key: tl.constexpr, idx: tl.constexpr, layout_override: tl.constexpr = None):
        item = self.pointer_offsets.getitem(key)
        if item.value.ext_key != "":
            res = self.pointer_offsets.getitem(item.value.ext_key).value.value
        else:
            res = item.value.value
        if mp.is_gluon():
            return gl.convert_layout(res, desc.get_sliced_layout_for_offset(idx, layout_override))
        else:
            return res

    @triton_jit
    def _get_iter_value_cw(self, name: tl.constexpr, num_prefetch: tl.constexpr):
        if self.iter_counters.is_name_exists(name).value:
            iter_item = self.iter_counters.getitem(name).value
            return mp.TritonField(iter_item.value - num_prefetch * iter_item.multipler)
        else:
            return mp.TritonConstexprField(0)

    @triton_jit
    def _get_offset_from_iter_cws(
        self, tensor_name: tl.constexpr, desc: BlockedTensorDesc, num_prefetch: tl.constexpr = 0, ext_offset_cws=None,
        ext_block_offset_cws=None
    ):
        info = self.desc_info_dict.getitem(tensor_name).value

        if ext_offset_cws is not None:
            tl.static_assert(isinstance(ext_offset_cws, TTDict), "ext_offset_cws must be TTDict if not None")
            ext_offset_keys = [
                mp.TritonConstexprField(sym.create_tree_id(
                    tensor_name, ext_offset_cws.keys[i]
                ))
                for i in tl.tuple(sym.tuple_range(len(ext_offset_cws.keys)))
            ]
            ext_offset_cws = TTDict(
                ext_offset_cws.values_cw,
                sym.make_list_from_cws(ext_offset_keys),
            )
        if ext_block_offset_cws is not None:
            tl.static_assert(isinstance(ext_block_offset_cws, TTDict), "ext_block_offset_cws must be TTDict if not None")
            ext_offset_keys = [
                mp.TritonConstexprField(sym.create_tree_id(
                    tensor_name, ext_block_offset_cws.keys[i]
                ))
                for i in tl.tuple(sym.tuple_range(len(ext_block_offset_cws.keys)))
            ]
            ext_block_offset_cws = TTDict(
                ext_block_offset_cws.values_cw,
                sym.make_list_from_cws(ext_offset_keys),
            )

        dim_keys = [
            mp.TritonConstexprField(
                sym.create_tree_id(
                    tensor_name, desc.get_block_dim_name_by_idx_cw(i).value
                )
            )
            for i in tl.tuple(sym.tuple_range(len(desc.block_shape)))
        ]
        tensor_iter_infos = [
            self.tensor_dim_name_to_iter_desc.getitem(dim_keys[i].value).value
            if self.tensor_dim_name_to_iter_desc.is_name_exists(dim_keys[i].value).value
            else _TensorIterInfo("", 1)
            for i in tl.tuple(sym.tuple_range(len(desc.block_shape)))
        ]
        scalar_offset_cws = ()
        for i in tl.static_range(len(desc.block_shape)):
            if (ext_block_offset_cws is not None and ext_block_offset_cws.is_name_exists(dim_keys[i].value).value):
                if info.block_strides is not None and info.block_strides.is_name_exists(desc.get_block_dim_name_by_idx_cw(i).value).value:
                    block_stride: tl.constexpr = info.block_strides.getitem(desc.get_block_dim_name_by_idx_cw(i).value).value
                else:
                    block_stride: tl.constexpr = desc.block_shape[i]
                scalar_offset_cws += (mp.dispatch_value(ext_block_offset_cws.getitem(dim_keys[i].value).value * block_stride),)  

            elif (ext_offset_cws is not None and ext_offset_cws.is_name_exists(dim_keys[i].value).value):
                scalar_offset_cws += (ext_offset_cws.getitem(dim_keys[i].value),)  
            else:
                if self.tensor_dim_name_to_iter_desc.is_name_exists(dim_keys[i].value).value:
                    scalar_offset_cws += (
                        mp.cwrapped_mul(
                            self._get_iter_value_cw(tensor_iter_infos[i].name, num_prefetch),
                            mp.TritonConstexprField(tensor_iter_infos[i].multipler),
                        ),
                    )
                else:
                    scalar_offset_cws += (mp.TritonConstexprField(0),)
        return scalar_offset_cws

    @triton_jit
    def _get_pointer_offsets(self, desc_key: tl.constexpr, desc: BlockedTensorDesc, scalar_offset_cws, 
            layout_override: tl.constexpr = None, is_atomic_reduce: tl.constexpr = False):
        offsets = [
            self._get_offset_from_pointer_offs(
                desc, sym.create_tree_id(desc_key, desc.block_shape[i]), i,
                layout_override=layout_override,
            )
            if self.pointer_offsets.is_name_exists(
                sym.create_tree_id(desc_key, desc.block_shape[i])
            ).value
            else desc.get_blocked_offset_by_idx(
                i,
                expand_dims=True,
                out_of_range=0,
                use_i64=False,
                ext_offset_cw=scalar_offset_cws[i],
                is_atomic_reduce=is_atomic_reduce,
                layout_override=layout_override,
            )
            for i in tl.tuple(sym.tuple_range(len(desc.block_shape)))
        ]
        return offsets

    @triton_jit
    def _load_internal(
        self, tensor_name: tl.constexpr, apply_mask: tl.constexpr = True, other=None, force_mask_sym: tl.constexpr = None, 
        gather_info: GatherInfo | None = None, offsets: TTDict | None = None, block_offsets: TTDict | None = None, smem_index: int = 0,
        enable_record: tl.constexpr = False,
    ):
        desc = self.descs.getitem(tensor_name).value
        info = self.desc_info_dict.getitem(tensor_name).value
        if mp.is_gluon():
            # tl.static_assert(
            #     info.is_sync == True,
            #     f" {tensor_name}: sync load must set is_sync=True via `ttfs.io.PipedIterInfo`",
            # )
            assert not desc.is_tma_desc().value, (
                "gluon tma desc don't support load (sync, into regs), use load_async instead"
            )

        scalar_offset_cws = self._get_offset_from_iter_cws(tensor_name, desc, ext_offset_cws=offsets, ext_block_offset_cws=block_offsets)
        if gather_info is not None:
            if _is_val_str(gather_info.dim):
                gather_info = aggregate_replace(
                    gather_info,
                    dim=desc._get_dim_by_block_dim_name(gather_info.dim).value
                )
            # self = self.record_debug_event(("gather_sync", tensor_name, desc.get_json_data_cw(), gather_info.is_inds_local) + scalar_offset_cws)
        if enable_record:
            self = self.record_debug_event(raw_ttdict(
                name="load" if gather_info is None else "gather",
                is_sync=True,
                tensor_name=tensor_name,
                tensor_info=desc.get_json_data_cw(),
                offsets=scalar_offset_cws,
                is_inds_local=gather_info.is_inds_local if gather_info is not None else False,
            ))

        if desc.is_tma_desc().value:
            # triton only.
            if gather_info is not None:
                scalar_offset_cws = _modify_offset_cw_for_gather(scalar_offset_cws, gather_info.inds, gather_info.is_inds_local, gather_info.dim)
                return desc.tma_gather_cw(scalar_offset_cws, add_offset_to_inds=False), self
            else:
                return desc.tma_load_cw(scalar_offset_cws), self
        else:
            # pointer offsets
            offsets, mask_cw = self._prepare_offsets_masks_for_pointer_io(
                tensor_name, desc, 
                offset_cws=scalar_offset_cws,
                apply_mask=apply_mask,
                force_mask_sym=force_mask_sym,
                gather_info=gather_info,
            )
            if self.pointers.is_name_exists(tensor_name).value:
                # pointers already incremented, just load
                pointers = self.pointers.getitem(tensor_name).value
                return tl.load(pointers, mask=mask_cw.value, other=other), self
            else:
                return tl.load(
                    desc.get_blocked_ptrs_from_offsets(offsets), mask=mask_cw.value, other=other
                ), self

    @triton_jit
    def _store_internal(
        self, tensor_name: tl.constexpr, value, apply_mask: tl.constexpr = True, reduce_kind: tl.constexpr = None,
        cast_to_default_layout: tl.constexpr = False, force_mask_sym: tl.constexpr = None,
        gather_info: GatherInfo | None = None, offsets: TTDict | None = None, block_offsets: TTDict | None = None,
        smem_index: int = 0, enable_record: tl.constexpr = False,
    ):
        desc = self.descs.getitem(tensor_name).value

        scalar_offset_cws = self._get_offset_from_iter_cws(
            tensor_name, desc, self._get_num_prefetch_cw().value, ext_offset_cws=offsets, ext_block_offset_cws=block_offsets
        )
        if gather_info is not None:
            if _is_val_str(gather_info.dim):
                gather_info = aggregate_replace(
                    gather_info,
                    dim=desc._get_dim_by_block_dim_name(gather_info.dim).value
                )
        if enable_record:
            self = self.record_debug_event(raw_ttdict(
                name="scatter" if gather_info is not None else "store",
                is_sync=True,
                tensor_name=tensor_name,
                tensor_info=desc.get_json_data_cw(),
                is_inds_local=gather_info.is_inds_local if gather_info is not None else False,
                reduce_kind=reduce_kind,
                offsets=scalar_offset_cws,
            ))

        if gather_info is not None:
            scalar_offset_cws = _modify_offset_cw_for_gather(scalar_offset_cws, gather_info.inds, gather_info.is_inds_local, gather_info.dim)

        if desc.is_tma_desc().value:
            if gather_info is not None:
                tl.static_assert(reduce_kind is None, "tma store don't support atomic scatter")
            if gather_info is None:
                if mp.is_gluon():
                    self._sync_store_internal_for_tma(smem_index, scalar_offset_cws, value, tensor_name, reduce_kind=reduce_kind)
                else:
                    desc.tma_store_cw(scalar_offset_cws, value, reduce_kind=reduce_kind)
            else:
                if mp.is_gluon():
                    self._sync_scatter_internal_for_tma(smem_index, scalar_offset_cws, value, tensor_name, reduce_kind=reduce_kind)
                else:
                    desc.tma_scatter_cw(scalar_offset_cws, value, reduce_kind=reduce_kind)
            return self
        else:
            # pointer offsets
            is_atomic_reduce: tl.constexpr = reduce_kind is not None
            if mp.is_gluon():
                if self.pointers.is_name_exists(tensor_name).value:
                    final_layout: tl.constexpr = self.pointers.getitem(tensor_name).value.type.layout
                else:
                    if cast_to_default_layout:
                        final_layout: tl.constexpr = desc.get_io_layout_cw(is_atomic_reduce).value
                    else:
                        final_layout: tl.constexpr = value.type.layout
                value = gl.convert_layout(value, final_layout)
            else:
                final_layout: tl.constexpr = None
            offsets, mask_cw = self._prepare_offsets_masks_for_pointer_io(
                tensor_name, desc, 
                offset_cws=scalar_offset_cws,
                apply_mask=apply_mask,
                force_mask_sym=force_mask_sym,
                gather_info=gather_info,
            )
            if self.pointers.is_name_exists(tensor_name).value:
                # pointers already incremented, just load
                pointers = self.pointers.getitem(tensor_name).value
            else:
                pointers = desc.get_blocked_ptrs_from_offsets(offsets)
            if reduce_kind is None:
                tl.store(pointers, value, mask=mask_cw.value)
            else:
                if reduce_kind == "add":
                    tl.atomic_add(pointers, value, mask=mask_cw.value)
                elif reduce_kind == "max":
                    tl.atomic_max(pointers, value, mask=mask_cw.value)
                elif reduce_kind == "min":
                    tl.atomic_min(pointers, value, mask=mask_cw.value)
                elif reduce_kind == "and":
                    tl.atomic_and(pointers, value, mask=mask_cw.value)
                elif reduce_kind == "or":
                    tl.atomic_or(pointers, value, mask=mask_cw.value)
                elif reduce_kind == "xor":
                    tl.atomic_xor(pointers, value, mask=mask_cw.value)
                else:
                    tl.static_assert(
                        False, f"unsupported reduce kind {reduce_kind} for atomic store"
                    )
            return self

    @triton_jit
    def _prepare_offsets_masks_for_pointer_io(self, tensor_name: tl.constexpr, desc, 
            offset_cws, apply_mask: tl.constexpr, 
            force_mask_sym: tl.constexpr, 
            gather_info: GatherInfo | None = None,
            final_layout: tl.constexpr = None,
            is_atomic_reduce: tl.constexpr = False,):
        offsets = self._get_pointer_offsets(tensor_name, desc, offset_cws, layout_override=final_layout, is_atomic_reduce=is_atomic_reduce)
        if gather_info is not None:
            offsets = [
                offsets[i]
                if i != gather_info.dim else 
                (offsets[i] + desc.unslice_1d_offset_by_idx(gather_info.inds, i) if gather_info.is_inds_local else desc.unslice_1d_offset_by_idx(gather_info.inds, i))
                for i in tl.tuple(
                    sym.tuple_range(len(desc.block_shape)))
            ]
        except_axis: tl.constexpr = -1 if gather_info is None else gather_info.dim
        if apply_mask and desc.is_need_block_mask(force_mask_sym=force_mask_sym, except_axis=except_axis).value:
            block_dims_is_divisible = desc._get_block_axes_is_divisible(force_mask_sym=force_mask_sym, except_axis=except_axis)
            masks = [
                offsets[block_dims_is_divisible.value[i]]
                < desc.get_dim_size_by_block_dim(
                    block_dims_is_divisible.value[i]
                ).value
                for i in tl.tuple(
                    sym.tuple_range(len(block_dims_is_divisible.value))
                )
            ]
            mask = masks[0]
            for i in tl.static_range(1, len(masks)):
                mask = mask & masks[i]
            if gather_info is not None and gather_info.inds_mask is not None:
                mask = mask & gather_info.inds_mask
        else:
            if gather_info is not None and gather_info.inds_mask is not None:
                mask = gather_info.inds_mask
            else:
                mask = None
        return offsets, mp.TritonField(mask)


    @triton_jit
    def _sync_store_internal_for_tma(self, smem_index, offset_cws, value, tensor_name: tl.constexpr, reduce_kind: tl.constexpr = None):
        tl.static_assert(False, "not implemented for base class")

    @triton_jit
    def _sync_scatter_internal_for_tma(self, smem_index, offset_cws, value, tensor_name: tl.constexpr, reduce_kind: tl.constexpr = None):
        tl.static_assert(False, "not implemented for base class")

    @triton_jit
    def load(self, tensor_name: tl.constexpr, gather_info: GatherInfo | None = None, offsets: TTDict | None = None, block_offsets: TTDict | None = None):
        return self._load_internal(tensor_name, apply_mask=False, gather_info=gather_info, offsets=offsets, block_offsets=block_offsets)[0]

    @triton_jit
    def masked_load(self, tensor_name: tl.constexpr, other=None, force_mask_sym: tl.constexpr = None, gather_info: GatherInfo | None = None, offsets: TTDict | None = None, block_offsets: TTDict | None = None):
        return self._load_internal(tensor_name, apply_mask=True, other=other, force_mask_sym=force_mask_sym, gather_info=gather_info, offsets=offsets, block_offsets=block_offsets)[0]

    @triton_jit
    def store(self, 
            tensor_name: tl.constexpr, value, 
            reduce_kind: tl.constexpr = None, 
            cast_to_default_layout: tl.constexpr = False, 
            apply_mask: tl.constexpr = False,
            gather_info: GatherInfo | None = None,
            offsets: TTDict | None = None,
            block_offsets: TTDict | None = None,
            smem_index=0,
        ):
        return self._store_internal(tensor_name, value, apply_mask=apply_mask, reduce_kind=reduce_kind, 
            cast_to_default_layout=cast_to_default_layout, gather_info=gather_info, offsets=offsets,
            smem_index=smem_index, block_offsets=block_offsets)

    @triton_jit
    def masked_store(self, 
            tensor_name: tl.constexpr, 
            value, 
            reduce_kind: tl.constexpr = None, 
            cast_to_default_layout: tl.constexpr = False, 
            apply_mask: tl.constexpr = True, 
            force_mask_sym: tl.constexpr = None,
            gather_info: GatherInfo | None = None,
            offsets: TTDict | None = None,
            block_offsets: TTDict | None = None,
            smem_index=0,
        ):
        return self._store_internal(tensor_name, value, apply_mask=apply_mask, reduce_kind=reduce_kind, 
            cast_to_default_layout=cast_to_default_layout, force_mask_sym=force_mask_sym, gather_info=gather_info,
            offsets=offsets, smem_index=smem_index, block_offsets=block_offsets)

    @triton_jit
    def close(self):
        return
    
    @triton_jit
    def get_tensor_manager(self):
        """WARNING: this assume all descs use same TensorManagerBase.
        """
        mgr = self.descs.values_cw[0].value.mgr 
        return mgr

    @triton_jit
    def _offset_tensor(self, desc, offs: TTOffsetDict):
        if isinstance(desc, BlockedTensorDescTMABase):
            return desc.offset_by_dict_if_exists(offs)
        elif isinstance(desc, BlockedTensorDescWithOffset):
            block_sym_global: tl.constexpr = sym.local_sym_to_global(
                desc.shape_sym, desc.block_shape_sym
            )

            offs_no_block = offs.filter_by_sym_exclude(block_sym_global)
            offs_block = offs.filter_by_sym_include(block_sym_global)
            return aggregate_replace(
                desc,
                ptr=desc.detached_dims.get_offseted_ptr(
                    desc,
                    offs_no_block.keys,
                    offs_no_block.values_cw,
                ),
                named_offsets=desc.named_offsets.add_offsets_if_exists(
                    offs_block.keys,
                    offs_block.values_cw
                )
            ) 
        else:
            # BlockedTensorDesc

            return aggregate_replace(
                desc,
                ptr=desc.detached_dims.get_offseted_ptr(
                    desc,
                    offs_no_block.keys,
                    offs_no_block.values_cw,
                ),
            ) 

    @triton_jit
    def offset_all_tensor(self, named_offs: TTOffsetDict):
        """Offset tensor descriptors without change ptrs.
        usually used in dimensions that may be out of boundry, e.g. sequence dimension.

        WARNING: this assume all descs use same TensorManagerBase.
        """
        new_values_cw = [
            mp.TritonField(
                self._offset_tensor(
                    self.descs.values_cw[i].value,
                    named_offs,
                )
            )
            for i in tl.tuple(sym.tuple_range(len(self.descs.keys)))
        ]
        new_descs = TTDict(
            keys=self.descs.keys,
            values_cw=new_values_cw,
        )
        return aggregate_replace(
            self,
            descs=new_descs,
        )


@triton_jit
def _get_tensor_pointers(tensors: TTDict):
    pointers_keys_bools = [
        mp.TritonConstexprField(False)
        if (
            not isinstance(tensors.values_cw[i].value, PipedIterInfo)
            or (tensors.values_cw[i].value.desc.is_tma_desc().value)
            or (tensors.values_cw[i].value.iter_mode != "pointers")
        )
        else mp.TritonConstexprField(True)
        for i in tl.tuple(sym.tuple_range(len(tensors.keys)))
    ]
    pointers_keys: tl.constexpr = sym.combine_tuple_cw_to_constexpr_list(
        mp.filter_tuple_by_bool_tuple_cw(
            [
                mp.TritonConstexprField(tensors.keys[i])
                for i in tl.tuple(sym.tuple_range(len(tensors.keys)))
            ],
            pointers_keys_bools,
        )
    )
    pointers_values = mp.filter_tuple_by_bool_tuple_cw(
        [
            mp.TritonConstexprField(-1)
            if (
                not isinstance(tensors.values_cw[i].value, PipedIterInfo)
                or (tensors.values_cw[i].value.desc.is_tma_desc().value)
                or (tensors.values_cw[i].value.iter_mode != "pointers")
            )
            else mp.TritonField(tensors.values_cw[i].value.desc.get_blocked_ptrs())
            for i in tl.tuple(sym.tuple_range(len(tensors.keys)))
        ],
        pointers_keys_bools,
    )
    pointers = TTDict(
        keys=pointers_keys,
        values_cw=pointers_values,
    )
    return pointers


@triton_jit
def _may_alloc_smem(
    info: PipedIterInfo, desc: BlockedTensorDesc, group_info: _GroupCommInfo
):
    if group_info.is_sync:
        # TMA sync store reqiures smem.
        # we rotating the store wait to pipeline TMA store in legacy pipeline (non-WS)
        # here the num_stage is usually used as num_split
        if desc.is_tma_desc().value or group_info.info.num_stage > 0:
            return mp.TritonField(desc.allocate_shared_memory(group_info.info.num_stage, info.smem_layout, info.smem_shape_override))
        else:
            return mp.TritonConstexprField(None)
    else:
        if group_info.info.num_stage == 0:
            return mp.TritonConstexprField(None)
        else:
            return mp.TritonField(desc.allocate_shared_memory(group_info.info.num_stage, info.smem_layout, info.smem_shape_override))

@triton_jit
def _may_alloc_ext_xmem(info: _ExtXmemDesc, group_info: _GroupCommInfo
):
    final_shape: tl.constexpr = sym.insert_front_item_to_list(group_info.info.num_stage, info.block_shape)
    if info.disable_alloc:
        return mp.TritonConstexprField(None)
    else:
        if info.mem_type == "tmem":
            return mp.TritonField(allocate_tensor_memory(info.dtype, final_shape, info.layout))
        else:
            return mp.TritonField(gl.allocate_shared_memory(info.dtype, final_shape, info.layout))

@triton_jit
def _alloc_tensor_smems(
    tensor_infos: TTDict,
    tensor_descs: TTDict,
    group_dict: TTDict,
    tensor_name_to_group: TTDict,
):
    smem_values = [
        _may_alloc_smem(
            tensor_infos.values_cw[i].value,
            tensor_descs.values_cw[i].value,
            group_dict.getitem(
                tensor_name_to_group.getitem(
                    tl.constexpr(tensor_infos.keys[i])
                ).value
            ).value,
        )
        for i in tl.tuple(sym.tuple_range(len(tensor_infos.keys)))
    ]
    tensor_smems = TTDict(
        keys=tensor_infos.keys,
        values_cw=smem_values,
    )
    return tensor_smems

@triton_jit
def _alloc_ext_xmems(
    xmem_dict: TTDict,
    group_dict: TTDict,
    tensor_name_to_group: TTDict,
):
    smem_values = [
        _may_alloc_ext_xmem(
            xmem_dict.values_cw[i].value,
            group_dict.getitem(
                tensor_name_to_group.getitem(
                    tl.constexpr(xmem_dict.keys[i])
                ).value
            ).value,
        )
        for i in tl.tuple(sym.tuple_range(len(xmem_dict.keys)))
    ]
    tensor_smems = TTDict(
        keys=xmem_dict.keys,
        values_cw=smem_values,
    )
    return tensor_smems

@triton_jit
def _init_single_bar(
    num_stage: tl.constexpr, count: tl.constexpr = 1, arrive: tl.constexpr = False
):
    bars = gl.allocate_shared_memory(
        gl.int64, [num_stage, 1], mbarrier.MBarrierLayout()
    )
    for i in gl.static_range(num_stage):
        mbarrier.init(bars.index(i), count=count)
        if arrive:
            mbarrier.arrive(bars.index(i), count=count)
    return bars

@triton_jit
def _init_single_bar_from_group_info(
    ginfo: _GroupCommInfo, is_producer: tl.constexpr = False
):  
    bars = gl.allocate_shared_memory(
        gl.int64, [ginfo.info.num_stage, 1], mbarrier.MBarrierLayout()
    )
    count: tl.constexpr = ginfo.info.num_consumers if not is_producer else 1
    for i in gl.static_range(ginfo.info.num_stage):
        mbarrier.init(bars.index(i), count=count)
        if not is_producer and ginfo.info.arrive_on_init:
            mbarrier.arrive(bars.index(i), count=count)
    return bars

@tl.core.builtin
def _create_iter_group_metas(
    loops: TTDict, tensors: TTDict, _semantic=None
):
    loops_dict = {k: v.value for k, v in zip(loops.keys, loops.values_cw)}
    # loop_dim_groups = tl.core._unwrap_if_constexpr(loop_dim_groups)
    tensor_dim_name_to_iter_desc = {}
    iter_counters = {}
    tensors_dict = {
        k: v.value for k, v in zip(tensors.keys, tensors.values_cw)
    }
    offset_tensor_id_dict: dict[int, Any] = {}
    off_infos = {}
    acceed_tensor_dim: dict[str, str] = {}
    for loop_name, dim_group in loops_dict.items():
        dim_group = tl.core._unwrap_if_constexpr(dim_group)
        if isinstance(dim_group, str):
            loop_info = LoopInfo(dim=dim_group, tensors_sym="")
        else:
            assert isinstance(dim_group, LoopInfo)
            loop_info = dim_group
        iter_stride = tl.core._unwrap_if_constexpr(loop_info.stride)
        loop_tensor_keys = sym.parse_shape_sym(tl.core._unwrap_if_constexpr(loop_info.tensors_sym))[0]
        if not loop_tensor_keys:
            loop_tensor_keys = list(tensors_dict.keys())
        # create single iterator for each group.
        loop_dim_group = tl.core._unwrap_if_constexpr(loop_info.dim)
        group_parts = sym.get_shape_names_from_sym(loop_dim_group)
        hcf_lists: list[int] = []
        for k in loop_tensor_keys:
            v = tensors_dict[k]
            if isinstance(v, _ExtXmemDesc):
                continue
            desc_block_strides = {}
            if isinstance(v, PipedIterInfo):
                desc = v.desc
                block_strides = tl.core._unwrap_if_constexpr(v.block_strides)
                if block_strides is not None:
                    desc_block_strides = {k: v.value for k, v in zip(block_strides.keys, block_strides.values_cw)}
            else:
                assert isinstance(v, BlockedTensorDesc), (
                    f"only support blocked tensor desc, but got {type(v)} for tensor {k}"
                )
                desc = v
            shape_sym = tl.core._unwrap_if_constexpr(desc.shape_sym)
            block_sym = tl.core._unwrap_if_constexpr(desc.block_shape_sym)
            block_sym_names, _ = sym.parse_shape_sym(block_sym)
            shape_names, alias_names = sym.parse_shape_sym(shape_sym)
            alias_to_glob = {a: k for a, k in zip(alias_names, shape_names)}
            block_sym_names_global = [alias_to_glob.get(n, n) for n in block_sym_names]

            if isinstance(v, PipedIterInfo):
                if is_not_none_may_constexpr(v.offsets):
                    offs_dict = {
                        k: v.value
                        for k, v in zip(v.offsets.keys, v.offsets.values_cw)
                    }
                    for off_k, off_v in offs_dict.items():
                        if off_k not in group_parts:
                            continue
                        key = sym._encode_parts_to_tree_id([k, off_k])
                        if key in acceed_tensor_dim:
                            continue
                        ten_id = id(off_v)
                        if ten_id not in offset_tensor_id_dict:
                            offset_tensor_id_dict[ten_id] = off_v
                            off_info = _MainOffsetInfo(off_v, "")
                        else:
                            off_info = _MainOffsetInfo(None, key)
                        off_infos[key] = off_info
            for group_dim in group_parts:
                if group_dim in block_sym_names_global:
                    key = sym._encode_parts_to_tree_id([k, group_dim])
                    if key in acceed_tensor_dim:
                        continue
                    idx = block_sym_names_global.index(group_dim)
                    if group_dim in desc_block_strides:
                        block_stride = desc_block_strides[group_dim]
                    else:
                        block_stride = desc.block_shape[idx]
                    hcf_lists.append(block_stride)
        hcf = math.gcd(*hcf_lists) if len(hcf_lists) > 0 else 1
        if iter_stride > 0:
            hcf = iter_stride
        iter_counters[loop_name] = _IterVarDesc(
            value=_semantic.to_tensor(0), multipler=hcf, dim_names=group_parts
        )
        for k in loop_tensor_keys:
            v = tensors_dict[k]
            if isinstance(v, _ExtXmemDesc):
                continue
            desc_block_strides = {}

            if isinstance(v, PipedIterInfo):
                desc = v.desc
                block_strides = tl.core._unwrap_if_constexpr(v.block_strides)

                if block_strides is not None:

                    desc_block_strides = {k: v.value for k, v in zip(block_strides.keys, block_strides.values_cw)}

            else:
                assert isinstance(v, BlockedTensorDesc), (
                    f"only support blocked tensor desc, but got {type(v)} for tensor {k}"
                )
                desc = v
            shape_sym = tl.core._unwrap_if_constexpr(desc.shape_sym)
            block_sym = tl.core._unwrap_if_constexpr(desc.block_shape_sym)
            block_sym_names, _ = sym.parse_shape_sym(block_sym)
            shape_names, alias_names = sym.parse_shape_sym(shape_sym)
            alias_to_glob = {a: k for a, k in zip(alias_names, shape_names)}
            block_sym_names_global = [alias_to_glob.get(n, n) for n in block_sym_names]
            for i in range(len(block_sym_names_global)):
                if block_sym_names_global[i] in group_parts:
                    if iter_stride > 0:
                        multipler = 1
                    else:
                        if block_sym_names_global[i] in desc_block_strides:
                            block_stride = desc_block_strides[block_sym_names_global[i]]
                        else:
                            block_stride = desc.block_shape[i]
                        multipler = block_stride // hcf
                    iter_info = _TensorIterInfo(
                        name=loop_name, multipler=multipler
                    )
                    key = sym._encode_parts_to_tree_id([k, block_sym_names_global[i]])
                    if key in acceed_tensor_dim:
                        LOGGER.warning(
                            f"tensor {k} dim {block_sym_names_global[i]} is already mapped to "
                            f"{acceed_tensor_dim[key]}, can't map to loop {loop_name}."
                        )
                        continue
                    acceed_tensor_dim[key] = loop_name
                    tensor_dim_name_to_iter_desc[key] = iter_info
    # if tensor desc don't bind to any loop, show a warning.
    all_tensors_accessed = set([sym._decode_tree_id_to_parts(k)[0] for k in tensor_dim_name_to_iter_desc.keys()])
    for k in tensors_dict.keys():
        v = tensors_dict[k]
        # ignore comm only tensor.
        if isinstance(v, _ExtXmemDesc):
            continue
        if k not in all_tensors_accessed:
            LOGGER.warning(f"tensor {k} is not mapped to any loop. you should remove it from pipeline.")
    iter_counters_named_off = TTDict(
        keys=list(iter_counters.keys()),
        values_cw=tl.tuple(
            [mp.TritonField(iter_counters[k]) for k in iter_counters.keys()]
        ),
    )
    tensor_dim_name_to_iter_desc_named_off = TTDict(
        keys=list(tensor_dim_name_to_iter_desc.keys()),
        values_cw=tl.tuple(
            [
                mp.TritonField(tensor_dim_name_to_iter_desc[k])
                for k in tensor_dim_name_to_iter_desc.keys()
            ]
        ),
    )

    tensors_dict_no_info = {}
    ext_xmem_descs = {}
    info_dict = {}
    for k, v in tensors_dict.items():
        if isinstance(v, _ExtXmemDesc):
            ext_xmem_descs[k] = v
            continue

        if isinstance(v, PipedIterInfo):
            tensors_dict_no_info[k] = v.desc
            info_dict[k] = _InternalExtendIterInfo(
                iter_mode=v.iter_mode,
                offsets=v.offsets,
                smem_layout=v.smem_layout,
                is_sync=v.is_sync,
                is_store=v.is_store,
                smem_shape_override=v.smem_shape_override,
                block_strides=v.block_strides,
            )
        else:
            tensors_dict_no_info[k] = v
            info_dict[k] = _InternalExtendIterInfo()
    tensor_desc_maps = TTDict(
        keys=list(tensors_dict_no_info.keys()),
        values_cw=tl.tuple(
            [
                mp.TritonField(tensors_dict_no_info[k])
                for k in tensors_dict_no_info.keys()
            ]
        ),
    )
    pointer_offsets = TTDict(
        keys=list(off_infos.keys()),
        values_cw=tl.tuple([mp.TritonField(off_infos[k]) for k in off_infos.keys()]),
    )
    info_ttdict = TTDict(
        keys=list(info_dict.keys()),
        values_cw=tl.tuple([mp.TritonField(info_dict[k]) for k in info_dict.keys()]),
    )
    ext_desc_maps = TTDict(
        keys=list(ext_xmem_descs.keys()),
        values_cw=tl.tuple(
            [mp.TritonField(ext_xmem_descs[k]) for k in ext_xmem_descs.keys()]
        ),
    )

    return (
        iter_counters_named_off,
        tensor_dim_name_to_iter_desc_named_off,
        tensor_desc_maps,
        pointer_offsets,
        info_ttdict,
        ext_desc_maps,
    )


@triton_jit
def create_simple_iter(loops: TTDict, tensors: TTDict):
    pointers = _get_tensor_pointers(tensors)
    iter_counters, tensor_dim_name_to_iter_desc, descs, pointer_offsets, info_dict, _ = (
        _create_iter_group_metas(loops, tensors)
    )
    res = IteratorGroupBase(
        tensor_dim_name_to_iter_desc=tensor_dim_name_to_iter_desc,
        iter_counters=iter_counters,
        descs=descs,
        pointer_offsets=pointer_offsets,
        pointers=pointers,
        desc_info_dict=info_dict,
    )
    return res


@aggregate(kw_only=True)
class PipelinedIteratorBase(IteratorGroupBase):
    num_stage: tl.constexpr
    smems: TTDict
    # each group of tensors will use same mbarrier/cp group for async io.
    all_load_groups: TTDict
    cur_load_groups: TTDict
    tensor_name_to_group_key: TTDict
    cur_group_key: tl.constexpr
    ext_descs: TTDict
    async_store_intra_overlap: tl.constexpr = True

    @triton_jit
    def get_xmem(self, name: tl.constexpr) -> gl.shared_memory_descriptor | tensor_memory_descriptor:
        return self.smems.getitem(name).value

    @triton_jit
    def get_smem(self, name: tl.constexpr) -> gl.shared_memory_descriptor:
        res = self.smems.getitem(name).value
        tl.static_assert(
            isinstance(res, gl.shared_memory_descriptor),
            f"tensor {name} doesn't have smem allocated, or allocated with tmem.",
        )
        return res

    @triton_jit
    def get_tmem(self, name: tl.constexpr) -> tensor_memory_descriptor:
        res = self.smems.getitem(name).value
        tl.static_assert(
            isinstance(res, tensor_memory_descriptor),
            f"tensor {name} doesn't have smem allocated, or allocated with tmem.",
        )
        return res

    @triton_jit
    def set_iter(
        self, loop_name: tl.constexpr, value, inc_store_iters: tl.constexpr = True
    ) -> "Self":
        tl.static_assert(
            self.iter_counters.is_name_exists(loop_name).value,
            f"iter counter for loop {loop_name} not found",
        )
        iter_item = self.iter_counters.getitem(loop_name).value
        # TODO check dim names is valid.
        if isinstance(value, int) and not isinstance(iter_item.value, int):
            value = get_scalar_tensor(value)
        prev_iter = iter_item.value
        n_iter_diff = value - (prev_iter // iter_item.multipler)
        res_counters = self.iter_counters.replaceitem(
            loop_name,
            mp.TritonField(
                _IterVarDesc(
                    value=value * iter_item.multipler,
                    multipler=iter_item.multipler,
                    dim_names=iter_item.dim_names,
                )
            ),
        )
        res = aggregate_replace(
            self,
            iter_counters=res_counters,
            cur_load_groups=self.all_load_groups.clone()
        )
        dim_names_sym: tl.constexpr = sym.names_to_sym(iter_item.dim_names)
        for i in tl.static_range(len(self.descs.keys)):
            info = self.desc_info_dict.getitem(
                tl.constexpr(self.descs.keys[i])
            ).value
            if inc_store_iters or not info.is_sync:
                res = res._increment_one(
                    mp.TritonField(n_iter_diff),
                    dim_names_sym,
                    tl.constexpr(self.descs.keys[i]),
                )
        return res

    @triton_jit
    def get_tensor_desc(self, name: tl.constexpr) -> "BlockedTensorDesc":
        return self.descs.getitem(name).value

    @triton_jit
    def _load_internal_async(
        self,
        smem_index,
        tensor_name: tl.constexpr,
        apply_mask: tl.constexpr = True,
        other=None,
        bar=None,
        force_mask_sym: tl.constexpr = None,
        pred=True,
        offsets: TTDict | None = None,
        gather_info: GatherInfo | None = None,
        block_offsets: TTDict | None = None,
    ):
        desc = self.descs.getitem(tensor_name).value
        if mp.is_gluon():
            assert not desc.is_tma_desc().value, (
                "gluon tma desc don't support load (sync, into regs), use load_async instead"
            )
        scalar_offset_cws = self._get_offset_from_iter_cws(tensor_name, desc, ext_offset_cws=offsets, ext_block_offset_cws=block_offsets)
        if gather_info is not None:
            if _is_val_str(gather_info.dim):
                gather_info = aggregate_replace(
                    gather_info,
                    dim=desc._get_dim_by_block_dim_name(gather_info.dim).value
                )
        self = self.record_debug_event(raw_ttdict(
            name="gather" if gather_info is not None else "load",
            is_sync=False,
            tensor_name=tensor_name,
            tensor_info=desc.get_json_data_cw(),
            is_inds_local=gather_info.is_inds_local if gather_info is not None else False,
            offsets=scalar_offset_cws,
        ))
        smem = self.smems.getitem(tensor_name).value.index(smem_index)

        if desc.is_tma_desc().value:
            tl.static_assert(
                bar is not None, "barrier should be provided for async tma load"
            )
            if gather_info is not None:
                scalar_offset_cws = _modify_offset_cw_for_gather(scalar_offset_cws, gather_info.inds, gather_info.is_inds_local, gather_info.dim)
                desc.issue_tma_gather_cw(scalar_offset_cws, bar, smem, pred=pred)
            else:
                desc.issue_tma_load_cw(scalar_offset_cws, bar, smem, pred=pred)
            return self
        else:
            # pointer offsets
            offsets, mask_cw = self._prepare_offsets_masks_for_pointer_io(
                tensor_name, desc, 
                offset_cws=scalar_offset_cws,
                apply_mask=apply_mask,
                force_mask_sym=force_mask_sym,
                gather_info=gather_info,
            )
            if self.pointers.is_name_exists(tensor_name).value:
                # pointers already incremented, just load
                pointers = self.pointers.getitem(tensor_name).value
                if isinstance(pred, int) and pred:
                    cp_async_copy_global_to_shared(smem, pointers, mask_cw.value, other)
                else:
                    if pred:
                        cp_async_copy_global_to_shared(smem, pointers, mask_cw.value, other)
                return self
            else:
                if isinstance(pred, int) and pred:
                    cp_async_copy_global_to_shared(
                        smem, desc.get_blocked_ptrs_from_offsets(offsets), mask_cw.value, other
                    )
                else:
                    if pred:
                        cp_async_copy_global_to_shared(
                            smem, desc.get_blocked_ptrs_from_offsets(offsets), mask_cw.value, other
                        )
                return self

    @triton_jit
    def get_sliced_layout_cw(
        self,
        tensor_name: tl.constexpr,
        dim_name: tl.constexpr,
    ):
        desc = self.descs.getitem(tensor_name).value
        return desc.get_sliced_layout_by_name_for_offset(dim_name)

    @triton_jit
    def get_desc_dtype_cw(
        self,
        tensor_name: tl.constexpr,
    ):
        desc = self.descs.getitem(tensor_name).value
        return desc.get_dtype()

    @triton_jit
    def _sync_store_internal_for_tma(self, smem_index, offset_cws, value, tensor_name: tl.constexpr, reduce_kind: tl.constexpr = None):
        desc = self.descs.getitem(tensor_name).value
        info = self.desc_info_dict.getitem(tensor_name).value

        value = desc._preprocess_tma_value(value)
        tl.static_assert(
            mp.is_gluon() and desc.is_tma_desc().value,
            "only tma support async store in gluon.",
        )
        tl.static_assert(
            info.is_sync, "TMA store only support no-buffer async (like sync)."
        )
        smem = self.smems.getitem(tensor_name).value.index(smem_index)
        if self.async_store_intra_overlap:
            tma.store_wait(pendings=0)
            smem.store(value)
            fence_async_shared()
            # Issue the store without waiting for it.
            desc.issue_tma_store_cw(offset_cws, smem, reduce_kind=reduce_kind)
        else:
            smem.store(value)
            fence_async_shared()
            # Issue the store without waiting for it.
            desc.issue_tma_store_cw(offset_cws, smem, reduce_kind=reduce_kind)
            tma.store_wait(pendings=0)
        return

    @triton_jit
    def _sync_scatter_internal_for_tma(self, smem_index, offset_cws, value, tensor_name: tl.constexpr, reduce_kind: tl.constexpr = None):
        desc = self.descs.getitem(tensor_name).value
        info = self.desc_info_dict.getitem(tensor_name).value
        tl.static_assert(
            mp.is_gluon() and desc.is_tma_desc().value,
            "only tma support async store in gluon.",
        )
        tl.static_assert(
            info.is_sync, "TMA store only support no-buffer async (like sync)."
        )
        smem = self.smems.getitem(tensor_name).value.index(0)
        if self.async_store_intra_overlap:
            # this requires user call pipeline.close() to wait for all async store to finish
            tma.store_wait(pendings=0)
            smem.store(value)
            fence_async_shared()
            # Issue the store without waiting for it.
            desc.issue_tma_scatter_cw(offset_cws, smem, reduce_kind=reduce_kind)
        else:
            smem.store(value)
            fence_async_shared()
            desc.issue_tma_scatter_cw(offset_cws, smem, reduce_kind=reduce_kind)
            tma.store_wait(pendings=0)
        return


    @triton_jit
    def close(self):
        """User should always call this at the end of the kernel to mark mbars and smems
        are "alive until here", otherwise triton may optimize them away and cause incorrect execution.
        """
        for i in tl.static_range(len(self.all_load_groups.keys)):
            ginfo = self.all_load_groups.values_cw[i].value
            if ginfo.producer_ready_bars is not None:
                for j in tl.static_range(ginfo.info.num_stage):
                    mbarrier.invalidate(ginfo.producer_ready_bars.index(j))
            if ginfo.consumer_finish_bars is not None:
                for j in tl.static_range(ginfo.info.num_stage):
                    mbarrier.invalidate(ginfo.consumer_finish_bars.index(j))
        for i in tl.static_range(len(self.smems.keys)):
            smem_may_none = self.smems.values_cw[i].value
            if isinstance(smem_may_none, gl.shared_memory_descriptor):
                smem_may_none._keep_alive()
        # TODO don't run this if no tma desc with is_sync=True included in tensors.
        tma.store_wait(pendings=0)

    @triton_jit
    def alloc_smems(self):
        tl.static_assert(self.smems.is_empty_cw().value, "smems should be empty before allocation")
        tensor_smems = _alloc_tensor_smems(
            self.desc_info_dict, self.descs, self.all_load_groups, self.tensor_name_to_group_key
        )
        ext_xmems = _alloc_ext_xmems(
            self.ext_descs, self.all_load_groups, self.tensor_name_to_group_key
        )
        return aggregate_replace(
            self,
            smems=tensor_smems.update(ext_xmems, check_unique=True),
        )

    @triton_jit
    def get_group_comm(self, group_key: tl.constexpr) -> "_GroupCommInfo":
        return self.all_load_groups.getitem(group_key).value

def _is_constexpr_eq(lfs, rfs):
    return tl.core._unwrap_if_constexpr(lfs) == tl.core._unwrap_if_constexpr(rfs)

@tl.core.builtin
def _create_async_group_meta(
    tensors: TTDict,
    info_dict: TTDict,
    async_groups,
    ext_xmem: TTDict,
    num_stage,
    num_store_stage,
    arrive_on_init,
    is_ws_pipeline,
    is_v2_api=False,
    _semantic=None,
):
    is_ws_pipeline = tl.core._unwrap_if_constexpr(is_ws_pipeline)
    async_groups = tl.core._unwrap_if_constexpr(async_groups)
    if async_groups is not None:
        assert isinstance(async_groups, tl.tuple)
    else:
        async_groups = tl.tuple([])
    tensors_dict = {
        k: v.value for k, v in zip(tensors.keys, tensors.values_cw)
    }
    info_dict_py = {
        k: v.value for k, v in zip(info_dict.keys, info_dict.values_cw)
    }
    xmem_dict: dict[str, _ExtXmemDesc] = {
        k: v.value for k, v in zip(ext_xmem.keys, ext_xmem.values_cw)
    }
    cur_groups_dict = {k: True for k in tensors_dict.keys()}
    cur_groups_dict.update({k: True for k in xmem_dict.keys()})
    group_key_to_info = {}
    num_stages = set()
    name_to_group_info = {}
    for v in async_groups:
        if is_v2_api:
            assert isinstance(v, tl.constexpr), "async_groups should only be string, set piped info in tensors."
            vv = tl.core._unwrap_if_constexpr(v)
            name_to_group_info[vv] = AsyncGroupInfo(name=vv)
        else:
            name_to_group_info[tl.core._unwrap_if_constexpr(v.name)] = v
    for group_info in async_groups:
        if isinstance(group_info, tl.constexpr):
            group = group_info
        else:
            group = group_info.name
        group = tl.core._unwrap_if_constexpr(group)
        group_parts = sym.parse_shape_sym(group)[0]
        group_parts = [x.strip() for x in group_parts]
        group_parts.sort()
        group_unified = ",".join(group_parts)
        for part in group_parts:
            assert part in cur_groups_dict, f"group part {part} not found in tensors"
            cur_groups_dict.pop(part)
        cur_groups_dict[group_unified] = True
    tensor_name_to_group_key = {}
    for group in cur_groups_dict:
        group_parts = group.split(",")

        if is_v2_api:
            group_info_cur: Optional[AsyncGroupInfo] = None 
            for part in group_parts:
                v = tensors_dict[part]
                assert isinstance(v, (PipedIterInfo, _ExtXmemDesc)), "in v2 api, we don't support desc in tensors"
                if group_info_cur is None:
                    group_info_cur = AsyncGroupInfo(
                        name=group,
                        num_consumers=v.num_consumers,
                        arrive_on_init=v.arrive_on_init,
                        num_stage=v.num_stage,
                        init_phase=v.init_phase,
                        producer_only=v.producer_only,
                        use_mbarrier=v.use_mbarrier,
                    )
                else:
                    # compare values
                    assert _is_constexpr_eq(group_info_cur.arrive_on_init, v.arrive_on_init), f"arrive_on_init mismatch in group {group}"
                    assert _is_constexpr_eq(group_info_cur.num_stage, v.num_stage), f"num_stage mismatch in group {group}"
                    assert _is_constexpr_eq(group_info_cur.use_mbarrier, v.use_mbarrier), f"use_mbarrier mismatch in group {group}"
                    assert _is_constexpr_eq(group_info_cur.num_consumers, v.num_consumers), f"num_consumers mismatch in group {group}"
                    assert _is_constexpr_eq(group_info_cur.init_phase, v.init_phase), f"init_phase mismatch in group {group}"
                    assert _is_constexpr_eq(group_info_cur.producer_only, v.producer_only), f"producer_only mismatch in group {group}"
            assert group_info_cur is not None, f"group_info for group {group} is not found in tensors"
            group_info = group_info_cur
        else:

            if group in name_to_group_info:
                group_info = name_to_group_info[group]
            else:
                group_info = AsyncGroupInfo(name=group)
        nbytes = 0
        is_mbarriers = []
        is_stores = []
        is_syncs = []
        is_xmems = []
        is_tmas = []
        for part in group_parts:
            v = tensors_dict[part]
            if not isinstance(v, _ExtXmemDesc):
                if isinstance(v, (PipedIterInfo, )):
                    desc = v.desc
                else:
                    assert isinstance(v, BlockedTensorDesc), (
                        "only support blocked tensor desc"
                    )
                    desc = v
                iter_info: PipedIterInfo = info_dict_py[part]
                assert part not in tensor_name_to_group_key, f"{tensor_name_to_group_key}, {part}, {group}"
                tensor_name_to_group_key[part] = group
                use_mbarrier_from_user = tl.core._unwrap_if_constexpr(group_info.use_mbarrier)
                if use_mbarrier_from_user is None:
                    if is_ws_pipeline:
                        use_mbarrier = not iter_info.is_sync 
                    else:
                        use_mbarrier = (
                            isinstance(
                                desc.ptr,
                                (gl.nvidia.hopper.tma.tensor_descriptor, tl.tensor_descriptor),
                            )
                            and not iter_info.is_sync
                        )
                else:
                    use_mbarrier = use_mbarrier_from_user

                block_shape = tl.core._unwrap_if_constexpr(desc.block_shape)
                val = 1
                for v in block_shape:
                    val *= v
                if isinstance(
                    desc.ptr, (gl.nvidia.hopper.tma.tensor_descriptor, tl.tensor_descriptor)
                ):
                    is_tmas.append(True)
                    nbytes += desc.ptr.block_type.nbytes
                else:
                    is_tmas.append(False)
                    dtype = desc.ptr.dtype.element_ty
                    nbytes += dtype.itemsize * val
                is_mbarriers.append(use_mbarrier)
                is_stores.append(iter_info.is_store)
                is_syncs.append(iter_info.is_sync)
                is_xmems.append(False)
            else:
                assert part in xmem_dict, f"group part {part} not found in tensors or ext_xmem"
                xmem_desc = xmem_dict[part]
                assert part not in tensor_name_to_group_key, f"{tensor_name_to_group_key}, {part}, {group}"

                tensor_name_to_group_key[part] = group

                is_mbarriers.append(True)
                is_stores.append(False)
                is_syncs.append(False)
                is_tmas.append(False)

                val = tl.core._unwrap_if_constexpr(xmem_desc.dtype).itemsize
                for v in tl.core._unwrap_if_constexpr(xmem_desc.block_shape):
                    val *= v
                nbytes += val
                is_xmems.append(True)

        # is_mbarriers must be all-true or all-false
        assert all(is_mbarriers) or not any(is_mbarriers), (
            f"group {group} has mixed mbarrier and non-mbarrier iters"
        )
        assert all(is_stores) or not any(is_stores), (
            f"group {group} has mixed store and non-store iters"
        )
        assert all(is_syncs) or not any(is_syncs), (
            f"group {group} has mixed sync and non-sync iters"
        )
        assert not any(is_xmems) or all(is_xmems), (
            f"group {group} has mixed xmem and non-xmem iters"
        )
        assert not any(is_tmas) or all(is_tmas), (
            f"group {group} has mixed TMA and non-TMA iters"
        )

        use_mbarrier = is_mbarriers[0]
        is_sync = is_syncs[0]
        is_store = is_stores[0]
        group_num_stage = tl.core._unwrap_if_constexpr(group_info.num_stage)
        if group_num_stage is None:
            if is_store:
                group_info.num_stage = num_store_stage
            else:
                group_info.num_stage = num_stage
        num_stages.add(tl.core._unwrap_if_constexpr(group_info.num_stage))
        group_arrive_on_init = tl.core._unwrap_if_constexpr(group_info.arrive_on_init)
        if group_arrive_on_init is None:
            group_info.arrive_on_init = arrive_on_init
        info = _GroupCommInfo(
            info=group_info,
            remain_group=group,
            nbytes=nbytes,
            is_store=is_store,
            is_sync=is_sync,
            is_tma=is_tmas[0],
            use_mbarrier=use_mbarrier,
            is_xmem=is_xmems[0]
        )
        group_key_to_info[group] = info
    res_map = TTDict(
        keys=list(group_key_to_info.keys()),
        values_cw=tl.tuple(
            [mp.TritonField(group_key_to_info[k]) for k in group_key_to_info.keys()]
        ),
    )
    res_tensor_name_to_group_key = TTDict(
        keys=list(tensor_name_to_group_key.keys()),
        values_cw=tl.tuple(
            [
                mp.TritonConstexprField(tensor_name_to_group_key[k])
                for k in tensor_name_to_group_key.keys()
            ]
        ),
    )
    num_stage_map = TTDict(
        keys=[str(i) for i in num_stages],
        values_cw=tl.tuple(
            [mp.TritonConstexprField(i) for i in num_stages]
        ),
    )
    return res_map, res_tensor_name_to_group_key, num_stage_map

@triton_jit
def create_pipelined_iter_legacy(
    num_stage: tl.constexpr, loops: TTDict, tensors: TTDict, async_groups=None, arrive_on_init: tl.constexpr = False,
    alloc_smem: tl.constexpr = True
):
    """Pipelined Iterators used for non-WS kernels.
    """
    # assume all tensors can be async loaded.
    pointers = _get_tensor_pointers(tensors)
    iter_counters, tensor_dim_name_to_iter_desc, descs, pointer_offsets, info_dict, xmem_dict = (
        _create_iter_group_metas(loops, tensors)
    )
    load_groups, name_to_group_key, _ = _create_async_group_meta(
        tensors, info_dict, async_groups, xmem_dict, num_stage, 1, arrive_on_init=arrive_on_init,
        is_ws_pipeline=False,
    )
    load_groups_value_cw = load_groups.values_cw
    # alloc bar

    load_groups_value_cw = [
        mp.TritonField(
            aggregate_replace(
                load_groups_value_cw[i].value,
                producer_ready_bars=_init_single_bar_from_group_info(load_groups_value_cw[i].value, is_producer=True)
                if load_groups_value_cw[i].value.use_mbarrier
                else None,
            )
        )
        for i in tl.tuple(sym.tuple_range(len(load_groups_value_cw)))
    ]
    load_groups = TTDict(
        keys=load_groups.keys,
        values_cw=load_groups_value_cw,
    )
    if alloc_smem:
        tensor_smems = _alloc_tensor_smems(
            info_dict, descs, load_groups, name_to_group_key
        )
    else:
        # complex schedulers may requires alloc smem inside a loop.
        tensor_smems = TTDict(keys=sym.empty_list(), values_cw=tl.tuple([]))

    res = PipelineLegacy(
        tensor_dim_name_to_iter_desc=tensor_dim_name_to_iter_desc,
        iter_counters=iter_counters,
        descs=descs,
        pointer_offsets=pointer_offsets,
        pointers=pointers,
        desc_info_dict=info_dict,
        all_load_groups=load_groups,
        cur_load_groups=load_groups,
        tensor_name_to_group_key=name_to_group_key,
        cur_group_key="",
        num_stage=num_stage,
        smems=tensor_smems,
        smem_read_idx=get_scalar_tensor(0),
        smem_write_idx=get_scalar_tensor(0),
        remain_cg_group=0,
        num_prefetch=0,
        ext_descs=xmem_dict,
    )
    return res


@triton_jit
def create_pipelined_iter_ws(
    num_stage: tl.constexpr,
    loops: TTDict,
    tensors: TTDict,
    async_groups = None,
    arrive_on_init: tl.constexpr = True,
    num_store_stage: tl.constexpr = 1,
    alloc_smem: tl.constexpr = True,
    recorder_args=None,
):
    # assume all tensors can be async loaded.
    pointers = _get_tensor_pointers(tensors)
    iter_counters, tensor_dim_name_to_iter_desc, descs, pointer_offsets, info_dict, xmem_descs = (
        _create_iter_group_metas(loops, tensors)
    )
    load_groups, tensor_name_to_group, all_num_stage_dict = _create_async_group_meta(
        tensors,
        info_dict,
        async_groups,
        xmem_descs,
        num_stage,
        num_store_stage,
        arrive_on_init=arrive_on_init,
        is_ws_pipeline=True,
    )
    load_groups_value_cw = load_groups.values_cw
    # tl.static_print("load_groups_value_cw", load_groups_value_cw)
    # alloc bar
    load_groups_value_cw = [
        mp.TritonField(
            aggregate_replace(
                load_groups_value_cw[i].value,
                producer_ready_bars=_init_single_bar_from_group_info(load_groups_value_cw[i].value, is_producer=True)
                if load_groups_value_cw[i].value.use_mbarrier and load_groups_value_cw[i].value.info.num_stage > 0
                else None,
                consumer_finish_bars=_init_single_bar_from_group_info(load_groups_value_cw[i].value)
                if load_groups_value_cw[i].value.use_mbarrier and load_groups_value_cw[i].value.info.num_stage > 0 and not load_groups_value_cw[i].value.info.producer_only
                else None,
            )
        )
        for i in tl.tuple(sym.tuple_range(len(load_groups_value_cw)))
    ]
    load_groups = TTDict(
        keys=load_groups.keys,
        values_cw=load_groups_value_cw,
    )
    if alloc_smem:
        tensor_smems = _alloc_tensor_smems(
            info_dict, descs, load_groups, tensor_name_to_group
        )
    else:
        # complex schedulers may requires alloc smem inside a loop.
        tensor_smems = TTDict(keys=sym.empty_list(), values_cw=tl.tuple([]))
    if alloc_smem:
        ext_xmems = _alloc_ext_xmems(
            xmem_descs, load_groups, tensor_name_to_group
        )
    else:
        # complex schedulers may requires alloc smem inside a loop.
        ext_xmems = TTDict(keys=sym.empty_list(), values_cw=tl.tuple([]))
    tensor_smems = tensor_smems.update(
        ext_xmems,
        check_unique=True,
    )
    counter_tuple = [
        mp.TritonField(_GluonWSPipelineCounter.create(phase=0, num_barriers=load_groups.values_cw[i].value.info.num_stage))
        for i in tl.tuple(sym.tuple_range(len(load_groups.values_cw)))
    ]
    res = PipelineWS(
        tensor_dim_name_to_iter_desc=tensor_dim_name_to_iter_desc,
        iter_counters=iter_counters,
        descs=descs,
        pointer_offsets=pointer_offsets,
        pointers=pointers,
        desc_info_dict=info_dict,
        ext_descs=xmem_descs,
        all_load_groups=load_groups,
        cur_load_groups=load_groups,
        tensor_name_to_group_key=tensor_name_to_group,
        cur_group_key="",
        num_stage=num_stage,
        smems=tensor_smems,
        counters=TTDict(
            keys=load_groups.keys,
            values_cw=counter_tuple,
        ),
        num_prefetch=0,
        outstanding_stores=0,
        cur_store_groups=sym.empty_list(),
        recorder=recorder_args.create_recorder(True) if recorder_args is not None else None,
    )
    return res

@triton_jit
def create_pipelined_iter_ws_v2(
    tm: TensorManagerBase,
    loops: TTDict,
    tensors: TTDict,
    async_groups = None,
    num_stage: tl.constexpr = 1,
    arrive_on_init: tl.constexpr = True,
    num_store_stage: tl.constexpr = 1,
    alloc_smem: tl.constexpr = True,
    recorder_args=None,
):
    tensors_values = [
        mp.TritonField(aggregate_replace(
            tensors.values_cw[i].value,
            desc=tm.get_predefined_unified_desc(tl.constexpr(tensors.keys[i])),
            block_strides=(tensors.values_cw[i].value.block_strides 
                            if tensors.values_cw[i].value.block_strides is not None 
                            else tm._get_external_block_strides(tl.constexpr(tensors.keys[i]))),
        ))
        if isinstance(tensors.values_cw[i].value, PipedIterInfoV2)
        else tensors.values_cw[i]
        for i in tl.tuple(sym.tuple_range(len(tensors.values_cw)))
    ]
    tensors = TTDict(
        keys=tensors.keys,
        values_cw=tensors_values,
    )
    # assume all tensors can be async loaded.
    pointers = _get_tensor_pointers(tensors)
    iter_counters, tensor_dim_name_to_iter_desc, descs, pointer_offsets, info_dict, xmem_descs = (
        _create_iter_group_metas(loops, tensors)
    )
    load_groups, tensor_name_to_group, all_num_stage_dict = _create_async_group_meta(
        tensors,
        info_dict,
        async_groups,
        xmem_descs,
        num_stage,
        num_store_stage,
        arrive_on_init=arrive_on_init,
        is_ws_pipeline=True,
        is_v2_api=True,
    )
    load_groups_value_cw = load_groups.values_cw
    # tl.static_print("load_groups_value_cw", load_groups_value_cw)
    # alloc bar
    load_groups_value_cw = [
        mp.TritonField(
            aggregate_replace(
                load_groups_value_cw[i].value,
                producer_ready_bars=_init_single_bar_from_group_info(load_groups_value_cw[i].value, is_producer=True)
                if load_groups_value_cw[i].value.use_mbarrier and load_groups_value_cw[i].value.info.num_stage > 0
                else None,
                consumer_finish_bars=_init_single_bar_from_group_info(load_groups_value_cw[i].value)
                if load_groups_value_cw[i].value.use_mbarrier and load_groups_value_cw[i].value.info.num_stage > 0 and not load_groups_value_cw[i].value.info.producer_only
                else None,
            )
        )
        for i in tl.tuple(sym.tuple_range(len(load_groups_value_cw)))
    ]
    load_groups = TTDict(
        keys=load_groups.keys,
        values_cw=load_groups_value_cw,
    )
    if alloc_smem:
        tensor_smems = _alloc_tensor_smems(
            info_dict, descs, load_groups, tensor_name_to_group
        )
    else:
        # complex schedulers may requires alloc smem inside a loop.
        tensor_smems = TTDict(keys=sym.empty_list(), values_cw=tl.tuple([]))
    if alloc_smem:
        ext_xmems = _alloc_ext_xmems(
            xmem_descs, load_groups, tensor_name_to_group
        )
    else:
        # complex schedulers may requires alloc smem inside a loop.
        ext_xmems = TTDict(keys=sym.empty_list(), values_cw=tl.tuple([]))
    tensor_smems = tensor_smems.update(
        ext_xmems,
        check_unique=True,
    )
    counter_tuple = [
        mp.TritonField(_GluonWSPipelineCounter.create(phase=0, num_barriers=load_groups.values_cw[i].value.info.num_stage))
        for i in tl.tuple(sym.tuple_range(len(load_groups.values_cw)))
    ]
    res = PipelineWS(
        tensor_dim_name_to_iter_desc=tensor_dim_name_to_iter_desc,
        iter_counters=iter_counters,
        descs=descs,
        pointer_offsets=pointer_offsets,
        pointers=pointers,
        desc_info_dict=info_dict,
        ext_descs=xmem_descs,
        all_load_groups=load_groups,
        cur_load_groups=load_groups,
        tensor_name_to_group_key=tensor_name_to_group,
        cur_group_key="",
        num_stage=num_stage,
        smems=tensor_smems,
        counters=TTDict(
            keys=load_groups.keys,
            values_cw=counter_tuple,
        ),
        num_prefetch=0,
        outstanding_stores=0,
        cur_store_groups=sym.empty_list(),
        recorder=recorder_args.create_recorder(True) if recorder_args is not None else None,
    )
    return res


@aggregate(kw_only=True)
class _PipelineIOResultBase:
    group: tl.constexpr
    smem_dict: TTDict

    @triton_jit
    def get_num_tensor_cw(self):
        parts: tl.constexpr = sym.get_shape_names_from_sym(self.group)
        return mp.TritonConstexprField(len(parts))

    @triton_jit
    def get_xmem(self, tensor_name: tl.constexpr):
        smem = self.smem_dict.getitem(tensor_name).value
        tl.static_assert(self.smem_dict.getitem(tensor_name).value is not None, f"tensor {tensor_name} doesn't have memory allocated in smem_dict")
        return smem

    @triton_jit
    def get_smem(self, tensor_name: tl.constexpr) -> gl.shared_memory_descriptor:
        smem = self.smem_dict.getitem(tensor_name).value
        tl.static_assert(
            isinstance(smem, gl.shared_memory_descriptor),
            f"tensor {tensor_name} isn't smem",
        )
        return smem

    @triton_jit
    def get_tmem(self, tensor_name: tl.constexpr) -> tensor_memory_descriptor:
        smem = self.smem_dict.getitem(tensor_name).value
        tl.static_assert(
            isinstance(smem, tensor_memory_descriptor),
            f"tensor {tensor_name} isn't smem",
        )
        return smem

    @triton_jit
    def load_xmem(self, tensor_name: tl.constexpr, layout: tl.constexpr):
        smem = self.smem_dict.getitem(tensor_name).value
        res = smem.load(layout)
        # if isinstance(smem, gl.shared_memory_descriptor):
        #     # check bank conflict
        #     bc_val: tl.constexpr = bank_conflicts_ex(res.type, smem.type)
        #     if bc_val > 0:
        #         mp.logger_warning("Tensor %s has %d bank conflicts when loading from shared memory.", tensor_name, bc_val)
        return res 

    @triton_jit
    def store_xmem(self, tensor_name: tl.constexpr, val):
        smem = self.smem_dict.getitem(tensor_name).value
        # if isinstance(smem, gl.shared_memory_descriptor):
        #     # check bank conflict
        #     bc_val: tl.constexpr = bank_conflicts_ex(val.type, smem.type)
        #     if bc_val > 0:
        #         mp.logger_warning("Tensor %s has %d bank conflicts when store to shared memory.", tensor_name, bc_val)
        return smem.store(val)

    @triton_jit
    def store_smem(self, tensor_name: tl.constexpr, val):
        return self.store_xmem(tensor_name, val)

@aggregate(kw_only=True)
class PipelineConsumerBase(_PipelineIOResultBase):
    pass 

@aggregate(kw_only=True)
class PipelineProducerBase(_PipelineIOResultBase):
    pass 

@aggregate(kw_only=True)
class LegacyPipelineConsumer(PipelineConsumerBase):
    pass


@constexpr_function
def _get_assoicated_group_key(tensor_sym, sym_list):
    tensor_names = sym.parse_shape_sym(tensor_sym)[0]
    for sym_val in sym_list:
        sym_names = sym.parse_shape_sym(sym_val)[0]
        if all(name in tensor_names for name in sym_names):
            return sym_val
    raise ValueError(
        f"tensor sym {tensor_sym} doesn't match any group sym in {sym_list}"
    )


@constexpr_function
def _remove_group_items_from_group(query_group, remain_group):
    sym_parts = sym.parse_shape_sym(remain_group)[0]
    query_parts = sym.parse_shape_sym(query_group)[0]
    new_parts = [part for part in sym_parts if part not in query_parts]
    return ",".join(new_parts)


@aggregate
class _GluonWSPipelineCounter:
    index: gl.tensor
    phase: gl.tensor
    num_barriers: gl.constexpr

    @staticmethod
    @gluon_jit
    def create(phase, num_barriers: gl.constexpr):
        return _GluonWSPipelineCounter(
            gl.to_tensor(0), gl.to_tensor(phase), num_barriers
        )

    @gluon_jit
    def next(self, pred=True):
        if self.num_barriers == 1:
            return _GluonWSPipelineCounter(gl.to_tensor(0), self.phase ^ 1, self.num_barriers)

        incr = self.index + gl.where(pred, 1, 0)
        rollover = incr == self.num_barriers
        index = gl.where(rollover, 0, incr)
        phase = gl.where(rollover, self.phase ^ 1, self.phase)
        return aggregate_replace(self, index=index, phase=phase)

@aggregate(kw_only=True)
class PipelineLegacy(PipelinedIteratorBase):
    # TODO: currently only support 1-d loop.
    smem_read_idx: tl.tensor
    smem_write_idx: tl.tensor
    remain_cg_group: tl.constexpr
    num_prefetch: tl.constexpr

    @triton_jit
    def clear(self):
        return aggregate_replace(
            self,
            smem_read_idx=get_scalar_tensor(0),
            smem_write_idx=get_scalar_tensor(0),
            remain_cg_group=0,
            num_prefetch=0,
            cur_group_key=tl.constexpr(""),
            cur_load_groups=self.all_load_groups.clone(),
        )

    @triton_jit
    def load_pipeline_state(self, other_pipe: "PipelineLegacy"):
        tl.static_assert(isinstance(other_pipe, PipelineLegacy), "other_pipe should be PipelineLegacy")
        return aggregate_replace(
            self,
            smem_read_idx=other_pipe.smem_read_idx,
            smem_write_idx=other_pipe.smem_write_idx,
            # remain_cg_group=other_pipe.remain_cg_group,
            # num_prefetch=other_pipe.num_prefetch,
            remain_cg_group=0,
            num_prefetch=0,

        )

    @triton_jit
    def wait_get_consumer(self, group: tl.constexpr, cp_remain_groups=None):
        group_comm = self.cur_load_groups.getitem(sym.unify_group_key(group)).value
        if self.record_waits:
            # self = self.record_start_profile_event(mp.format_string("{}|wait_consumer|{}", group, group_comm.info.num_stage))
            start_ts = self._get_start_profile_ts()

        if group_comm.use_mbarrier:
            read_phase = self.smem_read_idx // self.num_stage & 1
            bar = group_comm.producer_ready_bars.index(
                self.smem_read_idx % self.num_stage
            )
            mbarrier.wait(bar, read_phase)
        else:
            tl.static_assert(
                cp_remain_groups is not None,
                f"you must set cp_remain_groups when you use cp async load.",
            )
            # if cp_remain_groups is None:
            #     cp.wait_group(self.remain_cg_group - 1)
            # else:
            cp.wait_group(cp_remain_groups)
        if self.record_waits:
            self = self.record_end_profile_event(mp.format_string("{}|wait_consumer|{}", group, group_comm.info.num_stage), ext_start_ts=start_ts,
                user_scalar=self.smem_read_idx if self.record_pipeline_index else None)

        smems_dict = self.smems.get_subdict_by_sym(group)
        smem_values = [
            mp.TritonField(
                smems_dict.values_cw[i].value.index(
                    self.smem_read_idx % self.num_stage
                )
            )
            for i in tl.tuple(sym.tuple_range(len(smems_dict.keys)))
        ]

        res_self = aggregate_replace(
            self,
            remain_cg_group=self.remain_cg_group - (0 if group_comm.use_mbarrier else 1),
        )
        return res_self, LegacyPipelineConsumer(
            group=group,
            smem_dict=TTDict(smem_values, smems_dict.keys),
        )

    @triton_jit
    def _issue_load_gather_async(
        self, tensor_sym: tl.constexpr, apply_mask: tl.constexpr = True, other=None,
        force_mask_sym: tl.constexpr = None,
        gather_info: GatherInfo | None = None,
    ):
        group_key: tl.constexpr = _get_assoicated_group_key(
            tensor_sym, self.all_load_groups.keys
        )
        unified_group_key: tl.constexpr = sym.unify_group_key(tensor_sym)
        group_comm = self.cur_load_groups.getitem(group_key).value
        tl.static_assert(
            sym.is_subset_sym_in_sym(tensor_sym, group_comm.remain_group),
            f"tensor {tensor_sym} is not subset of remain "
            f"group {group_comm.remain_group} for load group {group_key}",
        )
        remain_sym: tl.constexpr = _remove_group_items_from_group(
            tensor_sym, group_comm.remain_group
        )
        smem_index = self.smem_write_idx % self.num_stage
        if group_comm.use_mbarrier:
            bar = group_comm.producer_ready_bars.index(smem_index)
        else:
            bar = None
        if group_comm.use_mbarrier and unified_group_key == group_key:
            # group start, currently mbarrier require this.
            tl.static_assert(
                group_comm.producer_ready_bars is not None,
                "mbarrier group should have barrier",
            )
            mbarrier.expect(
                bar, group_comm.nbytes
            )
        if self.cur_group_key != "":
            tl.static_assert(
                group_key == self.cur_group_key,
                f"you must finish current group {self.cur_group_key} before issue loads from other group {group_key}.",
            )
        tensor_names: tl.constexpr = sym.get_shape_names_from_sym(tensor_sym)
        tl.static_assert(
            self.all_load_groups.is_name_exists(unified_group_key).value,
            f"load group for tensor {tensor_sym} not found",
        )
        recorder = self.recorder
        for i in tl.static_range(len(tensor_names)):
            recorder = self._load_internal_async(
                smem_index,
                tl.constexpr(tensor_names[i]),
                apply_mask=apply_mask,
                other=other,
                bar=bar,
                force_mask_sym=force_mask_sym,
                gather_info=gather_info,
            )
        if remain_sym == "":
            new_cur_group_key: tl.constexpr = ""
        else:
            new_cur_group_key: tl.constexpr = group_key
        if remain_sym == "" and not group_comm.use_mbarrier:
            # group end, non-mbarrier (cp load) need this
            cp.commit_group()
        new_group_comm = aggregate_replace(
            group_comm,
            remain_group=remain_sym,
        )
        new_cur_load_groups = self.cur_load_groups.replaceitem(
            group_key, mp.TritonField(new_group_comm)
        )
        return aggregate_replace(
            self,
            recorder=recorder,
            remain_cg_group=self.remain_cg_group + (0 if group_comm.use_mbarrier else 1),
            cur_load_groups=new_cur_load_groups,
            cur_group_key=new_cur_group_key,
        )


    @triton_jit
    def issue_load_async(
        self, tensor_sym: tl.constexpr, apply_mask: tl.constexpr = True, other=None, force_mask_sym: tl.constexpr = None, 
        gather_info: GatherInfo | None = None,
    ):
        return self._issue_load_gather_async(tensor_sym, apply_mask, other, force_mask_sym=force_mask_sym,
            gather_info=gather_info)


    @triton_jit
    def increment(
        self,
        loop_name: tl.constexpr,
        n_block: tl.constexpr = 1,
        _is_prefetch: tl.constexpr = False,
        _is_drain: tl.constexpr = False,
    ) -> "Self":
        tl.static_assert(
            self.cur_group_key == "", f"{self.cur_group_key} is still pending."
        )
        res = aggregate_super_method(self.increment)(
            loop_name, n_block, inc_store_iters=not _is_prefetch
        )
        # reset load group state.
        if _is_prefetch:
            res = aggregate_replace(
                res,
                cur_load_groups=self.all_load_groups.clone(),
                smem_write_idx=self.smem_write_idx + n_block,
                num_prefetch=res.num_prefetch + n_block,
            )
        elif _is_drain:
            res = aggregate_replace(
                res,
                cur_load_groups=self.all_load_groups.clone(),
                smem_read_idx=self.smem_read_idx + n_block,
                num_prefetch=res.num_prefetch - n_block,
            )
        else:
            res = aggregate_replace(
                res,
                cur_load_groups=self.all_load_groups.clone(),
                smem_read_idx=self.smem_read_idx + n_block,
                smem_write_idx=self.smem_write_idx + n_block,
            )
        return res

    @triton_jit
    def increment_prefetch(
        self, loop_name: tl.constexpr, n_block: tl.constexpr = 1
    ) -> "Self":
        res = self.increment(loop_name, n_block, _is_prefetch=True)
        return res

    @triton_jit
    def increment_drain(
        self, loop_name: tl.constexpr, n_block: tl.constexpr = 1
    ) -> "Self":
        res = self.increment(loop_name, n_block, _is_drain=True)
        return res


    @triton_jit
    def _get_num_prefetch_cw(self):
        return mp.TritonConstexprField(self.num_prefetch)


@aggregate(kw_only=True)
class PipelineProducer(PipelineProducerBase):
    bar: gl.shared_memory_descriptor
    index: tl.tensor

    @triton_jit
    def finish(self, pred=True, count: tl.constexpr = 1, fence_shared: tl.constexpr = True):
        # only for mma without bar. for mma with bar, it will be automatically released when mma finished.
        if fence_shared:
            fence_async_shared()
        mbarrier.arrive(self.bar, count=count, pred=pred)

@aggregate(kw_only=True)
class PipelineWSConsumer(PipelineConsumerBase):
    bar: gl.shared_memory_descriptor
    index: tl.tensor

    @triton_jit
    def finish(self, pred=True, count: tl.constexpr = 1, fence_shared: tl.constexpr = True):
        # only for mma without bar. for mma with bar, it will be automatically released when mma finished.
        if fence_shared:
            fence_async_shared()
        mbarrier.arrive(self.bar, count=count, pred=pred)

# Helper for splitting a tensor along N. For our kernel, this only works for
# BLOCK_M=128 and num_warps=4, where all BLOCK_N elements are contiguously
# mapped to the same thread.
@gluon_jit
def _split_n(x, SUBTILE_FACTOR: gl.constexpr):
    split_count: gl.constexpr = SUBTILE_FACTOR.bit_length() - 1  # log2
    xs = (x, )
    for _ in gl.static_range(split_count):
        next_xs = ()
        for j in gl.static_range(len(xs)):
            x = xs[j]
            # Reshape to (M, 2, N//2) then permute so that tensor elements
            # remain contiguous along N.
            next_xs += x.reshape(x.shape[0], 2, x.shape[1] // 2).permute(0, 2, 1).split()
        xs = next_xs
    return xs

@aggregate(kw_only=True)
class PipelineWS(PipelinedIteratorBase):
    # TODO: currently only support 1-d loop.
    counters: TTDict
    num_prefetch: tl.constexpr
    outstanding_stores: tl.constexpr
    cur_store_groups: tl.constexpr

    @triton_jit
    def clear(self):
        return aggregate_replace(
            self,
            num_prefetch=0,
            cur_store_groups=sym.empty_list(),
            cur_group_key=tl.constexpr(""),
            cur_load_groups=self.all_load_groups.clone(),
        )
    
    @triton_jit
    def load_pipeline_state(self, other_pipe: "PipelineWS"):
        tl.static_assert(isinstance(other_pipe, PipelineWS), "other_pipe should be PipelineWS")
        return aggregate_replace(
            self,
            num_prefetch=other_pipe.num_prefetch,
            cur_store_groups=other_pipe.cur_store_groups,
            cur_group_key=other_pipe.cur_group_key,
            counters=other_pipe.counters.clone(),
            recorder=other_pipe.recorder,
        )


    @triton_jit
    def create_counter(self, key: tl.constexpr, phase, num_barriers: gl.constexpr):
        tl.static_assert(
            not self.counters.is_name_exists(key).value,
            f"counter with key {key} already exists",
        )

        counters = self.counters.additem(
            key,
            mp.TritonField(_GluonWSPipelineCounter.create(phase, num_barriers)),
        )
        return aggregate_replace(self, counters=counters)

    @triton_jit
    def wait_consumer(self, group: tl.constexpr, wait_static: tl.constexpr = True, pred=True):
        group_comm = self.cur_load_groups.getitem(sym.unify_group_key(group)).value
        counter = self.counters.getitem(sym.unify_group_key(group)).value
        if not wait_static:
            return self, group_comm, counter
        else:
            if group_comm.use_mbarrier:
                bar = group_comm.producer_ready_bars.index(counter.index)
                if self.record_waits:
                    start_ts = self._get_start_profile_ts()

                    # self = self.record_start_profile_event(mp.format_string("{}|wait_consumer|{}", group, group_comm.info.num_stage), remain_args=raw_ttdict(
                    #     comm_meta=group_comm.get_profile_metadata()
                    # ))

                mbarrier.wait(bar, counter.phase, pred=pred)
                if self.record_waits:
                    self = self.record_end_profile_event(mp.format_string("{}|wait_consumer|{}", group, group_comm.info.num_stage), remain_args=raw_ttdict(
                        comm_meta=group_comm.get_profile_metadata()
                    ), ext_start_ts=start_ts, user_scalar=counter.index if self.record_pipeline_index else None)

            else:
                tl.static_assert(
                    False,
                    f"cp consumer isn't allowed in WS pipeline.",
                )
            return self, group_comm, counter

    @triton_jit
    def get_consumer_for_init(self, group: tl.constexpr):
        group_comm = self.cur_load_groups.getitem(sym.unify_group_key(group)).value
        counter = self.counters.getitem(sym.unify_group_key(group)).value
        smems_dict = self.smems.get_subdict_by_sym(group)
        smem_values = [
            mp.TritonField(smems_dict.values_cw[i].value.index(counter.index))
            if smems_dict.values_cw[i].value is not None 
            else mp.TritonConstexprField(None)
            for i in tl.tuple(sym.tuple_range(len(smems_dict.keys)))
        ]
        return PipelineWSConsumer(
            group=group,
            smem_dict=TTDict(smem_values, smems_dict.keys),
            bar=group_comm.consumer_finish_bars.index(counter.index),
            index=counter.index,
        )

    @triton_jit
    def get_producer_for_init(self, group: tl.constexpr):
        group_comm = self.cur_load_groups.getitem(sym.unify_group_key(group)).value
        counter = self.counters.getitem(sym.unify_group_key(group)).value

        tl.static_assert(
            group_comm.use_mbarrier, "wait_get_producer only support mbarrier group"
        )
        producer_ready_bar = group_comm.producer_ready_bars.index(counter.index)
        smems_dict = self.smems.get_subdict_by_sym(group)
        smem_values = [
            mp.TritonField(smems_dict.values_cw[i].value.index(counter.index))
            if smems_dict.values_cw[i].value is not None 
            else mp.TritonConstexprField(None)
            for i in tl.tuple(sym.tuple_range(len(smems_dict.keys)))
        ]
        return PipelineProducer(
            group=group,
            smem_dict=TTDict(smem_values, smems_dict.keys),
            bar=producer_ready_bar,
            index=counter.index,
        )

    @triton_jit
    def wait_get_consumer(self, group: tl.constexpr, wait_static: tl.constexpr = True, pred=True):
        self, group_comm, counter = self.wait_consumer(group, wait_static, pred=pred)
        smems_dict = self.smems.get_subdict_by_sym(group)
        smem_values = [
            mp.TritonField(smems_dict.values_cw[i].value.index(counter.index))
            if smems_dict.values_cw[i].value is not None 
            else mp.TritonConstexprField(None)
            for i in tl.tuple(sym.tuple_range(len(smems_dict.keys)))
        ]
        return self, PipelineWSConsumer(
            group=group,
            smem_dict=TTDict(smem_values, smems_dict.keys),
            bar=group_comm.consumer_finish_bars.index(counter.index),
            index=counter.index,
        )

    @triton_jit
    def wait_get_producer(self, group: tl.constexpr, pred=True):
        group_comm = self.cur_load_groups.getitem(sym.unify_group_key(group)).value
        counter = self.counters.getitem(sym.unify_group_key(group)).value

        tl.static_assert(
            group_comm.use_mbarrier, "wait_get_producer only support mbarrier group"
        )
        # if group == "c":
        #     tl.device_print("index", counter.index)
        bar = group_comm.consumer_finish_bars.index(counter.index)
        producer_ready_bar = group_comm.producer_ready_bars.index(counter.index)
        if self.record_waits:
            # self = self.record_start_profile_event(mp.format_string("{}|wait_producer|{}", group, group_comm.info.num_stage), remain_args=raw_ttdict(
            #     comm_meta=group_comm.get_profile_metadata()
            # ))
            start_ts = self._get_start_profile_ts()
        mbarrier.wait(bar, counter.phase, pred=pred)
        if self.record_waits:
            self = self.record_end_profile_event(mp.format_string("{}|wait_producer|{}", group, group_comm.info.num_stage), remain_args=raw_ttdict(
                comm_meta=group_comm.get_profile_metadata()
            ), ext_start_ts=start_ts, user_scalar=counter.index if self.record_pipeline_index else None)

        smems_dict = self.smems.get_subdict_by_sym(group)
        smem_values = [
            mp.TritonField(smems_dict.values_cw[i].value.index(counter.index))
            if smems_dict.values_cw[i].value is not None 
            else mp.TritonConstexprField(None)
            for i in tl.tuple(sym.tuple_range(len(smems_dict.keys)))
        ]
        # res_self = self.increment_counters(group)
        return self, PipelineProducer(
            group=group,
            smem_dict=TTDict(smem_values, smems_dict.keys),
            bar=producer_ready_bar,
            index=counter.index,
        )

    @triton_jit
    def _issue_load_gather_async(
        self, tensor_sym: tl.constexpr, apply_mask: tl.constexpr = True, other=None,
        pred=True, offsets: TTDict | None = None,
        block_offsets: TTDict | None = None,
        gather_info: GatherInfo | None = None,
    ):
        group_key: tl.constexpr = _get_assoicated_group_key(
            tensor_sym, self.all_load_groups.keys
        )
        unified_group_key: tl.constexpr = sym.unify_group_key(tensor_sym)
        group_comm = self.cur_load_groups.getitem(group_key).value
        counter = self.counters.getitem(group_key).value

        tl.static_assert(
            sym.is_subset_sym_in_sym(tensor_sym, group_comm.remain_group),
            f"tensor {tensor_sym} is not subset of remain "
            f"group {group_comm.remain_group} for load group {group_key}",
        )
        remain_sym: tl.constexpr = _remove_group_items_from_group(
            tensor_sym, group_comm.remain_group
        )
        smem_index = counter.index
        if group_comm.use_mbarrier and unified_group_key == group_key:
            # group start, currently mbarrier require this.
            tl.static_assert(
                group_comm.producer_ready_bars is not None,
                "mbarrier group should have barrier",
            )
            if group_comm.is_tma:
                mbarrier.expect(
                    group_comm.producer_ready_bars.index(smem_index), group_comm.nbytes,
                    pred=pred,
                )
        if self.cur_group_key != "":
            tl.static_assert(
                group_key == self.cur_group_key,
                f"you must finish current group {self.cur_group_key} before issue loads from other group {group_key}.",
            )
        tensor_names: tl.constexpr = sym.get_shape_names_from_sym(tensor_sym)
        res = self
        for i in tl.static_range(len(tensor_names)):
            res = res._load_internal_async(
                smem_index,
                tl.constexpr(tensor_names[i]),
                apply_mask=apply_mask,
                other=other,
                bar=group_comm.producer_ready_bars.index(smem_index),
                pred=pred,
                offsets=offsets,
                block_offsets=block_offsets,
                gather_info=gather_info,
            )

        if remain_sym == "":
            new_cur_group_key: tl.constexpr = ""
        else:
            new_cur_group_key: tl.constexpr = group_key
        if remain_sym == "" and not group_comm.is_tma:
            # group end, cp load need this
            if group_comm.use_mbarrier:
                if isinstance(pred, int) and pred:
                    cp.mbarrier_arrive(group_comm.producer_ready_bars.index(smem_index))
                else:
                    if pred:
                        cp.mbarrier_arrive(group_comm.producer_ready_bars.index(smem_index))
                mbarrier.arrive(group_comm.producer_ready_bars.index(smem_index), pred=pred)
            else:
                if isinstance(pred, int) and pred:
                    cp.commit_group()
                else:
                    if pred:
                        cp.commit_group()

        new_group_comm = aggregate_replace(
            group_comm,
            remain_group=remain_sym,
        )
        new_cur_load_groups = self.cur_load_groups.replaceitem(
            group_key, mp.TritonField(new_group_comm)
        )
        return res

    @triton_jit
    def issue_load_async(
        self, tensor_sym: tl.constexpr, apply_mask: tl.constexpr = True, other=None, pred=True, 
        offsets: TTDict | None = None, block_offsets: TTDict | None = None, gather_info: GatherInfo | None = None,
    ):
        return self._issue_load_gather_async(tensor_sym, apply_mask, other, pred=pred, offsets=offsets, block_offsets=block_offsets, gather_info=gather_info)


    @triton_jit
    def piped_load_async(
        self, tensor_sym: tl.constexpr, apply_mask: tl.constexpr = True, other=None, pred=True, 
        offsets: TTDict | None = None, block_offsets: TTDict | None = None, gather_info: GatherInfo | None = None,
    ):
        """Wait producer, issue async load and increment counters.
        """
        pipeline, producer_iq = self.wait_get_producer(tensor_sym, pred=pred)
        pipeline = pipeline.issue_load_async(tensor_sym, apply_mask, other, pred=pred, offsets=offsets, block_offsets=block_offsets, gather_info=gather_info)
        pipeline = pipeline.increment_counters(tensor_sym, pred=pred) 
        return pipeline

    @triton_jit
    def piped_get_comsumer(
        self, tensor_sym: tl.constexpr, pred=True,
    ):
        """Wait consumer and increment counters.
        """
        pipeline, comsumer = self.wait_get_consumer(tensor_sym, pred=pred)
        pipeline = pipeline.increment_counters(tensor_sym, pred=pred) 
        return pipeline, comsumer

    @triton_jit
    def piped_load_comsumer_xmem(
        self, tensor_sym: tl.constexpr, layout: tl.constexpr,
    ):
        """Wait consumer and increment counters.
        """
        pipeline, comsumer = self.wait_get_consumer(tensor_sym)
        pipeline = pipeline.increment_counters(tensor_sym) 
        res = comsumer.load_xmem(tensor_sym, layout)
        comsumer.finish()
        return pipeline, res

    @triton_jit
    def piped_get_producer(
        self, tensor_sym: tl.constexpr, pred=True
    ):
        """Wait producer and increment counters.
        """
        pipeline, producer = self.wait_get_producer(tensor_sym, pred=pred)
        pipeline = pipeline.increment_counters(tensor_sym, pred=pred) 
        return pipeline, producer

    @triton_jit
    def piped_store_producer_xmem(
        self, tensor_sym: tl.constexpr, value, pred=True
    ):
        """Wait producer and increment counters.
        """
        pipeline, producer = self.wait_get_producer(tensor_sym, pred=pred)
        pipeline = pipeline.increment_counters(tensor_sym, pred=pred) 
        producer.store_xmem(tensor_sym, value)
        producer.finish(pred=pred)
        return pipeline

    @triton_jit
    def increment(
        self,
        loop_name: tl.constexpr,
        n_block: tl.constexpr = 1,
        _is_prefetch: tl.constexpr = False,
    ) -> "Self":
        tl.static_assert(
            self.cur_group_key == "", f"{self.cur_group_key} is still pending."
        )
        res = aggregate_super_method(self.increment)(
            loop_name, n_block, inc_store_iters=not _is_prefetch
        )
        if _is_prefetch:
            res = aggregate_replace(
                res,
                cur_load_groups=self.all_load_groups.clone(),
                num_prefetch=res.num_prefetch + n_block,
            )
        else:
            res = aggregate_replace(
                res,
                cur_load_groups=self.all_load_groups.clone(),
            )
        return res

    @triton_jit
    def _internal_increment_counters(
        self,
        counters_sym: tl.constexpr,
        pred=True
    ) -> "Self":
        # reset load group state.
        group_keys: tl.constexpr = sym.get_exist_group_in_sym(counters_sym, self.counters.keys)
        new_counter_cws = [
            mp.TritonField(
                self.counters.values_cw[i].value.next(pred=pred) 
                if (sym.is_name_in_names(self.counters.keys[i], group_keys)) 
                else self.counters.values_cw[i].value
            )
            for i in tl.tuple(sym.tuple_range(len(self.counters.keys)))
        ]

        new_counters = TTDict(
            keys=self.counters.keys,
            values_cw=new_counter_cws,
        )
        res = aggregate_replace(
            self,
            counters=new_counters,
        )
        return res

    @triton_jit
    def increment_counters(
        self,
        counters_sym: tl.constexpr,
        pred=True,
    ) -> "Self":
        return self._internal_increment_counters(counters_sym, pred=pred)

    @triton_jit
    def increment_prefetch(
        self, loop_name: tl.constexpr, n_block: tl.constexpr = 1
    ) -> "Self":
        res = self.increment(loop_name, n_block, _is_prefetch=True)
        return res

    @triton_jit
    def _get_num_prefetch_cw(self):
        return mp.TritonConstexprField(self.num_prefetch)


    @triton_jit
    def issue_store_async(
        self, tensor_sym: tl.constexpr, reduce_kind: tl.constexpr = None, offsets: TTDict | None = None, block_offsets: TTDict | None = None
    ):
        group_key: tl.constexpr = _get_assoicated_group_key(
            tensor_sym, self.all_load_groups.keys
        )
        group_comm = self.cur_load_groups.getitem(group_key).value
        counter = self.counters.getitem(group_key).value

        tl.static_assert(
            sym.is_subset_sym_in_sym(tensor_sym, group_comm.remain_group),
            f"tensor {tensor_sym} is not subset of remain "
            f"group {group_comm.remain_group} for load group {group_key}",
        )
        remain_sym: tl.constexpr = _remove_group_items_from_group(
            tensor_sym, group_comm.remain_group
        )
        smem_index = counter.index
        # tl.static_assert(group_comm.use_mbarrier and not group_comm.is_sync and group_comm.is_store, "issue_store_async only support mbarrier group currently.")
        tl.static_assert(group_comm.use_mbarrier and not group_comm.is_sync and group_comm.info.num_stage > 0, "issue_store_async only support mbarrier group currently.")

        tensor_names: tl.constexpr = sym.get_shape_names_from_sym(tensor_sym)
        recorder = self.recorder
        for i in tl.static_range(len(tensor_names)):
            tensor_name: tl.constexpr = tensor_names[i]
            desc = self.descs.getitem(tensor_name).value
            tl.static_assert(desc.is_tma_desc().value, "async store must be TMA for now.")

            scalar_offset_cws = self._get_offset_from_iter_cws(tensor_name, desc, ext_offset_cws=offsets, ext_block_offset_cws=block_offsets)
            smem = self.smems.getitem(tensor_name).value.index(smem_index)
            self = self.record_debug_event(raw_ttdict(
                name="store",
                is_sync=False,
                tensor_name=tensor_name,
                tensor_info=desc.get_json_data_cw(),
                offsets=scalar_offset_cws,
                reduce_kind=reduce_kind,
            ))
            desc.issue_tma_store_cw(scalar_offset_cws, smem, reduce_kind)

        if self.cur_group_key != "":
            tl.static_assert(
                group_key == self.cur_group_key,
                f"you must finish current group {self.cur_group_key} before issue loads from other group {group_key}.",
            )
        if remain_sym == "":
            new_store_groups: tl.constexpr = sym.append_item_to_list(group_key, self.cur_store_groups)
            new_cur_group_key: tl.constexpr = ""
        else:
            new_store_groups: tl.constexpr = self.cur_store_groups
            new_cur_group_key: tl.constexpr = group_key
        new_group_comm = aggregate_replace(
            group_comm,
            remain_group=remain_sym,
        )
        new_cur_load_groups = self.cur_load_groups.replaceitem(
            group_key, mp.TritonField(new_group_comm)
        )
        new_num_stores: tl.constexpr = self.outstanding_stores + (group_comm.info.num_stage - 1) * len(tensor_names)
        return aggregate_replace(
            self,
            recorder=recorder,
            cur_load_groups=new_cur_load_groups,
            cur_group_key=new_cur_group_key,
            outstanding_stores=new_num_stores,
            cur_store_groups=new_store_groups,
        )

    @triton_jit
    def flush_stores(self, iter):
        tma.store_wait(self.outstanding_stores)
        
        # pipeline delay is (group_comm.info.num_stage - 1)
        for i in tl.static_range(len(self.cur_store_groups)):
            group_key: tl.constexpr = self.cur_store_groups[i]
            group_comm = self.cur_load_groups.getitem(group_key).value
            pipeline_delay: tl.constexpr = group_comm.info.num_stage - 1
            counter = self.counters.getitem(group_key).value
            c_empty_bar = group_comm.consumer_finish_bars.index((counter.index + 1) % group_comm.info.num_stage)
            mbarrier.arrive(c_empty_bar, count=1, pred=iter >= pipeline_delay)

        return aggregate_replace(
            self,
            outstanding_stores=0,
            cur_store_groups=sym.empty_list(),
        )

    @triton_jit
    def tma_store_wait(self, pending):
        return self.async_store_wait(pending)

    @triton_jit
    def async_store_wait(self, pending):
        tma.store_wait(pending)

    @triton_jit
    def tma_store_subtiled_twostage(self, iter, src: tl.constexpr, dst: tl.constexpr, src_reg_layout: tl.constexpr):
        """Store a xmem (tmem/smem) to TMA target with subtiled support.
        this variant use 1x output smem and two-stage compute-store pipeline.

        NOTE: you should only use this for Tensor Memory for now, because
        TMA can copy from shared to global directly, no need to read to registers.
        but TMA don't support tensor memory to global, we have to read to registers
        first, and cause register pressure. so we may need to subtile the store.
        """
        res = self
        src_group_comm = self.cur_load_groups.getitem(src).value
        src_xmem = self.smems.getitem(src)
        dst_desc = self.descs.getitem(dst).value
        res, src_consumer = self.wait_get_consumer(src)
        dst_group_comm = self.cur_load_groups.getitem(dst).value
        tl.static_assert(dst_group_comm.info.num_stage == 1, f"only support 1-stage store pipeline.")
        tl.static_assert(src_xmem.shape[-1] % dst_desc.block_shape[-1] == 0, "currently only support subtile on the last dim, the subtile size should divide the block size.")
        split_factor: tl.constexpr = src_xmem.shape[-1] // dst_desc.block_shape[-1]
        split_n: tl.constexpr = dst_desc.block_shape[-1]
        tl.static_assert(src_group_comm.info.num_stage == 2, f"only support 2-stage compute-store pipeline.")
        dtype: tl.constexpr = dst_desc.ptr.dtype
        acc = src_consumer.load_xmem(src, src_reg_layout)
        counter = self.counters.getitem(src).value
        # variant 0 only need first smem.
        out_smem = self.smems.getitem(dst_desc).value.index(0)
        accs = _split_n(acc, split_factor)
        for i in gl.static_range(len(accs)):
            acc = accs[i].to(dtype)
            tma.store_wait(pendings=0)  # overlap with downcast
            out_smem.store(acc.to(dtype))
            # Arrive after the first SMEM store and rely on ptxas to interleave.
            if i == 0:
                c_empty_bar = src_group_comm.consumer_finish_bars.index((counter.index + 1) % src_group_comm.info.num_stage)
                mbarrier.arrive(c_empty_bar, count=1, pred=iter >= src_group_comm.info.num_stage - 1)
            fence_async_shared()
            scalar_offset_cws = self._get_offset_from_iter_cws(dst, dst_desc)
            scalar_offset_cws = [
                mp.dispatch_value(split_n * i + scalar_offset_cws[k].value)
                if k == len(scalar_offset_cws) - 1
                else scalar_offset_cws[k]
                for k in tl.tuple(sym.tuple_range(len(scalar_offset_cws)))
            ]
            dst_desc.issue_tma_store_cw(scalar_offset_cws, out_smem)
        return res

    @triton_jit
    def tma_store_subtiled_piped(self, src: tl.constexpr, dst: tl.constexpr, counter_key: tl.constexpr, src_reg_layout: tl.constexpr):
        """Store a xmem (tmem/smem) to TMA target with subtiled support.
        this variant use num_output_stage output smem, you need to create manual counter.
        
        NOTE: you should only use this for Tensor Memory for now, because
        TMA can copy from shared to global directly, no need to read to registers.
        but TMA don't support tensor memory to global, we have to read to registers
        first, and cause register pressure. so we may need to subtile the store.

        """
        res = self
        src_group_comm = self.cur_load_groups.getitem(src).value
        src_xmem = self.smems.getitem(src)
        dst_desc = self.descs.getitem(dst).value
        res, src_consumer = self.wait_get_consumer(src)
        dst_group_comm = self.cur_load_groups.getitem(dst).value
        tl.static_assert(src_xmem.shape[-1] % dst_desc.block_shape[-1] == 0, "currently only support subtile on the last dim, the subtile size should divide the block size.")
        split_factor: tl.constexpr = src_xmem.shape[-1] // dst_desc.block_shape[-1]
        split_n: tl.constexpr = dst_desc.block_shape[-1]
        src_counter = self.counters.getitem(src).value
        dtype: tl.constexpr = dst_desc.ptr.dtype

        acc_buf = src_xmem.index(src_counter.index)
        out_smem = self.smems.getitem(dst_desc).value

        for s in gl.static_range(split_factor):
            acc_sub = acc_buf.slice(split_n * s, split_n)
            subtile_counter = self.counters.getitem(counter_key).value
            acc_smem = out_smem.index(subtile_counter.index)
            acc = acc_sub.load(src_reg_layout).to(dtype)
            tma.store_wait(pendings=dst_group_comm.info.num_stage - 1)
            acc_smem.store(acc)
            scalar_offset_cws = self._get_offset_from_iter_cws(dst, dst_desc)
            scalar_offset_cws = [
                mp.dispatch_value(split_n * s + scalar_offset_cws[k].value)
                if k == len(scalar_offset_cws) - 1
                else scalar_offset_cws[k]
                for k in tl.tuple(sym.tuple_range(len(scalar_offset_cws)))
            ]
            dst_desc.issue_tma_store_cw(scalar_offset_cws, out_smem)
            res = res.increment_manual_counter(counter_key)
        c_empty_bar = src_group_comm.consumer_finish_bars.index(src_counter.index)
        mbarrier.arrive(c_empty_bar)
        return res

