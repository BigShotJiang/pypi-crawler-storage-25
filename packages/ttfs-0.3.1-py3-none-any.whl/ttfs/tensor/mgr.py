import ast
import dataclasses
import json
import traceback
from types import NoneType
from typing import Any

import torch

import triton.language as tl
from triton.experimental.gluon import language as gl
from typing_extensions import Annotated

from ttfs.core.aggtype import (
    FieldMeta,
    aggregate,
    aggregate_replace,
    triton_jit,
    constexpr_function,
)
from ttfs.core.mp import (
    TritonConstexprField,
    TritonField,
    cwrapped_add,
    filter_constexpr_fields,
    filter_non_constexpr_fields,
    get_all_field_keys_with_type,
    get_all_fields_with_type_gluon,
    get_constexpr_field_dict,
    get_dcls_fields,
    get_field,
    has_field,
    is_constexpr,
    is_gluon,
    replace_all_fields_with_type_gluon,
    replace_all_fields_with_type_triton,
    replace_fields_gluon,
    replace_fields_triton,
    tuple_to_cwrapper,
)
from ttfs.core import sym
from ttfs.core.ttdict import TTOffsetDict
from ttfs.core.mp import get_all_fields_with_type_triton
from triton.tools.tensor_descriptor import (
    TensorDescriptor as HostTensorDescriptorTriton,
)
from triton.experimental.gluon.nvidia.hopper import (
    TensorDescriptor as HostTensorDescriptorGluon,
)
from .base import TensorDesc, StrideWithMultipleOf
from .blocked import BlockedTensorDesc, BlockedTensorDescWithOffset, BlockedTensorDescTMAGluon, BlockedTensorDescTMATriton, TensorMgrDetachDimInfos


@aggregate
class TensorDimMultipleOf:
    pass

@triton_jit
def _cast_to_i32_if_needed(value_cw):
    if value_cw.is_constexpr:
        return value_cw
    else:
        value = value_cw.value
        if value.dtype == tl.int64:
            return TritonField(value.astype(tl.int32))
        else:
            return TritonField(value)


@triton_jit
def _cast_to_i64_if_needed(value_cw):
    if value_cw.is_constexpr:
        return value_cw
    else:
        value = value_cw.value
        if value.dtype == tl.int64:
            return TritonField(value.astype(tl.int64))
        else:
            return TritonField(value)

@sym.workaround_ignore_cache_record 
def _get_evaled_block_size_impl(constexpr_field_dict, block_size_json, block_stride_json):
    block_size_dict_items = json.loads(block_size_json)
    block_size_dict = dict(block_size_dict_items)
    block_stride_dict = {}
    if block_stride_json != "":
        block_stride_dict = json.loads(block_stride_json)
    block_stride_dict_res = {}
    block_names = list(block_size_dict.keys())
    block_values: list = []
    for eval_str in block_size_dict.values():
        try:
            value = eval(eval_str, {}, constexpr_field_dict)
        except:
            LOGGER.error(f"eval {eval_str} failed with input {constexpr_field_dict}")
            raise 
        block_values.append(value)
    for dim_name, eval_str in block_stride_dict.items():
        try:
            value = eval(eval_str, {}, constexpr_field_dict)
        except:
            LOGGER.error(f"eval {eval_str} failed with input {constexpr_field_dict}")
            raise 
        block_stride_dict_res[dim_name] = value

    block_sym = ",".join(block_names)
    block_stride_ttdict = TTOffsetDict(
        tl.tuple([TritonConstexprField(v) for v in block_stride_dict_res.values()]), tl.constexpr(list(block_stride_dict_res.keys()))
    )
    return block_sym, block_values, block_stride_ttdict


@constexpr_function 
def _get_evaled_block_size(constexpr_fields, block_size_json, block_stride_json):
    block_size_json = tl.core._unwrap_if_constexpr(block_size_json)
    block_stride_json = tl.core._unwrap_if_constexpr(block_stride_json)
    return _get_evaled_block_size_impl(constexpr_fields, block_size_json, block_stride_json)


@aggregate(kw_only=True)
class TensorManagerBase:
    ttfs_dim_multiple_of: TensorDimMultipleOf = dataclasses.field(
        default_factory=lambda: TensorDimMultipleOf()
    )
    _ttfs_internal_offs_dict: Annotated[
        TTOffsetDict, Any, FieldMeta(is_kernel_arg=False)
    ] = dataclasses.field(default_factory=TTOffsetDict)
    # store dims that replaced by replace_packed_dims.
    _ttfs_internal_original_dims: Annotated[
        TTOffsetDict, Any, FieldMeta(is_kernel_arg=False)
    ] = dataclasses.field(default_factory=TTOffsetDict)

    def __post_init__(self):
        # validate all TensorDesc fields
        fields = get_dcls_fields(self)
        all_fields_desc = []
        all_fields_not_desc = []
        for f in fields:
            key = f.name
            value = getattr(self, key)
            if isinstance(value, TensorDesc):
                all_fields_desc.append(key)
            else:
                all_fields_not_desc.append(key)
        for f in get_dcls_fields(TensorManagerBase):
            all_fields_not_desc.remove(f.name)
        shape_values = {}
        for f in fields:
            key = f.name
            value = getattr(self, key)
            if isinstance(value, TensorDesc):
                shape_sym = gl._unwrap_if_constexpr(value.shape_sym)
                shape_names, _ = sym.parse_shape_sym(shape_sym)

                if isinstance(value.ptr, torch.Tensor):
                    # cross-validation of shapes
                    for dim, shape_value in zip(shape_names, value.ptr.shape):
                        if dim in shape_values:
                            src_tensor_name, src_shape_value, shape_sym = shape_values[
                                dim
                            ]
                            assert src_shape_value == shape_value, (
                                f"Dimension {dim} has inconsistent shape values: {shape_values[dim]}({src_tensor_name}:{shape_sym}) and {shape_value}({key})."
                            )
                        else:
                            shape_values[dim] = (key, shape_value, value.shape_sym)
                elif isinstance(
                    value.ptr, (HostTensorDescriptorGluon, HostTensorDescriptorTriton)
                ):
                    assert isinstance(value.ptr.base, torch.Tensor), (
                        "Currently we only support host tensor desc with torch tensor base."
                    )
                    for dim, shape_value in zip(shape_names, value.ptr.base.shape):
                        if dim in shape_values:
                            src_tensor_name, src_shape_value, shape_sym = shape_values[
                                dim
                            ]
                            assert src_shape_value == shape_value, (
                                f"Dimension {dim} has inconsistent shape values: {shape_values[dim]}({src_tensor_name}:{shape_sym}) and {shape_value}({key})."
                            )
                        else:
                            shape_values[dim] = (key, shape_value, value.shape_sym)
                for dim_name in shape_names:
                    assert dim_name in all_fields_not_desc, (
                        f"Dimension {dim_name} doesn't exist in TensorManager. available dims: {all_fields_not_desc}"
                    )
                assert len(shape_names) == len(value.strides), (
                    f"Strides length {len(value.strides)} doesn't match shape length {len(shape_names)} for tensor {key}."
                )
        for f in fields:
            key = f.name
            value = getattr(self, key)
            if isinstance(value, tl.constexpr):
                if key in shape_values:
                    src_tensor_name, src_shape_value, shape_sym = shape_values[key]
                    assert src_shape_value == value.value, (
                        f"Dimension {key} has inconsistent shape values: {src_shape_value}({src_tensor_name}:{shape_sym}) and {value.value}({key})."
                    )

    @triton_jit
    def get_tensor_desc(self, name: tl.constexpr):
        desc = get_field(self, name).value
        return desc

    @triton_jit
    def get_dim_multiple_of(self, dim_name: tl.constexpr):
        if has_field(self.ttfs_dim_multiple_of, dim_name):
            dim_multiple_of_field = get_field(self.ttfs_dim_multiple_of, dim_name)
            tl.static_assert(
                dim_multiple_of_field.is_constexpr,
                "all fields in `ttfs_dim_multiple_of` must be constexpr.",
            )
            return dim_multiple_of_field
        else:
            return TritonConstexprField(1)

    @triton_jit
    def get_tensor_dim_size(self, name: tl.constexpr, axis: tl.constexpr):
        desc = get_field(self, name).value
        dim_name: tl.constexpr = sym.get_name_by_dim(desc.shape_sym, axis)
        return get_field(self, dim_name)

    @triton_jit
    def get_tensor_dim_size_by_name(self, name: tl.constexpr, dim_name: tl.constexpr):
        desc = get_field(self, name).value
        dim_name_unified: tl.constexpr = sym.local_name_to_global(
            desc.shape_sym, dim_name
        )
        return get_field(self, dim_name_unified)

    @triton_jit
    def get_tensor_stride(self, name: tl.constexpr, axis: tl.constexpr):
        return self.get_tensor_stride_with_multiple_of(name, axis).stride

    @triton_jit
    def _get_dim_field_may_replaced(
        self,
        name: tl.constexpr,
    ):
        if self._ttfs_internal_original_dims.is_name_exists(name).value:
            field = self._ttfs_internal_original_dims.getitem(name)
        else:
            field = get_field(self, tl.constexpr(name))
        return field

    @triton_jit
    def get_tensor_stride_with_multiple_of(
        self, name: tl.constexpr, axis: tl.constexpr
    ):
        desc = get_field(self, name).value
        stride_multiple_of_in_desc: tl.constexpr = desc.stride_multiple_of[axis]
        if is_constexpr(desc.strides[axis]):
            if desc.strides[axis] < 0:
                # if stride is unset, stride_multiple_of defined in desc will be ignored
                # calc stride from dims, assume contiguous
                stride_names: tl.constexpr = sym.get_stride_names(desc.shape_sym, axis)
                constexpr_fields: tl.constexpr = filter_constexpr_fields(
                    self, stride_names
                )
                non_constexpr_fields: tl.constexpr = filter_non_constexpr_fields(
                    self, stride_names
                )
                # aggregate can keep constexpr info
                stride_c = TritonConstexprField(1)
                stride_multiple_of_c = TritonConstexprField(1)
                for i in gl.static_range(len(constexpr_fields)):
                    field = self._get_dim_field_may_replaced(
                        tl.constexpr(constexpr_fields[i])
                    )
                    stride_c = TritonConstexprField(stride_c.value * field.value)
                    stride_multiple_of_c = TritonConstexprField(
                        stride_multiple_of_c.value
                        * self.get_dim_multiple_of(
                            tl.constexpr(constexpr_fields[i])
                        ).value
                    )
                if len(non_constexpr_fields) == 0:
                    return StrideWithMultipleOf(
                        stride_c,
                        stride_multiple_of_c.value,
                        False,
                    )
                else:
                    # for non-constexpr dims, we may need to use multiple_of
                    stride = 1
                    for i in gl.static_range(len(non_constexpr_fields)):
                        field = self._get_dim_field_may_replaced(
                            tl.constexpr(non_constexpr_fields[i])
                        )
                        # field = get_field(self, tl.constexpr(non_constexpr_fields[i]))
                        stride *= field.value
                        stride_multiple_of_c = TritonConstexprField(
                            stride_multiple_of_c.value
                            * self.get_dim_multiple_of(
                                tl.constexpr(non_constexpr_fields[i])
                            ).value
                        )

                    return StrideWithMultipleOf(
                        TritonField(stride * stride_c.value),
                        stride_multiple_of_c.value,
                        stride_multiple_of_c.value != 1,
                    )
            else:
                return StrideWithMultipleOf(
                    TritonConstexprField(desc.strides[axis]),
                    stride_multiple_of_in_desc,
                    stride_multiple_of_in_desc != 1,
                )
        else:
            return StrideWithMultipleOf(
                TritonField(desc.strides[axis]),
                stride_multiple_of_in_desc,
                stride_multiple_of_in_desc != 1,
            )

    @triton_jit
    def get_tensor_stride_by_name(self, name: tl.constexpr, dim_name: tl.constexpr):
        desc = get_field(self, name).value
        dim_name_unified: tl.constexpr = sym.local_name_to_global(
            desc.shape_sym, dim_name
        )
        axis: tl.constexpr = sym.get_dim_by_name(desc.shape_sym, dim_name_unified)
        return self.get_tensor_stride(name, axis)

    @triton_jit
    def get_tensor_stride_with_multiple_of_by_name(
        self, name: tl.constexpr, dim_name: tl.constexpr
    ):
        desc = get_field(self, name).value
        dim_name_unified: tl.constexpr = sym.local_name_to_global(
            desc.shape_sym, dim_name
        )
        axis: tl.constexpr = sym.get_dim_by_name(desc.shape_sym, dim_name_unified)
        return self.get_tensor_stride_with_multiple_of(name, axis)

    @triton_jit
    def get_dim_offset_by_name_cwrapper(self, dim_name: tl.constexpr):
        if self._ttfs_internal_offs_dict.is_name_exists(dim_name).value:
            return self._ttfs_internal_offs_dict.getitem(dim_name)
        else:
            return TritonConstexprField(0)

    @triton_jit
    def get_dim_offset_tuple_cwrapper_by_names(self, dim_names: tl.constexpr):
        dim_name_lst: tl.constexpr = sym.unify_offset_names(dim_names)
        return [
            self.get_dim_offset_by_name_cwrapper(tl.constexpr(dim_name_lst[i]))
            for i in tl.tuple(sym.tuple_range(len(dim_name_lst)))
        ]

    @triton_jit
    def get_tensor_dim_is_divisible(
        self, name: tl.constexpr, axis: tl.constexpr, divisor: tl.constexpr
    ):
        desc = get_field(self, name).value
        dim_size = self.get_tensor_dim_size(name, axis)
        if dim_size.is_constexpr:
            return TritonConstexprField(dim_size.value % divisor == 0)
        else:
            dim_multiple_of: tl.constexpr = self.get_dim_multiple_of(
                sym.get_name_by_dim(desc.shape_sym, axis)
            ).value
            return TritonConstexprField(dim_multiple_of % divisor == 0)

    @triton_jit
    def get_ptr_offset(
        self,
        name: tl.constexpr,
        off_names: tl.constexpr,
        values_cw: tl.tuple,
    ):
        # off_names can be constexpr(["M", "N"]) or "M,N"
        off_names_u: tl.constexpr = sym.unify_offset_names(off_names)
        desc = get_field(self, name).value
        noffs = TTOffsetDict(values_cw, off_names_u).filter_by_sym_include(
            desc.shape_sym
        )
        if len(noffs.keys) == 0:
            return 0
        else:
            offset = 0
            for i in gl.static_range(len(noffs.keys)):
                offset = (
                    offset
                    + self.get_tensor_stride_by_name(
                        name, tl.constexpr(noffs.keys[i])
                    ).value
                    * noffs.values_cw[i].value
                )
            return offset

    @triton_jit
    def get_offseted_ptr(
        self,
        name: tl.constexpr,
        off_names_sym: tl.constexpr,
        values_cw: tl.tuple,
        cast_offset_to_64bit: tl.constexpr = False,
    ):
        desc = get_field(self, name).value
        tl.static_assert(
            not desc.is_tma_desc().value, "Only support pointer tensor desc."
        )
        if cast_offset_to_64bit:
            values_cw = [
                _cast_to_i64_if_needed(values_cw[i])
                for i in tl.tuple(sym.tuple_range(len(values_cw)))
            ]
        return desc.ptr + self.get_ptr_offset(name, off_names_sym, values_cw)

    @triton_jit
    def get_current_offseted_ptr_except(
        self,
        name: tl.constexpr,
        except_sym: tl.constexpr,
        cast_offset_to_64bit: tl.constexpr = False,
    ):
        new_named_offs = self._ttfs_internal_offs_dict.filter_by_sym_exclude(
            except_sym
        )
        return self.get_offseted_ptr(
            name,
            new_named_offs.keys,
            new_named_offs.values_cw,
            cast_offset_to_64bit,
        )

    @triton_jit
    def get_tensor_dim_sizes_by_sym(self, name: tl.constexpr, shape_sym: tl.constexpr):
        shape_names: tl.constexpr = sym.get_shape_names_from_sym(shape_sym)
        shape = [
            self.get_tensor_dim_size_by_name(name, tl.constexpr(shape_names[i]))
            for i in tl.tuple(sym.tuple_range(len(shape_names)))
        ]
        return shape

    @triton_jit
    def get_tensor_strides_by_sym(self, name: tl.constexpr, shape_sym: tl.constexpr):
        shape_names: tl.constexpr = sym.get_shape_names_from_sym(shape_sym)
        shape = [
            self.get_tensor_stride_by_name(name, tl.constexpr(shape_names[i]))
            for i in tl.tuple(sym.tuple_range(len(shape_names)))
        ]
        return shape

    @triton_jit
    def get_block_desc(
        self,
        name: tl.constexpr,
        block_shape_sym: tl.constexpr,
        block_sizes: tl.constexpr,
        block_layout: tl.constexpr = None,
    ):
        desc = get_field(self, name).value
        desc.assert_is_pointer()
        desc.assert_is_valid()
        block_shape_sym_global: tl.constexpr = sym.local_sym_to_global(
            desc.shape_sym, block_shape_sym
        )
        detached_dims = self._detach_tm_dim_infos(name)
        if sym.is_any_sym_in_names(
            block_shape_sym_global, self._ttfs_internal_offs_dict.keys
        ):
            named_offsets = self._ttfs_internal_offs_dict.get_subdict_by_sym_default_zero(
                block_shape_sym_global
            )
            return BlockedTensorDescWithOffset(
                # ptr=desc.ptr,
                ptr=self.get_current_offseted_ptr_except(name, block_shape_sym_global),
                shape_sym=desc.shape_sym,
                strides=desc.strides,
                detached_dims=detached_dims,
                name=name,
                # mgr=self,
                io_layout=block_layout,
                block_shape_sym=block_shape_sym_global,
                block_shape=block_sizes,
                named_offsets=named_offsets,
            )
        else:
            # return a pointer with current offset variables.
            # block_offsets
            return BlockedTensorDesc(
                # ptr=desc.ptr,
                ptr=self.get_current_offseted_ptr_except(name, block_shape_sym_global),
                shape_sym=desc.shape_sym,
                detached_dims=detached_dims,
                strides=desc.strides,
                name=name,
                # mgr=self,
                io_layout=block_layout,
                block_shape_sym=block_shape_sym_global,
                block_shape=block_sizes,
            )

    @triton_jit
    def _get_external_block_info_cw(
        self,
        name: tl.constexpr,
    ):
        # TODO block_sizes must be constexpr, check this.
        desc = get_field(self, name).value
        tl.static_assert(desc.block_size_json != "", "block_size_json must be provided for external block info.")
        res: tl.constexpr = _get_evaled_block_size(get_constexpr_field_dict(self), desc.block_size_json, desc.block_stride_json)
        block_sym: tl.constexpr = res[0]
        block_sizes: tl.constexpr = res[1]
        block_strides_ttdict = res[2]
        return TritonConstexprField(block_sym), TritonConstexprField(block_sizes), block_strides_ttdict

    @triton_jit
    def _get_external_block_strides(
        self,
        name: tl.constexpr,
    ):
        return self._get_external_block_info_cw(name)[2]


    @triton_jit
    def get_offseted_block_desc(
        self,
        name: tl.constexpr,
        block_shape_sym: tl.constexpr,
        block_sizes: tl.constexpr,
        block_layout: tl.constexpr = None,
        cast_offset_to_64bit: tl.constexpr = False,
    ):
        # TODO block_sizes must be constexpr, check this.
        desc = get_field(self, name).value
        desc.assert_is_pointer()
        desc.assert_is_valid()
        block_shape_sym_global: tl.constexpr = sym.local_sym_to_global(
            desc.shape_sym, block_shape_sym
        )
        named_offsets = self._ttfs_internal_offs_dict.get_subdict_by_sym_default_zero(
            block_shape_sym_global
        )
        if cast_offset_to_64bit:
            named_offsets = named_offsets.cast_to_i64_if_needed()
        # tl.static_print(block_shape_sym_global, named_offsets)
        detached_dims = self._detach_tm_dim_infos(name)

        return BlockedTensorDescWithOffset(
            # ptr=desc.ptr,
            ptr=self.get_current_offseted_ptr_except(
                name, block_shape_sym_global, cast_offset_to_64bit
            ),
            shape_sym=desc.shape_sym,
            strides=desc.strides,
            name=name,
            detached_dims=detached_dims,
            # mgr=self,
            io_layout=block_layout,
            block_shape_sym=block_shape_sym_global,
            block_shape=block_sizes,
            named_offsets=named_offsets,
        )

    @triton_jit
    def get_predefined_offseted_block_desc(
        self,
        name: tl.constexpr,
        block_layout: tl.constexpr = None,
        cast_offset_to_64bit: tl.constexpr = False,
    ):
        # TODO block_sizes must be constexpr, check this.
        block_sym_cw, block_size_cw, _ = self._get_external_block_info_cw(name)
        return self.get_offseted_block_desc(
            name,
            block_shape_sym=block_sym_cw.value,
            block_sizes=block_size_cw.value,
            block_layout=block_layout,
            cast_offset_to_64bit=cast_offset_to_64bit,
        )


    @triton_jit
    def _get_offseted_block_desc_by_named_offset(
        self,
        name: tl.constexpr,
        named_offset: TTOffsetDict,
        cast_offset_to_64bit: tl.constexpr = False,
    ):
        block_shape_sym: tl.constexpr = sym.names_to_sym(named_offset.keys)
        block_sizes: tl.constexpr = [
            tl.constexpr(named_offset.values_cw[i].value)
            for i in tl.tuple(sym.tuple_range(len(named_offset.keys)))
        ]
        return self.get_offseted_block_desc(
            name,
            block_shape_sym,
            block_sizes,
            cast_offset_to_64bit=cast_offset_to_64bit,
        )


    @triton_jit
    def get_offseted_block_descs(
        self,
        desc_dicts,
        cast_offset_to_64bit: tl.constexpr = False,
    ) -> tuple["BlockedTensorDescWithOffset", ...]:
        res = [
            self._get_offseted_block_desc_by_named_offset(
                tl.constexpr(desc_dicts.keys[i]), 
                named_offset=desc_dicts.values_cw[i].value,
                cast_offset_to_64bit=cast_offset_to_64bit,
            )
            for i in tl.tuple(sym.tuple_range(len(desc_dicts.keys)))
        ]
        return res 

    @triton_jit
    def _detach_tm_dim_infos(
        self,
        name: tl.constexpr,
    ):
        # return a dim_name->dim_value and dim_name->dim_multiple_of dict.
        desc = get_field(self, name).value
        desc.assert_is_valid()
        shape_names: tl.constexpr = sym.get_shape_names_from_sym(desc.shape_sym)
        dims = [
            self.get_tensor_dim_size_by_name(name, tl.constexpr(shape_names[i]))
            for i in tl.tuple(sym.tuple_range(len(shape_names)))
        ]
        dims_dict = TTOffsetDict(dims, shape_names)

        dim_multiple_ofs = [
            self.get_dim_multiple_of(tl.constexpr(shape_names[i]))
            for i in tl.tuple(sym.tuple_range(len(shape_names)))
        ]
        dim_multiple_ofs_dict = TTOffsetDict(dim_multiple_ofs, shape_names)

        original_dims = self._ttfs_internal_original_dims.filter_by_sym_include(desc.shape_sym)
        return TensorMgrDetachDimInfos(dims_dict, dim_multiple_ofs_dict, original_dims)

    @triton_jit
    def _get_external_tma_block_desc_metadata(
        self,
        name: tl.constexpr,
        block_shape_sym: tl.constexpr,
    ):
        desc = get_field(self, name).value
        desc.assert_is_valid()
        tl.static_assert(desc.is_tma_desc().value, "must be a tensor desc")
        # TODO validate block_shape_sym
        block_sym_global: tl.constexpr = sym.local_sym_to_global(
            desc.shape_sym, block_shape_sym
        )
        block_sym_global_names: tl.constexpr = sym.get_shape_names_from_sym(
            block_sym_global
        )
        block_sym_axes: tl.constexpr = sym.get_sym_axes(desc.shape_sym, block_shape_sym)
        assert sym.is_int_list_sorted(block_sym_axes), (
            f"block_sym {block_shape_sym} must have same order as shape_sym {desc.shape_sym} in TMA."
        )

        named_offs_except_block = (
            self._ttfs_internal_offs_dict.filter_by_sym_exclude(block_sym_global)
        )
        named_offs_immu_except_block = (
            desc._ttfs_immutable_offs_dict.filter_by_sym_exclude(block_sym_global)
        )
        block_offset_in_tm = self.get_dim_offset_tuple_cwrapper_by_names(
            block_sym_global
        )
        immu_block_offset = (
            desc._ttfs_immutable_offs_dict.get_offsets_cw_by_sym_default_zero(
                block_sym_global
            )
        )
        offset_tuple_with_immu_offset = [
            cwrapped_add(block_offset_in_tm[i], immu_block_offset[i])
            for i in tl.tuple(sym.tuple_range(len(block_offset_in_tm)))
        ]
        new_named_offs = TTOffsetDict(
            offset_tuple_with_immu_offset, block_sym_global_names
        )
        final_non_block_no = named_offs_except_block.merge_add_offsets(
            named_offs_immu_except_block.keys,
            named_offs_immu_except_block.values_cw,
        )
        return new_named_offs, final_non_block_no

    @triton_jit
    def get_external_tma_block_desc(
        self,
        name: tl.constexpr,
        block_shape_sym: tl.constexpr,
        offset_tuple=None,
    ):

        new_named_offs, final_non_block_no = self._get_external_tma_block_desc_metadata(
            name, block_shape_sym
        )
        desc = get_field(self, name).value
        desc.assert_is_valid()
        tl.static_assert(desc.is_tma_desc().value, "must be a tensor desc")
        tma_desc = desc.ptr
        # TODO validate block_shape_sym
        block_sym_global: tl.constexpr = sym.local_sym_to_global(
            desc.shape_sym, block_shape_sym
        )
        block_sym_global_names: tl.constexpr = sym.get_shape_names_from_sym(
            block_sym_global
        )
        block_sym_axes: tl.constexpr = sym.get_sym_axes(desc.shape_sym, block_shape_sym)
        assert sym.is_int_list_sorted(block_sym_axes), (
            f"block_sym {block_shape_sym} must have same order as shape_sym {desc.shape_sym} in TMA."
        )
        local_block_shape: tl.constexpr = sym.index_shape_and_valid_other_one(
            desc.ptr.block_shape, block_sym_axes
        )
        detached_dims = self._detach_tm_dim_infos(name)
        return BlockedTensorDescTMATriton(
            ptr=tma_desc,
            shape_sym=desc.shape_sym,
            strides=desc.strides,
            name=name,
            # mgr=self,
            detached_dims=detached_dims,
            block_shape_sym=block_sym_global,
            block_shape=local_block_shape,
            non_block_named_offsets=final_non_block_no,
            named_offsets=(
                TTOffsetDict(offset_tuple, block_sym_global_names)
                if offset_tuple is not None
                else new_named_offs
            ),
        )

    @triton_jit
    def get_predefined_external_tma_block_desc(
        self,
        name: tl.constexpr,
        offset_tuple=None,
    ):
        block_shape_sym, _, _ = self._get_external_block_info_cw(name)
        return self.get_external_tma_block_desc(
            name,
            block_shape_sym.value,
            offset_tuple=offset_tuple,
        )

    @triton_jit
    def get_external_tma_block_desc_gluon(
        self,
        name: tl.constexpr,
        block_shape_sym: tl.constexpr,
    ):
        new_named_offs, final_non_block_no = self._get_external_tma_block_desc_metadata(
            name, block_shape_sym
        )
        desc = get_field(self, name).value
        desc.assert_is_valid()
        tl.static_assert(is_gluon() and desc.is_tma_desc().value, f"{name} must in gluon and be a tensor desc")
        # TODO validate block_shape_sym
        block_sym_global: tl.constexpr = sym.local_sym_to_global(
            desc.shape_sym, block_shape_sym
        )
        block_sym_global_names: tl.constexpr = sym.get_shape_names_from_sym(
            block_sym_global
        )
        # tl.static_assert(len(block_sym_global_names) == len(desc.ptr.shape), f"ndim mismatch, got {len(block_sym_global_names)} but expected {len(desc.ptr.shape)}")
        block_sym_axes: tl.constexpr = sym.get_sym_axes(desc.shape_sym, block_shape_sym)
        assert sym.is_int_list_sorted(block_sym_axes), (
            f"block_sym {block_shape_sym} must have same order as shape_sym {desc.shape_sym} in TMA."
        )
        local_block_shape: tl.constexpr = sym.index_shape_and_valid_other_one(
            desc.ptr.block_shape, block_sym_axes
        )
        detached_dims = self._detach_tm_dim_infos(name)
        return BlockedTensorDescTMAGluon(
            ptr=desc.ptr,
            shape_sym=desc.shape_sym,
            strides=desc.strides,
            name=name,
            detached_dims=detached_dims,
            # mgr=self,
            block_shape_sym=block_sym_global,
            block_shape=local_block_shape,
            non_block_named_offsets=final_non_block_no,
            named_offsets=new_named_offs,
        )

    @triton_jit
    def get_predefined_unified_desc(
        self,
        name: tl.constexpr,
    ):
        block_shape_sym_cw, block_size_cw, _ = self._get_external_block_info_cw(name)
        desc = get_field(self, name).value
        if desc.is_tma_desc().value:
            if is_gluon():
                return self.get_external_tma_block_desc_gluon(
                    name,
                    block_shape_sym_cw.value,
                )
            else:
                return self.get_external_tma_block_desc(
                    name,
                    block_shape_sym_cw.value,
                )
        else:

            return self.get_offseted_block_desc(
                name,
                block_shape_sym_cw.value,
                block_sizes=block_size_cw.value,
            )

    @triton_jit
    def get_predefined_external_tma_block_desc_gluon(
        self,
        name: tl.constexpr,
    ):
        block_shape_sym_cw, block_size_cw, _ = self._get_external_block_info_cw(name)
        return self.get_external_tma_block_desc_gluon(
            name,
            block_shape_sym_cw.value,
        )

    @triton_jit
    def get_external_tma_block_desc_gluon_v2(
        self,
        name: tl.constexpr,
    ):
        # TODO remove v1 version since external TMA don't support change block sym inside kernel.
        block_shape_sym: tl.constexpr = get_field(self, name).value.shape_sym
        return self.get_external_tma_block_desc_gluon(
            name,
            block_shape_sym,
        )

    @triton_jit
    def _get_external_tma_block_desc_gluon_by_named_offsets(
        self,
        name: tl.constexpr,
        named_offset: TTOffsetDict,
    ):
        block_shape_sym: tl.constexpr = sym.names_to_sym(named_offset.keys)
        return self.get_external_tma_block_desc_gluon(
            name,
            block_shape_sym,
        )

    @triton_jit
    def get_external_tma_block_gluon_descs(
        self,
        desc_syms: tl.constexpr,
    ) -> tuple["BlockedTensorDescTMAGluon", ...]:
        desc_syms_part: tl.constexpr = sym.unify_offset_names(desc_syms)
        res = [
            self.get_external_tma_block_desc_gluon_v2(
                tl.constexpr(desc_syms_part[i]), 
            )
            for i in tl.tuple(sym.tuple_range(len(desc_syms_part)))
        ]
        return res 

    @triton_jit
    def create_offseted_tma_block_desc(
        self,
        name: tl.constexpr,
        block_shape_sym: tl.constexpr,
        block_sizes: tl.constexpr,
        cast_offset_to_64bit: tl.constexpr = False,
    ):
        desc = get_field(self, name).value
        desc.assert_is_valid()
        tl.static_assert(not desc.is_tma_desc().value, "this function is used for device-side TensorDescriptor.")
        shape = self.get_tensor_dim_sizes_by_sym(name, block_shape_sym)
        strides = self.get_tensor_strides_by_sym(name, block_shape_sym)
        block_shape_sym_global: tl.constexpr = sym.local_sym_to_global(
            desc.shape_sym, block_shape_sym
        )
        named_offsets = self._ttfs_internal_offs_dict.get_subdict_by_sym_default_zero(
            block_shape_sym_global
        )
        if cast_offset_to_64bit:
            named_offsets = named_offsets.cast_to_i64_if_needed()

        new_ptr = self.get_current_offseted_ptr_except(
            name, block_shape_sym_global, cast_offset_to_64bit
        ),

        tma_desc = tl.make_tensor_descriptor(
            new_ptr, shape, strides, block_sizes
        )
        detached_dims = self._detach_tm_dim_infos(name)

        return BlockedTensorDescTMATriton(
            ptr=tma_desc,
            shape_sym=block_shape_sym_global,
            strides=[
                s.value for s in tl.tuple(sym.tuple_range(len(strides)))
            ],
            name=name,
            detached_dims=detached_dims,
            # mgr=self,
            block_shape_sym=block_shape_sym_global,
            block_shape=block_sizes,
            named_offsets=named_offsets,
            layout=None,
            non_block_named_offsets=TTOffsetDict([], tl.constexpr([]))
        )

    @triton_jit
    def create_offseted_tma_block_desc_gluon(
        self,
        name: tl.constexpr,
        block_shape_sym: tl.constexpr,
        block_sizes: tl.constexpr,
        cast_offset_to_64bit: tl.constexpr = False,
        padding_option: tl.constexpr = "zero",
        smem_layout: tl.constexpr = None

    ):
        desc = get_field(self, name).value
        desc.assert_is_valid()
        tl.static_assert(not desc.is_tma_desc().value, "this function is used for device-side TensorDescriptor.")
        shape = self.get_tensor_dim_sizes_by_sym(name, block_shape_sym)
        strides = self.get_tensor_strides_by_sym(name, block_shape_sym)
        block_shape_sym_global: tl.constexpr = sym.local_sym_to_global(
            desc.shape_sym, block_shape_sym
        )
        named_offsets = self._ttfs_internal_offs_dict.get_subdict_by_sym_default_zero(
            block_shape_sym_global
        )
        if cast_offset_to_64bit:
            named_offsets = named_offsets.cast_to_i64_if_needed()

        new_ptr = self.get_current_offseted_ptr_except(
            name, block_shape_sym_global, cast_offset_to_64bit
        ),
        if smem_layout is None:
            smem_layout_v: tl.constexpr = gl.NVMMASharedLayout.get_default_for(
                block_sizes,
                desc.get_dtype().value,
                # TODO transposed only support matrix.
                transposed=sym.check_matrix_is_transposed(
                    desc.shape_sym, block_shape_sym
                ),
            )
        else:
            smem_layout_v: tl.constexpr = smem_layout
        # WARNING: this requires triton 3.6+
        tma_desc = gl.nvidia.hopper.tma.make_tensor_descriptor(
            new_ptr, shape, strides, block_sizes, smem_layout_v,
            padding_option=padding_option
        )
        detached_dims = self._detach_tm_dim_infos(name)

        return BlockedTensorDescTMAGluon(
            ptr=tma_desc,
            shape_sym=block_shape_sym_global,
            strides=[
                s.value for s in tl.tuple(sym.tuple_range(len(strides)))
            ],
            detached_dims=detached_dims,
            name=name,
            # mgr=self,
            block_shape_sym=block_shape_sym_global,
            block_shape=block_sizes,
            named_offsets=named_offsets,
            layout=smem_layout,
            non_block_named_offsets=TTOffsetDict([], tl.constexpr([]))
        )

    @triton_jit
    def _get_offseted_desc(
        self,
        desc_key: tl.constexpr,
        desc,
        off_names_sym: tl.constexpr,
        values_cw: tl.tuple,
    ):

        if desc.is_valid_desc().value:
            if desc.is_tma_desc().value:
                res = desc.get_immutable_offseted_desc(
                    off_names=sym.get_shape_names_from_sym(off_names_sym),
                    values_cw=values_cw,
                )
            else:
                res = aggregate_replace(
                    desc,
                    ptr=self.get_offseted_ptr(
                        desc_key,
                        off_names_sym,
                        values_cw,
                        cast_offset_to_64bit=True,
                    ),
                )

        else:
            res = desc
        return res

    @triton_jit
    def offset_all_tensor_ptr(self, off_names_sym: tl.constexpr, offsets: tl.tuple):
        """offset all tensor desc ptrs that contain dimensions in off_names.
        e.g. for tensor manager with q(B, S, H, D), m(B, H, S) and c(B, S),
        tm.offset_all_tensor_ptr(["B", "H"], (1, 2)) will offset q and m ptrs by b and h.
        c will be offseted only by b.

        tensor descriptors behavior is same as `offset_all_tensor`.

        WARNING: you should use offset_all_tensor for dimensions that need to check boundry.
        WARNING: this function should be used in situation such as varlen attn.
        """
        off_names: tl.constexpr = sym.get_shape_names_from_sym(off_names_sym)
        tl.static_assert(
            len(off_names) == len(offsets), "offset names and offsets length mismatch."
        )
        all_field_keys: tl.constexpr = get_all_field_keys_with_type(self, TensorDesc)
        values_cw = tuple_to_cwrapper(offsets)
        if is_gluon():
            all_fields_tuple = get_all_fields_with_type_gluon(self, TensorDesc)
            all_fields_tuple_offseted = [
                self._get_offseted_desc(
                    all_field_keys[i],
                    all_fields_tuple[i],
                    off_names_sym,
                    values_cw,
                )
                for i in tl.tuple(sym.tuple_range(len(all_field_keys)))
            ]
            return replace_all_fields_with_type_gluon(
                self, TensorDesc, all_fields_tuple_offseted
            )
        else:
            all_fields_tuple = get_all_fields_with_type_triton(self, TensorDesc)

            all_fields_tuple_offseted = [
                self._get_offseted_desc(
                    all_field_keys[i],
                    all_fields_tuple[i],
                    off_names_sym,
                    values_cw,
                )
                for i in tl.tuple(sym.tuple_range(len(all_field_keys)))
            ]
            return replace_all_fields_with_type_triton(
                self, TensorDesc, all_fields_tuple_offseted
            )

    @triton_jit
    def offset_all_tensor_ptr_v2(self, named_offs: TTOffsetDict):
        """offset all tensor desc ptrs that contain dimensions in off_names.
        e.g. for tensor manager with q(B, S, H, D), m(B, H, S) and c(B, S),
        tm.offset_all_tensor_ptr(["B", "H"], (1, 2)) will offset q and m ptrs by b and h.
        c will be offseted only by b.

        tensor descriptors behavior is same as `offset_all_tensor`.

        WARNING: you should use offset_all_tensor for dimensions that need to check boundry.
        WARNING: this function should be used in situation such as varlen attn.
        """
        off_names_sym: tl.constexpr = sym.names_to_sym(named_offs.keys)
        all_field_keys: tl.constexpr = get_all_field_keys_with_type(self, TensorDesc)
        if is_gluon():
            all_fields_tuple = get_all_fields_with_type_gluon(self, TensorDesc)
            all_fields_tuple_offseted = [
                self._get_offseted_desc(
                    all_field_keys[i],
                    all_fields_tuple[i],
                    off_names_sym,
                    named_offs.values_cw,
                )
                for i in tl.tuple(sym.tuple_range(len(all_field_keys)))
            ]
            return replace_all_fields_with_type_gluon(
                self, TensorDesc, all_fields_tuple_offseted
            )
        else:
            all_fields_tuple = get_all_fields_with_type_triton(self, TensorDesc)

            all_fields_tuple_offseted = [
                self._get_offseted_desc(
                    all_field_keys[i],
                    all_fields_tuple[i],
                    off_names_sym,
                    named_offs.values_cw,
                )
                for i in tl.tuple(sym.tuple_range(len(all_field_keys)))
            ]
            return replace_all_fields_with_type_triton(
                self, TensorDesc, all_fields_tuple_offseted
            )

    @triton_jit
    def offset_all_tensor(self, off_names: tl.constexpr, offsets: tl.tuple):
        """Offset tensor descriptors without change ptrs.
        usually used in dimensions that may be out of boundry, e.g. sequence dimension.

        WARNING: you can't use this in a loop because it will change static type of this aggregate object.
        TODO currently this function will override previous offset, which may confuse users.
        """
        # store offsets in _ttfs_internal_offset_names and _ttfs_internal_offsets_cw
        off_names_u: tl.constexpr = sym.unify_offset_names(off_names)
        tl.static_assert(
            len(off_names_u) == len(offsets),
            "offset names and offsets length mismatch.",
        )

        return self.offset_all_tensor_v2(
            TTOffsetDict(tuple_to_cwrapper(offsets), off_names_u)
        )

    @triton_jit
    def offset_all_tensor_v2(self, named_offs: TTOffsetDict):
        """Offset tensor descriptors without change ptrs.
        usually used in dimensions that may be out of boundry, e.g. sequence dimension.

        WARNING: you can't use this in a loop because it will change static type of this aggregate object.
        TODO currently this function will override previous offset, which may confuse users.
        """
        return aggregate_replace(
            self,
            _ttfs_internal_offs_dict=self._ttfs_internal_offs_dict.merge_add_offsets(
                named_offs.keys, named_offs.values_cw
            ),
        )

    @triton_jit
    def replace_packed_dims(
        self,
        dims_sym: tl.constexpr,
        dims_tuple,
    ):
        """When we want to handle one sequence of a packed tensor, we need to set
        the packed dimensions to the actual sequence length.
        WARNING: call this function only affect boundry check. the stride calculation based on shape
        still use original dims, so don't use this to change dims!
        """
        dims_names: tl.constexpr = sym.get_shape_names_from_sym(dims_sym)
        dims_tuple_cw = tuple_to_cwrapper(dims_tuple)
        values = [
            _tm_replace_validate(
                get_field(self, tl.constexpr(dims_names[i])), dims_tuple_cw[i]
            )
            for i in tl.tuple(sym.tuple_range(len(dims_names)))
        ]
        original_dims = [
            get_field(self, tl.constexpr(dims_names[i]))
            for i in tl.tuple(sym.tuple_range(len(dims_names)))
        ]
        # original_dims may contains dims that is already replaced, so we
        # use old correct values to replace+merge original_dims.
        return aggregate_replace(
            replace_fields_triton(self, dims_names, values),
            _ttfs_internal_original_dims=TTOffsetDict(
                original_dims, dims_names
            ).merge_replace_offsets(
                self._ttfs_internal_original_dims.keys,
                self._ttfs_internal_original_dims.values_cw,
            ),
        )

    @triton_jit
    def replace_packed_dims_v2(
        self,
        named_offsets: TTOffsetDict,
    ):
        """When we want to handle one sequence of a packed tensor, we need to set
        the packed dimensions to the actual sequence length.
        WARNING: call this function only affect boundry check. the stride calculation based on shape
        still use original dims, so don't use this to change dims!
        """
        dims_names: tl.constexpr = named_offsets.keys
        dims_tuple_cw = named_offsets.values_cw
        values = [
            _tm_replace_validate(
                get_field(self, tl.constexpr(dims_names[i])), dims_tuple_cw[i]
            )
            for i in tl.tuple(sym.tuple_range(len(dims_names)))
        ]
        original_dims = [
            get_field(self, tl.constexpr(dims_names[i]))
            for i in tl.tuple(sym.tuple_range(len(dims_names)))
        ]
        # original_dims may contains dims that is already replaced, so we
        # use old correct values to replace+merge original_dims.
        return aggregate_replace(
            replace_fields_triton(self, dims_names, values),
            _ttfs_internal_original_dims=TTOffsetDict(
                original_dims, dims_names
            ).merge_replace_offsets(
                self._ttfs_internal_original_dims.keys,
                self._ttfs_internal_original_dims.values_cw,
            ),
        )

@triton_jit
def _tm_replace_validate(prev_value_to_assign, value):
    if prev_value_to_assign.is_constexpr:
        tl.static_assert(
            value.is_constexpr, "can't assign non-constexpr value to constexpr field"
        )
    return value


