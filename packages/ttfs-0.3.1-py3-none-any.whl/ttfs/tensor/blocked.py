import dataclasses
import json
from typing import Any, Optional

import triton.language as tl
from triton.experimental.gluon import language as gl
from typing_extensions import Annotated

from ttfs.core.aggtype import (
    aggregate,
    aggregate_replace,
    constexpr_function,
    get_scalar_tensor,
    triton_jit,
    FIELD_ACCESSOR_REGISTRY,
)
from ttfs.core.mp import (
    TritonConstexprField,
    TritonField,
    dispatch_value,
    is_gluon,
    merge_two_tuple,
    tuple_to_cwrapper,
    logger_info,
    workaround_ignore_cache_record,
)
from ttfs.core import sym
from ttfs.core.layout import (
    get_default_swizzed_shared_layout_nvidia,
)
from ttfs.core.ttdict import TTOffsetDict
from triton.experimental.gluon.language.nvidia.hopper import fence_async_shared
from ttfs.gl.ops import async_tma_reduce_shared_to_global

try:
    from triton.experimental.gluon.language.nvidia.blackwell import tma
except:
    from triton.experimental.gluon.language.nvidia.hopper import tma

from .base import TensorDesc, TensorMgrDetachDimInfos

@constexpr_function
def _insert_front(val, vec):
    # print(val, vec, tl.core._unwrap_if_constexpr(vec))
    return [val] + [tl.core._unwrap_if_constexpr(v) for v in vec]

@workaround_ignore_cache_record
def _get_json_encoded_metadata_impl(desc):
    # print(val, vec, tl.core._unwrap_if_constexpr(vec))
    name = tl.core._unwrap_if_constexpr(desc.name)
    block_shape_sym = tl.core._unwrap_if_constexpr(desc.block_shape_sym)
    block_shape = tl.core._unwrap_if_constexpr(desc.block_shape)
    block_shape = [tl.core._unwrap_if_constexpr(v) for v in block_shape]
    shape_sym = tl.core._unwrap_if_constexpr(desc.shape_sym)
    return json.dumps({
        "name": name,
        "block_shape_sym": block_shape_sym,
        "block_shape": block_shape,
        "shape_sym": shape_sym,
    })

@constexpr_function
def _get_json_encoded_metadata(desc):
    return _get_json_encoded_metadata_impl(desc)

@constexpr_function
def _get_full_block_shape(block_axes, block_shape):
    block_axes = [tl.core._unwrap_if_constexpr(v) for v in block_axes]
    block_shape = [tl.core._unwrap_if_constexpr(v) for v in block_shape]
    res_shape = [1] * len(block_axes)
    cnt = 0
    for i, axis in enumerate(block_axes):
        if axis >= 0:
            res_shape[i] = block_shape[axis]
            cnt += 1
    return res_shape


@aggregate(kw_only=True)
class BlockedTensorDesc(TensorDesc):
    name: tl.constexpr
    # mgr: TensorManagerBase
    detached_dims: TensorMgrDetachDimInfos
    block_shape_sym: tl.constexpr  # e.g. "S,H", can be alias name
    block_shape: tl.constexpr  # e.g. (32, 32)
    # for pointers
    io_layout: tl.constexpr = None

    def __repr__(self):
        name = self.name
        if isinstance(name, tl.constexpr):
            name = name.value 
        block_shape_sym = self.block_shape_sym
        if isinstance(block_shape_sym, tl.constexpr):
            block_shape_sym = block_shape_sym.value
        shape_sym = self.shape_sym
        if isinstance(shape_sym, tl.constexpr):
            shape_sym = shape_sym.value
        block_shape_sym_parts, _ = sym.parse_shape_sym(block_shape_sym)
        block_shape = tl.core._unwrap_if_constexpr(self.block_shape)
        block_shape = [tl.core._unwrap_if_constexpr(v) for v in block_shape]
        block_shape_str = ", ".join(f"{k}={v}" for k, v in zip(block_shape_sym_parts, block_shape))
        
        return f"{self.__class__.__name__}({name}, {block_shape_str}, shape_sym=\"{shape_sym}\")"

    @triton_jit
    def get_io_layout_cw(
        self,
        is_atomic_reduce: tl.constexpr = False,
    ):
        if self.io_layout is not None:
            return TritonConstexprField(self.io_layout)
        else:
            return self.get_default_blocked_io_layout_from_block(
                self.block_shape_sym, self.block_shape, is_atomic_reduce=is_atomic_reduce,
            )
    
    @triton_jit
    def get_json_data_cw(
        self,
    ):
        return TritonConstexprField(_get_json_encoded_metadata(self))

    @triton_jit
    def offset_desc_ptr(
        self,
        off_names: tl.constexpr,
        offsets: tl.tuple,
    ):
        self.assert_is_pointer()
        self.assert_is_valid()

        return aggregate_replace(
            self,
            # pointer check (not tma) is done in get_offseted_ptr
            # ptr=self.mgr.get_offseted_ptr(
            #     self.name,
            #     off_names,
            #     offsets,
            # ),
            ptr=self.detached_dims.get_offseted_ptr(
                self, off_names, offsets
            )
        )

    @triton_jit
    def get_block_dim_name_by_idx_cw(self, idx: tl.constexpr):
        block_names: tl.constexpr = sym.get_shape_names_from_sym(self.block_shape_sym)
        val: tl.constexpr = sym.local_name_to_global(self.shape_sym, block_names[idx])
        return TritonConstexprField(val)

    @triton_jit
    def get_dim_size(self, axis: tl.constexpr):
        # return self.mgr.get_tensor_dim_size(self.name, axis)
        return self.detached_dims.get_tensor_dim_size(self, axis)

    @triton_jit
    def get_dim_size_by_block_dim(self, block_dim: tl.constexpr):
        block_name: tl.constexpr = sym.get_block_dim_name_by_idx(
            self.block_shape_sym, block_dim
        ).value
        return self.get_dim_size_by_name(block_name)

    @triton_jit
    def get_dim_size_by_name(self, dim_name: tl.constexpr):
        # return self.mgr.get_tensor_dim_size_by_name(self.name, dim_name)
        return self.detached_dims.get_tensor_dim_size_by_name(self, dim_name)

    @triton_jit
    def get_block_size_by_name(self, block_dim_name: tl.constexpr):
        dim: tl.constexpr = sym.get_dim_by_name(self.block_shape_sym, block_dim_name)
        return TritonConstexprField(self.block_shape[dim])

    @triton_jit
    def get_stride(self, axis: tl.constexpr):
        # return self.mgr.get_tensor_stride(self.name, axis)
        return self.detached_dims.get_tensor_stride(self, axis)

    @triton_jit
    def get_stride_by_name(self, dim_name: tl.constexpr):
        # return self.mgr.get_tensor_stride_by_name(self.name, dim_name)
        return self.detached_dims.get_tensor_stride_by_name(self, dim_name)

    @triton_jit
    def get_block_nbytes_cw(self, block_shape_override: tl.constexpr = None):
        if isinstance(
            self.ptr, gl.nvidia.hopper.tma.tensor_descriptor
        ) or isinstance(
            self.ptr, tl.tensor_descriptor
        ):
            nbytes: tl.constexpr = self.ptr.block_type.nbytes
        else:
            dtype = self.ptr.dtype.element_ty
            if block_shape_override is None:
                block_shape: tl.constexpr = self.block_shape
            else:
                tl.static_assert(len(block_shape_override) == len(self.block_shape), "block_shape_override should have the same length as block_shape.")
                block_shape: tl.constexpr = block_shape_override

            nbytes: tl.constexpr = dtype.itemsize * sym.prod_int_list(block_shape)

        return TritonConstexprField(nbytes)

    @triton_jit
    def _get_block_dim_is_divisible(self, axis: tl.constexpr):
        block_size: tl.constexpr = self.block_shape[axis]
        dim = self.get_dim_size_by_block_dim(axis)
        if dim.is_constexpr:
            return TritonConstexprField(dim.value % block_size == 0)
        else:
            # dim_multiple_of: tl.constexpr = self.mgr.get_dim_multiple_of(
            #     sym.get_block_dim_name_by_idx(self.block_shape_sym, axis)
            # ).value
            dim_multiple_of_defined: tl.constexpr = self.detached_dims.has_dim_multiple_of_defined(
                sym.get_block_dim_name_by_idx(self.block_shape_sym, axis)
            ).value
            dim_multiple_of: tl.constexpr = self.detached_dims.get_dim_multiple_of(
                sym.get_block_dim_name_by_idx(self.block_shape_sym, axis)
            ).value
            # WARNING: for non-constexpr dim, if dim_multiple_of isn't defined by user, 
            # we still treat it as indivisible even if block size is 1.
            return TritonConstexprField(dim_multiple_of % block_size == 0 if dim_multiple_of_defined else False)

    @triton_jit
    def _get_block_axes_is_divisible(self, except_axis: tl.constexpr = -1, force_mask_sym: tl.constexpr = None):
        included_dim_sym_names: tl.constexpr = sym.get_shape_names_from_sym(force_mask_sym) if force_mask_sym is not None else sym.make_list()
        included_dim_sym_names_global: tl.constexpr = sym.local_names_to_global(self.shape_sym, included_dim_sym_names)
        block_dim_is_divisible: tl.constexpr = [
            False
            if sym.is_name_in_names(self.get_block_dim_name_by_idx_cw(i).value, included_dim_sym_names_global) 
            else self._get_block_dim_is_divisible(i).value
            for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
        ]
        return TritonConstexprField(
            sym.get_false_inds_of_bool_tuple(block_dim_is_divisible, except_axis)
        )

    @triton_jit
    def is_need_block_mask(self, except_axis: tl.constexpr = -1, force_mask_sym: tl.constexpr = None):
        block_dims_is_divisible = self._get_block_axes_is_divisible(except_axis, force_mask_sym)
        return TritonConstexprField(len(block_dims_is_divisible.value) > 0)

    @triton_jit
    def get_blocked_masks(self, except_axis: tl.constexpr = -1, layout_override: tl.constexpr = None, force_mask_sym: tl.constexpr = None):
        """Get block mask.

        Block mask definition: we will generate block mask for block dim that is not divisible (is_divisible=False).

        Block dim divisibility definition:
            if the dim is constexpr, is_divisible = (dim % block_size == 0)
            else if the dim isn't constexpr but user define multiple-of, is_divisible = (multiple_of % block_size == 0)
            else is_divisible = False (**EVEN IF block size is 1**)

        WARNING: mask won't be generated for divisible dims even if your offset may be out-of-range. you can use
        `force_mask_sym` to force generate mask for specific dims.
        """
        block_dims_is_divisible = self._get_block_axes_is_divisible(except_axis, force_mask_sym)
        gl.static_assert(
            len(block_dims_is_divisible.value) > 0,
            "due to triton's limits, we can't return any Optional content, "
            "use `is_need_block_mask` to check before get mask.",
        )
        masks = [
            (
                self.get_blocked_offset_by_idx(
                    block_dims_is_divisible.value[i], expand_dims=True, layout_override=layout_override
                )
                < self.get_dim_size_by_block_dim(block_dims_is_divisible.value[i]).value
            )
            for i in tl.tuple(sym.tuple_range(len(block_dims_is_divisible.value)))
        ]

        mask = masks[0]
        for i in tl.static_range(1, len(masks)):
            mask = mask & masks[i]
        return mask

    @triton_jit
    def get_default_blocked_io_layout(self, is_atomic_reduce: tl.constexpr = False):
        return self.get_default_blocked_io_layout_from_block(
            self.block_shape_sym, self.block_shape, is_atomic_reduce
        )

    @triton_jit
    def get_cur_offset_cw_by_block_idx(self, block_idx):
        return TritonConstexprField(0)

    @triton_jit
    def get_sliced_layout_for_offset(
        self,
        idx: tl.constexpr,
        layout_override: tl.constexpr = None,
        is_atomic_reduce: tl.constexpr = False,
    ):
        if layout_override is not None:
            layout: tl.constexpr = layout_override
        else:
            layout: tl.constexpr = self.get_io_layout_cw(is_atomic_reduce).value
        return TritonConstexprField(sym.get_sliced_layout_cw(layout, len(self.block_shape), idx))

    @triton_jit
    def get_sliced_layout_by_name_for_offset(
        self,
        dim_name: tl.constexpr,
        layout_override: tl.constexpr = None,
        is_atomic_reduce: tl.constexpr = False,
    ):
        dim_name_global: tl.constexpr = sym.local_name_to_global(
            self.shape_sym, dim_name
        )
        idx: tl.constexpr = sym.get_dim_by_name(self.block_shape_sym, dim_name_global)
        return self.get_sliced_layout_for_offset(idx, layout_override, is_atomic_reduce)

    @triton_jit
    def get_blocked_offset_by_idx(
        self,
        idx: tl.constexpr,
        expand_dims: tl.constexpr = False,
        out_of_range: tl.constexpr = 0,
        use_i64: tl.constexpr = False,
        ext_offset_cw = None,
        layout_override: tl.constexpr = None,
        is_atomic_reduce: tl.constexpr = False,
    ):
        block_size: tl.constexpr = self.block_shape[idx]
        if is_gluon():
            if layout_override is not None:
                layout: tl.constexpr = layout_override
            else:
                layout: tl.constexpr = self.get_io_layout_cw(is_atomic_reduce).value
            res_layout: tl.constexpr = sym.get_sliced_layout_cw(layout, len(self.block_shape), idx)
            res = gl.arange(0, block_size, layout=res_layout)
        else:
            res = tl.arange(0, block_size)
        if use_i64:
            res = res.to(tl.int64)
        dim_name: tl.constexpr = sym.get_block_dim_name_by_idx(
            self.block_shape_sym, idx
        )
        # dim_name_global: tl.constexpr = sym.local_name_to_global(
        #     self.shape_sym, dim_name
        # )
        if ext_offset_cw is not None:
            res = res + (self.get_cur_offset_cw_by_block_idx(idx).value + ext_offset_cw.value)
        else:
            res = res + self.get_cur_offset_cw_by_block_idx(idx).value

        if out_of_range == 0:
            res_oor = res
        elif out_of_range == 1:
            boundry = self.get_dim_size_by_block_dim(idx)
            res_oor = gl.where(res < boundry.value, res, 0)
        else:
            boundry = self.get_dim_size_by_block_dim(idx)
            # TODO should we use multiple_of in ttfs_dim_multiple_of here if boundry isn't constexpr?
            res_oor = res % boundry.value

        if not expand_dims:
            return res_oor
        else:
            return self.unslice_1d_offset(res_oor, dim_name)

    @triton_jit
    def get_blocked_offset_base_by_idx(
        self,
        idx: tl.constexpr,
        expand_dims: tl.constexpr = False,
    ):
        block_size: tl.constexpr = self.block_shape[idx]
        if is_gluon():
            res_layout: tl.constexpr = sym.get_sliced_layout_cw(
                self.get_io_layout_cw().value, len(self.block_shape), idx
            )
            res = gl.arange(0, block_size, layout=res_layout)
        else:
            res = tl.arange(0, block_size)
        dim_name: tl.constexpr = sym.get_block_dim_name_by_idx(
            self.block_shape_sym, idx
        )
        if not expand_dims:
            return res
        else:
            return self.unslice_1d_offset(res, dim_name)

    @triton_jit
    def _get_dim_by_block_dim_name(self, dim_name: tl.constexpr):
        dim_name_unified: tl.constexpr = sym.local_name_to_global(
            self.shape_sym, dim_name
        )
        block_sym_unified: tl.constexpr = sym.local_sym_to_global(
            self.shape_sym, self.block_shape_sym
        )
        block_idx: tl.constexpr = sym.get_dim_by_name(
            block_sym_unified, dim_name_unified
        )
        return TritonConstexprField(block_idx)

    @triton_jit
    def unslice_1d_offset(self, offset_1d, dim_name: tl.constexpr):
        block_idx: tl.constexpr = self._get_dim_by_block_dim_name(dim_name).value
        return self.unslice_1d_offset_by_idx(offset_1d, block_idx)

    @triton_jit
    def unslice_1d_offset_by_idx(self, offset_1d, block_idx: tl.constexpr):
        axes: tl.constexpr = sym.get_sliced_axes(
            len(self.block_shape), block_idx, descending=False
        )
        for i in tl.static_range(len(axes)):
            offset_1d = offset_1d.expand_dims(axes[i])
        return offset_1d

    @triton_jit
    def get_blocked_offset(
        self,
        dim_name: tl.constexpr,
        expand_dims: tl.constexpr = False,
        out_of_range: tl.constexpr = 0,
    ):
        dim: tl.constexpr = self._get_dim_by_block_dim_name(dim_name).value
        return self.get_blocked_offset_by_idx(dim, expand_dims, out_of_range)

    @triton_jit
    def get_blocked_offset_base(
        self,
        dim_name: tl.constexpr,
        expand_dims: tl.constexpr = False,
    ):
        """Get base blocked offset without adding current offset, which can be used to create mask."""
        dim: tl.constexpr = self._get_dim_by_block_dim_name(dim_name).value
        return self.get_blocked_offset_base_by_idx(dim, expand_dims)

    @triton_jit
    def get_full_block_shape_cw(
        self,
        block_shape_override: tl.constexpr = None
    ):
        """get full block shape with all non-block dim 1.
        this is used for TMA, TMA block shape rank must match origin tensor.
        """
        if block_shape_override is not None:
            block_shape: tl.constexpr = block_shape_override
        else:
            block_shape: tl.constexpr = self.block_shape
        block_sym_global: tl.constexpr = sym.local_sym_to_global(
            self.shape_sym, self.block_shape_sym
        )
        block_names: tl.constexpr = sym.get_shape_names_from_sym(block_sym_global)
        block_axes: tl.constexpr = sym.get_sym_axes_in_name_tuple(
            block_names, self.shape_sym
        )
        return TritonConstexprField(_get_full_block_shape(block_axes, block_shape))


    @triton_jit
    def get_blocked_offsets_tuple(
        self,
        out_of_range: tl.constexpr = 0,
        use_i64: tl.constexpr = False,
        gather_inds=None,
        gather_axis: tl.constexpr = 0,
        add_offset_to_inds: tl.constexpr = True,
        layout_override: tl.constexpr = None,
    ):
        if gather_inds is not None:
            if add_offset_to_inds:
                offsets = [
                    (
                        self.get_cur_offset_cw_by_block_idx(i).value
                        + self.unslice_1d_offset_by_idx(gather_inds, i)
                    )
                    if i == gather_axis
                    else self.get_blocked_offset_by_idx(
                        i,
                        expand_dims=True,
                        out_of_range=out_of_range,
                        use_i64=use_i64,
                    )
                    for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
                ]
            else:
                offsets = [
                    (self.unslice_1d_offset_by_idx(gather_inds, i))
                    if i == gather_axis
                    else self.get_blocked_offset_by_idx(
                        i,
                        expand_dims=True,
                        out_of_range=out_of_range,
                        use_i64=use_i64,
                        layout_override=layout_override,
                    )
                    for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
                ]

        else:
            offsets = [
                self.get_blocked_offset_by_idx(
                    i,
                    expand_dims=True,
                    out_of_range=out_of_range,
                    use_i64=use_i64,
                    layout_override=layout_override,
                )
                for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
            ]
        return offsets

    @triton_jit
    def get_blocked_ptrs_from_offsets(
        self,
        offsets,
    ):
        # strides = [
        #     self.mgr.get_tensor_stride_with_multiple_of_by_name(
        #         self.name, sym.get_block_dim_name_by_idx(self.block_shape_sym, i)
        #     )
        #     for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
        # ]
        strides = [
            self.detached_dims.get_tensor_stride_with_multiple_of_by_name(
                self, sym.get_block_dim_name_by_idx(self.block_shape_sym, i)
            )
            for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
        ]

        # triton/gluon analysizer perfer ptr + offset pattern instead of ptr + some_func_or_op(), so we have to inline them here.
        # if use ptr + self.get_blocked_offsets() or use gl.static_range to sum offsets first, triton kernel will use more registers.

        # multiple_of: if last dim isn't constexpr, it must be multiple_of aligned to allow vector access.
        # user can specify it by `stride_multiple_of` in TensorDesc or `ttfs_dim_multiple_of` in TensorManager (for auto inferenced stride).
        if len(strides) == 1:
            return self.ptr + offsets[0] * (
                tl.multiple_of(strides[0].stride.value, strides[0].multiple_of)
                if strides[0].need_multiple_of
                else strides[0].stride.value
            )
        elif len(strides) == 2:
            return (
                self.ptr
                + offsets[0]
                * (
                    tl.multiple_of(strides[0].stride.value, strides[0].multiple_of)
                    if strides[0].need_multiple_of
                    else strides[0].stride.value
                )
                + offsets[1]
                * (
                    tl.multiple_of(strides[1].stride.value, strides[1].multiple_of)
                    if strides[1].need_multiple_of
                    else strides[1].stride.value
                )
            )
        elif len(strides) == 3:
            return (
                self.ptr
                + offsets[0]
                * (
                    tl.multiple_of(strides[0].stride.value, strides[0].multiple_of)
                    if strides[0].need_multiple_of
                    else strides[0].stride.value
                )
                + offsets[1]
                * (
                    tl.multiple_of(strides[1].stride.value, strides[1].multiple_of)
                    if strides[1].need_multiple_of
                    else strides[1].stride.value
                )
                + offsets[2]
                * (
                    tl.multiple_of(strides[2].stride.value, strides[2].multiple_of)
                    if strides[2].need_multiple_of
                    else strides[2].stride.value
                )
            )
        elif len(strides) == 4:
            return (
                self.ptr
                + offsets[0]
                * (
                    tl.multiple_of(strides[0].stride.value, strides[0].multiple_of)
                    if strides[0].need_multiple_of
                    else strides[0].stride.value
                )
                + offsets[1]
                * (
                    tl.multiple_of(strides[1].stride.value, strides[1].multiple_of)
                    if strides[1].need_multiple_of
                    else strides[1].stride.value
                )
                + offsets[2]
                * (
                    tl.multiple_of(strides[2].stride.value, strides[2].multiple_of)
                    if strides[2].need_multiple_of
                    else strides[2].stride.value
                )
                + offsets[3]
                * (
                    tl.multiple_of(strides[3].stride.value, strides[3].multiple_of)
                    if strides[3].need_multiple_of
                    else strides[3].stride.value
                )
            )
        else:
            # general case, but use more registers.
            res = offsets[0] * (
                tl.multiple_of(strides[0].stride.value, strides[0].multiple_of)
                if strides[0].need_multiple_of
                else strides[0].stride.value
            )
            for i in gl.static_range(1, len(strides)):
                res += offsets[i] * (
                    tl.multiple_of(strides[i].stride.value, strides[i].multiple_of)
                    if strides[i].need_multiple_of
                    else strides[i].stride.value
                )
            return self.ptr + res

    @triton_jit
    def get_blocked_ptrs(
        self,
        out_of_range: tl.constexpr = 0,
        use_i64: tl.constexpr = False,
        gather_inds=None,
        gather_axis: tl.constexpr = 0,
        add_offset_to_inds: tl.constexpr = True,
        layout_override: tl.constexpr = None,
    ):
        offsets = self.get_blocked_offsets_tuple(
            out_of_range=out_of_range,
            use_i64=use_i64,
            gather_inds=gather_inds,
            gather_axis=gather_axis,
            add_offset_to_inds=add_offset_to_inds,
            layout_override=layout_override,
        )
        return self.get_blocked_ptrs_from_offsets(
            offsets,
        )

    @triton_jit
    def get_blocked_offsets(self, out_of_range: tl.constexpr = 0):
        # strides = [
        #     self.mgr.get_tensor_stride_with_multiple_of_by_name(
        #         self.name, sym.get_block_dim_name_by_idx(self.block_shape_sym, i)
        #     )
        #     for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
        # ]
        strides = [
            self.detached_dims.get_tensor_stride_with_multiple_of_by_name(
                self, sym.get_block_dim_name_by_idx(self.block_shape_sym, i)
            )
            for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
        ]

        offsets = [
            self.get_blocked_offset_by_idx(
                i, expand_dims=True, out_of_range=out_of_range
            )
            for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
        ]
        res = offsets[0]
        for i in gl.static_range(1, len(strides)):
            res += offsets[i] * (
                tl.multiple_of(strides[i].stride.value, strides[i].multiple_of)
                if strides[i].need_multiple_of
                else strides[i].stride.value
            )
        return res

    @triton_jit
    def get_block_stride_cw_by_dim_name(self, block_dim_name: tl.constexpr):
        block_dim_name_unified: tl.constexpr = sym.local_name_to_global(
            self.shape_sym, block_dim_name
        )
        # return self.mgr.get_tensor_stride_by_name(
        #     self.name, block_dim_name_unified
        # )
        return self.detached_dims.get_tensor_stride_by_name(
            self, block_dim_name_unified
        )

    @triton_jit
    def get_block_size_cw_by_dim_name(self, block_dim_name: tl.constexpr):
        block_dim_name_unified: tl.constexpr = sym.local_name_to_global(
            self.shape_sym, block_dim_name
        )
        return TritonConstexprField(
            self.block_shape[sym.get_dim_by_name(self.block_shape_sym, block_dim_name_unified)]
        )

    @triton_jit
    def get_default_smem_layout(self, block_shape_override: tl.constexpr = None):
        tl.static_assert(is_gluon(), "layout is only supported in gluon backend.")
        if block_shape_override is None:
            block_shape: tl.constexpr = self.block_shape
        else:
            tl.static_assert(len(block_shape_override) == len(self.block_shape), "block_shape_override should have the same length as block_shape.")
            tl.static_assert(not self.is_tma_desc().value, "only support override pointer block shape. TMA isn't supported")
            block_shape: tl.constexpr = block_shape_override
        if len(block_shape) > 2:
            gl.static_assert(sym.check_block_tensor_is_contiguous(
                self.shape_sym, self.block_shape_sym
            ), "3+D block must be contiguous")
        if self.is_swizzled_layout:
            return TritonConstexprField(
                gl.NVMMASharedLayout.get_default_for(
                    block_shape,
                    self.get_dtype().value,
                    transposed=False if len(block_shape) > 2 else sym.check_matrix_is_transposed(self.shape_sym, self.block_shape_sym),
                )
            )
        else:
            return TritonConstexprField(
                gl.NVMMASharedLayout(
                    0,
                    self.get_dtype().value.primitive_bitwidth,
                    len(block_shape),
                    transposed=False if len(block_shape) > 2 else sym.check_matrix_is_transposed(self.shape_sym, self.block_shape_sym),
                )
            )


    @triton_jit
    def get_default_swizzled_smem_layout(self, op_idx: tl.constexpr):
        tl.static_assert(is_gluon(), "layout is only supported in gluon backend.")
        gl.static_assert(
            len(self.block_shape) == 2, "Only support 2D blocked tensor for now."
        )
        kwidth: tl.constexpr = 32 // self.get_dtype().value.primitive_bitwidth
        is_transposed = sym.check_matrix_is_transposed(
            self.shape_sym, self.block_shape_sym
        )
        return TritonConstexprField(
            get_default_swizzed_shared_layout_nvidia(
                op_idx,
                kwidth,
                self.block_shape,
                [0, 1] if is_transposed else [1, 0],
                self.get_dtype().value,
            )
        )

    @triton_jit
    def allocate_shared_memory(self, num_stages: tl.constexpr, layout: tl.constexpr = None, block_shape_override: tl.constexpr = None):
        tl.static_assert(
            is_gluon(), "allocate_shared_memory is only supported in gluon backend."
        )
        if block_shape_override is None:
            block_shape: tl.constexpr = self.block_shape
        else:
            tl.static_assert(not self.is_tma_desc().value, "only support override pointer block shape. TMA isn't supported")
            block_shape: tl.constexpr = block_shape_override
        if self.is_tma_desc().value:
            # use full shape for TMA.
            full_block_shape: tl.constexpr = self.get_full_block_shape_cw(block_shape).value
        else:
            full_block_shape: tl.constexpr = block_shape

        final_shape: tl.constexpr = _insert_front(num_stages, full_block_shape)
        if layout is None:
            if self.is_tma_desc().value:
                smem_layout: tl.constexpr = self.ptr.layout
            else:
                smem_layout: tl.constexpr = self.get_default_smem_layout(block_shape_override).value
            logger_info("\"%s\"(%s) alloc %d%s bytes smem(swizzle_bw=%s).", self.name, self.get_dtype().value, 
                num_stages * self.get_block_nbytes_cw(block_shape_override).value, final_shape, smem_layout.swizzle_byte_width)

        else:
            smem_layout: tl.constexpr = layout
            logger_info("\"%s\"(%s) alloc %d%s bytes smem.", self.name, self.get_dtype().value, 
                num_stages * self.get_block_nbytes_cw(block_shape_override).value, final_shape)

        dtype: gl.constexpr = self.get_dtype().value
        return gl.allocate_shared_memory(
            dtype,
            final_shape,
            layout=smem_layout,
        )

    @triton_jit
    def allocate_single_shared_memory(self, layout: tl.constexpr = None, block_shape_override: tl.constexpr = None):
        tl.static_assert(
            is_gluon(), "allocate_shared_memory is only supported in gluon backend."
        )
        if block_shape_override is None:
            block_shape: tl.constexpr = self.block_shape
        else:
            tl.static_assert(not self.is_tma_desc().value, "only support override pointer block shape. TMA isn't supported")
            block_shape: tl.constexpr = block_shape_override
        if self.is_tma_desc().value:
            # use full shape for TMA.
            full_block_shape: tl.constexpr = self.get_full_block_shape_cw(block_shape).value
        else:
            full_block_shape: tl.constexpr = block_shape

        logger_info("\"%s\"(%s) alloc %d%s bytes smem.", self.name, self.get_dtype().value, 
            self.get_block_nbytes_cw(block_shape_override).value, full_block_shape)
        if layout is None:
            if self.is_tma_desc().value:
                smem_layout: tl.constexpr = self.ptr.layout
            else:
                smem_layout: tl.constexpr = self.get_default_smem_layout(full_block_shape).value
        else:
            smem_layout: tl.constexpr = layout
        dtype: gl.constexpr = self.get_dtype().value
        return gl.allocate_shared_memory(
            dtype, full_block_shape, layout=smem_layout
        )

    @triton_jit
    def masked_load(self, apply_mask: tl.constexpr = True, other=None, force_mask_sym: tl.constexpr = None):
        """Load current block immediately. block mask is applied by default.
        see block mask definition in `get_blocked_masks`.

        WARNING: we only apply block mask here, which means if the dim is divisible by block size, this dim doesn't have mask
        even if you provide invalid offset. this is OK in most cases but usually failed if you do something like subtile.
        to force apply mask on divisible dims, use force_mask_sym. 
        """
        self.assert_is_pointer()
        if apply_mask and self.is_need_block_mask(force_mask_sym=force_mask_sym).value:
            mask = self.get_blocked_masks(force_mask_sym=force_mask_sym)
        else:
            mask = None
        pointers = self.get_blocked_ptrs()
        if mask is None:
            other_ = None 
        else:
            other_ = other
        if is_gluon():
            return gl.load(pointers, mask, other_)
        else:
            return tl.load(pointers, mask, other_)

    @triton_jit
    def masked_gather(
        self,
        inds,
        axis: tl.constexpr,
        apply_mask: tl.constexpr = True,
        other=None,
        add_offset_to_inds: tl.constexpr = True,
        inds_mask=None,
        force_mask_sym: tl.constexpr = None,
    ):
        """Gather current block immediately. block mask is applied by default EXCEPT gather dim. 
        use inds_mask to provide mask for gather dim.
        see block mask definition in `get_blocked_masks`.

        WARNING: we only apply block mask here, which means if the dim is divisible by block size, this dim don't have mask
        even if you provide invalid offset. this is OK in most cases but usually failed if you do something like subtile.
        to force apply mask on divisible dims, use force_mask_sym. 
        """
        self.assert_is_pointer()
        if apply_mask and self.is_need_block_mask(axis, force_mask_sym=force_mask_sym).value:
            mask = self.get_blocked_masks(axis, force_mask_sym=force_mask_sym)
            if inds_mask is not None:
                mask = mask & inds_mask
        else:
            if inds_mask is not None:
                mask = inds_mask
            else:
                mask = None
        pointers = self.get_blocked_ptrs(
            gather_inds=inds, gather_axis=axis, add_offset_to_inds=add_offset_to_inds
        )
        if is_gluon():
            return gl.load(pointers, mask, other)
        else:
            return tl.load(pointers, mask, other)

    @triton_jit
    def masked_store(
        self, value, apply_mask: tl.constexpr = True, use_i64: tl.constexpr = False,
        cast_to_default_layout: tl.constexpr = False,
        force_mask_sym: tl.constexpr = None,
    ):
        """Store current block immediately. mask is applied by default.
        see block mask definition in `get_blocked_masks`.

        WARNING: we only apply block mask here, which means if the dim is divisible by block size, this dim don't have mask
        even if you provide invalid offset. this is OK in most cases but usually failed if you do something like subtile.
        to force apply mask on divisible dims, use force_mask_sym. 
        """
        self.assert_is_pointer()
        if cast_to_default_layout and is_gluon():
            value = gl.convert_layout(value, self.get_io_layout_cw().value)
        if is_gluon():
            value_layout: tl.constexpr = value.type.layout
        else:
            value_layout: tl.constexpr = None
        if apply_mask and self.is_need_block_mask(force_mask_sym=force_mask_sym).value:
            mask = self.get_blocked_masks(layout_override=value_layout, force_mask_sym=force_mask_sym)
        else:
            mask = None
        pointers = self.get_blocked_ptrs(use_i64=use_i64, layout_override=value_layout)
        if is_gluon():
            gl.store(pointers, value, mask)
        else:
            tl.store(pointers, value, mask)

    @triton_jit
    def masked_atomic_add(
        self, value, apply_mask: tl.constexpr = True, use_i64: tl.constexpr = False,
        cast_to_default_layout: tl.constexpr = False,
        force_mask_sym: tl.constexpr = None,
    ):
        """Atomic add current block immediately. mask is applied by default.
        see block mask definition in `get_blocked_masks`.

        WARNING: we only apply block mask here, which means if the dim is divisible by block size, this dim don't have mask
        even if you provide invalid offset. this is OK in most cases but usually failed if you do something like subtile.
        to force apply mask on divisible dims, use force_mask_sym. 
        """
        self.assert_is_pointer()
        if cast_to_default_layout and is_gluon():
            value = gl.convert_layout(value, self.get_io_layout_cw(is_atomic_reduce=True).value)
        if is_gluon():
            value_layout: tl.constexpr = value.type.layout
        else:
            value_layout: tl.constexpr = None

        if apply_mask and self.is_need_block_mask(force_mask_sym=force_mask_sym).value:
            mask = self.get_blocked_masks(layout_override=value_layout, force_mask_sym=force_mask_sym)
        else:
            mask = None
        pointers = self.get_blocked_ptrs(use_i64=use_i64, layout_override=value_layout)
        if is_gluon():
            gl.atomic_add(pointers, value, mask)
        else:
            tl.atomic_add(pointers, value, mask)

    @triton_jit
    def alloc_single_smem_with_load(self, smem_layout: tl.constexpr, apply_mask: tl.constexpr = True, other=None, shape_override: tl.constexpr = None):
        # TODO support TMA.
        tl.static_assert(is_gluon(), "alloc_smem_with_load is only supported in gluon backend.")
        smem = self.allocate_single_shared_memory(smem_layout, shape_override)
        val = self.masked_load(apply_mask=apply_mask, other=other)
        if shape_override is not None:
            val = val.reshape(shape_override)
        smem.store(val)

    @triton_jit
    def alloc_multiple_smem_with_load(self, smem_layout: tl.constexpr, apply_mask: tl.constexpr = True, other=None):
        # block size of first dim must be 1, we will use real dim (must be constexpr) as final alloc shape.
        tl.static_assert(is_gluon(), "alloc_smem_with_load is only supported in gluon backend.")
        dim_size_cw = self.get_dim_size_by_block_dim(0)
        dim_name: tl.constexpr = self.get_block_dim_name_by_idx_cw(0).value
        tl.static_assert(dim_size_cw.is_constexpr, "first dim must be constexpr.")
        tl.static_assert(self.block_shape[0] == 1, "first block dim must be 1.")
        alloc_shape: tl.constexpr = sym.replace_item_in_list(dim_size_cw.value, self.block_shape, 0)
        smem = self.allocate_single_shared_memory(smem_layout, alloc_shape)
        for j in tl.static_range(dim_size_cw.value):
            value = self.offset_by_dict(TTOffsetDict(
                [TritonConstexprField(j)],
                sym.make_list(dim_name)
            )).masked_load(apply_mask=apply_mask, other=other).reshape(self.block_shape[1:])
            smem.index(j).store(value)
        return smem

@aggregate(kw_only=True)
class BlockedTensorDescWithOffset(BlockedTensorDesc):
    named_offsets: TTOffsetDict

    def __repr__(self):
        return super().__repr__()

    @triton_jit
    def get_offseted_ptr(
        self,
        cast_offset_to_64bit: tl.constexpr = False,
    ):
        self.assert_is_pointer()
        self.assert_is_valid()
        values_cw = self.named_offsets.values_cw

        # return self.mgr.get_offseted_ptr(
        #     self.name,
        #     self.named_offsets.keys,
        #     values_cw,
        #     cast_offset_to_64bit=cast_offset_to_64bit,
        # )

        return self.detached_dims.get_offseted_ptr(
            self,
            self.named_offsets.keys,
            values_cw,
            cast_offset_to_64bit=cast_offset_to_64bit,
        )

    @triton_jit
    def get_offseted_ptr_desc(
        self,
        cast_offset_to_64bit: tl.constexpr = False,
    ):
        """replace pointer with offseted pointer and clear offsets (set to 0) in desc.
        return new desc.
        WARNING: don't use this inside any loop.
        """
        self.assert_is_pointer()
        self.assert_is_valid()
        values_cw = self.named_offsets.values_cw
        return aggregate_replace(
            self,
            ptr=self.detached_dims.get_offseted_ptr(
                self,
                self.named_offsets.keys,
                values_cw,
                cast_offset_to_64bit=cast_offset_to_64bit,
            ),
            named_offsets=self.named_offsets.get_cleared_named_offsets(),
        )

    @triton_jit
    def get_cur_offset_cw_by_block_idx(self, block_idx: tl.constexpr):
        return self.named_offsets.values_cw[block_idx]

    @tl.core.builtin
    def offset(self, _semantic=None, **kwargs):
        """Add offsets to current desc. note that this function won't add to pointer immediately.
        instead we store offsets to `desc.named_offsets`.
        For better pointer desc performance, you may need to call `get_offseted_ptr_desc`
        to replace pointer and clear offsets after offsetting.
        """
        shape, alias = sym.parse_shape_sym(tl.core._unwrap_if_constexpr(self.shape_sym))
        cur_names = self.named_offsets.keys
        cur_names = tl.core._unwrap_if_constexpr(cur_names)
        global_to_alias = {s: a for a, s in zip(alias, shape)}
        cur_names_alias = [global_to_alias[n] for n in cur_names]
        for k in kwargs:
            assert k in cur_names or k in cur_names_alias, (
                f"offset name {k} not found in current named offsets {cur_names}/{cur_names_alias}"
            )
        values = [self.named_offsets.values_cw[i] for i in range(len(cur_names))]
        for k, v in kwargs.items():
            if k in cur_names:
                origin_idx = cur_names.index(k)
            else:
                origin_idx = cur_names_alias.index(k)
            v2 = values[origin_idx]
            v2_is_c = tl.core._unwrap_if_constexpr(v2.is_constexpr)
            if isinstance(v, (tl.constexpr, str, int, float, bool)) and v2_is_c:
                if isinstance(v, tl.constexpr):
                    v = v.value
                v2_value = v2.value
                if isinstance(v2_value, tl.constexpr):
                    v2_value = v2_value.value
                values[origin_idx] = TritonConstexprField(v + v2.value)
            else:
                if isinstance(v, tl.constexpr):
                    v = v.value
                v2_value = v2.value
                if isinstance(v2_value, tl.constexpr):
                    v2_value = v2_value.value
                values[origin_idx] = TritonField(_semantic.add(v, v2_value, True))
        named_offs = TTOffsetDict(
            tl.tuple(values),
            self.named_offsets.keys,
        )
        return dataclasses.replace(
            self,
            named_offsets=named_offs,
        )

    @triton_jit
    def offset_by_dict(self, off_dict):
        """Add offsets to current desc. note that this function won't add to pointer immediately.
        instead we store offsets to `desc.named_offsets`.
        For better pointer desc performance, you may need to call `get_offseted_ptr_desc`
        to replace pointer and clear offsets after offsetting.
        """
        return aggregate_replace(
            self,
            named_offsets=self.named_offsets.add_offsets_must_exists(off_dict.keys, off_dict.values_cw),
        )

    @triton_jit
    def _increment_offset_dim(self, block_idx: tl.constexpr, value_cw):
        tl.static_assert(
            not self.named_offsets.values_cw[block_idx].is_constexpr,
            "you can't increment constexpr offset, convert "
            "it to tensor before entering any loop first.",
        )
        res = [
            dispatch_value(
                self.named_offsets.values_cw[i].value
                + (value_cw.value if i == block_idx else 0)
            )
            for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
        ]
        return res

    @triton_jit
    def _increment_offset_dim_nocheck(self, block_idx: tl.constexpr, value_cw):
        res = [
            dispatch_value(
                self.named_offsets.values_cw[i].value
                + (value_cw.value if i == block_idx else 0)
            )
            for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
        ]
        return res

    @triton_jit
    def make_offset_dim_mutable(self, dim_name: tl.constexpr):
        """Call this when you want to directly increment offset in a loop."""
        # TODO let dim_name support multiple dims like "B,H"
        dim_idx: tl.constexpr = self._get_dim_by_block_dim_name(dim_name).value

        res = [
            TritonField(get_scalar_tensor(self.named_offsets.values_cw[i].value))
            if i == dim_idx and self.named_offsets.values_cw[i].is_constexpr
            else self.named_offsets.values_cw[i]
            for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
        ]
        return self.replace_offset(res)

    @triton_jit
    def increment_fixed_block(self, dim_name: tl.constexpr, num_block: tl.constexpr):
        dim_idx: tl.constexpr = self._get_dim_by_block_dim_name(dim_name).value
        new_values_cw = self._increment_offset_dim(
            dim_idx, TritonConstexprField(num_block * self.block_shape[dim_idx])
        )
        return self.replace_offset(new_values_cw)

    @triton_jit
    def replace_offset(self, new_values_cw):
        gl.static_assert(
            len(new_values_cw) == len(self.block_shape),
            "New offset tuple length must match block shape length.",
        )
        return aggregate_replace(
            self,
            named_offsets=TTOffsetDict(
                new_values_cw, self.named_offsets.keys
            ),
        )

    @triton_jit
    def replace_block_offset(self, new_block_offset_tuple):
        gl.static_assert(
            len(new_block_offset_tuple) == len(self.block_shape),
            "New offset tuple length must match block shape length.",
        )
        new_values_cw = [
            TritonField(new_block_offset_tuple[i] * self.block_shape[i].value)
            for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
        ]
        return aggregate_replace(
            self,
            named_offsets=TTOffsetDict(
                new_values_cw, self.named_offsets.keys
            ),
        )

    @triton_jit
    def gather(self, offsets, add_offset_to_inds: tl.constexpr = True):
        tl.static_assert(
            len(offsets) == 2 and len(self.block_shape) == 2,
            "currently only support 2D gather to make api compatible with TMA gather.",
        )
        offsets_cw_arg = tuple_to_cwrapper(offsets)
        self.assert_is_pointer()
        # find gather axis
        is_blocked_tensors = [
            TritonConstexprField(True)
            if (
                isinstance(offsets_cw_arg[i].value, tl.tensor)
                and offsets_cw_arg[i].value.numel > 1
            )
            else TritonConstexprField(False)
            for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
        ]
        true_inds: tl.constexpr = sym.get_true_inds_of_bool_tuple_cw(
            is_blocked_tensors, -1
        )
        false_inds: tl.constexpr = sym.get_false_inds_of_bool_tuple_cw(
            is_blocked_tensors, -1
        )
        tl.static_assert(len(true_inds) == 1, "only support gather on one blocked dim")
        new_values_cw = self._increment_offset_dim_nocheck(
            false_inds[0], offsets_cw_arg[false_inds[0]]
        )
        return self.replace_offset(new_values_cw).masked_gather(
            offsets_cw_arg[true_inds[0]].value,
            axis=true_inds[0],
            apply_mask=True,
            add_offset_to_inds=add_offset_to_inds,
        )


@aggregate(kw_only=True)
class BlockedTensorDescTMABase(BlockedTensorDescWithOffset):
    non_block_named_offsets: TTOffsetDict
    def __repr__(self):
        return super().__repr__()

    @triton_jit
    def get_all_offsets_cw_for_tma(self, block_offsets_cw):
        tl.static_assert(
            len(block_offsets_cw) == len(self.block_shape),
            "block offsets length must match block shape length.",
        )
        block_sym_global: tl.constexpr = sym.local_sym_to_global(
            self.shape_sym, self.block_shape_sym
        )
        block_names: tl.constexpr = sym.get_shape_names_from_sym(block_sym_global)
        overall_offsets = merge_two_tuple(
            self.non_block_named_offsets.values_cw, block_offsets_cw
        )
        overall_offset_names: tl.constexpr = sym.merge_two_name_list(
            self.non_block_named_offsets.keys, block_names
        )
        sym_axes: tl.constexpr = sym.get_sym_axes_in_name_tuple(
            overall_offset_names, self.shape_sym
        )
        offset_tuple_cw = [
            overall_offsets[sym_axes[i]]
            if sym_axes[i] >= 0
            else TritonConstexprField(0)
            for i in tl.tuple(sym.tuple_range(len(sym_axes)))
        ]
        return offset_tuple_cw

    @triton_jit
    def _preprocess_tma_value(self, value):
        self.assert_is_tma_desc()
        tl.static_assert(len(value.shape) == len(self.block_shape), "value shape must match block shape.")
        for i in tl.static_range(len(self.block_shape)):
            tl.static_assert(
                value.shape[i] == self.block_shape[i],
                f"{self.name}: value shape must match block shape, but got {value.shape} and {self.block_shape}",
            )
        return value.reshape(self.ptr.block_shape)

    @triton_jit
    def offset_by_dict_if_exists(self, offs: TTOffsetDict):
        offs_keys_sym: tl.constexpr = sym.names_to_sym(offs.keys)
        offs_sym_global: tl.constexpr = sym.local_sym_to_global(
            self.shape_sym, offs_keys_sym, allow_invalid=True
        )
        offs_keys_global: tl.constexpr = sym.get_shape_names_from_sym(offs_sym_global)
        offs = TTOffsetDict(offs.values_cw, offs_keys_global)
        block_sym_global: tl.constexpr = sym.local_sym_to_global(
            self.shape_sym, self.block_shape_sym
        )
        offs_valid = offs.filter_by_sym_include(self.shape_sym)
        offs_no_block = offs_valid.filter_by_sym_exclude(block_sym_global)
        offs_block = offs_valid.filter_by_sym_include(block_sym_global)
        new_named_offs = self.named_offsets.add_offsets_must_exists(
            offs_block.keys, offs_block.values_cw
        )
        new_non_block_named_offs = self.non_block_named_offsets.merge_add_offsets(
            offs_no_block.keys, offs_no_block.values_cw
        )
        return aggregate_replace(
            self,
            named_offsets=new_named_offs,
            non_block_named_offsets=new_non_block_named_offs,
        )


@aggregate(kw_only=True)
class BlockedTensorDescTMATriton(BlockedTensorDescTMABase):
    def __repr__(self):
        return super().__repr__()

    @triton_jit
    def tma_load(self, offsets):
        self.assert_is_tma_desc()
        offsets_cw_arg = tuple_to_cwrapper(offsets)
        return self.tma_load_cw(offsets_cw_arg)

    @triton_jit
    def tma_load_cw(self, offsets_cw_arg):
        self.assert_is_tma_desc()
        values_cw = [
            dispatch_value(
                offsets_cw_arg[i].value + self.get_cur_offset_cw_by_block_idx(i).value
            )
            for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
        ]
        all_offsets_cw = self.get_all_offsets_cw_for_tma(values_cw)
        res = self.ptr.load(
            [
                all_offsets_cw[i].value
                for i in tl.tuple(sym.tuple_range(len(all_offsets_cw)))
            ]
        )
        res = res.reshape(self.block_shape)
        return res

    @triton_jit
    def tma_store_cw(self, offsets_cw_arg, value, reduce_kind: tl.constexpr = None, _ignore_offset: tl.constexpr = False):
        self.assert_is_tma_desc()
        value = self._preprocess_tma_value(value)
        if _ignore_offset:
            all_offsets_cw = self.get_all_offsets_cw_for_tma(self.named_offsets.values_cw)
        else:
            values_cw = [
                dispatch_value(
                    offsets_cw_arg[i].value + self.get_cur_offset_cw_by_block_idx(i).value
                )
                for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
            ]
            all_offsets_cw = self.get_all_offsets_cw_for_tma(values_cw)
        if reduce_kind is None:

            self.ptr.store(
                [
                    all_offsets_cw[i].value
                    for i in tl.tuple(sym.tuple_range(len(all_offsets_cw)))
                ],
                value,
            )
        else:
            if reduce_kind == "add":
                self.ptr.atomic_add(
                    [
                        all_offsets_cw[i].value
                        for i in tl.tuple(sym.tuple_range(len(all_offsets_cw)))
                    ],
                    value,
                )
            elif reduce_kind == "min":
                self.ptr.atomic_min(
                    [
                        all_offsets_cw[i].value
                        for i in tl.tuple(sym.tuple_range(len(all_offsets_cw)))
                    ],
                    value,
                )
            elif reduce_kind == "max":
                self.ptr.atomic_min(
                    [
                        all_offsets_cw[i].value
                        for i in tl.tuple(sym.tuple_range(len(all_offsets_cw)))
                    ],
                    value,
                )
            elif reduce_kind == "and":
                self.ptr.atomic_min(
                    [
                        all_offsets_cw[i].value
                        for i in tl.tuple(sym.tuple_range(len(all_offsets_cw)))
                    ],
                    value,
                )
            elif reduce_kind == "or":
                self.ptr.atomic_min(
                    [
                        all_offsets_cw[i].value
                        for i in tl.tuple(sym.tuple_range(len(all_offsets_cw)))
                    ],
                    value,
                )
            elif reduce_kind == "xor":
                self.ptr.atomic_min(
                    [
                        all_offsets_cw[i].value
                        for i in tl.tuple(sym.tuple_range(len(all_offsets_cw)))
                    ],
                    value,
                )
            else:
                tl.static_assert(
                    False, f"unsupported tma reduce {reduce_kind} , supported: add, min, max, and, or, xor"
                )

    @triton_jit
    def tma_store(self, offsets, value, reduce_kind: tl.constexpr = None):
        offsets_cw_arg = tuple_to_cwrapper(offsets)
        self.tma_store_cw(offsets_cw_arg, value, reduce_kind=reduce_kind)

    @triton_jit
    def tma_load_cur(self):
        """API for desc.offset(dim1=off1, dim2=off2).tma_load_cur() to support kwarg offsets.
        we will remove offset tuple based load later and use kwarg offsets.
        """
        self.assert_is_tma_desc()
        all_offsets_cw = self.get_all_offsets_cw_for_tma(self.named_offsets.values_cw)
        res = self.ptr.load(
            [
                all_offsets_cw[i].value
                for i in tl.tuple(sym.tuple_range(len(all_offsets_cw)))
            ]
        )
        res = res.reshape(self.block_shape)
        return res

    @triton_jit
    def tma_store_cur(self, value, reduce_kind: tl.constexpr = None):
        """API for desc.offset(dim1=off1, dim2=off2).tma_load_cur() to support kwarg offsets.
        """
        return self.tma_store_cw(
            None, value, _ignore_offset=True, reduce_kind=reduce_kind
        )

    @triton_jit
    def tma_gather_cw(self, offsets_cw_arg, add_offset_to_inds: tl.constexpr = True):
        self.assert_is_tma_desc()
        offsets_cw_arg = tuple_to_cwrapper(offsets)
        values_cw = [
            offsets_cw_arg[i]
            if (
                isinstance(offsets_cw_arg[i].value, tl.tensor)
                and offsets_cw_arg[i].value.numel > 1
                and not add_offset_to_inds
            )
            else dispatch_value(
                offsets_cw_arg[i].value + self.get_cur_offset_cw_by_block_idx(i).value
            )
            for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
        ]
        all_offsets_cw = self.get_all_offsets_cw_for_tma(values_cw)
        value = self.ptr.gather(
            *[
                all_offsets_cw[i].value
                for i in tl.tuple(sym.tuple_range(len(all_offsets_cw)))
            ]
        )
        # value = value.reshape(self.ptr.block_shape)
        return value

    @triton_jit
    def tma_gather(self, offsets, add_offset_to_inds: tl.constexpr = True):
        self.assert_is_tma_desc()
        offsets_cw_arg = tuple_to_cwrapper(offsets)
        return self.tma_gather_cw(offsets_cw_arg, add_offset_to_inds)

    @triton_jit
    def gather(self, offsets, add_offset_to_inds: tl.constexpr = True):
        return self.tma_gather(offsets, add_offset_to_inds)

    @triton_jit
    def tma_scatter_cw(self, offsets_cw_arg, value, add_offset_to_inds: tl.constexpr = True):
        value = self._preprocess_tma_value(value)
        self.assert_is_tma_desc()
        values_cw = [
            offsets_cw_arg[i]
            if (
                isinstance(offsets_cw_arg[i].value, tl.tensor)
                and offsets_cw_arg[i].value.numel > 1
                and not add_offset_to_inds
            )
            else dispatch_value(
                offsets_cw_arg[i].value + self.get_cur_offset_cw_by_block_idx(i).value
            )
            for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
        ]
        all_offsets_cw = self.get_all_offsets_cw_for_tma(values_cw)
        self.ptr.scatter(
            [
                all_offsets_cw[i].value
                for i in tl.tuple(sym.tuple_range(len(all_offsets_cw)))
            ],
            value,
        )


    @triton_jit
    def tma_scatter(self, offsets, value, add_offset_to_inds: tl.constexpr = True):
        value = value.reshape(self.ptr.block_shape)
        self.assert_is_tma_desc()
        offsets_cw_arg = tuple_to_cwrapper(offsets)
        self.tma_scatter_cw(offsets_cw_arg, value, add_offset_to_inds)


@aggregate(kw_only=True)
class BlockedTensorDescTMAGluon(BlockedTensorDescTMABase):

    def __repr__(self):
        return super().__repr__()

    @triton_jit
    def issue_tma_load_cw(self, offsets_cw_arg, bar, smem, pred=True):
        self.assert_is_tma_desc()
        values_cw = [
            dispatch_value(
                offsets_cw_arg[i].value + self.get_cur_offset_cw_by_block_idx(i).value
            )
            for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
        ]
        all_offsets_cw = self.get_all_offsets_cw_for_tma(values_cw)
        tma.async_copy_global_to_shared(self.ptr, [
            all_offsets_cw[i].value
            for i in tl.tuple(sym.tuple_range(len(all_offsets_cw)))
        ], bar, smem, pred=pred)
    
    @triton_jit
    def _issue_tma_gather_scatter_cw(self, is_gather: tl.constexpr, offsets_cw_arg, bar, smem, add_offset_to_inds: tl.constexpr = False, pred=True):
        self.assert_is_tma_desc()
        values_cw = [
            offsets_cw_arg[i]
            if (
                isinstance(offsets_cw_arg[i].value, tl.tensor)
                and offsets_cw_arg[i].value.numel > 1
                and not add_offset_to_inds
            )
            else dispatch_value(
                offsets_cw_arg[i].value + self.get_cur_offset_cw_by_block_idx(i).value
            )
            for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
        ]
        all_offsets_cw = self.get_all_offsets_cw_for_tma(values_cw)
        if is_gather:
            tma.async_gather(self.ptr, all_offsets_cw[0].value, all_offsets_cw[1].value, bar, smem, pred=pred)
        else:
            if isinstance(pred, int) and pred:
                tma.async_scatter(self.ptr, all_offsets_cw[0].value, all_offsets_cw[1].value, smem)
            else:
                if pred:
                    tma.async_scatter(self.ptr, all_offsets_cw[0].value, all_offsets_cw[1].value, smem)

    @triton_jit
    def issue_tma_gather_cw(self, offsets_cw_arg, bar, smem, add_offset_to_inds: tl.constexpr = False, pred=True):
        self._issue_tma_gather_scatter_cw(
            True, offsets_cw_arg, bar, smem, add_offset_to_inds=add_offset_to_inds, pred=pred
        )

    @triton_jit
    def issue_tma_scatter_cw(self, offsets_cw_arg, smem, add_offset_to_inds: tl.constexpr = False, pred=True):
        self._issue_tma_gather_scatter_cw(
            False, offsets_cw_arg, None, smem, add_offset_to_inds=add_offset_to_inds, pred=pred
        )

    @triton_jit
    def tma_load_cur(self, bar, smem, multicast: tl.constexpr = False):
        """API for desc.offset(dim1=off1, dim2=off2).tma_load_cur(bar, smem) to support kwarg offsets.
        we will remove offset tuple based load later and use kwarg offsets.
        """
        self.assert_is_tma_desc()
        all_offsets_cw = self.get_all_offsets_cw_for_tma(self.named_offsets.values_cw)
        tma.async_copy_global_to_shared(self.ptr, [
            all_offsets_cw[i].value
            for i in tl.tuple(sym.tuple_range(len(all_offsets_cw)))
        ], bar, smem, )

    @triton_jit
    def issue_tma_store_cw(self, offsets_cw_arg, smem, reduce_kind: tl.constexpr = None):
        """API for desc.offset(dim1=off1, dim2=off2).tma_store_cur(smem) to support kwarg offsets.
        """
        self.assert_is_tma_desc()
        values_cw = [
            dispatch_value(
                offsets_cw_arg[i].value + self.get_cur_offset_cw_by_block_idx(i).value
            )
            for i in tl.tuple(sym.tuple_range(len(self.block_shape)))
        ]
        all_offsets_cw = self.get_all_offsets_cw_for_tma(values_cw)
        if reduce_kind is None:
            tma.async_copy_shared_to_global(self.ptr, [
                all_offsets_cw[i].value
                for i in tl.tuple(sym.tuple_range(len(all_offsets_cw)))
            ], smem)
        else:
            async_tma_reduce_shared_to_global(self.ptr, reduce_kind, [
                all_offsets_cw[i].value
                for i in tl.tuple(sym.tuple_range(len(all_offsets_cw)))
            ], smem)

    @triton_jit
    def tma_store_cur(self, smem, reduce_kind: tl.constexpr = None):
        """API for desc.offset(dim1=off1, dim2=off2).tma_store_cur(smem) to support kwarg offsets.
        """
        self.assert_is_tma_desc()
        all_offsets_cw = self.get_all_offsets_cw_for_tma(self.named_offsets.values_cw)
        if reduce_kind is None:

            tma.async_copy_shared_to_global(self.ptr, [
                all_offsets_cw[i].value
                for i in tl.tuple(sym.tuple_range(len(all_offsets_cw)))
            ], smem)
        else:
            async_tma_reduce_shared_to_global(self.ptr, reduce_kind, [
                all_offsets_cw[i].value
                for i in tl.tuple(sym.tuple_range(len(all_offsets_cw)))
            ], smem)

    @triton_jit
    def tma_store_sync(self, value, smem, reduce_kind: tl.constexpr = None):
        value = self._preprocess_tma_value(value)

        tl.static_assert(
            is_gluon() and self.is_tma_desc().value,
            "only tma support async store in gluon.",
        )
        all_offsets_cw = self.get_all_offsets_cw_for_tma(self.named_offsets.values_cw)
        smem.store(value)
        fence_async_shared()
        # Issue the store without waiting for it.
        if reduce_kind is None:
            tma.async_copy_shared_to_global(self.ptr, [
                all_offsets_cw[i].value
                for i in tl.tuple(sym.tuple_range(len(all_offsets_cw)))
            ], smem)
        else:
            async_tma_reduce_shared_to_global(self.ptr, reduce_kind, [
                all_offsets_cw[i].value
                for i in tl.tuple(sym.tuple_range(len(all_offsets_cw)))
            ], smem)
        tma.store_wait(pendings=0)
        return

