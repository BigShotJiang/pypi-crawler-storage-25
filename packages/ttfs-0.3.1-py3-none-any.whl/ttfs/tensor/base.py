import ast
import dataclasses
import json
import traceback
from types import NoneType
from typing import Any

import torch

import triton.language as tl
from triton.experimental.gluon import language as gl
from typing_extensions import Annotated

from ttfs.core.aggtype import (
    FieldMeta,
    TritonAggFieldAccessor,
    TritonAggFlatField,
    aggregate,
    aggregate_replace,
    constexpr_function,
    triton_jit,
    FIELD_ACCESSOR_REGISTRY,
)
from ttfs.core.mp import (
    TritonConstexprField,
    TritonField,
    get_field,
    get_num_warps,
    is_constexpr,
    is_gluon,
    torch_dtype_to_gluon,
)
from ttfs.core import sym
from ttfs.core.layout import (
    get_default_block_io_layout,
)
from ttfs.core.ttdict import TTOffsetDict, TTDict, offsets
from ttfs.core.logger import logger as LOGGER
from triton.tools.tensor_descriptor import (
    TensorDescriptor as HostTensorDescriptorTriton,
)
from triton.experimental.gluon.nvidia.hopper import (
    TensorDescriptor as HostTensorDescriptorGluon,
)

@aggregate
class StrideWithMultipleOf:
    stride: Any
    multiple_of: tl.constexpr
    need_multiple_of: tl.constexpr


@aggregate
class TensorDesc:
    ptr: Any
    shape_sym: Annotated[str, tl.constexpr]
    # -1 or (-1, -1, 64, -1)
    strides: Annotated[Any, FieldMeta(is_kernel_arg=False)] = None
    stride_multiple_of: tl.constexpr = dataclasses.field(default=tl.constexpr(1))
    _ttfs_tmp_pv_stride: Annotated[
        str, tl.constexpr, FieldMeta(is_kernel_arg=False)
    ] = ""
    # only used when ptr is immutable (e.g. tensor descriptor).
    # otherwise offset will be added to pointer.
    _ttfs_immutable_offs_dict: Annotated[
        TTOffsetDict, FieldMeta(is_kernel_arg=False)
    ] = dataclasses.field(default_factory=TTOffsetDict)
    block_size_json: Annotated[
        str, tl.constexpr, FieldMeta(is_kernel_arg=False)
    ] = ""
    block_stride_json: Annotated[
        str, tl.constexpr, FieldMeta(is_kernel_arg=False)
    ] = ""
    is_swizzled_layout: Annotated[bool, tl.constexpr] = True

    def __post_init__(self):
        if isinstance(self.ptr, torch.Tensor):
            # init from host code
            msg = (
                f"strides must be None in host side init, get {self.strides}. use "
                'Annotated[ttfs.TensorDesc, ttfs.tensor_desc_meta("B,H")] '
                "to indicate which dims to pass strides for. we will fill strides from torch tensor."
            )
            assert self.strides is None or (isinstance(self.strides, tl.constexpr) and self.strides.value is None), msg
            sym_parts = sym.get_shape_names_from_sym(self.shape_sym)
            assert len(sym_parts) == self.ptr.ndim, (
                f"shape_sym {self.shape_sym} has {len(sym_parts)} dims, but tensor has {self.ptr.ndim} dims."
            )

        ndim: tl.constexpr = len(sym.get_shape_names_from_sym(self.shape_sym))
        if self.strides is None or (isinstance(self.strides, tl.constexpr) and self.strides.value is None):
            self.strides = tl.tuple([tl.constexpr(-1)] * ndim)
        if isinstance(
            self.ptr, (HostTensorDescriptorTriton, HostTensorDescriptorGluon)
        ):
            sym_parts = sym.get_shape_names_from_sym(self.shape_sym)
            assert len(sym_parts) == self.ptr.base.ndim, (
                f"shape_sym {self.shape_sym} has {len(sym_parts)} dims, but tensor has {self.ptr.base.ndim} dims."
            )

        if isinstance(
            self.ptr,
            (
                tl.tensor_descriptor,
                gl.nvidia.hopper.tma.tensor_descriptor,
                HostTensorDescriptorTriton,
                HostTensorDescriptorGluon,
            ),
        ):
            # when use host-side tensor desc, validate ndim.
            # NOTE: strides and stride_multiple_of will be ignored. TODO should we check this, make sure users don't set them?
            assert ndim == len(self.ptr.block_shape), (
                f"TensorDesc shape_sym indicates {ndim} dims, but ptr has {len(self.ptr.block_shape)} dims."
            )

        assert isinstance(self.strides, tl.tuple), (
            f"Strides must be a tl.tuple, but got {type(self.strides)}."
        )
        pv_stride_sym = tl.core._unwrap_if_constexpr(self._ttfs_tmp_pv_stride)
        if pv_stride_sym != "":
            value_axes = sym.get_sym_axes_allow_invalid(self.shape_sym, pv_stride_sym)
            new_strides = list(tl.constexpr(-1) for _ in range(ndim))
            for j, axis in enumerate(value_axes):
                # axis may be -1 if allow_invalid.
                if axis >= 0:
                    assert axis < ndim, (
                        f"passed stride axis {axis} out of range for shape with ndim {ndim}."
                    )
                    new_strides[axis] = self.strides[j]
            self.strides = tl.tuple(new_strides)
            # WARNING: dataclasses.replace will trigger __post_init__, so we must clear this here.
            self._ttfs_tmp_pv_stride = ""
        if isinstance(self.strides, tl.tuple):
            assert len(self.strides) == ndim, (
                f"Strides length {len(self.strides)} doesn't match shape length {ndim}."
            )
        if isinstance(self.stride_multiple_of, (tl.tuple, tuple, list)):
            assert len(self.stride_multiple_of) == ndim, (
                f"stride_multiple_of length {len(self.stride_multiple_of)} doesn't match shape length {ndim}."
            )
        else:
            self.stride_multiple_of = tuple([1] * ndim)

    @staticmethod
    @sym.workaround_ignore_cache_record
    def tma_from_tensor_triton(
        ten: torch.Tensor, shape_sym: str, block_shape: list[int],
        padding: str = "zero", block_size_expr_json: str = "",
    ):
        names, _ = sym.parse_shape_sym(shape_sym)
        assert len(names) == len(block_shape), (
            f"shape_sym {shape_sym} has {len(names)} dims, but block_shape has {len(block_shape)} dims."
        )
        assert len(names) == ten.ndim, (
            f"shape_sym {shape_sym} has {len(names)} dims, but tensor has {ten.ndim} dims."
        )
        return TensorDesc(
            ptr=HostTensorDescriptorTriton.from_tensor(ten, block_shape, padding),
            shape_sym=shape_sym,
            block_size_json=block_size_expr_json,
        )

    @staticmethod
    @sym.workaround_ignore_cache_record
    def tma_from_tensor(
        ten: torch.Tensor, shape_sym: str, block_shape: list[int], is_gluon: bool, padding: str = "zero",
        block_size_expr_json: str = "", block_stride_json: str = "", is_swizzled_layout: bool = True
    ):
        if is_gluon:
            return TensorDesc.tma_from_tensor_gluon(ten, shape_sym, block_shape, 
                padding, 
                block_size_expr_json=block_size_expr_json, 
                block_stride_json=block_stride_json,
                is_swizzled_layout=is_swizzled_layout)
        else:
            return TensorDesc.tma_from_tensor_triton(ten, shape_sym, block_shape, padding, block_size_expr_json=block_size_expr_json)

    @staticmethod
    @sym.workaround_ignore_cache_record
    def get_tma_desc_triton(ten: torch.Tensor, block_shape: list[int], padding: str = "zero"):
        return HostTensorDescriptorTriton.from_tensor(ten, block_shape, padding=padding)

    @staticmethod
    @sym.workaround_ignore_cache_record
    def tma_from_tensor_gluon(
        ten: torch.Tensor, shape_sym: str, block_shape: list[int], padding: str = "zero", 
        block_size_expr_json: str = "", block_stride_json: str = "", is_swizzled_layout: bool = True
    ):
        names, _ = sym.parse_shape_sym(shape_sym)
        assert len(names) == len(block_shape), (
            f"shape_sym {shape_sym} has {len(names)} dims, but block_shape has {len(block_shape)} dims."
        )
        assert len(names) == ten.ndim, (
            f"shape_sym {shape_sym} has {len(names)} dims, but tensor has {ten.ndim} dims."
        )
        if is_swizzled_layout:
            layout = gl.NVMMASharedLayout.get_default_for(
                block_shape, torch_dtype_to_gluon(ten.dtype)
            )
        else:
            layout = gl.NVMMASharedLayout(0, 
                torch_dtype_to_gluon(ten.dtype).primitive_bitwidth, rank=len(block_shape)
            )

        return TensorDesc(
            ptr=HostTensorDescriptorGluon.from_tensor(ten, block_shape, layout, padding=padding),
            shape_sym=shape_sym,
            block_size_json=block_size_expr_json,
            block_stride_json=block_stride_json,
            is_swizzled_layout=is_swizzled_layout,
        )

    @staticmethod
    @sym.workaround_ignore_cache_record
    def get_tma_desc_gluon(ten: torch.Tensor, block_shape: list[int]):
        layout = gl.NVMMASharedLayout.get_default_for(
            block_shape, torch_dtype_to_gluon(ten.dtype)
        )
        return HostTensorDescriptorGluon.from_tensor(ten, block_shape, layout)

    @staticmethod
    @triton_jit
    def empty():
        return TensorDesc(
            ptr=None,
            shape_sym="B",
        )

    @staticmethod
    def empty_host():
        return TensorDesc(
            ptr=None,
            shape_sym="",
        )

    @triton_jit
    def get_dtype(self):
        if self.is_tma_desc().value:
            dtype: tl.constexpr = self.ptr.dtype
        else:
            dtype: tl.constexpr = self.ptr.dtype.element_ty
        return TritonConstexprField(dtype)

    def get_dtype_post_init(self):
        if isinstance(self.ptr, (tl.tensor_descriptor,
                gl.nvidia.hopper.tma.tensor_descriptor)):
            return self.ptr.dtype
        else:
            return self.ptr.dtype.element_ty


    @triton_jit
    def get_ndim(self):
        ndim: tl.constexpr = len(sym.get_shape_names_from_sym(self.shape_sym))
        return TritonConstexprField(ndim)

    @triton_jit
    def is_tma_desc(self):
        if is_gluon():
            tl.static_assert(not isinstance(self.ptr, tl.tensor_descriptor), 
                "you need to create gluon TMA descriptor in gluon kernel, but you create triton desc.")
            return TritonConstexprField(
                isinstance(self.ptr, gl.nvidia.hopper.tma.tensor_descriptor)
            )
        else:
            return TritonConstexprField(isinstance(self.ptr, tl.tensor_descriptor))

    @triton_jit
    def is_valid_desc(self):
        # ptr may be none.
        return TritonConstexprField(self.ptr is not None)

    @triton_jit
    def assert_is_valid(self):
        tl.static_assert(self.is_valid_desc().value, "desc pointer must not be None.")

    @triton_jit
    def assert_is_pointer(self):
        tl.static_assert(
            not self.is_tma_desc().value, "Only support pointer tensor desc."
        )

    @triton_jit
    def assert_is_tma_desc(self):
        tl.static_assert(self.is_tma_desc().value, "Only support tma tensor desc.")

    @triton_jit
    def get_default_blocked_io_layout_from_block(
        self, block_shape_sym: tl.constexpr, block_shape: tl.constexpr, is_atomic_reduce: tl.constexpr = False
    ):
        tl.static_assert(is_gluon(), "layout is only supported in gluon backend.")
        num_warps: tl.constexpr = get_num_warps()
        order: tl.constexpr = sym.get_blocked_layout_order(
            self.shape_sym, block_shape_sym
        )
        # tl.static_print(block_shape_sym, block_shape, order)
        layout: tl.constexpr = get_default_block_io_layout(
            dtype=self.get_dtype().value,
            shape=block_shape,
            bitwidth=self.get_dtype().value.primitive_bitwidth,
            order=order,
            num_warps=num_warps,
            num_threads_per_warp=32,
            is_atomic_reduce=is_atomic_reduce,
        )
        return TritonConstexprField(layout)

    @triton_jit
    def get_immutable_offseted_desc(
        self, off_names: tl.constexpr, values_cw: tl.tuple
    ):
        new_named_offs = self._ttfs_immutable_offs_dict.merge_add_offsets(
            off_names, values_cw
        )
        return aggregate_replace(
            self,
            _ttfs_immutable_offs_dict=new_named_offs,
        )

@FIELD_ACCESSOR_REGISTRY.register(key=TensorDesc)
class TensorDescFieldAccessor(TritonAggFieldAccessor):
    def __init__(
        self, ndim: int = -1, passed_strides: str = "", constexpr_strides: str = ""
    ):
        # currently ndim is only used in validation
        self._ndim = ndim
        self._passed_strides = passed_strides
        if passed_strides != "":
            self._num_value_stride = len(passed_strides.split(","))
        else:
            self._num_value_stride = 0
        passed_strides_parts = [x.strip() for x in passed_strides.split(",")]
        constexpr_stride_idxes: list[int] = []
        if constexpr_strides:
            constexpr_stride_parts = [x.strip() for x in constexpr_strides.split(",")]
            for i, part in enumerate(passed_strides_parts):
                if part in constexpr_stride_parts:
                    constexpr_stride_idxes.append(i)
        self._constexpr_stride_idxes = constexpr_stride_idxes
        self._stride_multiple_of_short_name = "stride_mul"
        if ndim > 0:
            assert self._num_value_stride <= ndim, (
                f"passed_strides {passed_strides} has more dims than ndim {ndim}."
            )

    def get_custom_fields(self) -> list[tuple[str, bool]]:
        res: list[tuple[str, bool]] = [
            ("ptr", False),
            ("cfg", True),
        ]
        for i in range(self._num_value_stride):
            is_constexpr = i in self._constexpr_stride_idxes
            res.append((f"s{i}", is_constexpr))
        return res

    def get_load_call_node(
        self, meta: TritonAggFlatField, root_arg_name: str, fn_node: ast.Call
    ) -> ast.Call:
        new_stride_tuples = []
        for i in range(self._num_value_stride):
            arg_name = meta.mangle_path(root_arg_name, f"s{i}")
            new_stride_tuples.append(ast.Name(id=arg_name, ctx=ast.Load()))
        cfg_node = ast.Name(
            id=meta.mangle_path(root_arg_name, "cfg"), ctx=ast.Load()
        )
        node = ast.Call(
            func=fn_node,
            args=[],
            keywords=[
                ast.keyword(
                    arg="ptr",
                    value=ast.Name(
                        id=meta.mangle_path(root_arg_name, "ptr"), ctx=ast.Load()
                    ),
                ),
                ast.keyword(
                    arg="shape_sym",
                    value=ast.Subscript(
                        cfg_node, ast.Constant(0), ctx=ast.Load()
                    ),
                ),
                ast.keyword(
                    arg="stride_multiple_of",
                    value=ast.Subscript(
                        cfg_node, ast.Constant(1), ctx=ast.Load()
                    ),
                ),
                ast.keyword(
                    arg="block_size_json",
                    value=ast.Subscript(
                        cfg_node, ast.Constant(2), ctx=ast.Load()
                    ),
                ),
                ast.keyword(
                    arg="block_stride_json",
                    value=ast.Subscript(
                        cfg_node, ast.Constant(3), ctx=ast.Load()
                    ),
                ),
                ast.keyword(
                    arg="is_swizzled_layout",
                    value=ast.Subscript(
                        cfg_node, ast.Constant(4), ctx=ast.Load()
                    ),
                )

            ],
        )
        if self._passed_strides != "":
            node.keywords.append(
                ast.keyword(
                    arg="strides",
                    value=ast.Tuple(elts=new_stride_tuples, ctx=ast.Load()),
                ),
            )
            node.keywords.append(
                ast.keyword(
                    arg="_ttfs_tmp_pv_stride",
                    value=ast.Constant(value=self._passed_strides),
                )
            )
        return node

    def get_flatten_agg_to_kwarg_lines(
        self, meta: TritonAggFlatField, root_arg_name: str, desc_path: str
    ) -> list[str]:

        lines = [
            f"kwargs['{meta.mangle_path(root_arg_name, 'ptr')}'] = {desc_path}.ptr",
            (f"kwargs['{meta.mangle_path(root_arg_name, "cfg")}'] = "
             f"({desc_path}.shape_sym, {desc_path}.stride_multiple_of, "
             f"{desc_path}.block_size_json, {desc_path}.block_stride_json, "
             f"{desc_path}.is_swizzled_layout)"),
        ]
        if self._ndim > 0:
            lines.append(
                f"assert({desc_path}.ptr is not None and {desc_path}.ptr.ndim == {self._ndim}, 'TensorDesc ndim mismatch, expected {self._ndim}, get ' + str({desc_path}.ptr.ndim))"
            )
        if self._num_value_stride > 0:
            axes_var_name = meta.mangle_path(root_arg_name, "axes")
            # shape_sym is constexpr in host aggregate
            # allow invalid sym in passed_strides here.
            lines.append(
                f"{axes_var_name} = ttfs.sym.cached_get_sym_axes_host({desc_path}.shape_sym.value, '{self._passed_strides}', True)"
            )
            lines.append(f"if {desc_path}.ptr is not None:")
            for i in range(self._num_value_stride):
                # TODO currently hack for tensor descriptor.
                lines.append(f"    _stride_{i} = -1")
                lines.append(f"    if {axes_var_name}[{i}] >= 0:")
                lines.append(
                    f"        _stride_{i} = {desc_path}.ptr.stride({axes_var_name}[{i}]) if isinstance({desc_path}.ptr, torch.Tensor) else {desc_path}.ptr.strides[{axes_var_name}[{i}]]"
                )
                lines.append(
                    f"    kwargs['{meta.mangle_path(root_arg_name, f's{i}')}'] = _stride_{i}"
                )
            lines.append(f"else:")
            for i in range(self._num_value_stride):
                lines.append(
                    f"    kwargs['{meta.mangle_path(root_arg_name, f's{i}')}'] = -1"
                )
        return lines


def tensor_desc_meta(
    passed_strides: str = "", constexpr_strides: str = "", ndim=-1
) -> FieldMeta:
    return FieldMeta(
        accessor=TensorDescFieldAccessor(ndim, passed_strides, constexpr_strides)
    )

@aggregate
class TensorMgrDetachDimInfos:
    dims_dict: TTOffsetDict
    dim_multiple_ofs_dict: TTOffsetDict
    original_dims_dict: TTOffsetDict

    @triton_jit
    def _get_dim_field_may_replaced(
        self,
        name: tl.constexpr,
    ):
        if self.original_dims_dict.is_name_exists(name).value:
            field = self.original_dims_dict.getitem(name)
        else:
            field = self.dims_dict.getitem(name)
        return field

    @triton_jit
    def get_dim_multiple_of(self, dim_name: tl.constexpr):
        if self.dim_multiple_ofs_dict.is_name_exists(dim_name).value:
            return self.dim_multiple_ofs_dict.getitem(dim_name)
        else:
            return TritonConstexprField(1)

    @triton_jit
    def has_dim_multiple_of_defined(self, dim_name: tl.constexpr):
        return self.dim_multiple_ofs_dict.is_name_exists(dim_name)

    @triton_jit
    def get_tensor_dim_size(self, desc, axis: tl.constexpr):
        desc = get_field(self, name).value
        dim_name: tl.constexpr = sym.get_name_by_dim(desc.shape_sym, axis)
        return self.dims_dict.getitem(dim_name)

    @triton_jit
    def get_tensor_dim_size_by_name(self, desc, dim_name: tl.constexpr):
        dim_name_unified: tl.constexpr = sym.local_name_to_global(
            desc.shape_sym, dim_name
        )
        return self.dims_dict.getitem(dim_name_unified)

    @triton_jit
    def get_tensor_stride(self, desc, axis: tl.constexpr):
        return self.get_tensor_stride_with_multiple_of(desc, axis).stride

    @triton_jit
    def get_tensor_stride_by_name(self, desc, dim_name: tl.constexpr):
        dim_name_unified: tl.constexpr = sym.local_name_to_global(
            desc.shape_sym, dim_name
        )
        axis: tl.constexpr = sym.get_dim_by_name(desc.shape_sym, dim_name_unified)
        return self.get_tensor_stride(desc, axis)

    @triton_jit
    def get_tensor_stride_with_multiple_of(
        self, desc, axis: tl.constexpr
    ):
        stride_multiple_of_in_desc: tl.constexpr = desc.stride_multiple_of[axis]
        if is_constexpr(desc.strides[axis]):
            if desc.strides[axis] < 0:
                # if stride is unset, stride_multiple_of defined in desc will be ignored
                # calc stride from dims, assume contiguous
                stride_names: tl.constexpr = sym.get_stride_names(desc.shape_sym, axis)
                constexpr_fields: tl.constexpr = self.dims_dict.get_constexpr_keys_cw(
                    stride_names
                ).value
                non_constexpr_fields: tl.constexpr = self.dims_dict.get_non_constexpr_keys(
                    stride_names
                ).value
                # aggregate can keep constexpr info
                stride_c = TritonConstexprField(1)
                stride_multiple_of_c = TritonConstexprField(1)
                for i in gl.static_range(len(constexpr_fields)):
                    field = self._get_dim_field_may_replaced(
                        tl.constexpr(constexpr_fields[i])
                    )
                    stride_c = TritonConstexprField(stride_c.value * field.value)
                    stride_multiple_of_c = TritonConstexprField(
                        stride_multiple_of_c.value
                        * self.get_dim_multiple_of(
                            tl.constexpr(constexpr_fields[i])
                        ).value
                    )
                if len(non_constexpr_fields) == 0:
                    return StrideWithMultipleOf(
                        stride_c,
                        stride_multiple_of_c.value,
                        False,
                    )
                else:
                    # for non-constexpr dims, we may need to use multiple_of
                    stride = 1
                    for i in gl.static_range(len(non_constexpr_fields)):
                        field = self._get_dim_field_may_replaced(
                            tl.constexpr(non_constexpr_fields[i])
                        )
                        # field = get_field(self, tl.constexpr(non_constexpr_fields[i]))
                        stride *= field.value
                        stride_multiple_of_c = TritonConstexprField(
                            stride_multiple_of_c.value
                            * self.get_dim_multiple_of(
                                tl.constexpr(non_constexpr_fields[i])
                            ).value
                        )

                    return StrideWithMultipleOf(
                        TritonField(stride * stride_c.value),
                        stride_multiple_of_c.value,
                        stride_multiple_of_c.value != 1,
                    )
            else:
                return StrideWithMultipleOf(
                    TritonConstexprField(desc.strides[axis]),
                    stride_multiple_of_in_desc,
                    stride_multiple_of_in_desc != 1,
                )
        else:
            return StrideWithMultipleOf(
                TritonField(desc.strides[axis]),
                stride_multiple_of_in_desc,
                stride_multiple_of_in_desc != 1,
            )

    @triton_jit
    def get_tensor_stride_with_multiple_of_by_name(
        self, desc, dim_name: tl.constexpr
    ):
        dim_name_unified: tl.constexpr = sym.local_name_to_global(
            desc.shape_sym, dim_name
        )
        axis: tl.constexpr = sym.get_dim_by_name(desc.shape_sym, dim_name_unified)
        return self.get_tensor_stride_with_multiple_of(desc, axis)

    @triton_jit
    def get_ptr_offset(
        self,
        desc,
        off_names: tl.constexpr,
        values_cw: tl.tuple,
    ):
        # off_names can be constexpr(["M", "N"]) or "M,N"
        off_names_u: tl.constexpr = sym.unify_offset_names(off_names)
        noffs = TTOffsetDict(values_cw, off_names_u).filter_by_sym_include(
            desc.shape_sym
        )
        if len(noffs.keys) == 0:
            return 0
        else:
            offset = 0
            for i in gl.static_range(len(noffs.keys)):
                offset = (
                    offset
                    + self.get_tensor_stride_by_name(
                        desc, tl.constexpr(noffs.keys[i])
                    ).value
                    * noffs.values_cw[i].value
                )
            return offset

    @triton_jit
    def get_offseted_ptr(
        self,
        desc,
        off_names_sym: tl.constexpr,
        values_cw: tl.tuple,
        cast_offset_to_64bit: tl.constexpr = False,
    ):
        tl.static_assert(
            not desc.is_tma_desc().value, "Only support pointer tensor desc."
        )
        if cast_offset_to_64bit:
            values_cw = [
                _cast_to_i64_if_needed(values_cw[i])
                for i in tl.tuple(sym.tuple_range(len(values_cw)))
            ]
        return desc.ptr + self.get_ptr_offset(desc, off_names_sym, values_cw)


@triton_jit
def _cast_to_i64_if_needed(value_cw):
    if value_cw.is_constexpr:
        return value_cw
    else:
        value = value_cw.value
        if value.dtype == tl.int64:
            return TritonField(value.astype(tl.int64))
        else:
            return TritonField(value)



@dataclasses.dataclass
class TensorDescCreator:
    shape_sym: str 
    block_size_expr_dict: dict[str, str]

    def __post_init__(self):
        shape_part, alias = sym.parse_shape_sym(self.shape_sym)
        new_block_size_expr_dict: dict[str, str] = {}
        for k, v in self.block_size_expr_dict.items():
            if k not in shape_part:
                assert k in alias, f"block size symbol {k} not found in shape sym {self.shape_sym}"
                new_block_size_expr_dict[shape_part[alias.index(k)]] = v
            else:
                new_block_size_expr_dict[k] = v
        self.block_size_expr_dict = new_block_size_expr_dict

    def create_blocked_desc(self, ten: torch.Tensor) -> TensorDesc:
        return  TensorDesc(
            ten,
            self.shape_sym,
            block_size_json=json.dumps(list(self.block_size_expr_dict.items()))
        )

    def create_tma_desc(self, ten: torch.Tensor, block_shape: list[int], is_gluon: bool = False, padding: str = "zero",
            is_swizzled_layout: bool = True, ) -> TensorDesc:
        shape_part, alias = sym.parse_shape_sym(self.shape_sym)
        assert len(block_shape) == len(self.block_size_expr_dict)
        tma_block_shape: list[int] = [1 for _ in range(len(shape_part))]
        cnt = 0
        for k, v in self.block_size_expr_dict.items():
            tma_block_shape[shape_part.index(k)] = block_shape[cnt]
            cnt += 1
        return TensorDesc.tma_from_tensor(
            ten,
            self.shape_sym,
            tma_block_shape,
            block_size_expr_json=json.dumps(list(self.block_size_expr_dict.items())),
            padding=padding,
            is_gluon=is_gluon,
            is_swizzled_layout=is_swizzled_layout,
        )
