import dataclasses
from typing import Any, Self
from types import NoneType

import triton.language as tl
from typing_extensions import Annotated

from ttfs.core.aggtype import (
    FieldMeta,
    TritonAggFieldAccessor,
    TritonAggFlatField,
    base_aggregate_value,
    aggregate,
    aggregate_replace,
    constexpr_function,
    get_scalar_tensor,
    triton_jit,
    triton_jit_kernel,
)
from ttfs.core.mp import (
    TritonConstexprField,
    TritonField,
    TritonFieldBase,
    cwrapped_add,
    filter_tuple_by_bool_tuple_cw,
    filter_tuple_by_bools,
    is_gluon,
    dispatch_value,
)
from ttfs.core import sym



@aggregate
class TTDict(base_aggregate_value):
    values_cw: Annotated[tl.tuple, FieldMeta(is_kernel_arg=False)] = dataclasses.field(
        default_factory=lambda: tl.tuple([])
    )
    keys: Annotated[Any, tl.constexpr, FieldMeta(is_kernel_arg=False)] = (
        dataclasses.field(default_factory=lambda: tl.constexpr([]))
    )
    def __repr__(self):
        kv_dict = {self.keys[i]: self.values_cw[i].value for i in range(len(self.values_cw))}
        return repr(kv_dict)

    @triton_jit
    def filter_by_sym_exclude(self, exc_sym: tl.constexpr):
        filter_bools: tl.constexpr = sym.get_filter_offset_pair_bools_except(
            self.keys, exc_sym
        )
        new_keys: tl.constexpr = sym.filter_constexpr_lists(
            self.keys,
            filter_bools,
        )
        new_offsets = filter_tuple_by_bools(self.values_cw, filter_bools)
        return aggregate_replace(
            self,
            values_cw=new_offsets,
            keys=new_keys,
        )

    @triton_jit
    def filter_by_sym_include(self, inc_sym: tl.constexpr):
        filter_bools: tl.constexpr = sym.get_filter_offset_pair_bools(
            self.keys, inc_sym
        )
        new_keys: tl.constexpr = sym.filter_constexpr_lists(
            self.keys,
            filter_bools,
        )
        new_offsets = filter_tuple_by_bools(self.values_cw, filter_bools)
        return aggregate_replace(
            self,
            values_cw=new_offsets,
            keys=new_keys,
        )

    @triton_jit
    def get_constexpr_keys_cw(self, included_keys: tl.constexpr):
        is_constexpr_bools = [
            TritonConstexprField(self.values_cw[i].is_constexpr and sym.is_name_in_names(self.keys[i], included_keys))
            for i in tl.tuple(sym.tuple_range(len(self.values_cw)))
        ]
        new_keys: tl.constexpr = sym.filter_constexpr_lists_cw(
            self.keys,
            is_constexpr_bools,
        )
        return TritonConstexprField(new_keys)

    @triton_jit
    def get_non_constexpr_keys(self, included_keys: tl.constexpr):
        is_constexpr_bools = [
            TritonConstexprField(not self.values_cw[i].is_constexpr and sym.is_name_in_names(self.keys[i], included_keys))
            for i in tl.tuple(sym.tuple_range(len(self.values_cw)))
        ]
        new_keys: tl.constexpr = sym.filter_constexpr_lists_cw(
            self.keys,
            is_constexpr_bools,
        )
        return TritonConstexprField(new_keys)

    @triton_jit
    def replace_offset(self, new_values_cw, new_keys: tl.constexpr):
        tl.static_assert(
            len(new_values_cw) == len(new_keys),
            "New offset tuple length must match offsets length.",
        )
        return aggregate_replace(
            self,
            values_cw=new_values_cw,
            keys=new_keys,
        )
    
    @triton_jit
    def replaceitem(self, key: tl.constexpr, val_cw):
        tl.static_assert(isinstance(val_cw, TritonFieldBase), f"val_cw must be a TritonConstexprField or TritonField, but got {type(val_cw)}")
        tl.static_assert(sym.is_name_in_names(key, self.keys), f"Key {key} not found in offset names {self.keys}.")
        res = [
            val_cw
            if self.keys[i] == key
            else self.values_cw[i]
            for i in tl.tuple(sym.tuple_range(len(self.keys)))
        ]
        return aggregate_replace(
            self,
            values_cw=res,
        )
    
    @triton_jit
    def clone(self):
        res_keys: tl.constexpr = sym.copy_constexpr_list(self.keys)
        res_values = [
            self.values_cw[i] 
            for i in tl.tuple(sym.tuple_range(len(self.keys)))
        ]
        return aggregate_replace(
            self,
            values_cw=res_values,
            keys=res_keys,
        )

    @triton_jit
    def is_empty_cw(self):
        return TritonConstexprField(len(self.keys) == 0)

    @triton_jit
    def removeitem(self, key: tl.constexpr):
        tl.static_assert(sym.is_name_in_names(key, self.keys), f"Key {key} not found in offset names {self.keys}.")
        key_bools = [
            TritonConstexprField(True)
            if self.keys[i] == key
            else TritonConstexprField(False)
            for i in tl.tuple(sym.tuple_range(len(self.keys)))
        ]
        res_offset_names = sym.filter_constexpr_lists_cw(self.keys, key_bools)
        res = filter_tuple_by_bool_tuple_cw(self.values_cw)
        return aggregate_replace(
            self,
            values_cw=res,
            keys=res_offset_names,
        )

    @triton_jit
    def getitem(self, key: tl.constexpr):
        tl.static_assert(sym.is_name_in_names(key, self.keys), f"Key {key} not found in offset names {self.keys}.")
        return self.values_cw[sym.get_name_in_names_idx(key, self.keys)]

    @triton_jit
    def getitem_with_default(self, key: tl.constexpr, default_cw = None):
        if sym.is_name_in_names(key, self.keys):
            return self.values_cw[sym.get_name_in_names_idx(key, self.keys)]
        else:
            return default_cw

    @triton_jit
    def query_values_cw_by_sym(self, query_sym: tl.constexpr, default_cw = None):
        block_dims_in_offset: tl.constexpr = sym.get_sym_axes_in_name_tuple(
            self.keys, query_sym
        )
        if sym.is_any_sym_in_names(query_sym, self.keys):
            offset_tuple = [
                self.values_cw[block_dims_in_offset[i]]
                if block_dims_in_offset[i] >= 0
                else default_cw
                for i in tl.tuple(sym.tuple_range(len(block_dims_in_offset)))
            ]
        else:
            offset_tuple = [
                default_cw
                for i in tl.tuple(sym.tuple_range(len(block_dims_in_offset)))
            ]
        return offset_tuple


    @triton_jit
    def get_subdict_by_sym(self, query_sym: tl.constexpr):
        tl.static_assert(
            sym.is_all_sym_in_names(query_sym, self.keys),
            f"All dims in query_sym {query_sym} must be in keys {self.keys}.",
        )

        return aggregate_replace(
            self,
            values_cw=self.query_values_cw_by_sym(query_sym, default_cw=TritonConstexprField(None)),
            keys=sym.get_shape_names_from_sym(query_sym),
        )


    @triton_jit
    def get_sub_named_offset_by_sym(self, query_sym: tl.constexpr):
        tl.static_assert(
            sym.is_all_sym_in_names(query_sym, self.keys),
            f"All dims in query_sym {query_sym} must be in keys {self.keys}.",
        )
        return self.filter_by_sym_include(query_sym)



    @triton_jit
    def _merge_replace_offsets(
        self,
        query_offset_names: tl.constexpr,
        query_offsets_cw: tl.tuple,
        check_unique: tl.constexpr = False,
    ):
        union_set: tl.constexpr = sym.merge_two_name_list(
            self.keys, query_offset_names, do_unique=True, check_unique=check_unique
        )
        union_offsets = [
            TritonConstexprField(None)
            if not sym.is_name_in_names(union_set[i], self.keys)
            else self.values_cw[
                sym.get_name_in_names_idx(union_set[i], self.keys)
            ]
            for i in tl.tuple(sym.tuple_range(len(union_set)))
        ]
        # replace
        union_offsets = [
            union_offsets[i]
            if not sym.is_name_in_names(union_set[i], query_offset_names)
            else query_offsets_cw[
                sym.get_name_in_names_idx(union_set[i], query_offset_names)
            ]
            for i in tl.tuple(sym.tuple_range(len(union_set)))
        ]
        return self.replace_offset(union_offsets, union_set)

    @triton_jit
    def merge_replace_offsets(
        self, query_offset_names: tl.constexpr, query_offsets_cw: tl.tuple, check_unique: tl.constexpr = False
    ):
        return self._merge_replace_offsets(
            query_offset_names, query_offsets_cw, check_unique=check_unique
        )

    @triton_jit
    def update(
        self, other: "Self", check_unique: tl.constexpr = False
    ):
        return self._merge_replace_offsets(
            other.keys, other.values_cw, check_unique=check_unique
        )

    @triton_jit
    def additem(
        self, key: tl.constexpr, val_cw, raise_err_if_exists: tl.constexpr = True
    ):
        named_offs = aggregate_replace(
            self,
            keys=sym.append_item_to_list(key, sym.empty_list()),
            values_cw=tl.tuple([val_cw]),
        )
        return self.update(named_offs, check_unique=raise_err_if_exists)

    @triton_jit
    def is_name_exists(self, name: tl.constexpr):
        return TritonConstexprField(sym.is_name_in_names(name, self.keys))

    @triton_jit
    def reorder(self, new_order: tl.constexpr):
        for order in tl.static_range(len(new_order)):
            tl.static_assert(
                sym.is_name_in_names(new_order[order], self.keys),
                f"All names in new_order {new_order} must be in keys {self.keys}.",
            )
        new_values_cw = [
            self.values_cw[sym.get_name_in_names_idx(new_order[i], self.keys)]
            for i in tl.tuple(sym.tuple_range(len(new_order)))
        ]
        return self.replace_offset(new_values_cw, new_order)

@triton_jit
def _cast_to_i32_if_needed(value_cw):
    if value_cw.is_constexpr:
        return value_cw
    else:
        value = value_cw.value
        if value.dtype == tl.int64:
            return TritonField(value.astype(tl.int32))
        else:
            return TritonField(value)


@triton_jit
def _cast_to_i64_if_needed(value_cw):
    if value_cw.is_constexpr:
        return value_cw
    else:
        value = value_cw.value
        if value.dtype == tl.int64:
            return TritonField(value.astype(tl.int64))
        else:
            return TritonField(value)

@aggregate
class TTOffsetDict(TTDict):
    def __repr__(self):
        return super().__repr__()

    @triton_jit
    def get_cleared_named_offsets(self):
        new_offs = [
            TritonConstexprField(0)
            for _ in tl.tuple(sym.tuple_range(len(self.values_cw)))
        ]
        return aggregate_replace(self, values_cw=new_offs, keys=self.keys)

    @triton_jit
    def make_offset_dim_mutable(self, dim_axis: tl.constexpr):
        """Call this when you want to directly increment offset in a loop."""
        res = [
            TritonField(get_scalar_tensor(self.values_cw[i].value))
            if i == dim_axis and self.values_cw[i].is_constexpr
            else self.values_cw[i]
            for i in tl.tuple(sym.tuple_range(len(self.keys)))
        ]

        return self.replace_offset(res, self.keys)

    @triton_jit
    def getitem_default_zero(self, key: tl.constexpr):
        if sym.is_name_in_names(key, self.keys):
            return self.values_cw[sym.get_name_in_names_idx(key, self.keys)]
        else:
            return TritonConstexprField(0)

    @triton_jit
    def get_subdict_by_sym_default_zero(self, query_sym: tl.constexpr):
        return aggregate_replace(
            self,
            values_cw=self.query_values_cw_by_sym(query_sym, default_cw=TritonConstexprField(0)),
            keys=sym.get_shape_names_from_sym(query_sym),
        )

    @triton_jit
    def _merge_add_offsets(
        self,
        query_offset_names: tl.constexpr,
        query_offsets_cw: tl.tuple,
        check_unique: tl.constexpr = False,
    ):
        union_set: tl.constexpr = sym.merge_two_name_list(
            self.keys, query_offset_names, do_unique=True, check_unique=check_unique,
        )
        union_offsets = [
            TritonConstexprField(0)
            if not sym.is_name_in_names(union_set[i], self.keys)
            else self.values_cw[
                sym.get_name_in_names_idx(union_set[i], self.keys)
            ]
            for i in tl.tuple(sym.tuple_range(len(union_set)))
        ]
        union_offsets = [
            union_offsets[i]
            if not sym.is_name_in_names(union_set[i], query_offset_names)
            else cwrapped_add(
                query_offsets_cw[
                    sym.get_name_in_names_idx(union_set[i], query_offset_names)
                ],
                union_offsets[i],
            )
            for i in tl.tuple(sym.tuple_range(len(union_set)))
        ]
        return self.replace_offset(union_offsets, union_set)

    @triton_jit
    def merge_add_offsets(
        self, query_offset_names: tl.constexpr, query_offsets_cw: tl.tuple
    ):
        return self._merge_add_offsets(
            query_offset_names, query_offsets_cw,
        )

    @triton_jit
    def _add_offsets(
        self, query_offset_names: tl.constexpr, query_offsets_cw: tl.tuple, query_must_exist: tl.constexpr = False
    ):
        if query_must_exist:
            for i in tl.static_range(len(query_offset_names)):
                tl.static_assert(
                    sym.is_name_in_names(query_offset_names[i], self.keys),
                    f"Key {query_offset_names[i]} not found in offset names {self.keys}.",
                )
        new_offsets = [
            self.values_cw[i]
            if not sym.is_name_in_names(self.keys[i], query_offset_names)
            else dispatch_value(
                query_offsets_cw[
                    sym.get_name_in_names_idx(self.keys[i], query_offset_names)
                ].value + self.values_cw[i].value
            )
            for i in tl.tuple(sym.tuple_range(len(self.values_cw)))
        ]
        return self.replace_offset(new_offsets, self.keys)

    @triton_jit
    def add_offsets_if_exists(
        self, query_offset_names: tl.constexpr, query_offsets_cw: tl.tuple
    ):
        return self._add_offsets(query_offset_names, query_offsets_cw, query_must_exist=False)

    @triton_jit
    def add_offsets_must_exists(
        self, query_offset_names: tl.constexpr, query_offsets_cw: tl.tuple
    ):
        return self._add_offsets(query_offset_names, query_offsets_cw, query_must_exist=True)

    @triton_jit
    def get_offsets_cw_by_sym_default_zero(self, shape_sym: tl.constexpr):
        sym_names: tl.constexpr = sym.get_shape_names_from_sym(shape_sym)
        return [
            self.getitem_default_zero(tl.constexpr(sym_names[i]))
            for i in tl.tuple(sym.tuple_range(len(sym_names)))
        ]


    @triton_jit
    def cast_to_i64_if_needed(self):
        values_cw = [
            _cast_to_i64_if_needed(self.values_cw[i])
            for i in tl.tuple(sym.tuple_range(len(self.values_cw)))
        ]
        return self.replace_offset(values_cw, self.keys)

@tl.core.builtin
def offsets(_semantic=None, **kwargs):
    values = []
    keys = list(kwargs.keys())
    for k, v in kwargs.items():
        if isinstance(v, (tl.constexpr, str, int, float, bool, NoneType)):
            values.append(TritonConstexprField(v))
        elif isinstance(v, (TritonField, TritonConstexprField)):
            values.append(v)
        else:
            values.append(TritonField(v))
    named_offs = TTOffsetDict(
        tl.tuple(values),
        tl.constexpr(keys),
    )
    return named_offs

@tl.core.builtin
def raw_ttdict(_semantic=None, **kwargs):
    values = []
    keys = list(kwargs.keys())
    for k, v in kwargs.items():
        if isinstance(v, (tl.constexpr, str, int, float, bool, NoneType)):
            values.append(TritonConstexprField(v))
        elif isinstance(v, (TritonField, TritonConstexprField)):
            values.append(v)
        else:
            values.append(TritonField(v))
    named_offs = TTDict(
        tl.tuple(values),
        tl.constexpr(keys),
    )
    return named_offs

