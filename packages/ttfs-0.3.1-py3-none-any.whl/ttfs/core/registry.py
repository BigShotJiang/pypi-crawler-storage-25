import inspect
from typing import Any, Callable, Dict, Hashable, List, Optional, Generic, Type, TypeVar, Union

T = TypeVar("T", bound=Union[type, Callable])

T_value = TypeVar("T_value")

class HashableRegistry(Generic[T_value]):

    def __init__(self):
        self.global_dict: Dict[Hashable, T_value] = {}

    def register(self, key: Hashable):

        def wrapper(func: T_value) -> T_value:
            self.global_dict[key] = func
            return func

        return wrapper

    def __contains__(self, key: Hashable):
        return key in self.global_dict

    def __getitem__(self, key: Hashable):
        return self.global_dict[key]

    def items(self):
        yield from self.global_dict.items()
