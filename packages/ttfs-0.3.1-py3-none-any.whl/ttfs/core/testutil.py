import contextvars 
from typing import Any, Callable, Optional
import contextlib 
import triton.language as tl 
from triton._filecheck import run_parser as _run_parser
from ttfs.core.aggtype import constexpr_function
from ttfs.core.mp import TritonConstexprField, TritonField, workaround_ignore_cache_record

from triton.backends.compiler import GPUTarget

BLACKWELL_TARGET = GPUTarget("cuda", 100, 32)
HOPPER_TARGET = GPUTarget("cuda", 90, 32)
AMPERE_TARGET = GPUTarget("cuda", 80, 32)

class TritonStaticParseContext:
    def __init__(self):
        self.store: dict[str, Any] = {}

_TRITON_STATIC_PARSE_CTX: contextvars.ContextVar[Optional[TritonStaticParseContext]] = contextvars.ContextVar("_TRITON_STATIC_PARSE_CTX", default=None)

def get_triton_static_parse_ctx() -> Optional[TritonStaticParseContext]:
    ctx = _TRITON_STATIC_PARSE_CTX.get()
    if ctx is None:
        return None 
    return ctx

@contextlib.contextmanager
def triton_static_parse_ctx():
    ctx = TritonStaticParseContext()
    token = _TRITON_STATIC_PARSE_CTX.set(ctx)
    try:
        yield ctx
    finally:
        _TRITON_STATIC_PARSE_CTX.reset(token)

@workaround_ignore_cache_record
def _try_store_debug_value(key: str, value: Any):
    ctx = get_triton_static_parse_ctx()
    if ctx is not None:
        ctx.store[key] = value

@constexpr_function
def store_debug_value(key: str, value: Any):
    if isinstance(value, (TritonField, TritonConstexprField)):
        value = value.value
    if isinstance(value, tl.constexpr):
        value = value.value
    _try_store_debug_value(key, value)


def run_triton_debug_parser(kernel_fn, args=(), kwargs={}):
    with triton_static_parse_ctx() as ctx:
        _run_parser(kernel_fn, args, kwargs, target=BLACKWELL_TARGET)
    return ctx.store

# TODO add a fast jit function runner for unit tests.