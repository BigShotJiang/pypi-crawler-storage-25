import logging
import os
from typing import Final

from rich.logging import RichHandler


TTFS_LOG_LEVEL_ENV: Final = "TTFS_LOG_LEVEL"
_DEFAULT_LOG_LEVEL: Final = logging.WARNING
_LOGGER_NAME: Final = "ttfs"
_LOG_LEVEL_NAMES: Final = {
	logging.CRITICAL: "CRITICAL",
	logging.ERROR: "ERROR",
	logging.WARNING: "WARNING",
	logging.INFO: "INFO",
	logging.DEBUG: "DEBUG",
	logging.NOTSET: "NOTSET",
}


def _parse_log_level(level: str | int | None) -> int:
	if level is None:
		return _DEFAULT_LOG_LEVEL
	if isinstance(level, int):
		return level

	normalized = level.strip()
	if not normalized:
		return _DEFAULT_LOG_LEVEL
	if normalized.isdigit():
		return int(normalized)

	normalized = normalized.upper()
	if normalized == "WARN":
		normalized = "WARNING"

	parsed = logging.getLevelNamesMapping().get(normalized)
	if parsed is not None:
		return parsed

	raise ValueError(f"invalid log level: {level}")


def _create_handler() -> logging.Handler:
	handler = RichHandler(rich_tracebacks=True, show_path=False, markup=False)
	handler.setFormatter(logging.Formatter("%(message)s"))
	setattr(handler, "_ttfs_handler", True)
	return handler


def _get_base_logger() -> logging.Logger:
	base_logger = logging.getLogger(_LOGGER_NAME)
	if not any(getattr(handler, "_ttfs_handler", False) for handler in base_logger.handlers):
		base_logger.addHandler(_create_handler())
	base_logger.propagate = False
	return base_logger


def configure_logger(level: str | int | None = None) -> logging.Logger:
	base_logger = _get_base_logger()
	raw_level = os.getenv(TTFS_LOG_LEVEL_ENV) if level is None else level

	try:
		resolved_level = _parse_log_level(raw_level)
	except ValueError:
		resolved_level = _DEFAULT_LOG_LEVEL
		base_logger.setLevel(resolved_level)
		base_logger.warning(
			"Invalid %s=%r; falling back to %s",
			TTFS_LOG_LEVEL_ENV,
			raw_level,
			_LOG_LEVEL_NAMES.get(resolved_level, str(resolved_level)),
		)
		return base_logger

	base_logger.setLevel(resolved_level)
	return base_logger


def get_logger(name: str | None = None) -> logging.Logger:
	configure_logger()
	if not name or name == _LOGGER_NAME:
		return logging.getLogger(_LOGGER_NAME)
	if name.startswith(f"{_LOGGER_NAME}."):
		return logging.getLogger(name)
	return logging.getLogger(f"{_LOGGER_NAME}.{name}")


logger = get_logger()


__all__ = [
	"TTFS_LOG_LEVEL_ENV",
	"configure_logger",
	"get_logger",
	"logger",
]

