import dataclasses
from typing import Any, Self

import triton.language as tl
from typing_extensions import Annotated

from ttfs.core.aggtype import (
    FieldMeta,
    TritonAggFieldAccessor,
    TritonAggFlatField,
    base_aggregate_value,
    aggregate,
    constexpr_function,
    get_scalar_tensor,
    triton_jit,
    triton_jit_kernel,
)
from ttfs.core.mp import (
    TritonConstexprField,
    TritonField,
    TritonFieldBase,
    cwrapped_add,
    filter_tuple_by_bool_tuple_cw,
    filter_tuple_by_bools,
    is_gluon,
    dispatch_value,
)
from ttfs.core import sym



@aggregate
class TTArray(base_aggregate_value):
    values_cw: tl.tuple

    @constexpr_function
    def __len__(self) -> int:
        return len(self.values_cw)

    # @triton_jit
    # def get(self, idx: tl.constexpr):
    #     tl.static_assert(idx , f"Key {key} not found in offset names {self.keys}.")
    #     return self.values_cw[sym.get_name_in_names_idx(key, self.keys)]
