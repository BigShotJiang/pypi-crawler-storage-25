import ast

from regex import R

from triton import JITFunction
from ttfs.core.sym import workaround_ignore_cache_record
import inspect
from .aggtype import (
    TRITON_AGG_FLATTEN_META_FIELD,
    TRITON_AGG_META_FIELD,
    extract_annotated_type_and_meta,
    gluon_jit,
    gluon_builtin,
    is_aggregate_type,
    triton_builtin,
    constexpr_function,
    aggregate,
    triton_jit,
    base_aggregate_value,
    _AGG_INIT_CONTEXT_VAR,
)
from triton.experimental.gluon import language as gl
import triton.language as tl

import dataclasses
import torch
import triton
import inspect
from typing import get_type_hints, Any, TypeVar, Union
from . import logger 

_T = TypeVar("_T")

@aggregate
class TritonFieldBase(base_aggregate_value):
    pass


@aggregate
class TritonField(TritonFieldBase):
    value: Any
    is_constexpr: tl.constexpr = False

    def __repr__(self):
        return f"TTField({self.value})"


@aggregate
class TritonConstexprField(TritonFieldBase):
    value: tl.constexpr
    is_constexpr: tl.constexpr = True

    def __repr__(self):
        return f"TTConstField({self.value})"


@gluon_jit
def get_all_fields_with_type_gluon_v1(obj, agg_type: gl.constexpr) -> tl.tuple:
    all_field_keys: gl.constexpr = get_all_field_keys_with_type(obj, agg_type)
    # gl.static_print("!", all_field_keys)
    return tl.tuple([_get_field_gluon(obj, k) for k in tl.tuple(all_field_keys)])


@gluon_builtin
def get_all_fields_with_type_gluon(
    obj,
    agg_type,
    _semantic=None,
) -> tl.tuple:
    all_field_keys = __get_all_field_keys_with_type(obj, agg_type)
    # gl.static_print("!", all_field_keys)
    return tl.tuple([getattr(obj, k.value) for k in all_field_keys])


@triton_builtin
def get_all_fields_with_type_triton(
    obj,
    agg_type,
    _semantic=None,
) -> tl.tuple:
    all_field_keys = __get_all_field_keys_with_type(obj, agg_type)
    # gl.static_print("!", all_field_keys)
    return tl.tuple([getattr(obj, k.value) for k in all_field_keys])


@gluon_builtin
def replace_all_fields_with_type_gluon(
    obj: _T, agg_type, fields: tl.tuple, _semantic=None
) -> _T:
    all_field_keys = __get_all_field_keys_with_type(obj, agg_type)
    kv = {k.value: v for k, v in zip(all_field_keys, fields.values)}
    return dataclasses.replace(obj, **kv)


@triton_builtin
def replace_all_fields_with_type_triton(
    obj: _T, agg_type, fields: tl.tuple, _semantic=None
) -> _T:
    all_field_keys = __get_all_field_keys_with_type(obj, agg_type)
    kv = {k.value: v for k, v in zip(all_field_keys, fields.values)}
    return dataclasses.replace(obj, **kv)


@triton_builtin
def replace_fields_triton(
    obj: _T, field_keys, fields_cw: tl.tuple, _semantic=None
) -> _T:
    field_keys = tl.core._unwrap_if_constexpr(field_keys)
    assert len(field_keys) == len(fields_cw)
    assert is_aggregate_type(type(obj)), f"Expected aggregate type but got {type(obj)}"
    all_field_keys = set([f.name for f in dataclasses.fields(type(obj))])
    for k in field_keys:
        assert k in all_field_keys, f"Field {k} not found in aggregate type {type(obj)}"
    kv = {k: v.value for k, v in zip(field_keys, fields_cw.values)}
    return dataclasses.replace(obj, **kv)


@gluon_builtin
def replace_fields_gluon(
    obj: _T, field_keys, fields_cw: tl.tuple, _semantic=None
) -> _T:
    field_keys = tl.core._unwrap_if_constexpr(field_keys)
    assert len(field_keys) == len(fields_cw)
    assert is_aggregate_type(type(obj)), f"Expected aggregate type but got {type(obj)}"
    all_field_keys = set([f.name for f in dataclasses.fields(type(obj))])
    for k in field_keys:
        assert k in all_field_keys, f"Field {k} not found in aggregate type {type(obj)}"
    kv = {k: v.value for k, v in zip(field_keys, fields_cw.values)}
    return dataclasses.replace(obj, **kv)


@constexpr_function
def _get_field_is_constexpr(obj, field):
    field = tl.core._unwrap_if_constexpr(field)

    res = getattr(obj, field)
    res_is_constexpr = isinstance(res, tl.constexpr)

    return res_is_constexpr


@constexpr_function
def has_field(obj, field):
    field = tl.core._unwrap_if_constexpr(field)
    return hasattr(obj, field)


@constexpr_function
def all_fields_is_constexpr(obj, fields):
    fields = tl.core._unwrap_if_constexpr(fields)
    for field in fields:
        res = getattr(obj, field)
        res_is_constexpr = isinstance(res, tl.constexpr)
        if not res_is_constexpr:
            return False

    return True


@workaround_ignore_cache_record
def __get_all_field_keys_with_type(obj, agg_type):
    all_types = get_type_hints(type(obj), include_extras=True)
    res: list[gl.constexpr] = []
    for k, v in all_types.items():
        v, _ = extract_annotated_type_and_meta(v)
        if inspect.isclass(v) and issubclass(v, agg_type):
            res.append(gl.constexpr(k))
    return tuple(res)


@constexpr_function
def get_all_field_keys_with_type(obj, agg_type):
    return __get_all_field_keys_with_type(obj, agg_type)


@constexpr_function
def filter_constexpr_fields(obj, fields):
    fields = tl.core._unwrap_if_constexpr(fields)
    res_list: list[str] = []
    for field in fields:
        res = getattr(obj, field)
        res_is_constexpr = isinstance(res, tl.constexpr)
        if res_is_constexpr:
            res_list.append(field)

    return res_list

@workaround_ignore_cache_record
def _get_constexpr_field_dict_impl(obj):
    all_field_keys = set([f.name for f in dataclasses.fields(type(obj))])
    res_dict: dict[str, Any] = {}
    for field in all_field_keys:
        res = getattr(obj, field)
        res_is_constexpr = isinstance(res, tl.constexpr)
        if res_is_constexpr:
            res_dict[field] = res.value

    return res_dict


@constexpr_function
def get_constexpr_field_dict(obj):
    return _get_constexpr_field_dict_impl(obj)

@constexpr_function
def filter_non_constexpr_fields(obj, fields):
    fields = tl.core._unwrap_if_constexpr(fields)
    res_list: list[str] = []
    for field in fields:
        res = getattr(obj, field)
        res_is_constexpr = isinstance(res, tl.constexpr)
        if not res_is_constexpr:
            res_list.append(field)

    return res_list


@constexpr_function
def is_constexpr(obj):
    res_is_constexpr = isinstance(obj, (tl.constexpr, str, int, float, bool))
    return res_is_constexpr


@gluon_builtin
def _get_field_gluon(obj, field, *, _semantic=None):
    field = tl.core._unwrap_if_constexpr(field)
    res = getattr(obj, field)
    res_is_constexpr = isinstance(res, tl.constexpr)
    if res_is_constexpr:
        return tl.constexpr(res)
    else:
        return res


@triton_builtin
def _get_field_triton(obj, field, *, _semantic=None):
    field = tl.core._unwrap_if_constexpr(field)
    res = getattr(obj, field)
    res_is_constexpr = isinstance(res, tl.constexpr)
    if res_is_constexpr:
        return tl.constexpr(res)
    else:
        return res


@workaround_ignore_cache_record
def get_dcls_fields(obj):
    return dataclasses.fields(obj)


@gluon_builtin
def _get_field_type_gluon(dcls, field, *, _semantic=None):
    field = tl.core._unwrap_if_constexpr(field)
    agg_fields = getattr(dcls, TRITON_AGG_FLATTEN_META_FIELD)
    return tl.constexpr(agg_fields[field].type)


@tl.core.builtin
def _get_field_type_triton(dcls, field, *, _semantic=None):
    field = tl.core._unwrap_if_constexpr(field)
    agg_fields = getattr(dcls, TRITON_AGG_FLATTEN_META_FIELD)
    return tl.constexpr(agg_fields[field].type)


@gluon_jit
def dispatch_value(value):
    if is_constexpr(value):
        return TritonConstexprField(value, True)
    else:
        return TritonField(value, False)


@gluon_jit
def get_field_gluon(obj, field: gl.constexpr) -> Any:
    res_is_c: tl.constexpr = _get_field_is_constexpr(obj, field)

    if res_is_c:
        res: tl.constexpr = _get_field_gluon(obj, field)
        return TritonConstexprField(res, True)
    else:
        res = _get_field_gluon(obj, field)
        return TritonField(res, False)


@triton_jit
def get_field_triton(obj, field: tl.constexpr) -> Any:
    res_is_c: tl.constexpr = _get_field_is_constexpr(obj, field)

    if res_is_c:
        res: tl.constexpr = _get_field_triton(obj, field)
        return TritonConstexprField(res, True)
    else:
        res = _get_field_triton(obj, field)
        return TritonField(res, False)


@gluon_jit
def get_field(obj, field: gl.constexpr):
    res_is_c: tl.constexpr = _get_field_is_constexpr(obj, field)

    if res_is_c:
        if is_gluon():
            res: tl.constexpr = _get_field_gluon(obj, field)
        else:
            res: tl.constexpr = _get_field_triton(obj, field)
        return TritonConstexprField(res, True)
    else:
        if is_gluon():
            res = _get_field_gluon(obj, field)
        else:
            res = _get_field_triton(obj, field)
        return TritonField(res, False)


_TORCH_TO_GL_DTYPE: dict[torch.dtype, gl.dtype] = {
    torch.int8: gl.int8,
    torch.uint8: gl.uint8,
    torch.int16: gl.int16,
    torch.uint16: gl.uint16,
    torch.int32: gl.int32,
    torch.uint32: gl.uint32,
    torch.int64: gl.int64,
    torch.uint64: gl.uint64,
    torch.float16: gl.float16,
    torch.bfloat16: gl.bfloat16,
    torch.float32: gl.float32,
    torch.float8_e4m3fn: gl.float8e4nv,
    torch.float8_e5m2: gl.float8e5,
    torch.float8_e4m3fnuz: gl.float8e4b8,
}

_GL_TO_TORCH_DTYPE: dict[gl.dtype, torch.dtype] = {v: k for k, v in _TORCH_TO_GL_DTYPE.items()}
def torch_dtype_to_gluon(dtype: torch.dtype) -> gl.dtype:
    if dtype not in _TORCH_TO_GL_DTYPE:
        raise ValueError(f"Unsupported torch dtype: {dtype}")
    return _TORCH_TO_GL_DTYPE[dtype]

def gluon_dtype_to_torch(dtype: gl.dtype) -> torch.dtype:
    if dtype not in _GL_TO_TORCH_DTYPE:
        raise ValueError(f"Unsupported gluon dtype: {dtype}({type(dtype)})")
    return _GL_TO_TORCH_DTYPE[dtype]

@tl.core.builtin
def is_gluon(_semantic=None):
    # https://github.com/sublinear-systems/triton-utils/blob/master/utils.py#L106
    return isinstance(
        _semantic, triton.experimental.gluon.language._semantic.GluonSemantic
    )


@tl.core.builtin
def get_num_warps(_semantic=None, _generator=None):
    """
    Returns the number of warps that execute the current context, including in warp-specialized regions.
    """
    if _generator.caller_context is not None:
        # assert isinstance(generator.caller_context, GluonCallerContext)
        return gl.constexpr(_generator.caller_context.num_warps)
    return gl.constexpr(_semantic.builder.options.num_warps)

@workaround_ignore_cache_record
def get_num_warps_in_init():
    """
    Returns the number of warps that execute the current context, including in warp-specialized regions.
    """
    ctx = _AGG_INIT_CONTEXT_VAR.get()
    assert ctx is not None, "get_num_warps_in_init can only be called within aggregate __init__ or __post_init__"
    _generator = ctx.generator
    _semantic = ctx.semantic
    if _generator.caller_context is not None:
        # assert isinstance(generator.caller_context, GluonCallerContext)
        return gl.constexpr(_generator.caller_context.num_warps)
    return gl.constexpr(_semantic.builder.options.num_warps)

@constexpr_function
def get_field_type(dcls, field):
    field = tl.core._unwrap_if_constexpr(field)
    assert isinstance(field, str)
    field_parts = field.split(".")
    for part in field_parts:
        # assert is_aggregate_type(dcls), f"Expected aggregate type but got {dcls}"
        agg_fields = getattr(dcls, TRITON_AGG_META_FIELD)
        dcls = agg_fields[part].type
    return dcls


@triton_builtin
def filter_tuple_by_bools(inp, conds, *, _semantic=None):
    conds = tl.core._unwrap_if_constexpr(conds)
    return tl.tuple([v for v, c in zip(inp.values, conds) if c])

@triton_builtin
def filter_tuple_by_bool_tuple_cw(inp, conds, *, _semantic=None):
    return tl.tuple([v for v, c in zip(inp.values, conds.values) if c.value])

@triton_builtin
def filter_tuple_cw_is_not_None(inp, *, _semantic=None):
    return tl.tuple([v for v in inp.values if (not v.is_constexpr or (v.is_constexpr and v.value.value is not None))])

@triton_builtin
def merge_two_tuple(
    inp1,
    inp2,
    _semantic=None,
) -> tl.tuple:

    return tl.tuple([*inp1, *inp2])


@triton_builtin
def tuple_to_cwrapper(inp_tuple, *, _semantic=None):
    res = []
    for val in inp_tuple:
        res_is_constexpr = isinstance(val, (tl.constexpr, str, int, float, bool))
        if res_is_constexpr:
            res.append(TritonConstexprField(val, True))
        else:
            res.append(TritonField(val, False))
    return tl.tuple(res)


@triton_jit
def cwrapped_add(lfs, rfs) -> Any:
    return dispatch_value(lfs.value + rfs.value)

@triton_jit
def cwrapped_mul(lfs, rfs) -> Any:
    return dispatch_value(lfs.value * rfs.value)

@triton_jit
def cwrapped_sub(lfs, rfs) -> Any:
    return dispatch_value(lfs.value - rfs.value)

@constexpr_function
def _tuple_range(length):
    return tuple(i for i in range(length))


@triton_jit
def tuple_static_range(length: tl.constexpr):
    # TODO: currently this function can't keep constexpr of iter.
    return tl.tuple([i for i in tl.tuple(_tuple_range(length))])

@triton_jit
def tuple_static_range_cw(length: tl.constexpr):
    return tl.tuple([TritonConstexprField(i) for i in tl.tuple(_tuple_range(length))])

@triton_jit
def replace_tuple_by_idx(tp, new_val, idx: tl.constexpr):
    return [
        tp[i] if i != idx else new_val
        for i in tl.tuple(_tuple_range(len(tp)))
    ]

@tl.core.builtin
def rich_print(*val, _semantic=None):
    vals = (tl.core._unwrap_if_constexpr(v) for v in val)
    import rich 
    rich.print(*vals)

@tl.core.builtin
def logger_warning(msg, *val, _semantic=None):
    msg = tl.core._unwrap_if_constexpr(msg)
    val = [tl.core._unwrap_if_constexpr(v) for v in val]
    logger.warning(msg, *val)

@tl.core.builtin
def logger_info(msg, *val, _semantic=None):
    msg = tl.core._unwrap_if_constexpr(msg)
    val = [tl.core._unwrap_if_constexpr(v) for v in val]

    logger.info(msg, *val)

@tl.core.builtin
def logger_error(msg, *val, _semantic=None):
    msg = tl.core._unwrap_if_constexpr(msg)
    val = [tl.core._unwrap_if_constexpr(v) for v in val]

    logger.error(msg, *val)
    
@gluon_jit
def get_scalar_tensor(val) -> tl.tensor:
    return tl.core.to_tensor(val)

@constexpr_function
def format_string(v, *args):
    return v.format(*args)


@tl.core.builtin
def get_cur_jit_path_lineno(frame_cnt: int, _semantic=None):
    frame_cnt = tl.core._unwrap_if_constexpr(frame_cnt)
    assert frame_cnt > 0, "frame_cnt should be greater than 0"
    cur_frame = inspect.currentframe()

    cnt = 0

    while cur_frame is not None:
        # find frame name named "call_JitFunction"
        if cur_frame.f_code.co_name == "call_JitFunction":
            cnt += 1
            if cnt == frame_cnt:
                code_generator = cur_frame.f_locals["self"]
                # jit_fn: JITFunction = cur_frame.f_locals["fn"]
                jit_fn: JITFunction = code_generator.jit_fn

                path = inspect.getfile(jit_fn.fn)
                # print(ast.unparse(code_generator.cur_node))
                return tl.constexpr((path, code_generator.cur_node.lineno + jit_fn.starting_line_number))
        cur_frame = cur_frame.f_back
    del cur_frame
    return tl.constexpr(("unknown", -1)) 

@tl.core.builtin
def get_warp_partition_idx_and_name(_semantic=None):
    """WARNING: this function must be called in top-level function of each warp partition function.
    """
    cur_frame = inspect.currentframe()
    cnt = 0
    while cur_frame is not None:
        # find frame name named "call_JitFunction"
        if cur_frame.f_code.co_name == "call_JitFunction":
            cnt += 1

        if cur_frame.f_code.co_name == "warp_specialize" and cur_frame.f_code.co_filename.endswith("_semantic.py"):
            assert cnt == 1, "you must call this function in top-level function of each warp partition function"
            is_default = "partitions_op" not in cur_frame.f_locals
            if is_default:
                jit_fn: JITFunction = cur_frame.f_locals["default_partition"]
                part_idx = 0
            else:
                jit_fn: JITFunction = cur_frame.f_locals["func"]
                part_idx: JITFunction = cur_frame.f_locals["i"] + 1
            return tl.constexpr((part_idx, jit_fn.fn.__name__))
        cur_frame = cur_frame.f_back
    del cur_frame
    return tl.constexpr((0, "default", )) 
