"""Python port of the core functionality of Triton's ``LinearLayout`` utility.

The original implementation lives in ``include/triton/Tools/LinearLayout.h`` and
``lib/Tools/LinearLayout.cpp``.  This module offers a lightweight Python-native
reimplementation that mirrors the data model and the most commonly used
operations so that Python tooling can reason about layouts without depending on
C++ bindings.
"""

from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass
from typing import Any, Dict, Iterable, Iterator, List, Mapping, MutableMapping, Optional, Sequence, Set, Tuple, Union

import triton.experimental.gluon.language as gl


DimName = str
BasisVector = List[int]
BasesT = Mapping[DimName, Sequence[Sequence[int]]]
OutDimsT = Union[Mapping[DimName, int], Sequence[Tuple[DimName, int]]]

class LinearLayoutError(ValueError):
    """Raised when an invalid linear layout configuration is detected."""


def _is_power_of_two(value: int) -> bool:
    return value > 0 and value & (value - 1) == 0


def _log2_power_of_two(value: int) -> int:
    if not _is_power_of_two(value):
        raise LinearLayoutError(f"Expected a power-of-two value, got {value}")
    return value.bit_length() - 1


def _next_power_of_two(value: int) -> int:
    if value <= 1:
        return 1
    return 1 << (value - 1).bit_length()


def _normalize_dim_name(dim: Union[str, object]) -> DimName:
    return dim if isinstance(dim, str) else str(dim)


def _normalize_dim_sequence(dims: Sequence[Union[str, object]]) -> List[DimName]:
    return [_normalize_dim_name(dim) for dim in dims]


def _assert_dims_subset(candidate: Sequence[DimName], reference: Sequence[DimName], *, which: str) -> None:
    candidate_set = set(candidate)
    reference_set = set(reference)
    if not candidate_set.issubset(reference_set):
        missing = ", ".join(sorted(candidate_set - reference_set))
        raise LinearLayoutError(f"{which.capitalize()} dimensions {{{missing}}} are not present in the layout")


def _supremum(x: Sequence[DimName], y: Sequence[DimName]) -> List[DimName]:
    seen: "OrderedDict[DimName, None]" = OrderedDict()
    pos_x = {dim: idx for idx, dim in enumerate(x)}
    pos_y = {dim: idx for idx, dim in enumerate(y)}
    i = j = 0
    inf = float("inf")

    def advance(seq: Sequence[DimName], index: int) -> int:
        while index < len(seq) and seq[index] in seen:
            index += 1
        return index

    while i < len(x) or j < len(y):
        i = advance(x, i)
        j = advance(y, j)
        if i >= len(x) and j >= len(y):
            break
        if i < len(x) and j < len(y) and x[i] == y[j]:
            if pos_y[x[i]] < j:
                raise LinearLayoutError("Supremum does not exist")
            seen.setdefault(x[i], None)
            i += 1
            j += 1
            continue
        cand_x = inf
        cand_y = inf
        if i < len(x):
            dim_x = x[i]
            if dim_x in pos_y and pos_y[dim_x] >= j:
                cand_x = pos_y[dim_x]
        if j < len(y):
            dim_y = y[j]
            if dim_y in pos_x and pos_x[dim_y] >= i:
                cand_y = pos_x[dim_y]
        if i < len(x) and cand_x == inf:
            seen.setdefault(x[i], None)
            i += 1
            continue
        if j < len(y) and cand_y == inf:
            seen.setdefault(y[j], None)
            j += 1
            continue
        if cand_x <= cand_y:
            dim_x = x[i]
            if pos_y.get(dim_x, j) < j:
                raise LinearLayoutError("Supremum does not exist")
            seen.setdefault(dim_x, None)
            i += 1
        else:
            dim_y = y[j]
            if pos_x.get(dim_y, i) < i:
                raise LinearLayoutError("Supremum does not exist")
            seen.setdefault(dim_y, None)
            j += 1
    return list(seen.keys())


def _concat_matrices(A: "LinearLayout", B: "LinearLayout") -> List[int]:
    if A.get_total_out_dim_size_log2() < B.get_total_out_dim_size_log2():
        raise LinearLayoutError("concat_matrices requires A to dominate B's output rank")
    num_cols_a = A.get_total_in_dim_size_log2()
    concat = A._build_matrix()
    b_matrix = B._build_matrix()
    row_a = 0
    row_b = 0
    for out_dim, out_dim_size in A.get_out_dims():
        log_a = _log2_power_of_two(out_dim_size)
        if not B.has_out_dim(out_dim):
            raise LinearLayoutError(f"Layout B lacks output dimension '{out_dim}' for concatenation")
        log_b = _log2_power_of_two(B.get_out_dim_size(out_dim))
        for r in range(log_a):
            if r < log_b:
                concat[row_a] |= b_matrix[row_b] << num_cols_a
                row_b += 1
            row_a += 1
    return concat


def _lstsq(A: "LinearLayout", B: "LinearLayout") -> "LinearLayout":
    num_rows = A.get_total_out_dim_size_log2()
    if num_rows < B.get_total_out_dim_size_log2():
        raise LinearLayoutError("Incompatible output shapes for least-squares solve")
    num_cols_a = A.get_total_in_dim_size_log2()
    num_cols_b = B.get_total_in_dim_size_log2()
    combined = _concat_matrices(A, B)
    combined_rref, _ = LinearLayout._binary_rref(combined, num_rows, num_cols_a + num_cols_b)

    pivot_rows = [-1] * num_cols_a
    for col in range(num_cols_a):
        for row in range(num_rows):
            if (combined_rref[row] >> col) & 1:
                pivot_rows[col] = row
                break

    ret_mat = [0] * num_cols_a
    for col in range(num_cols_a):
        row = pivot_rows[col]
        ret_mat[col] = 0 if row == -1 else (combined_rref[row] >> num_cols_a)

    if not A.get_in_dim_names():
        raise LinearLayoutError("Cannot perform least-squares solve on empty layout")
    in_dim_1d = A.get_in_dim_names()[0]
    out_dim_1d = A.get_out_dim_names()[0]

    ret_bases: "OrderedDict[DimName, List[BasisVector]]" = OrderedDict()
    vectors: List[BasisVector] = []
    for c in range(num_cols_b):
        basis = 0
        for r in range(num_cols_a):
            basis |= ((ret_mat[r] >> c) & 1) << r
        vectors.append([basis])
    ret_bases[in_dim_1d] = vectors

    flattened = LinearLayout(
        ret_bases,
        [(out_dim_1d, A.get_total_in_dim_size())],
        require_surjective=False,
    )

    ret_in_dims = [(dim, B.get_in_dim_size(dim)) for dim in B.get_in_dim_names()]
    ret_out_dims = [(dim, A.get_in_dim_size(dim)) for dim in A.get_in_dim_names()]
    return flattened.reshape_ins(ret_in_dims).reshape_outs(ret_out_dims)


def _square_sublayout_is_identity(layout: "LinearLayout", dim_names: Sequence[DimName]) -> bool:
    dim_names = _normalize_dim_sequence(dim_names)
    if not dim_names:
        return True
    sub = layout.sublayout(dim_names, dim_names)
    for dim in dim_names:
        if layout.get_in_dim_size(dim) != layout.get_out_dim_size(dim):
            return False
    sub = sub.flatten_ins().flatten_outs()
    if not sub.get_in_dim_names() or not sub.get_out_dim_names():
        return True
    in_dim = sub.get_in_dim_names()[0]
    bases = sub.get_bases()[in_dim]
    for idx, basis in enumerate(bases):
        if basis[0] != (1 << idx):
            return False
    return True


def divide_left(A: "LinearLayout", B: "LinearLayout") -> Optional["LinearLayout"]:
    return A.divide_left(B)


def divide_right(A: "LinearLayout", B: "LinearLayout") -> Optional["LinearLayout"]:
    return A.divide_right(B)


def standard_out_dim_names(rank: int) -> List[DimName]:
    return [f"dim{i}" for i in range(rank)]


def identity_standard_nd(
    in_dim_name: DimName,
    shape: Sequence[int],
    order: Sequence[int],
) -> "LinearLayout":
    if len(shape) != len(order):
        raise LinearLayoutError("identity_standard_nd expects shape and order to match in length")
    dim_names = standard_out_dim_names(len(shape))
    layout = LinearLayout.empty()
    for dim_index in order:
        size = int(shape[dim_index])
        if size <= 0:
            raise LinearLayoutError("identity_standard_nd requires positive sizes")
        layout = layout * LinearLayout.identity1d(size, in_dim_name, dim_names[dim_index])
    return layout


def _ordered_shape_map(
    layout: "LinearLayout",
    shape: Mapping[DimName, int],
) -> "OrderedDict[DimName, int]":
    ordered: "OrderedDict[DimName, int]" = OrderedDict()
    for dim in layout.get_out_dim_names():
        if dim not in shape:
            raise LinearLayoutError(f"Missing size for output dimension '{dim}'")
        ordered[dim] = int(shape[dim])
    return ordered


def ensure_layout_not_smaller_than(
    layout: "LinearLayout",
    shape: Mapping[DimName, int],
) -> "LinearLayout":
    if layout.get_num_out_dims() == 0:
        return layout
    shape_map = _ordered_shape_map(layout, shape)
    in_dim_names = layout.get_in_dim_names()
    if not in_dim_names:
        raise LinearLayoutError("Layout must have at least one input dimension")
    minor_in_dim = in_dim_names[0]
    result = layout
    for dim in layout.get_out_dim_names():
        actual = layout.get_out_dim_size(dim)
        desired = shape_map[dim]
        if desired < actual and desired != 0 and actual % desired != 0:
            raise LinearLayoutError(
                f"Cannot shrink dimension '{dim}' from {actual} to {desired} without losing data"
            )
        if desired == actual:
            continue
        if desired % actual != 0:
            multiplier = 1
        else:
            multiplier = desired // actual
        result = result * LinearLayout.identity1d(multiplier, minor_in_dim, dim)
    return result


def ensure_layout_not_larger_than(
    layout: "LinearLayout",
    shape: Mapping[DimName, int],
    *,
    broadcast_registers: bool = True,
) -> "LinearLayout":
    if layout.get_num_out_dims() == 0:
        return layout
    shape_map = _ordered_shape_map(layout, shape)
    bases = layout.get_bases()
    out_dim_names = list(layout.get_out_dim_names())
    register_dim = "register"
    broadcasted_indices: Set[int] = set()

    for out_index, out_dim in enumerate(out_dim_names):
        actual_size = layout.get_out_dim_size(out_dim)
        desired_size = shape_map[out_dim]
        if actual_size <= desired_size:
            continue
        if actual_size % desired_size != 0:
            raise LinearLayoutError(
                f"Cannot reduce dimension '{out_dim}' from {actual_size} to {desired_size}"
            )
        sorted_bases: List[Tuple[DimName, int, int]] = []
        for in_dim, basis_vectors in bases.items():
            for basis_index, basis in enumerate(basis_vectors):
                value = basis[out_index]
                if value == 0:
                    continue
                if value & (value - 1):
                    raise LinearLayoutError("Expected power-of-two basis value")
                sorted_bases.append((in_dim, basis_index, value))
        sorted_bases.sort(key=lambda item: item[2], reverse=True)
        for in_dim, basis_index, _ in sorted_bases:
            if actual_size <= desired_size:
                break
            if not broadcast_registers and in_dim == register_dim:
                broadcasted_indices.add(basis_index)
            else:
                bases[in_dim][basis_index][out_index] = 0
            actual_size >>= 1

    if not broadcast_registers and broadcasted_indices:
        if register_dim not in bases:
            raise LinearLayoutError("Layout lacks 'register' dimension for broadcast removal")
        bases[register_dim] = [
            vec for idx, vec in enumerate(bases[register_dim]) if idx not in broadcasted_indices
        ]

    new_out_dims: List[Tuple[DimName, int]] = []
    for dim, size in layout.get_out_dims():
        target = shape_map[dim]
        new_out_dims.append((dim, min(size, target)))

    return LinearLayout(bases, new_out_dims, require_surjective=False)


def gluon_layout_to_linear_layout(
    shape: Sequence[int],
    layout: gl.DistributedLinearLayout,
) -> "LinearLayout":
    msg = "only support triton 3.6+, you can use gl.to_linear_layout to get a gl.DistributedLinearLayout first"
    assert isinstance(layout, gl.DistributedLinearLayout), msg
    return LinearLayout({
        "register": layout.reg_bases,
        "lane": layout.lane_bases,
        "warp": layout.warp_bases,
        "block": layout.block_bases,

    }, {
        f"dim{i}": layout.shape[i] for i in range(len(layout.shape))
    })


class LinearLayout:
    """Python translation of Triton's ``LinearLayout``.

    The class tracks a mapping from named input dimensions to their basis
    vectors, together with the ordered output dimensions and their sizes.  The
    representation and invariants follow the C++ implementation closely, but we
    rely solely on Python primitives (``dict``/``list``/``int``).
    """

    def __init__(
        self,
        bases: BasesT,
        out_dims: OutDimsT,
        *,
        require_surjective: bool = True,
    ) -> None:
        """
        Arguments:
            bases: Mapping from input dimension names to their basis vectors.
                e.g. ``{'x': [[1, 0], [2, 0]]}`` defines one labeled vector space `x` with two bits, 
                which is mapped to two dimension of a tensor. let L(b0, b1) -> [tensor_loc_0, tensor_loc_1],
                where b0 and b1 are elements of input vector, then we can use basis vectors (1, 0) and (0, 1)
                to define the mapping (linear transformation) from input vector to tensor location:
                L(1, 0) = (1, 0)
                L(0, 1) = (2, 0)
            out_dims: Sequence of (dimension name, size) pairs defining the output
                dimensions and their sizes.  Alternatively, a mapping from dimension
                names to sizes.
            require_surjective: If true, the constructor will raise if the provided
                bases do not span the entire output space.
        """
        self._bases: "OrderedDict[DimName, List[BasisVector]]" = self._normalize_bases(bases)
        self._out_dims: "OrderedDict[DimName, int]" = self._normalize_out_dims(out_dims)
        self._rank: int = 0
        self._check_invariants(require_surjective=require_surjective)

    # ------------------------------------------------------------------
    # Constructors mirroring the C++ API.
    # ------------------------------------------------------------------
    @staticmethod
    def empty() -> "LinearLayout":
        """Return the 0-dimensional layout that maps everything to zero."""

        return LinearLayout({}, [], require_surjective=False)

    @classmethod
    def from_bases(
        cls,
        bases: BasesT,
        out_dim_names: Sequence[DimName],
        *,
        require_surjective: bool = True,
    ) -> "LinearLayout":
        """Create a layout given bases and infer the output sizes."""

        normalized_bases = cls._normalize_bases(bases)
        sizes: "OrderedDict[DimName, int]" = OrderedDict()
        for name in out_dim_names:
            sizes[_normalize_dim_name(name)] = 1

        for in_dim_bases in normalized_bases.values():
            for basis in in_dim_bases:
                if len(basis) != len(out_dim_names):
                    raise LinearLayoutError(
                        "All basis vectors must match the number of output dimensions"
                    )
                for idx, value in enumerate(basis):
                    dim_name = _normalize_dim_name(out_dim_names[idx])
                    sizes[dim_name] = max(sizes[dim_name], _next_power_of_two(value + 1))

        out_dims = [(dim, size) for dim, size in sizes.items()]
        return cls(normalized_bases, out_dims, require_surjective=require_surjective)

    @classmethod
    def from_bases_with_sizes(
        cls,
        bases: BasesT,
        out_dims: Sequence[Tuple[DimName, int]],
        *,
        require_surjective: bool,
    ) -> "LinearLayout":
        """Create a layout from bases and explicit output dimension sizes."""

        return cls(bases, out_dims, require_surjective=require_surjective)

    @classmethod
    def strided1d(
        cls,
        size: int,
        stride: int,
        in_dim: DimName,
        out_dim: DimName,
    ) -> "LinearLayout":
        if size == 0:
            return cls.empty()
        if not _is_power_of_two(size):
            raise LinearLayoutError("Input size must be a power of two")

        bases = []
        i = 1
        while i < size:
            bases.append([i * stride])
            i <<= 1
        require_surjective = stride == 1
        out_dim_size = stride * size if stride else 1
        return cls(
            { _normalize_dim_name(in_dim): bases },
            [(_normalize_dim_name(out_dim), out_dim_size or 1)],
            require_surjective=require_surjective,
        )

    @classmethod
    def identity1d(cls, size: int, in_dim: DimName, out_dim: DimName) -> "LinearLayout":
        return cls.strided1d(size, 1, in_dim, out_dim)

    @classmethod
    def zeros1d(
        cls,
        size: int,
        in_dim: DimName,
        out_dim: DimName,
        out_dim_size: int = 1,
    ) -> "LinearLayout":
        if size == 0:
            return cls.empty()
        if not _is_power_of_two(size):
            raise LinearLayoutError("Input size must be a power of two")
        bases: List[BasisVector] = []
        j = 1
        while j < size:
            bases.append([0])
            j <<= 1
        return cls(
            { _normalize_dim_name(in_dim): bases },
            [(_normalize_dim_name(out_dim), max(out_dim_size, 1))],
            require_surjective=(out_dim_size == 1),
        )

    # ------------------------------------------------------------------
    # Accessors and simple predicates.
    # ------------------------------------------------------------------
    @property
    def bases(self) -> "OrderedDict[DimName, List[BasisVector]]":
        return OrderedDict((dim, [vec.copy() for vec in vectors]) for dim, vectors in self._bases.items())

    def to_triton_cpp_layout(self):
        from triton.tools import LinearLayout as _LinearLayoutCpp
        return _LinearLayoutCpp.from_bases(
            bases=list(self.bases.items()),
            out_dim_names=list(self._out_dims.keys()),
            out_dim_sizes=list(self._out_dims.values()),
            require_surjective=self.is_surjective(),
        )
        
    def get_shared_view(self, useHWPointOfView: bool) -> str:
        return self.to_triton_cpp_layout().get_shared_view(useHWPointOfView)

    def get_distributed_view(self, useHWPointOfView: bool) -> str:
        return self.to_triton_cpp_layout().get_distributed_view(useHWPointOfView)

    def get_matrix_view(self) -> List[List[int]]:
        return self.to_triton_cpp_layout().get_matrix_view()

    def get_bases(self) -> "OrderedDict[DimName, List[BasisVector]]":
        return self.bases

    def get_out_dims(self) -> List[Tuple[DimName, int]]:
        return [(dim, size) for dim, size in self._out_dims.items()]

    def get_out_dim_names(self) -> Tuple[DimName, ...]:
        return tuple(self._out_dims.keys())

    def get_in_dim_names(self) -> Tuple[DimName, ...]:
        return tuple(self._bases.keys())

    def has_in_dim(self, dim: DimName) -> bool:
        return dim in self._bases

    def has_out_dim(self, dim: DimName) -> bool:
        return dim in self._out_dims

    def get_basis(self, in_dim: DimName, pos: int) -> BasisVector:
        vectors = self._bases[in_dim]
        if pos < 0 or pos >= len(vectors):
            raise LinearLayoutError(f"Basis position {pos} out of range for in-dim {in_dim}")
        return vectors[pos].copy()

    def get_basis_value(self, in_dim: DimName, pos: int, out_dim: DimName) -> int:
        out_index = self.get_out_dim_index(out_dim)
        return self._bases[in_dim][pos][out_index]

    def get_out_dim_index(self, out_dim: DimName) -> int:
        try:
            return self.get_out_dim_names().index(out_dim)
        except ValueError as exc:
            raise LinearLayoutError(f"Unknown out dimension '{out_dim}'") from exc

    def get_in_dim_size_log2(self, in_dim: DimName) -> int:
        return len(self._bases[in_dim])

    def get_in_dim_size(self, in_dim: DimName) -> int:
        return 1 << self.get_in_dim_size_log2(in_dim)

    def get_total_in_dim_size_log2(self) -> int:
        return sum(len(bases) for bases in self._bases.values())

    def get_total_in_dim_size(self) -> int:
        return 1 << self.get_total_in_dim_size_log2()

    def get_out_dim_size_log2(self, out_dim: DimName) -> int:
        return _log2_power_of_two(self._out_dims[out_dim])

    def get_out_dim_size(self, out_dim: DimName) -> int:
        return self._out_dims[out_dim]

    def get_out_dim_name_by_base(self, base: list[int]) -> str:
        for out_dim, bases in self._bases.items():
            for candidate in bases:
                if candidate == base:
                    return out_dim
        raise LinearLayoutError("No matching output dimension found for the given base")

    def get_total_out_dim_size_log2(self) -> int:
        return sum(_log2_power_of_two(size) for size in self._out_dims.values())

    def get_total_out_dim_size(self) -> int:
        return 1 << self.get_total_out_dim_size_log2()

    def get_num_in_dims(self) -> int:
        return len(self._bases)

    def get_num_out_dims(self) -> int:
        return len(self._out_dims)

    @property
    def rank(self) -> int:
        return self._rank

    def is_surjective(self) -> bool:
        return self._rank == self.get_total_out_dim_size_log2()

    def is_injective(self) -> bool:
        return self._rank == self.get_total_in_dim_size_log2()

    def is_invertible(self) -> bool:
        return self.is_surjective() and self.get_total_in_dim_size() == self.get_total_out_dim_size()

    # ------------------------------------------------------------------
    # Transformations mirroring the C++ helpers.
    # ------------------------------------------------------------------
    def transpose_ins(self, new_order: Sequence[DimName]) -> "LinearLayout":
        self._assert_dims_equal_ignoring_order(new_order, self.get_in_dim_names(), which="input")
        reordered = OrderedDict((dim, self._bases[dim]) for dim in new_order)
        return LinearLayout(reordered, self.get_out_dims(), require_surjective=self.is_surjective())

    def transpose_outs(self, new_order: Sequence[DimName]) -> "LinearLayout":
        self._assert_dims_equal_ignoring_order(new_order, self.get_out_dim_names(), which="output")
        permutation = [self.get_out_dim_index(dim) for dim in new_order]
        new_bases: "OrderedDict[DimName, List[BasisVector]]" = OrderedDict()
        for in_dim, in_dim_bases in self._bases.items():
            permuted: List[BasisVector] = []
            for basis in in_dim_bases:
                permuted.append([basis[idx] for idx in permutation])
            new_bases[in_dim] = permuted
        new_out_dims = [(dim, self._out_dims[dim]) for dim in new_order]
        return LinearLayout(new_bases, new_out_dims, require_surjective=self.is_surjective())

    def reshape_ins(self, new_in_dims: Sequence[Tuple[DimName, int]]) -> "LinearLayout":
        if not all(_is_power_of_two(size) for _, size in new_in_dims):
            raise LinearLayoutError("All input reshape sizes must be powers of two")
        total = 1
        for _, size in new_in_dims:
            total *= size
        if total != self.get_total_in_dim_size():
            raise LinearLayoutError("Input reshape sizes must preserve the total input volume")

        flat_bases: List[BasisVector] = []
        for bases in self._bases.values():
            flat_bases.extend(basis.copy() for basis in bases)

        new_bases: "OrderedDict[DimName, List[BasisVector]]" = OrderedDict()
        cursor = 0
        for in_dim, size in new_in_dims:
            vectors: List[BasisVector] = []
            j = 1
            while j < size:
                vectors.append(flat_bases[cursor])
                cursor += 1
                j <<= 1
            new_bases[_normalize_dim_name(in_dim)] = vectors
        return LinearLayout(new_bases, self.get_out_dims(), require_surjective=self.is_surjective())

    def reshape_outs(self, new_out_dims: Sequence[Tuple[DimName, int]]) -> "LinearLayout":
        if not all(_is_power_of_two(size) for _, size in new_out_dims):
            raise LinearLayoutError("All output reshape sizes must be powers of two")
        total = 1
        for _, size in new_out_dims:
            total *= size
        if total != self.get_total_out_dim_size():
            raise LinearLayoutError("Output reshape sizes must preserve the total output volume")

        shifts: List[int] = [0]
        for dim in self.get_out_dim_names():
            shifts.append(shifts[-1] + self.get_out_dim_size_log2(dim))

        flat_bases: "OrderedDict[DimName, List[int]]" = OrderedDict()
        for in_dim, in_dim_bases in self._bases.items():
            flattened: List[int] = []
            for basis in in_dim_bases:
                acc = 0
                for idx, value in enumerate(basis):
                    acc |= value << shifts[idx]
                flattened.append(acc)
            flat_bases[in_dim] = flattened

        new_bases: "OrderedDict[DimName, List[BasisVector]]" = OrderedDict()
        for in_dim, flattened in flat_bases.items():
            vectors: List[BasisVector] = []
            for value in flattened:
                components: List[int] = []
                temp = value
                for _, size in new_out_dims:
                    components.append(temp % size)
                    temp //= size
                vectors.append(components)
            new_bases[in_dim] = vectors

        normalized_out_dims = [(_normalize_dim_name(dim), size) for dim, size in new_out_dims]
        return LinearLayout(new_bases, normalized_out_dims, require_surjective=self.is_surjective())

    def concat_ins(self, other: "LinearLayout") -> "LinearLayout":
        if self.get_out_dim_names() != other.get_out_dim_names():
            raise LinearLayoutError("Layouts must share identical output dimension names to concat inputs")
        for dim in self.get_out_dim_names():
            if self.get_out_dim_size(dim) != other.get_out_dim_size(dim):
                raise LinearLayoutError("Layouts must share output dimension sizes to concat inputs")

        result_bases = self.get_bases()
        for dim, bases in other.get_bases().items():
            if dim in result_bases:
                raise LinearLayoutError("Cannot concatenate input dimensions with duplicate names")
            result_bases[dim] = bases
        return LinearLayout(
            result_bases,
            self.get_out_dims(),
            require_surjective=False,
        )

    def concat_outs(self, other: "LinearLayout") -> "LinearLayout":
        if self.get_in_dim_names() != other.get_in_dim_names():
            raise LinearLayoutError("Layouts must share identical input dimension names to concat outputs")
        for dim in self.get_in_dim_names():
            if self.get_in_dim_size(dim) != other.get_in_dim_size(dim):
                raise LinearLayoutError("Layouts must share input dimension sizes to concat outputs")

        result_bases: "OrderedDict[DimName, List[BasisVector]]" = OrderedDict()
        for (dim, lhs_bases), (_, rhs_bases) in zip(self._bases.items(), other._bases.items()):
            combined: List[BasisVector] = []
            for lhs, rhs in zip(lhs_bases, rhs_bases):
                combined.append(lhs + rhs)
            result_bases[dim] = combined
        new_out_dims = self.get_out_dims() + other.get_out_dims()
        return LinearLayout(
            result_bases,
            new_out_dims,
            require_surjective=False,
        )

    def sublayout(
        self,
        in_dim_names: Sequence[DimName],
        out_dim_names: Sequence[DimName],
    ) -> "LinearLayout":
        in_dim_names = _normalize_dim_sequence(in_dim_names)
        out_dim_names = _normalize_dim_sequence(out_dim_names)
        _assert_dims_subset(in_dim_names, self.get_in_dim_names(), which="input")
        _assert_dims_subset(out_dim_names, self.get_out_dim_names(), which="output")

        out_indices = [self.get_out_dim_index(dim) for dim in out_dim_names]
        new_bases: "OrderedDict[DimName, List[BasisVector]]" = OrderedDict()
        for in_dim, in_dim_bases in self._bases.items():
            if in_dim not in in_dim_names:
                continue
            projected: List[BasisVector] = []
            for basis in in_dim_bases:
                projected.append([basis[idx] for idx in out_indices])
            new_bases[in_dim] = projected

        new_out_dims = [(dim, self.get_out_dim_size(dim)) for dim in out_dim_names]
        return LinearLayout(new_bases, new_out_dims, require_surjective=False)

    def sublayout_is_zero(
        self,
        in_dim_names: Sequence[DimName],
        out_dim_names: Sequence[DimName],
    ) -> bool:
        sub = self.sublayout(in_dim_names, out_dim_names)
        for bases in sub._bases.values():
            for basis in bases:
                if any(value != 0 for value in basis):
                    return False
        return True

    def direct_sum(self, other: "LinearLayout") -> "LinearLayout":
        in_dims = _supremum(list(self.get_in_dim_names()), list(other.get_in_dim_names()))
        out_dims = _supremum(list(self.get_out_dim_names()), list(other.get_out_dim_names()))

        in_dim_sizes_log2: "OrderedDict[DimName, int]" = OrderedDict((dim, 0) for dim in in_dims)
        out_dim_sizes_log2: "OrderedDict[DimName, int]" = OrderedDict((dim, 0) for dim in out_dims)

        for layout in (self, other):
            for dim in layout.get_in_dim_names():
                in_dim_sizes_log2[dim] += layout.get_in_dim_size_log2(dim)
            for dim in layout.get_out_dim_names():
                out_dim_sizes_log2[dim] += layout.get_out_dim_size_log2(dim)

        combined_bases: "OrderedDict[DimName, List[BasisVector]]" = OrderedDict()
        for in_dim, total_log2 in in_dim_sizes_log2.items():
            bases_matrix = [[0] * len(out_dims) for _ in range(total_log2)]
            if self.has_in_dim(in_dim):
                for out_idx, out_dim in enumerate(out_dims):
                    if self.has_out_dim(out_dim):
                        for i in range(self.get_in_dim_size_log2(in_dim)):
                            bases_matrix[i][out_idx] = self.get_basis_value(in_dim, i, out_dim)
            if other.has_in_dim(in_dim):
                offset = self.get_in_dim_size_log2(in_dim) if self.has_in_dim(in_dim) else 0
                for out_idx, out_dim in enumerate(out_dims):
                    if other.has_out_dim(out_dim):
                        shift = self.get_out_dim_size_log2(out_dim) if self.has_out_dim(out_dim) else 0
                        for i in range(other.get_in_dim_size_log2(in_dim)):
                            bases_matrix[offset + i][out_idx] = other.get_basis_value(in_dim, i, out_dim) << shift
            combined_bases[in_dim] = bases_matrix

        out_dim_sizes = [(dim, 1 << size_log2) for dim, size_log2 in out_dim_sizes_log2.items()]
        return LinearLayout(
            combined_bases,
            out_dim_sizes,
            require_surjective=self.is_surjective() and other.is_surjective(),
        )

    def __mul__(self, other: "LinearLayout") -> "LinearLayout":
        return self.direct_sum(other)

    def __rmul__(self, other: "LinearLayout") -> "LinearLayout":
        return other.direct_sum(self)

    def flatten_ins(self) -> "LinearLayout":
        if self.get_num_in_dims() == 0:
            return self.reshape_ins(())
        first = self.get_in_dim_names()[0]
        return self.reshape_ins(((first, self.get_total_in_dim_size()),))

    def flatten_outs(self) -> "LinearLayout":
        if self.get_num_out_dims() == 0:
            return self.reshape_outs(())
        first = self.get_out_dim_names()[0]
        return self.reshape_outs(((first, self.get_total_out_dim_size()),))

    def compose(self, outer: "LinearLayout") -> "LinearLayout":
        self._assert_dims_equal_ignoring_order(outer.get_in_dim_names(), self.get_out_dim_names(), which="output")
        for out_dim in self.get_out_dim_names():
            if self.get_out_dim_size(out_dim) > outer.get_in_dim_size(out_dim):
                raise LinearLayoutError(
                    f"compose requires outer layout to cover output dimension '{out_dim}'"
                )

        new_bases: "OrderedDict[DimName, List[BasisVector]]" = OrderedDict()
        for in_dim, in_dim_bases in self._bases.items():
            composed: List[BasisVector] = []
            for basis in in_dim_bases:
                pairs = list(zip(self.get_out_dim_names(), basis))
                applied = outer.apply(pairs)
                composed.append([value for _, value in applied])
            new_bases[in_dim] = composed

        composition_surjective = (
            self.is_surjective()
            and outer.is_surjective()
            and all(
                self.get_out_dim_size(dim) == outer.get_in_dim_size(dim)
                for dim in self.get_out_dim_names()
            )
        )
        return LinearLayout(new_bases, outer.get_out_dims(), require_surjective=composition_surjective)

    def invert_and_compose(self, outer: "LinearLayout") -> "LinearLayout":
        out_dims = list(self.get_out_dim_names())
        self._assert_dims_equal_ignoring_order(outer.get_out_dim_names(), out_dims, which="output")

        B = self
        A = outer.transpose_outs(out_dims)
        for dim in out_dims:
            if A.get_out_dim_size(dim) < B.get_out_dim_size(dim):
                raise LinearLayoutError(
                    f"invert_and_compose requires outer layout to cover dimension '{dim}'"
                )

        identity_dims: List[DimName] = []
        for dim in A.get_in_dim_names():
            if B.has_in_dim(dim) and A.sublayout([dim], out_dims) == B.sublayout([dim], out_dims):
                identity_dims.append(dim)

        a_non_identity = [dim for dim in A.get_in_dim_names() if dim not in identity_dims]
        b_non_identity = [dim for dim in B.get_in_dim_names() if dim not in identity_dims]

        A_reduced = A.sublayout(a_non_identity, out_dims)
        B_reduced = B.sublayout(b_non_identity, out_dims)
        is_empty = not a_non_identity and not b_non_identity

        result = LinearLayout.empty() if is_empty else _lstsq(A_reduced, B_reduced)
        for dim in identity_dims:
            identity_layout = LinearLayout.identity1d(A.get_in_dim_size(dim), dim, dim)
            result = result.direct_sum(identity_layout)

        return result.transpose_ins(list(B.get_in_dim_names())).transpose_outs(list(A.get_in_dim_names()))

    def invert(self) -> "LinearLayout":
        if not self.is_invertible():
            raise LinearLayoutError(
                "Layout must be surjective with matching in/out volume to be invertible"
            )
        return self.pseudoinvert()

    def pseudoinvert(self) -> "LinearLayout":
        identity = LinearLayout.empty()
        for out_dim in self.get_out_dim_names():
            identity = identity.direct_sum(
                LinearLayout.identity1d(self.get_out_dim_size(out_dim), out_dim, out_dim)
            )
        return identity.invert_and_compose(self)

    def is_trivial_over(self, dim_names: Sequence[DimName]) -> bool:
        dim_names = _normalize_dim_sequence(dim_names)
        for dim in dim_names:
            if dim not in self.get_in_dim_names() and dim not in self.get_out_dim_names():
                return False

        remaining_in = [dim for dim in self.get_in_dim_names() if dim not in dim_names]
        remaining_out = [dim for dim in self.get_out_dim_names() if dim not in dim_names]

        return (
            _square_sublayout_is_identity(self, dim_names)
            and self.sublayout_is_zero(remaining_in, dim_names)
            and self.sublayout_is_zero(dim_names, remaining_out)
        )

    def divide_left(self, other: "LinearLayout") -> Optional["LinearLayout"]:
        for dim in other.get_in_dim_names():
            if dim not in self.get_in_dim_names():
                return None
        for dim in other.get_out_dim_names():
            if dim not in self.get_out_dim_names():
                return None

        c_out_sizes: "OrderedDict[DimName, int]" = OrderedDict()
        for out_dim in self.get_out_dim_names():
            out_a = self.get_out_dim_size_log2(out_dim)
            out_b = other.get_out_dim_size_log2(out_dim) if other.has_out_dim(out_dim) else 0
            out_c = out_a - out_b
            if out_c < 0:
                return None
            c_out_sizes[out_dim] = 1 << out_c

        c_bases: "OrderedDict[DimName, List[BasisVector]]" = OrderedDict()
        for in_dim in self.get_in_dim_names():
            in_a = self.get_in_dim_size_log2(in_dim)
            in_b = other.get_in_dim_size_log2(in_dim) if other.has_in_dim(in_dim) else 0
            in_c = in_a - in_b
            if in_c < 0:
                return None

            vectors: List[BasisVector] = []
            for i in range(in_b):
                for out_dim in self.get_out_dim_names():
                    expected = other.get_basis_value(in_dim, i, out_dim) if other.has_out_dim(out_dim) else 0
                    actual = self.get_basis_value(in_dim, i, out_dim)
                    if actual != expected:
                        return None

            for i in range(in_b, in_a):
                basis: BasisVector = []
                for out_dim, size in c_out_sizes.items():
                    out_b = other.get_out_dim_size_log2(out_dim) if other.has_out_dim(out_dim) else 0
                    value = self.get_basis_value(in_dim, i, out_dim)
                    mask = (1 << out_b) - 1 if out_b else 0
                    if mask and (value & mask):
                        return None
                    basis.append(value >> out_b)
                vectors.append(basis)
            c_bases[in_dim] = vectors

        out_dims = list(c_out_sizes.items())
        try:
            result = LinearLayout(c_bases, out_dims, require_surjective=self.is_surjective() and other.is_surjective())
        except LinearLayoutError:
            return None
        if (other * result) != self:
            return None
        return result

    def divide_right(self, other: "LinearLayout") -> Optional["LinearLayout"]:
        for dim in other.get_in_dim_names():
            if dim not in self.get_in_dim_names():
                return None
        for dim in other.get_out_dim_names():
            if dim not in self.get_out_dim_names():
                return None

        c_out_sizes: "OrderedDict[DimName, int]" = OrderedDict()
        for out_dim in self.get_out_dim_names():
            out_a = self.get_out_dim_size_log2(out_dim)
            out_b = other.get_out_dim_size_log2(out_dim) if other.has_out_dim(out_dim) else 0
            out_c = out_a - out_b
            if out_c < 0:
                return None
            c_out_sizes[out_dim] = 1 << out_c

        c_bases: "OrderedDict[DimName, List[BasisVector]]" = OrderedDict()
        for in_dim in self.get_in_dim_names():
            in_a = self.get_in_dim_size_log2(in_dim)
            in_b = other.get_in_dim_size_log2(in_dim) if other.has_in_dim(in_dim) else 0
            in_c = in_a - in_b
            if in_c < 0:
                return None

            vectors: List[BasisVector] = []
            for i in range(in_c):
                basis = []
                for out_dim, _ in c_out_sizes.items():
                    basis.append(self.get_basis_value(in_dim, i, out_dim))
                vectors.append(basis)

            for i in range(in_c, in_a):
                j = i - in_c
                for out_dim in other.get_out_dim_names():
                    out_a = self.get_out_dim_size_log2(out_dim)
                    out_b = other.get_out_dim_size_log2(out_dim)
                    out_c = out_a - out_b
                    shift = out_c
                    value = self.get_basis_value(in_dim, i, out_dim)
                    mask = (1 << shift) - 1 if shift else 0
                    if mask and (value & mask):
                        return None
                    recovered = value >> shift
                    expected = other.get_basis_value(in_dim, j, out_dim)
                    if recovered != expected:
                        return None
            c_bases[in_dim] = vectors

        out_dims = list(c_out_sizes.items())
        try:
            result = LinearLayout(c_bases, out_dims, require_surjective=self.is_surjective() and other.is_surjective())
        except LinearLayoutError:
            return None
        if (result * other) != self:
            return None
        return result

    def quotient(self, dim_names: Sequence[DimName]) -> Optional["LinearLayout"]:
        dim_names = _normalize_dim_sequence(dim_names)
        if not self.is_trivial_over(dim_names):
            return None

        in_dims = [dim for dim in self.get_in_dim_names() if dim not in dim_names]
        out_dims = [dim for dim in self.get_out_dim_names() if dim not in dim_names]
        return self.sublayout(in_dims, out_dims)


    # ------------------------------------------------------------------
    # Functional helpers.
    # ------------------------------------------------------------------
    def apply(self, inputs: Sequence[Tuple[DimName, int]]) -> List[Tuple[DimName, int]]:
        values = { _normalize_dim_name(dim): val for dim, val in inputs }
        result: Dict[DimName, int] = { dim: 0 for dim in self.get_out_dim_names() }

        for in_dim, bases in self._bases.items():
            value = values.get(in_dim, 0)
            bit = 0
            limit = len(bases)
            if value < 0:
                raise LinearLayoutError(f"Input value for dimension '{in_dim}' must be non-negative")
            if value >= (1 << limit) and limit > 0:
                raise LinearLayoutError(
                    f"Input value {value} exceeds the representable range for dimension '{in_dim}'"
                )
            while value and bit < limit:
                if value & 1:
                    vector = bases[bit]
                    for idx, out_dim in enumerate(self.get_out_dim_names()):
                        result[out_dim] ^= vector[idx]
                value >>= 1
                bit += 1
        return list(result.items())

    def to_string(self) -> str:
        if not self._bases and not self._out_dims:
            return "\n(empty layout)"
        if not self._bases:
            dims = ", ".join(f"{dim} (size {size})" for dim, size in self._out_dims.items())
            return f"\n(empty layout with out-dims [{dims}])"

        lines: List[str] = [""]
        out_dims_str = ", ".join(f"{dim} (size {size})" for dim, size in self._out_dims.items())
        for in_dim, bases in self._bases.items():
            if not bases:
                lines.append(f" - {in_dim} is a size 1 dimension")
                continue
            entries: List[str] = []
            for idx, basis in enumerate(bases):
                power = 1 << idx
                basis_str = ", ".join(str(v) for v in basis)
                entries.append(f"{in_dim}={power} -> ({basis_str})")
            lines.append(" - " + "\n   ".join(entries))
        lines.append(f"where out dims are: [{out_dims_str}]")
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Equality / hashing (mirroring the C++ helpers).
    # ------------------------------------------------------------------
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, LinearLayout):
            return NotImplemented
        return self._bases == other._bases and self._out_dims == other._out_dims

    def equal_ignoring_out_dim_sizes(self, other: "LinearLayout") -> bool:
        if self.get_out_dim_names() != other.get_out_dim_names():
            return False
        return self._bases == other._bases

    def __repr__(self) -> str:
        return f"LinearLayout(bases={self._bases!r}, out_dims={self._out_dims!r})"

    # ------------------------------------------------------------------
    # Internal helpers.
    # ------------------------------------------------------------------
    @staticmethod
    def _normalize_bases(bases: BasesT) -> "OrderedDict[DimName, List[BasisVector]]":
        if isinstance(bases, OrderedDict):
            items = bases.items()
        else:
            items = list(bases.items())
        normalized: "OrderedDict[DimName, List[BasisVector]]" = OrderedDict()
        for dim, vectors in items:
            dim_name = _normalize_dim_name(dim)
            normalized[dim_name] = [list(vector) for vector in vectors]
        return normalized

    @staticmethod
    def _normalize_out_dims(out_dims: OutDimsT) -> "OrderedDict[DimName, int]":
        normalized: "OrderedDict[DimName, int]" = OrderedDict()
        if isinstance(out_dims, Mapping):
            iterator: Iterable[Tuple[DimName, int]] = out_dims.items()
        else:
            iterator = out_dims
        for dim, size in iterator:
            dim_name = _normalize_dim_name(dim)
            normalized[dim_name] = int(size)
        return normalized

    def _check_invariants(self, *, require_surjective: bool) -> None:
        out_dim_count = len(self._out_dims)
        for in_dim, vectors in self._bases.items():
            for basis in vectors:
                if any(value < 0 for value in basis):
                    raise LinearLayoutError(
                        f"Invalid negative basis value detected for input dimension '{in_dim}'"
                    )
                if len(basis) != out_dim_count:
                    raise LinearLayoutError(
                        "All basis vectors must match the number of output dimensions"
                    )
        for out_dim, size in self._out_dims.items():
            if size <= 0 or not _is_power_of_two(size):
                raise LinearLayoutError(
                    f"Output dimension '{out_dim}' has non power-of-two size {size}"
                )
        out_dim_names = self.get_out_dim_names()
        for in_dim, vectors in self._bases.items():
            for basis in vectors:
                for idx, value in enumerate(basis):
                    size = self._out_dims[out_dim_names[idx]]
                    if value >= size:
                        raise LinearLayoutError(
                            f"Basis value {value} for in-dim '{in_dim}' exceeds size of out-dim '{out_dim_names[idx]}'"
                        )

        self._rank = self._compute_rank()
        if require_surjective and not self.is_surjective():
            raise LinearLayoutError("Layout is expected to be surjective but failed the rank test")

    def _compute_rank(self) -> int:
        num_rows = self.get_total_out_dim_size_log2()
        num_cols = self.get_total_in_dim_size_log2()
        if num_rows > 64 or num_cols > 64:
            raise LinearLayoutError("Python port only supports layouts up to 64 bits per dimension")
        matrix = self._build_matrix()
        _, pivot_rows = self._binary_rref(matrix, num_rows, num_cols)
        return sum(1 for row in pivot_rows if row != -1)

    def _build_matrix(self) -> List[int]:
        rows = [0] * self.get_total_out_dim_size_log2()
        row_offset = 0
        for out_dim in self.get_out_dim_names():
            col_idx = 0
            out_size_log2 = self.get_out_dim_size_log2(out_dim)
            for in_dim in self.get_in_dim_names():
                bases = self._bases[in_dim]
                for basis in bases:
                    basis_val = basis[self.get_out_dim_index(out_dim)]
                    for bit in range(out_size_log2):
                        if (basis_val >> bit) & 1:
                            rows[row_offset + bit] |= 1 << col_idx
                    col_idx += 1
            row_offset += out_size_log2
        return rows

    @staticmethod
    def _binary_rref(matrix: List[int], num_rows: int, num_cols: int) -> Tuple[List[int], List[int]]:
        rows = list(matrix)
        pivot_rows = [-1] * num_cols
        rank = 0
        for col in range(num_cols):
            pivot = None
            for row in range(rank, num_rows):
                if (rows[row] >> col) & 1:
                    pivot = row
                    break
            if pivot is None:
                continue
            rows[rank], rows[pivot] = rows[pivot], rows[rank]
            for row in range(num_rows):
                if row != rank and ((rows[row] >> col) & 1):
                    rows[row] ^= rows[rank]
            pivot_rows[col] = rank
            rank += 1
            if rank == num_rows:
                break
        return rows, pivot_rows

    @staticmethod
    def _assert_dims_equal_ignoring_order(
        new_dims: Sequence[DimName],
        old_dims: Sequence[DimName],
        *,
        which: str,
    ) -> None:
        if set(new_dims) != set(old_dims):
            raise LinearLayoutError(
                f"{which.capitalize()} dimensions must match ignoring order; got {new_dims} vs {old_dims}"
            )


    def _order_per_dim(self, dim_name: str, default_order: list[int]):
        bases = self.get_bases()[dim_name]
        order: list[int] = []
        for basis in bases:
            for j in range(len(basis)):
                val = basis[j]
                if val != 0:
                    if j not in order:
                        order.append(j)
                    break
        for i in default_order:
            if i not in order:
                order.append(i)
        return order 
        

    def get_order(self):
        rank = self.get_num_out_dims()
        order = list(range(rank))[::-1]
        return self._order_per_dim("register", order)

    def get_contig(self, in_dim: str, lower_contig: list[int]):
        bases = self.get_bases()[in_dim]
        order = self.get_order()
        rank = len(order)
        contig = lower_contig.copy()
        j = 0
        for dim in order:
            basis = [0] * rank
            basis[dim] = contig[dim]

            while j < len(bases) and bases[j] == basis:
                contig[dim] *= 2
                basis[dim] *= 2
                j += 1 
        return contig

    def get_contig_per_thread(self):
        contig = [1] * len(self.get_order())
        return self.get_contig("register", contig)

@dataclass(frozen=True)
class ColumnAction:
    """Permutation action over the columns (bases) of a specific input dimension."""

    action: Sequence[int]
    in_dim: DimName
    in_size_log2: int

    def __post_init__(self) -> None:
        if not self.action:
            object.__setattr__(self, "_is_identity", True)
            return
        if max(self.action) >= self.in_size_log2:
            raise LinearLayoutError(
                f"ColumnAction is incompatible with in-dimension '{self.in_dim}'"
            )
        is_identity = list(self.action) == list(range(len(self.action))) and len(self.action) == self.in_size_log2
        object.__setattr__(self, "_is_identity", is_identity)

    @property
    def is_identity(self) -> bool:
        return getattr(self, "_is_identity")

    def apply_layout(self, layout: LinearLayout) -> LinearLayout:
        if not layout.has_in_dim(self.in_dim):
            raise LinearLayoutError(f"Layout has no input dimension named '{self.in_dim}'")
        if layout.get_in_dim_size_log2(self.in_dim) != self.in_size_log2:
            raise LinearLayoutError("Layout has a different size than the ColumnAction")
        if self.is_identity:
            return layout

        bases = layout.get_bases()
        original = bases[self.in_dim]
        permuted = []
        for idx in self.action:
            permuted.append(original[idx])
        bases[self.in_dim] = permuted
        return LinearLayout(
            bases,
            layout.get_out_dims(),
            require_surjective=False,
        )

    def apply_values(self, values: Sequence[int]) -> List[int]:
        expected_size = 1 << self.in_size_log2
        if len(values) != expected_size:
            raise LinearLayoutError(
                f"Expected {expected_size} values for dimension '{self.in_dim}', got {len(values)}"
            )
        if self.is_identity:
            return list(values)
        identity = LinearLayout.identity1d(len(values), self.in_dim, self.in_dim)
        permuted = self.apply_layout(identity)
        result: List[int] = []
        for index in range(permuted.get_in_dim_size(self.in_dim)):
            src_value = dict(permuted.apply([(self.in_dim, index)]))[self.in_dim]
            result.append(values[src_value])
        return result

    def inverse(self) -> "ColumnAction":
        inv = [0] * len(self.action)
        for idx, value in enumerate(self.action):
            inv[value] = idx
        return ColumnAction(inv, self.in_dim, self.in_size_log2)

    def left_compose(self, other: "ColumnAction") -> "ColumnAction":
        if self.in_dim != other.in_dim or self.in_size_log2 != other.in_size_log2:
            raise LinearLayoutError("Column actions must refer to the same dimension and size")
        composed = [other.action[idx] for idx in self.action]
        return ColumnAction(composed, self.in_dim, self.in_size_log2)

    def __str__(self) -> str:
        entries = ", ".join(str(i) for i in self.action)
        return f"ColumnAction({self.in_dim}: [{entries}])"

__all__ = [
    "LinearLayout",
    "ColumnAction",
    "LinearLayoutError",
    "standard_out_dim_names",
    "identity_standard_nd",
    "ensure_layout_not_smaller_than",
    "ensure_layout_not_larger_than",
]
