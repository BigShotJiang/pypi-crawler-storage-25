import dataclasses
from typing import Any, Self

import triton.language as tl

from ttfs.core.aggtype import (
    base_aggregate_value,
    aggregate,
    constexpr_function,
    get_scalar_tensor,
    triton_jit,
)
from ttfs.core.mp import (
    get_num_warps
)
from triton.experimental.gluon import language as gl



@aggregate
class TTRawSmem(base_aggregate_value):
    """Shared Memory for scalar access (not blocked access), used to implement low-level gluon kernel.
    """
    smem: gl.shared_memory_descriptor

    @constexpr_function
    def size(self):
        return self.smem.shape[1]

    @constexpr_function
    def dtype(self):
        return self.smem.dtype

    @triton_jit 
    def load(self, index):
        smem_element_wise_layout: gl.constexpr = gl.BlockedLayout([1], [32], [get_num_warps()], [0])
        return self.smem.index(get_scalar_tensor(index).to(tl.int32)).load(smem_element_wise_layout).item()

    @triton_jit 
    def store(self, index, value):
        smem_element_wise_layout: gl.constexpr = gl.BlockedLayout([1], [32], [get_num_warps()], [0])
        self.smem.index(get_scalar_tensor(index).to(tl.int32)).store(gl.full([1], value, value.dtype, smem_element_wise_layout))

@triton_jit 
def create_raw_smem(size, dtype):
    smem = gl.allocate_shared_memory(dtype, [size, 1], gl.SwizzledSharedLayout(1, 1, 1, [0]))
    return TTRawSmem(smem)