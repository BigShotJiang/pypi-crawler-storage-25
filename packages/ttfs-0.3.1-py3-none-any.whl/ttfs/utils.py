import contextlib
import re
from typing import Any, Callable, Optional

import numpy as np
import torch
import os
import sys
import threading
import time



def div_up(a: int, b: int) -> int:
    return (a + b - 1) // b


def align_up(a: int, b: int) -> int:
    return div_up(a, b) * b

def get_compiled_kernel_meta(ker):
    metadata_dict = ker.metadata._asdict().copy()
    metadata_dict.pop("target")
    metadata_dict["n_regs"] = ker.n_regs
    metadata_dict["n_spills"] = ker.n_spills
    metadata_dict["n_max_threads"] = ker.n_max_threads
    return metadata_dict

def get_compiled_kernel_meta_short(ker):
    # metadata_dict = ker.metadata._asdict().copy()
    metadata_dict = {}
    metadata_dict["n_regs"] = ker.n_regs
    metadata_dict["n_spills"] = ker.n_spills
    metadata_dict["n_max_threads"] = ker.n_max_threads
    metadata_dict["shared"] = ker.metadata.shared
    return metadata_dict

def get_attn_tflops(ms, B, H, S, D, causal):
    flops_per_matmul = 2.0 * B * H * S * S * D
    total_flops = 2 * flops_per_matmul
    if causal:
        total_flops *= 0.5
    tflops_per_sec = total_flops * 1e-12 / (ms * 1e-3)
    return tflops_per_sec

def patch_triton_cuda_ptx(*patchers: Callable[[str], str]):
    """Patch triton generated ptx code before it is compiled by nvcc.

    Args:
        patcher (Callable[[str], str]): A function that takes the original ptx code as input
            and returns the patched ptx code.
    """
    from triton.backends import backends 
    original_make_ptx = backends["nvidia"].compiler.make_ptx
    def _new_make_ptx(self, *args, **kwargs):

        res = original_make_ptx(self, *args, **kwargs)
        for patcher in patchers:
            res = patcher(res)
        return res 
    backends["nvidia"].compiler.make_ptx = _new_make_ptx


_TRITON_DEVICE_PRINT_PATTERN = re.compile(
    r"^\s*pid\s*\((?P<pid>[^)]*)\)\s*idx\s*\((?P<idx>[^)]*)\)\s*(?P<prefix>.*?):\s*(?P<value>[^\s]+)\s*$"
)


def _parse_debug_coord_tuple(text: str) -> tuple[int, ...]:
    if not text.strip():
        return ()
    return tuple(int(part.strip()) for part in text.split(",") if part.strip())


def _build_debug_output_array(values_by_coord: dict[tuple[int, ...], float]) -> np.ndarray:
    if not values_by_coord:
        return np.empty((0,), dtype=np.float64)

    max_coord = tuple(max(coord[axis] for coord in values_by_coord) for axis in range(len(next(iter(values_by_coord)))))
    result = np.full(tuple(axis + 1 for axis in max_coord), np.nan, dtype=np.float64)
    for coord, value in values_by_coord.items():
        result[coord] = value
    return result


def parse_triton_device_print_output_arrays(text: str) -> dict[str, np.ndarray]:
    """Parse Triton device print output into dense numpy arrays keyed by prefix.

    The expected line format is:
        pid (0, 0, 0) idx (0, 52) acc after qk ref: 0.015664

    Parsed coordinates are flattened as ``pid + idx`` and used as indices in the
    returned arrays. Unwritten positions are filled with ``np.nan``.
    """
    values_by_prefix: dict[str, dict[tuple[int, ...], float]] = {}
    expected_rank_by_prefix: dict[str, int] = {}

    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue

        match = _TRITON_DEVICE_PRINT_PATTERN.match(line)
        if match is None:
            print(line)
            continue

        prefix = match.group("prefix").strip()
        coord = _parse_debug_coord_tuple(match.group("pid")) + _parse_debug_coord_tuple(match.group("idx"))
        value = float(match.group("value"))
        values_by_coord = values_by_prefix.setdefault(prefix, {})

        expected_rank = expected_rank_by_prefix.get(prefix)
        if expected_rank is None:
            expected_rank_by_prefix[prefix] = len(coord)
        elif len(coord) != expected_rank:
            raise ValueError(
                f"Inconsistent Triton debug coordinate rank for prefix {prefix!r}: expected {expected_rank}, got {len(coord)} for line: {line}"
            )

        previous = values_by_coord.get(coord)
        if previous is not None and previous != value:
            print(
                f"Warning: conflicting Triton debug values for prefix {prefix!r} at coords {coord}: {previous} -> {value}. Overriding.",
                file=sys.stderr,
            )
        values_by_coord[coord] = value

    return {
        prefix: _build_debug_output_array(values_by_coord)
        for prefix, values_by_coord in values_by_prefix.items()
    }


def parse_triton_device_print_output(text: str, prefix: Optional[str] = None) -> np.ndarray:
    """Parse Triton device print output into a single dense numpy array.

    When multiple prefixes are present, pass ``prefix`` explicitly. If the output
    contains exactly one prefix, it is selected automatically.
    """
    arrays_by_prefix = parse_triton_device_print_output_arrays(text)
    if prefix is not None:
        return arrays_by_prefix.get(prefix, np.empty((0,), dtype=np.float64))

    if not arrays_by_prefix:
        return np.empty((0,), dtype=np.float64)
    if len(arrays_by_prefix) == 1:
        return next(iter(arrays_by_prefix.values()))

    raise ValueError(
        f"Multiple Triton debug prefixes found: {sorted(arrays_by_prefix)}. Pass prefix=... or use parse_triton_device_print_output_arrays()."
    )

class OutputGrabber(object):
    """
    Class used to grab standard output or another stream.
    """
    escape_char = "\b"

    def __init__(self, stream=None, threaded=False):
        self.origstream = stream
        self.threaded = threaded
        if self.origstream is None:
            self.origstream = sys.stdout
        self.origstreamfd = self.origstream.fileno()
        self.capturedtext = ""
        self.capturedarrays: dict[str, np.ndarray] = {}
        # Create a pipe so the stream can be captured:
        self.pipe_out, self.pipe_in = os.pipe()

    @property
    def capturedarray(self) -> np.ndarray:
        return self.get_capturedarray()

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, type, value, traceback):
        self.stop()

    def start(self):
        """
        Start capturing the stream data.
        """
        self.capturedtext = ""
        self.capturedarrays = {}
        # Save a copy of the stream:
        self.streamfd = os.dup(self.origstreamfd)
        # Replace the original stream with our write pipe:
        os.dup2(self.pipe_in, self.origstreamfd)
        if self.threaded:
            # Start thread that will read the stream:
            self.workerThread = threading.Thread(target=self.readOutput)
            self.workerThread.start()
            # Make sure that the thread is running and os.read() has executed:
            time.sleep(0.01)

    def stop(self):
        """
        Stop capturing the stream data and save the text in `capturedtext`.
        """
        # Print the escape character to make the readOutput method stop:
        self.origstream.write(self.escape_char)
        # Flush the stream to make sure all our data goes in before
        # the escape character:
        self.origstream.flush()
        if self.threaded:
            # wait until the thread finishes so we are sure that
            # we have until the last character:
            self.workerThread.join()
        else:
            self.readOutput()
        # Close the pipe:
        os.close(self.pipe_in)
        os.close(self.pipe_out)
        # Restore the original stream:
        os.dup2(self.streamfd, self.origstreamfd)
        # Close the duplicate stream:
        os.close(self.streamfd)
        self.capturedarrays = parse_triton_device_print_output_arrays(self.capturedtext)

    def get_capturedarray(self, prefix: Optional[str] = None) -> np.ndarray:
        if prefix is not None:
            return self.capturedarrays.get(prefix, np.empty((0,), dtype=np.float64))

        if not self.capturedarrays:
            return np.empty((0,), dtype=np.float64)
        if len(self.capturedarrays) == 1:
            return next(iter(self.capturedarrays.values()))

        raise ValueError(
            f"Multiple Triton debug prefixes found: {sorted(self.capturedarrays)}. Pass prefix=... or use capturedarrays."
        )

    def readOutput(self):
        """
        Read the stream data (one byte at a time)
        and save the text in `capturedtext`.
        """
        encoding = self.origstream.encoding or "utf-8"
        while True:
            char = os.read(self.pipe_out,1).decode(encoding)
            if not char or self.escape_char in char:
                break
            self.capturedtext += char


@contextlib.contextmanager
def capture_triton_debug_output(stream=None, threaded=True):
    """
    example_fmt: pid (0, 0, 0) idx (0, 52) acc after qk ref: 0.015664
    """    
    grabber = OutputGrabber(stream, threaded)
    grabber.start()
    try:
        yield grabber
    finally:
        torch.cuda.synchronize()
        grabber.stop()