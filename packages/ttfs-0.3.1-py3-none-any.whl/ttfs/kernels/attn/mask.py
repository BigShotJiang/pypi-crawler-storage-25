from ttfs.kernels.attn import constants
import triton.language as tl
from triton.experimental.gluon import language as gl
import ttfs


@ttfs.gluon_jit 
def apply_attn_mask(qk: tl.tensor, block_idx_m, block_idx_n, S_kv,
        block_m_split: tl.constexpr = 1, block_m_split_idx: tl.constexpr = 0, mask_flags: tl.constexpr = 0,
        packgqa: tl.constexpr = -1):
    apply_causal: tl.constexpr = (mask_flags & constants.ATTN_MASK_FLAG_CAUSAL) > 0
    apply_seq: tl.constexpr = (mask_flags & constants.ATTN_MASK_FLAG_SEQ) > 0
    ttfs.mp.logger_warning("apply mask apply_causal=%s, apply_seq=%s, mask_flags=%s", apply_causal, apply_seq, mask_flags)
    BLOCK_N: tl.constexpr = qk.shape[-1]
    # qk is already splitted.
    if packgqa > 0:
        BLOCK_M: tl.constexpr = qk.shape[0] * block_m_split // packgqa
        tl.static_assert((qk.shape[0]) % packgqa == 0, "qk.shape[0] should be divisible by packgqa")
    else:
        BLOCK_M: tl.constexpr = qk.shape[0] * block_m_split 
    if mask_flags == 0:
        return qk
    elif apply_seq and not apply_causal:
        if ttfs.mp.is_gluon():
            offs_n = gl.arange(0, BLOCK_N, 
                layout=gl.SliceLayout(0, qk.type.layout))
        else:
            offs_n = tl.arange(0, BLOCK_N)
        offs_n = offs_n + block_idx_n * BLOCK_N
        qk = tl.where(offs_n[None, :] < S_kv, qk, float("-inf"))
        return qk
    elif apply_causal:
        # TODO try AutoLayout
        if packgqa > 0:
            qk_with_qga = qk.reshape(BLOCK_M // block_m_split, packgqa, BLOCK_N)
            if ttfs.mp.is_gluon():

                offs_n = gl.arange(0, BLOCK_N, 
                    layout=gl.SliceLayout(0, gl.SliceLayout(1, qk_with_qga.type.layout)))
            else:
                offs_n = tl.arange(0, BLOCK_N)
            offs_n = offs_n + block_idx_n * BLOCK_N
            if ttfs.mp.is_gluon():
                offs_m = gl.arange(0, BLOCK_M // block_m_split, 
                    layout=gl.SliceLayout(1, gl.SliceLayout(2, qk_with_qga.type.layout)))
            else:
                offs_m = tl.arange(0, BLOCK_M // block_m_split)
            local_token_idx_base = block_idx_m * BLOCK_M
            if block_m_split_idx == 0:
                offs_m = offs_m + local_token_idx_base
            else:
                offs_m = offs_m + local_token_idx_base + (BLOCK_M // block_m_split) * block_m_split_idx            
            if apply_seq:
                mask = offs_n[None, None, :] < tl.minimum(offs_m[:, None, None] + 1, S_kv)
                # mask = (offs_n[None, :] <= offs_m[:, None]) & (offs_n[None, :] < self.tensors.S_kv)
            else:
                # mask = offs_n[None, None, :] <= offs_m[:, None, None]
                mask = tl.expand_dims(tl.expand_dims(offs_n, 0), 1) <= offs_m[:, None, None]
            if ttfs.mp.is_gluon():
                origin_layout: tl.constexpr = qk.type.layout
            qk = tl.where(mask, qk_with_qga, float("-inf")).reshape(qk.shape)
            if ttfs.mp.is_gluon():
                qk = gl.convert_layout(qk, origin_layout, assert_trivial=True)
        else:
            if ttfs.mp.is_gluon():
                offs_n = gl.arange(0, BLOCK_N, 
                    layout=gl.SliceLayout(0, qk.type.layout))
            else:
                offs_n = tl.arange(0, BLOCK_N)
            offs_n = offs_n + block_idx_n * BLOCK_N
            if ttfs.mp.is_gluon():
                offs_m = gl.arange(0, BLOCK_M // block_m_split, 
                    layout=gl.SliceLayout(1, qk.type.layout))
            else:
                offs_m = tl.arange(0, BLOCK_M // block_m_split)
            local_token_idx_base = block_idx_m * BLOCK_M
            if block_m_split_idx == 0:
                offs_m = offs_m + local_token_idx_base
            else:
                offs_m = offs_m + local_token_idx_base + (BLOCK_M // block_m_split) * block_m_split_idx

            if apply_seq:
                mask = offs_n[None, :] < tl.minimum(offs_m[:, None] + 1, S_kv)
                # mask = (offs_n[None, :] <= offs_m[:, None]) & (offs_n[None, :] < self.tensors.S_kv)
            else:
                mask = offs_n[None, :] <= offs_m[:, None]
            qk = tl.where(mask, qk, float("-inf"))
        return qk 
    else:
        return qk

@ttfs.gluon_jit 
def apply_attn_mask_kq(kq: tl.tensor, block_idx_m, block_idx_n, S_kv,
        block_m_split: tl.constexpr = 1, block_m_split_idx: tl.constexpr = 0, mask_flags: tl.constexpr = 0,
        packgqa: tl.constexpr = -1):
    apply_causal: tl.constexpr = (mask_flags & constants.ATTN_MASK_FLAG_CAUSAL) > 0
    apply_seq: tl.constexpr = (mask_flags & constants.ATTN_MASK_FLAG_SEQ) > 0
    ttfs.mp.logger_warning("apply mask apply_causal=%s, apply_seq=%s, mask_flags=%s", apply_causal, apply_seq, mask_flags)
    BLOCK_N: tl.constexpr = kq.shape[0]
    # kq is already splitted.
    if packgqa > 0:
        BLOCK_M: tl.constexpr = kq.shape[1] * block_m_split // packgqa
        tl.static_assert((kq.shape[1]) % packgqa == 0, "kq.shape[0] should be divisible by packgqa")
    else:
        BLOCK_M: tl.constexpr = kq.shape[1] * block_m_split 
    if mask_flags == 0:
        return kq
    elif apply_seq and not apply_causal:
        if ttfs.mp.is_gluon():
            offs_n = gl.arange(0, BLOCK_N, 
                layout=gl.SliceLayout(1, kq.type.layout))
        else:
            offs_n = tl.arange(0, BLOCK_N)
        offs_n = offs_n + block_idx_n * BLOCK_N
        kq = tl.where(offs_n[:, None] < S_kv, kq, float("-inf"))
        return kq
    elif apply_causal:
        # TODO try AutoLayout
        if packgqa > 0:
            qk_with_qga = kq.reshape(BLOCK_N, BLOCK_M // block_m_split, packgqa)
            if ttfs.mp.is_gluon():
                offs_n = gl.arange(0, BLOCK_N, 
                    layout=gl.SliceLayout(1, gl.SliceLayout(2, qk_with_qga.type.layout)))
            else:
                offs_n = tl.arange(0, BLOCK_N)
            offs_n = offs_n + block_idx_n * BLOCK_N
            if ttfs.mp.is_gluon():
                offs_m = gl.arange(0, BLOCK_M // block_m_split, 
                    layout=gl.SliceLayout(0, gl.SliceLayout(2, qk_with_qga.type.layout)))
            else:
                offs_m = tl.arange(0, BLOCK_M // block_m_split)
            local_token_idx_base = block_idx_m * BLOCK_M
            if block_m_split_idx == 0:
                offs_m = offs_m + local_token_idx_base
            else:
                offs_m = offs_m + local_token_idx_base + (BLOCK_M // block_m_split) * block_m_split_idx
            if apply_seq:
                mask = offs_n[:, None, None] < tl.minimum(offs_m[None, :, None] + 1, S_kv)
                # mask = (offs_n[None, :] <= offs_m[:, None]) & (offs_n[None, :] < self.tensors.S_kv)
            else:
                mask = offs_n[:, None, None] <= offs_m[None, :, None]
            if ttfs.mp.is_gluon():
                origin_layout: tl.constexpr = kq.type.layout
            kq = tl.where(mask, qk_with_qga, float("-inf")).reshape(kq.shape)
            if ttfs.mp.is_gluon():
                kq = gl.convert_layout(kq, origin_layout, assert_trivial=True)

        else:
            if ttfs.mp.is_gluon():
                offs_n = gl.arange(0, BLOCK_N, 
                    layout=gl.SliceLayout(1, kq.type.layout))
            else:
                offs_n = tl.arange(0, BLOCK_N)
            offs_n = offs_n + block_idx_n * BLOCK_N
            if ttfs.mp.is_gluon():
                offs_m = gl.arange(0, BLOCK_M // block_m_split, 
                    layout=gl.SliceLayout(0, kq.type.layout))
            else:
                offs_m = tl.arange(0, BLOCK_M // block_m_split)
            local_token_idx_base = block_idx_m * BLOCK_M
            if block_m_split_idx == 0:
                offs_m = offs_m + local_token_idx_base
            else:
                offs_m = offs_m + local_token_idx_base + (BLOCK_M // block_m_split) * block_m_split_idx

            if apply_seq:
                mask = offs_n[:, None] < tl.minimum(offs_m[None, :] + 1, S_kv)
                # mask = (offs_n[None, :] <= offs_m[:, None]) & (offs_n[None, :] < self.tensors.S_kv)
            else:
                mask = offs_n[:, None] <= offs_m[None, :]
            kq = tl.where(mask, kq, float("-inf"))
        return kq
    else:
        return kq

