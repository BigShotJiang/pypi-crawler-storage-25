import dataclasses
from typing import Any, Optional, Self

import torch

from ttfs.core.aggtype import aggregate_replace, get_scalar_tensor, triton_jit, aggregate
import triton.language as tl
from triton.experimental.gluon import language as gl
from ttfs.core.mp import get_num_warps
import ttfs.ops.cuda as cuda_ops
from ttfs.ops.constants import CUDA_WARP_SIZE
from ttfs.utils import div_up

@triton_jit
def _tt_divmod(a, b):
    return a // b, a % b


@triton_jit
def _tt_round_up(a, b):
    return tl.cdiv(a, b) * b


@triton_jit
def _tt_floor_power_of_2(val):
    res = 1
    for i in range(1, 31):
        candidate = 1 << i
        if candidate <= val:
            res = candidate
    return res


def _host_floor_power_of_2(val: int) -> int:
    if val <= 1:
        return 1
    return 1 << (val.bit_length() - 1)

@aggregate
class WorkTileInfo:
    tile_idx: Any
    is_valid_tile: Any

@aggregate
class WorkTileInfoV2:
    block_idx: tl.tensor 
    head_idx: tl.tensor
    batch_idx: tl.tensor
    split_idx: tl.tensor
    is_valid_tile: tl.tensor


@aggregate
class TileSchedulerBase:
    """Protocol defining the interface all tile schedulers must implement.

    Schedulers are responsible for:
    1. Coordinate mapping: linear tile index -> (m_block, head, batch, split)
    2. Work distribution: how to get the next tile (static grid-stride vs CLC dynamic)
    """

    def get_current_work(self) -> tuple[Self, WorkTileInfo]:
        """Get the current work tile coordinates."""
        ...

    def initial_work_tile_info(self) -> tuple[Self, WorkTileInfo]:
        """Get the initial work tile for this CTA."""
        ...

    def advance_to_next_work(self) -> tuple[Self, WorkTileInfo]:
        """Consumer-side advance: move to next tile and return it.

        For static schedulers: grid-stride increment + get_current_work.
        For CLC schedulers: consumer wait + get_current_work + consumer release + state advance.
        """
        ...

    def prefetch_next_work(self) -> None:
        """Producer-side prefetch of next work tile (no-op for static schedulers).

        For CLC schedulers: producer acquire + issue CLC query + producer state advance.
        Only called by the scheduler warp.
        """
        ...

    def producer_tail(self) -> None:
        """Producer-side cleanup after the last tile.

        No-op for static schedulers. For CLC schedulers: pipeline producer_tail.
        """
        ...

@dataclasses.dataclass
class TileSchedulerArguments:
    num_block: int
    num_head: int
    num_batch: int
    num_splits: int
    seqlen_k: int
    headdim: int
    headdim_v: int
    total_q: int
    tile_shape_mn: tuple[int, int]
    cluster_shape_mn: tuple[int, int] = (1, 1)
    mCuSeqlensQ: Optional[torch.Tensor] = None
    mSeqUsedQ: Optional[torch.Tensor] = None
    qhead_per_kvhead_packgqa: int = 1
    element_size: int = 2 # in bytes
    is_persistent: bool = False
    lpt: bool = False
    is_split_kv: bool = False
    head_swizzle: bool = False
    use_cluster_idx: bool = False

@aggregate
class FastDivmodDivisor:
    divisor: tl.tensor
    is_power_of_2: Any = False

    @staticmethod
    def create(divisor):
        return FastDivmodDivisor(divisor=divisor)

    @triton_jit
    def div(self, value):
        return value // self.divisor

    @triton_jit
    def mod(self, value):
        return value % self.divisor

    @triton_jit
    def divmod(self, value):
        return _tt_divmod(value, self.divisor)


@aggregate
class SingleTileSchedulerParams:
    num_block: tl.tensor
    num_head: tl.constexpr
    num_batch: tl.tensor
    num_splits: tl.tensor
    num_splits_divmod: FastDivmodDivisor
    is_split_kv: tl.constexpr = False
    cluster_shape_mn: tl.constexpr = (1, 1)
    use_cluster_idx: tl.constexpr = False

    @staticmethod
    def create(args: TileSchedulerArguments):
        return SingleTileSchedulerParams(
            num_block=args.num_block,
            num_head=args.num_head,
            num_batch=args.num_batch,
            num_splits=args.num_splits,
            num_splits_divmod=FastDivmodDivisor(args.num_splits),
            is_split_kv=args.is_split_kv,
            cluster_shape_mn=args.cluster_shape_mn,
            use_cluster_idx=args.use_cluster_idx,
        )


@aggregate
class SingleTileScheduler(TileSchedulerBase):
    params: SingleTileSchedulerParams
    block_idx: tl.tensor
    head_idx: tl.tensor
    batch_idx: tl.tensor
    _is_first_block: tl.tensor = True

    @triton_jit
    @staticmethod
    def create(params: SingleTileSchedulerParams):
        cluster_shape_m: tl.constexpr = params.cluster_shape_mn[0]
        head_idx = gl.program_id(1)
        batch_idx = gl.program_id(2)
        if params.use_cluster_idx and cluster_shape_m > 1:
            block_idx, _, _ = cuda_ops.cluster_ids()
        else:
            block_idx = gl.program_id(0)
        return SingleTileScheduler(
            params=params,
            block_idx=block_idx,
            head_idx=head_idx,
            batch_idx=batch_idx,
            _is_first_block=get_scalar_tensor(True),
        )

    @staticmethod
    def get_grid_shape(params: SingleTileSchedulerParams):
        assert params.cluster_shape_mn[1] == 1, "Only cluster_shape_mn[1] == 1 is supported"
        if params.use_cluster_idx:
            grid_x = params.num_block * params.cluster_shape_mn[0]
        else:
            grid_x = ((params.num_block + params.cluster_shape_mn[0] - 1) // params.cluster_shape_mn[0]) * params.cluster_shape_mn[0]
        return (grid_x, params.num_head * params.num_splits, params.num_batch)

    @triton_jit
    def get_current_work(self):
        if self.params.is_split_kv:
            head_idx, split_idx = self.params.num_splits_divmod.divmod(self.head_idx)
        else:
            head_idx = self.head_idx
            split_idx = 0
        work = WorkTileInfo(
            tile_idx=(self.block_idx, head_idx, self.batch_idx, split_idx),
            is_valid_tile=self._is_first_block,
        )
        return self, work

    @triton_jit
    def initial_work_tile_info(self):
        return self.get_current_work()

    @triton_jit
    def prefetch_next_work(self):
        pass
    @triton_jit

    def advance_to_next_work(self):
        res = aggregate_replace(self, _is_first_block=get_scalar_tensor(False))
        res, work = res.get_current_work()
        return res, work
    @triton_jit

    def producer_tail(self):
        pass


@aggregate
class StaticPersistentTileSchedulerParams:
    num_block_cluster_divmod: FastDivmodDivisor
    num_head_divmod: FastDivmodDivisor
    total_blocks_cluster: tl.tensor
    cluster_shape_m: Any = 1

    @staticmethod
    def create(args: TileSchedulerArguments):
        num_block_cluster = div_up(args.num_block, args.cluster_shape_mn[0] * args.cluster_shape_mn[1])
        total_blocks_cluster = num_block_cluster * args.num_head * args.num_batch
        return StaticPersistentTileSchedulerParams(
            num_block_cluster_divmod=FastDivmodDivisor(num_block_cluster),
            num_head_divmod=FastDivmodDivisor(args.num_head),
            total_blocks_cluster=total_blocks_cluster,
            cluster_shape_m=args.cluster_shape_mn[0],
        )


@aggregate
class StaticPersistentTileScheduler(TileSchedulerBase):
    params: StaticPersistentTileSchedulerParams
    tile_idx: Any

    @triton_jit
    @staticmethod
    def create(params: StaticPersistentTileSchedulerParams):
        if params.cluster_shape_m > 1:
            tile_idx, _, _ = cuda_ops.cluster_ids()
        else:
            tile_idx = gl.program_id(0)
        return StaticPersistentTileScheduler(params=params, tile_idx=tile_idx)

    @staticmethod
    def get_grid_shape(params: StaticPersistentTileSchedulerParams, sm_count):
        max_ctas = (sm_count // params.cluster_shape_m) * params.cluster_shape_m
        grid_x = min(max_ctas, params.total_blocks_cluster * params.cluster_shape_m)
        return (grid_x, 1, 1)

    @triton_jit
    def get_current_work(self):
        hn_idx, block_idx = self.params.num_block_cluster_divmod.divmod(self.tile_idx)
        batch_idx, head_idx = self.params.num_head_divmod.divmod(hn_idx)
        is_valid = self.tile_idx < self.params.total_blocks_cluster
        work = WorkTileInfo(
            tile_idx=(block_idx, head_idx, batch_idx, 0),
            is_valid_tile=is_valid,
        )
        return self, work

    @triton_jit
    def initial_work_tile_info(self):
        return self.get_current_work()
    @triton_jit

    def prefetch_next_work(self):
        pass
    @triton_jit

    def advance_to_next_work(self):
        if self.params.cluster_shape_m == 1:
            next_tile_idx = self.tile_idx + tl.num_programs(0)
        else:
            next_tile_idx = self.tile_idx + tl.num_programs(0) // self.params.cluster_shape_m
        res = aggregate_replace(self, tile_idx=next_tile_idx)
        res, work = res.get_current_work()
        return res, work
    @triton_jit

    def producer_tail(self):
        pass


@aggregate
class SingleTileLPTSchedulerParams:
    total_blocks: tl.tensor
    num_splits: tl.tensor
    num_block: tl.tensor
    num_head: tl.constexpr
    num_batch: tl.tensor
    l2_minor: Any
    num_head_divmod: FastDivmodDivisor
    l2_minor_divmod: FastDivmodDivisor
    l2_major_divmod: FastDivmodDivisor
    l2_minor_residual_divmod: FastDivmodDivisor
    num_hb_quotient: Any
    num_splits_divmod: FastDivmodDivisor
    is_split_kv: tl.constexpr = False
    cluster_shape_m: tl.constexpr = 1
    lpt: tl.constexpr = True
    enable_clc: tl.constexpr = False

    @staticmethod
    def create(args: TileSchedulerArguments, enable_clc=False):
        size_one_kv_head = args.seqlen_k * (args.headdim + args.headdim_v) * args.element_size
        size_l2 = 50 * 1024 * 1024
        swizzle_raw = size_l2 // size_one_kv_head
        swizzle = 1 if size_l2 < size_one_kv_head else _host_floor_power_of_2(swizzle_raw)
        num_hb_quotient = (args.num_head * args.num_batch) // swizzle
        num_hb_remainder = (args.num_head * args.num_batch) % swizzle
        return SingleTileLPTSchedulerParams(
            total_blocks=args.num_block * args.num_head * args.num_batch,
            num_splits=args.num_splits,
            num_block=args.num_block,
            num_head=args.num_head,
            num_batch=args.num_batch,
            l2_minor=swizzle,
            num_head_divmod=FastDivmodDivisor(args.num_head),
            l2_minor_divmod=FastDivmodDivisor(swizzle),
            l2_major_divmod=FastDivmodDivisor(swizzle * args.num_block),
            l2_minor_residual_divmod=FastDivmodDivisor(max(num_hb_remainder, 1)),
            num_hb_quotient=num_hb_quotient,
            num_splits_divmod=FastDivmodDivisor(args.num_splits),
            is_split_kv=args.is_split_kv,
            cluster_shape_m=args.cluster_shape_mn[0],
            lpt=args.lpt,
            enable_clc=enable_clc,
        )


@aggregate
class SingleTileLPTScheduler(TileSchedulerBase):
    params: SingleTileLPTSchedulerParams
    tile_idx: tl.tensor
    split_idx: tl.tensor

    @triton_jit
    @staticmethod
    def create(params: SingleTileLPTSchedulerParams):
        return SingleTileLPTScheduler(
            params=params,
            tile_idx=gl.program_id(0),
            split_idx=gl.program_id(1),
        )

    @staticmethod
    def get_grid_shape(params: SingleTileLPTSchedulerParams):
        if params.enable_clc:
            raise NotImplementedError("CLC scheduling is not implemented in tile_schr.py")
        return (params.total_blocks, params.num_splits, 1)

    @triton_jit
    def get_current_work(self):
        tl.static_assert(not self.params.enable_clc, "CLC scheduling is not implemented in tile_schr.py")
        bidhb, l2_mod = self.params.l2_major_divmod.divmod(self.tile_idx)
        if bidhb < self.params.num_hb_quotient:
            block, bidhb_residual = self.params.l2_minor_divmod.divmod(l2_mod)
        else:
            block, bidhb_residual = self.params.l2_minor_residual_divmod.divmod(l2_mod)
        bidhb_actual = bidhb * self.params.l2_minor + bidhb_residual
        batch_idx, head_idx = self.params.num_head_divmod.divmod(bidhb_actual)
        if self.params.lpt:
            block = self.params.num_block - 1 - block
        is_valid = self.tile_idx < self.params.total_blocks
        work = WorkTileInfo(
            tile_idx=(block, head_idx, batch_idx, self.split_idx),
            is_valid_tile=is_valid,
        )
        return self, work

    @triton_jit
    def initial_work_tile_info(self):
        return self.get_current_work()
    @triton_jit

    def prefetch_next_work(self):
        pass
    @triton_jit

    def advance_to_next_work(self):
        res = aggregate_replace(self, tile_idx=self.params.total_blocks)
        res, work = res.get_current_work()
        return res, work
    @triton_jit

    def producer_tail(self):
        pass


@aggregate
class SingleTileLPTBwdSchedulerParams:
    total_blocks: tl.tensor
    num_block: tl.tensor
    l2_minor: Any
    num_head_divmod: FastDivmodDivisor
    l2_minor_divmod: FastDivmodDivisor
    l2_major_divmod: FastDivmodDivisor
    l2_minor_residual_divmod: FastDivmodDivisor
    num_hb_quotient: Any
    cluster_shape_m: Any = 1
    spt: Any = True

    @staticmethod
    def create(args: TileSchedulerArguments):
        size_l2 = 50 * 1024 * 1024
        size_one_qdo_head = args.seqlen_k * (args.headdim + args.headdim_v) * args.element_size
        size_one_dqaccum_head = args.seqlen_k * args.headdim * 4
        size_one_head = size_one_qdo_head + size_one_dqaccum_head
        swizzle_raw = size_l2 // size_one_head
        swizzle = 1 if size_l2 < size_one_head else _host_floor_power_of_2(swizzle_raw)
        num_hb_quotient = (args.num_head * args.num_batch) // swizzle
        num_hb_remainder = (args.num_head * args.num_batch) % swizzle
        num_block = div_up(args.num_block, args.cluster_shape_mn[0])
        total_blocks = (num_block * args.cluster_shape_mn[0]) * args.num_head * args.num_batch
        return SingleTileLPTBwdSchedulerParams(
            total_blocks=total_blocks,
            num_block=num_block,
            l2_minor=swizzle,
            num_head_divmod=FastDivmodDivisor(args.num_head),
            l2_minor_divmod=FastDivmodDivisor(swizzle),
            l2_major_divmod=FastDivmodDivisor(swizzle * num_block),
            l2_minor_residual_divmod=FastDivmodDivisor(max(num_hb_remainder, 1)),
            num_hb_quotient=num_hb_quotient,
            cluster_shape_m=args.cluster_shape_mn[0],
            spt=args.lpt,
        )


@aggregate
class SingleTileLPTBwdScheduler(TileSchedulerBase):
    params: SingleTileLPTBwdSchedulerParams
    tile_idx: tl.tensor

    @triton_jit
    @staticmethod
    def create(params: SingleTileLPTBwdSchedulerParams):
        return SingleTileLPTBwdScheduler(params=params, tile_idx=gl.program_id(0))

    @staticmethod
    def get_grid_shape(params: SingleTileLPTBwdSchedulerParams):
        return (params.total_blocks, 1, 1)

    @triton_jit
    def get_current_work(self):
        cluster_idx = self.tile_idx // self.params.cluster_shape_m
        bidhb, l2_mod = self.params.l2_major_divmod.divmod(cluster_idx)
        if bidhb < self.params.num_hb_quotient:
            block, bidhb_residual = self.params.l2_minor_divmod.divmod(l2_mod)
        else:
            block, bidhb_residual = self.params.l2_minor_residual_divmod.divmod(l2_mod)
        bidhb_actual = bidhb * self.params.l2_minor + bidhb_residual
        batch_idx, head_idx = self.params.num_head_divmod.divmod(bidhb_actual)
        if self.params.spt:
            block = self.params.num_block - 1 - block
        if self.params.cluster_shape_m > 1:
            bidx_in_cluster = cuda_ops.cluster_cta_ids()
            block = block * self.params.cluster_shape_m + bidx_in_cluster[0]
        is_valid = self.tile_idx < self.params.total_blocks
        work = WorkTileInfo(
            tile_idx=(block, head_idx, batch_idx, 0),
            is_valid_tile=is_valid,
        )
        return self, work

    @triton_jit
    def initial_work_tile_info(self):
        return self.get_current_work()
    @triton_jit

    def prefetch_next_work(self):
        pass
    @triton_jit

    def advance_to_next_work(self):
        res = aggregate_replace(self, tile_idx=self.params.total_blocks)
        res, work = res.get_current_work()
        return res, work
    @triton_jit

    def producer_tail(self):
        pass


@aggregate
class SingleTileVarlenSchedulerParams:
    num_head: tl.constexpr
    num_batch: tl.tensor
    total_q: tl.tensor
    num_splits: tl.tensor
    max_kvblock_in_l2: tl.constexpr
    tile_shape_mn: tl.constexpr
    mCuSeqlensQ: Any = None
    mSeqUsedQ: Any = None
    qhead_per_kvhead_packgqa: tl.constexpr = 1
    lpt: tl.constexpr = False
    is_split_kv: tl.constexpr = False
    head_swizzle: tl.constexpr = False
    cluster_shape_m: tl.constexpr = 1

    @staticmethod
    def create(args: TileSchedulerArguments):
        size_l2 = 50 * 1024 * 1024
        max_kvblock_in_l2 = size_l2 // (
            (args.headdim + args.headdim_v) * args.element_size * args.tile_shape_mn[1]
        )
        return SingleTileVarlenSchedulerParams(
            num_head=args.num_head,
            num_batch=args.num_batch,
            total_q=args.total_q,
            num_splits=args.num_splits,
            max_kvblock_in_l2=max_kvblock_in_l2,
            tile_shape_mn=args.tile_shape_mn,
            mCuSeqlensQ=args.mCuSeqlensQ,
            mSeqUsedQ=args.mSeqUsedQ,
            qhead_per_kvhead_packgqa=args.qhead_per_kvhead_packgqa,
            lpt=args.lpt,
            is_split_kv=args.is_split_kv,
            head_swizzle=args.head_swizzle,
            cluster_shape_m=args.cluster_shape_mn[0],
        )


@aggregate
class SingleTileVarlenScheduler(TileSchedulerBase):
    params: SingleTileVarlenSchedulerParams
    tile_idx: tl.tensor
    split_idx: tl.tensor
    _is_first_block: Any = True

    @triton_jit
    @staticmethod
    def create(params: SingleTileVarlenSchedulerParams):
        tile_idx = gl.program_id(0)
        split_idx = gl.program_id(1)
        return SingleTileVarlenScheduler(
            params=params,
            tile_idx=tile_idx,
            split_idx=split_idx,
            _is_first_block=get_scalar_tensor(True),
        )

    @staticmethod
    def get_grid_shape(params: SingleTileVarlenSchedulerParams):
        total_blocks_max = (
            params.total_q
            + params.num_batch * (params.cluster_shape_m * params.tile_shape_mn[0] - 1)
        ) // params.tile_shape_mn[0]
        total_blocks_max = total_blocks_max // params.cluster_shape_m * params.cluster_shape_m
        return (total_blocks_max * params.num_head, params.num_splits, 1)

    @triton_jit
    def _get_num_m_blocks(self, lane, bidb_start):
        batch_idx = lane + bidb_start
        if self.params.mSeqUsedQ is not None:
            seqlen = 0
            if batch_idx < self.params.num_batch:
                seqlen = gl.load(self.params.mSeqUsedQ + batch_idx)
        else:
            assert self.params.mCuSeqlensQ is not None
            cur_cu_seqlen = 0
            if batch_idx <= self.params.num_batch:
                cur_cu_seqlen = gl.load(self.params.mCuSeqlensQ + batch_idx)
            next_cu_seqlen = cuda_ops.shfl_sync_down(cur_cu_seqlen, offset=1)
            seqlen = next_cu_seqlen - cur_cu_seqlen
        if self.params.qhead_per_kvhead_packgqa > 1:
            seqlen *= self.params.qhead_per_kvhead_packgqa
        return (
            tl.cdiv(tl.cdiv(seqlen, self.params.tile_shape_mn[0]), self.params.cluster_shape_m)
            if batch_idx < self.params.num_batch and lane < CUDA_WARP_SIZE - 1
            else 0
        )

    @triton_jit
    def _varlen_coord_map(self) -> WorkTileInfo:
        lane_idx = cuda_ops.lane_id()
        num_m_blocks = self._get_num_m_blocks(lane_idx, bidb_start=0)
        num_m_blocks_cumulative = cuda_ops.warp_prefix_sum(num_m_blocks, lane_idx)
        m_blocks_in_group = cuda_ops.shfl_sync_idx(num_m_blocks_cumulative, CUDA_WARP_SIZE - 1)

        block = 0
        head_idx = 0
        batch_idx = 0
        next_tile_idx = self.tile_idx // self.params.cluster_shape_m
        group_end_tile = m_blocks_in_group * self.params.num_head

        while group_end_tile <= next_tile_idx:
            batch_idx += CUDA_WARP_SIZE - 1
            if batch_idx >= self.params.num_batch:
                batch_idx = self.params.num_batch
                group_end_tile = next_tile_idx + 1
            else:
                num_m_blocks = self._get_num_m_blocks(lane_idx, bidb_start=batch_idx)
                num_m_blocks_cumulative = cuda_ops.warp_prefix_sum(num_m_blocks, lane_idx)
                m_blocks_in_group = cuda_ops.shfl_sync_idx(num_m_blocks_cumulative, CUDA_WARP_SIZE - 1)
                group_end_tile += m_blocks_in_group * self.params.num_head

        is_valid = False
        if batch_idx >= self.params.num_batch:
            block = 0
            head_idx = 0
            batch_idx = self.params.num_batch
        else:
            group_start_tile = group_end_tile - m_blocks_in_group * self.params.num_head
            batch_idx_in_group = cuda_ops.popc(
                cuda_ops.vote_ballot_sync(
                    group_start_tile + num_m_blocks_cumulative * self.params.num_head <= next_tile_idx
                )
            )
            batch_idx += batch_idx_in_group
            if batch_idx_in_group == 0:
                num_m_blocks_prev_lane = 0
            else:
                num_m_blocks_prev_lane = cuda_ops.shfl_sync_idx(
                    num_m_blocks_cumulative, batch_idx_in_group - 1
                )
            num_m_blocks = cuda_ops.shfl_sync_idx(num_m_blocks, batch_idx_in_group)
            mh_block = next_tile_idx - group_start_tile - num_m_blocks_prev_lane * self.params.num_head
            if self.params.lpt or self.params.head_swizzle:
                num_n_blocks = (
                    num_m_blocks
                    * self.params.tile_shape_mn[0]
                    * self.params.cluster_shape_m
                    // self.params.qhead_per_kvhead_packgqa
                    // self.params.tile_shape_mn[1]
                )
                nheads_in_l2 = (
                    16
                    if num_n_blocks * 16 <= self.params.max_kvblock_in_l2
                    else (
                        8
                        if num_n_blocks * 8 <= self.params.max_kvblock_in_l2
                        else (
                            4
                            if num_n_blocks * 4 <= self.params.max_kvblock_in_l2
                            else (2 if num_n_blocks * 2 <= self.params.max_kvblock_in_l2 else 1)
                        )
                    )
                )
                nheads_in_l2 = min(nheads_in_l2, self.params.num_head)
                mh_in_l2 = nheads_in_l2 * num_m_blocks
                section_idx = mh_block // mh_in_l2
                l2_mod = mh_block - section_idx * mh_in_l2
                nheads_in_this_section = (
                    nheads_in_l2
                    if nheads_in_l2 * (section_idx + 1) <= self.params.num_head
                    else self.params.num_head - section_idx * nheads_in_l2
                )
                block = l2_mod // nheads_in_this_section
                head_idx_residual = l2_mod - block * nheads_in_this_section
                head_idx = section_idx * nheads_in_l2 + head_idx_residual
                if self.params.lpt:
                    block = num_m_blocks - 1 - block
            else:
                head_idx = mh_block // num_m_blocks
                block = mh_block - head_idx * num_m_blocks

            is_valid = self._is_first_block & (batch_idx < self.params.num_batch)
            if self.params.cluster_shape_m > 1:
                bidx_in_cluster = cuda_ops.cluster_cta_ids()
                block = block * self.params.cluster_shape_m + bidx_in_cluster[0]

        split_idx = self.split_idx if self.params.is_split_kv else 0
        return WorkTileInfo(
            tile_idx=(block, head_idx, batch_idx, split_idx),
            is_valid_tile=is_valid,
        )

    @triton_jit
    def get_current_work(self):
        work = self._varlen_coord_map()
        return self, work

    @triton_jit
    def initial_work_tile_info(self):
        return self.get_current_work()
    @triton_jit

    def prefetch_next_work(self):
        pass
    @triton_jit

    def advance_to_next_work(self):
        res = aggregate_replace(self, _is_first_block=get_scalar_tensor(False))
        res, work = res.get_current_work()
        return res, work
    @triton_jit

    def producer_tail(self):
        pass
