from typing import Any

from ttfs.core.aggtype import triton_jit, aggregate
import triton.language as tl

@aggregate
class SeqlenInfoQK:
    seqlen_q: tl.tensor
    seqlen_k: tl.tensor

@aggregate
class BlockInfo:
    tile_m: tl.constexpr
    tile_n: tl.constexpr
    is_causal: tl.constexpr
    is_local: tl.constexpr = False
    is_split_kv: tl.constexpr = False
    window_size_left: Any = None
    window_size_right: Any = None
    qhead_per_kvhead_packgqa: tl.constexpr = 1

    @triton_jit 
    def get_n_block_min_max(self, seqlen_info, m_block, split_idx = 0, num_splits = 1):
        n_block_max = tl.cdiv(seqlen_info.seqlen_k, self.tile_n)
        if self.is_causal or (self.is_local and self.window_size_right is not None):
            m_idx_max = (m_block + 1) * self.tile_m
            if self.qhead_per_kvhead_packgqa > 1:
                m_idx_max = tl.cdiv(m_idx_max, self.qhead_per_kvhead_packgqa)
            n_idx = m_idx_max + seqlen_info.seqlen_k - seqlen_info.seqlen_q
            if self.is_causal:
                n_idx_right = n_idx
            else:
                n_idx_right = n_idx + self.window_size_right
            n_block_max = min(n_block_max, tl.cdiv(n_idx_right, self.tile_n))

        n_block_min = 0
        if self.is_local and self.window_size_left is not None:
            m_idx_min = m_block * self.tile_m
            if self.qhead_per_kvhead_packgqa > 1:
                m_idx_min = m_idx_min // self.qhead_per_kvhead_packgqa
            n_idx = m_idx_min + seqlen_info.seqlen_k - seqlen_info.seqlen_q
            n_idx_left = n_idx - self.window_size_left
            n_block_min = max(n_idx_left // self.tile_n, 0)

        if self.is_split_kv:
            num_n_blocks_per_split = (
                0
                if n_block_max <= n_block_min
                else (n_block_max - n_block_min + num_splits - 1) // num_splits
            )
            n_block_min = n_block_min + split_idx * num_n_blocks_per_split
            n_block_max = min(n_block_min + num_n_blocks_per_split, n_block_max)
        return n_block_min, n_block_max

    @triton_jit
    def get_m_block_min_max(self, seqlen_info, n_block):
        m_block_max = tl.cdiv(seqlen_info.seqlen_q, self.tile_m)
        m_block_min = 0
        if self.is_causal or (self.is_local and self.window_size_right is not None):
            n_idx_min = n_block * self.tile_n
            m_idx = n_idx_min + seqlen_info.seqlen_q - seqlen_info.seqlen_k
            m_idx_right = m_idx if self.is_causal else m_idx - self.window_size_right
            m_block_min = max(m_block_min, m_idx_right // self.tile_m)

        if self.is_local and self.window_size_left is not None:
            n_idx_max = (n_block + 1) * self.tile_n
            m_idx = n_idx_max + seqlen_info.seqlen_q - seqlen_info.seqlen_k
            m_idx_left = m_idx + self.window_size_left
            m_block_max = min(m_block_max, tl.cdiv(m_idx_left, self.tile_m))
        return m_block_min, m_block_max

    @triton_jit
    def get_n_block_min_causal_local_mask(self, seqlen_info, m_block, n_block_min):
        m_idx_min = m_block * self.tile_m
        if self.qhead_per_kvhead_packgqa > 1:
            m_idx_min = m_idx_min // self.qhead_per_kvhead_packgqa
        n_idx = m_idx_min + seqlen_info.seqlen_k - seqlen_info.seqlen_q
        if not self.is_local or self.window_size_right is None:
            n_idx_right = n_idx

        else:
            n_idx_right = n_idx + self.window_size_right

        return max(n_block_min, n_idx_right // self.tile_n)

    @triton_jit
    def get_n_block_min_before_local_mask(self, seqlen_info, m_block, n_block_min):
        if not self.is_local or self.window_size_left is None:
            return n_block_min
        else:
            m_idx_max = (m_block + 1) * self.tile_m
            if self.qhead_per_kvhead_packgqa > 1:
                m_idx_max = tl.cdiv(m_idx_max, self.qhead_per_kvhead_packgqa)
            n_idx = m_idx_max + seqlen_info.seqlen_k - seqlen_info.seqlen_q
            n_idx_left = n_idx - self.window_size_left
            return max(n_block_min, tl.cdiv(n_idx_left, self.tile_n))