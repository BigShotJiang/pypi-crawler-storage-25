import triton.language as tl


HOPPER_FWD_WARP_SCHR_WG1 = tl.constexpr(8)
HOPPER_FWD_WARP_SCHR_WG2 = tl.constexpr(9)
HOPPER_FWD_WARP_SCHR_WG3 = tl.constexpr(10)


ATTN_MASK_FLAG_CAUSAL = tl.constexpr(1 << 0)
ATTN_MASK_FLAG_SEQ = tl.constexpr(1 << 1)


ATTN_TILE_SCHR_SINGLE_TILE = tl.constexpr(0)
ATTN_TILE_SCHR_STATIC_PERSISTENT = tl.constexpr(1)
ATTN_TILE_SCHR_SINGLE_TILE_LPT = tl.constexpr(2)
ATTN_TILE_SCHR_SINGLE_TILE_LPT_BWD = tl.constexpr(3)
ATTN_TILE_SCHR_SINGLE_TILE_VARLEN = tl.constexpr(4)
