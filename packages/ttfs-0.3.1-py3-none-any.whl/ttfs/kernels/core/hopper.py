

import ttfs 
import triton 
import torch
from triton.experimental.gluon import language as gl
import itertools

@ttfs.constexpr_function
def get_warps_per_cta(BLOCK_M, BLOCK_N, num_warps, is_flash):
    assert num_warps >= 4
    if is_flash:
        return [num_warps, 1]
    warps_per_cta = [4, 1]
    m = 16
    # Tile the atom until we have enough warps.
    while warps_per_cta[0] * warps_per_cta[1] != num_warps:
        # Tile along M only if it would not cause broadcasting.
        if BLOCK_M > m * warps_per_cta[0]:
            warps_per_cta[0] *= 2
        else:
            warps_per_cta[1] *= 2
    return warps_per_cta

@ttfs.constexpr_function
def get_instr_shape_n(BLOCK_M, BLOCK_N, num_warps):
    m = 16
    mReps = triton.cdiv(BLOCK_M, m)
    nReps = triton.cdiv(num_warps, mReps)
    maxN = max(BLOCK_N // nReps, 8)
    n = 256
    while n > maxN or BLOCK_N % n != 0:
        n -= 8
    assert n >= 8, "expected to find a valid n"
    return n

@ttfs.constexpr_function
def pick_wgmma_layout(dtype, BLOCK_M, BLOCK_N, num_warps, is_flash: bool = False):
    m = 16
    k = 256 // dtype.primitive_bitwidth
    n = get_instr_shape_n(BLOCK_M, BLOCK_N, num_warps)
    warps_per_cta = get_warps_per_cta(BLOCK_M, BLOCK_N, num_warps, is_flash)
    return gl.NVMMADistributedLayout(
        version=[3, 0],
        warps_per_cta=warps_per_cta,
        instr_shape=[m, n, k],
    )

def find_matmul_configs(occupancy, dtype, num_buffers=1):
    dtype_bytes = torch.tensor([], dtype=dtype).element_size()

    # Assume ~1 KB of smem used by mbarriers, compiler-generated code, etc.
    smem = 228 * 1024 // occupancy - 1024

    configs = []
    BLOCK_MNK = [32, 64, 128, 256]
    for BLOCK_M, BLOCK_N, BLOCK_K, num_warps in itertools.product(BLOCK_MNK, BLOCK_MNK, BLOCK_MNK, [4, 8]):
        # Assume ~16 regs per thread of baseline usage.
        regs = 64 * 1024 // occupancy - 16 * num_warps * 32

        a_smem = BLOCK_M * BLOCK_K * dtype_bytes
        b_smem = BLOCK_N * BLOCK_K * dtype_bytes
        acc_smem = BLOCK_M * BLOCK_N * dtype_bytes
        # SMEM for A and B does not coexist with C.
        if max((a_smem + b_smem) * num_buffers, acc_smem) > smem:
            continue

        # The accumulator is the only in-memory tensor in f32.
        acc_regs = BLOCK_M * BLOCK_N
        # Max regs per thread is 256. Being near this can also cause spills.
        if acc_regs // num_warps // 32 >= 256:
            continue
        if acc_regs > regs:
            continue

        instr_shape_n = get_instr_shape_n(BLOCK_M, BLOCK_N, num_warps)
        configs.append((BLOCK_M, BLOCK_N, BLOCK_K, num_warps, instr_shape_n, occupancy))

    def filter_configs(configs, instr_shape_n):
        max_n_configs = [cfg for cfg in configs if cfg[4] == instr_shape_n]
        # Filter for configs with the largest BLOCK_M * BLOCK_K.
        max_block_mk = max(cfg[0] * cfg[2] for cfg in max_n_configs)
        return [cfg for cfg in max_n_configs if cfg[0] * cfg[2] == max_block_mk]

    top_instr_shape_n = sorted({cfg[4] for cfg in configs}, reverse=True)
    result_configs = filter_configs(configs, top_instr_shape_n[0])
    if len(top_instr_shape_n) > 1:
        result_configs += filter_configs(configs, top_instr_shape_n[1])
    return result_configs
