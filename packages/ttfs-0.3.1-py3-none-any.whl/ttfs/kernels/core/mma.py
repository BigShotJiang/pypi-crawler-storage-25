import ttfs 
import triton.language as tl
from triton.experimental.gluon.language.nvidia.ampere import mma_v2
from ttfs.tensor.io import PipelineConsumerBase
from triton.experimental.gluon import language as gl
from triton.experimental.gluon.language.nvidia.hopper import warpgroup_mma, warpgroup_mma_wait


from ttfs.core.layout import get_default_mma

@tl.core.builtin
def _empty_wait_for_mma_v2(num_outstanding=0, deps=None, _semantic=None):
    if deps is None:
        raise ValueError("simple mma deps must be given")
    if len(deps) == 1:
        return deps[0]
    return tuple(deps)

@ttfs.gluon_jit
def _reshape_smem(a_smem, mn: tl.constexpr, is_a: tl.constexpr, is_tr: tl.constexpr):
    if is_a:
        if is_tr: # [K, M]
            # gluon smem don't support slice-reshape, but support reshape-slice, so we need to avoid reshape if not necessary.
            if len(a_smem.shape) != 2 or a_smem.shape[1] != mn:
                a_smem = ttfs.gl.ops.reshape(a_smem, [-1, mn])
            a_smem = a_smem.permute((1, 0))
        else: # [M, K]
            if len(a_smem.shape) != 2 or a_smem.shape[0] != mn:
                a_smem = ttfs.gl.ops.reshape(a_smem, [mn, -1])
    else:
        if is_tr: # [N, K]
            if len(a_smem.shape) != 2 or a_smem.shape[0] != mn:
                a_smem = ttfs.gl.ops.reshape(a_smem, [mn, -1])
            a_smem = a_smem.permute((1, 0))
        else:
            if len(a_smem.shape) != 2 or a_smem.shape[1] != mn:
                a_smem = ttfs.gl.ops.reshape(a_smem, [-1, mn])
    return a_smem

@ttfs.aggregate
class AmpereMma:
    shape_mn: tl.constexpr 
    dtype: tl.constexpr 
    is_flash: tl.constexpr = False
    layout: tl.constexpr = None
    acc_type: tl.constexpr = tl.float32

    def __post_init__(self):
        shape_mn = tl.core._unwrap_if_constexpr(self.shape_mn)
        dtype = tl.core._unwrap_if_constexpr(self.dtype)
        num_warps = ttfs.mp.get_num_warps_in_init()
        is_flash = tl.core._unwrap_if_constexpr(self.is_flash)
        self.layout = get_default_mma(2, dtype, [shape_mn[0], shape_mn[1]], num_warps, is_chained=is_flash)

    @ttfs.gluon_jit 
    def create_acc_zero(self):
        return gl.zeros([self.shape_mn[0], self.shape_mn[1]], dtype=self.acc_type, layout=self.layout)

    @ttfs.gluon_jit 
    def _get_operand(self, val, is_tr: tl.constexpr, is_a: tl.constexpr):
        operand_layout: tl.constexpr = gl.DotOperandLayout(0 if is_a else 1, self.layout, 32 // self.dtype.primitive_bitwidth)
        mn_idx: tl.constexpr = 0 if is_a else 1
        if isinstance(val, PipelineConsumerBase):
            tl.static_assert(val.get_num_tensor_cw().value == 1, "expected exactly 1 tensor in consumer")
            a_smem = val.get_smem(val.group)
            a_smem = _reshape_smem(a_smem, self.shape_mn[mn_idx], is_a, is_tr)
            res = a_smem.load(operand_layout)
        elif isinstance(val, gl.shared_memory_descriptor):
            a_smem = val
            a_smem = _reshape_smem(a_smem, self.shape_mn[mn_idx], is_a, is_tr)
            res = a_smem.load(operand_layout)
        else:
            if is_tr:
                res = val.T
            else:
                res = val
            res = gl.convert_layout(res, operand_layout)

        return res 

    @ttfs.gluon_jit 
    def mma(self, a, b, a_is_tr: tl.constexpr, b_is_tr: tl.constexpr, acc=None):
        a_p = self._get_operand(a, a_is_tr, is_a=True)
        b_p = self._get_operand(b, b_is_tr, is_a=False)
        a_s0: tl.constexpr = a_p.shape[0]
        a_s1: tl.constexpr = a_p.shape[1]
        b_s0: tl.constexpr = b_p.shape[0]
        b_s1: tl.constexpr = b_p.shape[1]
        tl.static_assert(a_p.shape[1] == b_p.shape[0], 
            f"K mismatch. a: [{a_s0}, {a_s1}], b: [{b_s0}, {b_s1}]")
        tl.static_assert(a_p.shape[0] == self.shape_mn[0] and b_p.shape[1] == self.shape_mn[1], 
            f"MN mismatch. a: [{a_s0}, {a_s1}], b: [{b_s0}, {b_s1}]")

        if acc is None:
            acc = gl.zeros([self.shape_mn[0], self.shape_mn[1]], dtype=gl.float32, layout=self.layout)
        return mma_v2(a_p, b_p, acc)

    @ttfs.gluon_jit 
    def mma_nt(self, a, b, acc=None):
        return self.mma(a, b, a_is_tr=True, b_is_tr=False, acc=acc)

    @ttfs.gluon_jit 
    def mma_tn(self, a, b, acc=None):
        return self.mma(a, b, a_is_tr=False, b_is_tr=True, acc=acc)

    @ttfs.gluon_jit 
    def mma_tt(self, a, b, acc=None):
        return self.mma(a, b, a_is_tr=False, b_is_tr=False, acc=acc)

    @ttfs.gluon_jit 
    def wait(self, num_outstanding=0, deps=None):
        return _empty_wait_for_mma_v2(num_outstanding=num_outstanding, deps=deps)

    @ttfs.gluon_jit 
    @staticmethod 
    def create(shape_mn: tl.constexpr, dtype: tl.constexpr, is_flash: tl.constexpr = False):
        num_warps: tl.constexpr = ttfs.mp.get_num_warps()
        return AmpereMma(
            shape_mn=shape_mn,
            dtype=dtype,
            layout=get_default_mma(2, dtype, [shape_mn[0], shape_mn[1]], num_warps, is_chained=is_flash)
        )

@ttfs.aggregate
class HopperWgmma:
    shape_mn: tl.constexpr 
    dtype: tl.constexpr 
    is_flash: tl.constexpr = False
    layout: tl.constexpr = None
    acc_type: tl.constexpr = tl.float32

    def __post_init__(self):
        shape_mn = tl.core._unwrap_if_constexpr(self.shape_mn)
        dtype = tl.core._unwrap_if_constexpr(self.dtype)
        num_warps = ttfs.mp.get_num_warps_in_init()
        is_flash = tl.core._unwrap_if_constexpr(self.is_flash)
        self.layout = get_default_mma(3, dtype, [shape_mn[0], shape_mn[1]], num_warps, is_chained=is_flash)

    @ttfs.gluon_jit 
    def create_acc_zero(self):
        return gl.zeros([self.shape_mn[0], self.shape_mn[1]], dtype=self.acc_type, layout=self.layout)

    @ttfs.gluon_jit 
    def get_operand_layout_cw(self, idx):
        return ttfs.mp.TritonConstexprField(gl.DotOperandLayout(idx, self.layout, 32 // self.dtype.primitive_bitwidth))

    @ttfs.gluon_jit 
    def _get_operand(self, val, is_tr: tl.constexpr, is_a: tl.constexpr):
        operand_layout: tl.constexpr = gl.DotOperandLayout(0 if is_a else 1, self.layout, 32 // self.dtype.primitive_bitwidth)

        mn_idx: tl.constexpr = 0 if is_a else 1
        if isinstance(val, PipelineConsumerBase):
            tl.static_assert(val.get_num_tensor_cw().value == 1, "expected exactly 1 tensor in consumer")
            a_smem = val.get_smem(val.group)
            a_smem = _reshape_smem(a_smem, self.shape_mn[mn_idx], is_a, is_tr)
            res = a_smem
        elif isinstance(val, gl.shared_memory_descriptor):
            a_smem = val
            a_smem = _reshape_smem(a_smem, self.shape_mn[mn_idx], is_a, is_tr)
            res = a_smem
        else:
            if is_tr:
                res = val.T
            else:
                res = val
            res = gl.convert_layout(res, operand_layout)
        return res 

    @ttfs.gluon_jit 
    def wgmma(self, a, b, a_is_tr: tl.constexpr, b_is_tr: tl.constexpr, acc=None):
        a_p = self._get_operand(a, a_is_tr, is_a=True)
        b_p = self._get_operand(b, b_is_tr, is_a=False)
        a_s0: tl.constexpr = a_p.shape[0]
        a_s1: tl.constexpr = a_p.shape[1]
        b_s0: tl.constexpr = b_p.shape[0]
        b_s1: tl.constexpr = b_p.shape[1]
        tl.static_assert(a_p.shape[1] == b_p.shape[0], 
            f"K mismatch. a: [{a_s0}, {a_s1}], b: [{b_s0}, {b_s1}]")
        tl.static_assert(a_p.shape[0] == self.shape_mn[0] and b_p.shape[1] == self.shape_mn[1], 
            f"MN mismatch. a: [{a_s0}, {a_s1}], b: [{b_s0}, {b_s1}]")

        if acc is None:
            acc = gl.zeros([self.shape_mn[0], self.shape_mn[1]], dtype=gl.float32, layout=self.layout)
            use_acc: tl.constexpr = False 
        else:
            use_acc: tl.constexpr = True
        return warpgroup_mma(a_p, b_p, acc, is_async=True, use_acc=use_acc)

    @ttfs.gluon_jit 
    def wait(self, num_outstanding=0, deps=None):
        return warpgroup_mma_wait(num_outstanding=num_outstanding, deps=deps)


    @ttfs.gluon_jit 
    def mma_nt(self, a, b, acc=None):
        return self.wgmma(a, b, a_is_tr=True, b_is_tr=False, acc=acc)

    @ttfs.gluon_jit 
    def mma_tn(self, a, b, acc=None):
        return self.wgmma(a, b, a_is_tr=False, b_is_tr=True, acc=acc)

    @ttfs.gluon_jit 
    def mma_tt(self, a, b, acc=None):
        return self.wgmma(a, b, a_is_tr=False, b_is_tr=False, acc=acc)

    @ttfs.gluon_jit 
    @staticmethod 
    def create(shape_mn: tl.constexpr, dtype: tl.constexpr, is_flash: tl.constexpr = False):
        num_warps: tl.constexpr = ttfs.mp.get_num_warps()
        return HopperWgmma(
            shape_mn=shape_mn,
            dtype=dtype,
            layout=get_default_mma(3, dtype, [shape_mn[0], shape_mn[1]], num_warps, is_chained=is_flash)
        )
