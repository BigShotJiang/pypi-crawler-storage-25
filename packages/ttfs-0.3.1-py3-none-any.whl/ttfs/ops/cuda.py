import math

from ttfs.core.aggtype import constexpr_function, triton_jit
from ttfs.core.mp import get_num_warps
import triton.language as tl
from . import constants

@constexpr_function
def format_string(v, *args):
    return v.format(*args)

@triton_jit 
def bar_arrive(bar_id: tl.constexpr, num_threads: tl.constexpr):
    tl.inline_asm_elementwise(format_string("bar.arrive {},{}; // dummy $0", bar_id, num_threads), "=r", [], dtype=tl.int32, is_pure=False, pack=1)

@triton_jit 
def bar_wait(bar_id: tl.constexpr, num_threads: tl.constexpr):
    tl.inline_asm_elementwise(format_string("bar.sync {},{}; // dummy $0", bar_id, num_threads), "=r", [], dtype=tl.int32, is_pure=False, pack=1)

@triton_jit
def reg_dealloc(maxnreg: tl.constexpr):
    tl.inline_asm_elementwise(format_string("setmaxnreg.dec.sync.aligned.u32 {}; // dummy $0", maxnreg), "=r", [], dtype=tl.int32, is_pure=False, pack=1)

@triton_jit 
def reg_alloc(maxnreg: tl.constexpr):
    tl.inline_asm_elementwise(format_string("setmaxnreg.inc.sync.aligned.u32 {}; // dummy $0", maxnreg), "=r", [], dtype=tl.int32, is_pure=False, pack=1)

@triton_jit 
def bar_warp_sync(mask: tl.constexpr = 0xFFFFFFFF):
    tl.inline_asm_elementwise(format_string("bar.warp.sync {:#X}; // dummy $0", mask), "=r", [], dtype=tl.int32, is_pure=False, pack=1)

@triton_jit 
def bar_sync_partition(bar_id: tl.constexpr):
    num_threads: tl.constexpr = get_num_warps() * 32
    tl.inline_asm_elementwise(format_string("bar.sync {},{}; // dummy $0", bar_id, num_threads), "=r", [], dtype=tl.int32, is_pure=False, pack=1)

@triton_jit 
def vote_ballot_sync(pred, mask: tl.constexpr = 0xFFFFFFFF):
    return tl.inline_asm_elementwise(
        format_string("""
        .reg .pred %p;
        setp.ne.b32 %p, $1, 0;
        vote.sync.ballot.b32 $0,%p, {:#X};
        """, mask), 
        "=r,r", [pred], dtype=tl.uint32, is_pure=False, pack=1)

@triton_jit 
def vote_sync(pred, mode: tl.constexpr, mask: tl.constexpr = 0xFFFFFFFF):
    return tl.inline_asm_elementwise(
        format_string("""
        .reg .pred %p;
        setp.ne.b32 %p, $1, 0;
        vote.sync.{}.pred $0,%p, {:#X};
        """, mode, mask), 
        "=r,r", [pred], dtype=tl.uint32, is_pure=False, pack=1)

@triton_jit 
def shfl_sync(data, offset, mode: tl.constexpr, mask_and_clamp: tl.constexpr = 31, mask: tl.constexpr = 0xFFFFFFFF, out_dtype: tl.constexpr = tl.uint32):
    """
    mode: "up", "down", "xor", "idx"
    mask_and_clamp: for "up" and "down", the offset is clamped to [0, mask_and_clamp], and for "xor", the offset is masked with mask
    mask: the active mask of threads in the warp, default is 0xFFFFFFFF (all 32 threads active)
    """
    return tl.inline_asm_elementwise(
        format_string("shfl.sync.{}.b32 $0,$1,$2,{:#X},{:#X};", mode, mask_and_clamp, mask), 
        "=r,r,r", [data, offset], dtype=out_dtype.value, is_pure=False, pack=1)

@triton_jit 
def shfl_sync_down(data, offset, mask_and_clamp: tl.constexpr = 31, mask: tl.constexpr = 0xFFFFFFFF, out_dtype: tl.constexpr = tl.uint32):
    """Fetch data[lane + offset] if lane - offset <= max_lane
    mask_and_clamp: for "up" and "down", the offset is clamped to [0, mask_and_clamp], and for "xor", the offset is masked with mask
    mask: the active mask of threads in the warp, default is 0xFFFFFFFF (all 32 threads active)
    """
    return shfl_sync(data, offset, "down", mask_and_clamp, mask, out_dtype)


@triton_jit 
def shfl_sync_up(data, offset, mask_and_clamp: tl.constexpr = 0, mask: tl.constexpr = 0xFFFFFFFF, out_dtype: tl.constexpr = tl.uint32):
    """Fetch data[lane - offset] if lane - offset >= max_lane
    mask_and_clamp: for "up" and "down", the offset is clamped to [0, mask_and_clamp], and for "xor", the offset is masked with mask
    mask: the active mask of threads in the warp, default is 0xF (allFFFFFFF 32 threads active)
    """
    return shfl_sync(data, offset, "up", mask_and_clamp, mask, out_dtype)

@triton_jit 
def shfl_sync_bfly(data, offset, mask_and_clamp: tl.constexpr = 31, mask: tl.constexpr = 0xFFFFFFFF, out_dtype: tl.constexpr = tl.uint32):
    """Fetch data[lane ^ offset] if lane - offset <= max_lane
    mask_and_clamp: for "up" and "down", the offset is clamped to [0, mask_and_clamp], and for "xor", the offset is masked with mask
    mask: the active mask of threads in the warp, default is 0xFFFFFFFF (all 32 threads active)
    """
    return shfl_sync(data, offset, "bfly", mask_and_clamp, mask, out_dtype)

@triton_jit 
def shfl_sync_idx(data, offset, mask_and_clamp: tl.constexpr = 31, mask: tl.constexpr = 0xFFFFFFFF, out_dtype: tl.constexpr = tl.uint32):
    """Fetch data[offset] if offset <= max_lane
    mask_and_clamp: for "up" and "down", the offset is clamped to [0, mask_and_clamp], and for "xor", the offset is masked with mask
    mask: the active mask of threads in the warp, default is 0xFFFFFFFF (all 32 threads active)
    """
    return shfl_sync(data, offset, "idx", mask_and_clamp, mask, out_dtype)

@constexpr_function
def _log2(x):
    return int(math.log2(x))

@triton_jit
def warp_prefix_sum(val, lane=None):
    if lane is None:
        lane_val = lane_id()
    else:
        lane_val = lane
    for i in tl.static_range(_log2(constants.CUDA_WARP_SIZE)):
        offset = 1 << i
        # Very important that we set mask_and_clamp to 0
        partial_sum = shfl_sync_up(val, offset=offset, mask_and_clamp=0, out_dtype=val.dtype)
        # val += partial_sum if lane_val >= offset else 0
        if lane_val >= offset:
            val += partial_sum
    return val

@triton_jit 
def disable_scalar_optimization(val, out_dtype: tl.constexpr = tl.int32):
    return tl.inline_asm_elementwise(
        "mov.b32 $0, $1;", "=r,r", [val], 
        dtype=out_dtype.value, is_pure=True, pack=1).item()

@triton_jit 
def popc(value):
    value_bitwidth: tl.constexpr = value.dtype.primitive_bitwidth
    return tl.inline_asm_elementwise(
        format_string("popc.b{} $0,$1;", value_bitwidth), 
        "=r,l" if value_bitwidth == 64 else "=r,r", 
        [value], dtype=out_dtype.value, is_pure=True, pack=1)

@triton_jit 
def _get_special_reg(reg_name: tl.constexpr, out_dtype: tl.constexpr = tl.uint32):
    return tl.inline_asm_elementwise(
        format_string("mov.u32 $0, %{};", reg_name), "=r", [], 
        dtype=out_dtype.value, is_pure=True, pack=1)

@triton_jit 
def thread_ids(out_dtype: tl.constexpr = tl.uint32):
    return (
        _get_special_reg("tid.x", out_dtype),
        _get_special_reg("tid.y", out_dtype),
        _get_special_reg("tid.z", out_dtype),
    )


@triton_jit 
def number_threads(out_dtype: tl.constexpr = tl.uint32):
    return (
        _get_special_reg("ntid.x", out_dtype),
        _get_special_reg("ntid.y", out_dtype),
        _get_special_reg("ntid.z", out_dtype),
    )

@triton_jit 
def thread_id(out_dtype: tl.constexpr = tl.uint32):
    tx, ty, tzz = thread_ids(out_dtype)
    ntx, nty, ntz = number_threads(out_dtype)
    return tx + ty * ntx + tzz * ntx * nty

@triton_jit 
def lane_id(out_dtype: tl.constexpr = tl.uint32):
    return _get_special_reg("laneid", out_dtype)

@triton_jit 
def warp_id(out_dtype: tl.constexpr = tl.uint32):
    return _get_special_reg("warpid", out_dtype)

@triton_jit 
def number_warps(out_dtype: tl.constexpr = tl.uint32):
    return _get_special_reg("nwarpid", out_dtype)

@triton_jit 
def sm_id(out_dtype: tl.constexpr = tl.uint32):
    return _get_special_reg("smid", out_dtype)

@triton_jit 
def cluster_cta_ids(out_dtype: tl.constexpr = tl.uint32):
    return (
        _get_special_reg("cluster_ctaid.x", out_dtype),
        _get_special_reg("cluster_ctaid.y", out_dtype),
        _get_special_reg("cluster_ctaid.z", out_dtype),
    )

@triton_jit 
def cluster_ids(out_dtype: tl.constexpr = tl.uint32):
    return (
        _get_special_reg("clusterid.x", out_dtype),
        _get_special_reg("clusterid.y", out_dtype),
        _get_special_reg("clusterid.z", out_dtype),
    )

