import triton.language as tl 


CUDA_WARP_SIZE = tl.constexpr(32)