from typing import Optional
from ttfs.core.aggtype import constexpr_function, aggregate, gluon_jit
from ttfs.core.linear_layout import (gluon_layout_to_linear_layout)
from triton.experimental import gluon
from triton.experimental.gluon import language as gl
import triton.language as tl
from ttfs.gl import ll_tools
from ttfs.gl.core import get_ttfs_ll_from_tensor_cw
from ttfs.core import mp 

@gluon_jit
def inline_sum(x, axes: gl.constexpr, keep_dims: gl.constexpr = False):
    length: gl.constexpr = len(axes)
    # forward, x is only used for layout inference
    x_reduced = x
    for i in gl.static_range(length):
        x_reduced = gl.sum(x_reduced, axes[length - i - 1], keep_dims=keep_dims)
    return x_reduced

@gluon_jit
def inline_max(x, axes: gl.constexpr, keep_dims: gl.constexpr = False):
    length: gl.constexpr = len(axes)
    # forward, x is only used for layout inference
    x_reduced = x
    for i in gl.static_range(length):
        x_reduced = gl.max(x_reduced, axes[length - i - 1], keep_dims=keep_dims)
    return x_reduced

@gluon_jit
def inline_min(x, axes: gl.constexpr, keep_dims: gl.constexpr = False):
    length: gl.constexpr = len(axes)
    # forward, x is only used for layout inference
    x_reduced = x
    for i in gl.static_range(length):
        x_reduced = gl.min(x_reduced, axes[length - i - 1], keep_dims=keep_dims)
    return x_reduced


@gluon_jit
def inline_reduce_broadcast(x, y, axes: gl.constexpr, assert_trivial: gl.constexpr = True):
    keep_dims: gl.constexpr = False
    length: gl.constexpr = len(axes)
    # forward, x is only used for layout inference
    x_reduced = x
    for i in gl.static_range(length):
        x_reduced = gl.max(x_reduced, axes[length - i - 1], keep_dims=keep_dims)
    y1 = gl.convert_layout(y.reshape(x_reduced.shape), x_reduced.type.layout, assert_trivial=assert_trivial) # .reshape(x.shape)
    # backward
    for i in gl.static_range(length):
        y1 = y1.expand_dims(axes[i])
    return y1

@constexpr_function
def _get_reduce_axes_by_non_reduce_axis(a, non_reduce_axis):
    ndim = len(a.shape)
    reduce_axes = []
    for i in range(ndim):
        if i != non_reduce_axis:
            reduce_axes.append(i)
    return reduce_axes

@gluon_jit
def inline_reduce_broadcast_arange(x, start: gl.constexpr, end: gl.constexpr, axes: gl.constexpr):
    keep_dims: gl.constexpr = False
    length: gl.constexpr = len(axes)
    # forward, x is only used for layout inference
    x_reduced = x
    for i in gl.static_range(length):
        x_reduced = gl.max(x_reduced, axes[length - i - 1], keep_dims=keep_dims)
    y1 = gl.arange(start, end, layout=x_reduced.type.layout)
    # backward
    for i in gl.static_range(length):
        y1 = y1.expand_dims(axes[i])
    return y1

# hack triton.runtime.jit.DependenciesFinder to avoid check 
# nested python function without constexpr_function decorator.
gluon_layout_to_linear_layout.__triton_builtin__ = True
ll_tools.get_blocked_logical_dim_names.__triton_builtin__ = True
ll_tools.get_logical_layout_from_names.__triton_builtin__ = True
ll_tools.get_ll_reduce_shape_and_axes.__triton_builtin__ = True
ll_tools.get_blocked_logical_dim_names_short.__triton_builtin__ = True

@constexpr_function
def _get_blocked_logical_dim_names_constexpr(layout):
    return ll_tools.get_blocked_logical_dim_names(layout)

@constexpr_function
def _get_blocked_logical_dim_names_short_constexpr(layout):
    return ll_tools.get_blocked_logical_dim_names_short(layout)


@gluon_jit
def print_layout(a, msg):
    a_ll = get_ttfs_ll_from_tensor_cw(a)
    mp.logger_warning("%s %s", msg, a_ll.value)

@gluon_jit
def print_logical_dims(a, msg):
    a_ll = get_ttfs_ll_from_tensor_cw(a)
    mp.logger_warning("%s %s", msg, _get_blocked_logical_dim_names_constexpr(a_ll.value))

@gluon_jit
def print_logical_dims_short(a, msg):
    a_ll = get_ttfs_ll_from_tensor_cw(a)
    mp.logger_warning("%s %s", msg, _get_blocked_logical_dim_names_short_constexpr(a_ll.value))

@constexpr_function
def get_thread_reduce_shape_and_axes(a, a_ll, dim):
    # TODO a must be a blocked layout (i.e. no swizzle), how to check?
    name_mapping = {k: k for k in a_ll.bases.keys()}
    dim_colmajor = len(a.shape) - 1 - dim
    a_basenames = ll_tools.get_blocked_logical_dim_names(a_ll)
    reduce_basenames = a_basenames[dim_colmajor]
    for j in range(len(reduce_basenames)):
        if reduce_basenames[j] == "register":
            reduce_basenames[j] = "register_need_reduce"
    a_basenames[dim_colmajor] = reduce_basenames
    # basenames is col major.
    name_dim_pairs = ll_tools.get_logical_layout_from_names(sum(a_basenames, []), {
        "register_need_reduce": "register_need_reduce",
        **name_mapping,
    })
    # map names
    shape = [x[1] for x in name_dim_pairs]
    reduce_axes = []
    for i in range(len(name_dim_pairs)):
        if name_dim_pairs[i][0] == "register_need_reduce":
            reduce_axes.append(i)
    return shape, reduce_axes 

@constexpr_function
def get_lane_warp_reduce_shape_and_axes(a, a_ll, dim):
    # TODO a must be a blocked layout (i.e. no swizzle), how to check?
    name_mapping = {k: k for k in a_ll.bases.keys()}
    dim_colmajor = len(a.shape) - 1 - dim
    a_basenames = ll_tools.get_blocked_logical_dim_names(a_ll)
    reduce_basenames = a_basenames[dim_colmajor]
    for j in range(len(reduce_basenames)):
        if reduce_basenames[j] == "lane":
            reduce_basenames[j] = "lane_need_reduce"
        elif reduce_basenames[j] == "warp":
            reduce_basenames[j] = "warp_need_reduce"
    a_basenames[dim_colmajor] = reduce_basenames
    # basenames is col major.
    name_dim_pairs = ll_tools.get_logical_layout_from_names(sum(a_basenames, []), {
        "lane_need_reduce": "lane_need_reduce",
        "warp_need_reduce": "warp_need_reduce",
        **name_mapping,
    })
    # map names
    shape = [x[1] for x in name_dim_pairs]
    reduce_axes = []
    for i in range(len(name_dim_pairs)):
        if name_dim_pairs[i][0] == "lane_need_reduce" or name_dim_pairs[i][0] == "warp_need_reduce":
            reduce_axes.append(i)
    return shape, reduce_axes 

@constexpr_function
def get_ll_reduce_shape_and_axes(layout, reduce_base_names: list[str], flatten_name: bool = False):
    # reduce_base_names: ["register_2", "lane_2"] indicates reduce register and lane in dim 2.
    res = ll_tools.get_ll_reduce_shape_and_axes(layout, reduce_base_names, flatten_name)
    return (res.broadcast_shape, res.reduce_axes, res.reduced_shape)

@constexpr_function
def get_ll_reduce_shape_and_axes_all(layout, reduce_base_names: list[str], flatten_name: bool = False):
    # reduce_base_names: ["register_2", "lane_2"] indicates reduce register and lane in dim 2.
    res = ll_tools.get_ll_reduce_shape_and_axes(layout, reduce_base_names, flatten_name)
    return res

@gluon_jit 
def ptx_fma(a, b, c):
    return gl.inline_asm_elementwise(
        asm="""fma.rn.f32   $0, $1, $2, $3;""",
        constraints=("=r,r,r,r"),
        args=[a, b, c],
        dtype=gl.float32,
        is_pure=True,
        pack=1
    )

@gluon_jit
def ll_reduce_max(a, in_dim_names, keep_dims: gl.constexpr = False, flatten_name: gl.constexpr = False):
    res: gl.constexpr = get_ll_reduce_shape_and_axes_all(get_ttfs_ll_from_tensor_cw(a).value, in_dim_names, flatten_name)
    shape: gl.constexpr = res.broadcast_shape
    reduce_axes: gl.constexpr = res.reduce_axes
    reduced_origin_shape: gl.constexpr = res.reduced_shape
    res = inline_max(a.reshape(shape), reduce_axes, keep_dims=keep_dims)
    # reshape hack to force triton convert layout to distributed linear layout.
    if keep_dims:
        return res.reshape(res.shape)
    else:
        return res.reshape(reduced_origin_shape)

@gluon_jit
def ll_reduce_max_with_original(a, in_dim_names, keep_dims: gl.constexpr = False, flatten_name: gl.constexpr = False):
    res: gl.constexpr = get_ll_reduce_shape_and_axes_all(get_ttfs_ll_from_tensor_cw(a).value, in_dim_names, flatten_name)
    shape: gl.constexpr = res.broadcast_shape
    reduce_axes: gl.constexpr = res.reduce_axes
    reduced_origin_shape: gl.constexpr = res.reduced_shape

    res = inline_max(a.reshape(shape), reduce_axes, keep_dims=keep_dims)
    # reshape hack to force triton convert layout to distributed linear layout.
    if keep_dims:
        return res.reshape(res.shape), a.reshape(shape)
    else:
        return res.reshape(reduced_origin_shape), a.reshape(shape)


@gluon_jit
def ll_reduce_min(a, in_dim_names, keep_dims: gl.constexpr = False, flatten_name: gl.constexpr = False):
    res: gl.constexpr = get_ll_reduce_shape_and_axes_all(get_ttfs_ll_from_tensor_cw(a).value, in_dim_names, flatten_name)
    shape: gl.constexpr = res.broadcast_shape
    reduce_axes: gl.constexpr = res.reduce_axes
    reduced_origin_shape: gl.constexpr = res.reduced_shape

    res = inline_min(a.reshape(shape), reduce_axes, keep_dims=keep_dims)
    # reshape hack to force triton convert layout to distributed linear layout.
    if keep_dims:
        return res.reshape(res.shape)
    else:
        return res.reshape(reduced_origin_shape)

@gluon_jit
def ll_reduce_sum(a, in_dim_names, keep_dims: gl.constexpr = False, flatten_name: gl.constexpr = False):
    res: gl.constexpr = get_ll_reduce_shape_and_axes(get_ttfs_ll_from_tensor_cw(a).value, in_dim_names, flatten_name)
    shape: gl.constexpr = res[0]
    reduce_axes: gl.constexpr = res[1]
    reduced_origin_shape: gl.constexpr = res[2]

    res = inline_sum(a.reshape(shape), reduce_axes, keep_dims=keep_dims)
    if keep_dims:
        return res.reshape(res.shape)
    else:
        return res.reshape(reduced_origin_shape)

@gluon_jit
def ll_reduce_broadcast(x, y, in_dim_names, assert_trivial: gl.constexpr = True):
    res: gl.constexpr = get_ll_reduce_shape_and_axes(get_ttfs_ll_from_tensor_cw(x).value, in_dim_names)
    shape: gl.constexpr = res[0]
    reduce_axes: gl.constexpr = res[1]
    # gl.static_print(shape, reduce_axes, y.shape)
    x1 = x.reshape(shape)
    yr = inline_reduce_broadcast(x1, y, reduce_axes, assert_trivial=assert_trivial)
    # gl.static_print(shape, reduce_axes, x.shape, y.shape, yr.shape)
    _, yr = gl.broadcast(x1, yr)
    gl.static_assert(len(yr.shape) == len(shape), "ll_reduce_broadcast output ndim mismatch")
    return yr

@gluon_jit
def ll_reduce_broadcast_v2(x, y, in_dim_names):
    res: gl.constexpr = get_ll_reduce_shape_and_axes(get_ttfs_ll_from_tensor_cw(x).value, in_dim_names)
    shape: gl.constexpr = res[0]
    reduce_axes: gl.constexpr = res[1]
    # gl.static_print(shape, reduce_axes, y.shape)
    x1 = x.reshape(shape)
    yr = inline_reduce_broadcast(x1, y, reduce_axes)
    # gl.static_print(shape, reduce_axes, x.shape, y.shape, yr.shape)
    _, yr = gl.broadcast(x1, yr)
    gl.static_assert(len(yr.shape) == len(shape), "ll_reduce_broadcast output ndim mismatch")
    return gl.convert_layout((yr).reshape(x.shape), x.type.layout, assert_trivial=True)


@gluon_jit
def ll_reduce_broadcast_add(x, y, in_dim_names):
    res: gl.constexpr = get_ll_reduce_shape_and_axes(get_ttfs_ll_from_tensor_cw(x).value, in_dim_names)
    shape: gl.constexpr = res[0]
    reduce_axes: gl.constexpr = res[1]
    # gl.static_print(shape, reduce_axes, y.shape)
    x1 = x.reshape(shape)
    yr = gl.convert_layout(inline_reduce_broadcast(x1, y, reduce_axes), x1.type.layout, assert_trivial=True)
    return gl.convert_layout((x1 + yr).reshape(x.shape), x.type.layout, assert_trivial=True)

@gluon_jit
def ll_reduce_broadcast_mul(x, y, in_dim_names):
    if len(in_dim_names) == 0:
        return x * y
    else:
        res: gl.constexpr = get_ll_reduce_shape_and_axes(get_ttfs_ll_from_tensor_cw(x).value, in_dim_names)
        shape: gl.constexpr = res[0]
        reduce_axes: gl.constexpr = res[1]
        # gl.static_print(shape, reduce_axes, x, y)

        x1 = x.reshape(shape)
        if isinstance(y, float) or isinstance(y, int):
            yr = y 
        else:
            yr = gl.convert_layout(inline_reduce_broadcast(x1, y, reduce_axes), x1.type.layout, assert_trivial=True)
        return gl.convert_layout((x1 * yr).reshape(x.shape), x.type.layout, assert_trivial=True)

@gluon_jit
def ll_reduce_broadcast_fma(x, y, z, in_dim_names, z_is_scalar: gl.constexpr = False, use_fma: gl.constexpr = True):
    if len(in_dim_names) == 0:
        if use_fma:
            ret = gl.fma(x, y, z)
        else:
            ret = x * y + z
    else:
        res: gl.constexpr = get_ll_reduce_shape_and_axes(get_ttfs_ll_from_tensor_cw(x).value, in_dim_names)
        shape: gl.constexpr = res[0]
        reduce_axes: gl.constexpr = res[1]
        # gl.static_print(shape, reduce_axes, y.shape)
        x1 = x.reshape(shape)
        yr = gl.convert_layout(inline_reduce_broadcast(x1, y, reduce_axes), x1.type.layout, assert_trivial=True)
        if use_fma:
            if z_is_scalar:
                ret = gl.fma(x1, yr, z)
            else:
                ret = gl.fma(x1, yr, z.reshape(shape))
        else:
            if z_is_scalar:
                ret = x1 * yr + z
            else:
                ret = x1 * yr + z.reshape(shape)
        return gl.convert_layout(ret.reshape(x.shape), x.type.layout, assert_trivial=True)


@gluon_jit
def ll_reduce_broadcast_sub(x, y, in_dim_names):
    res: gl.constexpr = get_ll_reduce_shape_and_axes(get_ttfs_ll_from_tensor_cw(x).value, in_dim_names)
    shape: gl.constexpr = res[0]
    reduce_axes: gl.constexpr = res[1]
    # gl.static_print(shape, reduce_axes, y.shape)
    x1 = x.reshape(shape)
    yr = gl.convert_layout(inline_reduce_broadcast(x1, y, reduce_axes), x1.type.layout, assert_trivial=True)
    return gl.convert_layout((x1 - yr).reshape(x.shape), x.type.layout, assert_trivial=True)

@gluon_jit
def ll_reduce_broadcast_div(x, y, in_dim_names):
    res: gl.constexpr = get_ll_reduce_shape_and_axes(get_ttfs_ll_from_tensor_cw(x).value, in_dim_names)
    shape: gl.constexpr = res[0]
    reduce_axes: gl.constexpr = res[1]
    # gl.static_print(shape, reduce_axes, y.shape)
    x1 = x.reshape(shape)
    yr = gl.convert_layout(inline_reduce_broadcast(x1, y, reduce_axes), x1.type.layout, assert_trivial=True)
    return gl.convert_layout((x1 / yr).reshape(x.shape), x.type.layout, assert_trivial=True)


@constexpr_function
def get_matrix_reduce_dims_strides(a, layout, reduce_base_names: list[str]):
    assert len(a.shape) == 2, "only support matrix layout"
    res = ll_tools.get_ll_reduce_shape_and_axes(layout, reduce_base_names, flatten_name=True)
    # reduce_axes = res.local_reduce_axes
    reduce_axes = res.reduce_axes_per_dim
    reduce_strides = res.local_reduce_strides
    # reduce_dimsizes = res.local_reduce_dimsize
    # print(res)
    # currently only support at most two reduce axes per dim.
    assert len(reduce_axes[0]) <= 2
    assert len(reduce_axes[1]) <= 2
    if reduce_axes[0]:
        row_strides = tuple(reduce_strides[0])
        row_axes = tuple(reduce_axes[0])
    else:
        row_strides = ()
        row_axes = ()
    if reduce_axes[1]:
        col_strides = (reduce_strides[1])
        col_axes = (reduce_axes[1])
    else:
        col_strides = ()
        col_axes = ()
    return (row_axes, col_axes, row_strides, col_strides)

@constexpr_function
def get_matrix_non_reduce_dims_strides(a, layout, reduce_base_names: list[str]):
    assert len(a.shape) == 2, "only support matrix layout"
    res = ll_tools.get_ll_reduce_shape_and_axes(layout, reduce_base_names, flatten_name=True)
    print("[GLUON] matrix non reduce", res)
    reduce_axes = res.non_reduce_axes_per_dim
    reduce_strides = res.local_non_reduce_strides
    # reduce_axes = res.local_reduce_axes
    # reduce_strides = res.local_reduce_strides
    # reduce_dimsizes = res.local_reduce_dimsize
    # currently only support at most two reduce axes per dim.
    assert len(reduce_axes[0]) <= 2
    assert len(reduce_axes[1]) <= 2
    if reduce_axes[0]:
        row_strides = tuple(reduce_strides[0])
        row_axes = tuple(reduce_axes[0])
    else:
        row_strides = ()
        row_axes = ()
    if reduce_axes[1]:
        col_strides = (reduce_strides[1])
        col_axes = (reduce_axes[1])
    else:
        col_strides = ()
        col_axes = ()
    return (row_axes, col_axes, row_strides, col_strides)


@gluon_jit
def get_per_thread_ptr_offsets_v4(block_shape, mat_layout, init_row_offset, init_col_offset, ext_row_stride, ext_col_stride):
    mat = gl.zeros(block_shape, dtype=gl.float32, layout=mat_layout)
    res: gl.constexpr = get_matrix_non_reduce_dims_strides(mat, get_ttfs_ll_from_tensor_cw(mat), gl.constexpr(["register_0", "register_1"]))
    row_reduce_axes: gl.constexpr = res[0]
    col_reduce_axes: gl.constexpr = res[1]
    row_stride: gl.constexpr = res[2]
    col_stride: gl.constexpr = res[3]
    num_row_reduce_axes: gl.constexpr = len(row_reduce_axes)
    num_col_reduce_axes: gl.constexpr = len(col_reduce_axes)
    mat_reduced, mat_origin = ll_reduce_max_with_original(mat, gl.constexpr(["register_0", "register_1"]), keep_dims=True, flatten_name=True)
    if num_row_reduce_axes > 0:
        row_offset = 0
        for i in gl.static_range(num_row_reduce_axes):
            row_offset += inline_reduce_broadcast_arange(mat_origin, 0,
                 mat_reduced.shape[row_reduce_axes[i]], 
                 _get_reduce_axes_by_non_reduce_axis(mat_origin, row_reduce_axes[i])) * row_stride[i]
    if num_col_reduce_axes > 0:
        col_offset = 0
        for i in gl.static_range(num_col_reduce_axes):
            col_offset += inline_reduce_broadcast_arange(mat_origin, 0, 
                mat_reduced.shape[col_reduce_axes[i]], 
                _get_reduce_axes_by_non_reduce_axis(mat_origin, col_reduce_axes[i])) * col_stride[i]
    if num_col_reduce_axes != 0 and num_row_reduce_axes != 0:
        return ((init_row_offset + row_offset)  * ext_row_stride + (init_col_offset + col_offset) * ext_col_stride)
    elif num_row_reduce_axes != 0:
        return (init_row_offset + row_offset)  * ext_row_stride
    else:
        return (init_col_offset + col_offset) * ext_col_stride

@gluon_jit
def get_thread_ptr_offsets_v4(block_shape, mat_layout, ext_row_stride, ext_col_stride):
    mat = gl.zeros(block_shape, dtype=gl.float32, layout=mat_layout)
    res: gl.constexpr = get_matrix_reduce_dims_strides(mat, get_ttfs_ll_from_tensor_cw(mat), gl.constexpr(["register_0", "register_1"]))
    row_reduce_axes: gl.constexpr = res[0]
    col_reduce_axes: gl.constexpr = res[1]
    row_stride: gl.constexpr = res[2]
    col_stride: gl.constexpr = res[3]
    num_row_reduce_axes: gl.constexpr = len(row_reduce_axes)
    num_col_reduce_axes: gl.constexpr = len(col_reduce_axes)
    mat_reduced, mat_origin = ll_reduce_max_with_original(mat, gl.constexpr(["lane_0", "lane_1", "warp_0", "warp_1"]), keep_dims=True, flatten_name=True)
    if num_row_reduce_axes > 0:
        row_offset = 0
        for i in gl.static_range(num_row_reduce_axes):
            row_offset += inline_reduce_broadcast_arange(mat_origin, 0,
                 mat_reduced.shape[row_reduce_axes[i]], 
                 _get_reduce_axes_by_non_reduce_axis(mat_origin, row_reduce_axes[i])) * row_stride[i]
    if num_col_reduce_axes > 0:
        col_offset = 0
        for i in gl.static_range(num_col_reduce_axes):
            col_offset += inline_reduce_broadcast_arange(mat_origin, 0, 
                mat_reduced.shape[col_reduce_axes[i]], 
                _get_reduce_axes_by_non_reduce_axis(mat_origin, col_reduce_axes[i])) * col_stride[i]
    if num_col_reduce_axes != 0 and num_row_reduce_axes != 0:
        return (row_offset  * ext_row_stride + col_offset * ext_col_stride)
    elif num_row_reduce_axes != 0:
        return row_offset  * ext_row_stride
    else:
        return col_offset * ext_col_stride

@aggregate
class MatrixThreadOffset:

    shape: gl.constexpr
    layout: gl.constexpr
    contig_row: gl.constexpr
    contig_col: gl.constexpr

    # def __init__(self, shape, layout, contig_row, contig_col):
    #     layout = gl._unwrap_if_constexpr(layout)
    #     contig_row = gl._unwrap_if_constexpr(contig_row)
    #     contig_col = gl._unwrap_if_constexpr(contig_col)
    #     self.shape = gl.constexpr(shape)
    #     self.layout = gl.constexpr(layout)
    #     self.contig_row = gl.constexpr(contig_row)
    #     self.contig_col = gl.constexpr(contig_col)

    @gluon_jit
    def get_init_offsets(self, offset_row: gl.constexpr, offset_col: gl.constexpr, ext_row_stride, ext_col_stride):
        return get_per_thread_ptr_offsets_v4(self.shape, self.layout, offset_row, offset_col, ext_row_stride, ext_col_stride)

    @gluon_jit
    def get_full_ptrs(self, reduced_ptr, ext_row_stride, ext_col_stride):
        res = (reduced_ptr + get_thread_ptr_offsets_v4(self.shape, self.layout, ext_row_stride, ext_col_stride)).reshape(self.shape)
        res = gl.max_contiguous(gl.multiple_of(res, [self.contig_row, self.contig_col]), [self.contig_row, self.contig_col])
        return res

    @gluon_jit
    def get_full_ptrs_v2(self, reduced_ptr, ext_row_stride: gl.constexpr, ext_col_stride: gl.constexpr, contig: gl.constexpr):
        res = (reduced_ptr + get_thread_ptr_offsets_v4(self.shape, self.layout, ext_row_stride, ext_col_stride)).reshape(self.shape)
        res = gl.max_contiguous(gl.multiple_of(res, contig), contig)
        return res

    @gluon_jit
    def get_full_ptrs_k(self, reduced_ptr, ext_row_stride: gl.constexpr, ext_col_stride: gl.constexpr):
        res = (reduced_ptr + get_thread_ptr_offsets_v4(self.shape, self.layout, ext_row_stride, ext_col_stride)).reshape(self.shape)
        # res = gl.max_contiguous(gl.multiple_of(res, [16, 1]), [16, 1])
        # gl.static_print(self.shape, self.contig_row, self.contig_col)
        return res

@gluon_jit
def get_full_ptrs_k_dev(reduced_ptr, shape: gl.constexpr, layout: gl.constexpr, ext_row_stride: gl.constexpr, ext_col_stride: gl.constexpr):
    res = (reduced_ptr + get_thread_ptr_offsets_v4(shape, layout, ext_row_stride, ext_col_stride)).reshape(shape)
    res = gl.max_contiguous(gl.multiple_of(res, [16, 1]), [16, 1])
    # gl.static_print(self.shape, self.contig_row, self.contig_col)
    return res