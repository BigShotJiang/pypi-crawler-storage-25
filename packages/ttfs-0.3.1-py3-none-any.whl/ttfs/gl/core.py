import dataclasses
from typing import TYPE_CHECKING, Any, Callable, Optional, ParamSpec, cast, dataclass_transform, TypeVar

from triton.experimental.gluon import language as ttgl

from ttfs.core.aggtype import triton_jit, constexpr_function
from collections.abc import Sequence
from ttfs.core.linear_layout import LinearLayout, gluon_layout_to_linear_layout
from ttfs.core.mp import TritonConstexprField

# hack triton.runtime.jit.DependenciesFinder to avoid check 
# nested python function without constexpr_function decorator.
gluon_layout_to_linear_layout.__triton_builtin__ = True


@constexpr_function
def _py_ll_to_tt_ll(layout: ttgl.DistributedLinearLayout, require_surjective: bool = True) -> LinearLayout:
    # ll_layout is gl.DistributedLinearLayout, convert to 
    res = gluon_layout_to_linear_layout(layout.shape, layout, )
    return res


@triton_jit
def get_ttfs_linear_layout_cw(layout, shape):
    # ll_layout is gl.DistributedLinearLayout, convert to 
    ll_layout: ttgl.constexpr = ttgl.to_linear_layout(layout, shape)
    return TritonConstexprField(_py_ll_to_tt_ll(ll_layout))

@triton_jit
def get_ttfs_ll_from_tensor_cw(tensor):
    # ll_layout is gl.DistributedLinearLayout, convert to 
    ll_layout: ttgl.constexpr = ttgl.to_linear_layout(tensor.type.layout, tensor.shape)
    return TritonConstexprField(_py_ll_to_tt_ll(ll_layout))