from typing import Optional
from ttfs.core.linear_layout import LinearLayout

import dataclasses

def get_blocked_logical_dim_names(layout: LinearLayout):
    # assume input layout is a blocked ll (no swizzle)
    # this means all bases are either [0, x] or [x, 0]
    # assume cta layout is (1, 1)
    base_name_res: list[list[str]] = []
    num_out_dims = layout.get_num_out_dims()
    for i in range(num_out_dims - 1, -1, -1):
        dim_size = layout.get_out_dim_size_log2(f"dim{i}")
        base_names: list[str] = []

        for c in range(dim_size):
            base = [0 for _ in range(num_out_dims)]
            base[i] = 1 << c
            base_name = layout.get_out_dim_name_by_base(base)
            base_names.append(base_name)
        base_name_res.append(base_names)
    return base_name_res

def get_blocked_logical_dim_names_short(layout: LinearLayout):
    # assume input layout is a blocked ll (no swizzle)
    # this means all bases are either [0, x] or [x, 0]
    # assume cta layout is (1, 1)
    base_name_res: list[str] = []
    num_out_dims = layout.get_num_out_dims()
    for i in range(num_out_dims - 1, -1, -1):
        dim_size = layout.get_out_dim_size_log2(f"dim{i}")
        base_names: list[str] = []

        for c in range(dim_size):
            base = [0 for _ in range(num_out_dims)]
            base[i] = 1 << c
            base_name = layout.get_out_dim_name_by_base(base)
            base_names.append(base_name[:1].upper())
        base_name_short = "".join(base_names)
        base_name_res.append(base_name_short)
    return ",".join(base_name_res)


def get_logical_layout_from_names(base_names: list[str], name_mapping: dict[str, str]):
    # now base_names looks like [warp, lane, reg, lane, lane, reg, reg, reg]
    # each base indicates a dimension with size 2
    # we can get final layout shape [2, 2, 2, 2, 2, 2, 2, 2]
    # then we reduce all dimensions with same base together
    cur_base_name: str = name_mapping[base_names[0]]
    cur_size = 2
    name_dim_pairs: list[tuple[str, int]] = [(cur_base_name, 2)]

    for i, name in enumerate(base_names[1:]):
        if name_mapping[name] == cur_base_name:
            cur_size *= 2
            name_dim_pairs[-1] = (cur_base_name, cur_size)
        else:
            cur_base_name = name_mapping[name]
            cur_size = 2
            name_dim_pairs.append((cur_base_name, 2))
    return name_dim_pairs[::-1]


@dataclasses.dataclass
class LLReduceResult:
    # shape before reduce
    broadcast_shape: list[int]
    reduce_axes: list[int]
    reduced_shape: list[int]
    shape_after_reduce: list[int]
    local_reduce_axes: list[list[int]]
    local_reduce_strides: list[list[int]]
    local_non_reduce_axes: list[list[int]]
    local_non_reduce_strides: list[list[int]]
    local_reduce_dimsize: list[int]
    local_non_reduce_dimsize: list[int]
    reduce_axes_per_dim: list[list[int]]
    non_reduce_axes_per_dim: list[list[int]]
    basenames: list[list[str]]

def get_ll_reduce_shape_and_axes(layout: LinearLayout, reduce_base_names: list[str], flatten_name: bool = False):
    ndim = layout.get_num_out_dims()
    origin_shape = [x[1] for x in layout.get_out_dims()]
    basenames_list = get_blocked_logical_dim_names(layout)
    # map basenames list from "register" to "register_{dim}"
    for dim in range(len(basenames_list)):
        dim_rowmajor = len(basenames_list) - 1 - dim
        basenames_list[dim] = [f"{name}_{dim_rowmajor}" for name in basenames_list[dim]]
    basenames_flatten = sum(basenames_list, []) 
    name_mapping: dict[str, str] = {}
    for name in basenames_flatten:
        parts = name.split("_")
        dim = int(parts[-1])
        if flatten_name:
            if name in reduce_base_names:
                name_mapping[name] = f"reduce_dim_{dim}"
            else:
                name_mapping[name] = f"non_reduce_dim_{dim}"
        else:
            if name in reduce_base_names:
                name_mapping[name] = f"{parts[0]}_reduce_dim_{dim}"
            else:
                name_mapping[name] = f"{parts[0]}_non_reduce_dim_{dim}"
    name_dim_pairs = get_logical_layout_from_names(basenames_flatten, name_mapping)
    # print(basenames_list)
    shape = [x[1] for x in name_dim_pairs]
    shape_after_reduce = shape.copy()
    reduced_shape = [1 for _ in range(ndim)]
    reduce_axes = []

    local_reduce_axes = [[] for _ in range(ndim)]
    local_reduce_dimsize = [1 for _ in range(ndim)]

    local_reduce_strides = [[] for _ in range(ndim)]
    local_non_reduce_axes = [[] for _ in range(ndim)]
    local_non_reduce_strides = [[] for _ in range(ndim)]
    local_non_reduce_dimsize = [1 for _ in range(ndim)]

    reduce_axes_per_dim = [[] for _ in range(ndim)]
    non_reduce_axes_per_dim = [[] for _ in range(ndim)]
    cur_dim = 0
    cur_dim_offset = 0
    num_dim = 0
    cur_stride = origin_shape[0]
    for i in range(len(name_dim_pairs)):
        name = name_dim_pairs[i][0]
        dim = int(name.split("_")[-1])
        is_reduce_dim = "non_reduce_dim" not in name_dim_pairs[i][0]
        if is_reduce_dim:
            reduce_axes.append(i)
            shape_after_reduce[i] = 1
            reduce_axes_per_dim[dim].append(i)
        else:
            non_reduce_axes_per_dim[dim].append(i)
            reduced_shape[dim] *= shape[i]
        cur_dim_size = shape[i]
        if cur_dim != dim:
            cur_dim_offset += num_dim
            num_dim = 0
            cur_stride = origin_shape[dim]
            cur_dim = dim
        cur_stride //= cur_dim_size
        if is_reduce_dim:
            local_reduce_axes[dim].append(i - cur_dim_offset)
            local_reduce_strides[dim].append(cur_stride)
            local_reduce_dimsize[dim] *= cur_dim_size
        else:
            local_non_reduce_axes[dim].append(i - cur_dim_offset)
            local_non_reduce_strides[dim].append(cur_stride)
            local_non_reduce_dimsize[dim] *= cur_dim_size
        num_dim += 1
    return LLReduceResult(
        broadcast_shape=shape,
        reduce_axes=reduce_axes,
        reduced_shape=reduced_shape,
        shape_after_reduce=shape_after_reduce,
        local_reduce_axes=local_reduce_axes,
        local_reduce_strides=local_reduce_strides,
        local_non_reduce_axes=local_non_reduce_axes,
        local_non_reduce_strides=local_non_reduce_strides,
        local_reduce_dimsize=local_reduce_dimsize,
        local_non_reduce_dimsize=local_non_reduce_dimsize,
        reduce_axes_per_dim=reduce_axes_per_dim,
        non_reduce_axes_per_dim=non_reduce_axes_per_dim,
        basenames=basenames_list,
    )
    
    # return shape, reduce_axes, reduced_shape, shape_after_reduce, local_reduce_axes, local_reduce_strides

