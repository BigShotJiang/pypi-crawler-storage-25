import enum
from typing import Callable, TypeVar, cast
from triton.experimental.gluon import language as ttgl
from triton.experimental.gluon.language._core import builtin, _unwrap_if_constexpr
from triton.experimental.gluon.language._layouts import DotOperandLayout, NVMMADistributedLayout
from triton._C.libtriton import ir
from ttfs.core.aggtype import gluon_jit, constexpr_function
from ttfs.core.layout import get_default_block_layout
from ttfs.core import sym
from ttfs.core.mp import get_num_warps
import triton.language as tl


@builtin
def mma_v2(a, b, acc=None, layout=None, dtype=None, input_precision=None, _semantic=None):
    input_precision = _unwrap_if_constexpr(input_precision)
    assert isinstance(a, ttgl.tensor), "a must be a tensor"
    assert isinstance(b, ttgl.tensor), "b must be a tensor"
    if acc is None:
        assert layout is not None, "layout must be provided if acc is None"
        layout = _unwrap_if_constexpr(layout)
        assert isinstance(layout, NVMMADistributedLayout), f"layout must be provided if acc is None, got {layout}"
        assert dtype is not None 
        dtype = _unwrap_if_constexpr(dtype)

        M = a.type.shape[-2]
        N = b.type.shape[-1]
        
        out_type = ttgl._core.distributed_type(dtype, [M, N], layout)
        mma_layout = layout
    else:
        assert isinstance(acc, ttgl.tensor), "acc must be a tensor"
        mma_layout = acc.type.layout
        dtype = acc.dtype
        out_type = acc.type
    assert isinstance(mma_layout, NVMMADistributedLayout), "acc must have an NVMMADistributedLayout"
    assert mma_layout.version == [2, 0], "MMA layout must have version 2.0"

    assert isinstance(a.type.layout, DotOperandLayout), "a must have a DotOperandLayout"
    assert isinstance(b.type.layout, DotOperandLayout), "b must have a DotOperandLayout"
    assert a.type.layout.parent == mma_layout, "a's parent layout must be the same as acc's layout"
    assert b.type.layout.parent == mma_layout, "b's parent layout must be the same as acc's layout"
    assert a.type.layout.operand_index == 0, "a's operand index must be 0"
    assert b.type.layout.operand_index == 1, "b's operand index must be 1"

    handle = _semantic.dot(a, b, acc, input_precision=input_precision, max_num_imprecise_acc=None,
                           out_dtype=dtype).handle
    return ttgl.tensor(handle, out_type)


def _check(cond: bool, msg_fn: Callable[[], str], category=ValueError):
    if not cond:
        raise category(msg_fn())

@builtin
def async_copy_global_to_shared_ex(
    smem,
    pointer,
    mask=None,
    other=None,
    cache_modifier="",
    eviction_policy="",
    volatile=False,
    _semantic=None,
):
    """
    Asynchronously copy elements from global memory to shared memory.

    Args:
        smem (shared_memory_descriptor): Destination shared memory descriptor.
        pointer (tensor): Source pointer tensor.
        mask (tensor, optional): Mask tensor for predicated loads. Defaults to None.
        other (tensor, optional): Tensor to be used if mask is False. Defaults to None.
        cache_modifier (str): Cache modifier specifier. Defaults to "".
        eviction_policy (str): Eviction policy specifier. Defaults to "".
        volatile (bool): Whether the load is volatile. Defaults to False.
    """
    mask = _unwrap_if_constexpr(mask)
    other = _unwrap_if_constexpr(other)

    cache_modifier = _semantic._str_to_load_cache_modifier(cache_modifier)
    eviction_policy = _semantic._str_to_eviction_policy(eviction_policy)
    volatile = _unwrap_if_constexpr(volatile)
    if mask is not None:
        pointer, mask = _semantic.broadcast_impl_value(pointer, mask)
    if other is not None:
        other = _semantic.to_tensor(other)
        other = _semantic.cast(other, pointer.dtype.element_ty)
        pointer, other = _semantic.broadcast_impl_value(pointer, other)

    _check(
        smem.shape == pointer.shape,
        lambda: (
            f"expected smem shape to match pointer shape but got smem.shape = {smem.shape}, pointer.shape = {pointer.shape}"
        ),
    )
    mask_handle = mask.handle if mask is not None else ir.value()
    other_handle = other.handle if other is not None else ir.value()
    _semantic.builder.create_async_copy_global_to_local(
        smem.handle,
        pointer.handle,
        mask_handle,
        other_handle,
        cache_modifier,
        eviction_policy,
        volatile,
    )


_STR_KIND_TO_INT = {
    "add": ir.DESCRIPTOR_REDUCE_KIND.ADD,
    "min": ir.DESCRIPTOR_REDUCE_KIND.MIN,
    "max": ir.DESCRIPTOR_REDUCE_KIND.MAX,
    "inc": ir.DESCRIPTOR_REDUCE_KIND.INC,
    "dec": ir.DESCRIPTOR_REDUCE_KIND.DEC,
    "and": ir.DESCRIPTOR_REDUCE_KIND.AND,
    "or": ir.DESCRIPTOR_REDUCE_KIND.OR,
    "xor": ir.DESCRIPTOR_REDUCE_KIND.XOR,
}


@builtin
def async_tma_reduce_shared_to_global(tensor_desc, kind, coord, src, _semantic=None):
    # kind: string add, min, max, inc, dec, and, or, xor
    kind = _unwrap_if_constexpr(kind)
    kind = _STR_KIND_TO_INT.get(kind, None)
    assert kind is not None, f"unsupported reduce kind: {kind}, expected one of {list(_STR_KIND_TO_INT.keys())}"
    coord = _semantic._convert_to_ir_values(coord, require_i64=False)
    _semantic.builder.create_async_tma_reduce(kind, tensor_desc.handle, coord, src.handle)

@builtin
def bank_conflicts_ex(distr_ty, shared_ty, _semantic=None) -> int:
    """
    This function return -1 instead of raise error when smem is sliced.

    Count the bank conflicts per wavefront of each instruction generated when
    reading/writing the distributed tensor from/to the shared memory descriptor
    using ld.shared/st.shared instructions.

    We define a bank conflict of N to be the excess number of memory accesses that each
    wavefront needs to access the shared memory descriptor. When one uses no ld/st
    vectorization, this is equal to t he number of excess memory accesses per instruction.

    Args:
        distr_ty (distributed_type): The distributed tensor.
        shared_ty (shared_memory_descriptor_type): The shared memory descriptor.

    Returns:
        int: The number of bank conflicts.
    """
    distr_ty = _unwrap_if_constexpr(distr_ty)
    shared_ty = _unwrap_if_constexpr(shared_ty)
    if not isinstance(distr_ty, ttgl.distributed_type):
        raise TypeError(
            f"bank_conflicts expects the register layout to be a distributed_type, got {type(distr_ty)}")

    if not isinstance(shared_ty, ttgl.shared_memory_descriptor_type):
        raise TypeError(
            f"bank_conflicts expects the shared layout to be a shared_memory_descriptor_type, got {type(shared_ty)}"
        )

    if distr_ty.shape != shared_ty.shape:
        raise ValueError(f"register shape {distr_ty.shape} and shared shape {shared_ty.shape} must match")
    if shared_ty.element_ty != distr_ty.element_ty:
        raise ValueError(
            f"mismatched dtypes between register ({distr_ty.element_ty}) and shared ({shared_ty.element_ty}) layouts"
        )
    if shared_ty.shape != shared_ty.alloc_shape[-len(shared_ty.shape):]:
        return -1

    reg_attr = distr_ty.layout._to_ir(_semantic.builder)
    shared_attr = shared_ty.layout._to_ir(_semantic.builder)
    res = _semantic.builder.get_shared_bank_conflicts(reg_attr, shared_attr, list(distr_ty.shape),
                                                    distr_ty.element_ty.primitive_bitwidth)
    
    return res

@constexpr_function
def _get_split_shape(shape):
    return ttgl.tuple([*shape[:-1], 2, shape[-1] // 2])

@constexpr_function
def _get_join_shape(shape):
    return ttgl.tuple([*shape[:-1],shape[-1] * 2])

@constexpr_function
def _get_split_permute(ndim):
    base_left = 1 + ndim - 1
    base_right = 0 + ndim - 1
    remain = list(range(ndim - 1))
    order = [*remain, base_left, base_right]
    return ttgl.tuple(order)

@gluon_jit
def split_n(x, SUBTILE_FACTOR: ttgl.constexpr):
    split_count: ttgl.constexpr = SUBTILE_FACTOR.bit_length() - 1  # log2
    xs = (x, )
    for _ in ttgl.static_range(split_count):
        next_xs = ()
        for j in ttgl.static_range(len(xs)):
            x = xs[j]
            # Reshape to (M, 2, N//2) then permute so that tensor elements
            # remain contiguous along N.
            new_order = _get_split_permute(len(x.shape))
            next_xs += x.reshape(_get_split_shape(x.shape)).permute(new_order).split()
        xs = next_xs
    return xs

@gluon_jit
def join_n(xs):
    split_count: ttgl.constexpr = len(xs).bit_length() - 1  # log2
    for _ in ttgl.static_range(split_count):
        next_xs = ()
        for j in ttgl.static_range(0, len(xs), 2):
            x1 = xs[j]
            x2 = xs[j + 1]
            # if len(x1.shape) == 2:
            #     next_xs += (ttgl.join(x1, x2).permute(0, 2, 1).reshape([x1.shape[0], x1.shape[1] * 2]), )
            # elif len(x1.shape) == 1:
            #     next_xs += (ttgl.join(x1, x2).permute(1, 0).reshape([x1.shape[0] * 2]), )
            # else:
            new_order = _get_split_permute(len(x1.shape))
            next_xs += (ttgl.join(x1, x2).permute(new_order).reshape(_get_join_shape(x1.shape)), )
        xs = next_xs
    return xs[0]

# @constexpr_function
# def check_misaligned_for_padded_shared(smem_layout, value_ll_layout):
#     ll_vec_load = 
#     if isinstance(smem_layout, ttgl.PaddedSharedLayout):
#         for pad_pair in smem_layout.interval_padding_pairs:
#             pad_val = pad_pair[1]
#         pass

@constexpr_function
def format_string(v, *args):
    return v.format(*args)

@constexpr_function
def _ones_list(num):
    return [1 for _ in range(num)]


@gluon_jit 
def scalar_to_blocked_tensor(x: ttgl.tensor, shape: ttgl.constexpr):
    """Convert a scalar (illegal in triton programming model) to a real blocked tensor.
    In Triton/Gluon, they use blocked programming model. for scalar values, they assume they have
    same value across the whole tile. if we use some hack method such as inline asm to create a scalar
    with different value across tile, you will get undefined behavior with triton blocked ops, especially
    store operation.

    before you touch any triton/gluon blocked ops, you should convert your scalar to blocked tensor by this method.
    note that currently it's impossible to convert a tensor back to scalar.

    note that this only available on gluon, because we can't control layout in triton.
    """
    num_warps: ttgl.constexpr = get_num_warps()
    res = ttgl.zeros(shape, dtype=x.dtype, layout=get_default_block_layout(
        shape, _ones_list(len(shape)), sym.arange(len(shape), is_reverse=True), num_warps,  32
    ))
    ttgl.static_assert(x.numel == 1)
    # triton will use broadcasted layout from arguments in returned value, so we use a dummy tensor to hack this.
    return ttgl.inline_asm_elementwise(format_string("mov.b{} $0,$1; // dummy $2", 
        x.dtype.primitive_bitwidth), "=r,r,r", [x, res], dtype=x.dtype, is_pure=True, pack=1)

@gluon_jit 
def reshape(v, new_shape: ttgl.constexpr):
    return v.reshape(sym.get_newshape_for_reshape(v.shape, new_shape)) 
