"""
Event Type: tma/cp async global load, tma async global store, start wait/end wait


event format:

1. profile event (no arg)

8-bit constant string id (generated during compilation), up to 256 different constant strings (with dtypes if debug_event).
3-bit base type, 1-bit start/end + 2-bit profile/debug/tensor/meta type

5-bit event generic type

11 + 32 bit timestamp

use two 32-bit integer to store.

2. debug event (with arg)

profile event + up to 6 32-bit args, with total 8 32-bit integer to store. 0xFF... means invalid arg.

3. meta event (with arg)

profile event + up to 14 32-bit args, with total 16 32-bit integer to store. 0xFF... means invalid arg.
this event is stored to global directly.


4. tensor event

profile event + up to 6 32-bit args, then store whole tensor.
this event don't support smem based recording.

"""

import contextlib
import contextvars
import math
import enum
from typing import Annotated, Any, Optional, Self

import torch
from ttfs.gl.ops import scalar_to_blocked_tensor, join_n, split_n
from ttfs.core.aggtype import (
    FieldMeta,
    aggregate,
    aggregate_replace,
    constexpr_function,
    get_scalar_tensor,
    triton_jit,
)
import triton.language as tl
from triton.experimental.gluon import language as gl
from ttfs.core import sym
from ttfs.core import mp
from ttfs.core.ttdict import TTDict
from ttfs.ops.constants import CUDA_WARP_SIZE
from triton.experimental.gluon.language.nvidia.hopper import tma, fence_async_shared
from ttfs.core.logger import logger as LOGGER
from ttfs.ops import cuda as cuda_ops
from ttfs.core.layout import get_default_block_layout, get_default_block_io_layout
from .core import EventTensorPlaceholder, get_event_record_parser_ctx, RecordStaticDict
from ttfs.core.ttdict import raw_ttdict
from . import constants as rec_constants


@aggregate
class EventRecorderArgs:
    # global buf: [num_partition, buf_length]
    global_buf_ptr: Optional[tl.tensor]
    buf_length: tl.tensor
    # smem buf: [num_partition * num_event, event_length (2/8)], 16 will directly write to global, no smem used.
    flags: tl.constexpr
    max_num_partition: tl.constexpr
    smem_num_events: tl.constexpr = 0
    program_id_x: tl.constexpr = 0
    program_id_y: tl.constexpr = 0
    program_id_z: tl.constexpr = 0

    @triton_jit
    def create_recorder(self, enabled):
        if self.flags & rec_constants.RECORD_FLAGS_RECORD_ALL_BLOCK:
            enabled_final = enabled
        else:
            enabled_final = (
                enabled
                and self.program_id_x == gl.program_id(0)
                and self.program_id_y == gl.program_id(1)
                and self.program_id_z == gl.program_id(2)
            )

        return EventRecorder(
            static_enabled=self.global_buf_ptr is not None,
            enabled=enabled_final,
            global_buf_ptr=self.global_buf_ptr,
            buf_length=self.buf_length,
            max_num_partition=self.max_num_partition,
            cur_offset_global=tl.core.to_tensor(0),
            cur_offset_smem=tl.core.to_tensor(0),
            event_cnt=tl.core.to_tensor(0),
            is_smem_store_thread=tl.core.to_tensor(False),
            global_base_ts=tl.core.to_tensor(0),
            smem_num_events=self.smem_num_events,
            flags=self.flags,
        )

    @staticmethod
    def get_empty():
        return EventRecorderArgs(
            global_buf_ptr=None,
            buf_length=0,
            flags=0,
            max_num_partition=1,
        )


def empty_recorder():
    return EventRecorderArgs.get_empty()


@sym.workaround_ignore_cache_record
def _format_static_event_bits_impl(
    scope_id_key,
    is_start: bool,
    base_type: int,
    has_user: bool,
    scope_id_width: int = rec_constants.RECORD_SCOPE_ID_WIDTH.value,
):
    """
    ┌─────────────────────┌────────────────────┌────────────┌──────────────────────────┐
    │        ??b          │           ??b      │    3b      │           11b            │
    └─────────────────────└────────────────────└────────────└──────────────────────────┘
        user area                   scope id      base           cycle high
    """
    ctx = get_event_record_parser_ctx()
    assert ctx is not None, "event record parser context is not set"
    ev_id = ctx.query_id(scope_id_key, is_start, base_type, scope_id_width)
    assert ev_id < 2**scope_id_width, (
        f"too many different events, exceed {2**scope_id_width}"
    )
    base_3b = is_start << 2 | (base_type & 0b11)
    user_width = 32 - 14 - scope_id_width
    if has_user:
        final_bits = (ev_id << 14) | (base_3b << 11)
    else:
        final_bits = (
            (ev_id << 14)
            | (base_3b << 11)
            | ((2**user_width - 1) << (14 + scope_id_width))
        )
    # remain is FFFF
    return final_bits


def _parse_args_ttdict_impl(
    args_ttdict: TTDict, is_start: bool, base_type: int, allow_tensor: bool = True
):
    items = {}
    slots = []
    tensors = []
    for key, item_cw in zip(
        tl.core._unwrap_if_constexpr(args_ttdict.keys), args_ttdict.values_cw
    ):
        item = item_cw.value
        if isinstance(item, tl.constexpr):
            item = item.value
        if isinstance(item, (mp.TritonConstexprField, mp.TritonField)):
            item = item.value
        if isinstance(item, tl.constexpr):
            item = item.value

        if isinstance(item, (int, bool, str, tl.dtype, type(None))):
            items[key] = item
        elif isinstance(item, (tl.tensor)):
            if not allow_tensor:
                raise ValueError("tensor type is not allowed in nested ttdict")
            assert item.numel == 1 and not item.type.is_block(), (
                "only support scalar tensor as part of scope_id_key"
            )
            assert item.dtype.primitive_bitwidth <= 32, (
                "only support scalar tensor with bitwidth <= 32 as part of scope_id_key"
            )
            items[key] = None  # set during postprocess
            slots.append((key, EventTensorPlaceholder.create(len(tensors), item.dtype)))
            tensors.append(item)
        elif isinstance(item, tl.tuple):
            slot_list: list[tuple[int, EventTensorPlaceholder]] = []
            res_list = [None] * len(item.values)
            for i, titem in enumerate(item.values):
                if isinstance(titem, tl.constexpr):
                    titem = titem.value
                if isinstance(titem, (mp.TritonConstexprField, mp.TritonField)):
                    titem = titem.value
                if isinstance(titem, tl.constexpr):
                    titem = titem.value
                if isinstance(titem, (int, bool, str, tl.dtype, type(None))):
                    res_list[i] = titem
                elif isinstance(titem, (tl.tensor)):
                    if not allow_tensor:
                        raise ValueError("tensor type is not allowed in nested ttdict")
                    assert titem.numel == 1 and not item.type.is_block(), (
                        "only support scalar tensor as part of scope_id_key"
                    )
                    assert titem.dtype.primitive_bitwidth <= 32, (
                        "only support scalar tensor with bitwidth <= 32 as part of scope_id_key"
                    )
                    res_list[i] = None
                    slot_list.append(
                        (i, EventTensorPlaceholder.create(len(tensors), item.dtype))
                    )
                    tensors.append(titem)
                else:
                    raise ValueError(
                        f"unsupported scope_id_key item type: {type(item)}"
                    )
            if slot_list:
                slots.append((key, slot_list))
            items[key] = tuple(res_list)
        elif isinstance(item, TTDict):
            items[key] = _parse_args_ttdict_impl(
                item, is_start, base_type, allow_tensor=False
            )[0]
        else:
            raise ValueError(f"unsupported scope_id_key item type: {type(item)}")
    return items, slots, tensors


@tl.core.builtin
def _parse_args_ttdict(
    args_ttdict: TTDict,
    is_start: bool,
    base_type: int,
    scope_id_width: int = rec_constants.RECORD_SCOPE_ID_WIDTH.value,
    has_user: bool = False,
    _semantic=None,
):
    items, slots, tensors = _parse_args_ttdict_impl(
        args_ttdict, is_start, base_type, allow_tensor=True
    )

    is_start = tl.core._unwrap_if_constexpr(is_start)
    base_type = tl.core._unwrap_if_constexpr(base_type)
    scope_id_width = tl.core._unwrap_if_constexpr(scope_id_width)
    has_user = tl.core._unwrap_if_constexpr(has_user)
    final_bits = _format_static_event_bits_impl(
        RecordStaticDict(items, slots, len(tensors)),
        is_start,
        base_type,
        has_user,
        scope_id_width,
    )
    return mp.TritonConstexprField(final_bits), tl.tuple(tensors)


@triton_jit
def read_clock_words():
    return gl.inline_asm_elementwise(
        """
        mov.u32 $0, %clock;
        mov.u32 $1, %clock_hi;
        """,
        "=r,=r",
        [],
        dtype=(gl.uint32, gl.uint32),
        is_pure=False,
        pack=1,
    )


@triton_jit
def read_globaltimer():
    return gl.inline_asm_elementwise(
        "mov.u64 $0, %globaltimer;",
        "=l",
        [],
        dtype=gl.uint64,
        is_pure=False,
        pack=1,
    )


@triton_jit
def read_globaltimer_words():
    return gl.inline_asm_elementwise(
        """
        mov.u32 $0, %globaltimer_lo;
        mov.u32 $1, %globaltimer_hi;
        """,
        "=r,=r",
        [],
        dtype=(gl.uint32, gl.uint32),
        is_pure=False,
        pack=1,
    )


@triton_jit
def create_profile_event_global_off(
    base_time,
    args_ttdict: TTDict,
    is_start: tl.constexpr,
    base_type: tl.constexpr,
    pack_length: tl.constexpr,
    ts_override: tl.tensor | None = None,
    user_scalar: tl.tensor | None = None,
):
    state_bits_cw, tensors = _parse_args_ttdict(
        args_ttdict,
        is_start,
        base_type,
        scope_id_width=rec_constants.RECORD_SCOPE_ID_WIDTH,
        has_user=user_scalar is not None,
    )
    state_bits: tl.constexpr = state_bits_cw.value

    if user_scalar is not None:
        tl.static_assert(
            user_scalar.numel == 1 and not user_scalar.type.is_block(),
            "only support scalar tensor as user value",
        )
        tl.static_assert(
            not user_scalar.dtype.is_floating(),
            "only support non-float tensor as user value",
        )
        state_bits = state_bits | (
            user_scalar.cast(tl.uint32, bitcast=True)
            << (14 + rec_constants.RECORD_SCOPE_ID_WIDTH)
        )
    if ts_override is not None:
        tl.static_assert(
            is_start, "ts_override should only be provided for start event"
        )
        now = ts_override
    else:
        now = read_globaltimer()
    delta = now - base_time
    word0 = state_bits | gl.cast((delta >> 32) & 0x7FF, gl.uint32)
    word1 = gl.cast(delta & 0xFFFFFFFF, gl.uint32)
    return pack_event((word0, word1) + tensors, pack_length)


@triton_jit
def create_profile_event_cycle(
    args_ttdict: TTDict,
    is_start: tl.constexpr,
    base_type: tl.constexpr,
    pack_length: tl.constexpr,
    ts_override: tl.tuple | None = None,
    user_scalar: tl.tensor | None = None,
):
    state_bits_cw, tensors = _parse_args_ttdict(
        args_ttdict,
        is_start,
        base_type,
        scope_id_width=rec_constants.RECORD_SCOPE_ID_WIDTH,
        has_user=user_scalar is not None,
    )
    state_bits: tl.constexpr = state_bits_cw.value
    if user_scalar is not None:
        tl.static_assert(
            user_scalar.numel == 1 and not user_scalar.type.is_block(),
            "only support scalar tensor as user value",
        )
        tl.static_assert(
            not user_scalar.dtype.is_floating(),
            "only support non-float tensor as user value",
        )

        state_bits = state_bits | (
            user_scalar.cast(tl.uint32, bitcast=True)
            << (14 + rec_constants.RECORD_SCOPE_ID_WIDTH)
        )

    if ts_override is not None:
        tl.static_assert(
            is_start, "ts_override should only be provided for start event"
        )
        clk_lo = ts_override[0]
        clk_hi = ts_override[1]
    else:
        clk_lo, clk_hi = read_clock_words()

    word0 = state_bits | (clk_hi & 0x7FF)
    word1 = clk_lo
    return pack_event((word0, word1) + tensors, pack_length)


@constexpr_function
def get_pack_length(base_type):
    if base_type == 0:  # profile
        return 2
    elif base_type == 1:  # debug
        return 8
    elif base_type == 2:  # tensor
        return 8
    else:  # meta
        return 16


@triton_jit
def get_tensor_meta_ttdict_cw(ten):
    return raw_ttdict(
        tensor_dtype=mp.TritonConstexprField(ten.dtype),
        tensor_shape=mp.TritonConstexprField(ten.shape),
    )


@constexpr_function
def get_tensor_store_nwords(ten: tl.tensor):
    return (ten.numel * ten.dtype.primitive_bitwidth + 31) // 32


@triton_jit
def cast_to_uint(scalar):
    if isinstance(scalar, int):
        return tl.cast(tl.core.to_tensor(scalar), tl.uint32)
    else:
        dtype_bitwidth: tl.constexpr = scalar.dtype.primitive_bitwidth
        if dtype_bitwidth == 32:
            return tl.cast(scalar, tl.uint32, bitcast=True)
        elif dtype_bitwidth == 16:
            return tl.cast(tl.cast(scalar, tl.uint16, bitcast=True), tl.uint32)
        elif dtype_bitwidth == 8:
            return tl.cast(tl.cast(scalar, tl.uint8, bitcast=True), tl.uint32)
        else:
            raise ValueError(f"unsupported scalar dtype bitwidth: {dtype_bitwidth}")


@triton_jit
def _get_offset_1d(ten, idx: tl.constexpr):
    offset_1d = gl.arange(
        0,
        ten.shape[idx],
        layout=sym.get_sliced_layout_cw(ten.type.layout, len(ten.shape), idx),
    )
    axes: tl.constexpr = sym.get_sliced_axes(len(ten.shape), idx, descending=False)
    for j in tl.static_range(len(axes)):
        offset_1d = offset_1d.expand_dims(axes[j])
    return offset_1d


@triton_jit
def _get_tensor_store_offsets(ten):
    offset_1ds = ()
    for i in tl.static_range(len(ten.shape)):
        offset_1d = _get_offset_1d(ten, i)
        offset_1ds += (offset_1d,)
    return offset_1ds


@constexpr_function
def _get_tensor_strides(ten):
    strides = ()
    stride = 1
    for i in range(len(ten.shape) - 1, -1, -1):
        strides = (stride,) + strides
        stride *= ten.shape[i]
    return strides


@triton_jit
def pack_event(pack_tensors, pack_length: tl.constexpr):
    num_warps: tl.constexpr = mp.get_num_warps()
    res_fake = gl.zeros(
        [num_warps * CUDA_WARP_SIZE, pack_length],
        dtype=tl.uint32,
        layout=get_default_block_layout(
            [num_warps * CUDA_WARP_SIZE, pack_length],
            [1, pack_length],
            [1, 0],
            num_warps,
            CUDA_WARP_SIZE,
        ),
    )
    res_fake = res_fake.sum(
        0
    )  # make new sliced tensor, we only store event per warp partition (tile level)
    if pack_length == 2:
        tl.static_assert(
            len(pack_tensors) == 2, f"profile-only mode don't support tensor arg."
        )
    else:
        tl.static_assert(
            len(pack_tensors) <= pack_length + 2,
            f"too many tensors to pack into event (up to {pack_length})",
        )
    for i in tl.static_range(len(pack_tensors), pack_length):
        pack_tensors += (tl.core.to_tensor(0xFFFFFFFF),)
    pack_tensors_u32 = ()
    for i in tl.static_range(len(pack_tensors)):
        u32_ten = scalar_to_blocked_tensor(cast_to_uint(pack_tensors[i]), [1])
        pack_tensors_u32 += (u32_ten,)
    res = join_n(pack_tensors_u32)
    return gl.convert_layout(res, res_fake.type.layout, assert_trivial=True)


@aggregate
class EventRecorder:
    enabled: tl.tensor
    # global buf: [num_partition, buf_length]
    global_buf_ptr: Optional[tl.tensor]
    buf_length: tl.tensor

    cur_offset_global: tl.tensor
    # when we use smem mode, we use a tensor desc and store whole smem block to global.
    cur_offset_smem: tl.tensor
    is_smem_store_thread: tl.tensor
    event_cnt: tl.tensor
    global_base_ts: tl.tensor

    # smem buf: [num_partition * num_event, event_length (2/8)], 16 will directly write to global, no smem used.
    flags: tl.constexpr
    max_num_partition: tl.constexpr
    smem_num_events: tl.constexpr = 0
    # currently we only support record event in one block.
    program_id_x: tl.constexpr = 0
    program_id_y: tl.constexpr = 0
    program_id_z: tl.constexpr = 0
    global_buf_desc: Optional[gl.nvidia.hopper.tma.tensor_descriptor] = None
    _is_ready: Annotated[bool, tl.constexpr] = False
    partition_idx: Annotated[int, tl.constexpr] = -1
    smem: Optional[gl.shared_memory_descriptor] = None
    static_enabled: tl.constexpr = False

    @triton_jit
    def prepare(
        self,
        partition_idx: tl.constexpr,
        smem_num_events: tl.constexpr = None,
        name: tl.constexpr = None,
    ):
        if self.static_enabled:
            tl.static_assert(
                partition_idx >= 0 and partition_idx < self.max_num_partition,
                f"partition_idx {partition_idx} out of range [0, {self.max_num_partition})",
            )
            num_warps: tl.constexpr = mp.get_num_warps()
            num_threads: tl.constexpr = num_warps * CUDA_WARP_SIZE
            thread_id = cuda_ops.thread_id(out_dtype=tl.int32)  # use inline ptx
            thread_id_blocked = scalar_to_blocked_tensor(
                thread_id, [num_threads]
            )  # use inline ptx
            # for warp specialize, we assume each partition have contiguous thread ids
            min_thread_id = thread_id_blocked.min().item()

            if smem_num_events is None:
                num_smem_events_final: tl.constexpr = self.smem_num_events
            else:
                num_smem_events_final: tl.constexpr = smem_num_events
            if self.flags & rec_constants.RECORD_FLAGS_IS_CIRCULAR:
                if self.smem_num_events is not None:
                    tl.static_assert(
                        self.smem_num_events >= num_smem_events_final,
                        f"your provided smem_num_events {smem_num_events} must <= {self.smem_num_events}",
                    )
                tl.static_assert(
                    self.smem_num_events is not None and num_smem_events_final > 0,
                    "circular buffer must use smem to store events, smem_num_events must be greater than 0",
                )
            if num_smem_events_final > 0:
                allow_scalar_args: tl.constexpr = (
                    self.flags & rec_constants.RECORD_FLAGS_ALLOW_SCALAR_ARGS
                )
                smem = gl.allocate_shared_memory(
                    gl.uint32,
                    [num_smem_events_final, 2 if not allow_scalar_args else 8],
                    gl.SwizzledSharedLayout(1, 1, 1, [0]),
                )
            else:
                smem = None
            if self.flags & rec_constants.RECORD_FLAGS_RECORD_ALL_BLOCK:
                num_blocks = (
                    gl.num_programs(0) * gl.num_programs(1) * gl.num_programs(2)
                )
                block_idx_flat = (
                    gl.program_id(0)
                    + gl.program_id(1) * gl.num_programs(0)
                    + gl.program_id(2) * gl.num_programs(0) * gl.num_programs(1)
                )
            else:
                num_blocks = 1
                block_idx_flat = tl.core.to_tensor(0)
            if not isinstance(
                self.global_buf_ptr, gl.nvidia.hopper.tma.tensor_descriptor
            ):
                # offset global buf ptr
                if self.flags & rec_constants.RECORD_FLAGS_RECORD_ALL_BLOCK:
                    global_buf_ptr = (
                        self.global_buf_ptr
                        + (partition_idx * num_blocks + block_idx_flat)
                        * self.buf_length
                    )
                else:
                    global_buf_ptr = (
                        self.global_buf_ptr + partition_idx * self.buf_length
                    )
            else:
                global_buf_ptr = self.global_buf_ptr
            res = aggregate_replace(
                self,
                _is_ready=True,
                partition_idx=partition_idx,
                smem=smem,
                global_buf_ptr=global_buf_ptr,
                is_smem_store_thread=min_thread_id == thread_id,
            )
            gw = read_globaltimer()
            gw0, gw1 = read_globaltimer_words()
            sm_id = cuda_ops.sm_id()
            # here we store program ids, we may support multiple prograd record in future.
            record_dict = raw_ttdict(
                partition_name=name,
                num_smem_events=num_smem_events_final,
                event_cnt=tl.core.to_tensor(0),  # finalize event cnt
                ts_lo=gw0,
                ts_hi=gw1,
                sm_id=sm_id,
                pidx=tl.program_id(0),
                pidy=tl.program_id(1),
                pidz=tl.program_id(2),
                end_ts_lo=tl.core.to_tensor(0).cast(tl.uint32),  # finalize ts lo
                end_ts_hi=tl.core.to_tensor(0).cast(tl.uint32),  # finalize ts hi
                block_idx_flat=block_idx_flat,
                # flush_end_ts_lo=tl.core.to_tensor(0).cast(tl.uint32), # finalize ts lo
                # flush_end_ts_hi=tl.core.to_tensor(0).cast(tl.uint32), # finalize ts hi
            )
            if self.flags & rec_constants.RECORD_FLAGS_IS_CYCLE_MODE:
                cw0, cw1 = read_clock_words()
                record_dict = record_dict.update(
                    raw_ttdict(
                        cycle_lo=cw0,  # finalize ts lo
                        cycle_hi=cw1,  # finalize ts hi
                        end_cycle_lo=tl.core.to_tensor(0).cast(
                            tl.uint32
                        ),  # finalize ts lo
                        end_cycle_hi=tl.core.to_tensor(0).cast(
                            tl.uint32
                        ),  # finalize ts hi
                    )
                )
            res = res._record_meta_event(record_dict)

            return aggregate_replace(res, global_base_ts=gw)
        else:
            return self

    @triton_jit
    def finalize(self):
        if self.static_enabled:
            # WARNING: must call this before partition return if you use warp specialize.
            # store event cnt to third world of buf and end timestamp
            # TODO better way?
            if self.enabled:
                gl.store(self.global_buf_ptr + 2, self.event_cnt)
                gw0, gw1 = read_globaltimer_words()
                gl.store(self.global_buf_ptr + 9, gw0)
                gl.store(self.global_buf_ptr + 10, gw1)
                if self.flags & rec_constants.RECORD_FLAGS_IS_CYCLE_MODE:
                    cw0, cw1 = read_clock_words()
                    gl.store(self.global_buf_ptr + 14, cw0)
                    gl.store(self.global_buf_ptr + 15, cw1)

                if self.smem is not None:
                    res = self._flush_smem()
                else:
                    res = self
                return res
            else:
                return self
        else:
            return self

    @triton_jit
    def _record_meta_event(self, args_ttdict: TTDict):
        tl.static_assert(
            self._is_ready, "EventRecorder is not ready, call prepare() first"
        )
        pack_length: tl.constexpr = 16
        base_type: tl.constexpr = 3  # meta event
        event_ten = create_profile_event_global_off(
            self.global_base_ts, args_ttdict, True, base_type, pack_length
        )
        cur_offset_smem = self.cur_offset_smem
        cur_offset_global = self.cur_offset_global
        if self.enabled and cur_offset_global + pack_length <= self.buf_length:
            offs_m = (
                gl.arange(0, pack_length, layout=gl.AutoLayout()) + cur_offset_global
            )
            gl.store(self.global_buf_ptr + offs_m, event_ten)
            cur_offset_global += pack_length
        return aggregate_replace(
            self,
            cur_offset_smem=cur_offset_smem,
            cur_offset_global=cur_offset_global,
            event_cnt=self.event_cnt + 1,
        )

    @triton_jit
    def record_profile_event(
        self,
        is_start: tl.constexpr,
        args: TTDict = TTDict(),
        _frame_cnt: tl.constexpr = 2,
        ext_start_ts=None,
        user_scalar: tl.tensor | None = None,
    ):
        return self._record_event(
            0,
            args,
            is_start,
            _frame_cnt=_frame_cnt,
            ext_start_ts=ext_start_ts,
            user_scalar=user_scalar,
        )

    @triton_jit
    def record_debug_event(
        self,
        args: TTDict,
        user_scalar: tl.tensor | None = None,
        _frame_cnt: tl.constexpr = 2,
    ):
        return self._record_event(1, args, True, _frame_cnt, user_scalar=user_scalar)

    @triton_jit
    def is_profile_only_cw(self):
        return mp.TritonConstexprField(
            not (self.flags & rec_constants.RECORD_FLAGS_ALLOW_SCALAR_ARGS)
        )

    @triton_jit
    def allow_tensor_event_cw(self):
        return mp.TritonConstexprField(
            (self.flags & rec_constants.RECORD_FLAGS_ALLOW_TENSOR_EVENT)
        )

    @triton_jit
    def get_start_profile_ts(self):
        if self.flags & rec_constants.RECORD_FLAGS_IS_CYCLE_MODE:
            return read_clock_words()
        else:
            return read_globaltimer()

    @triton_jit
    def _flush_smem(self):
        cur_offset_smem = self.cur_offset_smem
        cur_offset_global = self.cur_offset_global

        # flush smem to global
        if self.global_buf_desc is not None:
            tl.static_assert(False, "not supported for now")
            fence_async_shared()
            tma.async_copy_shared_to_global(
                self.global_buf_desc, [self.partition_idx, cur_offset_global], self.smem
            )
            tma.store_wait(0)
            cur_offset_global += self.smem.shape[0] * self.smem.shape[1]
        else:
            # WARNING: you need a deep understanding of triton/gluon to modify following code.
            # we use batched processing pattern to flush smem, to allow smem dynamic indexing, we need to use
            # smem.index api (slice api don't allow dynamic access) to store each profile event,
            # then flush them to global when full.
            # unfortunately, we can't reinterpret smem remove the "index" virtual dim.
            # we must use a for loop to load each event in index dim to register, then store to global.
            # which is very slow.

            # our hack use illegal non-uniform scalar, we create thread id from inline ptx, then use it to "index" the smem.
            # triton assumes loaded event tensor is uniform across the entire tile, but in reality it isn’t.
            # to use blocked store, we need to convert "non-uniform" scalar to blocked tensor again.
            pack_length: tl.constexpr = (
                8 if self.flags & rec_constants.RECORD_FLAGS_ALLOW_SCALAR_ARGS else 2
            )
            num_warps: tl.constexpr = mp.get_num_warps()
            num_threads: tl.constexpr = num_warps * CUDA_WARP_SIZE
            thread_id = cuda_ops.thread_id(out_dtype=tl.int32)  # use inline ptx
            thread_id_blocked = scalar_to_blocked_tensor(
                thread_id, [num_threads]
            )  # use inline ptx
            # for warp specialize, we assume each partition have contiguous thread ids
            min_thread_id = thread_id_blocked.min().item()
            thread_id -= min_thread_id
            num_stores: tl.constexpr = max(self.smem_num_events // num_threads, 1)
            num_elem_per_store: tl.constexpr = min(self.smem_num_events, num_threads)

            for j in tl.static_range(num_stores):
                thread_id_offset = (
                    thread_id % self.smem_num_events
                ) + j * num_elem_per_store
                # event_val is "uniform" for triton, if we directly store it via gl.store,
                # only thread 0 will do real store, so we must convert this illegal non-uniform tensor
                # to real blocked tensor.
                event_val = self.smem.index(thread_id_offset).load(
                    get_default_block_layout(
                        [pack_length], [pack_length], [0], num_warps, CUDA_WARP_SIZE
                    )
                )
                loaded_vals = split_n(event_val, pack_length)
                loaded_vals_final = ()
                for k in tl.static_range(pack_length):
                    loaded_vals_final += (
                        scalar_to_blocked_tensor(
                            loaded_vals[k].item(), [num_elem_per_store, 1]
                        ),
                    )  # use inline ptx
                loaded_vals_blocked = join_n(loaded_vals_final).reshape(
                    [num_elem_per_store, pack_length]
                )
                offs_m = (
                    gl.arange(0, num_elem_per_store, layout=gl.AutoLayout())
                    + j * num_elem_per_store
                )
                offs_n = gl.arange(0, self.smem.shape[1], layout=gl.AutoLayout())
                if self.flags & rec_constants.RECORD_FLAGS_IS_CIRCULAR:
                    mask = offs_m[:, None] < max(cur_offset_smem, self.event_cnt)
                else:
                    mask = offs_m[:, None] < cur_offset_smem
                gl.store(
                    self.global_buf_ptr
                    + cur_offset_global
                    + offs_m[:, None] * self.smem.shape[1]
                    + offs_n[None, :],
                    loaded_vals_blocked,
                    mask=mask,
                )
            cur_offset_global += cur_offset_smem * self.smem.shape[1]
            # default_layout: tl.constexpr = get_default_block_io_layout(
            #     tl.uint32, [self.smem.shape[0], self.smem.shape[1]], tl.uint32.primitive_bitwidth, [1, 0], mp.get_num_warps(), CUDA_WARP_SIZE
            # )
            # smem_val = self.smem._reinterpret(gl.uint32, self.smem.shape, layout=gl.SwizzledSharedLayout(1, 1, 1, [1, 0])).load(default_layout)
            # offs_m = gl.arange(0, self.smem.shape[0], layout=gl.SliceLayout(1, default_layout))
            # offs_n = gl.arange(0, self.smem.shape[1], layout=gl.SliceLayout(0, default_layout))
            # gl.store(self.global_buf_ptr + cur_offset_global + offs_m[:, None] * self.smem.shape[1] + offs_n[None, :], smem_val, mask=offs_m[:, None] < cur_offset_smem)
            # cur_offset_global += cur_offset_smem * self.smem.shape[1]

        return aggregate_replace(
            self,
            cur_offset_smem=tl.core.to_tensor(0),
            cur_offset_global=cur_offset_global,
        )

    @triton_jit
    def _record_event(
        self,
        base_type: tl.constexpr,
        args_ttdict: TTDict,
        is_start: tl.constexpr,
        _frame_cnt: tl.constexpr = 1,
        ext_start_ts=None,
        user_scalar: tl.tensor | None = None,
    ):
        tl.static_assert(isinstance(args_ttdict, TTDict), "args must be TTDict")
        if self.static_enabled:
            if self.flags & rec_constants.RECORD_FLAGS_WITH_SOURCE_LOC:
                path_lineno: tl.constexpr = mp.get_cur_jit_path_lineno(_frame_cnt)
                args_ttdict = args_ttdict.update(
                    raw_ttdict(func_path=path_lineno[0], func_lineno=path_lineno[1]),
                    check_unique=True,
                )
            tl.static_assert(
                self._is_ready, "EventRecorder is not ready, call prepare() first"
            )
            pack_length: tl.constexpr = (
                8 if self.flags & rec_constants.RECORD_FLAGS_ALLOW_SCALAR_ARGS else 2
            )
            if not self.flags & rec_constants.RECORD_FLAGS_ALLOW_SCALAR_ARGS:
                tl.static_assert(
                    base_type == 0, "profile_only mode only support profile event"
                )
            else:
                tl.static_assert(
                    base_type != 3,
                    "don't call this for meta event, it only support global io",
                )
            event_cnt = self.event_cnt
            if self.flags & rec_constants.RECORD_FLAGS_IS_CYCLE_MODE:
                event_ten = create_profile_event_cycle(
                    args_ttdict,
                    is_start,
                    base_type,
                    pack_length,
                    user_scalar=user_scalar,
                )
            else:
                event_ten = create_profile_event_global_off(
                    self.global_base_ts,
                    args_ttdict,
                    is_start,
                    base_type,
                    pack_length,
                    user_scalar=user_scalar,
                )
            event_ten_to_store = (event_ten,)
            if ext_start_ts is not None:
                if self.flags & rec_constants.RECORD_FLAGS_IS_CYCLE_MODE:
                    start_event_ten = create_profile_event_cycle(
                        args_ttdict,
                        True,
                        base_type,
                        pack_length,
                        ext_start_ts,
                        user_scalar=user_scalar,
                    )
                else:
                    start_event_ten = create_profile_event_global_off(
                        self.global_base_ts,
                        args_ttdict,
                        True,
                        base_type,
                        pack_length,
                        ext_start_ts,
                        user_scalar=user_scalar,
                    )
                event_ten_to_store = (start_event_ten, event_ten)

            cur_offset_smem = self.cur_offset_smem
            cur_offset_global = self.cur_offset_global
            # when we use circular buffer, we can ensure global buffer is always enough, so no need to check boundry.

            # WARNING: when we use smem, we always use last smem slot as a reserved slot, which means only N - 1 slot are used for events.
            # this is because when we use `smem.index(ev_offset).store(event)`, gluon will generate a st.shared without any
            # pred, which means all threads in a block will write to one location, the winner is undefined, so the timestamp
            # recorded is also unstable.
            # We use a workaround to resolve this issue:
            # use `smem.index(gl.where(is_leader_thread, ev_offset, N - 1)).store(event)`
            # to let leader thread store events to real offset, and other threads store to last slot.
            for i in tl.static_range(len(event_ten_to_store)):
                event_ten = event_ten_to_store[i]
                if not (self.flags & rec_constants.RECORD_FLAGS_IS_CIRCULAR):
                    if (
                        self.enabled
                        and cur_offset_global + pack_length <= self.buf_length
                    ):
                        if self.smem is not None:
                            self.smem.index(
                                gl.where(
                                    self.is_smem_store_thread,
                                    cur_offset_smem,
                                    self.smem.shape[0] - 1,
                                )
                            ).store(event_ten)
                            cur_offset_smem += 1
                            if cur_offset_smem == self.smem.shape[0] - 1:
                                new_rec = self._flush_smem()
                                cur_offset_smem = new_rec.cur_offset_smem
                                cur_offset_global = new_rec.cur_offset_global
                        else:
                            offs_m = (
                                gl.arange(0, pack_length, layout=gl.AutoLayout())
                                + cur_offset_global
                            )

                            gl.store(self.global_buf_ptr + offs_m, event_ten)
                            cur_offset_global += pack_length
                        event_cnt += 1
                else:
                    if self.enabled:
                        tl.static_assert(
                            self.smem is not None,
                            "circular buffer must use smem to store events",
                        )
                        self.smem.index(
                            gl.where(
                                self.is_smem_store_thread,
                                cur_offset_smem,
                                self.smem.shape[0] - 1,
                            )
                        ).store(event_ten)
                        cur_offset_smem += 1
                        cur_offset_smem = gl.where(
                            cur_offset_smem == self.smem.shape[0] - 1,
                            tl.core.to_tensor(0),
                            cur_offset_smem,
                        )
                        event_cnt += 1

            return aggregate_replace(
                self,
                cur_offset_smem=cur_offset_smem,
                cur_offset_global=cur_offset_global,
                event_cnt=event_cnt,
            )
        else:
            return self

    @triton_jit
    def record_tensor_event(self, ten, args: TTDict, _frame_cnt: tl.constexpr = 1):
        tl.static_assert(isinstance(args, TTDict), "args must be TTDict")

        if self.static_enabled:
            tl.static_assert(
                self.flags & rec_constants.RECORD_FLAGS_ALLOW_TENSOR_EVENT,
                "allow tensor event flag is not set, can't record tensor event",
            )

            tl.static_assert(
                not (self.flags & rec_constants.RECORD_FLAGS_RECORD_ALL_BLOCK)
                and not (self.flags & rec_constants.RECORD_FLAGS_IS_CIRCULAR),
                "tensor event is not supported when record all blocks or is_circular",
            )
            num_words_to_store: tl.constexpr = get_tensor_store_nwords(ten)
            tensor_meta = get_tensor_meta_ttdict_cw(ten)
            args = args.update(tensor_meta, check_unique=True)
            if self.flags & rec_constants.RECORD_FLAGS_WITH_SOURCE_LOC:
                path_lineno: tl.constexpr = mp.get_cur_jit_path_lineno(_frame_cnt)
                args = args.update(
                    raw_ttdict(func_path=path_lineno[0], func_lineno=path_lineno[1]),
                    check_unique=True,
                )
            tl.static_assert(
                self._is_ready, "EventRecorder is not ready, call prepare() first"
            )
            pack_length: tl.constexpr = (
                8 if self.flags & rec_constants.RECORD_FLAGS_ALLOW_SCALAR_ARGS else 2
            )
            if self.flags & rec_constants.RECORD_FLAGS_IS_CYCLE_MODE:
                event_ten = create_profile_event_cycle(args, True, 2, pack_length)
            else:
                event_ten = create_profile_event_global_off(
                    self.global_base_ts, args, True, 2, pack_length
                )

            cur_offset_smem = self.cur_offset_smem
            cur_offset_global = self.cur_offset_global
            event_cnt = self.event_cnt
            if (
                self.enabled
                and cur_offset_global + pack_length + num_words_to_store
                <= self.buf_length
            ):
                if (
                    not (self.flags & rec_constants.RECORD_FLAGS_IS_CIRCULAR)
                    and self.smem is not None
                    and cur_offset_smem > 0
                ):
                    new_rec = self._flush_smem()
                    cur_offset_smem = new_rec.cur_offset_smem
                    cur_offset_global = new_rec.cur_offset_global
                offs_m = (
                    gl.arange(0, pack_length, layout=gl.AutoLayout())
                    + cur_offset_global
                )
                gl.store(self.global_buf_ptr + offs_m, event_ten)
                cur_offset_global += pack_length
                tensor_store_offs = _get_tensor_store_offsets(ten)
                strides: tl.constexpr = _get_tensor_strides(ten)
                res = tensor_store_offs[0] * strides[0]
                for i in gl.static_range(1, len(strides)):
                    res += tensor_store_offs[i] * strides[i]
                gl.store(
                    tl.cast(self.global_buf_ptr, tl.pointer_type(ten.dtype))
                    + cur_offset_global
                    + res,
                    ten,
                )
                cur_offset_global += num_words_to_store
                event_cnt += 1
            return aggregate_replace(
                self,
                cur_offset_smem=cur_offset_smem,
                cur_offset_global=cur_offset_global,
                event_cnt=event_cnt,
            )
        else:
            return self
