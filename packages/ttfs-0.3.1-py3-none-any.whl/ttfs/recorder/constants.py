import triton.language as tl 
import enum 


class RecordFlags(enum.IntFlag):
    IS_CIRCULAR = enum.auto()
    ALLOW_SCALAR_ARGS = enum.auto()
    RECORD_ALL_BLOCK = enum.auto()
    IS_CYCLE_MODE = enum.auto()
    ALLOW_TENSOR_EVENT = enum.auto()
    WITH_SOURCE_LOC = enum.auto()

RECORD_FLAGS_IS_CIRCULAR = tl.constexpr(int(RecordFlags.IS_CIRCULAR))
RECORD_FLAGS_ALLOW_SCALAR_ARGS = tl.constexpr(int(RecordFlags.ALLOW_SCALAR_ARGS))
RECORD_FLAGS_RECORD_ALL_BLOCK = tl.constexpr(int(RecordFlags.RECORD_ALL_BLOCK))
RECORD_FLAGS_IS_CYCLE_MODE = tl.constexpr(int(RecordFlags.IS_CYCLE_MODE))

RECORD_FLAGS_ALLOW_TENSOR_EVENT = tl.constexpr(int(RecordFlags.ALLOW_TENSOR_EVENT))
RECORD_FLAGS_WITH_SOURCE_LOC = tl.constexpr(int(RecordFlags.WITH_SOURCE_LOC))

RECORD_SCOPE_ID_WIDTH = tl.constexpr(8)