import dataclasses
from collections import defaultdict
import json
from typing import Optional, Any
import gzip

import numpy as np
import torch

import ttfs
from .core import BaseRecordEventType, EventRecordMetadata, RecordStaticDict
from .constants import RECORD_SCOPE_ID_WIDTH
from ttfs.core.logger import logger as LOGGER
from concurrent.futures import ProcessPoolExecutor
import multiprocessing


@dataclasses.dataclass
class RecordEvent:
    ts: int
    is_start: bool
    type: int

    args: dict[str, Any]
    user_value: int

    def get_name(self):
        if self.type == BaseRecordEventType.DEBUG:
            base_name = f"{self.args['tensor_name']}({self.args['name']})"
        else:
            base_name = self.args["name"]
        return f"{base_name} ({self.args['func_path']}:{self.args['func_lineno']})"


@dataclasses.dataclass
class RecordTensorEvent(RecordEvent):
    tensor: torch.Tensor


@dataclasses.dataclass
class RecordBlock:
    uid_int: int
    events: list[RecordEvent]
    start_ts: int
    end_ts: int
    end_flush_ts: int
    block_id: tuple[int, int, int]
    block_idx_flat: int
    sm_id: int
    partition_idx: int
    raw_args: dict[str, Any]
    partition_name: Optional[str] = None
    is_cycle_mode: bool = False
    cycle_start: int = 0
    cycle_end: int = 0
    raw_cycle_start: int = 0
    raw_cycle_end: int = 0

    def get_default_thread_name(self, use_sm_id: bool = False):
        if use_sm_id:
            uid = self.sm_id
        else:
            uid = self.block_id
        if self.partition_name is not None:
            return f"{uid}<{self.partition_name}-{self.partition_idx}>"
        return f"{uid}<{self.partition_idx}>"


@dataclasses.dataclass
class RecordResult:
    max_num_partition: int
    metadata: EventRecordMetadata
    blocks: list[RecordBlock]

    def to_google_trace_json_gz(
        self,
        group_by_sm_id: bool | None = None,
        with_event_meta: bool | None = None,
        block_info_part0_only: bool = True,
        target_sm_id: int | None = None,
    ):
        if group_by_sm_id is None:
            group_by_sm_id = self.metadata.record_all_block

        json_data = self.to_google_trace_json(
            group_by_sm_id,
            with_event_meta,
            block_info_part0_only,
            target_sm_id=target_sm_id,
        )
        json_str = json.dumps(json_data)
        return gzip.compress(json_str.encode("utf-8"))

    def to_google_trace_json(
        self,
        group_by_sm_id: bool | None = None,
        with_event_meta: bool | None = None,
        block_info_part0_only: bool = True,
        target_sm_id: int | None = None,
    ):
        if group_by_sm_id is None:
            group_by_sm_id = self.metadata.record_all_block
        if with_event_meta is None:
            with_event_meta = not self.metadata.record_all_block
        pid = 0
        meta_events = [
            {
                "name": "process_name",
                "ph": "M",
                "pid": pid,
                "tid": 0,
                "args": {"name": "ttfs-recorder"},
            }
        ]
        overview_pid = 1

        overview_events = [
            {
                "name": "process_name",
                "ph": "M",
                "pid": overview_pid,
                "tid": 0,
                "args": {"name": "ttfs-recorder-overview"},
            }
        ]

        thread_key_to_cnt: dict[tuple[int, Optional[str]], tuple[int, str]] = {}
        blocks = self.blocks.copy()
        if group_by_sm_id:
            blocks.sort(key=lambda x: (x.sm_id, x.partition_idx))
        if target_sm_id is not None:
            blocks = [b for b in blocks if b.sm_id == target_sm_id]
        for i, block in enumerate(blocks):
            trace_id = (
                i
                if not group_by_sm_id
                else (block.sm_id * self.max_num_partition + block.partition_idx)
            )
            thread_key = (trace_id, None)
            default_thread_name = block.get_default_thread_name(
                use_sm_id=group_by_sm_id
            )
            if thread_key not in thread_key_to_cnt:
                thread_key_to_cnt[thread_key] = (
                    len(thread_key_to_cnt),
                    default_thread_name,
                )
            for event in block.events:
                if event.type == BaseRecordEventType.PROFILE:
                    thread_key = (trace_id, event.args["thread_name"])
                    if thread_key not in thread_key_to_cnt:
                        thread_key_to_cnt[thread_key] = (
                            len(thread_key_to_cnt),
                            default_thread_name,
                        )
                elif event.type == BaseRecordEventType.DEBUG:
                    thread_key = (trace_id, None)
                    if thread_key not in thread_key_to_cnt:
                        thread_key_to_cnt[thread_key] = (
                            len(thread_key_to_cnt),
                            default_thread_name,
                        )
        if self.metadata.is_cycle_mode:
            min_ts = min(block.cycle_start for block in blocks) if blocks else 0
        else:
            min_ts = min(block.start_ts for block in blocks) if blocks else 0
        min_ts_global = min(block.start_ts for block in blocks) if blocks else 0
        max_ts_global = max(block.end_ts for block in blocks) if blocks else 0
        min_ts_cycle = min(block.cycle_start for block in blocks) if blocks else 0
        max_ts_cycle = max(block.cycle_end for block in blocks) if blocks else 0

        thread_key_to_name: dict[tuple[int, Optional[str]], str] = {}
        is_kernel_event_set = False
        for k, v in thread_key_to_cnt.items():
            thread_name = f"{v[1]}-{k[1]}" if k[1] is not None else v[1]
            thread_key_to_name[k] = thread_name
            meta_events.append(
                {
                    "name": "thread_name",
                    "ph": "M",
                    "pid": pid,
                    "tid": v[0],
                    "args": {"name": thread_name},
                }
            )
            meta_events.append(
                {
                    "name": "thread_sort_index",
                    "ph": "M",
                    "pid": pid,
                    "tid": v[0],
                    "args": {"sort_index": k[0] if group_by_sm_id else v[0]},
                }
            )
            if not is_kernel_event_set:
                if self.metadata.is_cycle_mode:
                    dur = (max_ts_cycle - min_ts_cycle) / 1000.0
                else:
                    dur = (max_ts_global - min_ts_global) / 1000.0
                dur_ms = (max_ts_global - min_ts_global) / 1000_000
                dur_us = (max_ts_global - min_ts_global) / 1000
                if dur_us > 1000:
                    dur_str = f"{dur_ms:.3f}ms"
                else:
                    dur_str = f"{dur_us:.3f}us"
                kernel_name = f"{self.metadata.kernel_name}|dur={dur_str}"
                kernel_meta = {
                    "dur_ms": (max_ts_global - min_ts_global) / 1000_000,
                    **self.metadata.kernel_infos,
                }
                if (
                    "n_spills" in self.metadata.kernel_infos
                    and self.metadata.kernel_infos["n_spills"] > 0
                ):
                    kernel_name += f"|n_spills={self.metadata.kernel_infos['n_spills']}"
                meta_events.append(
                    {
                        "name": kernel_name,
                        "cat": "meta",
                        "ph": "X",
                        "pid": pid,
                        "tid": v[0],
                        "ts": 0,
                        "dur": dur,
                        "args": kernel_meta,
                    }
                )
                is_kernel_event_set = True
        events = []
        for ev in meta_events[1:]:
            ev = ev.copy()
            ev["pid"] = overview_pid
            overview_events.append(ev)
        for i, block in enumerate(blocks):
            trace_id = (
                i
                if not group_by_sm_id
                else (block.sm_id * self.max_num_partition + block.partition_idx)
            )
            start_ts = (
                block.start_ts if not self.metadata.is_cycle_mode else block.cycle_start
            )
            end_ts = (
                block.end_ts if not self.metadata.is_cycle_mode else block.cycle_end
            )
            name = f"recorder({block.get_default_thread_name()})"
            dur_us = (block.end_ts - block.start_ts) / 1000
            if self.metadata.is_cycle_mode:
                name = f"recorder({block.get_default_thread_name()}|{dur_us:.3f}us)"
            event_block = {
                "name": name,
                "cat": "meta",
                "ph": "X",
                "pid": pid,
                "tid": thread_key_to_cnt[(trace_id, None)][0],
                "ts": (start_ts - min_ts) / 1000.0,
                "dur": max(end_ts - start_ts, 0) / 1000.0,
                "args": {
                    "block_id": block.block_id,
                    "block_idx_flat": block.block_idx_flat,
                    "partition_idx": block.partition_idx,
                    "sm_id": block.sm_id,
                    "duration": (block.end_ts - block.start_ts) / 1000,
                    "start_ms": (block.start_ts - min_ts_global) / 1000_000,
                    "end_ms": (block.end_ts - min_ts_global) / 1000_000,
                },
            }
            overview_event_block = event_block.copy()
            overview_event_block["pid"] = overview_pid
            overview_events.append(overview_event_block)
            if not block_info_part0_only or (
                block_info_part0_only and block.partition_idx == 0
            ):
                events.append(event_block)
            if with_event_meta:
                for event in block.events:
                    if event.type == BaseRecordEventType.PROFILE:
                        tid = thread_key_to_cnt[(trace_id, event.args["thread_name"])][
                            0
                        ]
                        name = event.args["name"]
                        if event.user_value != 0xFFFFFFFF:
                            name += f"|{event.user_value}"
                        events.append(
                            {
                                "name": name,
                                "cat": "profile",
                                "ph": "B" if event.is_start else "E",
                                "pid": pid,
                                "tid": tid,
                                "ts": (event.ts - min_ts) / 1000.0,
                                # "args": event.args,
                                "args": event.args,
                            }
                        )
                    elif event.type == BaseRecordEventType.DEBUG:
                        events.append(
                            {
                                "name": f"{event.args['tensor_name']}({event.args['name']})",
                                "cat": "debug",
                                "ph": "i",
                                "s": "p",
                                "pid": pid,
                                "tid": thread_key_to_cnt[(trace_id, None)][0],
                                "ts": (event.ts - min_ts) / 1000.0,
                                # "args": event.args,
                                "args": event.args,
                            }
                        )
            else:
                for event in block.events:
                    if event.type == BaseRecordEventType.PROFILE:
                        tid = thread_key_to_cnt[(trace_id, event.args["thread_name"])][
                            0
                        ]
                        name = event.args["name"]
                        if event.user_value != 0xFFFFFFFF:
                            name += f"|{event.user_value}"
                        events.append(
                            {
                                "name": name,
                                "cat": "profile",
                                "ph": "B" if event.is_start else "E",
                                "pid": pid,
                                "tid": tid,
                                "ts": (event.ts - min_ts) / 1000.0,
                            }
                        )
                    elif event.type == BaseRecordEventType.DEBUG:
                        events.append(
                            {
                                "name": f"{event.args['tensor_name']}({event.args['name']})",
                                "cat": "debug",
                                "ph": "i",
                                "s": "p",
                                "pid": pid,
                                "tid": thread_key_to_cnt[(trace_id, None)][0],
                                "ts": (event.ts - min_ts) / 1000.0,
                            }
                        )

        if self.metadata.record_all_block:
            res = {"traceEvents": meta_events + events + overview_events}
        else:
            res = {"traceEvents": meta_events + events}

        return res


def _parse_per_block(
    block: RecordBlock,
    buf_per_block: torch.Tensor,
    metadata: EventRecordMetadata,
    id_to_static_data: dict[int, RecordStaticDict],
):
    cur_cnt = 0
    event_size = 2 if metadata.profile_only else 8
    is_circular = metadata.is_circular
    scope_id_width = RECORD_SCOPE_ID_WIDTH.value
    # read metadata
    meta_ev_dict = block.raw_args
    num_event = meta_ev_dict["event_cnt"] - 1  # ignore meta event
    global_ts_lo = meta_ev_dict["ts_lo"]
    global_ts_hi = meta_ev_dict["ts_hi"]

    global_ts = (global_ts_hi << 32) | global_ts_lo
    num_smem_events = meta_ev_dict["num_smem_events"]
    buf_per_block = buf_per_block[16:]
    # cur_cnt += 16
    # print(buf_per_block[cur_cnt:])
    user_value_default = 0xFFFFFFFF >> (14 + scope_id_width)
    if not metadata.allow_tensor_event:
        if is_circular:
            # last slot is reserved for internal usage, see EventRecorder._record_event for more details.
            num_smem_events -= 1
        # if circular and overflow, rotate buffer. may overflow multiple times, so we need to find real start offset
        if is_circular and num_event > num_smem_events:
            buf_per_block = buf_per_block[: num_smem_events * event_size]
            real_start_offset = (num_event % num_smem_events) * event_size
            buf_per_block = torch.cat(
                [buf_per_block[real_start_offset:], buf_per_block[:real_start_offset]]
            )
            num_event = min(num_event, num_smem_events)
        # no tensor event, we can batch process many info.
        total_event_buffer = (
            buf_per_block[: num_event * event_size]
            .reshape(num_event, event_size)
            .numpy()
        )
        profile_ev_0 = total_event_buffer[:, 0]
        profile_ev_1 = total_event_buffer[:, 1]
        scope_id = profile_ev_0 >> 14 & (2**scope_id_width - 1)
        base_3b = (profile_ev_0 >> 11) & 0x7  # 3bit
        user_value = profile_ev_0 >> (14 + scope_id_width)
        is_start = base_3b >> 2 == 1
        base_ev_type = base_3b & 0b11
        clk_hi = profile_ev_0 & 0x7FF
        clk_lo = profile_ev_1
        clk = (clk_hi.astype(np.uint64) << 32) | clk_lo.astype(np.uint64)
        # print("???", clk)
        if metadata.is_cycle_mode and num_event > 0:
            # detect cycle overflow since we only use 43 bit.
            # clk, block.cycle_start and block.cycle_end must be monotonic increasing.
            clk_argsort = np.argsort(clk)
            clk_sorted = clk[clk_argsort]
            is_clk_monotonic = np.all(clk[1:] >= clk[:-1])
            clk_duration = clk_sorted[-1] - clk_sorted[0]
            block_cycle_start_43bit = block.raw_cycle_start & 0x7FFFFFFFFFF
            is_clk_monotonic &= block_cycle_start_43bit < clk_sorted[0]
            is_clk_monotonic &= block.cycle_end - block.cycle_start > clk_duration
            if not is_clk_monotonic:
                raise ValueError(
                    "Cycle overflow detected, you are unlucky, run profile again."
                )
            clk = clk - block_cycle_start_43bit
        if metadata.is_cycle_mode:
            ts_global = block.cycle_start + clk
        else:
            ts_global = global_ts + clk
        ts_global_lst = ts_global.tolist()
        is_start_lst = is_start.tolist()
        user_value = user_value.tolist()

        for j in range(num_event):
            static_data_obj = id_to_static_data[scope_id[j]].static_dict
            args_dict = static_data_obj.get_dict(
                total_event_buffer[j, 2 : 2 + static_data_obj.num_tensor]
            )
            base_type = base_ev_type[j].item()
            event = RecordEvent(
                ts=ts_global_lst[j],
                is_start=is_start_lst[j],
                type=base_type,
                args=args_dict,
                user_value=user_value[j]
                if user_value[j] != user_value_default
                else 0xFFFFFFFF,
            )
            block.events.append(event)

    else:
        for j in range(num_event):
            ev_data = buf_per_block[cur_cnt : cur_cnt + event_size]
            profile_ev_0 = int(ev_data[0].item())
            profile_ev_1 = int(ev_data[1].item())
            scope_id = profile_ev_0 >> 14 & (2**scope_id_width - 1)
            base_3b = (profile_ev_0 >> 11) & 0x7  # 3bit
            user_value = profile_ev_0 >> (14 + scope_id_width)
            static_data_obj = id_to_static_data[scope_id[j]].static_dict
            args_dict = static_data_obj.get_dict(
                ev_data[2 : 2 + static_data_obj.num_tensor]
            )
            is_start = base_3b >> 2 == 1
            base_ev_type = BaseRecordEventType(base_3b & 0b11)
            # clk hi is 11 bit
            clk_hi = profile_ev_0 & 0x7FF
            clk_lo = profile_ev_1
            clk = (clk_hi << 32) | clk_lo
            if metadata.is_cycle_mode:
                ts_global = block.cycle_start + clk
            else:
                ts_global = global_ts + clk
            if base_ev_type != BaseRecordEventType.TENSOR:
                event = RecordEvent(
                    ts=ts_global,
                    is_start=is_start,
                    type=base_ev_type,
                    args=args_dict,
                    user_value=0xFFFFFFFF,
                )
                block.events.append(event)
                cur_cnt += event_size

            else:
                cur_cnt += event_size

                dtype = args_dict["tensor_dtype"]
                dtype_th = ttfs.mp.gluon_dtype_to_torch(dtype)
                shape = args_dict["tensor_shape"]
                numel = 1
                for s in shape:
                    numel *= s
                tensor_data_nwords = (numel * dtype.primitive_bitwidth + 31) // 32
                tensor_data = buf_per_block[cur_cnt : cur_cnt + tensor_data_nwords]
                tensor_data_nbytes = numel * dtype.primitive_bitwidth // 8
                tensor_data_real = tensor_data.view(torch.uint8)[:tensor_data_nbytes]
                tensor = tensor_data_real.view(dtype_th).reshape(shape)
                event = RecordTensorEvent(
                    ts=ts_global,
                    is_start=is_start,
                    type=base_ev_type,
                    args=args_dict,
                    tensor=tensor,
                    user_value=0xFFFFFFFF,
                )
                block.events.append(event)
                cur_cnt += tensor_data_nwords
    return block


def parse_event_data(buf: torch.Tensor, metadata: EventRecordMetadata) -> RecordResult:
    assert buf.device.type == "cpu", "Only support parsing event data on CPU"
    id_to_static_data = {v.scope_id: v for k, v in metadata.event_name_dict.items()}
    event_size = 2 if metadata.profile_only else 8
    res: list[RecordBlock] = []
    if buf.ndim != 3:
        buf = buf[:, None, :]
        # with block
    scope_id_width = RECORD_SCOPE_ID_WIDTH.value

    num_block = buf.shape[1]
    is_circular = metadata.is_circular
    # parse metadata
    block_id_to_parts: dict[tuple[int, int, int], list[RecordBlock]] = {}
    is_circular_overflow_logged: set[int] = set()
    block_id_to_buffer_idx: dict[int, tuple[int, int]] = {}
    LOGGER.warning(
        "[recorder]Start parsing blocks..., num_scope=%s", len(id_to_static_data)
    )
    for block_idx in range(num_block):
        for part_idx in range(buf.shape[0]):
            buf_per_part = buf[part_idx]
            cur_cnt = 0
            buf_per_block = buf_per_part[block_idx]
            # read metadata
            profile_ev_0 = int(buf_per_block[0].item())
            profile_ev_1 = int(buf_per_block[1].item())
            scope_id = profile_ev_0 >> 14 & (2**scope_id_width - 1)
            static_data_meta: RecordStaticDict = id_to_static_data[scope_id].static_dict
            meta_ev_dict = static_data_meta.get_dict(
                buf_per_block[2 : 2 + static_data_meta.num_tensor]
            )
            num_event = meta_ev_dict["event_cnt"]
            if num_event == 0:
                continue
            global_ts_lo = meta_ev_dict["ts_lo"]
            global_ts_hi = meta_ev_dict["ts_hi"]

            global_ts = (global_ts_hi << 32) | global_ts_lo
            sm_id = meta_ev_dict["sm_id"]
            program_id_x = meta_ev_dict["pidx"]
            program_id_y = meta_ev_dict["pidy"]
            program_id_z = meta_ev_dict["pidz"]
            end_global_ts_lo = meta_ev_dict["end_ts_lo"]
            end_global_ts_hi = meta_ev_dict["end_ts_hi"]
            block_idx_flat = meta_ev_dict["block_idx_flat"]
            num_smem_events = meta_ev_dict["num_smem_events"]

            part_name = meta_ev_dict.get("partition_name", None)
            if end_global_ts_lo == 0 and num_event > 1:
                raise ValueError(
                    "you forget to call finalize() in the kernel, or the kernel is killed before finalize() is called"
                )
            end_global_ts = (end_global_ts_hi << 32) | end_global_ts_lo
            uid_int = block_idx_flat * buf.shape[0] + part_idx
            block = RecordBlock(
                uid_int,
                [],
                start_ts=global_ts,
                end_ts=end_global_ts,
                block_id=(program_id_x, program_id_y, program_id_z),
                sm_id=sm_id,
                partition_idx=part_idx,
                block_idx_flat=block_idx_flat,
                partition_name=part_name,
                raw_args=meta_ev_dict,
                end_flush_ts=-1,
                is_cycle_mode=metadata.is_cycle_mode,
            )
            if not metadata.allow_tensor_event:
                if is_circular:
                    # last slot is reserved for internal usage, see EventRecorder._record_event for more details.
                    num_smem_events -= 1
                # if circular and overflow, rotate buffer. may overflow multiple times, so we need to find real start offset
                if is_circular and num_event > num_smem_events:
                    if num_event not in is_circular_overflow_logged:
                        LOGGER.warning(
                            "[recorder]circular buffer overflow detected (%s vs %s), drop old events",
                            num_event,
                            num_smem_events,
                        )
                        is_circular_overflow_logged.add(num_event)

            if metadata.is_cycle_mode:
                cycle_lo = meta_ev_dict["cycle_lo"]
                cycle_hi = meta_ev_dict["cycle_hi"]
                end_cycle_lo = meta_ev_dict["end_cycle_lo"]
                end_cycle_hi = meta_ev_dict["end_cycle_hi"]
                cycle = (cycle_hi << 32) | cycle_lo
                end_cycle = (end_cycle_hi << 32) | end_cycle_lo
                block.cycle_start = cycle
                block.cycle_end = end_cycle
                block.raw_cycle_start = cycle
                block.raw_cycle_end = end_cycle
            # res.append(block)
            if block.block_id not in block_id_to_parts:
                block_id_to_parts[block.block_id] = []
            block_id_to_parts[block.block_id].append(block)
            block_id_to_buffer_idx[uid_int] = (part_idx, block_idx)
    block_id_to_parts_values = list(block_id_to_parts.values())
    if metadata.is_cycle_mode:
        block_id_to_parts_values.sort(key=lambda x: x[0].cycle_start)
    else:
        block_id_to_parts_values.sort(key=lambda x: x[0].start_ts)

    for parts in block_id_to_parts_values:
        parts.sort(key=lambda x: x.partition_idx)
    cycle_sm_offset: dict[int, int] = {}
    res = [block for parts in block_id_to_parts_values for block in parts]

    min_global_ts = min(block.start_ts for block in res) if res else 0
    if metadata.is_cycle_mode:
        # each sm have different base cycle, so we must align them to same, we will use first block in each sm to calculate sm offset.
        sm_to_blocks: dict[int, list[RecordBlock]] = defaultdict(list)
        for block in res:
            sm_to_blocks[block.sm_id].append(block)
        for sm_id, blocks in sm_to_blocks.items():
            blocks.sort(key=lambda x: x.cycle_start)
        for sm_id in sm_to_blocks:
            first_block = sm_to_blocks[sm_id][0]
            cycle_start = first_block.cycle_start
            cycle_end = first_block.cycle_end
            # global_start, global_end = sm_min_global_pair[sm_id]
            global_start = first_block.start_ts
            global_end = first_block.end_ts
            cycle_dur = cycle_end - cycle_start
            global_dur = global_end - global_start
            rate = global_dur / cycle_dur
            global_start_offset = global_start - min_global_ts
            cycle_start_offset = int(global_start_offset / rate)
            cycle_sm_offset[sm_id] = cycle_start_offset - cycle_start
        for block in res:
            block.cycle_start += cycle_sm_offset[block.sm_id]
            if block.cycle_start < 0:
                breakpoint()
            assert block.cycle_start >= 0
            block.cycle_end += cycle_sm_offset[block.sm_id]
    use_mp = True
    if multiprocessing.cpu_count() <= 4 and len(res) <= 16:
        use_mp = False
    if not use_mp:
        LOGGER.warning("[recorder]Start parsing events in each block...")

        for block in res:
            part_idx, block_idx = block_id_to_buffer_idx[block.uid_int]
            buf_per_part = buf[part_idx]
            buf_per_block = buf_per_part[block_idx]
            _parse_per_block(block, buf_per_block, metadata, id_to_static_data)
    else:
        LOGGER.warning(
            "[recorder]Start parsing events in each block by multiple-processing..."
        )

        with ProcessPoolExecutor(min(multiprocessing.cpu_count(), 16)) as executor:
            futures = []
            for block in res:
                part_idx, block_idx = block_id_to_buffer_idx[block.uid_int]
                buf_per_part = buf[part_idx]
                buf_per_block = buf_per_part[block_idx]
                futures.append(
                    executor.submit(
                        _parse_per_block,
                        block,
                        buf_per_block,
                        metadata,
                        id_to_static_data,
                    )
                )
            new_blocks = []
            for future in futures:
                new_blocks.append(future.result())
            res = new_blocks
    LOGGER.warning("[recorder]Parsing Finished.")

    return RecordResult(buf.shape[0], metadata, res)
