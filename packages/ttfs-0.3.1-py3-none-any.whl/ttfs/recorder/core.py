import contextlib
import contextvars
import math
import enum
import dataclasses
from typing import Annotated, Any, Optional, Self
import torch
from ttfs.utils import align_up
import triton.language as tl
from ttfs.core.mp import gluon_dtype_to_torch
from .constants import RecordFlags


class BaseRecordEventType(enum.IntEnum):
    PROFILE = 0
    DEBUG = 1
    TENSOR = 2
    META = 3


@dataclasses.dataclass
class EventTensorPlaceholder:
    slot_idx: int
    dtype: tl.dtype
    th_dtype: torch.dtype

    def __eq__(self, other: Self) -> bool:
        return self.dtype == other.dtype

    def __hash__(self):
        return hash(self.dtype)

    def parse_val(self, scalar_val):
        if self.dtype.primitive_bitwidth == 32:
            scalar_val = scalar_val.to(torch.uint32).view(self.th_dtype)
        elif self.dtype.primitive_bitwidth == 16:
            scalar_val = scalar_val.to(torch.uint16).view(self.th_dtype)
        elif self.dtype.primitive_bitwidth == 8:
            scalar_val = scalar_val.to(torch.uint8).view(self.th_dtype)
        else:
            raise ValueError(
                f"Unsupported dtype bitwidth: {self.dtype.primitive_bitwidth}"
            )
        return scalar_val.item()

    @staticmethod
    def create(idx: int, dtype: tl.dtype):
        th_dtype = gluon_dtype_to_torch(dtype)
        if dtype.primitive_bitwidth == 32:
            return EventTensorPlaceholder32(idx, dtype, th_dtype)
        elif dtype.primitive_bitwidth == 16:
            return EventTensorPlaceholder16(idx, dtype, th_dtype)
        elif dtype.primitive_bitwidth == 8:
            return EventTensorPlaceholder8(idx, dtype, th_dtype)

        return EventTensorPlaceholder(idx, dtype, th_dtype)


@dataclasses.dataclass
class EventTensorPlaceholder32(EventTensorPlaceholder):
    def parse_val(self, scalar_val):
        return scalar_val.to(torch.uint32).view(self.th_dtype).item()


@dataclasses.dataclass
class EventTensorPlaceholder16(EventTensorPlaceholder):
    def parse_val(self, scalar_val):
        return scalar_val.to(torch.uint16).view(self.th_dtype).item()


@dataclasses.dataclass
class EventTensorPlaceholder8(EventTensorPlaceholder):
    def parse_val(self, scalar_val):
        return scalar_val.to(torch.uint8).view(self.th_dtype).item()


def _get_static_key_in_nested_dict(items: dict[str, Any]):
    res = []
    for key, item in items.items():
        if not isinstance(item, dict):
            res.append((key, item))
        else:
            res.append((key, _get_static_key_in_nested_dict(item)))
    return tuple(res)


@dataclasses.dataclass
class RecordStaticDict:
    items: dict[str, Any]
    slots: list[
        tuple[str, list[tuple[int, EventTensorPlaceholder]] | EventTensorPlaceholder]
    ]
    num_tensor: int

    def get_static_key(self):
        return _get_static_key_in_nested_dict(self.items)

    def __hash__(self):
        return hash(tuple(self.items.keys()) + tuple(self.items.values()))

    def get_dict(self, kernel_vals: torch.Tensor):
        if not self.slots:
            return self.items
        res = self.items.copy()
        for key, slot in self.slots:
            if isinstance(slot, EventTensorPlaceholder):
                res[key] = slot.parse_val(kernel_vals[slot.slot_idx])
            else:
                # is tuple
                tuple_lst = list(res[key])
                for idx, holder in slot:
                    tuple_lst[idx] = holder.parse_val(kernel_vals[holder.slot_idx])
                res[key] = tuple(tuple_lst)
        return res


@dataclasses.dataclass
class EventRecordStaticMeta:
    scope_id: int
    is_start: bool
    base_type: int
    scope_width: int
    static_dict: RecordStaticDict


class EventRecordParserContext:
    def __init__(self):
        self.event_name_dict: dict[Any, EventRecordStaticMeta] = {}

    def query_id(
        self,
        sdict: "RecordStaticDict",
        is_start: bool,
        base_ev_type: int,
        scope_width: int,
    ):
        static_key = sdict.get_static_key()
        if static_key not in self.event_name_dict:
            self.event_name_dict[static_key] = EventRecordStaticMeta(
                len(self.event_name_dict), is_start, base_ev_type, scope_width, sdict
            )
        return self.event_name_dict[static_key].scope_id


class EventRecordContext:
    def __init__(
        self,
        max_num_partition: int,
        buf_length: int,
        smem_num_events: int = 0,
        is_circular: bool = False,
        profile_only: bool = True,
        target_program: Optional[tuple[int, ...]] = None,
        is_cycle_mode: bool = False,
        allow_tensor_event: bool = False,
        with_source_loc_info: bool = False,
        enabled: bool = True,
    ):
        assert smem_num_events >= 0 and buf_length >= 0 and max_num_partition > 0, (
            "smem_num_events, buf_length and max_num_partition must be positive"
        )
        # check smem_num_events is 2 powered
        if smem_num_events > 0:
            assert (smem_num_events & (smem_num_events - 1)) == 0, (
                "smem_num_events must be a power of 2"
            )
        else:
            assert buf_length > 0
        ev_length = 2 if profile_only else 8
        buf_length = max(buf_length, smem_num_events * ev_length)
        buf_length = align_up(buf_length, ev_length) + 16  # 16 is for metadata event
        self.buf_length = buf_length
        self.enabled = enabled
        self.max_num_partition = max_num_partition
        self.smem_num_events = smem_num_events
        assert isinstance(smem_num_events, int)
        self.is_circular = is_circular
        self.profile_only = profile_only
        self.is_cycle_mode = is_cycle_mode
        self.record_all_block = target_program is None
        self.allow_tensor_event = allow_tensor_event
        self.with_source_loc_info = with_source_loc_info
        if target_program is None:
            target_program = (0, 0, 0)
        if allow_tensor_event:
            assert (
                not self.profile_only
                and not self.record_all_block
                and not self.is_circular
            )

        target_program_lst = list(target_program)
        while len(target_program_lst) < 3:
            target_program_lst.append(0)
        self.target_program = tuple(target_program_lst[:3])

        self._event_buffer = torch.zeros(
            (0, buf_length), dtype=torch.uint32, device="cuda"
        )

        self._record_metadata: Optional[EventRecordMetadata] = None

    def get_flags(self):
        flags = RecordFlags(0)
        if self.is_circular:
            flags |= RecordFlags.IS_CIRCULAR
        if self.record_all_block:
            flags |= RecordFlags.RECORD_ALL_BLOCK
        if not self.profile_only:
            flags |= RecordFlags.ALLOW_SCALAR_ARGS
        if self.is_cycle_mode:
            flags |= RecordFlags.IS_CYCLE_MODE
        if self.allow_tensor_event:
            flags |= RecordFlags.ALLOW_TENSOR_EVENT
        if self.with_source_loc_info:
            flags |= RecordFlags.WITH_SOURCE_LOC
        return int(flags)

    def alloc_buffer(self, grid):
        if self.record_all_block:
            assert not callable(grid), (
                "grid must be a tuple when record_all_block is True"
            )
            num_block = 1
            for g in grid:
                num_block *= g
            self._event_buffer = torch.zeros(
                (self.max_num_partition, num_block, self.buf_length),
                dtype=torch.uint32,
                device="cuda",
            )
        else:
            self._event_buffer = torch.zeros(
                (self.max_num_partition, self.buf_length),
                dtype=torch.uint32,
                device="cuda",
            )

    def parse_result(self):
        from .postprocess import parse_event_data

        if self._record_metadata is None:
            raise ValueError("No event recorded")
        return parse_event_data(self._event_buffer.cpu(), self._record_metadata)


@dataclasses.dataclass
class EventRecordMetadata:
    kernel_name: str
    event_name_dict: dict[Any, EventRecordStaticMeta]
    flags: int
    target_program: tuple[int, ...]
    kernel_infos: dict[str, Any]

    @property
    def profile_only(self):
        return not bool(self.flags & RecordFlags.ALLOW_SCALAR_ARGS)

    @property
    def record_all_block(self):
        return bool(self.flags & RecordFlags.RECORD_ALL_BLOCK)

    @property
    def is_circular(self):
        return bool(self.flags & RecordFlags.IS_CIRCULAR)

    @property
    def is_cycle_mode(self):
        return bool(self.flags & RecordFlags.IS_CYCLE_MODE)

    @property
    def allow_tensor_event(self):
        return bool(self.flags & RecordFlags.ALLOW_TENSOR_EVENT)


_EVENT_RECORD_PARSER_CTX: contextvars.ContextVar[Optional[EventRecordParserContext]] = (
    contextvars.ContextVar("_EVENT_RECORD_PARSER_CTX", default=None)
)
_EVENT_RECORD_CTX: contextvars.ContextVar[Optional[EventRecordContext]] = (
    contextvars.ContextVar("_EVENT_RECORD_CTX", default=None)
)


@contextlib.contextmanager
def enter_event_record_context(
    max_num_partition: int,
    buffer_length: int,
    smem_num_events: int = 0,
    is_circular: bool = False,
    profile_only: bool = True,
    target_program: tuple[int, ...] = (0, 0, 0),
    enabled: bool = True,
):
    """Enter event record without change host launch code.

    WARNING: when you use event record ctx, your kernel must have a arg called `event_recorder_args`.

    WARNING: only gluon jitx kernels support this, raw triton kernel do nothing.
    """
    ctx = EventRecordContext(
        max_num_partition,
        buffer_length,
        smem_num_events=smem_num_events,
        is_circular=is_circular,
        profile_only=profile_only,
        target_program=target_program,
        enabled=enabled,
    )
    token = _EVENT_RECORD_CTX.set(ctx)
    try:
        yield ctx
    finally:
        _EVENT_RECORD_CTX.reset(token)


@contextlib.contextmanager
def enter_profile_context(
    max_num_partition: int,
    smem_num_events: int = 256,
    is_circular: bool = True,
    profile_only: bool = True,
    target_program: Optional[tuple[int, ...]] = None,
    is_cycle_mode: bool = True,
    enabled: bool = True,
):
    """Enter profile-only event record ctx.

    WARNING: when you use event record ctx, your kernel must have a arg called `event_recorder_args`.
    """
    ctx = EventRecordContext(
        max_num_partition,
        0,
        smem_num_events=smem_num_events,
        is_circular=is_circular,
        profile_only=profile_only,
        target_program=target_program,
        is_cycle_mode=is_cycle_mode,
        enabled=enabled,
    )
    token = _EVENT_RECORD_CTX.set(ctx)
    try:
        yield ctx
    finally:
        _EVENT_RECORD_CTX.reset(token)


@contextlib.contextmanager
def enter_debug_context(
    max_num_partition: int,
    buffer_length: int,
    target_program: Optional[tuple[int, ...]] = None,
    smem_num_events: int = 0,
    is_circular: bool = False,
    is_cycle_mode: bool = False,
    enabled: bool = True,
):
    """Enter event record ctx with debug scalar support.
    in this mode, pipeline will record all io coords.

    WARNING: when you use event record ctx, your kernel must have a arg called `event_recorder_args`.
    """
    ctx = EventRecordContext(
        max_num_partition,
        buffer_length,
        smem_num_events=smem_num_events,
        is_circular=is_circular,
        profile_only=False,
        target_program=target_program,
        is_cycle_mode=is_cycle_mode,
        enabled=enabled,
    )
    token = _EVENT_RECORD_CTX.set(ctx)
    try:
        yield ctx
    finally:
        _EVENT_RECORD_CTX.reset(token)


@contextlib.contextmanager
def enter_debug_with_tensor_context(
    max_num_partition: int,
    buffer_length: int,
    target_program: tuple[int, ...],
    enabled: bool = True,
):
    """Enter event record ctx with tensor event support.
    this mode don't support all-block record, you must specify target program to use it.

    WARNING: when you use event record ctx, your kernel must have a arg called `event_recorder_args`.
    """
    ctx = EventRecordContext(
        max_num_partition,
        buffer_length,
        smem_num_events=0,
        is_circular=False,
        profile_only=False,
        target_program=target_program,
        is_cycle_mode=False,
        allow_tensor_event=True,
        enabled=enabled,
    )
    token = _EVENT_RECORD_CTX.set(ctx)
    try:
        yield ctx
    finally:
        _EVENT_RECORD_CTX.reset(token)


@contextlib.contextmanager
def enter_event_record_parser_context():
    ctx = EventRecordParserContext()
    token = _EVENT_RECORD_PARSER_CTX.set(ctx)
    try:
        yield ctx
    finally:
        _EVENT_RECORD_PARSER_CTX.reset(token)


def get_event_record_parser_ctx() -> Optional[EventRecordParserContext]:
    return _EVENT_RECORD_PARSER_CTX.get()


def get_event_record_ctx() -> Optional[EventRecordContext]:
    return _EVENT_RECORD_CTX.get()
