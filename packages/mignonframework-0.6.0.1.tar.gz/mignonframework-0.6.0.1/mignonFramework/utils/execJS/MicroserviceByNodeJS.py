import subprocess
import requests
import atexit
import time
import os
import sys
import threading
from functools import wraps
from typing import Any
import warnings

class MicroServiceByNodeJS:
    def __init__(self, client_only=False, logger: Any = None,
                 url_base="http://127.0.0.1:3000",
                 scan_dir="./resources/js",
                 node_modules_path=None,
                 invoker_path=None, js_log_print=True, raise_exc=False):
        current_dir = os.path.dirname(os.path.abspath(__file__))
        static_folder = os.path.join(current_dir, '../starterUtil', "static")
        self.js_log = js_log_print
        if invoker_path is None:
            invoker_path = os.path.join(static_folder, 'js', "invoker.js")

        self.url_base = url_base
        self.node_modules_path = node_modules_path

        self.process = None
        self.client_only = client_only
        self.logger: Any = logger
        self.raise_exc = raise_exc
        self._start_server(invoker_path, scan_dir, node_modules_path)

    def _get_log_func(self, level: str, output_stream):
        """
        根据 logger 的类型（Mignon Logger, Loguru, 标准 Logging）和请求的 level，
        动态返回一个可调用的日志函数 func(message)。
        """
        logger = self.logger
        if not logger:
            def _print_and_flush(msg, _stream=output_stream):
                print(msg, file=_stream, flush=True)
            return _print_and_flush

        if hasattr(logger, 'write_log'):
            level_upper = level.upper()
            return lambda msg: logger.write_log(level_upper, msg)

        method_name = level.lower()
        if method_name == 'warn':
            method_name = 'warning'
        log_method = getattr(logger, method_name, None)

        if not log_method:
            log_method = getattr(logger, 'info', None)

        if log_method:
            return log_method

        def _print_and_flush_fallback(msg, _stream=output_stream):
            print(msg, file=_stream, flush=True)
        return _print_and_flush_fallback

    def _stream_printer(self, stream, output_stream, level="INFO"):
        """
        在后台线程中读取子进程的流, 并将其直接打印到Python的标准流中.
        支持动态识别 Logger 类型并分发到对应级别 (INFO/ERROR)。
        """
        try:
            # 在循环外解析一次日志函数，避免在 while 循环中频繁 getattr/hasattr
            log_func = self._get_log_func(level, output_stream)

            for line in iter(stream.readline, ''):
                line = line.strip()
                if line:
                    log_func(line)
                    # daemon 线程中 print 写入的数据可能滞留在 Python stdout 缓冲区，
                    # 必须手动 flush 才能让输出立即可见
                    if hasattr(output_stream, 'flush'):
                        try:
                            output_stream.flush()
                        except Exception:
                            pass
            stream.close()
        except Exception as e:
            # 不要静默吞掉异常，否则线程死掉了都不知道原因
            import traceback
            traceback.print_exc(file=sys.stderr)


    def _verify_service(self):
        """验证 Node.js 服务是否正在运行"""
        try:
            # 完整使用 self.url_base
            response = requests.get(f'{self.url_base}/status', timeout=10)
            if response.status_code == 200:
                data = response.json()
                return data.get('service_name') == 'js_invoker_microservice'
        except (requests.exceptions.RequestException, ValueError):
            return False
        return False

    # 启动服务时传递 node_modules_path 和 url_base
    def _start_server(self, invoker_path, scan_dir, node_modules_path):
        if self.client_only:
            if not self._verify_service():
                if self.raise_exc:
                    raise ConnectionError(f"在 client_only 模式下，无法连接到{self.url_base} 上的服务。")
                else:
                    warnings.warn(f"在 client_only 模式下，无法连接到{self.url_base} 上的服务。", RuntimeWarning, stacklevel=2)
            return

        # 不再进行端口占用检查和杀进程操作，仅检查服务是否运行
        if self._verify_service():
            warnings.warn(f"Node.js 服务已在 {self.url_base} 上运行，跳过启动。")
            return

        if not os.path.exists(invoker_path):
            raise FileNotFoundError(f"Invoker file not found: {invoker_path}")

        command = ['node', invoker_path]

        command.append(scan_dir if scan_dir else "")

        command.append(node_modules_path if node_modules_path else "")

        command.append(self.url_base)

        project_root = os.getcwd()
        env = os.environ.copy()


        popen_kwargs = {
            "cwd": project_root,
            "env": env,
            "shell": False
        }

        if self.js_log:
            # 重定向输出流到管道
            popen_kwargs['stdout'] = subprocess.PIPE
            popen_kwargs['stderr'] = subprocess.PIPE
            popen_kwargs['text'] = True
            popen_kwargs['bufsize'] = 1
            popen_kwargs['encoding'] = 'utf-8'
            popen_kwargs['errors'] = 'replace'
        else:
            popen_kwargs['stdout'] = subprocess.DEVNULL
            popen_kwargs['stderr'] = subprocess.DEVNULL

        self.process = subprocess.Popen(command, **popen_kwargs)

        # 如果开启了日志，则启动后台线程来打印日志
        if self.js_log:
            stdout_thread = threading.Thread(
                target=self._stream_printer,
                args=(self.process.stdout, sys.stdout, "INFO")
            )
            stdout_thread.daemon = True
            stdout_thread.start()
            stderr_thread = threading.Thread(
                target=self._stream_printer,
                args=(self.process.stderr, sys.stderr, "ERROR")
            )
            stderr_thread.daemon = True
            stderr_thread.start()
        atexit.register(self.shutdown)
        time.sleep(2)
        if not self._verify_service():
            if self.raise_exc:
                raise ConnectionError(f"Node.js 服务启动失败或在 {self.url_base} 上无法访问。")
            else:
                warnings.warn(f"Node.js 服务启动失败或在 {self.url_base} 上无法访问。")

    def invoke(self, file_name, func_name, *args, **kwargs):
        payload = {
            'func_name': func_name,
            'args': list(args)
        }
        url = f"{self.url_base}/{file_name}/invoke"
        try:
            response = requests.post(url, json=payload, timeout=10)
            response.raise_for_status()
            result = response.json()

            if result['success']:
                return result['result']
            else:
                error_message = f"JS execution failed: {result.get('error', '未知错误')}"
                if self.raise_exc:
                    raise RuntimeError(error_message)
                warnings.warn(error_message, RuntimeWarning, stacklevel=2)
                return None
        except requests.exceptions.RequestException as e:
            error_message = f"Could not connect to Node.js service at {self.url_base}: {e}"
            if self.raise_exc:
                if self.process:
                    self.shutdown()
                raise ConnectionError(error_message)
            warnings.warn(error_message, RuntimeWarning, stacklevel=2)
            return None

    def shutdown(self):
        if self.process and self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=5)
                print("Node.js service shut down gracefully.")
            except subprocess.TimeoutExpired:
                print("Node.js service did not terminate, killing it.", file=sys.stderr)
                self.process.kill()
            self.process = None
    def evalJS(self, file_name, func_name=None):
        def decorator(func):
            @wraps(func)
            def wrapper(*args, **kwargs):
                nonlocal func_name
                if func_name is None:
                    func_name = func.__name__

                return self.invoke(file_name, func_name, *args, **kwargs)

            return wrapper

        return decorator

    def startAsMicro(self):
        try:
            while True:
                # 保持主线程活跃
                time.sleep(1)
        except Exception:
            print("Received exit signal, shutting down service.")
            self.shutdown()