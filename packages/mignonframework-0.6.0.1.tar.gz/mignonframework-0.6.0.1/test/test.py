import requests
import json
import urllib.parse
from mignonFramework import JSONFormatter

# 由 Mignon Rex 的 MignonFramework.CurlToRequestsConverter 生成
# Have a good Request

headers = {
    "accept": "*/*",
    "accept-language": "zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7,zh-HK;q=0.6,zh-TW;q=0.5",
    "authorization": "Bearer Bearer eyJhbGciOiJIUzUxMiJ9.eyJpZCI6OTMwMTMxNTAzLCJleHAiOjE3Njc3MTk4NzIsInVzZXIiOiIyMDUxNzIifQ.oZiUa6yh4K-nDRBrnCdNhoEkssaO6tA7tQh4MVkWc13i0jp8jxhrmmzSYrLYMJ3E-mp-YdyG0mEFQrn2RTbofA",
    "cache-control": "no-cache",
    "channel": "SGUI",
    "client-type": "desktop_i",
    "client-version": "win-64-Lite-public-1.1.7",
    "content-type": "application/json",
    "globalid": "120211212%205172%CG20842%20260106145725717%091V0848%%8302",
    "hid": "HID-205172-d7f374a7-d5fc-42ad-afea-8c65061b8f4e",
    "lang": "zh-cn",
    "mac": "00-0C-29-D3-57-28",
    "origin": "https://sgui.trip51.cn",
    "pragma": "no-cache",
    "priority": "u=1, i",
    "referer": "https://sgui.trip51.cn/sgui/",
    "sec-ch-ua": "\"Google Chrome\";v=\"143\", \"Chromium\";v=\"143\", \"Not A(Brand\";v=\"24\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Windows\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-origin",
    "sign": "e76a13b20824c2db78a4f42624ef633aa0de3312645e3ba2262cd6a8519937f7",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36"
}

cookies = {
    "ivvtoken": "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJSREhLMTAwIiwiZXhwIjoxNzY3NzY5MDQ0LCJpYXQiOjE3Njc2ODI2NDR9.4G0dX3KAKSsHj9hA1-LrbS33vEOVez58rbHKeFdcpUI---999",
    "ROUTEID": ".c1_10.5.97.59"
}

json_data = {
    "configs": [
        {
            "queryType": "conf",
            "confType": "BUSINESS",
            "confCode": "BUSINESS.CHANGEUSEROFFICE.SWITCH"
        },
        {
            "queryType": "conf",
            "confType": "BUSINESS",
            "confCode": "BUSINESS.EMD.PAYMENT.RED.ENVELOPE.DISTRIBUTION.ENABLE"
        },
        {
            "queryType": "conf",
            "confType": "BUSINESS",
            "confCode": "BUSINESS.ACCOUNT.EMD.FIRST"
        },
        {
            "queryType": "conf",
            "confType": "SYSTEM",
            "confCode": "EXSYSTEM.SAT.EPID.UNUSE"
        },
        {
            "queryType": "conf",
            "confType": "SYSTEM",
            "confCode": "FRONT_LOG_MONITOR_SWITCH"
        },
        {
            "queryType": "conf",
            "confType": "SYSTEM",
            "confCode": "DRTP_FRONT_LOG_MONITOR_SWITCH"
        },
        {
            "queryType": "dict",
            "dictType": "Shortcut_Function_Toggle_Menu",
            "dictCode": "Shortcut_Function_Toggle",
            "label": "ShortcutFunctionToggleSwitch"
        },
        {
            "queryType": "dict",
            "dictType": "Agent_ET_Receipt",
            "dictCode": "Receipt",
            "label": "ETReceipt"
        },
        {
            "queryType": "conf",
            "confType": "BUSINESS",
            "confCode": "BUSINESS.ORDER.SPLIT.SWITCH"
        },
        {
            "queryType": "conf",
            "confType": "BUSINESS",
            "confCode": "BUSINESS.ISSUE.ET.SWITCH"
        }
    ]
}

url = "https://sgui.trip51.cn/sgui-bkc/config/query"

response = requests.post(
    url,
    headers=headers,
    cookies=cookies,
    json=json_data
)

# The following print statements are for debugging and are not part of the core request logic.
print(f"状态码: {response.status_code}")
try:
    print("响应 JSON:", response.json())
    JSONFormatter(response.text)
except json.JSONDecodeError:
    print("响应文本:", response.text)