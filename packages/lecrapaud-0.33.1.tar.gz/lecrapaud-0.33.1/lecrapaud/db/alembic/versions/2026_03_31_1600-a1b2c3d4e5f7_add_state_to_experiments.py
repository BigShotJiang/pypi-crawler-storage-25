"""add state column to experiments

Revision ID: a1b2c3d4e5f7
Revises: 0e47cb122c58
Create Date: 2026-03-31 16:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

from lecrapaud.config import LECRAPAUD_TABLE_PREFIX

# revision identifiers, used by Alembic.
revision: str = "a1b2c3d4e5f7"
down_revision: str = "0e47cb122c58"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    table = f"{LECRAPAUD_TABLE_PREFIX}_experiments"
    op.add_column(table, sa.Column("state", sa.String(20), nullable=True))
    op.execute(sa.text(f"UPDATE {table} SET state = 'completed' WHERE state IS NULL"))


def downgrade() -> None:
    table = f"{LECRAPAUD_TABLE_PREFIX}_experiments"
    op.drop_column(table, "state")
