import warnings
import os

# Suppress pkg_resources deprecation warnings (also in subprocesses via env var)
os.environ.setdefault("PYTHONWARNINGS", "ignore::UserWarning")
warnings.filterwarnings("ignore", message="pkg_resources is deprecated")
warnings.filterwarnings("ignore", message="pkg_resources", category=UserWarning)

from lecrapaud.base import *

# Export pipeline classes
from lecrapaud.pipeline import (
    PipelineLeCrapaud,
    LeCrapaudTransformer,
    FullPipelineTransformer,
    DataSplitterTransformer,
    DataReshaper,
)

# Export sklearn-compatible mixins
from lecrapaud.mixins import LeCrapaudTransformerMixin, LeCrapaudEstimatorMixin

# Export individual components for advanced usage
from lecrapaud.feature_engineering import FeatureEngineer
from lecrapaud.feature_preprocessing import FeaturePreprocessor
from lecrapaud.feature_selection import FeatureSelector
from lecrapaud.model_preprocessing import ModelPreprocessor
from lecrapaud.model_selection import ModelSelector

# Export context optimization classes
from lecrapaud.column_suggester import ColumnSuggester
from lecrapaud.business_objective import BusinessObjective, BusinessPresets
from lecrapaud.context_search_space import (
    create_context_search_space,
    print_search_space,
    describe_search_space,
)

DEFAULT_EXPERIMENT_PARAMS = LeCrapaud.DEFAULT_PARAMS
