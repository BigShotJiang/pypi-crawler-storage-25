"""Tabular machine learning entries."""
from .._entry import Entry


binary_classification = Entry(
    name="binary_classification",
    title="Tabular binary classification — boosting trio (placeholder)",
    when_to_use=[
        "Tabular target is 0/1",
        "Mixed numeric + categorical features",
        "Default first move on any binary tabular task",
    ],
    code="# placeholder — full XGB / LGBM / CatBoost pipeline to be added\n",
    notes=[
        "Run EDA + failure-mode scan first (see ml.failure_modes)",
        "Use Stratified K-Fold; never plain KFold on imbalanced data",
    ],
    requires=["lightgbm", "xgboost", "catboost", "sklearn"],
    refs=["ml/tabular §6.1"],
)
