"""Internal: Entry class for reference items.

Each leaf in the package is an Entry instance. Typing the entry name (no
parentheses) in a Jupyter/Colab cell prints its full content via __repr__.
``entry.code`` returns just the code string for direct copy.
"""


class Entry:
    """A reference entry. Type the entry name (no parens) in a Jupyter cell to
    display its full content. Use ``.code`` to get just the code as a string.
    """

    def __init__(
        self,
        name,
        title,
        when_to_use=None,
        code="",
        notes=None,
        requires=None,
        refs=None,
        brief="",
    ):
        self.name = name
        self.title = title
        self.when_to_use = list(when_to_use) if when_to_use else []
        self.code = code
        self.notes = list(notes) if notes else []
        self.requires = list(requires) if requires else []
        self.refs = list(refs) if refs else []
        self.brief = brief or title
        self.__doc__ = f"{name} — {title}\n\n{self.brief}"

    def __repr__(self):
        lines = [f"{self.name}  —  {self.title}", ""]

        if self.when_to_use:
            lines.append("When to use")
            lines.extend(f"  - {w}" for w in self.when_to_use)
            lines.append("")

        if self.code:
            lines.append("Code")
            lines.append(self.code.strip())
            lines.append("")

        if self.notes:
            lines.append("Notes")
            lines.extend(f"  - {n}" for n in self.notes)
            lines.append("")

        meta = []
        if self.requires:
            meta.append(f"Requires: {', '.join(self.requires)}")
        if self.refs:
            meta.append(f"Refs: {'; '.join(self.refs)}")
        if meta:
            lines.append("\n".join(meta))

        return "\n".join(lines).rstrip()

    def __str__(self):
        return self.__repr__()
