"""Task-agnostic utilities."""
import sys

from . import refs


def preflight():
    """Print environment summary: Python, key library versions, GPU status."""
    lines = [f"Python: {sys.version.split()[0]}"]

    for mod_name in ("numpy", "pandas", "sklearn", "torch", "transformers",
                     "torchvision", "torchaudio", "lightgbm", "xgboost", "catboost"):
        try:
            mod = __import__(mod_name)
            lines.append(f"{mod_name}: {getattr(mod, '__version__', '?')}")
        except ImportError:
            lines.append(f"{mod_name}: not installed")

    try:
        import torch
        if torch.cuda.is_available():
            props = torch.cuda.get_device_properties(0)
            lines.append(f"cuda: {torch.cuda.get_device_name(0)} ({props.total_memory / 1e9:.1f} GB)")
        else:
            lines.append("cuda: not available")
    except ImportError:
        pass

    print("\n".join(lines))


def find(query):
    """Search across all loaded entries for a query string. Returns matching
    entry names. (Surface prototype: only searches modules already imported.)
    """
    import axonet
    query_lower = query.lower()
    hits = []
    for sub_name in axonet._subpackages:
        sub = getattr(axonet, sub_name, None)
        if sub is None:
            continue
        for attr_name in dir(sub):
            if attr_name.startswith("_"):
                continue
            attr = getattr(sub, attr_name)
            haystack = " ".join([
                str(getattr(attr, "name", "")),
                str(getattr(attr, "title", "")),
                str(getattr(attr, "brief", "")),
                " ".join(getattr(attr, "notes", []) or []),
                " ".join(getattr(attr, "when_to_use", []) or []),
            ]).lower()
            if query_lower in haystack:
                hits.append(f"axonet.{sub_name}.{attr_name}")
    return hits
