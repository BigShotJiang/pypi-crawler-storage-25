"""axonet: utilities for neural network experiments."""
import importlib as _importlib

__version__ = "0.1.0"

_subpackages = ("ml", "cv", "nlp", "audio", "mm", "qa", "utils")


def __getattr__(name):
    if name in _subpackages:
        module = _importlib.import_module(f".{name}", __name__)
        globals()[name] = module
        return module
    raise AttributeError(f"module 'axonet' has no attribute {name!r}")


def __dir__():
    return sorted(set(globals()) | set(_subpackages))
