"""Audio entries."""
from .._entry import Entry


melspec_cnn = Entry(
    name="melspec_cnn",
    title="Mel-spectrogram + CNN audio classification (placeholder)",
    when_to_use=[
        "Audio classification when speech-specific models do not apply",
        "Environmental sound, music, instrument, deepfake",
    ],
    code="# placeholder — load -> 16k -> mono -> log-mel -> ResNet18 (in_channels=1)\n",
    notes=[
        "16 kHz resampling is mandatory for most pretrained models",
        "Mono conversion before any pretrained model",
    ],
    requires=["torchaudio", "torch"],
    refs=["audio/section7 §3"],
)
