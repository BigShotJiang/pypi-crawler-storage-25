"""Computer vision entries."""
from .._entry import Entry


unet = Entry(
    name="unet",
    title="U-Net from scratch (DoubleConv / Down / Up / OutConv)",
    when_to_use=[
        "Semantic segmentation, fill-in-blank scaffolded style",
        "PyTorch-only environment (HF disallowed)",
        "Binary or multiclass; medical / satellite / natural images",
    ],
    code='''import torch
import torch.nn as nn
import torch.nn.functional as F


class DoubleConv(nn.Module):
    """(Conv -> BN -> ReLU) * 2"""
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.double_conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.double_conv(x)


class Down(nn.Module):
    """MaxPool then DoubleConv"""
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.maxpool_conv = nn.Sequential(
            nn.MaxPool2d(2),
            DoubleConv(in_channels, out_channels),
        )

    def forward(self, x):
        return self.maxpool_conv(x)


class Up(nn.Module):
    """Upsample, concat skip, DoubleConv"""
    def __init__(self, in_channels, out_channels, bilinear=True):
        super().__init__()
        if bilinear:
            self.up = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=True)
        else:
            self.up = nn.ConvTranspose2d(in_channels, in_channels // 2, kernel_size=2, stride=2)
        self.conv = DoubleConv(in_channels, out_channels)

    def forward(self, x_dec, x_skip):
        x_dec = self.up(x_dec)
        diff_y = x_skip.size(2) - x_dec.size(2)
        diff_x = x_skip.size(3) - x_dec.size(3)
        x_dec = F.pad(x_dec, [diff_x // 2, diff_x - diff_x // 2,
                              diff_y // 2, diff_y - diff_y // 2])
        x = torch.cat([x_skip, x_dec], dim=1)
        return self.conv(x)


class OutConv(nn.Module):
    """1x1 projection to num_classes"""
    def __init__(self, in_channels, num_classes):
        super().__init__()
        self.conv = nn.Conv2d(in_channels, num_classes, kernel_size=1)

    def forward(self, x):
        return self.conv(x)


class UNet(nn.Module):
    def __init__(self, n_channels=3, n_classes=2, bilinear=True):
        super().__init__()
        factor = 2 if bilinear else 1

        self.inc = DoubleConv(n_channels, 64)
        self.down1 = Down(64, 128)
        self.down2 = Down(128, 256)
        self.down3 = Down(256, 512)
        self.down4 = Down(512, 1024 // factor)

        self.up1 = Up(1024, 512 // factor, bilinear)
        self.up2 = Up(512, 256 // factor, bilinear)
        self.up3 = Up(256, 128 // factor, bilinear)
        self.up4 = Up(128, 64, bilinear)
        self.outc = OutConv(64, n_classes)

    def forward(self, x):
        x1 = self.inc(x)
        x2 = self.down1(x1)
        x3 = self.down2(x2)
        x4 = self.down3(x3)
        x5 = self.down4(x4)
        x = self.up1(x5, x4)
        x = self.up2(x, x3)
        x = self.up3(x, x2)
        x = self.up4(x, x1)
        return self.outc(x)


# usage
# model = UNet(n_channels=3, n_classes=6, bilinear=True).to(device)
# logits = model(images)               # [B, n_classes, H, W]
# loss = F.cross_entropy(logits, masks)  # masks: [B, H, W] long
''',
    notes=[
        "Synchronized augmentation: wrap masks in tv_tensors.Mask before applying torchvision v2 transforms",
        "Mask values must be class indices 0..K-1 (long), not 0/255",
        "F.interpolate: bilinear for image features, nearest for mask predictions",
        "Skip connection: torch.cat([up_decoder, encoder_skip], dim=1) along channel axis",
        "factor=2 with bilinear halves channel count at the bottleneck (no learnable upsampling)",
    ],
    requires=["torch"],
    refs=["cv/segmentation §6.2", "2025 SG selection CV Q1.2"],
)


detr = Entry(
    name="detr",
    title="Object detection via HuggingFace DETR (placeholder)",
    when_to_use=[
        "Object detection task with HF allowed",
        "Variable-output problem (no NMS needed)",
    ],
    code="# placeholder — full pipeline to be added in next build pass\n",
    notes=["See cv/detection deep dive for full pipeline"],
    requires=["transformers", "torch"],
    refs=["cv/detection §6.6"],
)
