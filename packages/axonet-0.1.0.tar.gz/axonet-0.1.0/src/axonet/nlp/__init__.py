"""Natural language processing entries."""
from .._entry import Entry


hf_trainer = Entry(
    name="hf_trainer",
    title="HuggingFace Trainer text classification (placeholder)",
    when_to_use=[
        "Text classification with HF allowed",
        "Single-language or multilingual via xlm-r",
    ],
    code="# placeholder — full HF Trainer pipeline to be added\n",
    notes=[
        "Rename target column to 'labels' in your HF Dataset",
        "Set load_best_model_at_end=True and metric_for_best_model",
    ],
    requires=["transformers", "datasets", "torch"],
    refs=["nlp/text_classification §6.1"],
)
