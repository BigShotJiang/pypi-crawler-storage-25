import os
import re
import sys
import argparse
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
from peft import PeftModel

ADAPTER_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "adapters")
BASE_MODEL_ID    = "unsloth/Qwen2.5-Coder-7B-Instruct-bnb-4bit"
GITHUB_TOKEN     = os.environ.get("GITHUB_TOKEN", "")
MAX_NEW_TOKENS   = 300
MAX_FUNC_LENGTH  = 2000


def load_model():
    print("Loading model and adapters ...")

    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.float16,
        bnb_4bit_use_double_quant=True,
    )

    tokenizer = AutoTokenizer.from_pretrained(ADAPTER_DIR, trust_remote_code=True)

    base_model = AutoModelForCausalLM.from_pretrained(
        BASE_MODEL_ID,
        quantization_config=bnb_config,
        device_map="auto",
        torch_dtype=torch.float16,
        trust_remote_code=True,
    )

    model = PeftModel.from_pretrained(base_model, ADAPTER_DIR)
    model.eval()

    print("Model loaded\n")
    return model, tokenizer


def build_prompt(code: str) -> str:
    return (
        "<|im_start|>user\n"
        "You are a security code reviewer. Analyze the following code "
        "and provide a detailed vulnerability report.\n\n"
        f"### Code:\n```\n{code}\n```\n\n"
        "### Security Review:<|im_end|>\n"
        "<|im_start|>assistant\n"
    )


def review_code(model, tokenizer, code: str) -> dict:
    prompt = build_prompt(code)
    inputs = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=1024).to(model.device)

    with torch.no_grad():
        output = model.generate(
            **inputs,
            max_new_tokens=MAX_NEW_TOKENS,
            do_sample=False,
            temperature=1.0,
            pad_token_id=tokenizer.eos_token_id,
        )

    generated = output[0][inputs["input_ids"].shape[1]:]
    response  = tokenizer.decode(generated, skip_special_tokens=True).strip()

    is_vulnerable = "vulnerable" in response.lower() and "not vulnerable" not in response.lower()
    cwe = "N/A"
    cwe_match = re.search(r"CWE-\d+", response)
    if cwe_match:
        cwe = cwe_match.group(0)

    return {
        "verdict":       "VULNERABLE" if is_vulnerable else "SAFE",
        "cwe":           cwe,
        "is_vulnerable": is_vulnerable,
        "full_review":   response,
    }


def extract_functions_from_code(code: str) -> list[str]:
    pattern = re.compile(
        r'(?:(?:static|inline|extern|virtual|override)\s+)*'   # optional qualifiers
        r'[\w*&:<>]+\s+[\w*&]+\s*\([^)]*\)\s*\{',        # return type + name + params + {
        re.MULTILINE
    )

    matches = list(pattern.finditer(code))
    functions = []

    for i, match in enumerate(matches):
        start = match.start()
        end   = matches[i + 1].start() if i + 1 < len(matches) else len(code)
        func  = code[start:end].strip()

        if len(func) < 20:
            continue
        if len(func) > MAX_FUNC_LENGTH:
            func = func[:MAX_FUNC_LENGTH]

        functions.append(func)

    if not functions:
        functions = [code[:MAX_FUNC_LENGTH]]

    return functions


def get_pr_changes(repo_name: str, pr_number: int) -> list[dict]:
    try:
        from github import Github
    except ImportError:
        print("ERROR: PyGithub not installed. Run: pip install PyGithub")
        sys.exit(1)

    if not GITHUB_TOKEN:
        print("ERROR: GITHUB_TOKEN environment variable not set.")
        print("  Set it with: set GITHUB_TOKEN=your_token_here  (Windows)")
        sys.exit(1)

    print(f"Fetching PR #{pr_number} from {repo_name} ...")
    g    = Github(GITHUB_TOKEN)
    repo = g.get_repo(repo_name)
    pr   = repo.get_pull(pr_number)

    changed_files = []
    for f in pr.get_files():
        if not any(f.filename.endswith(ext) for ext in [
            ".c", ".cpp", ".h", ".cc", ".cxx",         # C/C++
            ".py", ".js", ".ts", ".java", ".go",        # other languages
            ".php", ".rb", ".rs", ".cs",
        ]):
            continue

        if f.patch:  # patch contains the diff
            changed_files.append({
                "filename": f.filename,
                "patch":    f.patch,
                "additions": f.additions,
                "deletions": f.deletions,
            })

    print(f"Found {len(changed_files)} changed code files\n")
    return changed_files


def extract_added_code_from_patch(patch: str) -> str:
    added_lines = []
    for line in patch.split("\n"):
        if line.startswith("+") and not line.startswith("+++"):
            added_lines.append(line[1:])  # strip the leading +
    return "\n".join(added_lines)


def print_report(results: list[dict]):
    vulnerable_count = sum(1 for r in results if r["is_vulnerable"])
    total            = len(results)

    print("\n" + "=" * 60)
    print("  SECURITY REVIEW REPORT")
    print("=" * 60)
    print(f"  Files/Functions reviewed : {total}")
    print(f"  Vulnerabilities found    : {vulnerable_count}")
    print(f"  Status: {'REVIEW NEEDED' if vulnerable_count > 0 else '✓ ALL CLEAR'}")
    print("=" * 60 + "\n")

    for i, result in enumerate(results):
        label = result.get("label", f"Snippet {i+1}")
        print(f"[{i+1}] {label}")
        print(f"    Verdict : {result['verdict']}")
        print(f"    CWE     : {result['cwe']}")
        print(f"    Review  :")
        for line in result["full_review"].split("\n"):
            print(f"      {line}")
        print()

    if vulnerable_count > 0:
        print("RECOMMENDATION: Do not merge. Address the vulnerabilities above before merging.")
    else:
        print("RECOMMENDATION: No vulnerabilities detected. Safe to merge.")
    print()


def save_report(results: list[dict], output_file: str = "security_report.txt"):
    with open(output_file, "w") as f:
        vulnerable_count = sum(1 for r in results if r["is_vulnerable"])
        f.write("SECURITY REVIEW REPORT\n")
        f.write("=" * 50 + "\n")
        f.write(f"Total reviewed  : {len(results)}\n")
        f.write(f"Vulnerabilities : {vulnerable_count}\n\n")
        for i, result in enumerate(results):
            f.write(f"[{i+1}] {result.get('label', f'Snippet {i+1}')}\n")
            f.write(f"Verdict : {result['verdict']}\n")
            f.write(f"CWE     : {result['cwe']}\n")
            f.write(f"Review  :\n{result['full_review']}\n")
            f.write("-" * 60 + "\n\n")
    print(f"Report saved to {output_file}")


def review_pr(model, tokenizer, repo_name: str, pr_number: int):
    changed_files = get_pr_changes(repo_name, pr_number)
    results = []

    for file in changed_files:
        print(f"Reviewing: {file['filename']} ({file['additions']} additions) ...")
        added_code = extract_added_code_from_patch(file["patch"])

        if not added_code.strip():
            continue

        functions = extract_functions_from_code(added_code)
        print(f"  Found {len(functions)} function(s) to review")

        for j, func in enumerate(functions):
            result = review_code(model, tokenizer, func)
            result["label"] = f"{file['filename']} — function {j+1}"
            results.append(result)
            status = "⚠ VULNERABLE" if result["is_vulnerable"] else "✓ safe"
            print(f"  Function {j+1}: {status}")

    print_report(results)
    #save_report(results, f"pr_{pr_number}_security_report.txt")


def review_file(model, tokenizer, filepath: str):
    with open(filepath, "r", errors="ignore") as f:
        code = f.read()

    functions = extract_functions_from_code(code)
    print(f"Found {len(functions)} function(s) in {filepath}\n")

    results = []
    for i, func in enumerate(functions):
        print(f"Reviewing function {i+1}/{len(functions)} ...")
        result = review_code(model, tokenizer, func)
        result["label"] = f"{filepath} — function {i+1}"
        results.append(result)

    print_report(results)
    #save_report(results)


def review_snippet(model, tokenizer, code: str):
    print("Reviewing code snippet ...\n")
    result = review_code(model, tokenizer, code)
    result["label"] = "Direct input"
    print_report([result])

def main():
    parser = argparse.ArgumentParser(description="Security code reviewer using fine-tuned LLM")
    group  = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--pr",   type=int,    help="GitHub PR number to review")
    group.add_argument("--file", type=str,    help="Local file to review")
    group.add_argument("--code", type=str,    help="Code snippet to review directly")
    parser.add_argument("--repo", type=str,   help="GitHub repo (owner/repo) — required with --pr")
    args = parser.parse_args()

    model, tokenizer = load_model()

    if args.pr:
        if not args.repo:
            print("ERROR: --repo is required when using --pr (e.g. --repo owner/reponame)")
            sys.exit(1)
        review_pr(model, tokenizer, args.repo, args.pr)

    elif args.file:
        review_file(model, tokenizer, args.file)

    elif args.code:
        review_snippet(model, tokenizer, args.code)


if __name__ == "__main__":
    main()