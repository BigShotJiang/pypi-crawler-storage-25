# -------------------------------------------------------------------------


def memberAccessPercentage(glEntity, min_access_level,
                           threshold_percentage, min_count):
    '''
    Returns a tuple of (count, percentage) of members whose access_level
    is >= min_access_level.

    Returns {None: reason} if members cannot be retrieved or none are found.
    '''

    from gitlab.exceptions import (GitlabAuthenticationError, GitlabGetError,
                                   GitlabHttpError)

    try:
        members = glEntity.members.list(all=True)
        total = len(members)

        if total == 0:
            return {None: 'No members found'}

        count = 0
        for member in members:
            if member.access_level >= min_access_level:
                count += 1

        percentage = (count / total) * 100
        exceeds = percentage >= threshold_percentage and count >= min_count

        return (exceeds, count, percentage)

    except (GitlabHttpError, GitlabGetError, GitlabAuthenticationError) as e:
        if e.response_code in [401, 403]:
            return {None: 'Insufficient permissions'}
