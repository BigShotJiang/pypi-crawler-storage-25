# AGENTS.md — Coding Agent Guidelines

This file provides instructions and context for agentic coding assistants working in this repository.

---

## Repository Overview

`gitlabcis` is a Python CLI tool that audits GitLab projects/groups/instances against CIS Benchmark security controls. It is structured as a Python package with:
- `gitlabcis/benchmarks/` — benchmark check implementations (one module per CIS section)
- `gitlabcis/cli/` — CLI entry point and argument parsing
- `gitlabcis/recommendations/` — YAML files defining each benchmark check's metadata
- `gitlabcis/utils/` — shared utilities (CI config parsing, etc.)
- `gitlabcis/tests/` — unit tests and input/CLI tests

---

## Environment Setup

```sh
make install    # creates venv/, installs package with [test,build] extras, sets up pre-commit hooks
make clean      # removes venv/, build artifacts, uninstalls package
make build      # clean + install + python -m build
```

Python version is pinned to **3.13** via `.tool-versions` (mise). The package supports Python 3.10–3.14.

---

## Build, Lint, and Test Commands

### Linting

```sh
venv/bin/tox -e flake8      # flake8 linting on gitlabcis/
venv/bin/tox -e bandit      # bandit security linting (excludes tests, .tox)
venv/bin/tox -e yamllint    # yamllint on gitlabcis/recommendations/
```

### Testing

```sh
# Run all tests (coverage):
venv/bin/tox -e cover

# Run only benchmark unit tests:
venv/bin/tox -e benchmarks

# Run only YAML recommendation baseline tests:
venv/bin/tox -e baseline

# Run all tox environments:
venv/bin/tox
```

### Running a Single Test

```sh
# Single test file:
venv/bin/pytest gitlabcis/tests/unit/benchmarks/source_code_1/code_changes_1_1_test.py

# Single test function:
venv/bin/pytest gitlabcis/tests/unit/benchmarks/source_code_1/code_changes_1_1_test.py::test_version_control

# With verbose output:
venv/bin/pytest -s -vv gitlabcis/tests/unit/benchmarks/source_code_1/code_changes_1_1_test.py::test_version_control

# Pass extra args through tox:
venv/bin/tox -e benchmarks -- gitlabcis/tests/unit/benchmarks/source_code_1/code_changes_1_1_test.py::test_version_control
```

Note: test files use the `from conftest import run` import, so `pytest` must be run from the repo root (not from inside `gitlabcis/`).

### Pre-commit Hooks

```sh
pre-commit run --all-files    # run all hooks: commitlint, markdownlint, gitleaks, isort, black, flake8
```

---

## Code Style Guidelines

### Line Length

**79 characters** (enforced by `black --line-length=79`). Use `# noqa: E501` sparingly for unavoidable long lines.

### Formatter

`black` with `-S` flag (skip string normalization). **Single quotes are predominant** — do not change quote style unless necessary.

### Import Sorting

`isort` (via pre-commit). Standard import order:
1. Standard library
2. Third-party libraries
3. Local `gitlabcis` imports

**Benchmark modules use deferred (inside-function) imports** — this is intentional and must be preserved:

```python
def some_benchmark(glEntity, glObject, **kwargs):
    from gitlab.exceptions import (GitlabAuthenticationError, GitlabGetError,
                                   GitlabHttpError, GitlabListError)
    from gitlabcis.utils import ci
    ...
```

Only `cli/` and `utils/` modules use top-level imports.

### File Headers

Every Python source file begins with a 79-character separator comment:

```python
# -----------------------------------------------------------------------------
```

### Naming Conventions

| Element | Convention | Example |
|---|---|---|
| Functions | `snake_case` | `sign_artifacts_in_build_pipeline` |
| Classes | `PascalCase` | `GitlabCIS`, `CustomLogFilter` |
| Local variables | `camelCase` | `glEntity`, `defaultBranch`, `protectedBranches` |
| Constants | `UPPER_SNAKE_CASE` | `MAX_WORKERS`, `OUTPUT_FORMATS`, `CHECK` |
| Private helpers | `_snake_case` | `_checkCrosslinks`, `_staleBranches` |
| Test files | `<module>_test.py` | `code_changes_1_1_test.py` (suffix, not prefix) |

### Comments

Do **not** add comments unless they are truly necessary. Avoid inline explanations.

---

## Benchmark Function Conventions

Every function in `gitlabcis/benchmarks/` follows a strict pattern:

### Signature

```python
def function_name(glEntity, glObject, **kwargs):
    """
    id: X.Y.Z
    title: Human-readable title of the check
    """
```

The docstring **must** contain `id:` and `title:` fields — this is validated by tests in `tests/unit/benchmarks/function_test.py`.

### Return Values

All benchmark functions return a single-key dict:

```python
{True: 'Reason string'}   # PASS
{False: 'Reason string'}  # FAIL
{None: 'Reason string'}   # SKIP (insufficient permissions, not applicable, not implemented)
```

### Entity Type Dispatch

```python
if kwargs.get('isProject'):
    # project-level logic
elif kwargs.get('isGroup'):
    return {None: 'Not yet implemented for groups'}
elif kwargs.get('isInstance'):
    return {None: 'Not applicable at instance level'}
```

### Error Handling Pattern

```python
except (GitlabHttpError, GitlabGetError, GitlabAuthenticationError) as e:
    if e.response_code in [401, 403]:
        return {None: 'Insufficient permissions'}
    if e.response_code == 404:
        return {None: 'Resource not found'}
```

Use `except AttributeError: return {None: 'Feature is not enabled'}` for disabled features.

Do **not** catch unhandled response codes — let them fall through (returns `None` implicitly).

---

## Recommendation YAML Files

Each benchmark check has a matching YAML file in `gitlabcis/recommendations/<section>/`. Required keys (validated by `tests/unit/yaml/`):

```yaml
id: X.Y.Z
name: function_name_matching_benchmark_module
title: Human-readable title
profile: Level 1 or Level 2
category: section name
description: |
  ...
rationale: |
  ...
references: []
```

The `name:` field **must exactly match** the benchmark function name.

---

## Testing Conventions

### Test Structure

Tests live in `gitlabcis/tests/unit/benchmarks/<section>/` and are named `<module>_test.py`.

The `run()` helper from `conftest.py` is used to assert outcomes:

```python
from conftest import run
from gitlabcis.benchmarks.source_code_1 import code_changes_1_1

def test_some_function(glEntity, glObject):
    test = code_changes_1_1.some_function

    glEntity.some_attr = True
    run(glEntity, glObject, test, True, **{'isProject': True})

    glEntity.some_attr = False
    run(glEntity, glObject, test, False, **{'isProject': True})

    for kwargs in [{'isGroup': True}, {'isInstance': True}]:
        run(glEntity, glObject, test, None, **kwargs)
```

### Available Fixtures (from `conftest.py`)

```python
glEntity      # Mock() — represents a GitLab project/group/instance
glObject      # Mock() — represents the top-level gitlab.Gitlab client
unauthorised  # Mock(side_effect=GitlabGetError(response_code=401))
gqlClient     # patches gql.Client
```

### Mocking Pattern

Use `from unittest.mock import Mock, patch`. For external API calls, set attributes or side effects directly on `glEntity`:

```python
glEntity.some_method.return_value = [Mock()]
glEntity.some_method.side_effect = GitlabHttpError('msg', response_code=403)
```

For utility functions, use `@patch('gitlabcis.utils.ci.searchConfig')`.

---

## Commit Message Convention

Enforced by `commitlint` (Angular convention, max 72 char header):

```
<type>(<optional scope>): <subject in sentence-case or lower-case>
```

Allowed types: `build`, `chore`, `ci`, `docs`, `feat`, `fix`, `perf`, `refactor`, `style`, `test`

---

## Bandit / Security Notes

- `# nosec B506` is used for YAML loading with `GitLabYamlLoader` (a safe custom loader)
- Do not introduce `yaml.load()` without a safe loader
- Do not log or expose secrets or tokens
