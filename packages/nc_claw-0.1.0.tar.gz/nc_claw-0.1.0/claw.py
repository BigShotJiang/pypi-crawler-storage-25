#!/usr/bin/env python3
"""
Claw v0.6.1 — Terminal AI Assistant
  Multi-Agent · Group Chat · Per-Agent API · Skills · Web Gateway
Usage: python claw.py
Zero dependencies — Python 3.8+ stdlib only.

Changelog 0.6.1:
  - Fixed: backtick-wrapped commands not executing
  - Fixed: fenced code blocks interfering with parser
  - Fixed: //exec matching //executable (word boundary)
  - Fixed: trailing punctuation on args
  - Fixed: //python multiline code blocks
  - Fixed: //exec and //write multiline blocks
  - Fixed: //search quoted patterns
  - Fixed: //copy / //move quoted paths
  - Fixed: //download filename from URL with query strings
  - Fixed: group chat missing command continuation reply
  - Fixed: system prompt now includes command format rules
"""

import json, os, sys, subprocess, platform, re, time, shutil, signal, readline, threading
from pathlib import Path
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
from urllib.parse import urlparse, parse_qs

# ━━━ Config ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CONFIG_FILE = Path.home() / ".claw_config.json"
HISTORY_FILE = Path.home() / ".claw_history"
SKILLS_DIR = Path.home() / ".claw" / "workspace" / "skills"
WORKSPACE_FILE = Path.home() / ".claw" / "workspace" / "AGENTS.md"
AGENTS_FILE = Path.home() / ".claw" / "agents.json"
GROUPS_FILE = Path.home() / ".claw" / "groups.json"

MAX_HISTORY = 20
MAX_TOKENS = 4096
TEMPERATURE = 0.7
MAX_CHAIN_DEPTH = 5

config = {
    "api_key": os.getenv("AI_API_KEY", ""),
    "api_base": os.getenv("AI_API_BASE", "https://api.openai.com/v1"),
    "model": os.getenv("AI_MODEL", "gpt-4o"),
    "skills": [],
}

if CONFIG_FILE.exists():
    try:
        with open(CONFIG_FILE) as f:
            saved = json.load(f)
        config.update({k: v for k, v in saved.items() if v})
    except Exception:
        pass


def save_config():
    s = {}
    for k, v in config.items():
        if k != "api_key" or v:
            s[k] = v
    CONFIG_FILE.write_text(json.dumps(s, indent=2))


# ━━━ Colors ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class C:
    R = "\033[0m"
    B = "\033[1m"
    D = "\033[2m"
    RED = "\033[31m"
    GRN = "\033[32m"
    YEL = "\033[33m"
    BLU = "\033[34m"
    MAG = "\033[35m"
    CYN = "\033[36m"


AGENT_COLOR_LIST = [C.GRN, C.BLU, C.MAG, C.YEL, C.RED, C.CYN]
AGENT_COLOR_NAMES = ["green", "blue", "magenta", "yellow", "red", "cyan"]

# ━━━ Token Usage ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

token_usage = {
    "prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0,
    "requests": 0, "last_prompt": 0, "last_completion": 0,
}


def _print_tokens():
    lp, lc = token_usage["last_prompt"], token_usage["last_completion"]
    if lp > 0 or lc > 0:
        print("  {}{}p:{} {} {}c:{} {} {}t:{} {}{}".format(
            C.D, C.CYN, C.R, lp, C.CYN, C.R, lc, C.CYN, C.R, lp + lc, C.D, C.R))


# ━━━ Skills System ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

BUILTIN_SKILLS = {
    "coder": {
        "name": "Coder", "desc": "专业编程助手，擅长代码编写和调试",
        "prompt": "## Skill: Coder\nYou are an expert programmer. Write clean, well-commented code. Explain your approach before writing code. Prefer stdlib when possible.",
    },
    "analyst": {
        "name": "Analyst", "desc": "数据分析助手，擅长数据处理和可视化",
        "prompt": "## Skill: Analyst\nYou are a data analyst. Check data quality first. Use clear statistics. Suggest visualizations. Use Python with pandas/numpy.",
    },
    "writer": {
        "name": "Writer", "desc": "写作助手，擅长文档和文案撰写",
        "prompt": "## Skill: Writer\nYou are a professional writer. Adapt tone to context. Use clear, concise language. Structure with headings and lists. Support Chinese and English.",
    },
    "sysadmin": {
        "name": "SysAdmin", "desc": "系统管理助手，擅长服务器运维",
        "prompt": "## Skill: SysAdmin\nYou are a Linux/Unix sysadmin. Check current state before changes. Prefer non-destructive commands. Log important operations. Monitor resources.",
    },
    "translator": {
        "name": "Translator", "desc": "翻译助手，擅长中英互译",
        "prompt": "## Skill: Translator\nYou are a professional translator. Maintain original meaning and tone. Adapt idioms to natural equivalents. Preserve formatting. Default: Chinese <-> English.",
    },
}


def get_all_skills():
    skills = dict(BUILTIN_SKILLS)
    if SKILLS_DIR.exists():
        for d in sorted(SKILLS_DIR.iterdir()):
            if not d.is_dir():
                continue
            skill_file = d / "SKILL.md"
            if skill_file.exists():
                content = skill_file.read_text("utf-8", errors="replace")
                lines = content.strip().split("\n")
                name, desc = d.name, ""
                if lines and lines[0].startswith("# "):
                    name = lines[0][2:].strip()
                if len(lines) > 1 and lines[1].startswith("> "):
                    desc = lines[1][2:].strip()
                skills[d.name] = {"name": name, "desc": desc or "Custom: " + d.name, "prompt": content}
    return skills


def get_loaded_skills():
    all_skills = get_all_skills()
    return [all_skills[s] for s in config.get("skills", []) if s in all_skills]


def skill_prompt():
    loaded = get_loaded_skills()
    return "\n\n".join(s["prompt"] for s in loaded) if loaded else ""


def cmd_skill(args):
    all_skills = get_all_skills()
    if not args or args == "list":
        loaded_ids = set(config.get("skills", []))
        print("\n  {}Skills{}\n".format(C.CYN, C.R))
        print("  {}Builtin:{}".format(C.B, C.R))
        for sid, s in BUILTIN_SKILLS.items():
            marker = "{}*{}".format(C.GRN, C.R) if sid in loaded_ids else " "
            print("    {} {}{:<14}{} {}".format(marker, C.B, sid, C.R, s["desc"]))
        custom = {k: v for k, v in all_skills.items() if k not in BUILTIN_SKILLS}
        if custom:
            print("\n  {}Custom:{}".format(C.B, C.R))
            for sid, s in custom.items():
                marker = "{}*{}".format(C.GRN, C.R) if sid in loaded_ids else " "
                print("    {} {}{:<14}{} {}".format(marker, C.B, sid, C.R, s["desc"]))
        if loaded_ids:
            print("\n  {}Loaded:{} {}".format(C.D, C.R, ", ".join(loaded_ids)))
        print()
        return
    parts = args.split(None, 1)
    action, target = parts[0], parts[1].strip() if len(parts) > 1 else ""
    if action == "load":
        if not target or target not in all_skills:
            print("  {}Skill not found{}\n".format(C.RED, C.R))
            return
        if target not in config["skills"]:
            config["skills"].append(target)
            save_config()
        print("  {}Loaded: {}{}\n".format(C.GRN, target, C.R))
    elif action == "unload":
        if target in config["skills"]:
            config["skills"].remove(target)
            save_config()
        print("  {}Unloaded: {}{}\n".format(C.D, target, C.R))
    elif action == "info":
        if target not in all_skills:
            print("  {}Not found{}\n".format(C.RED, C.R))
            return
        s = all_skills[target]
        print("\n  {}Name:{}   {}".format(C.D, C.R, s["name"]))
        print("  {}Desc:{}   {}\n".format(C.D, C.R, s["desc"]))
    elif action == "create":
        if not target:
            print("  {}Usage: /skill create <name>{}\n".format(C.YEL, C.R))
            return
        if target in BUILTIN_SKILLS:
            print("  {}Cannot overwrite builtin{}\n".format(C.RED, C.R))
            return
        skill_dir = SKILLS_DIR / target
        skill_dir.mkdir(parents=True, exist_ok=True)
        skill_file = skill_dir / "SKILL.md"
        if skill_file.exists():
            print("  {}Already exists{}" .format(C.YEL, C.R))
            if input("  {}Overwrite? (y/N): {}".format(C.YEL, C.R)).strip().lower() != "y":
                return
        print("  {}Creating skill: {}{}{}".format(C.GRN, C.B, target, C.R))
        lines = ["# " + target]
        desc = input("  {}Description: {}".format(C.D, C.R)).strip()
        if desc:
            lines.append("> " + desc)
        lines.append("")
        print("  {}Prompt (empty line to finish):{}".format(C.D, C.R))
        while True:
            try:
                line = input("    ")
            except EOFError:
                break
            if line == "":
                break
            lines.append(line)
        skill_file.write_text("\n".join(lines) + "\n", "utf-8")
        print("\n  {}Saved to {}{}\n".format(C.GRN, skill_file, C.R))
    elif action == "delete":
        if not target or target in BUILTIN_SKILLS:
            print("  {}Cannot delete{}\n".format(C.RED, C.R))
            return
        skill_dir = SKILLS_DIR / target
        if not skill_dir.exists():
            print("  {}Not found{}\n".format(C.RED, C.R))
            return
        if input("  {}Delete '{}'? (y/N): {}".format(C.YEL, target, C.R)).strip().lower() == "y":
            shutil.rmtree(str(skill_dir))
            if target in config["skills"]:
                config["skills"].remove(target)
                save_config()
            print("  {}Deleted{}\n".format(C.D, C.R))
    elif action == "clear":
        config["skills"] = []
        save_config()
        print("  {}All skills unloaded{}\n".format(C.D, C.R))
    else:
        print("  {}Usage: /skill [list|load|unload|info|create|delete|clear]{}\n".format(C.D, C.R))


# ━━━ Conversation / System Prompt ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

messages = []


def build_system():
    si = "{} {} ({})".format(platform.system(), platform.release(), platform.machine())
    sh = "cmd/PowerShell" if platform.system() == "Windows" else os.getenv("SHELL", "/bin/bash")

    cmd_list = (
        "  //exec <cmd>              Shell command\n"
        "  //read <path>             Read file / list dir\n"
        "  //write <path>            Write file (content until //end)\n"
        "  //copy <src> <dst>        Copy file/dir\n"
        "  //move <src> <dst>        Move / rename\n"
        "  //delete <path>           Delete (blocked for safety)\n"
        "  //mkdir <path>            Create directory\n"
        "  //tree <dir> [--depth N]  Directory tree\n"
        "  //search <pat> <dir>      Find + grep\n"
        "  //info                    System info\n"
        "  //process [--filter <n>]  Processes\n"
        "  //kill <pid|name>         Kill process\n"
        "  //env <key>               Env variable\n"
        "  //time                    Date/time\n"
        "  //ip                      IP addresses\n"
        "  //ping <host>             Ping\n"
        "  //python <code>           Python snippet\n"
        "  //git <args>              Git command\n"
        "  //open <target>           Open app/file/URL\n"
        "  //browse <url>            Fetch URL as text\n"
        "  //download <url> <path>   Download file\n"
    )

    py_example = (
        "for i in range(5):\n"
        '    print(f"Step {i}")\n'
    )

    json_example = (
        '{\n'
        '  "name": "app",\n'
        '  "version": "1.0"\n'
        '}\n'
    )

    base = (
        "You are Claw, a local AI assistant. Execute commands to help the user.\n"
        "\n"
        "## Commands (embed naturally in your reply)\n"
        + cmd_list +
        "\n"
        "## Command Format Rules (MUST follow)\n"
        "- Each command MUST be on its OWN line, separated from prose text by a blank line\n"
        "- NEVER wrap commands in backticks or markdown code fences\n"
        "- NEVER add trailing punctuation to commands\n"
        "- Multi-line block: command keyword alone on one line, then content, then //end\n"
        "- For multi-line Python: //python on its own line, then code, then //end\n"
        "- For multi-line shell: //exec on its own line, then commands, then //end\n"
        "- For file writing: //write <path> on its own line, then content, then //end\n"
        "\n"
        "Correct example of multi-line Python:\n"
        "\n"
        "I will write a script.\n"
        "\n"
        "//python\n"
        + py_example +
        "//end\n"
        "\n"
        "Correct example of file writing:\n"
        "\n"
        "Let me create a config file.\n"
        "\n"
        "//write config.json\n"
        + json_example +
        "//end\n"
        "\n"
        "## Rules\n"
        "- Use commands when helpful, naturally within text\n"
        "- Multiple commands OK; results return automatically, then continue\n"
        "- Ask before destructive ops. Be concise.\n"
        "\n"
        "Environment: " + si + " | Shell: " + sh + " | CWD: " + os.getcwd() + "\n"
    )

    if WORKSPACE_FILE.exists():
        try:
            w = WORKSPACE_FILE.read_text("utf-8", errors="replace")
            if w.strip():
                base += "\n\n## Workspace\n" + w
        except Exception:
            pass

    sp = skill_prompt()
    if sp:
        base += "\n\n" + sp

    return base



# ━━━ Per-Agent API Config ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def get_agent_api(agent_name):
    a = agents.get(agent_name, {})
    return (
        a.get("api_key") or config["api_key"],
        a.get("api_base") or config["api_base"],
        a.get("model") or config["model"],
    )


def get_agent_api_display(agent_name):
    key, base, model = get_agent_api(agent_name)
    a = agents.get(agent_name, {})
    return {
        "api_key": key, "api_key_source": "agent" if a.get("api_key") else "global",
        "api_base": base, "api_base_source": "agent" if a.get("api_base") else "global",
        "model": model, "model_source": "agent" if a.get("model") else "global",
    }


def _mask_key(key):
    if not key:
        return "(not set)"
    if len(key) > 12:
        return key[:8] + "..." + key[-4:]
    return "***"


# ━━━ Agent System ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

agents = {}
groups = {}
current_mode = "default"
current_target = None


def load_agents():
    global agents
    if AGENTS_FILE.exists():
        try:
            agents = json.loads(AGENTS_FILE.read_text("utf-8"))
        except Exception:
            pass


def save_agents():
    AGENTS_FILE.parent.mkdir(parents=True, exist_ok=True)
    AGENTS_FILE.write_text(json.dumps(agents, indent=2, ensure_ascii=False), "utf-8")


def load_groups():
    global groups
    if GROUPS_FILE.exists():
        try:
            groups = json.loads(GROUPS_FILE.read_text("utf-8"))
        except Exception:
            pass


def save_groups():
    GROUPS_FILE.parent.mkdir(parents=True, exist_ok=True)
    GROUPS_FILE.write_text(json.dumps(groups, indent=2, ensure_ascii=False), "utf-8")


def get_agent_color(name):
    if name in agents:
        return AGENT_COLOR_LIST[agents[name].get("color_idx", 0) % len(AGENT_COLOR_LIST)]
    return C.GRN


def next_color_idx():
    used = {a.get("color_idx", -1) for a in agents.values()}
    for i in range(len(AGENT_COLOR_LIST)):
        if i not in used:
            return i
    return len(used) % len(AGENT_COLOR_LIST)


def get_prompt():
    if current_mode == "agent" and current_target:
        color = get_agent_color(current_target)
        return "{}you{} {}→{}{}{}> ".format(C.BLU, C.R, C.D, color, current_target, C.R)
    if current_mode == "group" and current_target:
        return "{}you{} {}[{}{}{}]{}> ".format(C.BLU, C.R, C.D, C.GRN, current_target, C.D, C.R)
    return "{}you{}> ".format(C.BLU, C.R)


def build_agent_system(agent_name):
    agent = agents.get(agent_name, {})
    base = build_system()
    return base + "\n\n## Agent Identity\nYou are '{}' (@{}).\n{}\nStay in character. Be concise.".format(
        agent.get("display_name", agent_name), agent_name, agent.get("role", ""))


def build_group_system(agent_name, group_name):
    agent = agents.get(agent_name, {})
    group = groups.get(group_name, {})
    base = build_system()
    members = []
    for m in group.get("members", []):
        if m in agents:
            tag = " (You)" if m == agent_name else ""
            members.append("  - @{}{}: {} — {}".format(m, tag, agents[m]["display_name"], agents[m].get("role", "")[:80]))
    return base + """

## Agent Identity
You are '{}' (@{}).
{}

## Group Chat: {}
Members:
{}

### Rules:
- Use @username to direct messages to specific members
- When @mentioned, you MUST respond
- Keep responses concise and on-topic
- Stay in character as {}""".format(
        agent.get("display_name", agent_name), agent_name, agent.get("role", ""),
        group_name, "\n".join(members),
        agent.get("display_name", agent_name))


def extract_mentions(text):
    return list(set(re.findall(r'@(\w+)', text)))


def group_to_api_msgs(group_name, agent_name):
    group = groups.get(group_name, {})
    sys_content = build_group_system(agent_name, group_name)
    api_msgs = [{"role": "system", "content": sys_content}]
    for m in group.get("history", [])[-MAX_HISTORY * 2:]:
        sender, content, role = m.get("agent", "user"), m.get("content", ""), m.get("role", "user")
        if sender == agent_name and role == "assistant":
            api_msgs.append({"role": "assistant", "content": content})
        else:
            formatted = content if sender in ("user", "system") else "[{}]: {}".format(sender, content)
            if api_msgs and api_msgs[-1]["role"] == "user":
                api_msgs[-1]["content"] += "\n\n" + formatted
            else:
                api_msgs.append({"role": "user", "content": formatted})
    return api_msgs


# ━━━ Agent Commands ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def cmd_agent(args):
    global current_mode, current_target

    if not args or args == "list":
        print("\n  {}Agents{}\n".format(C.CYN, C.R))
        if not agents:
            print("  {}No agents. Use /agent create <name>{}\n".format(C.D, C.R))
            return
        for name, a in agents.items():
            color = get_agent_color(name)
            active = (current_mode == "agent" and current_target == name)
            marker = "{}●{}".format(color, C.R) if active else " "
            role_p = a.get("role", "")[:40]
            _, base, model = get_agent_api(name)
            base_short = base.split("//")[-1].split("/")[0][:25]
            api_info = "{}{}{} @ {}{}{}".format(C.D, model, C.R, C.D, base_short, C.R)
            print("  {} {}{:<12}{} {:<14} {}  {}".format(
                marker, color, name, C.R, a["display_name"], api_info, role_p))
        if current_mode == "agent":
            print("\n  {}Active: →{}{}".format(C.D, current_target, C.R))
        print()
        return

    parts = args.split(None, 1)
    action = parts[0]
    rest = parts[1].strip() if len(parts) > 1 else ""

    if action == "create":
        if not rest:
            print("  {}Usage: /agent create <name>{}\n".format(C.YEL, C.R))
            return
        name = rest.split()[0].lower()
        if not re.match(r'^[a-zA-Z]\w*$', name):
            print("  {}Invalid name{}\n".format(C.RED, C.R))
            return
        if name in agents:
            print("  {}Already exists{}\n".format(C.RED, C.R))
            return
        display = input("  {}Display name [{}]: {}".format(C.D, name.title(), C.R)).strip() or name.title()
        role = input("  {}Role/prompt: {}".format(C.D, C.R)).strip()
        print("\n  {}API Configuration (leave blank to use global){}".format(C.YEL, C.R))
        print("  {}Global: {} @ {}{}".format(C.D, config["model"], config["api_base"], C.R))
        agent_key = input("  {}API Key:    {}".format(C.D, C.R)).strip()
        agent_base = input("  {}API Base:   {}".format(C.D, C.R)).strip()
        agent_model = input("  {}Model:      {}".format(C.D, C.R)).strip()
        agents[name] = {
            "display_name": display,
            "role": role or "You are {}, a helpful assistant.".format(display),
            "api_key": agent_key if agent_key else None,
            "api_base": agent_base if agent_base else None,
            "model": agent_model if agent_model else None,
            "color_idx": next_color_idx(),
            "history": [],
        }
        save_agents()
        color = get_agent_color(name)
        eff_key, eff_base, eff_model = get_agent_api(name)
        print("\n  {}Created:{} {}{}{}".format(C.GRN, C.R, color, name, C.R))
        print("  {}Model:{} {}  {}({}){}".format(C.D, C.R, eff_model, C.D, "agent" if agent_model else "global", C.R))
        print("  {}API:{}   {}  {}({}){}".format(C.D, C.R, eff_base, C.D, "agent" if agent_base else "global", C.R))
        print("  {}Key:{}   {}  {}({}){}\n".format(C.D, C.R, _mask_key(eff_key), C.D, "agent" if agent_key else "global", C.R))

    elif action == "delete":
        if not rest or rest not in agents:
            print("  {}Not found{}\n".format(C.RED, C.R))
            return
        if input("  {}Delete '{}'? (y/N): {}".format(C.YEL, rest, C.R)).strip().lower() == "y":
            del agents[rest]
            for g in groups.values():
                if rest in g.get("members", []):
                    g["members"].remove(rest)
            save_agents()
            save_groups()
            if current_mode == "agent" and current_target == rest:
                current_mode, current_target = "default", None
            print("  {}Deleted: {}{}\n".format(C.D, rest, C.R))

    elif action == "info":
        if not rest or rest not in agents:
            print("  {}Usage: /agent info <name>{}\n".format(C.YEL, C.R))
            return
        a = agents[rest]
        color = get_agent_color(rest)
        eff = get_agent_api_display(rest)
        print("\n  {}Name:{}     {}{}{}".format(C.D, C.R, color, a["display_name"], C.R))
        print("  {}ID:{}       @{}".format(C.D, C.R, rest))
        print("  {}Role:{}     {}".format(C.D, C.R, a.get("role", "N/A")))
        print("\n  {}── API Config ──{}".format(C.YEL, C.R))
        print("  {}Model:{}    {}  {}({}){}".format(C.D, C.R, eff["model"], C.D, eff["model_source"], C.R))
        print("  {}API Base:{} {}  {}({}){}".format(C.D, C.R, eff["api_base"], C.D, eff["api_base_source"], C.R))
        print("  {}API Key:{}  {}  {}({}){}".format(C.D, C.R, _mask_key(eff["api_key"]), C.D, eff["api_key_source"], C.R))
        cidx = a.get("color_idx", 0) % len(AGENT_COLOR_NAMES)
        print("\n  {}Color:{}    {}".format(C.D, C.R, AGENT_COLOR_NAMES[cidx]))
        in_groups = [gn for gn, g in groups.items() if rest in g.get("members", [])]
        if in_groups:
            print("  {}Groups:{}   {}".format(C.D, C.R, ", ".join(in_groups)))
        print()

    elif action == "rename":
        p = rest.split(None, 1)
        if len(p) < 2:
            print("  {}Usage: /agent rename <old> <new>{}\n".format(C.YEL, C.R))
            return
        old, new = p[0], p[1].strip().lower()
        if old not in agents or new in agents:
            print("  {}Error{}\n".format(C.RED, C.R))
            return
        agents[new] = agents.pop(old)
        for g in groups.values():
            if old in g.get("members", []):
                g["members"] = [new if m == old else m for m in g["members"]]
        save_agents()
        save_groups()
        if current_target == old:
            current_target = new
        print("  {}Renamed: {} → {}{}\n".format(C.GRN, old, new, C.R))

    elif action == "switch":
        if not rest or rest not in agents:
            print("  {}Usage: /agent switch <name>{}\n".format(C.YEL, C.R))
            return
        current_mode, current_target = "agent", rest
        color = get_agent_color(rest)
        eff = get_agent_api_display(rest)
        print("  {}Switched → {}{}{}".format(C.GRN, color, agents[rest]["display_name"], C.R))
        print("  {}Model:{} {} {}({}){}".format(C.D, C.R, eff["model"], C.D, eff["model_source"], C.R))
        print()

    elif action == "back":
        current_mode, current_target = "default", None
        print("  {}Back to default mode{}\n".format(C.D, C.R))

    elif action == "prompt":
        p = rest.split(None, 1)
        if not p or p[0] not in agents:
            print("  {}Usage: /agent prompt <name> [text]{}\n".format(C.YEL, C.R))
            return
        if len(p) > 1:
            agents[p[0]]["role"] = p[1]
            save_agents()
            print("  {}Updated{}\n".format(C.GRN, C.R))
        else:
            print("  {}Current:{} {}\n".format(C.D, C.R, agents[p[0]].get("role", "N/A")))

    elif action == "model":
        p = rest.split(None, 1)
        if not p or p[0] not in agents:
            print("  {}Usage: /agent model <name> [model]{}\n".format(C.YEL, C.R))
            return
        name = p[0]
        if len(p) > 1:
            agents[name]["model"] = p[1]
            save_agents()
            print("  {}{} model → {}{}\n".format(C.GRN, name, p[1], C.R))
        else:
            eff = get_agent_api_display(name)
            print("  {}{} model:{} {} {}({}){}\n".format(
                C.D, name, C.R, eff["model"], C.D, eff["model_source"], C.R))

    elif action == "api":
        if not rest or rest.split()[0] not in agents:
            print("  {}Usage: /agent api <name> [key=xxx base=xxx model=xxx]{}\n".format(C.YEL, C.R))
            print("  {}  /agent api alice                           {}(show){}".format(C.D, C.R, C.R))
            print("  {}  /agent api alice model=gpt-4o              {}(set model){}".format(C.D, C.R, C.R))
            print("  {}  /agent api alice api_key=sk-xxx api_base=https://..{}".format(C.D, C.R))
            print("  {}  /agent api alice api_key=clear model=clear  {}(reset){}".format(C.D, C.R, C.R))
            print()
            return
        tokens = rest.split(None, 1)
        name = tokens[0]
        if len(tokens) < 2:
            eff = get_agent_api_display(name)
            a = agents[name]
            print("\n  {}── {} API Config ──{}".format(C.YEL, a["display_name"], C.R))
            print("  {}Model:{}    {}  {}({}){}".format(C.D, C.R, eff["model"], C.D, eff["model_source"], C.R))
            print("  {}API Base:{} {}  {}({}){}".format(C.D, C.R, eff["api_base"], C.D, eff["api_base_source"], C.R))
            print("  {}API Key:{}  {}  {}({}){}".format(C.D, C.R, _mask_key(eff["api_key"]), C.D, eff["api_key_source"], C.R))
            print("\n  {}Global:{} {} @ {}".format(C.D, C.R, config["model"], config["api_base"]))
            print()
            return
        settings = tokens[1]
        parsed = dict(re.findall(r'(api_key|api_base|model)\s*=\s*(\S+)', settings))
        if not parsed:
            print("  {}No valid settings found{}\n".format(C.RED, C.R))
            return
        a = agents[name]
        for k, v in parsed.items():
            if v.lower() == "clear":
                a[k] = None
                print("  {}{}{} reset to global".format(C.GRN, k, C.R))
            else:
                a[k] = v
                print("  {}{}{} → {}{}{}".format(C.GRN, k, C.R, C.B, v, C.R))
        save_agents()
        print()

    elif action == "clear":
        if not rest or rest not in agents:
            print("  {}Usage: /agent clear <name>{}\n".format(C.YEL, C.R))
            return
        agents[rest]["history"] = []
        save_agents()
        print("  {}Cleared: {}{}\n".format(C.D, rest, C.R))

    else:
        print("  {}Usage: /agent [list|create|delete|info|rename|switch|back|prompt|model|api|clear]{}\n".format(C.D, C.R))


# ━━━ Group Commands ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def cmd_group(args):
    global current_mode, current_target

    if not args or args == "list":
        print("\n  {}Groups{}\n".format(C.CYN, C.R))
        if not groups:
            print("  {}No groups. Use /group create <name>{}\n".format(C.D, C.R))
            return
        for gname, g in groups.items():
            active = (current_mode == "group" and current_target == gname)
            marker = "{}●{}".format(C.GRN, C.R) if active else " "
            members = ", ".join("@{}".format(m) for m in g.get("members", []))
            print("  {} {}{:<14}{} [{}]".format(marker, C.B, gname, C.R, members))
            if g.get("desc"):
                print("      {}{}{}".format(C.D, g["desc"], C.R))
        print()
        return

    parts = args.split(None, 1)
    action = parts[0]
    rest = parts[1].strip() if len(parts) > 1 else ""

    if action == "create":
        if not rest:
            print("  {}Usage: /group create <name>{}\n".format(C.YEL, C.R))
            return
        name = rest.split()[0].lower()
        if name in groups:
            print("  {}Already exists{}\n".format(C.RED, C.R))
            return
        desc = input("  {}Description: {}".format(C.D, C.R)).strip()
        avail = ", ".join(agents.keys()) or "(none — create agents first)"
        print("  {}Available agents: {}{}".format(C.D, avail, C.R))
        member_input = input("  {}Members (comma-separated): {}".format(C.D, C.R)).strip()
        members = [m.strip().lower() for m in member_input.split(",") if m.strip()]
        invalid = [m for m in members if m not in agents]
        if invalid:
            print("  {}Unknown: {} — create with /agent first{}\n".format(C.RED, ", ".join(invalid), C.R))
            return
        groups[name] = {"desc": desc, "members": members, "history": []}
        save_groups()
        print("\n  {}Created:{} {}{}{} [{}]\n".format(C.GRN, C.R, C.B, name, C.R, ", ".join(members)))

    elif action == "delete":
        if not rest or rest not in groups:
            print("  {}Not found{}\n".format(C.RED, C.R))
            return
        if input("  {}Delete '{}'? (y/N): {}".format(C.YEL, rest, C.R)).strip().lower() == "y":
            del groups[rest]
            save_groups()
            if current_mode == "group" and current_target == rest:
                current_mode, current_target = "default", None
            print("  {}Deleted{}\n".format(C.D, C.R))

    elif action == "info":
        if not rest or rest not in groups:
            print("  {}Usage: /group info <name>{}\n".format(C.YEL, C.R))
            return
        g = groups[rest]
        print("\n  {}Group:{}   {}{}{}".format(C.D, C.R, C.B, rest, C.R))
        print("  {}Desc:{}    {}".format(C.D, C.R, g.get("desc", "N/A")))
        print("  {}Members:{} ".format(C.D, C.R))
        for m in g.get("members", []):
            if m in agents:
                color = get_agent_color(m)
                _, base, model = get_agent_api(m)
                base_short = base.split("//")[-1].split("/")[0][:20]
                print("    {}@{}{} — {}  ({} @ {})".format(color, m, C.R, agents[m]["display_name"], model, base_short))
            else:
                print("    {}@{}{} (missing)".format(C.RED, m, C.R))
        print("  {}History:{} {} messages\n".format(C.D, C.R, len(g.get("history", []))))

    elif action == "add":
        p = rest.split(None, 1)
        if len(p) < 2:
            print("  {}Usage: /group add <group> <agent>{}\n".format(C.YEL, C.R))
            return
        gname, aname = p[0], p[1].strip().lower()
        if gname not in groups or aname not in agents:
            print("  {}Not found{}\n".format(C.RED, C.R))
            return
        if aname in groups[gname].get("members", []):
            print("  {}Already in group{}\n".format(C.YEL, C.R))
            return
        groups[gname]["members"].append(aname)
        save_groups()
        print("  {}Added {} → {}{}\n".format(C.GRN, aname, gname, C.R))

    elif action == "remove":
        p = rest.split(None, 1)
        if len(p) < 2 or p[0] not in groups:
            print("  {}Usage: /group remove <group> <agent>{}\n".format(C.YEL, C.R))
            return
        if p[1].strip().lower() in groups[p[0]].get("members", []):
            groups[p[0]]["members"].remove(p[1].strip().lower())
            save_groups()
            print("  {}Removed{}\n".format(C.D, C.R))
        else:
            print("  {}Not in group{}\n".format(C.RED, C.R))

    elif action == "enter":
        if not rest or rest not in groups:
            print("  {}Usage: /group enter <name>{}\n".format(C.YEL, C.R))
            return
        if not groups[rest].get("members"):
            print("  {}No members{}\n".format(C.RED, C.R))
            return
        current_mode, current_target = "group", rest
        members = " ".join("{}@{}{}".format(get_agent_color(m), m, C.R) for m in groups[rest]["members"])
        print("  {}Entered:{} {}{}{}".format(C.GRN, C.R, C.B, rest, C.R))
        print("  {}Members:{} {}".format(C.D, C.R, members))
        for m in groups[rest]["members"]:
            if m in agents:
                _, base, model = get_agent_api(m)
                color = get_agent_color(m)
                base_short = base.split("//")[-1].split("/")[0][:25]
                print("    {}@{}{} → {} @ {}".format(color, m, C.R, model, base_short))
        print("  {}Use @name to target, @all for everyone{}\n".format(C.D, C.R))

    elif action == "leave":
        if current_mode == "group":
            print("  {}Left: {}{}\n".format(C.D, current_target, C.R))
            current_mode, current_target = "default", None
        else:
            print("  {}Not in a group{}\n".format(C.D, C.R))

    elif action == "clear":
        if not rest or rest not in groups:
            print("  {}Usage: /group clear <name>{}\n".format(C.YEL, C.R))
            return
        groups[rest]["history"] = []
        save_groups()
        print("  {}Cleared{}\n".format(C.D, C.R))

    else:
        print("  {}Usage: /group [list|create|delete|info|add|remove|enter|leave|clear]{}\n".format(C.D, C.R))


# ━━━ Command Parser & Executor ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CMD_TYPES = [
    "exec", "open", "read", "write", "browse", "download",
    "copy", "move", "delete", "mkdir", "tree", "search",
    "info", "process", "kill", "env", "time", "ip", "ping", "python", "git",
]

DANGER = [
    r'\brm\s+(-[a-zA-Z]*r|--recursive)\b', r'\bmkfs\b', r'\bdd\s+if=',
    r'\b(shutdown|reboot|halt)\b', r'\bkill\s+(-9\s+)?1\b', r'\brm\s+-rf\s+[~/]',
]


def is_dangerous(cmd):
    return any(re.search(p, cmd, re.I) for p in DANGER)


def _strip_artifacts(text):
    """Remove Markdown formatting that interferes with command parsing."""
    text = text.replace('\r\n', '\n').replace('\r', '\n')
    # Remove fenced code blocks: ```bash ... ```
    text = re.sub(r'```\w*\s*\n', '\n', text)
    text = text.replace('```', '')
    # Remove inline backticks around commands: `//exec ls` → //exec ls
    text = re.sub(r'`(\s*//[^`]+?)`', r'\1', text)
    # Remove bold markers: **//exec ls** → //exec ls
    text = re.sub(r'\*\*(\s*//[^*]+?)\*\*', r'\1', text)
    return text


def parse_commands(text):
    """Parse //commands from AI replies.

    Supports:
    - //write <path>\\n...//end          multi-line file write
    - //python\\n...code...//end        multi-line Python
    - //exec\\n...script...//end        multi-line shell
    - //cmd args                        single-line commands
    """
    cmds = []
    clean = _strip_artifacts(text)

    # ── Multi-line blocks ──

    # //write <path>\n...content...\n//end
    for m in re.finditer(r'//write\s+(.+?)\s*\n(.*?)//end', clean, re.DOTALL | re.I):
        path = m.group(1).strip().strip('`"\'*')
        content = m.group(2)
        if content.startswith('\n'):
            content = content[1:]
        cmds.append({"type": "write", "args": path, "content": content})

    # //python\n...code...\n//end
    for m in re.finditer(r'//python\s*\n(.*?)//end', clean, re.DOTALL | re.I):
        code = m.group(1).rstrip('\n')
        cmds.append({"type": "python", "args": code})

    # //exec\n...script...\n//end
    for m in re.finditer(r'//exec\s*\n(.*?)//end', clean, re.DOTALL | re.I):
        script = m.group(1).rstrip('\n')
        cmds.append({"type": "exec", "args": script})

    # ── Single-line commands ──
    # \b word boundary prevents //exec matching //executable
    pat = r'//\s*(' + '|'.join(CMD_TYPES) + r')\b[ \t]*(.*?)[ \t]*$'
    for m in re.finditer(pat, clean, re.M | re.I):
        cmd_type = m.group(1).lower()
        args = m.group(2).strip()

        # Already handled by multi-line blocks
        if cmd_type == "write":
            continue
        if cmd_type in ("python", "exec") and not args:
            continue

        # Clean args: remove backticks, quotes, bold, trailing punctuation
        args = args.strip('`"\'*')
        args = args.rstrip('.,;:!?')

        if not args and cmd_type not in ("info", "time", "ip"):
            continue

        cmds.append({"type": cmd_type, "args": args})

    return cmds


def _run(cmd, timeout=30):
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
    out = r.stdout
    if r.stderr.strip():
        out += ("\n" if out else "") + "[stderr] " + r.stderr
    if r.returncode != 0:
        out += "\n[exit: {}]".format(r.returncode)
    return (out or "[No output]").strip()[:10000]


def _is_binary(path):
    try:
        with open(path, "rb") as f:
            return b"\x00" in f.read(8192)
    except Exception:
        return False


def _quote_split(args, n):
    """Split args respecting quoted strings, return list of n+ parts."""
    qparts = re.findall(r'(?:[^\s"]+|"[^"]*"|\'[^\']*\')+', args)
    if len(qparts) < n:
        return None
    return [p.strip('"\'') for p in qparts]


def execute_command(cmd):
    t, args = cmd["type"], cmd.get("args", "")

    try:
        if t == "exec":
            if is_dangerous(args):
                return "[BLOCKED: dangerous command: {}]".format(args)
            return _run(args)

        if t == "open":
            s = platform.system()
            if s == "Darwin":
                subprocess.Popen(["open", args], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            elif s == "Windows":
                os.startfile(args)
            else:
                subprocess.Popen(["xdg-open", args], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return "[Opened: {}]".format(args)

        if t == "read":
            p = Path(args).expanduser().resolve()
            if not p.exists():
                return "[Not found: {}]".format(args)
            if p.is_dir():
                items = sorted(p.iterdir())
                lines = []
                for i in items[:200]:
                    tag = "[D]" if i.is_dir() else "[F]"
                    lines.append("{}  {}".format(tag, i.name))
                return "\n".join(lines) or "[Empty]"
            if _is_binary(p):
                return "[Binary: {} ({} bytes)]".format(p, p.stat().st_size)
            text = p.read_text("utf-8", errors="replace")
            lines = text.split("\n")
            if len(lines) > 500:
                return "\n".join(lines[:500]) + "\n... [{} lines]".format(len(lines))
            return text

        if t == "write":
            p = Path(args).expanduser().resolve()
            p.parent.mkdir(parents=True, exist_ok=True)
            c = cmd.get("content", "")
            p.write_text(c, "utf-8")
            return "[Written {} chars to {}]".format(len(c), p)

        if t == "browse":
            import urllib.request
            req = urllib.request.Request(args, headers={"User-Agent": "Claw/1.0"})
            with urllib.request.urlopen(req, timeout=15) as r:
                raw = r.read().decode("utf-8", errors="replace")
            clean = re.sub(r'<(script|style)[^>]*>.*?</\1>', '', raw, flags=re.DOTALL)
            clean = re.sub(r'<[^>]+>', ' ', clean)
            return re.sub(r'\s+', ' ', clean).strip()[:6000]

        if t == "download":
            import urllib.request
            from urllib.parse import urlparse as _urlparse
            parts = args.split()
            url = parts[0]
            if len(parts) > 1:
                dst = Path(parts[1]).expanduser().resolve()
            else:
                filename = Path(_urlparse(url).path).name or "download"
                dst = Path(".") / filename
            dst.parent.mkdir(parents=True, exist_ok=True)
            urllib.request.urlretrieve(url, str(dst))
            return "[Downloaded {} bytes to {}]".format(dst.stat().st_size, dst)

        if t == "copy":
            qp = _quote_split(args, 2)
            if not qp:
                return "[Usage: //copy <src> <dst>]"
            src, dst = Path(qp[0]).expanduser().resolve(), Path(qp[1]).expanduser().resolve()
            if not src.exists():
                return "[Not found: {}]".format(src)
            if src.is_dir():
                shutil.copytree(str(src), str(dst))
            else:
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(str(src), str(dst))
            return "[Copied to {}]".format(dst)

        if t == "move":
            qp = _quote_split(args, 2)
            if not qp:
                return "[Usage: //move <src> <dst>]"
            src, dst = Path(qp[0]).expanduser().resolve(), Path(qp[1]).expanduser().resolve()
            if not src.exists():
                return "[Not found: {}]".format(src)
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(src), str(dst))
            return "[Moved to {}]".format(dst)

        if t == "delete":
            p = Path(args).expanduser().resolve()
            if not p.exists():
                return "[Not found: {}]".format(p)
            return "[BLOCKED: use //exec rm for manual delete]"

        if t == "mkdir":
            Path(args).expanduser().resolve().mkdir(parents=True, exist_ok=True)
            return "[Created: {}]".format(args)

        if t == "tree":
            parts = args.split("--depth")
            dp = Path(parts[0].strip() or ".").expanduser().resolve()
            depth = int(parts[1].strip()) if len(parts) > 1 and parts[1].strip() else 3
            if not dp.is_dir():
                return "[Not a dir: {}]".format(dp)
            lines = [str(dp)]

            def walk(d, prefix="", lvl=0):
                if lvl >= depth:
                    return
                try:
                    entries = sorted(d.iterdir(), key=lambda x: (x.is_file(), x.name.lower()))
                except PermissionError:
                    return
                for idx, e in enumerate(entries):
                    last = idx == len(entries) - 1
                    lines.append("{}{}{}{}".format(
                        prefix, "--- " if last else "--- ",
                        e.name, "/" if e.is_dir() else ""))
                    if e.is_dir():
                        walk(e, prefix + ("    " if last else "|   "), lvl + 1)

            walk(dp)
            return "\n".join(lines[:300])

        if t == "search":
            qp = re.findall(r'(?:[^\s"]+|"[^"]*"|\'[^\']*\')+', args)
            if len(qp) < 2:
                return "[Usage: //search <pattern> <dir>]"
            search_pat = qp[0].strip('"\'')
            sd = Path(qp[-1].strip('"\'')).expanduser().resolve()
            results = []
            for p in sd.rglob("*{}*".format(search_pat)):
                results.append("[name] {}".format(p))
                if len(results) >= 50:
                    break
            for p in sd.rglob("*"):
                if not p.is_file() or p.stat().st_size > 1_000_000 or _is_binary(p):
                    continue
                try:
                    text = p.read_text("utf-8", errors="replace")
                    for i, line in enumerate(text.split("\n"), 1):
                        if re.search(re.escape(search_pat), line, re.I):
                            results.append("[grep] {}:{}: {}".format(p, i, line.strip()[:120]))
                            if len(results) >= 50:
                                break
                except Exception:
                    continue
                if len(results) >= 50:
                    break
            return "\n".join(results) or "[No matches]"

        if t == "info":
            lines = [
                "OS      : {} {} ({})".format(platform.system(), platform.release(), platform.machine()),
                "Host    : {}".format(platform.node()),
                "Python  : {}".format(platform.python_version()),
                "CWD     : {}".format(os.getcwd()),
                "PID     : {}".format(os.getpid()),
            ]
            try:
                u = shutil.disk_usage(str(Path.home()))
                lines.append("Disk    : {}G / {}G".format(u.used // (1024 ** 3), u.total // (1024 ** 3)))
            except Exception:
                pass
            return "\n".join(lines)

        if t == "process":
            flt = ""
            if "--filter" in args:
                flt = args.split("--filter")[1].strip()
            cmd_str = "tasklist /fo csv" if platform.system() == "Windows" else "ps aux"
            out = _run(cmd_str, timeout=10)
            if flt and platform.system() != "Windows":
                lines = out.split("\n")
                header = lines[0] if lines else ""
                matched = [l for l in lines[1:] if flt.lower() in l.lower()]
                return header + "\n" + "\n".join(matched[:30]) if matched else "[No matches]"
            return "\n".join(out.split("\n")[:35])

        if t == "kill":
            if not args:
                return "[Usage: //kill <pid_or_name>]"
            if args.isdigit():
                os.kill(int(args), signal.SIGTERM)
                return "[SIGTERM to PID {}]".format(args)
            if platform.system() != "Windows":
                _run("pkill -f {}".format(args))
            else:
                _run("taskkill /IM {} /F".format(args))
            return "[Killed: {}]".format(args)

        if t == "env":
            if not args:
                return "\n".join("{}={}".format(k, v[:80]) for k, v in sorted(os.environ.items()))
            v = os.getenv(args)
            return "{}={}".format(args, v) if v else "[Not set: {}]".format(args)

        if t == "time":
            import datetime
            now = datetime.datetime.now()
            return "Local : {}\nUTC   : {}\nUnix  : {:.0f}".format(
                now.strftime("%Y-%m-%d %H:%M:%S"),
                datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
                time.time(),
            )

        if t == "ip":
            lines = ["[Local] " + _run("hostname -I 2>/dev/null || ifconfig | grep 'inet '")]
            try:
                import urllib.request
                pub = urllib.request.urlopen("https://api.ipify.org", 5).read().decode()
                lines.append("[Public] {}".format(pub))
            except Exception:
                lines.append("[Public] Failed to fetch")
            return "\n".join(lines)

        if t == "ping":
            parts = args.split("--count")
            host, cnt = parts[0].strip(), (parts[1].strip() if len(parts) > 1 else "4")
            flag = "-n" if platform.system() == "Windows" else "-c"
            return _run("ping {} {} {}".format(flag, cnt, host), 15)

        if t == "python":
            import io, contextlib, textwrap
            stdout_buf = io.StringIO()
            try:
                code = textwrap.dedent(args)
                with contextlib.redirect_stdout(stdout_buf):
                    exec(code, {"__builtins__": __builtins__, "os": os, "sys": sys,
                                "Path": Path, "json": json, "re": re, "time": time})
                return stdout_buf.getvalue().strip() or "[No output]"
            except Exception as e:
                return "[Error] {}: {}".format(type(e).__name__, e)

        if t == "git":
            return _run("git {}".format(args))

        return "[Unknown: {}]".format(t)

    except subprocess.TimeoutExpired:
        return "[Timeout 30s]"
    except Exception as e:
        return "[Error: {}: {}]".format(type(e).__name__, e)


# ━━━ Streaming API Client ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def stream_api(msgs, callback, api_key=None, api_base=None, model=None):
    import urllib.request
    key = api_key or config["api_key"]
    base = api_base or config["api_base"]
    mdl = model or config["model"]

    body = json.dumps({
        "model": mdl, "messages": msgs, "stream": True,
        "stream_options": {"include_usage": True},
        "temperature": TEMPERATURE, "max_tokens": MAX_TOKENS,
    }).encode()

    url = "{}/chat/completions".format(base)
    req = urllib.request.Request(url, data=body, headers={
        "Content-Type": "application/json",
        "Authorization": "Bearer {}".format(key),
        "Accept": "text/event-stream",
        "Accept-Encoding": "identity",
    }, method="POST")

    resp = urllib.request.urlopen(req, timeout=120)
    full, buf = "", ""
    last_usage = {}

    for chunk in iter(lambda: resp.read(512), b""):
        buf += chunk.decode("utf-8", errors="replace")
        while "\n" in buf:
            line, buf = buf.split("\n", 1)
            line = line.strip()
            if not line.startswith("data:"):
                continue
            payload = line[5:].strip()
            if payload == "[DONE]":
                break
            try:
                obj = json.loads(payload)
                if "usage" in obj and obj["usage"]:
                    last_usage = obj["usage"]
                tok = obj.get("choices", [{}])[0].get("delta", {}).get("content", "")
                if tok:
                    full += tok
                    callback(tok)
            except (json.JSONDecodeError, KeyError, IndexError):
                continue

    if last_usage:
        token_usage["prompt_tokens"] += last_usage.get("prompt_tokens", 0)
        token_usage["completion_tokens"] += last_usage.get("completion_tokens", 0)
        token_usage["total_tokens"] += last_usage.get("total_tokens", 0)
        token_usage["requests"] += 1
        token_usage["last_prompt"] = last_usage.get("prompt_tokens", 0)
        token_usage["last_completion"] = last_usage.get("completion_tokens", 0)

    return full


# ━━━ Web Gateway ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

gateway_server = None
gateway_port = None
gateway_start_time = 0
gateway_messages = []


class GatewayHandler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def send_json(self, data, status=200):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", len(body))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.end_headers()
        self.wfile.write(body)

    def send_ndjson_header(self):
        self.send_response(200)
        self.send_header("Content-Type", "application/x-ndjson; charset=utf-8")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.end_headers()

    def send_event(self, data):
        self.wfile.write((json.dumps(data, ensure_ascii=False) + "\n").encode("utf-8"))
        self.wfile.flush()

    def read_body(self):
        n = int(self.headers.get("Content-Length", 0))
        return json.loads(self.rfile.read(n)) if n else {}

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/api/health":
            self.send_json({
                "status": "ok", "version": "0.6.1", "model": config["model"],
                "agents": list(agents.keys()), "groups": list(groups.keys()),
                "uptime": time.time() - gateway_start_time,
                "token_usage": {"total": token_usage["total_tokens"], "requests": token_usage["requests"]},
            })
            return
        if path == "/api/config":
            safe = {k: v for k, v in config.items() if k != "api_key"}
            safe["has_key"] = bool(config["api_key"])
            self.send_json(safe)
            return
        if path == "/api/skills":
            all_skills = get_all_skills()
            loaded_ids = config.get("skills", [])
            result = [{"id": sid, "name": s["name"], "desc": s["desc"],
                        "loaded": sid in loaded_ids, "builtin": sid in BUILTIN_SKILLS}
                       for sid, s in all_skills.items()]
            self.send_json({"skills": result, "loaded": loaded_ids})
            return
        if path == "/api/agents":
            result = []
            for name, a in agents.items():
                eff = get_agent_api_display(name)
                result.append({"name": name, "display_name": a["display_name"],
                    "role": a.get("role", ""), "effective_api": {
                        "model": eff["model"], "api_base": eff["api_base"],
                        "model_source": eff["model_source"]}})
            self.send_json({"agents": result})
            return
        if path == "/api/groups":
            self.send_json({"groups": [{"name": n, "desc": g.get("desc", ""),
                "members": g.get("members", []), "history_count": len(g.get("history", []))}
                for n, g in groups.items()]})
            return
        if path == "/api/history":
            display = [{"role": m["role"], "content": m["content"]}
                       for m in gateway_messages if m["role"] in ("user", "assistant")
                       and not m["content"].startswith("[")]
            self.send_json({"messages": display})
            return
        if path == "/api/usage":
            self.send_json(token_usage)
            return
        if path in ("/api", "/"):
            self.send_json({"name": "Claw Gateway", "version": "0.6.1",
                "endpoints": {"GET /api/health": "Health", "GET /api/config": "Config",
                    "GET /api/skills": "Skills", "GET /api/agents": "Agents",
                    "GET /api/groups": "Groups", "GET /api/history": "History",
                    "GET /api/usage": "Token usage",
                    "POST /api/chat": "Chat (streaming ndjson)",
                    "POST /api/chat/sync": "Chat (sync)", "POST /api/clear": "Clear",
                    "POST /api/config": "Update config"}})
            return
        self.send_json({"error": "Not found"}, 404)

    def do_POST(self):
        path = urlparse(self.path).path
        if path == "/api/chat":
            self.handle_gateway_chat(True)
            return
        if path == "/api/chat/sync":
            self.handle_gateway_chat(False)
            return
        if path == "/api/clear":
            gateway_messages.clear()
            self.send_json({"ok": True})
            return
        if path == "/api/config":
            data = self.read_body()
            for k in ("api_key", "api_base", "model"):
                if k in data and data[k]:
                    config[k] = data[k]
            save_config()
            self.send_json({"ok": True})
            return
        if path == "/api/skills":
            data = self.read_body()
            action = data.get("action", "")
            skill_id = data.get("id", "")
            if action == "load":
                all_skills = get_all_skills()
                if skill_id not in all_skills:
                    self.send_json({"error": "Skill not found"}, 404)
                    return
                if skill_id not in config["skills"]:
                    config["skills"].append(skill_id)
                    save_config()
                self.send_json({"ok": True, "loaded": config["skills"]})
            elif action == "unload":
                if skill_id in config["skills"]:
                    config["skills"].remove(skill_id)
                    save_config()
                self.send_json({"ok": True, "loaded": config["skills"]})
            elif action == "clear":
                config["skills"] = []
                save_config()
                self.send_json({"ok": True, "loaded": []})
            else:
                self.send_json({"error": "Unknown action"}, 400)
            return
        self.send_json({"error": "Not found"}, 404)

    def handle_gateway_chat(self, streaming=True):
        data = self.read_body()
        user_msg = data.get("message", "").strip()
        if not user_msg:
            self.send_json({"error": "Empty message"}, 400)
            return
        if not config.get("api_key"):
            self.send_json({"error": "No API key"}, 400)
            return
        gateway_messages.append({"role": "user", "content": user_msg})
        if streaming:
            self.send_ndjson_header()
        sys_msg = {"role": "system", "content": build_system()}
        api_msgs = [sys_msg] + gateway_messages[-MAX_HISTORY * 2:]
        t0 = time.time()
        try:
            reply = stream_api(api_msgs,
                               lambda tok: self.send_event({"type": "token", "content": tok}) if streaming else None)
            elapsed = time.time() - t0
            if not reply:
                if streaming:
                    self.send_event({"type": "error", "content": "No response"})
                    self.send_event({"type": "done"})
                return
            gateway_messages.append({"role": "assistant", "content": reply})

            # Execute commands
            cmds = parse_commands(reply)
            cmd_results = []
            if cmds:
                if streaming:
                    self.send_event({"type": "commands", "commands": [
                        {"type": c["type"], "args": c.get("args", "")} for c in cmds]})
                for i, c in enumerate(cmds):
                    res = execute_command(c)
                    if streaming:
                        self.send_event({"type": "result", "index": i, "content": res})
                    cmd_results.append({"command": {"type": c["type"], "args": c.get("args", "")}, "result": res})
                gateway_messages.append({"role": "user", "content": "[Command results]\n" + "\n".join(
                    "[{}:{}] -> {}".format(r["command"]["type"], r["command"]["args"], r["result"]) for r in cmd_results)})
                # Continue after commands
                recent2 = gateway_messages[-MAX_HISTORY * 2:]
                api_msgs2 = [sys_msg] + recent2
                reply2 = stream_api(api_msgs2,
                                    lambda tok: self.send_event({"type": "token", "content": tok}) if streaming else None)
                if reply2:
                    gateway_messages.append({"role": "assistant", "content": reply2})

            usage_info = {"prompt": token_usage["last_prompt"], "completion": token_usage["last_completion"],
                          "total": token_usage["last_prompt"] + token_usage["last_completion"],
                          "time": round(elapsed, 2)}
            if streaming:
                self.send_event({"type": "usage", "usage": usage_info})
                self.send_event({"type": "done"})
            else:
                response = {"reply": reply, "time": round(elapsed, 2), "usage": usage_info}
                if cmd_results:
                    response["commands"] = cmd_results
                self.send_json(response)
        except Exception as e:
            if streaming:
                self.send_event({"type": "error", "content": str(e)})
                self.send_event({"type": "done"})
            else:
                self.send_json({"error": str(e)}, 500)
        if len(gateway_messages) > MAX_HISTORY * 2:
            gateway_messages[:] = gateway_messages[-MAX_HISTORY * 2:]


class ThreadedGateway(ThreadingMixIn, HTTPServer):
    daemon_threads = True


def cmd_gateway(args):
    global gateway_server, gateway_port, gateway_start_time
    parts = args.split(None, 1) if args else []
    action = parts[0] if parts else "status"
    target = parts[1].strip() if len(parts) > 1 else ""
    if action == "start":
        if gateway_server:
            print("  {}Already running on port {}{}\n".format(C.YEL, gateway_port, C.R))
            return
        port = int(target) if target and target.isdigit() else 8765
        try:
            gateway_server = ThreadedGateway(("0.0.0.0", port), GatewayHandler)
            gateway_port, gateway_start_time = port, time.time()
            threading.Thread(target=gateway_server.serve_forever, daemon=True).start()
            print("  {}Gateway started on port {}{}\n".format(C.GRN, port, C.R))
        except OSError as e:
            print("  {}Failed: {}{}\n".format(C.RED, e, C.R))
    elif action == "stop":
        if not gateway_server:
            print("  {}Not running{}\n".format(C.D, C.R))
            return
        gateway_server.shutdown()
        gateway_server = gateway_port = None
        print("  {}Stopped{}\n".format(C.D, C.R))
    elif action == "status":
        if gateway_server:
            print("\n  {}Gateway: {}running{} port {} ({:.0f}s){}\n".format(
                C.D, C.GRN, C.R, gateway_port, time.time() - gateway_start_time, C.R))
        else:
            print("\n  {}Gateway: {}stopped{}\n".format(C.D, C.RED, C.R))
    elif action == "restart":
        port = int(target) if target and target.isdigit() else (gateway_port or 8765)
        if gateway_server:
            gateway_server.shutdown()
            gateway_server = gateway_port = None
        cmd_gateway("start {}".format(port))
    else:
        print("  {}Usage: /gateway [start|stop|status|restart] [port]{}\n".format(C.D, C.R))


# ━━━ Chat Logic ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def _exec_commands(reply, history, agent_name=""):
    """Execute commands from AI reply. Returns True if commands were found."""
    cmds = parse_commands(reply)
    if not cmds:
        return False
    for c in cmds:
        print("\n  {}[{}] {}{}".format(C.YEL, c["type"], c.get("args", ""), C.R))
        result = execute_command(c)
        for line in result.split("\n")[:30]:
            print("  {}| {}{}".format(C.D, C.GRN, line, C.R))
        print("  {}{}{}".format(C.D, "-" * 40, C.R))
        entry = {"role": "user", "content": "[{}:{}] -> {}".format(c["type"], c.get("args", ""), result)}
        if agent_name:
            entry["agent"] = "system"
        history.append(entry)
    return True


def chat(user_input):
    """Default mode — chat with Claw using global API."""
    global messages
    messages.append({"role": "user", "content": user_input})

    loaded = config.get("skills", [])
    tag = "{}claw{}>".format(C.CYN, C.R)
    if loaded:
        tag = "{}claw{} {}[{}]{}>".format(C.CYN, C.R, C.MAG, ",".join(loaded), C.R)

    if not config.get("api_key"):
        reply = "未配置 API Key，请输入 /key <key> 设置。"
        print("\n{} {}\n".format(tag, reply))
        messages.append({"role": "assistant", "content": reply})
        return

    sys_msg = {"role": "system", "content": build_system()}
    api_msgs = [sys_msg] + messages[-MAX_HISTORY * 2:]

    print("\n{} ".format(tag), end="", flush=True)
    t0 = time.time()
    reply = stream_api(api_msgs, lambda tok: sys.stdout.write(tok) or sys.stdout.flush())
    elapsed = time.time() - t0
    if not reply:
        print("{}(no response){}".format(C.RED, C.R))
        return
    print("  {}({:.1f}s){}".format(C.D, elapsed, C.R))
    _print_tokens()
    messages.append({"role": "assistant", "content": reply})

    had_cmds = _exec_commands(reply, messages)

    if had_cmds:
        recent2 = messages[-MAX_HISTORY * 2:]
        api_msgs2 = [sys_msg] + recent2
        print("\n{} ".format(tag), end="", flush=True)
        reply2 = stream_api(api_msgs2, lambda tok: sys.stdout.write(tok) or sys.stdout.flush())
        if reply2:
            print()
            _print_tokens()
            messages.append({"role": "assistant", "content": reply2})

    if len(messages) > MAX_HISTORY * 2:
        messages[:] = messages[-MAX_HISTORY * 2:]


def chat_agent(user_input):
    """Agent mode — 1-on-1 with a named agent using its own API."""
    agent_name = current_target
    agent = agents[agent_name]
    color = get_agent_color(agent_name)
    display = agent["display_name"]
    history = agent.setdefault("history", [])

    history.append({"role": "user", "content": user_input})

    a_key, a_base, a_model = get_agent_api(agent_name)
    sys_msg = {"role": "system", "content": build_agent_system(agent_name)}
    api_msgs = [sys_msg] + history[-MAX_HISTORY * 2:]

    tag = "{}{}{}>".format(color, display, C.R)
    print("\n{} ".format(tag), end="", flush=True)
    t0 = time.time()
    reply = stream_api(api_msgs, lambda tok: sys.stdout.write(tok) or sys.stdout.flush(),
                       api_key=a_key, api_base=a_base, model=a_model)
    elapsed = time.time() - t0

    if not reply:
        print("{}(no response){}".format(C.RED, C.R))
        return
    print("  {}({:.1f}s){}".format(C.D, elapsed, C.R))
    _print_tokens()
    history.append({"role": "assistant", "content": reply})

    had_cmds = _exec_commands(reply, history)

    if had_cmds:
        recent2 = history[-MAX_HISTORY * 2:]
        api_msgs2 = [sys_msg] + recent2
        print("\n{} ".format(tag), end="", flush=True)
        reply2 = stream_api(api_msgs2, lambda tok: sys.stdout.write(tok) or sys.stdout.flush(),
                            api_key=a_key, api_base=a_base, model=a_model)
        if reply2:
            print()
            _print_tokens()
            history.append({"role": "assistant", "content": reply2})

    if len(history) > MAX_HISTORY * 2:
        agent["history"] = history[-MAX_HISTORY * 2:]
    save_agents()


def chat_group(user_input):
    """Group mode — multi-agent chat with @mention routing and AI chain."""
    group_name = current_target
    group = groups[group_name]
    history = group.setdefault("history", [])

    mentions = extract_mentions(user_input)
    members = set(group.get("members", []))

    if "all" in mentions:
        targets = list(group["members"])
    elif mentions:
        targets = [m for m in mentions if m in members]
        if not targets:
            print("  {}No valid @mention. Members: {}{}\n".format(
                C.RED, ", ".join("@" + m for m in members), C.R))
            return
    else:
        targets = [group["members"][0]]

    history.append({"role": "user", "content": user_input, "agent": "user"})

    responded = set()
    chain_depth = 0
    pending = list(targets)

    while pending and chain_depth < MAX_CHAIN_DEPTH:
        agent_name = pending.pop(0)
        if agent_name in responded or agent_name not in agents:
            continue
        responded.add(agent_name)

        agent = agents[agent_name]
        color = get_agent_color(agent_name)
        display = agent["display_name"]
        a_key, a_base, a_model = get_agent_api(agent_name)
        api_msgs = group_to_api_msgs(group_name, agent_name)

        tag = "{}{}{}>".format(color, display, C.R)
        print("\n{} ".format(tag), end="", flush=True)
        t0 = time.time()
        reply = stream_api(api_msgs, lambda tok: sys.stdout.write(tok) or sys.stdout.flush(),
                           api_key=a_key, api_base=a_base, model=a_model)
        elapsed = time.time() - t0

        if not reply:
            print("{}(no response){}".format(C.RED, C.R))
            continue
        print("  {}({:.1f}s){}".format(C.D, elapsed, C.R))
        _print_tokens()
        history.append({"role": "assistant", "content": reply, "agent": agent_name})

        # Execute commands
        cmds = parse_commands(reply)
        if cmds:
            for c in cmds:
                print("\n  {}[{}] {}{}".format(C.YEL, c["type"], c.get("args", ""), C.R))
                result = execute_command(c)
                for line in result.split("\n")[:30]:
                    print("  {}| {}{}".format(C.D, C.GRN, line, C.R))
                print("  {}{}{}".format(C.D, "-" * 40, C.R))
                history.append({
                    "role": "user",
                    "content": "[{}:{}] -> {}".format(c["type"], c.get("args", ""), result),
                    "agent": "system",
                })

            # Continuation: let agent see command results and continue
            api_msgs2 = group_to_api_msgs(group_name, agent_name)
            print("\n{} ".format(tag), end="", flush=True)
            reply2 = stream_api(api_msgs2, lambda tok: sys.stdout.write(tok) or sys.stdout.flush(),
                                api_key=a_key, api_base=a_base, model=a_model)
            if reply2:
                print()
                _print_tokens()
                history.append({"role": "assistant", "content": reply2, "agent": agent_name})
                # Handle @mentions in continuation
                cont_mentions = extract_mentions(reply2)
                for m in cont_mentions:
                    if m in members and m not in responded:
                        pending.append(m)
                        print("  {}→ @{} summoned by @{}{}".format(C.D, m, agent_name, C.R))

        # Check for @mentions in original reply
        for m in extract_mentions(reply):
            if m in members and m not in responded:
                pending.append(m)
                print("  {}→ @{} summoned by @{}{}".format(C.D, m, agent_name, C.R))

        chain_depth += 1

    if len(history) > MAX_HISTORY * 3:
        group["history"] = history[-MAX_HISTORY * 3:]
    save_groups()


# ━━━ Slash Commands ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def cmd_help():
    loaded = config.get("skills", [])
    gw_status = "running port {}".format(gateway_port) if gateway_server else "stopped"
    print("""
{}  Claw Commands v0.6.1{}

  {}<text>{}              Send message (mode-aware)
  {}/key <key>{}          Set global API Key
  {}/base <url>{}         Set global API Base URL
  {}/model <name>{}       Set global Model
  {}/config{}             Show current config
  {}/usage{}              View token usage
  {}/clear{}              Clear conversation
  {}/history{}            Show message history

  {}/skill list|load|unload|clear{}
  {}  Loaded:{} {}

  {}/agent list{}                 List all agents
  {}/agent create <name>{}       Create agent (set name, role, API)
  {}/agent switch <name>{}       1-on-1 with agent
  {}/agent back{}                Return to default
  {}/agent info <name>{}         View agent details + API config
  {}/agent api <name>{}          View/set agent API (key, base, model)
  {}/agent api <n> model=gpt-4o{}    Set model only
  {}/agent api <n> api_key=sk-xxx{}  Set full API
  {}/agent api <n> api_key=clear{}   Reset to global
  {}/agent model <name> [model]{} Quick set model
  {}/agent prompt <name> [text]{} View/edit role
  {}/agent rename|delete|clear{}

  {}/group list{}                 List groups
  {}/group create <name>{}       Create group (choose members)
  {}/group enter <name>{}        Enter group chat
  {}/group leave{}               Exit group
  {}/group add|remove|info|delete|clear{}

  {}/gateway start|stop|status|restart{}  ({})
  {}/workspace{}  {}/help{}  {}exit{}

  {}Group: @name msg → target, @all → everyone, plain → first member{}
""".format(
        C.CYN, C.R,
        C.B, C.R, C.B, C.R, C.B, C.R, C.B, C.R, C.B, C.R, C.B, C.R, C.B, C.R,
        C.B, C.R, C.D, C.R, ", ".join(loaded) if loaded else "none",
        C.B, C.R, C.B, C.R, C.B, C.R, C.B, C.R, C.B, C.R, C.B, C.R, C.B, C.R,
        C.B, C.R, C.B, C.R, C.B, C.R, C.B, C.R, C.B, C.R, C.B, C.R, C.B, C.R,
        C.B, C.R, C.B, C.R, C.B, C.R, C.B, C.R, C.B, C.R, C.B, C.R, C.B, C.R,
        C.B, C.R, gw_status, C.B, C.R, C.B, C.R, C.D, C.R, C.D, C.R,
    ))


def cmd_config():
    print("\n  {}── Global Config ──{}".format(C.YEL, C.R))
    print("  {}Model:{}     {}".format(C.D, C.R, config["model"]))
    print("  {}API:{}       {}".format(C.D, C.R, config["api_base"]))
    key = config.get("api_key", "")
    if key:
        print("  {}Key:{}       {}{}{}".format(C.D, C.R, C.GRN, _mask_key(key), C.R))
    else:
        print("  {}Key:{}       {}not set{}".format(C.D, C.R, C.RED, C.R))
    loaded = config.get("skills", [])
    print("  {}Skills:{}    {}".format(C.D, C.R, ", ".join(loaded) if loaded else "none"))
    print()
    print("  {}── Active Agents ({}{}){}".format(C.YEL, C.R, len(agents), C.R))
    for name, a in agents.items():
        _, base, model = get_agent_api(name)
        color = get_agent_color(name)
        base_short = base.split("//")[-1].split("/")[0][:25]
        k_src = "own" if a.get("api_key") else "global"
        print("  {}  @{}{} → {} @ {}  (key: {})".format(C.D, name, C.R, model, base_short, k_src))
    print()
    print("  {}── Groups ({}{}){}".format(C.YEL, C.R, len(groups), C.R))
    for gname, g in groups.items():
        members = ", ".join("@{}".format(m) for m in g.get("members", []))
        print("  {}  {}{} [{}]".format(C.D, gname, C.R, members))
    mode_str = current_mode
    if current_target:
        mode_str += " → {}".format(current_target)
    print("\n  {}Mode:{}      {}".format(C.D, C.R, mode_str))
    gw = "port {}".format(gateway_port) if gateway_server else "stopped"
    print("  {}Gateway:{}   {}\n".format(C.D, C.R, gw))


def cmd_usage():
    u = token_usage
    print("\n  {}Token Usage{}".format(C.CYN, C.R))
    print("  {}{}{}".format(C.D, "-" * 40, C.R))
    print("  {}Last prompt:{}       {}".format(C.D, C.R, u["last_prompt"]))
    print("  {}Last completion:{}   {}".format(C.D, C.R, u["last_completion"]))
    print("  {}Last total:{}        {}".format(C.D, C.R, u["last_prompt"] + u["last_completion"]))
    print("  {}Cumulative prompt:{} {}".format(C.D, C.R, u["prompt_tokens"]))
    print("  {}Cumulative compl:{}  {}".format(C.D, C.R, u["completion_tokens"]))
    print("  {}Cumulative total:{}  {}".format(C.D, C.R, u["total_tokens"]))
    print("  {}API requests:{}      {}".format(C.D, C.R, u["requests"]))
    if u["requests"] > 0:
        print("  {}Avg per request:{}   {}".format(C.D, C.R, u["total_tokens"] // u["requests"]))
    print()


def cmd_workspace():
    WORKSPACE_FILE.parent.mkdir(parents=True, exist_ok=True)
    if WORKSPACE_FILE.exists():
        print("\n  {}Current:{}\n".format(C.D, C.R))
        for line in WORKSPACE_FILE.read_text("utf-8").split("\n")[:20]:
            print("    {}".format(line))
        print()
    if input("  {}Edit? (y/N): {}".format(C.YEL, C.R)).strip().lower() != "y":
        return
    lines = []
    while True:
        try:
            line = input("    ")
        except EOFError:
            break
        if line == "":
            break
        lines.append(line)
    WORKSPACE_FILE.write_text("\n".join(lines) + "\n", "utf-8")
    print("\n  {}Saved.{}\n".format(C.GRN, C.R))


# ━━━ Main ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def main():
    global current_mode, current_target

    SKILLS_DIR.mkdir(parents=True, exist_ok=True)
    load_agents()
    load_groups()

    try:
        if HISTORY_FILE.exists():
            readline.read_history_file(str(HISTORY_FILE))
        readline.set_history_length(500)
    except Exception:
        pass

    loaded = config.get("skills", [])

    print("""
{}  ╔══════════════════════════════════════════════════════════╗
  ║   CLAW  Terminal  v0.6.1  Multi-API Agents + Groups + GW ║
  ╚══════════════════════════════════════════════════════════╝{}
  {}Global Model:{}  {}
  {}Global API:{}    {}
  {}Global Key:{}    {}
  {}Skills:{}       {}
  {}Agents:{}       {}  |  {}Groups:{} {}
  {}/help for all commands{}
""".format(
        C.CYN, C.R,
        C.D, C.R, config["model"],
        C.D, C.R, config["api_base"],
        C.D, C.R, ("set" if config["api_key"] else C.RED + "not set" + C.R),
        C.D, C.R, ", ".join(loaded) if loaded else "none",
        C.D, C.R, len(agents), C.D, C.R, len(groups),
        C.D, C.R,
    ))

    if agents:
        print("  {}Registered agents:{}\n".format(C.D, C.R))
        for name, a in agents.items():
            color = get_agent_color(name)
            _, base, model = get_agent_api(name)
            base_short = base.split("//")[-1].split("/")[0][:20]
            k_src = "own key" if a.get("api_key") else "global key"
            print("    {}@{}{} {:<14} {} @ {}  ({})".format(
                color, name, C.R, a["display_name"], model, base_short, k_src))
        print()

    if not config["api_key"]:
        print("  {}!  No global API Key.  /key <key> to set.{}\n".format(C.YEL, C.R))

    while True:
        try:
            user = input(get_prompt()).strip()
        except (EOFError, KeyboardInterrupt):
            print("\n  {}Bye.{}".format(C.D, C.R))
            break
        if not user:
            continue

        # ── Slash commands ──
        if user == "/help":
            cmd_help()
            continue
        if user == "/config":
            cmd_config()
            continue
        if user == "/usage":
            cmd_usage()
            continue
        if user == "/clear":
            if current_mode == "agent" and current_target:
                agents[current_target]["history"] = []
                save_agents()
            elif current_mode == "group" and current_target:
                groups[current_target]["history"] = []
                save_groups()
            else:
                messages.clear()
            print("  {}Cleared.{}\n".format(C.D, C.R))
            continue
        if user == "/history":
            if current_mode == "agent" and current_target:
                hist = agents[current_target].get("history", [])
                label = agents[current_target]["display_name"]
            elif current_mode == "group" and current_target:
                hist = groups[current_target].get("history", [])
                label = current_target
            else:
                hist = messages
                label = "claw"
            if not hist:
                print("  {}(empty){}\n".format(C.D, C.R))
            else:
                for m in hist:
                    sender = m.get("agent", m["role"])
                    role = "you" if sender == "user" else agents.get(sender, {}).get("display_name", label) if sender in agents else label
                    color = C.BLU if sender == "user" else get_agent_color(sender) if sender in agents else C.CYN
                    content = m["content"][:100].replace("\n", " ")
                    print("  {}{}{}> {}{}{}".format(color, role, C.R, C.D, content, C.R))
            print()
            continue
        if user.startswith("/key "):
            config["api_key"] = user[5:].strip()
            save_config()
            print("  {}Key saved.{}\n".format(C.GRN, C.R))
            continue
        if user.startswith("/base "):
            config["api_base"] = user[6:].strip()
            save_config()
            print("  {}Saved.{}\n".format(C.GRN, C.R))
            continue
        if user.startswith("/model "):
            config["model"] = user[7:].strip()
            save_config()
            print("  {}Saved.{}\n".format(C.GRN, C.R))
            continue
        if user.startswith("/skill"):
            cmd_skill(user[6:].strip())
            continue
        if user.startswith("/agent"):
            cmd_agent(user[6:].strip())
            continue
        if user.startswith("/group"):
            cmd_group(user[6:].strip())
            continue
        if user.startswith("/gateway"):
            cmd_gateway(user[8:].strip())
            continue
        if user == "/workspace":
            cmd_workspace()
            continue
        if user.lower() in ("exit", "quit", "q"):
            if gateway_server:
                gateway_server.shutdown()
            print("  {}Bye.{}".format(C.D, C.R))
            break

        # ── Route to appropriate chat mode ──
        if current_mode == "agent" and current_target:
            chat_agent(user)
        elif current_mode == "group" and current_target:
            chat_group(user)
        else:
            chat(user)

        try:
            readline.write_history_file(str(HISTORY_FILE))
        except Exception:
            pass

        print()


if __name__ == "__main__":
    main()
