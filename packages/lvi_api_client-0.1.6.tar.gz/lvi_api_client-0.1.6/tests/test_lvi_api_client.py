"""Unit tests for LogicVeinAPIClient using mocks.

These tests use mocked responses and do not require a real LogicVein server.
"""

import base64
import json
from unittest.mock import Mock, patch

import pytest
import requests

from src.logicvein.lvi_api_client import LogicVeinAPIClient


class TestLogicVeinAPIClientUnit:
    """Unit tests for LogicVeinAPIClient using mocks."""

    @pytest.fixture
    def mock_env(self, monkeypatch):
        """Mock environment variables."""
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token-123")
        monkeypatch.setenv("LVI_USERNAME", "")
        monkeypatch.setenv("LVI_PASSWORD", "")
        monkeypatch.setenv("LVI_VERIFY_SSL", "false")

    @pytest.fixture
    def client(self, mock_env):
        """Create a LogicVeinAPIClient instance with mocked session."""
        with patch("src.logicvein.lvi_api_client.requests.Session") as mock_session_class:
            mock_session = Mock()
            mock_session.headers = {}
            mock_session.verify = False
            mock_session_class.return_value = mock_session

            client = LogicVeinAPIClient()
            return client

    def test_initialization_with_api_token(self, mock_env):
        """Test client initialization with API token."""
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            client = LogicVeinAPIClient()

            assert client.host == "test.example.com"
            assert client.api_token == "test-token-123"
            assert client.base_url == "https://test.example.com/rest"
            assert "Authorization" in client.headers
            assert client.headers["Authorization"] == "Bearer test-token-123"

    def test_initialization_with_kwargs(self, monkeypatch):
        """Test client initialization with kwargs instead of env vars."""
        # Clear env vars so kwargs take precedence
        monkeypatch.delenv("LVI_HOST", raising=False)
        monkeypatch.delenv("LVI_API_TOKEN", raising=False)
        monkeypatch.delenv("LVI_VERIFY_SSL", raising=False)

        with patch("src.logicvein.lvi_api_client.requests.Session"):
            client = LogicVeinAPIClient(host="custom.host.com", api_token="custom-token", verify=True)

            assert client.host == "custom.host.com"
            assert client.api_token == "custom-token"
            assert client.verify_ssl is True

    def test_initialization_with_username_password(self, monkeypatch):
        """Test client initialization with username/password triggers authentication."""
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "")
        monkeypatch.setenv("LVI_USERNAME", "testuser")
        monkeypatch.setenv("LVI_PASSWORD", "testpass")

        with patch("src.logicvein.lvi_api_client.requests.Session") as mock_session_class:
            mock_session = Mock()
            mock_session.headers = {}
            mock_session.get.return_value = Mock(status_code=200)
            mock_session_class.return_value = mock_session

            client = LogicVeinAPIClient()

            # Verify authenticate was called
            assert client is not None
            mock_session.get.assert_called_once()

    def test_next_id_generates_unique_ids(self, client):
        """Test that _next_id generates unique request IDs."""
        id1 = client._next_id()
        id2 = client._next_id()
        id3 = client._next_id()

        assert id1 != id2
        assert id2 != id3
        assert id1 != id3

    def test_call_method_success(self, client, mock_response):
        """Test successful JSON-RPC call."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"data": "success"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.call("Test.method", param1="value1")

        assert result["result"]["data"] == "success"
        client.lvi_client.post.assert_called_once()

        # Verify the payload structure
        call_args = client.lvi_client.post.call_args
        assert call_args[0][0] == client.base_url

    def test_call_method_http_error(self, client):
        """Test JSON-RPC call with HTTP error."""
        mock_response = Mock()
        mock_response.raise_for_status.side_effect = requests.HTTPError("500 Server Error")
        client.lvi_client.post = Mock(return_value=mock_response)

        with pytest.raises(requests.HTTPError):
            client.call("Test.method")

    def test_get_networks_success(self, client, mock_networks_response):
        """Test get_networks returns list of networks."""
        client.lvi_client.post = Mock(return_value=mock_networks_response)

        networks = client.get_networks()

        assert isinstance(networks, list)
        assert len(networks) == 3
        assert "Default" in networks
        assert "Production" in networks

    def test_get_networks_empty_result(self, client, mock_response):
        """Test get_networks with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test", "result": []}
        client.lvi_client.post = Mock(return_value=mock_response)

        networks = client.get_networks()

        assert networks == []

    def test_search_devices_in_network(self, client, mock_devices_response):
        """Test search_devices_in_network returns device list."""
        client.lvi_client.post = Mock(return_value=mock_devices_response)

        devices = client.search_devices_in_network(network=["Default"], page_size=10)

        assert isinstance(devices, list)
        assert len(devices) == 2
        assert devices[0]["ipAddress"] == "192.168.1.1"
        assert devices[1]["ipAddress"] == "192.168.1.2"

    def test_get_device_by_ip_success(self, client, mock_device_response):
        """Test get_device_by_ip returns device details."""
        client.lvi_client.post = Mock(return_value=mock_device_response)

        device = client.get_device_by_ip("192.168.1.1", "Default")

        assert device is not None
        assert device["ipAddress"] == "192.168.1.1"
        assert device["deviceName"] == "router-01"
        assert device["vendor"] == "Cisco"

    def test_get_device_by_ip_not_found(self, client, mock_response):
        """Test get_device_by_ip when device doesn't exist."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        device = client.get_device_by_ip("192.168.99.99", "Default")

        assert device is None

    def test_search_devices_in_network_empty(self, client, mock_response):
        """Test search_devices_in_network with empty results."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"devices": []}}
        client.lvi_client.post = Mock(return_value=mock_response)

        devices = client.search_devices_in_network()

        assert isinstance(devices, list)
        assert len(devices) == 0

    def test_get_users_success(self, client, mock_users_response):
        """Test get_users returns user list."""
        client.lvi_client.post = Mock(return_value=mock_users_response)

        result = client.get_users()

        assert isinstance(result, dict)
        assert "users" in result
        assert len(result["users"]) == 2
        assert result["users"][0]["username"] == "admin"

    def test_get_available_roles_success(self, client, mock_response):
        """Test get_available_roles returns role list."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": ["Administrator", "Operator", "Viewer"],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        roles = client.get_available_roles()

        assert isinstance(roles, list)
        assert len(roles) == 3
        assert "Administrator" in roles

    def test_create_user(self, client, mock_response):
        """create_user uses Security.createUser with flat params and returns True on null result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.create_user(
            username="newuser",
            full_name="New User",
            email="new@example.com",
            password="password123",
            role_name="Operator",
        )

        assert result is True
        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert body["method"] == "Security.createUser"
        assert body["params"]["username"] == "newuser"
        assert body["params"]["fullName"] == "New User"
        assert body["params"]["role"] == "Operator"
        assert "user" not in body["params"]

    def test_delete_user(self, client, mock_response):
        """delete_user uses username string param, not userId int."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.delete_user("ansible-user")

        assert result is True
        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert body["method"] == "Security.deleteUser"
        assert body["params"]["username"] == "ansible-user"
        assert "userId" not in body["params"]

    def test_search_incidents(self, client, mock_response):
        """Test search_incidents method."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {
                "incidents": [
                    {"incidentId": "INC-001", "severity": "CRITICAL", "status": "OPEN", "summary": "Device down"}
                ]
            },
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        incidents = client.search_incidents(page_size=10)

        assert isinstance(incidents, list)
        assert len(incidents) == 1
        assert incidents[0]["incidentId"] == "INC-001"

    def test_authenticate_success(self, client, mock_successful_auth_response):
        """Test successful authentication."""
        client.lvi_client.get = Mock(return_value=mock_successful_auth_response)

        response = client.authenticate(username="testuser", password="testpass")

        assert response is not None
        assert response.status_code == 200
        client.lvi_client.get.assert_called_once()

    def test_authenticate_failure(self, client):
        """Test failed authentication."""
        mock_response = Mock()
        mock_response.raise_for_status.side_effect = requests.HTTPError("401 Unauthorized")
        client.lvi_client.get = Mock(return_value=mock_response)

        response = client.authenticate(username="baduser", password="badpass")

        assert response is None

    def test_authenticate_missing_credentials(self, client):
        """Test authentication with missing credentials."""
        with pytest.raises(ValueError, match="Username and password are required"):
            client.authenticate(username=None, password=None)

    def test_call_returns_text_on_json_decode_error(self, client):
        """Test call method handles JSON decode errors."""
        mock_response = Mock()
        mock_response.json.side_effect = ValueError("Invalid JSON")
        mock_response.text = "Error response text"
        mock_response.raise_for_status = Mock()
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.call("Test.method")

        assert result == "Error response text"


class TestBridgeMethods:
    """Test bridge-related methods."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_define_bridge(self, client, mock_response):
        """Test defining a new bridge."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.define_bridge("Bridge1", "bridge.example.com", 443, "admin", "pass")

        assert result is True

    def test_get_all_bridges(self, client, mock_response):
        """Test retrieving all bridges."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": [{"bridgeId": "1", "bridgeName": "Bridge1"}],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        bridges = client.get_all_bridges()

        assert isinstance(bridges, list)
        assert len(bridges) == 1

    def test_delete_bridge(self, client, mock_response):
        """Test deleting a bridge."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.delete_bridge("1")

        assert result is True


class TestAdditionalComplianceMethods:
    """Test additional compliance methods."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_get_rule_set(self, client, mock_response):
        """Test retrieving a specific rule set."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {"ruleSetId": 1, "name": "Security Rules"},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        rule_set = client.get_rule_set(1)

        assert isinstance(rule_set, dict)
        assert rule_set["name"] == "Security Rules"

    def test_create_rule_set_success(self, client, mock_response):
        """Returns True when server responds with result: null (success)."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.create_rule_set(rule_set_name="New Rules", adapter_id="Cisco::IOS")

        assert result is True

    def test_create_rule_set_failure(self, client, mock_response):
        """Returns False when server response indicates failure."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"error": "failed"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.create_rule_set(rule_set_name="New Rules", adapter_id="Cisco::IOS")

        assert result is False

    def test_create_rule_set_wrapped_in_rule_set_key(self, client, mock_response):
        """Request params must be wrapped as ruleSet={...}, not spread as keyword args."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        client.create_rule_set(rule_set_name="New Rules", adapter_id="Cisco::IOS")

        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert "ruleSet" in body["params"]
        assert "ruleSetName" not in body["params"]

    def test_create_rule_set_defaults(self, client, mock_response):
        """categoryId and remediationJobId default to null; networks defaults to ['*'] (all networks)."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        client.create_rule_set(rule_set_name="New Rules", adapter_id="Cisco::IOS")

        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        rule_set = body["params"]["ruleSet"]
        assert rule_set["categoryId"] is None
        assert rule_set["remediationJobId"] is None
        assert rule_set["networks"] == ["*"]

    def test_create_rule_set_default_xml_skeleton_when_empty(self, client, mock_response):
        """A minimal XML skeleton is generated when rule_set_xml is not provided."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        client.create_rule_set(rule_set_name="My Rules", adapter_id="Cisco::IOS")

        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        xml = body["params"]["ruleSet"]["ruleSetXml"]
        assert xml and xml.startswith("<?xml")
        assert "RuleSet" in xml

    def test_create_rule_set_explicit_xml_not_overridden(self, client, mock_response):
        """A caller-supplied rule_set_xml is passed through unchanged."""
        custom_xml = '<?xml version="1.0"?><RuleSet name="x"><Rule/></RuleSet>'
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        client.create_rule_set(rule_set_name="My Rules", adapter_id="Cisco::IOS", rule_set_xml=custom_xml)

        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert body["params"]["ruleSet"]["ruleSetXml"] == custom_xml

    def test_create_rule_set_explicit_values_passed_through(self, client, mock_response):
        """Explicit categoryId, remediationJobId, and networks are forwarded correctly."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        client.create_rule_set(
            rule_set_name="My Rules",
            adapter_id="Cisco::IOS",
            category_id="42",
            remediation_job_id="99",
            networks=["Default", "Prod"],
        )

        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        rule_set = body["params"]["ruleSet"]
        assert rule_set["categoryId"] == "42"
        assert rule_set["remediationJobId"] == "99"
        assert rule_set["networks"] == ["Default", "Prod"]

    def test_delete_rule_set(self, client, mock_response):
        """Test deleting a rule set — uses plural method name and wraps id in a list."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.delete_rule_set(1)

        assert result is True
        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert body["method"] == "Compliance.deleteRuleSets"
        assert body["params"]["ruleSetIds"] == [1]

    def test_get_policy(self, client, mock_response):
        """Test retrieving a specific policy."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {"policyId": 1, "name": "Security Policy"},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        policy = client.get_policy(1)

        assert isinstance(policy, dict)
        assert policy["name"] == "Security Policy"

    def test_create_policy(self, client, mock_response):
        """create_policy wraps params in policy={...} and returns the saved policy dict."""
        saved = {"policyId": 1, "policyName": "New Policy", "adapterId": "Cisco::IOS", "enabled": False}
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": saved}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.create_policy(policy_name="New Policy", adapter_id="Cisco::IOS", rule_set_mappings=[])

        assert result == saved
        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert body["method"] == "Compliance.savePolicy"
        assert "policy" in body["params"]
        assert "policyName" not in body["params"]

    def test_create_policy_with_policy_id(self, client, mock_response):
        """policy_id is included in the payload when provided (update case)."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"policyId": 5}}
        client.lvi_client.post = Mock(return_value=mock_response)

        client.create_policy(policy_name="test", adapter_id="Cisco::IOS", rule_set_mappings=[], policy_id=5)

        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert body["params"]["policy"]["policyId"] == 5

    def test_create_policy_without_policy_id(self, client, mock_response):
        """policyId is absent from the payload when not provided (create case)."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"policyId": 1}}
        client.lvi_client.post = Mock(return_value=mock_response)

        client.create_policy(policy_name="test", adapter_id="Cisco::IOS", rule_set_mappings=[])

        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert "policyId" not in body["params"]["policy"]

    def test_create_policy_returns_none_on_failure(self, client, mock_response):
        """Returns None when the API response has no result key."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.create_policy(policy_name="test", adapter_id="Cisco::IOS", rule_set_mappings=[])

        assert result is None

    def test_enable_policy(self, client, mock_response):
        """enable_policy uses plural method name and wraps id in a list."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.enable_policy(1)

        assert result is True
        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert body["method"] == "Compliance.setPoliciesEnablement"
        assert body["params"]["policyIds"] == [1]
        assert body["params"]["enabled"] is True

    def test_disable_policy(self, client, mock_response):
        """disable_policy uses plural method name and wraps id in a list."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.disable_policy(1)

        assert result is True
        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert body["method"] == "Compliance.setPoliciesEnablement"
        assert body["params"]["policyIds"] == [1]
        assert body["params"]["enabled"] is False

    def test_delete_policy(self, client, mock_response):
        """delete_policy uses plural method name and wraps id in a list."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.delete_policy(1)

        assert result is True
        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert body["method"] == "Compliance.deletePolicies"
        assert body["params"]["policyIds"] == [1]

    def test_get_rule_set_categories(self, client, mock_response):
        """Test retrieving rule set categories."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": [{"categoryId": 1, "categoryName": "Security"}],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        categories = client.get_rule_set_categories()

        assert isinstance(categories, list)
        assert len(categories) == 1

    def test_get_category_id_from_name(self, client, mock_response):
        """Test getting category ID from name."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": [{"categoryId": 1, "categoryName": "Security"}],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        category_id = client.get_category_id_from_name("Security")

        assert category_id == 1

    def test_get_category_id_from_name_not_found(self, client, mock_response):
        """Test getting category ID when name doesn't exist."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": [{"categoryId": 1, "categoryName": "Security"}],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        category_id = client.get_category_id_from_name("NonExistent")

        assert category_id is None

    def test_create_rule_set_category(self, client, mock_response):
        """Test creating a rule set category."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": [{"categoryId": 1}]}
        client.lvi_client.post = Mock(return_value=mock_response)

        category_id = client.create_rule_set_category("New Category", "Description")

        assert category_id == 1

    def test_get_compliance_violations_for_policy(self, client, mock_response):
        """Test retrieving compliance violations for a policy."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": [{"violationId": 1, "severity": "HIGH"}],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        violations = client.get_compliance_violations_for_policy(1)

        assert isinstance(violations, list)
        assert len(violations) == 1

    def test_evaluate_compliance_rule_sets(self, client, mock_response):
        """Test evaluating compliance rule sets."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": [{"ruleSetId": 1, "passed": True}],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        results = client.evaluate_compliance_rule_sets([1], "192.168.1.1")

        assert isinstance(results, list)
        assert len(results) == 1


class TestIncidentMethods:
    """Test incident-related methods."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_get_incident_by_id(self, client, mock_response):
        """Test retrieving an incident by ID."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {"incidentId": 1, "severity": "HIGH"},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        incident = client.get_incident_by_id(1)

        assert isinstance(incident, dict)
        assert incident["severity"] == "HIGH"


class TestAdditionalCredentialMethods:
    """Test additional credential methods."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_get_credential_config(self, client, mock_response):
        """Test retrieving a specific credential config."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"name": "Config1"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        config = client.get_credential_config("Config1")

        assert isinstance(config, dict)
        assert config["name"] == "Config1"

    def test_get_credential_sets(self, client, mock_response):
        """Test retrieving credential sets."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {"credentialSets": [{"name": "Set1"}]},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        sets = client.get_credential_sets("Config1")

        assert isinstance(sets, list)
        assert len(sets) == 1

    def test_save_credential_sets(self, client, mock_response):
        """Test saving credential sets."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.save_credential_sets("Config1", [{"name": "Set1"}])

        assert result is True

    def test_delete_credential_sets(self, client, mock_response):
        """Test deleting credential sets."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.delete_credential_sets("Config1", [1, 2])

        assert result is True

    def test_commit_credential_edits(self, client, mock_response):
        """Test committing credential edits."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.commit_credential_edits()

        assert result is True

    def test_discard_credential_edits(self, client, mock_response):
        """Test discarding credential edits."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.discard_credential_edits()

        assert result is True

    def test_get_last_successful_credential_mapping(self, client, mock_response):
        """Test retrieving last successful credential mapping."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"credentialSetId": 1}}
        client.lvi_client.post = Mock(return_value=mock_response)

        mapping = client.get_last_successful_credential_mapping("192.168.1.1")

        assert mapping is not None
        assert mapping["credentialSetId"] == 1


class TestAdditionalDeviceMethods:
    """Test additional device methods."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_update_devices(self, client, mock_response):
        """Test updating multiple devices."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.update_devices([{"ipAddress": "192.168.1.1"}])

        assert result is True

    def test_update_device_hardware(self, client, mock_response):
        """Test updating device hardware info."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.update_device_hardware("192.168.1.1", serial_number="SN123")

        assert result is True

    def test_update_end_of_dates(self, client, mock_response):
        """Test updating end-of-life dates."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.update_end_of_dates("192.168.1.1", end_of_life=1234567890)

        assert result is True

    def test_get_device_vlan_port_mappings(self, client, mock_response):
        """Test retrieving VLAN port mappings."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": [{"vlan": 10, "port": "Gi0/1"}]}
        client.lvi_client.post = Mock(return_value=mock_response)

        mappings = client.get_device_vlan_port_mappings("192.168.1.1")

        assert isinstance(mappings, list)
        assert len(mappings) == 1

    def test_get_device_hardware(self, client, mock_response):
        """Test retrieving device hardware info."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": [{"serialNumber": "SN123"}]}
        client.lvi_client.post = Mock(return_value=mock_response)

        hardware = client.get_device_hardware("192.168.1.1")

        assert isinstance(hardware, list)
        assert len(hardware) == 1


class TestAdditionalTelemetryMethods:
    """Test additional telemetry methods."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_get_arp_entries(self, client, mock_response):
        """Test retrieving ARP entries for network address."""
        # Mock get_networks
        networks_response = Mock()
        networks_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": ["Default"]}
        networks_response.raise_for_status = Mock()

        # Mock get_arp_entries
        arp_response = Mock()
        arp_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {"arpEntries": [{"ipAddress": "192.168.1.10"}]},
        }
        arp_response.raise_for_status = Mock()

        client.lvi_client.post = Mock(side_effect=[networks_response, arp_response])

        entries = client.get_arp_entries("192.168.1.0/24")

        assert isinstance(entries, list)
        assert len(entries) == 1

    def test_find_switch_port_for_host(self, client, mock_response):
        """Test finding switch port for a host."""
        # Mock get_networks
        networks_response = Mock()
        networks_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": ["Default"]}
        networks_response.raise_for_status = Mock()

        # Mock find_switch_port
        port_response = Mock()
        port_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {"switchIp": "192.168.1.1", "port": "Gi0/1"},
        }
        port_response.raise_for_status = Mock()

        client.lvi_client.post = Mock(side_effect=[networks_response, port_response])

        port_info = client.find_switch_port_for_host("192.168.1.10")

        assert isinstance(port_info, dict)
        assert port_info["switchIp"] == "192.168.1.1"


class TestAdditionalJobMethods:
    """Test additional job methods."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_save_job(self, client, mock_response):
        """Test saving a job."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"jobId": 123}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.save_job({"jobName": "Test Job"})

        assert result is not None
        assert result["jobId"] == 123

    def test_get_job(self, client, mock_response):
        """Test retrieving a job."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {"jobId": 123, "jobName": "Test Job"},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        job = client.get_job(123)

        assert job is not None
        assert job["jobName"] == "Test Job"

    def test_run_existing_job_now(self, client, mock_response):
        """Test running an existing job."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"executionId": "exec-123"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.run_existing_job_now(123)

        assert result is not None
        assert result["executionId"] == "exec-123"

    def test_search_job_executions(self, client, mock_response):
        """Test searching job executions."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {"executionData": [{"executionId": "exec-123"}]},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        executions = client.search_job_executions()

        assert isinstance(executions, list)
        assert len(executions) == 1


class TestAdditionalNetworkMethods:
    """Test additional managed network methods."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_get_all_managed_networks(self, client, mock_response):
        """Test retrieving all managed networks."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": [{"name": "Default"}, {"name": "Production"}],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        networks = client.get_all_managed_networks()

        assert isinstance(networks, list)
        assert len(networks) == 2

    def test_update_managed_network(self, client, mock_response):
        """Test updating a managed network."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.update_managed_network("Default", new_name="Production")

        assert result is True


class TestConfigurationMethods:
    """Test configuration-related methods."""

    @pytest.fixture
    def client(self, monkeypatch):
        """Create a test client."""
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_get_device_configuration_change_logs(self, client, mock_response):
        """Test retrieving device configuration change logs."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {
                "changeLogs": [
                    {"timestamp": 1234567890, "user": "admin", "message": "Config updated"},
                    {"timestamp": 1234567891, "user": "operator", "message": "Config modified"},
                ]
            },
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        logs = client.get_device_configuration_change_logs("192.168.1.1", "Default")

        assert isinstance(logs, list)
        assert len(logs) == 2
        assert logs[0]["user"] == "admin"

    def test_get_device_configuration_revision(self, client, mock_response):
        """Test retrieving device configuration revision."""
        config_content = "hostname router-01\ninterface GigabitEthernet0/0\n"
        encoded = base64.b64encode(config_content.encode()).decode()

        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"content": encoded}}
        client.lvi_client.post = Mock(return_value=mock_response)

        config = client.get_device_configuration_revision("192.168.1.1")

        assert config == config_content


class TestInterfaceMethods:
    """Test interface-related methods."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_get_device_interfaces(self, client, mock_response):
        """Test retrieving device interfaces."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": [
                {"name": "GigabitEthernet0/0", "status": "up"},
                {"name": "GigabitEthernet0/1", "status": "down"},
            ],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        interfaces = client.get_device_interfaces("192.168.1.1")

        assert isinstance(interfaces, list)
        assert len(interfaces) == 2
        assert interfaces[0]["name"] == "GigabitEthernet0/0"

    def test_search_device_interfaces(self, client, mock_response):
        """Test searching device interfaces."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {"interfaces": [{"name": "Gi0/0", "ipAddress": "192.168.1.1"}]},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        interfaces = client.search_device_interfaces(network="Default")

        assert isinstance(interfaces, list)
        assert len(interfaces) == 1


class TestTelemetryMethods:
    """Test telemetry-related methods."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_get_device_arp_table(self, client, mock_response):
        """Test retrieving device ARP table."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {"arpEntries": [{"ipAddress": "192.168.1.10", "macAddress": "00:11:22:33:44:55"}]},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        arp_table = client.get_device_arp_table("192.168.1.1")

        assert isinstance(arp_table, list)
        assert len(arp_table) == 1
        assert arp_table[0]["ipAddress"] == "192.168.1.10"

    def test_get_device_mac_table(self, client, mock_response):
        """Test retrieving device MAC table."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {"macEntries": [{"macAddress": "00:11:22:33:44:55", "port": "Gi0/1", "vlan": 10}]},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        mac_table = client.get_device_mac_table("192.168.1.1")

        assert isinstance(mac_table, list)
        assert len(mac_table) == 1
        assert mac_table[0]["port"] == "Gi0/1"

    def test_get_device_neighbors(self, client, mock_response):
        """Test retrieving device neighbors."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": [{"deviceId": "switch-01", "port": "Gi0/1"}],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        neighbors = client.get_device_neighbors("192.168.1.1")

        assert isinstance(neighbors, list)
        assert len(neighbors) == 1


class TestComplianceMethods:
    """Test compliance-related methods."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_get_all_rule_sets(self, client, mock_response):
        """Test retrieving all rule sets."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": [{"ruleSetId": 1, "name": "Security Rules"}, {"ruleSetId": 2, "name": "Config Standards"}],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        rule_sets = client.get_all_rule_sets(networks=["Default"])

        assert isinstance(rule_sets, list)
        assert len(rule_sets) == 2
        assert rule_sets[0]["name"] == "Security Rules"

    def test_get_all_policies(self, client, mock_response):
        """Test retrieving all policies."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": [{"policyId": 1, "name": "Security Policy"}],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        policies = client.get_all_policies()

        assert isinstance(policies, list)
        assert len(policies) == 1

    def test_get_compliance_summary(self, client, mock_response):
        """Test retrieving compliance summary."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {"totalDevices": 100, "compliant": 80, "nonCompliant": 20},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        summary = client.get_compliance_summary()

        assert isinstance(summary, dict)
        assert summary["totalDevices"] == 100

    def test_get_compliance_violations_for_device(self, client, mock_response):
        """Test retrieving compliance violations for a device."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": [{"violationId": 1, "policyId": 1, "severity": "HIGH"}],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        violations = client.get_compliance_violations_for_device("192.168.1.1")

        assert isinstance(violations, list)
        assert len(violations) == 1


class TestCredentialMethods:
    """Test credential-related methods."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_get_all_credential_configs(self, client, mock_response):
        """Test retrieving all credential configs."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": [{"name": "Default Creds", "addressSet": {"addresses": ["192.168.1.0/24"]}}],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        configs = client.get_all_credential_configs()

        assert isinstance(configs, list)
        assert len(configs) == 1

    def test_save_credential_config(self, client, mock_response):
        """Test saving a credential config."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"name": "Test Config"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.save_credential_config(config_name="Test Config", addresses=["192.168.1.0/24"])

        assert result is not None
        assert result["name"] == "Test Config"

    def test_delete_credential_config(self, client, mock_response):
        """Test deleting a credential config."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.delete_credential_config("Test Config")

        assert result is True


class TestPlaybookMethods:
    """Test playbook-related methods."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_get_playbooks(self, client, mock_response):
        """Test retrieving playbooks."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {"data": [{"scriptId": "1", "name": "Backup Playbook"}]},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        playbooks = client.get_playbooks()

        assert isinstance(playbooks, list)
        assert len(playbooks) == 1

    def test_run_playbook(self, client, mock_response):
        """Test running a playbook."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {"status": "running", "executionId": "123"},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.run_playbook("playbook-1")

        assert result is not None
        assert result["status"] == "running"


class TestNetworkManagementMethods:
    """Test managed network methods."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_define_managed_network(self, client, mock_response):
        """Test defining a new managed network."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.define_managed_network("Production")

        assert result is True

    def test_get_managed_network(self, client, mock_response):
        """Test retrieving a managed network."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {"name": "Production", "online": True},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        network = client.get_managed_network("Production")

        assert network is not None
        assert network["name"] == "Production"

    def test_delete_managed_network(self, client, mock_response):
        """Test deleting a managed network."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.delete_managed_network("Test Network")

        assert result is True


class TestJobSchedulerMethods:
    """Test job scheduler methods."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_search_jobs(self, client, mock_response):
        """Test searching for jobs."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {"jobData": [{"jobId": 1, "jobName": "Daily Backup"}]},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        jobs = client.search_jobs()

        assert isinstance(jobs, list)
        assert len(jobs) == 1

    def test_run_job_now(self, client, mock_response):
        """Test running a job immediately."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"executionId": "exec-123"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.run_job_now(
            job_name="Backup", job_type="Backup", managed_networks=["Default"], job_parameters={}
        )

        assert result is not None
        assert "executionId" in result

    def test_delete_job(self, client, mock_response):
        """Test deleting a job."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.delete_job(123)

        assert result is True


class TestDeviceUpdateMethods:
    """Test device update methods."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_update_device(self, client, mock_response):
        """Test updating a device."""
        # Mock get_device_by_ip
        get_response = Mock()
        get_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {"ipAddress": "192.168.1.1", "hostname": "old-name"},
        }

        # Mock update call
        update_response = Mock()
        update_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {"ipAddress": "192.168.1.1", "hostname": "new-name"},
        }
        update_response.raise_for_status = Mock()

        client.lvi_client.post = Mock(side_effect=[get_response, update_response])

        result = client.update_device("192.168.1.1", hostname="new-name")

        assert result is not None
        assert result["hostname"] == "new-name"

    def test_update_custom_fields(self, client, mock_response):
        """Test updating custom fields."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.update_custom_fields("192.168.1.1", custom_fields={"custom1": "value1"})

        assert result is True

    def test_create_device(self, client, mock_response):
        """Test creating a device."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"ipAddress": "192.168.1.1"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.create_device("192.168.1.1", "adapter-1")

        assert result is not None

    def test_delete_device(self, client, mock_response):
        """Test deleting a device."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.delete_device("192.168.1.1")

        assert result is not None


class TestAuthenticationEdgeCases:
    """Test authentication edge cases."""

    def test_authentication_timeout(self, monkeypatch):
        """Test authentication with connection timeout."""
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_USERNAME", "admin")
        monkeypatch.setenv("LVI_PASSWORD", "password")

        with patch("src.logicvein.lvi_api_client.requests.Session") as mock_session:
            mock_client = Mock()
            mock_client.get = Mock(side_effect=requests.exceptions.ConnectTimeout("Timeout"))
            mock_session.return_value = mock_client

            client = LogicVeinAPIClient()
            result = client.authenticate()

            assert result is None

    def test_initialization_without_token_triggers_auth(self, monkeypatch):
        """Test that initialization without API token triggers authentication."""
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_USERNAME", "admin")
        monkeypatch.setenv("LVI_PASSWORD", "password")
        monkeypatch.delenv("LVI_API_TOKEN", raising=False)

        with patch("src.logicvein.lvi_api_client.requests.Session") as mock_session:
            mock_client = Mock()
            mock_response = Mock()
            mock_response.raise_for_status = Mock()
            mock_client.get = Mock(return_value=mock_response)
            mock_session.return_value = mock_client

            client = LogicVeinAPIClient()

            # Verify authentication was called
            assert client is not None
            mock_client.get.assert_called_once()


class TestEmptyAndNoneResponses:
    """Test handling of empty and None responses."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_get_networks_no_result_key(self, client, mock_response):
        """Test get_networks when response has no result key."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        networks = client.get_networks()

        assert networks == []

    def test_get_all_groups_success(self, client, mock_response):
        """get_all_groups returns the list of group dicts from result."""
        groups = [
            {"deviceGroupId": "abc", "name": "Routing", "shared": True},
            {"deviceGroupId": "def", "name": "Switching", "shared": True},
        ]
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": groups}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_all_groups(networks=["Default"])

        assert result == groups
        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert body["method"] == "DeviceGroup.getAllGroups"
        assert body["params"]["network"] == ["Default"]

    def test_get_all_groups_default_network(self, client, mock_response):
        """get_all_groups defaults to ['Default'] when networks is not provided."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": []}
        client.lvi_client.post = Mock(return_value=mock_response)

        client.get_all_groups()

        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert body["params"]["network"] == ["Default"]

    def test_get_all_groups_no_result_key(self, client, mock_response):
        """get_all_groups returns [] when response has no result key."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_all_groups()

        assert result == []

    def test_get_jobs_success(self, client, mock_response):
        """get_jobs returns list of job dicts from result.jobData."""
        job = {"jobId": 4, "jobName": "1. Discover Network", "jobType": "Discover Devices"}
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {"offset": 0, "pageSize": 100, "total": 1, "jobData": [job]},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.search_jobs_with_queries()

        import json

        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert body["method"] == "Scheduler.searchJobsWithQueries"
        assert body["params"]["networks"] == ["Default"]
        assert body["params"]["queries"] == []
        assert result == [job]

    def test_get_jobs_default_network(self, client, mock_response):
        """get_jobs defaults to ['Default'] when networks is not provided."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {"offset": 0, "pageSize": 100, "total": 0, "jobData": []},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        client.search_jobs_with_queries()

        import json

        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert body["params"]["networks"] == ["Default"]

    def test_get_jobs_no_result_key(self, client, mock_response):
        """get_jobs returns [] when response has no result key."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.search_jobs_with_queries()

        assert result == []

    def test_get_jobs_paginates(self, client):
        """get_jobs fetches second page when first page is full."""
        page1_jobs = [{"jobId": i, "jobName": f"job{i}"} for i in range(2)]
        page2_jobs = [{"jobId": 10, "jobName": "job10"}]

        call_count = 0

        def side_effect(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            mock = Mock()
            mock.status_code = 200
            if call_count == 1:
                mock.json.return_value = {
                    "jsonrpc": "2.0",
                    "id": "t",
                    "result": {"offset": 0, "pageSize": 2, "total": 3, "jobData": page1_jobs},
                }
            else:
                mock.json.return_value = {
                    "jsonrpc": "2.0",
                    "id": "t",
                    "result": {"offset": 2, "pageSize": 2, "total": 3, "jobData": page2_jobs},
                }
            return mock

        client.lvi_client.post = Mock(side_effect=side_effect)

        result = client.search_jobs_with_queries(page_size=2)

        assert call_count == 2
        assert result == page1_jobs + page2_jobs

    def test_search_devices_no_devices_key(self, client, mock_response):
        """Test search_devices when response has no devices key."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {}}
        client.lvi_client.post = Mock(return_value=mock_response)

        devices = client.search_devices_in_network()

        assert devices == []

    def test_get_device_by_ip_no_result(self, client, mock_response):
        """Test get_device_by_ip when device not found."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        device = client.get_device_by_ip("192.168.1.1")

        assert device is None

    def test_get_device_configuration_change_logs_empty(self, client, mock_response):
        """Test get_device_configuration_change_logs with empty IP."""
        logs = client.get_device_configuration_change_logs("")

        assert logs == []

    def test_get_device_configuration_revision_empty_ip(self, client, mock_response):
        """Test get_device_configuration_revision with empty IP."""
        config = client.get_device_configuration_revision("")

        assert config == ""

    def test_get_device_configuration_revision_no_content(self, client, mock_response):
        """Test get_device_configuration_revision when no content in response."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {}}
        client.lvi_client.post = Mock(return_value=mock_response)

        config = client.get_device_configuration_revision("192.168.1.1")

        assert config == ""

    def test_get_device_configuration_revision_null_result(self, client, mock_response):
        """Test get_device_configuration_revision when result is None."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        config = client.get_device_configuration_revision("192.168.1.1")

        assert config == ""

    def test_get_device_interfaces_empty_result(self, client, mock_response):
        """Test get_device_interfaces with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        interfaces = client.get_device_interfaces("192.168.1.1")

        assert interfaces == []

    def test_get_device_vlan_port_mappings_empty(self, client, mock_response):
        """Test get_device_vlan_port_mappings with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        mappings = client.get_device_vlan_port_mappings("192.168.1.1")

        assert mappings == []

    def test_search_device_interfaces_empty(self, client, mock_response):
        """Test search_device_interfaces with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {}}
        client.lvi_client.post = Mock(return_value=mock_response)

        interfaces = client.search_device_interfaces()

        assert interfaces == []

    def test_get_device_hardware_empty(self, client, mock_response):
        """Test get_device_hardware with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        hardware = client.get_device_hardware("192.168.1.1")

        assert hardware == []


class TestTelemetryEdgeCases:
    """Test telemetry methods edge cases."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_get_device_arp_table_empty(self, client, mock_response):
        """Test get_device_arp_table with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {}}
        client.lvi_client.post = Mock(return_value=mock_response)

        arp_table = client.get_device_arp_table("192.168.1.1")

        assert arp_table == []

    def test_get_arp_entries_empty_networks(self, client, mock_response):
        """Test get_arp_entries when get_networks returns empty list."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": []}
        client.lvi_client.post = Mock(return_value=mock_response)

        entries = client.get_arp_entries("192.168.1.0/24")

        assert entries == []

    def test_get_arp_entries_with_provided_networks(self, client, mock_response):
        """Test get_arp_entries with networks provided."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {"arpEntries": [{"ipAddress": "192.168.1.10"}]},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        entries = client.get_arp_entries("192.168.1.0/24", networks=["Default"])

        assert len(entries) == 1

    def test_get_device_mac_table_empty(self, client, mock_response):
        """Test get_device_mac_table with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {}}
        client.lvi_client.post = Mock(return_value=mock_response)

        mac_table = client.get_device_mac_table("192.168.1.1")

        assert mac_table == []

    def test_get_device_neighbors_empty(self, client, mock_response):
        """Test get_device_neighbors with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        neighbors = client.get_device_neighbors("192.168.1.1")

        assert neighbors == []

    def test_find_switch_port_for_host_empty_networks(self, client, mock_response):
        """Test find_switch_port_for_host when no networks available."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": []}
        client.lvi_client.post = Mock(return_value=mock_response)

        port_info = client.find_switch_port_for_host("192.168.1.10")

        assert port_info is None

    def test_find_switch_port_for_host_with_networks(self, client, mock_response):
        """Test find_switch_port_for_host with networks provided."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {"switchIp": "192.168.1.1", "port": "Gi0/1"},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        port_info = client.find_switch_port_for_host("192.168.1.10", networks=["Default"])

        assert port_info is not None
        assert port_info["switchIp"] == "192.168.1.1"


class TestComplianceEdgeCases:
    """Test compliance methods edge cases."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_get_all_rule_sets_empty_networks(self, client, mock_response):
        """Test get_all_rule_sets when no networks available."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": []}
        client.lvi_client.post = Mock(return_value=mock_response)

        rule_sets = client.get_all_rule_sets()

        assert rule_sets == []

    def test_get_all_rule_sets_with_networks(self, client, mock_response):
        """Test get_all_rule_sets with networks provided."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": [{"ruleSetId": 1}]}
        client.lvi_client.post = Mock(return_value=mock_response)

        rule_sets = client.get_all_rule_sets(networks=["Default"])

        assert len(rule_sets) == 1

    def test_get_rule_set_empty(self, client, mock_response):
        """Test get_rule_set with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        rule_set = client.get_rule_set(1)

        assert rule_set == {}

    def test_delete_rule_set_failure(self, client, mock_response):
        """Test delete_rule_set when deletion fails."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"error": "Failed"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.delete_rule_set(1)

        assert result is False

    def test_get_all_policies_empty(self, client, mock_response):
        """Test get_all_policies with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        policies = client.get_all_policies()

        assert policies == []

    def test_get_policy_empty(self, client, mock_response):
        """Test get_policy with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        policy = client.get_policy(1)

        assert policy == {}

    def test_enable_policy_failure(self, client, mock_response):
        """Test enable_policy when it fails."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"error": "Failed"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.enable_policy(1)

        assert result is False

    def test_disable_policy_failure(self, client, mock_response):
        """Test disable_policy when it fails."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"error": "Failed"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.disable_policy(1)

        assert result is False

    def test_delete_policy_failure(self, client, mock_response):
        """Test delete_policy when it fails."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"error": "Failed"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.delete_policy(1)

        assert result is False

    def test_get_rule_set_categories_empty(self, client, mock_response):
        """Test get_rule_set_categories with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        categories = client.get_rule_set_categories()

        assert categories == []

    def test_create_rule_set_category_failure(self, client, mock_response):
        """Test create_rule_set_category when it fails."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        category_id = client.create_rule_set_category("Test Category")

        assert category_id is None

    def test_get_compliance_violations_for_device_empty(self, client, mock_response):
        """Test get_compliance_violations_for_device with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        violations = client.get_compliance_violations_for_device("192.168.1.1")

        assert violations == []

    def test_get_compliance_violations_for_policy_empty(self, client, mock_response):
        """Test get_compliance_violations_for_policy with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        violations = client.get_compliance_violations_for_policy(1)

        assert violations == []

    def test_get_compliance_summary_empty(self, client, mock_response):
        """Test get_compliance_summary with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        summary = client.get_compliance_summary()

        assert summary == {}

    def test_evaluate_compliance_rule_sets_empty(self, client, mock_response):
        """Test evaluate_compliance_rule_sets with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        results = client.evaluate_compliance_rule_sets([1], "192.168.1.1")

        assert results == []


class TestIncidentEdgeCases:
    """Test incident methods edge cases."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_get_incident_by_id_empty(self, client, mock_response):
        """Test get_incident_by_id with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        incident = client.get_incident_by_id(1)

        assert incident == {}

    def test_search_incidents_empty(self, client, mock_response):
        """Test search_incidents with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {}}
        client.lvi_client.post = Mock(return_value=mock_response)

        incidents = client.search_incidents()

        assert incidents == []


class TestCredentialEdgeCases:
    """Test credential methods edge cases."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_get_all_credential_configs_empty(self, client, mock_response):
        """Test get_all_credential_configs with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        configs = client.get_all_credential_configs()

        assert configs == []

    def test_get_credential_config_empty(self, client, mock_response):
        """Test get_credential_config with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        config = client.get_credential_config("Config1")

        assert config == {}

    def test_save_credential_config_failure(self, client, mock_response):
        """Test save_credential_config when it fails."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.save_credential_config(config_name="Test")

        assert result is None

    def test_delete_credential_config_failure(self, client, mock_response):
        """Test delete_credential_config when it fails."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"error": "Failed"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.delete_credential_config("Config1")

        assert result is False

    def test_get_credential_sets_empty(self, client, mock_response):
        """Test get_credential_sets with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        sets = client.get_credential_sets("Config1")

        assert sets == []

    def test_save_credential_sets_failure(self, client, mock_response):
        """Test save_credential_sets when it fails."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"error": "Failed"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.save_credential_sets("Config1", [])

        assert result is False

    def test_delete_credential_sets_failure(self, client, mock_response):
        """Test delete_credential_sets when it fails."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"error": "Failed"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.delete_credential_sets("Config1", [1])

        assert result is False

    def test_commit_credential_edits_failure(self, client, mock_response):
        """Test commit_credential_edits when it fails."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"error": "Failed"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.commit_credential_edits()

        assert result is False

    def test_discard_credential_edits_failure(self, client, mock_response):
        """Test discard_credential_edits when it fails."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"error": "Failed"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.discard_credential_edits()

        assert result is False

    def test_get_last_successful_credential_mapping_empty(self, client, mock_response):
        """Test get_last_successful_credential_mapping with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        mapping = client.get_last_successful_credential_mapping("192.168.1.1")

        assert mapping is None


class TestDeviceUpdateEdgeCases:
    """Test device update methods edge cases."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_update_device_not_found(self, client, mock_response):
        """Test update_device when device doesn't exist."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.update_device("192.168.1.1", hostname="new-name")

        assert result is None

    def test_update_device_no_result(self, client, mock_response):
        """Test update_device when update returns no result."""
        get_response = Mock()
        get_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"ipAddress": "192.168.1.1"}}
        get_response.raise_for_status = Mock()

        update_response = Mock()
        update_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        update_response.raise_for_status = Mock()

        client.lvi_client.post = Mock(side_effect=[get_response, update_response])

        result = client.update_device("192.168.1.1", hostname="new-name")

        assert result is None

    def test_update_devices_failure(self, client, mock_response):
        """Test update_devices when it fails."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"error": "Failed"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.update_devices([])

        assert result is False

    def test_update_custom_fields_failure(self, client, mock_response):
        """Test update_custom_fields when it fails."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"error": "Failed"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.update_custom_fields("192.168.1.1")

        assert result is False

    def test_update_device_hardware_failure(self, client, mock_response):
        """Test update_device_hardware when it fails."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"error": "Failed"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.update_device_hardware("192.168.1.1")

        assert result is False

    def test_update_end_of_dates_failure(self, client, mock_response):
        """Test update_end_of_dates when it fails."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"error": "Failed"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.update_end_of_dates("192.168.1.1")

        assert result is False

    def test_update_device_values_success(self, client, mock_response):
        """Test update_device_values successfully updates traits and adapter."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.update_device_values(
            ip_address="192.168.1.100",
            network="Default",
            adapter_id="Cisco::IOS",
            add_traits=["ncm", "dhcp"],
            remove_traits=["snmp"],
            identified_by_hostname=True,
        )

        assert result is True
        client.lvi_client.post.assert_called_once()

    def test_update_device_values_add_traits_only(self, client, mock_response):
        """Test update_device_values with only add_traits."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.update_device_values(
            ip_address="192.168.1.100",
            add_traits=["ncm", "ssh"],
        )

        assert result is True

    def test_update_device_values_change_adapter(self, client, mock_response):
        """Test update_device_values to change adapter only."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.update_device_values(
            ip_address="192.168.1.100",
            adapter_id="4RF::AprisaSR",
        )

        assert result is True

    def test_update_device_values_failure(self, client, mock_response):
        """Test update_device_values when it fails."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"error": "Failed"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.update_device_values(
            ip_address="192.168.1.100",
            add_traits=["ncm"],
        )

        assert result is False


class TestPlaybookEdgeCases:
    """Test playbook methods edge cases."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_get_playbooks_empty(self, client, mock_response):
        """Test get_playbooks with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {}}
        client.lvi_client.post = Mock(return_value=mock_response)

        playbooks = client.get_playbooks()

        assert playbooks == []

    def test_run_playbook_with_error(self, client, mock_response):
        """Test run_playbook when it returns an error."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "error": {"code": -1, "message": "Error"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.run_playbook("playbook-1")

        assert result == {"code": -1, "message": "Error"}

    def test_run_playbook_invalid_response(self, client, mock_response):
        """Test run_playbook with invalid response."""
        mock_response.json.return_value = "Invalid"
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.run_playbook("playbook-1")

        assert result is None


class TestNetworkManagementEdgeCases:
    """Test network management edge cases."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_define_managed_network_failure(self, client, mock_response):
        """Test define_managed_network when it fails."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"error": "Failed"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.define_managed_network("Test")

        assert result is False

    def test_get_managed_network_empty(self, client, mock_response):
        """Test get_managed_network with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        network = client.get_managed_network("Test")

        assert network is None

    def test_get_all_managed_networks_empty(self, client, mock_response):
        """Test get_all_managed_networks with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        networks = client.get_all_managed_networks()

        assert networks == []

    def test_delete_managed_network_failure(self, client, mock_response):
        """Test delete_managed_network when it fails."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"error": "Failed"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.delete_managed_network("Test")

        assert result is False

    def test_update_managed_network_failure(self, client, mock_response):
        """Test update_managed_network when it fails."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"error": "Failed"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.update_managed_network("Test")

        assert result is False


class TestJobSchedulerEdgeCases:
    """Test job scheduler edge cases."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_run_job_now_empty(self, client, mock_response):
        """Test run_job_now with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.run_job_now("Test", "Backup", [], {})

        assert result is None

    def test_save_job_empty(self, client, mock_response):
        """Test save_job with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.save_job({})

        assert result is None

    def test_delete_job_failure(self, client, mock_response):
        """Test delete_job when it fails."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"error": "Failed"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.delete_job(123)

        assert result is False

    def test_get_job_empty(self, client, mock_response):
        """Test get_job with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        job = client.get_job(123)

        assert job is None

    def test_search_jobs_empty(self, client, mock_response):
        """Test search_jobs with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {}}
        client.lvi_client.post = Mock(return_value=mock_response)

        jobs = client.search_jobs()

        assert jobs == []

    def test_run_existing_job_now_empty(self, client, mock_response):
        """Test run_existing_job_now with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.run_existing_job_now(123)

        assert result is None

    def test_search_job_executions_empty(self, client, mock_response):
        """Test search_job_executions with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {}}
        client.lvi_client.post = Mock(return_value=mock_response)

        executions = client.search_job_executions()

        assert executions == []


class TestBridgeEdgeCases:
    """Test bridge methods edge cases."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_define_bridge_failure(self, client, mock_response):
        """Test define_bridge when it fails."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"error": "Failed"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.define_bridge("Test", "host.com")

        assert result is False

    def test_get_all_bridges_empty(self, client, mock_response):
        """Test get_all_bridges with empty result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        bridges = client.get_all_bridges()

        assert bridges == []

    def test_delete_bridge_failure(self, client, mock_response):
        """Test delete_bridge when it fails."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"error": "Failed"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.delete_bridge("1")

        assert result is False


class TestIncidentsMethods:
    """Unit tests for new Incidents service methods."""

    @pytest.fixture
    def mock_env(self, monkeypatch):
        """Mock environment variables."""
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token-123")
        monkeypatch.setenv("LVI_USERNAME", "")
        monkeypatch.setenv("LVI_PASSWORD", "")
        monkeypatch.setenv("LVI_VERIFY_SSL", "false")

    @pytest.fixture
    def client(self, mock_env):
        """Create a LogicVeinAPIClient instance with mocked session."""
        with patch("src.logicvein.lvi_api_client.requests.Session") as mock_session_class:
            mock_session = Mock()
            mock_session.headers = {}
            mock_session.verify = False
            mock_session_class.return_value = mock_session

            client = LogicVeinAPIClient()
            return client

    def test_save_incident_success(self, client):
        """Test saving an incident successfully."""
        incident_data = {
            "incidentId": 7,
            "isNew": False,
            "summary": "Test incident",
            "status": "OPEN",
            "priority": "LOW",
            "severity": "WARNING",
            "resolution": "PENDING",
            "resolved": None,
            "assignee": "admin",
            "network": "Default",
            "policyId": 1,
        }

        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1, "result": incident_data}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.save_incident(incident_data)

        assert result is not None
        assert result["incidentId"] == 7
        assert result["summary"] == "Test incident"
        client.lvi_client.post.assert_called_once()

    def test_save_incident_returns_none_on_error(self, client):
        """Test that save_incident returns None on error response."""
        incident_data = {"incidentId": 1}

        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1, "error": {"code": -1, "message": "Error"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.save_incident(incident_data)

        assert result is None

    def test_get_webhook_templates_success(self, client):
        """Test getting webhook templates successfully."""
        templates = {
            "slack": {"headers": [{"Content-Type": "application/json"}], "content": '{"text": "{message}"}'},
            "teams": {"headers": [{"Content-Type": "application/json"}], "content": '{"type": "message"}'},
            "pagerduty_raise": {
                "headers": [{"Content-Type": "application/json"}],
                "content": '{"payload": {"summary": "{severity}"}}',
            },
        }

        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1, "result": templates}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_webhook_templates()

        assert result is not None
        assert "slack" in result
        assert "teams" in result
        assert "pagerduty_raise" in result
        client.lvi_client.post.assert_called_once()

    def test_get_webhook_templates_returns_empty_on_error(self, client):
        """Test that get_webhook_templates returns empty dict on error."""
        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1, "error": {"code": -1, "message": "Error"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_webhook_templates()

        assert result == {}

    def test_fill_webhook_replacements_success(self, client):
        """Test filling webhook replacements successfully."""
        template = '{"summary": "{severity}: {message}"}'
        filled = '{"summary": "WARNING: Test message"}'

        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1, "result": filled}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.fill_webhook_replacements(template)

        assert result == filled
        client.lvi_client.post.assert_called_once()

    def test_fill_webhook_replacements_with_trigger_event(self, client):
        """Test filling webhook replacements with trigger event."""
        template = '{"summary": "{severity}: {message}"}'
        trigger_event = {"severity": "CRITICAL", "message": "Alert"}
        filled = '{"summary": "CRITICAL: Alert"}'

        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1, "result": filled}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.fill_webhook_replacements(template, trigger_event)

        assert result == filled

    def test_fill_webhook_replacements_returns_empty_on_error(self, client):
        """Test that fill_webhook_replacements returns empty string on error."""
        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1, "error": {"code": -1, "message": "Error"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.fill_webhook_replacements("template")

        assert result == ""


class TestNewPlaybookMethods:
    """Unit tests for new VisualScript/Playbook methods."""

    @pytest.fixture
    def mock_env(self, monkeypatch):
        """Mock environment variables."""
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token-123")
        monkeypatch.setenv("LVI_VERIFY_SSL", "false")

    @pytest.fixture
    def client(self, mock_env):
        """Create a LogicVeinAPIClient instance."""
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            client = LogicVeinAPIClient()
            return client

    def test_save_playbook_success(self, client):
        """Test saving a playbook successfully."""
        playbook = {
            "name": "Test Playbook",
            "description": "Test description",
            "nodes": [],
            "edges": [],
            "categoryId": 1,
        }

        mock_response = Mock()
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": {"playbookId": 10, "name": "Test Playbook"},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.save_playbook(playbook)

        assert result is not None
        assert result["playbookId"] == 10
        client.lvi_client.post.assert_called_once()

    def test_add_playbook_category_success(self, client):
        """Test adding a playbook category successfully."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": {
                "categoryId": 5,
                "categoryName": "Test Category",
                "categoryColor": "#FF0000",
                "categoryImage": "test.svg",
            },
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.add_playbook_category("Test Category", "#FF0000", "test.svg")

        assert result == 5
        client.lvi_client.post.assert_called_once()

    def test_add_playbook_category_with_defaults(self, client):
        """Test adding a playbook category with default color/image."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": {
                "categoryId": 6,
                "categoryName": "Default Category",
                "categoryColor": "#1d31b8",
                "categoryImage": "playbook_default.svg",
            },
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.add_playbook_category("Default Category")

        assert result == 6


class TestMonitorSetMethods:
    """Unit tests for new Collection/Monitor Set methods."""

    @pytest.fixture
    def mock_env(self, monkeypatch):
        """Mock environment variables."""
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token-123")
        monkeypatch.setenv("LVI_VERIFY_SSL", "false")

    @pytest.fixture
    def client(self, mock_env):
        """Create a LogicVeinAPIClient instance."""
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            client = LogicVeinAPIClient()
            return client

    def test_search_monitor_sets_success(self, client):
        """Test searching monitor sets successfully."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": {
                "monitorSets": [{"setId": 1, "name": "Default Monitor Set"}, {"setId": 2, "name": "Custom Monitor Set"}]
            },
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.search_monitor_sets()

        assert len(result) == 2
        assert result[0]["setId"] == 1
        client.lvi_client.post.assert_called_once()

    def test_search_monitor_sets_with_filters(self, client):
        """Test searching monitor sets with filter parameters."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": {"monitorSets": [{"setId": 1, "name": "Default Monitor Set"}]},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.search_monitor_sets(descending=True, page_size=10)

        assert len(result) == 1
        client.lvi_client.post.assert_called_once()

    def test_associate_monitor_set_success(self, client):
        """Test associating a monitor set with device(s) successfully."""
        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1, "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.associate_monitor_set(set_id=2, host_queries=["ipCsv=192.168.1.12@Default"])

        assert result is True
        client.lvi_client.post.assert_called_once()

    def test_associate_monitor_set_failure(self, client):
        """Test that associate_monitor_set returns False on failure."""
        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1, "result": {"error": "Failed"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.associate_monitor_set(2, ["ipCsv=192.168.1.12@Default"])

        assert result is False

    def test_add_monitors_to_set_success(self, client):
        """Test adding monitors to a set successfully."""
        monitors = [
            {"monitorId": -1, "monitorName": "tcp port monitor", "setId": 5, "monitorType": "tcp", "disabled": False}
        ]

        mock_response = Mock()
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": [
                {"setId": 5, "monitorName": "tcp port monitor", "monitorType": "tcp", "retentionPolicy": "THREE_MONTHS"}
            ],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.add_monitors_to_set(monitors)

        assert len(result) == 1
        assert result[0]["monitorType"] == "tcp"
        client.lvi_client.post.assert_called_once()

    def test_dissociate_monitors_success(self, client):
        """Test removing monitors from device successfully."""
        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1, "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.dissociate_monitors(
            monitor_ids=[3, 4, 5], network="Default", device_uuid="ec782237-b3d4-4aec-b902-11eab9ef30af"
        )

        assert result is True
        client.lvi_client.post.assert_called_once()


class TestAlertPolicyMethods:
    """Unit tests for new Collection/Alert Policy methods."""

    @pytest.fixture
    def mock_env(self, monkeypatch):
        """Mock environment variables."""
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token-123")
        monkeypatch.setenv("LVI_VERIFY_SSL", "false")

    @pytest.fixture
    def client(self, mock_env):
        """Create a LogicVeinAPIClient instance."""
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            client = LogicVeinAPIClient()
            return client

    def test_search_alert_policies_success(self, client):
        """Test searching alert policies successfully."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": {
                "offset": 0,
                "pageSize": 100,
                "total": 2,
                "policies": [{"policyId": 1, "policyName": "Policy 1"}, {"policyId": 2, "policyName": "Policy 2"}],
            },
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.search_alert_policies()

        assert result is not None
        assert len(result) == 2
        assert result[0]["policyId"] == 1
        client.lvi_client.post.assert_called_once()

    def test_save_alert_policy_success(self, client):
        """Test saving an alert policy successfully."""
        policy = {
            "policyId": 2,
            "policyName": "test alert policy",
            "actionTypes": ["webhook", "email"],
            "managedNetworks": ["Default"],
        }

        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1, "result": policy}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.save_alert_policy(policy)

        assert result is not None
        assert result["policyId"] == 2
        assert "webhook" in result["actionTypes"]
        client.lvi_client.post.assert_called_once()

    def test_save_alert_actions_success(self, client):
        """Test saving alert actions successfully."""
        actions = [
            {"actionType": "webhook", "policyId": 2, "username": "admin", "json": {"url": "https://example.com"}},
            {"actionType": "email", "policyId": 2, "username": "admin", "json": {"to": "admin@example.com"}},
        ]

        mock_response = Mock()
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": [
                {"actionId": 19, "actionType": "webhook", "policyId": 2, "username": "admin"},
                {"actionId": 20, "actionType": "email", "policyId": 2, "username": "admin"},
            ],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.save_alert_actions(actions)

        assert len(result) == 2
        assert result[0]["actionType"] == "webhook"
        assert result[1]["actionType"] == "email"
        client.lvi_client.post.assert_called_once()


class TestMapMethods:
    """Unit tests for new Maps methods."""

    @pytest.fixture
    def mock_env(self, monkeypatch):
        """Mock environment variables."""
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token-123")
        monkeypatch.setenv("LVI_VERIFY_SSL", "false")

    @pytest.fixture
    def client(self, mock_env):
        """Create a LogicVeinAPIClient instance."""
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            client = LogicVeinAPIClient()
            return client

    def test_save_map_success(self, client):
        """Test saving a map successfully."""
        map_obj = {
            "mapId": 4,
            "name": "map for claude",
            "mapType": "device",
            "nodes": [
                {
                    "nodeId": {"uuid": "a3bf160b-e780-4b96-9e0b-f7f22f24d41f", "network": "Default"},
                    "nodeType": "device",
                    "props": {"x": 0, "y": 27},
                }
            ],
            "managedNetworks": ["Default"],
        }

        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1, "result": map_obj}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.save_map(map_obj)

        assert result is not None
        assert result["mapId"] == 4
        assert result["name"] == "map for claude"
        assert len(result["nodes"]) == 1
        client.lvi_client.post.assert_called_once()

    def test_save_map_returns_none_on_error(self, client):
        """Test that save_map returns None on error."""
        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1, "error": {"code": -1, "message": "Error"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.save_map({})

        assert result is None


class TestDashboardMethods:
    """Unit tests for new Dashboard methods."""

    @pytest.fixture
    def mock_env(self, monkeypatch):
        """Mock environment variables."""
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token-123")
        monkeypatch.setenv("LVI_VERIFY_SSL", "false")

    @pytest.fixture
    def client(self, mock_env):
        """Create a LogicVeinAPIClient instance."""
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            client = LogicVeinAPIClient()
            return client

    def test_save_dashboard_success(self, client):
        """Test saving a dashboard successfully."""
        dashboard = {
            "dashboardId": 2,
            "dashboardName": "Lab Dashboard",
            "definition": {
                "rows": [
                    {
                        "rowHeight": 241,
                        "widgets": [{"id": "0", "type": "inventory", "title": "Inventory", "config": {}}],
                    }
                ]
            },
            "managedNetworks": ["Default"],
            "shared": True,
        }

        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1, "result": dashboard}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.save_dashboard(dashboard)

        assert result is not None
        assert result["dashboardId"] == 2
        assert result["dashboardName"] == "Lab Dashboard"
        assert result["shared"] is True
        client.lvi_client.post.assert_called_once()

    def test_save_dashboard_with_multiple_widgets(self, client):
        """Test saving a dashboard with multiple widgets."""
        dashboard = {
            "dashboardId": 3,
            "dashboardName": "Multi-widget Dashboard",
            "definition": {
                "rows": [
                    {
                        "rowHeight": 300,
                        "widgets": [
                            {"id": "1", "type": "inventory", "title": "Inventory"},
                            {"id": "2", "type": "violations", "title": "Violations"},
                        ],
                    }
                ]
            },
            "managedNetworks": ["Default"],
        }

        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1, "result": dashboard}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.save_dashboard(dashboard)

        assert len(result["definition"]["rows"][0]["widgets"]) == 2
        client.lvi_client.post.assert_called_once()

    def test_get_all_dashboards_success(self, client):
        """Test retrieving all dashboards successfully."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": [
                {"dashboardId": 1, "dashboardName": "Dashboard 1"},
                {"dashboardId": 2, "dashboardName": "Dashboard 2"},
            ],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_all_dashboards()

        assert len(result) == 2
        assert result[0]["dashboardId"] == 1
        client.lvi_client.post.assert_called_once()

    def test_get_all_dashboards_empty(self, client):
        """Test get_all_dashboards returns empty list when no dashboards."""
        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_all_dashboards()

        assert result == []

    def test_delete_dashboard_success(self, client):
        """Test deleting a dashboard successfully."""
        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1, "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.delete_dashboard(1)

        assert result is True
        client.lvi_client.post.assert_called_once()

    def test_delete_dashboard_failure(self, client):
        """Test delete_dashboard returns False on failure."""
        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1, "result": {"error": "Failed"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.delete_dashboard(999)

        assert result is False


class TestAdditionalPlaybookMethods:
    """Unit tests for additional Playbook methods (get_playbook, delete_playbook, etc.)."""

    @pytest.fixture
    def mock_env(self, monkeypatch):
        """Mock environment variables."""
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token-123")
        monkeypatch.setenv("LVI_VERIFY_SSL", "false")

    @pytest.fixture
    def client(self, mock_env):
        """Create a LogicVeinAPIClient instance."""
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            client = LogicVeinAPIClient()
            return client

    def test_get_playbook_success(self, client):
        """Test retrieving a playbook by ID successfully."""
        playbook_data = {
            "visualScriptId": "abc-123",
            "name": "Test Playbook",
            "description": "A test playbook",
            "nodes": [],
            "edges": [],
        }
        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1, "result": playbook_data}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_playbook("abc-123")

        assert result is not None
        assert result["visualScriptId"] == "abc-123"
        assert result["name"] == "Test Playbook"
        client.lvi_client.post.assert_called_once()

    def test_get_playbook_with_version(self, client):
        """Test retrieving a specific version of a playbook."""
        playbook_data = {
            "visualScriptId": "abc-123",
            "name": "Test Playbook",
            "versionId": 2,
        }
        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1, "result": playbook_data}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_playbook("abc-123", version=2)

        assert result is not None
        assert result["versionId"] == 2

    def test_get_playbook_not_found(self, client):
        """Test get_playbook returns None when playbook not found."""
        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_playbook("nonexistent-id")

        assert result is None

    def test_delete_playbook_success(self, client):
        """Test deleting a playbook successfully."""
        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1, "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.delete_playbook("abc-123")

        assert result is True
        client.lvi_client.post.assert_called_once()

    def test_delete_playbook_failure(self, client):
        """Test delete_playbook returns False on failure."""
        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1, "result": {"error": "Failed"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.delete_playbook("nonexistent-id")

        assert result is False

    def test_get_playbook_available_nodes_success(self, client):
        """Test retrieving available playbook nodes successfully."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": [
                {"type": "start", "name": "Start Node"},
                {"type": "end", "name": "End Node"},
                {"type": "script", "name": "Script Node"},
            ],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_playbook_available_nodes()

        assert len(result) == 3
        assert result[0]["type"] == "start"

    def test_get_playbook_available_nodes_empty(self, client):
        """Test get_playbook_available_nodes returns empty list on no result."""
        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_playbook_available_nodes()

        assert result == []

    def test_get_playbook_categories_success(self, client):
        """Test retrieving playbook categories successfully."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": [
                {"categoryId": "1", "categoryName": "General"},
                {"categoryId": "2", "categoryName": "Network"},
            ],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_playbook_categories()

        assert len(result) == 2
        assert result[0]["categoryName"] == "General"

    def test_get_playbook_categories_empty(self, client):
        """Test get_playbook_categories returns empty list on no result."""
        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_playbook_categories()

        assert result == []


class TestAdditionalComplianceValidationMethods:
    """Unit tests for compliance validation methods (is_rule_set_name_unique, is_valid_regex, etc.)."""

    @pytest.fixture
    def mock_env(self, monkeypatch):
        """Mock environment variables."""
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token-123")
        monkeypatch.setenv("LVI_VERIFY_SSL", "false")

    @pytest.fixture
    def client(self, mock_env):
        """Create a LogicVeinAPIClient instance."""
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            client = LogicVeinAPIClient()
            return client

    def test_is_rule_set_name_unique_true(self, client):
        """Test is_rule_set_name_unique returns True for unique name."""
        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1, "result": True}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.is_rule_set_name_unique("Unique Rule Set Name")

        assert result is True

    def test_is_rule_set_name_unique_false(self, client):
        """Test is_rule_set_name_unique returns False for non-unique name."""
        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1, "result": False}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.is_rule_set_name_unique("Existing Rule Set")

        assert result is False

    def test_is_valid_regex_true(self, client):
        """Test is_valid_regex returns True for valid regex (API returns empty string on success)."""
        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1, "result": ""}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.is_valid_regex(r"^hostname\s+\S+")

        assert result is True

    def test_is_valid_regex_false(self, client):
        """Test is_valid_regex returns False for invalid regex (API returns error string)."""
        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1, "result": "Unclosed character class"}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.is_valid_regex(r"[invalid regex")

        assert result is False

    def test_get_policies_for_rule_set_success(self, client):
        """Test retrieving policies for a rule set successfully."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": [
                {"policyId": 1, "policyName": "Policy 1"},
                {"policyId": 2, "policyName": "Policy 2"},
            ],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_policies_for_rule_set(10)

        assert len(result) == 2
        assert result[0]["policyId"] == 1

    def test_get_policies_for_rule_set_empty(self, client):
        """Test get_policies_for_rule_set returns empty list when no policies."""
        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_policies_for_rule_set(999)

        assert result == []


class TestAdditionalMonitoringMethods:
    """Unit tests for additional monitoring methods (get_monitor_set, get_monitors_for_set, etc.)."""

    @pytest.fixture
    def mock_env(self, monkeypatch):
        """Mock environment variables."""
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token-123")
        monkeypatch.setenv("LVI_VERIFY_SSL", "false")

    @pytest.fixture
    def client(self, mock_env):
        """Create a LogicVeinAPIClient instance."""
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            client = LogicVeinAPIClient()
            return client

    def test_get_monitor_set_success(self, client):
        """Test retrieving a monitor set by ID successfully."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": {"setId": 1, "name": "Default Monitor Set", "monitors": []},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_monitor_set(1)

        assert result is not None
        assert result["setId"] == 1
        assert result["name"] == "Default Monitor Set"

    def test_get_monitor_set_not_found(self, client):
        """Test get_monitor_set returns None when set not found."""
        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_monitor_set(999)

        assert result is None

    def test_get_monitors_for_set_success(self, client):
        """Test retrieving monitors for a set successfully."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": [
                {"monitorId": 1, "monitorName": "CPU Monitor", "monitorType": "snmp"},
                {"monitorId": 2, "monitorName": "Memory Monitor", "monitorType": "snmp"},
            ],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_monitors_for_set(1)

        assert len(result) == 2
        assert result[0]["monitorName"] == "CPU Monitor"

    def test_get_monitors_for_set_empty(self, client):
        """Test get_monitors_for_set returns empty list when no monitors."""
        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_monitors_for_set(999)

        assert result == []

    def test_get_actions_for_alert_policy_success(self, client):
        """Test retrieving actions for an alert policy successfully."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": [
                {"actionId": 1, "actionType": "email", "policyId": 1},
                {"actionId": 2, "actionType": "webhook", "policyId": 1},
            ],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_actions_for_alert_policy(1)

        assert len(result) == 2
        assert result[0]["actionType"] == "email"

    def test_get_actions_for_alert_policy_empty(self, client):
        """Test get_actions_for_alert_policy returns empty list when no actions."""
        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_actions_for_alert_policy(999)

        assert result == []

    def test_find_mib_nodes_by_oid_success(self, client):
        """Test finding MIB nodes by OID successfully."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": [
                {"oid": "1.3.6.1.2.1.1.1", "name": "sysDescr", "description": "System Description"},
            ],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.find_mib_nodes_by_oid("1.3.6.1.2.1.1")

        assert len(result) == 1
        assert result[0]["name"] == "sysDescr"

    def test_find_mib_nodes_by_oid_empty(self, client):
        """Test find_mib_nodes_by_oid returns empty list when no matches."""
        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.find_mib_nodes_by_oid("9.9.9.9.9")

        assert result == []


class TestAdditionalMapMethods:
    """Unit tests for additional Map methods (get_map, get_map_tree, delete_maps)."""

    @pytest.fixture
    def mock_env(self, monkeypatch):
        """Mock environment variables."""
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token-123")
        monkeypatch.setenv("LVI_VERIFY_SSL", "false")

    @pytest.fixture
    def client(self, mock_env):
        """Create a LogicVeinAPIClient instance."""
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            client = LogicVeinAPIClient()
            return client

    def test_get_map_success(self, client):
        """Test retrieving a map by ID successfully."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": {
                "mapId": 1,
                "name": "Network Topology",
                "mapType": "device",
                "nodes": [],
            },
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_map(1)

        assert result is not None
        assert result["mapId"] == 1
        assert result["name"] == "Network Topology"

    def test_get_map_not_found(self, client):
        """Test get_map returns None when map not found."""
        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_map(999)

        assert result is None

    def test_get_map_tree_success(self, client):
        """Test retrieving the map tree structure successfully."""
        mock_response = Mock()
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": 1,
            "result": [
                {"mapId": 1, "name": "Root Map", "children": []},
                {"mapId": 2, "name": "Subnet Map", "children": []},
            ],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_map_tree()

        assert len(result) == 2
        assert result[0]["name"] == "Root Map"

    def test_get_map_tree_empty(self, client):
        """Test get_map_tree returns None when no result."""
        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_map_tree()

        assert result is None

    def test_delete_maps_success(self, client):
        """Test deleting maps successfully."""
        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1, "result": True}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.delete_maps([1, 2, 3])

        assert result is True
        client.lvi_client.post.assert_called_once()

    def test_delete_maps_failure(self, client):
        """Test delete_maps returns False on failure."""
        mock_response = Mock()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": 1, "result": {"error": "Failed"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.delete_maps([999])

        assert result is False


class TestConnectionAndUserMethods:
    """Tests for test_connection, user lookup helpers, and role management."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_test_connection_success(self, client, mock_response):
        """Test test_connection returns True when server responds with networks."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": [{"name": "Default"}]}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.test_connection()

        assert result is True

    def test_test_connection_failure(self, client):
        """Test test_connection returns False on connection error."""
        client.lvi_client.post = Mock(side_effect=requests.exceptions.ConnectionError("refused"))

        result = client.test_connection()

        assert result is False

    def test_get_user_by_id_success(self, client, mock_response):
        """Test get_user_by_id returns user dict."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {"userId": 5, "name": "alice"},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        user = client.get_user_by_id(5)

        assert user is not None
        assert user["userId"] == 5

    def test_get_user_by_id_not_found(self, client, mock_response):
        """Test get_user_by_id returns None when no result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        user = client.get_user_by_id(999)

        assert user is None

    def test_get_user_by_name_found(self, client, mock_response):
        """Test get_user_by_name returns the matching user."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": [{"name": "alice"}, {"name": "bob"}],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        user = client.get_user_by_name("alice")

        assert user is not None
        assert user["name"] == "alice"

    def test_get_user_by_name_not_found(self, client, mock_response):
        """Test get_user_by_name returns None when username absent."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": [{"name": "alice"}],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        user = client.get_user_by_name("nonexistent")

        assert user is None

    def test_update_user_success(self, client, mock_response):
        """update_user uses Security.updateUser with flat params and returns True on null result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.update_user("bob", full_name="Bob New", email="bob@example.com", role_name="Administrator")

        assert result is True
        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert body["method"] == "Security.updateUser"
        assert body["params"]["username"] == "bob"
        assert body["params"]["fullName"] == "Bob New"
        assert body["params"]["role"] == "Administrator"
        assert "user" not in body["params"]

    def test_update_user_omits_unset_fields(self, client, mock_response):
        """Fields not passed to update_user are absent from the request params."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        client.update_user("bob", full_name="Bob New")

        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert "email" not in body["params"]
        assert "role" not in body["params"]
        assert "metadata" not in body["params"]

    def test_update_user_failure(self, client, mock_response):
        """update_user returns False when the API response indicates failure."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"error": "not found"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.update_user("ghost", full_name="Ghost")

        assert result is False


class TestRoleMethods:
    """Tests for role creation, lookup, update, and deletion."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_get_role_by_name_found(self, client, mock_response):
        """Test get_role_by_name returns matching role."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": [{"name": "Administrator"}, {"name": "Read-Only"}],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        role = client.get_role_by_name("Administrator")

        assert role is not None
        assert role["name"] == "Administrator"

    def test_get_role_by_name_not_found(self, client, mock_response):
        """Test get_role_by_name returns None when name absent."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": [{"name": "Administrator"}],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        role = client.get_role_by_name("Superuser")

        assert role is None

    def test_create_role_success(self, client, mock_response):
        """Test create_role returns created role dict."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {"name": "Operator", "permissions": ["view"]},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.create_role("Operator", permissions=["view"])

        assert result is not None
        assert result["name"] == "Operator"

    def test_create_role_failure(self, client, mock_response):
        """Test create_role returns None on failure."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.create_role("Operator", permissions=[])

        assert result is None

    def test_update_role_success(self, client):
        """Test update_role fetches role then saves updated permissions."""
        get_resp = Mock()
        get_resp.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": [{"name": "Operator", "permissions": ["view"]}],
        }
        save_resp = Mock()
        save_resp.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {"name": "Operator", "permissions": ["view", "edit"]},
        }
        client.lvi_client.post = Mock(side_effect=[get_resp, save_resp])

        result = client.update_role("Operator", permissions=["view", "edit"])

        assert result is not None
        assert "edit" in result["permissions"]

    def test_update_role_not_found(self, client, mock_response):
        """Test update_role returns None when role name not found."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": []}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.update_role("Nonexistent", permissions=[])

        assert result is None

    def test_delete_role_success(self, client, mock_response):
        """Test delete_role returns True on success."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.delete_role("Operator")

        assert result is True

    def test_delete_role_failure(self, client, mock_response):
        """Test delete_role returns False on failure."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"error": "Not found"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.delete_role("Nonexistent")

        assert result is False


class TestJumphostMethods:
    """Tests for jumphost management methods."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_get_jumphost_for_network_success(self, client, mock_response):
        """Test get_jumphost_for_network returns jumphost config."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {"enabled": "true", "host": "jumphost.example.com", "adapter": "Cisco::IOS"},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_jumphost_for_network("Default")

        assert result is not None
        assert result["host"] == "jumphost.example.com"
        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert body["method"] == "Jumphost.getJumphostForNetwork"

    def test_get_jumphost_for_network_none(self, client, mock_response):
        """Test get_jumphost_for_network returns None when not configured."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_jumphost_for_network("Default")

        assert result is None

    def test_save_jumphost_success(self, client, mock_response):
        """Test save_jumphost returns True on success."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.save_jumphost("Default", enabled=True, host="jumphost.example.com")

        assert result is True

    def test_save_jumphost_failure(self, client, mock_response):
        """Test save_jumphost returns False on failure."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"error": "Failed"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.save_jumphost("Default")

        assert result is False

    def test_save_jumphost_override_port(self, client, mock_response):
        """overridePort and port are included in properties when provided."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        client.save_jumphost("test", enabled=True, host="1.1.1.1", override_port=True, port=22)

        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        props = body["params"]["properties"]
        assert props["overridePort"] == "true"
        assert props["port"] == 22


class TestTermLogsAndMibMethods:
    """Tests for terminal log search and MIB tree lookup."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_search_term_logs_success(self, client, mock_response):
        """Test search_term_logs returns matching log entries."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {"termLogs": [{"timestamp": 1700000000, "ipAddress": "192.168.1.1", "output": "show version"}]},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        logs = client.search_term_logs(networks=["Default"])

        assert isinstance(logs, list)
        assert len(logs) == 1
        assert logs[0]["ipAddress"] == "192.168.1.1"

    def test_search_term_logs_empty(self, client, mock_response):
        """Test search_term_logs returns empty list when no termLogs key."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {}}
        client.lvi_client.post = Mock(return_value=mock_response)

        logs = client.search_term_logs()

        assert logs == []

    def test_find_mib_children_success(self, client, mock_response):
        """Test find_mib_children returns direct children of the given OID."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": [
                {"oid": "1.3.6.1.2.1.1.1", "name": "sysDescr", "leaf": True},
                {"oid": "1.3.6.1.2.1.1.2", "name": "sysObjectID", "leaf": True},
            ],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        children = client.find_mib_children("1.3.6.1.2.1.1")

        assert isinstance(children, list)
        assert len(children) == 2
        assert children[0]["name"] == "sysDescr"

    def test_find_mib_children_empty(self, client, mock_response):
        """Test find_mib_children returns empty list when OID has no children."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        children = client.find_mib_children("9.9.9.9")

        assert children == []


class TestZeroTouchAndFileStoreMethods:
    """Tests for ZeroTouch history, FileStore entries, and execution detail methods."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_search_zero_touch_history_success(self, client, mock_response):
        """Test search_zero_touch_history returns history entries."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {"history": [{"timestamp": 1700000000, "ipAddress": "10.0.0.1", "status": "success"}]},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        history = client.search_zero_touch_history(networks=["Default"])

        assert isinstance(history, list)
        assert len(history) == 1
        assert history[0]["status"] == "success"

    def test_search_zero_touch_history_empty(self, client, mock_response):
        """Test search_zero_touch_history returns empty list when no history key."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {}}
        client.lvi_client.post = Mock(return_value=mock_response)

        history = client.search_zero_touch_history()

        assert history == []

    def test_get_device_file_store_entries_success(self, client, mock_response):
        """Test get_device_file_store_entries returns file entries."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {"entries": [{"filename": "startup-config", "size": 1024}]},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        entries = client.get_device_file_store_entries("192.168.1.1")

        assert isinstance(entries, list)
        assert len(entries) == 1
        assert entries[0]["filename"] == "startup-config"

    def test_get_device_file_store_entries_empty(self, client, mock_response):
        """Test get_device_file_store_entries returns empty list when no entries key."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {}}
        client.lvi_client.post = Mock(return_value=mock_response)

        entries = client.get_device_file_store_entries("192.168.1.1")

        assert entries == []

    def test_get_execution_details_success(self, client, mock_response):
        """Test get_execution_details returns list of per-device records."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": [{"ipAddress": "192.168.1.1", "status": "SUCCESS", "output": "OK"}],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        details = client.get_execution_details(42)

        assert isinstance(details, list)
        assert len(details) == 1
        assert details[0]["status"] == "SUCCESS"

    def test_get_execution_details_non_list_result(self, client, mock_response):
        """Test get_execution_details returns empty list when result is not a list."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {}}
        client.lvi_client.post = Mock(return_value=mock_response)

        details = client.get_execution_details(42)

        assert details == []

    def test_get_execution_record_success(self, client, mock_response):
        """Test get_execution_record returns execution record dict."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "test-id",
            "result": {"executionId": 42, "jobName": "Daily Backup", "status": "COMPLETED"},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        record = client.get_execution_record(42)

        assert record is not None
        assert record["executionId"] == 42
        assert record["status"] == "COMPLETED"

    def test_get_execution_record_not_found(self, client, mock_response):
        """Test get_execution_record returns None when execution not found."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id"}
        client.lvi_client.post = Mock(return_value=mock_response)

        record = client.get_execution_record(999)

        assert record is None


class TestBridgeUpdateAndMonitorMethods:
    """Tests for update_bridge, remove_monitors_from_set, and remove_playbook_category."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_update_bridge_success(self, client, mock_response):
        """Test update_bridge returns True on success."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.update_bridge("bridge-1", bridge_name="renamed", hostname="new-host.com")

        assert result is True

    def test_update_bridge_failure(self, client, mock_response):
        """Test update_bridge returns False on failure."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"error": "Not found"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.update_bridge("nonexistent")

        assert result is False

    def test_remove_monitors_from_set_success(self, client, mock_response):
        """Test remove_monitors_from_set returns True on success."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        monitors = [{"monitorId": 3, "setId": 1}, {"monitorId": 4, "setId": 1}]
        result = client.remove_monitors_from_set(monitors)

        assert result is True

    def test_remove_monitors_from_set_failure(self, client, mock_response):
        """Test remove_monitors_from_set returns False on failure."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"error": "Failed"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.remove_monitors_from_set([])

        assert result is False

    def test_remove_playbook_category_success(self, client, mock_response):
        """Test remove_playbook_category returns True on success."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.remove_playbook_category("cat-uuid-123")

        assert result is True

    def test_remove_playbook_category_failure(self, client, mock_response):
        """Test remove_playbook_category returns False on failure."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "test-id", "result": {"error": "Not found"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.remove_playbook_category("nonexistent-uuid")

        assert result is False


# =============================================================================
# New tests covering previously-uncovered lines
# =============================================================================


class TestIgnoreEnvVarsBranch:
    """Tests for __init__ ignore_env_vars=True branch (lines 46-51)."""

    def test_ignore_env_vars_uses_kwargs_not_env(self, monkeypatch):
        """When ignore_env_vars=True, env vars are NOT consulted."""
        monkeypatch.setenv("LVI_HOST", "env.host.com")
        monkeypatch.setenv("LVI_API_TOKEN", "env-token")
        monkeypatch.setenv("LVI_USERNAME", "env-user")
        monkeypatch.setenv("LVI_PASSWORD", "env-pass")

        with patch("src.logicvein.lvi_api_client.requests.Session"):
            client = LogicVeinAPIClient(
                ignore_env_vars=True,
                host="kwarg.host.com",
                api_token="kwarg-token",
                username="kwarg-user",
                password="kwarg-pass",
                verify=False,
                timeout=60,
            )

        assert client.host == "kwarg.host.com"
        assert client.api_token == "kwarg-token"
        assert client.username == "kwarg-user"
        assert client.password == "kwarg-pass"
        assert client.verify_ssl is False
        assert client.timeout == 60

    def test_ignore_env_vars_defaults_when_no_kwargs(self, monkeypatch):
        """When ignore_env_vars=True and kwargs absent, defaults apply (not env vars)."""
        monkeypatch.setenv("LVI_HOST", "should-be-ignored.com")
        monkeypatch.setenv("LVI_API_TOKEN", "ignored-token")

        with patch("src.logicvein.lvi_api_client.requests.Session"):
            client = LogicVeinAPIClient(ignore_env_vars=True)

        assert client.host == "localhost"
        assert client.api_token == ""
        assert client.timeout == 120


class TestSearchDevicesInNetworkPagination:
    """Tests for the pagination offset increment on line 245."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_pagination_fetches_second_page(self, client):
        """search_devices_in_network paginates when first batch equals page_size."""
        page1 = Mock()
        page1.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"devices": [{"ipAddress": f"10.0.0.{i}"} for i in range(2)]},
        }
        page1.raise_for_status = Mock()
        page2 = Mock()
        page2.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"devices": [{"ipAddress": "10.0.0.99"}]},
        }
        page2.raise_for_status = Mock()
        client.lvi_client.post = Mock(side_effect=[page1, page2])

        devices = client.search_devices_in_network(page_size=2)

        assert len(devices) == 3
        assert client.lvi_client.post.call_count == 2


class TestUpdateDeviceOptionalFields:
    """Tests for adapter_id and custom_fields branches in update_device (lines 325, 327-328)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_update_device_with_adapter_id(self, client):
        """update_device sets adapterId when adapter_id provided (line 325)."""
        get_resp = Mock()
        get_resp.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"ipAddress": "1.2.3.4", "adapterId": "old-adapter"},
        }
        get_resp.raise_for_status = Mock()
        save_resp = Mock()
        save_resp.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"ipAddress": "1.2.3.4", "adapterId": "Cisco::IOS"},
        }
        save_resp.raise_for_status = Mock()
        client.lvi_client.post = Mock(side_effect=[get_resp, save_resp])

        result = client.update_device("1.2.3.4", adapter_id="Cisco::IOS")

        assert result is not None
        assert result["adapterId"] == "Cisco::IOS"

    def test_update_device_with_custom_fields(self, client):
        """update_device applies each custom_field key (lines 327-328)."""
        get_resp = Mock()
        get_resp.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"ipAddress": "1.2.3.4"},
        }
        get_resp.raise_for_status = Mock()
        save_resp = Mock()
        save_resp.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"ipAddress": "1.2.3.4", "site": "DC1", "owner": "ops"},
        }
        save_resp.raise_for_status = Mock()
        client.lvi_client.post = Mock(side_effect=[get_resp, save_resp])

        result = client.update_device("1.2.3.4", custom_fields={"site": "DC1", "owner": "ops"})

        assert result is not None
        assert result["site"] == "DC1"


class TestUpdateDeviceHardwareOptionalFields:
    """Tests for make/model/osVersion optional branches (lines 446, 448, 450)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_update_device_hardware_with_make_model_osversion(self, client, mock_response):
        """update_device_hardware includes make, model, osVersion params (lines 446, 448, 450)."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.update_device_hardware(
            "1.2.3.4",
            make="Cisco",
            model="ASR1001",
            os_version="16.12.4",
        )

        assert result is True
        assert client.lvi_client.post.called


class TestUpdateEndOfDatesOptionalFields:
    """Tests for optional param branches in update_end_of_dates (lines 484, 486, 488, 492)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_update_end_of_dates_all_optional_params(self, client, mock_response):
        """update_end_of_dates with all optional params (lines 484, 486, 488, 492)."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.update_end_of_dates(
            "1.2.3.4",
            end_of_sale=1700000000,
            end_of_sw_maintenance=1710000000,
            end_of_security_vul_support=1720000000,
            end_of_service_contract_renewal=1730000000,
        )

        assert result is True

    def test_update_end_of_dates_only_end_of_life(self, client, mock_response):
        """update_end_of_dates with only end_of_life set."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.update_end_of_dates("1.2.3.4", end_of_life=1750000000)

        assert result is True


class TestGetAvailableAdapters:
    """Tests for get_available_adapters (lines 521-525)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_get_available_adapters_success(self, client, mock_response):
        """get_available_adapters returns the adapter list (lines 523-524)."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": [{"adapterId": "Cisco::IOS", "shortName": "Cisco IOS"}],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        adapters = client.get_available_adapters()

        assert isinstance(adapters, list)
        assert len(adapters) == 1
        assert adapters[0]["adapterId"] == "Cisco::IOS"

    def test_get_available_adapters_empty(self, client, mock_response):
        """get_available_adapters returns empty list when no result (line 525)."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t"}
        client.lvi_client.post = Mock(return_value=mock_response)

        adapters = client.get_available_adapters()

        assert adapters == []


class TestGetAdaptersWithConfigPaths:
    """Tests for get_adapters_with_config_paths (lines 544-551)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_get_adapters_with_config_paths_auto_fetches_networks(self, client):
        """When networks=[], get_adapters_with_config_paths fetches networks first (lines 544-545)."""
        networks_resp = Mock()
        networks_resp.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": ["Default"]}
        networks_resp.raise_for_status = Mock()
        adapters_resp = Mock()
        adapters_resp.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": [{"adapterId": "Cisco::IOS", "configurations": ["/running-config"]}],
        }
        adapters_resp.raise_for_status = Mock()
        client.lvi_client.post = Mock(side_effect=[networks_resp, adapters_resp])

        result = client.get_adapters_with_config_paths()

        assert isinstance(result, list)
        assert len(result) == 1
        assert client.lvi_client.post.call_count == 2

    def test_get_adapters_with_config_paths_success(self, client, mock_response):
        """get_adapters_with_config_paths returns adapter list when networks provided (lines 549-550)."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": [{"adapterId": "Cisco::IOS", "configurations": ["/running-config", "/startup-config"]}],
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_adapters_with_config_paths(networks=["Default"])

        assert len(result) == 1
        assert "/running-config" in result[0]["configurations"]

    def test_get_adapters_with_config_paths_empty(self, client, mock_response):
        """get_adapters_with_config_paths returns [] when response has no result (line 551)."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t"}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_adapters_with_config_paths(networks=["Default"])

        assert result == []


class TestConfigChangeLogPagination:
    """Tests for pagination break and offset in get_device_configuration_change_logs (lines 588, 595)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_change_logs_break_on_bad_response(self, client, mock_response):
        """Loop breaks when response lacks changeLogs key (line 588)."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": {}}
        client.lvi_client.post = Mock(return_value=mock_response)

        logs = client.get_device_configuration_change_logs("1.2.3.4")

        assert logs == []

    def test_change_logs_pagination_offset(self, client):
        """Loop continues and increments offset when full page returned (line 595)."""
        page1 = Mock()
        page1.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"changeLogs": [{"ts": i} for i in range(2)]},
        }
        page1.raise_for_status = Mock()
        page2 = Mock()
        page2.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"changeLogs": [{"ts": 99}]},
        }
        page2.raise_for_status = Mock()
        client.lvi_client.post = Mock(side_effect=[page1, page2])

        logs = client.get_device_configuration_change_logs("1.2.3.4", page_size=2)

        assert len(logs) == 3
        assert client.lvi_client.post.call_count == 2


class TestSearchDeviceInterfacesPagination:
    """Tests for pagination offset in search_device_interfaces (line 733)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_search_device_interfaces_paginates(self, client):
        """search_device_interfaces fetches second page when first is full (line 733)."""
        page1 = Mock()
        page1.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"interfaces": [{"name": f"Gi0/{i}"} for i in range(2)]},
        }
        page1.raise_for_status = Mock()
        page2 = Mock()
        page2.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"interfaces": [{"name": "Gi0/99"}]},
        }
        page2.raise_for_status = Mock()
        client.lvi_client.post = Mock(side_effect=[page1, page2])

        ifaces = client.search_device_interfaces(network="Default", page_size=2)

        assert len(ifaces) == 3
        assert client.lvi_client.post.call_count == 2


class TestArpTablePagination:
    """Tests for pagination offset in get_device_arp_table (line 802)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_arp_table_paginates(self, client):
        """get_device_arp_table fetches second page when first is full (line 802)."""
        page1 = Mock()
        page1.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"arpEntries": [{"ipAddress": f"10.0.0.{i}"} for i in range(2)]},
        }
        page1.raise_for_status = Mock()
        page2 = Mock()
        page2.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"arpEntries": [{"ipAddress": "10.0.0.99"}]},
        }
        page2.raise_for_status = Mock()
        client.lvi_client.post = Mock(side_effect=[page1, page2])

        entries = client.get_device_arp_table("1.2.3.4", page_size=2)

        assert len(entries) == 3


class TestGetArpEntriesPagination:
    """Tests for pagination offset in get_arp_entries (line 854)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_get_arp_entries_paginates(self, client):
        """get_arp_entries fetches second page when first is full (line 854)."""
        page1 = Mock()
        page1.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"arpEntries": [{"ipAddress": f"10.0.0.{i}"} for i in range(2)]},
        }
        page1.raise_for_status = Mock()
        page2 = Mock()
        page2.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"arpEntries": [{"ipAddress": "10.0.0.99"}]},
        }
        page2.raise_for_status = Mock()
        client.lvi_client.post = Mock(side_effect=[page1, page2])

        entries = client.get_arp_entries("10.0.0.0/24", networks=["Default"], page_size=2)

        assert len(entries) == 3


class TestMacTablePagination:
    """Tests for pagination offset in get_device_mac_table (line 900)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_mac_table_paginates(self, client):
        """get_device_mac_table fetches second page when first is full (line 900)."""
        page1 = Mock()
        page1.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"macEntries": [{"mac": f"aa:bb:cc:dd:ee:0{i}"} for i in range(2)]},
        }
        page1.raise_for_status = Mock()
        page2 = Mock()
        page2.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"macEntries": [{"mac": "aa:bb:cc:dd:ee:99"}]},
        }
        page2.raise_for_status = Mock()
        client.lvi_client.post = Mock(side_effect=[page1, page2])

        entries = client.get_device_mac_table("1.2.3.4", page_size=2)

        assert len(entries) == 3


class TestIsValidRegexFalseOnNoResult:
    """Test is_valid_regex returns False when response has no result key (line 1352)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_is_valid_regex_false_on_no_result(self, client, mock_response):
        """is_valid_regex returns False when response has no result key (line 1352)."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t"}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.is_valid_regex(r".*")

        assert result is False


class TestIsRuleSetNameUniqueFalseOnNoResult:
    """Test is_rule_set_name_unique returns False when response has no result key (line 1337)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_is_rule_set_name_unique_false_on_no_result(self, client, mock_response):
        """is_rule_set_name_unique returns False when response has no result key (line 1337)."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t"}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.is_rule_set_name_unique("SomeName", networks=["Default"], rule_set_id=None)

        assert result is False


class TestSearchIncidentsPagination:
    """Tests for pagination offset in search_incidents (line 1485)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_search_incidents_paginates(self, client):
        """search_incidents fetches second page when first is full (line 1485)."""
        page1 = Mock()
        page1.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"incidents": [{"incidentId": i} for i in range(2)]},
        }
        page1.raise_for_status = Mock()
        page2 = Mock()
        page2.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"incidents": [{"incidentId": 99}]},
        }
        page2.raise_for_status = Mock()
        client.lvi_client.post = Mock(side_effect=[page1, page2])

        incidents = client.search_incidents(page_size=2)

        assert len(incidents) == 3
        assert client.lvi_client.post.call_count == 2


class TestGetCredentialSetsPagination:
    """Tests for pagination offset in get_credential_sets (line 1707)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_get_credential_sets_paginates(self, client):
        """get_credential_sets fetches second page when first is full (line 1707)."""
        page1 = Mock()
        page1.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"credentialSets": [{"name": f"set{i}"} for i in range(2)]},
        }
        page1.raise_for_status = Mock()
        page2 = Mock()
        page2.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"credentialSets": [{"name": "set99"}]},
        }
        page2.raise_for_status = Mock()
        client.lvi_client.post = Mock(side_effect=[page1, page2])

        sets = client.get_credential_sets("Config1", page_size=2)

        assert len(sets) == 3


class TestGetPlaybooksPagination:
    """Tests for pagination offset in get_playbooks (line 1860)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_get_playbooks_paginates(self, client):
        """get_playbooks fetches second page when first is full (line 1860)."""
        page1 = Mock()
        page1.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"data": [{"scriptId": str(i)} for i in range(2)]},
        }
        page1.raise_for_status = Mock()
        page2 = Mock()
        page2.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"data": [{"scriptId": "99"}]},
        }
        page2.raise_for_status = Mock()
        client.lvi_client.post = Mock(side_effect=[page1, page2])

        playbooks = client.get_playbooks(page_size=2)

        assert len(playbooks) == 3


class TestSavePlaybookFailure:
    """Test save_playbook returns None on failure (line 2001)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_save_playbook_returns_none_on_failure(self, client, mock_response):
        """save_playbook returns None when response has no result key (line 2001)."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t"}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.save_playbook({"name": "Test"})

        assert result is None


class TestAddPlaybookCategoryFailure:
    """Test add_playbook_category returns None on failure (line 2028)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_add_playbook_category_returns_none_on_failure(self, client, mock_response):
        """add_playbook_category returns None when response has no categoryId (line 2028)."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t"}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.add_playbook_category("My Category")

        assert result is None


class TestUpdateManagedNetworkOptionalFields:
    """Tests for bridge_name and online optional branches in update_managed_network (lines 2129, 2131)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_update_managed_network_with_bridge_name(self, client, mock_response):
        """update_managed_network includes bridgeName when bridge_name provided (line 2129)."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.update_managed_network("Default", bridge_name="MyBridge")

        assert result is True

    def test_update_managed_network_with_online(self, client, mock_response):
        """update_managed_network includes online when online provided (line 2131)."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.update_managed_network("Default", online=False)

        assert result is True

    def test_update_managed_network_with_all_fields(self, client, mock_response):
        """update_managed_network with new_name, bridge_name, and online all set."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.update_managed_network("Default", new_name="Production", bridge_name="Bridge1", online=True)

        assert result is True


class TestRunJobNowDescriptionBranch:
    """Tests for description branch in run_job_now (line 2189)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_run_job_now_with_description(self, client, mock_response):
        """run_job_now sets custom description when provided (line 2189)."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"executionId": "exec-1"},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.run_job_now(
            job_name="My Job",
            job_type="Backup",
            managed_networks=["Default"],
            job_parameters={},
            description="Custom description here",
        )

        assert result is not None
        assert result["executionId"] == "exec-1"
        assert client.lvi_client.post.called


class TestSearchJobsPagination:
    """Tests for pagination offset in search_jobs (line 2291)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_search_jobs_paginates(self, client):
        """search_jobs fetches second page when first is full (line 2291)."""
        page1 = Mock()
        page1.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"jobData": [{"jobId": i} for i in range(2)]},
        }
        page1.raise_for_status = Mock()
        page2 = Mock()
        page2.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"jobData": [{"jobId": 99}]},
        }
        page2.raise_for_status = Mock()
        client.lvi_client.post = Mock(side_effect=[page1, page2])

        jobs = client.search_jobs(page_size=2)

        assert len(jobs) == 3


class TestSearchJobExecutionsPagination:
    """Tests for pagination offset in search_job_executions (line 2360)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_search_job_executions_paginates(self, client):
        """search_job_executions fetches second page when first is full (line 2360)."""
        page1 = Mock()
        page1.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"executionData": [{"executionId": i} for i in range(2)]},
        }
        page1.raise_for_status = Mock()
        page2 = Mock()
        page2.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"executionData": [{"executionId": 99}]},
        }
        page2.raise_for_status = Mock()
        client.lvi_client.post = Mock(side_effect=[page1, page2])

        executions = client.search_job_executions(page_size=2)

        assert len(executions) == 3


class TestUpdateBridgeOptionalFields:
    """Tests for port/username/password optional branches in update_bridge (lines 2444, 2446, 2448)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_update_bridge_with_port_username_password(self, client, mock_response):
        """update_bridge sends port, username, password when provided (lines 2444, 2446, 2448)."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.update_bridge(
            "bridge-1",
            port=8443,
            username="admin",
            password="secret",
        )

        assert result is True


class TestGetUsersEmptyFallback:
    """Test get_users returns [] when response has no result key (line 2471)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_get_users_empty_fallback(self, client, mock_response):
        """get_users returns [] when response has no result key (line 2471)."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t"}
        client.lvi_client.post = Mock(return_value=mock_response)

        users = client.get_users()

        assert users == []


class TestCreateUserFailure:
    """Test create_user returns None on failure (line 2542)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_create_user_returns_false_on_failure(self, client, mock_response):
        """create_user returns False when response has no result key."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t"}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.create_user(
            username="newuser",
            full_name="New User",
            email="new@example.com",
            password="pass123",
        )

        assert result is False


class TestUpdateUserMetadata:
    """Test update_user metadata parameter passthrough."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_update_user_with_metadata(self, client, mock_response):
        """metadata list is forwarded when provided."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": None}
        client.lvi_client.post = Mock(return_value=mock_response)
        meta = [{"key": "org.ziptie.provider.devices.columnVisibility", "value": "*"}]

        client.update_user("alice", metadata=meta)

        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert body["params"]["metadata"] == meta


class TestDeleteUserFailure:
    """Test delete_user returns False on failure (line 2601)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_delete_user_returns_false_on_failure(self, client, mock_response):
        """delete_user returns False when result is not None/None-string."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": {"error": "Not found"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.delete_user("missing-user")

        assert result is False


class TestGetAvailableRolesEmptyFallback:
    """Test get_available_roles returns [] when response has no result key (line 2614)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_get_available_roles_empty_fallback(self, client, mock_response):
        """get_available_roles returns [] when response has no result key (line 2614)."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t"}
        client.lvi_client.post = Mock(return_value=mock_response)

        roles = client.get_available_roles()

        assert roles == []


class TestUpdateRoleToolsAndFailure:
    """Tests for tools branch and failure path in update_role (lines 2684, 2690)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_update_role_with_tools(self, client):
        """update_role sets tools when tools param provided (line 2684)."""
        get_resp = Mock()
        get_resp.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": [{"name": "Operator", "permissions": ["view"], "tools": []}],
        }
        get_resp.raise_for_status = Mock()
        save_resp = Mock()
        save_resp.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"name": "Operator", "permissions": ["view"], "tools": ["backup"]},
        }
        save_resp.raise_for_status = Mock()
        client.lvi_client.post = Mock(side_effect=[get_resp, save_resp])

        result = client.update_role("Operator", tools=["backup"])

        assert result is not None
        assert "backup" in result["tools"]

    def test_update_role_save_returns_none(self, client):
        """update_role returns None when save response has no result key (line 2690)."""
        get_resp = Mock()
        get_resp.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": [{"name": "Operator", "permissions": ["view"]}],
        }
        get_resp.raise_for_status = Mock()
        save_resp = Mock()
        save_resp.json.return_value = {"jsonrpc": "2.0", "id": "t"}
        save_resp.raise_for_status = Mock()
        client.lvi_client.post = Mock(side_effect=[get_resp, save_resp])

        result = client.update_role("Operator", permissions=["view", "edit"])

        assert result is None


class TestSearchTermLogsPagination:
    """Tests for pagination offset in search_term_logs (line 2819)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_search_term_logs_paginates(self, client):
        """search_term_logs fetches second page when first is full (line 2819)."""
        page1 = Mock()
        page1.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"termLogs": [{"ts": i} for i in range(2)]},
        }
        page1.raise_for_status = Mock()
        page2 = Mock()
        page2.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"termLogs": [{"ts": 99}]},
        }
        page2.raise_for_status = Mock()
        client.lvi_client.post = Mock(side_effect=[page1, page2])

        logs = client.search_term_logs(page_size=2)

        assert len(logs) == 3


class TestSaveAlertActionsFailure:
    """Test save_alert_actions returns [] on failure (line 2999)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_save_alert_actions_returns_empty_on_failure(self, client, mock_response):
        """save_alert_actions returns [] when response result is not a list (line 2999)."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t"}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.save_alert_actions([{"actionType": "email", "policyId": 1}])

        assert result == []


class TestSearchMonitorSetsPagination:
    """Tests for no-result break and pagination offset in search_monitor_sets (lines 3044, 3049)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_search_monitor_sets_breaks_on_bad_response(self, client, mock_response):
        """search_monitor_sets breaks when response has no result key (line 3044)."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t"}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.search_monitor_sets()

        assert result == []

    def test_search_monitor_sets_paginates(self, client):
        """search_monitor_sets fetches second page when first is full (line 3049)."""
        page1 = Mock()
        page1.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"monitorSets": [{"setId": i} for i in range(2)]},
        }
        page1.raise_for_status = Mock()
        page2 = Mock()
        page2.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"monitorSets": [{"setId": 99}]},
        }
        page2.raise_for_status = Mock()
        client.lvi_client.post = Mock(side_effect=[page1, page2])

        result = client.search_monitor_sets(page_size=2)

        assert len(result) == 3


class TestAddMonitorsToSetFailure:
    """Test add_monitors_to_set returns [] on failure (line 3103)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_add_monitors_to_set_returns_empty_on_failure(self, client, mock_response):
        """add_monitors_to_set returns [] when result is not a list (line 3103)."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t"}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.add_monitors_to_set([{"monitorId": -1, "setId": 1}])

        assert result == []


class TestDissociateMonitorsFailure:
    """Test dissociate_monitors returns False on failure (line 3123)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_dissociate_monitors_returns_false_on_failure(self, client, mock_response):
        """dissociate_monitors returns False when result is not None/None-string (line 3123)."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": {"error": "Not found"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.dissociate_monitors([1, 2], "Default", "some-uuid")

        assert result is False


class TestSearchAlertPoliciesPagination:
    """Tests for no-result break and pagination offset in search_alert_policies (lines 3197, 3204)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_search_alert_policies_breaks_on_bad_response(self, client, mock_response):
        """search_alert_policies breaks when response lacks policies key (line 3197)."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": {}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.search_alert_policies()

        assert result == []

    def test_search_alert_policies_paginates(self, client):
        """search_alert_policies fetches second page when first is full (line 3204)."""
        page1 = Mock()
        page1.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"policies": [{"policyId": i} for i in range(2)]},
        }
        page1.raise_for_status = Mock()
        page2 = Mock()
        page2.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"policies": [{"policyId": 99}]},
        }
        page2.raise_for_status = Mock()
        client.lvi_client.post = Mock(side_effect=[page1, page2])

        result = client.search_alert_policies(page_size=2)

        assert len(result) == 3


class TestSaveAlertPolicyFailure:
    """Test save_alert_policy returns None on failure (line 3233)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_save_alert_policy_returns_none_on_failure(self, client, mock_response):
        """save_alert_policy returns None when response has no result key (line 3233)."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t"}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.save_alert_policy({"policyId": -1, "policyName": "New"})

        assert result is None


class TestSaveDashboardFailure:
    """Test save_dashboard returns None on failure (line 3424)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_save_dashboard_returns_none_on_failure(self, client, mock_response):
        """save_dashboard returns None when response has no result key (line 3424)."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t"}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.save_dashboard({"dashboardId": -1, "dashboardName": "New"})

        assert result is None


# ---------------------------------------------------------------------------
# save_trigger
# ---------------------------------------------------------------------------


@pytest.fixture
def _lvi_client(monkeypatch):
    monkeypatch.setenv("LVI_HOST", "test.example.com")
    monkeypatch.setenv("LVI_API_TOKEN", "test-token")
    with patch("src.logicvein.lvi_api_client.requests.Session"):
        return LogicVeinAPIClient()


class TestSaveTrigger:
    def test_returns_trigger_record_on_success(self, _lvi_client, mock_response):
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"triggerId": 12, "jobId": 21, "nextExpectedFireTime": 1773748800000},
        }
        _lvi_client.lvi_client.post = Mock(return_value=mock_response)

        result = _lvi_client.save_trigger(
            job_id=21,
            trigger_name="CHG:CHG001 at 2026-03-17T09:00",
            cron_expression="2026-03-17T09:00",
            time_zone="America/Halifax",
        )

        assert result is not None
        assert result["triggerId"] == 12
        assert result["nextExpectedFireTime"] == 1773748800000

    def test_sends_correct_rpc_params(self, _lvi_client, mock_response):
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": {"triggerId": 5}}
        _lvi_client.lvi_client.post = Mock(return_value=mock_response)

        _lvi_client.save_trigger(
            job_id=99,
            trigger_name="My Trigger",
            cron_expression="2026-06-01T14:30",
            time_zone="UTC",
            paused=True,
        )

        body = json.loads(_lvi_client.lvi_client.post.call_args.kwargs["data"])
        assert body["method"] == "Scheduler.saveTrigger"
        td = body["params"]["triggerData"]
        assert td["jobId"] == 99
        assert td["cronExpression"] == "2026-06-01T14:30"
        assert td["timeZone"] == "UTC"
        assert td["paused"] is True

    def test_returns_none_on_missing_result(self, _lvi_client, mock_response):
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t"}
        _lvi_client.lvi_client.post = Mock(return_value=mock_response)

        result = _lvi_client.save_trigger(1, "name", "2026-03-17T09:00")

        assert result is None


class TestCreateCommandRunnerJob:
    def test_returns_job_record_on_success(self, _lvi_client, mock_response):
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"jobId": 21, "jobName": "CHG:CHG001"},
        }
        _lvi_client.lvi_client.post = Mock(return_value=mock_response)

        result = _lvi_client.create_command_runner_job(
            device_ip="10.1.1.1",
            network="Default",
            commands="show version",
            job_name="CHG:CHG001",
        )

        assert result is not None
        assert result["jobId"] == 21

    def test_sends_correct_job_type_and_subtype(self, _lvi_client, mock_response):
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": {"jobId": 5}}
        _lvi_client.lvi_client.post = Mock(return_value=mock_response)

        _lvi_client.create_command_runner_job("10.1.1.1", "Default", "show version")

        body = json.loads(_lvi_client.lvi_client.post.call_args.kwargs["data"])
        assert body["method"] == "Scheduler.saveJob"
        jd = body["params"]["jobData"]
        assert jd["jobType"] == "Script Tool Job"
        assert jd["subType"] == "org.ziptie.tools.scripts.commandRunner"
        assert jd["jobId"] == 0
        assert jd["jobParameters"]["ipResolutionData"] == "10.1.1.1"
        assert jd["jobParameters"]["input.commandList"] == "show version"

    def test_returns_none_on_failure(self, _lvi_client, mock_response):
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t"}
        _lvi_client.lvi_client.post = Mock(return_value=mock_response)

        result = _lvi_client.create_command_runner_job("10.1.1.1", "Default", "show version")

        assert result is None


# =============================================================================
# Additional tests for uncovered branches and methods
# =============================================================================


class TestGetExecutionOutput:
    """Tests for get_execution_output (lines 3641-3674): success and exception paths."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_get_execution_output_success(self, client):
        """get_execution_output returns response text on success."""
        mock_get_response = Mock()
        mock_get_response.raise_for_status = Mock()
        mock_get_response.text = "show version output\nCisco IOS Version 15.1"
        client.lvi_client.get = Mock(return_value=mock_get_response)

        result = client.get_execution_output(execution_id=42, record_id=7)

        assert result == "show version output\nCisco IOS Version 15.1"
        client.lvi_client.get.assert_called_once()
        call_args = client.lvi_client.get.call_args
        assert "executionId" in call_args.kwargs["params"]
        assert call_args.kwargs["params"]["executionId"] == 42
        assert call_args.kwargs["params"]["recordId"] == 7

    def test_get_execution_output_http_error_returns_empty_string(self, client):
        """get_execution_output returns '' when raise_for_status raises."""
        mock_get_response = Mock()
        mock_get_response.raise_for_status.side_effect = requests.HTTPError("403 Forbidden")
        client.lvi_client.get = Mock(return_value=mock_get_response)

        result = client.get_execution_output(execution_id=42, record_id=7)

        assert result == ""

    def test_get_execution_output_connection_error_returns_empty_string(self, client):
        """get_execution_output returns '' when a connection exception is raised."""
        client.lvi_client.get = Mock(side_effect=requests.exceptions.ConnectionError("refused"))

        result = client.get_execution_output(execution_id=99, record_id=1)

        assert result == ""


class TestRunCommandRunnerJob:
    """Tests for run_command_runner_job (lines 2461-2505)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_run_command_runner_job_success(self, client, mock_response):
        """run_command_runner_job returns execution result on success."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"executionId": "exec-77"},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.run_command_runner_job(
            device_ip="10.1.1.1",
            network="Default",
            commands="show version",
        )

        assert result is not None
        assert result["executionId"] == "exec-77"
        client.lvi_client.post.assert_called_once()

    def test_run_command_runner_job_with_backup(self, client, mock_response):
        """run_command_runner_job passes backup_on_completion=True in job parameters."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"executionId": "exec-78"},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.run_command_runner_job(
            device_ip="10.1.1.2",
            network="Default",
            commands="show run",
            backup_on_completion=True,
        )

        assert result is not None
        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert body["params"]["jobData"]["jobParameters"]["backupOnCompletion"] == "true"

    def test_run_command_runner_job_returns_none_on_failure(self, client, mock_response):
        """run_command_runner_job returns None when API response has no result."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t"}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.run_command_runner_job("10.1.1.1", "Default", "show version")

        assert result is None

    def test_run_command_runner_job_with_custom_description(self, client, mock_response):
        """run_command_runner_job passes custom description when provided."""
        mock_response.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"executionId": "exec-79"},
        }
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.run_command_runner_job(
            device_ip="10.1.1.3",
            network="Default",
            commands="show ip int brief",
            description="Scheduled by CHG001",
        )

        assert result is not None
        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert body["params"]["jobData"]["description"] == "Scheduled by CHG001"


class TestCreateCommandRunnerJobBackupAndDescription:
    """Tests for backup_on_completion and description branches in create_command_runner_job."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_backup_on_completion_true(self, client, mock_response):
        """create_command_runner_job sets backupOnCompletion='true' when True."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": {"jobId": 10}}
        client.lvi_client.post = Mock(return_value=mock_response)

        client.create_command_runner_job("10.1.1.1", "Default", "show version", backup_on_completion=True)

        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert body["params"]["jobData"]["jobParameters"]["backupOnCompletion"] == "true"

    def test_custom_description_used(self, client, mock_response):
        """create_command_runner_job uses the provided description."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": {"jobId": 11}}
        client.lvi_client.post = Mock(return_value=mock_response)

        client.create_command_runner_job("10.1.1.1", "Default", "show version", description="My custom description")

        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert body["params"]["jobData"]["description"] == "My custom description"

    def test_empty_description_defaults_to_service_now_string(self, client, mock_response):
        """create_command_runner_job defaults description when empty string passed."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": {"jobId": 12}}
        client.lvi_client.post = Mock(return_value=mock_response)

        client.create_command_runner_job("10.1.1.1", "Default", "show version", description="")

        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert body["params"]["jobData"]["description"] == "Job scheduled by ServiceNow"


class TestRunJobNowSubTypeBranch:
    """Tests for sub_type branch in run_job_now (line 2196)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_run_job_now_with_sub_type(self, client, mock_response):
        """run_job_now includes subType in payload when sub_type is provided."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": {"executionId": "exec-1"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.run_job_now(
            job_name="Runner",
            job_type="Script Tool Job",
            managed_networks=["Default"],
            job_parameters={},
            sub_type="org.ziptie.tools.scripts.commandRunner",
        )

        assert result is not None
        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert body["params"]["jobData"]["subType"] == "org.ziptie.tools.scripts.commandRunner"

    def test_run_job_now_without_description_falls_back_to_job_type(self, client, mock_response):
        """run_job_now uses job_type as description when description is None (else branch)."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": {"executionId": "exec-2"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        client.run_job_now(
            job_name="Runner",
            job_type="Backup",
            managed_networks=["Default"],
            job_parameters={},
        )

        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        # When description is None, falls to else: description = job_type
        assert body["params"]["jobData"]["description"] == "Backup"


class TestCallMethodWithParamsArgument:
    """Tests for the call() method _params positional argument (line 162)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_call_with_positional_params_list(self, client, mock_response):
        """call() sends _params list directly (not as a dict) when _params is provided."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": ""}
        client.lvi_client.post = Mock(return_value=mock_response)

        client.call("Compliance.isValidRegex", _params=["^test.*"])

        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert body["params"] == ["^test.*"]

    def test_call_with_kwargs_sends_dict_params(self, client, mock_response):
        """call() sends kwargs as dict params when _params is not provided."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": {}}
        client.lvi_client.post = Mock(return_value=mock_response)

        client.call("Test.method", key1="value1", key2="value2")

        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert body["params"] == {"key1": "value1", "key2": "value2"}

    def test_call_logs_and_raises_on_non_ok_response(self, client):
        """call() raises HTTPError when response.ok is False."""
        mock_response = Mock()
        mock_response.ok = False
        mock_response.status_code = 500
        mock_response.text = "Internal Server Error"
        mock_response.raise_for_status.side_effect = requests.HTTPError("500")
        client.lvi_client.post = Mock(return_value=mock_response)

        with pytest.raises(requests.HTTPError):
            client.call("Test.method")


class TestInitializationEnvVarBranches:
    """Tests for env-var-driven initialization paths."""

    def test_verify_ssl_true_from_env(self, monkeypatch):
        """verify_ssl is True when LVI_VERIFY_SSL env var is 'true'."""
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        monkeypatch.setenv("LVI_VERIFY_SSL", "true")
        monkeypatch.delenv("LVI_USERNAME", raising=False)
        monkeypatch.delenv("LVI_PASSWORD", raising=False)

        with patch("src.logicvein.lvi_api_client.requests.Session"):
            client = LogicVeinAPIClient()

        assert client.verify_ssl is True

    def test_verify_kwarg_overrides_env(self, monkeypatch):
        """verify kwarg overrides the LVI_VERIFY_SSL env var."""
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        monkeypatch.setenv("LVI_VERIFY_SSL", "true")

        with patch("src.logicvein.lvi_api_client.requests.Session"):
            client = LogicVeinAPIClient(verify=False)

        assert client.verify_ssl is False

    def test_timeout_from_env(self, monkeypatch):
        """timeout is read from LVI_TIMEOUT env var."""
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        monkeypatch.setenv("LVI_TIMEOUT", "30")
        monkeypatch.delenv("LVI_USERNAME", raising=False)
        monkeypatch.delenv("LVI_PASSWORD", raising=False)

        with patch("src.logicvein.lvi_api_client.requests.Session"):
            client = LogicVeinAPIClient()

        assert client.timeout == 30

    def test_no_auth_header_without_api_token(self, monkeypatch):
        """Authorization header is absent when no API token is configured."""
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.delenv("LVI_API_TOKEN", raising=False)
        monkeypatch.delenv("LVI_USERNAME", raising=False)
        monkeypatch.delenv("LVI_PASSWORD", raising=False)

        with patch("src.logicvein.lvi_api_client.requests.Session"):
            client = LogicVeinAPIClient(ignore_env_vars=True)

        assert "Authorization" not in client.headers


class TestGetArpEntriesNonListNetworks:
    """Test get_arp_entries guard when get_networks returns a non-list (line 831)."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_get_arp_entries_returns_empty_when_networks_not_list(self, client, mock_response):
        """get_arp_entries returns [] when get_networks returns a non-list value."""
        # Simulate get_networks returning a dict instead of a list
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": {"error": "unauthorized"}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_arp_entries("192.168.1.0/24")

        assert result == []


class TestTestConnectionEdgeCases:
    """Additional test_connection edge cases."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_test_connection_returns_true_for_empty_network_list(self, client, mock_response):
        """test_connection returns True when get_networks returns an empty list (not None)."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": []}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.test_connection()

        # [] is not None, so test_connection should return True
        assert result is True

    def test_test_connection_returns_false_when_exception_raised(self, client):
        """test_connection returns False when call() raises an unexpected exception."""
        client.lvi_client.post = Mock(side_effect=RuntimeError("unexpected"))

        result = client.test_connection()

        assert result is False


class TestSaveTriggerWithFilterName:
    """Test save_trigger with non-empty filter_name."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_save_trigger_with_filter_name(self, client, mock_response):
        """save_trigger sends filterName in payload when filter_name is provided."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": {"triggerId": 20}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.save_trigger(
            job_id=5,
            trigger_name="Filtered Trigger",
            cron_expression="0 0 * * *",
            filter_name="my-filter",
        )

        assert result is not None
        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert body["params"]["triggerData"]["filterName"] == "my-filter"

    def test_save_trigger_paused_false_by_default(self, client, mock_response):
        """save_trigger sends paused=False by default."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": {"triggerId": 21}}
        client.lvi_client.post = Mock(return_value=mock_response)

        client.save_trigger(job_id=6, trigger_name="T", cron_expression="0 * * * *")

        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert body["params"]["triggerData"]["paused"] is False


class TestFindSwitchPortForHostNoCallWhenNetworksEmpty:
    """Test find_switch_port_for_host when get_networks() returns empty — no API call made."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_returns_none_when_auto_fetched_networks_empty(self, client, mock_response):
        """find_switch_port_for_host returns None when get_networks() returns []."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": []}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.find_switch_port_for_host("192.168.1.99")

        assert result is None

    def test_find_switch_port_returns_none_when_call_has_no_result(self, client, mock_response):
        """find_switch_port_for_host returns None when findSwitchPort result is absent."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t"}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.find_switch_port_for_host("192.168.1.99", networks=["Default"])

        assert result is None


class TestGetAllRuleSetsAutoFetch:
    """Test get_all_rule_sets when get_networks is called automatically."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_get_all_rule_sets_auto_fetches_networks(self, client):
        """get_all_rule_sets calls get_networks then getRuleSets when networks=[]."""
        networks_resp = Mock()
        networks_resp.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": ["Default"]}
        networks_resp.raise_for_status = Mock()
        rule_sets_resp = Mock()
        rule_sets_resp.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": [{"ruleSetId": 5, "name": "My Rules"}],
        }
        rule_sets_resp.raise_for_status = Mock()
        client.lvi_client.post = Mock(side_effect=[networks_resp, rule_sets_resp])

        result = client.get_all_rule_sets()

        assert len(result) == 1
        assert client.lvi_client.post.call_count == 2


class TestGetConfigRevisionWithTimestamp:
    """Test get_device_configuration_revision with a non-None timestamp."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_revision_with_timestamp_param(self, client, mock_response):
        """get_device_configuration_revision passes timestamp to call when provided."""
        config_content = "hostname router-01\n"
        import base64 as _b64

        encoded = _b64.b64encode(config_content.encode()).decode()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": {"content": encoded}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_device_configuration_revision("192.168.1.1", timestamp=1700000000)

        assert result == config_content
        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert body["params"]["timestamp"] == 1700000000

    def test_revision_with_custom_config_path(self, client, mock_response):
        """get_device_configuration_revision passes custom config_path to call."""
        config_content = "startup-config content\n"
        import base64 as _b64

        encoded = _b64.b64encode(config_content.encode()).decode()
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": {"content": encoded}}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.get_device_configuration_revision("192.168.1.1", config_path="/startup-config")

        assert result == config_content
        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert body["params"]["configPath"] == "/startup-config"


class TestUpdateDevicesResultNoneString:
    """Test update_devices when API returns the string 'None' rather than None."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def test_update_devices_result_none_string(self, client, mock_response):
        """update_devices returns True when API result is the string 'None'."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": "None"}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.update_devices([{"ipAddress": "1.2.3.4"}])

        assert result is True

    def test_update_device_values_result_none_string(self, client, mock_response):
        """update_device_values returns True when API result is the string 'None'."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": "None"}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.update_device_values("1.2.3.4", adapter_id="Cisco::IOS")

        assert result is True

    def test_update_custom_fields_result_none_string(self, client, mock_response):
        """update_custom_fields returns True when API result is the string 'None'."""
        mock_response.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": "None"}
        client.lvi_client.post = Mock(return_value=mock_response)

        result = client.update_custom_fields("1.2.3.4", custom_fields={"custom1": "v1"})

        assert result is True


class TestGetConfigHistory:
    """Unit tests for get_config_history."""

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.setenv("LVI_HOST", "test.example.com")
        monkeypatch.setenv("LVI_API_TOKEN", "test-token")
        with patch("src.logicvein.lvi_api_client.requests.Session"):
            return LogicVeinAPIClient()

    def _make_response(self, items, ok=True):
        r = Mock()
        r.ok = ok
        r.json.return_value = {
            "jsonrpc": "2.0",
            "id": "t",
            "result": {"configHistoryItems": items, "total": len(items)},
        }
        return r

    def test_returns_items_on_success(self, client):
        """Returns the list of config history items from the API."""
        items = [{"session": "s1", "ipAddress": "1.2.3.4"}, {"session": "s2", "ipAddress": "1.2.3.5"}]
        client.lvi_client.post = Mock(return_value=self._make_response(items))

        result = client.get_config_history(networks=["Default"])

        assert result == items

    def test_default_networks_is_default(self, client):
        """When networks is not provided, defaults to ['Default']."""
        client.lvi_client.post = Mock(return_value=self._make_response([]))

        client.get_config_history()

        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        assert body["params"]["networks"] == ["Default"]

    def test_request_body_contains_all_params(self, client):
        """All parameters are forwarded correctly in the request body."""
        client.lvi_client.post = Mock(return_value=self._make_response([]))

        client.get_config_history(
            networks=["Net1", "Net2"],
            data="filter",
            descending=False,
            scheme="ssh",
            sort_column="ipAddress",
            page_size=50,
        )

        body = json.loads(client.lvi_client.post.call_args.kwargs["data"])
        params = body["params"]
        assert body["method"] == "Configuration.retrieveConfigHistory"
        assert params["networks"] == ["Net1", "Net2"]
        assert params["data"] == "filter"
        assert params["descending"] is False
        assert params["scheme"] == "ssh"
        assert params["sortColumn"] == "ipAddress"
        assert params["pageData"]["pageSize"] == 50

    def test_paginates_until_partial_page(self, client):
        """Fetches subsequent pages until a page smaller than page_size is returned."""
        page1 = [{"session": f"s{i}"} for i in range(3)]
        page2 = [{"session": "s3"}]

        responses = [self._make_response(page1, ok=True), self._make_response(page2, ok=True)]
        client.lvi_client.post = Mock(side_effect=responses)

        result = client.get_config_history(networks=["Default"], page_size=3)

        assert len(result) == 4
        assert client.lvi_client.post.call_count == 2
        # Second call should have offset=3
        body2 = json.loads(client.lvi_client.post.call_args_list[1].kwargs["data"])
        assert body2["params"]["pageData"]["offset"] == 3

    def test_returns_empty_list_on_missing_result_key(self, client):
        """Returns [] when the API response has no 'result' key."""
        r = Mock()
        r.ok = True
        r.json.return_value = {"jsonrpc": "2.0", "id": "t"}
        client.lvi_client.post = Mock(return_value=r)

        result = client.get_config_history()

        assert result == []

    def test_returns_empty_list_on_missing_items_key(self, client):
        """Returns [] when 'result' exists but lacks 'configHistoryItems'."""
        r = Mock()
        r.ok = True
        r.json.return_value = {"jsonrpc": "2.0", "id": "t", "result": {"total": 0}}
        client.lvi_client.post = Mock(return_value=r)

        result = client.get_config_history()

        assert result == []

    def test_raises_on_connection_error(self, client):
        """ConnectionError from the HTTP layer propagates to the caller."""
        client.lvi_client.post = Mock(side_effect=requests.exceptions.ConnectionError("timeout"))

        with pytest.raises(requests.exceptions.ConnectionError):
            client.get_config_history()
