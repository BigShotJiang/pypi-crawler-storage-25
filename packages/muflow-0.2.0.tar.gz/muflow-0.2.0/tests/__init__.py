"""Tests for muflow."""
