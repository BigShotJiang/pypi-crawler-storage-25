# Changelog

## 0.0.3 (2026-04-08)

Full Changelog: [v0.0.2...v0.0.3](https://github.com/Seeknetic/seeknetic-sdk-python/compare/v0.0.2...v0.0.3)

### Chores

* update SDK settings ([9c9f865](https://github.com/Seeknetic/seeknetic-sdk-python/commit/9c9f8658b83cabde04b04488aa4a3b80027bcde0))
* update SDK settings ([600e638](https://github.com/Seeknetic/seeknetic-sdk-python/commit/600e638ae2c9c2b17d4564ebb9b8db5a2f35df4d))

## 0.0.2 (2026-04-08)

Full Changelog: [v0.0.1...v0.0.2](https://github.com/Seeknetic/seeknetic-sdk-python/compare/v0.0.1...v0.0.2)

### Chores

* sync repo ([e571ae3](https://github.com/Seeknetic/seeknetic-sdk-python/commit/e571ae3f6fd7b0a57aa97e77688284510e139fea))
* update SDK settings ([8ad01ed](https://github.com/Seeknetic/seeknetic-sdk-python/commit/8ad01ed63e0c95d8f74fbcd9a06101896c85df65))
* update SDK settings ([f8908a7](https://github.com/Seeknetic/seeknetic-sdk-python/commit/f8908a716b8ffbd8f518798ff21be29fd03e4e65))
* update SDK settings ([7ee1f79](https://github.com/Seeknetic/seeknetic-sdk-python/commit/7ee1f791d6e55cadda5723808a8e0ebf9e8de6ea))
* update SDK settings ([027616c](https://github.com/Seeknetic/seeknetic-sdk-python/commit/027616c7de6a2a0a46812637e0a6621ec3c0f3ce))
* update SDK settings ([bf270d6](https://github.com/Seeknetic/seeknetic-sdk-python/commit/bf270d6bc2cbad2392f1da5e9f2ab7639a626db0))
* update SDK settings ([e2b2692](https://github.com/Seeknetic/seeknetic-sdk-python/commit/e2b2692ddca81c2c27f3b1eb0c97bf5ec29a5cce))
