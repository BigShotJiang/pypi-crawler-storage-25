# Files

## Upload

Types:

```python
from seeknetic.types.files import TensorDict, UploadUploadTensorResponse
```

Methods:

- <code title="post /files/upload/tensors">client.files.upload.<a href="./src/seeknetic/resources/files/upload.py">upload_tensor</a>(\*\*<a href="src/seeknetic/types/files/upload_upload_tensor_params.py">params</a>) -> <a href="./src/seeknetic/types/files/upload_upload_tensor_response.py">UploadUploadTensorResponse</a></code>

# VideoEmbedding

Types:

```python
from seeknetic.types import VideoEmbeddingEncodeTextResponse
```

Methods:

- <code title="post /video_embedding/encode_text">client.video_embedding.<a href="./src/seeknetic/resources/video_embedding/video_embedding.py">encode_text</a>(\*\*<a href="src/seeknetic/types/video_embedding_encode_text_params.py">params</a>) -> <a href="./src/seeknetic/types/video_embedding_encode_text_response.py">VideoEmbeddingEncodeTextResponse</a></code>

## EncodeVideo

Types:

```python
from seeknetic.types.video_embedding import AsyncSubmitResponse
```

Methods:

- <code title="post /video_embedding/encode_video/async">client.video_embedding.encode_video.<a href="./src/seeknetic/resources/video_embedding/encode_video.py">submit_async</a>(\*\*<a href="src/seeknetic/types/video_embedding/encode_video_submit_async_params.py">params</a>) -> <a href="./src/seeknetic/types/video_embedding/async_submit_response.py">AsyncSubmitResponse</a></code>

# VideoTagging

Methods:

- <code title="post /video_tagging/async">client.video_tagging.<a href="./src/seeknetic/resources/video_tagging.py">submit_async_job</a>(\*\*<a href="src/seeknetic/types/video_tagging_submit_async_job_params.py">params</a>) -> <a href="./src/seeknetic/types/video_embedding/async_submit_response.py">AsyncSubmitResponse</a></code>

# AsyncStatus

Types:

```python
from seeknetic.types import AsyncStatusRetrieveResponse
```

Methods:

- <code title="get /async_status/{request_id}">client.async_status.<a href="./src/seeknetic/resources/async_status.py">retrieve</a>(request_id) -> <a href="./src/seeknetic/types/async_status_retrieve_response.py">AsyncStatusRetrieveResponse</a></code>
