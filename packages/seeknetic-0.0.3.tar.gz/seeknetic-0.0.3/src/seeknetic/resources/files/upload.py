# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Literal

import httpx

from ..._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...types.files import upload_upload_tensor_params
from ..._base_client import make_request_options
from ...types.files.tensor_dict_param import TensorDictParam
from ...types.files.upload_upload_tensor_response import UploadUploadTensorResponse

__all__ = ["UploadResource", "AsyncUploadResource"]


class UploadResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> UploadResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Seeknetic/seeknetic-sdk-python#accessing-raw-response-data-eg-headers
        """
        return UploadResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> UploadResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Seeknetic/seeknetic-sdk-python#with_streaming_response
        """
        return UploadResourceWithStreamingResponse(self)

    def upload_tensor(
        self,
        *,
        audio_input: TensorDictParam | Omit = omit,
        request_id: str | Omit = omit,
        service: Literal["embedding", "tagging"] | Omit = omit,
        video_input: upload_upload_tensor_params.VideoInput | Omit = omit,
        video_kwargs: Dict[str, object] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> UploadUploadTensorResponse:
        """Hosted under https://api.seeknetic.com/files.

        Requires authentication. Accepts
        structured tensor JSON and returns R2 keys that can be used by async embedding
        or tagging endpoints.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/files/upload/tensors",
            body=maybe_transform(
                {
                    "audio_input": audio_input,
                    "request_id": request_id,
                    "service": service,
                    "video_input": video_input,
                    "video_kwargs": video_kwargs,
                },
                upload_upload_tensor_params.UploadUploadTensorParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=UploadUploadTensorResponse,
        )


class AsyncUploadResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncUploadResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Seeknetic/seeknetic-sdk-python#accessing-raw-response-data-eg-headers
        """
        return AsyncUploadResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncUploadResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Seeknetic/seeknetic-sdk-python#with_streaming_response
        """
        return AsyncUploadResourceWithStreamingResponse(self)

    async def upload_tensor(
        self,
        *,
        audio_input: TensorDictParam | Omit = omit,
        request_id: str | Omit = omit,
        service: Literal["embedding", "tagging"] | Omit = omit,
        video_input: upload_upload_tensor_params.VideoInput | Omit = omit,
        video_kwargs: Dict[str, object] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> UploadUploadTensorResponse:
        """Hosted under https://api.seeknetic.com/files.

        Requires authentication. Accepts
        structured tensor JSON and returns R2 keys that can be used by async embedding
        or tagging endpoints.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/files/upload/tensors",
            body=await async_maybe_transform(
                {
                    "audio_input": audio_input,
                    "request_id": request_id,
                    "service": service,
                    "video_input": video_input,
                    "video_kwargs": video_kwargs,
                },
                upload_upload_tensor_params.UploadUploadTensorParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=UploadUploadTensorResponse,
        )


class UploadResourceWithRawResponse:
    def __init__(self, upload: UploadResource) -> None:
        self._upload = upload

        self.upload_tensor = to_raw_response_wrapper(
            upload.upload_tensor,
        )


class AsyncUploadResourceWithRawResponse:
    def __init__(self, upload: AsyncUploadResource) -> None:
        self._upload = upload

        self.upload_tensor = async_to_raw_response_wrapper(
            upload.upload_tensor,
        )


class UploadResourceWithStreamingResponse:
    def __init__(self, upload: UploadResource) -> None:
        self._upload = upload

        self.upload_tensor = to_streamed_response_wrapper(
            upload.upload_tensor,
        )


class AsyncUploadResourceWithStreamingResponse:
    def __init__(self, upload: AsyncUploadResource) -> None:
        self._upload = upload

        self.upload_tensor = async_to_streamed_response_wrapper(
            upload.upload_tensor,
        )
