# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ...types import video_embedding_encode_text_params
from ..._types import Body, Query, Headers, NotGiven, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .encode_video import (
    EncodeVideoResource,
    AsyncEncodeVideoResource,
    EncodeVideoResourceWithRawResponse,
    AsyncEncodeVideoResourceWithRawResponse,
    EncodeVideoResourceWithStreamingResponse,
    AsyncEncodeVideoResourceWithStreamingResponse,
)
from ..._base_client import make_request_options
from ...types.video_embedding_encode_text_response import VideoEmbeddingEncodeTextResponse

__all__ = ["VideoEmbeddingResource", "AsyncVideoEmbeddingResource"]


class VideoEmbeddingResource(SyncAPIResource):
    @cached_property
    def encode_video(self) -> EncodeVideoResource:
        return EncodeVideoResource(self._client)

    @cached_property
    def with_raw_response(self) -> VideoEmbeddingResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Seeknetic/seeknetic-sdk-python#accessing-raw-response-data-eg-headers
        """
        return VideoEmbeddingResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> VideoEmbeddingResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Seeknetic/seeknetic-sdk-python#with_streaming_response
        """
        return VideoEmbeddingResourceWithStreamingResponse(self)

    def encode_text(
        self,
        *,
        text: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> VideoEmbeddingEncodeTextResponse:
        """Requires authentication.

        Accepts JSON with required text.

        Args:
          text: Text to encode

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/video_embedding/encode_text",
            body=maybe_transform({"text": text}, video_embedding_encode_text_params.VideoEmbeddingEncodeTextParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=VideoEmbeddingEncodeTextResponse,
        )


class AsyncVideoEmbeddingResource(AsyncAPIResource):
    @cached_property
    def encode_video(self) -> AsyncEncodeVideoResource:
        return AsyncEncodeVideoResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncVideoEmbeddingResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Seeknetic/seeknetic-sdk-python#accessing-raw-response-data-eg-headers
        """
        return AsyncVideoEmbeddingResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncVideoEmbeddingResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Seeknetic/seeknetic-sdk-python#with_streaming_response
        """
        return AsyncVideoEmbeddingResourceWithStreamingResponse(self)

    async def encode_text(
        self,
        *,
        text: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> VideoEmbeddingEncodeTextResponse:
        """Requires authentication.

        Accepts JSON with required text.

        Args:
          text: Text to encode

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/video_embedding/encode_text",
            body=await async_maybe_transform(
                {"text": text}, video_embedding_encode_text_params.VideoEmbeddingEncodeTextParams
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=VideoEmbeddingEncodeTextResponse,
        )


class VideoEmbeddingResourceWithRawResponse:
    def __init__(self, video_embedding: VideoEmbeddingResource) -> None:
        self._video_embedding = video_embedding

        self.encode_text = to_raw_response_wrapper(
            video_embedding.encode_text,
        )

    @cached_property
    def encode_video(self) -> EncodeVideoResourceWithRawResponse:
        return EncodeVideoResourceWithRawResponse(self._video_embedding.encode_video)


class AsyncVideoEmbeddingResourceWithRawResponse:
    def __init__(self, video_embedding: AsyncVideoEmbeddingResource) -> None:
        self._video_embedding = video_embedding

        self.encode_text = async_to_raw_response_wrapper(
            video_embedding.encode_text,
        )

    @cached_property
    def encode_video(self) -> AsyncEncodeVideoResourceWithRawResponse:
        return AsyncEncodeVideoResourceWithRawResponse(self._video_embedding.encode_video)


class VideoEmbeddingResourceWithStreamingResponse:
    def __init__(self, video_embedding: VideoEmbeddingResource) -> None:
        self._video_embedding = video_embedding

        self.encode_text = to_streamed_response_wrapper(
            video_embedding.encode_text,
        )

    @cached_property
    def encode_video(self) -> EncodeVideoResourceWithStreamingResponse:
        return EncodeVideoResourceWithStreamingResponse(self._video_embedding.encode_video)


class AsyncVideoEmbeddingResourceWithStreamingResponse:
    def __init__(self, video_embedding: AsyncVideoEmbeddingResource) -> None:
        self._video_embedding = video_embedding

        self.encode_text = async_to_streamed_response_wrapper(
            video_embedding.encode_text,
        )

    @cached_property
    def encode_video(self) -> AsyncEncodeVideoResourceWithStreamingResponse:
        return AsyncEncodeVideoResourceWithStreamingResponse(self._video_embedding.encode_video)
