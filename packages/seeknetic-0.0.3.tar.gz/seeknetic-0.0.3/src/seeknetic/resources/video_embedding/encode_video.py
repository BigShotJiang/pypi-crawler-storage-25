# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.video_embedding import encode_video_submit_async_params
from ...types.video_embedding.async_submit_response import AsyncSubmitResponse

__all__ = ["EncodeVideoResource", "AsyncEncodeVideoResource"]


class EncodeVideoResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> EncodeVideoResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Seeknetic/seeknetic-sdk-python#accessing-raw-response-data-eg-headers
        """
        return EncodeVideoResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> EncodeVideoResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Seeknetic/seeknetic-sdk-python#with_streaming_response
        """
        return EncodeVideoResourceWithStreamingResponse(self)

    def submit_async(
        self,
        *,
        filename: str | Omit = omit,
        request_id: str | Omit = omit,
        tensor: encode_video_submit_async_params.Tensor | Omit = omit,
        video_base64: str | Omit = omit,
        video_url: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncSubmitResponse:
        """Requires authentication.

        Supports raw video input via video_url or video_base64,
        or preprocessed tensors via tensor.video_input_key and tensor.audio_input_key.
        Optional request_id is supported in tensor mode.

        Args:
          filename: Optional filename when video_base64 is used. Defaults to video.mp4.

          request_id: Optional custom request ID. Used with tensor mode.

          tensor: Preprocessed tensor mode. Provide at least one tensor key.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/video_embedding/encode_video/async",
            body=maybe_transform(
                {
                    "filename": filename,
                    "request_id": request_id,
                    "tensor": tensor,
                    "video_base64": video_base64,
                    "video_url": video_url,
                },
                encode_video_submit_async_params.EncodeVideoSubmitAsyncParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AsyncSubmitResponse,
        )


class AsyncEncodeVideoResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncEncodeVideoResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Seeknetic/seeknetic-sdk-python#accessing-raw-response-data-eg-headers
        """
        return AsyncEncodeVideoResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncEncodeVideoResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Seeknetic/seeknetic-sdk-python#with_streaming_response
        """
        return AsyncEncodeVideoResourceWithStreamingResponse(self)

    async def submit_async(
        self,
        *,
        filename: str | Omit = omit,
        request_id: str | Omit = omit,
        tensor: encode_video_submit_async_params.Tensor | Omit = omit,
        video_base64: str | Omit = omit,
        video_url: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncSubmitResponse:
        """Requires authentication.

        Supports raw video input via video_url or video_base64,
        or preprocessed tensors via tensor.video_input_key and tensor.audio_input_key.
        Optional request_id is supported in tensor mode.

        Args:
          filename: Optional filename when video_base64 is used. Defaults to video.mp4.

          request_id: Optional custom request ID. Used with tensor mode.

          tensor: Preprocessed tensor mode. Provide at least one tensor key.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/video_embedding/encode_video/async",
            body=await async_maybe_transform(
                {
                    "filename": filename,
                    "request_id": request_id,
                    "tensor": tensor,
                    "video_base64": video_base64,
                    "video_url": video_url,
                },
                encode_video_submit_async_params.EncodeVideoSubmitAsyncParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AsyncSubmitResponse,
        )


class EncodeVideoResourceWithRawResponse:
    def __init__(self, encode_video: EncodeVideoResource) -> None:
        self._encode_video = encode_video

        self.submit_async = to_raw_response_wrapper(
            encode_video.submit_async,
        )


class AsyncEncodeVideoResourceWithRawResponse:
    def __init__(self, encode_video: AsyncEncodeVideoResource) -> None:
        self._encode_video = encode_video

        self.submit_async = async_to_raw_response_wrapper(
            encode_video.submit_async,
        )


class EncodeVideoResourceWithStreamingResponse:
    def __init__(self, encode_video: EncodeVideoResource) -> None:
        self._encode_video = encode_video

        self.submit_async = to_streamed_response_wrapper(
            encode_video.submit_async,
        )


class AsyncEncodeVideoResourceWithStreamingResponse:
    def __init__(self, encode_video: AsyncEncodeVideoResource) -> None:
        self._encode_video = encode_video

        self.submit_async = async_to_streamed_response_wrapper(
            encode_video.submit_async,
        )
