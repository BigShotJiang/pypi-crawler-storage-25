# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from .._types import Body, Query, Headers, NotGiven, not_given
from .._utils import path_template
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.async_status_retrieve_response import AsyncStatusRetrieveResponse

__all__ = ["AsyncStatusResource", "AsyncAsyncStatusResource"]


class AsyncStatusResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncStatusResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Seeknetic/seeknetic-sdk-python#accessing-raw-response-data-eg-headers
        """
        return AsyncStatusResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncStatusResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Seeknetic/seeknetic-sdk-python#with_streaming_response
        """
        return AsyncStatusResourceWithStreamingResponse(self)

    def retrieve(
        self,
        request_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncStatusRetrieveResponse:
        """Requires authentication.

        Queries the current status and result of an async
        embedding or tagging request.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not request_id:
            raise ValueError(f"Expected a non-empty value for `request_id` but received {request_id!r}")
        return self._get(
            path_template("/async_status/{request_id}", request_id=request_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AsyncStatusRetrieveResponse,
        )


class AsyncAsyncStatusResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncAsyncStatusResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Seeknetic/seeknetic-sdk-python#accessing-raw-response-data-eg-headers
        """
        return AsyncAsyncStatusResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncAsyncStatusResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Seeknetic/seeknetic-sdk-python#with_streaming_response
        """
        return AsyncAsyncStatusResourceWithStreamingResponse(self)

    async def retrieve(
        self,
        request_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncStatusRetrieveResponse:
        """Requires authentication.

        Queries the current status and result of an async
        embedding or tagging request.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not request_id:
            raise ValueError(f"Expected a non-empty value for `request_id` but received {request_id!r}")
        return await self._get(
            path_template("/async_status/{request_id}", request_id=request_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AsyncStatusRetrieveResponse,
        )


class AsyncStatusResourceWithRawResponse:
    def __init__(self, async_status: AsyncStatusResource) -> None:
        self._async_status = async_status

        self.retrieve = to_raw_response_wrapper(
            async_status.retrieve,
        )


class AsyncAsyncStatusResourceWithRawResponse:
    def __init__(self, async_status: AsyncAsyncStatusResource) -> None:
        self._async_status = async_status

        self.retrieve = async_to_raw_response_wrapper(
            async_status.retrieve,
        )


class AsyncStatusResourceWithStreamingResponse:
    def __init__(self, async_status: AsyncStatusResource) -> None:
        self._async_status = async_status

        self.retrieve = to_streamed_response_wrapper(
            async_status.retrieve,
        )


class AsyncAsyncStatusResourceWithStreamingResponse:
    def __init__(self, async_status: AsyncAsyncStatusResource) -> None:
        self._async_status = async_status

        self.retrieve = async_to_streamed_response_wrapper(
            async_status.retrieve,
        )
