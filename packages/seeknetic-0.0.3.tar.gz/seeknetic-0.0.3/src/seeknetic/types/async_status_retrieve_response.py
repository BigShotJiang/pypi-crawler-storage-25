# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Optional
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["AsyncStatusRetrieveResponse"]


class AsyncStatusRetrieveResponse(BaseModel):
    created_at: Optional[datetime] = None

    embedding: Optional[List[float]] = None

    error_message: Optional[str] = None

    api_model_name: Optional[str] = FieldInfo(alias="model_name", default=None)

    request_id: Optional[str] = None

    status: Optional[Literal["pending", "processing", "completed", "failed"]] = None

    tags: Optional[Dict[str, object]] = None

    task_type: Optional[str] = None

    updated_at: Optional[datetime] = None
