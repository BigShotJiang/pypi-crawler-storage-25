# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["VideoTaggingSubmitAsyncJobParams", "Tensor"]


class VideoTaggingSubmitAsyncJobParams(TypedDict, total=False):
    filename: str
    """Optional filename when video_base64 is used. Defaults to video.mp4."""

    request_id: str
    """Optional custom request ID. Used with tensor mode."""

    tensor: Tensor
    """Preprocessed tensor mode. Provide at least one tensor key."""

    video_base64: str

    video_url: str


class Tensor(TypedDict, total=False):
    """Preprocessed tensor mode. Provide at least one tensor key."""

    video_input_key: str

    video_kwargs_key: str
