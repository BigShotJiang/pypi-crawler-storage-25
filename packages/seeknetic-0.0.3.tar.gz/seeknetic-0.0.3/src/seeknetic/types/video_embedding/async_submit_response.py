# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from typing_extensions import Literal

from ..._models import BaseModel

__all__ = ["AsyncSubmitResponse"]


class AsyncSubmitResponse(BaseModel):
    message: Optional[str] = None

    request_id: Optional[str] = None

    status: Optional[str] = None

    task_type: Optional[Literal["embedding", "tagging"]] = None
