# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable
from typing_extensions import Literal, Required, TypedDict

__all__ = ["TensorDictParam"]


class TensorDictParam(TypedDict, total=False):
    data: Required[str]
    """Base64 encoded numpy buffer"""

    dtype: Required[Literal["float32", "float64", "uint8"]]

    shape: Required[Iterable[int]]
