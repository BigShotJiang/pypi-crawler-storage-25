# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union
from typing_extensions import Literal, Required, TypeAlias, TypedDict

from .tensor_dict_param import TensorDictParam

__all__ = ["UploadUploadTensorParams", "VideoInput", "VideoInputVideoInputWithMetadata"]


class UploadUploadTensorParams(TypedDict, total=False):
    audio_input: TensorDictParam

    request_id: str

    service: Literal["embedding", "tagging"]

    video_input: VideoInput

    video_kwargs: Dict[str, object]


class VideoInputVideoInputWithMetadata(TypedDict, total=False):
    tensor: Required[TensorDictParam]

    metadata: Dict[str, object]


VideoInput: TypeAlias = Union[TensorDictParam, VideoInputVideoInputWithMetadata]
