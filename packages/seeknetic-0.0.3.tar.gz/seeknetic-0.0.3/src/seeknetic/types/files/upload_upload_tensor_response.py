# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict
from typing_extensions import Literal

from ..._models import BaseModel

__all__ = ["UploadUploadTensorResponse"]


class UploadUploadTensorResponse(BaseModel):
    r2_keys: Dict[str, str]
    """Uploaded R2 object keys, such as video_input, audio_input, and video_kwargs."""

    request_id: str

    status: Literal["uploaded"]
