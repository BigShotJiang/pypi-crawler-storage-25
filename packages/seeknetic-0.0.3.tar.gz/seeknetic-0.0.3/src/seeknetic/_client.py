# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Any, Mapping
from typing_extensions import Self, override

import httpx

from . import _exceptions
from ._qs import Querystring
from ._types import (
    Omit,
    Headers,
    Timeout,
    NotGiven,
    Transport,
    ProxiesTypes,
    RequestOptions,
    not_given,
)
from ._utils import is_given, get_async_library
from ._compat import cached_property
from ._models import SecurityOptions
from ._version import __version__
from ._streaming import Stream as Stream, AsyncStream as AsyncStream
from ._exceptions import APIStatusError
from ._base_client import (
    DEFAULT_MAX_RETRIES,
    SyncAPIClient,
    AsyncAPIClient,
)

if TYPE_CHECKING:
    from .resources import files, async_status, video_tagging, video_embedding
    from .resources.files.files import FilesResource, AsyncFilesResource
    from .resources.async_status import AsyncStatusResource, AsyncAsyncStatusResource
    from .resources.video_tagging import VideoTaggingResource, AsyncVideoTaggingResource
    from .resources.video_embedding.video_embedding import VideoEmbeddingResource, AsyncVideoEmbeddingResource

__all__ = [
    "Timeout",
    "Transport",
    "ProxiesTypes",
    "RequestOptions",
    "Seeknetic",
    "AsyncSeeknetic",
    "Client",
    "AsyncClient",
]


class Seeknetic(SyncAPIClient):
    # client options
    api_key: str | None
    bearer_token: str | None

    def __init__(
        self,
        *,
        api_key: str | None = None,
        bearer_token: str | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        # Configure a custom httpx client.
        # We provide a `DefaultHttpxClient` class that you can pass to retain the default values we use for `limits`, `timeout` & `follow_redirects`.
        # See the [httpx documentation](https://www.python-httpx.org/api/#client) for more details.
        http_client: httpx.Client | None = None,
        # Enable or disable schema validation for data returned by the API.
        # When enabled an error APIResponseValidationError is raised
        # if the API responds with invalid data for the expected schema.
        #
        # This parameter may be removed or changed in the future.
        # If you rely on this feature, please open a GitHub issue
        # outlining your use-case to help us decide if it should be
        # part of our public interface in the future.
        _strict_response_validation: bool = False,
    ) -> None:
        """Construct a new synchronous Seeknetic client instance.

        This automatically infers the following arguments from their corresponding environment variables if they are not provided:
        - `api_key` from `SEEKNETIC_API_KEY`
        - `bearer_token` from `SEEKNETIC_BEARER_TOKEN`
        """
        if api_key is None:
            api_key = os.environ.get("SEEKNETIC_API_KEY")
        self.api_key = api_key

        if bearer_token is None:
            bearer_token = os.environ.get("SEEKNETIC_BEARER_TOKEN")
        self.bearer_token = bearer_token

        if base_url is None:
            base_url = os.environ.get("SEEKNETIC_BASE_URL")
        if base_url is None:
            base_url = f"https://api.seeknetic.com"

        super().__init__(
            version=__version__,
            base_url=base_url,
            max_retries=max_retries,
            timeout=timeout,
            http_client=http_client,
            custom_headers=default_headers,
            custom_query=default_query,
            _strict_response_validation=_strict_response_validation,
        )

    @cached_property
    def files(self) -> FilesResource:
        from .resources.files import FilesResource

        return FilesResource(self)

    @cached_property
    def video_embedding(self) -> VideoEmbeddingResource:
        from .resources.video_embedding import VideoEmbeddingResource

        return VideoEmbeddingResource(self)

    @cached_property
    def video_tagging(self) -> VideoTaggingResource:
        from .resources.video_tagging import VideoTaggingResource

        return VideoTaggingResource(self)

    @cached_property
    def async_status(self) -> AsyncStatusResource:
        from .resources.async_status import AsyncStatusResource

        return AsyncStatusResource(self)

    @cached_property
    def with_raw_response(self) -> SeekneticWithRawResponse:
        return SeekneticWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> SeekneticWithStreamedResponse:
        return SeekneticWithStreamedResponse(self)

    @property
    @override
    def qs(self) -> Querystring:
        return Querystring(array_format="comma")

    @override
    def _auth_headers(self, security: SecurityOptions) -> dict[str, str]:
        return {
            **(self._api_key_auth if security.get("api_key_auth", False) else {}),
            **(self._bearer_auth if security.get("bearer_auth", False) else {}),
        }

    @property
    def _api_key_auth(self) -> dict[str, str]:
        api_key = self.api_key
        if api_key is None:
            return {}
        return {"X-API-Key": api_key}

    @property
    def _bearer_auth(self) -> dict[str, str]:
        bearer_token = self.bearer_token
        if bearer_token is None:
            return {}
        return {"Authorization": f"Bearer {bearer_token}"}

    @property
    @override
    def default_headers(self) -> dict[str, str | Omit]:
        return {
            **super().default_headers,
            "X-Stainless-Async": "false",
            **self._custom_headers,
        }

    @override
    def _validate_headers(self, headers: Headers, custom_headers: Headers) -> None:
        if headers.get("X-API-Key") or isinstance(custom_headers.get("X-API-Key"), Omit):
            return

        if headers.get("Authorization") or isinstance(custom_headers.get("Authorization"), Omit):
            return

        raise TypeError(
            '"Could not resolve authentication method. Expected either api_key or bearer_token to be set. Or for one of the `X-API-Key` or `Authorization` headers to be explicitly omitted"'
        )

    def copy(
        self,
        *,
        api_key: str | None = None,
        bearer_token: str | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        http_client: httpx.Client | None = None,
        max_retries: int | NotGiven = not_given,
        default_headers: Mapping[str, str] | None = None,
        set_default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        set_default_query: Mapping[str, object] | None = None,
        _extra_kwargs: Mapping[str, Any] = {},
    ) -> Self:
        """
        Create a new client instance re-using the same options given to the current client with optional overriding.
        """
        if default_headers is not None and set_default_headers is not None:
            raise ValueError("The `default_headers` and `set_default_headers` arguments are mutually exclusive")

        if default_query is not None and set_default_query is not None:
            raise ValueError("The `default_query` and `set_default_query` arguments are mutually exclusive")

        headers = self._custom_headers
        if default_headers is not None:
            headers = {**headers, **default_headers}
        elif set_default_headers is not None:
            headers = set_default_headers

        params = self._custom_query
        if default_query is not None:
            params = {**params, **default_query}
        elif set_default_query is not None:
            params = set_default_query

        http_client = http_client or self._client
        return self.__class__(
            api_key=api_key or self.api_key,
            bearer_token=bearer_token or self.bearer_token,
            base_url=base_url or self.base_url,
            timeout=self.timeout if isinstance(timeout, NotGiven) else timeout,
            http_client=http_client,
            max_retries=max_retries if is_given(max_retries) else self.max_retries,
            default_headers=headers,
            default_query=params,
            **_extra_kwargs,
        )

    # Alias for `copy` for nicer inline usage, e.g.
    # client.with_options(timeout=10).foo.create(...)
    with_options = copy

    @override
    def _make_status_error(
        self,
        err_msg: str,
        *,
        body: object,
        response: httpx.Response,
    ) -> APIStatusError:
        if response.status_code == 400:
            return _exceptions.BadRequestError(err_msg, response=response, body=body)

        if response.status_code == 401:
            return _exceptions.AuthenticationError(err_msg, response=response, body=body)

        if response.status_code == 403:
            return _exceptions.PermissionDeniedError(err_msg, response=response, body=body)

        if response.status_code == 404:
            return _exceptions.NotFoundError(err_msg, response=response, body=body)

        if response.status_code == 409:
            return _exceptions.ConflictError(err_msg, response=response, body=body)

        if response.status_code == 422:
            return _exceptions.UnprocessableEntityError(err_msg, response=response, body=body)

        if response.status_code == 429:
            return _exceptions.RateLimitError(err_msg, response=response, body=body)

        if response.status_code >= 500:
            return _exceptions.InternalServerError(err_msg, response=response, body=body)
        return APIStatusError(err_msg, response=response, body=body)


class AsyncSeeknetic(AsyncAPIClient):
    # client options
    api_key: str | None
    bearer_token: str | None

    def __init__(
        self,
        *,
        api_key: str | None = None,
        bearer_token: str | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        # Configure a custom httpx client.
        # We provide a `DefaultAsyncHttpxClient` class that you can pass to retain the default values we use for `limits`, `timeout` & `follow_redirects`.
        # See the [httpx documentation](https://www.python-httpx.org/api/#asyncclient) for more details.
        http_client: httpx.AsyncClient | None = None,
        # Enable or disable schema validation for data returned by the API.
        # When enabled an error APIResponseValidationError is raised
        # if the API responds with invalid data for the expected schema.
        #
        # This parameter may be removed or changed in the future.
        # If you rely on this feature, please open a GitHub issue
        # outlining your use-case to help us decide if it should be
        # part of our public interface in the future.
        _strict_response_validation: bool = False,
    ) -> None:
        """Construct a new async AsyncSeeknetic client instance.

        This automatically infers the following arguments from their corresponding environment variables if they are not provided:
        - `api_key` from `SEEKNETIC_API_KEY`
        - `bearer_token` from `SEEKNETIC_BEARER_TOKEN`
        """
        if api_key is None:
            api_key = os.environ.get("SEEKNETIC_API_KEY")
        self.api_key = api_key

        if bearer_token is None:
            bearer_token = os.environ.get("SEEKNETIC_BEARER_TOKEN")
        self.bearer_token = bearer_token

        if base_url is None:
            base_url = os.environ.get("SEEKNETIC_BASE_URL")
        if base_url is None:
            base_url = f"https://api.seeknetic.com"

        super().__init__(
            version=__version__,
            base_url=base_url,
            max_retries=max_retries,
            timeout=timeout,
            http_client=http_client,
            custom_headers=default_headers,
            custom_query=default_query,
            _strict_response_validation=_strict_response_validation,
        )

    @cached_property
    def files(self) -> AsyncFilesResource:
        from .resources.files import AsyncFilesResource

        return AsyncFilesResource(self)

    @cached_property
    def video_embedding(self) -> AsyncVideoEmbeddingResource:
        from .resources.video_embedding import AsyncVideoEmbeddingResource

        return AsyncVideoEmbeddingResource(self)

    @cached_property
    def video_tagging(self) -> AsyncVideoTaggingResource:
        from .resources.video_tagging import AsyncVideoTaggingResource

        return AsyncVideoTaggingResource(self)

    @cached_property
    def async_status(self) -> AsyncAsyncStatusResource:
        from .resources.async_status import AsyncAsyncStatusResource

        return AsyncAsyncStatusResource(self)

    @cached_property
    def with_raw_response(self) -> AsyncSeekneticWithRawResponse:
        return AsyncSeekneticWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncSeekneticWithStreamedResponse:
        return AsyncSeekneticWithStreamedResponse(self)

    @property
    @override
    def qs(self) -> Querystring:
        return Querystring(array_format="comma")

    @override
    def _auth_headers(self, security: SecurityOptions) -> dict[str, str]:
        return {
            **(self._api_key_auth if security.get("api_key_auth", False) else {}),
            **(self._bearer_auth if security.get("bearer_auth", False) else {}),
        }

    @property
    def _api_key_auth(self) -> dict[str, str]:
        api_key = self.api_key
        if api_key is None:
            return {}
        return {"X-API-Key": api_key}

    @property
    def _bearer_auth(self) -> dict[str, str]:
        bearer_token = self.bearer_token
        if bearer_token is None:
            return {}
        return {"Authorization": f"Bearer {bearer_token}"}

    @property
    @override
    def default_headers(self) -> dict[str, str | Omit]:
        return {
            **super().default_headers,
            "X-Stainless-Async": f"async:{get_async_library()}",
            **self._custom_headers,
        }

    @override
    def _validate_headers(self, headers: Headers, custom_headers: Headers) -> None:
        if headers.get("X-API-Key") or isinstance(custom_headers.get("X-API-Key"), Omit):
            return

        if headers.get("Authorization") or isinstance(custom_headers.get("Authorization"), Omit):
            return

        raise TypeError(
            '"Could not resolve authentication method. Expected either api_key or bearer_token to be set. Or for one of the `X-API-Key` or `Authorization` headers to be explicitly omitted"'
        )

    def copy(
        self,
        *,
        api_key: str | None = None,
        bearer_token: str | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        http_client: httpx.AsyncClient | None = None,
        max_retries: int | NotGiven = not_given,
        default_headers: Mapping[str, str] | None = None,
        set_default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        set_default_query: Mapping[str, object] | None = None,
        _extra_kwargs: Mapping[str, Any] = {},
    ) -> Self:
        """
        Create a new client instance re-using the same options given to the current client with optional overriding.
        """
        if default_headers is not None and set_default_headers is not None:
            raise ValueError("The `default_headers` and `set_default_headers` arguments are mutually exclusive")

        if default_query is not None and set_default_query is not None:
            raise ValueError("The `default_query` and `set_default_query` arguments are mutually exclusive")

        headers = self._custom_headers
        if default_headers is not None:
            headers = {**headers, **default_headers}
        elif set_default_headers is not None:
            headers = set_default_headers

        params = self._custom_query
        if default_query is not None:
            params = {**params, **default_query}
        elif set_default_query is not None:
            params = set_default_query

        http_client = http_client or self._client
        return self.__class__(
            api_key=api_key or self.api_key,
            bearer_token=bearer_token or self.bearer_token,
            base_url=base_url or self.base_url,
            timeout=self.timeout if isinstance(timeout, NotGiven) else timeout,
            http_client=http_client,
            max_retries=max_retries if is_given(max_retries) else self.max_retries,
            default_headers=headers,
            default_query=params,
            **_extra_kwargs,
        )

    # Alias for `copy` for nicer inline usage, e.g.
    # client.with_options(timeout=10).foo.create(...)
    with_options = copy

    @override
    def _make_status_error(
        self,
        err_msg: str,
        *,
        body: object,
        response: httpx.Response,
    ) -> APIStatusError:
        if response.status_code == 400:
            return _exceptions.BadRequestError(err_msg, response=response, body=body)

        if response.status_code == 401:
            return _exceptions.AuthenticationError(err_msg, response=response, body=body)

        if response.status_code == 403:
            return _exceptions.PermissionDeniedError(err_msg, response=response, body=body)

        if response.status_code == 404:
            return _exceptions.NotFoundError(err_msg, response=response, body=body)

        if response.status_code == 409:
            return _exceptions.ConflictError(err_msg, response=response, body=body)

        if response.status_code == 422:
            return _exceptions.UnprocessableEntityError(err_msg, response=response, body=body)

        if response.status_code == 429:
            return _exceptions.RateLimitError(err_msg, response=response, body=body)

        if response.status_code >= 500:
            return _exceptions.InternalServerError(err_msg, response=response, body=body)
        return APIStatusError(err_msg, response=response, body=body)


class SeekneticWithRawResponse:
    _client: Seeknetic

    def __init__(self, client: Seeknetic) -> None:
        self._client = client

    @cached_property
    def files(self) -> files.FilesResourceWithRawResponse:
        from .resources.files import FilesResourceWithRawResponse

        return FilesResourceWithRawResponse(self._client.files)

    @cached_property
    def video_embedding(self) -> video_embedding.VideoEmbeddingResourceWithRawResponse:
        from .resources.video_embedding import VideoEmbeddingResourceWithRawResponse

        return VideoEmbeddingResourceWithRawResponse(self._client.video_embedding)

    @cached_property
    def video_tagging(self) -> video_tagging.VideoTaggingResourceWithRawResponse:
        from .resources.video_tagging import VideoTaggingResourceWithRawResponse

        return VideoTaggingResourceWithRawResponse(self._client.video_tagging)

    @cached_property
    def async_status(self) -> async_status.AsyncStatusResourceWithRawResponse:
        from .resources.async_status import AsyncStatusResourceWithRawResponse

        return AsyncStatusResourceWithRawResponse(self._client.async_status)


class AsyncSeekneticWithRawResponse:
    _client: AsyncSeeknetic

    def __init__(self, client: AsyncSeeknetic) -> None:
        self._client = client

    @cached_property
    def files(self) -> files.AsyncFilesResourceWithRawResponse:
        from .resources.files import AsyncFilesResourceWithRawResponse

        return AsyncFilesResourceWithRawResponse(self._client.files)

    @cached_property
    def video_embedding(self) -> video_embedding.AsyncVideoEmbeddingResourceWithRawResponse:
        from .resources.video_embedding import AsyncVideoEmbeddingResourceWithRawResponse

        return AsyncVideoEmbeddingResourceWithRawResponse(self._client.video_embedding)

    @cached_property
    def video_tagging(self) -> video_tagging.AsyncVideoTaggingResourceWithRawResponse:
        from .resources.video_tagging import AsyncVideoTaggingResourceWithRawResponse

        return AsyncVideoTaggingResourceWithRawResponse(self._client.video_tagging)

    @cached_property
    def async_status(self) -> async_status.AsyncAsyncStatusResourceWithRawResponse:
        from .resources.async_status import AsyncAsyncStatusResourceWithRawResponse

        return AsyncAsyncStatusResourceWithRawResponse(self._client.async_status)


class SeekneticWithStreamedResponse:
    _client: Seeknetic

    def __init__(self, client: Seeknetic) -> None:
        self._client = client

    @cached_property
    def files(self) -> files.FilesResourceWithStreamingResponse:
        from .resources.files import FilesResourceWithStreamingResponse

        return FilesResourceWithStreamingResponse(self._client.files)

    @cached_property
    def video_embedding(self) -> video_embedding.VideoEmbeddingResourceWithStreamingResponse:
        from .resources.video_embedding import VideoEmbeddingResourceWithStreamingResponse

        return VideoEmbeddingResourceWithStreamingResponse(self._client.video_embedding)

    @cached_property
    def video_tagging(self) -> video_tagging.VideoTaggingResourceWithStreamingResponse:
        from .resources.video_tagging import VideoTaggingResourceWithStreamingResponse

        return VideoTaggingResourceWithStreamingResponse(self._client.video_tagging)

    @cached_property
    def async_status(self) -> async_status.AsyncStatusResourceWithStreamingResponse:
        from .resources.async_status import AsyncStatusResourceWithStreamingResponse

        return AsyncStatusResourceWithStreamingResponse(self._client.async_status)


class AsyncSeekneticWithStreamedResponse:
    _client: AsyncSeeknetic

    def __init__(self, client: AsyncSeeknetic) -> None:
        self._client = client

    @cached_property
    def files(self) -> files.AsyncFilesResourceWithStreamingResponse:
        from .resources.files import AsyncFilesResourceWithStreamingResponse

        return AsyncFilesResourceWithStreamingResponse(self._client.files)

    @cached_property
    def video_embedding(self) -> video_embedding.AsyncVideoEmbeddingResourceWithStreamingResponse:
        from .resources.video_embedding import AsyncVideoEmbeddingResourceWithStreamingResponse

        return AsyncVideoEmbeddingResourceWithStreamingResponse(self._client.video_embedding)

    @cached_property
    def video_tagging(self) -> video_tagging.AsyncVideoTaggingResourceWithStreamingResponse:
        from .resources.video_tagging import AsyncVideoTaggingResourceWithStreamingResponse

        return AsyncVideoTaggingResourceWithStreamingResponse(self._client.video_tagging)

    @cached_property
    def async_status(self) -> async_status.AsyncAsyncStatusResourceWithStreamingResponse:
        from .resources.async_status import AsyncAsyncStatusResourceWithStreamingResponse

        return AsyncAsyncStatusResourceWithStreamingResponse(self._client.async_status)


Client = Seeknetic

AsyncClient = AsyncSeeknetic
