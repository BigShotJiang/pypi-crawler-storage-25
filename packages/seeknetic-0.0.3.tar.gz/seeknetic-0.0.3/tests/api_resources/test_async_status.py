# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from seeknetic import Seeknetic, AsyncSeeknetic
from tests.utils import assert_matches_type
from seeknetic.types import AsyncStatusRetrieveResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestAsyncStatus:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_retrieve(self, client: Seeknetic) -> None:
        async_status = client.async_status.retrieve(
            "request_id",
        )
        assert_matches_type(AsyncStatusRetrieveResponse, async_status, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_retrieve(self, client: Seeknetic) -> None:
        response = client.async_status.with_raw_response.retrieve(
            "request_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        async_status = response.parse()
        assert_matches_type(AsyncStatusRetrieveResponse, async_status, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_retrieve(self, client: Seeknetic) -> None:
        with client.async_status.with_streaming_response.retrieve(
            "request_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            async_status = response.parse()
            assert_matches_type(AsyncStatusRetrieveResponse, async_status, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_retrieve(self, client: Seeknetic) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `request_id` but received ''"):
            client.async_status.with_raw_response.retrieve(
                "",
            )


class TestAsyncAsyncStatus:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_retrieve(self, async_client: AsyncSeeknetic) -> None:
        async_status = await async_client.async_status.retrieve(
            "request_id",
        )
        assert_matches_type(AsyncStatusRetrieveResponse, async_status, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncSeeknetic) -> None:
        response = await async_client.async_status.with_raw_response.retrieve(
            "request_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        async_status = await response.parse()
        assert_matches_type(AsyncStatusRetrieveResponse, async_status, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncSeeknetic) -> None:
        async with async_client.async_status.with_streaming_response.retrieve(
            "request_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            async_status = await response.parse()
            assert_matches_type(AsyncStatusRetrieveResponse, async_status, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncSeeknetic) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `request_id` but received ''"):
            await async_client.async_status.with_raw_response.retrieve(
                "",
            )
