# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from seeknetic import Seeknetic, AsyncSeeknetic
from tests.utils import assert_matches_type
from seeknetic.types.video_embedding import AsyncSubmitResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestVideoTagging:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_submit_async_job(self, client: Seeknetic) -> None:
        video_tagging = client.video_tagging.submit_async_job()
        assert_matches_type(AsyncSubmitResponse, video_tagging, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_submit_async_job_with_all_params(self, client: Seeknetic) -> None:
        video_tagging = client.video_tagging.submit_async_job(
            filename="filename",
            request_id="request_id",
            tensor={
                "video_input_key": "video_input_key",
                "video_kwargs_key": "video_kwargs_key",
            },
            video_base64="video_base64",
            video_url="https://example.com/video.mp4",
        )
        assert_matches_type(AsyncSubmitResponse, video_tagging, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_submit_async_job(self, client: Seeknetic) -> None:
        response = client.video_tagging.with_raw_response.submit_async_job()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        video_tagging = response.parse()
        assert_matches_type(AsyncSubmitResponse, video_tagging, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_submit_async_job(self, client: Seeknetic) -> None:
        with client.video_tagging.with_streaming_response.submit_async_job() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            video_tagging = response.parse()
            assert_matches_type(AsyncSubmitResponse, video_tagging, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncVideoTagging:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_submit_async_job(self, async_client: AsyncSeeknetic) -> None:
        video_tagging = await async_client.video_tagging.submit_async_job()
        assert_matches_type(AsyncSubmitResponse, video_tagging, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_submit_async_job_with_all_params(self, async_client: AsyncSeeknetic) -> None:
        video_tagging = await async_client.video_tagging.submit_async_job(
            filename="filename",
            request_id="request_id",
            tensor={
                "video_input_key": "video_input_key",
                "video_kwargs_key": "video_kwargs_key",
            },
            video_base64="video_base64",
            video_url="https://example.com/video.mp4",
        )
        assert_matches_type(AsyncSubmitResponse, video_tagging, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_submit_async_job(self, async_client: AsyncSeeknetic) -> None:
        response = await async_client.video_tagging.with_raw_response.submit_async_job()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        video_tagging = await response.parse()
        assert_matches_type(AsyncSubmitResponse, video_tagging, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_submit_async_job(self, async_client: AsyncSeeknetic) -> None:
        async with async_client.video_tagging.with_streaming_response.submit_async_job() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            video_tagging = await response.parse()
            assert_matches_type(AsyncSubmitResponse, video_tagging, path=["response"])

        assert cast(Any, response.is_closed) is True
