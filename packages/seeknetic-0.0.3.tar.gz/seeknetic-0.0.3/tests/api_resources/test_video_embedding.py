# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from seeknetic import Seeknetic, AsyncSeeknetic
from tests.utils import assert_matches_type
from seeknetic.types import VideoEmbeddingEncodeTextResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestVideoEmbedding:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_encode_text(self, client: Seeknetic) -> None:
        video_embedding = client.video_embedding.encode_text(
            text="a person walking on the beach",
        )
        assert_matches_type(VideoEmbeddingEncodeTextResponse, video_embedding, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_encode_text(self, client: Seeknetic) -> None:
        response = client.video_embedding.with_raw_response.encode_text(
            text="a person walking on the beach",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        video_embedding = response.parse()
        assert_matches_type(VideoEmbeddingEncodeTextResponse, video_embedding, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_encode_text(self, client: Seeknetic) -> None:
        with client.video_embedding.with_streaming_response.encode_text(
            text="a person walking on the beach",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            video_embedding = response.parse()
            assert_matches_type(VideoEmbeddingEncodeTextResponse, video_embedding, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncVideoEmbedding:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_encode_text(self, async_client: AsyncSeeknetic) -> None:
        video_embedding = await async_client.video_embedding.encode_text(
            text="a person walking on the beach",
        )
        assert_matches_type(VideoEmbeddingEncodeTextResponse, video_embedding, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_encode_text(self, async_client: AsyncSeeknetic) -> None:
        response = await async_client.video_embedding.with_raw_response.encode_text(
            text="a person walking on the beach",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        video_embedding = await response.parse()
        assert_matches_type(VideoEmbeddingEncodeTextResponse, video_embedding, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_encode_text(self, async_client: AsyncSeeknetic) -> None:
        async with async_client.video_embedding.with_streaming_response.encode_text(
            text="a person walking on the beach",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            video_embedding = await response.parse()
            assert_matches_type(VideoEmbeddingEncodeTextResponse, video_embedding, path=["response"])

        assert cast(Any, response.is_closed) is True
