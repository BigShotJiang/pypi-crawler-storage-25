# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from seeknetic import Seeknetic, AsyncSeeknetic
from tests.utils import assert_matches_type
from seeknetic.types.files import UploadUploadTensorResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestUpload:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_upload_tensor(self, client: Seeknetic) -> None:
        upload = client.files.upload.upload_tensor()
        assert_matches_type(UploadUploadTensorResponse, upload, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_upload_tensor_with_all_params(self, client: Seeknetic) -> None:
        upload = client.files.upload.upload_tensor(
            audio_input={
                "data": "AAAB...",
                "dtype": "float32",
                "shape": [1, 1, 220500],
            },
            request_id="emb-task-0001",
            service="embedding",
            video_input={
                "data": "AAAB...",
                "dtype": "uint8",
                "shape": [1, 12, 3, 224, 224],
            },
            video_kwargs={"foo": "bar"},
        )
        assert_matches_type(UploadUploadTensorResponse, upload, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_upload_tensor(self, client: Seeknetic) -> None:
        response = client.files.upload.with_raw_response.upload_tensor()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        upload = response.parse()
        assert_matches_type(UploadUploadTensorResponse, upload, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_upload_tensor(self, client: Seeknetic) -> None:
        with client.files.upload.with_streaming_response.upload_tensor() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            upload = response.parse()
            assert_matches_type(UploadUploadTensorResponse, upload, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncUpload:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_upload_tensor(self, async_client: AsyncSeeknetic) -> None:
        upload = await async_client.files.upload.upload_tensor()
        assert_matches_type(UploadUploadTensorResponse, upload, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_upload_tensor_with_all_params(self, async_client: AsyncSeeknetic) -> None:
        upload = await async_client.files.upload.upload_tensor(
            audio_input={
                "data": "AAAB...",
                "dtype": "float32",
                "shape": [1, 1, 220500],
            },
            request_id="emb-task-0001",
            service="embedding",
            video_input={
                "data": "AAAB...",
                "dtype": "uint8",
                "shape": [1, 12, 3, 224, 224],
            },
            video_kwargs={"foo": "bar"},
        )
        assert_matches_type(UploadUploadTensorResponse, upload, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_upload_tensor(self, async_client: AsyncSeeknetic) -> None:
        response = await async_client.files.upload.with_raw_response.upload_tensor()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        upload = await response.parse()
        assert_matches_type(UploadUploadTensorResponse, upload, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_upload_tensor(self, async_client: AsyncSeeknetic) -> None:
        async with async_client.files.upload.with_streaming_response.upload_tensor() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            upload = await response.parse()
            assert_matches_type(UploadUploadTensorResponse, upload, path=["response"])

        assert cast(Any, response.is_closed) is True
