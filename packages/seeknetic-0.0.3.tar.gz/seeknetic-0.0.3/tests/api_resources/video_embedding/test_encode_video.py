# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from seeknetic import Seeknetic, AsyncSeeknetic
from tests.utils import assert_matches_type
from seeknetic.types.video_embedding import AsyncSubmitResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestEncodeVideo:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_submit_async(self, client: Seeknetic) -> None:
        encode_video = client.video_embedding.encode_video.submit_async()
        assert_matches_type(AsyncSubmitResponse, encode_video, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_submit_async_with_all_params(self, client: Seeknetic) -> None:
        encode_video = client.video_embedding.encode_video.submit_async(
            filename="filename",
            request_id="request_id",
            tensor={
                "audio_input_key": "audio_input_key",
                "video_input_key": "video_input_key",
            },
            video_base64="video_base64",
            video_url="https://example.com/video.mp4",
        )
        assert_matches_type(AsyncSubmitResponse, encode_video, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_submit_async(self, client: Seeknetic) -> None:
        response = client.video_embedding.encode_video.with_raw_response.submit_async()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        encode_video = response.parse()
        assert_matches_type(AsyncSubmitResponse, encode_video, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_submit_async(self, client: Seeknetic) -> None:
        with client.video_embedding.encode_video.with_streaming_response.submit_async() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            encode_video = response.parse()
            assert_matches_type(AsyncSubmitResponse, encode_video, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncEncodeVideo:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_submit_async(self, async_client: AsyncSeeknetic) -> None:
        encode_video = await async_client.video_embedding.encode_video.submit_async()
        assert_matches_type(AsyncSubmitResponse, encode_video, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_submit_async_with_all_params(self, async_client: AsyncSeeknetic) -> None:
        encode_video = await async_client.video_embedding.encode_video.submit_async(
            filename="filename",
            request_id="request_id",
            tensor={
                "audio_input_key": "audio_input_key",
                "video_input_key": "video_input_key",
            },
            video_base64="video_base64",
            video_url="https://example.com/video.mp4",
        )
        assert_matches_type(AsyncSubmitResponse, encode_video, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_submit_async(self, async_client: AsyncSeeknetic) -> None:
        response = await async_client.video_embedding.encode_video.with_raw_response.submit_async()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        encode_video = await response.parse()
        assert_matches_type(AsyncSubmitResponse, encode_video, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_submit_async(self, async_client: AsyncSeeknetic) -> None:
        async with async_client.video_embedding.encode_video.with_streaming_response.submit_async() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            encode_video = await response.parse()
            assert_matches_type(AsyncSubmitResponse, encode_video, path=["response"])

        assert cast(Any, response.is_closed) is True
