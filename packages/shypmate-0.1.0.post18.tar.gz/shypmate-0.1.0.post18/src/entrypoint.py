"""
Container entrypoint — the full lifecycle of one dev agent run.

This script runs INSIDE the agent Docker container. It:
1. Reads configuration from environment variables
2. Clones the repo
3. Creates or checks out the agent branch
4. Builds project context
5. Runs the dev agent (think → tool → repeat loop)
6. (Agent handles: edit code, validate, commit, push, create/update PR)
7. Exits
"""

import json
import logging
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

from git import Repo
from git.exc import GitCommandError

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("shypmate.entrypoint")


def main() -> int:
    # --- Read env vars ---
    github_token = os.environ.get("GITHUB_TOKEN")
    task_description = os.environ.get("AGENT_TASK", "")
    branch_name = os.environ.get("AGENT_BRANCH", "")
    agent_id = os.environ.get("AGENT_ID", "unknown")
    is_rebase = os.environ.get("AGENT_REBASE", "false").lower() == "true"
    repo_name = os.environ.get("GITHUB_REPO", "")
    base_branch = os.environ.get("BASE_BRANCH", "main")
    workspace = os.environ.get("WORKSPACE", "/workspace")
    task_id = os.environ.get("AGENT_TASK_ID", "")

    if not github_token:
        logger.error("GITHUB_TOKEN is required")
        return 1
    if not repo_name:
        logger.error("GITHUB_REPO is required")
        return 1
    if not task_description:
        logger.error("AGENT_TASK is required")
        return 1
    if not branch_name:
        logger.error("AGENT_BRANCH is required")
        return 1
    # Check for LLM API key — the key var name is passed by the host
    llm_provider = os.environ.get("LLM_PROVIDER", "anthropic")
    if llm_provider == "anthropic" and not os.environ.get("ANTHROPIC_API_KEY"):
        logger.error("ANTHROPIC_API_KEY is required for Anthropic provider")
        return 1

    logger.info("=" * 60)
    logger.info("SHYPMATE AGENT STARTUP")
    logger.info("=" * 60)
    logger.info(f"  Agent ID:    {agent_id}")
    logger.info(f"  Task:        {task_description}")
    logger.info(f"  Branch:      {branch_name}")
    logger.info(f"  Base branch: {base_branch}")
    logger.info(f"  Repo:        {repo_name}")
    logger.info(f"  Rebase:      {is_rebase}")
    logger.info(f"  LLM:         {llm_provider} / {os.environ.get('LLM_MODEL', '?')}")
    logger.info(f"  Install cmd: {os.environ.get('INSTALL_COMMAND', '(none)')}")
    logger.info(f"  Task ID:     {task_id or '(none)'}")
    logger.info(f"  Brief:       {'available' if Path('/brief/project_brief.json').exists() else 'not found (standalone mode)'}")
    logger.info("=" * 60)

    # --- Clone repo ---
    clone_url = f"https://x-access-token:{github_token}@github.com/{repo_name}.git"
    logger.info(f"Cloning {repo_name} into {workspace}...")

    try:
        repo = Repo.clone_from(clone_url, workspace)
    except GitCommandError as e:
        # If workspace already has the repo (e.g., rebase re-run), fetch instead
        if Path(workspace).joinpath(".git").exists():
            logger.info("Workspace already has repo, fetching...")
            repo = Repo(workspace)
            repo.git.fetch("--all")
        else:
            logger.error(f"Clone failed: {e}")
            return 1

    # Configure git identity
    repo.config_writer().set_value("user", "name", f"shypmate-{agent_id}").release()
    repo.config_writer().set_value("user", "email", f"shypmate-{agent_id}@noreply.github.com").release()

    # --- Create or checkout branch ---
    try:
        if is_rebase:
            # For rebase: checkout existing branch
            logger.info(f"Checking out existing branch: {branch_name}")
            repo.git.checkout(branch_name)
        else:
            # For new work: create branch from base
            logger.info(f"Creating branch: {branch_name} from {base_branch}")
            repo.git.checkout(base_branch)
            repo.git.checkout("-b", branch_name)
    except GitCommandError:
        # Branch might exist remotely but not locally
        try:
            repo.git.checkout("-b", branch_name, f"origin/{branch_name}")
        except GitCommandError as e:
            logger.error(f"Branch setup failed: {e}")
            return 1

    # --- Install project dependencies ---
    # In dev mode (/opt/shypmate is mounted from host), skip install commands
    # that would override the mounted framework code (e.g. 'pip install -e .')
    install_command = os.environ.get("INSTALL_COMMAND", "")
    is_dev_mount = Path("/opt/shypmate/.dev_mounted").exists() or os.environ.get("SHYPMATE_DEV_MODE") == "1"
    if install_command and is_dev_mount and "pip install" in install_command:
        logger.info(f"Dev mode: skipping '{install_command}' to preserve mounted framework code")
    elif install_command:
        import subprocess
        logger.info(f"Installing dependencies: {install_command}")
        subprocess.run(
            install_command,
            shell=True,
            cwd=workspace,
            capture_output=True,
        )

    # --- Build project context ---
    # Add workspace to Python path so shypmate imports work
    sys.path.insert(0, workspace)

    # Check for pre-built brief from manager (shared volume at /brief)
    brief_dir = Path("/brief")
    project_context = None

    if brief_dir.exists() and (brief_dir / "project_brief.json").exists():
        logger.info("Found project brief from manager — skipping discovery")
        try:
            from shypmate.manager.project_brief import load_brief, load_task_plan

            brief = load_brief(brief_dir)
            if brief:
                # Build CONDENSED context from the pre-digested brief.
                # Do NOT include raw_context — the whole point is the manager
                # already distilled it into what agents need.
                parts = []
                if brief.understanding:
                    parts.append(f"## Project Understanding\n{brief.understanding}")
                if brief.architecture:
                    parts.append(f"## Architecture\n{brief.architecture}")
                if brief.conventions:
                    parts.append(f"## Coding Conventions (MUST follow)\n{brief.conventions}")
                if brief.file_map:
                    file_map_str = "\n".join(f"  {k}: {v}" for k, v in brief.file_map.items())
                    parts.append(f"## Key Files and Directories\n{file_map_str}")

                # Add task-specific plan if available
                if task_id:
                    plan = load_task_plan(task_id, brief_dir)
                    if plan:
                        plan_parts = [f"## Task Plan"]
                        if plan.approach:
                            plan_parts.append(f"Approach: {plan.approach}")
                        if plan.relevant_files:
                            plan_parts.append(f"Start with these files: {', '.join(plan.relevant_files)}")
                        if plan.patterns_to_follow:
                            plan_parts.append(f"Follow these patterns: {plan.patterns_to_follow}")
                        parts.append("\n".join(plan_parts))
                        logger.info(f"  Task plan loaded: {len(plan.relevant_files)} relevant files")

                project_context = "\n\n".join(parts)
                logger.info(f"  Condensed context from brief: {len(project_context)} chars "
                            f"(raw was {len(brief.raw_context)} chars — "
                            f"{100 - len(project_context) * 100 // max(len(brief.raw_context), 1)}% reduction)")
        except Exception as e:
            logger.warning(f"Could not load brief: {e}")

    # Fall back to standalone discovery if no brief
    if project_context is None:
        logger.info("Building project context (standalone mode)...")
        from shypmate.context.project_context import build_project_context, build_rebase_context

        if is_rebase:
            project_context = build_rebase_context(
                workspace, task_description
            )
        else:
            project_context = build_project_context(workspace)

    # Log context summary so we can see what the agent is working with
    logger.info("=" * 60)
    logger.info("PROJECT CONTEXT SUMMARY")
    logger.info("=" * 60)
    logger.info(f"  Context length: {len(project_context)} chars")
    # Show section headers from the context
    for line in project_context.split("\n"):
        line = line.strip()
        if line.startswith("##") or line.startswith("# "):
            logger.info(f"  Section: {line}")
    # Show first 500 chars as a preview
    logger.info(f"  Preview: {project_context[:500]}")
    logger.info("=" * 60)

    # --- Run agent ---
    logger.info("Starting dev agent...")

    from shypmate.crews.dev_crew import run_dev_crew

    try:
        result = run_dev_crew(
            task_description=task_description,
            branch_name=branch_name,
            project_context=project_context,
            is_rebase=is_rebase,
        )
        logger.info(f"Crew finished. Result:\n{result}")
    except Exception as e:
        logger.error(f"Crew execution failed: {e}", exc_info=True)

        # Even on failure, try to comment on the PR if one exists
        _comment_failure(branch_name, agent_id, str(e))
        return 1

    logger.info("Agent run complete.")
    return 0


def _comment_failure(branch_name: str, agent_id: str, error: str) -> None:
    """Best-effort: comment on the PR that the agent failed."""
    try:
        from github import Github

        token = os.environ.get("GITHUB_TOKEN", "")
        repo_name = os.environ.get("GITHUB_REPO", "")
        gh = Github(token)
        repo = gh.get_repo(repo_name)

        for pr in repo.get_pulls(state="open"):
            if pr.head.ref == branch_name:
                pr.create_issue_comment(
                    f"**AI Agent `{agent_id}` failed.**\n\n"
                    f"```\n{error[:2000]}\n```\n\n"
                    "This PR may need manual attention."
                )
                break
    except Exception:
        pass  # Best effort


if __name__ == "__main__":
    sys.exit(main())
