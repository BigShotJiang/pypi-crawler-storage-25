# Shypmate Roadmap

This file tracks planned features, architectural decisions, and future work. Claude agents should reference this file to understand what's coming and avoid implementing things that conflict with planned directions.

---

## Planned Features

### Escalation Triage via Claude CLI (`claude -p`)

**Status:** Planned
**Priority:** High
**Context:** The `request_human_input` tool and `shypmate inbox`/`shypmate respond` commands already provide file-based human-in-the-loop communication via `/comms/requests/` and `/comms/responses/`. This feature adds an AI triage layer before bothering the human.

**Design:**
- When an agent writes a question to `/comms/requests/`, the host-side watcher runs it through `claude --bare -p` first
- If Claude can answer confidently, it writes directly to `/comms/responses/` (no human needed)
- If Claude determines a human is needed, it escalates via the configured channel
- Uses the user's Claude subscription (not API credits) for cost efficiency
- Must include retry/backoff for subscription rate limits

**Architecture:**
```
Agent calls request_human_input → writes /comms/requests/{id}.json
    ↓
Host watcher detects new request
    ↓
claude --bare -p (triage on subscription)
    ├─ Can answer → write /comms/responses/{id}.json (done)
    └─ Needs human → escalate via terminal or SaaS
```

**Key decisions:**
- Claude CLI is not suitable as a drop-in replacement for the API provider in the agent loop — it manages its own tool loop and doesn't expose raw tool_use blocks
- CLI is best used for host-side orchestration (triage, PR review, task planning), not container-side agent work
- The API remains the correct choice for the container agent loop because it's provider-agnostic (Anthropic, OpenAI, Groq, Ollama, etc.)

---

### SaaS Backend for Remote Escalation

**Status:** Planned (not started)
**Priority:** Medium
**Context:** Currently, human responses only come via the terminal (`shypmate inbox`/`shypmate respond` or `--no-detach` interactive mode). This feature adds a remote notification channel.

**Design:**
- Host-side watcher POSTs question to a SaaS backend API when a human is needed
- Backend sends push notification to mobile app
- Human responds on mobile app
- Backend receives response, calls webhook or writes to `/comms/responses/`
- Same file-based protocol — the agent doesn't know or care which channel answered

**Components needed:**
- SaaS backend API (not started)
- Mobile app (not started)
- Host-side SaaS responder (new module alongside terminal responder)
- Configuration in `shypmate.yml` for escalation channel routing

---

### Escalation Channel Routing

**Status:** Planned
**Priority:** Medium
**Depends on:** SaaS Backend, CLI Triage

**Design:**
- Configurable escalation pipeline in `shypmate.yml`:
```yaml
escalation:
  channels:
    - type: cli_triage    # Try Claude CLI first
      enabled: true
    - type: terminal      # Fall back to terminal prompt
      enabled: true
    - type: saas          # Or push to SaaS/mobile
      enabled: false
      endpoint: https://api.shypmate.com/escalations
  timeout: 3600           # Max seconds to wait for response
```
- Channels are tried in order; first successful response wins
- Timeout handling (currently agents wait indefinitely)

---

## Existing Known Issues

- Agent container Dockerfile has system deps for Python/Django projects — needs to be more generic or configurable per project
- Monitor `cleanup_merged_containers` needs more testing
- No frontend/mobile agent specialization yet (v1 is backend-focused)
- No multi-agent collaboration within a single task
- No auto-merge capability
- Rate limiting on Anthropic API can slow agents significantly on low-tier plans

---

## Architecture Notes for Future Reference

### CLI vs API — When to Use Each

| Layer | Use | Why |
|---|---|---|
| **Container agent loop** | API (`providers.py`) | Provider-agnostic, returns raw tool_use blocks, supports custom tool schemas |
| **Host-side orchestration** | Claude CLI (`claude -p`) | Runs on subscription, good for planning/review/triage |
| **Escalation triage** | Claude CLI (`claude -p`) | Low volume, subscription cost, filters out trivial questions |
| **Task decomposition** | Claude CLI (`claude -p`) | Pre-launch planning, saves API credits |
| **PR review** | Claude CLI (`claude -p`) | Post-agent review before merge |

### Why Claude CLI Can't Replace the API in the Agent Loop

The agent loop sends messages + tool schemas to the LLM and receives back `tool_use` blocks indicating which custom tool to call with what arguments. The loop then dispatches those tools locally. `claude -p` is a full agent — it runs its own internal tool loop (Read, Edit, Bash) and returns final text. It doesn't expose intermediate tool_use decisions, so it can't drive a custom tool registry.

### Subscription Rate Limit Considerations

All `claude -p` calls share a single subscription quota. For escalation triage (low volume, sporadic), this is fine. For heavy workloads (all agent thinking), subscription limits would throttle quickly. The API has higher rate limits and scales with spend.
