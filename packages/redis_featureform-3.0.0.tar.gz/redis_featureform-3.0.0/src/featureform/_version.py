"""Package version helpers."""

from __future__ import annotations

import importlib
import sys
from importlib import metadata
from pathlib import Path
from typing import cast

if sys.version_info >= (3, 11):
    import tomllib
else:  # pragma: no cover - Python 3.10 fallback
    tomllib = importlib.import_module("tomli")

PACKAGE_NAME = "redis-featureform"


def _read_source_tree_version() -> str:
    pyproject_path = Path(__file__).resolve().parents[2] / "pyproject.toml"
    with pyproject_path.open("rb") as handle:
        pyproject = cast(dict[str, object], tomllib.load(handle))
    project = pyproject.get("project")
    if not isinstance(project, dict):
        raise RuntimeError(f"missing [project] in {pyproject_path}")
    project_data = cast(dict[str, object], project)
    version = project_data.get("version")
    if not isinstance(version, str) or not version:
        raise RuntimeError(f"missing [project].version in {pyproject_path}")
    return version


def resolve_version() -> str:
    """Resolve the package version from installed metadata or the source tree."""
    try:
        return metadata.version(PACKAGE_NAME)
    except metadata.PackageNotFoundError:
        # Source-tree execution during development may not have installed metadata.
        return _read_source_tree_version()
