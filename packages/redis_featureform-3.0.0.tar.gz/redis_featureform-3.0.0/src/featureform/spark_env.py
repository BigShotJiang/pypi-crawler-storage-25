"""Centralized Spark environment helpers for provider-specific overrides."""

from __future__ import annotations

import os

ENV_SPARK_JDBC_PASSWORD_PREFIX = "FEATUREFORM_SPARK_JDBC_PASSWORD_"
ENV_SPARK_ICEBERG_S3_ACCESS_KEY_ID_PREFIX = "FEATUREFORM_SPARK_ICEBERG_S3_ACCESS_KEY_ID_"
ENV_SPARK_ICEBERG_S3_SECRET_ACCESS_KEY_PREFIX = "FEATUREFORM_SPARK_ICEBERG_S3_SECRET_ACCESS_KEY_"
ENV_SPARK_ICEBERG_S3_REGION_PREFIX = "FEATUREFORM_SPARK_ICEBERG_S3_REGION_"
ENV_SPARK_ICEBERG_S3_ENDPOINT_PREFIX = "FEATUREFORM_SPARK_ICEBERG_S3_ENDPOINT_"


def postgres_password(token: str) -> str | None:
    return os.getenv(f"{ENV_SPARK_JDBC_PASSWORD_PREFIX}{token}")


def iceberg_access_key_id(token: str) -> str | None:
    return os.getenv(f"{ENV_SPARK_ICEBERG_S3_ACCESS_KEY_ID_PREFIX}{token}")


def iceberg_secret_access_key(token: str) -> str | None:
    return os.getenv(f"{ENV_SPARK_ICEBERG_S3_SECRET_ACCESS_KEY_PREFIX}{token}")


def iceberg_region(token: str) -> str | None:
    return os.getenv(f"{ENV_SPARK_ICEBERG_S3_REGION_PREFIX}{token}")


def iceberg_endpoint(token: str) -> str | None:
    return os.getenv(f"{ENV_SPARK_ICEBERG_S3_ENDPOINT_PREFIX}{token}")
