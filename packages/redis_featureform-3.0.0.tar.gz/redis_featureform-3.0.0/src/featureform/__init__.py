"""Featureform Python client library.

Enterprise-grade Python client for Featureform v2 API.
"""

from featureform._apply_context import get_active_apply_client, get_active_apply_workspace_id
from featureform._apply_wait import ApplyWaitError, WaitTarget
from featureform._internal.logging import (
    LogLevel,
    configure_logging,
    current_request_id,
    get_logger,
    request_id_context,
    temporary_log_level,
)
from featureform._internal.telemetry import TelemetryConfig
from featureform._version import resolve_version
from featureform.client import (
    ApplyResult,
    ApplyWaitResult,
    Client,
    GraphClientBase,
    GRPCGraphClient,
    PingResult,
    PlannedJob,
    PlannedTask,
    ProviderClient,
    ResourceChange,
    RESTGraphClient,
    SecretProviderClient,
    WorkspaceClient,
)
from featureform.config import Config
from featureform.errors import (
    AlreadyExistsError,
    ConnectionError,
    DataframeFallbackError,
    DataframePlanResolutionError,
    FeatureformError,
    FlightFallbackUnavailableError,
    InternalError,
    InvalidArgumentError,
    NotFoundError,
    ProviderWorkspaceMismatchError,
    SparkExecutionError,
    TimeoutError,
    ValidationError,
)

# New DSL resource classes
from featureform.resources import (
    AggregateFeature,
    AttributeFeature,
    Dataset,
    EnvSecretProvider,
    Feature,
    FeatureBuilder,
    FeatureInput,
    FeatureResource,
    FeatureView,
    FunctionNormalizerDetails,
    IcebergPrimaryDataset,
    IcebergProvider,
    K8sSecretProvider,
    Label,
    LabelBuilder,
    LabelResource,
    PostgresPrimaryDataset,
    PostgresProvider,
    PostgresTransformedDataset,
    PrimaryDataset,
    RealtimeFeature,
    RealtimeInput,
    RedisClusterProvider,
    RedisProvider,
    Resource,
    ResourceRegistry,
    S3Provider,
    SecretProviderBase,
    SerializerDetails,
    SnowflakePrimaryDataset,
    SnowflakeProvider,
    SnowflakeTransformedDataset,
    SparkProvider,
    SparkTransformedDataset,
    TrainingSet,
    TransformedDataset,
    VaultSecretProvider,
    postgres_sql_transformation,
    realtime_feature,
    spark_sql_transformation,
)
from featureform.resources import Provider as ProviderBase
from featureform.resources.entity import Entity
from featureform.spark import DataframeExecutionInfo, SparkOptions, get_execution_info
from featureform.types import (
    CLEAR,
    AWSSecretRef,
    AWSSecretsManagerSecretConfig,
    AzureSecretRef,
    CreateWorkspaceRequest,
    DynamoDBConfig,
    EnvSecretConfig,
    EnvSecretRef,
    GCPSecretRef,
    K8sSecretRef,
    KafkaConfig,
    KubernetesSecretConfig,
    PostgresConfig,
    Provider,
    ProviderConfig,
    ProviderType,
    RedisConfig,
    RegisterProviderRequest,
    RegisterSecretProviderRequest,
    S3Config,
    SecretProvider,
    SecretProviderConfig,
    SecretProviderType,
    SecretRef,
    SnowflakeConfig,
    SparkKerberosConfig,
    SparkProviderConfig,
    UpdateProviderRequest,
    UpdateSecretProviderRequest,
    UpdateWorkspaceRequest,
    VaultSecretConfig,
    VaultSecretRef,
    Workspace,
)

# Type helpers from types.resource
from featureform.types.resource import (
    AggregateFunction,
    FeatureLag,
    IcebergConfig,
    IcebergTableLocation,
    MaterializationEngine,
    PostgresDatasetConfig,
    ScalarType,
    SparkEnv,
    SparkExecutionDefaults,
    SparkJobConfig,
    TableLocation,
    TrainingSetType,
    ValueType,
)

__version__ = resolve_version()


def get_postgres(name: str) -> PostgresProvider:
    """Resolve a registered Postgres provider within an active apply context.

    Use this in resource files loaded by ``ff apply`` when you want method-style
    authoring such as ``postgres.dataset(...)`` or ``@postgres.sql_transformation(...)``.
    Outside apply, use ``client.get_postgres(...)`` instead.
    """

    client = get_active_apply_client()
    workspace_id = get_active_apply_workspace_id()
    if client is None:
        raise InvalidArgumentError(
            "ff.get_postgres() requires an active apply context. Use client.get_postgres() "
            "outside resource-file apply flows."
        )
    return client.get_postgres(name, workspace=workspace_id)


def get_provider(name: str) -> ProviderBase:
    """Resolve a registered provider within an active apply context.

    Outside apply, use ``client.get_provider(...)`` instead.
    """

    client = get_active_apply_client()
    workspace_id = get_active_apply_workspace_id()
    if client is None:
        raise InvalidArgumentError(
            "ff.get_provider() requires an active apply context. Use client.get_provider() "
            "outside resource-file apply flows."
        )
    return client.get_provider(name, workspace=workspace_id)


__all__ = [
    # Version
    "__version__",
    # Client
    "ApplyResult",
    "ApplyWaitError",
    "ApplyWaitResult",
    "Client",
    "GRPCGraphClient",
    "GraphClientBase",
    "PingResult",
    "PlannedJob",
    "PlannedTask",
    "ProviderClient",
    "RESTGraphClient",
    "ResourceChange",
    "SecretProviderClient",
    "WaitTarget",
    "WorkspaceClient",
    # Config
    "Config",
    "CLEAR",
    # Logging
    "LogLevel",
    "configure_logging",
    "current_request_id",
    "get_logger",
    "request_id_context",
    "temporary_log_level",
    # Telemetry
    "TelemetryConfig",
    # Errors
    "AlreadyExistsError",
    "ConnectionError",
    "DataframeFallbackError",
    "DataframePlanResolutionError",
    "FeatureformError",
    "FlightFallbackUnavailableError",
    "get_postgres",
    "get_provider",
    "InternalError",
    "InvalidArgumentError",
    "NotFoundError",
    "ProviderWorkspaceMismatchError",
    "SparkExecutionError",
    "TimeoutError",
    "ValidationError",
    # New DSL - Base
    "Resource",
    "ResourceRegistry",
    # New DSL - Secrets
    "SecretProviderBase",
    "EnvSecretProvider",
    "VaultSecretProvider",
    "K8sSecretProvider",
    "EnvSecretRef",
    "AWSSecretRef",
    "GCPSecretRef",
    "AzureSecretRef",
    "VaultSecretRef",
    "K8sSecretRef",
    "SecretRef",
    # New DSL - Providers (NOT Resources - registered separately)
    "IcebergProvider",
    "PostgresProvider",
    "SnowflakeProvider",
    "ProviderBase",
    "RedisProvider",
    "RedisClusterProvider",
    "S3Provider",
    "SparkProvider",
    "SparkOptions",
    "get_execution_info",
    "postgres_sql_transformation",
    "spark_sql_transformation",
    # New DSL - Entity
    "Entity",
    # New DSL - Datasets
    "Dataset",
    "IcebergPrimaryDataset",
    "PostgresPrimaryDataset",
    "PostgresTransformedDataset",
    "PrimaryDataset",
    "SnowflakePrimaryDataset",
    "SnowflakeTransformedDataset",
    "SparkTransformedDataset",
    "TransformedDataset",
    # New DSL - Features (builder pattern)
    "Feature",
    "FeatureBuilder",
    "FeatureResource",
    "FeatureInput",
    "AttributeFeature",
    "AggregateFeature",
    "FunctionNormalizerDetails",
    # New DSL - Labels (builder pattern)
    "Label",
    "LabelBuilder",
    "LabelResource",
    "RealtimeFeature",
    "RealtimeInput",
    "SerializerDetails",
    "realtime_feature",
    # New DSL - Training
    "FeatureView",
    "TrainingSet",
    # Type helpers
    "AggregateFunction",
    "FeatureLag",
    "IcebergConfig",
    "IcebergTableLocation",
    "MaterializationEngine",
    "PostgresDatasetConfig",
    "ScalarType",
    "SparkEnv",
    "SparkExecutionDefaults",
    "SparkJobConfig",
    "DataframeExecutionInfo",
    "TableLocation",
    "TrainingSetType",
    "ValueType",
    # Workspace Types
    "CreateWorkspaceRequest",
    "UpdateWorkspaceRequest",
    "Workspace",
    # Provider Types (legacy)
    "KafkaConfig",
    "PostgresConfig",
    "Provider",
    "ProviderConfig",
    "ProviderType",
    "DynamoDBConfig",
    "RedisConfig",
    "RegisterProviderRequest",
    "S3Config",
    "SparkKerberosConfig",
    "SparkProviderConfig",
    "SnowflakeConfig",
    "UpdateProviderRequest",
    # SecretProvider Types
    "AWSSecretsManagerSecretConfig",
    "EnvSecretConfig",
    "KubernetesSecretConfig",
    "RegisterSecretProviderRequest",
    "SecretProvider",
    "SecretProviderConfig",
    "SecretProviderType",
    "UpdateSecretProviderRequest",
    "VaultSecretConfig",
]
