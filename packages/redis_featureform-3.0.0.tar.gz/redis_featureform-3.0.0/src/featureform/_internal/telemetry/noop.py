"""No-op telemetry implementation.

Used when OpenTelemetry is not configured or not installed.
All operations are no-ops with zero overhead.
"""

from __future__ import annotations

from typing import Any

from featureform._internal.telemetry.base import (
    Attributes,
    SpanKind,
    StatusCode,
)


class NoOpSpan:
    """No-op span implementation.

    All methods are no-ops. Used when telemetry is disabled.
    """

    def set_attribute(self, key: str, value: str | int | float | bool) -> None:
        """No-op."""
        pass

    def set_status(self, code: StatusCode, description: str = "") -> None:
        """No-op."""
        pass

    def record_exception(self, exc: BaseException) -> None:
        """No-op."""
        pass

    def add_event(self, name: str, attributes: Attributes | None = None) -> None:
        """No-op."""
        pass

    def __enter__(self) -> NoOpSpan:
        """Enter context manager."""
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> None:
        """Exit context manager."""
        pass


class NoOpInstrumentor:
    """No-op instrumentor implementation.

    Returns NoOpSpan for all operations. Zero overhead when
    telemetry is not needed.
    """

    _instance: NoOpInstrumentor | None = None
    _span: NoOpSpan

    def __new__(cls) -> NoOpInstrumentor:
        """Singleton pattern for zero allocation."""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._span = NoOpSpan()
        return cls._instance

    def start_span(
        self,
        name: str,  # noqa: ARG002
        kind: SpanKind = SpanKind.INTERNAL,  # noqa: ARG002
        attributes: Attributes | None = None,  # noqa: ARG002
    ) -> NoOpSpan:
        """Return singleton NoOpSpan."""
        return self._span

    def inject_context(self, headers: dict[str, str]) -> dict[str, str]:
        """Return headers unchanged."""
        return headers

    def extract_context(self, headers: dict[str, str]) -> None:  # noqa: ARG002
        """Return None."""
        return None


__all__ = ["NoOpSpan", "NoOpInstrumentor"]
