"""Telemetry configuration.

Provides configuration for OpenTelemetry integration.
"""

from __future__ import annotations

import os
from dataclasses import dataclass

ENV_VARS = {
    "FEATUREFORM_TELEMETRY_ENABLED": "Enable telemetry",
    "FEATUREFORM_SERVICE_NAME": "Service name for telemetry",
    "FEATUREFORM_TRACES_ENABLED": "Enable traces",
    "FEATUREFORM_METRICS_ENABLED": "Enable metrics",
}


@dataclass
class TelemetryConfig:
    """Configuration for OpenTelemetry integration.

    Attributes:
        enabled: Whether telemetry is enabled.
        service_name: Service name for traces/metrics.
        traces_enabled: Whether to emit traces.
        metrics_enabled: Whether to emit metrics.
        propagate_context: Whether to propagate trace context.

    Example:
        >>> config = TelemetryConfig(
        ...     enabled=True,
        ...     service_name="my-app",
        ... )
        >>> client = Client(base_url="...", telemetry=config)
    """

    enabled: bool = False
    service_name: str = "featureform-client"
    traces_enabled: bool = True
    metrics_enabled: bool = True
    propagate_context: bool = True

    @classmethod
    def from_env(cls) -> TelemetryConfig:
        """Create configuration from environment variables.

        Environment variables:
            FEATUREFORM_TELEMETRY_ENABLED: Enable telemetry ("true"/"false")
            FEATUREFORM_SERVICE_NAME: Service name
            FEATUREFORM_TRACES_ENABLED: Enable traces ("true"/"false")
            FEATUREFORM_METRICS_ENABLED: Enable metrics ("true"/"false")

        Returns:
            TelemetryConfig from environment.
        """

        def parse_bool(value: str | None, default: bool) -> bool:
            if value is None:
                return default
            return value.lower() in ("true", "1", "yes")

        return cls(
            enabled=parse_bool(os.environ.get("FEATUREFORM_TELEMETRY_ENABLED"), False),
            service_name=os.environ.get("FEATUREFORM_SERVICE_NAME", "featureform-client"),
            traces_enabled=parse_bool(os.environ.get("FEATUREFORM_TRACES_ENABLED"), True),
            metrics_enabled=parse_bool(os.environ.get("FEATUREFORM_METRICS_ENABLED"), True),
        )


__all__ = ["TelemetryConfig", "ENV_VARS"]
