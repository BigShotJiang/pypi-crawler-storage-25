"""OpenTelemetry instrumentor implementation.

This module is only imported when OTel is installed and enabled.
All OTel imports are contained here to allow the rest of the
codebase to work without OTel installed.
"""

from __future__ import annotations

from typing import Any

from opentelemetry import trace
from opentelemetry.propagate import extract, inject
from opentelemetry.trace import SpanKind as OTelSpanKind
from opentelemetry.trace import Status
from opentelemetry.trace import StatusCode as OTelStatusCode

from featureform._internal.telemetry.base import (
    Attributes,
    SpanKind,
    StatusCode,
)
from featureform._internal.telemetry.config import TelemetryConfig

# Map our SpanKind to OTel SpanKind
_SPAN_KIND_MAP = {
    SpanKind.INTERNAL: OTelSpanKind.INTERNAL,
    SpanKind.CLIENT: OTelSpanKind.CLIENT,
    SpanKind.SERVER: OTelSpanKind.SERVER,
    SpanKind.PRODUCER: OTelSpanKind.PRODUCER,
    SpanKind.CONSUMER: OTelSpanKind.CONSUMER,
}

# Map our StatusCode to OTel StatusCode
_STATUS_CODE_MAP = {
    StatusCode.UNSET: OTelStatusCode.UNSET,
    StatusCode.OK: OTelStatusCode.OK,
    StatusCode.ERROR: OTelStatusCode.ERROR,
}


class OTelSpan:
    """Wrapper around OTel Span that implements our Span protocol.

    This wraps the context manager returned by start_as_current_span,
    which sets the span as the current span in the context for
    context propagation.
    """

    def __init__(self, span_cm: Any) -> None:
        """Initialize with OTel span context manager.

        Args:
            span_cm: Context manager from tracer.start_as_current_span()
        """
        self._span_cm = span_cm
        self._span: trace.Span | None = None

    def set_attribute(self, key: str, value: str | int | float | bool) -> None:
        """Set span attribute."""
        if self._span is not None:
            self._span.set_attribute(key, value)

    def set_status(self, code: StatusCode, description: str = "") -> None:
        """Set span status."""
        if self._span is not None:
            otel_code = _STATUS_CODE_MAP[code]
            self._span.set_status(Status(otel_code, description))

    def record_exception(self, exc: BaseException) -> None:
        """Record exception on span."""
        if self._span is not None:
            self._span.record_exception(exc)
            self._span.set_status(Status(OTelStatusCode.ERROR, str(exc)))

    def add_event(self, name: str, attributes: Attributes | None = None) -> None:
        """Add event to span."""
        if self._span is not None:
            self._span.add_event(name, attributes or {})

    def __enter__(self) -> OTelSpan:
        """Enter context manager."""
        self._span = self._span_cm.__enter__()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> None:
        """Exit context manager.

        Note: OTel's span __exit__ already records exceptions,
        so we don't need to call record_exception here.
        """
        self._span_cm.__exit__(exc_type, exc_val, exc_tb)


class OTelInstrumentor:
    """OpenTelemetry instrumentor implementation."""

    def __init__(
        self,
        config: TelemetryConfig,
        tracer_provider: trace.TracerProvider | None = None,
    ) -> None:
        """Initialize OTel instrumentor.

        Args:
            config: Telemetry configuration.
            tracer_provider: Optional tracer provider. If not provided,
                uses the global tracer provider.
        """
        self._config = config
        self._tracer = trace.get_tracer(
            "featureform",
            schema_url="https://opentelemetry.io/schemas/1.21.0",
            tracer_provider=tracer_provider,
        )

    def start_span(
        self,
        name: str,
        kind: SpanKind = SpanKind.INTERNAL,
        attributes: Attributes | None = None,
    ) -> OTelSpan:
        """Start a new OTel span.

        Uses start_as_current_span to set the span as the current span
        in the context, enabling context propagation via inject_context.
        """
        otel_kind = _SPAN_KIND_MAP[kind]
        # Use start_as_current_span to set as current for context propagation
        span_cm = self._tracer.start_as_current_span(
            name,
            kind=otel_kind,
            attributes=attributes,
        )
        return OTelSpan(span_cm)

    def inject_context(self, headers: dict[str, str]) -> dict[str, str]:
        """Inject trace context into headers."""
        inject(headers)
        return headers

    def extract_context(self, headers: dict[str, str]) -> Any:
        """Extract trace context from headers."""
        return extract(headers)


__all__ = ["OTelInstrumentor", "OTelSpan"]
