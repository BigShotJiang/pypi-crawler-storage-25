"""Telemetry abstraction for OpenTelemetry integration.

This module provides a clean abstraction over OpenTelemetry that:
1. Works without OTel installed (returns NoOp implementations)
2. Automatically uses OTel when installed and configured
3. Provides consistent API regardless of backend

Example:
    >>> from featureform._internal.telemetry import get_instrumentor, TelemetryConfig
    >>> config = TelemetryConfig(enabled=True)
    >>> instrumentor = get_instrumentor(config)
    >>> with instrumentor.start_span("my.operation") as span:
    ...     span.set_attribute("key", "value")
"""

from __future__ import annotations

import logging

from featureform._internal.telemetry.base import (
    Attributes,
    Instrumentor,
    Span,
    SpanKind,
    StatusCode,
)
from featureform._internal.telemetry.config import TelemetryConfig
from featureform._internal.telemetry.noop import NoOpInstrumentor, NoOpSpan

_logger = logging.getLogger(__name__)


def get_instrumentor(config: TelemetryConfig | None = None) -> Instrumentor:
    """Get the appropriate instrumentor based on configuration.

    Args:
        config: Telemetry configuration. If None, returns NoOp.

    Returns:
        Instrumentor implementation (OTel or NoOp).
    """
    if config is None or not config.enabled:
        return NoOpInstrumentor()

    # Try to import OTel
    try:
        from featureform._internal.telemetry.otel import OTelInstrumentor

        return OTelInstrumentor(config)
    except ImportError:
        _logger.warning(
            "OpenTelemetry requested but not installed. Install with: pip install redis-featureform[otel]"
        )
        return NoOpInstrumentor()


__all__ = [
    # Factory
    "get_instrumentor",
    # Config
    "TelemetryConfig",
    # Protocols
    "Instrumentor",
    "Span",
    # Enums
    "SpanKind",
    "StatusCode",
    # Types
    "Attributes",
    # NoOp (for testing)
    "NoOpInstrumentor",
    "NoOpSpan",
]
