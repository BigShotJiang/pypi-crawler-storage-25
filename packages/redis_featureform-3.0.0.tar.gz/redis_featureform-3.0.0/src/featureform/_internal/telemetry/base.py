"""Base protocols and types for telemetry abstraction.

This module defines the protocols that allow swapping between
NoOp and OTel implementations without changing client code.
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Protocol, runtime_checkable

# Type alias for span attributes
AttributeValue = str | int | float | bool | list[str] | list[int] | list[float]
Attributes = dict[str, AttributeValue]


class SpanKind(Enum):
    """Span kind enum matching OTel conventions."""

    INTERNAL = "internal"
    CLIENT = "client"
    SERVER = "server"
    PRODUCER = "producer"
    CONSUMER = "consumer"


class StatusCode(Enum):
    """Status code enum matching OTel conventions."""

    UNSET = "unset"
    OK = "ok"
    ERROR = "error"


@runtime_checkable
class Span(Protocol):
    """Protocol for span implementations.

    Matches the OTel Span interface for easy implementation.
    """

    def set_attribute(self, key: str, value: str | int | float | bool) -> None:
        """Set a span attribute."""
        ...

    def set_status(self, code: StatusCode, description: str = "") -> None:
        """Set span status."""
        ...

    def record_exception(self, exc: BaseException) -> None:
        """Record an exception on the span."""
        ...

    def add_event(self, name: str, attributes: Attributes | None = None) -> None:
        """Add an event to the span."""
        ...

    def __enter__(self) -> Span:
        """Enter context manager."""
        ...

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> None:
        """Exit context manager, ending the span."""
        ...


@runtime_checkable
class Instrumentor(Protocol):
    """Protocol for instrumentor implementations.

    Provides methods for creating spans and propagating context.
    """

    def start_span(
        self,
        name: str,
        kind: SpanKind = SpanKind.INTERNAL,
        attributes: Attributes | None = None,
    ) -> Span:
        """Start a new span.

        Args:
            name: Span name (e.g., "workspace.create").
            kind: Span kind (CLIENT for outgoing requests).
            attributes: Initial span attributes.

        Returns:
            A Span that should be used as a context manager.
        """
        ...

    def inject_context(self, headers: dict[str, str]) -> dict[str, str]:
        """Inject trace context into headers for propagation.

        Args:
            headers: HTTP headers dict to inject into.

        Returns:
            Headers with trace context added.
        """
        ...

    def extract_context(self, headers: dict[str, str]) -> Any:
        """Extract trace context from headers.

        Args:
            headers: HTTP headers to extract from.

        Returns:
            Context object (implementation-specific).
        """
        ...


__all__ = [
    "Attributes",
    "SpanKind",
    "StatusCode",
    "Span",
    "Instrumentor",
]
