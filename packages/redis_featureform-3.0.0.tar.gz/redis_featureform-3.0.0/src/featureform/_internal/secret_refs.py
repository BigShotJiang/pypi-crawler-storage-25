"""Internal adapters for string-based secret-ref transport fields."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from featureform.types.secret import SecretRef


def secret_ref_from_string(value: str | None) -> SecretRef | None:
    """Parse a transport-format secret ref string into a typed object."""
    if value is None or value == "":
        return None

    from featureform.types.secret import (
        AWSSecretRef,
        AzureSecretRef,
        EnvSecretRef,
        GCPSecretRef,
        K8sSecretRef,
        VaultSecretRef,
    )

    if value.startswith("env://"):
        name = value.removeprefix("env://")
        if not name:
            raise ValueError("env secret reference must include a variable name after 'env://'")
        return EnvSecretRef(name=name)

    if value.startswith("env:"):
        name = value.removeprefix("env:")
        if not name:
            raise ValueError("env secret reference must include a variable name after 'env:'")
        return EnvSecretRef(name=name)

    if value.startswith("vault:"):
        path, sep, key = value.removeprefix("vault:").partition("#")
        if not sep or not path or not key:
            raise ValueError("vault secret reference must use 'vault:<path>#<key>'")
        return VaultSecretRef(provider_name="vault", path=path, key=key)

    if value.startswith("k8s:"):
        name, sep, key = value.removeprefix("k8s:").partition("#")
        if not sep or not name or not key:
            raise ValueError("k8s secret reference must use 'k8s:<name>#<key>'")
        return K8sSecretRef(provider_name="k8s", name=name, key=key)

    if value.startswith("aws-secrets-manager:") or value.startswith("aws:"):
        provider_name = "aws-secrets-manager" if value.startswith("aws-secrets-manager:") else "aws"
        raw = value.removeprefix(f"{provider_name}:")
        secret_id, _, key = raw.partition("#")
        if not secret_id:
            raise ValueError(
                f"{provider_name} secret reference must use '{provider_name}:<secret-id>' or "
                f"'{provider_name}:<secret-id>#<key>'"
            )
        return AWSSecretRef(provider_name=provider_name, secret_id=secret_id, key=key or None)

    if value.startswith("gcp-secret-manager:") or value.startswith("gcp:"):
        provider_name = "gcp-secret-manager" if value.startswith("gcp-secret-manager:") else "gcp"
        raw = value.removeprefix(f"{provider_name}:")
        name, _, key = raw.partition("#")
        if not name:
            raise ValueError(
                f"{provider_name} secret reference must use '{provider_name}:<name>' or "
                f"'{provider_name}:<name>#<key>'"
            )
        return GCPSecretRef(provider_name=provider_name, name=name, key=key or None)

    if value.startswith("azure-key-vault:") or value.startswith("azure:"):
        provider_name = "azure-key-vault" if value.startswith("azure-key-vault:") else "azure"
        raw = value.removeprefix(f"{provider_name}:")
        name, _, key = raw.partition("#")
        if not name:
            raise ValueError(
                f"{provider_name} secret reference must use '{provider_name}:<name>' or "
                f"'{provider_name}:<name>#<key>'"
            )
        return AzureSecretRef(provider_name=provider_name, name=name, key=key or None)

    provider_name, separator, name = value.partition(":")
    if separator and provider_name and name and "://" not in name and "#" not in name:
        return EnvSecretRef(name=name, provider_name=provider_name)

    raise ValueError(f"invalid secret reference: {value}")


def secret_ref_to_string(value: SecretRef | None) -> str | None:
    """Serialize a typed secret ref into the string format used by some transports."""
    if value is None:
        return None

    from featureform.types.secret import (
        AWSSecretRef,
        EnvSecretRef,
        GCPSecretRef,
        K8sSecretRef,
        VaultSecretRef,
    )

    if isinstance(value, EnvSecretRef):
        prefix = value.provider_name or "env"
        return f"{prefix}:{value.name}"
    if isinstance(value, VaultSecretRef):
        return f"{value.provider_name}:{value.path}#{value.key}"
    if isinstance(value, K8sSecretRef):
        return f"{value.provider_name}:{value.name}#{value.key}"
    if isinstance(value, AWSSecretRef):
        suffix = f"#{value.key}" if value.key else ""
        return f"{value.provider_name}:{value.secret_id}{suffix}"
    if isinstance(value, GCPSecretRef):
        suffix = f"#{value.key}" if value.key else ""
        return f"{value.provider_name}:{value.name}{suffix}"
    suffix = f"#{value.key}" if value.key else ""
    return f"{value.provider_name}:{value.name}{suffix}"

    raise TypeError(f"unsupported secret ref type: {type(value)!r}")
