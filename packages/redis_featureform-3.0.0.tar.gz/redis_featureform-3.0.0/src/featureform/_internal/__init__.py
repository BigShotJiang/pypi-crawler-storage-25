"""Internal utilities for Featureform client."""
