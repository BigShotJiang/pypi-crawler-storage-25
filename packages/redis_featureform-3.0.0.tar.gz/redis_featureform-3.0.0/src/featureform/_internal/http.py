"""HTTP client wrapper."""

from __future__ import annotations

import ssl
import uuid
from collections.abc import Callable
from typing import Any

import httpx

import featureform
from featureform._internal.logging import get_logger, get_request_logger
from featureform.errors import (
    ConnectionError,
    FeatureformError,
    TimeoutError,
    UnexpectedProtocolResponseError,
)

# Module logger
_logger = get_logger("featureform.http")


class HTTPClient:
    """HTTP client wrapper with error handling and request tracking."""

    def __init__(
        self,
        base_url: str,
        timeout: float = 30.0,
        verify_ssl: bool = True,
        ca_cert_path: str | None = None,
        client_cert_path: str | None = None,
        client_key_path: str | None = None,
        headers: dict[str, str] | None = None,
        auth_header_provider: Callable[[], str | None] | None = None,
        skip_version_headers: bool = False,
    ) -> None:
        """Initialize HTTP client.

        Args:
            base_url: Base URL for requests.
            timeout: Request timeout in seconds.
            verify_ssl: Whether to verify SSL certificates.
            ca_cert_path: Optional CA bundle path for server verification.
            client_cert_path: Optional client certificate path for mTLS.
            client_key_path: Optional client private key path for mTLS.
            headers: Additional headers to include.
            skip_version_headers: If True, don't send version headers.
                This bypasses server-side version compatibility checking.
        """
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._verify_ssl = verify_ssl
        self._ca_cert_path = ca_cert_path
        self._client_cert_path = client_cert_path
        self._client_key_path = client_key_path
        self._headers = headers or {}
        self._auth_header_provider = auth_header_provider
        self._skip_version_headers = skip_version_headers
        self._default_headers = self._build_default_headers()
        self._client = httpx.Client(
            base_url=self._base_url,
            timeout=timeout,
            verify=httpx_ssl_context(
                verify_ssl,
                ca_cert_path,
                client_cert_path,
                client_key_path,
            ),
        )

    def _build_default_headers(self) -> dict[str, str]:
        """Build default headers."""
        headers = {
            "User-Agent": f"featureform-python/{featureform.__version__}",
            "Accept": "application/json",
            "Content-Type": "application/json",
        }
        # Only include version headers if not skipped.
        # Server validates these headers, so skipping them bypasses the check.
        if not self._skip_version_headers:
            headers["X-Featureform-Client-Version"] = featureform.__version__
            headers["X-Featureform-Client-Edition"] = "open-source"
        headers.update(self._headers)
        return headers

    def _add_request_id(self, headers: dict[str, str]) -> dict[str, str]:
        """Add request ID header."""
        if "X-Request-ID" not in headers:
            headers["X-Request-ID"] = str(uuid.uuid4())
        return headers

    def get(self, path: str, **kwargs: Any) -> httpx.Response:
        """Make a GET request."""
        return self._request("GET", path, **kwargs)

    def post(self, path: str, **kwargs: Any) -> httpx.Response:
        """Make a POST request."""
        return self._request("POST", path, **kwargs)

    def put(self, path: str, **kwargs: Any) -> httpx.Response:
        """Make a PUT request."""
        return self._request("PUT", path, **kwargs)

    def delete(self, path: str, **kwargs: Any) -> httpx.Response:
        """Make a DELETE request."""
        return self._request("DELETE", path, **kwargs)

    def _request(self, method: str, path: str, **kwargs: Any) -> httpx.Response:
        """Make an HTTP request."""
        headers = dict(self._default_headers)
        auth_header = self._auth_header_provider() if self._auth_header_provider else None
        if auth_header:
            headers["Authorization"] = auth_header
        headers.update(dict(kwargs.pop("headers", {})))
        headers = self._add_request_id(headers)
        request_id = headers.get("X-Request-ID", "unknown")

        # Create request-scoped logger
        logger = get_request_logger(_logger, request_id)

        logger.debug(
            "http_request_start",
            method=method,
            path=path,
            base_url=self._base_url,
        )

        try:
            response = self._client.request(method, path, headers=headers, **kwargs)

            logger.debug(
                "http_request_complete",
                method=method,
                path=path,
                status_code=response.status_code,
                duration_ms=response.elapsed.total_seconds() * 1000,
            )

            return response

        except httpx.ConnectError as e:
            logger.error(
                "http_connection_error",
                method=method,
                path=path,
                error=str(e),
            )
            raise ConnectionError(f"Failed to connect to {self._base_url}: {e}") from e

        except httpx.ConnectTimeout as e:
            logger.error(
                "http_connect_timeout_error",
                method=method,
                path=path,
                timeout=self._timeout,
                error=str(e),
            )
            raise TimeoutError(f"Connection to {self._base_url} timed out: {e}") from e

        except httpx.TimeoutException as e:
            logger.error(
                "http_timeout_error",
                method=method,
                path=path,
                timeout=self._timeout,
                error=str(e),
            )
            raise TimeoutError(f"Request timed out: {e}") from e

        except httpx.RemoteProtocolError as e:
            logger.error(
                "http_protocol_error",
                method=method,
                path=path,
                error=str(e),
            )
            raise UnexpectedProtocolResponseError(
                f"Unexpected HTTP protocol response from {self._base_url}: {e}. "
                "Verify the server URL and transport."
            ) from e

        except httpx.HTTPError as e:
            logger.error(
                "http_request_error",
                method=method,
                path=path,
                error=str(e),
            )
            raise FeatureformError(f"HTTP request failed for {self._base_url}: {e}") from e

    def close(self) -> None:
        """Close the HTTP client."""
        self._client.close()


def _httpx_verify_value(verify_ssl: bool, ca_cert_path: str | None) -> bool | ssl.SSLContext:
    """Build the base httpx verify value from client configuration."""
    if ca_cert_path:
        return ssl.create_default_context(cafile=ca_cert_path)
    return verify_ssl


def httpx_ssl_context(
    verify_ssl: bool,
    ca_cert_path: str | None,
    client_cert_path: str | None,
    client_key_path: str | None,
) -> bool | ssl.SSLContext:
    """Build the httpx SSL context, including optional client certificates."""
    verify_value = _httpx_verify_value(verify_ssl, ca_cert_path)
    if client_cert_path is None:
        return verify_value

    if verify_value is False:
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
    else:
        context = (
            verify_value
            if isinstance(verify_value, ssl.SSLContext)
            else ssl.create_default_context()
        )
    context.load_cert_chain(client_cert_path, client_key_path)
    return context


__all__ = ["HTTPClient"]
