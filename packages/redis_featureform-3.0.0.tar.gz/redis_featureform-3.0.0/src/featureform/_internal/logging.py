"""Structured logging for Featureform Python client.

This module provides structured logging following Python library best practices:
1. Silent by default (NullHandler)
2. Easy configuration for applications
3. structlog integration for structured output
4. Request ID tracking for correlation

Example:
    >>> from featureform import configure_logging, LogLevel
    >>> configure_logging(level=LogLevel.DEBUG)  # Enable debug logging
    >>> configure_logging(json=True)  # JSON output for production
"""

from __future__ import annotations

import contextvars
import logging
import sys
from enum import Enum
from typing import TYPE_CHECKING, Any, cast

import structlog
from structlog.types import FilteringBoundLogger

if TYPE_CHECKING:
    from structlog.types import Processor

# Package logger name
LOGGER_NAME = "featureform"

# Context variable for request ID
_request_id_var: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "request_id", default=None
)

# Track whether logging has been configured
_configured = False


class LogLevel(str, Enum):
    """Log levels for configuration."""

    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


def _setup_null_handler() -> None:
    """Set up NullHandler for silent-by-default behavior."""
    logger = logging.getLogger(LOGGER_NAME)
    # Only add NullHandler if no handlers exist
    if not logger.handlers:
        logger.addHandler(logging.NullHandler())


def _setup_silent_structlog() -> None:
    """Configure structlog to be silent by default.

    By default, structlog uses PrintLogger which outputs to stdout.
    We configure it to use stdlib integration which respects NullHandler.
    """
    # Configure structlog to use stdlib integration
    # This makes it respect the NullHandler we set up
    processors: list[Processor] = [
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
        structlog.dev.ConsoleRenderer(),
    ]

    structlog.configure(
        processors=processors,
        wrapper_class=structlog.stdlib.BoundLogger,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=False,  # Allow reconfiguration
    )


# Initialize NullHandler on module import
_setup_null_handler()
# Configure structlog to use stdlib (silent by default)
_setup_silent_structlog()


def reset_logging() -> None:
    """Reset logging configuration.

    This removes all handlers and reconfigures the NullHandler.
    Primarily used for testing.
    """
    global _configured
    logger = logging.getLogger(LOGGER_NAME)

    # Remove all handlers
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)

    # Reset level
    logger.setLevel(logging.NOTSET)

    # Re-add NullHandler
    logger.addHandler(logging.NullHandler())

    _configured = False


def configure_logging(
    level: LogLevel = LogLevel.INFO,
    json: bool = False,
    stream: Any = None,
) -> None:
    """Configure logging for the Featureform client.

    Call this function in your application to enable logging from the
    Featureform client library. Without calling this, the client is
    silent (per Python library best practices).

    Args:
        level: Minimum log level to output.
        json: If True, output JSON format. If False, use console format.
        stream: Output stream (default: sys.stderr).

    Example:
        >>> from featureform import configure_logging, LogLevel
        >>> configure_logging(level=LogLevel.DEBUG)  # Enable debug logging
        >>> configure_logging(json=True)  # JSON output for production
    """
    global _configured

    if stream is None:
        stream = sys.stderr

    # Configure standard library logging
    logger = logging.getLogger(LOGGER_NAME)
    logger.setLevel(getattr(logging, level.value))

    # Remove NullHandler and any existing handlers
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)

    # Add StreamHandler
    handler = logging.StreamHandler(stream)
    handler.setLevel(getattr(logging, level.value))
    logger.addHandler(handler)

    # Configure structlog
    processors: list[Processor] = [
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
    ]

    if json:
        processors.append(structlog.processors.JSONRenderer())
    else:
        processors.append(structlog.dev.ConsoleRenderer())

    structlog.configure(
        processors=processors,
        wrapper_class=structlog.stdlib.BoundLogger,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=False,  # Allow reconfiguration
    )

    _configured = True


def get_logger(name: str) -> FilteringBoundLogger:
    """Get a structured logger for the given name.

    Args:
        name: Logger name (should start with 'featureform.').

    Returns:
        A structlog bound logger.

    Example:
        >>> logger = get_logger("featureform.transport.rest")
        >>> logger.info("request sent", method="GET", path="/api/v1/workspaces")
    """
    return cast(FilteringBoundLogger, structlog.get_logger(name))


def get_request_logger(
    base_logger: FilteringBoundLogger,
    request_id: str,
) -> FilteringBoundLogger:
    """Create a logger with request ID bound.

    Args:
        base_logger: Base logger to extend.
        request_id: Request ID for correlation.

    Returns:
        Logger with request_id bound.
    """
    return base_logger.bind(request_id=request_id)


def current_request_id() -> str | None:
    """Get the current request ID from context.

    Returns:
        Current request ID or None if not set.
    """
    return _request_id_var.get()


class temporary_log_level:
    """Context manager to temporarily change the log level.

    Useful for debugging specific operations without changing
    global configuration.

    Args:
        level: Temporary log level.

    Example:
        >>> with temporary_log_level(LogLevel.DEBUG):
        ...     client.workspaces.create("test")  # Debug logs visible
        >>> # Back to original level
    """

    def __init__(self, level: LogLevel) -> None:
        """Initialize with target level."""
        self._level = level
        self._original_level: int = logging.NOTSET

    def __enter__(self) -> temporary_log_level:
        """Enter context and set temporary level."""
        logger = logging.getLogger(LOGGER_NAME)
        self._original_level = logger.level
        logger.setLevel(getattr(logging, self._level.value))
        # Also update handlers
        for handler in logger.handlers:
            if not isinstance(handler, logging.NullHandler):
                handler.setLevel(getattr(logging, self._level.value))
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> None:
        """Exit context and restore original level."""
        logger = logging.getLogger(LOGGER_NAME)
        logger.setLevel(self._original_level)
        # Restore handler levels
        for handler in logger.handlers:
            if not isinstance(handler, logging.NullHandler):
                handler.setLevel(self._original_level)


class request_id_context:
    """Context manager to set request ID for the current context.

    Args:
        request_id: Request ID to use. If None, generates a UUID.

    Example:
        >>> with request_id_context("req-123"):
        ...     client.workspaces.create("test")  # Logs include request_id
    """

    def __init__(self, request_id: str | None = None) -> None:
        """Initialize with optional request ID."""
        import uuid

        self._request_id = request_id if request_id is not None else str(uuid.uuid4())
        self._token: contextvars.Token[str | None] | None = None

    def __enter__(self) -> str:
        """Enter context and set request ID."""
        self._token = _request_id_var.set(self._request_id)
        return self._request_id

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> None:
        """Exit context and restore previous request ID."""
        if self._token is not None:
            _request_id_var.reset(self._token)
