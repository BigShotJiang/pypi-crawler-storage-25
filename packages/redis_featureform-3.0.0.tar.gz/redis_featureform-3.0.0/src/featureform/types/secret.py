"""Typed secret reference models."""

from __future__ import annotations

from typing import Annotated, Any, Literal

from pydantic import BaseModel, BeforeValidator, ConfigDict, Field, TypeAdapter


class EnvSecretRef(BaseModel):
    """Reference to an environment-variable-backed secret."""

    kind: Literal["env"] = "env"
    name: str = Field(..., min_length=1)
    provider_name: str | None = Field(default=None, min_length=1)

    model_config = ConfigDict(frozen=True, extra="forbid")


class VaultSecretRef(BaseModel):
    """Reference to a vault-backed secret."""

    kind: Literal["vault"] = "vault"
    provider_name: str = Field(..., min_length=1)
    path: str = Field(..., min_length=1)
    key: str = Field(..., min_length=1)

    model_config = ConfigDict(frozen=True, extra="forbid")


class K8sSecretRef(BaseModel):
    """Reference to a Kubernetes secret."""

    kind: Literal["k8s"] = "k8s"
    provider_name: str = Field(..., min_length=1)
    name: str = Field(..., min_length=1)
    key: str = Field(..., min_length=1)

    model_config = ConfigDict(frozen=True, extra="forbid")


class AWSSecretRef(BaseModel):
    """Reference to an AWS Secrets Manager-backed secret."""

    kind: Literal["aws"] = "aws"
    provider_name: str = Field(..., min_length=1)
    secret_id: str | None = Field(default=None, min_length=1)
    region: str | None = Field(default=None, min_length=1)
    key: str | None = Field(default=None, min_length=1)
    version_id: str | None = Field(default=None, min_length=1)
    version_stage: str | None = Field(default=None, min_length=1)

    model_config = ConfigDict(frozen=True, extra="forbid")


class GCPSecretRef(BaseModel):
    """Reference to a GCP Secret Manager-backed secret."""

    kind: Literal["gcp"] = "gcp"
    provider_name: str = Field(..., min_length=1)
    name: str = Field(..., min_length=1)
    project: str | None = Field(default=None, min_length=1)
    version: str | None = Field(default=None, min_length=1)
    key: str | None = Field(default=None, min_length=1)

    model_config = ConfigDict(frozen=True, extra="forbid")


class AzureSecretRef(BaseModel):
    """Reference to an Azure Key Vault-backed secret."""

    kind: Literal["azure"] = "azure"
    provider_name: str = Field(..., min_length=1)
    name: str = Field(..., min_length=1)
    vault_url: str | None = Field(default=None, min_length=1)
    version: str | None = Field(default=None, min_length=1)
    key: str | None = Field(default=None, min_length=1)

    model_config = ConfigDict(frozen=True, extra="forbid")


def _coerce_secret_ref_input(value: Any) -> Any:
    """Allow canonical shorthand strings anywhere SecretRef is accepted."""
    if isinstance(value, str):
        return parse_secret_ref_string(value)
    return value


SecretRef = Annotated[
    EnvSecretRef | VaultSecretRef | K8sSecretRef | AWSSecretRef | GCPSecretRef | AzureSecretRef,
    Field(discriminator="kind"),
    BeforeValidator(_coerce_secret_ref_input),
]

_SECRET_REF_ADAPTER: TypeAdapter[SecretRef] = TypeAdapter(SecretRef)
_BUILTIN_SECRET_PROVIDERS = {
    "env",
    "vault",
    "k8s",
    "aws",
    "aws-secrets-manager",
    "gcp",
    "gcp-secret-manager",
    "azure",
    "azure-key-vault",
}


def coerce_secret_ref(value: Any) -> SecretRef:
    """Normalize typed or dict secret refs."""
    return _SECRET_REF_ADAPTER.validate_python(value)


def parse_secret_ref_string(value: str) -> SecretRef:
    """Parse the canonical server shorthand secret reference format."""
    raw = value.strip()
    if raw == "":
        raise ValueError("secret reference cannot be empty")
    if raw.startswith("env://"):
        raise ValueError("legacy env:// secret syntax is not supported; use env:NAME")
    if raw.startswith("env:"):
        return EnvSecretRef(name=raw.removeprefix("env:"))

    provider_name, separator, location = raw.partition(":")
    if separator == "":
        raise ValueError(f"unsupported secret reference: {raw}")

    if (
        provider_name not in _BUILTIN_SECRET_PROVIDERS
        and location != ""
        and "#" not in location
        and "://" not in location
    ):
        return EnvSecretRef(name=location, provider_name=provider_name)

    if provider_name == "vault":
        path, key = location.split("#", 1) if "#" in location else (location, "")
        if not path or not key:
            raise ValueError("vault secret refs must include both path and key")
        return VaultSecretRef(provider_name="vault", path=path, key=key)

    if provider_name == "k8s":
        name, key = location.split("#", 1) if "#" in location else (location, "")
        if not name or not key:
            raise ValueError("k8s secret refs must include both name and key")
        return K8sSecretRef(provider_name="k8s", name=name, key=key)

    if provider_name in {"aws", "aws-secrets-manager"}:
        secret_id: str
        secret_key: str | None
        if "#" in location:
            secret_id, secret_key = location.split("#", 1)
        else:
            secret_id, secret_key = location, None
        return AWSSecretRef(provider_name=provider_name, secret_id=secret_id, key=secret_key)

    if provider_name in {"gcp", "gcp-secret-manager"}:
        gcp_name: str
        gcp_key: str | None
        if "#" in location:
            gcp_name, gcp_key = location.split("#", 1)
        else:
            gcp_name, gcp_key = location, None
        return GCPSecretRef(provider_name=provider_name, name=gcp_name, key=gcp_key)

    if provider_name in {"azure", "azure-key-vault"}:
        azure_name: str
        azure_key: str | None
        if "#" in location:
            azure_name, azure_key = location.split("#", 1)
        else:
            azure_name, azure_key = location, None
        return AzureSecretRef(provider_name=provider_name, name=azure_name, key=azure_key)

    raise ValueError(f"unsupported secret reference: {raw}")


def secret_ref_to_string(value: Any) -> str:
    """Serialize a typed secret ref into the canonical server shorthand format."""
    secret_ref = coerce_secret_ref(value)

    if isinstance(secret_ref, EnvSecretRef):
        if secret_ref.provider_name:
            return f"{secret_ref.provider_name}:{secret_ref.name}"
        return f"env:{secret_ref.name}"

    if isinstance(secret_ref, VaultSecretRef):
        if secret_ref.provider_name != "vault":
            raise ValueError("vault secret strings only support the built-in 'vault' provider")
        return f"vault:{secret_ref.path}#{secret_ref.key}"

    if isinstance(secret_ref, K8sSecretRef):
        if secret_ref.provider_name != "k8s":
            raise ValueError("k8s secret strings only support the built-in 'k8s' provider")
        return f"k8s:{secret_ref.name}#{secret_ref.key}"

    if isinstance(secret_ref, AWSSecretRef):
        if secret_ref.provider_name not in {"aws", "aws-secrets-manager"}:
            raise ValueError(
                "aws secret strings only support the built-in 'aws' or 'aws-secrets-manager' providers"
            )
        suffix = f"#{secret_ref.key}" if secret_ref.key is not None else ""
        return f"{secret_ref.provider_name}:{secret_ref.secret_id}{suffix}"

    if isinstance(secret_ref, GCPSecretRef):
        if secret_ref.provider_name not in {"gcp", "gcp-secret-manager"}:
            raise ValueError(
                "gcp secret strings only support the built-in 'gcp' or 'gcp-secret-manager' providers"
            )
        suffix = f"#{secret_ref.key}" if secret_ref.key is not None else ""
        return f"{secret_ref.provider_name}:{secret_ref.name}{suffix}"

    if secret_ref.provider_name not in {"azure", "azure-key-vault"}:
        raise ValueError(
            "azure secret strings only support the built-in 'azure' or 'azure-key-vault' providers"
        )
    suffix = f"#{secret_ref.key}" if secret_ref.key is not None else ""
    return f"{secret_ref.provider_name}:{secret_ref.name}{suffix}"


__all__ = [
    "AWSSecretRef",
    "AzureSecretRef",
    "coerce_secret_ref",
    "EnvSecretRef",
    "GCPSecretRef",
    "K8sSecretRef",
    "parse_secret_ref_string",
    "SecretRef",
    "secret_ref_to_string",
    "VaultSecretRef",
]
