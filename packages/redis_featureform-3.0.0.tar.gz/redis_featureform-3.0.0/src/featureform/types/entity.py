"""Entity types for Featureform.

This module provides EntityMapping for associating entity names with columns
in Labels and other resources that need multi-entity support.
"""

from __future__ import annotations

from pydantic import BaseModel, Field


class EntityMapping(BaseModel):
    """Mapping of an entity name to a column in a dataset.

    Used in Labels and other resources where we need to associate
    an entity (like "user" or "merchant") with the column containing
    the entity values (like "user_id" or "merchant_id").

    Attributes:
        name: The entity name (e.g., "user", "merchant").
        column: The column name containing entity values (REQUIRED).
        description: Optional description of this entity mapping.

    Example:
        >>> em = EntityMapping(name="user", column="user_id")
        >>> em = EntityMapping(name="merchant", column="merchant_id", description="Merchant entity")
    """

    name: str = Field(..., min_length=1, description="Entity name")
    column: str = Field(..., min_length=1, description="Column name containing entity values")
    description: str | None = Field(default=None, description="Optional description")

    model_config = {
        "frozen": True,
        "extra": "forbid",
    }


__all__ = ["EntityMapping"]
