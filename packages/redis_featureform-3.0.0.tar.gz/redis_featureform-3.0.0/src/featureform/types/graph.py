"""Typed graph query response models."""

from __future__ import annotations

from typing import Any, cast

from pydantic import BaseModel, ConfigDict, Field, SerializerFunctionWrapHandler, model_serializer
from pydantic_core.core_schema import SerializationInfo

from featureform.types.provider import SparkRuntimeView, SparkSubmissionView
from featureform.types.resource import (
    IcebergConfig,
    IcebergTableLocation,
    SparkJobConfig,
    TableLocation,
    ValueType,
)


class GraphModel(BaseModel):
    """Base graph model with dict-style compatibility for existing callers."""

    def __getitem__(self, key: str) -> Any:
        return getattr(self, key)

    def get(self, key: str, default: Any = None) -> Any:
        return getattr(self, key, default)


class GraphResourceSummary(GraphModel):
    """Summary view of a resource in graph list/search results."""

    name: str = Field(..., min_length=1)
    description: str = ""
    kind: str = ""
    subtype: str = ""
    variant: str = ""
    provider: str = ""
    entity: str = ""
    source_dataset: str = ""
    label: str = ""
    features: list[str] = Field(default_factory=list)
    entities: list[str] = Field(default_factory=list)
    inference_store: str = ""
    materialization_engine: str = ""
    spark_provider: str = ""
    feature_count: int = 0
    entity_count: int = 0

    model_config = ConfigDict(frozen=True, extra="forbid")


class GraphResourceRef(GraphModel):
    """Reference to another resource."""

    name: str = Field(..., min_length=1)
    kind: str = Field(..., min_length=1)

    model_config = ConfigDict(frozen=True, extra="forbid")


class GraphPagination(GraphModel):
    """Pagination metadata for graph list/search responses."""

    total: int = 0
    has_next: bool = False
    next_page_token: str = ""

    model_config = ConfigDict(frozen=True, extra="forbid")


class GraphResourceList(GraphModel):
    """List response for resource summaries."""

    resources: list[GraphResourceSummary] = Field(default_factory=list)
    version: int = 0
    pagination: GraphPagination | None = None

    model_config = ConfigDict(frozen=True, extra="ignore")


class RealtimeInputReference(GraphModel):
    """Reference used by a realtime input."""

    workspace: str = ""
    feature_view: str = ""
    feature_name: str = Field(..., min_length=1)

    model_config = ConfigDict(frozen=True, extra="forbid")


class GraphRealtimeInput(GraphModel):
    """Typed realtime input descriptor."""

    input_type: str = Field(..., min_length=1)
    name: str = ""
    feature_ref: RealtimeInputReference | None = None
    training_feature: RealtimeInputReference | None = None

    model_config = ConfigDict(frozen=True, extra="forbid")

    @model_serializer(mode="wrap")
    def _serialize_without_empty_refs(
        self, handler: SerializerFunctionWrapHandler, info: SerializationInfo
    ) -> dict[str, object]:
        del info
        data = handler(self)
        if not isinstance(data, dict):
            return cast(dict[str, object], data)
        serialized = cast(dict[str, Any], data)
        if serialized.get("feature_ref") is None:
            serialized.pop("feature_ref", None)
        if serialized.get("training_feature") is None:
            serialized.pop("training_feature", None)
        return cast(dict[str, object], serialized)


class GraphRealtimeFeatureFields(GraphModel):
    """Realtime-only fields for feature detail responses."""

    requirements: list[str] = Field(default_factory=list)
    inputs: list[GraphRealtimeInput] = Field(default_factory=list)
    serialization_python_version: str = ""

    model_config = ConfigDict(frozen=True, extra="forbid")


class GraphFeatureResource(GraphModel):
    """Concrete feature payload."""

    name: str = Field(..., min_length=1)
    description: str = ""
    variant: str = Field(..., min_length=1)
    entity: str = ""
    entity_column: str = ""
    source_dataset: str = ""
    provider: str = ""
    offline_store_provider: str = ""
    value_type: ValueType | None = None
    input_column: str = ""
    timestamp_column: str = ""
    function: str = ""
    time_window: str = ""
    realtime_feature: GraphRealtimeFeatureFields | None = None

    model_config = ConfigDict(frozen=True, extra="forbid")


class GraphDatasetResource(GraphModel):
    """Concrete dataset payload."""

    name: str = Field(..., min_length=1)
    description: str = ""
    variant: str = Field(..., min_length=1)
    provider: str = ""
    timestamp_column: str = ""
    table_location: TableLocation | None = None
    iceberg_location: IcebergTableLocation | None = None
    query: str = ""
    source_datasets: list[str] = Field(default_factory=list)
    incremental_sources: dict[str, str] = Field(default_factory=dict)
    primary_key: list[str] = Field(default_factory=list)
    transform_job_config: SparkJobConfig | None = None
    iceberg_config: IcebergConfig | None = None

    model_config = ConfigDict(frozen=True, extra="forbid")


class GraphEntityResource(GraphModel):
    """Concrete entity payload."""

    name: str = Field(..., min_length=1)
    description: str = ""

    model_config = ConfigDict(frozen=True, extra="forbid")


class GraphLabelResource(GraphModel):
    """Concrete label payload."""

    name: str = Field(..., min_length=1)
    description: str = ""
    entities: list[str] = Field(default_factory=list)
    entity_fields: list[str] = Field(default_factory=list)
    value_field: str = ""
    timestamp_field: str = ""
    source_dataset: str = ""
    provider: str = ""
    value_type: ValueType | None = None

    model_config = ConfigDict(frozen=True, extra="forbid")


class GraphFeatureLag(GraphModel):
    """Feature lag used in training-set detail responses."""

    feature: str = ""
    name: str = Field(..., min_length=1)
    lag: str = ""

    model_config = ConfigDict(frozen=True, extra="forbid")


class GraphTrainingSetResource(GraphModel):
    """Concrete training-set payload."""

    name: str = Field(..., min_length=1)
    description: str = ""
    provider: str = ""
    features: list[str] = Field(default_factory=list)
    label: str = ""
    type: str = Field(..., min_length=1)
    feature_lags: list[GraphFeatureLag] = Field(default_factory=list)
    compute_job_config: SparkJobConfig | None = None

    model_config = ConfigDict(frozen=True, extra="forbid")


class GraphFeatureViewResource(GraphModel):
    """Concrete feature-view payload."""

    name: str = Field(..., min_length=1)
    description: str = ""
    entity: str = ""
    features: list[str] = Field(default_factory=list)
    provider: str = ""
    inference_store: str = ""
    materialization_engine: str = ""
    spark_provider: str = ""
    join_strategy: str = ""
    materialize_job_config: SparkJobConfig | None = None

    model_config = ConfigDict(frozen=True, extra="forbid")


class GraphFeatureDetail(GraphModel):
    """Feature detail response."""

    version: int = 0
    summary: GraphResourceSummary
    consumers: list[GraphResourceRef] = Field(default_factory=list)
    sources: list[GraphResourceRef] = Field(default_factory=list)
    resource: GraphFeatureResource

    model_config = ConfigDict(frozen=True, extra="ignore")


class GraphDatasetDetail(GraphModel):
    """Dataset detail response."""

    version: int = 0
    summary: GraphResourceSummary
    consumers: list[GraphResourceRef] = Field(default_factory=list)
    sources: list[GraphResourceRef] = Field(default_factory=list)
    resource: GraphDatasetResource
    runtime_preview: SparkRuntimeView | None = None
    submission_preview: SparkSubmissionView | None = None

    model_config = ConfigDict(frozen=True, extra="ignore")


class GraphEntityDetail(GraphModel):
    """Entity detail response."""

    version: int = 0
    summary: GraphResourceSummary
    consumers: list[GraphResourceRef] = Field(default_factory=list)
    sources: list[GraphResourceRef] = Field(default_factory=list)
    resource: GraphEntityResource

    model_config = ConfigDict(frozen=True, extra="ignore")


class GraphLabelDetail(GraphModel):
    """Label detail response."""

    version: int = 0
    summary: GraphResourceSummary
    consumers: list[GraphResourceRef] = Field(default_factory=list)
    sources: list[GraphResourceRef] = Field(default_factory=list)
    resource: GraphLabelResource

    model_config = ConfigDict(frozen=True, extra="ignore")


class GraphTrainingSetDetail(GraphModel):
    """Training-set detail response."""

    version: int = 0
    summary: GraphResourceSummary
    consumers: list[GraphResourceRef] = Field(default_factory=list)
    sources: list[GraphResourceRef] = Field(default_factory=list)
    resource: GraphTrainingSetResource

    model_config = ConfigDict(frozen=True, extra="ignore")


class GraphFeatureViewDetail(GraphModel):
    """Feature-view detail response."""

    version: int = 0
    summary: GraphResourceSummary
    consumers: list[GraphResourceRef] = Field(default_factory=list)
    sources: list[GraphResourceRef] = Field(default_factory=list)
    resource: GraphFeatureViewResource

    model_config = ConfigDict(frozen=True, extra="ignore")


class GraphRelationshipResult(GraphModel):
    """Relationship query response."""

    resource: GraphResourceRef
    related: list[GraphResourceRef] = Field(default_factory=list)
    version: int = 0

    model_config = ConfigDict(frozen=True, extra="forbid")


class GraphPipelineStep(GraphModel):
    """Pipeline step descriptor."""

    name: str = Field(..., min_length=1)
    kind: str = Field(..., min_length=1)
    depth: int = 0
    query: str = ""

    model_config = ConfigDict(frozen=True, extra="forbid")


class GraphPipelineResult(BaseModel):
    """Pipeline query response."""

    resource: GraphResourceRef
    steps: list[GraphPipelineStep] = Field(default_factory=list)
    version: int = 0

    model_config = ConfigDict(frozen=True, extra="forbid")


class GraphNode(BaseModel):
    """Lineage/impact graph node."""

    name: str = Field(..., min_length=1)
    kind: str = Field(..., min_length=1)

    model_config = ConfigDict(frozen=True, extra="forbid")


class GraphEdge(BaseModel):
    """Lineage/impact graph edge."""

    from_name: str = Field(..., alias="from", min_length=1)
    to: str = Field(..., min_length=1)

    model_config = ConfigDict(frozen=True, extra="forbid", populate_by_name=True)


class GraphLineageResult(BaseModel):
    """Lineage/impact response."""

    nodes: list[GraphNode] = Field(default_factory=list)
    edges: list[GraphEdge] = Field(default_factory=list)
    version: int = 0

    model_config = ConfigDict(frozen=True, extra="forbid")


class GraphVersionSummary(BaseModel):
    """Committed graph version summary."""

    version: int
    principal_type: str = ""
    principal_id: str = ""
    message: str = ""
    timestamp: str = ""

    model_config = ConfigDict(frozen=True, extra="forbid")


class GraphVersionDiffChange(BaseModel):
    """Change entry in a version diff."""

    name: str = Field(..., min_length=1)
    kind: str = Field(..., min_length=1)
    change_type: str = Field(..., min_length=1)

    model_config = ConfigDict(frozen=True, extra="forbid")


class GraphVersionDiff(BaseModel):
    """Version diff response."""

    from_version: int
    to_version: int
    added: list[GraphVersionDiffChange] = Field(default_factory=list)
    modified: list[GraphVersionDiffChange] = Field(default_factory=list)
    deleted: list[GraphVersionDiffChange] = Field(default_factory=list)

    model_config = ConfigDict(frozen=True, extra="forbid")


class GraphResourceHistoryEntry(BaseModel):
    """Resource history entry."""

    version: int
    change_type: str = Field(..., min_length=1)
    principal_type: str = ""
    principal_id: str = ""
    message: str = ""
    timestamp: str = ""

    model_config = ConfigDict(frozen=True, extra="forbid")


class GraphResourceHistory(BaseModel):
    """Resource history response."""

    name: str = Field(..., min_length=1)
    entries: list[GraphResourceHistoryEntry] = Field(default_factory=list)

    model_config = ConfigDict(frozen=True, extra="forbid")


class GraphWorkspaceStats(BaseModel):
    """Workspace stats response."""

    version: int = 0
    features: int = 0
    datasets: int = 0
    entities: int = 0
    training_sets: int = 0
    labels: int = 0
    feature_views: int = 0
    provider_usage: dict[str, int] = Field(default_factory=dict)

    model_config = ConfigDict(frozen=True, extra="forbid")


class GraphWorkspaceOverview(BaseModel):
    """Workspace overview response."""

    workspace_id: str = ""
    workspace_name: str = ""
    description: str = ""
    version: int = 0
    stats: GraphWorkspaceStats | None = None
    recent_versions: list[GraphVersionSummary] = Field(default_factory=list)

    model_config = ConfigDict(frozen=True, extra="forbid")


__all__ = [
    "GraphDatasetDetail",
    "GraphDatasetResource",
    "GraphEdge",
    "GraphEntityDetail",
    "GraphEntityResource",
    "GraphFeatureDetail",
    "GraphFeatureLag",
    "GraphFeatureResource",
    "GraphFeatureViewDetail",
    "GraphFeatureViewResource",
    "GraphLabelDetail",
    "GraphLabelResource",
    "GraphLineageResult",
    "GraphNode",
    "GraphPagination",
    "GraphPipelineResult",
    "GraphPipelineStep",
    "GraphRealtimeFeatureFields",
    "GraphRealtimeInput",
    "GraphRelationshipResult",
    "GraphResourceHistory",
    "GraphResourceHistoryEntry",
    "GraphResourceList",
    "GraphResourceRef",
    "GraphResourceSummary",
    "GraphTrainingSetDetail",
    "GraphTrainingSetResource",
    "GraphVersionDiff",
    "GraphVersionDiffChange",
    "GraphVersionSummary",
    "GraphWorkspaceOverview",
    "GraphWorkspaceStats",
    "RealtimeInputReference",
]
