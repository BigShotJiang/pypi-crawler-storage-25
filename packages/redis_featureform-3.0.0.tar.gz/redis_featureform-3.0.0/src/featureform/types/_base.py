"""Shared base models for Featureform domain types."""

import warnings
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel

warnings.filterwarnings(
    "ignore",
    message=r'Field name "schema" in ".*" shadows an attribute in parent "FeatureformModel"',
    category=UserWarning,
)


class FeatureformModel(BaseModel):
    """Base model that reserves `schema` for typed domain fields.

    Pydantic still exposes a legacy `BaseModel.schema()` method. Declaring
    `schema` as `Any` for the type checker avoids false-positive override errors
    when our domain models use `schema` as a normal data field.
    """

    if TYPE_CHECKING:
        schema: Any
