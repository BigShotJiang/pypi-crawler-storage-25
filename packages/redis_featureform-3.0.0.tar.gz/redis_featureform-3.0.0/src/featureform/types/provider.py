"""Provider domain types."""

from datetime import datetime
from enum import Enum
from typing import Annotated
from urllib.parse import urlparse
from uuid import UUID

from pydantic import BaseModel, Field, field_serializer, field_validator, model_validator
from pydantic_core import PydanticCustomError

from featureform._internal.secret_refs import secret_ref_from_string, secret_ref_to_string
from featureform.types._base import FeatureformModel
from featureform.types.secret import SecretRef


class ProviderType(str, Enum):
    """Type of data provider.

    Values must match canonical REST/client type strings.
    """

    POSTGRES = "postgres"
    SNOWFLAKE = "snowflake"
    S3 = "s3"
    HDFS = "hdfs"
    SPARK = "spark"
    DYNAMODB = "dynamodb"
    REDIS = "redis"
    REDIS_CLUSTER = "redis-cluster"
    KAFKA = "kafka"
    ICEBERG = "iceberg"


class IcebergCatalogType(str, Enum):
    """Type of Iceberg catalog backend."""

    HIVE = "hive"
    REST = "rest"
    GLUE = "glue"
    SQL = "sql"


class SSLMode(str, Enum):
    """PostgreSQL SSL connection mode.

    See: https://www.postgresql.org/docs/current/libpq-ssl.html#LIBPQ-SSL-SSLMODE-STATEMENTS
    """

    DISABLE = "disable"
    ALLOW = "allow"
    PREFER = "prefer"
    REQUIRE = "require"
    VERIFY_CA = "verify-ca"
    VERIFY_FULL = "verify-full"


class RedisTLSMode(str, Enum):
    """Redis TLS connection mode."""

    DISABLED = "disabled"
    ENABLED = "enabled"
    VERIFY_CA = "verify-ca"
    VERIFY_FULL = "verify-full"
    MTLS = "mtls"


class ProviderHealthStatus(str, Enum):
    """Health status of a provider.

    Values must match Go constants in internal/provider/types/health.go.
    """

    UNKNOWN = "unknown"
    HEALTHY = "healthy"
    UNHEALTHY = "unhealthy"
    DISABLED = "disabled"


class ProviderHealth(BaseModel):
    """Health status information for a provider."""

    status: ProviderHealthStatus = Field(..., description="Health status")
    message: str | None = Field(default=None, description="Error message when unhealthy")
    checked_at: datetime | None = Field(default=None, description="Last health check timestamp")
    latency_ms: int = Field(default=0, description="Health check latency in milliseconds")
    consecutive_failures: int = Field(default=0, description="Number of consecutive failures")

    model_config = {
        "frozen": True,
    }


class PostgresConfig(FeatureformModel):
    """Configuration for PostgreSQL provider."""

    host: str = Field(..., description="Database host")
    port: int = Field(default=5432, description="Database port", ge=1, le=65535)
    database: str = Field(..., description="Database name")
    schema: str | None = Field(
        default=None,
        description="Schema for Featureform-managed tables (transforms, etc.). Default: ff_transforms",
    )
    user: str | None = Field(default=None, description="Database user")
    password_secret: SecretRef | None = Field(
        default=None, description="Secret reference for password"
    )
    ssl_mode: SSLMode = Field(
        default=SSLMode.PREFER,
        description="SSL mode for database connection",
    )

    model_config = {
        "frozen": True,
        "extra": "forbid",
        "populate_by_name": True,
    }


class SnowflakeConfig(FeatureformModel):
    """Configuration for Snowflake provider."""

    account: str = Field(..., description="Snowflake account identifier")
    host: str | None = Field(default=None, description="Explicit Snowflake host override")
    warehouse: str = Field(..., description="Warehouse name")
    database: str = Field(..., description="Database name")
    schema: str = Field(..., description="Schema name")
    auth_type: str = Field(default="password", description="Snowflake auth type")
    username: str | None = Field(default=None, description="Snowflake username")
    password_secret: SecretRef | None = Field(
        default=None, description="Secret reference for Snowflake password"
    )
    private_key_secret: SecretRef | None = Field(
        default=None, description="Secret reference for Snowflake private key"
    )
    passphrase_secret: SecretRef | None = Field(
        default=None, description="Secret reference for Snowflake private key passphrase"
    )
    oauth_client_id: str | None = Field(default=None, description="Snowflake OAuth client ID")
    oauth_client_secret: SecretRef | None = Field(
        default=None, description="Secret reference for Snowflake OAuth client secret"
    )
    oauth_token: SecretRef | None = Field(
        default=None, description="Secret reference for Snowflake OAuth token"
    )
    role: str | None = Field(default=None, description="Optional Snowflake role")
    login_timeout: int | None = Field(default=None, description="Snowflake login timeout")
    request_timeout: int | None = Field(default=None, description="Snowflake request timeout")
    session_params: dict[str, str] = Field(
        default_factory=dict,
        description="Snowflake session parameters",
    )

    model_config = {
        "frozen": True,
        "extra": "forbid",
        "populate_by_name": True,
    }

    @field_validator("session_params", mode="before")
    @classmethod
    def normalize_session_params(cls, value: object) -> object:
        if value is None:
            return {}
        return value

    @model_validator(mode="after")
    def validate_auth(self) -> "SnowflakeConfig":
        if self.auth_type == "password":
            if self.username is None:
                raise ValueError("username is required for Snowflake password auth")
            if self.password_secret is None:
                raise ValueError("password_secret is required for Snowflake password auth")
            return self

        if self.auth_type == "key-pair":
            if self.username is None:
                raise ValueError("username is required for Snowflake key-pair auth")
            if self.private_key_secret is None:
                raise ValueError("private_key_secret is required for Snowflake key-pair auth")
            return self

        if self.auth_type == "oauth":
            if self.oauth_client_id is None:
                raise ValueError("oauth_client_id is required for Snowflake oauth auth")
            if self.oauth_client_secret is None:
                raise ValueError("oauth_client_secret is required for Snowflake oauth auth")
            if self.oauth_token is None:
                raise ValueError("oauth_token is required for Snowflake oauth auth")
            return self

        raise ValueError("auth_type must be one of: password, key-pair, oauth")


class S3Config(BaseModel):
    """Configuration for S3 provider.

    Authentication is optional. If not provided, IAM role authentication is used.
    If access key authentication is desired, both access_key_id_secret and
    secret_access_key_secret must be provided together.
    """

    bucket: str = Field(..., description="S3 bucket name")
    region: str = Field(..., description="AWS region")
    access_key_id_secret: SecretRef | None = Field(
        None, description="Secret reference for AWS access key ID"
    )
    secret_access_key_secret: SecretRef | None = Field(
        None, description="Secret reference for AWS secret access key"
    )
    endpoint: str | None = Field(None, description="Custom endpoint for S3-compatible services")
    path_style_access: bool = Field(False, description="Use path-style access for MinIO")

    model_config = {
        "frozen": True,
        "extra": "forbid",
    }

    @model_validator(mode="after")
    def validate_credentials(self) -> "S3Config":
        """Validate that both credentials are provided together or neither."""
        has_access_key = self.access_key_id_secret is not None
        has_secret_key = self.secret_access_key_secret is not None

        if has_access_key != has_secret_key:
            raise PydanticCustomError(
                "featureform_provider_secret_pair",
                "Both access_key_id_secret and secret_access_key_secret must be provided together, "
                "or neither (for IAM role authentication)",
            )

        if self.endpoint is not None:
            parsed = urlparse(self.endpoint)
            if parsed.scheme not in {"http", "https"} or not parsed.netloc:
                raise PydanticCustomError(
                    "featureform_provider_endpoint_url",
                    "endpoint must be a valid http:// or https:// URL",
                )
        return self


class HDFSConfig(BaseModel):
    """Configuration for HDFS provider."""

    namenode_url: str = Field(..., description="WebHDFS endpoint")
    auth_type: str = Field(..., description="Authentication type")
    user: str | None = Field(default=None, description="Username for simple auth")
    kerberos_principal: SecretRef | None = Field(default=None)
    kerberos_keytab: SecretRef | None = Field(default=None)
    kerberos_realm: str | None = Field(default=None)
    kdc_host: str | None = Field(default=None)

    model_config = {
        "frozen": True,
        "extra": "forbid",
    }


class DynamoDBConfig(BaseModel):
    """Configuration for DynamoDB provider."""

    region: str = Field(..., description="AWS region")
    access_key_id_secret: SecretRef | None = Field(
        None, description="Secret reference for AWS access key ID"
    )
    secret_access_key_secret: SecretRef | None = Field(
        None, description="Secret reference for AWS secret access key"
    )
    endpoint: str | None = Field(None, description="Custom endpoint for LocalStack/testing")
    table_prefix: str | None = Field(None, description="Table name prefix")

    model_config = {
        "frozen": True,
        "extra": "forbid",
    }

    @model_validator(mode="after")
    def validate_credentials(self) -> "DynamoDBConfig":
        has_access_key = self.access_key_id_secret is not None
        has_secret_key = self.secret_access_key_secret is not None

        if has_access_key != has_secret_key:
            raise ValueError(
                "Both access_key_id_secret and secret_access_key_secret must be provided together, "
                "or neither (for IAM/default authentication)"
            )
        return self


class SparkProviderConfig(BaseModel):
    """Configuration for generic Spark provider."""

    class SparkHadoopConfig(BaseModel):
        """Typed Hadoop provider-owned Spark configuration."""

        s3a_provider: str | None = Field(default=None, description="S3 provider alias")
        path_style: bool | None = Field(default=None, description="Use path-style S3 access")

        model_config = {"frozen": True, "extra": "forbid"}

    class SparkStagingConfig(BaseModel):
        """Typed Spark staging configuration."""

        provider: str | None = Field(default=None, description="Staging provider alias")
        prefix: str | None = Field(default=None, description="Staging path prefix")

        model_config = {"frozen": True, "extra": "forbid"}

    class SparkK8sSecretKeyRef(BaseModel):
        """Kubernetes secret key reference for executor env injection."""

        env_var: str | None = Field(default=None)
        name: str | None = Field(default=None)
        key: str | None = Field(default=None)

        model_config = {"frozen": True, "extra": "forbid"}

    class SparkLocalBackend(BaseModel):
        """Typed Spark local backend."""

        master: str | None = Field(default=None)

        model_config = {"frozen": True, "extra": "forbid"}

    class SparkStandaloneBackend(BaseModel):
        """Typed Spark standalone backend."""

        master: str | None = Field(default=None)

        model_config = {"frozen": True, "extra": "forbid"}

    class SparkYarnBackend(BaseModel):
        """Typed Spark YARN backend."""

        master: str | None = Field(default=None)
        queue: str | None = Field(default=None)
        proxy_user: str | None = Field(default=None)

        model_config = {"frozen": True, "extra": "forbid"}

    class SparkK8sBackend(BaseModel):
        """Typed Spark Kubernetes backend."""

        api_server: str | None = Field(default=None)
        image: str | None = Field(default=None)
        namespace: str | None = Field(default=None)
        service_account: str | None = Field(default=None)
        executor_request_cores: str | None = Field(default=None)
        executor_limit_cores: str | None = Field(default=None)
        executor_pod_env: dict[str, str] = Field(default_factory=dict)
        driver_secrets: dict[str, str] = Field(default_factory=dict)
        executor_secrets: dict[str, str] = Field(default_factory=dict)
        executor_secret_key_refs: list["SparkProviderConfig.SparkK8sSecretKeyRef"] = Field(
            default_factory=list
        )

        model_config = {"frozen": True, "extra": "forbid"}

    class SparkBackend(BaseModel):
        """Typed Spark backend union."""

        local: "SparkProviderConfig.SparkLocalBackend | None" = Field(default=None)
        standalone: "SparkProviderConfig.SparkStandaloneBackend | None" = Field(default=None)
        yarn: "SparkProviderConfig.SparkYarnBackend | None" = Field(default=None)
        k8s: "SparkProviderConfig.SparkK8sBackend | None" = Field(default=None)

        model_config = {"frozen": True, "extra": "forbid"}

        @model_validator(mode="after")
        def validate_one_backend(self) -> "SparkProviderConfig.SparkBackend":
            configured = [
                item
                for item in (self.local, self.standalone, self.yarn, self.k8s)
                if item is not None
            ]
            if len(configured) != 1:
                raise ValueError("Exactly one Spark backend must be configured")
            return self

    class SparkRuntimeProfile(BaseModel):
        """Runtime compatibility profile for Spark dependency resolution."""

        backend: str | None = Field(default=None, description="Runtime backend identifier")
        spark_version: str | None = Field(default=None, description="Spark version")
        scala_binary_version: str | None = Field(default=None, description="Scala binary version")

        model_config = {"frozen": True, "extra": "forbid"}

    class SparkExecutionDefaults(BaseModel):
        """Structured Spark execution defaults."""

        driver_cores: int | None = Field(default=None, ge=1, description="Default driver cores")
        driver_memory: str | None = Field(default=None, description="Default driver memory")
        executor_memory: str | None = Field(default=None, description="Default executor memory")
        executor_cores: int | None = Field(default=None, ge=1, description="Default executor cores")
        num_executors: int | None = Field(default=None, ge=1, description="Default executor count")
        shuffle_partitions: int | None = Field(
            default=None, ge=1, description="Default shuffle partitions"
        )

        model_config = {"frozen": True, "extra": "forbid"}

    class SparkDependencyVersions(BaseModel):
        """Managed dependency version overrides."""

        iceberg: str | None = Field(default=None)
        iceberg_aws_bundle: str | None = Field(default=None)
        hadoop_aws: str | None = Field(default=None)
        aws_java_sdk_bundle: str | None = Field(default=None)
        postgres_jdbc: str | None = Field(default=None)

        model_config = {"frozen": True, "extra": "forbid"}

    class SparkDependencyPolicy(BaseModel):
        """Structured Spark dependency policy."""

        versions: "SparkProviderConfig.SparkDependencyVersions" = Field(
            default_factory=lambda: SparkProviderConfig.SparkDependencyVersions()
        )
        package_overrides: dict[str, str] = Field(default_factory=dict)
        extra_packages: list[str] = Field(default_factory=list)
        extra_jars: list[str] = Field(default_factory=list)
        provided_families: list[str] = Field(default_factory=list)

        model_config = {"frozen": True, "extra": "forbid"}

    class SparkAdvancedConfig(BaseModel):
        """Advanced Spark configuration escape hatch."""

        spark_conf: dict[str, str] = Field(default_factory=dict)

        model_config = {"frozen": True, "extra": "forbid"}

    class SparkSubmissionArtifactRef(BaseModel):
        """Transport-scoped Spark submission artifact reference."""

        uri: str = Field(..., min_length=1)

        model_config = {"frozen": True, "extra": "forbid"}

    class SparkSubmissionKerberosConfig(BaseModel):
        """Kerberos submission defaults for spark-submit transports."""

        principal: str = Field(..., min_length=1)
        realm: str | None = Field(default=None)
        kdc_host: str | None = Field(default=None)
        keytab_secret: SecretRef | None = Field(default=None)
        krb5_conf_secret: SecretRef | None = Field(default=None)

        model_config = {"frozen": True, "extra": "forbid"}

    class SparkSubmissionDefaults(BaseModel):
        """Typed spark-submit transport defaults."""

        app_name: str | None = Field(default=None)
        properties_file: str | None = Field(default=None)
        repositories: list[str] = Field(default_factory=list)
        files: list["SparkProviderConfig.SparkSubmissionArtifactRef"] = Field(default_factory=list)
        archives: list["SparkProviderConfig.SparkSubmissionArtifactRef"] = Field(
            default_factory=list
        )
        py_files: list["SparkProviderConfig.SparkSubmissionArtifactRef"] = Field(
            default_factory=list
        )
        kerberos: "SparkProviderConfig.SparkSubmissionKerberosConfig | None" = Field(default=None)

        model_config = {"frozen": True, "extra": "forbid"}

    class SparkEnv(BaseModel):
        """Typed environment values for one Spark scope."""

        values: dict[str, str] = Field(default_factory=dict)
        secrets: dict[str, SecretRef] = Field(default_factory=dict)

        model_config = {"frozen": True, "extra": "forbid"}

    class SparkResolvedStringValue(BaseModel):
        value: str = Field(...)
        source: str | None = Field(default=None)
        reason: str | None = Field(default=None)

        model_config = {"frozen": True, "extra": "forbid"}

    class SparkResolvedIntValue(BaseModel):
        value: int = Field(...)
        source: str | None = Field(default=None)
        reason: str | None = Field(default=None)

        model_config = {"frozen": True, "extra": "forbid"}

    class SparkResolvedExecution(BaseModel):
        driver_memory: "SparkProviderConfig.SparkResolvedStringValue | None" = Field(default=None)
        executor_memory: "SparkProviderConfig.SparkResolvedStringValue | None" = Field(default=None)
        executor_cores: "SparkProviderConfig.SparkResolvedIntValue | None" = Field(default=None)
        num_executors: "SparkProviderConfig.SparkResolvedIntValue | None" = Field(default=None)
        shuffle_partitions: "SparkProviderConfig.SparkResolvedIntValue | None" = Field(default=None)

        model_config = {"frozen": True, "extra": "forbid"}

    class SparkResolvedPackage(BaseModel):
        family: str | None = Field(default=None)
        coordinate: str | None = Field(default=None)
        source: str | None = Field(default=None)
        reason: str | None = Field(default=None)

        model_config = {"frozen": True, "extra": "forbid"}

    class SparkResolvedJar(BaseModel):
        uri: str | None = Field(default=None)
        source: str | None = Field(default=None)
        reason: str | None = Field(default=None)

        model_config = {"frozen": True, "extra": "forbid"}

    class SparkResolvedProvidedFamily(BaseModel):
        family: str | None = Field(default=None)
        source: str | None = Field(default=None)
        reason: str | None = Field(default=None)

        model_config = {"frozen": True, "extra": "forbid"}

    class SparkResolvedDependencies(BaseModel):
        packages: list["SparkProviderConfig.SparkResolvedPackage"] = Field(default_factory=list)
        jars: list["SparkProviderConfig.SparkResolvedJar"] = Field(default_factory=list)
        provided_families: list["SparkProviderConfig.SparkResolvedProvidedFamily"] = Field(
            default_factory=list
        )

        model_config = {"frozen": True, "extra": "forbid"}

    class SparkRuntimeConfEntry(BaseModel):
        key: str = Field(...)
        display_value: str = Field(...)
        redacted: bool = Field(default=False)
        source: str | None = Field(default=None)
        reason: str | None = Field(default=None)

        model_config = {"frozen": True, "extra": "forbid"}

    class SparkRuntimeView(BaseModel):
        fingerprint: str | None = Field(default=None)
        execution: "SparkProviderConfig.SparkResolvedExecution | None" = Field(default=None)
        dependencies: "SparkProviderConfig.SparkResolvedDependencies | None" = Field(default=None)
        conf: list["SparkProviderConfig.SparkRuntimeConfEntry"] = Field(default_factory=list)
        conditional_families: list[str] = Field(default_factory=list)

        model_config = {"frozen": True, "extra": "forbid"}

    class SparkSubmissionArtifact(BaseModel):
        kind: str | None = Field(default=None)
        uri: str | None = Field(default=None)
        source: str | None = Field(default=None)
        reason: str | None = Field(default=None)

        model_config = {"frozen": True, "extra": "forbid"}

    class SparkSubmissionEnvEntry(BaseModel):
        name: str | None = Field(default=None)
        display_value: str | None = Field(default=None)
        redacted: bool = Field(default=False)
        source: str | None = Field(default=None)
        reason: str | None = Field(default=None)

        model_config = {"frozen": True, "extra": "forbid"}

    class SparkSubmissionKerberosView(BaseModel):
        principal: str | None = Field(default=None)
        realm: str | None = Field(default=None)
        kdc_host: str | None = Field(default=None)
        keytab_configured: bool = Field(default=False)
        krb5_conf_provided: bool = Field(default=False)
        source: str | None = Field(default=None)
        reason: str | None = Field(default=None)

        model_config = {"frozen": True, "extra": "forbid"}

    class SparkSubmissionView(BaseModel):
        app_name: str | None = Field(default=None)
        driver_cores: "SparkProviderConfig.SparkResolvedIntValue | None" = Field(default=None)
        properties_file: "SparkProviderConfig.SparkSubmissionArtifact | None" = Field(default=None)
        repositories: list["SparkProviderConfig.SparkResolvedStringValue"] = Field(
            default_factory=list
        )
        files: list["SparkProviderConfig.SparkSubmissionArtifact"] = Field(default_factory=list)
        archives: list["SparkProviderConfig.SparkSubmissionArtifact"] = Field(default_factory=list)
        py_files: list["SparkProviderConfig.SparkSubmissionArtifact"] = Field(default_factory=list)
        environment: list["SparkProviderConfig.SparkSubmissionEnvEntry"] = Field(
            default_factory=list
        )
        queue: "SparkProviderConfig.SparkResolvedStringValue | None" = Field(default=None)
        proxy_user: "SparkProviderConfig.SparkResolvedStringValue | None" = Field(default=None)
        kerberos: "SparkProviderConfig.SparkSubmissionKerberosView | None" = Field(default=None)
        request_fingerprint: str | None = Field(default=None)

        model_config = {"frozen": True, "extra": "forbid"}

    catalogs: dict[str, str] = Field(default_factory=dict, description="Spark catalog aliases")
    backend: "SparkProviderConfig.SparkBackend | None" = Field(
        default=None, description="Typed Spark backend"
    )
    hadoop: "SparkProviderConfig.SparkHadoopConfig | None" = Field(
        default=None, description="Typed Hadoop config"
    )
    staging: "SparkProviderConfig.SparkStagingConfig | None" = Field(
        default=None, description="Typed staging config"
    )
    driver_env: "SparkProviderConfig.SparkEnv" = Field(
        default_factory=lambda: SparkProviderConfig.SparkEnv()
    )
    executor_env: "SparkProviderConfig.SparkEnv" = Field(
        default_factory=lambda: SparkProviderConfig.SparkEnv()
    )
    deploy_mode: str | None = Field(default=None, description="Spark deploy mode")
    runtime_profile: "SparkProviderConfig.SparkRuntimeProfile | None" = Field(default=None)
    execution_defaults: "SparkProviderConfig.SparkExecutionDefaults" = Field(
        default_factory=lambda: SparkProviderConfig.SparkExecutionDefaults()
    )
    dependencies: "SparkProviderConfig.SparkDependencyPolicy" = Field(
        default_factory=lambda: SparkProviderConfig.SparkDependencyPolicy()
    )
    advanced: "SparkProviderConfig.SparkAdvancedConfig" = Field(
        default_factory=lambda: SparkProviderConfig.SparkAdvancedConfig()
    )
    submission_defaults: "SparkProviderConfig.SparkSubmissionDefaults" = Field(
        default_factory=lambda: SparkProviderConfig.SparkSubmissionDefaults()
    )
    spark_conf: dict[str, str] = Field(
        default_factory=dict,
        description="Additional Spark configuration options",
    )
    max_execution_time: str | None = Field(default=None, description="Maximum execution time")

    model_config = {
        "frozen": True,
        "extra": "forbid",
    }


class RedisConfig(BaseModel):
    """Configuration for Redis provider."""

    host: str = Field(..., description="Redis host")
    port: int = Field(6379, description="Redis port", ge=1, le=65535)
    database: int = Field(0, description="Redis database index", ge=0, le=15)
    password_secret: SecretRef | None = Field(None, description="Secret reference for password")
    tls: "RedisTLSConfig | None" = Field(None, description="Redis TLS configuration")

    model_config = {
        "frozen": True,
        "extra": "forbid",
    }


class RedisClusterConfig(BaseModel):
    """Configuration for Redis cluster provider."""

    endpoints: list[str] = Field(..., description="Redis cluster startup endpoints")
    password_secret: SecretRef | None = Field(None, description="Secret reference for password")
    tls: "RedisTLSConfig | None" = Field(None, description="Redis TLS configuration")

    model_config = {
        "frozen": True,
        "extra": "forbid",
    }


class RedisTLSConfig(BaseModel):
    """Configuration for Redis TLS/mTLS."""

    mode: RedisTLSMode = Field(..., description="Redis TLS mode")
    ca_cert_path: str | None = Field(None, description="Server-side path to CA certificate")
    ca_cert_secret: SecretRef | None = Field(None, description="Secret reference containing CA PEM")
    server_name: str | None = Field(None, description="TLS server name override")
    client_cert_path: str | None = Field(None, description="Server-side path to client certificate")
    client_cert_secret: SecretRef | None = Field(
        None, description="Secret reference containing client cert PEM"
    )
    client_key_path: str | None = Field(None, description="Server-side path to client key")
    client_key_secret: SecretRef | None = Field(
        None, description="Secret reference containing client key PEM"
    )
    insecure_skip_verify: bool = Field(False, description="Skip TLS verification")
    min_version: str | None = Field(None, description="Minimum TLS version, e.g. 1.2 or 1.3")

    model_config = {
        "frozen": True,
        "extra": "forbid",
    }

    @field_validator("ca_cert_secret", "client_cert_secret", "client_key_secret", mode="before")
    @classmethod
    def parse_secret_ref_fields(cls, value: object) -> object:
        if isinstance(value, str):
            return secret_ref_from_string(value)
        return value

    @field_serializer("ca_cert_secret", "client_cert_secret", "client_key_secret", when_used="json")
    def serialize_secret_ref_fields(self, value: SecretRef | None) -> str | None:
        return secret_ref_to_string(value)


class KafkaConfig(BaseModel):
    """Configuration for Kafka provider."""

    brokers: list[str] = Field(..., description="List of Kafka broker addresses")
    sasl_username: str | None = Field(default=None, description="SASL username")
    sasl_password_secret: SecretRef | None = Field(
        default=None, description="Secret reference for SASL password"
    )
    sasl_mechanism: str | None = Field(
        default=None, description="SASL mechanism (PLAIN, SCRAM-SHA-256, SCRAM-SHA-512)"
    )
    oauth_client_id: str | None = Field(default=None, description="OAuth client ID")
    oauth_client_secret: SecretRef | None = Field(
        default=None, description="Secret reference for OAuth client secret"
    )
    oauth_token_url: str | None = Field(default=None, description="OAuth token URL")
    mtls_client_cert_secret: SecretRef | None = Field(
        default=None, description="Secret reference for Kafka client certificate"
    )
    mtls_client_key_secret: SecretRef | None = Field(
        default=None, description="Secret reference for Kafka client private key"
    )

    model_config = {
        "frozen": True,
        "extra": "forbid",
    }

    @model_validator(mode="after")
    def validate_auth(self) -> "KafkaConfig":
        has_sasl = any(
            value is not None and value != ""
            for value in (self.sasl_username, self.sasl_password_secret, self.sasl_mechanism)
        )
        has_oauth = any(
            value is not None and value != ""
            for value in (self.oauth_client_id, self.oauth_client_secret, self.oauth_token_url)
        )
        has_mtls = any(
            value is not None
            for value in (self.mtls_client_cert_secret, self.mtls_client_key_secret)
        )

        auth_mode_count = sum((has_sasl, has_oauth, has_mtls))
        if auth_mode_count > 1:
            raise PydanticCustomError(
                "featureform_kafka_auth_conflict",
                "KafkaConfig supports only one auth mode at a time",
            )

        if has_sasl and not all(
            value is not None and value != ""
            for value in (self.sasl_username, self.sasl_password_secret, self.sasl_mechanism)
        ):
            raise PydanticCustomError(
                "featureform_kafka_sasl_incomplete",
                "Kafka SASL auth requires sasl_username, sasl_password_secret, and sasl_mechanism",
            )

        if has_oauth and not all(
            value is not None and value != ""
            for value in (
                self.oauth_client_id,
                self.oauth_client_secret,
                self.oauth_token_url,
            )
        ):
            raise PydanticCustomError(
                "featureform_kafka_oauth_incomplete",
                "Kafka OAuth auth requires oauth_client_id, oauth_client_secret, and oauth_token_url",
            )

        if has_mtls and (
            self.mtls_client_cert_secret is None or self.mtls_client_key_secret is None
        ):
            raise PydanticCustomError(
                "featureform_kafka_mtls_incomplete",
                "Kafka mTLS auth requires mtls_client_cert_secret and mtls_client_key_secret",
            )

        return self


class IcebergHiveConfig(BaseModel):
    """Configuration for Hive Metastore catalog."""

    uri: str = Field(..., description="Thrift URI (e.g., thrift://hive-metastore:9083)")

    model_config = {"frozen": True, "extra": "forbid"}


class IcebergRESTConfig(BaseModel):
    """Configuration for REST catalog.

    Matches Go: RESTCatalogConfig in internal/provider/types/iceberg.go
    """

    uri: str = Field(..., description="REST endpoint (e.g., http://iceberg-rest:8181)")
    credential: SecretRef | None = Field(None, description="OAuth bearer token secret reference")
    prefix: str | None = Field(None, description="Multi-tenant prefix")

    model_config = {"frozen": True, "extra": "forbid"}


class IcebergGlueConfig(BaseModel):
    """Configuration for AWS Glue catalog."""

    region: str = Field(..., description="AWS region")
    catalog_id: str | None = Field(None, description="AWS account ID")

    model_config = {"frozen": True, "extra": "forbid"}


class IcebergS3Config(BaseModel):
    """Configuration for S3 warehouse access.

    Matches Go: S3StorageConfig in internal/provider/types/iceberg.go

    Authentication is optional. If not provided, IAM role authentication is used.
    If access key authentication is desired, both access_key_id_secret and
    secret_access_key_secret must be provided together.
    """

    region: str = Field(..., description="AWS region")
    endpoint: str | None = Field(None, description="Custom endpoint for MinIO/LocalStack")
    access_key_id: SecretRef | None = Field(
        None,
        alias="access_key_id_secret",
        description="Secret reference for access key ID",
    )
    secret_access_key: SecretRef | None = Field(
        None,
        alias="secret_access_key_secret",
        description="Secret reference for secret access key",
    )
    path_style_access: bool = Field(False, description="Use path-style access for MinIO")

    model_config = {"frozen": True, "extra": "forbid", "populate_by_name": True}

    @model_validator(mode="after")
    def validate_credentials(self) -> "IcebergS3Config":
        """Validate that both credentials are provided together or neither."""
        has_access_key = self.access_key_id is not None
        has_secret_key = self.secret_access_key is not None

        if has_access_key != has_secret_key:
            raise ValueError(
                "Both access_key_id_secret and secret_access_key_secret must be provided together, "
                "or neither (for IAM role authentication)"
            )
        return self

    @property
    def access_key_id_secret(self) -> SecretRef | None:
        return self.access_key_id

    @property
    def secret_access_key_secret(self) -> SecretRef | None:
        return self.secret_access_key


class IcebergSQLConfig(BaseModel):
    """Configuration for SQL-based catalog (Postgres, MySQL, SQLite).

    Matches Go: SQLCatalogConfig in internal/provider/types/iceberg.go
    """

    driver: str = Field(..., description="Database driver: postgres, mysql, sqlite")
    connection_string: SecretRef = Field(..., description="Connection string secret reference")

    model_config = {"frozen": True, "extra": "forbid"}


class IcebergCatalogBackend(BaseModel):
    """Typed Iceberg catalog backend."""

    hive: IcebergHiveConfig | None = Field(None, description="Hive Metastore config")
    rest: IcebergRESTConfig | None = Field(None, description="REST catalog config")
    glue: IcebergGlueConfig | None = Field(None, description="AWS Glue config")
    sql: IcebergSQLConfig | None = Field(None, description="SQL catalog config")

    model_config = {"frozen": True, "extra": "forbid"}

    @model_validator(mode="after")
    def validate_one_backend(self) -> "IcebergCatalogBackend":
        configured = [
            item for item in (self.hive, self.rest, self.glue, self.sql) if item is not None
        ]
        if len(configured) != 1:
            raise ValueError("Exactly one Iceberg catalog backend must be configured")
        return self


class IcebergS3Warehouse(BaseModel):
    """S3-backed Iceberg warehouse reference."""

    provider: str = Field(..., description="S3 provider name")
    prefix: str | None = Field(default=None, description="Warehouse prefix")

    model_config = {"frozen": True, "extra": "forbid"}


class IcebergHDFSWarehouse(BaseModel):
    """HDFS-backed Iceberg warehouse reference."""

    provider: str = Field(..., description="HDFS provider name")
    path: str = Field(..., description="Warehouse path")

    model_config = {"frozen": True, "extra": "forbid"}


class IcebergWarehouse(BaseModel):
    """Typed Iceberg warehouse reference."""

    s3: IcebergS3Warehouse | None = Field(None, description="S3 warehouse reference")
    hdfs: IcebergHDFSWarehouse | None = Field(None, description="HDFS warehouse reference")

    model_config = {"frozen": True, "extra": "forbid"}

    @model_validator(mode="after")
    def validate_one_warehouse(self) -> "IcebergWarehouse":
        configured = [item for item in (self.s3, self.hdfs) if item is not None]
        if len(configured) != 1:
            raise ValueError("Exactly one Iceberg warehouse variant must be configured")
        return self


class IcebergCatalogConfig(BaseModel):
    """Configuration for Iceberg Catalog provider."""

    backend: IcebergCatalogBackend = Field(..., description="Typed catalog backend")
    warehouse: IcebergWarehouse = Field(..., description="Typed warehouse reference")

    model_config = {"frozen": True, "extra": "forbid"}


ProviderConfig = Annotated[
    PostgresConfig
    | SnowflakeConfig
    | S3Config
    | SparkProviderConfig
    | DynamoDBConfig
    | RedisConfig
    | RedisClusterConfig
    | KafkaConfig
    | IcebergCatalogConfig,
    Field(discriminator=None),
]


class Provider(BaseModel):
    """Provider represents a data source or sink."""

    workspace_id: UUID = Field(..., description="Workspace this provider belongs to")
    name: str = Field(..., min_length=1, max_length=255, description="Provider name")
    description: str | None = Field(default=None, description="Provider description")
    type: ProviderType = Field(..., description="Provider type")
    config: ProviderConfig = Field(..., description="Provider configuration")
    secret_provider: str | None = Field(default=None, description="Secret provider name")
    secret_path: str | None = Field(default=None, description="Secret path")
    created_at: datetime = Field(..., description="Creation timestamp")
    updated_at: datetime = Field(..., description="Last update timestamp")
    health: ProviderHealth | None = Field(default=None, description="Provider health status")
    runtime_preview: SparkProviderConfig.SparkRuntimeView | None = Field(
        default=None, description="Projected Spark runtime preview"
    )
    submission_preview: SparkProviderConfig.SparkSubmissionView | None = Field(
        default=None, description="Projected Spark submission preview"
    )

    model_config = {
        "frozen": True,
        "extra": "forbid",
    }


class ProviderInput(BaseModel):
    """Input for creating/updating a provider."""

    name: str = Field(..., min_length=1, max_length=255)
    type: ProviderType = Field(...)
    config: dict[str, object] | ProviderConfig | None = Field(default=None)
    description: str | None = Field(default=None, max_length=1000)
    secret_provider: str | None = Field(default=None)
    secret_path: str | None = Field(default=None)

    model_config = {
        "extra": "forbid",
    }

    @model_validator(mode="after")
    def validate_transport_shape(self) -> "ProviderInput":
        if self.config is None:
            raise ValueError("config is required")
        return self


class RegisterProviderRequest(BaseModel):
    """Request to register a provider."""

    provider: ProviderInput = Field(...)
    skip_health_check: bool = Field(
        default=False, description="Skip the synchronous check at registration time"
    )
    disable_monitoring: bool = Field(
        default=False, description="Disable all recurring health checks (implies skip_health_check)"
    )

    model_config = {
        "extra": "forbid",
    }


class UpdateProviderRequest(BaseModel):
    """Request to update a provider."""

    provider: ProviderInput = Field(...)
    force: bool = Field(default=False, description="Force potentially breaking changes")
    skip_health_check: bool = Field(
        default=False, description="Skip the synchronous check on this update"
    )
    disable_monitoring: bool = Field(
        default=False, description="Disable all recurring health checks (implies skip_health_check)"
    )
    clear_config_fields: list[str] = Field(default_factory=list)

    model_config = {
        "extra": "forbid",
    }


SparkRuntimeProfile = SparkProviderConfig.SparkRuntimeProfile
SparkExecutionDefaults = SparkProviderConfig.SparkExecutionDefaults
SparkDependencyVersions = SparkProviderConfig.SparkDependencyVersions
SparkDependencyPolicy = SparkProviderConfig.SparkDependencyPolicy
SparkAdvancedConfig = SparkProviderConfig.SparkAdvancedConfig
SparkSubmissionArtifactRef = SparkProviderConfig.SparkSubmissionArtifactRef
SparkSubmissionKerberosConfig = SparkProviderConfig.SparkSubmissionKerberosConfig
SparkSubmissionDefaults = SparkProviderConfig.SparkSubmissionDefaults
SparkKerberosConfig = SparkProviderConfig.SparkSubmissionKerberosConfig
SparkResolvedStringValue = SparkProviderConfig.SparkResolvedStringValue
SparkResolvedIntValue = SparkProviderConfig.SparkResolvedIntValue
SparkResolvedExecution = SparkProviderConfig.SparkResolvedExecution
SparkResolvedPackage = SparkProviderConfig.SparkResolvedPackage
SparkResolvedJar = SparkProviderConfig.SparkResolvedJar
SparkResolvedProvidedFamily = SparkProviderConfig.SparkResolvedProvidedFamily
SparkResolvedDependencies = SparkProviderConfig.SparkResolvedDependencies
SparkRuntimeView = SparkProviderConfig.SparkRuntimeView
SparkSubmissionView = SparkProviderConfig.SparkSubmissionView


__all__ = [
    "Provider",
    "ProviderType",
    "ProviderConfig",
    "ProviderInput",
    "ProviderHealth",
    "ProviderHealthStatus",
    "RegisterProviderRequest",
    "UpdateProviderRequest",
    "PostgresConfig",
    "SnowflakeConfig",
    "S3Config",
    "SparkProviderConfig",
    "SparkRuntimeProfile",
    "SparkExecutionDefaults",
    "SparkDependencyVersions",
    "SparkDependencyPolicy",
    "SparkAdvancedConfig",
    "SparkSubmissionArtifactRef",
    "SparkSubmissionKerberosConfig",
    "SparkSubmissionDefaults",
    "SparkKerberosConfig",
    "SparkResolvedStringValue",
    "SparkResolvedIntValue",
    "SparkResolvedExecution",
    "SparkResolvedPackage",
    "SparkResolvedJar",
    "SparkResolvedProvidedFamily",
    "SparkResolvedDependencies",
    "SparkRuntimeView",
    "SparkSubmissionView",
    "DynamoDBConfig",
    "RedisTLSMode",
    "RedisTLSConfig",
    "RedisConfig",
    "RedisClusterConfig",
    "KafkaConfig",
    "SSLMode",
    "IcebergCatalogType",
    "IcebergCatalogConfig",
    "IcebergHiveConfig",
    "IcebergRESTConfig",
    "IcebergGlueConfig",
    "IcebergSQLConfig",
    "IcebergS3Config",
]
