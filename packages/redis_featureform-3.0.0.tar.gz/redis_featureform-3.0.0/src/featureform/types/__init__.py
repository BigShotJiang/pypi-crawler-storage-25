"""Domain types for Featureform client."""

from featureform.resources.realtime_feature import (
    FeatureInput,
    FunctionNormalizerDetails,
    RealtimeFeature,
    RealtimeInput,
    SerializerDetails,
)
from featureform.types.catalog import (
    CatalogLocation,
    CatalogLocationOwnership,
    CatalogLocationRef,
    CatalogLocationStatus,
)
from featureform.types.entity import EntityMapping
from featureform.types.graph import (
    GraphDatasetDetail,
    GraphEntityDetail,
    GraphFeatureDetail,
    GraphFeatureViewDetail,
    GraphLabelDetail,
    GraphLineageResult,
    GraphPipelineResult,
    GraphRelationshipResult,
    GraphResourceHistory,
    GraphResourceList,
    GraphResourceSummary,
    GraphTrainingSetDetail,
    GraphVersionDiff,
    GraphVersionSummary,
    GraphWorkspaceOverview,
    GraphWorkspaceStats,
)
from featureform.types.patch import CLEAR, ClearValue
from featureform.types.provider import (
    DynamoDBConfig,
    IcebergCatalogBackend,
    IcebergCatalogConfig,
    IcebergCatalogType,
    IcebergGlueConfig,
    IcebergHiveConfig,
    IcebergRESTConfig,
    IcebergS3Config,
    IcebergS3Warehouse,
    IcebergSQLConfig,
    IcebergWarehouse,
    KafkaConfig,
    PostgresConfig,
    Provider,
    ProviderConfig,
    ProviderHealthStatus,
    ProviderInput,
    ProviderType,
    RedisClusterConfig,
    RedisConfig,
    RedisTLSConfig,
    RedisTLSMode,
    RegisterProviderRequest,
    S3Config,
    SnowflakeConfig,
    SparkKerberosConfig,
    SparkProviderConfig,
    SSLMode,
    UpdateProviderRequest,
)
from featureform.types.provider import (
    SparkProviderConfig as _SparkProviderConfigNamespace,
)
from featureform.types.resource import (
    IcebergPrimaryDataset,
    IcebergTableLocation,
    JoinStrategy,
    MaterializationEngine,
)
from featureform.types.secret import (
    AWSSecretRef,
    AzureSecretRef,
    EnvSecretRef,
    GCPSecretRef,
    K8sSecretRef,
    SecretRef,
    VaultSecretRef,
)
from featureform.types.secret_provider import (
    AWSSecretsManagerSecretConfig,
    EnvSecretConfig,
    KubernetesSecretConfig,
    RegisterSecretProviderRequest,
    SecretProvider,
    SecretProviderConfig,
    SecretProviderInput,
    SecretProviderType,
    UpdateSecretProviderRequest,
    VaultSecretConfig,
)
from featureform.types.workspace import (
    CreateWorkspaceRequest,
    UpdateWorkspaceRequest,
    Workspace,
)

__all__ = [
    # Entity
    "EntityMapping",
    "CLEAR",
    "ClearValue",
    # Graph
    "GraphWorkspaceOverview",
    "GraphWorkspaceStats",
    "GraphResourceSummary",
    "GraphResourceList",
    "GraphFeatureDetail",
    "GraphDatasetDetail",
    "GraphEntityDetail",
    "GraphTrainingSetDetail",
    "GraphLabelDetail",
    "GraphFeatureViewDetail",
    "GraphRelationshipResult",
    "GraphPipelineResult",
    "GraphLineageResult",
    "GraphVersionSummary",
    "GraphVersionDiff",
    "GraphResourceHistory",
    # Secret refs
    "EnvSecretRef",
    "AWSSecretRef",
    "GCPSecretRef",
    "AzureSecretRef",
    "VaultSecretRef",
    "K8sSecretRef",
    "SecretRef",
    # Workspace
    "Workspace",
    "CreateWorkspaceRequest",
    "UpdateWorkspaceRequest",
    # Catalog
    "CatalogLocation",
    "CatalogLocationOwnership",
    "CatalogLocationRef",
    "CatalogLocationStatus",
    # Provider
    "Provider",
    "ProviderType",
    "ProviderConfig",
    "ProviderHealthStatus",
    "ProviderInput",
    "RegisterProviderRequest",
    "UpdateProviderRequest",
    "PostgresConfig",
    "SnowflakeConfig",
    "S3Config",
    "SparkKerberosConfig",
    "SparkProviderConfig",
    "SparkRuntimeProfile",
    "SparkExecutionDefaults",
    "SparkDependencyVersions",
    "SparkDependencyPolicy",
    "SparkHadoopConfig",
    "SparkStagingConfig",
    "SparkBackend",
    "SparkLocalBackend",
    "SparkStandaloneBackend",
    "SparkYarnBackend",
    "SparkK8sBackend",
    "SparkAdvancedConfig",
    "SparkSubmissionArtifactRef",
    "SparkSubmissionKerberosConfig",
    "SparkSubmissionDefaults",
    "DynamoDBConfig",
    "RedisTLSMode",
    "RedisTLSConfig",
    "RedisConfig",
    "RedisClusterConfig",
    "KafkaConfig",
    "SSLMode",
    # Iceberg Provider
    "IcebergCatalogType",
    "IcebergCatalogBackend",
    "IcebergCatalogConfig",
    "IcebergHiveConfig",
    "IcebergRESTConfig",
    "IcebergGlueConfig",
    "IcebergSQLConfig",
    "IcebergS3Config",
    "IcebergWarehouse",
    "IcebergS3Warehouse",
    # Iceberg Resources
    "IcebergTableLocation",
    "IcebergPrimaryDataset",
    "MaterializationEngine",
    "JoinStrategy",
    # Realtime
    "FeatureInput",
    "FunctionNormalizerDetails",
    "RealtimeFeature",
    "RealtimeInput",
    "SerializerDetails",
    # SecretProvider
    "SecretProvider",
    "SecretProviderType",
    "SecretProviderConfig",
    "SecretProviderInput",
    "RegisterSecretProviderRequest",
    "UpdateSecretProviderRequest",
    "AWSSecretsManagerSecretConfig",
    "EnvSecretConfig",
    "VaultSecretConfig",
    "KubernetesSecretConfig",
]

SparkRuntimeProfile = _SparkProviderConfigNamespace.SparkRuntimeProfile
SparkExecutionDefaults = _SparkProviderConfigNamespace.SparkExecutionDefaults
SparkDependencyVersions = _SparkProviderConfigNamespace.SparkDependencyVersions
SparkDependencyPolicy = _SparkProviderConfigNamespace.SparkDependencyPolicy
SparkHadoopConfig = _SparkProviderConfigNamespace.SparkHadoopConfig
SparkStagingConfig = _SparkProviderConfigNamespace.SparkStagingConfig
SparkBackend = _SparkProviderConfigNamespace.SparkBackend
SparkLocalBackend = _SparkProviderConfigNamespace.SparkLocalBackend
SparkStandaloneBackend = _SparkProviderConfigNamespace.SparkStandaloneBackend
SparkYarnBackend = _SparkProviderConfigNamespace.SparkYarnBackend
SparkK8sBackend = _SparkProviderConfigNamespace.SparkK8sBackend
SparkAdvancedConfig = _SparkProviderConfigNamespace.SparkAdvancedConfig
SparkSubmissionArtifactRef = _SparkProviderConfigNamespace.SparkSubmissionArtifactRef
SparkSubmissionKerberosConfig = _SparkProviderConfigNamespace.SparkSubmissionKerberosConfig
SparkSubmissionDefaults = _SparkProviderConfigNamespace.SparkSubmissionDefaults
