"""SecretProvider domain types."""

from datetime import datetime
from enum import Enum
from typing import Annotated
from uuid import UUID

from pydantic import BaseModel, Field, field_serializer, field_validator, model_validator
from pydantic_core import PydanticCustomError

from featureform._internal.secret_refs import secret_ref_from_string, secret_ref_to_string
from featureform.types.secret import SecretRef


class SecretProviderType(str, Enum):
    """Type of secret provider.

    Values must match the lowercase strings returned by the REST API's
    backendToType function in internal/rest/convert/secret_provider.go.
    """

    ENV = "env-var"
    VAULT = "vault"
    K8S = "k8s-secret"
    AWS = "aws-secrets-manager"


class EnvSecretConfig(BaseModel):
    """Configuration for environment variable secret provider."""

    prefix: str = Field("", description="Environment variable prefix")
    allow_defaults: bool = Field(
        False,
        description="Whether secret references may fall back to default values",
    )

    model_config = {
        "frozen": True,
        "extra": "forbid",
    }


class VaultSecretConfig(BaseModel):
    """Configuration for HashiCorp Vault secret provider."""

    address: str = Field(..., description="Vault server address")
    mount_path: str = Field(default="secret", description="KV secrets engine mount path")
    token_path: str | None = Field(None, description="Path to token file")
    namespace: str | None = Field(None, description="Vault namespace")

    model_config = {
        "frozen": True,
        "extra": "forbid",
    }


class KubernetesSecretConfig(BaseModel):
    """Configuration for Kubernetes secret provider."""

    namespace: str = Field(..., description="Kubernetes namespace")
    secret_name: str | None = Field(default=None, description="Default secret name")

    model_config = {
        "frozen": True,
        "extra": "forbid",
    }


class AWSSecretsManagerSecretConfig(BaseModel):
    """Configuration for AWS Secrets Manager secret provider."""

    region: str = Field(..., description="AWS region")
    secret_name: str | None = Field(None, description="Default AWS secret name")
    endpoint: str | None = Field(None, description="Optional custom AWS endpoint")
    access_key_id_secret: SecretRef | None = Field(
        None,
        description="Secret reference for AWS access key ID",
    )
    secret_access_key_secret: SecretRef | None = Field(
        None,
        description="Secret reference for AWS secret access key",
    )
    session_token_secret: SecretRef | None = Field(
        None,
        description="Secret reference for AWS session token",
    )

    model_config = {
        "frozen": True,
        "extra": "forbid",
    }

    @field_validator(
        "access_key_id_secret",
        "secret_access_key_secret",
        "session_token_secret",
        mode="before",
    )
    @classmethod
    def parse_secret_ref_fields(cls, value: object) -> object:
        if isinstance(value, str):
            return secret_ref_from_string(value)
        return value

    @field_serializer(
        "access_key_id_secret",
        "secret_access_key_secret",
        "session_token_secret",
        when_used="json",
    )
    def serialize_secret_ref_fields(self, value: SecretRef | None) -> str | None:
        return secret_ref_to_string(value)

    @model_validator(mode="after")
    def validate_credentials(self) -> "AWSSecretsManagerSecretConfig":
        """Validate AWS credential reference dependencies."""
        has_access_key = self.access_key_id_secret is not None
        has_secret_key = self.secret_access_key_secret is not None
        has_session_token = self.session_token_secret is not None

        if has_access_key != has_secret_key:
            raise PydanticCustomError(
                "featureform_secret_provider_secret_pair",
                "Both access_key_id_secret and secret_access_key_secret must be provided together, "
                "or neither (for IAM/default authentication)",
            )

        if has_session_token and not (has_access_key and has_secret_key):
            raise PydanticCustomError(
                "featureform_secret_provider_session_requires_pair",
                "session_token_secret requires both access_key_id_secret and "
                "secret_access_key_secret",
            )

        return self


SecretProviderConfig = Annotated[
    EnvSecretConfig | VaultSecretConfig | KubernetesSecretConfig | AWSSecretsManagerSecretConfig,
    Field(discriminator=None),
]


class SecretProvider(BaseModel):
    """SecretProvider represents a source for secrets."""

    workspace_id: UUID = Field(..., description="Workspace this provider belongs to")
    name: str = Field(..., min_length=1, max_length=255, description="Provider name")
    description: str | None = Field(default=None, description="Provider description")
    type: SecretProviderType = Field(..., description="Provider type")
    config: SecretProviderConfig = Field(..., description="Provider configuration")
    created_at: datetime = Field(..., description="Creation timestamp")
    updated_at: datetime = Field(..., description="Last update timestamp")

    model_config = {
        "frozen": True,
        "extra": "forbid",
    }


class SecretProviderInput(BaseModel):
    """Input for creating/updating a secret provider."""

    name: str = Field(..., min_length=1, max_length=255)
    type: SecretProviderType = Field(...)
    config: SecretProviderConfig = Field(...)
    description: str | None = Field(default=None, max_length=1000)

    model_config = {
        "extra": "forbid",
    }


class RegisterSecretProviderRequest(BaseModel):
    """Request to register a secret provider."""

    secret_provider: SecretProviderInput = Field(...)

    model_config = {
        "extra": "forbid",
    }


class UpdateSecretProviderRequest(BaseModel):
    """Request to update a secret provider."""

    secret_provider: SecretProviderInput = Field(...)
    force: bool = Field(default=False, description="Force potentially breaking changes")

    model_config = {
        "extra": "forbid",
    }


__all__ = [
    "SecretProvider",
    "SecretProviderType",
    "SecretProviderConfig",
    "SecretProviderInput",
    "RegisterSecretProviderRequest",
    "UpdateSecretProviderRequest",
    "EnvSecretConfig",
    "VaultSecretConfig",
    "KubernetesSecretConfig",
    "AWSSecretsManagerSecretConfig",
]
