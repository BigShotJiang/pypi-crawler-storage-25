"""Resource domain types for the apply command."""

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field

from featureform.types._base import FeatureformModel
from featureform.types.secret import SecretRef


class ScalarType(str, Enum):
    """Scalar data type of a value."""

    INT64 = "INT64"
    FLOAT32 = "FLOAT32"
    FLOAT64 = "FLOAT64"
    STRING = "STRING"
    BOOL = "BOOL"
    DATETIME = "DATETIME"
    TIMESTAMP = "TIMESTAMP"

    def to_proto(self) -> Any:
        """Convert to proto enum value.

        Returns Any to allow passing directly to proto constructors.
        """
        from featureform._generated.proto.featureform.v2 import resource_pb2

        mapping = {
            ScalarType.INT64: resource_pb2.SCALAR_TYPE_INT64,
            ScalarType.FLOAT32: resource_pb2.SCALAR_TYPE_FLOAT32,
            ScalarType.FLOAT64: resource_pb2.SCALAR_TYPE_FLOAT64,
            ScalarType.STRING: resource_pb2.SCALAR_TYPE_STRING,
            ScalarType.BOOL: resource_pb2.SCALAR_TYPE_BOOL,
            ScalarType.DATETIME: resource_pb2.SCALAR_TYPE_DATETIME,
            ScalarType.TIMESTAMP: resource_pb2.SCALAR_TYPE_TIMESTAMP,
        }
        return mapping.get(self, resource_pb2.SCALAR_TYPE_UNSPECIFIED)


class TrainingSetType(str, Enum):
    """Type of training set."""

    STATIC = "STATIC"
    DYNAMIC = "DYNAMIC"
    VIEW = "VIEW"

    def to_proto(self) -> Any:
        """Convert to proto enum value.

        Returns Any to allow passing directly to proto constructors.
        """
        from featureform._generated.proto.featureform.v2 import resource_pb2

        mapping = {
            TrainingSetType.STATIC: resource_pb2.TRAINING_SET_TYPE_STATIC,
            TrainingSetType.DYNAMIC: resource_pb2.TRAINING_SET_TYPE_DYNAMIC,
            TrainingSetType.VIEW: resource_pb2.TRAINING_SET_TYPE_VIEW,
        }
        return mapping.get(self, resource_pb2.TRAINING_SET_TYPE_UNSPECIFIED)


class MaterializationEngine(str, Enum):
    """Engine used to materialize a Feature View."""

    K8S = "K8S"
    SPARK = "SPARK"

    def to_proto(self) -> Any:
        """Convert to proto enum value.

        Returns Any to allow passing directly to proto constructors.
        """
        from featureform._generated.proto.featureform.v2 import resource_pb2

        mapping = {
            MaterializationEngine.K8S: resource_pb2.MATERIALIZATION_ENGINE_K8S,
            MaterializationEngine.SPARK: resource_pb2.MATERIALIZATION_ENGINE_SPARK,
        }
        return mapping.get(self, resource_pb2.MATERIALIZATION_ENGINE_UNSPECIFIED)


class JoinStrategy(str, Enum):
    """Join strategy used to combine feature sources in a Feature View."""

    FULL_OUTER = "FULL_OUTER"
    INNER = "INNER"

    def to_proto(self) -> Any:
        """Convert to proto enum value.

        Returns Any to allow passing directly to proto constructors.
        """
        from featureform._generated.proto.featureform.v2 import resource_pb2

        mapping = {
            JoinStrategy.FULL_OUTER: resource_pb2.JOIN_STRATEGY_FULL_OUTER,
            JoinStrategy.INNER: resource_pb2.JOIN_STRATEGY_INNER,
        }
        return mapping.get(self, resource_pb2.JOIN_STRATEGY_UNSPECIFIED)


class AggregateFunction(str, Enum):
    """Aggregation function for features."""

    SUM = "SUM"
    MEAN = "MEAN"
    COUNT = "COUNT"
    MIN = "MIN"
    MAX = "MAX"
    APPROXIMATE_PERCENTILE = "APPROXIMATE_PERCENTILE"
    APPROXIMATE_UNIQUE_COUNT = "APPROXIMATE_UNIQUE_COUNT"

    def to_proto(self) -> Any:
        """Convert to proto enum value.

        Returns Any to allow passing directly to proto constructors.
        """
        from featureform._generated.proto.featureform.v2 import resource_pb2

        mapping = {
            AggregateFunction.SUM: resource_pb2.AGGREGATE_FUNCTION_SUM,
            AggregateFunction.MEAN: resource_pb2.AGGREGATE_FUNCTION_MEAN,
            AggregateFunction.COUNT: resource_pb2.AGGREGATE_FUNCTION_COUNT,
            AggregateFunction.MIN: resource_pb2.AGGREGATE_FUNCTION_MIN,
            AggregateFunction.MAX: resource_pb2.AGGREGATE_FUNCTION_MAX,
            AggregateFunction.APPROXIMATE_PERCENTILE: resource_pb2.AGGREGATE_FUNCTION_APPROXIMATE_PERCENTILE,
            AggregateFunction.APPROXIMATE_UNIQUE_COUNT: resource_pb2.AGGREGATE_FUNCTION_APPROXIMATE_UNIQUE_COUNT,
        }
        return mapping.get(self, resource_pb2.AGGREGATE_FUNCTION_UNSPECIFIED)


class ValueType(BaseModel):
    """Represents the data type of a feature or label."""

    scalar_type: ScalarType = Field(..., description="The scalar data type")
    is_vector: bool = Field(default=False, description="Whether this is a vector type")
    dimension: int = Field(
        default=0, ge=0, description="Vector dimension (must be > 0 for vectors)"
    )
    is_embedding: bool = Field(default=False, description="Whether this is an embedding vector")

    model_config = {
        "frozen": True,
        "extra": "forbid",
    }

    def to_proto(self) -> Any:
        """Convert to proto ValueType message.

        Returns:
            A resource_pb2.ValueType protobuf message.
        """
        from featureform._generated.proto.featureform.v2 import resource_pb2

        return resource_pb2.ValueType(
            scalar_type=self.scalar_type.to_proto(),
            is_vector=self.is_vector,
            dimension=self.dimension,
            is_embedding=self.is_embedding,
        )


class Entity(BaseModel):
    """Entity represents a join key that connects features together."""

    name: str = Field(..., min_length=1, description="Entity name")
    description: str = Field(default="", description="Optional description")

    model_config = {
        "frozen": True,
        "extra": "forbid",
    }


class TableLocation(FeatureformModel):
    """Represents a table in a SQL database."""

    database: str = Field(default="", description="Database name")
    schema: str = Field(default="", description="Schema name")
    table: str = Field(..., min_length=1, description="Table name")

    model_config = {
        "frozen": True,
        "extra": "forbid",
        "populate_by_name": True,
    }


class IcebergTableLocation(BaseModel):
    """Represents a table in an Iceberg catalog."""

    namespace: str = Field(default="", description="Iceberg namespace")
    table: str = Field(..., min_length=1, description="Table name")

    model_config = {"frozen": True, "extra": "forbid"}


class SparkEnv(BaseModel):
    """Environment values and secrets for one Spark scope."""

    values: dict[str, str] = Field(default_factory=dict, description="Plain env values")
    secrets: dict[str, SecretRef] = Field(default_factory=dict, description="Secret env values")

    model_config = {"frozen": True, "extra": "forbid"}


class SparkExecutionDefaults(BaseModel):
    """Structured Spark execution overrides."""

    driver_cores: int | None = Field(default=None, ge=1, description="Driver cores")
    driver_memory: str | None = Field(default=None, description="Driver memory")
    executor_memory: str | None = Field(default=None, description="Executor memory")
    executor_cores: int | None = Field(default=None, ge=1, description="Executor cores")
    num_executors: int | None = Field(default=None, ge=1, description="Number of executors")
    shuffle_partitions: int | None = Field(default=None, ge=1, description="Shuffle partitions")

    model_config = {"frozen": True, "extra": "forbid"}


class SparkJobConfig(BaseModel):
    """Per-job Spark override configuration."""

    catalogs: dict[str, str] = Field(default_factory=dict, description="Spark catalog aliases")
    backend: dict[str, object] | None = Field(default=None, description="Typed backend override")
    hadoop: dict[str, object] | None = Field(default=None, description="Typed Hadoop override")
    staging: dict[str, object] | None = Field(default=None, description="Typed staging override")
    deploy_mode: str | None = Field(default=None, description="Spark deploy mode")
    execution_defaults: SparkExecutionDefaults = Field(default_factory=SparkExecutionDefaults)
    spark_conf: dict[str, str] = Field(default_factory=dict, description="Additional Spark config")
    driver_env: SparkEnv = Field(default_factory=SparkEnv, description="Driver environment")
    executor_env: SparkEnv = Field(default_factory=SparkEnv, description="Executor environment")

    model_config = {"frozen": True, "extra": "forbid"}


class IcebergConfig(BaseModel):
    """Iceberg table configuration."""

    catalog: str = Field(..., min_length=1, description="Iceberg catalog name")
    namespace: str = Field(..., min_length=1, description="Iceberg namespace")
    table: str = Field(..., min_length=1, description="Iceberg table name")

    model_config = {"frozen": True, "extra": "forbid"}


class PostgresDatasetConfig(FeatureformModel):
    """PostgreSQL dataset output configuration."""

    schema: str = Field(default="public", description="Schema name")
    table: str = Field(..., min_length=1, description="Table name")

    model_config = {"frozen": True, "extra": "forbid", "populate_by_name": True}


class FeatureLag(BaseModel):
    """Time-shifted version of a feature."""

    feature: str = Field(..., min_length=1, description="Feature name")
    name: str = Field(..., min_length=1, description="Name for the lagged feature")
    lag: str = Field(..., min_length=1, description="Lag duration (e.g., '1d', '7d')")

    model_config = {"frozen": True, "extra": "forbid"}


class PrimaryDataset(BaseModel):
    """Primary dataset represents raw data from external sources."""

    name: str = Field(..., min_length=1, description="Dataset name")
    description: str = Field(default="", description="Optional description")
    provider: str = Field(..., min_length=1, description="Provider name")
    location: TableLocation = Field(..., description="Table location")
    timestamp_column: str = Field(default="", description="Timestamp column name")

    model_config = {"frozen": True, "extra": "forbid"}


class IcebergPrimaryDataset(BaseModel):
    """Primary dataset from an Iceberg table."""

    name: str = Field(..., min_length=1, description="Dataset name")
    description: str = Field(default="", description="Optional description")
    provider: str = Field(..., min_length=1, description="Provider name")
    location: IcebergTableLocation = Field(..., description="Iceberg table location")
    timestamp_column: str = Field(default="", description="Timestamp column name")

    model_config = {"frozen": True, "extra": "forbid"}


class PostgresTransformedDataset(BaseModel):
    """Postgres transformed dataset."""

    name: str = Field(..., min_length=1, description="Dataset name")
    description: str = Field(default="", description="Optional description")
    provider: str = Field(default="", description="Provider name")
    source_datasets: list[str] = Field(..., min_length=1, description="Source dataset names")
    sql_query: str = Field(..., min_length=1, description="SQL query for transformation")
    postgres_config: PostgresDatasetConfig = Field(..., description="Postgres output config")

    model_config = {"frozen": True, "extra": "forbid"}


class Label(BaseModel):
    """Label represents a target variable for training ML models."""

    name: str = Field(..., min_length=1, description="Label name")
    description: str = Field(default="", description="Optional description")
    entities: list[str] = Field(..., min_length=1, description="Entity names")
    entity_fields: list[str] = Field(default_factory=list, description="Entity field columns")
    value_field: str = Field(..., min_length=1, description="Column name for the label value")
    timestamp_field: str = Field(default="", description="Timestamp field name")
    source_dataset: str = Field(..., min_length=1, description="Source dataset name")
    provider: str = Field(default="", description="Provider name")
    value_type: ValueType = Field(..., description="Data type of the label")

    model_config = {"frozen": True, "extra": "forbid"}


class TrainingSet(BaseModel):
    """Training set represents a combination of features and a label for ML training."""

    name: str = Field(..., min_length=1, description="Training set name")
    description: str = Field(default="", description="Optional description")
    provider: str = Field(default="", description="Provider name")
    features: list[str] = Field(..., min_length=1, description="Feature names")
    label: str = Field(..., min_length=1, description="Label name")
    type: TrainingSetType = Field(
        default=TrainingSetType.DYNAMIC, description="Type of training set"
    )
    feature_lags: list[FeatureLag] = Field(
        default_factory=list, description="Feature lag definitions"
    )
    compute_job_config: SparkJobConfig | None = Field(
        default=None, description="Optional Spark compute settings"
    )

    model_config = {"frozen": True, "extra": "forbid"}


class FeatureView(BaseModel):
    """Feature View groups features for online inference and offline retrieval.

    All features in a Feature View must share the same entity.
    """

    name: str = Field(..., min_length=1, description="Feature View name")
    description: str = Field(default="", description="Optional description")
    entity: str = Field(..., min_length=1, description="Entity name (all features must share)")
    features: list[str] = Field(..., min_length=1, description="Feature names")
    provider: str = Field(
        default="",
        description="Offline provider that owns feature-view compute and artifacts",
    )
    inference_store: str = Field(default="", description="Provider for storing materialized data")
    materialization_engine: MaterializationEngine = Field(
        ..., description="Engine for materialization (K8S or SPARK)"
    )
    spark_provider: str = Field(default="", description="Spark runtime provider for SPARK engine")
    materialize_job_config: SparkJobConfig | None = Field(
        default=None, description="Optional Spark materialization settings"
    )
    join_strategy: JoinStrategy = Field(
        default=JoinStrategy.FULL_OUTER,
        description="How deduplicated feature sources are combined",
    )
    batch_only: bool = Field(default=False, description="Keep only the offline batch snapshot")

    model_config = {"frozen": True, "extra": "forbid"}


# Type alias for all resource types
Resource = (
    Entity
    | PrimaryDataset
    | IcebergPrimaryDataset
    | PostgresTransformedDataset
    | Label
    | TrainingSet
    | FeatureView
)


__all__ = [
    "ScalarType",
    "TrainingSetType",
    "MaterializationEngine",
    "JoinStrategy",
    "AggregateFunction",
    "ValueType",
    "Entity",
    "TableLocation",
    "IcebergTableLocation",
    "SparkEnv",
    "SparkExecutionDefaults",
    "SparkJobConfig",
    "IcebergConfig",
    "PostgresDatasetConfig",
    "FeatureLag",
    "PrimaryDataset",
    "IcebergPrimaryDataset",
    "PostgresTransformedDataset",
    "Label",
    "TrainingSet",
    "FeatureView",
    "Resource",
]
