"""Workspace domain types."""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, Field


class Workspace(BaseModel):
    """Workspace represents a logical grouping of resources."""

    id: UUID = Field(..., description="Unique identifier")
    name: str = Field(..., min_length=1, max_length=255, description="Workspace name")
    description: str | None = Field(None, description="Optional description")
    created_at: datetime = Field(..., description="Creation timestamp")
    updated_at: datetime = Field(..., description="Last update timestamp")
    last_applied_version: int = Field(0, description="Last applied version number")

    model_config = {
        "frozen": True,
        "extra": "forbid",
    }


class CreateWorkspaceRequest(BaseModel):
    """Request to create a workspace."""

    name: str = Field(..., min_length=1, max_length=255)
    description: str | None = Field(None)

    model_config = {
        "extra": "forbid",
    }


class UpdateWorkspaceRequest(BaseModel):
    """Request to update a workspace.

    Note: The server requires name to be provided on update.
    """

    name: str = Field(..., min_length=1, max_length=255)
    description: str | None = Field(None)

    model_config = {
        "extra": "forbid",
    }


__all__ = [
    "Workspace",
    "CreateWorkspaceRequest",
    "UpdateWorkspaceRequest",
]
