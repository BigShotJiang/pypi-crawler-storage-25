"""Catalog domain types."""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, Field

from featureform.types._base import FeatureformModel


class CatalogLocationStatus(str, Enum):
    """Status of a physical catalog location."""

    UNSPECIFIED = "UNSPECIFIED"
    CREATING = "CREATING"
    READY = "READY"
    FAILED = "FAILED"
    DELETING = "DELETING"


class CatalogLocationOwnership(str, Enum):
    """Ownership of a physical catalog location."""

    UNSPECIFIED = "UNSPECIFIED"
    EXTERNAL = "EXTERNAL"
    MANAGED = "MANAGED"


class CatalogLocationRef(FeatureformModel):
    """Physical location details for a dataset."""

    type: Literal["table", "iceberg", "unknown"] = Field(..., description="Location type")
    database: str = Field(default="", description="Database name for SQL tables")
    schema: str = Field(
        default="",
        description="Schema name for SQL tables",
    )
    table: str = Field(default="", description="Table name")
    namespace: str = Field(default="", description="Iceberg namespace")

    model_config = {"frozen": True, "extra": "forbid", "populate_by_name": True}


class CatalogLocation(BaseModel):
    """Catalog entry describing where a logical dataset lives physically."""

    workspace_id: UUID
    resource_name: str = Field(..., min_length=1)
    provider_name: str = Field(..., min_length=1)
    ownership: CatalogLocationOwnership = CatalogLocationOwnership.UNSPECIFIED
    status: CatalogLocationStatus
    location: CatalogLocationRef
    inputs: list[str] = Field(default_factory=list)
    error_message: str = ""
    created_at: datetime | None = None
    updated_at: datetime | None = None

    model_config = {"frozen": True, "extra": "forbid"}
