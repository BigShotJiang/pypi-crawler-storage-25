"""Patch helpers."""


class ClearValue:
    """Sentinel used to explicitly clear a field in patch requests."""

    def __repr__(self) -> str:
        return "CLEAR"


CLEAR = ClearValue()


__all__ = ["CLEAR", "ClearValue"]
