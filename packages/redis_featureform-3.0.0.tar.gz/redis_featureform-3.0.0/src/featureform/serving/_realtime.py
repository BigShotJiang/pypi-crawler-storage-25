"""Realtime serving execution helpers."""

from __future__ import annotations

import base64
import importlib.metadata
import pickle
import platform
from collections.abc import Callable, Mapping
from typing import Any, cast

import cloudpickle
from packaging.requirements import InvalidRequirement, Requirement
from packaging.version import InvalidVersion, Version

from featureform.serving.types import (
    FeatureSchema,
    FeatureViewMetadata,
    RealtimeFeatureMetadata,
    ServeResult,
)


class RealtimeExecutor:
    """Executes realtime features from serving metadata and fetched values."""

    def __init__(self) -> None:
        self._callable_cache: dict[tuple[Any, ...], Callable[..., Any]] = {}

    def apply(
        self,
        metadata: FeatureViewMetadata,
        serve_result: ServeResult,
        requests: list[dict[str, Any]] | None,
        features: list[str] | None,
    ) -> ServeResult:
        schema_features = (
            metadata.feature_schema.features if metadata.feature_schema else metadata.features
        )
        features_by_name = {feature.name: feature for feature in schema_features}
        effective_outputs = (
            features
            if features
            else [feature.name for feature in schema_features if getattr(feature, "exposed", True)]
        )
        requested_realtime = [
            features_by_name[name]
            for name in effective_outputs
            if getattr(features_by_name[name], "mode", "stored") == "realtime"
        ]

        if not requested_realtime:
            filtered = self._filter_exposed_outputs(
                entity_name=metadata.entity,
                schema_features=schema_features,
                effective_outputs=effective_outputs,
                serve_result=serve_result,
            )
            return ServeResult(results=filtered)

        requests_by_entity = self._index_requests(requests)
        artifacts_by_name = {feature.name: feature for feature in metadata.realtime_features}
        for feature in requested_realtime:
            artifact = artifacts_by_name.get(feature.name)
            if artifact is None:
                raise ValueError(f"Missing realtime metadata for feature '{feature.name}'")
            self._validate_artifact_compatibility(artifact)

        final_results: dict[str, dict[str, Any]] = {}
        entity_ids = set(serve_result.results) | set(serve_result.backing_values)
        for entity in entity_ids:
            working_values = dict(serve_result.backing_values.get(entity, {}))
            working_values.update(serve_result.results.get(entity, {}))
            final_values: dict[str, Any] = {}
            runtime_inputs = requests_by_entity[entity].get("inputs", {})
            for output_name in effective_outputs:
                feature = features_by_name[output_name]
                if getattr(feature, "mode", "stored") == "stored":
                    if output_name in working_values:
                        final_values[output_name] = working_values[output_name]
                    continue

                artifact = artifacts_by_name[output_name]
                final_values[output_name] = self._execute_realtime_feature(
                    artifact,
                    working_values=working_values,
                    runtime_inputs=runtime_inputs,
                )
            entity_key = serve_result.results.get(entity, {}).get(metadata.entity)
            if entity_key is not None:
                final_values[metadata.entity] = entity_key
            if final_values:
                final_results[entity] = final_values

        return ServeResult(results=final_results)

    def _filter_exposed_outputs(
        self,
        *,
        entity_name: str,
        schema_features: list[FeatureSchema],
        effective_outputs: list[str],
        serve_result: ServeResult,
    ) -> dict[str, dict[str, Any]]:
        features_by_name = {feature.name: feature for feature in schema_features}
        filtered: dict[str, dict[str, Any]] = {}
        for entity, values in serve_result.results.items():
            entity_values = {
                name: values[name]
                for name in effective_outputs
                if name in values and getattr(features_by_name[name], "exposed", True)
            }
            if entity_name in values:
                entity_values[entity_name] = values[entity_name]
            if entity_values:
                filtered[entity] = entity_values
        return filtered

    def _index_requests(self, requests: list[dict[str, Any]] | None) -> dict[str, dict[str, Any]]:
        indexed: dict[str, dict[str, Any]] = {}
        for request in requests or []:
            indexed[str(request["entity"])] = request
        return indexed

    def _execute_realtime_feature(
        self,
        artifact: RealtimeFeatureMetadata,
        *,
        working_values: Mapping[str, Any],
        runtime_inputs: Mapping[str, Any],
    ) -> Any:
        fn = self._load_callable(artifact)
        args: list[Any] = []
        for input_value in artifact.inputs:
            if input_value.source_type == "stored_field":
                if input_value.source_name not in working_values:
                    raise ValueError(
                        f"Missing stored dependency '{input_value.source_name}' "
                        f"for realtime feature '{artifact.name}'"
                    )
                args.append(working_values[input_value.source_name])
                continue

            if input_value.source_type == "runtime_input":
                if input_value.source_name not in runtime_inputs:
                    raise ValueError(
                        f"Missing runtime input '{input_value.source_name}' "
                        f"for realtime feature '{artifact.name}'"
                    )
                args.append(runtime_inputs[input_value.source_name])
                continue

            raise ValueError(
                f"Unsupported realtime input source type '{input_value.source_type}' "
                f"for feature '{artifact.name}'"
            )
        return fn(*args)

    def _load_callable(self, artifact: RealtimeFeatureMetadata) -> Callable[..., Any]:
        cache_key = (
            artifact.name,
            artifact.serialized_function,
            artifact.serialization_python_version,
            artifact.serializer_details.get("name"),
            artifact.serializer_details.get("version"),
            artifact.serializer_details.get("protocol"),
        )
        cached = self._callable_cache.get(cache_key)
        if cached is not None:
            return cached

        decoded = base64.b64decode(artifact.serialized_function)
        loaded = cast(Callable[..., Any], cloudpickle.loads(decoded))
        self._callable_cache[cache_key] = loaded
        return loaded

    def _validate_artifact_compatibility(self, artifact: RealtimeFeatureMetadata) -> None:
        required_python = artifact.serialization_python_version
        current_python = platform.python_version()
        if self._major_minor(current_python) != self._major_minor(required_python):
            raise ValueError(
                f"Python version mismatch for realtime feature '{artifact.name}': "
                f"requires {required_python}, client is {current_python}"
            )

        serializer_name = str(artifact.serializer_details.get("name", ""))
        if serializer_name != "cloudpickle":
            raise ValueError(
                f"Unsupported serializer '{serializer_name}' for realtime feature '{artifact.name}'"
            )
        serializer_version = str(artifact.serializer_details.get("version", ""))
        if serializer_version != cloudpickle.__version__:
            raise ValueError(
                f"Serializer version mismatch for realtime feature '{artifact.name}': "
                f"requires {serializer_version}, client has {cloudpickle.__version__}"
            )

        protocol = int(artifact.serializer_details.get("protocol", pickle.HIGHEST_PROTOCOL))
        if protocol > pickle.HIGHEST_PROTOCOL:
            raise ValueError(
                f"Serializer protocol mismatch for realtime feature '{artifact.name}': "
                f"requires {protocol}, client supports {pickle.HIGHEST_PROTOCOL}"
            )

        for requirement in artifact.requirements:
            parsed_requirement = self._parse_requirement(requirement)
            package_name = (
                parsed_requirement.name
                if parsed_requirement is not None
                else self._package_name(requirement)
            )
            try:
                installed_version = importlib.metadata.version(package_name)
            except importlib.metadata.PackageNotFoundError as exc:
                raise ValueError(
                    f"Missing required package '{package_name}' for realtime feature '{artifact.name}'"
                ) from exc

            if parsed_requirement is None or not parsed_requirement.specifier:
                continue

            try:
                parsed_version = Version(installed_version)
            except InvalidVersion as exc:
                raise ValueError(
                    f"Installed package '{package_name}' has invalid version "
                    f"'{installed_version}' for realtime feature '{artifact.name}'"
                ) from exc

            if parsed_version not in parsed_requirement.specifier:
                raise ValueError(
                    f"Installed package '{package_name}' version {installed_version} "
                    f"does not satisfy requirement '{requirement}' "
                    f"for realtime feature '{artifact.name}'"
                )

    def _major_minor(self, version: str) -> tuple[str, str]:
        parts = version.split(".")
        if len(parts) < 2:
            return version, ""
        return parts[0], parts[1]

    def _package_name(self, requirement: str) -> str:
        parsed_requirement = self._parse_requirement(requirement)
        if parsed_requirement is not None:
            return parsed_requirement.name
        return requirement

    def _parse_requirement(self, requirement: str) -> Requirement | None:
        try:
            return Requirement(requirement)
        except InvalidRequirement:
            return None
