"""Helpers for serving metadata payloads."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any, cast

from featureform.serving.types import (
    FeatureSchema,
    FeatureViewMetadata,
    FeatureViewSchema,
    RealtimeFeatureInput,
    RealtimeFeatureMetadata,
)


def metadata_from_dict(data: Mapping[str, Any]) -> FeatureViewMetadata:
    """Build feature view metadata from the REST metadata payload."""
    raw_features = data.get("features", [])
    features = raw_features if isinstance(raw_features, list) else []
    raw_feature_schema = data.get("feature_schema")

    parsed_features = [
        FeatureSchema(
            name=str(typed_feature["name"]),
            type=str(typed_feature["type"]),
            nullable=bool(typed_feature.get("nullable", True)),
            mode=str(typed_feature.get("mode", "stored")),
            exposed=bool(typed_feature.get("exposed", True)),
        )
        for feature in features
        for typed_feature in [cast(Mapping[str, Any], feature)]
        if isinstance(feature, Mapping)
    ]

    feature_schema = None
    if isinstance(raw_feature_schema, Mapping):
        typed_feature_schema = cast(Mapping[str, Any], raw_feature_schema)
        raw_schema_features = typed_feature_schema.get("features", [])
        schema_features = raw_schema_features if isinstance(raw_schema_features, list) else []
        parsed_schema_features = [
            FeatureSchema(
                name=str(typed_feature["name"]),
                type=str(typed_feature["type"]),
                nullable=bool(typed_feature.get("nullable", True)),
                mode=str(typed_feature.get("mode", "stored")),
                exposed=bool(typed_feature.get("exposed", True)),
            )
            for feature in schema_features
            for typed_feature in [cast(Mapping[str, Any], feature)]
            if isinstance(feature, Mapping)
        ]
        feature_schema = FeatureViewSchema(features=parsed_schema_features)

    raw_realtime_features = data.get("realtime_features", [])
    realtime_features = raw_realtime_features if isinstance(raw_realtime_features, list) else []
    return FeatureViewMetadata(
        name=str(data["name"]),
        entity=str(data["entity"]),
        features=parsed_features,
        key_prefix=str(data["key_prefix"]),
        version=int(data["version"]),
        entity_columns=[
            str(column)
            for column in cast(list[Any], data.get("entity_columns", [str(data["entity"])]))
        ],
        feature_schema=feature_schema,
        realtime_features=[
            RealtimeFeatureMetadata(
                name=str(typed_feature["name"]),
                requirements=[
                    str(requirement)
                    for requirement in cast(list[Any], typed_feature.get("requirements", []))
                ],
                normalized_function_string=str(typed_feature["normalized_function_string"]),
                function_normalizer_details=dict(
                    cast(Mapping[str, Any], typed_feature["function_normalizer_details"])
                ),
                serialized_function=str(typed_feature["serialized_function"]),
                extracted_function_string=str(typed_feature["extracted_function_string"]),
                serialization_python_version=str(typed_feature["serialization_python_version"]),
                serializer_details=dict(
                    cast(Mapping[str, Any], typed_feature["serializer_details"])
                ),
                inputs=[
                    RealtimeFeatureInput(
                        source_type=str(typed_input["source_type"]),
                        source_name=str(typed_input["source_name"]),
                    )
                    for input_value in cast(list[Any], typed_feature.get("inputs", []))
                    for typed_input in [cast(Mapping[str, Any], input_value)]
                    if isinstance(input_value, Mapping)
                ],
            )
            for feature in realtime_features
            for typed_feature in [cast(Mapping[str, Any], feature)]
            if isinstance(feature, Mapping)
        ],
    )
