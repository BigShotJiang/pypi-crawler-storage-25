"""Serving client for online feature retrieval with BYOC support."""

from __future__ import annotations

import logging
from collections.abc import Callable, Iterable, Mapping, Sequence
from typing import TYPE_CHECKING, Any, cast
from urllib.parse import urlparse

from featureform._generated.proto.featureform.v2 import serving_pb2
from featureform.errors import NotFoundError
from featureform.serving._decode import (
    build_entity_list,
    deserialize_value,
    parse_raw_features,
)
from featureform.serving._metadata import metadata_from_dict
from featureform.serving._realtime import RealtimeExecutor
from featureform.serving.cache import MetadataCache
from featureform.serving.types import (
    FeatureSchema,
    FeatureViewMetadata,
    FeatureViewSchema,
    RealtimeFeatureInput,
    RealtimeFeatureMetadata,
    RedisLike,
    ServeResult,
    WarmLoadResult,
)

_logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from featureform.transport.grpc import GRPCTransport


class ServingClient:
    """Client for online feature serving with BYOC support."""

    def __init__(
        self,
        base_url: str = "http://localhost:8080",
        default_workspace: str = "default",
        redis: RedisLike | None = None,
        grpc_transport: Any | None = None,
        token: str | None = None,
        token_provider: Callable[[], str | None] | None = None,
        rest_base_url: str | None = None,
        background_refresh: bool = True,
        refresh_interval: int = 30,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._rest_metadata_base_url = (
            rest_base_url.rstrip("/") if rest_base_url is not None else None
        )
        self._default_workspace = default_workspace
        self._default_redis = redis
        self._grpc_transport = grpc_transport
        self._token = token
        self._token_provider = token_provider
        import requests  # type: ignore[import-untyped]

        self._session = requests.Session()
        self._cache = MetadataCache(
            fetch_fn=self._fetch_metadata, refresh_interval=refresh_interval
        )
        if background_refresh:
            self._cache.start_background_refresh()

    def _resolve_token(self) -> str | None:
        token_provider = cast(
            Callable[[], str | None] | None,
            getattr(self, "_token_provider", None),
        )
        if token_provider is not None:
            return token_provider()
        return cast(str | None, getattr(self, "_token", None))

    def _request(self, method: str, url: str, **kwargs: Any) -> Any:
        headers = dict(kwargs.pop("headers", {}))
        token = self._resolve_token()
        if token:
            headers["Authorization"] = f"Bearer {token}"
        return self._session.request(method, url, headers=headers, **kwargs)

    def serve(
        self,
        feature_view: str,
        entity: str | Mapping[str, str] | None = None,
        entities: list[str] | list[Mapping[str, str]] | None = None,
        requests: list[dict[str, Any]] | None = None,
        workspace: str | None = None,
        redis: RedisLike | None = None,
        include_key: bool = False,
        features: list[str] | None = None,
        return_type: str = "dict",
    ) -> ServeResult | dict[str, Any] | Any:
        ws = workspace or self._default_workspace
        redis_client = redis or self._default_redis
        if requests is not None and (entity is not None or entities is not None):
            raise ValueError("Cannot mix legacy entity/entities arguments with requests")

        metadata = self._cache.get_or_fetch(ws, feature_view)
        single = False
        single_key = ""
        entity_list: Sequence[str | Mapping[str, str]]
        if requests is not None:
            request_entity_list = self._build_request_entity_list(requests)
            entity_list = request_entity_list
            single = len(request_entity_list) == 1
            if request_entity_list:
                single_key = request_entity_list[0]
        else:
            single, entity_values = build_entity_list(entity, entities)
            if not entity_values:
                raise ValueError("Must provide either 'entity' or 'entities'")
            entity_list = entity_values
            if single and entity_values:
                single_key = self._entity_to_key(metadata, entity_values[0])
        self._validate_requested_features(metadata, features)
        if requests is None:
            self._validate_legacy_request(metadata, features)

        if redis_client is not None:
            result = self._serve_direct(redis_client, metadata, entity_list, include_key, features)
        elif getattr(self, "_grpc_transport", None) is not None:
            result = self._serve_standard_grpc(ws, feature_view, entity_list, include_key, features)
        else:
            result = self._serve_standard(ws, feature_view, entity_list, include_key, features)

        if self._should_apply_realtime(metadata, features):
            result = self._apply_realtime_features(
                metadata=metadata,
                result=result,
                requests=requests,
                features=features,
            )

        # Handle return type conversions
        if return_type == "pandas":
            return self._to_pandas(result)

        # For single entity queries, extract the dict first, then convert
        # This ensures numpy/torch conversions are applied to the final result
        if single:
            single_result = result.results.get(single_key, {})
            if return_type == "numpy":
                return self._to_numpy_dict(single_result)
            elif return_type == "torch":
                return self._to_torch_dict(single_result)
            return single_result

        # Multi-entity queries
        if return_type == "numpy":
            return self._to_numpy(result)
        elif return_type == "torch":
            return self._to_torch(result)
        return result

    def get_serving_metadata(
        self,
        feature_view: str,
        workspace: str | None = None,
        *,
        refresh: bool = False,
    ) -> FeatureViewMetadata:
        ws = workspace or self._default_workspace
        if refresh:
            metadata = self._fetch_metadata(ws, feature_view)
            self._cache.set(ws, feature_view, metadata)
            return metadata
        return self._cache.get_or_fetch(ws, feature_view)

    def _apply_realtime_features(
        self,
        *,
        metadata: FeatureViewMetadata,
        result: ServeResult,
        requests: list[dict[str, Any]] | None,
        features: list[str] | None,
    ) -> ServeResult:
        executor = getattr(self, "_realtime_executor", None)
        if executor is None:
            executor = RealtimeExecutor()
            self._realtime_executor = executor
        return executor.apply(metadata, result, requests, features)

    def _should_apply_realtime(
        self,
        metadata: FeatureViewMetadata,
        features: list[str] | None,
    ) -> bool:
        """Return whether the effective requested outputs include any realtime features."""
        schema_features = (
            metadata.feature_schema.features if metadata.feature_schema else metadata.features
        )
        features_by_name = {feature.name: feature for feature in schema_features}
        effective_outputs = (
            features
            if features
            else [feature.name for feature in schema_features if getattr(feature, "exposed", True)]
        )
        return any(
            getattr(features_by_name[feature_name], "mode", "stored") == "realtime"
            for feature_name in effective_outputs
        )

    def _build_request_entity_list(self, requests: list[dict[str, Any]]) -> list[str]:
        """Extract and validate entity IDs from the realtime request shape."""
        if not requests:
            raise ValueError("requests must be a non-empty list")

        entity_list: list[str] = []
        seen: set[str] = set()
        for request in requests:
            entity = request.get("entity")
            if entity is None or str(entity) == "":
                raise ValueError("Each request must include a non-empty entity")
            entity_str = str(entity)
            if entity_str in seen:
                raise ValueError(f"Duplicate entity in requests: {entity_str}")
            seen.add(entity_str)
            entity_list.append(entity_str)
        return entity_list

    def _validate_requested_features(
        self,
        metadata: FeatureViewMetadata,
        features: list[str] | None,
    ) -> None:
        """Validate requested output names against feature-view serving metadata."""
        if not features:
            return

        schema_features = (
            metadata.feature_schema.features if metadata.feature_schema else metadata.features
        )
        features_by_name = {feature.name: feature for feature in schema_features}

        for feature_name in features:
            feature = features_by_name.get(feature_name)
            if feature is None:
                raise ValueError(f"Unknown feature requested: {feature_name}")
            if not getattr(feature, "exposed", True):
                raise ValueError(f"Cannot request hidden backing field: {feature_name}")

    def _validate_legacy_request(
        self,
        metadata: FeatureViewMetadata,
        features: list[str] | None,
    ) -> None:
        """Validate legacy entity/entities requests against feature-view serving metadata."""
        schema_features = (
            metadata.feature_schema.features if metadata.feature_schema else metadata.features
        )
        features_by_name = {feature.name: feature for feature in schema_features}
        requested_features = (
            features
            if features
            else [feature.name for feature in schema_features if getattr(feature, "exposed", True)]
        )

        for feature_name in requested_features:
            feature = features_by_name[feature_name]
            if getattr(feature, "mode", "stored") == "realtime":
                raise ValueError(
                    "Legacy entity/entities serving cannot request realtime outputs; "
                    "use the realtime request shape"
                )

    def _serve_direct(
        self,
        redis_client: RedisLike,
        metadata: FeatureViewMetadata,
        entities: Sequence[str | Mapping[str, str]],
        include_key: bool,
        features: list[str] | None,
    ) -> ServeResult:
        results: dict[str, dict[str, Any]] = {}
        backing_values: dict[str, dict[str, Any]] = {}
        result_names, backing_names, fetch_names = self._build_direct_fetch_plan(metadata, features)
        pipe = redis_client.pipeline()
        entity_keys: list[str] = []
        for e in entities:
            entity_key = self._entity_to_key(metadata, e)
            entity_keys.append(entity_key)
            key = f"{metadata.key_prefix}{entity_key}"
            pipe.hgetall(key) if fetch_names is None else pipe.hmget(key, *fetch_names)
        raw_results = pipe.execute()
        for entity_key, raw in zip(entity_keys, raw_results, strict=True):
            if not raw:
                continue
            # For hmget, [None, None, ...] is truthy but means key doesn't exist
            if isinstance(raw, list) and all(v is None for v in raw):
                continue
            fetched_values = parse_raw_features(raw, metadata, fetch_names)
            result_values = {
                name: fetched_values[name] for name in result_names if name in fetched_values
            }
            backing_value_map = {
                name: fetched_values[name] for name in backing_names if name in fetched_values
            }
            if not result_values and not backing_value_map:
                # No actual feature values parsed (all were null)
                continue
            if include_key:
                key_name = (
                    metadata.entity_columns[0]
                    if len(metadata.entity_columns) == 1
                    else metadata.entity
                )
                result_values[key_name] = entity_key
            if result_values:
                results[entity_key] = result_values
            if backing_value_map:
                backing_values[entity_key] = backing_value_map
        return ServeResult(results=results, backing_values=backing_values)

    def _build_direct_fetch_plan(
        self,
        metadata: FeatureViewMetadata,
        requested_features: list[str] | None,
    ) -> tuple[list[str], list[str], list[str] | None]:
        schema_features = (
            metadata.feature_schema.features if metadata.feature_schema else metadata.features
        )
        requested_outputs = (
            requested_features
            if requested_features
            else [feature.name for feature in schema_features if getattr(feature, "exposed", True)]
        )
        features_by_name = {feature.name: feature for feature in schema_features}

        result_names = [
            name
            for name in requested_outputs
            if getattr(features_by_name[name], "mode", "stored") == "stored"
        ]
        backing_set: set[str] = set()
        realtime_metadata_by_name = {
            feature.name: feature for feature in metadata.realtime_features
        }
        for name in requested_outputs:
            if getattr(features_by_name[name], "mode", "stored") != "realtime":
                continue
            realtime_metadata = realtime_metadata_by_name.get(name)
            if realtime_metadata is None:
                continue
            for input_value in realtime_metadata.inputs:
                if input_value.source_type != "stored_field":
                    continue
                if input_value.source_name in result_names:
                    continue
                backing_set.add(input_value.source_name)

        backing_names = [feature.name for feature in schema_features if feature.name in backing_set]
        if not requested_features:
            return result_names, backing_names, None

        fetch_names = [
            feature.name
            for feature in schema_features
            if feature.name in set(result_names) or feature.name in backing_set
        ]
        return result_names, backing_names, fetch_names

    def _deserialize(self, value: str | bytes | None, value_type: str) -> Any:
        """Preserve the legacy instance method used by serving tests and callers."""
        return deserialize_value(value, value_type)

    def _serve_standard(
        self,
        ws: str,
        fv: str,
        entities: Sequence[str | Mapping[str, str]],
        include_key: bool,
        features: list[str] | None,
    ) -> ServeResult:
        payload: dict[str, Any] = {
            "workspace": ws,
            "feature_view": fv,
            "include_key": include_key,
            "features": features or [],
        }
        if entities and isinstance(entities[0], Mapping):
            payload["entity_values"] = entities
        else:
            payload["entities"] = entities

        resp = self._request(
            "POST",
            f"{self._base_url}/api/v1/serve",
            json=payload,
        )
        if resp.status_code == 404:
            try:
                message = resp.json().get("error", {}).get("message", resp.text)
            except Exception:
                message = resp.text
            raise NotFoundError(message)
        resp.raise_for_status()
        body = resp.json()
        return ServeResult(
            results=body.get("results", {}),
            backing_values=body.get("backing_values", {}),
        )

    def _serve_standard_grpc(
        self,
        ws: str,
        fv: str,
        entities: Sequence[str | Mapping[str, str]],
        include_key: bool,
        features: list[str] | None,
    ) -> ServeResult:
        import grpc
        from google.protobuf.struct_pb2 import Struct

        from featureform.transport.grpc import grpc_error_to_exception

        transport = cast("GRPCTransport", self._grpc_transport)

        request_kwargs: dict[str, Any] = {
            "workspace": ws,
            "feature_view": fv,
            "include_key": include_key,
            "features": features or [],
        }
        if entities and isinstance(entities[0], Mapping):
            request_kwargs["entity_values"] = []
            for entity in entities:
                if not isinstance(entity, Mapping):
                    continue
                struct_value = Struct()
                struct_value.update({str(key): str(value) for key, value in entity.items()})
                entity_values = cast(list[Struct], request_kwargs["entity_values"])
                entity_values.append(struct_value)
        else:
            request_kwargs["entities"] = entities
        request = serving_pb2.ServeRequest(**request_kwargs)
        try:
            response = transport.serving.Serve(request)
        except grpc.RpcError as e:
            raise grpc_error_to_exception(e) from e

        results: dict[str, dict[str, Any]] = {}
        for entity, feature_values in response.results.items():
            results[entity] = {
                name: value_to_python(value) for name, value in feature_values.values.items()
            }
        backing_values: dict[str, dict[str, Any]] = {}
        try:
            backing_values_field = response.backing_values
        except AttributeError:
            backing_items = []
        else:
            try:
                backing_items = list(backing_values_field.items())
            except TypeError:
                backing_items = []
        for entity, feature_values in backing_items:
            backing_values[entity] = {
                name: value_to_python(value) for name, value in feature_values.values.items()
            }
        return ServeResult(results=results, backing_values=backing_values)

    def _fetch_metadata(self, workspace: str, feature_view: str) -> FeatureViewMetadata:
        if getattr(self, "_grpc_transport", None) is not None:
            metadata = self._fetch_metadata_grpc(workspace, feature_view)
            if self._metadata_needs_rest_enrichment(metadata):
                enriched_metadata = self._fetch_metadata_rest_fallback(workspace, feature_view)
                if enriched_metadata is not None:
                    return enriched_metadata
            return metadata

        return self._fetch_metadata_rest(workspace, feature_view, base_url=self._base_url)

    def _fetch_metadata_rest(
        self,
        workspace: str,
        feature_view: str,
        *,
        base_url: str,
    ) -> FeatureViewMetadata:
        resp = self._request(
            "POST",
            f"{base_url}/api/v1/serving/metadata",
            json={"workspace": workspace, "feature_view": feature_view},
        )
        if resp.status_code == 404:
            try:
                message = resp.json().get("error", {}).get("message", resp.text)
            except Exception:
                message = resp.text
            raise NotFoundError(message)
        resp.raise_for_status()
        return metadata_from_dict(resp.json()["metadata"])

    def _fetch_metadata_rest_fallback(
        self,
        workspace: str,
        feature_view: str,
    ) -> FeatureViewMetadata | None:
        rest_base_url = self._rest_metadata_base_url or self._derive_rest_metadata_base_url()
        if rest_base_url is None:
            return None

        try:
            return self._fetch_metadata_rest(workspace, feature_view, base_url=rest_base_url)
        except Exception:
            _logger.debug(
                "serving metadata REST fallback failed for %s/%s via %s",
                workspace,
                feature_view,
                rest_base_url,
                exc_info=True,
            )
            return None

    def _fetch_metadata_grpc(self, workspace: str, feature_view: str) -> FeatureViewMetadata:
        import grpc

        from featureform.transport.grpc import grpc_error_to_exception

        transport = cast("GRPCTransport", self._grpc_transport)

        request = serving_pb2.GetServingMetadataRequest(
            workspace=workspace,
            feature_view=feature_view,
        )
        try:
            response = transport.serving.GetServingMetadata(request)
        except grpc.RpcError as e:
            raise grpc_error_to_exception(e) from e

        metadata = response.metadata
        raw_entity_columns = getattr(metadata, "entity_columns", None)
        if isinstance(raw_entity_columns, Iterable) and not isinstance(raw_entity_columns, str):
            entity_columns = list(raw_entity_columns)
        else:
            entity_columns = [metadata.entity]
        raw_feature_schema = getattr(metadata, "feature_schema", None)
        parsed_feature_schema = None
        if raw_feature_schema is not None:
            raw_schema_features = getattr(raw_feature_schema, "features", None)
            if isinstance(raw_schema_features, Iterable):
                schema_features = [
                    FeatureSchema(
                        name=getattr(feature, "name", ""),
                        type=getattr(feature, "type", ""),
                        nullable=getattr(feature, "nullable", False),
                        mode=getattr(feature, "mode", "stored"),
                        exposed=getattr(feature, "exposed", True),
                    )
                    for feature in raw_schema_features
                ]
                if schema_features:
                    parsed_feature_schema = FeatureViewSchema(features=schema_features)

        raw_realtime_features = getattr(metadata, "realtime_features", None)
        parsed_realtime_features: list[RealtimeFeatureMetadata] = []
        if isinstance(raw_realtime_features, Iterable):
            for feature in raw_realtime_features:
                inputs = [
                    RealtimeFeatureInput(
                        source_type=input_value.source_type,
                        source_name=input_value.source_name,
                    )
                    for input_value in getattr(feature, "inputs", [])
                ]
                parsed_realtime_features.append(
                    RealtimeFeatureMetadata(
                        name=getattr(feature, "name", ""),
                        requirements=list(getattr(feature, "requirements", [])),
                        normalized_function_string=getattr(
                            feature, "normalized_function_string", ""
                        ),
                        function_normalizer_details=self._proto_value_map_to_dict(
                            getattr(feature, "function_normalizer_details", {})
                        ),
                        serialized_function=getattr(feature, "serialized_function", ""),
                        extracted_function_string=getattr(feature, "extracted_function_string", ""),
                        serialization_python_version=getattr(
                            feature, "serialization_python_version", ""
                        ),
                        serializer_details=self._proto_value_map_to_dict(
                            getattr(feature, "serializer_details", {})
                        ),
                        inputs=inputs,
                    )
                )
        return FeatureViewMetadata(
            name=metadata.name,
            entity=metadata.entity,
            entity_columns=entity_columns,
            features=[
                FeatureSchema(
                    name=getattr(feature, "name", ""),
                    type=getattr(feature, "type", ""),
                    nullable=getattr(feature, "nullable", False),
                )
                for feature in metadata.features
            ],
            key_prefix=metadata.key_prefix,
            version=metadata.version,
            feature_schema=parsed_feature_schema,
            realtime_features=parsed_realtime_features,
        )

    def _metadata_needs_rest_enrichment(self, metadata: FeatureViewMetadata) -> bool:
        return metadata.feature_schema is None and not metadata.realtime_features

    def _proto_value_map_to_dict(self, values: Any) -> dict[str, Any]:
        try:
            items = values.items()
        except AttributeError:
            return {}
        return {str(key): value_to_python(value) for key, value in items}

    def _derive_rest_metadata_base_url(self) -> str | None:
        parsed = urlparse(self._base_url)
        if parsed.scheme in {"http", "https"} and parsed.hostname:
            parsed_port = parsed.port
            if parsed_port == 9090:
                return f"{parsed.scheme}://{parsed.hostname}:8080"
        if "://" not in self._base_url and ":" in self._base_url:
            host, _, port_text = self._base_url.rpartition(":")
            if host and port_text == "9090":
                return f"http://{host}:8080"
        return None

    def _to_numpy(self, result: ServeResult) -> ServeResult:
        import numpy as np

        for fv in result.results.values():
            for k, v in fv.items():
                if isinstance(v, list):
                    fv[k] = np.array(v, dtype=np.float32)
        return result

    def _to_numpy_dict(self, d: dict[str, Any]) -> dict[str, Any]:
        """Convert lists in a single dict to numpy arrays."""
        import numpy as np

        result: dict[str, Any] = {}
        for k, v in d.items():
            if isinstance(v, list):
                result[k] = np.array(v, dtype=np.float32)
            else:
                result[k] = v
        return result

    def _to_torch(self, result: ServeResult) -> ServeResult:
        torch = __import__("torch")  # Dynamic import to avoid type checker issues

        for fv in result.results.values():
            for k, v in fv.items():
                if isinstance(v, list):
                    fv[k] = torch.tensor(v, dtype=torch.float32)
        return result

    def _to_torch_dict(self, d: dict[str, Any]) -> dict[str, Any]:
        """Convert lists in a single dict to torch tensors."""
        torch = __import__("torch")

        result: dict[str, Any] = {}
        for k, v in d.items():
            if isinstance(v, list):
                result[k] = torch.tensor(v, dtype=torch.float32)
            else:
                result[k] = v
        return result

    def _to_pandas(self, result: ServeResult) -> Any:
        import pandas as pd  # type: ignore[import-untyped]

        if not result.results:
            return pd.DataFrame()
        # Cast to satisfy type checker - pandas types are complex
        data: dict[str, dict[str, Any]] = result.results
        return pd.DataFrame.from_dict(data, orient="index")  # pyright: ignore[reportUnknownMemberType]

    def _entity_to_key(
        self,
        metadata: FeatureViewMetadata,
        entity: str | Mapping[str, str],
    ) -> str:
        if isinstance(entity, Mapping):
            if not metadata.entity_columns:
                raise ValueError("serving metadata missing entity_columns")
            if len(metadata.entity_columns) == 1:
                key_column = metadata.entity_columns[0]
                if key_column not in entity:
                    raise ValueError(f"missing entity value: {key_column}")
                if len(entity) != 1:
                    raise ValueError("unexpected entity value")
                return str(entity[key_column])
            for column in metadata.entity_columns:
                if column not in entity:
                    raise ValueError(f"missing entity value: {column}")
            if any(column not in metadata.entity_columns for column in entity):
                raise ValueError("unexpected entity value")
            parts = [
                f"{column}={self._escape_entity_value(str(entity[column]))}"
                for column in metadata.entity_columns
            ]
            return f"{metadata.entity}:{'|'.join(parts)}"
        return str(entity)

    def _escape_entity_value(self, value: str) -> str:
        return value.replace("%", "%25").replace("|", "%7C").replace("=", "%3D")

    def warm_load(self, feature_views: list[str], workspace: str | None = None) -> WarmLoadResult:
        """Synchronously preload metadata for feature views."""
        ws = workspace or self._default_workspace
        loaded: list[str] = []
        errors: dict[str, str] = {}
        for fv in feature_views:
            try:
                self._cache.set(ws, fv, self._fetch_metadata(ws, fv))
                loaded.append(fv)
            except Exception as e:
                errors[fv] = str(e)
        return WarmLoadResult(loaded=loaded, errors=errors)

    async def warm_load_async(
        self, feature_views: list[str], workspace: str | None = None
    ) -> WarmLoadResult:
        """Asynchronously preload metadata for feature views."""
        import asyncio

        ws = workspace or self._default_workspace
        loaded: list[str] = []
        errors: dict[str, str] = {}

        async def load_one(fv: str) -> tuple[str, str | None]:
            try:
                loop = asyncio.get_event_loop()
                metadata = await loop.run_in_executor(None, self._fetch_metadata, ws, fv)
                self._cache.set(ws, fv, metadata)
                return fv, None
            except Exception as e:
                return fv, str(e)

        results = await asyncio.gather(*[load_one(fv) for fv in feature_views])
        for fv, err in results:
            if err is None:
                loaded.append(fv)
            else:
                errors[fv] = err
        return WarmLoadResult(loaded=loaded, errors=errors)

    def warm_load_workspace(self, workspace: str | None = None) -> WarmLoadResult:
        """Load all feature views in a workspace."""
        ws = workspace or self._default_workspace
        # Fetch list of feature views
        resp = self._request("GET", f"{self._base_url}/api/v1/workspaces/{ws}/feature-views")
        resp.raise_for_status()
        feature_views = [fv["name"] for fv in resp.json().get("feature_views", [])]
        return self.warm_load(feature_views, ws)

    def close(self) -> None:
        self._cache.stop_background_refresh()
        self._session.close()


def value_to_python(value: Any) -> Any:
    """Convert protobuf Struct values returned by gRPC serving into Python values."""
    kind = value.WhichOneof("kind")
    if kind == "null_value":
        return None
    if kind == "number_value":
        number = value.number_value
        if number.is_integer():
            return int(number)
        return number
    if kind == "string_value":
        return value.string_value
    if kind == "bool_value":
        return value.bool_value
    if kind == "struct_value":
        return {
            key: value_to_python(field_value)
            for key, field_value in value.struct_value.fields.items()
        }
    if kind == "list_value":
        return [value_to_python(item) for item in value.list_value.values]
    return None
