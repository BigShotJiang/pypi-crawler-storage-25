"""Types for feature serving."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class RedisLike(Protocol):
    """Protocol for Redis-like clients (BYOC pattern).

    Supports redis-py, fakeredis, or any client with compatible interface.
    """

    def hgetall(self, name: str) -> dict[bytes, bytes] | dict[str, str]:
        """Get all fields and values in a hash."""
        ...

    def pipeline(self) -> Any:
        """Create a pipeline for batch operations."""
        ...


@dataclass
class FeatureSchema:
    """Schema for a single feature."""

    name: str
    type: str  # "int64", "float64", "string", "bool", "vector", etc.
    nullable: bool = True
    mode: str = "stored"
    exposed: bool = True


@dataclass
class FeatureViewSchema:
    """Serving schema for a feature view."""

    features: list[FeatureSchema]


@dataclass(frozen=True)
class RealtimeFeatureInput:
    """Input binding for a realtime feature."""

    source_type: str
    source_name: str


@dataclass(frozen=True)
class RealtimeFeatureMetadata:
    """Serving-time metadata for a realtime feature."""

    name: str
    requirements: list[str]
    normalized_function_string: str
    function_normalizer_details: dict[str, Any]
    serialized_function: str
    extracted_function_string: str
    serialization_python_version: str
    serializer_details: dict[str, Any]
    inputs: list[RealtimeFeatureInput]


@dataclass
class FeatureViewMetadata:
    """Metadata for a feature view (used for BYOC direct serving)."""

    name: str
    entity: str  # Entity column name
    features: list[FeatureSchema]
    key_prefix: str  # Redis key prefix
    version: int
    entity_columns: list[str] = field(default_factory=list)
    feature_schema: FeatureViewSchema | None = None
    realtime_features: list[RealtimeFeatureMetadata] = field(default_factory=list)

    def __post_init__(self) -> None:
        """Default entity_columns for single-entity views."""
        if not self.entity_columns:
            self.entity_columns = [self.entity]

    def feature_names(self) -> list[str]:
        """Get list of feature names."""
        source = self.feature_schema.features if self.feature_schema is not None else self.features
        return [f.name for f in source]


@dataclass
class ServeResult:
    """Result from serving features."""

    results: dict[str, dict[str, Any]]
    errors: dict[str, str] = field(default_factory=dict)
    backing_values: dict[str, dict[str, Any]] = field(default_factory=dict)

    def __getitem__(self, entity: str) -> dict[str, Any]:
        """Get features for an entity."""
        return self.results[entity]

    def __contains__(self, entity: str) -> bool:
        """Check if entity is in results."""
        return entity in self.results

    def __len__(self) -> int:
        """Number of entities with results."""
        return len(self.results)

    def __iter__(self) -> Any:
        """Iterate over entity keys."""
        return iter(self.results)

    def entities(self) -> list[str]:
        """Get list of entities with results."""
        return list(self.results.keys())


@dataclass
class WarmLoadResult:
    """Result of warm-loading metadata."""

    loaded: list[str]
    errors: dict[str, str]

    @property
    def success_count(self) -> int:
        """Number of successfully loaded feature views."""
        return len(self.loaded)

    @property
    def error_count(self) -> int:
        """Number of failed feature views."""
        return len(self.errors)
