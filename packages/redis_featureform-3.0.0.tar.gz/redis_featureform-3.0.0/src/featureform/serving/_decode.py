"""Pure helpers for serving response decoding and entity selection."""

from __future__ import annotations

import json
from collections.abc import Mapping
from typing import Any

from featureform.errors import EntitySelectionError
from featureform.serving.types import FeatureViewMetadata


def _single_entity_list(entity: str | Mapping[str, str] | None) -> list[str | Mapping[str, str]]:
    assert entity is not None
    return [entity]


def build_entity_list(
    entity: str | Mapping[str, str] | None,
    entities: list[str] | list[Mapping[str, str]] | None,
) -> tuple[bool, list[str | Mapping[str, str]]]:
    """Build the effective entity list for a serve request."""
    if entity is not None and entities:
        raise EntitySelectionError("conflict")
    single = entity is not None
    entity_list = _single_entity_list(entity) if single else list(entities or [])
    return single, entity_list


def parse_bool(value: str) -> bool | None:
    """Parse a boolean string.

    Returns None for invalid values rather than coercing to False.
    """
    lower = value.lower()
    if lower == "true" or value == "1":
        return True
    if lower == "false" or value == "0":
        return False
    return None


def deserialize_value(value: str | bytes | None, value_type: str) -> Any:
    """Deserialize a string value to its typed representation."""
    if value is None:
        return None
    decoded = value.decode() if isinstance(value, bytes) else value
    try:
        if value_type in ("int64", "int32"):
            return int(decoded)
        if value_type in ("float64", "float32"):
            return float(decoded)
        if value_type == "bool":
            return parse_bool(decoded)
        if value_type in ("vector", "json"):
            return json.loads(decoded)
    except (ValueError, json.JSONDecodeError):
        return None
    return decoded


def get_feature_type(metadata: FeatureViewMetadata, feature_name: str) -> str:
    """Look up a feature type, defaulting to string."""
    return next(
        (feature.type for feature in metadata.features if feature.name == feature_name), "string"
    )


def parse_raw_features(
    raw: Any,
    metadata: FeatureViewMetadata,
    features: list[str] | None,
) -> dict[str, Any]:
    """Parse raw Redis values into typed feature values."""
    if isinstance(raw, list):
        return {
            name: deserialize_value(value, get_feature_type(metadata, name))
            for name, value in zip(features or [], raw, strict=True)
            if value is not None
        }

    schema_feature_names = {feature.name for feature in metadata.features}
    parsed: dict[str, Any] = {}
    for name, value in raw.items():
        decoded_name = name.decode() if isinstance(name, bytes) else name
        if decoded_name not in schema_feature_names:
            continue
        decoded_value = value.decode() if isinstance(value, bytes) else value
        parsed[decoded_name] = deserialize_value(
            decoded_value,
            get_feature_type(metadata, decoded_name),
        )
    return parsed
