"""Metadata cache with background refresh."""

from __future__ import annotations

import logging
import random
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from featureform.serving.types import FeatureViewMetadata

_logger = logging.getLogger(__name__)


@dataclass
class CacheEntry:
    """Cache entry with metadata and freshness tracking."""

    metadata: FeatureViewMetadata
    fetched_at: float
    refresh_count: int = 0


class MetadataCache:
    """Cache with background refresh for feature view metadata.

    Keeps metadata warm so serve() calls don't have cold-start latency.
    """

    def __init__(
        self,
        fetch_fn: Callable[[str, str], FeatureViewMetadata],
        ttl: int = 300,
        refresh_interval: int = 30,
        refresh_jitter: int = 5,
        stale_threshold: int = 300,
    ) -> None:
        """Initialize cache.

        Args:
            fetch_fn: Function to fetch metadata (workspace, fv_name) -> metadata.
            ttl: Cache TTL in seconds (for expiry).
            refresh_interval: Seconds between background refresh cycles.
            refresh_jitter: Random jitter to avoid thundering herd.
            stale_threshold: Warn if metadata is older than this.
        """
        self._fetch_fn = fetch_fn
        self._ttl = ttl
        self._refresh_interval = refresh_interval
        self._refresh_jitter = refresh_jitter
        self._stale_threshold = stale_threshold
        self._cache: dict[str, CacheEntry] = {}
        self._lock = threading.RLock()
        self._refresh_task: threading.Thread | None = None
        self._running = False

    def get(self, workspace: str, feature_view: str) -> FeatureViewMetadata | None:
        """Get cached metadata (returns None if not cached)."""
        cache_key = f"{workspace}:{feature_view}"
        with self._lock:
            entry = self._cache.get(cache_key)
            if entry is None:
                return None
            return entry.metadata

    def get_or_fetch(
        self,
        workspace: str,
        feature_view: str,
    ) -> FeatureViewMetadata:
        """Get from cache or fetch if missing/expired.

        IMPORTANT: Does NOT hold lock during network calls to avoid
        serializing all cache access behind a single HTTP request.
        """
        cache_key = f"{workspace}:{feature_view}"

        # Check cache while holding lock (fast path)
        with self._lock:
            entry = self._cache.get(cache_key)
            now = time.time()

            if entry is not None:
                age = now - entry.fetched_at
                if age < self._ttl:
                    # Warn if metadata is stale (older than stale_threshold)
                    if age > self._stale_threshold:
                        _logger.warning(
                            "stale_metadata: key=%s age=%.1fs threshold=%ds",
                            cache_key,
                            age,
                            self._stale_threshold,
                        )
                    return entry.metadata
                # Expired - will need to refresh (release lock first)
                stale_entry = entry
            else:
                stale_entry = None

        # Fetch OUTSIDE the lock to avoid blocking other threads
        try:
            metadata = self._fetch_fn(workspace, feature_view)
        except Exception:
            if stale_entry is not None:
                _logger.warning("cache_refresh_failed_using_stale: %s", cache_key)
                return stale_entry.metadata
            raise

        # Update cache with new data
        with self._lock:
            refresh_count = 0
            if stale_entry is not None:
                refresh_count = stale_entry.refresh_count + 1
            self._cache[cache_key] = CacheEntry(
                metadata=metadata,
                fetched_at=time.time(),
                refresh_count=refresh_count,
            )
        return metadata

    def set(self, workspace: str, feature_view: str, metadata: FeatureViewMetadata) -> None:
        """Set cache entry (called by warm_load)."""
        cache_key = f"{workspace}:{feature_view}"
        with self._lock:
            self._cache[cache_key] = CacheEntry(
                metadata=metadata,
                fetched_at=time.time(),
                refresh_count=0,
            )

    def start_background_refresh(self) -> None:
        """Start background refresh thread."""
        if self._refresh_task is not None:
            return

        self._running = True
        self._refresh_task = threading.Thread(
            target=self._refresh_loop,
            daemon=True,
            name="featureform-cache-refresh",
        )
        self._refresh_task.start()

    def stop_background_refresh(self) -> None:
        """Stop background refresh thread."""
        self._running = False
        if self._refresh_task:
            self._refresh_task.join(timeout=5)
            self._refresh_task = None

    def _refresh_loop(self) -> None:
        """Background refresh loop."""
        while self._running:
            jitter = random.uniform(0, self._refresh_jitter)
            time.sleep(self._refresh_interval + jitter)

            if not self._running:
                break

            with self._lock:
                keys = list(self._cache.keys())

            for key in keys:
                if not self._running:
                    break
                try:
                    workspace, fv = key.split(":", 1)
                    metadata = self._fetch_fn(workspace, fv)
                    with self._lock:
                        old = self._cache.get(key)
                        if old:
                            # Always update fetched_at to confirm entry is current,
                            # even if version is unchanged. This prevents entries
                            # from expiring and triggering sync fetches on hot path.
                            use_metadata = (
                                metadata
                                if metadata.version > old.metadata.version
                                else old.metadata
                            )
                            self._cache[key] = CacheEntry(
                                metadata=use_metadata,
                                fetched_at=time.time(),
                                refresh_count=old.refresh_count + 1,
                            )
                except Exception as e:
                    _logger.warning("background_refresh_failed: key=%s error=%s", key, str(e))
