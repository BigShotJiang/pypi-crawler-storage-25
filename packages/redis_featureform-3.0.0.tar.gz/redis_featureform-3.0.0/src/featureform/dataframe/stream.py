"""Streaming dataframe query results."""

from __future__ import annotations

from collections.abc import Callable, Iterator
from enum import Enum
from typing import TYPE_CHECKING

import pyarrow as pa

from featureform.dataframe.result import _apply_training_set_realtime_metadata
from featureform.serving._realtime import RealtimeExecutor

if TYPE_CHECKING:
    from featureform.spark import DataframeExecutionInfo


class StreamState(str, Enum):
    """Lifecycle states for a one-shot dataframe stream."""

    OPEN = "open"
    ITERATING = "iterating"
    CONSUMED = "consumed"
    CLOSED = "closed"
    FAILED = "failed"


class QueryStream:
    """One-shot streaming dataframe result."""

    def __init__(
        self,
        reader: pa.RecordBatchReader,
        *,
        schema: pa.Schema,
        exception_mapper: Callable[[Exception], Exception] | None = None,
        close_callback: Callable[[], None] | None = None,
        execution_info: DataframeExecutionInfo | None = None,
    ) -> None:
        self._reader = reader
        self._schema = schema
        self._exception_mapper = exception_mapper
        self._close_callback = close_callback
        self._state = StreamState.OPEN
        self._iterator_created = False
        self._resources_released = False
        self.execution_info = execution_info
        self._executor = RealtimeExecutor()
        self._loaded_callables: dict[str, object] = {}
        self._validated_artifacts: set[str] = set()

    @property
    def schema(self) -> pa.Schema:
        """Return the cached schema for the stream."""
        return self._schema

    @property
    def state(self) -> StreamState:
        """Return the current stream state."""
        return self._state

    def iter_batches(self) -> Iterator[pa.RecordBatch]:
        """Yield batches lazily from the underlying Flight reader."""
        if self._state == StreamState.CLOSED:
            raise RuntimeError("query stream is closed")
        if self._state == StreamState.CONSUMED:
            raise RuntimeError("query stream has already been consumed")
        if self._state == StreamState.FAILED:
            raise RuntimeError("query stream has failed and cannot be resumed")
        if self._state == StreamState.ITERATING or self._iterator_created:
            raise RuntimeError("query stream does not support concurrent or repeated iteration")

        self._state = StreamState.ITERATING
        self._iterator_created = True

        def _generator() -> Iterator[pa.RecordBatch]:
            try:
                for item in self._reader:
                    batch: pa.RecordBatch | None = None
                    if hasattr(item, "data") and item.data is not None:
                        batch = item.data
                    elif isinstance(item, pa.RecordBatch):
                        batch = item
                    if batch is None:
                        continue
                    yield _apply_training_set_realtime_metadata(
                        batch,
                        executor=self._executor,
                        loaded_callables=self._loaded_callables,
                        validated_artifacts=self._validated_artifacts,
                    )
            except Exception as exc:
                self._state = StreamState.FAILED
                if self._exception_mapper is not None:
                    mapped = self._exception_mapper(exc)
                    if mapped is exc:
                        raise
                    raise mapped from exc
                raise
            else:
                self._state = StreamState.CONSUMED
            finally:
                if self._state == StreamState.ITERATING:
                    self._state = StreamState.CONSUMED
                if self._state in {StreamState.CONSUMED, StreamState.FAILED}:
                    self._release_resources()

        return _generator()

    def close(self) -> None:
        """Close the underlying reader and release resources."""
        if self._state == StreamState.CLOSED:
            return
        try:
            self._release_resources()
        finally:
            self._state = StreamState.CLOSED

    def __enter__(self) -> QueryStream:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def _release_resources(self) -> None:
        if self._resources_released:
            return
        self._resources_released = True
        release_error: Exception | None = None

        reader_close = getattr(self._reader, "close", None)
        if callable(reader_close):
            try:
                reader_close()
            except Exception as exc:
                release_error = exc
        if self._close_callback is not None:
            try:
                self._close_callback()
            except Exception as exc:
                if release_error is None:
                    release_error = exc
            finally:
                self._close_callback = None
        if release_error is not None:
            raise release_error
