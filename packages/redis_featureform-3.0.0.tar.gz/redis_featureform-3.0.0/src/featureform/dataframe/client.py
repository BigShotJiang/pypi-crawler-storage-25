"""DataFrameClient for Apache Arrow Flight queries."""

from __future__ import annotations

import json
import re
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal

import pyarrow as pa
import pyarrow.flight as flight

from featureform._internal.logging import get_logger
from featureform.dataframe.result import QueryResult
from featureform.dataframe.stream import QueryStream
from featureform.errors import (
    AddressRequiredError,
    DatasetRequiredError,
    FlightConnectionError,
    FlightDatasetNotFoundError,
    FlightProviderNotFoundError,
    FlightTLSConfigurationError,
    FlightWorkspaceVersionUnavailableError,
    InvalidDataframeQueryKindError,
    InvalidFilterExpressionError,
    InvalidFilterTypeError,
    InvalidJSONFilterError,
    WorkspaceRequiredError,
)

if TYPE_CHECKING:
    pass

# Module logger
_logger = get_logger("featureform.dataframe.client")

QueryKind = Literal["dataset", "training_set", "feature_view"]


def _is_workspace_version_unavailable(error: flight.FlightError) -> bool:
    """Return True when Flight reports no committed workspace version yet."""
    return "no committed version" in str(error).lower()


# Filter types
class Filter:
    """Base class for query filters. Use the factory functions to create filters."""

    def to_dict(self) -> dict[str, Any]:
        """Convert filter to dict for JSON serialization."""
        raise NotImplementedError


@dataclass
class CompareFilter(Filter):
    """Comparison filter (column op value)."""

    column: str
    op: str  # eq, ne, lt, le, gt, ge, like
    value: Any

    def to_dict(self) -> dict[str, Any]:
        """Convert to dict."""
        return {"type": "compare", "column": self.column, "op": self.op, "value": self.value}


@dataclass
class InFilter(Filter):
    """IN filter (column IN values)."""

    column: str
    values: list[Any]

    def to_dict(self) -> dict[str, Any]:
        """Convert to dict."""
        return {"type": "in", "column": self.column, "values": self.values}


@dataclass
class BetweenFilter(Filter):
    """BETWEEN filter (column BETWEEN low AND high)."""

    column: str
    low: Any
    high: Any

    def to_dict(self) -> dict[str, Any]:
        """Convert to dict."""
        return {"type": "between", "column": self.column, "low": self.low, "high": self.high}


@dataclass
class IsNullFilter(Filter):
    """IS NULL / IS NOT NULL filter."""

    column: str
    is_null: bool = True

    def to_dict(self) -> dict[str, Any]:
        """Convert to dict."""
        return {"type": "is_null", "column": self.column, "is_null": self.is_null}


@dataclass
class AndFilter(Filter):
    """AND combination of filters."""

    filters: list[Filter]

    def to_dict(self) -> dict[str, Any]:
        """Convert to dict."""
        return {"type": "and", "filters": [f.to_dict() for f in self.filters]}


@dataclass
class OrFilter(Filter):
    """OR combination of filters."""

    filters: list[Filter]

    def to_dict(self) -> dict[str, Any]:
        """Convert to dict."""
        return {"type": "or", "filters": [f.to_dict() for f in self.filters]}


@dataclass
class NotFilter(Filter):
    """NOT filter."""

    filter: Filter

    def to_dict(self) -> dict[str, Any]:
        """Convert to dict."""
        return {"type": "not", "filter": self.filter.to_dict()}


# Convenience factory functions
def compare(column: str, op: str, value: Any) -> CompareFilter:
    """Create a comparison filter."""
    return CompareFilter(column=column, op=op, value=value)


def eq(column: str, value: Any) -> CompareFilter:
    """Create an equality filter (column = value)."""
    return CompareFilter(column=column, op="eq", value=value)


def gt(column: str, value: Any) -> CompareFilter:
    """Create a greater-than filter (column > value)."""
    return CompareFilter(column=column, op="gt", value=value)


def lt(column: str, value: Any) -> CompareFilter:
    """Create a less-than filter (column < value)."""
    return CompareFilter(column=column, op="lt", value=value)


def ge(column: str, value: Any) -> CompareFilter:
    """Create a greater-or-equal filter (column >= value)."""
    return CompareFilter(column=column, op="ge", value=value)


def le(column: str, value: Any) -> CompareFilter:
    """Create a less-or-equal filter (column <= value)."""
    return CompareFilter(column=column, op="le", value=value)


def like(column: str, pattern: str) -> CompareFilter:
    """Create a LIKE filter (column LIKE pattern)."""
    return CompareFilter(column=column, op="like", value=pattern)


def in_list(column: str, values: list[Any]) -> InFilter:
    """Create an IN filter (column IN (values))."""
    return InFilter(column=column, values=values)


def between(column: str, low: Any, high: Any) -> BetweenFilter:
    """Create a BETWEEN filter (column BETWEEN low AND high)."""
    return BetweenFilter(column=column, low=low, high=high)


def is_null(column: str) -> IsNullFilter:
    """Create an IS NULL filter."""
    return IsNullFilter(column=column, is_null=True)


def is_not_null(column: str) -> IsNullFilter:
    """Create an IS NOT NULL filter."""
    return IsNullFilter(column=column, is_null=False)


def and_(*filters: Filter) -> AndFilter:
    """Combine filters with AND."""
    return AndFilter(filters=list(filters))


def or_(*filters: Filter) -> OrFilter:
    """Combine filters with OR."""
    return OrFilter(filters=list(filters))


def not_(filter: Filter) -> NotFilter:  # noqa: A002
    """Negate a filter."""
    return NotFilter(filter=filter)


def parse_filter_expression(expr: str) -> Filter | None:
    """Parse a simple filter expression like 'amount > 100'.

    Supported formats: 'column op value' where op is =, !=, <, <=, >, >=, LIKE.

    Args:
        expr: Filter expression string.

    Returns:
        Filter object or None if empty.

    Raises:
        ValueError: If expression is invalid.
    """
    if not expr or not expr.strip():
        return None

    expr = expr.strip()

    # Try JSON first
    if expr.startswith("{"):
        try:
            return _filter_from_dict(json.loads(expr))
        except json.JSONDecodeError as e:
            raise InvalidJSONFilterError(str(e)) from e

    # Parse simple expression
    operators = [
        (">=", "ge"),
        ("<=", "le"),
        ("!=", "ne"),
        ("=", "eq"),
        (">", "gt"),
        ("<", "lt"),
    ]

    for op_str, op_code in operators:
        if op_str in expr:
            parts = expr.split(op_str, 1)
            if len(parts) == 2:
                column = parts[0].strip()
                value_str = parts[1].strip()
                value = _parse_value(value_str)
                return CompareFilter(column=column, op=op_code, value=value)

    # Try LIKE
    like_match = re.match(r"(\w+)\s+LIKE\s+(.+)", expr, re.IGNORECASE)
    if like_match:
        column = like_match.group(1)
        value = like_match.group(2).strip().strip("'\"")
        return CompareFilter(column=column, op="like", value=value)

    raise InvalidFilterExpressionError("expected 'column op value' (e.g., 'amount > 100')")


def _parse_value(value_str: str) -> Any:
    """Parse a value string into appropriate Python type."""
    # Try int
    try:
        return int(value_str)
    except ValueError:
        pass
    # Try float
    try:
        return float(value_str)
    except ValueError:
        pass
    # String (remove quotes)
    return value_str.strip("'\"")


def _filter_from_dict(data: dict[str, Any]) -> Filter:
    """Convert dict to Filter object."""
    filter_type = data.get("type")
    if filter_type == "compare":
        return CompareFilter(column=data["column"], op=data["op"], value=data["value"])
    elif filter_type == "in":
        return InFilter(column=data["column"], values=data["values"])
    elif filter_type == "between":
        return BetweenFilter(column=data["column"], low=data["low"], high=data["high"])
    elif filter_type == "is_null":
        return IsNullFilter(column=data["column"], is_null=data.get("is_null", True))
    elif filter_type == "and":
        return AndFilter(filters=[_filter_from_dict(f) for f in data["filters"]])
    elif filter_type == "or":
        return OrFilter(filters=[_filter_from_dict(f) for f in data["filters"]])
    elif filter_type == "not":
        return NotFilter(filter=_filter_from_dict(data["filter"]))
    else:
        raise InvalidFilterTypeError(filter_type)


@dataclass
class QueryRequest:
    """Request for a DataFrame query.

    Attributes:
        workspace: Name of the workspace.
        kind: Query target kind (`dataset`, `training_set`, or `feature_view`).
        dataset: Name of the dataset to query.
        columns: Optional list of columns to select.
        filter: Optional structured filter or filter expression string.
        limit: Optional maximum number of rows.
    """

    workspace: str
    dataset: str
    columns: list[str] | None = field(default=None)
    filter: Filter | str | None = field(default=None)  # noqa: A003
    limit: int | None = field(default=None)
    kind: QueryKind = field(default="dataset")

    def __post_init__(self) -> None:
        """Validate request fields."""
        if not self.workspace:
            raise WorkspaceRequiredError("workspace is required")
        if self.kind not in ("dataset", "training_set", "feature_view"):
            raise InvalidDataframeQueryKindError(self.kind)
        if not self.dataset:
            raise DatasetRequiredError("dataset is required")

    def to_ticket(self) -> flight.Ticket:
        """Convert to a Flight Ticket.

        Returns:
            Flight Ticket with JSON-encoded request.
        """
        data: dict[str, Any] = {
            "workspace": self.workspace,
            "kind": self.kind,
            "dataset": self.dataset,
        }
        if self.columns:
            data["columns"] = self.columns
        if self.filter:
            # Convert filter to structured format
            if isinstance(self.filter, str):
                parsed = parse_filter_expression(self.filter)
                if parsed:
                    data["filter"] = parsed.to_dict()
            elif isinstance(self.filter, Filter):
                data["filter"] = self.filter.to_dict()
        if self.limit:
            data["limit"] = self.limit

        ticket_bytes = json.dumps(data).encode("utf-8")
        return flight.Ticket(ticket_bytes)


class DataFrameClient:
    """Client for querying DataFrames via Apache Arrow Flight.

    Example:
        >>> client = DataFrameClient("localhost:9090")
        >>> result = client.query(workspace="my-ws", dataset="transactions")
        >>> df = result.to_pandas()
        >>> client.close()

        # For development without TLS:
        >>> client = DataFrameClient("localhost:9090", insecure=True)
    """

    def __init__(
        self,
        address: str,
        *,
        insecure: bool = False,
        ca_cert: bytes | None = None,
        token: str | None = None,
        token_provider: Callable[[], str | None] | None = None,
    ) -> None:
        """Initialize the client.

        Args:
            address: Server address (host:port).
            insecure: If True, skip certificate verification but still use TLS.
                     If no CA cert is provided and insecure=True, falls back to plaintext.
            ca_cert: Optional CA certificate bytes for verifying self-signed certs.
                    If not provided, checks FEATUREFORM_CA_CERT environment variable.

        Raises:
            ValueError: If address is empty.
        """
        if not address:
            raise AddressRequiredError("address cannot be empty")

        self._address = address
        self._insecure = insecure
        self._ca_cert = ca_cert
        self._token = token
        self._token_provider = token_provider
        self._client: flight.FlightClient | None = None
        _logger.debug("dataframe_client_init", address=address, insecure=insecure)

    @property
    def address(self) -> str:
        """Get the server address."""
        return self._address

    @property
    def insecure(self) -> bool:
        """Check if TLS is disabled."""
        return self._insecure

    def _connect(self) -> flight.FlightClient:
        """Connect to the Flight server.

        Returns:
            Flight client.

        Raises:
            flight.FlightUnavailableError: If TLS is required but no CA cert is available.
        """
        if self._client is None:
            _logger.debug("dataframe_client_connect", address=self._address)

            # Normalize address - strip existing scheme if present
            address = self._address
            if address.startswith("grpc+tls://"):
                address = address[len("grpc+tls://") :]
            elif address.startswith("grpc://"):
                address = address[len("grpc://") :]

            # Get CA cert from parameter or environment
            ca_cert = self._ca_cert
            if ca_cert is None:
                from featureform.config import ca_cert_path_from_env

                ca_cert_path = ca_cert_path_from_env()
                if ca_cert_path:
                    _logger.debug("dataframe_client_loading_ca_cert", path=ca_cert_path)
                    try:
                        with open(ca_cert_path, "rb") as f:
                            ca_cert = f.read()
                    except FileNotFoundError as err:
                        raise FlightTLSConfigurationError(
                            f"CA certificate file not found: {ca_cert_path}"
                        ) from err

            # Determine connection mode
            if ca_cert is not None:
                # TLS with custom CA cert (for self-signed certs)
                uri = f"grpc+tls://{address}"
                _logger.debug("dataframe_client_connect_tls_custom_ca", uri=uri)
                self._client = flight.connect(uri, tls_root_certs=ca_cert)
            elif self._insecure:
                # Plaintext (no TLS) - for local development only
                uri = f"grpc://{address}"
                _logger.debug("dataframe_client_connect_plaintext", uri=uri)
                self._client = flight.connect(uri)
            else:
                # TLS with system CA bundle (default)
                uri = f"grpc+tls://{address}"
                _logger.debug("dataframe_client_connect_tls", uri=uri)
                self._client = flight.connect(uri)

        return self._client

    def query(
        self,
        workspace: str,
        dataset: str,
        *,
        columns: list[str] | None = None,
        filter: Filter | str | None = None,  # noqa: A002
        limit: int | None = None,
        kind: QueryKind = "dataset",
    ) -> QueryResult:
        """Execute a DataFrame query.

        Args:
            workspace: Workspace name.
            dataset: Dataset name. For training-set reads, prefer `query_training_set()`.
            kind: Low-level query target kind. Public callers should prefer
                `query()` for datasets, `query_training_set()` for training sets,
                and `query_feature_view()` for feature views.
            columns: Optional columns to select.
            filter: Optional filter - can be a Filter object or string expression.
            limit: Optional row limit.

        Returns:
            QueryResult with the data.

        Examples:
            # Dataset query
            result = client.query("ws", "ds", filter="amount > 100")

            # Using structured filter
            from featureform.dataframe.client import gt, and_
            result = client.query("ws", "ds", filter=gt("amount", 100))
            result = client.query("ws", "ds", filter=and_(gt("amount", 100), eq("status", "active")))
        """
        request = QueryRequest(
            workspace=workspace,
            dataset=dataset,
            columns=columns,
            filter=filter,
            limit=limit,
            kind=kind,
        )

        _logger.debug(
            "dataframe_query_start",
            workspace=workspace,
            kind=kind,
            dataset=dataset,
            columns=columns,
            filter=str(filter) if filter else None,
            limit=limit,
        )

        ticket = request.to_ticket()
        return self.query_ticket(ticket.ticket, workspace=workspace, dataset=dataset)

    def query_dataset(
        self,
        workspace: str,
        dataset: str,
        *,
        columns: list[str] | None = None,
        filter: Filter | str | None = None,  # noqa: A002
        limit: int | None = None,
    ) -> QueryResult:
        """Execute a dataset query."""
        return self.query(
            workspace=workspace,
            dataset=dataset,
            kind="dataset",
            columns=columns,
            filter=filter,
            limit=limit,
        )

    def query_training_set(
        self,
        workspace: str,
        training_set: str,
        *,
        columns: list[str] | None = None,
        filter: Filter | str | None = None,  # noqa: A002
        limit: int | None = None,
    ) -> QueryResult:
        """Execute a training-set query.

        Prefer this helper over `query(..., kind="training_set")`.
        """
        return self.query(
            workspace=workspace,
            dataset=training_set,
            kind="training_set",
            columns=columns,
            filter=filter,
            limit=limit,
        )

    def query_feature_view(
        self,
        workspace: str,
        feature_view: str,
        *,
        columns: list[str] | None = None,
        filter: Filter | str | None = None,  # noqa: A002
        limit: int | None = None,
    ) -> QueryResult:
        """Execute a feature-view query against its committed offline snapshot."""
        return self.query(
            workspace=workspace,
            dataset=feature_view,
            kind="feature_view",
            columns=columns,
            filter=filter,
            limit=limit,
        )

    def _call_options(self) -> flight.FlightCallOptions | None:
        token = self._token_provider() if self._token_provider is not None else self._token
        if not token:
            return None
        return flight.FlightCallOptions(headers=[(b"authorization", f"Bearer {token}".encode())])

    def _map_flight_error(
        self,
        error: Exception,
        *,
        workspace: str | None = None,
        dataset: str | None = None,
    ) -> Exception:
        """Translate Arrow Flight errors into typed dataframe exceptions."""
        if isinstance(
            error,
            (
                FlightConnectionError,
                FlightWorkspaceVersionUnavailableError,
                FlightProviderNotFoundError,
                FlightDatasetNotFoundError,
            ),
        ):
            return error
        if isinstance(error, flight.FlightUnavailableError):
            _logger.error("dataframe_query_error", error=str(error))
            error_str = str(error).lower()
            if "ssl" in error_str or "tls" in error_str or "handshake" in error_str:
                return FlightConnectionError(
                    f"TLS handshake failed connecting to {self._address}. "
                    f"The server may not have TLS enabled. Try using --insecure flag."
                )
            if (
                "connection refused" in error_str
                or "failed to connect" in error_str
                or "name resolution" in error_str
                or "dns" in error_str
            ):
                return FlightConnectionError(
                    f"Could not connect to server at {self._address}. "
                    f"Check that the server is running and the address is correct."
                )
            return FlightConnectionError(f"Server unavailable at {self._address}: {error}")
        if isinstance(error, flight.FlightInternalError):
            _logger.error("dataframe_query_error", error=str(error))
            if workspace is not None and _is_workspace_version_unavailable(error):
                return FlightWorkspaceVersionUnavailableError(
                    (
                        f"Workspace '{workspace}' does not have a committed version visible "
                        "to Arrow Flight yet."
                    ),
                    code="workspace_version_unavailable",
                )
            error_str = str(error)
            if (
                workspace is not None
                and "provider" in error_str.lower()
                and "not found" in error_str.lower()
            ):
                match = re.search(r'provider ["\']?([^"\']+)["\']?', error_str, re.IGNORECASE)
                provider_name = match.group(1) if match else "unknown"
                return FlightProviderNotFoundError(
                    f"Provider '{provider_name}' not found in workspace '{workspace}'. "
                    f"Did you register it with 'ff provider register'?"
                )
            if (
                workspace is not None
                and dataset is not None
                and (
                    "catalog lookup failed" in error_str.lower() or "not found" in error_str.lower()
                )
            ):
                return FlightDatasetNotFoundError(
                    f"Dataset '{dataset}' not found in workspace '{workspace}'. "
                    f"Check that the dataset exists and has been applied."
                )
            return error
        if isinstance(error, flight.FlightError):
            _logger.error("dataframe_query_error", error=str(error))
            if workspace is not None and _is_workspace_version_unavailable(error):
                return FlightWorkspaceVersionUnavailableError(
                    (
                        f"Workspace '{workspace}' does not have a committed version visible "
                        "to Arrow Flight yet."
                    ),
                    code="workspace_version_unavailable",
                )
            return error
        if isinstance(error, pa.ArrowKeyError):
            _logger.error("dataframe_query_error", error=str(error))
            error_str = str(error).lower()
            if (
                workspace is not None
                and dataset is not None
                and (
                    ("dataset" in error_str and "missing" in error_str)
                    or ("dataset" in error_str and "not found" in error_str)
                )
            ):
                return FlightDatasetNotFoundError(
                    f"Dataset '{dataset}' not found in workspace '{workspace}'. "
                    f"Check that the dataset exists and has been applied."
                )
        return error

    def _open_ticket_reader(
        self,
        ticket_bytes: bytes,
        *,
        workspace: str | None = None,
        dataset: str | None = None,
    ) -> pa.RecordBatchReader:
        """Open a Flight reader for a prebuilt ticket."""
        client = self._connect()
        call_options = self._call_options()
        try:
            if call_options is not None:
                return client.do_get(flight.Ticket(ticket_bytes), options=call_options)
            return client.do_get(flight.Ticket(ticket_bytes))
        except Exception as exc:
            mapped = self._map_flight_error(exc, workspace=workspace, dataset=dataset)
            if mapped is exc:
                raise
            raise mapped from exc

    def query_ticket(
        self,
        ticket_bytes: bytes,
        *,
        workspace: str | None = None,
        dataset: str | None = None,
    ) -> QueryResult:
        """Execute a DataFrame query using a prebuilt Flight ticket."""
        reader = self._open_ticket_reader(ticket_bytes, workspace=workspace, dataset=dataset)
        try:
            result = QueryResult.from_reader(reader)
        except Exception as exc:
            mapped = self._map_flight_error(exc, workspace=workspace, dataset=dataset)
            if mapped is exc:
                raise
            raise mapped from exc
        _logger.debug("dataframe_query_complete", rows=result.num_rows)
        return result

    def query_stream(
        self,
        workspace: str,
        dataset: str,
        *,
        columns: list[str] | None = None,
        filter: Filter | str | None = None,  # noqa: A002
        limit: int | None = None,
        kind: QueryKind = "dataset",
        close_callback: Callable[[], None] | None = None,
    ) -> QueryStream:
        """Open a one-shot streaming query."""
        request = QueryRequest(
            workspace=workspace,
            dataset=dataset,
            columns=columns,
            filter=filter,
            limit=limit,
            kind=kind,
        )
        ticket = request.to_ticket()
        return self.query_stream_ticket(
            ticket.ticket,
            workspace=workspace,
            dataset=dataset,
            close_callback=close_callback,
        )

    def query_stream_ticket(
        self,
        ticket_bytes: bytes,
        *,
        workspace: str | None = None,
        dataset: str | None = None,
        close_callback: Callable[[], None] | None = None,
    ) -> QueryStream:
        """Open a streaming DataFrame query using a prebuilt Flight ticket."""
        reader = self._open_ticket_reader(ticket_bytes, workspace=workspace, dataset=dataset)
        return QueryStream(
            reader,
            schema=reader.schema,
            exception_mapper=lambda exc: self._map_flight_error(
                exc, workspace=workspace, dataset=dataset
            ),
            close_callback=close_callback,
        )

    def close(self) -> None:
        """Close the client connection."""
        if self._client is not None:
            _logger.debug("dataframe_client_close")
            self._client.close()
            self._client = None

    def __enter__(self) -> DataFrameClient:
        """Enter context manager."""
        return self

    def __exit__(self, *args: object) -> None:
        """Exit context manager."""
        self.close()
