"""Materialized dataframe query results."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING

import pyarrow as pa

from featureform.serving._realtime import RealtimeExecutor
from featureform.serving.types import RealtimeFeatureInput, RealtimeFeatureMetadata

if TYPE_CHECKING:
    import pandas as pd
    import polars as pl

    from featureform.spark import DataframeExecutionInfo


_TRAINING_SET_REALTIME_METADATA_KEY = b"featureform_training_set_realtime_metadata"


class QueryResult:
    """Materialized result of a DataFrame query."""

    def __init__(
        self,
        batches: list[pa.RecordBatch] | None = None,
        *,
        execution_info: DataframeExecutionInfo | None = None,
    ) -> None:
        """Initialize with record batches.

        Args:
            batches: List of Arrow RecordBatches.
        """
        executor = RealtimeExecutor()
        loaded_callables: dict[str, object] = {}
        validated_artifacts: set[str] = set()
        self._batches: list[pa.RecordBatch] = [
            _apply_training_set_realtime_metadata(
                batch,
                executor=executor,
                loaded_callables=loaded_callables,
                validated_artifacts=validated_artifacts,
            )
            for batch in (batches or [])
        ]
        self.execution_info = execution_info

    @classmethod
    def empty(cls) -> QueryResult:
        """Create an empty result."""
        return cls(batches=[])

    @classmethod
    def from_reader(cls, reader: pa.RecordBatchReader) -> QueryResult:
        """Create result from a RecordBatchReader or FlightStreamReader.

        Args:
            reader: Arrow RecordBatchReader or FlightStreamReader from Flight stream.

        Returns:
            QueryResult with collected batches.
        """
        batches = []
        for item in reader:
            # Handle FlightStreamChunk (from do_get) or RecordBatch
            if hasattr(item, "data") and item.data is not None:
                # FlightStreamChunk - extract the RecordBatch
                batches.append(item.data)
            elif isinstance(item, pa.RecordBatch):
                # Direct RecordBatch
                batches.append(item)
            # Skip chunks with no data (e.g., metadata-only chunks)
        return cls(batches=batches)

    def is_empty(self) -> bool:
        """Check if the result has no data."""
        return len(self._batches) == 0

    @property
    def schema(self) -> pa.Schema | None:
        """Get the schema of the result.

        Returns:
            Schema if available, None if empty.
        """
        if not self._batches:
            return None
        return self._batches[0].schema

    @property
    def num_rows(self) -> int:
        """Get total number of rows across all batches."""
        return sum(batch.num_rows for batch in self._batches)

    def to_arrow(self) -> pa.Table:
        """Convert to a PyArrow Table.

        This concatenates all batches into a single table.
        For large datasets, prefer the explicit streaming API.

        Returns:
            PyArrow Table containing all data.
        """
        if not self._batches:
            # Return empty table with empty schema
            return pa.table({})
        return pa.Table.from_batches(self._batches)

    def to_pandas(self) -> pd.DataFrame:
        """Convert to a Pandas DataFrame.

        This materializes all data in memory.
        For large datasets, prefer the explicit streaming API.

        Returns:
            Pandas DataFrame containing all data.
        """
        return self.to_arrow().to_pandas()

    def to_polars(self) -> pl.DataFrame:
        """Convert to a Polars DataFrame.

        Requires polars to be installed.

        Returns:
            Polars DataFrame containing all data.

        Raises:
            ImportError: If polars is not installed.
        """
        try:
            import polars as pl
        except ImportError as e:
            raise ImportError(
                "polars is required for to_polars(). Install it with: pip install polars"
            ) from e

        return pl.from_arrow(self.to_arrow())

    def __repr__(self) -> str:
        """Return string representation."""
        return f"QueryResult(batches={len(self._batches)}, rows={self.num_rows})"


def _apply_training_set_realtime_metadata(
    batch: pa.RecordBatch,
    *,
    executor: RealtimeExecutor | None = None,
    loaded_callables: dict[str, object] | None = None,
    validated_artifacts: set[str] | None = None,
) -> pa.RecordBatch:
    metadata = _decode_training_set_realtime_metadata(batch.schema)
    if metadata is None:
        return batch

    realtime_outputs, realtime_artifacts, hidden_names, feature_types = metadata
    if not realtime_outputs and not hidden_names:
        return batch

    if executor is None:
        executor = RealtimeExecutor()
    if loaded_callables is None:
        loaded_callables = {}
    if validated_artifacts is None:
        validated_artifacts = set()
    arrays_by_name = {
        name: batch.column(i).to_pylist() for i, name in enumerate(batch.schema.names)
    }
    columns_by_name = {name: batch.column(i) for i, name in enumerate(batch.schema.names)}

    for output_name in realtime_outputs:
        artifact = realtime_artifacts.get(output_name)
        if artifact is None:
            raise ValueError(f"Missing realtime metadata for training-set feature '{output_name}'")

        if output_name not in validated_artifacts:
            executor._validate_artifact_compatibility(artifact)
            validated_artifacts.add(output_name)
        fn = loaded_callables.get(output_name)
        if fn is None:
            fn = executor._load_callable(artifact)
            loaded_callables[output_name] = fn
        output_values = []
        for row_index in range(batch.num_rows):
            args = []
            for input_value in artifact.inputs:
                if input_value.source_type != "stored_field":
                    raise ValueError(
                        "Training-set realtime execution only supports stored_field inputs; "
                        f"found '{input_value.source_type}' for feature '{artifact.name}'"
                    )
                if input_value.source_name not in arrays_by_name:
                    raise ValueError(
                        f"Missing backing field '{input_value.source_name}' "
                        f"for training-set realtime feature '{artifact.name}'"
                    )
                args.append(arrays_by_name[input_value.source_name][row_index])
            output_values.append(fn(*args))
        arrays_by_name[output_name] = output_values

    final_names = [name for name in batch.schema.names if name not in hidden_names]
    for output_name in realtime_outputs:
        if output_name not in final_names:
            final_names.append(output_name)

    final_arrays: list[pa.Array] = []
    for name in final_names:
        if name in realtime_outputs:
            final_arrays.append(pa.array(arrays_by_name[name], type=feature_types.get(name)))
            continue
        if name in columns_by_name:
            final_arrays.append(columns_by_name[name])
            continue
        final_arrays.append(pa.array(arrays_by_name[name], type=feature_types.get(name)))
    return pa.record_batch(final_arrays, names=final_names)


def _decode_training_set_realtime_metadata(
    schema: pa.Schema,
) -> (
    tuple[list[str], dict[str, RealtimeFeatureMetadata], set[str], dict[str, pa.DataType | None]]
    | None
):
    metadata = schema.metadata or {}
    raw_payload = metadata.get(_TRAINING_SET_REALTIME_METADATA_KEY)
    if raw_payload is None:
        return None

    payload = json.loads(raw_payload.decode("utf-8"))
    feature_schema = payload.get("feature_schema", [])
    realtime_features = payload.get("realtime_features", [])

    hidden_names = {
        str(feature["name"]) for feature in feature_schema if not bool(feature.get("exposed", True))
    }
    realtime_outputs = [
        str(feature["name"])
        for feature in feature_schema
        if str(feature.get("mode", "stored")) == "realtime" and bool(feature.get("exposed", True))
    ]
    feature_types = {
        str(feature["name"]): _feature_type_to_arrow_type(str(feature.get("type", "")))
        for feature in feature_schema
    }

    parsed_realtime_features = {
        str(feature["name"]): RealtimeFeatureMetadata(
            name=str(feature["name"]),
            requirements=[str(requirement) for requirement in feature.get("requirements", [])],
            normalized_function_string=str(feature["normalized_function_string"]),
            function_normalizer_details=dict(feature["function_normalizer_details"]),
            serialized_function=str(feature["serialized_function"]),
            extracted_function_string=str(feature["extracted_function_string"]),
            serialization_python_version=str(feature["serialization_python_version"]),
            serializer_details=dict(feature["serializer_details"]),
            inputs=[
                RealtimeFeatureInput(
                    source_type=str(input_value["source_type"]),
                    source_name=str(input_value["source_name"]),
                )
                for input_value in feature.get("inputs", [])
            ],
        )
        for feature in realtime_features
    }
    return realtime_outputs, parsed_realtime_features, hidden_names, feature_types


def _feature_type_to_arrow_type(feature_type: str) -> pa.DataType | None:
    feature_type = feature_type.lower()
    if feature_type == "bool":
        return pa.bool_()
    if feature_type == "int32":
        return pa.int32()
    if feature_type == "int64":
        return pa.int64()
    if feature_type == "float32":
        return pa.float32()
    if feature_type == "float64":
        return pa.float64()
    if feature_type == "string":
        return pa.string()
    if feature_type == "timestamp":
        return pa.timestamp("us")
    return None
