"""Featureform exception hierarchy."""


class FeatureformError(Exception):
    """Base exception for all Featureform errors."""

    def __init__(
        self,
        message: str,
        *,
        code: str | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.code = code
        self.request_id = request_id

    def __str__(self) -> str:
        parts = [self.message]
        if self.code:
            parts.append(f"code={self.code}")
        if self.request_id:
            parts.append(f"request_id={self.request_id}")
        return " ".join(parts)


class ValidationError(FeatureformError, ValueError):
    """Validation failed."""

    pass


class ConfigurationError(ValidationError):
    """Configuration failed validation."""

    pass


class BaseURLConfigurationError(ConfigurationError):
    """Base URL configuration is invalid."""

    pass


class ClientCertificateConfigurationError(ConfigurationError):
    """mTLS client certificate configuration is incomplete."""

    pass


class NotFoundError(FeatureformError):
    """Resource not found."""

    pass


class AlreadyExistsError(FeatureformError):
    """Resource already exists."""

    pass


class InvalidArgumentError(FeatureformError):
    """Invalid argument provided."""

    pass


class InternalError(FeatureformError):
    """Internal server error."""

    pass


class ConnectionError(FeatureformError):
    """Failed to connect to server."""

    pass


class TimeoutError(FeatureformError):
    """Request timed out."""

    pass


class AuthenticationError(FeatureformError):
    """Authentication failed (e.g., invalid token)."""

    pass


class PermissionDeniedError(FeatureformError):
    """Permission denied to access resource."""

    pass


class RateLimitError(FeatureformError):
    """Rate limit exceeded."""

    def __init__(
        self,
        message: str,
        *,
        code: str | None = None,
        request_id: str | None = None,
        retry_after: int | None = None,
    ) -> None:
        super().__init__(message, code=code, request_id=request_id)
        self.retry_after = retry_after


class ServiceUnavailableError(FeatureformError):
    """Service is temporarily unavailable."""

    pass


class VersionMismatchError(FeatureformError):
    """Version mismatch between client and server."""

    pass


class EditionMismatchError(FeatureformError):
    """Edition mismatch between client and server."""

    pass


class WorkspaceRequiredError(ValidationError):
    """Workspace is required but was not provided."""

    pass


class DatasetRequiredError(ValidationError):
    """Dataset is required but was not provided."""

    pass


class AddressRequiredError(ValidationError):
    """Address is required but was not provided."""

    pass


class InvalidJSONFilterError(ValidationError):
    """JSON filter expression is invalid."""

    def __init__(self, details: str | None = None) -> None:
        message = "invalid JSON filter"
        if details:
            message = f"{message}: {details}"
        super().__init__(message, code="invalid_json_filter")
        self.details = details


class InvalidFilterExpressionError(ValidationError):
    """Filter expression is invalid."""

    def __init__(self, details: str | None = None) -> None:
        message = "invalid filter expression"
        if details:
            message = f"{message}: {details}"
        super().__init__(message, code="invalid_filter_expression")
        self.details = details


class InvalidFilterTypeError(ValidationError):
    """Structured dataframe filter type is invalid."""

    def __init__(self, filter_type: str | None) -> None:
        super().__init__(
            f"invalid filter type: {filter_type}",
            code="invalid_filter_type",
        )
        self.filter_type = filter_type


class FlightConnectionError(FeatureformError):
    """Arrow Flight connection failed."""

    pass


class FlightTLSConfigurationError(FlightConnectionError):
    """Arrow Flight TLS configuration failed."""

    pass


class FlightProviderNotFoundError(NotFoundError):
    """Requested dataframe provider was not found."""

    pass


class FlightDatasetNotFoundError(NotFoundError):
    """Requested dataframe dataset was not found."""

    pass


class FlightWorkspaceVersionUnavailableError(FeatureformError):
    """Workspace has no committed version visible to Arrow Flight yet."""

    pass


class FeatureViewMetadataError(ValidationError):
    """Feature view metadata is invalid."""

    def __init__(self) -> None:
        super().__init__(
            "serving metadata missing entity_columns",
            code="feature_view_metadata_missing_entity_columns",
        )


class EntitySelectionError(ValidationError):
    """Serving request entity selection is invalid."""

    def __init__(self, reason: str) -> None:
        messages = {
            "missing": "Must provide either 'entity' or 'entities'",
            "conflict": "Cannot provide both 'entity' and 'entities'",
        }
        super().__init__(messages[reason], code=f"entity_selection_{reason}")
        self.reason = reason


class MissingEntityValueError(ValidationError):
    """Serving request is missing an entity value."""

    def __init__(self, entity_name: str) -> None:
        super().__init__(f"missing entity value: {entity_name}", code="missing_entity_value")
        self.entity_name = entity_name


class UnexpectedEntityValueError(ValidationError):
    """Serving request contains unexpected entity values."""

    def __init__(self) -> None:
        super().__init__("unexpected entity value", code="unexpected_entity_value")


class NameResolutionError(ValidationError):
    """Object could not be resolved to a Featureform resource name."""

    pass


class FeatureBuilderStateError(ValidationError):
    """Feature builder is missing required state."""

    pass


class FeatureDatasetRequiredError(FeatureBuilderStateError):
    """Feature builder requires from_dataset() before completion."""

    pass


class LabelBuilderStateError(ValidationError):
    """Label builder is missing required state."""

    pass


class LabelDatasetRequiredError(LabelBuilderStateError):
    """Label builder requires from_dataset()."""

    pass


class LabelValueRequiredError(LabelBuilderStateError):
    """Label builder requires value()."""

    pass


class LabelEntityRequiredError(LabelBuilderStateError):
    """Label builder requires at least one entity()."""

    pass


class ProviderConfigError(ValidationError):
    """Provider configuration is invalid."""

    pass


class ProviderSecretConfigurationError(ProviderConfigError):
    """Provider secret configuration is incomplete."""

    pass


class UnsupportedProviderTypeError(FeatureformError, ValueError):
    """Provider type is not supported."""

    pass


class MissingPostgresConfigError(ProviderConfigError):
    """Provider is missing required postgres config."""

    def __init__(
        self,
        *,
        provider_name: str | None = None,
        missing_fields: tuple[str, ...] | None = None,
    ) -> None:
        message = "--pg-host and --pg-database are required for postgres"
        if provider_name is not None and missing_fields is not None:
            fields = ", ".join(missing_fields)
            message = f"Provider '{provider_name}' is missing required postgres config: {fields}"
        super().__init__(message, code="missing_postgres_config")
        self.provider_name = provider_name
        self.missing_fields = missing_fields


class MissingSnowflakeConfigError(ProviderConfigError):
    """Provider is missing required Snowflake config."""

    def __init__(
        self,
        *,
        provider_name: str | None = None,
        missing_fields: tuple[str, ...] | None = None,
    ) -> None:
        message = (
            "--snowflake-account, --snowflake-warehouse, "
            "--snowflake-database, and --snowflake-schema are required for snowflake"
        )
        if provider_name is not None and missing_fields is not None:
            fields = ", ".join(missing_fields)
            message = f"Provider '{provider_name}' is missing required snowflake config: {fields}"
        super().__init__(message, code="missing_snowflake_config")
        self.provider_name = provider_name
        self.missing_fields = missing_fields


class MissingS3ConfigError(ProviderConfigError):
    """Provider is missing required S3 config."""

    def __init__(self) -> None:
        super().__init__(
            "--s3-bucket and --s3-region are required for s3",
            code="missing_s3_config",
        )


class MissingDynamoDBConfigError(ProviderConfigError):
    """Provider is missing required DynamoDB config."""

    def __init__(self) -> None:
        super().__init__(
            "--dynamodb-region is required for dynamodb",
            code="missing_dynamodb_config",
        )


class MissingRedisConfigError(ProviderConfigError):
    """Provider is missing required Redis config."""

    def __init__(self) -> None:
        super().__init__(
            "--redis-host is required for redis",
            code="missing_redis_config",
        )


class MissingRedisClusterConfigError(ProviderConfigError):
    """Provider is missing required Redis cluster config."""

    def __init__(self) -> None:
        super().__init__(
            "--redis-cluster-endpoints is required for redis-cluster",
            code="missing_redis_cluster_config",
        )


class MissingIcebergCatalogConfigError(ProviderConfigError):
    """Iceberg provider is missing its catalog selection config."""

    def __init__(self) -> None:
        super().__init__(
            "--iceberg-catalog-type and --iceberg-warehouse-provider are required for iceberg",
            code="missing_iceberg_catalog_config",
        )


class MissingIcebergRESTConfigError(ProviderConfigError):
    """Iceberg REST catalog is missing its required URI."""

    def __init__(self) -> None:
        super().__init__(
            "--iceberg-rest-uri is required for REST catalog",
            code="missing_iceberg_rest_config",
        )


class MissingIcebergHiveConfigError(ProviderConfigError):
    """Iceberg Hive catalog is missing its required URI."""

    def __init__(self) -> None:
        super().__init__(
            "--iceberg-hive-uri is required for HIVE catalog",
            code="missing_iceberg_hive_config",
        )


class MissingIcebergGlueConfigError(ProviderConfigError):
    """Iceberg Glue catalog is missing its required region."""

    def __init__(self) -> None:
        super().__init__(
            "--iceberg-glue-region is required for GLUE catalog",
            code="missing_iceberg_glue_config",
        )


class ProviderTypeMismatchError(FeatureformError, TypeError):
    """Provider type does not match the requested API."""

    pass


class ProviderDatasetsNotImplementedError(FeatureformError, NotImplementedError):
    """Dataset relationship API is not implemented."""

    pass


class UnresolvedProviderReferenceError(ValidationError):
    """Apply resource references a locally-constructed unresolved provider object."""

    def __init__(self, *, unresolved_references: dict[str, tuple[str, ...]]) -> None:
        details = "; ".join(
            f"{provider_name}: {', '.join(usages)}"
            for provider_name, usages in sorted(unresolved_references.items())
        )
        super().__init__(
            "resource authoring used unresolved local provider object(s): "
            f"{details}. Use client.get_provider()/client.get_postgres() "
            "(or ff.get_provider()/ff.get_postgres() in apply resource files), or pass provider "
            "names directly instead of constructing provider objects locally.",
            code="unresolved_provider_reference",
        )
        self.unresolved_references = unresolved_references


class ProviderWorkspaceMismatchError(ValidationError):
    """Apply resource references a resolved provider handle from another workspace."""

    def __init__(
        self,
        *,
        expected_workspace_id: str,
        source_workspace_ids: dict[str, tuple[str, ...]],
        mismatched_references: dict[str, tuple[str, ...]],
    ) -> None:
        details: list[str] = []
        for provider_name, usages in mismatched_references.items():
            source_ids = ", ".join(source_workspace_ids[provider_name])
            usage_list = ", ".join(usages)
            details.append(
                f"{provider_name}: source workspace(s) {source_ids}, target workspace "
                f"{expected_workspace_id}, usages {usage_list}"
            )

        super().__init__(
            "resource authoring used backend-resolved provider handle(s) from a different "
            f"workspace: {'; '.join(details)}",
            code="provider_workspace_mismatch",
        )
        self.expected_workspace_id = expected_workspace_id
        self.source_workspace_ids = source_workspace_ids
        self.mismatched_references = mismatched_references


class SecretFormatError(ValidationError):
    """Secret reference string is invalid."""

    pass


class TransportUnavailableError(FeatureformError, RuntimeError):
    """Requested transport is unavailable."""

    pass


class RESTTransportUnavailableError(TransportUnavailableError):
    """REST transport is unavailable."""

    pass


class GRPCTransportUnavailableError(TransportUnavailableError):
    """gRPC transport is unavailable."""

    pass


class NoTransportAvailableError(TransportUnavailableError):
    """No client transport is available."""

    pass


class NoResourcesToApplyError(ValidationError):
    """Apply requires at least one resource."""

    pass


class RESTApplyNotImplementedError(FeatureformError, NotImplementedError):
    """REST apply is not implemented."""

    pass


class ApplyMappingError(FeatureformError, RuntimeError):
    """Apply error mapping failed."""

    pass


class GRPCTLSConfigurationError(ConfigurationError):
    """gRPC TLS channel configuration failed."""

    pass


class GRPCTLSConnectionError(ConnectionError):
    """gRPC TLS connection failed."""

    pass


class GRPCMTLSAuthenticationError(AuthenticationError):
    """gRPC mTLS authentication failed."""

    pass


class UnexpectedProtocolResponseError(FeatureformError):
    """Transport received an unexpected protocol response."""

    pass


class InvalidDataframeEngineError(ValidationError):
    """Dataframe engine selection is invalid."""

    def __init__(self, engine: str) -> None:
        super().__init__(
            f"invalid dataframe engine: {engine}",
            code="invalid_dataframe_engine",
        )
        self.engine = engine
        self.allowed = ("flight", "spark", "auto")


class InvalidDataframeQueryKindError(ValidationError):
    """Dataframe query target kind is invalid."""

    def __init__(self, kind: str) -> None:
        super().__init__(
            f"invalid dataframe query kind: {kind}",
            code="invalid_dataframe_query_kind",
        )
        self.kind = kind
        self.allowed = ("dataset", "training_set", "feature_view")


class SparkSessionRequiredError(ValidationError):
    """Spark execution requires a Spark session."""

    def __init__(self) -> None:
        super().__init__(
            "spark session is required when engine='spark'",
            code="spark_session_required",
        )


class SparkWorkspaceReferenceRequiredError(ValidationError):
    """Spark execution requires a workspace reference."""

    def __init__(self) -> None:
        super().__init__(
            "workspace_id or workspace is required when using Spark engine",
            code="spark_workspace_reference_required",
        )


class DataframePlanResolutionError(FeatureformError):
    """Failed to resolve or prepare a dataframe execution plan."""

    def __init__(self) -> None:
        super().__init__(
            "dataframe plan execution failed before fallback could run",
            code="dataframe_plan_resolution_failed",
        )


class SparkExecutionError(FeatureformError):
    """Spark-native dataframe execution failed."""

    pass


class SparkPlanUnavailableError(SparkExecutionError):
    """Resolved dataframe plan cannot execute in Spark."""

    def __init__(self) -> None:
        super().__init__(
            "dataframe plan does not contain a Spark-compatible plan",
            code="spark_plan_unavailable",
        )


class SparkJdbcExecutionError(SparkExecutionError):
    """Spark JDBC execution failed."""

    def __init__(self, provider_name: str) -> None:
        super().__init__(
            f"Spark JDBC read failed for provider '{provider_name}'. "
            "Pass local credentials with SparkOptions.postgres(...) or "
            "FEATUREFORM_SPARK_JDBC_PASSWORD_<PROVIDER>.",
            code="spark_jdbc_execution_failed",
        )
        self.provider_name = provider_name


class SparkIcebergExecutionError(SparkExecutionError):
    """Spark Iceberg execution failed."""

    def __init__(self, provider_name: str) -> None:
        super().__init__(
            f"Spark Iceberg read failed for provider '{provider_name}'. "
            "Pass local catalog credentials with SparkOptions.iceberg_s3(...) or "
            "FEATUREFORM_SPARK_ICEBERG_S3_*_<PROVIDER>.",
            code="spark_iceberg_execution_failed",
        )
        self.provider_name = provider_name


class UnhandledSparkExecutionError(SparkExecutionError):
    """Spark execution failed with an unclassified local error."""

    def __init__(self, error_type: str) -> None:
        super().__init__(
            f"Spark execution failed with local {error_type}.",
            code="spark_execution_failed",
        )
        self.error_type = error_type


class DataframeFallbackError(FeatureformError):
    """Spark execution failed and Flight fallback could not complete."""

    def __init__(
        self,
        *,
        message: str,
        code: str,
        spark_error: SparkExecutionError | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(message, code=code, request_id=request_id)
        self.spark_error = spark_error


class FlightFallbackUnavailableError(DataframeFallbackError):
    """Spark fallback to Flight was requested, but no fallback plan was available."""

    def __init__(self, *, spark_error: SparkExecutionError | None = None) -> None:
        super().__init__(
            message="No Flight fallback plan is available after Spark execution failed.",
            code="flight_fallback_unavailable",
            spark_error=spark_error,
        )


class FlightFallbackExecutionError(DataframeFallbackError):
    """Spark fallback to Flight failed while executing the fallback plan."""

    def __init__(self, *, spark_error: SparkExecutionError | None = None) -> None:
        super().__init__(
            message="Flight fallback execution failed after Spark execution error.",
            code="flight_fallback_execution_failed",
            spark_error=spark_error,
        )


class ApplyWaitConfigurationError(ValidationError):
    """Apply wait configuration is invalid."""

    pass


class WaitWithDryRunError(ApplyWaitConfigurationError):
    """Apply wait cannot be combined with dry_run."""

    def __init__(self) -> None:
        super().__init__("wait cannot be used with dry_run", code="wait_with_dry_run")


class WaitForRequiresWaitError(ApplyWaitConfigurationError):
    """Wait target overrides require wait=True."""

    def __init__(self) -> None:
        super().__init__("wait_for requires wait=True", code="wait_for_requires_wait")


class WaitTimeoutRequiresWaitError(ApplyWaitConfigurationError):
    """Wait timeout overrides require wait=True."""

    def __init__(self) -> None:
        super().__init__(
            "wait_timeout requires wait=True",
            code="wait_timeout_requires_wait",
        )


class PollIntervalRequiresWaitError(ApplyWaitConfigurationError):
    """Poll interval overrides require wait=True."""

    def __init__(self) -> None:
        super().__init__(
            "poll_interval requires wait=True",
            code="poll_interval_requires_wait",
        )


class InvalidWaitTimeoutError(ApplyWaitConfigurationError):
    """Apply wait timeout must be positive."""

    def __init__(self, wait_timeout: float) -> None:
        super().__init__(
            "wait_timeout must be greater than 0",
            code="invalid_wait_timeout",
        )
        self.wait_timeout = wait_timeout


class InvalidPollIntervalError(ApplyWaitConfigurationError):
    """Apply poll interval must be positive."""

    def __init__(self, poll_interval: float) -> None:
        super().__init__(
            "poll_interval must be greater than 0",
            code="invalid_poll_interval",
        )
        self.poll_interval = poll_interval


class InvalidWaitTargetError(ApplyWaitConfigurationError):
    """Apply wait target is invalid."""

    def __init__(self, wait_target: str) -> None:
        super().__init__(
            f"invalid wait target: {wait_target}",
            code="invalid_wait_target",
        )
        self.wait_target = wait_target


__all__ = [
    "FeatureformError",
    "NotFoundError",
    "AlreadyExistsError",
    "InvalidArgumentError",
    "ValidationError",
    "InternalError",
    "ConnectionError",
    "TimeoutError",
    "AuthenticationError",
    "PermissionDeniedError",
    "RateLimitError",
    "ServiceUnavailableError",
    "VersionMismatchError",
    "EditionMismatchError",
    "WorkspaceRequiredError",
    "DatasetRequiredError",
    "AddressRequiredError",
    "ConfigurationError",
    "BaseURLConfigurationError",
    "ClientCertificateConfigurationError",
    "InvalidJSONFilterError",
    "InvalidFilterExpressionError",
    "FlightConnectionError",
    "FlightTLSConfigurationError",
    "FlightProviderNotFoundError",
    "FlightDatasetNotFoundError",
    "FlightWorkspaceVersionUnavailableError",
    "FeatureViewMetadataError",
    "EntitySelectionError",
    "MissingEntityValueError",
    "UnexpectedEntityValueError",
    "NameResolutionError",
    "FeatureBuilderStateError",
    "FeatureDatasetRequiredError",
    "LabelBuilderStateError",
    "LabelDatasetRequiredError",
    "LabelValueRequiredError",
    "LabelEntityRequiredError",
    "ProviderConfigError",
    "ProviderSecretConfigurationError",
    "UnsupportedProviderTypeError",
    "MissingPostgresConfigError",
    "MissingSnowflakeConfigError",
    "MissingS3ConfigError",
    "MissingDynamoDBConfigError",
    "MissingRedisConfigError",
    "MissingRedisClusterConfigError",
    "MissingIcebergCatalogConfigError",
    "MissingIcebergRESTConfigError",
    "MissingIcebergHiveConfigError",
    "MissingIcebergGlueConfigError",
    "ProviderTypeMismatchError",
    "ProviderDatasetsNotImplementedError",
    "UnresolvedProviderReferenceError",
    "ProviderWorkspaceMismatchError",
    "SecretFormatError",
    "TransportUnavailableError",
    "RESTTransportUnavailableError",
    "GRPCTransportUnavailableError",
    "NoTransportAvailableError",
    "NoResourcesToApplyError",
    "RESTApplyNotImplementedError",
    "ApplyMappingError",
    "GRPCTLSConfigurationError",
    "GRPCTLSConnectionError",
    "GRPCMTLSAuthenticationError",
    "UnexpectedProtocolResponseError",
    "InvalidDataframeEngineError",
    "InvalidDataframeQueryKindError",
    "SparkSessionRequiredError",
    "SparkWorkspaceReferenceRequiredError",
    "DataframePlanResolutionError",
    "SparkExecutionError",
    "SparkPlanUnavailableError",
    "SparkJdbcExecutionError",
    "SparkIcebergExecutionError",
    "UnhandledSparkExecutionError",
    "FlightFallbackUnavailableError",
    "FlightFallbackExecutionError",
    "DataframeFallbackError",
    "ApplyWaitConfigurationError",
    "WaitWithDryRunError",
    "WaitForRequiresWaitError",
    "WaitTimeoutRequiresWaitError",
    "PollIntervalRequiresWaitError",
    "InvalidWaitTimeoutError",
    "InvalidPollIntervalError",
    "InvalidWaitTargetError",
]
