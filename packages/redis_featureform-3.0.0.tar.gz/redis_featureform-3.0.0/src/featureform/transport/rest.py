"""REST transport implementation."""

from __future__ import annotations

from types import TracebackType
from typing import Any

from featureform._internal.http import HTTPClient
from featureform._internal.logging import get_logger
from featureform._internal.telemetry import (
    Instrumentor,
    SpanKind,
    StatusCode,
    TelemetryConfig,
    get_instrumentor,
)
from featureform.config import Config
from featureform.errors import (
    AlreadyExistsError,
    FeatureformError,
    InternalError,
    InvalidArgumentError,
    NotFoundError,
)
from featureform.transport.base import Response

# Module logger
_logger = get_logger("featureform.transport.rest")


class RESTTransport:
    """REST transport implementation with optional telemetry."""

    def __init__(
        self,
        config: Config,
        telemetry: TelemetryConfig | None = None,
    ) -> None:
        """Initialize REST transport.

        Args:
            config: Client configuration.
            telemetry: Optional telemetry configuration for tracing.
        """
        self._config = config
        self._instrumentor: Instrumentor = get_instrumentor(telemetry)
        self._http = HTTPClient(
            base_url=config.base_url,
            timeout=config.timeout,
            verify_ssl=config.verify_ssl,
            ca_cert_path=config.ca_cert_path,
            client_cert_path=config.client_cert_path,
            client_key_path=config.client_key_path,
            headers=dict(config.headers),
            auth_header_provider=config.authorization_header,
            skip_version_headers=config.skip_version_check,
        )

    def get(self, path: str, **kwargs: Any) -> Response:
        """Make a GET request with tracing."""
        return self._request("GET", path, **kwargs)

    def post(self, path: str, json: Any = None, **kwargs: Any) -> Response:
        """Make a POST request with tracing."""
        return self._request("POST", path, json=json, **kwargs)

    def put(self, path: str, json: Any = None, **kwargs: Any) -> Response:
        """Make a PUT request with tracing."""
        return self._request("PUT", path, json=json, **kwargs)

    def delete(self, path: str, **kwargs: Any) -> Response:
        """Make a DELETE request with tracing."""
        return self._request("DELETE", path, **kwargs)

    def _send_request(
        self,
        method: str,
        path: str,
        span: Any,
        **kwargs: Any,
    ) -> Any:
        """Send an HTTP request while recording the response on the provided span."""
        headers = dict(kwargs.pop("headers", {}))
        headers = self._instrumentor.inject_context(headers)

        try:
            http_method = getattr(self._http, method.lower())
            response = http_method(path, headers=headers, **kwargs)

            span.set_attribute("http.status_code", response.status_code)

            if response.status_code >= 400:
                span.set_status(
                    StatusCode.ERROR,
                    f"HTTP {response.status_code}",
                )

            return response

        except Exception as e:
            span.record_exception(e)
            raise

    def request_raw(self, method: str, path: str, **kwargs: Any) -> Any:
        """Make an HTTP request and return the raw httpx response."""
        with self._instrumentor.start_span(
            f"HTTP {method}",
            kind=SpanKind.CLIENT,
            attributes={
                "http.method": method,
                "http.url": f"{self._config.base_url}{path}",
                "http.target": path,
            },
        ) as span:
            return self._send_request(method, path, span, **kwargs)

    def _request(self, method: str, path: str, **kwargs: Any) -> Response:
        """Make an HTTP request with tracing.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE).
            path: Request path.
            **kwargs: Additional arguments for the HTTP client.

        Returns:
            Response object.
        """
        with self._instrumentor.start_span(
            f"HTTP {method}",
            kind=SpanKind.CLIENT,
            attributes={
                "http.method": method,
                "http.url": f"{self._config.base_url}{path}",
                "http.target": path,
            },
        ) as span:
            response = self._send_request(method, path, span, **kwargs)
            try:
                return self._handle_response(response)
            except Exception as e:
                span.record_exception(e)
                raise

    def _handle_response(self, response: Any) -> Response:
        """Handle HTTP response and map errors."""
        request_id = response.headers.get("X-Request-ID")

        if response.status_code >= 400:
            _logger.warning(
                "api_error_response",
                status_code=response.status_code,
                path=str(response.url.path),
                request_id=request_id,
            )
            self._raise_error(response, request_id)

        try:
            data = response.json()
        except Exception:
            data = None

        return Response(
            status_code=response.status_code,
            data=data,
            headers=dict(response.headers),
            request_id=request_id,
        )

    def _raise_error(self, response: Any, request_id: str | None) -> None:
        """Raise appropriate error based on status code."""
        try:
            error_data = response.json()
            error_info = error_data.get("error", {})
            message = error_info.get("message", response.text)
            code = error_info.get("code")
        except Exception:
            message = response.text or f"HTTP {response.status_code}"
            code = None

        _logger.debug(
            "api_error_details",
            status_code=response.status_code,
            error_code=code,
            message=message,
            request_id=request_id,
        )

        error_kwargs = {"code": code, "request_id": request_id}

        if response.status_code == 400:
            raise InvalidArgumentError(message, **error_kwargs)
        elif response.status_code == 404:
            raise NotFoundError(message, **error_kwargs)
        elif response.status_code == 409:
            raise AlreadyExistsError(message, **error_kwargs)
        elif response.status_code >= 500:
            raise InternalError(message, **error_kwargs)
        else:
            raise FeatureformError(message, **error_kwargs)

    def raise_for_response(self, response: Any) -> None:
        """Raise the mapped REST exception for a raw response."""
        request_id = response.headers.get("X-Request-ID")
        self._raise_error(response, request_id)

    def close(self) -> None:
        """Close the transport."""
        self._http.close()

    def __enter__(self) -> RESTTransport:
        """Enter context manager."""
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Exit context manager."""
        self.close()


__all__ = ["RESTTransport"]
