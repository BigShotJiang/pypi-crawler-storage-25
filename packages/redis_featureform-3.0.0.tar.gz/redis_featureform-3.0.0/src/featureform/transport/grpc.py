"""gRPC transport implementation using generated stubs."""

from __future__ import annotations

from collections.abc import Callable, Sequence
from importlib import import_module
from types import TracebackType
from typing import TYPE_CHECKING, Any, NamedTuple, Protocol, cast

import grpc

from featureform._internal.logging import get_logger
from featureform._internal.telemetry import (
    Instrumentor,
    TelemetryConfig,
    get_instrumentor,
)
from featureform.config import Config
from featureform.errors import (
    AlreadyExistsError,
    FeatureformError,
    GRPCMTLSAuthenticationError,
    GRPCTLSConfigurationError,
    GRPCTLSConnectionError,
    InternalError,
    InvalidArgumentError,
    NotFoundError,
    UnexpectedProtocolResponseError,
)

apply_pb2: Any = None
apply_pb2_grpc: Any = None
catalog_pb2: Any = None
catalog_pb2_grpc: Any = None
dataframe_pb2: Any = None
dataframe_pb2_grpc: Any = None
provider_pb2: Any = None
provider_pb2_grpc: Any = None
resource_pb2: Any = None
secret_provider_pb2: Any = None
secret_provider_pb2_grpc: Any = None
serving_pb2_grpc: Any = None
workspace_pb2: Any = None
workspace_pb2_grpc: Any = None

try:
    _apply_pb2 = import_module("featureform._generated.proto.featureform.v2.apply_pb2")
    _apply_pb2_grpc = import_module("featureform._generated.proto.featureform.v2.apply_pb2_grpc")
    _catalog_pb2 = import_module("featureform._generated.proto.featureform.v2.catalog_pb2")
    _catalog_pb2_grpc = import_module(
        "featureform._generated.proto.featureform.v2.catalog_pb2_grpc"
    )
    _provider_pb2 = import_module("featureform._generated.proto.featureform.v2.provider_pb2")
    _provider_pb2_grpc = import_module(
        "featureform._generated.proto.featureform.v2.provider_pb2_grpc"
    )
    _resource_pb2 = import_module("featureform._generated.proto.featureform.v2.resource_pb2")
    _secret_provider_pb2 = import_module(
        "featureform._generated.proto.featureform.v2.secret_provider_pb2"
    )
    _secret_provider_pb2_grpc = import_module(
        "featureform._generated.proto.featureform.v2.secret_provider_pb2_grpc"
    )
    _dataframe_pb2 = import_module("featureform._generated.proto.featureform.v2.dataframe_pb2")
    _dataframe_pb2_grpc = import_module(
        "featureform._generated.proto.featureform.v2.dataframe_pb2_grpc"
    )
    _serving_pb2_grpc = import_module(
        "featureform._generated.proto.featureform.v2.serving_pb2_grpc"
    )
    _workspace_pb2 = import_module("featureform._generated.proto.featureform.v2.workspace_pb2")
    _workspace_pb2_grpc = import_module(
        "featureform._generated.proto.featureform.v2.workspace_pb2_grpc"
    )
except ImportError:
    pass
else:
    apply_pb2 = _apply_pb2
    apply_pb2_grpc = _apply_pb2_grpc
    catalog_pb2 = _catalog_pb2
    catalog_pb2_grpc = _catalog_pb2_grpc
    dataframe_pb2 = _dataframe_pb2
    dataframe_pb2_grpc = _dataframe_pb2_grpc
    provider_pb2 = _provider_pb2
    provider_pb2_grpc = _provider_pb2_grpc
    resource_pb2 = _resource_pb2
    secret_provider_pb2 = _secret_provider_pb2
    secret_provider_pb2_grpc = _secret_provider_pb2_grpc
    serving_pb2_grpc = _serving_pb2_grpc
    workspace_pb2 = _workspace_pb2
    workspace_pb2_grpc = _workspace_pb2_grpc

# Module logger
_logger = get_logger("featureform.transport.grpc")

if TYPE_CHECKING:

    class _UnaryUnaryClientInterceptor(grpc.UnaryUnaryClientInterceptor[Any, Any]):
        pass

    class _UnaryStreamClientInterceptor(grpc.UnaryStreamClientInterceptor[Any, Any]):
        pass
else:
    _UnaryUnaryClientInterceptor = grpc.UnaryUnaryClientInterceptor
    _UnaryStreamClientInterceptor = grpc.UnaryStreamClientInterceptor


class _ClientCallDetails(NamedTuple):
    method: str
    timeout: float | None
    metadata: Sequence[tuple[str, str | bytes]] | None
    credentials: grpc.CallCredentials | None
    wait_for_ready: bool | None
    compression: grpc.Compression | None


class _BearerTokenClientInterceptor(
    _UnaryUnaryClientInterceptor,
    _UnaryStreamClientInterceptor,
):
    """Attach bearer auth metadata to gRPC client calls when configured."""

    def __init__(self, metadata_provider: Callable[[], Sequence[tuple[str, str]]]) -> None:
        self._metadata_provider = metadata_provider

    def _augment_details(self, client_call_details: grpc.ClientCallDetails) -> _ClientCallDetails:
        existing_metadata = tuple(client_call_details.metadata or ())
        metadata = tuple(self._metadata_provider())
        return _ClientCallDetails(
            method=client_call_details.method,
            timeout=client_call_details.timeout,
            metadata=existing_metadata + metadata,
            credentials=client_call_details.credentials,
            wait_for_ready=getattr(client_call_details, "wait_for_ready", None),
            compression=getattr(client_call_details, "compression", None),
        )

    def intercept_unary_unary(
        self,
        continuation: Any,
        client_call_details: grpc.ClientCallDetails,
        request: Any,
    ) -> Any:
        return continuation(self._augment_details(client_call_details), request)

    def intercept_unary_stream(
        self,
        continuation: Any,
        client_call_details: grpc.ClientCallDetails,
        request: Any,
    ) -> Any:
        return continuation(self._augment_details(client_call_details), request)


class TimeoutStubProxy:
    """Proxy that injects a default timeout into gRPC stub calls."""

    def __init__(
        self,
        stub: Any,
        *,
        default_timeout: float,
        logger: Any,
        stub_name: str,
    ) -> None:
        self._stub = stub
        self._default_timeout = default_timeout
        self._logger = logger
        self._stub_name = stub_name

    def __getattr__(self, name: str) -> Any:
        """Wrap callable stub methods with timeout injection and debug logging."""
        attr = getattr(self._stub, name)
        if not callable(attr):
            return attr

        def wrapped(*args: Any, **kwargs: Any) -> Any:
            kwargs.setdefault("timeout", self._default_timeout)
            self._logger.debug(
                "grpc_stub_call",
                stub=self._stub_name,
                method=name,
                timeout=kwargs["timeout"],
            )
            return attr(*args, **kwargs)

        return wrapped


def _grpc_target_from_url(url: str) -> tuple[str, bool]:
    """Convert a configured base URL into a gRPC target and mode.

    Returns:
        A tuple of ``(target, use_plaintext)``.
    """
    if url.startswith("http://"):
        return url[7:], True
    if url.startswith("https://"):
        return url[8:], False
    if url.startswith("grpc://"):
        return url[7:], False
    return url, False


def _create_tls_channel(
    target: str,
    verify_ssl: bool,
    *,
    ca_cert_path: str | None = None,
    client_cert_path: str | None = None,
    client_key_path: str | None = None,
) -> grpc.Channel:
    """Create a TLS-enabled gRPC channel for a host:port target."""
    root_certificates: bytes | None = None
    private_key: bytes | None = None
    certificate_chain: bytes | None = None

    if ca_cert_path:
        _logger.debug("grpc_using_custom_ca", path=ca_cert_path)
        try:
            root_certificates = _load_file_bytes(ca_cert_path)
        except FileNotFoundError as err:
            raise GRPCTLSConfigurationError(
                f"CA certificate file not found: {ca_cert_path}\n"
                "Set FEATUREFORM_CA_CERT to a valid CA certificate path."
            ) from err

    if client_cert_path and client_key_path:
        try:
            certificate_chain = _load_file_bytes(client_cert_path)
        except FileNotFoundError as err:
            raise GRPCTLSConfigurationError(
                f"Client certificate file not found: {client_cert_path}\n"
                "Set FEATUREFORM_CLIENT_CERT to a valid client certificate path."
            ) from err
        try:
            private_key = _load_file_bytes(client_key_path)
        except FileNotFoundError as err:
            raise GRPCTLSConfigurationError(
                f"Client key file not found: {client_key_path}\n"
                "Set FEATUREFORM_CLIENT_KEY to a valid client private key path."
            ) from err

    if not verify_ssl and root_certificates is None:
        if certificate_chain is not None or private_key is not None:
            raise GRPCTLSConfigurationError(
                "gRPC TLS requires a CA certificate when using client certificates with "
                "private or self-signed server certs.\n\n"
                "Set FEATUREFORM_CA_CERT=/path/to/ca.crt or provide ca_cert_path when "
                "using --insecure with mTLS."
            )
        _logger.debug("grpc_channel_tls_insecure", target=target)
        raise GRPCTLSConnectionError(
            "TLS connection required but certificate verification failed.\n\n"
            "Options:\n"
            "  1. Use system CA (remove --insecure if server has valid cert)\n"
            "  2. For self-signed certs, set: FEATUREFORM_CA_CERT=/path/to/ca.crt\n"
            "  3. For local development without TLS, use: --server http://host:port"
        )

    if verify_ssl or root_certificates is not None:
        _logger.debug("grpc_channel_tls_verified", target=target)
        credentials = grpc.ssl_channel_credentials(
            root_certificates=root_certificates,
            private_key=private_key,
            certificate_chain=certificate_chain,
        )
        return grpc.secure_channel(target, credentials)
    raise AssertionError("unreachable")


def create_grpc_channel(
    base_url: str,
    verify_ssl: bool,
    *,
    no_tls: bool = False,
    ca_cert_path: str | None = None,
    client_cert_path: str | None = None,
    client_key_path: str | None = None,
) -> grpc.Channel:
    """Create a gRPC channel using the same secure-by-default URL handling as the client."""
    target, use_plaintext = _grpc_target_from_url(base_url)
    if no_tls:
        _logger.debug("grpc_channel_no_tls", target=target)
        return grpc.insecure_channel(target)
    if use_plaintext:
        _logger.debug("grpc_channel_plaintext", target=target)
        return grpc.insecure_channel(target)
    return _create_tls_channel(
        target,
        verify_ssl,
        ca_cert_path=ca_cert_path,
        client_cert_path=client_cert_path,
        client_key_path=client_key_path,
    )


def _load_file_bytes(path: str) -> bytes:
    """Load file contents from disk."""
    with open(path, "rb") as file_obj:
        return file_obj.read()


class WorkspaceServiceStub(Protocol):
    """Typed interface for the workspace service stub."""

    def CreateWorkspace(self, request: Any) -> Any: ...
    def GetWorkspace(self, request: Any) -> Any: ...
    def GetWorkspaceByName(self, request: Any) -> Any: ...
    def ListWorkspaces(self, request: Any) -> Any: ...
    def UpdateWorkspace(self, request: Any) -> Any: ...
    def DeleteWorkspace(self, request: Any) -> Any: ...


class ProviderServiceStub(Protocol):
    """Typed interface for the provider service stub."""

    def RegisterProvider(self, request: Any) -> Any: ...
    def GetProvider(self, request: Any) -> Any: ...
    def ListProviders(self, request: Any) -> Any: ...
    def UpdateProvider(self, request: Any) -> Any: ...
    def DeleteProvider(self, request: Any) -> Any: ...


class SecretProviderServiceStub(Protocol):
    """Typed interface for the secret-provider service stub."""

    def RegisterSecretProvider(self, request: Any) -> Any: ...
    def GetSecretProvider(self, request: Any) -> Any: ...
    def ListSecretProviders(self, request: Any) -> Any: ...
    def UpdateSecretProvider(self, request: Any) -> Any: ...
    def DeleteSecretProvider(self, request: Any) -> Any: ...


class ApplyServiceStub(Protocol):
    """Typed interface for the apply service stub."""

    def Apply(self, request: Any) -> Any: ...


class CatalogServiceStub(Protocol):
    """Typed interface for the catalog service stub."""

    def ListLocations(self, request: Any) -> Any: ...
    def GetLocation(self, request: Any) -> Any: ...
    def ListLocationsByProvider(self, request: Any) -> Any: ...


class DataframeServiceStub(Protocol):
    """Typed interface for the dataframe plan service stub."""

    def ResolveDataframePlan(self, request: Any) -> Any: ...


class ResourceServiceStub(Protocol):
    """Typed interface for the resource-query service stub."""

    def __getattr__(self, name: str) -> Any: ...


class ServingServiceStub(Protocol):
    """Typed interface for the serving service stub."""

    def Serve(self, request: Any) -> Any: ...
    def GetServingMetadata(self, request: Any) -> Any: ...


class GRPCTransport:
    """gRPC transport implementation using generated protobuf stubs."""

    def __init__(
        self,
        config: Config,
        telemetry: TelemetryConfig | None = None,
    ) -> None:
        """Initialize gRPC transport.

        Args:
            config: Client configuration.
            telemetry: Optional telemetry configuration for tracing.
        """
        self._config = config
        self._telemetry_config = telemetry
        self._instrumentor: Instrumentor = get_instrumentor(telemetry)
        self._channel: grpc.Channel | None = None
        self._workspace_stub: WorkspaceServiceStub | None = None
        self._provider_stub: ProviderServiceStub | None = None
        self._secret_provider_stub: SecretProviderServiceStub | None = None
        self._catalog_stub: CatalogServiceStub | None = None
        self._dataframe_stub: DataframeServiceStub | None = None
        self._apply_stub: ApplyServiceStub | None = None
        self._resource_stub: ResourceServiceStub | None = None
        self._serving_stub: ServingServiceStub | None = None

    def _auth_metadata(self) -> list[tuple[str, str]]:
        """Build outgoing auth metadata from configured auth state."""
        header = self._config.authorization_header() or ""
        if header:
            return [("authorization", header)]
        return []

    def _get_channel(self) -> grpc.Channel:
        """Get or create the gRPC channel.

        Connection logic:
        - By default, tries TLS (secure_channel)
        - If verify_ssl=False (--insecure), skips certificate verification but still uses TLS
        - http:// scheme explicitly requests plaintext (no TLS)

        This means:
        - grpc://host:port → TLS with cert verification (default)
        - grpc://host:port --insecure → TLS without cert verification
        - http://host:port → plaintext (no TLS, for local dev only)
        """
        if self._channel is None:
            channel = create_grpc_channel(
                self._config.base_url,
                self._config.verify_ssl,
                no_tls=self._config.no_tls,
                ca_cert_path=self._config.ca_cert_path,
                client_cert_path=self._config.client_cert_path,
                client_key_path=self._config.client_key_path,
            )
            intercept_channel = cast(Any, grpc).intercept_channel
            channel = intercept_channel(
                channel,
                _BearerTokenClientInterceptor(self._auth_metadata),
            )

            self._channel = channel
        assert self._channel is not None
        return self._channel

    def channel(self) -> grpc.Channel:
        """Return the underlying gRPC channel, creating it if needed."""
        return self._get_channel()

    @property
    def workspace(self) -> WorkspaceServiceStub:
        """Get the workspace service stub."""
        if self._workspace_stub is None:
            global workspace_pb2_grpc
            if workspace_pb2_grpc is None:
                workspace_pb2_grpc = import_module(
                    "featureform._generated.proto.featureform.v2.workspace_pb2_grpc"
                )
            self._workspace_stub = cast(
                WorkspaceServiceStub,
                TimeoutStubProxy(
                    workspace_pb2_grpc.WorkspaceServiceStub(self._get_channel()),
                    default_timeout=self._config.timeout,
                    logger=_logger,
                    stub_name="WorkspaceServiceStub",
                ),
            )
        return self._workspace_stub

    @property
    def provider(self) -> ProviderServiceStub:
        """Get the provider service stub."""
        if self._provider_stub is None:
            global provider_pb2_grpc
            if provider_pb2_grpc is None:
                provider_pb2_grpc = import_module(
                    "featureform._generated.proto.featureform.v2.provider_pb2_grpc"
                )
            self._provider_stub = cast(
                ProviderServiceStub,
                TimeoutStubProxy(
                    provider_pb2_grpc.ProviderServiceStub(self._get_channel()),
                    default_timeout=self._config.timeout,
                    logger=_logger,
                    stub_name="ProviderServiceStub",
                ),
            )
        return self._provider_stub

    @property
    def secret_provider(self) -> SecretProviderServiceStub:
        """Get the secret provider service stub."""
        if self._secret_provider_stub is None:
            global secret_provider_pb2_grpc
            if secret_provider_pb2_grpc is None:
                secret_provider_pb2_grpc = import_module(
                    "featureform._generated.proto.featureform.v2.secret_provider_pb2_grpc"
                )
            self._secret_provider_stub = cast(
                SecretProviderServiceStub,
                TimeoutStubProxy(
                    secret_provider_pb2_grpc.SecretProviderServiceStub(self._get_channel()),
                    default_timeout=self._config.timeout,
                    logger=_logger,
                    stub_name="SecretProviderServiceStub",
                ),
            )
        return self._secret_provider_stub

    @property
    def catalog(self) -> CatalogServiceStub:
        """Get the catalog service stub."""
        if self._catalog_stub is None:
            global catalog_pb2_grpc
            if catalog_pb2_grpc is None:
                catalog_pb2_grpc = import_module(
                    "featureform._generated.proto.featureform.v2.catalog_pb2_grpc"
                )
            self._catalog_stub = cast(
                CatalogServiceStub,
                TimeoutStubProxy(
                    catalog_pb2_grpc.CatalogServiceStub(self._get_channel()),
                    default_timeout=self._config.timeout,
                    logger=_logger,
                    stub_name="CatalogServiceStub",
                ),
            )
        return self._catalog_stub

    @property
    def apply(self) -> ApplyServiceStub:
        """Get the apply service stub."""
        if self._apply_stub is None:
            global apply_pb2_grpc
            if apply_pb2_grpc is None:
                apply_pb2_grpc = import_module(
                    "featureform._generated.proto.featureform.v2.apply_pb2_grpc"
                )
            self._apply_stub = cast(
                ApplyServiceStub,
                TimeoutStubProxy(
                    apply_pb2_grpc.ApplyServiceStub(self._get_channel()),
                    default_timeout=self._config.timeout,
                    logger=_logger,
                    stub_name="ApplyServiceStub",
                ),
            )
        return self._apply_stub

    @property
    def dataframe(self) -> DataframeServiceStub:
        """Get the dataframe plan service stub."""
        if self._dataframe_stub is None:
            global dataframe_pb2_grpc
            if dataframe_pb2_grpc is None:
                from featureform._generated.proto.featureform.v2 import (
                    dataframe_pb2_grpc as _dataframe_pb2_grpc,
                )

                dataframe_pb2_grpc = _dataframe_pb2_grpc
            self._dataframe_stub = cast(
                DataframeServiceStub,
                dataframe_pb2_grpc.DataframeServiceStub(self._get_channel()),
            )
        return self._dataframe_stub

    @property
    def resource(self) -> ResourceServiceStub:
        """Get the resource query service stub.

        This import is lazy because resource-service codegen may not be present
        in all development environments until protobuf generation is run.
        """
        if self._resource_stub is None:
            pkg = import_module("featureform._generated.proto.featureform.v2")
            resource_service_pb2_grpc = getattr(pkg, "resource_service_pb2_grpc", None)
            if resource_service_pb2_grpc is None:
                resource_service_pb2_grpc = import_module(
                    "featureform._generated.proto.featureform.v2.resource_service_pb2_grpc"
                )

            self._resource_stub = cast(
                ResourceServiceStub,
                TimeoutStubProxy(
                    resource_service_pb2_grpc.ResourceServiceStub(self._get_channel()),
                    default_timeout=self._config.timeout,
                    logger=_logger,
                    stub_name="ResourceServiceStub",
                ),
            )
        return self._resource_stub

    @property
    def serving(self) -> ServingServiceStub:
        """Get the serving service stub."""
        if self._serving_stub is None:
            global serving_pb2_grpc
            if serving_pb2_grpc is None:
                serving_pb2_grpc = import_module(
                    "featureform._generated.proto.featureform.v2.serving_pb2_grpc"
                )
            self._serving_stub = cast(
                ServingServiceStub,
                TimeoutStubProxy(
                    serving_pb2_grpc.ServingServiceStub(self._get_channel()),
                    default_timeout=self._config.timeout,
                    logger=_logger,
                    stub_name="ServingServiceStub",
                ),
            )
        return self._serving_stub

    def close(self) -> None:
        """Close the gRPC channel."""
        if self._channel is not None:
            self._channel.close()
            self._channel = None
            self._workspace_stub = None
            self._provider_stub = None
            self._secret_provider_stub = None
            self._catalog_stub = None
            self._dataframe_stub = None
            self._apply_stub = None
            self._resource_stub = None
            self._serving_stub = None

    def __enter__(self) -> GRPCTransport:
        """Enter context manager."""
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Exit context manager."""
        self.close()


def grpc_error_to_exception(error: grpc.RpcError) -> FeatureformError:
    """Convert gRPC error to Featureform exception with actionable messages.

    Follows the design principle: "Error: <what happened>. <what to do>"
    """
    code = error.code()
    details = error.details() or str(error)

    # Log the error based on severity
    if code in (
        grpc.StatusCode.INTERNAL,
        grpc.StatusCode.UNAVAILABLE,
        grpc.StatusCode.UNKNOWN,
    ):
        _logger.error(
            "grpc_error",
            status_code=code.name,
            details=details,
        )
    else:
        _logger.warning(
            "grpc_error",
            status_code=code.name,
            details=details,
        )

    # Check for TLS-related errors and provide helpful messages (prepend, keep original)
    error_str = str(error).lower()
    if (
        "certificate required" in error_str
        or "client certificate" in error_str
        or "bad certificate" in error_str
    ):
        return GRPCMTLSAuthenticationError(
            "mTLS authentication failed. The server requires a valid client certificate.\n\n"
            "Options:\n"
            "  1. Set FEATUREFORM_CLIENT_CERT=/path/to/client.crt\n"
            "  2. Set FEATUREFORM_CLIENT_KEY=/path/to/client.key\n"
            "  3. Set FEATUREFORM_CA_CERT=/path/to/ca.crt for private CAs\n\n"
            f"Original error: {details}"
        )
    if (
        "trying to connect an http1.x server" in error_str
        or "error reading server preface" in error_str
    ):
        return UnexpectedProtocolResponseError(
            f"Unexpected gRPC response: {details}. Verify the server URL and transport."
        )
    if "ssl" in error_str or "certificate" in error_str or "handshake" in error_str:
        helpful_msg = (
            "TLS connection failed. The server requires a secure connection.\n\n"
            "Options:\n"
            "  1. For self-signed certs: FEATUREFORM_CA_CERT=/path/to/ca.crt ff --insecure ...\n"
            "  2. For local dev without TLS: ff --server http://localhost:9090 ...\n\n"
            f"Original error: {details}"
        )
        return GRPCTLSConnectionError(helpful_msg)

    normalized_details = details.lower().strip()

    # Some serving paths currently return UNKNOWN for missing feature views.
    # Keep this narrow until the server returns NOT_FOUND consistently.
    if code == grpc.StatusCode.UNKNOWN and normalized_details == "feature view not found":
        return NotFoundError(f"{details}. Verify the resource name and workspace.")

    # Map gRPC codes to actionable error messages
    if code == grpc.StatusCode.NOT_FOUND:
        return NotFoundError(f"{details}. Verify the resource name and workspace.")
    elif code == grpc.StatusCode.ALREADY_EXISTS:
        return AlreadyExistsError(
            f"{details}. Use a different name or delete the existing resource."
        )
    elif code == grpc.StatusCode.INVALID_ARGUMENT:
        return InvalidArgumentError(f"{details}. Check the input values and try again.")
    elif code == grpc.StatusCode.UNAVAILABLE:
        lower_details = details.lower()
        if (
            "connection refused" in lower_details
            or "failed to connect to all addresses" in lower_details
        ):
            return InternalError(
                f"Server unreachable: {details}. Verify the server address and that the service is running."
            )
        return InternalError(
            f"Server unavailable: {details}. "
            "The server may be starting up or under maintenance. Try again shortly."
        )
    elif code == grpc.StatusCode.DEADLINE_EXCEEDED:
        return InternalError(
            f"Request timed out: {details}. Try increasing --timeout or check server health."
        )
    elif code == grpc.StatusCode.PERMISSION_DENIED:
        from featureform.errors import PermissionDeniedError

        return PermissionDeniedError(
            f"{details}. You don't have access to this resource. Contact your administrator."
        )
    elif code == grpc.StatusCode.UNAUTHENTICATED:
        from featureform.errors import AuthenticationError

        return AuthenticationError(f"{details}. Run 'ff auth login' or set FEATUREFORM_TOKEN.")
    elif code == grpc.StatusCode.RESOURCE_EXHAUSTED:
        from featureform.errors import RateLimitError

        return RateLimitError(
            f"Rate limit exceeded: {details}. Wait and try again.",
            retry_after=60,
        )
    elif code == grpc.StatusCode.INTERNAL:
        return InternalError(f"Internal server error: {details}.")
    else:
        return FeatureformError(f"Unexpected gRPC error: {details}.")


# Re-export proto types for convenience
__all__ = [
    "GRPCTransport",
    "grpc_error_to_exception",
    "apply_pb2",
    "apply_pb2_grpc",
    "catalog_pb2",
    "catalog_pb2_grpc",
    "dataframe_pb2",
    "dataframe_pb2_grpc",
    "resource_pb2",
    "workspace_pb2",
    "workspace_pb2_grpc",
    "provider_pb2",
    "provider_pb2_grpc",
    "secret_provider_pb2",
    "secret_provider_pb2_grpc",
]
