"""Base transport protocol."""

from dataclasses import dataclass
from typing import Any, Protocol, runtime_checkable


@dataclass
class Response:
    """HTTP response wrapper."""

    status_code: int
    data: Any
    headers: dict[str, str]
    request_id: str | None = None


@runtime_checkable
class Transport(Protocol):
    """Protocol for transport implementations."""

    def get(self, path: str, **kwargs: Any) -> Response:
        """Make a GET request."""
        ...

    def post(self, path: str, json: Any = None, **kwargs: Any) -> Response:
        """Make a POST request."""
        ...

    def put(self, path: str, json: Any = None, **kwargs: Any) -> Response:
        """Make a PUT request."""
        ...

    def delete(self, path: str, **kwargs: Any) -> Response:
        """Make a DELETE request."""
        ...

    def close(self) -> None:
        """Close the transport."""
        ...


__all__ = ["Transport", "Response"]
