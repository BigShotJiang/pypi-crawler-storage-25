"""Transport layer for Featureform client."""

from enum import Enum

from featureform.transport.base import Response, Transport
from featureform.transport.grpc import GRPCTransport, grpc_error_to_exception
from featureform.transport.rest import RESTTransport


class TransportType(Enum):
    """Transport type enum."""

    REST = "rest"
    GRPC = "grpc"


def detect_transport_type(url: str) -> TransportType:
    """Auto-detect transport type from URL.

    Args:
        url: Server URL.

    Returns:
        TransportType based on URL scheme.

    Examples:
        - "http://localhost:8080" -> REST
        - "https://api.example.com" -> REST
        - "grpc://localhost:50051" -> GRPC
        - "localhost:50051" (bare host:port) -> GRPC
    """
    if url.startswith("http://") or url.startswith("https://"):
        return TransportType.REST
    elif url.startswith("grpc://"):
        return TransportType.GRPC
    else:
        # Bare host:port format defaults to gRPC
        return TransportType.GRPC


__all__ = [
    "Transport",
    "TransportType",
    "Response",
    "RESTTransport",
    "GRPCTransport",
    "grpc_error_to_exception",
    "detect_transport_type",
]
