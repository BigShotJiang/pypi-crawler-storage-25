"""Featureform client implementation."""

from __future__ import annotations

import base64
import time
from collections.abc import Sequence
from importlib import import_module
from pathlib import Path
from types import TracebackType
from typing import TYPE_CHECKING, Any, Literal, cast
from urllib.parse import SplitResult, urlparse, urlsplit, urlunsplit
from uuid import UUID

import grpc

if TYPE_CHECKING:
    from featureform._generated.proto.featureform.v2 import (
        provider_pb2,
        secret_provider_pb2,
        workspace_pb2,
    )
    from featureform.resources.provider import PostgresProvider, SnowflakeProvider
    from featureform.resources.provider import Provider as ResourceProvider
    from featureform.types.provider import SparkProviderConfig

from pydantic import BaseModel, ConfigDict, TypeAdapter

from featureform._apply_wait import (
    ApplyJobFetchError,
    ApplyWaitError,
    ApplyWorkspaceVersionTimeoutError,
    WaitTarget,
    wait_for_job,
)
from featureform._internal.logging import get_logger
from featureform._internal.secret_refs import secret_ref_to_string
from featureform._internal.telemetry import TelemetryConfig
from featureform.auth.runtime import (
    build_runtime_token_provider,
    normalize_config_path,
)
from featureform.cli import env as cli_env
from featureform.config import Config
from featureform.dataframe import DataFrameClient, QueryResult, QueryStream
from featureform.errors import (
    DataframeFallbackError,
    DataframePlanResolutionError,
    FeatureformError,
    GRPCTransportUnavailableError,
    InvalidArgumentError,
    InvalidDataframeEngineError,
    InvalidPollIntervalError,
    InvalidWaitTargetError,
    InvalidWaitTimeoutError,
    MissingPostgresConfigError,
    MissingSnowflakeConfigError,
    NoResourcesToApplyError,
    NotFoundError,
    NoTransportAvailableError,
    PollIntervalRequiresWaitError,
    ProviderDatasetsNotImplementedError,
    ProviderTypeMismatchError,
    ProviderWorkspaceMismatchError,
    RESTTransportUnavailableError,
    SparkExecutionError,
    SparkIcebergExecutionError,
    SparkJdbcExecutionError,
    SparkPlanUnavailableError,
    SparkSessionRequiredError,
    UnhandledSparkExecutionError,
    UnresolvedProviderReferenceError,
    UnsupportedProviderTypeError,
    WaitForRequiresWaitError,
    WaitTimeoutRequiresWaitError,
    WaitWithDryRunError,
    WorkspaceRequiredError,
)
from featureform.spark import DataframeExecutionInfo, SparkOptions, attach_execution_info
from featureform.transport import (
    GRPCTransport,
    RESTTransport,
    TransportType,
    detect_transport_type,
)
from featureform.transport.base import Response
from featureform.types import (
    CLEAR,
    AWSSecretRef,
    AWSSecretsManagerSecretConfig,
    AzureSecretRef,
    CatalogLocation,
    CreateWorkspaceRequest,
    DynamoDBConfig,
    EnvSecretConfig,
    EnvSecretRef,
    GCPSecretRef,
    GraphDatasetDetail,
    GraphEntityDetail,
    GraphFeatureDetail,
    GraphFeatureViewDetail,
    GraphLabelDetail,
    GraphLineageResult,
    GraphPipelineResult,
    GraphRelationshipResult,
    GraphResourceHistory,
    GraphResourceList,
    GraphTrainingSetDetail,
    GraphVersionDiff,
    GraphVersionSummary,
    GraphWorkspaceOverview,
    GraphWorkspaceStats,
    IcebergCatalogConfig,
    K8sSecretRef,
    KafkaConfig,
    KubernetesSecretConfig,
    PostgresConfig,
    Provider,
    ProviderConfig,
    ProviderInput,
    ProviderType,
    RedisClusterConfig,
    RedisConfig,
    RegisterProviderRequest,
    RegisterSecretProviderRequest,
    S3Config,
    SecretProvider,
    SecretProviderConfig,
    SecretProviderInput,
    SecretProviderType,
    SecretRef,
    SnowflakeConfig,
    SparkProviderConfig,
    UpdateProviderRequest,
    UpdateSecretProviderRequest,
    UpdateWorkspaceRequest,
    VaultSecretConfig,
    VaultSecretRef,
    Workspace,
)

DATAFRAME_KIND_METADATA_KEY = "x-featureform-dataframe-kind"

# Module logger
_logger = get_logger("featureform.client")


def _apply_change_type_to_str(change_type: int) -> str:
    """Convert proto change types into stable string actions."""
    mapping = {
        0: "unspecified",
        1: "add",
        2: "modify",
        3: "delete",
    }
    return mapping.get(change_type, "unknown")


def _strip_enum_prefix(value: str, prefix: str) -> str:
    if value.startswith(prefix):
        return value[len(prefix) :]
    return value


def _normalize_enum_value(value: Any, prefix: str = "") -> str:
    if not isinstance(value, str):
        return str(value or "")
    normalized = value
    if prefix and normalized.startswith(prefix):
        normalized = normalized[len(prefix) :]
    return normalized.lower()


def _normalize_scalar_type_value(value: Any) -> Any:
    if isinstance(value, str) and value.startswith("SCALAR_TYPE_"):
        return value[len("SCALAR_TYPE_") :]
    return value


def _normalize_value_type_payload(payload: Any) -> Any:
    if not isinstance(payload, dict):
        return payload
    normalized: dict[str, Any] = dict(payload)
    scalar_type = normalized.get("scalarType")
    if scalar_type is not None and "scalar_type" not in normalized:
        normalized["scalar_type"] = scalar_type
        del normalized["scalarType"]
    is_vector = normalized.get("isVector")
    if is_vector is not None and "is_vector" not in normalized:
        normalized["is_vector"] = is_vector
        del normalized["isVector"]
    is_embedding = normalized.get("isEmbedding")
    if is_embedding is not None and "is_embedding" not in normalized:
        normalized["is_embedding"] = is_embedding
        del normalized["isEmbedding"]
    if "scalar_type" in normalized:
        normalized["scalar_type"] = _normalize_scalar_type_value(normalized["scalar_type"])
    return normalized


def _normalize_resource_summary_payload(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, dict):
        return {}
    normalized = dict(payload)
    if "kind" in normalized:
        normalized["kind"] = _normalize_enum_value(normalized["kind"], "RESOURCE_KIND_")
    return normalized


def _normalize_graph_detail_summary(
    summary_payload: Any,
    *,
    fallback_kind: str,
) -> dict[str, Any]:
    normalized = _normalize_resource_summary_payload(summary_payload)
    if not normalized.get("kind"):
        normalized["kind"] = fallback_kind
    if "variant" in normalized and "subtype" not in normalized:
        normalized["subtype"] = str(normalized["variant"])
    normalized.pop("variant", None)
    return normalized


def _normalize_resource_ref_payload(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, dict):
        return {}
    normalized = dict(payload)
    if "kind" in normalized:
        normalized["kind"] = _normalize_enum_value(normalized["kind"], "RESOURCE_KIND_")
    return normalized


def _normalize_realtime_reference_payload(payload: Any) -> Any:
    if payload is None:
        return None
    if not isinstance(payload, dict):
        return payload
    normalized: dict[str, Any] = {
        key: value for key, value in dict(payload).items() if value is not None and value != ""
    }
    if not normalized:
        return None
    if not normalized.get("feature_name"):
        return None
    return normalized


def _normalize_realtime_input_payload(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, dict):
        return {}
    normalized: dict[str, Any] = dict(payload)
    if "feature_ref" in normalized:
        feature_ref = _normalize_realtime_reference_payload(normalized["feature_ref"])
        if feature_ref is None:
            normalized.pop("feature_ref", None)
        else:
            normalized["feature_ref"] = feature_ref
    if "training_feature" in normalized:
        training_feature = _normalize_realtime_reference_payload(normalized["training_feature"])
        if training_feature is None:
            normalized.pop("training_feature", None)
        else:
            normalized["training_feature"] = training_feature
    return normalized


def _normalize_feature_resource_payload(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, dict):
        return {}
    normalized = dict(payload)
    if "value_type" in normalized:
        normalized["value_type"] = _normalize_value_type_payload(normalized["value_type"])
    return normalized


def _normalize_dataset_resource_payload(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, dict):
        return {}
    return dict(payload)


def _normalize_label_resource_payload(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, dict):
        return {}
    normalized = dict(payload)
    if "value_type" in normalized:
        normalized["value_type"] = _normalize_value_type_payload(normalized["value_type"])
    return normalized


def _normalize_training_set_resource_payload(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, dict):
        return {}
    return dict(payload)


def _normalize_planner_ir_payload(payload: Any) -> dict[str, Any] | None:
    if not isinstance(payload, dict):
        return None

    normalized = cast(dict[str, Any], dict(payload))
    items_value = normalized.get("items", [])
    items: list[dict[str, Any]] = []
    if isinstance(items_value, list):
        for item_value in items_value:
            if not isinstance(item_value, dict):
                continue
            item = cast(dict[str, Any], item_value)
            normalized_item: dict[str, Any] = {}
            for key in ("id", "graph_diff", "action", "reason", "current_id", "desired_id"):
                value = item.get(key)
                if isinstance(value, str) and value:
                    normalized_item[key] = value
            if normalized_item:
                items.append(normalized_item)
    normalized["items"] = items

    for order_key in ("reconcile_order", "delete_order"):
        value = normalized.get(order_key)
        normalized[order_key] = (
            [entry for entry in value if isinstance(entry, str)] if isinstance(value, list) else []
        )

    return normalized


def _normalize_graph_detail_payload(payload: dict[str, Any]) -> dict[str, Any]:
    if (
        "resource" in payload
        and isinstance(payload.get("resource"), dict)
        and "summary" in payload["resource"]
    ):
        detail = dict(cast(dict[str, Any], payload["resource"]))
        detail["version"] = payload.get("version", 0)
        payload = detail

    normalized = dict(payload)
    normalized["summary"] = _normalize_resource_summary_payload(normalized.get("summary"))
    normalized["sources"] = [
        _normalize_resource_ref_payload(item)
        for item in cast(list[Any], normalized.get("sources", []))
    ]
    normalized["consumers"] = [
        _normalize_resource_ref_payload(item)
        for item in cast(list[Any], normalized.get("consumers", []))
    ]
    return normalized


def _feature_resource_from_proto(resource: dict[str, Any]) -> dict[str, Any]:
    if "realtime_feature" in resource:
        realtime_payload = cast(dict[str, Any], resource["realtime_feature"])
        return {
            "name": realtime_payload.get("name", ""),
            "description": realtime_payload.get("description", ""),
            "variant": "REALTIME",
            "entity": realtime_payload.get("entity", ""),
            "provider": realtime_payload.get("provider", ""),
            "value_type": _normalize_value_type_payload(realtime_payload.get("value_type")),
            "realtime_feature": {
                "requirements": realtime_payload.get("requirements", []),
                "inputs": [
                    _normalize_realtime_input_payload(item)
                    for item in cast(list[Any], realtime_payload.get("inputs", []))
                ],
                "serialization_python_version": realtime_payload.get(
                    "serialization_python_version", ""
                ),
            },
        }

    feature_variants = {
        "batch_attribute_feature": "BATCH_ATTRIBUTE",
        "batch_aggregate_feature": "BATCH_AGGREGATE",
        "streaming_attribute_feature": "STREAMING_ATTRIBUTE",
        "streaming_aggregate_feature": "STREAMING_AGGREGATE",
    }
    for key, variant in feature_variants.items():
        if key in resource and isinstance(resource[key], dict):
            feature_payload = cast(dict[str, Any], resource[key])
            return {
                "name": feature_payload.get("name", ""),
                "description": feature_payload.get("description", ""),
                "variant": variant,
                "entity": feature_payload.get("entity", ""),
                "entity_column": feature_payload.get("entity_column", ""),
                "source_dataset": feature_payload.get("source_dataset", ""),
                "provider": feature_payload.get("provider", ""),
                "offline_store_provider": feature_payload.get("offline_store_provider", ""),
                "value_type": _normalize_value_type_payload(feature_payload.get("value_type")),
                "input_column": feature_payload.get("input_column", ""),
                "timestamp_column": feature_payload.get("timestamp_column", ""),
                "function": _normalize_enum_value(
                    feature_payload.get("function", ""), "AGGREGATE_FUNCTION_"
                ).upper(),
                "time_window": feature_payload.get("time_window", ""),
            }
    return {}


def _dataset_resource_from_proto(resource: dict[str, Any]) -> dict[str, Any]:
    resource_variants = {
        "primary_dataset": "PRIMARY",
        "iceberg_primary_dataset": "ICEBERG_PRIMARY",
        "spark_iceberg_transformed_dataset": "SPARK_ICEBERG_TRANSFORMED",
        "spark_iceberg_incremental_transformed_dataset": "SPARK_ICEBERG_INCREMENTAL",
        "postgres_transformed_dataset": "POSTGRES_TRANSFORMED",
        "postgres_incremental_transformed_dataset": "POSTGRES_INCREMENTAL",
    }
    for key, variant in resource_variants.items():
        if key not in resource or not isinstance(resource[key], dict):
            continue
        dataset_payload = cast(dict[str, Any], resource[key])
        normalized: dict[str, Any] = {
            "name": dataset_payload.get("name", ""),
            "description": dataset_payload.get("description", ""),
            "variant": variant,
            "provider": dataset_payload.get("provider", ""),
            "timestamp_column": dataset_payload.get("timestamp_column", ""),
            "query": dataset_payload.get("sql_query", ""),
            "source_datasets": dataset_payload.get("source_datasets", []),
            "incremental_sources": dataset_payload.get("incremental_sources", {}),
            "primary_key": dataset_payload.get("primary_key", []),
        }
        if "location" in dataset_payload and key == "primary_dataset":
            normalized["table_location"] = dataset_payload.get("location")
        if "location" in dataset_payload and key == "iceberg_primary_dataset":
            normalized["iceberg_location"] = dataset_payload.get("location")
        if "transform_job_config" in dataset_payload:
            normalized["transform_job_config"] = dataset_payload.get("transform_job_config")
        if "iceberg_config" in dataset_payload:
            normalized["iceberg_config"] = dataset_payload.get("iceberg_config")
        if "postgres_config" in dataset_payload:
            postgres_config = cast(dict[str, Any], dataset_payload["postgres_config"])
            normalized["table_location"] = {
                "database": "",
                "schema": postgres_config.get("schema", ""),
                "table": postgres_config.get("table", ""),
            }
        return normalized
    return {}


def _label_resource_from_proto(resource: dict[str, Any]) -> dict[str, Any]:
    label_payload = cast(dict[str, Any], resource.get("label", {}))
    return {
        "name": label_payload.get("name", ""),
        "description": label_payload.get("description", ""),
        "entities": label_payload.get("entities", []),
        "entity_fields": label_payload.get("entity_fields", []),
        "value_field": label_payload.get("value_field", ""),
        "timestamp_field": label_payload.get("timestamp_field", ""),
        "source_dataset": label_payload.get("source_dataset", ""),
        "provider": label_payload.get("provider", ""),
        "value_type": _normalize_value_type_payload(label_payload.get("value_type")),
    }


def _training_set_resource_from_proto(resource: dict[str, Any]) -> dict[str, Any]:
    training_payload = cast(dict[str, Any], resource.get("training_set", {}))
    return {
        "name": training_payload.get("name", ""),
        "description": training_payload.get("description", ""),
        "provider": training_payload.get("provider", ""),
        "features": training_payload.get("features", []),
        "label": training_payload.get("label", ""),
        "type": _normalize_enum_value(
            training_payload.get("type", ""), "TRAINING_SET_TYPE_"
        ).upper(),
        "feature_lags": training_payload.get("feature_lags", []),
        "compute_job_config": training_payload.get("compute_job_config"),
    }


def _feature_view_resource_from_proto(resource: dict[str, Any]) -> dict[str, Any]:
    feature_view_payload = cast(dict[str, Any], resource.get("feature_view", {}))
    return {
        "name": feature_view_payload.get("name", ""),
        "description": feature_view_payload.get("description", ""),
        "entity": feature_view_payload.get("entity", ""),
        "features": feature_view_payload.get("features", []),
        "provider": feature_view_payload.get("provider", ""),
        "inference_store": feature_view_payload.get("inference_store", ""),
        "materialization_engine": _normalize_enum_value(
            feature_view_payload.get("materialization_engine", ""),
            "MATERIALIZATION_ENGINE_",
        ).upper(),
        "spark_provider": feature_view_payload.get("spark_provider", ""),
        "join_strategy": _normalize_enum_value(
            feature_view_payload.get("join_strategy", ""),
            "JOIN_STRATEGY_",
        ).upper(),
        "materialize_job_config": feature_view_payload.get("materialize_job_config"),
    }


def _resource_detail_resource_from_proto(
    detail: dict[str, Any], resource_kind: str
) -> dict[str, Any]:
    resource = cast(dict[str, Any], detail.get("resource", {}))
    if resource_kind == "feature":
        return _feature_resource_from_proto(resource)
    if resource_kind == "dataset":
        return _dataset_resource_from_proto(resource)
    if resource_kind == "entity":
        entity_payload = cast(dict[str, Any], resource.get("entity", {}))
        return {
            "name": entity_payload.get("name", ""),
            "description": entity_payload.get("description", ""),
        }
    if resource_kind == "label":
        return _label_resource_from_proto(resource)
    if resource_kind == "training_set":
        return _training_set_resource_from_proto(resource)
    if resource_kind == "feature_view":
        return _feature_view_resource_from_proto(resource)
    return {}


def _provider_config_to_dict(config: ProviderConfig | dict[str, Any]) -> dict[str, Any]:
    if isinstance(config, dict):
        return {key: value for key, value in config.items() if value is not None}
    config_dict = config.model_dump(exclude_none=True, mode="json", by_alias=True)
    if isinstance(config, SparkProviderConfig):
        for key in (
            "catalogs",
            "backend",
            "hadoop",
            "staging",
            "driver_env",
            "executor_env",
            "runtime_profile",
            "execution_defaults",
            "dependencies",
            "advanced",
            "submission_defaults",
        ):
            if _is_empty_nested_config(config_dict.get(key)):
                config_dict.pop(key, None)
    return config_dict


def _spark_config_to_rest_payload(config_dict: dict[str, Any]) -> dict[str, Any]:
    normalized = dict(config_dict)

    advanced = normalized.get("advanced")
    advanced_spark_conf: dict[str, str] = {}
    if isinstance(advanced, dict):
        advanced_dict = cast(dict[str, Any], advanced)
        raw_advanced_spark_conf = advanced_dict.get("spark_conf")
        if isinstance(raw_advanced_spark_conf, dict):
            advanced_spark_conf = {
                str(key): str(value) for key, value in raw_advanced_spark_conf.items()
            }

    defaults: dict[str, Any] = {}
    for key in (
        "catalogs",
        "driver_env",
        "executor_env",
        "deploy_mode",
        "runtime_profile",
        "execution_defaults",
        "dependencies",
        "submission_defaults",
        "max_execution_time",
    ):
        value = normalized.pop(key, None)
        if value is not None:
            defaults[key] = value

    merged_spark_conf = dict(advanced_spark_conf)
    raw_spark_conf = normalized.pop("spark_conf", None)
    if isinstance(raw_spark_conf, dict):
        merged_spark_conf.update({str(key): str(value) for key, value in raw_spark_conf.items()})
    if merged_spark_conf:
        defaults["spark_conf"] = merged_spark_conf

    normalized.pop("advanced", None)
    if defaults:
        normalized["defaults"] = defaults
    return normalized


def _normalize_spark_provider_payload(config_dict: dict[str, Any]) -> dict[str, Any]:
    normalized = dict(config_dict)
    defaults = normalized.pop("defaults", None)
    if not isinstance(defaults, dict):
        return normalized

    flattened = dict(cast(dict[str, Any], defaults))
    for key, value in normalized.items():
        flattened[key] = value
    return flattened


def _is_empty_nested_config(value: Any) -> bool:
    if value is None:
        return True
    if isinstance(value, dict):
        return all(_is_empty_nested_config(item) for item in value.values())
    if isinstance(value, list):
        return len(value) == 0
    return False


def _provider_config_from_payload(
    provider_type: ProviderType,
    config: ProviderConfig | dict[str, Any],
) -> ProviderConfig:
    if not isinstance(config, dict):
        return config

    config_dict = dict(config)
    if provider_type == ProviderType.POSTGRES:
        return PostgresConfig.model_validate(config_dict)
    if provider_type == ProviderType.SNOWFLAKE:
        return SnowflakeConfig.model_validate(config_dict)
    if provider_type == ProviderType.S3:
        path_prefix = config_dict.pop("path_prefix", None)
        config_dict.pop("path", None)
        if config_dict.get("endpoint") == "":
            config_dict["endpoint"] = None
        if path_prefix:
            bucket = str(config_dict.get("bucket", ""))
            config_dict["bucket"] = f"s3://{bucket}/{str(path_prefix).lstrip('/')}"
        return S3Config.model_validate(config_dict)
    if provider_type == ProviderType.SPARK:
        config_dict = _normalize_spark_provider_payload(config_dict)
        return SparkProviderConfig.model_validate(config_dict)
    if provider_type == ProviderType.DYNAMODB:
        return DynamoDBConfig.model_validate(config_dict)
    if provider_type == ProviderType.REDIS:
        _normalize_redis_tls_payload(config_dict)
        return RedisConfig.model_validate(config_dict)
    if provider_type == ProviderType.REDIS_CLUSTER:
        _normalize_redis_tls_payload(config_dict)
        return RedisClusterConfig.model_validate(config_dict)
    if provider_type == ProviderType.KAFKA:
        return KafkaConfig.model_validate(config_dict)
    if provider_type == ProviderType.ICEBERG:
        return IcebergCatalogConfig.model_validate(config_dict)
    raise InvalidArgumentError(f"unsupported provider type for config parsing: {provider_type}")


def _normalize_redis_tls_payload(config_dict: dict[str, Any]) -> None:
    tls = config_dict.get("tls")
    if not isinstance(tls, dict):
        return
    tls_payload = cast(dict[str, Any], tls)

    for key in (
        "ca_cert_path",
        "ca_cert_secret",
        "server_name",
        "client_cert_path",
        "client_cert_secret",
        "client_key_path",
        "client_key_secret",
        "min_version",
    ):
        if tls_payload.get(key) == "":
            tls_payload[key] = None


def _secret_provider_config_from_payload(
    provider_type: SecretProviderType,
    config: SecretProviderConfig | dict[str, Any],
) -> SecretProviderConfig:
    if not isinstance(config, dict):
        return config

    config_dict = dict(config)
    if provider_type == SecretProviderType.ENV:
        return EnvSecretConfig.model_validate(config_dict)
    if provider_type == SecretProviderType.VAULT:
        return VaultSecretConfig.model_validate(config_dict)
    if provider_type == SecretProviderType.K8S:
        return KubernetesSecretConfig.model_validate(config_dict)
    if provider_type == SecretProviderType.AWS:
        return AWSSecretsManagerSecretConfig.model_validate(config_dict)
    raise InvalidArgumentError(
        f"unsupported secret provider type for config parsing: {provider_type}"
    )


def _parse_graph_resource_list(payload: dict[str, Any]) -> GraphResourceList:
    normalized = dict(payload)
    normalized["resources"] = [
        _normalize_resource_summary_payload(item)
        for item in cast(list[Any], normalized.get("resources", []))
    ]
    pagination = normalized.get("pagination")
    if isinstance(pagination, dict):
        normalized_pagination = dict(cast(dict[str, Any], pagination))
        if "total" not in normalized_pagination and "total_count" in normalized_pagination:
            total_count = normalized_pagination.pop("total_count")
            normalized_pagination["total"] = total_count
        normalized["pagination"] = normalized_pagination
    return GraphResourceList.model_validate(normalized)


def _parse_graph_feature_detail(payload: dict[str, Any]) -> GraphFeatureDetail:
    normalized = _normalize_graph_detail_payload(payload)
    normalized["summary"] = _normalize_graph_detail_summary(
        normalized.get("summary"), fallback_kind="feature"
    )
    if "variant" not in cast(dict[str, Any], normalized.get("resource", {})):
        normalized["resource"] = _resource_detail_resource_from_proto(
            normalized, normalized["summary"].get("kind", "")
        )
    normalized["resource"] = _normalize_feature_resource_payload(normalized.get("resource"))
    return GraphFeatureDetail.model_validate(normalized)


def _parse_graph_dataset_detail(payload: dict[str, Any]) -> GraphDatasetDetail:
    normalized = _normalize_graph_detail_payload(payload)
    normalized["summary"] = _normalize_graph_detail_summary(
        normalized.get("summary"), fallback_kind="dataset"
    )
    if "variant" not in cast(dict[str, Any], normalized.get("resource", {})):
        normalized["resource"] = _resource_detail_resource_from_proto(
            normalized, normalized["summary"].get("kind", "")
        )
    normalized["resource"] = _normalize_dataset_resource_payload(normalized.get("resource"))
    return GraphDatasetDetail.model_validate(normalized)


def _parse_graph_entity_detail(payload: dict[str, Any]) -> GraphEntityDetail:
    normalized = _normalize_graph_detail_payload(payload)
    normalized["summary"] = _normalize_graph_detail_summary(
        normalized.get("summary"), fallback_kind="entity"
    )
    if "name" not in cast(dict[str, Any], normalized.get("resource", {})):
        normalized["resource"] = _resource_detail_resource_from_proto(
            normalized, normalized["summary"].get("kind", "")
        )
    return GraphEntityDetail.model_validate(normalized)


def _parse_graph_label_detail(payload: dict[str, Any]) -> GraphLabelDetail:
    normalized = _normalize_graph_detail_payload(payload)
    normalized["summary"] = _normalize_graph_detail_summary(
        normalized.get("summary"), fallback_kind="label"
    )
    if "name" not in cast(dict[str, Any], normalized.get("resource", {})):
        normalized["resource"] = _resource_detail_resource_from_proto(
            normalized, normalized["summary"].get("kind", "")
        )
    normalized["resource"] = _normalize_label_resource_payload(normalized.get("resource"))
    return GraphLabelDetail.model_validate(normalized)


def _parse_graph_training_set_detail(payload: dict[str, Any]) -> GraphTrainingSetDetail:
    normalized = _normalize_graph_detail_payload(payload)
    normalized["summary"] = _normalize_graph_detail_summary(
        normalized.get("summary"), fallback_kind="training_set"
    )
    if "type" not in cast(dict[str, Any], normalized.get("resource", {})):
        normalized["resource"] = _resource_detail_resource_from_proto(
            normalized, normalized["summary"].get("kind", "")
        )
    normalized["resource"] = _normalize_training_set_resource_payload(normalized.get("resource"))
    return GraphTrainingSetDetail.model_validate(normalized)


def _parse_graph_feature_view_detail(payload: dict[str, Any]) -> GraphFeatureViewDetail:
    normalized = _normalize_graph_detail_payload(payload)
    normalized["summary"] = _normalize_graph_detail_summary(
        normalized.get("summary"), fallback_kind="feature_view"
    )
    if "entity" not in cast(dict[str, Any], normalized.get("resource", {})):
        normalized["resource"] = _resource_detail_resource_from_proto(
            normalized, normalized["summary"].get("kind", "")
        )
    return GraphFeatureViewDetail.model_validate(normalized)


def _parse_graph_relationship_result(payload: dict[str, Any]) -> GraphRelationshipResult:
    normalized = dict(payload)
    normalized["resource"] = _normalize_resource_ref_payload(normalized.get("resource"))
    normalized["related"] = [
        _normalize_resource_ref_payload(item)
        for item in cast(list[Any], normalized.get("related", []))
    ]
    return GraphRelationshipResult.model_validate(normalized)


def _parse_graph_pipeline_result(payload: dict[str, Any]) -> GraphPipelineResult:
    normalized = dict(payload)
    normalized["resource"] = _normalize_resource_ref_payload(normalized.get("resource"))
    steps: list[dict[str, Any]] = []
    for item in cast(list[Any], normalized.get("steps", [])):
        if isinstance(item, dict):
            step: dict[str, Any] = dict(item)
            if "kind" in step:
                step["kind"] = _normalize_enum_value(step["kind"], "RESOURCE_KIND_")
            steps.append(step)
    normalized["steps"] = steps
    return GraphPipelineResult.model_validate(normalized)


def _parse_graph_lineage_result(payload: dict[str, Any]) -> GraphLineageResult:
    normalized = dict(payload)
    normalized["nodes"] = [
        {
            **cast(dict[str, Any], item),
            "kind": _normalize_enum_value(cast(dict[str, Any], item).get("kind"), "RESOURCE_KIND_"),
        }
        for item in cast(list[Any], normalized.get("nodes", []))
        if isinstance(item, dict)
    ]
    return GraphLineageResult.model_validate(normalized)


def _parse_graph_workspace_overview(payload: dict[str, Any]) -> GraphWorkspaceOverview:
    normalized = dict(payload.get("overview", payload))
    return GraphWorkspaceOverview.model_validate(normalized)


def _parse_graph_workspace_stats(payload: dict[str, Any]) -> GraphWorkspaceStats:
    normalized = dict(payload.get("stats", payload))
    return GraphWorkspaceStats.model_validate(normalized)


def _parse_graph_version_summary(payload: dict[str, Any]) -> GraphVersionSummary:
    return GraphVersionSummary.model_validate(payload)


def _parse_graph_version_diff(payload: dict[str, Any]) -> GraphVersionDiff:
    def normalize_changes(items: Any) -> list[dict[str, Any]]:
        normalized_items: list[dict[str, Any]] = []
        for item in cast(list[Any], items or []):
            if not isinstance(item, dict):
                continue
            normalized: dict[str, Any] = dict(item)
            normalized["kind"] = _normalize_enum_value(normalized.get("kind"), "RESOURCE_KIND_")
            normalized["change_type"] = _normalize_enum_value(
                normalized.get("change_type"), "CHANGE_TYPE_"
            )
            normalized_items.append(normalized)
        return normalized_items

    normalized = dict(payload)
    normalized["added"] = normalize_changes(normalized.get("added"))
    normalized["modified"] = normalize_changes(normalized.get("modified"))
    normalized["deleted"] = normalize_changes(normalized.get("deleted"))
    return GraphVersionDiff.model_validate(normalized)


def _parse_graph_resource_history(payload: dict[str, Any]) -> GraphResourceHistory:
    normalized = dict(payload)
    entries: list[dict[str, Any]] = []
    for item in cast(list[Any], normalized.get("entries", [])):
        if not isinstance(item, dict):
            continue
        entry: dict[str, Any] = dict(item)
        entry["change_type"] = _normalize_enum_value(entry.get("change_type"), "CHANGE_TYPE_")
        entries.append(entry)
    normalized["entries"] = entries
    return GraphResourceHistory.model_validate(normalized)


def _split_patch_config(
    config: ProviderConfig | dict[str, Any],
) -> tuple[dict[str, Any], list[str]]:
    if not isinstance(config, dict):
        clear_fields_from_model: list[str] = []
        explicit_fields: set[str] = set(getattr(config, "model_fields_set", set()))
        model_fields: dict[str, Any] = getattr(type(config), "model_fields", {})
        for field_name, field_info in model_fields.items():
            if field_name not in explicit_fields:
                continue
            if getattr(config, field_name) is not None:
                continue
            clear_fields_from_model.append(field_info.alias or field_name)
        return _provider_config_to_dict(config), clear_fields_from_model

    patch_config: dict[str, Any] = {}
    clear_fields_from_dict: list[str] = []
    for key, value in config.items():
        if value is CLEAR:
            clear_fields_from_dict.append(key)
            continue
        if value is None:
            continue
        patch_config[key] = value
    return patch_config, clear_fields_from_dict


class SecretProviderHandle:
    """Handle for interacting with a registered secret provider.

    This class wraps a SecretProvider and provides a convenient API
    for getting secret references.

    Example:
        >>> env = client.secrets()
        >>> password = env.get("PG_PASSWORD")
        >>> print(password)  # EnvSecretRef(kind='env', name='PG_PASSWORD')
    """

    def __init__(self, provider: SecretProvider) -> None:
        """Create a handle from a SecretProvider.

        Args:
            provider: The underlying SecretProvider.
        """
        self._provider = provider

    @property
    def name(self) -> str:
        """The secret provider name."""
        return self._provider.name

    @property
    def type(self) -> SecretProviderType:
        """The secret provider type."""
        return self._provider.type

    @property
    def workspace_id(self) -> UUID:
        """The workspace ID this provider belongs to."""
        return self._provider.workspace_id

    def get(self, name: str | None = None, *, key: str | None = None) -> SecretRef:
        """Get a secret reference from this provider.

        Args:
            name: The secret name (env var name, vault path, k8s secret name, AWS secret ID).
                AWS secret providers may omit this to use the provider's configured default secret.
            key: Optional key for vault, k8s, and AWS secrets with multiple fields.

        Returns:
            A typed secret reference (not the actual value - resolved by server).

        Example:
            >>> env = client.secrets()
            >>> password = env.get("PG_PASSWORD")
            >>>
            >>> vault = client.secrets("vault")
            >>> api_key = vault.get("api/stripe", key="secret_key")
        """
        if self._provider.type == SecretProviderType.ENV:
            if not name:
                raise ValueError("Env secret refs require a name")
            provider_name = None if self._provider.name == "env" else self._provider.name
            return EnvSecretRef(name=name, provider_name=provider_name)
        if self._provider.type == SecretProviderType.VAULT:
            if not name:
                raise ValueError("Vault secret refs require a path")
            if not key:
                raise ValueError("Vault secret refs require a key")
            return VaultSecretRef(provider_name=self._provider.name, path=name, key=key)
        if self._provider.type == SecretProviderType.K8S:
            if not name:
                raise ValueError("K8s secret refs require a name")
            if not key:
                raise ValueError("K8s secret refs require a key")
            return K8sSecretRef(provider_name=self._provider.name, name=name, key=key)
        if self._provider.type == SecretProviderType.AWS:
            return AWSSecretRef(
                provider_name=self._provider.name,
                secret_id=name or None,
                key=key,
            )
        raise TypeError(f"Unsupported secret provider type: {self._provider.type}")


_SECRET_REF_ADAPTER: TypeAdapter[SecretRef] = TypeAdapter(SecretRef)


def _config_secret_ref(value: Any) -> SecretRef | None:
    """Normalize config secret values into typed secret refs."""
    if value is None:
        return None
    if isinstance(
        value,
        (
            EnvSecretRef,
            VaultSecretRef,
            K8sSecretRef,
            AWSSecretRef,
            GCPSecretRef,
            AzureSecretRef,
        ),
    ):
        return value
    if isinstance(value, dict):
        return _SECRET_REF_ADAPTER.validate_python(value)
    raise TypeError(f"Unsupported secret config value: {type(value).__name__}")


def _secret_ref_to_dict(value: Any) -> dict[str, Any] | None:
    secret_ref = _config_secret_ref(value)
    if secret_ref is None:
        return None
    return secret_ref.model_dump(mode="json", exclude_none=True)


def _secret_ref_to_proto(value: Any, provider_pb2: Any) -> Any:
    secret_ref = _config_secret_ref(value)
    if secret_ref is None:
        return None
    if isinstance(secret_ref, EnvSecretRef):
        env_payload: dict[str, Any] = {"name": secret_ref.name}
        if secret_ref.provider_name is not None:
            env_payload["provider_name"] = secret_ref.provider_name
        return provider_pb2.SecretRef(env=provider_pb2.EnvSecretRef(**env_payload))
    if isinstance(secret_ref, VaultSecretRef):
        vault_payload: dict[str, Any] = {
            "provider_name": secret_ref.provider_name,
            "path": secret_ref.path,
            "key": secret_ref.key,
        }
        return provider_pb2.SecretRef(vault=provider_pb2.VaultSecretRef(**vault_payload))
    if isinstance(secret_ref, K8sSecretRef):
        k8s_payload = {
            "provider_name": secret_ref.provider_name,
            "name": secret_ref.name,
            "key": secret_ref.key,
        }
        return provider_pb2.SecretRef(k8s=provider_pb2.K8sSecretRef(**k8s_payload))
    if isinstance(secret_ref, AWSSecretRef):
        aws_payload: dict[str, Any] = {
            "provider_name": secret_ref.provider_name,
        }
        if secret_ref.secret_id is not None:
            aws_payload["secret_id"] = secret_ref.secret_id
        if secret_ref.region is not None:
            aws_payload["region"] = secret_ref.region
        if secret_ref.key is not None:
            aws_payload["key"] = secret_ref.key
        if secret_ref.version_id is not None:
            aws_payload["version_id"] = secret_ref.version_id
        if secret_ref.version_stage is not None:
            aws_payload["version_stage"] = secret_ref.version_stage
        return provider_pb2.SecretRef(aws=provider_pb2.AWSSecretRef(**aws_payload))
    if isinstance(secret_ref, GCPSecretRef):
        gcp_payload = {
            "provider_name": secret_ref.provider_name,
            "name": secret_ref.name,
        }
        if secret_ref.project is not None:
            gcp_payload["project"] = secret_ref.project
        if secret_ref.version is not None:
            gcp_payload["version"] = secret_ref.version
        if secret_ref.key is not None:
            gcp_payload["key"] = secret_ref.key
        return provider_pb2.SecretRef(gcp=provider_pb2.GCPSecretRef(**gcp_payload))
    azure_payload = {
        "provider_name": secret_ref.provider_name,
        "name": secret_ref.name,
    }
    if secret_ref.vault_url is not None:
        azure_payload["vault_url"] = secret_ref.vault_url
    if secret_ref.version is not None:
        azure_payload["version"] = secret_ref.version
    if secret_ref.key is not None:
        azure_payload["key"] = secret_ref.key
    return provider_pb2.SecretRef(azure=provider_pb2.AzureSecretRef(**azure_payload))


def _secret_ref_from_proto(value: Any) -> SecretRef | None:
    if value is None:
        return None
    variant = value.WhichOneof("ref")
    if variant == "env":
        provider_name = value.env.provider_name or None
        return EnvSecretRef(name=value.env.name, provider_name=provider_name)
    if variant == "vault":
        return VaultSecretRef(
            provider_name=value.vault.provider_name,
            path=value.vault.path,
            key=value.vault.key,
        )
    if variant == "k8s":
        return K8sSecretRef(
            provider_name=value.k8s.provider_name,
            name=value.k8s.name,
            key=value.k8s.key,
        )
    if variant == "aws":
        return AWSSecretRef(
            provider_name=value.aws.provider_name,
            secret_id=value.aws.secret_id or None,
            region=value.aws.region or None,
            key=value.aws.key or None,
            version_id=value.aws.version_id or None,
            version_stage=value.aws.version_stage or None,
        )
    if variant == "gcp":
        return GCPSecretRef(
            provider_name=value.gcp.provider_name,
            name=value.gcp.name,
            project=value.gcp.project or None,
            version=value.gcp.version or None,
            key=value.gcp.key or None,
        )
    if variant == "azure":
        return AzureSecretRef(
            provider_name=value.azure.provider_name,
            name=value.azure.name,
            vault_url=value.azure.vault_url or None,
            version=value.azure.version or None,
            key=value.azure.key or None,
        )
    return None


def _spark_backend_from_proto(value: Any) -> Any | None:
    if value is None:
        return None
    from featureform.types.provider import SparkProviderConfig

    if value.HasField("local"):
        return SparkProviderConfig.SparkBackend(
            local=SparkProviderConfig.SparkLocalBackend(master=value.local.master or None)
        )
    if value.HasField("standalone"):
        return SparkProviderConfig.SparkBackend(
            standalone=SparkProviderConfig.SparkStandaloneBackend(
                master=value.standalone.master or None
            )
        )
    if value.HasField("yarn"):
        return SparkProviderConfig.SparkBackend(
            yarn=SparkProviderConfig.SparkYarnBackend(
                master=value.yarn.master or None,
                queue=value.yarn.config.queue or None,
                proxy_user=value.yarn.config.proxy_user or None,
            )
        )
    if value.HasField("k8s"):
        return SparkProviderConfig.SparkBackend(
            k8s=SparkProviderConfig.SparkK8sBackend(
                api_server=value.k8s.api_server or None,
                image=value.k8s.config.image or None,
                namespace=value.k8s.config.namespace or None,
                service_account=value.k8s.config.service_account or None,
                executor_request_cores=value.k8s.config.executor_request_cores or None,
                executor_limit_cores=value.k8s.config.executor_limit_cores or None,
                executor_pod_env=dict(value.k8s.config.executor_pod_env),
                driver_secrets=dict(value.k8s.config.driver_secrets),
                executor_secrets=dict(value.k8s.config.executor_secrets),
                executor_secret_key_refs=[
                    SparkProviderConfig.SparkK8sSecretKeyRef(
                        env_var=item.env_var or None,
                        name=item.name or None,
                        key=item.key or None,
                    )
                    for item in value.k8s.config.executor_secret_key_refs
                ],
            )
        )
    return None


def _redis_tls_to_proto(tls: Any | None, provider_pb2_module: Any) -> Any | None:
    if tls is None:
        return None
    mode = getattr(getattr(tls, "mode", None), "value", getattr(tls, "mode", ""))
    return provider_pb2_module.RedisTLSConfig(
        mode=mode,
        ca_cert_path=getattr(tls, "ca_cert_path", None) or "",
        ca_cert_secret=_secret_ref_or_string_to_string(getattr(tls, "ca_cert_secret", None)),
        server_name=getattr(tls, "server_name", None) or "",
        client_cert_path=getattr(tls, "client_cert_path", None) or "",
        client_cert_secret=_secret_ref_or_string_to_string(
            getattr(tls, "client_cert_secret", None)
        ),
        client_key_path=getattr(tls, "client_key_path", None) or "",
        client_key_secret=_secret_ref_or_string_to_string(getattr(tls, "client_key_secret", None)),
        insecure_skip_verify=bool(getattr(tls, "insecure_skip_verify", False)),
        min_version=getattr(tls, "min_version", None) or "",
    )


def _secret_ref_or_string_to_string(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    return secret_ref_to_string(value) or ""


def _redis_tls_dict_to_proto(config: dict[str, Any], provider_pb2_module: Any) -> Any | None:
    tls = config.get("tls")
    if not isinstance(tls, dict):
        return None
    tls_dict = cast(dict[str, Any], tls)
    return provider_pb2_module.RedisTLSConfig(
        mode=str(tls_dict.get("mode") or ""),
        ca_cert_path=str(tls_dict.get("ca_cert_path") or ""),
        ca_cert_secret=_secret_ref_or_string_to_string(
            tls_dict.get("ca_cert_secret") or tls_dict.get("ca_cert")
        ),
        server_name=str(tls_dict.get("server_name") or ""),
        client_cert_path=str(tls_dict.get("client_cert_path") or ""),
        client_cert_secret=_secret_ref_or_string_to_string(
            tls_dict.get("client_cert_secret") or tls_dict.get("client_cert")
        ),
        client_key_path=str(tls_dict.get("client_key_path") or ""),
        client_key_secret=_secret_ref_or_string_to_string(
            tls_dict.get("client_key_secret") or tls_dict.get("client_key")
        ),
        insecure_skip_verify=bool(tls_dict.get("insecure_skip_verify", False)),
        min_version=str(tls_dict.get("min_version") or ""),
    )


def _iceberg_catalog_patch_dict_to_proto(config: dict[str, Any], provider_pb2_module: Any) -> Any:
    iceberg_config = provider_pb2_module.IcebergCatalogConfig()

    backend = config.get("backend")
    if isinstance(backend, dict):
        backend_dict = cast(dict[str, Any], backend)
        if isinstance(backend_dict.get("hive"), dict):
            hive_dict = cast(dict[str, Any], backend_dict["hive"])
            iceberg_config.backend.hive.CopyFrom(
                provider_pb2_module.IcebergHiveConfig(uri=str(hive_dict.get("uri") or ""))
            )
        if isinstance(backend_dict.get("rest"), dict):
            rest_dict = cast(dict[str, Any], backend_dict["rest"])
            rest_config = provider_pb2_module.IcebergRESTConfig(
                uri=str(rest_dict.get("uri") or ""),
                prefix=str(rest_dict.get("prefix") or ""),
            )
            if "credential" in rest_dict:
                credential = _secret_ref_to_proto(rest_dict["credential"], provider_pb2_module)
                if credential is not None:
                    rest_config.credential_secret.CopyFrom(credential)
            iceberg_config.backend.rest.CopyFrom(rest_config)
        if isinstance(backend_dict.get("glue"), dict):
            glue_dict = cast(dict[str, Any], backend_dict["glue"])
            iceberg_config.backend.glue.CopyFrom(
                provider_pb2_module.IcebergGlueConfig(
                    region=str(glue_dict.get("region") or ""),
                    catalog_id=str(glue_dict.get("catalog_id") or ""),
                )
            )
        if isinstance(backend_dict.get("sql"), dict):
            sql_dict = cast(dict[str, Any], backend_dict["sql"])
            sql_config = provider_pb2_module.IcebergSQLConfig(
                driver=str(sql_dict.get("driver") or "")
            )
            if "connection_string" in sql_dict:
                connection_string = _secret_ref_to_proto(
                    sql_dict["connection_string"], provider_pb2_module
                )
                if connection_string is not None:
                    sql_config.connection_string_secret.CopyFrom(connection_string)
            iceberg_config.backend.sql.CopyFrom(sql_config)

    warehouse = config.get("warehouse")
    if isinstance(warehouse, dict):
        warehouse_dict = cast(dict[str, Any], warehouse)
        if isinstance(warehouse_dict.get("s3"), dict):
            s3_dict = cast(dict[str, Any], warehouse_dict["s3"])
            iceberg_config.warehouse.s3.provider = str(s3_dict.get("provider") or "")
            iceberg_config.warehouse.s3.prefix = str(s3_dict.get("prefix") or "")
        if isinstance(warehouse_dict.get("hdfs"), dict):
            hdfs_dict = cast(dict[str, Any], warehouse_dict["hdfs"])
            iceberg_config.warehouse.hdfs.provider = str(hdfs_dict.get("provider") or "")
            iceberg_config.warehouse.hdfs.path = str(hdfs_dict.get("path") or "")

    return iceberg_config


def _redis_tls_from_proto(proto_tls: Any) -> dict[str, Any] | None:
    if proto_tls is None:
        return None
    mode = str(getattr(proto_tls, "mode", "") or "")
    ca_cert_path = str(getattr(proto_tls, "ca_cert_path", "") or "")
    ca_cert_secret = str(getattr(proto_tls, "ca_cert_secret", "") or "")
    server_name = str(getattr(proto_tls, "server_name", "") or "")
    client_cert_path = str(getattr(proto_tls, "client_cert_path", "") or "")
    client_cert_secret = str(getattr(proto_tls, "client_cert_secret", "") or "")
    client_key_path = str(getattr(proto_tls, "client_key_path", "") or "")
    client_key_secret = str(getattr(proto_tls, "client_key_secret", "") or "")
    min_version = str(getattr(proto_tls, "min_version", "") or "")
    insecure_skip_verify = bool(getattr(proto_tls, "insecure_skip_verify", False))

    if not any(
        [
            mode,
            ca_cert_path,
            ca_cert_secret,
            server_name,
            client_cert_path,
            client_cert_secret,
            client_key_path,
            client_key_secret,
            min_version,
            insecure_skip_verify,
        ]
    ):
        return None

    return {
        "mode": mode,
        "ca_cert_path": ca_cert_path or None,
        "ca_cert_secret": ca_cert_secret or None,
        "server_name": server_name or None,
        "client_cert_path": client_cert_path or None,
        "client_cert_secret": client_cert_secret or None,
        "client_key_path": client_key_path or None,
        "client_key_secret": client_key_secret or None,
        "insecure_skip_verify": insecure_skip_verify,
        "min_version": min_version or None,
    }


def _require_json_object(value: Any, *, field_name: str) -> dict[str, Any]:
    """Validate that a JSON value is an object and narrow its type."""
    if not isinstance(value, dict):
        raise RuntimeError(f"{field_name} must be a JSON object")
    return cast(dict[str, Any], value)


def _proto_to_dataframe_resolution(proto_resolution: Any) -> dict[str, Any]:
    """Convert a dataframe resolution protobuf into the REST-shaped dict payload."""
    resolution: dict[str, Any] = {
        "workspace_id": str(getattr(proto_resolution, "workspace_id", "")),
        "dataset": str(getattr(proto_resolution, "dataset", "")),
        "provider_name": str(getattr(proto_resolution, "provider_name", "")),
        "provider_kind": str(getattr(proto_resolution, "provider_kind", "")),
        "status": str(getattr(proto_resolution, "status", "")),
    }

    pushdown = getattr(proto_resolution, "pushdown", None)
    if pushdown is not None:
        pushdown_payload: dict[str, Any] = {}
        columns = list(getattr(pushdown, "columns", []))
        if columns:
            pushdown_payload["columns"] = [str(column) for column in columns]
        filter_value = str(getattr(pushdown, "filter", ""))
        if filter_value:
            pushdown_payload["filter"] = filter_value
        limit_value = int(getattr(pushdown, "limit", 0))
        if limit_value > 0:
            pushdown_payload["limit"] = limit_value
        if pushdown_payload:
            resolution["pushdown"] = pushdown_payload

    sql_table = getattr(proto_resolution, "sql_table", None)
    if sql_table is not None and hasattr(sql_table, "table") and sql_table.table:
        resolution["sql_table"] = {
            "database": str(getattr(sql_table, "database", "")),
            "schema": str(getattr(sql_table, "schema", "")),
            "table": str(sql_table.table),
        }

    iceberg_table = getattr(proto_resolution, "iceberg_table", None)
    if iceberg_table is not None and hasattr(iceberg_table, "table") and iceberg_table.table:
        resolution["iceberg_table"] = {
            "catalog": str(getattr(iceberg_table, "catalog", "")),
            "namespace": str(getattr(iceberg_table, "namespace", "")),
            "table": str(iceberg_table.table),
        }

    plan_payload: dict[str, Any] = {}
    plan = getattr(proto_resolution, "plan", None)
    if plan is not None:
        spark_jdbc = getattr(plan, "spark_jdbc", None)
        if spark_jdbc is not None and hasattr(spark_jdbc, "format") and spark_jdbc.format:
            plan_payload["spark_jdbc"] = {
                "format": str(spark_jdbc.format),
                "url": str(getattr(spark_jdbc, "url", "")),
                "dbtable": str(getattr(spark_jdbc, "dbtable", "")),
                "driver": str(getattr(spark_jdbc, "driver", "")),
                "options": {
                    str(key): str(value)
                    for key, value in dict(getattr(spark_jdbc, "options", {})).items()
                },
            }

        spark_iceberg = getattr(plan, "spark_iceberg", None)
        if (
            spark_iceberg is not None
            and hasattr(spark_iceberg, "catalog_name")
            and spark_iceberg.catalog_name
        ):
            plan_payload["spark_iceberg"] = {
                "catalog_name": str(spark_iceberg.catalog_name),
                "table_identifier": str(getattr(spark_iceberg, "table_identifier", "")),
                "spark_conf": {
                    str(key): str(value)
                    for key, value in dict(getattr(spark_iceberg, "spark_conf", {})).items()
                },
            }

        flight_plan = getattr(plan, "flight", None)
        if flight_plan is not None and hasattr(flight_plan, "address") and flight_plan.address:
            plan_payload["flight"] = {
                "address": str(flight_plan.address),
                "ticket": str(getattr(flight_plan, "ticket", "")),
                "tls_enabled": bool(getattr(flight_plan, "tls_enabled", False)),
            }

    resolution["plan"] = plan_payload

    fallback_flight = getattr(proto_resolution, "fallback_flight", None)
    if (
        fallback_flight is not None
        and hasattr(fallback_flight, "address")
        and fallback_flight.address
    ):
        resolution["fallback_flight"] = {
            "address": str(fallback_flight.address),
            "ticket": str(getattr(fallback_flight, "ticket", "")),
            "tls_enabled": bool(getattr(fallback_flight, "tls_enabled", False)),
        }

    return resolution


def _resource_to_json(resource: Any) -> dict[str, Any]:
    """Convert a resource object into the REST apply JSON shape."""
    resource_type = getattr(resource, "resource_type", None)
    if resource_type is not None:
        type_name = str(resource_type)
    else:
        type_name = type(resource).__name__
        normalized: list[str] = []
        for index, char in enumerate(type_name):
            if char.isupper() and index > 0:
                normalized.append("_")
            normalized.append(char.lower())
        type_name = "".join(normalized)

    spec = cast(dict[str, Any], resource.model_dump(by_alias=True))
    if "name" not in spec:
        resource_name = getattr(resource, "name", None)
        if resource_name is not None:
            spec["name"] = resource_name
    return {"type": type_name, "spec": spec}


class ResourceChange(BaseModel):
    """A single resource change from apply."""

    resource_type: str
    resource_name: str
    action: str  # "create", "update", "delete", "unchanged"
    diff: str = ""

    model_config = ConfigDict(frozen=True)


class ApplyResult(BaseModel):
    """Result of an apply operation."""

    version: int
    base_version: int | None = None
    apply_strategy: str | None = None
    execution_mode: str | None = None
    no_changes: bool = False
    job_id: str | None = None
    planned_job: PlannedJob | None = None
    planner_ir: dict[str, Any] | None = None
    plan_error: str | None = None
    resources_created: int = 0
    resources_updated: int = 0
    resources_unchanged: int = 0
    changes: list[ResourceChange] = []

    model_config = ConfigDict(frozen=True)


class ApplyWaitResult(BaseModel):
    """Result of waiting for an apply operation to complete."""

    apply: ApplyResult
    job: dict[str, Any] | None = None

    model_config = ConfigDict(frozen=True)


class PlannedTask(BaseModel):
    """A single planned task returned from dry-run apply."""

    id: str
    type: str
    operation: str = "normal"
    resource_id: str | None = None
    resource_ids: list[str] = []
    depends_on: list[str] = []

    model_config = ConfigDict(frozen=True)


class PlannedJob(BaseModel):
    """A planned job returned from dry-run apply."""

    name: str
    tasks: list[PlannedTask] = []

    model_config = ConfigDict(frozen=True)


class PingResult(BaseModel):
    """Result of a connectivity and health probe."""

    ok: bool
    healthy: bool
    transport: str
    endpoint: str
    diagnosis: str
    detail: str | None = None
    server_status: str | None = None

    model_config = ConfigDict(frozen=True)


class GraphClientBase:
    """Base class for resource-graph query operations."""

    def overview(self) -> GraphWorkspaceOverview:
        """Get workspace overview."""
        raise NotImplementedError

    def stats(self, version: int | None = None) -> GraphWorkspaceStats:
        """Get workspace stats."""
        raise NotImplementedError

    def list_features(
        self,
        *,
        version: int | None = None,
        limit: int | None = None,
        offset: int | None = None,
        entity: str | None = None,
        provider: str | None = None,
        source_dataset: str | None = None,
        name_contains: str | None = None,
    ) -> GraphResourceList:
        """List features."""
        raise NotImplementedError

    def get_feature(self, name: str, *, version: int | None = None) -> GraphFeatureDetail:
        """Get feature details."""
        raise NotImplementedError

    def get_feature_sources(
        self, name: str, *, depth: int | None = None, version: int | None = None
    ) -> GraphRelationshipResult:
        """Get feature sources."""
        raise NotImplementedError

    def get_feature_consumers(
        self, name: str, *, depth: int | None = None, version: int | None = None
    ) -> GraphRelationshipResult:
        """Get feature consumers."""
        raise NotImplementedError

    def get_feature_pipeline(self, name: str, *, version: int | None = None) -> GraphPipelineResult:
        """Get feature pipeline."""
        raise NotImplementedError

    def list_datasets(
        self,
        *,
        version: int | None = None,
        limit: int | None = None,
        offset: int | None = None,
        provider: str | None = None,
        name_contains: str | None = None,
    ) -> GraphResourceList:
        """List datasets."""
        raise NotImplementedError

    def get_dataset(self, name: str, *, version: int | None = None) -> GraphDatasetDetail:
        """Get dataset details."""
        raise NotImplementedError

    def get_dataset_sources(
        self, name: str, *, depth: int | None = None, version: int | None = None
    ) -> GraphRelationshipResult:
        """Get dataset sources."""
        raise NotImplementedError

    def get_dataset_consumers(
        self, name: str, *, depth: int | None = None, version: int | None = None
    ) -> GraphRelationshipResult:
        """Get dataset consumers."""
        raise NotImplementedError

    def get_dataset_pipeline(self, name: str, *, version: int | None = None) -> GraphPipelineResult:
        """Get dataset pipeline."""
        raise NotImplementedError

    def list_entities(
        self,
        *,
        version: int | None = None,
        limit: int | None = None,
        offset: int | None = None,
        name_contains: str | None = None,
    ) -> GraphResourceList:
        """List entities."""
        raise NotImplementedError

    def get_entity(self, name: str, *, version: int | None = None) -> GraphEntityDetail:
        """Get entity details."""
        raise NotImplementedError

    def list_training_sets(
        self,
        *,
        version: int | None = None,
        limit: int | None = None,
        offset: int | None = None,
        provider: str | None = None,
        label: str | None = None,
        includes_feature: str | None = None,
        name_contains: str | None = None,
    ) -> GraphResourceList:
        """List training sets."""
        raise NotImplementedError

    def get_training_set(self, name: str, *, version: int | None = None) -> GraphTrainingSetDetail:
        """Get training set details."""
        raise NotImplementedError

    def get_training_set_sources(
        self, name: str, *, depth: int | None = None, version: int | None = None
    ) -> GraphRelationshipResult:
        """Get training set sources."""
        raise NotImplementedError

    def get_training_set_consumers(
        self, name: str, *, depth: int | None = None, version: int | None = None
    ) -> GraphRelationshipResult:
        """Get training set consumers."""
        raise NotImplementedError

    def get_training_set_pipeline(
        self, name: str, *, version: int | None = None
    ) -> GraphPipelineResult:
        """Get training set pipeline."""
        raise NotImplementedError

    def list_labels(
        self,
        *,
        version: int | None = None,
        limit: int | None = None,
        offset: int | None = None,
        provider: str | None = None,
        entity: str | None = None,
        source_dataset: str | None = None,
        name_contains: str | None = None,
    ) -> GraphResourceList:
        """List labels."""
        raise NotImplementedError

    def get_label(self, name: str, *, version: int | None = None) -> GraphLabelDetail:
        """Get label details."""
        raise NotImplementedError

    def get_label_sources(
        self, name: str, *, depth: int | None = None, version: int | None = None
    ) -> GraphRelationshipResult:
        """Get label sources."""
        raise NotImplementedError

    def get_label_consumers(
        self, name: str, *, depth: int | None = None, version: int | None = None
    ) -> GraphRelationshipResult:
        """Get label consumers."""
        raise NotImplementedError

    def get_label_pipeline(self, name: str, *, version: int | None = None) -> GraphPipelineResult:
        """Get label pipeline."""
        raise NotImplementedError

    def list_feature_views(
        self,
        *,
        version: int | None = None,
        limit: int | None = None,
        offset: int | None = None,
        entity: str | None = None,
        includes_feature: str | None = None,
        inference_store: str | None = None,
        materialization_engine: str | None = None,
        spark_provider: str | None = None,
        name_contains: str | None = None,
    ) -> GraphResourceList:
        """List feature views."""
        raise NotImplementedError

    def get_feature_view(self, name: str, *, version: int | None = None) -> GraphFeatureViewDetail:
        """Get feature view details."""
        raise NotImplementedError

    def get_feature_view_sources(
        self, name: str, *, depth: int | None = None, version: int | None = None
    ) -> GraphRelationshipResult:
        """Get feature view sources."""
        raise NotImplementedError

    def get_feature_view_consumers(
        self, name: str, *, depth: int | None = None, version: int | None = None
    ) -> GraphRelationshipResult:
        """Get feature view consumers."""
        raise NotImplementedError

    def get_feature_view_pipeline(
        self, name: str, *, version: int | None = None
    ) -> GraphPipelineResult:
        """Get feature view pipeline."""
        raise NotImplementedError

    def get_resources_by_provider(
        self, provider: str, *, version: int | None = None
    ) -> GraphResourceList:
        """Get resources using a provider."""
        raise NotImplementedError

    def search(
        self,
        query: str,
        *,
        version: int | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> GraphResourceList:
        """Search resources."""
        raise NotImplementedError

    def lineage(
        self,
        name: str,
        *,
        upstream_depth: int | None = None,
        downstream_depth: int | None = None,
        version: int | None = None,
    ) -> GraphLineageResult:
        """Get lineage graph."""
        raise NotImplementedError

    def impact(
        self, names: list[str], *, depth: int | None = None, version: int | None = None
    ) -> GraphLineageResult:
        """Get impact graph."""
        raise NotImplementedError

    def list_versions(self) -> list[GraphVersionSummary]:
        """List committed versions."""
        raise NotImplementedError

    def get_version(self, version: int) -> GraphVersionSummary:
        """Get a committed version."""
        raise NotImplementedError

    def diff_versions(self, from_version: int, to_version: int) -> GraphVersionDiff:
        """Diff two committed versions."""
        raise NotImplementedError

    def resource_history(self, name: str) -> GraphResourceHistory:
        """Get resource history."""
        raise NotImplementedError


def _clean_params(params: dict[str, Any]) -> dict[str, Any]:
    """Remove unset query/request values while preserving falsy integers."""
    return {key: value for key, value in params.items() if value is not None}


class RESTGraphClient(GraphClientBase):
    """REST client for resource-graph query operations."""

    def __init__(self, transport: RESTTransport, workspace_id: UUID) -> None:
        self._transport = transport
        self._workspace_id = workspace_id
        self._logger = get_logger("featureform.client.graph.rest")

    def _get(self, path: str, **params: Any) -> dict[str, Any]:
        response = self._transport.get(path, params=_clean_params(params))
        return dict(response.data or {})

    def overview(self) -> GraphWorkspaceOverview:
        return _parse_graph_workspace_overview(
            self._get(f"/api/v1/workspaces/{self._workspace_id}/summary")
        )

    def stats(self, version: int | None = None) -> GraphWorkspaceStats:
        return _parse_graph_workspace_stats(
            self._get(f"/api/v1/workspaces/{self._workspace_id}/stats", version=version)
        )

    def list_features(self, **kwargs: Any) -> GraphResourceList:
        return _parse_graph_resource_list(
            self._get(f"/api/v1/workspaces/{self._workspace_id}/features", **kwargs)
        )

    def get_feature(self, name: str, *, version: int | None = None) -> GraphFeatureDetail:
        return _parse_graph_feature_detail(
            self._get(f"/api/v1/workspaces/{self._workspace_id}/features/{name}", version=version)
        )

    def get_feature_sources(
        self, name: str, *, depth: int | None = None, version: int | None = None
    ) -> GraphRelationshipResult:
        return _parse_graph_relationship_result(
            self._get(
                f"/api/v1/workspaces/{self._workspace_id}/features/{name}/sources",
                depth=depth,
                version=version,
            )
        )

    def get_feature_consumers(
        self, name: str, *, depth: int | None = None, version: int | None = None
    ) -> GraphRelationshipResult:
        return _parse_graph_relationship_result(
            self._get(
                f"/api/v1/workspaces/{self._workspace_id}/features/{name}/consumers",
                depth=depth,
                version=version,
            )
        )

    def get_feature_pipeline(self, name: str, *, version: int | None = None) -> GraphPipelineResult:
        return _parse_graph_pipeline_result(
            self._get(
                f"/api/v1/workspaces/{self._workspace_id}/features/{name}/pipeline",
                version=version,
            )
        )

    def list_datasets(self, **kwargs: Any) -> GraphResourceList:
        return _parse_graph_resource_list(
            self._get(f"/api/v1/workspaces/{self._workspace_id}/datasets", **kwargs)
        )

    def get_dataset(self, name: str, *, version: int | None = None) -> GraphDatasetDetail:
        return _parse_graph_dataset_detail(
            self._get(f"/api/v1/workspaces/{self._workspace_id}/datasets/{name}", version=version)
        )

    def get_dataset_sources(
        self, name: str, *, depth: int | None = None, version: int | None = None
    ) -> GraphRelationshipResult:
        return _parse_graph_relationship_result(
            self._get(
                f"/api/v1/workspaces/{self._workspace_id}/datasets/{name}/sources",
                depth=depth,
                version=version,
            )
        )

    def get_dataset_consumers(
        self, name: str, *, depth: int | None = None, version: int | None = None
    ) -> GraphRelationshipResult:
        return _parse_graph_relationship_result(
            self._get(
                f"/api/v1/workspaces/{self._workspace_id}/datasets/{name}/consumers",
                depth=depth,
                version=version,
            )
        )

    def get_dataset_pipeline(self, name: str, *, version: int | None = None) -> GraphPipelineResult:
        return _parse_graph_pipeline_result(
            self._get(
                f"/api/v1/workspaces/{self._workspace_id}/datasets/{name}/pipeline",
                version=version,
            )
        )

    def list_entities(self, **kwargs: Any) -> GraphResourceList:
        return _parse_graph_resource_list(
            self._get(f"/api/v1/workspaces/{self._workspace_id}/entities", **kwargs)
        )

    def get_entity(self, name: str, *, version: int | None = None) -> GraphEntityDetail:
        return _parse_graph_entity_detail(
            self._get(f"/api/v1/workspaces/{self._workspace_id}/entities/{name}", version=version)
        )

    def list_training_sets(self, **kwargs: Any) -> GraphResourceList:
        return _parse_graph_resource_list(
            self._get(f"/api/v1/workspaces/{self._workspace_id}/training-sets", **kwargs)
        )

    def get_training_set(self, name: str, *, version: int | None = None) -> GraphTrainingSetDetail:
        return _parse_graph_training_set_detail(
            self._get(
                f"/api/v1/workspaces/{self._workspace_id}/training-sets/{name}",
                version=version,
            )
        )

    def get_training_set_sources(
        self, name: str, *, depth: int | None = None, version: int | None = None
    ) -> GraphRelationshipResult:
        return _parse_graph_relationship_result(
            self._get(
                f"/api/v1/workspaces/{self._workspace_id}/training-sets/{name}/sources",
                depth=depth,
                version=version,
            )
        )

    def get_training_set_consumers(
        self, name: str, *, depth: int | None = None, version: int | None = None
    ) -> GraphRelationshipResult:
        return _parse_graph_relationship_result(
            self._get(
                f"/api/v1/workspaces/{self._workspace_id}/training-sets/{name}/consumers",
                depth=depth,
                version=version,
            )
        )

    def get_training_set_pipeline(
        self, name: str, *, version: int | None = None
    ) -> GraphPipelineResult:
        return _parse_graph_pipeline_result(
            self._get(
                f"/api/v1/workspaces/{self._workspace_id}/training-sets/{name}/pipeline",
                version=version,
            )
        )

    def list_labels(self, **kwargs: Any) -> GraphResourceList:
        return _parse_graph_resource_list(
            self._get(f"/api/v1/workspaces/{self._workspace_id}/labels", **kwargs)
        )

    def get_label(self, name: str, *, version: int | None = None) -> GraphLabelDetail:
        return _parse_graph_label_detail(
            self._get(f"/api/v1/workspaces/{self._workspace_id}/labels/{name}", version=version)
        )

    def get_label_sources(
        self, name: str, *, depth: int | None = None, version: int | None = None
    ) -> GraphRelationshipResult:
        return _parse_graph_relationship_result(
            self._get(
                f"/api/v1/workspaces/{self._workspace_id}/labels/{name}/sources",
                depth=depth,
                version=version,
            )
        )

    def get_label_consumers(
        self, name: str, *, depth: int | None = None, version: int | None = None
    ) -> GraphRelationshipResult:
        return _parse_graph_relationship_result(
            self._get(
                f"/api/v1/workspaces/{self._workspace_id}/labels/{name}/consumers",
                depth=depth,
                version=version,
            )
        )

    def get_label_pipeline(self, name: str, *, version: int | None = None) -> GraphPipelineResult:
        return _parse_graph_pipeline_result(
            self._get(
                f"/api/v1/workspaces/{self._workspace_id}/labels/{name}/pipeline",
                version=version,
            )
        )

    def list_feature_views(self, **kwargs: Any) -> GraphResourceList:
        return _parse_graph_resource_list(
            self._get(f"/api/v1/workspaces/{self._workspace_id}/feature-views", **kwargs)
        )

    def get_feature_view(self, name: str, *, version: int | None = None) -> GraphFeatureViewDetail:
        return _parse_graph_feature_view_detail(
            self._get(
                f"/api/v1/workspaces/{self._workspace_id}/feature-views/{name}",
                version=version,
            )
        )

    def get_feature_view_sources(
        self, name: str, *, depth: int | None = None, version: int | None = None
    ) -> GraphRelationshipResult:
        return _parse_graph_relationship_result(
            self._get(
                f"/api/v1/workspaces/{self._workspace_id}/feature-views/{name}/sources",
                depth=depth,
                version=version,
            )
        )

    def get_feature_view_consumers(
        self, name: str, *, depth: int | None = None, version: int | None = None
    ) -> GraphRelationshipResult:
        return _parse_graph_relationship_result(
            self._get(
                f"/api/v1/workspaces/{self._workspace_id}/feature-views/{name}/consumers",
                depth=depth,
                version=version,
            )
        )

    def get_feature_view_pipeline(
        self, name: str, *, version: int | None = None
    ) -> GraphPipelineResult:
        return _parse_graph_pipeline_result(
            self._get(
                f"/api/v1/workspaces/{self._workspace_id}/feature-views/{name}/pipeline",
                version=version,
            )
        )

    def get_resources_by_provider(
        self, provider: str, *, version: int | None = None
    ) -> GraphResourceList:
        return _parse_graph_resource_list(
            self._get(
                f"/api/v1/workspaces/{self._workspace_id}/providers/{provider}/resources",
                version=version,
            )
        )

    def search(
        self,
        query: str,
        *,
        version: int | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> GraphResourceList:
        return _parse_graph_resource_list(
            self._get(
                f"/api/v1/workspaces/{self._workspace_id}/resources",
                query=query,
                version=version,
                limit=limit,
                offset=offset,
            )
        )

    def lineage(
        self,
        name: str,
        *,
        upstream_depth: int | None = None,
        downstream_depth: int | None = None,
        version: int | None = None,
    ) -> GraphLineageResult:
        return _parse_graph_lineage_result(
            self._get(
                f"/api/v1/workspaces/{self._workspace_id}/resources/{name}/lineage",
                upstream_depth=upstream_depth,
                downstream_depth=downstream_depth,
                version=version,
            )
        )

    def impact(
        self, names: list[str], *, depth: int | None = None, version: int | None = None
    ) -> GraphLineageResult:
        if len(names) != 1:
            raise InvalidArgumentError("impact currently requires exactly one resource name")
        return _parse_graph_lineage_result(
            self._get(
                f"/api/v1/workspaces/{self._workspace_id}/resources/{names[0]}/impact",
                depth=depth,
                version=version,
            )
        )

    def list_versions(self) -> list[GraphVersionSummary]:
        response = self._get(f"/api/v1/workspaces/{self._workspace_id}/versions")
        return [_parse_graph_version_summary(item) for item in response.get("versions", [])]

    def get_version(self, version: int) -> GraphVersionSummary:
        response = self._get(f"/api/v1/workspaces/{self._workspace_id}/versions/{version}")
        return _parse_graph_version_summary(dict(response.get("version", response)))

    def diff_versions(self, from_version: int, to_version: int) -> GraphVersionDiff:
        return _parse_graph_version_diff(
            self._get(
                f"/api/v1/workspaces/{self._workspace_id}/versions/{to_version}/diff",
                base=from_version,
            )
        )

    def resource_history(self, name: str) -> GraphResourceHistory:
        return _parse_graph_resource_history(
            self._get(f"/api/v1/workspaces/{self._workspace_id}/resources/{name}/history")
        )


class GRPCGraphClient(GraphClientBase):
    """gRPC client for resource-graph query operations."""

    _DETAIL_RESPONSE_KEYS = {
        "GetFeature": "feature",
        "GetDataset": "dataset",
        "GetEntity": "entity",
        "GetTrainingSet": "training_set",
        "GetLabel": "label",
        "GetFeatureView": "feature_view",
    }

    def __init__(self, transport: GRPCTransport, workspace_id: UUID) -> None:
        self._transport = transport
        self._workspace_id = workspace_id
        self._logger = get_logger("featureform.client.graph.grpc")

    def _modules(self) -> tuple[Any, Any]:
        from featureform._generated.proto.featureform.v2 import common_pb2, resource_service_pb2

        return common_pb2, resource_service_pb2

    def _message_to_dict(self, message: Any) -> dict[str, Any]:
        from google.protobuf.json_format import MessageToDict

        return MessageToDict(
            message,
            preserving_proto_field_name=True,
            use_integers_for_enums=False,
            always_print_fields_with_no_presence=True,
        )

    def _build_request(self, request_name: str, **fields: Any) -> Any:
        common_pb2, resource_service_pb2 = self._modules()
        request_type = getattr(resource_service_pb2, request_name)
        payload = dict(fields)
        payload["workspace_id"] = str(self._workspace_id)

        version = payload.pop("version", None)
        if version is not None:
            payload["at_version"] = resource_service_pb2.AtVersion(version=version)

        limit = payload.pop("limit", None)
        offset = payload.pop("offset", None)
        if limit is not None or offset is not None:
            payload["pagination"] = common_pb2.PaginationRequest(
                limit=limit or 0, offset=offset or 0
            )

        return request_type(**_clean_params(payload))

    def _call(self, method: str, request_name: str, **fields: Any) -> dict[str, Any]:
        request = self._build_request(request_name, **fields)
        response = getattr(self._transport.resource, method)(request)
        payload = self._message_to_dict(response)
        detail_key = self._DETAIL_RESPONSE_KEYS.get(method)
        if detail_key is None:
            return payload
        detail_payload = payload.get(detail_key)
        if not isinstance(detail_payload, dict):
            raise RuntimeError(f"{method} response missing '{detail_key}' payload")
        return detail_payload

    def overview(self) -> GraphWorkspaceOverview:
        return _parse_graph_workspace_overview(
            self._call("GetWorkspaceOverview", "GetWorkspaceOverviewRequest")
        )

    def stats(self, version: int | None = None) -> GraphWorkspaceStats:
        return _parse_graph_workspace_stats(
            self._call("GetWorkspaceStats", "GetWorkspaceStatsRequest", version=version)
        )

    def list_features(self, **kwargs: Any) -> GraphResourceList:
        return _parse_graph_resource_list(
            self._call("ListFeatures", "ListFeaturesRequest", **kwargs)
        )

    def get_feature(self, name: str, *, version: int | None = None) -> GraphFeatureDetail:
        return _parse_graph_feature_detail(
            self._call("GetFeature", "GetFeatureRequest", name=name, version=version)
        )

    def get_feature_sources(
        self, name: str, *, depth: int | None = None, version: int | None = None
    ) -> GraphRelationshipResult:
        return _parse_graph_relationship_result(
            self._call(
                "GetFeatureSources",
                "GetFeatureSourcesRequest",
                name=name,
                depth=depth,
                version=version,
            )
        )

    def get_feature_consumers(
        self, name: str, *, depth: int | None = None, version: int | None = None
    ) -> GraphRelationshipResult:
        return _parse_graph_relationship_result(
            self._call(
                "GetFeatureConsumers",
                "GetFeatureConsumersRequest",
                name=name,
                depth=depth,
                version=version,
            )
        )

    def get_feature_pipeline(self, name: str, *, version: int | None = None) -> GraphPipelineResult:
        return _parse_graph_pipeline_result(
            self._call(
                "GetFeaturePipeline", "GetFeaturePipelineRequest", name=name, version=version
            )
        )

    def list_datasets(self, **kwargs: Any) -> GraphResourceList:
        return _parse_graph_resource_list(
            self._call("ListDatasets", "ListDatasetsRequest", **kwargs)
        )

    def get_dataset(self, name: str, *, version: int | None = None) -> GraphDatasetDetail:
        return _parse_graph_dataset_detail(
            self._call("GetDataset", "GetDatasetRequest", name=name, version=version)
        )

    def get_dataset_sources(
        self, name: str, *, depth: int | None = None, version: int | None = None
    ) -> GraphRelationshipResult:
        return _parse_graph_relationship_result(
            self._call(
                "GetDatasetSources",
                "GetDatasetSourcesRequest",
                name=name,
                depth=depth,
                version=version,
            )
        )

    def get_dataset_consumers(
        self, name: str, *, depth: int | None = None, version: int | None = None
    ) -> GraphRelationshipResult:
        return _parse_graph_relationship_result(
            self._call(
                "GetDatasetConsumers",
                "GetDatasetConsumersRequest",
                name=name,
                depth=depth,
                version=version,
            )
        )

    def get_dataset_pipeline(self, name: str, *, version: int | None = None) -> GraphPipelineResult:
        return _parse_graph_pipeline_result(
            self._call(
                "GetDatasetPipeline", "GetDatasetPipelineRequest", name=name, version=version
            )
        )

    def list_entities(self, **kwargs: Any) -> GraphResourceList:
        return _parse_graph_resource_list(
            self._call("ListEntities", "ListEntitiesRequest", **kwargs)
        )

    def get_entity(self, name: str, *, version: int | None = None) -> GraphEntityDetail:
        return _parse_graph_entity_detail(
            self._call("GetEntity", "GetEntityRequest", name=name, version=version)
        )

    def list_training_sets(self, **kwargs: Any) -> GraphResourceList:
        return _parse_graph_resource_list(
            self._call("ListTrainingSets", "ListTrainingSetsRequest", **kwargs)
        )

    def get_training_set(self, name: str, *, version: int | None = None) -> GraphTrainingSetDetail:
        return _parse_graph_training_set_detail(
            self._call("GetTrainingSet", "GetTrainingSetRequest", name=name, version=version)
        )

    def get_training_set_sources(
        self, name: str, *, depth: int | None = None, version: int | None = None
    ) -> GraphRelationshipResult:
        return _parse_graph_relationship_result(
            self._call(
                "GetTrainingSetSources",
                "GetTrainingSetSourcesRequest",
                name=name,
                depth=depth,
                version=version,
            )
        )

    def get_training_set_consumers(
        self, name: str, *, depth: int | None = None, version: int | None = None
    ) -> GraphRelationshipResult:
        return _parse_graph_relationship_result(
            self._call(
                "GetTrainingSetConsumers",
                "GetTrainingSetConsumersRequest",
                name=name,
                depth=depth,
                version=version,
            )
        )

    def get_training_set_pipeline(
        self, name: str, *, version: int | None = None
    ) -> GraphPipelineResult:
        return _parse_graph_pipeline_result(
            self._call(
                "GetTrainingSetPipeline",
                "GetTrainingSetPipelineRequest",
                name=name,
                version=version,
            )
        )

    def list_labels(self, **kwargs: Any) -> GraphResourceList:
        return _parse_graph_resource_list(self._call("ListLabels", "ListLabelsRequest", **kwargs))

    def get_label(self, name: str, *, version: int | None = None) -> GraphLabelDetail:
        return _parse_graph_label_detail(
            self._call("GetLabel", "GetLabelRequest", name=name, version=version)
        )

    def get_label_sources(
        self, name: str, *, depth: int | None = None, version: int | None = None
    ) -> GraphRelationshipResult:
        return _parse_graph_relationship_result(
            self._call(
                "GetLabelSources",
                "GetLabelSourcesRequest",
                name=name,
                depth=depth,
                version=version,
            )
        )

    def get_label_consumers(
        self, name: str, *, depth: int | None = None, version: int | None = None
    ) -> GraphRelationshipResult:
        return _parse_graph_relationship_result(
            self._call(
                "GetLabelConsumers",
                "GetLabelConsumersRequest",
                name=name,
                depth=depth,
                version=version,
            )
        )

    def get_label_pipeline(self, name: str, *, version: int | None = None) -> GraphPipelineResult:
        return _parse_graph_pipeline_result(
            self._call("GetLabelPipeline", "GetLabelPipelineRequest", name=name, version=version)
        )

    def list_feature_views(self, **kwargs: Any) -> GraphResourceList:
        return _parse_graph_resource_list(
            self._call("ListFeatureViews", "ListFeatureViewsRequest", **kwargs)
        )

    def get_feature_view(self, name: str, *, version: int | None = None) -> GraphFeatureViewDetail:
        return _parse_graph_feature_view_detail(
            self._call("GetFeatureView", "GetFeatureViewRequest", name=name, version=version)
        )

    def get_feature_view_sources(
        self, name: str, *, depth: int | None = None, version: int | None = None
    ) -> GraphRelationshipResult:
        return _parse_graph_relationship_result(
            self._call(
                "GetFeatureViewSources",
                "GetFeatureViewSourcesRequest",
                name=name,
                depth=depth,
                version=version,
            )
        )

    def get_feature_view_consumers(
        self, name: str, *, depth: int | None = None, version: int | None = None
    ) -> GraphRelationshipResult:
        return _parse_graph_relationship_result(
            self._call(
                "GetFeatureViewConsumers",
                "GetFeatureViewConsumersRequest",
                name=name,
                depth=depth,
                version=version,
            )
        )

    def get_feature_view_pipeline(
        self, name: str, *, version: int | None = None
    ) -> GraphPipelineResult:
        return _parse_graph_pipeline_result(
            self._call(
                "GetFeatureViewPipeline",
                "GetFeatureViewPipelineRequest",
                name=name,
                version=version,
            )
        )

    def get_resources_by_provider(
        self, provider: str, *, version: int | None = None
    ) -> GraphResourceList:
        return _parse_graph_resource_list(
            self._call(
                "GetResourcesByProvider",
                "GetResourcesByProviderRequest",
                provider=provider,
                version=version,
            )
        )

    def search(
        self,
        query: str,
        *,
        version: int | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> GraphResourceList:
        return _parse_graph_resource_list(
            self._call(
                "Search",
                "SearchRequest",
                query=query,
                version=version,
                limit=limit,
                offset=offset,
            )
        )

    def lineage(
        self,
        name: str,
        *,
        upstream_depth: int | None = None,
        downstream_depth: int | None = None,
        version: int | None = None,
    ) -> GraphLineageResult:
        return _parse_graph_lineage_result(
            self._call(
                "GetLineage",
                "GetLineageRequest",
                name=name,
                upstream_depth=upstream_depth,
                downstream_depth=downstream_depth,
                version=version,
            )
        )

    def impact(
        self, names: list[str], *, depth: int | None = None, version: int | None = None
    ) -> GraphLineageResult:
        return _parse_graph_lineage_result(
            self._call(
                "GetImpact",
                "GetImpactRequest",
                names=names,
                depth=depth,
                version=version,
            )
        )

    def list_versions(self) -> list[GraphVersionSummary]:
        response = self._call("ListVersions", "ListVersionsRequest")
        return [_parse_graph_version_summary(item) for item in response.get("versions", [])]

    def get_version(self, version: int) -> GraphVersionSummary:
        response = self._call(
            "GetVersion",
            "GetResourceServiceVersionRequest",
            version=version,
        )
        return _parse_graph_version_summary(dict(response.get("version", response)))

    def diff_versions(self, from_version: int, to_version: int) -> GraphVersionDiff:
        return _parse_graph_version_diff(
            self._call(
                "DiffVersions",
                "DiffVersionsRequest",
                from_version=from_version,
                to_version=to_version,
            )
        )

    def resource_history(self, name: str) -> GraphResourceHistory:
        return _parse_graph_resource_history(
            self._call("GetResourceHistory", "GetResourceHistoryRequest", name=name)
        )


class WorkspaceClientBase:
    """Base class for workspace client operations."""

    def create(
        self,
        name: str,
        description: str | None = None,
    ) -> Workspace:
        """Create a new workspace."""
        raise NotImplementedError

    def get(self, workspace_id: str | UUID) -> Workspace:
        """Get a workspace by ID."""
        raise NotImplementedError

    def get_by_name(self, name: str) -> Workspace:
        """Get a workspace by name."""
        raise NotImplementedError

    def list(self) -> list[Workspace]:
        """List all workspaces."""
        raise NotImplementedError

    def update(
        self,
        workspace_id: str | UUID,
        name: str,
        description: str | None = None,
    ) -> Workspace:
        """Update a workspace."""
        raise NotImplementedError

    def delete(self, workspace_id: str | UUID) -> None:
        """Delete a workspace."""
        raise NotImplementedError


class CatalogClientBase:
    """Base class for catalog client operations."""

    def list(self, provider: str | None = None) -> list[CatalogLocation]:
        """List catalog locations in the workspace."""
        raise NotImplementedError

    def get(self, resource_name: str) -> CatalogLocation:
        """Get a catalog location by resource name."""
        raise NotImplementedError


class WorkspaceClient(WorkspaceClientBase):
    """REST client for workspace operations."""

    def __init__(self, transport: RESTTransport) -> None:
        """Initialize workspace client."""
        self._transport = transport
        self._logger = get_logger("featureform.client.workspace")

    def create(
        self,
        name: str,
        description: str | None = None,
    ) -> Workspace:
        """Create a new workspace.

        Args:
            name: Workspace name.
            description: Optional description.

        Returns:
            Created workspace.
        """
        self._logger.debug("workspace_create_start", name=name)
        request = CreateWorkspaceRequest(name=name, description=description)
        response = self._transport.post(
            "/api/v1/workspaces",
            json=request.model_dump(exclude_none=True),
        )
        workspace = self._parse_workspace(response)
        self._logger.debug("workspace_create_complete", workspace_id=str(workspace.id))
        return workspace

    def get(self, workspace_id: str | UUID) -> Workspace:
        """Get a workspace by ID.

        Args:
            workspace_id: Workspace ID.

        Returns:
            Workspace.
        """
        self._logger.debug("workspace_get", workspace_id=str(workspace_id))
        response = self._transport.get(f"/api/v1/workspaces/{workspace_id}")
        return self._parse_workspace(response)

    def get_by_name(self, name: str) -> Workspace:
        """Get a workspace by name.

        Args:
            name: Workspace name.

        Returns:
            Workspace.
        """
        self._logger.debug("workspace_get_by_name", name=name)
        response = self._transport.get("/api/v1/workspaces", params={"name": name})
        workspaces = response.data.get("workspaces", [])
        if not workspaces:
            raise NotFoundError(f"workspace {name!r} not found")
        return Workspace.model_validate(workspaces[0])

    def list(self) -> list[Workspace]:
        """List all workspaces.

        Returns:
            List of workspaces.
        """
        self._logger.debug("workspace_list")
        response = self._transport.get("/api/v1/workspaces")
        workspaces_data = response.data.get("workspaces", [])
        return [Workspace.model_validate(ws) for ws in workspaces_data]

    def update(
        self,
        workspace_id: str | UUID,
        name: str,
        description: str | None = None,
    ) -> Workspace:
        """Update a workspace.

        Args:
            workspace_id: Workspace ID.
            name: New name (required by server).
            description: New description (optional).

        Returns:
            Updated workspace.
        """
        self._logger.debug("workspace_update", workspace_id=str(workspace_id))
        request = UpdateWorkspaceRequest(name=name, description=description)
        response = self._transport.put(
            f"/api/v1/workspaces/{workspace_id}",
            json=request.model_dump(exclude_none=True),
        )
        return self._parse_workspace(response)

    def delete(self, workspace_id: str | UUID) -> None:
        """Delete a workspace.

        Args:
            workspace_id: Workspace ID.
        """
        self._logger.debug("workspace_delete", workspace_id=str(workspace_id))
        self._transport.delete(f"/api/v1/workspaces/{workspace_id}")

    def _parse_workspace(self, response: Response) -> Workspace:
        """Parse workspace from response."""
        workspace_data = response.data.get("workspace", response.data)
        return Workspace.model_validate(workspace_data)


class GRPCWorkspaceClient(WorkspaceClientBase):
    """gRPC client for workspace operations."""

    def __init__(self, transport: GRPCTransport) -> None:
        """Initialize gRPC workspace client."""
        self._transport = transport
        self._logger = get_logger("featureform.client.workspace.grpc")

    def create(
        self,
        name: str,
        description: str | None = None,
    ) -> Workspace:
        """Create a new workspace via gRPC."""
        import grpc

        from featureform.transport.grpc import grpc_error_to_exception, workspace_pb2

        self._logger.debug("workspace_create_start", name=name)
        request = workspace_pb2.CreateWorkspaceRequest(
            name=name,
            description=description or "",
        )
        try:
            response = self._transport.workspace.CreateWorkspace(request)
            workspace = self._proto_to_workspace(response.workspace)
            self._logger.debug("workspace_create_complete", workspace_id=str(workspace.id))
            return workspace
        except grpc.RpcError as e:
            raise grpc_error_to_exception(e) from e

    def get(self, workspace_id: str | UUID) -> Workspace:
        """Get a workspace by ID via gRPC."""
        import grpc

        from featureform.transport.grpc import grpc_error_to_exception, workspace_pb2

        self._logger.debug("workspace_get", workspace_id=str(workspace_id))
        request = workspace_pb2.GetWorkspaceRequest(id=str(workspace_id))
        try:
            response = self._transport.workspace.GetWorkspace(request)
            return self._proto_to_workspace(response.workspace)
        except grpc.RpcError as e:
            raise grpc_error_to_exception(e) from e

    def get_by_name(self, name: str) -> Workspace:
        """Get a workspace by name via gRPC."""
        import grpc

        from featureform.transport.grpc import grpc_error_to_exception, workspace_pb2

        self._logger.debug("workspace_get_by_name", name=name)
        request = workspace_pb2.GetWorkspaceByNameRequest(name=name)
        try:
            response = self._transport.workspace.GetWorkspaceByName(request)
            return self._proto_to_workspace(response.workspace)
        except grpc.RpcError as e:
            raise grpc_error_to_exception(e) from e

    def list(self) -> list[Workspace]:
        """List all workspaces via gRPC."""
        import grpc

        from featureform.transport.grpc import grpc_error_to_exception, workspace_pb2

        self._logger.debug("workspace_list")
        request = workspace_pb2.ListWorkspacesRequest()
        try:
            response = self._transport.workspace.ListWorkspaces(request)
            return [self._proto_to_workspace(ws) for ws in response.workspaces]
        except grpc.RpcError as e:
            raise grpc_error_to_exception(e) from e

    def update(
        self,
        workspace_id: str | UUID,
        name: str,
        description: str | None = None,
    ) -> Workspace:
        """Update a workspace via gRPC."""
        import grpc

        from featureform.transport.grpc import grpc_error_to_exception, workspace_pb2

        self._logger.debug("workspace_update", workspace_id=str(workspace_id))
        request = workspace_pb2.UpdateWorkspaceRequest(
            id=str(workspace_id),
            name=name,
            description=description or "",
        )
        try:
            response = self._transport.workspace.UpdateWorkspace(request)
            return self._proto_to_workspace(response.workspace)
        except grpc.RpcError as e:
            raise grpc_error_to_exception(e) from e

    def delete(self, workspace_id: str | UUID) -> None:
        """Delete a workspace via gRPC."""
        import grpc

        from featureform.transport.grpc import grpc_error_to_exception, workspace_pb2

        self._logger.debug("workspace_delete", workspace_id=str(workspace_id))
        request = workspace_pb2.DeleteWorkspaceRequest(id=str(workspace_id))
        try:
            self._transport.workspace.DeleteWorkspace(request)
        except grpc.RpcError as e:
            raise grpc_error_to_exception(e) from e

    def _proto_to_workspace(self, proto_ws: workspace_pb2.Workspace) -> Workspace:
        """Convert proto workspace to Workspace model."""
        from datetime import datetime, timezone

        created_at = (
            datetime.fromtimestamp(
                proto_ws.created_at.seconds + proto_ws.created_at.nanos / 1e9,
                tz=timezone.utc,
            )
            if proto_ws.HasField("created_at")
            else datetime.now(timezone.utc)
        )

        updated_at = (
            datetime.fromtimestamp(
                proto_ws.updated_at.seconds + proto_ws.updated_at.nanos / 1e9,
                tz=timezone.utc,
            )
            if proto_ws.HasField("updated_at")
            else created_at
        )

        return Workspace(
            id=UUID(proto_ws.id),
            name=proto_ws.name,
            description=proto_ws.description,
            created_at=created_at,
            updated_at=updated_at,
            last_applied_version=proto_ws.last_applied_version,
        )


class CatalogClient(CatalogClientBase):
    """REST client for catalog operations."""

    def __init__(self, transport: RESTTransport, workspace_id: UUID) -> None:
        self._transport = transport
        self._workspace_id = workspace_id
        self._logger = get_logger("featureform.client.catalog")

    def list(self, provider: str | None = None) -> list[CatalogLocation]:
        """List catalog locations in the workspace."""
        self._logger.debug("catalog_list", workspace_id=str(self._workspace_id), provider=provider)
        params = {"provider": provider} if provider else None
        response = self._transport.get(
            f"/api/v1/workspaces/{self._workspace_id}/locations",
            params=params,
        )
        return [CatalogLocation.model_validate(loc) for loc in response.data.get("locations", [])]

    def get(self, resource_name: str) -> CatalogLocation:
        """Get a catalog location by resource name."""
        self._logger.debug(
            "catalog_get",
            workspace_id=str(self._workspace_id),
            resource_name=resource_name,
        )
        response = self._transport.get(
            f"/api/v1/workspaces/{self._workspace_id}/locations/{resource_name}"
        )
        return CatalogLocation.model_validate(response.data.get("location", response.data))


class GRPCCatalogClient(CatalogClientBase):
    """gRPC client for catalog operations."""

    def __init__(self, transport: GRPCTransport, workspace_id: UUID) -> None:
        self._transport = transport
        self._workspace_id = workspace_id
        self._logger = get_logger("featureform.client.catalog.grpc")

    def list(self, provider: str | None = None) -> list[CatalogLocation]:
        """List catalog locations in the workspace via gRPC."""
        import grpc

        from featureform.transport.grpc import catalog_pb2, grpc_error_to_exception

        self._logger.debug("catalog_list", workspace_id=str(self._workspace_id), provider=provider)
        try:
            if provider:
                return [
                    self._proto_to_catalog_location(loc)
                    for loc in self._transport.catalog.ListLocationsByProvider(
                        catalog_pb2.ListLocationsByProviderRequest(
                            workspace_id=str(self._workspace_id),
                            provider_name=provider,
                        )
                    ).locations
                ]
            return [
                self._proto_to_catalog_location(loc)
                for loc in self._transport.catalog.ListLocations(
                    catalog_pb2.ListLocationsRequest(workspace_id=str(self._workspace_id))
                ).locations
            ]
        except grpc.RpcError as e:
            raise grpc_error_to_exception(e) from e

    def get(self, resource_name: str) -> CatalogLocation:
        """Get a catalog location by resource name via gRPC."""
        import grpc

        from featureform.transport.grpc import catalog_pb2, grpc_error_to_exception

        self._logger.debug(
            "catalog_get",
            workspace_id=str(self._workspace_id),
            resource_name=resource_name,
        )
        try:
            response = self._transport.catalog.GetLocation(
                catalog_pb2.GetLocationRequest(
                    workspace_id=str(self._workspace_id),
                    resource_name=resource_name,
                )
            )
            return self._proto_to_catalog_location(response.location)
        except grpc.RpcError as e:
            raise grpc_error_to_exception(e) from e

    def _proto_to_catalog_location(self, proto_loc: Any) -> CatalogLocation:
        """Convert proto catalog location to CatalogLocation model."""
        from featureform.transport.grpc import catalog_pb2

        location_data: dict[str, str] = {"type": "unknown"}

        if proto_loc.HasField("table"):
            location_data = {
                "type": "table",
                "database": proto_loc.table.database,
                "schema": proto_loc.table.schema,
                "table": proto_loc.table.table,
            }
        elif proto_loc.HasField("iceberg"):
            location_data = {
                "type": "iceberg",
                "namespace": proto_loc.iceberg.namespace,
                "table": proto_loc.iceberg.table,
            }

        created_at = proto_loc.created_at.ToDatetime() if proto_loc.HasField("created_at") else None
        updated_at = proto_loc.updated_at.ToDatetime() if proto_loc.HasField("updated_at") else None
        status_name = catalog_pb2.CatalogLocationStatus.Name(proto_loc.status)
        ownership = "UNSPECIFIED"
        if hasattr(catalog_pb2, "CatalogLocationOwnership") and hasattr(proto_loc, "ownership"):
            ownership = catalog_pb2.CatalogLocationOwnership.Name(proto_loc.ownership).removeprefix(
                "CATALOG_LOCATION_OWNERSHIP_"
            )

        return CatalogLocation.model_validate(
            {
                "workspace_id": proto_loc.workspace_id,
                "resource_name": proto_loc.resource_name,
                "provider_name": proto_loc.provider_name,
                "ownership": ownership,
                "status": status_name.removeprefix("CATALOG_LOCATION_STATUS_"),
                "location": location_data,
                "inputs": list(proto_loc.inputs),
                "error_message": proto_loc.error_message,
                "created_at": created_at,
                "updated_at": updated_at,
            }
        )


class ProviderClientBase:
    """Base class for provider client operations."""

    def register(
        self,
        name: str,
        provider_type: ProviderType,
        config: ProviderConfig,
        skip_health_check: bool = False,
        disable_monitoring: bool = False,
    ) -> Provider:
        """Register a new provider."""
        raise NotImplementedError

    def get(self, name: str) -> Provider:
        """Get a provider by name."""
        raise NotImplementedError

    def list(self) -> list[Provider]:
        """List all providers in the workspace."""
        raise NotImplementedError

    def delete(self, name: str) -> None:
        """Delete a provider."""
        raise NotImplementedError

    def update(
        self,
        name: str,
        config: ProviderConfig | dict[str, Any],
        force: bool = False,
        skip_health_check: bool = False,
        disable_monitoring: bool = False,
        provider_type: ProviderType | None = None,
    ) -> Provider:
        """Update a provider."""
        raise NotImplementedError

    def register_redis(
        self,
        name: str,
        *,
        host: str,
        port: int = 6379,
        database: int = 0,
        password_secret: SecretRef | None = None,
        skip_health_check: bool = False,
        disable_monitoring: bool = False,
    ) -> Provider:
        """Register a standalone Redis provider."""
        from featureform.types.provider import RedisConfig

        return self.register(
            name=name,
            provider_type=ProviderType.REDIS,
            config=RedisConfig(
                host=host,
                port=port,
                database=database,
                password_secret=password_secret,
                tls=None,
            ),
            skip_health_check=skip_health_check,
            disable_monitoring=disable_monitoring,
        )

    def register_spark(
        self,
        name: str,
        *,
        catalogs: dict[str, str],
        backend: SparkProviderConfig.SparkBackend | dict[str, Any],
        deploy_mode: str | None = None,
        runtime_profile: SparkProviderConfig.SparkRuntimeProfile | dict[str, Any] | None = None,
        execution_defaults: SparkProviderConfig.SparkExecutionDefaults
        | dict[str, Any]
        | None = None,
        dependencies: SparkProviderConfig.SparkDependencyPolicy | dict[str, Any] | None = None,
        advanced: SparkProviderConfig.SparkAdvancedConfig | dict[str, Any] | None = None,
        submission_defaults: (
            SparkProviderConfig.SparkSubmissionDefaults | dict[str, Any] | None
        ) = None,
        spark_conf: dict[str, str] | None = None,
        max_execution_time: str | None = None,
        hadoop: SparkProviderConfig.SparkHadoopConfig | dict[str, Any] | None = None,
        staging: SparkProviderConfig.SparkStagingConfig | dict[str, Any] | None = None,
        driver_env: SparkProviderConfig.SparkEnv | dict[str, Any] | None = None,
        executor_env: SparkProviderConfig.SparkEnv | dict[str, Any] | None = None,
        skip_health_check: bool = False,
        disable_monitoring: bool = False,
        **extra_config_kwargs: Any,
    ) -> Provider:
        """Register a Spark provider."""
        from featureform.types.provider import SparkProviderConfig

        parsed_runtime_profile = (
            SparkProviderConfig.SparkRuntimeProfile.model_validate(runtime_profile)
            if isinstance(runtime_profile, dict)
            else runtime_profile
        )
        parsed_execution_defaults = (
            SparkProviderConfig.SparkExecutionDefaults.model_validate(execution_defaults)
            if isinstance(execution_defaults, dict)
            else execution_defaults
        )
        parsed_dependencies = (
            SparkProviderConfig.SparkDependencyPolicy.model_validate(dependencies)
            if isinstance(dependencies, dict)
            else dependencies
        )
        parsed_advanced = (
            SparkProviderConfig.SparkAdvancedConfig.model_validate(advanced)
            if isinstance(advanced, dict)
            else advanced
        )
        parsed_submission_defaults = (
            SparkProviderConfig.SparkSubmissionDefaults.model_validate(submission_defaults)
            if isinstance(submission_defaults, dict)
            else submission_defaults
        )
        parsed_driver_env = (
            SparkProviderConfig.SparkEnv.model_validate(driver_env)
            if isinstance(driver_env, dict)
            else driver_env
        )
        parsed_executor_env = (
            SparkProviderConfig.SparkEnv.model_validate(executor_env)
            if isinstance(executor_env, dict)
            else executor_env
        )
        parsed_backend = (
            SparkProviderConfig.SparkBackend.model_validate(backend)
            if isinstance(backend, dict)
            else backend
        )
        parsed_hadoop = (
            SparkProviderConfig.SparkHadoopConfig.model_validate(hadoop)
            if isinstance(hadoop, dict)
            else hadoop
        )
        parsed_staging = (
            SparkProviderConfig.SparkStagingConfig.model_validate(staging)
            if isinstance(staging, dict)
            else staging
        )
        config_kwargs: dict[str, Any] = {
            "catalogs": catalogs,
            "backend": parsed_backend,
            "deploy_mode": deploy_mode,
            "spark_conf": spark_conf or {},
            "max_execution_time": max_execution_time,
            "hadoop": parsed_hadoop,
            "staging": parsed_staging,
            "driver_env": parsed_driver_env or SparkProviderConfig.SparkEnv(),
            "executor_env": parsed_executor_env or SparkProviderConfig.SparkEnv(),
        }
        if parsed_runtime_profile is not None:
            config_kwargs["runtime_profile"] = parsed_runtime_profile
        if parsed_execution_defaults is not None:
            config_kwargs["execution_defaults"] = parsed_execution_defaults
        if parsed_dependencies is not None:
            config_kwargs["dependencies"] = parsed_dependencies
        if parsed_advanced is not None:
            config_kwargs["advanced"] = parsed_advanced
        if parsed_submission_defaults is not None:
            config_kwargs["submission_defaults"] = parsed_submission_defaults
        config_kwargs.update(extra_config_kwargs)

        return self.register(
            name=name,
            provider_type=ProviderType.SPARK,
            config=SparkProviderConfig.model_validate(config_kwargs),
            skip_health_check=skip_health_check,
            disable_monitoring=disable_monitoring,
        )

    def register_redis_cluster(
        self,
        name: str,
        *,
        endpoints: Sequence[str],
        password_secret: SecretRef | None = None,
        skip_health_check: bool = False,
        disable_monitoring: bool = False,
    ) -> Provider:
        """Register a Redis Cluster provider."""
        from featureform.types.provider import RedisClusterConfig

        return self.register(
            name=name,
            provider_type=ProviderType.REDIS_CLUSTER,
            config=RedisClusterConfig(
                endpoints=list(endpoints),
                password_secret=password_secret,
                tls=None,
            ),
            skip_health_check=skip_health_check,
            disable_monitoring=disable_monitoring,
        )


class ProviderClient(ProviderClientBase):
    """REST client for provider operations."""

    def __init__(self, transport: RESTTransport, workspace_id: UUID) -> None:
        """Initialize provider client."""
        self._transport = transport
        self._workspace_id = workspace_id
        self._logger = get_logger("featureform.client.provider")

    def register(
        self,
        name: str,
        provider_type: ProviderType,
        config: ProviderConfig,
        skip_health_check: bool = False,
        disable_monitoring: bool = False,
    ) -> Provider:
        """Register a new provider.

        Args:
            name: Provider name.
            provider_type: Type of provider.
            config: Provider configuration.
            skip_health_check: Skip health check during registration.

        Returns:
            Registered provider.
        """
        self._logger.debug(
            "provider_register_start",
            name=name,
            provider_type=str(provider_type),
            workspace_id=str(self._workspace_id),
            skip_health_check=skip_health_check,
            disable_monitoring=disable_monitoring,
        )
        config_dict, _ = _split_patch_config(config)
        if provider_type == ProviderType.SPARK:
            config_dict = _spark_config_to_rest_payload(config_dict)
        provider_input_kwargs: dict[str, Any] = {
            "name": name,
            "type": provider_type,
            "config": config_dict,
        }
        provider_input = ProviderInput(**provider_input_kwargs)
        # disable_monitoring implies skip_health_check (no sync check needed either).
        if disable_monitoring:
            skip_health_check = True
        request = RegisterProviderRequest(
            provider=provider_input,
            skip_health_check=skip_health_check,
            disable_monitoring=disable_monitoring,
        )
        response = self._transport.post(
            f"/api/v1/workspaces/{self._workspace_id}/providers",
            json=request.model_dump(exclude_none=True, mode="json", by_alias=True),
        )
        provider = self._parse_provider(response)
        self._logger.debug("provider_register_complete", name=provider.name)
        return provider

    def get(self, name: str) -> Provider:
        """Get a provider by name.

        Args:
            name: Provider name.

        Returns:
            Provider.
        """
        self._logger.debug("provider_get", name=name)
        response = self._transport.get(f"/api/v1/workspaces/{self._workspace_id}/providers/{name}")
        return self._parse_provider(response)

    def list(self) -> list[Provider]:
        """List all providers in the workspace.

        Returns:
            List of providers.
        """
        self._logger.debug("provider_list", workspace_id=str(self._workspace_id))
        response = self._transport.get(f"/api/v1/workspaces/{self._workspace_id}/providers")
        providers_data = response.data.get("providers", [])
        return [self._parse_provider_data(cast(dict[str, Any], p)) for p in providers_data]

    def delete(self, name: str) -> None:
        """Delete a provider.

        Args:
            name: Provider name.
        """
        self._logger.debug("provider_delete", name=name)
        self._transport.delete(f"/api/v1/workspaces/{self._workspace_id}/providers/{name}")

    def update(
        self,
        name: str,
        config: ProviderConfig | dict[str, Any],
        force: bool = False,
        skip_health_check: bool = False,
        disable_monitoring: bool = False,
        provider_type: ProviderType | None = None,
    ) -> Provider:
        """Update an existing provider.

        Args:
            name: Provider name.
            config: Updated provider configuration.
            force: Force potentially breaking changes (e.g., host changes).
            skip_health_check: Skip health check after update.
            provider_type: Provider type. If provided, skips a redundant API call
                to fetch the existing provider. Use this when you already have
                the provider type from a previous get() call.

        Returns:
            Updated provider.
        """
        self._logger.debug(
            "provider_update_start",
            name=name,
            workspace_id=str(self._workspace_id),
            force=force,
            skip_health_check=skip_health_check,
            disable_monitoring=disable_monitoring,
        )
        # Get existing provider to preserve type only if provider_type not provided.
        # This avoids a redundant API call when the caller already has the type.
        if provider_type is None:
            existing = self.get(name)
            provider_type = existing.type

        config_dict, clear_fields = _split_patch_config(config)
        if provider_type == ProviderType.SPARK:
            config_dict = _spark_config_to_rest_payload(config_dict)
        provider_input_kwargs: dict[str, Any] = {
            "name": name,
            "type": provider_type,
            "config": config_dict,
        }
        provider_input = ProviderInput(**provider_input_kwargs)
        request = UpdateProviderRequest(
            provider=provider_input,
            force=force,
            skip_health_check=skip_health_check,
            disable_monitoring=disable_monitoring,
            clear_config_fields=clear_fields,
        )
        response = self._transport.put(
            f"/api/v1/workspaces/{self._workspace_id}/providers/{name}",
            json=request.model_dump(exclude_none=True, mode="json", by_alias=True),
        )
        provider = self._parse_provider(response)
        self._logger.debug("provider_update_complete", name=provider.name)
        return provider

    def _parse_provider(self, response: Response) -> Provider:
        """Parse provider from response."""
        provider_data = response.data.get("provider", response.data)
        return self._parse_provider_data(cast(dict[str, Any], provider_data))

    def _parse_provider_data(self, provider_data: dict[str, Any]) -> Provider:
        typed_data = dict(provider_data)
        provider_type = ProviderType(typed_data["type"])
        config_payload = typed_data.get("config", {})
        typed_data["config"] = _provider_config_from_payload(
            provider_type,
            cast(dict[str, Any], config_payload),
        )
        return Provider.model_validate(typed_data)


class GRPCProviderClient(ProviderClientBase):
    """gRPC client for provider operations."""

    def __init__(self, transport: GRPCTransport, workspace_id: UUID) -> None:
        """Initialize gRPC provider client."""
        self._transport = transport
        self._workspace_id = workspace_id
        self._logger = get_logger("featureform.client.provider.grpc")

    def register(
        self,
        name: str,
        provider_type: ProviderType,
        config: ProviderConfig | dict[str, Any],
        skip_health_check: bool = False,
        disable_monitoring: bool = False,
    ) -> Provider:
        """Register a new provider via gRPC."""
        import grpc

        from featureform.transport.grpc import grpc_error_to_exception, provider_pb2

        self._logger.debug(
            "provider_register_start",
            name=name,
            provider_type=str(provider_type),
            workspace_id=str(self._workspace_id),
            skip_health_check=skip_health_check,
            disable_monitoring=disable_monitoring,
        )

        proto_provider = self._config_to_proto(name, provider_type, config)
        request = provider_pb2.RegisterProviderRequest(
            workspace_id=str(self._workspace_id),
            provider=proto_provider,
            skip_health_check=skip_health_check,
            disable_monitoring=disable_monitoring,
        )
        try:
            response = self._transport.provider.RegisterProvider(request)
            provider = self._proto_to_provider(response.provider)
            self._logger.debug("provider_register_complete", name=provider.name)
            return provider
        except grpc.RpcError as e:
            raise grpc_error_to_exception(e) from e

    def get(self, name: str) -> Provider:
        """Get a provider by name via gRPC."""
        import grpc

        from featureform.transport.grpc import grpc_error_to_exception, provider_pb2

        self._logger.debug("provider_get", name=name)
        request = provider_pb2.GetProviderRequest(
            workspace_id=str(self._workspace_id),
            name=name,
        )
        try:
            response = self._transport.provider.GetProvider(request)
            return self._proto_to_provider(response.provider)
        except grpc.RpcError as e:
            raise grpc_error_to_exception(e) from e

    def list(self) -> list[Provider]:
        """List all providers in the workspace via gRPC."""
        import grpc

        from featureform.transport.grpc import grpc_error_to_exception, provider_pb2

        self._logger.debug("provider_list", workspace_id=str(self._workspace_id))
        request = provider_pb2.ListProvidersRequest(
            workspace_id=str(self._workspace_id),
        )
        try:
            response = self._transport.provider.ListProviders(request)
            return [self._proto_to_provider(p) for p in response.providers]
        except grpc.RpcError as e:
            raise grpc_error_to_exception(e) from e

    def delete(self, name: str) -> None:
        """Delete a provider via gRPC."""
        import grpc

        from featureform.transport.grpc import grpc_error_to_exception, provider_pb2

        self._logger.debug("provider_delete", name=name)
        request = provider_pb2.DeleteProviderRequest(
            workspace_id=str(self._workspace_id),
            name=name,
        )
        try:
            self._transport.provider.DeleteProvider(request)
        except grpc.RpcError as e:
            raise grpc_error_to_exception(e) from e

    def update(
        self,
        name: str,
        config: ProviderConfig | dict[str, Any],
        force: bool = False,
        skip_health_check: bool = False,
        disable_monitoring: bool = False,
        provider_type: ProviderType | None = None,
    ) -> Provider:
        """Update an existing provider via gRPC."""
        import grpc

        from featureform.transport.grpc import grpc_error_to_exception, provider_pb2

        self._logger.debug(
            "provider_update_start",
            name=name,
            workspace_id=str(self._workspace_id),
            force=force,
            skip_health_check=skip_health_check,
            disable_monitoring=disable_monitoring,
        )

        existing_provider: Provider | None = None
        if provider_type is None:
            existing_provider = self.get(name)
            provider_type = existing_provider.type

        config_dict, clear_fields = _split_patch_config(config)
        if provider_type == ProviderType.SPARK:
            config_dict = self._normalize_spark_patch_dict(
                name,
                config_dict,
                existing_provider,
            )
        proto_provider = self._patch_dict_to_proto(name, provider_type, config_dict)
        request = provider_pb2.UpdateProviderRequest(
            workspace_id=str(self._workspace_id),
            provider=proto_provider,
            force=force,
            skip_health_check=skip_health_check,
            disable_monitoring=disable_monitoring,
            clear_config_fields=clear_fields,
        )
        try:
            response = self._transport.provider.UpdateProvider(request)
            provider = self._proto_to_provider(response.provider)
            self._logger.debug("provider_update_complete", name=provider.name)
            return provider
        except grpc.RpcError as e:
            raise grpc_error_to_exception(e) from e

    def _normalize_spark_patch_dict(
        self,
        name: str,
        config: dict[str, Any],
        existing_provider: Provider | None,
    ) -> dict[str, Any]:
        advanced = config.get("advanced")
        if not isinstance(advanced, dict):
            return config
        advanced_patch = cast(dict[str, Any], advanced)

        if "spark_conf" in advanced_patch:
            return config

        set_spark_conf = cast(dict[str, str], advanced_patch.get("set_spark_conf") or {})
        remove_spark_conf = cast(list[str], advanced_patch.get("remove_spark_conf") or [])
        if not set_spark_conf and not remove_spark_conf:
            return config

        provider = existing_provider if existing_provider is not None else self.get(name)
        if not isinstance(provider.config, SparkProviderConfig):
            raise ProviderTypeMismatchError(
                f"expected spark provider config for {name}, got {type(provider.config).__name__}"
            )

        merged_spark_conf = dict(provider.config.advanced.spark_conf)
        merged_spark_conf.update(set_spark_conf)
        for key in remove_spark_conf:
            merged_spark_conf.pop(key, None)

        normalized = dict(config)
        normalized["advanced"] = {"spark_conf": merged_spark_conf}
        return normalized

    def _config_to_proto(
        self, name: str, provider_type: ProviderType, config: ProviderConfig | dict[str, Any]
    ) -> Any:
        """Convert config to proto Provider."""
        from featureform._generated.proto.featureform.v2 import provider_pb2
        from featureform.errors import InvalidArgumentError
        from featureform.types.provider import IcebergCatalogConfig

        # Map provider type to proto enum
        type_map = {
            ProviderType.ICEBERG: provider_pb2.PROVIDER_TYPE_ICEBERG_CATALOG,
            ProviderType.POSTGRES: provider_pb2.PROVIDER_TYPE_POSTGRES,
            ProviderType.SNOWFLAKE: provider_pb2.PROVIDER_TYPE_SNOWFLAKE,
            ProviderType.S3: provider_pb2.PROVIDER_TYPE_S3,
            ProviderType.SPARK: provider_pb2.PROVIDER_TYPE_SPARK,
            ProviderType.DYNAMODB: provider_pb2.PROVIDER_TYPE_DYNAMODB,
            ProviderType.REDIS: provider_pb2.PROVIDER_TYPE_REDIS,
            ProviderType.REDIS_CLUSTER: provider_pb2.PROVIDER_TYPE_REDIS_CLUSTER,
            ProviderType.KAFKA: provider_pb2.PROVIDER_TYPE_KAFKA,
        }
        try:
            proto_type = type_map[provider_type]
        except KeyError as exc:
            raise InvalidArgumentError(
                f"unsupported provider type for gRPC transport: {provider_type}"
            ) from exc

        proto_provider = provider_pb2.Provider(
            workspace_id=str(self._workspace_id),
            name=name,
            type=proto_type,
        )

        if isinstance(config, dict):
            return self._patch_dict_to_proto(name, provider_type, config)

        # Set type-specific config
        if isinstance(config, IcebergCatalogConfig):
            iceberg_config = provider_pb2.IcebergCatalogConfig()
            if config.backend.hive is not None:
                iceberg_config.backend.hive.CopyFrom(
                    provider_pb2.IcebergHiveConfig(uri=config.backend.hive.uri)
                )
            elif config.backend.rest is not None:
                rest_config = provider_pb2.IcebergRESTConfig(
                    uri=config.backend.rest.uri,
                    prefix=config.backend.rest.prefix or "",
                )
                credential = _secret_ref_to_proto(config.backend.rest.credential, provider_pb2)
                if credential is not None:
                    rest_config.credential_secret.CopyFrom(credential)
                iceberg_config.backend.rest.CopyFrom(rest_config)
            elif config.backend.glue is not None:
                iceberg_config.backend.glue.CopyFrom(
                    provider_pb2.IcebergGlueConfig(
                        region=config.backend.glue.region,
                        catalog_id=config.backend.glue.catalog_id or "",
                    )
                )
            elif config.backend.sql is not None:
                sql_config = provider_pb2.IcebergSQLConfig(driver=config.backend.sql.driver)
                connection_string = _secret_ref_to_proto(
                    config.backend.sql.connection_string, provider_pb2
                )
                if connection_string is not None:
                    sql_config.connection_string_secret.CopyFrom(connection_string)
                iceberg_config.backend.sql.CopyFrom(sql_config)

            if config.warehouse.s3 is not None:
                iceberg_config.warehouse.s3.provider = config.warehouse.s3.provider
                iceberg_config.warehouse.s3.prefix = config.warehouse.s3.prefix or ""
            elif config.warehouse.hdfs is not None:
                iceberg_config.warehouse.hdfs.provider = config.warehouse.hdfs.provider
                iceberg_config.warehouse.hdfs.path = config.warehouse.hdfs.path
            proto_provider.iceberg_catalog.CopyFrom(iceberg_config)

        elif provider_type == ProviderType.POSTGRES:
            from featureform.types.provider import PostgresConfig, SSLMode

            if isinstance(config, PostgresConfig):
                # Map SSLMode to proto enum
                ssl_mode_map = {
                    SSLMode.DISABLE: provider_pb2.SSL_MODE_DISABLE,
                    SSLMode.ALLOW: provider_pb2.SSL_MODE_ALLOW,
                    SSLMode.PREFER: provider_pb2.SSL_MODE_PREFER,
                    SSLMode.REQUIRE: provider_pb2.SSL_MODE_REQUIRE,
                    SSLMode.VERIFY_CA: provider_pb2.SSL_MODE_VERIFY_CA,
                    SSLMode.VERIFY_FULL: provider_pb2.SSL_MODE_VERIFY_FULL,
                }
                proto_ssl_mode = ssl_mode_map.get(config.ssl_mode, provider_pb2.SSL_MODE_PREFER)
                postgres_config = provider_pb2.PostgresConfig(
                    host=config.host,
                    port=config.port,
                    database=config.database,
                    username=config.user or "",
                    ssl_mode=proto_ssl_mode,
                )
                password_secret = _secret_ref_to_proto(config.password_secret, provider_pb2)
                if password_secret is not None:
                    postgres_config.password_secret.CopyFrom(password_secret)
                proto_provider.postgres.CopyFrom(postgres_config)

        elif provider_type == ProviderType.SNOWFLAKE:
            from featureform.types.provider import SnowflakeConfig

            if isinstance(config, SnowflakeConfig):
                auth_type_map = {
                    "password": provider_pb2.SNOWFLAKE_AUTH_TYPE_PASSWORD,
                    "key-pair": provider_pb2.SNOWFLAKE_AUTH_TYPE_KEY_PAIR,
                    "oauth": provider_pb2.SNOWFLAKE_AUTH_TYPE_OAUTH,
                }
                snowflake_config = provider_pb2.SnowflakeConfig(
                    account=config.account,
                    host=config.host or "",
                    auth_type=auth_type_map.get(
                        config.auth_type,
                        provider_pb2.SNOWFLAKE_AUTH_TYPE_UNSPECIFIED,
                    ),
                    username=config.username or "",
                    database=config.database,
                    schema=config.schema,
                    warehouse=config.warehouse,
                    role=config.role or "",
                    oauth_client_id=config.oauth_client_id or "",
                    login_timeout=config.login_timeout or 0,
                    request_timeout=config.request_timeout or 0,
                )
                password_secret = _secret_ref_to_proto(config.password_secret, provider_pb2)
                if password_secret is not None:
                    snowflake_config.password_secret.CopyFrom(password_secret)
                private_key_secret = _secret_ref_to_proto(config.private_key_secret, provider_pb2)
                if private_key_secret is not None:
                    snowflake_config.private_key_secret.CopyFrom(private_key_secret)
                passphrase_secret = _secret_ref_to_proto(config.passphrase_secret, provider_pb2)
                if passphrase_secret is not None:
                    snowflake_config.passphrase_secret.CopyFrom(passphrase_secret)
                oauth_client_secret = _secret_ref_to_proto(config.oauth_client_secret, provider_pb2)
                if oauth_client_secret is not None:
                    snowflake_config.oauth_client_secret.CopyFrom(oauth_client_secret)
                oauth_token = _secret_ref_to_proto(config.oauth_token, provider_pb2)
                if oauth_token is not None:
                    snowflake_config.oauth_token.CopyFrom(oauth_token)
                if config.session_params:
                    snowflake_config.session_params.update(config.session_params)
                proto_provider.snowflake.CopyFrom(snowflake_config)

        elif provider_type == ProviderType.SPARK:
            from featureform.types.provider import SparkProviderConfig

            if isinstance(config, SparkProviderConfig):
                spark_config = provider_pb2.SparkProviderConfig()
                merged_spark_conf = dict(config.advanced.spark_conf)
                merged_spark_conf.update(dict(config.spark_conf))
                if config.backend:
                    if config.backend.local is not None:
                        spark_config.backend.local.master = config.backend.local.master or ""
                    elif config.backend.standalone is not None:
                        spark_config.backend.standalone.master = (
                            config.backend.standalone.master or ""
                        )
                    elif config.backend.yarn is not None:
                        spark_config.backend.yarn.master = config.backend.yarn.master or ""
                        spark_config.backend.yarn.config.queue = config.backend.yarn.queue or ""
                        spark_config.backend.yarn.config.proxy_user = (
                            config.backend.yarn.proxy_user or ""
                        )
                    elif config.backend.k8s is not None:
                        spark_config.backend.k8s.api_server = config.backend.k8s.api_server or ""
                        spark_config.backend.k8s.config.image = config.backend.k8s.image or ""
                        spark_config.backend.k8s.config.namespace = (
                            config.backend.k8s.namespace or ""
                        )
                        spark_config.backend.k8s.config.service_account = (
                            config.backend.k8s.service_account or ""
                        )
                        spark_config.backend.k8s.config.executor_request_cores = (
                            config.backend.k8s.executor_request_cores or ""
                        )
                        spark_config.backend.k8s.config.executor_limit_cores = (
                            config.backend.k8s.executor_limit_cores or ""
                        )
                        spark_config.backend.k8s.config.executor_pod_env.update(
                            dict(config.backend.k8s.executor_pod_env)
                        )
                        spark_config.backend.k8s.config.driver_secrets.update(
                            dict(config.backend.k8s.driver_secrets)
                        )
                        spark_config.backend.k8s.config.executor_secrets.update(
                            dict(config.backend.k8s.executor_secrets)
                        )
                        spark_config.backend.k8s.config.executor_secret_key_refs.extend(
                            provider_pb2.K8sSecretKeyRef(
                                env_var=item.env_var or "",
                                name=item.name or "",
                                key=item.key or "",
                            )
                            for item in config.backend.k8s.executor_secret_key_refs
                        )
                if config.hadoop:
                    spark_config.hadoop.s3a_provider = config.hadoop.s3a_provider or ""
                    spark_config.hadoop.path_style = bool(config.hadoop.path_style)
                if config.staging:
                    spark_config.staging.provider = config.staging.provider or ""
                    spark_config.staging.prefix = config.staging.prefix or ""
                spark_config.defaults.catalogs.update(dict(config.catalogs))
                spark_config.defaults.deploy_mode = config.deploy_mode or ""
                spark_config.defaults.spark_conf.update(merged_spark_conf)
                spark_config.defaults.max_execution_time = config.max_execution_time or ""
                spark_config.defaults.driver_env.values.update(dict(config.driver_env.values))
                for key, value in config.driver_env.secrets.items():
                    secret_ref = _secret_ref_to_proto(value, provider_pb2)
                    if secret_ref is not None:
                        spark_config.defaults.driver_env.secrets[key].CopyFrom(secret_ref)
                spark_config.defaults.executor_env.values.update(dict(config.executor_env.values))
                for key, value in config.executor_env.secrets.items():
                    secret_ref = _secret_ref_to_proto(value, provider_pb2)
                    if secret_ref is not None:
                        spark_config.defaults.executor_env.secrets[key].CopyFrom(secret_ref)
                if config.runtime_profile is not None:
                    spark_config.defaults.runtime_profile.CopyFrom(
                        provider_pb2.SparkRuntimeProfile(
                            backend=config.runtime_profile.backend or "",
                            spark_version=config.runtime_profile.spark_version or "",
                            scala_binary_version=config.runtime_profile.scala_binary_version or "",
                        )
                    )
                spark_config.defaults.execution_defaults.CopyFrom(
                    provider_pb2.SparkExecutionDefaults(
                        driver_memory=config.execution_defaults.driver_memory or "",
                        executor_memory=config.execution_defaults.executor_memory or "",
                        executor_cores=config.execution_defaults.executor_cores or 0,
                        num_executors=config.execution_defaults.num_executors or 0,
                        shuffle_partitions=config.execution_defaults.shuffle_partitions or 0,
                        driver_cores=config.execution_defaults.driver_cores or 0,
                    )
                )
                spark_config.defaults.dependencies.CopyFrom(
                    provider_pb2.SparkDependencyPolicy(
                        versions=provider_pb2.SparkDependencyVersions(
                            iceberg=config.dependencies.versions.iceberg or "",
                            iceberg_aws_bundle=config.dependencies.versions.iceberg_aws_bundle
                            or "",
                            hadoop_aws=config.dependencies.versions.hadoop_aws or "",
                            aws_java_sdk_bundle=config.dependencies.versions.aws_java_sdk_bundle
                            or "",
                            postgres_jdbc=config.dependencies.versions.postgres_jdbc or "",
                        ),
                        package_overrides=dict(config.dependencies.package_overrides),
                        extra_packages=list(config.dependencies.extra_packages),
                        extra_jars=list(config.dependencies.extra_jars),
                        provided_families=list(config.dependencies.provided_families),
                    )
                )
                if (
                    config.submission_defaults.app_name
                    or config.submission_defaults.properties_file
                    or config.submission_defaults.repositories
                    or config.submission_defaults.files
                    or config.submission_defaults.archives
                    or config.submission_defaults.py_files
                    or config.submission_defaults.kerberos is not None
                ):
                    submission_defaults = provider_pb2.SparkSubmissionDefaults(
                        app_name=config.submission_defaults.app_name or "",
                        properties_file=config.submission_defaults.properties_file or "",
                        repositories=list(config.submission_defaults.repositories),
                        files=[
                            provider_pb2.SparkSubmissionArtifactRef(uri=item.uri)
                            for item in config.submission_defaults.files
                        ],
                        archives=[
                            provider_pb2.SparkSubmissionArtifactRef(uri=item.uri)
                            for item in config.submission_defaults.archives
                        ],
                        py_files=[
                            provider_pb2.SparkSubmissionArtifactRef(uri=item.uri)
                            for item in config.submission_defaults.py_files
                        ],
                    )
                    if config.submission_defaults.kerberos is not None:
                        kerberos = provider_pb2.SparkSubmissionKerberosConfig(
                            principal=config.submission_defaults.kerberos.principal,
                            realm=config.submission_defaults.kerberos.realm or "",
                            kdc_host=config.submission_defaults.kerberos.kdc_host or "",
                        )
                        keytab_secret = _secret_ref_to_proto(
                            config.submission_defaults.kerberos.keytab_secret, provider_pb2
                        )
                        if keytab_secret is not None:
                            kerberos.keytab_secret.CopyFrom(keytab_secret)
                        krb5_conf_secret = _secret_ref_to_proto(
                            config.submission_defaults.kerberos.krb5_conf_secret, provider_pb2
                        )
                        if krb5_conf_secret is not None:
                            kerberos.krb5_conf_secret.CopyFrom(krb5_conf_secret)
                        submission_defaults.kerberos.CopyFrom(kerberos)
                    spark_config.defaults.submission_defaults.CopyFrom(submission_defaults)
                proto_provider.spark.CopyFrom(spark_config)

        elif provider_type == ProviderType.REDIS:
            from featureform.types.provider import RedisConfig

            if isinstance(config, RedisConfig):
                redis_config = provider_pb2.RedisConfig(
                    host=config.host,
                    port=config.port,
                    db=config.database,
                )
                password_secret = _secret_ref_to_proto(config.password_secret, provider_pb2)
                if password_secret is not None:
                    redis_config.password_secret.CopyFrom(password_secret)
                redis_tls = _redis_tls_to_proto(config.tls, provider_pb2)
                if redis_tls is not None:
                    redis_config.tls.CopyFrom(redis_tls)
                proto_provider.redis.CopyFrom(redis_config)

        elif provider_type == ProviderType.REDIS_CLUSTER:
            from featureform.types.provider import RedisClusterConfig

            if isinstance(config, RedisClusterConfig):
                redis_cluster_config = provider_pb2.RedisClusterConfig(
                    endpoints=list(config.endpoints),
                )
                password_secret = _secret_ref_to_proto(config.password_secret, provider_pb2)
                if password_secret is not None:
                    redis_cluster_config.password_secret.CopyFrom(password_secret)
                redis_tls = _redis_tls_to_proto(config.tls, provider_pb2)
                if redis_tls is not None:
                    redis_cluster_config.tls.CopyFrom(redis_tls)
                proto_provider.redis_cluster.CopyFrom(redis_cluster_config)

        elif provider_type == ProviderType.S3:
            from featureform.types.provider import S3Config

            if isinstance(config, S3Config):
                bucket = config.bucket
                path_prefix = ""
                if bucket.lower().startswith("s3://"):
                    parsed = urlparse(bucket)
                    bucket = parsed.netloc
                    path_prefix = parsed.path.lstrip("/")
                s3_config = provider_pb2.S3Config(
                    bucket=bucket,
                    region=config.region,
                    endpoint=config.endpoint or "",
                    path_prefix=path_prefix,
                    path_style_access=bool(config.path_style_access),
                )
                access_key = _secret_ref_to_proto(config.access_key_id_secret, provider_pb2)
                if access_key is not None:
                    s3_config.access_key_id_secret.CopyFrom(access_key)
                secret_key = _secret_ref_to_proto(config.secret_access_key_secret, provider_pb2)
                if secret_key is not None:
                    s3_config.secret_access_key_secret.CopyFrom(secret_key)
                proto_provider.s3.CopyFrom(s3_config)

        elif provider_type == ProviderType.DYNAMODB:
            from featureform.types.provider import DynamoDBConfig

            if isinstance(config, DynamoDBConfig):
                dynamodb_config = provider_pb2.DynamoDBConfig(
                    region=config.region,
                    endpoint=config.endpoint or "",
                    table_prefix=config.table_prefix or "",
                )
                access_key = _secret_ref_to_proto(config.access_key_id_secret, provider_pb2)
                if access_key is not None:
                    dynamodb_config.access_key_id_secret.CopyFrom(access_key)
                secret_key = _secret_ref_to_proto(config.secret_access_key_secret, provider_pb2)
                if secret_key is not None:
                    dynamodb_config.secret_access_key_secret.CopyFrom(secret_key)
                proto_provider.dynamodb.CopyFrom(dynamodb_config)

        elif provider_type == ProviderType.KAFKA:
            from featureform.types.provider import KafkaConfig

            if isinstance(config, KafkaConfig):
                kafka_config = provider_pb2.KafkaConfig(
                    brokers=list(config.brokers),
                )
                if config.sasl_username:
                    kafka_config.sasl_username = config.sasl_username
                sasl_password_secret = _secret_ref_to_proto(
                    config.sasl_password_secret, provider_pb2
                )
                if sasl_password_secret is not None:
                    kafka_config.sasl_password_secret.CopyFrom(sasl_password_secret)
                if config.sasl_mechanism:
                    kafka_config.sasl_mechanism = config.sasl_mechanism
                if config.oauth_client_id:
                    kafka_config.oauth_client_id = config.oauth_client_id
                oauth_client_secret = _secret_ref_to_proto(config.oauth_client_secret, provider_pb2)
                if oauth_client_secret is not None:
                    kafka_config.oauth_client_secret.CopyFrom(oauth_client_secret)
                if config.oauth_token_url:
                    kafka_config.oauth_token_url = config.oauth_token_url
                mtls_client_cert_secret = _secret_ref_to_proto(
                    config.mtls_client_cert_secret, provider_pb2
                )
                if mtls_client_cert_secret is not None:
                    kafka_config.mtls_client_cert_secret.CopyFrom(mtls_client_cert_secret)
                mtls_client_key_secret = _secret_ref_to_proto(
                    config.mtls_client_key_secret, provider_pb2
                )
                if mtls_client_key_secret is not None:
                    kafka_config.mtls_client_key_secret.CopyFrom(mtls_client_key_secret)
                proto_provider.kafka.CopyFrom(kafka_config)

        return proto_provider

    def _patch_dict_to_proto(
        self, name: str, provider_type: ProviderType, config: dict[str, Any]
    ) -> Any:
        from featureform.transport.grpc import provider_pb2

        type_map = {
            ProviderType.ICEBERG: provider_pb2.PROVIDER_TYPE_ICEBERG_CATALOG,
            ProviderType.POSTGRES: provider_pb2.PROVIDER_TYPE_POSTGRES,
            ProviderType.SNOWFLAKE: provider_pb2.PROVIDER_TYPE_SNOWFLAKE,
            ProviderType.S3: provider_pb2.PROVIDER_TYPE_S3,
            ProviderType.SPARK: provider_pb2.PROVIDER_TYPE_SPARK,
            ProviderType.DYNAMODB: provider_pb2.PROVIDER_TYPE_DYNAMODB,
            ProviderType.REDIS: provider_pb2.PROVIDER_TYPE_REDIS,
            ProviderType.REDIS_CLUSTER: provider_pb2.PROVIDER_TYPE_REDIS_CLUSTER,
            ProviderType.KAFKA: provider_pb2.PROVIDER_TYPE_KAFKA,
        }
        proto_provider = provider_pb2.Provider(
            workspace_id=str(self._workspace_id),
            name=name,
            type=type_map.get(provider_type, provider_pb2.PROVIDER_TYPE_UNSPECIFIED),
        )

        if provider_type == ProviderType.ICEBERG:
            proto_provider.iceberg_catalog.CopyFrom(
                _iceberg_catalog_patch_dict_to_proto(config, provider_pb2)
            )
            return proto_provider

        if provider_type == ProviderType.POSTGRES:
            if "host" in config:
                proto_provider.postgres.host = config["host"]
            if "port" in config:
                proto_provider.postgres.port = config["port"]
            if "database" in config:
                proto_provider.postgres.database = config["database"]
            if "user" in config:
                proto_provider.postgres.username = config["user"]
            if "password_secret" in config:
                password_secret = _secret_ref_to_proto(config["password_secret"], provider_pb2)
                if password_secret is not None:
                    proto_provider.postgres.password_secret.CopyFrom(password_secret)
            if "ssl_mode" in config:
                ssl_mode_map = {
                    "disable": provider_pb2.SSL_MODE_DISABLE,
                    "allow": provider_pb2.SSL_MODE_ALLOW,
                    "prefer": provider_pb2.SSL_MODE_PREFER,
                    "require": provider_pb2.SSL_MODE_REQUIRE,
                    "verify-ca": provider_pb2.SSL_MODE_VERIFY_CA,
                    "verify-full": provider_pb2.SSL_MODE_VERIFY_FULL,
                }
                proto_provider.postgres.ssl_mode = ssl_mode_map.get(
                    config["ssl_mode"], provider_pb2.SSL_MODE_UNSPECIFIED
                )
            return proto_provider

        if provider_type == ProviderType.SNOWFLAKE:
            if "account" in config:
                proto_provider.snowflake.account = config["account"]
            if "host" in config:
                proto_provider.snowflake.host = config["host"]
            if "auth_type" in config:
                auth_type_map = {
                    "password": provider_pb2.SNOWFLAKE_AUTH_TYPE_PASSWORD,
                    "key-pair": provider_pb2.SNOWFLAKE_AUTH_TYPE_KEY_PAIR,
                    "oauth": provider_pb2.SNOWFLAKE_AUTH_TYPE_OAUTH,
                }
                proto_provider.snowflake.auth_type = auth_type_map.get(
                    config["auth_type"],
                    provider_pb2.SNOWFLAKE_AUTH_TYPE_UNSPECIFIED,
                )
            if "username" in config:
                proto_provider.snowflake.username = config["username"]
            if "password_secret" in config:
                password_secret = _secret_ref_to_proto(config["password_secret"], provider_pb2)
                if password_secret is not None:
                    proto_provider.snowflake.password_secret.CopyFrom(password_secret)
            if "private_key_secret" in config:
                private_key_secret = _secret_ref_to_proto(
                    config["private_key_secret"], provider_pb2
                )
                if private_key_secret is not None:
                    proto_provider.snowflake.private_key_secret.CopyFrom(private_key_secret)
            if "passphrase_secret" in config:
                passphrase_secret = _secret_ref_to_proto(config["passphrase_secret"], provider_pb2)
                if passphrase_secret is not None:
                    proto_provider.snowflake.passphrase_secret.CopyFrom(passphrase_secret)
            if "oauth_client_id" in config:
                proto_provider.snowflake.oauth_client_id = config["oauth_client_id"]
            if "oauth_client_secret" in config:
                oauth_client_secret = _secret_ref_to_proto(
                    config["oauth_client_secret"], provider_pb2
                )
                if oauth_client_secret is not None:
                    proto_provider.snowflake.oauth_client_secret.CopyFrom(oauth_client_secret)
            if "oauth_token" in config:
                oauth_token = _secret_ref_to_proto(config["oauth_token"], provider_pb2)
                if oauth_token is not None:
                    proto_provider.snowflake.oauth_token.CopyFrom(oauth_token)
            if "database" in config:
                proto_provider.snowflake.database = config["database"]
            if "schema" in config:
                proto_provider.snowflake.schema = config["schema"]
            if "warehouse" in config:
                proto_provider.snowflake.warehouse = config["warehouse"]
            if "role" in config:
                proto_provider.snowflake.role = config["role"]
            if "login_timeout" in config:
                proto_provider.snowflake.login_timeout = config["login_timeout"]
            if "request_timeout" in config:
                proto_provider.snowflake.request_timeout = config["request_timeout"]
            if "session_params" in config:
                proto_provider.snowflake.session_params.update(config["session_params"])
            return proto_provider

        if provider_type == ProviderType.S3:
            if "bucket" in config:
                proto_provider.s3.bucket = config["bucket"]
            if "region" in config:
                proto_provider.s3.region = config["region"]
            if "endpoint" in config:
                proto_provider.s3.endpoint = config["endpoint"]
            if "path_style_access" in config:
                proto_provider.s3.path_style_access = bool(config["path_style_access"])
            if "access_key_id_secret" in config:
                access_key = _secret_ref_to_proto(config["access_key_id_secret"], provider_pb2)
                if access_key is not None:
                    proto_provider.s3.access_key_id_secret.CopyFrom(access_key)
            if "secret_access_key_secret" in config:
                secret_key = _secret_ref_to_proto(config["secret_access_key_secret"], provider_pb2)
                if secret_key is not None:
                    proto_provider.s3.secret_access_key_secret.CopyFrom(secret_key)
            return proto_provider

        if provider_type == ProviderType.SPARK:
            if "catalogs" in config and isinstance(config["catalogs"], dict):
                proto_provider.spark.defaults.catalogs.update(config["catalogs"])
            if "deploy_mode" in config:
                proto_provider.spark.defaults.deploy_mode = config["deploy_mode"]
            if "spark_conf" in config:
                proto_provider.spark.defaults.spark_conf.update(config["spark_conf"])
            if "max_execution_time" in config:
                proto_provider.spark.defaults.max_execution_time = config["max_execution_time"]
            if "backend" in config and isinstance(config["backend"], dict):
                backend = cast(dict[str, Any], config["backend"])
                if "local" in backend and isinstance(backend["local"], dict):
                    local = cast(dict[str, Any], backend["local"])
                    proto_provider.spark.backend.local.master = local.get("master", "")
                if "standalone" in backend and isinstance(backend["standalone"], dict):
                    standalone = cast(dict[str, Any], backend["standalone"])
                    proto_provider.spark.backend.standalone.master = standalone.get("master", "")
                if "yarn" in backend and isinstance(backend["yarn"], dict):
                    yarn = cast(dict[str, Any], backend["yarn"])
                    proto_provider.spark.backend.yarn.master = yarn.get("master", "")
                    proto_provider.spark.backend.yarn.config.queue = yarn.get("queue", "")
                    proto_provider.spark.backend.yarn.config.proxy_user = yarn.get("proxy_user", "")
                if "k8s" in backend and isinstance(backend["k8s"], dict):
                    k8s = cast(dict[str, Any], backend["k8s"])
                    proto_provider.spark.backend.k8s.api_server = k8s.get("api_server", "")
                    proto_provider.spark.backend.k8s.config.image = k8s.get("image", "")
                    proto_provider.spark.backend.k8s.config.namespace = k8s.get("namespace", "")
                    proto_provider.spark.backend.k8s.config.service_account = k8s.get(
                        "service_account", ""
                    )
                    proto_provider.spark.backend.k8s.config.executor_request_cores = k8s.get(
                        "executor_request_cores", ""
                    )
                    proto_provider.spark.backend.k8s.config.executor_limit_cores = k8s.get(
                        "executor_limit_cores", ""
                    )
                    if isinstance(k8s.get("executor_pod_env"), dict):
                        proto_provider.spark.backend.k8s.config.executor_pod_env.update(
                            cast(dict[str, str], k8s["executor_pod_env"])
                        )
                    if isinstance(k8s.get("driver_secrets"), dict):
                        proto_provider.spark.backend.k8s.config.driver_secrets.update(
                            cast(dict[str, str], k8s["driver_secrets"])
                        )
                    if isinstance(k8s.get("executor_secrets"), dict):
                        proto_provider.spark.backend.k8s.config.executor_secrets.update(
                            cast(dict[str, str], k8s["executor_secrets"])
                        )
                    if isinstance(k8s.get("executor_secret_key_refs"), list):
                        refs = cast(list[dict[str, Any]], k8s["executor_secret_key_refs"])
                        proto_provider.spark.backend.k8s.config.executor_secret_key_refs.extend(
                            provider_pb2.K8sSecretKeyRef(
                                env_var=item.get("env_var", ""),
                                name=item.get("name", ""),
                                key=item.get("key", ""),
                            )
                            for item in refs
                        )
            if "hadoop" in config and isinstance(config["hadoop"], dict):
                hadoop = cast(dict[str, Any], config["hadoop"])
                if "s3a_provider" in hadoop:
                    proto_provider.spark.hadoop.s3a_provider = hadoop["s3a_provider"]
                if "path_style" in hadoop:
                    proto_provider.spark.hadoop.path_style = hadoop["path_style"]
            if "staging" in config and isinstance(config["staging"], dict):
                staging = cast(dict[str, Any], config["staging"])
                if "provider" in staging:
                    proto_provider.spark.staging.provider = staging["provider"]
                if "prefix" in staging:
                    proto_provider.spark.staging.prefix = staging["prefix"]
            if "driver_env" in config and isinstance(config["driver_env"], dict):
                driver_env = cast(dict[str, Any], config["driver_env"])
                values = driver_env.get("values")
                if isinstance(values, dict):
                    proto_provider.spark.defaults.driver_env.values.update(
                        cast(dict[str, str], values)
                    )
                secrets_map = driver_env.get("secrets")
                if isinstance(secrets_map, dict):
                    for key, value in cast(dict[str, Any], secrets_map).items():
                        secret_ref = _secret_ref_to_proto(value, provider_pb2)
                        if secret_ref is not None:
                            proto_provider.spark.defaults.driver_env.secrets[key].CopyFrom(
                                secret_ref
                            )
            if "executor_env" in config and isinstance(config["executor_env"], dict):
                executor_env = cast(dict[str, Any], config["executor_env"])
                values = executor_env.get("values")
                if isinstance(values, dict):
                    proto_provider.spark.defaults.executor_env.values.update(
                        cast(dict[str, str], values)
                    )
                secrets_map = executor_env.get("secrets")
                if isinstance(secrets_map, dict):
                    for key, value in cast(dict[str, Any], secrets_map).items():
                        secret_ref = _secret_ref_to_proto(value, provider_pb2)
                        if secret_ref is not None:
                            proto_provider.spark.defaults.executor_env.secrets[key].CopyFrom(
                                secret_ref
                            )
            if "runtime_profile" in config and isinstance(config["runtime_profile"], dict):
                runtime_profile = cast(dict[str, Any], config["runtime_profile"])
                spark_runtime_profile = provider_pb2.SparkRuntimeProfile()
                if "backend" in runtime_profile:
                    spark_runtime_profile.backend = runtime_profile["backend"]
                if "spark_version" in runtime_profile:
                    spark_runtime_profile.spark_version = runtime_profile["spark_version"]
                if "scala_binary_version" in runtime_profile:
                    spark_runtime_profile.scala_binary_version = runtime_profile[
                        "scala_binary_version"
                    ]
                proto_provider.spark.defaults.runtime_profile.CopyFrom(spark_runtime_profile)
            if "execution_defaults" in config and isinstance(config["execution_defaults"], dict):
                execution_defaults = cast(dict[str, Any], config["execution_defaults"])
                spark_execution_defaults = provider_pb2.SparkExecutionDefaults()
                if "driver_memory" in execution_defaults:
                    spark_execution_defaults.driver_memory = execution_defaults["driver_memory"]
                if "executor_memory" in execution_defaults:
                    spark_execution_defaults.executor_memory = execution_defaults["executor_memory"]
                if "executor_cores" in execution_defaults:
                    spark_execution_defaults.executor_cores = execution_defaults["executor_cores"]
                if "num_executors" in execution_defaults:
                    spark_execution_defaults.num_executors = execution_defaults["num_executors"]
                if "shuffle_partitions" in execution_defaults:
                    spark_execution_defaults.shuffle_partitions = execution_defaults[
                        "shuffle_partitions"
                    ]
                if "driver_cores" in execution_defaults:
                    spark_execution_defaults.driver_cores = execution_defaults["driver_cores"]
                proto_provider.spark.defaults.execution_defaults.CopyFrom(spark_execution_defaults)
            if "dependencies" in config and isinstance(config["dependencies"], dict):
                dependencies = cast(dict[str, Any], config["dependencies"])
                spark_dependencies = provider_pb2.SparkDependencyPolicy()
                versions = dependencies.get("versions")
                if isinstance(versions, dict):
                    if "iceberg" in versions:
                        spark_dependencies.versions.iceberg = versions["iceberg"]
                    if "iceberg_aws_bundle" in versions:
                        spark_dependencies.versions.iceberg_aws_bundle = versions[
                            "iceberg_aws_bundle"
                        ]
                    if "hadoop_aws" in versions:
                        spark_dependencies.versions.hadoop_aws = versions["hadoop_aws"]
                    if "aws_java_sdk_bundle" in versions:
                        spark_dependencies.versions.aws_java_sdk_bundle = versions[
                            "aws_java_sdk_bundle"
                        ]
                    if "postgres_jdbc" in versions:
                        spark_dependencies.versions.postgres_jdbc = versions["postgres_jdbc"]
                if "package_overrides" in dependencies:
                    spark_dependencies.package_overrides.update(dependencies["package_overrides"])
                if "extra_packages" in dependencies:
                    spark_dependencies.extra_packages.extend(dependencies["extra_packages"])
                if "extra_jars" in dependencies:
                    spark_dependencies.extra_jars.extend(dependencies["extra_jars"])
                if "provided_families" in dependencies:
                    spark_dependencies.provided_families.extend(dependencies["provided_families"])
                proto_provider.spark.defaults.dependencies.CopyFrom(spark_dependencies)
            if "advanced" in config and isinstance(config["advanced"], dict):
                advanced = cast(dict[str, Any], config["advanced"])
                spark_conf = cast(dict[str, str], advanced.get("spark_conf") or {})
                proto_provider.spark.defaults.spark_conf.update(spark_conf)
            if "submission_defaults" in config and isinstance(config["submission_defaults"], dict):
                submission = config["submission_defaults"]
                if "app_name" in submission:
                    proto_provider.spark.defaults.submission_defaults.app_name = submission[
                        "app_name"
                    ]
                if "properties_file" in submission:
                    proto_provider.spark.defaults.submission_defaults.properties_file = submission[
                        "properties_file"
                    ]
                if "repositories" in submission:
                    proto_provider.spark.defaults.submission_defaults.repositories.extend(
                        submission["repositories"]
                    )
                if "files" in submission:
                    proto_provider.spark.defaults.submission_defaults.files.extend(
                        provider_pb2.SparkSubmissionArtifactRef(uri=item["uri"])
                        for item in submission["files"]
                    )
                if "archives" in submission:
                    proto_provider.spark.defaults.submission_defaults.archives.extend(
                        provider_pb2.SparkSubmissionArtifactRef(uri=item["uri"])
                        for item in submission["archives"]
                    )
                if "py_files" in submission:
                    proto_provider.spark.defaults.submission_defaults.py_files.extend(
                        provider_pb2.SparkSubmissionArtifactRef(uri=item["uri"])
                        for item in submission["py_files"]
                    )
                if "kerberos" in submission and isinstance(submission["kerberos"], dict):
                    kerberos = submission["kerberos"]
                    if "principal" in kerberos:
                        proto_provider.spark.defaults.submission_defaults.kerberos.principal = (
                            kerberos["principal"]
                        )
                    if "realm" in kerberos:
                        proto_provider.spark.defaults.submission_defaults.kerberos.realm = kerberos[
                            "realm"
                        ]
                    if "kdc_host" in kerberos:
                        proto_provider.spark.defaults.submission_defaults.kerberos.kdc_host = (
                            kerberos["kdc_host"]
                        )
                    if "keytab_secret" in kerberos:
                        secret_ref = _secret_ref_to_proto(kerberos["keytab_secret"], provider_pb2)
                        if secret_ref is not None:
                            proto_provider.spark.defaults.submission_defaults.kerberos.keytab_secret.CopyFrom(
                                secret_ref
                            )
                    if "krb5_conf_secret" in kerberos:
                        secret_ref = _secret_ref_to_proto(
                            kerberos["krb5_conf_secret"], provider_pb2
                        )
                        if secret_ref is not None:
                            proto_provider.spark.defaults.submission_defaults.kerberos.krb5_conf_secret.CopyFrom(
                                secret_ref
                            )
            return proto_provider

        if provider_type == ProviderType.DYNAMODB:
            if "region" in config:
                proto_provider.dynamodb.region = config["region"]
            if "endpoint" in config:
                proto_provider.dynamodb.endpoint = config["endpoint"]
            if "table_prefix" in config:
                proto_provider.dynamodb.table_prefix = config["table_prefix"]
            if "access_key_id_secret" in config:
                access_key = _secret_ref_to_proto(config["access_key_id_secret"], provider_pb2)
                if access_key is not None:
                    proto_provider.dynamodb.access_key_id_secret.CopyFrom(access_key)
            if "secret_access_key_secret" in config:
                secret_key = _secret_ref_to_proto(config["secret_access_key_secret"], provider_pb2)
                if secret_key is not None:
                    proto_provider.dynamodb.secret_access_key_secret.CopyFrom(secret_key)
            return proto_provider

        if provider_type == ProviderType.KAFKA:
            if "brokers" in config:
                proto_provider.kafka.brokers.extend(config["brokers"])
            if "sasl_username" in config:
                proto_provider.kafka.sasl_username = config["sasl_username"]
            if "sasl_password_secret" in config:
                sasl_password_secret = _secret_ref_to_proto(
                    config["sasl_password_secret"], provider_pb2
                )
                if sasl_password_secret is not None:
                    proto_provider.kafka.sasl_password_secret.CopyFrom(sasl_password_secret)
            if "sasl_mechanism" in config:
                proto_provider.kafka.sasl_mechanism = config["sasl_mechanism"]
            if "oauth_client_id" in config:
                proto_provider.kafka.oauth_client_id = config["oauth_client_id"]
            if "oauth_client_secret" in config:
                oauth_client_secret = _secret_ref_to_proto(
                    config["oauth_client_secret"], provider_pb2
                )
                if oauth_client_secret is not None:
                    proto_provider.kafka.oauth_client_secret.CopyFrom(oauth_client_secret)
            if "oauth_token_url" in config:
                proto_provider.kafka.oauth_token_url = config["oauth_token_url"]
            if "mtls_client_cert_secret" in config:
                mtls_client_cert_secret = _secret_ref_to_proto(
                    config["mtls_client_cert_secret"], provider_pb2
                )
                if mtls_client_cert_secret is not None:
                    proto_provider.kafka.mtls_client_cert_secret.CopyFrom(mtls_client_cert_secret)
            if "mtls_client_key_secret" in config:
                mtls_client_key_secret = _secret_ref_to_proto(
                    config["mtls_client_key_secret"], provider_pb2
                )
                if mtls_client_key_secret is not None:
                    proto_provider.kafka.mtls_client_key_secret.CopyFrom(mtls_client_key_secret)
            return proto_provider

        if provider_type == ProviderType.REDIS:
            if "host" in config:
                proto_provider.redis.host = config["host"]
            if "port" in config:
                proto_provider.redis.port = config["port"]
            if "database" in config:
                proto_provider.redis.db = config["database"]
            if "password_secret" in config:
                password_secret = _secret_ref_to_proto(config["password_secret"], provider_pb2)
                if password_secret is not None:
                    proto_provider.redis.password_secret.CopyFrom(password_secret)
            redis_tls = _redis_tls_dict_to_proto(config, provider_pb2)
            if redis_tls is not None:
                proto_provider.redis.tls.CopyFrom(redis_tls)
            return proto_provider

        if provider_type == ProviderType.REDIS_CLUSTER:
            if "endpoints" in config:
                proto_provider.redis_cluster.endpoints.extend(config["endpoints"])
            if "password_secret" in config:
                password_secret = _secret_ref_to_proto(config["password_secret"], provider_pb2)
                if password_secret is not None:
                    proto_provider.redis_cluster.password_secret.CopyFrom(password_secret)
            redis_tls = _redis_tls_dict_to_proto(config, provider_pb2)
            if redis_tls is not None:
                proto_provider.redis_cluster.tls.CopyFrom(redis_tls)
            return proto_provider

        return proto_provider

    def _proto_to_provider(
        self,
        proto_p: provider_pb2.Provider,
    ) -> Provider:
        """Convert proto provider to Provider model."""
        from datetime import datetime, timezone

        from featureform._generated.proto.featureform.v2 import provider_pb2
        from featureform.errors import InvalidArgumentError
        from featureform.types.provider import ProviderHealth, ProviderHealthStatus

        created_at = (
            datetime.fromtimestamp(
                proto_p.created_at.seconds + proto_p.created_at.nanos / 1e9,
                tz=timezone.utc,
            )
            if proto_p.HasField("created_at")
            else datetime.now(timezone.utc)
        )

        updated_at = (
            datetime.fromtimestamp(
                proto_p.updated_at.seconds + proto_p.updated_at.nanos / 1e9,
                tz=timezone.utc,
            )
            if proto_p.HasField("updated_at")
            else created_at
        )

        # Map proto type to our enum
        type_map = {
            provider_pb2.PROVIDER_TYPE_ICEBERG_CATALOG: ProviderType.ICEBERG,
            provider_pb2.PROVIDER_TYPE_POSTGRES: ProviderType.POSTGRES,
            provider_pb2.PROVIDER_TYPE_SNOWFLAKE: ProviderType.SNOWFLAKE,
            provider_pb2.PROVIDER_TYPE_S3: ProviderType.S3,
            provider_pb2.PROVIDER_TYPE_SPARK: ProviderType.SPARK,
            provider_pb2.PROVIDER_TYPE_DYNAMODB: ProviderType.DYNAMODB,
            provider_pb2.PROVIDER_TYPE_REDIS: ProviderType.REDIS,
            provider_pb2.PROVIDER_TYPE_REDIS_CLUSTER: ProviderType.REDIS_CLUSTER,
            provider_pb2.PROVIDER_TYPE_KAFKA: ProviderType.KAFKA,
        }
        try:
            p_type = type_map[proto_p.type]
        except KeyError as exc:
            raise InvalidArgumentError(
                f"unsupported provider type from gRPC server: {proto_p.type}"
            ) from exc

        config: ProviderConfig
        if proto_p.HasField("iceberg_catalog"):
            ic = proto_p.iceberg_catalog
            config_payload: dict[str, Any] = {}
            if ic.HasField("backend"):
                backend_payload: dict[str, Any] = {}
                if ic.backend.HasField("hive"):
                    backend_payload["hive"] = {"uri": ic.backend.hive.uri}
                if ic.backend.HasField("rest"):
                    backend_payload["rest"] = {
                        "uri": ic.backend.rest.uri,
                        "credential": _secret_ref_to_dict(
                            _secret_ref_from_proto(ic.backend.rest.credential_secret)
                        ),
                        "prefix": ic.backend.rest.prefix or None,
                    }
                if ic.backend.HasField("glue"):
                    backend_payload["glue"] = {
                        "region": ic.backend.glue.region,
                        "catalog_id": ic.backend.glue.catalog_id or None,
                    }
                if ic.backend.HasField("sql"):
                    backend_payload["sql"] = {
                        "driver": ic.backend.sql.driver,
                        "connection_string": _secret_ref_to_dict(
                            _secret_ref_from_proto(ic.backend.sql.connection_string_secret)
                        ),
                    }
                config_payload["backend"] = backend_payload
            if ic.HasField("warehouse"):
                warehouse_payload: dict[str, Any] = {}
                if ic.warehouse.HasField("s3"):
                    warehouse_payload["s3"] = {
                        "provider": ic.warehouse.s3.provider,
                        "prefix": ic.warehouse.s3.prefix or None,
                    }
                if ic.warehouse.HasField("hdfs"):
                    warehouse_payload["hdfs"] = {
                        "provider": ic.warehouse.hdfs.provider,
                        "path": ic.warehouse.hdfs.path,
                    }
                config_payload["warehouse"] = warehouse_payload
            config = IcebergCatalogConfig.model_validate(config_payload)
        elif proto_p.HasField("postgres"):
            from featureform.types.provider import SSLMode

            ssl_mode_map = {
                provider_pb2.SSL_MODE_DISABLE: SSLMode.DISABLE.value,
                provider_pb2.SSL_MODE_ALLOW: SSLMode.ALLOW.value,
                provider_pb2.SSL_MODE_PREFER: SSLMode.PREFER.value,
                provider_pb2.SSL_MODE_REQUIRE: SSLMode.REQUIRE.value,
                provider_pb2.SSL_MODE_VERIFY_CA: SSLMode.VERIFY_CA.value,
                provider_pb2.SSL_MODE_VERIFY_FULL: SSLMode.VERIFY_FULL.value,
            }
            config = PostgresConfig.model_validate(
                {
                    "host": proto_p.postgres.host,
                    "port": proto_p.postgres.port,
                    "database": proto_p.postgres.database,
                    "user": proto_p.postgres.username,
                    "password_secret": _secret_ref_to_dict(
                        _secret_ref_from_proto(proto_p.postgres.password_secret)
                    ),
                    "ssl_mode": ssl_mode_map.get(proto_p.postgres.ssl_mode, SSLMode.PREFER.value),
                }
            )
        elif proto_p.HasField("spark"):
            runtime_profile_backend = proto_p.spark.defaults.runtime_profile.backend or None
            runtime_profile_spark_version = (
                proto_p.spark.defaults.runtime_profile.spark_version or None
            )
            runtime_profile_scala_binary_version = (
                proto_p.spark.defaults.runtime_profile.scala_binary_version or None
            )
            runtime_profile: dict[str, str | None] | None = None
            if any(
                (
                    runtime_profile_backend,
                    runtime_profile_spark_version,
                    runtime_profile_scala_binary_version,
                )
            ):
                runtime_profile = {
                    "backend": runtime_profile_backend,
                    "spark_version": runtime_profile_spark_version,
                    "scala_binary_version": runtime_profile_scala_binary_version,
                }

            config = SparkProviderConfig.model_validate(
                {
                    "catalogs": dict(proto_p.spark.defaults.catalogs),
                    "backend": _spark_backend_from_proto(proto_p.spark.backend),
                    "hadoop": (
                        {
                            "s3a_provider": proto_p.spark.hadoop.s3a_provider or None,
                            "path_style": proto_p.spark.hadoop.path_style,
                        }
                        if proto_p.spark.HasField("hadoop")
                        else None
                    ),
                    "staging": (
                        {
                            "provider": proto_p.spark.staging.provider or None,
                            "prefix": proto_p.spark.staging.prefix or None,
                        }
                        if proto_p.spark.HasField("staging")
                        else None
                    ),
                    "driver_env": {
                        "values": dict(proto_p.spark.defaults.driver_env.values),
                        "secrets": {
                            key: _secret_ref_from_proto(value)
                            for key, value in proto_p.spark.defaults.driver_env.secrets.items()
                        },
                    },
                    "executor_env": {
                        "values": dict(proto_p.spark.defaults.executor_env.values),
                        "secrets": {
                            key: _secret_ref_from_proto(value)
                            for key, value in proto_p.spark.defaults.executor_env.secrets.items()
                        },
                    },
                    "deploy_mode": proto_p.spark.defaults.deploy_mode or None,
                    "runtime_profile": runtime_profile,
                    "execution_defaults": {
                        "driver_cores": proto_p.spark.defaults.execution_defaults.driver_cores
                        or None,
                        "driver_memory": proto_p.spark.defaults.execution_defaults.driver_memory
                        or None,
                        "executor_memory": proto_p.spark.defaults.execution_defaults.executor_memory
                        or None,
                        "executor_cores": proto_p.spark.defaults.execution_defaults.executor_cores
                        or None,
                        "num_executors": proto_p.spark.defaults.execution_defaults.num_executors
                        or None,
                        "shuffle_partitions": proto_p.spark.defaults.execution_defaults.shuffle_partitions
                        or None,
                    },
                    "dependencies": {
                        "versions": {
                            "iceberg": proto_p.spark.defaults.dependencies.versions.iceberg or None,
                            "iceberg_aws_bundle": proto_p.spark.defaults.dependencies.versions.iceberg_aws_bundle
                            or None,
                            "hadoop_aws": proto_p.spark.defaults.dependencies.versions.hadoop_aws
                            or None,
                            "aws_java_sdk_bundle": proto_p.spark.defaults.dependencies.versions.aws_java_sdk_bundle
                            or None,
                            "postgres_jdbc": proto_p.spark.defaults.dependencies.versions.postgres_jdbc
                            or None,
                        },
                        "package_overrides": dict(
                            proto_p.spark.defaults.dependencies.package_overrides
                        ),
                        "extra_packages": list(proto_p.spark.defaults.dependencies.extra_packages),
                        "extra_jars": list(proto_p.spark.defaults.dependencies.extra_jars),
                        "provided_families": list(
                            proto_p.spark.defaults.dependencies.provided_families
                        ),
                    },
                    "advanced": {
                        "spark_conf": dict(proto_p.spark.defaults.spark_conf),
                    },
                    "submission_defaults": {
                        "app_name": proto_p.spark.defaults.submission_defaults.app_name or None,
                        "properties_file": proto_p.spark.defaults.submission_defaults.properties_file
                        or None,
                        "repositories": list(
                            proto_p.spark.defaults.submission_defaults.repositories
                        ),
                        "files": [
                            {"uri": item.uri}
                            for item in proto_p.spark.defaults.submission_defaults.files
                        ],
                        "archives": [
                            {"uri": item.uri}
                            for item in proto_p.spark.defaults.submission_defaults.archives
                        ],
                        "py_files": [
                            {"uri": item.uri}
                            for item in proto_p.spark.defaults.submission_defaults.py_files
                        ],
                        "kerberos": (
                            {
                                "principal": proto_p.spark.defaults.submission_defaults.kerberos.principal
                                or None,
                                "realm": proto_p.spark.defaults.submission_defaults.kerberos.realm
                                or None,
                                "kdc_host": proto_p.spark.defaults.submission_defaults.kerberos.kdc_host
                                or None,
                                "keytab_secret": _secret_ref_to_dict(
                                    _secret_ref_from_proto(
                                        proto_p.spark.defaults.submission_defaults.kerberos.keytab_secret
                                    )
                                ),
                                "krb5_conf_secret": _secret_ref_to_dict(
                                    _secret_ref_from_proto(
                                        proto_p.spark.defaults.submission_defaults.kerberos.krb5_conf_secret
                                    )
                                ),
                            }
                            if proto_p.spark.defaults.submission_defaults.HasField("kerberos")
                            else None
                        ),
                    },
                    "spark_conf": dict(proto_p.spark.defaults.spark_conf),
                    "max_execution_time": proto_p.spark.defaults.max_execution_time or None,
                }
            )
        elif proto_p.HasField("redis"):
            config_dict = {
                "host": proto_p.redis.host,
                "port": proto_p.redis.port,
                "database": proto_p.redis.db,
                "password_secret": _secret_ref_to_dict(
                    _secret_ref_from_proto(proto_p.redis.password_secret)
                ),
            }
            redis_tls = _redis_tls_from_proto(proto_p.redis.tls)
            if redis_tls is not None:
                config_dict["tls"] = redis_tls
            config = RedisConfig.model_validate(config_dict)
        elif proto_p.HasField("redis_cluster"):
            config_dict = {
                "endpoints": list(proto_p.redis_cluster.endpoints),
                "password_secret": _secret_ref_to_dict(
                    _secret_ref_from_proto(proto_p.redis_cluster.password_secret)
                ),
            }
            redis_tls = _redis_tls_from_proto(proto_p.redis_cluster.tls)
            if redis_tls is not None:
                config_dict["tls"] = redis_tls
            config = RedisClusterConfig.model_validate(config_dict)
        elif proto_p.HasField("s3"):
            bucket = proto_p.s3.bucket
            if proto_p.s3.path_prefix:
                bucket = f"s3://{bucket}/{proto_p.s3.path_prefix.lstrip('/')}"
            config = S3Config.model_validate(
                {
                    "bucket": bucket,
                    "region": proto_p.s3.region,
                    "endpoint": proto_p.s3.endpoint or None,
                    "path_style_access": bool(proto_p.s3.path_style_access),
                    "access_key_id_secret": _secret_ref_to_dict(
                        _secret_ref_from_proto(proto_p.s3.access_key_id_secret)
                    ),
                    "secret_access_key_secret": _secret_ref_to_dict(
                        _secret_ref_from_proto(proto_p.s3.secret_access_key_secret)
                    ),
                }
            )
        elif proto_p.HasField("dynamodb"):
            config = DynamoDBConfig.model_validate(
                {
                    "region": proto_p.dynamodb.region,
                    "endpoint": proto_p.dynamodb.endpoint,
                    "access_key_id_secret": _secret_ref_to_dict(
                        _secret_ref_from_proto(proto_p.dynamodb.access_key_id_secret)
                    ),
                    "secret_access_key_secret": _secret_ref_to_dict(
                        _secret_ref_from_proto(proto_p.dynamodb.secret_access_key_secret)
                    ),
                    "table_prefix": proto_p.dynamodb.table_prefix,
                }
            )
        elif proto_p.HasField("snowflake"):
            config = SnowflakeConfig.model_validate(
                {
                    "account": proto_p.snowflake.account,
                    "host": proto_p.snowflake.host or None,
                    "auth_type": {
                        provider_pb2.SNOWFLAKE_AUTH_TYPE_PASSWORD: "password",
                        provider_pb2.SNOWFLAKE_AUTH_TYPE_KEY_PAIR: "key-pair",
                        provider_pb2.SNOWFLAKE_AUTH_TYPE_OAUTH: "oauth",
                    }.get(proto_p.snowflake.auth_type, "password"),
                    "username": proto_p.snowflake.username or None,
                    "password_secret": _secret_ref_to_dict(
                        _secret_ref_from_proto(proto_p.snowflake.password_secret)
                    ),
                    "private_key_secret": _secret_ref_to_dict(
                        _secret_ref_from_proto(proto_p.snowflake.private_key_secret)
                    ),
                    "passphrase_secret": _secret_ref_to_dict(
                        _secret_ref_from_proto(proto_p.snowflake.passphrase_secret)
                    ),
                    "oauth_client_id": proto_p.snowflake.oauth_client_id or None,
                    "oauth_client_secret": _secret_ref_to_dict(
                        _secret_ref_from_proto(proto_p.snowflake.oauth_client_secret)
                    ),
                    "oauth_token": _secret_ref_to_dict(
                        _secret_ref_from_proto(proto_p.snowflake.oauth_token)
                    ),
                    "database": proto_p.snowflake.database,
                    "schema": proto_p.snowflake.schema,
                    "warehouse": proto_p.snowflake.warehouse,
                    "role": proto_p.snowflake.role or None,
                    "login_timeout": proto_p.snowflake.login_timeout or None,
                    "request_timeout": proto_p.snowflake.request_timeout or None,
                    "session_params": dict(proto_p.snowflake.session_params),
                }
            )
        elif proto_p.HasField("kafka"):
            kafka_config_dict: dict[str, Any] = {
                "brokers": list(proto_p.kafka.brokers),
            }
            if proto_p.kafka.sasl_username:
                kafka_config_dict["sasl_username"] = proto_p.kafka.sasl_username
            sasl_password_secret = _secret_ref_to_dict(
                _secret_ref_from_proto(proto_p.kafka.sasl_password_secret)
            )
            if sasl_password_secret is not None:
                kafka_config_dict["sasl_password_secret"] = sasl_password_secret
            if proto_p.kafka.sasl_mechanism:
                kafka_config_dict["sasl_mechanism"] = proto_p.kafka.sasl_mechanism
            if proto_p.kafka.oauth_client_id:
                kafka_config_dict["oauth_client_id"] = proto_p.kafka.oauth_client_id
            oauth_client_secret = _secret_ref_to_dict(
                _secret_ref_from_proto(proto_p.kafka.oauth_client_secret)
            )
            if oauth_client_secret is not None:
                kafka_config_dict["oauth_client_secret"] = oauth_client_secret
            if proto_p.kafka.oauth_token_url:
                kafka_config_dict["oauth_token_url"] = proto_p.kafka.oauth_token_url
            mtls_client_cert_secret = _secret_ref_to_dict(
                _secret_ref_from_proto(proto_p.kafka.mtls_client_cert_secret)
            )
            if mtls_client_cert_secret is not None:
                kafka_config_dict["mtls_client_cert_secret"] = mtls_client_cert_secret
            mtls_client_key_secret = _secret_ref_to_dict(
                _secret_ref_from_proto(proto_p.kafka.mtls_client_key_secret)
            )
            if mtls_client_key_secret is not None:
                kafka_config_dict["mtls_client_key_secret"] = mtls_client_key_secret
            config = KafkaConfig.model_validate(kafka_config_dict)
        else:
            raise InvalidArgumentError(f"provider config missing for gRPC provider: {proto_p.name}")

        health = None
        if proto_p.HasField("health"):
            status_map = {
                provider_pb2.PROVIDER_HEALTH_STATUS_UNKNOWN: ProviderHealthStatus.UNKNOWN,
                provider_pb2.PROVIDER_HEALTH_STATUS_HEALTHY: ProviderHealthStatus.HEALTHY,
                provider_pb2.PROVIDER_HEALTH_STATUS_UNHEALTHY: ProviderHealthStatus.UNHEALTHY,
            }
            status = status_map.get(proto_p.health.status)
            if status is not None:
                checked_at = None
                if proto_p.health.HasField("checked_at"):
                    checked_at = datetime.fromtimestamp(
                        proto_p.health.checked_at.seconds + proto_p.health.checked_at.nanos / 1e9,
                        tz=timezone.utc,
                    )

                health = ProviderHealth(
                    status=status,
                    message=proto_p.health.message or None,
                    checked_at=checked_at,
                    latency_ms=proto_p.health.latency_ms,
                    consecutive_failures=proto_p.health.consecutive_failures,
                )

        return Provider(
            workspace_id=UUID(proto_p.workspace_id),
            name=proto_p.name,
            type=p_type,
            config=config,
            created_at=created_at,
            updated_at=updated_at,
            health=health,
        )


class SecretProviderClientBase:
    """Base class for secret provider client operations."""

    def register(
        self,
        name: str,
        provider_type: SecretProviderType,
        config: SecretProviderConfig,
        description: str | None = None,
    ) -> SecretProvider:
        """Register a new secret provider."""
        raise NotImplementedError

    def get(self, name: str) -> SecretProvider:
        """Get a secret provider by name."""
        raise NotImplementedError

    def list(self) -> list[SecretProvider]:
        """List all secret providers in the workspace."""
        raise NotImplementedError

    def delete(self, name: str) -> None:
        """Delete a secret provider."""
        raise NotImplementedError

    def update(
        self,
        name: str,
        config: SecretProviderConfig,
        force: bool = False,
        provider_type: SecretProviderType | None = None,
        description: str | None = None,
    ) -> SecretProvider:
        """Update a secret provider."""
        raise NotImplementedError


class SecretProviderClient(SecretProviderClientBase):
    """REST client for secret provider operations."""

    def __init__(self, transport: RESTTransport, workspace_id: UUID) -> None:
        """Initialize secret provider client."""
        self._transport = transport
        self._workspace_id = workspace_id
        self._logger = get_logger("featureform.client.secret_provider")

    def register(
        self,
        name: str,
        provider_type: SecretProviderType,
        config: SecretProviderConfig,
        description: str | None = None,
    ) -> SecretProvider:
        """Register a new secret provider.

        Args:
            name: Provider name.
            provider_type: Type of secret provider.
            config: Provider configuration.

        Returns:
            Registered secret provider.
        """
        self._logger.debug(
            "secret_provider_register_start",
            name=name,
            provider_type=str(provider_type),
            workspace_id=str(self._workspace_id),
        )
        secret_provider_input = SecretProviderInput(
            name=name,
            type=provider_type,
            config=config,
            description=description,
        )
        request = RegisterSecretProviderRequest(secret_provider=secret_provider_input)
        response = self._transport.post(
            f"/api/v1/workspaces/{self._workspace_id}/secret-providers",
            json=request.model_dump(exclude_none=True, mode="json"),
        )
        provider = self._parse_secret_provider(response)
        self._logger.debug("secret_provider_register_complete", name=provider.name)
        return provider

    def get(self, name: str) -> SecretProvider:
        """Get a secret provider by name.

        Args:
            name: Provider name.

        Returns:
            SecretProvider.
        """
        self._logger.debug("secret_provider_get", name=name)
        response = self._transport.get(
            f"/api/v1/workspaces/{self._workspace_id}/secret-providers/{name}"
        )
        return self._parse_secret_provider(response)

    def list(self) -> list[SecretProvider]:
        """List all secret providers in the workspace.

        Returns:
            List of secret providers.
        """
        self._logger.debug("secret_provider_list", workspace_id=str(self._workspace_id))
        response = self._transport.get(f"/api/v1/workspaces/{self._workspace_id}/secret-providers")
        providers_data = response.data.get("secret_providers", [])
        return [self._parse_secret_provider_data(cast(dict[str, Any], p)) for p in providers_data]

    def delete(self, name: str) -> None:
        """Delete a secret provider.

        Args:
            name: Provider name.
        """
        self._logger.debug("secret_provider_delete", name=name)
        self._transport.delete(f"/api/v1/workspaces/{self._workspace_id}/secret-providers/{name}")

    def update(
        self,
        name: str,
        config: SecretProviderConfig,
        force: bool = False,
        provider_type: SecretProviderType | None = None,
        description: str | None = None,
    ) -> SecretProvider:
        """Update an existing secret provider.

        Args:
            name: Provider name.
            config: Updated provider configuration.
            force: Force potentially breaking changes (e.g., address changes).
            provider_type: Provider type. If provided, skips a redundant API call
                to fetch the existing provider. Use this when you already have
                the provider type from a previous get() call.

        Returns:
            Updated secret provider.
        """
        self._logger.debug(
            "secret_provider_update_start",
            name=name,
            workspace_id=str(self._workspace_id),
            force=force,
        )
        # Get existing provider to preserve type only if provider_type not provided.
        # This avoids a redundant API call when the caller already has the type.
        if provider_type is None:
            existing = self.get(name)
            provider_type = existing.type

        secret_provider_input = SecretProviderInput(
            name=name,
            type=provider_type,
            config=config,
            description=description,
        )
        request = UpdateSecretProviderRequest(
            secret_provider=secret_provider_input,
            force=force,
        )
        response = self._transport.put(
            f"/api/v1/workspaces/{self._workspace_id}/secret-providers/{name}",
            json=request.model_dump(exclude_none=True, mode="json"),
        )
        provider = self._parse_secret_provider(response)
        self._logger.debug("secret_provider_update_complete", name=provider.name)
        return provider

    def _parse_secret_provider(self, response: Response) -> SecretProvider:
        """Parse secret provider from response."""
        provider_data = response.data.get("secret_provider", response.data)
        return self._parse_secret_provider_data(cast(dict[str, Any], provider_data))

    def _parse_secret_provider_data(self, provider_data: dict[str, Any]) -> SecretProvider:
        typed_data = dict(provider_data)
        provider_type = SecretProviderType(typed_data["type"])
        typed_data["config"] = _secret_provider_config_from_payload(
            provider_type,
            cast(dict[str, Any], typed_data.get("config", {})),
        )
        return SecretProvider.model_validate(typed_data)


class GRPCSecretProviderClient(SecretProviderClientBase):
    """gRPC client for secret provider operations."""

    def __init__(self, transport: GRPCTransport, workspace_id: UUID) -> None:
        """Initialize gRPC secret provider client."""
        self._transport = transport
        self._workspace_id = workspace_id
        self._logger = get_logger("featureform.client.secret_provider.grpc")

    def register(
        self,
        name: str,
        provider_type: SecretProviderType,
        config: SecretProviderConfig,
        description: str | None = None,
    ) -> SecretProvider:
        """Register a new secret provider via gRPC."""
        import grpc

        from featureform.transport.grpc import grpc_error_to_exception, secret_provider_pb2

        self._logger.debug(
            "secret_provider_register_start",
            name=name,
            provider_type=str(provider_type),
            workspace_id=str(self._workspace_id),
        )

        provider = self._config_to_proto(name, provider_type, config, description)
        request = secret_provider_pb2.RegisterSecretProviderRequest(
            workspace_id=str(self._workspace_id),
            provider=provider,
        )
        try:
            response = self._transport.secret_provider.RegisterSecretProvider(request)
            result = self._proto_to_secret_provider(response.provider)
            self._logger.debug("secret_provider_register_complete", name=result.name)
            return result
        except grpc.RpcError as e:
            raise grpc_error_to_exception(e) from e

    def get(self, name: str) -> SecretProvider:
        """Get a secret provider by name via gRPC."""
        import grpc

        from featureform.transport.grpc import grpc_error_to_exception, secret_provider_pb2

        self._logger.debug("secret_provider_get", name=name)
        request = secret_provider_pb2.GetSecretProviderRequest(
            workspace_id=str(self._workspace_id),
            name=name,
        )
        try:
            response = self._transport.secret_provider.GetSecretProvider(request)
            return self._proto_to_secret_provider(response.provider)
        except grpc.RpcError as e:
            raise grpc_error_to_exception(e) from e

    def list(self) -> list[SecretProvider]:
        """List all secret providers in the workspace via gRPC."""
        import grpc

        from featureform.transport.grpc import grpc_error_to_exception, secret_provider_pb2

        self._logger.debug("secret_provider_list", workspace_id=str(self._workspace_id))
        request = secret_provider_pb2.ListSecretProvidersRequest(
            workspace_id=str(self._workspace_id),
        )
        try:
            response = self._transport.secret_provider.ListSecretProviders(request)
            return [self._proto_to_secret_provider(p) for p in response.providers]
        except grpc.RpcError as e:
            raise grpc_error_to_exception(e) from e

    def delete(self, name: str) -> None:
        """Delete a secret provider via gRPC."""
        import grpc

        from featureform.transport.grpc import grpc_error_to_exception, secret_provider_pb2

        self._logger.debug("secret_provider_delete", name=name)
        request = secret_provider_pb2.DeleteSecretProviderRequest(
            workspace_id=str(self._workspace_id),
            name=name,
        )
        try:
            self._transport.secret_provider.DeleteSecretProvider(request)
        except grpc.RpcError as e:
            raise grpc_error_to_exception(e) from e

    def update(
        self,
        name: str,
        config: SecretProviderConfig,
        force: bool = False,
        provider_type: SecretProviderType | None = None,
        description: str | None = None,
    ) -> SecretProvider:
        """Update an existing secret provider via gRPC."""
        import grpc

        from featureform.transport.grpc import grpc_error_to_exception, secret_provider_pb2

        self._logger.debug(
            "secret_provider_update_start",
            name=name,
            workspace_id=str(self._workspace_id),
            force=force,
        )

        if provider_type is None:
            existing = self.get(name)
            provider_type = existing.type

        provider = self._config_to_proto(name, provider_type, config, description)
        request = secret_provider_pb2.UpdateSecretProviderRequest(
            workspace_id=str(self._workspace_id),
            provider=provider,
            force=force,
        )
        try:
            response = self._transport.secret_provider.UpdateSecretProvider(request)
            result = self._proto_to_secret_provider(response.provider)
            self._logger.debug("secret_provider_update_complete", name=result.name)
            return result
        except grpc.RpcError as e:
            raise grpc_error_to_exception(e) from e

    def _config_to_proto(
        self,
        name: str,
        provider_type: SecretProviderType,
        config: SecretProviderConfig,
        description: str | None = None,
    ) -> Any:
        """Convert config to proto SecretProvider."""
        from featureform._generated.proto.featureform.v2 import secret_provider_pb2

        # Map provider type to proto enum
        type_map = {
            SecretProviderType.ENV: secret_provider_pb2.SECRET_PROVIDER_TYPE_ENV,
            SecretProviderType.VAULT: secret_provider_pb2.SECRET_PROVIDER_TYPE_VAULT,
            SecretProviderType.K8S: secret_provider_pb2.SECRET_PROVIDER_TYPE_K8S,
            SecretProviderType.AWS: (secret_provider_pb2.SECRET_PROVIDER_TYPE_AWS_SECRETS_MANAGER),
        }
        proto_type = type_map.get(
            provider_type, secret_provider_pb2.SECRET_PROVIDER_TYPE_UNSPECIFIED
        )

        provider = secret_provider_pb2.SecretProvider(
            workspace_id=str(self._workspace_id),
            name=name,
            type=proto_type,
        )
        if description is not None:
            provider.description = description

        # Set type-specific config
        if isinstance(config, EnvSecretConfig):
            provider.env.CopyFrom(secret_provider_pb2.EnvConfig(prefix=config.prefix))
        elif isinstance(config, AWSSecretsManagerSecretConfig):
            provider.aws_secrets_manager.CopyFrom(
                secret_provider_pb2.AWSSecretsManagerConfig(
                    region=config.region,
                    secret_name=config.secret_name or "",
                    endpoint=config.endpoint or "",
                    access_key_id_secret=secret_ref_to_string(config.access_key_id_secret) or "",
                    secret_access_key_secret=secret_ref_to_string(config.secret_access_key_secret)
                    or "",
                    session_token_secret=secret_ref_to_string(config.session_token_secret) or "",
                )
            )
        elif isinstance(config, VaultSecretConfig):
            vault_config = secret_provider_pb2.VaultConfig(
                address=config.address,
                mount_path=config.mount_path,
                namespace=config.namespace or "",
            )
            if config.token_path is not None:
                vault_config.token_path.path = config.token_path
            provider.vault.CopyFrom(vault_config)
        else:
            provider.k8s.CopyFrom(
                secret_provider_pb2.K8sConfig(
                    namespace=config.namespace,
                    secret_name=config.secret_name or "",
                )
            )

        return provider

    def _proto_to_secret_provider(
        self,
        proto_sp: secret_provider_pb2.SecretProvider,
    ) -> SecretProvider:
        """Convert proto secret provider to SecretProvider model."""
        from datetime import datetime, timezone

        from featureform._generated.proto.featureform.v2 import secret_provider_pb2

        created_at = (
            datetime.fromtimestamp(
                proto_sp.created_at.seconds + proto_sp.created_at.nanos / 1e9,
                tz=timezone.utc,
            )
            if proto_sp.HasField("created_at")
            else datetime.now(timezone.utc)
        )

        updated_at = (
            datetime.fromtimestamp(
                proto_sp.updated_at.seconds + proto_sp.updated_at.nanos / 1e9,
                tz=timezone.utc,
            )
            if proto_sp.HasField("updated_at")
            else created_at
        )

        # Map proto type to our enum
        type_map = {
            secret_provider_pb2.SECRET_PROVIDER_TYPE_ENV: SecretProviderType.ENV,
            secret_provider_pb2.SECRET_PROVIDER_TYPE_VAULT: SecretProviderType.VAULT,
            secret_provider_pb2.SECRET_PROVIDER_TYPE_K8S: SecretProviderType.K8S,
            secret_provider_pb2.SECRET_PROVIDER_TYPE_AWS_SECRETS_MANAGER: (SecretProviderType.AWS),
        }
        sp_type = type_map.get(proto_sp.type, SecretProviderType.ENV)

        config: SecretProviderConfig
        if proto_sp.HasField("env"):
            config = EnvSecretConfig(prefix=proto_sp.env.prefix, allow_defaults=False)
        elif proto_sp.HasField("vault"):
            config = VaultSecretConfig.model_validate(
                {
                    "address": proto_sp.vault.address,
                    "mount_path": proto_sp.vault.mount_path,
                    "namespace": proto_sp.vault.namespace or None,
                    "token_path": (
                        proto_sp.vault.token_path.path
                        if proto_sp.vault.HasField("token_path")
                        else None
                    ),
                }
            )
        elif proto_sp.HasField("k8s"):
            config = KubernetesSecretConfig(
                namespace=proto_sp.k8s.namespace,
                secret_name=proto_sp.k8s.secret_name or None,
            )
        elif proto_sp.HasField("aws_secrets_manager"):
            config = AWSSecretsManagerSecretConfig.model_validate(
                {
                    "region": proto_sp.aws_secrets_manager.region,
                    "secret_name": proto_sp.aws_secrets_manager.secret_name or None,
                    "endpoint": proto_sp.aws_secrets_manager.endpoint or None,
                    "access_key_id_secret": (
                        proto_sp.aws_secrets_manager.access_key_id_secret or None
                    ),
                    "secret_access_key_secret": (
                        proto_sp.aws_secrets_manager.secret_access_key_secret or None
                    ),
                    "session_token_secret": (
                        proto_sp.aws_secrets_manager.session_token_secret or None
                    ),
                }
            )
        else:
            raise InvalidArgumentError(
                f"secret provider config missing for gRPC secret provider: {proto_sp.name}"
            )

        return SecretProvider(
            workspace_id=UUID(proto_sp.workspace_id),
            name=proto_sp.name,
            description=proto_sp.description if proto_sp.HasField("description") else None,
            type=sp_type,
            config=config,
            created_at=created_at,
            updated_at=updated_at,
        )


class Client:
    """Main Featureform client.

    Example:
        >>> client = Client(base_url="http://localhost:8080")
        >>> workspace = client.workspaces.create(name="my-workspace")
        >>> print(workspace.id)
    """

    @staticmethod
    def _build_postgres_provider(provider: Provider) -> PostgresProvider:
        """Construct a PostgresProvider factory from a registered provider model."""
        from featureform.resources.provider import PostgresProvider

        config = provider.config
        if isinstance(config, dict):
            config_dict = cast(dict[str, Any], config)
            missing = [field for field in ("host", "database") if not config_dict.get(field)]
            if missing:
                raise MissingPostgresConfigError(
                    provider_name=provider.name,
                    missing_fields=tuple(missing),
                )
            config = PostgresConfig.model_validate(config_dict)
        elif not isinstance(config, PostgresConfig):
            raise ProviderTypeMismatchError(
                f"Provider '{provider.name}' is type '{provider.type}', expected '{ProviderType.POSTGRES}'"
            )

        missing = [
            field
            for field, value in (("host", config.host), ("database", config.database))
            if not value
        ]
        if missing:
            raise MissingPostgresConfigError(
                provider_name=provider.name,
                missing_fields=tuple(missing),
            )

        resource_provider = PostgresProvider(
            name=provider.name,
            host=config.host,
            port=config.port,
            database=config.database,
            user=config.user,
            password=config.password_secret,
            ssl_mode=config.ssl_mode.value,
        )
        resource_provider.mark_resolved(workspace_id=provider.workspace_id)
        return resource_provider

    @staticmethod
    def _build_snowflake_provider(provider: Provider) -> SnowflakeProvider:
        """Construct a SnowflakeProvider factory from a registered provider model."""
        from featureform.resources.provider import SnowflakeProvider

        config = provider.config
        if isinstance(config, dict):
            config_dict = cast(dict[str, Any], config)
            missing = [
                field
                for field in ("account", "warehouse", "database", "schema")
                if not config_dict.get(field)
            ]
            if missing:
                raise MissingSnowflakeConfigError(
                    provider_name=provider.name,
                    missing_fields=tuple(missing),
                )
            config = SnowflakeConfig.model_validate(config_dict)
        elif not isinstance(config, SnowflakeConfig):
            raise ProviderTypeMismatchError(
                f"Provider '{provider.name}' is type '{provider.type}', expected '{ProviderType.SNOWFLAKE}'"
            )

        missing = [
            field
            for field, value in (
                ("account", config.account),
                ("warehouse", config.warehouse),
                ("database", config.database),
                ("schema", config.schema),
            )
            if not value
        ]
        if missing:
            raise MissingSnowflakeConfigError(
                provider_name=provider.name,
                missing_fields=tuple(missing),
            )

        resource_provider = SnowflakeProvider(
            name=provider.name,
            account=config.account,
            host=config.host or "",
            warehouse=config.warehouse,
            database=config.database,
            schema=config.schema,
            auth_type=config.auth_type,
            username=config.username,
            password_secret=config.password_secret,
            private_key_secret=config.private_key_secret,
            passphrase_secret=config.passphrase_secret,
            oauth_client_id=config.oauth_client_id,
            oauth_client_secret=config.oauth_client_secret,
            oauth_token=config.oauth_token,
            role=config.role,
            login_timeout=config.login_timeout,
            request_timeout=config.request_timeout,
            session_params=dict(config.session_params or {}),
        )
        resource_provider.mark_resolved(workspace_id=provider.workspace_id)
        return resource_provider

    def __init__(
        self,
        base_url: str = "http://localhost:8080",
        rest_url: str | None = None,
        timeout: float = 30.0,
        verify_ssl: bool = True,
        token: str | None = None,
        config: Config | None = None,
        telemetry: TelemetryConfig | None = None,
        transport: TransportType | str | None = None,
        redis: Any | None = None,
        background_refresh: bool = True,
        refresh_interval: int = 30,
        default_workspace: str = "default",
    ) -> None:
        """Initialize Featureform client.

        Args:
            base_url: Base URL for the API.
            rest_url: Optional REST base URL used for serving metadata when the primary
                transport is gRPC.
            timeout: Request timeout in seconds.
            verify_ssl: Whether to verify SSL certificates.
            token: Optional explicit bearer token, including user OIDC access tokens,
                service-account tokens, and machine-credential assertion tokens.
            config: Optional Config object (overrides other args).
            telemetry: Optional telemetry configuration for tracing.
            transport: Transport type (rest/grpc). Auto-detected from URL if not specified.
            redis: Optional Redis client for BYOC serving (bring your own client).
            background_refresh: Enable background metadata refresh for serving.
            refresh_interval: Seconds between metadata refresh cycles.
            default_workspace: Default workspace for serving operations.
        """
        self._redis = redis
        self._rest_url = rest_url.rstrip("/") if rest_url is not None else None
        self._background_refresh = background_refresh
        self._refresh_interval = refresh_interval
        self._default_workspace = default_workspace
        self._serving_client: Any = None  # Lazy initialized
        if config is not None:
            self._config = config
        else:
            self._config = Config(
                base_url=base_url,
                timeout=timeout,
                verify_ssl=verify_ssl,
                token=token,
            )
        self._telemetry = telemetry

        # Determine transport type
        if transport is None:
            self._transport_type = detect_transport_type(self._config.base_url)
        elif isinstance(transport, str):
            self._transport_type = TransportType(transport.lower())
        else:
            self._transport_type = transport

        _logger.debug(
            "client_init",
            base_url=self._config.base_url,
            transport=self._transport_type.value,
        )

        # Create appropriate transport
        self._rest_transport: RESTTransport | None = None
        self._grpc_transport: GRPCTransport | None = None
        self._workspaces: WorkspaceClientBase

        if self._transport_type == TransportType.REST:
            self._rest_transport = RESTTransport(self._config, telemetry=telemetry)
            self._workspaces = WorkspaceClient(self._rest_transport)
        else:
            self._grpc_transport = GRPCTransport(self._config, telemetry=telemetry)
            self._workspaces = GRPCWorkspaceClient(self._grpc_transport)

    @classmethod
    def from_env(cls, telemetry: TelemetryConfig | None = None) -> Client:
        """Create a client from environment variables and shared auth state.

        Args:
            telemetry: Optional telemetry configuration for tracing.

        Returns:
            Configured client that prefers explicit env auth and otherwise reuses the
            active profile's stored session state.
        """
        resolved_config_path = normalize_config_path(cli_env.config_override())
        config = Config.from_env()
        base_url = config.base_url
        transport: TransportType

        if cli_env.env("FEATUREFORM_BASE_URL"):
            transport = detect_transport_type(base_url)
        else:
            from featureform.cli.auth import YAMLProfileRepository

            profile = YAMLProfileRepository(resolved_config_path).get_active_profile()
            if profile is not None:
                base_url = profile.server
                transport = TransportType(profile.transport.lower())
                config = config.model_copy(update={"base_url": base_url, "no_tls": profile.no_tls})
            else:
                transport = detect_transport_type(base_url)

        runtime_transport = transport.value
        token_provider = build_runtime_token_provider(
            timeout=config.timeout,
            verify_ssl=config.verify_ssl,
            no_tls=config.no_tls,
            ca_cert_path=config.ca_cert_path,
            client_cert_path=config.client_cert_path,
            client_key_path=config.client_key_path,
            config_path=resolved_config_path,
            auth_storage_mode=cli_env.env("FEATUREFORM_AUTH_STORAGE"),
            explicit_token=config.token,
            client_id=cli_env.env("FEATUREFORM_CLIENT_ID"),
            client_secret=cli_env.env("FEATUREFORM_CLIENT_SECRET"),
            issuer_url=cli_env.env("FEATUREFORM_ISSUER_URL"),
            server_url=base_url,
            transport=runtime_transport,
        )
        config = config.model_copy(update={"token_provider": token_provider})
        return cls(config=config, telemetry=telemetry, transport=transport)

    @classmethod
    def from_profile(
        cls,
        *,
        profile_name: str | None = None,
        base_url: str | None = None,
        rest_url: str | None = None,
        timeout: float = 30.0,
        verify_ssl: bool = True,
        no_tls: bool | None = None,
        ca_cert_path: str | None = None,
        client_cert_path: str | None = None,
        client_key_path: str | None = None,
        token: str | None = None,
        client_id: str | None = None,
        client_secret: str | None = None,
        issuer_url: str | None = None,
        config_path: str | Path | None = None,
        auth_storage_mode: str | None = None,
        telemetry: TelemetryConfig | None = None,
        transport: TransportType | str | None = None,
        redis: Any | None = None,
        background_refresh: bool = True,
        refresh_interval: int = 30,
        default_workspace: str = "default",
    ) -> Client:
        """Create a client that reuses the active or named stored auth profile.

        This is the explicit ambient-auth path for notebooks, demos, and tests that
        want shared session reuse without manually exporting bearer tokens.
        """
        resolved_config_path = normalize_config_path(config_path)
        from featureform.cli.auth import YAMLProfileRepository

        profile_repo = YAMLProfileRepository(resolved_config_path)
        selected_profile = (
            profile_repo.get_profile(profile_name)
            if profile_name is not None
            else profile_repo.get_active_profile()
        )
        if profile_name is not None and selected_profile is None:
            raise ValueError(f"Auth profile '{profile_name}' was not found.")

        if selected_profile is not None:
            if base_url is not None and selected_profile.server.rstrip("/") != base_url.rstrip("/"):
                raise ValueError("Selected auth profile does not match the supplied server.")
            if transport is None:
                resolved_transport = TransportType(selected_profile.transport.lower())
            elif isinstance(transport, str):
                resolved_transport = TransportType(transport.lower())
            else:
                resolved_transport = transport
            if resolved_transport.value != selected_profile.transport.lower():
                raise ValueError("Selected auth profile does not match the supplied transport.")
            base_url = selected_profile.server
            resolved_no_tls = selected_profile.no_tls if no_tls is None else no_tls
        else:
            if base_url is None:
                raise ValueError("No active profile found; pass base_url or log in first.")
            if transport is None:
                resolved_transport = detect_transport_type(base_url)
            elif isinstance(transport, str):
                resolved_transport = TransportType(transport.lower())
            else:
                resolved_transport = transport
            resolved_no_tls = False if no_tls is None else no_tls

        token_provider = build_runtime_token_provider(
            timeout=timeout,
            verify_ssl=verify_ssl,
            no_tls=resolved_no_tls,
            ca_cert_path=ca_cert_path,
            client_cert_path=client_cert_path,
            client_key_path=client_key_path,
            config_path=resolved_config_path,
            auth_storage_mode=auth_storage_mode,
            explicit_token=token,
            client_id=client_id,
            client_secret=client_secret,
            issuer_url=issuer_url,
            server_url=base_url,
            transport=resolved_transport.value,
            profile_name=profile_name,
        )
        config = Config(
            base_url=base_url,
            timeout=timeout,
            verify_ssl=verify_ssl,
            no_tls=resolved_no_tls,
            ca_cert_path=ca_cert_path,
            client_cert_path=client_cert_path,
            client_key_path=client_key_path,
            token=token,
            token_provider=token_provider,
        )
        return cls(
            config=config,
            rest_url=rest_url,
            telemetry=telemetry,
            transport=resolved_transport,
            redis=redis,
            background_refresh=background_refresh,
            refresh_interval=refresh_interval,
            default_workspace=default_workspace,
        )

    @property
    def workspaces(self) -> WorkspaceClientBase:
        """Get workspace client."""
        return self._workspaces

    @property
    def transport_type(self) -> TransportType:
        """Get the transport type."""
        return self._transport_type

    @property
    def rest_transport(self) -> RESTTransport | None:
        """Get REST transport (if using REST)."""
        return self._rest_transport

    @property
    def grpc_transport(self) -> GRPCTransport | None:
        """Get gRPC transport (if using gRPC)."""
        return self._grpc_transport

    @property
    def transport(self) -> RESTTransport:
        """Get the underlying REST transport for direct API calls.

        Raises:
            RuntimeError: If using gRPC transport.
        """
        if self._rest_transport is None:
            raise RESTTransportUnavailableError(
                "REST transport not available. Use grpc_transport instead."
            )
        return self._rest_transport

    def ping(self) -> PingResult:
        """Probe the configured Featureform server and report health."""
        if self._rest_transport is not None:
            return self._ping_rest()
        if self._grpc_transport is not None:
            return self._ping_grpc()
        raise NoTransportAvailableError("No transport available.")

    def _ping_rest(self) -> PingResult:
        """Probe the REST health endpoint."""
        if self._rest_transport is None:
            raise RESTTransportUnavailableError("REST transport not available.")

        response = self._rest_transport.request_raw("GET", "/health")
        try:
            payload = response.json()
        except Exception:
            payload = None

        if response.status_code >= 400:
            if isinstance(payload, dict):
                payload_dict = cast(dict[str, Any], payload)
                status = str(payload_dict.get("status", "unknown")).lower()
                if status != "healthy":
                    return PingResult(
                        ok=False,
                        healthy=False,
                        transport=self._transport_type.value,
                        endpoint=f"{self._config.base_url}/health",
                        diagnosis="featureform_unhealthy",
                        detail=cast(str | None, payload_dict.get("version")),
                        server_status=status,
                    )
            self._rest_transport.raise_for_response(response)

        if not isinstance(payload, dict):
            return PingResult(
                ok=False,
                healthy=False,
                transport=self._transport_type.value,
                endpoint=f"{self._config.base_url}/health",
                diagnosis="unexpected_server",
                detail="Health endpoint did not return a JSON object.",
            )

        payload_dict = cast(dict[str, Any], payload)
        status = str(payload_dict.get("status", "unknown")).lower()
        healthy = status == "healthy"
        return PingResult(
            ok=healthy,
            healthy=healthy,
            transport=self._transport_type.value,
            endpoint=f"{self._config.base_url}/health",
            diagnosis="ok" if healthy else "featureform_unhealthy",
            detail=cast(str | None, payload_dict.get("version")),
            server_status=status,
        )

    def _ping_grpc(self) -> PingResult:
        """Probe the standard gRPC health service."""
        from grpc_health.v1 import health_pb2, health_pb2_grpc

        if self._grpc_transport is None:
            raise GRPCTransportUnavailableError("gRPC transport not available.")

        channel = self._grpc_transport.channel()
        stub = health_pb2_grpc.HealthStub(channel)
        try:
            response = stub.Check(health_pb2.HealthCheckRequest(), timeout=self._config.timeout)
        except grpc.RpcError as e:
            from featureform.transport.grpc import grpc_error_to_exception

            raise grpc_error_to_exception(e) from e
        status_name = health_pb2.HealthCheckResponse.ServingStatus.Name(response.status)
        healthy = response.status == health_pb2.HealthCheckResponse.SERVING

        return PingResult(
            ok=healthy,
            healthy=healthy,
            transport=self._transport_type.value,
            endpoint=self._config.base_url,
            diagnosis="ok" if healthy else "featureform_unhealthy",
            detail=None,
            server_status=status_name,
        )

    def providers(self, workspace_id: str | UUID) -> ProviderClientBase:
        """Get provider client for a workspace.

        Args:
            workspace_id: Workspace ID.

        Returns:
            Provider client.
        """
        if isinstance(workspace_id, str):
            workspace_id = UUID(workspace_id)

        if self._rest_transport is not None:
            return ProviderClient(self._rest_transport, workspace_id)
        elif self._grpc_transport is not None:
            return GRPCProviderClient(self._grpc_transport, workspace_id)
        else:
            raise NoTransportAvailableError("No transport available.")

    def catalogs(self, workspace_id: str | UUID) -> CatalogClientBase:
        """Get catalog client for a workspace."""
        if isinstance(workspace_id, str):
            workspace_id = UUID(workspace_id)

        if self._rest_transport is not None:
            return CatalogClient(self._rest_transport, workspace_id)
        elif self._grpc_transport is not None:
            return GRPCCatalogClient(self._grpc_transport, workspace_id)
        else:
            raise NoTransportAvailableError("No transport available.")

    def secret_providers(self, workspace_id: str | UUID) -> SecretProviderClientBase:
        """Get secret provider client for a workspace.

        Args:
            workspace_id: Workspace ID.

        Returns:
            Secret provider client.
        """
        if isinstance(workspace_id, str):
            workspace_id = UUID(workspace_id)

        if self._rest_transport is not None:
            return SecretProviderClient(self._rest_transport, workspace_id)
        elif self._grpc_transport is not None:
            return GRPCSecretProviderClient(self._grpc_transport, workspace_id)
        else:
            raise NoTransportAvailableError("No transport available.")

    def secrets(
        self,
        name: str = "env",
        *,
        workspace: str | UUID | None = None,
    ) -> SecretProviderHandle:
        """Get a secret provider handle for getting secrets.

        Args:
            name: Secret provider name (defaults to the built-in "env" provider).
            workspace: Workspace name or ID. If None, uses default workspace.

        Returns:
            SecretProviderHandle with a .get() method for getting secrets.

        Example:
            >>> env = client.secrets()
            >>> password = env.get("PG_PASSWORD")
            >>>
            >>> vault = client.secrets("vault")
            >>> api_key = vault.get("db/postgres", key="password")
        """
        workspace_id = self._resolve_workspace_ref(workspace)
        provider = self.secret_providers(workspace_id).get(name)
        return SecretProviderHandle(provider)

    def list_secret_providers(
        self,
        *,
        workspace: str | UUID | None = None,
    ) -> list[SecretProvider]:
        """List all secret providers in a workspace.

        Args:
            workspace: Workspace name or ID. If None, uses default workspace.

        Returns:
            List of secret providers.
        """
        workspace_id = self._resolve_workspace_ref(workspace)
        return self.secret_providers(workspace_id).list()

    def get_postgres(
        self,
        name: str,
        *,
        workspace: str | UUID | None = None,
    ) -> PostgresProvider:
        """Get a registered Postgres provider as a usable factory.

        Args:
            name: Provider name.
            workspace: Workspace name or ID. If None, uses default workspace.

        Returns:
            PostgresProvider that can be used to create datasets and transformations.

        Raises:
            TypeError: If the provider is not a Postgres provider.

        Example:
            >>> postgres = client.get_postgres("analytics_db")
            >>> txns = postgres.dataset(name="transactions", table="transactions")
        """

        workspace_id = self._resolve_workspace_ref(workspace)
        provider = self.providers(workspace_id).get(name)

        if provider.type != ProviderType.POSTGRES:
            raise ProviderTypeMismatchError(
                f"Provider '{name}' is {provider.type.value}, not postgres"
            )

        return self._build_postgres_provider(provider)

    def get_snowflake(
        self,
        name: str,
        *,
        workspace: str | UUID | None = None,
    ) -> SnowflakeProvider:
        """Get a registered Snowflake provider as a usable factory."""

        workspace_id = self._resolve_workspace_ref(workspace)
        provider = self.providers(workspace_id).get(name)

        if provider.type != ProviderType.SNOWFLAKE:
            raise ProviderTypeMismatchError(
                f"Provider '{name}' is {provider.type.value}, not snowflake"
            )

        return self._build_snowflake_provider(provider)

    def get_provider(
        self,
        name: str,
        *,
        workspace: str | UUID | None = None,
    ) -> ResourceProvider:
        """Get a registered provider as a usable factory.

        Automatically detects the provider type and returns the appropriate factory.
        Currently Postgres and Snowflake providers are implemented.

        Args:
            name: Provider name.
            workspace: Workspace name or ID. If None, uses default workspace.

        Returns:
            Provider factory.

        Example:
            >>> provider = client.get_provider("analytics_db")
            >>> txns = provider.dataset(name="transactions", table="transactions")
        """

        workspace_id = self._resolve_workspace_ref(workspace)
        provider = self.providers(workspace_id).get(name)

        # Return the appropriate typed provider
        if provider.type == ProviderType.POSTGRES:
            return self._build_postgres_provider(provider)
        if provider.type == ProviderType.SNOWFLAKE:
            return self._build_snowflake_provider(provider)

        raise UnsupportedProviderTypeError(f"Provider type {provider.type} not yet supported")

    def list_providers(
        self,
        *,
        workspace: str | UUID | None = None,
    ) -> list[Provider]:
        """List all providers in a workspace.

        Args:
            workspace: Workspace name or ID. If None, uses default workspace.

        Returns:
            List of providers.
        """
        workspace_id = self._resolve_workspace_ref(workspace)
        return self.providers(workspace_id).list()

    def refresh(self, obj: Any) -> Any:
        """Refresh a domain object with fresh data from the server.

        Args:
            obj: A Workspace, Provider, or SecretProvider to refresh.

        Returns:
            A new instance of the same type with fresh data.

        Raises:
            TypeError: If the object type is not supported.

        Example:
            >>> provider = client.get_postgres("analytics")
            >>> provider = client.refresh(provider)  # Get fresh data
        """
        if isinstance(obj, Workspace):
            return self.workspaces.get(obj.id)

        if isinstance(obj, Provider):
            return self.providers(obj.workspace_id).get(obj.name)

        if isinstance(obj, SecretProvider):
            return self.secret_providers(obj.workspace_id).get(obj.name)

        raise TypeError(f"Cannot refresh object of type {type(obj).__name__}")

    def datasets(
        self,
        *,
        provider: str | Provider | None = None,
        workspace: str | UUID | None = None,
    ) -> list[Any]:
        """Get datasets, optionally filtered by provider.

        Args:
            provider: Filter by provider name or Provider object.
            workspace: Workspace name or ID. If None, uses default workspace.

        Returns:
            List of datasets.

        Example:
            >>> # All datasets in workspace
            >>> datasets = client.datasets()
            >>>
            >>> # Datasets for a specific provider
            >>> datasets = client.datasets(provider=postgres)
            >>> datasets = client.datasets(provider="analytics_db")
        """
        return self._get_datasets_for_provider(provider=provider, workspace=workspace)

    def _get_datasets_for_provider(
        self,
        *,
        provider: str | Provider | None = None,  # noqa: ARG002
        workspace: str | UUID | None = None,  # noqa: ARG002
    ) -> list[Any]:
        """Internal method to get datasets for a provider.

        Note: actual implementation depends on the catalog/resource API.
        """
        raise ProviderDatasetsNotImplementedError("client.datasets() is not implemented yet")

    def _resolve_dataset_name(self, dataset: str | Any) -> str:
        """Resolve dataset name from string or object with .name attribute."""
        if isinstance(dataset, str):
            return dataset
        if hasattr(dataset, "name"):
            return str(dataset.name)
        raise TypeError(f"Cannot resolve dataset name from {type(dataset)}")

    def _resolve_dataframe_kind(
        self,
        dataset: str | Any,
        explicit_kind: Literal["dataset", "training_set"] | None = None,
    ) -> Literal["dataset", "training_set"]:
        """Resolve dataframe query kind from explicit input or resource metadata."""
        if explicit_kind is not None:
            return explicit_kind
        resource_type = getattr(dataset, "resource_type", None)
        if resource_type == "training_set":
            return "training_set"
        return "dataset"

    def _reject_feature_view_dataframe_target(self, dataset: str | Any) -> None:
        """Reject obvious feature-view objects on the dataset dataframe surface."""
        if getattr(dataset, "resource_type", None) == "feature_view":
            raise TypeError(
                "feature_view targets require client.feature_view_dataframe() or "
                "client.feature_view_dataframe_stream()"
            )

    def _resolve_feature_view_name(self, feature_view: str | Any) -> str:
        """Resolve feature view name from string or object with .name attribute."""
        if isinstance(feature_view, str):
            return feature_view
        if hasattr(feature_view, "name"):
            return str(feature_view.name)
        raise TypeError(f"Cannot resolve feature view name from {type(feature_view)}")

    def _resolve_feature_view_target(self, feature_view: str | Any) -> str:
        """Resolve a feature-view target and reject obvious non-feature-view objects."""
        resource_type = getattr(feature_view, "resource_type", None)
        if resource_type not in (None, "feature_view"):
            raise TypeError(
                "feature_view_dataframe() requires a FeatureView object or feature view name"
            )
        return self._resolve_feature_view_name(feature_view)

    def graph(self, workspace: str | UUID) -> GraphClientBase:
        """Get graph-query client for a workspace name or ID."""
        workspace_id = self._resolve_workspace(workspace)

        if self._rest_transport is not None:
            return RESTGraphClient(self._rest_transport, workspace_id)
        elif self._grpc_transport is not None:
            return GRPCGraphClient(self._grpc_transport, workspace_id)
        else:
            raise NoTransportAvailableError("No transport available.")

    def dataframe(
        self,
        dataset: str | Any,  # str or Dataset/TransformedDataset object
        workspace: str | None = None,
        *,
        workspace_id: str | UUID | None = None,
        columns: list[str] | None = None,
        filter: str | None = None,  # noqa: A002
        limit: int | None = None,
        kind: Literal["dataset", "training_set"] | None = None,
        flight_server: str | None = None,
        insecure: bool = False,
        engine: str = "flight",
        spark: Any | None = None,
        spark_options: SparkOptions | None = None,
        spark_host_map: dict[str, str] | None = None,
        spark_jdbc_options: dict[str, str] | None = None,
        spark_conf: dict[str, str] | None = None,
    ) -> Any:
        """Query a dataset and return results as Arrow data.

        Uses Apache Arrow Flight by default, or Spark-native read plans when available.

        Args:
            dataset: Name of the dataset to query, or a Dataset/TransformedDataset object.
            workspace: Workspace containing the dataset. If None, uses default workspace.
            workspace_id: Stable workspace ID for server-side dataframe plan resolution.
            columns: Optional list of columns to select. If None, all columns.
            filter: Optional filter expression (e.g., "amount > 100").
            limit: Optional maximum number of rows to return.
            kind: Optional low-level query target kind (`dataset` or `training_set`).
                For training-set reads by name, prefer `query_training_set(...)`.
            flight_server: Optional custom Flight server address.
                          Defaults to same host as base_url on port 9090.
            insecure: If True, disable TLS for the Flight connection.
                     Default is False (TLS enabled).
            engine: Dataframe execution engine: "flight", "spark", or "auto".
            spark: Optional SparkSession. Required when using Spark-native execution.
            spark_options: Optional typed Spark execution settings. Preferred over
                raw ``spark_jdbc_options`` and ``spark_conf``.
            spark_host_map: Optional host rewrite map for Spark-native execution.
                Useful when the server resolves container/network hostnames but the
                local Spark session must connect via different hostnames.
            spark_jdbc_options: Optional client-local Spark JDBC options to merge into
                resolved JDBC plans. Use this for credentials such as passwords that
                should not be returned by the server.
            spark_conf: Optional client-local Spark configuration to merge into
                resolved Iceberg plans. Use this for credentials or environment-
                specific Spark settings that should stay local to the caller.

        Returns:
            QueryResult for Flight execution, or a Spark DataFrame for Spark execution.

        Example:
            >>> # By name
            >>> result = client.dataframe("transactions", workspace="my-workspace")
            >>>
            >>> # By object
            >>> result = client.dataframe(daily_totals, workspace="my-workspace")
            >>>
            >>> # Training set by explicit helper
            >>> result = client.query_training_set("fraud_training", workspace="my-workspace")
            >>>
            >>> df = result.to_pandas()
        """
        self._reject_feature_view_dataframe_target(dataset)
        dataset_name = self._resolve_dataset_name(dataset)
        query_kind = self._resolve_dataframe_kind(dataset, kind)
        return self._dataframe_request(
            dataset=dataset_name,
            query_kind=query_kind,
            workspace=workspace,
            workspace_id=workspace_id,
            columns=columns,
            filter=filter,
            limit=limit,
            flight_server=flight_server,
            insecure=insecure,
            engine=engine,
            spark=spark,
            spark_options=spark_options,
            spark_host_map=spark_host_map,
            spark_jdbc_options=spark_jdbc_options,
            spark_conf=spark_conf,
        )

    def feature_view_dataframe(
        self,
        feature_view: str | Any,
        workspace: str | None = None,
        *,
        workspace_id: str | UUID | None = None,
        columns: list[str] | None = None,
        filter: str | None = None,  # noqa: A002
        limit: int | None = None,
        flight_server: str | None = None,
        insecure: bool = False,
        engine: str = "flight",
        spark: Any | None = None,
        spark_options: SparkOptions | None = None,
        spark_host_map: dict[str, str] | None = None,
        spark_jdbc_options: dict[str, str] | None = None,
        spark_conf: dict[str, str] | None = None,
    ) -> Any:
        """Query a feature view's committed offline snapshot as a dataframe."""
        feature_view_name = self._resolve_feature_view_target(feature_view)
        return self._dataframe_request(
            dataset=feature_view_name,
            query_kind="feature_view",
            workspace=workspace,
            workspace_id=workspace_id,
            columns=columns,
            filter=filter,
            limit=limit,
            flight_server=flight_server,
            insecure=insecure,
            engine=engine,
            spark=spark,
            spark_options=spark_options,
            spark_host_map=spark_host_map,
            spark_jdbc_options=spark_jdbc_options,
            spark_conf=spark_conf,
        )

    def _dataframe_request(
        self,
        *,
        dataset: str,
        query_kind: Literal["dataset", "training_set", "feature_view"],
        workspace: str | None,
        workspace_id: str | UUID | None,
        columns: list[str] | None,
        filter: str | None,  # noqa: A002
        limit: int | None,
        flight_server: str | None,
        insecure: bool,
        engine: str,
        spark: Any | None,
        spark_options: SparkOptions | None,
        spark_host_map: dict[str, str] | None,
        spark_jdbc_options: dict[str, str] | None,
        spark_conf: dict[str, str] | None,
    ) -> Any:
        normalized_engine = engine.lower()
        if normalized_engine not in {"flight", "spark", "auto"}:
            raise InvalidDataframeEngineError(normalized_engine)
        if normalized_engine == "spark" and spark is None:
            raise SparkSessionRequiredError()

        if spark is not None and normalized_engine in {"spark", "auto"}:
            resolved_workspace_id = workspace_id
            if resolved_workspace_id is None:
                workspace_ref = workspace if workspace is not None else self._default_workspace
                resolved_workspace_id = self._resolve_workspace_ref(
                    workspace_ref,
                    allow_default=False,
                )

            resolution: dict[str, Any] | None = None
            spark_error: SparkExecutionError | None = None
            try:
                resolution = self._resolve_dataframe_plan(
                    dataset=dataset,
                    workspace_id=resolved_workspace_id,
                    kind=query_kind,
                    columns=columns,
                    filter=filter,
                    limit=limit,
                    engine=normalized_engine,
                )
                return self._execute_dataframe_plan(
                    resolution,
                    spark=spark,
                    spark_options=self._resolve_effective_spark_options(
                        resolution=resolution,
                        spark_options=spark_options,
                        spark_host_map=spark_host_map,
                        spark_jdbc_options=spark_jdbc_options,
                        spark_conf=spark_conf,
                    ),
                )
            except SparkExecutionError as exc:
                spark_error = exc
                if normalized_engine != "auto":
                    raise
            except Exception as exc:
                if normalized_engine != "auto":
                    raise
                if resolution is not None:
                    raise DataframePlanResolutionError() from exc
                if workspace is None:
                    workspace = self.workspaces.get(resolved_workspace_id).name
                _logger.warning(
                    "dataframe_plan_fallback_to_flight",
                    dataset=dataset,
                    workspace=workspace,
                )
            if normalized_engine == "auto" and spark_error is not None:
                try:
                    fallback = self._execute_flight_fallback_plan(
                        resolution=resolution,
                        flight_server=flight_server,
                        insecure=insecure,
                        fallback_reason="spark_plan_execution_failed",
                    )
                except Exception as exc:
                    raise self._flight_fallback_execution_error(spark_error=spark_error) from exc

                if fallback is not None:
                    _logger.warning(
                        "dataframe_plan_fallback_to_flight",
                        dataset=dataset,
                        workspace=workspace,
                    )
                    return fallback

                raise self._flight_fallback_unavailable_error(
                    spark_error=spark_error
                ) from spark_error

            if normalized_engine == "auto" and resolution is not None:
                try:
                    fallback = self._execute_flight_fallback_plan(
                        resolution=resolution,
                        flight_server=flight_server,
                        insecure=insecure,
                        fallback_reason="spark_plan_execution_failed",
                    )
                except Exception as exc:
                    raise self._flight_fallback_execution_error(spark_error=spark_error) from exc
                if fallback is not None:
                    _logger.warning(
                        "dataframe_plan_fallback_to_flight",
                        dataset=dataset,
                        workspace=workspace,
                    )
                    return fallback
                raise self._flight_fallback_unavailable_error(
                    spark_error=spark_error
                ) from spark_error

        return self._query_dataframe_via_flight(
            dataset=dataset,
            kind=query_kind,
            workspace=workspace,
            columns=columns,
            filter=filter,
            limit=limit,
            flight_server=flight_server,
            insecure=insecure,
            execution_info=DataframeExecutionInfo(
                engine="flight",
                plan_type="flight_direct",
                fallback_reason=(
                    "spark_plan_resolution_failed"
                    if spark is not None and normalized_engine == "auto"
                    else None
                ),
            ),
        )

    def dataframe_stream(
        self,
        dataset: str | Any,
        workspace: str | None = None,
        *,
        columns: list[str] | None = None,
        filter: str | None = None,  # noqa: A002
        limit: int | None = None,
        kind: Literal["dataset", "training_set"] | None = None,
        flight_server: str | None = None,
        insecure: bool = False,
    ) -> QueryStream:
        """Open a one-shot streaming dataframe query over Arrow Flight."""
        self._reject_feature_view_dataframe_target(dataset)
        dataset_name = self._resolve_dataset_name(dataset)
        query_kind = self._resolve_dataframe_kind(dataset, kind)
        return self._dataframe_stream_request(
            dataset=dataset_name,
            query_kind=query_kind,
            workspace=workspace,
            columns=columns,
            filter=filter,
            limit=limit,
            flight_server=flight_server,
            insecure=insecure,
        )

    def feature_view_dataframe_stream(
        self,
        feature_view: str | Any,
        workspace: str | None = None,
        *,
        columns: list[str] | None = None,
        filter: str | None = None,  # noqa: A002
        limit: int | None = None,
        flight_server: str | None = None,
        insecure: bool = False,
    ) -> QueryStream:
        """Open a one-shot streaming feature-view dataframe query over Arrow Flight."""
        feature_view_name = self._resolve_feature_view_target(feature_view)
        return self._dataframe_stream_request(
            dataset=feature_view_name,
            query_kind="feature_view",
            workspace=workspace,
            columns=columns,
            filter=filter,
            limit=limit,
            flight_server=flight_server,
            insecure=insecure,
        )

    def _dataframe_stream_request(
        self,
        *,
        dataset: str,
        query_kind: Literal["dataset", "training_set", "feature_view"],
        workspace: str | None,
        columns: list[str] | None,
        filter: str | None,  # noqa: A002
        limit: int | None,
        flight_server: str | None,
        insecure: bool,
    ) -> QueryStream:
        """Open a one-shot streaming dataframe query over Arrow Flight."""
        return self._query_dataframe_stream_via_flight(
            dataset=dataset,
            kind=query_kind,
            workspace=workspace,
            columns=columns,
            filter=filter,
            limit=limit,
            flight_server=flight_server,
            insecure=insecure,
            execution_info=DataframeExecutionInfo(
                engine="flight",
                plan_type="flight_direct_streaming",
            ),
        )

    def _query_dataframe_via_flight(
        self,
        *,
        dataset: str,
        kind: Literal["dataset", "training_set", "feature_view"],
        workspace: str | None,
        columns: list[str] | None,
        filter: str | None,  # noqa: A002
        limit: int | None,
        flight_server: str | None,
        insecure: bool,
        execution_info: DataframeExecutionInfo | None = None,
    ) -> QueryResult:
        """Execute a dataframe query via Arrow Flight."""
        workspace, flight_server, resolved_insecure = self._resolve_flight_query_target(
            workspace=workspace,
            flight_server=flight_server,
            insecure=insecure,
        )

        _logger.debug(
            "dataframe_query",
            dataset=dataset,
            kind=kind,
            workspace=workspace,
            flight_server=flight_server,
            insecure=resolved_insecure,
        )

        df_client = DataFrameClient(
            flight_server,
            insecure=resolved_insecure,
            **self._subclient_auth_kwargs(),
        )
        try:
            result = df_client.query(
                workspace=workspace,
                dataset=dataset,
                kind=kind,
                columns=columns,
                filter=filter,
                limit=limit,
            )
            if execution_info is not None:
                attach_execution_info(result, execution_info)
            return result
        finally:
            df_client.close()

    def _query_dataframe_stream_via_flight(
        self,
        *,
        dataset: str,
        kind: Literal["dataset", "training_set", "feature_view"],
        workspace: str | None,
        columns: list[str] | None,
        filter: str | None,  # noqa: A002
        limit: int | None,
        flight_server: str | None,
        insecure: bool,
        execution_info: DataframeExecutionInfo | None = None,
    ) -> QueryStream:
        """Execute a streaming dataframe query via Arrow Flight."""
        workspace, flight_server, resolved_insecure = self._resolve_flight_query_target(
            workspace=workspace,
            flight_server=flight_server,
            insecure=insecure,
        )

        _logger.debug(
            "dataframe_stream_query",
            dataset=dataset,
            kind=kind,
            workspace=workspace,
            flight_server=flight_server,
            insecure=resolved_insecure,
        )

        df_client = DataFrameClient(
            flight_server,
            insecure=resolved_insecure,
            **self._subclient_auth_kwargs(),
        )
        try:
            stream = df_client.query_stream(
                workspace=workspace,
                dataset=dataset,
                kind=kind,
                columns=columns,
                filter=filter,
                limit=limit,
                close_callback=df_client.close,
            )
        except Exception:
            df_client.close()
            raise
        if execution_info is not None:
            attach_execution_info(stream, execution_info)
        return stream

    def _resolve_flight_query_target(
        self,
        *,
        workspace: str | None,
        flight_server: str | None,
        insecure: bool,
    ) -> tuple[str, str, bool]:
        """Resolve workspace and Flight connection settings for dataframe queries."""
        from urllib.parse import urlparse

        resolved_workspace = self._require_workspace_name(workspace)

        if flight_server is None:
            parsed = urlparse(self._config.base_url)
            host = parsed.hostname or parsed.path or "localhost"
            if self._transport_type == TransportType.GRPC and parsed.port is not None:
                resolved_flight_server = f"{host}:{parsed.port}"
            else:
                resolved_flight_server = f"{host}:9090"
            resolved_insecure = insecure or self._config.no_tls or parsed.scheme == "http"
        else:
            resolved_flight_server = flight_server
            # Explicit flight_server/insecure arguments win. This preserves mixed
            # deployments where the API is plaintext but Flight is separately exposed
            # over TLS.
            resolved_insecure = insecure

        return resolved_workspace, resolved_flight_server, resolved_insecure

    def query_dataset(
        self,
        dataset: str | Any,
        workspace: str | None = None,
        columns: list[str] | None = None,
        filter: str | None = None,  # noqa: A002
        limit: int | None = None,
        flight_server: str | None = None,
        insecure: bool = False,
    ) -> QueryResult:
        """Query a dataset through Arrow Flight."""
        return cast(
            QueryResult,
            self.dataframe(
                dataset,
                workspace=workspace,
                columns=columns,
                filter=filter,
                limit=limit,
                kind="dataset",
                flight_server=flight_server,
                insecure=insecure,
            ),
        )

    def query_training_set(
        self,
        training_set: str | Any,
        workspace: str | None = None,
        columns: list[str] | None = None,
        filter: str | None = None,  # noqa: A002
        limit: int | None = None,
        flight_server: str | None = None,
        insecure: bool = False,
    ) -> QueryResult:
        """Query a training set through Arrow Flight.

        Prefer this helper over the generic dataframe query surface when the
        target is a named training set.
        """
        return cast(
            QueryResult,
            self.dataframe(
                training_set,
                workspace=workspace,
                columns=columns,
                filter=filter,
                limit=limit,
                kind="training_set",
                flight_server=flight_server,
                insecure=insecure,
            ),
        )

    def query_feature_view(
        self,
        feature_view: str | Any,
        workspace: str | None = None,
        columns: list[str] | None = None,
        filter: str | None = None,  # noqa: A002
        limit: int | None = None,
        flight_server: str | None = None,
        insecure: bool = False,
    ) -> QueryResult:
        """Query a feature view's committed offline snapshot through Arrow Flight."""
        return cast(
            QueryResult,
            self.feature_view_dataframe(
                feature_view,
                workspace=workspace,
                columns=columns,
                filter=filter,
                limit=limit,
                flight_server=flight_server,
                insecure=insecure,
            ),
        )

    def _resolve_dataframe_plan(
        self,
        *,
        dataset: str,
        workspace_id: str | UUID,
        kind: Literal["dataset", "training_set", "feature_view"] | None,
        columns: list[str] | None,
        filter: str | None,  # noqa: A002
        limit: int | None,
        engine: str,
    ) -> dict[str, Any]:
        """Resolve the preferred dataframe execution plan from the server."""
        if isinstance(workspace_id, UUID):
            workspace_id = str(workspace_id)

        payload = {
            "workspace_id": workspace_id,
            "dataset": dataset,
            "columns": columns or [],
            "filter": filter,
            "limit": limit,
            "engine_hint": engine,
        }
        if kind is not None:
            payload["kind"] = kind

        if self._rest_transport is not None:
            max_attempts = 5
            for attempt in range(max_attempts):
                try:
                    response = self._rest_transport.post(
                        "/api/v1/dataframe/plan",
                        json=payload,
                    )
                    break
                except FeatureformError as exc:
                    if not self._should_retry_dataframe_plan_resolution(exc, attempt, max_attempts):
                        raise
                    time.sleep(1)
            else:
                raise RuntimeError("dataframe plan resolution retry loop exited unexpectedly")

            data = _require_json_object(response.data, field_name="dataframe plan response")
            resolution = data.get("resolution", data)
            return _require_json_object(
                resolution,
                field_name="dataframe plan response missing resolution payload",
            )

        if self._grpc_transport is None:
            raise NoTransportAvailableError(
                "dataframe plan resolution requires REST or gRPC transport"
            )

        from featureform.transport.grpc import dataframe_pb2, grpc_error_to_exception

        if dataframe_pb2 is None:
            dataframe_pb2 = import_module(
                "featureform._generated.proto.featureform.v2.dataframe_pb2"
            )

        engine_map = {
            "auto": dataframe_pb2.DATAFRAME_ENGINE_HINT_AUTO,
            "spark": dataframe_pb2.DATAFRAME_ENGINE_HINT_SPARK,
            "flight": dataframe_pb2.DATAFRAME_ENGINE_HINT_FLIGHT,
        }
        request = dataframe_pb2.ResolveDataframePlanRequest(
            workspace_id=workspace_id,
            dataset=dataset,
            columns=columns or [],
            filter=filter or "",
            limit=limit or 0,
            engine_hint=engine_map.get(engine, dataframe_pb2.DATAFRAME_ENGINE_HINT_UNSPECIFIED),
        )
        metadata: list[tuple[str, str]] | None = None
        if kind is not None:
            metadata = [(DATAFRAME_KIND_METADATA_KEY, kind)]
        max_attempts = 5
        resolve_plan_rpc = cast(Any, self._grpc_transport.dataframe.ResolveDataframePlan)
        for attempt in range(max_attempts):
            try:
                if metadata is None:
                    response = resolve_plan_rpc(request)
                else:
                    response = resolve_plan_rpc(request, metadata=metadata)
                return _proto_to_dataframe_resolution(response.resolution)
            except Exception as exc:
                if hasattr(exc, "code") and hasattr(exc, "details"):
                    mapped = grpc_error_to_exception(cast(Any, exc))
                    if not self._should_retry_dataframe_plan_resolution(
                        mapped, attempt, max_attempts
                    ):
                        raise mapped from exc
                    time.sleep(1)
                    continue
                raise

        raise RuntimeError("dataframe plan resolution retry loop exited unexpectedly")

    def _should_retry_dataframe_plan_resolution(
        self, error: FeatureformError, attempt: int, max_attempts: int
    ) -> bool:
        """Retry shortly when REST plan resolution lags a just-completed apply."""
        if attempt >= max_attempts - 1:
            return False

        message = error.message.lower()
        return "workspace has no committed resources" in message or "version not found" in message

    def _execute_dataframe_plan(
        self,
        resolution: dict[str, Any],
        *,
        spark: Any,
        spark_options: SparkOptions,
    ) -> Any:
        """Execute a resolved dataframe plan using Spark."""
        plan = _require_json_object(
            resolution.get("plan"), field_name="dataframe plan missing plan field"
        )
        info_base = self._build_execution_info(resolution, engine="spark")

        spark_jdbc = plan.get("spark_jdbc")
        if isinstance(spark_jdbc, dict):
            try:
                dataframe = self._execute_spark_jdbc_plan(
                    spark_jdbc,
                    spark=spark,
                    spark_options=spark_options,
                )
            except Exception as exc:
                raise self._wrap_spark_execution_error(
                    exc,
                    resolution=resolution,
                    plan_type="spark_jdbc",
                ) from exc
            dataframe = self._apply_spark_pushdown(dataframe, resolution)
            attach_execution_info(
                dataframe,
                info_base.__class__(**{**info_base.__dict__, "plan_type": "spark_jdbc"}),
            )
            return dataframe

        spark_iceberg = plan.get("spark_iceberg")
        if isinstance(spark_iceberg, dict):
            try:
                dataframe = self._execute_spark_iceberg_plan(
                    spark_iceberg,
                    spark=spark,
                    spark_options=spark_options,
                )
            except Exception as exc:
                raise self._wrap_spark_execution_error(
                    exc,
                    resolution=resolution,
                    plan_type="spark_iceberg",
                ) from exc
            dataframe = self._apply_spark_pushdown(dataframe, resolution)
            attach_execution_info(
                dataframe,
                info_base.__class__(**{**info_base.__dict__, "plan_type": "spark_iceberg"}),
            )
            return dataframe

        raise SparkPlanUnavailableError()

    def _apply_spark_pushdown(self, dataframe: Any, resolution: dict[str, Any]) -> Any:
        """Apply resolved dataframe pushdown operations to a Spark DataFrame."""
        pushdown_value = resolution.get("pushdown", {})
        if not isinstance(pushdown_value, dict):
            return dataframe
        pushdown = cast(dict[str, Any], pushdown_value)

        columns = pushdown.get("columns")
        if isinstance(columns, list) and columns:
            dataframe = dataframe.select(*[str(column) for column in columns])

        filter_expr = pushdown.get("filter")
        if isinstance(filter_expr, str) and filter_expr:
            dataframe = dataframe.filter(filter_expr)

        limit = pushdown.get("limit")
        if isinstance(limit, int) and limit > 0:
            dataframe = dataframe.limit(limit)

        return dataframe

    def _execute_spark_jdbc_plan(
        self,
        plan: dict[str, Any],
        *,
        spark: Any,
        spark_options: SparkOptions,
    ) -> Any:
        """Execute a Spark JDBC dataframe plan."""
        plan = self._rewrite_spark_jdbc_plan_hosts(plan, spark_host_map=spark_options.host_map)
        reader = spark.read.format(str(plan.get("format", "jdbc")))
        for key in ("url", "dbtable", "driver"):
            value = plan.get(key)
            if not isinstance(value, str) or not value:
                raise RuntimeError(f"spark_jdbc plan missing required field: {key}")
            reader = reader.option(key, value)

        options = plan.get("options", {})
        if isinstance(options, dict):
            for key, value in options.items():
                reader = reader.option(str(key), str(value))
        for key, value in spark_options.jdbc_options.items():
            reader = reader.option(str(key), str(value))

        return reader.load()

    def _execute_flight_fallback_plan(
        self,
        *,
        resolution: dict[str, Any] | None,
        flight_server: str | None,
        insecure: bool,
        fallback_reason: str,
    ) -> QueryResult | None:
        """Execute the server-provided Flight fallback plan when present."""
        if not isinstance(resolution, dict):
            return None

        fallback_value = resolution.get("fallback_flight")
        if not isinstance(fallback_value, dict):
            return None
        fallback = cast(dict[str, Any], fallback_value)

        address = flight_server or fallback.get("address")
        ticket = fallback.get("ticket")
        tls_enabled = fallback.get("tls_enabled", True)
        if not isinstance(address, str) or not address:
            return None
        if not isinstance(ticket, str) or not ticket:
            return None

        df_client = DataFrameClient(
            address,
            insecure=insecure or not bool(tls_enabled),
            **self._subclient_auth_kwargs(),
        )
        try:
            result = df_client.query_ticket(base64.b64decode(ticket))
            attach_execution_info(
                result,
                self._build_execution_info(
                    resolution,
                    engine="flight",
                    plan_type="fallback_flight",
                    fallback_reason=fallback_reason,
                ),
            )
            return result
        finally:
            df_client.close()

    def _execute_spark_iceberg_plan(
        self,
        plan: dict[str, Any],
        *,
        spark: Any,
        spark_options: SparkOptions,
    ) -> Any:
        """Execute a Spark Iceberg dataframe plan."""
        plan = self._rewrite_spark_iceberg_plan_hosts(plan, spark_host_map=spark_options.host_map)
        spark_session = (
            spark.newSession() if callable(getattr(spark, "newSession", None)) else spark
        )

        merged_conf: dict[str, str] = {}
        resolved_conf = plan.get("spark_conf", {})
        if isinstance(resolved_conf, dict):
            for key, value in resolved_conf.items():
                merged_conf[str(key)] = str(value)
        for key, value in spark_options.catalog_overrides.items():
            merged_conf[str(key)] = str(value)

        for key, value in merged_conf.items():
            spark_session.conf.set(key, value)
        self._sync_spark_hadoop_overrides(spark, merged_conf)

        table_identifier = plan.get("table_identifier")
        if not isinstance(table_identifier, str) or not table_identifier:
            raise RuntimeError("spark_iceberg plan missing required field: table_identifier")

        return spark_session.table(table_identifier)

    def _sync_spark_hadoop_overrides(self, spark: Any, merged_conf: dict[str, str]) -> None:
        """Mirror spark.hadoop.* overrides into the shared Hadoop configuration."""
        spark_context = getattr(spark, "sparkContext", None)
        if spark_context is None:
            return
        hadoop_conf = self._resolve_spark_hadoop_configuration(spark_context)
        if hadoop_conf is None:
            return

        current_overrides: dict[str, str] = {}
        for key, value in merged_conf.items():
            if key.startswith("spark.hadoop."):
                current_overrides[key.removeprefix("spark.hadoop.")] = value

        managed_keys = set(
            getattr(spark_context, "_featureform_managed_hadoop_override_keys", set())
        )
        for key in managed_keys - set(current_overrides):
            if callable(getattr(hadoop_conf, "unset", None)):
                hadoop_conf.unset(key)

        for key, value in current_overrides.items():
            hadoop_conf.set(key, value)

        spark_context._featureform_managed_hadoop_override_keys = set(current_overrides)

    def _resolve_spark_hadoop_configuration(self, spark_context: Any) -> Any | None:
        """Resolve the shared Hadoop configuration from SparkContext across PySpark shapes."""
        jsc = getattr(spark_context, "_jsc", None)
        hadoop_conf = getattr(jsc, "hadoopConfiguration", None)
        if hadoop_conf is None:
            return None
        if callable(hadoop_conf):
            hadoop_conf = hadoop_conf()
        if not callable(getattr(hadoop_conf, "set", None)):
            return None
        return hadoop_conf

    def _resolve_effective_spark_options(
        self,
        *,
        resolution: dict[str, Any],
        spark_options: SparkOptions | None,
        spark_host_map: dict[str, str] | None,
        spark_jdbc_options: dict[str, str] | None,
        spark_conf: dict[str, str] | None,
    ) -> SparkOptions:
        provider_kind = resolution.get("provider_kind")
        provider_name = resolution.get("provider_name")
        catalog_name = None
        plan_value = resolution.get("plan")
        if isinstance(plan_value, dict):
            typed_plan_value = cast(dict[str, Any], plan_value)
            spark_iceberg_value = typed_plan_value.get("spark_iceberg")
            if isinstance(spark_iceberg_value, dict):
                typed_spark_iceberg_value = cast(dict[str, Any], spark_iceberg_value)
                catalog_name_value = typed_spark_iceberg_value.get("catalog_name")
                if isinstance(catalog_name_value, str):
                    catalog_name = catalog_name_value

        resolved = SparkOptions()
        if isinstance(spark_host_map, dict):
            resolved = resolved.merge(SparkOptions(host_map=spark_host_map))
        if isinstance(spark_jdbc_options, dict):
            resolved = resolved.merge(SparkOptions(jdbc_options=spark_jdbc_options))
        if isinstance(spark_conf, dict):
            resolved = resolved.merge(SparkOptions(catalog_overrides=spark_conf))
        if isinstance(provider_kind, str) and isinstance(provider_name, str):
            resolved = resolved.merge(
                SparkOptions.from_env(
                    provider_kind=provider_kind,
                    provider_name=provider_name,
                    catalog_name=catalog_name,
                )
            )
        if spark_options is not None:
            resolved = spark_options.merge(resolved)
        return resolved

    def _build_execution_info(
        self,
        resolution: dict[str, Any] | None,
        *,
        engine: str,
        plan_type: str | None = None,
        fallback_reason: str | None = None,
    ) -> DataframeExecutionInfo:
        provider_kind = None
        provider_name = None
        if isinstance(resolution, dict):
            kind_value = resolution.get("provider_kind")
            name_value = resolution.get("provider_name")
            if isinstance(kind_value, str):
                provider_kind = kind_value
            if isinstance(name_value, str):
                provider_name = name_value
        return DataframeExecutionInfo(
            engine=engine,
            plan_type=plan_type or f"{engine}_direct",
            provider_kind=provider_kind,
            provider_name=provider_name,
            fallback_reason=fallback_reason,
        )

    def _wrap_spark_execution_error(
        self,
        error: Exception,
        *,
        resolution: dict[str, Any],
        plan_type: str,
    ) -> SparkExecutionError:
        provider_name = resolution.get("provider_name")
        provider_display = provider_name if isinstance(provider_name, str) else "unknown"
        if plan_type == "spark_jdbc":
            return SparkJdbcExecutionError(provider_display)
        if plan_type == "spark_iceberg":
            return SparkIcebergExecutionError(provider_display)
        return UnhandledSparkExecutionError(type(error).__name__)

    def _flight_fallback_unavailable_error(
        self, *, spark_error: SparkExecutionError | None
    ) -> DataframeFallbackError:
        from featureform.errors import FlightFallbackUnavailableError

        return FlightFallbackUnavailableError(spark_error=spark_error)

    def _flight_fallback_execution_error(
        self, *, spark_error: SparkExecutionError | None
    ) -> DataframeFallbackError:
        from featureform.errors import FlightFallbackExecutionError

        return FlightFallbackExecutionError(spark_error=spark_error)

    def _rewrite_spark_jdbc_plan_hosts(
        self, plan: dict[str, Any], *, spark_host_map: dict[str, str] | None
    ) -> dict[str, Any]:
        """Rewrite hostnames in Spark JDBC plans when local Spark needs alternate endpoints."""
        if not spark_host_map:
            return plan
        rewritten = dict(plan)
        url = rewritten.get("url")
        if isinstance(url, str):
            rewritten["url"] = self._rewrite_jdbc_url_hosts(url, spark_host_map)
        return rewritten

    def _rewrite_spark_iceberg_plan_hosts(
        self, plan: dict[str, Any], *, spark_host_map: dict[str, str] | None
    ) -> dict[str, Any]:
        """Rewrite hostnames in Spark Iceberg configuration for local Spark sessions."""
        if not spark_host_map:
            return plan
        rewritten = dict(plan)
        spark_conf = rewritten.get("spark_conf")
        if not isinstance(spark_conf, dict):
            return rewritten

        rewritten_conf: dict[str, Any] = {}
        for key, value in spark_conf.items():
            if isinstance(value, str):
                rewritten_conf[key] = self._rewrite_url_hosts(value, spark_host_map)
            else:
                rewritten_conf[key] = value
        rewritten["spark_conf"] = rewritten_conf
        return rewritten

    def _rewrite_jdbc_url_hosts(self, value: str, spark_host_map: dict[str, str]) -> str:
        """Rewrite hostnames in JDBC URLs using a simple host mapping."""
        prefix, separator, suffix = value.partition("://")
        if not separator:
            return value

        authority, path_separator, rest = suffix.partition("/")
        if not authority:
            return value

        userinfo, at_sign, host_port = authority.rpartition("@")
        authority_prefix = f"{userinfo}{at_sign}" if at_sign else ""
        host, colon, port = host_port.partition(":")
        if not host:
            return value

        rewritten_host = spark_host_map.get(host)
        if rewritten_host is None:
            return value

        rewritten_authority = (
            f"{authority_prefix}{rewritten_host}{colon}{port}"
            if colon
            else f"{authority_prefix}{rewritten_host}"
        )
        return f"{prefix}://{rewritten_authority}{path_separator}{rest}"

    def _rewrite_url_hosts(self, value: str, spark_host_map: dict[str, str]) -> str:
        """Rewrite hostnames in standard URLs using the provided host map."""
        parsed = urlsplit(value)
        if not parsed.hostname:
            return value

        rewritten_target = spark_host_map.get(parsed.hostname)
        if rewritten_target is None:
            return value
        rewritten_host, rewritten_port = self._split_host_port_override(rewritten_target)

        userinfo = ""
        if parsed.username is not None:
            userinfo = parsed.username
            if parsed.password is not None:
                userinfo = f"{userinfo}:{parsed.password}"
            userinfo = f"{userinfo}@"

        port_value = rewritten_port if rewritten_port is not None else parsed.port
        port = f":{port_value}" if port_value is not None else ""
        netloc = f"{userinfo}{rewritten_host}{port}"
        rewritten = SplitResult(parsed.scheme, netloc, parsed.path, parsed.query, parsed.fragment)
        return urlunsplit(rewritten)

    def _split_host_port_override(self, value: str) -> tuple[str, int | None]:
        """Split a host-map override into hostname and optional port."""
        if value.startswith("["):
            return value, None
        host, separator, port = value.rpartition(":")
        if separator and host and port.isdigit():
            return host, int(port)
        return value, None

    def _get_serving_client(self) -> Any:
        """Get or create the serving client (lazy initialization)."""
        if self._serving_client is None:
            from featureform.serving import ServingClient

            self._serving_client = ServingClient(
                base_url=self._config.base_url,
                rest_base_url=self._rest_url,
                default_workspace=self._default_workspace,
                redis=self._redis,
                grpc_transport=self._grpc_transport,
                **self._subclient_auth_kwargs(),
                background_refresh=self._background_refresh,
                refresh_interval=self._refresh_interval,
            )
        return self._serving_client

    def _subclient_auth_kwargs(self) -> dict[str, Any]:
        """Build auth kwargs for long-lived helper clients."""
        if self._config.token_provider is not None:
            return {"token_provider": self._config.resolve_token}

        token = self._auth_token()
        if token is not None:
            return {"token": token}

        return {}

    def _auth_token(self) -> str | None:
        """Extract a bearer token from client configuration when present."""
        header = self._config.authorization_header() or ""
        if header.startswith("Bearer "):
            return header.removeprefix("Bearer ")
        return None

    def serve(
        self,
        feature_view: str | Any,  # str or FeatureView object
        entity: str | None = None,
        entities: list[str] | None = None,
        requests: list[dict[str, Any]] | None = None,
        workspace: str | None = None,
        redis: Any | None = None,
        include_key: bool = False,
        features: list[str] | None = None,
        return_type: str = "dict",
    ) -> Any:
        """Serve features for one or more entities.

        Args:
            feature_view: Feature view name or FeatureView object.
            entity: Single entity ID (mutually exclusive with entities).
            entities: List of entity IDs (mutually exclusive with entity).
            requests: Realtime request shape containing per-entity runtime inputs.
            workspace: Workspace name (uses default if not specified).
            redis: Redis client for BYOC mode (uses default if not specified).
            include_key: Include entity key in response.
            features: Specific features to return (None = all).
            return_type: Return format: "dict", "numpy", "pandas", "torch".

        Returns:
            For single entity: dict of feature_name -> value
            For batch: ServeResult with dict of entity -> features

        Example:
            >>> # By name
            >>> features = client.serve("fraud_detection", entity="user_123")
            >>> # By object
            >>> features = client.serve(user_features, entity="user_123")
            >>> print(features["avg_transaction"])
        """
        # Resolve feature view name from object if needed
        feature_view_name = self._resolve_feature_view_name(feature_view)

        return self._get_serving_client().serve(
            feature_view=feature_view_name,
            entity=entity,
            entities=entities,
            requests=requests,
            workspace=self._require_workspace_name(workspace, allow_default=True),
            redis=redis,
            include_key=include_key,
            features=features,
            return_type=return_type,
        )

    def get_serving_metadata(
        self,
        feature_view: str | Any,  # str or FeatureView object
        workspace: str | None = None,
        refresh: bool = False,
    ) -> Any:
        """Get serving metadata for a feature view.

        Args:
            feature_view: Feature view name or FeatureView object.
            workspace: Workspace name (uses default if not specified).
            refresh: Force a fresh metadata fetch instead of using cached metadata.

        Returns:
            FeatureViewMetadata for the requested feature view.
        """
        feature_view_name = self._resolve_feature_view_name(feature_view)

        return self._get_serving_client().get_serving_metadata(
            feature_view=feature_view_name,
            workspace=self._require_workspace_name(workspace, allow_default=True),
            refresh=refresh,
        )

    def warm_load(
        self,
        feature_views: list[str | Any],  # list of str or FeatureView objects
        workspace: str | None = None,
    ) -> Any:
        """Preload metadata for feature views.

        Call this at application startup to avoid cold-start latency.

        Args:
            feature_views: List of feature view names or FeatureView objects.
            workspace: Workspace name (uses default if not specified).

        Returns:
            WarmLoadResult with loaded and errors lists.

        Example:
            >>> # By names
            >>> result = client.warm_load(["fraud_detection", "user_features"])
            >>> # By objects
            >>> result = client.warm_load([user_features, transaction_features])
            >>> print(f"Loaded {result.success_count} feature views")
        """
        # Resolve feature view names from objects if needed
        resolved_names = [self._resolve_feature_view_name(fv) for fv in feature_views]
        return self._get_serving_client().warm_load(
            resolved_names,
            self._require_workspace_name(workspace, allow_default=True),
        )

    def apply(
        self,
        resources: list[Any] | None = None,
        *,
        workspace: str | UUID | None = None,
        message: str = "",
        dry_run: bool = False,
        execution_mode: str = "NORMAL",
        show_planner_ir: bool = False,
        wait: bool = False,
        wait_for: WaitTarget | str = WaitTarget.FINISHED,
        wait_timeout: float = 1800.0,
        poll_interval: float = 2.0,
    ) -> ApplyResult:
        """Apply resources to a workspace.

        If resources is None, uses all resources from the global ResourceRegistry.
        This allows the pattern of importing definition modules and applying:

            import definitions  # Side effect: registers resources
            client = ff.Client()
            client.apply(workspace="my-workspace")  # Applies all registered

        Args:
            resources: List of resources to apply. If None, uses registry.
            workspace: Target workspace name or ID (required).
            message: Change description.
            dry_run: If True, return plan without applying.
            execution_mode: NORMAL, UPDATE, or FULL_REMATERIALIZE.
            show_planner_ir: If True, include debug planner IR in dry-run responses.
            wait: If True, wait for the apply job after submission.
            wait_for: Wait target: running or finished.
            wait_timeout: Wait timeout in seconds.
            poll_interval: Job polling interval in seconds.

        Returns:
            ApplyResult with version info and changes.

        Raises:
            FeatureformError: If resources, workspace, or wait configuration are invalid.
            ApplyWaitError: If waiting for apply completion fails or times out.
        """
        return self._apply_with_semantics(
            resources=resources,
            workspace=workspace,
            message=message,
            dry_run=dry_run,
            wait=wait,
            wait_for=wait_for,
            wait_timeout=wait_timeout,
            poll_interval=poll_interval,
            apply_strategy="APPLY",
            execution_mode=execution_mode,
            show_planner_ir=show_planner_ir,
        )

    def merge(
        self,
        resources: list[Any] | None = None,
        *,
        workspace: str | UUID | None = None,
        message: str = "",
        dry_run: bool = False,
        execution_mode: str = "NORMAL",
        show_planner_ir: bool = False,
        wait: bool = False,
        wait_for: WaitTarget | str = WaitTarget.FINISHED,
        wait_timeout: float = 1800.0,
        poll_interval: float = 2.0,
    ) -> ApplyResult:
        """Merge resources into a workspace without deleting omitted resources."""
        return self._apply_with_semantics(
            resources=resources,
            workspace=workspace,
            message=message,
            dry_run=dry_run,
            wait=wait,
            wait_for=wait_for,
            wait_timeout=wait_timeout,
            poll_interval=poll_interval,
            apply_strategy="MERGE",
            execution_mode=execution_mode,
            show_planner_ir=show_planner_ir,
        )

    def _apply_with_semantics(
        self,
        *,
        resources: list[Any] | None,
        workspace: str | UUID | None,
        message: str,
        dry_run: bool,
        wait: bool,
        wait_for: WaitTarget | str,
        wait_timeout: float,
        poll_interval: float,
        apply_strategy: str,
        execution_mode: str,
        show_planner_ir: bool,
    ) -> ApplyResult:
        """Apply or merge resources using explicit request semantics."""
        from featureform.resources.base import Resource, ResourceRegistry

        # Get resources from registry if not provided
        if resources is None:
            resources = ResourceRegistry.get_all()

        if not resources:
            raise NoResourcesToApplyError(
                "No resources to apply. Define resources or pass them explicitly."
            )

        if workspace is None:
            raise WorkspaceRequiredError("workspace is required")

        apply_strategy = apply_strategy.strip().upper()
        execution_mode = execution_mode.strip().upper()

        normalized_wait_for = self._normalize_wait_target(wait_for)
        self._validate_apply_wait_options(
            dry_run=dry_run,
            wait=wait,
            wait_for=normalized_wait_for,
            wait_timeout=wait_timeout,
            poll_interval=poll_interval,
        )
        if show_planner_ir and not dry_run:
            raise InvalidArgumentError("show_planner_ir requires dry_run=True")

        # Resolve workspace to ID
        workspace_id = self._resolve_workspace_ref(workspace, allow_default=False)

        _logger.debug(
            "apply_start",
            workspace_id=str(workspace_id),
            resource_count=len(resources),
            dry_run=dry_run,
        )

        self.validate_apply_provider_references(resources, workspace_id=workspace_id)
        json_resources, proto_resources = self._serialize_apply_resources(resources, Resource)
        response_data = self.submit_apply_request(
            json_resources=json_resources,
            proto_resources=proto_resources,
            workspace_id=workspace_id,
            message=message,
            dry_run=dry_run,
            apply_strategy=apply_strategy,
            execution_mode=execution_mode,
            show_planner_ir=show_planner_ir,
        )
        result = self._map_apply_response(response_data)

        if wait:
            self.wait_for_apply(
                result,
                workspace_id=workspace_id,
                wait_for=normalized_wait_for,
                timeout_seconds=wait_timeout,
                poll_interval_seconds=poll_interval,
            )
        return result

    def _serialize_apply_resources(
        self,
        resources: list[Any],
        resource_type: type[Any],
    ) -> tuple[list[dict[str, Any]], list[Any]]:
        """Serialize new-style resources for apply and merge requests."""
        json_resources: list[dict[str, Any]] = []
        proto_resources: list[Any] = []
        skipped_resources: list[tuple[str, str]] = []  # (type_name, repr)

        for resource in resources:
            if isinstance(resource, resource_type):
                json_resources.append(_resource_to_json(resource))
                proto_resources.append(resource.to_proto())
                continue

            type_name = type(resource).__name__
            resource_repr = repr(resource)[:100]
            skipped_resources.append((type_name, resource_repr))
            _logger.warning(
                "apply_skipped_non_resource",
                resource_type=type_name,
                resource_repr=resource_repr,
            )

        if skipped_resources:
            import warnings

            skipped_summary = ", ".join(f"{t}({r[:30]}...)" for t, r in skipped_resources[:5])
            if len(skipped_resources) > 5:
                skipped_summary += f" and {len(skipped_resources) - 5} more"
            warnings.warn(
                f"apply() skipped {len(skipped_resources)} non-Resource object(s): {skipped_summary}. "
                "These resources were not applied. Use the new Resource classes from featureform.resources.",
                UserWarning,
                stacklevel=4,
            )

        return json_resources, proto_resources

    def validate_apply_provider_references(
        self,
        resources: list[Any],
        *,
        workspace_id: UUID | None = None,
    ) -> None:
        """Validate provider objects captured during resource authoring before apply."""
        from featureform.resources.base import Resource

        unresolved_usages: dict[str, set[str]] = {}
        mismatched_usages: dict[str, set[str]] = {}
        source_workspace_ids: dict[str, set[str]] = {}
        for resource in resources:
            if not isinstance(resource, Resource):
                continue

            resource_name = getattr(resource, "name", type(resource).__name__)
            for reference in resource.provider_references:
                usage = f"{resource.resource_type}:{resource_name}.{reference.field_name}"
                if not reference.resolved:
                    unresolved_usages.setdefault(reference.provider_name, set()).add(usage)
                    continue
                if workspace_id is None:
                    continue
                if reference.source_workspace_id is None:
                    mismatched_usages.setdefault(reference.provider_name, set()).add(usage)
                    source_workspace_ids.setdefault(reference.provider_name, set()).add("<unknown>")
                    continue
                if reference.source_workspace_id != workspace_id:
                    mismatched_usages.setdefault(reference.provider_name, set()).add(usage)
                    source_workspace_ids.setdefault(reference.provider_name, set()).add(
                        str(reference.source_workspace_id)
                    )

        if unresolved_usages:
            raise UnresolvedProviderReferenceError(
                unresolved_references={
                    provider_name: tuple(sorted(usages))
                    for provider_name, usages in sorted(unresolved_usages.items())
                }
            )

        if not mismatched_usages:
            return

        raise ProviderWorkspaceMismatchError(
            expected_workspace_id=str(workspace_id),
            source_workspace_ids={
                provider_name: tuple(sorted(workspaces))
                for provider_name, workspaces in sorted(source_workspace_ids.items())
            },
            mismatched_references={
                provider_name: tuple(sorted(usages))
                for provider_name, usages in sorted(mismatched_usages.items())
            },
        )

    def submit_apply_request(
        self,
        *,
        json_resources: list[dict[str, Any]] | None,
        proto_resources: list[Any] | None,
        workspace_id: UUID | str,
        message: str,
        dry_run: bool,
        apply_strategy: str,
        execution_mode: str,
        show_planner_ir: bool = False,
    ) -> dict[str, Any]:
        """Submit an apply request using pre-serialized resources."""
        if self._grpc_transport is not None:
            return self._apply_grpc_raw(
                proto_resources=proto_resources or [],
                workspace_id=workspace_id,
                message=message,
                dry_run=dry_run,
                apply_strategy=apply_strategy,
                execution_mode=execution_mode,
                show_planner_ir=show_planner_ir,
            )
        if self._rest_transport is not None:
            return self._apply_rest_raw(
                json_resources=json_resources or [],
                workspace_id=workspace_id,
                message=message,
                dry_run=dry_run,
                apply_strategy=apply_strategy,
                execution_mode=execution_mode,
                show_planner_ir=show_planner_ir,
            )
        raise NoTransportAvailableError("No transport available for apply")

    def _map_apply_response(self, data: dict[str, Any]) -> ApplyResult:
        """Map a raw apply response payload into the public apply result."""
        changes_value = data.get("changes", [])
        changes: list[ResourceChange] = []
        if isinstance(changes_value, list):
            for change_value in changes_value:
                if not isinstance(change_value, dict):
                    continue
                change = cast(dict[str, Any], change_value)
                action = change.get("type")
                resource_name = change.get("resource_name")
                resource_type = change.get("resource_type")
                if (
                    isinstance(action, str)
                    and isinstance(resource_name, str)
                    and isinstance(resource_type, str)
                ):
                    changes.append(
                        ResourceChange(
                            resource_type=resource_type,
                            resource_name=resource_name,
                            action=action,
                        )
                    )

        delta_value = data.get("delta", {})
        delta = cast(dict[str, Any], delta_value) if isinstance(delta_value, dict) else {}
        created = delta.get("added")
        updated = delta.get("modified")

        version = data.get("version")
        if not isinstance(version, int):
            version = 0

        base_version = data.get("base_version")
        if not isinstance(base_version, int):
            base_version = None

        apply_strategy = data.get("apply_strategy")
        if not isinstance(apply_strategy, str) or not apply_strategy:
            apply_strategy = None

        execution_mode = data.get("execution_mode")
        if not isinstance(execution_mode, str) or not execution_mode:
            execution_mode = None

        no_changes = bool(data.get("no_changes", False))
        job_id = data.get("job_id")
        plan_error = data.get("plan_error")
        planned_job_value = data.get("planned_job")
        planner_ir = _normalize_planner_ir_payload(data.get("planner_ir"))
        planned_job: PlannedJob | None = None
        if isinstance(planned_job_value, dict):
            planned_job_data = cast(dict[str, Any], planned_job_value)
            tasks_value = planned_job_data.get("tasks", [])
            tasks: list[PlannedTask] = []
            if isinstance(tasks_value, list):
                for task_value in tasks_value:
                    if not isinstance(task_value, dict):
                        continue
                    task = cast(dict[str, Any], task_value)
                    task_id = task.get("id")
                    task_type = task.get("type")
                    if not isinstance(task_id, str) or not isinstance(task_type, str):
                        continue

                    resource_ids_value = task.get("resource_ids")
                    resource_ids = (
                        [value for value in resource_ids_value if isinstance(value, str)]
                        if isinstance(resource_ids_value, list)
                        else []
                    )
                    resource_id = task.get("resource_id")
                    if not resource_ids and isinstance(resource_id, str) and resource_id:
                        resource_ids = [resource_id]
                    depends_on_value = task.get("depends_on")
                    depends_on = (
                        [value for value in depends_on_value if isinstance(value, str)]
                        if isinstance(depends_on_value, list)
                        else []
                    )
                    operation = task.get("operation")
                    tasks.append(
                        PlannedTask(
                            id=task_id,
                            type=task_type,
                            operation=operation
                            if isinstance(operation, str) and operation
                            else "normal",
                            resource_id=resource_id
                            if isinstance(resource_id, str) and resource_id
                            else None,
                            resource_ids=resource_ids,
                            depends_on=depends_on,
                        )
                    )

            planned_job_name = planned_job_data.get("name")
            if isinstance(planned_job_name, str) and planned_job_name:
                planned_job = PlannedJob(name=planned_job_name, tasks=tasks)

        return ApplyResult(
            version=version,
            base_version=base_version,
            apply_strategy=apply_strategy,
            execution_mode=execution_mode,
            no_changes=no_changes,
            job_id=job_id if isinstance(job_id, str) and job_id else None,
            planned_job=planned_job,
            planner_ir=planner_ir,
            plan_error=plan_error if isinstance(plan_error, str) and plan_error else None,
            resources_created=created if isinstance(created, int) else 0,
            resources_updated=updated if isinstance(updated, int) else 0,
            resources_unchanged=0,
            changes=changes,
        )

    def wait_for_apply(
        self,
        apply_result: ApplyResult,
        *,
        workspace_id: UUID,
        wait_for: WaitTarget = WaitTarget.FINISHED,
        timeout_seconds: float = 1800.0,
        poll_interval_seconds: float = 2.0,
    ) -> ApplyWaitResult:
        """Wait for an apply result to reach the requested state."""
        deadline = time.monotonic() + timeout_seconds
        job: dict[str, Any] | None = None

        if apply_result.job_id:
            remaining_timeout = max(0.0, deadline - time.monotonic())
            job = wait_for_job(
                get_job=self._get_scheduler_job,
                job_id=apply_result.job_id,
                wait_for=wait_for,
                timeout_seconds=remaining_timeout,
                poll_interval_seconds=poll_interval_seconds,
                is_not_found_error=lambda exc: isinstance(exc, NotFoundError),
            )

        if wait_for == WaitTarget.FINISHED:
            self._wait_for_workspace_version(
                workspace_id=workspace_id,
                minimum=apply_result.version,
                deadline=deadline,
                poll_interval_seconds=poll_interval_seconds,
            )

        return ApplyWaitResult(apply=apply_result, job=job)

    def _wait_for_workspace_version(
        self,
        *,
        workspace_id: UUID,
        minimum: int,
        deadline: float,
        poll_interval_seconds: float,
    ) -> int:
        """Wait until the workspace last applied version becomes visible."""
        last_seen = 0
        while True:
            workspace = self.workspaces.get(workspace_id)
            last_seen = workspace.last_applied_version
            if last_seen >= minimum:
                return last_seen
            if time.monotonic() >= deadline:
                break
            time.sleep(poll_interval_seconds)

        raise ApplyWorkspaceVersionTimeoutError(workspace_id, minimum, last_seen)

    def _get_scheduler_job(self, job_id: str) -> dict[str, Any]:
        """Fetch a scheduler job using the active client transport."""
        if self._grpc_transport is not None:
            scheduler_pb2 = import_module("featureform._generated.proto.scheduler.v1.scheduler_pb2")
            scheduler_pb2_grpc = import_module(
                "featureform._generated.proto.scheduler.v1.scheduler_pb2_grpc"
            )
            stub = scheduler_pb2_grpc.SchedulerServiceStub(self._grpc_transport.channel())
            try:
                response = stub.GetJob(
                    scheduler_pb2.GetJobRequest(job_id=job_id, include_tasks=True),
                    timeout=self._config.timeout,
                )
            except grpc.RpcError as exc:
                if exc.code() == grpc.StatusCode.NOT_FOUND:
                    raise NotFoundError(f"Job '{job_id}' not found.") from None
                detail = exc.details() if hasattr(exc, "details") else str(exc)
                if not detail:
                    detail = str(exc)
                raise ApplyJobFetchError(job_id, detail=detail) from exc
            return {
                "id": response.job.id,
                "status": scheduler_pb2.JobStatus.Name(response.job.status).replace(
                    "JOB_STATUS_", ""
                ),
            }

        if self._rest_transport is None:
            raise NoTransportAvailableError("No transport available for scheduler polling")

        response = self._rest_transport.get(f"/api/v1/scheduler/jobs/{job_id}")
        data = _require_json_object(response.data, field_name="scheduler job response")
        job = data.get("job", {})
        return _require_json_object(job, field_name="scheduler job payload")

    def _normalize_wait_target(self, wait_for: WaitTarget | str) -> WaitTarget:
        """Normalize public wait target input into the enum value."""
        if isinstance(wait_for, WaitTarget):
            return wait_for
        try:
            return WaitTarget(wait_for.lower())
        except ValueError as exc:
            raise InvalidWaitTargetError(wait_for) from exc

    def _validate_apply_wait_options(
        self,
        *,
        dry_run: bool,
        wait: bool,
        wait_for: WaitTarget,
        wait_timeout: float,
        poll_interval: float,
    ) -> None:
        """Validate apply wait option combinations."""
        if wait and dry_run:
            raise WaitWithDryRunError()
        if not wait:
            if wait_for != WaitTarget.FINISHED:
                raise WaitForRequiresWaitError()
            if wait_timeout != 1800.0:
                raise WaitTimeoutRequiresWaitError()
            if poll_interval != 2.0:
                raise PollIntervalRequiresWaitError()
            return
        if wait_timeout <= 0:
            raise InvalidWaitTimeoutError(wait_timeout)
        if poll_interval <= 0:
            raise InvalidPollIntervalError(poll_interval)

    def _require_workspace_name(
        self,
        workspace: str | None,
        *,
        allow_default: bool = True,
    ) -> str:
        """Return a workspace name for APIs whose contract is name-based."""

        resolved = workspace or (self._default_workspace if allow_default else None)
        if not resolved:
            raise WorkspaceRequiredError("workspace is required")
        return resolved

    def _resolve_workspace_ref(
        self,
        workspace: str | UUID | None,
        *,
        allow_default: bool = True,
    ) -> UUID:
        """Resolve a workspace name or ID to a workspace ID."""

        resolved = workspace or (self._default_workspace if allow_default else None)
        if resolved is None:
            raise WorkspaceRequiredError("workspace is required")
        return self._resolve_workspace(resolved)

    def _resolve_workspace(self, workspace: str | UUID) -> UUID:
        """Resolve a workspace reference to ID.

        Args:
            workspace: Workspace name or UUID.

        Returns:
            Workspace UUID.
        """
        # If already a UUID, return it
        if isinstance(workspace, UUID):
            return workspace

        # Try to parse as UUID
        try:
            return UUID(workspace)
        except ValueError:
            pass

        # Look up by name
        ws = self._workspaces.get_by_name(workspace)
        return ws.id

    def _apply_grpc_raw(
        self,
        proto_resources: list[Any],
        workspace_id: UUID | str,
        message: str,
        dry_run: bool,
        apply_strategy: str,
        execution_mode: str,
        show_planner_ir: bool,
    ) -> dict[str, Any]:
        """Apply resources via gRPC and return the raw response payload."""
        import grpc

        from featureform._generated.proto.featureform.v2 import apply_pb2
        from featureform.transport.grpc import grpc_error_to_exception

        if self._grpc_transport is None:
            raise GRPCTransportUnavailableError("gRPC transport not available")

        metadata = apply_pb2.VersionMetadata(
            message=message,
        )
        request = apply_pb2.ApplyRequest(
            workspace_id=str(workspace_id),
            resources=proto_resources,
            metadata=metadata,
            dry_run=dry_run,
            apply_strategy=getattr(apply_pb2, f"APPLY_STRATEGY_{apply_strategy}"),
            execution_mode=getattr(apply_pb2, f"EXECUTION_MODE_{execution_mode}"),
            include_planner_ir=show_planner_ir,
        )

        try:
            response = self._grpc_transport.apply.Apply(request)  # pyright: ignore[reportUnknownMemberType, reportAttributeAccessIssue]
            result: dict[str, Any] = {
                "no_changes": response.no_changes,  # pyright: ignore[reportUnknownMemberType]
                "apply_strategy": _strip_enum_prefix(
                    apply_pb2.ApplyStrategy.Name(response.apply_strategy),  # pyright: ignore[reportUnknownMemberType]
                    "APPLY_STRATEGY_",
                ),
                "execution_mode": _strip_enum_prefix(
                    apply_pb2.ExecutionMode.Name(response.execution_mode),  # pyright: ignore[reportUnknownMemberType]
                    "EXECUTION_MODE_",
                ),
            }

            if response.HasField("version"):  # pyright: ignore[reportUnknownMemberType]
                result["version"] = response.version  # pyright: ignore[reportUnknownMemberType]

            if response.HasField("base_version"):  # pyright: ignore[reportUnknownMemberType]
                result["base_version"] = response.base_version  # pyright: ignore[reportUnknownMemberType]

            if response.HasField("delta"):  # pyright: ignore[reportUnknownMemberType]
                result["delta"] = {
                    "added": response.delta.added,  # pyright: ignore[reportUnknownMemberType]
                    "modified": response.delta.modified,  # pyright: ignore[reportUnknownMemberType]
                    "deleted": response.delta.deleted,  # pyright: ignore[reportUnknownMemberType]
                }

            if response.changes:  # pyright: ignore[reportUnknownMemberType]
                result["changes"] = [
                    {
                        "type": _apply_change_type_to_str(c.type),  # pyright: ignore[reportUnknownMemberType]
                        "resource_name": c.resource_name,  # pyright: ignore[reportUnknownMemberType]
                        "resource_type": c.resource_type,  # pyright: ignore[reportUnknownMemberType]
                        "resource_id": c.resource_id,  # pyright: ignore[reportUnknownMemberType]
                    }
                    for c in response.changes  # pyright: ignore[reportUnknownMemberType]
                ]

            if response.HasField("planned_job"):  # pyright: ignore[reportUnknownMemberType]
                result["planned_job"] = {
                    "name": response.planned_job.name,  # pyright: ignore[reportUnknownMemberType]
                    "tasks": [
                        {
                            "id": t.id,  # pyright: ignore[reportUnknownMemberType]
                            "type": t.type,  # pyright: ignore[reportUnknownMemberType]
                            "operation": t.operation,  # pyright: ignore[reportUnknownMemberType]
                            "resource_id": t.resource_id,  # pyright: ignore[reportUnknownMemberType]
                            "resource_ids": list(t.resource_ids),  # pyright: ignore[reportUnknownMemberType]
                            "depends_on": list(t.depends_on),  # pyright: ignore[reportUnknownMemberType]
                        }
                        for t in response.planned_job.tasks  # pyright: ignore[reportUnknownMemberType]
                    ],
                }

            if response.HasField("planner_ir"):  # pyright: ignore[reportUnknownMemberType]
                result["planner_ir"] = {
                    "items": [
                        {
                            "id": item.id,  # pyright: ignore[reportUnknownMemberType]
                            "graph_diff": item.graph_diff,  # pyright: ignore[reportUnknownMemberType]
                            "action": item.action,  # pyright: ignore[reportUnknownMemberType]
                            "reason": item.reason,  # pyright: ignore[reportUnknownMemberType]
                            "current_id": item.current_id,  # pyright: ignore[reportUnknownMemberType]
                            "desired_id": item.desired_id,  # pyright: ignore[reportUnknownMemberType]
                        }
                        for item in response.planner_ir.items  # pyright: ignore[reportUnknownMemberType]
                    ],
                    "reconcile_order": list(response.planner_ir.reconcile_order),  # pyright: ignore[reportUnknownMemberType]
                    "delete_order": list(response.planner_ir.delete_order),  # pyright: ignore[reportUnknownMemberType]
                }

            if response.HasField("job_id"):  # pyright: ignore[reportUnknownMemberType]
                result["job_id"] = response.job_id  # pyright: ignore[reportUnknownMemberType]

            if response.HasField("plan_error"):  # pyright: ignore[reportUnknownMemberType]
                result["plan_error"] = response.plan_error  # pyright: ignore[reportUnknownMemberType]

            _logger.debug(
                "apply_complete",
                version=result.get("version", 0),
                created=result.get("delta", {}).get("added", 0),
                updated=result.get("delta", {}).get("modified", 0),
            )

            return result

        except grpc.RpcError as e:
            raise grpc_error_to_exception(e) from e

    def _apply_rest_raw(
        self,
        json_resources: list[dict[str, Any]],
        workspace_id: UUID | str,
        message: str,
        dry_run: bool,
        apply_strategy: str,
        execution_mode: str,
        show_planner_ir: bool,
    ) -> dict[str, Any]:
        """Apply resources via the REST API and return the raw response payload."""
        if self._rest_transport is None:
            raise RESTTransportUnavailableError("REST transport not available")

        response = self._rest_transport.post(
            f"/api/v1/workspaces/{workspace_id}/apply",
            json={
                "resources": json_resources,
                "message": message,
                "dry_run": dry_run,
                "apply_strategy": apply_strategy,
                "execution_mode": execution_mode,
                "include_planner_ir": show_planner_ir,
            },
        )
        return _require_json_object(response.data, field_name="apply response")

    def close(self) -> None:
        """Close the client."""
        _logger.debug("client_close")
        if self._serving_client is not None:
            self._serving_client.close()
        if self._rest_transport is not None:
            self._rest_transport.close()
        if self._grpc_transport is not None:
            self._grpc_transport.close()

    def __enter__(self) -> Client:
        """Enter context manager."""
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Exit context manager."""
        self.close()


__all__ = [
    "PlannedJob",
    "PlannedTask",
    "ApplyResult",
    "ApplyWaitError",
    "ApplyWaitResult",
    "Client",
    "GRPCGraphClient",
    "GraphClientBase",
    "PingResult",
    "ProviderClient",
    "RESTGraphClient",
    "ResourceChange",
    "SecretProviderClient",
    "WaitTarget",
    "WorkspaceClient",
]
