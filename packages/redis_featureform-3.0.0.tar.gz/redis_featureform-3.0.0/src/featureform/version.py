"""Version compatibility checking for Featureform client-server communication.

This module provides functions to check compatibility between client and server
versions using semantic versioning (semver).

Compatibility rules:
- Same MAJOR.MINOR: Fully compatible
- Same MAJOR, different MINOR: Compatible with warning
- Different MAJOR: Incompatible
- Dev versions: Always compatible with warning
- Invalid versions: Compatible with warning (fail-open)

Edition compatibility:
- Same edition: Compatible
- Open-source client + Enterprise server: Compatible
- Enterprise client + Open-source server: Incompatible
"""

from __future__ import annotations

from dataclasses import dataclass

from packaging import version as pkg_version

from featureform.errors import EditionMismatchError, VersionMismatchError

# Edition constants
EDITION_OPEN_SOURCE = "open-source"
EDITION_ENTERPRISE = "enterprise"


@dataclass
class CompatibilityResult:
    """Result of a version compatibility check."""

    compatible: bool
    warning: str | None = None
    error: str | None = None
    exception: Exception | None = None

    def has_warning(self) -> bool:
        """Return True if there is a warning message."""
        return self.warning is not None

    def has_error(self) -> bool:
        """Return True if there is an error message."""
        return self.error is not None


def is_dev_version(version_str: str) -> bool:
    """Check if the version string indicates a development build.

    Args:
        version_str: Version string to check.

    Returns:
        True if the version is a dev version (case insensitive).
    """
    return version_str.lower() == "dev"


def check_compatibility(client_version: str, server_version: str) -> CompatibilityResult:
    """Check if client and server versions are compatible.

    Args:
        client_version: Client semver string (e.g., "1.2.3").
        server_version: Server semver string (e.g., "1.2.3").

    Returns:
        CompatibilityResult indicating compatibility status.
    """
    # Handle dev versions - always compatible with warning
    if is_dev_version(client_version) or is_dev_version(server_version):
        return CompatibilityResult(
            compatible=True,
            warning="Development version detected - skipping compatibility check",
        )

    # Parse versions
    try:
        # Strip 'v' prefix if present
        client_str = client_version.lstrip("v")
        client_ver = pkg_version.parse(client_str)
    except Exception:
        return CompatibilityResult(
            compatible=True,
            warning="Invalid client version format",
        )

    try:
        server_str = server_version.lstrip("v")
        server_ver = pkg_version.parse(server_str)
    except Exception:
        return CompatibilityResult(
            compatible=True,
            warning="Invalid server version format",
        )

    # Check if versions are valid (have major/minor attributes)
    if not hasattr(client_ver, "major") or not hasattr(server_ver, "major"):
        return CompatibilityResult(
            compatible=True,
            warning="Invalid version format",
        )

    # Different major version = incompatible
    if client_ver.major != server_ver.major:
        return CompatibilityResult(
            compatible=False,
            error=f"Incompatible versions: client {client_version}, "
            f"server {server_version} (major version mismatch)",
            exception=VersionMismatchError(
                f"Incompatible versions: client {client_version}, "
                f"server {server_version} (major version mismatch)"
            ),
        )

    # Same major, different minor = warn
    if client_ver.minor != server_ver.minor:
        if client_ver.minor < server_ver.minor:
            return CompatibilityResult(
                compatible=True,
                warning=f"Client version {client_version} is older than "
                f"server {server_version} - consider upgrading",
            )
        return CompatibilityResult(
            compatible=True,
            warning=f"Client version {client_version} is newer than "
            f"server {server_version} - some features may not work",
        )

    # Same major.minor = fully compatible
    return CompatibilityResult(compatible=True)


def check_edition_compatibility(
    client_edition: str,
    server_edition: str,
) -> CompatibilityResult:
    """Check if client and server editions are compatible.

    Args:
        client_edition: Client edition (e.g., "open-source", "enterprise").
        server_edition: Server edition.

    Returns:
        CompatibilityResult indicating compatibility status.
    """
    # Same edition = compatible
    if client_edition.lower() == server_edition.lower():
        return CompatibilityResult(compatible=True)

    # Open-source client connecting to enterprise server is fine
    if (
        client_edition.lower() == EDITION_OPEN_SOURCE
        and server_edition.lower() == EDITION_ENTERPRISE
    ):
        return CompatibilityResult(compatible=True)

    # Enterprise client connecting to open-source server is not compatible
    if (
        client_edition.lower() == EDITION_ENTERPRISE
        and server_edition.lower() == EDITION_OPEN_SOURCE
    ):
        return CompatibilityResult(
            compatible=False,
            error=f"Edition mismatch: client is {client_edition}, server is {server_edition} - "
            "enterprise features are not available",
            exception=EditionMismatchError(
                f"Edition mismatch: client is {client_edition}, server is {server_edition} - "
                "enterprise features are not available"
            ),
        )

    # Unknown editions - warn but allow
    return CompatibilityResult(
        compatible=True,
        warning=f"Unknown edition: client {client_edition}, server {server_edition}",
    )


def check_full_compatibility(
    client_version: str,
    server_version: str,
    client_edition: str,
    server_edition: str,
) -> CompatibilityResult:
    """Check both version and edition compatibility.

    Args:
        client_version: Client semver string.
        server_version: Server semver string.
        client_edition: Client edition.
        server_edition: Server edition.

    Returns:
        CompatibilityResult indicating compatibility status.
    """
    # Check version compatibility first
    version_result = check_compatibility(client_version, server_version)
    if not version_result.compatible:
        return version_result

    # Check edition compatibility
    edition_result = check_edition_compatibility(client_edition, server_edition)
    if not edition_result.compatible:
        return edition_result

    # Combine warnings if both have them
    if version_result.warning and edition_result.warning:
        return CompatibilityResult(
            compatible=True,
            warning=f"{version_result.warning}; {edition_result.warning}",
        )
    if version_result.warning:
        return version_result
    return edition_result


__all__ = [
    "CompatibilityResult",
    "EDITION_OPEN_SOURCE",
    "EDITION_ENTERPRISE",
    "check_compatibility",
    "check_edition_compatibility",
    "check_full_compatibility",
    "is_dev_version",
]
