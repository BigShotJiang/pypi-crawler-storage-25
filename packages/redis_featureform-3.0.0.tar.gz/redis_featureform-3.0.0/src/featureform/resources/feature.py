"""Feature resource classes with fluent builder API.

Example usage:
    transaction_count_7d = (
        ff.Feature()
        .from_dataset(user_events, entity="user_id", value="amount", timestamp="ts")
        .aggregate(function=ff.AggregateFunction.COUNT, window=timedelta(days=7))
    )

    user_name = (
        ff.Feature()
        .from_dataset(users, entity="user_id", value="name", timestamp="updated_at")
        .attribute()
    )
"""

from __future__ import annotations

import re
from abc import ABC
from datetime import timedelta
from typing import TYPE_CHECKING, Any

from pydantic import ConfigDict, Field, field_serializer

from featureform.errors import FeatureDatasetRequiredError
from featureform.resources.base import Resource, attach_provider_reference, resolve_name
from featureform.types.resource import AggregateFunction, ScalarType, ValueType

if TYPE_CHECKING:
    from featureform._generated.proto.featureform.v2 import resource_pb2
    from featureform.resources.dataset import Dataset


def parse_time_window(window: str | timedelta) -> timedelta:
    """Parse a time window to a timedelta.

    Accepts either a timedelta or a string like '7d', '1h', '30m'.
    """
    if isinstance(window, timedelta):
        return window
    if not window:
        return timedelta()

    pattern = re.compile(r"(\d+)([smhdw])")
    matches = pattern.findall(window.lower())
    if not matches:
        raise ValueError(f"Invalid time window format: {window}")

    total = timedelta()
    for value, unit in matches:
        val = int(value)
        if unit == "s":
            total += timedelta(seconds=val)
        elif unit == "m":
            total += timedelta(minutes=val)
        elif unit == "h":
            total += timedelta(hours=val)
        elif unit == "d":
            total += timedelta(days=val)
        elif unit == "w":
            total += timedelta(weeks=val)
    return total


def normalize_time_window(window: timedelta | None) -> timedelta | None:
    """Normalize zero-duration windows to lifetime aggregates."""
    if window is None:
        return None
    if window.total_seconds() == 0:
        return None
    return window


class FeatureBuilder:
    """Fluent builder for creating features.

    Example:
        >>> txn_count = (
        ...     ff.Feature(name="txn_count")
        ...     .from_dataset(events, entity="user_id", value="amount", timestamp="ts")
        ...     .aggregate(function=ff.AggregateFunction.COUNT, window=timedelta(days=7))
        ... )
    """

    def __init__(self, name: str = "", description: str = "") -> None:
        self._name: str = name
        self._source_dataset: str | None = None
        self._entity_name: str | None = None  # Entity name (reference)
        self._entity_column: str | None = None  # Column name in dataset
        self._value_column: str | None = None
        self._timestamp_column: str | None = None
        self._description: str = description
        self._provider: str = ""
        self._provider_obj: Any | None = None

    def from_dataset(
        self,
        dataset: str | Dataset,
        *,
        entity: str,
        value: str,
        timestamp: str = "",
        entity_column: str = "",
    ) -> FeatureBuilder:
        """Specify the source dataset and column mappings.

        Args:
            dataset: Source dataset name or object
            entity: Entity name that this feature belongs to
            value: Column name containing feature values
            timestamp: Optional timestamp column name
            entity_column: Column in dataset containing entity keys.
                          If not specified, defaults to the entity name.
        """
        self._source_dataset = resolve_name(dataset)
        self._entity_name = entity
        self._entity_column = entity_column if entity_column else entity
        self._value_column = value
        self._timestamp_column = timestamp
        return self

    def with_description(self, desc: str) -> FeatureBuilder:
        """Set the feature description."""
        self._description = desc
        return self

    def with_provider(self, provider_obj: str | Any) -> FeatureBuilder:
        """Set the provider."""
        self._provider = resolve_name(provider_obj)
        self._provider_obj = provider_obj
        return self

    def aggregate(
        self,
        *,
        function: AggregateFunction,
        window: str | timedelta | None = None,
        value_type: ValueType | None = None,
    ) -> AggregateFeature:
        """Create an aggregate feature.

        Args:
            function: Aggregate function (SUM, COUNT, MEAN, MIN, MAX, etc.)
            window: Optional time window; omit for lifetime aggregate.
            value_type: Optional feature value type. Defaults to FLOAT64 when
                omitted (see FeatureResource.value_type). Pass an explicit
                ValueType for non-numeric outputs (e.g. STRING, BOOL) or for
                integer-valued aggregates like COUNT.
        """
        if self._source_dataset is None:
            raise FeatureDatasetRequiredError("Must call from_dataset() before aggregate()")

        kwargs: dict[str, Any] = {
            "explicit_name": self._name,
            "source_dataset": self._source_dataset,
            "entity_name": self._entity_name or "",
            "entity_column": self._entity_column or "",
            "value_column": self._value_column or "",
            "timestamp_column": self._timestamp_column or "",
            "function": function,
            "time_window": normalize_time_window(
                parse_time_window(window) if window is not None else None
            ),
            "description": self._description,
            "provider": self._provider,
        }
        if value_type is not None:
            kwargs["value_type"] = value_type
        feature = AggregateFeature(**kwargs)
        if self._provider_obj is not None:
            attach_provider_reference(feature, self._provider_obj, field_name="provider")
        return feature

    def attribute(self, *, value_type: ValueType | None = None) -> AttributeFeature:
        """Create an attribute (direct column mapping) feature.

        Args:
            value_type: Optional feature value type. Defaults to FLOAT64 when
                omitted (see FeatureResource.value_type). Pass an explicit
                ValueType for non-numeric columns (e.g. STRING, BOOL,
                DATETIME) so the server does not silently coerce them.
        """
        if self._source_dataset is None:
            raise FeatureDatasetRequiredError("Must call from_dataset() before attribute()")

        kwargs: dict[str, Any] = {
            "explicit_name": self._name,
            "source_dataset": self._source_dataset,
            "entity_name": self._entity_name or "",
            "entity_column": self._entity_column or "",
            "value_column": self._value_column or "",
            "timestamp_column": self._timestamp_column or "",
            "description": self._description,
            "provider": self._provider,
        }
        if value_type is not None:
            kwargs["value_type"] = value_type
        feature = AttributeFeature(**kwargs)
        if self._provider_obj is not None:
            attach_provider_reference(feature, self._provider_obj, field_name="provider")
        return feature


def Feature(name: str = "", description: str = "") -> FeatureBuilder:  # noqa: N802
    """Start building a feature. Returns a FeatureBuilder for fluent construction.

    Args:
        name: Optional feature name. If not provided, must be auto-generated.
        description: Optional feature description.
    """
    return FeatureBuilder(name=name, description=description)


class FeatureResource(Resource, ABC):
    """Base class for all feature resources."""

    explicit_name: str = Field(default="", description="Explicit name (if provided)")
    source_dataset: str = Field(..., min_length=1, description="Source dataset name")
    entity_name: str = Field(
        ..., min_length=1, description="Entity name reference", serialization_alias="entity"
    )
    entity_column: str = Field(
        ..., min_length=1, description="Entity column name in source dataset"
    )
    value_column: str = Field(
        ..., min_length=1, description="Value column name", serialization_alias="input_column"
    )
    timestamp_column: str = Field(default="", description="Timestamp column name")
    value_type: ValueType = Field(
        default_factory=lambda: ValueType(scalar_type=ScalarType.FLOAT64),
        description="Type of the feature value (defaults to FLOAT64)",
    )
    description: str = Field(default="", description="Optional description")
    provider: str = Field(default="", description="Provider name")

    model_config = ConfigDict(
        frozen=True, extra="forbid", arbitrary_types_allowed=True, populate_by_name=True
    )

    def model_dump(self, **kwargs: Any) -> dict[str, Any]:
        """Override to serialize complex types properly."""
        data = super().model_dump(**kwargs)
        # Serialize value_type properly for JSON
        if "value_type" in data and hasattr(self, "value_type"):
            vt = self.value_type.model_dump()
            # Convert scalar_type enum to string
            if "scalar_type" in vt:
                vt["scalar_type"] = (
                    str(vt["scalar_type"].value)
                    if hasattr(vt["scalar_type"], "value")
                    else str(vt["scalar_type"])
                )
            data["value_type"] = vt
        # Serialize aggregate function enum to string
        if "function" in data and hasattr(data["function"], "value"):
            data["function"] = data["function"].value
        return data

    @property
    def resource_type(self) -> str:
        return "feature"

    @property
    def name(self) -> str:
        """Return explicit name if provided, otherwise auto-generate from dataset and column."""
        if self.explicit_name:
            return self.explicit_name
        return f"{self.source_dataset}_{self.value_column}"


class AttributeFeature(FeatureResource):
    """Direct column mapping feature (no aggregation).

    Created via: ff.Feature().from_dataset(...).attribute()
    """

    @property
    def resource_type(self) -> str:
        return "batch_attribute_feature"

    def to_proto(self) -> resource_pb2.Resource:
        """Convert to protobuf Resource message."""
        from featureform._generated.proto.featureform.v2 import resource_pb2

        return resource_pb2.Resource(
            batch_attribute_feature=resource_pb2.BatchAttributeFeature(
                name=self.name,
                description=self.description,
                entity=self.entity_name,
                entity_column=self.entity_column,
                source_dataset=self.source_dataset,
                input_column=self.value_column,
                provider=self.provider,
                timestamp_column=self.timestamp_column,
                value_type=resource_pb2.ValueType(
                    scalar_type=self.value_type.scalar_type.to_proto(),
                    is_vector=self.value_type.is_vector,
                    dimension=self.value_type.dimension,
                    is_embedding=self.value_type.is_embedding,
                ),
            )
        )


class AggregateFeature(FeatureResource):
    """Aggregation feature with time window.

    Created via: ff.Feature().from_dataset(...).aggregate(...)
    """

    function: AggregateFunction = Field(..., description="Aggregate function")
    time_window: timedelta | None = Field(default=None, description="Time window for aggregation")

    @field_serializer("time_window")
    @classmethod
    def serialize_time_window(cls, v: timedelta | None) -> float | None:
        """Serialize timedelta as total seconds for JSON compatibility."""
        normalized = normalize_time_window(v)
        if normalized is None:
            return None
        return normalized.total_seconds()

    @property
    def resource_type(self) -> str:
        return "batch_aggregate_feature"

    @property
    def name(self) -> str:
        """Generate feature name including aggregation info."""
        if self.explicit_name:
            return self.explicit_name
        base = f"{self.source_dataset}_{self.value_column}_{self.function.value.lower()}"
        normalized_window = normalize_time_window(self.time_window)
        if normalized_window is None:
            return base
        window_str = format_time_window(normalized_window)
        return f"{base}_{window_str}"

    def to_proto(self) -> resource_pb2.Resource:
        """Convert to protobuf Resource message."""
        from google.protobuf.duration_pb2 import Duration

        from featureform._generated.proto.featureform.v2 import resource_pb2

        batch_aggregate_feature = resource_pb2.BatchAggregateFeature(
            name=self.name,
            description=self.description,
            entity=self.entity_name,
            entity_column=self.entity_column,
            source_dataset=self.source_dataset,
            input_column=self.value_column,
            function=self.function.to_proto(),
            provider=self.provider,
            timestamp_column=self.timestamp_column,
            value_type=resource_pb2.ValueType(
                scalar_type=self.value_type.scalar_type.to_proto(),
                is_vector=self.value_type.is_vector,
                dimension=self.value_type.dimension,
                is_embedding=self.value_type.is_embedding,
            ),
        )
        normalized_window = normalize_time_window(self.time_window)
        if normalized_window is not None:
            time_window_proto = Duration()
            time_window_proto.FromTimedelta(normalized_window)
            batch_aggregate_feature.time_window.CopyFrom(time_window_proto)

        return resource_pb2.Resource(batch_aggregate_feature=batch_aggregate_feature)


def format_time_window(td: timedelta) -> str:
    """Format a timedelta as a human-readable string (e.g., '7d', '30m', '45s').

    Uses the largest appropriate unit:
    - Days if >= 24 hours
    - Hours if >= 60 minutes
    - Minutes if >= 60 seconds
    - Seconds otherwise
    """
    total_seconds = int(td.total_seconds())

    if total_seconds <= 0:
        return "0s"

    # Days (86400 seconds)
    if total_seconds >= 86400:
        return f"{total_seconds // 86400}d"

    # Hours (3600 seconds)
    if total_seconds >= 3600:
        return f"{total_seconds // 3600}h"

    # Minutes (60 seconds)
    if total_seconds >= 60:
        return f"{total_seconds // 60}m"

    # Seconds
    return f"{total_seconds}s"
