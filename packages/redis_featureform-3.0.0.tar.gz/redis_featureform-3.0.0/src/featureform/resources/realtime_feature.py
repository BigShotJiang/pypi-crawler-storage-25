"""Realtime feature resource definitions."""

from __future__ import annotations

import base64
import datetime as dt
import inspect
import pickle
import platform
import types
from collections.abc import Callable
from importlib import metadata
from typing import Any, Union, cast, get_args, get_origin, get_type_hints

import cloudpickle
from packaging.requirements import InvalidRequirement, Requirement
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from pydantic_core import PydanticCustomError

from featureform.resources.base import Resource, attach_provider_reference, resolve_name
from featureform.types.resource import ScalarType, ValueType


class ExtractedFunctionStringUnavailableError(ValueError):
    """Raised when source text cannot be extracted from a Python function."""


class RealtimeFeatureReturnTypeError(ValueError):
    """Realtime feature return annotation is unsupported."""


class RealtimeFeatureReferenceError(ValueError):
    """Raised when a realtime feature input reference cannot be resolved to a name."""

    def __init__(self) -> None:
        super().__init__("Invalid feature reference: missing 'name' attribute")


class RealtimeTrainingFeatureReferenceError(ValueError):
    """Raised when a training feature reference cannot be resolved to a name."""

    def __init__(self) -> None:
        super().__init__("Invalid training feature reference: missing 'name' attribute")


def _serialize_function(fn: Callable[..., Any]) -> bytes:
    """Serialize a realtime function with an explicitly typed wrapper."""
    serializer = cast(Callable[..., bytes], cast(Any, cloudpickle).dumps)
    return serializer(fn, protocol=pickle.HIGHEST_PROTOCOL)


class FeatureInput(BaseModel):
    """Reference a pre-computed feature as input to a realtime feature."""

    feature: Any = Field(..., description="Feature reference object or name string")

    model_config = ConfigDict(frozen=True, extra="forbid", arbitrary_types_allowed=True)

    @field_validator("feature", mode="before")
    @classmethod
    def validate_feature(cls, value: Any) -> Any:
        """Ensure the feature reference is present."""
        if value is None:
            raise PydanticCustomError(
                "featureform_realtime_feature_required", "feature cannot be None"
            )
        return value

    @property
    def feature_name(self) -> str:
        """Return the feature name from a string or named object."""
        if isinstance(self.feature, str):
            return self.feature
        if hasattr(self.feature, "name"):
            name = self.feature.name
            if isinstance(name, str):
                return name
        raise RealtimeFeatureReferenceError()


class RealtimeInput(BaseModel):
    """Reference a runtime input passed during serving."""

    name: str = Field(..., description="Serving-time parameter name")
    training_feature: Any | None = Field(
        default=None,
        description="Optional feature reference used when generating training sets",
    )

    model_config = ConfigDict(frozen=True, extra="forbid", arbitrary_types_allowed=True)

    @field_validator("name", mode="before")
    @classmethod
    def validate_name(cls, value: Any) -> str:
        """Ensure the realtime input name is a non-empty string."""
        if value is None:
            raise PydanticCustomError(
                "featureform_realtime_input_name_required", "name cannot be None"
            )
        if not isinstance(value, str):
            raise PydanticCustomError(
                "featureform_realtime_input_name_type",
                "name must be a string, got {type_name}",
                {"type_name": type(value).__name__},
            )
        if not value.strip():
            raise PydanticCustomError(
                "featureform_realtime_input_name_empty", "name cannot be empty"
            )
        return value

    @property
    def has_training_support(self) -> bool:
        """Return whether the input has a training feature backing it."""
        return self.training_feature is not None

    @property
    def training_feature_name(self) -> str | None:
        """Return the training feature name when present."""
        if self.training_feature is None:
            return None
        if isinstance(self.training_feature, str):
            return self.training_feature
        if hasattr(self.training_feature, "name"):
            name = self.training_feature.name
            if isinstance(name, str):
                return name
        raise RealtimeTrainingFeatureReferenceError()


RealtimeFeatureInput = FeatureInput | RealtimeInput


class FunctionNormalizerDetails(BaseModel):
    """Metadata describing how normalized function text was produced."""

    method: str = Field(..., min_length=1, description="Normalization strategy name")
    version: int = Field(..., ge=1, description="Normalization algorithm version")

    model_config = ConfigDict(frozen=True, extra="forbid")


class SerializerDetails(BaseModel):
    """Metadata describing how serialized function bytes were produced."""

    name: str = Field(..., min_length=1, description="Serializer implementation name")
    version: str = Field(..., min_length=1, description="Serializer implementation version")
    protocol: int = Field(..., ge=0, description="Serializer protocol version")

    model_config = ConfigDict(frozen=True, extra="forbid")


class RealtimeFeature(Resource):
    """Feature computed at serve time by executing serialized Python code."""

    name: str = Field(..., min_length=1, description="Realtime feature name")
    description: str = Field(default="", description="Optional feature description")
    entity: str = Field(..., min_length=1, description="Entity served by the feature")
    provider: str = Field(..., min_length=1, description="Execution provider name")
    value_type: str = Field(
        ...,
        min_length=1,
        description="Normalized Featureform-supported return type name",
    )
    inputs: list[RealtimeFeatureInput] = Field(
        ...,
        description="Ordered input binding contract for the realtime function",
    )
    requirements: list[str] = Field(
        default_factory=list,
        description="Canonicalized Python package requirements",
    )
    normalized_function_string: str = Field(
        ...,
        min_length=1,
        description="Canonical function text used for logical equivalence",
    )
    function_normalizer_details: FunctionNormalizerDetails = Field(
        ...,
        description="How extracted function text was normalized",
    )
    serialized_function: bytes = Field(..., min_length=1, description="Cloudpickle payload")
    extracted_function_string: str = Field(
        ...,
        min_length=1,
        description="Original extracted function source text",
    )
    serialization_python_version: str = Field(
        ...,
        min_length=1,
        description="Python version used to serialize the function",
    )
    serializer_details: SerializerDetails = Field(
        ...,
        description="Serializer metadata for the cloudpickled payload",
    )

    model_config = ConfigDict(
        frozen=True,
        extra="forbid",
        arbitrary_types_allowed=True,
    )

    @field_validator("value_type")
    @classmethod
    def validate_supported_value_type(cls, value: str) -> str:
        """Normalize return type strings to supported Featureform scalar types."""
        return _normalize_supported_value_type_name(value)

    @property
    def resource_type(self) -> str:
        return "realtime_feature"

    def to_proto(self) -> Any:
        """Convert to protobuf Resource message."""
        from featureform._generated.proto.featureform.v2 import resource_pb2

        proto_inputs: list[Any] = []
        for input_value in self.inputs:
            if isinstance(input_value, FeatureInput):
                proto_inputs.append(
                    resource_pb2.RealtimeFeatureInput(
                        input_type="feature",
                        feature_ref=resource_pb2.FeatureReference(
                            feature_name=input_value.feature_name
                        ),
                    )
                )
                continue

            training_feature = None
            if input_value.training_feature_name is not None:
                training_feature = resource_pb2.FeatureReference(
                    feature_name=input_value.training_feature_name
                )

            proto_inputs.append(
                resource_pb2.RealtimeFeatureInput(
                    input_type="realtime",
                    name=input_value.name,
                    training_feature=training_feature,
                )
            )

        return resource_pb2.Resource(
            realtime_feature=resource_pb2.RealtimeFeature(
                name=self.name,
                description=self.description,
                entity=self.entity,
                provider=self.provider,
                value_type=_value_type_to_proto(self.value_type),
                inputs=proto_inputs,
                requirements=self.requirements,
                normalized_function_string=self.normalized_function_string,
                function_normalizer_details=resource_pb2.FunctionNormalizerDetails(
                    method=self.function_normalizer_details.method,
                    version=self.function_normalizer_details.version,
                ),
                serialized_function=self.serialized_function,
                extracted_function_string=self.extracted_function_string,
                serialization_python_version=self.serialization_python_version,
                serializer_details=resource_pb2.SerializerDetails(
                    name=self.serializer_details.name,
                    version=self.serializer_details.version,
                    protocol=self.serializer_details.protocol,
                ),
            )
        )

    def model_dump(self, **kwargs: Any) -> dict[str, Any]:
        """Serialize realtime features for REST apply."""
        data = super().model_dump(**kwargs)
        data["value_type"] = _value_type_to_json(self.value_type)
        data["inputs"] = [_input_to_json(input_value) for input_value in self.inputs]
        data["serialized_function"] = base64.b64encode(self.serialized_function).decode("ascii")
        return data


class _RealtimeFeatureConfig(BaseModel):
    """Internal validation model for provider.realtime_feature."""

    fn: Callable[..., Any]
    inputs: list[RealtimeFeatureInput]
    requirements: list[str] = Field(default_factory=list)

    model_config = ConfigDict(arbitrary_types_allowed=True)

    @model_validator(mode="after")
    def validate_inputs_match_function_signature(self) -> _RealtimeFeatureConfig:
        """Validate positional binding against the function signature."""
        signature = inspect.signature(self.fn)
        keyword_only_required = [
            parameter.name
            for parameter in signature.parameters.values()
            if parameter.kind is inspect.Parameter.KEYWORD_ONLY
            and parameter.default is inspect.Parameter.empty
        ]
        if keyword_only_required:
            raise PydanticCustomError(
                "featureform_realtime_keyword_only",
                "Realtime feature functions cannot declare required keyword-only "
                "parameters because inputs are bound positionally. Found: {parameters}",
                {"parameters": keyword_only_required},
            )

        parameters = [
            parameter
            for parameter in signature.parameters.values()
            if parameter.kind
            in (inspect.Parameter.POSITIONAL_ONLY, inspect.Parameter.POSITIONAL_OR_KEYWORD)
        ]
        parameter_names = [parameter.name for parameter in parameters]

        if len(self.inputs) != len(parameter_names):
            raise PydanticCustomError(
                "featureform_realtime_input_count",
                "Number of inputs ({input_count}) must match number of function "
                "parameters ({parameter_count}). Parameters: {parameters}",
                {
                    "input_count": len(self.inputs),
                    "parameter_count": len(parameter_names),
                    "parameters": parameter_names,
                },
            )

        try:
            type_hints = get_type_hints(self.fn)
        except Exception:
            return self

        for index, input_value in enumerate(self.inputs):
            parameter_name = parameter_names[index]
            parameter_type = type_hints.get(parameter_name)
            if isinstance(input_value, FeatureInput):
                requires_optional = True
            else:
                requires_optional = input_value.has_training_support
            if requires_optional and parameter_type and not _is_optional_type(parameter_type):
                raise PydanticCustomError(
                    "featureform_realtime_optional_input",
                    "Parameter '{parameter_name}' must have Optional type because it "
                    "receives values from features which can be None.",
                    {"parameter_name": parameter_name},
                )

        return self

    @field_validator("requirements")
    @classmethod
    def validate_and_canonicalize_requirements(cls, values: list[str]) -> list[str]:
        """Validate requirement strings and return a canonicalized list."""
        normalized: set[str] = set()
        for value in values:
            try:
                requirement = Requirement(value.strip())
            except InvalidRequirement as exc:
                raise PydanticCustomError(
                    "featureform_realtime_requirement",
                    "Invalid requirement: {requirement}",
                    {"requirement": value},
                ) from exc

            normalized.add(str(requirement))

        return sorted(normalized)


def _is_optional_type(type_hint: Any) -> bool:
    """Return whether a type annotation allows None."""
    if type_hint is Any:
        return True

    origin = get_origin(type_hint)
    if origin is Union:
        return type(None) in get_args(type_hint)

    if isinstance(type_hint, types.UnionType):
        return type(None) in get_args(type_hint)

    return False


def _get_return_type(fn: Callable[..., Any]) -> str:
    """Resolve the return annotation to a supported Featureform scalar type name."""
    try:
        return_annotation = get_type_hints(fn).get("return", inspect.Signature.empty)
    except Exception:
        return_annotation = inspect.signature(fn).return_annotation
    return _normalize_return_annotation(return_annotation)


def _value_type_to_proto(value_type_name: str) -> Any:
    """Convert a normalized realtime return type into a proto ValueType."""
    return _value_type_from_string(value_type_name).to_proto()


def _value_type_to_json(value_type_name: str) -> dict[str, Any]:
    """Convert a normalized realtime return type into JSON ValueType shape."""
    return _value_type_from_string(value_type_name).model_dump()


def _value_type_from_string(value_type_name: str) -> ValueType:
    """Map a supported realtime return type name to a Featureform ValueType."""
    normalized = _normalize_supported_value_type_name(value_type_name)
    scalar_type = {
        "int": ScalarType.INT64,
        "float": ScalarType.FLOAT64,
        "str": ScalarType.STRING,
        "bool": ScalarType.BOOL,
        "datetime": ScalarType.DATETIME,
    }[normalized]
    return ValueType(scalar_type=scalar_type)


def _normalize_return_annotation(return_annotation: Any) -> str:
    """Normalize a Python return annotation into a supported Featureform type name."""
    if return_annotation is inspect.Signature.empty or return_annotation is Any:
        raise RealtimeFeatureReturnTypeError(
            "Unsupported realtime feature return type 'Any'; expected one of "
            "float, int, str, bool, datetime, or Optional[...] of those"
        )

    origin = get_origin(return_annotation)
    if origin is Union or isinstance(return_annotation, types.UnionType):
        args = get_args(return_annotation)
        non_none_args = [arg for arg in args if arg is not type(None)]
        if len(non_none_args) == 1 and len(non_none_args) != len(args):
            return _normalize_return_annotation(non_none_args[0])
        raise RealtimeFeatureReturnTypeError(
            f"Unsupported realtime feature return type '{return_annotation}'; expected one of "
            "float, int, str, bool, datetime, or Optional[...] of those"
        )

    if origin is not None:
        raise RealtimeFeatureReturnTypeError(
            f"Unsupported realtime feature return type '{return_annotation}'; expected one of "
            "float, int, str, bool, datetime, or Optional[...] of those"
        )

    if return_annotation is int:
        return "int"
    if return_annotation is float:
        return "float"
    if return_annotation is str:
        return "str"
    if return_annotation is bool:
        return "bool"
    if return_annotation is dt.datetime:
        return "datetime"

    if isinstance(return_annotation, str):
        return _normalize_supported_value_type_name(return_annotation)

    if hasattr(return_annotation, "__name__"):
        name = return_annotation.__name__
        if isinstance(name, str):
            return _normalize_supported_value_type_name(name)

    raise RealtimeFeatureReturnTypeError(
        f"Unsupported realtime feature return type '{return_annotation}'; expected one of "
        "float, int, str, bool, datetime, or Optional[...] of those"
    )


def _strip_optional_wrapper(value_type_name: str) -> str:
    """Reduce Optional/None unions to the wrapped scalar type string."""
    if value_type_name.startswith("typing.Optional[") and value_type_name.endswith("]"):
        return value_type_name[len("typing.Optional[") : -1].strip()

    if value_type_name.startswith("Optional[") and value_type_name.endswith("]"):
        return value_type_name[len("Optional[") : -1].strip()

    for prefix in ("typing.Union[", "Union["):
        if value_type_name.startswith(prefix) and value_type_name.endswith("]"):
            inner = value_type_name[len(prefix) : -1]
            parts = [part.strip() for part in inner.split(",")]
            non_none_parts = [part for part in parts if part not in {"None", "NoneType"}]
            if len(non_none_parts) == 1 and len(non_none_parts) != len(parts):
                return non_none_parts[0]

    if "|" in value_type_name:
        parts = [part.strip() for part in value_type_name.split("|")]
        non_none_parts = [part for part in parts if part not in {"None", "NoneType"}]
        if len(non_none_parts) == 1 and len(non_none_parts) != len(parts):
            return non_none_parts[0]

    return value_type_name


def _normalize_supported_value_type_name(value_type_name: str) -> str:
    """Normalize supported realtime return type strings and reject unsupported ones."""
    normalized = _strip_optional_wrapper(value_type_name.strip())
    aliases = {
        "int": "int",
        "float": "float",
        "str": "str",
        "string": "str",
        "bool": "bool",
        "datetime": "datetime",
        "datetime.datetime": "datetime",
        "dt.datetime": "datetime",
    }
    resolved = aliases.get(normalized)
    if resolved is None:
        raise RealtimeFeatureReturnTypeError(
            f"Unsupported realtime feature return type '{value_type_name}'; expected one of "
            "float, int, str, bool, datetime, or Optional[...] of those"
        )
    return resolved


def _input_to_json(input_value: RealtimeFeatureInput) -> dict[str, Any]:
    """Convert an input model to the JSON shape used by REST apply."""
    if isinstance(input_value, FeatureInput):
        return {
            "input_type": "feature",
            "feature_ref": {
                "feature_name": input_value.feature_name,
            },
        }

    data: dict[str, Any] = {
        "input_type": "realtime",
        "name": input_value.name,
    }
    if input_value.training_feature_name is not None:
        data["training_feature"] = {
            "feature_name": input_value.training_feature_name,
        }
    return data


def _get_extracted_function_string(fn: Callable[..., Any]) -> str:
    """Extract source text from a Python function."""
    try:
        return inspect.getsource(fn)
    except (OSError, TypeError) as exc:
        raise ExtractedFunctionStringUnavailableError(
            f"Could not extract source for realtime feature '{fn.__name__}'"
        ) from exc


def create_realtime_feature(
    *,
    provider: str,
    entity: str,
    inputs: list[RealtimeFeatureInput],
    fn: Callable[..., Any],
    name: str | None = None,
    description: str | None = None,
    requirements: list[str] | None = None,
) -> RealtimeFeature:
    """Create a realtime feature resource from a Python callable."""
    config = _RealtimeFeatureConfig(
        fn=fn,
        inputs=inputs,
        requirements=requirements or [],
    )

    extracted_function_string = _get_extracted_function_string(fn)

    return RealtimeFeature(
        name=name or fn.__name__,
        description=description if description is not None else (fn.__doc__ or ""),
        entity=entity,
        provider=provider,
        value_type=_get_return_type(fn),
        inputs=inputs,
        requirements=config.requirements,
        normalized_function_string=extracted_function_string,
        function_normalizer_details=FunctionNormalizerDetails(method="raw", version=1),
        serialized_function=_serialize_function(fn),
        extracted_function_string=extracted_function_string,
        serialization_python_version=platform.python_version(),
        serializer_details=SerializerDetails(
            name="cloudpickle",
            version=metadata.version("cloudpickle"),
            protocol=pickle.HIGHEST_PROTOCOL,
        ),
    )


def realtime_feature(
    *,
    provider: str | Any,
    entity: str,
    inputs: list[RealtimeFeatureInput],
    name: str | None = None,
    description: str | None = None,
    requirements: list[str] | None = None,
) -> Callable[[Callable[..., Any]], RealtimeFeature]:
    """Create a realtime feature decorator from a provider name or resolved provider object."""

    def decorator(fn: Callable[..., Any]) -> RealtimeFeature:
        feature = create_realtime_feature(
            provider=resolve_name(provider),
            entity=entity,
            inputs=inputs,
            fn=fn,
            name=name,
            description=description,
            requirements=requirements,
        )
        attach_provider_reference(feature, provider, field_name="provider")
        return feature

    return decorator


__all__ = [
    "ExtractedFunctionStringUnavailableError",
    "FeatureInput",
    "FunctionNormalizerDetails",
    "RealtimeFeature",
    "RealtimeFeatureInput",
    "RealtimeInput",
    "RealtimeFeatureReturnTypeError",
    "SerializerDetails",
    "create_realtime_feature",
    "realtime_feature",
]
