"""Base classes for Featureform resources.

This module provides:
- Resource: Abstract base class for all Featureform resources
- ResourceRegistry: Thread-local registry for auto-registration
- resolve_name: Helper to resolve object names
"""

from __future__ import annotations

import threading
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, ClassVar, cast
from uuid import UUID

from pydantic import BaseModel, ConfigDict, PrivateAttr

from featureform.errors import NameResolutionError

if TYPE_CHECKING:
    from google.protobuf.message import Message


def resolve_name(obj: Any) -> str:
    """Resolve an object to its name string.

    Accepts:
    - A string (returned as-is)
    - Any object with a 'name' attribute (extracts the name)

    Args:
        obj: The object to resolve (string or object with .name)

    Returns:
        The resolved name string

    Raises:
        ValueError: If the object cannot be resolved to a name
    """
    if isinstance(obj, str):
        return obj
    if hasattr(obj, "name"):
        name: str = obj.name
        return name
    raise NameResolutionError(f"Cannot resolve name from {type(obj)}")


@dataclass(frozen=True)
class ProviderReference:
    """Internal record of how a resource referenced a provider object."""

    provider_name: str
    field_name: str
    resolved: bool
    source_type: str
    source_workspace_id: UUID | None


class ResourceRegistry:
    """Thread-local registry for collecting resources during definition.

    Resources are automatically registered when instantiated (if _auto_register=True).
    Builders (like LabelBuilder, FeatureBuilder) can also be registered and will be
    resolved to their final resources at get_all() time.

    This is thread-safe using thread-local storage.
    """

    _local: ClassVar[threading.local] = threading.local()

    @classmethod
    def _get_resources(cls) -> list[Any]:
        """Get the resource list for the current thread."""
        if not hasattr(cls._local, "resources"):
            cls._local.resources = []
        # threading.local attributes are dynamically typed; type assertion needed
        raw_resources = cls._local.resources  # pyright: ignore[reportUnknownMemberType]
        resources = cast(list[Any], raw_resources)
        return resources

    @classmethod
    def register(cls, resource: Any) -> None:
        """Register a resource or builder to the registry."""
        cls._get_resources().append(resource)

    @classmethod
    def register_builder(cls, builder: Any) -> None:
        """Register a builder that will be resolved at get_all() time."""
        cls._get_resources().append(builder)

    @classmethod
    def _resolve_item(cls, item: Any) -> Resource | None:
        """Resolve an item to a Resource, handling builders."""
        if isinstance(item, Resource):
            return item
        # Check if it's a builder with a build() method
        if hasattr(item, "build") and callable(item.build):
            try:
                built = item.build()
                if isinstance(built, Resource):
                    return built
            except (ValueError, AttributeError):
                # Builder is incomplete, skip it
                return None
        return None

    @classmethod
    def get_all(cls) -> list[Resource]:
        """Get all registered resources, resolving any builders."""
        result: list[Resource] = []
        seen_names: set[str] = set()

        for item in cls._get_resources():
            resolved = cls._resolve_item(item)
            if resolved is not None:
                # Deduplicate by name
                name = getattr(resolved, "name", None)
                if name and name in seen_names:
                    continue
                if name:
                    seen_names.add(name)
                result.append(resolved)

        return result

    @classmethod
    def clear(cls) -> None:
        """Clear all registered resources."""
        cls._local.resources = []

    @classmethod
    def get_by_type(cls, resource_type: type[Resource]) -> list[Resource]:
        """Get all resources of a specific type."""
        return [r for r in cls.get_all() if isinstance(r, resource_type)]

    @classmethod
    def get_by_name(cls, name: str) -> Resource | None:
        """Get a resource by name."""
        for r in cls.get_all():
            resource_name = getattr(r, "name", None)
            if resource_name == name:
                return r
        return None


class Resource(BaseModel, ABC):
    """Abstract base class for all Featureform resources.

    All resources inherit from this class, which provides:
    - Auto-registration to ResourceRegistry on instantiation
    - Serialization to protobuf for apply
    - Validation via Pydantic

    Attributes:
        _auto_register: Class variable controlling auto-registration. Set to False
            for resources that should not be automatically registered.
    """

    # Class variable: if True, resource is auto-registered on instantiation
    _auto_register: ClassVar[bool] = True
    _provider_references: tuple[ProviderReference, ...] = PrivateAttr(default_factory=tuple)

    # Pydantic configuration
    model_config = ConfigDict(
        frozen=True,  # Immutable after creation
        extra="forbid",  # No extra fields allowed
        arbitrary_types_allowed=True,  # Allow non-Pydantic types
    )

    def __init__(self, **data: Any) -> None:
        """Initialize the resource and optionally register it."""
        super().__init__(**data)
        if self._auto_register:
            ResourceRegistry.register(self)

    @abstractmethod
    def to_proto(self) -> Message:
        """Convert the resource to its protobuf representation.

        Returns:
            The protobuf message for this resource.
        """
        ...

    @property
    @abstractmethod
    def resource_type(self) -> str:
        """Return the resource type name.

        Returns:
            A string identifying the resource type (e.g., 'entity', 'feature').
        """
        ...

    def __repr__(self) -> str:
        """Return a string representation of the resource."""
        name = getattr(self, "name", "unnamed")
        return f"{self.__class__.__name__}(name={name!r})"

    @property
    def provider_references(self) -> tuple[ProviderReference, ...]:
        """Return provider-object references captured during authoring."""
        return self._provider_references

    @property
    def unresolved_provider_references(self) -> tuple[ProviderReference, ...]:
        """Return provider references that came from unresolved local objects."""
        return tuple(ref for ref in self._provider_references if not ref.resolved)

    def add_provider_reference(self, reference: ProviderReference) -> None:
        """Record a provider reference without leaking it into payload serialization."""
        self._provider_references = self._provider_references + (reference,)

    def _add_provider_reference(self, reference: ProviderReference) -> None:
        self.add_provider_reference(reference)


def attach_provider_reference(resource: Resource, provider_obj: Any, *, field_name: str) -> None:
    """Attach provider-origin metadata to a resource when authored from an object."""
    reference = _provider_reference_from_object(provider_obj, field_name=field_name)
    if reference is not None:
        resource.add_provider_reference(reference)


def _provider_reference_from_object(
    provider_obj: Any,
    *,
    field_name: str,
) -> ProviderReference | None:
    """Build a ProviderReference for supported provider object types."""
    if provider_obj is None or isinstance(provider_obj, str):
        return None

    from featureform.resources.provider import Provider as ResourceProvider
    from featureform.types.provider import Provider as DomainProvider

    if isinstance(provider_obj, ResourceProvider):
        return ProviderReference(
            provider_name=provider_obj.name,
            field_name=field_name,
            resolved=provider_obj.is_resolved(),
            source_type=type(provider_obj).__name__,
            source_workspace_id=provider_obj.workspace_id,
        )

    if isinstance(provider_obj, DomainProvider):
        return ProviderReference(
            provider_name=provider_obj.name,
            field_name=field_name,
            resolved=True,
            source_type=type(provider_obj).__name__,
            source_workspace_id=provider_obj.workspace_id,
        )

    return None
