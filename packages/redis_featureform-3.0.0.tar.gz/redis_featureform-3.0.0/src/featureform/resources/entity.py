"""Entity resource class."""

from __future__ import annotations

from typing import TYPE_CHECKING

from pydantic import Field

from featureform.resources.base import Resource

if TYPE_CHECKING:
    from featureform._generated.proto.featureform.v2 import resource_pb2


class Entity(Resource):
    """Entity represents a join key that connects features together.

    Entities define the primary keys used to join features across datasets.
    Common examples include user_id, item_id, session_id, etc.

    Example:
        >>> user = ff.Entity(name="user", description="User entity")
        >>> item = ff.Entity(name="item", description="Item/product entity")

    Attributes:
        name: Unique identifier for the entity.
        description: Human-readable description of the entity.
    """

    name: str = Field(..., min_length=1, description="Entity name")
    description: str = Field(default="", description="Optional description")

    @property
    def resource_type(self) -> str:
        """Return the resource type name."""
        return "entity"

    def to_proto(self) -> resource_pb2.Resource:
        """Convert to protobuf Resource message."""
        from featureform._generated.proto.featureform.v2 import resource_pb2

        return resource_pb2.Resource(
            entity=resource_pb2.Entity(
                name=self.name,
                description=self.description,
            )
        )
