"""Dataset resource classes."""

from __future__ import annotations

from abc import ABC
from typing import TYPE_CHECKING, Any, cast

from pydantic import Field

from featureform.resources.base import Resource
from featureform.types.resource import (
    IcebergTableLocation,
    PostgresDatasetConfig,
    SparkJobConfig,
    TableLocation,
)
from featureform.types.secret import (
    AWSSecretRef,
    AzureSecretRef,
    EnvSecretRef,
    GCPSecretRef,
    K8sSecretRef,
    SecretRef,
    VaultSecretRef,
)

if TYPE_CHECKING:
    from featureform._generated.proto.featureform.v2 import resource_pb2


def _secret_ref_to_provider_proto(value: SecretRef, provider_pb2: Any) -> Any:
    if isinstance(value, EnvSecretRef):
        return provider_pb2.SecretRef(env=provider_pb2.EnvSecretRef(**value.model_dump()))
    if isinstance(value, VaultSecretRef):
        return provider_pb2.SecretRef(vault=provider_pb2.VaultSecretRef(**value.model_dump()))
    if isinstance(value, K8sSecretRef):
        return provider_pb2.SecretRef(k8s=provider_pb2.K8sSecretRef(**value.model_dump()))
    if isinstance(value, AWSSecretRef):
        return provider_pb2.SecretRef(
            aws_secrets_manager=provider_pb2.AWSSecretRef(**value.model_dump())
        )
    if isinstance(value, GCPSecretRef):
        return provider_pb2.SecretRef(
            gcp_secret_manager=provider_pb2.GCPSecretRef(**value.model_dump())
        )
    azure_ref: AzureSecretRef = value
    return provider_pb2.SecretRef(
        azure_key_vault=provider_pb2.AzureSecretRef(**azure_ref.model_dump())
    )


class Dataset(Resource, ABC):
    """Base class for all datasets (primary and transformed).

    Datasets represent tabular data that can be used as:
    - Sources for features
    - Sources for labels
    - Inputs to transformations
    """

    name: str = Field(..., min_length=1, description="Dataset name")
    description: str = Field(default="", description="Optional description")
    provider: str = Field(default="", description="Provider name")
    timestamp_column: str = Field(default="", description="Timestamp column name")

    @property
    def resource_type(self) -> str:
        """Return the resource type name."""
        return "dataset"


# -----------------------------------------------------------------------------
# Primary Datasets
# -----------------------------------------------------------------------------


class PrimaryDataset(Dataset, ABC):
    """Base class for primary datasets (external data sources)."""

    pass


class PostgresPrimaryDataset(PrimaryDataset):
    """Primary dataset from PostgreSQL.

    Example:
        >>> transactions = ff.PostgresPrimaryDataset(
        ...     name="transactions",
        ...     provider="postgres",
        ...     location=ff.TableLocation(schema="public", table="transactions"),
        ...     timestamp_column="created_at",
        ... )
    """

    location: TableLocation = Field(..., description="Table location")

    @property
    def resource_type(self) -> str:
        return "primary_dataset"

    def to_proto(self) -> resource_pb2.Resource:
        """Convert to protobuf Resource message."""
        from featureform._generated.proto.featureform.v2 import resource_pb2

        return resource_pb2.Resource(
            primary_dataset=resource_pb2.PrimaryDataset(
                name=self.name,
                description=self.description,
                provider=self.provider,
                location=resource_pb2.TableLocation(
                    database=self.location.database,
                    schema=self.location.schema,
                    table=self.location.table,
                ),
                timestamp_column=self.timestamp_column,
            )
        )


class SnowflakePrimaryDataset(PrimaryDataset):
    """Primary dataset from Snowflake."""

    location: TableLocation = Field(..., description="Table location")

    @property
    def resource_type(self) -> str:
        return "primary_dataset"

    def to_proto(self) -> resource_pb2.Resource:
        """Convert to protobuf Resource message."""
        from featureform._generated.proto.featureform.v2 import resource_pb2

        return resource_pb2.Resource(
            primary_dataset=resource_pb2.PrimaryDataset(
                name=self.name,
                description=self.description,
                provider=self.provider,
                location=resource_pb2.TableLocation(
                    database=self.location.database,
                    schema=self.location.schema,
                    table=self.location.table,
                ),
                timestamp_column=self.timestamp_column,
            )
        )


class IcebergPrimaryDataset(PrimaryDataset):
    """Primary dataset from Iceberg.

    Example:
        >>> events = ff.IcebergPrimaryDataset(
        ...     name="events",
        ...     provider="iceberg-catalog",
        ...     location=ff.IcebergTableLocation(namespace="raw", table="events"),
        ... )
    """

    location: IcebergTableLocation = Field(..., description="Iceberg table location")

    @property
    def resource_type(self) -> str:
        return "iceberg_primary_dataset"

    def to_proto(self) -> resource_pb2.Resource:
        """Convert to protobuf Resource message."""
        from featureform._generated.proto.featureform.v2 import resource_pb2

        return resource_pb2.Resource(
            iceberg_primary_dataset=resource_pb2.IcebergPrimaryDataset(
                name=self.name,
                description=self.description,
                provider=self.provider,
                location=resource_pb2.IcebergTableLocation(
                    namespace=self.location.namespace,
                    table=self.location.table,
                ),
                timestamp_column=self.timestamp_column,
            )
        )


# -----------------------------------------------------------------------------
# Transformed Datasets
# -----------------------------------------------------------------------------


class TransformedDataset(Dataset, ABC):
    """Base class for transformed datasets."""

    source_datasets: list[str] = Field(..., min_length=1, description="Source dataset names")
    sql_query: str = Field(..., min_length=1, description="SQL query for transformation")


class PostgresTransformedDataset(TransformedDataset):
    """SQL transformation executed in PostgreSQL.

    Example:
        >>> daily_totals = ff.PostgresTransformedDataset(
        ...     name="daily_totals",
        ...     provider="postgres",
        ...     source_datasets=["transactions"],
        ...     sql_query="SELECT date, SUM(amount) FROM {{ transactions }} GROUP BY date",
        ...     postgres_config=ff.PostgresDatasetConfig(schema="analytics", table="daily_totals"),
        ... )
    """

    postgres_config: PostgresDatasetConfig = Field(..., description="Postgres output config")

    @property
    def resource_type(self) -> str:
        return "postgres_transformed_dataset"

    def to_proto(self) -> resource_pb2.Resource:
        """Convert to protobuf Resource message."""
        from featureform._generated.proto.featureform.v2 import resource_pb2

        return resource_pb2.Resource(
            postgres_transformed_dataset=resource_pb2.PostgresTransformedDataset(
                name=self.name,
                description=self.description,
                provider=self.provider,
                source_datasets=self.source_datasets,
                sql_query=self.sql_query,
                postgres_config=resource_pb2.PostgresDatasetConfig(
                    schema=self.postgres_config.schema,
                    table=self.postgres_config.table,
                ),
            )
        )


class SnowflakeTransformedDataset(TransformedDataset):
    """SQL transformation executed in Snowflake."""

    @property
    def resource_type(self) -> str:
        return "snowflake_transformed_dataset"

    def to_proto(self) -> resource_pb2.Resource:
        """Convert to protobuf Resource message."""
        from featureform._generated.proto.featureform.v2 import resource_pb2

        return resource_pb2.Resource(
            snowflake_transformed_dataset=resource_pb2.SnowflakeTransformedDataset(
                name=self.name,
                description=self.description,
                provider=self.provider,
                source_datasets=self.source_datasets,
                sql_query=self.sql_query,
            )
        )


class SparkTransformedDataset(TransformedDataset):
    """Spark SQL transformation with system-managed catalog output.

    Example:
        >>> features = ff.SparkTransformedDataset(
        ...     name="features",
        ...     provider="spark",
        ...     source_datasets=["events"],
        ...     sql_query="SELECT user_id, COUNT(*) FROM {{ events }} GROUP BY 1",
        ... )
    """

    transform_job_config: SparkJobConfig | None = Field(
        default=None, description="Optional Spark job settings"
    )

    @property
    def resource_type(self) -> str:
        return "spark_transformed_dataset"

    def to_proto(self) -> resource_pb2.Resource:
        """Convert to protobuf Resource message."""
        from featureform._generated.proto.featureform.v2 import provider_pb2, resource_pb2

        spark_cfg = None
        if self.transform_job_config:
            execution = self.transform_job_config.execution_defaults
            spark_cfg = resource_pb2.SparkJobOverride(
                catalogs=cast(Any, self.transform_job_config.catalogs),
                deploy_mode=self.transform_job_config.deploy_mode or "",
                spark_conf=cast(Any, self.transform_job_config.spark_conf),
                execution_defaults=provider_pb2.SparkExecutionDefaults(
                    driver_cores=execution.driver_cores or 0,
                    driver_memory=execution.driver_memory or "",
                    executor_memory=execution.executor_memory or "",
                    executor_cores=execution.executor_cores or 0,
                    num_executors=execution.num_executors or 0,
                    shuffle_partitions=execution.shuffle_partitions or 0,
                ),
                driver_env=provider_pb2.SparkEnv(
                    values=self.transform_job_config.driver_env.values,
                    secrets={
                        key: _secret_ref_to_provider_proto(value, provider_pb2)
                        for key, value in self.transform_job_config.driver_env.secrets.items()
                    },
                ),
                executor_env=provider_pb2.SparkEnv(
                    values=self.transform_job_config.executor_env.values,
                    secrets={
                        key: _secret_ref_to_provider_proto(value, provider_pb2)
                        for key, value in self.transform_job_config.executor_env.secrets.items()
                    },
                ),
            )

        return resource_pb2.Resource(
            spark_transformed_dataset=resource_pb2.SparkTransformedDataset(
                name=self.name,
                description=self.description,
                provider=self.provider,
                source_datasets=self.source_datasets,
                sql_query=self.sql_query,
                transform_job_config=spark_cfg,
            )
        )
