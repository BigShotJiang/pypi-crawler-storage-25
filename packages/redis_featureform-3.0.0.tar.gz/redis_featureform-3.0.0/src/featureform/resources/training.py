"""Training resource classes."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from pydantic import Field, field_validator, model_validator

from featureform.resources.base import Resource, attach_provider_reference, resolve_name
from featureform.types.resource import (
    FeatureLag,
    JoinStrategy,
    MaterializationEngine,
    SparkJobConfig,
    TrainingSetType,
)
from featureform.types.secret import (
    AWSSecretRef,
    AzureSecretRef,
    EnvSecretRef,
    GCPSecretRef,
    K8sSecretRef,
    SecretRef,
    VaultSecretRef,
)

if TYPE_CHECKING:
    from featureform._generated.proto.featureform.v2 import resource_pb2


def _secret_ref_to_provider_proto(value: SecretRef, provider_pb2: Any) -> Any:
    if isinstance(value, EnvSecretRef):
        return provider_pb2.SecretRef(env=provider_pb2.EnvSecretRef(**value.model_dump()))
    if isinstance(value, VaultSecretRef):
        return provider_pb2.SecretRef(vault=provider_pb2.VaultSecretRef(**value.model_dump()))
    if isinstance(value, K8sSecretRef):
        return provider_pb2.SecretRef(k8s=provider_pb2.K8sSecretRef(**value.model_dump()))
    if isinstance(value, AWSSecretRef):
        return provider_pb2.SecretRef(
            aws_secrets_manager=provider_pb2.AWSSecretRef(**value.model_dump())
        )
    if isinstance(value, GCPSecretRef):
        return provider_pb2.SecretRef(
            gcp_secret_manager=provider_pb2.GCPSecretRef(**value.model_dump())
        )
    azure_ref: AzureSecretRef = value
    return provider_pb2.SecretRef(
        azure_key_vault=provider_pb2.AzureSecretRef(**azure_ref.model_dump())
    )


class TrainingSet(Resource):
    """Training set combining features and a label.

    A TrainingSet defines which features to join with a label for
    creating ML training datasets.

    Example:
        >>> ts = ff.TrainingSet(
        ...     name="churn_training",
        ...     features=["user_total_7d", "user_avg_7d"],
        ...     label="churned",
        ... )

    Attributes:
        name: Unique identifier for the training set.
        description: Human-readable description.
        features: List of feature names.
        label: Label name.
        type: Training set type (DYNAMIC or STATIC).
        feature_lags: Optional feature lags configuration.
    """

    name: str = Field(..., min_length=1, description="Training set name")
    description: str = Field(default="", description="Optional description")
    provider: str = Field(default="", description="Provider name")
    features: list[str] = Field(..., min_length=1, description="Feature names")
    label: str = Field(..., min_length=1, description="Label name")
    type: TrainingSetType = Field(default=TrainingSetType.DYNAMIC, description="Type")
    feature_lags: list[FeatureLag] = Field(default_factory=list, description="Feature lags")
    compute_job_config: SparkJobConfig | None = Field(
        default=None, description="Optional Spark compute settings"
    )

    def __init__(self, **data: Any) -> None:
        provider_input = data.get("provider")
        super().__init__(**data)
        if provider_input not in (None, ""):
            attach_provider_reference(self, provider_input, field_name="provider")

    @field_validator("features", mode="before")
    @classmethod
    def _resolve_features(cls, v: list[Any]) -> list[str]:
        """Accept feature names, FeatureResource objects, or FeatureBuilder objects."""
        return [resolve_name(f) for f in v]

    @field_validator("label", mode="before")
    @classmethod
    def _resolve_label(cls, v: Any) -> str:
        """Accept label name, LabelResource object, or LabelBuilder object."""
        return resolve_name(v)

    @field_validator("provider", mode="before")
    @classmethod
    def _resolve_provider(cls, v: Any) -> str:
        """Accept provider name or provider object."""
        if v == "":
            return ""
        return resolve_name(v)

    @property
    def resource_type(self) -> str:
        """Return the resource type name."""
        return "training_set"

    def model_dump(self, **kwargs: Any) -> dict[str, Any]:
        """Override to serialize enums properly."""
        data = super().model_dump(**kwargs)
        # Serialize TrainingSetType enum to string
        if "type" in data and hasattr(data["type"], "value"):
            data["type"] = data["type"].value
        return data

    def to_proto(self) -> resource_pb2.Resource:
        """Convert to protobuf Resource message."""
        from google.protobuf.duration_pb2 import Duration

        from featureform._generated.proto.featureform.v2 import provider_pb2, resource_pb2
        from featureform.resources.feature import parse_time_window

        lags: list[Any] = []
        for lag in self.feature_lags:
            lag_duration = Duration()
            lag_duration.FromTimedelta(parse_time_window(lag.lag))
            lags.append(
                resource_pb2.FeatureLag(name=lag.name, feature=lag.feature, lag=lag_duration)
            )
        spark_cfg = None
        if self.compute_job_config:
            execution = self.compute_job_config.execution_defaults
            spark_cfg = resource_pb2.JobConfig(
                spark=resource_pb2.SparkJobOverride(
                    catalogs=cast(Any, self.compute_job_config.catalogs),
                    deploy_mode=self.compute_job_config.deploy_mode or "",
                    spark_conf=cast(Any, self.compute_job_config.spark_conf),
                    execution_defaults=provider_pb2.SparkExecutionDefaults(
                        driver_cores=execution.driver_cores or 0,
                        driver_memory=execution.driver_memory or "",
                        executor_memory=execution.executor_memory or "",
                        executor_cores=execution.executor_cores or 0,
                        num_executors=execution.num_executors or 0,
                        shuffle_partitions=execution.shuffle_partitions or 0,
                    ),
                    driver_env=provider_pb2.SparkEnv(
                        values=self.compute_job_config.driver_env.values,
                        secrets={
                            key: _secret_ref_to_provider_proto(value, provider_pb2)
                            for key, value in self.compute_job_config.driver_env.secrets.items()
                        },
                    ),
                    executor_env=provider_pb2.SparkEnv(
                        values=self.compute_job_config.executor_env.values,
                        secrets={
                            key: _secret_ref_to_provider_proto(value, provider_pb2)
                            for key, value in self.compute_job_config.executor_env.secrets.items()
                        },
                    ),
                )
            )

        return resource_pb2.Resource(
            training_set=resource_pb2.TrainingSet(
                name=self.name,
                description=self.description,
                provider=self.provider,
                features=self.features,
                label=self.label,
                type=self.type.to_proto(),
                feature_lags=lags,
                compute_job_config=spark_cfg,
            )
        )


class FeatureView(Resource):
    """Feature View groups features for inference.

    A FeatureView defines which features to materialize to an inference
    store for online serving.

    Example:
        >>> fv = ff.FeatureView(
        ...     name="user_features",
        ...     entity="user",
        ...     features=["user_total_7d", "user_avg_7d"],
        ...     inference_store="redis",
        ...     materialization_engine=ff.MaterializationEngine.K8S,
        ... )

    Attributes:
        name: Unique identifier for the feature view.
        description: Human-readable description.
        entity: Entity this view serves.
        features: List of feature names.
        inference_store: Provider name for the inference store.
        materialization_engine: Engine to run materialization.
        join_strategy: How deduplicated feature sources are combined.
        batch_only: Maintain only the committed offline snapshot.
    """

    name: str = Field(..., min_length=1, description="Feature view name")
    description: str = Field(default="", description="Optional description")
    entity: str = Field(..., min_length=1, description="Entity name")
    features: list[str] = Field(..., min_length=1, description="Feature names")
    provider: str = Field(
        default="",
        description="Offline provider that owns feature-view compute and artifacts",
    )
    inference_store: str = Field(default="", description="Inference store provider")
    materialization_engine: MaterializationEngine = Field(..., description="Engine type")
    join_strategy: JoinStrategy = Field(
        default=JoinStrategy.FULL_OUTER, description="Join strategy"
    )
    spark_provider: str = Field(default="", description="Spark runtime provider for SPARK engine")
    materialize_job_config: SparkJobConfig | None = Field(
        default=None, description="Optional Spark materialization settings"
    )
    batch_only: bool = Field(default=False, description="Keep only the offline batch snapshot")

    def __init__(self, **data: Any) -> None:
        provider_input = data.get("provider")
        inference_store_input = data.get("inference_store")
        spark_provider_input = data.get("spark_provider")
        super().__init__(**data)
        if provider_input not in (None, ""):
            attach_provider_reference(self, provider_input, field_name="provider")
        attach_provider_reference(self, inference_store_input, field_name="inference_store")
        if spark_provider_input not in (None, ""):
            attach_provider_reference(self, spark_provider_input, field_name="spark_provider")

    @field_validator("entity", mode="before")
    @classmethod
    def _resolve_entity(cls, v: Any) -> str:
        """Accept entity name or Entity object."""
        return resolve_name(v)

    @field_validator("features", mode="before")
    @classmethod
    def _resolve_features(cls, v: list[Any]) -> list[str]:
        """Accept feature names, FeatureResource objects, or FeatureBuilder objects."""
        return [resolve_name(f) for f in v]

    @field_validator("inference_store", mode="before")
    @classmethod
    def _resolve_inference_store(cls, v: Any) -> str:
        """Accept provider name or Provider object."""
        if v in ("", None):
            return ""
        return resolve_name(v)

    @field_validator("provider", "spark_provider", mode="before")
    @classmethod
    def _resolve_provider_like(cls, v: Any) -> str:
        """Accept provider name or Provider object."""
        if v == "":
            return ""
        return resolve_name(v)

    @model_validator(mode="after")
    def _validate_batch_only(self) -> FeatureView:
        if self.batch_only and self.inference_store:
            raise ValueError("FeatureView inference_store cannot be set when batch_only=True")
        if not self.batch_only and not self.inference_store:
            raise ValueError("FeatureView inference_store is required when batch_only=False")
        return self

    @property
    def resource_type(self) -> str:
        """Return the resource type name."""
        return "feature_view"

    def to_proto(self) -> resource_pb2.Resource:
        """Convert to protobuf Resource message."""
        from featureform._generated.proto.featureform.v2 import provider_pb2, resource_pb2

        spark_cfg = None
        if self.materialize_job_config:
            execution = self.materialize_job_config.execution_defaults
            spark_cfg = resource_pb2.JobConfig(
                spark=resource_pb2.SparkJobOverride(
                    catalogs=cast(Any, self.materialize_job_config.catalogs),
                    deploy_mode=self.materialize_job_config.deploy_mode or "",
                    spark_conf=cast(Any, self.materialize_job_config.spark_conf),
                    execution_defaults=provider_pb2.SparkExecutionDefaults(
                        driver_cores=execution.driver_cores or 0,
                        driver_memory=execution.driver_memory or "",
                        executor_memory=execution.executor_memory or "",
                        executor_cores=execution.executor_cores or 0,
                        num_executors=execution.num_executors or 0,
                        shuffle_partitions=execution.shuffle_partitions or 0,
                    ),
                    driver_env=provider_pb2.SparkEnv(
                        values=self.materialize_job_config.driver_env.values,
                        secrets={
                            key: _secret_ref_to_provider_proto(value, provider_pb2)
                            for key, value in self.materialize_job_config.driver_env.secrets.items()
                        },
                    ),
                    executor_env=provider_pb2.SparkEnv(
                        values=self.materialize_job_config.executor_env.values,
                        secrets={
                            key: _secret_ref_to_provider_proto(value, provider_pb2)
                            for key, value in self.materialize_job_config.executor_env.secrets.items()
                        },
                    ),
                )
            )

        return resource_pb2.Resource(
            feature_view=resource_pb2.FeatureView(
                name=self.name,
                description=self.description,
                entity=self.entity,
                features=self.features,
                provider=self.provider,
                inference_store=self.inference_store,
                materialization_engine=self.materialization_engine.to_proto(),
                join_strategy=self.join_strategy.to_proto(),
                spark_provider=self.spark_provider,
                materialize_job_config=spark_cfg,
                batch_only=self.batch_only,
            )
        )
