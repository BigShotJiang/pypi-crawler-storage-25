"""Label resource class with fluent builder API.

Example usage:
    # Single entity
    fraud_label = (
        ff.Label()
        .from_dataset(user_fraud_labels)
        .value("is_fraud")
        .timestamp("label_ts")
        .entity("user", column="user_id")
    )

    # Multiple entities
    multi_label = (
        ff.Label()
        .from_dataset(transaction_labels)
        .value("is_fraud")
        .entity("user", column="user_id")
        .entity("merchant", column="merchant_id")
    )
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, ClassVar

from pydantic import ConfigDict, Field

from featureform.errors import (
    LabelDatasetRequiredError,
    LabelEntityRequiredError,
    LabelValueRequiredError,
)
from featureform.resources.base import Resource, attach_provider_reference, resolve_name
from featureform.types.entity import EntityMapping
from featureform.types.resource import ScalarType, ValueType

if TYPE_CHECKING:
    from featureform._generated.proto.featureform.v2 import resource_pb2
    from featureform.resources.dataset import Dataset


class LabelBuilder:
    """Fluent builder for creating labels.

    Example:
        >>> fraud_label = (
        ...     ff.Label()
        ...     .from_dataset(user_fraud_labels)
        ...     .value("is_fraud")
        ...     .timestamp("label_ts")
        ...     .entity("user", column="user_id")
        ... )
    """

    def __init__(self) -> None:
        from featureform.resources.base import ResourceRegistry

        self._source_dataset: str | None = None
        self._value_column: str | None = None
        self._timestamp_column: str = ""
        self._entities: list[EntityMapping] = []
        self._description: str = ""
        self._provider: str = ""
        self._provider_obj: Any | None = None
        self._built_resource: LabelResource | None = None

        # Register the builder - it will be resolved at get_all() time
        ResourceRegistry.register_builder(self)

    def from_dataset(self, dataset: str | Dataset) -> LabelBuilder:
        """Specify the source dataset."""
        self._source_dataset = resolve_name(dataset)
        return self

    def value(self, column: str) -> LabelBuilder:
        """Specify the column containing the label value."""
        self._value_column = column
        return self

    def timestamp(self, column: str) -> LabelBuilder:
        """Specify the column containing the timestamp."""
        self._timestamp_column = column
        return self

    def entity(self, name: str, *, column: str) -> LabelBuilder:
        """Add an entity mapping.

        Args:
            name: Name of the entity (e.g., "user", "merchant").
            column: Column name in the dataset containing the entity ID (REQUIRED).

        Returns:
            Self for chaining. Can be called multiple times for multiple entities.

        Example:
            >>> label = (
            ...     ff.Label()
            ...     .from_dataset("labels")
            ...     .value("target")
            ...     .entity("user", column="user_id")
            ...     .entity("merchant", column="merchant_id")
            ... )
        """
        self._entities.append(EntityMapping(name=name, column=column))
        return self

    def with_description(self, desc: str) -> LabelBuilder:
        """Set the label description."""
        self._description = desc
        return self

    def with_provider(self, provider_obj: str | Any) -> LabelBuilder:
        """Set the provider."""
        self._provider = resolve_name(provider_obj)
        self._provider_obj = provider_obj
        return self

    def build(self) -> LabelResource:
        """Build the final LabelResource. Called automatically when chaining ends."""
        if self._built_resource is None:
            self._built_resource = self._create_resource()
        return self._built_resource

    def _create_resource(self) -> LabelResource:
        """Create the LabelResource (only called once)."""
        if self._source_dataset is None:
            raise LabelDatasetRequiredError("Must call from_dataset()")
        if self._value_column is None:
            raise LabelValueRequiredError("Must call value()")
        if not self._entities:
            raise LabelEntityRequiredError("Must call entity() at least once")

        label = LabelResource(
            source_dataset=self._source_dataset,
            value_column=self._value_column,
            timestamp_column=self._timestamp_column,
            entities=tuple(self._entities),
            description=self._description,
            provider=self._provider,
        )
        if self._provider_obj is not None:
            attach_provider_reference(label, self._provider_obj, field_name="provider")
        return label

    # Allow using the builder result directly as a LabelResource
    def __getattr__(self, name: str) -> Any:
        """Delegate attribute access to built resource for seamless usage."""
        if name.startswith("_"):
            raise AttributeError(name)
        return getattr(self.build(), name)

    def __repr__(self) -> str:
        """Return representation of the built resource."""
        try:
            return repr(self.build())
        except ValueError:
            return "LabelBuilder(incomplete)"


def Label() -> LabelBuilder:  # noqa: N802
    """Start building a label. Returns a LabelBuilder for fluent construction."""
    return LabelBuilder()


class LabelResource(Resource):
    """Label resource representing a target variable for ML training.

    Supports multiple entities, each with a name and column mapping.

    NOTE: LabelResource does NOT auto-register because it's always created through
    LabelBuilder which already registered itself. This prevents double-registration
    and mutation-during-iteration bugs in ResourceRegistry.get_all().
    """

    # Disable auto-registration - LabelBuilder handles registration
    _auto_register: ClassVar[bool] = False

    source_dataset: str = Field(..., min_length=1, description="Source dataset name")
    value_column: str = Field(
        ..., min_length=1, description="Value column name", serialization_alias="value_field"
    )
    entities: tuple[EntityMapping, ...] = Field(
        ..., min_length=1, description="Entity mappings (name -> column)"
    )
    timestamp_column: str = Field(
        default="", description="Timestamp column name", serialization_alias="timestamp_field"
    )
    value_type: ValueType = Field(
        default_factory=lambda: ValueType(scalar_type=ScalarType.BOOL),
        description="Type of the label value (defaults to BOOL)",
    )
    description: str = Field(default="", description="Optional description")
    provider: str = Field(default="", description="Provider name")

    model_config = ConfigDict(
        frozen=True, extra="forbid", arbitrary_types_allowed=True, populate_by_name=True
    )

    def model_dump(self, **kwargs: Any) -> dict[str, Any]:
        """Override to include entities and entity_fields as lists."""
        data = super().model_dump(**kwargs)
        # Remove the entities tuple and convert to lists for server
        entities_data = data.pop("entities", ())
        data["entities"] = [e["name"] for e in entities_data]
        data["entity_fields"] = [e["column"] for e in entities_data]
        # Serialize value_type properly for JSON
        if hasattr(self, "value_type"):
            vt = self.value_type.model_dump()
            # Convert scalar_type enum to string
            if "scalar_type" in vt:
                vt["scalar_type"] = (
                    str(vt["scalar_type"].value)
                    if hasattr(vt["scalar_type"], "value")
                    else str(vt["scalar_type"])
                )
            data["value_type"] = vt
        return data

    @property
    def resource_type(self) -> str:
        return "label"

    @property
    def name(self) -> str:
        """Generate label name from dataset and column."""
        return f"{self.source_dataset}_{self.value_column}"

    def to_proto(self) -> resource_pb2.Resource:
        """Convert to protobuf Resource message."""
        from featureform._generated.proto.featureform.v2 import resource_pb2

        return resource_pb2.Resource(
            label=resource_pb2.Label(
                name=self.name,
                description=self.description,
                entities=[e.name for e in self.entities],
                entity_fields=[e.column for e in self.entities],
                value_field=self.value_column,
                timestamp_field=self.timestamp_column,
                source_dataset=self.source_dataset,
                provider=self.provider,
                value_type=resource_pb2.ValueType(
                    scalar_type=self.value_type.scalar_type.to_proto(),
                    is_vector=self.value_type.is_vector,
                    dimension=self.value_type.dimension,
                    is_embedding=self.value_type.is_embedding,
                ),
            )
        )
