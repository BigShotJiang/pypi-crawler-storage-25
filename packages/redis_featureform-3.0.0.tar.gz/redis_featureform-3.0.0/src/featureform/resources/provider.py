"""Provider configuration for Featureform.

Providers are configurations that represent external systems and act as:
1. Factories for datasets via .dataset() method
2. Decorator factories for transformations via .sql_transformation()

IMPORTANT: Providers are NOT Resources. They are:
- Configuration containers (host, port, credentials)
- Factories for datasets and transformations
- Registered separately via CLI or client.providers.register()

Resources (Entity, Feature, Label, TrainingSet) reference providers by name.
Provider-backed resource authoring should use backend-resolved provider objects
from `client.get_provider()` / `client.get_postgres()` or plain provider names.
"""

from __future__ import annotations

import re
from abc import ABC, abstractmethod
from collections.abc import Callable
from typing import TYPE_CHECKING, Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr

from featureform.resources.base import attach_provider_reference, resolve_name
from featureform.types.secret import EnvSecretRef, K8sSecretRef, SecretRef, VaultSecretRef

if TYPE_CHECKING:
    from featureform.resources.dataset import (
        Dataset,
        IcebergPrimaryDataset,
        PostgresPrimaryDataset,
        PostgresTransformedDataset,
        SnowflakePrimaryDataset,
        SnowflakeTransformedDataset,
        SparkTransformedDataset,
    )
    from featureform.resources.realtime_feature import RealtimeFeature, RealtimeFeatureInput
    from featureform.types.resource import SparkJobConfig


class SecretProviderBase(BaseModel, ABC):
    """Base class for secret provider configurations.

    SecretProviders define where secrets are stored (Vault, Env, K8s, etc.).
    Use .secret() to create references to specific secret values.

    SecretProviders are NOT Resources - they are registered separately via:
    - CLI: `ff secret-provider register ...`
    - Client: `client.secret_providers.register(provider)`
    """

    name: str = Field(..., min_length=1, description="Secret provider name")
    description: str = Field(default="", description="Optional description")
    _resolved: bool = PrivateAttr(default=False)
    _workspace_id: UUID | None = PrivateAttr(default=None)

    model_config = ConfigDict(frozen=True, extra="forbid")

    @property
    @abstractmethod
    def secret_provider_type(self) -> str:
        """Return the secret provider type (e.g., 'vault', 'env', 'k8s')."""
        ...

    def mark_resolved(self, *, workspace_id: UUID | None = None) -> None:
        self._resolved = True
        self._workspace_id = workspace_id

    def is_resolved(self) -> bool:
        return self._resolved

    @property
    def workspace_id(self) -> UUID | None:
        return self._workspace_id

    def _mark_resolved(self, *, workspace_id: UUID | None = None) -> None:
        self.mark_resolved(workspace_id=workspace_id)

    def _is_resolved(self) -> bool:
        return self.is_resolved()

    # Note: secret() method is defined by each subclass with appropriate signature
    # since different providers have different parameters


class EnvSecretProvider(SecretProviderBase):
    """Environment variable secret provider.

    Reads secrets from environment variables.

    Example:
        >>> env = client.secrets()
        >>> pg_password = env.get("PG_PASSWORD")
    """

    name: str = Field(default="env", min_length=1, description="Secret provider name")
    prefix: str = Field(default="", description="Optional prefix for env var names")

    @property
    def secret_provider_type(self) -> str:
        return "env"

    def secret(self, key: str) -> EnvSecretRef:
        """Create a reference to an environment variable secret."""
        full_key = f"{self.prefix}{key}" if self.prefix else key
        provider_name = None if self.name == "env" else self.name
        return EnvSecretRef(name=full_key, provider_name=provider_name)


class VaultSecretProvider(SecretProviderBase):
    """HashiCorp Vault secret provider.

    Reads secrets from HashiCorp Vault.

    Example:
        >>> vault = client.secrets("vault")
        >>> pg_password = vault.get("database/postgres", key="password")
    """

    address: str = Field(..., description="Vault server address")
    namespace: str = Field(default="", description="Vault namespace (Enterprise)")
    mount_path: str = Field(default="secret", description="KV secrets engine mount path")

    @property
    def secret_provider_type(self) -> str:
        return "vault"

    def secret(self, path: str, key: str) -> VaultSecretRef:
        """Create a reference to a Vault secret.

        Args:
            path: Path to the secret within the mount (e.g., "database/postgres")
            key: Specific field within the secret
        """
        return VaultSecretRef(provider_name=self.name, path=path, key=key)


class K8sSecretProvider(SecretProviderBase):
    """Kubernetes secret provider.

    Reads secrets from Kubernetes Secrets.

    Example:
        >>> k8s = ff.K8sSecretProvider(name="k8s", namespace="featureform")
        >>> pg_password = k8s.secret("postgres-credentials", key="password")
    """

    namespace: str = Field(default="default", description="Kubernetes namespace")

    @property
    def secret_provider_type(self) -> str:
        return "k8s"

    def secret(self, secret_name: str, key: str) -> K8sSecretRef:
        """Create a reference to a Kubernetes secret.

        Args:
            secret_name: Name of the Kubernetes Secret
            key: Key within the secret data
        """
        return K8sSecretRef(provider_name=self.name, name=secret_name, key=key)


class Provider(BaseModel, ABC):
    """Base class for all provider configurations.

    Providers are NOT Resources - they are registered separately via:
    - CLI: `ff provider register ...`
    - Client: `client.providers.register(provider)`

    Providers act as factories:
    - .dataset() creates PrimaryDataset resources
    - .sql_transformation() decorator creates TransformedDataset resources

    Example:
        >>> postgres = client.get_postgres("analytics_db")
        >>>
        >>> users = postgres.dataset(name="users", table="users")
        >>>
        >>> @postgres.sql_transformation(inputs=[users])
        ... def daily_totals():
        ...     return "SELECT date, SUM(amount) FROM {{ users }} GROUP BY date"
    """

    name: str = Field(..., min_length=1, description="Provider name")
    description: str = Field(default="", description="Optional description")
    _resolved: bool = PrivateAttr(default=False)
    _workspace_id: UUID | None = PrivateAttr(default=None)

    model_config = ConfigDict(frozen=True, extra="forbid")

    @property
    @abstractmethod
    def provider_type(self) -> str:
        """Return the provider type (e.g., 'postgres', 'spark', 'redis')."""
        ...

    def mark_resolved(self, *, workspace_id: UUID | None = None) -> None:
        self._resolved = True
        self._workspace_id = workspace_id

    def is_resolved(self) -> bool:
        return self._resolved

    @property
    def workspace_id(self) -> UUID | None:
        return self._workspace_id

    def _mark_resolved(self, *, workspace_id: UUID | None = None) -> None:
        self.mark_resolved(workspace_id=workspace_id)

    def _is_resolved(self) -> bool:
        return self.is_resolved()

    @staticmethod
    def _extract_sources_from_sql(sql_query: str) -> list[str]:
        """Extract source table names from SQL {{ table }} syntax."""
        matches = re.findall(r"\{\{\s*(\w+)\s*\}\}", sql_query)
        return list(dict.fromkeys(matches))  # Dedupe, preserve order

    @staticmethod
    def _resolve_sources(
        sources: list[str | Dataset] | None,
        sql_query: str,
    ) -> list[str]:
        """Resolve source names from explicit list or extract from SQL."""
        if sources:
            return [s if isinstance(s, str) else s.name for s in sources]
        return Provider._extract_sources_from_sql(sql_query)

    @staticmethod
    def build_sql_transformation_definition(
        func: Callable[..., str],
        inputs: list[str | Dataset] | None,
    ) -> tuple[str, list[str]]:
        import inspect

        sig = inspect.signature(func)
        params = list(sig.parameters.keys())

        source_names: list[str] = []
        for ds in inputs or []:
            if isinstance(ds, str):
                source_names.append(ds)
            elif hasattr(ds, "name"):
                source_names.append(str(ds.name))
            else:
                source_names.append(str(ds))

        sql_query = func(*params) if params else func()
        for i, param in enumerate(params):
            if i < len(source_names):
                sql_query = sql_query.replace(f"{{{{ {param} }}}}", f"{{{{ {source_names[i]} }}}}")

        return sql_query, Provider._resolve_sources(inputs, sql_query)

    @staticmethod
    def _build_sql_transformation_definition(
        func: Callable[..., str],
        inputs: list[str | Dataset] | None,
    ) -> tuple[str, list[str]]:
        return Provider.build_sql_transformation_definition(func, inputs)

    def realtime_feature(
        self,
        *,
        entity: str,
        inputs: list[RealtimeFeatureInput],
        name: str | None = None,
        description: str | None = None,
        requirements: list[str] | None = None,
    ) -> Callable[[Callable[..., Any]], RealtimeFeature]:
        """Create a provider-scoped realtime feature decorator."""
        from featureform.resources.realtime_feature import create_realtime_feature

        def decorator(func: Callable[..., Any]) -> RealtimeFeature:
            feature = create_realtime_feature(
                provider=self.name,
                entity=entity,
                inputs=inputs,
                fn=func,
                name=name,
                description=description,
                requirements=requirements,
            )
            attach_provider_reference(feature, self, field_name="provider")
            return feature

        return decorator


class PostgresProvider(Provider):
    """PostgreSQL provider configuration.

    Creates datasets and SQL transformations that run on PostgreSQL.
    For apply authoring, prefer a backend-resolved handle from
    ``client.get_postgres(...)`` over constructing a local provider object.

    Example:
        >>> postgres = client.get_postgres("transactions_db")
        >>> transactions = postgres.dataset(name="transactions", table="transactions")
    """

    host: str = Field(..., description="Postgres host")
    port: int = Field(default=5432, ge=1, le=65535, description="Postgres port")
    database: str = Field(..., description="Database name")
    user: str | None = Field(default=None, description="Username")
    password: SecretRef | None = Field(default=None, description="Password secret reference")
    ssl_mode: str = Field(default="prefer", description="SSL mode")

    @property
    def provider_type(self) -> str:
        return "postgres"

    def dataset(
        self,
        *,
        name: str,
        table: str,
        schema: str = "public",
        database: str | None = None,
        description: str = "",
        timestamp_column: str = "",
    ) -> PostgresPrimaryDataset:
        """Create a primary dataset from this Postgres provider.

        Example:
            >>> users = postgres.dataset(
            ...     name="users",
            ...     table="users",
            ...     schema="public",
            ...     timestamp_column="updated_at",
            ... )
        """
        from featureform.resources.dataset import PostgresPrimaryDataset
        from featureform.types.resource import TableLocation

        dataset = PostgresPrimaryDataset(
            name=name,
            description=description,
            provider=self.name,
            location=TableLocation(
                database=database or self.database,
                schema=schema,
                table=table,
            ),
            timestamp_column=timestamp_column,
        )
        attach_provider_reference(dataset, self, field_name="provider")
        return dataset

    def sql_transformation(
        self,
        *,
        name: str | None = None,
        description: str | None = None,
        inputs: list[str | Dataset] | None = None,
        output_schema: str = "ff_transforms",
    ) -> Callable[[Callable[..., str]], PostgresTransformedDataset]:
        """Create a PostgreSQL SQL transformation.

        Function parameters map positionally to inputs and can be used in Jinja templates.

        Example:
            >>> @postgres.sql_transformation(inputs=[transactions, users])
            ... def daily_totals(txns, u):
            ...     '''Aggregate transactions by day.'''
            ...     return '''
            ...         SELECT date_trunc('day', ts) as day, SUM(amount)
            ...         FROM {{ txns }}
            ...         JOIN {{ u }} ON txns.user_id = u.user_id
            ...         GROUP BY 1
            ...     '''
        """
        from featureform.resources.dataset import PostgresTransformedDataset
        from featureform.types.resource import PostgresDatasetConfig

        def decorator(func: Callable[..., str]) -> PostgresTransformedDataset:
            dataset_name = name or func.__name__
            sql_query, final_source_names = self.build_sql_transformation_definition(func, inputs)

            dataset = PostgresTransformedDataset(
                name=dataset_name,
                description=description if description is not None else (func.__doc__ or ""),
                provider=self.name,
                source_datasets=final_source_names,
                sql_query=sql_query,
                postgres_config=PostgresDatasetConfig(
                    schema=output_schema,
                    table=dataset_name,
                ),
            )
            attach_provider_reference(dataset, self, field_name="provider")
            return dataset

        return decorator


class SnowflakeProvider(Provider):
    """Snowflake provider configuration for resource authoring."""

    account: str = Field(default="", description="Snowflake account identifier")
    host: str = Field(default="", description="Snowflake host")
    warehouse: str = Field(default="", description="Snowflake warehouse")
    database: str = Field(..., description="Snowflake database")
    schema_name: str = Field(default="PUBLIC", alias="schema", description="Snowflake schema")
    auth_type: str = Field(default="password", description="Snowflake auth type")
    username: str | None = Field(default=None, description="Snowflake username")
    password_secret: SecretRef | None = Field(
        default=None,
        description="Secret reference for Snowflake password auth",
    )
    private_key_secret: SecretRef | None = Field(
        default=None,
        description="Secret reference for Snowflake key-pair auth",
    )
    passphrase_secret: SecretRef | None = Field(
        default=None,
        description="Secret reference for Snowflake key-pair passphrase",
    )
    oauth_client_id: str | None = Field(default=None, description="Snowflake OAuth client ID")
    oauth_client_secret: SecretRef | None = Field(
        default=None,
        description="Secret reference for Snowflake OAuth client secret",
    )
    oauth_token: SecretRef | None = Field(
        default=None,
        description="Secret reference for Snowflake OAuth token",
    )
    role: str | None = Field(default=None, description="Snowflake role")
    login_timeout: int | None = Field(default=None, description="Snowflake login timeout")
    request_timeout: int | None = Field(default=None, description="Snowflake request timeout")
    session_params: dict[str, str] = Field(
        default_factory=dict,
        description="Snowflake session parameters",
    )

    @property
    def provider_type(self) -> str:
        return "snowflake"

    def dataset(
        self,
        *,
        name: str,
        table: str,
        schema: str | None = None,
        database: str | None = None,
        description: str = "",
        timestamp_column: str = "",
    ) -> SnowflakePrimaryDataset:
        """Create a primary dataset from this Snowflake provider."""
        from featureform.resources.dataset import SnowflakePrimaryDataset
        from featureform.types.resource import TableLocation

        return SnowflakePrimaryDataset(
            name=name,
            description=description,
            provider=self.name,
            location=TableLocation(
                database=database or self.database,
                schema=schema or self.schema_name,
                table=table,
            ),
            timestamp_column=timestamp_column,
        )

    def sql_transformation(
        self,
        *,
        name: str | None = None,
        description: str | None = None,
        inputs: list[str | Dataset] | None = None,
    ) -> Callable[[Callable[..., str]], SnowflakeTransformedDataset]:
        """Create a Snowflake SQL transformation."""
        from featureform.resources.dataset import SnowflakeTransformedDataset

        def decorator(func: Callable[..., str]) -> SnowflakeTransformedDataset:
            dataset_name = name or func.__name__
            sql_query, final_source_names = self._build_sql_transformation_definition(func, inputs)

            return SnowflakeTransformedDataset(
                name=dataset_name,
                description=description if description is not None else (func.__doc__ or ""),
                provider=self.name,
                source_datasets=final_source_names,
                sql_query=sql_query,
            )

        return decorator


class SparkProvider(Provider):
    """Spark provider for running SQL transformations.

    Example:
        >>> @ff.spark_sql_transformation(provider="spark_cluster", inputs=["events"])
        ... def compute_features():
        ...     return "SELECT user_id, COUNT(*) AS cnt FROM {{ events }} GROUP BY 1"
    """

    catalogs: dict[str, str] = Field(default_factory=dict, description="Spark catalog aliases")

    @property
    def provider_type(self) -> str:
        return "spark"

    def sql_transformation(
        self,
        *,
        name: str | None = None,
        description: str | None = None,
        inputs: list[str | Dataset] | None = None,
        transform_job_config: SparkJobConfig | None = None,
    ) -> Callable[[Callable[..., str]], SparkTransformedDataset]:
        """Create a Spark SQL transformation with system-managed output.

        Function parameters map positionally to inputs and can be used in Jinja templates.

        Example:
            >>> @spark.sql_transformation(inputs=[events])
            ... def compute_features(e):
            ...     '''Compute user features from events.'''
            ...     return "SELECT user_id, COUNT(*) FROM {{ e }} GROUP BY 1"
        """
        from featureform.resources.dataset import SparkTransformedDataset

        def decorator(func: Callable[..., str]) -> SparkTransformedDataset:
            dataset_name = name or func.__name__
            sql_query, final_source_names = self.build_sql_transformation_definition(func, inputs)

            dataset = SparkTransformedDataset(
                name=dataset_name,
                description=description if description is not None else (func.__doc__ or ""),
                provider=self.name,
                source_datasets=final_source_names,
                sql_query=sql_query,
                transform_job_config=transform_job_config,
            )
            attach_provider_reference(dataset, self, field_name="provider")
            return dataset

        return decorator


class RedisProvider(Provider):
    """Redis provider for online feature storage.

    Example:
        >>> redis = ff.RedisProvider(
        ...     name="redis",
        ...     host="localhost",
        ...     port=6379,
        ... )
    """

    host: str = Field(..., description="Redis host")
    port: int = Field(default=6379, ge=1, le=65535, description="Redis port")
    database: int = Field(default=0, ge=0, description="Redis database number")
    password: SecretRef | None = Field(default=None, description="Password secret reference")

    @property
    def provider_type(self) -> str:
        return "redis"


class RedisClusterProvider(Provider):
    """Redis Cluster provider for online feature storage."""

    endpoints: list[str] = Field(..., description="Redis cluster startup endpoints")
    password: SecretRef | None = Field(default=None, description="Password secret reference")

    @property
    def provider_type(self) -> str:
        return "redis-cluster"


class S3Provider(Provider):
    """S3 provider for storage.

    Example:
        >>> s3 = ff.S3Provider(
        ...     name="s3_bucket",
        ...     bucket="my-bucket",
        ...     region="us-east-1",
        ... )
    """

    bucket: str = Field(..., description="S3 bucket name")
    region: str = Field(..., description="AWS region")
    access_key_id: SecretRef | None = Field(default=None, description="Access key secret reference")
    secret_access_key: SecretRef | None = Field(
        default=None, description="Secret key secret reference"
    )
    endpoint: str | None = Field(default=None, description="Custom endpoint for S3-compatible")

    @property
    def provider_type(self) -> str:
        return "s3"


class IcebergProvider(Provider):
    """Iceberg catalog provider.

    Example:
        >>> iceberg = ff.IcebergProvider(
        ...     name="iceberg_catalog",
        ...     catalog_name="main",
        ...     warehouse="s3://my-bucket/warehouse",
        ... )
    """

    catalog_name: str = Field(..., description="Canonical Iceberg catalog name")
    warehouse: str = Field(..., description="Warehouse location")

    @property
    def provider_type(self) -> str:
        return "iceberg"

    def dataset(
        self,
        *,
        name: str,
        namespace: str,
        table: str,
        description: str = "",
        timestamp_column: str = "",
    ) -> IcebergPrimaryDataset:
        """Create a primary dataset from this Iceberg catalog."""
        from featureform.resources.dataset import IcebergPrimaryDataset
        from featureform.types.resource import IcebergTableLocation

        dataset = IcebergPrimaryDataset(
            name=name,
            description=description,
            provider=self.name,
            location=IcebergTableLocation(
                namespace=namespace,
                table=table,
            ),
            timestamp_column=timestamp_column,
        )
        attach_provider_reference(dataset, self, field_name="provider")
        return dataset


def postgres_sql_transformation(
    *,
    provider: str | Any,
    name: str | None = None,
    description: str | None = None,
    inputs: list[str | Dataset] | None = None,
    output_schema: str = "ff_transforms",
) -> Callable[[Callable[..., str]], PostgresTransformedDataset]:
    """Create a PostgreSQL SQL transformation from a provider name or resolved provider object."""
    from featureform.resources.dataset import PostgresTransformedDataset
    from featureform.types.resource import PostgresDatasetConfig

    provider_name = resolve_name(provider)

    def decorator(func: Callable[..., str]) -> PostgresTransformedDataset:
        dataset_name = name or func.__name__
        sql_query, final_source_names = Provider.build_sql_transformation_definition(func, inputs)
        dataset = PostgresTransformedDataset(
            name=dataset_name,
            description=description if description is not None else (func.__doc__ or ""),
            provider=provider_name,
            source_datasets=final_source_names,
            sql_query=sql_query,
            postgres_config=PostgresDatasetConfig(
                schema=output_schema,
                table=dataset_name,
            ),
        )
        attach_provider_reference(dataset, provider, field_name="provider")
        return dataset

    return decorator


def spark_sql_transformation(
    *,
    provider: str | Any,
    name: str | None = None,
    description: str | None = None,
    inputs: list[str | Dataset] | None = None,
    transform_job_config: SparkJobConfig | None = None,
) -> Callable[[Callable[..., str]], SparkTransformedDataset]:
    """Create a Spark SQL transformation from a provider name or resolved provider object."""
    from featureform.resources.dataset import SparkTransformedDataset

    provider_name = resolve_name(provider)

    def decorator(func: Callable[..., str]) -> SparkTransformedDataset:
        dataset_name = name or func.__name__
        sql_query, final_source_names = Provider.build_sql_transformation_definition(func, inputs)
        dataset = SparkTransformedDataset(
            name=dataset_name,
            description=description if description is not None else (func.__doc__ or ""),
            provider=provider_name,
            source_datasets=final_source_names,
            sql_query=sql_query,
            transform_job_config=transform_job_config,
        )
        attach_provider_reference(dataset, provider, field_name="provider")
        return dataset

    return decorator


__all__ = [
    "SecretProviderBase",
    "EnvSecretProvider",
    "VaultSecretProvider",
    "K8sSecretProvider",
    "Provider",
    "PostgresProvider",
    "SnowflakeProvider",
    "SparkProvider",
    "RedisProvider",
    "RedisClusterProvider",
    "S3Provider",
    "IcebergProvider",
    "postgres_sql_transformation",
    "spark_sql_transformation",
]
