"""Featureform resource definitions.

This module provides the new DSL for defining Featureform resources:
- Provider-based transformations via decorators (@provider.sql_transformation)
- Fluent builder API for Features and Labels
- Auto-registration to ResourceRegistry for apply

Example:
    >>> client = ff.Client()
    >>> postgres = client.get_postgres("pg")
    >>> users = postgres.dataset(name="users", table="users")
    >>>
    >>> @postgres.sql_transformation(inputs=[users])
    ... def daily_stats():
    ...     return "SELECT date, COUNT(*) FROM {{ users }} GROUP BY date"
    >>>
    >>> user_count = (
    ...     ff.Feature()
    ...     .from_dataset(daily_stats, entity="user_id", value="count", timestamp="date")
    ...     .aggregate(function=ff.AggregateFunction.COUNT, window=timedelta(days=7))
    ... )
"""

from featureform.resources.base import Resource, ResourceRegistry, resolve_name
from featureform.resources.dataset import (
    Dataset,
    IcebergPrimaryDataset,
    PostgresPrimaryDataset,
    PostgresTransformedDataset,
    PrimaryDataset,
    SnowflakePrimaryDataset,
    SnowflakeTransformedDataset,
    SparkTransformedDataset,
    TransformedDataset,
)
from featureform.resources.entity import Entity
from featureform.resources.feature import (
    AggregateFeature,
    AttributeFeature,
    Feature,
    FeatureBuilder,
    FeatureResource,
)
from featureform.resources.label import Label, LabelBuilder, LabelResource
from featureform.resources.provider import (
    EnvSecretProvider,
    IcebergProvider,
    K8sSecretProvider,
    PostgresProvider,
    Provider,
    RedisClusterProvider,
    RedisProvider,
    S3Provider,
    SecretProviderBase,
    SnowflakeProvider,
    SparkProvider,
    VaultSecretProvider,
    postgres_sql_transformation,
    spark_sql_transformation,
)
from featureform.resources.realtime_feature import (
    FeatureInput,
    FunctionNormalizerDetails,
    RealtimeFeature,
    RealtimeInput,
    SerializerDetails,
    realtime_feature,
)
from featureform.resources.training import FeatureView, TrainingSet

__all__ = [
    # Base
    "Resource",
    "ResourceRegistry",
    "resolve_name",
    # Secrets
    "SecretProviderBase",
    "EnvSecretProvider",
    "VaultSecretProvider",
    "K8sSecretProvider",
    # Providers (NOT Resources - registered separately)
    "Provider",
    "PostgresProvider",
    "SnowflakeProvider",
    "SparkProvider",
    "RedisProvider",
    "RedisClusterProvider",
    "S3Provider",
    "IcebergProvider",
    "postgres_sql_transformation",
    "spark_sql_transformation",
    # Entity
    "Entity",
    # Datasets
    "Dataset",
    "PrimaryDataset",
    "PostgresPrimaryDataset",
    "SnowflakePrimaryDataset",
    "IcebergPrimaryDataset",
    "TransformedDataset",
    "PostgresTransformedDataset",
    "SnowflakeTransformedDataset",
    "SparkTransformedDataset",
    # Features (builder pattern)
    "Feature",
    "FeatureBuilder",
    "FeatureResource",
    "AttributeFeature",
    "AggregateFeature",
    "FeatureInput",
    # Labels (builder pattern)
    "Label",
    "LabelBuilder",
    "LabelResource",
    "FunctionNormalizerDetails",
    "RealtimeFeature",
    "RealtimeInput",
    "SerializerDetails",
    "realtime_feature",
    # Training
    "TrainingSet",
    "FeatureView",
]
