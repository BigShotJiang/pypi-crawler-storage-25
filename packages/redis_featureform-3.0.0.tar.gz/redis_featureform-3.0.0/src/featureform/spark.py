"""Spark helpers for Featureform dataframe execution."""

from __future__ import annotations

import re
import weakref
from dataclasses import dataclass, field
from typing import Any, cast

from featureform import spark_env

_S3A_SIMPLE_CREDENTIALS_PROVIDER = "org.apache.hadoop.fs.s3a.SimpleAWSCredentialsProvider"
_S3A_FILESYSTEM_IMPL = "org.apache.hadoop.fs.s3a.S3AFileSystem"


def _normalize_provider_token(value: str) -> str:
    return re.sub(r"[^A-Z0-9]+", "_", value.upper()).strip("_")


def _catalog_name_for_provider(provider_name: str) -> str:
    normalized = provider_name.lower()
    normalized = normalized.replace("-", "_").replace(".", "_").replace(" ", "_").replace("/", "_")
    return f"ff_{normalized}"


@dataclass(frozen=True)
class DataframeExecutionInfo:
    """Execution metadata attached to dataframe query results."""

    engine: str
    plan_type: str
    provider_kind: str | None = None
    provider_name: str | None = None
    fallback_reason: str | None = None


_EXECUTION_INFO_BY_OBJECT: weakref.WeakKeyDictionary[object, DataframeExecutionInfo] = (
    weakref.WeakKeyDictionary()
)


@dataclass(frozen=True)
class SparkOptions:
    """Client-local Spark configuration for dataframe reads."""

    jdbc_options: dict[str, str] = field(default_factory=dict)
    catalog_overrides: dict[str, str] = field(default_factory=dict)
    host_map: dict[str, str] = field(default_factory=dict)

    @classmethod
    def postgres(cls, **jdbc_options: str) -> SparkOptions:
        return cls(jdbc_options={str(key): str(value) for key, value in jdbc_options.items()})

    @classmethod
    def with_catalog_overrides(cls, overrides: dict[str, str]) -> SparkOptions:
        return cls(catalog_overrides={str(key): str(value) for key, value in overrides.items()})

    @classmethod
    def iceberg_s3(
        cls,
        *,
        provider_name: str,
        catalog_name: str | None = None,
        access_key_id: str | None = None,
        secret_access_key: str | None = None,
        region: str | None = None,
        endpoint: str | None = None,
        path_style_access: bool = False,
    ) -> SparkOptions:
        resolved_catalog_name = catalog_name or _catalog_name_for_provider(provider_name)
        overrides: dict[str, str] = {}
        if access_key_id:
            overrides[f"spark.sql.catalog.{resolved_catalog_name}.s3.access-key-id"] = access_key_id
            overrides[f"spark.sql.catalog.{resolved_catalog_name}.client.access-key-id"] = (
                access_key_id
            )
            overrides["spark.hadoop.fs.s3a.access.key"] = access_key_id
        if secret_access_key:
            overrides[f"spark.sql.catalog.{resolved_catalog_name}.s3.secret-access-key"] = (
                secret_access_key
            )
            overrides[f"spark.sql.catalog.{resolved_catalog_name}.client.secret-access-key"] = (
                secret_access_key
            )
            overrides["spark.hadoop.fs.s3a.secret.key"] = secret_access_key
        if access_key_id and secret_access_key:
            overrides["spark.hadoop.fs.s3a.aws.credentials.provider"] = (
                _S3A_SIMPLE_CREDENTIALS_PROVIDER
            )
        if region:
            overrides[f"spark.sql.catalog.{resolved_catalog_name}.s3.region"] = region
            overrides["spark.hadoop.fs.s3a.endpoint.region"] = region
        if endpoint:
            overrides[f"spark.sql.catalog.{resolved_catalog_name}.s3.endpoint"] = endpoint
            overrides["spark.hadoop.fs.s3a.endpoint"] = endpoint
            if endpoint.startswith("http://"):
                overrides["spark.hadoop.fs.s3a.connection.ssl.enabled"] = "false"
        if path_style_access:
            overrides[f"spark.sql.catalog.{resolved_catalog_name}.s3.path-style-access"] = "true"
            overrides["spark.hadoop.fs.s3a.path.style.access"] = "true"
        if endpoint or access_key_id or secret_access_key:
            overrides["spark.hadoop.fs.s3a.impl"] = _S3A_FILESYSTEM_IMPL
        return cls(catalog_overrides=overrides)

    @classmethod
    def from_env(
        cls,
        *,
        provider_kind: str | None,
        provider_name: str | None,
        catalog_name: str | None = None,
    ) -> SparkOptions:
        if not provider_kind or not provider_name:
            return cls()

        token = _normalize_provider_token(provider_name)
        if provider_kind == "postgres":
            password = spark_env.postgres_password(token)
            if password:
                return cls.postgres(password=password)
            return cls()

        if provider_kind == "iceberg":
            access_key_id = spark_env.iceberg_access_key_id(token)
            secret_access_key = spark_env.iceberg_secret_access_key(token)
            region = spark_env.iceberg_region(token)
            endpoint = spark_env.iceberg_endpoint(token)
            return cls.iceberg_s3(
                provider_name=provider_name,
                catalog_name=catalog_name,
                access_key_id=access_key_id,
                secret_access_key=secret_access_key,
                region=region,
                endpoint=endpoint,
            )

        return cls()

    def merge(self, other: SparkOptions | None) -> SparkOptions:
        if other is None:
            return self
        return SparkOptions(
            jdbc_options={**other.jdbc_options, **self.jdbc_options},
            catalog_overrides={**other.catalog_overrides, **self.catalog_overrides},
            host_map={**other.host_map, **self.host_map},
        )


def attach_execution_info(result: object, info: DataframeExecutionInfo) -> None:
    try:
        typed_result = cast(Any, result)
        typed_result.execution_info = info
        return
    except Exception:
        pass

    try:
        _EXECUTION_INFO_BY_OBJECT[result] = info
    except TypeError:
        # Some foreign result objects support neither attributes nor weakrefs.
        return


def get_execution_info(result: object) -> DataframeExecutionInfo | None:
    info = getattr(result, "execution_info", None)
    if isinstance(info, DataframeExecutionInfo):
        return info
    try:
        return _EXECUTION_INFO_BY_OBJECT.get(result)
    except TypeError:
        return None
