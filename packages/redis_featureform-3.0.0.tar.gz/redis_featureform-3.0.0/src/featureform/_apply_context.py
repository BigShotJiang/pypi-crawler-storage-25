"""Apply-time provider resolution context for resource files."""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager
from contextvars import ContextVar
from typing import TYPE_CHECKING
from uuid import UUID

if TYPE_CHECKING:
    from featureform.client import Client


_active_client: ContextVar[Client | None] = ContextVar(
    "featureform_active_apply_client",
    default=None,
)
_active_workspace_id: ContextVar[UUID | None] = ContextVar(
    "featureform_active_apply_workspace_id",
    default=None,
)


@contextmanager
def apply_resolution_context(
    *,
    client: Client | None,
    workspace_id: UUID | None,
) -> Iterator[None]:
    """Temporarily expose the active apply client/workspace to resource files."""
    client_token = _active_client.set(client)
    workspace_token = _active_workspace_id.set(workspace_id)
    try:
        yield
    finally:
        _active_client.reset(client_token)
        _active_workspace_id.reset(workspace_token)


def get_active_apply_client() -> Client | None:
    """Return the active apply client, if any."""
    return _active_client.get()


def get_active_apply_workspace_id() -> UUID | None:
    """Return the active apply workspace ID, if any."""
    return _active_workspace_id.get()
