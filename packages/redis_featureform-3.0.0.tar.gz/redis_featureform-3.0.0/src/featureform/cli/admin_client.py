"""Admin API client helpers for RBAC, audit, and machine credentials."""

from __future__ import annotations

from typing import Any, Protocol, cast

import grpc
import httpx

from featureform.cli.utils import CLIContext, TransportFormat

rbac_pb2: Any = None
rbac_pb2_grpc: Any = None
audit_pb2: Any = None
audit_pb2_grpc: Any = None

try:
    from featureform._generated.proto.featureform.v2 import audit_pb2 as _audit_pb2
    from featureform._generated.proto.featureform.v2 import audit_pb2_grpc as _audit_pb2_grpc
    from featureform._generated.proto.featureform.v2 import rbac_pb2 as _rbac_pb2
    from featureform._generated.proto.featureform.v2 import rbac_pb2_grpc as _rbac_pb2_grpc
except ModuleNotFoundError:
    pass
else:
    rbac_pb2 = _rbac_pb2
    rbac_pb2_grpc = _rbac_pb2_grpc
    audit_pb2 = _audit_pb2
    audit_pb2_grpc = _audit_pb2_grpc


class AdminClientError(Exception):
    """Raised when an admin API request fails."""

    def __init__(
        self,
        message: str | None = None,
        *,
        code: int = 1,
        status_code: int | None = None,
        response_text: str | None = None,
    ) -> None:
        if message is None:
            if status_code is not None and response_text is not None:
                message = f"HTTP {status_code}: {response_text}"
            else:
                message = "admin API request failed"
        super().__init__(message)
        self.message = message
        self.code = code
        self.status_code = status_code
        self.response_text = response_text


class RbacServiceStub(Protocol):
    def WhoAmI(self, request: Any, *, metadata: list[tuple[str, str]] | None = None) -> Any: ...
    def ListRoleDefinitions(
        self, request: Any, *, metadata: list[tuple[str, str]] | None = None
    ) -> Any: ...
    def ListPermissionDefinitions(
        self, request: Any, *, metadata: list[tuple[str, str]] | None = None
    ) -> Any: ...
    def SearchPrincipals(
        self, request: Any, *, metadata: list[tuple[str, str]] | None = None
    ) -> Any: ...
    def GrantRoleBinding(
        self, request: Any, *, metadata: list[tuple[str, str]] | None = None
    ) -> Any: ...
    def RevokeRoleBinding(
        self, request: Any, *, metadata: list[tuple[str, str]] | None = None
    ) -> Any: ...
    def RevokeRoleBindingByID(
        self, request: Any, *, metadata: list[tuple[str, str]] | None = None
    ) -> Any: ...
    def ListRoleBindings(
        self, request: Any, *, metadata: list[tuple[str, str]] | None = None
    ) -> Any: ...
    def ListRoleBindingSubjects(
        self, request: Any, *, metadata: list[tuple[str, str]] | None = None
    ) -> Any: ...
    def GrantModelResourceBinding(
        self, request: Any, *, metadata: list[tuple[str, str]] | None = None
    ) -> Any: ...
    def RevokeModelResourceBinding(
        self, request: Any, *, metadata: list[tuple[str, str]] | None = None
    ) -> Any: ...
    def RevokeModelResourceBindingByID(
        self, request: Any, *, metadata: list[tuple[str, str]] | None = None
    ) -> Any: ...
    def ListModelResourceBindings(
        self, request: Any, *, metadata: list[tuple[str, str]] | None = None
    ) -> Any: ...
    def GetEffectiveAccess(
        self, request: Any, *, metadata: list[tuple[str, str]] | None = None
    ) -> Any: ...
    def ExplainEffectiveAccess(
        self, request: Any, *, metadata: list[tuple[str, str]] | None = None
    ) -> Any: ...
    def CheckPermission(
        self, request: Any, *, metadata: list[tuple[str, str]] | None = None
    ) -> Any: ...
    def BatchCheckPermissions(
        self, request: Any, *, metadata: list[tuple[str, str]] | None = None
    ) -> Any: ...


class AuditServiceStub(Protocol):
    def ListAuditLogs(
        self, request: Any, *, metadata: list[tuple[str, str]] | None = None
    ) -> Any: ...


class MachineCredentialServiceStub(Protocol):
    def CreateMachineCredential(
        self, request: Any, *, metadata: list[tuple[str, str]] | None = None
    ) -> Any: ...
    def GetMachineCredential(
        self, request: Any, *, metadata: list[tuple[str, str]] | None = None
    ) -> Any: ...
    def ListMachineCredentials(
        self, request: Any, *, metadata: list[tuple[str, str]] | None = None
    ) -> Any: ...
    def RotateMachineCredential(
        self, request: Any, *, metadata: list[tuple[str, str]] | None = None
    ) -> Any: ...
    def RevokeMachineCredential(
        self, request: Any, *, metadata: list[tuple[str, str]] | None = None
    ) -> Any: ...
    def GetMachineCredentialUsage(
        self, request: Any, *, metadata: list[tuple[str, str]] | None = None
    ) -> Any: ...


class AdminClient:
    """Admin client for RBAC, audit, and machine credentials."""

    def __init__(self, cli_ctx: CLIContext):
        self.cli_ctx = cli_ctx
        self._grpc_channel: grpc.Channel | None = None
        self._rbac_stub: RbacServiceStub | None = None
        self._audit_stub: AuditServiceStub | None = None
        self._machine_stub: MachineCredentialServiceStub | None = None

    def _use_grpc(self) -> bool:
        return self.cli_ctx.transport == TransportFormat.GRPC

    def _rest_request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json_data: dict[str, Any] | None = None,
    ) -> Any:
        url = f"{self.cli_ctx.get_rest_url().rstrip('/')}/api/v1{path}"
        headers: dict[str, str] = {}
        token = self.cli_ctx.get_auth_token()
        if token:
            headers["Authorization"] = f"Bearer {token}"

        with httpx.Client(
            verify=self.cli_ctx.verify_ssl,
            timeout=httpx.Timeout(self.cli_ctx.timeout, connect=5.0),
        ) as client:
            response = client.request(method, url, params=params, json=json_data, headers=headers)

        if response.status_code >= 400:
            raise AdminClientError(
                code=1,
                status_code=response.status_code,
                response_text=response.text,
            )
        if not response.text.strip():
            return {}
        return response.json()

    def _get_channel(self) -> grpc.Channel:
        if self._grpc_channel is None:
            url = self.cli_ctx.base_url
            if url.startswith("http://"):
                self._grpc_channel = grpc.insecure_channel(url[7:])
            elif url.startswith("https://"):
                self._grpc_channel = grpc.secure_channel(url[8:], grpc.ssl_channel_credentials())
            else:
                self._grpc_channel = grpc.insecure_channel(url)
        return self._grpc_channel

    def _metadata(self) -> list[tuple[str, str]] | None:
        token = self.cli_ctx.get_auth_token()
        if not token:
            return None
        return [("authorization", f"Bearer {token}")]

    def _get_rbac_pb2(self) -> Any:
        global rbac_pb2
        if rbac_pb2 is None:
            from featureform._generated.proto.featureform.v2 import rbac_pb2 as _rbac_pb2

            rbac_pb2 = _rbac_pb2
        return rbac_pb2

    def _get_rbac_stub(self) -> RbacServiceStub:
        if self._rbac_stub is None:
            global rbac_pb2_grpc
            if rbac_pb2_grpc is None:
                from featureform._generated.proto.featureform.v2 import (
                    rbac_pb2_grpc as _rbac_pb2_grpc,
                )

                rbac_pb2_grpc = _rbac_pb2_grpc
            self._rbac_stub = cast(
                RbacServiceStub, rbac_pb2_grpc.RbacServiceStub(self._get_channel())
            )
        return self._rbac_stub

    def _get_audit_pb2(self) -> Any:
        global audit_pb2
        if audit_pb2 is None:
            from featureform._generated.proto.featureform.v2 import audit_pb2 as _audit_pb2

            audit_pb2 = _audit_pb2
        return audit_pb2

    def _get_audit_stub(self) -> AuditServiceStub:
        if self._audit_stub is None:
            global audit_pb2_grpc
            if audit_pb2_grpc is None:
                from featureform._generated.proto.featureform.v2 import (
                    audit_pb2_grpc as _audit_pb2_grpc,
                )

                audit_pb2_grpc = _audit_pb2_grpc
            self._audit_stub = cast(
                AuditServiceStub,
                audit_pb2_grpc.AuditServiceStub(self._get_channel()),
            )
        return self._audit_stub

    def _get_machine_stub(self) -> MachineCredentialServiceStub:
        if self._machine_stub is None:
            self._machine_stub = self._get_machine_stub_from_grpc()
        return self._machine_stub

    def _get_machine_stub_from_grpc(self) -> MachineCredentialServiceStub:
        global rbac_pb2_grpc
        if rbac_pb2_grpc is None:
            from featureform._generated.proto.featureform.v2 import rbac_pb2_grpc as _rbac_pb2_grpc

            rbac_pb2_grpc = _rbac_pb2_grpc
        return cast(
            MachineCredentialServiceStub,
            rbac_pb2_grpc.MachineCredentialServiceStub(self._get_channel()),
        )

    def _grpc_error(self, err: grpc.RpcError) -> AdminClientError:
        details = err.details() if hasattr(err, "details") else str(err)
        return AdminClientError(details or str(err))

    def _identity_to_dict(self, identity: Any) -> dict[str, Any]:
        result = {
            "principal_type": getattr(identity, "principal_type", ""),
            "principal_id": getattr(identity, "principal_id", ""),
        }
        for field in ("email", "name", "provider"):
            value = getattr(identity, field, "")
            if value:
                result[field] = value
        return result

    def _machine_context_to_dict(self, machine_context: Any) -> dict[str, Any]:
        result: dict[str, Any] = {
            "provider": getattr(machine_context, "provider", ""),
            "principal_id": getattr(machine_context, "principal_id", ""),
        }
        for field, key in (
            ("credential_id", "credential_id"),
            ("credential_name", "credential_name"),
            ("token_expires", "token_expires"),
        ):
            value = getattr(machine_context, field, "")
            if value:
                result[key] = value
        scopes = list(getattr(machine_context, "scopes", []))
        if scopes:
            result["scopes"] = scopes
        return result

    def _binding_to_dict(self, binding: Any) -> dict[str, Any]:
        result = {
            "scope": getattr(binding, "scope", ""),
            "principal_type": getattr(binding, "principal_type", ""),
            "principal_id": getattr(binding, "principal_id", ""),
            "role": getattr(binding, "role", ""),
        }
        binding_id = getattr(binding, "id", "")
        if binding_id:
            result["id"] = binding_id
        workspace_id = getattr(binding, "workspace_id", "")
        if workspace_id:
            result["workspace_id"] = workspace_id
        return result

    def _binding_subject_to_dict(self, subject: Any) -> dict[str, Any]:
        result = {
            "principal_type": getattr(subject, "principal_type", ""),
            "principal_id": getattr(subject, "principal_id", ""),
            "roles": list(getattr(subject, "roles", [])),
            "binding_ids": list(getattr(subject, "binding_ids", [])),
            "scopes": list(getattr(subject, "scopes", [])),
        }
        last_updated_at = getattr(subject, "last_updated_at", "")
        if last_updated_at:
            result["last_updated_at"] = last_updated_at
        return result

    def _role_definition_to_dict(self, definition: Any) -> dict[str, Any]:
        return {
            "id": getattr(definition, "id", ""),
            "label": getattr(definition, "label", ""),
            "description": getattr(definition, "description", ""),
            "scope": getattr(definition, "scope", ""),
            "permissions": list(getattr(definition, "permissions", [])),
            "managed_by": getattr(definition, "managed_by", ""),
        }

    def _permission_definition_to_dict(self, definition: Any) -> dict[str, Any]:
        return {
            "id": getattr(definition, "id", ""),
            "label": getattr(definition, "label", ""),
            "description": getattr(definition, "description", ""),
            "category": getattr(definition, "category", ""),
            "resource_scope": getattr(definition, "resource_scope", ""),
        }

    def _principal_search_result_to_dict(self, principal: Any) -> dict[str, Any]:
        result = {
            "principal_type": getattr(principal, "principal_type", ""),
            "principal_id": getattr(principal, "principal_id", ""),
            "source": getattr(principal, "source", ""),
        }
        for field in ("display_name", "email"):
            value = getattr(principal, field, "")
            if value:
                result[field] = value
        return result

    def _model_resource_to_dict(self, binding: Any) -> dict[str, Any]:
        result = {
            "workspace_id": getattr(binding, "workspace_id", ""),
            "principal_type": getattr(binding, "principal_type", ""),
            "principal_id": getattr(binding, "principal_id", ""),
            "resource_type": getattr(binding, "resource_type", ""),
            "resource_name": getattr(binding, "resource_name", ""),
        }
        binding_id = getattr(binding, "id", "")
        if binding_id:
            result["id"] = binding_id
        return result

    def _permission_source_to_dict(self, source: Any) -> dict[str, Any]:
        result = {"source_type": getattr(source, "source_type", "")}
        for field in ("role", "scope", "workspace_id", "principal_type", "principal_id"):
            value = getattr(source, field, "")
            if value:
                result[field] = value
        return result

    def _permission_explanation_to_dict(self, explanation: Any) -> dict[str, Any]:
        return {
            "permission": getattr(explanation, "permission", ""),
            "sources": [
                self._permission_source_to_dict(source)
                for source in getattr(explanation, "sources", [])
            ],
        }

    def _audit_event_to_dict(self, event: Any) -> dict[str, Any]:
        result = {
            "id": getattr(event, "id", ""),
            "scope": getattr(event, "scope", ""),
            "workspace_id": getattr(event, "workspace_id", ""),
            "actor_type": getattr(event, "actor_type", ""),
            "actor_id": getattr(event, "actor_id", ""),
            "event_type": getattr(event, "event_type", ""),
            "target_type": getattr(event, "target_type", ""),
            "target_id": getattr(event, "target_id", ""),
            "created_at": getattr(event, "created_at", ""),
        }
        metadata = dict(getattr(event, "metadata", {}))
        if metadata:
            result["metadata"] = metadata
        return result

    def _credential_to_dict(self, credential: Any) -> dict[str, Any]:
        result = {
            "id": getattr(credential, "id", ""),
            "workspace_id": getattr(credential, "workspace_id", ""),
            "name": getattr(credential, "name", ""),
            "principal_type": getattr(credential, "principal_type", ""),
            "principal_id": getattr(credential, "principal_id", ""),
            "public_key": getattr(credential, "public_key", ""),
            "algorithm": getattr(credential, "algorithm", ""),
            "status": getattr(credential, "status", ""),
        }
        for field in ("last_used_at", "rotated_at", "revoked_at", "created_at", "updated_at"):
            value = getattr(credential, field, "")
            if value:
                result[field] = value
        return result

    def whoami(self) -> dict[str, Any]:
        if not self._use_grpc():
            return cast(dict[str, Any], self._rest_request("GET", "/rbac/whoami"))
        try:
            pb = self._get_rbac_pb2()
            resp = self._get_rbac_stub().WhoAmI(pb.WhoAmIRequest(), metadata=self._metadata())
        except grpc.RpcError as err:
            raise self._grpc_error(err) from err
        result: dict[str, Any] = {"identity": self._identity_to_dict(resp.identity)}
        if list(resp.idp_roles):
            result["idp_roles"] = list(resp.idp_roles)
        if getattr(resp, "machine_context", None) and getattr(
            resp.machine_context, "principal_id", ""
        ):
            result["machine_context"] = self._machine_context_to_dict(resp.machine_context)
        return result

    def list_roles(self) -> dict[str, Any]:
        if not self._use_grpc():
            return cast(dict[str, Any], self._rest_request("GET", "/rbac/roles"))
        try:
            pb = self._get_rbac_pb2()
            resp = self._get_rbac_stub().ListRoleDefinitions(
                pb.ListRoleDefinitionsRequest(), metadata=self._metadata()
            )
        except grpc.RpcError as err:
            raise self._grpc_error(err) from err
        return {"roles": [self._role_definition_to_dict(role) for role in resp.roles]}

    def list_permissions(self) -> dict[str, Any]:
        if not self._use_grpc():
            return cast(dict[str, Any], self._rest_request("GET", "/rbac/permissions"))
        try:
            pb = self._get_rbac_pb2()
            resp = self._get_rbac_stub().ListPermissionDefinitions(
                pb.ListPermissionDefinitionsRequest(), metadata=self._metadata()
            )
        except grpc.RpcError as err:
            raise self._grpc_error(err) from err
        return {
            "permissions": [
                self._permission_definition_to_dict(permission) for permission in resp.permissions
            ]
        }

    def search_principals(self, **filters: Any) -> dict[str, Any]:
        if not self._use_grpc():
            params = dict(filters)
            query = params.pop("query", None)
            if query is not None:
                params["q"] = query
            return cast(
                dict[str, Any],
                self._rest_request("GET", "/rbac/principals/search", params=params),
            )
        try:
            pb = self._get_rbac_pb2()
            request_filters = dict(filters)
            resp = self._get_rbac_stub().SearchPrincipals(
                pb.SearchPrincipalsRequest(**request_filters), metadata=self._metadata()
            )
        except grpc.RpcError as err:
            raise self._grpc_error(err) from err
        return {
            "principals": [
                self._principal_search_result_to_dict(principal) for principal in resp.principals
            ]
        }

    def grant_role(
        self,
        *,
        role: str,
        workspace: str | None,
        scope: str,
        principal_type: str,
        principal_id: str,
    ) -> dict[str, Any]:
        if not self._use_grpc():
            payload = {
                "role": role,
                "scope": scope,
                "principal_type": principal_type,
                "principal_id": principal_id,
            }
            if workspace:
                payload["workspace_id"] = workspace
            return cast(
                dict[str, Any],
                self._rest_request("POST", "/rbac/bindings", json_data=payload),
            )
        try:
            pb = self._get_rbac_pb2()
            binding = pb.RoleBinding(
                scope=scope,
                workspace_id=workspace or "",
                principal_type=principal_type,
                principal_id=principal_id,
                role=role,
            )
            resp = self._get_rbac_stub().GrantRoleBinding(
                pb.GrantRoleBindingRequest(binding=binding), metadata=self._metadata()
            )
        except grpc.RpcError as err:
            raise self._grpc_error(err) from err
        return {"binding": self._binding_to_dict(resp.binding)}

    def revoke_role(
        self,
        *,
        role: str,
        workspace: str | None,
        scope: str,
        principal_type: str,
        principal_id: str,
    ) -> dict[str, Any]:
        if not self._use_grpc():
            payload = {
                "role": role,
                "scope": scope,
                "principal_type": principal_type,
                "principal_id": principal_id,
            }
            if workspace:
                payload["workspace_id"] = workspace
            return cast(
                dict[str, Any],
                self._rest_request("DELETE", "/rbac/bindings", json_data=payload),
            )
        try:
            pb = self._get_rbac_pb2()
            binding = pb.RoleBinding(
                scope=scope,
                workspace_id=workspace or "",
                principal_type=principal_type,
                principal_id=principal_id,
                role=role,
            )
            self._get_rbac_stub().RevokeRoleBinding(
                pb.RevokeRoleBindingRequest(binding=binding), metadata=self._metadata()
            )
        except grpc.RpcError as err:
            raise self._grpc_error(err) from err
        return {}

    def list_bindings(self, **filters: Any) -> dict[str, Any]:
        if not self._use_grpc():
            return cast(dict[str, Any], self._rest_request("GET", "/rbac/bindings", params=filters))
        try:
            pb = self._get_rbac_pb2()
            request_filters = dict(filters)
            request_filters.pop("scope", None)
            resp = self._get_rbac_stub().ListRoleBindings(
                pb.ListRoleBindingsRequest(**request_filters),
                metadata=self._metadata(),
            )
        except grpc.RpcError as err:
            raise self._grpc_error(err) from err
        return {"bindings": [self._binding_to_dict(binding) for binding in resp.bindings]}

    def list_binding_subjects(self, **filters: Any) -> dict[str, Any]:
        if not self._use_grpc():
            path = "/rbac/bindings/subjects"
            workspace_id = filters.get("workspace_id")
            scope = filters.pop("scope", None)
            if workspace_id:
                path = f"/rbac/workspaces/{workspace_id}/bindings/subjects"
                filters = {key: value for key, value in filters.items() if key != "workspace_id"}
            elif scope == "global":
                path = "/rbac/global-bindings/subjects"
            return cast(dict[str, Any], self._rest_request("GET", path, params=filters))
        try:
            pb = self._get_rbac_pb2()
            request_filters = dict(filters)
            request_filters.pop("scope", None)
            resp = self._get_rbac_stub().ListRoleBindingSubjects(
                pb.ListRoleBindingSubjectsRequest(**request_filters),
                metadata=self._metadata(),
            )
        except grpc.RpcError as err:
            raise self._grpc_error(err) from err
        return {"subjects": [self._binding_subject_to_dict(subject) for subject in resp.subjects]}

    def effective_access(self, **filters: Any) -> dict[str, Any]:
        if not self._use_grpc():
            return cast(
                dict[str, Any],
                self._rest_request("GET", "/rbac/effective-access", params=filters),
            )
        try:
            pb = self._get_rbac_pb2()
            resp = self._get_rbac_stub().GetEffectiveAccess(
                pb.GetEffectiveAccessRequest(**filters), metadata=self._metadata()
            )
        except grpc.RpcError as err:
            raise self._grpc_error(err) from err
        result: dict[str, Any] = {
            "identity": self._identity_to_dict(resp.identity),
            "permissions": list(resp.permissions),
            "featureform_bindings": [
                self._binding_to_dict(binding) for binding in resp.featureform_bindings
            ],
            "model_resources": [
                self._model_resource_to_dict(binding) for binding in resp.model_resources
            ],
        }
        if list(resp.idp_roles):
            result["idp_roles"] = list(resp.idp_roles)
        if getattr(resp, "machine_context", None) and getattr(
            resp.machine_context, "principal_id", ""
        ):
            result["machine_context"] = self._machine_context_to_dict(resp.machine_context)
        return result

    def explain_effective_access(self, **filters: Any) -> dict[str, Any]:
        if not self._use_grpc():
            return cast(
                dict[str, Any],
                self._rest_request("GET", "/rbac/effective-access/explain", params=filters),
            )
        try:
            pb = self._get_rbac_pb2()
            resp = self._get_rbac_stub().ExplainEffectiveAccess(
                pb.ExplainEffectiveAccessRequest(**filters), metadata=self._metadata()
            )
        except grpc.RpcError as err:
            raise self._grpc_error(err) from err
        result: dict[str, Any] = {
            "identity": self._identity_to_dict(resp.identity),
            "featureform_bindings": [
                self._binding_to_dict(binding) for binding in resp.featureform_bindings
            ],
            "permissions": [
                self._permission_explanation_to_dict(permission) for permission in resp.permissions
            ],
            "model_resources": [
                self._model_resource_to_dict(binding) for binding in resp.model_resources
            ],
        }
        if list(resp.idp_roles):
            result["idp_roles"] = list(resp.idp_roles)
        if getattr(resp, "machine_context", None) and getattr(
            resp.machine_context, "principal_id", ""
        ):
            result["machine_context"] = self._machine_context_to_dict(resp.machine_context)
        return result

    def check_permission(self, **filters: Any) -> dict[str, Any]:
        if not self._use_grpc():
            return cast(dict[str, Any], self._rest_request("GET", "/rbac/check", params=filters))
        try:
            pb = self._get_rbac_pb2()
            resp = self._get_rbac_stub().CheckPermission(
                pb.CheckPermissionRequest(**filters), metadata=self._metadata()
            )
        except grpc.RpcError as err:
            raise self._grpc_error(err) from err
        return {"allowed": resp.allowed}

    def batch_check_permissions(self, checks: list[dict[str, Any]]) -> dict[str, Any]:
        if not self._use_grpc():
            return cast(
                dict[str, Any],
                self._rest_request("POST", "/rbac/check/batch", json_data={"checks": checks}),
            )
        try:
            pb = self._get_rbac_pb2()
            entries = [pb.BatchCheckPermissionEntry(**check) for check in checks]
            resp = self._get_rbac_stub().BatchCheckPermissions(
                pb.BatchCheckPermissionsRequest(checks=entries), metadata=self._metadata()
            )
        except grpc.RpcError as err:
            raise self._grpc_error(err) from err
        return {
            "checks": [
                {
                    "workspace_id": getattr(check, "workspace_id", ""),
                    "permission": getattr(check, "permission", ""),
                    "resource_type": getattr(check, "resource_type", ""),
                    "resource_name": getattr(check, "resource_name", ""),
                    "allowed": getattr(check, "allowed", False),
                }
                for check in resp.checks
            ]
        }

    def list_model_resources(self, **filters: Any) -> dict[str, Any]:
        if not self._use_grpc():
            return cast(
                dict[str, Any],
                self._rest_request("GET", "/rbac/model-resources", params=filters),
            )
        try:
            pb = self._get_rbac_pb2()
            resp = self._get_rbac_stub().ListModelResourceBindings(
                pb.ListModelResourceBindingsRequest(**filters), metadata=self._metadata()
            )
        except grpc.RpcError as err:
            raise self._grpc_error(err) from err
        return {"resources": [self._model_resource_to_dict(binding) for binding in resp.bindings]}

    def allow_model_resource(self, **payload: Any) -> dict[str, Any]:
        if not self._use_grpc():
            return cast(
                dict[str, Any],
                self._rest_request("POST", "/rbac/model-resources", json_data=payload),
            )
        try:
            pb = self._get_rbac_pb2()
            binding = pb.ModelResourceBinding(**payload)
            resp = self._get_rbac_stub().GrantModelResourceBinding(
                pb.GrantModelResourceBindingRequest(binding=binding), metadata=self._metadata()
            )
        except grpc.RpcError as err:
            raise self._grpc_error(err) from err
        return {"resource": self._model_resource_to_dict(resp.binding)}

    def revoke_model_resource(self, **payload: Any) -> dict[str, Any]:
        if not self._use_grpc():
            return cast(
                dict[str, Any],
                self._rest_request("DELETE", "/rbac/model-resources", json_data=payload),
            )
        try:
            pb = self._get_rbac_pb2()
            binding = pb.ModelResourceBinding(**payload)
            self._get_rbac_stub().RevokeModelResourceBinding(
                pb.RevokeModelResourceBindingRequest(binding=binding), metadata=self._metadata()
            )
        except grpc.RpcError as err:
            raise self._grpc_error(err) from err
        return {}

    def revoke_role_by_id(self, binding_id: str) -> dict[str, Any]:
        if not self._use_grpc():
            return cast(
                dict[str, Any],
                self._rest_request("DELETE", f"/rbac/bindings/{binding_id}"),
            )
        try:
            pb = self._get_rbac_pb2()
            self._get_rbac_stub().RevokeRoleBindingByID(
                pb.RevokeRoleBindingByIDRequest(id=binding_id), metadata=self._metadata()
            )
        except grpc.RpcError as err:
            raise self._grpc_error(err) from err
        return {}

    def revoke_model_resource_by_id(self, binding_id: str) -> dict[str, Any]:
        if not self._use_grpc():
            return cast(
                dict[str, Any],
                self._rest_request("DELETE", f"/rbac/model-resources/{binding_id}"),
            )
        try:
            pb = self._get_rbac_pb2()
            self._get_rbac_stub().RevokeModelResourceBindingByID(
                pb.RevokeModelResourceBindingByIDRequest(id=binding_id),
                metadata=self._metadata(),
            )
        except grpc.RpcError as err:
            raise self._grpc_error(err) from err
        return {}

    def list_audit_logs(self, **filters: Any) -> dict[str, Any]:
        if not self._use_grpc():
            workspace_id = filters.pop("workspace_id", None)
            path = f"/workspaces/{workspace_id}/audit-logs" if workspace_id else "/audit-logs"
            return cast(dict[str, Any], self._rest_request("GET", path, params=filters))
        try:
            pb = self._get_audit_pb2()
            request_filters = dict(filters)
            if not request_filters.get("workspace_id") and not request_filters.get("scope"):
                request_filters["scope"] = "global"
            resp = self._get_audit_stub().ListAuditLogs(
                pb.ListAuditLogsRequest(**request_filters),
                metadata=self._metadata(),
            )
        except grpc.RpcError as err:
            raise self._grpc_error(err) from err
        return {"events": [self._audit_event_to_dict(event) for event in resp.events]}

    def create_machine_credential(self, **payload: Any) -> dict[str, Any]:
        if not self._use_grpc():
            return cast(
                dict[str, Any],
                self._rest_request("POST", "/machine-credentials", json_data=payload),
            )
        try:
            pb = self._get_rbac_pb2()
            credential = pb.MachineCredential(**payload)
            resp = self._get_machine_stub().CreateMachineCredential(
                pb.CreateMachineCredentialRequest(credential=credential), metadata=self._metadata()
            )
        except grpc.RpcError as err:
            raise self._grpc_error(err) from err
        return {"credential": self._credential_to_dict(resp.credential)}

    def get_machine_credential(self, credential_id: str) -> dict[str, Any]:
        if not self._use_grpc():
            return cast(
                dict[str, Any],
                self._rest_request("GET", f"/machine-credentials/{credential_id}"),
            )
        try:
            pb = self._get_rbac_pb2()
            resp = self._get_machine_stub().GetMachineCredential(
                pb.GetMachineCredentialRequest(id=credential_id), metadata=self._metadata()
            )
        except grpc.RpcError as err:
            raise self._grpc_error(err) from err
        return {"credential": self._credential_to_dict(resp.credential)}

    def list_machine_credentials(self, **filters: Any) -> dict[str, Any]:
        if not self._use_grpc():
            return cast(
                dict[str, Any],
                self._rest_request("GET", "/machine-credentials", params=filters),
            )
        try:
            pb = self._get_rbac_pb2()
            resp = self._get_machine_stub().ListMachineCredentials(
                pb.ListMachineCredentialsRequest(**filters), metadata=self._metadata()
            )
        except grpc.RpcError as err:
            raise self._grpc_error(err) from err
        return {
            "credentials": [self._credential_to_dict(credential) for credential in resp.credentials]
        }

    def rotate_machine_credential(self, credential_id: str, **payload: Any) -> dict[str, Any]:
        if not self._use_grpc():
            return cast(
                dict[str, Any],
                self._rest_request(
                    "POST", f"/machine-credentials/{credential_id}/rotate", json_data=payload
                ),
            )
        try:
            pb = self._get_rbac_pb2()
            resp = self._get_machine_stub().RotateMachineCredential(
                pb.RotateMachineCredentialRequest(
                    id=credential_id, public_key=payload.get("public_key", "")
                ),
                metadata=self._metadata(),
            )
        except grpc.RpcError as err:
            raise self._grpc_error(err) from err
        return {"credential": self._credential_to_dict(resp.credential)}

    def revoke_machine_credential(self, credential_id: str) -> dict[str, Any]:
        if not self._use_grpc():
            return cast(
                dict[str, Any],
                self._rest_request("POST", f"/machine-credentials/{credential_id}/revoke"),
            )
        try:
            pb = self._get_rbac_pb2()
            self._get_machine_stub().RevokeMachineCredential(
                pb.RevokeMachineCredentialRequest(id=credential_id), metadata=self._metadata()
            )
        except grpc.RpcError as err:
            raise self._grpc_error(err) from err
        return {}

    def machine_credential_usage(self, credential_id: str) -> dict[str, Any]:
        if not self._use_grpc():
            return cast(
                dict[str, Any],
                self._rest_request("GET", f"/machine-credentials/{credential_id}/usage"),
            )
        try:
            pb = self._get_rbac_pb2()
            resp = self._get_machine_stub().GetMachineCredentialUsage(
                pb.GetMachineCredentialUsageRequest(id=credential_id), metadata=self._metadata()
            )
        except grpc.RpcError as err:
            raise self._grpc_error(err) from err
        return self._credential_to_dict(resp.credential)
