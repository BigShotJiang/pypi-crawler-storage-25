"""Profile repository interface for CLI auth state."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Protocol, cast

import yaml

from featureform.cli import env
from featureform.cli.auth.fs import ensure_private_parent_dir
from featureform.cli.auth.types import ProfileConfig


class ProfileRepository(Protocol):
    """Read and mutate named CLI profiles."""

    def get_active_profile(self) -> ProfileConfig | None:
        """Return the active profile, if one exists."""
        ...

    def get_profile(self, name: str) -> ProfileConfig | None:
        """Return a named profile, if one exists."""
        ...

    def save_profile(self, profile: ProfileConfig) -> None:
        """Persist a profile definition."""
        ...

    def set_active_profile(self, name: str) -> None:
        """Set the active profile by name."""
        ...


def default_config_dir() -> Path:
    """Return the default CLI config directory."""
    return env.default_config_dir()


def default_config_path() -> Path:
    """Return the default CLI config file path."""
    override = env.config_override()
    if override:
        return Path(override).expanduser().resolve()
    return default_config_dir() / "config.yaml"


class YAMLProfileRepository:
    """Persist CLI profile state in the standard YAML config file."""

    def __init__(self, config_path: Path | None = None) -> None:
        self.config_path = config_path or default_config_path()

    def get_active_profile(self) -> ProfileConfig | None:
        data = self._load()
        data_map = cast(dict[str, Any], data)
        active_name = data_map.get("auth_profile")
        profiles_obj = data_map.get("profiles", {})
        if isinstance(active_name, str) and isinstance(profiles_obj, dict):
            profiles = cast(dict[str, Any], profiles_obj)
            profile = profiles.get(active_name)
            if isinstance(profile, dict):
                return self._profile_from_dict(active_name, profile)

        legacy_server = data_map.get("server")
        if isinstance(legacy_server, str) and legacy_server:
            transport = data_map.get("transport")
            legacy_no_tls = data_map.get("no_tls")
            return ProfileConfig(
                name="default",
                server=legacy_server,
                transport=transport if isinstance(transport, str) and transport else "grpc",
                no_tls=bool(legacy_no_tls),
            )
        return None

    def get_profile(self, name: str) -> ProfileConfig | None:
        data = self._load()
        data_map = cast(dict[str, Any], data)
        profiles_obj = data_map.get("profiles", {})
        if not isinstance(profiles_obj, dict):
            return None
        profiles = cast(dict[str, Any], profiles_obj)
        profile = profiles.get(name)
        if not isinstance(profile, dict):
            return None
        return self._profile_from_dict(name, profile)

    def save_profile(self, profile: ProfileConfig) -> None:
        data = self._load()
        profiles = data.setdefault("profiles", {})
        if not isinstance(profiles, dict):
            profiles = {}
            data["profiles"] = profiles

        profiles[profile.name] = {
            "server": profile.server,
            "transport": profile.transport,
            "no_tls": profile.no_tls,
            "issuer_url": profile.issuer_url,
            "cli_client_id": profile.cli_client_id,
            "version": profile.version,
        }

        if data.get("auth_profile") == profile.name or data.get("auth_profile") is None:
            data["server"] = profile.server
            data["transport"] = profile.transport
            data["no_tls"] = profile.no_tls
        self._save(data)

    def set_active_profile(self, name: str) -> None:
        data = self._load()
        data["auth_profile"] = name
        profile = self.get_profile(name)
        if profile is not None:
            data["server"] = profile.server
            data["transport"] = profile.transport
            data["no_tls"] = profile.no_tls
        self._save(data)

    def _profile_from_dict(self, name: str, data: dict[object, object]) -> ProfileConfig:
        data_map = cast(dict[str, Any], data)
        transport = data_map.get("transport")
        no_tls = data_map.get("no_tls")
        issuer_url = data_map.get("issuer_url")
        cli_client_id = data_map.get("cli_client_id")
        version = data_map.get("version", 1)
        return ProfileConfig(
            name=name,
            server=str(data_map["server"]),
            transport=transport if isinstance(transport, str) and transport else "grpc",
            no_tls=bool(no_tls),
            issuer_url=issuer_url if isinstance(issuer_url, str) else None,
            cli_client_id=cli_client_id if isinstance(cli_client_id, str) else None,
            version=version if isinstance(version, int) else 1,
        )

    def _load(self) -> dict[str, object]:
        if not self.config_path.exists():
            return {"version": 1}
        with self.config_path.open(encoding="utf-8") as handle:
            data = yaml.safe_load(handle) or {}
        if not isinstance(data, dict):
            raise ValueError(f"Invalid config shape in {self.config_path}")
        if "version" not in data:
            data["version"] = 1
        return data

    def _save(self, data: dict[str, object]) -> None:
        ensure_private_parent_dir(self.config_path)
        with self.config_path.open("w", encoding="utf-8") as handle:
            yaml.safe_dump(data, handle, sort_keys=False)
        self.config_path.chmod(0o600)
