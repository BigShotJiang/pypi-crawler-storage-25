"""Session storage interfaces and implementations for CLI auth."""

from __future__ import annotations

import json
import os
from collections.abc import Iterator
from contextlib import contextmanager
from datetime import datetime
from importlib import import_module
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import Any, Protocol, cast

import yaml

from featureform.cli import env
from featureform.cli.auth.fs import ensure_private_parent_dir
from featureform.cli.auth.profiles import default_config_path
from featureform.cli.auth.types import StoredSession


class StorageUnavailableError(RuntimeError):
    """Raised when secure session storage is unavailable."""


class SessionStore(Protocol):
    """Persist and retrieve interactive sessions by profile."""

    def load(self, profile: str) -> StoredSession | None:
        """Load the stored session for a profile, if any."""
        ...

    def save(self, profile: str, session: StoredSession) -> None:
        """Persist the session for a profile."""
        ...

    def delete(self, profile: str) -> None:
        """Delete the session for a profile."""
        ...

    def compare_and_swap(
        self, profile: str, expected: StoredSession, updated: StoredSession
    ) -> bool:
        """Persist ``updated`` only if the current session still matches ``expected``."""
        ...


def default_session_path() -> Path:
    """Return the default persisted session file path."""
    return default_config_path().parent / "sessions.yaml"


def build_session_store(
    session_path: Path | None = None, *, storage_mode: str | None = None
) -> SessionStore:
    """Build the configured session store.

    The default enterprise policy is secure storage via keyring. File-backed
    persistence remains available only as an explicit fallback.
    """
    resolved_storage_mode = (storage_mode or env.auth_storage_mode()).strip().lower()
    if resolved_storage_mode in {"", "keyring"}:
        try:
            return KeyringSessionStore()
        except StorageUnavailableError as exc:
            return UnavailableSessionStore(str(exc))
    if resolved_storage_mode == "file":
        return FileSessionStore(session_path)
    raise StorageUnavailableError(
        "Unsupported auth storage mode. Set FEATUREFORM_AUTH_STORAGE=keyring or FEATUREFORM_AUTH_STORAGE=file."
    )


class KeyringSessionStore:
    """Store interactive sessions in the OS-backed keyring when available."""

    service_name = "featureform-cli"
    username_prefix = "session:"

    def __init__(self) -> None:
        try:
            self._keyring = import_module("keyring")
        except ModuleNotFoundError as exc:
            raise StorageUnavailableError(
                "Secure credential storage is unavailable because the 'keyring' package is not installed. "
                "Install keyring or explicitly opt into file-backed storage with FEATUREFORM_AUTH_STORAGE=file."
            ) from exc
        self._backend = self._keyring.get_keyring()
        backend_priority = getattr(self._backend, "priority", None)
        if isinstance(backend_priority, (int, float)) and backend_priority <= 0:
            raise StorageUnavailableError(
                "Secure credential storage is unavailable because no usable keyring backend is configured. "
                "Configure a system keyring or explicitly opt into file-backed storage with FEATUREFORM_AUTH_STORAGE=file."
            )

    def load(self, profile: str) -> StoredSession | None:
        raw = self._call_keyring("get_password", self.service_name, self._username(profile))
        if raw is None:
            return None
        try:
            payload = json.loads(cast(str, raw))
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid keyring session payload for profile {profile}") from exc
        return _session_from_mapping(profile, payload)

    def save(self, profile: str, session: StoredSession) -> None:
        self._call_keyring(
            "set_password",
            self.service_name,
            self._username(profile),
            json.dumps(_session_to_mapping(session)),
        )

    def delete(self, profile: str) -> None:
        try:
            self._call_keyring("delete_password", self.service_name, self._username(profile))
        except StorageUnavailableError:
            raise
        except Exception:
            return

    def compare_and_swap(
        self, profile: str, expected: StoredSession, updated: StoredSession
    ) -> bool:
        current = self.load(profile)
        if current != expected:
            return False
        self.save(profile, updated)
        return True

    def _username(self, profile: str) -> str:
        return f"{self.username_prefix}{profile}"

    def _call_keyring(self, method_name: str, *args: object) -> object:
        try:
            return getattr(self._keyring, method_name)(*args)
        except Exception as exc:
            if method_name == "delete_password" and exc.__class__.__name__ == "PasswordDeleteError":
                return None
            raise StorageUnavailableError(
                "Secure credential storage is unavailable because the configured keyring backend could not be used. "
                "Configure a working system keyring or explicitly opt into file-backed storage with FEATUREFORM_AUTH_STORAGE=file."
            ) from exc


class UnavailableSessionStore:
    """Session store placeholder used when secure storage is unavailable."""

    def __init__(self, message: str) -> None:
        self.message = message

    def load(self, profile: str) -> StoredSession | None:
        del profile
        raise StorageUnavailableError(self.message)

    def save(self, profile: str, session: StoredSession) -> None:
        del profile, session
        raise StorageUnavailableError(self.message)

    def delete(self, profile: str) -> None:
        del profile
        raise StorageUnavailableError(self.message)

    def compare_and_swap(
        self, profile: str, expected: StoredSession, updated: StoredSession
    ) -> bool:
        del profile, expected, updated
        raise StorageUnavailableError(self.message)


class FileSessionStore:
    """Store interactive CLI sessions in a restricted local YAML file."""

    def __init__(self, session_path: Path | None = None) -> None:
        self.session_path = session_path or default_session_path()

    def load(self, profile: str) -> StoredSession | None:
        with self._locked():
            data = self._load_all()
            raw = data.get(profile)
            if not isinstance(raw, dict):
                return None
            return _session_from_mapping(profile, raw)

    def save(self, profile: str, session: StoredSession) -> None:
        with self._locked():
            data = self._load_all()
            data[profile] = _session_to_mapping(session)
            self._save_all(data)

    def delete(self, profile: str) -> None:
        with self._locked():
            data = self._load_all()
            data.pop(profile, None)
            self._save_all(data)

    def compare_and_swap(
        self, profile: str, expected: StoredSession, updated: StoredSession
    ) -> bool:
        with self._locked():
            data = self._load_all()
            raw = data.get(profile)
            if not isinstance(raw, dict):
                return False
            current = _session_from_mapping(profile, raw)
            if current != expected:
                return False
            data[profile] = _session_to_mapping(updated)
            self._save_all(data)
            return True

    def _load_all(self) -> dict[str, object]:
        if not self.session_path.exists():
            return {}
        with self.session_path.open(encoding="utf-8") as handle:
            data = yaml.safe_load(handle) or {}
        if not isinstance(data, dict):
            raise ValueError(f"Invalid session store shape in {self.session_path}")
        return data

    def _save_all(self, data: dict[str, object]) -> None:
        ensure_private_parent_dir(self.session_path)
        with NamedTemporaryFile(
            "w",
            encoding="utf-8",
            dir=self.session_path.parent,
            prefix=f"{self.session_path.name}.",
            suffix=".tmp",
            delete=False,
        ) as handle:
            yaml.safe_dump(data, handle, sort_keys=True)
            temp_path = Path(handle.name)
        os.chmod(temp_path, 0o600)
        os.replace(temp_path, self.session_path)
        self.session_path.chmod(0o600)

    @contextmanager
    def _locked(self) -> Iterator[None]:
        ensure_private_parent_dir(self.session_path)
        lock_path = self.session_path.with_suffix(f"{self.session_path.suffix}.lock")
        lock_handle = lock_path.open("a+", encoding="utf-8")
        try:
            _lock_file(lock_handle)
            yield
        finally:
            _unlock_file(lock_handle)
            lock_handle.close()


def _lock_file(handle: Any) -> None:
    if os.name == "nt":
        msvcrt = import_module("msvcrt")
        handle.seek(0)
        locking = cast(Any, msvcrt.locking)
        lock_mode = cast(Any, msvcrt.LK_LOCK)
        locking(handle.fileno(), lock_mode, 1)
        return

    import fcntl

    fcntl.flock(handle.fileno(), fcntl.LOCK_EX)


def _unlock_file(handle: Any) -> None:
    if os.name == "nt":
        msvcrt = import_module("msvcrt")
        handle.seek(0)
        locking = cast(Any, msvcrt.locking)
        unlock_mode = cast(Any, msvcrt.LK_UNLCK)
        locking(handle.fileno(), unlock_mode, 1)
        return

    import fcntl

    fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def _session_to_mapping(session: StoredSession) -> dict[str, object]:
    return {
        "access_token": session.access_token,
        "refresh_token": session.refresh_token,
        "issuer_url": session.issuer_url,
        "client_id": session.client_id,
        "login_method": session.login_method,
        "subject": session.subject,
        "expires_at": session.expires_at.isoformat(),
    }


def _session_from_mapping(profile: str, raw: object) -> StoredSession:
    if not isinstance(raw, dict):
        raise ValueError(f"Corrupt session state for profile {profile}")
    raw_map = cast(dict[str, Any], raw)
    expires_at = raw_map.get("expires_at")
    if not isinstance(expires_at, str):
        raise ValueError(f"Corrupt session state for profile {profile}")
    login_method = raw_map.get("login_method")
    login_method_str = login_method if isinstance(login_method, str) else "device_code"
    return StoredSession(
        profile_name=profile,
        access_token=str(raw_map["access_token"]),
        refresh_token=raw_map.get("refresh_token")
        if isinstance(raw_map.get("refresh_token"), str)
        else None,
        issuer_url=str(raw_map["issuer_url"]),
        client_id=str(raw_map["client_id"]),
        login_method=login_method_str,
        subject=raw_map.get("subject") if isinstance(raw_map.get("subject"), str) else None,
        expires_at=datetime.fromisoformat(expires_at),
    )
