"""Clock abstractions for deterministic auth/session logic."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Protocol


class Clock(Protocol):
    """Provide the current time for auth/session logic."""

    def now(self) -> datetime:
        """Return the current time."""
        ...


class SystemClock:
    """Default wall-clock implementation."""

    def now(self) -> datetime:
        """Return the current UTC time."""
        return datetime.now(timezone.utc)
