"""Filesystem helpers for CLI auth state."""

from __future__ import annotations

from contextlib import suppress
from pathlib import Path


def ensure_private_parent_dir(path: Path) -> None:
    """Create the parent directory and tighten permissions when allowed."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with suppress(PermissionError):
        # Shared system directories like /tmp are writable but not ours to chmod.
        path.parent.chmod(0o700)
