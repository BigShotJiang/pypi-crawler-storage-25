"""Core auth/session data types for CLI orchestration."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime


@dataclass(slots=True)
class AuthMetadata:
    """Server-advertised auth configuration for CLI login."""

    auth_enabled: bool
    issuer_url: str | None = None
    oidc_discovery_url: str | None = None
    cli_client_id: str | None = None
    audience: str | None = None
    supported_login_methods: list[str] = field(default_factory=list)
    token_refresh_supported: bool = False
    scopes: list[str] = field(default_factory=list)


@dataclass(slots=True)
class StoredSession:
    """Persisted interactive auth session for a CLI profile."""

    profile_name: str
    access_token: str
    refresh_token: str | None
    issuer_url: str
    client_id: str
    subject: str | None
    expires_at: datetime
    login_method: str = "device_code"


@dataclass(slots=True)
class ProfileConfig:
    """Resolved CLI profile configuration."""

    name: str
    server: str
    transport: str = "grpc"
    no_tls: bool = False
    issuer_url: str | None = None
    cli_client_id: str | None = None
    last_discovery_at: datetime | None = None
    version: int = 1


@dataclass(slots=True)
class LoginState:
    """Result of a profile-aware interactive login."""

    profile_name: str
    server: str
    issuer_url: str
    client_id: str
    replaced_existing_session: bool = False


@dataclass(slots=True)
class AuthStatus:
    """Current CLI auth/profile state."""

    profile_name: str | None
    server: str | None
    session_state: str
    discovery_state: str
    auth_source: str | None = None
    issuer_url: str | None = None
    message: str | None = None


@dataclass(slots=True)
class LogoutResult:
    """Result of clearing persisted auth state for a profile."""

    profile_name: str | None
    removed_session: bool
