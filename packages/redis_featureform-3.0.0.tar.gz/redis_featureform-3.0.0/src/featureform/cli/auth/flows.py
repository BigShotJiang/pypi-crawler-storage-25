"""Auth flow execution interfaces for CLI login and refresh."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Protocol

from featureform.auth import (
    get_device_authorization,
    get_password_token,
    poll_for_token,
    refresh_access_token,
)
from featureform.cli.auth.types import AuthMetadata, StoredSession


@dataclass(slots=True)
class LoginResult:
    """Result of a successful login or refresh operation."""

    access_token: str
    refresh_token: str | None
    expires_at: datetime
    subject: str | None = None


class AuthFlowExecutor(Protocol):
    """Execute auth flows against the configured OIDC provider."""

    def login_device(self, metadata: AuthMetadata) -> LoginResult:
        """Perform device-flow login using discovered metadata."""
        ...

    def login_password(
        self,
        metadata: AuthMetadata,
        *,
        username: str,
        password: str,
        client_id: str | None = None,
        scope: str | None = None,
    ) -> LoginResult:
        """Perform password-grant login using discovered metadata."""
        ...

    def refresh(self, session: StoredSession, metadata: AuthMetadata) -> LoginResult:
        """Refresh an existing stored session."""
        ...


class OIDCFlowExecutor:
    """OIDC-backed device login and refresh flows for the CLI."""

    def __init__(
        self, *, scope: str = "openid profile offline_access", timeout: float = 30.0
    ) -> None:
        self.scope = scope
        self.timeout = timeout

    def login_device(self, metadata: AuthMetadata) -> LoginResult:
        if not metadata.issuer_url:
            raise ValueError("issuer URL is required for device login")
        if not metadata.cli_client_id:
            raise ValueError("CLI client ID is required for device login")

        device_resp = get_device_authorization(
            issuer_url=metadata.issuer_url,
            client_id=metadata.cli_client_id,
            scope=" ".join(metadata.scopes) if metadata.scopes else self.scope,
            timeout=self.timeout,
        )
        token_response = poll_for_token(
            issuer_url=metadata.issuer_url,
            client_id=metadata.cli_client_id,
            device_code=str(device_resp["device_code"]),
            interval=int(device_resp.get("interval", 5)),
            timeout=self.timeout,
        )
        return LoginResult(
            access_token=token_response.access_token,
            refresh_token=token_response.refresh_token,
            expires_at=datetime.now(timezone.utc) + timedelta(seconds=token_response.expires_in),
        )

    def login_password(
        self,
        metadata: AuthMetadata,
        *,
        username: str,
        password: str,
        client_id: str | None = None,
        scope: str | None = None,
    ) -> LoginResult:
        if not metadata.issuer_url:
            raise ValueError("issuer URL is required for password login")
        resolved_client_id = client_id or metadata.cli_client_id
        if not resolved_client_id:
            raise ValueError("client ID is required for password login")

        token_response = get_password_token(
            issuer_url=metadata.issuer_url,
            client_id=resolved_client_id,
            username=username,
            password=password,
            scope=scope or " ".join(metadata.scopes) if metadata.scopes else self.scope,
            timeout=self.timeout,
        )
        return LoginResult(
            access_token=token_response.access_token,
            refresh_token=token_response.refresh_token,
            expires_at=datetime.now(timezone.utc) + timedelta(seconds=token_response.expires_in),
        )

    def refresh(self, session: StoredSession, metadata: AuthMetadata) -> LoginResult:
        del metadata
        if not session.refresh_token:
            raise ValueError("refresh token is required")
        token_response = refresh_access_token(
            issuer_url=session.issuer_url,
            client_id=session.client_id,
            refresh_token=session.refresh_token,
            timeout=self.timeout,
        )
        return LoginResult(
            access_token=token_response.access_token,
            refresh_token=token_response.refresh_token or session.refresh_token,
            expires_at=datetime.now(timezone.utc) + timedelta(seconds=token_response.expires_in),
            subject=session.subject,
        )
