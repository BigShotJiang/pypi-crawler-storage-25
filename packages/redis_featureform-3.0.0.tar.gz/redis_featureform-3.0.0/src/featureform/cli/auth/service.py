"""Coordinator service for enterprise CLI auth behavior."""

from __future__ import annotations

import base64
import json
from datetime import timedelta
from typing import Any, cast

from featureform._internal.logging import get_logger
from featureform.auth import AuthenticationError, get_client_credentials_token
from featureform.cli.auth.clock import Clock
from featureform.cli.auth.discovery import AuthDiscoveryClient, AuthDiscoveryError
from featureform.cli.auth.flows import AuthFlowExecutor, LoginResult
from featureform.cli.auth.profiles import ProfileRepository
from featureform.cli.auth.session_store import SessionStore, StorageUnavailableError
from featureform.cli.auth.types import (
    AuthMetadata,
    AuthStatus,
    LoginState,
    LogoutResult,
    ProfileConfig,
    StoredSession,
)

refresh_skew = timedelta(seconds=60)
_logger = get_logger("featureform.cli.auth.service")


class AuthService:
    """Coordinate discovery, profiles, sessions, and refresh behavior."""

    def __init__(
        self,
        *,
        discovery: AuthDiscoveryClient,
        sessions: SessionStore,
        profiles: ProfileRepository,
        flows: AuthFlowExecutor,
        clock: Clock,
    ) -> None:
        self.discovery = discovery
        self.sessions = sessions
        self.profiles = profiles
        self.flows = flows
        self.clock = clock

    def login(
        self,
        *,
        server_url: str | None = None,
        profile_name: str | None = None,
        transport: str = "grpc",
        no_tls: bool = False,
    ) -> LoginState:
        """Perform profile-aware login."""
        active = self.profiles.get_active_profile()
        resolved_profile = self._resolve_profile_for_login(
            active=active,
            server_url=server_url,
            profile_name=profile_name,
            transport=transport,
            no_tls=no_tls,
        )
        metadata = self.discovery.get_metadata(resolved_profile.server, resolved_profile.transport)
        self._validate_metadata(
            metadata,
            require_device_code=True,
            require_cli_client_id=True,
        )

        existing = self.sessions.load(resolved_profile.name)
        login_result = self.flows.login_device(metadata)
        return self._persist_login(
            profile=resolved_profile,
            existing=existing,
            login_result=login_result,
            issuer_url=metadata.issuer_url or "",
            client_id=metadata.cli_client_id or "",
            login_method="device_code",
        )

    def login_password(
        self,
        *,
        username: str,
        password: str,
        server_url: str | None = None,
        profile_name: str | None = None,
        transport: str = "grpc",
        no_tls: bool = False,
        client_id: str | None = None,
        scope: str | None = None,
    ) -> LoginState:
        """Perform profile-aware password-grant login."""
        active = self.profiles.get_active_profile()
        resolved_profile = self._resolve_profile_for_login(
            active=active,
            server_url=server_url,
            profile_name=profile_name,
            transport=transport,
            no_tls=no_tls,
        )
        metadata = self.discovery.get_metadata(resolved_profile.server, resolved_profile.transport)
        self._validate_metadata(metadata)

        resolved_client_id = client_id or metadata.audience or metadata.cli_client_id
        if not resolved_client_id:
            raise ValueError("Server discovery did not return a password-grant client ID")

        existing = self.sessions.load(resolved_profile.name)
        login_result = self.flows.login_password(
            metadata,
            username=username,
            password=password,
            client_id=resolved_client_id,
            scope=scope,
        )
        return self._persist_login(
            profile=resolved_profile,
            existing=existing,
            login_result=login_result,
            issuer_url=metadata.issuer_url or "",
            client_id=resolved_client_id,
            login_method="password",
        )

    def login_password_direct(
        self,
        *,
        username: str,
        password: str,
        issuer_url: str,
        client_id: str,
        server_url: str | None = None,
        profile_name: str | None = None,
        transport: str = "grpc",
        no_tls: bool = False,
        scope: str | None = None,
    ) -> LoginState:
        """Perform profile-aware password-grant login using explicit OIDC settings."""
        active = self.profiles.get_active_profile()
        resolved_profile = self._resolve_profile_for_login(
            active=active,
            server_url=server_url,
            profile_name=profile_name,
            transport=transport,
            no_tls=no_tls,
        )
        metadata = AuthMetadata(
            auth_enabled=True,
            issuer_url=issuer_url,
            cli_client_id=client_id,
            scopes=scope.split() if scope else [],
        )
        existing = self.sessions.load(resolved_profile.name)
        login_result = self.flows.login_password(
            metadata,
            username=username,
            password=password,
            client_id=client_id,
            scope=scope,
        )
        return self._persist_login(
            profile=resolved_profile,
            existing=existing,
            login_result=login_result,
            issuer_url=issuer_url,
            client_id=client_id,
            login_method="password",
        )

    def login_device_direct(
        self,
        *,
        issuer_url: str,
        client_id: str,
        server_url: str | None = None,
        profile_name: str | None = None,
        transport: str = "grpc",
        no_tls: bool = False,
        scope: str | None = None,
    ) -> LoginState:
        """Perform profile-aware device login using explicit OIDC settings."""
        active = self.profiles.get_active_profile()
        resolved_profile = self._resolve_profile_for_login(
            active=active,
            server_url=server_url,
            profile_name=profile_name,
            transport=transport,
            no_tls=no_tls,
        )
        metadata = AuthMetadata(
            auth_enabled=True,
            issuer_url=issuer_url,
            cli_client_id=client_id,
            supported_login_methods=["device_code"],
            scopes=scope.split() if scope else [],
        )
        existing = self.sessions.load(resolved_profile.name)
        login_result = self.flows.login_device(metadata)
        return self._persist_login(
            profile=resolved_profile,
            existing=existing,
            login_result=login_result,
            issuer_url=issuer_url,
            client_id=client_id,
            login_method="device_code",
        )

    def _persist_login(
        self,
        *,
        profile: ProfileConfig,
        existing: StoredSession | None,
        login_result: LoginResult,
        issuer_url: str,
        client_id: str,
        login_method: str,
    ) -> LoginState:
        session = StoredSession(
            profile_name=profile.name,
            access_token=login_result.access_token,
            refresh_token=login_result.refresh_token,
            issuer_url=issuer_url,
            client_id=client_id,
            login_method=login_method,
            subject=login_result.subject or _jwt_subject(login_result.access_token),
            expires_at=login_result.expires_at,
        )
        profile.issuer_url = issuer_url
        profile.cli_client_id = client_id
        self.profiles.save_profile(profile)
        self.profiles.set_active_profile(profile.name)
        self.sessions.save(profile.name, session)

        return LoginState(
            profile_name=profile.name,
            server=profile.server,
            issuer_url=session.issuer_url,
            client_id=session.client_id,
            replaced_existing_session=existing is not None,
        )

    def status(self, *, env_token: str | None = None) -> AuthStatus:
        """Return profile/session/discovery status."""
        profile = self.profiles.get_active_profile()
        if profile is None:
            return AuthStatus(
                profile_name=None,
                server=None,
                session_state="no_profile",
                discovery_state="unknown",
                auth_source="env_token" if env_token else None,
            )

        if env_token:
            env_discovery_state = "unknown"
            env_discovery_message: str | None = None
            try:
                metadata = self.discovery.get_metadata(profile.server, profile.transport)
                env_discovery_state = "auth_disabled" if not metadata.auth_enabled else "live"
            except AuthDiscoveryError as exc:
                env_discovery_state = "unavailable"
                env_discovery_message = str(exc)
            return AuthStatus(
                profile_name=profile.name,
                server=profile.server,
                session_state="env_override",
                discovery_state=env_discovery_state,
                auth_source="FEATUREFORM_TOKEN",
                issuer_url=profile.issuer_url,
                message=env_discovery_message,
            )

        try:
            session = self.sessions.load(profile.name)
        except (StorageUnavailableError, ValueError) as exc:
            return AuthStatus(
                profile_name=profile.name,
                server=profile.server,
                session_state="storage_unavailable",
                discovery_state="unknown",
                issuer_url=profile.issuer_url,
                message=str(exc),
            )

        discovery_state = "unknown"
        discovery_message: str | None = None
        try:
            metadata = self.discovery.get_metadata(profile.server, profile.transport)
            discovery_state = "auth_disabled" if not metadata.auth_enabled else "live"
        except AuthDiscoveryError as exc:
            discovery_state = "unavailable"
            discovery_message = str(exc)
        if session is None:
            return AuthStatus(
                profile_name=profile.name,
                server=profile.server,
                session_state="no_session",
                discovery_state=discovery_state,
                issuer_url=profile.issuer_url,
                message=discovery_message,
            )

        session_state = "session_present"
        if not self._session_is_valid(session):
            session_state = "refresh_required"
        return AuthStatus(
            profile_name=profile.name,
            server=profile.server,
            session_state=session_state,
            discovery_state=discovery_state,
            issuer_url=session.issuer_url,
            message=discovery_message,
        )

    def logout(self) -> LogoutResult:
        """Clear persisted interactive session state."""
        profile = self.profiles.get_active_profile()
        if profile is None:
            return LogoutResult(profile_name=None, removed_session=False)
        had_session = self.sessions.load(profile.name) is not None
        self.sessions.delete(profile.name)
        return LogoutResult(profile_name=profile.name, removed_session=had_session)

    def resolve_access_token(
        self,
        *,
        env_token: str | None = None,
        client_id: str | None = None,
        client_secret: str | None = None,
        issuer_url: str | None = None,
        server_url: str | None = None,
        transport: str | None = None,
        profile_name: str | None = None,
    ) -> str | None:
        """Resolve the effective access token for a command invocation."""
        if env_token:
            _logger.debug("auth_token_resolution_using_env_token")
            return env_token

        if client_id and client_secret and issuer_url:
            _logger.debug(
                "auth_token_resolution_using_client_credentials",
                issuer_url=issuer_url,
                client_id=client_id,
            )
            login_client_credentials = cast(
                Any, getattr(self.flows, "login_client_credentials", None)
            )
            if callable(login_client_credentials):
                result = cast(
                    LoginResult,
                    login_client_credentials(
                        issuer_url=issuer_url,
                        client_id=client_id,
                        client_secret=client_secret,
                    ),
                )
                return result.access_token
            token_response = get_client_credentials_token(
                issuer_url=issuer_url,
                client_id=client_id,
                client_secret=client_secret,
            )
            return token_response.access_token

        profile = (
            self.profiles.get_profile(profile_name)
            if profile_name is not None
            else self.profiles.get_active_profile()
        )
        if profile_name is not None and profile is None:
            raise ValueError(f"Auth profile '{profile_name}' was not found")
        if profile is None:
            _logger.debug("auth_token_resolution_no_active_profile")
            return None
        if _profile_target_mismatch(profile=profile, server_url=server_url, transport=transport):
            _logger.warning(
                "auth_token_resolution_profile_target_mismatch",
                profile_name=profile.name,
                profile_server=profile.server,
                profile_transport=profile.transport,
                command_server=server_url,
                command_transport=transport,
            )
            raise ValueError(
                "Active auth profile points at a different server than this command. "
                "Re-login for this target or select the correct profile."
            )
        session = self.sessions.load(profile.name)
        if session is None:
            _logger.debug("auth_token_resolution_no_stored_session", profile_name=profile.name)
            return None

        if self._session_is_valid(session):
            _logger.debug("auth_token_resolution_using_cached_session", profile_name=profile.name)
            return session.access_token

        _logger.info(
            "auth_token_resolution_refreshing_stored_session",
            profile_name=profile.name,
            profile_server=profile.server,
            profile_transport=profile.transport,
        )
        try:
            metadata = self.discovery.get_metadata(profile.server, profile.transport)
        except AuthDiscoveryError as exc:
            _logger.warning(
                "auth_token_resolution_refresh_discovery_unavailable",
                profile_name=profile.name,
                profile_server=profile.server,
                error=str(exc),
            )
            raise ValueError(
                "Stored session exists but cannot be refreshed because auth discovery is unavailable. "
                "Try again later or re-login."
            ) from exc

        self._validate_metadata(metadata)
        if self._materially_changed(session, metadata):
            _logger.warning(
                "auth_token_resolution_refresh_material_change",
                profile_name=profile.name,
                profile_server=profile.server,
                issuer_url=session.issuer_url,
                discovered_issuer_url=metadata.issuer_url,
            )
            raise ValueError("Auth discovery changed materially; please re-login")

        if not session.refresh_token or not metadata.token_refresh_supported:
            _logger.warning(
                "auth_token_resolution_refresh_not_supported",
                profile_name=profile.name,
                has_refresh_token=bool(session.refresh_token),
                token_refresh_supported=metadata.token_refresh_supported,
            )
            raise ValueError("Stored session expired and cannot be refreshed; please re-login")

        try:
            refreshed = self.flows.refresh(session, metadata)
        except AuthenticationError as exc:
            _logger.warning(
                "auth_token_resolution_refresh_failed",
                profile_name=profile.name,
                error=str(exc),
                reason=exc.reason,
            )
            if exc.reason == "invalid_refresh_token":
                self.sessions.delete(profile.name)
                raise ValueError(
                    "Stored session expired and refresh was rejected; please re-login"
                ) from exc
            raise ValueError(
                "Stored session exists but could not be refreshed right now; please try again."
            ) from exc
        updated = StoredSession(
            profile_name=profile.name,
            access_token=refreshed.access_token,
            refresh_token=refreshed.refresh_token or session.refresh_token,
            issuer_url=session.issuer_url,
            client_id=session.client_id,
            login_method=session.login_method,
            subject=refreshed.subject or session.subject,
            expires_at=refreshed.expires_at,
        )
        if self.sessions.compare_and_swap(profile.name, session, updated):
            _logger.info("auth_token_resolution_refresh_succeeded", profile_name=profile.name)
            return updated.access_token

        latest_session = self.sessions.load(profile.name)
        if latest_session is None:
            raise ValueError("Stored session changed while refreshing; please re-login")
        if self._session_is_valid(latest_session):
            _logger.debug(
                "auth_token_resolution_refresh_raced_but_latest_is_valid",
                profile_name=profile.name,
            )
            return latest_session.access_token
        raise ValueError("Stored session changed while refreshing; please retry")

    def _resolve_profile_for_login(
        self,
        *,
        active: ProfileConfig | None,
        server_url: str | None,
        profile_name: str | None,
        transport: str,
        no_tls: bool,
    ) -> ProfileConfig:
        if active is None:
            if not server_url:
                raise ValueError("No configured profile found; configure a server or pass --server")
            name = profile_name or "default"
            return ProfileConfig(name=name, server=server_url, transport=transport, no_tls=no_tls)

        if profile_name:
            existing = self.profiles.get_profile(profile_name)
            if existing is not None:
                if server_url and existing.server != server_url:
                    raise ValueError("Requested profile does not match the supplied server")
                if no_tls:
                    existing.no_tls = True
                return existing
            if not server_url:
                raise ValueError("A new profile requires --server")
            return ProfileConfig(
                name=profile_name,
                server=server_url,
                transport=transport,
                no_tls=no_tls,
            )

        if server_url and active.server != server_url:
            raise ValueError("A different server requires an explicit profile selection")
        if no_tls:
            active.no_tls = True
        return active

    def _validate_metadata(
        self,
        metadata: AuthMetadata,
        *,
        require_device_code: bool = False,
        require_cli_client_id: bool = False,
    ) -> None:
        if not metadata.auth_enabled:
            raise ValueError("Auth is not enabled on the target server")
        if not metadata.issuer_url:
            raise ValueError("Server discovery did not return an issuer URL")
        if require_cli_client_id and not metadata.cli_client_id:
            raise ValueError("Server discovery did not return a CLI client ID")
        if require_device_code and "device_code" not in metadata.supported_login_methods:
            raise ValueError(
                "Server discovery does not advertise device-code login support for the CLI"
            )

    def _materially_changed(self, session: StoredSession, metadata: AuthMetadata) -> bool:
        methods = metadata.supported_login_methods or []
        if session.issuer_url != metadata.issuer_url:
            return True
        if session.login_method == "device_code":
            return session.client_id != metadata.cli_client_id or "device_code" not in methods
        return False

    def _session_is_valid(self, session: StoredSession) -> bool:
        return session.expires_at - refresh_skew > self.clock.now()


def _jwt_subject(token: str) -> str | None:
    parts = token.split(".")
    if len(parts) != 3:
        return None
    payload = parts[1]
    payload += "=" * (-len(payload) % 4)
    try:
        decoded = base64.urlsafe_b64decode(payload.encode("ascii")).decode("utf-8")
        claims = json.loads(decoded)
    except (ValueError, UnicodeDecodeError, json.JSONDecodeError):
        return None
    subject = claims.get("sub")
    return subject if isinstance(subject, str) else None


def _profile_target_mismatch(
    *,
    profile: ProfileConfig,
    server_url: str | None,
    transport: str | None,
) -> bool:
    del transport
    if not server_url:
        return False
    return profile.server.rstrip("/") != server_url.rstrip("/")
