"""Auth orchestration interfaces for the Featureform CLI."""

from __future__ import annotations

from importlib import import_module
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from featureform.cli.auth.clock import Clock, SystemClock
    from featureform.cli.auth.discovery import (
        AuthDiscoveryClient,
        AuthDiscoveryError,
        CompositeAuthDiscoveryClient,
        GRPCAuthDiscoveryClient,
        RESTAuthDiscoveryClient,
    )
    from featureform.cli.auth.flows import AuthFlowExecutor, LoginResult, OIDCFlowExecutor
    from featureform.cli.auth.profiles import (
        ProfileRepository,
        YAMLProfileRepository,
        default_config_dir,
        default_config_path,
    )
    from featureform.cli.auth.service import AuthService
    from featureform.cli.auth.session_store import (
        FileSessionStore,
        KeyringSessionStore,
        SessionStore,
        StorageUnavailableError,
        build_session_store,
        default_session_path,
    )
    from featureform.cli.auth.types import (
        AuthMetadata,
        AuthStatus,
        LoginState,
        LogoutResult,
        ProfileConfig,
        StoredSession,
    )

_EXPORTS = {
    "Clock": ("featureform.cli.auth.clock", "Clock"),
    "SystemClock": ("featureform.cli.auth.clock", "SystemClock"),
    "AuthDiscoveryClient": ("featureform.cli.auth.discovery", "AuthDiscoveryClient"),
    "AuthDiscoveryError": ("featureform.cli.auth.discovery", "AuthDiscoveryError"),
    "CompositeAuthDiscoveryClient": (
        "featureform.cli.auth.discovery",
        "CompositeAuthDiscoveryClient",
    ),
    "GRPCAuthDiscoveryClient": ("featureform.cli.auth.discovery", "GRPCAuthDiscoveryClient"),
    "RESTAuthDiscoveryClient": ("featureform.cli.auth.discovery", "RESTAuthDiscoveryClient"),
    "AuthFlowExecutor": ("featureform.cli.auth.flows", "AuthFlowExecutor"),
    "LoginResult": ("featureform.cli.auth.flows", "LoginResult"),
    "OIDCFlowExecutor": ("featureform.cli.auth.flows", "OIDCFlowExecutor"),
    "ProfileRepository": ("featureform.cli.auth.profiles", "ProfileRepository"),
    "YAMLProfileRepository": ("featureform.cli.auth.profiles", "YAMLProfileRepository"),
    "default_config_dir": ("featureform.cli.auth.profiles", "default_config_dir"),
    "default_config_path": ("featureform.cli.auth.profiles", "default_config_path"),
    "AuthService": ("featureform.cli.auth.service", "AuthService"),
    "FileSessionStore": ("featureform.cli.auth.session_store", "FileSessionStore"),
    "KeyringSessionStore": ("featureform.cli.auth.session_store", "KeyringSessionStore"),
    "SessionStore": ("featureform.cli.auth.session_store", "SessionStore"),
    "StorageUnavailableError": ("featureform.cli.auth.session_store", "StorageUnavailableError"),
    "build_session_store": ("featureform.cli.auth.session_store", "build_session_store"),
    "default_session_path": ("featureform.cli.auth.session_store", "default_session_path"),
    "AuthMetadata": ("featureform.cli.auth.types", "AuthMetadata"),
    "AuthStatus": ("featureform.cli.auth.types", "AuthStatus"),
    "LoginState": ("featureform.cli.auth.types", "LoginState"),
    "LogoutResult": ("featureform.cli.auth.types", "LogoutResult"),
    "ProfileConfig": ("featureform.cli.auth.types", "ProfileConfig"),
    "StoredSession": ("featureform.cli.auth.types", "StoredSession"),
}


def __getattr__(name: str) -> Any:
    if name not in _EXPORTS:
        raise AttributeError(name)

    module_name, attr_name = _EXPORTS[name]
    module = import_module(module_name)
    return getattr(module, attr_name)


__all__ = (
    "Clock",
    "SystemClock",
    "AuthDiscoveryClient",
    "AuthDiscoveryError",
    "CompositeAuthDiscoveryClient",
    "GRPCAuthDiscoveryClient",
    "RESTAuthDiscoveryClient",
    "AuthFlowExecutor",
    "LoginResult",
    "OIDCFlowExecutor",
    "ProfileRepository",
    "YAMLProfileRepository",
    "default_config_dir",
    "default_config_path",
    "AuthService",
    "FileSessionStore",
    "KeyringSessionStore",
    "SessionStore",
    "StorageUnavailableError",
    "build_session_store",
    "default_session_path",
    "AuthMetadata",
    "AuthStatus",
    "LoginState",
    "LogoutResult",
    "ProfileConfig",
    "StoredSession",
)
