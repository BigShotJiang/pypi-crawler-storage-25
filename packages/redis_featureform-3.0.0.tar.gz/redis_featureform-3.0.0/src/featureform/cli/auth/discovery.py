"""Discovery interface for CLI auth metadata."""

from __future__ import annotations

from importlib import import_module
from typing import Any, Protocol, cast
from urllib.parse import urlparse

import grpc
import httpx

from featureform._internal.http import httpx_ssl_context
from featureform._internal.logging import get_logger
from featureform.cli.auth.types import AuthMetadata
from featureform.transport.grpc import TimeoutStubProxy, create_grpc_channel

_logger = get_logger("featureform.cli.auth.discovery")


class AuthDiscoveryError(RuntimeError):
    """Raised when server auth discovery is missing, malformed, or unreachable."""


class AuthDiscoveryClient(Protocol):
    """Fetch auth metadata from a Featureform server."""

    def get_metadata(self, server_url: str, transport: str) -> AuthMetadata:
        """Return auth metadata for the given server and transport."""
        ...


class RESTAuthDiscoveryClient:
    """Fetch auth metadata from the public REST discovery endpoint."""

    def __init__(
        self,
        *,
        timeout: float = 30.0,
        verify_ssl: bool = True,
        ca_cert_path: str | None = None,
        client_cert_path: str | None = None,
        client_key_path: str | None = None,
    ) -> None:
        self.timeout = timeout
        self.verify_ssl = verify_ssl
        self.ca_cert_path = ca_cert_path
        self.client_cert_path = client_cert_path
        self.client_key_path = client_key_path

    def get_metadata(self, server_url: str, transport: str) -> AuthMetadata:
        del transport
        try:
            with httpx.Client(
                timeout=self.timeout,
                verify=httpx_ssl_context(
                    self.verify_ssl,
                    self.ca_cert_path,
                    self.client_cert_path,
                    self.client_key_path,
                ),
            ) as client:
                response = client.get(f"{server_url.rstrip('/')}/api/v1/auth/metadata")
                response.raise_for_status()
                return _parse_metadata_payload(response.json())
        except httpx.HTTPStatusError as exc:
            status_code = exc.response.status_code
            if status_code == 404:
                raise AuthDiscoveryError(
                    "The target server does not expose auth discovery metadata. "
                    "Retry with --issuer-url and --client-id."
                ) from exc
            raise AuthDiscoveryError(
                f"Auth discovery failed with HTTP {status_code}. Retry with --issuer-url and --client-id."
            ) from exc
        except httpx.HTTPError as exc:
            raise AuthDiscoveryError(
                "The target server could not be reached for auth discovery. Retry or pass --issuer-url and --client-id."
            ) from exc


class GRPCAuthDiscoveryClient:
    """Fetch auth metadata from the public gRPC version service."""

    def __init__(
        self,
        *,
        timeout: float = 30.0,
        verify_ssl: bool = True,
        no_tls: bool = False,
        ca_cert_path: str | None = None,
        client_cert_path: str | None = None,
        client_key_path: str | None = None,
    ) -> None:
        self.timeout = timeout
        self.verify_ssl = verify_ssl
        self.no_tls = no_tls
        self.ca_cert_path = ca_cert_path
        self.client_cert_path = client_cert_path
        self.client_key_path = client_key_path

    def get_metadata(self, server_url: str, transport: str) -> AuthMetadata:
        del transport
        try:
            version_pb2 = import_module("featureform._generated.proto.featureform.v2.version_pb2")
            version_pb2_grpc = import_module(
                "featureform._generated.proto.featureform.v2.version_pb2_grpc"
            )

            channel = create_grpc_channel(
                server_url,
                self.verify_ssl,
                no_tls=self.no_tls,
                ca_cert_path=self.ca_cert_path,
                client_cert_path=self.client_cert_path,
                client_key_path=self.client_key_path,
            )
            try:
                stub = TimeoutStubProxy(
                    version_pb2_grpc.VersionServiceStub(channel),
                    default_timeout=self.timeout,
                    logger=_logger,
                    stub_name="VersionServiceStub",
                )
                response = stub.GetAuthMetadata(version_pb2.GetAuthMetadataRequest())
            finally:
                channel.close()
        except grpc.RpcError as exc:
            raise AuthDiscoveryError(
                "The target gRPC server could not return auth discovery metadata."
            ) from exc

        return AuthMetadata(
            auth_enabled=response.auth_enabled,
            issuer_url=response.issuer_url or None,
            oidc_discovery_url=response.oidc_discovery_url or None,
            cli_client_id=response.cli_client_id or None,
            audience=response.audience or None,
            supported_login_methods=list(response.supported_login_methods),
            token_refresh_supported=response.token_refresh_supported,
            scopes=list(response.scopes),
        )


class CompositeAuthDiscoveryClient:
    """Use the configured transport first, then fall back when appropriate."""

    def __init__(
        self, *, rest: RESTAuthDiscoveryClient, grpc_client: GRPCAuthDiscoveryClient
    ) -> None:
        self.rest = rest
        self.grpc_client = grpc_client

    def get_metadata(self, server_url: str, transport: str) -> AuthMetadata:
        if transport == "grpc":
            try:
                _logger.debug("auth_discovery_attempt", transport="grpc", server_url=server_url)
                return self.grpc_client.get_metadata(server_url, transport)
            except (AuthDiscoveryError, grpc.RpcError, OSError) as exc:
                if not _should_try_rest_fallback(server_url):
                    _logger.warning(
                        "auth_discovery_grpc_failed_without_rest_fallback",
                        server_url=server_url,
                        error=str(exc),
                    )
                    raise
                _logger.warning(
                    "auth_discovery_grpc_failed_falling_back_to_rest",
                    server_url=server_url,
                    error=str(exc),
                )
                return self.rest.get_metadata(server_url, "rest")
        _logger.debug("auth_discovery_attempt", transport="rest", server_url=server_url)
        return self.rest.get_metadata(server_url, transport)


def _should_try_rest_fallback(server_url: str) -> bool:
    """Return True when a failed gRPC discovery can sensibly retry via REST.

    Bare host:port gRPC targets like localhost:9090 do not imply a matching REST
    endpoint on the same port. Falling back there only burns the full timeout.
    """
    if not server_url:
        return False
    if "://" not in server_url:
        return False
    parsed = urlparse(server_url)
    return parsed.scheme in {"http", "https"}


def _parse_metadata_payload(payload: object) -> AuthMetadata:
    if not isinstance(payload, dict):
        raise AuthDiscoveryError("Auth discovery response must be an object")
    payload_map = cast(dict[str, Any], payload)

    auth_enabled = payload_map.get("auth_enabled")
    if not isinstance(auth_enabled, bool):
        raise AuthDiscoveryError("Auth discovery response is missing a boolean auth_enabled field")

    supported_login_methods = payload_map.get("supported_login_methods", [])
    if not isinstance(supported_login_methods, list):
        raise AuthDiscoveryError(
            "Auth discovery response has an invalid supported_login_methods field"
        )
    scopes = payload_map.get("scopes", [])
    if not isinstance(scopes, list):
        raise AuthDiscoveryError("Auth discovery response has an invalid scopes field")

    for field_name in ("issuer_url", "oidc_discovery_url", "cli_client_id", "audience"):
        value = payload_map.get(field_name)
        if value is not None and not isinstance(value, str):
            raise AuthDiscoveryError(
                f"Auth discovery response field {field_name} must be a string when present"
            )

    token_refresh_supported = payload_map.get("token_refresh_supported", False)
    if not isinstance(token_refresh_supported, bool):
        raise AuthDiscoveryError(
            "Auth discovery response has an invalid token_refresh_supported field"
        )

    return AuthMetadata(
        auth_enabled=auth_enabled,
        issuer_url=payload_map.get("issuer_url")
        if isinstance(payload_map.get("issuer_url"), str)
        else None,
        oidc_discovery_url=payload_map.get("oidc_discovery_url")
        if isinstance(payload_map.get("oidc_discovery_url"), str)
        else None,
        cli_client_id=payload_map.get("cli_client_id")
        if isinstance(payload_map.get("cli_client_id"), str)
        else None,
        audience=payload_map.get("audience")
        if isinstance(payload_map.get("audience"), str)
        else None,
        supported_login_methods=[
            method for method in supported_login_methods if isinstance(method, str)
        ],
        token_refresh_supported=token_refresh_supported,
        scopes=[scope for scope in scopes if isinstance(scope, str)],
    )
