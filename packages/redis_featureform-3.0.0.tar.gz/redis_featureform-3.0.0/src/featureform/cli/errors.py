"""CLI error handling with actionable user messages.

This module provides consistent error formatting following the design principle:
"Error: <what happened>. <what to do>"

Exit codes follow the ERROR_MESSAGES.md specification.
"""

from __future__ import annotations

import httpx

# Exit codes per ERROR_MESSAGES.md spec
EXIT_SUCCESS = 0
EXIT_ERROR = 1
EXIT_INVALID_ARGS = 2
EXIT_NOT_FOUND = 3
EXIT_CONNECTION_ERROR = 4
EXIT_TIMEOUT = 5
EXIT_AUTH_ERROR = 6
EXIT_VERSION_MISMATCH = 7
EXIT_CONFIG_ERROR = 8


def format_connection_error(url: str, err: httpx.ConnectError) -> tuple[str, int]:
    """Format connection error with actionable message.

    Returns:
        Tuple of (message, exit_code)
    """
    # Check for DNS resolution failure
    err_str = str(err).lower()
    if "name resolution" in err_str or "getaddrinfo" in err_str or "nodename" in err_str:
        hostname = _extract_hostname(url)
        return (
            f"Cannot resolve hostname '{hostname}'. Check server URL or network configuration.",
            EXIT_CONNECTION_ERROR,
        )

    # Generic connection refused
    return (
        f"Cannot connect to server at '{url}'. Server may be down or URL is incorrect.",
        EXIT_CONNECTION_ERROR,
    )


def format_timeout_error(timeout: float) -> tuple[str, int]:
    """Format timeout error with actionable message.

    Returns:
        Tuple of (message, exit_code)
    """
    return (
        f"Request timed out after {timeout}s. Try increasing --timeout or check server health.",
        EXIT_TIMEOUT,
    )


def format_http_error(
    resp: httpx.Response, resource_type: str = "", resource_id: str = ""
) -> tuple[str, int]:
    """Format HTTP error with actionable message based on status code.

    Returns:
        Tuple of (message, exit_code)
    """
    status = resp.status_code

    # Try to extract message from JSON response
    detail = ""
    try:
        data = resp.json()
        detail = data.get("message", data.get("detail", ""))
    except Exception:
        detail = resp.text[:200] if resp.text else ""

    if status == 400:
        msg = f"Invalid request: {detail}" if detail else "Invalid request"
        return (msg, EXIT_INVALID_ARGS)

    if status == 401:
        return (
            "Authentication failed - token is invalid or expired. Run 'ff auth login' to refresh.",
            EXIT_AUTH_ERROR,
        )

    if status == 403:
        return (
            "Permission denied. You don't have access to this resource. Contact your administrator.",
            EXIT_AUTH_ERROR,
        )

    if status == 404:
        if resource_type and resource_id:
            return (f"{resource_type} '{resource_id}' not found.", EXIT_NOT_FOUND)
        return ("Resource not found.", EXIT_NOT_FOUND)

    if status == 409:
        # Always use the server's message for conflicts - could be "already exists",
        # "job already running", overlap policy violation, etc.
        msg = detail if detail else "Resource conflict"
        return (msg, EXIT_ERROR)

    if status == 429:
        retry_after = resp.headers.get("Retry-After", "60")
        return (
            f"Rate limit exceeded. Try again in {retry_after} seconds.",
            EXIT_ERROR,
        )

    if status == 503:
        return (
            "Service temporarily unavailable. The server may be starting up or under maintenance.",
            EXIT_CONNECTION_ERROR,
        )

    # Generic server error
    return (
        f"Server error ({status}): {detail}" if detail else f"Server error ({status})",
        EXIT_ERROR,
    )


def format_auth_missing_error() -> tuple[str, int]:
    """Format missing authentication error."""
    return (
        "Authentication required. Run 'ff auth login' or set FEATUREFORM_TOKEN.",
        EXIT_AUTH_ERROR,
    )


def format_server_not_configured_error() -> tuple[str, int]:
    """Format server not configured error."""
    return (
        "Server URL not configured. Set FEATUREFORM_BASE_URL or pass --server flag.",
        EXIT_CONFIG_ERROR,
    )


def format_tls_error(url: str) -> tuple[str, int]:
    """Format TLS/SSL error with actionable message."""
    return (
        f"TLS connection failed to '{url}'. Use --insecure for self-signed certs or check certificate.",
        EXIT_CONNECTION_ERROR,
    )


def _extract_hostname(url: str) -> str:
    """Extract hostname from URL."""
    try:
        from urllib.parse import urlparse

        return urlparse(url).hostname or url
    except Exception:
        return url
