"""Featureform CLI package."""

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from featureform.cli.main import app, check_server_compatibility, get_context


def __getattr__(name: str) -> Any:
    if name not in {"app", "check_server_compatibility", "get_context"}:
        raise AttributeError(name)

    from featureform.cli.main import app, check_server_compatibility, get_context

    exports = {
        "app": app,
        "check_server_compatibility": check_server_compatibility,
        "get_context": get_context,
    }
    return exports[name]


__all__ = ["app", "check_server_compatibility", "get_context"]
