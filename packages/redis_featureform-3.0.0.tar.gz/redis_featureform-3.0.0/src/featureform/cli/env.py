"""Centralized CLI environment helpers."""

from __future__ import annotations

import os
import tempfile
from pathlib import Path

ENV_FEATUREFORM_CONFIG = "FEATUREFORM_CONFIG"
ENV_FEATUREFORM_AUTH_STORAGE = "FEATUREFORM_AUTH_STORAGE"
ENV_FEATUREFORM_TOKEN = "FEATUREFORM_TOKEN"
ENV_NO_COLOR = "NO_COLOR"
ENV_TERM = "TERM"
ENV_HOME = "HOME"
ENV_USERPROFILE = "USERPROFILE"
ENV_HOMEDRIVE = "HOMEDRIVE"
ENV_HOMEPATH = "HOMEPATH"


def env(name: str) -> str | None:
    return os.environ.get(name)


def env_or_default(name: str, default: str) -> str:
    return os.environ.get(name, default)


def config_override() -> str | None:
    return env(ENV_FEATUREFORM_CONFIG)


def default_config_dir() -> Path:
    override = config_override()
    if override:
        return Path(override).expanduser().resolve().parent

    home = env(ENV_HOME)
    if home:
        return Path(home).expanduser().resolve() / ".featureform"

    user_profile = env(ENV_USERPROFILE)
    if user_profile:
        return Path(user_profile).expanduser().resolve() / ".featureform"

    home_drive = env(ENV_HOMEDRIVE)
    home_path = env(ENV_HOMEPATH)
    if home_drive and home_path:
        return Path(f"{home_drive}{home_path}").expanduser().resolve() / ".featureform"

    try:
        return Path.home() / ".featureform"
    except RuntimeError:
        return Path(tempfile.gettempdir()).resolve() / ".featureform"


def featureform_token() -> str | None:
    return env(ENV_FEATUREFORM_TOKEN)


def auth_storage_mode() -> str:
    return env_or_default(ENV_FEATUREFORM_AUTH_STORAGE, "keyring").strip().lower()


def no_color_enabled() -> bool:
    return bool(env(ENV_NO_COLOR))


def term_name() -> str | None:
    return env(ENV_TERM)
