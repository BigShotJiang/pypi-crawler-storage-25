"""Table output formatter using Rich."""

from __future__ import annotations

from typing import Any, cast

from rich.console import Console
from rich.table import Table

from featureform.cli.output.base import OutputFormatter


class TableFormatter(OutputFormatter):
    """Format output as Rich tables.

    This formatter supports two modes of operation:
    1. format()/format_list(): Returns a string, optionally terminal-aware
    2. print()/print_list(): Prints directly to console for proper terminal detection

    For CLI output, prefer print()/print_list() as they allow Rich to
    automatically detect terminal capabilities and respect NO_COLOR.
    """

    def __init__(self, headers: list[str] | None = None) -> None:
        """Initialize table formatter.

        Args:
            headers: Column headers for the table.
        """
        self._headers = headers or []

    def _build_table(self, data: Any) -> Table:
        """Build a Rich Table from data.

        Args:
            data: Data to format (Pydantic model, dict, or other).

        Returns:
            Configured Rich Table.
        """
        if hasattr(data, "model_dump"):
            # Pydantic model - vertical key/value layout
            items = data.model_dump()
            table = Table(show_header=True, header_style="bold")
            table.add_column("Field", style="cyan")
            table.add_column("Value", style="green")
            for key, value in items.items():
                table.add_row(str(key), str(value))
        else:
            table = Table(show_header=True, header_style="bold")
            for header in self._headers:
                table.add_column(header)
            if isinstance(data, dict):
                table.add_row(
                    *[str(cast(dict[str, Any], data).get(h.lower(), "")) for h in self._headers]
                )
            else:
                table.add_row(str(data))
        return table

    def _build_list_table(self, data: list[Any], headers: list[str] | None = None) -> Table:
        """Build a Rich Table from a list of items.

        Args:
            data: List of items to format.
            headers: Optional headers override.

        Returns:
            Configured Rich Table.
        """
        hdrs = headers or self._headers
        table = Table(show_header=True, header_style="bold")
        for header in hdrs:
            table.add_column(header)

        for item in data:
            if hasattr(item, "model_dump"):
                row_data: dict[str, Any] = cast(dict[str, Any], item.model_dump())
                row = [str(row_data.get(h.lower().replace(" ", "_"), "")) for h in hdrs]
            elif isinstance(item, dict):
                row = [
                    str(cast(dict[str, Any], item).get(h.lower().replace(" ", "_"), ""))
                    for h in hdrs
                ]
            else:
                row = [str(item)]
            table.add_row(*row)

        return table

    def format(self, data: Any, console: Console | None = None) -> str:
        """Format a single item as a table string.

        Args:
            data: Data to format.
            console: Optional console for terminal-aware formatting.
                     If None, creates a console with no terminal (plain text).

        Returns:
            Formatted string.
        """
        table = self._build_table(data)
        if console is None:
            # No console provided - create one that produces plain text
            console = Console(force_terminal=False, no_color=True)
        with console.capture() as capture:
            console.print(table)
        return capture.get()

    def format_list(
        self,
        data: list[Any],
        headers: list[str] | None = None,
        console: Console | None = None,
    ) -> str:
        """Format a list of items as a table string.

        Args:
            data: List of items to format.
            headers: Optional headers for table output.
            console: Optional console for terminal-aware formatting.

        Returns:
            Formatted string.
        """
        table = self._build_list_table(data, headers)
        if console is None:
            console = Console(force_terminal=False, no_color=True)
        with console.capture() as capture:
            console.print(table)
        return capture.get()

    def print(self, data: Any, console: Console) -> None:
        """Print a single item directly to console.

        This is the preferred method for CLI output - allows Rich to
        auto-detect terminal capabilities and respect NO_COLOR.

        Args:
            data: Data to print.
            console: Console to print to.
        """
        table = self._build_table(data)
        console.print(table)

    def print_list(
        self,
        data: list[Any],
        console: Console,
        headers: list[str] | None = None,
    ) -> None:
        """Print a list of items directly to console.

        Args:
            data: List of items to print.
            console: Console to print to.
            headers: Optional headers override.
        """
        table = self._build_list_table(data, headers)
        console.print(table)


__all__ = ["TableFormatter"]
