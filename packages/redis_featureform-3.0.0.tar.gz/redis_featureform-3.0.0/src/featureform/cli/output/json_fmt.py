"""JSON output formatter."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any, cast

from featureform.cli.output.base import OutputFormatter

if TYPE_CHECKING:
    from rich.console import Console


class JSONFormatter(OutputFormatter):
    """Format output as JSON."""

    def __init__(self, indent: int = 2) -> None:
        """Initialize JSON formatter.

        Args:
            indent: Indentation level for pretty printing.
        """
        self._indent = indent

    def format(self, data: Any, console: Console | None = None) -> str:  # noqa: ARG002
        """Format a single item as JSON.

        Args:
            data: Data to format.
            console: Ignored for JSON (no terminal formatting needed).

        Returns:
            JSON formatted string.
        """
        output: dict[str, Any]
        if hasattr(data, "model_dump"):
            output = cast(dict[str, Any], data.model_dump(mode="json"))
        elif isinstance(data, dict):
            output = cast(dict[str, Any], data)
        else:
            output = {"value": str(data)}
        return json.dumps(output, indent=self._indent, default=str, ensure_ascii=False)

    def format_list(
        self,
        data: list[Any],
        headers: list[str] | None = None,  # noqa: ARG002
        console: Console | None = None,  # noqa: ARG002
    ) -> str:
        """Format a list of items as JSON.

        Args:
            data: List of items to format.
            headers: Ignored for JSON.
            console: Ignored for JSON (no terminal formatting needed).

        Returns:
            JSON formatted string.
        """
        items: list[dict[str, Any]] = []
        for item in data:
            if hasattr(item, "model_dump"):
                items.append(cast(dict[str, Any], item.model_dump(mode="json")))
            elif isinstance(item, dict):
                items.append(item)
            else:
                items.append({"value": str(item)})
        return json.dumps(items, indent=self._indent, default=str, ensure_ascii=False)


__all__ = ["JSONFormatter"]
