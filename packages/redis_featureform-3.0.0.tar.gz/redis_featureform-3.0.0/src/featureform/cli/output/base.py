"""Base output formatter."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from rich.console import Console


class OutputFormatter(ABC):
    """Abstract base class for output formatters."""

    @abstractmethod
    def format(self, data: Any, console: Console | None = None) -> str:
        """Format data for output.

        Args:
            data: Data to format.
            console: Optional console for terminal-aware formatting.
                     If None, produces plain text without ANSI codes.

        Returns:
            Formatted string.
        """
        ...

    @abstractmethod
    def format_list(
        self,
        data: list[Any],
        headers: list[str] | None = None,
        console: Console | None = None,
    ) -> str:
        """Format a list of items.

        Args:
            data: List of items to format.
            headers: Optional headers for table output.
            console: Optional console for terminal-aware formatting.

        Returns:
            Formatted string.
        """
        ...


__all__ = ["OutputFormatter"]
