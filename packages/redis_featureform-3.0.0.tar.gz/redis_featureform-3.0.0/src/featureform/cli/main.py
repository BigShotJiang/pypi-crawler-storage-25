"""Featureform CLI main entry point."""

import sys
from importlib import import_module
from pathlib import Path
from typing import Annotated, Literal, cast

import grpc
import httpx
import typer
from click.core import ParameterSource

import featureform
from featureform._internal.http import httpx_ssl_context
from featureform._internal.logging import LogLevel, configure_logging, get_logger
from featureform.cli import env
from featureform.cli.auth import YAMLProfileRepository
from featureform.cli.commands import (
    apply,
    audit,
    auth,
    catalog,
    config,
    dataframe,
    graph,
    machine_credential,
    provider,
    rbac,
    scheduler,
    secret_provider,
    workspace,
)
from featureform.cli.utils import CLIContext, OutputFormat, TransportFormat
from featureform.transport.grpc import TimeoutStubProxy, create_grpc_channel
from featureform.version import check_compatibility

_logger = get_logger("featureform.cli.main")


def _normalize_no_tls_target(target: str, transport: TransportFormat) -> str:
    """Normalize a target when --no-tls is set.

    For REST, bare host:port targets should behave like plain HTTP.
    Explicit HTTPS targets are incompatible with --no-tls for any transport.
    """
    if not target:
        return target
    if target.startswith("https://"):
        raise typer.BadParameter("--no-tls cannot be used with an explicit https:// target")
    if transport == TransportFormat.REST and "://" not in target:
        return f"http://{target}"
    return target


def _is_unreachable_error(error: Exception) -> bool:
    """Return True when the error indicates the server could not be reached."""
    if isinstance(error, httpx.ConnectError):
        return True
    if isinstance(error, grpc.RpcError):
        return error.code() in (
            grpc.StatusCode.UNAVAILABLE,
            grpc.StatusCode.DEADLINE_EXCEEDED,
        )
    return False


def _fetch_server_version(cli_ctx: CLIContext) -> dict[str, str]:
    """Fetch server version using the configured transport."""
    if cli_ctx.transport == TransportFormat.GRPC:
        return _fetch_server_version_grpc(cli_ctx)
    return _fetch_server_version_rest(cli_ctx)


def _fetch_server_version_rest(cli_ctx: CLIContext) -> dict[str, str]:
    """Fetch server version from the REST endpoint."""
    with httpx.Client(
        timeout=cli_ctx.timeout,
        verify=httpx_ssl_context(
            cli_ctx.verify_ssl,
            cli_ctx.ca_cert_path,
            cli_ctx.client_cert_path,
            cli_ctx.client_key_path,
        ),
    ) as client:
        response = client.get(f"{cli_ctx.get_rest_url().rstrip('/')}/version")
        response.raise_for_status()
        return cast(dict[str, str], response.json())


def _fetch_server_version_grpc(cli_ctx: CLIContext) -> dict[str, str]:
    """Fetch server version from the gRPC VersionService."""
    version_pb2 = import_module("featureform._generated.proto.featureform.v2.version_pb2")
    version_pb2_grpc = import_module("featureform._generated.proto.featureform.v2.version_pb2_grpc")

    channel = create_grpc_channel(
        cli_ctx.base_url,
        cli_ctx.verify_ssl,
        no_tls=cli_ctx.no_tls,
        ca_cert_path=cli_ctx.ca_cert_path,
        client_cert_path=cli_ctx.client_cert_path,
        client_key_path=cli_ctx.client_key_path,
    )

    try:
        stub = TimeoutStubProxy(
            version_pb2_grpc.VersionServiceStub(channel),
            default_timeout=cli_ctx.timeout,
            logger=_logger,
            stub_name="VersionServiceStub",
        )
        response = stub.GetVersion(version_pb2.GetVersionRequest())
    finally:
        channel.close()

    return {
        "version": response.version,
        "build_date": response.build_date,
        "git_commit": response.git_commit,
        "edition": response.edition,
    }


def _apply_profile_defaults(
    ctx: typer.Context,
    *,
    config_path: Path | None,
    server: str | None,
    grpc_server: str | None,
    transport: TransportFormat,
    issuer_url: str | None,
    no_tls: bool,
) -> tuple[str | None, str | None, TransportFormat, str | None, bool]:
    repo = YAMLProfileRepository(config_path)
    active = repo.get_active_profile()
    if active is None:
        return server, grpc_server, transport, issuer_url, no_tls

    if ctx.get_parameter_source("transport") == ParameterSource.DEFAULT:
        try:
            transport = TransportFormat(active.transport)
        except ValueError:
            transport = transport

    if ctx.get_parameter_source("server") == ParameterSource.DEFAULT and not server:
        server = active.server
    if ctx.get_parameter_source("grpc_server") == ParameterSource.DEFAULT and not grpc_server:
        grpc_server = active.server if transport == TransportFormat.GRPC else grpc_server
    if ctx.get_parameter_source("issuer_url") == ParameterSource.DEFAULT and not issuer_url:
        issuer_url = active.issuer_url
    if ctx.get_parameter_source("no_tls") == ParameterSource.DEFAULT and not no_tls:
        no_tls = active.no_tls

    return server, grpc_server, transport, issuer_url, no_tls


def _get_rich_markup_mode() -> Literal["rich"] | None:
    """Determine rich_markup_mode based on terminal and environment.

    Returns None (plain text) if:
    - NO_COLOR environment variable is set (https://no-color.org/)
    - TERM is "dumb"
    - stdout is not a TTY (e.g., piped output, CI/CD)

    Returns "rich" for interactive terminal use.
    """
    if env.no_color_enabled():
        return None
    if env.term_name() == "dumb":
        return None
    if not sys.stdout.isatty():
        return None
    return "rich"


app = typer.Typer(
    name="ff",
    help="Featureform CLI - Manage your feature store infrastructure",
    no_args_is_help=True,
    rich_markup_mode=_get_rich_markup_mode(),
)

# Add subcommands
app.add_typer(workspace.app, name="workspace")
app.add_typer(catalog.app, name="catalog")
app.add_typer(graph.app, name="graph")
app.add_typer(provider.app, name="provider")
app.add_typer(secret_provider.app, name="secret-provider")
app.add_typer(config.app, name="config")
app.add_typer(apply.app, name="apply")
app.add_typer(auth.app, name="auth")
app.add_typer(rbac.app, name="rbac")
app.add_typer(machine_credential.app, name="machine-credential")
app.add_typer(audit.app, name="audit")
app.add_typer(scheduler.app, name="scheduler")
app.add_typer(dataframe.app, name="dataframe")


@app.callback()
def main(
    ctx: typer.Context,
    server: Annotated[
        str | None,
        typer.Option(
            "--server", "-s", help="Server URL (REST or gRPC)", envvar="FEATUREFORM_BASE_URL"
        ),
    ] = None,
    grpc_server: Annotated[
        str | None,
        typer.Option(
            "--grpc-server",
            help="gRPC server URL (overrides --server when using --transport grpc)",
            envvar="FEATUREFORM_GRPC_URL",
        ),
    ] = None,
    output: Annotated[
        OutputFormat,
        typer.Option("--output", "-o", help="Output format", case_sensitive=False),
    ] = OutputFormat.TABLE,
    transport: Annotated[
        TransportFormat,
        typer.Option(
            "--transport",
            help="Transport protocol (rest or grpc)",
            case_sensitive=False,
            envvar="FEATUREFORM_TRANSPORT",
        ),
    ] = TransportFormat.REST,
    timeout: Annotated[
        float,
        typer.Option("--timeout", "-t", help="Request timeout in seconds"),
    ] = 30.0,
    token: Annotated[
        str | None,
        typer.Option("--token", help="Bearer token for authentication", envvar="FEATUREFORM_TOKEN"),
    ] = None,
    client_id: Annotated[
        str | None,
        typer.Option(
            "--client-id",
            help="OAuth2 client ID for service account auth",
            envvar="FEATUREFORM_CLIENT_ID",
        ),
    ] = None,
    client_secret: Annotated[
        str | None,
        typer.Option(
            "--client-secret",
            help="OAuth2 client secret",
            envvar="FEATUREFORM_CLIENT_SECRET",
        ),
    ] = None,
    issuer_url: Annotated[
        str | None,
        typer.Option("--issuer-url", help="OIDC issuer URL", envvar="FEATUREFORM_ISSUER_URL"),
    ] = None,
    insecure: Annotated[
        bool,
        typer.Option("--insecure", help="Disable SSL verification"),
    ] = False,
    ca_cert: Annotated[
        str | None,
        typer.Option(
            "--ca-cert",
            help="Path to CA certificate bundle for TLS verification",
            envvar="FEATUREFORM_CA_CERT",
        ),
    ] = None,
    client_cert: Annotated[
        str | None,
        typer.Option(
            "--client-cert",
            help="Path to client certificate for mTLS authentication",
            envvar="FEATUREFORM_CLIENT_CERT",
        ),
    ] = None,
    client_key: Annotated[
        str | None,
        typer.Option(
            "--client-key",
            help="Path to client private key for mTLS authentication",
            envvar="FEATUREFORM_CLIENT_KEY",
        ),
    ] = None,
    config_file: Annotated[
        Path | None,
        typer.Option("--config", help="Path to the CLI config file", envvar="FEATUREFORM_CONFIG"),
    ] = None,
    no_tls: Annotated[
        bool,
        typer.Option(
            "--no-tls",
            help="Disable TLS and use plaintext gRPC. Only applies to --transport grpc.",
        ),
    ] = False,
    no_color: Annotated[
        bool,
        typer.Option("--no-color", help="Disable colored output"),
    ] = False,
    verbose: Annotated[
        bool,
        typer.Option("--verbose", "-v", help="Enable verbose debug logging to stderr"),
    ] = False,
    skip_version_check: Annotated[
        bool,
        typer.Option(
            "--skip-version-check",
            help="Skip client-server version compatibility check",
            envvar="FEATUREFORM_SKIP_VERSION_CHECK",
        ),
    ] = False,
) -> None:
    """Featureform CLI - Manage your feature store infrastructure."""
    ctx.ensure_object(dict)
    if verbose:
        configure_logging(level=LogLevel.DEBUG)
    # Respect NO_COLOR environment variable (https://no-color.org/)
    effective_no_color = no_color or env.no_color_enabled()
    timeout_explicit = ctx.get_parameter_source("timeout") != ParameterSource.DEFAULT

    server, grpc_server, transport, issuer_url, no_tls = _apply_profile_defaults(
        ctx,
        config_path=config_file.resolve() if config_file is not None else None,
        server=server,
        grpc_server=grpc_server,
        transport=transport,
        issuer_url=issuer_url,
        no_tls=no_tls,
    )

    if no_tls:
        if server:
            server = _normalize_no_tls_target(server, transport)
        if grpc_server:
            grpc_server = _normalize_no_tls_target(grpc_server, TransportFormat.GRPC)

    # Determine the effective base URL based on transport.
    # For gRPC transport, use --grpc-server if provided, otherwise fall back to --server.
    # Keep the REST URL separately so transport-specific clients can opt into it when needed.
    rest_url: str | None = None
    if transport == TransportFormat.GRPC and grpc_server:
        effective_base_url = grpc_server
        # When using gRPC, --server provides the REST URL for scheduler commands
        rest_url = server
    else:
        effective_base_url = server or ""

    ctx.obj["context"] = CLIContext(
        base_url=effective_base_url,
        rest_url=rest_url,
        timeout=timeout,
        timeout_explicit=timeout_explicit,
        output_format=output,
        transport=transport,
        verify_ssl=not insecure,
        no_tls=no_tls,
        ca_cert_path=ca_cert,
        client_cert_path=client_cert,
        client_key_path=client_key,
        token=token,
        client_id=client_id,
        client_secret=client_secret,
        issuer_url=issuer_url,
        config_path=config_file.resolve() if config_file is not None else None,
        no_color=effective_no_color,
        skip_version_check=skip_version_check,
        verbose=verbose,
    )
    # Also store for legacy check_server_compatibility() function
    ctx.obj["skip_version_check"] = skip_version_check
    if verbose:
        _logger.debug(
            "cli_context_initialized",
            base_url=effective_base_url,
            rest_url=rest_url,
            transport=transport.value,
            timeout=timeout,
            timeout_explicit=timeout_explicit,
            config_path=str(config_file.resolve()) if config_file is not None else None,
        )


@app.command()
def version(
    ctx: typer.Context,
    client_only: Annotated[
        bool,
        typer.Option(
            "--client-only",
            "-c",
            help="Only show client version, skip server",
        ),
    ] = False,
) -> None:
    """Show the CLI and server version.

    By default, shows both client and server version when a server is configured.
    Use --client-only to show only the client version.
    """
    typer.echo(f"ff version {featureform.__version__}")

    if not client_only:
        cli_ctx: CLIContext | None = ctx.obj.get("context") if ctx.obj else None
        if cli_ctx is None or not cli_ctx.is_server_configured():
            typer.echo("\nServer: not configured (use --server flag or FEATUREFORM_BASE_URL)")
            return

        try:
            server_info = _fetch_server_version(cli_ctx)

            typer.echo("")
            typer.echo(f"Server version {server_info.get('version', 'unknown')}")
            typer.echo(f"Server Build Date: {server_info.get('build_date', 'unknown')}")
            typer.echo(f"Server Git Commit: {server_info.get('git_commit', 'unknown')}")

            # Check compatibility
            result = check_compatibility(
                featureform.__version__,
                server_info.get("version", "unknown"),
            )
            if result.has_warning():
                typer.echo(f"\n⚠️  {result.warning}")
            if not result.compatible:
                typer.echo(f"\n❌ {result.error}", err=True)

        except Exception as e:
            if _is_unreachable_error(e):
                typer.echo(f"\nServer: unreachable ({e})", err=True)
                return
            typer.echo(f"\nServer: error ({e})", err=True)


@app.command()
def ping(ctx: typer.Context) -> None:
    """Check whether the configured Featureform server is reachable and healthy."""
    cli_ctx: CLIContext | None = ctx.obj.get("context") if ctx.obj else None
    if cli_ctx is None or not cli_ctx.is_server_configured():
        typer.echo("Server: not configured (use --server flag or FEATUREFORM_BASE_URL)", err=True)
        raise typer.Exit(1)

    client = cli_ctx.get_client()
    try:
        result = client.ping()
    except Exception as error:
        typer.echo(f"Ping failed: {error}", err=True)
        raise typer.Exit(1) from error

    typer.echo(f"Transport: {result.transport}")
    typer.echo(f"Endpoint: {result.endpoint}")
    typer.echo(f"Diagnosis: {result.diagnosis}")
    if result.server_status:
        typer.echo(f"Server status: {result.server_status}")
    if result.detail:
        typer.echo(f"Detail: {result.detail}")

    if not result.ok:
        raise typer.Exit(1)


def get_context(ctx: typer.Context) -> CLIContext:
    """Get CLI context from typer context."""
    cli_ctx: CLIContext = ctx.obj["context"]
    return cli_ctx


def check_server_compatibility(ctx: typer.Context) -> None:
    """Check client-server version compatibility.

    Call this function from subcommands that connect to the server.
    It will print warnings or raise an error if versions are incompatible.

    If the server is not configured (no --server flag or FEATUREFORM_BASE_URL),
    this function silently returns without checking. The actual command will
    fail with a clear error when it tries to get_client().

    Args:
        ctx: Typer context containing CLI context and skip_version_check flag.

    Raises:
        typer.Exit: If versions are incompatible.
    """
    if ctx.obj is None:
        return

    skip_check = ctx.obj.get("skip_version_check", False)
    if skip_check:
        return

    cli_ctx: CLIContext | None = ctx.obj.get("context")
    if cli_ctx is None:
        return

    # Skip if server not configured - the command will fail with a clear error later
    if not cli_ctx.is_server_configured():
        return

    try:
        server_info = _fetch_server_version(cli_ctx)

        result = check_compatibility(
            featureform.__version__,
            server_info.get("version", "unknown"),
        )

        if result.has_warning():
            typer.echo(f"⚠️  Warning: {result.warning}", err=True)

        if not result.compatible:
            typer.echo(
                f"❌ Error: {result.error}\n"
                "Please upgrade your CLI: pip install --upgrade redis-featureform",
                err=True,
            )
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as error:
        if _is_unreachable_error(error) or isinstance(error, httpx.HTTPError):
            typer.echo("⚠️  Warning: Could not check server version compatibility", err=True)
            return
        typer.echo("⚠️  Warning: Could not check server version compatibility", err=True)


if __name__ == "__main__":
    app()
