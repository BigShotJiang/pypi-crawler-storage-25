"""Dataframe CLI commands."""

from __future__ import annotations

import csv
import io
import json
import sys
from enum import Enum
from typing import Annotated

import typer
from rich.console import Console
from rich.table import Table

from featureform.dataframe import DataFrameClient, QueryResult

app = typer.Typer(
    name="dataframe",
    help="Query datasets and output as dataframes",
)

console = Console()
err_console = Console(file=sys.stderr)


@app.callback()
def dataframe_callback() -> None:
    """Query datasets and output as dataframes."""
    pass


class DataFrameOutputFormat(str, Enum):
    """Output format for dataframe command."""

    TABLE = "table"
    JSON = "json"
    CSV = "csv"


def _output_table(result: QueryResult) -> None:
    """Output result as a rich table."""
    if result.is_empty():
        console.print("[dim]No data found[/dim]")
        return

    schema = result.schema
    if schema is None:
        console.print("[dim]No data found[/dim]")
        return

    table = Table(show_header=True, header_style="bold")
    for field in schema:
        table.add_column(field.name)

    for batch in result.to_arrow().to_batches():
        for row_idx in range(batch.num_rows):
            row = []
            for col_idx in range(batch.num_columns):
                val = batch.column(col_idx)[row_idx].as_py()
                row.append(str(val) if val is not None else "")
            table.add_row(*row)

    console.print(table)


def _output_json(result: QueryResult) -> None:
    """Output result as JSON lines."""
    if result.is_empty():
        return

    schema = result.schema
    if schema is None:
        return

    for batch in result.to_arrow().to_batches():
        for row_idx in range(batch.num_rows):
            row = {}
            for col_idx in range(batch.num_columns):
                col_name = schema.field(col_idx).name
                val = batch.column(col_idx)[row_idx].as_py()
                row[col_name] = val
            print(json.dumps(row))


def _output_csv(result: QueryResult) -> None:
    """Output result as CSV."""
    if result.is_empty():
        return

    schema = result.schema
    if schema is None:
        return

    output = io.StringIO()
    writer = csv.writer(output)

    # Write header
    headers = [field.name for field in schema]
    writer.writerow(headers)

    # Write rows
    for batch in result.to_arrow().to_batches():
        for row_idx in range(batch.num_rows):
            row = []
            for col_idx in range(batch.num_columns):
                val = batch.column(col_idx)[row_idx].as_py()
                row.append(val if val is not None else "")
            writer.writerow(row)

    print(output.getvalue(), end="")


@app.command()
def query(
    ctx: typer.Context,
    dataset: Annotated[str, typer.Argument(help="Dataset name to query")],
    workspace: Annotated[
        str,
        typer.Option("--workspace", "-w", help="Workspace name (required)"),
    ],
    server: Annotated[
        str,
        typer.Option("--server", "-s", help="Flight server address"),
    ] = "localhost:9090",
    kind: Annotated[
        str,
        typer.Option("--kind", help="Query target kind: dataset, training_set, or feature_view"),
    ] = "dataset",
    columns: Annotated[
        str | None,
        typer.Option("--columns", "-c", help="Columns to select (comma-separated)"),
    ] = None,
    filter_expr: Annotated[
        str | None,
        typer.Option("--filter", "-f", help="Filter expression"),
    ] = None,
    limit: Annotated[
        int | None,
        typer.Option("--limit", "-l", help="Maximum rows to return"),
    ] = None,
    output: Annotated[
        DataFrameOutputFormat,
        typer.Option("--output", "-o", help="Output format"),
    ] = DataFrameOutputFormat.TABLE,
    insecure: Annotated[
        bool,
        typer.Option("--insecure", help="Disable TLS (for development/testing)"),
    ] = False,
) -> None:
    """Query a dataset and output as a dataframe."""
    if not workspace:
        err_console.print("[red]Error:[/red] --workspace is required")
        raise typer.Exit(1)

    column_list = columns.split(",") if columns else None
    token = None
    if ctx.obj and "context" in ctx.obj:
        token = ctx.obj["context"].get_auth_token()

    try:
        client = DataFrameClient(server, insecure=insecure, token=token)
        result = client.query(
            workspace=workspace,
            dataset=dataset,
            kind=kind,
            columns=column_list,
            filter=filter_expr,
            limit=limit,
        )

        if output == DataFrameOutputFormat.TABLE:
            _output_table(result)
        elif output == DataFrameOutputFormat.JSON:
            _output_json(result)
        elif output == DataFrameOutputFormat.CSV:
            _output_csv(result)

        client.close()
    except Exception as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from e
