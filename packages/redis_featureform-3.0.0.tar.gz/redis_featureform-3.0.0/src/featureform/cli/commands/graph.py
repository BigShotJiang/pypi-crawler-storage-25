"""Graph query CLI commands."""

from __future__ import annotations

from typing import Annotated, Any

import typer

from featureform.cli.utils import CLIContext, OutputFormat

app = typer.Typer(name="graph", help="Graph query and resource browsing", no_args_is_help=True)
workspace_app = typer.Typer(
    name="workspace", help="Workspace-level graph views", no_args_is_help=True
)
feature_app = typer.Typer(name="feature", help="Feature graph queries", no_args_is_help=True)
dataset_app = typer.Typer(name="dataset", help="Dataset graph queries", no_args_is_help=True)
entity_app = typer.Typer(name="entity", help="Entity graph queries", no_args_is_help=True)
training_set_app = typer.Typer(
    name="training-set", help="Training set graph queries", no_args_is_help=True
)
label_app = typer.Typer(name="label", help="Label graph queries", no_args_is_help=True)
feature_view_app = typer.Typer(
    name="feature-view", help="Feature view graph queries", no_args_is_help=True
)
provider_app = typer.Typer(name="provider", help="Provider graph queries", no_args_is_help=True)
version_app = typer.Typer(name="version", help="Version graph queries", no_args_is_help=True)

app.add_typer(workspace_app, name="workspace")
app.add_typer(feature_app, name="feature")
app.add_typer(dataset_app, name="dataset")
app.add_typer(entity_app, name="entity")
app.add_typer(training_set_app, name="training-set")
app.add_typer(label_app, name="label")
app.add_typer(feature_view_app, name="feature-view")
app.add_typer(provider_app, name="provider")
app.add_typer(version_app, name="version")


RESOURCE_HEADERS = ["name", "kind", "variant", "provider", "entity", "source_dataset"]
REF_HEADERS = ["name", "kind"]
PIPELINE_HEADERS = ["name", "kind", "depth", "query"]
VERSION_HEADERS = ["version", "principal_type", "principal_id", "message", "timestamp"]
CHANGE_HEADERS = ["name", "kind", "change_type"]


def _get_context(ctx: typer.Context) -> CLIContext:
    cli_ctx: CLIContext = ctx.obj["context"]
    return cli_ctx


def _graph_client(ctx: typer.Context, workspace: str) -> tuple[CLIContext, Any]:
    cli_ctx = _get_context(ctx)
    return cli_ctx, cli_ctx.get_client().graph(workspace)


def _print(cli_ctx: CLIContext, value: Any, headers: list[str], *, is_list: bool = False) -> None:
    if is_list and not value:
        if cli_ctx.output_format in (OutputFormat.JSON, OutputFormat.YAML):
            cli_ctx.print_formatted([], headers, is_list=True)
        else:
            cli_ctx.console.print("No results found")
        return
    cli_ctx.print_formatted(value, headers, is_list=is_list)


@workspace_app.command("overview")
def workspace_overview(
    ctx: typer.Context,
    workspace: Annotated[str, typer.Option("--workspace", "-w", help="Workspace name or ID")],
) -> None:
    """Get workspace overview."""
    cli_ctx, graph = _graph_client(ctx, workspace)
    try:
        _print(cli_ctx, graph.overview(), ["workspace_name", "version"])
    except Exception as err:
        cli_ctx.err_console.print(f"[red]Error:[/red] {err}")
        raise typer.Exit(1) from err
    finally:
        cli_ctx.close()


@workspace_app.command("stats")
def workspace_stats(
    ctx: typer.Context,
    workspace: Annotated[str, typer.Option("--workspace", "-w", help="Workspace name or ID")],
    version: Annotated[
        int | None, typer.Option("--version", help="Committed graph version")
    ] = None,
) -> None:
    """Get workspace stats."""
    cli_ctx, graph = _graph_client(ctx, workspace)
    try:
        _print(
            cli_ctx,
            graph.stats(version=version),
            [
                "version",
                "features",
                "datasets",
                "entities",
                "training_sets",
                "labels",
                "feature_views",
            ],
        )
    except Exception as err:
        cli_ctx.err_console.print(f"[red]Error:[/red] {err}")
        raise typer.Exit(1) from err
    finally:
        cli_ctx.close()


def _register_resource_commands(
    subapp: typer.Typer,
    *,
    resource_name: str,
    list_method: str,
    get_method: str,
    has_relationships: bool,
    list_filters: list[tuple[str, str]],
) -> None:
    @subapp.command("list")
    def list_command(
        ctx: typer.Context,
        workspace: Annotated[str, typer.Option("--workspace", "-w", help="Workspace name or ID")],
        version: Annotated[
            int | None, typer.Option("--version", help="Committed graph version")
        ] = None,
        limit: Annotated[
            int | None, typer.Option("--limit", help="Maximum number of results")
        ] = None,
        offset: Annotated[int | None, typer.Option("--offset", help="Pagination offset")] = None,
        entity: Annotated[str | None, typer.Option("--entity", help="Filter by entity")] = None,
        provider: Annotated[
            str | None, typer.Option("--provider", help="Filter by provider")
        ] = None,
        source_dataset: Annotated[
            str | None, typer.Option("--source-dataset", help="Filter by source dataset")
        ] = None,
        label: Annotated[str | None, typer.Option("--label", help="Filter by label")] = None,
        includes_feature: Annotated[
            str | None, typer.Option("--includes-feature", help="Filter by included feature")
        ] = None,
        inference_store: Annotated[
            str | None, typer.Option("--inference-store", help="Filter by inference store")
        ] = None,
        materialization_engine: Annotated[
            str | None,
            typer.Option("--materialization-engine", help="Filter by materialization engine"),
        ] = None,
        spark_provider: Annotated[
            str | None, typer.Option("--spark-provider", help="Filter by spark provider")
        ] = None,
        name_contains: Annotated[
            str | None, typer.Option("--name-contains", help="Filter by partial name")
        ] = None,
    ) -> None:
        """List resources of this type."""
        cli_ctx, graph = _graph_client(ctx, workspace)
        filters = {
            "version": version,
            "limit": limit,
            "offset": offset,
            "entity": entity,
            "provider": provider,
            "source_dataset": source_dataset,
            "label": label,
            "includes_feature": includes_feature,
            "inference_store": inference_store,
            "materialization_engine": materialization_engine,
            "spark_provider": spark_provider,
            "name_contains": name_contains,
        }
        allowed_filters = {param: filters[param] for param, _ in list_filters}
        try:
            result = getattr(graph, list_method)(**allowed_filters)
            _print(cli_ctx, result.resources, RESOURCE_HEADERS, is_list=True)
        except Exception as err:
            cli_ctx.err_console.print(f"[red]Error:[/red] {err}")
            raise typer.Exit(1) from err
        finally:
            cli_ctx.close()

    @subapp.command("get")
    def get_command(
        ctx: typer.Context,
        name: Annotated[str, typer.Argument(help="Resource name")],
        workspace: Annotated[str, typer.Option("--workspace", "-w", help="Workspace name or ID")],
        version: Annotated[
            int | None, typer.Option("--version", help="Committed graph version")
        ] = None,
    ) -> None:
        """Get a single resource."""
        cli_ctx, graph = _graph_client(ctx, workspace)
        try:
            result = getattr(graph, get_method)(name, version=version)
            _print(cli_ctx, result, ["summary", "sources", "consumers", "runtime_preview"])
        except Exception as err:
            cli_ctx.err_console.print(f"[red]Error:[/red] {err}")
            raise typer.Exit(1) from err
        finally:
            cli_ctx.close()

    _ = (list_command, get_command)

    if not has_relationships:
        return

    @subapp.command("sources")
    def sources_command(
        ctx: typer.Context,
        name: Annotated[str, typer.Argument(help="Resource name")],
        workspace: Annotated[str, typer.Option("--workspace", "-w", help="Workspace name or ID")],
        depth: Annotated[int | None, typer.Option("--depth", help="Traversal depth")] = None,
        version: Annotated[
            int | None, typer.Option("--version", help="Committed graph version")
        ] = None,
    ) -> None:
        """Get upstream sources."""
        cli_ctx, graph = _graph_client(ctx, workspace)
        try:
            result = getattr(graph, f"get_{resource_name}_sources")(
                name, depth=depth, version=version
            )
            _print(cli_ctx, result.related, REF_HEADERS, is_list=True)
        except Exception as err:
            cli_ctx.err_console.print(f"[red]Error:[/red] {err}")
            raise typer.Exit(1) from err
        finally:
            cli_ctx.close()

    @subapp.command("consumers")
    def consumers_command(
        ctx: typer.Context,
        name: Annotated[str, typer.Argument(help="Resource name")],
        workspace: Annotated[str, typer.Option("--workspace", "-w", help="Workspace name or ID")],
        depth: Annotated[int | None, typer.Option("--depth", help="Traversal depth")] = None,
        version: Annotated[
            int | None, typer.Option("--version", help="Committed graph version")
        ] = None,
    ) -> None:
        """Get downstream consumers."""
        cli_ctx, graph = _graph_client(ctx, workspace)
        try:
            result = getattr(graph, f"get_{resource_name}_consumers")(
                name, depth=depth, version=version
            )
            _print(cli_ctx, result.related, REF_HEADERS, is_list=True)
        except Exception as err:
            cli_ctx.err_console.print(f"[red]Error:[/red] {err}")
            raise typer.Exit(1) from err
        finally:
            cli_ctx.close()

    @subapp.command("pipeline")
    def pipeline_command(
        ctx: typer.Context,
        name: Annotated[str, typer.Argument(help="Resource name")],
        workspace: Annotated[str, typer.Option("--workspace", "-w", help="Workspace name or ID")],
        version: Annotated[
            int | None, typer.Option("--version", help="Committed graph version")
        ] = None,
    ) -> None:
        """Get ordered pipeline."""
        cli_ctx, graph = _graph_client(ctx, workspace)
        try:
            result = getattr(graph, f"get_{resource_name}_pipeline")(name, version=version)
            _print(cli_ctx, result.steps, PIPELINE_HEADERS, is_list=True)
        except Exception as err:
            cli_ctx.err_console.print(f"[red]Error:[/red] {err}")
            raise typer.Exit(1) from err
        finally:
            cli_ctx.close()

    _ = (sources_command, consumers_command, pipeline_command)


_register_resource_commands(
    feature_app,
    resource_name="feature",
    list_method="list_features",
    get_method="get_feature",
    has_relationships=True,
    list_filters=[
        ("version", ""),
        ("limit", ""),
        ("offset", ""),
        ("entity", ""),
        ("provider", ""),
        ("source_dataset", ""),
        ("name_contains", ""),
    ],
)
_register_resource_commands(
    dataset_app,
    resource_name="dataset",
    list_method="list_datasets",
    get_method="get_dataset",
    has_relationships=True,
    list_filters=[
        ("version", ""),
        ("limit", ""),
        ("offset", ""),
        ("provider", ""),
        ("name_contains", ""),
    ],
)
_register_resource_commands(
    entity_app,
    resource_name="entity",
    list_method="list_entities",
    get_method="get_entity",
    has_relationships=False,
    list_filters=[("version", ""), ("limit", ""), ("offset", ""), ("name_contains", "")],
)
_register_resource_commands(
    training_set_app,
    resource_name="training_set",
    list_method="list_training_sets",
    get_method="get_training_set",
    has_relationships=True,
    list_filters=[
        ("version", ""),
        ("limit", ""),
        ("offset", ""),
        ("provider", ""),
        ("label", ""),
        ("includes_feature", ""),
        ("name_contains", ""),
    ],
)
_register_resource_commands(
    label_app,
    resource_name="label",
    list_method="list_labels",
    get_method="get_label",
    has_relationships=True,
    list_filters=[
        ("version", ""),
        ("limit", ""),
        ("offset", ""),
        ("provider", ""),
        ("entity", ""),
        ("source_dataset", ""),
        ("name_contains", ""),
    ],
)
_register_resource_commands(
    feature_view_app,
    resource_name="feature_view",
    list_method="list_feature_views",
    get_method="get_feature_view",
    has_relationships=True,
    list_filters=[
        ("version", ""),
        ("limit", ""),
        ("offset", ""),
        ("entity", ""),
        ("includes_feature", ""),
        ("inference_store", ""),
        ("materialization_engine", ""),
        ("spark_provider", ""),
        ("name_contains", ""),
    ],
)


@provider_app.command("resources")
def provider_resources(
    ctx: typer.Context,
    provider: Annotated[str, typer.Argument(help="Provider name")],
    workspace: Annotated[str, typer.Option("--workspace", "-w", help="Workspace name or ID")],
    version: Annotated[
        int | None, typer.Option("--version", help="Committed graph version")
    ] = None,
) -> None:
    """List resources referencing a provider."""
    cli_ctx, graph = _graph_client(ctx, workspace)
    try:
        result = graph.get_resources_by_provider(provider, version=version)
        _print(cli_ctx, result.resources, RESOURCE_HEADERS, is_list=True)
    except Exception as err:
        cli_ctx.err_console.print(f"[red]Error:[/red] {err}")
        raise typer.Exit(1) from err
    finally:
        cli_ctx.close()


@app.command("search")
def search(
    ctx: typer.Context,
    query: Annotated[str, typer.Argument(help="Search query")],
    workspace: Annotated[str, typer.Option("--workspace", "-w", help="Workspace name or ID")],
    version: Annotated[
        int | None, typer.Option("--version", help="Committed graph version")
    ] = None,
    limit: Annotated[int | None, typer.Option("--limit", help="Maximum number of results")] = None,
    offset: Annotated[int | None, typer.Option("--offset", help="Pagination offset")] = None,
) -> None:
    """Search resources by name."""
    cli_ctx, graph = _graph_client(ctx, workspace)
    try:
        result = graph.search(query, version=version, limit=limit, offset=offset)
        _print(cli_ctx, result.resources, RESOURCE_HEADERS, is_list=True)
    except Exception as err:
        cli_ctx.err_console.print(f"[red]Error:[/red] {err}")
        raise typer.Exit(1) from err
    finally:
        cli_ctx.close()


@app.command("lineage")
def lineage(
    ctx: typer.Context,
    name: Annotated[str, typer.Argument(help="Resource name")],
    workspace: Annotated[str, typer.Option("--workspace", "-w", help="Workspace name or ID")],
    upstream_depth: Annotated[int | None, typer.Option("--upstream-depth")] = None,
    downstream_depth: Annotated[int | None, typer.Option("--downstream-depth")] = None,
    version: Annotated[
        int | None, typer.Option("--version", help="Committed graph version")
    ] = None,
) -> None:
    """Get lineage graph for a resource."""
    cli_ctx, graph = _graph_client(ctx, workspace)
    try:
        result = graph.lineage(
            name,
            upstream_depth=upstream_depth,
            downstream_depth=downstream_depth,
            version=version,
        )
        _print(cli_ctx, result.nodes, REF_HEADERS, is_list=True)
    except Exception as err:
        cli_ctx.err_console.print(f"[red]Error:[/red] {err}")
        raise typer.Exit(1) from err
    finally:
        cli_ctx.close()


@app.command("impact")
def impact(
    ctx: typer.Context,
    names: Annotated[list[str], typer.Argument(help="One or more resource names")],
    workspace: Annotated[str, typer.Option("--workspace", "-w", help="Workspace name or ID")],
    depth: Annotated[int | None, typer.Option("--depth", help="Traversal depth")] = None,
    version: Annotated[
        int | None, typer.Option("--version", help="Committed graph version")
    ] = None,
) -> None:
    """Get downstream impact graph for one or more resources."""
    cli_ctx, graph = _graph_client(ctx, workspace)
    try:
        result = graph.impact(names, depth=depth, version=version)
        _print(cli_ctx, result.nodes, REF_HEADERS, is_list=True)
    except Exception as err:
        cli_ctx.err_console.print(f"[red]Error:[/red] {err}")
        raise typer.Exit(1) from err
    finally:
        cli_ctx.close()


@app.command("history")
def history(
    ctx: typer.Context,
    name: Annotated[str, typer.Argument(help="Resource name")],
    workspace: Annotated[str, typer.Option("--workspace", "-w", help="Workspace name or ID")],
) -> None:
    """Get resource history."""
    cli_ctx, graph = _graph_client(ctx, workspace)
    try:
        result = graph.resource_history(name)
        _print(cli_ctx, result.entries, VERSION_HEADERS, is_list=True)
    except Exception as err:
        cli_ctx.err_console.print(f"[red]Error:[/red] {err}")
        raise typer.Exit(1) from err
    finally:
        cli_ctx.close()


@version_app.command("list")
def version_list(
    ctx: typer.Context,
    workspace: Annotated[str, typer.Option("--workspace", "-w", help="Workspace name or ID")],
) -> None:
    """List committed versions."""
    cli_ctx, graph = _graph_client(ctx, workspace)
    try:
        _print(cli_ctx, graph.list_versions(), VERSION_HEADERS, is_list=True)
    except Exception as err:
        cli_ctx.err_console.print(f"[red]Error:[/red] {err}")
        raise typer.Exit(1) from err
    finally:
        cli_ctx.close()


@version_app.command("get")
def version_get(
    ctx: typer.Context,
    version: Annotated[int, typer.Argument(help="Committed version number")],
    workspace: Annotated[str, typer.Option("--workspace", "-w", help="Workspace name or ID")],
) -> None:
    """Get a single committed version."""
    cli_ctx, graph = _graph_client(ctx, workspace)
    try:
        _print(cli_ctx, graph.get_version(version), VERSION_HEADERS)
    except Exception as err:
        cli_ctx.err_console.print(f"[red]Error:[/red] {err}")
        raise typer.Exit(1) from err
    finally:
        cli_ctx.close()


@version_app.command("diff")
def version_diff(
    ctx: typer.Context,
    from_version: Annotated[int, typer.Argument(help="Base version")],
    to_version: Annotated[int, typer.Argument(help="Target version")],
    workspace: Annotated[str, typer.Option("--workspace", "-w", help="Workspace name or ID")],
) -> None:
    """Diff two committed versions."""
    cli_ctx, graph = _graph_client(ctx, workspace)
    try:
        result = graph.diff_versions(from_version, to_version)
        changes = [
            *result.added,
            *result.modified,
            *result.deleted,
        ]
        _print(cli_ctx, changes, CHANGE_HEADERS, is_list=True)
    except Exception as err:
        cli_ctx.err_console.print(f"[red]Error:[/red] {err}")
        raise typer.Exit(1) from err
    finally:
        cli_ctx.close()
