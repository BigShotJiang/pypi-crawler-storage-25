"""Scheduler CLI commands."""

from __future__ import annotations

import sys
from typing import Annotated, Any
from uuid import UUID

import httpx
import typer
from rich.console import Console

from featureform.cli.commands._common import resolve_workspace_id
from featureform.cli.errors import (
    EXIT_ERROR,
    EXIT_INVALID_ARGS,
    EXIT_SUCCESS,
    format_connection_error,
    format_timeout_error,
)
from featureform.cli.output import JSONFormatter, OutputFormatter, TableFormatter, YAMLFormatter
from featureform.cli.scheduler_client import SchedulerClient, SchedulerClientError
from featureform.cli.utils import CLIContext, OutputFormat

app = typer.Typer(
    name="scheduler",
    help="Scheduler management commands",
    no_args_is_help=True,
)

queue_app = typer.Typer(name="queue", help="Queue operations", no_args_is_help=True)
groups_app = typer.Typer(name="groups", help="Scheduler group operations", no_args_is_help=True)
job_app = typer.Typer(name="job", help="Job operations", no_args_is_help=True)
task_app = typer.Typer(name="task", help="Task operations", no_args_is_help=True)
schedule_app = typer.Typer(name="schedule", help="Scheduled job operations", no_args_is_help=True)
external_execution_app = typer.Typer(
    name="external-execution",
    help="External execution operations",
    no_args_is_help=True,
)

app.add_typer(queue_app, name="queue")
app.add_typer(groups_app, name="groups")
app.add_typer(job_app, name="job")
app.add_typer(task_app, name="task")
app.add_typer(schedule_app, name="schedule")
app.add_typer(external_execution_app, name="external-execution")

console = Console()
err_console = Console(file=sys.stderr)


# Pagination limits - keep in sync with Go constants in internal/scheduler/types/pagination.go
DEFAULT_JOBS_LIMIT = 50
MAX_JOBS_LIMIT = 1000
DEFAULT_LOGS_LIMIT = 1000
MAX_LOGS_LIMIT = 10000
DEFAULT_SCHEDULES_LIMIT = 50
MAX_SCHEDULES_LIMIT = 1000

# Table headers
QUEUE_HEADERS = ["NAME", "MODE", "PENDING", "RUNNING", "COMPLETED", "FAILED"]
GROUP_HEADERS = [
    "ID",
    "NAME",
    "KIND",
    "STATUS",
    "TOTAL JOBS",
    "PENDING JOBS",
    "RUNNING JOBS",
    "COMPLETED JOBS",
    "FAILED JOBS",
    "CANCELED JOBS",
]
JOB_HEADERS = ["ID", "QUEUE", "NAME", "STATUS", "CREATED"]
TASK_HEADERS = ["ID", "JOB", "TASK DEF", "STATUS", "CRITICAL", "STARTED", "COMPLETED"]
SCHEDULE_HEADERS = ["ID", "NAME", "QUEUE", "SCHEDULE", "ENABLED", "NEXT RUN"]
STATS_HEADERS = ["QUEUE", "PENDING", "RUNNING", "COMPLETED", "FAILED"]
DETAIL_HEADERS = ["FIELD", "VALUE"]
EXTERNAL_EXECUTION_TABLE_HEADERS = [
    "EXECUTION ID",
    "TASK ID",
    "PROVIDER",
    "PROVIDER EXEC ID",
    "STATUS",
    "SUBMITTED",
    "COMPLETED",
]
JOB_TASK_HEADERS = ["TASK ID", "TASK DEF", "STATUS", "STARTED", "COMPLETED", "EXTERNAL EXECUTION"]


def _get_context(ctx: typer.Context) -> CLIContext:
    """Get CLI context."""
    cli_ctx: CLIContext = ctx.obj["context"]
    return cli_ctx


def _print_output(cli_ctx: CLIContext, output: str) -> None:
    """Print output using plain print for structured formats, console for table."""
    if cli_ctx.output_format in (OutputFormat.JSON, OutputFormat.YAML):
        print(output)
    else:
        console.print(output)


def _format_output(
    ctx: CLIContext, data: Any, headers: list[str] | None = None, is_list: bool = False
) -> str:
    """Format output based on context settings."""
    formatter: OutputFormatter
    if ctx.output_format == OutputFormat.JSON:
        formatter = JSONFormatter()
    elif ctx.output_format == OutputFormat.YAML:
        formatter = YAMLFormatter()
    else:
        formatter = TableFormatter(headers or [])

    if is_list:
        return formatter.format_list(data if isinstance(data, list) else [data], headers)
    return formatter.format(data)


def _handle_request_error(err: Exception, url: str = "", timeout: float = 30.0) -> None:
    """Handle request errors with actionable messages."""
    if isinstance(err, httpx.ConnectError):
        msg, exit_code = format_connection_error(url, err)
        err_console.print(f"[red]Error:[/red] {msg}")
        raise typer.Exit(exit_code) from err
    if isinstance(err, httpx.TimeoutException):
        msg, exit_code = format_timeout_error(timeout)
        err_console.print(f"[red]Error:[/red] {msg}")
        raise typer.Exit(exit_code) from err
    err_console.print(f"[red]Error:[/red] {err}")
    raise typer.Exit(EXIT_ERROR) from err


def _format_detail_rows(data: dict[str, Any]) -> list[dict[str, str]]:
    """Render a dict as FIELD/VALUE rows for table output."""
    rows: list[dict[str, str]] = []
    for key, value in data.items():
        if value in ("", None, [], {}):
            continue
        label = key.replace("_", " ").upper()
        if isinstance(value, (dict, list)):
            rendered = (
                YAMLFormatter().format(value)
                if isinstance(value, dict)
                else YAMLFormatter().format_list(value)
            )
            rows.append({"field": label, "value": rendered.strip()})
            continue
        rows.append({"field": label, "value": str(value)})
    return rows


def _external_execution_summary_text(execution: dict[str, Any] | None) -> str:
    """Format a compact external execution summary for table output."""
    if not execution:
        return ""

    lines = [
        f"id={execution.get('id', '')}",
        f"provider={execution.get('provider_id', '') or '-'}",
        f"provider_exec_id={execution.get('external_id', '') or '-'}",
        f"status={execution.get('status', '') or '-'}",
    ]
    if execution.get("external_url"):
        lines.append(f"url={execution['external_url']}")
    if execution.get("completed_at"):
        lines.append(f"completed={execution['completed_at']}")
    return "\n".join(lines)


def _print_task_detail(cli_ctx: CLIContext, task: dict[str, Any]) -> None:
    """Print a task detail view with an attached external execution block."""
    detail = dict(task)
    external_execution = detail.pop("external_execution", None)
    rows = _format_detail_rows(detail)
    if external_execution:
        rows.append(
            {
                "field": "EXTERNAL EXECUTION",
                "value": _external_execution_summary_text(external_execution),
            }
        )
    output = _format_output(cli_ctx, rows, DETAIL_HEADERS, is_list=True)
    _print_output(cli_ctx, output)


def _print_job_detail(cli_ctx: CLIContext, job: dict[str, Any]) -> None:
    """Print a job detail view with a separate task table."""
    detail = dict(job)
    tasks = detail.pop("tasks", [])
    detail_output = _format_output(
        cli_ctx, _format_detail_rows(detail), DETAIL_HEADERS, is_list=True
    )
    _print_output(cli_ctx, detail_output)
    if not tasks:
        return

    formatted_tasks = [
        {
            "task_id": task.get("id", ""),
            "task_def": task.get("task_def_id", ""),
            "status": task.get("status", ""),
            "started": task.get("started_at", ""),
            "completed": task.get("completed_at", ""),
            "external_execution": _external_execution_summary_text(task.get("external_execution")),
        }
        for task in tasks
    ]
    _print_output(cli_ctx, _format_output(cli_ctx, formatted_tasks, JOB_TASK_HEADERS, is_list=True))


def _resolve_workspace_option(cli_ctx: CLIContext, workspace: str) -> str:
    """Resolve a workspace name or UUID to a UUID string."""
    try:
        return str(UUID(workspace))
    except ValueError:
        client = cli_ctx.get_client()
        return str(resolve_workspace_id(client, workspace))


# -----------------------------------------------------------------------------
# Group Commands
# -----------------------------------------------------------------------------


@groups_app.command("list")
def group_list(
    ctx: typer.Context,
    workspace: Annotated[str, typer.Option("--workspace", help="Workspace ID or name")],
    status: Annotated[
        list[str] | None,
        typer.Option(
            "--status",
            "-s",
            help="Filter by derived status (PENDING, RUNNING, CANCELING, SUCCEEDED, FAILED, CANCELED)",
        ),
    ] = None,
    limit: Annotated[int, typer.Option("--limit", help="Maximum number of groups to return")] = 0,
    offset: Annotated[int, typer.Option("--offset", help="Result offset")] = 0,
) -> None:
    """List scheduler groups for a workspace."""
    cli_ctx = _get_context(ctx)
    try:
        client = SchedulerClient(cli_ctx)
        groups = client.list_groups(
            workspace,
            statuses=status,
            limit=limit,
            offset=offset,
        )

        if not groups:
            if cli_ctx.output_format in (OutputFormat.JSON, OutputFormat.YAML):
                _print_output(cli_ctx, _format_output(cli_ctx, [], GROUP_HEADERS, is_list=True))
            else:
                console.print("No groups found")
            return

        output = _format_output(cli_ctx, groups, GROUP_HEADERS, is_list=True)
        _print_output(cli_ctx, output)
    except SchedulerClientError as e:
        err_console.print(f"[red]Error:[/red] {e.message}")
        raise typer.Exit(e.code) from e
    except typer.Exit:
        raise
    except Exception as e:
        _handle_request_error(e)


@groups_app.command("get")
def group_get(
    ctx: typer.Context,
    group_id: Annotated[str, typer.Argument(help="Scheduler group ID")],
) -> None:
    """Get a scheduler group by ID."""
    cli_ctx = _get_context(ctx)
    try:
        client = SchedulerClient(cli_ctx)
        group = client.get_group(group_id)
        if cli_ctx.output_format in (OutputFormat.JSON, OutputFormat.YAML):
            _print_output(cli_ctx, _format_output(cli_ctx, group))
            return
        _print_output(
            cli_ctx,
            _format_output(cli_ctx, _format_detail_rows(group), DETAIL_HEADERS, is_list=True),
        )
    except SchedulerClientError as e:
        err_console.print(f"[red]Error:[/red] {e.message}")
        raise typer.Exit(e.code) from e
    except typer.Exit:
        raise
    except Exception as e:
        _handle_request_error(e)


@groups_app.command("jobs")
def group_jobs(
    ctx: typer.Context,
    group_id: Annotated[str, typer.Argument(help="Scheduler group ID")],
    limit: Annotated[int, typer.Option("--limit", help="Maximum number of jobs to return")] = 0,
    offset: Annotated[int, typer.Option("--offset", help="Result offset")] = 0,
) -> None:
    """List jobs belonging to a scheduler group."""
    cli_ctx = _get_context(ctx)
    try:
        client = SchedulerClient(cli_ctx)
        jobs = client.list_group_jobs(group_id, limit=limit, offset=offset)
        if not jobs:
            if cli_ctx.output_format in (OutputFormat.JSON, OutputFormat.YAML):
                _print_output(cli_ctx, _format_output(cli_ctx, [], JOB_HEADERS, is_list=True))
            else:
                console.print("No jobs found")
            return
        _print_output(cli_ctx, _format_output(cli_ctx, jobs, JOB_HEADERS, is_list=True))
    except SchedulerClientError as e:
        err_console.print(f"[red]Error:[/red] {e.message}")
        raise typer.Exit(e.code) from e
    except typer.Exit:
        raise
    except Exception as e:
        _handle_request_error(e)


@groups_app.command("cancel")
def group_cancel(
    ctx: typer.Context,
    group_id: Annotated[str, typer.Argument(help="Scheduler group ID")],
) -> None:
    """Cancel a scheduler group by ID."""
    cli_ctx = _get_context(ctx)
    try:
        client = SchedulerClient(cli_ctx)
        group = client.cancel_group(group_id)
        if cli_ctx.output_format in (OutputFormat.JSON, OutputFormat.YAML):
            _print_output(cli_ctx, _format_output(cli_ctx, group))
            return
        _print_output(
            cli_ctx,
            _format_output(cli_ctx, _format_detail_rows(group), DETAIL_HEADERS, is_list=True),
        )
    except SchedulerClientError as e:
        err_console.print(f"[red]Error:[/red] {e.message}")
        raise typer.Exit(e.code) from e
    except typer.Exit:
        raise
    except Exception as e:
        _handle_request_error(e)


# -----------------------------------------------------------------------------
# Queue Commands
# -----------------------------------------------------------------------------


@queue_app.command("list")
def queue_list(
    ctx: typer.Context,
    workspace: Annotated[str, typer.Option("--workspace", help="Workspace ID or name")],
) -> None:
    """List all queues with their statistics."""
    cli_ctx = _get_context(ctx)
    try:
        client = SchedulerClient(cli_ctx)
        workspace_id = _resolve_workspace_option(cli_ctx, workspace)
        queues = client.list_queues(workspace_id)

        if not queues:
            if cli_ctx.output_format in (OutputFormat.JSON, OutputFormat.YAML):
                output = _format_output(cli_ctx, [], QUEUE_HEADERS, is_list=True)
                _print_output(cli_ctx, output)
            else:
                console.print("No queues found")
            return

        output = _format_output(cli_ctx, queues, QUEUE_HEADERS, is_list=True)
        _print_output(cli_ctx, output)
    except SchedulerClientError as e:
        err_console.print(f"[red]Error:[/red] {e.message}")
        raise typer.Exit(e.code) from e
    except typer.Exit:
        raise
    except Exception as e:
        _handle_request_error(e)


@queue_app.command("get")
def queue_get(
    ctx: typer.Context,
    name: Annotated[str, typer.Argument(help="Queue name")],
    workspace: Annotated[str, typer.Option("--workspace", help="Workspace ID or name")],
) -> None:
    """Get a queue by name."""
    cli_ctx = _get_context(ctx)
    try:
        client = SchedulerClient(cli_ctx)
        workspace_id = _resolve_workspace_option(cli_ctx, workspace)
        queue = client.get_queue(workspace_id, name)
        output = _format_output(cli_ctx, queue, QUEUE_HEADERS)
        _print_output(cli_ctx, output)
    except SchedulerClientError as e:
        err_console.print(f"[red]Error:[/red] {e.message}")
        raise typer.Exit(e.code) from e
    except typer.Exit:
        raise
    except Exception as e:
        _handle_request_error(e)


@queue_app.command("create")
def queue_create(
    ctx: typer.Context,
    name: Annotated[str, typer.Argument(help="Queue name")],
    workspace: Annotated[str, typer.Option("--workspace", help="Workspace ID or name")],
    mode: Annotated[
        str,
        typer.Option("--mode", "-m", help="Execution mode (SERIALIZED or CONCURRENT)"),
    ] = "CONCURRENT",
) -> None:
    """Create a new queue."""
    cli_ctx = _get_context(ctx)
    mode_upper = mode.upper()
    if mode_upper not in ("SERIALIZED", "CONCURRENT"):
        err_console.print("[red]Error:[/red] Mode must be SERIALIZED or CONCURRENT")
        raise typer.Exit(EXIT_INVALID_ARGS)

    try:
        client = SchedulerClient(cli_ctx)
        workspace_id = _resolve_workspace_option(cli_ctx, workspace)
        client.create_queue(workspace_id, name, mode_upper)
        console.print(f"Queue {name} created")
    except SchedulerClientError as e:
        err_console.print(f"[red]Error:[/red] {e.message}")
        raise typer.Exit(e.code) from e
    except typer.Exit:
        raise
    except Exception as e:
        _handle_request_error(e)


# -----------------------------------------------------------------------------
# Job Commands
# -----------------------------------------------------------------------------


@job_app.command("list")
def job_list(
    ctx: typer.Context,
    workspace: Annotated[str, typer.Option("--workspace", help="Workspace ID or name")],
    queue: Annotated[str | None, typer.Option("--queue", "-q", help="Filter by queue name")] = None,
    status: Annotated[
        list[str] | None,
        typer.Option(
            "--status",
            "-s",
            help="Filter by status (PENDING, RUNNING, COMPLETED, FAILED, CANCELED)",
        ),
    ] = None,
    limit: Annotated[
        int, typer.Option("--limit", "-l", help="Maximum number of jobs to return")
    ] = DEFAULT_JOBS_LIMIT,
    offset: Annotated[int, typer.Option("--offset", help="Offset for pagination")] = 0,
) -> None:
    """List jobs with optional filters."""
    cli_ctx = _get_context(ctx)
    try:
        client = SchedulerClient(cli_ctx)
        workspace_id = _resolve_workspace_option(cli_ctx, workspace)
        data = client.list_jobs(
            workspace=workspace_id,
            queue_name=queue,
            statuses=status,
            limit=limit,
            offset=offset,
        )

        jobs = data.get("jobs", [])
        if not jobs:
            if cli_ctx.output_format in (OutputFormat.JSON, OutputFormat.YAML):
                output = _format_output(cli_ctx, [], JOB_HEADERS, is_list=True)
                _print_output(cli_ctx, output)
            else:
                console.print("No jobs found")
            return

        formatted_jobs = [
            {
                "id": j.get("id", ""),
                "queue": j.get("queue_name", ""),
                "name": j.get("name", ""),
                "status": j.get("status", ""),
                "created": j.get("created_at", ""),
            }
            for j in jobs
        ]
        output = _format_output(cli_ctx, formatted_jobs, JOB_HEADERS, is_list=True)
        _print_output(cli_ctx, output)

        if data.get("has_more"):
            console.print(f"[dim]Showing {len(jobs)} of {data.get('total_count', '?')} jobs[/dim]")
    except SchedulerClientError as e:
        err_console.print(f"[red]Error:[/red] {e.message}")
        raise typer.Exit(e.code) from e
    except typer.Exit:
        raise
    except Exception as e:
        _handle_request_error(e)


@job_app.command("get")
def job_get(
    ctx: typer.Context,
    job_id: Annotated[str, typer.Argument(help="Job ID")],
) -> None:
    """Get a job by ID."""
    cli_ctx = _get_context(ctx)
    try:
        client = SchedulerClient(cli_ctx)
        job = client.get_job(job_id)
        if cli_ctx.output_format in (OutputFormat.JSON, OutputFormat.YAML):
            _print_output(cli_ctx, _format_output(cli_ctx, job))
        else:
            _print_job_detail(cli_ctx, job)
    except SchedulerClientError as e:
        err_console.print(f"[red]Error:[/red] {e.message}")
        raise typer.Exit(e.code) from e
    except typer.Exit:
        raise
    except Exception as e:
        _handle_request_error(e)


@job_app.command("cancel")
def job_cancel(
    ctx: typer.Context,
    job_id: Annotated[str, typer.Argument(help="Job ID")],
) -> None:
    """Cancel a pending or running job."""
    cli_ctx = _get_context(ctx)
    try:
        client = SchedulerClient(cli_ctx)
        job = client.cancel_job(job_id)
        if job.get("status") == "RUNNING" and job.get("cancel_requested_at"):
            console.print(f"Job {job_id} cancel requested")
        else:
            console.print(f"Job {job_id} canceled")
    except SchedulerClientError as e:
        err_console.print(f"[red]Error:[/red] {e.message}")
        raise typer.Exit(e.code) from e
    except typer.Exit:
        raise
    except Exception as e:
        _handle_request_error(e)


@job_app.command("retry")
def job_retry(
    ctx: typer.Context,
    job_id: Annotated[str, typer.Argument(help="Job ID")],
) -> None:
    """Retry a failed or canceled job in place."""
    cli_ctx = _get_context(ctx)
    try:
        client = SchedulerClient(cli_ctx)
        client.retry_job(job_id)
        console.print(f"Job {job_id} retry initiated")
    except SchedulerClientError as e:
        err_console.print(f"[red]Error:[/red] {e.message}")
        raise typer.Exit(e.code) from e
    except typer.Exit:
        raise
    except Exception as e:
        _handle_request_error(e)


@job_app.command("logs")
def job_logs(
    ctx: typer.Context,
    job_id: Annotated[str, typer.Argument(help="Job ID")],
    limit: Annotated[
        int, typer.Option("--limit", "-l", help="Maximum number of log entries")
    ] = DEFAULT_LOGS_LIMIT,
    level: Annotated[
        str | None, typer.Option("--level", help="Minimum log level (DEBUG, INFO, WARN, ERROR)")
    ] = None,
) -> None:
    """Get logs for a job."""
    cli_ctx = _get_context(ctx)
    try:
        client = SchedulerClient(cli_ctx)
        logs = client.get_job_logs(job_id, limit=limit, level=level)
        _output_logs(cli_ctx, logs)
    except SchedulerClientError as e:
        err_console.print(f"[red]Error:[/red] {e.message}")
        raise typer.Exit(e.code) from e
    except typer.Exit:
        raise
    except Exception as e:
        _handle_request_error(e)


def _output_logs(cli_ctx: CLIContext, logs: list[dict[str, Any]]) -> None:
    """Output log entries."""
    if cli_ctx.output_format == OutputFormat.JSON:
        json_formatter = JSONFormatter()
        print(json_formatter.format_list(logs))
    elif cli_ctx.output_format == OutputFormat.YAML:
        yaml_formatter = YAMLFormatter()
        print(yaml_formatter.format_list(logs))
    else:
        if not logs:
            console.print("No log entries")
            return
        for log in logs:
            ts = log.get("timestamp", "")
            lvl = log.get("level", "INFO")
            task = log.get("task_id", "")[:8] if log.get("task_id") else ""
            msg = log.get("message", "")
            console.print(f"{ts} [{lvl}] [{task}] {msg}")


# -----------------------------------------------------------------------------
# Task Commands
# -----------------------------------------------------------------------------


@task_app.command("list")
def task_list(
    ctx: typer.Context,
    job_id: Annotated[str, typer.Option("--job-id", help="Job ID whose tasks should be listed")],
) -> None:
    """List tasks for a job."""
    cli_ctx = _get_context(ctx)
    try:
        client = SchedulerClient(cli_ctx)
        tasks = client.list_tasks_for_job(job_id)

        if not tasks:
            if cli_ctx.output_format in (OutputFormat.JSON, OutputFormat.YAML):
                output = _format_output(cli_ctx, [], TASK_HEADERS, is_list=True)
                _print_output(cli_ctx, output)
            else:
                console.print("No tasks found")
            return

        if cli_ctx.output_format in (OutputFormat.JSON, OutputFormat.YAML):
            output = _format_output(cli_ctx, tasks, TASK_HEADERS, is_list=True)
            _print_output(cli_ctx, output)
            return

        formatted_tasks = [
            {
                "id": task.get("id", ""),
                "job": task.get("job_id", ""),
                "task_def": task.get("task_def_id", ""),
                "status": task.get("status", ""),
                "critical": task.get("critical", False),
                "started": task.get("started_at", ""),
                "completed": task.get("completed_at", ""),
            }
            for task in tasks
        ]
        output = _format_output(cli_ctx, formatted_tasks, TASK_HEADERS, is_list=True)
        _print_output(cli_ctx, output)
    except SchedulerClientError as e:
        err_console.print(f"[red]Error:[/red] {e.message}")
        raise typer.Exit(e.code) from e
    except typer.Exit:
        raise
    except Exception as e:
        _handle_request_error(e)


@task_app.command("get")
def task_get(
    ctx: typer.Context,
    task_id: Annotated[str, typer.Argument(help="Task ID")],
) -> None:
    """Get a task by ID."""
    cli_ctx = _get_context(ctx)
    try:
        client = SchedulerClient(cli_ctx)
        task = client.get_task(task_id)
        if cli_ctx.output_format in (OutputFormat.JSON, OutputFormat.YAML):
            _print_output(cli_ctx, _format_output(cli_ctx, task))
        else:
            _print_task_detail(cli_ctx, task)
    except SchedulerClientError as e:
        err_console.print(f"[red]Error:[/red] {e.message}")
        raise typer.Exit(e.code) from e
    except typer.Exit:
        raise
    except Exception as e:
        _handle_request_error(e)


@task_app.command("logs")
def task_logs(
    ctx: typer.Context,
    task_id: Annotated[str, typer.Argument(help="Task ID")],
    limit: Annotated[
        int, typer.Option("--limit", "-l", help="Maximum number of log entries")
    ] = DEFAULT_LOGS_LIMIT,
    level: Annotated[
        str | None, typer.Option("--level", help="Minimum log level (DEBUG, INFO, WARN, ERROR)")
    ] = None,
) -> None:
    """Get logs for a task."""
    cli_ctx = _get_context(ctx)
    try:
        client = SchedulerClient(cli_ctx)
        logs = client.get_task_logs(task_id, limit=limit, level=level)
        _output_logs(cli_ctx, logs)
    except SchedulerClientError as e:
        err_console.print(f"[red]Error:[/red] {e.message}")
        raise typer.Exit(e.code) from e
    except typer.Exit:
        raise
    except Exception as e:
        _handle_request_error(e)


# -----------------------------------------------------------------------------
# Schedule Commands
# -----------------------------------------------------------------------------


@schedule_app.command("list")
def schedule_list(
    ctx: typer.Context,
    workspace: Annotated[str, typer.Option("--workspace", help="Workspace ID or name")],
    queue: Annotated[str | None, typer.Option("--queue", "-q", help="Filter by queue name")] = None,
    enabled_only: Annotated[
        bool, typer.Option("--enabled-only", help="Show only enabled schedules")
    ] = False,
    limit: Annotated[
        int, typer.Option("--limit", "-l", help="Maximum number of schedules")
    ] = DEFAULT_SCHEDULES_LIMIT,
    offset: Annotated[int, typer.Option("--offset", help="Offset for pagination")] = 0,
) -> None:
    """List scheduled jobs."""
    cli_ctx = _get_context(ctx)
    try:
        client = SchedulerClient(cli_ctx)
        workspace_id = _resolve_workspace_option(cli_ctx, workspace)
        data = client.list_scheduled_jobs(
            workspace=workspace_id,
            queue_name=queue,
            enabled_only=enabled_only,
            limit=limit,
            offset=offset,
        )

        schedules = data.get("scheduled_jobs", [])
        if not schedules:
            if cli_ctx.output_format in (OutputFormat.JSON, OutputFormat.YAML):
                output = _format_output(cli_ctx, [], SCHEDULE_HEADERS, is_list=True)
                _print_output(cli_ctx, output)
            else:
                console.print("No scheduled jobs found")
            return

        formatted = [
            {
                "id": s.get("id", ""),
                "name": s.get("name", ""),
                "queue": s.get("queue_name", ""),
                "schedule": s.get("cron_expression", ""),
                "enabled": "Yes" if s.get("enabled") else "No",
                "next_run": s.get("next_run_at", ""),
            }
            for s in schedules
        ]
        output = _format_output(cli_ctx, formatted, SCHEDULE_HEADERS, is_list=True)
        _print_output(cli_ctx, output)
    except SchedulerClientError as e:
        err_console.print(f"[red]Error:[/red] {e.message}")
        raise typer.Exit(e.code) from e
    except typer.Exit:
        raise
    except Exception as e:
        _handle_request_error(e)


@schedule_app.command("get")
def schedule_get(
    ctx: typer.Context,
    id_or_name: Annotated[str, typer.Argument(help="Schedule ID or name")],
) -> None:
    """Get a scheduled job by ID or name."""
    cli_ctx = _get_context(ctx)
    try:
        client = SchedulerClient(cli_ctx)
        sj = client.get_scheduled_job(id_or_name)
        output = _format_output(cli_ctx, sj)
        _print_output(cli_ctx, output)
    except SchedulerClientError as e:
        err_console.print(f"[red]Error:[/red] {e.message}")
        raise typer.Exit(e.code) from e
    except typer.Exit:
        raise
    except Exception as e:
        _handle_request_error(e)


@schedule_app.command("pause")
def schedule_pause(
    ctx: typer.Context,
    id_or_name: Annotated[str, typer.Argument(help="Schedule ID or name")],
) -> None:
    """Pause a scheduled job."""
    cli_ctx = _get_context(ctx)
    try:
        client = SchedulerClient(cli_ctx)
        client.pause_scheduled_job(id_or_name)
        console.print(f"Scheduled job {id_or_name} paused")
    except SchedulerClientError as e:
        err_console.print(f"[red]Error:[/red] {e.message}")
        raise typer.Exit(e.code) from e
    except typer.Exit:
        raise
    except Exception as e:
        _handle_request_error(e)


@schedule_app.command("resume")
def schedule_resume(
    ctx: typer.Context,
    id_or_name: Annotated[str, typer.Argument(help="Schedule ID or name")],
) -> None:
    """Resume a paused scheduled job."""
    cli_ctx = _get_context(ctx)
    try:
        client = SchedulerClient(cli_ctx)
        client.resume_scheduled_job(id_or_name)
        console.print(f"Scheduled job {id_or_name} resumed")
    except SchedulerClientError as e:
        err_console.print(f"[red]Error:[/red] {e.message}")
        raise typer.Exit(e.code) from e
    except typer.Exit:
        raise
    except Exception as e:
        _handle_request_error(e)


@schedule_app.command("trigger")
def schedule_trigger(
    ctx: typer.Context,
    id_or_name: Annotated[str, typer.Argument(help="Schedule ID or name")],
) -> None:
    """Trigger an immediate execution of a scheduled job."""
    cli_ctx = _get_context(ctx)
    try:
        client = SchedulerClient(cli_ctx)
        data = client.trigger_scheduled_job(id_or_name)
        job_id = data.get("job_id", data.get("id", "unknown"))
        console.print(f"Triggered scheduled job {id_or_name}, created job {job_id}")
    except SchedulerClientError as e:
        err_console.print(f"[red]Error:[/red] {e.message}")
        raise typer.Exit(e.code) from e
    except typer.Exit:
        raise
    except Exception as e:
        _handle_request_error(e)


@schedule_app.command("delete")
def schedule_delete(
    ctx: typer.Context,
    id_or_name: Annotated[str, typer.Argument(help="Schedule ID or name")],
    force: Annotated[bool, typer.Option("--force", "-f", help="Skip confirmation")] = False,
) -> None:
    """Delete a scheduled job."""
    cli_ctx = _get_context(ctx)

    if not force:
        confirm = typer.confirm(f"Are you sure you want to delete scheduled job {id_or_name}?")
        if not confirm:
            console.print("Cancelled")
            raise typer.Exit(EXIT_SUCCESS)

    try:
        client = SchedulerClient(cli_ctx)
        client.delete_scheduled_job(id_or_name)
        console.print(f"Scheduled job {id_or_name} deleted")
    except SchedulerClientError as e:
        err_console.print(f"[red]Error:[/red] {e.message}")
        raise typer.Exit(e.code) from e
    except typer.Exit:
        raise
    except Exception as e:
        _handle_request_error(e)


# -----------------------------------------------------------------------------
# External Execution Commands
# -----------------------------------------------------------------------------


@external_execution_app.command("list")
def external_execution_list(
    ctx: typer.Context,
    workspace: Annotated[str, typer.Option("--workspace", help="Workspace ID or name")],
    provider_id: Annotated[
        str | None, typer.Option("--provider-id", help="Filter by provider ID")
    ] = None,
    job_id: Annotated[
        str | None, typer.Option("--job-id", help="Filter by scheduler job ID")
    ] = None,
    task_id: Annotated[
        str | None, typer.Option("--task-id", help="Filter by scheduler task ID")
    ] = None,
    status: Annotated[
        str | None,
        typer.Option(
            "--status",
            help="Filter by status (PENDING, RUNNING, SUCCEEDED, FAILED, CANCELED)",
        ),
    ] = None,
    external_id: Annotated[
        str | None, typer.Option("--external-id", help="Filter by provider execution ID")
    ] = None,
    limit: Annotated[
        int, typer.Option("--limit", "-l", help="Maximum number of executions to return")
    ] = DEFAULT_JOBS_LIMIT,
) -> None:
    """List external executions."""
    cli_ctx = _get_context(ctx)
    try:
        client = SchedulerClient(cli_ctx)
        workspace_id = _resolve_workspace_option(cli_ctx, workspace)
        data = client.list_external_executions(
            workspace_id,
            provider_id=provider_id,
            job_id=job_id,
            task_id=task_id,
            status=status,
            external_id=external_id,
            limit=limit,
        )

        executions = data.get("external_executions", [])
        if not executions:
            if cli_ctx.output_format in (OutputFormat.JSON, OutputFormat.YAML):
                empty_payload = {
                    "external_executions": [],
                    "total_count": data.get("total_count", 0),
                    "has_more": data.get("has_more", False),
                }
                _print_output(cli_ctx, _format_output(cli_ctx, empty_payload))
            else:
                console.print("No external executions found")
            return

        if cli_ctx.output_format in (OutputFormat.JSON, OutputFormat.YAML):
            _print_output(cli_ctx, _format_output(cli_ctx, data))
            return

        formatted = [
            {
                "execution_id": execution.get("id", ""),
                "task_id": execution.get("scheduler_task_id", ""),
                "provider": execution.get("provider_id", ""),
                "provider_exec_id": execution.get("external_id", ""),
                "status": execution.get("status", ""),
                "submitted": execution.get("submitted_at", ""),
                "completed": execution.get("completed_at", ""),
            }
            for execution in executions
        ]
        output = _format_output(
            cli_ctx,
            formatted,
            EXTERNAL_EXECUTION_TABLE_HEADERS,
            is_list=True,
        )
        _print_output(cli_ctx, output)

        if data.get("has_more"):
            console.print(
                f"[dim]Showing {len(executions)} of {data.get('total_count', '?')} external executions[/dim]"
            )
    except SchedulerClientError as e:
        err_console.print(f"[red]Error:[/red] {e.message}")
        raise typer.Exit(e.code) from e
    except typer.Exit:
        raise
    except Exception as e:
        _handle_request_error(e)


@external_execution_app.command("get")
def external_execution_get(
    ctx: typer.Context,
    execution_id: Annotated[str, typer.Argument(help="External execution ID")],
) -> None:
    """Get an external execution by ID."""
    cli_ctx = _get_context(ctx)
    try:
        client = SchedulerClient(cli_ctx)
        execution = client.get_external_execution(execution_id)
        if cli_ctx.output_format in (OutputFormat.JSON, OutputFormat.YAML):
            _print_output(cli_ctx, _format_output(cli_ctx, execution))
        else:
            _print_output(
                cli_ctx,
                _format_output(
                    cli_ctx, _format_detail_rows(execution), DETAIL_HEADERS, is_list=True
                ),
            )
    except SchedulerClientError as e:
        err_console.print(f"[red]Error:[/red] {e.message}")
        raise typer.Exit(e.code) from e
    except typer.Exit:
        raise
    except Exception as e:
        _handle_request_error(e)


# -----------------------------------------------------------------------------
# Stats Command
# -----------------------------------------------------------------------------


@app.command("stats")
def stats(
    ctx: typer.Context,
    workspace: Annotated[str, typer.Option("--workspace", help="Workspace ID or name")],
    queue: Annotated[
        str | None, typer.Option("--queue", "-q", help="Filter stats by queue name")
    ] = None,
) -> None:
    """View scheduler statistics."""
    cli_ctx = _get_context(ctx)
    try:
        client = SchedulerClient(cli_ctx)
        workspace_id = _resolve_workspace_option(cli_ctx, workspace)
        data = client.get_stats(workspace=workspace_id, queue_name=queue)

        if cli_ctx.output_format == OutputFormat.JSON:
            json_formatter = JSONFormatter()
            print(json_formatter.format(data))
            return
        if cli_ctx.output_format == OutputFormat.YAML:
            yaml_formatter = YAMLFormatter()
            print(yaml_formatter.format(data))
            return

        # Table output
        overall = data.get("overall", {})
        by_queue = data.get("by_queue", [])

        if queue:
            # Single queue stats
            console.print(f"[bold]Stats for queue: {queue}[/bold]")
            console.print(f"  Pending:   {overall.get('pending_jobs', 0)}")
            console.print(f"  Running:   {overall.get('running_jobs', 0)}")
            completed = overall.get("completed_jobs", 0) + overall.get(
                "completed_with_warnings_jobs", 0
            )
            console.print(f"  Completed: {completed}")
            console.print(f"  Failed:    {overall.get('failed_jobs', 0)}")
        else:
            # Overall and per-queue stats
            console.print("[bold]Overall Stats[/bold]")
            console.print(f"  Pending:   {overall.get('pending_jobs', 0)}")
            console.print(f"  Running:   {overall.get('running_jobs', 0)}")
            completed = overall.get("completed_jobs", 0) + overall.get(
                "completed_with_warnings_jobs", 0
            )
            console.print(f"  Completed: {completed}")
            console.print(f"  Failed:    {overall.get('failed_jobs', 0)}")

            if by_queue:
                console.print("\n[bold]Per-Queue Stats[/bold]")
                formatted_queues: list[dict[str, object]] = []
                for q in by_queue:
                    qs = q.get("stats", {})
                    completed_q = qs.get("completed_jobs", 0) + qs.get(
                        "completed_with_warnings_jobs", 0
                    )
                    formatted_queues.append(
                        {
                            "queue": q.get("queue", {}).get("name", ""),
                            "pending": qs.get("pending_jobs", 0),
                            "running": qs.get("running_jobs", 0),
                            "completed": completed_q,
                            "failed": qs.get("failed_jobs", 0),
                        }
                    )
                output = _format_output(cli_ctx, formatted_queues, STATS_HEADERS, is_list=True)
                console.print(output)
    except SchedulerClientError as e:
        err_console.print(f"[red]Error:[/red] {e.message}")
        raise typer.Exit(e.code) from e
    except typer.Exit:
        raise
    except Exception as e:
        _handle_request_error(e)
