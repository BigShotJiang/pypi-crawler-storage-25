"""Apply CLI command."""

from __future__ import annotations

import importlib.util
import re
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Annotated, Any, cast
from uuid import UUID

import typer
from rich.console import Console
from rich.markup import escape

from featureform._apply_wait import (
    ApplyJobStateTimeoutError,
    ApplyJobVisibilityTimeoutError,
    ApplyWaitError,
    ApplyWaitTimeoutError,
    WaitTarget,
    wait_for_job,
)
from featureform.cli.commands._common import resolve_workspace_id
from featureform.cli.errors import EXIT_ERROR, EXIT_TIMEOUT
from featureform.cli.output import JSONFormatter
from featureform.cli.scheduler_client import (
    NotFoundError,
    SchedulerApplyJobFailedError,
    SchedulerApplyTimeoutError,
    SchedulerClient,
    SchedulerClientError,
)
from featureform.cli.utils import CLIContext, OutputFormat
from featureform.transport import TransportType
from featureform.transport.grpc import resource_pb2  # pyright: ignore[reportUnknownMemberType]

app = typer.Typer(
    name="apply",
    help="Apply resources from a Python entry file or package directory to a workspace",
)

console = Console()
err_console = Console(file=sys.stderr)


@dataclass(frozen=True)
class ApplyFlagInputs:
    merge: bool
    update: bool
    full_rematerialize: bool
    plan: bool


@dataclass(frozen=True)
class ApplySemantics:
    strategy: str
    execution_mode: str


class ApplyFlagSemantics:
    """Resolve user-facing apply flags into request semantics."""

    @staticmethod
    def resolve(flags: ApplyFlagInputs) -> ApplySemantics:
        execution_mode_selectors = sum((flags.update, flags.full_rematerialize))
        if execution_mode_selectors > 1:
            raise ValueError("only one of --update or --full-rematerialize may be specified")

        strategy = "MERGE" if flags.merge else "APPLY"
        execution_mode = "NORMAL"
        if flags.update:
            execution_mode = "UPDATE"
        if flags.full_rematerialize:
            execution_mode = "FULL_REMATERIALIZE"
        return ApplySemantics(strategy=strategy, execution_mode=execution_mode)


class ResourceFileParameterError(typer.BadParameter):
    """Structured CLI parameter error for apply resource loading."""

    def __init__(self, message: str, *, code: str) -> None:
        super().__init__(message)
        self.code = code


@dataclass(frozen=True)
class ResourceModuleLoadTarget:
    """Resolved module execution target for apply resource loading."""

    source_path: Path
    module_name: str
    sys_path_entry: Path
    package_prefix: str | None = None
    submodule_search_locations: list[str] | None = None


def _package_components_for_file(file_path: Path) -> tuple[list[str], Path]:
    """Return package components for a file and the sys.path entry that exposes them."""
    components: list[str] = []
    current = file_path.parent
    while (current / "__init__.py").is_file():
        components.append(current.name)
        current = current.parent
    components.reverse()
    return components, current


def _package_components_for_directory(directory_path: Path) -> tuple[list[str], Path]:
    """Return package components for a package directory and its sys.path entry."""
    components: list[str] = []
    current = directory_path
    while (current / "__init__.py").is_file():
        components.append(current.name)
        current = current.parent
    components.reverse()
    return components, current


def _resolve_module_load_target(file_path: Path) -> ResourceModuleLoadTarget:
    """Resolve a file or package directory to a module execution target."""
    resolved_path = file_path.resolve()

    if resolved_path.is_dir():
        init_path = resolved_path / "__init__.py"
        if not init_path.is_file():
            raise ResourceFileParameterError(f"Not a file: {file_path}", code="not_a_file")

        package_components, sys_path_entry = _package_components_for_directory(resolved_path)
        if not package_components:
            raise ResourceFileParameterError(
                f"Could not resolve package from directory: {file_path}",
                code="module_load_failed",
            )
        module_name = ".".join(package_components)
        return ResourceModuleLoadTarget(
            source_path=init_path,
            module_name=module_name,
            sys_path_entry=sys_path_entry,
            package_prefix=package_components[0],
            submodule_search_locations=[str(resolved_path)],
        )

    if not resolved_path.is_file():
        raise ResourceFileParameterError(f"Not a file: {file_path}", code="not_a_file")

    package_components, sys_path_entry = _package_components_for_file(resolved_path)
    if not package_components:
        return ResourceModuleLoadTarget(
            source_path=resolved_path,
            module_name="resources_module",
            sys_path_entry=sys_path_entry,
        )

    if resolved_path.name == "__init__.py":
        module_name = ".".join(package_components)
        return ResourceModuleLoadTarget(
            source_path=resolved_path,
            module_name=module_name,
            sys_path_entry=sys_path_entry,
            package_prefix=package_components[0],
            submodule_search_locations=[str(resolved_path.parent)],
        )

    module_name = ".".join([*package_components, resolved_path.stem])
    return ResourceModuleLoadTarget(
        source_path=resolved_path,
        module_name=module_name,
        sys_path_entry=sys_path_entry,
        package_prefix=package_components[0],
    )


def _get_context(ctx: typer.Context) -> CLIContext:
    """Get CLI context."""
    cli_ctx: CLIContext = ctx.obj["context"]
    return cli_ctx


def _camel_to_snake(name: str) -> str:
    """Convert CamelCase to snake_case."""
    # Insert underscore before uppercase letters and convert to lowercase
    s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", name)
    return re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1).lower()


def load_resources_from_file(
    file_path: Path,
    *,
    client: Any | None = None,
    workspace_id: UUID | None = None,
) -> list[Any]:
    """Load resources from a Python file or package directory.

    Supports two patterns:
    1. Explicit `resources = [...]` list in the file
    2. Auto-registration via ResourceRegistry (new pattern with decorators)

    The function first tries to use the explicit resources list.
    If not found, it falls back to the ResourceRegistry.

    Args:
        file_path: Path to the Python file or package directory containing resources.

    Returns:
        List of resources.

    Raises:
        typer.BadParameter: If file not found or no resources defined.
    """
    from featureform._apply_context import apply_resolution_context
    from featureform.resources.base import ResourceRegistry

    if not file_path.exists():
        raise ResourceFileParameterError(f"File not found: {file_path}", code="file_not_found")

    # Clear the registry before loading to ensure clean state
    ResourceRegistry.clear()

    load_target = _resolve_module_load_target(file_path)

    # Load the module from the resolved target.
    spec = importlib.util.spec_from_file_location(
        load_target.module_name,
        load_target.source_path,
        submodule_search_locations=load_target.submodule_search_locations,
    )
    if spec is None or spec.loader is None:
        raise ResourceFileParameterError(
            f"Could not load module from: {file_path}",
            code="module_load_failed",
        )

    module = importlib.util.module_from_spec(spec)
    previous_modules: dict[str, Any] = {}
    if load_target.package_prefix is not None:
        prefix = f"{load_target.package_prefix}."
        for name in list(sys.modules):
            if name == load_target.package_prefix or name.startswith(prefix):
                previous_modules[name] = sys.modules.pop(name)
    elif load_target.module_name in sys.modules:
        previous_modules[load_target.module_name] = sys.modules.pop(load_target.module_name)

    original_sys_path = list(sys.path)
    sys.modules[load_target.module_name] = module
    sys.path.insert(0, str(load_target.sys_path_entry))
    try:
        with apply_resolution_context(client=client, workspace_id=workspace_id):
            spec.loader.exec_module(module)
    finally:
        sys.path[:] = original_sys_path
        if load_target.package_prefix is not None:
            prefix = f"{load_target.package_prefix}."
            for name in list(sys.modules):
                if name == load_target.package_prefix or name.startswith(prefix):
                    sys.modules.pop(name, None)
            sys.modules.update(previous_modules)
        elif load_target.module_name in previous_modules:
            sys.modules[load_target.module_name] = previous_modules[load_target.module_name]
        else:
            sys.modules.pop(load_target.module_name, None)

    # First, try to use explicit resources list
    if hasattr(module, "resources"):
        resources = module.resources
        if not isinstance(resources, list):
            raise ResourceFileParameterError(
                f"'resources' in {file_path} must be a list, got {type(resources).__name__}",
                code="resources_not_list",
            )
        return list(resources)

    # Fall back to ResourceRegistry (auto-registration pattern)
    registered_resources = ResourceRegistry.get_all()
    if registered_resources:
        return list(registered_resources)

    # No resources found in either pattern
    raise ResourceFileParameterError(
        f"No resources found in {file_path}. "
        "Either define a 'resources' list or use auto-registering resource classes "
        "(e.g., ff.Entity, ff.PostgresProvider, @provider.transformation).",
        code="no_resources_found",
    )


def resources_to_json(resources: list[Any]) -> list[dict[str, Any]]:
    """Convert resources to JSON format.

    Args:
        resources: List of resource objects.

    Returns:
        List of dicts with 'type' and 'spec' keys.
    """
    result: list[dict[str, Any]] = []
    for resource in resources:
        # Use the resource_type property if available (new Resource classes),
        # otherwise fall back to snake_case class name (legacy types)
        resource_type = getattr(resource, "resource_type", None)
        if resource_type is not None:
            type_name: str = resource_type
        else:
            type_name = _camel_to_snake(type(resource).__name__)
        # Get the spec from model_dump() with aliases to match proto field names
        spec = cast(dict[str, Any], resource.model_dump(by_alias=True))
        # Ensure 'name' is included (some resources have computed name properties)
        if "name" not in spec:
            resource_name = getattr(resource, "name", None)
            if resource_name is not None:
                spec["name"] = resource_name
        result.append({"type": type_name, "spec": spec})
    return result


def resources_to_proto(resources: list[Any]) -> list[Any]:  # noqa: C901
    """Convert resources to proto format for gRPC.

    Supports both:
    1. New-style resources (from featureform.resources) with to_proto() method
    2. Old-style resources (from featureform.types.resource) with manual conversion

    Args:
        resources: List of resource objects.

    Returns:
        List of proto Resource messages.
    """
    from featureform.resources.base import Resource as NewResource
    from featureform.types.resource import (
        Entity,
        FeatureView,
        IcebergPrimaryDataset,
        JoinStrategy,
        MaterializationEngine,
        PostgresTransformedDataset,
        PrimaryDataset,
    )

    result: list[Any] = []
    for resource in resources:
        # First, check if this is a new-style resource with to_proto() method
        if isinstance(resource, NewResource):
            # to_proto() is typed as Message but actually returns resource_pb2.Resource
            proto = cast(Any, resource.to_proto())
            result.append(proto)
            continue

        # Legacy handling for old-style resources
        if isinstance(resource, Entity):
            proto_res = resource_pb2.Resource(
                entity=resource_pb2.Entity(
                    name=resource.name,
                    description=resource.description or "",
                )
            )
            result.append(proto_res)
        elif isinstance(resource, IcebergPrimaryDataset):
            # Handle IcebergPrimaryDataset separately (before PrimaryDataset due to inheritance)
            iceberg_location = resource.location
            proto_res = resource_pb2.Resource(
                iceberg_primary_dataset=resource_pb2.IcebergPrimaryDataset(
                    name=resource.name,
                    description=resource.description or "",
                    provider=resource.provider,
                    location=resource_pb2.IcebergTableLocation(
                        namespace=iceberg_location.namespace if iceberg_location else "",
                        table=iceberg_location.table if iceberg_location else "",
                    ),
                    timestamp_column=resource.timestamp_column or "",
                )
            )
            result.append(proto_res)
        elif isinstance(resource, PrimaryDataset):
            table_location = resource.location
            proto_res = resource_pb2.Resource(
                primary_dataset=resource_pb2.PrimaryDataset(
                    name=resource.name,
                    description=resource.description or "",
                    provider=resource.provider,
                    location=resource_pb2.TableLocation(
                        database=table_location.database if table_location else "",
                        schema=table_location.schema if table_location else "",
                        table=table_location.table if table_location else "",
                    ),
                    timestamp_column=resource.timestamp_column or "",
                )
            )
            result.append(proto_res)
        elif isinstance(resource, PostgresTransformedDataset):
            pg_config = resource.postgres_config
            proto_res = resource_pb2.Resource(
                postgres_transformed_dataset=resource_pb2.PostgresTransformedDataset(
                    name=resource.name,
                    description=resource.description or "",
                    provider=resource.provider or "",
                    source_datasets=resource.source_datasets,
                    sql_query=resource.sql_query,
                    postgres_config=resource_pb2.PostgresDatasetConfig(
                        schema=pg_config.schema if pg_config else "public",
                        table=pg_config.table if pg_config else "",
                    ),
                )
            )
            result.append(proto_res)
        elif isinstance(resource, FeatureView):
            # Map MaterializationEngine enum to proto
            engine_map = {
                MaterializationEngine.K8S: resource_pb2.MATERIALIZATION_ENGINE_K8S,
                MaterializationEngine.SPARK: resource_pb2.MATERIALIZATION_ENGINE_SPARK,
            }
            join_strategy_map = {
                JoinStrategy.FULL_OUTER: resource_pb2.JOIN_STRATEGY_FULL_OUTER,
                JoinStrategy.INNER: resource_pb2.JOIN_STRATEGY_INNER,
            }
            proto_engine = engine_map.get(
                resource.materialization_engine,
                resource_pb2.MATERIALIZATION_ENGINE_UNSPECIFIED,
            )
            proto_join_strategy = join_strategy_map.get(
                resource.join_strategy,
                resource_pb2.JOIN_STRATEGY_UNSPECIFIED,
            )
            proto_res = resource_pb2.Resource(
                feature_view=resource_pb2.FeatureView(
                    name=resource.name,
                    description=resource.description or "",
                    entity=resource.entity,
                    features=resource.features,
                    provider=resource.provider or "",
                    inference_store=resource.inference_store,
                    materialization_engine=proto_engine,
                    join_strategy=proto_join_strategy,
                    spark_provider=resource.spark_provider or "",
                    batch_only=resource.batch_only,
                )
            )
            result.append(proto_res)
        else:
            # Unsupported type - fail with helpful message
            resource_type = type(resource).__name__
            err_console.print(
                f"[red]Error:[/red] Resource type '{resource_type}' is not supported for gRPC apply.\n"
                f"  Supported types: Entity, PrimaryDataset, IcebergPrimaryDataset, "
                f"PostgresTransformedDataset, "
                f"BatchAttributeFeature, FeatureView\n"
                f"  To add support, update resources_to_proto() in apply.py or use new-style resources."
            )
            raise typer.Exit(1)
    return result


def _wait_for_job(
    scheduler_client: SchedulerClient,
    job_id: str,
    wait_for: WaitTarget,
    timeout_seconds: float,
    poll_interval_seconds: float,
) -> dict[str, Any]:
    """Poll the scheduler until a job reaches the requested state."""
    try:
        return wait_for_job(
            get_job=scheduler_client.get_job,
            job_id=job_id,
            wait_for=wait_for,
            timeout_seconds=timeout_seconds,
            poll_interval_seconds=poll_interval_seconds,
            is_not_found_error=lambda exc: isinstance(exc, NotFoundError),
            monotonic_fn=time.monotonic,
            sleep_fn=time.sleep,
        )
    except ApplyJobVisibilityTimeoutError:
        timeout_error = SchedulerApplyTimeoutError(job_id, waiting_for_visibility=True)
        timeout_error.code = EXIT_TIMEOUT
        raise timeout_error from None
    except ApplyJobStateTimeoutError as exc:
        timeout_error = SchedulerApplyTimeoutError(
            job_id,
            wait_for=exc.wait_for.value,
            last_status=exc.last_status,
        )
        timeout_error.code = EXIT_TIMEOUT
        raise timeout_error from None
    except ApplyWaitTimeoutError:
        timeout_error = SchedulerApplyTimeoutError(job_id)
        timeout_error.code = EXIT_TIMEOUT
        raise timeout_error from None
    except ApplyWaitError as exc:
        status = getattr(exc, "status", "UNKNOWN")
        failed_error = SchedulerApplyJobFailedError(
            job_id,
            status,
            detail=getattr(exc, "detail", None),
            job=getattr(exc, "job", None),
        )
        failed_error.code = EXIT_ERROR
        raise failed_error from None


def _print_output(cli_ctx: CLIContext, output: str) -> None:
    """Print output using plain print for structured formats, console for table."""
    if cli_ctx.output_format in ("json", "yaml"):
        print(output)
    else:
        console.print(output)


def _format_plan_output(cli_ctx: CLIContext, data: dict[str, Any]) -> str:
    """Format plan output."""
    if cli_ctx.output_format == OutputFormat.JSON:
        formatter = JSONFormatter()
        return formatter.format(data)

    # Text format
    lines = ["[bold]Plan (dry run)[/bold]", ""]

    base_version = data.get("base_version")
    if isinstance(base_version, int):
        lines.append(f"  Base version:   {base_version}")
    apply_strategy = data.get("apply_strategy")
    if isinstance(apply_strategy, str) and apply_strategy:
        lines.append(f"  Apply strategy: {apply_strategy}")
    execution_mode = data.get("execution_mode")
    if isinstance(execution_mode, str) and execution_mode:
        lines.append(f"  Execution mode: {execution_mode}")
    if len(lines) > 2:
        lines.append("")

    delta = data.get("delta", {})
    lines.append(f"  To add:    {delta.get('added', 0)}")
    lines.append(f"  To modify: {delta.get('modified', 0)}")
    lines.append(f"  To delete: {delta.get('deleted', 0)}")
    lines.append("")

    changes = data.get("changes", [])
    planned_job = data.get("planned_job")
    planner_ir = data.get("planner_ir")
    if changes:
        lines.append("[bold]Changes:[/bold]")
        for change in changes:
            change_type = change.get("type", "unknown")
            resource_name = change.get("resource_name", "unknown")
            resource_type = change.get("resource_type", "unknown")
            symbol = {"add": "+", "modify": "~", "delete": "-"}.get(change_type, "?")
            lines.append(f"  {symbol} {resource_name} ({resource_type})")
    elif planned_job:
        lines.append("No graph changes detected. Execution mode still plans runtime work.")
    else:
        lines.append("No changes detected.")

    # Show planned job if present
    if planned_job:
        lines.append("")
        lines.append(f"[bold]Planned Job:[/bold] {planned_job.get('name', 'unnamed')}")
        lines.append("Tasks:")
        for task in planned_job.get("tasks", []):
            task_type = task.get("type", "unknown")
            operation = task.get("operation", "normal")
            operation_label = escape(f"[{operation}]")
            resource_ids = task.get("resource_ids", [])
            if isinstance(resource_ids, list):
                formatted_resource_ids = [value for value in resource_ids if isinstance(value, str)]
            else:
                formatted_resource_ids = []
            if not formatted_resource_ids:
                resource_id = task.get("resource_id", "")
                if isinstance(resource_id, str) and resource_id:
                    formatted_resource_ids = [resource_id]
            depends_on = task.get("depends_on", [])
            deps = f" (depends on: {', '.join(depends_on)})" if depends_on else ""
            resource_summary = ", ".join(formatted_resource_ids)
            lines.append(
                f"  - {escape(str(task_type))} {operation_label}: "
                f"{escape(resource_summary)}{escape(deps)}"
            )

    if isinstance(planner_ir, dict) and planner_ir:
        planner_ir_dict = cast(dict[str, Any], planner_ir)
        items = planner_ir_dict.get("items", [])
        reconcile_order = planner_ir_dict.get("reconcile_order", [])
        delete_order = planner_ir_dict.get("delete_order", [])
        lines.append("")
        lines.append("[bold]Planner IR:[/bold]")
        if isinstance(items, list):
            lines.append("Items:")
            for item_value in items:
                if not isinstance(item_value, dict):
                    continue
                item = cast(dict[str, Any], item_value)
                item_id = item.get("id", "unknown")
                graph_diff = item.get("graph_diff", "unknown")
                action = item.get("action", "unknown")
                reason = item.get("reason", "unknown")
                current_id = item.get("current_id")
                desired_id = item.get("desired_id")
                suffix_parts: list[str] = []
                if isinstance(current_id, str) and current_id:
                    suffix_parts.append(f"current={current_id}")
                if isinstance(desired_id, str) and desired_id:
                    suffix_parts.append(f"desired={desired_id}")
                suffix = f" ({', '.join(suffix_parts)})" if suffix_parts else ""
                lines.append(
                    "  - "
                    f"{escape(str(item_id))}: "
                    f"{escape(str(graph_diff))} / {escape(str(action))} / {escape(str(reason))}"
                    f"{escape(suffix)}"
                )
        if isinstance(reconcile_order, list):
            lines.append(f"Reconcile order: {escape(', '.join(str(v) for v in reconcile_order))}")
        if isinstance(delete_order, list):
            lines.append(f"Delete order: {escape(', '.join(str(v) for v in delete_order))}")

    plan_error = data.get("plan_error")
    if isinstance(plan_error, str) and plan_error:
        lines.append("")
        lines.append("[bold red]Unable to create planned job:[/bold red]")
        lines.append(f"  {plan_error}")

    lines.append("")
    lines.append("No changes applied. Run without --plan to apply.")

    return "\n".join(lines)


def _format_apply_output(cli_ctx: CLIContext, data: dict[str, Any]) -> str:
    """Format apply output."""
    if cli_ctx.output_format == OutputFormat.JSON:
        formatter = JSONFormatter()
        return formatter.format(data)

    # Text format
    lines = ["[bold green]Apply Successful[/bold green]", ""]

    version = data.get("version", "")
    if version:
        lines.append(f"  Version: {version}")

    job_id = data.get("job_id", "")
    if job_id:
        lines.append(f"  Job ID:   {job_id}")

    delta = data.get("delta", {})
    lines.append(f"  Added:    {delta.get('added', 0)}")
    lines.append(f"  Modified: {delta.get('modified', 0)}")
    lines.append(f"  Deleted:  {delta.get('deleted', 0)}")

    job = data.get("job")
    if isinstance(job, dict) and job:
        job_data = cast(dict[str, Any], job)
        lines.append("")
        lines.append("[bold]Job:[/bold]")
        lines.append(f"  Status:   {job_data.get('status', 'UNKNOWN')}")
        if job_data.get("started_at"):
            lines.append(f"  Started:  {job_data.get('started_at')}")
        if job_data.get("completed_at"):
            lines.append(f"  Finished: {job_data.get('completed_at')}")
        if job_data.get("error_message"):
            lines.append(f"  Error:    {job_data.get('error_message')}")

    return "\n".join(lines)


def _get_failed_tasks(job: dict[str, Any]) -> list[dict[str, Any]]:
    """Return failed tasks from a scheduler job payload."""
    tasks = job.get("tasks", [])
    if not isinstance(tasks, list):
        return []
    failed_tasks: list[dict[str, Any]] = []
    for task in tasks:
        if not isinstance(task, dict):
            continue
        task_data = cast(dict[str, Any], task)
        if task_data.get("status") in {"FAILED", "CANCELED"}:
            failed_tasks.append(task_data)
    return failed_tasks


def _format_apply_failure_output(cli_ctx: CLIContext, data: dict[str, Any]) -> str:
    """Format a failed apply job with scheduler details."""
    if cli_ctx.output_format == OutputFormat.JSON:
        formatter = JSONFormatter()
        return formatter.format(data)

    lines = ["[bold red]Apply Failed[/bold red]", ""]
    lines.append(f"  Job ID: {data.get('job_id', 'unknown')}")
    lines.append(f"  Status: {data.get('status', 'UNKNOWN')}")

    error_message = data.get("error_message")
    if error_message:
        lines.append(f"  Error:  {error_message}")

    failed_tasks = data.get("failed_tasks", [])
    if isinstance(failed_tasks, list) and failed_tasks:
        lines.append("")
        lines.append("[bold]Failed Tasks:[/bold]")
        for task in failed_tasks:
            if not isinstance(task, dict):
                continue
            task_data = cast(dict[str, Any], task)
            task_id = task_data.get("id", "unknown")
            task_def_id = task_data.get("task_def_id", "unknown")
            status = task_data.get("status", "UNKNOWN")
            task_error = task_data.get("error_message")
            lines.append(f"  - {task_def_id} ({task_id}): {status}")
            if task_error:
                lines.append(f"    Error: {task_error}")

    return "\n".join(lines)


def _build_apply_failure_details(
    scheduler_client: SchedulerClient,
    failure: SchedulerApplyJobFailedError,
) -> dict[str, Any]:
    """Fetch scheduler details for a failed apply job."""
    job = scheduler_client.get_job(failure.job_id)
    return {
        "job_id": failure.job_id,
        "status": job.get("status", failure.status),
        "error_message": job.get("error_message", ""),
        "job": job,
        "failed_tasks": _get_failed_tasks(job),
    }


@app.callback(invoke_without_command=True)
def apply_resources(
    ctx: typer.Context,
    file: Annotated[
        Path | None,
        typer.Option(
            "-f",
            "--file",
            help="Python entry file or package directory containing resources",
        ),
    ] = None,
    workspace: Annotated[
        str | None, typer.Option("--workspace", "-w", help="Workspace name or ID")
    ] = None,
    plan: Annotated[
        bool, typer.Option("--plan", help="Show what would change without applying")
    ] = False,
    merge: Annotated[bool, typer.Option("--merge", help="Use merge apply strategy")] = False,
    update: Annotated[bool, typer.Option("--update", help="Use update execution mode")] = False,
    full_rematerialize: Annotated[
        bool,
        typer.Option("--full-rematerialize", help="Use full rematerialize execution mode"),
    ] = False,
    show_planner_ir: Annotated[
        bool,
        typer.Option(
            "--show-planner-ir",
            help="Include debug planner IR in plan output",
            hidden=True,
        ),
    ] = False,
    message: Annotated[str, typer.Option("--message", "-m", help="Change message")] = "",
    wait: Annotated[
        bool, typer.Option("--wait", help="Wait for the apply job after submission")
    ] = False,
    wait_for: Annotated[
        WaitTarget,
        typer.Option("--wait-for", help="Wait target: running or finished"),
    ] = WaitTarget.FINISHED,
    wait_timeout: Annotated[
        float,
        typer.Option("--wait-timeout", help="Wait timeout in seconds"),
    ] = 1800.0,
    poll_interval: Annotated[
        float,
        typer.Option("--poll-interval", help="Job polling interval in seconds"),
    ] = 2.0,
) -> None:
    """Apply resources from a Python entry file or package directory to a workspace."""
    # If no file provided, show help
    if file is None:
        raise typer.BadParameter("--file is required")

    try:
        semantics = ApplyFlagSemantics.resolve(
            ApplyFlagInputs(
                merge=merge,
                update=update,
                full_rematerialize=full_rematerialize,
                plan=plan,
            )
        )
    except ValueError as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from e

    if not workspace:
        err_console.print("[red]Error:[/red] --workspace is required")
        raise typer.Exit(1)
    if wait and plan:
        err_console.print("[red]Error:[/red] --wait cannot be used with --plan")
        raise typer.Exit(1)
    if show_planner_ir and not plan:
        err_console.print("[red]Error:[/red] --show-planner-ir requires --plan")
        raise typer.Exit(1)
    if wait_timeout <= 0:
        err_console.print("[red]Error:[/red] --wait-timeout must be greater than 0")
        raise typer.Exit(1)
    if poll_interval <= 0:
        err_console.print("[red]Error:[/red] --poll-interval must be greater than 0")
        raise typer.Exit(1)

    cli_ctx = _get_context(ctx)
    client = cli_ctx.get_client()

    try:
        # Resolve workspace name to ID if needed
        resolved_workspace_id = resolve_workspace_id(client, workspace)
        workspace_id = str(resolved_workspace_id)

        # Load resources from file
        resources = load_resources_from_file(
            file,
            client=client,
            workspace_id=resolved_workspace_id,
        )
        client.validate_apply_provider_references(resources, workspace_id=resolved_workspace_id)
        json_resources = (
            resources_to_json(resources) if client.transport_type == TransportType.REST else None
        )
        proto_resources = (
            resources_to_proto(resources) if client.transport_type == TransportType.GRPC else None
        )
        response_data = client.submit_apply_request(
            json_resources=json_resources,
            proto_resources=proto_resources,
            workspace_id=workspace_id,
            message=message,
            dry_run=plan,
            apply_strategy=semantics.strategy,
            execution_mode=semantics.execution_mode,
            show_planner_ir=show_planner_ir,
        )

        if wait and response_data.get("job_id"):
            scheduler_client = SchedulerClient(cli_ctx)
            job = _wait_for_job(
                scheduler_client=scheduler_client,
                job_id=str(response_data["job_id"]),
                wait_for=wait_for,
                timeout_seconds=wait_timeout,
                poll_interval_seconds=poll_interval,
            )
            response_data["job"] = job

        if plan:
            output = _format_plan_output(cli_ctx, response_data)
        else:
            output = _format_apply_output(cli_ctx, response_data)
        _print_output(cli_ctx, output)
        if plan and isinstance(response_data.get("plan_error"), str):
            raise typer.Exit(EXIT_ERROR)
    except SchedulerApplyJobFailedError as e:
        if not plan:
            try:
                scheduler_client = SchedulerClient(cli_ctx)
                failure_details = _build_apply_failure_details(scheduler_client, e)
                output = _format_apply_failure_output(cli_ctx, failure_details)
                if cli_ctx.output_format in (OutputFormat.JSON, OutputFormat.YAML):
                    _print_output(cli_ctx, output)
                else:
                    err_console.print(output)
            except SchedulerClientError:
                err_console.print(f"[red]Error:[/red] {e.message}")
            raise typer.Exit(e.code) from e
        err_console.print(f"[red]Error:[/red] {e.message}")
        raise typer.Exit(e.code) from e
    except SchedulerClientError as e:
        err_console.print(f"[red]Error:[/red] {e.message}")
        raise typer.Exit(e.code) from e
    except typer.BadParameter as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from e
    except typer.Exit:
        raise
    except Exception as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from e
    finally:
        cli_ctx.close()
