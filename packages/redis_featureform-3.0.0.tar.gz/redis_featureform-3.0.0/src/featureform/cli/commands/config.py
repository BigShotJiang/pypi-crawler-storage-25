"""Config CLI commands."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Annotated

import typer
import yaml
from rich.console import Console

from featureform.cli.auth.profiles import default_config_path
from featureform.cli.output import JSONFormatter, OutputFormatter, YAMLFormatter
from featureform.cli.utils import CLIContext, OutputFormat

app = typer.Typer(
    name="config",
    help="Manage CLI configuration",
    no_args_is_help=True,
)

console = Console()
err_console = Console(file=sys.stderr)


def _get_context(ctx: typer.Context) -> CLIContext:
    """Get CLI context."""
    cli_ctx: CLIContext = ctx.obj["context"]
    return cli_ctx


def _resolve_config_path(ctx: typer.Context | None, explicit: Path | None = None) -> Path:
    """Resolve the effective config path for the current invocation."""
    if explicit is not None:
        return explicit
    if ctx is not None and ctx.obj and "context" in ctx.obj:
        cli_ctx = _get_context(ctx)
        if cli_ctx.config_path is not None:
            return cli_ctx.config_path
    return default_config_path()


def _load_config(config_path: Path) -> dict[str, object]:
    """Load configuration from file."""
    if not config_path.exists():
        return {}
    with open(config_path, encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def _save_config(config_path: Path, config: dict[str, object]) -> None:
    """Save configuration to file."""
    config_path.parent.mkdir(parents=True, exist_ok=True)
    with open(config_path, "w", encoding="utf-8") as f:
        yaml.dump(config, f, default_flow_style=False, sort_keys=False)


@app.command("init")
def init(
    ctx: typer.Context,
    server: Annotated[
        str,
        typer.Option("--server", "-s", help="Server URL"),
    ] = "http://localhost:8080",
    output_format: Annotated[
        OutputFormat,
        typer.Option("--output", "-o", help="Default output format"),
    ] = OutputFormat.TABLE,
    timeout: Annotated[
        float,
        typer.Option("--timeout", "-t", help="Request timeout in seconds"),
    ] = 30.0,
    force: Annotated[
        bool,
        typer.Option("--force", "-f", help="Overwrite existing config"),
    ] = False,
) -> None:
    """Initialize CLI configuration."""
    config_path = _resolve_config_path(ctx)
    if config_path.exists() and not force:
        err_console.print(f"[yellow]Config file already exists:[/yellow] {config_path}")
        err_console.print("Use --force to overwrite")
        raise typer.Exit(1)

    config: dict[str, object] = {
        "server": server,
        "output": output_format.value,
        "timeout": timeout,
    }

    _save_config(config_path, config)
    console.print(f"[green]Config created:[/green] {config_path}")


@app.command("view")
def view(
    ctx: typer.Context,
    config_file: Annotated[
        Path | None,
        typer.Option("--config", "-c", help="Config file path"),
    ] = None,
) -> None:
    """View current configuration."""
    cli_ctx = _get_context(ctx)
    config_path = _resolve_config_path(ctx, config_file)

    if not config_path.exists():
        err_console.print(f"[yellow]No config file found at:[/yellow] {config_path}")
        err_console.print("Run 'ff config init' to create one")
        raise typer.Exit(1)

    config = _load_config(config_path)

    formatter: OutputFormatter
    if cli_ctx.output_format == OutputFormat.JSON:
        formatter = JSONFormatter()
        console.print(formatter.format(config))
    elif cli_ctx.output_format == OutputFormat.YAML:
        formatter = YAMLFormatter()
        console.print(formatter.format(config))
    else:
        console.print(f"[bold]Config file:[/bold] {config_path}")
        console.print()
        for key, value in config.items():
            console.print(f"  [cyan]{key}:[/cyan] {value}")


@app.command("set")
def set_value(
    ctx: typer.Context,
    key: Annotated[str, typer.Argument(help="Configuration key")],
    value: Annotated[str, typer.Argument(help="Configuration value")],
    config_file: Annotated[
        Path | None,
        typer.Option("--config", "-c", help="Config file path"),
    ] = None,
) -> None:
    """Set a configuration value."""
    config_path = _resolve_config_path(ctx, config_file)

    if not config_path.exists():
        err_console.print(f"[yellow]No config file found at:[/yellow] {config_path}")
        err_console.print("Run 'ff config init' to create one")
        raise typer.Exit(1)

    config = _load_config(config_path)

    # Handle type conversion for known keys
    if key == "timeout":
        config[key] = float(value)
    else:
        config[key] = value

    _save_config(config_path, config)
    console.print(f"[green]Set[/green] {key} = {value}")


@app.command("get")
def get_value(
    ctx: typer.Context,
    key: Annotated[str, typer.Argument(help="Configuration key")],
    config_file: Annotated[
        Path | None,
        typer.Option("--config", "-c", help="Config file path"),
    ] = None,
) -> None:
    """Get a configuration value."""
    config_path = _resolve_config_path(ctx, config_file)

    if not config_path.exists():
        err_console.print(f"[yellow]No config file found at:[/yellow] {config_path}")
        err_console.print("Run 'ff config init' to create one")
        raise typer.Exit(1)

    config = _load_config(config_path)

    if key not in config:
        err_console.print(f"[red]Key not found:[/red] {key}")
        raise typer.Exit(1)

    console.print(config[key])


@app.command("path")
def show_path(ctx: typer.Context) -> None:
    """Show the config file path."""
    console.print(str(_resolve_config_path(ctx)))
