"""Workspace CLI commands."""

from typing import Annotated

import typer

from featureform.cli.utils import CLIContext
from featureform.errors import NotFoundError

app = typer.Typer(
    name="workspace",
    help="Manage workspaces",
    no_args_is_help=True,
)

WORKSPACE_HEADERS = ["ID", "Name", "Description", "Created At", "Updated At"]


def _get_context(ctx: typer.Context) -> CLIContext:
    """Get CLI context."""
    cli_ctx: CLIContext = ctx.obj["context"]
    return cli_ctx


@app.command("create")
def create(
    ctx: typer.Context,
    name: Annotated[str, typer.Argument(help="Workspace name")],
    description: Annotated[
        str | None,
        typer.Option("--description", "-d", help="Workspace description"),
    ] = None,
) -> None:
    """Create a new workspace."""
    cli_ctx = _get_context(ctx)
    client = cli_ctx.get_client()
    try:
        workspace = client.workspaces.create(name=name, description=description)
        cli_ctx.print_formatted(workspace, WORKSPACE_HEADERS)
    except Exception as e:
        cli_ctx.err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from e
    finally:
        cli_ctx.close()


@app.command("get")
def get(
    ctx: typer.Context,
    workspace_id: Annotated[
        str | None,
        typer.Argument(help="Workspace ID"),
    ] = None,
    name: Annotated[
        str | None,
        typer.Option("--name", "-n", help="Workspace name"),
    ] = None,
) -> None:
    """Get a workspace by ID or name."""
    cli_ctx = _get_context(ctx)
    client = cli_ctx.get_client()

    if not workspace_id and not name:
        cli_ctx.err_console.print("[red]Error:[/red] Either workspace ID or --name is required")
        raise typer.Exit(1)

    try:
        if workspace_id:
            workspace = client.workspaces.get(workspace_id)
        elif name:
            workspace = client.workspaces.get_by_name(name)
        else:
            # Should never reach here due to the check above
            raise typer.Exit(1)
        cli_ctx.print_formatted(workspace, WORKSPACE_HEADERS)
    except NotFoundError:
        cli_ctx.err_console.print("[red]Error:[/red] Workspace not found")
        raise typer.Exit(1) from None
    except Exception as e:
        cli_ctx.err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from e
    finally:
        cli_ctx.close()


@app.command("list")
def list_workspaces(ctx: typer.Context) -> None:
    """List all workspaces."""
    cli_ctx = _get_context(ctx)
    client = cli_ctx.get_client()
    try:
        workspaces = client.workspaces.list()
        if not workspaces:
            # For structured output formats, output empty list
            if cli_ctx.output_format in ("json", "yaml"):
                cli_ctx.print_formatted([], WORKSPACE_HEADERS, is_list=True)
            else:
                cli_ctx.console.print("No workspaces found")
            return
        cli_ctx.print_formatted(workspaces, WORKSPACE_HEADERS, is_list=True)
    except Exception as e:
        cli_ctx.err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from e
    finally:
        cli_ctx.close()


@app.command("update")
def update(
    ctx: typer.Context,
    workspace_id: Annotated[str, typer.Argument(help="Workspace ID")],
    name: Annotated[
        str,
        typer.Option("--name", "-n", help="New workspace name (required)"),
    ],
    description: Annotated[
        str | None,
        typer.Option("--description", "-d", help="New workspace description"),
    ] = None,
) -> None:
    """Update an existing workspace."""
    cli_ctx = _get_context(ctx)
    client = cli_ctx.get_client()

    try:
        workspace = client.workspaces.update(workspace_id, name=name, description=description)
        cli_ctx.print_formatted(workspace, WORKSPACE_HEADERS)
    except NotFoundError:
        cli_ctx.err_console.print("[red]Error:[/red] Workspace not found")
        raise typer.Exit(1) from None
    except Exception as e:
        cli_ctx.err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from e
    finally:
        cli_ctx.close()


@app.command("delete")
def delete(
    ctx: typer.Context,
    workspace_id: Annotated[str, typer.Argument(help="Workspace ID")],
    force: Annotated[
        bool,
        typer.Option("--force", "-f", help="Skip confirmation"),
    ] = False,
) -> None:
    """Delete a workspace."""
    cli_ctx = _get_context(ctx)
    client = cli_ctx.get_client()

    if not force:
        confirm = typer.confirm(f"Are you sure you want to delete workspace {workspace_id}?")
        if not confirm:
            cli_ctx.console.print("Cancelled")
            raise typer.Exit(0)

    try:
        client.workspaces.delete(workspace_id)
        cli_ctx.console.print(f"Workspace {workspace_id} deleted")
    except NotFoundError:
        cli_ctx.err_console.print("[red]Error:[/red] Workspace not found")
        raise typer.Exit(1) from None
    except Exception as e:
        cli_ctx.err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from e
    finally:
        cli_ctx.close()
