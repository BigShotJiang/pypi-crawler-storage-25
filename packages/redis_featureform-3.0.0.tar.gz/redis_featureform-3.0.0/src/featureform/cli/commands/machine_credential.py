"""Machine credential CLI commands."""

from __future__ import annotations

from typing import Annotated, cast

import typer

from featureform.cli.admin_client import AdminClient, AdminClientError
from featureform.cli.utils import CLIContext

app = typer.Typer(
    name="machine-credential", help="Manage machine credentials", no_args_is_help=True
)

HEADERS = ["id", "name", "workspace_id", "principal_id", "status", "created_at"]


def _ctx(ctx: typer.Context) -> CLIContext:
    return cast(CLIContext, ctx.obj["context"])


def _handle_err(cli_ctx: CLIContext, err: Exception) -> None:
    message = err.message if isinstance(err, AdminClientError) else str(err)
    cli_ctx.err_console.print(f"[red]Error:[/red] {message}")
    raise typer.Exit(1) from err


@app.command("create")
def create(
    ctx: typer.Context,
    name: Annotated[str, typer.Argument(help="Credential name")],
    workspace: Annotated[str, typer.Option("--workspace", help="Workspace ID")],
    service_account: Annotated[
        str, typer.Option("--service-account", help="Service account principal ID")
    ],
    public_key: Annotated[str, typer.Option("--public-key", help="Public key material")],
    algorithm: Annotated[str, typer.Option("--algorithm", help="Signing algorithm")] = "Ed25519",
) -> None:
    """Create a machine credential."""
    cli_ctx = _ctx(ctx)
    try:
        data = AdminClient(cli_ctx).create_machine_credential(
            name=name,
            workspace_id=workspace,
            principal_type="service_account",
            principal_id=service_account,
            public_key=public_key,
            algorithm=algorithm,
        )
        cli_ctx.print_formatted(data.get("credential", data), HEADERS)
    except Exception as err:
        _handle_err(cli_ctx, err)


@app.command("get")
def get(
    ctx: typer.Context,
    credential_id: Annotated[str, typer.Argument(help="Credential ID")],
) -> None:
    """Get a machine credential."""
    cli_ctx = _ctx(ctx)
    try:
        data = AdminClient(cli_ctx).get_machine_credential(credential_id)
        cli_ctx.print_formatted(data.get("credential", data), HEADERS)
    except Exception as err:
        _handle_err(cli_ctx, err)


@app.command("list")
def list_credentials(
    ctx: typer.Context,
    workspace: Annotated[str | None, typer.Option("--workspace", help="Workspace ID")] = None,
    service_account: Annotated[
        str | None,
        typer.Option("--service-account", help="Service account principal ID"),
    ] = None,
    status: Annotated[str | None, typer.Option("--status", help="Credential status")] = None,
) -> None:
    """List machine credentials."""
    cli_ctx = _ctx(ctx)
    try:
        filters: dict[str, str] = {}
        if workspace:
            filters["workspace_id"] = workspace
        if service_account:
            filters["principal_id"] = service_account
        if status:
            filters["status"] = status
        data = AdminClient(cli_ctx).list_machine_credentials(**filters)
        items = data.get("credentials", data)
        cli_ctx.print_formatted(items, HEADERS, is_list=True)
    except Exception as err:
        _handle_err(cli_ctx, err)


@app.command("rotate")
def rotate(
    ctx: typer.Context,
    credential_id: Annotated[str, typer.Argument(help="Credential ID")],
    public_key: Annotated[str, typer.Option("--public-key", help="Replacement public key")],
) -> None:
    """Rotate a machine credential."""
    cli_ctx = _ctx(ctx)
    try:
        data = AdminClient(cli_ctx).rotate_machine_credential(
            credential_id,
            public_key=public_key,
        )
        cli_ctx.print_formatted(data.get("credential", data), HEADERS)
    except Exception as err:
        _handle_err(cli_ctx, err)


@app.command("revoke")
def revoke(
    ctx: typer.Context,
    credential_id: Annotated[str, typer.Argument(help="Credential ID")],
) -> None:
    """Revoke a machine credential."""
    cli_ctx = _ctx(ctx)
    try:
        AdminClient(cli_ctx).revoke_machine_credential(credential_id)
        cli_ctx.console.print("Machine credential revoked")
    except Exception as err:
        _handle_err(cli_ctx, err)


@app.command("usage")
def usage(
    ctx: typer.Context,
    credential_id: Annotated[str, typer.Argument(help="Credential ID")],
) -> None:
    """Show usage for a machine credential."""
    cli_ctx = _ctx(ctx)
    try:
        cli_ctx.print_formatted(
            AdminClient(cli_ctx).machine_credential_usage(credential_id),
            ["field", "value"],
        )
    except Exception as err:
        _handle_err(cli_ctx, err)
