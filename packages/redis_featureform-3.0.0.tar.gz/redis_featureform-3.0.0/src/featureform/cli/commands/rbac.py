"""RBAC CLI commands."""

from __future__ import annotations

import json
from typing import Annotated, Any, cast

import typer

from featureform.cli.admin_client import AdminClient, AdminClientError
from featureform.cli.utils import CLIContext

app = typer.Typer(
    name="rbac", help="Manage RBAC bindings and inspect effective access", no_args_is_help=True
)

BINDING_HEADERS = ["scope", "workspace_id", "principal_type", "principal_id", "role"]
RESOURCE_HEADERS = [
    "workspace_id",
    "principal_type",
    "principal_id",
    "resource_type",
    "resource_name",
]
EFFECTIVE_HEADERS = [
    "identity",
    "idp_roles",
    "featureform_bindings",
    "permissions",
    "model_resources",
    "machine_context",
]
ROLE_HEADERS = ["id", "label", "description", "scope", "permissions", "managed_by"]
PERMISSION_HEADERS = ["id", "label", "description", "category", "resource_scope"]
PRINCIPAL_HEADERS = ["principal_type", "principal_id", "display_name", "email", "source"]
SUBJECT_HEADERS = [
    "principal_type",
    "principal_id",
    "roles",
    "binding_ids",
    "scopes",
    "last_updated_at",
]


def _ctx(ctx: typer.Context) -> CLIContext:
    return cast(CLIContext, ctx.obj["context"])


def _principal_args(
    user: str | None,
    group: str | None,
    service_account: str | None,
) -> tuple[str, str]:
    selected = [
        ("user", user),
        ("group", group),
        ("service_account", service_account),
    ]
    values = [(kind, value) for kind, value in selected if value]
    if len(values) != 1:
        raise typer.BadParameter("exactly one of --user, --group, or --service-account is required")
    return values[0]


def _handle_err(cli_ctx: CLIContext, err: Exception) -> None:
    message = err.message if isinstance(err, AdminClientError) else str(err)
    cli_ctx.err_console.print(f"[red]Error:[/red] {message}")
    raise typer.Exit(1) from err


@app.command("whoami")
def whoami(ctx: typer.Context) -> None:
    """Show the current authenticated principal and effective roles."""
    cli_ctx = _ctx(ctx)
    try:
        cli_ctx.print_formatted(AdminClient(cli_ctx).whoami(), ["field", "value"])
    except Exception as err:
        _handle_err(cli_ctx, err)


@app.command("roles")
def roles(ctx: typer.Context) -> None:
    """List built-in RBAC roles."""
    cli_ctx = _ctx(ctx)
    try:
        data = AdminClient(cli_ctx).list_roles()
        cli_ctx.print_formatted(data.get("roles", data), ROLE_HEADERS, is_list=True)
    except Exception as err:
        _handle_err(cli_ctx, err)


@app.command("permissions")
def permissions(ctx: typer.Context) -> None:
    """List built-in RBAC permissions."""
    cli_ctx = _ctx(ctx)
    try:
        data = AdminClient(cli_ctx).list_permissions()
        cli_ctx.print_formatted(data.get("permissions", data), PERMISSION_HEADERS, is_list=True)
    except Exception as err:
        _handle_err(cli_ctx, err)


@app.command("search-principals")
def search_principals(
    ctx: typer.Context,
    query: Annotated[str, typer.Argument(help="Case-insensitive principal search query")],
    workspace: Annotated[str | None, typer.Option("--workspace", help="Workspace ID")] = None,
    principal_type: Annotated[
        str | None, typer.Option("--principal-type", help="Principal type")
    ] = None,
    limit: Annotated[int | None, typer.Option("--limit", help="Maximum results")] = None,
) -> None:
    """Search known principals."""
    cli_ctx = _ctx(ctx)
    try:
        filters: dict[str, object] = {"query": query}
        if workspace:
            filters["workspace_id"] = workspace
        if principal_type:
            filters["principal_type"] = principal_type
        if limit is not None:
            filters["limit"] = limit
        data = AdminClient(cli_ctx).search_principals(**filters)
        cli_ctx.print_formatted(data.get("principals", data), PRINCIPAL_HEADERS, is_list=True)
    except Exception as err:
        _handle_err(cli_ctx, err)


@app.command("grant")
def grant(
    ctx: typer.Context,
    role: Annotated[str, typer.Argument(help="Role to grant")],
    workspace: Annotated[str | None, typer.Option("--workspace", help="Workspace ID")] = None,
    global_scope: Annotated[bool, typer.Option("--global", help="Grant at global scope")] = False,
    user: Annotated[str | None, typer.Option("--user", help="User principal ID")] = None,
    group: Annotated[str | None, typer.Option("--group", help="Group principal ID")] = None,
    service_account: Annotated[
        str | None,
        typer.Option("--service-account", help="Service account principal ID"),
    ] = None,
) -> None:
    """Grant a role to a principal."""
    cli_ctx = _ctx(ctx)
    try:
        principal_type, principal_id = _principal_args(user, group, service_account)
        if workspace and global_scope:
            raise typer.BadParameter("--workspace and --global are mutually exclusive")
        scope = "global" if global_scope else "workspace"
        if scope == "workspace" and not workspace:
            raise typer.BadParameter("--workspace is required unless --global is set")
        payload = AdminClient(cli_ctx).grant_role(
            role=role,
            workspace=workspace,
            scope=scope,
            principal_type=principal_type,
            principal_id=principal_id,
        )
        cli_ctx.print_formatted(payload.get("binding", payload), BINDING_HEADERS)
    except Exception as err:
        _handle_err(cli_ctx, err)


@app.command("revoke")
def revoke(
    ctx: typer.Context,
    role: Annotated[str, typer.Argument(help="Role to revoke")],
    workspace: Annotated[str | None, typer.Option("--workspace", help="Workspace ID")] = None,
    global_scope: Annotated[bool, typer.Option("--global", help="Revoke at global scope")] = False,
    user: Annotated[str | None, typer.Option("--user", help="User principal ID")] = None,
    group: Annotated[str | None, typer.Option("--group", help="Group principal ID")] = None,
    service_account: Annotated[
        str | None,
        typer.Option("--service-account", help="Service account principal ID"),
    ] = None,
) -> None:
    """Revoke a role from a principal."""
    cli_ctx = _ctx(ctx)
    try:
        principal_type, principal_id = _principal_args(user, group, service_account)
        if workspace and global_scope:
            raise typer.BadParameter("--workspace and --global are mutually exclusive")
        scope = "global" if global_scope else "workspace"
        if scope == "workspace" and not workspace:
            raise typer.BadParameter("--workspace is required unless --global is set")
        AdminClient(cli_ctx).revoke_role(
            role=role,
            workspace=workspace,
            scope=scope,
            principal_type=principal_type,
            principal_id=principal_id,
        )
        cli_ctx.console.print("Role revoked")
    except Exception as err:
        _handle_err(cli_ctx, err)


@app.command("list")
def list_bindings(
    ctx: typer.Context,
    workspace: Annotated[str | None, typer.Option("--workspace", help="Workspace ID")] = None,
    global_scope: Annotated[bool, typer.Option("--global", help="List global bindings")] = False,
    user: Annotated[str | None, typer.Option("--user", help="User principal ID")] = None,
    group: Annotated[str | None, typer.Option("--group", help="Group principal ID")] = None,
    service_account: Annotated[
        str | None,
        typer.Option("--service-account", help="Service account principal ID"),
    ] = None,
    role: Annotated[str | None, typer.Option("--role", help="Filter by role")] = None,
) -> None:
    """List RBAC bindings."""
    cli_ctx = _ctx(ctx)
    try:
        filters: dict[str, str] = {}
        if workspace and global_scope:
            raise typer.BadParameter("--workspace and --global are mutually exclusive")
        if workspace:
            filters["workspace_id"] = workspace
        if global_scope:
            filters["scope"] = "global"
        if role:
            filters["role"] = role
        values = [("user", user), ("group", group), ("service_account", service_account)]
        selected = [(kind, value) for kind, value in values if value]
        if len(selected) > 1:
            raise typer.BadParameter(
                "at most one of --user, --group, or --service-account may be set"
            )
        if selected:
            filters["principal_type"], filters["principal_id"] = selected[0]
        data = AdminClient(cli_ctx).list_bindings(**filters)
        items = data.get("bindings", data)
        cli_ctx.print_formatted(items, BINDING_HEADERS, is_list=True)
    except Exception as err:
        _handle_err(cli_ctx, err)


@app.command("subjects")
def list_binding_subjects(
    ctx: typer.Context,
    workspace: Annotated[str | None, typer.Option("--workspace", help="Workspace ID")] = None,
    global_scope: Annotated[bool, typer.Option("--global", help="List global subjects")] = False,
    user: Annotated[str | None, typer.Option("--user", help="User principal ID")] = None,
    group: Annotated[str | None, typer.Option("--group", help="Group principal ID")] = None,
    service_account: Annotated[
        str | None,
        typer.Option("--service-account", help="Service account principal ID"),
    ] = None,
    role: Annotated[str | None, typer.Option("--role", help="Filter by role")] = None,
) -> None:
    """List RBAC bindings grouped by principal."""
    cli_ctx = _ctx(ctx)
    try:
        filters: dict[str, str] = {}
        if workspace and global_scope:
            raise typer.BadParameter("--workspace and --global are mutually exclusive")
        if workspace:
            filters["workspace_id"] = workspace
        if global_scope:
            filters["scope"] = "global"
        if role:
            filters["role"] = role
        values = [("user", user), ("group", group), ("service_account", service_account)]
        selected = [(kind, value) for kind, value in values if value]
        if len(selected) > 1:
            raise typer.BadParameter(
                "at most one of --user, --group, or --service-account may be set"
            )
        if selected:
            filters["principal_type"], filters["principal_id"] = selected[0]
        data = AdminClient(cli_ctx).list_binding_subjects(**filters)
        cli_ctx.print_formatted(data.get("subjects", data), SUBJECT_HEADERS, is_list=True)
    except Exception as err:
        _handle_err(cli_ctx, err)


@app.command("effective")
def effective(
    ctx: typer.Context,
    workspace: Annotated[str | None, typer.Option("--workspace", help="Workspace ID")] = None,
    user: Annotated[str | None, typer.Option("--user", help="User principal ID")] = None,
    group: Annotated[str | None, typer.Option("--group", help="Group principal ID")] = None,
    service_account: Annotated[
        str | None,
        typer.Option("--service-account", help="Service account principal ID"),
    ] = None,
    explain: Annotated[bool, typer.Option("--explain", help="Explain permission sources")] = False,
) -> None:
    """Show effective access for a principal."""
    cli_ctx = _ctx(ctx)
    try:
        filters: dict[str, str] = {}
        if workspace:
            filters["workspace_id"] = workspace
        selected = [
            (kind, value)
            for kind, value in [
                ("user", user),
                ("group", group),
                ("service_account", service_account),
            ]
            if value
        ]
        if len(selected) > 1:
            raise typer.BadParameter(
                "at most one of --user, --group, or --service-account may be set"
            )
        if selected:
            filters["principal_type"], filters["principal_id"] = selected[0]
        data = (
            AdminClient(cli_ctx).explain_effective_access(**filters)
            if explain
            else AdminClient(cli_ctx).effective_access(**filters)
        )
        cli_ctx.print_formatted(data, EFFECTIVE_HEADERS)
    except Exception as err:
        _handle_err(cli_ctx, err)


@app.command("check")
def check(
    ctx: typer.Context,
    permission: Annotated[
        str | None, typer.Option("--permission", help="Permission to check")
    ] = None,
    workspace: Annotated[str | None, typer.Option("--workspace", help="Workspace ID")] = None,
    resource_type: Annotated[
        str | None, typer.Option("--resource-type", help="Resource type")
    ] = None,
    resource_name: Annotated[str | None, typer.Option("--resource", help="Resource name")] = None,
    batch: Annotated[
        list[str] | None,
        typer.Option(
            "--batch",
            help="JSON-encoded batch check entry; may be provided multiple times",
        ),
    ] = None,
) -> None:
    """Check whether the current principal has a permission."""
    cli_ctx = _ctx(ctx)
    try:
        if batch:
            checks: list[dict[str, Any]] = []
            for entry in batch:
                parsed = json.loads(entry)
                if not isinstance(parsed, dict):
                    raise typer.BadParameter("--batch entries must decode to objects")
                checks.append(cast(dict[str, Any], parsed))
            data = AdminClient(cli_ctx).batch_check_permissions(checks)
        else:
            if not permission:
                raise typer.BadParameter("--permission is required unless --batch is used")
            data = AdminClient(cli_ctx).check_permission(
                permission=permission,
                workspace_id=workspace,
                resource_type=resource_type,
                resource_name=resource_name,
            )
        cli_ctx.print_formatted(data, ["field", "value"])
    except Exception as err:
        _handle_err(cli_ctx, err)


@app.command("list-resources")
def list_resources(
    ctx: typer.Context,
    workspace: Annotated[str, typer.Option("--workspace", help="Workspace ID")],
    user: Annotated[str | None, typer.Option("--user", help="User principal ID")] = None,
    group: Annotated[str | None, typer.Option("--group", help="Group principal ID")] = None,
    service_account: Annotated[
        str | None,
        typer.Option("--service-account", help="Service account principal ID"),
    ] = None,
) -> None:
    """List model resource bindings."""
    cli_ctx = _ctx(ctx)
    try:
        principal_type, principal_id = _principal_args(user, group, service_account)
        data = AdminClient(cli_ctx).list_model_resources(
            workspace_id=workspace,
            principal_type=principal_type,
            principal_id=principal_id,
        )
        items = data.get("resources", data)
        cli_ctx.print_formatted(items, RESOURCE_HEADERS, is_list=True)
    except Exception as err:
        _handle_err(cli_ctx, err)


@app.command("allow-resource")
def allow_resource(
    ctx: typer.Context,
    resource_type: Annotated[str, typer.Argument(help="Resource type, e.g. feature_view")],
    resource_name: Annotated[str, typer.Argument(help="Resource name")],
    workspace: Annotated[str, typer.Option("--workspace", help="Workspace ID")],
    user: Annotated[str | None, typer.Option("--user", help="User principal ID")] = None,
    group: Annotated[str | None, typer.Option("--group", help="Group principal ID")] = None,
    service_account: Annotated[
        str | None,
        typer.Option("--service-account", help="Service account principal ID"),
    ] = None,
) -> None:
    """Allow a model-scoped resource."""
    cli_ctx = _ctx(ctx)
    try:
        principal_type, principal_id = _principal_args(user, group, service_account)
        data = AdminClient(cli_ctx).allow_model_resource(
            workspace_id=workspace,
            principal_type=principal_type,
            principal_id=principal_id,
            resource_type=resource_type,
            resource_name=resource_name,
        )
        cli_ctx.print_formatted(data.get("resource", data), RESOURCE_HEADERS)
    except Exception as err:
        _handle_err(cli_ctx, err)


@app.command("revoke-resource")
def revoke_resource(
    ctx: typer.Context,
    resource_type: Annotated[str, typer.Argument(help="Resource type, e.g. feature_view")],
    resource_name: Annotated[str, typer.Argument(help="Resource name")],
    workspace: Annotated[str, typer.Option("--workspace", help="Workspace ID")],
    user: Annotated[str | None, typer.Option("--user", help="User principal ID")] = None,
    group: Annotated[str | None, typer.Option("--group", help="Group principal ID")] = None,
    service_account: Annotated[
        str | None,
        typer.Option("--service-account", help="Service account principal ID"),
    ] = None,
) -> None:
    """Revoke a model-scoped resource."""
    cli_ctx = _ctx(ctx)
    try:
        principal_type, principal_id = _principal_args(user, group, service_account)
        AdminClient(cli_ctx).revoke_model_resource(
            workspace_id=workspace,
            principal_type=principal_type,
            principal_id=principal_id,
            resource_type=resource_type,
            resource_name=resource_name,
        )
        cli_ctx.console.print("Resource binding revoked")
    except Exception as err:
        _handle_err(cli_ctx, err)
