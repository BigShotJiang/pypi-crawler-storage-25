"""Provider CLI commands."""

from typing import Annotated

import typer

from featureform.cli.commands._common import resolve_workspace_id
from featureform.cli.commands._provider_config import build_register_config, build_update_patch
from featureform.cli.utils import CLIContext
from featureform.errors import NotFoundError
from featureform.types import (
    ProviderType,
    RedisTLSMode,
    SSLMode,
)

app = typer.Typer(
    name="provider",
    help="Manage providers",
    no_args_is_help=True,
)

PROVIDER_HEADERS = ["Name", "Type", "Workspace ID", "Created At", "Updated At"]


def _parse_session_params(values: list[str] | None) -> dict[str, str] | None:
    if not values:
        return None

    params: dict[str, str] = {}
    for value in values:
        key, sep, param_value = value.partition("=")
        if not sep or not key or not param_value:
            raise ValueError("--snowflake-session-param must be in KEY=VALUE form")
        params[key] = param_value
    return params


def _get_context(ctx: typer.Context) -> CLIContext:
    """Get CLI context."""
    cli_ctx: CLIContext = ctx.obj["context"]
    return cli_ctx


def _has_explicit_spark_update_flags(**kwargs: object) -> bool:
    for key, value in kwargs.items():
        if not key.startswith("spark_"):
            continue
        if value is None:
            continue
        if isinstance(value, list) and len(value) == 0:
            continue
        return True
    return False


@app.command("register")
def register(
    ctx: typer.Context,
    name: Annotated[str, typer.Argument(help="Provider name")],
    workspace: Annotated[str, typer.Option("--workspace", "-w", help="Workspace name or ID")],
    provider_type: Annotated[
        ProviderType,
        typer.Option("--type", "-t", help="Provider type", case_sensitive=False),
    ],
    # Postgres options
    pg_host: Annotated[str | None, typer.Option("--pg-host", help="Postgres host")] = None,
    pg_port: Annotated[int, typer.Option("--pg-port", help="Postgres port")] = 5432,
    pg_database: Annotated[
        str | None, typer.Option("--pg-database", help="Postgres database")
    ] = None,
    pg_user: Annotated[str | None, typer.Option("--pg-user", help="Postgres user")] = None,
    pg_password_secret: Annotated[
        str | None,
        typer.Option("--pg-password-secret", help="Secret reference for Postgres password"),
    ] = None,
    pg_ssl_mode: Annotated[
        SSLMode,
        typer.Option(
            "--pg-ssl-mode",
            help="SSL mode for PostgreSQL connection",
            case_sensitive=False,
        ),
    ] = SSLMode.PREFER,
    # Snowflake options
    snowflake_account: Annotated[
        str | None, typer.Option("--snowflake-account", help="Snowflake account")
    ] = None,
    snowflake_host: Annotated[
        str | None, typer.Option("--snowflake-host", help="Snowflake host override")
    ] = None,
    snowflake_warehouse: Annotated[
        str | None, typer.Option("--snowflake-warehouse", help="Snowflake warehouse")
    ] = None,
    snowflake_database: Annotated[
        str | None, typer.Option("--snowflake-database", help="Snowflake database")
    ] = None,
    snowflake_schema: Annotated[
        str | None, typer.Option("--snowflake-schema", help="Snowflake schema")
    ] = None,
    snowflake_auth_type: Annotated[
        str, typer.Option("--snowflake-auth-type", help="Snowflake auth type")
    ] = "password",
    snowflake_username: Annotated[
        str | None, typer.Option("--snowflake-username", help="Snowflake username")
    ] = None,
    snowflake_password_secret: Annotated[
        str | None,
        typer.Option("--snowflake-password-secret", help="Secret reference for Snowflake password"),
    ] = None,
    snowflake_private_key_secret: Annotated[
        str | None,
        typer.Option(
            "--snowflake-private-key-secret", help="Secret reference for Snowflake private key"
        ),
    ] = None,
    snowflake_passphrase_secret: Annotated[
        str | None,
        typer.Option(
            "--snowflake-passphrase-secret",
            help="Secret reference for Snowflake private key passphrase",
        ),
    ] = None,
    snowflake_oauth_client_id: Annotated[
        str | None,
        typer.Option("--snowflake-oauth-client-id", help="Snowflake OAuth client ID"),
    ] = None,
    snowflake_oauth_client_secret: Annotated[
        str | None,
        typer.Option(
            "--snowflake-oauth-client-secret",
            help="Secret reference for Snowflake OAuth client secret",
        ),
    ] = None,
    snowflake_oauth_token: Annotated[
        str | None,
        typer.Option("--snowflake-oauth-token", help="Secret reference for Snowflake OAuth token"),
    ] = None,
    snowflake_role: Annotated[
        str | None, typer.Option("--snowflake-role", help="Snowflake role")
    ] = None,
    snowflake_login_timeout: Annotated[
        int | None,
        typer.Option("--snowflake-login-timeout", help="Snowflake login timeout in seconds"),
    ] = None,
    snowflake_request_timeout: Annotated[
        int | None,
        typer.Option("--snowflake-request-timeout", help="Snowflake request timeout in seconds"),
    ] = None,
    snowflake_session_param: Annotated[
        list[str] | None,
        typer.Option("--snowflake-session-param", help="Snowflake session param in KEY=VALUE form"),
    ] = None,
    # S3 options
    s3_bucket: Annotated[str | None, typer.Option("--s3-bucket", help="S3 bucket")] = None,
    s3_region: Annotated[str | None, typer.Option("--s3-region", help="S3 region")] = None,
    s3_access_key_id_secret: Annotated[
        str | None,
        typer.Option("--s3-access-key-id-secret", help="Secret reference for AWS access key ID"),
    ] = None,
    s3_secret_access_key_secret: Annotated[
        str | None,
        typer.Option(
            "--s3-secret-access-key-secret", help="Secret reference for AWS secret access key"
        ),
    ] = None,
    s3_endpoint: Annotated[
        str | None,
        typer.Option("--s3-endpoint", help="Custom S3 endpoint (for LocalStack/MinIO)"),
    ] = None,
    s3_path_style_access: Annotated[
        bool,
        typer.Option("--s3-path-style-access", help="Use path-style S3 access (for MinIO)"),
    ] = False,
    # Spark options
    spark_catalog: Annotated[
        list[str] | None,
        typer.Option("--spark-catalog", help="Spark catalog alias mapping in alias=provider form"),
    ] = None,
    spark_backend: Annotated[
        str | None,
        typer.Option("--spark-backend", help="Spark backend JSON object"),
    ] = None,
    spark_hadoop: Annotated[
        str | None, typer.Option("--spark-hadoop", help="Spark Hadoop JSON object")
    ] = None,
    spark_staging: Annotated[
        str | None, typer.Option("--spark-staging", help="Spark staging JSON object")
    ] = None,
    spark_driver_env: Annotated[
        list[str] | None,
        typer.Option("--spark-driver-env", help="Spark driver env in key=value form"),
    ] = None,
    spark_executor_env: Annotated[
        list[str] | None,
        typer.Option("--spark-executor-env", help="Spark executor env in key=value form"),
    ] = None,
    spark_deploy_mode: Annotated[
        str | None, typer.Option("--spark-deploy-mode", help="Spark deploy mode")
    ] = None,
    spark_driver_memory: Annotated[
        str | None, typer.Option("--spark-driver-memory", help="Spark driver memory")
    ] = None,
    spark_executor_memory: Annotated[
        str | None, typer.Option("--spark-executor-memory", help="Spark executor memory")
    ] = None,
    spark_executor_cores: Annotated[
        int | None, typer.Option("--spark-executor-cores", help="Spark executor cores")
    ] = None,
    spark_num_executors: Annotated[
        int | None, typer.Option("--spark-num-executors", help="Spark executor count")
    ] = None,
    spark_default_driver_memory: Annotated[
        str | None,
        typer.Option("--spark-default-driver-memory", help="Default Spark driver memory"),
    ] = None,
    spark_default_executor_memory: Annotated[
        str | None,
        typer.Option("--spark-default-executor-memory", help="Default Spark executor memory"),
    ] = None,
    spark_default_executor_cores: Annotated[
        int | None,
        typer.Option("--spark-default-executor-cores", help="Default Spark executor cores"),
    ] = None,
    spark_default_num_executors: Annotated[
        int | None,
        typer.Option("--spark-default-num-executors", help="Default Spark executor count"),
    ] = None,
    spark_default_shuffle_partitions: Annotated[
        int | None,
        typer.Option(
            "--spark-default-shuffle-partitions",
            help="Default Spark shuffle partition count",
        ),
    ] = None,
    spark_dependency_version: Annotated[
        list[str] | None,
        typer.Option(
            "--spark-dependency-version",
            help="Managed Spark dependency override in family=version form",
        ),
    ] = None,
    spark_extra_package: Annotated[
        list[str] | None,
        typer.Option("--spark-extra-package", help="Additional Spark package coordinate"),
    ] = None,
    spark_extra_jar: Annotated[
        list[str] | None,
        typer.Option("--spark-extra-jar", help="Additional Spark jar URI"),
    ] = None,
    spark_conf: Annotated[
        list[str] | None,
        typer.Option("--spark-conf", help="Advanced Spark config entry in key=value form"),
    ] = None,
    spark_runtime_backend: Annotated[
        str | None, typer.Option("--spark-runtime-backend", help="Spark runtime backend label")
    ] = None,
    spark_version: Annotated[
        str | None, typer.Option("--spark-version", help="Spark runtime version")
    ] = None,
    spark_scala_binary_version: Annotated[
        str | None,
        typer.Option("--spark-scala-binary-version", help="Spark Scala binary version"),
    ] = None,
    spark_submission_app_name: Annotated[
        str | None, typer.Option("--spark-submission-app-name", help="Default Spark app name")
    ] = None,
    spark_driver_cores: Annotated[
        int | None, typer.Option("--spark-driver-cores", help="Default Spark driver cores")
    ] = None,
    spark_properties_file: Annotated[
        str | None, typer.Option("--spark-properties-file", help="Spark properties file URI")
    ] = None,
    spark_repository: Annotated[
        list[str] | None, typer.Option("--spark-repository", help="Additional Spark repository URI")
    ] = None,
    spark_file: Annotated[
        list[str] | None, typer.Option("--spark-file", help="Spark submission file URI")
    ] = None,
    spark_archive: Annotated[
        list[str] | None, typer.Option("--spark-archive", help="Spark submission archive URI")
    ] = None,
    spark_py_file: Annotated[
        list[str] | None, typer.Option("--spark-py-file", help="Spark submission py-file URI")
    ] = None,
    spark_env: Annotated[
        list[str] | None, typer.Option("--spark-env", help="Spark submission env in key=value form")
    ] = None,
    spark_env_secret: Annotated[
        list[str] | None,
        typer.Option(
            "--spark-env-secret", help="Spark submission env secret in key=secret-ref form"
        ),
    ] = None,
    spark_queue: Annotated[
        str | None, typer.Option("--spark-queue", help="Spark submission queue")
    ] = None,
    spark_proxy_user: Annotated[
        str | None, typer.Option("--spark-proxy-user", help="Spark submission proxy user")
    ] = None,
    spark_kerberos_principal: Annotated[
        str | None, typer.Option("--spark-kerberos-principal", help="Spark Kerberos principal")
    ] = None,
    spark_kerberos_realm: Annotated[
        str | None, typer.Option("--spark-kerberos-realm", help="Spark Kerberos realm")
    ] = None,
    spark_kerberos_kdc_host: Annotated[
        str | None, typer.Option("--spark-kerberos-kdc-host", help="Spark Kerberos KDC host")
    ] = None,
    spark_kerberos_keytab_secret: Annotated[
        str | None,
        typer.Option("--spark-kerberos-keytab-secret", help="Secret reference for Spark keytab"),
    ] = None,
    spark_kerberos_krb5_conf_secret: Annotated[
        str | None,
        typer.Option("--spark-kerberos-krb5-conf-secret", help="Secret reference for krb5.conf"),
    ] = None,
    # DynamoDB options
    dynamodb_region: Annotated[
        str | None, typer.Option("--dynamodb-region", help="DynamoDB region")
    ] = None,
    dynamodb_access_key_id_secret: Annotated[
        str | None,
        typer.Option(
            "--dynamodb-access-key-id-secret",
            help="Secret reference for DynamoDB AWS access key ID",
        ),
    ] = None,
    dynamodb_secret_access_key_secret: Annotated[
        str | None,
        typer.Option(
            "--dynamodb-secret-access-key-secret",
            help="Secret reference for DynamoDB AWS secret access key",
        ),
    ] = None,
    dynamodb_endpoint: Annotated[
        str | None,
        typer.Option("--dynamodb-endpoint", help="Custom DynamoDB endpoint (for LocalStack)"),
    ] = None,
    dynamodb_table_prefix: Annotated[
        str | None,
        typer.Option("--dynamodb-table-prefix", help="DynamoDB table name prefix"),
    ] = None,
    # Redis options
    redis_host: Annotated[str | None, typer.Option("--redis-host", help="Redis host")] = None,
    redis_port: Annotated[int, typer.Option("--redis-port", help="Redis port")] = 6379,
    redis_password_secret: Annotated[
        str | None,
        typer.Option("--redis-password-secret", help="Secret reference for Redis password"),
    ] = None,
    redis_tls_mode: Annotated[
        RedisTLSMode | None,
        typer.Option("--redis-tls-mode", help="Redis TLS mode", case_sensitive=False),
    ] = None,
    redis_tls_ca_cert_path: Annotated[
        str | None,
        typer.Option("--redis-tls-ca-cert-path", help="Server-side path to Redis CA cert"),
    ] = None,
    redis_tls_ca_cert_secret: Annotated[
        str | None,
        typer.Option(
            "--redis-tls-ca-cert-secret", help="Secret reference containing Redis CA cert"
        ),
    ] = None,
    redis_tls_server_name: Annotated[
        str | None,
        typer.Option("--redis-tls-server-name", help="Redis TLS server name override"),
    ] = None,
    redis_tls_client_cert_path: Annotated[
        str | None,
        typer.Option("--redis-tls-client-cert-path", help="Server-side path to Redis client cert"),
    ] = None,
    redis_tls_client_cert_secret: Annotated[
        str | None,
        typer.Option(
            "--redis-tls-client-cert-secret",
            help="Secret reference containing Redis client cert",
        ),
    ] = None,
    redis_tls_client_key_path: Annotated[
        str | None,
        typer.Option("--redis-tls-client-key-path", help="Server-side path to Redis client key"),
    ] = None,
    redis_tls_client_key_secret: Annotated[
        str | None,
        typer.Option(
            "--redis-tls-client-key-secret",
            help="Secret reference containing Redis client key",
        ),
    ] = None,
    redis_tls_insecure_skip_verify: Annotated[
        bool | None,
        typer.Option("--redis-tls-insecure-skip-verify", help="Skip Redis TLS verification"),
    ] = None,
    redis_tls_min_version: Annotated[
        str | None,
        typer.Option("--redis-tls-min-version", help="Redis TLS minimum version"),
    ] = None,
    # Iceberg options
    iceberg_warehouse_provider: Annotated[
        str | None,
        typer.Option(
            "--iceberg-warehouse-provider",
            help="Provider name for the Iceberg warehouse backing store",
        ),
    ] = None,
    iceberg_warehouse_prefix: Annotated[
        str | None,
        typer.Option(
            "--iceberg-warehouse-prefix",
            help="Optional prefix under the warehouse provider root",
        ),
    ] = None,
    iceberg_catalog_name: Annotated[
        str | None,
        typer.Option("--iceberg-catalog-name", help="Canonical Iceberg catalog name"),
    ] = None,
    iceberg_rest_uri: Annotated[
        str | None,
        typer.Option("--iceberg-rest-uri", help="REST catalog URI (required for REST catalog)"),
    ] = None,
    iceberg_rest_credential: Annotated[
        str | None,
        typer.Option("--iceberg-rest-credential", help="REST catalog credential secret"),
    ] = None,
    iceberg_rest_prefix: Annotated[
        str | None,
        typer.Option("--iceberg-rest-prefix", help="REST catalog prefix"),
    ] = None,
    iceberg_hive_uri: Annotated[
        str | None,
        typer.Option("--iceberg-hive-uri", help="Hive Metastore URI (required for HIVE catalog)"),
    ] = None,
    iceberg_glue_region: Annotated[
        str | None,
        typer.Option("--iceberg-glue-region", help="AWS Glue region (required for GLUE catalog)"),
    ] = None,
    iceberg_glue_catalog_id: Annotated[
        str | None,
        typer.Option("--iceberg-glue-catalog-id", help="AWS Glue catalog ID"),
    ] = None,
    iceberg_sql_driver: Annotated[
        str | None,
        typer.Option("--iceberg-sql-driver", help="SQL catalog driver"),
    ] = None,
    iceberg_sql_connection_string: Annotated[
        str | None,
        typer.Option(
            "--iceberg-sql-connection-string",
            help="SQL catalog connection string secret reference",
        ),
    ] = None,
    iceberg_s3_region: Annotated[
        str | None,
        typer.Option("--iceberg-s3-region", help="S3 region for warehouse access"),
    ] = None,
    iceberg_s3_endpoint: Annotated[
        str | None,
        typer.Option("--iceberg-s3-endpoint", help="S3 endpoint (for MinIO/LocalStack)"),
    ] = None,
    iceberg_s3_access_key_id: Annotated[
        str | None,
        typer.Option("--iceberg-s3-access-key-id", help="S3 access key ID"),
    ] = None,
    iceberg_s3_secret_access_key: Annotated[
        str | None,
        typer.Option("--iceberg-s3-secret-access-key", help="S3 secret access key"),
    ] = None,
    iceberg_s3_path_style_access: Annotated[
        bool,
        typer.Option("--iceberg-s3-path-style-access", help="Use path-style S3 access (for MinIO)"),
    ] = False,
    # Health check options
    skip_health_check: Annotated[
        bool,
        typer.Option(
            "--skip-health-check",
            help="Skip the synchronous connectivity check at registration time",
        ),
    ] = False,
    disable_monitoring: Annotated[
        bool,
        typer.Option(
            "--disable-monitoring",
            help="Disable all recurring health checks (implies --skip-health-check)",
        ),
    ] = False,
) -> None:
    """Register a new provider."""
    cli_ctx = _get_context(ctx)
    client = cli_ctx.get_client()

    try:
        config = build_register_config(
            provider_type,
            pg_host=pg_host,
            pg_port=pg_port,
            pg_database=pg_database,
            pg_user=pg_user,
            pg_password_secret=pg_password_secret,
            pg_ssl_mode=pg_ssl_mode,
            snowflake_account=snowflake_account,
            snowflake_host=snowflake_host,
            snowflake_warehouse=snowflake_warehouse,
            snowflake_database=snowflake_database,
            snowflake_schema=snowflake_schema,
            snowflake_auth_type=snowflake_auth_type,
            snowflake_username=snowflake_username,
            snowflake_password_secret=snowflake_password_secret,
            snowflake_private_key_secret=snowflake_private_key_secret,
            snowflake_passphrase_secret=snowflake_passphrase_secret,
            snowflake_oauth_client_id=snowflake_oauth_client_id,
            snowflake_oauth_client_secret=snowflake_oauth_client_secret,
            snowflake_oauth_token=snowflake_oauth_token,
            snowflake_role=snowflake_role,
            snowflake_login_timeout=snowflake_login_timeout,
            snowflake_request_timeout=snowflake_request_timeout,
            snowflake_session_params=_parse_session_params(snowflake_session_param),
            s3_bucket=s3_bucket,
            s3_region=s3_region,
            s3_access_key_id_secret=s3_access_key_id_secret,
            s3_secret_access_key_secret=s3_secret_access_key_secret,
            s3_endpoint=s3_endpoint,
            s3_path_style_access=s3_path_style_access,
            spark_catalog=spark_catalog,
            spark_backend=spark_backend,
            spark_hadoop=spark_hadoop,
            spark_staging=spark_staging,
            spark_driver_env=spark_driver_env,
            spark_executor_env=spark_executor_env,
            spark_deploy_mode=spark_deploy_mode,
            spark_driver_memory=spark_driver_memory,
            spark_executor_memory=spark_executor_memory,
            spark_executor_cores=spark_executor_cores,
            spark_num_executors=spark_num_executors,
            spark_default_driver_memory=spark_default_driver_memory,
            spark_default_executor_memory=spark_default_executor_memory,
            spark_default_executor_cores=spark_default_executor_cores,
            spark_default_num_executors=spark_default_num_executors,
            spark_default_shuffle_partitions=spark_default_shuffle_partitions,
            spark_dependency_version=spark_dependency_version,
            spark_extra_package=spark_extra_package,
            spark_extra_jar=spark_extra_jar,
            spark_conf=spark_conf,
            spark_runtime_backend=spark_runtime_backend,
            spark_version=spark_version,
            spark_scala_binary_version=spark_scala_binary_version,
            spark_submission_app_name=spark_submission_app_name,
            spark_driver_cores=spark_driver_cores,
            spark_properties_file=spark_properties_file,
            spark_repository=spark_repository,
            spark_file=spark_file,
            spark_archive=spark_archive,
            spark_py_file=spark_py_file,
            spark_env=spark_env,
            spark_env_secret=spark_env_secret,
            spark_queue=spark_queue,
            spark_proxy_user=spark_proxy_user,
            spark_kerberos_principal=spark_kerberos_principal,
            spark_kerberos_realm=spark_kerberos_realm,
            spark_kerberos_kdc_host=spark_kerberos_kdc_host,
            spark_kerberos_keytab_secret=spark_kerberos_keytab_secret,
            spark_kerberos_krb5_conf_secret=spark_kerberos_krb5_conf_secret,
            dynamodb_region=dynamodb_region,
            dynamodb_access_key_id_secret=dynamodb_access_key_id_secret,
            dynamodb_secret_access_key_secret=dynamodb_secret_access_key_secret,
            dynamodb_endpoint=dynamodb_endpoint,
            dynamodb_table_prefix=dynamodb_table_prefix,
            redis_host=redis_host,
            redis_port=redis_port,
            redis_password_secret=redis_password_secret,
            redis_tls_mode=redis_tls_mode,
            redis_tls_ca_cert_path=redis_tls_ca_cert_path,
            redis_tls_ca_cert_secret=redis_tls_ca_cert_secret,
            redis_tls_server_name=redis_tls_server_name,
            redis_tls_client_cert_path=redis_tls_client_cert_path,
            redis_tls_client_cert_secret=redis_tls_client_cert_secret,
            redis_tls_client_key_path=redis_tls_client_key_path,
            redis_tls_client_key_secret=redis_tls_client_key_secret,
            redis_tls_insecure_skip_verify=redis_tls_insecure_skip_verify,
            redis_tls_min_version=redis_tls_min_version,
            iceberg_warehouse_provider=iceberg_warehouse_provider,
            iceberg_warehouse_prefix=iceberg_warehouse_prefix,
            iceberg_catalog_name=iceberg_catalog_name,
            iceberg_rest_uri=iceberg_rest_uri,
            iceberg_rest_credential=iceberg_rest_credential,
            iceberg_rest_prefix=iceberg_rest_prefix,
            iceberg_hive_uri=iceberg_hive_uri,
            iceberg_glue_region=iceberg_glue_region,
            iceberg_glue_catalog_id=iceberg_glue_catalog_id,
            iceberg_sql_driver=iceberg_sql_driver,
            iceberg_sql_connection_string=iceberg_sql_connection_string,
            iceberg_s3_region=iceberg_s3_region,
            iceberg_s3_endpoint=iceberg_s3_endpoint,
            iceberg_s3_access_key_id=iceberg_s3_access_key_id,
            iceberg_s3_secret_access_key=iceberg_s3_secret_access_key,
            iceberg_s3_path_style_access=iceberg_s3_path_style_access,
        )
    except ValueError as err:
        cli_ctx.err_console.print(f"[red]Error:[/red] {err}")
        raise typer.Exit(1) from err

    # Resolve workspace name/ID to UUID
    try:
        workspace_id = resolve_workspace_id(client, workspace)
    except NotFoundError:
        cli_ctx.err_console.print(f"[red]Error:[/red] Workspace '{workspace}' not found")
        raise typer.Exit(1) from None

    try:
        provider = client.providers(workspace_id).register(
            name=name,
            provider_type=provider_type,
            config=config,
            skip_health_check=skip_health_check,
            disable_monitoring=disable_monitoring,
        )
        cli_ctx.print_formatted(provider, PROVIDER_HEADERS)
    except Exception as e:
        cli_ctx.err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from e
    finally:
        cli_ctx.close()


@app.command("get")
def get(
    ctx: typer.Context,
    name: Annotated[str, typer.Argument(help="Provider name")],
    workspace: Annotated[str, typer.Option("--workspace", "-w", help="Workspace name or ID")],
) -> None:
    """Get a provider by name."""
    cli_ctx = _get_context(ctx)
    client = cli_ctx.get_client()

    try:
        workspace_id = resolve_workspace_id(client, workspace)
        provider = client.providers(workspace_id).get(name)
        cli_ctx.print_formatted(provider, PROVIDER_HEADERS)
    except NotFoundError:
        cli_ctx.err_console.print("[red]Error:[/red] Provider not found")
        raise typer.Exit(1) from None
    except Exception as e:
        cli_ctx.err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from e
    finally:
        cli_ctx.close()


@app.command("list")
def list_providers(
    ctx: typer.Context,
    workspace: Annotated[str, typer.Option("--workspace", "-w", help="Workspace name or ID")],
) -> None:
    """List all providers in a workspace."""
    cli_ctx = _get_context(ctx)
    client = cli_ctx.get_client()

    try:
        workspace_id = resolve_workspace_id(client, workspace)
        providers = client.providers(workspace_id).list()
        if not providers:
            # For structured output formats, output empty list
            if cli_ctx.output_format in ("json", "yaml"):
                cli_ctx.print_formatted([], PROVIDER_HEADERS, is_list=True)
            else:
                cli_ctx.console.print("No providers found")
            return
        cli_ctx.print_formatted(providers, PROVIDER_HEADERS, is_list=True)
    except Exception as e:
        cli_ctx.err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from e
    finally:
        cli_ctx.close()


@app.command("update")
def update(
    ctx: typer.Context,
    name: Annotated[str, typer.Argument(help="Provider name")],
    workspace: Annotated[str, typer.Option("--workspace", "-w", help="Workspace name or ID")],
    # Postgres options
    pg_host: Annotated[str | None, typer.Option("--pg-host", help="Postgres host")] = None,
    pg_port: Annotated[int | None, typer.Option("--pg-port", help="Postgres port")] = None,
    pg_database: Annotated[
        str | None, typer.Option("--pg-database", help="Postgres database")
    ] = None,
    pg_user: Annotated[str | None, typer.Option("--pg-user", help="Postgres user")] = None,
    pg_password_secret: Annotated[
        str | None,
        typer.Option("--pg-password-secret", help="Secret reference for Postgres password"),
    ] = None,
    pg_ssl_mode: Annotated[
        SSLMode | None,
        typer.Option(
            "--pg-ssl-mode",
            help="SSL mode for PostgreSQL connection",
            case_sensitive=False,
        ),
    ] = None,
    # Snowflake options
    snowflake_account: Annotated[
        str | None, typer.Option("--snowflake-account", help="Snowflake account")
    ] = None,
    snowflake_host: Annotated[
        str | None, typer.Option("--snowflake-host", help="Snowflake host override")
    ] = None,
    snowflake_warehouse: Annotated[
        str | None, typer.Option("--snowflake-warehouse", help="Snowflake warehouse")
    ] = None,
    snowflake_database: Annotated[
        str | None, typer.Option("--snowflake-database", help="Snowflake database")
    ] = None,
    snowflake_schema: Annotated[
        str | None, typer.Option("--snowflake-schema", help="Snowflake schema")
    ] = None,
    snowflake_auth_type: Annotated[
        str | None, typer.Option("--snowflake-auth-type", help="Snowflake auth type")
    ] = None,
    snowflake_username: Annotated[
        str | None, typer.Option("--snowflake-username", help="Snowflake username")
    ] = None,
    snowflake_password_secret: Annotated[
        str | None,
        typer.Option("--snowflake-password-secret", help="Secret reference for Snowflake password"),
    ] = None,
    snowflake_private_key_secret: Annotated[
        str | None,
        typer.Option(
            "--snowflake-private-key-secret", help="Secret reference for Snowflake private key"
        ),
    ] = None,
    snowflake_passphrase_secret: Annotated[
        str | None,
        typer.Option(
            "--snowflake-passphrase-secret",
            help="Secret reference for Snowflake private key passphrase",
        ),
    ] = None,
    snowflake_oauth_client_id: Annotated[
        str | None,
        typer.Option("--snowflake-oauth-client-id", help="Snowflake OAuth client ID"),
    ] = None,
    snowflake_oauth_client_secret: Annotated[
        str | None,
        typer.Option(
            "--snowflake-oauth-client-secret",
            help="Secret reference for Snowflake OAuth client secret",
        ),
    ] = None,
    snowflake_oauth_token: Annotated[
        str | None,
        typer.Option("--snowflake-oauth-token", help="Secret reference for Snowflake OAuth token"),
    ] = None,
    snowflake_role: Annotated[
        str | None, typer.Option("--snowflake-role", help="Snowflake role")
    ] = None,
    snowflake_login_timeout: Annotated[
        int | None,
        typer.Option("--snowflake-login-timeout", help="Snowflake login timeout in seconds"),
    ] = None,
    snowflake_request_timeout: Annotated[
        int | None,
        typer.Option("--snowflake-request-timeout", help="Snowflake request timeout in seconds"),
    ] = None,
    snowflake_session_param: Annotated[
        list[str] | None,
        typer.Option("--snowflake-session-param", help="Snowflake session param in KEY=VALUE form"),
    ] = None,
    # S3 options
    s3_bucket: Annotated[str | None, typer.Option("--s3-bucket", help="S3 bucket")] = None,
    s3_region: Annotated[str | None, typer.Option("--s3-region", help="S3 region")] = None,
    s3_access_key_id_secret: Annotated[
        str | None,
        typer.Option("--s3-access-key-id-secret", help="Secret reference for AWS access key ID"),
    ] = None,
    s3_secret_access_key_secret: Annotated[
        str | None,
        typer.Option(
            "--s3-secret-access-key-secret", help="Secret reference for AWS secret access key"
        ),
    ] = None,
    s3_endpoint: Annotated[
        str | None,
        typer.Option("--s3-endpoint", help="Custom S3 endpoint (for LocalStack/MinIO)"),
    ] = None,
    # Spark options
    spark_catalog: Annotated[
        list[str] | None,
        typer.Option("--spark-catalog", help="Spark catalog alias mapping in alias=provider form"),
    ] = None,
    spark_backend: Annotated[
        str | None,
        typer.Option("--spark-backend", help="Spark backend JSON object"),
    ] = None,
    spark_hadoop: Annotated[
        str | None, typer.Option("--spark-hadoop", help="Spark Hadoop JSON object")
    ] = None,
    spark_staging: Annotated[
        str | None, typer.Option("--spark-staging", help="Spark staging JSON object")
    ] = None,
    spark_driver_env: Annotated[
        list[str] | None,
        typer.Option("--spark-driver-env", help="Spark driver env in key=value form"),
    ] = None,
    spark_executor_env: Annotated[
        list[str] | None,
        typer.Option("--spark-executor-env", help="Spark executor env in key=value form"),
    ] = None,
    spark_deploy_mode: Annotated[
        str | None, typer.Option("--spark-deploy-mode", help="Spark deploy mode")
    ] = None,
    spark_driver_memory: Annotated[
        str | None, typer.Option("--spark-driver-memory", help="Spark driver memory")
    ] = None,
    spark_executor_memory: Annotated[
        str | None, typer.Option("--spark-executor-memory", help="Spark executor memory")
    ] = None,
    spark_executor_cores: Annotated[
        int | None, typer.Option("--spark-executor-cores", help="Spark executor cores")
    ] = None,
    spark_num_executors: Annotated[
        int | None, typer.Option("--spark-num-executors", help="Spark executor count")
    ] = None,
    spark_default_driver_memory: Annotated[
        str | None,
        typer.Option("--spark-default-driver-memory", help="Default Spark driver memory"),
    ] = None,
    spark_default_executor_memory: Annotated[
        str | None,
        typer.Option("--spark-default-executor-memory", help="Default Spark executor memory"),
    ] = None,
    spark_default_executor_cores: Annotated[
        int | None,
        typer.Option("--spark-default-executor-cores", help="Default Spark executor cores"),
    ] = None,
    spark_default_num_executors: Annotated[
        int | None,
        typer.Option("--spark-default-num-executors", help="Default Spark executor count"),
    ] = None,
    spark_default_shuffle_partitions: Annotated[
        int | None,
        typer.Option(
            "--spark-default-shuffle-partitions",
            help="Default Spark shuffle partition count",
        ),
    ] = None,
    spark_dependency_version: Annotated[
        list[str] | None,
        typer.Option(
            "--spark-dependency-version",
            help="Managed Spark dependency override in family=version form",
        ),
    ] = None,
    spark_extra_package: Annotated[
        list[str] | None,
        typer.Option("--spark-extra-package", help="Additional Spark package coordinate"),
    ] = None,
    spark_extra_jar: Annotated[
        list[str] | None,
        typer.Option("--spark-extra-jar", help="Additional Spark jar URI"),
    ] = None,
    spark_conf: Annotated[
        list[str] | None,
        typer.Option("--spark-conf", help="Advanced Spark config entry in key=value form"),
    ] = None,
    spark_clear_conf: Annotated[
        list[str] | None,
        typer.Option("--spark-clear-conf", help="Remove an advanced Spark config key"),
    ] = None,
    spark_runtime_backend: Annotated[
        str | None, typer.Option("--spark-runtime-backend", help="Spark runtime backend label")
    ] = None,
    spark_version: Annotated[
        str | None, typer.Option("--spark-version", help="Spark runtime version")
    ] = None,
    spark_scala_binary_version: Annotated[
        str | None,
        typer.Option("--spark-scala-binary-version", help="Spark Scala binary version"),
    ] = None,
    spark_submission_app_name: Annotated[
        str | None, typer.Option("--spark-submission-app-name", help="Default Spark app name")
    ] = None,
    spark_driver_cores: Annotated[
        int | None, typer.Option("--spark-driver-cores", help="Default Spark driver cores")
    ] = None,
    spark_properties_file: Annotated[
        str | None, typer.Option("--spark-properties-file", help="Spark properties file URI")
    ] = None,
    spark_repository: Annotated[
        list[str] | None, typer.Option("--spark-repository", help="Additional Spark repository URI")
    ] = None,
    spark_file: Annotated[
        list[str] | None, typer.Option("--spark-file", help="Spark submission file URI")
    ] = None,
    spark_archive: Annotated[
        list[str] | None, typer.Option("--spark-archive", help="Spark submission archive URI")
    ] = None,
    spark_py_file: Annotated[
        list[str] | None, typer.Option("--spark-py-file", help="Spark submission py-file URI")
    ] = None,
    spark_env: Annotated[
        list[str] | None, typer.Option("--spark-env", help="Spark submission env in key=value form")
    ] = None,
    spark_env_secret: Annotated[
        list[str] | None,
        typer.Option(
            "--spark-env-secret", help="Spark submission env secret in key=secret-ref form"
        ),
    ] = None,
    spark_queue: Annotated[
        str | None, typer.Option("--spark-queue", help="Spark submission queue")
    ] = None,
    spark_proxy_user: Annotated[
        str | None, typer.Option("--spark-proxy-user", help="Spark submission proxy user")
    ] = None,
    spark_kerberos_principal: Annotated[
        str | None, typer.Option("--spark-kerberos-principal", help="Spark Kerberos principal")
    ] = None,
    spark_kerberos_realm: Annotated[
        str | None, typer.Option("--spark-kerberos-realm", help="Spark Kerberos realm")
    ] = None,
    spark_kerberos_kdc_host: Annotated[
        str | None, typer.Option("--spark-kerberos-kdc-host", help="Spark Kerberos KDC host")
    ] = None,
    spark_kerberos_keytab_secret: Annotated[
        str | None,
        typer.Option("--spark-kerberos-keytab-secret", help="Secret reference for Spark keytab"),
    ] = None,
    spark_kerberos_krb5_conf_secret: Annotated[
        str | None,
        typer.Option("--spark-kerberos-krb5-conf-secret", help="Secret reference for krb5.conf"),
    ] = None,
    # DynamoDB options
    dynamodb_region: Annotated[
        str | None, typer.Option("--dynamodb-region", help="DynamoDB region")
    ] = None,
    dynamodb_access_key_id_secret: Annotated[
        str | None,
        typer.Option(
            "--dynamodb-access-key-id-secret",
            help="Secret reference for DynamoDB AWS access key ID",
        ),
    ] = None,
    dynamodb_secret_access_key_secret: Annotated[
        str | None,
        typer.Option(
            "--dynamodb-secret-access-key-secret",
            help="Secret reference for DynamoDB AWS secret access key",
        ),
    ] = None,
    dynamodb_endpoint: Annotated[
        str | None,
        typer.Option("--dynamodb-endpoint", help="Custom DynamoDB endpoint (for LocalStack)"),
    ] = None,
    dynamodb_table_prefix: Annotated[
        str | None,
        typer.Option("--dynamodb-table-prefix", help="DynamoDB table name prefix"),
    ] = None,
    # Redis options
    redis_host: Annotated[str | None, typer.Option("--redis-host", help="Redis host")] = None,
    redis_port: Annotated[int | None, typer.Option("--redis-port", help="Redis port")] = None,
    redis_password_secret: Annotated[
        str | None,
        typer.Option("--redis-password-secret", help="Secret reference for Redis password"),
    ] = None,
    redis_tls_mode: Annotated[
        RedisTLSMode | None,
        typer.Option("--redis-tls-mode", help="Redis TLS mode", case_sensitive=False),
    ] = None,
    redis_tls_ca_cert_path: Annotated[
        str | None,
        typer.Option("--redis-tls-ca-cert-path", help="Server-side path to Redis CA cert"),
    ] = None,
    redis_tls_ca_cert_secret: Annotated[
        str | None,
        typer.Option(
            "--redis-tls-ca-cert-secret", help="Secret reference containing Redis CA cert"
        ),
    ] = None,
    redis_tls_server_name: Annotated[
        str | None,
        typer.Option("--redis-tls-server-name", help="Redis TLS server name override"),
    ] = None,
    redis_tls_client_cert_path: Annotated[
        str | None,
        typer.Option("--redis-tls-client-cert-path", help="Server-side path to Redis client cert"),
    ] = None,
    redis_tls_client_cert_secret: Annotated[
        str | None,
        typer.Option(
            "--redis-tls-client-cert-secret",
            help="Secret reference containing Redis client cert",
        ),
    ] = None,
    redis_tls_client_key_path: Annotated[
        str | None,
        typer.Option("--redis-tls-client-key-path", help="Server-side path to Redis client key"),
    ] = None,
    redis_tls_client_key_secret: Annotated[
        str | None,
        typer.Option(
            "--redis-tls-client-key-secret",
            help="Secret reference containing Redis client key",
        ),
    ] = None,
    redis_tls_insecure_skip_verify: Annotated[
        bool | None,
        typer.Option("--redis-tls-insecure-skip-verify", help="Skip Redis TLS verification"),
    ] = None,
    redis_tls_min_version: Annotated[
        str | None,
        typer.Option("--redis-tls-min-version", help="Redis TLS minimum version"),
    ] = None,
    # Update options
    force: Annotated[
        bool,
        typer.Option("--force", "-f", help="Force potentially breaking changes (e.g., host)"),
    ] = False,
    skip_health_check: Annotated[
        bool,
        typer.Option(
            "--skip-health-check", help="Skip the synchronous connectivity check on this update"
        ),
    ] = False,
    disable_monitoring: Annotated[
        bool,
        typer.Option(
            "--disable-monitoring",
            help="Disable all recurring health checks (implies --skip-health-check)",
        ),
    ] = False,
) -> None:
    """Update an existing provider."""
    cli_ctx = _get_context(ctx)

    spark_kwargs = {
        "spark_catalog": spark_catalog,
        "spark_backend": spark_backend,
        "spark_hadoop": spark_hadoop,
        "spark_staging": spark_staging,
        "spark_driver_env": spark_driver_env,
        "spark_executor_env": spark_executor_env,
        "spark_deploy_mode": spark_deploy_mode,
        "spark_driver_memory": spark_driver_memory,
        "spark_executor_memory": spark_executor_memory,
        "spark_executor_cores": spark_executor_cores,
        "spark_num_executors": spark_num_executors,
        "spark_default_driver_memory": spark_default_driver_memory,
        "spark_default_executor_memory": spark_default_executor_memory,
        "spark_default_executor_cores": spark_default_executor_cores,
        "spark_default_num_executors": spark_default_num_executors,
        "spark_default_shuffle_partitions": spark_default_shuffle_partitions,
        "spark_dependency_version": spark_dependency_version,
        "spark_extra_package": spark_extra_package,
        "spark_extra_jar": spark_extra_jar,
        "spark_conf": spark_conf,
        "spark_clear_conf": spark_clear_conf,
        "spark_runtime_backend": spark_runtime_backend,
        "spark_version": spark_version,
        "spark_scala_binary_version": spark_scala_binary_version,
        "spark_submission_app_name": spark_submission_app_name,
        "spark_driver_cores": spark_driver_cores,
        "spark_properties_file": spark_properties_file,
        "spark_repository": spark_repository,
        "spark_file": spark_file,
        "spark_archive": spark_archive,
        "spark_py_file": spark_py_file,
        "spark_env": spark_env,
        "spark_env_secret": spark_env_secret,
        "spark_queue": spark_queue,
        "spark_proxy_user": spark_proxy_user,
        "spark_kerberos_principal": spark_kerberos_principal,
        "spark_kerberos_realm": spark_kerberos_realm,
        "spark_kerberos_kdc_host": spark_kerberos_kdc_host,
        "spark_kerberos_keytab_secret": spark_kerberos_keytab_secret,
        "spark_kerberos_krb5_conf_secret": spark_kerberos_krb5_conf_secret,
    }
    if _has_explicit_spark_update_flags(**spark_kwargs):
        try:
            build_update_patch(ProviderType.SPARK, **spark_kwargs)
        except ValueError as err:
            cli_ctx.err_console.print(f"[red]Error:[/red] {err}")
            raise typer.Exit(1) from err

    client = cli_ctx.get_client()

    # Resolve workspace name/ID to UUID
    try:
        workspace_id = resolve_workspace_id(client, workspace)
    except NotFoundError:
        cli_ctx.err_console.print(f"[red]Error:[/red] Workspace '{workspace}' not found")
        raise typer.Exit(1) from None

    try:
        # Get existing provider to determine type
        existing = client.providers(workspace_id).get(name)
        config = build_update_patch(
            existing.type,
            pg_host=pg_host,
            pg_port=pg_port,
            pg_database=pg_database,
            pg_user=pg_user,
            pg_password_secret=pg_password_secret,
            pg_ssl_mode=pg_ssl_mode,
            snowflake_account=snowflake_account,
            snowflake_host=snowflake_host,
            snowflake_warehouse=snowflake_warehouse,
            snowflake_database=snowflake_database,
            snowflake_schema=snowflake_schema,
            snowflake_auth_type=snowflake_auth_type,
            snowflake_username=snowflake_username,
            snowflake_password_secret=snowflake_password_secret,
            snowflake_private_key_secret=snowflake_private_key_secret,
            snowflake_passphrase_secret=snowflake_passphrase_secret,
            snowflake_oauth_client_id=snowflake_oauth_client_id,
            snowflake_oauth_client_secret=snowflake_oauth_client_secret,
            snowflake_oauth_token=snowflake_oauth_token,
            snowflake_role=snowflake_role,
            snowflake_login_timeout=snowflake_login_timeout,
            snowflake_request_timeout=snowflake_request_timeout,
            snowflake_session_params=_parse_session_params(snowflake_session_param),
            s3_bucket=s3_bucket,
            s3_region=s3_region,
            s3_access_key_id_secret=s3_access_key_id_secret,
            s3_secret_access_key_secret=s3_secret_access_key_secret,
            s3_endpoint=s3_endpoint,
            spark_catalog=spark_catalog,
            spark_backend=spark_backend,
            spark_hadoop=spark_hadoop,
            spark_staging=spark_staging,
            spark_driver_env=spark_driver_env,
            spark_executor_env=spark_executor_env,
            spark_deploy_mode=spark_deploy_mode,
            spark_driver_memory=spark_driver_memory,
            spark_executor_memory=spark_executor_memory,
            spark_executor_cores=spark_executor_cores,
            spark_num_executors=spark_num_executors,
            spark_default_driver_memory=spark_default_driver_memory,
            spark_default_executor_memory=spark_default_executor_memory,
            spark_default_executor_cores=spark_default_executor_cores,
            spark_default_num_executors=spark_default_num_executors,
            spark_default_shuffle_partitions=spark_default_shuffle_partitions,
            spark_dependency_version=spark_dependency_version,
            spark_extra_package=spark_extra_package,
            spark_extra_jar=spark_extra_jar,
            spark_conf=spark_conf,
            spark_clear_conf=spark_clear_conf,
            dynamodb_region=dynamodb_region,
            dynamodb_access_key_id_secret=dynamodb_access_key_id_secret,
            dynamodb_secret_access_key_secret=dynamodb_secret_access_key_secret,
            dynamodb_endpoint=dynamodb_endpoint,
            dynamodb_table_prefix=dynamodb_table_prefix,
            redis_host=redis_host,
            redis_port=redis_port,
            redis_password_secret=redis_password_secret,
            redis_tls_mode=redis_tls_mode,
            redis_tls_ca_cert_path=redis_tls_ca_cert_path,
            redis_tls_ca_cert_secret=redis_tls_ca_cert_secret,
            redis_tls_server_name=redis_tls_server_name,
            redis_tls_client_cert_path=redis_tls_client_cert_path,
            redis_tls_client_cert_secret=redis_tls_client_cert_secret,
            redis_tls_client_key_path=redis_tls_client_key_path,
            redis_tls_client_key_secret=redis_tls_client_key_secret,
            redis_tls_insecure_skip_verify=redis_tls_insecure_skip_verify,
            redis_tls_min_version=redis_tls_min_version,
        )

        provider = client.providers(workspace_id).update(
            name=name,
            config=config,
            force=force,
            skip_health_check=skip_health_check,
            disable_monitoring=disable_monitoring,
            provider_type=existing.type,
        )
        cli_ctx.print_formatted(provider, PROVIDER_HEADERS)
    except NotFoundError:
        cli_ctx.err_console.print("[red]Error:[/red] Provider not found")
        raise typer.Exit(1) from None
    except ValueError as err:
        cli_ctx.err_console.print(f"[red]Error:[/red] {err}")
        raise typer.Exit(1) from err
    except Exception as e:
        cli_ctx.err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from e
    finally:
        cli_ctx.close()


@app.command("delete")
def delete(
    ctx: typer.Context,
    name: Annotated[str, typer.Argument(help="Provider name")],
    workspace: Annotated[str, typer.Option("--workspace", "-w", help="Workspace name or ID")],
    confirm: Annotated[
        bool,
        typer.Option("--yes", "-y", "--force", help="Skip confirmation"),
    ] = False,
) -> None:
    """Delete a provider."""
    cli_ctx = _get_context(ctx)
    client = cli_ctx.get_client()

    if not confirm:
        confirmed = typer.confirm(f"Are you sure you want to delete provider {name}?")
        if not confirmed:
            cli_ctx.console.print("Cancelled")
            raise typer.Exit(0)

    try:
        workspace_id = resolve_workspace_id(client, workspace)
        client.providers(workspace_id).delete(name)
        cli_ctx.console.print(f"Provider {name} deleted")
    except NotFoundError:
        cli_ctx.err_console.print("[red]Error:[/red] Provider not found")
        raise typer.Exit(1) from None
    except Exception as e:
        cli_ctx.err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from e
    finally:
        cli_ctx.close()
