"""Authentication commands for Featureform CLI."""

import sys
from typing import Annotated, cast

import typer
from click.core import ParameterSource
from rich.console import Console
from rich.panel import Panel

from featureform._internal.logging import get_logger
from featureform.auth import (
    AuthenticationError,
    get_device_authorization,
    poll_for_token,
)
from featureform.auth.runtime import build_runtime_auth_service, resolve_auth_discovery_timeout
from featureform.cli import env
from featureform.cli.admin_client import AdminClient, AdminClientError
from featureform.cli.auth import (
    AuthDiscoveryError,
    AuthService,
    StorageUnavailableError,
)
from featureform.cli.utils import CLIContext

# Module logger
_logger = get_logger("featureform.cli.auth")

# Rich console for output
console = Console()

app = typer.Typer(
    name="auth",
    help="Authentication commands",
    no_args_is_help=True,
    rich_markup_mode="rich",
)


def do_login(
    issuer_url: str | None = None,
    client_id: str = "featureform-cli",
    scope: str = "openid",
) -> str | None:
    """Perform device authorization login flow.

    Args:
        issuer_url: OIDC issuer URL.
        client_id: OAuth2 client ID.
        scope: OAuth2 scope.

    Returns:
        Access token on success, None on failure.
    """
    if not issuer_url:
        console.print(
            "[red]Error:[/red] --issuer-url is required. "
            "Set FEATUREFORM_ISSUER_URL or pass --issuer-url.",
            style="bold",
        )
        raise typer.Exit(code=1)

    _logger.info("starting_device_authorization_login", issuer_url=issuer_url)

    try:
        # Initiate device authorization
        console.print("[dim]Initiating device authorization...[/dim]")
        device_resp = get_device_authorization(
            issuer_url=issuer_url,
            client_id=client_id,
            scope=scope,
        )

        user_code = device_resp.get("user_code", "N/A")
        verification_uri = device_resp.get("verification_uri", "")
        verification_uri_complete = device_resp.get("verification_uri_complete", "")
        device_code = device_resp.get("device_code", "")
        interval = device_resp.get("interval", 5)

        # Display login instructions
        uri_to_show = verification_uri_complete or verification_uri
        console.print(
            Panel(
                f"[bold]Open this URL in your browser:[/bold]\n\n"
                f"  [link={uri_to_show}]{uri_to_show}[/link]\n\n"
                f"[bold]Enter code:[/bold] [cyan]{user_code}[/cyan]",
                title="[bold green]Login Required[/bold green]",
                border_style="green",
            )
        )
        console.print("\n[dim]Waiting for authentication...[/dim]")

        # Poll for token
        token_response = poll_for_token(
            issuer_url=issuer_url,
            client_id=client_id,
            device_code=device_code,
            interval=interval,
        )

        console.print("[green]✓ Successfully authenticated![/green]")
        _logger.info("login_successful")

        # Display the token for the user
        console.print(
            f"\n[bold]Access Token:[/bold]\n[dim]{token_response.access_token[:50]}...[/dim]"
        )
        console.print(
            "\n[yellow]Tip:[/yellow] Set FEATUREFORM_TOKEN environment variable to use this token."
        )

        return token_response.access_token

    except AuthenticationError as e:
        _logger.error("login_failed", error=str(e))
        console.print(f"[red]Authentication failed:[/red] {e}")
        raise typer.Exit(code=1) from e


def _build_auth_service(cli_ctx: CLIContext) -> AuthService:
    return build_runtime_auth_service(
        timeout=cli_ctx.timeout,
        timeout_explicit=cli_ctx.timeout_explicit,
        verify_ssl=cli_ctx.verify_ssl,
        no_tls=cli_ctx.no_tls,
        ca_cert_path=cli_ctx.ca_cert_path,
        client_cert_path=cli_ctx.client_cert_path,
        client_key_path=cli_ctx.client_key_path,
        config_path=cli_ctx.config_path,
    )


_resolve_auth_discovery_timeout = resolve_auth_discovery_timeout


build_auth_service = _build_auth_service


def _get_context(ctx: typer.Context) -> CLIContext:
    cli_ctx: CLIContext = ctx.obj["context"]
    return cli_ctx


def _resolve_password_grant_client_id(ctx: typer.Context, client_id: str) -> str | None:
    get_parameter_source = getattr(ctx, "get_parameter_source", None)
    if (
        callable(get_parameter_source)
        and get_parameter_source("client_id") == ParameterSource.COMMANDLINE
    ):
        return client_id
    env_client_id = env.env_or_default("FF_AUTH_PASSWORD_CLIENT_ID", "")
    return env_client_id or None


def _read_password(*, password_stdin: bool) -> str:
    if password_stdin:
        password = sys.stdin.read().rstrip("\r\n")
        if not password:
            console.print("[red]Error:[/red] No password received on stdin.")
            raise typer.Exit(code=1)
        return password

    if not sys.stdin.isatty():
        console.print(
            "[red]Error:[/red] Password login requires a terminal prompt or [bold]--password-stdin[/bold]."
        )
        raise typer.Exit(code=1)

    password = cast(str, typer.prompt("Password", hide_input=True))
    if not password:
        console.print("[red]Error:[/red] Password cannot be empty.")
        raise typer.Exit(code=1)
    return password


@app.command("login")
def login_command(
    ctx: typer.Context,
    profile: Annotated[
        str | None,
        typer.Option("--profile", help="CLI profile to log into"),
    ] = None,
    issuer_url: Annotated[
        str | None,
        typer.Option("--issuer-url", help="OIDC issuer URL", envvar="FEATUREFORM_ISSUER_URL"),
    ] = None,
    client_id: Annotated[
        str,
        typer.Option("--client-id", help="OAuth2 client ID", envvar="FEATUREFORM_LOGIN_CLIENT_ID"),
    ] = "featureform-cli",
    scope: Annotated[
        str,
        typer.Option("--scope", help="OAuth2 scope"),
    ] = "openid",
    username: Annotated[
        str | None,
        typer.Option("--username", help="Username for explicit dev password grant"),
    ] = None,
    password_stdin: Annotated[
        bool,
        typer.Option("--password-stdin", help="Read the password from stdin"),
    ] = False,
) -> None:
    """Login using browser-based SSO (Device Authorization Flow)."""
    cli_ctx = _get_context(ctx)

    if password_stdin and not username:
        console.print("[red]Error:[/red] --password-stdin requires --username.")
        raise typer.Exit(code=1)

    service = _build_auth_service(cli_ctx)
    has_profile_context = (
        bool(cli_ctx.base_url)
        or profile is not None
        or service.profiles.get_active_profile() is not None
    )

    if username:
        resolved_client_id = _resolve_password_grant_client_id(ctx, client_id)
        password = _read_password(password_stdin=password_stdin)

        if has_profile_context:
            try:
                result = service.login_password(
                    username=username,
                    password=password,
                    server_url=cli_ctx.base_url or None,
                    profile_name=profile,
                    transport=cli_ctx.transport.value,
                    no_tls=cli_ctx.no_tls,
                    client_id=resolved_client_id,
                    scope=scope,
                )
            except (ValueError, AuthDiscoveryError, StorageUnavailableError) as exc:
                if issuer_url:
                    try:
                        if not resolved_client_id:
                            raise ValueError(
                                "Password login requires a password-grant client ID when server discovery "
                                "does not advertise one. Set FF_AUTH_PASSWORD_CLIENT_ID or pass --client-id."
                            )
                        result = service.login_password_direct(
                            username=username,
                            password=password,
                            issuer_url=issuer_url,
                            client_id=resolved_client_id,
                            server_url=cli_ctx.base_url or None,
                            profile_name=profile,
                            transport=cli_ctx.transport.value,
                            no_tls=cli_ctx.no_tls,
                            scope=scope,
                        )
                    except (
                        AuthenticationError,
                        ValueError,
                        StorageUnavailableError,
                    ) as fallback_exc:
                        console.print(f"[red]Error:[/red] {fallback_exc}")
                        raise typer.Exit(code=1) from fallback_exc
                else:
                    console.print(f"[red]Error:[/red] {exc}")
                    if isinstance(exc, AuthDiscoveryError):
                        console.print(
                            "[yellow]Hint:[/yellow] Retry with [bold]--issuer-url[/bold] and [bold]--client-id[/bold]."
                        )
                    raise typer.Exit(code=1) from exc

            if result.replaced_existing_session:
                console.print(
                    f"[green]✓ Login complete.[/green] Updated session for profile [cyan]{result.profile_name}[/cyan]."
                )
            else:
                console.print(
                    f"[green]✓ Login complete.[/green] Active profile: [cyan]{result.profile_name}[/cyan]."
                )
            return

        console.print(
            "[red]Error:[/red] Password login requires [bold]--server[/bold] or an existing profile."
        )
        raise typer.Exit(code=1)

    if issuer_url:
        if not has_profile_context:
            console.print(
                "[red]Error:[/red] Device login requires [bold]--server[/bold] or an existing profile."
            )
            raise typer.Exit(code=1)
        try:
            result = service.login_device_direct(
                issuer_url=issuer_url,
                client_id=client_id,
                server_url=cli_ctx.base_url or None,
                profile_name=profile,
                transport=cli_ctx.transport.value,
                no_tls=cli_ctx.no_tls,
                scope=scope,
            )
        except (AuthenticationError, ValueError, StorageUnavailableError) as exc:
            console.print(f"[red]Error:[/red] {exc}")
            raise typer.Exit(code=1) from exc

        if result.replaced_existing_session:
            console.print(
                f"[green]✓ Login complete.[/green] Updated session for profile [cyan]{result.profile_name}[/cyan]."
            )
        else:
            console.print(
                f"[green]✓ Login complete.[/green] Active profile: [cyan]{result.profile_name}[/cyan]."
            )
        return

    try:
        result = service.login(
            server_url=cli_ctx.base_url or None,
            profile_name=profile,
            transport=cli_ctx.transport.value,
            no_tls=cli_ctx.no_tls,
        )
    except (ValueError, AuthDiscoveryError, StorageUnavailableError) as exc:
        console.print(f"[red]Error:[/red] {exc}")
        if isinstance(exc, AuthDiscoveryError):
            console.print(
                "[yellow]Hint:[/yellow] Retry with [bold]--issuer-url[/bold] and [bold]--client-id[/bold]."
            )
        raise typer.Exit(code=1) from exc

    if result.replaced_existing_session:
        console.print(
            f"[green]✓ Login complete.[/green] Updated session for profile [cyan]{result.profile_name}[/cyan]."
        )
    else:
        console.print(
            f"[green]✓ Login complete.[/green] Active profile: [cyan]{result.profile_name}[/cyan]."
        )


@app.command("status")
def status_command(ctx: typer.Context) -> None:
    """Show current authentication status."""
    cli_ctx = _get_context(ctx)
    token = env.featureform_token()
    if token:
        console.print("[green]✓ Authenticated via FEATUREFORM_TOKEN[/green]")
    elif cli_ctx.client_id and cli_ctx.issuer_url:
        console.print("[green]✓ Service account credentials configured[/green]")
        console.print(f"  Client ID: [dim]{cli_ctx.client_id}[/dim]")
        console.print(f"  Issuer URL: [dim]{cli_ctx.issuer_url}[/dim]")

    try:
        status = _build_auth_service(cli_ctx).status(env_token=token)
    except StorageUnavailableError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc
    if status.profile_name is None:
        console.print("[yellow]! No profile configured[/yellow]")
        console.print("  Run 'ff auth login --server ...' or set a config profile.")
        return

    console.print(f"Profile: [cyan]{status.profile_name}[/cyan]")
    console.print(f"Server: [dim]{status.server}[/dim]")
    if status.auth_source:
        console.print(f"Auth source: [dim]{status.auth_source}[/dim]")
    if status.discovery_state == "auth_disabled":
        console.print("[green]✓ Authentication is disabled on this server[/green]")
    elif status.discovery_state == "unavailable":
        console.print("[yellow]! Discovery currently unavailable[/yellow]")
    elif status.discovery_state == "live":
        console.print("[green]✓ Discovery metadata reachable[/green]")
    if status.message:
        console.print(f"Detail: [dim]{status.message}[/dim]")

    if status.session_state == "no_session":
        console.print("[yellow]! No stored interactive session[/yellow]")
    elif status.session_state == "env_override":
        console.print("[green]✓ Using environment-based auth[/green]")
    elif status.session_state == "refresh_required":
        console.print(
            "[yellow]! Stored session requires refresh before the next authenticated call[/yellow]"
        )
    elif status.session_state == "storage_unavailable":
        console.print("[red]Error:[/red] Interactive session storage is unavailable")
    else:
        console.print("[green]✓ Stored interactive session present[/green]")


@app.command("logout")
def logout_command(ctx: typer.Context) -> None:
    """Clear the stored interactive session for the active profile."""
    try:
        result = _build_auth_service(_get_context(ctx)).logout()
    except StorageUnavailableError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc
    if result.profile_name is None:
        console.print("[yellow]! No active profile configured[/yellow]")
        return
    if result.removed_session:
        console.print(f"[green]✓ Logged out of profile[/green] [cyan]{result.profile_name}[/cyan]")
        return
    console.print(
        f"[yellow]! No stored interactive session for profile[/yellow] [cyan]{result.profile_name}[/cyan]"
    )


@app.command("token")
def token_command(ctx: typer.Context) -> None:
    """Print the effective access token for the current invocation."""
    cli_ctx = _get_context(ctx)
    try:
        token = _build_auth_service(cli_ctx).resolve_access_token(
            env_token=cli_ctx.token,
            client_id=cli_ctx.client_id,
            client_secret=cli_ctx.client_secret,
            issuer_url=cli_ctx.issuer_url,
            server_url=cli_ctx.base_url,
            transport=cli_ctx.transport.value,
        )
    except (ValueError, StorageUnavailableError) as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc
    if not token:
        console.print("[red]Error:[/red] No access token available.")
        raise typer.Exit(code=1)
    console.print(token)


@app.command("whoami")
def whoami_command(ctx: typer.Context) -> None:
    """Show the current authenticated principal."""
    cli_ctx = _get_context(ctx)
    try:
        cli_ctx.print_formatted(AdminClient(cli_ctx).whoami(), ["field", "value"])
    except AdminClientError as exc:
        console.print(f"[red]Error:[/red] {exc.message}")
        raise typer.Exit(code=1) from exc
