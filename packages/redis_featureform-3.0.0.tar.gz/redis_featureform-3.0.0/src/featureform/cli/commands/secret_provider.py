"""Secret Provider CLI commands."""

from typing import Annotated, cast

import typer

from featureform._internal.secret_refs import secret_ref_from_string
from featureform.cli.commands._common import resolve_workspace_id
from featureform.cli.utils import CLIContext
from featureform.errors import NotFoundError
from featureform.types import (
    AWSSecretsManagerSecretConfig,
    EnvSecretConfig,
    KubernetesSecretConfig,
    SecretProviderType,
    SecretRef,
    VaultSecretConfig,
)

app = typer.Typer(
    name="secret-provider",
    help="Manage secret providers",
    no_args_is_help=True,
)

SECRET_PROVIDER_HEADERS = ["Name", "Type", "Workspace ID", "Created At", "Updated At"]


def _get_context(ctx: typer.Context) -> CLIContext:
    """Get CLI context."""
    cli_ctx: CLIContext = ctx.obj["context"]
    return cli_ctx


def _coerce_secret_ref(value: SecretRef | str | None) -> SecretRef | None:
    if isinstance(value, str):
        return secret_ref_from_string(value)
    return value


@app.command("register")
def register(
    ctx: typer.Context,
    name: Annotated[str, typer.Argument(help="Secret provider name")],
    workspace: Annotated[str, typer.Option("--workspace", "-w", help="Workspace name or ID")],
    provider_type: Annotated[
        SecretProviderType,
        typer.Option("--type", "-t", help="Secret provider type", case_sensitive=False),
    ],
    # Vault options
    vault_address: Annotated[
        str | None, typer.Option("--vault-address", help="Vault server address")
    ] = None,
    vault_token_path: Annotated[
        str | None, typer.Option("--vault-token-path", help="Path to Vault token file")
    ] = None,
    vault_namespace: Annotated[
        str | None, typer.Option("--vault-namespace", help="Vault namespace")
    ] = None,
    # Kubernetes options
    k8s_namespace: Annotated[
        str | None, typer.Option("--k8s-namespace", help="Kubernetes namespace")
    ] = None,
    k8s_secret_name: Annotated[
        str | None, typer.Option("--k8s-secret-name", help="Kubernetes secret name")
    ] = None,
    # Env options
    env_prefix: Annotated[
        str, typer.Option("--env-prefix", help="Environment variable prefix")
    ] = "",
    # AWS Secrets Manager options
    aws_region: Annotated[str | None, typer.Option("--aws-region", help="AWS region")] = None,
    aws_secret_name: Annotated[
        str | None, typer.Option("--aws-secret-name", help="Default AWS secret name")
    ] = None,
    aws_endpoint: Annotated[
        str | None, typer.Option("--aws-endpoint", help="Optional custom AWS endpoint")
    ] = None,
    aws_access_key_id_secret: Annotated[
        str | None,
        typer.Option(
            "--aws-access-key-id-secret",
            help="Secret reference for AWS access key ID",
        ),
    ] = None,
    aws_secret_access_key_secret: Annotated[
        str | None,
        typer.Option(
            "--aws-secret-access-key-secret",
            help="Secret reference for AWS secret access key",
        ),
    ] = None,
    aws_session_token_secret: Annotated[
        str | None,
        typer.Option("--aws-session-token-secret", help="Secret reference for AWS session token"),
    ] = None,
) -> None:
    """Register a new secret provider."""
    cli_ctx = _get_context(ctx)
    client = cli_ctx.get_client()

    # Resolve workspace name/ID to UUID
    try:
        workspace_id = resolve_workspace_id(client, workspace)
    except NotFoundError:
        cli_ctx.err_console.print(f"[red]Error:[/red] Workspace '{workspace}' not found")
        raise typer.Exit(1) from None

    # Build config based on provider type
    config: (
        VaultSecretConfig | KubernetesSecretConfig | EnvSecretConfig | AWSSecretsManagerSecretConfig
    )
    if provider_type == SecretProviderType.VAULT:
        if not vault_address:
            cli_ctx.err_console.print("[red]Error:[/red] --vault-address is required for vault")
            raise typer.Exit(1)
        config = VaultSecretConfig(
            address=vault_address,
            token_path=vault_token_path,
            namespace=vault_namespace,
        )
    elif provider_type == SecretProviderType.K8S:
        if not k8s_namespace or not k8s_secret_name:
            cli_ctx.err_console.print(
                "[red]Error:[/red] --k8s-namespace and --k8s-secret-name are required for k8s"
            )
            raise typer.Exit(1)
        config = KubernetesSecretConfig(
            namespace=k8s_namespace,
            secret_name=k8s_secret_name,
        )
    elif provider_type == SecretProviderType.ENV:
        config = EnvSecretConfig(prefix=env_prefix, allow_defaults=False)
    elif provider_type == SecretProviderType.AWS:
        if not aws_region:
            cli_ctx.err_console.print("[red]Error:[/red] --aws-region is required for AWS")
            raise typer.Exit(1)
        config = AWSSecretsManagerSecretConfig(
            region=aws_region,
            secret_name=aws_secret_name,
            endpoint=aws_endpoint,
            access_key_id_secret=_coerce_secret_ref(aws_access_key_id_secret),
            secret_access_key_secret=_coerce_secret_ref(aws_secret_access_key_secret),
            session_token_secret=_coerce_secret_ref(aws_session_token_secret),
        )
    else:
        cli_ctx.err_console.print(
            f"[red]Error:[/red] Secret provider type {provider_type} not yet supported in CLI"
        )
        raise typer.Exit(1)

    try:
        secret_provider = client.secret_providers(workspace_id).register(
            name=name,
            provider_type=provider_type,
            config=config,
        )
        cli_ctx.print_formatted(secret_provider, SECRET_PROVIDER_HEADERS)
    except Exception as e:
        cli_ctx.err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from e
    finally:
        cli_ctx.close()


@app.command("get")
def get(
    ctx: typer.Context,
    name: Annotated[str, typer.Argument(help="Secret provider name")],
    workspace: Annotated[str, typer.Option("--workspace", "-w", help="Workspace name or ID")],
) -> None:
    """Get a secret provider by name."""
    cli_ctx = _get_context(ctx)
    client = cli_ctx.get_client()

    try:
        workspace_id = resolve_workspace_id(client, workspace)
        secret_provider = client.secret_providers(workspace_id).get(name)
        cli_ctx.print_formatted(secret_provider, SECRET_PROVIDER_HEADERS)
    except NotFoundError:
        cli_ctx.err_console.print("[red]Error:[/red] Secret provider not found")
        raise typer.Exit(1) from None
    except Exception as e:
        cli_ctx.err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from e
    finally:
        cli_ctx.close()


@app.command("list")
def list_secret_providers(
    ctx: typer.Context,
    workspace: Annotated[str, typer.Option("--workspace", "-w", help="Workspace name or ID")],
) -> None:
    """List all secret providers in a workspace."""
    cli_ctx = _get_context(ctx)
    client = cli_ctx.get_client()

    try:
        workspace_id = resolve_workspace_id(client, workspace)
        secret_providers = client.secret_providers(workspace_id).list()
        if not secret_providers:
            # For structured output formats, output empty list
            if cli_ctx.output_format in ("json", "yaml"):
                cli_ctx.print_formatted([], SECRET_PROVIDER_HEADERS, is_list=True)
            else:
                cli_ctx.console.print("No secret providers found")
            return
        cli_ctx.print_formatted(secret_providers, SECRET_PROVIDER_HEADERS, is_list=True)
    except Exception as e:
        cli_ctx.err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from e
    finally:
        cli_ctx.close()


@app.command("update")
def update(
    ctx: typer.Context,
    name: Annotated[str, typer.Argument(help="Secret provider name")],
    workspace: Annotated[str, typer.Option("--workspace", "-w", help="Workspace name or ID")],
    # Vault options
    vault_address: Annotated[
        str | None, typer.Option("--vault-address", help="Vault server address")
    ] = None,
    vault_token_path: Annotated[
        str | None, typer.Option("--vault-token-path", help="Path to Vault token file")
    ] = None,
    vault_namespace: Annotated[
        str | None, typer.Option("--vault-namespace", help="Vault namespace")
    ] = None,
    # Kubernetes options
    k8s_namespace: Annotated[
        str | None, typer.Option("--k8s-namespace", help="Kubernetes namespace")
    ] = None,
    k8s_secret_name: Annotated[
        str | None, typer.Option("--k8s-secret-name", help="Kubernetes secret name")
    ] = None,
    # Env options
    env_prefix: Annotated[
        str | None, typer.Option("--env-prefix", help="Environment variable prefix")
    ] = None,
    # AWS Secrets Manager options
    aws_region: Annotated[str | None, typer.Option("--aws-region", help="AWS region")] = None,
    aws_secret_name: Annotated[
        str | None, typer.Option("--aws-secret-name", help="Default AWS secret name")
    ] = None,
    aws_endpoint: Annotated[
        str | None, typer.Option("--aws-endpoint", help="Optional custom AWS endpoint")
    ] = None,
    aws_access_key_id_secret: Annotated[
        str | None,
        typer.Option(
            "--aws-access-key-id-secret",
            help="Secret reference for AWS access key ID",
        ),
    ] = None,
    aws_secret_access_key_secret: Annotated[
        str | None,
        typer.Option(
            "--aws-secret-access-key-secret",
            help="Secret reference for AWS secret access key",
        ),
    ] = None,
    aws_session_token_secret: Annotated[
        str | None,
        typer.Option("--aws-session-token-secret", help="Secret reference for AWS session token"),
    ] = None,
    # Update options
    force: Annotated[
        bool,
        typer.Option("--force", "-f", help="Force potentially breaking changes (e.g., address)"),
    ] = False,
) -> None:
    """Update an existing secret provider."""
    cli_ctx = _get_context(ctx)
    client = cli_ctx.get_client()

    try:
        # Resolve workspace name/ID to UUID
        workspace_id = resolve_workspace_id(client, workspace)

        # Get existing provider to determine type
        existing = client.secret_providers(workspace_id).get(name)

        # Build config based on provider type, merging with existing values.
        # Use `is not None` checks to preserve valid falsy values like empty strings.
        config: (
            VaultSecretConfig
            | KubernetesSecretConfig
            | EnvSecretConfig
            | AWSSecretsManagerSecretConfig
        )
        if existing.type == SecretProviderType.VAULT:
            existing_vault = cast(VaultSecretConfig, existing.config)
            config = VaultSecretConfig(
                address=(vault_address if vault_address is not None else existing_vault.address),
                mount_path=existing_vault.mount_path,
                token_path=(
                    vault_token_path if vault_token_path is not None else existing_vault.token_path
                ),
                namespace=(
                    vault_namespace if vault_namespace is not None else existing_vault.namespace
                ),
            )
        elif existing.type == SecretProviderType.K8S:
            existing_k8s = cast(KubernetesSecretConfig, existing.config)
            config = KubernetesSecretConfig(
                namespace=(k8s_namespace if k8s_namespace is not None else existing_k8s.namespace),
                secret_name=(
                    k8s_secret_name if k8s_secret_name is not None else existing_k8s.secret_name
                ),
            )
        elif existing.type == SecretProviderType.ENV:
            existing_env = (
                existing.config
                if isinstance(existing.config, EnvSecretConfig)
                else EnvSecretConfig.model_validate(existing.config)
            )
            config = EnvSecretConfig(
                prefix=env_prefix if env_prefix is not None else existing_env.prefix,
                allow_defaults=existing_env.allow_defaults,
            )
        elif existing.type == SecretProviderType.AWS:
            existing_aws = (
                existing.config
                if isinstance(existing.config, AWSSecretsManagerSecretConfig)
                else AWSSecretsManagerSecretConfig.model_validate(existing.config)
            )
            config = AWSSecretsManagerSecretConfig(
                region=aws_region if aws_region is not None else existing_aws.region,
                secret_name=(
                    aws_secret_name if aws_secret_name is not None else existing_aws.secret_name
                ),
                endpoint=aws_endpoint if aws_endpoint is not None else existing_aws.endpoint,
                access_key_id_secret=(
                    _coerce_secret_ref(aws_access_key_id_secret)
                    if aws_access_key_id_secret is not None
                    else existing_aws.access_key_id_secret
                ),
                secret_access_key_secret=(
                    _coerce_secret_ref(aws_secret_access_key_secret)
                    if aws_secret_access_key_secret is not None
                    else existing_aws.secret_access_key_secret
                ),
                session_token_secret=(
                    _coerce_secret_ref(aws_session_token_secret)
                    if aws_session_token_secret is not None
                    else existing_aws.session_token_secret
                ),
            )
        else:
            cli_ctx.err_console.print(
                f"[red]Error:[/red] Secret provider type {existing.type} not yet supported"
            )
            raise typer.Exit(1)

        secret_provider = client.secret_providers(workspace_id).update(
            name=name,
            config=config,
            force=force,
        )
        cli_ctx.print_formatted(secret_provider, SECRET_PROVIDER_HEADERS)
    except NotFoundError:
        cli_ctx.err_console.print("[red]Error:[/red] Secret provider not found")
        raise typer.Exit(1) from None
    except Exception as e:
        cli_ctx.err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from e
    finally:
        cli_ctx.close()


@app.command("delete")
def delete(
    ctx: typer.Context,
    name: Annotated[str, typer.Argument(help="Secret provider name")],
    workspace: Annotated[str, typer.Option("--workspace", "-w", help="Workspace name or ID")],
    confirm: Annotated[
        bool,
        typer.Option("--yes", "-y", "--force", help="Skip confirmation"),
    ] = False,
) -> None:
    """Delete a secret provider."""
    cli_ctx = _get_context(ctx)
    client = cli_ctx.get_client()

    if not confirm:
        confirmed = typer.confirm(f"Are you sure you want to delete secret provider {name}?")
        if not confirmed:
            cli_ctx.console.print("Cancelled")
            raise typer.Exit(0)

    try:
        workspace_id = resolve_workspace_id(client, workspace)
        client.secret_providers(workspace_id).delete(name)
        cli_ctx.console.print(f"Secret provider {name} deleted")
    except NotFoundError:
        cli_ctx.err_console.print("[red]Error:[/red] Secret provider not found")
        raise typer.Exit(1) from None
    except Exception as e:
        cli_ctx.err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1) from e
    finally:
        cli_ctx.close()
