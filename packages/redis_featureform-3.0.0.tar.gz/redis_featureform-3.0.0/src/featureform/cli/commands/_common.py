"""Shared helpers for CLI command modules."""

from __future__ import annotations

from uuid import UUID

from featureform.client import Client


def resolve_workspace_id(client: Client, workspace: str) -> UUID:
    """Resolve a workspace name or UUID string to a UUID.

    Args:
        client: Featureform client.
        workspace: Workspace UUID string or workspace name.

    Returns:
        Workspace UUID.
    """
    try:
        return UUID(workspace)
    except ValueError:
        return client.workspaces.get_by_name(workspace).id
