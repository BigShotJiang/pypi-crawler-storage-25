"""Audit CLI commands."""

from __future__ import annotations

from typing import Annotated, cast

import typer

from featureform.cli.admin_client import AdminClient, AdminClientError
from featureform.cli.utils import CLIContext

app = typer.Typer(name="audit", help="Inspect audit logs", no_args_is_help=True)

HEADERS = ["id", "scope", "workspace_id", "actor_id", "event_type", "created_at"]


def _ctx(ctx: typer.Context) -> CLIContext:
    return cast(CLIContext, ctx.obj["context"])


def _handle_err(cli_ctx: CLIContext, err: Exception) -> None:
    message = err.message if isinstance(err, AdminClientError) else str(err)
    cli_ctx.err_console.print(f"[red]Error:[/red] {message}")
    raise typer.Exit(1) from err


@app.command("list")
def list_logs(
    ctx: typer.Context,
    workspace: Annotated[str | None, typer.Option("--workspace", help="Workspace ID")] = None,
    global_scope: Annotated[
        bool, typer.Option("--global", help="List global audit events")
    ] = False,
    principal_id: Annotated[str | None, typer.Option("--principal-id", help="Principal ID")] = None,
    event_type: Annotated[str | None, typer.Option("--event-type", help="Event type")] = None,
    page_size: Annotated[int | None, typer.Option("--page-size", help="Page size")] = None,
) -> None:
    """List audit log entries."""
    cli_ctx = _ctx(ctx)
    try:
        filters: dict[str, str | int] = {}
        if workspace and global_scope:
            raise typer.BadParameter("--workspace and --global are mutually exclusive")
        if global_scope:
            filters["scope"] = "global"
        if workspace:
            filters["workspace_id"] = workspace
        if principal_id:
            filters["principal_id"] = principal_id
        if event_type:
            filters["event_type"] = event_type
        if page_size:
            filters["page_size"] = page_size
        data = AdminClient(cli_ctx).list_audit_logs(**filters)
        items = data.get("events", data)
        cli_ctx.print_formatted(items, HEADERS, is_list=True)
    except Exception as err:
        _handle_err(cli_ctx, err)
