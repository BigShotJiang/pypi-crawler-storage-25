"""Catalog CLI commands."""

from typing import Annotated, Any

import typer

from featureform.cli.commands._common import resolve_workspace_id
from featureform.cli.utils import CLIContext
from featureform.errors import NotFoundError

app = typer.Typer(
    name="catalog",
    help="Query the physical catalog",
    no_args_is_help=True,
)

CATALOG_HEADERS = [
    "Resource Name",
    "Provider Name",
    "Status",
    "Location",
    "Updated At",
]


def _get_context(ctx: typer.Context) -> CLIContext:
    """Get CLI context."""
    cli_ctx: CLIContext = ctx.obj["context"]
    return cli_ctx


def _location_display(location: Any) -> str:
    """Format a catalog location for CLI output."""
    if location.type == "table":
        parts = [location.database, location.schema, location.table]
        return ".".join(part for part in parts if part)
    if location.type == "iceberg":
        parts = [location.namespace, location.table]
        return ".".join(part for part in parts if part)
    return ""


def _catalog_to_cli_row(location: Any) -> dict[str, str]:
    """Convert a catalog location to CLI display fields."""
    return {
        "resource_name": location.resource_name,
        "provider_name": location.provider_name,
        "status": location.status.value
        if hasattr(location.status, "value")
        else str(location.status),
        "location": _location_display(location.location),
        "updated_at": location.updated_at.isoformat() if location.updated_at else "",
        "workspace_id": str(location.workspace_id),
        "error_message": location.error_message,
        "inputs": ", ".join(location.inputs),
        "created_at": location.created_at.isoformat() if location.created_at else "",
    }


@app.command("list")
def list_locations(
    ctx: typer.Context,
    workspace: Annotated[str, typer.Option("--workspace", "-w", help="Workspace name or ID")],
    provider: Annotated[
        str | None, typer.Option("--provider", "-p", help="Filter by provider name")
    ] = None,
) -> None:
    """List catalog locations in a workspace."""
    cli_ctx = _get_context(ctx)
    client = cli_ctx.get_client()

    try:
        workspace_id = resolve_workspace_id(client, workspace)
    except NotFoundError:
        cli_ctx.err_console.print("[red]Error:[/red] Workspace not found")
        raise typer.Exit(1) from None

    try:
        locations = client.catalogs(workspace_id).list(provider=provider)
        if not locations:
            cli_ctx.console.print("No catalog locations found")
            return
        cli_ctx.print_formatted(
            [_catalog_to_cli_row(loc) for loc in locations], CATALOG_HEADERS, is_list=True
        )
    except NotFoundError as exc:
        cli_ctx.err_console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1) from None
    finally:
        cli_ctx.close()


@app.command("get")
def get_location(
    ctx: typer.Context,
    resource_name: Annotated[str, typer.Argument(help="Logical dataset/resource name")],
    workspace: Annotated[str, typer.Option("--workspace", "-w", help="Workspace name or ID")],
) -> None:
    """Get a catalog location by resource name."""
    cli_ctx = _get_context(ctx)
    client = cli_ctx.get_client()

    try:
        workspace_id = resolve_workspace_id(client, workspace)
    except NotFoundError:
        cli_ctx.err_console.print("[red]Error:[/red] Workspace not found")
        raise typer.Exit(1) from None

    try:
        location = client.catalogs(workspace_id).get(resource_name)
        cli_ctx.print_formatted(_catalog_to_cli_row(location), CATALOG_HEADERS)
    except NotFoundError:
        cli_ctx.err_console.print("[red]Error:[/red] Catalog location not found")
        raise typer.Exit(1) from None
    finally:
        cli_ctx.close()
