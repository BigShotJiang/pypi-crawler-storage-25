"""Pure helpers for provider CLI config construction."""

from __future__ import annotations

import json
from typing import Any, cast

from pydantic import BaseModel, TypeAdapter

from featureform.errors import (
    MissingDynamoDBConfigError,
    MissingPostgresConfigError,
    MissingRedisClusterConfigError,
    MissingRedisConfigError,
    MissingS3ConfigError,
    UnsupportedProviderTypeError,
)
from featureform.types import (
    CLEAR,
    DynamoDBConfig,
    EnvSecretRef,
    IcebergCatalogConfig,
    IcebergGlueConfig,
    IcebergHiveConfig,
    IcebergRESTConfig,
    IcebergSQLConfig,
    K8sSecretRef,
    PostgresConfig,
    ProviderType,
    RedisClusterConfig,
    RedisConfig,
    RedisTLSConfig,
    RedisTLSMode,
    S3Config,
    SecretRef,
    SnowflakeConfig,
    SparkAdvancedConfig,
    SparkDependencyPolicy,
    SparkDependencyVersions,
    SparkExecutionDefaults,
    SparkProviderConfig,
    SparkSubmissionArtifactRef,
    SparkSubmissionDefaults,
    SparkSubmissionKerberosConfig,
    SSLMode,
    VaultSecretRef,
)
from featureform.types.provider import IcebergCatalogBackend, IcebergS3Warehouse, IcebergWarehouse
from featureform.types.secret import coerce_secret_ref

ProviderConfig = (
    PostgresConfig
    | SnowflakeConfig
    | S3Config
    | SparkProviderConfig
    | DynamoDBConfig
    | RedisConfig
    | RedisClusterConfig
    | IcebergCatalogConfig
)

_SECRET_REF_ADAPTER: TypeAdapter[SecretRef] = TypeAdapter(SecretRef)
_SPARK_DEPENDENCY_VERSION_FIELDS = {
    "iceberg": "iceberg",
    "iceberg_aws_bundle": "iceberg_aws_bundle",
    "hadoop_aws": "hadoop_aws",
    "aws_java_sdk_bundle": "aws_java_sdk_bundle",
    "postgres_jdbc": "postgres_jdbc",
}
_RESERVED_SPARK_ADVANCED_CONF_HINTS = {
    "spark.driver.memory": "execution_defaults.driver_memory",
    "spark.executor.memory": "execution_defaults.executor_memory",
    "spark.executor.cores": "execution_defaults.executor_cores",
    "spark.executor.instances": "execution_defaults.num_executors",
    "spark.sql.shuffle.partitions": "execution_defaults.shuffle_partitions",
}


def _coerce_secret_ref(value: Any) -> SecretRef | None:
    """Normalize CLI secret arguments into typed secret refs.

    CLI flags currently accept env-var names for secret-bearing provider fields.
    Empty strings clear optional secret refs in local config assembly.
    """
    if value is None:
        return None
    if isinstance(value, str):
        raw_value = value.strip()
        if raw_value == "":
            return None
        if ":" not in raw_value and "@" not in raw_value:
            return EnvSecretRef(name=raw_value)
        provider_name, backend_ref = _split_secret_provider_prefix(raw_value)
        secret_ref = coerce_secret_ref(backend_ref)
        if provider_name is None:
            return secret_ref
        if isinstance(secret_ref, EnvSecretRef):
            return secret_ref.model_copy(update={"provider_name": provider_name})
        if isinstance(secret_ref, VaultSecretRef):
            return secret_ref.model_copy(update={"provider_name": provider_name})
        if isinstance(secret_ref, K8sSecretRef):
            return secret_ref.model_copy(update={"provider_name": provider_name})
        return secret_ref.model_copy(update={"provider_name": provider_name})
    if isinstance(value, EnvSecretRef):
        return value
    if isinstance(value, dict):
        return _SECRET_REF_ADAPTER.validate_python(value)
    return _SECRET_REF_ADAPTER.validate_python(value)


def _split_secret_provider_prefix(value: str) -> tuple[str | None, str]:
    prefix, separator, remainder = value.partition("@")
    if separator == "" or prefix == "":
        return None, value
    if ":" not in remainder:
        return None, value
    return prefix, remainder


def _parse_string_key_value_pairs(
    entries: list[str] | None,
    *,
    option_name: str,
) -> dict[str, str]:
    parsed: dict[str, str] = {}
    for raw_entry in entries or []:
        key, separator, value = raw_entry.partition("=")
        key = key.strip()
        value = value.strip()
        if separator == "" or not key or value == "":
            raise ValueError(f"{option_name} entries must use key=value syntax")
        if key in parsed:
            raise ValueError(f"duplicate {option_name} entry for {key}")
        parsed[key] = value
    return parsed


def _validate_spark_advanced_conf_keys(conf: dict[str, str]) -> None:
    for key in conf:
        hint = _RESERVED_SPARK_ADVANCED_CONF_HINTS.get(key.strip())
        if hint is not None:
            raise ValueError(f"{key} is managed by {hint}")


def _parse_json_object(value: str | None, *, option_name: str) -> dict[str, Any] | None:
    if value is None:
        return None
    raw = value.strip()
    if raw == "":
        raise ValueError(f"{option_name} must be a JSON object")
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ValueError(f"{option_name} must be valid JSON") from exc
    if not isinstance(parsed, dict):
        raise ValueError(f"{option_name} must be a JSON object")
    return parsed


def _build_spark_catalogs(entries: list[str] | None) -> dict[str, str]:
    return _parse_string_key_value_pairs(entries, option_name="spark-catalog")


def _build_spark_dependency_versions(entries: list[str] | None) -> SparkDependencyVersions:
    pairs = _parse_string_key_value_pairs(entries, option_name="spark-dependency-version")
    values: dict[str, str] = {}
    for family, version in pairs.items():
        field_name = _SPARK_DEPENDENCY_VERSION_FIELDS.get(family)
        if field_name is None:
            supported = ", ".join(sorted(_SPARK_DEPENDENCY_VERSION_FIELDS))
            raise ValueError(
                f"unsupported spark dependency family {family}; expected one of: {supported}"
            )
        values[field_name] = version
    return SparkDependencyVersions(**values)


def _build_spark_execution_defaults(**kwargs: Any) -> SparkExecutionDefaults:
    return SparkExecutionDefaults(
        driver_cores=kwargs.get("spark_driver_cores"),
        driver_memory=kwargs.get("spark_default_driver_memory"),
        executor_memory=kwargs.get("spark_default_executor_memory"),
        executor_cores=kwargs.get("spark_default_executor_cores"),
        num_executors=kwargs.get("spark_default_num_executors"),
        shuffle_partitions=kwargs.get("spark_default_shuffle_partitions"),
    )


def _build_spark_runtime_profile(**kwargs: Any) -> SparkProviderConfig.SparkRuntimeProfile | None:
    backend = kwargs.get("spark_runtime_backend")
    spark_version = kwargs.get("spark_version")
    scala_binary_version = kwargs.get("spark_scala_binary_version")
    if backend is None and spark_version is None and scala_binary_version is None:
        return None
    return SparkProviderConfig.SparkRuntimeProfile(
        backend=backend,
        spark_version=spark_version,
        scala_binary_version=scala_binary_version,
    )


def _build_spark_dependency_policy(**kwargs: Any) -> SparkDependencyPolicy:
    return SparkDependencyPolicy(
        versions=_build_spark_dependency_versions(kwargs.get("spark_dependency_version")),
        extra_packages=list(kwargs.get("spark_extra_package") or []),
        extra_jars=list(kwargs.get("spark_extra_jar") or []),
    )


def _build_spark_advanced_config(**kwargs: Any) -> SparkAdvancedConfig:
    spark_conf = _parse_string_key_value_pairs(kwargs.get("spark_conf"), option_name="spark-conf")
    _validate_spark_advanced_conf_keys(spark_conf)
    return SparkAdvancedConfig(spark_conf=spark_conf)


def _build_spark_submission_artifacts(
    entries: list[str] | None,
) -> list[SparkSubmissionArtifactRef]:
    return [
        SparkSubmissionArtifactRef(uri=entry.strip()) for entry in entries or [] if entry.strip()
    ]


def _build_spark_backend(value: Any) -> SparkProviderConfig.SparkBackend:
    backend = _parse_json_object(value, option_name="--spark-backend")
    return SparkProviderConfig.SparkBackend.model_validate(backend)


def _build_optional_spark_hadoop(value: Any) -> SparkProviderConfig.SparkHadoopConfig | None:
    config = _parse_json_object(value, option_name="--spark-hadoop")
    if not config:
        return None
    return SparkProviderConfig.SparkHadoopConfig.model_validate(config)


def _build_optional_spark_staging(value: Any) -> SparkProviderConfig.SparkStagingConfig | None:
    config = _parse_json_object(value, option_name="--spark-staging")
    if not config:
        return None
    return SparkProviderConfig.SparkStagingConfig.model_validate(config)


def _build_spark_submission_kerberos(
    **kwargs: Any,
) -> SparkSubmissionKerberosConfig | None:
    principal = kwargs.get("spark_kerberos_principal")
    realm = kwargs.get("spark_kerberos_realm")
    kdc_host = kwargs.get("spark_kerberos_kdc_host")
    keytab_secret = _coerce_secret_ref(kwargs.get("spark_kerberos_keytab_secret"))
    krb5_conf_secret = _coerce_secret_ref(kwargs.get("spark_kerberos_krb5_conf_secret"))
    if (
        principal is None
        and realm is None
        and kdc_host is None
        and keytab_secret is None
        and krb5_conf_secret is None
    ):
        return None
    if not principal:
        raise ValueError("--spark-kerberos-principal is required when kerberos defaults are set")
    return SparkSubmissionKerberosConfig(
        principal=principal,
        realm=realm,
        kdc_host=kdc_host,
        keytab_secret=keytab_secret,
        krb5_conf_secret=krb5_conf_secret,
    )


def _build_spark_submission_defaults(**kwargs: Any) -> SparkSubmissionDefaults:
    return SparkSubmissionDefaults(
        app_name=kwargs.get("spark_submission_app_name"),
        properties_file=kwargs.get("spark_properties_file"),
        repositories=list(kwargs.get("spark_repository") or []),
        files=_build_spark_submission_artifacts(kwargs.get("spark_file")),
        archives=_build_spark_submission_artifacts(kwargs.get("spark_archive")),
        py_files=_build_spark_submission_artifacts(kwargs.get("spark_py_file")),
        kerberos=_build_spark_submission_kerberos(**kwargs),
    )


def build_register_config(provider_type: ProviderType, **kwargs: Any) -> ProviderConfig:
    """Build a provider config from CLI options."""
    if provider_type == ProviderType.POSTGRES:
        if not kwargs.get("pg_host") or not kwargs.get("pg_database"):
            raise MissingPostgresConfigError()
        return PostgresConfig(
            host=kwargs["pg_host"],
            port=kwargs.get("pg_port", 5432),
            database=kwargs["pg_database"],
            user=kwargs.get("pg_user"),
            password_secret=_coerce_secret_ref(kwargs.get("pg_password_secret")),
            ssl_mode=kwargs.get("pg_ssl_mode", SSLMode.PREFER),
        )

    if provider_type == ProviderType.S3:
        if not kwargs.get("s3_bucket") or not kwargs.get("s3_region"):
            raise MissingS3ConfigError()
        return S3Config(
            bucket=kwargs["s3_bucket"],
            region=kwargs["s3_region"],
            access_key_id_secret=_coerce_secret_ref(kwargs.get("s3_access_key_id_secret")),
            secret_access_key_secret=_coerce_secret_ref(kwargs.get("s3_secret_access_key_secret")),
            endpoint=kwargs.get("s3_endpoint"),
            path_style_access=bool(kwargs.get("s3_path_style_access", False)),
        )

    if provider_type == ProviderType.SNOWFLAKE:
        if not kwargs.get("snowflake_account") or not kwargs.get("snowflake_database"):
            raise ValueError(
                "--snowflake-account and --snowflake-database are required for snowflake"
            )
        if not kwargs.get("snowflake_warehouse") or not kwargs.get("snowflake_schema"):
            raise ValueError(
                "--snowflake-warehouse and --snowflake-schema are required for snowflake"
            )
        return SnowflakeConfig(
            account=kwargs["snowflake_account"],
            host=kwargs.get("snowflake_host"),
            warehouse=kwargs["snowflake_warehouse"],
            database=kwargs["snowflake_database"],
            schema=kwargs["snowflake_schema"],
            auth_type=kwargs.get("snowflake_auth_type", "password"),
            username=kwargs.get("snowflake_username"),
            password_secret=_coerce_secret_ref(kwargs.get("snowflake_password_secret")),
            private_key_secret=_coerce_secret_ref(kwargs.get("snowflake_private_key_secret")),
            passphrase_secret=_coerce_secret_ref(kwargs.get("snowflake_passphrase_secret")),
            oauth_client_id=kwargs.get("snowflake_oauth_client_id"),
            oauth_client_secret=_coerce_secret_ref(kwargs.get("snowflake_oauth_client_secret")),
            oauth_token=_coerce_secret_ref(kwargs.get("snowflake_oauth_token")),
            role=kwargs.get("snowflake_role"),
            login_timeout=kwargs.get("snowflake_login_timeout"),
            request_timeout=kwargs.get("snowflake_request_timeout"),
            session_params=dict(kwargs.get("snowflake_session_params") or {}),
        )

    if provider_type == ProviderType.SPARK:
        catalogs = _build_spark_catalogs(kwargs.get("spark_catalog"))
        if not catalogs:
            raise ValueError("--spark-catalog is required for spark")
        if kwargs.get("spark_backend") is None:
            raise ValueError("--spark-backend is required for spark")
        runtime_profile = _build_spark_runtime_profile(**kwargs)
        execution_defaults = _build_spark_execution_defaults(**kwargs)
        if kwargs.get("spark_driver_cores") is not None:
            execution_defaults = execution_defaults.model_copy(
                update={"driver_cores": kwargs["spark_driver_cores"]}
            )
        dependencies = _build_spark_dependency_policy(**kwargs)
        advanced = _build_spark_advanced_config(**kwargs)
        submission_defaults = _build_spark_submission_defaults(**kwargs)
        return SparkProviderConfig(
            catalogs=catalogs,
            backend=_build_spark_backend(kwargs["spark_backend"]),
            hadoop=_build_optional_spark_hadoop(kwargs.get("spark_hadoop")),
            staging=_build_optional_spark_staging(kwargs.get("spark_staging")),
            driver_env=SparkProviderConfig.SparkEnv(
                values=_parse_string_key_value_pairs(
                    kwargs.get("spark_driver_env"),
                    option_name="spark-driver-env",
                )
            ),
            executor_env=SparkProviderConfig.SparkEnv(
                values=_parse_string_key_value_pairs(
                    kwargs.get("spark_executor_env"),
                    option_name="spark-executor-env",
                )
            ),
            deploy_mode=kwargs.get("spark_deploy_mode"),
            runtime_profile=runtime_profile,
            execution_defaults=execution_defaults,
            dependencies=dependencies,
            advanced=advanced,
            submission_defaults=submission_defaults,
            spark_conf=dict(advanced.spark_conf),
            max_execution_time=kwargs.get("spark_max_execution_time"),
        )

    if provider_type == ProviderType.DYNAMODB:
        if not kwargs.get("dynamodb_region"):
            raise MissingDynamoDBConfigError()
        return DynamoDBConfig(
            region=kwargs["dynamodb_region"],
            access_key_id_secret=_coerce_secret_ref(kwargs.get("dynamodb_access_key_id_secret")),
            secret_access_key_secret=_coerce_secret_ref(
                kwargs.get("dynamodb_secret_access_key_secret")
            ),
            endpoint=kwargs.get("dynamodb_endpoint"),
            table_prefix=kwargs.get("dynamodb_table_prefix"),
        )

    if provider_type == ProviderType.REDIS:
        if not kwargs.get("redis_host"):
            raise MissingRedisConfigError()
        return RedisConfig(
            host=kwargs["redis_host"],
            port=kwargs.get("redis_port", 6379),
            database=0,
            password_secret=_coerce_secret_ref(kwargs.get("redis_password_secret")),
            tls=_build_redis_tls_config(**kwargs),
        )

    if provider_type == ProviderType.REDIS_CLUSTER:
        endpoints = kwargs.get("redis_cluster_endpoints") or []
        if not endpoints:
            raise MissingRedisClusterConfigError()
        return RedisClusterConfig(
            endpoints=endpoints,
            password_secret=_coerce_secret_ref(kwargs.get("redis_password_secret")),
            tls=_build_redis_tls_config(**kwargs),
        )

    if provider_type == ProviderType.ICEBERG:
        return _build_iceberg_register_config(**kwargs)

    raise UnsupportedProviderTypeError(f"Provider type {provider_type} not yet supported in CLI")


def merge_update_config(
    provider_type: ProviderType,
    existing_config: ProviderConfig | dict[str, Any] | None,
    **kwargs: Any,
) -> (
    PostgresConfig
    | SnowflakeConfig
    | S3Config
    | SparkProviderConfig
    | DynamoDBConfig
    | RedisConfig
    | RedisClusterConfig
):
    """Merge existing provider config with CLI update options."""
    current: dict[str, Any]
    if isinstance(existing_config, BaseModel):
        current = existing_config.model_dump(exclude_none=True, mode="json")
    else:
        current = existing_config or {}

    if provider_type == ProviderType.POSTGRES:
        return PostgresConfig(
            host=kwargs["pg_host"]
            if kwargs.get("pg_host") is not None
            else str(current.get("host", "")),
            port=kwargs["pg_port"]
            if kwargs.get("pg_port") is not None
            else int(current.get("port", 5432)),
            database=(
                kwargs["pg_database"]
                if kwargs.get("pg_database") is not None
                else str(current.get("database", ""))
            ),
            user=kwargs["pg_user"] if kwargs.get("pg_user") is not None else current.get("user"),
            password_secret=_coerce_secret_ref(
                kwargs["pg_password_secret"]
                if kwargs.get("pg_password_secret") is not None
                else current.get("password_secret")
            ),
            ssl_mode=(
                kwargs["pg_ssl_mode"]
                if kwargs.get("pg_ssl_mode") is not None
                else SSLMode(current.get("ssl_mode", "prefer"))
            ),
        )

    if provider_type == ProviderType.S3:
        return S3Config(
            bucket=kwargs["s3_bucket"]
            if kwargs.get("s3_bucket") is not None
            else str(current.get("bucket", "")),
            region=kwargs["s3_region"]
            if kwargs.get("s3_region") is not None
            else str(current.get("region", "")),
            access_key_id_secret=_coerce_secret_ref(
                kwargs["s3_access_key_id_secret"]
                if kwargs.get("s3_access_key_id_secret") is not None
                else current.get("access_key_id_secret")
            ),
            secret_access_key_secret=_coerce_secret_ref(
                kwargs["s3_secret_access_key_secret"]
                if kwargs.get("s3_secret_access_key_secret") is not None
                else current.get("secret_access_key_secret")
            ),
            endpoint=kwargs["s3_endpoint"]
            if kwargs.get("s3_endpoint") is not None
            else current.get("endpoint"),
            path_style_access=(
                bool(kwargs["s3_path_style_access"])
                if kwargs.get("s3_path_style_access") is not None
                else bool(current.get("path_style_access", False))
            ),
        )

    if provider_type == ProviderType.SNOWFLAKE:
        return SnowflakeConfig(
            account=kwargs["snowflake_account"]
            if kwargs.get("snowflake_account") is not None
            else str(current.get("account", "")),
            host=kwargs["snowflake_host"]
            if kwargs.get("snowflake_host") is not None
            else current.get("host"),
            warehouse=kwargs["snowflake_warehouse"]
            if kwargs.get("snowflake_warehouse") is not None
            else str(current.get("warehouse", "")),
            database=kwargs["snowflake_database"]
            if kwargs.get("snowflake_database") is not None
            else str(current.get("database", "")),
            schema=kwargs["snowflake_schema"]
            if kwargs.get("snowflake_schema") is not None
            else str(current.get("schema", "")),
            auth_type=kwargs["snowflake_auth_type"]
            if kwargs.get("snowflake_auth_type") is not None
            else str(current.get("auth_type", "password")),
            username=kwargs["snowflake_username"]
            if kwargs.get("snowflake_username") is not None
            else current.get("username"),
            password_secret=_coerce_secret_ref(
                kwargs["snowflake_password_secret"]
                if kwargs.get("snowflake_password_secret") is not None
                else current.get("password_secret")
            ),
            private_key_secret=_coerce_secret_ref(
                kwargs["snowflake_private_key_secret"]
                if kwargs.get("snowflake_private_key_secret") is not None
                else current.get("private_key_secret")
            ),
            passphrase_secret=_coerce_secret_ref(
                kwargs["snowflake_passphrase_secret"]
                if kwargs.get("snowflake_passphrase_secret") is not None
                else current.get("passphrase_secret")
            ),
            oauth_client_id=kwargs["snowflake_oauth_client_id"]
            if kwargs.get("snowflake_oauth_client_id") is not None
            else current.get("oauth_client_id"),
            oauth_client_secret=_coerce_secret_ref(
                kwargs["snowflake_oauth_client_secret"]
                if kwargs.get("snowflake_oauth_client_secret") is not None
                else current.get("oauth_client_secret")
            ),
            oauth_token=_coerce_secret_ref(
                kwargs["snowflake_oauth_token"]
                if kwargs.get("snowflake_oauth_token") is not None
                else current.get("oauth_token")
            ),
            role=kwargs["snowflake_role"]
            if kwargs.get("snowflake_role") is not None
            else current.get("role"),
            login_timeout=kwargs["snowflake_login_timeout"]
            if kwargs.get("snowflake_login_timeout") is not None
            else current.get("login_timeout"),
            request_timeout=kwargs["snowflake_request_timeout"]
            if kwargs.get("snowflake_request_timeout") is not None
            else current.get("request_timeout"),
            session_params=(
                dict(kwargs["snowflake_session_params"])
                if kwargs.get("snowflake_session_params") is not None
                else dict(current.get("session_params") or {})
            ),
        )

    if provider_type == ProviderType.SPARK:
        return SparkProviderConfig(
            catalogs=(
                _build_spark_catalogs(kwargs.get("spark_catalog"))
                if kwargs.get("spark_catalog") is not None
                else dict(current.get("catalogs") or {})
            ),
            backend=(
                _build_spark_backend(kwargs.get("spark_backend"))
                if kwargs.get("spark_backend") is not None
                else SparkProviderConfig.SparkBackend.model_validate(current.get("backend") or {})
            ),
            hadoop=(
                _build_optional_spark_hadoop(kwargs.get("spark_hadoop"))
                if kwargs.get("spark_hadoop") is not None
                else _build_optional_spark_hadoop(current.get("hadoop"))
            ),
            staging=(
                _build_optional_spark_staging(kwargs.get("spark_staging"))
                if kwargs.get("spark_staging") is not None
                else _build_optional_spark_staging(current.get("staging"))
            ),
            driver_env=(
                SparkProviderConfig.SparkEnv(
                    values=_parse_string_key_value_pairs(
                        kwargs.get("spark_driver_env"),
                        option_name="spark-driver-env",
                    )
                )
                if kwargs.get("spark_driver_env") is not None
                else SparkProviderConfig.SparkEnv.model_validate(current.get("driver_env") or {})
            ),
            executor_env=(
                SparkProviderConfig.SparkEnv(
                    values=_parse_string_key_value_pairs(
                        kwargs.get("spark_executor_env"),
                        option_name="spark-executor-env",
                    )
                )
                if kwargs.get("spark_executor_env") is not None
                else SparkProviderConfig.SparkEnv.model_validate(current.get("executor_env") or {})
            ),
            deploy_mode=kwargs["spark_deploy_mode"]
            if kwargs.get("spark_deploy_mode") is not None
            else current.get("deploy_mode"),
        )

    if provider_type == ProviderType.REDIS:
        return RedisConfig(
            host=kwargs["redis_host"]
            if kwargs.get("redis_host") is not None
            else str(current.get("host", "")),
            port=kwargs["redis_port"]
            if kwargs.get("redis_port") is not None
            else int(current.get("port", 6379)),
            database=int(current.get("database", 0)),
            password_secret=_coerce_secret_ref(
                kwargs["redis_password_secret"]
                if kwargs.get("redis_password_secret") is not None
                else current.get("password_secret")
            ),
            tls=_merge_redis_tls_config(current.get("tls"), **kwargs),
        )

    if provider_type == ProviderType.REDIS_CLUSTER:
        current_endpoints = current.get("endpoints") or []
        return RedisClusterConfig(
            endpoints=(
                kwargs["redis_cluster_endpoints"]
                if kwargs.get("redis_cluster_endpoints") is not None
                else list(current_endpoints)
            ),
            password_secret=_coerce_secret_ref(
                kwargs["redis_password_secret"]
                if kwargs.get("redis_password_secret") is not None
                else current.get("password_secret")
            ),
            tls=_merge_redis_tls_config(current.get("tls"), **kwargs),
        )

    if provider_type == ProviderType.DYNAMODB:
        return DynamoDBConfig(
            region=kwargs["dynamodb_region"]
            if kwargs.get("dynamodb_region") is not None
            else str(current.get("region", "")),
            access_key_id_secret=_coerce_secret_ref(
                kwargs["dynamodb_access_key_id_secret"]
                if kwargs.get("dynamodb_access_key_id_secret") is not None
                else current.get("access_key_id_secret")
            ),
            secret_access_key_secret=_coerce_secret_ref(
                kwargs["dynamodb_secret_access_key_secret"]
                if kwargs.get("dynamodb_secret_access_key_secret") is not None
                else current.get("secret_access_key_secret")
            ),
            endpoint=(
                kwargs["dynamodb_endpoint"]
                if kwargs.get("dynamodb_endpoint") is not None
                else current.get("endpoint")
            ),
            table_prefix=(
                kwargs["dynamodb_table_prefix"]
                if kwargs.get("dynamodb_table_prefix") is not None
                else current.get("table_prefix")
            ),
        )

    raise UnsupportedProviderTypeError(
        f"Provider type {provider_type} not yet supported for update"
    )


def build_update_patch(provider_type: ProviderType, **kwargs: Any) -> dict[str, Any]:
    """Build a sparse provider update patch from explicit CLI options only."""
    if provider_type == ProviderType.POSTGRES:
        patch: dict[str, Any] = {}
        if kwargs.get("pg_host") is not None:
            patch["host"] = kwargs["pg_host"]
        if kwargs.get("pg_port") is not None:
            patch["port"] = kwargs["pg_port"]
        if kwargs.get("pg_database") is not None:
            patch["database"] = kwargs["pg_database"]
        if kwargs.get("pg_user") is not None:
            patch["user"] = kwargs["pg_user"]
        if kwargs.get("pg_password_secret") is not None:
            patch["password_secret"] = (
                CLEAR
                if kwargs["pg_password_secret"] == ""
                else _coerce_secret_ref(kwargs["pg_password_secret"])
            )
        if kwargs.get("pg_ssl_mode") is not None:
            patch["ssl_mode"] = kwargs["pg_ssl_mode"].value
        return patch

    if provider_type == ProviderType.S3:
        patch = {}
        if kwargs.get("s3_bucket") is not None:
            patch["bucket"] = kwargs["s3_bucket"]
        if kwargs.get("s3_region") is not None:
            patch["region"] = kwargs["s3_region"]
        if kwargs.get("s3_access_key_id_secret") is not None:
            patch["access_key_id_secret"] = (
                CLEAR
                if kwargs["s3_access_key_id_secret"] == ""
                else _coerce_secret_ref(kwargs["s3_access_key_id_secret"])
            )
        if kwargs.get("s3_secret_access_key_secret") is not None:
            patch["secret_access_key_secret"] = (
                CLEAR
                if kwargs["s3_secret_access_key_secret"] == ""
                else _coerce_secret_ref(kwargs["s3_secret_access_key_secret"])
            )
        if kwargs.get("s3_endpoint") is not None:
            patch["endpoint"] = kwargs["s3_endpoint"]
        return patch

    if provider_type == ProviderType.SNOWFLAKE:
        patch = {}
        if kwargs.get("snowflake_account") is not None:
            patch["account"] = kwargs["snowflake_account"]
        if kwargs.get("snowflake_host") is not None:
            patch["host"] = kwargs["snowflake_host"]
        if kwargs.get("snowflake_warehouse") is not None:
            patch["warehouse"] = kwargs["snowflake_warehouse"]
        if kwargs.get("snowflake_database") is not None:
            patch["database"] = kwargs["snowflake_database"]
        if kwargs.get("snowflake_schema") is not None:
            patch["schema"] = kwargs["snowflake_schema"]
        if kwargs.get("snowflake_auth_type") is not None:
            patch["auth_type"] = kwargs["snowflake_auth_type"]
        if kwargs.get("snowflake_username") is not None:
            patch["username"] = kwargs["snowflake_username"]
        if kwargs.get("snowflake_password_secret") is not None:
            patch["password_secret"] = (
                CLEAR
                if kwargs["snowflake_password_secret"] == ""
                else _coerce_secret_ref(kwargs["snowflake_password_secret"])
            )
        if kwargs.get("snowflake_private_key_secret") is not None:
            patch["private_key_secret"] = (
                CLEAR
                if kwargs["snowflake_private_key_secret"] == ""
                else _coerce_secret_ref(kwargs["snowflake_private_key_secret"])
            )
        if kwargs.get("snowflake_passphrase_secret") is not None:
            patch["passphrase_secret"] = (
                CLEAR
                if kwargs["snowflake_passphrase_secret"] == ""
                else _coerce_secret_ref(kwargs["snowflake_passphrase_secret"])
            )
        if kwargs.get("snowflake_oauth_client_id") is not None:
            patch["oauth_client_id"] = kwargs["snowflake_oauth_client_id"]
        if kwargs.get("snowflake_oauth_client_secret") is not None:
            patch["oauth_client_secret"] = (
                CLEAR
                if kwargs["snowflake_oauth_client_secret"] == ""
                else _coerce_secret_ref(kwargs["snowflake_oauth_client_secret"])
            )
        if kwargs.get("snowflake_oauth_token") is not None:
            patch["oauth_token"] = (
                CLEAR
                if kwargs["snowflake_oauth_token"] == ""
                else _coerce_secret_ref(kwargs["snowflake_oauth_token"])
            )
        if kwargs.get("snowflake_role") is not None:
            patch["role"] = kwargs["snowflake_role"]
        if kwargs.get("snowflake_login_timeout") is not None:
            patch["login_timeout"] = kwargs["snowflake_login_timeout"]
        if kwargs.get("snowflake_request_timeout") is not None:
            patch["request_timeout"] = kwargs["snowflake_request_timeout"]
        if kwargs.get("snowflake_session_params") is not None:
            patch["session_params"] = dict(kwargs["snowflake_session_params"])
        return patch

    if provider_type == ProviderType.SPARK:
        patch = {}
        if kwargs.get("spark_catalog") is not None:
            patch["catalogs"] = _build_spark_catalogs(kwargs["spark_catalog"])
        if kwargs.get("spark_backend") is not None:
            patch["backend"] = _parse_json_object(
                kwargs["spark_backend"],
                option_name="--spark-backend",
            )
        if kwargs.get("spark_hadoop") is not None:
            patch["hadoop"] = _parse_json_object(
                kwargs["spark_hadoop"],
                option_name="--spark-hadoop",
            )
        if kwargs.get("spark_staging") is not None:
            patch["staging"] = _parse_json_object(
                kwargs["spark_staging"],
                option_name="--spark-staging",
            )
        if kwargs.get("spark_driver_env") is not None:
            patch["driver_env"] = {
                "values": _parse_string_key_value_pairs(
                    kwargs["spark_driver_env"],
                    option_name="spark-driver-env",
                )
            }
        if kwargs.get("spark_executor_env") is not None:
            patch["executor_env"] = {
                "values": _parse_string_key_value_pairs(
                    kwargs["spark_executor_env"],
                    option_name="spark-executor-env",
                )
            }
        if kwargs.get("spark_deploy_mode") is not None:
            patch["deploy_mode"] = kwargs["spark_deploy_mode"]
        runtime_profile = {}
        if kwargs.get("spark_runtime_backend") is not None:
            runtime_profile["backend"] = kwargs["spark_runtime_backend"]
        if kwargs.get("spark_version") is not None:
            runtime_profile["spark_version"] = kwargs["spark_version"]
        if kwargs.get("spark_scala_binary_version") is not None:
            runtime_profile["scala_binary_version"] = kwargs["spark_scala_binary_version"]
        if runtime_profile:
            patch["runtime_profile"] = runtime_profile

        execution_defaults = {}
        if kwargs.get("spark_driver_cores") is not None:
            execution_defaults["driver_cores"] = kwargs["spark_driver_cores"]
        if kwargs.get("spark_default_driver_memory") is not None:
            execution_defaults["driver_memory"] = kwargs["spark_default_driver_memory"]
        if kwargs.get("spark_default_executor_memory") is not None:
            execution_defaults["executor_memory"] = kwargs["spark_default_executor_memory"]
        if kwargs.get("spark_default_executor_cores") is not None:
            execution_defaults["executor_cores"] = kwargs["spark_default_executor_cores"]
        if kwargs.get("spark_default_num_executors") is not None:
            execution_defaults["num_executors"] = kwargs["spark_default_num_executors"]
        if kwargs.get("spark_default_shuffle_partitions") is not None:
            execution_defaults["shuffle_partitions"] = kwargs["spark_default_shuffle_partitions"]
        if execution_defaults:
            patch["execution_defaults"] = execution_defaults

        dependency_versions = _build_spark_dependency_versions(
            kwargs.get("spark_dependency_version")
        )
        dependency_patch: dict[str, Any] = {}
        versions_payload = dependency_versions.model_dump(exclude_none=True)
        if versions_payload:
            dependency_patch["versions"] = versions_payload
        if kwargs.get("spark_extra_package") is not None:
            dependency_patch["extra_packages"] = list(kwargs["spark_extra_package"])
        if kwargs.get("spark_extra_jar") is not None:
            dependency_patch["extra_jars"] = list(kwargs["spark_extra_jar"])
        if dependency_patch:
            patch["dependencies"] = dependency_patch

        set_spark_conf = _parse_string_key_value_pairs(
            kwargs.get("spark_conf"),
            option_name="spark-conf",
        )
        _validate_spark_advanced_conf_keys(set_spark_conf)
        remove_spark_conf = list(kwargs.get("spark_clear_conf") or [])
        if set_spark_conf or remove_spark_conf:
            patch["advanced"] = {}
            if set_spark_conf:
                patch["advanced"]["set_spark_conf"] = set_spark_conf
            if remove_spark_conf:
                patch["advanced"]["remove_spark_conf"] = remove_spark_conf

        submission_defaults = {}
        if kwargs.get("spark_submission_app_name") is not None:
            submission_defaults["app_name"] = kwargs["spark_submission_app_name"]
        if kwargs.get("spark_properties_file") is not None:
            submission_defaults["properties_file"] = kwargs["spark_properties_file"]
        if kwargs.get("spark_repository") is not None:
            submission_defaults["repositories"] = list(kwargs["spark_repository"])
        if kwargs.get("spark_file") is not None:
            submission_defaults["files"] = [
                {"uri": item} for item in kwargs["spark_file"] if item and item.strip()
            ]
        if kwargs.get("spark_archive") is not None:
            submission_defaults["archives"] = [
                {"uri": item} for item in kwargs["spark_archive"] if item and item.strip()
            ]
        if kwargs.get("spark_py_file") is not None:
            submission_defaults["py_files"] = [
                {"uri": item} for item in kwargs["spark_py_file"] if item and item.strip()
            ]
        kerberos = {}
        if kwargs.get("spark_kerberos_principal") is not None:
            kerberos["principal"] = kwargs["spark_kerberos_principal"]
        if kwargs.get("spark_kerberos_realm") is not None:
            kerberos["realm"] = kwargs["spark_kerberos_realm"]
        if kwargs.get("spark_kerberos_kdc_host") is not None:
            kerberos["kdc_host"] = kwargs["spark_kerberos_kdc_host"]
        if kwargs.get("spark_kerberos_keytab_secret") is not None:
            kerberos["keytab_secret"] = _coerce_secret_ref(kwargs["spark_kerberos_keytab_secret"])
        if kwargs.get("spark_kerberos_krb5_conf_secret") is not None:
            kerberos["krb5_conf_secret"] = _coerce_secret_ref(
                kwargs["spark_kerberos_krb5_conf_secret"]
            )
        if kerberos:
            if "principal" not in kerberos:
                raise ValueError(
                    "--spark-kerberos-principal is required when kerberos defaults are set"
                )
            submission_defaults["kerberos"] = kerberos
        if submission_defaults:
            patch["submission_defaults"] = submission_defaults
        return patch

    if provider_type == ProviderType.DYNAMODB:
        patch = {}
        if kwargs.get("dynamodb_region") is not None:
            patch["region"] = kwargs["dynamodb_region"]
        if kwargs.get("dynamodb_access_key_id_secret") is not None:
            patch["access_key_id_secret"] = (
                CLEAR
                if kwargs["dynamodb_access_key_id_secret"] == ""
                else _coerce_secret_ref(kwargs["dynamodb_access_key_id_secret"])
            )
        if kwargs.get("dynamodb_secret_access_key_secret") is not None:
            patch["secret_access_key_secret"] = (
                CLEAR
                if kwargs["dynamodb_secret_access_key_secret"] == ""
                else _coerce_secret_ref(kwargs["dynamodb_secret_access_key_secret"])
            )
        if kwargs.get("dynamodb_endpoint") is not None:
            patch["endpoint"] = kwargs["dynamodb_endpoint"]
        if kwargs.get("dynamodb_table_prefix") is not None:
            patch["table_prefix"] = kwargs["dynamodb_table_prefix"]
        return patch

    if provider_type == ProviderType.REDIS:
        patch = {}
        if kwargs.get("redis_host") is not None:
            patch["host"] = kwargs["redis_host"]
        if kwargs.get("redis_port") is not None:
            patch["port"] = kwargs["redis_port"]
        if kwargs.get("redis_password_secret") is not None:
            patch["password_secret"] = (
                CLEAR
                if kwargs["redis_password_secret"] == ""
                else _coerce_secret_ref(kwargs["redis_password_secret"])
            )
        redis_tls_patch = _build_redis_tls_patch(**kwargs)
        if redis_tls_patch:
            patch["tls"] = redis_tls_patch
        return patch

    if provider_type == ProviderType.REDIS_CLUSTER:
        patch = {}
        if kwargs.get("redis_cluster_endpoints") is not None:
            patch["endpoints"] = kwargs["redis_cluster_endpoints"]
        if kwargs.get("redis_password_secret") is not None:
            patch["password_secret"] = (
                CLEAR
                if kwargs["redis_password_secret"] == ""
                else _coerce_secret_ref(kwargs["redis_password_secret"])
            )
        redis_tls_patch = _build_redis_tls_patch(**kwargs)
        if redis_tls_patch:
            patch["tls"] = redis_tls_patch
        return patch

    raise UnsupportedProviderTypeError(
        f"Provider type {provider_type} not yet supported for update"
    )


def _build_iceberg_register_config(**kwargs: Any) -> IcebergCatalogConfig:
    warehouse_provider = kwargs.get("iceberg_warehouse_provider")
    warehouse_prefix = kwargs.get("iceberg_warehouse_prefix")
    catalog_name = kwargs.get("iceberg_catalog_name")

    if not warehouse_provider:
        raise ValueError("--iceberg-warehouse-provider is required for iceberg")
    if not catalog_name:
        raise ValueError("--iceberg-catalog-name is required for iceberg")
    unsupported_s3_options = {
        "iceberg_s3_region": "--iceberg-s3-region",
        "iceberg_s3_endpoint": "--iceberg-s3-endpoint",
        "iceberg_s3_access_key_id": "--iceberg-s3-access-key-id",
        "iceberg_s3_secret_access_key": "--iceberg-s3-secret-access-key",
        "iceberg_s3_path_style_access": "--iceberg-s3-path-style-access",
    }
    provided_unsupported = [
        option_name
        for field_name, option_name in unsupported_s3_options.items()
        if kwargs.get(field_name) not in (None, False)
    ]
    if provided_unsupported:
        provided_flags = ", ".join(provided_unsupported)
        raise ValueError(
            f"{provided_flags} are not supported by the current typed Iceberg provider config; "
            "configure warehouse access through the referenced provider instead"
        )

    rest_config = (
        IcebergRESTConfig(
            uri=kwargs["iceberg_rest_uri"],
            credential=_coerce_secret_ref(kwargs.get("iceberg_rest_credential")),
            prefix=kwargs.get("iceberg_rest_prefix"),
        )
        if kwargs.get("iceberg_rest_uri")
        else None
    )
    hive_config = (
        IcebergHiveConfig(uri=kwargs["iceberg_hive_uri"])
        if kwargs.get("iceberg_hive_uri")
        else None
    )
    glue_config = (
        IcebergGlueConfig(
            region=kwargs["iceberg_glue_region"],
            catalog_id=kwargs.get("iceberg_glue_catalog_id"),
        )
        if kwargs.get("iceberg_glue_region")
        else None
    )
    sql_config = None
    sql_driver = kwargs.get("iceberg_sql_driver")
    sql_connection_string = kwargs.get("iceberg_sql_connection_string")
    if sql_driver or sql_connection_string:
        if not sql_driver or not sql_connection_string:
            raise ValueError(
                "--iceberg-sql-driver and --iceberg-sql-connection-string are required together for SQL catalog"
            )
        sql_config = IcebergSQLConfig(
            driver=sql_driver,
            connection_string=cast(SecretRef, _coerce_secret_ref(sql_connection_string)),
        )

    configured_backends = [
        config
        for config in (rest_config, hive_config, glue_config, sql_config)
        if config is not None
    ]
    if not configured_backends:
        raise ValueError(
            "One Iceberg backend must be configured via --iceberg-rest-uri, --iceberg-hive-uri, "
            "--iceberg-glue-region, or the SQL flags"
        )
    if len(configured_backends) > 1:
        raise ValueError(
            "Only one Iceberg backend may be configured via REST, Hive, Glue, or SQL flags"
        )

    return IcebergCatalogConfig(
        backend=IcebergCatalogBackend(
            rest=rest_config,
            hive=hive_config,
            glue=glue_config,
            sql=sql_config,
        ),
        warehouse=IcebergWarehouse(
            s3=IcebergS3Warehouse(provider=warehouse_provider, prefix=warehouse_prefix),
            hdfs=None,
        ),
    )


def _build_redis_tls_config(**kwargs: Any) -> RedisTLSConfig | None:
    mode = kwargs.get("redis_tls_mode")
    if mode is None:
        return None
    insecure_skip_verify = kwargs.get("redis_tls_insecure_skip_verify")
    return RedisTLSConfig(
        mode=mode if isinstance(mode, RedisTLSMode) else RedisTLSMode(mode),
        ca_cert_path=kwargs.get("redis_tls_ca_cert_path"),
        ca_cert_secret=_coerce_secret_ref(kwargs.get("redis_tls_ca_cert_secret")),
        server_name=kwargs.get("redis_tls_server_name"),
        client_cert_path=kwargs.get("redis_tls_client_cert_path"),
        client_cert_secret=_coerce_secret_ref(kwargs.get("redis_tls_client_cert_secret")),
        client_key_path=kwargs.get("redis_tls_client_key_path"),
        client_key_secret=_coerce_secret_ref(kwargs.get("redis_tls_client_key_secret")),
        insecure_skip_verify=(insecure_skip_verify if insecure_skip_verify is not None else False),
        min_version=kwargs.get("redis_tls_min_version"),
    )


def _merge_redis_tls_config(existing: Any, **kwargs: Any) -> RedisTLSConfig | None:
    current: dict[str, Any] = {}
    if isinstance(existing, dict):
        current = cast(dict[str, Any], existing)
    elif existing is not None:
        current = cast(dict[str, Any], existing.model_dump(exclude_none=False))

    mode = kwargs.get("redis_tls_mode")
    if mode is None:
        existing_mode = current.get("mode")
        if not existing_mode:
            return None
        mode = RedisTLSMode(existing_mode)

    return RedisTLSConfig(
        mode=mode if isinstance(mode, RedisTLSMode) else RedisTLSMode(mode),
        ca_cert_path=(
            kwargs["redis_tls_ca_cert_path"]
            if kwargs.get("redis_tls_ca_cert_path") is not None
            else current.get("ca_cert_path")
        ),
        ca_cert_secret=(
            _coerce_secret_ref(kwargs["redis_tls_ca_cert_secret"])
            if kwargs.get("redis_tls_ca_cert_secret") is not None
            else current.get("ca_cert_secret")
        ),
        server_name=(
            kwargs["redis_tls_server_name"]
            if kwargs.get("redis_tls_server_name") is not None
            else current.get("server_name")
        ),
        client_cert_path=(
            kwargs["redis_tls_client_cert_path"]
            if kwargs.get("redis_tls_client_cert_path") is not None
            else current.get("client_cert_path")
        ),
        client_cert_secret=(
            _coerce_secret_ref(kwargs["redis_tls_client_cert_secret"])
            if kwargs.get("redis_tls_client_cert_secret") is not None
            else current.get("client_cert_secret")
        ),
        client_key_path=(
            kwargs["redis_tls_client_key_path"]
            if kwargs.get("redis_tls_client_key_path") is not None
            else current.get("client_key_path")
        ),
        client_key_secret=(
            _coerce_secret_ref(kwargs["redis_tls_client_key_secret"])
            if kwargs.get("redis_tls_client_key_secret") is not None
            else current.get("client_key_secret")
        ),
        insecure_skip_verify=(
            kwargs["redis_tls_insecure_skip_verify"]
            if kwargs.get("redis_tls_insecure_skip_verify") is not None
            else bool(current.get("insecure_skip_verify", False))
        ),
        min_version=(
            kwargs["redis_tls_min_version"]
            if kwargs.get("redis_tls_min_version") is not None
            else current.get("min_version")
        ),
    )


def _build_redis_tls_patch(**kwargs: Any) -> dict[str, Any]:
    patch: dict[str, Any] = {}
    if kwargs.get("redis_tls_mode") is not None:
        mode = kwargs["redis_tls_mode"]
        patch["mode"] = mode.value if isinstance(mode, RedisTLSMode) else str(mode)
    if kwargs.get("redis_tls_ca_cert_path") is not None:
        patch["ca_cert_path"] = kwargs["redis_tls_ca_cert_path"]
    if kwargs.get("redis_tls_ca_cert_secret") is not None:
        patch["ca_cert_secret"] = (
            CLEAR
            if kwargs["redis_tls_ca_cert_secret"] == ""
            else _coerce_secret_ref(kwargs["redis_tls_ca_cert_secret"])
        )
    if kwargs.get("redis_tls_server_name") is not None:
        patch["server_name"] = kwargs["redis_tls_server_name"]
    if kwargs.get("redis_tls_client_cert_path") is not None:
        patch["client_cert_path"] = kwargs["redis_tls_client_cert_path"]
    if kwargs.get("redis_tls_client_cert_secret") is not None:
        patch["client_cert_secret"] = (
            CLEAR
            if kwargs["redis_tls_client_cert_secret"] == ""
            else _coerce_secret_ref(kwargs["redis_tls_client_cert_secret"])
        )
    if kwargs.get("redis_tls_client_key_path") is not None:
        patch["client_key_path"] = kwargs["redis_tls_client_key_path"]
    if kwargs.get("redis_tls_client_key_secret") is not None:
        patch["client_key_secret"] = (
            CLEAR
            if kwargs["redis_tls_client_key_secret"] == ""
            else _coerce_secret_ref(kwargs["redis_tls_client_key_secret"])
        )
    if kwargs.get("redis_tls_insecure_skip_verify") is not None:
        patch["insecure_skip_verify"] = kwargs["redis_tls_insecure_skip_verify"]
    if kwargs.get("redis_tls_min_version") is not None:
        patch["min_version"] = kwargs["redis_tls_min_version"]
    return patch
