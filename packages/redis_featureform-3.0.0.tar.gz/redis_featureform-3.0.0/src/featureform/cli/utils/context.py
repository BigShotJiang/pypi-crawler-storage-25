"""CLI context management."""

from __future__ import annotations

import sys
from enum import Enum
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field
from rich.console import Console

from featureform import Client, Config
from featureform._internal.logging import get_logger
from featureform.cli.output import JSONFormatter, OutputFormatter, TableFormatter, YAMLFormatter
from featureform.transport import TransportType

# Module logger
_logger = get_logger("featureform.cli.context")


class OutputFormat(str, Enum):
    """Output format options."""

    TABLE = "table"
    JSON = "json"
    YAML = "yaml"


class TransportFormat(str, Enum):
    """Transport format options for CLI."""

    REST = "rest"
    GRPC = "grpc"


class CLIContext(BaseModel):
    """CLI context holding configuration and client.

    Provides shared Console instances for terminal-aware output.
    The console respects NO_COLOR environment variable and can be
    explicitly disabled via the no_color flag.
    """

    model_config = {"arbitrary_types_allowed": True}

    base_url: str = Field(default="http://localhost:8080")
    rest_url: str | None = Field(
        default=None
    )  # Optional REST base URL for transport-specific fallbacks
    timeout: float = Field(default=30.0)
    timeout_explicit: bool = Field(default=False)
    output_format: OutputFormat = Field(default=OutputFormat.TABLE)
    transport: TransportFormat = Field(default=TransportFormat.REST)
    verify_ssl: bool = Field(default=True)
    no_tls: bool = Field(default=False)
    ca_cert_path: str | None = Field(default=None)
    client_cert_path: str | None = Field(default=None)
    client_key_path: str | None = Field(default=None)
    token: str | None = Field(default=None)
    client_id: str | None = Field(default=None)
    client_secret: str | None = Field(default=None)
    issuer_url: str | None = Field(default=None)
    config_path: Path | None = Field(default=None)
    no_color: bool = Field(default=False)
    skip_version_check: bool = Field(default=False)
    verbose: bool = Field(default=False)
    _client: Client | None = None
    _console: Console | None = None
    _err_console: Console | None = None

    def get_auth_token(self) -> str | None:
        """Get authentication token using priority order.

        Priority:
        1. Direct token (--token or FEATUREFORM_TOKEN)
        2. Client credentials (acquire token if client_id + client_secret + issuer_url)

        Returns:
            Bearer token or None if not authenticated.
        """
        try:
            from featureform.cli.auth import StorageUnavailableError
            from featureform.cli.commands.auth import build_auth_service
        except ImportError:
            return None

        try:
            return build_auth_service(self).resolve_access_token(
                env_token=self.token,
                client_id=self.client_id,
                client_secret=self.client_secret,
                issuer_url=self.issuer_url,
                server_url=self.base_url,
                transport=self.transport.value,
            )
        except (ValueError, StorageUnavailableError) as exc:
            _logger.warning(
                "auth_token_resolution_failed",
                base_url=self.base_url,
                transport=self.transport.value,
                error=str(exc),
            )
            return None

    def is_server_configured(self) -> bool:
        """Check if server URL is configured.

        Returns:
            True if base_url is set (non-empty), False otherwise.
        """
        return bool(self.base_url)

    def get_rest_url(self) -> str:
        """Get the REST API URL.

        When using gRPC transport, this returns rest_url if set, otherwise base_url.
        Scheduler commands always use REST API even when the CLI is configured for gRPC.

        Returns:
            The REST API URL to use for HTTP requests.
        """
        if self.transport == TransportFormat.GRPC and self.rest_url:
            return self.rest_url
        return self.base_url

    def require_server_configured(self) -> None:
        """Require that server URL is configured.

        Raises:
            typer.Exit: If server is not configured.
        """
        if not self.is_server_configured():
            import typer

            typer.echo(
                "Error: Server not configured. "
                "Use --server flag or set FEATUREFORM_BASE_URL environment variable.",
                err=True,
            )
            raise typer.Exit(1)

    def get_client(self) -> Client:
        """Get or create the client.

        Raises:
            SystemExit: If server is not configured (no --server flag or FEATUREFORM_BASE_URL).
        """
        if self._client is None:
            # Check if server is configured (exits with error if not)
            self.require_server_configured()

            # Build headers with auth token if available
            headers: dict[str, str] = {}
            auth_token = self.get_auth_token()
            if auth_token:
                headers["Authorization"] = f"Bearer {auth_token}"

            config = Config(
                base_url=self.base_url,
                timeout=self.timeout,
                verify_ssl=self.verify_ssl,
                no_tls=self.no_tls,
                ca_cert_path=self.ca_cert_path,
                client_cert_path=self.client_cert_path,
                client_key_path=self.client_key_path,
                token=auth_token,
                headers=headers,
                skip_version_check=self.skip_version_check,
            )

            # Map CLI transport to Client transport type
            transport_type = (
                TransportType.GRPC if self.transport == TransportFormat.GRPC else TransportType.REST
            )
            self._client = Client(config=config, transport=transport_type)
        return self._client

    def get_formatter(self) -> OutputFormatter:
        """Get the output formatter based on format setting."""
        if self.output_format == OutputFormat.JSON:
            return JSONFormatter()
        elif self.output_format == OutputFormat.YAML:
            return YAMLFormatter()
        else:
            return TableFormatter()

    @property
    def console(self) -> Console:
        """Get the shared stdout console.

        This console respects NO_COLOR environment variable and
        auto-detects terminal capabilities. Use this for all
        table output to ensure proper terminal detection.

        Returns:
            Shared Console instance for stdout.
        """
        if self._console is None:
            self._console = Console(no_color=self.no_color)
        return self._console

    @property
    def err_console(self) -> Console:
        """Get the shared stderr console.

        Use this for error messages and warnings.

        Returns:
            Shared Console instance for stderr.
        """
        if self._err_console is None:
            self._err_console = Console(file=sys.stderr, no_color=self.no_color)
        return self._err_console

    def close(self) -> None:
        """Close the client connection."""
        if self._client is not None:
            self._client.close()
            self._client = None

    def print_formatted(self, data: Any, headers: list[str], is_list: bool = False) -> None:
        """Format and print output based on context settings.

        For JSON/YAML: formats to string and prints (no ANSI codes).
        For TABLE: prints directly via Rich console (terminal-aware).

        Args:
            data: The data to print (single item or list).
            headers: Column headers for table formatting.
            is_list: Whether to format as a list of items.
        """
        items = data if isinstance(data, list) else [data]

        if self.output_format == OutputFormat.JSON:
            json_fmt = JSONFormatter()
            output = json_fmt.format_list(items, headers) if is_list else json_fmt.format(data)
            print(output)
        elif self.output_format == OutputFormat.YAML:
            yaml_fmt = YAMLFormatter()
            output = yaml_fmt.format_list(items, headers) if is_list else yaml_fmt.format(data)
            print(output)
        else:
            # TABLE format - print directly for terminal detection
            table_fmt = TableFormatter(headers)
            if is_list:
                table_fmt.print_list(items, self.console, headers)
            else:
                table_fmt.print(data, self.console)


__all__ = ["CLIContext", "OutputFormat", "TransportFormat"]
