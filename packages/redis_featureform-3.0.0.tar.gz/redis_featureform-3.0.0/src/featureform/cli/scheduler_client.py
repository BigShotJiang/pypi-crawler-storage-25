"""Scheduler client abstraction supporting both REST and gRPC transports."""

from __future__ import annotations

from collections.abc import Sequence
from importlib import import_module
from typing import TYPE_CHECKING, Any, NamedTuple, NoReturn, Protocol, cast
from uuid import UUID

import grpc
import httpx
from google.protobuf.json_format import MessageToDict

from featureform._internal.http import httpx_ssl_context
from featureform._internal.logging import get_logger
from featureform.cli.commands._common import resolve_workspace_id
from featureform.cli.utils import CLIContext, TransportFormat
from featureform.transport.grpc import TimeoutStubProxy, create_grpc_channel

scheduler_pb2: Any = None
scheduler_pb2_grpc: Any = None
_logger = get_logger("featureform.cli.scheduler_client")
_VALID_EXTERNAL_EXECUTION_STATUSES = ("PENDING", "RUNNING", "SUCCEEDED", "FAILED", "CANCELED")

try:
    _scheduler_pb2 = import_module("featureform._generated.proto.scheduler.v1.scheduler_pb2")
    _scheduler_pb2_grpc = import_module(
        "featureform._generated.proto.scheduler.v1.scheduler_pb2_grpc"
    )
except ImportError:
    pass
else:
    scheduler_pb2 = _scheduler_pb2
    scheduler_pb2_grpc = _scheduler_pb2_grpc

if TYPE_CHECKING:
    _UnaryUnaryClientInterceptor = grpc.UnaryUnaryClientInterceptor[Any, Any]
    _UnaryStreamClientInterceptor = grpc.UnaryStreamClientInterceptor[Any, Any]
else:
    _UnaryUnaryClientInterceptor = grpc.UnaryUnaryClientInterceptor
    _UnaryStreamClientInterceptor = grpc.UnaryStreamClientInterceptor


class _ClientCallDetails(NamedTuple):
    method: str
    timeout: float | None
    metadata: Sequence[tuple[str, str | bytes]] | None
    credentials: grpc.CallCredentials | None
    wait_for_ready: bool | None
    compression: grpc.Compression | None


class _BearerTokenClientInterceptor(
    _UnaryUnaryClientInterceptor,
    _UnaryStreamClientInterceptor,
):
    """Attach bearer auth metadata to scheduler gRPC calls."""

    def __init__(self, metadata: Sequence[tuple[str, str]]) -> None:
        self._metadata = tuple(metadata)

    def _augment_details(self, client_call_details: grpc.ClientCallDetails) -> _ClientCallDetails:
        existing_metadata = tuple(client_call_details.metadata or ())
        return _ClientCallDetails(
            method=client_call_details.method,
            timeout=client_call_details.timeout,
            metadata=existing_metadata + self._metadata,
            credentials=client_call_details.credentials,
            wait_for_ready=getattr(client_call_details, "wait_for_ready", None),
            compression=getattr(client_call_details, "compression", None),
        )

    def intercept_unary_unary(
        self,
        continuation: Any,
        client_call_details: grpc.ClientCallDetails,
        request: Any,
    ) -> Any:
        return continuation(self._augment_details(client_call_details), request)

    def intercept_unary_stream(
        self,
        continuation: Any,
        client_call_details: grpc.ClientCallDetails,
        request: Any,
    ) -> Any:
        return continuation(self._augment_details(client_call_details), request)


class SchedulerClientError(Exception):
    """Base exception for scheduler client errors."""

    def __init__(self, message: str, code: int = 1):
        super().__init__(message)
        self.message = message
        self.code = code


class NotFoundError(SchedulerClientError):
    """Resource not found error."""

    def __init__(self, resource_type: str, resource_id: str):
        super().__init__(f"{resource_type} '{resource_id}' not found.", code=3)
        self.resource_type = resource_type
        self.resource_id = resource_id


class QueueAlreadyExistsError(SchedulerClientError):
    """Queue already exists."""

    def __init__(self, name: str):
        super().__init__(f"Queue '{name}' already exists", code=1)
        self.queue_name = name


class SchedulerUnavailableError(SchedulerClientError):
    """Scheduler service is unavailable."""


class SchedulerApplyJobFailedError(SchedulerClientError):
    """Apply job finished in a failed terminal state."""

    def __init__(
        self,
        job_id: str,
        status: str,
        *,
        detail: str | None = None,
        job: dict[str, Any] | None = None,
    ):
        message = f"Apply job '{job_id}' finished with status {status}."
        if detail:
            message = f"{message} {detail}"
        super().__init__(message, code=1)
        self.job_id = job_id
        self.status = status
        self.detail = detail
        self.job = job


class SchedulerApplyTimeoutError(SchedulerClientError):
    """Timed out waiting for apply job completion."""

    def __init__(
        self,
        job_id: str,
        *,
        wait_for: str | None = None,
        last_status: str | None = None,
        waiting_for_visibility: bool = False,
    ):
        if waiting_for_visibility:
            message = f"Timed out waiting for job '{job_id}' to become visible."
        elif wait_for is not None and last_status is not None:
            message = (
                f"Timed out waiting for job '{job_id}' to reach {wait_for}. "
                f"Last status: {last_status}."
            )
        else:
            message = f"Timed out waiting for job '{job_id}'"
        super().__init__(message, code=1)
        self.job_id = job_id
        self.wait_for = wait_for
        self.last_status = last_status
        self.waiting_for_visibility = waiting_for_visibility


class SchedulerServiceStub(Protocol):
    """Typed interface for the scheduler gRPC stub."""

    def ListQueues(self, request: Any) -> Any: ...
    def GetQueue(self, request: Any) -> Any: ...
    def CreateQueue(self, request: Any) -> Any: ...
    def GetStats(self, request: Any) -> Any: ...
    def ListJobs(self, request: Any) -> Any: ...
    def GetJob(self, request: Any) -> Any: ...
    def ListGroups(self, request: Any) -> Any: ...
    def GetGroup(self, request: Any) -> Any: ...
    def ListGroupJobs(self, request: Any) -> Any: ...
    def CancelGroup(self, request: Any) -> Any: ...
    def ListExternalExecutions(self, request: Any) -> Any: ...
    def GetExternalExecution(self, request: Any) -> Any: ...
    def CancelJob(self, request: Any) -> Any: ...
    def RetryJob(self, request: Any) -> Any: ...
    def GetJobLogs(self, request: Any) -> Any: ...
    def GetTask(self, request: Any) -> Any: ...
    def GetTaskLogs(self, request: Any) -> Any: ...
    def ListScheduledJobs(self, request: Any) -> Any: ...
    def GetScheduledJob(self, request: Any) -> Any: ...
    def PauseScheduledJob(self, request: Any) -> Any: ...
    def ResumeScheduledJob(self, request: Any) -> Any: ...
    def TriggerScheduledJob(self, request: Any) -> Any: ...
    def DeleteScheduledJob(self, request: Any) -> Any: ...


class SchedulerClient:
    """Abstract scheduler client that works with both REST and gRPC."""

    def __init__(self, cli_ctx: CLIContext):
        self.cli_ctx = cli_ctx
        self._grpc_channel: grpc.Channel | None = None
        self._grpc_stub: SchedulerServiceStub | None = None

    def _get_scheduler_pb2(self) -> Any:
        """Get the generated scheduler protobuf module."""
        global scheduler_pb2
        if scheduler_pb2 is None:
            scheduler_pb2 = import_module("featureform._generated.proto.scheduler.v1.scheduler_pb2")
        return scheduler_pb2

    def _get_grpc_channel(self) -> grpc.Channel:
        """Get or create gRPC channel."""
        if self._grpc_channel is None:
            channel = create_grpc_channel(
                self.cli_ctx.base_url,
                self.cli_ctx.verify_ssl,
                no_tls=self.cli_ctx.no_tls,
                ca_cert_path=self.cli_ctx.ca_cert_path,
                client_cert_path=self.cli_ctx.client_cert_path,
                client_key_path=self.cli_ctx.client_key_path,
            )
            auth_token = self.cli_ctx.get_auth_token()
            if auth_token:
                intercept_channel = cast(Any, grpc).intercept_channel
                channel = intercept_channel(
                    channel,
                    _BearerTokenClientInterceptor((("authorization", f"Bearer {auth_token}"),)),
                )
            self._grpc_channel = channel
        assert self._grpc_channel is not None
        return self._grpc_channel

    def _get_grpc_stub(self) -> SchedulerServiceStub:
        """Get or create gRPC stub."""
        if self._grpc_stub is None:
            global scheduler_pb2_grpc
            if scheduler_pb2_grpc is None:
                scheduler_pb2_grpc = import_module(
                    "featureform._generated.proto.scheduler.v1.scheduler_pb2_grpc"
                )
            channel = self._get_grpc_channel()
            self._grpc_stub = cast(
                SchedulerServiceStub,
                TimeoutStubProxy(
                    scheduler_pb2_grpc.SchedulerServiceStub(channel),
                    default_timeout=self.cli_ctx.timeout,
                    logger=_logger,
                    stub_name="SchedulerServiceStub",
                ),
            )
        return self._grpc_stub

    def _make_rest_request(
        self,
        method: str,
        path: str,
        params: dict[str, Any] | None = None,
        json_data: dict[str, Any] | None = None,
    ) -> httpx.Response:
        """Make REST API request."""
        rest_url = self.cli_ctx.get_rest_url()
        url = f"{rest_url.rstrip('/')}/api/v1{path}"
        headers: dict[str, str] = {}
        auth_token = self.cli_ctx.get_auth_token()
        if auth_token:
            headers["Authorization"] = f"Bearer {auth_token}"

        with httpx.Client(
            verify=httpx_ssl_context(
                self.cli_ctx.verify_ssl,
                self.cli_ctx.ca_cert_path,
                self.cli_ctx.client_cert_path,
                self.cli_ctx.client_key_path,
            ),
            timeout=httpx.Timeout(self.cli_ctx.timeout, connect=5.0),
        ) as client:
            return client.request(method, url, params=params, json=json_data, headers=headers)

    def _use_grpc(self) -> bool:
        """Check if gRPC transport should be used."""
        return self.cli_ctx.transport == TransportFormat.GRPC

    def _normalize_external_execution_status(self, status: str) -> str:
        """Validate and normalize an external execution status filter."""
        normalized = status.upper()
        if normalized not in _VALID_EXTERNAL_EXECUTION_STATUSES:
            valid = ", ".join(_VALID_EXTERNAL_EXECUTION_STATUSES)
            raise SchedulerClientError(
                f"invalid status '{status}': must be one of {valid}",
            )
        return normalized

    def _resolve_workspace_id(self, workspace: str) -> str:
        """Resolve a workspace name or UUID string to a UUID string."""
        try:
            return str(UUID(workspace))
        except ValueError:
            client = self.cli_ctx.get_client()
            return str(resolve_workspace_id(client, workspace))

    def list_queues(self, workspace: str) -> list[dict[str, Any]]:
        """List all queues with stats."""
        if self._use_grpc():
            return self._list_queues_grpc(workspace)
        return self._list_queues_rest(workspace)

    def _list_queues_grpc(self, workspace: str) -> list[dict[str, Any]]:
        """List queues via gRPC."""
        stub = self._get_grpc_stub()
        pb = self._get_scheduler_pb2()
        workspace_id = self._resolve_workspace_id(workspace)
        resp = stub.ListQueues(pb.ListQueuesRequest(workspace_id=workspace_id))
        return [self._queue_with_stats_to_dict(q) for q in resp.queues]

    def _list_queues_rest(self, workspace: str) -> list[dict[str, Any]]:
        """List queues via REST."""
        workspace_id = self._resolve_workspace_id(workspace)
        resp = self._make_rest_request(
            "GET", "/scheduler/queues", params={"workspace_id": workspace_id}
        )
        if not resp.is_success:
            self._handle_rest_error(resp, "Queues", "")
        data = resp.json()
        return [self._transform_rest_queue(q) for q in data.get("queues", [])]

    def get_queue(self, workspace: str, name: str) -> dict[str, Any]:
        """Get a queue by name."""
        if self._use_grpc():
            return self._get_queue_grpc(workspace, name)
        return self._get_queue_rest(workspace, name)

    def _get_queue_grpc(self, workspace: str, name: str) -> dict[str, Any]:
        """Get queue via gRPC."""
        stub = self._get_grpc_stub()
        pb = self._get_scheduler_pb2()
        workspace_id = self._resolve_workspace_id(workspace)
        try:
            resp = stub.GetQueue(pb.GetQueueRequest(workspace_id=workspace_id, name=name))
            return self._queue_with_stats_to_dict(resp.queue)
        except grpc.RpcError as e:
            if e.code() == grpc.StatusCode.NOT_FOUND:
                raise NotFoundError("Queue", name) from e
            raise SchedulerClientError(str(e.details())) from e

    def _get_queue_rest(self, workspace: str, name: str) -> dict[str, Any]:
        """Get queue via REST.

        REST API returns {"queue": {"queue": {...}, "stats": {...}}}.
        We pass the inner wrapper to _transform_rest_queue which expects
        {"queue": {...}, "stats": {...}}.
        """
        workspace_id = self._resolve_workspace_id(workspace)
        resp = self._make_rest_request(
            "GET",
            f"/scheduler/queues/{name}",
            params={"workspace_id": workspace_id},
        )
        if not resp.is_success:
            self._handle_rest_error(resp, "Queue", name)
        data = resp.json()
        # Extract the inner {"queue": {...}, "stats": {...}} wrapper
        queue_with_stats = data.get("queue", {})
        return self._transform_rest_queue(queue_with_stats)

    def _queue_with_stats_to_dict(self, qws: Any) -> dict[str, Any]:
        """Convert gRPC QueueWithStats to dict."""
        pb = self._get_scheduler_pb2()
        queue = qws.queue
        stats = qws.stats
        return {
            "name": queue.name,
            "mode": pb.ExecutionMode.Name(queue.mode).replace("EXECUTION_MODE_", ""),
            "pending": stats.pending_jobs,
            "running": stats.running_jobs,
            "completed": stats.completed_jobs + stats.completed_with_warnings_jobs,
            "failed": stats.failed_jobs,
        }

    def _transform_rest_queue(self, item: dict[str, Any]) -> dict[str, Any]:
        """Transform REST API queue response to common format.

        Expects item to be {"queue": {...}, "stats": {...}}.
        """
        queue = item.get("queue", {})
        stats = item.get("stats", {})
        return {
            "name": queue.get("name", ""),
            "mode": queue.get("execution_mode", queue.get("mode", "")),
            "pending": stats.get("pending_jobs", 0),
            "running": stats.get("running_jobs", 0),
            "completed": stats.get("completed_jobs", 0)
            + stats.get("completed_with_warnings_jobs", 0),
            "failed": stats.get("failed_jobs", 0),
        }

    def _handle_rest_error(
        self, resp: httpx.Response, resource_type: str, resource_id: str
    ) -> None:
        """Handle REST API errors."""
        if resp.status_code == 404:
            raise NotFoundError(resource_type, resource_id)
        if resp.status_code == 503:
            raise SchedulerUnavailableError("scheduler unavailable")
        raise SchedulerClientError(f"HTTP {resp.status_code}: {resp.text}", code=1)

    def _handle_grpc_error(
        self, error: grpc.RpcError, resource_type: str, resource_id: str
    ) -> NoReturn:
        """Convert gRPC errors to scheduler client errors."""
        if error.code() == grpc.StatusCode.NOT_FOUND:
            raise NotFoundError(resource_type, resource_id) from error
        if error.code() == grpc.StatusCode.ALREADY_EXISTS:
            raise QueueAlreadyExistsError(resource_id) from error
        if error.code() == grpc.StatusCode.UNAVAILABLE:
            raise SchedulerUnavailableError("scheduler unavailable") from error
        detail = error.details() or str(error)
        if error.code() == grpc.StatusCode.INTERNAL and "scheduler unavailable" in detail.lower():
            raise SchedulerUnavailableError("scheduler unavailable") from error
        raise SchedulerClientError(detail) from error

    def create_queue(self, workspace: str, name: str, mode: str) -> dict[str, Any]:
        """Create a new queue."""
        if self._use_grpc():
            return self._create_queue_grpc(workspace, name, mode)
        return self._create_queue_rest(workspace, name, mode)

    def _create_queue_grpc(self, workspace: str, name: str, mode: str) -> dict[str, Any]:
        """Create queue via gRPC."""
        stub = self._get_grpc_stub()
        pb = self._get_scheduler_pb2()
        exec_mode = pb.ExecutionMode.Value(f"EXECUTION_MODE_{mode.upper()}")
        workspace_id = self._resolve_workspace_id(workspace)
        try:
            resp = stub.CreateQueue(
                pb.CreateQueueRequest(workspace_id=workspace_id, name=name, mode=exec_mode)
            )
            return {"name": resp.queue.name, "mode": mode}
        except grpc.RpcError as e:
            if e.code() == grpc.StatusCode.ALREADY_EXISTS:
                raise QueueAlreadyExistsError(name) from e
            raise SchedulerClientError(str(e.details())) from e

    def _create_queue_rest(self, workspace: str, name: str, mode: str) -> dict[str, Any]:
        """Create queue via REST."""
        workspace_id = self._resolve_workspace_id(workspace)
        resp = self._make_rest_request(
            "POST",
            "/scheduler/queues",
            json_data={"workspace_id": workspace_id, "name": name, "execution_mode": mode},
        )
        if not resp.is_success:
            self._handle_rest_error(resp, "Queue", name)
        return resp.json()  # type: ignore[no-any-return]

    def get_stats(self, workspace: str, queue_name: str | None = None) -> dict[str, Any]:
        """Get scheduler statistics."""
        if self._use_grpc():
            return self._get_stats_grpc(workspace, queue_name)
        return self._get_stats_rest(workspace, queue_name)

    def _get_stats_grpc(self, workspace: str, queue_name: str | None) -> dict[str, Any]:
        """Get stats via gRPC."""
        stub = self._get_grpc_stub()
        pb = self._get_scheduler_pb2()
        workspace_id = self._resolve_workspace_id(workspace)
        req = pb.GetStatsRequest(workspace_id=workspace_id)
        if queue_name:
            req.queue_name = queue_name
        resp = stub.GetStats(req)
        return self._stats_response_to_dict(resp)

    def _get_stats_rest(self, workspace: str, queue_name: str | None) -> dict[str, Any]:
        """Get stats via REST."""
        # REST API expects 'queue' parameter, not 'queue_name'
        workspace_id = self._resolve_workspace_id(workspace)
        params: dict[str, Any] = {"workspace_id": workspace_id}
        if queue_name:
            params["queue"] = queue_name
        resp = self._make_rest_request("GET", "/scheduler/stats", params=params)
        if not resp.is_success:
            self._handle_rest_error(resp, "Stats", queue_name or "")
        return resp.json()  # type: ignore[no-any-return]

    def _stats_response_to_dict(self, resp: Any) -> dict[str, Any]:
        """Convert gRPC stats response to dict.

        Returns data in a format compatible with both display code and JSON output.
        The display code expects nested format for by_queue: {"queue": {...}, "stats": {...}}.
        """
        overall = resp.overall
        result: dict[str, Any] = {
            "overall": {
                "pending_jobs": overall.pending_jobs,
                "running_jobs": overall.running_jobs,
                "completed_jobs": overall.completed_jobs,
                "completed_with_warnings_jobs": overall.completed_with_warnings_jobs,
                "failed_jobs": overall.failed_jobs,
            }
        }
        if resp.by_queue:
            result["by_queue"] = [self._queue_with_stats_to_nested_dict(q) for q in resp.by_queue]
        return result

    def _queue_with_stats_to_nested_dict(self, qws: Any) -> dict[str, Any]:
        """Convert gRPC QueueWithStats to nested dict for stats display.

        Returns format: {"queue": {"name": ...}, "stats": {"pending_jobs": ..., ...}}
        This matches the format expected by the stats command display code.
        """
        pb = self._get_scheduler_pb2()
        queue = qws.queue
        stats = qws.stats
        return {
            "queue": {
                "name": queue.name,
                "mode": pb.ExecutionMode.Name(queue.mode).replace("EXECUTION_MODE_", ""),
            },
            "stats": {
                "pending_jobs": stats.pending_jobs,
                "running_jobs": stats.running_jobs,
                "completed_jobs": stats.completed_jobs,
                "completed_with_warnings_jobs": stats.completed_with_warnings_jobs,
                "failed_jobs": stats.failed_jobs,
            },
        }

    def list_jobs(
        self,
        workspace: str,
        queue_name: str | None = None,
        statuses: list[str] | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict[str, Any]:
        """List jobs with optional filters."""
        if self._use_grpc():
            return self._list_jobs_grpc(workspace, queue_name, statuses, limit, offset)
        return self._list_jobs_rest(workspace, queue_name, statuses, limit, offset)

    def _list_jobs_grpc(
        self,
        workspace: str,
        queue_name: str | None,
        statuses: list[str] | None,
        limit: int,
        offset: int,
    ) -> dict[str, Any]:
        """List jobs via gRPC."""
        stub = self._get_grpc_stub()
        pb = self._get_scheduler_pb2()
        pagination = pb.PaginationRequest(limit=limit, offset=offset)
        workspace_id = self._resolve_workspace_id(workspace)
        req = pb.ListJobsRequest(workspace_id=workspace_id, pagination=pagination)
        if queue_name:
            req.queue_name = queue_name
        if statuses:
            for s in statuses:
                status_enum = pb.JobStatus.Value(f"JOB_STATUS_{s.upper()}")
                req.statuses.append(status_enum)
        resp = stub.ListJobs(req)
        return {
            "jobs": [self._job_to_dict(j) for j in resp.jobs],
            "total_count": resp.pagination.total_count,
            "has_more": resp.pagination.has_more,
        }

    def _list_jobs_rest(
        self,
        workspace: str,
        queue_name: str | None,
        statuses: list[str] | None,
        limit: int,
        offset: int,
    ) -> dict[str, Any]:
        """List jobs via REST."""
        workspace_id = self._resolve_workspace_id(workspace)
        params: dict[str, Any] = {"workspace_id": workspace_id, "limit": limit, "offset": offset}
        if queue_name:
            params["queue"] = queue_name
        if statuses:
            params["status"] = ",".join(s.upper() for s in statuses)
        resp = self._make_rest_request("GET", "/scheduler/jobs", params=params)
        if not resp.is_success:
            self._handle_rest_error(resp, "Jobs", "")
        return resp.json()  # type: ignore[no-any-return]

    def _job_to_dict(self, job: Any) -> dict[str, Any]:
        """Convert gRPC Job to dict."""
        pb = self._get_scheduler_pb2()
        data = {
            "id": job.id,
            "workspace_id": job.workspace_id,
            "queue_name": job.queue_name,
            "name": job.name,
            "status": pb.JobStatus.Name(job.status).replace("JOB_STATUS_", ""),
            "worker_id": job.worker_id,
            "error_message": job.error_message,
            "retry_count": job.retry_count,
            "max_retries": job.max_retries,
            "priority": job.priority,
            "created_at": job.created_at.ToDatetime().isoformat()
            if job.HasField("created_at")
            else "",
            "started_at": job.started_at.ToDatetime().isoformat()
            if job.HasField("started_at")
            else "",
            "completed_at": job.completed_at.ToDatetime().isoformat()
            if job.HasField("completed_at")
            else "",
            "cancel_requested_at": job.cancel_requested_at.ToDatetime().isoformat()
            if job.HasField("cancel_requested_at")
            else "",
            "last_heartbeat": job.last_heartbeat.ToDatetime().isoformat()
            if job.HasField("last_heartbeat")
            else "",
            "heartbeat_deadline": job.heartbeat_deadline.ToDatetime().isoformat()
            if job.HasField("heartbeat_deadline")
            else "",
            "claim_generation": job.claim_generation,
            "retry_after": job.retry_after.ToDatetime().isoformat()
            if job.HasField("retry_after")
            else "",
        }
        if getattr(job, "group_id", ""):
            data["group_id"] = job.group_id
        if getattr(job, "group_index", 0) or getattr(job, "group_id", ""):
            data["group_index"] = job.group_index
        return data

    def _group_to_dict(self, group: Any) -> dict[str, Any]:
        """Convert gRPC GroupWithCounts to a flat dict."""
        pb = self._get_scheduler_pb2()
        group_meta = group.group
        data = {
            "id": group_meta.id,
            "workspace_id": group_meta.workspace_id,
            "queue_id": group_meta.queue_id,
            "name": group_meta.name,
            "kind": group_meta.kind,
            "request_id": group_meta.request_id,
            "metadata": self._proto_struct_to_dict(group_meta.metadata)
            if group_meta.HasField("metadata")
            else {},
            "created_at": group_meta.created_at.ToDatetime().isoformat()
            if group_meta.HasField("created_at")
            else "",
            "updated_at": group_meta.updated_at.ToDatetime().isoformat()
            if group_meta.HasField("updated_at")
            else "",
            "cancel_requested_at": group_meta.cancel_requested_at.ToDatetime().isoformat()
            if group_meta.HasField("cancel_requested_at")
            else "",
            "terminal_at": group_meta.terminal_at.ToDatetime().isoformat()
            if group_meta.HasField("terminal_at")
            else "",
            "status": pb.GroupStatus.Name(group.status).replace("GROUP_STATUS_", ""),
            "total_jobs": group.counts.total_jobs,
            "pending_jobs": group.counts.pending_jobs,
            "running_jobs": group.counts.running_jobs,
            "completed_jobs": group.counts.completed_jobs,
            "failed_jobs": group.counts.failed_jobs,
            "canceled_jobs": group.counts.canceled_jobs,
        }
        return data

    def _transform_rest_group(self, item: dict[str, Any]) -> dict[str, Any]:
        """Transform REST API group wrapper to the CLI's flat shape."""
        group = item.get("group", {})
        counts = item.get("counts", {})
        return {
            "id": group.get("id", ""),
            "workspace_id": group.get("workspace_id", ""),
            "queue_id": group.get("queue_id", ""),
            "name": group.get("name", ""),
            "kind": group.get("kind", ""),
            "request_id": group.get("request_id", ""),
            "metadata": group.get("metadata", {}) or {},
            "created_at": group.get("created_at", ""),
            "updated_at": group.get("updated_at", ""),
            "cancel_requested_at": group.get("cancel_requested_at", ""),
            "terminal_at": group.get("terminal_at", ""),
            "status": item.get("status", ""),
            "total_jobs": counts.get("total_jobs", 0),
            "pending_jobs": counts.get("pending_jobs", 0),
            "running_jobs": counts.get("running_jobs", 0),
            "completed_jobs": counts.get("completed_jobs", 0),
            "failed_jobs": counts.get("failed_jobs", 0),
            "canceled_jobs": counts.get("canceled_jobs", 0),
        }

    def list_groups(
        self,
        workspace: str,
        *,
        queue_name: str | None = None,
        kind: str | None = None,
        statuses: list[str] | None = None,
        limit: int = 0,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        """List scheduler groups."""
        if self._use_grpc():
            stub = self._get_grpc_stub()
            pb = self._get_scheduler_pb2()
            workspace_id = self._resolve_workspace_id(workspace)
            req = pb.ListGroupsRequest(workspace_id=workspace_id)
            if queue_name:
                req.queue_name = queue_name
            if kind:
                req.kind = kind
            if statuses:
                for status in statuses:
                    req.statuses.append(pb.GroupStatus.Value(f"GROUP_STATUS_{status.upper()}"))
            if limit or offset:
                req.pagination.CopyFrom(pb.PaginationRequest(limit=limit, offset=offset))
            try:
                resp = stub.ListGroups(req)
                return [self._group_to_dict(group) for group in resp.groups]
            except grpc.RpcError as error:
                self._handle_grpc_error(error, "Groups", workspace_id)

        workspace_id = self._resolve_workspace_id(workspace)
        params: dict[str, Any] = {"workspace_id": workspace_id}
        if queue_name:
            params["queue_name"] = queue_name
        if kind:
            params["kind"] = kind
        if statuses:
            params["status"] = [status.upper() for status in statuses]
        if limit:
            params["limit"] = limit
        if offset:
            params["offset"] = offset
        resp = self._make_rest_request("GET", "/scheduler/groups", params=params)
        if not resp.is_success:
            self._handle_rest_error(resp, "Groups", workspace_id)
        data = resp.json()
        return [self._transform_rest_group(group) for group in data.get("groups", [])]

    def get_group(self, group_id: str) -> dict[str, Any]:
        """Get a scheduler group by ID."""
        if self._use_grpc():
            stub = self._get_grpc_stub()
            pb = self._get_scheduler_pb2()
            try:
                resp = stub.GetGroup(pb.GetGroupRequest(group_id=group_id))
                return self._group_to_dict(resp.group)
            except grpc.RpcError as error:
                self._handle_grpc_error(error, "Group", group_id)

        resp = self._make_rest_request("GET", f"/scheduler/groups/{group_id}")
        if not resp.is_success:
            self._handle_rest_error(resp, "Group", group_id)
        data = resp.json()
        return self._transform_rest_group(data.get("group", {}))

    def list_group_jobs(
        self,
        group_id: str,
        *,
        limit: int = 0,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        """List jobs for a scheduler group."""
        if self._use_grpc():
            stub = self._get_grpc_stub()
            pb = self._get_scheduler_pb2()
            req = pb.ListGroupJobsRequest(group_id=group_id)
            if limit or offset:
                req.pagination.CopyFrom(pb.PaginationRequest(limit=limit, offset=offset))
            try:
                resp = stub.ListGroupJobs(req)
                return [self._job_to_dict(job) for job in resp.jobs]
            except grpc.RpcError as error:
                self._handle_grpc_error(error, "Group", group_id)

        params: dict[str, Any] = {}
        if limit:
            params["limit"] = limit
        if offset:
            params["offset"] = offset
        resp = self._make_rest_request("GET", f"/scheduler/groups/{group_id}/jobs", params=params)
        if not resp.is_success:
            self._handle_rest_error(resp, "Group", group_id)
        data = resp.json()
        return data.get("jobs", [])  # type: ignore[no-any-return]

    def cancel_group(self, group_id: str) -> dict[str, Any]:
        """Cancel a scheduler group by ID."""
        if self._use_grpc():
            stub = self._get_grpc_stub()
            pb = self._get_scheduler_pb2()
            try:
                resp = stub.CancelGroup(pb.CancelGroupRequest(group_id=group_id))
                return self._group_to_dict(resp.group)
            except grpc.RpcError as error:
                self._handle_grpc_error(error, "Group", group_id)

        resp = self._make_rest_request("POST", f"/scheduler/groups/{group_id}/cancel")
        if not resp.is_success:
            self._handle_rest_error(resp, "Group", group_id)
        data = resp.json()
        return self._transform_rest_group(data.get("group", {}))

    def _external_execution_summary_to_dict(self, execution: Any) -> dict[str, Any]:
        """Convert gRPC ExternalExecutionSummary to dict."""
        pb = self._get_scheduler_pb2()
        return {
            "id": execution.id,
            "provider_id": execution.provider_id,
            "external_id": execution.external_id,
            "external_name": execution.external_name,
            "external_url": execution.external_url,
            "status": pb.ExternalExecutionStatus.Name(execution.status).replace(
                "EXTERNAL_EXECUTION_STATUS_", ""
            ),
            "raw_status": execution.raw_status,
            "error": execution.error,
            "submitted_at": execution.submitted_at.ToDatetime().isoformat()
            if execution.HasField("submitted_at")
            else "",
            "started_at": execution.started_at.ToDatetime().isoformat()
            if execution.HasField("started_at")
            else "",
            "completed_at": execution.completed_at.ToDatetime().isoformat()
            if execution.HasField("completed_at")
            else "",
            "created_at": execution.created_at.ToDatetime().isoformat()
            if execution.HasField("created_at")
            else "",
            "updated_at": execution.updated_at.ToDatetime().isoformat()
            if execution.HasField("updated_at")
            else "",
        }

    def _external_execution_to_dict(self, execution: Any) -> dict[str, Any]:
        """Convert gRPC ExternalExecution to dict."""
        pb = self._get_scheduler_pb2()
        return {
            "id": execution.id,
            "workspace_id": execution.workspace_id,
            "provider_id": execution.provider_id,
            "scheduler_job_id": execution.scheduler_job_id,
            "scheduler_task_id": execution.scheduler_task_id,
            "idempotency_key": execution.idempotency_key,
            "external_id": execution.external_id,
            "external_name": execution.external_name,
            "external_url": execution.external_url,
            "status": pb.ExternalExecutionStatus.Name(execution.status).replace(
                "EXTERNAL_EXECUTION_STATUS_", ""
            ),
            "raw_status": execution.raw_status,
            "error": execution.error,
            "submitted_at": execution.submitted_at.ToDatetime().isoformat()
            if execution.HasField("submitted_at")
            else "",
            "started_at": execution.started_at.ToDatetime().isoformat()
            if execution.HasField("started_at")
            else "",
            "completed_at": execution.completed_at.ToDatetime().isoformat()
            if execution.HasField("completed_at")
            else "",
            "version": execution.version,
            "metadata": self._proto_struct_to_dict(execution.metadata)
            if execution.HasField("metadata")
            else {},
            "logs": [self._proto_struct_to_dict(entry) for entry in execution.logs],
            "artifacts": self._proto_struct_to_dict(execution.artifacts)
            if execution.HasField("artifacts")
            else {},
            "created_at": execution.created_at.ToDatetime().isoformat()
            if execution.HasField("created_at")
            else "",
            "updated_at": execution.updated_at.ToDatetime().isoformat()
            if execution.HasField("updated_at")
            else "",
        }

    def _proto_struct_to_dict(self, value: Any) -> dict[str, Any]:
        """Convert a protobuf Struct message to a plain dict."""
        if value is None:
            return {}
        return MessageToDict(value)

    def _task_to_dict(self, task: Any) -> dict[str, Any]:
        """Convert gRPC task to dict."""
        pb = self._get_scheduler_pb2()
        data = {
            "id": task.id,
            "job_id": task.job_id,
            "task_def_id": task.task_def_id,
            "status": pb.TaskStatus.Name(task.status).replace("TASK_STATUS_", ""),
            "critical": task.critical,
            "error_message": task.error_message,
            "retry_count": task.retry_count,
            "max_retries": task.max_retries,
            "started_at": task.started_at.ToDatetime().isoformat()
            if task.HasField("started_at")
            else "",
            "completed_at": task.completed_at.ToDatetime().isoformat()
            if task.HasField("completed_at")
            else "",
        }
        if task.HasField("external_execution"):
            data["external_execution"] = self._external_execution_summary_to_dict(
                task.external_execution
            )
        return data

    def _log_entry_to_dict(self, entry: Any) -> dict[str, Any]:
        """Convert gRPC log entry to dict."""
        pb = self._get_scheduler_pb2()
        return {
            "id": entry.id,
            "task_id": entry.task_id,
            "job_id": entry.job_id,
            "level": pb.LogLevel.Name(entry.level).replace("LOG_LEVEL_", ""),
            "message": entry.message,
            "timestamp": entry.timestamp.ToDatetime().isoformat()
            if entry.HasField("timestamp")
            else "",
        }

    def _scheduled_job_to_dict(self, job: Any) -> dict[str, Any]:
        """Convert gRPC scheduled job to dict."""
        return {
            "id": job.id,
            "name": job.name,
            "queue_name": job.queue_name,
            "schedule": job.schedule,
            "cron_expression": job.schedule,
            "enabled": job.enabled,
            "next_run_at": job.next_run_at.ToDatetime().isoformat()
            if job.HasField("next_run_at")
            else "",
            "last_run_at": job.last_run_at.ToDatetime().isoformat()
            if job.HasField("last_run_at")
            else "",
            "created_at": job.created_at.ToDatetime().isoformat()
            if job.HasField("created_at")
            else "",
            "updated_at": job.updated_at.ToDatetime().isoformat()
            if job.HasField("updated_at")
            else "",
        }

    def get_job(self, job_id: str) -> dict[str, Any]:
        """Get a job by ID."""
        if self._use_grpc():
            stub = self._get_grpc_stub()
            pb = self._get_scheduler_pb2()
            try:
                grpc_resp = stub.GetJob(pb.GetJobRequest(job_id=job_id, include_tasks=True))
                data = self._job_to_dict(grpc_resp.job)
                if grpc_resp.tasks:
                    data["tasks"] = [self._task_to_dict(task) for task in grpc_resp.tasks]
                return data
            except grpc.RpcError as error:
                self._handle_grpc_error(error, "Job", job_id)
        rest_resp = self._make_rest_request("GET", f"/scheduler/jobs/{job_id}")
        if not rest_resp.is_success:
            self._handle_rest_error(rest_resp, "Job", job_id)
        data = rest_resp.json()
        job = data.get("job", {})
        if data.get("tasks"):
            job["tasks"] = data["tasks"]
        return job  # type: ignore[no-any-return]

    def list_external_executions(
        self,
        workspace: str,
        *,
        provider_id: str | None = None,
        job_id: str | None = None,
        task_id: str | None = None,
        status: str | None = None,
        external_id: str | None = None,
        limit: int = 50,
    ) -> dict[str, Any]:
        """List external executions."""
        if self._use_grpc():
            stub = self._get_grpc_stub()
            pb = self._get_scheduler_pb2()
            workspace_id = self._resolve_workspace_id(workspace)
            req = pb.ListExternalExecutionsRequest(
                workspace_id=workspace_id,
                pagination=pb.PaginationRequest(limit=limit),
            )
            if provider_id:
                req.provider_id = provider_id
            if job_id:
                req.scheduler_job_id = job_id
            if task_id:
                req.scheduler_task_id = task_id
            if status:
                normalized_status = self._normalize_external_execution_status(status)
                req.status = pb.ExternalExecutionStatus.Value(
                    f"EXTERNAL_EXECUTION_STATUS_{normalized_status}"
                )
            if external_id:
                req.external_id = external_id
            try:
                grpc_resp = stub.ListExternalExecutions(req)
                return {
                    "external_executions": [
                        self._external_execution_to_dict(execution)
                        for execution in grpc_resp.external_executions
                    ],
                    "total_count": grpc_resp.pagination.total_count,
                    "has_more": grpc_resp.pagination.has_more,
                }
            except grpc.RpcError as error:
                self._handle_grpc_error(error, "External execution", workspace_id)

        workspace_id = self._resolve_workspace_id(workspace)
        params: dict[str, Any] = {"workspace_id": workspace_id, "limit": limit}
        if provider_id:
            params["provider_id"] = provider_id
        if job_id:
            params["job_id"] = job_id
        if task_id:
            params["task_id"] = task_id
        if status:
            params["status"] = self._normalize_external_execution_status(status)
        if external_id:
            params["external_id"] = external_id
        rest_resp = self._make_rest_request("GET", "/scheduler/external-executions", params=params)
        if not rest_resp.is_success:
            self._handle_rest_error(rest_resp, "External executions", workspace_id)
        return rest_resp.json()  # type: ignore[no-any-return]

    def get_external_execution(self, execution_id: str) -> dict[str, Any]:
        """Get an external execution by ID."""
        if self._use_grpc():
            stub = self._get_grpc_stub()
            pb = self._get_scheduler_pb2()
            try:
                grpc_resp = stub.GetExternalExecution(
                    pb.GetExternalExecutionRequest(id=execution_id)
                )
                return self._external_execution_to_dict(grpc_resp.external_execution)
            except grpc.RpcError as error:
                self._handle_grpc_error(error, "External execution", execution_id)
        rest_resp = self._make_rest_request("GET", f"/scheduler/external-executions/{execution_id}")
        if not rest_resp.is_success:
            self._handle_rest_error(rest_resp, "External execution", execution_id)
        return rest_resp.json().get("external_execution", {})  # type: ignore[no-any-return]

    def list_tasks_for_job(self, job_id: str) -> list[dict[str, Any]]:
        """List tasks for a job by reusing the job details endpoint."""
        job = self.get_job(job_id)
        tasks = job.get("tasks", [])
        if not isinstance(tasks, list):
            raise SchedulerClientError(f"job '{job_id}' returned an invalid tasks payload")
        return tasks

    def cancel_job(self, job_id: str) -> dict[str, Any]:
        """Cancel a job."""
        if self._use_grpc():
            stub = self._get_grpc_stub()
            pb = self._get_scheduler_pb2()
            try:
                grpc_resp = stub.CancelJob(pb.CancelJobRequest(job_id=job_id))
                return self._job_to_dict(grpc_resp.job) if grpc_resp.HasField("job") else {}
            except grpc.RpcError as error:
                self._handle_grpc_error(error, "Job", job_id)
        rest_resp = self._make_rest_request("POST", f"/scheduler/jobs/{job_id}/cancel")
        if not rest_resp.is_success:
            self._handle_rest_error(rest_resp, "Job", job_id)
        payload = cast(dict[str, Any], rest_resp.json() if rest_resp.content else {})
        return cast(dict[str, Any], payload.get("job", payload))

    def retry_job(self, job_id: str) -> dict[str, Any]:
        """Retry a job."""
        if self._use_grpc():
            stub = self._get_grpc_stub()
            pb = self._get_scheduler_pb2()
            try:
                grpc_resp = stub.RetryJob(pb.RetryJobRequest(job_id=job_id))
                return self._job_to_dict(grpc_resp.job)
            except grpc.RpcError as error:
                self._handle_grpc_error(error, "Job", job_id)
        rest_resp = self._make_rest_request("POST", f"/scheduler/jobs/{job_id}/retries")
        if not rest_resp.is_success:
            self._handle_rest_error(rest_resp, "Job", job_id)
        payload = cast(dict[str, Any], rest_resp.json() if rest_resp.content else {})
        return cast(dict[str, Any], payload.get("job", payload))

    def get_job_logs(
        self, job_id: str, limit: int, level: str | None = None
    ) -> list[dict[str, Any]]:
        """Get logs for a job."""
        if self._use_grpc():
            stub = self._get_grpc_stub()
            pb = self._get_scheduler_pb2()
            req = pb.GetJobLogsRequest(
                job_id=job_id,
                pagination=pb.PaginationRequest(limit=limit),
            )
            if level:
                req.min_level = pb.LogLevel.Value(f"LOG_LEVEL_{level.upper()}")
            try:
                grpc_resp = stub.GetJobLogs(req)
                return [self._log_entry_to_dict(entry) for entry in grpc_resp.logs]
            except grpc.RpcError as error:
                self._handle_grpc_error(error, "Job", job_id)
        params: dict[str, Any] = {"limit": limit}
        if level:
            params["min_level"] = level.upper()
        rest_resp = self._make_rest_request("GET", f"/scheduler/jobs/{job_id}/logs", params=params)
        if not rest_resp.is_success:
            self._handle_rest_error(rest_resp, "Job", job_id)
        return rest_resp.json().get("logs", [])  # type: ignore[no-any-return]

    def get_task(self, task_id: str) -> dict[str, Any]:
        """Get a task by ID."""
        if self._use_grpc():
            stub = self._get_grpc_stub()
            pb = self._get_scheduler_pb2()
            try:
                grpc_resp = stub.GetTask(pb.GetTaskRequest(task_id=task_id))
                data = self._task_to_dict(grpc_resp.task)
                if grpc_resp.HasField("job"):
                    data["job"] = self._job_to_dict(grpc_resp.job)
                return data
            except grpc.RpcError as error:
                self._handle_grpc_error(error, "Task", task_id)
        rest_resp = self._make_rest_request("GET", f"/scheduler/tasks/{task_id}")
        if not rest_resp.is_success:
            self._handle_rest_error(rest_resp, "Task", task_id)
        return rest_resp.json().get("task", {})  # type: ignore[no-any-return]

    def get_task_logs(
        self, task_id: str, limit: int, level: str | None = None
    ) -> list[dict[str, Any]]:
        """Get logs for a task."""
        if self._use_grpc():
            stub = self._get_grpc_stub()
            pb = self._get_scheduler_pb2()
            req = pb.GetTaskLogsRequest(
                task_id=task_id,
                pagination=pb.PaginationRequest(limit=limit),
            )
            if level:
                req.min_level = pb.LogLevel.Value(f"LOG_LEVEL_{level.upper()}")
            try:
                grpc_resp = stub.GetTaskLogs(req)
                return [self._log_entry_to_dict(entry) for entry in grpc_resp.logs]
            except grpc.RpcError as error:
                self._handle_grpc_error(error, "Task", task_id)
        params: dict[str, Any] = {"limit": limit}
        if level:
            params["min_level"] = level.upper()
        rest_resp = self._make_rest_request(
            "GET", f"/scheduler/tasks/{task_id}/logs", params=params
        )
        if not rest_resp.is_success:
            self._handle_rest_error(rest_resp, "Task", task_id)
        return rest_resp.json().get("logs", [])  # type: ignore[no-any-return]

    def list_scheduled_jobs(
        self,
        workspace: str,
        queue_name: str | None = None,
        enabled_only: bool = False,
        limit: int = 50,
        offset: int = 0,
    ) -> dict[str, Any]:
        """List scheduled jobs."""
        if self._use_grpc():
            stub = self._get_grpc_stub()
            pb = self._get_scheduler_pb2()
            workspace_id = self._resolve_workspace_id(workspace)
            req = pb.ListScheduledJobsRequest(
                workspace_id=workspace_id,
                pagination=pb.PaginationRequest(limit=limit, offset=offset),
            )
            if enabled_only:
                req.enabled = True
            if queue_name:
                req.queue_name = queue_name
            try:
                grpc_resp = stub.ListScheduledJobs(req)
                jobs = [self._scheduled_job_to_dict(job) for job in grpc_resp.scheduled_jobs]
                return {
                    "scheduled_jobs": jobs,
                    "total_count": grpc_resp.pagination.total_count,
                    "has_more": grpc_resp.pagination.has_more,
                }
            except grpc.RpcError as error:
                self._handle_grpc_error(error, "Schedules", queue_name or "")
        workspace_id = self._resolve_workspace_id(workspace)
        params: dict[str, Any] = {"workspace_id": workspace_id, "limit": limit, "offset": offset}
        if queue_name:
            params["queue"] = queue_name
        if enabled_only:
            params["enabled"] = "true"
        rest_resp = self._make_rest_request("GET", "/scheduler/schedules", params=params)
        if not rest_resp.is_success:
            self._handle_rest_error(rest_resp, "Schedules", "")
        return rest_resp.json()  # type: ignore[no-any-return]

    def get_scheduled_job(self, id_or_name: str) -> dict[str, Any]:
        """Get a scheduled job by ID or name."""
        if self._use_grpc():
            stub = self._get_grpc_stub()
            pb = self._get_scheduler_pb2()
            try:
                grpc_resp = stub.GetScheduledJob(pb.GetScheduledJobRequest(id_or_name=id_or_name))
                return self._scheduled_job_to_dict(grpc_resp.scheduled_job)
            except grpc.RpcError as error:
                self._handle_grpc_error(error, "Scheduled job", id_or_name)
        rest_resp = self._make_rest_request("GET", f"/scheduler/schedules/{id_or_name}")
        if not rest_resp.is_success:
            self._handle_rest_error(rest_resp, "Scheduled job", id_or_name)
        return rest_resp.json().get("scheduled_job", {})  # type: ignore[no-any-return]

    def pause_scheduled_job(self, id_or_name: str) -> dict[str, Any]:
        """Pause a scheduled job."""
        if self._use_grpc():
            stub = self._get_grpc_stub()
            pb = self._get_scheduler_pb2()
            try:
                grpc_resp = stub.PauseScheduledJob(
                    pb.PauseScheduledJobRequest(id_or_name=id_or_name)
                )
                return self._scheduled_job_to_dict(grpc_resp.scheduled_job)
            except grpc.RpcError as error:
                self._handle_grpc_error(error, "Scheduled job", id_or_name)
        rest_resp = self._make_rest_request("POST", f"/scheduler/schedules/{id_or_name}/pause")
        if not rest_resp.is_success:
            self._handle_rest_error(rest_resp, "Scheduled job", id_or_name)
        return rest_resp.json() if rest_resp.content else {}

    def resume_scheduled_job(self, id_or_name: str) -> dict[str, Any]:
        """Resume a scheduled job."""
        if self._use_grpc():
            stub = self._get_grpc_stub()
            pb = self._get_scheduler_pb2()
            try:
                grpc_resp = stub.ResumeScheduledJob(
                    pb.ResumeScheduledJobRequest(id_or_name=id_or_name)
                )
                return self._scheduled_job_to_dict(grpc_resp.scheduled_job)
            except grpc.RpcError as error:
                self._handle_grpc_error(error, "Scheduled job", id_or_name)
        rest_resp = self._make_rest_request("POST", f"/scheduler/schedules/{id_or_name}/resume")
        if not rest_resp.is_success:
            self._handle_rest_error(rest_resp, "Scheduled job", id_or_name)
        return rest_resp.json() if rest_resp.content else {}

    def trigger_scheduled_job(self, id_or_name: str) -> dict[str, Any]:
        """Trigger a scheduled job immediately."""
        if self._use_grpc():
            stub = self._get_grpc_stub()
            pb = self._get_scheduler_pb2()
            try:
                grpc_resp = stub.TriggerScheduledJob(
                    pb.TriggerScheduledJobRequest(id_or_name=id_or_name)
                )
                return self._job_to_dict(grpc_resp.job)
            except grpc.RpcError as error:
                self._handle_grpc_error(error, "Scheduled job", id_or_name)
        rest_resp = self._make_rest_request("POST", f"/scheduler/schedules/{id_or_name}/trigger")
        if not rest_resp.is_success:
            self._handle_rest_error(rest_resp, "Scheduled job", id_or_name)
        return rest_resp.json()  # type: ignore[no-any-return]

    def delete_scheduled_job(self, id_or_name: str) -> None:
        """Delete a scheduled job."""
        if self._use_grpc():
            stub = self._get_grpc_stub()
            pb = self._get_scheduler_pb2()
            try:
                stub.DeleteScheduledJob(pb.DeleteScheduledJobRequest(id_or_name=id_or_name))
                return
            except grpc.RpcError as error:
                self._handle_grpc_error(error, "Scheduled job", id_or_name)
        resp = self._make_rest_request("DELETE", f"/scheduler/schedules/{id_or_name}")
        if not resp.is_success:
            self._handle_rest_error(resp, "Scheduled job", id_or_name)
