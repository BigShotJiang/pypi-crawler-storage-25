"""Configuration management for Featureform client."""

import os
from collections.abc import Callable

from pydantic import BaseModel, Field, field_validator, model_validator
from pydantic_core import PydanticCustomError

ENV_VARS = {
    "FEATUREFORM_BASE_URL": "Base URL for the Featureform API",
    "FEATUREFORM_TIMEOUT": "Request timeout in seconds",
    "FEATUREFORM_VERIFY_SSL": "Whether to verify TLS certificates",
    "FEATUREFORM_TOKEN": (
        "Bearer token used for authentication, including user, service-account, "
        "and machine-credential tokens"
    ),
}

ENV_FEATUREFORM_CA_CERT = "FEATUREFORM_CA_CERT"
TokenProvider = Callable[[], str | None]


class Config(BaseModel):
    """Configuration for Featureform client."""

    base_url: str = Field(
        default="http://localhost:8080",
        description="Base URL for the Featureform API",
    )
    timeout: float = Field(
        default=30.0,
        description="Request timeout in seconds",
        gt=0,
    )
    verify_ssl: bool = Field(
        default=True,
        description="Whether to verify SSL certificates",
    )
    no_tls: bool = Field(
        default=False,
        description="Whether to disable TLS entirely for gRPC transports",
    )
    ca_cert_path: str | None = Field(
        default=None,
        description="Optional CA bundle path for verifying self-signed or private CA certs",
    )
    client_cert_path: str | None = Field(
        default=None,
        description="Optional client certificate path for mTLS authentication",
    )
    client_key_path: str | None = Field(
        default=None,
        description="Optional client private key path for mTLS authentication",
    )
    token: str | None = Field(
        default=None,
        description=(
            "Bearer token for authentication, including user OIDC tokens, "
            "service-account tokens, and machine-credential assertion tokens"
        ),
    )
    token_provider: TokenProvider | None = Field(
        default=None,
        description="Optional request-time bearer token resolver",
        exclude=True,
        repr=False,
    )
    headers: dict[str, str] = Field(
        default_factory=dict,
        description="Additional headers to include in requests",
    )
    skip_version_check: bool = Field(
        default=False,
        description="Skip sending version headers to bypass server-side compatibility checking",
    )

    model_config = {
        "frozen": True,
        "extra": "forbid",
        "arbitrary_types_allowed": True,
    }

    @field_validator("base_url")
    @classmethod
    def validate_base_url(cls, v: str) -> str:
        """Validate that base_url is a valid URL or gRPC target.

        Accepts:
        - http:// or https:// URLs for REST transport
        - grpc:// URLs for gRPC transport
        - host:port format for gRPC transport (e.g., localhost:50051)
        """
        if v.startswith(("http://", "https://", "grpc://")):
            return v.rstrip("/")
        # Allow bare host:port format for gRPC (but not other URL schemes)
        if "://" not in v and ":" in v and not v.startswith("/"):
            return v
        raise PydanticCustomError(
            "featureform_base_url",
            "base_url must start with http://, https://, grpc://, or be host:port format",
        )

    @model_validator(mode="after")
    def validate_client_certificate_paths(self) -> "Config":
        """Require both certificate and key when configuring mTLS."""
        if bool(self.client_cert_path) != bool(self.client_key_path):
            raise PydanticCustomError(
                "featureform_client_cert_pair",
                "client_cert_path and client_key_path must be set together",
            )
        return self

    @classmethod
    def from_env(cls) -> "Config":
        """Create configuration from environment variables."""
        base_url = os.environ.get("FEATUREFORM_BASE_URL", "http://localhost:8080")
        timeout_str = os.environ.get("FEATUREFORM_TIMEOUT", "30.0")
        verify_ssl_str = os.environ.get("FEATUREFORM_VERIFY_SSL", "true")
        ca_cert_path = os.environ.get(ENV_FEATUREFORM_CA_CERT)
        client_cert_path = os.environ.get("FEATUREFORM_CLIENT_CERT")
        client_key_path = os.environ.get("FEATUREFORM_CLIENT_KEY")
        token = os.environ.get("FEATUREFORM_TOKEN")

        return cls(
            base_url=base_url,
            timeout=float(timeout_str),
            verify_ssl=verify_ssl_str.lower() in ("true", "1", "yes"),
            ca_cert_path=ca_cert_path,
            client_cert_path=client_cert_path,
            client_key_path=client_key_path,
            token=token,
        )

    def resolve_token(self) -> str | None:
        """Resolve the current bearer token."""
        if self.token_provider is not None:
            return self.token_provider()
        return self.token

    def authorization_header(self) -> str | None:
        """Resolve the current Authorization header value, if any."""
        header = self.headers.get("Authorization") or self.headers.get("authorization")
        if header:
            return header

        token = self.resolve_token()
        if token:
            return f"Bearer {token}"
        return None


__all__ = ["Config", "ENV_VARS"]


def ca_cert_path_from_env() -> str | None:
    return os.environ.get(ENV_FEATUREFORM_CA_CERT)
