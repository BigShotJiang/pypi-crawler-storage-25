"""Shared apply wait helpers for CLI and Python client flows."""

from __future__ import annotations

import time
from collections.abc import Callable, Mapping
from enum import Enum
from typing import Any, cast


class WaitTarget(str, Enum):
    """Wait target options for apply jobs."""

    RUNNING = "running"
    FINISHED = "finished"


TERMINAL_JOB_STATUSES = {"COMPLETED", "COMPLETED_WITH_WARNINGS", "FAILED", "CANCELED"}
SUCCESSFUL_TERMINAL_JOB_STATUSES = {"COMPLETED", "COMPLETED_WITH_WARNINGS"}
FAILED_JOB_STATUSES = {"FAILED", "CANCELED"}


class ApplyWaitError(Exception):
    """Raised when apply wait semantics fail or time out."""


class ApplyWaitTimeoutError(ApplyWaitError):
    """Raised when apply waiting exceeds the allotted timeout."""


class ApplyJobVisibilityTimeoutError(ApplyWaitTimeoutError):
    """Timed out before the scheduler job became visible."""

    def __init__(self, job_id: str) -> None:
        super().__init__(f"Timed out waiting for job '{job_id}' to become visible.")
        self.job_id = job_id


class ApplyJobStateTimeoutError(ApplyWaitTimeoutError):
    """Timed out before the scheduler job reached the requested wait target."""

    def __init__(self, job_id: str, wait_for: WaitTarget, last_status: str) -> None:
        super().__init__(
            f"Timed out waiting for job '{job_id}' to reach {wait_for.value}. "
            f"Last status: {last_status}."
        )
        self.job_id = job_id
        self.wait_for = wait_for
        self.last_status = last_status


class ApplyJobFailedError(ApplyWaitError):
    """Apply job reached a failed terminal state."""

    def __init__(
        self,
        job_id: str,
        status: str,
        *,
        detail: str | None = None,
        job: dict[str, Any] | None = None,
    ) -> None:
        message = f"Apply job '{job_id}' finished with status {status}."
        if detail:
            message = f"{message} {detail}"
        super().__init__(message)
        self.job_id = job_id
        self.status = status
        self.detail = detail
        self.job = job


class ApplyJobFetchError(ApplyWaitError):
    """Fetching scheduler job state failed."""

    def __init__(self, job_id: str, detail: str | None = None) -> None:
        message = f"Failed to fetch apply job '{job_id}'."
        if detail:
            message = f"{message} {detail}"
        super().__init__(message)
        self.job_id = job_id
        self.detail = detail


class ApplyWorkspaceVersionTimeoutError(ApplyWaitTimeoutError):
    """Timed out waiting for the applied workspace version to become visible."""

    def __init__(self, workspace_id: object, minimum: int, last_seen: int) -> None:
        super().__init__(
            f"Timed out waiting for workspace '{workspace_id}' to reach applied version "
            f"{minimum}. Last seen version: {last_seen}."
        )
        self.workspace_id = workspace_id
        self.minimum = minimum
        self.last_seen = last_seen


def summarize_failed_job(job: Mapping[str, object]) -> str | None:
    """Build a concise failure summary from scheduler job data."""
    parts: list[str] = []

    job_error_value: object = job.get("error_message")
    job_error = str(job_error_value or "").strip()
    if job_error:
        parts.append(f"job error: {job_error}")

    tasks_value: object = job.get("tasks")
    if isinstance(tasks_value, list):
        failed_task = next(
            (
                task
                for task in tasks_value
                if isinstance(task, Mapping)
                and str(cast(Mapping[str, object], task).get("status", "")).upper() == "FAILED"
            ),
            None,
        )
        if isinstance(failed_task, Mapping):
            task = cast(Mapping[str, object], failed_task)
            task_def_id_value: object = task.get("task_def_id")
            task_id_value: object = task.get("id")
            task_error_value: object = task.get("error_message")
            task_label = str(task_def_id_value or task_id_value or "").strip()
            task_error = str(task_error_value or "").strip()
            if task_label:
                summary = f"failed task: {task_label}"
                if task_error:
                    summary = f"{summary}; error: {task_error}"
                parts.append(summary)

    if not parts:
        return None
    return " ".join(parts)


def wait_target_reached(status: str, wait_for: WaitTarget) -> bool:
    """Return whether the current job status satisfies the wait target."""
    if wait_for == WaitTarget.RUNNING:
        return status == "RUNNING" or status in SUCCESSFUL_TERMINAL_JOB_STATUSES
    return status in TERMINAL_JOB_STATUSES


def wait_for_job(
    *,
    get_job: Callable[[str], dict[str, Any]],
    job_id: str,
    wait_for: WaitTarget,
    timeout_seconds: float,
    poll_interval_seconds: float,
    is_not_found_error: Callable[[Exception], bool] | None = None,
    monotonic_fn: Callable[[], float] = time.monotonic,
    sleep_fn: Callable[[float], None] = time.sleep,
) -> dict[str, Any]:
    """Poll the scheduler until a job reaches the requested state."""
    deadline = monotonic_fn() + timeout_seconds

    while True:
        try:
            job = get_job(job_id)
        except Exception as exc:
            if is_not_found_error is not None and is_not_found_error(exc):
                if monotonic_fn() >= deadline:
                    raise ApplyJobVisibilityTimeoutError(job_id) from None
                sleep_fn(poll_interval_seconds)
                continue
            raise

        raw_status = job.get("status")
        status = str(raw_status).upper().strip() if raw_status not in (None, "") else "UNKNOWN"
        if status in FAILED_JOB_STATUSES:
            raise ApplyJobFailedError(
                job_id,
                status,
                detail=summarize_failed_job(job),
                job=job,
            )
        if wait_target_reached(status, wait_for):
            return job

        if monotonic_fn() >= deadline:
            raise ApplyJobStateTimeoutError(job_id, wait_for, status)

        sleep_fn(poll_interval_seconds)
