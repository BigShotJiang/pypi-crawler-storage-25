"""Shared runtime auth helpers for CLI and Python client flows."""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path

from featureform.cli.auth.clock import SystemClock
from featureform.cli.auth.discovery import (
    CompositeAuthDiscoveryClient,
    GRPCAuthDiscoveryClient,
    RESTAuthDiscoveryClient,
)
from featureform.cli.auth.flows import OIDCFlowExecutor
from featureform.cli.auth.profiles import YAMLProfileRepository
from featureform.cli.auth.service import AuthService
from featureform.cli.auth.session_store import build_session_store

AUTH_DISCOVERY_TIMEOUT_CAP = 5.0
RuntimeTokenProvider = Callable[[], str | None]


def resolve_auth_discovery_timeout(request_timeout: float, *, explicit: bool) -> float:
    """Resolve the discovery timeout shared by CLI and runtime auth lookups."""
    if explicit:
        return max(1.0, request_timeout)
    return max(1.0, min(request_timeout, AUTH_DISCOVERY_TIMEOUT_CAP))


def normalize_config_path(config_path: str | Path | None) -> Path | None:
    """Resolve an optional config path to an absolute Path."""
    if config_path is None:
        return None
    return Path(config_path).expanduser().resolve()


def build_runtime_auth_service(
    *,
    timeout: float = 30.0,
    timeout_explicit: bool = False,
    verify_ssl: bool = True,
    no_tls: bool = False,
    ca_cert_path: str | None = None,
    client_cert_path: str | None = None,
    client_key_path: str | None = None,
    config_path: str | Path | None = None,
    auth_storage_mode: str | None = None,
) -> AuthService:
    """Build the shared auth service used by the CLI and Python SDK."""
    resolved_config_path = normalize_config_path(config_path)
    discovery_timeout = resolve_auth_discovery_timeout(timeout, explicit=timeout_explicit)

    session_path = (
        resolved_config_path.parent / "sessions.yaml" if resolved_config_path is not None else None
    )

    return AuthService(
        discovery=CompositeAuthDiscoveryClient(
            rest=RESTAuthDiscoveryClient(
                timeout=discovery_timeout,
                verify_ssl=verify_ssl,
                ca_cert_path=ca_cert_path,
                client_cert_path=client_cert_path,
                client_key_path=client_key_path,
            ),
            grpc_client=GRPCAuthDiscoveryClient(
                timeout=discovery_timeout,
                verify_ssl=verify_ssl,
                no_tls=no_tls,
                ca_cert_path=ca_cert_path,
                client_cert_path=client_cert_path,
                client_key_path=client_key_path,
            ),
        ),
        sessions=build_session_store(session_path, storage_mode=auth_storage_mode),
        profiles=YAMLProfileRepository(resolved_config_path),
        flows=OIDCFlowExecutor(timeout=timeout),
        clock=SystemClock(),
    )


def build_runtime_token_provider(
    *,
    timeout: float = 30.0,
    timeout_explicit: bool = False,
    verify_ssl: bool = True,
    no_tls: bool = False,
    ca_cert_path: str | None = None,
    client_cert_path: str | None = None,
    client_key_path: str | None = None,
    config_path: str | Path | None = None,
    auth_storage_mode: str | None = None,
    explicit_token: str | None = None,
    client_id: str | None = None,
    client_secret: str | None = None,
    issuer_url: str | None = None,
    server_url: str | None = None,
    transport: str | None = None,
    profile_name: str | None = None,
) -> RuntimeTokenProvider:
    """Build a request-time token resolver for runtime clients."""
    service = build_runtime_auth_service(
        timeout=timeout,
        timeout_explicit=timeout_explicit,
        verify_ssl=verify_ssl,
        no_tls=no_tls,
        ca_cert_path=ca_cert_path,
        client_cert_path=client_cert_path,
        client_key_path=client_key_path,
        config_path=config_path,
        auth_storage_mode=auth_storage_mode,
    )

    def resolve() -> str | None:
        return service.resolve_access_token(
            env_token=explicit_token,
            client_id=client_id,
            client_secret=client_secret,
            issuer_url=issuer_url,
            server_url=server_url,
            transport=transport,
            profile_name=profile_name,
        )

    return resolve
