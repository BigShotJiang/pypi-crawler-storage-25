"""OAuth2 token acquisition for Featureform CLI."""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, cast

import httpx

from featureform._internal.logging import get_logger
from featureform._internal.telemetry import SpanKind, StatusCode, get_instrumentor
from featureform.errors import AuthenticationError as BaseAuthenticationError

# Module logger
_logger = get_logger("featureform.auth.token")

# Default timeout for auth requests
DEFAULT_TIMEOUT = 30.0


def _protocol_mismatch_message(issuer_url: str, error: httpx.RemoteProtocolError) -> str:
    """Build a user-facing message for non-HTTP issuer endpoints."""
    return (
        f"Unexpected HTTP protocol response from issuer URL {issuer_url}: {error}. "
        "Verify that --issuer-url points to your OIDC issuer, not a Featureform gRPC endpoint "
        "or another non-HTTP service."
    )


class AuthenticationError(BaseAuthenticationError):
    """Authentication failed."""

    def __init__(
        self,
        message: str,
        *,
        error_code: str | None = None,
        reason: str | None = None,
        status_code: int | None = None,
    ) -> None:
        """Initialize AuthenticationError.

        Args:
            message: Error message.
            error_code: Optional OAuth2 error code.
        """
        super().__init__(message, code=error_code)
        self.error_code = error_code
        self.reason = reason
        self.status_code = status_code

    def __str__(self) -> str:
        return super().__str__()


@dataclass
class TokenResponse:
    """OAuth2 token response.

    Attributes:
        access_token: The access token string.
        token_type: Token type (usually "Bearer").
        expires_in: Token expiration time in seconds.
        refresh_token: Optional refresh token.
        scope: Optional scope string.
    """

    access_token: str
    token_type: str
    expires_in: int
    refresh_token: str | None = None
    scope: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TokenResponse:
        """Create TokenResponse from dictionary.

        Args:
            data: Dictionary containing token response fields.

        Returns:
            TokenResponse instance.
        """
        return cls(
            access_token=data["access_token"],
            token_type=data["token_type"],
            expires_in=data["expires_in"],
            refresh_token=data.get("refresh_token"),
            scope=data.get("scope"),
        )


def get_client_credentials_token(
    issuer_url: str,
    client_id: str,
    client_secret: str,
    timeout: float = DEFAULT_TIMEOUT,
) -> TokenResponse:
    """Get access token using client credentials grant.

    Args:
        issuer_url: OAuth2 issuer URL (e.g., https://auth.example.com/realms/test).
        client_id: OAuth2 client ID.
        client_secret: OAuth2 client secret.
        timeout: Request timeout in seconds.

    Returns:
        TokenResponse containing the access token.

    Raises:
        AuthenticationError: If authentication fails.
    """
    instrumentor = get_instrumentor()
    token_url = f"{issuer_url.rstrip('/')}/protocol/openid-connect/token"

    with instrumentor.start_span(
        "auth.client_credentials",
        kind=SpanKind.CLIENT,
        attributes={"auth.issuer_url": issuer_url, "auth.client_id": client_id},
    ) as span:
        _logger.debug(
            "requesting_client_credentials_token",
            issuer_url=issuer_url,
            client_id=client_id,
        )

        try:
            response = httpx.post(
                token_url,
                data={
                    "grant_type": "client_credentials",
                    "client_id": client_id,
                    "client_secret": client_secret,
                },
                timeout=timeout,
            )

            if response.status_code != 200:
                span.set_status(StatusCode.ERROR, f"HTTP {response.status_code}")
                _logger.error(
                    "client_credentials_failed",
                    status_code=response.status_code,
                    response=response.text,
                )
                raise AuthenticationError(
                    f"Authentication failed: {response.status_code} - {response.text}",
                    reason="invalid_client_credentials",
                    status_code=response.status_code,
                )

            token_data = response.json()
            span.set_status(StatusCode.OK)
            _logger.info("client_credentials_token_acquired", client_id=client_id)
            return TokenResponse.from_dict(token_data)

        except httpx.ConnectError as e:
            span.set_status(StatusCode.ERROR, "Connection failed")
            span.record_exception(e)
            _logger.error("connection_error", error=str(e))
            raise AuthenticationError(f"Connection failed: {e}", reason="connection_failed") from e

        except httpx.TimeoutException as e:
            span.set_status(StatusCode.ERROR, "Request timed out")
            span.record_exception(e)
            _logger.error("timeout_error", error=str(e))
            raise AuthenticationError(f"Request timed out: {e}", reason="request_timeout") from e

        except httpx.RemoteProtocolError as e:
            span.set_status(StatusCode.ERROR, "Unexpected protocol response")
            span.record_exception(e)
            _logger.error("protocol_error", issuer_url=issuer_url, error=str(e))
            raise AuthenticationError(
                _protocol_mismatch_message(issuer_url, e),
                reason="unexpected_protocol_response",
            ) from e


def get_password_token(
    issuer_url: str,
    client_id: str,
    username: str,
    password: str,
    scope: str = "openid",
    timeout: float = DEFAULT_TIMEOUT,
) -> TokenResponse:
    """Get access token using password grant.

    Args:
        issuer_url: OAuth2 issuer URL (e.g., https://auth.example.com/realms/test).
        client_id: OAuth2 client ID.
        username: Username for password grant authentication.
        password: Password for password grant authentication.
        scope: OAuth2 scope string.
        timeout: Request timeout in seconds.

    Returns:
        TokenResponse containing the access token and optional refresh token.

    Raises:
        AuthenticationError: If authentication fails.
    """
    instrumentor = get_instrumentor()
    token_url = f"{issuer_url.rstrip('/')}/protocol/openid-connect/token"

    with instrumentor.start_span(
        "auth.password_grant",
        kind=SpanKind.CLIENT,
        attributes={"auth.issuer_url": issuer_url, "auth.client_id": client_id},
    ) as span:
        _logger.debug(
            "requesting_password_grant_token",
            issuer_url=issuer_url,
            client_id=client_id,
            username=username,
        )

        try:
            response = httpx.post(
                token_url,
                data={
                    "grant_type": "password",
                    "client_id": client_id,
                    "username": username,
                    "password": password,
                    "scope": scope,
                },
                timeout=timeout,
            )

            if response.status_code != 200:
                span.set_status(StatusCode.ERROR, f"HTTP {response.status_code}")
                _logger.error(
                    "password_grant_failed",
                    status_code=response.status_code,
                    response=response.text,
                )
                raise AuthenticationError(
                    f"Authentication failed: {response.status_code} - {response.text}",
                    reason="invalid_user_credentials",
                    status_code=response.status_code,
                )

            token_data = response.json()
            span.set_status(StatusCode.OK)
            _logger.info("password_grant_token_acquired", client_id=client_id, username=username)
            return TokenResponse.from_dict(token_data)

        except httpx.ConnectError as e:
            span.set_status(StatusCode.ERROR, "Connection failed")
            span.record_exception(e)
            _logger.error("connection_error", error=str(e))
            raise AuthenticationError(f"Connection failed: {e}", reason="connection_failed") from e

        except httpx.TimeoutException as e:
            span.set_status(StatusCode.ERROR, "Request timed out")
            span.record_exception(e)
            _logger.error("timeout_error", error=str(e))
            raise AuthenticationError(f"Request timed out: {e}", reason="request_timeout") from e

        except httpx.RemoteProtocolError as e:
            span.set_status(StatusCode.ERROR, "Unexpected protocol response")
            span.record_exception(e)
            _logger.error("protocol_error", issuer_url=issuer_url, error=str(e))
            raise AuthenticationError(
                _protocol_mismatch_message(issuer_url, e),
                reason="unexpected_protocol_response",
            ) from e


def refresh_access_token(
    issuer_url: str,
    client_id: str,
    refresh_token: str,
    timeout: float = DEFAULT_TIMEOUT,
) -> TokenResponse:
    """Exchange a refresh token for a new access token.

    Args:
        issuer_url: OAuth2 issuer URL (e.g., https://auth.example.com/realms/test).
        client_id: OAuth2 client ID.
        refresh_token: OAuth2 refresh token.
        timeout: Request timeout in seconds.

    Returns:
        TokenResponse containing the refreshed access token.

    Raises:
        AuthenticationError: If refresh fails.
    """
    instrumentor = get_instrumentor()
    token_url = f"{issuer_url.rstrip('/')}/protocol/openid-connect/token"

    with instrumentor.start_span(
        "auth.refresh_token",
        kind=SpanKind.CLIENT,
        attributes={"auth.issuer_url": issuer_url, "auth.client_id": client_id},
    ) as span:
        _logger.debug(
            "requesting_refreshed_access_token",
            issuer_url=issuer_url,
            client_id=client_id,
        )

        try:
            response = httpx.post(
                token_url,
                data={
                    "grant_type": "refresh_token",
                    "client_id": client_id,
                    "refresh_token": refresh_token,
                },
                timeout=timeout,
            )

            if response.status_code != 200:
                span.set_status(StatusCode.ERROR, f"HTTP {response.status_code}")
                _logger.error(
                    "refresh_token_failed",
                    status_code=response.status_code,
                    response=response.text,
                )
                raise AuthenticationError(
                    f"Token refresh failed: {response.status_code} - {response.text}",
                    reason="invalid_refresh_token",
                    status_code=response.status_code,
                )

            token_data = response.json()
            span.set_status(StatusCode.OK)
            _logger.info("refreshed_access_token_acquired", client_id=client_id)
            return TokenResponse.from_dict(token_data)

        except httpx.ConnectError as e:
            span.set_status(StatusCode.ERROR, "Connection failed")
            span.record_exception(e)
            _logger.error("connection_error", error=str(e))
            raise AuthenticationError(f"Connection failed: {e}", reason="connection_failed") from e

        except httpx.TimeoutException as e:
            span.set_status(StatusCode.ERROR, "Request timed out")
            span.record_exception(e)
            _logger.error("timeout_error", error=str(e))
            raise AuthenticationError(f"Request timed out: {e}", reason="request_timeout") from e

        except httpx.RemoteProtocolError as e:
            span.set_status(StatusCode.ERROR, "Unexpected protocol response")
            span.record_exception(e)
            _logger.error("protocol_error", issuer_url=issuer_url, error=str(e))
            raise AuthenticationError(
                _protocol_mismatch_message(issuer_url, e),
                reason="unexpected_protocol_response",
            ) from e


def get_device_authorization(
    issuer_url: str,
    client_id: str,
    scope: str = "openid",
    timeout: float = DEFAULT_TIMEOUT,
) -> dict[str, Any]:
    """Initiate device authorization flow.

    Args:
        issuer_url: OAuth2 issuer URL.
        client_id: OAuth2 client ID.
        scope: OAuth2 scope string.
        timeout: Request timeout in seconds.

    Returns:
        Dictionary containing device_code, user_code, verification_uri, etc.

    Raises:
        AuthenticationError: If the request fails.
    """
    instrumentor = get_instrumentor()
    device_url = f"{issuer_url.rstrip('/')}/protocol/openid-connect/auth/device"

    with instrumentor.start_span(
        "auth.device_authorization",
        kind=SpanKind.CLIENT,
        attributes={"auth.issuer_url": issuer_url, "auth.client_id": client_id},
    ) as span:
        _logger.debug(
            "requesting_device_authorization",
            issuer_url=issuer_url,
            client_id=client_id,
        )

        try:
            response = httpx.post(
                device_url,
                data={
                    "client_id": client_id,
                    "scope": scope,
                },
                timeout=timeout,
            )

            if response.status_code != 200:
                span.set_status(StatusCode.ERROR, f"HTTP {response.status_code}")
                _logger.error(
                    "device_authorization_failed",
                    status_code=response.status_code,
                    response=response.text,
                )
                raise AuthenticationError(
                    f"Device authorization failed: {response.status_code} - {response.text}",
                    reason="device_authorization_failed",
                    status_code=response.status_code,
                )

            result: dict[str, Any] = cast(dict[str, Any], response.json())
            span.set_status(StatusCode.OK)
            _logger.info(
                "device_authorization_received",
                user_code=result.get("user_code"),
                verification_uri=result.get("verification_uri"),
            )
            return result

        except httpx.ConnectError as e:
            span.set_status(StatusCode.ERROR, "Connection failed")
            span.record_exception(e)
            _logger.error("connection_error", error=str(e))
            raise AuthenticationError(f"Connection failed: {e}", reason="connection_failed") from e

        except httpx.TimeoutException as e:
            span.set_status(StatusCode.ERROR, "Request timed out")
            span.record_exception(e)
            _logger.error("timeout_error", error=str(e))
            raise AuthenticationError(f"Request timed out: {e}", reason="request_timeout") from e

        except httpx.RemoteProtocolError as e:
            span.set_status(StatusCode.ERROR, "Unexpected protocol response")
            span.record_exception(e)
            _logger.error("protocol_error", issuer_url=issuer_url, error=str(e))
            raise AuthenticationError(
                _protocol_mismatch_message(issuer_url, e),
                reason="unexpected_protocol_response",
            ) from e


def poll_for_token(
    issuer_url: str,
    client_id: str,
    device_code: str,
    interval: int = 5,
    timeout: float = DEFAULT_TIMEOUT,
) -> TokenResponse:
    """Poll for token during device authorization flow.

    Args:
        issuer_url: OAuth2 issuer URL.
        client_id: OAuth2 client ID.
        device_code: Device code from device authorization response.
        interval: Polling interval in seconds.
        timeout: Request timeout in seconds.

    Returns:
        TokenResponse containing the access token.

    Raises:
        AuthenticationError: If authentication fails or is denied.
    """
    instrumentor = get_instrumentor()
    token_url = f"{issuer_url.rstrip('/')}/protocol/openid-connect/token"

    with instrumentor.start_span(
        "auth.poll_for_token",
        kind=SpanKind.CLIENT,
        attributes={"auth.issuer_url": issuer_url, "auth.client_id": client_id},
    ) as span:
        _logger.debug("starting_token_polling", client_id=client_id)

        while True:
            try:
                response = httpx.post(
                    token_url,
                    data={
                        "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                        "client_id": client_id,
                        "device_code": device_code,
                    },
                    timeout=timeout,
                )

                if response.status_code == 200:
                    token_data = response.json()
                    span.set_status(StatusCode.OK)
                    _logger.info("token_acquired_via_device_flow", client_id=client_id)
                    return TokenResponse.from_dict(token_data)

                # Handle error responses
                error_data = response.json()
                error = error_data.get("error", "unknown_error")

                if error == "authorization_pending":
                    _logger.debug("authorization_pending", interval=interval)
                    time.sleep(interval)
                    continue

                if error == "slow_down":
                    interval += 5
                    _logger.debug("slow_down_requested", new_interval=interval)
                    time.sleep(interval)
                    continue

                # Terminal errors
                span.set_status(StatusCode.ERROR, error)
                if error == "access_denied":
                    _logger.error("access_denied")
                    raise AuthenticationError(
                        "Access denied by user",
                        error_code="access_denied",
                        reason="access_denied",
                    )

                if error == "expired_token":
                    _logger.error("device_code_expired")
                    raise AuthenticationError(
                        "Device code expired",
                        error_code="expired_token",
                        reason="expired_token",
                    )

                _logger.error("token_polling_failed", error=error)
                raise AuthenticationError(
                    f"Token polling failed: {error}",
                    error_code=error,
                    reason="token_polling_failed",
                )

            except httpx.ConnectError as e:
                span.set_status(StatusCode.ERROR, "Connection failed")
                span.record_exception(e)
                _logger.error("connection_error", error=str(e))
                raise AuthenticationError(
                    f"Connection failed: {e}",
                    reason="connection_failed",
                ) from e

            except httpx.TimeoutException as e:
                span.set_status(StatusCode.ERROR, "Request timed out")
                span.record_exception(e)
                _logger.error("timeout_error", error=str(e))
                raise AuthenticationError(
                    f"Request timed out: {e}",
                    reason="request_timeout",
                ) from e

            except httpx.RemoteProtocolError as e:
                span.set_status(StatusCode.ERROR, "Unexpected protocol response")
                span.record_exception(e)
                _logger.error("protocol_error", issuer_url=issuer_url, error=str(e))
                raise AuthenticationError(
                    _protocol_mismatch_message(issuer_url, e),
                    reason="unexpected_protocol_response",
                ) from e
