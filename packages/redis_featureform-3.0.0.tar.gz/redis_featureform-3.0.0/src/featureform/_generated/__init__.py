"""Generated code from protobuf and OpenAPI."""
