"""Generated proto package."""
