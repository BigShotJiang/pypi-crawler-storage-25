"""Generated proto.scheduler package."""
