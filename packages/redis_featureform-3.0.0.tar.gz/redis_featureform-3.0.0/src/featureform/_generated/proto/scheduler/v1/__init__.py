"""Generated proto.scheduler.v1 package."""
