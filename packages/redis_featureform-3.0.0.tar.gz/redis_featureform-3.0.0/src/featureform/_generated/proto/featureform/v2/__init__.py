"""Generated proto.featureform.v2 package."""
