"""CLI for opensdmx — SDMX 2.1 REST API client."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional

_HELP_FLAGS = {"--help", "-h"}

import httpx
import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from .base import get_base_url, get_provider

app = typer.Typer(help="opensdmx — SDMX 2.1 REST API CLI\n\nEnv vars: OPENSDMX_PROVIDER (provider name or URL), OPENSDMX_AGENCY (agency ID for custom URLs)")
console = Console()
err_console = Console(stderr=True)


def _version_callback(value: bool) -> None:
    if value:
        from importlib.metadata import version
        console.print(version("opensdmx"))
        raise typer.Exit()

_PROVIDER_HELP = "Provider name ('eurostat', 'ecb') or custom base URL. Env: OPENSDMX_PROVIDER"


def _parse_extra_filters(ctx: typer.Context) -> dict:
    """Parse extra --KEY VALUE args from context as dimension filters.

    Supports multiple values per dimension:
      --geo IT --geo FR  →  {"geo": "IT+FR"}
      --geo IT+FR        →  {"geo": "IT+FR"}
    """
    accumulated: dict[str, list[str]] = {}
    extra = ctx.args
    i = 0
    while i < len(extra):
        arg = extra[i]
        if arg.startswith("--") and i + 1 < len(extra):
            key = arg[2:]
            accumulated.setdefault(key, []).append(extra[i + 1])
            i += 2
        else:
            err_console.print(f"[red]Unexpected argument:[/red] {arg}")
            raise typer.Exit(1)
    return {k: "+".join(v) if len(v) > 1 else v[0] for k, v in accumulated.items()}


def _apply_provider(provider: str | None) -> None:
    """Set active provider from CLI option or OPENSDMX_PROVIDER env var."""
    import os
    resolved = provider or os.environ.get("OPENSDMX_PROVIDER")
    if resolved:
        from .base import PROVIDERS, set_provider
        if resolved not in PROVIDERS and not resolved.startswith("http"):
            valid = ", ".join(sorted(PROVIDERS))
            err_console.print(f"[red]Error:[/red] unknown provider '{resolved}'. Valid: {valid}")
            raise typer.Exit(1)
        agency_id = os.environ.get("OPENSDMX_AGENCY")
        set_provider(resolved, agency_id=agency_id)


def _check_api_reachable() -> None:
    """Do a lightweight GET check on the active provider's base URL."""
    from .base import _rate_limit_file
    if _rate_limit_file().exists():
        return
    try:
        with httpx.Client(timeout=5.0) as client:
            client.get(get_base_url())
    except (httpx.HTTPError, OSError):
        provider_name = get_provider().get("agency_id", "API")
        err_console.print(
            f"[red]⚠ {provider_name} API unreachable.[/red] "
            "Check your network connection or provider URL."
        )
        raise typer.Exit(1)


@app.callback(invoke_without_command=True)
def _startup(
    ctx: typer.Context,
    version: bool = typer.Option(False, "--version", "-V", callback=_version_callback, is_eager=True, help="Show version and exit"),
) -> None:
    if ctx.invoked_subcommand is None:
        from importlib.metadata import version as _version
        console.print(f"opensdmx {_version('opensdmx')}\n")
        console.print(ctx.get_help())
        raise typer.Exit()
    if not _HELP_FLAGS.intersection(sys.argv):
        _check_api_reachable()


@app.command()
def search(
    keyword: str = typer.Argument(..., help="Keyword to search in dataset descriptions"),
    semantic: bool = typer.Option(False, "--semantic", "-s", help="Use semantic search via Ollama embeddings"),
    n: int = typer.Option(20, "--n", help="Max number of results to show"),
    provider: Optional[str] = typer.Option(None, "--provider", "-p", help=_PROVIDER_HELP),
):
    """Search datasets by keyword (or semantically with --semantic).

    Default provider: eurostat. Use --provider to switch.

    Tip: semantic search matches meaning, not exact words. Try synonyms
    or related terms for better results (e.g. "jobless" instead of "unemployment").

    Examples:

      opensdmx search unemployment
      opensdmx search unemployment --n 5
      opensdmx search --semantic disoccupazione --n 5
      opensdmx search population --provider istat
    """
    _apply_provider(provider)

    if semantic:
        from .embed import semantic_search
        try:
            df = semantic_search(keyword, n=n)
        except FileNotFoundError:
            err_console.print(
                "[red]Error:[/red] Embeddings cache not found.\n"
                "Build it first:  opensdmx embed"
            )
            raise typer.Exit(1)
        except Exception as e:
            err_console.print(f"[red]Error:[/red] {e}")
            raise typer.Exit(1)

        table = Table(title=f"Semantic search: {keyword}", show_lines=False)
        table.add_column("df_id", style="cyan", no_wrap=True)
        table.add_column("df_description")
        table.add_column("score", style="dim")

        for row in df.iter_rows(named=True):
            table.add_row(row["df_id"], row["df_description"] or "", f"{row['score']:.3f}")

        console.print(table)
        return

    from . import search_dataset
    try:
        with console.status("[dim]Searching...[/dim]"):
            df = search_dataset(keyword)
    except Exception as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)

    if df.is_empty():
        err_console.print(f"[yellow]No datasets found for:[/yellow] {keyword}")
        raise typer.Exit(0)

    total = len(df)
    df = df.head(n)
    title = f"Search: {keyword} ({len(df)} of {total})" if total > n else f"Search: {keyword} ({total})"
    table = Table(title=title, show_lines=False)
    table.add_column("df_id", style="cyan", no_wrap=True)
    table.add_column("df_description")

    for row in df.iter_rows(named=True):
        table.add_row(row["df_id"], row["df_description"] or "")

    console.print(table)


@app.command()
def info(
    dataset_id: str = typer.Argument(..., help="Dataset ID"),
    provider: Optional[str] = typer.Option(None, "--provider", "-p", help=_PROVIDER_HELP),
):
    """Show metadata and dimensions for a dataset.

    Default provider: eurostat. Use --provider to switch.

    Examples:

      opensdmx info NAMA_10_GDP
      opensdmx info DCIS_POPRES1 --provider istat
    """
    _apply_provider(provider)
    from . import dimensions_info, load_dataset
    try:
        with console.status("[dim]Loading dataset...[/dim]"):
            ds = load_dataset(dataset_id)
    except Exception as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)

    meta = (
        f"ID:          {ds['df_id']}\n"
        f"Version:     {ds['version']}\n"
        f"Description: {ds['df_description']}\n"
        f"Structure:   {ds['df_structure_id']}"
    )
    console.print(Panel(meta, title="Dataset Info", expand=False))

    try:
        dim_df = dimensions_info(ds)
    except Exception as e:
        err_console.print(f"[yellow]Warning:[/yellow] could not fetch dimension info: {e}")
        return

    if dim_df.is_empty():
        console.print("[yellow]No dimensions found.[/yellow]")
        return

    table = Table(title="Dimensions", show_lines=False)
    table.add_column("dimension_id", style="cyan", no_wrap=True)
    table.add_column("position")
    table.add_column("codelist_id")
    table.add_column("description")

    for row in dim_df.iter_rows(named=True):
        table.add_row(
            row["dimension_id"],
            str(row["position"]) if row["position"] is not None else "",
            row["codelist_id"] or "",
            row.get("description") or "",
        )

    console.print(table)


@app.command()
def values(
    dataset_id: str = typer.Argument(..., help="Dataset ID"),
    dim: str = typer.Argument(..., help="Dimension ID (e.g. FREQ)"),
    provider: Optional[str] = typer.Option(None, "--provider", "-p", help=_PROVIDER_HELP),
):
    """Show available values for a dimension.

    Default provider: eurostat. Use --provider to switch.

    Examples:

      opensdmx values NAMA_10_GDP FREQ
      opensdmx values DCIS_POPRES1 ITTER107 --provider istat
    """
    _apply_provider(provider)
    from . import get_dimension_values, load_dataset
    try:
        with console.status("[dim]Loading...[/dim]"):
            ds = load_dataset(dataset_id)
            val_df = get_dimension_values(ds, dim)
    except Exception as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)

    if val_df.is_empty():
        err_console.print(f"[yellow]No values found for dimension:[/yellow] {dim}")
        raise typer.Exit(1)

    table = Table(title=f"{dataset_id} / {dim}", show_lines=False)
    table.add_column("id", style="cyan", no_wrap=True)
    table.add_column("name")

    for row in val_df.iter_rows(named=True):
        table.add_row(row["id"] or "", row["name"] or "")

    console.print(table)


@app.command()
def constraints(
    dataset_id: str = typer.Argument(..., help="Dataset ID"),
    dimension: Optional[str] = typer.Argument(None, help="Dimension ID (optional); if omitted shows all dimensions"),
    provider: Optional[str] = typer.Option(None, "--provider", "-p", help=_PROVIDER_HELP),
):
    """Show constrained (actually present) values for a dataflow's dimensions.

    Without DIMENSION: shows all dimensions with their count and a short sample.
    With DIMENSION: shows the full list of codes present in the dataflow for that
    dimension, enriched with human-readable labels from the codelist.

    Default provider: eurostat. Use --provider to switch.

    Examples:

      opensdmx constraints NAMA_10_GDP
      opensdmx constraints NAMA_10_GDP FREQ
      opensdmx constraints DCIS_POPRES1 ITTER107 --provider istat
    """
    _apply_provider(provider)
    import polars as pl

    from . import load_dataset
    from .discovery import ConstraintsUnavailable, get_available_values, get_dimension_values

    try:
        with console.status("[dim]Loading dataset...[/dim]"):
            ds = load_dataset(dataset_id)
    except Exception as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)

    try:
        with console.status("[dim]Fetching constraints...[/dim]"):
            avail = get_available_values(ds)
    except ConstraintsUnavailable:
        err_console.print(
            f"[yellow]⚠ Constraints not available for [bold]{dataset_id}[/bold] "
            f"(dataflow is hidden or not yet public).[/yellow]\n"
            f"Data is still accessible:  opensdmx get {dataset_id} ..."
        )
        raise typer.Exit(0)
    except Exception as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)

    if not avail:
        err_console.print(
            "[red]Error:[/red] No constrained values returned. "
            "This provider may not support the availableconstraint endpoint."
        )
        raise typer.Exit(1)

    if dimension is None:
        # Summary mode: one row per dimension
        table = Table(title=f"Constraints: {dataset_id}", show_lines=False)
        table.add_column("dimension_id", style="cyan", no_wrap=True)
        table.add_column("n_values", justify="right")
        table.add_column("sample")

        for dim_id, df in avail.items():
            codes = df["id"].to_list()
            table.add_row(dim_id, str(len(codes)), ", ".join(codes[:3]))

        console.print(table)
        return

    # Single-dimension mode
    valid_dims = list(ds["dimensions"].keys())
    dim_upper = {d.upper(): d for d in valid_dims}
    actual_dim = dim_upper.get(dimension.upper())
    if actual_dim is None:
        err_console.print(
            f"[red]Error:[/red] Dimension '{dimension}' not found.\n"
            f"Valid dimensions: {', '.join(valid_dims)}"
        )
        raise typer.Exit(1)

    if actual_dim not in avail:
        err_console.print(
            f"[yellow]No constrained values found for dimension:[/yellow] {actual_dim}"
        )
        raise typer.Exit(1)

    constrained_codes = avail[actual_dim]["id"].to_list()

    try:
        with console.status("[dim]Fetching labels...[/dim]"):
            labels_df = get_dimension_values(ds, actual_dim)
    except (httpx.HTTPError, OSError, ValueError):  # labels are optional, fall back to empty
        labels_df = pl.DataFrame({"id": [], "name": []}, schema={"id": pl.Utf8, "name": pl.Utf8})

    constrained_df = pl.DataFrame({"id": constrained_codes})
    if not labels_df.is_empty():
        result_df = constrained_df.join(labels_df, on="id", how="left")
        result_df = result_df.with_columns(pl.col("name").fill_null("—"))
    else:
        result_df = constrained_df.with_columns(pl.lit("—").alias("name"))

    table = Table(title=f"{dataset_id} / {actual_dim} (constrained)", show_lines=False)
    table.add_column("id", style="cyan", no_wrap=True)
    table.add_column("name")

    for row in result_df.iter_rows(named=True):
        table.add_row(row["id"] or "", row["name"] or "—")

    console.print(table)


@app.command()
def embed(
    provider: Optional[str] = typer.Option(None, "--provider", "-p", help=_PROVIDER_HELP),
):
    """Build semantic embeddings cache for the dataset catalog.

    Default provider: eurostat. Use --provider to switch.

    Examples:

      opensdmx embed
      opensdmx embed --provider istat
    """
    _apply_provider(provider)
    from .embed import build_embeddings
    try:
        build_embeddings(progress=True)
    except Exception as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def providers():
    """List built-in SDMX providers (alias, name, description).

    These are curated examples — opensdmx works with any SDMX 2.1 REST endpoint.
    Use --provider <URL> to connect to any provider not listed here.

    Examples:

      opensdmx providers
      opensdmx search unemployment --provider ecb
    """
    from .base import PROVIDERS

    console.print(
        "\n[dim]The providers below are curated examples. "
        "opensdmx works with any SDMX 2.1 REST endpoint — "
        "use [/dim][cyan]--provider <URL>[/cyan][dim] to connect to any unlisted provider.[/dim]\n"
    )

    table = Table(show_lines=True)
    table.add_column("alias", style="cyan", no_wrap=True)
    table.add_column("name", no_wrap=True)
    table.add_column("description")
    table.add_column("agency", style="dim", no_wrap=True)

    for alias, cfg in PROVIDERS.items():
        table.add_row(
            alias,
            cfg.get("name", ""),
            cfg.get("description", ""),
            cfg.get("agency_id", ""),
        )

    console.print(table)


_LARGE_DATASET_THRESHOLD = 5000


@app.command(context_settings={"allow_extra_args": True, "ignore_unknown_options": True})
def get(
    ctx: typer.Context,
    dataset_id: str = typer.Argument(..., help="Dataset ID"),
    out: Optional[Path] = typer.Option(None, "--out", help="Output file (.csv/.parquet/.json)"),
    start_period: Optional[str] = typer.Option(None, "--start-period", help="Start period (e.g. 2020, 2020-Q1, 2020-01)"),
    end_period: Optional[str] = typer.Option(None, "--end-period", help="End period (e.g. 2023, 2023-Q4, 2023-12)"),
    last_n: Optional[int] = typer.Option(None, "--last-n", help="Return only last N observations per series"),
    first_n: Optional[int] = typer.Option(None, "--first-n", help="Return only first N observations per series"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip large-dataset confirmation prompt"),
    provider: Optional[str] = typer.Option(None, "--provider", "-p", help=_PROVIDER_HELP),
):
    """Get data for a dataset. Extra --DIM VALUE pairs are used as filters.

    Default provider: eurostat. Use --provider to switch.

    Examples:

      opensdmx get NAMA_10_GDP
      opensdmx get NAMA_10_GDP --FREQ A --GEO IT --out data.csv
      opensdmx get NAMA_10_GDP --start-period 2010 --end-period 2023 --out data.parquet
      opensdmx get DCIS_POPRES1 --ITTER107 IT --provider istat
    """
    _apply_provider(provider)
    from . import get_data, load_dataset, set_filters

    filters = _parse_extra_filters(ctx)

    try:
        import warnings as _warnings
        with console.status("[dim]Loading dataset...[/dim]"):
            ds = load_dataset(dataset_id)
            if filters:
                with _warnings.catch_warnings(record=True) as _caught:
                    _warnings.simplefilter("always")
                    ds = set_filters(ds, **filters)
                for _w in _caught:
                    err_console.print(f"[yellow]Warning:[/yellow] {_w.message}")

        # Probe for large datasets when no last_n/first_n limit is set
        if not last_n and not first_n and not yes:
            try:
                with console.status("[dim]Checking dataset size...[/dim]"):
                    probe = get_data(ds, last_n_observations=1)
                n_series = len(probe)
                if n_series > _LARGE_DATASET_THRESHOLD:
                    err_console.print(
                        f"[yellow]Warning:[/yellow] this dataset has ~{n_series:,} series (no filters set).\n"
                        f"Download may be large. Use [cyan]--last-n N[/cyan] to limit, or [cyan]--yes[/cyan] to proceed."
                    )
                    raise typer.Exit(1)
            except httpx.HTTPStatusError:
                pass  # let the real request fail with a proper error

        with console.status("[dim]Fetching data...[/dim]"):
            df = get_data(ds, start_period=start_period, end_period=end_period,
                          last_n_observations=last_n, first_n_observations=first_n)
    except httpx.HTTPStatusError as e:
        err_console.print(f"[red]HTTP {e.response.status_code}:[/red] {e.request.url}")
        if e.response.status_code in (400, 404):
            err_console.print("[yellow]Hint:[/yellow] check filter values with: opensdmx constraints <dataset_id>")
        raise typer.Exit(1)
    except Exception as e:
        err_console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)

    if out is None:
        sys.stdout.write(df.write_csv())
    else:
        suffix = out.suffix.lower()
        if suffix == ".parquet":
            df.write_parquet(out)
        elif suffix == ".json":
            df.write_ndjson(out)
        elif suffix == ".csv":
            df.write_csv(out)
        else:
            err_console.print(f"[red]Error:[/red] unsupported output format '{suffix}'. Supported: .csv, .parquet, .json")
            raise typer.Exit(1)
        console.print(f"[green]Saved:[/green] {out}")


@app.command(context_settings={"allow_extra_args": True, "ignore_unknown_options": True})
def plot(
    ctx: typer.Context,
    dataset_id: str = typer.Argument(..., help="Dataset ID"),
    x: str = typer.Option("TIME_PERIOD", "--x", help="Column for X axis"),
    y: str = typer.Option("OBS_VALUE", "--y", help="Column for Y axis"),
    color: Optional[str] = typer.Option(None, "--color", help="Column for color grouping"),
    geom: str = typer.Option("line", "--geom", help="Chart type: line, bar, barh, point, scatter"),
    title: Optional[str] = typer.Option(None, "--title", help="Chart title (default: dataset description)"),
    xlabel: Optional[str] = typer.Option(None, "--xlabel", help="X axis label (default: column name)"),
    ylabel: Optional[str] = typer.Option(None, "--ylabel", help="Y axis label (default: column name)"),
    out: Optional[Path] = typer.Option(None, "--out", help="Output file (.png/.pdf/.svg) — default: <dataset_id>.png"),
    width: float = typer.Option(10.0, "--width", help="Chart width in inches"),
    height: float = typer.Option(5.0, "--height", help="Chart height in inches"),
    start_period: Optional[str] = typer.Option(None, "--start-period", help="Start period (e.g. 2020, 2020-Q1, 2020-01)"),
    end_period: Optional[str] = typer.Option(None, "--end-period", help="End period (e.g. 2023, 2023-Q4, 2023-12)"),
    provider: Optional[str] = typer.Option(None, "--provider", "-p", help=_PROVIDER_HELP),
):
    """Plot data as a chart (line, bar, horizontal bar, or scatter).

    INPUT can be a dataflow ID (fetches from SDMX) or a local file
    (.csv, .tsv, .parquet). Extra --DIM VALUE pairs are used as filters
    when fetching from SDMX.

    Examples:

      opensdmx plot une_rt_m --freq M --geo IT --color geo
      opensdmx plot /tmp/data.csv --color geo --title "Road deaths"
      opensdmx plot /tmp/ranking.csv --geom barh --x geo --title "Rate by country"
      opensdmx plot /tmp/data.csv --geom bar --x year --color geo
    """
    import matplotlib
    matplotlib.use("Agg")
    from plotnine import aes, coord_flip, geom_col, geom_line, geom_point, ggplot, labs, scale_x_date, theme_minimal

    import polars as pl

    # Detect file input vs dataflow ID
    input_path = Path(dataset_id)
    ds_description = dataset_id
    if input_path.suffix.lower() in (".csv", ".tsv", ".parquet") and input_path.exists():
        try:
            if input_path.suffix.lower() == ".parquet":
                df = pl.read_parquet(input_path)
            else:
                separator = "\t" if input_path.suffix.lower() == ".tsv" else ","
                df = pl.read_csv(input_path, separator=separator, infer_schema_length=10000, schema_overrides={"TIME_PERIOD": pl.Utf8})
            ds_description = input_path.stem
        except Exception as e:
            err_console.print(f"[red]Error reading file:[/red] {e}")
            raise typer.Exit(1)
    else:
        _apply_provider(provider)
        from . import get_data, load_dataset, set_filters

        filters = _parse_extra_filters(ctx)

        try:
            ds = load_dataset(dataset_id)
            if filters:
                ds = set_filters(ds, **filters)
            df = get_data(ds, start_period=start_period, end_period=end_period)
            ds_description = ds["df_description"]
        except httpx.HTTPStatusError as e:
            err_console.print(f"[red]HTTP {e.response.status_code}:[/red] {e.request.url}")
            if e.response.status_code in (400, 404):
                err_console.print("[yellow]Hint:[/yellow] check filter values with: opensdmx constraints <dataset_id>")
            raise typer.Exit(1)
        except Exception as e:
            err_console.print(f"[red]Error:[/red] {e}")
            raise typer.Exit(1)

    if x not in df.columns or y not in df.columns:
        err_console.print(f"[red]Error:[/red] columns '{x}' or '{y}' not found in data.")
        err_console.print(f"Available columns: {', '.join(df.columns)}")
        raise typer.Exit(1)

    df = df.with_columns(pl.col(y).cast(pl.Float64, strict=False))
    if df[x].dtype == pl.Utf8:
        from .retrieval import parse_time_period
        parsed = parse_time_period(df[x])
        if parsed.drop_nulls().len() > 0:
            df = df.with_columns(parsed.alias(x))
    pdf = df.to_pandas()

    if geom == "scatter":
        geom = "point"
    if geom not in ("line", "bar", "barh", "point"):
        err_console.print(f"[red]Error:[/red] unknown --geom '{geom}'. Use: line, bar, barh, point, scatter")
        raise typer.Exit(1)

    if geom in ("bar", "barh"):
        import pandas as pd

        # Sort categories by value for readable bar charts
        if geom == "barh":
            order = pdf.groupby(x)[y].sum().sort_values().index.tolist()
            pdf[x] = pd.Categorical(pdf[x], categories=order, ordered=True)
            if color:
                aes_mapping = aes(x=x, y=y, fill=color)
            else:
                aes_mapping = aes(x=x, y=y)
            p = ggplot(pdf, aes_mapping) + geom_col() + coord_flip()
            p = p + labs(
                title=title or ds_description,
                x=xlabel or x,
                y=ylabel or y,
            )
        else:
            if color:
                aes_mapping = aes(x=x, y=y, fill=color)
            else:
                aes_mapping = aes(x=x, y=y)
            p = ggplot(pdf, aes_mapping) + geom_col()
            p = p + labs(
                title=title or ds_description,
                x=xlabel or x,
                y=ylabel or y,
            )
        p = p + theme_minimal()
    else:
        aes_mapping = aes(x=x, y=y, color=color) if color else aes(x=x, y=y)
        p = ggplot(pdf, aes_mapping)
        if geom == "point":
            p = p + geom_point(size=2)
        else:
            p = p + geom_line(size=1) + geom_point(size=1.5)
        p = p + labs(
            title=title or ds_description,
            x=xlabel or x,
            y=ylabel or y,
        ) + theme_minimal()
        if hasattr(pdf[x], "dt"):
            p = p + scale_x_date(date_breaks="2 years", date_labels="%Y")

    if out is None:
        import re
        safe_name = re.sub(r"[^\w\-]", "_", ds_description.lower()).strip("_")
        out = Path(f"{safe_name}.png")
    p.save(str(out), dpi=150, width=width, height=height)
    console.print(f"[green]Saved:[/green] {out}")


@app.command(hidden=True)
def guide(
    query: Optional[str] = typer.Argument(None, help="Goal in natural language"),
    dataset: Optional[str] = typer.Option(None, "--dataset", "-d", help="Dataset ID to use directly (skip interactive selection)"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Non-interactive: auto-confirm all prompts and download data.csv"),
    out: Path = typer.Option(Path("data.csv"), "--out", help="Output file when --yes is set"),
    provider: Optional[str] = typer.Option(None, "--provider", "-p", help=_PROVIDER_HELP),
):
    """Guided dataset discovery: semantic search + AI multi-turn conversation for filters.

    Default provider: eurostat. Use --provider to switch.

    Examples:

      opensdmx guide "unemployment Italy"
      opensdmx guide "PIL Italia" --dataset NAMA_10_GDP --yes
      opensdmx guide "popolazione" --provider istat --yes --out pop.csv
    """
    _apply_provider(provider)
    from .guide import run_guide
    run_guide(query=query, dataset=dataset, yes=yes, out=out)


@app.command()
def blacklist(
    remove: Optional[list[str]] = typer.Option(None, "--remove", help="Dataset ID to remove from blacklist (repeatable)"),
    provider: Optional[str] = typer.Option(None, "--provider", "-p", help=_PROVIDER_HELP),
):
    """List and manage datasets marked as unavailable.

    Default provider: eurostat. Use --provider to switch.

    Examples:

      opensdmx blacklist
      opensdmx blacklist --remove NAMA_10_GDP
      opensdmx blacklist --remove NAMA_10_GDP --remove STS_INPR_M
    """
    _apply_provider(provider)
    from .db_cache import delete_invalid_dataset, list_invalid_datasets

    # Non-interactive remove via --remove flag
    if remove:
        for df_id in remove:
            if delete_invalid_dataset(df_id):
                console.print(f"[green]Removed:[/green] {df_id}")
            else:
                err_console.print(f"[yellow]Not found in blacklist:[/yellow] {df_id}")
        return

    entries = list_invalid_datasets()
    if not entries:
        console.print("[green]No datasets in the blacklist.[/green]")
        return

    table = Table(title="Blacklisted datasets", show_lines=False)
    table.add_column("df_id", style="cyan", no_wrap=True)
    table.add_column("Description")
    table.add_column("Added on", style="dim", no_wrap=True)

    import datetime
    for e in entries:
        date_str = datetime.datetime.fromtimestamp(e["marked_at"]).strftime("%Y-%m-%d %H:%M")
        table.add_row(e["df_id"], e["description"] or "", date_str)

    console.print(table)

    try:
        import questionary
    except ImportError:
        err_console.print(
            "[red]Error:[/red] questionary not installed.\n"
            "Run: pip install opensdmx[guide]"
        )
        raise typer.Exit(1)

    choices = [
        questionary.Choice(
            title=f"{e['df_id']}  {e['description'] or ''}",
            value=e["df_id"],
        )
        for e in entries
    ]
    to_remove = questionary.checkbox(
        "Select datasets to remove from blacklist:",
        choices=choices,
    ).ask()

    if not to_remove:
        console.print("[dim]No changes.[/dim]")
        return

    for df_id in to_remove:
        delete_invalid_dataset(df_id)
        console.print(f"[green]Removed:[/green] {df_id}")


def main():
    app()
