# 🗄️ DBSheet

> Import Excel / CSV files directly into **MySQL** or **PostgreSQL** — straight from your terminal.

---

## ✨ Features

- 📊 Load `.xlsx` and `.csv` files into a database with one command
- 🐘 Supports **PostgreSQL** and **MySQL**
- 🔑 Auto primary key with custom data type
- 🔄 Upsert support — re-run without duplicates
- 🛡️ Handles column names with **spaces** (`Joining Date`, etc.)
- 🔒 Hidden password input (`****`)
- ⚡ Auto port detection (`5432` for Postgres, `3306` for MySQL)
- 📁 Built-in file manager (`ls`, `mkdir`, `touch`, `remove`, etc.)
- 🎨 Beautiful CLI powered by [Rich](https://github.com/Textualize/rich)

---

## 📦 Installation

```bash
pip install dbsheet
```

Or install from source:

```bash
git clone https://github.com/yourusername/dbsheet.git
cd dbsheet
pip install -e .
```

---

## 🚀 Quick Start

```bash
dbsheet
```

Then inside the CLI:

```
> config
db type (mysql/postgres): postgres
host: localhost
user: postgres
password:               ← hidden input
database: mydb
port (press Enter for default '5432'):
excel file: ./data.xlsx
sheet name: Sheet1
configuration loaded

> create_db
> connect
> create_table
> insert
DATA INSERTED OR UPDATED
```

---

## 📋 Excel Format

Your Excel file should look like this:

| ID   | Name          | Age | Joining Date | Status |
|------|---------------|-----|--------------|--------|
| 1001 | Aarav Sharma  | 28  | 2023-01-15   | Active |
| 1002 | Priya Verma   | 31  | 2022-07-04   | Active |

> ✅ Column names with spaces like `Joining Date` are fully supported.  
> ✅ Data can start from any row — empty leading rows are auto-skipped.

---

## ⚙️ Config File

Instead of typing config every time, save it to a `.txt` file:

```
db_type: postgres
host: localhost
user: postgres
password: yourpassword
database: mydb
port: 5432
file_name: ./data.xlsx
sheet_name: Sheet1
```

Then load it:

```
> config_file
config_file: ./myconfig.txt
config loaded from /path/to/myconfig.txt
```

---

## 📖 All Commands

| Command       | Description                          |
|---------------|--------------------------------------|
| `config`      | Configure database connection        |
| `config_file` | Load config from a `.txt` file       |
| `read_config` | Show current config (password hidden)|
| `create_db`   | Create the database                  |
| `connect`     | Connect to the database              |
| `create_table`| Create table from Excel headers      |
| `insert`      | Insert / upsert all rows             |
| `select`      | Select and print all rows            |
| `drop_table`  | Drop the current table               |
| `truncate`    | Truncate the current table           |
| `find`        | Find rows by column value            |
| `row_count`   | Show number of data rows in Excel    |
| `col_count`   | Show number of columns               |
| `header`      | Print column headers                 |
| `sheet`       | Print sheet name                     |
| `ls`          | List files and directories           |
| `mkdir`       | Create a folder                      |
| `rmdir`       | Remove a folder                      |
| `touch`       | Create a file                        |
| `remove`      | Remove a file                        |
| `path`        | Show absolute path of a file         |
| `read_file`   | Read and print a file's content      |
| `edit`        | Open file in terminal editor         |
| `cls`         | Clear the screen                     |
| `exit`        | Quit the CLI                         |

---

## 🔍 Find Command

Supports column names with spaces:

```
> find
column name: Joining Date
value: 2023-01-15
found:
(1001, 'Aarav Sharma', 28, 65000, 'Engineering', 'Delhi', '...', '2023-01-15', 'Active')
```

---

## 🗂️ Project Structure

```
dbsheet/
├── __init__.py
├── cli.py          ← CLI entry point
├── db_sheet.py     ← MySQL / Postgres logic
├── os_sys.py       ← File manager utilities
└── editor.py       ← Terminal file editor
setup.py
pyproject.toml
README.md
```

---

## 🛠️ Requirements

- Python 3.8+
- PostgreSQL or MySQL running locally or remotely

Dependencies installed automatically via pip:

```
psycopg[binary]>=3.0
mysql-connector-python>=8.0
openpyxl>=3.0
rich>=13.0
```

---

## 📝 License

MIT License — free to use and modify.