from setuptools import setup, find_packages
from pathlib import Path

long_description = (Path(__file__).parent / "README.md").read_text(encoding="utf-8")

setup(
    name="sheetpush",
    version="1.0.0",
    description="Import Excel / CSV files directly into MySQL or PostgreSQL from the terminal",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Sarthak sachdeva",
    author_email="your@email.com",
    url="https://github.com/RangamRKSS/dbsheet_git",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "psycopg[binary]>=3.0",
        "mysql-connector-python>=8.0",
        "openpyxl>=3.0",
        "rich>=13.0",
    ],
    entry_points={
        "console_scripts": [
            "sheetpush=sheetpush.cli:run",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)