import curses
import sys

def config_editor(filepath: str):
    """Simple config file editor"""
    
    # File read karo
    try:
        with open(filepath, "r") as f:
            lines = f.readlines()
    except FileNotFoundError:
        lines = []
    
    def main(stdscr):
        curses.curs_set(1)
        curses.start_color()
        
        # Colors
        curses.init_pair(1, curses.COLOR_GREEN, curses.COLOR_BLACK)
        curses.init_pair(2, curses.COLOR_YELLOW, curses.COLOR_BLACK)
        curses.init_pair(3, curses.COLOR_CYAN, curses.COLOR_BLACK)
        curses.init_pair(4, curses.COLOR_BLACK, curses.COLOR_GREEN)
        
        # State
        buffer = [line.rstrip('\n') for line in lines]
        if not buffer:
            buffer = [""]
        
        cursor_y = 0
        cursor_x = 0
        offset_y = 0
        message = ""
        
        while True:
            stdscr.clear()
            height, width = stdscr.getmaxyx()
            
            # ── Header ──────────────────────
            header = f" DBSHEET Config Editor — {filepath} "
            stdscr.attron(curses.color_pair(4))
            stdscr.addstr(0, 0, header.ljust(width))
            stdscr.attroff(curses.color_pair(4))
            
            # ── File content ────────────────
            for i, line in enumerate(
                buffer[offset_y:offset_y + height - 3]
            ):
                y = i + 1
                
                # Line number
                stdscr.attron(curses.color_pair(3))
                stdscr.addstr(y, 0, f"{offset_y + i + 1:3} ")
                stdscr.attroff(curses.color_pair(3))
                
                # Line content — comments gray
                if line.startswith("#"):
                    stdscr.attron(curses.color_pair(3))
                    stdscr.addstr(y, 4, line[:width-5])
                    stdscr.attroff(curses.color_pair(3))
                    
                # Key = Value highlight
                elif "=" in line:
                    parts = line.split("=", 1)
                    
                    # Key — yellow
                    stdscr.attron(curses.color_pair(2))
                    stdscr.addstr(y, 4, parts[0])
                    stdscr.attroff(curses.color_pair(2))
                    
                    stdscr.addstr(y, 4 + len(parts[0]), "=")
                    
                    # Value — green
                    stdscr.attron(curses.color_pair(1))
                    if len(parts) > 1:
                        stdscr.addstr(
                            y, 
                            5 + len(parts[0]), 
                            parts[1][:width-6-len(parts[0])]
                        )
                    stdscr.attroff(curses.color_pair(1))
                    
                else:
                    stdscr.addstr(y, 4, line[:width-5])
            
            # ── Status bar ──────────────────
            status = (
                f" Ctrl+S: Save  "
                f"Ctrl+Q: Quit  "
                f"Line: {cursor_y+1}/{len(buffer)}"
            )
            stdscr.attron(curses.color_pair(4))
            stdscr.addstr(height-2, 0, status.ljust(width))
            stdscr.attroff(curses.color_pair(4))
            
            # Message bar
            if message:
                stdscr.attron(curses.color_pair(1))
                stdscr.addstr(height-1, 0, message[:width])
                stdscr.attroff(curses.color_pair(1))
            
            # Cursor set karo
            try:
                stdscr.move(
                    cursor_y - offset_y + 1,
                    min(cursor_x + 4, width-1)
                )
            except:
                pass
            
            stdscr.refresh()
            
            # ── Key handling ────────────────
            key = stdscr.getch()
            
            # Arrow keys
            if key == curses.KEY_UP:
                if cursor_y > 0:
                    cursor_y -= 1
                    cursor_x = min(
                        cursor_x, 
                        len(buffer[cursor_y])
                    )
                    if cursor_y < offset_y:
                        offset_y -= 1
                        
            elif key == curses.KEY_DOWN:
                if cursor_y < len(buffer) - 1:
                    cursor_y += 1
                    cursor_x = min(
                        cursor_x,
                        len(buffer[cursor_y])
                    )
                    if cursor_y >= offset_y + height - 3:
                        offset_y += 1
                        
            elif key == curses.KEY_LEFT:
                if cursor_x > 0:
                    cursor_x -= 1
                    
            elif key == curses.KEY_RIGHT:
                if cursor_x < len(buffer[cursor_y]):
                    cursor_x += 1
            
            # Home / End
            elif key == curses.KEY_HOME:
                cursor_x = 0
                
            elif key == curses.KEY_END:
                cursor_x = len(buffer[cursor_y])
            
            # Backspace
            elif key in (curses.KEY_BACKSPACE, 127, 8):
                if cursor_x > 0:
                    line = buffer[cursor_y]
                    buffer[cursor_y] = (
                        line[:cursor_x-1] + 
                        line[cursor_x:]
                    )
                    cursor_x -= 1
                elif cursor_y > 0:
                    # Lines merge karo
                    cursor_x = len(buffer[cursor_y-1])
                    buffer[cursor_y-1] += buffer[cursor_y]
                    buffer.pop(cursor_y)
                    cursor_y -= 1
            
            # Enter — new line
            elif key == 10:
                line = buffer[cursor_y]
                buffer[cursor_y] = line[:cursor_x]
                buffer.insert(cursor_y+1, line[cursor_x:])
                cursor_y += 1
                cursor_x = 0
                if cursor_y >= offset_y + height - 3:
                    offset_y += 1
            
            # Ctrl+S — Save
            elif key == 19:
                with open(filepath, "w") as f:
                    f.write('\n'.join(buffer))
                message = "✅ Saved!"
                
            # Ctrl+Q — Quit
            elif key == 17:
                break
            
            # Normal character type karo
            elif 32 <= key <= 126:
                line = buffer[cursor_y]
                buffer[cursor_y] = (
                    line[:cursor_x] + 
                    chr(key) + 
                    line[cursor_x:]
                )
                cursor_x += 1
    
    curses.wrapper(main)