from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from .sheetpush import Sheetpush
from .os_sys import mkdir,rmdir,remove,path,listDir,touch,read_file,clear_screen
from pathlib import Path
import getpass

console = Console()


def show_help():
    table = Table(title="Sheetpush Commands", border_style="cyan")
    table.add_column("Command", style="bold yellow")
    table.add_column("Description", style="white")
    table.add_row("config", "configure database connection")
    table.add_row("config_file", "configure database connection file")
    table.add_row("read_config", "read configure database connection file")
    table.add_row("create_db", "create database")
    table.add_row("connect", "connect database")
    table.add_row("create_table <column , data type>", "create table from excel")
    table.add_row("insert", "insert excel rows")
    table.add_row("drop_table", "drop current table")
    table.add_row("truncate", "truncate current table")
    table.add_row("select", "select all rows")
    table.add_row("row_count", "show excel row count")
    table.add_row("col_count", "show excel column count")
    table.add_row("find <column> <value>", "find value in excel")
    table.add_row("header", "show table header")
    table.add_row("sheet", "show table sheet")
    table.add_row("ls", "show file and dir list")
    table.add_row("mkdir", "create folder")
    table.add_row("rmdir", "remove folder")
    table.add_row("touch", "create file")
    table.add_row("remove", "remove file")
    table.add_row("path", "show file absulute path")
    table.add_row("edit", "edit files ")
    table.add_row("read_file", "read files data")
    table.add_row("cls", "clear screen")
    table.add_row("exit", "quit cli")

    console.print(table)


def build_db(config):
    return Sheetpush.create(
        db_type=config["db_type"],
        host=config["host"],
        user=config["user"],
        password=config["password"],
        database=config["database"],
        port=int(config.get("port", 5432)),
        file_name=config["file_name"],
        sheet_name=config["sheet_name"],
    )


def run():
    console.print(
        Panel(
            "[bold green]Welcome to Sheetpush CLI[/bold green]\nType [yellow]help[/yellow]",
            border_style="green",
        )
    )

    config = {}
    config_file = {}
    cf_file = None
    db = None
    unqic_col = None
    unqic_dtype = None

    while True:
        try:
            raw = console.input("[bold cyan]> [/bold cyan]").strip()
        except (KeyboardInterrupt, EOFError):
            console.print("\n[bold red]Goodbye[/bold red]")
            break

        if not raw:
            continue

        parts = raw.split()
        cmd = parts[0].lower()

        if cmd in ("exit", "quit"):
            console.print("[bold red]Goodbye[/bold red]")
            break

        elif cmd == "help":
            show_help()

        elif cmd == "config":
            # ── db type ──────────────────────────────────────────
            db_type = console.input("db type (mysql/postgres): ").strip().lower()
            config["db_type"] = db_type

            # ── auto default port based on db type ───────────────
            default_port = "5432" if db_type == "postgres" else "3306"

            config["host"]     = console.input("host: ").strip()
            config["user"]     = console.input("user: ").strip()

            # ── hidden password (shows **** while typing) ─────────
            config["password"] = getpass.getpass("password: ")

            config["database"] = console.input("database: ").strip()

            # ── port with smart default ───────────────────────────
            port_input = console.input(
                f"port (press Enter for default '{default_port}'): "
            ).strip()
            config["port"] = port_input or default_port

            config["file_name"]  = console.input("excel file: ").strip()
            config["sheet_name"] = console.input("sheet name: ").strip()

            db = build_db(config)
            console.print("[green]configuration loaded[/green]")

        elif cmd == "config_file":
            raw_path = console.input("config_file: ").strip()
            cf_file = Path(raw_path).expanduser().resolve()
            if not cf_file.exists():
                console.print(f"[red]File not found:[/red] {cf_file}")
                continue
            try:
                config_file = {}
                with cf_file.open("r", encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if not line or line.startswith("#"):
                            continue
                        if ":" not in line:
                            continue
                        key, value = line.split(":", 1)
                        config_file[key.strip()] = value.strip()

                required = [
                    "db_type",
                    "host",
                    "user",
                    "password",
                    "database",
                    "port",
                    "file_name",
                    "sheet_name",
                ]

                missing = [k for k in required if k not in config_file]

                if missing:
                    console.print(
                        f"[red]Missing config keys:[/red] {', '.join(missing)}"
                    )
                    continue

                # ── auto fill port if missing or empty ────────────
                if not config_file.get("port"):
                    config_file["port"] = (
                        "5432" if config_file.get("db_type") == "postgres" else "3306"
                    )

                db = build_db(config_file)
                console.print(
                    f"[green]config loaded from[/green] [bold]{cf_file}[/bold]"
                )
            except Exception as e:
                console.print(f"[red]Config error:[/red] {e}")

        elif cmd == "create_db":
            db.create_db()

        elif cmd == "read_config":
            if not db:
                console.print("[red]No config loaded[/red]")
            else:
                table = Table(title="Current Config", border_style="cyan")
                table.add_column("Key", style="bold yellow")
                table.add_column("Value", style="white")

                for key in ("host", "user", "password", "database", "port", "file_name", "sheet_name"):
                    raw_value = config.get(key) or config_file.get(key, "")
                    # ── mask password in read_config display ──────
                    display_value = "********" if key == "password" else str(raw_value)
                    table.add_row(key, display_value)

                console.print(table)

        elif cmd == "connect":
            db.connect()

        elif cmd == "create_table":
            value = console.input(
                "unique column (optional, press Enter for default 'id'): "
            ).strip()
            dtype_value = console.input(
                "unique column data type (optional, press Enter for default 'TEXT'): "
            ).strip()

            unqic_col = value or "id"
            unqic_dtype = dtype_value or "TEXT"
            try:
                db.drop_table()
            except Exception:
                pass
            db.create_table(unqic_col, unqic_dtype)
            console.print(
                f"[green]table created with unique column:[/green] [bold]{unqic_col}[/bold]"
            )

        elif cmd == "insert":
            db.insert()

        elif cmd == "header":
            db.show_header()

        elif cmd == "sheet":
            db.show_sheet()

        elif cmd == "drop_table":
            db.drop_table()

        elif cmd == "truncate":
            db.truncate_table()

        elif cmd == "select":
            db.select_all()

        elif cmd == "row_count":
            db.row_count()

        elif cmd == "col_count":
            db.col_count()

        elif cmd == "ls":
            value = console.input("enter path (./): ").strip()
            listDir(value)

        elif cmd == "mkdir":
            value = console.input("enter folder name & path (./): ").strip()
            mkdir(value)

        elif cmd == "rmdir":
            value = console.input("enter folder name & path (./): ").strip()
            rmdir(value)

        elif cmd == "remove":
            value = console.input("enter folder name & path (./): ").strip()
            remove(value)

        elif cmd == "touch":
            value = console.input("enter folder name & path (./): ").strip()
            touch(value)

        elif cmd == "path":
            value = console.input("enter folder name & path (./): ").strip()
            path(value)

        elif cmd == "read_file":
            value = console.input("enter folder name & path (./): ").strip()
            read_file(value)

        elif cmd == "cls":
            clear_screen()
            console.print(
                Panel(
                    "[bold green]Welcome to Sheetpush CLI[/bold green]\nType [yellow]help[/yellow]",
                    border_style="green",
                )
            )

        elif cmd == "find":
            col   = console.input("column name: ").strip()   # handles spaces like "Joining Date"
            value = console.input("value: ").strip()
            db.find(col, value)

        elif cmd == "edit":
            try:
                from .editor import config_editor
                filename = console.input("enter file name & path (./): ").strip()
                config_editor(filename)
            except ImportError:
                console.print("[red]curses is not available. Install:[/red] pip install windows-curses")

        elif not db:
            console.print("[red]Run 'config' first[/red]")

        else:
            console.print(f"[red]Unknown command:[/red] {cmd}")


if __name__ == "__main__":
    run()