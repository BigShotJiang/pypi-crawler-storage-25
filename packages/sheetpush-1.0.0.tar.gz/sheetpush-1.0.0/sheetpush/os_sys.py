import os 
from pathlib import Path
# print(os.getcwd())
# dir = ", ".join(os.listdir())
# os.mkdir()
# os.rmdir()
# os.rename() rename file
# os.remove()  remove file
# print(os.path.abspath("../config.txt"))
# os.path.exists()

def listDir(dir="./"):
    ddir = ', '.join(os.listdir(dir))
    print(ddir)


def mkdir(dir):
    os.mkdir(dir)
    if os.path.exists(dir):
        print(os.path.abspath(dir))
    else:
        print(dir," folder not created")


def rmdir(dir):
    os.rmdir(dir)
    if os.path.exists(dir):
        print("folder not remove")
    else:
        print("folder remove")

def remove(file):
    os.remove(file)
    if os.path.exists(file):
        print("file not remove")
    else:
        print("file remove")

def path(file):
    print(os.path.abspath(file))

def touch(filename):
    Path(filename).touch()
    if os.path.exists(filename):
        print("file created")
    else:
        print("file not created")



def read_file(filename):
    if os.path.exists(filename):
        with open(filename , "r") as f:
            print("++++++++++++++++++++++++++++++++++++++")
            print(f.read())
            print("++++++++++++++++++++++++++++++++++++++")


def clear_screen():
    os.system("cls" if os.name == "nt" else "clear")