import csv
from pathlib import Path
import psycopg
import mysql.connector
from typing import TypeVar, overload, Literal, Union
from abc import ABC, abstractmethod
from openpyxl import load_workbook


def load_sheet(file_name, sheet_name=None):
    ext = Path(file_name).suffix.lower()

    if ext in (".xlsx", ".xlsm", ".xltx", ".xltm"):
        wd = load_workbook(file_name)
        ws = wd[sheet_name]

        # Find the first non-empty row to use as header
        header_row_index = None
        for i, row in enumerate(ws.iter_rows(values_only=True), start=1):
            if any(cell is not None for cell in row):
                header_row_index = i
                break

        if header_row_index is None:
            raise ValueError("Sheet appears to be empty")

        # Read header from that row, strip None and whitespace
        raw_header = [cell.value for cell in ws[header_row_index]]
        header = [
            str(h).strip()
            for h in raw_header
            if h is not None and str(h).strip() != ""
        ]

        # Store header_row_index on ws so insert() knows where data starts
        ws._header_row_index = header_row_index
        table_name = ws.title
        return ws, header, table_name

    elif ext == ".csv":
        with open(file_name, "r", encoding="utf-8-sig", newline="") as f:
            rows = list(csv.reader(f))

        # Strip empty leading rows
        start = 0
        for i, row in enumerate(rows):
            if any(cell.strip() for cell in row):
                start = i
                break

        header = [h.strip() for h in rows[start] if h.strip() != ""]
        table_name = Path(file_name).stem

        class CsvSheet:
            def __init__(self, rows, header, title, data_start):
                self.rows = rows
                self.header = header
                self.title = title
                self.max_row = len(rows) - data_start
                self.max_column = len(header)
                self._header_row_index = data_start + 1  # 1-based

            def iter_rows(self, min_row=1, values_only=True):
                for row in self.rows[min_row - 1:]:
                    yield tuple(row)

        ws = CsvSheet(rows, header, table_name, start)
        return ws, header, table_name

    else:
        raise ValueError("Only .xlsx and .csv supported")


class BaseDb(ABC):
    @abstractmethod
    def create_db(self):
        raise NotImplementedError

    @abstractmethod
    def connect(self):
        raise NotImplementedError

    @abstractmethod
    def create_table(self):
        raise NotImplementedError

    @abstractmethod
    def insert(self):
        raise NotImplementedError

    @abstractmethod
    def drop_table(self):
        raise NotImplementedError

    @abstractmethod
    def row_count(self):
        raise NotImplementedError

    @abstractmethod
    def col_count(self):
        raise NotImplementedError

    @abstractmethod
    def truncate_table(self):
        raise NotImplementedError

    @abstractmethod
    def select_all(self):
        raise NotImplementedError

    @abstractmethod
    def find(self, col, value):
        raise NotImplementedError

    @abstractmethod
    def show_header(self):
        raise NotImplementedError

    @abstractmethod
    def show_sheet(self):
        raise NotImplementedError


# ─────────────────────────────────────────────
#  MySQL  (backticks everywhere)
# ─────────────────────────────────────────────
class Mysql(BaseDb):
    def __init__(self, host, user, password, database, file_name, sheet_name=None, port=3306):
        self.host = host
        self.user = user
        self.password = password
        self.database = database
        self.cur = None
        self.conn = None
        self.file_name = file_name
        self.sheet_name = sheet_name
        self.port = port
        self.uqnic = None
        self.uqnic_dtype = None
        self.ws, self.header, self.table_name = load_sheet(self.file_name, self.sheet_name)

    def create_db(self):
        conn = mysql.connector.connect(
            host=self.host,
            user=self.user,
            password=self.password
        )
        cur = conn.cursor()
        cur.execute(f"CREATE DATABASE IF NOT EXISTS `{self.database}`")
        conn.commit()
        cur.close()
        conn.close()
        print(f"{self.database} database created successfully")

    def connect(self):
        self.conn = mysql.connector.connect(
            host=self.host,
            user=self.user,
            password=self.password,
            database=self.database,
            port=self.port
        )
        self.cur = self.conn.cursor()
        print("mysql connected")

    def create_table(self, uqnic="id", uqnic_dtype="TEXT"):
        if uqnic not in self.header:
            raise ValueError(f"column '{uqnic}' not found in sheet")

        self.uqnic = uqnic
        self.uqnic_dtype = uqnic_dtype
        column = []
        for col in self.header:
            if col == uqnic:
                column.append(f"`{col}` {uqnic_dtype} PRIMARY KEY")
            else:
                column.append(f"`{col}` TEXT")

        sql = f"""
        CREATE TABLE IF NOT EXISTS `{self.table_name}` (
            {", ".join(column)}
        )
        """

        try:
            self.conn.rollback()
            self.cur.execute(f"DROP TABLE IF EXISTS `{self.table_name}`")
            self.cur.execute(sql)
            self.conn.commit()
            print("table created")
        except Exception as e:
            self.conn.rollback()
            print(f"create_table error: {e}")

    def insert(self):
        columns = ", ".join([f"`{c}`" for c in self.header])
        placeholders = ", ".join(["%s"] * len(self.header))
        update_cols = ", ".join(
            [f"`{col}` = VALUES(`{col}`)" for col in self.header if col != self.uqnic]
        )

        sql = f"""
        INSERT INTO `{self.database}`.`{self.table_name}` ({columns})
        VALUES ({placeholders})
        ON DUPLICATE KEY UPDATE {update_cols}
        """

        data_start = getattr(self.ws, '_header_row_index', 1) + 1
        rows = [
            tuple(row[:len(self.header)])
            for row in self.ws.iter_rows(min_row=data_start, values_only=True)
            if any(cell is not None for cell in row)
        ]

        try:
            self.cur.executemany(sql, rows)
            self.conn.commit()
            print("DATA INSERTED OR UPDATED")
        except Exception as e:
            self.conn.rollback()
            print(f"insert error: {e}")

    def drop_table(self):
        self.cur.execute(f"DROP TABLE `{self.table_name}`")
        self.conn.commit()
        print(f"{self.table_name} table deleted")

    def truncate_table(self):
        self.cur.execute(f"TRUNCATE TABLE `{self.table_name}`")
        self.conn.commit()
        print(f"{self.table_name} TRUNCATE TABLE")

    def row_count(self):
        data_start = getattr(self.ws, '_header_row_index', 1) + 1
        count = sum(
            1 for row in self.ws.iter_rows(min_row=data_start, values_only=True)
            if any(cell is not None for cell in row)
        )
        print(count)

    def col_count(self):
        print(len(self.header))

    def select_all(self):
        self.cur.execute(f"SELECT * FROM `{self.table_name}`")
        print(self.cur.fetchall())

    def find(self, col, value):
        if col not in self.header:
            print("Header not found")
            return
        try:
            self.cur.execute(
                f"SELECT * FROM `{self.table_name}` WHERE `{col}` = %s",
                (value,)
            )
            rows = self.cur.fetchall()
            if rows:
                print("found:")
                for row in rows:
                    print(row)
            else:
                print("not found")
        except Exception as e:
            self.conn.rollback()
            print(f"find error: {e}")

    def show_header(self):
        print(", ".join(self.header))

    def show_sheet(self):
        print(self.ws.title)


# ─────────────────────────────────────────────
#  Postgres  (double quotes everywhere)
# ─────────────────────────────────────────────
class Postgres(BaseDb):
    def __init__(self, host, user, database, password, file_name, sheet_name=None, port=5432):
        self.host = host
        self.password = password
        self.user = user
        self.database = database
        self.cur = None
        self.conn = None
        self.file_name = file_name
        self.sheet_name = sheet_name
        self.port = port
        self.uqnic = None
        self.uqnic_dtype = None
        self.ws, self.header, self.table_name = load_sheet(self.file_name, self.sheet_name)

    def create_db(self):
        self.conn = psycopg.connect(
            host=self.host,
            dbname="postgres",
            user=self.user,
            password=self.password,
            port=self.port
        )
        self.conn.autocommit = True
        self.cur = self.conn.cursor()

        self.cur.execute(
            "SELECT 1 FROM pg_database WHERE datname = %s",
            (self.database,)
        )
        exists = self.cur.fetchone()

        if not exists:
            self.cur.execute(f'CREATE DATABASE "{self.database}"')
            print("Postgres database created")
        else:
            print("Database already exists")

        self.cur.close()
        self.conn.close()

    def connect(self):
        self.conn = psycopg.connect(
            host=self.host,
            dbname=self.database,
            user=self.user,
            password=self.password,
            port=self.port
        )
        self.conn.rollback()
        self.cur = self.conn.cursor()
        print("postgres connected")

    def create_table(self, uqnic="id", uqnic_dtype="TEXT"):
        if uqnic not in self.header:
            raise ValueError(f"column '{uqnic}' not found in sheet")

        self.uqnic = uqnic
        self.uqnic_dtype = uqnic_dtype
        column = []
        for col in self.header:
            if col == uqnic:
                column.append(f'"{col}" {uqnic_dtype} PRIMARY KEY')
            else:
                column.append(f'"{col}" TEXT')

        sql = f"""
        CREATE TABLE IF NOT EXISTS "{self.table_name}" (
            {", ".join(column)}
        )
        """

        try:
            self.conn.rollback()
            self.cur.execute(f'DROP TABLE IF EXISTS "{self.table_name}"')
            self.cur.execute(sql)
            self.conn.commit()
            print("table created")
        except Exception as e:
            self.conn.rollback()
            print(f"create_table error: {e}")

    def insert(self):
        columns = ", ".join([f'"{c}"' for c in self.header])
        placeholders = ", ".join(["%s"] * len(self.header))
        update_cols = ", ".join(
            [f'"{col}"=EXCLUDED."{col}"' for col in self.header if col != self.uqnic]
        )

        sql = f"""
        INSERT INTO "{self.table_name}" ({columns})
        VALUES ({placeholders})
        ON CONFLICT ("{self.uqnic}")
        DO UPDATE SET {update_cols}
        """

        data_start = getattr(self.ws, '_header_row_index', 1) + 1
        rows = [
            tuple(row[:len(self.header)])
            for row in self.ws.iter_rows(min_row=data_start, values_only=True)
            if any(cell is not None for cell in row)
        ]

        try:
            self.cur.executemany(sql, rows)
            self.conn.commit()
            print("DATA INSERTED OR UPDATED")
        except Exception as e:
            self.conn.rollback()
            print(f"insert error: {e}")

    def drop_table(self):
        self.cur.execute(f'DROP TABLE "{self.table_name}"')
        self.conn.commit()
        print(f"{self.table_name} table deleted")

    def truncate_table(self):
        self.cur.execute(f'TRUNCATE TABLE "{self.table_name}"')
        self.conn.commit()
        print(f"{self.table_name} TRUNCATE TABLE")

    def row_count(self):
        data_start = getattr(self.ws, '_header_row_index', 1) + 1
        count = sum(
            1 for row in self.ws.iter_rows(min_row=data_start, values_only=True)
            if any(cell is not None for cell in row)
        )
        print(count)

    def col_count(self):
        print(len(self.header))

    def select_all(self):
        self.cur.execute(f'SELECT * FROM "{self.table_name}"')
        print(self.cur.fetchall())

    def find(self, col, value):
        if col not in self.header:
            print("Header not found")
            return
        try:
            self.cur.execute(
                f'SELECT * FROM "{self.table_name}" WHERE "{col}" = %s',
                (value,)
            )
            rows = self.cur.fetchall()
            if rows:
                print("found:")
                for row in rows:
                    print(row)
            else:
                print("not found")
        except Exception as e:
            self.conn.rollback()
            print(f"find error: {e}")

    def show_header(self):
        print(", ".join(self.header))

    def show_sheet(self):
        print(self.ws.title)


T = TypeVar("T", bound=BaseDb)


class Sheetpush:
    DRIVERS = {
        "mysql": Mysql,
        "postgres": Postgres,
    }

    @classmethod
    @overload
    def create(cls, db_type: Literal["mysql"], **config) -> Mysql:
        ...

    @classmethod
    @overload
    def create(cls, db_type: Literal["postgres"], **config) -> Postgres:
        ...

    @classmethod
    def create(cls, db_type, **config) -> Union[Mysql, Postgres]:
        try:
            return cls.DRIVERS[db_type](**config)
        except KeyError:
            raise ValueError(f"unsupported database {db_type}")