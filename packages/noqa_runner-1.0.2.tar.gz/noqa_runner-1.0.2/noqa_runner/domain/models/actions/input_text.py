from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field
from pydantic.json_schema import SkipJsonSchema

from noqa_runner.domain.models.actions.base import BaseAction
from noqa_runner.domain.models.actions.tap import BBox2D
from noqa_runner.domain.models.state.screen import ActiveElement


class InputTextElementLocation(BaseModel):
    """Native element location for input field resolved via XML parsing."""

    element: ActiveElement = Field(
        description="Input field element with coordinates and metadata"
    )


class InputTextBboxLocation(BaseModel):
    """Bbox fallback location when no native input element found."""

    bbox_2d: BBox2D = Field(
        description="Bounding box [ymin, xmin, ymax, xmax] in range 0-1000"
    )


class InputText(BaseAction):
    """Input text into a mobile element using vision-based field selection"""

    name: Literal["input_text"] = "input_text"
    text: str = Field(description="Text to input into the field", min_length=1)
    element_description: str = Field(
        description="Description of the target input field"
    )
    location: SkipJsonSchema[
        InputTextElementLocation | InputTextBboxLocation | None
    ] = Field(
        default=None,
        description="Vision-detected input field location (element or bbox)",
    )

    def get_action_description(self) -> str:
        """Get description of vision input text action"""
        lower_first_desc = (
            self.element_description[0].lower() + self.element_description[1:]
        )
        return f"Input text '{self.text}' in {lower_first_desc}"
