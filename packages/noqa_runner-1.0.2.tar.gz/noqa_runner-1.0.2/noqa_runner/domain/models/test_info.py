"""Domain models for test information"""

from __future__ import annotations

from uuid import uuid4

from pydantic import BaseModel, Field, model_validator

from noqa_runner.domain.models.state.flow import FlowItemRaw


class RunnerTestInfo(BaseModel):
    """Test case information for runner.

    Either ``case_id`` (fetched from backend) or ``flows`` (inline) must be supplied.
    """

    test_id: str = Field(
        default_factory=lambda: str(uuid4()), description="Unique test identifier"
    )
    case_id: str | None = Field(
        default=None,
        description="Backend case ID — if provided, flows and case_name are fetched from the backend",
    )
    flows: list[FlowItemRaw] | None = Field(
        default=None,
        description="Test case flows with instructions and expected results",
    )
    case_name: str = Field(default="", description="Test case name")

    @model_validator(mode="after")
    def check_case_id_or_flows(self) -> "RunnerTestInfo":
        if not self.case_id and not self.flows:
            raise ValueError("Either 'case_id' or 'flows' must be provided")
        return self
