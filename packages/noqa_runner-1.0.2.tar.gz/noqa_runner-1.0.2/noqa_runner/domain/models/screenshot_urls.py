from __future__ import annotations

from pydantic import BaseModel


class ScreenshotURLs(BaseModel):
    upload_url: str
    download_url: str
    object_key: str
