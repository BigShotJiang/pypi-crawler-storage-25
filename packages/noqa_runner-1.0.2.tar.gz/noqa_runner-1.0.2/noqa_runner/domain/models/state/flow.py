from __future__ import annotations

from pydantic import BaseModel, Field

from noqa_runner.domain.models.state.expected_result import ExpectedResult


class FlowItemRaw(BaseModel):
    """Flow item as received from external sources — result is plain text"""

    instructions: str = Field(min_length=1)
    result: str | None = None


class FlowItem(BaseModel):
    """Flow item with structured expected result after preparation"""

    instructions: str = Field(min_length=1)
    result: ExpectedResult | None = None
