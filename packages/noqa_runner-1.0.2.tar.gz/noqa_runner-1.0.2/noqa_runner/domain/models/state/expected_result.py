from __future__ import annotations

from pydantic import BaseModel, Field
from pydantic.json_schema import SkipJsonSchema


class ExpectedResultUpdate(BaseModel):
    """Expected result update model for LLM responses"""

    alias: str = Field(description="Alias of the expected result to update")
    is_verified: bool = Field(
        description="Whether expected result is verified (true/false)"
    )
    evidence: str | None = Field(
        default=None,
        description="Evidence for the verification, or null if no evidence",
    )
    confidence: int | None = Field(
        default=None, ge=0, le=100, description="Confidence of the evidence (0-100)"
    )


class ExpectedResult(BaseModel):
    """Single expected result schema"""

    expected_result: str = Field(description="Expected result to verify")
    alias: str = Field(
        default="",
        description="Short unique identifier for the expected result (e.g. 'login_success')",
    )
    is_verified: bool = Field(
        default=False, description="Whether expected result is verified (true/false)"
    )
    evidence: str | None = Field(
        default=None,
        description="Evidence for the verification, or null if no evidence",
    )
    step_number: SkipJsonSchema[int | None] = Field(
        default=None, description="Step number where evidence was found, or null"
    )
    confidence: int | None = Field(
        default=None, ge=0, le=100, description="Confidence of the evidence (0-100)"
    )
