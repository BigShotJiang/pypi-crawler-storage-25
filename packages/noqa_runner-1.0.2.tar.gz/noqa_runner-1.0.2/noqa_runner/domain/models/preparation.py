from __future__ import annotations

from pydantic import BaseModel

from noqa_runner.domain.models.state.flow import FlowItem


class PreparationResult(BaseModel):
    flows: list[FlowItem]
    case_name: str
