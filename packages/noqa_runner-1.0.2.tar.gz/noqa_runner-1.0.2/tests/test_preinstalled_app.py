"""Tests for pre-installed app support (no build_source scenario)"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from typer.testing import CliRunner

from noqa_runner.application.run_test_session import RunnerSession
from noqa_runner.application.services.android_mobile_service import AndroidMobileService
from noqa_runner.application.services.ios_mobile_service import IOSMobileService
from noqa_runner.domain.models.platform import Platform
from noqa_runner.domain.models.state.flow import FlowItemRaw
from noqa_runner.domain.models.test_info import RunnerTestInfo
from noqa_runner.interfaces.cli.cli import app

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def make_appium_client():
    client = MagicMock()
    client.terminate_app = MagicMock()
    client.activate_app = MagicMock()
    return client


# ---------------------------------------------------------------------------
# BaseMobileService.restart_app
# ---------------------------------------------------------------------------


class TestRestartApp:
    def test_ios_restart_app_restarts(self):
        client = make_appium_client()
        service = IOSMobileService(appium_client=client, bundle_id="com.example.app")

        service.restart_app()

        client.terminate_app.assert_called_once_with("com.example.app")
        client.activate_app.assert_called_once_with("com.example.app")

    def test_android_restart_app_restarts(self):
        client = make_appium_client()
        service = AndroidMobileService(
            appium_client=client, bundle_id="com.example.app"
        )

        service.restart_app()

        client.terminate_app.assert_called_once_with("com.example.app")
        client.activate_app.assert_called_once_with("com.example.app")

    def test_install_app_does_not_call_launch(self):
        """install_app with a file path must not call terminate/activate."""
        client = make_appium_client()
        service = AndroidMobileService(
            appium_client=client, bundle_id="com.example.app"
        )

        service.install_app(
            build_source="/path/to/app.apk",
            bundle_id="com.example.app",
            app_store_id=None,
        )

        client.terminate_app.assert_not_called()
        client.activate_app.assert_not_called()


# ---------------------------------------------------------------------------
# RunnerSession.execute — bundle_id validation
# ---------------------------------------------------------------------------


class TestRunnerSessionBundleIdValidation:
    @pytest.mark.asyncio
    async def test_proceeds_when_no_build_source_but_bundle_id_provided(self):
        """When build_source=None and bundle_id is given, session should start (not raise early)."""
        session = RunnerSession()
        test = RunnerTestInfo(
            test_id="test-1", flows=[FlowItemRaw(instructions="tap login")]
        )

        mock_appium_client = MagicMock()
        mock_appium_client.__enter__ = MagicMock(return_value=mock_appium_client)
        mock_appium_client.__exit__ = MagicMock(return_value=False)
        mock_appium_client.get_screenshot = MagicMock(return_value="base64img==")
        mock_appium_client.get_resolution = MagicMock(
            return_value={"width": 390, "height": 844}
        )
        mock_appium_client.terminate_app = MagicMock()
        mock_appium_client.activate_app = MagicMock()
        mock_appium_client.dismiss_system_alert = MagicMock()

        with (
            patch(
                "noqa_runner.application.run_test_session.AppiumClient",
                return_value=mock_appium_client,
            ),
            patch(
                "noqa_runner.application.run_test_session.AppiumClient.cleanup_all_sessions"
            ),
            patch.object(
                session, "_run_single_test", new_callable=AsyncMock
            ) as mock_run,
        ):
            await session.execute(
                noqa_api_token="token",  # nosec B106
                tests=[test],
                build_source=None,
                app_bundle_id="com.example.app",
                platform=Platform.IOS,
            )

        mock_run.assert_awaited_once()
        _, kwargs = mock_run.call_args
        assert kwargs["bundle_id"] == "com.example.app"  # nosec B101


# ---------------------------------------------------------------------------
# CLI validation
# ---------------------------------------------------------------------------


class TestCLIPreinstalledValidation:
    runner = CliRunner()

    def test_error_when_no_build_source_and_no_bundle_id(self):
        result = self.runner.invoke(
            app,
            [
                "run",
                "--noqa-api-token",
                "tok",
                "--case-input-json",
                '[{"flows":[{"instructions":"tap"}]}]',
                # no --build-source, no --app-bundle-id
            ],
        )
        assert result.exit_code == 1  # nosec B101
        assert "--app-bundle-id is required" in result.output  # nosec B101

    def test_no_error_when_no_build_source_but_bundle_id_given(self):
        """CLI validation should pass; the actual test execution will fail due to no Appium,
        but exit code must NOT be 1 from our validation check."""
        with patch("noqa_runner.interfaces.cli.cli._run_async", new_callable=AsyncMock):
            result = self.runner.invoke(
                app,
                [
                    "run",
                    "--noqa-api-token",
                    "tok",
                    "--app-bundle-id",
                    "com.example.app",
                    "--case-input-json",
                    '[{"flows":[{"instructions":"tap"}]}]',
                ],
            )
        # Validation passed — _run_async was called (mocked successfully)
        assert result.exit_code == 0  # nosec B101

    def test_error_when_ios_build_has_wrong_extension(self):
        result = self.runner.invoke(
            app,
            [
                "run",
                "--noqa-api-token",
                "tok",
                "--build-source",
                "/path/to/app.zip",
                "--platform",
                "ios",
                "--case-input-json",
                '[{"flows":[{"instructions":"tap"}]}]',
            ],
        )
        assert result.exit_code != 0  # nosec B101
