"""Tests for RunnerSession.execute input validation"""

from __future__ import annotations

import pytest

from noqa_runner.application.run_test_session import RunnerSession
from noqa_runner.domain.models.app_source import AppSource
from noqa_runner.domain.models.platform import Platform
from noqa_runner.domain.models.state.flow import FlowItemRaw
from noqa_runner.domain.models.test_info import RunnerTestInfo


def make_test() -> RunnerTestInfo:
    return RunnerTestInfo(
        test_id="test-1", flows=[FlowItemRaw(instructions="tap login")]
    )


class TestExecuteValidation:
    @pytest.mark.asyncio
    async def test_error_when_no_bundle_id(self):
        session = RunnerSession()
        with pytest.raises(ValueError, match="app_bundle_id is required"):
            await session.execute(
                noqa_api_token="token",  # nosec B106
                tests=[make_test()],
                app_bundle_id=None,
            )

    @pytest.mark.asyncio
    async def test_error_when_appstore_without_app_store_id(self):
        session = RunnerSession()
        with pytest.raises(ValueError, match="app_store_id is required"):
            await session.execute(
                noqa_api_token="token",  # nosec B106
                tests=[make_test()],
                app_bundle_id="com.example.app",
                build_source=AppSource.APPSTORE,
                app_store_id=None,
            )

    @pytest.mark.asyncio
    async def test_error_when_testflight_without_app_store_id(self):
        session = RunnerSession()
        with pytest.raises(ValueError, match="app_store_id is required"):
            await session.execute(
                noqa_api_token="token",  # nosec B106
                tests=[make_test()],
                app_bundle_id="com.example.app",
                build_source=AppSource.TESTFLIGHT,
                app_store_id=None,
            )

    @pytest.mark.asyncio
    async def test_error_when_ios_file_wrong_extension(self):
        session = RunnerSession()
        with pytest.raises(ValueError, match=r"\.ipa or \.app extension"):
            await session.execute(
                noqa_api_token="token",  # nosec B106
                tests=[make_test()],
                app_bundle_id="com.example.app",
                build_source="/path/to/app.zip",
                platform=Platform.IOS,
            )

    @pytest.mark.asyncio
    async def test_error_when_android_file_wrong_extension(self):
        session = RunnerSession()
        with pytest.raises(ValueError, match=r"\.apk extension"):
            await session.execute(
                noqa_api_token="token",  # nosec B106
                tests=[make_test()],
                app_bundle_id="com.example.app",
                build_source="/path/to/app.zip",
                platform=Platform.ANDROID,
            )

    @pytest.mark.asyncio
    async def test_appstore_string_normalized_and_validates_app_store_id(self):
        """'appstore' string должен нормализоваться в AppSource и потом упасть без app_store_id"""
        session = RunnerSession()
        with pytest.raises(ValueError, match="app_store_id is required"):
            await session.execute(
                noqa_api_token="token",  # nosec B106
                tests=[make_test()],
                app_bundle_id="com.example.app",
                build_source="appstore",
                app_store_id=None,
            )
