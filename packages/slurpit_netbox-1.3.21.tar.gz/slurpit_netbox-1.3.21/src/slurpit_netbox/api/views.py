import ipaddress
import netaddr
import traceback
import logging
from datetime import timedelta

logger = logging.getLogger(__name__)

from rest_framework.routers import APIRootView
from rest_framework_bulk import BulkCreateModelMixin, BulkDestroyModelMixin
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from rest_framework import status

from django.db import transaction
from django.http import JsonResponse
from django.contrib.contenttypes.models import ContentType
from django.forms.models import model_to_dict
from django.utils import timezone
from django.utils.text import slugify
from django.db.models import Q, Count

from .serializers import (
    SlurpitPlanningSerializer, 
    SlurpitSnapshotSerializer, 
    SlurpitImportedDeviceSerializer, 
    SlurpitPrefixSerializer, 
    SlurpitInterfaceSerializer, 
    SlurpitInitIPAddressSerializer,
)
from ..validator import (
    device_validator, 
    ipam_validator, 
    interface_validator, 
    prefix_validator,
)
from ..importer import process_import, import_devices, import_plannings, start_device_import, create_sites, sync_sites, BATCH_SIZE
from ..management.choices import *
from ..views.datamapping import get_device_dict
from ..references.generic import (
    status_offline, SlurpitViewSet, status_decommissioning,
    normalize_ip_address, get_or_create_vrf, batch_process, remove_duplicates
)
from ..references.imports import * 
from ..models import (
    SlurpitPlanning, 
    SlurpitSnapshot, 
    SlurpitImportedDevice, 
    SlurpitStagedDevice,
    SlurpitMapping, 
    SlurpitInitIPAddress, 
    SlurpitInterface, 
    SlurpitPrefix,
    ensure_slurpit_tags,
)
from ..filtersets import SlurpitPlanningFilterSet, SlurpitSnapshotFilterSet, SlurpitImportedDeviceFilterSet
from ..views.setting import sync_snapshot
from ipam.models import (
    FHRPGroup, VRF, IPAddress, VLAN, Role, Prefix, VLANGroup
)
from ipam.api.serializers import PrefixSerializer
from dcim.models import Interface, Site
from dcim.forms import InterfaceForm
from ipam.forms import (
    IPAddressForm, PrefixForm
)
from tenancy.models import Tenant
from django.core.cache import cache
from dcim.api.serializers_.sites import SiteSerializer

__all__ = (
    'SlurpitPlanningViewSet',
    'SlurpitRootView',
    'SlurpitDeviceView'
)

class SlurpitRootView(APIRootView):
    """
    Slurpit API root view
    """
    def get_view_name(self):
        return 'Slurpit'
    

class DeviceViewSet(
        SlurpitViewSet,
        BulkCreateModelMixin,
        BulkDestroyModelMixin,
    ):
    queryset = SlurpitImportedDevice.objects.all()
    serializer_class = SlurpitImportedDeviceSerializer
    filterset_class = SlurpitImportedDeviceFilterSet

    @action(detail=False, methods=['delete'], url_path='delete-all')
    def delete_all(self, request, *args, **kwargs):
        with transaction.atomic():
            Device.objects.select_related('slurpitimporteddevice').update(status=status_decommissioning())
            SlurpitStagedDevice.objects.all().delete()
            SlurpitImportedDevice.objects.filter(mapped_device__isnull=True).delete()

        return Response(status=status.HTTP_204_NO_CONTENT)
    
    @action(detail=False, methods=['delete'], url_path='delete/(?P<hostname>[^/.]+)')
    def delete(self, request, *args, **kwargs):
        hostname_to_delete = kwargs.get('hostname')
        with transaction.atomic():
            to_delete = SlurpitImportedDevice.objects.filter(hostname=hostname_to_delete)
            Device.objects.filter(slurpitimporteddevice__in=to_delete).update(status=status_decommissioning())
            to_delete.filter(mapped_device__isnull=True).delete()
            SlurpitStagedDevice.objects.filter(hostname=hostname_to_delete).delete()

        return Response(status=status.HTTP_204_NO_CONTENT)
    
    @action(detail=False, methods=['post'],  url_path='sync')
    def sync(self, request):            
        errors = device_validator(request.data)
        if errors:
            return JsonResponse({'status': 'errors', 'errors': errors}, status=status.HTTP_400_BAD_REQUEST)
        
        tenant_name = request.query_params.get('tenant')
        tenant = None
        if tenant_name:
            tenant, created = Tenant.objects.get_or_create(
                name=tenant_name,
                defaults={'slug': slugify(tenant_name)}
            )
            if created:
                ensure_slurpit_tags(tenant)

        ids = [obj['id'] for obj in request.data]
        hostnames = [obj['hostname'] for obj in request.data]
        SlurpitStagedDevice.objects.filter(Q(hostname__in=hostnames) | Q(slurpit_id__in=ids)).delete()
        import_devices(request.data, tenant=tenant)        
        return JsonResponse({'status': 'success'})

    @action(detail=False, methods=['post'],  url_path='sync_start')
    def sync_start(self, request):
        sync_sites()
        threshold = timezone.now() - timedelta(days=1)
        SlurpitStagedDevice.objects.filter(created__lt=threshold).delete()
        return JsonResponse({'status': 'success'})

    @action(detail=False, methods=['post'],  url_path='sync_end')
    def sync_end(self, request):
        process_import()
        return JsonResponse({'status': 'success'})

    def create(self, request, *args, **kwargs):
        tenant_name = request.query_params.get('tenant')

        sync_sites()
        errors = device_validator(request.data)
        if errors:
            return JsonResponse({'status': 'errors', 'errors': errors}, status=400)
        if len(request.data) != 1:
            return JsonResponse({'status': 'errors', 'errors': ['List size should be 1']}, status=400)

        tenant = None
        if tenant_name:
            tenant, created = Tenant.objects.get_or_create(
                name=tenant_name,
                defaults={'slug': slugify(tenant_name)}
            )
            if created:
                ensure_slurpit_tags(tenant)

        start_device_import()
        import_devices(request.data, tenant=tenant)
        process_import(delete=False)
        
        return JsonResponse({'status': 'success'})
    
class SlurpitTestAPIView(SlurpitViewSet):
    queryset = SlurpitImportedDevice.objects.all()
    serializer_class = SlurpitImportedDeviceSerializer
    filterset_class = SlurpitImportedDeviceFilterSet

    permission_classes = [IsAuthenticated]

    @action(detail=False, methods=['get'], url_path='api')
    def api(self, request, *args, **kwargs):    
        return JsonResponse({'status': 'success'})
    
class SlurpitDeviceView(SlurpitViewSet):
    queryset = Device.objects.all()
    serializer_class = DeviceSerializer
    filterset_class = DeviceFilterSet


    @action(detail=False, methods=['get'], url_path='all')
    def all(self, request, *args, **kwargs):
        request_body = []

        devices_array = [get_device_dict(device) for device in Device.objects.all()]

        objs = SlurpitMapping.objects.all()
        
        for device in devices_array:
            row = {}
            for obj in objs:
                target_field = obj.target_field.split('|')[1]
                row[obj.source_field] = str(device[target_field])
            request_body.append(row)


        return JsonResponse({'data': request_body})
    

class SlurpitInterfaceView(SlurpitViewSet):
    queryset = SlurpitInterface.objects.all()

    def get_serializer_class(self):
        return SlurpitInterfaceSerializer
    
    def create(self, request):
        # Validate request Interface data
        errors = interface_validator(request.data)
        if errors:
            return JsonResponse({'status': 'errors', 'errors': errors}, status=400)

        try:
            # Get initial values for Interface
            enable_reconcile = True
            initial_obj = SlurpitInterface.objects.filter(name='').values('enable_reconcile', *SlurpitInterface.reconcile_fields, *SlurpitInterface.ignore_fields).first()
            initial_interface_values = {}
            interface_update_ignore_values = []

            if initial_obj:
                enable_reconcile = initial_obj['enable_reconcile']
                del initial_obj['enable_reconcile']
                initial_interface_values = {**initial_obj}

                for key in initial_interface_values.keys():
                    if key.startswith('ignore_') and initial_interface_values[key]:
                        interface_update_ignore_values.append(key)
            else:
                initial_interface_values = {
                    'type': "other",
                    'label': '',
                    'description': '',
                    'speed': 0,
                    'duplex': None,
                    'module': None,
                    'device': None,
                    'enabled': True,
                    'ip_address': None,
                    'vrf': None
                }

                # device = None

                # if initial_interface_values['device'] is not None:
                #     device = Device.objects.get(name=initial_interface_values['device'])

                # initial_interface_values['device'] = device

            total_errors = {}
            insert_data = []
            update_data = []
            total_data = []
            duplicates = []
            # Form validation 
            for record in request.data[::-1]:
                unique_interface = f'{record["name"]}/{record["hostname"]}'

                if unique_interface in duplicates:
                    continue
                duplicates.append(unique_interface)
                # Debug: Store raw record before any modifications
                record['raw_data'] = record.copy()
                device = None
                try:
                    device = Device.objects.get(name=record['hostname'])
                except: 
                    device = None

                if device is None: 
                    continue
                record['device'] = device
                del record['hostname']

                if 'status' in record:
                    if record['status'] == 'up':
                        record['enabled'] = True
                    else:
                        record['enabled'] = False
                    # Kept status for downstream usage if needed, though translation to enabled is done above

                if 'description' in record:
                    record['description'] = str(record['description'])
                
                if 'ip_address' in record and record['ip_address']:
                    record['ip_address'] = normalize_ip_address(record['ip_address'], Prefix)
                    
                new_data = {**record}
                total_data.append(new_data)

        
            if enable_reconcile:
                batch_update_qs = []
                batch_insert_qs = []

                for item in total_data:

                    # Handle VRF resolution
                    vrf = None
                    if item.get('vrf'):
                        try:
                            vrf_name = item['vrf']
                            vrf, created = VRF.objects.get_or_create(name=vrf_name, defaults={'rd': f"65000:{vrf_name}", 'description': f"Created by Slurp'it for {vrf_name}"})
                            if created:
                                from ..models import ensure_slurpit_tags
                                ensure_slurpit_tags(vrf)
                        except:
                            vrf = None
                    item['vrf'] = vrf

                    slurpit_interface_item = SlurpitInterface.objects.filter(
                        name=item.get('name'), 
                        device=item.get('device')
                    )
                    
                    if slurpit_interface_item:
                        slurpit_interface_item = slurpit_interface_item.first()

                        # Update
                        allowed_fields_with_none = {}
                        update = False

                        # Get current NetBox values for fallback
                        netbox_obj = Interface.objects.filter(
                            name=item.get('name'), 
                            device=item.get('device')
                        ).first()
                        
                        old_interface = {}
                        if netbox_obj:
                            for field in SlurpitInterface.reconcile_fields:
                                if field == 'ip_address':
                                    first_ip = netbox_obj.ip_addresses.first()
                                    old_interface[field] = str(first_ip.address) if first_ip else None
                                elif field == 'vrf':
                                    first_ip = netbox_obj.ip_addresses.first()
                                    old_interface[field] = first_ip.vrf if first_ip and first_ip.vrf else None
                                else:
                                    old_interface[field] = getattr(netbox_obj, field, None)

                        for field in SlurpitInterface.reconcile_fields:
                            field_name = f'ignore_{field}'
                            if field_name in interface_update_ignore_values:
                                continue

                            value = item.get(field)
                            current = getattr(slurpit_interface_item, field, None)
                            
                            # Normalize None and "" for comparison
                            if (current or "") != (value or ""):
                                if value is not None and value != "" or field in allowed_fields_with_none:
                                    update = True
                                    setattr(slurpit_interface_item, field, value)
                                else:
                                    # Fallback logic: 1. NetBox, 2. Global Default
                                    update = True
                                    fallback = old_interface.get(field)
                                    if fallback is None or fallback == "":
                                        fallback = initial_interface_values.get(field)
                                    
                                    if (current or "") != (fallback or ""):
                                        setattr(slurpit_interface_item, field, fallback)
                        
                        if update or slurpit_interface_item.raw_data != item.get('raw_data'):
                            slurpit_interface_item.raw_data = item.get('raw_data')
                            batch_update_qs.append(slurpit_interface_item)
                    else:
                        obj = Interface.objects.filter(
                            name=item.get('name'), 
                            device=item.get('device')
                        )
                        not_null_fields = {'label', 'device', 'module', 'type', 'duplex', 'speed', 'description', 'enabled'}

                        new_interface = {}
                        if obj:
                            obj = obj.first()
                            old_interface = {}

                            for field in SlurpitInterface.reconcile_fields:
                                field_name = f'ignore_{field}'
                                if field_name in interface_update_ignore_values:
                                    continue

                                # Handle fields that are not direct attributes of the NetBox Interface model
                                if field == 'ip_address':
                                    first_ip = obj.ip_addresses.first()
                                    old_interface[field] = str(first_ip.address) if first_ip else None
                                elif field == 'vrf':
                                    first_ip = obj.ip_addresses.first()
                                    old_interface[field] = first_ip.vrf if first_ip and first_ip.vrf else None
                                else:
                                    old_interface[field] = getattr(obj, field)

                                new_interface[field] = item.get(field, initial_interface_values.get(field))

                                if field in not_null_fields and (new_interface[field] is None or new_interface[field] == ""):
                                    new_interface[field] = old_interface[field]
                                    if (new_interface[field] is None or new_interface[field] == ""):
                                        new_interface[field] = initial_interface_values[field]

                            if new_interface == old_interface:
                                continue
                        else:
                            for field in SlurpitInterface.reconcile_fields: 
                                new_interface[field] = item.get(field, initial_interface_values.get(field))

                        batch_insert_qs.append(SlurpitInterface(
                            name = item.get('name'), 
                            raw_data = item.get('raw_data'),
                            **new_interface
                        ))
                
                batch_process(
                    batch_insert_qs,
                    BATCH_SIZE,
                    lambda batch: SlurpitInterface.objects.bulk_create(batch)
                )
                batch_process(
                    batch_update_qs,
                    BATCH_SIZE,
                    lambda batch: SlurpitInterface.objects.bulk_update(batch, fields=list(SlurpitInterface.reconcile_fields) + ['raw_data'])
                )
                remove_duplicates(SlurpitInterface, ['name', 'device_id'])
            else:                
                # Fail case
                for item in total_data:
                    new_data = {**initial_interface_values, **item}
                    obj = Interface()
                    form = InterfaceForm(data=new_data, instance=obj)
                    if form.is_valid() is False:
                        form_errors = form.errors
                        error_list_dict = {}

                        for field, errors in form_errors.items():
                            error_list_dict[field] = list(errors)

                        # Duplicate Interface
                        keys = error_list_dict.keys()
                        
                        if len(keys) ==1 and '__all__' in keys and len(error_list_dict['__all__']) == 1 and error_list_dict['__all__'][0].endswith("already exists."):
                            update_data.append(new_data)
                            continue
                        if '__all__' in keys and len(error_list_dict['__all__']) == 1 and error_list_dict['__all__'][0].endswith("already exists."):
                            del error_list_dict['__all__']
                        
                        error_key = f'{new_data["name"]}({"Global" if new_data["device"] is None else new_data["device"]})'
                        total_errors[error_key] = error_list_dict

                        return JsonResponse({'status': 'errors', 'errors': total_errors}, status=400)
                    else:
                        insert_data.append(new_data)

                # Batch Insert
                count = len(insert_data)
                offset = 0
                while offset < count:
                    batch_qs = insert_data[offset:offset + BATCH_SIZE]
                    to_import = []        
                    for interface_item in batch_qs:
                        filtered_interface_item = {k: v for k, v in interface_item.items() if not k.startswith('ignore_')}
                        to_import.append(Interface(**filtered_interface_item))
                    Interface.objects.bulk_create(to_import)
                    offset += BATCH_SIZE
                
                
                # Batch Update
                batch_update_qs = []
                for update_item in update_data:
                    item = Interface.objects.get(name=update_item['name'], device=update_item['device'])
                    
                    # Update
                    allowed_fields_with_none = {}

                    for field, value in update_item.items():
                        ignore_field = f'ignore_{field}'
                        if ignore_field in interface_update_ignore_values:
                            continue 

                        if field in SlurpitInterface.reconcile_fields and value is not None and value != "" or field in allowed_fields_with_none:
                            setattr(item, field, value)

                    batch_update_qs.append(item)

                
                count = len(batch_update_qs)
                offset = 0
                while offset < count:
                    batch_qs = batch_update_qs[offset:offset + BATCH_SIZE]
                    to_import = []        
                    for interface_item in batch_qs:
                        to_import.append(interface_item)

                    Interface.objects.bulk_update(to_import, fields=SlurpitInterface.reconcile_fields)
                    offset += BATCH_SIZE


            return JsonResponse({'status': 'success'})
        except Exception as e:
            return JsonResponse({'status': 'errors', 'errors': f"Process threw error: {e} - {traceback.format_exc()}"}, status=400)
        
class SlurpitIPAMView(SlurpitViewSet):
    queryset = IPAddress.objects.all()
    
    def get_serializer_class(self):
        return SlurpitInitIPAddressSerializer
    
    def create(self, request, *args, **kwargs):
        tenant_name = request.query_params.get('tenant')
        # Validate request IPAM data
        errors = ipam_validator(request.data)
        if errors:
            return JsonResponse({'status': 'errors', 'errors': errors}, status=400)

        tenant = None
        if tenant_name:
            tenant, created = Tenant.objects.get_or_create(
                name=tenant_name,
                defaults={'slug': slugify(tenant_name)}
            )
            if created:
                ensure_slurpit_tags(tenant)

        vrf = None
        try:
            # Get initial values for IPAM
            enable_reconcile = True
            initial_obj = SlurpitInitIPAddress.objects.filter(address=None).values('enable_reconcile', *SlurpitInitIPAddress.reconcile_fields, *SlurpitInitIPAddress.ignore_fields).first()

            initial_ipaddress_values = {}
            ipaddress_update_ignore_values = []
            
            if initial_obj:
                enable_reconcile = initial_obj['enable_reconcile']
                del initial_obj['enable_reconcile']
                initial_ipaddress_values = {**initial_obj}

                obj = SlurpitInitIPAddress.objects.filter(address=None).get()

                if initial_ipaddress_values['vrf'] is not None:
                    vrf = VRF.objects.get(pk=initial_ipaddress_values['vrf'])
                if initial_ipaddress_values['tenant'] is not None:
                    initial_ipaddress_values['tenant'] = Tenant.objects.get(pk=initial_ipaddress_values['tenant'])

                initial_ipaddress_values['vrf'] = vrf

                for key in initial_ipaddress_values.keys():
                    if key.startswith('ignore_') and initial_ipaddress_values[key]:
                        ipaddress_update_ignore_values.append(key)
                
            else:
                initial_ipaddress_values['vrf'] = None
                initial_ipaddress_values['tenant'] = None
                initial_ipaddress_values['role'] = ''
                initial_ipaddress_values['description'] = ''
                initial_ipaddress_values['dns_name'] = ''
                initial_ipaddress_values['status'] = 'active'
            
            if tenant:
                initial_ipaddress_values['tenant'] = tenant

            total_errors = {}
            insert_ips = []
            update_ips = []
            total_ips = []

            duplicates = []
            # Form validation 
            for record in request.data[::-1]:
                unique_ipaddress = f'{record["address"]}'

                # Debug: Store raw record before any modifications
                record['raw_data'] = record.copy()

                # Handle VRF
                vrf = get_or_create_vrf(record.get('vrf', ''))
                if vrf:
                    record['vrf'] = vrf
                elif 'vrf' in record:
                    del record['vrf']

                # Normalize IP address
                record['address'] = normalize_ip_address(unique_ipaddress, Prefix)

                record['stripped_address'] = str(ipaddress.ip_interface(record['address']).ip)
                if record['stripped_address'] in duplicates:
                    continue
                
                duplicates.append(record['stripped_address'])

                new_data = {**record}
                total_ips.append(new_data)



            if enable_reconcile:
                batch_update_qs = []
                batch_insert_qs = []


                for item in total_ips:
                    # Check if VRF should be ignored for lookup
                    ignore_vrf = 'ignore_vrf' in ipaddress_update_ignore_values
                    
                    if ignore_vrf:
                        slurpit_ipaddress_item = SlurpitInitIPAddress.objects.filter(address__net_host=item['stripped_address'])
                    else:
                        slurpit_ipaddress_item = SlurpitInitIPAddress.objects.filter(address__net_host=item['stripped_address'], vrf=item['vrf'])
                    
                    if slurpit_ipaddress_item:
                        slurpit_ipaddress_item = slurpit_ipaddress_item.first()

                        allowed_fields_with_none = {'status'}
                        update = item.get('address') != slurpit_ipaddress_item.address

                        # Get current NetBox values for fallback
                        ignore_vrf = 'ignore_vrf' in ipaddress_update_ignore_values
                        if ignore_vrf:
                            netbox_obj = IPAddress.objects.filter(address__net_host=item['stripped_address']).first()
                        else:
                            netbox_obj = IPAddress.objects.filter(address__net_host=item['stripped_address'], vrf=item['vrf']).first()
                        
                        old_ipaddress = {}
                        if netbox_obj:
                            for field in SlurpitInitIPAddress.reconcile_fields:
                                old_ipaddress[field] = getattr(netbox_obj, field, None)

                        for field in SlurpitInitIPAddress.reconcile_fields:
                            field_name = f'ignore_{field}'
                            if field_name in ipaddress_update_ignore_values:
                                continue

                            value = item.get(field, initial_ipaddress_values.get(field))
                            current = getattr(slurpit_ipaddress_item, field, None)
                            if (current or "") != (value or ""):
                                if value is not None and value != "" or field in allowed_fields_with_none:
                                    update = True
                                    setattr(slurpit_ipaddress_item, field, value)
                                else:
                                    # Fallback logic: 1. NetBox, 2. Global Default
                                    update = True
                                    fallback = old_ipaddress.get(field)
                                    if fallback is None or fallback == "":
                                        fallback = initial_ipaddress_values.get(field)
                                    
                                    if (current or "") != (fallback or ""):
                                        setattr(slurpit_ipaddress_item, field, fallback)

                        if update or slurpit_ipaddress_item.raw_data != item.get('raw_data'):
                            slurpit_ipaddress_item.raw_data = item.get('raw_data')
                            batch_update_qs.append(slurpit_ipaddress_item)
                    else:
                        # Check if VRF should be ignored for lookup
                        ignore_vrf = 'ignore_vrf' in ipaddress_update_ignore_values
                        
                        if ignore_vrf:
                            obj_queryset = IPAddress.objects.filter(address__net_host=item.get('stripped_address'))
                        else:
                            obj_queryset = IPAddress.objects.filter(
                                address__net_host=item.get('stripped_address'), 
                                vrf=item.get('vrf')
                            )
                        
                        not_null_fields = {'role', 'description', 'tenant', 'dns_name'}
                        new_ipaddress = {}

                        if obj_queryset.exists():
                            obj = obj_queryset.first()
                            old_ipaddress = {}
                            
                            for field in SlurpitInitIPAddress.reconcile_fields:
                                field_name = f'ignore_{field}'
                                if field_name in ipaddress_update_ignore_values:
                                    continue
                                old_ipaddress[field] = getattr(obj, field)
                                new_ipaddress[field] = item.get(field, initial_ipaddress_values.get(field))

                                if field in not_null_fields and (new_ipaddress[field] is None or new_ipaddress[field] == ""):
                                    new_ipaddress[field] = old_ipaddress[field]
                                    if (new_ipaddress[field] is None or new_ipaddress[field] == ""):
                                        new_ipaddress[field] = initial_ipaddress_values[field]

                            # Normalize null vs empty string for comparison
                            normalized_old = {k: (v or "") for k, v in old_ipaddress.items()}
                            normalized_new = {k: (v or "") for k, v in new_ipaddress.items()}

                            if normalized_new == normalized_old and item['address'] == str(obj.address):
                                continue
                        else:
                            for field in SlurpitInitIPAddress.reconcile_fields:
                                new_ipaddress[field] = item.get(field, initial_ipaddress_values.get(field))
                        
                        obj = SlurpitInitIPAddress(
                            address = item.get('address'), 
                            raw_data = item.get('raw_data'),
                            **new_ipaddress
                        )

                        batch_insert_qs.append(obj)
                
                count = len(batch_insert_qs)
                offset = 0

                while offset < count:
                    batch_qs = batch_insert_qs[offset:offset + BATCH_SIZE]
                    created_items = SlurpitInitIPAddress.objects.bulk_create(batch_qs)
                    offset += BATCH_SIZE

                count = len(batch_update_qs)
                offset = 0
                while offset < count:
                    batch_qs = batch_update_qs[offset:offset + BATCH_SIZE]
                    SlurpitInitIPAddress.objects.bulk_update(batch_qs, fields=list(SlurpitInitIPAddress.reconcile_fields) + ['raw_data'])
                    offset += BATCH_SIZE

                # Ensure we handle deduplication correctly based on VRF ignore setting
                ignore_vrf = 'ignore_vrf' in ipaddress_update_ignore_values
                unique_fields = ['address']
                if not ignore_vrf:
                    unique_fields.append('vrf')
                
                remove_duplicates(SlurpitInitIPAddress, unique_fields)
                
            else:
                # Fail case
                for item in total_ips:
                    new_data = {**initial_ipaddress_values, **item}
                    obj = IPAddress()
                    form = IPAddressForm(data=new_data, instance=obj)
                    if form.is_valid() is False:
                        form_errors = form.errors
                        error_list_dict = {}

                        for field, errors in form_errors.items():
                            error_list_dict[field] = list(errors)

                        # Duplicate IP Address
                        keys = error_list_dict.keys()
                        
                        if len(keys) ==1 and 'address' in keys and len(error_list_dict['address']) == 1 and error_list_dict['address'][0].startswith("Duplicate"):
                            update_ips.append(new_data)
                            continue
                        if 'address' in keys and len(error_list_dict['address']) == 1 and error_list_dict['address'][0].startswith("Duplicate"):
                            del error_list_dict['address']
                        
                        error_key = f'{new_data["address"]}({"Global" if new_data["vrf"] is None else new_data["vrf"]})'
                        total_errors[error_key] = error_list_dict

                        return JsonResponse({'status': 'errors', 'errors': total_errors}, status=400)
                    else:
                        insert_ips.append(new_data)

                # Batch Insert
                def process_batch(batch_qs):
                    to_import = []        
                    for ipaddress_item in batch_qs:
                        # Filter out ignore_ fields (used for UI feature) and only include valid IPAddress model fields
                        valid_fields = {'address', 'status', 'role', 'vrf', 'tenant', 'description', 'dns_name'}
                        filtered_ipaddress_item = {
                            k: v for k, v in ipaddress_item.items() 
                            if k in valid_fields and not k.startswith('ignore_')
                        }
                        to_import.append(IPAddress(**filtered_ipaddress_item))
                    IPAddress.objects.bulk_create(to_import)
                
                batch_process(insert_ips, BATCH_SIZE, process_batch)
                
                # Batch Update
                batch_update_qs = []
                # Check if VRF should be ignored for lookup
                ignore_vrf = 'ignore_vrf' in ipaddress_update_ignore_values
                
                for update_item in update_ips:
                    if ignore_vrf:
                         item = IPAddress.objects.filter(address=update_item['address']).first()
                    else:
                         item = IPAddress.objects.filter(address=update_item['address'], vrf=update_item['vrf']).first()

                    if not item:
                        continue

                    # Update
                    allowed_fields_with_none = {'status'}

                    for field, value in update_item.items():
                        ignore_field = f'ignore_{field}'
                        if ignore_field in ipaddress_update_ignore_values:
                            continue 

                        if field in SlurpitInitIPAddress.reconcile_fields and value is not None and value != "" or field in allowed_fields_with_none:
                            setattr(item, field, value)

                    batch_update_qs.append(item)

                batch_process(
                    batch_update_qs, 
                    BATCH_SIZE, 
                    lambda batch: IPAddress.objects.bulk_update(batch, fields=SlurpitInitIPAddress.reconcile_fields)
                )


            return JsonResponse({'status': 'success'})
        except Exception as e:
            return JsonResponse({'status': 'errors', 'errors': f"Process threw error: {e} - {traceback.format_exc()}"}, status=400)
        


class SlurpitPrefixView(SlurpitViewSet):
    queryset = SlurpitPrefix.objects.all()

    def get_serializer_class(self):
        return SlurpitPrefixSerializer

    def create(self, request, *args, **kwargs):
        tenant_name = request.query_params.get('tenant')
        # Validate request prefix data
        errors = prefix_validator(request.data)
        if errors:
            return JsonResponse({'status': 'errors', 'errors': errors}, status=400)

        tenant = None
        if tenant_name:
            tenant, created = Tenant.objects.get_or_create(
                name=tenant_name,
                defaults={'slug': slugify(tenant_name)}
            )
            if created:
                ensure_slurpit_tags(tenant)

        vrf = None
        role = None
        vlan = None
        
        try:
            # Get initial values for prefix
            enable_reconcile = True
            initial_obj = SlurpitPrefix.objects.filter(prefix=None).values('enable_reconcile', *SlurpitPrefix.reconcile_fields, *SlurpitPrefix.ignore_fields).first()
            initial_prefix_values = {}
            prefix_update_ignore_values = []

            if initial_obj:
                enable_reconcile = initial_obj['enable_reconcile']
                del initial_obj['enable_reconcile']
                initial_prefix_values = {**initial_obj}

                if initial_prefix_values['vrf'] is not None:
                    vrf = VRF.objects.get(pk=initial_prefix_values['vrf'])
                if initial_prefix_values['tenant'] is not None:
                    initial_prefix_values['tenant'] = Tenant.objects.get(pk=initial_prefix_values['tenant'])
                if initial_prefix_values['vlan'] is not None:
                    vlan = VLAN.objects.get(pk=initial_prefix_values['vlan'])
                if initial_prefix_values['role'] is not None:
                    role = Role.objects.get(pk=initial_prefix_values['role'])

                initial_prefix_values['vrf'] = vrf
                initial_prefix_values['vlan'] = vlan
                initial_prefix_values['role'] = role

                for key in initial_prefix_values.keys():
                    if key.startswith('ignore_') and initial_prefix_values[key]:
                        prefix_update_ignore_values.append(key)

            else:
                initial_prefix_values = {
                    'status': 'active',
                    'vrf': None,
                    'tenant': None,
                    'vlan': None,
                    'role': None,
                    'description': '',
                    'is_pool': False,
                    'mark_utilized': False
                }
            
            if tenant:
                initial_prefix_values['tenant'] = tenant

            total_errors = {}
            insert_data = []
            update_data = []
            total_data = []

            duplicates = []
            # Form validation 
            for record in request.data[::-1]:
                # Normalize prefix to avoid DataError (host bits set)
                try:
                    record['prefix'] = str(netaddr.IPNetwork(record['prefix']).cidr)
                except Exception:
                    logger.debug("Prefix normalization failed for: %s", record.get('prefix'))
                
                unique_prefix = f'{record["prefix"]}'

                if unique_prefix in duplicates:
                    continue
                duplicates.append(unique_prefix)

                # Debug: Store raw record before any modifications
                record['raw_data'] = record.copy()

                if 'vrf' in record and len(record['vrf']) > 0:
                    vrf = VRF.objects.filter(name=record['vrf'])
                    if vrf:
                        record['vrf'] = vrf.first()
                    else:
                        vrf = VRF.objects.create(name=record['vrf'])
                        record['vrf'] = vrf
                else:
                    if 'vrf' in record:
                        del record['vrf']

                new_data = {**initial_prefix_values, **record}
                total_data.append(new_data)
        
            if enable_reconcile:
                batch_update_qs = []
                batch_insert_qs = []

                # Check if VRF should be ignored for lookup
                ignore_vrf = 'ignore_vrf' in prefix_update_ignore_values

                for item in total_data:
                    if ignore_vrf:
                        slurpit_prefix_item = SlurpitPrefix.objects.filter(prefix=item['prefix'])
                    else:
                        slurpit_prefix_item = SlurpitPrefix.objects.filter(prefix=item['prefix'], vrf=item['vrf'])
                    
                    if slurpit_prefix_item:
                        slurpit_prefix_item = slurpit_prefix_item.first()

                        allowed_fields_with_none = {'status'}
                        update = False
                        for field in SlurpitPrefix.reconcile_fields:
                            field_name = f'ignore_{field}'
                            if field_name in prefix_update_ignore_values:
                                continue

                            value = item.get(field, initial_prefix_values.get(field))
                            current = getattr(slurpit_prefix_item, field, None)
                            if (current or "") != (value or ""):
                                if value is not None and value != "" or field in allowed_fields_with_none:
                                    update = True
                                    setattr(slurpit_prefix_item, field, value)
                                else:
                                    update = True
                                    value = initial_prefix_values.get(field)
                                    if (current or "") != (value or ""):
                                        setattr(slurpit_prefix_item, field, initial_prefix_values.get(field))
                        if update or slurpit_prefix_item.raw_data != item.get('raw_data'):
                            slurpit_prefix_item.raw_data = item.get('raw_data')
                            batch_update_qs.append(slurpit_prefix_item)
                    else:
                        if ignore_vrf:
                            obj_queryset = Prefix.objects.filter(prefix=item.get('prefix'))
                        else:
                            obj_queryset = Prefix.objects.filter(
                                prefix=item.get('prefix'), 
                                vrf=item.get('vrf')
                            )
                        
                        not_null_fields = {'vlan', 'tenant', 'role', 'description'}                        
                        new_prefix = {}

                        if obj_queryset.exists():
                            obj = obj_queryset.first()
                            old_prefix = {}
                            
                            for field in SlurpitPrefix.reconcile_fields:
                                field_name = f'ignore_{field}'
                                if field_name in prefix_update_ignore_values:
                                    continue
                                old_prefix[field] = getattr(obj, field)
                                new_prefix[field] = item.get(field, initial_prefix_values.get(field))

                                if field in not_null_fields and (new_prefix[field] is None or new_prefix[field] == ""):
                                    new_prefix[field] = old_prefix[field]
                                    if (new_prefix[field] is None or new_prefix[field] == ""):
                                        new_prefix[field] = initial_prefix_values[field]

                            # Normalize null vs empty string for comparison
                            normalized_old = {k: (v or "") for k, v in old_prefix.items()}
                            normalized_new = {k: (v or "") for k, v in new_prefix.items()}

                            if normalized_new == normalized_old:
                                continue
                        else:
                            for field in SlurpitPrefix.reconcile_fields:
                                new_prefix[field] = item.get(field, initial_prefix_values.get(field))

                        batch_insert_qs.append(SlurpitPrefix(
                            prefix = item.get('prefix'),
                            raw_data = item.get('raw_data'),
                            **new_prefix
                        ))
                
                count = len(batch_insert_qs)
                offset = 0

                while offset < count:
                    batch_qs = batch_insert_qs[offset:offset + BATCH_SIZE]
                    slurpit_p_list = SlurpitPrefix.objects.bulk_create(batch_qs)
                    for p in slurpit_p_list:
                        ensure_slurpit_tags(p)
                    offset += BATCH_SIZE


                count = len(batch_update_qs)
                offset = 0
                while offset < count:
                    batch_qs = batch_update_qs[offset:offset + BATCH_SIZE]
                    SlurpitPrefix.objects.bulk_update(batch_qs, fields=list(SlurpitPrefix.reconcile_fields) + ['raw_data'])
                    for p in batch_qs:
                        ensure_slurpit_tags(p)
                    offset += BATCH_SIZE

                # Ensure we handle deduplication correctly based on VRF ignore setting
                unique_fields = ['prefix']
                if not ignore_vrf:
                    unique_fields.append('vrf')
                
                remove_duplicates(SlurpitPrefix, unique_fields)

            else:                
                # Fail case
                for new_data in total_data:
                    obj = Prefix()
                    form = PrefixForm(data=new_data, instance=obj)
                    if form.is_valid() is False:
                        form_errors = form.errors
                        error_list_dict = {}

                        for field, errors in form_errors.items():
                            error_list_dict[field] = list(errors)

                        # Duplicate Prefix
                        keys = error_list_dict.keys()
                        
                        if len(keys) ==1 and 'prefix' in keys and len(error_list_dict['prefix']) == 1 and error_list_dict['prefix'][0].startswith("Duplicate"):
                            update_data.append(new_data)
                            continue
                        if 'prefix' in keys and len(error_list_dict['prefix']) == 1 and error_list_dict['prefix'][0].startswith("Duplicate"):
                            del error_list_dict['prefix']
                        
                        error_key = f'{new_data["prefix"]}({"Global" if new_data["vrf"] is None else new_data["vrf"]})'
                        total_errors[error_key] = error_list_dict

                        return JsonResponse({'status': 'errors', 'errors': total_errors}, status=400)
                    else:
                        insert_data.append(new_data)

                # Batch Insert
                count = len(insert_data)
                offset = 0
                while offset < count:
                    batch_qs = insert_data[offset:offset + BATCH_SIZE]
                    to_import = []        
                    for prefix_item in batch_qs:
                        filtered_prefix_item = {k: v for k, v in prefix_item.items() if not k.startswith('ignore_')}
                        to_import.append(Prefix(**filtered_prefix_item))
                    p_list = Prefix.objects.bulk_create(to_import)
                    for p in p_list:
                        ensure_slurpit_tags(p)
                    offset += BATCH_SIZE
                
                
                # Batch Update
                batch_update_qs = []

                for update_item in update_data:
                    item = Prefix.objects.filter(prefix=update_item['prefix'], vrf=update_item['vrf']).first()
                    
                    if not item:
                        continue
                    
                    # Update
                    allowed_fields_with_none = {'status'}

                    for field, value in update_item.items():
                        ignore_field = f'ignore_{field}'
                        if ignore_field in prefix_update_ignore_values:
                            continue 
                        
                        if field in SlurpitPrefix.reconcile_fields and value is not None and value != "" or field in allowed_fields_with_none:
                            setattr(item, field, value)
                    
                    batch_update_qs.append(item)

                
                count = len(batch_update_qs)
                offset = 0
                while offset < count:
                    batch_qs = batch_update_qs[offset:offset + BATCH_SIZE]
                    to_import = []        
                    for prefix_item in batch_qs:
                        to_import.append(prefix_item)

                    Prefix.objects.bulk_update(to_import, fields=SlurpitPrefix.reconcile_fields)
                    for p in to_import:
                        ensure_slurpit_tags(p)
                    offset += BATCH_SIZE

            return JsonResponse({'status': 'success'})
        except Exception as e:
            return JsonResponse({'status': 'errors', 'errors': f"Process threw error: {e} - {traceback.format_exc()}"}, status=400)

    @action(detail=False, methods=['get'], url_path='all')
    def all(self, request, *args, **kwargs):
        prefixes = Prefix.objects.filter(tags__name="slurpit")
        serializer = PrefixSerializer(prefixes, many=True, context={'request': request})
        
        prefixes = []
        for prefix in serializer.data:
            prefixes.append(f'{prefix["prefix"]}')
        return JsonResponse(prefixes, safe=False)

class SlurpitPlanningViewSet(
        SlurpitViewSet
    ):
    queryset = SlurpitPlanning.objects.all()
    serializer_class = SlurpitPlanningSerializer
    filterset_class = SlurpitPlanningFilterSet
    
    def get_queryset(self):
        if self.request.method == 'GET':
            # Customize this queryset to suit your requirements for GET requests
            return SlurpitPlanning.objects.filter(selected=True)
        # For other methods, use the default queryset
        return self.queryset
    
class SlurpitSiteView(SlurpitViewSet):
    queryset = Site.objects.all()
    
    def get_serializer_class(self):
        return SiteSerializer
    
    def create(self, request, *args, **kwargs):
        tenant_name = request.query_params.get('tenant')
        tenant = None
        if tenant_name:
            tenant, created = Tenant.objects.get_or_create(
                name=tenant_name,
                defaults={'slug': slugify(tenant_name)}
            )
            if created:
                ensure_slurpit_tags(tenant)
        try:
            create_sites(request.data[::-1], tenant=tenant)
        except Exception as e:
            return JsonResponse({'status': 'errors', 'errors': f"Process threw error: {e} - {traceback.format_exc()}"}, status=400)

        return JsonResponse({'status': 'success'})
        
