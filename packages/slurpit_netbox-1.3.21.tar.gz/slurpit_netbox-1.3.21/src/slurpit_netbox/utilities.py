import uuid
import hashlib
import math

def generate_random_string():
    """Generate a random string using UUID and SHA256 hashing.
    
    Creates a UUID, encodes it to bytes, hashes it with SHA256, and returns
    the hexadecimal representation. Used for generating API keys.
    
    Returns:
        Hexadecimal string (64 characters) representing the SHA256 hash
    """
    # Generate a UUID and convert it to a string
    unique_id = str(uuid.uuid4())
    
    # Get the UTF-8 encoded bytes of the UUID string
    encoded_id = unique_id.encode('utf-8')

    # Create a SHA256 hash of the encoded UUID
    sha256_hash = hashlib.sha256(encoded_id)

    # Convert the SHA256 hash to a hexadecimal string
    hashed_string = sha256_hash.hexdigest()

    return hashed_string

def format_time_ticks(timeticks):
    """Format SNMP timeticks (hundredths of a second) into human-readable format.
    
    Converts timeticks to seconds, then formats as "X days, HH:MM:SS".
    Returns None if input is not numeric or is blank.
    
    Args:
        timeticks: Timeticks value (string or number) representing hundredths of a second
    
    Returns:
        Formatted string like "5 days, 12:34:56" or None if invalid/blank
    
    Example:
        format_time_ticks("12345678")  # Returns "1 days, 10:17:36"
        format_time_ticks("")          # Returns None
        format_time_ticks(None)        # Returns None
    """
    # Guard first — if not numeric or blank, return None
    if not timeticks or timeticks == '':
        return None
    
    try:
        # Convert to float first to handle string numbers
        timeticks_float = float(timeticks)
    except (ValueError, TypeError):
        return None
    
    # Convert timeticks (hundredths of a second) to total seconds
    total_seconds = timeticks_float / 100
    
    # Calculate days, hours, minutes, seconds
    days = math.floor(total_seconds / 86400)
    hours = math.floor((total_seconds % 86400) / 3600)
    minutes = math.floor((total_seconds % 3600) / 60)
    seconds = total_seconds % 60
    
    # Format as "X days, HH:MM:SS"
    return f"{int(days)} days, {int(hours):02d}:{int(minutes):02d}:{int(seconds):02d}"