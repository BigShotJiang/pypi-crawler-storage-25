from django.db import models
from dcim.models import Device, DeviceType
from django.utils.translation import gettext_lazy as _

"""
"hostname": "SW-PLC-33.amphia.zh",
"fqdn": "10.64.144.31",
"device_os": "cisco_ios",
"device_type": "CATALYST 4510R+E",
"added": "finder",
"created": "2023-10-30 13:29:17",
"last_updated": "2023-11-01 23:02:51"
"""

from netbox.models import NetBoxModel, PrimaryModel

class SlurpitStagedDevice(NetBoxModel):
    """Temporary storage model for devices before import into NetBox.
    
    Stores device data fetched from Slurp'it API before it is processed and
    moved to SlurpitImportedDevice. Used during the import process to stage
    devices for review and onboarding.
    
    Attributes:
        slurpit_id: Unique ID from Slurp'it system
        disabled: Whether device is disabled in Slurp'it
        hostname: Device hostname (unique)
        fqdn: Fully qualified domain name
        ipv4: Management IP address
        device_os: Operating system name
        device_type: Device type/model
        site: Site name
        brand: Manufacturer brand
        serial: Device serial number
        os_version: OS version string
        snmp_uptime: SNMP uptime value
    """
    slurpit_id = models.BigIntegerField (unique=True)
    disabled = models.BooleanField(default=False)
    hostname = models.CharField(max_length=255, unique=True)
    fqdn = models.CharField(max_length=128)
    ipv4 = models.CharField(max_length=23, null=True)
    device_os = models.CharField(max_length=128)
    device_type = models.CharField(max_length=255)
    site = models.CharField(max_length=255, null=True)
    brand = models.CharField(max_length=255)
    serial = models.CharField(max_length=255, null=True)
    os_version = models.CharField(max_length=255, null=True)
    snmp_uptime = models.CharField(max_length=255, null=True)
    tags = models.TextField(null=True, blank=True)
    tenant = models.ForeignKey(to='tenancy.Tenant', on_delete=models.SET_NULL, null=True, blank=True)
    
    def __str__(self):
        return f"{self.hostname}"

    class Meta:
        ordering = ('hostname',)
        verbose_name = _('Slurpit Staged Device')
        verbose_name_plural = _('Slurpit Staged Devices')
    
    
class SlurpitImportedDevice(NetBoxModel):
    """Main model for devices imported from Slurp'it.
    
    Represents a device that has been imported from Slurp'it and is ready for
    or has been onboarded into NetBox. Links to NetBox Device and DeviceType
    objects when onboarded.
    
    Attributes:
        slurpit_id: Unique ID from Slurp'it system
        disabled: Whether device is disabled in Slurp'it
        hostname: Device hostname (unique)
        fqdn: Fully qualified domain name
        ipv4: Management IP address
        device_os: Operating system name
        device_type: Device type/model
        site: Site name
        brand: Manufacturer brand
        serial: Device serial number
        os_version: OS version string
        snmp_uptime: SNMP uptime value
        mapped_devicetype: ForeignKey to NetBox DeviceType (set when onboarded)
        mapped_device: OneToOneField to NetBox Device (set when onboarded)
    """
    slurpit_id = models.BigIntegerField(unique=True)
    disabled = models.BooleanField(default=False)
    hostname = models.CharField(max_length=255, unique=True)
    fqdn = models.CharField(max_length=128)
    ipv4 = models.CharField(max_length=23, null=True)
    device_os = models.CharField(max_length=128)
    device_type = models.CharField(max_length=255)
    site = models.CharField(max_length=255, null=True)
    brand = models.CharField(max_length=255)
    serial = models.CharField(max_length=255, null=True)
    os_version = models.CharField(max_length=255, null=True)
    snmp_uptime = models.CharField(max_length=255, null=True)
    tags = models.TextField(null=True, blank=True)
    tenant = models.ForeignKey(to='tenancy.Tenant', on_delete=models.SET_NULL, null=True, blank=True)
    mapped_devicetype = models.ForeignKey(to=DeviceType, null=True, on_delete=models.SET_NULL)
    mapped_device = models.OneToOneField(to=Device, null=True, on_delete=models.CASCADE)

    def get_absolute_url(self):
        """Return absolute URL for this object.
        
        Returns:
            URL string (currently returns '/')
        """
        return '/'
    
    def __str__(self):
        return f"{self.hostname}"
    
    @property
    def slurpit_device_type(self):
        """Get device type from mapped device's custom fields.
        
        Returns:
            'slurpit_devicetype' value from mapped_device's custom_field_data,
            or None if not present or device not mapped
        """
        if not self.mapped_device:
            return None
        return self.mapped_device.custom_field_data.get('slurpit_devicetype')

    def copy_staged_values(self, device: SlurpitStagedDevice):
        """Copy values from a SlurpitStagedDevice to this imported device.
        
        Transfers all device metadata from the staged device to this imported
        device instance. Used during the import process.
        
        Args:
            device: SlurpitStagedDevice instance to copy from
        """
        self.slurpit_id = device.slurpit_id
        self.disabled = device.disabled
        self.hostname = device.hostname
        self.ipv4 = getattr(device, "ipv4", None) or getattr(device, "address", None)
        self.fqdn = device.fqdn
        self.device_os = device.device_os
        self.device_type = device.device_type
        self.serial = device.serial
        self.os_version = device.os_version
        self.snmp_uptime = device.snmp_uptime
        self.tags = device.tags
        self.tenant = device.tenant
        self.brand = device.brand
        self.site = device.site
        self.created = device.created
        self.last_updated = device.last_updated

    class Meta:
        ordering = ('hostname',)
        verbose_name = _('Slurpit Imported Device')
        verbose_name_plural = _('Slurpit Imported Devices')

    
