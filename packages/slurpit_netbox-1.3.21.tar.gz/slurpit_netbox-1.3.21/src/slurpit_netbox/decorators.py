from functools import wraps
from .models import SlurpitSetting, ensure_slurpit_tags, create_custom_fields
from django.contrib import messages
from django.shortcuts import redirect

def slurpit_plugin_registered(view_func):
    """Decorator to check plugin configuration before allowing view access.
    
    Validates that the plugin is properly configured (API key generated for push mode,
    server settings configured for pull mode) and displays warning messages if not.
    Also ensures custom fields and tags are created.
    
    Args:
        view_func: View function to wrap
    
    Returns:
        Wrapped view function that performs configuration checks
    """
    @wraps(view_func)
    def _wrapped_view(request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect('login')

        create_custom_fields()
        ensure_slurpit_tags()
        
        paths = [
            'plugins/slurpit/settings/',
            'plugins/slurpit/devices/',
            'plugins/slurpit/data_mapping/',
            'plugins/slurpit/reconcile/',
        ]

        for path in paths:
            if path in request.path and request.method == 'GET':
                # Ignore test case
                test_param = request.GET.get('test',None)
                if test_param == 'test':
                    continue
                
                appliance_type_param = request.GET.get('appliance_type', None)
                if appliance_type_param:
                    continue

                reset_param = request.GET.get('reset', None)
                if reset_param:
                    continue
                
                try:
                    setting = SlurpitSetting.objects.get()
                    server_url = setting.server_url
                    api_key = setting.api_key
                    appliance_type = setting.appliance_type
                    connection_status = setting.connection_status

                    from account.models import UserToken
                    if (appliance_type == 'push' or appliance_type == 'both') and not UserToken.objects.exists():
                        messages.warning(request, "To use the Slurp'it plugin, it is necessary to first generate a Plugin API Key on the Setting Page.")
                    elif (appliance_type == 'pull' or appliance_type == 'both') and connection_status != 'connected':
                        messages.warning(request, "To use the Slurp'it plugin, you should first configure the server settings. Go to settings and configure the Slurp'it server in the parameter section.")
                    elif appliance_type == '':
                        messages.warning(request, "To use the Slurp'it plugin, it is necessary to first select the Data synchronization Type on the Setting Page.")
                except Exception as e:
                    setting = None
                    messages.warning(request, "To use the Slurp'it plugin, it is necessary to first select the Data synchronization Type on the Setting Page.")

                return view_func(request, *args, **kwargs)

        return view_func(request, *args, **kwargs)
    return _wrapped_view