from datetime import datetime

def device_validator(data):
    """Validate device data structure and required fields.
    
    Validates that data is a list and each entry contains required fields with
    correct formats. Checks date formats and disabled field values.
    
    Args:
        data: List of device dictionaries to validate
    
    Returns:
        List of error messages (empty if validation passes)
    
    Required fields:
        - id: Device ID
        - hostname: Device hostname
        - fqdn: Fully qualified domain name
        - device_os: Operating system
        - device_type: Device type/model
        - brand: Manufacturer brand
        - disabled: '0' or '1'
        - createddate: Date in format 'YYYY-MM-DD HH:MM:SS'
        - changeddate: Date in format 'YYYY-MM-DD HH:MM:SS'
    """
    required_fields = ['id', 'hostname', 'fqdn', 'device_os', 
                       'device_type', 'brand', 'disabled', 
                       'createddate', 'changeddate']

    if not isinstance(data, list):
        return ["Should be a list"]
    
    errors = []
    
    for entry in data:
        for field in required_fields:
            if field not in entry or entry[field] is None:
                errors.append(f"Field {field} is missing or was None - {entry}")
            else:
                # Further validation logic for each field could go here,
                # like checking that 'last_seen' is a valid datetime for instance:
                if field in ['createddate', 'changeddate']:
                    try:
                        # Assuming the dates are in ISO format (YYYY-MM-DD HH:MM:SS)
                        datetime.strptime(entry[field], '%Y-%m-%d %H:%M:%S')
                    except ValueError:
                        errors.append(f"Invalid date format for {field} in entry with id {entry.get('id', 'unknown')}")

                if field == 'disabled' and entry[field] not in ['0', '1']:
                    errors.append(f"Invalid value for disabled in entry with id {entry.get('id', 'unknown')}")
    
    return errors

def ipam_validator(data):
    """Validate IPAM (IP address) data structure.
    
    Validates that data is a list and each entry contains the required 'address' field.
    
    Args:
        data: List of IP address dictionaries to validate
    
    Returns:
        List of error messages (empty if validation passes)
    
    Required fields:
        - address: IP address string
    """
    required_fields = ['address']
    
    if not isinstance(data, list):
        return ["Should be a list"]
    
    errors = []
    for entry in data:
        for field in required_fields:
            if field not in entry or entry[field] is None:
                errors.append(f"Field {field} is missing or was None - {entry}")

    return errors

def interface_validator(data):
    """Validate interface data structure.
    
    Validates that data is a list and each entry contains required fields.
    
    Args:
        data: List of interface dictionaries to validate
    
    Returns:
        List of error messages (empty if validation passes)
    
    Required fields:
        - name: Interface name
        - hostname: Device hostname
    """
    required_fields = ['name', 'hostname']
    
    if not isinstance(data, list):
        return ["Should be a list"]
    
    errors = []
    for entry in data:
        for field in required_fields:
            if field not in entry or entry[field] is None:
                errors.append(f"Field {field} is missing or was None - {entry}")

    return errors

def prefix_validator(data):
    """Validate prefix data structure.
    
    Validates that data is a list and each entry contains the required 'prefix' field.
    
    Args:
        data: List of prefix dictionaries to validate
    
    Returns:
        List of error messages (empty if validation passes)
    
    Required fields:
        - prefix: Network prefix in CIDR notation
    """
    required_fields = ['prefix']
    
    if not isinstance(data, list):
        return ["Should be a list"]
    
    errors = []
    for entry in data:
        for field in required_fields:
            if field not in entry or entry[field] is None:
                errors.append(f"Field {field} is missing or was None - {entry}")

    return errors
