import django.contrib.postgres.fields
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('slurpit_netbox', '0030_netbox_45_compatibility'),
    ]

    operations = [
        migrations.AddField(
            model_name='slurpitinterface',
            name='cable_connector',
            field=models.PositiveSmallIntegerField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name='slurpitinterface',
            name='cable_positions',
            field=django.contrib.postgres.fields.ArrayField(base_field=models.PositiveSmallIntegerField(), blank=True, null=True, size=None),
        ),
    ]
