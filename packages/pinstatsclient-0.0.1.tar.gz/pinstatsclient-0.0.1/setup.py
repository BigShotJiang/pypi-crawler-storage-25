from setuptools import setup; setup(name='pinstatsclient', version='0.0.1', description='test')
