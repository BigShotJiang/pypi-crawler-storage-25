"""Tests for the StorageClient unified interface."""

from uuid import UUID

import pytest

from huitzo_sdk.storage import InMemoryBackend, StorageClient, StorageNamespace


@pytest.fixture()
def namespace() -> StorageNamespace:
    return StorageNamespace(
        tenant_id=UUID("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"),
        user_id=UUID("bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb"),
        pack_id="my-pack",
    )


@pytest.fixture()
def backend() -> InMemoryBackend:
    return InMemoryBackend()


@pytest.fixture()
def client(backend: InMemoryBackend, namespace: StorageNamespace) -> StorageClient:
    return StorageClient(backend, namespace)


USER_PREFIX = (
    "tenant:aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa:"
    "user:bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb:"
    "pack:my-pack:"
)
TENANT_PREFIX = "tenant:aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa:"
PACK_PREFIX = "tenant:aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa:pack:my-pack:"


class TestStorageClientProperties:
    def test_namespace_accessible(self, client: StorageClient, namespace: StorageNamespace) -> None:
        assert client.namespace is namespace

    def test_backend_accessible(self, client: StorageClient, backend: InMemoryBackend) -> None:
        assert client.backend is backend

    def test_scope_key_delegates(self, client: StorageClient) -> None:
        assert client.scope_key("k") == f"{USER_PREFIX}k"
        assert client.scope_key("k", "tenant") == f"{TENANT_PREFIX}k"

    def test_scope_prefix_delegates(self, client: StorageClient) -> None:
        assert client.scope_prefix("cache-") == f"{USER_PREFIX}cache-"


class TestStorageClientCore:
    @pytest.mark.asyncio
    async def test_save_and_get(self, client: StorageClient) -> None:
        await client.save("settings", {"theme": "dark"})
        assert await client.get("settings") == {"theme": "dark"}

    @pytest.mark.asyncio
    async def test_get_missing_returns_default(self, client: StorageClient) -> None:
        assert await client.get("missing") is None
        assert await client.get("missing", default=42) == 42

    @pytest.mark.asyncio
    async def test_save_returns_scoped_key(self, client: StorageClient) -> None:
        result = await client.save("k", "v")
        assert result == f"{USER_PREFIX}k"

    @pytest.mark.asyncio
    async def test_delete(self, client: StorageClient) -> None:
        await client.save("k", "v")
        assert await client.delete("k") is True
        assert await client.get("k") is None

    @pytest.mark.asyncio
    async def test_delete_missing(self, client: StorageClient) -> None:
        assert await client.delete("nope") is False

    @pytest.mark.asyncio
    async def test_exists(self, client: StorageClient) -> None:
        assert await client.exists("k") is False
        await client.save("k", "v")
        assert await client.exists("k") is True

    @pytest.mark.asyncio
    async def test_list(self, client: StorageClient) -> None:
        await client.save("a", 1)
        await client.save("b", 2)
        keys = await client.list()
        assert len(keys) == 2
        assert all(k.startswith(USER_PREFIX) for k in keys)

    @pytest.mark.asyncio
    async def test_list_with_prefix(self, client: StorageClient) -> None:
        await client.save("cache-x", 1)
        await client.save("cache-y", 2)
        await client.save("other-z", 3)
        keys = await client.list("cache-")
        assert len(keys) == 2

    @pytest.mark.asyncio
    async def test_list_pagination(self, client: StorageClient) -> None:
        for i in range(5):
            await client.save(f"k{i}", i)
        page1 = await client.list(limit=2)
        page2 = await client.list(limit=2, offset=2)
        assert len(page1) == 2
        assert len(page2) == 2


class TestStorageClientScopes:
    @pytest.mark.asyncio
    async def test_user_scope_default(
        self, client: StorageClient, backend: InMemoryBackend
    ) -> None:
        await client.save("k", "v")
        assert await backend.exists(f"{USER_PREFIX}k") is True

    @pytest.mark.asyncio
    async def test_tenant_scope(self, client: StorageClient, backend: InMemoryBackend) -> None:
        await client.save("shared", "data", scope="tenant")
        assert await backend.exists(f"{TENANT_PREFIX}shared") is True
        assert await client.get("shared", scope="tenant") == "data"

    @pytest.mark.asyncio
    async def test_pack_scope(self, client: StorageClient, backend: InMemoryBackend) -> None:
        await client.save("cache", "hit", scope="pack")
        assert await backend.exists(f"{PACK_PREFIX}cache") is True
        assert await client.get("cache", scope="pack") == "hit"

    @pytest.mark.asyncio
    async def test_invalid_scope_raises(self, client: StorageClient) -> None:
        with pytest.raises(ValueError, match="Invalid scope"):
            await client.save("k", "v", scope="global")

    @pytest.mark.asyncio
    async def test_scopes_are_isolated(self, client: StorageClient) -> None:
        await client.save("k", "user-val", scope="user")
        await client.save("k", "tenant-val", scope="tenant")
        assert await client.get("k", scope="user") == "user-val"
        assert await client.get("k", scope="tenant") == "tenant-val"


class TestStorageClientBatch:
    @pytest.mark.asyncio
    async def test_save_many(self, client: StorageClient) -> None:
        await client.save_many({"a": 1, "b": 2, "c": 3})
        assert await client.get("a") == 1
        assert await client.get("b") == 2
        assert await client.get("c") == 3

    @pytest.mark.asyncio
    async def test_get_many_returns_original_keys(self, client: StorageClient) -> None:
        await client.save("a", 1)
        await client.save("b", 2)
        result = await client.get_many(["a", "b", "missing"])
        assert result == {"a": 1, "b": 2, "missing": None}

    @pytest.mark.asyncio
    async def test_delete_many(self, client: StorageClient) -> None:
        await client.save_many({"a": 1, "b": 2, "c": 3})
        count = await client.delete_many(["a", "c", "missing"])
        assert count == 2
        assert await client.exists("b") is True
        assert await client.exists("a") is False


class TestStorageClientAdvanced:
    @pytest.mark.asyncio
    async def test_save_with_ttl(self, client: StorageClient) -> None:
        await client.save("temp", "data", ttl=3600)
        assert await client.get("temp") == "data"

    @pytest.mark.asyncio
    async def test_save_with_metadata(self, client: StorageClient) -> None:
        await client.save("doc", {"title": "Q1"}, metadata={"type": "report"})
        results = await client.query(metadata={"type": "report"})
        assert len(results) == 1
        assert results[0]["value"] == {"title": "Q1"}

    @pytest.mark.asyncio
    async def test_query_by_prefix(self, client: StorageClient) -> None:
        await client.save("report-1", {"title": "Q1"})
        await client.save("report-2", {"title": "Q2"})
        await client.save("other-1", {"title": "X"})
        results = await client.query("report-")
        assert len(results) == 2

    @pytest.mark.asyncio
    async def test_transaction_commit(self, client: StorageClient) -> None:
        await client.save("balance", 100)
        async with client.transaction():
            await client.save("balance", 50)
            await client.save("transferred", 50)
        assert await client.get("balance") == 50
        assert await client.get("transferred") == 50

    @pytest.mark.asyncio
    async def test_transaction_rollback(self, client: StorageClient) -> None:
        await client.save("balance", 100)
        with pytest.raises(ValueError, match="insufficient"):
            async with client.transaction():
                await client.save("balance", -10)
                raise ValueError("insufficient")
        assert await client.get("balance") == 100


class TestStorageClientKeyValidation:
    @pytest.mark.asyncio
    async def test_empty_key_rejected(self, client: StorageClient) -> None:
        with pytest.raises(ValueError, match="must not be empty"):
            await client.save("", "v")

    @pytest.mark.asyncio
    async def test_colon_in_key_rejected(self, client: StorageClient) -> None:
        with pytest.raises(ValueError, match="Invalid storage key"):
            await client.save("bad:key", "v")

    @pytest.mark.asyncio
    async def test_long_key_rejected(self, client: StorageClient) -> None:
        with pytest.raises(ValueError, match="exceeds"):
            await client.save("x" * 257, "v")

    @pytest.mark.asyncio
    async def test_max_length_key_accepted(self, client: StorageClient) -> None:
        await client.save("x" * 256, "v")
        assert await client.get("x" * 256) == "v"

    @pytest.mark.asyncio
    async def test_valid_chars_accepted(self, client: StorageClient) -> None:
        await client.save("my-key_v2/sub.path", "v")
        assert await client.get("my-key_v2/sub.path") == "v"

    @pytest.mark.asyncio
    async def test_batch_validates_keys(self, client: StorageClient) -> None:
        with pytest.raises(ValueError):
            await client.save_many({"good": 1, "bad:key": 2})
        with pytest.raises(ValueError):
            await client.get_many(["good", "bad:key"])
        with pytest.raises(ValueError):
            await client.delete_many(["good", "bad:key"])


class TestStorageClientTenantIsolation:
    @pytest.mark.asyncio
    async def test_different_tenants_isolated(self, backend: InMemoryBackend) -> None:
        ns1 = StorageNamespace(
            tenant_id=UUID("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"),
            user_id=UUID("bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb"),
            pack_id="my-pack",
        )
        ns2 = StorageNamespace(
            tenant_id=UUID("cccccccc-cccc-cccc-cccc-cccccccccccc"),
            user_id=UUID("bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb"),
            pack_id="my-pack",
        )
        client1 = StorageClient(backend, ns1)
        client2 = StorageClient(backend, ns2)

        await client1.save("secret", "tenant-a-data")
        await client2.save("secret", "tenant-c-data")

        assert await client1.get("secret") == "tenant-a-data"
        assert await client2.get("secret") == "tenant-c-data"
