"""Tests for SSH integration client (SSHClient, SSHResult, allowed-targets enforcement)."""

from __future__ import annotations

from unittest.mock import AsyncMock
from uuid import uuid4

import pytest

from huitzo_sdk.errors import SSHError
from huitzo_sdk.integrations.ssh import (
    MAX_COMMAND_LENGTH,
    SSHClient,
    SSHResult,
    SSHTargetConfig,
)


def _make_target(
    name: str = "test-server", known_hosts: str | None = "host key"
) -> SSHTargetConfig:
    return SSHTargetConfig(
        target_id=uuid4(),
        name=name,
        host="10.0.1.50",
        port=22,
        username="huitzo",
        auth_method="key",
        private_key="-----BEGIN OPENSSH PRIVATE KEY-----\nfake\n-----END OPENSSH PRIVATE KEY-----",
        password=None,
        known_hosts=known_hosts,
    )


class TestSSHClient:
    @pytest.fixture
    def backend(self) -> AsyncMock:
        mock = AsyncMock()
        mock.run.return_value = SSHResult(stdout="ok\n", stderr="", exit_code=0)
        return mock

    @pytest.fixture
    def targets(self) -> dict[str, SSHTargetConfig]:
        return {
            "gpu-cluster": _make_target("gpu-cluster"),
            "web-server": _make_target("web-server"),
        }

    @pytest.fixture
    def client(self, backend: AsyncMock, targets: dict[str, SSHTargetConfig]) -> SSHClient:
        return SSHClient(
            _backend=backend,
            _targets=targets,
            _allowed_target_names=["gpu-cluster", "web-server"],
        )

    @pytest.fixture
    def wildcard_client(self, backend: AsyncMock, targets: dict[str, SSHTargetConfig]) -> SSHClient:
        return SSHClient(
            _backend=backend,
            _targets=targets,
            _allowed_target_names=["*"],
        )

    # ── Basic execution ────────────────────────────────────────────────

    @pytest.mark.asyncio
    async def test_run_success(self, client: SSHClient, backend: AsyncMock) -> None:
        result = await client.run("gpu-cluster", "nvidia-smi")
        assert result.stdout == "ok\n"
        assert result.exit_code == 0
        backend.run.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_run_passes_timeout(self, client: SSHClient, backend: AsyncMock) -> None:
        await client.run("gpu-cluster", "uptime", timeout=120)
        call_kwargs = backend.run.call_args.kwargs
        assert call_kwargs["timeout"] == 120

    @pytest.mark.asyncio
    async def test_run_default_timeout(self, client: SSHClient, backend: AsyncMock) -> None:
        await client.run("gpu-cluster", "uptime")
        call_kwargs = backend.run.call_args.kwargs
        assert call_kwargs["timeout"] == 30

    # ── Wildcard access ────────────────────────────────────────────────

    @pytest.mark.asyncio
    async def test_wildcard_allows_any_target(
        self, wildcard_client: SSHClient, backend: AsyncMock
    ) -> None:
        result = await wildcard_client.run("gpu-cluster", "ls")
        assert result.exit_code == 0

    # ── Allowed-targets enforcement ────────────────────────────────────

    @pytest.mark.asyncio
    async def test_target_not_allowed(self, backend: AsyncMock) -> None:
        client = SSHClient(
            _backend=backend,
            _targets={"gpu-cluster": _make_target("gpu-cluster")},
            _allowed_target_names=["other-server"],
        )
        with pytest.raises(SSHError, match="not allowed"):
            await client.run("gpu-cluster", "ls")
        backend.run.assert_not_awaited()

    @pytest.mark.asyncio
    async def test_empty_allowed_list_denies_all(self, backend: AsyncMock) -> None:
        client = SSHClient(
            _backend=backend,
            _targets={"gpu-cluster": _make_target("gpu-cluster")},
            _allowed_target_names=[],
        )
        with pytest.raises(SSHError, match="no SSH targets configured"):
            await client.run("gpu-cluster", "ls")
        backend.run.assert_not_awaited()

    @pytest.mark.asyncio
    async def test_allowed_check_before_lookup(self, backend: AsyncMock) -> None:
        """_check_allowed runs before target lookup — even if target doesn't exist."""
        client = SSHClient(
            _backend=backend,
            _targets={},  # empty targets dict
            _allowed_target_names=["only-this"],
        )
        with pytest.raises(SSHError, match="not allowed"):
            await client.run("other-target", "ls")

    # ── Target not found ───────────────────────────────────────────────

    @pytest.mark.asyncio
    async def test_target_not_found(self, backend: AsyncMock) -> None:
        client = SSHClient(
            _backend=backend,
            _targets={},
            _allowed_target_names=["*"],
        )
        with pytest.raises(SSHError, match="not found"):
            await client.run("nonexistent", "ls")

    # ── Command validation ─────────────────────────────────────────────

    @pytest.mark.asyncio
    async def test_command_too_long(self, client: SSHClient, backend: AsyncMock) -> None:
        long_command = "x" * (MAX_COMMAND_LENGTH + 1)
        with pytest.raises(SSHError, match="maximum length"):
            await client.run("gpu-cluster", long_command)
        backend.run.assert_not_awaited()

    @pytest.mark.asyncio
    async def test_command_with_null_bytes(self, client: SSHClient, backend: AsyncMock) -> None:
        with pytest.raises(SSHError, match="null bytes"):
            await client.run("gpu-cluster", "ls\x00-la")
        backend.run.assert_not_awaited()

    @pytest.mark.asyncio
    async def test_command_at_max_length_allowed(
        self, client: SSHClient, backend: AsyncMock
    ) -> None:
        exact_command = "x" * MAX_COMMAND_LENGTH
        await client.run("gpu-cluster", exact_command)
        backend.run.assert_awaited_once()


class TestSSHResult:
    def test_frozen(self) -> None:
        result = SSHResult(stdout="out", stderr="err", exit_code=0)
        with pytest.raises(AttributeError):
            result.stdout = "changed"  # type: ignore[misc]

    def test_fields(self) -> None:
        result = SSHResult(stdout="hello\n", stderr="warn\n", exit_code=1)
        assert result.stdout == "hello\n"
        assert result.stderr == "warn\n"
        assert result.exit_code == 1


class TestSSHTargetConfig:
    def test_frozen(self) -> None:
        config = _make_target()
        with pytest.raises(AttributeError):
            config.host = "changed"  # type: ignore[misc]

    def test_fields(self) -> None:
        config = _make_target("my-server")
        assert config.name == "my-server"
        assert config.host == "10.0.1.50"
        assert config.port == 22
        assert config.auth_method == "key"
