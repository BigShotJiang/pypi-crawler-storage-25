"""
Module: tests.test_llm_chat
Description: Tests for LLMClient.chat() method.

Implements:
    - docs/sdk/integrations.md#llm-integration
"""

from __future__ import annotations

from typing import Any, AsyncIterator
from unittest.mock import AsyncMock

import pytest

from huitzo_sdk.integrations.llm import LLMClient


class ChatBackend:
    """Backend that implements chat()."""

    def __init__(self) -> None:
        self.chat_mock = AsyncMock(return_value="chat response")
        self.complete_mock = AsyncMock(return_value="complete response")

    async def complete(self, **kwargs: Any) -> str:
        return await self.complete_mock(**kwargs)

    async def chat(self, **kwargs: Any) -> str:
        return await self.chat_mock(**kwargs)

    def stream(self, **kwargs: Any) -> AsyncIterator[str]:
        raise NotImplementedError


@pytest.mark.asyncio
async def test_chat_delegates_to_backend() -> None:
    backend = ChatBackend()
    client = LLMClient(_backend=backend)

    result = await client.chat(
        [{"role": "user", "content": "hello"}],
        model="claude-sonnet-4-20250514",
    )

    assert result == "chat response"
    backend.chat_mock.assert_called_once()
    call_kwargs = backend.chat_mock.call_args.kwargs
    assert call_kwargs["messages"] == [{"role": "user", "content": "hello"}]
    assert call_kwargs["model"] == "claude-sonnet-4-20250514"


@pytest.mark.asyncio
async def test_chat_default_model() -> None:
    backend = ChatBackend()
    client = LLMClient(_backend=backend)

    await client.chat([{"role": "user", "content": "hi"}])

    call_kwargs = backend.chat_mock.call_args.kwargs
    assert call_kwargs["model"] == "claude-sonnet-4-20250514"
