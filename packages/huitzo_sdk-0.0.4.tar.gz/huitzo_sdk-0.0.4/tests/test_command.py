"""Tests for the @command decorator and HuitzoCommand base class."""

import asyncio
import time
from uuid import uuid4

import pytest
from pydantic import BaseModel

from huitzo_sdk import Context, HuitzoCommand, command
from huitzo_sdk.errors import CommandError, CommandTimeoutError, ConfigurationError
from huitzo_sdk.types import CommandMetadata


class AddArgs(BaseModel):
    a: int
    b: int


class GreetArgs(BaseModel):
    name: str
    greeting: str = "Hello"


def _make_ctx(**kwargs) -> Context:
    """Create a Context with real identity for testing."""
    defaults = {
        "user_id": uuid4(),
        "tenant_id": uuid4(),
    }
    defaults.update(kwargs)
    return Context(**defaults)


# --- Decorator tests ---


class TestCommandDecorator:
    def test_stores_metadata(self) -> None:
        @command("add", namespace="math")
        async def add(args: AddArgs, ctx: Context) -> dict:
            return {"result": args.a + args.b}

        meta: CommandMetadata = add._huitzo_command  # type: ignore[attr-defined]
        assert meta.name == "add"
        assert meta.namespace == "math"
        assert meta.version == "1.0.0"
        assert meta.timeout == 60

    def test_stores_custom_metadata(self) -> None:
        @command(
            "analyze",
            namespace="data",
            version="2.0.0",
            timeout=3600,
            queue="long",
            output_format="json",
            description="Analyze data",
        )
        async def analyze(args: AddArgs, ctx: Context) -> dict:
            return {}

        meta: CommandMetadata = analyze._huitzo_command  # type: ignore[attr-defined]
        assert meta.version == "2.0.0"
        assert meta.timeout == 3600
        assert meta.queue == "long"
        assert meta.output_format == "json"
        assert meta.description == "Analyze data"

    def test_retries_param_accepted(self) -> None:
        """retries parameter is accepted per docs/sdk/commands.md."""

        @command("test", namespace="ns", retries=5, retry_backoff=2.0, retry_max_wait=120)
        async def test_cmd(args: AddArgs, ctx: Context) -> dict:
            return {}

        meta = test_cmd._huitzo_command
        assert meta.retries == 5
        assert meta.retry_backoff == 2.0
        assert meta.retry_max_wait == 120

    @pytest.mark.asyncio
    async def test_async_execution(self) -> None:
        @command("add", namespace="math")
        async def add(args: AddArgs, ctx: Context) -> dict:
            return {"result": args.a + args.b}

        ctx = _make_ctx(command_name="add", namespace="math")
        result = await add(AddArgs(a=2, b=3), ctx)
        assert result == {"result": 5}

    @pytest.mark.asyncio
    async def test_sync_execution(self) -> None:
        @command("greet", namespace="example")
        def greet(args: GreetArgs, ctx: Context) -> str:
            return f"{args.greeting}, {args.name}!"

        ctx = _make_ctx(command_name="greet", namespace="example")
        result = await greet(GreetArgs(name="World"), ctx)
        assert result == "Hello, World!"

    @pytest.mark.asyncio
    async def test_dict_args_validated(self) -> None:
        @command("add", namespace="math")
        async def add(args: AddArgs, ctx: Context) -> dict:
            return {"result": args.a + args.b}

        ctx = _make_ctx()
        result = await add({"a": 10, "b": 20}, ctx)
        assert result == {"result": 30}

    @pytest.mark.asyncio
    async def test_invalid_dict_args_rejected(self) -> None:
        @command("add", namespace="math")
        async def add(args: AddArgs, ctx: Context) -> dict:
            return {"result": args.a + args.b}

        ctx = _make_ctx()
        with pytest.raises(Exception):  # Pydantic ValidationError
            await add({"a": "not_a_number", "b": 20}, ctx)

    @pytest.mark.asyncio
    async def test_context_injected_raises_when_none(self) -> None:
        """Calling a command with ctx=None must raise ConfigurationError."""

        @command("whoami", namespace="utils")
        async def whoami(args: GreetArgs, ctx: Context) -> dict:
            return {"command": ctx.command_name, "ns": ctx.namespace}

        with pytest.raises(ConfigurationError, match="Context must be provided"):
            await whoami(GreetArgs(name="test"))

    @pytest.mark.asyncio
    async def test_explicit_context(self) -> None:
        @command("test", namespace="demo")
        async def test_cmd(args: GreetArgs, ctx: Context) -> str:
            return ctx.correlation_id

        ctx = _make_ctx(correlation_id="custom-id")
        result = await test_cmd(GreetArgs(name="x"), ctx)
        assert result == "custom-id"


# --- Timeout enforcement tests ---


class TestTimeoutEnforcement:
    @pytest.mark.asyncio
    async def test_async_command_timeout(self) -> None:
        @command("slow", namespace="test", timeout=1)
        async def slow_cmd(args: AddArgs, ctx: Context) -> dict:
            await asyncio.sleep(5)
            return {}

        ctx = _make_ctx()
        with pytest.raises(CommandTimeoutError) as exc_info:
            await slow_cmd(AddArgs(a=1, b=2), ctx)
        assert exc_info.value.timeout_seconds == 1

    @pytest.mark.asyncio
    async def test_async_command_completes_within_timeout(self) -> None:
        @command("fast", namespace="test", timeout=5)
        async def fast_cmd(args: AddArgs, ctx: Context) -> dict:
            return {"result": args.a + args.b}

        ctx = _make_ctx()
        result = await fast_cmd(AddArgs(a=1, b=2), ctx)
        assert result == {"result": 3}

    @pytest.mark.asyncio
    async def test_sync_command_timeout(self) -> None:
        @command("slow-sync", namespace="test", timeout=1)
        def slow_sync(args: AddArgs, ctx: Context) -> dict:
            time.sleep(5)
            return {}

        ctx = _make_ctx()
        with pytest.raises(CommandTimeoutError):
            await slow_sync(AddArgs(a=1, b=2), ctx)

    @pytest.mark.asyncio
    async def test_timeout_zero_means_no_limit(self) -> None:
        @command("unlimited", namespace="test", timeout=0)
        async def unlimited_cmd(args: AddArgs, ctx: Context) -> dict:
            await asyncio.sleep(0.1)
            return {"done": True}

        ctx = _make_ctx()
        result = await unlimited_cmd(AddArgs(a=1, b=2), ctx)
        assert result == {"done": True}


# --- Class-based command tests ---


class TestHuitzoCommand:
    @pytest.mark.asyncio
    async def test_execute(self) -> None:
        class AddCommand(HuitzoCommand):
            name = "add"
            namespace = "math"

            async def execute(self, args: AddArgs, ctx: Context) -> dict:
                return {"result": args.a + args.b}

        cmd = AddCommand()
        ctx = _make_ctx()
        result = await cmd.run(AddArgs(a=5, b=7), ctx)
        assert result == {"result": 12}

    @pytest.mark.asyncio
    async def test_ctx_none_raises_configuration_error(self) -> None:
        class MyCommand(HuitzoCommand):
            name = "test"
            namespace = "demo"

            async def execute(self, args: AddArgs, ctx: Context) -> dict:
                return {}

        cmd = MyCommand()
        with pytest.raises(ConfigurationError, match="Context must be provided"):
            await cmd.run(AddArgs(a=1, b=2))

    @pytest.mark.asyncio
    async def test_configure_hook(self) -> None:
        class SlowCommand(HuitzoCommand):
            name = "slow"
            namespace = "tasks"

            def configure(self) -> None:
                self.timeout = 7200
                self.queue = "long"

            async def execute(self, args: AddArgs, ctx: Context) -> dict:
                return {}

        cmd = SlowCommand()
        assert cmd.metadata.timeout == 7200
        assert cmd.metadata.queue == "long"

    @pytest.mark.asyncio
    async def test_lifecycle_hooks(self) -> None:
        events: list[str] = []

        class TrackedCommand(HuitzoCommand):
            name = "tracked"
            namespace = "test"

            def on_start(self, args: AddArgs) -> None:  # type: ignore[override]
                events.append("start")

            def on_complete(self, result: dict) -> None:  # type: ignore[override]
                events.append("complete")

            async def execute(self, args: AddArgs, ctx: Context) -> dict:
                return {"ok": True}

        cmd = TrackedCommand()
        ctx = _make_ctx()
        await cmd.run(AddArgs(a=1, b=2), ctx)
        assert events == ["start", "complete"]

    @pytest.mark.asyncio
    async def test_on_error_hook(self) -> None:
        errors: list[Exception] = []

        class FailingCommand(HuitzoCommand):
            name = "fail"
            namespace = "test"

            def on_error(self, error: Exception) -> None:
                errors.append(error)

            async def execute(self, args: AddArgs, ctx: Context) -> dict:
                raise CommandError(message="boom")

        cmd = FailingCommand()
        ctx = _make_ctx()
        with pytest.raises(CommandError, match="boom"):
            await cmd.run(AddArgs(a=1, b=2), ctx)

        assert len(errors) == 1
        assert str(errors[0]) == "boom"

    def test_metadata_property(self) -> None:
        class MyCommand(HuitzoCommand):
            name = "my-cmd"
            namespace = "test"
            version = "2.0.0"

        cmd = MyCommand()
        assert cmd.metadata.name == "my-cmd"
        assert cmd.metadata.namespace == "test"
        assert cmd.metadata.version == "2.0.0"

    @pytest.mark.asyncio
    async def test_class_timeout_enforcement(self) -> None:
        class SlowCommand(HuitzoCommand):
            name = "slow"
            namespace = "test"
            timeout = 1

            async def execute(self, args: AddArgs, ctx: Context) -> dict:
                await asyncio.sleep(5)
                return {}

        cmd = SlowCommand()
        ctx = _make_ctx()
        with pytest.raises(CommandTimeoutError):
            await cmd.run(AddArgs(a=1, b=2), ctx)
