"""Tests for the Context class."""

import pytest
from uuid import UUID

from huitzo_sdk import Context, DeploymentMode
from huitzo_sdk.errors import (
    ConfigurationError,
    HuitzoError,
    IntegrationError,
)
from huitzo_sdk.integrations.secrets import EnvSecretsBackend, SecretsClient
from huitzo_sdk.storage import InMemoryBackend, StorageClient, StorageNamespace


class TestContextCreation:
    def test_default_values(self) -> None:
        ctx = Context()
        assert isinstance(ctx.user_id, UUID)
        assert isinstance(ctx.tenant_id, UUID)
        assert isinstance(ctx.session_id, UUID)
        assert isinstance(ctx.correlation_id, str)
        assert ctx.deployment_mode == DeploymentMode.CLOUD

    def test_custom_identity(self) -> None:
        uid = UUID("12345678-1234-1234-1234-123456789abc")
        tid = UUID("abcdefab-abcd-abcd-abcd-abcdefabcdef")
        ctx = Context(user_id=uid, tenant_id=tid)
        assert ctx.user_id == uid
        assert ctx.tenant_id == tid

    def test_command_metadata(self) -> None:
        ctx = Context(
            command_name="test-cmd",
            namespace="demo",
            command_version="2.0.0",
        )
        assert ctx.command_name == "test-cmd"
        assert ctx.namespace == "demo"
        assert ctx.command_version == "2.0.0"

    def test_deployment_mode(self) -> None:
        ctx = Context(deployment_mode=DeploymentMode.SELF_HOSTED)
        assert ctx.deployment_mode == DeploymentMode.SELF_HOSTED
        assert ctx.deployment_mode.value == "self_hosted"


class TestContextStubs:
    """Test that future services raise ConfigurationError (in HuitzoError hierarchy)."""

    STUBBED_SERVICES = [
        "env",
        "config",
        "local_storage",
        "inference_backend",
    ]

    @pytest.mark.parametrize("service", STUBBED_SERVICES)
    def test_stubbed_service_raises_configuration_error(self, service: str) -> None:
        ctx = Context()
        with pytest.raises(ConfigurationError, match=f"ctx.{service}"):
            getattr(ctx, service)

    @pytest.mark.parametrize("service", STUBBED_SERVICES)
    def test_stubbed_service_is_huitzo_error(self, service: str) -> None:
        ctx = Context()
        with pytest.raises(HuitzoError):
            getattr(ctx, service)

    def test_unknown_attribute_raises_attribute_error(self) -> None:
        ctx = Context()
        with pytest.raises(AttributeError):
            _ = ctx.nonexistent_thing


class TestContextIntegrationProperties:
    """Test that integration properties raise IntegrationError when not wired."""

    INTEGRATION_SERVICES = [
        "llm",
        "email",
        "http",
        "telegram",
        "files",
        "storage",
        "commands",
        "secrets",
        "log",
        "mcp",
    ]

    @pytest.mark.parametrize("service", INTEGRATION_SERVICES)
    def test_unwired_integration_raises_integration_error(self, service: str) -> None:
        ctx = Context()
        with pytest.raises(IntegrationError, match=f"ctx.{service}"):
            getattr(ctx, service)

    @pytest.mark.parametrize("service", INTEGRATION_SERVICES)
    def test_unwired_integration_is_huitzo_error(self, service: str) -> None:
        ctx = Context()
        with pytest.raises(HuitzoError):
            getattr(ctx, service)


class TestContextStorageWiring:
    """Test that ctx.storage works when wired with a StorageClient."""

    def test_storage_returns_client_when_wired(self) -> None:
        ns = StorageNamespace(
            tenant_id=UUID("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"),
            user_id=UUID("bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb"),
            pack_id="my-pack",
        )
        client = StorageClient(InMemoryBackend(), ns)
        ctx = Context(_storage=client)
        assert ctx.storage is client

    def test_storage_raises_when_not_wired(self) -> None:
        ctx = Context()
        with pytest.raises(IntegrationError, match="ctx.storage"):
            _ = ctx.storage

    def test_storage_raises_when_wired_with_raw_namespace(self) -> None:
        ns = StorageNamespace(
            tenant_id=UUID("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"),
            user_id=UUID("bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb"),
            pack_id="my-pack",
        )
        ctx = Context(_storage=ns)
        with pytest.raises(IntegrationError, match="StorageClient"):
            _ = ctx.storage


class TestDeploymentMode:
    def test_all_modes(self) -> None:
        assert DeploymentMode.CLOUD.value == "cloud"
        assert DeploymentMode.SELF_HOSTED.value == "self_hosted"
        assert DeploymentMode.EDGE.value == "edge"

    def test_comparison(self) -> None:
        ctx = Context(deployment_mode=DeploymentMode.EDGE)
        assert ctx.deployment_mode == DeploymentMode.EDGE
        assert ctx.deployment_mode != DeploymentMode.CLOUD


class TestContextSecretsWiring:
    """Test that ctx.secrets works when wired with a SecretsClient."""

    def test_secrets_returns_client_when_wired(self) -> None:
        client = SecretsClient(_backend=EnvSecretsBackend())
        ctx = Context(_secrets=client)
        assert ctx.secrets is client

    def test_secrets_raises_when_not_wired(self) -> None:
        ctx = Context()
        with pytest.raises(IntegrationError, match="ctx.secrets"):
            _ = ctx.secrets


class TestContextExecuteStub:
    """Test that ctx.execute() raises IntegrationError when not wired."""

    @pytest.mark.asyncio
    async def test_execute_raises_integration_error(self) -> None:
        ctx = Context()
        with pytest.raises(IntegrationError, match="ctx.execute"):
            await ctx.execute("other-pack", "some-command")

    @pytest.mark.asyncio
    async def test_execute_is_huitzo_error(self) -> None:
        ctx = Context()
        with pytest.raises(HuitzoError):
            await ctx.execute("other-pack", "some-command")
