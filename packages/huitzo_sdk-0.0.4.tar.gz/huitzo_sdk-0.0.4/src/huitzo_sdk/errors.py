"""
Module: errors
Description: SDK exception hierarchy for structured error handling.

Implements:
    - docs/sdk/error-handling.md#sdk-exception-hierarchy
    - docs/sdk/error-handling.md#exception-reference

See Also:
    - docs/sdk/commands.md (for command error patterns)
"""

from __future__ import annotations

from typing import Any
from urllib.parse import urlparse, urlunparse


def _redact_url(url: str) -> str:
    """Strip query parameters from URL to prevent credential leaks."""
    parsed = urlparse(url)
    return urlunparse((parsed.scheme, parsed.netloc, parsed.path, "", "", ""))


class HuitzoError(Exception):
    """Base exception for all Huitzo SDK errors."""

    code: str = "HUITZO_ERROR"
    http_status: int = 500
    retryable: bool = False

    def __init__(self, message: str, *, details: dict[str, Any] | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.details = details or {}


class CommandError(HuitzoError):
    """General command execution failure."""

    code = "COMMAND_FAILED"

    def __init__(
        self,
        message: str,
        *,
        exit_code: int = 1,
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message, details=details)
        self.exit_code = exit_code


class ValidationError(HuitzoError):
    """Input validation failed."""

    code = "VALIDATION_FAILED"
    http_status = 400

    def __init__(self, *, field: str, value: Any, message: str) -> None:
        super().__init__(message)
        self.field = field
        self.value = value


class CommandTimeoutError(HuitzoError):
    """Command exceeded its configured timeout."""

    code = "TIMEOUT"
    http_status = 408
    retryable = True

    def __init__(self, *, timeout_seconds: int, elapsed_seconds: float) -> None:
        super().__init__(
            f"Command timed out after {elapsed_seconds:.1f}s (limit: {timeout_seconds}s)"
        )
        self.timeout_seconds = timeout_seconds
        self.elapsed_seconds = elapsed_seconds


class StorageError(HuitzoError):
    """Storage operation failed."""

    code = "STORAGE_ERROR"

    def __init__(self, *, operation: str, key: str | None = None, message: str) -> None:
        super().__init__(message)
        self.operation = operation
        self.key = key


class SecretsError(HuitzoError):
    """User secret access failure."""

    code = "SECRET_MISSING"
    http_status = 400

    def __init__(self, *, secret_name: str, message: str) -> None:
        super().__init__(message)
        self.secret_name = secret_name


class ExternalAPIError(HuitzoError):
    """User-configured external API failure."""

    code = "EXTERNAL_API_ERROR"
    http_status = 502

    def __init__(self, *, service: str, message: str) -> None:
        super().__init__(message)
        self.service = service


class IntegrationError(HuitzoError):
    """Platform service failure (base for LLM, Email, HTTP errors)."""

    code = "INTEGRATION_ERROR"
    http_status = 502
    retryable = True

    def __init__(
        self,
        *,
        service: str,
        message: str,
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message, details=details)
        self.service = service


class LLMError(IntegrationError):
    """LLM provider error."""

    code = "LLM_ERROR"

    def __init__(
        self,
        *,
        provider: str,
        model: str | None = None,
        status_code: int | None = None,
        message: str,
    ) -> None:
        super().__init__(service=f"llm:{provider}", message=message)
        self.provider = provider
        self.model = model
        self.status_code = status_code


class EmailError(IntegrationError):
    """Email sending error."""

    code = "EMAIL_ERROR"

    def __init__(self, *, message: str) -> None:
        super().__init__(service="email", message=message)


class HTTPError(IntegrationError):
    """HTTP request error."""

    code = "HTTP_ERROR"

    def __init__(
        self,
        *,
        url: str,
        method: str,
        status_code: int | None = None,
        response_body: str | None = None,
        message: str,
    ) -> None:
        super().__init__(service="http", message=message)
        self.url = _redact_url(url)
        self.method = method
        self.status_code = status_code
        self.response_body = (
            (response_body[:200] + " [truncated]")
            if response_body and len(response_body) > 200
            else response_body
        )


class HTTPSecurityError(HuitzoError):
    """Request to disallowed domain."""

    code = "HTTP_SECURITY_ERROR"
    http_status = 403

    def __init__(
        self,
        *,
        domain: str,
        allowed_domains: list[str] | None = None,
        message: str | None = None,
    ) -> None:
        super().__init__(message or f"Domain not allowed: {domain}")
        self.domain = domain
        self.allowed_domains: list[str] = allowed_domains or []


class SSHError(HuitzoError):
    """SSH execution or connection failure."""

    code = "SSH_ERROR"
    http_status = 502
    retryable = True

    def __init__(
        self,
        *,
        host: str = "",
        target: str = "",
        message: str = "",
    ) -> None:
        self.host = host
        self.target = target
        super().__init__(message=message or f"SSH error on target '{target or host}'")


class CircularCommandError(CommandError):
    """Circular command call detected (A calls B calls A)."""

    code = "CIRCULAR_COMMAND"

    def __init__(self, *, call_stack: list[str], command: str) -> None:
        chain = " -> ".join(call_stack + [command])
        super().__init__(
            message=f"Circular command call detected: {chain}",
            exit_code=1,
            details={"call_stack": call_stack, "command": command},
        )
        self.call_stack = call_stack
        self.command = command


class CommandNotFoundError(CommandError):
    """Requested command does not exist in this pack."""

    code = "COMMAND_NOT_FOUND"
    http_status = 404

    def __init__(self, *, command: str, namespace: str) -> None:
        super().__init__(
            message=f"Command '{command}' not found in pack '{namespace}'.",
            exit_code=1,
            details={"command": command, "namespace": namespace},
        )
        self.command_name = command
        self.pack_namespace = namespace


class PackExecutionError(HuitzoError):
    """Cross-pack command execution failed."""

    code = "PACK_EXECUTION_ERROR"

    def __init__(
        self,
        *,
        pack: str,
        command: str,
        original_error: Exception | None = None,
        message: str,
    ) -> None:
        super().__init__(message)
        self.pack = pack
        self.command = command
        self.original_error = original_error


class PackPermissionError(HuitzoError):
    """Insufficient permissions."""

    code = "PERMISSION_DENIED"
    http_status = 403

    def __init__(self, *, message: str) -> None:
        super().__init__(message)


class ConfigurationError(HuitzoError):
    """Invalid configuration."""

    code = "CONFIGURATION_ERROR"

    def __init__(self, *, message: str) -> None:
        super().__init__(message)


class RateLimitError(HuitzoError):
    """Rate limit exceeded."""

    code = "RATE_LIMITED"
    http_status = 429
    retryable = True

    def __init__(
        self,
        *,
        retry_after: float,
        limit: str | None = None,
        current: int | None = None,
        message: str | None = None,
    ) -> None:
        super().__init__(message or f"Rate limit exceeded. Retry after {retry_after}s")
        self.retry_after = retry_after
        self.limit = limit
        self.current = current


# ---------------------------------------------------------------------------
# MCP (Model Context Protocol) error hierarchy
# ---------------------------------------------------------------------------


class MCPError(IntegrationError):
    """Base error for MCP operations."""

    code = "MCP_ERROR"

    def __init__(self, *, message: str, details: dict[str, Any] | None = None) -> None:
        super().__init__(service="mcp", message=message, details=details)


class MCPConnectionError(MCPError):
    """Failed to connect to an MCP server."""

    code = "MCP_CONNECTION_ERROR"

    def __init__(self, *, server: str, message: str) -> None:
        super().__init__(message=message, details={"server": server})
        self.server = server


class MCPToolError(MCPError):
    """MCP tool invocation failed."""

    code = "MCP_TOOL_ERROR"

    def __init__(self, *, tool: str, server: str, message: str) -> None:
        super().__init__(message=message, details={"tool": tool, "server": server})
        self.tool = tool
        self.server = server


class MCPTimeoutError(MCPError):
    """MCP operation timed out."""

    code = "MCP_TIMEOUT"
    retryable = True

    def __init__(self, *, server: str, timeout_seconds: int, message: str | None = None) -> None:
        super().__init__(
            message=message or f"MCP call to '{server}' timed out after {timeout_seconds}s",
            details={"server": server, "timeout_seconds": timeout_seconds},
        )
        self.server = server
        self.timeout_seconds = timeout_seconds


class MCPSchemaError(MCPError):
    """MCP tool schema validation failed."""

    code = "MCP_SCHEMA_ERROR"

    def __init__(self, *, tool: str, message: str) -> None:
        super().__init__(message=message, details={"tool": tool})
        self.tool = tool
