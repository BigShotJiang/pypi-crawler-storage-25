"""
Module: storage.protocol
Description: StorageBackend Protocol defining the abstract storage interface.

Implements:
    - docs/sdk/storage-backends.md#storage-backend-protocol
    - docs/sdk/storage.md#core-methods

See Also:
    - docs/sdk/storage.md (for high-level storage API)
    - docs/sdk/context.md#ctx-storage (for Context integration)
"""

from __future__ import annotations

import builtins
from contextlib import AbstractAsyncContextManager
from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class StorageBackend(Protocol):
    """Abstract storage interface enabling multiple backends.

    All storage backends must implement this protocol. Keys are pre-scoped
    by StorageNamespace before reaching the backend.
    """

    async def save(
        self,
        key: str,
        value: Any,
        *,
        ttl: int | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """Save a value to storage.

        Args:
            key: Storage key (max 256 characters, pre-scoped).
            value: JSON-serializable value.
            ttl: Time-to-live in seconds.
            metadata: Optional metadata for querying.

        Returns:
            The storage key.

        Raises:
            StorageError: If save operation fails.
        """
        ...

    async def get(self, key: str, *, default: Any = None) -> Any:
        """Retrieve a value from storage.

        Args:
            key: Storage key.
            default: Value returned if key not found.

        Returns:
            The stored value, or default if not found.

        Raises:
            StorageError: If retrieval fails.
        """
        ...

    async def delete(self, key: str) -> bool:
        """Delete a value from storage.

        Args:
            key: Storage key.

        Returns:
            True if deleted, False if not found.

        Raises:
            StorageError: If deletion fails.
        """
        ...

    async def exists(self, key: str) -> bool:
        """Check if a key exists in storage.

        Args:
            key: Storage key.

        Returns:
            True if key exists and is not expired.
        """
        ...

    async def list(
        self, prefix: str = "", *, limit: int = 100, offset: int = 0
    ) -> builtins.list[str]:
        """List keys matching a prefix.

        Args:
            prefix: Key prefix to match.
            limit: Maximum number of keys to return.
            offset: Pagination offset.

        Returns:
            List of matching keys.

        Raises:
            StorageError: If listing fails.
        """
        ...

    async def save_many(self, items: dict[str, Any], *, ttl: int | None = None) -> None:
        """Save multiple key-value pairs.

        Args:
            items: Dictionary of key-value pairs.
            ttl: Optional TTL applied to all items.

        Raises:
            StorageError: If any save fails.
        """
        ...

    async def get_many(self, keys: builtins.list[str]) -> dict[str, Any]:
        """Retrieve multiple values.

        Args:
            keys: List of keys to retrieve.

        Returns:
            Dictionary mapping keys to values (None for missing keys).
        """
        ...

    async def delete_many(self, keys: builtins.list[str]) -> int:
        """Delete multiple keys.

        Args:
            keys: List of keys to delete.

        Returns:
            Number of keys actually deleted.
        """
        ...

    async def query(
        self,
        prefix: str = "",
        *,
        metadata: dict[str, Any] | None = None,
        limit: int = 100,
    ) -> builtins.list[dict[str, Any]]:
        """Query storage by prefix and metadata filters.

        Args:
            prefix: Key prefix to match.
            metadata: Metadata key-value filters (exact match).
            limit: Maximum number of results.

        Returns:
            List of records with key, value, and metadata.
        """
        ...

    def transaction(self) -> AbstractAsyncContextManager[None]:
        """Begin an atomic transaction.

        Usage:
            async with backend.transaction():
                await backend.save("k1", v1)
                await backend.save("k2", v2)
                # Both commit or both rollback.
        """
        ...
