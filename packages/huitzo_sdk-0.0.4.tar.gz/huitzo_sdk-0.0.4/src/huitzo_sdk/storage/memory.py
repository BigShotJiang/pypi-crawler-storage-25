"""
Module: storage.memory
Description: In-memory storage backend for testing and development.

Implements:
    - docs/sdk/storage-backends.md#storage-backend-protocol
    - docs/sdk/storage.md#core-methods
    - docs/sdk/storage.md#ttl-time-to-live
    - docs/sdk/storage.md#batch-operations
    - docs/sdk/storage.md#transactions
    - docs/sdk/storage.md#query-by-metadata

See Also:
    - docs/sdk/storage.md (for high-level storage API)
"""

from __future__ import annotations

import asyncio
import builtins
import copy
import time
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from typing import Any, AsyncIterator


@dataclass
class _Entry:
    """Internal storage entry."""

    value: Any
    metadata: dict[str, Any] = field(default_factory=dict)
    expires_at: float | None = None

    def is_expired(self) -> bool:
        return self.expires_at is not None and time.monotonic() >= self.expires_at


class InMemoryBackend:
    """In-memory implementation of StorageBackend for testing.

    Supports all protocol methods including TTL, batch operations,
    metadata queries, and transactions.

    Note: This backend has the following limitations:
    - Expired entries are cleaned up lazily (only when accessed), which may
      cause memory usage to grow with many TTL-based entries that are never
      accessed again.
    - Transactions create a deep copy of all data, which has O(n) time and
      space overhead where n is the total number of keys in storage.
    """

    def __init__(self) -> None:
        self._data: dict[str, _Entry] = {}
        self._in_transaction: bool = False
        self._snapshot: dict[str, _Entry] | None = None
        self._tx_lock: asyncio.Lock = asyncio.Lock()

    def _clean_expired(self, key: str) -> None:
        entry = self._data.get(key)
        if entry is not None and entry.is_expired():
            del self._data[key]

    def _set_expiration_for_testing(self, key: str, expires_at: float) -> None:
        """Set expiration time for a key (for testing purposes only).

        Args:
            key: The key to modify
            expires_at: Expiration timestamp (from time.monotonic())
        """
        if key in self._data:
            self._data[key].expires_at = expires_at

    def _get_entry(self, key: str) -> _Entry | None:
        self._clean_expired(key)
        return self._data.get(key)

    async def save(
        self,
        key: str,
        value: Any,
        *,
        ttl: int | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        expires_at = (time.monotonic() + ttl) if ttl is not None else None
        self._data[key] = _Entry(
            value=value,
            metadata=metadata or {},
            expires_at=expires_at,
        )
        return key

    async def get(self, key: str, *, default: Any = None) -> Any:
        entry = self._get_entry(key)
        if entry is None:
            return default
        return entry.value

    async def delete(self, key: str) -> bool:
        self._clean_expired(key)
        if key in self._data:
            del self._data[key]
            return True
        return False

    async def exists(self, key: str) -> bool:
        return self._get_entry(key) is not None

    async def list(
        self, prefix: str = "", *, limit: int = 100, offset: int = 0
    ) -> builtins.list[str]:
        # Clean expired keys lazily
        keys = [k for k in self._data if k.startswith(prefix) and not self._data[k].is_expired()]
        keys.sort()
        return keys[offset : offset + limit]

    async def save_many(self, items: dict[str, Any], *, ttl: int | None = None) -> None:
        for key, value in items.items():
            await self.save(key, value, ttl=ttl)

    async def get_many(self, keys: builtins.list[str]) -> dict[str, Any]:
        return {key: await self.get(key) for key in keys}

    async def delete_many(self, keys: builtins.list[str]) -> int:
        count = 0
        for key in keys:
            if await self.delete(key):
                count += 1
        return count

    async def query(
        self,
        prefix: str = "",
        *,
        metadata: dict[str, Any] | None = None,
        limit: int = 100,
    ) -> builtins.list[dict[str, Any]]:
        results: builtins.list[dict[str, Any]] = []
        for key, entry in sorted(self._data.items()):
            if entry.is_expired():
                continue
            if not key.startswith(prefix):
                continue
            if metadata:
                if not all(entry.metadata.get(k) == v for k, v in metadata.items()):
                    continue
            results.append(
                {"key": key, "value": entry.value, "metadata": copy.deepcopy(entry.metadata)}
            )
            if len(results) >= limit:
                break
        return results

    @asynccontextmanager
    async def transaction(self) -> AsyncIterator[None]:
        """Atomic transaction with snapshot-based rollback.

        Uses an asyncio.Lock to ensure only one transaction runs at a time,
        preventing concurrent tasks from corrupting state.
        """
        if self._in_transaction:
            # Nested transaction: just yield (no new snapshot)
            yield
            return

        async with self._tx_lock:
            # Take snapshot
            self._snapshot = {
                k: _Entry(copy.deepcopy(v.value), copy.deepcopy(v.metadata), v.expires_at)
                for k, v in self._data.items()
            }
            self._in_transaction = True
            try:
                yield
                # Commit: discard snapshot
                self._snapshot = None
            except BaseException:
                # Rollback: restore snapshot
                if self._snapshot is not None:
                    self._data = self._snapshot
                    self._snapshot = None
                raise
            finally:
                self._in_transaction = False
