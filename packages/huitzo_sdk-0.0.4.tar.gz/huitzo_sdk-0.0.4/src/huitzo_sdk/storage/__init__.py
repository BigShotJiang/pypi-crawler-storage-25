"""
Module: storage
Description: Storage interface, backends, and key scoping for the Huitzo SDK.

Implements:
    - docs/sdk/storage.md
    - docs/sdk/storage-backends.md

See Also:
    - docs/sdk/context.md#ctx-storage (for Context integration)
"""

from huitzo_sdk.storage.client import StorageClient
from huitzo_sdk.storage.memory import InMemoryBackend
from huitzo_sdk.storage.namespace import StorageNamespace
from huitzo_sdk.storage.protocol import StorageBackend

__all__ = [
    "StorageBackend",
    "StorageClient",
    "InMemoryBackend",
    "StorageNamespace",
]
