"""
Module: huitzo_sdk
Description: Huitzo SDK for building Intelligence Packs.

Implements:
    - docs/sdk/overview.md
    - docs/sdk/commands.md
    - docs/sdk/context.md
    - docs/sdk/error-handling.md

See Also:
    - docs/sdk/storage.md
    - docs/sdk/storage-backends.md
    - docs/sdk/integrations.md
"""

from huitzo_sdk.command import HuitzoCommand, command
from huitzo_sdk.commands_service import CommandsBackend, CommandsClient
from huitzo_sdk.context import Context
from huitzo_sdk.errors import (
    CircularCommandError,
    CommandError,
    CommandNotFoundError,
    CommandTimeoutError,
    ConfigurationError,
    EmailError,
    ExternalAPIError,
    HTTPError,
    HTTPSecurityError,
    HuitzoError,
    IntegrationError,
    LLMError,
    MCPConnectionError,
    MCPError,
    MCPSchemaError,
    MCPTimeoutError,
    MCPToolError,
    PackExecutionError,
    PackPermissionError,
    RateLimitError,
    SSHError,
    SecretsError,
    StorageError,
    ValidationError,
)
from huitzo_sdk.integrations import (
    DevLogBackend,
    EmailClient,
    EnvSecretsBackend,
    FileClient,
    FileStorageBackend,
    HTTPClient,
    LLMClient,
    LogClient,
    SecretsBackend,
    SecretsClient,
    SSHClient,
    TelegramClient,
)
from huitzo_sdk.storage import InMemoryBackend, StorageBackend, StorageClient, StorageNamespace
from huitzo_sdk.types import CommandMetadata, DeploymentMode, Result

__all__ = [
    # Core
    "command",
    "HuitzoCommand",
    "Context",
    # Commands
    "CommandsBackend",
    "CommandsClient",
    # Integrations
    "LLMClient",
    "EmailClient",
    "HTTPClient",
    "TelegramClient",
    "SSHClient",
    "FileClient",
    "FileStorageBackend",
    "LogClient",
    "DevLogBackend",
    "SecretsClient",
    "SecretsBackend",
    "EnvSecretsBackend",
    # Storage
    "StorageBackend",
    "StorageClient",
    "InMemoryBackend",
    "StorageNamespace",
    # Types
    "CommandMetadata",
    "DeploymentMode",
    "Result",
    # Errors
    "HuitzoError",
    "CircularCommandError",
    "CommandError",
    "CommandNotFoundError",
    "ValidationError",
    "CommandTimeoutError",
    "StorageError",
    "SecretsError",
    "ExternalAPIError",
    "IntegrationError",
    "LLMError",
    "EmailError",
    "HTTPError",
    "HTTPSecurityError",
    "SSHError",
    "PackExecutionError",
    "PackPermissionError",
    "ConfigurationError",
    "RateLimitError",
    "MCPError",
    "MCPConnectionError",
    "MCPToolError",
    "MCPTimeoutError",
    "MCPSchemaError",
]
