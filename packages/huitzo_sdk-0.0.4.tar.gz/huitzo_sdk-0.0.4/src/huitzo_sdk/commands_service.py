"""
Module: commands_service
Description: Intra-pack command execution service for ctx.commands.

Implements:
    - docs/sdk/context.md#intra-pack-command-execution

See Also:
    - docs/sdk/commands.md (for command patterns)
    - docs/sdk/error-handling.md (for error patterns)
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Protocol, runtime_checkable

from huitzo_sdk.errors import (
    CircularCommandError,
    CommandError,
    CommandNotFoundError,
    CommandTimeoutError,
)
from huitzo_sdk.types import Result

MAX_CALL_DEPTH = 10


@runtime_checkable
class CommandsBackend(Protocol):
    """Backend protocol for resolving same-pack commands."""

    def resolve(self, command_name: str) -> Callable[..., Any] | None:
        """Resolve a command name to its callable within the current pack.

        Args:
            command_name: Short command name (e.g., "get-visit")

        Returns:
            The command function, or None if not found.
        """
        ...

    def get_timeout(self, command_name: str) -> int:
        """Get the configured timeout for a command.

        Args:
            command_name: Short command name

        Returns:
            Timeout in seconds, or 60 as default.
        """
        ...


@dataclass
class CommandsClient:
    """Client for executing commands within the same pack.

    Provides ctx.commands.execute() for intra-pack command composition.
    Always executes inline (never routes to Celery).
    Tracks call stack to detect circular calls.
    Deducts timeout from parent's remaining budget.
    """

    _backend: CommandsBackend
    _namespace: str
    _parent_timeout: float | None = None
    _start_time: float = field(default_factory=time.monotonic)
    _call_stack: list[str] = field(default_factory=list)
    _context: Any = field(default=None, repr=False)

    async def execute(
        self,
        command_name: str,
        args: dict[str, Any],
        *,
        timeout: int | None = None,
    ) -> Result:
        """Execute a command within the same pack.

        Args:
            command_name: Short name of the command (e.g., "get-visit")
            args: Arguments dict to pass to the command
            timeout: Override timeout in seconds. If None, uses the
                     inner command's configured timeout, capped by
                     the parent's remaining budget.

        Returns:
            The command result.

        Raises:
            CommandNotFoundError: Command not in this pack
            CircularCommandError: Circular call detected
            CommandTimeoutError: Execution exceeded timeout budget
            CommandError: Inner command failure
        """
        # 1. Check for circular call
        if command_name in self._call_stack:
            raise CircularCommandError(
                call_stack=list(self._call_stack),
                command=command_name,
            )

        # 2. Check call depth
        if len(self._call_stack) >= MAX_CALL_DEPTH:
            raise CircularCommandError(
                call_stack=list(self._call_stack),
                command=command_name,
            )

        # 3. Resolve command
        command_func = self._backend.resolve(command_name)
        if command_func is None:
            raise CommandNotFoundError(
                command=command_name,
                namespace=self._namespace,
            )

        # 4. Calculate effective timeout
        inner_timeout = timeout if timeout is not None else self._backend.get_timeout(command_name)
        remaining_budget = self._remaining_budget()
        effective_timeout: float | None
        if remaining_budget is not None:
            capped = min(float(inner_timeout), remaining_budget)
            if capped <= 0.0:
                raise CommandTimeoutError(
                    timeout_seconds=inner_timeout,
                    elapsed_seconds=self._elapsed(),
                )
            effective_timeout = capped
        else:
            if inner_timeout <= 0 and timeout is not None:
                # User explicitly passed timeout=0 — immediate rejection
                raise CommandTimeoutError(
                    timeout_seconds=inner_timeout,
                    elapsed_seconds=self._elapsed(),
                )
            effective_timeout = float(inner_timeout) if inner_timeout > 0 else None

        # 5. Push onto call stack and execute inline
        self._call_stack.append(command_name)
        start = time.monotonic()
        try:
            result: Result = await asyncio.wait_for(
                command_func(args, self._context),
                timeout=effective_timeout,
            )
            return result
        except asyncio.TimeoutError:
            elapsed = time.monotonic() - start
            raise CommandTimeoutError(
                timeout_seconds=int(effective_timeout or 0),
                elapsed_seconds=elapsed,
            )
        except (CircularCommandError, CommandNotFoundError, CommandTimeoutError, CommandError):
            raise
        except Exception as e:
            raise CommandError(
                message=f"Intra-pack call to '{command_name}' failed: {e}",
                details={"command": command_name, "original_error": str(e)},
            ) from e
        finally:
            self._call_stack.pop()

    def _remaining_budget(self) -> float | None:
        """Calculate remaining timeout budget from parent."""
        if self._parent_timeout is None:
            return None
        elapsed = time.monotonic() - self._start_time
        return max(0.0, self._parent_timeout - elapsed)

    def _elapsed(self) -> float:
        """Elapsed time since the parent command started."""
        return time.monotonic() - self._start_time
