"""
Module: integrations.telegram
Description: Telegram integration client for sending messages, documents, and photos.

Implements:
    - docs/sdk/integrations.md#telegram-integration

See Also:
    - docs/sdk/error-handling.md (for IntegrationError)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, runtime_checkable


@runtime_checkable
class TelegramBackend(Protocol):
    """Backend protocol for Telegram bot API."""

    async def send(
        self,
        *,
        chat_id: str,
        message: str,
        parse_mode: str | None,
    ) -> None: ...

    async def send_document(
        self,
        *,
        chat_id: str,
        document: bytes,
        filename: str,
        caption: str | None,
    ) -> None: ...

    async def send_photo(
        self,
        *,
        chat_id: str,
        photo: bytes,
        caption: str | None,
    ) -> None: ...


@dataclass
class TelegramClient:
    """Client for sending Telegram messages and media.

    This is the SDK-side interface. The backend injects a real implementation
    at runtime that calls the Telegram Bot API.
    """

    _backend: TelegramBackend

    async def send(
        self,
        *,
        chat_id: str,
        message: str,
        parse_mode: str | None = None,
    ) -> None:
        """Send a text message.

        Args:
            chat_id: Target chat ID.
            message: Message text.
            parse_mode: "Markdown" or "HTML".

        Raises:
            IntegrationError: If sending fails.
        """
        await self._backend.send(chat_id=chat_id, message=message, parse_mode=parse_mode)

    async def send_document(
        self,
        *,
        chat_id: str,
        document: bytes,
        filename: str,
        caption: str | None = None,
    ) -> None:
        """Send a document.

        Args:
            chat_id: Target chat ID.
            document: File bytes.
            filename: Filename for the document.
            caption: Optional caption.

        Raises:
            IntegrationError: If sending fails.
        """
        await self._backend.send_document(
            chat_id=chat_id, document=document, filename=filename, caption=caption
        )

    async def send_photo(
        self,
        *,
        chat_id: str,
        photo: bytes,
        caption: str | None = None,
    ) -> None:
        """Send a photo.

        Args:
            chat_id: Target chat ID.
            photo: Image bytes.
            caption: Optional caption.

        Raises:
            IntegrationError: If sending fails.
        """
        await self._backend.send_photo(chat_id=chat_id, photo=photo, caption=caption)
