"""
Module: integrations.secrets
Description: Secrets integration client for accessing user-configured secrets.

Implements:
    - docs/sdk/context.md#secrets
    - docs/reference/secrets.md

See Also:
    - docs/sdk/error-handling.md (for SecretsError)
"""

from __future__ import annotations

import os
import warnings
from dataclasses import dataclass
from typing import Protocol, runtime_checkable

from huitzo_sdk.errors import SecretsError


@runtime_checkable
class SecretsBackend(Protocol):
    """Backend protocol for secrets providers."""

    async def get(self, key: str) -> str | None: ...


@dataclass
class SecretsClient:
    """Client for accessing user-configured secrets.

    This is the SDK-side interface. The backend injects a real implementation
    at runtime that handles retrieval from the platform's encrypted secrets store.
    """

    _backend: SecretsBackend

    async def require(self, key: str) -> str:
        """Retrieve a required secret, raising SecretsError if it is missing.

        Args:
            key: The secret name.

        Returns:
            The secret value.

        Raises:
            SecretsError: If the secret is not configured.
        """
        value = await self._backend.get(key)
        if value is None:
            raise SecretsError(
                secret_name=key,
                message=f"Required secret '{key}' is not configured.",
            )
        return value

    async def get(self, key: str) -> str | None:
        """Retrieve an optional secret, returning None if it is missing.

        Args:
            key: The secret name.

        Returns:
            The secret value, or None if not configured.
        """
        return await self._backend.get(key)

    async def exists(self, key: str) -> bool:
        """Check whether a secret is configured.

        Args:
            key: The secret name.

        Returns:
            True if the secret is configured, False otherwise.
        """
        return await self._backend.get(key) is not None


_ENV_PREFIX = "HUITZO_SECRET_"
_ENV_WARNING = (
    "⚠  ctx.secrets running in ENV fallback mode (dev only).\n"
    f"   Set {_ENV_PREFIX}<KEY_NAME>=<value> in your .env file.\n"
    "   This is NOT production-safe."
)


@dataclass
class EnvSecretsBackend:
    """Development-only secrets backend that reads from environment variables.

    Keys are resolved by looking up ``HUITZO_SECRET_<KEY_NAME>`` in the process
    environment.  A one-time warning is emitted on first use to remind developers
    that this backend is not suitable for production.

    Example::

        export HUITZO_SECRET_OPENAI_API_KEY=sk-...

        api_key = await ctx.secrets.require("OPENAI_API_KEY")
    """

    _warned: bool = False

    def _warn_once(self) -> None:
        # This check-and-set is synchronous with no await points, so it is
        # atomic within the asyncio event loop and safe from concurrent access.
        if not self._warned:
            warnings.warn(_ENV_WARNING, stacklevel=4)
            self._warned = True

    async def get(self, key: str) -> str | None:
        """Look up ``HUITZO_SECRET_<key>`` from the environment."""
        self._warn_once()
        return os.environ.get(f"{_ENV_PREFIX}{key}")
