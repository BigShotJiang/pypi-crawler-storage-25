# AgntSpace

**Personal AI operating system / second brain. Run it in the cloud at agntspace.com, or locally on your machine.**

[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org)
[![Status: Active Development](https://img.shields.io/badge/status-active%20development-green.svg)](#status)

```bash
pip install agntspace && agntspace start
# → opens http://localhost:8000, onboarding wizard guides you through setup
```

> New here? Read the [5-minute tour](docs/tour.md). Extending AgntSpace? See the [community hub](https://github.com/agntspace/agntspace-community) for skills, plugins, and vault templates.

## Origin Story

AgntSpace started as a personal AI assistant with a memory system — a way to give an LLM persistent context about your life, projects, and decisions across conversations. We built layered memory compaction, a knowledge graph, trust evolution, and contract enforcement. It worked, but the knowledge side felt incomplete.

The missing piece was an LLM-powered wiki — a system where an AI reads your raw sources and compiles them into an interconnected, always-up-to-date knowledge base with wiki-links, entity pages, and source provenance. We wired that concept into the agent architecture: the agent ingests your files, compiles wiki articles, cross-links entities, detects contradictions, tracks provenance back to sources, and keeps the whole thing current as new information arrives. Combined with the memory system, you get an AI that not only remembers what you told it — it *understands* what you know.

## Philosophy

> Your AI agent will learn how you think, how you work, and how you decide.
> That makes the persistence layer — your memory, your knowledge graph, your
> behavioral context — the most valuable digital asset you own. It should not
> belong to the platform that hosts the model. It should not leave with your
> employer when you change jobs. It should not be locked in a proprietary
> format that makes switching providers an act of cognitive amnesia.
>
> AgntSpace exists because we believe the persistence layer belongs to you:
> stored in plain files you can read without us, governed by a contract you
> write and the agent enforces in code, with a complete decision trail so
> "what did you do?" always has a verifiable answer. The agent earns autonomy
> through demonstrated competence. It never acts outside the contract. And
> when you leave, your second brain comes with you — no export, no migration,
> no permission needed. It was never ours.

Every architectural choice in this project flows from that commitment:

- The [**Contract**](#1-the-contract--a-negotiated-relationship) is how "governed by an agreement you write" becomes code — YAML permissions, default-deny, enforced on every action.
- The [**Trust System**](#2-trust--it-grows-with-you) is how "earns autonomy through demonstrated competence" works — feedback-driven, domain-specific, reversible.
- The [**Decision Log**](#what-makes-this-different) is how "complete trail of every decision" is kept — correlation IDs, memory provenance, per-tool-call accountability.
- The [**Vault**](#strategic-independence) is how "belongs to you" is guaranteed — plain markdown, no proprietary format, works with Obsidian or any text editor, no cloud required.
- The [**Epistemic Engine**](#what-makes-this-different) is how "never pretends" is enforced — five-factor knowledge weights, justification chains, contradiction detection, verified vs. believed distinction.

## What Is AgntSpace?

AgntSpace is a personal AI agent that runs your life alongside you. Not a chatbot you visit when you have a question — a persistent partner that knows your projects, tracks your goals, manages your communications, learns from your feedback, and grows more capable over time.

You talk to a main agent through whatever channel you prefer — web, Telegram, WhatsApp, Discord, Slack, CLI. Behind it, a team of specialized subagents works on your behalf: a Researcher digs into topics, a Writer drafts in your voice, an Analyst crunches numbers, a Planner breaks goals into steps. You can deploy as many subagents as you need — pre-built or custom — and the main agent orchestrates them all under your contract.

The agents read and write your knowledge in a markdown vault you can edit with any tool you like. They delegate your work, coach your goals, and consolidate what you learned today into long-term memory while you sleep.

Run it locally and everything stays on your machine. Or use agntspace.com and we host it for you. Either way: your data is stored in markdown files, your agent's personality is readable text, and the rules of engagement between you are an editable contract — no black boxes.

### Strategic Independence

AgntSpace is designed to be **fully provider-independent** as a core architectural principle:

- **LLM independent.** Switch between Anthropic, OpenAI, Google, Mistral, Ollama, or any OpenAI-compatible API at any time. Your data, contract, memory, and trust scores stay the same. The LLM is a replaceable reasoning engine, not a platform lock-in.
- **Infrastructure independent.** Run on your laptop, a server, Docker, or our hosted service. Move between them freely. Your vault is portable markdown — not tied to any cloud, database, or vendor.
- **Channel independent.** Add or remove messaging channels (Telegram, WhatsApp, Discord, Slack) without affecting the agent's capabilities. Channels are delivery mechanisms, not dependencies.
- **Storage independent.** Integrate with Obsidian, Logseq, or any markdown-based tool. Your vault works with or without external editors.

This means you are never locked into a specific AI provider, cloud platform, or tool ecosystem. AgntSpace is yours to run however you want, with whichever providers you choose, forever.

```mermaid
graph TB
    subgraph Channels["How You Connect"]
        WebUI["Web UI"]
        Msg["Telegram / WhatsApp\nDiscord / Slack"]
        Desktop["Desktop App"]
        CLI["CLI"]
    end

    subgraph Core["AgntSpace"]
        Main["Main Agent"]
        Sub["Subagents\nResearcher / Writer\nAnalyst / Planner"]
        Main -->|orchestrates| Sub
    end

    subgraph Brain["The Brain"]
        Vault["Vault (MD)"]
        Skills["Skills (MD)"]
        Memory["Memory (SQLite)"]
        Domains["Domains\n(Life OS)"]
    end

    subgraph LLM["LLM Provider"]
        Cloud["Anthropic / OpenAI"]
        Local["Ollama (local)"]
    end

    subgraph Integrations["Integrations"]
        Gmail["Gmail"]
        GCal["Google Calendar"]
        GitHub["GitHub"]
    end

    WebUI & Msg & Desktop & CLI --> Main
    Main --> Vault & Skills & Memory & Domains
    Main --> Cloud & Local
    Main --> Integrations
```

---

## What Makes This Different

Most AI products give you a conversation. AgntSpace gives you a **relationship** — with identity, trust, memory, growth, and accountability.

### 1. The Contract — A Negotiated Relationship

Every other AI system has terms of service written by the company. AgntSpace has a **contract written by you**.

CONTRACT.md is a human-readable agreement between you and your agent that defines: what it can do, what it can't, how autonomous it should be, what data it can send to the cloud, and when it should ask before acting. The contract is not just documentation — it's **enforced in code**. Every agent action is checked against your contract before execution. When the contract is ambiguous, the agent asks. It does not assume permission.

No other personal AI system formalizes the human-agent relationship as an editable, enforceable agreement.

### 2. Three Identities, One Relationship

AgntSpace has three entities, not two:

- **You** — your identity, preferences, and context live in USER.md and PROFILE.md
- **The agent** — its personality, values, and boundaries live in SOUL.md
- **The agreement** — the rules of engagement live in CONTRACT.md

You can open SOUL.md and read exactly who your agent is. You can edit it. You can change its personality to match how you want to be supported. No other AI product gives you a readable, editable file that defines the agent's identity.

```mermaid
graph LR
    Human["You\nUSER.md + PROFILE.md"]
    Contract["CONTRACT.md\n(enforced in code)"]
    Agent["Agent\nSOUL.md"]

    Human <-->|"negotiated\nagreement"| Contract
    Contract <-->|"governs\nbehavior"| Agent
    Human <-->|"relationship"| Agent

    style Human fill:#4A90D9,color:#fff
    style Contract fill:#F39C12,color:#fff
    style Agent fill:#27AE60,color:#fff
```

### 3. Trust That Evolves

Other AI systems have a fixed level of capability. AgntSpace has **trust that grows from experience**.

The agent starts cautious. As you delegate tasks and give feedback, it earns trust per domain. After 5 successful email drafts, it earns autonomy over email. If it sends something wrong, trust drops. You can override trust at any time, but you shouldn't have to — it adapts.

This means a new AgntSpace agent and a 6-month-old AgntSpace agent behave differently. The one that's been working with you is more capable, more autonomous, and more aligned with how you work — because it earned that through demonstrated competence, not a settings toggle.

### 4. The Agent Teaches Itself

When the agent notices it keeps doing the same kind of task — investor update emails, meeting notes, financial reports — it drafts a skill for it. Not code. A structured instruction set (SKILL.md) that captures the pattern, your preferences, and the right approach.

You review the skill. If it's good, you approve it. Now the agent uses it going forward — and continues refining it as more feedback comes in.

No other system has the agent composing and refining its own instruction sets from observed patterns and accumulated feedback.

### 5. A Shared Thinking Space

The daily journal isn't a log — it's a **shared cognitive space** where both you and the agent think.

You write your thoughts, reflections, and decisions. The agent writes its observations, actions, and learnings. Both are clearly attributed. At end of day, the reflection process consolidates what matters into long-term memory.

This means you can open today's journal in any markdown editor and see — in one file — what you thought, what the agent noticed, what decisions were made, and what was learned. No other system gives both human and agent a shared, transparent place to think.

### 6. Knowledge Graph — Automatic

Other AI tools search by keywords. AgntSpace builds a **knowledge graph** from every interaction — automatically.

The agent creates `[[wiki-links]]` in memory files as it works. Every person, project, decision, and concept gets connected. When you ask "What do I know about the Acme deal?" — the agent doesn't just search text. It traverses the graph: Acme Corp → Sarah Chen → B2B Partnership → Q2 Pivot → Investor Update. You get the full picture, not just keyword matches.

You never create links manually. You never manage a graph. The agent builds it from every conversation, email, task, and decision. The graph view in the UI is a visualization of what the agent already knows.

### 7. A Coach, Not Just a Tool

AgntSpace doesn't just execute tasks — it tracks your goals, predicts your behavior patterns, and gently nudges you when things stall.

"You tend to lose momentum on side projects after 2 weeks. The book outline hasn't been touched in 10 days."

It knows this because it's been reading your journal, tracking your tasks, and consolidating your patterns through weekly reflection. It's not a generic productivity tip — it's based on your actual behavior over time.

### 7. Honest Privacy

Every "private AI" product claims your data is safe. AgntSpace tells you exactly what happens:

- Your vault is local. Your embeddings are computed locally. Your search is local.
- But when the agent thinks, it sends context to a cloud LLM. Your notes, your profile, your memory — transmitted to Anthropic or OpenAI.
- Sensitive directories (finances, health, journal, goals) require your confirmation before sending.
- For full privacy, switch to Ollama. All reasoning stays on your machine. The architecture supports this as a first-class mode, not an afterthought.

No disclaimers buried in settings. Privacy is a first-class design principle.

### 8. Multi-Agent Orchestration

The product is called Agnt**Space** because it's not one agent — it's a **space where agents work together** under your contract, orchestrated by a main agent you trust. You build the team you need.

```mermaid
graph TD
    Human["You: 'Prepare the Q2 board deck'"]
    --> Main["Main Agent\n(decomposes task)"]
    Main --> R["Researcher\npull Q2 metrics"]
    Main --> A["Analyst\ncreate charts"]
    Main --> W["Writer\ndraft summary"]
    R --> Main2["Main Agent\n(assembles result)"]
    A --> Main2
    W --> Main2
    Main2 --> Human2["Delivers deck → You review → Feedback"]

    style Main fill:#4A90D9,color:#fff
    style Main2 fill:#4A90D9,color:#fff
    style R fill:#27AE60,color:#fff
    style A fill:#E67E22,color:#fff
    style W fill:#8E44AD,color:#fff
```

### 9. Everything Is a File

Your identity. Your agent's soul. The contract between you. Your memory. Your tasks. Your trust scores. Your goals. Your skills. All of it is **markdown files** you can open in any text editor.

There is no proprietary database that holds your life. There is no cloud account that locks you in. If AgntSpace disappears tomorrow, you still have every file, in a format that works with any markdown editor — Obsidian, VS Code, Logseq, Notepad, or whatever comes next.

The database (SQLite) is a search index. Delete it and it rebuilds from your files. Your files are the truth.

---

## The Cognitive Loop

```mermaid
graph LR
    Identity["Identity\nSOUL + USER + CONTRACT"]
    --> Thinking["Thinking\nJournal"]
    --> Delegating["Delegating\nSubagents"]
    --> Doing["Doing\nTasks"]
    --> Remembering["Remembering\nReflection → MEMORY"]
    --> Learning["Learning\nFeedback → Trust"]
    --> Growing["Growing\nSkillSchool"]
    --> Coaching["Coaching\nGoals + Nudges"]
    --> Autonomy["Autonomy\nTrust evolves"]
    --> Identity

    style Identity fill:#4A90D9,color:#fff
    style Thinking fill:#7B68EE,color:#fff
    style Delegating fill:#E67E22,color:#fff
    style Doing fill:#27AE60,color:#fff
    style Remembering fill:#8E44AD,color:#fff
    style Learning fill:#F39C12,color:#fff
    style Growing fill:#1ABC9C,color:#fff
    style Coaching fill:#E74C3C,color:#fff
    style Autonomy fill:#3498DB,color:#fff
```

---

## Requirements

Depends on how you run it:

| | agntspace.com | Desktop App | CLI |
|---|---|---|---|
| **You need** | A browser | Download installer | Python 3.11+ |
| **OS** | Any | Windows, macOS, Linux | Windows, macOS, Linux |
| **LLM** | Included (cloud) | Cloud: API key. Local: [Ollama](https://ollama.com) installed | Same as desktop |
| **Hardware (cloud LLM)** | Nothing | 2GB RAM, any CPU | Same |
| **Hardware (local LLM)** | N/A | 16GB+ RAM, modern CPU/GPU | Same |

**That's it.** No Docker required. No database to install. No Redis, no Postgres, no Node.js. SQLite is bundled with Python. FastEmbed downloads its model on first run (~80MB).

### LLM — The Brain Behind the Agent

| Mode | Provider | What you need | Quality | Privacy | Cost |
|------|----------|--------------|---------|---------|------|
| **Cloud** | Anthropic (Claude) | API key from [console.anthropic.com](https://console.anthropic.com) | Best | Vault content sent to provider | Pay per use (~$3-15/mo typical) |
| **Cloud** | OpenAI (GPT) | API key from [platform.openai.com](https://platform.openai.com) | Great | Vault content sent to provider | Pay per use |
| **Local** | Ollama | Install [Ollama](https://ollama.com) + download a model | Good (depends on model) | Total privacy — nothing leaves your machine | Free (your hardware) |

---

## Getting Started

### Option A: agntspace.com (nothing to install)

Sign up at **agntspace.com** and start talking to your agent in the browser. Same features, hosted for you. Export anytime.

### Option B: Desktop App (no terminal)

Download for [Windows](.) | [macOS](.) | [Linux](.) — double-click, visual setup wizard, runs in system tray.

### Option C: One-Line Install

**macOS / Linux:**
```bash
curl -fsSL https://agntspace.com/install.sh | bash
```

**Windows** (PowerShell):
```powershell
irm https://agntspace.com/install.ps1 | iex
```

**Or manually:**
```bash
pip install agntspace
agntspace init
```

Interactive setup: creates `~/.agntspace/`, configures LLM (cloud or Ollama), runs onboarding conversation to generate your PROFILE.md and CONTRACT.md.

```bash
agntspace start              # Start server
agntspace chat               # Talk via CLI
agntspace delegate "task"    # Delegate directly
agntspace journal "thought"  # Quick journal entry
# Web UI → http://localhost:8000
```

### No Markdown Required

Everything works through the web UI. Power users can edit vault files directly — changes sync instantly.

| Action | Web UI | File (optional) |
|--------|--------|----------------|
| Your profile | Control Panel → Profile | `vault/PROFILE.md` |
| Agent permissions | Control Panel → Contract | `vault/CONTRACT.md` |
| Agent personality | Control Panel → Agent | `vault/SOUL.md` |
| Journal | Journal page | `vault/journal/*.md` |
| Tasks | Tasks board | `vault/tasks/*.md` |
| Goals | Goals page | `vault/goals/*.md` |
| Subagents | Control Panel → Agents | `vault/agents/*.md` |
| Trust scores | Control Panel → Trust | `vault/TRUST.md` |

---

## Key Concepts

### Task Delegation

| Mode | Behavior |
|------|----------|
| **Just do it** | Agent executes, reports when done |
| **Review** | Agent executes, you approve before finalizing |
| **Recommend** | Agent researches, presents options, you decide |
| **Watch** | Agent monitors, alerts when triggered |

Tasks are markdown files with progress logs, escalation notes, and feedback. Agent escalates gracefully when stuck.

```mermaid
graph LR
    D["Delegated"] --> P["In Progress"]
    P --> B["Blocked\n(escalate)"]
    B --> P
    P --> R["Review"]
    P --> Done["Done"]
    R --> Done
    R --> Rev["Revision\nNeeded"]
    Rev --> P
    Done --> F["Feedback\ngood / redo"]
    F --> T["Trust\nupdated"]

    style D fill:#3498DB,color:#fff
    style P fill:#F39C12,color:#fff
    style B fill:#E74C3C,color:#fff
    style R fill:#8E44AD,color:#fff
    style Done fill:#27AE60,color:#fff
    style F fill:#1ABC9C,color:#fff
    style T fill:#4A90D9,color:#fff
```

### SkillSchool

Agent notices repeating patterns, drafts a skill (SKILL.md), proposes it for your review. Three triggers: pattern detection, feedback accumulation, human request. Skills refine over time as feedback continues.

### Journal (Shared Thinking Space)

Daily file, four sections: **Thoughts** (human), **Observations** (agent), **Decisions** (both, with reasoning), **Learnings** (both). Thinking-out-loud detection in chat: agent asks "Save to journal?" Configurable: ask, auto, or off.

### Reflection

End-of-day: journal → reflection draft → (your approval or auto) → MEMORY.md updated. Weekly: 7 days synthesized into patterns and progress. Feeds coach, SkillSchool, and trust recalculation.

### Coach

Tracks goals (`vault/goals/*.md`), predicts behavior patterns, nudges gently on stalls, captures aspirations from conversation, celebrates wins. Opt-in, configurable frequency and quiet hours.

### 4-Tier Proactivity

| Tier | Behavior |
|------|----------|
| **Observer** | Only responds when asked |
| **Advisor** | Suggests but never acts |
| **Assistant** | Acts on routine, asks for non-routine |
| **Partner** | Full autonomy within contract boundaries |

### Autopilot Mode

Enable for travel/busy periods with expiry date. Reflections auto-commit, trusted domains auto-approve, notifications batched to daily digest. Auto-disables with welcome-back summary.

### Honest Privacy

**Always local:** vault, embeddings (FastEmbed), search index (SQLite), heartbeat state.
**Sent to cloud LLM (cloud mode):** SOUL.md, USER.md, MEMORY.md excerpts, vault content for current task, conversation history. Sensitive dirs (finances, health, journal, goals) gated — agent asks first.
**Full privacy:** switch to Ollama. All reasoning on-device.

### Everything Is a File

Identity, memory, tasks, trust, goals, skills, subagent definitions — all markdown. Database is a derived search index. Delete it, it rebuilds. No proprietary format. No vendor lock-in.

---

## Proactive Systems

| System | Frequency | What it does |
|--------|-----------|-------------|
| **Heartbeat** | Every 30 min | Gathers integration state, diffs, logs to journal, notifies on changes |
| **Task scheduler** | Continuous | Checks pending/watch tasks, triggers on conditions |
| **Daily reflection** | End of day | Journal → reflection draft → (approval) → MEMORY.md |
| **Weekly cycle** | End of week | Reflection → coach review → SkillSchool analysis → trust recalculation |
| **Digest** | Daily (autopilot) | Batches notifications into a single summary |

---

## Stack

| Layer | Technology |
|-------|-----------|
| Backend | Python, FastAPI, WebSocket |
| Frontend | React, Vite, TypeScript, Zustand |
| Database | SQLite + sqlite-vec (local, optionally encrypted) |
| Embeddings | FastEmbed (local, never cloud) |
| Knowledge | Markdown vault (YAML frontmatter + wiki-links) |
| LLM | Anthropic / OpenAI **or** Ollama (local) |
| Desktop | Tauri (thin wrapper, system tray) |

## Project Structure

```
agntspace/
├── server/                    Python backend (FastAPI)
│   └── src/agntspace/
│       ├── api/               HTTP + WebSocket routes
│       ├── agent/             Main agent, orchestrator, subagent runtime
│       ├── llm/               Provider abstraction (cloud + local)
│       ├── vault/             Read/write/search markdown files
│       ├── journal/           Cognitive journal system
│       ├── tasks/             Task delegation + lifecycle
│       ├── trust/             Trust evolution engine
│       ├── skillschool/       Agent self-improvement
│       ├── coach/             Goal tracking + nudges
│       ├── skills/            Skill loader + matcher
│       ├── memory/            Conversation buffer + search
│       ├── domains/           9 Life OS modules
│       ├── channels/          Telegram, WhatsApp, Discord, Slack
│       ├── integrations/      Gmail, GCal, GitHub
│       ├── automation/        Heartbeat, scheduler
│       └── security/          Sanitizer, contract enforcement
├── ui/                        React frontend
├── desktop/                   Tauri desktop app
├── packages/plugin-sdk/       Python plugin SDK
├── defaults/                  Template vault + skills (copied on first run)
├── tests/                     Unit + integration + E2E
├── docs/                      Documentation
├── scripts/                   Dev, build, generators
└── deploy/                    Docker, systemd
```

## User Data

```
~/.agntspace/                       ← app_dir (FIXED — config, db, credentials, logs)
├── config.toml
├── agntspace.db
├── credentials.json
└── logs/

<your folder>/                       ← vault root (any directory you pick)
├── agntspace-inbox/                 ← drop zone
├── agntspace-journal/               ← your journal + agent observations
│   ├── user/                        YOU write here (agent reads)
│   └── agnt/                        AGENT writes here (you read)
├── agntspace-knowledge/             ← knowledge bases (per topic)
│   └── {topic}/
│       ├── wiki/                    Compiled articles with [[backlinks]]
│       ├── library/                 Organized sources
│       └── inbox/                   Per-KB drop zone
├── agntspace-projects/              ← projects (tasks live inside each project)
│   └── {slug}/
│       ├── PROJECT.md
│       ├── tasks/
│       ├── notes/
│       └── output/
├── agntspace-goals/                 ← first-class goals (cross-project)
│
└── agntspace/                       ← agent internals (never touch manually)
    ├── system/
    │   ├── identity/                SOUL, USER, PROFILE, CONTRACT, TRUST, RELATIONSHIP
    │   ├── agents/                  Subagent definitions
    │   ├── skills/                  AI instruction sets
    │   ├── security/                Guardian, blacklist, audit
    │   └── logs/                    Server + simulation logs
    └── memory/
        ├── MEMORY.md                Long-term memory (assembled view)
        ├── summaries/               Layered temporal summaries
        ├── pending/                 Awaiting user approval
        └── graph/                   SPO knowledge graph
```

---

## Status

Active development. Core systems implemented: chat, vault, LLM abstraction, journal, task delegation, trust evolution, contract enforcement, onboarding, dashboard, and control panel.

## Extending AgntSpace

AgntSpace is **proprietary software** maintained by [Archer Futura Technologies AB](https://agntspace.com) (Stockholm). The core product is not open source. The **[community hub](https://github.com/agntspace/agntspace-community)** is where you can extend it:

- **Skills** — teach the agent new behaviours with Markdown + YAML (no code)
- **Plugins** — register tools, hooks, and API routes in Python
- **Vault templates** — ship curated starter vaults for specific workflows

See [docs.agntspace.com](https://docs.agntspace.com) for authoring guides.

## Support

- **Bug reports / feature requests** — [community issue tracker](https://github.com/agntspace/agntspace-community/issues)
- **Questions / show-and-tell** — [community Discussions](https://github.com/agntspace/agntspace-community/discussions)
- **Commercial support** — [agntspace.com](https://agntspace.com)

## License

AgntSpace is proprietary software. By installing `agntspace` from PyPI you agree to the terms at [agntspace.com/terms](https://agntspace.com/terms).

Free for personal use. Commercial licensing for organisations is available — contact `licensing@agntspace.com`.
