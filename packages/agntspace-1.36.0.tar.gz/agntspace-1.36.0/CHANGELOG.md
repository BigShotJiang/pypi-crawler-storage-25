# CHANGELOG

<!-- version list -->

## v1.3.7 (2026-04-09)

### Bug Fixes

- Improve installer scripts and error handling for AgntSpace setup
  ([`aa405b4`](https://github.com/agntspace/agntspace/commit/aa405b48ab21f59be69b8bf1e4d921d4d3cf773b))


## v1.3.6 (2026-04-09)

### Bug Fixes

- Include ui_dist directory in wheel build and update app to serve UI correctly
  ([`7f0da20`](https://github.com/agntspace/agntspace/commit/7f0da20f1d1acffd567365baf3db110efe335b10))


## v1.3.5 (2026-04-09)

### Bug Fixes

- Include defaults directory in wheel build
  ([`2c1fe11`](https://github.com/agntspace/agntspace/commit/2c1fe117f97658bc8641e757703b1a23a738c081))


## v1.3.4 (2026-04-09)

### Bug Fixes

- Improve AgntSpace installation error handling and provide alias instructions
  ([`eab7899`](https://github.com/agntspace/agntspace/commit/eab78996efbd837da90e61581a5fb810c44c3bfc))


## v1.3.3 (2026-04-09)

### Bug Fixes

- Streamline AgntSpace installation by adding --no-cache-dir and suppressing output
  ([`e77b9b1`](https://github.com/agntspace/agntspace/commit/e77b9b107f8591b37d8c4fc0274139df1e2c5323))


## v1.3.2 (2026-04-08)

### Bug Fixes

- Use python3 -m pip instead of pip3 in install script to avoid version mismatch
  ([`41f7e4b`](https://github.com/agntspace/agntspace/commit/41f7e4b50497b1b2112eda375572a85137f60b96))


## v1.3.1 (2026-04-08)

### Bug Fixes

- Add --no-cache-dir to install script to prevent stale package versions
  ([`fb9c204`](https://github.com/agntspace/agntspace/commit/fb9c204e92d9862298a2ea1a499f6a1f5d1bba4a))


## v1.3.0 (2026-04-08)

### Features

- Update version to 1.1.1 and add fastembed dependency for semantic search
  ([`2a9d2a3`](https://github.com/agntspace/agntspace/commit/2a9d2a3bb8b4474eba12c8248a3b0dfa09225ee0))


## v1.2.0 (2026-04-08)

### Features

- Add installation scripts for Windows and Linux
  ([`1432a5c`](https://github.com/agntspace/agntspace/commit/1432a5cc5f8ee47d91747c4a919458efd3ee4c26))


## v1.1.0 (2026-04-08)

### Features

- Enable publishing to PyPI in release workflow
  ([`c15b197`](https://github.com/agntspace/agntspace/commit/c15b197a097b7c2b00b7340bc9d537e179d70eb9))


## v1.0.0 (2026-04-08)

- Initial Release
