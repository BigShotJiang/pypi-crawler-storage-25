"""Agent context assembly from vault identity files."""

from __future__ import annotations

from agntspace.vault.reader import VaultDocument, VaultReader


def load_identity_context(vault: VaultReader) -> dict[str, VaultDocument]:
    """Load all identity files needed for the system prompt.

    Returns dict keyed by file stem: SOUL, USER, PROFILE, CONTRACT, MEMORY.
    """
    return vault.read_identity_files()
