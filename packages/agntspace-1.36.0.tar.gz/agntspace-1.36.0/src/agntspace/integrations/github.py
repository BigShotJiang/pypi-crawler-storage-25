"""GitHub integration."""

from __future__ import annotations

import logging

from agntspace.integrations.base import Integration, IntegrationStatus

log = logging.getLogger(__name__)


class GitHubIntegration(Integration):
    """GitHub integration via personal access token."""

    name = "github"
    description = "Monitor repos, PRs, and issues"

    def __init__(self) -> None:
        self._connected = False
        self._token: str | None = None

    async def connect(self, credentials: dict) -> None:
        self._token = credentials.get("token", "")
        if self._token:
            self._connected = True
            log.info("GitHub integration connected")

    async def disconnect(self) -> None:
        self._connected = False
        self._token = None

    async def check_status(self) -> IntegrationStatus:
        return IntegrationStatus(name=self.name, connected=self._connected)

    async def sync(self) -> dict:
        if not self._connected:
            return {"error": "Not connected"}
        # TODO: Implement GitHub API sync
        return {"repos": 0, "prs": 0, "status": "stub"}

    @property
    def is_connected(self) -> bool:
        return self._connected
