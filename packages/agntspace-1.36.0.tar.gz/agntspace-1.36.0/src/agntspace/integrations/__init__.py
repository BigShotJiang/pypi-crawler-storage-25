"""Integrations: external service connections (Gmail, GCal, GitHub)."""

from agntspace.integrations.base import Integration
from agntspace.integrations.manager import IntegrationManager

__all__ = ["Integration", "IntegrationManager"]
