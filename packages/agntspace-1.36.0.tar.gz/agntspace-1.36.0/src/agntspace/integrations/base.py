"""Base integration interface for external services."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field


@dataclass
class IntegrationStatus:
    """Status of an integration."""

    name: str
    connected: bool
    last_sync: str = ""
    error: str = ""
    metadata: dict = field(default_factory=dict)


class Integration(ABC):
    """Abstract base for external service integrations."""

    name: str = "unknown"
    description: str = ""

    @abstractmethod
    async def connect(self, credentials: dict) -> None:
        """Establish connection with provided credentials."""

    @abstractmethod
    async def disconnect(self) -> None:
        """Disconnect from the service."""

    @abstractmethod
    async def check_status(self) -> IntegrationStatus:
        """Check connection status."""

    @abstractmethod
    async def sync(self) -> dict:
        """Sync data from the service. Returns summary of changes."""

    @property
    @abstractmethod
    def is_connected(self) -> bool:
        """Whether the integration is currently connected."""
