"""Google Calendar integration."""

from __future__ import annotations

import logging

from agntspace.integrations.base import Integration, IntegrationStatus

log = logging.getLogger(__name__)


class GCalIntegration(Integration):
    """Google Calendar integration."""

    name = "gcal"
    description = "Read and manage calendar events"

    def __init__(self) -> None:
        self._connected = False

    async def connect(self, credentials: dict) -> None:
        self._connected = True
        log.info("Google Calendar integration connected")

    async def disconnect(self) -> None:
        self._connected = False

    async def check_status(self) -> IntegrationStatus:
        return IntegrationStatus(name=self.name, connected=self._connected)

    async def sync(self) -> dict:
        if not self._connected:
            return {"error": "Not connected"}
        # TODO: Implement GCal API sync
        return {"events": 0, "status": "stub"}

    @property
    def is_connected(self) -> bool:
        return self._connected
