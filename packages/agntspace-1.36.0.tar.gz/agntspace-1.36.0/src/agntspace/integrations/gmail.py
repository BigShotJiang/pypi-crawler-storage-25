"""Gmail integration."""

from __future__ import annotations

import logging

from agntspace.integrations.base import Integration, IntegrationStatus

log = logging.getLogger(__name__)


class GmailIntegration(Integration):
    """Gmail integration via Google API."""

    name = "gmail"
    description = "Read and draft emails via Gmail API"

    def __init__(self) -> None:
        self._connected = False
        self._credentials: dict | None = None

    async def connect(self, credentials: dict) -> None:
        """Connect with OAuth credentials."""
        self._credentials = credentials
        self._connected = True
        log.info("Gmail integration connected")

    async def disconnect(self) -> None:
        self._connected = False
        self._credentials = None

    async def check_status(self) -> IntegrationStatus:
        return IntegrationStatus(
            name=self.name,
            connected=self._connected,
        )

    async def sync(self) -> dict:
        """Sync recent emails (stub — requires OAuth implementation)."""
        if not self._connected:
            return {"error": "Not connected"}
        # TODO: Implement Gmail API sync
        return {"emails": 0, "status": "stub"}

    @property
    def is_connected(self) -> bool:
        return self._connected
