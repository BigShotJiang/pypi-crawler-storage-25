"""SkillSchool: agent self-improvement through pattern detection."""

from agntspace.skillschool.service import SkillSchoolService

__all__ = ["SkillSchoolService"]
