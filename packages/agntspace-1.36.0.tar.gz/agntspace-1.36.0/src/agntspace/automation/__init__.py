"""Automation: heartbeat, scheduler, and background tasks."""
