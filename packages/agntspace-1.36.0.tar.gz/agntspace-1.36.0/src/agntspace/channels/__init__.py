"""Channels: messaging platform integrations (Telegram, WhatsApp, Discord, Slack)."""

from agntspace.channels.base import Channel, ChannelMessage
from agntspace.channels.manager import ChannelManager

__all__ = ["Channel", "ChannelMessage", "ChannelManager"]
