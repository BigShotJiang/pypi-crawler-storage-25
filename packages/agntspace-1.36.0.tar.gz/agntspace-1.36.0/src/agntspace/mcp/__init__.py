"""MCP (Model Context Protocol) — server + client.

Server: exposes AgntSpace tools to any MCP-compatible client.
Client: connects to external MCP servers for additional capabilities.
"""
