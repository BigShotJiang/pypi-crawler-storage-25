"""Domains: 9 Life OS modules for organizing vault content."""

from agntspace.domains.base import DomainService

__all__ = ["DomainService"]
