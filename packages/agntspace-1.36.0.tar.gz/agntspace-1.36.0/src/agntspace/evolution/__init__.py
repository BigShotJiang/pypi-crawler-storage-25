"""Evolution — repo-native Bayesian self-improvement control plane.

Purpose: learn from verified execution traces, compile reusable execution
policies ("Reflexes"), mine failure patterns ("Anti-Reflexes"), and route
future work with uncertainty-aware selection.

Goal (binding — see system/evolution/SKILL.md or docs for canonical version):
    Improve from verified work, not confident narration. Improvement
    must remain governed, auditable, reversible, and compatible with
    AgntSpace's file-native + contract-first architecture. The goal is
    not unconstrained autonomy. The goal is better judgment, better
    routing, better execution, and better calibration under uncertainty.

Non-negotiables (enforced in kernel.py + checked at every reflex load):
  - Verified work only — learning sensors read ScopeMutations + result_status,
    never narrated success.
  - Governed — Protected Kernel allow/forbid list locks contract,
    security, audit, privacy, emergency stop, approval boundaries.
  - Auditable — every run/selection/promotion writes both a SQLite row
    AND a readable vault artifact under system/evolution/.
  - Reversible — every promotion records a rollback_target; YAML
    kill switch disables the selector without code changes.
  - No proxy worship — utility is a weighted geometric mean (vetoes,
    not averages); writes only score if verified AND not rolled back.
"""

from __future__ import annotations

from agntspace.evolution.schemas import (
    POLICY_BASELINE_RANDOM,
    POLICY_INCUMBENT_DEFAULT,
    AntiReflex,
    OutcomeVector,
    PolicyChoice,
    Promotion,
    Reflex,
    ReplayJob,
    RunManifest,
    SelectorTelemetry,
)

__all__ = [
    "AntiReflex",
    "OutcomeVector",
    "POLICY_BASELINE_RANDOM",
    "POLICY_INCUMBENT_DEFAULT",
    "PolicyChoice",
    "Promotion",
    "Reflex",
    "ReplayJob",
    "RunManifest",
    "SelectorTelemetry",
]
