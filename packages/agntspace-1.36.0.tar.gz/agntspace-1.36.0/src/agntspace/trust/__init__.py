"""Trust: Bayesian domain trust evolution from multi-signal feedback."""

from agntspace.trust.service import (
    BayesianConfig,
    BetaTrustScore,
    TrustCheckResult,
    TrustService,
    compute_approval_weight,
    detect_correction,
    domain_for_action,
    override_to_trust_signal,
    set_trust_domain_map,
    set_trust_signals,
)

__all__ = [
    "BayesianConfig",
    "BetaTrustScore",
    "TrustCheckResult",
    "TrustService",
    "compute_approval_weight",
    "detect_correction",
    "domain_for_action",
    "override_to_trust_signal",
    "set_trust_domain_map",
    "set_trust_signals",
]
