"""Allow ``python -m agntspace`` as an alternative to the console script."""

from agntspace.cli import app

if __name__ == "__main__":
    app()
