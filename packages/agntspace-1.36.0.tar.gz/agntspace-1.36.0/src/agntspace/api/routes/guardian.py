"""Guardian / blacklist API endpoints."""

from __future__ import annotations

from fastapi import APIRouter, Request
from pydantic import BaseModel

router = APIRouter(prefix="/guardian", tags=["guardian"])


class BlacklistAddRequest(BaseModel):
    value: str
    category: str  # domain | email | account | phone | ip | keyword | url_pattern
    reason: str
    source: str = "user"


class ScanRequest(BaseModel):
    text: str


class ApprovalRequest(BaseModel):
    value: str
    category: str


@router.get("/blacklist")
async def get_blacklist(request: Request) -> list[dict]:
    """Get the full blacklist."""
    guardian = request.app.state.guardian
    entries = guardian.get_blacklist()
    return [
        {
            "value": e.value,
            "category": e.category,
            "reason": e.reason,
            "source": e.source,
            "added": e.added,
            "status": e.status,
        }
        for e in entries
    ]


@router.post("/blacklist")
async def add_to_blacklist(request: Request, body: BlacklistAddRequest) -> dict:
    """Add an entry to the blacklist."""
    guardian = request.app.state.guardian
    entry = guardian.add_entry(
        value=body.value,
        category=body.category,
        reason=body.reason,
        source=body.source,
    )
    return {"value": entry.value, "category": entry.category, "status": entry.status}


@router.delete("/blacklist")
async def remove_from_blacklist(request: Request, body: ApprovalRequest) -> dict:
    """Remove an entry from the blacklist."""
    guardian = request.app.state.guardian
    removed = guardian.remove_entry(body.value, body.category)
    return {"removed": removed}


@router.post("/blacklist/approve")
async def approve_recommendation(request: Request, body: ApprovalRequest) -> dict:
    """Approve a pending agent recommendation."""
    guardian = request.app.state.guardian
    approved = guardian.approve_recommendation(body.value, body.category)
    return {"approved": approved}


@router.post("/blacklist/reject")
async def reject_recommendation(request: Request, body: ApprovalRequest) -> dict:
    """Reject a pending agent recommendation."""
    guardian = request.app.state.guardian
    rejected = guardian.reject_recommendation(body.value, body.category)
    return {"rejected": rejected}


@router.get("/blacklist/pending")
async def get_pending(request: Request) -> list[dict]:
    """Get pending agent recommendations."""
    guardian = request.app.state.guardian
    entries = guardian.get_pending_recommendations()
    return [
        {
            "value": e.value,
            "category": e.category,
            "reason": e.reason,
            "added": e.added,
        }
        for e in entries
    ]


@router.post("/scan")
async def scan_content(request: Request, body: ScanRequest) -> dict:
    """Scan text content against the blacklist."""
    guardian = request.app.state.guardian
    result = guardian.scan_text(body.text)
    return {"safe": result.safe, "threats": result.threats}


@router.get("/stats")
async def guardian_stats(request: Request) -> dict:
    """Get blacklist statistics."""
    guardian = request.app.state.guardian
    return guardian.get_stats()
