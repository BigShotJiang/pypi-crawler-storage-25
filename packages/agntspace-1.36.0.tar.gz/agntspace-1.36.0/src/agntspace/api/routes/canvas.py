"""Canvas A2UI REST API — CRUD for items and snapshots."""

from __future__ import annotations

from fastapi import APIRouter, Request
from pydantic import BaseModel

router = APIRouter(prefix="/canvas", tags=["canvas"])


# ── request models ───────────────────────────────────────────────────────

class PushBody(BaseModel):
    content: str
    content_type: str = "markdown"
    title: str = ""

class UpdateBody(BaseModel):
    content: str | None = None
    title: str | None = None
    content_type: str | None = None

class NoteBody(BaseModel):
    note: str

class PinBody(BaseModel):
    pinned: bool

class ReorderBody(BaseModel):
    ids: list[str]

class SnapshotBody(BaseModel):
    name: str


# ── items ────────────────────────────────────────────────────────────────

@router.get("")
async def get_canvas(request: Request) -> dict:
    canvas = request.app.state.canvas
    items = await canvas.get_items()
    return {"items": items}


@router.post("/items")
async def push_item(request: Request, body: PushBody) -> dict:
    canvas = request.app.state.canvas
    item = await canvas.push(body.content, body.content_type, body.title)
    return {"item": item}


@router.patch("/items/{item_id}")
async def update_item(request: Request, item_id: str, body: UpdateBody) -> dict:
    canvas = request.app.state.canvas
    item = await canvas.update(item_id, content=body.content, title=body.title, content_type=body.content_type)
    if not item:
        return {"error": "Item not found"}
    return {"item": item}


@router.delete("/items/{item_id}")
async def delete_item(request: Request, item_id: str) -> dict:
    canvas = request.app.state.canvas
    removed = await canvas.remove(item_id)
    return {"removed": removed}


@router.patch("/items/{item_id}/pin")
async def pin_item(request: Request, item_id: str, body: PinBody) -> dict:
    canvas = request.app.state.canvas
    item = await canvas.set_pinned(item_id, body.pinned)
    if not item:
        return {"error": "Item not found"}
    return {"item": item}


@router.patch("/items/{item_id}/note")
async def set_note(request: Request, item_id: str, body: NoteBody) -> dict:
    canvas = request.app.state.canvas
    item = await canvas.set_user_note(item_id, body.note)
    if not item:
        return {"error": "Item not found"}
    return {"item": item}


@router.post("/reorder")
async def reorder_items(request: Request, body: ReorderBody) -> dict:
    canvas = request.app.state.canvas
    await canvas.reorder(body.ids)
    return {"reordered": True}


@router.post("/reset")
async def reset_canvas(request: Request) -> dict:
    canvas = request.app.state.canvas
    await canvas.reset()
    return {"reset": True}


# ── snapshots ────────────────────────────────────────────────────────────

@router.get("/snapshots")
async def list_snapshots(request: Request) -> dict:
    canvas = request.app.state.canvas
    snaps = await canvas.snapshot_list()
    return {"snapshots": snaps}


@router.post("/snapshots")
async def save_snapshot(request: Request, body: SnapshotBody) -> dict:
    canvas = request.app.state.canvas
    snap = await canvas.snapshot_save(body.name)
    return {"snapshot": snap}


@router.post("/snapshots/{snapshot_id}/restore")
async def restore_snapshot(request: Request, snapshot_id: str) -> dict:
    canvas = request.app.state.canvas
    ok = await canvas.snapshot_restore(snapshot_id)
    return {"restored": ok}


@router.delete("/snapshots/{snapshot_id}")
async def delete_snapshot(request: Request, snapshot_id: str) -> dict:
    canvas = request.app.state.canvas
    ok = await canvas.snapshot_delete(snapshot_id)
    return {"deleted": ok}
