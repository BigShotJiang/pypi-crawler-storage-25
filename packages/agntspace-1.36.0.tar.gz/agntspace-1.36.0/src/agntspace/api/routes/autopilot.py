"""Autopilot mode API endpoints."""

from __future__ import annotations

from fastapi import APIRouter, Request
from pydantic import BaseModel

router = APIRouter(prefix="/autopilot", tags=["autopilot"])


class AutopilotToggleRequest(BaseModel):
    enabled: bool
    until: str | None = None  # YYYY-MM-DD expiry


@router.get("")
async def autopilot_status(request: Request) -> dict:
    """Get autopilot status."""
    return request.app.state.autopilot.status()


@router.post("")
async def toggle_autopilot(request: Request, body: AutopilotToggleRequest) -> dict:
    """Enable or disable autopilot."""
    autopilot = request.app.state.autopilot
    if body.enabled:
        autopilot.enable(until=body.until)
    else:
        return autopilot.disable()
    return autopilot.status()


@router.get("/digest")
async def get_digest(request: Request) -> list[dict]:
    """Get queued notifications digest."""
    return request.app.state.autopilot.get_digest()


@router.post("/digest/clear")
async def clear_digest(request: Request) -> dict:
    """Clear the notification digest queue."""
    count = request.app.state.autopilot.clear_digest()
    return {"cleared": count}
