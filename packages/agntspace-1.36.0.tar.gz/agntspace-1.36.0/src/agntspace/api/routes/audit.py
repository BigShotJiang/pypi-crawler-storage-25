"""Audit trail API endpoints."""

from __future__ import annotations

from fastapi import APIRouter, Request

router = APIRouter(prefix="/audit", tags=["audit"])


@router.get("")
async def get_audit_log(
    request: Request,
    limit: int = 50,
    action: str | None = None,
    date: str | None = None,
) -> list[dict]:
    """Query the audit trail."""
    audit = request.app.state.audit
    return audit.get_entries(limit=limit, action_filter=action, date_filter=date)


@router.get("/today")
async def get_today(request: Request) -> list[dict]:
    """Get today's audit entries."""
    audit = request.app.state.audit
    return audit.get_today()


@router.post("/purge")
async def purge_audit(request: Request, before: str | None = None) -> dict:
    """Purge audit entries."""
    audit = request.app.state.audit
    count = audit.purge(before_date=before)
    return {"purged": count}
