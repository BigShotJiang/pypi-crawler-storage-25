"""API: FastAPI routes and WebSocket handlers."""
