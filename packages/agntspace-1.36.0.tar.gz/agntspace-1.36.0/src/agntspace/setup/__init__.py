"""Setup: first-run initialization."""

from agntspace.setup.init import run_init

__all__ = ["run_init"]
