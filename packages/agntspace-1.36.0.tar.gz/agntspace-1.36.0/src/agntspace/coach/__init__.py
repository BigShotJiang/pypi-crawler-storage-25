"""Coach: goal tracking, pattern prediction, and gentle nudges."""

from agntspace.coach.service import CoachService

__all__ = ["CoachService"]
