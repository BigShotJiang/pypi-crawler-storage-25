"""Journal: daily cognitive space for human and agent."""

from agntspace.journal.service import JournalService

__all__ = ["JournalService"]
