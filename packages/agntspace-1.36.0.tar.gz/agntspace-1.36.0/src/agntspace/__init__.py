"""AgntSpace — Personal AI agent that runs your life alongside you."""

__version__ = "0.1.0"
