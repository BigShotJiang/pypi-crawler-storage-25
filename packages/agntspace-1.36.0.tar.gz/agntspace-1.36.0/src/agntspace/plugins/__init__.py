"""AgntSpace plugin system — extensible tools, integrations, and channels."""
