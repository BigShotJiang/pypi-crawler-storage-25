# OneNote Import

Imports Microsoft OneNote notebooks into your vault as markdown. Uses the OneNote
desktop app on Windows via COM — no Azure app, no OAuth, no cloud round-trip.

## Requirements

- Windows
- OneNote desktop app installed and signed in to the account whose notebooks you want
- `pywin32` Python package (auto-installed with the `onenote` extra)

```bash
pip install "agntspace[onenote]"
```

## How it works

1. Enable the plugin from `/plugins`.
2. Trigger an import either from chat ("import my OneNote notebooks") or via
   `POST /api/plugins/onenote-import/run`.
3. The plugin connects to the OneNote desktop app (via PowerShell's COM
   bridge — no pywin32 needed), walks every notebook / section / page,
   converts each page to markdown, and writes into
   `<vault>/OneNote/<Notebook>/<Section>/<Page>.md`.
4. Only the `.md` file is written — no XML sidecar. OneNote itself is the
   source of truth; re-running the import re-fetches fresh XML from COM.
5. Inline images are extracted to `<vault>/OneNote/<Notebook>/<section>/.images/`
   and the markdown references them as relative links. The dot-prefixed folder
   name keeps the inbox watcher from treating the image files as standalone
   sources.
6. The inbox watcher picks up the new markdown and routes it through the normal
   KB ingest pipeline — no separate configuration needed.

## Incremental imports

A state file at `<vault>/OneNote/.onenote-state.json` records each page's
`lastModifiedTime` after a successful import. On the next run, unchanged pages
are skipped. To force a full re-import, delete the state file.

## Tool parameters

- `target_folder` (string, default `"OneNote"`) — vault subfolder for imported
  notebooks
- `notebooks` (array, optional) — display names to restrict to; omit to import
  everything the signed-in user can see
- `incremental` (bool, default `true`) — skip pages unchanged since last import

Returns `{notebooks_imported, pages_imported, pages_skipped, errors, target_folder}`.

## Limitations

- Ink / handwriting is skipped (inserted as `<!-- skipped: ink annotation -->`
  in the markdown output)
- Password-protected sections are skipped with a log warning
- The OneNote desktop app must be running or launchable — if it's not installed,
  import fails fast with a clear message
