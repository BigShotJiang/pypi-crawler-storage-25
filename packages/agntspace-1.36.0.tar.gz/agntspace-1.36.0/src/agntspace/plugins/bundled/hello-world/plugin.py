"""Hello World plugin — demonstrates the AgntSpace plugin API.

Registers a single tool `greet_user` that returns a greeting.
"""

from agntspace.plugins.base import PluginBase, PluginContext


class HelloWorldPlugin(PluginBase):
    def init(self, ctx: PluginContext) -> None:
        ctx.log.debug("Hello World plugin initializing")

        def greet_handler(inp: dict) -> dict:
            name = inp.get("name", "friend")
            return {"greeting": f"Hello, {name}! Welcome to AgntSpace."}

        ctx.registry.register_tool(
            name="greet_user",
            description="Greet a user by name. A sample plugin tool.",
            input_schema={
                "type": "object",
                "properties": {
                    "name": {"type": "string", "description": "Name of the person to greet"},
                },
                "required": ["name"],
            },
            handler=greet_handler,
            contract_action="canvas_push",
        )

    def shutdown(self) -> None:
        pass


plugin = HelloWorldPlugin()
