"""MCP tool registration modules."""
