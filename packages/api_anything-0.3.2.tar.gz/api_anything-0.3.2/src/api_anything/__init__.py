"""api-anything has been renamed to `invoco`.

This 0.3.2 release is the final api-anything package. It depends on invoco and
prints a deprecation notice on import. All code that previously lived here has
moved to the `invoco` package. Install the new name:

    pip install invoco

See https://github.com/aiking931931/invoco for details.
"""
from __future__ import annotations

import sys

__version__ = "0.3.2"

_NOTICE = (
    "\n[api-anything] DEPRECATION: api-anything has been renamed to `invoco`.\n"
    "[api-anything] Install the new name: `pip install invoco`\n"
    "[api-anything] This 0.3.2 release is the last api-anything package; no further\n"
    "[api-anything] api-anything versions will be published. See\n"
    "[api-anything] https://github.com/aiking931931/invoco for the active project.\n"
)

# Emit the notice once per import, to stderr so logs pick it up but stdout stays clean.
print(_NOTICE, file=sys.stderr)

try:
    import invoco as _invoco  # noqa: F401  — pulled via dependency

    # Re-export for minimal compatibility — consumers can still
    # `from api_anything import expose` and keep working.
    from invoco import expose, registry, ExposedFunction  # noqa: F401
except ImportError:  # pragma: no cover - defensive; invoco is a hard dep
    pass


__all__ = ["__version__", "expose", "registry", "ExposedFunction"]
