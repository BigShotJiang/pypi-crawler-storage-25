# api-anything — DEPRECATED, renamed to `invoco`

**This project has moved.** Install `invoco` instead:

```bash
pip install invoco
```

- New home: https://github.com/aiking931931/invoco
- New PyPI: https://pypi.org/project/invoco/
- `api-anything` 0.3.2 is the final release. It prints a deprecation notice and re-exports from `invoco` for minimal compatibility. No further `api-anything` versions will be published.

## Migration

```python
# before
from api_anything import expose   # still works via re-export in 0.3.2, will stop once yanked

# after
from invoco import expose
```

## License

Apache-2.0.
