# 更新日志

## v0.2.25 (2026-04-08)

### Bug Fixes

- **修复 CLI 模式代理访问认证头缺失问题**：`_get_remote_request_headers` 方法之前仅对 `RunMode.NORMAL` 返回包含 `lab-auth-code`、`auth-code`、`serialnumber` 等认证头，CLI 模式返回空字典，导致通过代理访问设备时服务端报授权码错误。现在 CLI 模式也会正确返回认证头。
- **修复 `ConnectionInfo.debug_id` 必填校验问题**：`debug_id` 在某些场景下可能为空（如用户直接提供 authCode 时），将其从必填字段改为可选字段（默认 `None`），为空时不续期不释放设备。同步移除 `create_device()` 中对 `debug_id` 的必填校验。
