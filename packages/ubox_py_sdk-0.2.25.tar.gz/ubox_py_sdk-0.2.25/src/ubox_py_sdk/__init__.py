"""
优测Python UBox

提供与优测设备通信的Python接口。
支持调试模式和执行模式两种运行方式。
"""

from .client import UBox, operation_timer, connect_device, create_device
from .device import Device
from .device_operations import LogcatTask
from .handler import EventHandler
from .models import OSType, RunMode, ConnectionInfo, DeviceButton, DriverType, PhonePlatform, PinchDirection
from ubox_py_sdk.utils.jwt_util import JWTUtil

# 当前 SDK 版本号，需要与 pyproject.toml 中的 version 保持一致
__version__ = "0.2.25"

# 核心类
__all__ = [
    # 主要类
    "UBox",  # 主客户端类
    "Device",  # 设备类
    "connect_device",  # CLI模式快捷函数，一步创建设备实例
    "create_device",  # CLI模式快捷函数，用连接信息直接创建设备实例（跳过连接流程）
    "ConnectionInfo",  # CLI模式设备连接信息结构体

    # 枚举类型
    "OSType",  # 操作系统类型 (ANDROID, IOS, HM)
    "RunMode",  # 运行模式 (DEBUG, EXECUTE)
    "DeviceButton",  # 按键操作
    "DriverType",  # 面向用户的驱动类型参数

    "PhonePlatform",  # 设备列表指定设备类型时使用

    "operation_timer",
    "EventHandler",
    "LogcatTask",
    "PinchDirection",
]
