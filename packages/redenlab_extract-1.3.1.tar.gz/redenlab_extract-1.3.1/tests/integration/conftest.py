"""
Shared fixtures for integration tests.

Authentication is read from tests/fixtures/config.yaml:
    client_id: <your-client-id>
    client_secret: <your-client-secret>
    base_url: https://...  # optional

Alternatively, set REDENLAB_CLIENT_ID + REDENLAB_CLIENT_SECRET env vars directly,
or run 'redenlab login' for PKCE browser-based auth.

Tests are skipped if no auth is available or the fixture config is missing.
"""

import os
from pathlib import Path

import pytest
import yaml

FIXTURES_DIR = Path(__file__).parent.parent / "fixtures"
TEST_AUDIO_FILE = FIXTURES_DIR / "s0001_12.wav"
CONFIG_FILE = FIXTURES_DIR / "config.yaml"


def _load_fixture_config() -> dict:
    """Load tests/fixtures/config.yaml if it exists, silently return {} otherwise."""
    if not CONFIG_FILE.exists():
        return {}
    try:
        with open(CONFIG_FILE) as f:
            return yaml.safe_load(f) or {}
    except (yaml.YAMLError, OSError):
        return {}


@pytest.fixture(scope="session")
def session():
    """
    Create a RedenLabSession with real credentials.

    Reads client_id/client_secret from tests/fixtures/config.yaml and sets them
    as REDENLAB_CLIENT_ID / REDENLAB_CLIENT_SECRET env vars for the duration of
    the test session. Falls back to whatever env vars or PKCE tokens are already set.
    """
    from redenlab_extract import RedenLabSession
    from redenlab_extract.exceptions import AuthenticationError, ConfigurationError

    config = _load_fixture_config()

    # Inject credentials from config file as env vars (only if not already set)
    if config.get("client_id") and not os.environ.get("REDENLAB_CLIENT_ID"):
        os.environ["REDENLAB_CLIENT_ID"] = config["client_id"]
    if config.get("client_secret") and not os.environ.get("REDENLAB_CLIENT_SECRET"):
        os.environ["REDENLAB_CLIENT_SECRET"] = config["client_secret"]

    base_url = config.get("base_url")

    try:
        return RedenLabSession(base_url=base_url)
    except (AuthenticationError, ConfigurationError) as e:
        pytest.skip(f"Authentication not available: {e}")


@pytest.fixture
def test_audio_path():
    """
    Get path to test audio file.

    Requirements for the WAV file:
    - Short duration (2-5 seconds recommended)
    - Clear speech in English (for transcription tests)
    - WAV format, 16kHz sample rate recommended
    """
    if not TEST_AUDIO_FILE.exists():
        pytest.skip(
            f"Test audio file not found at {TEST_AUDIO_FILE}. "
            "Add a short WAV file (2-5 seconds) to run integration tests."
        )
    return str(TEST_AUDIO_FILE)


@pytest.fixture
def transcribe_client(session):
    """Create a TranscribeClient instance with real credentials."""
    from redenlab_extract import TranscribeClient

    return TranscribeClient(session, language_code="en-US", max_speaker_count=10)


@pytest.fixture
def intelligibility_client(session):
    """Create an intelligibility inference client with real credentials."""
    from redenlab_extract import intelligibility_client as make_intelligibility_client

    return make_intelligibility_client(session, model_name="als-intelligibility-v1")
