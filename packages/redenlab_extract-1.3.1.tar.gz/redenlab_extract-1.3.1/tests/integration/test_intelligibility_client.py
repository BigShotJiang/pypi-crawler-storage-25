"""
Integration tests for the intelligibility inference client.

These tests verify that the intelligibility_client factory and the underlying
InferenceClient work correctly against the real RedenLab API. Run these tests
before releasing a new SDK version.

Prerequisites:
    - Authenticated session: set REDENLAB_CLIENT_ID + REDENLAB_CLIENT_SECRET, or
      run 'redenlab login' for PKCE browser-based auth.
    - tests/fixtures/s0001_12.wav exists (short audio file, 2-5 seconds).

Run with:
    pytest tests/integration/test_intelligibility_client.py -v
"""

import pytest

from redenlab_extract import intelligibility_client, run_inference
from redenlab_extract.exceptions import ValidationError

pytestmark = pytest.mark.integration


class TestIntelligibilityClientInitialization:
    """Tests for intelligibility_client factory initialization."""

    def test_client_creates_with_valid_session(self, session):
        """Verify client can be created with a valid session."""
        client = intelligibility_client(session, model_name="als-intelligibility-v1")
        assert client.model_name == "als-intelligibility-v1"

    def test_client_accepts_all_valid_models(self, session):
        """Verify factory accepts all valid model names."""
        valid_models = [
            "ataxia-intelligibility",
            "als-intelligibility-v1",
            "als-intelligibility-v2",
        ]
        for model_name in valid_models:
            client = intelligibility_client(session, model_name=model_name)
            assert client.model_name == model_name

    def test_client_rejects_invalid_model(self, session):
        """Verify factory raises ValidationError for invalid model name."""
        with pytest.raises(ValidationError):
            intelligibility_client(session, model_name="invalid-model")

    def test_client_repr_shows_model_info(self, session):
        """Verify __repr__ includes model name."""
        client = intelligibility_client(session, model_name="als-intelligibility-v1")
        repr_str = repr(client)
        assert "als-intelligibility-v1" in repr_str


class TestIntelligibilityClientHealth:
    """Tests for intelligibility health check functionality."""

    def test_health_returns_status(self, intelligibility_client):
        """
        Verify health() returns valid status.

        Intelligibility uses SageMaker endpoints which support health checks.
        """
        health_result = intelligibility_client.health()

        assert "status" in health_result
        assert "ready" in health_result
        assert health_result["status"] in ["healthy", "warming", "unhealthy", "cold", "warming_up"]

    def test_warmup_returns_status(self, intelligibility_client):
        """Verify warmup() returns status information."""
        warmup_result = intelligibility_client.warmup()

        assert "status" in warmup_result


class TestIntelligibilityClientSubmit:
    """Tests for intelligibility job submission."""

    def test_submit_returns_job_id(self, intelligibility_client, session, test_audio_path):
        """Verify submit() returns a valid job_id."""
        asset = session.upload(test_audio_path)
        job_id = intelligibility_client._submit_with_upload_wait(asset)

        assert job_id is not None
        assert isinstance(job_id, str)
        assert len(job_id) > 0


class TestIntelligibilityClientStatus:
    """Tests for intelligibility job status retrieval."""

    def test_get_status_returns_valid_response(
        self, intelligibility_client, session, test_audio_path
    ):
        """Verify get_status() returns valid job status."""
        asset = session.upload(test_audio_path)
        job_id = intelligibility_client._submit_with_upload_wait(asset)

        status = intelligibility_client.get_status(job_id)

        assert "job_id" in status
        assert "status" in status
        assert status["job_id"] == job_id
        assert status["status"] in ["upload_pending", "processing", "completed", "failed"]


class TestIntelligibilityClientEndToEnd:
    """
    End-to-end tests for the intelligibility client.

    These tests run the full workflow and may take several minutes to complete
    if the backend is cold.
    """

    def test_predict_returns_result(self, intelligibility_client, session, test_audio_path):
        """
        Verify run_inference() completes and returns an intelligibility result.

        This is the primary smoke test — if this passes, the basic SDK
        workflow is functioning correctly.
        """
        result = run_inference(session, intelligibility_client, test_audio_path)

        assert result["status"] == "completed"
        assert result["result"] is not None
        assert result["job_id"] is not None

    def test_submit_poll_workflow(self, intelligibility_client, session, test_audio_path):
        """Verify separate upload → submit → poll workflow works."""
        asset = session.upload(test_audio_path)
        job_id = intelligibility_client._submit_with_upload_wait(asset)
        assert job_id is not None

        result = intelligibility_client.poll(job_id, timeout=600)

        assert result["status"] == "completed"
        assert result["job_id"] == job_id

    def test_progress_callback_is_called(self, intelligibility_client, session, test_audio_path):
        """Verify progress_callback receives status updates during polling."""
        callback_calls = []

        def progress_callback(status):
            callback_calls.append(status)

        result = run_inference(
            session,
            intelligibility_client,
            test_audio_path,
            progress_callback=progress_callback,
        )

        assert result["status"] == "completed"
        assert len(callback_calls) >= 1
        for call in callback_calls:
            assert "status" in call
