"""
Integration tests for TranscribeClient.

These tests verify that the TranscribeClient works correctly against the real
RedenLab API. Run these tests before releasing a new SDK version to ensure
basic workflows function as expected.

Prerequisites:
    - Authenticated session: set REDENLAB_CLIENT_ID + REDENLAB_CLIENT_SECRET, or
      run 'redenlab login' for PKCE browser-based auth.
    - tests/fixtures/s0001_12.wav exists (short audio file, 2-5 seconds).

Run with:
    pytest tests/integration/test_transcribe_client.py -v
"""

import pytest

from redenlab_extract import TranscribeClient, run_inference
from redenlab_extract.exceptions import ValidationError

pytestmark = pytest.mark.integration


class TestTranscribeClientInitialization:
    """Tests for TranscribeClient initialization."""

    def test_client_initializes_with_valid_session(self, session):
        """Verify client can be created with a valid session."""
        client = TranscribeClient(session)
        assert client.model_name == "transcribe"

    def test_client_accepts_language_code(self, session):
        """Verify client accepts and stores language_code parameter."""
        client = TranscribeClient(session, language_code="en-AU")
        assert client.language_code == "en-AU"

    def test_client_accepts_max_speaker_count(self, session):
        """Verify client accepts and stores max_speaker_count parameter."""
        client = TranscribeClient(session, max_speaker_count=4)
        assert client.max_speaker_count == 4

    def test_max_speaker_count_always_sent_to_backend(self, session):
        """
        Verify max_speaker_count is always included in the submitted payload.

        The transcribe Lambda always sets ShowSpeakerLabels=True, which requires
        MaxSpeakerLabels to be an integer. Omitting it causes a 500 Parameter
        validation error from boto3. The SDK defaults to 10 when not set by the caller.
        """
        client = TranscribeClient(session, language_code="en-US")
        assert client.max_speaker_count is None  # Not set by caller

        # Verify the submit method injects the default before sending
        import unittest.mock as mock

        with mock.patch.object(client, "_payload_builder") as mock_builder:
            mock_builder.build.return_value = {
                "asset_id": "x",
                "language_code": "en-US",
                "max_speaker_count": 10,
            }
            with mock.patch(
                "redenlab_extract.api.submit_inference_job", return_value={"job_id": "test-job"}
            ):
                from redenlab_extract.asset import Asset

                dummy_asset = Asset(asset_id="x", filename="x.wav", content_type="audio/wav")
                client.submit(dummy_asset)
            # max_speaker_count=10 must be in the kwargs passed to build()
            call_kwargs = mock_builder.build.call_args.kwargs
            assert "max_speaker_count" in call_kwargs
            assert call_kwargs["max_speaker_count"] == 10

    def test_client_repr_shows_model_info(self, session):
        """Verify __repr__ includes TranscribeClient and configured parameters."""
        client = TranscribeClient(session, language_code="en-US")
        repr_str = repr(client)
        assert "TranscribeClient" in repr_str


class TestTranscribeClientHealth:
    """Tests for TranscribeClient health check functionality."""

    def test_health_returns_not_supported(self, transcribe_client):
        """
        Verify health() returns 'not_supported' status.

        TranscribeClient uses AWS Transcribe managed service which doesn't have
        a health endpoint — it's always available.
        """
        health_result = transcribe_client.health()

        assert health_result["status"] == "not_supported"
        assert health_result["ready"] is True
        assert health_result["is_warming"] is False
        assert "managed service" in health_result["message"].lower()

    def test_warmup_returns_not_supported(self, transcribe_client):
        """
        Verify warmup() returns 'not_supported' status.

        TranscribeClient uses AWS Transcribe managed service which doesn't require warmup.
        """
        warmup_result = transcribe_client.warmup()

        assert warmup_result["status"] == "not_supported"
        assert "managed service" in warmup_result["message"].lower()


class TestTranscribeClientSubmit:
    """Tests for TranscribeClient job submission."""

    def test_submit_returns_job_id(self, transcribe_client, session, test_audio_path):
        """Verify submit() returns a valid job_id."""
        asset = session.upload(test_audio_path)
        job_id = transcribe_client._submit_with_upload_wait(asset)

        assert job_id is not None
        assert isinstance(job_id, str)
        assert len(job_id) > 0

    def test_submit_with_language_code_override(self, session, test_audio_path):
        """Verify language_code can be overridden per submission."""
        client = TranscribeClient(session, language_code="en-US", max_speaker_count=10)
        asset = session.upload(test_audio_path)

        # Override with different language
        job_id = client._submit_with_upload_wait(asset, language_code="en-AU")

        assert job_id is not None
        assert isinstance(job_id, str)


class TestTranscribeClientStatus:
    """Tests for TranscribeClient job status retrieval."""

    def test_get_status_returns_valid_response(self, transcribe_client, session, test_audio_path):
        """Verify get_status() returns valid job status."""
        asset = session.upload(test_audio_path)
        job_id = transcribe_client._submit_with_upload_wait(asset)

        status = transcribe_client.get_status(job_id)

        assert "job_id" in status
        assert "status" in status
        assert status["job_id"] == job_id
        assert status["status"] in ["upload_pending", "processing", "completed", "failed"]


class TestTranscribeClientEndToEnd:
    """
    End-to-end tests for TranscribeClient.

    These tests run the full transcription workflow and may take several
    minutes to complete.
    """

    def test_predict_returns_transcription(self, transcribe_client, session, test_audio_path):
        """
        Verify run_inference() completes and returns transcription result.

        This is the primary smoke test — if this passes, the basic SDK
        workflow is functioning correctly.
        """
        result = run_inference(session, transcribe_client, test_audio_path)

        assert result["status"] == "completed"
        assert result["transcript"] is not None
        assert result["job_id"] is not None

    def test_submit_poll_workflow(self, transcribe_client, session, test_audio_path):
        """Verify separate upload → submit → poll workflow works."""
        asset = session.upload(test_audio_path)
        job_id = transcribe_client._submit_with_upload_wait(asset)
        assert job_id is not None

        result = transcribe_client.poll(job_id, timeout=600)

        assert result["status"] == "completed"
        assert result["job_id"] == job_id

    def test_progress_callback_is_called(self, transcribe_client, session, test_audio_path):
        """Verify progress_callback receives status updates during polling."""
        callback_calls = []

        def progress_callback(status):
            callback_calls.append(status)

        result = run_inference(
            session,
            transcribe_client,
            test_audio_path,
            progress_callback=progress_callback,
        )

        assert result["status"] == "completed"
        assert len(callback_calls) >= 1
        for call in callback_calls:
            assert "status" in call
