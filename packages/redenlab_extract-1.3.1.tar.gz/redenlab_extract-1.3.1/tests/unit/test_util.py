"""
Tests for the utility module
"""

import pytest

from redenlab_extract.exceptions import ValidationError
from redenlab_extract.utils import get_content_type

# --- Happy path: exact mappings ---


@pytest.mark.parametrize(
    "filename, expected",
    [
        ("clip.wav", "audio/wav"),
        ("clip.wave", "audio/wav"),
        ("clip.flac", "audio/flac"),
        ("clip.ogg", "audio/ogg"),
    ],
)
def test_get_content_type_supported(filename, expected):
    assert get_content_type(filename) == expected


# --- Case-insensitivity + funky names ---


@pytest.mark.parametrize(
    "filename, expected",
    [
        ("UPPER.WAV", "audio/wav"),
        ("mix.cAsE.fLaC", "audio/flac"),
        ("speace name.ogg", "audio/ogg"),
        ("multiple.dots.name.WAVE", "audio/wav"),
    ],
)
def test_get_content_type_is_case_sensitive_and_handles_multiple_dots(filename, expected):
    assert get_content_type(filename) == expected


# --- Unsupported extensions raise ValidationError ---


@pytest.mark.parametrize("filename", ["song.mp3", "audio.m4a", "noext", "weird.ext"])
def test_get_content_type_unsupported(filename):
    with pytest.raises(ValidationError):
        get_content_type(filename)
