import json
from datetime import datetime, timedelta, timezone
from unittest.mock import patch

import pytest
import requests

from redenlab_extract.discovery import (
    _fetch_discovery_config,
    _get_cached_discovery,
    _is_url_cache_valid,
    _read_url_cache,
    _validate_base_url,
    _write_url_cache,
    get_cognito_config,
    get_default_base_url,
)

# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------

_VALID_BASE_URL = "https://abc.execute-api.us-east-1.amazonaws.com/prod"

_FULL_DISCOVERY = {
    "base_url": _VALID_BASE_URL,
    "cognito": {
        "user_pool_id": "us-east-1_abc123",
        "client_id": "test-client-id",
        "domain": "test.auth.us-east-1.amazoncognito.com",
        "region": "us-east-1",
    },
}


# ---------------------------------------------------------------------------
# _validate_base_url
# ---------------------------------------------------------------------------


class TestValidateBaseUrl:
    @pytest.mark.parametrize(
        "url",
        [
            "https://abc.execute-api.us-east-1.amazonaws.com/prod",
            "https://d123.cloudfront.net/endpoint.json",
            "https://intelligens.redenlab.com",
            "https://api.redenlab.com/prod",
        ],
    )
    def test_valid_urls(self, url):
        assert _validate_base_url(url) is True

    def test_rejects_http_scheme(self):
        assert _validate_base_url("http://api.redenlab-ml.com") is False

    def test_rejects_non_string(self):
        assert _validate_base_url(None) is False  # type: ignore[arg-type]
        assert _validate_base_url(123) is False  # type: ignore[arg-type]

    def test_rejects_https_without_known_pattern(self):
        assert _validate_base_url("https://unknown-host.example.com") is False


# ---------------------------------------------------------------------------
# _is_url_cache_valid
# ---------------------------------------------------------------------------


class TestIsUrlCacheValid:
    def test_fresh_cache_is_valid(self):
        cache = {"fetched_at": datetime.now(timezone.utc).isoformat()}
        assert _is_url_cache_valid(cache) is True

    def test_expired_cache_is_invalid(self):
        old = (datetime.now(timezone.utc) - timedelta(hours=25)).isoformat()
        assert _is_url_cache_valid({"fetched_at": old}) is False

    def test_missing_fetched_at_is_invalid(self):
        assert _is_url_cache_valid({}) is False

    def test_malformed_fetched_at_is_invalid(self):
        assert _is_url_cache_valid({"fetched_at": "not-a-date"}) is False


# ---------------------------------------------------------------------------
# _read_url_cache
# ---------------------------------------------------------------------------


class TestReadUrlCache:
    def test_returns_none_when_file_missing(self, tmp_path):
        with patch(
            "redenlab_extract.discovery._get_url_cache_path",
            return_value=tmp_path / "no_cache.json",
        ):
            assert _read_url_cache() is None

    def test_returns_none_for_malformed_json(self, tmp_path):
        cache_file = tmp_path / "cache.json"
        cache_file.write_text("not json {{{")
        with patch("redenlab_extract.discovery._get_url_cache_path", return_value=cache_file):
            assert _read_url_cache() is None

    def test_returns_none_for_old_format(self, tmp_path):
        # Old format had base_url at top level without "discovery" wrapper
        cache_file = tmp_path / "cache.json"
        cache_file.write_text(json.dumps({"base_url": _VALID_BASE_URL}))
        with patch("redenlab_extract.discovery._get_url_cache_path", return_value=cache_file):
            assert _read_url_cache() is None

    def test_returns_cache_data_when_valid(self, tmp_path):
        cache_file = tmp_path / "cache.json"
        cache_data = {
            "discovery": _FULL_DISCOVERY,
            "fetched_at": datetime.now(timezone.utc).isoformat(),
        }
        cache_file.write_text(json.dumps(cache_data))
        with patch("redenlab_extract.discovery._get_url_cache_path", return_value=cache_file):
            assert _read_url_cache() == cache_data


# ---------------------------------------------------------------------------
# _write_url_cache
# ---------------------------------------------------------------------------


class TestWriteUrlCache:
    def test_writes_discovery_and_fetched_at(self, tmp_path):
        cache_file = tmp_path / "cache.json"
        with patch("redenlab_extract.discovery._get_url_cache_path", return_value=cache_file):
            _write_url_cache(_FULL_DISCOVERY)
        written = json.loads(cache_file.read_text())
        assert written["discovery"] == _FULL_DISCOVERY
        assert "fetched_at" in written

    def test_silently_ignores_os_error(self, tmp_path):
        cache_file = tmp_path / "cache.json"
        with patch("redenlab_extract.discovery._get_url_cache_path", return_value=cache_file):
            with patch("builtins.open", side_effect=OSError("disk full")):
                _write_url_cache(_FULL_DISCOVERY)  # must not raise


# ---------------------------------------------------------------------------
# _fetch_discovery_config
# ---------------------------------------------------------------------------


class TestFetchDiscoveryConfig:
    def _make_response(self, data):
        from unittest.mock import MagicMock

        r = MagicMock()
        r.json.return_value = data
        return r

    def test_returns_dict_on_success(self):
        with patch(
            "redenlab_extract.discovery.requests.get",
            return_value=self._make_response(_FULL_DISCOVERY),
        ):
            result = _fetch_discovery_config()
        assert result == _FULL_DISCOVERY

    def test_returns_none_when_base_url_missing(self):
        with patch(
            "redenlab_extract.discovery.requests.get",
            return_value=self._make_response({"cognito": {}}),
        ):
            assert _fetch_discovery_config() is None

    def test_returns_none_when_base_url_fails_validation(self):
        with patch(
            "redenlab_extract.discovery.requests.get",
            return_value=self._make_response({"base_url": "https://untrusted.example.com"}),
        ):
            assert _fetch_discovery_config() is None

    def test_returns_none_on_request_exception(self):
        with patch(
            "redenlab_extract.discovery.requests.get",
            side_effect=requests.RequestException("timeout"),
        ):
            assert _fetch_discovery_config() is None


# ---------------------------------------------------------------------------
# _get_cached_discovery
# ---------------------------------------------------------------------------


class TestGetCachedDiscovery:
    def _fresh_cache(self, discovery=None):
        return {
            "discovery": discovery or _FULL_DISCOVERY,
            "fetched_at": datetime.now(timezone.utc).isoformat(),
        }

    def _stale_cache(self, discovery=None):
        return {
            "discovery": discovery or _FULL_DISCOVERY,
            "fetched_at": (datetime.now(timezone.utc) - timedelta(hours=25)).isoformat(),
        }

    def test_returns_cached_discovery_without_fetching_when_fresh(self):
        with patch("redenlab_extract.discovery._read_url_cache", return_value=self._fresh_cache()):
            with patch("redenlab_extract.discovery._fetch_discovery_config") as mock_fetch:
                result = _get_cached_discovery()
        assert result == _FULL_DISCOVERY
        mock_fetch.assert_not_called()

    def test_fetches_and_updates_cache_when_stale(self):
        with patch("redenlab_extract.discovery._read_url_cache", return_value=self._stale_cache()):
            with patch(
                "redenlab_extract.discovery._fetch_discovery_config", return_value=_FULL_DISCOVERY
            ):
                with patch("redenlab_extract.discovery._write_url_cache") as mock_write:
                    result = _get_cached_discovery()
        assert result == _FULL_DISCOVERY
        mock_write.assert_called_once_with(_FULL_DISCOVERY)

    def test_falls_back_to_stale_cache_when_fetch_fails(self):
        stale_discovery = {"base_url": _VALID_BASE_URL}
        with patch(
            "redenlab_extract.discovery._read_url_cache",
            return_value=self._stale_cache(stale_discovery),
        ):
            with patch("redenlab_extract.discovery._fetch_discovery_config", return_value=None):
                result = _get_cached_discovery()
        assert result == stale_discovery

    def test_returns_none_when_no_cache_and_fetch_fails(self):
        with patch("redenlab_extract.discovery._read_url_cache", return_value=None):
            with patch("redenlab_extract.discovery._fetch_discovery_config", return_value=None):
                assert _get_cached_discovery() is None


# ---------------------------------------------------------------------------
# get_default_base_url
# ---------------------------------------------------------------------------


class TestGetDefaultBaseUrl:
    def test_returns_url_from_discovery(self):
        with patch(
            "redenlab_extract.discovery._get_cached_discovery", return_value=_FULL_DISCOVERY
        ):
            assert get_default_base_url() == _VALID_BASE_URL

    def test_returns_none_when_discovery_fails(self):
        with patch("redenlab_extract.discovery._get_cached_discovery", return_value=None):
            assert get_default_base_url() is None

    def test_returns_none_when_url_fails_validation(self):
        with patch(
            "redenlab_extract.discovery._get_cached_discovery",
            return_value={"base_url": "https://untrusted.example.com"},
        ):
            assert get_default_base_url() is None


# ---------------------------------------------------------------------------
# get_cognito_config
# ---------------------------------------------------------------------------


class TestGetCognitoConfig:
    def test_returns_all_required_fields(self):
        with patch(
            "redenlab_extract.discovery._get_cached_discovery", return_value=_FULL_DISCOVERY
        ):
            result = get_cognito_config()
        assert result == {
            "user_pool_id": "us-east-1_abc123",
            "client_id": "test-client-id",
            "domain": "test.auth.us-east-1.amazoncognito.com",
            "region": "us-east-1",
        }

    def test_returns_none_when_discovery_fails(self):
        with patch("redenlab_extract.discovery._get_cached_discovery", return_value=None):
            assert get_cognito_config() is None

    def test_returns_none_when_cognito_section_missing(self):
        with patch(
            "redenlab_extract.discovery._get_cached_discovery",
            return_value={"base_url": _VALID_BASE_URL},
        ):
            assert get_cognito_config() is None

    def test_returns_none_when_required_field_missing(self):
        incomplete = {
            **_FULL_DISCOVERY,
            "cognito": {
                "user_pool_id": "us-east-1_abc123",
                "client_id": "test-client-id",
                # domain and region absent
            },
        }
        with patch("redenlab_extract.discovery._get_cached_discovery", return_value=incomplete):
            assert get_cognito_config() is None
