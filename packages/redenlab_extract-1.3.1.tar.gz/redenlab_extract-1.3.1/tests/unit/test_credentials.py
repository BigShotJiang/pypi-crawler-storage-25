import os
from datetime import datetime, timedelta, timezone
from unittest.mock import MagicMock, patch

import pytest
import requests
import yaml

from redenlab_extract.credentials import (
    BaseCredentials,
    ClientCredentials,
    PKCECredentials,
    _load_tokens,
    _save_tokens,
    build_credentials,
)
from redenlab_extract.exceptions import AuthenticationError, ConfigurationError

# ---------------------------------------------------------------------------
# Shared constants
# ---------------------------------------------------------------------------

_VALID_TOKENS = {
    "access_token": "test-access-token",
    "refresh_token": "test-refresh-token",
    "token_expiry": "2027-12-31T00:00:00+00:00",
    "user_sub": "user-sub-123",
}

_COGNITO_CONFIG = {
    "domain": "test.auth.us-east-1.amazoncognito.com",
    "client_id": "test-client-id",
    "user_pool_id": "us-east-1_test",
    "region": "us-east-1",
}

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class _ConcreteCredentials(BaseCredentials):
    """Minimal concrete subclass for testing BaseCredentials in isolation."""

    def __init__(self):
        super().__init__()
        self.refresh_count = 0

    def _do_refresh(self) -> tuple[str, datetime]:
        self.refresh_count += 1
        return "refreshed-token", datetime.now(timezone.utc) + timedelta(hours=1)


# ---------------------------------------------------------------------------
# _load_tokens
# ---------------------------------------------------------------------------


class TestLoadTokens:
    def test_returns_none_when_file_missing(self, tmp_path, monkeypatch):
        monkeypatch.setattr(
            "redenlab_extract.credentials._CREDENTIALS_PATH", tmp_path / "no_file.yaml"
        )
        assert _load_tokens() is None

    def test_returns_none_for_malformed_yaml(self, tmp_path, monkeypatch):
        creds_file = tmp_path / "credentials.yaml"
        creds_file.write_text(":\t invalid yaml\n")
        monkeypatch.setattr("redenlab_extract.credentials._CREDENTIALS_PATH", creds_file)
        assert _load_tokens() is None

    def test_returns_none_when_required_field_missing(self, tmp_path, monkeypatch):
        creds_file = tmp_path / "credentials.yaml"
        partial = {k: v for k, v in _VALID_TOKENS.items() if k != "refresh_token"}
        creds_file.write_text(yaml.dump(partial))
        monkeypatch.setattr("redenlab_extract.credentials._CREDENTIALS_PATH", creds_file)
        assert _load_tokens() is None

    def test_returns_token_dict_when_valid(self, tmp_path, monkeypatch):
        creds_file = tmp_path / "credentials.yaml"
        creds_file.write_text(yaml.dump(_VALID_TOKENS))
        monkeypatch.setattr("redenlab_extract.credentials._CREDENTIALS_PATH", creds_file)
        assert _load_tokens() == _VALID_TOKENS


# ---------------------------------------------------------------------------
# _save_tokens
# ---------------------------------------------------------------------------


class TestSaveTokens:
    def test_writes_all_fields(self, tmp_path, monkeypatch):
        creds_file = tmp_path / "credentials.yaml"
        monkeypatch.setattr("redenlab_extract.credentials._CREDENTIALS_PATH", creds_file)
        _save_tokens(**_VALID_TOKENS)
        data = yaml.safe_load(creds_file.read_text())
        assert data["access_token"] == _VALID_TOKENS["access_token"]
        assert data["refresh_token"] == _VALID_TOKENS["refresh_token"]
        assert data["token_expiry"] == _VALID_TOKENS["token_expiry"]
        assert data["user_sub"] == _VALID_TOKENS["user_sub"]

    def test_sets_owner_only_permissions(self, tmp_path, monkeypatch):
        creds_file = tmp_path / "credentials.yaml"
        monkeypatch.setattr("redenlab_extract.credentials._CREDENTIALS_PATH", creds_file)
        _save_tokens(**_VALID_TOKENS)
        assert os.stat(creds_file).st_mode & 0o777 == 0o600


# ---------------------------------------------------------------------------
# BaseCredentials — token expiry
# ---------------------------------------------------------------------------


class TestIsTokenExpiring:
    def test_none_expiry_is_expiring(self):
        creds = _ConcreteCredentials()
        assert creds._is_token_expiring() is True

    def test_token_within_5_min_buffer_is_expiring(self):
        creds = _ConcreteCredentials()
        creds._token_expiry = datetime.now(timezone.utc) + timedelta(minutes=4)
        assert creds._is_token_expiring() is True

    def test_token_with_time_remaining_is_not_expiring(self):
        creds = _ConcreteCredentials()
        creds._token_expiry = datetime.now(timezone.utc) + timedelta(hours=1)
        assert creds._is_token_expiring() is False


# ---------------------------------------------------------------------------
# BaseCredentials — get_token cache gate
# ---------------------------------------------------------------------------


class TestGetToken:
    def test_returns_cached_token_without_refresh(self):
        creds = _ConcreteCredentials()
        creds._cached_token = "cached-token"
        creds._token_expiry = datetime.now(timezone.utc) + timedelta(hours=1)

        assert creds.get_token() == "cached-token"
        assert creds.refresh_count == 0

    def test_calls_refresh_when_no_cached_token(self):
        creds = _ConcreteCredentials()
        token = creds.get_token()
        assert token == "refreshed-token"
        assert creds.refresh_count == 1

    def test_calls_refresh_when_token_expiring(self):
        creds = _ConcreteCredentials()
        creds._cached_token = "old-token"
        creds._token_expiry = datetime.now(timezone.utc) + timedelta(minutes=2)

        assert creds.get_token() == "refreshed-token"
        assert creds.refresh_count == 1

    def test_updates_cache_after_refresh(self):
        creds = _ConcreteCredentials()
        creds.get_token()
        assert creds._cached_token == "refreshed-token"
        assert creds._token_expiry is not None


# ---------------------------------------------------------------------------
# BaseCredentials — get_headers
# ---------------------------------------------------------------------------


class TestGetHeaders:
    def test_returns_bearer_authorization_header(self):
        creds = _ConcreteCredentials()
        creds._cached_token = "test-token"
        creds._token_expiry = datetime.now(timezone.utc) + timedelta(hours=1)

        headers = creds.get_headers()

        assert headers["Authorization"] == "Bearer test-token"
        assert headers["Content-Type"] == "application/json"
        assert headers["Accept"] == "application/json"


# ---------------------------------------------------------------------------
# PKCECredentials — __init__
# ---------------------------------------------------------------------------


class TestPKCECredentialsInit:
    def test_populates_token_fields_from_stored(self):
        with patch("redenlab_extract.credentials._load_tokens", return_value=_VALID_TOKENS):
            creds = PKCECredentials(_COGNITO_CONFIG)
        assert creds._cached_token == _VALID_TOKENS["access_token"]
        assert creds._refresh_token == _VALID_TOKENS["refresh_token"]
        assert creds._user_sub == _VALID_TOKENS["user_sub"]

    def test_parses_token_expiry_as_datetime(self):
        with patch("redenlab_extract.credentials._load_tokens", return_value=_VALID_TOKENS):
            creds = PKCECredentials(_COGNITO_CONFIG)
        assert isinstance(creds._token_expiry, datetime)

    def test_sets_none_expiry_for_unparseable_timestamp(self):
        bad_tokens = {**_VALID_TOKENS, "token_expiry": "not-a-date"}
        with patch("redenlab_extract.credentials._load_tokens", return_value=bad_tokens):
            creds = PKCECredentials(_COGNITO_CONFIG)
        assert creds._token_expiry is None

    def test_raises_authentication_error_when_no_stored_tokens(self):
        with patch("redenlab_extract.credentials._load_tokens", return_value=None):
            with pytest.raises(AuthenticationError, match="redenlab login"):
                PKCECredentials(_COGNITO_CONFIG)


# ---------------------------------------------------------------------------
# PKCECredentials — _do_refresh
# ---------------------------------------------------------------------------


@pytest.fixture
def pkce_creds():
    """PKCECredentials with stored tokens loaded from mock, ready for refresh tests."""
    with patch("redenlab_extract.credentials._load_tokens", return_value=_VALID_TOKENS):
        yield PKCECredentials(_COGNITO_CONFIG)


class TestPKCECredentialsDoRefresh:
    def test_returns_new_access_token_and_expiry(self, pkce_creds):
        mock_response = MagicMock()
        mock_response.ok = True
        mock_response.json.return_value = {"access_token": "new-token", "expires_in": 3600}

        with patch("redenlab_extract.credentials.requests.post", return_value=mock_response):
            with patch("redenlab_extract.credentials._save_tokens"):
                token, expiry = pkce_creds._do_refresh()

        assert token == "new-token"
        assert isinstance(expiry, datetime)

    def test_saves_new_token_to_disk(self, pkce_creds):
        mock_response = MagicMock()
        mock_response.ok = True
        mock_response.json.return_value = {"access_token": "new-token", "expires_in": 3600}

        with patch("redenlab_extract.credentials.requests.post", return_value=mock_response):
            with patch("redenlab_extract.credentials._save_tokens") as mock_save:
                pkce_creds._do_refresh()

        mock_save.assert_called_once()
        assert mock_save.call_args.kwargs["access_token"] == "new-token"

    def test_raises_on_request_exception(self, pkce_creds):
        with patch(
            "redenlab_extract.credentials.requests.post",
            side_effect=requests.RequestException("connection timeout"),
        ):
            with pytest.raises(AuthenticationError, match="Token refresh failed"):
                pkce_creds._do_refresh()

    def test_raises_on_non_ok_response(self, pkce_creds):
        mock_response = MagicMock()
        mock_response.ok = False

        with patch("redenlab_extract.credentials.requests.post", return_value=mock_response):
            with pytest.raises(AuthenticationError, match="Session expired"):
                pkce_creds._do_refresh()

    def test_raises_when_access_token_absent_from_response(self, pkce_creds):
        mock_response = MagicMock()
        mock_response.ok = True
        mock_response.json.return_value = {"expires_in": 3600}  # no access_token key

        with patch("redenlab_extract.credentials.requests.post", return_value=mock_response):
            with pytest.raises(AuthenticationError, match="Session expired"):
                pkce_creds._do_refresh()


# ---------------------------------------------------------------------------
# ClientCredentials — _do_refresh
# ---------------------------------------------------------------------------


_CLIENT_ENV = {
    "REDENLAB_CLIENT_ID": "machine-client-id",
    "REDENLAB_CLIENT_SECRET": "machine-client-secret",
}


@pytest.fixture
def client_creds():
    return ClientCredentials(_COGNITO_CONFIG)


class TestClientCredentialsDoRefresh:
    def test_returns_access_token_and_expiry(self, client_creds):
        mock_response = MagicMock()
        mock_response.ok = True
        mock_response.json.return_value = {"access_token": "machine-token", "expires_in": 3600}

        with patch.dict(os.environ, _CLIENT_ENV):
            with patch("redenlab_extract.credentials.requests.post", return_value=mock_response):
                token, expiry = client_creds._do_refresh()

        assert token == "machine-token"
        assert isinstance(expiry, datetime)

    def test_posts_basic_auth_header(self, client_creds):
        import base64

        mock_response = MagicMock()
        mock_response.ok = True
        mock_response.json.return_value = {"access_token": "machine-token", "expires_in": 3600}

        with patch.dict(os.environ, _CLIENT_ENV):
            with patch(
                "redenlab_extract.credentials.requests.post", return_value=mock_response
            ) as mock_post:
                client_creds._do_refresh()

        headers = mock_post.call_args.kwargs["headers"]
        expected = base64.b64encode(b"machine-client-id:machine-client-secret").decode()
        assert headers["Authorization"] == f"Basic {expected}"

    def test_posts_client_credentials_grant(self, client_creds):
        mock_response = MagicMock()
        mock_response.ok = True
        mock_response.json.return_value = {"access_token": "machine-token", "expires_in": 3600}

        with patch.dict(os.environ, _CLIENT_ENV):
            with patch(
                "redenlab_extract.credentials.requests.post", return_value=mock_response
            ) as mock_post:
                client_creds._do_refresh()

        data = mock_post.call_args.kwargs["data"]
        assert data["grant_type"] == "client_credentials"
        assert "ml-api/" in data["scope"]

    def test_raises_when_env_vars_missing(self, client_creds):
        with patch.dict(os.environ, {}, clear=True):
            with pytest.raises(AuthenticationError, match="REDENLAB_CLIENT_ID"):
                client_creds._do_refresh()

    def test_raises_on_request_exception(self, client_creds):
        with patch.dict(os.environ, _CLIENT_ENV):
            with patch(
                "redenlab_extract.credentials.requests.post",
                side_effect=requests.RequestException("timeout"),
            ):
                with pytest.raises(AuthenticationError, match="Token request failed"):
                    client_creds._do_refresh()

    def test_raises_on_non_ok_response(self, client_creds):
        mock_response = MagicMock()
        mock_response.ok = False
        mock_response.status_code = 401

        with patch.dict(os.environ, _CLIENT_ENV):
            with patch("redenlab_extract.credentials.requests.post", return_value=mock_response):
                with pytest.raises(AuthenticationError, match="Machine authentication failed"):
                    client_creds._do_refresh()

    def test_raises_when_access_token_absent_from_response(self, client_creds):
        mock_response = MagicMock()
        mock_response.ok = True
        mock_response.json.return_value = {"expires_in": 3600}

        with patch.dict(os.environ, _CLIENT_ENV):
            with patch("redenlab_extract.credentials.requests.post", return_value=mock_response):
                with pytest.raises(AuthenticationError, match="no access token"):
                    client_creds._do_refresh()


# ---------------------------------------------------------------------------
# build_credentials factory
# ---------------------------------------------------------------------------


class TestBuildCredentials:
    def test_returns_pkce_when_no_env_vars(self):
        with patch.dict(os.environ, {}, clear=True):
            with patch("redenlab_extract.credentials._load_tokens", return_value=_VALID_TOKENS):
                creds = build_credentials(_COGNITO_CONFIG)
        assert isinstance(creds, PKCECredentials)

    def test_returns_client_credentials_when_both_env_vars_set(self):
        with patch.dict(os.environ, _CLIENT_ENV):
            creds = build_credentials(_COGNITO_CONFIG)
        assert isinstance(creds, ClientCredentials)

    def test_raises_when_only_client_id_set(self):
        with patch.dict(os.environ, {"REDENLAB_CLIENT_ID": "only-id"}, clear=True):
            with pytest.raises(ConfigurationError, match="Both REDENLAB_CLIENT_ID"):
                build_credentials(_COGNITO_CONFIG)

    def test_raises_when_only_client_secret_set(self):
        with patch.dict(os.environ, {"REDENLAB_CLIENT_SECRET": "only-secret"}, clear=True):
            with pytest.raises(ConfigurationError, match="Both REDENLAB_CLIENT_ID"):
                build_credentials(_COGNITO_CONFIG)
