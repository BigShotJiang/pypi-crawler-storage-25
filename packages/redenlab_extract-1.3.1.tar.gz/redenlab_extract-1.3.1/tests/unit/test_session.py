from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from redenlab_extract import Asset, RedenLabSession
from redenlab_extract.exceptions import ConfigurationError, UploadError, ValidationError
from redenlab_extract.session import _resolve_base_url

# ---------------------------------------------------------------------------
# Shared constants
# ---------------------------------------------------------------------------

_DEFAULT_BASE_URL = "https://test.api.com"
_DEFAULT_COGNITO = {"domain": "test.auth.com", "client_id": "test-client"}
_DEFAULT_HEADERS = {
    "Authorization": "Bearer test-token",
    "Content-Type": "application/json",
    "Accept": "application/json",
}

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def session():
    """Valid RedenLabSession with all external collaborators mocked."""
    with (
        patch("redenlab_extract.session._resolve_base_url", return_value=_DEFAULT_BASE_URL),
        patch("redenlab_extract.session.get_cognito_config", return_value=_DEFAULT_COGNITO),
        patch("redenlab_extract.session.build_credentials") as mock_build_creds,
    ):
        mock_creds = MagicMock()
        mock_creds.get_headers.return_value = _DEFAULT_HEADERS
        mock_build_creds.return_value = mock_creds
        yield RedenLabSession()


# ---------------------------------------------------------------------------
# Init / configuration
# ---------------------------------------------------------------------------


class TestInit:
    def test_base_url_set_from_config(self, session):
        assert session.base_url == _DEFAULT_BASE_URL

    @patch("redenlab_extract.session.build_credentials")
    @patch("redenlab_extract.session.get_cognito_config", return_value=_DEFAULT_COGNITO)
    @patch(
        "redenlab_extract.session.get_default_base_url", return_value="https://discovery.api.com"
    )
    @patch("redenlab_extract.session._resolve_base_url", return_value=None)
    def test_base_url_falls_back_to_discovery(
        self, mock_resolve, mock_default_url, mock_cognito, mock_build_creds
    ):
        mock_build_creds.return_value = MagicMock()
        s = RedenLabSession()
        assert s.base_url == "https://discovery.api.com"
        mock_default_url.assert_called_once()

    @patch("redenlab_extract.session.build_credentials")
    @patch("redenlab_extract.session.get_cognito_config", return_value=_DEFAULT_COGNITO)
    @patch("redenlab_extract.session.get_default_base_url", return_value=None)
    @patch("redenlab_extract.session._resolve_base_url", return_value=None)
    def test_missing_base_url_raises_configuration_error(
        self, mock_resolve, mock_default_url, mock_cognito, mock_build_creds
    ):
        with pytest.raises(ConfigurationError, match="No API base URL"):
            RedenLabSession()

    @patch("redenlab_extract.session.get_cognito_config", return_value=None)
    @patch("redenlab_extract.session._resolve_base_url", return_value=_DEFAULT_BASE_URL)
    def test_discovery_failure_raises_configuration_error(self, mock_resolve, mock_cognito):
        with pytest.raises(ConfigurationError, match="discovery"):
            RedenLabSession()

    @patch("redenlab_extract.session.build_credentials")
    @patch("redenlab_extract.session.get_cognito_config", return_value=_DEFAULT_COGNITO)
    @patch("redenlab_extract.session._resolve_base_url", return_value=_DEFAULT_BASE_URL)
    def test_cognito_config_forwarded_to_credentials(
        self, mock_resolve, mock_cognito, mock_build_creds
    ):
        RedenLabSession()
        mock_build_creds.assert_called_once_with(_DEFAULT_COGNITO)


# ---------------------------------------------------------------------------
# _resolve_base_url — priority resolution
# ---------------------------------------------------------------------------


class TestResolveBaseUrl:
    def test_kwarg_beats_env_var(self, monkeypatch):
        monkeypatch.setenv("REDENLAB_ML_BASE_URL", "https://env.api.com")
        assert _resolve_base_url("https://kwarg.api.com", None) == "https://kwarg.api.com"

    def test_kwarg_beats_config_file(self, tmp_path):
        config = tmp_path / "config.yaml"
        config.write_text("base_url: https://config.api.com\n")
        assert _resolve_base_url("https://kwarg.api.com", config) == "https://kwarg.api.com"

    def test_env_var_beats_config_file(self, monkeypatch, tmp_path):
        monkeypatch.setenv("REDENLAB_ML_BASE_URL", "https://env.api.com")
        config = tmp_path / "config.yaml"
        config.write_text("base_url: https://config.api.com\n")
        assert _resolve_base_url(None, config) == "https://env.api.com"

    def test_config_file_used_when_no_kwarg_or_env(self, monkeypatch, tmp_path):
        monkeypatch.delenv("REDENLAB_ML_BASE_URL", raising=False)
        config = tmp_path / "config.yaml"
        config.write_text("base_url: https://config.api.com\n")
        assert _resolve_base_url(None, config) == "https://config.api.com"

    def test_returns_none_when_nothing_configured(self, monkeypatch, tmp_path):
        monkeypatch.delenv("REDENLAB_ML_BASE_URL", raising=False)
        assert _resolve_base_url(None, tmp_path / "nonexistent.yaml") is None

    def test_invalid_yaml_raises_configuration_error(self, monkeypatch, tmp_path):
        monkeypatch.delenv("REDENLAB_ML_BASE_URL", raising=False)
        config = tmp_path / "config.yaml"
        config.write_text(":\t invalid yaml\n")
        with pytest.raises(ConfigurationError, match="Failed to parse config file"):
            _resolve_base_url(None, config)

    def test_non_dict_config_raises_configuration_error(self, monkeypatch, tmp_path):
        monkeypatch.delenv("REDENLAB_ML_BASE_URL", raising=False)
        config = tmp_path / "config.yaml"
        config.write_text("- item1\n- item2\n")
        with pytest.raises(ConfigurationError, match="must contain a YAML dictionary"):
            _resolve_base_url(None, config)


# ---------------------------------------------------------------------------
# get_auth_headers
# ---------------------------------------------------------------------------


class TestGetAuthHeaders:

    def test_delegates_to_credentials(self, session):
        headers = session.get_auth_headers()
        assert headers == _DEFAULT_HEADERS
        session._credentials.get_headers.assert_called_once()


# ---------------------------------------------------------------------------
# upload
# ---------------------------------------------------------------------------


class TestUpload:
    @patch("redenlab_extract.session.upload_to_presigned_url")
    @patch("redenlab_extract.session.api.request_presigned_url")
    @patch("redenlab_extract.session.get_content_type", return_value="audio/wav")
    @patch("redenlab_extract.session.validate_file_path")
    def test_returns_asset_with_correct_fields(
        self, mock_validate, mock_content_type, mock_presigned, mock_upload, session, tmp_path
    ):
        test_file = tmp_path / "test_audio.wav"
        test_file.write_bytes(b"\x00" * 10)
        mock_validate.return_value = test_file
        mock_presigned.return_value = ("asset-123", "https://s3.example.com/upload", 3600)

        asset = session.upload(str(test_file))

        assert isinstance(asset, Asset)
        assert asset.asset_id == "asset-123"
        assert asset.filename == "test_audio.wav"
        assert asset.content_type == "audio/wav"
        assert asset.duration is None

    @patch("redenlab_extract.session.upload_to_presigned_url")
    @patch("redenlab_extract.session.api.request_presigned_url")
    @patch("redenlab_extract.session.get_content_type", return_value="audio/wav")
    @patch("redenlab_extract.session.validate_file_path")
    def test_auth_headers_forwarded_to_api(
        self, mock_validate, mock_content_type, mock_presigned, mock_upload, session, tmp_path
    ):
        test_file = tmp_path / "test_audio.wav"
        test_file.write_bytes(b"\x00" * 10)
        mock_validate.return_value = test_file
        mock_presigned.return_value = ("asset-123", "https://s3.example.com/upload", 3600)

        session.upload(str(test_file))

        assert mock_presigned.call_args.kwargs["auth_headers"] == _DEFAULT_HEADERS

    @patch("redenlab_extract.session.validate_file_path")
    def test_propagates_validation_error(self, mock_validate, session):
        mock_validate.side_effect = ValidationError("File does not exist")
        with pytest.raises(ValidationError, match="does not exist"):
            session.upload("/nonexistent/path.wav")

    @patch("redenlab_extract.session.upload_to_presigned_url")
    @patch("redenlab_extract.session.api.request_presigned_url")
    @patch("redenlab_extract.session.get_content_type", return_value="audio/wav")
    @patch("redenlab_extract.session.validate_file_path")
    def test_propagates_upload_error(
        self, mock_validate, mock_content_type, mock_presigned, mock_upload, session, tmp_path
    ):
        test_file = tmp_path / "test_audio.wav"
        test_file.write_bytes(b"\x00" * 10)
        mock_validate.return_value = test_file
        mock_presigned.return_value = ("asset-123", "https://s3.example.com/upload", 3600)
        mock_upload.side_effect = UploadError("S3 upload failed (HTTP 403)")

        with pytest.raises(UploadError, match="S3 upload failed"):
            session.upload(str(test_file))


# ---------------------------------------------------------------------------
# upload_chunked
# ---------------------------------------------------------------------------


class TestUploadChunked:
    @patch("redenlab_extract.session.upload_to_presigned_url")
    @patch("redenlab_extract.session.api.request_presigned_url")
    @patch("redenlab_extract.session.get_content_type", return_value="audio/wav")
    @patch("redenlab_extract.session.validate_file_path")
    @patch("redenlab_extract.session._get_audio_duration", side_effect=ImportError)
    def test_falls_back_to_single_upload_when_soundfile_missing(
        self,
        mock_duration,
        mock_validate,
        mock_content_type,
        mock_presigned,
        mock_upload,
        session,
        tmp_path,
    ):
        test_file = tmp_path / "test.wav"
        test_file.write_bytes(b"\x00" * 10)
        mock_validate.return_value = test_file
        mock_presigned.return_value = ("asset-123", "https://s3.example.com/upload", 3600)

        result = session.upload_chunked(str(test_file))

        assert len(result) == 1
        assert result[0].asset_id == "asset-123"

    @patch("redenlab_extract.session.upload_to_presigned_url")
    @patch("redenlab_extract.session.api.request_presigned_url")
    @patch("redenlab_extract.session.get_content_type", return_value="audio/wav")
    @patch("redenlab_extract.session.validate_file_path")
    @patch("redenlab_extract.session._get_audio_duration", return_value=30.0)
    def test_short_file_returns_single_asset_without_parent(
        self,
        mock_duration,
        mock_validate,
        mock_content_type,
        mock_presigned,
        mock_upload,
        session,
        tmp_path,
    ):
        test_file = tmp_path / "short.wav"
        test_file.write_bytes(b"\x00" * 10)
        mock_validate.return_value = test_file
        mock_presigned.return_value = ("asset-short", "https://s3.example.com/upload", 3600)

        result = session.upload_chunked(str(test_file), chunk_duration=50.0)

        assert len(result) == 1
        assert result[0].asset_id == "asset-short"
        assert result[0].parent_asset_id is None

    @patch("redenlab_extract.session._cleanup_chunk_files")
    @patch("redenlab_extract.session._split_audio_into_chunks")
    @patch("redenlab_extract.session.upload_to_presigned_url")
    @patch("redenlab_extract.session.api.request_presigned_url")
    @patch("redenlab_extract.session.get_content_type", return_value="audio/wav")
    @patch("redenlab_extract.session.validate_file_path")
    @patch("redenlab_extract.session._get_audio_duration", return_value=120.0)
    def test_long_file_chunks_linked_to_parent(
        self,
        mock_duration,
        mock_validate,
        mock_content_type,
        mock_presigned,
        mock_upload,
        mock_split,
        mock_cleanup,
        session,
        tmp_path,
    ):
        test_file = tmp_path / "long.wav"
        test_file.write_bytes(b"\x00" * 10)
        mock_validate.return_value = test_file

        chunk_files = [tmp_path / f"chunk_{i}.wav" for i in range(3)]
        for f in chunk_files:
            f.write_bytes(b"\x00" * 10)
        mock_split.return_value = [str(f) for f in chunk_files]

        call_count = 0

        def presigned_side_effect(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return ("parent-id", "https://s3.example.com/parent", 3600)
            return (f"chunk-id-{call_count - 2}", f"https://s3.example.com/chunk", 3600)

        mock_presigned.side_effect = presigned_side_effect

        result = session.upload_chunked(str(test_file), chunk_duration=50.0)

        assert len(result) == 3
        for i, chunk in enumerate(result):
            assert chunk.parent_asset_id == "parent-id"
            assert chunk.chunk_index == i
            assert chunk.asset_id == f"chunk-id-{i}"

    @patch("redenlab_extract.session._cleanup_chunk_files")
    @patch("redenlab_extract.session._split_audio_into_chunks")
    @patch("redenlab_extract.session.upload_to_presigned_url")
    @patch("redenlab_extract.session.api.request_presigned_url")
    @patch("redenlab_extract.session.get_content_type", return_value="audio/wav")
    @patch("redenlab_extract.session.validate_file_path")
    @patch("redenlab_extract.session._get_audio_duration", return_value=120.0)
    def test_cleanup_runs_even_when_chunk_upload_fails(
        self,
        mock_duration,
        mock_validate,
        mock_content_type,
        mock_presigned,
        mock_upload,
        mock_split,
        mock_cleanup,
        session,
        tmp_path,
    ):
        test_file = tmp_path / "long.wav"
        test_file.write_bytes(b"\x00" * 10)
        mock_validate.return_value = test_file

        chunk_files = [tmp_path / f"chunk_{i}.wav" for i in range(2)]
        for f in chunk_files:
            f.write_bytes(b"\x00" * 10)
        chunk_paths = [str(f) for f in chunk_files]
        mock_split.return_value = chunk_paths

        # Parent upload succeeds; first chunk presigned URL request fails
        mock_presigned.side_effect = [
            ("parent-id", "https://s3.example.com/parent", 3600),
            UploadError("chunk request failed"),
        ]

        with pytest.raises(UploadError):
            session.upload_chunked(str(test_file))

        mock_cleanup.assert_called_once_with(chunk_paths)
