"""
Payload builders for model-specific inference requests.

Uses the Strategy pattern to encapsulate model-specific parameter handling.
Each model gets its own builder that knows how to construct the API payload.
"""

from abc import ABC, abstractmethod
from typing import Any


class PayloadBuilder(ABC):
    """
    Abstract base class for model-specific payload builders.

    Each model implementation defines how to build its specific payload
    from core fields and model-specific parameters.

    IMPORTANT: Builder instances are shared (singleton pattern).
    Implementations MUST be stateless - do not store data in self.
    All state should be passed as parameters.
    """

    @abstractmethod
    def build(self, asset_id: str, **model_params: Any) -> dict[str, Any]:
        """
        Build the payload for API submission.

        Args:
            asset_id: Asset identifier (backend derives s3_key from uploads table)
            **model_params: Model-specific parameters

        Returns:
            Dictionary payload for API request
        """
        pass

    @abstractmethod
    def validate_params(self, **model_params: Any) -> None:
        """
        Validate model-specific parameters.

        Args:
            **model_params: Parameters to validate

        Raises:
            ValueError: If parameters are invalid
        """
        pass


class TranscribePayloadBuilder(PayloadBuilder):
    """Payload builder for the transcribe model."""

    def build(self, asset_id: str, **model_params: Any) -> dict[str, Any]:
        """
        Build transcribe model payload.

        Args:
            asset_id: Asset identifier
            **model_params: Must include 'language_code', optionally 'max_speaker_count'

        Returns:
            Payload with asset_id, language_code, and optionally max_speaker_count
        """
        self.validate_params(**model_params)

        payload = {
            "asset_id": asset_id,
            "language_code": model_params["language_code"],
        }

        # Add max_speaker_count if provided
        if "max_speaker_count" in model_params:
            payload["max_speaker_count"] = model_params["max_speaker_count"]

        return payload

    def validate_params(self, **model_params: Any) -> None:
        """Validate that language_code is provided and max_speaker_count is valid if provided."""
        if "language_code" not in model_params:
            raise ValueError(
                "transcribe model requires 'language_code' parameter "
                "(e.g., 'en-US', 'es-ES')"
                "Provide it either in TranscribeClient(..., language_code='en-US') "
                "or in submit(file_path, language_code='en-US')"
            )

        language_code = model_params["language_code"]
        if not isinstance(language_code, str) or not language_code:
            raise ValueError(f"language_code must be a non-empty string, got: {language_code!r}")

        # Validate max_speaker_count if provided
        if "max_speaker_count" in model_params:
            max_speaker_count = model_params["max_speaker_count"]
            if not isinstance(max_speaker_count, int):
                raise ValueError(
                    f"max_speaker_count must be an integer, got: {type(max_speaker_count).__name__}"
                )
            if max_speaker_count < 2 or max_speaker_count > 10:
                raise ValueError(
                    f"max_speaker_count must be between 2 and 10, got: {max_speaker_count}"
                )


class IntelligibilityPayloadBuilder(PayloadBuilder):
    """Payload builder for the intelligibility model."""

    def build(self, asset_id: str, **model_params: Any) -> dict[str, Any]:
        """
        Build intelligibility model payload.

        Args:
            asset_id: Asset identifier
            **model_params: No extra parameters required

        Returns:
            Payload with just asset_id
        """
        self.validate_params(**model_params)

        return {
            "asset_id": asset_id,
        }

    def validate_params(self, **model_params: Any) -> None:
        """Validate that no unexpected parameters are provided."""
        if model_params:
            unexpected = ", ".join(model_params.keys())
            raise ValueError(
                f"intelligibility model does not accept parameters, " f"but got: {unexpected}"
            )


class WhisperXPayloadBuilder(PayloadBuilder):
    """Payload builder for the whisperx model."""

    def build(self, asset_id: str, **model_params: Any) -> dict[str, Any]:
        """
        Build whisperx model payload.

        Args:
            asset_id: Asset identifier
            **model_params: Optionally 'diarize' (bool, default False) and
                           'batch_size' (int, default 16)

        Returns:
            Payload with asset_id, diarize, and batch_size
        """
        self.validate_params(**model_params)

        return {
            "asset_id": asset_id,
            "diarize": model_params.get("diarize", False),
            "batch_size": model_params.get("batch_size", 16),
        }

    def validate_params(self, **model_params: Any) -> None:
        """Validate diarize and batch_size if provided."""
        allowed = {"diarize", "batch_size"}
        unexpected = [k for k in model_params if k not in allowed]
        if unexpected:
            raise ValueError(
                f"whisperx model only accepts 'diarize' and 'batch_size' parameters, "
                f"but got unexpected: {', '.join(unexpected)}"
            )

        if "diarize" in model_params:
            diarize = model_params["diarize"]
            if not isinstance(diarize, bool):
                raise ValueError(f"diarize must be a bool, got: {type(diarize).__name__}")

        if "batch_size" in model_params:
            batch_size = model_params["batch_size"]
            if not isinstance(batch_size, int):
                raise ValueError(f"batch_size must be an integer, got: {type(batch_size).__name__}")
            if batch_size < 1:
                raise ValueError(f"batch_size must be >= 1, got: {batch_size}")


class SpeakerDiarizationPayloadBuilder(PayloadBuilder):
    """Payload builder for the speaker diarization model."""

    def build(self, asset_id: str, **model_params: Any) -> dict[str, Any]:
        """
        Build speaker diarization model payload.

        Args:
            asset_id: Asset identifier
            **model_params: Optionally 'num_speakers' (int, 1-10)

        Returns:
            Payload with asset_id and optionally num_speakers
        """
        self.validate_params(**model_params)

        payload = {
            "asset_id": asset_id,
        }

        # Add num_speakers if provided
        if "num_speakers" in model_params:
            payload["num_speakers"] = model_params["num_speakers"]

        return payload

    def validate_params(self, **model_params: Any) -> None:
        """Validate num_speakers if provided."""
        # Only num_speakers is allowed
        unexpected = [k for k in model_params.keys() if k != "num_speakers"]
        if unexpected:
            raise ValueError(
                f"speaker_diarization model only accepts 'num_speakers' parameter, "
                f"but got unexpected: {', '.join(unexpected)}"
            )

        # Validate num_speakers if provided
        if "num_speakers" in model_params:
            num_speakers = model_params["num_speakers"]
            if not isinstance(num_speakers, int):
                raise ValueError(
                    f"num_speakers must be an integer, got: {type(num_speakers).__name__}"
                )
            if num_speakers < 1 or num_speakers > 10:
                raise ValueError(f"num_speakers must be between 1 and 10, got: {num_speakers}")


# Registry mapping model names to their payload builders
PAYLOAD_BUILDERS: dict[str, PayloadBuilder] = {
    "transcribe": TranscribePayloadBuilder(),
    "als-intelligibility-mtpa": IntelligibilityPayloadBuilder(),
    "als-intelligibility-eals": IntelligibilityPayloadBuilder(),
    "als-naturalness-mtpa": IntelligibilityPayloadBuilder(),
    "als-naturalness-eals": IntelligibilityPayloadBuilder(),
    "ataxia-intelligibility": IntelligibilityPayloadBuilder(),
    "ataxia-naturalness": IntelligibilityPayloadBuilder(),
    "sylber-time": IntelligibilityPayloadBuilder(),
    "speaker_counter": IntelligibilityPayloadBuilder(),
    "speaker_diarisation_workflow": SpeakerDiarizationPayloadBuilder(),
    "whisperx": WhisperXPayloadBuilder(),
}


def get_payload_builder(model_name: str) -> PayloadBuilder:
    """
    Get the payload builder for a given model.

    Args:
        model_name: Name of the model

    Returns:
        PayloadBuilder instance for the model

    Raises:
        ValueError: If model is not supported
    """
    if model_name not in PAYLOAD_BUILDERS:
        supported = ", ".join(PAYLOAD_BUILDERS.keys())
        raise ValueError(f"Unsupported model: {model_name!r}. " f"Supported models: {supported}")

    return PAYLOAD_BUILDERS[model_name]


def register_payload_builder(model_name: str, builder: PayloadBuilder) -> None:
    """
    Register a custom payload builder for a model.

    This allows users to extend the SDK with custom models.

    Args:
        model_name: Name of the model
        builder: PayloadBuilder instance

    Example:
        >>> class CustomBuilder(PayloadBuilder):
        ...     def build(self, asset_id, **params):
        ...         return {"asset_id": asset_id, "custom": params}
        ...     def validate_params(self, **params):
        ...         pass
        >>> register_payload_builder("custom_model", CustomBuilder())
    """
    PAYLOAD_BUILDERS[model_name] = builder
