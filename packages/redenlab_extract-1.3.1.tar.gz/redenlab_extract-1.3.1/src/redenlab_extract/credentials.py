"""
Credential management for RedenLab Extract SDK.

Owns the full credential class hierarchy and PKCE-specific token persistence.
All credential classes share the cache gate in BaseCredentials and implement
_do_refresh() with auth-mode-specific logic.

Disk persistence (_load_tokens, _save_tokens) is module-private — only
PKCECredentials and login.py use it. ClientCredentials has no disk state.

Tokens are stored in ~/.redenlab-ml/credentials.yaml, separate from the
runtime config at ~/.redenlab-ml/config.yaml.
"""

import os
from abc import ABC, abstractmethod
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import requests
import yaml

from .exceptions import AuthenticationError, ConfigurationError

_CREDENTIALS_PATH = Path.home() / ".redenlab-ml" / "credentials.yaml"
_REFRESH_BUFFER_MINUTES = 5


# ---------------------------------------------------------------------------
# Disk persistence — PKCE only
# ---------------------------------------------------------------------------


def _load_tokens() -> dict[str, str] | None:
    """Read stored PKCE tokens from credentials.yaml."""
    if not _CREDENTIALS_PATH.exists():
        return None
    try:
        with open(_CREDENTIALS_PATH) as f:
            data = yaml.safe_load(f) or {}
    except (yaml.YAMLError, OSError):
        return None
    required = {"access_token", "refresh_token", "token_expiry", "user_sub"}
    if not required.issubset(data.keys()):
        return None
    return {k: str(data[k]) for k in required}


def _save_tokens(
    access_token: str,
    refresh_token: str,
    token_expiry: str,
    user_sub: str,
) -> None:
    """Write PKCE tokens to credentials.yaml (owner read/write only)."""
    _CREDENTIALS_PATH.parent.mkdir(parents=True, exist_ok=True)
    data = {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_expiry": token_expiry,
        "user_sub": user_sub,
    }
    with open(_CREDENTIALS_PATH, "w") as f:
        yaml.dump(data, f, default_flow_style=False)
    os.chmod(_CREDENTIALS_PATH, 0o600)


# ---------------------------------------------------------------------------
# Credential classes
# ---------------------------------------------------------------------------


class BaseCredentials(ABC):
    """
    Abstract base for credential providers.

    Owns the in-memory token cache. Subclasses implement _do_refresh() with
    auth-mode-specific logic; everything else (cache gate, expiry check,
    header building) is shared here.
    """

    def __init__(self) -> None:
        self._cached_token: str | None = None
        self._token_expiry: datetime | None = None

    def get_token(self) -> str:
        """Return a valid access token, refreshing silently if needed."""
        if self._cached_token and not self._is_token_expiring():
            return self._cached_token
        token, expiry = self._do_refresh()
        self._cached_token = token
        self._token_expiry = expiry
        return token

    def get_headers(self) -> dict[str, str]:
        """Build HTTP Authorization headers for an API request."""
        return {
            "Authorization": f"Bearer {self.get_token()}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    def _is_token_expiring(self) -> bool:
        if self._token_expiry is None:
            return True
        buffer = timedelta(minutes=_REFRESH_BUFFER_MINUTES)
        return datetime.now(timezone.utc) >= (self._token_expiry - buffer)

    @abstractmethod
    def _do_refresh(self) -> tuple[str, datetime]:
        """Fetch a fresh token. Returns (access_token, expiry)."""
        ...


class PKCECredentials(BaseCredentials):
    """
    Credentials for human users authenticated via the PKCE browser flow.

    Loads the stored token from credentials.yaml into the in-memory cache on
    init. Refreshes via the Cognito refresh_token grant and persists the new
    token back to disk.
    """

    def __init__(self, cognito_config: dict[str, Any]) -> None:
        super().__init__()
        self._cognito_config = cognito_config

        stored = _load_tokens()
        if not stored:
            raise AuthenticationError(
                "Not authenticated. Please run 'redenlab login' to authenticate."
            )

        self._cached_token = stored["access_token"]
        self._refresh_token = stored["refresh_token"]
        self._user_sub = stored["user_sub"]
        try:
            self._token_expiry = datetime.fromisoformat(stored["token_expiry"])
        except (ValueError, TypeError):
            self._token_expiry = None

    def _do_refresh(self) -> tuple[str, datetime]:
        token_url = f"https://{self._cognito_config['domain']}/oauth2/token"

        try:
            response = requests.post(
                token_url,
                data={
                    "grant_type": "refresh_token",
                    "client_id": self._cognito_config["client_id"],
                    "refresh_token": self._refresh_token,
                },
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                timeout=10,
            )
        except requests.RequestException as e:
            raise AuthenticationError(f"Token refresh failed: {e}") from e

        if not response.ok:
            raise AuthenticationError(
                "Session expired. Please run 'redenlab login' to re-authenticate."
            )

        data = response.json()
        access_token = data.get("access_token")
        expires_in = data.get("expires_in", 3600)

        if not access_token:
            raise AuthenticationError(
                "Session expired. Please run 'redenlab login' to re-authenticate."
            )

        expiry = datetime.now(timezone.utc) + timedelta(seconds=expires_in)

        _save_tokens(
            access_token=access_token,
            refresh_token=self._refresh_token,
            token_expiry=expiry.isoformat(),
            user_sub=self._user_sub,
        )

        return access_token, expiry


class ClientCredentials(BaseCredentials):
    """
    Credentials for machine/service users via the OAuth2 Client Credentials grant.

    Reads REDENLAB_CLIENT_ID and REDENLAB_CLIENT_SECRET from environment variables.
    Starts cold — fetches on the first API call. Never reads or writes disk tokens.
    """

    def __init__(self, cognito_config: dict[str, Any]) -> None:
        super().__init__()
        self._cognito_config = cognito_config

    def _do_refresh(self) -> tuple[str, datetime]:
        import base64

        from .payload import PAYLOAD_BUILDERS

        client_id = os.environ.get("REDENLAB_CLIENT_ID", "")
        client_secret = os.environ.get("REDENLAB_CLIENT_SECRET", "")

        if not client_id or not client_secret:
            raise AuthenticationError(
                "REDENLAB_CLIENT_ID and REDENLAB_CLIENT_SECRET must be set for machine auth."
            )

        scope = " ".join(f"ml-api/{model}" for model in PAYLOAD_BUILDERS)
        token_url = f"https://{self._cognito_config['domain']}/oauth2/token"
        encoded = base64.b64encode(f"{client_id}:{client_secret}".encode()).decode()

        try:
            response = requests.post(
                token_url,
                data={"grant_type": "client_credentials", "scope": scope},
                headers={
                    "Content-Type": "application/x-www-form-urlencoded",
                    "Authorization": f"Basic {encoded}",
                },
                timeout=10,
            )
        except requests.RequestException as e:
            raise AuthenticationError(f"Token request failed: {e}") from e

        if not response.ok:
            raise AuthenticationError(
                f"Machine authentication failed (HTTP {response.status_code}). "
                "Check REDENLAB_CLIENT_ID and REDENLAB_CLIENT_SECRET."
            )

        data = response.json()
        access_token = data.get("access_token")
        expires_in = data.get("expires_in", 3600)

        if not access_token:
            raise AuthenticationError(
                "Machine authentication failed: no access token in Cognito response."
            )

        expiry = datetime.now(timezone.utc) + timedelta(seconds=expires_in)
        return access_token, expiry


def build_credentials(cognito_config: dict[str, Any]) -> BaseCredentials:
    """
    Factory that selects the right credential subclass based on environment.

    Machine auth (Client Credentials) is used when both REDENLAB_CLIENT_ID and
    REDENLAB_CLIENT_SECRET are set. Falls back to PKCECredentials otherwise.
    """
    client_id = os.environ.get("REDENLAB_CLIENT_ID")
    client_secret = os.environ.get("REDENLAB_CLIENT_SECRET")

    if client_id and client_secret:
        return ClientCredentials(cognito_config)
    if client_id or client_secret:
        raise ConfigurationError(
            "Both REDENLAB_CLIENT_ID and REDENLAB_CLIENT_SECRET must be set for machine auth."
        )
    return PKCECredentials(cognito_config)
