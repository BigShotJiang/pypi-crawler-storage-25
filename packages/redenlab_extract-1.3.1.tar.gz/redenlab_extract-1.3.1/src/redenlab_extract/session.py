"""
Session management for RedenLab Extract SDK.

RedenLabSession is the authenticated SDK context: it owns a base URL and a
credentials object, and exposes asset-surface operations (upload today,
list/delete later). Service discovery lives in discovery.py; token lifecycle
lives in credentials.py. This module only orchestrates them and provides the
asset operations.
"""

import os
from pathlib import Path

import yaml

from . import api
from .asset import Asset
from .credentials import build_credentials
from .discovery import get_cognito_config, get_default_base_url
from .exceptions import ConfigurationError, ValidationError
from .upload import (
    _cleanup_chunk_files,
    _get_audio_duration,
    _split_audio_into_chunks,
    upload_to_presigned_url,
)
from .utils import get_content_type, validate_file_path

# ---------------------------------------------------------------------------
# Base URL resolution
# ---------------------------------------------------------------------------

_CONFIG_PATH = Path.home() / ".redenlab-ml" / "config.yaml"


def _resolve_base_url(kwarg: str | None, config_path: Path | None) -> str | None:
    """
    Resolve base URL from the three user-controlled sources, in priority order:
    1. Constructor kwarg
    2. REDENLAB_ML_BASE_URL env var
    3. base_url field in config.yaml

    Returns None if none are set; caller falls back to discovery.
    """
    if kwarg:
        return kwarg
    env = os.environ.get("REDENLAB_ML_BASE_URL")
    if env:
        return env
    path = config_path if config_path is not None else _CONFIG_PATH
    if path.exists():
        try:
            with open(path) as f:
                data = yaml.safe_load(f) or {}
            if not isinstance(data, dict):
                raise ConfigurationError(
                    f"Config file must contain a YAML dictionary, got {type(data)}"
                )
            return data.get("base_url")
        except yaml.YAMLError as e:
            raise ConfigurationError(f"Failed to parse config file: {e}") from e
        except OSError as e:
            raise ConfigurationError(f"Failed to read config file: {e}") from e
    return None


# ---------------------------------------------------------------------------
# Session
# ---------------------------------------------------------------------------


class RedenLabSession:
    """
    Authenticated session for talking to the RedenLab API.

    Owns a base URL and a credentials object, and exposes asset-surface
    operations: uploading files and producing reusable Asset objects that
    any inference client can consume.

    Run 'redenlab login' to authenticate before creating a session.

    Args:
        base_url: API base URL (optional, defaults to discovery)
        config_path: Path to config file (optional)
    """

    def __init__(
        self,
        base_url: str | None = None,
        config_path: str | None = None,
    ):
        """
        Initialize session, loading credentials from stored config.

        Raises:
            AuthenticationError: If no credentials are found (run 'redenlab login')
            ConfigurationError: If configuration or discovery is unavailable
        """
        config_path_obj: Path | None = Path(config_path) if config_path else None

        self.base_url: str = _resolve_base_url(base_url, config_path_obj) or get_default_base_url()  # type: ignore[assignment]
        if not self.base_url or not isinstance(self.base_url, str):
            raise ConfigurationError(
                "No API base URL configured. Please set via:\n"
                "1. RedenLabSession(base_url='https://...')\n"
                "2. Environment variable: REDENLAB_ML_BASE_URL\n"
                "3. Config file: ~/.redenlab-ml/config.yaml"
            )

        cognito_config = get_cognito_config()
        if not cognito_config:
            raise ConfigurationError(
                "Could not reach RedenLab discovery service. "
                "Check your internet connection and try again."
            )

        self._credentials = build_credentials(cognito_config)

    def get_auth_headers(self) -> dict[str, str]:
        """
        Get authentication headers for an API request.

        Returns a valid Bearer token, refreshing silently from the in-memory
        cache if the token is expired or expiring within 5 minutes.

        Returns:
            Dict of HTTP headers including Authorization: Bearer <token>

        Raises:
            AuthenticationError: If credentials are missing or refresh fails
        """
        return self._credentials.get_headers()

    def upload(self, file_path: str) -> Asset:
        """
        Upload a single audio file to S3.

        1. Requests a presigned URL from the backend
        2. Uploads the file to S3 synchronously
        3. Returns an Asset object immediately

        **Important:** After the S3 upload completes, the backend updates the
        upload status (upload_pending → uploaded). This typically takes 1-3 seconds.
        The SDK handles this automatically when you use client.predict().

        Args:
            file_path: Path to the audio file to upload

        Returns:
            Asset object representing the uploaded file

        Raises:
            ValidationError: If file path is invalid or file type not supported
            AuthenticationError: If credentials are invalid or expired
            UploadError: If file upload fails
            APIError: If API communication fails
        """
        file_path_obj = validate_file_path(file_path)
        content_type = get_content_type(file_path)
        filename = file_path_obj.name

        asset_id, upload_url, expires_in = api.request_presigned_url(
            base_url=self.base_url,
            auth_headers=self.get_auth_headers(),
            filename=filename,
            content_type=content_type,
        )

        upload_to_presigned_url(
            file_path=str(file_path_obj),
            presigned_url=upload_url,
            content_type=content_type,
        )

        return Asset(
            asset_id=asset_id,
            filename=filename,
            content_type=content_type,
            duration=None,
        )

    def upload_chunked(
        self,
        file_path: str,
        chunk_duration: float = 50.0,
        overlap: float = 1.0,
    ) -> list[Asset]:
        """
        Upload audio file with automatic chunking for long files.

        If file duration <= chunk_duration, uploads as a single asset.
        Otherwise:
        1. Uploads the original file as a parent record
        2. Splits the file into chunks locally
        3. Uploads each chunk with parent_asset_id referencing the original file

        Args:
            file_path: Path to the audio file to upload
            chunk_duration: Duration of each chunk in seconds (default: 50)
            overlap: Overlap between chunks in seconds (default: 1.0)

        Returns:
            List of Asset objects. Each has parent_asset_id set to the original
            file's asset_id.

        Raises:
            ValidationError: If file path is invalid or file type not supported
            AuthenticationError: If credentials are invalid or expired
            UploadError: If file upload fails
            APIError: If API communication fails
            ImportError: If soundfile is not installed
        """
        try:
            duration = _get_audio_duration(file_path)
        except ImportError:
            return [self.upload(file_path)]

        if duration <= chunk_duration:
            return [self.upload(file_path)]

        parent_asset = self.upload(file_path)
        parent_asset_id = parent_asset.asset_id

        chunk_files = _split_audio_into_chunks(
            file_path, chunk_duration=int(chunk_duration), overlap=overlap
        )

        if not chunk_files:
            return [parent_asset]

        chunks: list[Asset] = []
        seen_indices: set[int] = set()

        try:
            for i, chunk_file in enumerate(chunk_files):
                if i in seen_indices:
                    raise ValidationError(f"Duplicate chunk_index {i} detected")
                seen_indices.add(i)

                file_path_obj = Path(chunk_file)
                content_type = get_content_type(chunk_file)
                filename = file_path_obj.name

                asset_id, upload_url, expires_in = api.request_presigned_url(
                    base_url=self.base_url,
                    auth_headers=self.get_auth_headers(),
                    filename=filename,
                    content_type=content_type,
                    parent_asset_id=parent_asset_id,
                    chunk_index=i,
                )

                upload_to_presigned_url(
                    file_path=str(file_path_obj),
                    presigned_url=upload_url,
                    content_type=content_type,
                )

                chunks.append(
                    Asset(
                        asset_id=asset_id,
                        filename=filename,
                        content_type=content_type,
                        duration=None,
                        parent_asset_id=parent_asset_id,
                        chunk_index=i,
                    )
                )

            return chunks
        finally:
            _cleanup_chunk_files(chunk_files)

    def __repr__(self) -> str:
        return f"RedenLabSession(base_url='{self.base_url}')"
