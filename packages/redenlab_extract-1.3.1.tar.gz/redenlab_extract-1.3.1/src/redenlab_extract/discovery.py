"""
Service discovery for RedenLab Extract SDK.

Read-only view of remote runtime metadata. Fetches the endpoint manifest
from CloudFront and caches it locally with a TTL. Exposes typed accessors
for the slices callers actually need (base URL, Cognito config) so the
manifest shape stays an internal concern.

This module is a leaf: no auth, no session, no user config. It must remain
importable before any session exists — login.py and credentials.py both
depend on it.
"""

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import requests

DISCOVERY_URL = "https://d8eq7mphxcvfl.cloudfront.net/endpoint.json"

_CACHE_TTL_HOURS = 24
_FETCH_TIMEOUT_SECONDS = 5


def _get_url_cache_path() -> Path:
    return Path.home() / ".redenlab-ml" / "url_cache.json"


def _read_url_cache() -> dict[str, Any] | None:
    cache_path = _get_url_cache_path()
    if not cache_path.exists():
        return None
    try:
        with open(cache_path) as f:
            cache_data = json.load(f)
        if not isinstance(cache_data, dict):
            return None
        # Old format had "base_url" at top level — not compatible with new structure
        if "discovery" not in cache_data or "fetched_at" not in cache_data:
            return None
        return cache_data
    except (json.JSONDecodeError, OSError):
        return None


def _write_url_cache(discovery: dict[str, Any]) -> None:
    cache_path = _get_url_cache_path()
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    cache_data = {
        "discovery": discovery,
        "fetched_at": datetime.now(timezone.utc).isoformat(),
    }
    try:
        with open(cache_path, "w") as f:
            json.dump(cache_data, f, indent=2)
    except OSError:
        pass


def _is_url_cache_valid(cache_data: dict[str, Any]) -> bool:
    try:
        fetched_at = datetime.fromisoformat(cache_data["fetched_at"])
        age = datetime.now(timezone.utc) - fetched_at
        return age < timedelta(hours=_CACHE_TTL_HOURS)
    except (ValueError, KeyError, TypeError):
        return False


def _validate_base_url(url: str) -> bool:
    if not isinstance(url, str):
        return False
    if not url.startswith("https://"):
        return False
    valid_patterns = [
        "intelligens.redenlab",
        "amazonaws.com",
        "cloudfront.net",
        ".redenlab.",
        "redenlab-",
    ]
    return any(pattern in url for pattern in valid_patterns)


def _fetch_discovery_config() -> dict[str, Any] | None:
    try:
        response = requests.get(DISCOVERY_URL, timeout=_FETCH_TIMEOUT_SECONDS)
        response.raise_for_status()
        data = response.json()
        if not isinstance(data, dict):
            return None
        base_url = data.get("base_url")
        if not base_url or not isinstance(base_url, str):
            return None
        if not _validate_base_url(base_url):
            return None
        return data
    except (requests.RequestException, json.JSONDecodeError, KeyError):
        return None


def _get_cached_discovery() -> dict[str, Any] | None:
    """
    Return the discovery JSON, using the on-disk cache when fresh.

    Flow: fresh cache → CloudFront fetch → stale cache → None.
    """
    cache_data = _read_url_cache()
    if cache_data and _is_url_cache_valid(cache_data):
        return dict(cache_data["discovery"])
    discovery = _fetch_discovery_config()
    if discovery:
        _write_url_cache(discovery)
        return discovery
    if cache_data and "discovery" in cache_data:
        return dict(cache_data["discovery"])
    return None


def get_default_base_url() -> str | None:
    """Return the API base URL from discovery, or None if unavailable."""
    discovery = _get_cached_discovery()
    if not discovery:
        return None
    base_url = discovery.get("base_url")
    if isinstance(base_url, str) and _validate_base_url(base_url):
        return base_url
    return None


def get_cognito_config() -> dict[str, Any] | None:
    """
    Return Cognito configuration from discovery.

    Returns:
        Dict with keys: user_pool_id, client_id, domain, region
        Returns None if discovery fails or the cognito section is incomplete.
    """
    discovery = _get_cached_discovery()
    if not discovery:
        return None
    cognito = discovery.get("cognito")
    if not isinstance(cognito, dict):
        return None
    required_fields = {"user_pool_id", "client_id", "domain", "region"}
    if not required_fields.issubset(cognito.keys()):
        return None
    return {
        "user_pool_id": cognito["user_pool_id"],
        "client_id": cognito["client_id"],
        "domain": cognito["domain"],
        "region": cognito["region"],
    }
