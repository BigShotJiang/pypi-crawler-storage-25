"""
RedenLab Extract SDK

Python SDK for RedenLab's ML inference service.
"""

__version__ = "1.3.1"

# Core classes
from .asset import Asset
from .client import (
    InferenceClient,
    TranscribeClient,
    intelligibility_client,
    naturalness_client,
    speaker_counter_client,
    speaker_diarization_client,
    sylber_time_client,
    whisperX_client,
)

# Exceptions
from .exceptions import (
    APIError,
    AuthenticationError,
    ConfigurationError,
    InferenceError,
    RedenLabMLError,
    TimeoutError,
    UploadError,
    ValidationError,
)
from .session import RedenLabSession

# Workflow functions
from .workflows import aggregate_results, run_chunked_inference, run_inference

__all__ = [
    # Core classes
    "Asset",
    "RedenLabSession",
    "InferenceClient",
    "TranscribeClient",
    # Factory functions
    "intelligibility_client",
    "naturalness_client",
    "speaker_counter_client",
    "speaker_diarization_client",
    "sylber_time_client",
    "whisperX_client",
    # Workflow functions
    "run_inference",
    "run_chunked_inference",
    "aggregate_results",
    # Exceptions
    "RedenLabMLError",
    "AuthenticationError",
    "InferenceError",
    "TimeoutError",
    "APIError",
    "UploadError",
    "ValidationError",
    "ConfigurationError",
]
