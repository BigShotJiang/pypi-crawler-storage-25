"""
PKCE login flow for RedenLab ML SDK.

Implements the OAuth2 Authorization Code flow with PKCE for human SDK users.
Stores tokens in ~/.redenlab-ml/credentials.yaml after successful authentication.
"""

import base64
import hashlib
import http.server
import secrets
import threading
import urllib.parse
import webbrowser
from datetime import datetime, timedelta, timezone
from typing import Any

import requests

from .credentials import _load_tokens, _save_tokens
from .discovery import get_cognito_config
from .exceptions import AuthenticationError, ConfigurationError

_CALLBACK_PATH = "/callback"
_CALLBACK_PORTS = [9999]
_LOGIN_TIMEOUT_SECONDS = 300  # 5 minutes
_TOKEN_EXCHANGE_TIMEOUT_SECONDS = 10


def _generate_pkce_pair() -> tuple[str, str]:
    """
    Generate a PKCE code verifier and code challenge.

    Returns:
        Tuple of (code_verifier, code_challenge)
    """
    code_verifier = base64.urlsafe_b64encode(secrets.token_bytes(32)).rstrip(b"=").decode()
    digest = hashlib.sha256(code_verifier.encode()).digest()
    code_challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode()
    return code_verifier, code_challenge


def _build_auth_url(cognito_config: dict[str, Any], port: int, code_challenge: str) -> str:
    """
    Build the Cognito authorization URL for the PKCE flow.

    Args:
        cognito_config: Cognito config dict from get_cognito_config()
        port: Localhost port for the callback
        code_challenge: PKCE code challenge

    Returns:
        Full authorization URL string
    """
    params = {
        "response_type": "code",
        "client_id": cognito_config["client_id"],
        "redirect_uri": f"http://localhost:{port}{_CALLBACK_PATH}",
        "code_challenge": code_challenge,
        "code_challenge_method": "S256",
        "scope": "openid email",
    }
    query = urllib.parse.urlencode(params)
    return f"https://{cognito_config['domain']}/oauth2/authorize?{query}"


def _exchange_code_for_tokens(
    code: str,
    code_verifier: str,
    cognito_config: dict[str, Any],
    port: int,
) -> dict[str, Any]:
    """
    Exchange authorization code for tokens via Cognito token endpoint.

    Args:
        code: Authorization code from callback
        code_verifier: PKCE code verifier
        cognito_config: Cognito config dict
        port: Localhost port used for the redirect URI

    Returns:
        Dict with access_token, refresh_token, expires_in

    Raises:
        AuthenticationError: If token exchange fails
    """
    token_url = f"https://{cognito_config['domain']}/oauth2/token"

    try:
        response = requests.post(
            token_url,
            data={
                "grant_type": "authorization_code",
                "client_id": cognito_config["client_id"],
                "code": code,
                "redirect_uri": f"http://localhost:{port}{_CALLBACK_PATH}",
                "code_verifier": code_verifier,
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            timeout=_TOKEN_EXCHANGE_TIMEOUT_SECONDS,
        )
    except requests.RequestException as e:
        raise AuthenticationError(f"Token exchange failed: {e}") from e

    if not response.ok:
        raise AuthenticationError(
            f"Token exchange failed (HTTP {response.status_code}). Please try logging in again."
        )

    data: dict[str, Any] = response.json()

    if "access_token" not in data or "refresh_token" not in data:
        raise AuthenticationError("Unexpected response from Cognito. Please try logging in again.")

    return data


class _CallbackHandler(http.server.BaseHTTPRequestHandler):
    """Minimal HTTP handler that captures the OAuth2 callback."""

    auth_code: str | None = None
    error: str | None = None

    def do_GET(self) -> None:
        parsed = urllib.parse.urlparse(self.path)

        if parsed.path != _CALLBACK_PATH:
            self._send_response(400, "<h2>Unexpected request.</h2>")
            return

        params = urllib.parse.parse_qs(parsed.query)

        if "error" in params:
            _CallbackHandler.error = params["error"][0]
            self._send_response(400, "<h2>Authentication failed. You can close this tab.</h2>")
        elif "code" in params:
            _CallbackHandler.auth_code = params["code"][0]
            self._send_response(
                200,
                "<html><body><h2>Login successful. You can close this tab.</h2></body></html>",
            )
        else:
            _CallbackHandler.error = "No code in callback"
            self._send_response(400, "<h2>No authorization code received.</h2>")

    def _send_response(self, status: int, body: str) -> None:
        self.send_response(status)
        self.send_header("Content-Type", "text/html")
        self.end_headers()
        self.wfile.write(body.encode())

    def log_message(self, format: str, *args: Any) -> None:
        pass  # Suppress default request logging


def _find_available_port() -> int:
    """
    Find an available localhost port from the configured range.

    Returns:
        Available port number

    Raises:
        ConfigurationError: If all ports in the range are in use
    """
    import socket

    for port in _CALLBACK_PORTS:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("localhost", port))
                return port
            except OSError:
                continue

    ports_str = "–".join(str(p) for p in [_CALLBACK_PORTS[0], _CALLBACK_PORTS[-1]])
    raise ConfigurationError(
        f"Could not start local server: ports {ports_str} are all in use. "
        "Free a port and try again."
    )


def _wait_for_callback(port: int) -> str:
    """
    Start a localhost HTTP server and wait for the OAuth2 callback.

    Args:
        port: Port to listen on

    Returns:
        Authorization code from callback

    Raises:
        AuthenticationError: If callback returns an error, times out, or is cancelled
    """
    _CallbackHandler.auth_code = None
    _CallbackHandler.error = None

    server = http.server.HTTPServer(("localhost", port), _CallbackHandler)
    server.timeout = _LOGIN_TIMEOUT_SECONDS

    def serve() -> None:
        server.handle_request()

    thread = threading.Thread(target=serve, daemon=True)
    thread.start()
    thread.join(timeout=_LOGIN_TIMEOUT_SECONDS)

    server.server_close()

    if _CallbackHandler.error:
        raise AuthenticationError(
            f"Authentication failed: {_CallbackHandler.error}. "
            "Please run 'redenlab login' again."
        )

    if not _CallbackHandler.auth_code:
        raise AuthenticationError("Login timed out. Please run 'redenlab login' again.")

    return _CallbackHandler.auth_code


def _check_existing_credentials() -> bool:
    """
    Check if valid credentials exist and prompt the user if so.

    Returns:
        True if login should proceed, False if user cancelled
    """
    from datetime import datetime, timezone

    credentials = _load_tokens()

    if not credentials:
        return True

    try:
        expiry = datetime.fromisoformat(credentials["token_expiry"])
        is_expired = datetime.now(timezone.utc) >= expiry
    except (ValueError, TypeError):
        is_expired = True

    if is_expired:
        print("Your session has expired, logging in again...")
        return True

    # Valid session — prompt before overwriting
    try:
        answer = input("You're already logged in. Re-authenticate anyway? [y/N] ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print("\nLogin cancelled.")
        return False

    return answer == "y"


def login() -> None:
    """
    Authenticate with RedenLab via browser-based PKCE login.

    Opens the browser to the Cognito hosted UI. After the user authenticates,
    tokens are stored in ~/.redenlab-ml/credentials.yaml.

    Raises:
        ConfigurationError: If Cognito config cannot be fetched or no port is available
        AuthenticationError: If login fails or times out
    """
    if not _check_existing_credentials():
        return

    cognito_config = get_cognito_config()
    if not cognito_config:
        raise ConfigurationError(
            "Could not fetch Cognito configuration from the discovery service. "
            "Check your internet connection and try again."
        )

    port = _find_available_port()
    code_verifier, code_challenge = _generate_pkce_pair()
    auth_url = _build_auth_url(cognito_config, port, code_challenge)

    opened = webbrowser.open(auth_url)
    if opened:
        print("Opening browser for authentication...")
    else:
        print(
            "Could not open browser automatically. Open this URL to authenticate:\n\n"
            f"  {auth_url}\n"
        )

    print(f"Waiting for login to complete (timeout: {_LOGIN_TIMEOUT_SECONDS // 60} minutes)...")

    try:
        auth_code = _wait_for_callback(port)
    except KeyboardInterrupt:
        print("\nLogin cancelled.")
        return

    tokens = _exchange_code_for_tokens(auth_code, code_verifier, cognito_config, port)

    expires_in = tokens.get("expires_in", 3600)
    token_expiry = (datetime.now(timezone.utc) + timedelta(seconds=expires_in)).isoformat()

    # Extract user_sub from the access token payload (middle segment, base64url-decoded)
    user_sub = _extract_sub(tokens["access_token"])

    _save_tokens(
        access_token=tokens["access_token"],
        refresh_token=tokens["refresh_token"],
        token_expiry=token_expiry,
        user_sub=user_sub,
    )

    print("\n✓ Login successful. Credentials saved to ~/.redenlab-ml/config.yaml")


def _extract_sub(access_token: str) -> str:
    """
    Extract the 'sub' claim from a JWT access token without verifying the signature.

    Args:
        access_token: JWT string

    Returns:
        Sub claim string, or empty string if extraction fails
    """
    try:
        import json

        payload_segment = access_token.split(".")[1]
        # Add padding if needed
        padding = 4 - len(payload_segment) % 4
        if padding != 4:
            payload_segment += "=" * padding
        payload = json.loads(base64.urlsafe_b64decode(payload_segment))
        return str(payload.get("sub", ""))
    except Exception:
        return ""
