"""
File upload functionality for RedenLab ML SDK.

Handles uploading files to S3 via presigned URLs, and audio chunking helpers
used by RedenLabSession.upload_chunked.
"""

import os
import tempfile
from collections.abc import Callable
from pathlib import Path
from typing import BinaryIO

import requests
from requests.exceptions import ConnectionError, RequestException, Timeout

from .exceptions import UploadError, ValidationError
from .utils import format_file_size, get_file_size, validate_file_path

# ---------------------------------------------------------------------------
# Audio chunking helpers
# ---------------------------------------------------------------------------


def _get_audio_duration(file_path: str) -> float:
    """
    Get audio file duration in seconds without loading the entire file.

    Raises:
        ValidationError: If file cannot be read
        ImportError: If soundfile is not installed
    """
    try:
        import soundfile as sf
    except ImportError as e:
        raise ImportError(
            "soundfile is required for audio chunking. " "Install it with: pip install soundfile"
        ) from e

    try:
        info = sf.info(file_path)
        return float(info.duration)
    except Exception as e:
        raise ValidationError(f"Cannot read audio file duration: {e}") from e


def _split_audio_into_chunks(
    file_path: str, chunk_duration: int = 60, overlap: float = 1.0
) -> list[str]:
    """
    Split audio file into chunks with overlap.

    Creates temporary chunk files with naming pattern:
    {base_name}_chunk_{index}_of_{total}.{ext}

    Returns:
        List of paths to temporary chunk files, or empty list if chunking not required.

    Raises:
        ValidationError: If file cannot be read or split
        ImportError: If soundfile/numpy is not installed
    """
    try:
        import numpy as np
        import soundfile as sf
    except ImportError as e:
        raise ImportError(
            "soundfile and numpy are required for audio chunking. "
            "Install them with: pip install soundfile numpy"
        ) from e

    path = validate_file_path(file_path)

    try:
        data, samplerate = sf.read(str(path))

        total_duration = len(data) / samplerate

        if total_duration <= chunk_duration:
            return []

        chunk_samples = int(chunk_duration * samplerate)
        overlap_samples = int(overlap * samplerate)
        step_samples = chunk_samples - overlap_samples

        num_chunks = int(np.ceil((len(data) - overlap_samples) / step_samples))

        temp_dir = tempfile.mkdtemp(prefix="redenlab_audio_chunks_")

        base_name = path.stem
        ext = path.suffix

        chunk_files = []

        for i in range(num_chunks):
            start = i * step_samples
            end = min(start + chunk_samples, len(data))

            chunk_data = data[start:end]

            chunk_filename = f"{base_name}_chunk_{i}_of_{num_chunks}{ext}"
            chunk_path = os.path.join(temp_dir, chunk_filename)

            sf.write(chunk_path, chunk_data, samplerate)
            chunk_files.append(chunk_path)

        return chunk_files

    except Exception as e:
        raise ValidationError(f"Failed to split audio file: {e}") from e


def _cleanup_chunk_files(chunk_files: list[str]) -> None:
    """Clean up temporary chunk files and their parent directory."""
    if not chunk_files:
        return

    try:
        temp_dir = os.path.dirname(chunk_files[0])

        for chunk_file in chunk_files:
            try:
                if os.path.exists(chunk_file):
                    os.remove(chunk_file)
            except Exception:
                pass

        try:
            if os.path.exists(temp_dir):
                os.rmdir(temp_dir)
        except Exception:
            pass

    except Exception:
        pass


# ---------------------------------------------------------------------------
# S3 upload
# ---------------------------------------------------------------------------

# Default timeout for upload requests (in seconds)
# Larger than API requests since we're uploading potentially large files
DEFAULT_UPLOAD_TIMEOUT = 300  # 5 minutes


def upload_to_presigned_url(
    file_path: str,
    presigned_url: str,
    content_type: str,
    timeout: int = DEFAULT_UPLOAD_TIMEOUT,
    progress_callback: Callable[[int, int], None] | None = None,
) -> None:
    """
    Upload a file to S3 using a presigned URL.

    Args:
        file_path: Path to the file to upload
        presigned_url: Presigned S3 URL from the API
        content_type: MIME type of the file (e.g., 'audio/wav')
        timeout: Upload timeout in seconds
        progress_callback: Optional callback function(bytes_uploaded, total_bytes)
                          called during upload to report progress

    Raises:
        UploadError: If upload fails for any reason

    Example:
        >>> def progress(uploaded, total):
        ...     percent = (uploaded / total) * 100
        ...     print(f"Upload progress: {percent:.1f}%")
        >>> upload_to_presigned_url(
        ...     'audio.wav',
        ...     'https://s3.amazonaws.com/...',
        ...     'audio/wav',
        ...     progress_callback=progress
        ... )
    """
    path = Path(file_path)

    # Validate file exists
    if not path.exists():
        raise UploadError(f"File does not exist: {file_path}")

    if not path.is_file():
        raise UploadError(f"Path is not a file: {file_path}")

    # Get file size for progress tracking
    try:
        file_size = get_file_size(file_path)
    except Exception as e:
        raise UploadError(f"Cannot read file: {e}") from e

    # Create progress tracking wrapper if callback provided
    data: bytes | _ProgressTrackingFile
    if progress_callback:
        data = _ProgressTrackingFile(file_path, progress_callback, file_size)
    else:
        try:
            with open(file_path, "rb") as f:
                data = f.read()
        except OSError as e:
            raise UploadError(f"Cannot read file: {e}") from e

    # Prepare headers
    headers = {
        "Content-Type": content_type,
    }

    # Upload file
    try:
        response = requests.put(
            presigned_url,
            data=data,
            headers=headers,
            timeout=timeout,
        )

        # Check for errors
        if not response.ok:
            error_message = response.text or f"HTTP {response.status_code}"
            raise UploadError(f"Upload failed (HTTP {response.status_code}): {error_message}")

    except Timeout as e:
        raise UploadError(
            f"Upload timed out after {timeout} seconds. "
            f"File size: {format_file_size(file_size)}. "
            "Try increasing the timeout or checking your network connection."
        ) from e
    except ConnectionError as e:
        raise UploadError(f"Connection error during upload: {e}") from e
    except RequestException as e:
        raise UploadError(f"Upload failed: {e}") from e
    except Exception as e:
        raise UploadError(f"Unexpected error during upload: {e}") from e
    finally:
        # Close the file if we opened it for progress tracking
        if progress_callback and hasattr(data, "close"):
            data.close()


class _ProgressTrackingFile:
    """
    File-like object that reports upload progress via callback.

    This wrapper reads the file in chunks and calls the progress callback
    after each chunk is read.
    """

    def __init__(
        self,
        file_path: str,
        callback: Callable[[int, int], None],
        total_size: int,
        chunk_size: int = 8192,
    ):
        """
        Initialize progress tracking file wrapper.

        Args:
            file_path: Path to the file
            callback: Function to call with (bytes_read, total_bytes)
            total_size: Total file size in bytes
            chunk_size: Size of chunks to read (default 8KB)
        """
        self.file_path = file_path
        self.callback = callback
        self.total_size = total_size
        self.chunk_size = chunk_size
        self.bytes_read = 0
        self._file: BinaryIO | None = None

    def __enter__(self):
        """Open the file when entering context."""
        self._file = open(self.file_path, "rb")
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Close the file when exiting context."""
        if self._file:
            self._file.close()

    def read(self, size: int = -1) -> bytes:
        """
        Read from the file and report progress.

        Args:
            size: Number of bytes to read (-1 for all)

        Returns:
            Bytes read from file
        """
        if self._file is None:
            self._file = open(self.file_path, "rb")

        # Determine how much to read
        if size == -1:
            chunk_size = self.chunk_size
        else:
            chunk_size = min(size, self.chunk_size)

        # Read chunk
        chunk = self._file.read(chunk_size)

        if chunk:
            # Update progress
            self.bytes_read += len(chunk)

            # Call progress callback
            try:
                self.callback(self.bytes_read, self.total_size)
            except Exception:
                # Don't let callback errors break the upload
                pass

        return chunk

    def __iter__(self):
        """Make this object iterable for requests library."""
        return self

    def __next__(self):
        """Read next chunk for iteration."""
        chunk = self.read(self.chunk_size)
        if not chunk:
            raise StopIteration
        return chunk

    def close(self):
        """Close the underlying file."""
        if self._file:
            self._file.close()
            self._file = None
