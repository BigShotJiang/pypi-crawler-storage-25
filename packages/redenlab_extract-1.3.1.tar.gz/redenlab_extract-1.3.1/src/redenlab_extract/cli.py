"""
Command-line interface for RedenLab ML SDK.

Entry point registered as the 'redenlab' command via pyproject.toml.
"""

import argparse
import sys


def cmd_login(_args: argparse.Namespace) -> None:
    """Handle the 'redenlab login' subcommand."""
    from .exceptions import AuthenticationError, ConfigurationError
    from .login import login

    try:
        login()
    except ConfigurationError as e:
        print(f"Configuration error: {e}", file=sys.stderr)
        sys.exit(1)
    except AuthenticationError as e:
        print(f"Authentication error: {e}", file=sys.stderr)
        sys.exit(1)


def main() -> None:
    """Entry point for the 'redenlab' CLI command."""
    parser = argparse.ArgumentParser(
        prog="redenlab",
        description="RedenLab ML SDK command-line tools",
    )

    subparsers = parser.add_subparsers(dest="command", metavar="<command>")
    subparsers.required = True

    login_parser = subparsers.add_parser("login", help="Authenticate with RedenLab")
    login_parser.set_defaults(func=cmd_login)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
