# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.3.0] - 2026-05-13

### Breaking Changes

- **API key authentication removed.** `RedenLabSession` no longer accepts `api_key`.
  Existing sessions using `RedenLabSession(api_key=...)` will break. See Added below
  for migration.
- **`~/.redenlab-ml/config.yaml` token format changed.** Tokens are no longer stored
  in a `cognito:` section of `config.yaml`. They moved to a separate
  `~/.redenlab-ml/credentials.yaml`. Run `redenlab login` again after upgrading.

### Added

- **`redenlab login` CLI command** — opens a browser-based PKCE flow to authenticate
  with AWS Cognito. Stores tokens in `~/.redenlab-ml/credentials.yaml`.
- **JWT authentication via AWS Cognito** replacing API keys. Two modes, auto-detected
  by `RedenLabSession()`:
  - **Human / interactive** (`PKCECredentials`): run `redenlab login` once. Tokens are
    stored in `~/.redenlab-ml/credentials.yaml` and silently refreshed on expiry.
  - **Machine / headless** (`ClientCredentials`): set `REDENLAB_CLIENT_ID` and
    `REDENLAB_CLIENT_SECRET` environment variables. Token fetched on first API call
    via OAuth2 Client Credentials grant; no disk I/O.
- **`credentials.py`** — credential class hierarchy: `BaseCredentials` (in-memory cache
  gate), `PKCECredentials`, `ClientCredentials`, and `build_credentials()` factory that
  auto-selects the mode from the environment.
- **`discovery.py`** — service discovery: fetches the CloudFront manifest, maintains an
  on-disk URL cache (24 h TTL with stale fallback), exposes `get_default_base_url()` and
  `get_cognito_config()`.
- **Token / config file split:**
  - `~/.redenlab-ml/credentials.yaml` — PKCE tokens only (flat, `chmod 600`).
  - `~/.redenlab-ml/config.yaml` — runtime overrides only (`base_url`, `timeout`).

### Changed

- **`RedenLabSession.__init__`** — `api_key` parameter removed. Base URL resolved via
  `_resolve_base_url()` (constructor kwarg → `REDENLAB_ML_BASE_URL` env var →
  `~/.redenlab-ml/config.yaml` → service discovery). Credentials via `build_credentials()`.
- **`TranscribeClient.submit()`** — `max_speaker_count` is now always included in the
  payload, defaulting to `10` when not set. The transcribe Lambda always sets
  `ShowSpeakerLabels=True`, which requires `MaxSpeakerLabels` to be an integer; omitting
  it previously caused a boto3 `ParamValidationError` (HTTP 500).
- **Audio helpers** (`_get_audio_duration`, `_split_audio_into_chunks`,
  `_cleanup_chunk_files`) moved from `session.py` to `upload.py`.
- **Integration tests** rewritten: credentials loaded from `tests/fixtures/config.yaml`
  (`client_id` / `client_secret` / `base_url`), clients constructed via `RedenLabSession()`
  and factory functions, submit tests use `_submit_with_upload_wait()`.

### Fixed

- `mypy` errors in `discovery.py` and `login.py` (`Returning Any from function declared
  to return dict[str, Any] | None`).

### Removed

- **`config.py`** — dissolved: discovery logic moved to `discovery.py`, base URL
  resolution to `session.py`, token persistence to `credentials.py`.
- **`auth.py`** — dissolved: token lifecycle inlined into `credentials.py` classes,
  header construction inlined into `BaseCredentials.get_headers()`.

## [1.2.0] - 2026-04-14

### Added
- **New `whisperX_client()`** - WhisperX speech recognition with word-level timestamps
  - Accepts `diarize` (bool, default `False`) to enable speaker diarization
  - Accepts `batch_size` (int, default `16`) to control inference batch size
  - Submits full audio as a whole (no chunking)
  - Supports warmup via `client.warmup()`
  - Returns segments with word-level timestamps, confidence scores, and speaker labels (when diarization enabled)
- **`WhisperXPayloadBuilder`** - Payload builder for the whisperx model
  - Validates `diarize` (bool) and `batch_size` (int >= 1)

## [1.1.0] - 2026-03-27

### Added
- **New `speaker_diarization_client()`** - Advanced speaker diarization using speaker counter + pyannote pipeline
  - Supports auto-detection of speaker count using speaker counter model
  - Supports manual speaker count specification via `num_speakers` parameter (1-10)
  - Per-file speaker count configuration for processing multiple files with different speaker counts
  - Returns detailed diarization segments with timestamps and speaker labels
  - Returns primary speaker identification (speaker with most talking time)
- **`max_speaker_count` parameter for `TranscribeClient`** - Control AWS Transcribe speaker diarization
  - Can be set per-prediction for different files
  - Validates range (2-10 speakers)
- **`SpeakerDiarizationPayloadBuilder`** - Payload builder for speaker diarization model
  - Validates `num_speakers` parameter (1-10 range)
  - Supports optional speaker count specification

### Changed
- Updated `TranscribePayloadBuilder` to support `max_speaker_count` parameter

## [1.0.0] - 2026-03-XX


## [0.4.0] - 2026-01-21

### Added
- Model versioning with alias support (v1/v2 aliases map to backend model names)
- Integration tests for `IntelligibilityClient` and `TranscribeClient`
- Standard deviation (`std_dev`) output when calling `_poll_multiple`

### Changed
- **Breaking**: Renamed package from `redenlab_ml` to `redenlab_extract`
- Updated imports throughout codebase to use new package name
- Improved type annotations for mypy compliance

## [0.3.0] - 2026-01-13

### Added
- Added all intelligibility and naturalness models
- Intelligibility and naturalness can chunk audio and run inference on them to provide aggregate results
- Users can check health of endpoints and wake them up

### Changed
- Updated minimum Python version requirement to 3.10+ (using modern `|` union type syntax)
- Fixed code formatting to comply with Black formatter
- Fixed type checking issues for mypy compliance

## [0.2.0] - 2025-01-15

### Added
- **New `submit()` method** - Upload file and submit inference job without blocking, returns `job_id` immediately
- **New `poll()` method** - Poll for job completion with customizable timeout and progress callbacks
- Support for efficient batch processing by separating submit and poll phases
- Ability to resume polling for jobs after program restart (using `job_id`)

### Changed
- Refactored `predict()` to use `submit()` + `poll()` internally (backward compatible, same behavior)
- Improved documentation with batch processing examples
- Added `test_batch_inference.py` demonstrating three usage patterns

### Documentation
- Added batch processing guide in README
- Updated API documentation with submit/poll examples

## [0.1.0] - 2025-01-10

### Added
- Initial release
- Core `InferenceClient` for ML inference
- File upload to S3 via presigned URLs
- Async job management with polling
- Authentication via API key
- Support for multiple models (intelligibility, speaker diarization, etc.)
- Retry logic with exponential backoff
- Comprehensive error handling
- Configuration via environment variables and config files

[Unreleased]: https://github.com/redenlab/redenlab-ml-sdk/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/redenlab/redenlab-ml-sdk/releases/tag/v0.1.0
