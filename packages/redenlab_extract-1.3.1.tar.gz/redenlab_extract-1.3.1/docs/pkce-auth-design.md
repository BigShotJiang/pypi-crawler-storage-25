# PKCE Authentication — SDK Design

## Background

The backend has migrated from per-user API keys (`X-Api-Key` header) to Cognito JWT-based
authentication (`Authorization: Bearer <access_token>`). This document covers the SDK-side
implementation of the human user (PKCE) authentication flow.

Machine/service authentication (OAuth2 Client Credentials) is deferred to a follow-up PR.
Test updates are also deferred.

---

## User Flow

```
redenlab login
  → SDK fetches Cognito config from discovery URL
  → SDK generates PKCE code verifier + challenge
  → SDK starts localhost HTTP server (port 9999–10001)
  → SDK opens browser to Cognito hosted UI
  → User authenticates in browser
  → Cognito redirects to localhost callback with auth code
  → SDK exchanges code + verifier for tokens
  → SDK saves tokens to ~/.redenlab-ml/config.yaml

Every subsequent SDK call:
  → RedenLabSession.get_auth_headers() checks token expiry
  → If expiry within 5 minutes: silently refreshes via Cognito token endpoint
  → If refresh token expired: raises AuthenticationError("Session expired. Please run 'redenlab login' to re-authenticate.")
  → Returns {"Authorization": "Bearer <access_token>", "Content-Type": "application/json", "Accept": "application/json"}
  → api.py passes headers directly to HTTP request
```

---

## Discovery URL

The existing `endpoint.json` (served via CloudFront at `DISCOVERY_URL`) is extended to include
Cognito config alongside the existing `base_url`:

```json
{
  "base_url": "https://aq8qparreh.execute-api.us-west-2.amazonaws.com/prod",
  "updated_at": "2025-01-21T14:30:00Z",
  "version": "2.0",
  "cognito": {
    "user_pool_id": "us-west-2_xxxxx",
    "client_id": "xxxxx",
    "domain": "redenlab-ml.auth.us-west-2.amazoncognito.com",
    "region": "us-west-2"
  }
}
```

The `config.py` fetch/cache layer is refactored to cache the full JSON response (not just
`base_url`). Both `get_default_base_url()` and `get_cognito_config()` read from the same
cache file (`~/.redenlab-ml/url_cache.json`), extending it to store the full discovery payload.
Cache TTL remains 24 hours.

---

## Credential Storage

Tokens are stored in `~/.redenlab-ml/config.yaml` under a `cognito:` section:

```yaml
cognito:
  access_token: eyJ...
  refresh_token: eyJ...
  token_expiry: "2026-04-27T15:30:00+00:00"   # now + expires_in at login time
  user_sub: "us-west-2_xxxxx|cognito-sub"
```

`token_expiry` is stored as an ISO 8601 timestamp so expiry can be checked without
decoding the JWT.

File permissions on `~/.redenlab-ml/config.yaml` are set to `600` (owner read/write only)
when credentials are written. This matches the convention used by `~/.aws/credentials`.

### Re-login behaviour

| State | Behaviour |
|---|---|
| Credentials exist and valid | Prompt: `"You're already logged in. Re-authenticate anyway? [y/N]"` |
| Credentials exist but expired | Skip prompt, print `"Your session has expired, logging in again..."` |
| No credentials | Proceed silently |

---

## PKCE Flow Details

### Port selection
Try ports `9999 → 10000 → 10001` in order. Fail with a clear error if all are in use:
```
Could not start local server: ports 9999-10001 are all in use. Free a port and try again.
```

### Scopes
`openid email`

### Authorization URL
```
https://{domain}/oauth2/authorize
  ?response_type=code
  &client_id={client_id}
  &redirect_uri=http://localhost:{port}/callback
  &code_challenge={code_challenge}
  &code_challenge_method=S256
  &scope=openid+email
```

### PKCE parameters
- `code_verifier`: 32 random bytes, base64url-encoded (no padding)
- `code_challenge`: `base64url(SHA256(code_verifier))`
- Both generated using stdlib (`secrets`, `hashlib`) — no new dependencies

### Browser failure
If `webbrowser.open()` fails, print the URL for manual copy-paste:
```
Could not open browser automatically. Open this URL to authenticate:

  https://redenlab-ml.auth.us-west-2.amazoncognito.com/oauth2/authorize?...

Waiting for login to complete (timeout: 5 minutes)...
```

### Callback timeout
5 minutes. On timeout:
```
Login timed out. Please run 'redenlab login' again.
```

### Post-callback browser page
Simple HTML response:
```html
<html><body><h2>Login successful. You can close this tab.</h2></body></html>
```

### Token exchange
`POST https://{domain}/oauth2/token` with:
- `grant_type=authorization_code`
- `client_id={client_id}`
- `code={auth_code}`
- `redirect_uri=http://localhost:{port}/callback`
- `code_verifier={code_verifier}`

Response fields saved: `access_token`, `refresh_token`, `expires_in` (used to compute `token_expiry`).

---

## Token Lifecycle

### Lazy evaluation
`RedenLabSession.get_auth_headers()` is called before every API request (not once at session
init). This ensures long-running batch jobs (polling for hours) always use a valid token.

### Refresh logic
```
if token_expiry - now < 5 minutes:
    POST /oauth2/token with grant_type=refresh_token
    save new access_token + token_expiry
    (refresh_token itself is not rotated by Cognito)
```

### Refresh token expiry (30-day TTL)
If the refresh token has expired, Cognito returns a 400. The SDK raises:
```
AuthenticationError("Session expired. Please run 'redenlab login' to re-authenticate.")
```

---

## Files Changed

### New files
| File | Purpose |
|---|---|
| `src/redenlab_extract/login.py` | PKCE flow: PKCE generation, localhost server, browser open, token exchange, credential save |
| `src/redenlab_extract/cli.py` | `redenlab login` entry point using `argparse` with subcommands |

### Modified files
| File | Changes |
|---|---|
| `config.py` | Refactor cache to store full discovery JSON; add `get_cognito_config()`; add `save_credentials()` / `load_credentials()`; add file permission (`600`) logic |
| `auth.py` | Replace API key functions with `get_access_token()` and `get_auth_headers(token) -> dict`; remove `validate_api_key`, `mask_api_key`, `validate_api_key_format` |
| `session.py` | Remove `api_key` parameter entirely; add `get_auth_headers() -> dict` lazy method; remove `self.api_key`; simplify `__repr__` |
| `api.py` | Replace `api_key: str` parameter with `auth_headers: dict` in all 4 functions; remove internal `get_auth_headers()` call |
| `utils.py` | Remove `validate_api_key_format` |
| `pyproject.toml` | Add `[project.scripts]` entry: `redenlab = "redenlab_extract.cli:main"` |

### Not changed
`client.py`, `asset.py`, `payload.py`, `polling.py`, `upload.py`, `workflows.py`, `exceptions.py`

---

## CLI Structure

```
redenlab <subcommand>

Subcommands:
  login    Authenticate with RedenLab (opens browser)
```

Built with `argparse`. Structured for subcommands from the start so `logout`, `whoami`,
or other commands can be added without restructuring.

### Terminal output during login
```
Opening browser for authentication...
Waiting for login to complete (timeout: 5 minutes)...

✓ Login successful. Credentials saved to ~/.redenlab-ml/config.yaml
```

---

## Dependencies

No new packages required. PKCE uses stdlib only:
- `secrets` — code verifier generation
- `hashlib` — SHA256 for code challenge
- `base64` — base64url encoding
- `http.server` — localhost callback server
- `webbrowser` — open browser
- `urllib.parse` — URL construction and parsing

`requests` (already a dependency) handles the Cognito token endpoint calls.
