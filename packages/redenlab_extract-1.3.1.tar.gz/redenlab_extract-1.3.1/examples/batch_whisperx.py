#!/usr/bin/env python3
"""
Batch WhisperX Inference Example for RedenLab ML SDK

Batch processes multiple audio files through the WhisperX endpoint, which returns
word-level timestamps, confidence scores, and optional speaker diarization.
Results are saved as TextGrid and JSON files, plus a summary CSV.

Flow:
    1. Health check — warm up endpoint if cold
    2. Upload ALL files (whole audio, no chunking)
    3. Submit ALL inference jobs
    4. Poll ALL jobs and process results immediately on completion
    5. Save TextGrid + JSON per file, summary CSV

Usage:
    export REDENLAB_ML_API_KEY='your-api-key'
    python batch_whisperx.py --input /path/to/audio --output /path/to/output

Arguments:
    --input, -i       : Input folder containing audio files
    --output, -o      : Output folder for results
                        Creates: textgrid/ and whisperx_results/ subfolders
    --diarize         : Enable speaker diarization (default: False)
    --batch-size      : Batch size for inference (default: 16)
    --timeout         : Max seconds to wait for all jobs (default: 3600)
    --poll-interval   : Seconds between status checks (default: 10)
"""

import argparse
import json
import os
import sys
import time
from pathlib import Path

# Use local SDK code instead of installed version (for development)
script_dir = Path(__file__).resolve().parent
sdk_src_dir = script_dir.parent / "src"
if sdk_src_dir.exists():
    sys.path.insert(0, str(sdk_src_dir))
    print(f"Using local SDK from: {sdk_src_dir}")
else:
    print("Warning: Local SDK src directory not found, using installed version")

import pandas as pd
import requests
from praatio import textgrid

from redenlab_extract import InferenceClient, RedenLabSession, whisperX_client

# Supported audio extensions
AUDIO_EXTENSIONS = {".wav", ".flac", ".ogg"}


def read_json_from_url(url: str, timeout: float = 30.0) -> dict:
    """Fetch JSON data from a presigned URL."""
    r = requests.get(url, timeout=timeout)
    r.raise_for_status()
    return r.json()


def process_whisperx_result(result: dict) -> textgrid.Textgrid:
    """
    Convert a WhisperX result dict to a Praat TextGrid.

    Creates the following tiers:
    - VAD:        One interval per segment (speech regions)
    - Words:      Word-level alignments from word_segments
    - Confidence: Per-word confidence scores
    - Speaker:    Per-word speaker labels (only when diarization was run)

    Args:
        result: The ``result`` sub-dict from the WhisperX API response
                (i.e. ``response["result"]``)

    Returns:
        A praatio Textgrid object
    """
    segments = result.get("segments", [])
    word_segments = result.get("word_segments", [])
    has_diarization = result.get("diarization", False)

    # Determine total audio duration from the last word end time
    if word_segments:
        audio_duration = word_segments[-1]["end"]
    elif segments:
        audio_duration = segments[-1]["end"]
    else:
        audio_duration = 0.0

    tg = textgrid.Textgrid()

    # --- VAD tier: one interval per segment ---
    vad_entries = [(seg["start"], seg["end"], "speech") for seg in segments]
    tg.addTier(textgrid.IntervalTier("VAD", vad_entries, 0, audio_duration))

    # --- Words tier ---
    word_entries = [
        (w["start"], w["end"], w["word"].strip()) for w in word_segments
    ]
    tg.addTier(textgrid.IntervalTier("Words", word_entries, 0, audio_duration))

    # --- Confidence tier ---
    conf_entries = [
        (w["start"], w["end"], str(round(w["score"], 4))) for w in word_segments
    ]
    tg.addTier(textgrid.IntervalTier("Confidence", conf_entries, 0, audio_duration))

    # --- Speaker tier (only when diarization was requested) ---
    if has_diarization:
        speaker_entries = [
            (w["start"], w["end"], w.get("speaker", "")) for w in word_segments
        ]
        tg.addTier(textgrid.IntervalTier("Speaker", speaker_entries, 0, audio_duration))

    return tg


def get_audio_files(input_folder: str) -> list[str]:
    """Get sorted list of audio files from input folder."""
    folder = Path(input_folder)
    if not folder.exists():
        raise FileNotFoundError(f"Input folder not found: {input_folder}")

    files = [
        str(f)
        for f in folder.iterdir()
        if f.is_file() and f.suffix.lower() in AUDIO_EXTENSIONS
    ]

    if not files:
        raise ValueError(
            f"No audio files found in {input_folder}. "
            f"Supported formats: {', '.join(AUDIO_EXTENSIONS)}"
        )

    return sorted(files)


def ensure_endpoint_ready(client: InferenceClient, warmup_timeout: int = 900) -> None:
    """
    Check endpoint health and warm it up if needed. Blocks until ready.

    Args:
        client: InferenceClient instance
        warmup_timeout: Max seconds to wait for warmup (default: 900 = 15 min)
    """
    print("\n" + "-" * 60)
    print("HEALTH CHECK: Verifying endpoint status")
    print("-" * 60)

    health = client.health()

    if health.get("status") == "not_supported":
        print(f"  {health.get('message', 'Health check not supported — endpoint always available.')}")
        return

    if health.get("ready") and not health.get("is_warming"):
        response_time = health.get("response_time", "unknown")
        print(f"  Endpoint is ready (response time: {response_time}s)")
        return

    if health.get("status") == "warming_up":
        print("  Endpoint is warming up from cold start.")
    else:
        print(f"  Endpoint is not ready (status: {health.get('status')}). Triggering warmup...")

    print(f"  Running warmup (timeout: {warmup_timeout}s). This may take up to 10 minutes...")
    result = client.warmup(timeout=warmup_timeout, show_progress=True, force=True)

    if result.get("status") not in ("success", "already_ready"):
        print(f"  ERROR: Warmup did not complete successfully: {result}")
        sys.exit(1)

    print("  Endpoint is ready — proceeding with inference.")


def poll_all_jobs(
    client: InferenceClient,
    job_ids: list[str],
    on_complete_callback=None,
    poll_interval: int = 10,
    timeout: int = 3600,
) -> dict[str, dict]:
    """
    Poll all jobs until they complete or fail, calling callback immediately on completion.

    Args:
        client: InferenceClient instance
        job_ids: List of job IDs to poll
        on_complete_callback: Called as callback(job_id, status_data) when a job completes
        poll_interval: Seconds between poll rounds
        timeout: Maximum total wait time

    Returns:
        Dict mapping job_id -> final status dict
    """
    results = {}
    pending = set(job_ids)
    start_time = time.time()

    print(f"\nPolling {len(job_ids)} jobs for completion...")
    print("-" * 60)

    while pending and (time.time() - start_time) < timeout:
        for job_id in list(pending):
            try:
                status_data = client.get_status(job_id)
                status = status_data.get("status")

                if status == "completed":
                    results[job_id] = status_data
                    pending.remove(job_id)
                    print(
                        f"  [COMPLETED] Job {job_id[:12]}... "
                        f"({len(results)}/{len(job_ids)})"
                    )
                    if on_complete_callback:
                        try:
                            on_complete_callback(job_id, status_data)
                        except Exception as e:
                            print(f"            ERROR processing result: {e}")

                elif status == "failed":
                    results[job_id] = status_data
                    pending.remove(job_id)
                    error_msg = status_data.get("error", "Unknown error")
                    print(
                        f"  [FAILED]    Job {job_id[:12]}... "
                        f"({len(results)}/{len(job_ids)}) — {error_msg}"
                    )

            except Exception as e:
                print(f"  [ERROR] Checking job {job_id[:12]}...: {e}")

        if pending:
            elapsed = int(time.time() - start_time)
            print(
                f"  ... {len(pending)} jobs still processing "
                f"(elapsed: {elapsed}s, waiting {poll_interval}s)"
            )
            time.sleep(poll_interval)

    for job_id in pending:
        results[job_id] = {"job_id": job_id, "status": "timeout", "error": "Polling timeout"}
        print(f"  [TIMEOUT]   Job {job_id[:12]}...")

    return results


def main():
    parser = argparse.ArgumentParser(
        description="Batch WhisperX inference using RedenLab ML SDK",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    python batch_whisperx.py -i ./audio_files -o ./results
    python batch_whisperx.py -i ./audio_files -o ./results --diarize --batch-size 8
        """,
    )
    parser.add_argument(
        "-i", "--input", required=True, help="Input folder containing audio files"
    )
    parser.add_argument(
        "-o", "--output", required=True, help="Output folder for results"
    )
    parser.add_argument(
        "--diarize",
        action="store_true",
        default=False,
        help="Enable speaker diarization (default: False)",
    )
    parser.add_argument(
        "--batch-size",
        type=int,
        default=16,
        help="Batch size for WhisperX inference (default: 16)",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=3600,
        help="Maximum time to wait for jobs in seconds (default: 3600)",
    )
    parser.add_argument(
        "--poll-interval",
        type=int,
        default=10,
        help="Seconds between status checks (default: 10)",
    )

    args = parser.parse_args()

    # Check for API key
    api_key = os.environ.get("REDENLAB_ML_API_KEY")
    if not api_key:
        print("Error: REDENLAB_ML_API_KEY environment variable not set")
        print("Set it with: export REDENLAB_ML_API_KEY='your-api-key'")
        sys.exit(1)

    # Setup output directories
    output_path = Path(args.output)
    textgrid_dir = output_path / "textgrid"
    whisperx_results_dir = output_path / "whisperx_results"

    output_path.mkdir(parents=True, exist_ok=True)
    textgrid_dir.mkdir(exist_ok=True)
    whisperx_results_dir.mkdir(exist_ok=True)

    print("\n" + "=" * 60)
    print("RedenLab ML SDK - Batch WhisperX Inference")
    print("=" * 60)
    print(f"Input folder:  {args.input}")
    print(f"Output folder: {args.output}")
    print(f"Diarize:       {args.diarize}")
    print(f"Batch size:    {args.batch_size}")
    print("=" * 60)

    # Initialise session and client
    session = RedenLabSession(api_key=api_key)
    client = whisperX_client(
        session=session,
        diarize=args.diarize,
        batch_size=args.batch_size,
        timeout=args.timeout,
    )
    print(f"\nClient initialized: {client}")

    # Warm up endpoint before doing any work
    ensure_endpoint_ready(client, warmup_timeout=args.timeout)

    # Get audio files
    try:
        audio_files = get_audio_files(args.input)
        print(f"\nFound {len(audio_files)} audio files to process")
    except (FileNotFoundError, ValueError) as e:
        print(f"Error: {e}")
        sys.exit(1)

    df = pd.DataFrame(
        {
            "filename": [Path(p).name for p in audio_files],
            "path": audio_files,
        }
    )

    # -------------------------------------------------------------------------
    # PHASE 1: Upload (whole file — no chunking for WhisperX)
    # -------------------------------------------------------------------------
    print("\n" + "-" * 60)
    print("PHASE 1: Uploading audio files")
    print("-" * 60)

    assets = []
    for i, row in df.iterrows():
        print(f"  [{i + 1}/{len(df)}] Uploading {row['filename']}...")
        try:
            asset = session.upload(row["path"])
            assets.append(asset)
            print(f"         Asset ID: {asset.asset_id[:12]}...")
        except Exception as e:
            print(f"         ERROR: {e}")
            assets.append(None)

    df["asset_id"] = [a.asset_id if a else None for a in assets]
    print(f"\nUploaded {sum(1 for a in assets if a is not None)}/{len(df)} files")

    # -------------------------------------------------------------------------
    # PHASE 2: Submit inference jobs
    # -------------------------------------------------------------------------
    print("\n" + "-" * 60)
    print("PHASE 2: Submitting WhisperX jobs")
    print("-" * 60)

    job_ids = []
    for i, (row, asset) in enumerate(zip(df.itertuples(index=False), assets)):
        if asset is None:
            print(f"  [{i + 1}/{len(df)}] Skipping {row.filename} (upload failed)")
            job_ids.append(None)
            continue

        print(f"  [{i + 1}/{len(df)}] Submitting {row.filename}...")
        try:
            job_id = client._submit_with_upload_wait(asset)
            job_ids.append(job_id)
            print(f"         Job ID: {job_id[:12]}...")
        except Exception as e:
            print(f"         ERROR: {e}")
            job_ids.append(None)

    df["job_id"] = job_ids
    print(f"\nSubmitted {sum(1 for j in job_ids if j is not None)}/{len(df)} jobs")

    # -------------------------------------------------------------------------
    # PHASE 3: Poll and process results immediately on completion
    # -------------------------------------------------------------------------
    job_to_filename = {
        job_id: filename
        for job_id, filename in zip(job_ids, df["filename"])
        if job_id is not None
    }

    processed_jobs: dict[str, dict] = {}

    def process_result_immediately(job_id: str, status_data: dict) -> None:
        filename = job_to_filename.get(job_id, "unknown")

        result_url = status_data.get("result_url")
        if result_url is None:
            print(f"         → ERROR: No result_url in response for {filename}")
            processed_jobs[job_id] = {"status": "processing_failed", "error": "No result_url"}
            return

        # Fetch full result from presigned S3 URL
        try:
            fetched = read_json_from_url(result_url)
        except Exception as e:
            print(f"         → ERROR fetching result_url: {e}")
            processed_jobs[job_id] = {"status": "processing_failed", "error": str(e)}
            return

        # Save fetched JSON to whisperx_results/
        json_filename = Path(filename).stem + ".json"
        json_path = whisperx_results_dir / json_filename
        try:
            with open(json_path, "w") as f:
                json.dump(fetched, f, indent=2)
            print(f"         → Saved JSON: {json_filename}")
        except Exception as e:
            print(f"         → ERROR saving JSON: {e}")

        # Build TextGrid from fetched result (top-level, no "result" wrapper)
        result = fetched
        try:
            tg = process_whisperx_result(result)
            tg_filename = Path(filename).stem + ".TextGrid"
            tg_path = textgrid_dir / tg_filename
            tg.save(str(tg_path), format="short_textgrid", includeBlankSpaces=True)
            print(f"         → Saved TextGrid: {tg_filename}")
            processed_jobs[job_id] = {"status": "processed", "textgrid": tg}
        except Exception as e:
            print(f"         → ERROR creating TextGrid: {e}")
            processed_jobs[job_id] = {"status": "processing_failed", "error": str(e)}

    print("\n" + "-" * 60)
    print("PHASE 3: Polling and processing results")
    print("-" * 60)

    valid_job_ids = [j for j in job_ids if j is not None]
    poll_all_jobs(
        client,
        valid_job_ids,
        on_complete_callback=process_result_immediately,
        poll_interval=args.poll_interval,
        timeout=args.timeout,
    )

    # -------------------------------------------------------------------------
    # PHASE 4: Save summary CSV
    # -------------------------------------------------------------------------
    print("\n" + "-" * 60)
    print("PHASE 4: Saving summary")
    print("-" * 60)

    final_statuses = []
    for job_id in df["job_id"]:
        if job_id is None:
            final_statuses.append("submit_failed")
        else:
            final_statuses.append(processed_jobs.get(job_id, {}).get("status", "unknown"))

    df["status"] = final_statuses

    summary_df = df[["filename", "path", "asset_id", "job_id", "status"]].copy()
    summary_path = output_path / "whisperx_summary.csv"
    summary_df.to_csv(summary_path, index=False)
    print(f"  Saved summary to: {summary_path}")

    # Print final summary
    completed = sum(1 for s in final_statuses if s == "processed")
    failed = sum(1 for s in final_statuses if "failed" in s)
    other = len(final_statuses) - completed - failed

    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print(f"  Total files:        {len(df)}")
    print(f"  Successfully saved: {completed}")
    print(f"  Failed:             {failed}")
    if other > 0:
        print(f"  Other:              {other}")
    print()
    print(f"  Output folder:      {output_path}")
    print(f"  TextGrids:          {textgrid_dir}")
    print(f"  JSON results:       {whisperx_results_dir}")
    print(f"  Summary CSV:        {summary_path}")
    print("=" * 60)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nInterrupted by user. Exiting...")
        sys.exit(1)
    except Exception as e:
        print(f"\n\nFATAL ERROR: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)
