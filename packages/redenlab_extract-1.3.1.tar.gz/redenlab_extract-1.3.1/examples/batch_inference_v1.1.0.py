#!/usr/bin/env python3
"""
Batch Inference Example for RedenLab ML SDK (Intelligibility & Naturalness)

This script batch processes multiple audio files using either an intelligibility
or naturalness model. Long files (>50s) are automatically split into chunks and
aggregated. Results are saved as per-file JSON and a summary CSV.

Flow:
    1. Health check — warm up endpoint if cold
    2. Upload ALL files (with chunking for long files) to get asset IDs
    3. Submit ALL inference jobs
    4. Poll ALL jobs and aggregate chunked results
    5. Save JSON per file + summary CSV

Usage:
    export REDENLAB_ML_API_KEY='your-api-key'
    python batch_inference.py --input /path/to/audio --output /path/to/output --model-name als-intelligibility-v1

Arguments:
    --input, -i       : Input folder containing audio files
    --output, -o      : Output folder for results
                        Creates: json_results/ and <model_name>_summary.csv
    --model-name, -m  : Model to use (see available models below)

Available models:
    Intelligibility: als-intelligibility-v1, als-intelligibility-v2, ataxia-intelligibility
    Naturalness:     als-naturalness-v1, als-naturalness-v2, ataxia-naturalness
"""

import argparse
import json
import os
import sys
import time
from pathlib import Path

import pandas as pd

from redenlab_extract import (
    RedenLabSession,
    aggregate_results,
    intelligibility_client,
    naturalness_client,
)

# Supported audio extensions
AUDIO_EXTENSIONS = {".wav", ".flac", ".ogg"}

INTELLIGIBILITY_MODELS = {
    "als-intelligibility-v1",
    "als-intelligibility-v2",
    "ataxia-intelligibility",
}

NATURALNESS_MODELS = {
    "als-naturalness-v1",
    "als-naturalness-v2",
    "ataxia-naturalness",
}


def get_client(session: RedenLabSession, model_name: str, timeout: int):
    """Return the appropriate client and score key for the given model name."""
    if model_name in INTELLIGIBILITY_MODELS:
        return intelligibility_client(session, model_name=model_name, timeout=timeout), "intelligibility_score"
    elif model_name in NATURALNESS_MODELS:
        return naturalness_client(session, model_name=model_name, timeout=timeout), "naturalness_score"
    else:
        valid = sorted(INTELLIGIBILITY_MODELS | NATURALNESS_MODELS)
        raise ValueError(f"Unknown model '{model_name}'. Valid models: {', '.join(valid)}")


def ensure_endpoint_ready(client, warmup_timeout: int = 900) -> None:
    """
    Check endpoint health and warm it up if needed. Blocks until the endpoint is ready.

    Args:
        client: InferenceClient instance
        warmup_timeout: Max seconds to wait for warmup (default: 900 = 15 min)
    """
    print("\n" + "-" * 60)
    print("HEALTH CHECK: Verifying endpoint status")
    print("-" * 60)

    health = client.health()

    if health.get("status") == "not_supported":
        print(f"  {health.get('message', 'Health check not supported — endpoint always available.')}")
        return

    if health.get("ready") and not health.get("is_warming"):
        response_time = health.get("response_time", "unknown")
        print(f"  Endpoint is ready (response time: {response_time}s)")
        return

    if health.get("status") == "warming_up":
        print("  Endpoint is warming up from cold start.")
    else:
        print(f"  Endpoint is not ready (status: {health.get('status')}). Triggering warmup...")

    print(f"  Running warmup (timeout: {warmup_timeout}s). This may take up to 10 minutes...")
    result = client.warmup(timeout=warmup_timeout, show_progress=True, force=True)

    if result.get("status") not in ("success", "already_ready"):
        print(f"  ERROR: Warmup did not complete successfully: {result}")
        sys.exit(1)

    print("  Endpoint is ready — proceeding with inference.")


def get_audio_files(input_folder: str) -> list[str]:
    """Get list of audio files from input folder."""
    folder = Path(input_folder)
    if not folder.exists():
        raise FileNotFoundError(f"Input folder not found: {input_folder}")

    files = [
        str(f)
        for f in folder.iterdir()
        if f.is_file() and f.suffix.lower() in AUDIO_EXTENSIONS
    ]

    if not files:
        raise ValueError(
            f"No audio files found in {input_folder}. "
            f"Supported formats: {', '.join(AUDIO_EXTENSIONS)}"
        )

    return sorted(files)


def main():
    parser = argparse.ArgumentParser(
        description="Batch intelligibility/naturalness inference using RedenLab ML SDK",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    python batch_inference.py -i ./audio -o ./results -m als-intelligibility-v1
    python batch_inference.py -i ./audio -o ./results -m ataxia-naturalness
        """,
    )
    parser.add_argument(
        "-i", "--input", required=True, help="Input folder containing audio files"
    )
    parser.add_argument(
        "-o", "--output", required=True, help="Output folder for results"
    )
    parser.add_argument(
        "-m", "--model-name", required=True,
        help="Model name (e.g., 'als-intelligibility-v1', 'ataxia-naturalness')",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=3600,
        help="Maximum time to wait for jobs in seconds (default: 3600)",
    )
    parser.add_argument(
        "--poll-interval",
        type=int,
        default=10,
        help="Seconds between status checks (default: 10)",
    )

    args = parser.parse_args()

    # Check for API key
    api_key = os.environ.get("REDENLAB_ML_API_KEY")
    if not api_key:
        print("Error: REDENLAB_ML_API_KEY environment variable not set")
        print("Set it with: export REDENLAB_ML_API_KEY='your-api-key'")
        sys.exit(1)

    # Validate model name and build client
    session = RedenLabSession(api_key=api_key)
    try:
        client, score_key = get_client(session, args.model_name, args.timeout)
    except ValueError as e:
        print(f"Error: {e}")
        sys.exit(1)

    # Setup output directories
    output_path = Path(args.output)
    json_results_dir = output_path / "json_results"
    output_path.mkdir(parents=True, exist_ok=True)
    json_results_dir.mkdir(exist_ok=True)

    print("\n" + "=" * 60)
    print("RedenLab ML SDK - Batch Inference")
    print("=" * 60)
    print(f"Input folder:  {args.input}")
    print(f"Output folder: {args.output}")
    print(f"Model:         {args.model_name}")
    print(f"Score key:     {score_key}")
    print("=" * 60)

    # Check endpoint health and warm up if needed before doing any work
    ensure_endpoint_ready(client, warmup_timeout=args.timeout)

    # Get audio files
    try:
        audio_files = get_audio_files(args.input)
        print(f"\nFound {len(audio_files)} audio files to process")
    except (FileNotFoundError, ValueError) as e:
        print(f"Error: {e}")
        sys.exit(1)

    df = pd.DataFrame(
        {
            "filename": [Path(p).name for p in audio_files],
            "path": audio_files,
        }
    )

    # ---------------------------------------------------------------------------
    # PHASE 1: Upload (with automatic chunking for files > 50s)
    # session.upload_chunked() returns list[Asset]:
    #   - 1 asset  → file fits in a single chunk
    #   - N assets → file was split; each asset is one chunk
    # ---------------------------------------------------------------------------
    print("\n" + "-" * 60)
    print("PHASE 1: Uploading audio files")
    print("-" * 60)

    # file_assets maps filename -> list[Asset]
    file_assets: dict[str, list] = {}

    for i, row in df.iterrows():
        print(f"  [{i + 1}/{len(df)}] Uploading {row['filename']}...")
        try:
            assets = session.upload_chunked(row["path"])
            file_assets[row["filename"]] = assets
            chunk_info = f" ({len(assets)} chunks)" if len(assets) > 1 else ""
            asset_ids_preview = ", ".join(a.asset_id[:12] + "..." for a in assets)
            print(f"         Asset ID(s): {asset_ids_preview}{chunk_info}")
        except Exception as e:
            print(f"         ERROR: {e}")
            file_assets[row["filename"]] = []

    uploaded = sum(1 for assets in file_assets.values() if assets)
    print(f"\nUploaded {uploaded}/{len(df)} files")

    # For the summary CSV: use the first asset_id as the file's representative ID
    df["asset_id"] = [
        file_assets[row["filename"]][0].asset_id if file_assets.get(row["filename"]) else None
        for _, row in df.iterrows()
    ]

    # ---------------------------------------------------------------------------
    # PHASE 2: Submit inference jobs for every asset (chunk)
    # ---------------------------------------------------------------------------
    print("\n" + "-" * 60)
    print("PHASE 2: Submitting inference jobs")
    print("-" * 60)

    # file_job_ids maps filename -> list[job_id]
    file_job_ids: dict[str, list[str]] = {}

    for i, (_, row) in enumerate(df.iterrows()):
        filename = row["filename"]
        assets = file_assets.get(filename, [])

        if not assets:
            print(f"  [{i + 1}/{len(df)}] Skipping {filename} (upload failed)")
            file_job_ids[filename] = []
            continue

        print(f"  [{i + 1}/{len(df)}] Submitting {filename}...")
        job_ids = []
        failed = False
        for asset in assets:
            try:
                job_id = client.submit(asset)
                job_ids.append(job_id)
            except Exception as e:
                print(f"         ERROR submitting chunk {asset.asset_id[:12]}...: {e}")
                failed = True
                break

        if failed:
            file_job_ids[filename] = []
        else:
            file_job_ids[filename] = job_ids
            chunk_info = f" ({len(job_ids)} chunks)" if len(job_ids) > 1 else ""
            print(f"         Job ID(s): {', '.join(j[:12] + '...' for j in job_ids)}{chunk_info}")

    total_jobs = sum(len(ids) for ids in file_job_ids.values())
    print(f"\nSubmitted {total_jobs} total jobs for {len(df)} files")

    # ---------------------------------------------------------------------------
    # PHASE 3: Poll all jobs and aggregate chunked results
    # For a single job: client.poll() returns the result directly.
    # For multiple jobs (chunks): poll each individually, collect raw chunk
    # results, then aggregate_results() computes mean score + std_dev.
    # ---------------------------------------------------------------------------
    print("\n" + "-" * 60)
    print("PHASE 3: Polling for completion")
    print("-" * 60)

    results: dict[str, dict] = {}

    for i, (_, row) in enumerate(df.iterrows(), 1):
        filename = row["filename"]
        job_ids = file_job_ids.get(filename, [])

        if not job_ids:
            results[filename] = {"status": "failed", "error": "Submission failed"}
            print(f"  [{i}/{len(df)}] {filename}: SKIPPED (submission failed)")
            continue

        print(f"  [{i}/{len(df)}] Polling {filename}...")
        try:
            if len(job_ids) == 1:
                result = client.poll(job_ids[0], timeout=args.timeout)
                score = result.get("result", {}).get(score_key)
                results[filename] = {
                    "status": result.get("status", "unknown"),
                    score_key: score,
                    "std_dev": None,
                    "num_chunks": None,
                    "chunk_scores": None,
                    "raw_result": result,
                }
            else:
                # Poll each chunk job individually
                chunk_results = []
                for job_id in job_ids:
                    chunk_result = client.poll(job_id, timeout=args.timeout)
                    if chunk_result.get("status") == "completed":
                        chunk_results.append(chunk_result)

                # Aggregate using the SDK's aggregate_results()
                aggregated = aggregate_results(chunk_results, score_key)
                score = aggregated.get("result", {}).get(score_key)
                std_dev = aggregated.get("result", {}).get("std_dev")
                chunk_scores = aggregated.get("result", {}).get("chunk_scores")
                results[filename] = {
                    "status": aggregated.get("status", "unknown"),
                    score_key: score,
                    "std_dev": std_dev,
                    "num_chunks": len(job_ids),
                    "chunk_scores": chunk_scores,
                    "raw_result": aggregated,
                }

            score_val = results[filename][score_key]
            score_str = f"{score_val:.4f}" if score_val is not None else "N/A"
            status_icon = "+" if results[filename]["status"] == "completed" else "!"
            print(f"         [{status_icon}] {score_key}: {score_str}")

        except Exception as e:
            print(f"         ERROR: {e}")
            results[filename] = {"status": "failed", "error": str(e)}

    # ---------------------------------------------------------------------------
    # PHASE 4: Save outputs
    # ---------------------------------------------------------------------------
    print("\n" + "-" * 60)
    print("PHASE 4: Saving results")
    print("-" * 60)

    for filename, result in results.items():
        json_filename = Path(filename).stem + ".json"
        json_path = json_results_dir / json_filename

        output_data = {
            "filename": filename,
            "model_name": args.model_name,
            "score_key": score_key,
            "status": result.get("status"),
            score_key: result.get(score_key),
            "std_dev": result.get("std_dev"),
            "num_chunks": result.get("num_chunks"),
            "chunk_scores": result.get("chunk_scores"),
        }
        if "error" in result:
            output_data["error"] = result["error"]

        with open(json_path, "w") as f:
            json.dump(output_data, f, indent=2)

    print(f"  Saved {len(results)} JSON files to {json_results_dir}")

    # Build summary CSV — one row per file, flattened columns
    summary_rows = []
    for _, row in df.iterrows():
        filename = row["filename"]
        result = results.get(filename, {})
        job_ids = file_job_ids.get(filename, [])
        summary_rows.append({
            "filename": filename,
            "path": row["path"],
            "asset_id": row["asset_id"],
            "job_ids": ", ".join(job_ids) if job_ids else None,
            "status": result.get("status", "unknown"),
            score_key: result.get(score_key),
            "std_dev": result.get("std_dev"),
            "num_chunks": result.get("num_chunks"),
        })

    summary_df = pd.DataFrame(summary_rows)
    summary_path = output_path / f"{args.model_name}_summary.csv"
    summary_df.to_csv(summary_path, index=False)
    print(f"  Saved summary to: {summary_path}")

    # Print final summary
    final_statuses = summary_df["status"].tolist()
    completed = sum(1 for s in final_statuses if s == "completed")
    failed = sum(1 for s in final_statuses if s == "failed")
    other = len(final_statuses) - completed - failed

    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print(f"  Total files:   {len(df)}")
    print(f"  Completed:     {completed}")
    print(f"  Failed:        {failed}")
    if other > 0:
        print(f"  Other:         {other}")
    print()

    for _, row in summary_df.iterrows():
        status_icon = "+" if row["status"] == "completed" else "x"
        score_val = row[score_key]
        score_str = f"{score_val:.4f}" if score_val is not None else "N/A"
        std_str = f" (std: {row['std_dev']:.4f})" if pd.notna(row.get("std_dev")) else ""
        chunk_str = f" [{int(row['num_chunks'])} chunks]" if pd.notna(row.get("num_chunks")) else ""
        print(f"  [{status_icon}] {row['filename']}: {score_str}{std_str}{chunk_str}")

    print()
    print(f"  Output folder: {output_path}")
    print(f"  JSON results:  {json_results_dir}")
    print(f"  Summary CSV:   {summary_path}")
    print("=" * 60)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nInterrupted by user. Exiting...")
        sys.exit(1)
    except Exception as e:
        print(f"\n\nFATAL ERROR: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)
