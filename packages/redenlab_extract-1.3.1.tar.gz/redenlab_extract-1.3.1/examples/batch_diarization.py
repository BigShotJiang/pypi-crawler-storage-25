#!/usr/bin/env python3
"""
Batch Speaker Diarization Example for RedenLab ML SDK

This script batch processes multiple audio files using the speaker diarization
model. Full audio files are required — chunking is not supported by this model.

Flow:
    1. Health check — warm up endpoint if cold (once)
    2. Upload ALL files in parallel to get asset IDs
    3. Submit ALL inference jobs in parallel
    4. Poll ALL jobs, fetch full result JSON from result_url, build TextGrids
    5. Save JSON per file + TextGrids + summary CSV

Usage:
    export REDENLAB_ML_API_KEY='your-api-key'
    python batch_diarization.py --input /path/to/audio --output /path/to/output

    # Specify known speaker count (skips auto-detection):
    python batch_diarization.py --input /path/to/audio --output /path/to/output --num-speakers 2

    # Control parallelism:
    python batch_diarization.py --input /path/to/audio --output /path/to/output --max-workers 5

Arguments:
    --input, -i         : Input folder containing audio files
    --output, -o        : Output folder for results
                          Creates: json_results/, textgrid/, and diarization_summary.csv
    --num-speakers, -n  : Number of speakers (optional; omit for auto-detection)
    --max-workers       : Max parallel threads for upload and submit (default: 8)
"""

import argparse
import json
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import pandas as pd
import requests
from praatio import textgrid

from redenlab_extract import RedenLabSession, speaker_diarization_client

# Supported audio extensions
AUDIO_EXTENSIONS = {".wav", ".flac", ".ogg"}


def read_json_from_url(url: str, timeout: float = 30.0) -> dict:
    """Fetch JSON data from a presigned URL."""
    r = requests.get(url, timeout=timeout)
    r.raise_for_status()
    return r.json()


def segments_to_textgrid(segments: list[dict], duration: float) -> textgrid.Textgrid:
    """
    Convert diarization segments to a Praat TextGrid with one tier per speaker.

    Using per-speaker tiers correctly handles overlapping speech (crosstalk):
    each tier only contains that speaker's segments, so concurrent segments
    on different tiers do not conflict.

    Args:
        segments: List of dicts with speaker, start, end
        duration: Total audio duration in seconds

    Returns:
        praatio Textgrid object
    """
    # Group segments by speaker, preserving insertion order
    speaker_segments: dict[str, list[tuple]] = {}
    for seg in segments:
        speaker = str(seg["speaker"])
        speaker_segments.setdefault(speaker, [])
        speaker_segments[speaker].append((seg["start"], seg["end"], speaker))

    tg = textgrid.Textgrid()
    for speaker, intervals in sorted(speaker_segments.items()):
        tier = textgrid.IntervalTier(speaker, intervals, 0, duration)
        tg.addTier(tier)
    return tg


def ensure_endpoint_ready(client, warmup_timeout: int = 900) -> None:
    """
    Check endpoint health and warm it up if needed. Blocks until the endpoint is ready.

    Args:
        client: InferenceClient instance
        warmup_timeout: Max seconds to wait for warmup (default: 900 = 15 min)
    """
    print("\n" + "-" * 60)
    print("HEALTH CHECK: Verifying endpoint status")
    print("-" * 60)

    health = client.health()

    if health.get("status") == "not_supported":
        print(f"  {health.get('message', 'Health check not supported — endpoint always available.')}")
        return

    if health.get("ready") and not health.get("is_warming"):
        response_time = health.get("response_time", "unknown")
        print(f"  Endpoint is ready (response time: {response_time}s)")
        return

    if health.get("status") == "warming_up":
        print("  Endpoint is warming up from cold start.")
    else:
        print(f"  Endpoint is not ready (status: {health.get('status')}). Triggering warmup...")

    print(f"  Running warmup (timeout: {warmup_timeout}s). This may take up to 10 minutes...")
    result = client.warmup(timeout=warmup_timeout, show_progress=True, force=True)

    if result.get("status") not in ("success", "already_ready"):
        print(f"  ERROR: Warmup did not complete successfully: {result}")
        sys.exit(1)

    print("  Endpoint is ready — proceeding with inference.")


def get_audio_files(input_folder: str) -> list[str]:
    """Get list of audio files from input folder."""
    folder = Path(input_folder)
    if not folder.exists():
        raise FileNotFoundError(f"Input folder not found: {input_folder}")

    files = [
        str(f)
        for f in folder.iterdir()
        if f.is_file() and f.suffix.lower() in AUDIO_EXTENSIONS
    ]

    if not files:
        raise ValueError(
            f"No audio files found in {input_folder}. "
            f"Supported formats: {', '.join(AUDIO_EXTENSIONS)}"
        )

    return sorted(files)


def upload_and_submit_one(session, client, filename: str, path: str, num_speakers) -> dict:
    """
    Upload a single file and immediately submit its inference job.

    Keeping upload + submit in one thread ensures the asset_id and job_id
    are always paired with the correct filename — no index alignment needed.

    Returns:
        dict with keys: filename, path, asset_id, job_id
        asset_id and job_id are None if the respective step failed.
    """
    result = {"filename": filename, "path": path, "asset_id": None, "job_id": None}

    try:
        asset = session.upload(path)
        result["asset_id"] = asset.asset_id
    except Exception as e:
        print(f"  [UPLOAD ERROR] {filename}: {e}")
        return result

    try:
        submit_kwargs = {}
        if num_speakers is not None:
            submit_kwargs["num_speakers"] = num_speakers
        result["job_id"] = client._submit_with_upload_wait(asset, **submit_kwargs)
    except Exception as e:
        print(f"  [SUBMIT ERROR] {filename}: {e}")

    return result


def upload_and_submit_all(
    session, client, df: pd.DataFrame, num_speakers, max_workers: int
) -> pd.DataFrame:
    """
    Upload and submit all files in parallel, one thread per file.

    Each thread handles the full upload → submit sequence for a single file,
    so filename, asset_id, and job_id are always captured together.

    Returns:
        df with asset_id and job_id columns added.
    """
    rows = [df.iloc[i] for i in range(len(df))]

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(
                upload_and_submit_one,
                session, client, row["filename"], row["path"], num_speakers
            ): row["filename"]
            for row in rows
        }

        results_by_filename = {}
        for future in as_completed(futures):
            filename = futures[future]
            try:
                result = future.result()
                results_by_filename[filename] = result
                asset_id = result["asset_id"]
                job_id = result["job_id"]
                if asset_id and job_id:
                    print(f"  [OK] {filename}  asset={asset_id[:12]}...  job={job_id[:12]}...")
                elif asset_id:
                    print(f"  [SUBMIT FAILED] {filename}  asset={asset_id[:12]}...")
                else:
                    print(f"  [UPLOAD FAILED] {filename}")
            except Exception as e:
                results_by_filename[filename] = {
                    "filename": filename,
                    "path": None,
                    "asset_id": None,
                    "job_id": None,
                }
                print(f"  [ERROR] {filename}: {e}")

    # Reconstruct columns in original df order
    df = df.copy()
    df["asset_id"] = df["filename"].map(lambda f: results_by_filename[f]["asset_id"])
    df["job_id"] = df["filename"].map(lambda f: results_by_filename[f]["job_id"])
    return df


def poll_all_jobs(
    client,
    job_ids: list[str],
    on_complete_callback=None,
    poll_interval: int = 10,
    timeout: int = 3600,
) -> dict[str, dict]:
    """
    Poll all jobs until they complete or fail, with optional callback for immediate processing.

    Args:
        client: InferenceClient instance
        job_ids: List of job IDs to poll
        on_complete_callback: Optional function called immediately when each job completes.
                            Signature: callback(job_id: str, status_data: dict) -> None
        poll_interval: Seconds between poll attempts
        timeout: Maximum time to wait for all jobs

    Returns:
        Dictionary mapping job_id to final status dict
    """
    results = {}
    pending = set(job_ids)
    start_time = time.time()

    print(f"\nPolling {len(job_ids)} jobs for completion...")
    print("-" * 60)

    while pending and (time.time() - start_time) < timeout:
        for job_id in list(pending):
            try:
                status_data = client.get_status(job_id)
                status = status_data.get("status")

                if status == "completed":
                    results[job_id] = status_data
                    pending.remove(job_id)
                    completed_count = len(results)
                    total = len(job_ids)
                    print(f"  [COMPLETED] Job {job_id[:12]}... ({completed_count}/{total})")

                    if on_complete_callback:
                        try:
                            on_complete_callback(job_id, status_data)
                        except Exception as e:
                            print(f"         ERROR processing result: {e}")

                elif status == "failed":
                    results[job_id] = status_data
                    pending.remove(job_id)
                    completed_count = len(results)
                    total = len(job_ids)
                    error_msg = status_data.get("error", "Unknown error")
                    print(f"  [FAILED] Job {job_id[:12]}... - {error_msg}")

            except Exception as e:
                print(f"  [ERROR] Checking job {job_id[:12]}...: {e}")

        if pending:
            elapsed = int(time.time() - start_time)
            print(
                f"  ... {len(pending)} jobs still processing "
                f"(elapsed: {elapsed}s, waiting {poll_interval}s)"
            )
            time.sleep(poll_interval)

    for job_id in pending:
        results[job_id] = {"job_id": job_id, "status": "timeout", "error": "Polling timeout"}
        print(f"  [TIMEOUT] Job {job_id[:12]}...")

    return results


def main():
    parser = argparse.ArgumentParser(
        description="Batch speaker diarization using RedenLab ML SDK",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    python batch_diarization.py -i ./audio -o ./results
    python batch_diarization.py -i ./audio -o ./results --num-speakers 2
    python batch_diarization.py -i ./audio -o ./results --max-workers 5
        """,
    )
    parser.add_argument(
        "-i", "--input", required=True, help="Input folder containing audio files"
    )
    parser.add_argument(
        "-o", "--output", required=True, help="Output folder for results"
    )
    parser.add_argument(
        "-n", "--num-speakers",
        type=int,
        default=None,
        help="Number of speakers (optional; omit to auto-detect)",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=3600,
        help="Maximum time to wait for jobs in seconds (default: 3600)",
    )
    parser.add_argument(
        "--poll-interval",
        type=int,
        default=10,
        help="Seconds between status checks (default: 10)",
    )
    parser.add_argument(
        "--max-workers",
        type=int,
        default=8,
        help="Max parallel threads for upload and submit (default: 8)",
    )

    args = parser.parse_args()

    # Check for API key
    api_key = os.environ.get("REDENLAB_ML_API_KEY")
    if not api_key:
        print("Error: REDENLAB_ML_API_KEY environment variable not set")
        print("Set it with: export REDENLAB_ML_API_KEY='your-api-key'")
        sys.exit(1)

    # Setup output directories
    output_path = Path(args.output)
    json_results_dir = output_path / "json_results"
    textgrid_dir = output_path / "textgrid"
    output_path.mkdir(parents=True, exist_ok=True)
    json_results_dir.mkdir(exist_ok=True)
    textgrid_dir.mkdir(exist_ok=True)

    print("\n" + "=" * 60)
    print("RedenLab ML SDK - Batch Speaker Diarization")
    print("=" * 60)
    print(f"Input folder:  {args.input}")
    print(f"Output folder: {args.output}")
    num_speakers_display = str(args.num_speakers) if args.num_speakers is not None else "auto-detect"
    print(f"Num speakers:  {num_speakers_display}")
    print(f"Max workers:   {args.max_workers}")
    print("=" * 60)

    # Initialize session and client
    session = RedenLabSession(api_key=api_key)
    client = speaker_diarization_client(session=session, timeout=args.timeout)
    print(f"\nClient initialized: {client}")

    # Get audio files
    try:
        audio_files = get_audio_files(args.input)
        print(f"\nFound {len(audio_files)} audio files to process")
    except (FileNotFoundError, ValueError) as e:
        print(f"Error: {e}")
        sys.exit(1)

    df = pd.DataFrame(
        {
            "filename": [Path(p).name for p in audio_files],
            "path": audio_files,
        }
    )

    # ---------------------------------------------------------------------------
    # PHASE 1: Health check — warm up once before upload + submit
    # Parallelism keeps the total upload+submit time short enough that the
    # endpoint stays warm throughout without needing repeated health checks.
    # ---------------------------------------------------------------------------
    ensure_endpoint_ready(client, warmup_timeout=args.timeout)

    # ---------------------------------------------------------------------------
    # PHASE 2: Upload and submit all files in parallel (one thread per file)
    # ---------------------------------------------------------------------------
    print("\n" + "-" * 60)
    print("PHASE 2: Uploading and submitting jobs")
    print("-" * 60)
    print(f"Starting timing")
    start_timer = time.time()

    df = upload_and_submit_all(session, client, df, args.num_speakers, max_workers=args.max_workers)

    uploaded = df["asset_id"].notna().sum()
    submitted = df["job_id"].notna().sum()
    print(f"\nUploaded {uploaded}/{len(df)} files, submitted {submitted}/{len(df)} jobs")

    # Create mapping from job_id to filename for the callback
    job_to_filename = {
        row["job_id"]: row["filename"]
        for _, row in df.iterrows()
        if row["job_id"] is not None
    }

    # Track processed results
    processed_jobs = {}

    def process_result_immediately(job_id: str, status_data: dict):
        """Fetch full result JSON, save it, and build a TextGrid from segments."""
        filename = job_to_filename.get(job_id, "unknown")
        summary = status_data.get("summary", {})
        result_url = status_data.get("result_url")

        if result_url is None:
            print(f"         → ERROR: No result_url in response")
            processed_jobs[job_id] = {
                "status": "processing_failed",
                "error": "No result_url in response",
                "summary": summary,
            }
            return

        try:
            # Fetch full result JSON from presigned URL
            result_data = read_json_from_url(result_url)

            # Save raw JSON
            json_filename = Path(filename).stem + ".json"
            json_path = json_results_dir / json_filename
            with open(json_path, "w") as f:
                json.dump(result_data, f, indent=2)
            print(f"         → Saved JSON: {json_filename}")

            # Build TextGrid from segments
            segments = result_data.get("diarization", [])
            duration = summary.get("duration", 0.0)
            tg = segments_to_textgrid(segments, duration)
            tg_filename = Path(filename).stem + ".TextGrid"
            tg_path = textgrid_dir / tg_filename
            tg.save(str(tg_path), format="short_textgrid", includeBlankSpaces=True)
            print(f"         → Saved TextGrid: {tg_filename}")

            processed_jobs[job_id] = {"status": "processed", "summary": summary}

        except Exception as e:
            print(f"         → ERROR processing: {e}")
            processed_jobs[job_id] = {
                "status": "processing_failed",
                "error": str(e),
                "summary": summary,
            }

    # ---------------------------------------------------------------------------
    # PHASE 3: Poll all jobs
    # ---------------------------------------------------------------------------
    print("\n" + "-" * 60)
    print("PHASE 3: Polling and processing results")
    print("-" * 60)

    valid_job_ids = df["job_id"].dropna().tolist()
    job_results = poll_all_jobs(
        client,
        valid_job_ids,
        on_complete_callback=process_result_immediately,
        poll_interval=args.poll_interval,
        timeout=args.timeout,
    )
    print(f"Total time = {time.time()-start_timer}")

    # ---------------------------------------------------------------------------
    # PHASE 4: Save summary CSV
    # Flattens the 'summary' block (speaker_count, primary_speaker, duration,
    # segment_count) from the API response into individual columns.
    # ---------------------------------------------------------------------------
    summary_rows = []
    for _, row in df.iterrows():
        job_id = row["job_id"]
        processed = processed_jobs.get(job_id, {})
        api_summary = processed.get("summary", {})

        if job_id is None:
            status = "submit_failed"
        elif job_id in job_results:
            status = job_results[job_id].get("status", "unknown")
        else:
            status = "unknown"

        summary_rows.append({
            "filename": row["filename"],
            "path": row["path"],
            "asset_id": row["asset_id"],
            "job_id": job_id,
            "num_speakers_requested": args.num_speakers,
            "status": status,
            "speaker_count": api_summary.get("speaker_count"),
            "primary_speaker": api_summary.get("primary_speaker"),
            "duration": api_summary.get("duration"),
            "segment_count": api_summary.get("segment_count"),
        })

    summary_df = pd.DataFrame(summary_rows)
    summary_path = output_path / "diarization_summary.csv"
    summary_df.to_csv(summary_path, index=False)
    print(f"\nSaved summary to: {summary_path}")

    # Print final summary
    final_statuses = summary_df["status"].tolist()
    completed = sum(1 for s in final_statuses if s == "completed")
    failed = sum(1 for s in final_statuses if s in ("failed", "submit_failed"))
    other = len(final_statuses) - completed - failed
    processed_count = sum(1 for j in processed_jobs.values() if j.get("status") == "processed")

    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print(f"  Total files:        {len(df)}")
    print(f"  Completed:          {completed}")
    print(f"  Successfully saved: {processed_count}")
    print(f"  Failed:             {failed}")
    if other > 0:
        print(f"  Other:             {other}")
    print()
    print(f"  Output folder:      {output_path}")
    print(f"  TextGrids:          {textgrid_dir}")
    print(f"  JSON results:       {json_results_dir}")
    print(f"  Summary CSV:        {summary_path}")
    print("=" * 60)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nInterrupted by user. Exiting...")
        sys.exit(1)
    except Exception as e:
        print(f"\n\nFATAL ERROR: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)
