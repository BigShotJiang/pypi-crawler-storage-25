#!/usr/bin/env python3
"""
Batch Multi-Model Inference Example for RedenLab ML SDK

Runs inference on a folder of audio files across multiple models in one pass.
Files are uploaded once; the resulting asset IDs are reused for every model.
Long files (>50s) are automatically split into chunks and aggregated.

Authentication — choose one:

  Human / interactive (PKCE):
      Run once to store tokens in ~/.redenlab-ml/credentials.yaml:
          redenlab login
      Then run this script with no auth env vars set.

  Machine / headless (Client Credentials):
      export REDENLAB_CLIENT_ID='your-client-id'
      export REDENLAB_CLIENT_SECRET='your-client-secret'
      RedenLabSession() will detect these and fetch a token automatically.

Flow:
    1. Health check each model endpoint (warm up if cold)
    2. Upload ALL files once (with chunking for long files) to get asset IDs
    3. For each model:
       a. Submit ALL inference jobs using the already-uploaded asset IDs
       b. Poll ALL jobs and aggregate chunked results
       c. Save JSON per file + per-model summary CSV

Output layout:
    <output>/json_results/<model_name>/<file_stem>.json
    <output>/<model_name>_summary.csv

Usage:
    python batch_inference_v1.2.0.py \\
        --input /path/to/audio \\
        --output /path/to/output \\
        --models als-intelligibility-v1 als-naturalness-v1

Arguments:
    --input, -i   : Input folder containing audio files
    --output, -o  : Output folder for results
    --models, -m  : One or more model names (space-separated)

Available models:
    Intelligibility: als-intelligibility-v1, als-intelligibility-v2, ataxia-intelligibility
    Naturalness:     als-naturalness-v1, als-naturalness-v2, ataxia-naturalness
"""

import argparse
import json
import os
import sys
import tempfile
from math import gcd
from pathlib import Path

import pandas as pd

from redenlab_extract import (
    RedenLabSession,
    aggregate_results,
    intelligibility_client,
    naturalness_client,
)
from redenlab_extract.exceptions import AuthenticationError, ConfigurationError

AUDIO_EXTENSIONS = {".wav", ".flac", ".ogg"}

INTELLIGIBILITY_MODELS = {
    "als-intelligibility-v1",
    "als-intelligibility-v2",
    "ataxia-intelligibility",
}

NATURALNESS_MODELS = {
    "als-naturalness-v1",
    "als-naturalness-v2",
    "ataxia-naturalness",
}


TARGET_SR = 16_000


def resample_to_16k(input_path: str) -> tuple[str, bool]:
    """
    Resample audio to 16 kHz if it isn't already.

    Returns (path_to_use, was_resampled).
    When was_resampled is True the returned path is a temporary file — the
    caller is responsible for deleting it after upload.
    """
    try:
        from scipy.signal import resample_poly
    except ImportError as e:
        raise ImportError(
            "scipy is required for resampling. Install with: pip install scipy"
        ) from e

    import soundfile as sf

    info = sf.info(input_path)
    if info.samplerate == TARGET_SR:
        return input_path, False

    data, sr = sf.read(input_path)
    g = gcd(sr, TARGET_SR)
    resampled = resample_poly(data, TARGET_SR // g, sr // g, axis=0)

    suffix = Path(input_path).suffix
    tmp_fd, tmp_path = tempfile.mkstemp(suffix=suffix, prefix="redenlab_16k_")
    os.close(tmp_fd)
    sf.write(tmp_path, resampled, TARGET_SR)
    return tmp_path, True


def get_client(session: RedenLabSession, model_name: str, timeout: int):
    if model_name in INTELLIGIBILITY_MODELS:
        return intelligibility_client(session, model_name=model_name, timeout=timeout), "intelligibility_score"
    elif model_name in NATURALNESS_MODELS:
        return naturalness_client(session, model_name=model_name, timeout=timeout), "naturalness_score"
    else:
        valid = sorted(INTELLIGIBILITY_MODELS | NATURALNESS_MODELS)
        raise ValueError(f"Unknown model '{model_name}'. Valid models: {', '.join(valid)}")


def ensure_endpoint_ready(client, model_name: str, warmup_timeout: int = 900) -> None:
    print("\n" + "-" * 60)
    print(f"HEALTH CHECK: {model_name}")
    print("-" * 60)

    health = client.health()

    if health.get("status") == "not_supported":
        print(f"  {health.get('message', 'Health check not supported — endpoint always available.')}")
        return

    if health.get("ready") and not health.get("is_warming"):
        print(f"  Endpoint is ready (response time: {health.get('response_time', 'unknown')}s)")
        return

    if health.get("status") == "warming_up":
        print("  Endpoint is warming up from cold start.")
    else:
        print(f"  Endpoint not ready (status: {health.get('status')}). Triggering warmup...")

    print(f"  Running warmup (timeout: {warmup_timeout}s). This may take up to 10 minutes...")
    result = client.warmup(timeout=warmup_timeout, show_progress=True, force=True)

    if result.get("status") not in ("success", "already_ready"):
        print(f"  ERROR: Warmup did not complete: {result}")
        sys.exit(1)

    print("  Endpoint is ready — proceeding with inference.")


def get_audio_files(input_folder: str) -> list[str]:
    folder = Path(input_folder)
    if not folder.exists():
        raise FileNotFoundError(f"Input folder not found: {input_folder}")

    files = [
        str(f)
        for f in folder.iterdir()
        if f.is_file() and f.suffix.lower() in AUDIO_EXTENSIONS
    ]

    if not files:
        raise ValueError(
            f"No audio files found in {input_folder}. "
            f"Supported formats: {', '.join(AUDIO_EXTENSIONS)}"
        )

    return sorted(files)


def main():
    parser = argparse.ArgumentParser(
        description="Batch multi-model inference using RedenLab ML SDK",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    python batch_inference_v1.2.0.py -i ./audio -o ./results -m als-intelligibility-v1
    python batch_inference_v1.2.0.py -i ./audio -o ./results -m als-intelligibility-v1 als-naturalness-v1
        """,
    )
    parser.add_argument("-i", "--input", required=True, help="Input folder containing audio files")
    parser.add_argument("-o", "--output", required=True, help="Output folder for results")
    parser.add_argument(
        "-m", "--models",
        nargs="+",
        required=True,
        metavar="MODEL",
        help="One or more model names (e.g. als-intelligibility-v1 als-naturalness-v1)",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=3600,
        help="Max seconds to wait for jobs (default: 3600)",
    )
    parser.add_argument(
        "--poll-interval",
        type=int,
        default=10,
        help="Seconds between status checks (default: 10)",
    )

    args = parser.parse_args()

    try:
        session = RedenLabSession()
    except AuthenticationError:
        print("Error: Not authenticated.")
        print("  Human users:   run 'redenlab login' once in your terminal")
        print("  Machine users: set REDENLAB_CLIENT_ID and REDENLAB_CLIENT_SECRET env vars")
        sys.exit(1)
    except ConfigurationError as e:
        print(f"Configuration error: {e}")
        sys.exit(1)

    # Validate all model names upfront before doing any work
    model_configs: dict[str, tuple] = {}  # model_name -> (client, score_key)
    for model_name in args.models:
        try:
            client, score_key = get_client(session, model_name, args.timeout)
            model_configs[model_name] = (client, score_key)
        except ValueError as e:
            print(f"Error: {e}")
            sys.exit(1)

    # Deduplicate while preserving order
    seen = set()
    ordered_models = []
    for m in args.models:
        if m not in seen:
            seen.add(m)
            ordered_models.append(m)

    output_path = Path(args.output)
    output_path.mkdir(parents=True, exist_ok=True)

    print("\n" + "=" * 60)
    print("RedenLab ML SDK - Batch Multi-Model Inference")
    print("=" * 60)
    print(f"Input folder:  {args.input}")
    print(f"Output folder: {args.output}")
    print(f"Models ({len(ordered_models)}):")
    for m in ordered_models:
        _, sk = model_configs[m]
        print(f"  - {m}  [{sk}]")
    print("=" * 60)

    # Health-check all endpoints before uploading anything
    for model_name in ordered_models:
        client, _ = model_configs[model_name]
        ensure_endpoint_ready(client, model_name, warmup_timeout=args.timeout)

    # Collect audio files
    try:
        audio_files = get_audio_files(args.input)
        print(f"\nFound {len(audio_files)} audio files to process")
    except (FileNotFoundError, ValueError) as e:
        print(f"Error: {e}")
        sys.exit(1)

    df = pd.DataFrame(
        {
            "filename": [Path(p).name for p in audio_files],
            "path": audio_files,
        }
    )

    # ---------------------------------------------------------------------------
    # PHASE 1: Upload once — asset IDs are reused across all models
    # ---------------------------------------------------------------------------
    print("\n" + "-" * 60)
    print("PHASE 1: Uploading audio files (once, shared across all models)")
    print("-" * 60)

    file_assets: dict[str, list] = {}

    for i, row in df.iterrows():
        print(f"  [{i + 1}/{len(df)}] Uploading {row['filename']}...")
        tmp_path = None
        try:
            upload_path, was_resampled = resample_to_16k(row["path"])
            if was_resampled:
                tmp_path = upload_path
                print(f"         Resampled to {TARGET_SR} Hz")
            assets = session.upload_chunked(upload_path)
            file_assets[row["filename"]] = assets
            chunk_info = f" ({len(assets)} chunks)" if len(assets) > 1 else ""
            asset_ids_preview = ", ".join(a.asset_id[:12] + "..." for a in assets)
            print(f"         Asset ID(s): {asset_ids_preview}{chunk_info}")
        except Exception as e:
            print(f"         ERROR: {e}")
            file_assets[row["filename"]] = []
        finally:
            if tmp_path and os.path.exists(tmp_path):
                os.remove(tmp_path)

    uploaded = sum(1 for assets in file_assets.values() if assets)
    print(f"\nUploaded {uploaded}/{len(df)} files")

    df["asset_id"] = [
        file_assets[row["filename"]][0].asset_id if file_assets.get(row["filename"]) else None
        for _, row in df.iterrows()
    ]

    # ---------------------------------------------------------------------------
    # PHASES 2–4: Per-model — submit, poll, save
    # ---------------------------------------------------------------------------
    all_summary_paths: list[Path] = []

    for model_idx, model_name in enumerate(ordered_models, 1):
        client, score_key = model_configs[model_name]

        print("\n" + "=" * 60)
        print(f"MODEL {model_idx}/{len(ordered_models)}: {model_name}  [{score_key}]")
        print("=" * 60)

        # Per-model output dirs
        model_json_dir = output_path / "json_results" / model_name
        model_json_dir.mkdir(parents=True, exist_ok=True)

        # --- Phase 2: Submit ---
        print("\n" + "-" * 60)
        print(f"PHASE 2: Submitting inference jobs — {model_name}")
        print("-" * 60)

        file_job_ids: dict[str, list[str]] = {}

        for i, (_, row) in enumerate(df.iterrows()):
            filename = row["filename"]
            assets = file_assets.get(filename, [])

            if not assets:
                print(f"  [{i + 1}/{len(df)}] Skipping {filename} (upload failed)")
                file_job_ids[filename] = []
                continue

            print(f"  [{i + 1}/{len(df)}] Submitting {filename}...")
            job_ids = []
            failed = False
            for asset in assets:
                try:
                    job_id = client._submit_with_upload_wait(asset)
                    job_ids.append(job_id)
                except Exception as e:
                    print(f"         ERROR submitting chunk {asset.asset_id[:12]}...: {e}")
                    failed = True
                    break

            if failed:
                file_job_ids[filename] = []
            else:
                file_job_ids[filename] = job_ids
                chunk_info = f" ({len(job_ids)} chunks)" if len(job_ids) > 1 else ""
                print(f"         Job ID(s): {', '.join(j[:12] + '...' for j in job_ids)}{chunk_info}")

        total_jobs = sum(len(ids) for ids in file_job_ids.values())
        print(f"\nSubmitted {total_jobs} total jobs for {len(df)} files")

        # --- Phase 3: Poll ---
        print("\n" + "-" * 60)
        print(f"PHASE 3: Polling for completion — {model_name}")
        print("-" * 60)

        results: dict[str, dict] = {}

        for i, (_, row) in enumerate(df.iterrows(), 1):
            filename = row["filename"]
            job_ids = file_job_ids.get(filename, [])

            if not job_ids:
                results[filename] = {"status": "failed", "error": "Submission failed"}
                print(f"  [{i}/{len(df)}] {filename}: SKIPPED (submission failed)")
                continue

            print(f"  [{i}/{len(df)}] Polling {filename}...")
            try:
                if len(job_ids) == 1:
                    result = client.poll(job_ids[0], timeout=args.timeout)
                    score = result.get("result", {}).get(score_key)
                    results[filename] = {
                        "status": result.get("status", "unknown"),
                        score_key: score,
                        "std_dev": None,
                        "num_chunks": None,
                        "chunk_scores": None,
                        "raw_result": result,
                    }
                else:
                    chunk_results = []
                    for job_id in job_ids:
                        chunk_result = client.poll(job_id, timeout=args.timeout)
                        if chunk_result.get("status") == "completed":
                            chunk_results.append(chunk_result)

                    aggregated = aggregate_results(chunk_results, score_key)
                    score = aggregated.get("result", {}).get(score_key)
                    results[filename] = {
                        "status": aggregated.get("status", "unknown"),
                        score_key: score,
                        "std_dev": aggregated.get("result", {}).get("std_dev"),
                        "num_chunks": len(job_ids),
                        "chunk_scores": aggregated.get("result", {}).get("chunk_scores"),
                        "raw_result": aggregated,
                    }

                score_val = results[filename][score_key]
                score_str = f"{score_val:.4f}" if score_val is not None else "N/A"
                status_icon = "+" if results[filename]["status"] == "completed" else "!"
                print(f"         [{status_icon}] {score_key}: {score_str}")

            except Exception as e:
                print(f"         ERROR: {e}")
                results[filename] = {"status": "failed", "error": str(e)}

        # --- Phase 4: Save ---
        print("\n" + "-" * 60)
        print(f"PHASE 4: Saving results — {model_name}")
        print("-" * 60)

        for filename, result in results.items():
            json_path = model_json_dir / (Path(filename).stem + ".json")
            output_data = {
                "filename": filename,
                "model_name": model_name,
                "score_key": score_key,
                "status": result.get("status"),
                score_key: result.get(score_key),
                "std_dev": result.get("std_dev"),
                "num_chunks": result.get("num_chunks"),
                "chunk_scores": result.get("chunk_scores"),
            }
            if "error" in result:
                output_data["error"] = result["error"]
            with open(json_path, "w") as f:
                json.dump(output_data, f, indent=2)

        print(f"  Saved {len(results)} JSON files to {model_json_dir}")

        summary_rows = []
        for _, row in df.iterrows():
            filename = row["filename"]
            result = results.get(filename, {})
            job_ids = file_job_ids.get(filename, [])
            summary_rows.append({
                "filename": filename,
                "path": row["path"],
                "asset_id": row["asset_id"],
                "job_ids": ", ".join(job_ids) if job_ids else None,
                "status": result.get("status", "unknown"),
                score_key: result.get(score_key),
                "std_dev": result.get("std_dev"),
                "num_chunks": result.get("num_chunks"),
            })

        summary_df = pd.DataFrame(summary_rows)
        summary_path = output_path / f"{model_name}_summary.csv"
        summary_df.to_csv(summary_path, index=False)
        print(f"  Saved summary to: {summary_path}")
        all_summary_paths.append(summary_path)

        # Per-model result table
        completed = sum(1 for s in summary_df["status"] if s == "completed")
        failed = sum(1 for s in summary_df["status"] if s == "failed")
        print(f"\n  Results: {completed} completed, {failed} failed out of {len(df)}")
        for _, row in summary_df.iterrows():
            status_icon = "+" if row["status"] == "completed" else "x"
            score_val = row[score_key]
            score_str = f"{score_val:.4f}" if score_val is not None else "N/A"
            std_str = f" (std: {row['std_dev']:.4f})" if pd.notna(row.get("std_dev")) else ""
            chunk_str = f" [{int(row['num_chunks'])} chunks]" if pd.notna(row.get("num_chunks")) else ""
            print(f"    [{status_icon}] {row['filename']}: {score_str}{std_str}{chunk_str}")

    # ---------------------------------------------------------------------------
    # Final summary across all models
    # ---------------------------------------------------------------------------
    print("\n" + "=" * 60)
    print("ALL DONE")
    print("=" * 60)
    print(f"  Files processed:  {len(df)}")
    print(f"  Models run:       {len(ordered_models)}")
    print(f"  Output folder:    {output_path}")
    print(f"  JSON results:     {output_path / 'json_results'}/")
    print(f"  Summary CSVs:")
    for p in all_summary_paths:
        print(f"    {p}")
    print("=" * 60)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nInterrupted by user. Exiting...")
        sys.exit(1)
    except Exception as e:
        print(f"\n\nFATAL ERROR: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)
