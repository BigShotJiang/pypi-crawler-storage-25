#!/usr/bin/env python3
"""
Batch Sylber-Time Inference Example for RedenLab ML SDK

This script demonstrates how to batch process multiple audio files using the
sylber-time model, poll for completion, and export results to TextGrid and CSV formats.

Usage:
    export REDENLAB_ML_API_KEY='your-api-key'
    python batch_sylber_time.py --input /path/to/audio/folder --output /path/to/output

Arguments:
    --input, -i     : Input folder containing audio files
    --output, -o    : Output folder for results
                      Creates: textgrid/, json_results/, and sylber_time_summary.csv
"""

import argparse
import json
import os
import sys
import time
from pathlib import Path

import pandas as pd
from praatio import textgrid

from redenlab_extract import RedenLabSession, sylber_time_client

# Supported audio extensions
AUDIO_EXTENSIONS = {".wav", ".flac", ".ogg"}

# Metric columns extracted from result (excludes STATUS and segments)
METRIC_KEYS = [
    "DUR",
    "SYL_PER_MEAN", "SYL_PER_STD", "SYL_PER_COV",
    "SYL_DUR_MEAN", "SYL_DUR_STD", "SYL_DUR_COV",
    "SYL_COUNT", "SYL_PERSEC",
    "P_MEAN", "P_STD", "P_COV",
    "SPEECH_PERCENT", "P_PERCENT", "SPEECH_TO_P",
    "ARATE",
]


def segments_to_textgrid(segments: list[dict], duration: float) -> textgrid.Textgrid:
    """
    Convert sylber-time segments to a Praat TextGrid with a single Syllables tier.

    Args:
        segments: List of dicts with syllable_id, start, end
        duration: Total audio duration in seconds

    Returns:
        praatio Textgrid object
    """
    intervals = [
        (seg["start"], seg["end"], str(seg["syllable_id"]))
        for seg in segments
    ]

    tg = textgrid.Textgrid()
    syllable_tier = textgrid.IntervalTier("Syllables", intervals, 0, duration)
    tg.addTier(syllable_tier)
    return tg


def ensure_endpoint_ready(client, warmup_timeout: int = 900) -> None:
    """
    Check endpoint health and warm it up if needed. Blocks until the endpoint is ready.

    Args:
        client: InferenceClient instance (created by sylber_time_client)
        warmup_timeout: Max seconds to wait for warmup (default: 900 = 15 min)

    Raises:
        SystemExit: If the endpoint fails to become ready
    """
    print("\n" + "-" * 60)
    print("HEALTH CHECK: Verifying endpoint status")
    print("-" * 60)

    health = client.health()

    if health.get("status") == "not_supported":
        print(f"  {health.get('message', 'Health check not supported — endpoint always available.')}")
        return

    if health.get("ready") and not health.get("is_warming"):
        response_time = health.get("response_time", "unknown")
        print(f"  Endpoint is ready (response time: {response_time}s)")
        return

    # Endpoint is cold or warming up — trigger warmup and wait
    if health.get("status") == "warming_up":
        print("  Endpoint is warming up from cold start.")
    else:
        print(f"  Endpoint is not ready (status: {health.get('status')}). Triggering warmup...")

    print(f"  Running warmup (timeout: {warmup_timeout}s). This may take up to 10 minutes...")
    result = client.warmup(timeout=warmup_timeout, show_progress=True, force=True)

    if result.get("status") not in ("success", "already_ready"):
        print(f"  ERROR: Warmup did not complete successfully: {result}")
        sys.exit(1)

    print("  Endpoint is ready — proceeding with inference.")


def get_audio_files(input_folder: str) -> list[str]:
    """Get list of audio files from input folder."""
    folder = Path(input_folder)
    if not folder.exists():
        raise FileNotFoundError(f"Input folder not found: {input_folder}")

    files = []
    for f in folder.iterdir():
        if f.is_file() and f.suffix.lower() in AUDIO_EXTENSIONS:
            files.append(str(f))

    if not files:
        raise ValueError(
            f"No audio files found in {input_folder}. "
            f"Supported formats: {', '.join(AUDIO_EXTENSIONS)}"
        )

    return sorted(files)


def poll_all_jobs(
    client,
    job_ids: list[str],
    on_complete_callback=None,
    poll_interval: int = 10,
    timeout: int = 3600,
) -> dict[str, dict]:
    """
    Poll all jobs until they complete or fail, with optional callback for immediate processing.

    Args:
        client: InferenceClient instance (created by sylber_time_client)
        job_ids: List of job IDs to poll
        on_complete_callback: Optional function called immediately when each job completes.
                            Signature: callback(job_id: str, status_data: dict) -> None
        poll_interval: Seconds between poll attempts
        timeout: Maximum time to wait for all jobs

    Returns:
        Dictionary mapping job_id to final status dict
    """
    results = {}
    pending = set(job_ids)
    start_time = time.time()

    print(f"\nPolling {len(job_ids)} jobs for completion...")
    print("-" * 60)

    while pending and (time.time() - start_time) < timeout:
        for job_id in list(pending):
            try:
                status_data = client.get_status(job_id)
                status = status_data.get("status")

                if status == "completed":
                    results[job_id] = status_data
                    pending.remove(job_id)
                    completed_count = len(results)
                    total = len(job_ids)
                    print(f"  [COMPLETED] Job {job_id[:12]}... ({completed_count}/{total})")

                    if on_complete_callback:
                        try:
                            on_complete_callback(job_id, status_data)
                        except Exception as e:
                            print(f"         ERROR processing result: {e}")

                elif status == "failed":
                    results[job_id] = status_data
                    pending.remove(job_id)
                    completed_count = len(results)
                    total = len(job_ids)
                    error_msg = status_data.get("error", "Unknown error")
                    print(f"  [FAILED] Job {job_id[:12]}... - {error_msg}")

            except Exception as e:
                print(f"  [ERROR] Checking job {job_id[:12]}...: {e}")

        if pending:
            elapsed = int(time.time() - start_time)
            print(
                f"  ... {len(pending)} jobs still processing "
                f"(elapsed: {elapsed}s, waiting {poll_interval}s)"
            )
            time.sleep(poll_interval)

    # Handle timeout for remaining jobs
    for job_id in pending:
        results[job_id] = {"job_id": job_id, "status": "timeout", "error": "Polling timeout"}
        print(f"  [TIMEOUT] Job {job_id[:12]}...")

    return results


def main():
    parser = argparse.ArgumentParser(
        description="Batch sylber-time inference using RedenLab ML SDK",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    python batch_sylber_time.py -i ./audio_files -o ./results
    python batch_sylber_time.py --input /data/recordings --output /data/sylber_results
        """,
    )
    parser.add_argument(
        "-i", "--input", required=True, help="Input folder containing audio files"
    )
    parser.add_argument(
        "-o", "--output", required=True, help="Output folder for results"
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=3600,
        help="Maximum time to wait for jobs in seconds (default: 3600)",
    )
    parser.add_argument(
        "--poll-interval",
        type=int,
        default=10,
        help="Seconds between status checks (default: 10)",
    )

    args = parser.parse_args()

    # Check for API key
    api_key = os.environ.get("REDENLAB_ML_API_KEY")
    if not api_key:
        print("Error: REDENLAB_ML_API_KEY environment variable not set")
        print("Set it with: export REDENLAB_ML_API_KEY='your-api-key'")
        sys.exit(1)

    # Setup output directories
    output_path = Path(args.output)
    json_results_dir = output_path / "json_results"
    textgrid_dir = output_path / "textgrid"

    output_path.mkdir(parents=True, exist_ok=True)
    json_results_dir.mkdir(exist_ok=True)
    textgrid_dir.mkdir(exist_ok=True)

    print("\n" + "=" * 60)
    print("RedenLab ML SDK - Batch Sylber-Time Inference")
    print("=" * 60)
    print(f"Input folder:  {args.input}")
    print(f"Output folder: {args.output}")
    print("=" * 60)

    # Get audio files
    try:
        audio_files = get_audio_files(args.input)
        print(f"\nFound {len(audio_files)} audio files to process")
    except (FileNotFoundError, ValueError) as e:
        print(f"Error: {e}")
        sys.exit(1)

    # Create DataFrame
    df = pd.DataFrame(
        {
            "filename": [Path(p).name for p in audio_files],
            "path": audio_files,
        }
    )

    # Initialize session and client
    session = RedenLabSession(api_key=api_key)
    client = sylber_time_client(session=session, timeout=args.timeout)
    print(f"\nClient initialized: {client}")

    # Check endpoint health and warm up if needed before doing any work
    ensure_endpoint_ready(client, warmup_timeout=args.timeout)

    # Upload all files first
    print("\n" + "-" * 60)
    print("PHASE 1: Uploading audio files")
    print("-" * 60)

    assets = []
    for i, row in df.iterrows():
        print(f"  [{i + 1}/{len(df)}] Uploading {row['filename']}...")
        try:
            asset = session.upload(row["path"])
            assets.append(asset)
            print(f"         Asset ID: {asset.asset_id[:12]}...")
        except Exception as e:
            print(f"         ERROR: {e}")
            assets.append(None)

    df["asset_id"] = [asset.asset_id if asset else None for asset in assets]
    print(f"\nUploaded {sum(1 for a in assets if a is not None)}/{len(df)} files")

    # Submit all jobs
    print("\n" + "-" * 60)
    print("PHASE 2: Submitting sylber-time jobs")
    print("-" * 60)

    job_ids = []
    for i, (row, asset) in enumerate(zip(df.iterrows(), assets)):
        row = row[1]  # Extract row data from tuple
        if asset is None:
            print(f"  [{i + 1}/{len(df)}] Skipping {row['filename']} (upload failed)")
            job_ids.append(None)
            continue

        print(f"  [{i + 1}/{len(df)}] Submitting {row['filename']}...")
        try:
            job_id = client.submit(asset)
            job_ids.append(job_id)
            print(f"         Job ID: {job_id[:12]}...")
        except Exception as e:
            print(f"         ERROR: {e}")
            job_ids.append(None)

    df["job_id"] = job_ids
    print(f"\nSubmitted {sum(1 for j in job_ids if j is not None)}/{len(df)} jobs")

    # Create a mapping from job_id to filename for the callback
    job_to_filename = {
        job_id: filename
        for job_id, filename in zip(job_ids, df["filename"])
        if job_id is not None
    }

    # Track processed metrics per job_id
    processed_jobs = {}

    # Define callback to process results immediately
    def process_result_immediately(job_id: str, status_data: dict):
        """Process and save result as soon as job completes."""
        filename = job_to_filename.get(job_id, "unknown")
        result = status_data.get("result", {})

        try:
            # Save raw JSON result
            json_filename = Path(filename).stem + ".json"
            json_path = json_results_dir / json_filename
            with open(json_path, "w") as f:
                json.dump(status_data, f, indent=2)
            print(f"         → Saved JSON: {json_filename}")

            # Convert segments to TextGrid and save
            segments = result.get("segments", [])
            duration = result.get("DUR", 0.0)
            tg = segments_to_textgrid(segments, duration)
            tg_filename = Path(filename).stem + ".TextGrid"
            tg_path = textgrid_dir / tg_filename
            tg.save(str(tg_path), format="short_textgrid", includeBlankSpaces=True)
            print(f"         → Saved TextGrid: {tg_filename}")

            # Extract flat metrics (excludes STATUS and segments)
            metrics = {key: result.get(key) for key in METRIC_KEYS}

            processed_jobs[job_id] = {
                "status": "processed",
                "metrics": metrics,
            }

        except Exception as e:
            print(f"         → ERROR processing: {e}")
            processed_jobs[job_id] = {
                "status": "processing_failed",
                "error": str(e),
                "metrics": {key: None for key in METRIC_KEYS},
            }

    # Poll all jobs with immediate result processing
    print("\n" + "-" * 60)
    print("PHASE 3: Polling and processing results")
    print("-" * 60)

    valid_job_ids = [j for j in job_ids if j is not None]
    job_results = poll_all_jobs(
        client,
        valid_job_ids,
        on_complete_callback=process_result_immediately,
        poll_interval=args.poll_interval,
        timeout=args.timeout,
    )

    # Build summary rows with flattened metric columns
    summary_rows = []
    for _, row in df.iterrows():
        job_id = row["job_id"]
        base = {
            "filename": row["filename"],
            "path": row["path"],
            "asset_id": row["asset_id"],
            "job_id": job_id,
        }

        if job_id is None:
            base["status"] = "submit_failed"
            base.update({key: None for key in METRIC_KEYS})
        elif job_id in job_results:
            base["status"] = job_results[job_id].get("status", "unknown")
            processed = processed_jobs.get(job_id, {})
            base.update(processed.get("metrics", {key: None for key in METRIC_KEYS}))
        else:
            base["status"] = "unknown"
            base.update({key: None for key in METRIC_KEYS})

        summary_rows.append(base)

    summary_df = pd.DataFrame(summary_rows)
    summary_path = output_path / "sylber_time_summary.csv"
    summary_df.to_csv(summary_path, index=False)
    print(f"\nSaved summary to: {summary_path}")

    # Print final summary
    final_statuses = summary_df["status"].tolist()
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    completed = sum(1 for s in final_statuses if s == "completed")
    failed = sum(1 for s in final_statuses if s in ("failed", "submit_failed"))
    other = len(final_statuses) - completed - failed
    processed_count = sum(1 for j in processed_jobs.values() if j.get("status") == "processed")

    print(f"  Total files:        {len(df)}")
    print(f"  Completed:          {completed}")
    print(f"  Successfully saved: {processed_count}")
    print(f"  Failed:             {failed}")
    if other > 0:
        print(f"  Other:              {other}")
    print()
    print(f"  Output folder:      {output_path}")
    print(f"  TextGrids:          {textgrid_dir}")
    print(f"  JSON results:       {json_results_dir}")
    print(f"  Summary CSV:        {summary_path}")
    print("=" * 60)


if __name__ == "__main__":
    main()
