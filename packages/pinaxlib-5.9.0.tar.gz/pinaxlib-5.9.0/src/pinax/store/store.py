"""DuckDB-backed catalog store."""

from __future__ import annotations

import contextlib
import hashlib
import json
import os
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any, ClassVar, Self, cast

if TYPE_CHECKING:
    from collections.abc import Callable, Generator, Sequence

import duckdb
import sdmxlib
import sdmxlib.model.codelist
import sdmxlib.model.datastructure
from attrs import Factory, define
from sdmxlib import CompileContext, InternationalString

from pinax.model.agents import Agent, ContactPoint
from pinax.model.classification import Standard
from pinax.model.dataset import (
    AggregateDataset,
    BaseDataset,
    GeospatialDataset,
    MicrodataDataset,
    OpenDataset,
    PublicationDataset,
    Variable,
)
from pinax.model.distribution import DataService, Distribution
from pinax.model.licence import LicenceDocument
from pinax.model.quality import ProvenanceStatement, QualityAnnotation
from pinax.model.skos import Concept, ConceptRef, ConceptScheme
from pinax.model.spatial import SpatialCoverage
from pinax.model.temporal import Frequency, TemporalCoverage
from pinax.query import (
    MapFilter,
    PositionalFilter,
)
from pinax.store import schema as _catalog_schema
from pinax.store.row import Row
from pinax.store.scopes import (
    CodelistScope,
    CodelistsScope,
    ConceptSchemesScope,
    DatasetScope,
    DimensionsScope,
    ThemesScope,
)
from pinax.store.sentinel import make_unloaded

__all__ = ["Catalog", "QueryBuilder", "Row", "SearchResult"]

# ---------------------------------------------------------------------------
# Type registry
# ---------------------------------------------------------------------------

_DATASET_TYPES: dict[str, type[BaseDataset]] = {
    "open": OpenDataset,
    "aggregate": AggregateDataset,
    "microdata": MicrodataDataset,
    "geospatial": GeospatialDataset,
    "publication": PublicationDataset,
    # backward compat for data stored with old class-name _type values
    "Dataset": OpenDataset,
    "StatisticalDataset": AggregateDataset,
}

_CLS_TO_KIND: dict[type[BaseDataset], str] = {
    OpenDataset: "open",
    AggregateDataset: "aggregate",
    MicrodataDataset: "microdata",
    GeospatialDataset: "geospatial",
    PublicationDataset: "publication",
}

# entity_type values that identify a dataset-level row in the search index.
# Used to exclude code-level rows (entity_type == "code") from dataset
# rankings, see issue #82.
_DATASET_ENTITY_TYPES: tuple[str, ...] = tuple(_CLS_TO_KIND.values())

# Sidecar file that records which embedding model + prefixes produced the
# vector index in ``<catalog>/search/``.  Written by ``build_index`` and read
# back by ``open()`` so callers don't have to remember which model to load.
_EMBEDDINGS_META_FILE = "embeddings.json"
# v2: code-row schema gained dimension_id/dimension_label/code_id/code_label
# columns and the default for `embed_codes` flipped to False (#83, #84).
# Indexes built on v1 are still readable for dataset-level search but lack
# the structured code columns required by ``search_codes``.
_EMBEDDINGS_META_VERSION = 2

_DEFAULT_EMBED_BATCH_SIZE = 256
_EMBED_BATCH_SIZE_ENV = "PINAX_EMBED_BATCH_SIZE"


def _embed_batch_size() -> int:
    """Resolve the encoder batch size from ``PINAX_EMBED_BATCH_SIZE``.

    Falls back to ``_DEFAULT_EMBED_BATCH_SIZE`` when the env var is unset,
    empty, non-numeric, or non-positive — the default is conservative
    enough to run on modest hardware, so we never want to silently pick
    something worse.
    """
    raw = os.environ.get(_EMBED_BATCH_SIZE_ENV)
    if not raw:
        return _DEFAULT_EMBED_BATCH_SIZE
    try:
        value = int(raw)
    except ValueError:
        return _DEFAULT_EMBED_BATCH_SIZE
    return value if value > 0 else _DEFAULT_EMBED_BATCH_SIZE


def _read_embeddings_meta(search_dir: Path) -> dict[str, Any] | None:
    """Return the parsed ``embeddings.json`` from *search_dir*, or None.

    Returns ``None`` when the file is missing, empty, or malformed — callers
    should treat that as "no embedding metadata", not as an error.
    """
    meta_path = search_dir / _EMBEDDINGS_META_FILE
    if not meta_path.is_file():
        return None
    try:
        data = json.loads(meta_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(data, dict):
        return None
    return data


def _write_embeddings_meta(
    search_dir: Path,
    *,
    model_name: str | None,
    document_prefix: str,
    query_prefix: str,
) -> None:
    """Persist embedding-build metadata to ``<search_dir>/embeddings.json``.

    No-op when *model_name* is ``None`` — without a model name there is no
    way for ``open()`` to reload a matching encoder, so there is no point
    pinning the prefixes either.
    """
    if model_name is None:
        return
    search_dir.mkdir(parents=True, exist_ok=True)
    payload = {
        "version": _EMBEDDINGS_META_VERSION,
        "model": model_name,
        "document_prefix": document_prefix,
        "query_prefix": query_prefix,
    }
    (search_dir / _EMBEDDINGS_META_FILE).write_text(
        json.dumps(payload, indent=2) + "\n",
        encoding="utf-8",
    )


# Maps queryable types to their DuckDB table
_TABLE_MAP: dict[type, str] = {
    BaseDataset: "dataset",
    OpenDataset: "dataset",
    AggregateDataset: "dataset",
    MicrodataDataset: "dataset",
    GeospatialDataset: "dataset",
    PublicationDataset: "dataset",
    Agent: "agent",
    DataService: "data_service",
    Distribution: "distribution",
}

# Column names for flat-column entity queries
_ENTITY_COLUMNS: dict[type, str] = {
    Agent: "id, name, type, homepage",
    DataService: "id, title, description, endpoint_url",
    Distribution: (
        "id, dataset_id, title, description, access_url, download_url,"
        " media_type, format, byte_size, issued, modified,"
        " licence_id, service_id, distribution_type"
    ),
}

# Supported filter column names per entity table
_ENTITY_FILTER_COLS: dict[type, dict[str, str]] = {
    Agent: {"id": "id", "type": "type", "homepage": "homepage", "name": "name['en']"},
    DataService: {"id": "id", "endpoint_url": "endpoint_url"},
    Distribution: {
        "id": "id",
        "dataset_id": "dataset_id",
        "format": "format",
        "media_type": "media_type",
        "access_url": "access_url",
    },
}


def _map_to_istring(m: dict[str, str] | None) -> InternationalString | None:
    """Convert a DuckDB MAP dict to InternationalString."""
    if m is None:
        return None
    return InternationalString.of(m)


def _istring_to_map(s: InternationalString | None) -> dict[str, str] | None:
    """Convert InternationalString to a Python dict for DuckDB MAP param."""
    if s is None:
        return None
    return {lang: s[lang] for lang in s}


@dataclass
class _QueryContext(CompileContext):
    """Pinax-specific compile context.

    Extends :class:`sdmxlib.CompileContext` with pinax-flavored accumulators.
    The base class tracks shared state across predicates that need it (joins,
    join-alias dedup); this subclass adds:

    - **WHERE accumulator** — predicates' fragments collect here. The base
      CompileContext only carries joins because each predicate's
      ``to_sql(ctx)`` returns its own WHERE fragment + params; the compiler
      ANDs them together. We accumulate here for convenience so the
      ``join_clause`` / ``where_clause`` properties produce the final
      stitched SQL.

    Alias generation, schema resolution, and join-dedup live on the base
    :class:`~sdmxlib.CompileContext`.
    """

    wheres: list[str] = field(default_factory=list)
    where_params: list[object] = field(default_factory=list)

    def add_where(self, sql: str, *filter_params: object) -> None:
        """Append a WHERE clause fragment and its parameters."""
        self.wheres.append(sql)
        self.where_params.extend(filter_params)

    @property
    def join_clause(self) -> str:
        return " ".join(self.join_sqls)

    @property
    def where_clause(self) -> str:
        return ("WHERE " + " AND ".join(self.wheres)) if self.wheres else ""

    @property
    def params(self) -> list[object]:
        """All parameters in execution order: joins first, then WHERE params."""
        return [*self.join_params, *self.where_params]


@define
class _BatchContext:
    """Pre-fetched relationship data for batch dataset reconstruction."""

    agents: dict[str, Agent]
    contacts: dict[str, ContactPoint]
    frequencies: dict[str, Frequency]
    licences: dict[str, LicenceDocument]
    themes: dict[str, list[ConceptRef]]
    subject: dict[str, list[ConceptRef]]
    dataset_type: dict[str, ConceptRef]
    keywords: dict[str, list[InternationalString]]
    spatial: dict[str, list[SpatialCoverage]]
    distributions: dict[str, list[Distribution]]
    standards: dict[str, list[Standard]]
    quality: dict[str, list[QualityAnnotation]]
    provenance: dict[str, list[ProvenanceStatement]]
    dimension_names: dict[str, list[InternationalString]]
    variables: dict[str, list[Variable]]
    feature_types: dict[str, list[str]]
    authors: dict[str, list[str]]


@define(frozen=True)
class _DimensionIds:
    """FK IDs returned by ``_upsert_dimension_records``."""

    publisher: str | None = None
    creator: str | None = None
    contact: str | None = None
    frequency: str | None = None
    licence: str | None = None


def _assemble_dataset(
    row: tuple[Any, ...],
    ctx: _BatchContext,
    *,
    include_rels: frozenset[str] | None = None,
) -> BaseDataset:
    """Assemble a single dataset from a row using pre-fetched batch context.

    Parameters
    ----------
    include_rels:
        When ``None`` all relationships are populated from *ctx*.
        When a frozenset, only named relationships are populated; the rest
        are set to the ``UNLOADED`` sentinel so that accidental access raises
        ``NotLoadedError`` rather than silently returning empty data.
    """
    (
        identifier,
        kind,
        title_map,
        desc_map,
        vnotes_map,
        publisher_id,
        creator_id,
        contact_id,
        frequency_id,
        licence_id,
        temporal_start,
        temporal_end,
        status,
        access_rights,
        issued,
        modified,
        landing_page,
        version,
        language,
        num_series,
        sdmx_dataflow_urn,
        measure_dim,
        sample_size,
        universe,
        collection_method,
        anonymization,
        survey_id,
        crs,
        spatial_resolution,
        scale,
        doi,
        isbn,
        publication_type,
        pages,
        series_title_map,
        _dataset_type_uri,  # resolved via batch ctx.dataset_type below
        extras_map,
    ) = row

    title = _map_to_istring(title_map) or InternationalString()
    description = _map_to_istring(desc_map) or InternationalString()
    version_notes = _map_to_istring(vnotes_map)
    extras = dict(extras_map) if extras_map else {}

    temporal_coverage: TemporalCoverage | None = None
    if temporal_start is not None or temporal_end is not None:
        temporal_coverage = TemporalCoverage(start=temporal_start, end=temporal_end)

    lang_list: list[str] = list(language) if language else []

    def _rel(field: str, loaded_value: Any, unloaded_value: Any = None) -> Any:
        """Return loaded_value if field is included, else the UNLOADED sentinel.

        For FK-based fields (publisher, creator, frequency, licence) pass the already-
        resolved value as *loaded_value* and ``None`` as *unloaded_value* —
        when the FK column itself is NULL we always return None regardless of
        include_rels, because we KNOW from the main row there is no value.
        """
        if include_rels is None or field in include_rels:
            return loaded_value
        # FK is null → genuinely no value; skip UNLOADED
        if unloaded_value is None and loaded_value is None:
            return None
        return make_unloaded(field)

    base_kwargs: dict[str, Any] = {
        "identifier": identifier,
        "title": title,
        "description": description,
        # FK-based: if FK is null the dataset genuinely has no publisher/etc.
        "publisher": _rel(
            "publisher",
            ctx.agents.get(publisher_id) if publisher_id else None,
            make_unloaded("publisher") if publisher_id else None,
        ),
        "creator": _rel(
            "creator",
            ctx.agents.get(creator_id) if creator_id else None,
            make_unloaded("creator") if creator_id else None,
        ),
        "contact_point": _rel(
            "contact_point",
            ctx.contacts.get(contact_id) if contact_id else None,
            make_unloaded("contact_point") if contact_id else None,
        ),
        "frequency": _rel(
            "frequency",
            ctx.frequencies.get(frequency_id) if frequency_id else None,
            make_unloaded("frequency") if frequency_id else None,
        ),
        "licence": _rel(
            "licence",
            ctx.licences.get(licence_id) if licence_id else None,
            make_unloaded("licence") if licence_id else None,
        ),
        # Bridge-table list fields: always UNLOADED when not included
        "keywords": _rel("keywords", ctx.keywords.get(identifier, []), "sentinel"),
        "themes": _rel("themes", ctx.themes.get(identifier, []), "sentinel"),
        "subject": _rel("subject", ctx.subject.get(identifier, []), "sentinel"),
        "dataset_type": _rel("dataset_type", ctx.dataset_type.get(identifier), "sentinel"),
        "spatial_coverage": _rel("spatial_coverage", ctx.spatial.get(identifier, []), "sentinel"),
        "distributions": _rel("distributions", ctx.distributions.get(identifier, []), "sentinel"),
        "conforms_to": _rel("conforms_to", ctx.standards.get(identifier, []), "sentinel"),
        "provenance": _rel("provenance", ctx.provenance.get(identifier, []), "sentinel"),
        "quality_annotations": _rel("quality_annotations", ctx.quality.get(identifier, []), "sentinel"),
        # Scalar fields — always loaded from the main row
        "issued": issued,
        "modified": modified,
        "temporal_coverage": temporal_coverage,
        "language": lang_list,
        "landing_page": landing_page,
        "version": version,
        "version_notes": version_notes,
        "access_rights": access_rights,
        "status": status,
        "extras": extras,
    }

    if kind == "aggregate":
        return AggregateDataset(
            **base_kwargs,
            dimension_names=_rel("dimension_names", ctx.dimension_names.get(identifier, []), "sentinel"),
            num_series=num_series,
            sdmx_dataflow_urn=sdmx_dataflow_urn,
            measure_dim=measure_dim,
        )
    if kind == "microdata":
        return MicrodataDataset(
            **base_kwargs,
            variables=_rel("variables", ctx.variables.get(identifier, []), "sentinel"),
            sample_size=sample_size,
            universe=universe,
            collection_method=collection_method,
            anonymization=anonymization,
            survey_id=survey_id,
        )
    if kind == "geospatial":
        return GeospatialDataset(
            **base_kwargs,
            crs=crs,
            spatial_resolution=spatial_resolution,
            feature_types=_rel("feature_types", ctx.feature_types.get(identifier, []), "sentinel"),
            scale=scale,
        )
    if kind == "publication":
        series_title = _map_to_istring(series_title_map)
        return PublicationDataset(
            **base_kwargs,
            authors=_rel("authors", ctx.authors.get(identifier, []), "sentinel"),
            doi=doi,
            isbn=isbn,
            publication_type=publication_type,
            pages=pages,
            series_title=series_title,
        )
    return OpenDataset(**base_kwargs)


def _reconstruct_agent(row: tuple[Any, ...]) -> Agent:
    id_, name_map, type_, homepage = row
    name = _map_to_istring(name_map) or InternationalString()
    return Agent(id=id_, name=name, type=type_, homepage=homepage)


def _reconstruct_data_service(row: tuple[Any, ...]) -> DataService:
    id_, title_map, desc_map, endpoint_url = row
    title = _map_to_istring(title_map) or InternationalString()
    description = _map_to_istring(desc_map)
    # Load serves_datasets from service_dataset bridge
    return DataService(id=id_, title=title, description=description, endpoint_url=endpoint_url or "")


def _reconstruct_distribution(row: tuple[Any, ...]) -> Distribution:
    (
        id_,
        _dataset_id,
        title_map,
        desc_map,
        access_url,
        download_url,
        media_type,
        fmt,
        byte_size,
        issued,
        modified,
        _licence_id,
        _service_id,
        dist_type,
    ) = row
    title = _map_to_istring(title_map)
    description = _map_to_istring(desc_map)
    return Distribution(
        id=id_,
        title=title,
        description=description,
        access_url=access_url,
        download_url=download_url,
        media_type=media_type,
        format=fmt,
        byte_size=byte_size,
        issued=issued,
        modified=modified,
        distribution_type=dist_type,
    )


_ENTITY_RECONSTRUCTORS: dict[type, Any] = {
    Agent: _reconstruct_agent,
    DataService: _reconstruct_data_service,
    Distribution: _reconstruct_distribution,
}


def _sql_literal(v: Any) -> str:
    """Format a Python value as a DuckDB SQL literal for bulk VALUES clauses."""
    if v is None:
        return "NULL"
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    if isinstance(v, (int, float)):
        return str(v)
    if isinstance(v, datetime):
        return f"'{v.isoformat()}'"
    if isinstance(v, dict):
        # MAP literal for DuckDB
        entries = ", ".join(f"'{k}': '{str(val).replace(chr(39), chr(39) + chr(39))}'" for k, val in v.items())
        return f"MAP {{{entries}}}"
    s = str(v).replace("'", "''")
    return f"'{s}'"


def _agent_id(agent: Agent) -> str:
    """Derive a stable ID for an agent."""
    return (
        agent.id
        or hashlib.md5(  # noqa: S324
            (agent.name.get("en") or agent.name.get("fr") or "").encode()
        ).hexdigest()[:12]
    )


def _contact_id(contact: ContactPoint) -> str:
    """Derive a stable ID for a contact."""
    key = contact.email or contact.url or ""
    if contact.name:
        key += contact.name.get("en") or contact.name.get("fr") or ""
    return hashlib.md5(key.encode()).hexdigest()[:12]  # noqa: S324


# ---------------------------------------------------------------------------
# Sortable columns mapping
# ---------------------------------------------------------------------------

_SORTABLE_COLUMNS: frozenset[str] = frozenset(
    {
        "identifier",
        "kind",
        "status",
        "issued",
        "modified",
        "publisher_id",
        "frequency_id",
    }
)

_MAP_SORTABLE_COLUMNS: frozenset[str] = frozenset({"title"})

# Columns allowed in .select() / .scalars() lightweight projections
_SELECTABLE_COLUMNS: frozenset[str] = frozenset(
    {
        "identifier",
        "kind",
        "status",
        "issued",
        "modified",
        "landing_page",
        "version",
    }
)
_MAP_SELECTABLE_COLUMNS: frozenset[str] = frozenset({"title", "description"})

# ---------------------------------------------------------------------------
# Internal query result container
# ---------------------------------------------------------------------------


@define
class _SortSpec:
    field: str
    desc: bool = False
    nulls: str | None = None
    lang: str | None = None


@define
class _QueryResult:
    total: int
    rows: list[Any]
    scores: dict[str, float] = Factory(dict)


# ---------------------------------------------------------------------------
# Public result types
# ---------------------------------------------------------------------------


@define
class SearchResult[T]:
    """Container for query results with pagination metadata."""

    items: list[T]
    total: int
    facets: dict[str, dict[str, int]] = Factory(dict)
    offset: int = 0
    scores: dict[str, float] = Factory(dict)


@define(frozen=True)
class CodeSearchResult:
    """One BM25 hit from :meth:`Catalog.search_codes`.

    Carries the structured ``(dimension_id, code_id)`` pair so callers —
    typically LLM agents translating a phrase like "Ontario" into a
    filter — can use it directly without re-parsing the joined text.
    """

    dataset_id: str
    dimension_id: str
    dimension_label: str
    code_id: str
    code_label: str
    text: str
    score: float
    lang: str


# Relationship names accepted by QueryBuilder.include().
# These match the model field names on BaseDataset (and subclasses).
_VALID_INCLUDE_RELS: frozenset[str] = frozenset(
    {
        "publisher",
        "creator",
        "contact_point",
        "frequency",
        "licence",
        "themes",
        "subject",
        "dataset_type",
        "keywords",
        "spatial_coverage",
        "distributions",
        "conforms_to",
        "quality_annotations",
        "provenance",
        "dimension_names",  # AggregateDataset
        "variables",  # MicrodataDataset
        "feature_types",  # GeospatialDataset
        "authors",  # PublicationDataset
    }
)


class QueryBuilder[T]:
    """Chainable query builder. Terminal method: ``.execute()`` or ``.all()``."""

    __slots__ = (
        "_cls",
        "_exists_filters",
        "_facet_fields",
        "_filters",
        "_from_ids",
        "_hybrid_text",
        "_include_rels",
        "_limit",
        "_map_filters",
        "_offset",
        "_scalar_col",
        "_search_fuzziness",
        "_search_operator",
        "_select_cols",
        "_select_lang",
        "_sort_fields",
        "_store",
        "_text",
    )

    def __init__(
        self,
        store: Catalog,
        cls: type[T],
        *,
        filters: dict[str, Any] | None = None,
        exists_filters: list[PositionalFilter] | None = None,
        map_filters: list[MapFilter] | None = None,
        from_ids: list[str] | None = None,
        text: str | None = None,
        hybrid_text: str | None = None,
        search_operator: str = "or",
        search_fuzziness: int = 0,
        sort_fields: list[_SortSpec] | None = None,
        limit: int | None = None,
        offset: int = 0,
        facet_fields: list[str] | None = None,
        select_cols: tuple[str, ...] | None = None,
        select_lang: str | None = None,
        scalar_col: str | None = None,
        include_rels: frozenset[str] | None = None,
    ) -> None:
        self._store = store
        self._cls = cls
        self._filters = filters or {}
        self._exists_filters = exists_filters or []
        self._map_filters = map_filters or []
        self._from_ids = from_ids
        self._text = text
        self._hybrid_text = hybrid_text
        self._search_operator = search_operator
        self._search_fuzziness = search_fuzziness
        self._sort_fields = sort_fields or []
        self._limit = limit
        self._offset = offset
        self._facet_fields = facet_fields or []
        self._select_cols = select_cols
        self._select_lang = select_lang
        self._scalar_col = scalar_col
        self._include_rels = include_rels

    # -- internal clone helper --

    def _clone(self, **overrides: Any) -> QueryBuilder[T]:
        """Return a copy with the given fields overridden."""
        defaults: dict[str, Any] = {
            "filters": dict(self._filters),
            "exists_filters": list(self._exists_filters),
            "map_filters": list(self._map_filters),
            "from_ids": self._from_ids,
            "text": self._text,
            "hybrid_text": self._hybrid_text,
            "search_operator": self._search_operator,
            "search_fuzziness": self._search_fuzziness,
            "sort_fields": list(self._sort_fields),
            "limit": self._limit,
            "offset": self._offset,
            "facet_fields": list(self._facet_fields),
            "select_cols": self._select_cols,
            "select_lang": self._select_lang,
            "scalar_col": self._scalar_col,
            "include_rels": self._include_rels,
        }
        defaults.update(overrides)
        return QueryBuilder(self._store, self._cls, **defaults)

    # -- chaining methods --

    def filter(self, *pos_filters: PositionalFilter | MapFilter, **kw_filters: Any) -> QueryBuilder[T]:
        """Add filter criteria. Returns a new builder (immutable chain)."""
        new_exists = list(self._exists_filters)
        new_map = list(self._map_filters)
        for pf in pos_filters:
            if isinstance(pf, MapFilter):
                new_map.append(pf)
            else:
                new_exists.append(pf)
        merged = {**self._filters, **kw_filters}
        return self._clone(filters=merged, exists_filters=new_exists, map_filters=new_map)

    def from_ids(self, ids: list[str]) -> QueryBuilder[T]:
        """Restrict results to a pre-computed list of identifiers."""
        return self._clone(from_ids=ids)

    def search(self, text: str, *, operator: str = "or", fuzzy: int = 0) -> QueryBuilder[T]:
        """Add full-text search. Requires LanceDB.

        Parameters
        ----------
        operator:
            How to join multi-term queries: ``"or"`` (default) matches any
            term; ``"and"`` requires all terms.
        fuzzy:
            Levenshtein edit distance for fuzzy matching: ``0`` (default,
            exact match), ``1``, or ``2``.
        """
        return self._clone(text=text, search_operator=operator, search_fuzziness=fuzzy)

    def hybrid_search(self, text: str) -> QueryBuilder[T]:
        """Add hybrid BM25 + semantic search. Requires LanceDB."""
        return self._clone(hybrid_text=text)

    def sort_by(
        self,
        field: str,
        *,
        desc: bool = False,
        nulls: str | None = None,
        lang: str | None = None,
    ) -> QueryBuilder[T]:
        """Add a sort criterion.

        For MAP columns like ``title``, pass ``lang`` to specify the
        language key (e.g. ``lang="en"``).  Raises ``ValueError`` if
        ``lang`` is omitted for a MAP column.
        """
        new_sorts = [*self._sort_fields, _SortSpec(field=field, desc=desc, nulls=nulls, lang=lang)]
        return self._clone(sort_fields=new_sorts)

    def limit(self, n: int) -> QueryBuilder[T]:
        """Set maximum number of results."""
        return self._clone(limit=n)

    def offset(self, n: int) -> QueryBuilder[T]:
        """Set pagination offset."""
        return self._clone(offset=n)

    def with_facets(self, *fields: str) -> QueryBuilder[T]:
        """Request facet counts alongside the results."""
        return self._clone(facet_fields=[*self._facet_fields, *fields])

    def include(self, *relationships: str) -> QueryBuilder[T]:
        """Declare which relationships to batch-load during hydration.

        By default all relationships are loaded (~17 queries).  Calling
        ``include()`` switches to selective loading: only the named
        relationships are fetched; everything else stays at its model
        default (``None`` / ``[]``).

        Subsequent ``include()`` calls accumulate — they do not replace
        the previous set.  Use ``full()`` to revert to loading everything.

        Valid names mirror the model field names::

            store.query(BaseDataset)
                .include("publisher", "themes", "keywords")
                .collect()   # 3 batch loads instead of 17

        Raises ``ValueError`` for unrecognised relationship names.
        """
        unknown = set(relationships) - _VALID_INCLUDE_RELS
        if unknown:
            msg = f"Unknown relationship(s): {sorted(unknown)}. Valid names: {sorted(_VALID_INCLUDE_RELS)}"
            raise ValueError(msg)
        current = self._include_rels if self._include_rels is not None else frozenset()
        return self._clone(include_rels=current | frozenset(relationships))

    def full(self) -> QueryBuilder[T]:
        """Load all relationships (the default behaviour).

        Useful to explicitly opt into full hydration after a partial
        ``include()`` call, or to make the cost visible at the call site::

            store.query(BaseDataset).filter(...).full().collect()
        """
        return self._clone(include_rels=None)

    # -- projection modifiers (SA2-style) --

    def select(self, *columns: str, lang: str | None = None) -> QueryBuilder[T]:
        """Set dict projection mode. Terminals return dicts instead of objects.

        ``lang`` is required when selecting MAP columns (``title``,
        ``description``).  Raises ``ValueError`` for unknown column names.
        """
        all_allowed = _SELECTABLE_COLUMNS | _MAP_SELECTABLE_COLUMNS
        for col in columns:
            if col not in all_allowed:
                msg = f"Invalid select column: {col!r}. Allowed: {sorted(all_allowed)}"
                raise ValueError(msg)
        map_cols = _MAP_SELECTABLE_COLUMNS & set(columns)
        if map_cols and lang is None:
            msg = f"lang is required when selecting MAP columns: {sorted(map_cols)}"
            raise ValueError(msg)
        return self._clone(select_cols=columns, select_lang=lang)

    def scalars(self, column: str, *, lang: str | None = None) -> QueryBuilder[T]:
        """Set single-column flat projection mode.

        Terminals return bare values instead of objects or dicts.
        """
        all_allowed = _SELECTABLE_COLUMNS | _MAP_SELECTABLE_COLUMNS
        if column not in all_allowed:
            msg = f"Invalid scalar column: {column!r}. Allowed: {sorted(all_allowed)}"
            raise ValueError(msg)
        if column in _MAP_SELECTABLE_COLUMNS and lang is None:
            msg = f"lang is required when selecting MAP column {column!r}"
            raise ValueError(msg)
        return self._clone(scalar_col=column, select_lang=lang)

    # -- projection guards --

    def _check_entity_mode(self, method: str) -> None:
        if self._select_cols is not None:
            msg = f".{method}() cannot be used when .select() is active — use .rows() instead"
            raise ValueError(msg)
        if self._scalar_col is not None:
            msg = f".{method}() cannot be used when .scalars() is active — use .values() instead"
            raise ValueError(msg)

    def _check_row_mode(self, method: str) -> None:
        if self._select_cols is None:
            msg = f".{method}() requires .select() — call .select(...) first, or use .collect() for domain objects"
            raise ValueError(msg)

    def _check_scalar_mode(self, method: str) -> None:
        if self._scalar_col is None:
            msg = f".{method}() requires .scalars() — call .scalars(...) first"
            raise ValueError(msg)

    # -- terminal methods --

    def execute(self) -> SearchResult[T]:
        """Execute the query and return a ``SearchResult`` with metadata.

        Only available in entity mode (no ``.select()`` / ``.scalars()``).
        """
        self._check_entity_mode("execute")
        return self._store._execute_query(  # noqa: SLF001
            self._cls,
            self._filters,
            self._exists_filters,
            self._map_filters,
            self._from_ids,
            self._text,
            self._hybrid_text,
            self._search_operator,
            self._search_fuzziness,
            self._sort_fields,
            self._limit,
            self._offset,
            self._facet_fields,
            include_rels=self._include_rels,
        )

    def _resolve_search_ids(self) -> list[str] | None:
        """If text search is active, resolve ranked IDs; otherwise return None."""
        if self._text is None and self._hybrid_text is None:
            return None
        return self._store._ranked_ids_from_search(  # noqa: SLF001
            self._cls,
            self._filters,
            self._exists_filters,
            self._map_filters,
            self._text,
            self._hybrid_text,
            self._search_operator,
            self._search_fuzziness,
            self._sort_fields,
            self._limit,
            self._offset,
        )

    def collect(self) -> list[T]:
        """Execute and return domain objects.

        This is the preferred terminal for entity results — consistent with
        scope terminals (``.collect()`` on ``SchemeScope``, ``CodelistScope``,
        etc.).  Use ``.rows()`` for ``Row`` projections or ``.values()`` for
        scalar projections.
        """
        self._check_entity_mode("collect")
        return self.execute().items

    def all(self) -> list[T]:
        """Alias for ``.collect()``."""
        return self.collect()

    def first(self) -> T | None:
        """Execute with limit=1 and return the first domain object or None."""
        self._check_entity_mode("first")
        items = self.limit(1).collect()
        return items[0] if items else None

    def one(self) -> T:
        """Execute and return exactly one domain object; raise on 0 or >1."""
        self._check_entity_mode("one")
        result = self.limit(2).execute()
        if result.total == 0:
            msg = "No results found"
            raise KeyError(msg)
        if result.total > 1:
            msg = f"Expected exactly one result, got {result.total}"
            raise ValueError(msg)
        return result.items[0]

    # -- row projection terminals --

    def rows(self) -> list[Row]:
        """Execute and return ``Row`` objects (requires ``.select()``)."""
        self._check_row_mode("rows")
        ranked_ids = self._resolve_search_ids()
        if ranked_ids is not None and not ranked_ids:
            return []
        return self._store._execute_projection(  # noqa: SLF001
            self._cls,
            self._select_cols,  # pyright: ignore[reportArgumentType]
            self._select_lang,
            filters={} if ranked_ids is not None else self._filters,
            exists_filters=[] if ranked_ids is not None else self._exists_filters,
            map_filters=[] if ranked_ids is not None else self._map_filters,
            from_ids=ranked_ids if ranked_ids is not None else self._from_ids,
            sort_fields=[] if ranked_ids is not None else self._sort_fields,
            limit=None if ranked_ids is not None else self._limit,
            offset=0 if ranked_ids is not None else self._offset,
        )

    def row(self) -> Row | None:
        """Execute with limit=1 and return the first ``Row`` or None."""
        items = self.limit(1).rows()
        return items[0] if items else None

    # -- scalar projection terminals --

    def values(self) -> list[Any]:
        """Execute and return flat scalar values (requires ``.scalars()``)."""
        self._check_scalar_mode("values")
        ranked_ids = self._resolve_search_ids()
        if ranked_ids is not None:
            if not ranked_ids:
                return []
            # Fast path: scalar("identifier") returns ranked IDs directly
            if self._scalar_col == "identifier":
                return ranked_ids
        return self._store._execute_scalar_projection(  # noqa: SLF001
            self._cls,
            self._scalar_col,  # pyright: ignore[reportArgumentType]
            self._select_lang,
            filters={} if ranked_ids is not None else self._filters,
            exists_filters=[] if ranked_ids is not None else self._exists_filters,
            map_filters=[] if ranked_ids is not None else self._map_filters,
            from_ids=ranked_ids if ranked_ids is not None else self._from_ids,
            sort_fields=[] if ranked_ids is not None else self._sort_fields,
            limit=None if ranked_ids is not None else self._limit,
            offset=0 if ranked_ids is not None else self._offset,
        )

    def value(self) -> Any | None:
        """Execute with limit=1 and return the first scalar value or None."""
        items = self.limit(1).values()
        return items[0] if items else None

    # -- projection-independent terminals --

    def count(self) -> int:
        """Return the total count without fetching items."""
        return self._store._execute_query(  # noqa: SLF001
            self._cls,
            self._filters,
            self._exists_filters,
            self._map_filters,
            self._from_ids,
            self._text,
            self._hybrid_text,
            self._search_operator,
            self._search_fuzziness,
            self._sort_fields,
            0,
            self._offset,
            [],
            include_rels=self._include_rels,
        ).total

    def exists(self) -> bool:
        """Return True if at least one result matches the filters."""
        if self._text is not None or self._hybrid_text is not None:
            ranked_ids = self._store._ranked_ids_from_search(  # noqa: SLF001
                self._cls,
                self._filters,
                self._exists_filters,
                self._map_filters,
                self._text,
                self._hybrid_text,
                self._search_operator,
                self._search_fuzziness,
                [],
                limit=1,
                offset=0,
            )
            return len(ranked_ids) > 0
        return self._store._execute_exists(  # noqa: SLF001
            self._cls,
            self._filters,
            self._exists_filters,
            self._map_filters,
            self._from_ids,
        )


# ---------------------------------------------------------------------------
# Catalog
# ---------------------------------------------------------------------------


class Catalog:
    """DuckDB-backed catalog store.

    **Persistent catalogs** — use the classmethods for explicit create/open semantics:

    - ``Catalog("my_catalog").open()`` — create a new catalog folder; raises
      ``FileExistsError`` if one already exists there.
    - ``Catalog("my_catalog").open()`` — open an existing catalog; raises
      ``FileNotFoundError`` if no catalog exists there.
    - ``Catalog("my_catalog").open()`` — idempotent, safe default.

    On-disk layout under ``<uri>/``:

    - ``meta.duckdb`` — co-located ``sdmx.*`` (registry) and ``pinax.*``
      (catalog) schemas (Topology B).
    - ``lake.ducklake`` — DuckLake catalog sidecar; ATTACHed as ``lake``
      at open time.
    - ``parquet/`` — DuckLake-managed observation files (DATA_PATH).
    - ``search/`` — optional Lance vector index.

    Observation writes go through ``cat.data.write_observations(...)``;
    no public filesystem-parquet seam.

    **In-memory** (no persistence)::

        store = Catalog()

    **Shared-connection** (sdmxlib ``LocalRegistry`` integration)::

        conn = duckdb.connect("shared.duckdb")
        store = Catalog(conn)
        local = sl.Registry(conn)

    ``Catalog(path)`` is an alias for ``open_or_create`` and is provided
    for convenience and backward compatibility.
    """

    _uri: str | Path
    _conn: duckdb.DuckDBPyConnection | None
    _cursor: duckdb.DuckDBPyConnection | None  # cursor with search_path='pinax'
    _owns_connection: bool
    _bundle_dir: Path | None
    _embedding_model: Any | None
    _embedding_model_name: str | None
    _document_prefix: str
    _query_prefix: str
    _registry: sdmxlib.Registry | None
    _data: sdmxlib.DuckDBDataStore | None

    def __init__(
        self,
        uri: str | Path = ":memory:",
        *,
        embedding_model: Any | None = None,
        document_prefix: str = "",
        query_prefix: str = "",
    ) -> None:
        """Reference a catalog at ``uri``.

        Path-style: construction is cheap — only the URI and configuration
        are stashed. The DuckDB connection opens on :meth:`open` (or
        implicitly when entering a ``with`` block). Use
        :meth:`from_connection` to wrap an existing DuckDB connection
        (e.g. when sharing one with sdmxlib).

        Parameters
        ----------
        uri:
            ``":memory:"`` for an in-memory catalog (default), or a folder
            path for a persistent catalog. Folder mode lays out
            ``<uri>/meta.duckdb`` (sentinel), ``<uri>/lake.ducklake``
            (DuckLake catalog), ``<uri>/parquet/`` (DuckLake DATA_PATH),
            and an optional ``<uri>/search/`` for the Lance index.
        document_prefix:
            Prepended to every document text before embedding in
            ``build_index``. Required for asymmetric models like e5
            (``"passage: "``); leave empty for symmetric models.
        query_prefix:
            Prepended to every query string before embedding in
            ``semantic_search`` / ``hybrid_search``. For e5 use
            ``"query: "``; leave empty for symmetric models.
        """
        self._uri = uri
        self._conn = None
        self._cursor = None
        self._owns_connection = True
        self._bundle_dir = None
        self._embedding_model = embedding_model
        self._embedding_model_name = None
        self._document_prefix = document_prefix
        self._query_prefix = query_prefix
        self._bulk_depth = 0
        self._lance = None
        self._registry = None
        self._data = None

    @property
    def uri(self) -> str | Path:
        """The URI this catalog references. Available before opening."""
        return self._uri

    def open(self) -> Self:
        """Open the underlying DuckDB connection and prepare schemas + Lance.

        Idempotent within a single open/close cycle. Returns ``self`` so the
        call composes with ``with``::

            with Catalog("my_catalog").open() as cat:
                ...
        """
        if self._conn is not None:
            return self
        if str(self._uri) == ":memory:":
            self._conn = duckdb.connect(":memory:")
            self._bundle_dir = None
        else:
            path = Path(self._uri)
            (path / "parquet").mkdir(parents=True, exist_ok=True)
            self._conn = duckdb.connect(str(path / "meta.duckdb"))
            self._bundle_dir = path
        self._owns_connection = True
        if self._embedding_model is not None and self._bundle_dir is None:
            msg = "embedding_model requires a folder-mode catalog (pass a path, not ':memory:')"
            raise ValueError(msg)
        self._cursor = _catalog_schema.create_schema(self._conn)
        # Compose an sdmxlib Registry on the same connection (Topology B —
        # see docs/design/bundle-architecture.md, Decision 7). The pinax
        # schema and the sdmx schema co-exist in one DuckDB file, so cross-
        # schema queries (e.g. join pinax.dataset to sdmx.codelist) work
        # natively without ATTACH plumbing.
        self._registry = sdmxlib.Registry.from_connection(self._conn)
        # ATTACH the DuckLake sidecar (folder mode only — in-memory has no
        # lake). Sidecar layout because DuckDB rejects self-ATTACH; the
        # ducklake catalog file sits next to meta.duckdb so the bundle is
        # still one cleavage point on disk.
        if self._bundle_dir is not None:
            attach_url = f"'ducklake:{self._bundle_dir / 'lake.ducklake'}'"
            attach_options = f"(DATA_PATH '{self._bundle_dir / 'parquet'}/')"
            self._data = sdmxlib.DuckDBDataStore.from_registry(
                self._registry,
                attach={"lake": (attach_url, attach_options)},
                extensions=["ducklake"],
            )
        else:
            # In-memory catalogs have no lake; write_observations is unavailable.
            self._data = sdmxlib.DuckDBDataStore.from_registry(self._registry)
        if self._bundle_dir is not None:
            self._init_lance()
            # Restore embedding metadata written by a previous build_index()
            # so the caller doesn't have to remember which model + prefixes
            # match this index. Missing/malformed metadata leaves the store
            # in its empty default state — callers can still set things
            # explicitly.
            meta = _read_embeddings_meta(self._bundle_dir / "search")
            if meta is not None:
                model = meta.get("model")
                if isinstance(model, str):
                    self._embedding_model_name = model
                doc_pref = meta.get("document_prefix")
                if isinstance(doc_pref, str) and not self._document_prefix:
                    self._document_prefix = doc_pref
                q_pref = meta.get("query_prefix")
                if isinstance(q_pref, str) and not self._query_prefix:
                    self._query_prefix = q_pref
        return self

    @classmethod
    def from_connection(
        cls,
        conn: duckdb.DuckDBPyConnection,
        *,
        embedding_model: Any | None = None,
        document_prefix: str = "",
        query_prefix: str = "",
    ) -> Self:
        """Wrap an existing DuckDB connection.

        The Catalog does NOT take ownership of the connection — closing the
        Catalog leaves the connection open. Use this when the connection is
        shared with another component (e.g. an sdmxlib :class:`Registry`
        co-located in the same DuckDB).

        ``embedding_model`` is rejected here because shared-connection mode
        has no on-disk ``data/`` directory to host the Lance index.
        """
        if embedding_model is not None:
            msg = "from_connection() does not support embedding_model — Lance needs a folder-mode catalog"
            raise ValueError(msg)
        instance = cls.__new__(cls)
        instance._uri = ":connection:"  # noqa: SLF001 — alternate constructor sets private state
        instance._conn = conn  # noqa: SLF001
        instance._owns_connection = False  # noqa: SLF001
        instance._bundle_dir = None  # noqa: SLF001
        instance._embedding_model = None  # noqa: SLF001
        instance._embedding_model_name = None  # noqa: SLF001
        instance._document_prefix = document_prefix  # noqa: SLF001
        instance._query_prefix = query_prefix  # noqa: SLF001
        instance._bulk_depth = 0  # noqa: SLF001
        instance._lance = None  # noqa: SLF001
        instance._cursor = _catalog_schema.create_schema(conn)  # noqa: SLF001
        instance._registry = sdmxlib.Registry.from_connection(conn)  # noqa: SLF001
        # Shared-connection mode: the caller owns any ATTACH plumbing. The
        # DataStore wraps the same connection without applying its own
        # extensions/ATTACH; lake reads/writes only work if the caller has
        # already ATTACHed a ducklake.
        instance._data = sdmxlib.DuckDBDataStore.from_registry(instance._registry)  # noqa: SLF001
        return instance

    def _init_lance(self) -> None:
        """Set up the LanceDB index (called for all folder-mode catalogs).

        Silently skips if lancedb is not installed — search methods will
        raise ``RuntimeError`` when invoked without the index.
        """
        assert self._bundle_dir is not None  # noqa: S101
        try:
            from pinax.store.lance import LanceIndex  # noqa: PLC0415

            self._lance = LanceIndex(self._bundle_dir / "search")
        except ImportError:
            return

    @property
    def connection(self) -> duckdb.DuckDBPyConnection:
        """The underlying DuckDB connection (for sharing with sdmxlib Registry).

        Raises:
            RuntimeError: If the catalog hasn't been opened.
        """
        if self._conn is None:
            msg = (
                f"Catalog({self._uri!r}) is not open. Use it as a context manager "
                "(``with Catalog(uri) as cat: ...``) or call ``.open()`` first."
            )
            raise RuntimeError(msg)
        return self._conn

    @property
    def registry(self) -> sdmxlib.Registry:
        """The co-located :class:`sdmxlib.Registry` (Topology B composition).

        Both the ``pinax.*`` schema and the ``sdmx.*`` schema live in the
        same DuckDB file on the same connection, so cross-schema queries
        and ``SqlRelation`` composition work without ATTACH plumbing.
        Mutations through the registry (``cat.registry.add(codelist)``)
        are visible immediately to pinax queries that join across schemas.

        Raises:
            RuntimeError: If the catalog hasn't been opened.
        """
        if self._registry is None:
            msg = (
                f"Catalog({self._uri!r}) is not open. Use it as a context manager "
                "(``with Catalog(uri) as cat: ...``) or call ``.open()`` first."
            )
            raise RuntimeError(msg)
        return self._registry

    @property
    def embedding_model_name(self) -> str | None:
        """The model id that produced this catalog's vector index, if known.

        Populated either explicitly via ``build_index(model_name=...)`` or by
        reading ``<catalog>/search/embeddings.json`` on ``open()``. Callers
        such as a query-side wrapper can use this to load a matching encoder
        without hard-coding the model name.
        """
        return self._embedding_model_name

    def attach_embedding_model(self, model: Any) -> None:
        """Attach an encoder to a folder-mode store opened from disk.

        Required for :meth:`hybrid_search` and :meth:`semantic_search` on
        stores opened via :meth:`open` / :meth:`open_or_create`.  Those
        constructors restore the *name* of the encoder used at
        ``build_index`` time (from ``<catalog>/search/embeddings.json``)
        but cannot re-instantiate the encoder itself — pinax core has no
        dependency on ``sentence-transformers`` or any specific encoder
        library.

        Pass an object that exposes ``.encode(text) -> Sequence[float]``
        whose model matches :attr:`embedding_model_name`.  The match is
        the caller's responsibility — the encoder name is opaque to
        pinax.

        Example::

            store = Catalog("data/catalog").open()
            if store.embedding_model_name:
                from sentence_transformers import SentenceTransformer

                store.attach_embedding_model(SentenceTransformer(store.embedding_model_name))
        """
        self._embedding_model = model

    @property
    def document_prefix(self) -> str:
        """Prefix prepended to documents at index time (e.g. ``"passage: "``)."""
        return self._document_prefix

    @property
    def query_prefix(self) -> str:
        """Prefix prepended to queries at search time (e.g. ``"query: "``)."""
        return self._query_prefix

    @property
    def cursor(self) -> duckdb.DuckDBPyConnection:
        """A fresh DuckDB cursor with ``search_path='pinax'``.

        Returns a new cursor each call so ad-hoc reads never leave an
        implicit transaction that blocks ``store.transaction()``::

            store.cursor.execute("SELECT identifier FROM dataset WHERE kind = 'open'")
        """
        cur = self.connection.cursor()
        cur.execute("SET search_path = 'pinax'")
        return cur

    @property
    def themes(self) -> ThemesScope:
        """Lazy scope over theme classification schemes: ``store.themes["statcan"]``."""
        return ThemesScope(store=self)

    @property
    def concept_schemes(self) -> ConceptSchemesScope:
        """Lazy scope over SKOS concept schemes: ``store.concept_schemes["uri"]``."""
        return ConceptSchemesScope(store=self)

    # ------------------------------------------------------------------
    # SKOS concept scheme and concept persistence
    # ------------------------------------------------------------------

    def _put_concept_scheme(self, scheme: ConceptScheme) -> None:
        """Persist a ConceptScheme and cascade to its Concept children.

        Upserts the scheme row, replaces top_concept rows, and calls
        ``put_concept()`` for each concept in ``scheme.concepts``.
        """
        self._exec(
            """INSERT INTO concept_scheme (uri, label, definition)
            VALUES (?, ?, ?)
            ON CONFLICT (uri) DO UPDATE SET
                label = excluded.label,
                definition = excluded.definition""",
            [scheme.uri, _istring_to_map(scheme.label), _istring_to_map(scheme.definition)],
        )
        self._exec("DELETE FROM concept_scheme_top_concept WHERE scheme_uri = ?", [scheme.uri])
        if scheme.top_concepts:
            lit = _sql_literal
            vals = ", ".join(f"({lit(scheme.uri)}, {lit(n)})" for n in scheme.top_concepts)
            self._c.execute(f"INSERT INTO concept_scheme_top_concept (scheme_uri, notation) VALUES {vals}")
        for concept in scheme.concepts.values():
            self.put_concept(scheme.uri, concept)

    def get_concept_scheme(self, uri: str) -> ConceptScheme | None:
        """Retrieve a ConceptScheme with its full concepts dict populated."""
        row = self._c.execute("SELECT uri, label, definition FROM concept_scheme WHERE uri = ?", [uri]).fetchone()
        if row is None:
            return None
        label = _map_to_istring(row[1]) or InternationalString()
        definition = _map_to_istring(row[2])

        # Load top_concepts (notations)
        tc_rows = self._c.execute(
            "SELECT notation FROM concept_scheme_top_concept WHERE scheme_uri = ? ORDER BY notation",
            [uri],
        ).fetchall()
        top_concepts = tuple(r[0] for r in tc_rows)

        # Load all concepts in this scheme
        c_rows = self._c.execute(
            """SELECT notation, label, alt_label, definition FROM concept
            WHERE in_scheme = ? ORDER BY notation""",
            [uri],
        ).fetchall()
        concepts: dict[str, Concept] = {}
        for c_row in c_rows:
            notation = c_row[0]
            c_label = _map_to_istring(c_row[1]) or InternationalString()
            c_alt_label = _map_to_istring(c_row[2]) or InternationalString()
            c_definition = _map_to_istring(c_row[3])
            # Load relations for this concept
            concept_uri = f"{uri}/{notation}"
            rel_rows = self._c.execute(
                """SELECT r.relation, c2.notation
                FROM concept_relation r
                JOIN concept c2 ON c2.uri = r.target_uri
                WHERE r.source_uri = ?""",
                [concept_uri],
            ).fetchall()
            broader: list[str] = []
            narrower: list[str] = []
            related: list[str] = []
            for rel_row in rel_rows:
                if rel_row[0] == "broader":
                    broader.append(rel_row[1])
                elif rel_row[0] == "narrower":
                    narrower.append(rel_row[1])
                elif rel_row[0] == "related":
                    related.append(rel_row[1])
            concepts[notation] = Concept(
                notation=notation,
                label=c_label,
                alt_label=c_alt_label,
                definition=c_definition,
                broader=tuple(broader),
                narrower=tuple(narrower),
                related=tuple(related),
            )

        return ConceptScheme(
            uri=uri,
            label=label,
            definition=definition,
            concepts=concepts,
            top_concepts=top_concepts,
        )

    def put_concept(self, scheme_uri: str, concept: Concept) -> None:
        """Persist a single Concept within its scheme.

        The concept URI is derived as ``{scheme_uri}/{concept.notation}``.
        ``broader``/``narrower``/``related`` are notations in the same scheme;
        their URIs are resolved the same way.
        """
        concept_uri = f"{scheme_uri}/{concept.notation}"
        self._exec(
            """INSERT INTO concept (uri, in_scheme, notation, label, alt_label, definition)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT (uri) DO UPDATE SET
                notation = excluded.notation,
                label = excluded.label,
                alt_label = excluded.alt_label,
                definition = excluded.definition""",
            [
                concept_uri,
                scheme_uri,
                concept.notation,
                _istring_to_map(concept.label),
                _istring_to_map(concept.alt_label),
                _istring_to_map(concept.definition),
            ],
        )
        self._exec("DELETE FROM concept_relation WHERE source_uri = ?", [concept_uri])
        lit = _sql_literal
        rel_rows: list[tuple[str, str, str]] = [
            *[(concept_uri, f"{scheme_uri}/{n}", "broader") for n in concept.broader],
            *[(concept_uri, f"{scheme_uri}/{n}", "narrower") for n in concept.narrower],
            *[(concept_uri, f"{scheme_uri}/{n}", "related") for n in concept.related],
        ]
        if rel_rows:
            vals = ", ".join(f"({lit(r[0])}, {lit(r[1])}, {lit(r[2])})" for r in rel_rows)
            self._c.execute(
                f"INSERT INTO concept_relation (source_uri, target_uri, relation) VALUES {vals} ON CONFLICT DO NOTHING"
            )

    def get_concept(self, uri: str) -> Concept | None:
        """Retrieve a single Concept by URI."""
        row = self._c.execute(
            "SELECT notation, label, alt_label, definition FROM concept WHERE uri = ?", [uri]
        ).fetchone()
        if row is None:
            return None
        notation = row[0]
        label = _map_to_istring(row[1]) or InternationalString()
        alt_label = _map_to_istring(row[2]) or InternationalString()
        definition = _map_to_istring(row[3])

        rel_rows = self._c.execute(
            """SELECT r.relation, c2.notation
            FROM concept_relation r
            JOIN concept c2 ON c2.uri = r.target_uri
            WHERE r.source_uri = ?""",
            [uri],
        ).fetchall()
        broader: list[str] = []
        narrower: list[str] = []
        related: list[str] = []
        for rel_row in rel_rows:
            if rel_row[0] == "broader":
                broader.append(rel_row[1])
            elif rel_row[0] == "narrower":
                narrower.append(rel_row[1])
            elif rel_row[0] == "related":
                related.append(rel_row[1])

        return Concept(
            notation=notation,
            label=label,
            alt_label=alt_label,
            definition=definition,
            broader=tuple(broader),
            narrower=tuple(narrower),
            related=tuple(related),
        )

    def __enter__(self) -> Self:
        if self._conn is None:
            self.open()
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def close(self) -> None:
        """Close the database connection (only if this catalog owns it).

        After ``close()``, the catalog can be re-opened with :meth:`open`.
        """
        if self._conn is not None and self._owns_connection:
            self._conn.close()
        self._conn = None
        self._cursor = None
        self._registry = None

    @property
    def _c(self) -> duckdb.DuckDBPyConnection:
        """Internal accessor — return the live cursor or raise a clear error.

        Methods that touch the database route through this so the error
        message points at the lifecycle problem instead of the downstream
        ``AttributeError`` you'd see with a bare ``None``.
        """
        if self._cursor is None:
            msg = (
                f"Catalog({self._uri!r}) is not open. Use it as a context manager "
                "(``with Catalog(uri) as cat: ...``) or call ``.open()`` first."
            )
            raise RuntimeError(msg)
        return self._cursor

    @property
    def bundle_dir(self) -> Path | None:
        """The bundle directory in folder mode, else ``None`` for in-memory.

        Holds ``meta.duckdb``, ``lake.ducklake``, ``parquet/``, and
        optional ``search/``.
        """
        return self._bundle_dir

    @property
    def data(self) -> sdmxlib.DuckDBDataStore:
        """The bundle's data plane.

        A :class:`sdmxlib.DuckDBDataStore` sharing the catalog's DuckDB
        connection, with the DuckLake sidecar ATTACHed as ``lake``
        (folder mode) or unattached (in-memory / shared-connection mode).
        Producers write observations through
        ``cat.data.write_observations(schema, table, source)``; that
        routes through the lake when one is attached.

        Raises:
            RuntimeError: If the catalog hasn't been opened.
        """
        if self._data is None:
            msg = (
                f"Catalog({self._uri!r}) is not open. Use it as a context manager "
                "(``with Catalog(uri) as cat: ...``) or call ``.open()`` first."
            )
            raise RuntimeError(msg)
        return self._data

    def _exec(self, sql: str, params: list[Any] | None = None) -> None:
        """Execute a DDL or DML statement on the catalog cursor."""
        if params is None:
            _ = self._c.execute(sql)
        else:
            _ = self._c.execute(sql, params)

    @contextlib.contextmanager
    def bulk_load(self) -> Generator[Self]:
        """Context manager for high-throughput catalog ingest.

        Raises the WAL auto-checkpoint threshold to 1 GB so DuckDB
        does not checkpoint after every 16 MB of writes, then runs
        a single checkpoint on exit.

        Re-entrant: nested ``bulk_load()`` calls are no-ops — only the
        outermost level controls WAL settings, checkpoint, and index
        rebuild.

        .. code-block:: python

            with store.bulk_load():
                for pid in pids:
                    ingest_statcan_table(store, pid, ...)
            # single checkpoint here
        """
        self._bulk_depth += 1
        if self._bulk_depth == 1:
            self._c.execute("SET wal_autocheckpoint = '1GB'")
        try:
            yield self
        finally:
            self._bulk_depth -= 1
            if self._bulk_depth == 0:
                self._c.execute("SET wal_autocheckpoint = '16MB'")
                self.connection.execute("CHECKPOINT")

    @contextlib.contextmanager
    def transaction(self) -> Generator[Self]:
        """Wrap multiple writes in a single DuckDB transaction.

        Commits on clean exit, rolls back on exception.  Composes with
        ``bulk_load()`` for batched high-throughput ingest::

            with store.bulk_load():
                for batch in batched(datasets, 500):
                    with store.transaction():
                        for ds in batch:
                            store.put(ds)
        """
        self._c.begin()
        try:
            yield self
            self._c.commit()
        except BaseException:
            self._c.rollback()
            raise

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    def put(self, obj: BaseDataset | ConceptScheme | Sequence[BaseDataset | ConceptScheme]) -> None:
        """Add or update a dataset, concept scheme, or list of either.

        Dispatches on type:

        - ``BaseDataset`` (and subclasses) — upserts the dataset record and
          all bridge rows (themes, keywords, distributions, etc.).
        - ``ConceptScheme`` — upserts the scheme and cascades to its concepts.
        - ``list`` / ``Sequence`` — calls ``put()`` for each element.
        """
        if isinstance(obj, (list, tuple)):
            for item in obj:
                self.put(item)
        elif isinstance(obj, ConceptScheme):
            self._put_concept_scheme(obj)
        else:
            ds = cast("BaseDataset", obj)
            dim = self._upsert_dimension_records(ds)
            self._upsert_fact_row(ds, dim)
            self._write_bridge_rows(ds)

    # ------------------------------------------------------------------
    # Semantic & hybrid search
    # ------------------------------------------------------------------

    def semantic_search(
        self,
        text: str,
        *,
        lang: str = "en",
        limit: int = 50,
        offset: int = 0,
    ) -> SearchResult[BaseDataset]:
        """Pure semantic nearest-neighbour search using the vector index.

        Requires the store to have been initialised with an ``embedding_model``.
        """
        if self._lance is None or self._embedding_model is None:
            msg = "semantic_search requires an embedding_model; pass it to Catalog()"
            raise RuntimeError(msg)
        query_vec: list[float] = list(self._embedding_model.encode(self._query_prefix + text))
        all_hits = self._lance.search(query_vec, lang=lang, limit=limit + offset, entity_type=_DATASET_ENTITY_TYPES)
        total = len(all_hits)
        page_hits = all_hits[offset : offset + limit]
        if not page_hits:
            return SearchResult(items=[], total=total, offset=offset)
        identifiers = [h[0] for h in page_hits]
        scores = {h[0]: h[1] for h in page_hits}
        items = self._fetch_by_identifiers(identifiers)
        return SearchResult(items=items, total=total, offset=offset, scores=scores)

    def hybrid_search(
        self,
        text: str,
        *,
        lang: str = "en",
        limit: int = 50,
        offset: int = 0,
        rrf_k: int = 60,
    ) -> SearchResult[BaseDataset]:
        """Hybrid BM25 + semantic search using Reciprocal Rank Fusion.

        Requires the store to have been initialised with an ``embedding_model``.
        """
        if self._lance is None or self._embedding_model is None:
            msg = "hybrid_search requires an embedding_model; pass it to Catalog()"
            raise RuntimeError(msg)
        rrf_scores = self._rrf_rank(text, lang=lang, rrf_k=rrf_k)
        ranked = sorted(rrf_scores, key=lambda i: rrf_scores[i], reverse=True)
        total = len(ranked)
        page_ids = ranked[offset : offset + limit]
        if not page_ids:
            return SearchResult(items=[], total=total, offset=offset)
        items = self._fetch_by_identifiers(page_ids)
        scores = {ident: rrf_scores[ident] for ident in page_ids}
        return SearchResult(items=items, total=total, offset=offset, scores=scores)

    def _rrf_rank(
        self,
        text: str,
        *,
        lang: str = "en",
        rrf_k: int = 60,
        oversample: int = 200,
        operator: str = "or",
        fuzziness: int = 0,
    ) -> dict[str, float]:
        """Compute RRF-merged identifier ranking from vector + BM25 hits."""
        assert self._lance is not None  # noqa: S101
        assert self._embedding_model is not None  # noqa: S101

        query_vec: list[float] = list(self._embedding_model.encode(self._query_prefix + text))
        vec_hits = self._lance.search(query_vec, lang=lang, limit=oversample, entity_type=_DATASET_ENTITY_TYPES)
        vec_rank: dict[str, int] = {ident: i + 1 for i, (ident, _) in enumerate(vec_hits)}

        bm25_hits = self._lance.bm25_search(
            text,
            lang=lang,
            limit=oversample,
            operator=operator,
            fuzziness=fuzziness,
            entity_type=_DATASET_ENTITY_TYPES,
        )
        bm25_rank: dict[str, int] = {ident: i + 1 for i, (ident, _) in enumerate(bm25_hits)}

        all_ids = set(vec_rank) | set(bm25_rank)
        rrf: dict[str, float] = {}
        for ident in all_ids:
            score = 0.0
            if ident in vec_rank:
                score += 1.0 / (rrf_k + vec_rank[ident])
            if ident in bm25_rank:
                score += 1.0 / (rrf_k + bm25_rank[ident])
            rrf[ident] = score

        return rrf

    def _fetch_by_identifiers(self, identifiers: list[str]) -> list[BaseDataset]:
        """Fetch datasets by identifier list, preserving order."""
        if not identifiers:
            return []
        datasets = self._fetch_datasets(identifiers)
        order = {ident: i for i, ident in enumerate(identifiers)}
        return sorted(datasets, key=lambda ds: order.get(ds.identifier, 9999))

    def _collect_search_texts(self) -> list[tuple[str, str, str, str]]:
        """Collect ``(id, kind, lang, text)`` tuples for all datasets.

        Uses a single SQL query with LEFT JOINs instead of per-dataset
        object reconstruction — collapses ~75k round-trips to 1 query.
        """
        db_rows = self._c.execute("""
            SELECT
                d.identifier,
                d.kind,
                d.title,
                d.description,
                LIST(DISTINCT dk.keyword),
                LIST(DISTINCT c.label),
                LIST(DISTINCT dn.label)
            FROM dataset d
            LEFT JOIN dataset_keyword dk ON dk.dataset_id = d.identifier
            LEFT JOIN dataset_theme dt   ON dt.dataset_id = d.identifier
            LEFT JOIN concept c          ON c.uri = dt.concept_uri
            LEFT JOIN dimension_name dn  ON dn.dataset_id = d.identifier
            GROUP BY d.identifier, d.kind, d.title, d.description
        """).fetchall()

        items: list[tuple[str, str, str, str]] = []
        for ident, kind, title_map, desc_map, kw_maps, theme_maps, dim_maps in db_rows:
            items.extend(self._texts_for_row(ident, kind, title_map, desc_map, kw_maps, theme_maps, dim_maps))
        return items

    @staticmethod
    def _texts_for_row(
        ident: str,
        kind: str,
        title_map: dict[str, str] | None,
        desc_map: dict[str, str] | None,
        kw_maps: list[dict[str, str]] | None,
        theme_maps: list[dict[str, str]] | None,
        dim_maps: list[dict[str, str]] | None,
    ) -> list[tuple[str, str, str, str]]:
        """Build ``(id, kind, lang, text)`` tuples for one dataset row."""
        langs = set(title_map or {}) | set(desc_map or {})
        if not langs:
            langs = {"en"}
        result: list[tuple[str, str, str, str]] = []
        for lang in sorted(langs):
            parts = [
                (title_map or {}).get(lang, ""),
                (desc_map or {}).get(lang, ""),
            ]
            parts.extend(m[lang] for m in kw_maps or [] if m and lang in m)
            parts.extend(m[lang] for m in theme_maps or [] if m and lang in m)
            parts.extend(m[lang] for m in dim_maps or [] if m and lang in m)
            text = " ".join(p for p in parts if p)
            if text:
                result.append((ident, kind, lang, text))
        return result

    def _collect_code_texts(self, *, max_codes_per_codelist: int = 500) -> list[dict[str, Any]]:
        """Collect LanceDB row dicts for individual SDMX codes (one per language).

        Joins ``dataset`` -> ``sdmx.dataflow`` -> ``sdmx.dsd_component`` ->
        ``sdmx.code`` to emit one search row per (dataset, dimension, code,
        language).  Each row's ``text`` is formatted as
        ``"{dataset_title} | {dimension_label}: {code_label}"`` — proven
        effective for RAG retrieval in sdmx-ai — and the row also carries
        the structured ``dimension_id`` / ``dimension_label`` / ``code_id`` /
        ``code_label`` fields so callers don't have to re-parse the joined
        text (#83).

        The returned dict shape:
            ``{"id", "entity_type"="code", "lang", "text",
               "dimension_id", "dimension_label", "code_id", "code_label"}``

        Codelists with more than *max_codes_per_codelist* entries are skipped
        to avoid bloating the index with high-cardinality dimensions (e.g.
        postal codes, commodity codes).
        """
        # Guard: sdmx schema may not exist if no SDMX data has been ingested
        has_sdmx = self._c.execute(
            "SELECT COUNT(*) FROM information_schema.schemata WHERE schema_name = 'sdmx'"
        ).fetchone()
        if not has_sdmx or has_sdmx[0] == 0:
            return []

        rows = self._c.execute(
            """
            WITH codelist_size AS (
                SELECT codelist_urn, COUNT(*) AS n
                FROM sdmx.code
                GROUP BY codelist_urn
            )
            SELECT
                d.identifier,
                d.title,
                dc.component_id                    AS dimension_id,
                COALESCE(con.name, cl_text.label)  AS dim_label,
                c.code_id                          AS code_id,
                c.name                             AS code_label
            FROM dataset d
            JOIN sdmx.dataflow df          ON df.urn = d.sdmx_dataflow_urn
            JOIN sdmx.dsd_component dc     ON dc.dsd_urn = df.dsd_urn
                                           AND dc.component_type = 'Dimension'
            JOIN codelist_size cs           ON cs.codelist_urn = dc.codelist_urn
            JOIN sdmx.code c               ON c.codelist_urn = dc.codelist_urn
            LEFT JOIN sdmx.concept con     ON con.concept_urn = dc.concept_urn
            LEFT JOIN (
                SELECT owner_urn, MAP_FROM_ENTRIES(LIST({k: lang, v: text})) AS label
                FROM sdmx.localized_text
                WHERE field = 'name'
                GROUP BY owner_urn
            ) cl_text ON cl_text.owner_urn = dc.codelist_urn
            WHERE d.sdmx_dataflow_urn IS NOT NULL
              AND cs.n <= ?
            """,
            [max_codes_per_codelist],
        ).fetchall()

        items: list[dict[str, Any]] = []
        for ident, title_map, dim_id, dim_label_map, code_id, code_label_map in rows:
            # Determine languages from the dataset title
            langs = set(title_map or {})
            if not langs:
                langs = {"en"}
            for lang in sorted(langs):
                ds_title = (title_map or {}).get(lang, "")
                dim_label = (dim_label_map or {}).get(lang, "") if dim_label_map else ""
                code_label = (code_label_map or {}).get(lang, "") if code_label_map else ""
                if not code_label:
                    continue
                text = f"{ds_title} | {dim_label}: {code_label}" if dim_label else f"{ds_title} | {code_label}"
                items.append(
                    {
                        "id": ident,
                        "entity_type": "code",
                        "lang": lang,
                        "text": text,
                        "dimension_id": dim_id or "",
                        "dimension_label": dim_label,
                        "code_id": code_id or "",
                        "code_label": code_label,
                    }
                )
        return items

    def build_index(
        self,
        embedding_model: Any = None,
        progress: Callable[[int, int], None] | None = None,
        *,
        include_codes: bool = True,
        embed_codes: bool = False,
        max_codes_per_codelist: int = 500,
        document_prefix: str | None = None,
        query_prefix: str | None = None,
        model_name: str | None = None,
    ) -> int:
        """Re-index all datasets for search and optionally build ANN vectors.

        If *embedding_model* is provided it is stored for future vector
        operations.  Safe to call multiple times.

        Uses batch encoding (256 texts per call) and bulk LanceDB writes
        for efficient full rebuilds.

        Parameters:
            embedding_model: Optional sentence-transformer-style model.
            progress: Optional ``(current, total)`` callback invoked after
                text collection and after each encoding batch. When provided,
                the model's internal progress bar is suppressed.
            include_codes: Whether to index individual SDMX codes alongside
                dataset-level text. Defaults to True. Code rows are still
                BM25-searchable via ``search_codes()`` even when
                ``embed_codes=False``.
            embed_codes: Whether to compute embeddings for code rows. Defaults
                to False — embedding every code in a 25k-dataset catalog
                with an e5-family model can take hours, but BM25 over
                short controlled-vocabulary code labels is usually
                sufficient. Set to True if you need vector search over
                individual codes (#84).
            max_codes_per_codelist: Skip codelists with more entries than this
                to avoid bloating the index. Defaults to 500.
            document_prefix: Override the store's document prefix for this
                build. For e5-family models pass ``"passage: "``. When
                ``None`` (default), the value from ``__init__`` is used.
            query_prefix: Override the store's query prefix going forward.
                For e5-family models pass ``"query: "``. When ``None``
                (default), the value from ``__init__`` is preserved.
            model_name: Hugging Face / SentenceTransformers model id used to
                produce the embeddings (e.g. ``"intfloat/multilingual-e5-base"``).
                When provided, persisted to ``<catalog>/search/embeddings.json``
                so a later ``Catalog.open()`` can recover which model
                belongs with this index.

        Returns:
            Number of datasets indexed.
        """
        if embedding_model is not None:
            self._embedding_model = embedding_model
        if document_prefix is not None:
            self._document_prefix = document_prefix
        if query_prefix is not None:
            self._query_prefix = query_prefix
        if model_name is not None:
            self._embedding_model_name = model_name
        if self._lance is None:
            self._init_lance()
        assert self._lance is not None  # noqa: S101

        dataset_items = self._collect_search_texts()
        code_rows = self._collect_code_texts(max_codes_per_codelist=max_codes_per_codelist) if include_codes else []
        total = len(dataset_items) + len(code_rows)
        if progress is not None:
            progress(0, total)

        # Build dataset rows first so PyArrow infers ``list[float]`` for
        # the embedding column when a model is configured; code rows can
        # then safely carry ``None`` when embed_codes=False.
        dataset_rows = self._build_dataset_lance_rows(dataset_items, progress=progress)
        self._attach_code_embeddings(code_rows, embed_codes=embed_codes, progress=progress)

        self._lance.add_bulk(dataset_rows + code_rows)
        self._lance.build_index()
        if progress is not None:
            progress(total, total)
        self._persist_embeddings_meta()
        n_datasets = self._c.execute("SELECT COUNT(*) FROM dataset").fetchone()
        return int(n_datasets[0]) if n_datasets else 0

    _EMPTY_CODE_FIELDS: ClassVar[dict[str, str]] = {
        "dimension_id": "",
        "dimension_label": "",
        "code_id": "",
        "code_label": "",
    }

    def _build_dataset_lance_rows(
        self,
        dataset_items: list[tuple[str, str, str, str]],
        *,
        progress: Callable[[int, int], None] | None,
    ) -> list[dict[str, Any]]:
        """Materialize dataset-level LanceDB rows, optionally embedded."""
        if self._embedding_model is not None:
            rows = self._batch_encode(dataset_items, progress=progress)
            for row in rows:
                row.update(self._EMPTY_CODE_FIELDS)
            return rows
        return [
            {
                "id": item[0],
                "entity_type": item[1],
                "lang": item[2],
                "text": item[3],
                **self._EMPTY_CODE_FIELDS,
            }
            for item in dataset_items
        ]

    def _attach_code_embeddings(
        self,
        code_rows: list[dict[str, Any]],
        *,
        embed_codes: bool,
        progress: Callable[[int, int], None] | None,
    ) -> None:
        """Populate the ``embedding`` column on *code_rows* in place.

        - No model configured → leave rows alone (no embedding column).
        - Model + ``embed_codes=True`` → encode each code row's text.
        - Model + ``embed_codes=False`` → set ``embedding=None`` so the
          row schema lines up with the dataset rows (#84).
        """
        if not code_rows or self._embedding_model is None:
            return
        if embed_codes:
            code_items = [(r["id"], r["entity_type"], r["lang"], r["text"]) for r in code_rows]
            encoded = self._batch_encode(code_items, progress=progress)
            for row, enc in zip(code_rows, encoded, strict=True):
                row["embedding"] = enc["embedding"]
            return
        for row in code_rows:
            row["embedding"] = None

    def _persist_embeddings_meta(self) -> None:
        """Write the ``embeddings.json`` sidecar after a successful build.

        No-op for in-memory catalogs or when no model name was supplied —
        without a name there's nothing useful for ``open()`` to recover.
        """
        if self._bundle_dir is None or self._embedding_model_name is None:
            return
        _write_embeddings_meta(
            self._bundle_dir / "search",
            model_name=self._embedding_model_name,
            document_prefix=self._document_prefix,
            query_prefix=self._query_prefix,
        )

    def _batch_encode(
        self,
        items: list[tuple[str, str, str, str]],
        progress: Callable[[int, int], None] | None = None,
    ) -> list[dict[str, Any]]:
        """Batch-encode texts and return LanceDB rows with embeddings.

        Batch size defaults to 256 and can be overridden via the
        ``PINAX_EMBED_BATCH_SIZE`` env var — useful on hardware with
        more GPU/unified memory than a typical CI machine.
        """
        batch_size = _embed_batch_size()
        total = len(items)
        rows: list[dict[str, Any]] = []
        for i in range(0, total, batch_size):
            batch = items[i : i + batch_size]
            assert self._embedding_model is not None  # noqa: S101
            prefix = self._document_prefix
            texts = [prefix + item[3] for item in batch] if prefix else [item[3] for item in batch]
            if progress is not None:
                try:
                    vecs = self._embedding_model.encode(texts, show_progress_bar=False)
                except TypeError:
                    vecs = self._embedding_model.encode(texts)
            else:
                vecs = self._embedding_model.encode(texts)
            rows.extend(
                {"id": item[0], "entity_type": item[1], "lang": item[2], "text": item[3], "embedding": vec}
                for item, vec in zip(batch, vecs, strict=True)
            )
            if progress is not None:
                progress(min(i + batch_size, total), total)
        return rows

    def _upsert_dimension_records(self, dataset: BaseDataset) -> _DimensionIds:
        """Upsert agents, contacts, frequencies, and licences.

        Theme/subject/type concepts are NOT upserted here — they are citations
        from the dataset to externally-managed ConceptScheme artefacts.
        """
        ag_id: str | None = None
        if dataset.publisher is not None:
            ag_id = _agent_id(dataset.publisher)
            self._exec(
                "INSERT INTO agent (id, name, type, homepage)"
                " VALUES (?, ?, ?, ?)"
                " ON CONFLICT (id) DO UPDATE SET"
                " name = excluded.name, type = excluded.type, homepage = excluded.homepage",
                [ag_id, _istring_to_map(dataset.publisher.name), dataset.publisher.type, dataset.publisher.homepage],
            )

        creator_id: str | None = None
        if dataset.creator is not None:
            creator_id = _agent_id(dataset.creator)
            self._exec(
                "INSERT INTO agent (id, name, type, homepage)"
                " VALUES (?, ?, ?, ?)"
                " ON CONFLICT (id) DO UPDATE SET"
                " name = excluded.name, type = excluded.type, homepage = excluded.homepage",
                [creator_id, _istring_to_map(dataset.creator.name), dataset.creator.type, dataset.creator.homepage],
            )

        ct_id: str | None = None
        if dataset.contact_point is not None:
            ct_id = _contact_id(dataset.contact_point)
            self._exec(
                "INSERT INTO contact (id, name, email, phone, url)"
                " VALUES (?, ?, ?, ?, ?)"
                " ON CONFLICT (id) DO UPDATE SET"
                " name = excluded.name, email = excluded.email,"
                " phone = excluded.phone, url = excluded.url",
                [
                    ct_id,
                    _istring_to_map(dataset.contact_point.name),
                    dataset.contact_point.email,
                    dataset.contact_point.phone,
                    dataset.contact_point.url,
                ],
            )

        freq_id: str | None = None
        if dataset.frequency is not None:
            freq_id = dataset.frequency.id
            self._exec(
                "INSERT INTO frequency (id, label) VALUES (?, ?) ON CONFLICT (id) DO UPDATE SET label = excluded.label",
                [freq_id, _istring_to_map(dataset.frequency.label)],
            )

        lic_id: str | None = None
        if dataset.licence is not None:
            lic_id = dataset.licence.id
            self._exec(
                "INSERT INTO licence (id, label, uri) VALUES (?, ?, ?)"
                " ON CONFLICT (id) DO UPDATE SET label = excluded.label, uri = excluded.uri",
                [lic_id, _istring_to_map(dataset.licence.label), dataset.licence.uri],
            )

        return _DimensionIds(
            publisher=ag_id,
            creator=creator_id,
            contact=ct_id,
            frequency=freq_id,
            licence=lic_id,
        )

    def _upsert_fact_row(self, dataset: BaseDataset, dim: _DimensionIds) -> None:
        """Upsert the main dataset fact row."""
        # Variant-specific fields
        num_series: int | None = None
        sdmx_dataflow_urn: str | None = None
        measure_dim: str | None = None
        sample_size: int | None = None
        universe: str | None = None
        collection_method: str | None = None
        anonymization: str | None = None
        survey_id: str | None = None
        crs: str | None = None
        spatial_resolution: str | None = None
        scale: str | None = None
        doi: str | None = None
        isbn: str | None = None
        publication_type: str | None = None
        pages: int | None = None
        series_title: dict[str, str] | None = None

        if isinstance(dataset, AggregateDataset):
            num_series = dataset.num_series
            sdmx_dataflow_urn = dataset.sdmx_dataflow_urn
            measure_dim = dataset.measure_dim
        elif isinstance(dataset, MicrodataDataset):
            sample_size = dataset.sample_size
            universe = dataset.universe
            collection_method = dataset.collection_method
            anonymization = dataset.anonymization
            survey_id = dataset.survey_id
        elif isinstance(dataset, GeospatialDataset):
            crs = dataset.crs
            spatial_resolution = dataset.spatial_resolution
            scale = dataset.scale
        elif isinstance(dataset, PublicationDataset):
            doi = dataset.doi
            isbn = dataset.isbn
            publication_type = dataset.publication_type
            pages = dataset.pages
            series_title = _istring_to_map(dataset.series_title)

        temporal_start: datetime | None = None
        temporal_end: datetime | None = None
        if dataset.temporal_coverage is not None:
            temporal_start = dataset.temporal_coverage.start
            temporal_end = dataset.temporal_coverage.end

        extras_map = dataset.extras or None
        language_list = dataset.language or None

        dataset_type_uri = dataset.dataset_type.uri if dataset.dataset_type is not None else None

        self._exec(
            """INSERT INTO dataset (
                identifier, kind, title, description, version_notes,
                publisher_id, creator_id, contact_id, frequency_id, licence_id,
                temporal_start, temporal_end, status, access_rights,
                issued, modified, landing_page, version, language,
                num_series, sdmx_dataflow_urn, measure_dim,
                sample_size, universe, collection_method, anonymization, survey_id,
                crs, spatial_resolution, scale,
                doi, isbn, publication_type, pages, series_title,
                dataset_type,
                extras
            ) VALUES (
                ?, ?, ?, ?, ?,
                ?, ?, ?, ?, ?,
                ?, ?, ?, ?,
                ?, ?, ?, ?, ?,
                ?, ?, ?,
                ?, ?, ?, ?, ?,
                ?, ?, ?,
                ?, ?, ?, ?, ?,
                ?,
                ?
            )
            ON CONFLICT (identifier) DO UPDATE SET
                kind = excluded.kind,
                title = excluded.title,
                description = excluded.description,
                version_notes = excluded.version_notes,
                publisher_id = excluded.publisher_id,
                creator_id = excluded.creator_id,
                contact_id = excluded.contact_id,
                frequency_id = excluded.frequency_id,
                licence_id = excluded.licence_id,
                temporal_start = excluded.temporal_start,
                temporal_end = excluded.temporal_end,
                status = excluded.status,
                access_rights = excluded.access_rights,
                issued = excluded.issued,
                modified = excluded.modified,
                landing_page = excluded.landing_page,
                version = excluded.version,
                language = excluded.language,
                num_series = excluded.num_series,
                sdmx_dataflow_urn = excluded.sdmx_dataflow_urn,
                measure_dim = excluded.measure_dim,
                sample_size = excluded.sample_size,
                universe = excluded.universe,
                collection_method = excluded.collection_method,
                anonymization = excluded.anonymization,
                survey_id = excluded.survey_id,
                crs = excluded.crs,
                spatial_resolution = excluded.spatial_resolution,
                scale = excluded.scale,
                doi = excluded.doi,
                isbn = excluded.isbn,
                publication_type = excluded.publication_type,
                pages = excluded.pages,
                series_title = excluded.series_title,
                dataset_type = excluded.dataset_type,
                extras = excluded.extras
            """,
            [
                dataset.identifier,
                dataset.kind,
                _istring_to_map(dataset.title),
                _istring_to_map(dataset.description),
                _istring_to_map(dataset.version_notes),
                dim.publisher,
                dim.creator,
                dim.contact,
                dim.frequency,
                dim.licence,
                temporal_start,
                temporal_end,
                dataset.status,
                dataset.access_rights,
                dataset.issued,
                dataset.modified,
                dataset.landing_page,
                dataset.version,
                language_list,
                num_series,
                sdmx_dataflow_urn,
                measure_dim,
                sample_size,
                universe,
                collection_method,
                anonymization,
                survey_id,
                crs,
                spatial_resolution,
                scale,
                doi,
                isbn,
                publication_type,
                pages,
                series_title,
                dataset_type_uri,
                extras_map,
            ],
        )

    def _write_bridge_rows(self, dataset: BaseDataset) -> None:  # noqa: C901, PLR0912
        """Write bridge rows for themes, keywords, spatial, distributions, etc."""
        ds_id = dataset.identifier
        lit = _sql_literal

        # Theme citations (concept URIs only — concepts owned by ConceptScheme)
        self._exec("DELETE FROM dataset_theme WHERE dataset_id = ?", [ds_id])
        if dataset.themes:
            vals = ", ".join(f"({lit(ds_id)}, {lit(t.uri)})" for t in dataset.themes)
            self._c.execute(f"INSERT INTO dataset_theme (dataset_id, concept_uri) VALUES {vals}")

        # Subject citations
        self._exec("DELETE FROM dataset_subject WHERE dataset_id = ?", [ds_id])
        if dataset.subject:
            vals = ", ".join(f"({lit(ds_id)}, {lit(s.uri)})" for s in dataset.subject)
            self._c.execute(f"INSERT INTO dataset_subject (dataset_id, concept_uri) VALUES {vals}")

        # Keywords (MAP column, with ordinal) — batch VALUES insert
        self._exec("DELETE FROM dataset_keyword WHERE dataset_id = ?", [ds_id])
        if dataset.keywords:
            vals = ", ".join(
                f"({lit(ds_id)}, {lit(_istring_to_map(kw))}, {lit(i)})" for i, kw in enumerate(dataset.keywords)
            )
            self._c.execute(f"INSERT INTO dataset_keyword (dataset_id, keyword, ordinal) VALUES {vals}")

        # Spatial coverage (MAP label, with ordinal) — batch VALUES insert
        self._exec("DELETE FROM dataset_spatial WHERE dataset_id = ?", [ds_id])
        if dataset.spatial_coverage:
            vals = ", ".join(
                f"({lit(ds_id)}, {lit(_istring_to_map(sc.label))}, {lit(sc.uri)},"
                f" {lit(sc.bbox[0] if sc.bbox else None)}, {lit(sc.bbox[1] if sc.bbox else None)},"
                f" {lit(sc.bbox[2] if sc.bbox else None)}, {lit(sc.bbox[3] if sc.bbox else None)}, {lit(i)})"
                for i, sc in enumerate(dataset.spatial_coverage)
            )
            self._c.execute(
                f"INSERT INTO dataset_spatial"
                f" (dataset_id, label, uri, bbox_west, bbox_south, bbox_east, bbox_north, ordinal)"
                f" VALUES {vals}"
            )

        # Standards
        self._exec("DELETE FROM dataset_standard WHERE dataset_id = ?", [ds_id])
        for std in dataset.conforms_to:
            self._exec(
                "INSERT INTO standard (id, label, uri) VALUES (?, ?, ?)"
                " ON CONFLICT (id) DO UPDATE SET label = excluded.label, uri = excluded.uri",
                [std.id, _istring_to_map(std.label), std.uri],
            )
            self._exec(
                "INSERT INTO dataset_standard (dataset_id, standard_id) VALUES (?, ?) ON CONFLICT DO NOTHING",
                [ds_id, std.id],
            )

        # Distributions
        self._exec("DELETE FROM distribution WHERE dataset_id = ?", [ds_id])
        for dist in dataset.distributions:
            lic_id: str | None = None
            if dist.licence is not None:
                lic_id = dist.licence.id
            svc_id: str | None = None
            if dist.access_service is not None:
                svc = dist.access_service
                svc_id = svc.id
                self._exec(
                    "INSERT INTO data_service (id, title, description, endpoint_url)"
                    " VALUES (?, ?, ?, ?)"
                    " ON CONFLICT (id) DO UPDATE SET"
                    " title = excluded.title, description = excluded.description,"
                    " endpoint_url = excluded.endpoint_url",
                    [svc.id, _istring_to_map(svc.title), _istring_to_map(svc.description), svc.endpoint_url],
                )
                # service_dataset bridge
                self._exec(
                    "INSERT INTO service_dataset (service_id, dataset_id) VALUES (?, ?) ON CONFLICT DO NOTHING",
                    [svc.id, ds_id],
                )
            self._exec(
                """INSERT INTO distribution
                    (id, dataset_id, title, description, access_url, download_url,
                     media_type, format, byte_size, issued, modified, licence_id,
                     service_id, distribution_type)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT (id) DO UPDATE SET
                    dataset_id = excluded.dataset_id, title = excluded.title,
                    description = excluded.description,
                    access_url = excluded.access_url, download_url = excluded.download_url,
                    media_type = excluded.media_type, format = excluded.format,
                    byte_size = excluded.byte_size, issued = excluded.issued,
                    modified = excluded.modified, licence_id = excluded.licence_id,
                    service_id = excluded.service_id,
                    distribution_type = excluded.distribution_type""",
                [
                    dist.id,
                    ds_id,
                    _istring_to_map(dist.title),
                    _istring_to_map(dist.description),
                    dist.access_url,
                    dist.download_url,
                    dist.media_type,
                    dist.format,
                    dist.byte_size,
                    dist.issued,
                    dist.modified,
                    lic_id,
                    svc_id,
                    dist.distribution_type,
                ],
            )

        # Quality annotations
        self._exec("DELETE FROM quality_annotation WHERE dataset_id = ?", [ds_id])
        for i, qa in enumerate(dataset.quality_annotations):
            self._exec(
                "INSERT INTO quality_annotation (dataset_id, ordinal, dimension, label, body) VALUES (?, ?, ?, ?, ?)",
                [ds_id, i, qa.dimension, _istring_to_map(qa.label), _istring_to_map(qa.body)],
            )

        # Provenance
        self._exec("DELETE FROM provenance WHERE dataset_id = ?", [ds_id])
        for i, prov in enumerate(dataset.provenance):
            self._exec(
                "INSERT INTO provenance (dataset_id, ordinal, label, uri) VALUES (?, ?, ?, ?)",
                [ds_id, i, _istring_to_map(prov.label), prov.uri],
            )

        # Dimension names (AggregateDataset)
        self._exec("DELETE FROM dimension_name WHERE dataset_id = ?", [ds_id])
        if isinstance(dataset, AggregateDataset) and dataset.dimension_names:
            for i, dim_label in enumerate(dataset.dimension_names):
                self._exec(
                    "INSERT INTO dimension_name (dataset_id, ordinal, label) VALUES (?, ?, ?)",
                    [ds_id, i, _istring_to_map(dim_label)],
                )

        # Variables (MicrodataDataset)
        self._exec("DELETE FROM variable WHERE dataset_id = ?", [ds_id])
        if isinstance(dataset, MicrodataDataset):
            for var in dataset.variables:
                self._exec(
                    """INSERT INTO variable
                        (dataset_id, variable_id, label, description, value_type,
                         classification_id, universe, question_text, valid_range, derivation)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    [
                        ds_id,
                        var.id,
                        _istring_to_map(var.label),
                        _istring_to_map(var.description),
                        var.value_type,
                        var.classification_id,
                        var.universe,
                        var.question_text,
                        var.valid_range,
                        var.derivation,
                    ],
                )

        # Feature types (GeospatialDataset)
        self._exec("DELETE FROM feature_type WHERE dataset_id = ?", [ds_id])
        if isinstance(dataset, GeospatialDataset):
            for ft in dataset.feature_types:
                self._exec(
                    "INSERT INTO feature_type (dataset_id, type_name) VALUES (?, ?)",
                    [ds_id, ft],
                )

        # Authors (PublicationDataset)
        self._exec("DELETE FROM author WHERE dataset_id = ?", [ds_id])
        if isinstance(dataset, PublicationDataset):
            for i, name in enumerate(dataset.authors):
                self._exec(
                    "INSERT INTO author (dataset_id, ordinal, name) VALUES (?, ?, ?)",
                    [ds_id, i, name],
                )

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------

    def get[T: BaseDataset](self, cls: type[T], identifier: str) -> T | None:
        """Retrieve a single dataset by identifier, narrowed to cls.

        Returns None if the identifier does not exist or the stored type
        is not compatible with cls.
        """
        row = self._c.execute(
            f"SELECT {self._DATASET_COLUMNS} FROM dataset WHERE identifier = ?",
            [identifier],
        ).fetchone()
        if row is None:
            return None
        ds = self._reconstruct_dataset(row)
        if not isinstance(ds, cls):
            return None
        return ds  # pyright: ignore[reportReturnType]

    def _reconstruct_dataset(self, row: tuple[Any, ...]) -> BaseDataset:
        """Reconstruct a BaseDataset subclass from a dataset table row."""
        (
            identifier,
            kind,
            title_map,
            desc_map,
            vnotes_map,
            publisher_id,
            creator_id,
            contact_id,
            frequency_id,
            licence_id,
            temporal_start,
            temporal_end,
            status,
            access_rights,
            issued,
            modified,
            landing_page,
            version,
            language,
            num_series,
            sdmx_dataflow_urn,
            measure_dim,
            sample_size,
            universe,
            collection_method,
            anonymization,
            survey_id,
            crs,
            spatial_resolution,
            scale,
            doi,
            isbn,
            publication_type,
            pages,
            series_title_map,
            dataset_type_uri,
            extras_map,
        ) = row

        title = _map_to_istring(title_map) or InternationalString()
        description = _map_to_istring(desc_map) or InternationalString()
        version_notes = _map_to_istring(vnotes_map)
        extras = dict(extras_map) if extras_map else {}

        # Read related entities
        publisher = self._read_agent(publisher_id) if publisher_id else None
        creator = self._read_agent(creator_id) if creator_id else None
        contact_point = self._read_contact(contact_id) if contact_id else None
        frequency = self._read_frequency(frequency_id) if frequency_id else None
        licence = self._read_licence(licence_id) if licence_id else None
        themes = self._read_themes(identifier)
        subject = self._read_subjects(identifier)
        dataset_type = self._read_concept_ref(dataset_type_uri) if dataset_type_uri else None
        keywords = self._read_keywords(identifier)
        spatial_coverage = self._read_spatial(identifier)
        distributions = self._read_distributions(identifier)
        conforms_to = self._read_standards(identifier)
        quality_annotations = self._read_quality_annotations(identifier)
        provenance = self._read_provenance(identifier)

        temporal_coverage: TemporalCoverage | None = None
        if temporal_start is not None or temporal_end is not None:
            temporal_coverage = TemporalCoverage(start=temporal_start, end=temporal_end)

        lang_list: list[str] = list(language) if language else []

        # Base kwargs common to all variants
        base_kwargs: dict[str, Any] = {
            "identifier": identifier,
            "title": title,
            "description": description,
            "publisher": publisher,
            "creator": creator,
            "contact_point": contact_point,
            "keywords": keywords,
            "themes": themes,
            "subject": subject,
            "dataset_type": dataset_type,
            "issued": issued,
            "modified": modified,
            "frequency": frequency,
            "spatial_coverage": spatial_coverage,
            "temporal_coverage": temporal_coverage,
            "distributions": distributions,
            "licence": licence,
            "language": lang_list,
            "landing_page": landing_page,
            "version": version,
            "version_notes": version_notes,
            "conforms_to": conforms_to,
            "access_rights": access_rights,
            "status": status,
            "provenance": provenance,
            "quality_annotations": quality_annotations,
            "extras": extras,
        }

        if kind == "aggregate":
            dimension_names = self._read_dimension_names(identifier)
            return AggregateDataset(
                **base_kwargs,
                dimension_names=dimension_names,
                num_series=num_series,
                sdmx_dataflow_urn=sdmx_dataflow_urn,
                measure_dim=measure_dim,
            )
        if kind == "microdata":
            variables = self._read_variables(identifier)
            return MicrodataDataset(
                **base_kwargs,
                variables=variables,
                sample_size=sample_size,
                universe=universe,
                collection_method=collection_method,
                anonymization=anonymization,
                survey_id=survey_id,
            )
        if kind == "geospatial":
            feature_types = self._read_feature_types(identifier)
            return GeospatialDataset(
                **base_kwargs,
                crs=crs,
                spatial_resolution=spatial_resolution,
                feature_types=feature_types,
                scale=scale,
            )
        if kind == "publication":
            authors = self._read_authors(identifier)
            series_title = _map_to_istring(series_title_map)
            return PublicationDataset(
                **base_kwargs,
                authors=authors,
                doi=doi,
                isbn=isbn,
                publication_type=publication_type,
                pages=pages,
                series_title=series_title,
            )
        # Default: OpenDataset (also handles legacy "Dataset" kind)
        return OpenDataset(**base_kwargs)

    # -- Entity readers --

    def _read_agent(self, agent_id: str) -> Agent | None:
        row = self._c.execute("SELECT id, name, type, homepage FROM agent WHERE id = ?", [agent_id]).fetchone()
        if row is None:
            return None
        return Agent(id=row[0], name=_map_to_istring(row[1]) or InternationalString(), type=row[2], homepage=row[3])

    def _read_contact(self, contact_id: str) -> ContactPoint | None:
        row = self._c.execute("SELECT id, name, email, phone, url FROM contact WHERE id = ?", [contact_id]).fetchone()
        if row is None:
            return None
        return ContactPoint(name=_map_to_istring(row[1]), email=row[2], phone=row[3], url=row[4])

    def _read_frequency(self, freq_id: str) -> Frequency | None:
        row = self._c.execute("SELECT id, label FROM frequency WHERE id = ?", [freq_id]).fetchone()
        if row is None:
            return None
        return Frequency(id=row[0], label=_map_to_istring(row[1]) or InternationalString())

    def _read_licence(self, lic_id: str) -> LicenceDocument | None:
        row = self._c.execute("SELECT id, label, uri FROM licence WHERE id = ?", [lic_id]).fetchone()
        if row is None:
            return None
        return LicenceDocument(id=row[0], label=_map_to_istring(row[1]) or InternationalString(), uri=row[2])

    def _read_concept_ref(self, uri: str) -> ConceptRef:
        """Build a ConceptRef for a single URI, hydrating label/notation from store if available."""
        row = self._c.execute("SELECT notation, label, in_scheme FROM concept WHERE uri = ?", [uri]).fetchone()
        if row is None:
            return ConceptRef(uri=uri)
        return ConceptRef(
            uri=uri,
            scheme_uri=row[2],
            notation=row[0],
            label=_map_to_istring(row[1]) or InternationalString(),
        )

    def _read_themes(self, dataset_id: str) -> list[ConceptRef]:
        rows = self._c.execute(
            """SELECT dt.concept_uri, c.notation, c.label, c.in_scheme
            FROM dataset_theme dt
            LEFT JOIN concept c ON c.uri = dt.concept_uri
            WHERE dt.dataset_id = ?""",
            [dataset_id],
        ).fetchall()
        return [
            ConceptRef(
                uri=r[0],
                notation=r[1],
                label=_map_to_istring(r[2]) or InternationalString(),
                scheme_uri=r[3],
            )
            for r in rows
        ]

    def _read_subjects(self, dataset_id: str) -> list[ConceptRef]:
        rows = self._c.execute(
            """SELECT ds.concept_uri, c.notation, c.label, c.in_scheme
            FROM dataset_subject ds
            LEFT JOIN concept c ON c.uri = ds.concept_uri
            WHERE ds.dataset_id = ?""",
            [dataset_id],
        ).fetchall()
        return [
            ConceptRef(
                uri=r[0],
                notation=r[1],
                label=_map_to_istring(r[2]) or InternationalString(),
                scheme_uri=r[3],
            )
            for r in rows
        ]

    def _read_keywords(self, dataset_id: str) -> list[InternationalString]:
        rows = self._c.execute(
            "SELECT keyword FROM dataset_keyword WHERE dataset_id = ? ORDER BY ordinal",
            [dataset_id],
        ).fetchall()
        return [_map_to_istring(r[0]) or InternationalString() for r in rows]

    def _read_spatial(self, dataset_id: str) -> list[SpatialCoverage]:
        rows = self._c.execute(
            """SELECT label, uri, bbox_west, bbox_south, bbox_east, bbox_north
            FROM dataset_spatial WHERE dataset_id = ? ORDER BY ordinal""",
            [dataset_id],
        ).fetchall()
        result = []
        for r in rows:
            label = _map_to_istring(r[0])
            bbox: tuple[float, float, float, float] | None = None
            if r[2] is not None:
                bbox = (r[2], r[3], r[4], r[5])
            result.append(SpatialCoverage(label=label, uri=r[1], bbox=bbox))
        return result

    def _read_distributions(self, dataset_id: str) -> list[Distribution]:
        rows = self._c.execute(
            """SELECT id, title, description, access_url, download_url,
                media_type, format, byte_size, issued, modified,
                licence_id, service_id, distribution_type
            FROM distribution WHERE dataset_id = ?""",
            [dataset_id],
        ).fetchall()
        result = []
        for r in rows:
            lic: LicenceDocument | None = None
            if r[10] is not None:
                lic = self._read_licence(r[10])
            svc: DataService | None = None
            if r[11] is not None:
                svc = self._read_data_service(r[11])
            result.append(
                Distribution(
                    id=r[0],
                    title=_map_to_istring(r[1]),
                    description=_map_to_istring(r[2]),
                    access_url=r[3],
                    download_url=r[4],
                    media_type=r[5],
                    format=r[6],
                    byte_size=r[7],
                    issued=r[8],
                    modified=r[9],
                    licence=lic,
                    access_service=svc,
                    distribution_type=r[12],
                )
            )
        return result

    def _read_data_service(self, service_id: str) -> DataService | None:
        row = self._c.execute(
            "SELECT id, title, description, endpoint_url FROM data_service WHERE id = ?",
            [service_id],
        ).fetchone()
        if row is None:
            return None
        serves_rows = self._c.execute(
            "SELECT dataset_id FROM service_dataset WHERE service_id = ?", [service_id]
        ).fetchall()
        return DataService(
            id=row[0],
            title=_map_to_istring(row[1]) or InternationalString(),
            description=_map_to_istring(row[2]),
            endpoint_url=row[3] or "",
            serves_datasets=[r[0] for r in serves_rows],
        )

    def _read_standards(self, dataset_id: str) -> list[Standard]:
        rows = self._c.execute(
            """SELECT s.id, s.label, s.uri
            FROM dataset_standard ds
            JOIN standard s ON ds.standard_id = s.id
            WHERE ds.dataset_id = ?""",
            [dataset_id],
        ).fetchall()
        return [Standard(id=r[0], label=_map_to_istring(r[1]) or InternationalString(), uri=r[2]) for r in rows]

    def _read_quality_annotations(self, dataset_id: str) -> list[QualityAnnotation]:
        rows = self._c.execute(
            "SELECT dimension, label, body FROM quality_annotation WHERE dataset_id = ? ORDER BY ordinal",
            [dataset_id],
        ).fetchall()
        return [
            QualityAnnotation(dimension=r[0], label=_map_to_istring(r[1]), body=_map_to_istring(r[2])) for r in rows
        ]

    def _read_provenance(self, dataset_id: str) -> list[ProvenanceStatement]:
        rows = self._c.execute(
            "SELECT label, uri FROM provenance WHERE dataset_id = ? ORDER BY ordinal",
            [dataset_id],
        ).fetchall()
        return [ProvenanceStatement(label=_map_to_istring(r[0]) or InternationalString(), uri=r[1]) for r in rows]

    def _read_dimension_names(self, dataset_id: str) -> list[InternationalString]:
        rows = self._c.execute(
            "SELECT label FROM dimension_name WHERE dataset_id = ? ORDER BY ordinal",
            [dataset_id],
        ).fetchall()
        return [_map_to_istring(r[0]) or InternationalString() for r in rows]

    def _read_variables(self, dataset_id: str) -> list[Variable]:
        rows = self._c.execute(
            """SELECT variable_id, label, description, value_type,
                classification_id, universe, question_text, valid_range, derivation
            FROM variable WHERE dataset_id = ?""",
            [dataset_id],
        ).fetchall()
        return [
            Variable(
                id=r[0],
                label=_map_to_istring(r[1]) or InternationalString(),
                description=_map_to_istring(r[2]),
                value_type=r[3],
                classification_id=r[4],
                universe=r[5],
                question_text=r[6],
                valid_range=r[7],
                derivation=r[8],
            )
            for r in rows
        ]

    def _read_feature_types(self, dataset_id: str) -> list[str]:
        rows = self._c.execute("SELECT type_name FROM feature_type WHERE dataset_id = ?", [dataset_id]).fetchall()
        return [r[0] for r in rows]

    def _read_authors(self, dataset_id: str) -> list[str]:
        rows = self._c.execute("SELECT name FROM author WHERE dataset_id = ? ORDER BY ordinal", [dataset_id]).fetchall()
        return [r[0] for r in rows]

    # -- Batch entity readers (selectin-style eager loading) --

    def _batch_read_agents(self, ids: set[str]) -> dict[str, Agent]:
        if not ids:
            return {}
        placeholders = ", ".join("?" * len(ids))
        rows = self._c.execute(
            f"SELECT id, name, type, homepage FROM agent WHERE id IN ({placeholders})",
            list(ids),
        ).fetchall()
        return {
            r[0]: Agent(id=r[0], name=_map_to_istring(r[1]) or InternationalString(), type=r[2], homepage=r[3])
            for r in rows
        }

    def _batch_read_contacts(self, ids: set[str]) -> dict[str, ContactPoint]:
        if not ids:
            return {}
        placeholders = ", ".join("?" * len(ids))
        rows = self._c.execute(
            f"SELECT id, name, email, phone, url FROM contact WHERE id IN ({placeholders})",
            list(ids),
        ).fetchall()
        return {r[0]: ContactPoint(name=_map_to_istring(r[1]), email=r[2], phone=r[3], url=r[4]) for r in rows}

    def _batch_read_frequencies(self, ids: set[str]) -> dict[str, Frequency]:
        if not ids:
            return {}
        placeholders = ", ".join("?" * len(ids))
        rows = self._c.execute(
            f"SELECT id, label FROM frequency WHERE id IN ({placeholders})",
            list(ids),
        ).fetchall()
        return {r[0]: Frequency(id=r[0], label=_map_to_istring(r[1]) or InternationalString()) for r in rows}

    def _batch_read_licences(self, ids: set[str]) -> dict[str, LicenceDocument]:
        if not ids:
            return {}
        placeholders = ", ".join("?" * len(ids))
        rows = self._c.execute(
            f"SELECT id, label, uri FROM licence WHERE id IN ({placeholders})",
            list(ids),
        ).fetchall()
        return {
            r[0]: LicenceDocument(id=r[0], label=_map_to_istring(r[1]) or InternationalString(), uri=r[2]) for r in rows
        }

    def _batch_read_themes(self, dataset_ids: list[str]) -> dict[str, list[ConceptRef]]:
        if not dataset_ids:
            return {}
        placeholders = ", ".join("?" * len(dataset_ids))
        rows = self._c.execute(
            f"""SELECT dt.dataset_id, dt.concept_uri, c.notation, c.label, c.in_scheme
            FROM dataset_theme dt
            LEFT JOIN concept c ON c.uri = dt.concept_uri
            WHERE dt.dataset_id IN ({placeholders})""",
            dataset_ids,
        ).fetchall()
        result: dict[str, list[ConceptRef]] = {}
        for r in rows:
            result.setdefault(r[0], []).append(
                ConceptRef(
                    uri=r[1],
                    notation=r[2],
                    label=_map_to_istring(r[3]) or InternationalString(),
                    scheme_uri=r[4],
                )
            )
        return result

    def _batch_read_subjects(self, dataset_ids: list[str]) -> dict[str, list[ConceptRef]]:
        if not dataset_ids:
            return {}
        placeholders = ", ".join("?" * len(dataset_ids))
        rows = self._c.execute(
            f"""SELECT ds.dataset_id, ds.concept_uri, c.notation, c.label, c.in_scheme
            FROM dataset_subject ds
            LEFT JOIN concept c ON c.uri = ds.concept_uri
            WHERE ds.dataset_id IN ({placeholders})""",
            dataset_ids,
        ).fetchall()
        result: dict[str, list[ConceptRef]] = {}
        for r in rows:
            result.setdefault(r[0], []).append(
                ConceptRef(
                    uri=r[1],
                    notation=r[2],
                    label=_map_to_istring(r[3]) or InternationalString(),
                    scheme_uri=r[4],
                )
            )
        return result

    def _batch_read_dataset_types(self, dataset_ids: list[str]) -> dict[str, ConceptRef]:
        """Batch-fetch dataset_type ConceptRefs, hydrated from the concept table where available."""
        if not dataset_ids:
            return {}
        placeholders = ", ".join("?" * len(dataset_ids))
        rows = self._c.execute(
            f"""SELECT d.identifier, d.dataset_type, c.notation, c.label, c.in_scheme
            FROM dataset d
            LEFT JOIN concept c ON c.uri = d.dataset_type
            WHERE d.identifier IN ({placeholders}) AND d.dataset_type IS NOT NULL""",
            dataset_ids,
        ).fetchall()
        return {
            r[0]: ConceptRef(
                uri=r[1],
                notation=r[2],
                label=_map_to_istring(r[3]) or InternationalString(),
                scheme_uri=r[4],
            )
            for r in rows
        }

    def _batch_read_keywords(self, dataset_ids: list[str]) -> dict[str, list[InternationalString]]:
        if not dataset_ids:
            return {}
        placeholders = ", ".join("?" * len(dataset_ids))
        rows = self._c.execute(
            f"SELECT dataset_id, keyword FROM dataset_keyword WHERE dataset_id IN ({placeholders}) ORDER BY ordinal",
            dataset_ids,
        ).fetchall()
        result: dict[str, list[InternationalString]] = {}
        for r in rows:
            result.setdefault(r[0], []).append(_map_to_istring(r[1]) or InternationalString())
        return result

    def _batch_read_spatial(self, dataset_ids: list[str]) -> dict[str, list[SpatialCoverage]]:
        if not dataset_ids:
            return {}
        placeholders = ", ".join("?" * len(dataset_ids))
        rows = self._c.execute(
            f"""SELECT dataset_id, label, uri, bbox_west, bbox_south, bbox_east, bbox_north
            FROM dataset_spatial WHERE dataset_id IN ({placeholders}) ORDER BY ordinal""",
            dataset_ids,
        ).fetchall()
        result: dict[str, list[SpatialCoverage]] = {}
        for r in rows:
            label = _map_to_istring(r[1])
            bbox: tuple[float, float, float, float] | None = None
            if r[3] is not None:
                bbox = (r[3], r[4], r[5], r[6])
            result.setdefault(r[0], []).append(SpatialCoverage(label=label, uri=r[2], bbox=bbox))
        return result

    def _batch_read_data_services(self, ids: set[str]) -> dict[str, DataService]:
        if not ids:
            return {}
        placeholders = ", ".join("?" * len(ids))
        svc_rows = self._c.execute(
            f"SELECT id, title, description, endpoint_url FROM data_service WHERE id IN ({placeholders})",
            list(ids),
        ).fetchall()
        serves_rows = self._c.execute(
            f"SELECT service_id, dataset_id FROM service_dataset WHERE service_id IN ({placeholders})",
            list(ids),
        ).fetchall()
        serves_map: dict[str, list[str]] = {}
        for r in serves_rows:
            serves_map.setdefault(r[0], []).append(r[1])
        return {
            r[0]: DataService(
                id=r[0],
                title=_map_to_istring(r[1]) or InternationalString(),
                description=_map_to_istring(r[2]),
                endpoint_url=r[3] or "",
                serves_datasets=serves_map.get(r[0], []),
            )
            for r in svc_rows
        }

    def _batch_read_distributions(self, dataset_ids: list[str]) -> dict[str, list[Distribution]]:
        if not dataset_ids:
            return {}
        placeholders = ", ".join("?" * len(dataset_ids))
        rows = self._c.execute(
            f"""SELECT dataset_id, id, title, description, access_url, download_url,
                media_type, format, byte_size, issued, modified,
                licence_id, service_id, distribution_type
            FROM distribution WHERE dataset_id IN ({placeholders})""",
            dataset_ids,
        ).fetchall()
        # Collect nested FK IDs
        lic_ids: set[str] = set()
        svc_ids: set[str] = set()
        for r in rows:
            if r[11] is not None:
                lic_ids.add(r[11])
            if r[12] is not None:
                svc_ids.add(r[12])
        licences = self._batch_read_licences(lic_ids)
        services = self._batch_read_data_services(svc_ids)

        result: dict[str, list[Distribution]] = {}
        for r in rows:
            dist = Distribution(
                id=r[1],
                title=_map_to_istring(r[2]),
                description=_map_to_istring(r[3]),
                access_url=r[4],
                download_url=r[5],
                media_type=r[6],
                format=r[7],
                byte_size=r[8],
                issued=r[9],
                modified=r[10],
                licence=licences.get(r[11]) if r[11] else None,
                access_service=services.get(r[12]) if r[12] else None,
                distribution_type=r[13],
            )
            result.setdefault(r[0], []).append(dist)
        return result

    def _batch_read_standards(self, dataset_ids: list[str]) -> dict[str, list[Standard]]:
        if not dataset_ids:
            return {}
        placeholders = ", ".join("?" * len(dataset_ids))
        rows = self._c.execute(
            f"""SELECT ds.dataset_id, s.id, s.label, s.uri
            FROM dataset_standard ds
            JOIN standard s ON ds.standard_id = s.id
            WHERE ds.dataset_id IN ({placeholders})""",
            dataset_ids,
        ).fetchall()
        result: dict[str, list[Standard]] = {}
        for r in rows:
            result.setdefault(r[0], []).append(
                Standard(id=r[1], label=_map_to_istring(r[2]) or InternationalString(), uri=r[3])
            )
        return result

    def _batch_read_quality_annotations(self, dataset_ids: list[str]) -> dict[str, list[QualityAnnotation]]:
        if not dataset_ids:
            return {}
        placeholders = ", ".join("?" * len(dataset_ids))
        rows = self._c.execute(
            f"""SELECT dataset_id, dimension, label, body
            FROM quality_annotation WHERE dataset_id IN ({placeholders}) ORDER BY ordinal""",
            dataset_ids,
        ).fetchall()
        result: dict[str, list[QualityAnnotation]] = {}
        for r in rows:
            result.setdefault(r[0], []).append(
                QualityAnnotation(dimension=r[1], label=_map_to_istring(r[2]), body=_map_to_istring(r[3]))
            )
        return result

    def _batch_read_provenance(self, dataset_ids: list[str]) -> dict[str, list[ProvenanceStatement]]:
        if not dataset_ids:
            return {}
        placeholders = ", ".join("?" * len(dataset_ids))
        rows = self._c.execute(
            f"""SELECT dataset_id, label, uri
            FROM provenance WHERE dataset_id IN ({placeholders}) ORDER BY ordinal""",
            dataset_ids,
        ).fetchall()
        result: dict[str, list[ProvenanceStatement]] = {}
        for r in rows:
            result.setdefault(r[0], []).append(
                ProvenanceStatement(label=_map_to_istring(r[1]) or InternationalString(), uri=r[2])
            )
        return result

    def _batch_read_dimension_names(self, dataset_ids: list[str]) -> dict[str, list[InternationalString]]:
        if not dataset_ids:
            return {}
        placeholders = ", ".join("?" * len(dataset_ids))
        rows = self._c.execute(
            f"""SELECT dataset_id, label
            FROM dimension_name WHERE dataset_id IN ({placeholders}) ORDER BY ordinal""",
            dataset_ids,
        ).fetchall()
        result: dict[str, list[InternationalString]] = {}
        for r in rows:
            result.setdefault(r[0], []).append(_map_to_istring(r[1]) or InternationalString())
        return result

    def _batch_read_variables(self, dataset_ids: list[str]) -> dict[str, list[Variable]]:
        if not dataset_ids:
            return {}
        placeholders = ", ".join("?" * len(dataset_ids))
        rows = self._c.execute(
            f"""SELECT dataset_id, variable_id, label, description, value_type,
                classification_id, universe, question_text, valid_range, derivation
            FROM variable WHERE dataset_id IN ({placeholders})""",
            dataset_ids,
        ).fetchall()
        result: dict[str, list[Variable]] = {}
        for r in rows:
            result.setdefault(r[0], []).append(
                Variable(
                    id=r[1],
                    label=_map_to_istring(r[2]) or InternationalString(),
                    description=_map_to_istring(r[3]),
                    value_type=r[4],
                    classification_id=r[5],
                    universe=r[6],
                    question_text=r[7],
                    valid_range=r[8],
                    derivation=r[9],
                )
            )
        return result

    def _batch_read_feature_types(self, dataset_ids: list[str]) -> dict[str, list[str]]:
        if not dataset_ids:
            return {}
        placeholders = ", ".join("?" * len(dataset_ids))
        rows = self._c.execute(
            f"SELECT dataset_id, type_name FROM feature_type WHERE dataset_id IN ({placeholders})",
            dataset_ids,
        ).fetchall()
        result: dict[str, list[str]] = {}
        for r in rows:
            result.setdefault(r[0], []).append(r[1])
        return result

    def _batch_read_authors(self, dataset_ids: list[str]) -> dict[str, list[str]]:
        if not dataset_ids:
            return {}
        placeholders = ", ".join("?" * len(dataset_ids))
        rows = self._c.execute(
            f"SELECT dataset_id, name FROM author WHERE dataset_id IN ({placeholders}) ORDER BY ordinal",
            dataset_ids,
        ).fetchall()
        result: dict[str, list[str]] = {}
        for r in rows:
            result.setdefault(r[0], []).append(r[1])
        return result

    # -- Batch reconstruction --

    _DATASET_COLUMNS = """identifier, kind, title, description, version_notes,
        publisher_id, creator_id, contact_id, frequency_id, licence_id,
        temporal_start, temporal_end, status, access_rights,
        issued, modified, landing_page, version, language,
        num_series, sdmx_dataflow_urn, measure_dim,
        sample_size, universe, collection_method, anonymization, survey_id,
        crs, spatial_resolution, scale,
        doi, isbn, publication_type, pages, series_title,
        dataset_type,
        extras"""

    def _batch_reconstruct(
        self,
        rows: list[tuple[Any, ...]],
        *,
        include_rels: frozenset[str] | None = None,
    ) -> list[BaseDataset]:
        """Reconstruct multiple datasets using batched relationship loading.

        Uses one SQL query per relationship type (selectin strategy) instead of
        N queries per dataset.

        Parameters
        ----------
        include_rels:
            When ``None`` (default) all relationships are loaded (~17 queries).
            When a frozenset, only the named relationships are fetched; the
            rest default to ``None`` / ``[]`` on the assembled objects.
            Use ``QueryBuilder.include()`` to set this on a query.
        """
        if not rows:
            return []

        # Extract identifiers and FK IDs from the already-fetched main rows.
        # This is cheap (no SQL) and always runs regardless of include_rels.
        identifiers: list[str] = []
        publisher_ids: set[str] = set()
        creator_ids: set[str] = set()
        contact_ids: set[str] = set()
        frequency_ids: set[str] = set()
        licence_ids: set[str] = set()
        for row in rows:
            identifiers.append(row[0])
            if row[5]:
                publisher_ids.add(row[5])
            if row[6]:
                creator_ids.add(row[6])
            if row[7]:
                contact_ids.add(row[7])
            if row[8]:
                frequency_ids.add(row[8])
            if row[9]:
                licence_ids.add(row[9])

        def _load(rel: str) -> bool:
            return include_rels is None or rel in include_rels

        # Batch-fetch only the requested relationships.
        ctx = _BatchContext(
            agents=(
                self._batch_read_agents(publisher_ids | creator_ids) if (_load("publisher") or _load("creator")) else {}
            ),
            contacts=self._batch_read_contacts(contact_ids) if _load("contact_point") else {},
            frequencies=self._batch_read_frequencies(frequency_ids) if _load("frequency") else {},
            licences=self._batch_read_licences(licence_ids) if _load("licence") else {},
            themes=self._batch_read_themes(identifiers) if _load("themes") else {},
            subject=self._batch_read_subjects(identifiers) if _load("subject") else {},
            dataset_type=self._batch_read_dataset_types(identifiers) if _load("dataset_type") else {},
            keywords=self._batch_read_keywords(identifiers) if _load("keywords") else {},
            spatial=self._batch_read_spatial(identifiers) if _load("spatial_coverage") else {},
            distributions=self._batch_read_distributions(identifiers) if _load("distributions") else {},
            standards=self._batch_read_standards(identifiers) if _load("conforms_to") else {},
            quality=self._batch_read_quality_annotations(identifiers) if _load("quality_annotations") else {},
            provenance=self._batch_read_provenance(identifiers) if _load("provenance") else {},
            dimension_names=self._batch_read_dimension_names(identifiers) if _load("dimension_names") else {},
            variables=self._batch_read_variables(identifiers) if _load("variables") else {},
            feature_types=self._batch_read_feature_types(identifiers) if _load("feature_types") else {},
            authors=self._batch_read_authors(identifiers) if _load("authors") else {},
        )

        return [_assemble_dataset(row, ctx, include_rels=include_rels) for row in rows]

    def _fetch_datasets(
        self,
        identifiers: list[str],
        *,
        include_rels: frozenset[str] | None = None,
    ) -> list[BaseDataset]:
        """Batch-fetch and hydrate datasets by identifier list."""
        if not identifiers:
            return []
        placeholders = ", ".join("?" * len(identifiers))
        rows = self._c.execute(
            f"SELECT {self._DATASET_COLUMNS} FROM dataset WHERE identifier IN ({placeholders})",
            identifiers,
        ).fetchall()
        return self._batch_reconstruct(rows, include_rels=include_rels)

    # ------------------------------------------------------------------
    # Query
    # ------------------------------------------------------------------

    def query[T](self, cls: type[T], **filters: Any) -> QueryBuilder[T]:
        """Start a structured query. Returns a QueryBuilder for chaining."""
        builder: QueryBuilder[T] = QueryBuilder(self, cls)
        if filters:
            builder = builder.filter(**filters)
        return builder

    def search(
        self,
        text: str,
        limit: int = 50,
        offset: int = 0,
        *,
        operator: str = "or",
        fuzzy: int = 0,
    ) -> SearchResult[BaseDataset]:
        """Full-text search across titles and descriptions.

        Parameters
        ----------
        operator:
            How to join multi-term queries: ``"or"`` (default) matches any
            term; ``"and"`` requires all terms to match.
        fuzzy:
            Levenshtein edit distance for fuzzy matching: ``0`` (default,
            exact match), ``1``, or ``2``.

        Requires LanceDB (``pinax[search]``).  Returns an empty result
        when the index has not been built — see issue #77.
        """
        if self._lance is None:
            return SearchResult(items=[], total=0, offset=offset)
        bm25_hits = self._lance.bm25_search(
            text,
            limit=limit + offset,
            operator=operator,
            fuzziness=fuzzy,
            entity_type=_DATASET_ENTITY_TYPES,
        )
        total = len(bm25_hits)
        page_hits = bm25_hits[offset : offset + limit]
        if not page_hits:
            return SearchResult(items=[], total=total, offset=offset)
        identifiers = [h[0] for h in page_hits]
        items = self._fetch_by_identifiers(identifiers)
        scores = {h[0]: h[1] for h in page_hits}
        return SearchResult(items=items, total=total, offset=offset, scores=scores)

    def search_codes(
        self,
        text: str,
        *,
        dataset_ids: Sequence[str] | None = None,
        lang: str = "en",
        limit: int = 20,
        operator: str = "or",
        fuzzy: int = 0,
    ) -> list[CodeSearchResult]:
        """BM25 search over individual SDMX code rows (#83).

        Returns matching dimension/code combinations from any dataset that
        was indexed with ``build_index(include_codes=True)`` — this is the
        intended path for an LLM agent translating a free-text phrase
        into a structured ``(dimension_id, code_id)`` filter.

        Parameters
        ----------
        dataset_ids:
            Restrict matches to these dataset identifiers. ``None``
            (default) searches across the entire catalog. Pass a single
            dataset id once an agent has narrowed the dataflow it is
            querying — much higher precision than catalog-wide.
        lang:
            Match against the language-specific row (BCP-47 code).
        limit:
            Maximum number of hits to return (default 20).
        operator:
            ``"or"`` (default) matches any query term; ``"and"`` requires
            all terms to match.
        fuzzy:
            Levenshtein edit distance for fuzzy matching: ``0`` (default,
            exact), ``1``, or ``2``.

        Returns an empty list when the LanceDB index has not been built —
        consistent with :meth:`search` (#77).
        """
        if self._lance is None:
            return []
        rows = self._lance.bm25_search_rows(
            text,
            columns=("id", "dimension_id", "dimension_label", "code_id", "code_label", "text", "lang"),
            lang=lang,
            limit=limit,
            operator=operator,
            fuzziness=fuzzy,
            entity_type="code",
            id_filter=list(dataset_ids) if dataset_ids is not None else None,
        )
        return [
            CodeSearchResult(
                dataset_id=r["id"],
                dimension_id=r.get("dimension_id", "") or "",
                dimension_label=r.get("dimension_label", "") or "",
                code_id=r.get("code_id", "") or "",
                code_label=r.get("code_label", "") or "",
                text=r["text"],
                score=float(r["_score"]),
                lang=r.get("lang", lang),
            )
            for r in rows
        ]

    def facets(self, *fields: str) -> dict[str, dict[str, int]]:
        """Return facet counts for specified fields across all datasets.

        Supported fields: ``"publisher"``, ``"creator"``, ``"themes"``, ``"frequency"``,
        ``"status"``, ``"spatial"``, ``"type"``.
        """
        return {f: self._facet_all(f) for f in fields}

    def _facet_all(self, field_name: str) -> dict[str, int]:
        cur = self._c
        if field_name == "publisher":
            rows = cur.execute(
                "SELECT a.id, COUNT(*) AS cnt"
                " FROM dataset d JOIN agent a ON d.publisher_id = a.id"
                " GROUP BY a.id ORDER BY cnt DESC"
            ).fetchall()
        elif field_name == "creator":
            rows = cur.execute(
                "SELECT a.id, COUNT(*) AS cnt"
                " FROM dataset d JOIN agent a ON d.creator_id = a.id"
                " GROUP BY a.id ORDER BY cnt DESC"
            ).fetchall()
        elif field_name == "themes":
            rows = cur.execute(
                "SELECT dt.concept_uri, COUNT(*) AS cnt FROM dataset_theme dt GROUP BY dt.concept_uri ORDER BY cnt DESC"
            ).fetchall()
        elif field_name == "frequency":
            rows = cur.execute(
                "SELECT frequency_id, COUNT(*) AS cnt FROM dataset"
                " WHERE frequency_id IS NOT NULL"
                " GROUP BY frequency_id ORDER BY cnt DESC"
            ).fetchall()
        elif field_name == "status":
            rows = cur.execute(
                "SELECT status, COUNT(*) AS cnt FROM dataset WHERE status IS NOT NULL GROUP BY status ORDER BY cnt DESC"
            ).fetchall()
        elif field_name == "spatial":
            rows = cur.execute(
                "SELECT ds.label['en'], COUNT(DISTINCT ds.dataset_id) AS cnt"
                " FROM dataset_spatial ds"
                " WHERE ds.label['en'] IS NOT NULL"
                " GROUP BY ds.label['en'] ORDER BY cnt DESC"
            ).fetchall()
        elif field_name == "type":
            rows = cur.execute("SELECT kind, COUNT(*) AS cnt FROM dataset GROUP BY kind ORDER BY cnt DESC").fetchall()
        else:
            rows = []
        return {row[0]: row[1] for row in rows}

    def agent_labels(self, lang: str = "en") -> dict[str, str]:
        """Return ``{agent_id: display_name}`` for the publisher facet sidebar."""
        rows = self._c.execute(
            "SELECT id, name[?] FROM agent WHERE name[?] IS NOT NULL",
            [lang, lang],
        ).fetchall()
        return {row[0]: row[1] for row in rows}

    def concept_labels(self, lang: str = "en", *, scheme_uri: str | None = None) -> dict[str, str]:
        """Return ``{concept_uri: display_label}`` for the theme/subject facet sidebar."""
        if scheme_uri is not None:
            rows = self._c.execute(
                "SELECT uri, label[?] FROM concept WHERE label[?] IS NOT NULL AND in_scheme = ?",
                [lang, lang, scheme_uri],
            ).fetchall()
        else:
            rows = self._c.execute(
                "SELECT uri, label[?] FROM concept WHERE label[?] IS NOT NULL",
                [lang, lang],
            ).fetchall()
        return {row[0]: row[1] for row in rows}

    def spatial_labels(self, lang: str = "en") -> dict[str, str]:
        """Return ``{en_label: display_label}`` for the spatial facet sidebar."""
        if lang == "en":
            return {}
        # SELECT DISTINCT instead of GROUP BY because DuckDB rejects a
        # COALESCE built from grouped MAP-indexed expressions, even when
        # both inner columns appear in the GROUP BY list.
        rows = self._c.execute(
            """SELECT DISTINCT label['en'], COALESCE(label[?], label['en'])
            FROM dataset_spatial
            WHERE label['en'] IS NOT NULL""",
            [lang],
        ).fetchall()
        return {row[0]: row[1] for row in rows}

    # ------------------------------------------------------------------
    # Internal query execution
    # ------------------------------------------------------------------

    def _execute_query[T](
        self,
        cls: type[T],
        filters: dict[str, Any],
        exists_filters: list[PositionalFilter],
        map_filters: list[MapFilter],
        from_ids: list[str] | None,
        text: str | None,
        hybrid_text: str | None,
        search_operator: str,
        search_fuzziness: int,
        sort_fields: list[_SortSpec],
        limit: int | None,
        offset: int,
        facet_fields: list[str],
        *,
        include_rels: frozenset[str] | None = None,
    ) -> SearchResult[T]:
        # Entity types (Agent, DataService, Distribution) use flat-column queries
        if cls in _ENTITY_RECONSTRUCTORS:
            return self._execute_entity_query(cls, filters, exists_filters, limit, offset)  # pyright: ignore[reportReturnType]

        fsql = self._build_filter_sql(cls, filters)  # pyright: ignore[reportArgumentType]
        for ef in exists_filters:
            exists_sql, exists_params = ef.to_sql(fsql)
            fsql.add_where(exists_sql, *exists_params)
        for mf in map_filters:
            mf_sql, mf_params = mf.to_sql(fsql)
            fsql.add_where(mf_sql, *mf_params)

        if from_ids is not None and not from_ids:
            return SearchResult(items=[], total=0, facets={}, offset=offset, scores={})
        if from_ids is not None:
            placeholders = ", ".join("?" * len(from_ids))
            fsql.add_where(f"d.identifier IN ({placeholders})", *from_ids)

        if hybrid_text is not None or text is not None:
            search_text: str = hybrid_text if hybrid_text is not None else (text or "")
            search_type = "hybrid" if hybrid_text is not None else "fts"
            qr = self._run_search_query(
                fsql.join_clause,
                fsql.where_clause,
                fsql.params,
                search_text,
                search_type,
                sort_fields,
                limit,
                offset,
                from_ids=from_ids,
                operator=search_operator,
                fuzziness=search_fuzziness,
            )
        else:
            qr = self._run_filter_query(
                fsql.join_clause,
                fsql.where_clause,
                fsql.params,
                sort_fields,
                limit,
                offset,
                from_ids=from_ids,
            )

        all_datasets = self._fetch_datasets(list(qr.rows), include_rels=include_rels)
        ds_by_id = {ds.identifier: ds for ds in all_datasets}
        items: list[T] = [  # pyright: ignore[reportAssignmentType]
            ds_by_id[ident] for ident in qr.rows if ident in ds_by_id
        ]

        computed_facets: dict[str, dict[str, int]] = {}
        for ff in facet_fields:
            computed_facets[ff] = self._compute_facet_in_context(ff, fsql)

        return SearchResult(items=items, total=qr.total, facets=computed_facets, offset=offset, scores=qr.scores)

    def _execute_entity_query[T](
        self,
        cls: type[T],
        filters: dict[str, Any],
        exists_filters: list[PositionalFilter],
        limit: int | None,
        offset: int,
    ) -> SearchResult[T]:
        """Execute a flat-column query for non-dataset entity types."""
        table = _TABLE_MAP[cls]
        cols = _ENTITY_COLUMNS[cls]
        filter_col_map = _ENTITY_FILTER_COLS.get(cls, {})
        reconstruct = _ENTITY_RECONSTRUCTORS[cls]

        wheres: list[str] = []
        params: list[Any] = []
        for key, val in filters.items():
            col = filter_col_map.get(key)
            if col:
                wheres.append(f"{col} = ?")
                params.append(val)

        # Entity queries (Agent, DataService, Distribution) don't bind to
        # the ``d.identifier`` outer alias that exists_filters expect. We
        # still pass a context so the predicates' to_sql() signatures match;
        # in practice exists_filters here are rare.
        ef_ctx = _QueryContext(row_alias=table)
        for ef in exists_filters:
            ef_sql, ef_params = ef.to_sql(ef_ctx)
            wheres.append(ef_sql)
            params.extend(ef_params)

        where_clause = ("WHERE " + " AND ".join(wheres)) if wheres else ""
        count_sql = f"SELECT COUNT(*) FROM {table} {where_clause}"
        fetch_sql = f"SELECT {cols} FROM {table} {where_clause}"
        if limit is not None:
            fetch_sql += f" LIMIT {limit}"
        if offset:
            fetch_sql += f" OFFSET {offset}"

        count_row = self._c.execute(count_sql, params).fetchone()
        total = int(count_row[0]) if count_row else 0
        rows = self._c.execute(fetch_sql, params).fetchall()
        items: list[T] = [reconstruct(row) for row in rows]  # pyright: ignore[reportAssignmentType]
        return SearchResult(items=items, total=total, offset=offset)

    def _run_search_query(
        self,
        join_clause: str,
        where_clause: str,
        params: list[Any],
        text: str,
        search_type: str,
        sort_fields: list[_SortSpec],  # noqa: ARG002
        limit: int | None,
        offset: int,
        *,
        from_ids: list[str] | None = None,  # noqa: ARG002
        operator: str = "or",
        fuzziness: int = 0,
    ) -> _QueryResult:
        """Execute a search query using LanceDB.

        When the LanceDB index is unavailable (lancedb not installed, or
        ``build_index()`` has not been called yet), returns an empty
        result instead of raising — callers should already handle the
        empty-results case, and a soft failure is friendlier than a
        hard ``RuntimeError`` mid-request.  See issue #77.
        """
        if self._lance is None:
            return _QueryResult(total=0, rows=[], scores={})

        if search_type == "hybrid":
            if self._embedding_model is None:
                msg = "hybrid_search requires an embedding_model"
                raise RuntimeError(msg)
            rrf_scores = self._rrf_rank(text, operator=operator, fuzziness=fuzziness)
            search_ids = sorted(rrf_scores, key=lambda i: rrf_scores[i], reverse=True)
            scores = rrf_scores
        else:
            bm25_hits = self._lance.bm25_search(
                text,
                limit=200,
                operator=operator,
                fuzziness=fuzziness,
                entity_type=_DATASET_ENTITY_TYPES,
            )
            search_ids = [h[0] for h in bm25_hits]
            scores = {h[0]: h[1] for h in bm25_hits}

        if not search_ids:
            return _QueryResult(total=0, rows=[], scores={})

        # Apply relational filters to search results
        placeholders = ", ".join("?" * len(search_ids))
        extra_where = f"d.identifier IN ({placeholders})"
        if where_clause:
            combined_where = f"{where_clause} AND {extra_where}"
        else:
            combined_where = f"WHERE {extra_where}"

        all_params = [*params, *search_ids]
        count_sql = f"SELECT COUNT(*) FROM dataset d {join_clause} {combined_where}"
        fetch_sql = f"SELECT d.identifier FROM dataset d {join_clause} {combined_where}"

        count_row = self._c.execute(count_sql, all_params).fetchone()
        total = int(count_row[0]) if count_row else 0
        rows = self._c.execute(fetch_sql, all_params).fetchall()

        # Preserve search rank order
        filtered_ids = {r[0] for r in rows}
        ordered = [ident for ident in search_ids if ident in filtered_ids]
        filtered_scores = {k: v for k, v in scores.items() if k in filtered_ids}

        page_start = offset
        page_end = (offset + limit) if limit is not None else None
        return _QueryResult(total=total, rows=ordered[page_start:page_end], scores=filtered_scores)

    def _ranked_ids_from_search(
        self,
        cls: type,
        filters: dict[str, Any],
        exists_filters: list[PositionalFilter],
        map_filters: list[MapFilter],
        text: str | None,
        hybrid_text: str | None,
        search_operator: str,
        search_fuzziness: int,
        sort_fields: list[_SortSpec],
        limit: int | None,
        offset: int,
    ) -> list[str]:
        """Run a search query with relational filters and return ranked IDs."""
        search_text = hybrid_text if hybrid_text is not None else text
        if search_text is None:
            return []
        search_type = "hybrid" if hybrid_text is not None else "fts"

        fsql = self._build_filter_sql(cls, filters)
        for ef in exists_filters:
            exists_sql, exists_params = ef.to_sql(fsql)
            fsql.add_where(exists_sql, *exists_params)
        for mf in map_filters:
            mf_sql, mf_params = mf.to_sql(fsql)
            fsql.add_where(mf_sql, *mf_params)

        qr = self._run_search_query(
            fsql.join_clause,
            fsql.where_clause,
            fsql.params,
            search_text,
            search_type,
            sort_fields,
            limit=limit,
            offset=offset,
            operator=search_operator,
            fuzziness=search_fuzziness,
        )
        return qr.rows

    _NULLS_OPTIONS: frozenset[str] = frozenset({"first", "last"})

    @staticmethod
    def _build_order_clause(
        sort_fields: list[_SortSpec],
        from_ids: list[str] | None,
    ) -> tuple[str, list[Any]]:
        """Build the ORDER BY clause for a filter query.

        Returns ``(sql_fragment, params)`` — MAP columns use parameterised
        ``element_at()`` so the language key must be bound.
        """
        all_fields = _SORTABLE_COLUMNS | _MAP_SORTABLE_COLUMNS
        if sort_fields:
            parts: list[str] = []
            order_params: list[Any] = []
            for spec in sort_fields:
                if spec.field not in all_fields:
                    msg = f"Invalid sort field: {spec.field!r}. Allowed: {sorted(all_fields)}"
                    raise ValueError(msg)
                if spec.field in _MAP_SORTABLE_COLUMNS:
                    if spec.lang is None:
                        msg = f"lang is required when sorting by MAP column {spec.field!r}"
                        raise ValueError(msg)
                    col_expr = f"d.{spec.field}[?]"
                    order_params.append(spec.lang)
                else:
                    col_expr = f"d.{spec.field}"
                clause = f"{col_expr} {'DESC' if spec.desc else 'ASC'}"
                if spec.nulls is not None:
                    if spec.nulls not in Catalog._NULLS_OPTIONS:
                        msg = f"Invalid nulls option: {spec.nulls!r}. Allowed: {sorted(Catalog._NULLS_OPTIONS)}"
                        raise ValueError(msg)
                    clause += f" NULLS {spec.nulls.upper()}"
                parts.append(clause)
            return "ORDER BY " + ", ".join(parts), order_params
        if from_ids is not None and from_ids:
            return "ORDER BY list_position(?::VARCHAR[], d.identifier)", []
        return "ORDER BY d.identifier ASC", []

    def _run_filter_query(
        self,
        join_clause: str,
        where_clause: str,
        params: list[Any],
        sort_fields: list[_SortSpec],
        limit: int | None,
        offset: int,
        *,
        from_ids: list[str] | None = None,
    ) -> _QueryResult:
        count_sql = f"SELECT COUNT(*) FROM dataset d {join_clause} {where_clause}"
        order_clause, order_params = self._build_order_clause(sort_fields, from_ids)

        fetch_sql = f"""SELECT d.identifier
            FROM dataset d {join_clause} {where_clause}
            {order_clause}"""
        if limit is not None:
            fetch_sql += f" LIMIT {limit}"
        if offset:
            fetch_sql += f" OFFSET {offset}"

        count_row = self._c.execute(count_sql, params).fetchone()
        total = int(count_row[0]) if count_row else 0

        if not sort_fields and from_ids is not None and from_ids:
            fetch_params = [*params, *order_params, from_ids]
        else:
            fetch_params = [*params, *order_params]
        rows = self._c.execute(fetch_sql, fetch_params).fetchall()
        return _QueryResult(total=total, rows=[r[0] for r in rows])

    def _execute_projection(
        self,
        cls: type,
        select_cols: tuple[str, ...],
        select_lang: str | None,
        filters: dict[str, Any],
        exists_filters: list[PositionalFilter],
        map_filters: list[MapFilter],
        from_ids: list[str] | None,
        sort_fields: list[_SortSpec],
        limit: int | None,
        offset: int,
    ) -> list[Row]:
        """Lightweight Row projection — single SQL, no store.get()."""
        fsql = self._build_filter_sql(cls, filters)
        for ef in exists_filters:
            exists_sql, exists_params = ef.to_sql(fsql)
            fsql.add_where(exists_sql, *exists_params)
        for mf in map_filters:
            mf_sql, mf_params = mf.to_sql(fsql)
            fsql.add_where(mf_sql, *mf_params)
        if from_ids is not None and not from_ids:
            return []
        if from_ids is not None:
            placeholders = ", ".join("?" * len(from_ids))
            fsql.add_where(f"d.identifier IN ({placeholders})", *from_ids)

        col_exprs: list[str] = []
        col_params: list[Any] = []
        for col in select_cols:
            if col in _MAP_SELECTABLE_COLUMNS:
                col_exprs.append(f"d.{col}[?] AS {col}")
                col_params.append(select_lang)
            else:
                col_exprs.append(f"d.{col}")

        order_clause, order_params = self._build_order_clause(sort_fields, from_ids)

        sql = f"SELECT {', '.join(col_exprs)} FROM dataset d {fsql.join_clause} {fsql.where_clause} {order_clause}"
        if limit is not None:
            sql += f" LIMIT {limit}"
        if offset:
            sql += f" OFFSET {offset}"

        all_params = col_params + fsql.params
        if not sort_fields and from_ids is not None and from_ids:
            all_params = [*all_params, *order_params, from_ids]
        else:
            all_params = [*all_params, *order_params]

        rows = self._c.execute(sql, all_params).fetchall()
        return [Row({col: row[i] for i, col in enumerate(select_cols)}) for row in rows]

    def _execute_scalar_projection(
        self,
        cls: type,
        scalar_col: str,
        select_lang: str | None,
        filters: dict[str, Any],
        exists_filters: list[PositionalFilter],
        map_filters: list[MapFilter],
        from_ids: list[str] | None,
        sort_fields: list[_SortSpec],
        limit: int | None,
        offset: int,
    ) -> list[Any]:
        """Single-column flat projection — returns list of bare values."""
        fsql = self._build_filter_sql(cls, filters)
        for ef in exists_filters:
            exists_sql, exists_params = ef.to_sql(fsql)
            fsql.add_where(exists_sql, *exists_params)
        for mf in map_filters:
            mf_sql, mf_params = mf.to_sql(fsql)
            fsql.add_where(mf_sql, *mf_params)
        if from_ids is not None and not from_ids:
            return []
        if from_ids is not None:
            placeholders = ", ".join("?" * len(from_ids))
            fsql.add_where(f"d.identifier IN ({placeholders})", *from_ids)

        col_params: list[Any] = []
        if scalar_col in _MAP_SELECTABLE_COLUMNS:
            col_expr = f"d.{scalar_col}[?]"
            col_params.append(select_lang)
        else:
            col_expr = f"d.{scalar_col}"

        order_clause, order_params = self._build_order_clause(sort_fields, from_ids)

        sql = f"SELECT {col_expr} FROM dataset d {fsql.join_clause} {fsql.where_clause} {order_clause}"
        if limit is not None:
            sql += f" LIMIT {limit}"
        if offset:
            sql += f" OFFSET {offset}"

        all_params = col_params + fsql.params
        if not sort_fields and from_ids is not None and from_ids:
            all_params = [*all_params, *order_params, from_ids]
        else:
            all_params = [*all_params, *order_params]

        rows = self._c.execute(sql, all_params).fetchall()
        return [r[0] for r in rows]

    def _execute_exists(
        self,
        cls: type,
        filters: dict[str, Any],
        exists_filters: list[PositionalFilter],
        map_filters: list[MapFilter],
        from_ids: list[str] | None,
    ) -> bool:
        """Return True if at least one row matches the filters."""
        fsql = self._build_filter_sql(cls, filters)
        for ef in exists_filters:
            exists_sql, exists_params = ef.to_sql(fsql)
            fsql.add_where(exists_sql, *exists_params)
        for mf in map_filters:
            mf_sql, mf_params = mf.to_sql(fsql)
            fsql.add_where(mf_sql, *mf_params)
        if from_ids is not None and not from_ids:
            return False
        if from_ids is not None:
            placeholders = ", ".join("?" * len(from_ids))
            fsql.add_where(f"d.identifier IN ({placeholders})", *from_ids)

        sql = f"SELECT 1 FROM dataset d {fsql.join_clause} {fsql.where_clause} LIMIT 1"
        row = self._c.execute(sql, fsql.params).fetchone()
        return row is not None

    def _build_filter_sql(
        self,
        cls: type,
        filters: dict[str, Any],
    ) -> _QueryContext:
        """Build base SQL filter fragments from a cls + filter dict."""
        ctx = _QueryContext(row_alias="d")

        if cls in _CLS_TO_KIND:
            ctx.add_where("d.kind = ?", _CLS_TO_KIND[cls])

        for key, val in filters.items():
            if key == "publisher":
                ctx.add_where("d.publisher_id = ?", val)
            elif key == "creator":
                ctx.add_where("d.creator_id = ?", val)
            elif key == "status":
                ctx.add_where("d.status = ?", val)
            elif key == "frequency":
                ctx.add_where("d.frequency_id = ?", val)
            elif key == "identifier":
                ctx.add_where("d.identifier = ?", val)

        return ctx

    def _compute_facet_in_context(
        self,
        field_name: str,
        fsql: _QueryContext,
    ) -> dict[str, int]:
        """Compute facet counts restricted to the current query's match set."""
        join_clause = fsql.join_clause
        where_clause = fsql.where_clause
        match_sql = f"SELECT DISTINCT d.identifier FROM dataset d {join_clause} {where_clause}"
        match_params = list(fsql.params)

        if field_name == "publisher":
            sql = f"""SELECT a.id, COUNT(*) AS cnt
                FROM ({match_sql}) m
                JOIN dataset d ON m.identifier = d.identifier
                JOIN agent a ON d.publisher_id = a.id
                GROUP BY a.id ORDER BY cnt DESC"""
        elif field_name == "creator":
            sql = f"""SELECT a.id, COUNT(*) AS cnt
                FROM ({match_sql}) m
                JOIN dataset d ON m.identifier = d.identifier
                JOIN agent a ON d.creator_id = a.id
                GROUP BY a.id ORDER BY cnt DESC"""
        elif field_name == "themes":
            sql = f"""SELECT dt.concept_uri, COUNT(*) AS cnt
                FROM ({match_sql}) m
                JOIN dataset_theme dt ON m.identifier = dt.dataset_id
                GROUP BY dt.concept_uri ORDER BY cnt DESC"""
        elif field_name == "frequency":
            sql = f"""SELECT d.frequency_id, COUNT(*) AS cnt
                FROM ({match_sql}) m
                JOIN dataset d ON m.identifier = d.identifier
                WHERE d.frequency_id IS NOT NULL
                GROUP BY d.frequency_id ORDER BY cnt DESC"""
        elif field_name == "status":
            sql = f"""SELECT d.status, COUNT(*) AS cnt
                FROM ({match_sql}) m
                JOIN dataset d ON m.identifier = d.identifier
                WHERE d.status IS NOT NULL
                GROUP BY d.status ORDER BY cnt DESC"""
        elif field_name == "spatial":
            sql = f"""SELECT ds.label['en'], COUNT(DISTINCT m.identifier) AS cnt
                FROM ({match_sql}) m
                JOIN dataset_spatial ds ON m.identifier = ds.dataset_id
                WHERE ds.label['en'] IS NOT NULL
                GROUP BY ds.label['en'] ORDER BY cnt DESC"""
        elif field_name == "type":
            sql = f"""SELECT d.kind, COUNT(*) AS cnt
                FROM ({match_sql}) m
                JOIN dataset d ON m.identifier = d.identifier
                GROUP BY d.kind ORDER BY cnt DESC"""
        else:
            return {}

        rows = self._c.execute(sql, match_params).fetchall()
        return {row[0]: row[1] for row in rows}

    # ---------------------------------------------------------------------------
    # Structural traversal — shared sdmxlib tables
    # ---------------------------------------------------------------------------

    def dataset(self, identifier: str) -> DatasetScope:
        """Return a scope for navigating a dataset's graph relationships.

        Enables Gremlin-style traversal::

            store.dataset("housing-stats").codelists
            store.dataset("housing-stats").related("codelist")
            store.dataset("housing-stats").upstream(depth=5)
        """
        return DatasetScope(identifier=identifier, store=self)

    def codelist(self, urn: str) -> CodelistScope:
        """Return a lazy scope for the codelist identified by *urn*."""
        return CodelistScope(urn=urn, store=self)

    @property
    def codelists(self) -> CodelistsScope:
        """Lazy scope over all codelists in the shared structural tables."""
        return CodelistsScope(store=self)

    def dimensions(self, ds: AggregateDataset) -> DimensionsScope:
        """Return a lazy scope over the dimensions of *ds*."""
        if ds.sdmx_dataflow_urn is None:
            return DimensionsScope(dataflow_urn="", store=self)
        return DimensionsScope(dataflow_urn=ds.sdmx_dataflow_urn, store=self)

    def _resolve_codelist(self, urn: str) -> sdmxlib.model.codelist.Codelist:
        """Resolve a codelist URN to its full sdmxlib Codelist object."""
        reg = self.registry
        cl = reg.get(urn, eager=True)  # type: ignore[arg-type]
        if cl is None:
            msg = f"Codelist not found: {urn}"
            raise LookupError(msg)
        return cl  # type: ignore[return-value]

    def _resolve_codelist_urn(self, dataflow_urn: str, dimension_id: str) -> str | None:
        """Resolve the codelist URN for a specific dimension of a dataflow."""
        try:
            row = self.connection.execute(
                """
                SELECT dc.codelist_urn
                FROM sdmx.dataflow df
                JOIN sdmx.dsd_component dc ON dc.dsd_urn = df.dsd_urn
                WHERE df.urn = ?
                  AND dc.component_id = ?
                  AND dc.component_type = 'Dimension'
                  AND dc.codelist_urn IS NOT NULL
                LIMIT 1
                """,
                [dataflow_urn, dimension_id],
            ).fetchone()
        except duckdb.CatalogException:
            return None
        return row[0] if row else None

    def code_map(self, dataset_id: str, lang: str = "en") -> dict[str, dict[str, str]]:
        """Return ``{dimension_id: {code_id: label}}`` for a dataset.

        Joins catalog ``dataset`` -> ``sdmx.dataflow`` -> ``sdmx.dsd_component`` ->
        ``sdmx.code`` entirely in SQL.
        """
        try:
            rows = self.connection.execute(
                """
                SELECT dc.component_id, c.code_id, c.name[?]
                FROM pinax.dataset d
                JOIN sdmx.dataflow df ON df.urn = d.sdmx_dataflow_urn
                JOIN sdmx.dsd_component dc ON dc.dsd_urn = df.dsd_urn
                JOIN sdmx.code c ON c.codelist_urn = dc.codelist_urn
                WHERE d.identifier = ?
                  AND dc.component_type = 'Dimension'
                ORDER BY dc.position, c.position
                """,
                [lang, dataset_id],
            ).fetchall()
        except duckdb.CatalogException:
            return {}
        result: dict[str, dict[str, str]] = {}
        for dim_id, code_id, label in rows:
            result.setdefault(dim_id, {})[code_id] = label or code_id
        return result

    def codelist_for(self, dataset_id: str, dimension: str) -> sdmxlib.model.codelist.Codelist | None:
        """Return the Codelist for a specific dimension of a dataset.

        Resolves via the shared structural tables. Returns ``None`` if the
        dataset has no SDMX link or the dimension has no enumerated codelist.
        """
        try:
            row = self.connection.execute(
                """
                SELECT dc.codelist_urn
                FROM pinax.dataset d
                JOIN sdmx.dataflow df ON df.urn = d.sdmx_dataflow_urn
                JOIN sdmx.dsd_component dc ON dc.dsd_urn = df.dsd_urn
                WHERE d.identifier = ?
                  AND dc.component_id = ?
                  AND dc.component_type = 'Dimension'
                  AND dc.codelist_urn IS NOT NULL
                LIMIT 1
                """,
                [dataset_id, dimension],
            ).fetchone()
        except duckdb.CatalogException:
            return None
        if row is None:
            return None
        codelist_urn: str = row[0]
        reg = self.registry
        return reg.get(codelist_urn, eager=True)  # type: ignore[return-value]

    def get_structure(self, ds: AggregateDataset) -> sdmxlib.model.datastructure.DataStructure | None:
        """Resolve the full DataStructure for an AggregateDataset.

        Returns ``None`` if ``ds.sdmx_dataflow_urn`` is not set or the DSD
        is not in the shared structural tables.
        """
        if ds.sdmx_dataflow_urn is None:
            return None
        try:
            row = self.connection.execute(
                "SELECT dsd_urn FROM sdmx.dataflow WHERE urn = ? LIMIT 1",
                [ds.sdmx_dataflow_urn],
            ).fetchone()
        except duckdb.CatalogException:
            return None
        if row is None:
            return None
        dsd_urn: str = row[0]
        reg = self.registry
        return reg.get(dsd_urn)  # type: ignore[return-value]

    # ---------------------------------------------------------------------------
    # Lineage and provenance
    # ---------------------------------------------------------------------------

    #: Recognised relationship type values (``prov:wasDerivedFrom`` family).
    LINEAGE_RELATIONSHIPS: tuple[str, ...] = (
        "derived_from",
        "revision_of",
        "supplement_to",
        "feeds_into",
        "adjusted_from",
        "aggregated_from",
        "uses_classification",
        "replaces",
    )

    #: Recognised confidence values for lineage rows.
    LINEAGE_CONFIDENCE: tuple[str, ...] = ("asserted", "inferred", "extracted")

    def add_lineage(
        self,
        source_id: str,
        target_id: str,
        relationship: str,
        *,
        activity_label: str | None = None,
        activity_type: str | None = None,
        agent_id: str | None = None,
        timestamp: datetime | None = None,
        confidence: str = "asserted",
        notes: str | None = None,
    ) -> None:
        """Record a PROV-O-aligned lineage edge between two datasets."""
        row_id = hashlib.md5(  # noqa: S324
            f"{source_id}:{target_id}:{relationship}".encode()
        ).hexdigest()
        self._exec(
            """
            INSERT INTO lineage
                (id, source_id, target_id, relationship, activity_label,
                 activity_type, agent_id, timestamp, confidence, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT (source_id, target_id, relationship) DO UPDATE SET
                id             = excluded.id,
                activity_label = excluded.activity_label,
                activity_type  = excluded.activity_type,
                agent_id       = excluded.agent_id,
                timestamp      = excluded.timestamp,
                confidence     = excluded.confidence,
                notes          = excluded.notes
            """,
            [
                row_id,
                source_id,
                target_id,
                relationship,
                activity_label,
                activity_type,
                agent_id,
                timestamp,
                confidence,
                notes,
            ],
        )
