"""SFTP / FTP connection helpers for the unified session model."""

import socket
from ftplib import FTP
from typing import Any, List, Optional, Tuple

try:
    import paramiko
except ImportError:
    paramiko = None  # type: ignore


def _close_sock(s: Optional[socket.socket]) -> None:
    if s is not None:
        try:
            s.close()
        except Exception:
            pass


def _try_sftp_over_ssh_client(
    host_s: str,
    port: int,
    uname: str,
    password: Optional[str],
    *,
    allow_agent: bool,
    look_for_keys: bool,
    timeout: int,
) -> Tuple[Optional[Any], Optional["paramiko.SFTPClient"]]:
    """Return (client, sftp) on success, (None, None) on failure."""
    if paramiko is None:
        return None, None
    sock: Optional[socket.socket] = None
    try:
        sock = socket.create_connection((host_s, int(port)), timeout=timeout)
        sock.settimeout(float(timeout))
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(
            hostname=host_s,
            port=int(port),
            username=uname,
            password=password,
            timeout=timeout,
            banner_timeout=timeout,
            auth_timeout=timeout,
            allow_agent=allow_agent,
            look_for_keys=look_for_keys,
            sock=sock,
        )
        return client, client.open_sftp()
    except Exception:
        _close_sock(sock)
        return None, None


def _transport_try_auth(
    t: "paramiko.Transport", uname: str, pwd: str
) -> bool:
    """Authenticate on an already-started Transport; return True if SFTP can proceed."""
    # Some appliances allow "none" auth first.
    try:
        t.auth_none(uname)
        if t.is_authenticated():
            return True
    except paramiko.AuthenticationException:
        pass
    except Exception:
        pass

    if pwd:
        try:
            t.auth_password(uname, pwd)
            if t.is_authenticated():
                return True
        except paramiko.AuthenticationException:
            pass
        except Exception:
            pass
        try:
            t.auth_interactive_dumb(uname, pwd)
            if t.is_authenticated():
                return True
        except Exception:
            pass
    else:
        # Empty password: WinSCP often succeeds via password="" or keyboard-interactive with blank fields.
        for attempt in (
            lambda: t.auth_password(uname, ""),
            lambda: t.auth_interactive_dumb(uname, ""),
        ):
            try:
                attempt()
                if t.is_authenticated():
                    return True
            except Exception:
                pass

        def _ki_handler(_title: str, _instructions: str, prompt_list: List[str]) -> List[str]:
            return [""] * len(prompt_list)

        try:
            t.auth_interactive(uname, _ki_handler)
            if t.is_authenticated():
                return True
        except Exception:
            pass

    return False


def connect_sftp(
    host: str,
    port: int,
    username: str,
    password: str,
    timeout: int = 25,
) -> Tuple[Optional[Any], Optional["paramiko.SFTPClient"], str]:
    """Return (SSHClient or Transport, SFTPClient, error).

    Tries password auth, optional agent/keys, explicit empty-password auth (common on embedded
    images), then keyboard-interactive with blank responses.
    """
    if paramiko is None:
        return None, None, "paramiko is not installed (pip install paramiko)"
    if not (host or "").strip():
        return None, None, "Host is empty"
    uname = (username or "").strip()
    if not uname:
        return None, None, "User name is required for SFTP"
    pwd = (password or "").strip()
    host_s = host.strip()

    # --- SSHClient attempts (password, agent, keys combinations) ---
    client_attempts: List[Tuple[Optional[str], bool, bool]] = []
    if pwd:
        client_attempts.extend(
            [
                (pwd, True, True),
                (pwd, False, False),
            ]
        )
    else:
        # Empty password: try agent/keys, then explicit "" (some dropbear/openssh setups).
        client_attempts.extend(
            [
                (None, True, True),
                ("", True, True),
                (None, False, False),
                ("", False, False),
            ]
        )

    for pw, aa, lk in client_attempts:
        c, sftp = _try_sftp_over_ssh_client(
            host_s,
            port,
            uname,
            pw,
            allow_agent=aa,
            look_for_keys=lk,
            timeout=timeout,
        )
        if c is not None and sftp is not None:
            return c, sftp, ""

    # --- Transport: keyboard-interactive and empty-password paths (many headless / IVI servers) ---
    sock3: Optional[socket.socket] = None
    try:
        sock3 = socket.create_connection((host_s, int(port)), timeout=timeout)
        sock3.settimeout(float(timeout))
        t = paramiko.Transport(sock3)
        t.banner_timeout = timeout
        t.auth_timeout = timeout
        t.start_client(timeout=timeout)
        if _transport_try_auth(t, uname, pwd):
            sftp = paramiko.SFTPClient.from_transport(t)
            if sftp is None:
                t.close()
                return None, None, "Could not start SFTP subsystem."
            return t, sftp, ""
        t.close()
        return None, None, "Authentication failed (enter password or configure SSH keys in Preferences)."
    except Exception as exc:
        _close_sock(sock3)
        return None, None, str(exc)


def disconnect_sftp(transport: Any, sftp: Any) -> None:
    try:
        if sftp is not None:
            sftp.close()
    except Exception:
        pass
    try:
        if transport is not None:
            transport.close()
    except Exception:
        pass


def sftp_first_listable_path(sftp: Any, username: str = "") -> str:
    """Return a remote path that exists for SFTP listing (many embedded images lack /root or /home)."""
    u = (username or "").strip()
    candidates = ["/", "/tmp", "/storage", "/sdcard", "/mnt", "/media"]
    if u == "root":
        candidates.insert(0, "/root")
    if u:
        candidates.insert(1, f"/home/{u}")
    for c in candidates:
        try:
            sftp.listdir_attr(c)
            return c
        except Exception:
            continue
    return "/"


def connect_ftp(
    host: str,
    port: int,
    user: str,
    password: str,
    timeout: int = 25,
) -> Tuple[Optional[FTP], str]:
    if not host.strip():
        return None, "Host is empty"
    try:
        ftp = FTP()
        ftp.connect(host.strip(), int(port), timeout=timeout)
        ftp.login(user or "", password or "")
        ftp.set_pasv(True)
        try:
            ftp.encoding = "utf-8"
        except Exception:
            pass
        return ftp, ""
    except Exception as exc:
        return None, str(exc)


def disconnect_ftp(ftp: Optional[FTP]) -> None:
    if ftp is None:
        return
    try:
        ftp.quit()
    except Exception:
        try:
            ftp.close()
        except Exception:
            pass
