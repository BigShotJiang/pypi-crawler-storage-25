# src/net_alpha/db/repository.py
from __future__ import annotations

import json
import logging
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import UTC, date, datetime
from decimal import Decimal
from typing import TYPE_CHECKING
from uuid import uuid4

if TYPE_CHECKING:
    from net_alpha.portfolio.plan_diff import SnapshotRow

from sqlalchemy import func, text
from sqlalchemy.engine import Engine
from sqlmodel import Session, select

from net_alpha.db.tables import (
    AccountRow,
    CashEventRow,
    ExemptMatchRow,
    ImportRecordRow,
    LossCarryforwardRow,
    LotOverrideRow,
    LotRow,
    MetaRow,
    PositionTargetRow,
    RealizedGLLotRow,
    Section1256ClassificationRow,
    Section1256MTMRow,
    ServiceRunRow,
    SplitRow,
    TradeRow,
    UserPreferenceRow,
    WashSaleViolationRow,
    WashSaleWatchResultRow,
)
from net_alpha.models.accounts import AccountType
from net_alpha.models.domain import (
    Account,
    AddImportResult,
    CashEvent,
    ExemptMatch,
    ImportRecord,
    ImportSummary,
    Lot,
    OptionDetails,
    RemoveImportResult,
    Section1256Classification,
    Section1256MTM,
    Trade,
    WashSaleViolation,
)
from net_alpha.models.preferences import AccountPreference
from net_alpha.models.realized_gl import RealizedGLLot
from net_alpha.models.splits import LotOverride, Split
from net_alpha.prefs.overview_layout import OverviewLayout as OverviewLayout
from net_alpha.prefs.overview_layout import default_overview_layout
from net_alpha.prefs.overview_layout import sanitize as _sanitize_overview_layout
from net_alpha.section_1256.universe import is_section_1256 as _is_section_1256
from net_alpha.section_1256.universe import load_universe
from net_alpha.targets.models import PositionTarget, TargetUnit
from net_alpha.targets.tags import normalize_tag, normalize_tags

log = logging.getLogger(__name__)


class Repository:
    """v2 repository — narrowed; one method per CLI need."""

    def __init__(self, engine: Engine):
        self.engine = engine
        # Per-Repository cache of account_id -> "broker/label". Repository is
        # one-per-request in the web layer, so this never goes stale within a
        # single page render — but bulk list_* methods used to issue one
        # `s.get(AccountRow, account_id)` per row (N+1). Cached here, the
        # entire page render does at most one lookup per distinct account.
        self._acct_display_cache: dict[int, str] = {}

    # --- Account / import management ---

    def get_or_create_account(self, broker: str, label: str) -> Account:
        with Session(self.engine) as s:
            row = s.exec(select(AccountRow).where(AccountRow.broker == broker, AccountRow.label == label)).first()
            if row is None:
                row = AccountRow(broker=broker, label=label)
                s.add(row)
                s.commit()
                s.refresh(row)
            return Account(id=row.id, broker=row.broker, label=row.label)

    def get_account(self, broker: str, label: str) -> Account | None:
        with Session(self.engine) as s:
            row = s.exec(select(AccountRow).where(AccountRow.broker == broker, AccountRow.label == label)).first()
            if row is None:
                return None
            return Account(id=row.id, broker=row.broker, label=row.label)

    def list_accounts(self) -> list[Account]:
        with Session(self.engine) as s:
            rows = s.exec(select(AccountRow).order_by(AccountRow.broker, AccountRow.label)).all()
            return [Account(id=r.id, broker=r.broker, label=r.label, type=r.type) for r in rows]

    def get_account_type(self, *, broker: str, label: str) -> str:
        with Session(self.engine) as s:
            row = s.exec(select(AccountRow).where(AccountRow.broker == broker, AccountRow.label == label)).first()
            return row.type if row else "taxable"

    def account_types_by_display(self) -> dict[str, AccountType]:
        """Single-query map of ``"broker/label"`` → ``AccountType``.

        Used by the wash-sale detector to apply Rev. Rul. 2008-5 (IRA-trap)
        rules. Missing or unknown type strings fall back to ``TAXABLE`` so
        legacy rows pre-dating schema v19 stay safe.
        """
        out: dict[str, AccountType] = {}
        with Session(self.engine) as s:
            rows = s.exec(select(AccountRow)).all()
            for r in rows:
                display = f"{r.broker}/{r.label}"
                try:
                    out[display] = AccountType(r.type) if r.type else AccountType.TAXABLE
                except ValueError:
                    out[display] = AccountType.TAXABLE
        return out

    def set_account_type(self, *, broker: str, label: str, type_: str) -> None:
        with Session(self.engine) as s:
            row = s.exec(select(AccountRow).where(AccountRow.broker == broker, AccountRow.label == label)).first()
            if row is None:
                return  # caller should ensure account exists first
            row.type = type_
            s.add(row)
            s.commit()

    def existing_put_assignment_keys(self, account_id: int) -> set[tuple[str, str, str, float]]:
        """Set of (account_display, ticker, date_iso, qty) for every existing
        put_assignment trade in `account_id`. Consumed by
        ``filter_assignment_duplicates`` to drop the raw Schwab Buy-of-
        underlying row when it's re-imported in a partial CSV that lacks the
        matching Assigned option row.
        """
        with Session(self.engine) as s:
            display = self._account_display_for_id(s, account_id)
            rows = s.exec(
                select(TradeRow.ticker, TradeRow.trade_date, TradeRow.quantity).where(
                    TradeRow.account_id == account_id,
                    TradeRow.basis_source == "put_assignment",
                )
            ).all()
            return {(display, ticker, trade_date, float(quantity)) for ticker, trade_date, quantity in rows}

    def resolve_account_label(self, label: str) -> str | None:
        """Map a broker-exported account string to the canonical ``broker/label``
        display form used everywhere else in the app.

        Resolution order, returning the matched account's display string:
          1. Direct display match: label == f"{a.broker}/{a.label}"
          2. Bare-label match:     label == a.label
          3. Alias match:          label == a.broker_label
        Returns None when nothing matches. The display form is what
        aggregate_open_positions emits on its side of the verify reconciler
        join, so storing display-form broker_position.account_label is what
        makes the (account_label, symbol) keys actually align.
        """
        with Session(self.engine) as s:
            for a in s.exec(select(AccountRow)).all():
                display = f"{a.broker}/{a.label}"
                if label in (display, a.label, a.broker_label):
                    return display
            return None

    def set_account_broker_alias(self, *, account_id: int, broker_label: str) -> None:
        """Register a broker-exported label as an alias for `account_id` and
        retroactively retag broker_position rows that hold the raw label.

        Retag target is the broker/label display string (matching
        aggregate_open_positions' side of the verify join). Any rows from
        past imports stamped with the raw broker string flip to that
        display form so the next verify run joins them cleanly.
        """
        with Session(self.engine) as s:
            row = s.exec(select(AccountRow).where(AccountRow.id == account_id)).first()
            if row is None:
                raise ValueError(f"unknown account id={account_id}")
            row.broker_label = broker_label
            s.add(row)
            canonical = f"{row.broker}/{row.label}"
            s.exec(
                text("UPDATE broker_position SET account_label = :canonical WHERE account_label = :raw").bindparams(
                    canonical=canonical,
                    raw=broker_label,
                )
            )
            s.commit()

    def unresolved_broker_labels(self, *, import_id: int) -> list[str]:
        """Distinct broker_position.account_label values in `import_id` that
        do not match any account's canonical display form (broker/label).

        Returned in stable alphabetical order so the picker UI renders
        deterministically across page reloads.
        """
        with Session(self.engine) as s:
            display_forms = {f"{a.broker}/{a.label}" for a in s.exec(select(AccountRow)).all()}
            rows = s.exec(
                text(
                    "SELECT DISTINCT account_label FROM broker_position WHERE import_id = :iid ORDER BY account_label"
                ).bindparams(iid=import_id)
            ).all()
            return [r[0] for r in rows if r[0] not in display_forms]

    def get_user_preference(self, account_id: int) -> AccountPreference | None:
        with Session(self.engine) as s:
            row = s.get(UserPreferenceRow, account_id)
            if row is None:
                return None
            return AccountPreference(
                account_id=row.account_id,
                profile=row.profile,  # type: ignore[arg-type]
                density=row.density,  # type: ignore[arg-type]
                theme=row.theme,  # type: ignore[arg-type]
                updated_at=row.updated_at,
            )

    def list_user_preferences(self) -> list[AccountPreference]:
        with Session(self.engine) as s:
            rows = s.exec(select(UserPreferenceRow)).all()
            return [
                AccountPreference(
                    account_id=r.account_id,
                    profile=r.profile,  # type: ignore[arg-type]
                    density=r.density,  # type: ignore[arg-type]
                    theme=r.theme,  # type: ignore[arg-type]
                    updated_at=r.updated_at,
                )
                for r in rows
            ]

    def upsert_user_preference(self, pref: AccountPreference) -> None:
        with Session(self.engine) as s:
            row = s.get(UserPreferenceRow, pref.account_id)
            if row is None:
                row = UserPreferenceRow(
                    account_id=pref.account_id,
                    profile=pref.profile,
                    density=pref.density,
                    theme=pref.theme,
                    updated_at=pref.updated_at,
                )
                s.add(row)
            else:
                row.profile = pref.profile
                row.density = pref.density
                row.theme = pref.theme
                row.updated_at = pref.updated_at
            s.commit()

    def get_tour_completed(self) -> bool:
        with Session(self.engine) as s:
            row = s.exec(text("SELECT value FROM meta WHERE key='onboarding.tour_completed'")).first()
        return bool(row and str(row[0]) == "1")

    def set_tour_completed(self, value: bool) -> None:
        with Session(self.engine) as s:
            s.exec(
                text(
                    "INSERT INTO meta(key, value) VALUES "
                    "('onboarding.tour_completed', :v) "
                    "ON CONFLICT(key) DO UPDATE SET value=:v"
                ),
                params={"v": "1" if value else "0"},
            )
            s.commit()

    def list_imports(self) -> list[ImportSummary]:
        with Session(self.engine) as s:
            stmt = (
                select(ImportRecordRow, AccountRow)
                .join(AccountRow, AccountRow.id == ImportRecordRow.account_id)
                .order_by(ImportRecordRow.imported_at.desc())
            )
            out: list[ImportSummary] = []
            for ir, a in s.exec(stmt).all():
                gl_count = s.exec(
                    select(func.count(RealizedGLLotRow.id)).where(RealizedGLLotRow.import_id == ir.id)
                ).one()
                out.append(
                    ImportSummary(
                        id=ir.id,
                        account_display=f"{a.broker}/{a.label}",
                        csv_filename=ir.csv_filename,
                        trade_count=ir.trade_count,
                        imported_at=ir.imported_at,
                        gl_lot_count=int(gl_count or 0),
                        min_trade_date=date.fromisoformat(ir.min_trade_date) if ir.min_trade_date else None,
                        max_trade_date=date.fromisoformat(ir.max_trade_date) if ir.max_trade_date else None,
                        equity_count=ir.equity_count,
                        option_count=ir.option_count,
                        option_expiry_count=ir.option_expiry_count,
                        parse_warnings=json.loads(ir.parse_warnings_json) if ir.parse_warnings_json else [],
                        duplicate_trades=ir.duplicate_trades or 0,
                        cash_event_count=ir.cash_event_count or 0,
                    )
                )
            return out

    def get_import(self, import_id: int) -> ImportRecord | None:
        with Session(self.engine) as s:
            row = s.get(ImportRecordRow, import_id)
            if row is None:
                return None
            return ImportRecord(
                id=row.id,
                account_id=row.account_id,
                csv_filename=row.csv_filename,
                csv_sha256=row.csv_sha256,
                imported_at=row.imported_at,
                trade_count=row.trade_count,
            )

    def existing_natural_keys(self, account_id: int) -> set[str]:
        with Session(self.engine) as s:
            rows = s.exec(select(TradeRow.natural_key).where(TradeRow.account_id == account_id)).all()
            return set(rows)

    def existing_cash_event_natural_keys(self, account_id: int) -> set[str]:
        with Session(self.engine) as s:
            rows = s.exec(select(CashEventRow.natural_key).where(CashEventRow.account_id == account_id)).all()
            return set(rows)

    def add_import(
        self,
        account: Account,
        record: ImportRecord,
        trades: list[Trade],
        cash_events: list[CashEvent] | None = None,
    ) -> AddImportResult:
        """Insert trades for a new ImportRecord. Caller should pre-filter dups
        with existing_natural_keys; we still rely on the UNIQUE constraint as
        the safety net for anything the caller missed.
        """
        with Session(self.engine) as s:
            ir = ImportRecordRow(
                account_id=account.id,
                csv_filename=record.csv_filename,
                csv_sha256=record.csv_sha256,
                imported_at=record.imported_at,
                trade_count=len(trades),
                min_trade_date=record.min_trade_date.isoformat() if record.min_trade_date else None,
                max_trade_date=record.max_trade_date.isoformat() if record.max_trade_date else None,
                equity_count=record.equity_count,
                option_count=record.option_count,
                option_expiry_count=record.option_expiry_count,
                parse_warnings_json=json.dumps(record.parse_warnings) if record.parse_warnings else None,
            )
            s.add(ir)
            s.flush()  # populate ir.id

            # Pre-filter natural-key duplicates BEFORE inserting. The previous
            # try/rollback path was unsafe: SQLAlchemy session rollback unwinds
            # the entire session, silently undoing every trade flushed earlier
            # in this same call. Two within-file collisions could cascade into
            # hundreds of lost trades. Mirror the cash-event branch below
            # (which already pre-filters for the same reason).
            existing_keys = set(s.exec(select(TradeRow.natural_key).where(TradeRow.account_id == account.id)).all())
            new_count = 0
            dup_count = 0
            seen_in_batch: set[str] = set()
            for t in trades:
                nk = t.compute_natural_key()
                if nk in existing_keys or nk in seen_in_batch:
                    dup_count += 1
                    continue
                seen_in_batch.add(nk)
                # On first import the broker date IS the acquisition date —
                # populate transfer_date with the same value so the user can
                # later edit `date` (acquisition) without losing the original.
                _is_transfer = t.basis_source in ("transfer_in", "transfer_out")
                # C1: auto-detect §1256 status if the caller (broker parser) did
                # not set it explicitly. Respects any True already on the trade.
                flag_1256 = t.is_section_1256 or _is_section_1256(t)
                tr = TradeRow(
                    import_id=ir.id,
                    account_id=account.id,
                    natural_key=nk,
                    ticker=t.ticker,
                    trade_date=t.date.isoformat(),
                    action=t.action,
                    quantity=t.quantity,
                    proceeds=t.proceeds,
                    cost_basis=t.cost_basis,
                    basis_unknown=t.basis_unknown,
                    basis_source=t.basis_source,
                    gross_cash_impact=t.gross_cash_impact,
                    option_strike=(t.option_details.strike if t.option_details else None),
                    option_expiry=(t.option_details.expiry.isoformat() if t.option_details else None),
                    option_call_put=(t.option_details.call_put if t.option_details else None),
                    transfer_date=(t.date.isoformat() if _is_transfer else None),
                    is_section_1256=flag_1256,
                )
                s.add(tr)
                s.flush()
                new_count += 1

            # Cash events use the same import_id. Pre-filter against existing
            # natural keys (and within-batch dups) BEFORE inserting, so we never
            # rely on the UNIQUE-constraint rollback path. A rollback inside this
            # session would unwind the trade rows flushed earlier in the same
            # session — silently dropping just-imported trades. Pre-filtering
            # avoids that risk entirely.
            new_cash = 0
            if cash_events:
                # Pre-fetch existing natural keys WITHIN the same session to
                # avoid a nested Session that would expire ir.
                existing_cash_keys = set(
                    s.exec(select(CashEventRow.natural_key).where(CashEventRow.account_id == account.id)).all()
                )
                seen_in_batch: set[str] = set()
                for ev in cash_events:
                    nk = ev.compute_natural_key()
                    if nk in existing_cash_keys or nk in seen_in_batch:
                        continue
                    seen_in_batch.add(nk)
                    er = CashEventRow(
                        import_id=ir.id,
                        account_id=account.id,
                        natural_key=nk,
                        event_date=ev.event_date.isoformat(),
                        kind=ev.kind,
                        amount=ev.amount,
                        ticker=ev.ticker,
                        description=ev.description or "",
                    )
                    s.add(er)
                    s.flush()
                    new_cash += 1

            # Update import record with final counts and commit everything atomically.
            ir.trade_count = new_count
            # `record.duplicate_trades` is the pre-filter count from the upload
            # route (caller dedup'd against existing_natural_keys). `dup_count`
            # is the runtime UNIQUE-constraint fallback. Sum so the displayed
            # number matches what the user actually skipped.
            ir.duplicate_trades = (record.duplicate_trades or 0) + dup_count
            if cash_events:
                ir.cash_event_count = (ir.cash_event_count or 0) + new_cash
            s.commit()

            return AddImportResult(
                import_id=ir.id,
                new_trades=new_count,
                duplicate_trades=ir.duplicate_trades,
                new_cash_events=new_cash,
            )

    def add_cash_events(self, events: list[CashEvent], *, import_id: int) -> int:
        """Insert cash events; dedupe on (account_id, natural_key). Returns count of NEW rows."""
        if not events:
            return 0
        with Session(self.engine) as s:
            # Group inputs by account_id once so we can pre-fetch existing keys.
            inserted = 0
            account_id_cache: dict[str, int] = {}

            def resolve_aid(display: str) -> int:
                if display in account_id_cache:
                    return account_id_cache[display]
                broker, label = display.split("/", 1)
                row = s.exec(select(AccountRow).where(AccountRow.broker == broker, AccountRow.label == label)).first()
                if row is None:
                    raise LookupError(f"Account {display!r} not found")
                account_id_cache[display] = row.id
                return row.id

            for ev in events:
                aid = resolve_aid(ev.account)
                row = CashEventRow(
                    import_id=import_id,
                    account_id=aid,
                    natural_key=ev.compute_natural_key(),
                    event_date=ev.event_date.isoformat(),
                    kind=ev.kind,
                    amount=ev.amount,
                    ticker=ev.ticker,
                    description=ev.description,
                )
                try:
                    s.add(row)
                    s.flush()
                    inserted += 1
                except Exception:
                    s.rollback()
            s.commit()
            return inserted

    def _row_to_cash_event(self, s: Session, row: CashEventRow) -> CashEvent:
        return CashEvent(
            id=str(row.id),
            account=self._account_display_for_id(s, row.account_id),
            event_date=date.fromisoformat(row.event_date),
            kind=row.kind,
            amount=row.amount,
            ticker=row.ticker,
            description=row.description or "",
        )

    def list_cash_events(
        self,
        *,
        account_id: int | None = None,
        since: date | None = None,
        until: date | None = None,
    ) -> list[CashEvent]:
        with Session(self.engine) as s:
            stmt = select(CashEventRow)
            if account_id is not None:
                stmt = stmt.where(CashEventRow.account_id == account_id)
            if since is not None:
                stmt = stmt.where(CashEventRow.event_date >= since.isoformat())
            if until is not None:
                stmt = stmt.where(CashEventRow.event_date <= until.isoformat())
            stmt = stmt.order_by(CashEventRow.event_date)
            rows = s.exec(stmt).all()
            return [self._row_to_cash_event(s, r) for r in rows]

    # --- Reads ---

    def _row_to_trade(self, row: TradeRow, account_display: str) -> Trade:
        opt = None
        if row.option_strike is not None:
            opt = OptionDetails(
                strike=row.option_strike,
                expiry=date.fromisoformat(row.option_expiry),
                call_put=row.option_call_put,
            )
        return Trade(
            id=str(row.id),
            account=account_display,
            date=date.fromisoformat(row.trade_date),
            ticker=row.ticker,
            action=row.action,
            quantity=row.quantity,
            proceeds=row.proceeds,
            cost_basis=row.cost_basis,
            basis_unknown=row.basis_unknown,
            basis_source=row.basis_source,
            is_manual=row.is_manual,
            transfer_basis_user_set=row.transfer_basis_user_set,
            gross_cash_impact=row.gross_cash_impact,
            option_details=opt,
            transfer_date=(date.fromisoformat(row.transfer_date) if row.transfer_date else None),
            transfer_group_id=row.transfer_group_id,
            is_section_1256=row.is_section_1256,
        )

    def _account_display_for_id(self, s: Session, account_id: int) -> str:
        cached = self._acct_display_cache.get(account_id)
        if cached is not None:
            return cached
        a = s.get(AccountRow, account_id)
        display = f"{a.broker}/{a.label}"
        self._acct_display_cache[account_id] = display
        return display

    def all_trades(self) -> list[Trade]:
        with Session(self.engine) as s:
            rows = s.exec(select(TradeRow)).all()
            return [self._row_to_trade(r, self._account_display_for_id(s, r.account_id)) for r in rows]

    def trades_in_window(self, start: date, end: date) -> list[Trade]:
        with Session(self.engine) as s:
            rows = s.exec(
                select(TradeRow).where(
                    TradeRow.trade_date >= start.isoformat(),
                    TradeRow.trade_date <= end.isoformat(),
                )
            ).all()
            return [self._row_to_trade(r, self._account_display_for_id(s, r.account_id)) for r in rows]

    def trades_for_ticker_in_window(self, ticker: str, sell_date: date, days: int = 30) -> list[Trade]:
        """Return trades for ``ticker`` whose date falls within ±``days`` of ``sell_date``.

        Used by the pre-trade simulator's wash-sale check
        (``engine.lot_selector._check_wash_sale``). The caller is responsible
        for expanding the ticker list with substantially-identical ETF pairs.
        """
        from datetime import timedelta

        lo = sell_date - timedelta(days=days)
        hi = sell_date + timedelta(days=days)
        with Session(self.engine) as s:
            rows = s.exec(
                select(TradeRow).where(
                    TradeRow.ticker == ticker,
                    TradeRow.trade_date >= lo.isoformat(),
                    TradeRow.trade_date <= hi.isoformat(),
                )
            ).all()
            return [self._row_to_trade(r, self._account_display_for_id(s, r.account_id)) for r in rows]

    def trades_for_import(self, import_id: int) -> list[Trade]:
        with Session(self.engine) as s:
            rows = s.exec(select(TradeRow).where(TradeRow.import_id == import_id)).all()
            return [self._row_to_trade(r, self._account_display_for_id(s, r.account_id)) for r in rows]

    def _row_to_lot(self, row: LotRow, account_display: str) -> Lot:
        opt = None
        if row.option_strike is not None:
            opt = OptionDetails(
                strike=row.option_strike,
                expiry=date.fromisoformat(row.option_expiry),
                call_put=row.option_call_put,
            )
        return Lot(
            id=str(row.id),
            trade_id=str(row.trade_id),
            account=account_display,
            date=date.fromisoformat(row.trade_date),
            ticker=row.ticker,
            quantity=row.quantity,
            cost_basis=row.cost_basis,
            adjusted_basis=row.adjusted_basis,
            option_details=opt,
            tacked_acquired_date=(date.fromisoformat(row.tacked_acquired_date) if row.tacked_acquired_date else None),
        )

    def all_lots(self) -> list[Lot]:
        with Session(self.engine) as s:
            rows = s.exec(select(LotRow)).all()
            return [self._row_to_lot(r, self._account_display_for_id(s, r.account_id)) for r in rows]

    def _row_to_violation(self, s: Session, row: WashSaleViolationRow) -> WashSaleViolation:
        return WashSaleViolation(
            id=str(row.id),
            loss_trade_id=str(row.loss_trade_id),
            replacement_trade_id=str(row.replacement_trade_id),
            confidence=row.confidence,
            disallowed_loss=row.disallowed_loss,
            matched_quantity=row.matched_quantity,
            ticker=row.ticker,
            loss_account=self._account_display_for_id(s, row.loss_account_id),
            buy_account=self._account_display_for_id(s, row.buy_account_id),
            loss_sale_date=date.fromisoformat(row.loss_sale_date),
            triggering_buy_date=date.fromisoformat(row.triggering_buy_date),
            source=row.source,
            kind=getattr(row, "kind", "deferred") or "deferred",
        )

    def all_violations(self) -> list[WashSaleViolation]:
        with Session(self.engine) as s:
            rows = s.exec(select(WashSaleViolationRow)).all()
            return [self._row_to_violation(s, r) for r in rows]

    def violations_for_year(self, year: int) -> list[WashSaleViolation]:
        prefix = f"{year}-"
        with Session(self.engine) as s:
            rows = s.exec(
                select(WashSaleViolationRow).where(WashSaleViolationRow.loss_sale_date.startswith(prefix))
            ).all()
            return [self._row_to_violation(s, r) for r in rows]

    def list_distinct_tickers(self) -> list[str]:
        """All distinct tickers across all imported trades, sorted ascending."""
        with Session(self.engine) as s:
            rows = s.exec(select(TradeRow.ticker).distinct().order_by(TradeRow.ticker)).all()
            return list(rows)

    def distinct_held_tickers(self) -> list[str]:
        """Tickers ever traded across all accounts (Buy or Sell)."""
        with Session(self.engine) as s:
            rows = s.exec(text("SELECT DISTINCT ticker FROM trades WHERE action IN ('Buy', 'Sell')")).all()
            return [r[0] for r in rows]

    def distinct_target_tickers(self) -> list[str]:
        """Tickers declared in PositionTargets."""
        with Session(self.engine) as s:
            rows = s.exec(text("SELECT DISTINCT symbol FROM position_targets")).all()
            return [r[0] for r in rows]

    def tickers_with_open_lots(self) -> set[str]:
        """Tickers that have at least one lot row with quantity > 0.

        Approximates "currently held" for palette tier ranking. Cheap;
        a single SELECT DISTINCT against an indexed column.
        """
        with Session(self.engine) as s:
            rows = s.exec(text("SELECT DISTINCT ticker FROM lots WHERE quantity > 0")).all()
            return {r[0] for r in rows}

    def read_plan_snapshot(self) -> dict[str, SnapshotRow]:
        """Return the persisted Plan-view snapshot as a dict keyed by ticker."""
        from net_alpha.portfolio.plan_diff import SnapshotRow

        with Session(self.engine) as s:
            rows = s.exec(
                text("SELECT ticker, target_kind, target_value, risk_pill, pl_bucket FROM plan_view_snapshot")
            ).all()
            return {
                r[0]: SnapshotRow(
                    ticker=r[0],
                    target_kind=r[1],
                    target_value=r[2],
                    risk_pill=r[3],
                    pl_bucket=r[4],
                )
                for r in rows
            }

    def write_plan_snapshot(
        self,
        rows: list[SnapshotRow],
        *,
        taken_at: str,
    ) -> None:
        """Replace the Plan-view snapshot in full. Always wipes prior rows."""
        with Session(self.engine) as s:
            s.exec(text("DELETE FROM plan_view_snapshot"))
            for r in rows:
                s.exec(
                    text(
                        "INSERT INTO plan_view_snapshot "
                        "(ticker, target_kind, target_value, risk_pill, pl_bucket, snapshot_taken_at) "
                        "VALUES (:tk, :kind, :val, :pill, :bucket, :ts)"
                    ).bindparams(
                        tk=r.ticker,
                        kind=r.target_kind,
                        val=r.target_value,
                        pill=r.risk_pill,
                        bucket=r.pl_bucket,
                        ts=taken_at,
                    )
                )
            s.commit()

    def get_plan_last_seen_at(self) -> str | None:
        """Return the ISO 8601 timestamp of the user's last 'Mark as seen' click."""
        with Session(self.engine) as s:
            row = s.exec(text("SELECT value FROM meta WHERE key='plan_last_seen_at'")).first()
            return row[0] if row else None

    def set_plan_last_seen_at(self, when: str) -> None:
        """Upsert the plan_last_seen_at row in `meta`."""
        with Session(self.engine) as s:
            s.exec(
                text(
                    "INSERT INTO meta (key, value) VALUES ('plan_last_seen_at', :v) "
                    "ON CONFLICT(key) DO UPDATE SET value = :v"
                ).bindparams(v=when)
            )
            s.commit()

    def mark_plan_seen(
        self,
        rows: list[SnapshotRow],
        *,
        when: str,
    ) -> None:
        """Atomically rewrite plan_view_snapshot AND set plan_last_seen_at.

        Replaces two sequential commits (write_plan_snapshot + set_plan_last_seen_at)
        with a single transaction so a crash between the snapshot write and the
        timestamp update can never leave the state inconsistent.
        """
        with Session(self.engine) as s:
            s.exec(text("DELETE FROM plan_view_snapshot"))
            for r in rows:
                s.exec(
                    text(
                        "INSERT INTO plan_view_snapshot "
                        "(ticker, target_kind, target_value, risk_pill, pl_bucket, snapshot_taken_at) "
                        "VALUES (:tk, :kind, :val, :pill, :bucket, :ts)"
                    ).bindparams(
                        tk=r.ticker,
                        kind=r.target_kind,
                        val=r.target_value,
                        pill=r.risk_pill,
                        bucket=r.pl_bucket,
                        ts=when,
                    )
                )
            s.exec(
                text(
                    "INSERT INTO meta (key, value) VALUES ('plan_last_seen_at', :v) "
                    "ON CONFLICT(key) DO UPDATE SET value = :v"
                ).bindparams(v=when)
            )
            s.commit()

    def get_trades_for_ticker(self, ticker: str) -> list[Trade]:
        """All trades for a ticker, sorted by trade_date ascending."""
        with Session(self.engine) as s:
            rows = s.exec(select(TradeRow).where(TradeRow.ticker == ticker).order_by(TradeRow.trade_date)).all()
            return [self._row_to_trade(r, self._account_display_for_id(s, r.account_id)) for r in rows]

    def get_lots_for_ticker(self, ticker: str) -> list[Lot]:
        """Open lots for a ticker, sorted by trade_date ascending."""
        with Session(self.engine) as s:
            rows = s.exec(select(LotRow).where(LotRow.ticker == ticker).order_by(LotRow.trade_date)).all()
            return [self._row_to_lot(r, self._account_display_for_id(s, r.account_id)) for r in rows]

    def get_violations_for_ticker(self, ticker: str) -> list[WashSaleViolation]:
        """All violations for a ticker, sorted by loss_sale_date ascending."""
        with Session(self.engine) as s:
            rows = s.exec(
                select(WashSaleViolationRow)
                .where(WashSaleViolationRow.ticker == ticker)
                .order_by(WashSaleViolationRow.loss_sale_date)
            ).all()
            return [self._row_to_violation(s, r) for r in rows]

    # --- Mutations ---

    def remove_import(self, import_id: int) -> RemoveImportResult:
        from datetime import timedelta

        with Session(self.engine) as s:
            trade_rows = s.exec(select(TradeRow).where(TradeRow.import_id == import_id)).all()
            trade_ids = [r.id for r in trade_rows]
            removed_dates = [date.fromisoformat(r.trade_date) for r in trade_rows]

            # Cascade-delete derived rows that reference these trades
            if trade_ids:
                s.exec(LotRow.__table__.delete().where(LotRow.trade_id.in_(trade_ids)))
                s.exec(
                    WashSaleViolationRow.__table__.delete().where(
                        (WashSaleViolationRow.loss_trade_id.in_(trade_ids))
                        | (WashSaleViolationRow.replacement_trade_id.in_(trade_ids))
                    )
                )
                s.exec(LotOverrideRow.__table__.delete().where(LotOverrideRow.trade_id.in_(trade_ids)))
                s.exec(
                    ExemptMatchRow.__table__.delete().where(
                        (ExemptMatchRow.loss_trade_id.in_(trade_ids))
                        | (ExemptMatchRow.triggering_buy_id.in_(trade_ids))
                    )
                )
                s.exec(
                    Section1256ClassificationRow.__table__.delete().where(
                        Section1256ClassificationRow.trade_id.in_(trade_ids)
                    )
                )
            s.exec(TradeRow.__table__.delete().where(TradeRow.import_id == import_id))
            # Delete G/L lots tied to this import (added in schema v2)
            s.exec(RealizedGLLotRow.__table__.delete().where(RealizedGLLotRow.import_id == import_id))
            s.exec(CashEventRow.__table__.delete().where(CashEventRow.import_id == import_id))
            s.exec(ImportRecordRow.__table__.delete().where(ImportRecordRow.id == import_id))
            s.commit()

            if not removed_dates:
                return RemoveImportResult(removed_trade_count=0, recompute_window=None)

            window = (
                min(removed_dates) - timedelta(days=30),
                max(removed_dates) + timedelta(days=30),
            )
            return RemoveImportResult(removed_trade_count=len(trade_ids), recompute_window=window)

    def update_import_aggregates(
        self,
        *,
        import_id: int,
        min_trade_date: date | None,
        max_trade_date: date | None,
        equity_count: int,
        option_count: int,
        option_expiry_count: int,
        parse_warnings: list[str],
    ) -> None:
        """Persist aggregate columns. Used by the backfill helper."""
        with Session(self.engine) as s:
            row = s.get(ImportRecordRow, import_id)
            if row is None:
                raise LookupError(f"Import #{import_id} not found")
            row.min_trade_date = min_trade_date.isoformat() if min_trade_date else None
            row.max_trade_date = max_trade_date.isoformat() if max_trade_date else None
            row.equity_count = equity_count
            row.option_count = option_count
            row.option_expiry_count = option_expiry_count
            row.parse_warnings_json = json.dumps(parse_warnings) if parse_warnings else None
            s.add(row)
            s.commit()

    def get_import_detail(self, import_id: int) -> dict | None:
        """Return a dict of detail-panel fields for the imports detail fragment.

        Includes: aggregate columns, plus an account hint (the first ticker count),
        plus distinct-ticker info pulled live from the joined trade rows.
        Returns None if the import does not exist.
        """
        rec = self.get_import(import_id)
        if rec is None:
            return None
        trades = self.trades_for_import(import_id)
        distinct_tickers = sorted({t.ticker for t in trades})
        with Session(self.engine) as s:
            ir = s.get(ImportRecordRow, import_id)
            account_row = s.exec(select(AccountRow).where(AccountRow.id == ir.account_id)).first()
            broker = account_row.broker if account_row else "unknown"
            label = account_row.label if account_row else "unknown"
            warnings = []
            if ir.parse_warnings_json:
                warnings = json.loads(ir.parse_warnings_json)
            min_td = date.fromisoformat(ir.min_trade_date) if ir.min_trade_date else None
            max_td = date.fromisoformat(ir.max_trade_date) if ir.max_trade_date else None
            equity_count = ir.equity_count or 0
            option_count = ir.option_count or 0
            option_expiry_count = ir.option_expiry_count or 0
            cash_event_count = ir.cash_event_count or 0
        return {
            "id": import_id,
            "broker": broker,
            "account_label": label,
            "csv_filename": rec.csv_filename,
            "min_trade_date": min_td,
            "max_trade_date": max_td,
            "equity_count": equity_count,
            "option_count": option_count,
            "option_expiry_count": option_expiry_count,
            "cash_event_count": cash_event_count,
            "distinct_ticker_count": len(distinct_tickers),
            "tickers_preview": distinct_tickers[:5],
            "parse_warnings": warnings,
        }

    def replace_violations_in_window(self, start: date, end: date, new_violations: list[WashSaleViolation]) -> None:
        with Session(self.engine) as s:
            s.exec(
                WashSaleViolationRow.__table__.delete().where(
                    WashSaleViolationRow.loss_sale_date >= start.isoformat(),
                    WashSaleViolationRow.loss_sale_date <= end.isoformat(),
                )
            )
            for v in new_violations:
                try:
                    s.add(self._violation_to_row(s, v))
                except LookupError:
                    # Schwab G/L violation has no matching Sell trade in the DB
                    # (e.g. G/L imported without Transaction History) — skip silently.
                    pass
            s.commit()

    def _violation_to_row(self, s: Session, v: WashSaleViolation) -> WashSaleViolationRow:
        # account_id resolution by display string ("schwab/personal")
        la = self._account_id_for_display(s, v.loss_account)
        ba = self._account_id_for_display(s, v.buy_account)

        if getattr(v, "source", "engine") == "schwab_g_l":
            # Synthetic IDs like "schwab_gl_<hash>" can't be int()-cast.
            # Resolve to the real TradeRow by matching the Sell trade for this
            # account+ticker+date.  Raise LookupError when none found so the
            # caller can skip this violation cleanly.
            sell_row = s.exec(
                select(TradeRow).where(
                    TradeRow.account_id == la,
                    TradeRow.ticker == v.ticker,
                    TradeRow.action == "Sell",
                    TradeRow.trade_date == v.loss_sale_date.isoformat(),
                )
            ).first()
            if sell_row is None:
                raise LookupError(f"No Sell trade found for Schwab G/L violation on {v.ticker} {v.loss_sale_date}")
            trade_id = sell_row.id
            loss_trade_id = trade_id
            replacement_trade_id = trade_id
        else:
            loss_trade_id = int(v.loss_trade_id)
            replacement_trade_id = int(v.replacement_trade_id)

        return WashSaleViolationRow(
            loss_trade_id=loss_trade_id,
            replacement_trade_id=replacement_trade_id,
            loss_account_id=la,
            buy_account_id=ba,
            loss_sale_date=v.loss_sale_date.isoformat(),
            triggering_buy_date=v.triggering_buy_date.isoformat(),
            ticker=v.ticker,
            confidence=v.confidence,
            disallowed_loss=v.disallowed_loss,
            matched_quantity=v.matched_quantity,
            source=getattr(v, "source", "engine"),
            kind=getattr(v, "kind", "deferred") or "deferred",
        )

    def replace_lots_in_window(self, start: date, end: date, new_lots: list[Lot]) -> None:
        with Session(self.engine) as s:
            s.exec(
                LotRow.__table__.delete().where(
                    LotRow.trade_date >= start.isoformat(),
                    LotRow.trade_date <= end.isoformat(),
                )
            )
            for lot in new_lots:
                s.add(self._lot_to_row(s, lot))
            s.commit()

    def _lot_to_row(self, s: Session, lot: Lot) -> LotRow:
        # account is "schwab/personal"; trade_id is stringified int from _row_to_trade
        return LotRow(
            trade_id=int(lot.trade_id),
            account_id=self._account_id_for_display(s, lot.account),
            ticker=lot.ticker,
            trade_date=lot.date.isoformat(),
            quantity=lot.quantity,
            cost_basis=lot.cost_basis,
            adjusted_basis=lot.adjusted_basis,
            option_strike=(lot.option_details.strike if lot.option_details else None),
            option_expiry=(lot.option_details.expiry.isoformat() if lot.option_details else None),
            option_call_put=(lot.option_details.call_put if lot.option_details else None),
            tacked_acquired_date=(lot.tacked_acquired_date.isoformat() if lot.tacked_acquired_date else None),
        )

    def _account_id_for_display(self, s: Session, display: str) -> int:
        broker, label = display.split("/", 1)
        row = s.exec(select(AccountRow).where(AccountRow.broker == broker, AccountRow.label == label)).first()
        if row is None:
            raise RuntimeError(f"no account row for {display!r}")
        return row.id

    def _account_ids_for_displays(self, s: Session, displays: Sequence[str]) -> list[int]:
        """Resolve a list of 'broker/label' display strings to account IDs.
        Unknown displays are silently dropped."""
        out: list[int] = []
        for d in displays:
            try:
                out.append(self._account_id_for_display(s, d))
            except RuntimeError:
                continue
        return out

    # ----- Realized G/L methods (schema v2) -----

    def add_gl_lots(self, account: Account, import_id: int, lots: list[RealizedGLLot]) -> int:
        """Insert G/L lots, deduplicated on natural_key. Returns count of new rows."""
        if account.id is None:
            raise ValueError("Account must have an id")
        inserted = 0
        with Session(self.engine) as s:
            existing = set(
                s.exec(select(RealizedGLLotRow.natural_key).where(RealizedGLLotRow.account_id == account.id)).all()
            )
            for lot in lots:
                key = lot.compute_natural_key()
                if key in existing:
                    continue
                row = RealizedGLLotRow(
                    import_id=import_id,
                    account_id=account.id,
                    symbol_raw=lot.symbol_raw,
                    ticker=lot.ticker,
                    closed_date=lot.closed_date.isoformat(),
                    opened_date=lot.opened_date.isoformat(),
                    quantity=lot.quantity,
                    proceeds=lot.proceeds,
                    cost_basis=lot.cost_basis,
                    unadjusted_cost_basis=lot.unadjusted_cost_basis,
                    wash_sale=lot.wash_sale,
                    disallowed_loss=lot.disallowed_loss,
                    term=lot.term,
                    option_strike=lot.option_strike,
                    option_expiry=lot.option_expiry,
                    option_call_put=lot.option_call_put,
                    natural_key=key,
                )
                s.add(row)
                existing.add(key)
                inserted += 1
            s.commit()
        return inserted

    def get_gl_lots_for_match(self, *, account_id: int, symbol_raw: str, closed_date: date) -> list[RealizedGLLot]:
        """All G/L lots in this account that match a Sell trade by symbol+closed_date."""
        with Session(self.engine) as s:
            rows = s.exec(
                select(RealizedGLLotRow).where(
                    RealizedGLLotRow.account_id == account_id,
                    RealizedGLLotRow.symbol_raw == symbol_raw,
                    RealizedGLLotRow.closed_date == closed_date.isoformat(),
                )
            ).all()
            account_display = self._account_display_for_id(s, account_id)
        return [self._row_to_gl_lot(r, account_display) for r in rows]

    def get_gl_lots_for_ticker(self, account_id: int, ticker: str) -> list[RealizedGLLot]:
        """All G/L lots for a ticker in this account, sorted by closed_date."""
        with Session(self.engine) as s:
            rows = s.exec(
                select(RealizedGLLotRow)
                .where(
                    RealizedGLLotRow.account_id == account_id,
                    RealizedGLLotRow.ticker == ticker,
                )
                .order_by(RealizedGLLotRow.closed_date)
            ).all()
            account_display = self._account_display_for_id(s, account_id)
        return [self._row_to_gl_lot(r, account_display) for r in rows]

    def _splits_by_symbol(self) -> dict[str, list[tuple[str, float]]]:
        """All splits grouped by symbol as (split_date_iso, ratio) tuples.

        Returned in raw-row form (no Pydantic) so the hot paths that scale GL
        quantities don't pay model-conversion overhead for every row.
        """
        with Session(self.engine) as s:
            rows = s.exec(select(SplitRow)).all()
            out: dict[str, list[tuple[str, float]]] = {}
            for r in rows:
                out.setdefault(r.symbol, []).append((r.split_date, float(r.ratio)))
            return out

    def _post_split_scale(
        self,
        splits_by_symbol: dict[str, list[tuple[str, float]]],
        ticker: str,
        on_date_iso: str,
    ) -> float:
        """Cumulative product of split ratios with split_date > on_date_iso.

        `splits/apply.py` rewrites lot.quantity to post-split units the instant
        a split's ex-date passes; GL rows and trades still hold the
        broker-reported pre-split units until that scaling is applied here.
        """
        splits = splits_by_symbol.get(ticker)
        if not splits:
            return 1.0
        m = 1.0
        for split_date_iso, ratio in splits:
            if split_date_iso > on_date_iso:
                m *= ratio
        return m

    def get_equity_gl_closures(self) -> dict[tuple[str, str], float]:
        """Sum of closed equity quantity per (account_display, ticker) across all
        GL lots, expressed in post-split units to match the split-adjusted
        lot.quantity that ``consume_lots_fifo`` consumes against.

        Used by position aggregations to compute true open quantity when the user
        has imported a Realized G/L CSV without the matching Transaction History
        (so trade-table sells are incomplete). Options are excluded — only rows
        with no option_strike contribute.
        """
        splits_by_symbol = self._splits_by_symbol()
        out: dict[tuple[str, str], float] = {}
        with Session(self.engine) as s:
            rows = s.exec(select(RealizedGLLotRow).where(RealizedGLLotRow.option_strike.is_(None))).all()
            for r in rows:
                display = self._account_display_for_id(s, r.account_id)
                key = (display, r.ticker)
                scale = self._post_split_scale(splits_by_symbol, r.ticker, r.closed_date)
                out[key] = out.get(key, 0.0) + float(r.quantity) * scale
        return out

    def get_option_gl_closures(self) -> dict[tuple[str, str, float, str, str], float]:
        """Sum of closed option-contract quantity per
        (account_display, ticker, strike, expiry_iso, call_put) across all GL
        lots, expressed in post-split units (Schwab applies splits to contract
        count, not the multiplier).

        Used by the open-option counter so contracts that closed via expiry
        worthless or assignment (events Schwab records in GL but not in the
        transaction CSV) don't get double-counted as still open.
        """
        splits_by_symbol = self._splits_by_symbol()
        out: dict[tuple[str, str, float, str, str], float] = {}
        with Session(self.engine) as s:
            rows = s.exec(select(RealizedGLLotRow).where(RealizedGLLotRow.option_strike.is_not(None))).all()
            for r in rows:
                display = self._account_display_for_id(s, r.account_id)
                key = (display, r.ticker, r.option_strike, r.option_expiry, r.option_call_put)
                scale = self._post_split_scale(splits_by_symbol, r.ticker, r.closed_date)
                out[key] = out.get(key, 0.0) + float(r.quantity) * scale
        return out

    def get_gl_lots_for_account(self, account_id: int) -> list[RealizedGLLot]:
        with Session(self.engine) as s:
            rows = s.exec(select(RealizedGLLotRow).where(RealizedGLLotRow.account_id == account_id)).all()
            account_display = self._account_display_for_id(s, account_id)
        return [self._row_to_gl_lot(r, account_display) for r in rows]

    def list_all_gl_lots(self) -> list[RealizedGLLot]:
        """Every Realized G/L lot across all accounts.

        Used by the Closed positions tab to render historical realized lots.
        Sorted by close date descending so most recent closures land at the
        top of the table.
        """
        with Session(self.engine) as s:
            rows = s.exec(select(RealizedGLLotRow).order_by(RealizedGLLotRow.closed_date.desc())).all()
            display_cache: dict[int, str] = {}
            out: list[RealizedGLLot] = []
            for r in rows:
                if r.account_id not in display_cache:
                    display_cache[r.account_id] = self._account_display_for_id(s, r.account_id)
                out.append(self._row_to_gl_lot(r, display_cache[r.account_id]))
        return out

    def _row_to_gl_lot(self, row: RealizedGLLotRow, account_display: str) -> RealizedGLLot:
        return RealizedGLLot(
            account_display=account_display,
            symbol_raw=row.symbol_raw,
            ticker=row.ticker,
            closed_date=date.fromisoformat(row.closed_date),
            opened_date=date.fromisoformat(row.opened_date),
            quantity=row.quantity,
            proceeds=row.proceeds,
            cost_basis=row.cost_basis,
            unadjusted_cost_basis=row.unadjusted_cost_basis,
            wash_sale=row.wash_sale,
            disallowed_loss=row.disallowed_loss,
            term=row.term,
            option_strike=row.option_strike,
            option_expiry=row.option_expiry,
            option_call_put=row.option_call_put,
        )

    # ----- Stitch helpers (schema v2) -----

    def get_sells_for_account(self, account_id: int) -> list[Trade]:
        """All Sell trades in this account. Used by stitch as input set."""
        with Session(self.engine) as s:
            rows = s.exec(
                select(TradeRow).where(
                    TradeRow.account_id == account_id,
                    TradeRow.action == "Sell",
                )
            ).all()
            account_display = self._account_display_for_id(s, account_id)
        return [self._row_to_trade(r, account_display) for r in rows]

    def get_buys_before_date(self, *, account_id: int, ticker: str, before_date: date) -> list[Trade]:
        """Buy trades in this account+ticker on or before `before_date`, oldest first."""
        with Session(self.engine) as s:
            rows = s.exec(
                select(TradeRow)
                .where(
                    TradeRow.account_id == account_id,
                    TradeRow.ticker == ticker,
                    TradeRow.action == "Buy",
                    TradeRow.trade_date <= before_date.isoformat(),
                )
                .order_by(TradeRow.trade_date)
            ).all()
            account_display = self._account_display_for_id(s, account_id)
        return [self._row_to_trade(r, account_display) for r in rows]

    def update_trade_basis(
        self,
        trade_id: str,
        cost_basis: float | None,
        basis_source: str,
        trade_date: date | None = None,
    ) -> None:
        """Persist hydrated cost_basis and basis_source on a Trade row.

        When ``trade_date`` is provided, the row's acquisition date is updated
        too — used by the inline "set basis & date" form on the positions pane
        so transfer-in lots get a real acquisition date instead of the
        broker-statement receipt date.

        Transfer rows (basis_source already in {transfer_in, transfer_out})
        keep their original basis_source — overwriting it with "user_set"
        would erase the transfer semantic and let downstream logic count the
        user-set basis as cash invested. Instead we flip
        ``transfer_basis_user_set=True`` to record the edit.
        """
        with Session(self.engine) as s:
            row = s.exec(select(TradeRow).where(TradeRow.id == int(trade_id))).first()
            if row is None:
                raise LookupError(f"Trade id {trade_id} not found")
            row.cost_basis = cost_basis
            if row.basis_source in ("transfer_in", "transfer_out"):
                row.transfer_basis_user_set = True
            else:
                row.basis_source = basis_source
            if cost_basis is not None:
                row.basis_unknown = False
            if trade_date is not None:
                row.trade_date = trade_date.isoformat()
            s.add(row)
            s.commit()

    def _set_is_manual_for_test(self, trade_id: int, value: bool) -> None:
        """Test-only helper: flip is_manual on a trade row.

        create_manual_trade() forces is_manual=True; tests need to simulate
        imported (non-manual) transfer rows to exercise transfer-only code paths.
        """
        with Session(self.engine) as s:
            row = s.exec(select(TradeRow).where(TradeRow.id == trade_id)).first()
            if row is None:
                raise LookupError(f"Trade id {trade_id} not found")
            row.is_manual = value
            s.add(row)
            s.commit()

    def _resolve_account(self, s: Session, display: str) -> AccountRow:
        if "/" in display:
            broker, label = display.split("/", 1)
        else:
            broker, label = "Manual", display
        row = s.exec(select(AccountRow).where(AccountRow.broker == broker, AccountRow.label == label)).first()
        if row is None:
            raise LookupError(f"Account {display!r} not found — create it via /imports first")
        return row

    def create_manual_trade(self, trade: Trade, etf_pairs: dict[str, list[str]]) -> Trade:
        """Insert a user-entered trade.

        import_id is NULL; natural_key uses the 'manual:' namespace so it
        never collides with a CSV-derived key. Triggers a full wash-sale
        recompute. Returns the persisted Trade with its database id populated.
        """
        from net_alpha.engine.recompute import recompute_all_violations

        with Session(self.engine) as s:
            account = self._resolve_account(s, trade.account)
            nk = f"manual:{uuid4().hex}"
            tr = TradeRow(
                import_id=None,
                account_id=account.id,
                natural_key=nk,
                ticker=trade.ticker,
                trade_date=trade.date.isoformat(),
                action=trade.action,
                quantity=trade.quantity,
                proceeds=trade.proceeds,
                cost_basis=trade.cost_basis,
                basis_unknown=trade.basis_unknown,
                basis_source=trade.basis_source,
                gross_cash_impact=trade.gross_cash_impact,  # NEW
                option_strike=(trade.option_details.strike if trade.option_details else None),
                option_expiry=(trade.option_details.expiry.isoformat() if trade.option_details else None),
                option_call_put=(trade.option_details.call_put if trade.option_details else None),
                is_manual=True,
                transfer_basis_user_set=False,
            )
            s.add(tr)
            s.commit()
            s.refresh(tr)
            saved = self._row_to_trade(tr, self._account_display_for_id(s, tr.account_id))
        recompute_all_violations(self, etf_pairs)
        return saved

    def update_manual_trade(self, trade: Trade, etf_pairs: dict[str, list[str]]) -> Trade:
        """Update a manual trade. Verifies is_manual=True. Preserves natural_key."""
        from net_alpha.engine.recompute import recompute_all_violations

        if trade.id is None:
            raise ValueError("update_manual_trade requires Trade.id")
        with Session(self.engine) as s:
            row = s.exec(select(TradeRow).where(TradeRow.id == int(trade.id))).first()
            if row is None:
                raise LookupError(f"Trade id {trade.id} not found")
            if not row.is_manual:
                raise ValueError("update_manual_trade requires is_manual=True row")
            account = self._resolve_account(s, trade.account)
            row.account_id = account.id
            row.ticker = trade.ticker
            row.trade_date = trade.date.isoformat()
            row.action = trade.action
            row.quantity = trade.quantity
            row.proceeds = trade.proceeds
            row.cost_basis = trade.cost_basis
            row.basis_unknown = trade.basis_unknown
            row.basis_source = trade.basis_source
            row.gross_cash_impact = trade.gross_cash_impact  # NEW
            row.option_strike = trade.option_details.strike if trade.option_details else None
            row.option_expiry = trade.option_details.expiry.isoformat() if trade.option_details else None
            row.option_call_put = trade.option_details.call_put if trade.option_details else None
            # is_manual stays True; natural_key untouched.
            s.add(row)
            s.commit()
            s.refresh(row)
            saved = self._row_to_trade(row, self._account_display_for_id(s, row.account_id))
        recompute_all_violations(self, etf_pairs)
        return saved

    def delete_manual_trade(self, trade_id: str, etf_pairs: dict[str, list[str]]) -> None:
        """Delete a manual trade. Verifies is_manual=True."""
        from net_alpha.engine.recompute import recompute_all_violations

        with Session(self.engine) as s:
            row = s.exec(select(TradeRow).where(TradeRow.id == int(trade_id))).first()
            if row is None:
                raise LookupError(f"Trade id {trade_id} not found")
            if not row.is_manual:
                raise ValueError("delete_manual_trade requires is_manual=True row")
            s.delete(row)
            s.commit()
        recompute_all_violations(self, etf_pairs)

    def split_imported_transfer(
        self,
        trade_id: str,
        segments: list[tuple[date, float, float]],
        etf_pairs: dict[str, list[str]],
    ) -> list[Trade]:
        """Split one imported transfer row into N siblings (date, qty, basis_or_proceeds).

        The user's broker hands them a single transfer row covering shares
        that were originally acquired across multiple lots/dates. This
        method represents that as N siblings sharing a ``transfer_group_id``
        and the original ``transfer_date``.

        Behaviour:
          * Sum of segment quantities must equal the parent's quantity.
          * The first segment overwrites the parent in place (so its
            natural_key is preserved — re-importing the original CSV row
            still dedupes).
          * Remaining segments are inserted as new rows with derived keys
            ``<parent_nk>:seg<i>`` so they don't collide on re-import.
          * If there is exactly one segment, behaves like
            ``update_imported_transfer``.

        Triggers a full wash-sale recompute. Returns all sibling Trades.
        """
        from net_alpha.engine.recompute import recompute_all_violations

        if not segments:
            raise ValueError("at least one segment is required")
        for d, q, b in segments:
            if q <= 0:
                raise ValueError(f"segment quantity must be > 0 (got {q})")
            if b < 0:
                raise ValueError(f"segment basis/proceeds must be >= 0 (got {b})")

        with Session(self.engine) as s:
            row = s.exec(select(TradeRow).where(TradeRow.id == int(trade_id))).first()
            if row is None:
                raise LookupError(f"Trade id {trade_id} not found")
            if row.is_manual:
                raise ValueError("Use update_manual_trade for manual rows")
            if row.basis_source not in ("transfer_in", "transfer_out"):
                raise ValueError(f"split_imported_transfer requires a transfer row; basis_source={row.basis_source!r}")

            # Reuse existing group id if the row was already split before.
            # When re-splitting, the constraint is the ORIGINAL transfer total
            # (parent + existing siblings), not the parent's current segment
            # quantity — otherwise users get locked into the first split.
            group_id = row.transfer_group_id or uuid4().hex
            existing_siblings_qty = 0.0
            if row.transfer_group_id is not None:
                sibling_rows = s.exec(
                    select(TradeRow).where(
                        TradeRow.transfer_group_id == row.transfer_group_id,
                        TradeRow.id != row.id,
                    )
                ).all()
                existing_siblings_qty = sum(sr.quantity for sr in sibling_rows)
            expected_total_qty = row.quantity + existing_siblings_qty

            total_qty = sum(q for _, q, _ in segments)
            # Float-safe equality with a small tolerance — the user types
            # decimal quantities and rounding can drift by 1e-9.
            if abs(total_qty - expected_total_qty) > 1e-6:
                raise ValueError(
                    f"segment quantities sum to {total_qty} but original transfer qty is {expected_total_qty}"
                )

            # Original transfer_date is the broker-statement date — preserve.
            xfer_date = row.transfer_date or row.trade_date

            # Apply first segment to the parent row in place.
            first_date, first_qty, first_basis = segments[0]
            row.trade_date = first_date.isoformat()
            row.quantity = float(first_qty)
            if row.basis_source == "transfer_in":
                row.cost_basis = float(first_basis)
            else:
                row.proceeds = float(first_basis)
            row.transfer_basis_user_set = True
            row.basis_unknown = False
            row.transfer_group_id = group_id
            row.transfer_date = xfer_date
            s.add(row)
            s.flush()  # materialize before sibling natural_keys derive from it

            saved_rows: list[TradeRow] = [row]

            # Remove any prior siblings from a previous split (excluding the
            # parent), so re-splitting starts from a clean slate.
            prior_siblings = s.exec(
                select(TradeRow).where(
                    TradeRow.transfer_group_id == group_id,
                    TradeRow.id != row.id,
                )
            ).all()
            for sib in prior_siblings:
                s.delete(sib)
            s.flush()

            parent_nk = row.natural_key
            for i, (seg_date, seg_qty, seg_basis) in enumerate(segments[1:], start=1):
                sib = TradeRow(
                    import_id=row.import_id,
                    account_id=row.account_id,
                    natural_key=f"{parent_nk}:seg{i}",
                    ticker=row.ticker,
                    trade_date=seg_date.isoformat(),
                    action=row.action,
                    quantity=float(seg_qty),
                    proceeds=(float(seg_basis) if row.basis_source == "transfer_out" else None),
                    cost_basis=(float(seg_basis) if row.basis_source == "transfer_in" else None),
                    basis_unknown=False,
                    basis_source=row.basis_source,
                    is_manual=False,
                    transfer_basis_user_set=True,
                    gross_cash_impact=None,
                    option_strike=row.option_strike,
                    option_expiry=row.option_expiry,
                    option_call_put=row.option_call_put,
                    transfer_date=xfer_date,
                    transfer_group_id=group_id,
                )
                s.add(sib)
                saved_rows.append(sib)

            s.commit()
            for r in saved_rows:
                s.refresh(r)
            saved = [self._row_to_trade(r, self._account_display_for_id(s, r.account_id)) for r in saved_rows]
        recompute_all_violations(self, etf_pairs)
        return saved

    def get_trades_in_transfer_group(self, group_id: str | None) -> list[Trade]:
        """All sibling trades sharing a transfer_group_id, in trade_date order."""
        if not group_id:
            return []
        with Session(self.engine) as s:
            rows = s.exec(
                select(TradeRow)
                .where(TradeRow.transfer_group_id == group_id)
                .order_by(TradeRow.trade_date, TradeRow.id)
            ).all()
            return [self._row_to_trade(r, self._account_display_for_id(s, r.account_id)) for r in rows]

    def update_imported_transfer(
        self,
        trade_id: str,
        new_date: date,
        new_basis_or_proceeds: float,
        etf_pairs: dict[str, list[str]],
    ) -> Trade:
        """Update date + basis (or proceeds) on an imported transfer row.

        Raises ValueError if the row is is_manual=True or basis_source is not
        in {'transfer_in','transfer_out'}.

        Preserves natural_key explicitly so a future re-import of the original
        CSV dedupes against the user's edit.

        Triggers a full wash-sale recompute. Returns the updated Trade.
        """
        from net_alpha.engine.recompute import recompute_all_violations

        with Session(self.engine) as s:
            row = s.exec(select(TradeRow).where(TradeRow.id == int(trade_id))).first()
            if row is None:
                raise LookupError(f"Trade id {trade_id} not found")
            if row.is_manual:
                raise ValueError("Use update_manual_trade for manual rows")
            if row.basis_source not in ("transfer_in", "transfer_out"):
                raise ValueError(f"update_imported_transfer requires a transfer row; basis_source={row.basis_source!r}")
            row.trade_date = new_date.isoformat()
            if row.basis_source == "transfer_in":
                row.cost_basis = new_basis_or_proceeds
            else:  # transfer_out
                row.proceeds = new_basis_or_proceeds
            row.transfer_basis_user_set = True
            row.basis_unknown = False
            # natural_key intentionally untouched.
            s.add(row)
            s.commit()
            s.refresh(row)
            saved = self._row_to_trade(row, self._account_display_for_id(s, row.account_id))
        recompute_all_violations(self, etf_pairs)
        return saved

    # --- Splits ---

    def add_split(
        self,
        symbol: str,
        split_date: date,
        ratio: float,
        source: str,
    ) -> int | None:
        """Insert a split. Returns the new id, or the existing id if (symbol, split_date)
        already exists (no-op for re-fetch). Returns None only on unexpected failure."""
        from datetime import UTC
        from datetime import datetime as _dt

        with Session(self.engine) as s:
            existing = s.exec(
                select(SplitRow).where(
                    SplitRow.symbol == symbol,
                    SplitRow.split_date == split_date.isoformat(),
                )
            ).first()
            if existing is not None:
                return existing.id
            row = SplitRow(
                symbol=symbol,
                split_date=split_date.isoformat(),
                ratio=ratio,
                source=source,
                fetched_at=_dt.now(UTC).isoformat(),
            )
            s.add(row)
            s.commit()
            s.refresh(row)
            return row.id

    def get_splits(self, symbol: str | None = None) -> list[Split]:
        """Return all splits (optionally filtered by symbol), oldest first."""
        from datetime import datetime as _dt

        with Session(self.engine) as s:
            stmt = select(SplitRow)
            if symbol is not None:
                stmt = stmt.where(SplitRow.symbol == symbol)
            stmt = stmt.order_by(SplitRow.split_date)
            rows = s.exec(stmt).all()
            return [
                Split(
                    id=r.id,
                    symbol=r.symbol,
                    split_date=date.fromisoformat(r.split_date),
                    ratio=r.ratio,
                    source=r.source,
                    fetched_at=_dt.fromisoformat(r.fetched_at),
                )
                for r in rows
            ]

    # --- Lot overrides ---

    def add_lot_override(
        self,
        trade_id: int,
        field: str,
        old_value: float,
        new_value: float,
        reason: str,
        split_id: int | None = None,
    ) -> int:
        from datetime import UTC
        from datetime import datetime as _dt

        with Session(self.engine) as s:
            row = LotOverrideRow(
                trade_id=trade_id,
                field=field,
                old_value=old_value,
                new_value=new_value,
                reason=reason,
                split_id=split_id,
                edited_at=_dt.now(UTC).isoformat(),
            )
            s.add(row)
            s.commit()
            s.refresh(row)
            return row.id

    def get_lot_overrides_for_trade(self, trade_id: int) -> list[LotOverride]:
        from datetime import datetime as _dt

        with Session(self.engine) as s:
            rows = s.exec(
                select(LotOverrideRow).where(LotOverrideRow.trade_id == trade_id).order_by(LotOverrideRow.edited_at)
            ).all()
            return [
                LotOverride(
                    id=r.id,
                    trade_id=r.trade_id,
                    field=r.field,
                    old_value=r.old_value,
                    new_value=r.new_value,
                    reason=r.reason,
                    edited_at=_dt.fromisoformat(r.edited_at),
                    split_id=r.split_id,
                )
                for r in rows
            ]

    def all_lot_overrides(self) -> list[LotOverride]:
        """All overrides across all trades, used by the post-recompute applier."""
        from datetime import datetime as _dt

        with Session(self.engine) as s:
            rows = s.exec(select(LotOverrideRow).order_by(LotOverrideRow.edited_at)).all()
            return [
                LotOverride(
                    id=r.id,
                    trade_id=r.trade_id,
                    field=r.field,
                    old_value=r.old_value,
                    new_value=r.new_value,
                    reason=r.reason,
                    edited_at=_dt.fromisoformat(r.edited_at),
                    split_id=r.split_id,
                )
                for r in rows
            ]

    def get_split_overrides_for_trade(self, trade_id: int, split_id: int) -> list[LotOverrideRow]:
        """Used by apply_split to check idempotency: 'have I already applied this split to this trade?'"""
        with Session(self.engine) as s:
            rows = s.exec(
                select(LotOverrideRow).where(
                    LotOverrideRow.trade_id == trade_id,
                    LotOverrideRow.split_id == split_id,
                )
            ).all()
            return list(rows)

    def get_lot_rows_for_symbol(self, symbol: str) -> list:
        """Return raw LotRow records (NOT domain Lot) so the splits applier
        can mutate them by id. Open-only is the default since closed lots are
        irrelevant to the user's current holdings; for split application we
        also want closed lots so historical wash-sale data stays correct."""
        with Session(self.engine) as s:
            rows = s.exec(select(LotRow).where(LotRow.ticker == symbol)).all()
            # Detach from session by copying to dicts; caller will mutate via update_lot_qty_and_basis.
            return [
                {
                    "id": r.id,
                    "trade_id": r.trade_id,
                    "ticker": r.ticker,
                    "trade_date": r.trade_date,
                    "quantity": r.quantity,
                    "adjusted_basis": r.adjusted_basis,
                    "cost_basis": r.cost_basis,
                }
                for r in rows
            ]

    def update_lot_qty_and_basis(self, lot_id: int, *, quantity: float, adjusted_basis: float) -> None:
        with Session(self.engine) as s:
            row = s.get(LotRow, lot_id)
            if row is None:
                return
            row.quantity = quantity
            row.adjusted_basis = adjusted_basis
            s.add(row)
            s.commit()

    def get_lot_row_dict_by_id(self, lot_id: int) -> dict | None:
        """Return raw lot data for a single lot by id, as a detached dict.
        Returns None if not found. Mirrors the dict shape used by
        get_lot_rows_for_symbol so consumers can mutate via update_lot_qty_and_basis."""
        with Session(self.engine) as s:
            r = s.get(LotRow, lot_id)
            if r is None:
                return None
            return {
                "id": r.id,
                "trade_id": r.trade_id,
                "ticker": r.ticker,
                "trade_date": r.trade_date,
                "quantity": r.quantity,
                "adjusted_basis": r.adjusted_basis,
                "cost_basis": r.cost_basis,
            }

    def get_lot_row_dict_by_trade_id(self, trade_id: int) -> dict | None:
        """Return raw lot data for the lot belonging to a given trade_id.
        Returns None if not found."""
        with Session(self.engine) as s:
            r = s.exec(select(LotRow).where(LotRow.trade_id == trade_id)).first()
            if r is None:
                return None
            return {
                "id": r.id,
                "trade_id": r.trade_id,
                "ticker": r.ticker,
                "trade_date": r.trade_date,
                "quantity": r.quantity,
                "adjusted_basis": r.adjusted_basis,
                "cost_basis": r.cost_basis,
            }

    def get_trade_by_id(self, trade_id: int) -> Trade | None:
        """Return the domain Trade for the given primary-key id, or None."""
        with Session(self.engine) as s:
            row = s.get(TradeRow, trade_id)
            if row is None:
                return None
            return self._row_to_trade(row, self._account_display_for_id(s, row.account_id))

    # ---- ExemptMatch ----

    def save_exempt_matches(self, matches: list[ExemptMatch]) -> None:
        """Persist exempt matches. Caller is responsible for clear_exempt_matches() before
        a full recompute to avoid duplicates."""
        with Session(self.engine) as session:
            for m in matches:
                session.add(
                    ExemptMatchRow(
                        loss_trade_id=int(m.loss_trade_id),
                        triggering_buy_id=int(m.triggering_buy_id),
                        exempt_reason=m.exempt_reason,
                        rule_citation=m.rule_citation,
                        notional_disallowed=m.notional_disallowed,
                        confidence=m.confidence,
                        matched_quantity=m.matched_quantity,
                        loss_account=m.loss_account,
                        buy_account=m.buy_account,
                        loss_sale_date=m.loss_sale_date.isoformat(),
                        triggering_buy_date=m.triggering_buy_date.isoformat(),
                        ticker=m.ticker,
                    )
                )
            session.commit()

    def clear_exempt_matches(self) -> None:
        with Session(self.engine) as session:
            session.exec(ExemptMatchRow.__table__.delete())
            session.commit()

    def list_exempt_matches(
        self,
        *,
        accounts: Sequence[str] | None = None,
        year: int | None = None,
    ) -> list[ExemptMatchRow]:
        effective: list[str] = list(accounts) if accounts else []
        with Session(self.engine) as session:
            stmt = select(ExemptMatchRow)
            if effective:
                stmt = stmt.where(
                    ExemptMatchRow.loss_account.in_(effective) | ExemptMatchRow.buy_account.in_(effective)
                )
            if year is not None:
                stmt = stmt.where(ExemptMatchRow.loss_sale_date.startswith(f"{year}-"))
            return list(session.exec(stmt).all())

    # ---- Section1256Classification ----

    def save_section_1256_classifications(self, classifications: list[Section1256Classification]) -> None:
        """Upsert by trade_id (unique). Replaces prior classification for the same trade."""
        with Session(self.engine) as session:
            for c in classifications:
                session.exec(
                    Section1256ClassificationRow.__table__.delete().where(
                        Section1256ClassificationRow.trade_id == int(c.trade_id)
                    )
                )
                session.add(
                    Section1256ClassificationRow(
                        trade_id=int(c.trade_id),
                        realized_pnl=c.realized_pnl,
                        long_term_portion=c.long_term_portion,
                        short_term_portion=c.short_term_portion,
                        underlying=c.underlying,
                    )
                )
            session.commit()

    def clear_section_1256_classifications(self) -> None:
        with Session(self.engine) as session:
            session.exec(Section1256ClassificationRow.__table__.delete())
            session.commit()

    def delete_violations_by_id(self, violation_ids: list[int]) -> None:
        """Delete WashSaleViolationRows by primary key. No-op if list is empty."""
        if not violation_ids:
            return
        with Session(self.engine) as s:
            s.exec(WashSaleViolationRow.__table__.delete().where(WashSaleViolationRow.id.in_(violation_ids)))
            s.commit()

    def set_section_1256_flag(self, trade_ids: list[int]) -> None:
        """Backfill is_section_1256=True on the given trades. Used by migrations.
        Accepts integer trade IDs (matches delete_violations_by_id signature)."""
        if not trade_ids:
            return
        with Session(self.engine) as s:
            s.exec(TradeRow.__table__.update().where(TradeRow.id.in_(trade_ids)).values(is_section_1256=True))
            s.commit()

    def list_section_1256_classifications(
        self,
        *,
        accounts: Sequence[str] | None = None,
        year: int | None = None,
    ) -> list[Section1256ClassificationRow]:
        effective: list[str] = list(accounts) if accounts else []
        with Session(self.engine) as session:
            if effective or year is not None:
                # Join to TradeRow to apply account/year filters
                stmt = select(Section1256ClassificationRow).join(
                    TradeRow, TradeRow.id == Section1256ClassificationRow.trade_id
                )
                if effective:
                    acct_ids = self._account_ids_for_displays(session, effective)
                    if not acct_ids:
                        return []
                    stmt = stmt.where(TradeRow.account_id.in_(acct_ids))
                if year is not None:
                    stmt = stmt.where(TradeRow.trade_date.startswith(f"{year}-"))
            else:
                stmt = select(Section1256ClassificationRow)
            return list(session.exec(stmt).all())

    # ---- Section1256MTM (year-end mark-to-market) ----

    def save_section_1256_mtm(self, rows: list[Section1256MTM]) -> None:
        """Idempotent upsert by (position_key, tax_year)."""
        if not rows:
            return
        with Session(self.engine) as session:
            for r in rows:
                session.exec(
                    Section1256MTMRow.__table__.delete().where(
                        (Section1256MTMRow.position_key == r.position_key) & (Section1256MTMRow.tax_year == r.tax_year)
                    )
                )
                session.add(
                    Section1256MTMRow(
                        position_key=r.position_key,
                        tax_year=r.tax_year,
                        last_business_day=r.last_business_day.isoformat(),
                        fmv=r.fmv,
                        basis_before=r.basis_before,
                        unrealized_pnl=r.unrealized_pnl,
                        long_term_portion=r.long_term_portion,
                        short_term_portion=r.short_term_portion,
                        fmv_source=r.fmv_source,
                        ticker=r.ticker,
                        account=r.account,
                    )
                )
            session.commit()

    def clear_section_1256_mtm(self) -> None:
        """Delete all MTM rows."""
        with Session(self.engine) as session:
            session.exec(Section1256MTMRow.__table__.delete())
            session.commit()

    def section_1256_mtm_rows(self, period, accounts: Sequence[str] | None = None) -> list[Section1256MTM]:
        """Return MTM rows filtered by period and optional account."""
        effective: list[str] = list(accounts) if accounts else []
        with Session(self.engine) as session:
            stmt = select(Section1256MTMRow)
            if period.kind == "year" and period.year is not None:
                stmt = stmt.where(Section1256MTMRow.tax_year == period.year)
            if effective:
                stmt = stmt.where(Section1256MTMRow.account.in_(effective))
            rows = session.exec(stmt).all()
            return [
                Section1256MTM(
                    position_key=r.position_key,
                    tax_year=r.tax_year,
                    last_business_day=date.fromisoformat(r.last_business_day),
                    fmv=r.fmv,
                    basis_before=r.basis_before,
                    unrealized_pnl=r.unrealized_pnl,
                    long_term_portion=r.long_term_portion,
                    short_term_portion=r.short_term_portion,
                    fmv_source=r.fmv_source,
                    ticker=r.ticker,
                    account=r.account,
                )
                for r in rows
            ]

    def section_1256_mtm_pnl(self, period, accounts: Sequence[str] | None = None) -> Decimal:
        """Sum of unrealized_pnl across all MTM rows matching period and account."""
        rows = self.section_1256_mtm_rows(period, accounts=accounts)
        total = Decimal("0")
        for r in rows:
            total += r.unrealized_pnl
        return total

    def prior_year_mtm_basis_for_position(self, position_key: str, year: int) -> Decimal | None:
        """FMV at end of `year` for `position_key` — becomes basis_before for `year+1`."""
        with Session(self.engine) as session:
            stmt = (
                select(Section1256MTMRow)
                .where(Section1256MTMRow.position_key == position_key)
                .where(Section1256MTMRow.tax_year == year)
            )
            row = session.exec(stmt).first()
            return row.fmv if row is not None else None

    def get_violation(self, vid: int):
        """Return WashSaleViolationRow by primary key, or None."""
        with Session(self.engine) as session:
            return session.get(WashSaleViolationRow, vid)

    def get_exempt_match(self, eid: int):
        """Return ExemptMatchRow by primary key, or None."""
        with Session(self.engine) as session:
            return session.get(ExemptMatchRow, eid)

    # ---- After-tax helpers (Task 17) ----

    def realized_pnl_split(self, period, accounts: Sequence[str] | None = None) -> dict[str, Decimal]:
        """Return {'short_term': Decimal, 'long_term': Decimal} for closed non-§1256 lots.

        Draws from RealizedGLLotRow (broker-sourced Realized G/L CSV).
        Term is determined by the broker-supplied `term` column ("Short Term" / "Long Term").
        P&L per lot = proceeds - cost_basis (uses the wash-sale-adjusted cost_basis column).
        """
        effective: list[str] = list(accounts) if accounts else []
        st = Decimal("0")
        lt = Decimal("0")
        with Session(self.engine) as session:
            stmt = select(RealizedGLLotRow)
            if effective:
                acct_ids = self._account_ids_for_displays(session, effective)
                if not acct_ids:
                    return {"short_term": Decimal("0"), "long_term": Decimal("0")}
                stmt = stmt.where(RealizedGLLotRow.account_id.in_(acct_ids))
            if period.kind != "lifetime":
                stmt = stmt.where(RealizedGLLotRow.closed_date.startswith(f"{period.year}-"))
            # Exclude broad-based index option lots (§1256 contracts) — these are
            # accounted for separately via section_1256_pnl. Both sides of the AND
            # must hold to be excluded: (a) ticker is in the §1256 universe, and
            # (b) the row represents an option (option_strike is not None).
            universe = load_universe()
            if universe:
                stmt = stmt.where(
                    ~(RealizedGLLotRow.ticker.in_(universe) & RealizedGLLotRow.option_strike.is_not(None))
                )
            rows = session.exec(stmt).all()
            for r in rows:
                pnl = Decimal(str(r.proceeds)) - Decimal(str(r.cost_basis))
                if r.term == "Long Term":
                    lt += pnl
                else:
                    st += pnl
        return {"short_term": st, "long_term": lt}

    def section_1256_pnl(self, period, accounts: Sequence[str] | None = None) -> Decimal:
        """Total realized P&L for §1256 contracts in the period.

        Draws from Section1256ClassificationRow (engine-derived). The realized_pnl
        field is the net gain/loss already; 60/40 LT/ST split is applied by
        compute_after_tax, not here.
        """
        effective: list[str] = list(accounts) if accounts else []
        with Session(self.engine) as session:
            stmt = select(Section1256ClassificationRow).join(
                TradeRow, TradeRow.id == Section1256ClassificationRow.trade_id
            )
            if effective:
                acct_ids = self._account_ids_for_displays(session, effective)
                if not acct_ids:
                    return Decimal("0")
                stmt = stmt.where(TradeRow.account_id.in_(acct_ids))
            if period.kind != "lifetime":
                stmt = stmt.where(TradeRow.trade_date.startswith(f"{period.year}-"))
            rows = session.exec(stmt).all()
            total = Decimal("0")
            for r in rows:
                total += Decimal(str(r.realized_pnl))
        return total

    def wash_sale_disallowed_total(self, period, accounts: Sequence[str] | None = None) -> Decimal:
        """Total disallowed loss amount for wash-sale violations in the period.

        Draws from WashSaleViolationRow. Account filter matches violations where
        the loss account OR the triggering buy account is the specified account.
        """
        by_kind = self.wash_sale_disallowed_by_kind(period, accounts=accounts)
        return sum(by_kind.values(), Decimal("0"))

    def wash_sale_disallowed_by_kind(self, period, accounts: Sequence[str] | None = None) -> dict[str, Decimal]:
        """Disallowed loss totals split by ``WashSaleViolation.kind``.

        Returns ``{"deferred": <amount>, "permanent_ira": <amount>}``. The
        permanent_ira bucket holds Rev. Rul. 2008-5 disallowances (loss is gone
        forever — no §1091(d) basis rollover); deferred holds ordinary
        §1091 wash sales whose disallowed loss adds to the replacement lot's
        basis. Always returns both keys (zero when none present) so callers
        can format without conditional logic.
        """
        effective: list[str] = list(accounts) if accounts else []
        with Session(self.engine) as session:
            stmt = select(WashSaleViolationRow.kind, WashSaleViolationRow.disallowed_loss)
            if effective:
                acct_ids = self._account_ids_for_displays(session, effective)
                if not acct_ids:
                    return {"deferred": Decimal("0"), "permanent_ira": Decimal("0")}
                stmt = stmt.where(
                    WashSaleViolationRow.loss_account_id.in_(acct_ids)
                    | WashSaleViolationRow.buy_account_id.in_(acct_ids)
                )
            if period.kind != "lifetime":
                stmt = stmt.where(WashSaleViolationRow.loss_sale_date.startswith(f"{period.year}-"))
            out: dict[str, Decimal] = {"deferred": Decimal("0"), "permanent_ira": Decimal("0")}
            for kind, amount in session.exec(stmt).all():
                bucket = kind if kind in out else "deferred"
                out[bucket] += Decimal(str(amount))
        return out

    # ---- Position Targets ----

    def list_targets(self) -> list[PositionTarget]:
        """Return all position targets sorted alphabetically by symbol,
        each with its tag tuple populated. One round trip for tags."""
        with Session(self.engine) as s:
            rows = s.exec(select(PositionTargetRow).order_by(PositionTargetRow.symbol)).all()
            tag_rows = s.exec(text("SELECT target_symbol, tag FROM position_target_tag ORDER BY tag")).all()
        tags_by_sym: dict[str, list[str]] = {}
        for sym, tag in tag_rows:
            tags_by_sym.setdefault(sym, []).append(tag)
        return [self._row_to_target(r, tuple(tags_by_sym.get(r.symbol, ()))) for r in rows]

    def list_targets_by_manual_order(self) -> list[PositionTarget]:
        """Return all position targets ordered by sort_order ASC, with
        symbol ASC as the deterministic tiebreaker. Used by the Plan tab's
        Manual sort mode. Tags are populated in one round trip."""
        with Session(self.engine) as s:
            rows = s.exec(
                select(PositionTargetRow).order_by(PositionTargetRow.sort_order, PositionTargetRow.symbol)
            ).all()
            tag_rows = s.exec(text("SELECT target_symbol, tag FROM position_target_tag ORDER BY tag")).all()
        tags_by_sym: dict[str, list[str]] = {}
        for sym, tag in tag_rows:
            tags_by_sym.setdefault(sym, []).append(tag)
        return [self._row_to_target(r, tuple(tags_by_sym.get(r.symbol, ()))) for r in rows]

    def get_target(self, symbol: str) -> PositionTarget | None:
        """Return the target for `symbol` (case-insensitive), or None if absent.
        Tag tuple is populated."""
        sym = symbol.upper()
        with Session(self.engine) as s:
            row = s.exec(select(PositionTargetRow).where(PositionTargetRow.symbol == sym)).first()
            if row is None:
                return None
            tag_rows = s.exec(
                text("SELECT tag FROM position_target_tag WHERE target_symbol = :sym ORDER BY tag"),
                params={"sym": sym},
            ).all()
        return self._row_to_target(row, tuple(r[0] for r in tag_rows))

    def upsert_target(self, symbol: str, amount: Decimal, unit: TargetUnit) -> PositionTarget:
        """Create or update the position target for `symbol`.

        On insert, created_at and updated_at are both set to now and
        sort_order is set to MAX(sort_order) + 1 (new targets append to
        the end of the manual order). On update, only target_amount,
        target_unit, and updated_at change; created_at and sort_order are
        preserved.
        """
        sym = symbol.upper()
        now = datetime.now(UTC).isoformat()
        with Session(self.engine) as s:
            row = s.exec(select(PositionTargetRow).where(PositionTargetRow.symbol == sym)).first()
            if row is None:
                max_so = s.exec(text("SELECT COALESCE(MAX(sort_order), 0) FROM position_targets")).first()
                next_so = int(max_so[0]) + 1 if max_so else 1
                row = PositionTargetRow(
                    symbol=sym,
                    target_amount=amount,
                    target_unit=unit.value,
                    created_at=now,
                    updated_at=now,
                    sort_order=next_so,
                )
            else:
                row.target_amount = amount
                row.target_unit = unit.value
                row.updated_at = now
            s.add(row)
            s.commit()
            s.refresh(row)
            return self._row_to_target(row)

    def delete_target(self, symbol: str) -> bool:
        """Delete the target for `symbol`. Returns True if deleted, False if not found."""
        sym = symbol.upper()
        with Session(self.engine) as s:
            row = s.exec(select(PositionTargetRow).where(PositionTargetRow.symbol == sym)).first()
            if row is None:
                return False
            # Application-level cascade: SQLite FK ON DELETE CASCADE only fires
            # when foreign_keys=ON AND the table was created via the v16 migration
            # path (not SQLModel.metadata.create_all on fresh installs). Belt and
            # suspenders so orphan tag rows can't leak into list_all_tags.
            s.exec(
                text("DELETE FROM position_target_tag WHERE target_symbol = :sym"),
                params={"sym": sym},
            )
            s.delete(row)
            s.commit()
        return True

    def set_target_order(self, symbols: Sequence[str]) -> None:
        """Atomically rewrite the manual ordering of targets.

        For each symbol in `symbols` (case-insensitive), set its
        sort_order to its 1-indexed position in the list.

        - Symbols absent from the input list keep their existing
          sort_order (defensive against a stale browser POST that omits
          a recently-added symbol).
        - Unknown symbols in the input list are silently dropped.
        - All writes happen in a single transaction; partial failure
          leaves prior order intact.

        An empty list is a no-op.
        """
        if not symbols:
            return
        normalized = [s.upper() for s in symbols if s and s.strip()]
        with Session(self.engine) as s:
            position = 1
            for sym in normalized:
                result = s.exec(
                    text("UPDATE position_targets SET sort_order = :so WHERE symbol = :sym"),
                    params={"so": position, "sym": sym},
                )
                # Only advance the position counter if the row existed.
                # SQLAlchemy returns a Result whose rowcount is reliable
                # for single-row UPDATEs in SQLite.
                if result.rowcount > 0:
                    position += 1
            s.commit()

    # ---- Position Target Tags (M:N) ----

    def list_target_tags(self, symbol: str) -> tuple[str, ...]:
        """Return tags for `symbol` (case-insensitive), alpha-sorted."""
        sym = symbol.upper()
        with Session(self.engine) as s:
            rows = s.exec(
                text("SELECT tag FROM position_target_tag WHERE target_symbol = :sym ORDER BY tag"),
                params={"sym": sym},
            ).all()
        return tuple(r[0] for r in rows)

    def set_target_tags(self, symbol: str, tags: Sequence[str]) -> None:
        """Atomically replace the tag set for `symbol`.

        Inputs are normalized through ``normalize_tags`` (lowercase,
        deduped, alpha-sorted, invalid items dropped). Whole-tag-set
        replace runs inside a single transaction so a failure mid-write
        leaves the prior set intact.
        """
        sym = symbol.upper()
        normalized = normalize_tags(tags)
        with Session(self.engine) as s:
            s.exec(
                text("DELETE FROM position_target_tag WHERE target_symbol = :sym"),
                params={"sym": sym},
            )
            for t in normalized:
                s.exec(
                    text("INSERT INTO position_target_tag(target_symbol, tag) VALUES (:sym, :tag)"),
                    params={"sym": sym, "tag": t},
                )
            s.commit()

    def add_target_tag(self, symbol: str, tag: str) -> bool:
        """Add a single tag. Returns True if the tag is now present, False
        if the input was invalid (and the set is unchanged). Idempotent."""
        norm = normalize_tag(tag)
        if norm is None:
            return False
        sym = symbol.upper()
        with Session(self.engine) as s:
            s.exec(
                text("INSERT OR IGNORE INTO position_target_tag(target_symbol, tag) VALUES (:sym, :tag)"),
                params={"sym": sym, "tag": norm},
            )
            s.commit()
        return True

    def remove_target_tag(self, symbol: str, tag: str) -> None:
        """Remove a single tag. Idempotent (no-op if absent)."""
        norm = normalize_tag(tag)
        if norm is None:
            return
        sym = symbol.upper()
        with Session(self.engine) as s:
            s.exec(
                text("DELETE FROM position_target_tag WHERE target_symbol = :sym AND tag = :tag"),
                params={"sym": sym, "tag": norm},
            )
            s.commit()

    def list_all_tags(self) -> tuple[str, ...]:
        """Union of all tags currently in use, alpha-sorted, deduped."""
        with Session(self.engine) as s:
            rows = s.exec(text("SELECT DISTINCT tag FROM position_target_tag ORDER BY tag")).all()
        return tuple(r[0] for r in rows)

    @staticmethod
    def _row_to_target(
        row: PositionTargetRow,
        tags: tuple[str, ...] = (),
    ) -> PositionTarget:
        return PositionTarget(
            symbol=row.symbol,
            target_amount=Decimal(str(row.target_amount)),
            target_unit=TargetUnit(row.target_unit),
            created_at=datetime.fromisoformat(row.created_at),
            updated_at=datetime.fromisoformat(row.updated_at),
            tags=tags,
            sort_order=row.sort_order,
        )

    # ---- Overview Layout (per-profile row order + hidden set) ----

    def get_overview_layout(self, profile: str) -> OverviewLayout:
        """Return the saved layout for `profile`, or the default on miss/error."""
        with Session(self.engine) as s:
            row = s.exec(
                text("SELECT layout_json FROM overview_layout WHERE profile = :p").bindparams(p=profile)
            ).first()
        if row is None:
            return default_overview_layout()
        try:
            data = json.loads(row[0])
            raw = OverviewLayout(**data)
        except (json.JSONDecodeError, ValueError, TypeError) as exc:
            log.warning(
                "get_overview_layout: bad JSON for %r — falling back to default (%s)",
                profile,
                exc,
            )
            return default_overview_layout()
        return _sanitize_overview_layout(raw)

    def set_overview_layout(self, profile: str, layout: OverviewLayout) -> None:
        """UPSERT the saved layout for `profile`. Sanitizes before write."""
        clean = _sanitize_overview_layout(layout)
        payload = json.dumps({"rows": clean.rows, "hidden": clean.hidden})
        now = datetime.now(UTC).isoformat()
        with Session(self.engine) as s:
            s.exec(
                text(
                    "INSERT INTO overview_layout(profile, layout_json, updated_at) "
                    "VALUES (:p, :j, :u) "
                    "ON CONFLICT(profile) DO UPDATE SET layout_json = :j, updated_at = :u"
                ).bindparams(p=profile, j=payload, u=now)
            )
            s.commit()

    def clear_overview_layout(self, profile: str) -> None:
        with Session(self.engine) as s:
            s.exec(text("DELETE FROM overview_layout WHERE profile = :p").bindparams(p=profile))
            s.commit()

    # ---- Carryforward derivation adapters ----

    def earliest_trade_year(self) -> int | None:
        """Year of the earliest realized close in the DB. None if no trades."""
        with Session(self.engine) as s:
            row = s.exec(select(TradeRow.trade_date).order_by(TradeRow.trade_date).limit(1)).first()
        if row is None:
            return None
        # trade_date is YYYY-MM-DD string; first 4 chars are year.
        return int(row[:4])

    def realized_pnl_split_by_year(self, year: int) -> tuple[Decimal, Decimal]:
        """Return (st_pnl, lt_pnl) signed for the given calendar year.

        ST/LT classification:
        - FIFO-match each sell to a buy lot (same account+ticker, lot date
          <= sell date); consume lot quantity as sells walk forward in time.
        - Holding period uses ``Lot.effective_acquired_date`` so IRC §1223(4)
          wash-sale tacking is honored (a replacement lot's clock includes
          the time held in the wash-triggering loss-side lot).
        - When no Lot rows exist for an (account, ticker) — e.g. trades were
          inserted without a subsequent wash-sale recompute — fall back to
          synthesizing a FIFO chain from Buy trades. The fallback gives correct
          FIFO consumption but cannot honor tacking (no tacked_acquired_date
          to read).
        - Long-term threshold: > 365 days.
        - Equities only — option sells are skipped.
        - Sells with no available prior lot/trade fall back to ST.
        """
        st = Decimal("0")
        lt = Decimal("0")
        all_trades = self.all_trades()
        all_lots = self.all_lots()

        # Per (account, ticker) chain of "lot-like" donors with FIFO ordering,
        # remaining quantity, and effective acquired date. Lots win when
        # present; otherwise we synthesize from Buy trades.
        @dataclass
        class _Donor:
            key: str
            sort_date: date
            eff_date: date
            quantity: float

        chains: dict[tuple[str, str], list[_Donor]] = {}
        keys_with_lots: set[tuple[str, str]] = set()
        for lot in all_lots:
            if lot.option_details is not None:
                continue  # equities only
            k = (lot.account, lot.ticker)
            keys_with_lots.add(k)
            chains.setdefault(k, []).append(
                _Donor(
                    key=f"lot:{lot.id}",
                    sort_date=lot.date,
                    eff_date=lot.effective_acquired_date(),
                    quantity=lot.quantity,
                )
            )
        # Trade-based fallback: include Buys whose (account, ticker) had no
        # lot rows at all. (Mixed states for a single ticker fall on the lot
        # side — once recompute has run, the engine is authoritative.)
        for t in all_trades:
            if t.option_details is not None:
                continue
            if t.action.lower() not in {"buy", "buy to open"}:
                continue
            k = (t.account, t.ticker)
            if k in keys_with_lots:
                continue
            chains.setdefault(k, []).append(
                _Donor(
                    key=f"trade:{t.id}",
                    sort_date=t.date,
                    eff_date=t.date,
                    quantity=t.quantity,
                )
            )
        for chain in chains.values():
            chain.sort(key=lambda d: d.sort_date)

        # Walk sells in chronological order so prior-year consumption is
        # reflected when classifying current-year sells.
        sells = sorted(
            [
                t
                for t in all_trades
                if t.action.lower() == "sell"
                and t.option_details is None
                and t.proceeds is not None
                and t.cost_basis is not None
            ],
            key=lambda t: t.date,
        )

        for sell in sells:
            chain = chains.get((sell.account, sell.ticker), [])
            qty_to_match = sell.quantity
            consumed: list[tuple[float, date]] = []
            for donor in chain:
                if donor.sort_date > sell.date:
                    break
                if donor.quantity <= 0:
                    continue
                take = min(qty_to_match, donor.quantity)
                donor.quantity -= take
                consumed.append((take, donor.eff_date))
                qty_to_match -= take
                if qty_to_match <= 0:
                    break

            if sell.date.year != year:
                continue  # consumption recorded; classification only for target year

            pnl = Decimal(str(sell.proceeds)) - Decimal(str(sell.cost_basis))
            if not consumed:
                # Orphan sell — no prior donor available. Conservative: ST.
                st += pnl
                continue

            # Per-share allocation across consumed donor fragments.
            total_consumed_qty = sum(q for q, _ in consumed)
            for take, eff_date in consumed:
                share = Decimal(str(take)) / Decimal(str(total_consumed_qty))
                portion = pnl * share
                days = (sell.date - eff_date).days
                if days > 365:
                    lt += portion
                else:
                    st += portion
        return st, lt

    # ---- Carryforward overrides ----

    def get_carryforward_override(self, year: int) -> LossCarryforwardRow | None:
        """Return the user-entered ST/LT carryforward override for `year`,
        or None if no override is recorded."""
        with Session(self.engine) as s:
            return s.get(LossCarryforwardRow, year)

    def upsert_carryforward_override(
        self,
        *,
        year: int,
        st: Decimal,
        lt: Decimal,
        note: str | None = None,
    ) -> None:
        """Create or replace the carryforward override for `year`.

        Amounts are stored as positive magnitudes (loss = positive number);
        sign is flipped at apply-time inside the planner / after-tax math.
        Always stamped with ``source="user"`` and a fresh ``updated_at``.
        """
        now = datetime.now(UTC)
        with Session(self.engine) as s:
            existing = s.get(LossCarryforwardRow, year)
            if existing is None:
                row = LossCarryforwardRow(
                    year=year,
                    st_amount=st,
                    lt_amount=lt,
                    source="user",
                    note=note,
                    updated_at=now,
                )
                s.add(row)
            else:
                existing.st_amount = st
                existing.lt_amount = lt
                existing.note = note
                existing.updated_at = now
                s.add(existing)
            s.commit()

    def delete_carryforward_override(self, year: int) -> None:
        """Delete the carryforward override for `year`. No-op if absent."""
        with Session(self.engine) as s:
            existing = s.get(LossCarryforwardRow, year)
            if existing is not None:
                s.delete(existing)
                s.commit()

    def all_carryforward_overrides(self) -> list[LossCarryforwardRow]:
        """Return every carryforward override, sorted ascending by year."""
        with Session(self.engine) as s:
            return list(s.exec(select(LossCarryforwardRow).order_by(LossCarryforwardRow.year)).all())

    # --- Service run history ---

    def record_service_run(
        self,
        *,
        job_name: str,
        started_at: str,
        finished_at: str | None,
        status: str,
        duration_ms: int | None,
        error_msg: str | None,
        payload: str | None,
    ) -> ServiceRunRow:
        """Insert one service-run audit row and return it with its assigned id."""
        with Session(self.engine) as s:
            row = ServiceRunRow(
                job_name=job_name,
                started_at=started_at,
                finished_at=finished_at,
                status=status,
                duration_ms=duration_ms,
                error_msg=error_msg,
                payload=payload,
            )
            s.add(row)
            s.commit()
            s.refresh(row)
            return row

    def list_service_runs(
        self,
        *,
        limit: int = 50,
        job_name: str | None = None,
    ) -> list[ServiceRunRow]:
        """Return recent service-run rows, newest first.

        Args:
            limit: Maximum number of rows to return (default 50).
            job_name: If given, restrict to rows with this job name.
        """
        with Session(self.engine) as s:
            stmt = select(ServiceRunRow).order_by(ServiceRunRow.id.desc()).limit(limit)
            if job_name is not None:
                stmt = stmt.where(ServiceRunRow.job_name == job_name)
            return list(s.exec(stmt).all())

    # -----------------------------------------------------------------------
    # Forward-looking watch helpers (used by engine.washsale_watch)
    # -----------------------------------------------------------------------

    def latest_price(self, ticker: str) -> Decimal | None:
        """Return the latest cached price for *ticker*, or None if unknown."""
        from net_alpha.db.tables import PriceCacheRow

        with Session(self.engine) as s:
            row = s.get(PriceCacheRow, ticker)
            return Decimal(str(row.price)) if row is not None else None

    def position_quantity(self, *, ticker: str, broker: str | None = None, account: str) -> Decimal:
        """Net share quantity held in *account* for *ticker* (Buy minus Sell).

        Keyed by (broker, account label) to resolve the correct AccountRow.
        If *broker* is None, falls back to matching by label only (returns
        the first matching account — suitable for single-broker setups).
        """
        with Session(self.engine) as s:
            if broker is not None:
                acct_row = s.exec(
                    select(AccountRow).where(AccountRow.broker == broker, AccountRow.label == account)
                ).first()
            else:
                acct_row = s.exec(select(AccountRow).where(AccountRow.label == account)).first()
            if acct_row is None:
                return Decimal("0")
            rows = s.exec(select(TradeRow).where(TradeRow.account_id == acct_row.id, TradeRow.ticker == ticker)).all()
            total = Decimal("0")
            for r in rows:
                if r.action == "Buy":
                    total += Decimal(str(r.quantity))
                elif r.action == "Sell":
                    total -= Decimal(str(r.quantity))
            return total

    def average_basis(self, *, ticker: str, broker: str | None = None, account: str) -> Decimal | None:
        """Weighted-average cost basis per share for *ticker* in *account*.

        Returns None if no buy trades exist (cannot compute a basis).
        Keyed by (broker, account label) — same convention as position_quantity.
        """
        with Session(self.engine) as s:
            if broker is not None:
                acct_row = s.exec(
                    select(AccountRow).where(AccountRow.broker == broker, AccountRow.label == account)
                ).first()
            else:
                acct_row = s.exec(select(AccountRow).where(AccountRow.label == account)).first()
            if acct_row is None:
                return None
            rows = s.exec(
                select(TradeRow).where(
                    TradeRow.account_id == acct_row.id,
                    TradeRow.ticker == ticker,
                    TradeRow.action == "Buy",
                )
            ).all()
            if not rows:
                return None
            total_cost = sum(Decimal(str(r.cost_basis or 0)) for r in rows)
            total_qty = sum(Decimal(str(r.quantity)) for r in rows)
            if total_qty == 0:
                return None
            return total_cost / total_qty

    def buys_in_window_non_taxable(self, *, start: date, end: date) -> list:
        """Return Buy rows from tax-advantaged accounts within [start, end].

        Each returned object exposes .id, .ticker, .account (label), .trade_date.
        Only accounts whose ``type != 'taxable'`` are included so callers can
        detect §1091 IRA-trap risk without filtering themselves.
        """
        with Session(self.engine) as s:
            rows = s.exec(
                text("""
                    SELECT t.id, t.ticker, a.label AS account, t.trade_date
                    FROM trades t
                    JOIN accounts a ON a.id = t.account_id
                    WHERE t.action = 'Buy'
                      AND a.type != 'taxable'
                      AND date(t.trade_date) BETWEEN date(:start) AND date(:end)
                    ORDER BY t.trade_date
                """),
                params={"start": start.isoformat(), "end": end.isoformat()},
            ).all()

            class _BuyRow:
                __slots__ = ("id", "ticker", "account", "trade_date")

                def __init__(self, id_: int, ticker: str, account: str, trade_date: str) -> None:
                    self.id = id_
                    self.ticker = ticker
                    self.account = account
                    self.trade_date = trade_date

            return [_BuyRow(r[0], r[1], r[2], r[3]) for r in rows]

    def upsert_watch_result(
        self,
        *,
        target_id: int,
        status: str,
        severity: str,
        reason: str | None,
        triggering: str | None,
        computed_at: str,
    ) -> None:
        with Session(self.engine) as s:
            s.exec(
                text(
                    """
                    INSERT INTO washsale_watch_result(
                        target_id, status, severity, reason, triggering, computed_at
                    ) VALUES (:tid, :st, :sv, :r, :tg, :ts)
                    ON CONFLICT(target_id) DO UPDATE SET
                        status=:st, severity=:sv, reason=:r, triggering=:tg, computed_at=:ts
                    """
                ),
                params={
                    "tid": target_id,
                    "st": status,
                    "sv": severity,
                    "r": reason,
                    "tg": triggering,
                    "ts": computed_at,
                },
            )
            s.commit()

    def watch_results_by_target(self) -> dict[str, WashSaleWatchResultRow]:
        """Return latest watch_result keyed by symbol, for fast plan-row rendering.

        Joins washsale_watch_result with position_targets on target_id so the
        template can look up results by the PlanRow.symbol field directly.
        """
        with Session(self.engine) as s:
            stmt = select(WashSaleWatchResultRow, PositionTargetRow.symbol).join(
                PositionTargetRow,
                WashSaleWatchResultRow.target_id == PositionTargetRow.id,
            )
            return {symbol: row for row, symbol in s.exec(stmt).all()}

    # --- Broker positions (verify engine) ---------------------------------

    def save_broker_positions(self, *, rows: list[dict], as_of_date: str) -> int:
        """Insert an ImportRecord + N BrokerPosition rows.

        The ``imports`` table has a NOT-NULL ``account_id`` FK so we attach
        every positions import to a sentinel account (``positions/(multi)``)
        — the underlying broker_position rows carry their own per-row
        ``account_label`` so the sentinel is purely a referential-integrity
        placeholder, never surfaced as a real trading account.

        The ``csv_filename`` is prefixed with ``[positions]`` so the imports
        page can visibly distinguish positions imports from trade/G&L imports
        even without a dedicated ``kind`` column on the table.

        Returns the new ImportRecord ``id``.
        """
        from net_alpha.verify.models import BrokerPosition

        with Session(self.engine) as s:
            # Sentinel account for the FK; created lazily on first positions
            # import. broker="positions", label="(multi)" — distinct enough
            # from any real broker that it cannot collide.
            acct = s.exec(
                select(AccountRow).where(AccountRow.broker == "positions", AccountRow.label == "(multi)")
            ).first()
            if acct is None:
                acct = AccountRow(broker="positions", label="(multi)")
                s.add(acct)
                s.flush()

            rec = ImportRecordRow(
                account_id=acct.id,
                csv_filename=f"[positions] as of {as_of_date}",
                csv_sha256=f"positions-{as_of_date}-{len(rows)}",
                imported_at=datetime.now(UTC),
                trade_count=len(rows),
            )
            s.add(rec)
            s.flush()
            # Resolve each row's broker-exported label to the canonical
            # broker/label display form so the verify reconciler's
            # (account_label, symbol) key joins cleanly against
            # aggregate_open_positions on the other side. Unresolved rows
            # keep their raw string and surface in the /imports/positions/map
            # picker for one-time user mapping.
            all_accounts = list(s.exec(select(AccountRow)).all())
            lookup: dict[str, str] = {}
            for a in all_accounts:
                display = f"{a.broker}/{a.label}"
                lookup[display] = display
                lookup[a.label] = display
                if a.broker_label:
                    lookup[a.broker_label] = display
            for r in rows:
                raw = r["account_label"]
                label = lookup.get(raw, raw)
                s.add(
                    BrokerPosition(
                        import_id=rec.id,
                        account_label=label,
                        symbol=r["symbol"],
                        qty=r["qty"],
                        cost_basis=r["cost_basis"],
                        market_value=r["market_value"],
                        unrealized_pl=r["unrealized_pl"],
                        as_of_date=as_of_date,
                    )
                )
            s.commit()
            return rec.id

    def aggregate_open_positions(self) -> list[dict]:
        """Sum open-lot qty/basis/market_value per (symbol, account_label).

        Equity-only — option lots are skipped to match the Phase 3 choice in
        the renderer (broker All-Positions CSV reconciliation compares equity
        positions only). FIFO-consumes lots by sells + Realized G/L closures
        so we don't double-count closed lots.

        market_value_total is computed from the cached `latest_price()`; if a
        symbol has no cached price the contribution is 0 and downstream tolerance
        comparisons may surface drift — that's intentional (the user can refresh
        prices and re-run verify).

        Returns a list of dicts with keys: ``symbol``, ``account_label``,
        ``qty``, ``adjusted_basis_total``, ``market_value_total``.
        """
        from net_alpha.portfolio.positions import consume_lots_fifo

        trades = self.all_trades()
        lots = self.all_lots()
        gl_closures = self.get_equity_gl_closures()
        gl_option_closures = self.get_option_gl_closures()
        # Splits scale trade-side sells into post-split units so they
        # match split-adjusted lot.quantity. GL closures are already
        # scaled inside get_*_gl_closures above; this keeps the two
        # sources in the same unit system.
        splits_by_ticker = {sym: self.get_splits(sym) for sym in {lot.ticker for lot in lots}}
        consumed = consume_lots_fifo(
            lots=lots,
            trades=trades,
            gl_closures=gl_closures,
            gl_option_closures=gl_option_closures,
            splits_by_ticker=splits_by_ticker,
        )

        price_cache: dict[str, Decimal | None] = {}

        def _price(ticker: str) -> Decimal:
            if ticker not in price_cache:
                price_cache[ticker] = self.latest_price(ticker)
            p = price_cache[ticker]
            return p if p is not None else Decimal("0")

        out: dict[tuple[str, str], dict] = {}
        for lot, rem_qty, rem_basis in consumed:
            if lot.option_details is not None:
                continue
            if rem_qty <= 0:
                continue
            key = (lot.account, lot.ticker)
            row = out.get(key)
            if row is None:
                row = {
                    "symbol": lot.ticker,
                    "account_label": lot.account,
                    "qty": 0.0,
                    "adjusted_basis_total": 0.0,
                    "market_value_total": 0.0,
                }
                out[key] = row
            row["qty"] += float(rem_qty)
            row["adjusted_basis_total"] += float(rem_basis)
            row["market_value_total"] += float(rem_qty * _price(lot.ticker))
        return list(out.values())

    def latest_broker_positions(self) -> tuple[list, str | None]:
        """Return the most-recent broker_position rows + their as_of_date.

        Empty list + None if no positions CSV has ever been imported. Rows
        are returned as ``BrokerPosition`` SQLModel instances detached from
        the session.
        """
        from net_alpha.verify.models import BrokerPosition

        with Session(self.engine) as s:
            max_import = s.exec(text("SELECT MAX(import_id) FROM broker_position")).first()
            # SQLAlchemy returns a Row; exec().first() on raw text gives a
            # tuple-like Row, or None on empty results. Guard both shapes.
            if not max_import or max_import[0] is None:
                return [], None
            latest_import_id = max_import[0]
            rows = list(s.exec(select(BrokerPosition).where(BrokerPosition.import_id == latest_import_id)).all())
            for r in rows:
                s.expunge(r)
            as_of = rows[0].as_of_date if rows else None
            return rows, as_of

    # --- Verify engine persistence ---

    def save_verify_run(
        self,
        *,
        run_at: str,
        trigger: str,
        status: str,
        duration_ms: int,
        checks_total: int,
        checks_passed: int,
        checks_warned: int,
        checks_failed: int,
        reference_age_days: int | None,
        notes: str,
        findings: list,
    ) -> int:
        """Insert one verify_result + N verify_finding rows in a single transaction.

        Also runs the rolling 90-day cleanup on the indexed ``run_at`` column —
        keeps the audit table from growing unboundedly while still preserving
        a useful trend window for the verify history page.

        ``detail_json`` is stored as a JSON string when the finding carries a
        non-empty detail dict, and as NULL otherwise (avoids "{}" noise).
        """
        from net_alpha.verify.models import VerifyFinding, VerifyResult

        with Session(self.engine) as session:
            vr = VerifyResult(
                run_at=run_at,
                trigger=trigger,
                status=status,
                duration_ms=duration_ms,
                checks_total=checks_total,
                checks_passed=checks_passed,
                checks_warned=checks_warned,
                checks_failed=checks_failed,
                reference_age_days=reference_age_days,
                notes=notes,
            )
            session.add(vr)
            session.flush()
            for f in findings:
                severity = f.severity.value if hasattr(f.severity, "value") else str(f.severity)
                detail_json = json.dumps(f.detail) if f.detail else None
                session.add(
                    VerifyFinding(
                        run_id=vr.id,
                        rule_id=f.rule_id,
                        severity=severity,
                        scope=f.scope,
                        ours=f.ours,
                        theirs=f.theirs,
                        delta=f.delta,
                        detail_json=detail_json,
                    )
                )
            # Rolling 90-day cleanup. ``run_at`` is an ISO timestamp string —
            # SQLite's date() parses the leading YYYY-MM-DD prefix so this
            # comparison is safe without explicit casting.
            session.exec(text("DELETE FROM verify_result WHERE run_at < date('now', '-90 days')"))
            session.commit()
            return vr.id

    def latest_verify_run(self):
        """Return the most-recent VerifyResult row (or None)."""
        from net_alpha.verify.models import VerifyResult

        with Session(self.engine) as session:
            row = session.exec(select(VerifyResult).order_by(VerifyResult.run_at.desc()).limit(1)).first()
            if row is not None:
                session.expunge(row)
            return row

    def list_verify_runs(self, *, limit: int = 50) -> list:
        """Return the most-recent ``limit`` VerifyResult rows, newest first."""
        from net_alpha.verify.models import VerifyResult

        with Session(self.engine) as session:
            rows = list(session.exec(select(VerifyResult).order_by(VerifyResult.run_at.desc()).limit(limit)).all())
            for r in rows:
                session.expunge(r)
            return rows

    def list_verify_findings(self, *, run_id: int) -> list:
        """Return every VerifyFinding row attached to a given verify_result.id."""
        from net_alpha.verify.models import VerifyFinding

        with Session(self.engine) as session:
            rows = list(session.exec(select(VerifyFinding).where(VerifyFinding.run_id == run_id)).all())
            for r in rows:
                session.expunge(r)
            return rows

    def get_verify_finding(self, finding_id: int):
        """Return one VerifyFinding row by id (or None)."""
        from net_alpha.verify.models import VerifyFinding

        with Session(self.engine) as session:
            row = session.exec(select(VerifyFinding).where(VerifyFinding.id == finding_id)).first()
            if row is not None:
                session.expunge(row)
            return row


# ---------------------------------------------------------------------------
# Legacy / preserved classes — kept for import compatibility
# ---------------------------------------------------------------------------


class MetaRepository:
    """Functional — MetaRow schema is unchanged in v2."""

    def __init__(self, session: Session):
        self._session = session

    def get(self, key: str) -> str | None:
        row = self._session.exec(select(MetaRow).where(MetaRow.key == key)).first()
        return row.value if row else None

    def set(self, key: str, value: str) -> None:
        row = self._session.exec(select(MetaRow).where(MetaRow.key == key)).first()
        if row:
            row.value = value
            self._session.add(row)
        else:
            self._session.add(MetaRow(key=key, value=value))
