"""Smoke tests for shieldpi-mcp.

Hits live api.shieldpi.io for tier-1 endpoints (no auth). Skips tier-2
unless SHIELDPI_API_KEY is set.
"""

from __future__ import annotations

import os

import pytest

from shieldpi_mcp.client import ShieldPiAPIError, ShieldPiClient


@pytest.mark.asyncio
async def test_get_methodology_returns_v7_document() -> None:
    async with ShieldPiClient() as client:
        data = await client.get("/api/intelligence/methodology")
    assert isinstance(data, dict)
    assert data.get("document_version", "").startswith("v7")
    assert "breach_layer_v7" in data
    assert "scoring" in data and "judge" in data and "dedup" in data


@pytest.mark.asyncio
async def test_get_leaderboard_returns_models() -> None:
    async with ShieldPiClient() as client:
        data = await client.get("/api/models/leaderboard", params={"limit": 5})
    assert isinstance(data, dict)
    assert "models" in data
    assert isinstance(data["models"], list)


@pytest.mark.asyncio
async def test_get_attack_graph_responds() -> None:
    async with ShieldPiClient() as client:
        data = await client.get("/api/intelligence/attack-graph")
    assert data is not None  # endpoint returns 200 even with empty graph


@pytest.mark.asyncio
async def test_tier2_without_key_raises() -> None:
    # Force no-key path (env var must be unset for the test process)
    client = ShieldPiClient(api_key=None)
    async with client:
        with pytest.raises(ShieldPiAPIError) as excinfo:
            client.require_key("list_attack_categories")
        assert excinfo.value.status == 401
        assert "API key" in excinfo.value.body


@pytest.mark.asyncio
@pytest.mark.skipif(
    not os.getenv("SHIELDPI_API_KEY"),
    reason="SHIELDPI_API_KEY not set; skipping authenticated smoke test",
)
async def test_list_attack_categories_with_key() -> None:
    async with ShieldPiClient() as client:
        data = await client.get("/api/attacks/categories", auth=True)
    assert isinstance(data, (list, dict))


def test_server_imports_cleanly() -> None:
    """Importing the FastMCP server registers all tools without error."""
    from shieldpi_mcp.server import mcp  # noqa: F401

    # FastMCP internal: tools are stored in `_tool_manager`. Just confirm at
    # least one tool was registered. The exact internal API is private; if it
    # changes upstream this test gets a clear failure pointing to the upgrade.
    assert hasattr(mcp, "_tool_manager") or hasattr(mcp, "tools")
