"""ShieldPi MCP server.

Exposes 11 tools that wrap api.shieldpi.io so any MCP-compatible client
(Claude Desktop, Claude Code, Cursor, Continue, etc.) can:

- Query the ShieldPi V7 methodology, attack graph, model families, leaderboard
- Look up models in the registry + their tested security posture
- Browse the 27,000+ attack technique library by category
- Kick off scans against a target and pull back forensic results

Tier-1 tools (no API key required):
  get_methodology, get_attack_graph, get_model_families,
  get_leaderboard_feed, get_leaderboard, get_model_registry

Tier-2 tools (require SHIELDPI_API_KEY env var):
  list_attack_categories, list_attack_techniques,
  start_scan, get_scan_status, get_scan_intelligence

Run as a stdio MCP server: `shieldpi-mcp` (entry point) or
`python -m shieldpi_mcp.server`.
"""

from __future__ import annotations

import json
from typing import Any, Literal

from mcp.server.fastmcp import FastMCP

from shieldpi_mcp.client import ShieldPiAPIError, ShieldPiClient

mcp = FastMCP(
    name="shieldpi",
    instructions=(
        "ShieldPi is an LLM security scanner with 27,000+ attack techniques, "
        "4 scan modes (Browser/API/Agent/Model), and a forensic platform that "
        "extracts breach evidence from successful attacks. Use these tools to "
        "look up the methodology, browse the attack catalog, query the public "
        "leaderboard, and (with an API key) run scans + fetch forensic results. "
        "Public docs: https://shieldpi.io/methodology · Leaderboard: https://shieldpi.info"
    ),
)


# ---------------------------------------------------------------------------
# Tier-1 tools (public, no API key required)
# ---------------------------------------------------------------------------


@mcp.tool()
async def get_methodology() -> str:
    """Return ShieldPi's full V7 scoring + dedup + judge + breach-layer methodology.

    Use this when the user asks "how does ShieldPi score a model?", "what does
    ExploitDepth L3 mean?", or wants to cite the methodology in a report.
    Returns the same JSON document published at /api/intelligence/methodology.
    """
    async with ShieldPiClient() as client:
        data = await client.get("/api/intelligence/methodology")
    return json.dumps(data, indent=2)


@mcp.tool()
async def get_attack_graph() -> str:
    """Return the cross-customer anonymized attack-success graph.

    Maps attack technique → success rate per model family. The graph gets
    smarter as more scans complete (network effect). Useful when the user
    asks "which jailbreaks work on Claude / GPT / Gemini today?"
    """
    async with ShieldPiClient() as client:
        data = await client.get("/api/intelligence/attack-graph")
    return json.dumps(data, indent=2)


@mcp.tool()
async def get_model_families() -> str:
    """Return ShieldPi's model-family taxonomy + similarity edges.

    Useful when the user wants to know what families ShieldPi recognizes
    (anthropic / openai / google / meta / qwen / kimi / deepseek / etc.) and
    how findings transfer across families.
    """
    async with ShieldPiClient() as client:
        data = await client.get("/api/intelligence/families")
    return json.dumps(data, indent=2)


@mcp.tool()
async def get_leaderboard_feed() -> str:
    """Return the live leaderboard feed — the data behind shieldpi.info.

    Gives every model with a recent ShieldPi scan: best security score, grade,
    last-tested timestamp, weakest category. Updated as scans complete.
    """
    async with ShieldPiClient() as client:
        data = await client.get("/api/intelligence/leaderboard-feed")
    return json.dumps(data, indent=2)


@mcp.tool()
async def get_leaderboard(limit: int = 30) -> str:
    """Return the public model leaderboard sorted by best security score.

    Args:
        limit: max number of models to return (default 30, capped server-side).
    """
    async with ShieldPiClient() as client:
        data = await client.get("/api/models/leaderboard", params={"limit": limit})
    return json.dumps(data, indent=2)


@mcp.tool()
async def get_model_registry(family: str | None = None) -> str:
    """Return the registry of models ShieldPi knows how to test.

    Args:
        family: optional family filter (anthropic, openai, google, meta, qwen, ...).
            When omitted, returns all 38+ supported models.
    """
    async with ShieldPiClient() as client:
        data = await client.get("/api/models/registry")
    if family:
        # Server doesn't filter; do it client-side so the LLM only sees what it asked for.
        if isinstance(data, dict) and "models" in data:
            data = {
                **data,
                "models": [
                    m for m in data["models"]
                    if m.get("family", "").lower() == family.lower()
                ],
            }
    return json.dumps(data, indent=2)


# ---------------------------------------------------------------------------
# Tier-2 tools (require API key)
# ---------------------------------------------------------------------------


@mcp.tool()
async def list_attack_categories() -> str:
    """List the 15 attack categories ShieldPi tests against.

    Requires SHIELDPI_API_KEY (free tier works). Each category includes the
    technique count, OWASP LLM mapping, and OWASP Agentic mapping.
    """
    async with ShieldPiClient() as client:
        client.require_key("list_attack_categories")
        data = await client.get("/api/attacks/categories", auth=True)
    return json.dumps(data, indent=2)


@mcp.tool()
async def list_attack_techniques(
    category: str | None = None,
    source: str | None = None,
    limit: int = 25,
    offset: int = 0,
) -> str:
    """Browse the 27,000+ attack technique library.

    Args:
        category: optional category filter (e.g. "prompt_injection", "jailbreak",
            "agent_exploitation", "data_exfiltration").
        source: optional source filter (e.g. "github:elder-plinius/L1B3RT45",
            "shieldpi:agent_attack_library", "agentdojo").
        limit: max techniques per page (default 25, max 100).
        offset: pagination offset.

    Requires SHIELDPI_API_KEY.
    """
    params: dict[str, Any] = {"limit": min(limit, 100), "offset": offset}
    if category:
        params["category"] = category
    if source:
        params["source"] = source
    async with ShieldPiClient() as client:
        client.require_key("list_attack_techniques")
        data = await client.get("/api/attacks", params=params, auth=True)
    return json.dumps(data, indent=2)


# Map MCP `depth` to backend ScanConfig values. Backend caps
# max_attacks_per_category at 100 and timeout_seconds at 3600.
_DEPTH_PRESETS: dict[str, dict[str, int]] = {
    "quick":    {"max_attacks_per_category": 5,  "timeout_seconds": 300},
    "standard": {"max_attacks_per_category": 10, "timeout_seconds": 600},
    "deep":     {"max_attacks_per_category": 50, "timeout_seconds": 1800},
}


@mcp.tool()
async def start_scan(
    target_url: str,
    mode: Literal["browser", "api", "agent", "model"] = "browser",
    target_name: str | None = None,
    depth: Literal["quick", "standard", "deep"] = "standard",
) -> str:
    """Start a ShieldPi scan against a target URL.

    Internally does the two-step backend flow: creates a Target via
    `POST /api/targets`, then starts the scan via `POST /api/scans`.

    Args:
        target_url: URL or model identifier to scan. For `mode=model`, pass an
            OpenRouter slug like "anthropic/claude-sonnet-4.5" or "openai/gpt-4o";
            this tool auto-prefixes with `model://` if needed. For `mode=agent`,
            pass an agent identifier; auto-prefixed with `agent://`.
        mode: scan mode — browser (web app), api (REST), agent (live agent),
            model (LLM via OpenRouter). Default: browser.
        target_name: human-readable label for the target. Defaults to the URL.
        depth: quick (~5min, 5 attacks per category), standard (~10min, 10/cat),
            deep (~30min, 50/cat). Default: standard.

    Returns JSON with target_id, scan_id, and the dashboard URL where progress
    can be watched. Pass scan_id to `get_scan_status` (poll) or
    `get_scan_intelligence` (final results).

    Requires SHIELDPI_API_KEY.
    """
    # Normalize URL for non-HTTP modes
    normalized_url = target_url
    if mode == "model" and not target_url.startswith(("model://", "http://", "https://")):
        normalized_url = f"model://{target_url}"
    elif mode == "agent" and not target_url.startswith(("agent://", "http://", "https://")):
        normalized_url = f"agent://{target_url}"

    target_body = {
        "name": target_name or target_url,
        "url": normalized_url,
        "scan_mode": mode,
    }
    config_body = {**_DEPTH_PRESETS[depth], "target_name": target_name or target_url}
    scan_body: dict[str, Any] = {"config": config_body}

    async with ShieldPiClient() as client:
        client.require_key("start_scan")
        # Step 1: create the Target.
        target = await client.post("/api/targets", json=target_body, auth=True)
        target_id = target["id"]
        # Step 2: start the Scan against the new Target.
        scan_body["target_id"] = target_id
        scan = await client.post("/api/scans", json=scan_body, auth=True)
        scan_id = scan["id"]

    result = {
        "target_id": target_id,
        "scan_id": scan_id,
        "status": scan.get("status", "queued"),
        "depth": depth,
        "mode": mode,
        "target_name": target_name or target_url,
        "target_url": normalized_url,
        "dashboard_url": f"https://shieldpi.io/dashboard/scans/{scan_id}",
        "next_step": (
            f"Poll `get_scan_status(scan_id='{scan_id}')` until status is 'completed' "
            f"or 'completed_partial' (typically 5–30 min depending on depth). "
            f"Then call `get_scan_intelligence(scan_id='{scan_id}')` for the full "
            f"breach forensics package."
        ),
    }
    return json.dumps(result, indent=2)


@mcp.tool()
async def get_scan_status(scan_id: str) -> str:
    """Get the current status of an in-progress scan.

    Cheap to call repeatedly — lighter than `get_scan_intelligence`.
    Use this to poll while a scan is running.

    Args:
        scan_id: UUID returned by `start_scan`.

    Returns JSON with status (queued | running | completed | completed_partial |
    failed), current phase, and elapsed time. Once status is `completed` or
    `completed_partial`, switch to `get_scan_intelligence` for results.

    Requires SHIELDPI_API_KEY.
    """
    async with ShieldPiClient() as client:
        client.require_key("get_scan_status")
        data = await client.get(f"/api/scans/{scan_id}/status", auth=True)
    return json.dumps(data, indent=2)


@mcp.tool()
async def get_scan_intelligence(scan_id: str) -> str:
    """Pull the full intelligence + breach-forensics package for a scan.

    Returns: security score + grade + per-category results + extracted breach
    artifacts (creds / PII / code / tools) + kill chain narrative + business
    impact estimate. Only meaningful once the scan reaches `completed` or
    `completed_partial` — call `get_scan_status` first to check.

    Args:
        scan_id: UUID returned by `start_scan` or visible in the dashboard URL.

    Requires SHIELDPI_API_KEY.
    """
    async with ShieldPiClient() as client:
        client.require_key("get_scan_intelligence")
        data = await client.get(f"/api/scans/{scan_id}/intelligence", auth=True)
    return json.dumps(data, indent=2)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    """Run the MCP server over stdio (Claude Desktop / Code / Cursor default)."""
    try:
        mcp.run()
    except ShieldPiAPIError as exc:
        # FastMCP catches tool errors per-call; this only fires if the loop itself dies.
        raise SystemExit(f"shieldpi-mcp fatal: {exc}") from exc


if __name__ == "__main__":
    main()
