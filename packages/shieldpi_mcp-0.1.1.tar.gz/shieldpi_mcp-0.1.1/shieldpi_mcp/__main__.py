"""Allow `python -m shieldpi_mcp` to launch the server."""

from shieldpi_mcp.server import main

if __name__ == "__main__":
    main()
