#!/usr/bin/env bash
# Add ShieldPi MCP server to Claude Code.
#
# Prereq: pip install shieldpi-mcp  (or pipx install shieldpi-mcp)
#
# Usage: ./claude-code.sh

set -euo pipefail

if ! command -v shieldpi-mcp >/dev/null 2>&1; then
  echo "shieldpi-mcp not found. Install with: pip install shieldpi-mcp"
  exit 1
fi

claude mcp add shieldpi -- shieldpi-mcp
echo
echo "Added. Tier-2 tools (techniques catalog, scans) need an API key."
echo "Set it in your shell or in ~/.envrc:"
echo "  export SHIELDPI_API_KEY=\"shpi_live_...\""
echo
echo "Get a free key: https://shieldpi.io/dashboard/api-keys"
