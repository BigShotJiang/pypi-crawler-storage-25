# Distribution checklist — shieldpi-mcp

End-to-end checklist for getting `shieldpi-mcp` in front of every Claude Desktop / Code / Cursor / Continue user. Each step is small; the order matters.

## 1. PyPI publish (10 min — do this first)

The `publish-mcp.yml` GitHub Action publishes on a `mcp-v*` tag push, but it needs a PyPI token first.

### One-time PyPI setup

1. Sign in (or create account) at https://pypi.org/ as `support@shieldpi.io`.
2. Reserve the project name: https://pypi.org/manage/account/projects/ → it'll auto-claim on first upload, but you can manually create it.
3. Create an API token scoped to `shieldpi-mcp` only:
   - https://pypi.org/manage/account/token/
   - Token name: `shieldpi-mcp-github-actions`
   - Scope: project `shieldpi-mcp` (after first upload). Until first upload, scope it to "Entire account" temporarily.
4. Add the token to the repo as a secret named `PYPI_MCP_TOKEN`:
   - https://github.com/ShieldPi1/shieldpi-watchtower/settings/secrets/actions
   - Name: `PYPI_MCP_TOKEN` · Value: the `pypi-...` token from step 3.

### First publish

```bash
cd /Users/calvin/shieldpi-deploy
git tag mcp-v0.1.0
git push origin mcp-v0.1.0
```

GitHub Actions runs `publish-mcp.yml` → tests → `python -m build` → `twine upload`. Within ~3 min the package appears at https://pypi.org/project/shieldpi-mcp/.

After the first successful upload, narrow the PyPI token scope from "Entire account" to "shieldpi-mcp" only, and rotate `PYPI_MCP_TOKEN` to the narrowed token.

### Verify

```bash
pip install shieldpi-mcp
shieldpi-mcp --help 2>&1 | head -3   # should print MCP server startup info
```

## 2. Anthropic MCP directory (1–4 weeks review)

Anthropic maintains a curated list at https://github.com/modelcontextprotocol/servers. Submission is a PR to that repo.

### Submission steps

1. Fork https://github.com/modelcontextprotocol/servers.
2. Add an entry to `README.md` in the **"Third-Party Servers"** → **"Official Integrations"** (since we're an established product) or **"Community Servers"** section. Format follows the existing entries:

   ```markdown
   - **[ShieldPi](https://github.com/ShieldPi1/shieldpi-watchtower/tree/main/mcp-server)** — Query 27,000+ LLM attack techniques, run security scans, and pull breach forensics. Powers the [ShieldPi Watchtower](https://shieldpi.io) AI security platform.
   ```

3. Open PR with a short description:
   > Adding `shieldpi-mcp` — production MCP server for ShieldPi Watchtower (LLM security forensics platform). 10 tools across 6 public + 4 authenticated endpoints. MIT-licensed, on PyPI as `shieldpi-mcp`. Tested against live api.shieldpi.io. Public methodology + leaderboard at shieldpi.io and shieldpi.info.

4. Anthropic policy review (per their MCP directory policy: https://support.anthropic.com/en/articles/11697096):
   - Outbound HTTPS only ✅
   - API keys never logged ✅
   - Private IPs not exposed ✅
   - Clear error messages ✅
   - LICENSE present (MIT) ✅
   - README documents tools + auth ✅

5. Approval typically takes 1–4 weeks. They may ask for changes — respond fast.

### Smithery (parallel — same day)

Smithery (https://smithery.ai/) is a community MCP marketplace that auto-discovers from GitHub. Listing happens automatically once the repo is public + tagged. You can also submit manually at https://smithery.ai/new for fast indexing.

## 3. ClawHub (OpenClaw skill registry — same day)

OpenClaw's ClawHub at https://clawhub.ai accepts MCP servers as well. Submit at https://clawhub.ai/submit.

## 4. Inbound funnel — wire the MCP install URL into shieldpi.io

After PyPI publish:

1. Add a "Connect via MCP" CTA on shieldpi.io homepage hero — single line:
   ```
   pip install shieldpi-mcp && shieldpi-mcp
   ```
2. Add a `/mcp` page documenting the 10 tools (mirror the README).
3. Update the leaderboard footer at shieldpi.info: "Use this data in your own LLM session — `pip install shieldpi-mcp`".
4. Add `MCP server: pip install shieldpi-mcp` to every blog post sidebar.

## 5. Distribution announcement (next sprint, after PyPI is live)

- **HN Show post:** "Show HN: shieldpi-mcp — query 27,000+ LLM jailbreaks from inside Claude Desktop"
- **LinkedIn post** (Calvin) — focus on the use case ("ask Claude about the security posture of any model, get a real answer from a real scanner")
- **X thread** — 5 tweets walking through the 10 tools with a real example each
- **Reddit:** r/LocalLLaMA, r/MachineLearning, r/cybersecurity (read each sub's rules first; some require account history)
- **Direct outreach:** any AI security researcher who's ever cited a leaderboard

## Timeline (optimistic)

| Day | Item |
|-----|------|
| Today | Code shipped to GitHub ✅ (commit `ae839f8`) |
| Today | PyPI token set up + first tag → PyPI publish |
| Day +1 | Anthropic MCP directory PR opened |
| Day +1 | Smithery + ClawHub submissions |
| Day +1 | shieldpi.io `/mcp` page + homepage CTA |
| Day +2–3 | HN Show + LinkedIn + X thread |
| Day +7 to +28 | Anthropic directory approval lands |
| Day +30 | First inbound usage signal (PyPI download count, ShieldPi API key signups attributable to MCP) |

## Success metrics (90 days)

Per [[decision-shieldpi-v8-growth-adoption]]:
- 1,000+ PyPI installs
- 10+ inbound enterprise inquiries with MCP attribution
- Listed on Anthropic MCP directory
