"""livechord-bar-arbitrator — post-processor that fixes bar / downbeat
phase drift, beats-per-bar confusion, and intermittent doubletime
without re-running expensive audio models.

Public API
----------
::

    from livechord_bar_arbitrator import arbitrate, apply_to_chord_json

    # chord_data: dict matching LiveChord's chord JSON schema —
    # {"chords": [...], "beats": [...], "downbeats": [...], "bpm": ...}
    result = arbitrate(chord_data)
    if result["applied"]:
        chord_data = apply_to_chord_json(chord_data, result)

The optional ONNX-trained Phase 1 model is fetched from Hugging Face Hub
on demand when ``arbitrate(model_path=None)`` is called and downloaded
to the local cache. Pass ``model_path="..."`` to use a local file.
"""

import logging
from pathlib import Path
from typing import Optional

from .arbitrator import (
    arbitrate as _arbitrate_internal,
    arbitrate_rule_based,
    arbitrate_model_based,
    apply_to_chord_json,
    restore_from_snapshot,
    phase1_refine,
    ArbitrationResult,
    FEATURE_DIM,
)

logger = logging.getLogger(__name__)

_HUB_REPO_ID = "livechord-music/livechord-bar-arbitrator"
_HUB_FILENAME_ONNX = "bar_arbitrator_v1.onnx"


def _resolve_model_path(model_path: Optional[str]) -> Optional[str]:
    if model_path is not None:
        p = Path(model_path)
        if not p.exists():
            logger.warning("explicit model_path not found: %s", p)
            return None
        return str(p)
    try:
        from huggingface_hub import hf_hub_download
    except ImportError:
        logger.debug("huggingface_hub not installed — Phase 1 model unavailable")
        return None
    try:
        local = hf_hub_download(repo_id=_HUB_REPO_ID, filename=_HUB_FILENAME_ONNX)
        return str(local)
    except Exception as e:
        logger.warning("hf_hub_download(%s, %s) failed: %s",
                       _HUB_REPO_ID, _HUB_FILENAME_ONNX, e)
        return None


def arbitrate(chord_data, *, model_path=None, force=False):
    """Arbitrate downbeats / beats-per-bar in ``chord_data``.

    If ``model_path`` is given, runs the ONNX Phase 1 model (with rule
    fallback when unavailable). If ``model_path is None``, attempts
    HF Hub download of the published Phase 1 ONNX model first; on
    failure falls back to the deterministic Phase 0 rule baseline.
    """
    resolved = _resolve_model_path(model_path)
    return _arbitrate_internal(chord_data, model_path=resolved, force=force)


__version__ = "0.1.0"
__all__ = [
    "arbitrate",
    "arbitrate_rule_based",
    "arbitrate_model_based",
    "apply_to_chord_json",
    "restore_from_snapshot",
    "phase1_refine",
    "ArbitrationResult",
    "FEATURE_DIM",
    "__version__",
]
