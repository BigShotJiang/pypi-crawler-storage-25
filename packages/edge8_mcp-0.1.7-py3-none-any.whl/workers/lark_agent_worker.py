#!/usr/bin/env python3
"""
Lark Agent Worker — Mac daemon that polls Redis and dispatches claude -p subprocesses.
Managed by launchd. Uses Claude Code CLI (Pro Plan auth).
"""

import asyncio
import json
import logging
import os
import subprocess
import yaml
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [lark-worker] %(levelname)s %(message)s",
)
log = logging.getLogger(__name__)

REDIS_URL = os.getenv("LARK_REDIS_URL", "")
REDIS_TOKEN = os.getenv("LARK_REDIS_TOKEN", "")
REGISTRY_PATH = Path(__file__).parent.parent.parent / "config" / "agent_registry.yaml"
CLAUDE_BIN = os.getenv("CLAUDE_BIN", "claude")
AGENT_TIMEOUT = int(os.getenv("AGENT_TIMEOUT", "120"))


def load_registry() -> dict:
    with open(REGISTRY_PATH) as f:
        data = yaml.safe_load(f)
    return {p["app_id"]: p for p in data.get("projects", [])}


def build_router_prompt(payload: dict, agents: list[dict]) -> str:
    agent_list = "\n".join(
        f"- id: {a['id']}\n  description: {a['description']}"
        for a in agents
    )
    return (
        f"Available agents:\n{agent_list}\n\n"
        f"Message from {payload.get('sender_name', 'unknown')}:\n"
        f"{payload.get('text', '')}\n\n"
        f"Output only the agent id."
    )


def build_agent_prompt(payload: dict) -> str:
    history_lines = "\n".join(
        f"[{h.get('ts', '')}] {h.get('sender', '')}: {h.get('text', '')}"
        for h in payload.get("history", [])
    )
    return (
        f"=== CONVERSATION HISTORY ===\n{history_lines}\n\n"
        f"=== CURRENT MESSAGE ===\n"
        f"From: {payload.get('sender_name', payload.get('sender_open_id', ''))}\n"
        f"Chat ID: {payload.get('chat_id', '')}\n"
        f"Text: {payload.get('text', '')}\n\n"
        f"=== TASK ===\n"
        f"Reply using lark_send_message(receive_id=\"{payload.get('chat_id', '')}\", receive_id_type=\"chat_id\", content=\"...\").\n"
        f"Write plain text only — no markdown syntax. Use line breaks instead of bullet points or headers."
    )


def run_claude(prompt: str, cwd: str) -> tuple[int, str, str]:
    """Run claude -p in a workspace directory. Returns (returncode, stdout, stderr)."""
    result = subprocess.run(
        [CLAUDE_BIN, "-p", prompt, "--output-format", "json"],
        cwd=cwd,
        capture_output=True,
        text=True,
        timeout=AGENT_TIMEOUT,
    )
    return result.returncode, result.stdout, result.stderr


async def blpop_redis(key: str) -> dict | None:
    """Poll Upstash Redis via REST API. Blocks up to 1s."""
    import aiohttp
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(
                REDIS_URL,
                headers={"Authorization": f"Bearer {REDIS_TOKEN}", "Content-Type": "application/json"},
                json=["BLPOP", key, "1"],
                timeout=aiohttp.ClientTimeout(total=5),
            ) as resp:
                data = await resp.json()
                result = data.get("result")
                if result:
                    return json.loads(result[1])
    except Exception as e:
        log.warning(f"Redis poll error: {e}")
        await asyncio.sleep(1)
    return None


async def process_payload(payload: dict, project: dict) -> None:
    root = project["root"]
    agents = project["agents"]

    # Stage 1: Route
    router_cwd = str(Path(root) / "_router")
    if not Path(router_cwd).exists():
        log.error(f"Router workspace missing: {router_cwd}")
        return

    router_prompt = build_router_prompt(payload, agents)
    log.info(f"Routing message from {payload.get('sender_name')}...")

    try:
        rc, stdout, stderr = run_claude(router_prompt, router_cwd)
    except subprocess.TimeoutExpired:
        log.error("Router timed out")
        return

    try:
        agent_id = json.loads(stdout).get("result", "").strip().lower()
    except Exception:
        agent_id = stdout.strip().lower()

    if not agent_id or agent_id == "none":
        log.info("Router returned none — no agent matched, ignoring message")
        return

    log.info(f"Routed to agent: {agent_id}")

    # Stage 2: Execute
    agent_cwd = str(Path(root) / agent_id)
    if not Path(agent_cwd).exists():
        log.error(f"Agent workspace missing: {agent_cwd}")
        return

    agent_prompt = build_agent_prompt(payload)

    try:
        rc, stdout, stderr = run_claude(agent_prompt, agent_cwd)
        if rc != 0:
            log.error(f"Agent {agent_id} exited {rc}: {stderr[:500]}")
        else:
            log.info(f"Agent {agent_id} completed successfully")
    except subprocess.TimeoutExpired:
        log.error(f"Agent {agent_id} timed out after {AGENT_TIMEOUT}s")


async def main() -> None:
    if not REDIS_URL or not REDIS_TOKEN:
        raise RuntimeError("LARK_REDIS_URL and LARK_REDIS_TOKEN must be set")

    log.info("Lark agent worker started")
    registry = load_registry()
    log.info(f"Loaded {len(registry)} project(s): {list(registry.keys())}")

    while True:
        for app_id, project in registry.items():
            redis_key = f"lark:events:{app_id}"
            payload = await blpop_redis(redis_key)
            if payload:
                path = payload.get("path", "/unknown")
                if path == "/message":
                    asyncio.create_task(process_payload(payload, project))
                else:
                    log.info(f"Ignoring non-message event: {path}")


if __name__ == "__main__":
    asyncio.run(main())
