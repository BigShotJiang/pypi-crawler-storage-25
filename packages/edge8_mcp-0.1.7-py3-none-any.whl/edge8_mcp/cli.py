from pathlib import Path

BANNER = """
\033[36m
  ███████╗██████╗  ██████╗ ███████╗ █████╗
  ██╔════╝██╔══██╗██╔════╝ ██╔════╝██╔══██╗
  █████╗  ██║  ██║██║  ███╗█████╗  ╚█████╔╝
  ██╔══╝  ██║  ██║██║   ██║██╔══╝  ██╔══██╗
  ███████╗██████╔╝╚██████╔╝███████╗╚█████╔╝
  ╚══════╝╚═════╝  ╚═════╝ ╚══════╝ ╚════╝
\033[0m\033[90m  Workspace Automation MCP  •  edge8.ai\033[0m
"""


def main():
    from dotenv import load_dotenv
    load_dotenv(Path.cwd() / ".env", override=False)

    print(BANNER)

    from mcp_server.server import mcp
    mcp.run(show_banner=False)


if __name__ == "__main__":
    main()
