# Agent System

A modular, context-aware agent orchestration system that intelligently routes requests, executes tools, and generates natural responses with specialized grading capabilities.

## Overview

The AgentSystem is a sophisticated orchestration layer that:

1. **Routes requests intelligently** using the Router Agent with context providers
2. **Executes tools efficiently** via the Tool Agent with 2-stage planning
3. **Generates natural responses** using the Answering Agent with streaming support
4. **Processes assignments** through the Grading Workflow system
5. **Manages context** via pluggable context providers
6. **Caches data** using Redis for performance optimization

## Architecture

### Core Components

#### 1. AgentState
Centralized state management that tracks:
- Conversation history and messages
- Current user input and iteration count
- Intent detection (TOOL, CHAT, GRADING)
- Tool execution results and metadata
- Student context and email
- Pre-fetched context data

#### 2. RouterAgent
Intelligent request router that:
- Analyzes user intent using LLM
- Detects submission follow-ups (keyword + semantic)
- Selects appropriate tool groups
- Determines execution status (CONTINUE/FINISHED)
- Integrates context from providers (AIO, Student, Prefetch)
- Supports Redis caching for performance

#### 3. ToolAgent
2-stage tool execution agent:
- **Stage 1 (Planning)**: Selects relevant tools and generates custom system prompt
- **Stage 2 (Execution)**: Executes tools with optimized context
- Uses prompt caching for efficiency
- Handles tool parameter extraction and validation

#### 4. AnsweringAgent
Context-aware response generator:
- Generates natural language responses
- Supports streaming output
- Integrates context from providers
- Adapts role based on platform (e.g., AI Buddy for AIO)
- Uses Redis caching for repeated queries

#### 5. GradingWorkflow
Specialized assignment grading system:
- Dual-agent architecture (Scorer + Reflector)
- Processes student submissions
- Generates detailed feedback
- Integrates with Circle for posting results
- Supports prior-check for duplicate submissions

#### 6. Context Providers
Pluggable context injection system:
- **AIOGuidelinesProvider**: Injects AIO program guidelines
- **StudentContextProvider**: Adds student progress and enrollment data
- **PrefetchContextProvider**: Uses pre-loaded entity context
- **ContextRegistry**: Manages provider registration and execution

## Usage

### Basic Usage

```python
from src.agents.systems.simple_agent_system import AgentSystem

# Initialize agent
agent = AgentSystem(
    tool_groups=["circle_aio"],
    member_id=123,
    session_id="session_abc",
    auto_save=True
)

# Non-streaming
response = await agent.run("What missions should I complete next?")
print(response)

# Streaming
async for event in agent.run_stream(
    "I want to submit Mission 1",
    email="student@example.com",
    files=[{"url": "...", "name": "submission.pdf"}]
):
    if event["event"] == "content":
        print(event["data"], end="")
```

### With Context Pre-fetching

```python
# Pre-fetch entity context for faster responses
agent = AgentSystem(
    tool_groups=["circle_aio"],
    member_id=123
)

# Context is automatically injected
async for event in agent.run_stream(
    "Tell me about Mission 1",
    context_type="challenge",
    context_id="challenge_uuid_123"
):
    process_event(event)
```

## Agent Flow

The system follows an iterative flow:

1. **User Input** → State updated with message
2. **Router Agent** → Analyzes intent (TOOL/CHAT/GRADING)
3. **Branch by Intent**:
   - **TOOL**: Tool Agent → Execute tools → Loop back to Router
   - **CHAT**: Answering Agent → Generate response → Done
   - **GRADING**: Grading Workflow → Process submission → Done
4. **Iteration Control**: Max 3 iterations before forcing completion
5. **Streaming Output**: Events yielded in real-time

### Flow Control Rules

- Router decides intent and status (CONTINUE/FINISHED)
- Tool execution results stored in state for next iteration
- Context providers inject data before each agent call
- Session auto-save persists messages to database
- Redis caching reduces redundant API calls

## Features

### ✅ Intelligent Routing
- LLM-powered intent detection (TOOL/CHAT/GRADING)
- Hybrid follow-up detection (keyword + semantic)
- Tool group selection based on context
- Performance-optimized with max iteration limits

### ✅ Tool Integration
- 2-stage tool planning and execution
- Prompt caching for efficiency
- Dynamic tool selection per request
- Comprehensive error handling

### ✅ Context Management
- Pluggable context provider system
- Student progress and enrollment tracking
- Pre-fetched entity context support
- Platform-specific guidelines injection

### ✅ Caching & Performance
- Redis-based caching for student data
- Router decision caching
- Prompt caching for repeated queries
- Batch session auto-save

### ✅ Grading System
- Dual-agent grading (Scorer + Reflector)
- Prior-check for duplicate submissions
- Challenge type-aware grade status
- Circle integration for posting results

### ✅ Streaming & Session Management
- Real-time event streaming
- Session persistence to Supabase
- Conversation history tracking
- File upload support

## Testing

### Run Tests
```bash
# Run all agent tests
pytest tests/agents/ -v

# Test grading system
pytest tests/grading/ -v

# Test specific components
pytest tests/agents/test_router_agent.py -v
pytest tests/agents/test_tool_agent.py -v
pytest tests/agents/test_answering_agent.py -v

# Interactive grading test
python tests/grading/test_mission06_interactive.py
```

### Test Coverage
- Router intent detection tests
- Tool planning and execution tests
- Context provider integration tests
- Grading workflow tests (structural + interactive)
- Session management tests
- Caching behavior tests

## Configuration

### Environment Variables
```bash
# Required
export OPENROUTER_API_KEY="your-api-key-here"

# Optional - Redis caching
export UPSTASH_REDIS_URL="your-redis-url"
export UPSTASH_REDIS_TOKEN="your-redis-token"

# Optional - Session management
export AIO_SUPABASE_URL="your-supabase-url"
export AIO_SUPABASE_SERVICE_ROLE_KEY="your-service-key"
```

### LLM Models
```python
# Default configuration in AgentSystem
router_llm = "arcee-ai/trinity-mini:nitro"  # Fast routing
tool_llm = "arcee-ai/trinity-mini:nitro"    # Tool selection
writing_llm = "google/gemini-2.5-flash-lite:nitro"  # Response generation
```

## Examples

### Assignment Submission
```python
agent = AgentSystem(tool_groups=["circle_aio"], member_id=123)

async for event in agent.run_stream(
    "I want to submit Mission 1",
    email="student@example.com",
    files=[{"url": "https://...", "name": "mission1.pdf"}]
):
    if event["event"] == "grading_response":
        print(f"Score: {event['data']['score']}")
```

### Student Progress Query
```python
async for event in agent.run_stream(
    "What missions should I complete next?",
    email="student@example.com"
):
    if event["event"] == "content":
        print(event["data"], end="")
```

### Follow-up Questions
```python
# After submission, student asks for help
async for event in agent.run_stream(
    "How can I improve my score?",
    email="student@example.com"
):
    # Router detects follow-up and uses circle_aio tools
    # to provide enriched suggestions
    process_event(event)
```

### General Chat
```python
response = await agent.run(
    "What is the AI Officer Program about?"
)
print(response)
```

## API Reference

### AgentSystem
Main orchestration class for agent system.

#### Constructor
```python
AgentSystem(
    tool_groups: List[str] = None,
    context: List[dict] = None,
    session_id: Optional[str] = None,
    member_id: Optional[int] = None,
    auto_save: bool = True,
    prompt_logger = None
)
```

#### Methods
- `run(user_input: str) -> str`: Non-streaming execution
- `run_stream(user_input, email, files, with_post, circle_file_urls, context_type, context_id) -> AsyncGenerator`: Streaming execution
- `get_history() -> List[Dict]`: Get conversation history

### Event Types
Streaming events yielded by `run_stream`:
- `{"event": "reasoning", "data": str}`: Router decisions and thoughts
- `{"event": "content", "data": str}`: Response content chunks
- `{"event": "grading_response", "data": dict}`: Grading results
- `{"event": "metadata", "data": dict}`: Additional metadata
- `{"event": "error", "data": str}`: Error messages

### AgentState
Centralized state management:
- `messages`: Conversation history
- `current_input`: Current user input
- `intent`: Detected intent (TOOL/CHAT/GRADING)
- `tool_results`: Tool execution results
- `iteration_count`: Current iteration number
- `email`: Student email
- `member_id`: Member ID
- `prefetch_context`: Pre-loaded entity data

## Error Handling

The system includes comprehensive error handling:
- Router decision failures
- Tool execution errors
- API connectivity issues
- Invalid input handling
- Graceful degradation

## Integration

### With Existing Systems
The AgentSystem integrates with:
- Tool schemas (`src/agents/tools/schema.py`)
- Platform connectors (`src/connectors/`)
- OpenRouter LLM client (`src/connectors/openrouter/`)
- Supabase for session management
- Redis for caching
- Circle API for grading posts

### Extension Points
- **Custom Context Providers**: Implement `BaseContextProvider`
- **New Tool Groups**: Add to `TOOL_GROUP_DEFINITIONS`
- **Custom Agents**: Extend `BaseAgent`
- **Grading Customization**: Modify `GradingWorkflow` or `OptimizedGradingWorkflow`

## Best Practices

1. **Use session IDs** for conversation persistence
2. **Enable Redis caching** for production performance
3. **Pre-fetch context** when entity ID is known
4. **Monitor iteration counts** to prevent loops
5. **Use streaming** for better UX
6. **Implement prompt logging** for debugging
7. **Test grading flows** interactively before deployment
8. **Cache student data** to reduce database load

## Troubleshooting

### Common Issues

**Router always returns CHAT**
- Check tool_groups are properly configured
- Verify context providers are registered
- Review router prompt and iteration count

**Tool execution fails**
- Verify tool schemas are correct
- Check tool handler implementations
- Review tool_inputs in state

**Grading not triggered**
- Ensure `context_type="challenge"` or user mentions submission
- Check if `circle_aio` is in tool_groups
- Verify email is provided

**Caching not working**
- Verify UPSTASH_REDIS_URL and TOKEN are set
- Check Redis connection logs
- Ensure upstash-redis package is installed

**Session not persisting**
- Verify AIO_SUPABASE_URL and KEY are set
- Check auto_save is True
- Ensure session_id is provided

### Debug Mode
```python
import logging
logging.basicConfig(level=logging.DEBUG)

# Enable prompt logging
from src.utils.prompt_logger import PromptLogger
logger = PromptLogger()
agent = AgentSystem(tool_groups=["circle_aio"], prompt_logger=logger)
```
