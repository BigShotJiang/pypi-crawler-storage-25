"""
Entity Resolver Module

Provides entity resolution pre-processing before RAG search.
Resolves shorthand entity references (e.g., "Mission 5") to canonical names.

This is Phase 2A of the Response Quality Improvement Proposal.
"""

from typing import Optional, List, Dict, Any, Protocol
from dataclasses import dataclass
from abc import ABC, abstractmethod
import re


@dataclass
class ResolvedQuery:
    """Result of entity resolution attempt."""
    original: str
    resolved_query: str
    resolved: bool
    entity_type: Optional[str] = None
    entity_id: Optional[str | int] = None
    entity_name: Optional[str] = None
    enriched_query: Optional[str] = None


class ResolutionStrategy(ABC):
    """Abstract base class for entity resolution strategies."""
    
    @abstractmethod
    async def resolve(self, query: str, entity_type: Optional[str] = None) -> ResolvedQuery:
        """Attempt to resolve entity reference in query.
        
        Args:
            query: User input query
            entity_type: Optional hint about expected entity type
            
        Returns:
            ResolvedQuery with resolution results
        """
        pass
    
    @abstractmethod
    async def resolve_from_context(
        self, 
        query: str, 
        conversation_history: List[Dict[str, Any]]
    ) -> ResolvedQuery:
        """Attempt to resolve using conversation context.
        
        Args:
            query: Current user input
            conversation_history: Recent conversation turns
            
        Returns:
            ResolvedQuery with resolution results
        """
        pass


class MissionNumberStrategy(ResolutionStrategy):
    """Resolves 'Mission 5' → '05 From Prompts to Packaged AI'"""
    
    # Mapping of word numbers to digits
    WORD_TO_NUMBER = {
        "zero": "0", "one": "1", "two": "2", "three": "3", "four": "4",
        "five": "5", "six": "6", "seven": "7", "eight": "8", "nine": "9",
        "ten": "10", "eleven": "11", "twelve": "12", "thirteen": "13",
        "fourteen": "14", "fifteen": "15", "sixteen": "16", "seventeen": "17",
        "eighteen": "18", "nineteen": "19", "twenty": "20"
    }
    
    def __init__(self, db_handler):
        """Initialize with database handler.
        
        Args:
            db_handler: DatabaseToolHandler instance
        """
        self.db = db_handler
    
    def _normalize_mission_number(self, mission_text: str) -> str:
        """Convert mission text to normalized 2-digit format."""
        try:
            mission_lower = mission_text.lower().strip()
            if mission_lower in self.WORD_TO_NUMBER:
                mission_num = int(self.WORD_TO_NUMBER[mission_lower])
            else:
                mission_num = int(mission_text)
            return str(mission_num).zfill(2)
        except (ValueError, AttributeError):
            return ""
    
    async def resolve(self, query: str, entity_type: Optional[str] = None) -> ResolvedQuery:
        """Resolve mission number patterns like "Mission 5"."""
        # Pattern: Mission + number or word
        valid_words = "|".join(self.WORD_TO_NUMBER.keys())
        pattern = rf"Mission\s+#?\s*(\d+|{valid_words})"
        matches = re.findall(pattern, query, re.IGNORECASE)
        
        if not matches:
            return ResolvedQuery(
                original=query,
                resolved_query=query,
                resolved=False
            )
        
        mission_text = matches[0]
        normalized = self._normalize_mission_number(mission_text)
        
        if not normalized:
            return ResolvedQuery(
                original=query,
                resolved_query=query,
                resolved=False
            )
        
        # Query database for mission with this prefix
        try:
            result = await self.db.execute(
                resource="missions",
                name=f"{normalized}%",  # Starts with normalized number
                limit=1
            )
            
            missions = result.get("metadata", [])
            if missions and len(missions) > 0:
                mission = missions[0]
                mission_name = mission.get("name", "")
                mission_id = mission.get("id")
                
                # Construct enriched query
                enriched = query.replace(
                    f"Mission {mission_text}",
                    f"Mission {mission_name}"
                )
                
                return ResolvedQuery(
                    original=query,
                    resolved_query=mission_name,
                    resolved=True,
                    entity_type="mission",
                    entity_id=mission_id,
                    entity_name=mission_name,
                    enriched_query=enriched
                )
        except Exception as e:
            print(f"⚠️ Error resolving mission: {e}")
        
        return ResolvedQuery(
            original=query,
            resolved_query=query,
            resolved=False
        )
    
    async def resolve_from_context(
        self, 
        query: str, 
        conversation_history: List[Dict[str, Any]]
    ) -> ResolvedQuery:
        """Resolve mission reference from conversation history.
        
        Handles cases like:
        - Turn 1: "Tell me about Mission 5" → resolved
        - Turn 2: "What materials does it have?" → resolve "it" to Mission 5 from history
        """
        # Only try context resolution if query doesn't already have a mission reference
        valid_words = "|".join(self.WORD_TO_NUMBER.keys())
        direct_pattern = rf"Mission\s+#?\s*(\d+|{valid_words})"
        if re.search(direct_pattern, query, re.IGNORECASE):
            # Query already has explicit mission reference — use direct resolve instead
            return ResolvedQuery(original=query, resolved_query=query, resolved=False)
        
        # Scan conversation history (most recent first) for mission mentions
        for msg in reversed(conversation_history):
            content = msg.get("content", "")
            mission_match = re.search(direct_pattern, content, re.IGNORECASE)
            if mission_match:
                mission_text = mission_match.group(1)
                # Re-run direct resolution with the found mission number
                synthetic_query = f"Mission {mission_text}"
                result = await self.resolve(synthetic_query)
                if result.resolved:
                    # Return with the ORIGINAL query but resolved entity
                    return ResolvedQuery(
                        original=query,
                        resolved_query=result.resolved_query,
                        resolved=True,
                        entity_type=result.entity_type,
                        entity_id=result.entity_id,
                        entity_name=result.entity_name,
                        enriched_query=f"{query} (regarding Mission {result.entity_name})"
                    )
        
        return ResolvedQuery(original=query, resolved_query=query, resolved=False)


class ChallengeNumberStrategy(ResolutionStrategy):
    """Resolves 'Challenge 1 Mission 5' → specific challenge."""
    
    def __init__(self, db_handler):
        self.db = db_handler
    
    async def resolve(self, query: str, entity_type: Optional[str] = None) -> ResolvedQuery:
        """Resolve challenge references like 'Challenge 1 in Mission 5'."""
        # Pattern: Challenge + number + (optional) + Mission + number
        pattern = r"Challenge\s+(\d+)(?:\s+(?:in|of|from)\s+)?(?:Mission\s+(\d+))?"
        match = re.search(pattern, query, re.IGNORECASE)
        
        if not match:
            return ResolvedQuery(
                original=query,
                resolved_query=query,
                resolved=False
            )
        
        challenge_num = match.group(1)
        mission_num = match.group(2) if match.group(2) else None
        
        try:
            # Build query to find challenge
            filters = {"challenge_position": int(challenge_num)}
            if mission_num:
                # First resolve the mission to get space_id
                mission_strategy = MissionNumberStrategy(self.db)
                mission_result = await mission_strategy.resolve(f"Mission {mission_num}")
                if mission_result.resolved and mission_result.entity_id:
                    filters["space_id"] = mission_result.entity_id
            
            result = await self.db.execute(
                resource="challenges",
                **filters,
                limit=1
            )
            
            challenges = result.get("metadata", [])
            if challenges and len(challenges) > 0:
                challenge = challenges[0]
                challenge_name = challenge.get("challenge_name") or challenge.get("name", "")
                
                return ResolvedQuery(
                    original=query,
                    resolved_query=challenge_name,
                    resolved=True,
                    entity_type="challenge",
                    entity_id=challenge.get("challenge_id") or challenge.get("id"),
                    entity_name=challenge_name,
                    enriched_query=f"{query} ({challenge_name})"
                )
        except Exception as e:
            print(f"⚠️ Error resolving challenge: {e}")
        
        return ResolvedQuery(
            original=query,
            resolved_query=query,
            resolved=False
        )
    
    async def resolve_from_context(
        self, 
        query: str, 
        conversation_history: List[Dict[str, Any]]
    ) -> ResolvedQuery:
        """Resolve using conversation context."""
        # Look for recently mentioned missions in conversation history
        recent_mission = None
        for msg in reversed(conversation_history):
            content = msg.get("content", "")
            # Try to find mission reference
            mission_match = re.search(r"Mission\s+(\d+|\w+)", content, re.IGNORECASE)
            if mission_match:
                recent_mission = mission_match.group(1)
                break
        
        if recent_mission:
            # Re-run with mission context
            enhanced_query = f"Challenge in Mission {recent_mission}"
            return await self.resolve(enhanced_query)
        
        return ResolvedQuery(
            original=query,
            resolved_query=query,
            resolved=False
        )


class EntityResolver:
    """Main entity resolver that orchestrates multiple resolution strategies.
    
    Extensible: each platform registers its own resolution strategies.
    """
    
    def __init__(self, db_handler):
        """Initialize with database handler.
        
        Args:
            db_handler: DatabaseToolHandler instance
        """
        self.db = db_handler
        self._strategies: List[ResolutionStrategy] = []
        
        # Register default AIO strategies
        self.register_strategy(MissionNumberStrategy(db_handler))
        self.register_strategy(ChallengeNumberStrategy(db_handler))
    
    def register_strategy(self, strategy: ResolutionStrategy):
        """Register a new resolution strategy.
        
        Args:
            strategy: ResolutionStrategy implementation
        """
        self._strategies.append(strategy)
    
    async def resolve(
        self, 
        query: str, 
        entity_type: Optional[str] = None,
        conversation_history: Optional[List[Dict[str, Any]]] = None
    ) -> ResolvedQuery:
        """Resolve entity references using query + optional conversation context.
        
        Args:
            query: User input to resolve
            entity_type: Optional hint about expected entity type
            conversation_history: Recent conversation turns for context
            
        Returns:
            ResolvedQuery with resolution results
        """
        # First try direct resolution from query alone
        for strategy in self._strategies:
            result = await strategy.resolve(query, entity_type)
            if result.resolved:
                return result
        
        # If unresolved and we have history, try context-based resolution
        if conversation_history:
            for strategy in self._strategies:
                result = await strategy.resolve_from_context(query, conversation_history)
                if result.resolved:
                    return result
        
        return ResolvedQuery(
            original=query,
            resolved_query=query,
            resolved=False
        )
