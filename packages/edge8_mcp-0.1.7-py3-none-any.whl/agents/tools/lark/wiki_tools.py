import os
import sys
import asyncio
from typing import Dict, Any, List, Optional

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.insert(0, project_root)

from dotenv import load_dotenv
from connectors.lark_interactions.wiki import Wiki, Nodes
from connectors.lark_interactions.doc import LarkDocs
from agents.tools.shared import ToolHandler
from agents.tools.lark.wiki_formatter import WikiDocumentFormatter

load_dotenv()


class WikiSearchResult:
    """Represents a wiki node search result with extracted content."""
    
    def __init__(self, node: Dict[str, Any], content: Optional[str] = None, metadata: Optional[Dict[str, Any]] = None):
        self.node = node
        self.content = content
        self.metadata = metadata or {}
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "node": self.node,
            "content": self.content,
            "metadata": self.metadata
        }


class LarkWikiSearchHandler(ToolHandler):
    """Search wiki spaces and nodes by query."""
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        access_token = kwargs.get("access_token")
        query = kwargs.get("query")
        space_id = kwargs.get("space_id", "")
        node_id = kwargs.get("node_id", "")
        page_size = kwargs.get("page_size", 50)
        
        try:
            wiki = Wiki(is_auth=True, access_token=access_token)
            results = wiki.search(query, space_id=space_id, node_id=node_id, page_size=page_size)
            
            return {
                "content": f"Successfully searched wiki for '{query}'",
                "metadata": {"search_results": results, "total_count": len(results)}
            }
        except Exception as e:
            return {"error": f"Failed to search wiki: {str(e)}"}


class LarkWikiListSpacesHandler(ToolHandler):
    """List all wiki spaces."""
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        access_token = kwargs.get("access_token")
        page_size = kwargs.get("page_size", 50)
        page_token = kwargs.get("page_token", "")
        
        try:
            wiki = Wiki(is_auth=True, access_token=access_token)
            spaces = wiki.list_spaces(page_size=page_size, page_token=page_token)
            
            return {
                "content": f"Successfully listed {len(spaces)} wiki spaces",
                "metadata": {"spaces": spaces, "total_count": len(spaces)}
            }
        except Exception as e:
            return {"error": f"Failed to list wiki spaces: {str(e)}"}


class LarkWikiGetSpaceHandler(ToolHandler):
    """Get details of a specific wiki space."""
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        access_token = kwargs.get("access_token")
        space_id = kwargs.get("space_id")
        
        try:
            wiki = Wiki(is_auth=True, access_token=access_token)
            space = wiki.get_space(space_id)
            
            return {
                "content": f"Successfully retrieved wiki space '{space.get('name', 'Unknown')}'",
                "metadata": {"space": space}
            }
        except Exception as e:
            return {"error": f"Failed to get wiki space: {str(e)}"}


class LarkWikiListNodesHandler(ToolHandler):
    """List all nodes in a wiki space."""
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        access_token = kwargs.get("access_token")
        space_id = kwargs.get("space_id")
        page_size = kwargs.get("page_size", 50)
        page_token = kwargs.get("page_token", "")
        
        try:
            nodes = Nodes(space_id=space_id, is_auth=True, access_token=access_token)
            node_list = nodes.list(page_size=page_size, page_token=page_token)
            
            return {
                "content": f"Successfully listed {len(node_list)} nodes in space",
                "metadata": {"nodes": node_list, "total_count": len(node_list)}
            }
        except Exception as e:
            return {"error": f"Failed to list wiki nodes: {str(e)}"}


class LarkWikiGetNodeHandler(ToolHandler):
    """Get details of a specific wiki node."""
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        access_token = kwargs.get("access_token")
        node_token = kwargs.get("node_token")
        
        try:
            nodes = Nodes(is_auth=True, access_token=access_token)
            node = nodes.get(node_token)
            
            return {
                "content": f"Successfully retrieved wiki node '{node.get('title', 'Unknown')}'",
                "metadata": {"node": node}
            }
        except Exception as e:
            return {"error": f"Failed to get wiki node: {str(e)}"}


class LarkWikiExtractDocxContentHandler(ToolHandler):
    """
    Extract markdown content from docx-type wiki nodes.
    
    This handler searches wiki nodes and extracts markdown content from nodes
    of type "docx" using the LarkDocs.get_content method.
    """
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        access_token = kwargs.get("access_token")
        space_id = kwargs.get("space_id")
        query = kwargs.get("query", "")
        extract_all_nodes = kwargs.get("extract_all_nodes", False)
        page_size = kwargs.get("page_size", 50)
        
        try:
            results = []
            
            # Search or list nodes
            if query:
                wiki = Wiki(is_auth=True, access_token=access_token)
                search_results = wiki.search(query, space_id=space_id, page_size=page_size)
                nodes_to_process = search_results
            elif extract_all_nodes and space_id:
                nodes_connector = Nodes(space_id=space_id, is_auth=True, access_token=access_token)
                nodes_to_process = nodes_connector.list(page_size=page_size)
            else:
                return {"error": "Either 'query' or 'extract_all_nodes' with 'space_id' must be provided"}
            
            # Extract content from docx nodes
            docs = LarkDocs(is_auth=True, access_token=access_token)
            
            for node in nodes_to_process:
                # Check if node is of type docx
                obj_type = node.get("obj_type", "")
                if obj_type.lower() == "docx":
                    try:
                        doc_token = node.get("node_token") or node.get("token")
                        if not doc_token:
                            continue
                        
                        # Extract markdown content
                        markdown_content = docs.get_content(
                            doc_id=doc_token,
                            doc_type="docx",
                            content_type="markdown",
                            lang="en"
                        )
                        
                        # Get document metadata
                        doc_metadata = docs.get(doc_token)
                        
                        result = WikiSearchResult(
                            node=node,
                            content=markdown_content,
                            metadata={
                                "doc_token": doc_token,
                                "title": node.get("title", ""),
                                "creator": node.get("creator", ""),
                                "owner": node.get("owner", ""),
                                "doc_metadata": doc_metadata
                            }
                        )
                        results.append(result.to_dict())
                    except Exception as e:
                        # Log error but continue processing other nodes
                        results.append({
                            "node": node,
                            "error": f"Failed to extract content: {str(e)}",
                            "metadata": {}
                        })
            
            if not results:
                return {
                    "content": "No docx-type nodes found to extract",
                    "metadata": {"extracted_nodes": [], "total_count": 0}
                }
            
            return {
                "content": f"Successfully extracted content from {len(results)} docx nodes",
                "metadata": {"extracted_nodes": results, "total_count": len(results)}
            }
        except Exception as e:
            return {"error": f"Failed to extract wiki docx content: {str(e)}"}


class LarkWikiSearchAndExtractHandler(ToolHandler):
    """
    Comprehensive handler that searches wiki spaces/nodes and extracts markdown
    content from docx-type sub-nodes with metadata.
    
    This is the main entry point for wiki search and extraction workflows.
    """
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        access_token = kwargs.get("access_token")
        query = kwargs.get("query")
        space_id = kwargs.get("space_id", "")
        include_subnodes = kwargs.get("include_subnodes", True)
        page_size = kwargs.get("page_size", 50)
        
        try:
            wiki = Wiki(is_auth=True, access_token=access_token)
            docs = LarkDocs(is_auth=True, access_token=access_token)
            
            # Search for nodes matching query
            search_results = wiki.search(query, space_id=space_id, page_size=page_size)
            
            if not search_results:
                return {
                    "content": f"No wiki nodes found matching query '{query}'",
                    "metadata": {"results": [], "total_count": 0}
                }
            
            extracted_results = []
            
            for node in search_results:
                node_result = {
                    "node_info": {
                        "token": node.get("node_token") or node.get("token"),
                        "title": node.get("title", ""),
                        "type": node.get("obj_type", ""),
                        "creator": node.get("creator", ""),
                        "owner": node.get("owner", ""),
                    },
                    "content": None,
                    "metadata": {},
                    "subnodes": []
                }
                
                # If node is docx type, extract its content
                if node.get("obj_type", "").lower() == "docx":
                    try:
                        doc_token = node.get("node_token") or node.get("token")
                        if doc_token:
                            markdown_content = docs.get_content(
                                doc_id=doc_token,
                                doc_type="docx",
                                content_type="markdown",
                                lang="en"
                            )
                            doc_metadata = docs.get(doc_token)
                            
                            node_result["content"] = markdown_content
                            node_result["metadata"] = {
                                "doc_token": doc_token,
                                "document_id": doc_metadata.get("document_id", ""),
                                "created_time": doc_metadata.get("created_time", ""),
                                "modified_time": doc_metadata.get("modified_time", ""),
                                "owner": doc_metadata.get("owner", ""),
                            }
                    except Exception as e:
                        node_result["metadata"]["extraction_error"] = str(e)
                
                # Extract subnodes if requested and space_id is available
                if include_subnodes and space_id:
                    try:
                        nodes_connector = Nodes(space_id=space_id, is_auth=True, access_token=access_token)
                        all_nodes = nodes_connector.list(page_size=page_size)
                        
                        # Find subnodes (nodes with parent_node_token matching current node)
                        node_token = node.get("node_token") or node.get("token")
                        subnodes = [n for n in all_nodes if n.get("parent_node_token") == node_token]
                        
                        for subnode in subnodes:
                            if subnode.get("obj_type", "").lower() == "docx":
                                try:
                                    subnode_token = subnode.get("node_token") or subnode.get("token")
                                    if subnode_token:
                                        subnode_content = docs.get_content(
                                            doc_id=subnode_token,
                                            doc_type="docx",
                                            content_type="markdown",
                                            lang="en"
                                        )
                                        subnode_metadata = docs.get(subnode_token)
                                        
                                        node_result["subnodes"].append({
                                            "token": subnode_token,
                                            "title": subnode.get("title", ""),
                                            "type": subnode.get("obj_type", ""),
                                            "content": subnode_content,
                                            "metadata": {
                                                "doc_token": subnode_token,
                                                "document_id": subnode_metadata.get("document_id", ""),
                                                "created_time": subnode_metadata.get("created_time", ""),
                                                "modified_time": subnode_metadata.get("modified_time", ""),
                                                "owner": subnode_metadata.get("owner", ""),
                                            }
                                        })
                                except Exception as e:
                                    node_result["subnodes"].append({
                                        "token": subnode.get("node_token") or subnode.get("token"),
                                        "title": subnode.get("title", ""),
                                        "error": f"Failed to extract subnode content: {str(e)}"
                                    })
                    except Exception as e:
                        node_result["metadata"]["subnodes_extraction_error"] = str(e)
                
                extracted_results.append(node_result)
            
            return {
                "content": f"Successfully searched and extracted content from {len(extracted_results)} wiki nodes",
                "metadata": {
                    "results": extracted_results,
                    "total_count": len(extracted_results),
                    "query": query,
                    "space_id": space_id
                }
            }
        except Exception as e:
            return {"error": f"Failed to search and extract wiki content: {str(e)}"}


class LarkWikiGetSpaceByNameHandler(ToolHandler):
    """
    Get space ID by space name, find a node by name within that space,
    check for children nodes, and extract metadata and markdown from all children.
    """
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        access_token = kwargs.get("access_token")
        space_name = kwargs.get("space_name")
        node_name = kwargs.get("node_name")
        
        try:
            wiki = Wiki(is_auth=True, access_token=access_token)
            docs = LarkDocs(is_auth=True, access_token=access_token)
            
            # Step 1: Get all spaces and find the one matching space_name
            all_spaces = wiki.list_spaces(page_size=100)
            target_space = None
            
            for space in all_spaces:
                if space.get("name", "").lower() == space_name.lower():
                    target_space = space
                    break
            
            if not target_space:
                return {
                    "error": f"Space '{space_name}' not found",
                    "metadata": {"available_spaces": [s.get("name") for s in all_spaces]}
                }
            
            space_id = target_space.get("space_id", "")
            
            # Step 2: Get all nodes in the space and find the one matching node_name
            nodes_connector = Nodes(space_id=space_id, is_auth=True, access_token=access_token)
            all_nodes = nodes_connector.list(page_size=100)
            target_node = None
            
            for node in all_nodes:
                if node.get("title", "").lower() == node_name.lower():
                    target_node = node
                    break
            
            if not target_node:
                return {
                    "error": f"Node '{node_name}' not found in space '{space_name}'",
                    "metadata": {
                        "space_id": space_id,
                        "space_name": target_space.get("name"),
                        "available_nodes": [n.get("title") for n in all_nodes]
                    }
                }
            
            target_node_token = target_node.get("node_token") or target_node.get("token")
            
            # Step 3: Find all children nodes (nodes with parent_node_token matching target_node)
            children_nodes = [n for n in all_nodes if n.get("parent_node_token") == target_node_token]
            
            if not children_nodes:
                return {
                    "content": f"Node '{node_name}' has no children",
                    "metadata": {
                        "space_id": space_id,
                        "space_name": target_space.get("name"),
                        "node_token": target_node_token,
                        "node_title": target_node.get("title"),
                        "children_count": 0,
                        "children": []
                    }
                }
            
            # Step 4: Extract metadata and markdown from all children nodes
            children_data = []
            
            for child in children_nodes:
                child_token = child.get("node_token") or child.get("token")
                child_result = {
                    "token": child_token,
                    "title": child.get("title", ""),
                    "type": child.get("obj_type", ""),
                    "creator": child.get("creator", ""),
                    "owner": child.get("owner", ""),
                    "content": None,
                    "metadata": {}
                }
                
                # If child is docx type, extract markdown content and metadata
                if child.get("obj_type", "").lower() == "docx":
                    try:
                        # Get markdown content
                        markdown_content = docs.get_content(
                            doc_id=child_token,
                            doc_type="docx",
                            content_type="markdown",
                            lang="en"
                        )
                        
                        # Get document metadata
                        doc_metadata = docs.get(child_token)
                        
                        child_result["content"] = markdown_content
                        child_result["metadata"] = {
                            "doc_token": child_token,
                            "document_id": doc_metadata.get("document_id", ""),
                            "created_time": doc_metadata.get("created_time", ""),
                            "modified_time": doc_metadata.get("modified_time", ""),
                            "owner": doc_metadata.get("owner", ""),
                            "creator": doc_metadata.get("creator", ""),
                        }
                    except Exception as e:
                        child_result["metadata"]["extraction_error"] = str(e)
                else:
                    # For non-docx nodes, still capture basic metadata
                    child_result["metadata"] = {
                        "type": child.get("obj_type", ""),
                        "note": "Content extraction only available for docx-type nodes"
                    }
                
                children_data.append(child_result)
            
            return {
                "content": f"Successfully found space '{space_name}', node '{node_name}', and extracted data from {len(children_data)} children",
                "metadata": {
                    "space_id": space_id,
                    "space_name": target_space.get("name"),
                    "node_token": target_node_token,
                    "node_title": target_node.get("title"),
                    "node_type": target_node.get("obj_type", ""),
                    "children_count": len(children_data),
                    "children": children_data
                }
            }
        except Exception as e:
            return {"error": f"Failed to get space and extract children content: {str(e)}"}


class LarkWikiFormatChildrenToTableHandler(ToolHandler):
    """
    Use LLM to format wiki child node data into table records with predefined keys.
    
    This handler uses the WikiDocumentFormatter to process children data,
    reusing precise values from metadata and intelligently extracting content.
    """
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        children_data = kwargs.get("children_data")  # List of child node dicts
        predefined_keys = kwargs.get("predefined_keys")  # List of target table column names
        llm_model = kwargs.get("llm_model", "gpt-4o-mini")  # LLM model to use
        
        if not children_data:
            return {"error": "children_data is required"}
        
        if not predefined_keys:
            return {"error": "predefined_keys is required"}
        
        try:
            # Initialize formatter
            formatter = WikiDocumentFormatter(llm_model=llm_model)
            
            # Format all documents
            result = await formatter.format_documents(children_data, predefined_keys)
            
            # Check for errors
            if result.get("errors"):
                return {
                    "error": f"Failed to format {len(result['errors'])} children",
                    "metadata": result
                }
            
            return {
                "content": f"Successfully formatted {result['total_count']} wiki children into table records",
                "metadata": result
            }
        except Exception as e:
            return {"error": f"Failed to format wiki children to table records: {str(e)}"}


class LarkWikiExtractAndFormatHandler(ToolHandler):
    """
    End-to-end handler that combines space/node lookup, child extraction,
    and LLM-based formatting into table records in a single call.
    """
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        access_token = kwargs.get("access_token")
        space_name = kwargs.get("space_name")
        node_name = kwargs.get("node_name")
        predefined_keys = kwargs.get("predefined_keys")
        llm_model = kwargs.get("llm_model", "gpt-4o-mini")
        
        try:
            # Step 1: Get space, node, and children
            space_handler = LarkWikiGetSpaceByNameHandler()
            space_result = await space_handler.execute(
                access_token=access_token,
                space_name=space_name,
                node_name=node_name
            )
            
            if "error" in space_result:
                return space_result
            
            children_data = space_result.get("metadata", {}).get("children", [])
            
            if not children_data:
                return {
                    "content": f"Node '{node_name}' has no children to format",
                    "metadata": {
                        "records": [],
                        "total_count": 0
                    }
                }
            
            # Step 2: Format children using LLM
            format_handler = LarkWikiFormatChildrenToTableHandler()
            format_result = await format_handler.execute(
                children_data=children_data,
                predefined_keys=predefined_keys,
                llm_model=llm_model
            )
            
            if "error" in format_result:
                return format_result
            
            # Enrich result with source information
            result_metadata = format_result.get("metadata", {})
            result_metadata["source"] = {
                "space_name": space_name,
                "node_name": node_name,
                "space_id": space_result.get("metadata", {}).get("space_id"),
                "node_token": space_result.get("metadata", {}).get("node_token")
            }
            
            return {
                "content": f"Successfully extracted and formatted {len(result_metadata.get('records', []))} records from '{node_name}' children",
                "metadata": result_metadata
            }
        except Exception as e:
            return {"error": f"Failed to extract and format wiki data: {str(e)}"}


__all__ = [
    "LarkWikiSearchHandler",
    "LarkWikiListSpacesHandler",
    "LarkWikiGetSpaceHandler",
    "LarkWikiListNodesHandler",
    "LarkWikiGetNodeHandler",
    "LarkWikiExtractDocxContentHandler",
    "LarkWikiSearchAndExtractHandler",
    "LarkWikiGetSpaceByNameHandler",
    "LarkWikiFormatChildrenToTableHandler",
    "LarkWikiExtractAndFormatHandler",
    "WikiSearchResult"
]
