# Lark Tools
import asyncio
import os

from agents.tools.shared import ToolHandler
from typing import Dict, Any
from connectors.lark_interactions.contacts import Users, Organizations
from connectors.lark_interactions.base import LarkBaseTable
from dotenv import load_dotenv

load_dotenv()

# GET current Lark user with supabase profile ID:
class LarkGetCurrentUserHandler(ToolHandler):
    async def execute(self, **kwargs) -> Dict[str, Any]:
        access_token = kwargs.get("access_token")

        try:
            lark_user_handler = Users(is_auth=True, access_token=access_token)
            # M-1: wrap blocking requests call
            lark_user = await asyncio.to_thread(lark_user_handler.get_current_user)
            email = lark_user.get("email", None)
            if email is None:
              return { "error": "Unauthorized" }

            return { "content": "User found", "metadata": { "user": lark_user } }
        except Exception as e:
            return {"error": f"Failed to retrieve user: {str(e)}"}


# FIND Lark user
class GetLarkUserHandler(ToolHandler):
    async def execute(self, **kwargs) -> Dict[str, Any]:
        access_token = kwargs.get("access_token")
        query = kwargs.get("query")
        print("Query: ", query)
        print(f"Access: {access_token[:5] if access_token else 'None'}...")
        users = []
        try:
            org_handler = Organizations(is_auth=True, access_token=access_token)
            user_handler = Users()
            # M-1: wrap blocking requests calls
            search_results = await asyncio.to_thread(org_handler.search_employee, query, page_size=10)
            if len(search_results) == 0:
                return {"error": "User not found"}

            for u in search_results:
                uid = u.get("base_info", {}).get("employee_id", "")
                user_info = await asyncio.to_thread(user_handler.get_single_user, uid)
                email = user_info.get("email", "")
                name = user_info.get("name", "")
                users.append({"id": uid, "email": email, "name": name})
            users_str = "\n".join([f"- Name: {user.get('name', '')}\n- Email: {user.get('email', '')}\n- ID: {user.get('id', '')}" for user in users])
            return { "content": users_str, "metadata": {"users": users} }
        except Exception as e:
            return {"error": f"Failed to retrieve user: {str(e)}"}

class LarkGetUserByIdHandler(ToolHandler):
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """Resolve a Lark open_id or user_id to a full user profile."""
        user_id = kwargs.get("user_id", "")
        id_type = kwargs.get("id_type", "open_id")
        try:
            user = await asyncio.to_thread(Users().get_single_user, user_id, id_type)
            return {"content": f"User '{user.get('name', user_id)}' found.", "metadata": {"user": user}}
        except Exception as e:
            return {"error": f"Failed to get user: {str(e)}"}


class LarkListDepartmentMembersHandler(ToolHandler):
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """List all members of a Lark department."""
        access_token = kwargs.get("access_token")
        department_id = kwargs.get("department_id", "")
        page_size = kwargs.get("page_size", 50)
        try:
            members = await asyncio.to_thread(
                Users(is_auth=True, access_token=access_token).list_by_department,
                department_id, "open_id", "open_department_id", page_size,
            )
            return {
                "content": f"Found {len(members)} member(s) in department '{department_id}'.",
                "metadata": {"members": members, "count": len(members)},
            }
        except Exception as e:
            return {"error": f"Failed to list department members: {str(e)}"}


__all__ = [
  "LarkGetCurrentUserHandler",
  "GetLarkUserHandler",
  "LarkGetUserByIdHandler",
  "LarkListDepartmentMembersHandler",
]