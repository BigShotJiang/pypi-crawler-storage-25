# Lark Tools
import os
from agents.tools.shared import ToolHandler
from typing import Dict, Any
from connectors.lark_interactions.contacts import Users, Organizations
from .base_tools import LarkBaseCheckAuthTool
from connectors.lark_interactions.auth import LarkAuth
from dotenv import load_dotenv

load_dotenv()

SERVER_URL = os.getenv("SERVER_URL")
LOCALHOST_URL = os.getenv("LOCALHOST_URL")
PY_ENV = os.getenv("PY_ENV")

## Lark OAuth Tool:
class LarkOAuthHandler(ToolHandler):
    async def execute(self) -> Dict[str, Any]:
        try:
            lark_auth = LarkAuth()
            lark_redirect_url = lark_auth.oauth_code()
            return {"content":"Successfully performed OAuth", "metadata": {"redirect_uri": lark_redirect_url}}
        except Exception as e:
            return {"error": f"Failed to perform OAuth: {str(e)}"}
          
## Lark Get Auth Session of User from supabase, if expired, refresh it

class LarkGetAuthSessionHandler(ToolHandler):
  async def execute(self, **kwargs) -> Dict[str, Any]:
    lark_user_id = kwargs.get("lark_user_id")
    email = kwargs.get("email")
    try:
        user_handler = Users()
        lark_auth = LarkAuth()
        
        # Get user email from lark user id
        if lark_user_id:
            lark_user = user_handler.get_single_user(id=lark_user_id)
            user_email = lark_user.get("email")
        
        if email:
            user_email = email
        # Get user id from user email
        supabase_client = get_custom_client(key=SUPABASE_SERVICE_ROLE_KEY)
        user = supabase_client.table("profiles").select("id").eq("email", user_email).execute().data
        
        if len(user) == 0:
            return {"content": "No session", "metadata": {"access_token": None}}
        user_id = user[0].get("id")
        print("user_id: ",user_id)
        # Check tokens validity
        try:
            is_tokens_valid: dict = supabase_client.rpc(
                "lark_secret_check_by_user", 
                {"p_user_id": user_id}
            ).execute().data[0]
        except Exception as e:
            return {"content": "No session", "metadata": {"access_token": None}, "error": str(e)}
        # If tokens are valid
        if is_tokens_valid:
            if is_tokens_valid.get("needs_refresh"):
                # Refresh tokens
                new_tokens = lark_auth.refresh_access_token(is_tokens_valid.get("refresh_token"))
                # Update tokens in supabase
                updated_tokens = supabase_client.rpc("insert_or_update_lark_secret", {
                    "p_user_id": user_id,
                    "p_access_token": new_tokens.get("access_token"),
                    "p_refresh_token": new_tokens.get("refresh_token"),
                    "p_expires_in": new_tokens.get("expires_in"),
                    "p_refresh_token_expires_in": new_tokens.get("refresh_token_expires_in", new_tokens.get("expires_in"))
                }).execute().data
                # print("updated_tokens: ",updated_tokens)
                return {"content": "Session updated", "metadata": {"access_token": updated_tokens.get("access_token")}}
            else:
                is_tokens_valid.pop("needs_refresh")
                return {"content": "Session valid", "metadata": {"access_token": is_tokens_valid.get("access_token")}}
        
        # If tokens are not valid
        if not is_tokens_valid:
            return {"content": "No session", "metadata": {"access_token": None}}
    except Exception as e:
        raise Exception(str(e))
        

__all__ = [
  "LarkOAuthHandler", 
  "LarkGetAuthSessionHandler"
]