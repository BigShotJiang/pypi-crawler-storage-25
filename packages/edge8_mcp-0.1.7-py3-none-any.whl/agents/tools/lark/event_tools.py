# Lark Tools
import os
from agents.tools.shared import ToolHandler
from connectors.lark_interactions.calendar import LarkCalendars, LarkEvents
from utils.text_processing import text_search
from utils.custom_types import LarkCalendarEventSummary, LarkEventAttendeeSimple, LarkEventAttendee
from dotenv import load_dotenv
from .user_tools import LarkGetCurrentUserHandler

load_dotenv()

class LarkGetCurrentUserCalendarHandler(ToolHandler):
    async def execute(self, **kwargs):
        bot_type = "meeting"
        access_token = kwargs.get("access_token")
        
        try:
            # Init Supabase, Lark, ThoughtFlow
            lark_calendars_handler = LarkCalendars(is_auth=True, access_token=access_token, bot_type=bot_type)
            
            lark_get_current_user_tool = LarkGetCurrentUserHandler()
            user = await lark_get_current_user_tool.execute(access_token=access_token)
            email = user.get("metadata", {}).get("lark_info", {}).get("email", "")
            
            calendars = lark_calendars_handler.search(query=email)
            if(len(calendars) == 0):
                return {"error": "No calendars found"}
            
            return {"content": "Successfully retrieved calendars", "metadata": {"calendars": calendars}}
            
        except Exception as e:
            return {"error": f"Failed to retrieve calendars: {str(e)}"}

class LarkSearchEventsHandler(ToolHandler):
    async def execute(self, **kwargs):
        access_token = kwargs.get("access_token")
        query = kwargs.get("query", "")
        start_time = kwargs.get("start_time", None)
        end_time = kwargs.get("end_time", None)
        try:
            # Init Supabase, Lark, ThoughtFlow
            lark_calendars_tool = LarkGetCurrentUserCalendarHandler()
            lark_events_handler = LarkEvents(is_auth=True, access_token=access_token)
        
            calendar = await lark_calendars_tool.execute(access_token=access_token)
            calendar_id = calendar.get("metadata", {}).get("calendars", [{}])[0].get("calendar_id", "")
            if calendar_id == "":
              return {"error": "No calendars found"}
            filters = {}
            if start_time is not None:
              filters["start_time"] = {"date": start_time, "timestamp": None, "timezone": None}
            if end_time is not None:
              filters["end_time"] = {"date": end_time, "timestamp": None, "timezone": None}
            events = lark_events_handler.search(calendar_id = calendar_id, query=query, filter=filters)
            
            if len(events) == 0:
              return {"error": "No events found"}
            
            return {"content": "Successfully retrieved events", "metadata": {"events": events}}
        
        except Exception as e:
            return {"error": f"Failed to list events: {str(e)}"}
          
class LarkGetEventHandler(ToolHandler):
    async def execute(self, **kwargs):
        access_token = kwargs.get("access_token")
        event_id = kwargs.get("event_id", "")
        extracted_keys = kwargs.get("extracted_keys", [])
        try:
            # Init Supabase, Lark, ThoughtFlow
            lark_calendars_tool = LarkGetCurrentUserCalendarHandler()
            lark_events_handler = LarkEvents(is_auth=True, access_token=access_token)
        
            calendar = await lark_calendars_tool.execute(access_token=access_token)
            calendar_id = calendar.get("metadata", {}).get("calendars", [{}])[0].get("calendar_id", "")
            if calendar_id == "":
              return {"error": "No calendars found"}
            event = lark_events_handler.get(calendar_id = calendar_id, event_id=event_id)
            
            if event is None:
              return {"error": "No events found"}

            # Map attendees
            attendees: LarkEventAttendee = event.get("attendees", [])
            mapped_attendees: list[LarkEventAttendeeSimple] = [{
              "user_id": attendee.get("user_id", ""), 
              "name": attendee.get("display_name", ""),
              "rsvp_status": attendee.get("rsvp_status", ""),
              "third_party_email": attendee.get("third_party_email", ""),
              "is_external": attendee.get("is_external", False),
            } for attendee in attendees]
            # Simplify event
            mapped_event: LarkCalendarEventSummary = {
              "event_id": event.get("event_id", ""),
              "organizer_calendar_id": event.get("organizer_calendar_id", ""),
              "organizer_id": event.get("organizer", {}).get("user_id", ""),
              "organizer_name": event.get("organizer", {}).get("display_name", ""),
              "summary": event.get("summary", ""),
              "description": event.get("description", ""),
              "start_time": event.get("start_time", {}).get("timestamp", ""),
              "end_time": event.get("end_time", {}).get("timestamp", ""),
              "vchat": event.get("vchat", {}),
              "visibility": event.get("visibility", ""),
              "attendees": mapped_attendees,
              "vc_url": event.get("vchat", {}).get("meeting_url", ""),
              "vc_type": event.get("vchat", {}).get("vc_type", ""),
              "vc_description": event.get("vchat", {}).get("description", ""),
              "vc_permission": event.get("vchat", {}).get("meeting_settings", {}).get("join_meeting_permission", ""),
            }
            # Extract specific keys if extracted_keys is not empty
            response_event = mapped_event
            if len(extracted_keys) > 0:
              for key in extracted_keys:
                response_event[key] = mapped_event.get(key, "")
            
            return {"content": "Successfully retrieved events", "metadata": {"event": response_event}}
        
        except Exception as e:
            return {"error": f"Failed to list events: {str(e)}"}

class LarkListEventsHandler(ToolHandler):
    async def execute(self, **kwargs):
        access_token = kwargs.get("access_token")
        anchor_time = int(kwargs.get("anchor_time", 1761338478))
        query = kwargs.get("query", "")
        try:
            # Init Supabase, Lark, ThoughtFlow
            lark_calendars_tool = LarkGetCurrentUserCalendarHandler()
            lark_events_handler = LarkEvents(is_auth=True, access_token=access_token)
        
            calendar = await lark_calendars_tool.execute(access_token=access_token)
            calendar_id = calendar.get("metadata", {}).get("calendars", [{}])[0].get("calendar_id", "")
            if calendar_id == "":
              return {"error": "No calendars found"}
            
            events = lark_events_handler.list(calendar_id, anchor_time=anchor_time)
            filtered_events = [
                event for event in events \
                if event.get("status", "") != "cancelled" \
                and event.get("vchat", None) is not None
                and event.get("vchat", {}).get("meeting_url", "") != ""
            ]
            
            if query != "":
              filtered_events = [
                event for event in events \
                if text_search(event.get("summary", ""), query)
              ]
            
            if len(filtered_events) == 0:
              return {"error": "No events found"}
            
            return {"content": "Successfully retrieved events", "metadata": {"events": filtered_events}}
        
        except Exception as e:
            return {"error": f"Failed to list events: {str(e)}"}

import asyncio
import logging

_event_logger = logging.getLogger(__name__)


class LarkCreateEventHandler(ToolHandler):
    async def execute(self, **kwargs) -> dict:
        """Create a new calendar event."""
        access_token = kwargs.get("access_token")
        summary = kwargs.get("summary", "")
        description = kwargs.get("description", "")
        start_time = kwargs.get("start_time", "")  # ISO date or unix timestamp string
        end_time = kwargs.get("end_time", "")
        attendee_ids = kwargs.get("attendee_ids", [])  # list of open_ids
        try:
            cal_tool = LarkGetCurrentUserCalendarHandler()
            cal = await cal_tool.execute(access_token=access_token)
            calendar_id = cal.get("metadata", {}).get("calendars", [{}])[0].get("calendar_id", "")
            if not calendar_id:
                return {"error": "No calendar found for this user."}

            event_data: dict = {
                "summary": summary,
                "description": description,
                "start_time": {"timestamp": start_time} if start_time else {},
                "end_time": {"timestamp": end_time} if end_time else {},
            }
            if attendee_ids:
                event_data["attendees"] = [{"type": "user", "user_id": uid} for uid in attendee_ids]

            event = await asyncio.to_thread(
                LarkEvents(is_auth=True, access_token=access_token).create_event,
                calendar_id, event_data,
            )
            return {"content": f"Successfully created event '{summary}'.", "metadata": {"event": event}}
        except Exception as e:
            _event_logger.exception("LarkCreateEventHandler failed")
            return {"error": f"Failed to create event: {str(e)}"}


class LarkUpdateEventHandler(ToolHandler):
    async def execute(self, **kwargs) -> dict:
        """Update an existing calendar event."""
        access_token = kwargs.get("access_token")
        event_id = kwargs.get("event_id", "")
        updates = kwargs.get("updates", {})  # arbitrary fields to merge
        try:
            cal_tool = LarkGetCurrentUserCalendarHandler()
            cal = await cal_tool.execute(access_token=access_token)
            calendar_id = cal.get("metadata", {}).get("calendars", [{}])[0].get("calendar_id", "")
            if not calendar_id:
                return {"error": "No calendar found for this user."}

            event = await asyncio.to_thread(
                LarkEvents(is_auth=True, access_token=access_token).update,
                calendar_id, event_id, updates,
            )
            return {"content": f"Successfully updated event '{event_id}'.", "metadata": {"event": event}}
        except Exception as e:
            _event_logger.exception("LarkUpdateEventHandler failed")
            return {"error": f"Failed to update event: {str(e)}"}


class LarkDeleteEventHandler(ToolHandler):
    async def execute(self, **kwargs) -> dict:
        """Delete a calendar event."""
        access_token = kwargs.get("access_token")
        event_id = kwargs.get("event_id", "")
        try:
            cal_tool = LarkGetCurrentUserCalendarHandler()
            cal = await cal_tool.execute(access_token=access_token)
            calendar_id = cal.get("metadata", {}).get("calendars", [{}])[0].get("calendar_id", "")
            if not calendar_id:
                return {"error": "No calendar found for this user."}

            result = await asyncio.to_thread(
                LarkEvents(is_auth=True, access_token=access_token).delete,
                calendar_id, event_id,
            )
            return {"content": f"Event '{event_id}' deleted.", "metadata": {"result": result}}
        except Exception as e:
            _event_logger.exception("LarkDeleteEventHandler failed")
            return {"error": f"Failed to delete event: {str(e)}"}


__all__ = [
  "LarkListEventsHandler",
  "LarkGetEventHandler",
  "LarkSearchEventsHandler",
  "LarkCreateEventHandler",
  "LarkUpdateEventHandler",
  "LarkDeleteEventHandler",
]