import asyncio
import logging
import os
import sys
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.insert(0, project_root)

from agents.tools.shared import ToolHandler
from connectors.lark_interactions.tasks import LarkTasks
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class LarkCreateTaskHandler(ToolHandler):
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """Create a Lark task."""
        access_token = kwargs.get("access_token")
        summary = kwargs.get("summary", "")
        description = kwargs.get("description", "")
        due_timestamp = kwargs.get("due_timestamp")
        assignee_ids: Optional[List[str]] = kwargs.get("assignee_ids")
        try:
            task = await asyncio.to_thread(
                LarkTasks(access_token=access_token).create,
                summary, description, due_timestamp, assignee_ids,
            )
            return {"content": f"Successfully created task '{summary}'.", "metadata": {"task": task}}
        except Exception as e:
            logger.exception("LarkCreateTaskHandler failed")
            return {"error": f"Failed to create task: {str(e)}"}


class LarkListTasksHandler(ToolHandler):
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """List Lark tasks for the authenticated user."""
        access_token = kwargs.get("access_token")
        completed = kwargs.get("completed")
        page_size = kwargs.get("page_size", 50)
        try:
            tasks = await asyncio.to_thread(
                LarkTasks(access_token=access_token).list,
                page_size, "", completed,
            )
            return {
                "content": f"Found {len(tasks)} task(s).",
                "metadata": {"tasks": tasks, "count": len(tasks)},
            }
        except Exception as e:
            logger.exception("LarkListTasksHandler failed")
            return {"error": f"Failed to list tasks: {str(e)}"}


class LarkUpdateTaskHandler(ToolHandler):
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """Update an existing Lark task."""
        access_token = kwargs.get("access_token")
        task_guid = kwargs.get("task_guid", "")
        try:
            task = await asyncio.to_thread(
                LarkTasks(access_token=access_token).update,
                task_guid,
                kwargs.get("summary"),
                kwargs.get("description"),
                kwargs.get("completed_at"),
                kwargs.get("due_timestamp"),
            )
            return {"content": f"Successfully updated task '{task_guid}'.", "metadata": {"task": task}}
        except Exception as e:
            logger.exception("LarkUpdateTaskHandler failed")
            return {"error": f"Failed to update task: {str(e)}"}


class LarkGetTaskHandler(ToolHandler):
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """Get a single Lark task by GUID."""
        access_token = kwargs.get("access_token")
        task_guid = kwargs.get("task_guid", "")
        try:
            task = await asyncio.to_thread(
                LarkTasks(access_token=access_token).get, task_guid
            )
            return {"content": f"Successfully retrieved task '{task_guid}'.", "metadata": {"task": task}}
        except Exception as e:
            logger.exception("LarkGetTaskHandler failed")
            return {"error": f"Failed to get task: {str(e)}"}


class LarkDeleteTaskHandler(ToolHandler):
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """Delete a Lark task by GUID."""
        access_token = kwargs.get("access_token")
        task_guid = kwargs.get("task_guid", "")
        try:
            success = await asyncio.to_thread(
                LarkTasks(access_token=access_token).delete, task_guid
            )
            return {
                "content": f"Task '{task_guid}' deleted." if success else f"Delete returned non-success for '{task_guid}'.",
                "metadata": {"task_guid": task_guid, "success": success},
            }
        except Exception as e:
            logger.exception("LarkDeleteTaskHandler failed")
            return {"error": f"Failed to delete task: {str(e)}"}


__all__ = ["LarkCreateTaskHandler", "LarkListTasksHandler", "LarkUpdateTaskHandler", "LarkGetTaskHandler", "LarkDeleteTaskHandler"]
