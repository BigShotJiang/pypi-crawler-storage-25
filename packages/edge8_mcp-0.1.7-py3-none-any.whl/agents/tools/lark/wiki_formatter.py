"""
Wiki document formatter module for converting wiki content into structured table records.

This module handles LLM-based formatting of wiki document data into table records
with predefined keys, reusing precise values and intelligently extracting content.
"""

import os
import sys
import json
from typing import Dict, Any, List, Optional

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.insert(0, project_root)

from connectors.openrouter.llm import OpenRouterMultimodalLLM, ChatMessage


class WikiDocumentFormatter:
    """
    Formats wiki document data into structured table records using LLM.
    
    Processes one document at a time, reusing precise values from metadata
    and intelligently extracting content from markdown.
    """
    
    def __init__(self, llm_model: str = "gpt-4o-mini"):
        """
        Initialize the formatter with an LLM model.
        
        Args:
            llm_model: OpenRouter model to use for formatting
        """
        self.llm_model = llm_model
        self.llm_client = OpenRouterMultimodalLLM(model=llm_model)
    
    def _build_response_schema(self, predefined_keys: List[str]) -> Dict[str, Any]:
        """
        Build JSON schema for structured LLM response.
        
        Args:
            predefined_keys: List of required keys in the output record
            
        Returns:
            Response schema dict for OpenRouter API
        """
        return {
            "type": "json_schema",
            "json_schema": {
                "name": "TableRecord",
                "strict": True,
                "schema": {
                    "type": "object",
                    "properties": {
                        key: {"type": ["string", "array", "object", "null"]}
                        for key in predefined_keys
                    },
                    "required": predefined_keys,
                    "additionalProperties": False
                }
            }
        }
    
    def _build_system_prompt(self, predefined_keys: List[str]) -> str:
        """
        Build the system prompt for LLM data mapping.
        
        Args:
            predefined_keys: List of target table column names
            
        Returns:
            System prompt string
        """
        return f"""You are an expert data mapper that transforms wiki document content into structured table records.

Your task is to analyze the provided wiki document and map it into a JSON record with these exact keys:
{json.dumps(predefined_keys, indent=2)}

IMPORTANT GUIDELINES:
1. REUSE PRECISE VALUES: For fields that require precision (IDs, tokens, existing data), use the values provided in the document context
2. EXTRACT FROM CONTENT: For descriptive fields, intelligently extract relevant information from the markdown content
3. TYPE CONSISTENCY: Ensure all values match the expected types (strings, arrays of strings, objects with specific structures)
4. NULL HANDLING: Use null only when information is genuinely unavailable
5. FIELD MAPPING: 
   - Fields with "name" in context (like Assignee) should be objects with "name" key
   - Fields with "link" in context should be objects with "link" key
   - Multi-select fields should be arrays of strings
   - Text fields should be strings

Return ONLY a valid JSON object with all required keys."""
    
    def _build_document_context(self, child_data: Dict[str, Any]) -> str:
        """
        Build context string from child document data.
        
        Args:
            child_data: Dictionary containing child node information
            
        Returns:
            Formatted context string
        """
        child_token = child_data.get("token", "")
        child_title = child_data.get("title", "")
        child_type = child_data.get("type", "")
        child_content = child_data.get("content", "")
        child_metadata = child_data.get("metadata", {})
        
        context_parts = [
            f"Document Title: {child_title}",
            f"Document Type: {child_type}",
            f"Document Token: {child_token}",
            f"Creator: {child_metadata.get('creator', 'Unknown')}",
            f"Owner: {child_metadata.get('owner', 'Unknown')}",
            f"Created: {child_metadata.get('created_time', 'Unknown')}",
            f"Modified: {child_metadata.get('modified_time', 'Unknown')}",
            "",
            "Content:",
            child_content if child_content else "[No content available]"
        ]
        
        return "\n".join(context_parts)
    
    async def format_document(
        self,
        child_data: Dict[str, Any],
        predefined_keys: List[str]
    ) -> Dict[str, Any]:
        """
        Format a single wiki document into a table record.
        
        Args:
            child_data: Dictionary containing document data (title, content, metadata, token)
            predefined_keys: List of target table column names
            
        Returns:
            Dictionary containing formatted record and source metadata
            
        Raises:
            ValueError: If LLM response cannot be parsed as JSON
            Exception: If LLM call fails
        """
        child_title = child_data.get("title", "")
        child_token = child_data.get("token", "")
        child_type = child_data.get("type", "")
        
        # Build context and prompts
        context = self._build_document_context(child_data)
        system_prompt = self._build_system_prompt(predefined_keys)
        response_schema = self._build_response_schema(predefined_keys)
        
        # Prepare messages
        messages = [
            ChatMessage(role="system", content=system_prompt),
            ChatMessage(role="user", content=f"""
Please map this wiki document into the table format:

{context}

Return a JSON object with all the predefined keys. Reuse precise values from the document context where applicable.
""")
        ]
        
        # Call LLM with structured response format
        response_content = await self.llm_client.achat(
            messages,
            response_format=response_schema,
            plugins=[
                {"id": "response-healing"}
            ],
            provider={
                "require_parameters": True
            }
        )
        
        # Extract and parse response
        response_text = response_content.message.content if hasattr(response_content, 'message') else str(response_content)
        
        try:
            parsed_record = json.loads(response_text)
        except json.JSONDecodeError as e:
            raise ValueError(
                f"Failed to parse LLM response as JSON for child '{child_title}': {str(e)}\n"
                f"Raw response: {response_text}"
            )
        
        # Add source metadata
        parsed_record["_source_metadata"] = {
            "wiki_title": child_title,
            "wiki_type": child_type,
            "wiki_token": child_token,
            "extracted_from": "wiki_child_node"
        }
        
        return parsed_record
    
    async def format_documents(
        self,
        children_data: List[Dict[str, Any]],
        predefined_keys: List[str]
    ) -> Dict[str, Any]:
        """
        Format multiple wiki documents into table records.
        
        Args:
            children_data: List of child document dictionaries
            predefined_keys: List of target table column names
            
        Returns:
            Dictionary containing formatted records and metadata
        """
        if not children_data:
            return {
                "records": [],
                "total_count": 0,
                "errors": []
            }
        
        formatted_records = []
        errors = []
        
        for child in children_data:
            try:
                record = await self.format_document(child, predefined_keys)
                formatted_records.append(record)
            except ValueError as e:
                errors.append({
                    "child_title": child.get("title", "Unknown"),
                    "error": str(e)
                })
            except Exception as e:
                errors.append({
                    "child_title": child.get("title", "Unknown"),
                    "error": f"Failed to format document: {str(e)}"
                })
        
        return {
            "records": formatted_records,
            "total_count": len(formatted_records),
            "errors": errors,
            "predefined_keys": predefined_keys,
            "llm_model": self.llm_model
        }


__all__ = ["WikiDocumentFormatter"]
