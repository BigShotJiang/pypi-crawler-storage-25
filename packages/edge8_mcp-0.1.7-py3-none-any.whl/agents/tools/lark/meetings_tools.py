# Lark Tools
import os
from agents.tools.shared import ToolHandler, call_llm
from agents.prompts import CENTRAL_PROMPT_MAPPING, DEFAULT_TEMPLATE
from typing import Dict, Any
from connectors.lark_interactions.meetings import MeetingRecord, Minutes
from connectors.lark_interactions.file import LarkFiles, LarkFilesPermission
from connectors.lark_interactions.doc import LarkDocs, LarkDocsContent
from connectors.lark_interactions.contacts import Users
from utils.encryption import AESCipher
from agents.tools.lark.doc_tools import LarkSearchDocHandler
from .user_tools import LarkGetCurrentUserHandler
from .event_tools import LarkListEventsHandler
from datetime import datetime
import asyncio
import httpx
from dotenv import load_dotenv
from utils.time_op import frequency_to_cron

load_dotenv()

SUPABASE_SERVICE_ROLE_KEY = os.getenv("PUBLIC_SUPABASE_SERVICE_KEY")
SERVER_URL = os.getenv("SERVER_URL")
LOCALHOST_URL = os.getenv("LOCALHOST_URL")
PY_ENV = os.getenv("PY_ENV")


def _supabase():
    from connectors.supabase_client.db import get_custom_client
    return get_custom_client(key=SUPABASE_SERVICE_ROLE_KEY)


## Lark INSERT Meeting names to Supabase report_setting table
class LarkInsertMeetingNamesHandler(ToolHandler):
  async def execute(self, **kwargs) -> Dict[str, Any]:
    access_token = kwargs.get("access_token")
    meeting_settings: list = kwargs.get("meeting_settings", [])
    table_name = kwargs.get("table_name", "report_settings")
    try:
      lark_get_current_user_tool = LarkGetCurrentUserHandler()
      user = await lark_get_current_user_tool.execute(access_token=access_token)
      user_id = user.get("metadata", {}).get("user", {}).get("open_id", "")
      
      # Get existing settings
      query = _supabase().table("report_settings").select("id", "name", "frequency").eq("user_id", user_id).execute().data
      existing_settings = query
      for i, setting in enumerate(meeting_settings):
        setting['cron_expression'] = frequency_to_cron(setting.get("frequency"))
        meeting_settings[i] = setting
        for idx, existing_setting in enumerate(existing_settings):
          if setting.get("name") == existing_setting.get("name") and setting.get("frequency") == existing_setting.get("frequency"):
            meeting_settings.pop(idx)
            break
            
      meeting_report_settings = supabase\
          .table("report_settings")\
          .insert([
            {
              "user_id": user_id,
              **setting,
            } for setting in meeting_settings
          ]).execute().data
        
      return {
        "content": "Successfully inserted meeting names to Supabase", 
        "metadata": {"meeting_report_settings": meeting_report_settings}
      }
        
    except Exception as e:
      return {"error": f"Failed to insert meeting names to Supabase: {str(e)}"}

# GET Summary of Lark Meetings by type or matching text in title from ThoughtFlow
class GetMeetingSummaryHandler(ToolHandler):
    async def execute(self, **kwargs) -> Dict[str, Any]:
      type_query = kwargs.get("type_query", "")
      title_query = kwargs.get("title_query", "")
      date_range = kwargs.get("date_range", "")
      print("Type Query: ", type_query)
      print("Title Query: ", title_query)
      print("Date Range: ", date_range)
        
      global supabase
      integrated_meeting_data = supabase\
        .table("meetings")\
        .select("summary,meeting_types(name)")\
        .eq("platform", "lark")\
        .or_("title.ilike.%{title_query}%,meeting_types.name.ilike.%{type_query}%")\
        .order("created_at", desc=True)\
        .execute().data
        
      if len(integrated_meeting_data) == 0:
        return {"error": "No matching meeting found"}
        
      # Parse and validate date range
      try:
        date_parts = date_range.split(" to ")
        if len(date_parts) != 2:
          raise ValueError(f"Invalid date range format: expected 'START to END', got '{date_range}'")
        
        start_date = datetime.fromisoformat(date_parts[0].strip())
        end_date = datetime.fromisoformat(date_parts[1].strip())
      except (ValueError, AttributeError) as e:
        raise ValueError(f"Failed to parse date range '{date_range}': {str(e)}")
        
      print("Start Date: ", start_date)
      print("End Date: ", end_date)
        
      # Filter meetings by date range with error handling
      meetings_by_date = []
      for meeting in integrated_meeting_data:
        try:
          created_at_str = meeting.get("created_at")
          if not created_at_str:
            continue
          created_at = datetime.fromisoformat(created_at_str)
          if start_date <= created_at <= end_date:
            meetings_by_date.append(meeting)
        except (ValueError, TypeError) as e:
          print(f"Warning: Skipping meeting with invalid created_at '{created_at_str}': {str(e)}")
          continue
        
      print("Meeting Data by Date: ", meetings_by_date)
        
      meeting_summary_list = []
      for meeting in meetings_by_date:
        summary = meeting.get("summary", "")
        if meeting.get("meeting_types", {}).get("name", "") == "One-On-One":
            summary = decrypt_meeting_summary(meeting.get("summary", ""))
        meeting_summary_list.append(summary)
      
      if(len(meeting_summary_list) == 0):
        return {"error": "No matching meeting found"}
        
      print("Meeting Summary List: ", meeting_summary_list)
      return {
        "content": "Successfully retrieved meeting summary",
        "metadata": {
            "meeting_summary_list": meeting_summary_list,
        }
      }
        
class LarkEventToMeetingNotes(ToolHandler):
    async def execute(self, **kwargs) -> Dict[str, Any]:
        query = kwargs.get("query", "")
        anchor_time = int(kwargs.get("anchor_time", 1761338478))
        access_token = kwargs.get("access_token", "")
        
        if access_token == "":
          return {"error": "No access token provided"}
        
        try:
            # Init Supabase, Lark, ThoughtFlow
            http_client = httpx.AsyncClient()
            lark_list_events_tool = LarkListEventsHandler()
            
            events = await lark_list_events_tool.execute(
              access_token=access_token, 
              query=query, 
              anchor_time=anchor_time
            )
            events = events.get("metadata", {}).get("events", [])
            if len(events) == 0:
              return {"error": "No events found"}
            
            base_url = LOCALHOST_URL if PY_ENV == 'development' else SERVER_URL
            url = f"{base_url}/api/v1/lark/meetings/summary/from-number"
            print("URL: ", url)
            auth_token = os.getenv("SERVER_AUTH_API_KEY")
            headers = {
              "Authorization": "Bearer " + auth_token,
              "lark-access-token": access_token,
              "Content-Type": "application/json"
            }
            tasks = []
            for event in events:
              print("Event: ", event.get("summary", ""))
              meeting_url = event.get("vchat", {}).get("meeting_url", "")
              meeting_number = meeting_url.split("/")[-1]
              task = asyncio.create_task(
                http_client.get(url, headers=headers, params={"meeting_number": meeting_number})
              )
              tasks.append(task)
              
            # Fire all requests without waiting for responses (but ensure they're sent)
            # await asyncio.gather(*tasks, return_exceptions=True)
            await asyncio.sleep(3)   

            return {
                "content": "Successfully generated summary from minutes",
								"metadata": { "events": events }
            }
        except Exception as e:
            return {"error": f"Failed to generate summary from minutes: {str(e)}"}
        
class LarkMeetingNumberToMeetingNotes(ToolHandler):
    async def execute(self, **kwargs) -> Dict[str, Any]:
        meeting_number: str = kwargs.get("meeting_number", "")
        access_token = kwargs.get("access_token")
        
        if meeting_number == "":
          return {"error": "No meeting number provided"}
        
        try:
            # Init Supabase, Lark, ThoughtFlow
            http_client = httpx.AsyncClient()
            lark_meeting_minutes_tool = LarkGetMinutesFromMeetingNumber()
            
            # Extract minutes from meeting number and store to Supabase
            response = await lark_meeting_minutes_tool.execute(meeting_number=meeting_number, access_token=access_token)
            if(response.get("error")):
              return {"error": response.get("error")}
            meeting_minutes = response.get('metadata', {}).get('meetings', [])
            if len(meeting_minutes) == 0:
              return {"error": "No minutes found for meeting number: " + meeting_number}
            
            # Loop over extracted meetings from meeting_number and generate summaries
            base_url = LOCALHOST_URL if PY_ENV == 'development' else SERVER_URL
            url = f"{base_url}/api/v1/lark/meetings/summary/from-id"
            auth_token = os.getenv("SERVER_AUTH_API_KEY")
            headers = {
              "Authorization": "Bearer " + auth_token,
              "lark-access-token": access_token,
              "Content-Type": "application/json"
            }
            print(url)
            tasks = []
            for meeting in meeting_minutes:
              # Fire off request without waiting for response
              _task = asyncio.create_task(http_client.get(url, params={"meeting_id": meeting.get("platform_id", ""), }, headers=headers))
              tasks.append(_task)
            await asyncio.sleep(3) 
            return {
                "content": "Successfully generated summary from minutes",
                "metadata": {
                    "meetings": meeting_minutes
                }
            }

        except Exception as e:
            return {"error": f"Failed to get meeting notes from minutes: {str(e)}"}

class LarkQueryEventToMeetingNotes(ToolHandler):
    async def execute(self, **kwargs) -> Dict[str, Any]:
        meeting_query = kwargs.get("meeting_query")
        anchor_time = int(kwargs.get("anchor_time", 1761338478))
        access_token = kwargs.get("access_token")
        
        try:
            # Init
            http_client = httpx.AsyncClient()
            lark_events_tool = LarkListEventsHandler()
            
            # List exiting events from a user
            events_response = await lark_events_tool.execute(
              access_token=access_token, 
              anchor_time=anchor_time, 
              query=meeting_query
            )
            if events_response.get("error"):
              print("Error listing events: ", events_response.get("error"))
              return {"error": events_response.get("error")}
            events = events_response.get("metadata", {}).get("events", [])
            
            # Filter to find the desired event based on query
            print("filtered_event: ",len(events))
            print("First event: ", events[0].get("summary", ""))
            print("Second event: ", events[1].get("summary", ""))
            if len(events) == 0:
              return {"error": "No matching event found"}
            
            # Extract meeting number from meeting_url
            meeting_url = events[0].get("vchat", {}).get("meeting_url", "")
            meeting_number = meeting_url.split("/")[-1]
            
            base_url = LOCALHOST_URL if PY_ENV == 'development' else SERVER_URL
            url = f"{base_url}/api/v1/lark/meetings/summary/from-number"
            print("URL: ", url)
            auth_token = os.getenv("SERVER_AUTH_API_KEY")
            headers = {
              "Authorization": "Bearer " + auth_token,
              "lark-access-token": access_token,
              "Content-Type": "application/json"
            }
            _task = asyncio.create_task(
              http_client.get(url, headers=headers, params={"meeting_number": meeting_number})
            )
            await asyncio.sleep(3)   
            
            return {
                "content": "Successfully generated summary from minutes",
                "metadata": {
                    "event": events[0]
                }
            }

        except Exception as e:
            return {"error": f"Failed to get meeting notes from minutes: {str(e)}"}

class LarkGetMinutesFromMeetingNumber(ToolHandler):
    async def execute(self, **kwargs) -> Dict[str, Any]:
        meeting_number = kwargs.get("meeting_number", "")
        access_token = kwargs.get("access_token", "")
        start_time = kwargs.get("start_time", datetime.fromisoformat("2025-10-10 00:00:00").timestamp())
        end_time = kwargs.get("end_time", datetime.now().timestamp())
        
        try:
            global supabase
            lark_get_current_user_tool = LarkGetCurrentUserHandler()
            user = await lark_get_current_user_tool.execute(access_token=access_token)
            user_id = user.get("metadata", {}).get("user", {}).get("open_id", "")
            print("user_id: ", user_id)
            meeting_recording = MeetingRecord(is_auth=True, access_token=access_token)
            meetings: list[dict] = meeting_recording.get_by_meeting_number(meeting_number, int(start_time), int(end_time))
            # print("meetings: ", meetings)
            if len(meetings) == 0:
                return {"error": "No matching meeting found"}
            
            # Bulk extract and upload minutes
            stored_meetings = await self.bulk_extract_and_upload_minutes(
              meetings, 
              user_id, 
              meeting_recording,
              access_token,
              "Edge8 Automation",
              "meetings"
            )
            print("stored_meetings: ", stored_meetings)
            
            return {
                "content": "Successfully retrieved minutes",
                "metadata": {
                    "meetings": stored_meetings
                }
            }
        except Exception as e:
            return {"error": f"Failed to retrieve minutes: {str(e)}"}
          
    async def bulk_extract_and_upload_minutes(
      self, 
      meetings: list[dict], 
      user_id: str, 
      meeting_recording: MeetingRecord,
    ) -> list:
        stored_meetings = []
        global supabase
        for meeting in meetings:
            meeting_id = meeting.get("id", "")
            meeting_title = meeting.get("topic", meeting.get("summary", "")).replace("<>","to")
            print("Meeting Title: ", meeting_title)
            print("Meeting ID: ", meeting_id)
            try:
              meeting_metadata = meeting_recording.get_details(meeting_id)
            except Exception as e:
              print("Meeting details: ", e)
              continue
            recording = meeting_recording.get_recording(meeting_id)
            print("Recording: ", recording)
            url = recording.get("url")
            duration = recording.get("duration")
            print("URL: ", url, "Duration: ", duration)
            start_time = int(meeting_metadata.get("start_time", 0))
            end_time = int(meeting_metadata.get("end_time", 0))
            minutes_insertion = {
              "user_id": user_id,
              "title": meeting_title,
              "platform_id": meeting_id,
              "platform": "lark",
              "minutes_url": url,
              "duration": int(duration),
              "start_time": start_time,
              "end_time": end_time,
              "summary": "",
            }
            print("minutes_insertion: ", minutes_insertion)
            try:
              inserted = _supabase().table("meetings").insert(minutes_insertion).execute()
              stored_meetings.append(inserted.data[0] if inserted.data else None)
            except Exception as e:
              print(f"Failed to insert meeting to Supabase: {str(e)}")
              continue
        return stored_meetings

class LarkMeetingSummaryGenerator(ToolHandler):
    def _encrypt_summary(self, summary: str, encryption_key: str) -> str:
        """
        Encrypt summary using AES cipher with the provided key.
        """
        from Crypto.Cipher import AES
        from Crypto.Random import get_random_bytes
        import base64
        import hashlib
        
        # Hash the key to get a consistent 256-bit key
        key = hashlib.sha256(AESCipher.str_to_bytes(encryption_key)).digest()
        
        # Generate random IV
        iv = get_random_bytes(AES.block_size)
        
        # Create cipher
        cipher = AES.new(key, AES.MODE_CBC, iv)
        
        # Pad the summary
        summary_bytes = summary.encode('utf-8')
        padding_length = AES.block_size - (len(summary_bytes) % AES.block_size)
        padded_summary = summary_bytes + bytes([padding_length] * padding_length)
        
        # Encrypt
        encrypted = cipher.encrypt(padded_summary)
        
        # Combine IV and encrypted data, then base64 encode
        encrypted_data = iv + encrypted
        return base64.b64encode(encrypted_data).decode('utf-8')
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        meeting_id = kwargs.get("meeting_id", "")
        access_token = kwargs.get("access_token", "")
        print("Meeting ID in LarkGenerateSummaryFromMeeting: ", meeting_id)
        if (meeting_id == ""):
            return {"error": "No meeting ID found"}
        global supabase
        try:
            # Get current user
            current_user_tool = LarkGetCurrentUserHandler()
            lark_user = Users()
            user = await current_user_tool.execute(access_token=access_token)
            name = user.get("metadata", {}).get("user", {}).get("name", "")
            user_id = user.get("metadata", {}).get("user", {}).get("open_id", "")
            
            # Get meeting details
            meeting_recording = MeetingRecord(is_auth=True, access_token=access_token)
            meeting_metadata = meeting_recording.get_details(meeting_id)
            meeting_title = meeting_metadata.get("topic", "")
            participants = meeting_metadata.get("participants", [])

            # Check if meeting is 1-1
            is_one_on_one = len(participants) == 2 and "1-1" in meeting_title

            if is_one_on_one:
                # Get non-host participant
                non_host = next((x for x in participants if x.get("id") != user_id or (not x.get("is_host") and not x.get("is_cohost"))), None)
                non_host_id = non_host.get("id", "")
                non_host_info = lark_user.get_single_user(non_host_id)
                non_host_name = non_host_info.get("name", "")

                # Check if meeting title contains non-host name and "Catch-up"
                if non_host_name in meeting_title and "Catch-up" in meeting_title:
                    # Search for existing doc
                    doc_handler = LarkSearchDocHandler()
                    found_doc = await doc_handler.execute(
                        access_token=access_token, 
                        search_key=meeting_title,
                        owner_ids=[user_id],
                        docs_types=['doc']
                    )
                    if (found_doc.get("error")):
                        return {"error": found_doc.get("error")}
                    content = found_doc.get("metadata", {}).get("content", "")

            # Query Supabase for meeting record
            meeting_records = _supabase().table("meetings").select("*,meeting_types(summary_template)").eq("platform_id", meeting_id).eq("user_id", user_id).execute().data
            print("Meeting in LarkGenerateSummaryFromMeeting: ", meeting_records)
            if len(meeting_records) == 0:
              return {"error": "No meeting found"}
            
            # Get summary from minutes
            summary_from_minutes_generator = LarkGenerateSummaryFromMinutes()
            found_meeting = meeting_records[0]
            minutes_url = found_meeting.get("minutes_url", "")
            print("Minutes URL: ", minutes_url)
            summary = await summary_from_minutes_generator.execute(
              url=minutes_url, 
              access_token=access_token,
              contexts=content,
              template=found_meeting.get("meeting_types", {}).get("summary_template", "")
            )
            summary = summary.get("metadata", {}).get("summary", "")
            
            if isinstance(summary, dict) and summary.get("error"):
                return {"error": summary.get("error")}
            
            # Encrypt summary for 1-1 meetings
            if is_one_on_one:
              encryption_key = os.getenv("THOUGHTFLOW_PRIVATE_KEY")
              if not encryption_key:
                return {"error": "Encryption key not found for 1-1 meeting"}
              encrypted_summary = self._encrypt_summary(summary, encryption_key)
            else:
              encrypted_summary = summary
            
            # Update meeting record in Supabase
            updated_meeting = _supabase().table("meetings").update({
              "summary": encrypted_summary
            }).eq("id", found_meeting.get("id")).execute().data

            return {
                "content": "Successfully generated summary from minutes",
                "metadata": {
                  "meetings": updated_meeting
                }
            }
        except Exception as e:
            print("Error in LarkGenerateSummaryFromMeeting: ", e)
            return {"error": f"Failed to generate summary from minutes: {str(e)}"}

class LarkGenerateSummaryFromMinutes(ToolHandler):
    async def execute(self, **kwargs) -> Dict[str, Any]:
        access_token = kwargs.get("access_token", "")
        url = kwargs.get("url", "")
        contexts = kwargs.get("contexts", "")
        template = kwargs.get("template", DEFAULT_TEMPLATE)
        bot_type = "meeting"
        
        if url == '':
          return {"error": "URL is required"}
        try:
            # Get transcript
            minutes_token = url.split("/")[-1]
            minutes_handler = Minutes(
                is_auth=True, 
                access_token=access_token, 
                bot_type=bot_type, 
                minute_token=minutes_token
            )
            
            transcript_bytes = minutes_handler.get_transcript()
            transcript_content = transcript_bytes.decode("utf-8")
            
            print("Transcript: ", transcript_content[0:50], "...")
            
            summary = await call_llm(
              messages=[
                {
                  "role": "system",
                  "content": CENTRAL_PROMPT_MAPPING.get("meeting_summary")
                },
                {
                  "role": "user",
                  "content": f"""Generate meeting summary with the following contexts:
                  - [Meeting Transcript]: {transcript_content}
                  - [Template]: {template}
                  {f"- [Contexts]: {contexts}" if contexts else ""}
                  """.strip()
                }
              ],
              model="meta-llama/llama-3.1-8b-instruct"
            )
        
            return {
                "content": "Successfully generated summary from minutes",
                "metadata": {"summary": summary}
            }
        except Exception as e:
            return {"error": f"Failed to generate summary from minutes: {str(e)}"}

class LarkGetMeetingMinutesDirect(ToolHandler):
    """DB-free version: fetch meeting recordings from Lark API and return minutes_url directly.

    Does not require Supabase. Returns meeting metadata and the transcript URL so
    the caller can pass it to LarkGenerateSummaryFromMinutes without any DB reads/writes.
    """
    async def execute(self, **kwargs) -> Dict[str, Any]:
        meeting_number = kwargs.get("meeting_number", "")
        access_token = kwargs.get("access_token", "")
        start_time = kwargs.get("start_time", datetime.fromisoformat("2025-10-10 00:00:00").timestamp())
        end_time = kwargs.get("end_time", datetime.now().timestamp())

        if not meeting_number:
            return {"error": "meeting_number is required"}

        try:
            meeting_recording = MeetingRecord(is_auth=True, access_token=access_token)
            meetings: list[dict] = meeting_recording.get_by_meeting_number(
                meeting_number, int(start_time), int(end_time)
            )
            if not meetings:
                return {"error": f"No meetings found for meeting number: {meeting_number}"}

            results = []
            for meeting in meetings:
                meeting_id = meeting.get("id", "")
                try:
                    metadata = meeting_recording.get_details(meeting_id)
                    recording = meeting_recording.get_recording(meeting_id)
                    results.append({
                        "platform_id": meeting_id,
                        "title": metadata.get("topic", meeting.get("summary", "")),
                        "minutes_url": recording.get("url", ""),
                        "duration": recording.get("duration"),
                        "start_time": metadata.get("start_time"),
                        "end_time": metadata.get("end_time"),
                        "participants": metadata.get("participants", []),
                    })
                except Exception as e:
                    print(f"Skipping meeting {meeting_id}: {e}")
                    continue

            if not results:
                return {"error": "Could not extract meeting details from Lark API"}

            return {
                "content": f"Found {len(results)} meeting(s) for number {meeting_number}",
                "metadata": {"meetings": results},
            }
        except Exception as e:
            return {"error": f"Failed to fetch meeting minutes: {str(e)}"}


class LarkMeetingToDocumentHandler(ToolHandler):
    async def execute(self, **kwargs) -> Dict[str, Any]:
        access_token = kwargs.get("access_token")
        content = kwargs.get("content", "")
        permission_list = kwargs.get("permission_list", [])
        
        try:
            lark_docs_handler = LarkDocs(is_auth=True, access_token=access_token)
            auth_lark_docs_content = LarkDocsContent(is_auth=True, access_token=access_token)
            lark_files_handler = LarkFiles(is_auth=True, access_token=access_token)
            lark_files_permission_handler = LarkFilesPermission(is_auth=True, access_token=access_token)
            
            # Create document in Lark
            document = lark_docs_handler.create(title="Meeting Notes")
            
            # Create Lark Blocks from Markdown
            _document_content = auth_lark_docs_content.text_to_blocks(
              document.get("document_id", ""), 
              document.get("document_id", ""),
              "open_id", 
              content
            )
            
            # Retrieve document URL
            document_url = lark_files_handler.get_files_metadata(
                [{"doc_token": document.get("document_id", ""), "doc_type": "docx"}]
            ).get('metas', [{}])[0].get('url', '')
            
            if len(permission_list) > 0:
                for permission in permission_list:
                    lark_files_permission_handler.add(
                        document.get("document_id", ""), 
                        permission.get("user_id", ""), 
                        permission.get("permission_type", "view"), 
                        permission.get("user_id_type", "openid"), 
                        "doc",
                        permission.get("need_notification", True)
                    )
            
            return { "content": "Document created successfully", "metadata": { "url": document_url } }
        except Exception as e:
            return {"error": f"Failed to create document: {str(e)}"}

def decrypt_meeting_summary(encrypted_summary: str) -> str:
    """
    Decrypt a meeting summary that was encrypted with THOUGHTFLOW_PRIVATE_KEY.
    Only used for 1-1 meetings.
    """
    encryption_key = os.getenv("THOUGHTFLOW_PRIVATE_KEY")
    if not encryption_key:
        raise ValueError("Encryption key not found for decryption")
    
    from Crypto.Cipher import AES
    import base64
    import hashlib
    
    # Hash the key to get a consistent 256-bit key
    key = hashlib.sha256(AESCipher.str_to_bytes(encryption_key)).digest()
    
    # Decode from base64
    encrypted_data = base64.b64decode(encrypted_summary)
    
    # Extract IV and encrypted content
    iv = encrypted_data[:AES.block_size]
    encrypted_content = encrypted_data[AES.block_size:]
    
    # Decrypt
    cipher = AES.new(key, AES.MODE_CBC, iv)
    padded_summary = cipher.decrypt(encrypted_content)
    
    # Remove padding
    padding_length = padded_summary[-1]
    summary = padded_summary[:-padding_length].decode('utf-8')
    
    return summary

__all__ = [
  "LarkInsertMeetingNamesHandler",
  "LarkMeetingToDocumentHandler",
  "LarkGenerateSummaryFromMinutes",
  "LarkMeetingSummaryGenerator",
  "GetMeetingSummaryHandler",
  "LarkGetMeetingMinutesDirect",
  "LarkQueryEventToMeetingNotes",
  "LarkEventToMeetingNotes",
  "LarkMeetingNumberToMeetingNotes",
  "decrypt_meeting_summary"
]