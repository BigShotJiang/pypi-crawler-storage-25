import os
import sys
import asyncio
import json
import logging
# Add project root to path: lark -> tools -> agents -> src -> project_root
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.insert(0, project_root)

from agents.tools.shared import ToolHandler
from connectors.lark_interactions.conversation import *
from agents.tools.lark.auth_tools import LarkGetAuthSessionHandler
from connectors.lark_interactions.contacts import Users, Organizations
from utils.file_handling import parse_data_from_json_file

def button_card_mapping(title: str, body: str, button_text: str, kwargs: dict, card_path: str):
  card = parse_data_from_json_file(card_path)
  card["header"]["title"]["content"] = title
  card["elements"][0]["text"]["content"] = body
  if button_text != '':
    card["elements"][1]["actions"][0]["text"]["content"] = button_text
    value_check = card["elements"][1]["actions"][0].get("value", None)
    url_check = card["elements"][1]["actions"][0].get("multi_url", None)
    if value_check is not None:
      card["elements"][1]["actions"][0]["value"] = kwargs
    elif url_check is not None:
      card["elements"][1]["actions"][0]["multi_url"] = kwargs
  else:
    card["elements"].pop()
  
  return json.dumps(card)

class LarkSendMessageHandler(ToolHandler):
    async def execute(self, **kwargs):
        """Send a message to a Lark user or group.

        Args:
            receive_id (str): The ID of the user or group to send the message to.
            content (str): The content of the message.
            title (str, optional): The title of the message. Defaults to "".
            button_label (str, optional): The label of the button in the message. Defaults to "".
            kwargs (dict, optional): Additional keyword arguments for the message. Defaults to {}.

        Returns:
            dict: A dictionary containing the response from the Lark API.
        """
        
        
        # Required parameters
        receive_id = kwargs.pop("receive_id")
        receive_id_type = kwargs.pop("receive_id_type", "open_id")
        content = kwargs.pop("content", "")
        is_card_message = kwargs.pop("is_card_message", False)
        
        # Optional parameters, only applicable for card messages
        title = kwargs.pop("title", "")
        button_label = kwargs.pop("button_label", "")
        
        if(receive_id is None):
            return { "error": "receive_id is required" }
              
        card_path = "/config/lark/link_button_card.json" \
          if kwargs.get('url', '') != '' \
          else "/config/lark/button_card.json"
        
        try:
            # Init Supabase, Lark, ThoughtFlow
            lark_conversations_handler = LarkChatMessages()
            
            if(is_card_message):
              body = button_card_mapping(
                title, 
                content, 
                button_label, 
                kwargs or {}, 
                card_path
              )
            else:
              body = json.dumps({"text": content})
            
            response = lark_conversations_handler.send(
              receive_id=receive_id,
              receive_id_type=receive_id_type,
              msg_type="text" if not is_card_message else "interactive", 
              content=body
            )
            
            return {"content": "Successfully sent message", "metadata": {"message": response}}
        except Exception as e:
            print("Exception: ", e)
            return {"error": f"Failed to send message: {str(e)}"}

class LarkListChatsHandler(ToolHandler):
    async def execute(self, **kwargs):
        """List all Lark chat groups the authenticated user is a member of.

        Args:
          access_token (str): The user OAuth access token.
          page_size (int, optional): Number of chats per page (max 100). Defaults to 20.
          page_token (str, optional): Cursor from a previous response to fetch the next page.

        Returns:
          dict: A dictionary containing the list of chat groups and pagination info.
        """
        access_token = kwargs.pop("access_token")
        page_size = kwargs.pop("page_size", 20)
        page_token = kwargs.pop("page_token", None)
        try:
            result = await asyncio.to_thread(
                lambda: LarkChatGroups(access_token=access_token).get(
                    page_size=page_size, page_token=page_token
                )
            )
            active = [g for g in result["items"] if g.get("chat_status") != "dissolved"]
            if not active:
                return {"content": "No active chat groups found.", "metadata": {"chats": [], "has_more": False, "page_token": None}}
            return {
                "content": f"Found {len(active)} chat group(s).",
                "metadata": {
                    "chats": active,
                    "has_more": result["has_more"],
                    "page_token": result["page_token"],
                },
            }
        except Exception as e:
            logger.exception("LarkListChatsHandler failed")
            return {"error": f"Failed to list chats: {str(e)}"}


class LarkChatHistoryHandler(ToolHandler):
    async def execute(self, **kwargs):
        """Get the chat history for a Lark user or group.

        Args:
          access_token (str): The access token for the Lark API.
          query (str, optional): The query to search for in the chat history. Defaults to "".

        Returns:
          dict: A dictionary containing the response from the Lark API.
        """
        
        access_token = kwargs.pop("access_token")
        query = kwargs.pop("query", "")
        
        try:
            lark_conversations_handler = LarkChatMessages(access_token=access_token)
            lark_chat_groups_handler = lark_conversations_handler.chat_group_handler
            # M-1: wrap blocking requests call
            chat_groups = await asyncio.to_thread(lark_chat_groups_handler.search, query=query)
            chat_groups = list(filter(lambda x: x["chat_status"] != 'dissolved', chat_groups))
            # M-2: guard against empty results
            if not chat_groups:
                return {"error": f"No active chat groups found matching '{query}'."}
            group_id = chat_groups[0]["chat_id"]
            lark_conversations_handler.__init__(group_id=group_id)
            chat_history = await asyncio.to_thread(lambda: lark_conversations_handler.msg_by_all)

            return {"content": "Successfully retrieved chat history", "metadata": {"chat_history": chat_history}}
        except Exception as e:
            logger.exception("LarkChatHistoryHandler failed")
            return {"error": f"Failed to retrieve chat history: {str(e)}"}


class LarkSearchUserAndSendMessageHandler(ToolHandler):
    async def execute(self, **kwargs):
        """Search for a user by name and send them a message.

        Args:
            user_name (str): The name of the user to search for.
            message_content (str): The content of the message to send.
            access_token (str, optional): The access token for the Lark API. If not provided, will use default auth.
            title (str, optional): The title of the message for card messages. Defaults to "".
            button_label (str, optional): The label of the button in the message. Defaults to "".
            is_card_message (bool, optional): Whether to send as a card message. Defaults to False.
            **additional_kwargs: Additional keyword arguments to pass to the message.

        Returns:
            dict: A dictionary containing the response with user info and message status.
        """
        
        # Required parameters
        access_token = kwargs.pop("access_token", "")
        user_name = kwargs.pop("user_name")
        message_content = kwargs.pop("message_content")
        
        # Optional parameters
        title = kwargs.pop("title", "")
        button_label = kwargs.pop("button_label", None)
        is_card_message = kwargs.pop("is_card_message", False)
        
        if not user_name:
            return {"error": "user_name is required"}
        
        if not message_content:
            return {"error": "message_content is required"}
        
        try:
            # Search for the user by name
            users_handler = Organizations()
            search_results = users_handler.search_employee(query=user_name, page_size=2)
            
            if not search_results:
                return {
                    "error": f"No users found matching name: {user_name}",
                    "metadata": {"search_query": user_name}
                }
            
            # Get the first matching user
            matched_user = search_results[0]
            user_info = matched_user.get("base_info", {})
            user_id = user_info.get("employee_id")
            user_display_name = user_info.get("name", {}).get("name", {}).get("default_value", user_name)
            
            if not user_id:
                return {
                    "error": f"User found but no open_id available: {user_display_name}",
                    "metadata": {"user": matched_user}
                }
            
            # Send message to the user
            send_message_handler = LarkSendMessageHandler()
            message_kwargs = {
                "receive_id": user_id,
                "receive_id_type": "open_id",
                "content": message_content,
                "is_card_message": is_card_message,
                "title": title,
                "button_label": button_label,
                **kwargs  # Pass any additional kwargs
            }
            
            message_response = await send_message_handler.execute(**message_kwargs)
            
            return {
                "content": f"Successfully sent message to {user_display_name}",
                "metadata": {
                    "user": {
                        "name": user_display_name,
                        "open_id": user_id,
                        "full_user_info": matched_user
                    },
                    "message_response": message_response
                }
            }
            
        except Exception as e:
            print(f"Exception: {e}")
            return {"error": f"Failed to search user and send message: {str(e)}"}


async def main():
  LARK_USER_ID = "ou_ff1c55b47c6ef9a40dc1ce3dc9cd5374"
  lark_user_handler = LarkGetAuthSessionHandler()   
  response = await lark_user_handler.execute(lark_user_id=LARK_USER_ID)
  access_token = response.get("metadata", {}).get("access_token")
  lark_chat_history_handler = LarkChatHistoryHandler()
  chat_history = await lark_chat_history_handler.execute(access_token=access_token, query="Dev - Travel Buddy (hơi hơi vui vẻ)")
  print("Chat history: ", chat_history)
  
if __name__ == "__main__":
  asyncio.run(main())


logger = logging.getLogger(__name__)


class LarkUpdateCardHandler(ToolHandler):
    async def execute(self, **kwargs) -> dict:
        message_id = kwargs.pop("message_id")
        content = kwargs.pop("content")
        if not message_id:
            return {"error": "message_id is required"}
        try:
            lark = LarkChatMessages()
            response = await asyncio.to_thread(lark.patch, message_id, content)
            return {"content": "Successfully updated card message.", "metadata": {"message": response}}
        except Exception as e:
            logger.exception("LarkUpdateCardHandler failed")
            return {"error": f"Failed to update card: {str(e)}"}


class LarkReplyToMessageHandler(ToolHandler):
    async def execute(self, **kwargs) -> dict:
        """Reply to an existing Lark message in-thread."""
        message_id = kwargs.get("message_id", "")
        content = kwargs.get("content", "")
        reply_in_thread = kwargs.get("reply_in_thread", False)
        try:
            lark = LarkChatMessages()
            body = json.dumps({"text": content})
            response = await asyncio.to_thread(lark.reply, message_id, body, "text", reply_in_thread)
            return {"content": "Successfully replied to message.", "metadata": {"message": response}}
        except Exception as e:
            logger.exception("LarkReplyToMessageHandler failed")
            return {"error": f"Failed to reply to message: {str(e)}"}


class LarkReactToMessageHandler(ToolHandler):
    async def execute(self, **kwargs) -> dict:
        """Add an emoji reaction to a Lark message."""
        message_id = kwargs.get("message_id", "")
        emoji_type = kwargs.get("emoji_type", "THUMBSUP")
        try:
            lark = LarkChatMessages()
            response = await asyncio.to_thread(lark.add_reaction, message_id, emoji_type)
            return {"content": f"Successfully reacted with '{emoji_type}'.", "metadata": {"reaction": response}}
        except Exception as e:
            logger.exception("LarkReactToMessageHandler failed")
            return {"error": f"Failed to add reaction: {str(e)}"}


__all__ = [
  "LarkSendMessageHandler",
  "LarkChatHistoryHandler",
  "LarkSearchUserAndSendMessageHandler",
  "LarkUpdateCardHandler",
  "LarkReplyToMessageHandler",
  "LarkReactToMessageHandler",
  "button_card_mapping"
]

            