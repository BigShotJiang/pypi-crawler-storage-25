import asyncio
import logging
import os
import sys
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.insert(0, project_root)

from agents.tools.shared import ToolHandler
from connectors.lark_interactions.sheets import LarkSheets
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class LarkReadSheetHandler(ToolHandler):
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """Read values from a Lark Spreadsheet range."""
        access_token = kwargs.get("access_token")
        spreadsheet_token = kwargs.get("spreadsheet_token")
        range_ = kwargs.get("range", "")
        try:
            result = await asyncio.to_thread(
                LarkSheets(access_token=access_token).read_values, spreadsheet_token, range_
            )
            return {
                "content": f"Successfully read range '{range_}' from spreadsheet.",
                "metadata": {"values": result.get("values", []), "range": result.get("range", range_)},
            }
        except Exception as e:
            logger.exception("LarkReadSheetHandler failed")
            return {"error": f"Failed to read sheet: {str(e)}"}


class LarkWriteSheetHandler(ToolHandler):
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """Write values to a Lark Spreadsheet range."""
        access_token = kwargs.get("access_token")
        spreadsheet_token = kwargs.get("spreadsheet_token")
        range_ = kwargs.get("range", "")
        values: List[List[Any]] = kwargs.get("values", [])
        try:
            result = await asyncio.to_thread(
                LarkSheets(access_token=access_token).write_values, spreadsheet_token, range_, values
            )
            return {"content": f"Successfully wrote to range '{range_}'.", "metadata": {"updated": result}}
        except Exception as e:
            logger.exception("LarkWriteSheetHandler failed")
            return {"error": f"Failed to write sheet: {str(e)}"}


class LarkAppendSheetHandler(ToolHandler):
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """Append rows to a Lark Spreadsheet after the last non-empty row."""
        access_token = kwargs.get("access_token")
        spreadsheet_token = kwargs.get("spreadsheet_token")
        range_ = kwargs.get("range", "")
        values: List[List[Any]] = kwargs.get("values", [])
        try:
            result = await asyncio.to_thread(
                LarkSheets(access_token=access_token).append_values, spreadsheet_token, range_, values
            )
            return {"content": f"Successfully appended rows to '{range_}'.", "metadata": {"updated": result}}
        except Exception as e:
            logger.exception("LarkAppendSheetHandler failed")
            return {"error": f"Failed to append to sheet: {str(e)}"}


__all__ = ["LarkReadSheetHandler", "LarkWriteSheetHandler", "LarkAppendSheetHandler"]
