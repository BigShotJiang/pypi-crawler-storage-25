import os
from agents.tools.shared import ToolHandler
from typing import Dict, Any, Union, Optional
from connectors.lark_interactions.base import LarkBase, LarkBaseTable, LarkTableField
from connectors.lark_interactions.file import LarkFiles
from connectors.lark_interactions.auth import LarkAuth
from connectors.lark_interactions.wiki import Wiki
from .user_tools import LarkGetCurrentUserHandler
from utils.text_processing import text_search
from utils.time_op import calculate_expiry_date
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

SERVER_URL = os.getenv("SERVER_URL")
LOCALHOST_URL = os.getenv("LOCALHOST_URL")
PY_ENV = os.getenv("PY_ENV")

def map_data_to_fields(data: dict) -> list[dict]:
      """
      Maps input data dict based on their value data type to the corresponding Lark field type.
      
      Type mapping:
      - str -> "multiline" (type 1)
      - int/float -> "number" (type 2)
      - bool -> "checkbox" (type 7)
      - list -> "multiple_option" (type 4)
      - dict (with 'name' key) -> "person" (type 11)
      - dict (with 'link' key) -> "link" (type 15)
      """
      lark_base_table = LarkBaseTable()
      mapped_fields = []
      for key, value in data.items():
        field_type = None
        
        if isinstance(value, bool):
          # Check bool before int since bool is subclass of int
          field_type = lark_base_table.type_str_int_map.get("checkbox")
        elif isinstance(value, (int, float)):
          field_type = lark_base_table.type_str_int_map.get("number")
        elif isinstance(value, str):
          field_type = lark_base_table.type_str_int_map.get("multiline")
        elif isinstance(value, list):
          field_type = lark_base_table.type_str_int_map.get("multiple_option")
        elif isinstance(value, dict):
          # Detect dict type based on keys
          if "name" in value or "id" in value:
            field_type = lark_base_table.type_str_int_map.get("person")
          elif "link" in value:
            field_type = lark_base_table.type_str_int_map.get("link")
          else:
            # Default to multiline for unknown dict structures
            field_type = lark_base_table.type_str_int_map.get("multiline")
        else:
          # Default fallback
          field_type = lark_base_table.type_str_int_map.get("multiline")
        
        mapped_fields.append({"field_name": key, "type": field_type})
      
      return mapped_fields
    
def new_table_with_fields(access_token: str, app_id: str, table_name: str, fields: list[dict]) -> Dict[str, Any]:
  try:
    # Create new table
    lark_base_table = LarkBaseTable(is_auth=True, access_token=access_token)
    new_table = lark_base_table.create_table(app_id, table_name, fields=fields)
    return {"content": "Successfully created new Lark table", "metadata": {"new_table": new_table}}
  except Exception as e:
    return {"error": f"Failed to create new Lark table: {str(e)}"}

def new_base_with_table(access_token: str, app_name: str, table_name: str, data: list[dict]) -> Dict[str, Any]:
  try:
    # Create new base
    lark_base = LarkBase(is_auth=True, access_token=access_token)
    new_base = lark_base.create_app(app_name)
    base_id = new_base.get("app_token", "")
    fields = map_data_to_fields(data)
            
    # Create new table with data
    table = new_table_with_fields(access_token, base_id, table_name, fields)
    
    print("Table created: ", table)
            
    # Delete default table
    lark_table = LarkBaseTable(is_auth=True, access_token=access_token)
    tables = lark_table.list_tables(base_id) 
    lark_table.delete_table(base_id, tables[0]["table_id"])
            
    return {"content": "Successfully created new Lark base with data", "metadata": {"new_base": new_base, "table": table}}
  except Exception as e:
    return {"error": f"Failed to create new Lark base with data: {str(e)}"}


class LarkNewBaseTool(ToolHandler):
    name = "lark_new_base"
    description = "Create a new Lark base"
    args = {
        "access_token": "Access token for Lark authentication",
        "app_name": "Name of the new Lark base",
    }
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        access_token = kwargs.get("access_token")
        app_name = kwargs.get("app_name")
        try:
            lark_base = LarkBase(is_auth=True, access_token=access_token)
            new_base = lark_base.create_app(app_name)
            return {"content": "Successfully created new Lark base", "metadata": {"new_base": new_base}}
        except Exception as e:
            return {"error": f"Failed to create new Lark base: {str(e)}"}
          
class LarkGetBaseFromQuery(ToolHandler):
    name = "lark_get_base_from_query"
    description = "Get a Lark base from a query"
    args = {
        "access_token": "Access token for Lark authentication",
        "query": "Query to get the Lark base",
        "owner_ids": "Owner IDs of the Lark base",
    }
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        access_token = kwargs.get("access_token")
        query = kwargs.get("query")
        owner_ids = kwargs.get("owner_ids")
        try:
            lark_files = LarkFiles(is_auth=True, access_token=access_token)
            files = lark_files.search(query, 'bitable', owner_ids=owner_ids)
            
            if len(files) == 0:
              return {"code": 11244, "error": "Not found"}
            else:
              name_matched = text_search(files[0].get('title'), query)
              if not name_matched:
                return {"code": 11244, "error": "Not found"}
              if files[0].get('docs_type') != 'bitable':
                return {"code": 11244, "error": "Not found"}
              
            base = files[0]
            return {"content": "Successfully got Lark base from query", "metadata": {"base": base}}
        except Exception as e:
            return {"error": f"Failed to get Lark base from query: {str(e)}"}

class LarkNewBaseWithDataTool(ToolHandler):
    name = "lark_new_base_with_data"
    description = "Create a new Lark base with data"
    args = {
        "access_token": "Access token for Lark authentication",
        "app_name": "Name of the new Lark base",
        "table_name": "Name of the new table",
        "data": "Data to insert into the base",
    }
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        access_token = kwargs.get("access_token")
        app_name = kwargs.get("app_name")
        table_name = kwargs.get("table_name", "Table")
        data = kwargs.get("data")
        try:
            # Create new base
            lark_base = LarkBase(is_auth=True, access_token=access_token)
            new_base = lark_base.create_app(app_name)
            base_id = new_base.get("app_token", "")
            
            # Create new table with data
            lark_new_table_with_data_tool = LarkNewTableWithData()
            table = await lark_new_table_with_data_tool.execute(access_token=access_token, app_id=base_id, table_name=table_name, data=data)
            
            # Delete default table
            lark_table = LarkBaseTable(is_auth=True, access_token=access_token)
            tables = lark_table.list_tables(base_id) 
            lark_table.delete_table(base_id, tables[0]["table_id"])
            
            return {"content": "Successfully created new Lark base with data", "metadata": {"new_base": new_base, "table": table}}
        except Exception as e:
            return {"error": f"Failed to create new Lark base with data: {str(e)}"}
  
class LarkInsertTableData(ToolHandler):
    name = "lark_insert_table_data"
    description = "Insert data into a Lark table"
    args = {
      "access_token": "Access token for Lark authentication",
      "app_id": "ID of the Lark app",
      "table_id": "ID of the Lark table",
      "data": "Data to insert into the table",
    }
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        access_token = kwargs.get("access_token")
        app_id = kwargs.get("app_id")
        table_id = kwargs.get("table_id")
        data = kwargs.get("data")
        if isinstance(data, dict):
          data = [{"fields": data}]
        elif isinstance(data, list):
          data = [{"fields": d} for d in data]
        print("Data: ", data)
        try:
            # Insert data
            lark_base_table = LarkBaseTable(is_auth=True, access_token=access_token)
            table_data = lark_base_table.insert(app_id, table_id, data)
            return {"content": "Successfully inserted data into Lark table", "metadata": {"table_data": table_data}}
        except Exception as e:
            return {"error": f"Failed to insert data into Lark table: {str(e)}"}


class LarkNewTableWithData(ToolHandler):
    name = "lark_new_table_with_data"
    description = "Create a new Lark table with data"
    args = {
        "access_token": "Access token for Lark authentication",
        "app_id": "ID of the Lark app",
        "table_name": "Name of the new table",
        "fields": "List of fields for the new table",
        "data": "Data to insert into the table",
    }
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        access_token = kwargs.get("access_token")
        app_id = kwargs.get("app_id")
        table_name = kwargs.get("table_name")
        data = kwargs.get("data")
        if isinstance(data, dict):
          fields = map_data_to_fields(data)
          data = [{"fields": data}]
        elif isinstance(data, list):
          fields = map_data_to_fields(data[0])
          data = [{"fields": d} for d in data]
        print("Fields: ", fields)
        try:
            lark_base_table = LarkBaseTable(is_auth=True, access_token=access_token)
            new_table = lark_base_table.create_table(app_id, table_name, fields=fields)
            print("New table: ", new_table)
            if len(data) > 0:
                table_data = lark_base_table.insert(app_id, new_table["table_id"], data)
                return {"content": "Successfully created new Lark table with data", "metadata": {"new_table": new_table, "table_data": table_data}}
            return {"content": "Successfully created new Lark table with data", "metadata": {"new_table": new_table}}
        except Exception as e:
            return {"error": f"Failed to create new Lark table with data: {str(e)}"}
          
          
class LarkGetTable(ToolHandler):
    name = "lark_get_base_with_table"
    description = "Get a Lark base with its tables"
    args = {
        "access_token": "Access token for Lark authentication",
        "app_name": "Name of the Lark app",
    }
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        access_token = kwargs.get("access_token")
        app_name = kwargs.get("app_name")
        table_name = kwargs.get("table_name")
        
        print("App name for search: ", app_name)
        print("Table name for search: ", table_name)
        
        try:
          # Get current user
          get_current_user = LarkGetCurrentUserHandler()
          current_user = await get_current_user.execute(access_token=access_token)
          user_id = current_user.get("metadata", {}).get("lark_info", {}).get("open_id", "")
          
          # Search for base
          search_tool = LarkGetBaseFromQuery()
          result = await search_tool.execute(access_token=access_token, query=app_name, owner_ids=[user_id])

          # If base not found, create new base
          if result.get("error") and ("11244" in result.get("error") or "Not found" in result.get("error")):
            print("Base not found, creating new base")
            return result
          
          # If base found, get base
          print("Base found, getting base")
          base = result.get("metadata").get("base")
          print("Base: ", base)
          app_id = base.get("docs_token")
          print("App ID: ", app_id)
          
          # Get base tables
          lark_base_table = LarkBaseTable(is_auth=True, access_token=access_token)
          base_tables = lark_base_table.list_tables(app_id)
          table = next((table for table in base_tables if table["name"] == table_name), None)
          
          return {"content": "Successfully got Lark base with tables", "metadata": {"base": base, "table": table}}
        except Exception as e:
          return {"error": f"Failed to get Lark base with tables: {str(e)}"}
        
class LarkFetchTableData(ToolHandler):
    name = "lark_fetch_table_data"
    description = "Fetch data from a Lark table"
    args = {
        "access_token": "Access token for Lark authentication",
        "app_name": "ID of the Lark app",
        "table_name": "ID of the Lark table",
        "field_names": "List of field names to fetch",
        "sort": "List of sort conditions",
        "filter": "List of filter conditions",
    }
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        access_token = kwargs.get("access_token")
        app_name = kwargs.get("app_name")
        table_name = kwargs.get("table_name")
        field_names = kwargs.get("field_names")
        sort = kwargs.get("sort")
        filters = kwargs.get("filters")
        try:
          # Get table
          get_table_tool = LarkGetTable()
          table_metadata = (await get_table_tool.execute(
            access_token=access_token, 
            app_name=app_name, 
            table_name=table_name
          )).get("metadata", {})
          
          # C-3: The upstream search stores the Bitable token under "docs_token", not "app_id"
          app_id = table_metadata.get("base", {}).get("docs_token", "")
          table_id = table_metadata.get("table", {}).get("table_id", "")

          # Fetch table data
          table_handler = LarkBaseTable(is_auth=True, access_token=access_token)
          table_data = table_handler.search_records(app_id=app_id, table_id=table_id, field_names=field_names, sort=sort, filter={"conditions": filters})
          
          return {"content": "Successfully got Lark base with tables", "metadata": {"data": table_data}}
        except Exception as e:
          return {"error": f"Failed to get Lark base with tables: {str(e)}"}

class LarkUpdateTableHandler(ToolHandler):
    name = "lark_update_table"
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        access_token = kwargs.get("access_token")
        app_name = kwargs.get("app_name")
        table_name = kwargs.get("table_name")
        record_id = kwargs.get("record_id")
        data = kwargs.get("data")
        if isinstance(data, dict):
          data = [{"fields": data}]
        elif isinstance(data, list):
          data = [{"fields": d} for d in data]
        
        print("App name: ", app_name)
        print("Table name: ", table_name)
        
        try:
          # Get table
          get_table_tool = LarkGetTable()
          table_metadata = (await get_table_tool.execute(
            access_token=access_token, 
            app_name=app_name, 
            table_name=table_name
          )).get("metadata", {})
          
          app_id = table_metadata.get("base", {}).get("app_id", "")
          table_id = table_metadata.get("table", {}).get("table_id", "")
          
          # Update table data
          table_handler = LarkBaseTable(is_auth=True, access_token=access_token)
          table_data = table_handler.update_record(app_id=app_id, table_id=table_id, record_id=record_id, record=data)
          
          return {"content": "Successfully updated Lark table", "metadata": {"data": table_data}}
        except Exception as e:
          return {"error": f"Failed to update Lark table: {str(e)}"}
        
class LarkInsertWithExistingCheck(ToolHandler):
    name = "lark_insert_with_existing_check"
    description = "Insert data into a Lark table with existing check"
    args = {
        "access_token": "Access token for Lark authentication",
        "app_name": "ID of the Lark app",
        "table_name": "ID of the Lark table",
        "data": "Data to insert into the table",
    }
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        access_token = kwargs.get("access_token")
        app_name = kwargs.get("app_name")
        table_name = kwargs.get("table_name")
        data = kwargs.get("data")
        
        print("App name: ", app_name)
        print("Table name: ", table_name)
        
        try:
          # Get table
          get_table_tool = LarkGetTable()
          table_metadata = await get_table_tool.execute(
            access_token=access_token, 
            app_name=app_name, 
            table_name=table_name,
            fallback_data=data
          )
          
          if table_metadata.get("error"):
            print("Table not found, creating new table")
            print("Error response: ", table_metadata)
            table_metadata = new_base_with_table(
              access_token=access_token, 
              app_name=app_name, 
              table_name=table_name, 
              data=data
            )
          
          # Get base and table
          table_metadata = table_metadata.get("metadata", {})
          table = table_metadata.get("table", {})
          app_id = table_metadata.get("base", {}).get("docs_token", "")
          table_id = table.get("table_id", "") if table is not None else None
          if table_id is None:
            table_new_tool = LarkNewTableWithData()
            table_metadata = await table_new_tool.execute(
              access_token=access_token, 
              app_id=app_id, 
              table_name=table_name, 
              data=data
            )
            if table_metadata.get("error"):
              return {"error": table_metadata.get("error")}
            table_id = table_metadata.get("metadata", {}).get("new_table", {}).get("table_id", "")
          
          # Insert new record
          table_insert_data_tool = LarkInsertTableData()
          table_data = await table_insert_data_tool.execute(
            access_token=access_token, 
            app_id=app_id, 
            table_id=table_id, 
            data=data
          )
          
          print("Table data: ", table_data)
          
          return {"content": "Successfully inserted data into Lark table", "metadata": {"table_data": table_data}}
        except Exception as e:
          return {"error": f"Failed to insert data into Lark table: {str(e)}"}

class LarkBaseCheckAuthTool(ToolHandler):
  """
  Tool for checking and refreshing Lark authentication tokens.
  
  This tool verifies the current user's authentication status and automatically
  refreshes expired access tokens using stored refresh tokens. It maintains
  authentication state in a Lark table ("Edge8 Automation Auth").
  
  Workflow:
  1. Retrieve current authenticated user's open_id
  2. Query the auth table for the user's token records
  3. Check if access token has expired
  4. If expired, refresh using the refresh token
  5. Update the auth table with new token and expiry times
  6. Return the valid access token
  """
  
  # Configuration constants
  AUTH_APP_NAME = "Edge8 Automation Sessions"  # Lark app name containing auth records
  AUTH_TABLE_NAME = "Table"                # Table name for storing user tokens
  AUTH_FIELDS = ["open_id", "access_token", "refresh_token", "expires_at"]  # Fields to retrieve
  
  async def execute(self, **kwargs) -> Dict[str, Any]:
    """
    Execute authentication check and token refresh if needed.
    
    Args:
        access_token: Current Lark access token for API calls
        
    Returns:
        Dict with:
        - success: {"content": "...", "metadata": {"access_token": <token>}}
        - error: {"error": <error_message>}
    """
    try:
      lark_user_id = kwargs.get("user_id")
      
      # Step 2: Get auth table metadata
      base_id, table_id = await self._get_auth_table_ids(None)
      if isinstance(base_id, dict) and "error" in base_id:
        return base_id
      
      # Step 3: Retrieve user's auth record from table
      table_data = await self._get_user_auth_record(None, base_id, table_id, lark_user_id)
      if isinstance(table_data, dict) and "error" in table_data:
        return table_data
      
      # Extract token information
      current_access_token = table_data[0].get("access_token", "")
      expires_at = table_data[0].get("expires_at", "")
      refresh_token = table_data[0].get("refresh_token", "")
      record_id = table_data[0].get("record_id", "")
      
      # Step 4: Check if token is expired and refresh if needed
      if self._is_token_expired(expires_at):
        current_access_token = await self._refresh_and_update_token(
          None, base_id, table_id, record_id, refresh_token
        )
        if isinstance(current_access_token, dict) and "error" in current_access_token:
          return current_access_token
      
      # Step 5: Return the valid access token
      return {
        "content": "Successfully checked Lark table authentication", 
        "metadata": {"access_token": current_access_token}
      }
      
    except Exception as e:
      # Catch and return any errors that occur during execution
      return {"error": f"Failed to check Lark table authentication: {str(e)}"}
  
  async def _get_current_user_id(self, access_token: str) -> Union[str, Dict[str, Any]]:
    """
    Step 1: Retrieve the current user's open_id.
    
    Args:
        access_token: Lark access token
        
    Returns:
        User's open_id or error dict
    """
    lark_current_user = LarkGetCurrentUserHandler()
    current_user = await lark_current_user.execute(access_token=access_token)
    
    if current_user.get("error"):
      return {"error": current_user.get("error")}
    
    user_id = current_user.get("metadata", {}).get("user", {}).get("open_id", "")
    return user_id
  
  async def _get_auth_table_ids(self, access_token: str) -> Union[tuple[str, str], Dict[str, Any]]:
    """
    Step 2: Get the auth table metadata (base_id and table_id).
    
    Args:
        access_token: Lark access token
        
    Returns:
        Tuple of (base_id, table_id) or error dict
    """
    get_table_tool = LarkGetTable()
    table_metadata = await get_table_tool.execute(
      access_token=access_token, 
      app_name=self.AUTH_APP_NAME, 
      table_name=self.AUTH_TABLE_NAME
    )
    
    if table_metadata.get("error"):
      return {"error": table_metadata.get("error")}
    
    base = table_metadata.get("metadata", {}).get("base", {})
    table = table_metadata.get("metadata", {}).get("table", {})
    
    if not base or not table:
      return {"error": "Base or table not found"}
    
    base_id = base.get("docs_token", "")
    table_id = table.get("table_id", "")
    
    return base_id, table_id
  
  async def _get_user_auth_record(
    self, 
    access_token: str, 
    base_id: str, 
    table_id: str, 
    user_id: str
  ) -> Union[list, Dict[str, Any]]:
    """
    Step 3: Search for the current user's authentication record in the table.
    
    Args:
        access_token: Lark access token
        base_id: Lark base/app ID
        table_id: Lark table ID
        user_id: User's open_id
        
    Returns:
        List of table records or error dict
    """
    table_handler = LarkBaseTable(is_auth=True, access_token=access_token)
    table_data = table_handler.search_records(
      app_id=base_id, 
      table_id=table_id, 
      field_names=self.AUTH_FIELDS, 
      sort=[], 
      filter={"conditions": [f"open_id={user_id}"]}
    )
    
    if not table_data:
      return {"error": "User not found in table"}
    
    return table_data
  
  def _is_token_expired(self, expires_at: str) -> bool:
    """
    Step 4a: Check if the access token has expired.
    
    Args:
        expires_at: Token expiration time in ISO format
        
    Returns:
        True if token is expired, False otherwise
    """
    from datetime import datetime
    return datetime.fromisoformat(expires_at).timestamp() < datetime.now().timestamp()
  
  async def _refresh_and_update_token(
    self,
    access_token: str,
    base_id: str,
    table_id: str,
    record_id: str,
    refresh_token: str
  ) -> Union[str, Dict[str, Any]]:
    """
    Step 4b & 5: Refresh expired token and update the auth table.
    
    Args:
        access_token: Current Lark access token
        base_id: Lark base/app ID
        table_id: Lark table ID
        record_id: User's record ID in the auth table
        refresh_token: Refresh token for obtaining new access token
        
    Returns:
        New access token or error dict
    """
    try:
      # Refresh the token using the refresh token
      lark_auth = LarkAuth()
      new_access_token_resp = lark_auth.refresh_access_token(refresh_token)
      
      # Calculate new expiration times
      expires_at = calculate_expiry_date(seconds=new_access_token_resp.get("expires_in", 0))
      refresh_token_expires_at = calculate_expiry_date(
        seconds=new_access_token_resp.get("refresh_token_expires_in", 0)
      )
      
      # Prepare updated record with new token information
      new_data = {
        **new_access_token_resp,
        "expires_at": expires_at,
        "refresh_token_expires_at": refresh_token_expires_at
      }
      
      # Update the auth table with refreshed tokens
      table_handler = LarkBaseTable(is_auth=True, access_token=access_token)
      updated_session = table_handler.update_record(
        app_id=base_id, 
        table_id=table_id, 
        record_id=record_id, 
        record=new_data
      )
      
      # Extract and return the newly refreshed access token
      return updated_session.get("access_token", "")
      
    except Exception as e:
      return {"error": f"Failed to refresh token: {str(e)}"}


class LarkBaseInsertNewSessionTool(ToolHandler):
  """
  Tool for inserting a brand new Lark authentication session.
  
  This tool creates a new authentication record for a user in the auth table.
  It's used when a user authenticates for the first time or needs to create
  a new session record. It maintains authentication state in a Lark table
  ("Edge8 Automation Auth").
  
  Workflow:
  1. Retrieve current authenticated user's open_id and email
  2. Query the auth table for the user's existing records
  3. If record exists, return error (use check/update tool instead)
  4. If no record exists, prepare new session data with tokens
  5. Insert new session record into the auth table
  6. Return the inserted session information
  """
  
  # Configuration constants
  AUTH_APP_NAME = "Edge8 Automation Auth"  # Lark app name containing auth records
  AUTH_TABLE_NAME = "Table"                # Table name for storing user tokens
  AUTH_FIELDS = ["open_id", "email", "access_token", "refresh_token", "expires_at"]  # Fields to retrieve
  
  async def execute(self, **kwargs) -> Dict[str, Any]:
    """
    Execute new session insertion.
    
    Args:
        access_token: Current Lark access token for API calls
        email: User's email address
        refresh_token: Refresh token for future token refreshes
        expires_in: Token expiration time in seconds
        refresh_token_expires_in: Refresh token expiration time in seconds
        
    Returns:
        Dict with:
        - success: {"content": "...", "metadata": {"session_id": <id>, "access_token": <token>}}
        - error: {"error": <error_message>}
    """
    try:
      access_token = kwargs.get("access_token")
      email = kwargs.get("email")
      refresh_token = kwargs.get("refresh_token")
      expires_in = kwargs.get("expires_in", 7200)  # Default 2 hours
      refresh_token_expires_in = kwargs.get("refresh_token_expires_in", 2592000)  # Default 30 days
      
      # Step 1: Get current user's open_id
      user_id = await self._get_current_user_id(access_token)
      if isinstance(user_id, dict) and "error" in user_id:
        return user_id
      
      # Step 2: Get auth table metadata
      base_id, table_id = await self._get_auth_table_ids(access_token)
      if isinstance(base_id, dict) and "error" in base_id:
        return base_id
      
      # Step 3: Check if user already has a session record
      existing_record = await self._check_existing_session(access_token, base_id, table_id, user_id)
      if isinstance(existing_record, dict) and "error" in existing_record:
        return existing_record
      
      if existing_record:
        return {"error": "User already has an active session. Use update tool instead."}
      
      # Step 4: Prepare new session data
      session_data = await self._prepare_new_session_data(
        user_id, access_token, refresh_token, expires_in, refresh_token_expires_in
      )
      
      # Step 5: Insert new session into auth table
      record_id = await self._insert_session_record(
        access_token, base_id, table_id, session_data
      )
      if isinstance(record_id, dict) and "error" in record_id:
        return record_id
      
      # Step 6: Return success with session information
      return {
        "content": "Successfully inserted new Lark authentication session", 
        "metadata": {
          "session_id": record_id,
          "access_token": access_token,
          "user_id": user_id
        }
      }
      
    except Exception as e:
      return {"error": f"Failed to insert new Lark session: {str(e)}"}
  
  async def _get_current_user_id(self, access_token: str) -> Union[str, Dict[str, Any]]:
    """
    Step 1a: Retrieve the current user's open_id.
    
    Args:
        access_token: Lark access token
        
    Returns:
        User's open_id or error dict
    """
    lark_current_user = LarkGetCurrentUserHandler()
    current_user = await lark_current_user.execute(access_token=access_token)
    
    if current_user.get("error"):
      return {"error": current_user.get("error")}
    
    user_id = current_user.get("metadata", {}).get("user", {}).get("open_id", "")
    return user_id
  
  async def _get_auth_table_ids(self, access_token: str) -> Union[tuple[str, str], Dict[str, Any]]:
    """
    Step 2: Get the auth table metadata (base_id and table_id).
    
    Args:
        access_token: Lark access token
        
    Returns:
        Tuple of (base_id, table_id) or error dict
    """
    get_table_tool = LarkGetTable()
    table_metadata = await get_table_tool.execute(
      access_token=access_token, 
      app_name=self.AUTH_APP_NAME, 
      table_name=self.AUTH_TABLE_NAME
    )
    
    if table_metadata.get("error"):
      return {"error": table_metadata.get("error")}
    
    base = table_metadata.get("metadata", {}).get("base", {})
    table = table_metadata.get("metadata", {}).get("table", {})
    
    if not base or not table:
      return {"error": "Base or table not found"}
    
    base_id = base.get("docs_token", "")
    table_id = table.get("table_id", "")
    
    return base_id, table_id
  
  async def _check_existing_session(
    self,
    access_token: str,
    base_id: str,
    table_id: str,
    user_id: str
  ) -> Optional[Union[list, Dict[str, Any]]]:
    """
    Step 3: Check if user already has an existing session record.
    
    Args:
        access_token: Lark access token
        base_id: Lark base/app ID
        table_id: Lark table ID
        user_id: User's open_id
        
    Returns:
        List of records if exists, None if not found, or error dict
    """
    try:
      table_handler = LarkBaseTable(is_auth=True, access_token=access_token)
      table_data = table_handler.search_records(
        app_id=base_id, 
        table_id=table_id, 
        field_names=self.AUTH_FIELDS, 
        sort=[], 
        filter={"conditions": [f"open_id={user_id}"]}
      )
      
      return table_data if table_data else None
      
    except Exception as e:
      return {"error": f"Failed to check existing session: {str(e)}"}
  
  async def _prepare_new_session_data(
    self,
    user_id: str,
    access_token: str,
    refresh_token: str,
    expires_in: int,
    refresh_token_expires_in: int
  ) -> Dict[str, Any]:
    """
    Step 4: Prepare new session data with calculated expiration times.
    
    Args:
        user_id: User's open_id
        email: User's email address
        access_token: New access token
        refresh_token: Refresh token
        expires_in: Access token expiration in seconds
        refresh_token_expires_in: Refresh token expiration in seconds
        
    Returns:
        Dictionary with prepared session data
    """
    # Calculate expiration times
    expires_at = calculate_expiry_date(seconds=expires_in)
    refresh_token_expires_at = calculate_expiry_date(seconds=refresh_token_expires_in)
    
    # Prepare session record
    session_data = {
      "open_id": user_id,
      "access_token": access_token,
      "refresh_token": refresh_token,
      "expires_at": expires_at,
      "refresh_token_expires_at": refresh_token_expires_at,
      "created_at": datetime.now().isoformat(),
      "status": "active"
    }
    
    return session_data
  
  async def _insert_session_record(
    self,
    access_token: str,
    base_id: str,
    table_id: str,
    session_data: Dict[str, Any]
  ) -> Union[str, Dict[str, Any]]:
    """
    Step 5: Insert the new session record into the auth table.
    
    Args:
        access_token: Lark access token
        base_id: Lark base/app ID
        table_id: Lark table ID
        session_data: Session data to insert
        
    Returns:
        Record ID of inserted session or error dict
    """
    try:
      table_insert_handler = LarkInsertTableData()
      
      # Insert the new record
      result = table_insert_handler.execute(
        access_token=access_token,
        app_id=base_id,
        table_id=table_id,
        data=session_data
      )
      
      # Extract record ID from result
      record_id = result.get("record_id", "") if isinstance(result, dict) else ""
      
      if not record_id:
        return {"error": "Failed to get record ID from insert response"}
      
      return record_id
      
    except Exception as e:
      return {"error": f"Failed to insert session record: {str(e)}"}

class LarkCopyTableTool(ToolHandler):
  """
  Tool for copying a table and all its data from one base to another.
  
  This tool extracts a table with all its records and schema from a source base
  and creates an identical table in a target base. It handles both base IDs and
  base names as input.
  
  Workflow:
  1. Resolve source base ID (search by name if needed)
  2. Get source table metadata and schema
  3. Fetch all records from source table
  4. Resolve target base ID (search by name if needed)
  5. Create new table in target base with same schema
  6. Insert all records into the new table
  7. Return success with metadata
  """
  
  name = "lark_copy_table"
  description = "Copy a table and all its data from one base to another"
  args = {
    "access_token": "Access token for Lark authentication",
    "source_base_id": "ID of the source base",
    "source_base_name": "Name of the source base",
    "target_base_id": "ID of the target base",
    "target_base_name": "Name of the target base",
    "table_name": "Name of the table to copy",
  }
  
  async def execute(self, **kwargs) -> Dict[str, Any]:
    """
    Execute table copy operation.
    
    Args:
        access_token: Lark access token
        source_base_id: Source base ID
        source_base_name: Source base name
        target_base_id: Target base ID
        target_base_name: Target base name
        table_name: Name of table to copy
        
    Returns:
        Dict with:
        - success: {"content": "...", "metadata": {"new_table": {...}, "records_copied": <count>}}
        - error: {"error": <error_message>}
    """
    try:
      access_token = kwargs.get("access_token")
      source_base_id = kwargs.get("source_base_id")
      source_base_name = kwargs.get("source_base_name")
      target_base_id = kwargs.get("target_base_id")
      target_base_name = kwargs.get("target_base_name")
      table_name = kwargs.get("table_name")
      
      # Step 1: Resolve source base ID
      resolved_source_base_id = await self._resolve_base_id(
        access_token, source_base_id, source_base_name
      )
      print("Resolved source base ID:", resolved_source_base_id)
      if isinstance(resolved_source_base_id, dict) and "error" in resolved_source_base_id:
        return resolved_source_base_id
      
      # Step 2: Get source table metadata and schema
      source_table_id = await self._get_table_info(
        access_token, resolved_source_base_id, table_name
      )
      if isinstance(source_table_id, dict) and "error" in source_table_id:
        return source_table_id
      
      # Step 3: Fetch all records from source table
      source_records = await self._fetch_all_records(
        access_token, resolved_source_base_id, source_table_id
      )
      if isinstance(source_records, dict) and "error" in source_records:
        return source_records
      
      # Step 4: Resolve target base ID
      resolved_target_base_id = await self._resolve_base_id(
        access_token, target_base_id, target_base_name
      )
      if isinstance(resolved_target_base_id, dict) and "error" in resolved_target_base_id:
        return resolved_target_base_id
      print("Resolved target base ID:", resolved_target_base_id)
      # Step 5: Create new table in target base with same schema
      new_table = LarkNewTableWithData()
      new_table = await new_table.execute(
        access_token=access_token,
        app_id=resolved_target_base_id,
        table_name=table_name,
        data=source_records
      )
      
      if isinstance(new_table, dict) and "error" in new_table:
        return new_table
      
      # Step 7: Return success
      return {
        "content": f"Successfully copied table '{table_name}' with {records_count} records",
        "metadata": {
          "new_table": new_table,
          "records_copied": records_count,
          "source_base_id": resolved_source_base_id,
          "target_base_id": resolved_target_base_id
        }
      }
      
    except Exception as e:
      return {"error": f"Failed to copy table: {str(e)}"}
  
  async def _resolve_base_id(
    self, 
    access_token: str, 
    base_id: str,
    base_name: str
  ) -> Union[str, Dict[str, Any]]:
    """
    Resolve base ID from either an ID or a name.
    If base_id is provided, use it directly.
    Otherwise, search for the base by base_name.
    Falls back to searching wiki nodes if base is not found.
    
    Args:
        access_token: Lark access token
        base_id: Base ID (if provided)
        base_name: Base name (if provided)
        
    Returns:
        Base ID or error dict
    """
    # If base_id is provided, use it directly
    if base_id:
      return base_id
    
    # If base_name is provided, search for it
    if base_name:
      try:
        get_current_user = LarkGetCurrentUserHandler()
        current_user = await get_current_user.execute(access_token=access_token)
        user_id = current_user.get("metadata", {}).get("lark_info", {}).get("open_id", "")
        
        # Step 1: Try to find base using LarkGetBaseFromQuery
        search_tool = LarkGetBaseFromQuery()
        result = await search_tool.execute(
          access_token=access_token, 
          query=base_name, 
          owner_ids=[user_id]
        )
        
        if not result.get("error"):
          base = result.get("metadata", {}).get("base", {})
          resolved_base_id = base.get("docs_token", "")
          
          if resolved_base_id:
            return resolved_base_id
        
        # Step 2: Fallback - Search wiki nodes if base not found
        print(f"Base '{base_name}' not found in bases, searching wiki nodes...")
        wiki_result = await self._search_wiki_nodes(access_token, base_name)
        
        if isinstance(wiki_result, dict) and "error" not in wiki_result:
          wiki_node_token = wiki_result.get("doc_token")
          if wiki_node_token:
            return wiki_node_token
        
        # If wiki search also fails, return error
        return {"error": f"Base or wiki node '{base_name}' not found"}
        
      except Exception as e:
        return {"error": f"Failed to resolve base ID: {str(e)}"}
    
    # Neither ID nor name provided
    return {"error": "Either base_id or base_name must be provided"}
  
  async def _search_wiki_nodes(
    self,
    access_token: str,
    query: str
  ) -> Dict[str, Any]:
    """
    Search wiki nodes as a fallback when base is not found.
    
    Args:
        access_token: Lark access token
        query: Query string to search for
        
    Returns:
        Dict with node_id if found, or error dict
    """
    try:
      wiki = Wiki(is_auth=True, access_token=access_token)
      
      # Search wiki nodes
      search_results = wiki.search(query, page_size=50)
      
      if not search_results:
        return {"error": f"No wiki nodes found matching '{query}'"}
      
      # Find the best match (first result with matching title)
      for node in search_results:
        node_title = node.get("title", "")
        if node_title.lower() == query.lower():
          # Exact match found
          print("Exact match found:", node)
          node_id = node.get("node_id")
          if node_id:
            return {
              "node_id": node_id,
              "node_title": node_title,
              "node_type": node.get("obj_type", ""),
              "space_id": node.get("space_id", ""),
              "doc_token": node.get("obj_token", "")
            }
      
      # If no exact match, return the first result
      first_node = search_results[0]
      node_id = first_node.get("node_id")
      if node_id:
        return {
          "node_id": node_id,
          "node_title": first_node.get("title", ""),
          "node_type": first_node.get("obj_type", ""),
          "space_id": first_node.get("space_id", ""),
          "doc_token": first_node.get("obj_token", "")
        }
      
      return {"error": "Could not extract node ID from search results"}
      
    except Exception as e:
      return {"error": f"Failed to search wiki nodes: {str(e)}"}
  
  async def _get_table_info(
    self,
    access_token: str,
    base_id: str,
    table_name: str
  ) -> Dict[str, Any]:
    """
    Get table metadata including table ID and field schema.
    
    Args:
        access_token: Lark access token
        base_id: Base ID
        table_name: Table name to find
        
    Returns:
        Dict with table_id and fields, or error dict
    """
    try:
      lark_base_table = LarkBaseTable(is_auth=True, access_token=access_token)
      tables = lark_base_table.list_tables(base_id)
      
      # Find table by name
      target_table = next(
        (t for t in tables if t.get("name") == table_name), 
        None
      )
      
      if not target_table:
        return {"error": f"Table '{table_name}' not found in base"}
      
      table_id = target_table.get("table_id", "")
      
      return table_id
      
    except Exception as e:
      return {"error": f"Failed to get table info: {str(e)}"}
  
  async def _fetch_all_records(
    self,
    access_token: str,
    base_id: str,
    table_id: str
  ) -> Union[list, Dict[str, Any]]:
    """
    Fetch all records from a table.
    
    Args:
        access_token: Lark access token
        base_id: Base ID
        table_id: Table ID
        
    Returns:
        List of records or error dict
    """
    try:
      lark_base_table = LarkBaseTable(is_auth=True, access_token=access_token)
      
      # Fetch all records without filters
      records = lark_base_table.search_records(
        app_id=base_id,
        table_id=table_id,
        field_names=None,  # Empty means all fields
        sort=None,
        filter=None
      )
      
      return records if records else []
      
    except Exception as e:
      return {"error": f"Failed to fetch records: {str(e)}"}
  
  async def _create_table_in_target(
    self,
    access_token: str,
    target_base_id: str,
    table_name: str,
    source_fields: list
  ) -> Dict[str, Any]:
    """
    Create a new table in the target base with the same schema as source.
    
    Args:
        access_token: Lark access token
        target_base_id: Target base ID
        table_name: Name for the new table
        source_fields: Field schema from source table
        
    Returns:
        New table metadata or error dict
    """
    try:
      lark_base_table = LarkBaseTable(is_auth=True, access_token=access_token)
      
      # Prepare fields for new table (copy field structure)
      new_fields = []
      for field in source_fields:
        new_field = {
          "field_name": field.get("field_name", ""),
          "type": field.get("type", 1)  # Default to multiline if type not specified
        }
        new_fields.append(new_field)
      
      # Create new table
      new_table = lark_base_table.create_table(
        target_base_id,
        table_name,
        fields=new_fields
      )
      
      return new_table
      
    except Exception as e:
      return {"error": f"Failed to create table in target base: {str(e)}"}
  
  async def _insert_records_to_target(
    self,
    access_token: str,
    target_base_id: str,
    target_table_id: str,
    records: list
  ) -> Dict[str, Any]:
    """
    Insert all records into the target table.
    
    Args:
        access_token: Lark access token
        target_base_id: Target base ID
        target_table_id: Target table ID
        records: Records to insert
        
    Returns:
        Dict with records_count or error dict
    """
    try:
      if not records:
        return {"records_count": 0}
      
      # Format records for insertion
      formatted_records = []
      for record in records:
        # Extract fields from record
        fields = record.get("fields", {})
        formatted_records.append({"fields": fields})
      
      lark_base_table = LarkBaseTable(is_auth=True, access_token=access_token)
      
      # Insert records
      insert_result = lark_base_table.insert(
        target_base_id,
        target_table_id,
        formatted_records
      )
      
      return {"records_count": len(formatted_records)}
      
    except Exception as e:
      return {"error": f"Failed to insert records: {str(e)}"}

    
import asyncio
import logging

_base_logger = logging.getLogger(__name__)


class LarkListBaseTablesHandler(ToolHandler):
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """List all tables in a Lark Bitable app."""
        access_token = kwargs.get("access_token")
        app_id = kwargs.get("app_id", "")
        try:
            tables = await asyncio.to_thread(
                LarkBaseTable(is_auth=True, access_token=access_token).list_tables, app_id
            )
            return {
                "content": f"Found {len(tables)} table(s).",
                "metadata": {"tables": tables, "count": len(tables)},
            }
        except Exception as e:
            _base_logger.exception("LarkListBaseTablesHandler failed")
            return {"error": f"Failed to list tables: {str(e)}"}


class LarkListBaseFieldsHandler(ToolHandler):
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """List all fields (schema) in a Lark Bitable table."""
        access_token = kwargs.get("access_token")
        app_id = kwargs.get("app_id", "")
        table_id = kwargs.get("table_id", "")
        try:
            fields = await asyncio.to_thread(
                LarkBaseTable(is_auth=True, access_token=access_token).list_fields, app_id, table_id
            )
            return {
                "content": f"Found {len(fields)} field(s).",
                "metadata": {"fields": fields, "count": len(fields)},
            }
        except Exception as e:
            _base_logger.exception("LarkListBaseFieldsHandler failed")
            return {"error": f"Failed to list fields: {str(e)}"}


class LarkUpdateBaseRecordHandler(ToolHandler):
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """Update a single Bitable record by app_id, table_id, and record_id."""
        access_token = kwargs.get("access_token")
        app_id = kwargs.get("app_id", "")
        table_id = kwargs.get("table_id", "")
        record_id = kwargs.get("record_id", "")
        fields = kwargs.get("fields", {})
        try:
            updated = await asyncio.to_thread(
                LarkBaseTable(is_auth=True, access_token=access_token).update_record,
                app_id, table_id, record_id, {"fields": fields},
            )
            return {"content": "Successfully updated record.", "metadata": {"record": updated}}
        except Exception as e:
            _base_logger.exception("LarkUpdateBaseRecordHandler failed")
            return {"error": f"Failed to update record: {str(e)}"}


class LarkDeleteBaseRecordsHandler(ToolHandler):
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """Batch delete Bitable records by record ID list."""
        access_token = kwargs.get("access_token")
        app_id = kwargs.get("app_id", "")
        table_id = kwargs.get("table_id", "")
        record_ids = kwargs.get("record_ids", [])
        try:
            result = await asyncio.to_thread(
                LarkBaseTable(is_auth=True, access_token=access_token).delete_records,
                app_id, table_id, record_ids,
            )
            return {
                "content": f"Deleted {len(record_ids)} record(s).",
                "metadata": {"result": result, "deleted_count": len(record_ids)},
            }
        except Exception as e:
            _base_logger.exception("LarkDeleteBaseRecordsHandler failed")
            return {"error": f"Failed to delete records: {str(e)}"}


__all__ = [
    "LarkNewBaseTool",
    "LarkGetBaseFromQuery",
    "LarkNewBaseWithDataTool",
    "LarkInsertTableData",
    "LarkNewTableWithData",
    "LarkGetTable",
    "LarkFetchTableData",
    "LarkUpdateTableHandler",
    "LarkInsertWithExistingCheck",
    "LarkBaseCheckAuthTool",
    "LarkBaseInsertNewSessionTool",
    "LarkCopyTableTool",
    "map_data_to_fields",
    "LarkListBaseTablesHandler",
    "LarkListBaseFieldsHandler",
    "LarkUpdateBaseRecordHandler",
    "LarkDeleteBaseRecordsHandler",
]
        
