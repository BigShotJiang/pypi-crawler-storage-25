import os
import sys
import asyncio
import json
import requests
from typing import Dict, Any, List, Optional

# Add project root to path
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.insert(0, project_root)

from dotenv import load_dotenv
from connectors.lark_interactions.file import LarkFiles
from connectors.lark_interactions.doc import LarkDocs
from agents.tools.lark.auth_tools import LarkGetAuthSessionHandler
from agents.tools.shared import ToolHandler

load_dotenv()

class LarkGetFileMetadataHandler(ToolHandler):
    """Extract file metadata and content from Lark file ID"""
    async def execute(self, **kwargs) -> Dict[str, Any]:
        access_token = kwargs.get("access_token")
        file_token = kwargs.get("file_token")
        doc_type = kwargs.get("doc_type", "file")  # file, doc, sheet, bitable, docx, pdf
        
        try:
            lark_files = LarkFiles(access_token=access_token)
            
            # Get file metadata
            metadata_response = lark_files.get_files_metadata([{
                "doc_token": file_token,
                "doc_type": doc_type
            }])
            file_metadata = metadata_response.get("metas", [])[0] if metadata_response.get("metas") else {}
            file_name = file_metadata.get("title", file_metadata.get("name", ""))
            file_url = file_metadata.get("url", "")
            owner_id = file_metadata.get("owner_id", "")
            
            # Try to extract content if it's a document
            content = ""
            if doc_type in ["doc", "docx"]:
                try:
                    lark_docs = LarkDocs(access_token=access_token)
                    content = lark_docs.get_raw_content(file_token)
                except Exception as e:
                    print(f"Could not extract content: {str(e)}")
            
            return {
                "content": f"Successfully retrieved metadata for file '{file_name}'",
                "metadata": {
                    "file_name": file_name,
                    "file_token": file_token,
                    "file_url": file_url,
                    "owner_id": owner_id,
                    "doc_type": doc_type,
                    "raw_content": content,
                    "full_metadata": file_metadata
                }
            }
            
        except Exception as e:
            return {"error": f"Failed to get file metadata: {str(e)}"}

class LarkGetMatchedFileHandler(ToolHandler):
    """Get matched file from search"""
    async def execute(self, **kwargs) -> Dict[str, Any]:
        access_token = kwargs.get("access_token")
        folder_token = kwargs.get("folder_token")
        match_key = kwargs.get("match_key")
        target_extension = kwargs.get("target_extension", ".pdf")
        
        try:
            lark_files = LarkFiles(access_token=access_token)
            
            # Search for files
            search_results = lark_files.list_files(
                folder_token=folder_token,
            )
            
            # Find exact or best match
            file_token = None
            file_info = None
            
            for result in search_results:
                if result.get("name", "").endswith(target_extension) and result.get("name", "").strip() == match_key.strip():
                    file_token = result.get("doc_token", "")
                    file_info = result
                    break
            
            # If no exact match, take first result
            if not file_token and search_results:
                file_token = search_results[0].get("doc_token", "")
                file_info = search_results[0]
            
            if file_token:
                return {
                    "content": f"Found file '{file_info.get('title', '')}'",
                    "metadata": {
                        "file_name": file_info.get("title", ""),
                        "file_token": file_token,
                        "file_url": file_info.get("url", ""),
                        "owner_id": file_info.get("owner_id", "")
                    }
                }
            else:
                return {
                    "content": f"No file found matching '{match_key}'",
                    "metadata": {
                        "file_name": match_key,
                        "file_token": None
                    }
                }
            
        except Exception as e:
            return {"error": f"Failed to search files: {str(e)}"}


class LarkGetFolderInfoHandler(ToolHandler):
    """Get folder information including name from folder token"""
    async def execute(self, **kwargs) -> Dict[str, Any]:
        access_token = kwargs.get("access_token")
        folder_token = kwargs.get("folder_token")
        
        try:
            lark_files = LarkFiles(access_token=access_token)
            
            # Get folder metadata
            metadata_response = lark_files.get_files_metadata([{
                "doc_token": folder_token,
                "doc_type": "folder"
            }])
            
            folder_metadata = metadata_response.get("metas", [])[0] if metadata_response.get("metas") else {}
            folder_name = folder_metadata.get("title", "")
            
            return {
                "content": f"Successfully retrieved folder info for '{folder_name}'",
                "metadata": {
                    "folder_name": folder_name,
                    "folder_token": folder_token,
                    "full_metadata": folder_metadata
                }
            }
            
        except Exception as e:
            return {"error": f"Failed to get folder info: {str(e)}"}


class LarkSearchFilesHandler(ToolHandler):
    """Search for files in Lark by name pattern"""
    async def execute(self, **kwargs) -> Dict[str, Any]:
        access_token = kwargs.get("access_token")
        search_key = kwargs.get("search_key")
        object_types = kwargs.get("object_types", ["file", "doc", "docx"])
        owner_ids = kwargs.get("owner_ids", None)
        
        try:
            lark_files = LarkFiles(access_token=access_token)
            
            # Search for files
            search_results = lark_files.search(
                query=search_key,
                object_types=object_types,
                owner_ids=owner_ids
            )
            
            # Format results
            nearest_result = {}
            formatted_results = []
            for result in search_results:
                formatted_result = {
                    "name": result.get("title", ""),
                    "token": result.get("docs_token", ""),
                    "type": result.get("docs_type", ""),
                    "url": result.get("url", ""),
                    "owner_id": result.get("owner_id", "")
                }
                if search_key in result.get("title", ""):
                    nearest_result = formatted_result
                formatted_results.append(formatted_result)
            
            return {
                "content": f"Found {len(formatted_results)} file(s) matching '{search_key}'",
                "metadata": {
                    "search_key": search_key,
                    "nearest_result": nearest_result,
                    "results": formatted_results,
                    "count": len(formatted_results)
                }
            }
            
        except Exception as e:
            return {"error": f"Failed to search files: {str(e)}"}

class LarkMoveFileToFolderHandler(ToolHandler):
    """Move a file to a specific folder in Lark"""
    async def execute(self, **kwargs) -> Dict[str, Any]:
        access_token = kwargs.get("access_token")
        file_token = kwargs.get("file_token")
        target_folder_token = kwargs.get("target_folder_token")
        file_type = kwargs.get("file_type", "docx")
        
        try:
            lark_files = LarkFiles(access_token=access_token)
            
            # Move file using Lark API
            url = f"{lark_files.base_url}/drive/v1/files/{file_token}/move"
            headers = {
                "Authorization": f"Bearer {access_token}",
                "Content-Type": "application/json",
            }
            
            # L-3: wrap blocking requests.post in asyncio.to_thread
            response = await asyncio.to_thread(
                requests.post,
                url,
                headers=headers,
                json={"type": file_type, "folder_token": target_folder_token},
                params={"type": file_type},
            )

            if response.status_code == 200:
                return {
                    "content": "Successfully moved file to folder",
                    "metadata": {
                        "file_token": file_token,
                        "target_folder_token": target_folder_token,
                        "response": response.json(),
                    },
                }
            else:
                return {"error": f"Failed to move file: {response.text}"}
            
        except Exception as e:
            return {"error": f"Failed to move file: {str(e)}"}


async def main():
    """Test the file tools"""
    LARK_USER_ID = "ou_ff1c55b47c6ef9a40dc1ce3dc9cd5374"
    lark_user_handler = LarkGetAuthSessionHandler()   
    response = await lark_user_handler.execute(lark_user_id=LARK_USER_ID)
    access_token = response.get("metadata", {}).get("access_token")
    
    # Test search files
    search_handler = LarkSearchFilesHandler()
    result = await search_handler.execute(
        access_token=access_token,
        search_key="Mission 1"
    )
    print("Search result:", json.dumps(result, indent=2))


if __name__ == "__main__":
    asyncio.run(main())


class LarkListFolderHandler(ToolHandler):
    """List files in a Lark Drive folder."""
    async def execute(self, **kwargs) -> Dict[str, Any]:
        access_token = kwargs.get("access_token")
        folder_token = kwargs.get("folder_token", None)
        page_size = kwargs.get("page_size", 50)
        try:
            files = await asyncio.to_thread(
                LarkFiles(access_token=access_token).list_files,
                page_size, "", folder_token,
            )
            return {
                "content": f"Found {len(files)} file(s).",
                "metadata": {"files": files, "count": len(files), "folder_token": folder_token},
            }
        except Exception as e:
            return {"error": f"Failed to list folder: {str(e)}"}


__all__ = [
    "LarkGetFileMetadataHandler",
    "LarkGetFolderInfoHandler",
    "LarkSearchFilesHandler",
    "LarkMoveFileToFolderHandler",
    "LarkGetMatchedFileHandler",
    "LarkListFolderHandler",
]
