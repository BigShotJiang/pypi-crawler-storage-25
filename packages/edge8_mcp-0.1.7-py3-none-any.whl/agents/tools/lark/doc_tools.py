import asyncio
import logging
import os
import sys
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.insert(0, project_root)

from dotenv import load_dotenv
from connectors.lark_interactions.doc import LarkDocs, LarkDocsContent, LarkDocComments
from agents.tools.lark.auth_tools import LarkGetAuthSessionHandler
from agents.tools.lark.file_tools import LarkGetFileMetadataHandler
from agents.tools.shared import ToolHandler
from typing import Dict, Any

load_dotenv()

logger = logging.getLogger(__name__)

## Lark Document Tools
class LarkCreateDocHandler(ToolHandler):
    async def execute(self, **kwargs) -> Dict[str, Any]:
        access_token = kwargs.get("access_token")
        title = kwargs.get("title")
        content = kwargs.get("content")
        folder_token = kwargs.get("folder_token")
        try:
            doc_client = LarkDocs(access_token=access_token)
            # M-1: wrap blocking requests calls
            new_doc = await asyncio.to_thread(doc_client.create, folder_token, title)
            doc_id = new_doc.get("document_id", "")
            file_metadata_handler = LarkGetFileMetadataHandler()
            metadata = await file_metadata_handler.execute(access_token=access_token, file_token=doc_id, doc_type="docx")
            url = metadata.get("metadata", {}).get("file_url", "")
            await asyncio.to_thread(
                LarkDocsContent(access_token=access_token).text_to_blocks,
                doc_id, doc_id, "open_id", content,
            )
            return {"content": f"Successfully created document '{title}' in Lark.", "metadata": {"document_id": doc_id, "document_url": url}}

        except Exception as e:
            logger.exception("LarkCreateDocHandler failed")
            return {"error": f"Failed to create document in Lark: {str(e)}"}

class LarkSearchDocHandler(ToolHandler):
    async def execute(self, **kwargs) -> Dict[str, Any]:
        access_token = kwargs.get("access_token")
        search_key = kwargs.get("search_key")
        owner_ids = kwargs.get("owner_ids", [])
        docs_types = kwargs.get("docs_types", ['file'])
        try:
            doc_handler = LarkDocs(access_token=access_token)
            # M-1: wrap blocking requests call
            docs = await asyncio.to_thread(
                doc_handler.search, search_key, owner_ids=owner_ids, docs_types=docs_types
            )
            entities = docs.get("docs_entities", [])
            # M-2: guard against empty results
            if not entities:
                return {"error": f"No documents found matching '{search_key}'."}
            doc = entities[0]
            docs_token = doc.get("docs_token", "")
            content = await asyncio.to_thread(doc_handler.get_content, docs_token)
            return {"content": f"Successfully searched for document '{search_key}' in Lark.", "metadata": {"document": doc, "content": content}}

        except Exception as e:
            logger.exception("LarkSearchDocHandler failed")
            return {"error": f"Failed to search for document in Lark: {str(e)}"}
          

async def main():
  LARK_USER_ID = "ou_ff1c55b47c6ef9a40dc1ce3dc9cd5374"
  lark_user_handler = LarkGetAuthSessionHandler()   
  response = await lark_user_handler.execute(lark_user_id=LARK_USER_ID)
  access_token = response.get("metadata", {}).get("access_token")
  await LarkCreateDocHandler().execute(access_token=access_token, title="Test", content="**Test**", folder_token="")

if __name__ == "__main__":
  asyncio.run(main())

class LarkGetDocCommentsHandler(ToolHandler):
    async def execute(self, **kwargs) -> dict:
        access_token = kwargs.get("access_token")
        doc_token = kwargs.get("doc_token", "")
        doc_type = kwargs.get("doc_type", "docx")
        try:
            comments = await asyncio.to_thread(
                LarkDocComments(access_token=access_token).list, doc_token, doc_type
            )
            return {
                "content": f"Found {len(comments)} comment(s).",
                "metadata": {"comments": comments, "count": len(comments)},
            }
        except Exception as e:
            logger.exception("LarkGetDocCommentsHandler failed")
            return {"error": f"Failed to get comments: {str(e)}"}


class LarkAddDocCommentHandler(ToolHandler):
    async def execute(self, **kwargs) -> dict:
        access_token = kwargs.get("access_token")
        doc_token = kwargs.get("doc_token", "")
        content = kwargs.get("content", "")
        doc_type = kwargs.get("doc_type", "docx")
        try:
            comment = await asyncio.to_thread(
                LarkDocComments(access_token=access_token).add, doc_token, content, doc_type
            )
            return {"content": "Successfully added comment.", "metadata": {"comment": comment}}
        except Exception as e:
            logger.exception("LarkAddDocCommentHandler failed")
            return {"error": f"Failed to add comment: {str(e)}"}


class LarkGetDocumentContentHandler(ToolHandler):
    async def execute(self, **kwargs) -> dict:
        """Read the content of a Lark document by its token."""
        access_token = kwargs.get("access_token")
        doc_token = kwargs.get("doc_token", "")
        format = kwargs.get("format", "raw")  # "raw" | "markdown"
        try:
            docs = LarkDocs(access_token=access_token)
            if format == "markdown":
                content = await asyncio.to_thread(docs.get_content, doc_token, "docx", "markdown", "en")
            else:
                content = await asyncio.to_thread(docs.get_raw_content, doc_token)
            return {
                "content": f"Successfully retrieved document content ({format}).",
                "metadata": {"doc_token": doc_token, "format": format, "text": content},
            }
        except Exception as e:
            logger.exception("LarkGetDocumentContentHandler failed")
            return {"error": f"Failed to get document content: {str(e)}"}


__all__ = ["LarkCreateDocHandler", "LarkSearchDocHandler", "LarkGetDocCommentsHandler", "LarkAddDocCommentHandler", "LarkGetDocumentContentHandler"]