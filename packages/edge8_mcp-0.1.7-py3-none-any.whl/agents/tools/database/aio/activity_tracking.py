"""
Activity Types CRUD Operations
Database operations for activity_types table using Supabase SDK
"""

from __future__ import annotations
from typing import List, Optional, Dict, Any
from pydantic import BaseModel

# Pydantic models
class ActivityTypeCreate(BaseModel):
    activity_code: str
    activity_name: str
    activity_description: Optional[str] = None
    category: str
    points: int
    is_active: bool = True
    is_repeatable: bool = False
    max_occurrences: Optional[int] = None
    database_view: Optional[str] = None
    validation_field: Optional[str] = None
    validation_condition: Optional[str] = None
    validation_sql: Optional[str] = None

class ActivityTypeUpdate(BaseModel):
    activity_name: Optional[str] = None
    activity_description: Optional[str] = None
    category: Optional[str] = None
    points: Optional[int] = None
    is_active: Optional[bool] = None
    is_repeatable: Optional[bool] = None
    max_occurrences: Optional[int] = None
    database_view: Optional[str] = None
    validation_field: Optional[str] = None
    validation_condition: Optional[str] = None
    validation_sql: Optional[str] = None

class ActivityTypeResponse(BaseModel):
    id: int
    activity_code: str
    activity_name: str
    activity_description: Optional[str]
    category: str
    points: int
    is_active: bool
    is_repeatable: bool
    max_occurrences: Optional[int]
    database_view: Optional[str]
    validation_field: Optional[str]
    validation_condition: Optional[str]
    validation_sql: Optional[str]
    created_at: str
    updated_at: str

class ActivityTypeList(BaseModel):
    entries: List[ActivityTypeResponse]
    total: int

# CRUD operations
class ActivityTypesCRUD:
    def __init__(self, supabase: Client):
        self.supabase = supabase

    async def create(self, activity_data: ActivityTypeCreate) -> ActivityTypeResponse:
        """Create a new activity type"""
        try:
            response = self.supabase.table("activity_types").insert({
                "activity_code": activity_data.activity_code,
                "activity_name": activity_data.activity_name,
                "activity_description": activity_data.activity_description,
                "category": activity_data.category,
                "points": activity_data.points,
                "is_active": activity_data.is_active,
                "is_repeatable": activity_data.is_repeatable,
                "max_occurrences": activity_data.max_occurrences,
                "database_view": activity_data.database_view,
                "validation_field": activity_data.validation_field,
                "validation_condition": activity_data.validation_condition,
                "validation_sql": activity_data.validation_sql
            }).execute()
            
            if not response.data:
                raise ValueError("Failed to create activity type")
            
            return ActivityTypeResponse(**response.data[0])
        except Exception as e:
            if "duplicate key" in str(e).lower():
                raise ValueError(f"Activity code '{activity_data.activity_code}' already exists")
            raise ValueError(f"Error creating activity type: {str(e)}")

    async def get_by_id(self, activity_id: int) -> Optional[ActivityTypeResponse]:
        """Get activity type by ID"""
        try:
            response = (
                self.supabase.table("activity_types")
                .select("*")
                .eq("id", activity_id)
                .limit(1)
                .execute()
            )
            
            if not response.data:
                return None
                
            return ActivityTypeResponse(**response.data[0])
        except Exception as e:
            raise ValueError(f"Error getting activity type: {str(e)}")

    async def get_by_code(self, activity_code: str) -> Optional[ActivityTypeResponse]:
        """Get activity type by code"""
        try:
            response = (
                self.supabase.table("activity_types")
                .select("*")
                .eq("activity_code", activity_code)
                .limit(1)
                .execute()
            )
            
            if not response.data:
                return None
                
            return ActivityTypeResponse(**response.data[0])
        except Exception as e:
            raise ValueError(f"Error getting activity type: {str(e)}")

    async def get_all(
        self,
        skip: int = 0,
        limit: int = 100,
        category: Optional[str] = None,
        is_active: Optional[bool] = None
    ) -> ActivityTypeList:
        """Get all activity types with optional filtering"""
        try:
            query = self.supabase.table("activity_types").select("*", count="exact")
            
            if category:
                query = query.eq("category", category)
            if is_active is not None:
                query = query.eq("is_active", is_active)
            
            response = (
                query.order("created_at", desc=True)
                .limit(limit)
                .offset(skip)
                .execute()
            )
            
            data = response.data or []
            return ActivityTypeList(
                entries=[ActivityTypeResponse(**item) for item in data],
                total=response.count or 0
            )
        except Exception as e:
            raise ValueError(f"Error getting activity types: {str(e)}")

    async def get_active_activities(self) -> List[ActivityTypeResponse]:
        """Get all active activity types"""
        try:
            response = (
                self.supabase.table("activity_types")
                .select("*")
                .eq("is_active", True)
                .order("category", desc=False)
                .order("activity_name", desc=False)
                .execute()
            )
            
            return [ActivityTypeResponse(**item) for item in response.data or []]
        except Exception as e:
            raise ValueError(f"Error getting active activities: {str(e)}")

    async def get_categories(self) -> List[str]:
        """Get all unique activity categories"""
        try:
            response = (
                self.supabase.table("activity_types")
                .select("category")
                .eq("is_active", True)
                .execute()
            )
            
            categories = list(set(item["category"] for item in response.data or []))
            return sorted(categories)
        except Exception as e:
            raise ValueError(f"Error getting categories: {str(e)}")

    async def update(self, activity_id: int, activity_data: ActivityTypeUpdate) -> Optional[ActivityTypeResponse]:
        """Update activity type"""
        try:
            update_data = activity_data.dict(exclude_unset=True)
            
            if not update_data:
                return await self.get_by_id(activity_id)
            
            # Remove updated_at if present (handled by trigger)
            if "updated_at" in update_data:
                del update_data["updated_at"]
            
            response = (
                self.supabase.table("activity_types")
                .update(update_data)
                .eq("id", activity_id)
                .execute()
            )
            
            if not response.data:
                return None
                
            return ActivityTypeResponse(**response.data[0])
        except Exception as e:
            raise ValueError(f"Error updating activity type: {str(e)}")

    async def delete(self, activity_id: int) -> bool:
        """Delete activity type"""
        try:
            response = (
                self.supabase.table("activity_types")
                .delete()
                .eq("id", activity_id)
                .execute()
            )
            
            return len(response.data or []) > 0
        except Exception as e:
            raise ValueError(f"Error deleting activity type: {str(e)}")

    async def get_all(
        self,
        skip: int = 0,
        limit: int = 100,
        category: Optional[str] = None,
        is_active: Optional[bool] = None
    ) -> ActivityTypeList:
        """Get all activity types with optional filtering"""
        try:
            query = self.supabase.table("activity_types").select("*", count="exact")
            
            if category:
                query = query.eq("category", category)
            if is_active is not None:
                query = query.eq("is_active", is_active)
            
            response = (
                query.order("created_at", desc=True)
                .limit(limit)
                .offset(skip)
                .execute()
            )
            
            data = response.data or []
            return ActivityTypeList(
                entries=[ActivityTypeResponse(**item) for item in data],
                total=response.count or 0
            )
        except Exception as e:
            raise ValueError(f"Error getting activity types: {str(e)}")

    async def get_active_activities(self) -> List[ActivityTypeResponse]:
        """Get all active activity types"""
        try:
            response = (
                self.supabase.table("activity_types")
                .select("*")
                .eq("is_active", True)
                .order("category", desc=False)
                .order("activity_name", desc=False)
                .execute()
            )
            
            return [ActivityTypeResponse(**item) for item in response.data or []]
        except Exception as e:
            raise ValueError(f"Error getting active activities: {str(e)}")

    async def get_categories(self) -> List[str]:
        """Get all unique activity categories"""
        try:
            response = (
                self.supabase.table("activity_types")
                .select("category")
                .eq("is_active", True)
                .execute()
            )
            
            categories = list(set(item["category"] for item in response.data or []))
            return sorted(categories)
        except Exception as e:
            raise ValueError(f"Error getting categories: {str(e)}")

    async def update(self, activity_id: int, activity_data: ActivityTypeUpdate) -> Optional[ActivityTypeResponse]:
        """Update activity type"""
        try:
            update_data = activity_data.dict(exclude_unset=True)
            
            if not update_data:
                return await self.get_by_id(activity_id)
            
            # Remove updated_at if present (handled by trigger)
            if "updated_at" in update_data:
                del update_data["updated_at"]
            
            response = (
                self.supabase.table("activity_types")
                .update(update_data)
                .eq("id", activity_id)
                .execute()
            )
            
            if not response.data:
                return None
                
            return ActivityTypeResponse(**response.data[0])
        except Exception as e:
            raise ValueError(f"Error updating activity type: {str(e)}")

    async def delete(self, activity_id: int) -> bool:
        """Delete activity type"""
        try:
            response = (
                self.supabase.table("activity_types")
                .delete()
                .eq("id", activity_id)
                .execute()
            )
            
            return len(response.data or []) > 0
        except Exception as e:
            raise ValueError(f"Error deleting activity type: {str(e)}")
