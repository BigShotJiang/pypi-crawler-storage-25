"""
Base Sync Tool for Circle to Supabase Synchronization

Abstract base class that all sync tools will inherit from.
Provides common functionality for Circle API client initialization,
Supabase client initialization, retry logic, pagination handling,
error handling, logging, and sync metadata tracking.
"""

from abc import ABC, abstractmethod
from typing import Optional, Dict, List, Any
from datetime import datetime, timezone
import logging
import time
from tenacity import retry, stop_after_attempt, wait_exponential
import requests

from connectors.supabase_client.createClient import get_custom_client

logger = logging.getLogger(__name__)


class BaseSyncTool(ABC):
    """
    Abstract base class for Circle to Supabase sync tools.
    
    Provides common functionality:
    - Circle API client initialization
    - Supabase client initialization
    - Retry logic with exponential backoff
    - Pagination handling
    - Error handling and logging
    - Sync metadata tracking
    """
    
    def __init__(self):
        """Initialize Circle and Supabase clients"""
        self.circle_client = self._init_circle_client()
        self.supabase_client = self._init_supabase_client()
        self.sync_job_name = self.__class__.__name__
    
    @abstractmethod
    def _init_circle_client(self):
        """Initialize Circle API client (implement in subclass)"""
        pass
    
    def _init_supabase_client(self):
        """Initialize Supabase client"""
        return get_custom_client(
            options={"schema": "core"}
        )
    
    @abstractmethod
    def _fetch_circle_data(self, mode: str, last_sync: Optional[datetime]) -> List[Dict]:
        """
        Fetch data from Circle API
        
        Args:
            mode: "full" or "incremental"
            last_sync: Last successful sync timestamp (for incremental)
            
        Returns:
            List of records from Circle API
        """
        pass
    
    @abstractmethod
    def _transform_data(self, circle_records: List[Dict]) -> List[Dict]:
        """
        Transform Circle data to Supabase schema
        
        Args:
            circle_records: Raw records from Circle API
            
        Returns:
            List of records ready for Supabase upsert
        """
        pass
    
    @abstractmethod
    def _get_target_table(self) -> str:
        """Return target Supabase table name (e.g., 'core.series')"""
        pass
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=4, max=10),
        reraise=True
    )
    def _fetch_with_retry(self, fetch_func, *args, **kwargs):
        """
        Fetch data with exponential backoff retry
        
        Handles:
        - Rate limits (429)
        - Server errors (5xx)
        - Network timeouts
        """
        try:
            return fetch_func(*args, **kwargs)
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 429:
                logger.warning("Rate limit hit, waiting 60s")
                time.sleep(60)
                raise
            elif e.response.status_code >= 500:
                logger.warning(f"Server error {e.response.status_code}, retrying")
                raise
            else:
                logger.error(f"Client error {e.response.status_code}: {e}")
                return None
        except Exception as e:
            logger.error(f"Unexpected error: {str(e)}")
            raise
    
    def _upsert_to_supabase(self, records: List[Dict], conflict_column: str = "id"):
        """
        Upsert records to Supabase with conflict resolution
        
        Args:
            records: List of records to upsert
            conflict_column: Column to use for conflict resolution
        """
        if not records:
            logger.info("No records to upsert")
            return
        
        table_name = self._get_target_table()
        
        try:
            # Batch upsert
            result = self.supabase_client.table(table_name).upsert(
                records,
                on_conflict=conflict_column
            ).execute()
            
            logger.info(f"Upserted {len(records)} records to {table_name}")
            return result
            
        except Exception as e:
            logger.error(f"Failed to upsert to {table_name}: {str(e)}")
            raise
    
    def _log_sync_metadata(
        self, 
        mode: str, 
        started_at: datetime,
        status: str,
        records_fetched: int = 0,
        records_synced: int = 0,
        error_message: Optional[str] = None
    ):
        """Log sync metadata to core.sync_metadata table"""
        try:
            metadata = {
                "sync_job_name": self.sync_job_name,
                "sync_mode": mode,
                "started_at": started_at.isoformat(),
                "completed_at": datetime.now(timezone.utc).isoformat(),
                "status": status,
                "records_fetched": records_fetched,
                "records_synced": records_synced,
                "error_message": error_message
            }
            
            self.supabase_client.table("sync_metadata").insert(metadata).execute()
            
        except Exception as e:
            logger.error(f"Failed to log sync metadata: {str(e)}")
    
    def sync(self, mode: str = "incremental", last_sync: Optional[datetime] = None) -> Dict[str, Any]:
        """
        Execute sync job
        
        Args:
            mode: "full" or "incremental"
            last_sync: Last successful sync timestamp (for incremental)
            
        Returns:
            Dict with sync results
        """
        started_at = datetime.now(timezone.utc)
        
        try:
            logger.info(f"Starting {self.sync_job_name} in {mode} mode")
            
            # Fetch from Circle
            circle_records = self._fetch_circle_data(mode, last_sync)
            records_fetched = len(circle_records)
            
            logger.info(f"Fetched {records_fetched} records from Circle")
            
            # Transform data
            transformed_records = self._transform_data(circle_records)
            
            # Upsert to Supabase
            self._upsert_to_supabase(transformed_records)
            records_synced = len(transformed_records)
            
            # Log success
            self._log_sync_metadata(
                mode=mode,
                started_at=started_at,
                status="success",
                records_fetched=records_fetched,
                records_synced=records_synced
            )
            
            logger.info(f"Completed {self.sync_job_name}: {records_synced} records synced")
            
            return {
                "status": "success",
                "records_fetched": records_fetched,
                "records_synced": records_synced,
                "duration_seconds": (datetime.now(timezone.utc) - started_at).total_seconds()
            }
            
        except Exception as e:
            error_msg = str(e)
            logger.error(f"Sync failed: {error_msg}")
            
            # Log failure
            self._log_sync_metadata(
                mode=mode,
                started_at=started_at,
                status="failed",
                error_message=error_msg
            )
            
            return {
                "status": "failed",
                "error": error_msg
            }
