import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
import uuid

from dotenv import load_dotenv

from agents.tools.shared import ToolHandler
from connectors.supabase_client.db import get_custom_client

class TypeformAnalyticsHandler(ToolHandler):
  def execute(self, **kwargs):
    resource = kwargs.get("forms")
    
    return {"content": "Successfully performed Typeform Analytics", "metadata": {"resource": resource}}