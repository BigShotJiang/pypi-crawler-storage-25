# Webhook & Daily Sync - Quick Reference

## TypeformWebhookHandler

### Setup

```bash
# .env
TYPEFORM_WEBHOOK_SECRET=your-secret
AIO_SUPABASE_URL=https://your-project.supabase.co
AIO_SUPABASE_SERVICE_ROLE_KEY=your-key
```

### FastAPI Endpoint

```python
from fastapi import FastAPI, Request, HTTPException
from src.agents.tools.database.typeform_webhook import TypeformWebhookHandler
import json

app = FastAPI()
webhook_handler = TypeformWebhookHandler()

@app.post("/webhooks/typeform")
async def handle_typeform_webhook(request: Request):
    body = await request.body()
    signature = request.headers.get("X-Typeform-Signature", "")
    
    if not webhook_handler.verify_webhook_signature(body.decode(), signature):
        raise HTTPException(status_code=401, detail="Invalid signature")
    
    event_data = json.loads(body)
    result = await webhook_handler.handle_form_response_event(event_data)
    
    return result
```

### Webhook URL

Configure in Typeform: `https://your-domain.com/webhooks/typeform`

### Response

```python
{
    "status": "success",
    "submission_id": "uuid",
    "answers_synced": 5,
    "response_id": "response_id"
}
```

---

## TypeformDailySyncTool

### Setup

```bash
# .env
AIO_SUPABASE_URL=https://your-project.supabase.co
AIO_SUPABASE_SERVICE_ROLE_KEY=your-key
TYPEFORM_ACCESS_TOKEN=your-token
```

### Vercel Cron Configuration

**vercel.json**:
```json
{
  "crons": [
    {
      "path": "/api/cron/typeform-daily-sync",
      "schedule": "0 2 * * *"
    }
  ]
}
```

### FastAPI Endpoint

```python
from fastapi import APIRouter, Header, HTTPException
from src.agents.tools.database.typeform_daily_sync import TypeformDailySyncTool

@router.post("/api/typeform/daily-sync")
async def daily_sync(authorization: str = Header(None)):
    if authorization != f"Bearer {os.getenv('CRON_SECRET')}":
        raise HTTPException(status_code=401, detail="Unauthorized")
    
    sync_tool = TypeformDailySyncTool()
    result = await sync_tool.run_daily_sync()
    
    return result
```

### Response

```python
{
    "status": "success",
    "timestamp": "2025-11-29T02:00:00Z",
    "new_forms": 2,
    "updated_forms": 1,
    "new_responses": 15,
    "new_answers": 120
}
```

---

## Cron Schedules

```
"0 2 * * *"     - Daily at 2 AM UTC
"0 */6 * * *"   - Every 6 hours
"0 0 * * 0"     - Weekly on Sunday
"0 0 1 * *"     - Monthly on 1st
```

---

## Methods

### TypeformWebhookHandler

| Method | Purpose |
|--------|---------|
| `verify_webhook_signature()` | Verify webhook authenticity |
| `handle_form_response_event()` | Process webhook event |

### TypeformDailySyncTool

| Method | Purpose |
|--------|---------|
| `run_daily_sync()` | Main daily sync operation |
| `_sync_new_forms()` | Detect and sync new forms |
| `_sync_form_updates()` | Detect and sync form updates |
| `_sync_new_responses()` | Detect and sync new responses |

---

## Error Handling

### Webhook

```python
result = await webhook_handler.handle_form_response_event(event_data)

if result["status"] == "error":
    print(f"Error: {result['error']}")
elif result["status"] == "skipped":
    print(f"Skipped: {result['reason']}")
```

### Daily Sync

```python
result = await sync_tool.run_daily_sync()

if result["status"] == "error":
    print(f"Error: {result['error']}")
else:
    print(f"Synced {result['new_responses']} responses")
```

---

## Files

- **Webhook**: `src/agents/tools/database/typeform_webhook.py`
- **Daily Sync**: `src/agents/tools/database/typeform_daily_sync.py`
- **Guide**: `src/agents/tools/database/WEBHOOK_AND_DAILY_SYNC_GUIDE.md`

---

## Flow

```
Typeform
├── New Response → Webhook → Immediate Sync
├── New Form → Daily Sync (2 AM UTC)
└── Form Update → Daily Sync (2 AM UTC)
```

---

**Status**: ✅ Production Ready
