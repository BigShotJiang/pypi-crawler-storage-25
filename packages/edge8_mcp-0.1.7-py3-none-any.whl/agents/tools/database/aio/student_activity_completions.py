"""
Student Activity Completions CRUD Operations
Database operations for student_activity_completions table using Supabase SDK
"""

from __future__ import annotations
from typing import List, Optional, Dict, Any
from pydantic import BaseModel

# Pydantic models
class StudentActivityCompletionCreate(BaseModel):
    student_id: int
    activity_code: str
    points_awarded: int
    occurrence_count: int = 1
    metadata: Optional[dict] = None

class StudentActivityCompletionUpdate(BaseModel):
    points_awarded: Optional[int] = None
    occurrence_count: Optional[int] = None
    metadata: Optional[dict] = None

class StudentActivityCompletionResponse(BaseModel):
    id: int
    student_id: int
    activity_code: str
    points_awarded: int
    occurrence_count: int
    metadata: Optional[dict]
    completed_at: str

class StudentActivityCompletionList(BaseModel):
    entries: List[StudentActivityCompletionResponse]
    total: int

class ActivityAwardRequest(BaseModel):
    student_id: int
    activity_code: str
    metadata: Optional[dict] = None

class ActivityAwardResponse(BaseModel):
    success: bool
    message: str
    points_awarded: int
    completion_id: Optional[int]

# CRUD operations
class StudentActivityCompletionsCRUD:
    def __init__(self, supabase: Client):
        self.supabase = supabase

    async def create(self, completion_data: StudentActivityCompletionCreate) -> StudentActivityCompletionResponse:
        """Create a new activity completion"""
        try:
            response = self.supabase.table("student_activity_completions").insert({
                "student_id": completion_data.student_id,
                "activity_code": completion_data.activity_code,
                "points_awarded": completion_data.points_awarded,
                "occurrence_count": completion_data.occurrence_count,
                "metadata": completion_data.metadata or {}
            }).execute()
            
            if not response.data:
                raise ValueError("Failed to create activity completion")
            
            return StudentActivityCompletionResponse(**response.data[0])
        except Exception as e:
            if "foreign key constraint" in str(e).lower():
                raise ValueError(f"Activity code '{completion_data.activity_code}' does not exist")
            elif "duplicate key" in str(e).lower():
                raise ValueError(f"Activity completion for student {completion_data.student_id} with occurrence {completion_data.occurrence_count} already exists")
            raise ValueError(f"Failed to create activity completion: {str(e)}")

    async def get_by_id(self, completion_id: int) -> Optional[StudentActivityCompletionResponse]:
        """Get activity completion by ID"""
        try:
            response = (
                self.supabase.table("student_activity_completions")
                .select("*")
                .eq("id", completion_id)
                .limit(1)
                .execute()
            )
            
            if not response.data:
                return None
                
            return StudentActivityCompletionResponse(**response.data[0])
        except Exception as e:
            raise ValueError(f"Error getting activity completion: {str(e)}")

    async def get_all(
        self,
        skip: int = 0,
        limit: int = 100,
        student_id: Optional[int] = None,
        activity_code: Optional[str] = None
    ) -> StudentActivityCompletionList:
        """Get all activity completions with optional filtering"""
        try:
            query = self.supabase.table("student_activity_completions").select("*", count="exact")
            
            if student_id:
                query = query.eq("student_id", student_id)
            if activity_code:
                query = query.eq("activity_code", activity_code)
            
            response = (
                query.order("completed_at", desc=True)
                .limit(limit)
                .offset(skip)
                .execute()
            )
            
            data = response.data or []
            return StudentActivityCompletionList(
                entries=[StudentActivityCompletionResponse(**item) for item in data],
                total=response.count or 0
            )
        except Exception as e:
            raise ValueError(f"Error getting activity completions: {str(e)}")

    async def get_by_student(
        self, 
        student_id: int,
        activity_code: Optional[str] = None
    ) -> List[StudentActivityCompletionResponse]:
        """Get all completions for a specific student"""
        try:
            query = self.supabase.table("student_activity_completions").select("*").eq("student_id", student_id)
            
            if activity_code:
                query = query.eq("activity_code", activity_code)
            
            response = query.order("completed_at", desc=True).execute()
            
            return [StudentActivityCompletionResponse(**item) for item in response.data or []]
        except Exception as e:
            raise ValueError(f"Error getting student completions: {str(e)}")

    async def update(
        self, 
        completion_id: int, 
        completion_data: StudentActivityCompletionUpdate
    ) -> Optional[StudentActivityCompletionResponse]:
        """Update activity completion"""
        try:
            update_data = completion_data.dict(exclude_unset=True)
            
            if not update_data:
                return await self.get_by_id(completion_id)
            
            response = (
                self.supabase.table("student_activity_completions")
                .update(update_data)
                .eq("id", completion_id)
                .execute()
            )
            
            if not response.data:
                return None
                
            return StudentActivityCompletionResponse(**response.data[0])
        except Exception as e:
            raise ValueError(f"Failed to update activity completion: {str(e)}")

    async def delete(self, completion_id: int) -> bool:
        """Delete activity completion"""
        try:
            response = (
                self.supabase.table("student_activity_completions")
                .delete()
                .eq("id", completion_id)
                .execute()
            )
            
            return len(response.data or []) > 0
        except Exception as e:
            raise ValueError(f"Failed to delete activity completion: {str(e)}")

    async def award_activity_points(
        self, 
        award_request: ActivityAwardRequest,
        user_email: Optional[str] = None
    ) -> ActivityAwardResponse:
        """Safely award activity points using the secure function"""
        
        try:
            # Set session variable for audit logging (if supported)
            # Note: Supabase doesn't support session variables in the same way
            # This will be handled by the trigger function
            
            # Call the secure function using RPC
            response = self.supabase.rpc("award_activity_points", {
                "p_student_id": award_request.student_id,
                "p_activity_code": award_request.activity_code,
                "p_metadata": award_request.metadata or {}
            }).execute()
            
            if not response.data:
                raise ValueError("Failed to award activity points")
            
            result = response.data[0]
            return ActivityAwardResponse(**result)
        except Exception as e:
            raise ValueError(f"Failed to award activity points: {str(e)}")

    async def get_student_activity_summary(self, student_id: int) -> Dict[str, Any]:
        """Get activity summary for a student"""
        try:
            response = (
                self.supabase.table("student_activity_completions")
                .select("points_awarded, activity_code")
                .eq("student_id", student_id)
                .execute()
            )
            
            data = response.data or []
            total_completions = len(data)
            total_points = sum(item.get("points_awarded", 0) for item in data)
            unique_activities = len(set(item.get("activity_code") for item in data))
            
            return {
                "total_completions": total_completions,
                "total_points": total_points,
                "unique_activities": unique_activities
            }
        except Exception as e:
            raise ValueError(f"Error getting student activity summary: {str(e)}")

    async def get_activity_completion_stats(self, activity_code: str) -> Dict[str, Any]:
        """Get completion statistics for a specific activity"""
        try:
            response = (
                self.supabase.table("student_activity_completions")
                .select("student_id, points_awarded")
                .eq("activity_code", activity_code)
                .execute()
            )
            
            data = response.data or []
            total_completions = len(data)
            unique_students = len(set(item.get("student_id") for item in data))
            total_points_awarded = sum(item.get("points_awarded", 0) for item in data)
            avg_points_per_completion = total_points_awarded / total_completions if total_completions > 0 else 0.0
            
            return {
                "total_completions": total_completions,
                "unique_students": unique_students,
                "total_points_awarded": total_points_awarded,
                "avg_points_per_completion": float(avg_points_per_completion)
            }
        except Exception as e:
            raise ValueError(f"Error getting activity completion stats: {str(e)}")

    async def get_top_students_by_points(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Get top students by total points using leaderboard view"""
        try:
            response = (
                self.supabase.table("student_leaderboard")
                .select("student_id, student_name, student_email, total_calculated_points, activities_completed")
                .order("total_calculated_points", desc=True)
                .limit(limit)
                .execute()
            )
            
            return [
                {
                    "student_id": item["student_id"],
                    "student_name": item["student_name"],
                    "student_email": item["student_email"],
                    "total_points": item["total_calculated_points"],
                    "completion_count": item["activities_completed"]
                }
                for item in response.data or []
            ]
        except Exception as e:
            raise ValueError(f"Error getting top students: {str(e)}")
