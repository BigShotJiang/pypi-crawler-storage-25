"""
Typeform Webhook Handler

Receives webhook events from Typeform and syncs new responses to Supabase.
Designed to be used as a FastAPI endpoint.
"""

import os
import json
import hmac
import hashlib
from typing import Dict, Any, Optional
from datetime import datetime
import uuid

from dotenv import load_dotenv

from connectors.supabase_client.db import get_custom_client
from connectors.typeform.forms import TypeformForms
from utils.custom_types import TypeformResponse, TypeformAnswer

load_dotenv()


class TypeformWebhookHandler:
    """Handle incoming Typeform webhook events for new responses"""

    def __init__(self):
        """Initialize webhook handler with Supabase client"""
        self.aio_supabase_url = os.getenv("AIO_SUPABASE_URL")
        self.aio_supabase_service_role_key = os.getenv("AIO_SUPABASE_SERVICE_ROLE_KEY")
        self.typeform_webhook_secret = os.getenv("TYPEFORM_WEBHOOK_SECRET")

        if not self.aio_supabase_url or not self.aio_supabase_service_role_key:
            raise ValueError(
                "AIO_SUPABASE_URL and AIO_SUPABASE_SERVICE_ROLE_KEY environment variables must be set"
            )

        self.supabase_client: Client = get_custom_client(
            self.aio_supabase_url, self.aio_supabase_service_role_key
        )
        self.typeform_forms = TypeformForms()

    def verify_webhook_signature(self, payload: str, signature: str) -> bool:
        """
        Verify webhook signature from Typeform

        Args:
            payload: Raw request body
            signature: X-Typeform-Signature header value

        Returns:
            True if signature is valid, False otherwise
        """
        if not self.typeform_webhook_secret:
            print("⚠️ TYPEFORM_WEBHOOK_SECRET not set - skipping signature verification")
            return True

        try:
            # Typeform signature format: sha256=<hash>
            expected_signature = (
                "sha256="
                + hmac.new(
                    self.typeform_webhook_secret.encode(),
                    payload.encode(),
                    hashlib.sha256,
                ).hexdigest()
            )

            is_valid = hmac.compare_digest(signature, expected_signature)

            if not is_valid:
                print(f"❌ Invalid webhook signature")
                return False

            print("✅ Webhook signature verified")
            return True

        except Exception as e:
            print(f"❌ Error verifying signature: {str(e)}")
            return False

    async def handle_form_response_event(
        self, event_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Handle form_response event from Typeform webhook

        Args:
            event_data: Webhook event data

        Returns:
            Dictionary with processing result
        """
        try:
            # Extract event type
            event_type = event_data.get("event_type")

            if event_type != "form_response":
                print(f"⚠️ Ignoring event type: {event_type}")
                return {"status": "ignored", "event_type": event_type}

            # Extract form and response data
            form_response = event_data.get("form_response", {})
            form_id = form_response.get("form_id")
            response_id = form_response.get("response_id")

            if not form_id or not response_id:
                print("❌ Missing form_id or response_id in webhook event")
                return {"status": "error", "error": "Missing form_id or response_id"}

            print(f"📥 Processing webhook event for form {form_id}, response {response_id}")

            # Get form slug (database form ID)
            form_db_id = await self._get_form_db_id(form_id)

            if not form_db_id:
                print(f"⚠️ Form {form_id} not found in database - skipping response")
                return {
                    "status": "skipped",
                    "reason": "Form not found in database",
                    "form_id": form_id,
                }

            # Sync the response
            result = await self._sync_webhook_response(form_db_id, form_response)

            return result

        except Exception as e:
            print(f"❌ Error handling webhook event: {str(e)}")
            return {"status": "error", "error": str(e)}

    async def _get_form_db_id(self, typeform_id: str) -> Optional[str]:
        """
        Get database form ID from Typeform ID

        Args:
            typeform_id: Typeform form ID

        Returns:
            Database form UUID or None
        """
        try:
            response = (
                self.supabase_client.table("forms")
                .select("id")
                .eq("slug", typeform_id)
                .execute()
            )

            if response.data and len(response.data) > 0:
                return response.data[0].get("id")

            return None

        except Exception as e:
            print(f"❌ Error getting form DB ID: {str(e)}")
            return None

    async def _sync_webhook_response(
        self, form_db_id: str, form_response: TypeformResponse
    ) -> Dict[str, Any]:
        """
        Sync webhook response to database

        Args:
            form_db_id: Database form ID
            form_response: Response data from webhook

        Returns:
            Dictionary with sync result
        """
        try:
            response_id = form_response.get("response_id")
            submitted_at = form_response.get("submitted_at")
            response_type = form_response.get("response_type", "completed")

            # Extract submitter email and name from answers
            submitter_email = "anonymous@typeform.local"
            submitter_name = None

            answers = form_response.get("answers", [])
            for answer in answers:
                field_type = answer.get("field", {}).get("type")
                answer_type = answer.get("type")
                
                # Email field (including contact_info subfield)
                if field_type == "email" or answer_type == "email":
                    email_value = answer.get("email") or answer.get("text")
                    if email_value:
                        submitter_email = email_value
                
                # Try to get name from short_text fields
                if field_type == "short_text" and not submitter_name:
                    if answer.get("text"):
                        submitter_name = answer.get("text")

            # Check if response already exists
            existing = (
                self.supabase_client.table("form_submissions")
                .select("id")
                .eq("form_id", form_db_id)
                .filter("submitted_at", "eq", submitted_at)
                .execute()
            )

            if existing.data and len(existing.data) > 0:
                print(f"⚠️ Response already exists in database")
                return {
                    "status": "skipped",
                    "reason": "Response already exists",
                    "response_id": response_id,
                }

            # Prepare submission data (matching form_submissions table schema)
            metadata = form_response.get("metadata", {})
            submission_insert_data = {
                "id": str(uuid.uuid4()),
                "form_id": form_db_id,
                "submitter_email": submitter_email,
                "submitter_name": submitter_name,
                "status": "submitted" if response_type == "completed" else "draft",
                "submitted_at": submitted_at,
                "ip_address": metadata.get("ip_address"),
                "user_agent": metadata.get("user_agent"),
            }

            # Insert submission
            submission_response = (
                self.supabase_client.table("form_submissions")
                .insert(submission_insert_data)
                .execute()
            )

            if not submission_response.data:
                raise Exception("Failed to insert submission")

            submission_db_id = submission_response.data[0].get("id")
            print(f"✅ Inserted submission: {submission_db_id}")

            # Sync answers
            answers_count = 0
            for answer in answers:
                try:
                    answer_result = await self._sync_webhook_answer(
                        submission_db_id, form_db_id, answer
                    )
                    if answer_result:
                        answers_count += 1
                except Exception as e:
                    print(f"⚠️ Error syncing answer: {str(e)}")

            print(f"✅ Synced {answers_count} answers")

            return {
                "status": "success",
                "submission_id": submission_db_id,
                "answers_synced": answers_count,
                "response_id": response_id,
            }

        except Exception as e:
            print(f"❌ Error syncing webhook response: {str(e)}")
            return {"status": "error", "error": str(e)}

    async def _sync_webhook_answer(
        self, submission_db_id: str, form_db_id: str, answer: TypeformAnswer
    ) -> bool:
        """
        Sync webhook answer to database

        Args:
            submission_db_id: Database submission ID
            form_db_id: Database form ID
            answer: Answer data

        Returns:
            True if successful, False otherwise
        """
        try:
            field_id = answer.get("field", {}).get("id")
            answer_type = answer.get("type")

            # Extract answer value based on type
            answer_value = None
            if answer_type == "text":
                answer_value = answer.get("text")
            elif answer_type == "email":
                answer_value = answer.get("email") or answer.get("text")
            elif answer_type == "number":
                answer_value = str(answer.get("number"))
            elif answer_type == "choice":
                choice = answer.get("choice", {})
                answer_value = choice.get("label")
            elif answer_type == "choices":
                choices = answer.get("choices", {})
                # Handle both list format and dict format with labels array
                if isinstance(choices, list):
                    answer_value = "; ".join(c.get("label", "") for c in choices)
                elif isinstance(choices, dict) and choices.get("labels"):
                    answer_value = "; ".join(choices.get("labels", []))
            elif answer_type == "date":
                answer_value = answer.get("date")
            elif answer_type == "time":
                answer_value = answer.get("time")
            elif answer_type == "boolean":
                answer_value = str(answer.get("boolean"))
            elif answer_type == "file_url":
                answer_value = answer.get("file_url")
            elif answer_type == "phone_number":
                answer_value = answer.get("phone_number") or answer.get("text")
            else:
                answer_value = str(answer.get(answer_type, ""))

            if not answer_value:
                return False

            # Get question ID from field ref
            questions_response = (
                self.supabase_client.table("form_questions")
                .select("id")
                .eq("form_id", form_db_id)
                .filter(
                    "validation_rules->>typeform_ref",
                    "eq",
                    answer.get("field", {}).get("ref"),
                )
                .execute()
            )

            if not questions_response.data:
                print(f"⚠️ Question not found for field {field_id}")
                return False

            question_db_id = questions_response.data[0].get("id")

            # Prepare answer data
            answer_insert_data = {
                "id": str(uuid.uuid4()),
                "submission_id": submission_db_id,
                "question_id": question_db_id,
                "answer_value": answer_value,
                "answer_type": answer_type,
                "is_valid": True,
            }

            # Insert answer
            answer_response = (
                self.supabase_client.table("form_submission_answers")
                .insert(answer_insert_data)
                .execute()
            )

            if not answer_response.data:
                raise Exception("Failed to insert answer")

            return True

        except Exception as e:
            print(f"❌ Error syncing webhook answer: {str(e)}")
            return False


__all__ = ["TypeformWebhookHandler"]
