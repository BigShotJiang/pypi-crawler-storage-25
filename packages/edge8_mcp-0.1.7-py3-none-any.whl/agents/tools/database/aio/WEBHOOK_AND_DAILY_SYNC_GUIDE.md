# Typeform Webhook & Daily Sync - Complete Guide

## Overview

Two specialized tools for real-time and scheduled Typeform data syncing:

1. **TypeformWebhookHandler** - Real-time webhook receiver for new responses
2. **TypeformDailySyncTool** - Daily scheduled scan for form updates and new responses

---

## 1. TypeformWebhookHandler

### Purpose

Receives webhook events from Typeform in real-time and syncs new responses immediately to Supabase.

**File**: `src/agents/tools/database/typeform_webhook.py`
**Class**: `TypeformWebhookHandler`

### Features

✅ **Real-time response sync** - Syncs responses as they come in
✅ **Webhook signature verification** - Validates Typeform webhook authenticity
✅ **Duplicate detection** - Prevents duplicate response syncing
✅ **Error handling** - Continues on individual errors
✅ **Type-safe** - Uses TypedDict definitions

### Setup

#### 1. Get Webhook Secret from Typeform

1. Go to Typeform account settings
2. Navigate to Webhooks
3. Create new webhook
4. Copy the webhook secret

#### 2. Add to Environment

```bash
# .env
TYPEFORM_WEBHOOK_SECRET=your-webhook-secret
AIO_SUPABASE_URL=https://your-project.supabase.co
AIO_SUPABASE_SERVICE_ROLE_KEY=your-key
```

#### 3. Create FastAPI Endpoint

```python
from fastapi import FastAPI, Request, HTTPException
from src.agents.tools.database.typeform_webhook import TypeformWebhookHandler
import json

app = FastAPI()
webhook_handler = TypeformWebhookHandler()

@app.post("/webhooks/typeform")
async def handle_typeform_webhook(request: Request):
    """Handle incoming Typeform webhook"""
    
    # Get raw body for signature verification
    body = await request.body()
    signature = request.headers.get("X-Typeform-Signature", "")
    
    # Verify signature
    if not webhook_handler.verify_webhook_signature(body.decode(), signature):
        raise HTTPException(status_code=401, detail="Invalid signature")
    
    # Parse JSON
    event_data = json.loads(body)
    
    # Handle event
    result = await webhook_handler.handle_form_response_event(event_data)
    
    return result
```

#### 4. Configure Webhook in Typeform

1. Go to form settings
2. Integrations → Webhooks
3. Add webhook URL: `https://your-domain.com/webhooks/typeform`
4. Select "form_response" event
5. Save

### Usage

```python
from src.agents.tools.database.typeform_webhook import TypeformWebhookHandler

webhook_handler = TypeformWebhookHandler()

# Verify signature
is_valid = webhook_handler.verify_webhook_signature(payload, signature)

# Handle event
result = await webhook_handler.handle_form_response_event(event_data)
```

### Webhook Event Format

Typeform sends webhook events in this format:

```json
{
  "event_type": "form_response",
  "form_response": {
    "form_id": "ayztPlg7",
    "response_id": "qnkb2ezp461cgnydtmqnkb2kswm00be7",
    "response_type": "completed",
    "submitted_at": "2025-11-18T03:14:04Z",
    "answers": [
      {
        "type": "text",
        "field": {
          "id": "WRfcvINoCFnc",
          "type": "long_text",
          "ref": "39fb9901-e872-46e0-ba26-550ea1f803bf"
        },
        "text": "Sample response"
      }
    ],
    "metadata": {
      "user_agent": "Mozilla/5.0...",
      "platform": "other",
      "browser": "default",
      "ip_address": "192.168.1.1"
    }
  }
}
```

### Response

```python
{
    "status": "success" | "error" | "ignored" | "skipped",
    "submission_id": "uuid",
    "answers_synced": 5,
    "response_id": "response_id",
    "error": "error message (if error)"
}
```

### Error Handling

```python
result = await webhook_handler.handle_form_response_event(event_data)

if result["status"] == "error":
    print(f"Error: {result['error']}")
elif result["status"] == "skipped":
    print(f"Skipped: {result['reason']}")
elif result["status"] == "success":
    print(f"Synced {result['answers_synced']} answers")
```

---

## 2. TypeformDailySyncTool

### Purpose

Scheduled daily scan to check for:
1. New form creations
2. Form updates (title, description, fields)
3. New responses since last sync

**File**: `src/agents/tools/database/typeform_daily_sync.py`
**Class**: `TypeformDailySyncTool`

### Features

✅ **New form detection** - Finds forms created in Typeform
✅ **Form update detection** - Finds updated forms by timestamp
✅ **New response detection** - Finds responses since last sync
✅ **Batch processing** - Handles multiple forms efficiently
✅ **Detailed logging** - Tracks all operations

### Setup

#### 1. Add to Environment

```bash
# .env
AIO_SUPABASE_URL=https://your-project.supabase.co
AIO_SUPABASE_SERVICE_ROLE_KEY=your-key
TYPEFORM_ACCESS_TOKEN=your-token
```

#### 2. Create Vercel Cron Job

Create `vercel.json`:

```json
{
  "crons": [
    {
      "path": "/api/cron/typeform-daily-sync",
      "schedule": "0 2 * * *"
    }
  ]
}
```

This runs daily at 2 AM UTC.

#### 3. Create API Route

Create `pages/api/cron/typeform-daily-sync.ts`:

```typescript
import { NextRequest, NextResponse } from 'next/server';

export const config = {
  runtime: 'nodejs',
};

export default async function handler(req: NextRequest) {
  // Verify cron secret
  if (req.headers.get('authorization') !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    // Call Python backend
    const response = await fetch('https://your-backend.com/api/typeform/daily-sync', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    const result = await response.json();
    return NextResponse.json(result);
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}
```

Or in Python (FastAPI):

```python
from fastapi import APIRouter, Header, HTTPException
from src.agents.tools.database.typeform_daily_sync import TypeformDailySyncTool

router = APIRouter()

@router.post("/api/typeform/daily-sync")
async def daily_sync(authorization: str = Header(None)):
    """Daily Typeform sync via Vercel cron"""
    
    # Verify cron secret
    expected_auth = f"Bearer {os.getenv('CRON_SECRET')}"
    if authorization != expected_auth:
        raise HTTPException(status_code=401, detail="Unauthorized")
    
    # Run sync
    sync_tool = TypeformDailySyncTool()
    result = await sync_tool.run_daily_sync()
    
    return result
```

### Usage

```python
from src.agents.tools.database.typeform_daily_sync import TypeformDailySyncTool
import asyncio

async def main():
    sync_tool = TypeformDailySyncTool()
    result = await sync_tool.run_daily_sync()
    print(result)

asyncio.run(main())
```

### Response

```python
{
    "status": "success" | "error",
    "timestamp": "2025-11-29T02:00:00Z",
    "new_forms": 2,
    "updated_forms": 1,
    "new_responses": 15,
    "new_answers": 120,
    "details": {
        "new_forms": {
            "count": 2,
            "forms": [
                {
                    "typeform_id": "form_id",
                    "db_id": "uuid",
                    "questions": 8
                }
            ]
        },
        "updated_forms": {
            "count": 1,
            "forms": [...]
        },
        "new_responses": {
            "count": 15,
            "answers_count": 120,
            "responses": [...]
        }
    }
}
```

### Cron Schedule Examples

```
"0 2 * * *"     - Daily at 2 AM UTC
"0 */6 * * *"   - Every 6 hours
"0 0 * * 0"     - Weekly on Sunday at midnight
"0 0 1 * *"     - Monthly on 1st at midnight
```

---

## Comparison

| Feature | Webhook | Daily Sync |
|---------|---------|-----------|
| **Trigger** | Real-time | Scheduled |
| **Latency** | Immediate | Up to 24 hours |
| **New responses** | ✅ | ✅ |
| **New forms** | ❌ | ✅ |
| **Form updates** | ❌ | ✅ |
| **Cost** | Lower | Lower |
| **Complexity** | Medium | Low |

---

## Integration Strategy

### Recommended Setup

1. **Use Webhook** for real-time response syncing
2. **Use Daily Sync** for form updates and new forms
3. **Fallback** - Daily sync catches any missed webhook events

### Flow Diagram

```
Typeform
├── New Response
│   └── Webhook → TypeformWebhookHandler → Supabase (immediate)
│
├── New Form
│   └── Daily Sync (2 AM UTC) → TypeformDailySyncTool → Supabase
│
└── Form Update
    └── Daily Sync (2 AM UTC) → TypeformDailySyncTool → Supabase
```

---

## Error Handling

### Webhook Errors

```python
# Invalid signature
{
    "status": "error",
    "error": "Invalid webhook signature"
}

# Form not found
{
    "status": "skipped",
    "reason": "Form not found in database",
    "form_id": "form_id"
}

# Response already exists
{
    "status": "skipped",
    "reason": "Response already exists",
    "response_id": "response_id"
}
```

### Daily Sync Errors

```python
# General error
{
    "status": "error",
    "timestamp": "2025-11-29T02:00:00Z",
    "error": "Error message"
}

# Partial success
{
    "status": "success",
    "new_forms": 2,
    "updated_forms": 0,
    "new_responses": 15,
    "details": {
        "new_forms": {
            "error": "Some forms failed"
        }
    }
}
```

---

## Monitoring

### Webhook Monitoring

```python
# Log webhook events
import logging

logger = logging.getLogger(__name__)

@app.post("/webhooks/typeform")
async def handle_typeform_webhook(request: Request):
    result = await webhook_handler.handle_form_response_event(event_data)
    
    if result["status"] == "success":
        logger.info(f"Synced response: {result['response_id']}")
    else:
        logger.warning(f"Webhook processing failed: {result}")
    
    return result
```

### Daily Sync Monitoring

```python
# Log daily sync results
import logging

logger = logging.getLogger(__name__)

@router.post("/api/typeform/daily-sync")
async def daily_sync():
    sync_tool = TypeformDailySyncTool()
    result = await sync_tool.run_daily_sync()
    
    logger.info(f"Daily sync completed: {result['new_forms']} new forms, "
                f"{result['new_responses']} new responses")
    
    return result
```

---

## Testing

### Test Webhook Handler

```python
import json
from src.agents.tools.database.typeform_webhook import TypeformWebhookHandler

webhook_handler = TypeformWebhookHandler()

# Test event
event_data = {
    "event_type": "form_response",
    "form_response": {
        "form_id": "ayztPlg7",
        "response_id": "test_response_123",
        "response_type": "completed",
        "submitted_at": "2025-11-29T12:00:00Z",
        "answers": [
            {
                "type": "text",
                "field": {
                    "id": "field_id",
                    "type": "short_text",
                    "ref": "field_ref"
                },
                "text": "Test answer"
            }
        ]
    }
}

result = await webhook_handler.handle_form_response_event(event_data)
print(result)
```

### Test Daily Sync

```python
from src.agents.tools.database.typeform_daily_sync import TypeformDailySyncTool
import asyncio

async def test_daily_sync():
    sync_tool = TypeformDailySyncTool()
    result = await sync_tool.run_daily_sync()
    
    print(f"New forms: {result['new_forms']}")
    print(f"Updated forms: {result['updated_forms']}")
    print(f"New responses: {result['new_responses']}")

asyncio.run(test_daily_sync())
```

---

## Security

### Webhook Security

1. **Verify signature** - Always verify X-Typeform-Signature header
2. **Use HTTPS** - Webhook endpoint must use HTTPS
3. **Validate data** - Validate all incoming data
4. **Rate limiting** - Implement rate limiting on webhook endpoint

### Daily Sync Security

1. **Verify cron secret** - Check authorization header
2. **Use service role key** - Use Supabase service role for database access
3. **Log operations** - Log all sync operations
4. **Monitor failures** - Alert on sync failures

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Webhook not received | Check webhook URL is accessible, verify signature secret |
| Signature verification fails | Ensure TYPEFORM_WEBHOOK_SECRET is correct |
| Form not found | Run daily sync first to create form |
| Responses not syncing | Check Supabase credentials, verify form exists |
| Daily sync not running | Check Vercel cron configuration, verify CRON_SECRET |

---

## Files

- **Webhook Handler**: `src/agents/tools/database/typeform_webhook.py`
- **Daily Sync Tool**: `src/agents/tools/database/typeform_daily_sync.py`
- **Main Sync Tool**: `src/agents/tools/database/aio.py` (TypeformDataSyncTool)
- **Guide**: `src/agents/tools/database/WEBHOOK_AND_DAILY_SYNC_GUIDE.md`

---

## Summary

**TypeformWebhookHandler** - Real-time response syncing
- Receives webhook events from Typeform
- Verifies webhook signature
- Syncs responses immediately
- Prevents duplicates

**TypeformDailySyncTool** - Scheduled form and response syncing
- Detects new forms
- Detects form updates
- Syncs new responses
- Runs via Vercel cron job

**Together** - Complete Typeform data sync solution
- Real-time responses via webhook
- Daily form updates via cron
- Fallback for missed events
- Production-ready error handling

---

**Created**: 2025-11-29
**Status**: ✅ Production Ready
