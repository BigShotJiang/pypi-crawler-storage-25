"""
Typeform Daily Sync Tool

Scheduled daily scan via Vercel cronjob to check for:
1. New form creations
2. Form updates (title, description, fields)
3. New responses since last sync

Designed to be called by Vercel cron jobs.
"""

import os
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
import uuid

from dotenv import load_dotenv

from connectors.supabase_client.db import get_custom_client
from connectors.typeform.forms import TypeformForms
from connectors.typeform.responses import TypeformResponses
from utils.custom_types import TypeformForm, TypeformField, TypeformResponse

load_dotenv()


class TypeformDailySyncTool:
    """Daily sync tool for form updates and new responses"""

    def __init__(self, api_key: Optional[str] = None):
        """Initialize daily sync tool.

        Args:
            api_key: Typeform personal access token. Falls back to
                     TYPEFORM_ACCESS_TOKEN env var if not provided.
        """
        self.aio_supabase_url = os.getenv("AIO_SUPABASE_URL")
        self.aio_supabase_service_role_key = os.getenv("AIO_SUPABASE_SERVICE_ROLE_KEY")

        if not self.aio_supabase_url or not self.aio_supabase_service_role_key:
            raise ValueError(
                "AIO_SUPABASE_URL and AIO_SUPABASE_SERVICE_ROLE_KEY environment variables must be set"
            )

        self.supabase_client: Client = get_custom_client(
            self.aio_supabase_url, self.aio_supabase_service_role_key
        )

        # H-3: pass the resolved key explicitly so the credential store is used
        # rather than always reading TYPEFORM_ACCESS_TOKEN from the environment.
        self.typeform_forms = TypeformForms(access_token=api_key)
        self.typeform_responses = TypeformResponses(access_token=api_key)

    async def run_daily_sync(self) -> Dict[str, Any]:
        """
        Main daily sync operation

        Returns:
            Dictionary with sync results
        """
        print("🔄 Starting daily Typeform sync...")
        print(f"⏰ Timestamp: {datetime.utcnow().isoformat()}")

        try:
            # Step 1: Check for new forms
            new_forms_result = await self._sync_new_forms()

            # Step 2: Check for form updates
            form_updates_result = await self._sync_form_updates()

            # Step 3: Check for new responses
            new_responses_result = await self._sync_new_responses()

            total_result = {
                "status": "success",
                "timestamp": datetime.utcnow().isoformat(),
                "new_forms": new_forms_result.get("count", 0),
                "updated_forms": form_updates_result.get("count", 0),
                "new_responses": new_responses_result.get("count", 0),
                "new_answers": new_responses_result.get("answers_count", 0),
                "details": {
                    "new_forms": new_forms_result,
                    "updated_forms": form_updates_result,
                    "new_responses": new_responses_result,
                },
            }

            print("✅ Daily sync completed successfully")
            return total_result

        except Exception as e:
            print(f"❌ Error in daily sync: {str(e)}")
            return {
                "status": "error",
                "timestamp": datetime.utcnow().isoformat(),
                "error": str(e),
            }

    async def _sync_new_forms(self) -> Dict[str, Any]:
        """
        Check for new forms created in Typeform

        Returns:
            Dictionary with new forms count and details
        """
        try:
            print("📥 Checking for new forms...")

            # Get all forms from Typeform
            forms_response = await self.typeform_forms.list_forms(page_size=200)
            typeform_forms = forms_response.get("items", [])

            if not typeform_forms:
                print("ℹ️ No forms found in Typeform")
                return {"count": 0, "forms": []}

            # Get existing forms from database
            existing_forms_response = (
                self.supabase_client.table("forms").select("slug").execute()
            )
            existing_slugs = {f.get("slug") for f in existing_forms_response.data}

            # Find new forms
            new_forms = []
            for form_summary in typeform_forms:
                form_id = form_summary.get("id")
                if form_id not in existing_slugs:
                    new_forms.append(form_id)

            if not new_forms:
                print("ℹ️ No new forms found")
                return {"count": 0, "forms": []}

            print(f"✅ Found {len(new_forms)} new forms")

            # Sync new forms
            synced_forms = []
            for form_id in new_forms:
                try:
                    form_data = await self.typeform_forms.get_form(form_id)
                    result = await self._sync_form_and_questions(form_data)
                    if result.get("form_db_id"):
                        synced_forms.append(
                            {
                                "typeform_id": form_id,
                                "db_id": result.get("form_db_id"),
                                "questions": result.get("questions_synced", 0),
                            }
                        )
                        print(f"   ✅ Synced new form: {form_id}")
                except Exception as e:
                    print(f"   ❌ Error syncing form {form_id}: {str(e)}")

            return {"count": len(synced_forms), "forms": synced_forms}

        except Exception as e:
            print(f"❌ Error checking for new forms: {str(e)}")
            return {"count": 0, "forms": [], "error": str(e)}

    async def _sync_form_updates(self) -> Dict[str, Any]:
        """
        Check for updates to existing forms

        Returns:
            Dictionary with updated forms count and details
        """
        try:
            print("📥 Checking for form updates...")

            # Get all forms from database
            db_forms_response = (
                self.supabase_client.table("forms")
                .select("id, slug, updated_at, settings")
                .execute()
            )
            db_forms = {f.get("slug"): f for f in db_forms_response.data}

            if not db_forms:
                print("ℹ️ No forms in database")
                return {"count": 0, "forms": []}

            # Check each form for updates
            updated_forms = []
            for typeform_id, db_form in db_forms.items():
                try:
                    # Fetch form from Typeform
                    form_data = await self.typeform_forms.get_form(typeform_id)
                    typeform_updated_at = form_data.get("last_updated_at") or form_data.get("updated_at")

                    # Compare timestamps
                    db_updated_at = db_form.get("updated_at")

                    if typeform_updated_at and db_updated_at:
                        if typeform_updated_at > db_updated_at:
                            # Form was updated
                            result = await self._update_form_and_questions(
                                db_form.get("id"), form_data
                            )
                            updated_forms.append(
                                {
                                    "typeform_id": typeform_id,
                                    "db_id": db_form.get("id"),
                                    "questions_updated": result.get("questions_updated", 0),
                                }
                            )
                            print(f"   ✅ Updated form: {typeform_id}")

                except Exception as e:
                    print(f"   ⚠️ Error checking form {typeform_id}: {str(e)}")

            if updated_forms:
                print(f"✅ Found {len(updated_forms)} updated forms")
            else:
                print("ℹ️ No form updates found")

            return {"count": len(updated_forms), "forms": updated_forms}

        except Exception as e:
            print(f"❌ Error checking for form updates: {str(e)}")
            return {"count": 0, "forms": [], "error": str(e)}

    async def _sync_new_responses(self) -> Dict[str, Any]:
        """
        Check for new responses since last sync

        Returns:
            Dictionary with new responses count and details
        """
        try:
            print("📥 Checking for new responses...")

            # Get all forms from database
            db_forms_response = (
                self.supabase_client.table("forms")
                .select("id, slug, updated_at")
                .execute()
            )

            if not db_forms_response.data:
                print("ℹ️ No forms in database")
                return {"count": 0, "responses": [], "answers_count": 0}

            total_responses = 0
            total_answers = 0
            synced_responses = []

            # Check each form for new responses
            for db_form in db_forms_response.data:
                form_db_id = db_form.get("id")
                typeform_id = db_form.get("slug")
                last_sync = db_form.get("updated_at")

                try:
                    # Fetch responses since last sync
                    responses_data = await self.typeform_responses.get_responses(
                        typeform_id, page_size=100, since=last_sync
                    )
                    responses_list = responses_data.get("items", [])

                    if not responses_list:
                        continue

                    # Sync each response
                    for response in responses_list:
                        try:
                            result = await self._sync_response(form_db_id, response)
                            if result:
                                total_responses += 1
                                total_answers += result.get("answers_count", 0)
                                synced_responses.append(
                                    {
                                        "form_id": typeform_id,
                                        "response_id": response.get("response_id"),
                                        "answers": result.get("answers_count", 0),
                                    }
                                )
                        except Exception as e:
                            print(f"   ⚠️ Error syncing response: {str(e)}")

                except Exception as e:
                    print(f"   ⚠️ Error fetching responses for {typeform_id}: {str(e)}")

            if total_responses > 0:
                print(f"✅ Synced {total_responses} new responses with {total_answers} answers")
            else:
                print("ℹ️ No new responses found")

            return {
                "count": total_responses,
                "answers_count": total_answers,
                "responses": synced_responses,
            }

        except Exception as e:
            print(f"❌ Error checking for new responses: {str(e)}")
            return {"count": 0, "answers_count": 0, "responses": [], "error": str(e)}

    async def _sync_form_and_questions(
        self, form_data: TypeformForm
    ) -> Dict[str, Any]:
        """
        Sync new form and its questions

        Args:
            form_data: Form data from Typeform API

        Returns:
            Dictionary with sync results
        """
        try:
            form_id = form_data.get("id")
            form_title = form_data.get("title", "Untitled Form")
            form_type = form_data.get("type", "form")
            created_at = form_data.get("created_at")
            updated_at = form_data.get("last_updated_at") or form_data.get("updated_at")

            # Map form type
            form_type_map = {
                "quiz": "assessment",
                "survey": "survey",
                "form": "feedback",
            }
            db_form_type = form_type_map.get(form_type, "feedback")

            # Generate UUID
            form_db_id = str(uuid.uuid4())

            # Prepare form data
            form_insert_data = {
                "id": form_db_id,
                "name": form_title,
                "slug": form_id,
                "description": form_data.get("description"),
                "form_type": db_form_type,
                "status": "published",
                "instructor_id": "00000000-0000-0000-0000-000000000000",
                "submission_count": 0,
                "created_at": created_at,
                "updated_at": updated_at,
                "allow_anonymous": True,
                "show_progress_bar": True,
                "randomize_questions": False,
                "settings": {
                    "typeform_id": form_id,
                    "typeform_type": form_type,
                    "welcome_screens": form_data.get("welcome_screens", []),
                    "thank_you_screens": form_data.get("thank_you_screens", []),
                },
            }

            # Insert form
            form_response = (
                self.supabase_client.table("forms").insert(form_insert_data).execute()
            )

            if not form_response.data:
                raise Exception("Failed to insert form")

            # Sync questions
            fields = form_data.get("fields", [])
            questions_synced = 0

            for display_order, field in enumerate(fields, 1):
                try:
                    question_result = await self._sync_question(
                        form_db_id, field, display_order
                    )
                    if question_result:
                        questions_synced += 1
                except Exception as e:
                    print(f"   ⚠️ Error syncing question: {str(e)}")

            return {
                "form_db_id": form_db_id,
                "questions_synced": questions_synced,
            }

        except Exception as e:
            print(f"❌ Error syncing form: {str(e)}")
            return {"form_db_id": None, "questions_synced": 0}

    async def _update_form_and_questions(
        self, form_db_id: str, form_data: TypeformForm
    ) -> Dict[str, Any]:
        """
        Update existing form and questions

        Args:
            form_db_id: Database form ID
            form_data: Updated form data

        Returns:
            Dictionary with update results
        """
        try:
            form_title = form_data.get("title", "Untitled Form")
            updated_at = form_data.get("last_updated_at") or form_data.get("updated_at")

            # Update form
            update_data = {
                "name": form_title,
                "updated_at": updated_at,
            }

            self.supabase_client.table("forms").update(update_data).eq(
                "id", form_db_id
            ).execute()

            # Delete old questions
            self.supabase_client.table("form_questions").delete().eq(
                "form_id", form_db_id
            ).execute()

            # Sync new questions
            fields = form_data.get("fields", [])
            questions_updated = 0

            for display_order, field in enumerate(fields, 1):
                try:
                    question_result = await self._sync_question(
                        form_db_id, field, display_order
                    )
                    if question_result:
                        questions_updated += 1
                except Exception as e:
                    print(f"   ⚠️ Error syncing question: {str(e)}")

            return {"questions_updated": questions_updated}

        except Exception as e:
            print(f"❌ Error updating form: {str(e)}")
            return {"questions_updated": 0}

    async def _sync_question(
        self, form_db_id: str, field: TypeformField, display_order: int
    ) -> bool:
        """Sync a single question"""
        try:
            field_type = field.get("type")
            field_title = field.get("title", "Untitled Question")

            field_type_map = {
                "short_text": "text",
                "long_text": "textarea",
                "email": "email",
                "number": "number",
                "dropdown": "multiple_choice",
                "multiple_choice": "multiple_choice",
                "nps": "rating",
                "opinion_scale": "rating",
                "rating": "rating",
                "yes_no": "checkbox",
                "date": "date",
                "time": "text",
                "phone_number": "text",
                "file_upload": "file_upload",
                "contact_info": "text",
                "statement": "text",
            }

            db_question_type = field_type_map.get(field_type, "text")

            validations = field.get("validations", {})
            validation_rules = {
                "required": validations.get("required", False),
                "typeform_type": field_type,
                "typeform_ref": field.get("ref"),
            }

            # Extract options for choice fields
            options = None
            properties = field.get("properties", {})
            if properties.get("choices"):
                options = {
                    "choices": [
                        {"id": c.get("id"), "label": c.get("label"), "ref": c.get("ref")}
                        for c in properties.get("choices", [])
                    ]
                }

            # Extract contact info subfields
            subfields = properties.get("fields", [])
            if subfields:
                options = {
                    "subfields": [
                        {
                            "id": f.get("id"),
                            "ref": f.get("ref"),
                            "title": f.get("title"),
                            "subfield_key": f.get("subfield_key"),
                            "type": f.get("type"),
                        }
                        for f in subfields
                    ]
                }

            question_insert_data = {
                "id": str(uuid.uuid4()),
                "form_id": form_db_id,
                "question_text": field_title,
                "question_type": db_question_type,
                "display_order": display_order,
                "is_required": validations.get("required", False),
                "help_text": field.get("properties", {}).get("description"),
                "placeholder_text": None,
                "validation_rules": validation_rules,
                "options": options,
                "default_value": None,
            }

            question_response = (
                self.supabase_client.table("form_questions")
                .insert(question_insert_data)
                .execute()
            )

            if not question_response.data:
                return False

            # Sync subfields as separate questions (for contact_info fields)
            if subfields:
                for subfield_order, subfield in enumerate(subfields, 1):
                    await self._sync_subfield_question(
                        form_db_id, subfield, display_order * 100 + subfield_order
                    )

            return True

        except Exception as e:
            print(f"❌ Error syncing question: {str(e)}")
            return False

    async def _sync_subfield_question(
        self, form_db_id: str, subfield: Dict[str, Any], display_order: int
    ) -> bool:
        """Sync a contact_info subfield as a separate question entry"""
        try:
            subfield_type = subfield.get("type", "short_text")

            type_map = {
                "short_text": "text",
                "email": "email",
                "phone_number": "text",
            }
            db_question_type = type_map.get(subfield_type, "text")

            validations = subfield.get("validations", {})
            validation_rules = {
                "required": validations.get("required", False),
                "typeform_type": subfield_type,
                "typeform_ref": subfield.get("ref"),
                "is_subfield": True,
                "subfield_key": subfield.get("subfield_key"),
            }

            question_insert_data = {
                "id": str(uuid.uuid4()),
                "form_id": form_db_id,
                "question_text": subfield.get("title", "Untitled"),
                "question_type": db_question_type,
                "display_order": display_order,
                "is_required": validations.get("required", False),
                "help_text": None,
                "placeholder_text": None,
                "validation_rules": validation_rules,
                "options": None,
                "default_value": None,
            }

            question_response = (
                self.supabase_client.table("form_questions")
                .insert(question_insert_data)
                .execute()
            )

            return bool(question_response.data)

        except Exception as e:
            print(f"❌ Error syncing subfield question: {str(e)}")
            return False

    async def _sync_response(
        self, form_db_id: str, response: TypeformResponse
    ) -> Optional[Dict[str, Any]]:
        """Sync a single response"""
        try:
            response_id = response.get("response_id")
            submitted_at = response.get("submitted_at")
            response_type = response.get("response_type", "completed")

            # Extract submitter email and name from answers
            submitter_email = "anonymous@typeform.local"
            submitter_name = None
            answers = response.get("answers", [])
            
            for answer in answers:
                field_type = answer.get("field", {}).get("type")
                answer_type = answer.get("type")
                
                # Email field (including contact_info subfield)
                if field_type == "email" or answer_type == "email":
                    email_value = answer.get("email") or answer.get("text")
                    if email_value:
                        submitter_email = email_value
                
                # Try to get name from short_text fields
                if field_type == "short_text" and not submitter_name:
                    if answer.get("text"):
                        submitter_name = answer.get("text")

            # Prepare submission data (matching form_submissions table schema)
            metadata = response.get("metadata", {})
            submission_insert_data = {
                "id": str(uuid.uuid4()),
                "form_id": form_db_id,
                "submitter_email": submitter_email,
                "submitter_name": submitter_name,
                "status": "submitted" if response_type == "completed" else "draft",
                "submitted_at": submitted_at,
                "ip_address": metadata.get("ip_address"),
                "user_agent": metadata.get("user_agent"),
            }

            submission_response = (
                self.supabase_client.table("form_submissions")
                .insert(submission_insert_data)
                .execute()
            )

            if not submission_response.data:
                raise Exception("Failed to insert submission")

            submission_db_id = submission_response.data[0].get("id")

            answers_count = 0
            for answer in answers:
                try:
                    answer_result = await self._sync_answer(
                        submission_db_id, form_db_id, answer
                    )
                    if answer_result:
                        answers_count += 1
                except Exception as e:
                    print(f"   ⚠️ Error syncing answer: {str(e)}")

            return {"submission_id": submission_db_id, "answers_count": answers_count}

        except Exception as e:
            print(f"❌ Error syncing response: {str(e)}")
            return None

    async def _sync_answer(
        self, submission_db_id: str, form_db_id: str, answer
    ) -> bool:
        """Sync a single answer"""
        try:
            answer_type = answer.get("type")

            answer_value = None
            if answer_type == "text":
                answer_value = answer.get("text")
            elif answer_type == "email":
                answer_value = answer.get("email") or answer.get("text")
            elif answer_type == "number":
                answer_value = str(answer.get("number"))
            elif answer_type == "choice":
                answer_value = answer.get("choice", {}).get("label")
            elif answer_type == "choices":
                choices = answer.get("choices", {})
                # Handle both list format and dict format with labels array
                if isinstance(choices, list):
                    answer_value = "; ".join(c.get("label", "") for c in choices)
                elif isinstance(choices, dict) and choices.get("labels"):
                    answer_value = "; ".join(choices.get("labels", []))
            elif answer_type == "date":
                answer_value = answer.get("date")
            elif answer_type == "time":
                answer_value = answer.get("time")
            elif answer_type == "boolean":
                answer_value = str(answer.get("boolean"))
            elif answer_type == "file_url":
                answer_value = answer.get("file_url")
            elif answer_type == "phone_number":
                answer_value = answer.get("phone_number") or answer.get("text")
            else:
                answer_value = str(answer.get(answer_type, ""))

            if not answer_value:
                return False

            questions_response = (
                self.supabase_client.table("form_questions")
                .select("id")
                .eq("form_id", form_db_id)
                .filter(
                    "validation_rules->>typeform_ref",
                    "eq",
                    answer.get("field", {}).get("ref"),
                )
                .execute()
            )

            if not questions_response.data:
                return False

            question_db_id = questions_response.data[0].get("id")

            answer_insert_data = {
                "id": str(uuid.uuid4()),
                "submission_id": submission_db_id,
                "question_id": question_db_id,
                "answer_value": answer_value,
                "answer_type": answer_type,
                "is_valid": True,
            }

            answer_response = (
                self.supabase_client.table("form_submission_answers")
                .insert(answer_insert_data)
                .execute()
            )

            return bool(answer_response.data)

        except Exception as e:
            print(f"❌ Error syncing answer: {str(e)}")
            return False


__all__ = ["TypeformDailySyncTool"]
