"""
Audit Log CRUD Operations
Database operations for activity_audit_log table using Supabase SDK
"""

from __future__ import annotations
from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta
from pydantic import BaseModel

# Pydantic models
class AuditLogEntry(BaseModel):
    id: int
    table_name: str
    operation: str
    record_id: Optional[int]
    old_data: Optional[dict]
    new_data: Optional[dict]
    changed_by_user_id: Optional[str]
    changed_by_email: Optional[str]
    changed_at: str
    ip_address: Optional[str]
    user_agent: Optional[str]

class AuditLogList(BaseModel):
    entries: List[AuditLogEntry]
    total: int

class AuditLogFilters(BaseModel):
    table_name: Optional[str] = None
    operation: Optional[str] = None
    record_id: Optional[int] = None
    changed_by_email: Optional[str] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None

# CRUD operations
class AuditLogCRUD:
    def __init__(self, supabase: Client):
        self.supabase = supabase

    async def get_all(
        self,
        skip: int = 0,
        limit: int = 100,
        filters: Optional[AuditLogFilters] = None
    ) -> AuditLogList:
        """Get all audit log entries with optional filtering"""
        try:
            query = self.supabase.table("activity_audit_log").select("*", count="exact")
            
            if filters:
                if filters.table_name:
                    query = query.eq("table_name", filters.table_name)
                if filters.operation:
                    query = query.eq("operation", filters.operation)
                if filters.record_id:
                    query = query.eq("record_id", filters.record_id)
                if filters.changed_by_email:
                    query = query.eq("changed_by_email", filters.changed_by_email)
                if filters.start_date:
                    query = query.gte("changed_at", filters.start_date.isoformat())
                if filters.end_date:
                    query = query.lte("changed_at", filters.end_date.isoformat())
            
            response = (
                query.order("changed_at", desc=True)
                .limit(limit)
                .offset(skip)
                .execute()
            )
            
            data = response.data or []
            return AuditLogList(
                entries=[AuditLogEntry(**item) for item in data],
                total=response.count or 0
            )
        except Exception as e:
            raise ValueError(f"Error getting audit logs: {str(e)}")

    async def get_by_id(self, log_id: int) -> Optional[AuditLogEntry]:
        """Get audit log entry by ID"""
        try:
            response = (
                self.supabase.table("activity_audit_log")
                .select("*")
                .eq("id", log_id)
                .limit(1)
                .execute()
            )
            
            if not response.data:
                return None
                
            return AuditLogEntry(**response.data[0])
        except Exception as e:
            raise ValueError(f"Error getting audit log entry: {str(e)}")

    async def get_by_record(
        self, 
        table_name: str, 
        record_id: int,
        skip: int = 0,
        limit: int = 50
    ) -> AuditLogList:
        """Get audit log entries for a specific record"""
        try:
            response = (
                self.supabase.table("activity_audit_log")
                .select("*", count="exact")
                .eq("table_name", table_name)
                .eq("record_id", record_id)
                .order("changed_at", desc=True)
                .limit(limit)
                .offset(skip)
                .execute()
            )
            
            data = response.data or []
            return AuditLogList(
                entries=[AuditLogEntry(**item) for item in data],
                total=response.count or 0
            )
        except Exception as e:
            raise ValueError(f"Error getting audit log entries for record: {str(e)}")

    async def get_recent_changes(
        self, 
        hours: int = 24,
        table_name: Optional[str] = None
    ) -> List[AuditLogEntry]:
        """Get recent changes within specified hours"""
        try:
            from datetime import datetime, timedelta
            cutoff_time = (datetime.utcnow() - timedelta(hours=hours)).isoformat()
            
            query = self.supabase.table("activity_audit_log").select("*").gte("changed_at", cutoff_time)
            
            if table_name:
                query = query.eq("table_name", table_name)
            
            response = query.order("changed_at", desc=True).limit(100).execute()
            
            return [AuditLogEntry(**item) for item in response.data or []]
        except Exception as e:
            raise ValueError(f"Error getting recent changes: {str(e)}")

    async def get_user_activity(
        self, 
        user_email: str,
        skip: int = 0,
        limit: int = 100
    ) -> AuditLogList:
        """Get audit log entries for a specific user"""
        try:
            response = (
                self.supabase.table("activity_audit_log")
                .select("*", count="exact")
                .eq("changed_by_email", user_email)
                .order("changed_at", desc=True)
                .limit(limit)
                .offset(skip)
                .execute()
            )
            
            data = response.data or []
            return AuditLogList(
                entries=[AuditLogEntry(**item) for item in data],
                total=response.count or 0
            )
        except Exception as e:
            raise ValueError(f"Error getting user activity: {str(e)}")

    async def get_operation_summary(
        self, 
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None
    ) -> Dict[str, Any]:
        """Get summary of operations by type"""
        try:
            query = self.supabase.table("activity_audit_log").select("operation, changed_by_email, table_name")
            
            if start_date:
                query = query.gte("changed_at", start_date.isoformat())
            if end_date:
                query = query.lte("changed_at", end_date.isoformat())
            
            response = query.execute()
            data = response.data or []
            
            # Aggregate data manually
            summary = {}
            for item in data:
                op = item.get("operation")
                if op not in summary:
                    summary[op] = {
                        "count": 0,
                        "unique_users": set(),
                        "affected_tables": set()
                    }
                summary[op]["count"] += 1
                if item.get("changed_by_email"):
                    summary[op]["unique_users"].add(item["changed_by_email"])
                if item.get("table_name"):
                    summary[op]["affected_tables"].add(item["table_name"])
            
            # Convert sets to counts
            results = [
                {
                    "operation": op,
                    "count": stats["count"],
                    "unique_users": len(stats["unique_users"]),
                    "affected_tables": len(stats["affected_tables"])
                }
                for op, stats in summary.items()
            ]
            results.sort(key=lambda x: x["count"], reverse=True)
            
            return {
                "operations": results,
                "total_operations": sum(result["count"] for result in results)
            }
        except Exception as e:
            raise ValueError(f"Error getting operation summary: {str(e)}")

    async def get_table_activity_summary(
        self, 
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None
    ) -> Dict[str, Any]:
        """Get summary of activity by table"""
        try:
            query = self.supabase.table("activity_audit_log").select("table_name, operation, changed_by_email")
            
            if start_date:
                query = query.gte("changed_at", start_date.isoformat())
            if end_date:
                query = query.lte("changed_at", end_date.isoformat())
            
            response = query.execute()
            data = response.data or []
            
            # Aggregate by table
            table_summary = {}
            for item in data:
                table = item.get("table_name")
                if table not in table_summary:
                    table_summary[table] = {
                        "total_changes": 0,
                        "unique_users": set(),
                        "inserts": 0,
                        "updates": 0,
                        "deletes": 0
                    }
                table_summary[table]["total_changes"] += 1
                if item.get("changed_by_email"):
                    table_summary[table]["unique_users"].add(item["changed_by_email"])
                op = item.get("operation")
                if op == "INSERT":
                    table_summary[table]["inserts"] += 1
                elif op == "UPDATE":
                    table_summary[table]["updates"] += 1
                elif op == "DELETE":
                    table_summary[table]["deletes"] += 1
            
            tables = [
                {
                    "table_name": table,
                    "total_changes": stats["total_changes"],
                    "unique_users": len(stats["unique_users"]),
                    "inserts": stats["inserts"],
                    "updates": stats["updates"],
                    "deletes": stats["deletes"]
                }
                for table, stats in table_summary.items()
            ]
            tables.sort(key=lambda x: x["total_changes"], reverse=True)
            
            return {
                "tables": tables,
                "total_changes": sum(t["total_changes"] for t in tables)
            }
        except Exception as e:
            raise ValueError(f"Error getting table activity summary: {str(e)}")

    async def get_suspicious_activity(
        self, 
        hours: int = 24,
        threshold_changes: int = 50
    ) -> List[Dict[str, Any]]:
        """Detect suspicious activity patterns"""
        try:
            from datetime import datetime, timedelta
            cutoff_time = (datetime.utcnow() - timedelta(hours=hours)).isoformat()
            
            response = (
                self.supabase.table("activity_audit_log")
                .select("changed_by_email, table_name, changed_at")
                .gte("changed_at", cutoff_time)
                .not_.is_("changed_by_email", "null")
                .execute()
            )
            
            data = response.data or []
            
            # Aggregate by user
            user_activity = {}
            for item in data:
                email = item.get("changed_by_email")
                if not email:
                    continue
                if email not in user_activity:
                    user_activity[email] = {
                        "changes": [],
                        "tables": set()
                    }
                user_activity[email]["changes"].append(item.get("changed_at"))
                if item.get("table_name"):
                    user_activity[email]["tables"].add(item.get("table_name"))
            
            # Filter by threshold and calculate metrics
            suspicious = []
            for email, activity in user_activity.items():
                change_count = len(activity["changes"])
                if change_count > threshold_changes:
                    changes_sorted = sorted(activity["changes"])
                    suspicious.append({
                        "changed_by_email": email,
                        "change_count": change_count,
                        "tables_affected": len(activity["tables"]),
                        "first_change": changes_sorted[0],
                        "last_change": changes_sorted[-1]
                    })
            
            suspicious.sort(key=lambda x: x["change_count"], reverse=True)
            return suspicious
        except Exception as e:
            raise ValueError(f"Error detecting suspicious activity: {str(e)}")

    async def cleanup_old_logs(self, days_to_keep: int = 365) -> int:
        """Clean up old audit logs (admin only)"""
        try:
            from datetime import datetime, timedelta
            cutoff_date = (datetime.utcnow() - timedelta(days=days_to_keep)).isoformat()
            
            response = (
                self.supabase.table("activity_audit_log")
                .delete()
                .lt("changed_at", cutoff_date)
                .execute()
            )
            
            return len(response.data or [])
        except Exception as e:
            raise ValueError(f"Failed to cleanup old audit logs: {str(e)}"
            )

    async def export_audit_logs(
        self,
        filters: Optional[AuditLogFilters] = None,
        format: str = "json"
    ) -> List[Dict[str, Any]]:
        """Export audit logs for analysis"""
        try:
            query = self.supabase.table("activity_audit_log").select("*")
            
            if filters:
                if filters.table_name:
                    query = query.eq("table_name", filters.table_name)
                if filters.operation:
                    query = query.eq("operation", filters.operation)
                if filters.record_id:
                    query = query.eq("record_id", filters.record_id)
                if filters.changed_by_email:
                    query = query.eq("changed_by_email", filters.changed_by_email)
                if filters.start_date:
                    query = query.gte("changed_at", filters.start_date.isoformat())
                if filters.end_date:
                    query = query.lte("changed_at", filters.end_date.isoformat())
            
            response = query.order("changed_at", desc=True).execute()
            
            return [dict(item) for item in response.data or []]
        except Exception as e:
            raise ValueError(f"Error exporting audit logs: {str(e)}")
