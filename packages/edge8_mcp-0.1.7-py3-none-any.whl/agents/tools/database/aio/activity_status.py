"""
Activity Status CRUD Operations
Handles operations for student activity status views and calculations
"""

from __future__ import annotations
from typing import List, Optional, Dict, Any
from pydantic import BaseModel

# Pydantic models
class StudentActivityStatus(BaseModel):
    student_id: int
    student_name: str
    student_email: str
    avatar_url: Optional[str]
    profile_activities: Dict[str, Any]
    community_activities: Dict[str, Any]
    mission_activities: Dict[str, Any]
    profile_points: int
    community_points: int
    mission_points: int
    total_calculated_points: int
    logged_activities: Dict[str, Any]
    activity_summary: Dict[str, Any]
    calculated_at: str

class ActivityStatus(BaseModel):
    activity_code: str
    activity_name: str
    points: int
    completed: bool
    count: int
    points_earned: int

class LeaderboardEntry(BaseModel):
    student_id: int
    student_name: str
    student_email: str
    avatar_url: Optional[str]
    total_calculated_points: int
    profile_points: int
    community_points: int
    mission_points: int
    activities_completed: int
    profile_completion_percentage: float
    rank: int
    calculated_at: str

class LeaderboardResponse(BaseModel):
    entries: List[LeaderboardEntry]
    total: int

# Database Operations
class ActivityStatusCRUD:
    def __init__(self, supabase: Client):
        self.supabase = supabase

    async def get_student_activity_status(self, student_id: int) -> Optional[StudentActivityStatus]:
        """Get comprehensive activity status for a specific student using the database view"""
        try:
            response = (
                self.supabase.table("student_activity_status_complete")
                .select("*")
                .eq("student_id", student_id)
                .limit(1)
                .execute()
            )
            
            if not response.data:
                return None
            
            result = response.data[0]
            return StudentActivityStatus(**result)
        except Exception as e:
            raise ValueError(f"Error getting student activity status: {str(e)}")

    async def get_student_activity_points(self, student_id: int) -> List[ActivityStatus]:
        """Get detailed activity points breakdown for a student using RPC function"""
        try:
            response = self.supabase.rpc("calculate_student_activity_points", {
                "p_student_id": student_id
            }).execute()
            
            if not response.data:
                return []
            
            return [ActivityStatus(**result) for result in response.data]
        except Exception as e:
            raise ValueError(f"Failed to get student activity points: {str(e)}")

    async def get_leaderboard(
        self,
        skip: int = 0,
        limit: int = 50,
        min_points: Optional[int] = None
    ) -> LeaderboardResponse:
        """Get student leaderboard using the database view"""
        try:
            query = self.supabase.table("student_leaderboard").select("*", count="exact")
            
            if min_points:
                query = query.gte("total_calculated_points", min_points)
            
            response = (
                query.order("rank", desc=False)
                .limit(limit)
                .offset(skip)
                .execute()
            )
            
            data = response.data or []
            return LeaderboardResponse(
                entries=[LeaderboardEntry(**item) for item in data],
                total=response.count or 0
            )
        except Exception as e:
            raise ValueError(f"Error getting leaderboard: {str(e)}")

    async def get_top_students(self, limit: int = 10) -> List[LeaderboardEntry]:
        """Get top N students by points"""
        try:
            response = (
                self.supabase.table("student_leaderboard")
                .select("*")
                .order("rank", desc=False)
                .limit(limit)
                .execute()
            )
            
            return [LeaderboardEntry(**item) for item in response.data or []]
        except Exception as e:
            raise ValueError(f"Error getting top students: {str(e)}")

    async def get_student_rank(self, student_id: int) -> Optional[Dict[str, Any]]:
        """Get a student's rank and position on leaderboard"""
        try:
            response = (
                self.supabase.table("student_leaderboard")
                .select("rank, total_calculated_points, profile_points, community_points, mission_points, activities_completed, profile_completion_percentage")
                .eq("student_id", student_id)
                .limit(1)
                .execute()
            )
            
            if not response.data:
                return None
            
            return response.data[0]
        except Exception as e:
            raise ValueError(f"Error getting student rank: {str(e)}")

    async def get_activity_completion_stats(self) -> Dict[str, Any]:
        """Get overall activity completion statistics"""
        try:
            # Get all students from view
            response = self.supabase.table("student_activity_status_complete").select("total_calculated_points, profile_completion_percentage").execute()
            
            data = response.data or []
            total_students = len(data)
            active_students = sum(1 for item in data if item.get("total_calculated_points", 0) > 0)
            avg_points = sum(item.get("total_calculated_points", 0) for item in data) / total_students if total_students > 0 else 0.0
            max_points = max((item.get("total_calculated_points", 0) for item in data), default=0)
            completed_profiles = sum(1 for item in data if item.get("profile_completion_percentage", 0) == 100)
            
            return {
                "total_students": total_students,
                "active_students": active_students,
                "avg_points": float(avg_points),
                "max_points": max_points,
                "completed_profiles": completed_profiles
            }
        except Exception as e:
            raise ValueError(f"Error getting activity completion stats: {str(e)}")

    async def get_category_stats(self) -> Dict[str, Any]:
        """Get statistics by activity category"""
        try:
            response = (
                self.supabase.table("student_activity_status_complete")
                .select("profile_points, community_points, mission_points")
                .gt("total_calculated_points", 0)
                .execute()
            )
            
            data = response.data or []
            count = len(data)
            
            if count == 0:
                return {
                    "profile": {"avg_points": 0.0, "total_points": 0},
                    "community": {"avg_points": 0.0, "total_points": 0},
                    "mission": {"avg_points": 0.0, "total_points": 0}
                }
            
            profile_total = sum(item.get("profile_points", 0) for item in data)
            community_total = sum(item.get("community_points", 0) for item in data)
            mission_total = sum(item.get("mission_points", 0) for item in data)
            
            return {
                "profile": {
                    "avg_points": float(profile_total / count),
                    "total_points": profile_total
                },
                "community": {
                    "avg_points": float(community_total / count),
                    "total_points": community_total
                },
                "mission": {
                    "avg_points": float(mission_total / count),
                    "total_points": mission_total
                }
            }
        except Exception as e:
            raise ValueError(f"Error getting category stats: {str(e)}")

    async def search_students_by_activity(
        self, 
        activity_code: str,
        completed_only: bool = True
    ) -> List[Dict[str, Any]]:
        """Search students who have completed a specific activity"""
        try:
            # Use student_activity_completions table directly
            response = (
                self.supabase.table("student_activity_completions")
                .select("student_id, activity_code, points_awarded, occurrence_count, completed_at")
                .eq("activity_code", activity_code)
                .order("completed_at", desc=True)
                .execute()
            )
            
            return [dict(item) for item in response.data or []]
        except Exception as e:
            raise ValueError(f"Error searching students by activity: {str(e)}")

    async def get_activity_participation_rate(self, activity_code: str) -> Dict[str, Any]:
        """Get participation rate for a specific activity"""
        try:
            # Get total students from view
            total_response = self.supabase.table("student_activity_status_complete").select("student_id", count="exact").execute()
            total_students = total_response.count or 0
            
            # Get completed students for this activity
            completed_response = (
                self.supabase.table("student_activity_completions")
                .select("student_id", count="exact")
                .eq("activity_code", activity_code)
                .execute()
            )
            completed_students = len(set(item["student_id"] for item in completed_response.data or []))
            
            participation_percentage = round((completed_students / total_students) * 100, 2) if total_students > 0 else 0.0
            
            return {
                "activity_code": activity_code,
                "total_students": total_students,
                "completed_students": completed_students,
                "participation_percentage": participation_percentage
            }
        except Exception as e:
            raise ValueError(f"Error getting activity participation rate: {str(e)}")
