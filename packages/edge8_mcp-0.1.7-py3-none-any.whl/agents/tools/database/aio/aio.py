"""
Async Database Tool Handler

Handles complex database operations including:
1. Fetching space and space group information
2. Querying lessons and space group members
3. Creating challenge submissions
4. Uploading files to Supabase storage
5. Updating submission records with file metadata
"""

import os
import sys
import json
import asyncio

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.data_conversion import (
    encode_base64_by_chunk,
    get_mime_type_from_filename,
    get_file_category,
    convert_to_pdf,
)
from utils.file_handling import sanitize_filename
from typing import Dict, Any, Optional, List, Tuple
import httpx
from pathlib import Path
from dotenv import load_dotenv

from connectors.supabase_client.db import get_custom_client
from connectors.supabase_client.storage import upload_to_storage
from connectors.openrouter.llm import OpenRouterMultimodalLLM, ChatMessage
from connectors.typeform.forms import TypeformForms
from connectors.typeform.responses import TypeformResponses
from utils.custom_types import TypeformForm, TypeformField, TypeformResponse, TypeformAnswer
from utils.mission_detection import detect_mission_space
from utils.data_conversion import EXTENSION_TO_MIME_TYPE
import uuid
from datetime import datetime

load_dotenv()


class DatabaseToolHandler:
    """Handle complex database operations with file uploads"""

    def __init__(self, cache_client=None):
        """Initialize Supabase client"""
        self.supabase_url = os.getenv("AIO_SUPABASE_URL")
        self.supabase_key = os.getenv("AIO_SUPABASE_SERVICE_ROLE_KEY")

        if not self.supabase_url or not self.supabase_key:
            raise ValueError(
                "AIO_SUPABASE_URL and AIO_SUPABASE_SERVICE_ROLE_KEY environment variables required"
            )

        self.supabase = get_custom_client(self.supabase_url, self.supabase_key)
        self.http_client = httpx.AsyncClient()

        # Add cache support
        self.cache = cache_client
        self._cache_ttls = {
            "series": 3600,       # 1 hour - static content
            "missions": 3600,     # 1 hour - static content
            "workshops": 3600,    # 1 hour - static content
            "briefs": 3600,       # 1 hour - static content
            "challenges": 3600,   # 1 hour - static content
            "guidelines": 3600,   # 1 hour - static content
            # Student data - semi-static, cache for 5 min
            "students": 300,
            "enrollments": 300,
            "student_progress": 300,
        }

    def _build_cache_key(self, resource: str, kwargs: Dict) -> str:
        """Build deterministic cache key from resource and query parameters

        Args:
            resource: Resource name
            kwargs: Query parameters

        Returns:
            Cache key string
        """
        # Filter out None values and resource param
        params = {k: v for k, v in kwargs.items() if k != "resource" and v is not None and v != ""}
        params_str = json.dumps(params, sort_keys=True)
        params_hash = hash(params_str)
        return f"aio:{resource}:{params_hash}"

    async def fetch_space_groups_with_filter(
        self, filter: Dict[str, Any]
    ) -> Optional[List[Dict[str, Any]]]:
        """
        Fetch space groups with filter

        Args:
            filter: Filter conditions

        Returns:
            List of space groups or None
        """
        try:
            supabase_filters = ",".join(
                [f"{key}.eq.{value}" for key, value in filter.items()]
            )
            response = (
                self.supabase.table("space_groups")
                .select("*")
                .or_(supabase_filters)
                .order("created_at", desc=False)
                .execute()
            )

            if not response.data or len(response.data) == 0:
                print(f"❌ No space groups found")
                return None

            space_groups = response.data
            print(f"✅ Found {len(space_groups)} space groups")
            return space_groups

        except Exception as e:
            print(f"❌ Error fetching space groups: {str(e)}")
            return None

    async def fetch_space_info(self, space_name: str) -> Optional[Dict[str, Any]]:
        """
        Fetch space and space group information

        Args:
            space_name: Name of the space

        Returns:
            Dictionary with space and space_group data or None
        """
        try:
            response = (
                self.supabase.table("spaces")
                .select("id, name, space_group_id, space_groups(id, name)")
                .eq("name", space_name)
                .execute()
            )

            if not response.data or len(response.data) == 0:
                print(f"❌ Space not found: {space_name}")
                return None

            space_data = response.data[0]
            print(f"✅ Found space: {space_data['name']} (id: {space_data['id']})")
            return space_data

        except Exception as e:
            print(f"❌ Error fetching space info: {str(e)}")
            return None

    async def fetch_challenge_by_uuid(self, challenge_uuid: str) -> Optional[Dict[str, Any]]:
        """
        Fetch challenge metadata directly by challenges.id (UUID).
        Used by the context_type="challenge" shortcut to skip detection.

        Returns a dict compatible with detect_challenge_from_text_or_files output,
        enriched with space_id, space_group_id, event_id, rubric_content, body_html.
        """
        try:
            response = (
                self.supabase.table("challenges")
                .select(
                    "id, name, type, status, mission_id, series_id, sequence_order, "
                    "micro_session_workshop_id, rubric_content, body_html, markdown, workbook_content"
                )
                .eq("id", challenge_uuid)
                .limit(1)
                .execute()
            )
            if not response.data:
                print(f"❌ Challenge not found by UUID: {challenge_uuid}")
                return None

            challenge = response.data[0]
            challenge_type = challenge.get("type", "mission_final")

            # Derive entity_type from challenge type
            entity_type_map = {
                "mission_final": "mission",
                "mission": "mission",
                "micro_session": "micro_session",
                "workshop": "workshop",
                "capstone": "capstone",
            }
            entity_type = entity_type_map.get(challenge_type, "mission")

            # Resolve space info (mission/workshop types have mission_id → spaces)
            space_id: Optional[int] = challenge.get("mission_id")
            space_group_id: Optional[int] = None
            entity_name: Optional[str] = None

            if space_id:
                space_resp = (
                    self.supabase.table("spaces")
                    .select("id, name, space_group_id")
                    .eq("id", space_id)
                    .limit(1)
                    .execute()
                )
                if space_resp.data:
                    entity_name = space_resp.data[0].get("name")
                    space_group_id = space_resp.data[0].get("space_group_id")

            # Resolve series info
            series_id: Optional[int] = challenge.get("series_id")
            series_name: Optional[str] = None
            if series_id:
                sg_resp = (
                    self.supabase.table("space_groups")
                    .select("id, name")
                    .eq("id", series_id)
                    .limit(1)
                    .execute()
                )
                if sg_resp.data:
                    series_name = sg_resp.data[0].get("name")
                    # For micro_sessions without a space, use series_id as space_group_id
                    if space_group_id is None:
                        space_group_id = series_id

            # Resolve event info (micro_session/workshop types)
            event_id: Optional[int] = challenge.get("micro_session_workshop_id")
            if event_id and not entity_name:
                event_resp = (
                    self.supabase.table("events")
                    .select("id, name")
                    .eq("id", event_id)
                    .limit(1)
                    .execute()
                )
                if event_resp.data:
                    entity_name = event_resp.data[0].get("name")

            result = {
                "challenge_id": challenge["id"],
                "challenge_uuid": challenge["id"],
                "challenge_name": challenge.get("name"),
                "challenge_type": challenge_type,
                "entity_type": entity_type,
                "entity_id": space_id or event_id,
                "entity_name": entity_name,
                "series_id": series_id,
                "series_name": series_name,
                "space_id": space_id,
                "space_group_id": space_group_id,
                "event_id": event_id,
                "mission_id": challenge.get("mission_id"),  # NEW
                "sequence_order": challenge.get("sequence_order"),  # NEW
                "rubric_content": challenge.get("rubric_content"),
                "body_html": challenge.get("body_html"),
                "markdown": challenge.get("markdown"),
                "workbook_content": challenge.get("workbook_content"),
            }
            print(f"✅ Fetched challenge by UUID: {challenge.get('name')} (type={challenge_type})")
            return result

        except Exception as e:
            print(f"❌ Error fetching challenge by UUID: {str(e)}")
            return None

    async def fetch_chat_room_info(self, chat_room_id: str) -> Optional[Dict[str, Any]]:
        """
        Fetch chat room information for a space group

        Args:
            chat_room_id: ID of the chat room

        Returns:
            Dictionary with chat room data or None
        """
        try:
            response = (
                self.supabase.table("spaces")
                .select("id, name")
                .eq("chat_room_id", chat_room_id)
                .execute()
            )

            if not response.data or len(response.data) == 0:
                # print(f"❌ Chat room not found for space group {space_group_id}")
                return None

            chat_room_data = response.data[0]
            print(
                f"✅ Found chat room: {chat_room_data['name']} (id: {chat_room_data['id']})"
            )
            return chat_room_data

        except Exception as e:
            print(f"❌ Error fetching chat room info: {str(e)}")
            return None

    async def fetch_lesson(self, space_id: int) -> Optional[List[Dict[str, Any]]]:
        """
        Fetch lesson with type='final_assignment' for a space

        Args:
            space_id: ID of the space

        Returns:
            Lesson data or None
        """
        try:
            response = (
                self.supabase.table("lessons")
                .select("*")
                .eq("space_id", space_id)
                .execute()
            )

            if not response.data or len(response.data) == 0:
                print(f"❌ No final_assignment lesson found for space {space_id}")
                return None

            lessons = response.data
            return lessons

        except Exception as e:
            print(f"❌ Error fetching lesson: {str(e)}")
            return None

    async def fetch_spaces_by_name_and_groups(
        self,
        space_name: str,
        space_group_ids: List[int],
        additional_filters: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """
        Fetch spaces by name filtered by space group IDs.
        
        Args:
            space_name: Name of the space to filter by
            space_group_ids: List of space group IDs to filter by
            additional_filters: Optional additional filter conditions (column: value)
            
        Returns:
            List of space dictionaries with id, name, space_group_id
        """
        spaces = []
        try:
            for sg_id in space_group_ids:
                query = self.supabase.table("spaces").select(
                    "id, name, space_group_id"
                ).eq("space_group_id", sg_id).eq("name", space_name)
                
                if additional_filters:
                    for col, val in additional_filters.items():
                        query = query.eq(col, val)
                
                response = query.execute()
                if response.data:
                    spaces.extend(response.data)
            
            print(f"✅ Found {len(spaces)} spaces with name='{space_name}'")
            return spaces
            
        except Exception as e:
            print(f"❌ Error fetching spaces by name: {str(e)}")
            return []
    
    async def fetch_space_by_name_and_group_id(
        self,
        space_name: str,
        space_group_id: int,
        additional_filters: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        try:
            query = self.supabase.table("spaces").select(
                "id, name, space_group_id"
            ).eq("space_group_id", space_group_id).eq("name", space_name)
                
            if additional_filters:
                for col, val in additional_filters.items():
                    query = query.eq(col, val)
                
            response = query.execute()
            return response.data[0]
            
        except Exception as e:
            print(f"❌ Error fetching spaces by name: {str(e)}")
            return []

    async def fetch_challenge_submission_posts(
        self, space_id: int
    ) -> List[Dict[str, Any]]:
        """
        Fetch posts with is_challenge_submission=TRUE for a space.
        
        Args:
            space_id: ID of the space
            
        Returns:
            List of post dictionaries
        """
        try:
            response = self.supabase.table("posts").select(
                "id, name, user_id, tiptap_body, body, is_challenge_submission"
            ).eq("space_id", space_id).eq("is_challenge_submission", True).execute()
            
            if not response.data:
                return []
            
            print(f"✅ Found {len(response.data)} challenge submission posts in space {space_id}")
            return response.data
            
        except Exception as e:
            print(f"❌ Error fetching challenge submission posts: {str(e)}")
            return []

    async def fetch_member_email_by_user_id(self, user_id: int) -> Optional[str]:
        """
        Fetch member email from space_group_members by user_id.
        
        Args:
            user_id: User ID to look up
            
        Returns:
            Email address or None
        """
        try:
            response = self.supabase.table("space_group_members").select(
                "author_email"
            ).eq("user_id", user_id).limit(1).execute()
            
            if not response.data:
                print(f"⚠️ No member found for user_id {user_id}")
                return None
            
            email = response.data[0].get("author_email")
            return email
            
        except Exception as e:
            print(f"❌ Error fetching member email: {str(e)}")
            return None

    async def fetch_existing_challenge_submission(
        self,
        student_id: Optional[int] = None,
        challenge_id: Optional[int] = None,
        *,
        email: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """
        Fetch existing challenge submission.

        Lookup paths (in priority order):
        1. student_id + challenge_id (legacy — lessons.id integer)
        2. email + challenge_id (UUID string — resolves student via members table)

        Returns:
            Most recent challenge submission record or None if not found
        """
        try:
            # Resolve student_id from email when not provided directly
            if student_id is None and email:
                member = self.supabase.table("members").select("id").eq("email", email).execute()
                if not member.data:
                    return None
                student_id = int(member.data[0]["id"])

            if student_id is None or challenge_id is None:
                return None

            # Determine filter column: UUID string → challenge_uuid, int → challenge_id
            col = "challenge_uuid" if isinstance(challenge_id, str) else "challenge_id"

            response = (
                self.supabase.table("challenge_submissions")
                .select("id, score, grade_status, status, graded_at, submitted_at")
                .eq("student_id", student_id)
                .eq(col, challenge_id)
                .order("submitted_at", desc=True)
                .limit(1)
                .execute()
            )

            if not response.data:
                return None

            submission = response.data[0]
            print(f"   ✅ Found existing submission: {submission.get('id')}")
            return submission

        except Exception as e:
            print(f"❌ Error fetching challenge submission: {str(e)}")
            return None

    async def fetch_rubric_from_supabase(
        self,
        challenge_uuid: Optional[str] = None,
        space_id: Optional[int] = None,
    ) -> Optional[str]:
        """
        Fetch rubric content from Supabase challenges table.

        Preferred: direct lookup by challenge_uuid (single query).
        Fallback: lookup by space_id (mission_id) with is_legacy priority.

        Args:
            challenge_uuid: challenges.id UUID for direct lookup
            space_id: spaces.id (mission_id) for legacy lookup

        Returns:
            Rubric content string or None
        """
        try:
            rubric_content = None

            # Preferred: direct lookup by challenge_uuid
            if challenge_uuid:
                response = (
                    self.supabase.table("challenges")
                    .select("rubric_content")
                    .eq("id", challenge_uuid)
                    .limit(1)
                    .execute()
                )
                if response.data:
                    rubric_content = response.data[0].get("rubric_content")
                if rubric_content:
                    print(f"✅ Fetched rubric by challenge_uuid: {challenge_uuid}")
                    return rubric_content

            # Fallback: lookup by space_id (mission_id)
            if space_id:
                response = (
                    self.supabase.table("challenges")
                    .select("rubric_content")
                    .eq("mission_id", space_id)
                    .eq("is_legacy", False)
                    .execute()
                )
                if response.data:
                    rubric_content = response.data[0].get("rubric_content")

                if not rubric_content:
                    print(f"⚠️ No non-legacy rubric found for mission {space_id}, falling back to legacy")
                    legacy_response = (
                        self.supabase.table("challenges")
                        .select("rubric_content")
                        .eq("mission_id", space_id)
                        .eq("is_legacy", True)
                        .execute()
                    )
                    if legacy_response.data:
                        rubric_content = legacy_response.data[0].get("rubric_content")

            if not rubric_content:
                print(f"❌ No rubric found (space_id={space_id}, challenge_uuid={challenge_uuid})")
                return None

            return rubric_content

        except Exception as e:
            print(f"❌ Error fetching rubric from Supabase: {str(e)}")
            return None

    async def fetch_space_group_member(
        self, email: str, space_group_id: int
    ) -> Optional[Dict[str, Any]]:
        """
        Fetch space group member by email and space_group_id

        Args:
            email: Member's email (author_email)
            space_group_id: ID of the space group

        Returns:
            Space group member data or None
        """
        try:
            response = (
                self.supabase.table("space_group_members")
                .select("*")
                .eq("author_email", email)
                .eq("space_group_id", space_group_id)
                .execute()
            )

            if not response.data or len(response.data) == 0:
                print(f"❌ Member not found: {email} in space_group {space_group_id}")
                response = (
                    self.supabase.table("space_group_members")
                    .select("*")
                    .eq("author_email", email)
                    .limit(1)
                    .execute()
                )

            member = response.data[0]
            print(
                f"✅ Found member: {member.get('author_name', 'Unknown')} (id: {member['id']})"
            )
            return member

        except Exception as e:
            print(f"❌ Error fetching space group member: {str(e)}")
            return None

    async def create_challenge_submission(
        self,
        student_id: int,
        challenge_id: Optional[int] = None,
        challenge_uuid: Optional[str] = None,
        micro_session_workshop_id: Optional[int] = None,
        student_inputs: Optional[Dict[str, Dict[str, str]]] = None,
        student_input_text: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """
        Create a new challenge submission record

        Args:
            student_id: ID of the student (space_group_members.id)
            challenge_id: ID of the challenge (lessons.id) — None for micro_sessions
            challenge_uuid: challenges.id UUID — set when challenge_metadata is available
            micro_session_workshop_id: events.id — set for micro_session/workshop types
            student_input_text: Raw text content from student's chat message

        Returns:
            Created submission record or None
        """
        try:
            submission_data: Dict[str, Any] = {"student_id": student_id}
            if challenge_id is not None:
                submission_data["challenge_id"] = challenge_id
            if challenge_uuid is not None:
                submission_data["challenge_uuid"] = challenge_uuid
            if micro_session_workshop_id is not None:
                submission_data["micro_session_workshop_id"] = micro_session_workshop_id
            if student_inputs is not None:
                # Store as single-element array per DB schema (student_inputs jsonb[])
                submission_data["student_inputs"] = [student_inputs]
            if student_input_text is not None:
                submission_data["student_input_text"] = student_input_text

            response = (
                self.supabase.table("challenge_submissions")
                .insert(submission_data)
                .execute()
            )

            if not response.data or len(response.data) == 0:
                print(f"❌ Failed to create challenge submission")
                return None

            submission = response.data[0]
            print(f"✅ Created challenge submission: {submission['id']}")
            return submission

        except Exception as e:
            print(f"❌ Error creating challenge submission: {str(e)}")
            return None

    async def download_file_bytes(self, url: str) -> Optional[bytes]:
        """
        Download file from URL

        Args:
            url: URL of the file

        Returns:
            File bytes or None
        """
        try:
            response = await self.http_client.get(url, timeout=300.0)
            response.raise_for_status()
            print(f"✅ Downloaded file: {url.split('/')[-1]} ({len(response.content)} bytes)")
            return response.content

        except Exception as e:
            print(f"❌ Error downloading file {url}: {str(e)}")
            return None

    async def upload_file_to_storage(
        self,
        file_bytes: bytes,
        file_name: str,
        space_group_id: int,
        space_id: int,
        student_id: int,
    ) -> Optional[Dict[str, Any]]:
        """
        Upload file to Supabase storage

        Args:
            file_bytes: File content as bytes
            file_name: Name of the file
            space_group_id: ID of the space group
            space_id: ID of the space

        Returns:
            Storage object metadata or None
        """
        try:
            # Construct storage path
            print(f"ℹ File name: {file_name}")
            ext = Path(file_name).suffix
            mime_type = EXTENSION_TO_MIME_TYPE.get(ext)
            
            print(f"ℹ Uploading {file_name} to Supabase...")

            # Sanitize file name to remove special characters that Supabase rejects
            sanitized_file_name = sanitize_filename(file_name)

            storage_path = (
                f"{space_group_id}/{space_id}/{student_id}/{sanitized_file_name}"
            )
            
            print(f"ℹ Storage path: {storage_path}")

            # Upload to storage
            response = upload_to_storage(
                self.supabase,
                mime_type,
                file_bytes,
                "submission_attachments",
                storage_path,
                60 * 60 * 24 * 365,
            )

            return {
                "id": response["id"],
                "path": response["path"],
                "url": response["url"],
                "size": len(file_bytes),
                "mime_type": mime_type,
            }

        except Exception as e:
            print(f"❌ Error uploading file to storage: {str(e)}")
            return None

    async def insert_submission_attachments(
        self, attachments: List[Dict[str, Any]]
    ) -> bool:
        """
        Insert challenge submission attachments

        Args:
            submission_id: ID of the submission
            attachments: List of attachment metadata

        Returns:
            True if successful, False otherwise
        """
        try:
            _response = (
                self.supabase.table("submission_attachments")
                .insert(attachments)
                .execute()
            )

            print(f"✅ Inserted {len(attachments)} attachment(s)")
            return True

        except Exception as e:
            print(f"❌ Error inserting attachments: {str(e)}")
            return False

    async def detect_challenge_from_text_or_files(
        self, user_message: str, file_names: List[str] = ['']
    ) -> Optional[Dict[str, Any]]:
        """
        Detect challenge from user message or file names across all entity types.
        
        Supports detection for:
        - Missions: "Mission 1 - Generative AI Essentials" or "Mission 1"
        - Workshops: "Workshop 2 - AI Officer Program" or "Workshop 2"
        - Micro Sessions: "Micro Session X" or similar
        - Capstones: "Capstone - Series Name"
        - Challenges: Can be within any of the above entities
        
        Args:
            user_message: User's text message
            file_names: List of file names
            
        Returns:
            Dict with challenge metadata or None:
            {
                "challenge_id": int,
                "challenge_name": str,
                "entity_type": str,  # "mission", "workshop", "micro_session", "capstone"
                "entity_id": int,
                "entity_name": str,
                "series_id": Optional[int],
                "series_name": Optional[str]
            }
        """
        try:
            # Try parsing user message first (without file names to avoid corruption)
            parsed = self._parse_challenge_input(user_message)
            
            # If user message didn't yield a result, try each filename individually
            if not parsed and file_names:
                for fname in file_names:
                    if fname:
                        parsed = self._parse_challenge_input(fname)
                        if parsed:
                            break
            
            if not parsed:
                print("⚠️ Could not parse challenge information from input")
                return None
            
            print(f"🔍 Parsed: entity_type={parsed['entity_type']}, challenge_name={parsed['challenge_name']}, series_name={parsed.get('series_name')}")
            
            # Query based on entity type
            challenge = await self._query_challenge_by_entity(parsed)
            
            if challenge:
                print(f"✅ Found challenge: {challenge['challenge_name']} in {challenge['entity_type']}")
                return challenge
            else:
                print(f"⚠️ No challenge found for parsed input")
                return None
            
        except Exception as e:
            print(f"❌ Error detecting challenge: {str(e)}")
            import traceback
            traceback.print_exc()
            return None
    
    def _parse_challenge_input(self, text: str) -> Optional[Dict[str, Any]]:
        """
        Parse entity type, challenge name, and optional series name from text.

        Expected formats:
        - "[Challenge Name] - [Entity Name] - [Series Name]"
        - "[Challenge Name] - [Entity Name]"
        - "[Entity Type] [Number] - [Series Name]"
        - "[Entity Type] [Number]"
        - "Capstone - [Series Name]"

        Args:
            text: Input text to parse

        Returns:
            Dict with parsed information or None
        """
        import re

        text = text.strip()

        # Entity type patterns
        entity_patterns = {
            'mission': r'(?:mission|Mission)\s*(\d+)',
            'workshop': r'(?:workshop|Workshop)\s*(\d+)',
            'micro_session': r'(?:micro\s*session|Micro\s*Session)\s*(\d+)',
            'capstone': r'(?:capstone|Capstone)'
        }

        # Strip file extensions and trailing parentheticals (e.g. "(2).pdf")
        # so filenames like "Mission 1 Final Challenge.pdf" become parseable text.
        cleaned_text = re.sub(r'\s*\(\d+\)\s*', ' ', text)  # remove "(2)" etc.
        cleaned_text = re.sub(
            r'\.(pdf|zip|txt|py|js|html|css|json|md|docx|xlsx|pptx)$',
            '', cleaned_text, flags=re.IGNORECASE
        ).strip()

        # Try to match entity type first using a more flexible approach
        matched_entity = None
        entity_number = None

        # First, try to match specific entity types with numbers (Mission 1, Workshop 2)
        for entity_type, pattern in entity_patterns.items():
            if entity_type != 'capstone':  # Capstone is handled differently
                match = re.search(pattern, cleaned_text, re.IGNORECASE)
                if match:
                    matched_entity = entity_type
                    entity_number = match.group(1) if match.groups() else None
                    break

        # If no numbered entity found, check for hyphenated formats or standalone capstone
        if not matched_entity:
            parts = [p.strip() for p in cleaned_text.split('-')]

            # Case: "Challenge Name - Entity Name - Series Name" or "Entity Name - Series Name"
            if len(parts) >= 2:
                # Check for Capstone specifically in any part
                for part in parts:
                    if re.search(entity_patterns['capstone'], part, re.IGNORECASE):
                        matched_entity = 'capstone'
                        break

                if matched_entity == 'capstone':
                    # If capstone is detected, assume format "[Challenge Name] - Capstone - [Series Name]"
                    # Or "Capstone - [Series Name]"
                    challenge_name_parts = []
                    series_name_parts = []
                    capstone_found = False

                    for part in parts:
                        if re.search(entity_patterns['capstone'], part, re.IGNORECASE):
                            capstone_found = True
                            continue

                        if not capstone_found:
                            challenge_name_parts.append(part)
                        else:
                            series_name_parts.append(part)

                    return {
                        'entity_type': 'capstone',
                        'challenge_name': " - ".join(challenge_name_parts) if challenge_name_parts else None,
                        'series_name': " - ".join(series_name_parts) if series_name_parts else None
                    }

                # Generic hyphenated format parsing if not capstone
                if not matched_entity:
                    # Try to detect entity type from the second to last part (e.g., "Entity Name")
                    entity_part = parts[-2] if len(parts) > 2 else parts[-1]
                    for entity_type, pattern in entity_patterns.items():
                        if re.search(pattern, entity_part, re.IGNORECASE):
                            matched_entity = entity_type
                            break

                    if matched_entity:
                        return {
                            'entity_type': matched_entity,
                            'challenge_name': parts[0] if len(parts) > 2 else None,  # Challenge name is first part if series is present
                            'entity_name': entity_part,
                            'series_name': parts[-1] if len(parts) > 2 else None
                        }

            # If still no entity matched, check for standalone entity names (e.g., "Capstone")
            if not matched_entity:
                for entity_type, pattern in entity_patterns.items():
                    if re.search(pattern, cleaned_text, re.IGNORECASE):
                        matched_entity = entity_type
                        break

        if not matched_entity:
            print("Could not parse any known entity type.")
            return None

        # If an entity was matched, now extract challenge and series names more robustly
        challenge_name = None
        series_name = None

        # Handle cases like "Capstone - Generative AI Essentials"
        if matched_entity == 'capstone':
            capstone_match = re.search(entity_patterns['capstone'], cleaned_text, re.IGNORECASE)
            if capstone_match:
                pre_capstone_text = cleaned_text[:capstone_match.start()].strip()
                post_capstone_text = cleaned_text[capstone_match.end():].strip()

                # If there's text before 'Capstone', it's the challenge name
                if pre_capstone_text:
                    challenge_name = pre_capstone_text

                # If there's text after 'Capstone' and it's hyphenated, it's the series name
                if post_capstone_text:
                    if post_capstone_text.startswith('-'):
                        series_name = post_capstone_text[1:].strip()
                    else:
                        series_name = post_capstone_text.strip()

        # Handle other entity types with numbers (Mission 1, Workshop 2, Micro Session 3)
        elif entity_number:
            entity_pattern = entity_patterns[matched_entity]
            match = re.search(entity_pattern, cleaned_text, re.IGNORECASE)
            if match:
                pre_entity_text = cleaned_text[:match.start()].strip()
                post_entity_text = cleaned_text[match.end():].strip()

                if pre_entity_text:
                    challenge_name = pre_entity_text

                if post_entity_text.startswith('-'):
                    series_name = post_entity_text[1:].strip()
                else:
                    series_name = post_entity_text.strip()

        # Clean up challenge_name and series_name
        if challenge_name:
            challenge_name = re.sub(r'^(?:challenge|assignment|submission)\s*[:\-]?\s*', '', challenge_name, flags=re.IGNORECASE).strip()
        if series_name:
            series_name = re.sub(r'^(?:series)\s*[:\-]?\s*', '', series_name, flags=re.IGNORECASE).strip()

        return {
            'entity_type': matched_entity,
            'entity_number': entity_number,
            'challenge_name': challenge_name if challenge_name else None,
            'series_name': series_name if series_name else None
        }
    
    async def _query_challenge_by_entity(self, parsed: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Query database for challenge based on parsed entity information.
        
        Args:
            parsed: Parsed information from _parse_challenge_input
            
        Returns:
            Dict with challenge metadata or None
        """
        entity_type = parsed['entity_type']
        challenge_name = parsed.get('challenge_name')
        series_name = parsed.get('series_name')
        
        try:
            if entity_type == 'mission':
                return await self._query_mission_challenge(parsed)
            elif entity_type == 'workshop':
                return await self._query_workshop_challenge(parsed)
            elif entity_type == 'micro_session':
                return await self._query_micro_session_challenge(parsed)
            elif entity_type == 'capstone':
                return await self._query_capstone_challenge(parsed)
            else:
                print(f"⚠️ Unknown entity type: {entity_type}")
                return None
        except Exception as e:
            print(f"❌ Error querying {entity_type} challenge: {str(e)}")
            return None
    
    async def _query_mission_challenge(self, parsed: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Query challenge within a mission"""
        entity_number = parsed.get('entity_number')
        challenge_name = parsed.get('challenge_name')
        series_name = parsed.get('series_name')
        
        # Build query
        query = self.supabase.table("missions").select(
            "id, name, slug, series_id, mission_number"
        )
        
        # Filter by mission number if provided
        if entity_number:
            query = query.eq("mission_number", int(entity_number))
        
        # Filter by series name if provided
        if series_name:
            # First get series ID
            series_response = self.supabase.table("series").select("id").ilike("name", f"%{series_name}%").execute()
            if series_response.data:
                series_id = series_response.data[0]['id']
                query = query.eq("series_id", series_id)
        
        response = query.execute()
        
        if not response.data:
            return None
        
        mission = response.data[0]
        mission_id = mission['id']
        
        # Query challenges for this mission — prioritize is_legacy=False
        challenge_query = self.supabase.table("challenges").select(
            "id, name, type, status"
        ).eq("mission_id", mission_id).eq("is_legacy", False)
        
        if challenge_name:
            challenge_query = challenge_query.ilike("name", f"%{challenge_name}%")
        
        challenge_response = challenge_query.execute()
        
        # Fallback to is_legacy=True if no non-legacy challenge found
        if not challenge_response.data:
            print(f"⚠️ No non-legacy challenge for mission {mission_id}, falling back to legacy")
            legacy_query = self.supabase.table("challenges").select(
                "id, name, type, status"
            ).eq("mission_id", mission_id).eq("is_legacy", True)
            if challenge_name:
                legacy_query = legacy_query.ilike("name", f"%{challenge_name}%")
            challenge_response = legacy_query.execute()
        
        if not challenge_response.data:
            # Return mission info even if no specific challenge found
            return {
                "challenge_id": None,
                "challenge_name": None,
                "entity_type": "mission",
                "entity_id": mission_id,
                "entity_name": mission['name'],
                "series_id": mission.get('series_id'),
                "series_name": series_name
            }
        
        challenge = challenge_response.data[0]
        
        return {
            "challenge_id": challenge['id'],
            "challenge_name": challenge['name'],
            "entity_type": "mission",
            "entity_id": mission_id,
            "entity_name": mission['name'],
            "series_id": mission.get('series_id'),
            "series_name": series_name
        }
    
    async def _query_workshop_challenge(self, parsed: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Query challenge within a workshop"""
        entity_number = parsed.get('entity_number')
        challenge_name = parsed.get('challenge_name')
        series_name = parsed.get('series_name')
        
        # Build query
        query = self.supabase.table("workshops").select(
            "id, name, slug, series_id, series_name"
        )
        
        # Filter by workshop number if provided (extract from name)
        if entity_number:
            query = query.ilike("name", f"%{entity_number}%")
        
        # Filter by series name if provided
        if series_name:
            query = query.ilike("series_name", f"%{series_name}%")
        
        response = query.execute()
        
        if not response.data:
            return None
        
        workshop = response.data[0]
        workshop_id = workshop['id']
        
        # Query challenges for this workshop — prioritize is_legacy=False
        challenge_query = self.supabase.table("challenges").select(
            "id, name, type, status"
        ).eq("mission_id", workshop_id).eq("is_legacy", False)
        
        if challenge_name:
            challenge_query = challenge_query.ilike("name", f"%{challenge_name}%")
        
        challenge_response = challenge_query.execute()
        
        # Fallback to is_legacy=True if no non-legacy challenge found
        if not challenge_response.data:
            print(f"⚠️ No non-legacy challenge for workshop {workshop_id}, falling back to legacy")
            legacy_query = self.supabase.table("challenges").select(
                "id, name, type, status"
            ).eq("mission_id", workshop_id).eq("is_legacy", True)
            if challenge_name:
                legacy_query = legacy_query.ilike("name", f"%{challenge_name}%")
            challenge_response = legacy_query.execute()
        
        if not challenge_response.data:
            return {
                "challenge_id": None,
                "challenge_name": None,
                "entity_type": "workshop",
                "entity_id": workshop_id,
                "entity_name": workshop['name'],
                "series_id": workshop.get('series_id'),
                "series_name": workshop.get('series_name')
            }
        
        challenge = challenge_response.data[0]
        
        return {
            "challenge_id": challenge['id'],
            "challenge_name": challenge['name'],
            "entity_type": "workshop",
            "entity_id": workshop_id,
            "entity_name": workshop['name'],
            "series_id": workshop.get('series_id'),
            "series_name": workshop.get('series_name')
        }
    
    async def _query_micro_session_challenge(self, parsed: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Query challenge within a micro session"""
        entity_number = parsed.get('entity_number')
        challenge_name = parsed.get('challenge_name')
        series_name = parsed.get('series_name')
        
        # Build query
        query = self.supabase.table("micro_sessions").select(
            "id, name, slug, space"
        )
        
        # Filter by session number if provided
        if entity_number:
            query = query.ilike("name", f"%{entity_number}%")
        
        # Filter by series/space name if provided
        if series_name:
            query = query.ilike("space", f"%{series_name}%")
        
        response = query.execute()
        
        if not response.data:
            return None
        
        session = response.data[0]
        session_id = session['id']
        
        # Note: Micro sessions might not have challenges in the same way
        # Return session info
        return {
            "challenge_id": None,
            "challenge_name": challenge_name,
            "entity_type": "micro_session",
            "entity_id": session_id,
            "entity_name": session['name'],
            "series_id": None,
            "series_name": session.get('space')
        }
    
    async def _query_capstone_challenge(self, parsed: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Query capstone challenge - standalone challenges directly under Series/Program/Essentials"""
        challenge_name = parsed.get('challenge_name')
        series_name = parsed.get('series_name')
        
        # Capstone challenges are standalone challenges in the challenges table
        # They are NOT children of missions
        # Query challenges with "Capstone" in the name — prioritize is_legacy=False
        query = self.supabase.table("challenges").select(
            "id, name, type, status, mission_id"
        ).ilike("name", "%capstone%").eq("is_legacy", False)
        
        # If specific challenge name provided, filter by it
        if challenge_name:
            query = query.ilike("name", f"%{challenge_name}%")
        
        # Execute query to get all matching capstone challenges
        response = query.execute()
        
        # Fallback to is_legacy=True if no non-legacy capstone found
        if not response.data:
            print(f"⚠️ No non-legacy capstone challenge found, falling back to legacy")
            legacy_query = self.supabase.table("challenges").select(
                "id, name, type, status, mission_id"
            ).ilike("name", "%capstone%").eq("is_legacy", True)
            if challenge_name:
                legacy_query = legacy_query.ilike("name", f"%{challenge_name}%")
            response = legacy_query.execute()
        
        if not response.data:
            return None
        
        # If series_name provided, filter by checking mission's series
        if series_name:
            # Get series ID first
            series_response = self.supabase.table("series").select("id").ilike("name", f"%{series_name}%").execute()
            if not series_response.data:
                return None
            series_id = series_response.data[0]['id']
            
            # Filter challenges to those whose mission belongs to this series
            filtered_challenges = []
            for challenge in response.data:
                if challenge.get('mission_id'):
                    mission_response = self.supabase.table("missions").select("id, name, slug, series_id").eq("id", challenge['mission_id']).execute()
                    if mission_response.data and mission_response.data[0].get('series_id') == series_id:
                        filtered_challenges.append(challenge)
            
            if not filtered_challenges:
                return None
            challenge = filtered_challenges[0]
        else:
            challenge = response.data[0]
        
        challenge_id = challenge['id']
        
        # Get the mission this challenge belongs to (for entity_name and series info)
        if challenge.get('mission_id'):
            mission_query = self.supabase.table("missions").select(
                "id, name, slug, series_id"
            ).eq("id", challenge['mission_id'])
            mission_response = mission_query.execute()
            
            if mission_response.data:
                mission = mission_response.data[0]
                return {
                    "challenge_id": challenge_id,
                    "challenge_name": challenge['name'],
                    "entity_type": "capstone",
                    "entity_id": mission['id'],
                    "entity_name": mission['name'],
                    "series_id": mission.get('series_id'),
                    "series_name": series_name
                }
        
        # Fallback if no mission found
        return {
            "challenge_id": challenge_id,
            "challenge_name": challenge['name'],
            "entity_type": "capstone",
            "entity_id": None,
            "entity_name": challenge['name'],
            "series_id": None,
            "series_name": series_name
        }

    async def detect_mission_space_from_text_or_files(
        self, user_message: str, file_names: List[str]
    ) -> Optional[str]:
        """
        Detect space name from user message or file names.
        
        DEPRECATED: Use detect_challenge_from_text_or_files instead for better entity support.
        
        Args:
            user_message: User's text message
            file_names: List of file names
            
        Returns:
            Matched space name or None
        """
        try:
            # Step 1: Fetch space groups with type="series"
            space_groups = await self.fetch_space_groups_with_filter({"type": "series"})
            
            if not space_groups:
                print("⚠️ No space groups found with type='series'")
                return None
            
            # Step 2: Query spaces that have space_group_id from found groups and is_mission="true"
            mission_spaces = []
            space_group_ids = [sg.get("id") for sg in space_groups]
            
            if space_group_ids:
                try:
                    for sg_id in space_group_ids:
                        response = self.supabase.table("spaces").select(
                            "id, name, space_group_id"
                        ).eq("space_group_id", sg_id).eq("is_mission", True).execute()
                        
                        if response.data:
                            mission_spaces.extend(response.data)
                            
                except Exception as e:
                    print(f"⚠️ Error querying mission spaces: {str(e)}")
                    return None

            if not mission_spaces:
                return None
                
            # Step 3: Detect from user_message
            detected_space_name = detect_mission_space(user_message, mission_spaces)
            if detected_space_name:
                return detected_space_name
                
            # Step 4: Detect from file_names
            for file_name in file_names:
                detected_space_name = detect_mission_space(file_name, mission_spaces)
                if detected_space_name:
                    return detected_space_name
                    
            return None
            
        except Exception as e:
            print(f"❌ Error detecting space name: {str(e)}")
            return None
        
    async def fetch_challenge_submission_space(self, space_group_id):
        try:
            response = (
                self.supabase.table("spaces")
                .select("id, name")
                .eq("space_group_id", space_group_id)
                .ilike("name", "%Challenge Submissions%")
                .execute()
            )

            if not response.data or len(response.data) == 0:
                return None

            space_data = response.data[0]
            print(f"✅ Found space: {space_data['name']} (id: {space_data['id']})")
            return space_data

        except Exception as e:
            print(f"❌ Error fetching space info: {str(e)}")
            return None

    async def process_submission(
        self,
        email: str,
        space_name: str,
        files: Optional[List[dict[str, Any]]] = [],
        chat_room_id: Optional[str] = None,
        skip_prior_check: bool = False,
        resolved_challenge_name: Optional[str] = None,
        challenge_metadata: Optional[Dict[str, Any]] = None,
        student_inputs: Optional[Dict[str, Dict[str, str]]] = None,
        text_content: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Main handler: Process submission with file uploads

        Args:
            email: Student's email
            space_name: Name of the space (used for legacy path; ignored when challenge_metadata provided)
            files: List of file URLs
            resolved_challenge_name: DEPRECATED — use challenge_metadata instead.
                Kept for backward compatibility during transition.
            challenge_metadata: Pre-resolved challenge dict from fetch_challenge_by_uuid or
                detect_challenge_from_text_or_files. When provided, uses challenges-first path
                which supports micro_sessions (no spaces/lessons needed).
                Keys: challenge_uuid, challenge_name, challenge_type, space_id, space_group_id,
                       event_id, series_id, rubric_content, body_html, entity_name, entity_type.
            text_content: Raw text content from student's chat message

        Returns:
            Dictionary with submission_id, student_name, and files in base64
        """
        try:
            if files is None:
                files = []
            print(f"\n🚀 Processing submission for {email} in space '{space_name}'")
            # print(f"   Files to upload: {len(files)}")

            # ── Resolve space_id, space_group_id, lesson, challenge_id ──
            import markdownify

            space_id: Optional[int] = None
            space_group_id: Optional[int] = None
            challenge_id: Optional[int] = None  # lessons.id (None for micro_sessions)
            challenge_uuid: Optional[str] = None  # challenges.id
            event_id: Optional[int] = None
            challenge_name: str = ""
            lesson_context: str = ""
            lesson: Optional[Dict[str, Any]] = None
            chat_room = None

            if challenge_metadata:
                # ── Challenges-first path: challenge_uuid is the single source of truth.
                # No lessons table queries — build everything from challenges table + challenge_metadata.
                space_id = challenge_metadata.get("space_id")
                space_group_id = challenge_metadata.get("space_group_id")
                challenge_uuid = challenge_metadata.get("challenge_uuid")
                event_id = challenge_metadata.get("event_id")
                challenge_name = challenge_metadata.get("challenge_name") or challenge_metadata.get("entity_name") or ""

                print(f"\n📍 Step 1: Challenges-first path. challenge_uuid={challenge_uuid}, space_id={space_id}")

                # Build lesson_context from challenge body_html — no lessons lookup
                body = challenge_metadata.get("body_html") or challenge_metadata.get("markdown") or ""
                lesson_context = f"{challenge_name}\nDescription:\n {markdownify.markdownify(body)}\n"
                # challenge_id stays None — chat-based grading links via challenge_uuid only

                if not space_group_id:
                    return {"error": "Could not resolve space_group_id from challenge metadata"}
            else:
                # ── Legacy path (unchanged) ──
                # Step 1: Fetch space and space group info
                print("\n📍 Step 1: Fetching space information...")
                space_info = await self.fetch_space_info(space_name)
                if not space_info:
                    return {"error": f"Space not found: {space_name}"}

                space_id = space_info["id"]
                space_group_id = space_info.get("space_group_id")

                if not space_group_id:
                    return {"error": "Space group ID not found"}

                print(f"Space group ID: {space_group_id}")

                if chat_room_id:
                    chat_room = await self.fetch_chat_room_info(chat_room_id)
                    if not chat_room:
                        return {"error": f"Chat room not found"}

                # Step 2: Fetch lesson / resolve challenge
                print("\n📚 Step 2: Fetching lesson...")
                lessons = await self.fetch_lesson(space_id)
                if not lessons:
                    return {"error": f"No lessons found for space {space_id}"}

                if resolved_challenge_name:
                    print(f"   🔍 Matching lesson by resolved_challenge_name='{resolved_challenge_name}'")
                    matched = [l for l in lessons if l["name"].strip().lower() == resolved_challenge_name.strip().lower()]
                    if not matched:
                        matched = [l for l in lessons if resolved_challenge_name.strip().lower() in l["name"].strip().lower()]
                    if not matched:
                        print(f"   ⚠️ No lesson matched '{resolved_challenge_name}', falling back to final_assignment")
                        matched = [l for l in lessons if l["type"] == "final_assignment"]
                        if not matched:
                            matched = [lessons[0]] if lessons else []
                    if not matched:
                        return {"error": f"No lesson found matching '{resolved_challenge_name}' in space {space_id}"}
                    lesson = matched[0]
                else:
                    final_assignment = [l for l in lessons if l["type"] == "final_assignment"]
                    if not final_assignment:
                        return {"error": f"No final_assignment lesson found for space {space_id}"}
                    lesson = final_assignment[0]

                # Build lesson context
                lesson_context = f"{lesson['name']}\n"
                lesson_context += f"Description:\n {markdownify.markdownify(lesson.get('body_html', ''))}\n"
                challenge_id = lesson["id"]
                challenge_name = lesson["name"]

            if chat_room_id and not chat_room:
                chat_room = await self.fetch_chat_room_info(chat_room_id)
                if not chat_room:
                    return {"error": f"Chat room not found"}

            # Step 3: Fetch space group member
            print("\n👤 Step 3: Fetching space group member...")
            member = await self.fetch_space_group_member(email, space_group_id)
            if not member:
                return {"error": f"Member not found: {email}"}

            student_id = member["id"]
            student_name = member.get("author_name", "Unknown")

            submission_id = None  # May be set by Step 3.5 (reuse)

            # ★ Step 3.5: Check for existing submissions
            if not skip_prior_check:
                print("\n🔍 Step 3.5: Checking for prior submission...")

                # Build the prior-check filter: use challenge_uuid (authoritative) when available,
                # otherwise fall back to challenge_id for legacy submissions
                def _build_prior_query(base_query):
                    q = base_query.eq("student_id", student_id)
                    if challenge_uuid is not None:
                        q = q.eq("challenge_uuid", challenge_uuid)
                    elif challenge_id is not None:
                        q = q.eq("challenge_id", challenge_id)
                    else:
                        return None  # Cannot check without an identifier
                    return q

                # 3.5a: Check for any PASSED submission (not just latest)
                base = self.supabase.table("challenge_submissions").select(
                    "id, score, grade_status, status, graded_at, submitted_at, feedback"
                )
                passed_query = _build_prior_query(base)
                passed_resp = None
                if passed_query:
                    passed_resp = (
                        passed_query
                        .eq("grade_status", "pass")
                        .order("graded_at", desc=True)
                        .limit(1)
                        .execute()
                    )
                    if not passed_resp.data:
                        # Fallback: check by score >= 80 for pre-fix rows without grade_status
                        base2 = self.supabase.table("challenge_submissions").select(
                            "id, score, grade_status, status, graded_at, submitted_at, feedback"
                        )
                        fallback_query = _build_prior_query(base2)
                        if fallback_query:
                            passed_resp = (
                                fallback_query
                                .eq("status", "graded")
                                .gte("score", 80)
                                .order("graded_at", desc=True)
                                .limit(1)
                                .execute()
                            )

                if passed_resp and passed_resp.data:
                    existing = passed_resp.data[0]
                    score_value = float(existing.get("score") or 0)
                    print(f"   ⚠️ Prior passed submission found: score={score_value}, grade_status={existing.get('grade_status')}")

                    # Resolve challenge_type for score-display decision
                    _challenge_type = "mission"  # default: non-final (no score shown)
                    if challenge_metadata and challenge_metadata.get("challenge_type"):
                        _challenge_type = challenge_metadata["challenge_type"]
                    elif lesson and lesson.get("type") == "final_assignment":
                        _challenge_type = "mission_final"

                    # Fetch prior submission content for feedback comparison
                    prior_content = await self._fetch_prior_submission_content(existing["id"])
                    prior_feedback = existing.get("feedback", "")

                    return {
                        "success": True,
                        "needs_resubmit_confirmation": True,
                        "prior_submission": {
                            "id": existing["id"],
                            "score": score_value,
                            "grade_status": existing.get("grade_status"),
                            "graded_at": existing.get("graded_at"),
                            "status": existing.get("status"),
                            "feedback": prior_feedback,
                        },
                        "prior_submission_context": {
                            "content": prior_content,
                            "score": score_value,
                            "feedback": prior_feedback,
                            "submission_id": existing["id"],
                        },
                        "challenge_type": _challenge_type,
                        "student_id": student_id,
                        "student_name": student_name,
                        "student_email": email,
                        "space_id": space_id,
                        "space_name": space_name,
                        "space_group_id": space_group_id,
                        "challenge_name": challenge_name,
                        "challenge_id": challenge_id,
                        "challenge_uuid": challenge_uuid,
                        "lesson_context": lesson_context,
                    }

                # 3.5b: No passed submission — check for ungraded submission to reuse
                if challenge_id is not None:
                    existing = await self.fetch_existing_challenge_submission(
                        student_id, challenge_id
                    )
                elif challenge_uuid is not None:
                    # For micro_sessions: query by challenge_uuid
                    ungraded_resp = (
                        self.supabase.table("challenge_submissions")
                        .select("id, status, grade_status")
                        .eq("student_id", student_id)
                        .eq("challenge_uuid", challenge_uuid)
                        .order("submitted_at", desc=True)
                        .limit(1)
                        .execute()
                    )
                    existing = ungraded_resp.data[0] if ungraded_resp.data else None
                else:
                    existing = None

                if existing:
                    existing_status = existing.get("status")
                    existing_grade = existing.get("grade_status")
                    if existing_status == "submitted" and existing_grade is None:
                        print(f"   ♻️ Reusing ungraded submission: {existing['id']}")
                        submission_id = existing["id"]
                    else:
                        print(f"   📝 Prior submission with redo — creating new submission")

            # Step 4: Create challenge submission (skip if reusing)
            if submission_id is None:
                print("\n📝 Step 4: Creating challenge submission...")
                submission = await self.create_challenge_submission(
                    student_id=student_id,
                    challenge_id=challenge_id,
                    challenge_uuid=challenge_uuid,
                    micro_session_workshop_id=event_id,
                    student_inputs=student_inputs,
                    student_input_text=text_content,
                )
                if not submission:
                    return {"error": "Failed to create challenge submission"}
                submission_id = submission["id"]
            
            # Build challenge_content from lesson or challenge_metadata
            _challenge_content = ""
            if lesson:
                _challenge_content = lesson.get("body_html", "")
            elif challenge_metadata:
                _challenge_content = challenge_metadata.get("body_html") or challenge_metadata.get("markdown") or ""

            # Resolve challenge_type from metadata or lesson (used in both return paths)
            _challenge_type = "mission"  # default: non-final
            if challenge_metadata and challenge_metadata.get("challenge_type"):
                _challenge_type = challenge_metadata["challenge_type"]
            elif lesson and lesson.get("type") == "final_assignment":
                _challenge_type = "mission_final"
            elif lesson:
                _challenge_type = "mission"

            if len(files) == 0:
                return {
                    "success": True,
                    "submission_id": submission_id,
                    "student_name": student_name,
                    "student_email": email,
                    "space_id": space_id,
                    "space_name": space_name,
                    "space_group_id": space_group_id,
                    "challenge_name": challenge_name,
                    "challenge_id": challenge_id,
                    "challenge_uuid": challenge_uuid,
                    "challenge_content": _challenge_content,
                    "files_count": 0,
                    "files": [],
                    "chat_room_name": chat_room.get("name", "") if chat_room else "",
                    "lesson_context": lesson_context,
                    "challenge_type": _challenge_type,
                }

            # Step 5: Download and upload files in parallel
            print("\n📤 Step 5: Downloading and uploading files...")

            seen_file_keys: set[tuple[str, str]] = set()
            semaphore = asyncio.Semaphore(5)

            async def _process_single_file(file_dict: Dict[str, Any]) -> Optional[Dict[str, Any]]:
                """Download, convert, upload a single file. Returns dict with attachment + file_base64 or None."""
                async with semaphore:
                    file_url = file_dict.get("url")
                    file_name = file_dict.get("file_name", file_url.split("/")[-1].split("?")[0])
                    file_key = (file_url or "", file_name or "")

                    # Dedup check (thread-safe since we're in async single-thread)
                    if file_key in seen_file_keys:
                        print(f"   ⚠ Skipping duplicate file input: {file_name or file_url}")
                        return None
                    seen_file_keys.add(file_key)

                    # Download
                    file_bytes = await self.download_file_bytes(file_url)
                    if not file_bytes:
                        print(f"   ⚠ Skipping file: {file_url}")
                        return None

                    if not file_name:
                        file_name = f"file_{id(file_dict)}"

                    # Convert docx/txt to PDF
                    if file_name.endswith(".docx") or file_name.endswith(".txt"):
                        file_obj = convert_to_pdf(file_bytes, file_name)
                        file_bytes = file_obj["data"]
                        file_name = file_obj["filename"]

                    supabase_url = os.getenv("AIO_SUPABASE_URL")
                    supabase_storage_bucket = "submission_attachments"
                    storage_info = None

                    if supabase_url not in file_url and supabase_storage_bucket not in file_url:
                        storage_info = await self.upload_file_to_storage(
                            file_bytes=file_bytes,
                            file_name=file_name,
                            space_group_id=space_group_id,
                            space_id=space_id or event_id,
                            student_id=student_id,
                        )

                    # Build result
                    attachment = None
                    file_base64 = None

                    if storage_info is None:
                        mime_type = get_mime_type_from_filename(file_name)
                        attachment = {
                            "submission_id": submission_id,
                            # "url": file_url,
                            "name": file_name,
                            "size_bytes": len(file_bytes),
                            "mime_type": mime_type,
                        }
                        file_base64 = {
                            "name": file_name,
                            "data": file_url,
                            "file_type": get_file_category(mime_type),
                        }
                    elif storage_info.get("id"):
                        attachment = {
                            "submission_id": submission_id,
                            "storage_object_id": storage_info["id"],
                            # "url": storage_info.get("url"),
                        }
                        file_base64 = {
                            "name": file_name,
                            "data": storage_info.get("url"),
                            "file_type": get_file_category(storage_info["mime_type"]),
                        }

                    return {"attachment": attachment, "file_base64": file_base64}

            # Run all files in parallel
            tasks = [_process_single_file(fd) for fd in files]
            results = await asyncio.gather(*tasks, return_exceptions=True)

            # Collect results
            attachments = []
            files_base64 = []
            seen_storage_ids: set[str] = set()

            for result in results:
                if isinstance(result, Exception):
                    print(f"   ⚠ File processing error: {result}")
                    continue
                if result is None:
                    continue
                att = result.get("attachment")
                fb = result.get("file_base64")
                if att:
                    # Dedup storage IDs
                    sid = att.get("storage_object_id")
                    if sid and sid in seen_storage_ids:
                        continue
                    if sid:
                        seen_storage_ids.add(sid)
                    attachments.append(att)
                if fb:
                    files_base64.append(fb)

            if not attachments:
                return {"error": "No files were successfully uploaded"}

            # Step 6: Update submission with attachments
            print("\n💾 Step 6: Updating submission with attachments...")
            updated = await self.insert_submission_attachments(attachments)

            if not updated:
                return {"error": "Failed to update submission with attachments"}

            print(f"\n✅ Submission processing complete!")

            return {
                "success": True,
                "submission_id": submission_id,
                "student_name": student_name,
                "student_email": email,
                "space_id": space_id,
                "space_name": space_name,
                "space_group_id": space_group_id,
                "challenge_name": challenge_name,
                "challenge_id": challenge_id,
                "challenge_uuid": challenge_uuid,
                "challenge_content": _challenge_content,
                "files_count": len(files_base64),
                "files": files_base64,
                "chat_room_name": chat_room.get("name", "") if chat_room else "",
                "lesson_context": lesson_context,
                "challenge_type": _challenge_type,
            }

        except Exception as e:
            print(f"\n❌ Error processing submission: {str(e)}")
            return {"error": str(e)}

    async def _fetch_prior_submission_content(self, submission_id: str) -> str:
        """
        Fetch the content from a prior submission for comparison.
        Returns markdown-formatted content from submission attachments.

        Args:
            submission_id: UUID of the prior submission

        Returns:
            Markdown-formatted text content from prior submission files
        """
        try:
            # Query submission_attachments table for files
            attachments = (
                self.supabase.table("submission_attachments")
                .select("file_url, file_name")
                .eq("submission_id", submission_id)
                .execute()
            )

            if not attachments.data:
                return ""

            # Extract content from files
            content_parts = []
            for file in attachments.data:
                try:
                    file_url = file.get("file_url")
                    file_name = file.get("file_name", "unknown")

                    if not file_url:
                        continue

                    # Download file
                    import httpx
                    async with httpx.AsyncClient() as client:
                        response = await client.get(file_url)
                        response.raise_for_status()
                        file_bytes = response.content

                    # Extract text based on file type
                    if file_name.endswith(".pdf"):
                        # Use existing PDF extraction logic
                        from agents.tools.shared import LLMPdfExtractor
                        extractor = LLMPdfExtractor()
                        content = await extractor.extract_from_bytes(file_bytes)
                    elif file_name.endswith((".txt", ".md", ".py", ".json", ".docx")):
                        # Plain text files
                        try:
                            content = file_bytes.decode("utf-8")
                        except UnicodeDecodeError:
                            # Fallback to multimodal extractor
                            from agents.tools.shared import MultimodalFileExtractor
                            extractor = MultimodalFileExtractor()
                            result = await extractor.execute(files=[{"url": file_url, "file_name": file_name}])
                            content = result.get("content", {}).get("markdown", "")
                    else:
                        # Use multimodal extractor for other types
                        from agents.tools.shared import MultimodalFileExtractor
                        extractor = MultimodalFileExtractor()
                        result = await extractor.execute(files=[{"url": file_url, "file_name": file_name}])
                        content = result.get("content", {}).get("markdown", "")

                    if content:
                        content_parts.append(f"### From {file_name}:\n{content}")
                except Exception as e:
                    print(f"⚠️ Failed to extract content from {file_name}: {e}")
                    continue

            return "\n\n---\n\n".join(content_parts)

        except Exception as e:
            print(f"❌ Error fetching prior submission content: {e}")
            return ""

    async def store_grading_results(
        self,
        email: str,
        challenge_id: str,
        score: float,
        grade_status: str,
        feedback: str,
        scoring_details: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Store grading results in the database for AIO grading flow.
        Creates or updates a challenge_submission record.

        Args:
            email: Student's email
            challenge_id: UUID of the challenge
            score: Percentage score (0-100)
            grade_status: "pass" or "redo"
            feedback: Full feedback text
            scoring_details: JSON-serializable scoring breakdown

        Returns:
            Dict with submission record or error
        """
        try:
            # Get student_id from email
            member_result = self.supabase.table('members').select("id").eq('email', email).execute()
            if not member_result.data or len(member_result.data) == 0:
                return {"error": f"Member not found for email: {email}"}
            student_id = member_result.data[0]['id']

            # Get challenge info
            challenge_result = self.supabase.table('challenges').select("*").eq('id', challenge_id).execute()
            if not challenge_result.data:
                return {"error": f"Challenge not found: {challenge_id}"}
            challenge = challenge_result.data[0]

            # Prepare submission data
            submission_data = {
                'student_id': student_id,
                'challenge_id': challenge_id,
                'score': int(score),
                'grade_status': grade_status,
                'feedback': feedback,
                'scoring_details': scoring_details or {},
                'status': 'graded',
                'space_id': challenge.get('space_id'),
                'mission_id': challenge.get('mission_id'),
            }

            # Insert new submission record
            result = self.supabase.table('challenge_submissions').insert(submission_data).execute()

            if result.data:
                print(f"✅ Stored grading result for student {student_id}, challenge {challenge_id}: {score}% - {grade_status}")
                return {"success": True, "submission": result.data[0]}
            else:
                return {"error": "Failed to insert submission"}

        except Exception as e:
            print(f"❌ Error storing grading results: {str(e)}")
            return {"error": str(e)}

    async def execute(self, **kwargs):
        resource = kwargs.get("resource", "students")
        limit = kwargs.get("limit", "1")
        name = kwargs.get("name", "")
        query = kwargs.get("query", name)
        email = kwargs.get("email", '')
        timestamp = kwargs.get("timestamp", "")
        include_related = kwargs.get("include_related", True)
        member_id = kwargs.get('member_id', None)
        series_name = kwargs.get('series_name', '')
        table_name = ''
        selections = []
        filters = []
        and_filters = []  # Applied as .eq() (AND conditions), separate from or_() filters

        # Check if resource is cacheable
        if resource in self._cache_ttls and self.cache:
            cache_key = self._build_cache_key(resource, kwargs)

            # Try cache first
            try:
                cached = self.cache.get(cache_key)
                if cached:
                    print(f"📦 AIO cache HIT: {resource}")
                    result = json.loads(cached)
                    result["from_cache"] = True
                    return result
            except Exception as e:
                print(f"⚠️  Cache read error for {resource}: {e}")

        # Cache miss or not cacheable - proceed with normal query
        print(f"🔍 AIO cache MISS: {resource}")

        print("Email: ", email)
        if email != '' and member_id is None:
            member = self.supabase.table('members').select("id").eq('email', email).execute()
            if member.data and len(member.data) > 0:
                member_id = int(member.data[0].get('id'))
                print("Member ID: ", member_id)
            else:
                print(f"⚠️  No member found for email: {email}")
        from .const import AIO_TABLE_READABLE_COLUMNS

        if resource == "series":
            table_name = "series"
            selections = AIO_TABLE_READABLE_COLUMNS["series"]
            if query != '' and query is not None:
                filters.append({"column": "name", "value": f"*{query}*", "operator": "ilike"})

        elif resource == "missions":
            table_name = "missions"
            selections = AIO_TABLE_READABLE_COLUMNS["missions"]
            if query != '' and query is not None:
                filters.append({"column": "name", "value": f"*{query}*", "operator": "ilike"})
            # Filter missions by parent series/course name (applied as AND via .eq())
            if series_name:
                series_response = self.supabase.table("series").select("id").ilike("name", f"%{series_name}%").execute()
                if series_response.data:
                    and_filters.append({"column": "series_id", "value": series_response.data[0]['id']})

        elif resource == "briefs":
            table_name = "briefs"
            selections = AIO_TABLE_READABLE_COLUMNS["briefs"]
            if query != '' and query is not None:
                filters.append({"column": "name", "value": f"*{query}*", "operator": "ilike"})

        elif resource == "challenges":
            table_name = "challenges"
            selections = AIO_TABLE_READABLE_COLUMNS["challenges"]
            if query != '' and query is not None:
                filters.append({"column": "name", "value": f"*{query}*", "operator": "ilike"})

        elif resource == "students":
            table_name = "students"
            selections = AIO_TABLE_READABLE_COLUMNS["students"]
            if query != '' and query is not None:
                if '@' not in query:
                    filters.append({"column": "name", "value": f"*{query}*", "operator": "ilike"})
                if '@' in query:
                    filters.append({"column": "email", "value": f"*{query}*", "operator": "ilike"})
            if email != '':
                filters.append({"column": "email", "value": email, "operator": "eq"})

        elif resource == "enrollments":
            table_name = "enrollments"
            selections = AIO_TABLE_READABLE_COLUMNS["enrollments"]
            if query != '' and query is not None:
                filters.append({"column": "author_name", "value": f"*{query}*", "operator": "ilike"})
            if email != '': 
                filters.append({"column": "author_email", "value": email, "operator": "ilike"})
            if member_id is not None:
                filters.append({"column": "user_id", "value": member_id, "operator": "eq"})

        elif resource == "submissions":
            table_name = "submissions"
            selections = AIO_TABLE_READABLE_COLUMNS["submissions"]
            submission_filters = [
                {"column": "status", "value": "graded", "operator": "eq"},
            ]
            if query != '' and query is not None:
                submission_filters.append({"column": "feedback", "value": f"*{query}*", "operator": "ilike"})
            if member_id is not None:
                submission_filters.append({"column": "student_id", "value": member_id, "operator": "eq"})
            filters.extend(submission_filters)

        elif resource == "submission_files":
            table_name = "submission_files"
            selections = AIO_TABLE_READABLE_COLUMNS["submission_files"]
            if query != '' and query is not None:
                filters.append({"column": "name", "value": f"*{query}*", "operator": "ilike"})

        elif resource == "session_attendees":
            table_name = "session_attendees"
            selections = AIO_TABLE_READABLE_COLUMNS["session_attendees"]
            if query != '' and query is not None:
                if '@' not in query:
                    filters.append({"column": "attendee_name", "value": f"*{query}*", "operator": "ilike"})
                if '@' in query:
                    filters.append({"column": "attendee_email", "value": f"*{query}*", "operator": "ilike"})
            if member_id is not None:
                filters.append({"column": "student_id", "value": member_id, "operator": "eq"})

        elif resource == "micro_sessions":
            table_name = "micro_sessions"
            selections = AIO_TABLE_READABLE_COLUMNS["micro_sessions"]
            if query != '' and query is not None:
                filters.append({"column": "name", "value": f"*{query}*", "operator": "ilike"})
                filters.append({"column": "description", "value": f"*{query}*", "operator": "ilike"})
            if timestamp != '':
                filters.append({"column": "starts_at", "value": timestamp, "operator": "gte"})

        elif resource == "workshops":
            table_name = "workshops"
            selections = AIO_TABLE_READABLE_COLUMNS["workshops"]
            if query != '' and query is not None:
                filters.append({"column": "name", "value": f"*{query}*", "operator": "ilike"})

        elif resource == "mission_progress":
            table_name = "mission_progress"
            selections = AIO_TABLE_READABLE_COLUMNS["mission_progress"]
            if member_id is not None:
                filters.append({"column": "student_id", "value": member_id, "operator": "eq"})

        elif resource == "workshop_progress":
            table_name = "workshop_progress"
            selections = AIO_TABLE_READABLE_COLUMNS["workshop_progress"]
            if member_id is not None:
                filters.append({"column": "student_id", "value": member_id, "operator": "eq"})

        elif resource == "micro_sessions_progress":
            table_name = "micro_sessions_progress"
            selections = AIO_TABLE_READABLE_COLUMNS["micro_sessions_progress"]
            if member_id is not None:
                filters.append({"column": "student_id", "value": member_id, "operator": "eq"})

        elif resource == "student_progress":
            table_name = "student_progress"
            selections = AIO_TABLE_READABLE_COLUMNS["student_progress"]
            if email != '':
                # Filter by student email via students table join
                filters.append({"column": "student_email", "value": email, "operator": "eq"})
            if member_id is not None:
                filters.append({"column": "student_id", "value": member_id, "operator": "eq"})

        elif resource == "guidelines":
            table_name = "guidelines"
            selections = AIO_TABLE_READABLE_COLUMNS["guidelines"]
            if query != '' and query is not None:
                filters.append({"column": "body", "value": f"*{query}*", "operator": "ilike"})
                filters.append({"column": "name", "value": f"*{query}*", "operator": "ilike"})

        elif resource == "posts":
            table_name = "posts"
            selections = ["id", "name", "body", "user_name", "user_email", "space_name", "published_at", "likes_count", "comments_count"]
            if query != '' and query is not None:
                filters.append({"column": "body", "value": f"*{query}*", "operator": "ilike"})
                filters.append({"column": "name", "value": f"*{query}*", "operator": "ilike"})

        elif resource == "events":
            table_name = "events"
            selections = ["id", "name", "body", "starts_at", "ends_at", "location_type", "virtual_location_url", "member_name", "member_email", "likes_count", "comments_count", "url"]
            if query != '' and query is not None:
                filters.append({"column": "body", "value": f"*{query}*", "operator": "ilike"})
                filters.append({"column": "name", "value": f"*{query}*", "operator": "ilike"})
            if timestamp != '':
                filters.append({"column": "starts_at", "value": timestamp, "operator": "gte"})

        elif resource == "posts":
            table_name = "posts"
            selections = AIO_TABLE_READABLE_COLUMNS["posts"]
            if query != '' and query is not None:
                filters.append({"column": "body->>body", "value": f"*{query}*", "operator": "ilike"})
                filters.append({"column": "name", "value": f"*{query}*", "operator": "ilike"})
            if timestamp != '':
                filters.append({"column": "published_at", "value": timestamp, "operator": "gte"})
        
        else:
            table_name = "students"
            selections = AIO_TABLE_READABLE_COLUMNS["students"]
            if member_id is not None:
                filters.append({"column": "id", "value": member_id, "operator": "eq"})

        try:
            base_query = self.supabase.schema("public").table(table_name).select(",".join(selections)).limit(int(limit))

            # Apply AND filters (e.g., series_id for missions by course)
            for af in and_filters:
                base_query = base_query.eq(af["column"], af["value"])

            if len(filters) > 0:
                # Group filters by operator type:
                # - OR-able same-column ilike filters (e.g. name OR body) stay as .or_()
                # - Equality / range filters are applied individually to avoid PostgREST
                #   parser failures on special characters (apostrophes, commas, etc.)
                or_filters = [f for f in filters if f.get("operator") in ("ilike", "like")]
                exact_filters = [f for f in filters if f.get("operator") not in ("ilike", "like")]

                if or_filters:
                    or_parts = []
                    for f in or_filters:
                        value = str(f.get("value", ""))
                        value = value.replace("\u2018", "'").replace("\u2019", "'")
                        value = value.replace("\u201c", '"').replace("\u201d", '"')
                        # Wrap value in double-quotes so PostgREST treats it as a literal
                        # string — this handles apostrophes and commas safely.
                        quoted = value.replace('"', '\\"')
                        or_parts.append(f'{f.get("column")}.{f.get("operator")}."{quoted}"')
                    filter_string = ",".join(or_parts)
                    print(f"{resource} filter string: {filter_string}")
                    base_query = base_query.or_(filter_string)

                for f in exact_filters:
                    col = f.get("column")
                    op = f.get("operator")
                    value = f.get("value")
                    if op == "eq":
                        base_query = base_query.eq(col, value)
                    elif op == "gte":
                        base_query = base_query.gte(col, value)
                    elif op == "lte":
                        base_query = base_query.lte(col, value)
                    elif op == "in":
                        base_query = base_query.in_(col, value)

            response = base_query.execute()

            # Fetch related data if requested
            if include_related and response.data:
                if resource == "submissions":
                    # Fetch submission_files for each submission
                    submission_ids = [s.get("id") for s in response.data if s.get("id")]
                    if submission_ids:
                        files_response = self.supabase.table("submission_files").select("*").in_("submission_id", submission_ids).execute()
                        # Group files by submission_id
                        files_by_submission = {}
                        for f in files_response.data:
                            sub_id = f.get("submission_id")
                            if sub_id not in files_by_submission:
                                files_by_submission[sub_id] = []
                            files_by_submission[sub_id].append(f)
                        # Attach files to submissions
                        for submission in response.data:
                            submission_id = submission.get("id")
                            submission["files"] = files_by_submission.get(submission_id, [])

                elif resource == "live_sessions":
                    # Fetch session_attendees for each session
                    session_ids = [s.get("id") for s in response.data if s.get("id")]
                    if session_ids:
                        attendees_response = self.supabase.table("session_attendees").select("*").in_("session_id", session_ids).execute()
                        # Group attendees by session_id
                        attendees_by_session = {}
                        for a in attendees_response.data:
                            sess_id = a.get("session_id")
                            if sess_id not in attendees_by_session:
                                attendees_by_session[sess_id] = []
                            attendees_by_session[sess_id].append(a)
                        # Attach attendees to sessions
                        for session in response.data:
                            session_id = session.get("id")
                            session["attendees"] = attendees_by_session.get(session_id, [])

                elif resource == "missions":
                    # Fetch briefs, mission_challenges
                    mission_ids = [m.get("id") for m in response.data if m.get("id")]
                    if mission_ids:
                        # Fetch briefs
                        briefs_response = self.supabase.schema("public").table("briefs").select("*").in_("mission_id", mission_ids).execute()
                        briefs_by_mission = {}
                        for b in briefs_response.data:
                            mission_id = b.get("mission_id")
                            if mission_id not in briefs_by_mission:
                                briefs_by_mission[mission_id] = []
                            briefs_by_mission[mission_id].append(b)

                        # Fetch mission_challenges — prioritize is_legacy=False, fallback to is_legacy=True
                        challenges_response = self.supabase.schema("public").table("challenges").select("*").in_("mission_id", mission_ids).eq("is_legacy", False).execute()
                        challenges_by_mission = {}
                        if challenges_response.data:
                            for c in challenges_response.data:
                                mission_id = c.get("mission_id")
                                if mission_id not in challenges_by_mission:
                                    challenges_by_mission[mission_id] = []
                                challenges_by_mission[mission_id].append(c)
                        # For missions with no non-legacy challenges, fallback to legacy
                        missing_ids = [mid for mid in mission_ids if mid not in challenges_by_mission]
                        if missing_ids:
                            legacy_challenges = self.supabase.schema("public").table("challenges").select("*").in_("mission_id", missing_ids).eq("is_legacy", True).execute()
                            for c in (legacy_challenges.data or []):
                                mission_id = c.get("mission_id")
                                if mission_id not in challenges_by_mission:
                                    challenges_by_mission[mission_id] = []
                                challenges_by_mission[mission_id].append(c)

                        # Attach related data to missions
                        for mission in response.data:
                            mission_id = mission.get("id")
                            mission["briefs"] = briefs_by_mission.get(mission_id, [])
                            mission["mission_challenges"] = challenges_by_mission.get(mission_id, [])

            text_response = ''
            if not response.data or len(response.data) == 0:
                text_response = f"No {resource} found"
            else:
                text_response = f"Found {len(response.data)} for {resource}" + "\n"

            result = {"content": text_response, "metadata": response.data}

            # Cache result if applicable
            if resource in self._cache_ttls and self.cache and not result.get("error"):
                try:
                    ttl = self._cache_ttls[resource]
                    cache_key = self._build_cache_key(resource, kwargs)
                    self.cache.setex(cache_key, ttl, json.dumps(result))
                    print(f"💾 Cached AIO data: {resource} (TTL: {ttl}s)")
                except Exception as e:
                    print(f"⚠️  Cache write error for {resource}: {e}")

            return result

        except Exception as e:
            print(f"❌ Error fetching **{resource}** info: {str(e)}")
            return {"error": str(e)}

    async def close(self):
        """Close HTTP client"""
        await self.http_client.aclose()


class ChallengeSubmissionTool:
    """Tool for handling challenge submissions"""

    def __init__(self):
        """Initialize the tool"""
        self.handler = DatabaseToolHandler()

    async def execute(
        self,
        email: str,
        space_name: str,
        files: Optional[List[str]] = None,
        chat_room_id: Optional[str] = None,
        skip_prior_check: bool = False,
        resolved_challenge_name: Optional[str] = None,
        challenge_metadata: Optional[Dict[str, Any]] = None,
        student_inputs: Optional[Dict[str, Dict[str, str]]] = None,
        text_content: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Execute challenge submission processing

        Args:
            email: Student's email
            space_name: Name of the space
            chat_room_id: ID of the chat room
            files: List of file URLs
            skip_prior_check: Skip prior submission check
            resolved_challenge_name: DEPRECATED — use challenge_metadata instead.
            challenge_metadata: Pre-resolved challenge dict (from fetch_challenge_by_uuid or detection).
            text_content: Raw text content from student's chat message

        Returns:
            Dictionary with submission results
        """
        try:
            result = await self.handler.process_submission(
                email, space_name, files, chat_room_id,
                skip_prior_check=skip_prior_check,
                resolved_challenge_name=resolved_challenge_name,
                challenge_metadata=challenge_metadata,
                student_inputs=student_inputs,
                text_content=text_content,
            )
            return result
        finally:
            await self.handler.close()


class LessonHTMLConverter:
    """Convert lesson HTML to Markdown with file extraction"""

    def __init__(self):
        """Initialize Supabase and LLM clients"""
        self.supabase = get_custom_client(
            os.getenv("AIO_SUPABASE_URL"), os.getenv("AIO_SUPABASE_SERVICE_ROLE_KEY")
        )
        self.llm = OpenRouterMultimodalLLM(model="google/gemini-2.0-flash-lite-001")
        self.http_client = httpx.AsyncClient(timeout=30.0)

        # Tracking stats
        self.stats = {
            "lessons_processed": 0,
            "lessons_updated": 0,
            "files_downloaded": 0,
            "files_uploaded": 0,
            "errors": [],
        }

    def extract_file_urls_from_html(self, html_content: str) -> List[Tuple[str, str]]:
        """
        Extract file URLs from HTML content

        Args:
            html_content: HTML string

        Returns:
            List of tuples (url, filename)
        """
        file_urls = []

        try:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(html_content, "html.parser")

            # Extract from <a> tags with class="file"
            for link in soup.find_all("a", href=True, class_="file"):
                href = link.get("href", "")
                if href:
                    filename = (
                        link.get_text(strip=True)
                        or href.split("/")[-1].split("?")[0]
                        or "file"
                    )
                    file_urls.append((href, filename))

            # Extract from <img> tags with src
            for img in soup.find_all("img", src=True):
                src = img.get("src", "")
                if src and not src.startswith("data:"):
                    filename = (
                        img.get("alt", "image")
                        or src.split("/")[-1].split("?")[0]
                        or "image.jpg"
                    )
                    file_urls.append((src, filename))

            # Extract from <video> and <audio> tags
            for media in soup.find_all(["video", "audio"]):
                for source in media.find_all("source", src=True):
                    src = source.get("src", "")
                    if src and not src.startswith("data:"):
                        filename = (
                            src.split("/")[-1].split("?")[0] or f"{media.name}.mp4"
                        )
                        file_urls.append((src, filename))
            print(file_urls)
            print(f"Extracted {len(file_urls)} file URLs from HTML")
            return file_urls

        except Exception as e:
            print(f"Error extracting file URLs: {str(e)}")
            return []

    async def download_file_bytes(self, url: str, filename: str) -> Optional[bytes]:
        """
        Download file from URL

        Args:
            url: File URL
            filename: Original filename

        Returns:
            File bytes or None
        """
        try:
            # Handle relative URLs
            if url.startswith("/"):
                # Assume it's from the same domain as Supabase
                url = f"https://app.circle.so{url}"

            response = await self.http_client.get(url, follow_redirects=True)
            response.raise_for_status()

            print(f"Downloaded {filename} ({len(response.content)} bytes)")
            return response.content

        except Exception as e:
            print(f"Error downloading {filename} from {url}: {str(e)}")
            return None

    def get_mime_type(self, filename: str) -> str:
        """Get MIME type from filename"""
        ext_to_mime = {
            ".pdf": "application/pdf",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".png": "image/png",
            ".gif": "image/gif",
            ".webp": "image/webp",
            ".doc": "application/msword",
            ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            ".xls": "application/vnd.ms-excel",
            ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            ".ppt": "application/vnd.ms-powerpoint",
            ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            ".zip": "application/zip",
            ".mp4": "video/mp4",
            ".avi": "video/x-msvideo",
            ".mov": "video/quicktime",
            ".mkv": "video/x-matroska",
            ".webm": "video/webm",
            ".mp3": "audio/mpeg",
            ".wav": "audio/wav",
            ".m4a": "audio/mp4",
        }

        ext = os.path.splitext(filename)[1].lower()
        return ext_to_mime.get(ext, "application/octet-stream")

    async def upload_file_to_storage(
        self, file_bytes: bytes, filename: str, lesson_id: int
    ) -> Optional[str]:
        """
        Upload file to Supabase storage bucket "lesson_attachments"

        Args:
            file_bytes: File content
            filename: Original filename
            lesson_id: ID of the lesson

        Returns:
            Storage URL or None
        """
        try:
            mime_type = self.get_mime_type(filename)
            formatted_filename = filename.replace(" - ", "_").replace(" ", "_")

            # Use upload_to_storage with custom path
            # We need to upload directly to storage with custom path
            storage_path = f"{lesson_id}/{formatted_filename}"

            result = upload_to_storage(
                self.supabase,
                mime_type,
                file_bytes,
                "lesson_attachments",
                storage_path,
                url_exp=60 * 60 * 24 * 365,
            )

            print(f"Uploaded {filename} to storage: {storage_path}")

            storage_path = result.get("path")
            print(f"Generated signed URL for {filename}")

            self.stats["files_uploaded"] += 1
            return storage_path

        except Exception as e:
            print(f"Error uploading {filename} to storage: {str(e)}")
            return None

    async def convert_html_to_markdown(
        self, html_content: str, lesson_name: str
    ) -> str:
        """
        Convert HTML to Markdown using LLM

        Args:
            html_content: HTML string
            lesson_name: Name of the lesson (for context)

        Returns:
            Markdown formatted string
        """
        try:
            system_prompt = """You are an expert at converting HTML to clean, well-formatted Markdown.

## Conversion Rules:
1. Convert HTML headings (h1-h6) to Markdown headings (#, ##, etc.)
2. Convert paragraphs to plain text with proper spacing
3. Convert lists (ul, ol) to Markdown lists (-, 1., etc.)
4. Convert bold/strong to **text**
5. Convert italic/em to *text*
6. Convert links to [text](url) format
7. Convert tables to Markdown table format
8. Convert code blocks to ```language code blocks
9. Remove unnecessary HTML tags and attributes
10. Preserve the document structure and hierarchy
11. Add proper spacing between sections
12. Remove any embedded file references or broken links

## Output Format:
Return ONLY the Markdown content, no explanations or additional text."""

            user_message = f"""Convert this HTML to clean Markdown.

Lesson: {lesson_name}

HTML Content:
{html_content}"""

            messages = [
                ChatMessage(role="system", content=system_prompt),
                ChatMessage(role="user", content=user_message),
            ]

            print(f"Converting HTML to Markdown for lesson: {lesson_name}")
            response = await self.llm.achat(messages)
            markdown_content = response.message.content.strip()

            print(
                f"Successfully converted HTML to Markdown ({len(markdown_content)} chars)"
            )
            return markdown_content

        except Exception as e:
            print(f"Error converting HTML to Markdown: {str(e)}")
            return ""

    async def fetch_lesson(self, lesson_id: int) -> Dict:
        """
        Fetch a single lesson from Supabase

        Args:
            lesson_id: ID of the lesson

        Returns:
            Lesson record from Supabase
        """
        try:
            response = (
                self.supabase.table("lessons")
                .select("id, name, body_html")
                .eq("id", lesson_id)
                .execute()
            )

            if not response.data or len(response.data) == 0:
                raise Exception(f"Lesson {lesson_id} not found")

            lesson = response.data[0]
            return lesson

        except Exception as e:
            raise Exception(f"Error fetching lesson {lesson_id}: {str(e)}")

    async def process_lesson(self, lesson_id: int) -> bool:
        """
        Process a single lesson: convert HTML to Markdown and handle files

        Args:
            lesson_id: ID of the lesson

        Returns:
            True if successful, False otherwise
        """
        try:
            lesson = await self.fetch_lesson(lesson_id)
            lesson_name = lesson.get("name", "Unknown")
            html_content = lesson.get("body_html", "")

            print(f"\n{'='*60}")
            print(f"Processing lesson: {lesson_name} (ID: {lesson_id})")
            print(f"{'='*60}")

            if not html_content:
                print(f"No HTML content found for lesson {lesson_id}")
                return False

            # Step 1: Extract file URLs from HTML
            print("Step 1: Extracting file URLs from HTML...")
            file_urls = self.extract_file_urls_from_html(html_content)

            attachment_urls = []

            # Step 2: Download and upload files
            if file_urls:
                print(f"Step 2: Processing {len(file_urls)} files...")

                for url, filename in file_urls:
                    print(f"   Processing: {filename}")

                    # Download file
                    file_bytes = await self.download_file_bytes(url, filename)
                    if not file_bytes:
                        print(f"   ⚠ Skipped: {filename}")
                        continue

                    self.stats["files_downloaded"] += 1

                    # Upload to storage
                    storage_url = await self.upload_file_to_storage(
                        file_bytes, filename, lesson_id
                    )
                    if storage_url:
                        attachment_urls.append(storage_url)
                        print(f"   ✓ Uploaded: {filename}")
                    else:
                        print(f"   ⚠ Upload failed: {filename}")
            else:
                print("Step 2: No files to process")

            # Step 3: Convert HTML to Markdown
            print("Step 3: Converting HTML to Markdown...")
            markdown_content = await self.convert_html_to_markdown(
                html_content, lesson_name
            )

            if not markdown_content:
                print(f"Failed to convert HTML to Markdown for lesson {lesson_id}")
                return False

            # Step 4: Update lesson in Supabase
            print("Step 4: Updating lesson in Supabase...")

            update_data = {"markdown": markdown_content}

            if attachment_urls:
                update_data["attachments"] = attachment_urls

            response = (
                self.supabase.table("lessons")
                .update(update_data)
                .eq("id", lesson_id)
                .execute()
            )

            if response.data:
                print(f"✅ Updated lesson {lesson_id}")
                print(f"   - Markdown: {len(markdown_content)} characters")
                print(f"   - Attachments: {len(attachment_urls)} files")
                self.stats["lessons_updated"] += 1
                return True
            else:
                print(f"Failed to update lesson {lesson_id}")
                return False

        except Exception as e:
            error_msg = f"Error processing lesson {lesson.get('id')}: {str(e)}"
            print(error_msg)
            self.stats["errors"].append(error_msg)
            return False


import os
from typing import Dict, Any, Optional
from dotenv import load_dotenv

load_dotenv()

class TypeformDataSyncTool:
    """Sync Typeform data to Supabase database"""

    def __init__(self, instructor_id: Optional[str] = None):
        """
        Initialize Typeform Data Sync Tool

        Args:
            instructor_id: UUID of the instructor creating forms (defaults to system user)
        """
        self.aio_supabase_url = os.getenv("AIO_SUPABASE_URL")
        self.aio_supabase_service_role_key = os.getenv("AIO_SUPABASE_SERVICE_ROLE_KEY")

        if not self.aio_supabase_url or not self.aio_supabase_service_role_key:
            raise ValueError(
                "AIO_SUPABASE_URL and AIO_SUPABASE_SERVICE_ROLE_KEY environment variables must be set"
            )

        # Initialize Supabase client
        self.supabase_client: Client = get_custom_client(
            self.aio_supabase_url, self.aio_supabase_service_role_key
        )

        # Initialize Typeform connectors
        self.typeform_forms = TypeformForms()
        self.typeform_responses = TypeformResponses()

        # Default instructor ID (system user)
        self.instructor_id = instructor_id or "00000000-0000-0000-0000-000000000000"

    async def sync_all_forms(self) -> Dict[str, Any]:
        """
        Fetch all forms from Typeform API and sync to Supabase

        Returns:
            Dictionary with sync results
        """
        print("📥 Fetching all forms from Typeform API...")
        try:
            # Fetch all forms from Typeform
            forms_response = await self.typeform_forms.list_forms(page_size=200)
            forms_list = forms_response.get("items", [])

            if not forms_list:
                print("⚠️ No forms found in Typeform account")
                return {
                    "status": "success",
                    "forms_synced": 0,
                    "questions_synced": 0,
                    "responses_synced": 0,
                    "answers_synced": 0,
                }

            print(f"✅ Found {len(forms_list)} forms")

            # Sync each form
            total_forms = 0
            total_questions = 0
            total_responses = 0
            total_answers = 0
            failed_forms = []

            for form_summary in forms_list:
                form_id = form_summary.get("id")
                try:
                    # Fetch detailed form structure
                    form_response = await self.typeform_forms.get_form(form_id)
                    form_data = form_response

                    # Sync form and questions
                    form_result = await self._sync_form_and_questions(form_data)
                    total_forms += form_result.get("forms_synced", 0)
                    total_questions += form_result.get("questions_synced", 0)

                    # Sync responses
                    response_result = await self._sync_form_responses(
                        form_id, form_result.get("form_db_id")
                    )
                    total_responses += response_result.get("responses_synced", 0)
                    total_answers += response_result.get("answers_synced", 0)

                    print(f"✅ Synced form: {form_summary.get('title', form_id)}")

                except Exception as e:
                    print(f"❌ Error syncing form {form_id}: {str(e)}")
                    failed_forms.append({"form_id": form_id, "error": str(e)})

            return {
                "status": "success",
                "forms_synced": total_forms,
                "questions_synced": total_questions,
                "responses_synced": total_responses,
                "answers_synced": total_answers,
                "failed_forms": failed_forms,
            }

        except Exception as e:
            print(f"❌ Error fetching forms: {str(e)}")
            return {"status": "error", "error": str(e)}

    async def _sync_form_and_questions(
        self, form_data: TypeformForm
    ) -> Dict[str, Any]:
        """
        Sync form structure and questions to database

        Args:
            form_data: TypeformForm data from API

        Returns:
            Dictionary with sync results including form_db_id
        """
        try:
            form_id = form_data.get("id")
            form_title = form_data.get("title", "Untitled Form")
            form_type = form_data.get("type", "form")
            created_at = form_data.get("created_at")
            updated_at = form_data.get("last_updated_at") or form_data.get("updated_at")

            # Map Typeform type to database form_type
            form_type_map = {
                "quiz": "assessment",
                "survey": "survey",
                "form": "feedback",
            }
            db_form_type = form_type_map.get(form_type, "feedback")

            # Generate UUID for form
            form_db_id = str(uuid.uuid4())

            # Prepare form data for insertion
            form_insert_data = {
                "id": form_db_id,
                "name": form_title,
                "slug": form_id,  # Use Typeform ID as slug
                "description": form_data.get("description"),
                "form_type": db_form_type,
                "status": "published",
                "instructor_id": self.instructor_id,
                "submission_count": 0,
                "created_at": created_at,
                "updated_at": updated_at,
                "allow_anonymous": True,
                "show_progress_bar": True,
                "randomize_questions": False,
                "settings": {
                    "typeform_id": form_id,
                    "typeform_type": form_type,
                    "welcome_screens": form_data.get("welcome_screens", []),
                    "thank_you_screens": form_data.get("thank_you_screens", []),
                },
            }

            # Insert form
            form_response = (
                self.supabase_client.table("forms").insert(form_insert_data).execute()
            )

            if not form_response.data:
                raise Exception("Failed to insert form")

            print(f"   ✅ Inserted form: {form_title}")

            # Sync questions
            fields = form_data.get("fields", [])
            questions_synced = 0

            for display_order, field in enumerate(fields, 1):
                try:
                    question_result = await self._sync_question(
                        form_db_id, field, display_order
                    )
                    if question_result:
                        questions_synced += 1
                except Exception as e:
                    print(f"   ⚠️ Error syncing question: {str(e)}")

            print(f"   ✅ Synced {questions_synced} questions")

            return {
                "forms_synced": 1,
                "questions_synced": questions_synced,
                "form_db_id": form_db_id,
            }

        except Exception as e:
            print(f"❌ Error syncing form and questions: {str(e)}")
            return {"forms_synced": 0, "questions_synced": 0, "form_db_id": None}

    async def _sync_question(
        self, form_db_id: str, field: TypeformField, display_order: int
    ) -> bool:
        """
        Sync a single question to database

        Args:
            form_db_id: Database form ID
            field: TypeformField data
            display_order: Display order of the question

        Returns:
            True if successful, False otherwise
        """
        try:
            field_id = field.get("id")
            field_type = field.get("type")
            field_title = field.get("title", "Untitled Question")

            # Map Typeform field types to database question types
            field_type_map = {
                "short_text": "text",
                "long_text": "textarea",
                "email": "email",
                "number": "number",
                "dropdown": "multiple_choice",
                "multiple_choice": "multiple_choice",
                "nps": "rating",
                "opinion_scale": "rating",
                "rating": "rating",
                "yes_no": "checkbox",
                "date": "date",
                "time": "text",
                "phone_number": "text",
                "file_upload": "file_upload",
                "contact_info": "text",
                "statement": "text",
            }

            db_question_type = field_type_map.get(field_type, "text")

            # Extract validation rules
            validations = field.get("validations", {})
            validation_rules = {
                "required": validations.get("required", False),
                "typeform_type": field_type,
                "typeform_ref": field.get("ref"),
            }

            # Extract options for choice fields
            options = None
            properties = field.get("properties", {})
            if properties.get("choices"):
                options = {
                    "choices": [
                        {"id": c.get("id"), "label": c.get("label"), "ref": c.get("ref")}
                        for c in properties.get("choices", [])
                    ]
                }

            # Extract contact info subfields and sync them as separate questions
            subfields = properties.get("fields", [])
            if subfields:
                options = {
                    "subfields": [
                        {
                            "id": f.get("id"),
                            "ref": f.get("ref"),
                            "title": f.get("title"),
                            "subfield_key": f.get("subfield_key"),
                            "type": f.get("type"),
                        }
                        for f in subfields
                    ]
                }

            # Prepare question data
            question_insert_data = {
                "id": str(uuid.uuid4()),
                "form_id": form_db_id,
                "question_text": field_title,
                "question_type": db_question_type,
                "display_order": display_order,
                "is_required": validations.get("required", False),
                "help_text": field.get("properties", {}).get("description"),
                "placeholder_text": None,
                "validation_rules": validation_rules,
                "options": options,
                "default_value": None,
            }

            # Insert question
            question_response = (
                self.supabase_client.table("form_questions")
                .insert(question_insert_data)
                .execute()
            )

            if not question_response.data:
                raise Exception("Failed to insert question")

            # Sync subfields as separate questions (for contact_info fields)
            if subfields:
                for subfield_order, subfield in enumerate(subfields, 1):
                    await self._sync_subfield_question(
                        form_db_id, subfield, display_order * 100 + subfield_order
                    )

            return True

        except Exception as e:
            print(f"❌ Error syncing question: {str(e)}")
            return False

    async def _sync_subfield_question(
        self, form_db_id: str, subfield: Dict[str, Any], display_order: int
    ) -> bool:
        """
        Sync a contact_info subfield as a separate question entry.
        This allows answers to subfields to be properly linked.

        Args:
            form_db_id: Database form ID
            subfield: Subfield data from contact_info field
            display_order: Display order of the question

        Returns:
            True if successful, False otherwise
        """
        try:
            subfield_type = subfield.get("type", "short_text")
            
            # Map subfield types
            type_map = {
                "short_text": "text",
                "email": "email",
                "phone_number": "text",
            }
            db_question_type = type_map.get(subfield_type, "text")

            validations = subfield.get("validations", {})
            validation_rules = {
                "required": validations.get("required", False),
                "typeform_type": subfield_type,
                "typeform_ref": subfield.get("ref"),
                "is_subfield": True,
                "subfield_key": subfield.get("subfield_key"),
            }

            question_insert_data = {
                "id": str(uuid.uuid4()),
                "form_id": form_db_id,
                "question_text": subfield.get("title", "Untitled"),
                "question_type": db_question_type,
                "display_order": display_order,
                "is_required": validations.get("required", False),
                "help_text": None,
                "placeholder_text": None,
                "validation_rules": validation_rules,
                "options": None,
                "default_value": None,
            }

            question_response = (
                self.supabase_client.table("form_questions")
                .insert(question_insert_data)
                .execute()
            )

            if not question_response.data:
                raise Exception("Failed to insert subfield question")

            return True

        except Exception as e:
            print(f"❌ Error syncing subfield question: {str(e)}")
            return False

    async def _sync_form_responses(
        self, typeform_id: str, form_db_id: Optional[str]
    ) -> Dict[str, Any]:
        """
        Sync form responses to database

        Args:
            typeform_id: Typeform form ID
            form_db_id: Database form ID

        Returns:
            Dictionary with sync results
        """
        if not form_db_id:
            return {"responses_synced": 0, "answers_synced": 0}

        try:
            # Fetch responses from Typeform
            responses_data = await self.typeform_responses.get_responses(
                typeform_id, page_size=100
            )
            responses_list = responses_data.get("items", [])

            if not responses_list:
                print(f"   ℹ️ No responses found for form {typeform_id}")
                return {"responses_synced": 0, "answers_synced": 0}

            print(f"   📥 Syncing {len(responses_list)} responses...")

            responses_synced = 0
            answers_synced = 0

            for response in responses_list:
                try:
                    response_result = await self._sync_response(
                        form_db_id, response
                    )
                    if response_result:
                        responses_synced += 1
                        answers_synced += response_result.get("answers_count", 0)
                except Exception as e:
                    print(f"   ⚠️ Error syncing response: {str(e)}")

            print(f"   ✅ Synced {responses_synced} responses with {answers_synced} answers")

            return {
                "responses_synced": responses_synced,
                "answers_synced": answers_synced,
            }

        except Exception as e:
            print(f"❌ Error syncing responses: {str(e)}")
            return {"responses_synced": 0, "answers_synced": 0}

    async def _sync_response(
        self, form_db_id: str, response: TypeformResponse
    ) -> Optional[Dict[str, Any]]:
        """
        Sync a single response to database

        Args:
            form_db_id: Database form ID
            response: TypeformResponse data

        Returns:
            Dictionary with sync results or None on error
        """
        try:
            response_id = response.get("response_id")
            submitted_at = response.get("submitted_at")
            response_type = response.get("response_type", "completed")

            # Extract submitter email and name from answers
            submitter_email = "anonymous@typeform.local"
            submitter_name = None

            answers = response.get("answers", [])
            for answer in answers:
                field_type = answer.get("field", {}).get("type")
                answer_type = answer.get("type")
                
                # Email field (including contact_info subfield)
                if field_type == "email" or answer_type == "email":
                    email_value = answer.get("email") or answer.get("text")
                    if email_value:
                        submitter_email = email_value
                
                # Try to get name from short_text fields with first_name ref pattern
                if field_type == "short_text" and not submitter_name:
                    field_ref = answer.get("field", {}).get("ref", "")
                    # Check if this looks like a name field
                    if answer.get("text"):
                        submitter_name = answer.get("text")

            # Prepare submission data (matching form_submissions table schema)
            metadata = response.get("metadata", {})
            submission_insert_data = {
                "id": str(uuid.uuid4()),
                "form_id": form_db_id,
                "submitter_email": submitter_email,
                "submitter_name": submitter_name,
                "status": "submitted" if response_type == "completed" else "draft",
                "submitted_at": submitted_at,
                "ip_address": metadata.get("ip_address"),
                "user_agent": metadata.get("user_agent"),
            }

            # Insert submission
            submission_response = (
                self.supabase_client.table("form_submissions")
                .insert(submission_insert_data)
                .execute()
            )

            if not submission_response.data:
                raise Exception("Failed to insert submission")

            submission_db_id = submission_response.data[0].get("id")

            # Sync answers
            answers_count = 0
            for answer in answers:
                try:
                    answer_result = await self._sync_answer(
                        submission_db_id, form_db_id, answer
                    )
                    if answer_result:
                        answers_count += 1
                except Exception as e:
                    print(f"   ⚠️ Error syncing answer: {str(e)}")

            return {"submission_id": submission_db_id, "answers_count": answers_count}

        except Exception as e:
            print(f"❌ Error syncing response: {str(e)}")
            return None

    async def _sync_answer(
        self, submission_db_id: str, form_db_id: str, answer: TypeformAnswer
    ) -> bool:
        """
        Sync a single answer to database

        Args:
            submission_db_id: Database submission ID
            form_db_id: Database form ID
            answer: TypeformAnswer data

        Returns:
            True if successful, False otherwise
        """
        try:
            field_id = answer.get("field", {}).get("id")
            answer_type = answer.get("type")

            # Extract answer value based on type
            answer_value = None
            if answer_type == "text":
                answer_value = answer.get("text")
            elif answer_type == "email":
                answer_value = answer.get("email") or answer.get("text")
            elif answer_type == "number":
                answer_value = str(answer.get("number"))
            elif answer_type == "choice":
                choice = answer.get("choice", {})
                answer_value = choice.get("label")
            elif answer_type == "choices":
                choices = answer.get("choices", {})
                # Handle both list format and dict format with labels array
                if isinstance(choices, list):
                    answer_value = "; ".join(c.get("label", "") for c in choices)
                elif isinstance(choices, dict) and choices.get("labels"):
                    answer_value = "; ".join(choices.get("labels", []))
            elif answer_type == "date":
                answer_value = answer.get("date")
            elif answer_type == "time":
                answer_value = answer.get("time")
            elif answer_type == "boolean":
                answer_value = str(answer.get("boolean"))
            elif answer_type == "file_url":
                answer_value = answer.get("file_url")
            elif answer_type == "phone_number":
                answer_value = answer.get("phone_number") or answer.get("text")
            else:
                answer_value = str(answer.get(answer_type, ""))

            if not answer_value:
                return False

            # Get question ID from field ID
            questions_response = (
                self.supabase_client.table("form_questions")
                .select("id")
                .eq("form_id", form_db_id)
                .filter("validation_rules->>typeform_ref", "eq", answer.get("field", {}).get("ref"))
                .execute()
            )

            if not questions_response.data:
                print(f"   ⚠️ Question not found for field {field_id}")
                return False

            question_db_id = questions_response.data[0].get("id")

            # Prepare answer data
            answer_insert_data = {
                "id": str(uuid.uuid4()),
                "submission_id": submission_db_id,
                "question_id": question_db_id,
                "answer_value": answer_value,
                "answer_type": answer_type,
                "is_valid": True,
            }

            # Insert answer
            answer_response = (
                self.supabase_client.table("form_submission_answers")
                .insert(answer_insert_data)
                .execute()
            )

            if not answer_response.data:
                raise Exception("Failed to insert answer")

            return True

        except Exception as e:
            print(f"❌ Error syncing answer: {str(e)}")
            return False


__all__ = [
    "DatabaseToolHandler",
    "ChallengeSubmissionTool",
    "TypeformDataSyncTool",
    "LessonHTMLConverter"
]
