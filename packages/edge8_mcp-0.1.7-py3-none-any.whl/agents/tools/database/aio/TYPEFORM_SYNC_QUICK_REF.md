# Typeform Data Sync Tool - Quick Reference

## Quick Start

```python
from src.agents.tools.database.aio import TypeformDataSyncTool
import asyncio

async def main():
    sync_tool = TypeformDataSyncTool()
    result = await sync_tool.sync_all_forms()
    print(result)

asyncio.run(main())
```

---

## Output

```python
{
    "status": "success",
    "forms_synced": 8,
    "questions_synced": 42,
    "responses_synced": 156,
    "answers_synced": 1248,
    "failed_forms": []
}
```

---

## With Custom Instructor

```python
sync_tool = TypeformDataSyncTool(
    instructor_id="550e8400-e29b-41d4-a716-446655440000"
)
result = await sync_tool.sync_all_forms()
```

---

## Data Mapping

### Form Types
- `quiz` → `assessment`
- `survey` → `survey`
- `form` → `feedback`

### Field Types
| Typeform | Database |
|----------|----------|
| short_text | text |
| long_text | textarea |
| email | email |
| number | number |
| dropdown | multiple_choice |
| multiple_choice | multiple_choice |
| nps | rating |
| opinion_scale | rating |
| rating | rating |
| yes_no | checkbox |
| date | date |
| phone_number | text |
| file_upload | file_upload |

---

## Database Tables

1. **forms** - Form metadata
2. **form_questions** - Questions/fields
3. **form_submissions** - Responses
4. **form_submission_answers** - Individual answers

---

## Environment Variables

```bash
AIO_SUPABASE_URL=https://your-project.supabase.co
AIO_SUPABASE_SERVICE_ROLE_KEY=your-key
TYPEFORM_ACCESS_TOKEN=your-token
```

---

## Error Handling

```python
result = await sync_tool.sync_all_forms()

if result["status"] == "error":
    print(f"Error: {result['error']}")

if result.get("failed_forms"):
    for failed in result["failed_forms"]:
        print(f"Failed: {failed['form_id']}: {failed['error']}")
```

---

## Methods

| Method | Purpose |
|--------|---------|
| `sync_all_forms()` | Main entry point |
| `_sync_form_and_questions()` | Sync form + questions |
| `_sync_form_responses()` | Sync responses |
| `_sync_response()` | Sync single response |
| `_sync_answer()` | Sync single answer |

---

## Performance

- **Total time**: ~30-50 seconds for 8 forms + 156 responses
- **Forms**: 2-5s
- **Questions**: 2-3s
- **Responses**: 10-15s
- **Answers**: 15-20s

---

## Logging Output

```
📥 Fetching all forms from Typeform API...
✅ Found 8 forms
✅ Synced form: Community Course Mission
   ✅ Inserted form: Community Course Mission
   ✅ Synced 8 questions
   📥 Syncing 35 responses...
   ✅ Synced 35 responses with 280 answers
```

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| SUPABASE_URL not found | Add to .env |
| TYPEFORM_TOKEN not found | Add to .env |
| Failed to insert form | Check DDL schema |
| Question not found | Ensure questions synced first |

---

## Integration

```python
from src.agents.tools.database.aio import TypeformDataSyncTool

# In agent
sync_tool = TypeformDataSyncTool()
result = await sync_tool.sync_all_forms()

# In workflow
async def sync_workflow():
    sync_tool = TypeformDataSyncTool()
    return await sync_tool.sync_all_forms()
```

---

## Files

- **Implementation**: `src/agents/tools/database/aio.py`
- **Schema**: `tests/typeform_exports/form_tables_ddl.sql`
- **Guide**: `src/agents/tools/database/TYPEFORM_SYNC_GUIDE.md`
- **Connectors**: `src/connectors/typeform/`
- **Types**: `src/utils/custom_types.py`

---

**Status**: ✅ Production Ready
