# Tools Module

## Purpose

The tools module contains all tool definitions, schemas, and handlers for the agent system. Tools are specialized functions that agents can execute to interact with external platforms and perform operations.

## Folder Structure

```
src/agents/tools/
├── schema.py              # Tool schema definitions and registry
├── handlers.py            # Tool execution handlers
├── shared.py              # Shared utilities and base classes
├── schemas/               # Tool schema definitions by category
│   ├── general_tools.py   # Web search, formatting, etc.
│   ├── lark_tools.py      # Lark platform tools
│   ├── circle_tools.py    # Circle community tools
│   ├── typeform_tools.py  # Typeform integration tools
│   └── rag_tools.py       # RAG/vector search tools
├── lark/                  # Lark tool handlers
│   ├── doc_handler.py     # Document operations
│   ├── meeting_handler.py # Meeting operations
│   └── ...                # Other Lark handlers
├── circle/                # Circle tool handlers
│   ├── post_handler.py    # Post operations
│   ├── sync_handler.py    # Data sync operations
│   └── ...                # Other Circle handlers
└── database/              # Database tool handlers
    ├── aio/               # AIO LMS database tools
    │   └── aio.py         # Student, challenge, submission tools
    └── vector/            # Vector search tools
        └── vector_handler.py # RAG search handler
```

## Tool Architecture

### Tool Components

```
ToolSchema (Definition)
    ↓
ToolHandler (Implementation)
    ↓
ToolExecutionResult (Output)
```

### 1. ToolSchema

**Purpose:** Defines tool metadata and parameters for LLM consumption

**Structure:**
```python
from pydantic import BaseModel, Field
from typing import Dict, Any, Optional, Callable

class ToolSchema(BaseModel):
    name: str = Field(..., description="Unique tool name")
    description: str = Field(..., description="What the tool does")
    parameters: Dict[str, Any] = Field(..., description="JSON schema for parameters")
    handler: Callable = Field(..., description="Tool execution handler")
    group: Optional[str] = Field(default=None, description="Tool group")
    
    def to_openrouter_tool_schema(self) -> Dict[str, Any]:
        """Convert to OpenRouter tool format"""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters
            }
        }
    
    class Config:
        json_schema_extra = {
            "example": {
                "name": "create_lark_document",
                "description": "Create a new document in Lark",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "title": {"type": "string"},
                        "content": {"type": "string"}
                    },
                    "required": ["title", "content"]
                },
                "group": "lark"
            }
        }
```

### 2. ToolHandler

**Purpose:** Implements tool execution logic

**Base Class:**
```python
from abc import ABC, abstractmethod
from typing import Any, Dict
from pydantic import BaseModel

class ToolExecutionResult(BaseModel):
    success: bool
    result: Any = None
    error: Optional[str] = None
    metadata: Dict[str, Any] = {}

class BaseToolHandler(ABC):
    """Base class for all tool handlers"""
    
    @abstractmethod
    async def execute(self, **kwargs) -> ToolExecutionResult:
        """Execute the tool with given parameters"""
        pass
    
    def validate_params(self, schema: Dict, params: Dict) -> bool:
        """Validate parameters against schema"""
        # Validation logic
        pass
```

### 3. Tool Registration

**Location:** `schema.py` and `schemas/` directory

```python
from typing import List
from src.agents.tools.schemas import (
    GENERAL_TOOLS,
    LARK_TOOLS,
    CIRCLE_TOOLS,
    TYPEFORM_TOOLS,
    RAG_TOOLS
)

# Aggregated tool registry
AVAILABLE_TOOLS: List[ToolSchema] = [
    *GENERAL_TOOLS,
    *LARK_TOOLS,
    *CIRCLE_TOOLS,
    *TYPEFORM_TOOLS,
    *RAG_TOOLS
]

# Tool group definitions
TOOL_GROUP_DEFINITIONS = {
    'general': 'Use for general actions, search, or external data access',
    'lark_doc': 'Use for Lark document operations',
    'lark_events': 'Use for Lark calendar events',
    'lark_meetings': 'Use for Lark meeting operations',
    'circle_aio': 'Use for Circle AI Officer Community operations',
    'grading_system': 'Use for student assignment submissions'
}

# Get tools by group
def get_tools_by_group(group: str) -> List[ToolSchema]:
    if group == "general":
        return GENERAL_TOOLS
    if group == "circle_aio":
        return RAG_TOOLS  # Vector search for AIO content
    # ... more groups
```

## Tool Categories

### 1. RAG Tools (Vector Search)

**Location:** `src/agents/tools/schemas/rag_tools.py`

**Tools:**
- `search_challenges` - Search for challenges/missions by query
- `search_series` - Search for series/programs
- `search_events` - Search for upcoming events
- `get_student_progress` - Get student progress and enrollments
- `get_challenge_details` - Get detailed challenge information

**Handler:** `src/agents/tools/database/vector/vector_handler.py`

**Features:**
- Vector similarity search using embeddings
- Filters by entity type (challenge, series, event)
- Returns ranked results with metadata
- Integrates with AIO database schema

### 2. Circle Tools (Sync & Operations)

**Location:** `src/agents/tools/schemas/circle_tools.py`

**Categories:**

#### Sync Operations
- `circle_sync_all` - Sync all Circle data
- `circle_space_groups_sync` - Sync space groups
- `circle_spaces_sync` - Sync spaces
- `circle_posts_sync` - Sync posts
- `circle_topics_sync` - Sync topics
- `circle_member_engagement_sync` - Sync member engagement
- `circle_student_brief_progress_sync` - Sync student progress

#### Data Operations
- `circle_message` - Send message to Circle
- `challenge_submission` - Submit challenge assignment
- `lesson_html_converter` - Convert lesson HTML
- `circle_members_handler` - Handle member operations

**Handler:** `src/agents/tools/circle/` (various handlers)

**Features:**
- Automated data synchronization from Circle API
- Incremental sync with last_synced tracking
- Batch processing for large datasets
- Integration with Supabase for persistence

### 3. Database Tools (AIO LMS)

**Location:** `src/agents/tools/database/aio/aio.py`

**Handler:** `DatabaseToolHandler`

**Resources:**
- `students` - Student records and profiles
- `enrollments` - Program/series enrollments
- `student_progress` - Learning progress tracking
- `challenge_submissions` - Assignment submissions
- `challenges` - Challenge/mission metadata
- `series` - Program/series metadata
- `events` - Upcoming events

**Operations:**
```python
# Get student by email
result = await handler.execute(resource="students", email="student@example.com")

# Get enrollments
result = await handler.execute(resource="enrollments", email="student@example.com")

# Get progress
result = await handler.execute(resource="student_progress", email="student@example.com")

# Submit challenge
result = await handler.execute(
    resource="challenge_submissions",
    action="create",
    data={"student_id": "...", "challenge_id": "...", ...}
)
```

**Features:**
- Unified interface for all AIO database operations
- Redis caching for frequently accessed data
- Automatic email-to-ID resolution
- Support for filters and pagination

## Tool Implementation

### Example: RAG Search Tool

**Schema Definition:**
```python
# In schemas/rag_tools.py
search_challenges_tool = ToolSchema(
    name="search_challenges",
    description="Search for challenges/missions using semantic search",
    parameters={
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": "Search query for challenges"
            },
            "limit": {
                "type": "integer",
                "description": "Maximum number of results",
                "default": 5
            }
        },
        "required": ["query"]
    },
    handler=search_challenges_handler
)
```

**Handler Implementation:**
```python
# In database/vector/vector_handler.py
async def search_challenges_handler(**kwargs) -> Dict[str, Any]:
    """Search for challenges using vector similarity"""
    query = kwargs.get("query")
    limit = kwargs.get("limit", 5)
    
    try:
        # Generate embedding for query
        embedding = await generate_embedding(query)
        
        # Vector similarity search
        results = await supabase.rpc(
            "search_challenges",
            {
                "query_embedding": embedding,
                "match_threshold": 0.7,
                "match_count": limit
            }
        ).execute()
        
        return {
            "success": True,
            "results": results.data,
            "count": len(results.data)
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }
```

### Example: Database Tool

**Schema Definition:**
```python
# In schemas/rag_tools.py
get_student_progress_tool = ToolSchema(
    name="get_student_progress",
    description="Get student progress, enrollments, and submissions",
    parameters={
        "type": "object",
        "properties": {
            "email": {
                "type": "string",
                "description": "Student email address"
            }
        },
        "required": ["email"]
    },
    handler=get_student_progress_handler
)
```

**Handler Implementation:**
```python
# In database/aio/aio.py
class DatabaseToolHandler:
    async def execute(self, resource: str, **kwargs) -> Dict[str, Any]:
        """Execute database operation"""
        email = kwargs.get("email")
        
        if resource == "student_progress":
            # Get student ID from email
            student = await self._get_student_by_email(email)
            if not student:
                return {"success": False, "error": "Student not found"}
            
            # Get progress data
            progress = await supabase.table("student_progress")
                .select("*")
                .eq("student_id", student["id"])
                .execute()
            
            return {
                "success": True,
                "data": progress.data
            }
```

### Tool Groups

**Current Groups:**

1. **general** - Web search, text formatting, URL extraction
2. **lark_doc** - Lark document operations
3. **lark_events** - Lark calendar and events
4. **lark_meetings** - Lark meeting transcripts and summaries
5. **circle_aio** - RAG search for AIO content (challenges, series, events)
6. **grading_system** - Assignment submission and grading

**Tool Group Selection:**
```python
def get_tools_by_group(group: str) -> List[ToolSchema]:
    if group == "general":
        return GENERAL_TOOLS
    if group == "circle_aio":
        return RAG_TOOLS  # Vector search tools
    if group == "lark_doc":
        return [tool for tool in LARK_TOOLS if tool.name in ["lark_create_doc", ...]]
    # ... more groups
```

## Tool Handler Registry

**Location:** `handlers.py`

```python
from typing import Dict, Type
from src.agents.tools.shared import BaseToolHandler

# Handler registry
TOOL_HANDLERS: Dict[str, Type[BaseToolHandler]] = {
    "create_lark_document": CreateLarkDocumentHandler,
    "create_circle_post": CreateCirclePostHandler,
    "create_submission": CreateSubmissionHandler,
    # ... more handlers
}

def get_tool_handler(tool_name: str, **credentials) -> BaseToolHandler:
    """Get handler instance for tool"""
    handler_class = TOOL_HANDLERS.get(tool_name)
    if not handler_class:
        raise ValueError(f"No handler found for tool: {tool_name}")
    
    return handler_class(**credentials)
```

## Usage in Agent System

### Tool Selection (Planner)

```python
# Planner selects tools
selected_tools = [
    AVAILABLE_TOOLS["create_lark_document"],
    AVAILABLE_TOOLS["set_document_permissions"]
]
```

### Tool Execution (Executor)

```python
# Executor calls tools
for tool_call in llm_response.tool_calls:
    handler = get_tool_handler(
        tool_call.name,
        access_token=user_token
    )
    
    result = await handler.execute(**tool_call.parameters)
    
    if not result.success:
        logger.error(f"Tool failed: {result.error}")
```

## Best Practices

### 1. Tool Design

- **Single Responsibility**: Each tool does one thing well
- **Clear Descriptions**: Help LLM understand when to use tool
- **Proper Parameters**: Use JSON schema for validation
- **Error Handling**: Return structured errors
- **Idempotency**: Tools should be safe to retry

### 2. Schema Design

```python
# Good: Clear, specific description
ToolSchema(
    name="create_lark_document",
    description="Create a new document in Lark with specified title and content. Returns document ID and URL.",
    parameters={...}
)

# Bad: Vague description
ToolSchema(
    name="create_doc",
    description="Creates a document",
    parameters={...}
)
```

### 3. Parameter Validation

```python
class MyToolHandler(BaseToolHandler):
    async def execute(self, **kwargs) -> ToolExecutionResult:
        # Validate required parameters
        if not kwargs.get("required_param"):
            return ToolExecutionResult(
                success=False,
                error="Missing required parameter: required_param"
            )
        
        # Validate parameter types
        if not isinstance(kwargs.get("count"), int):
            return ToolExecutionResult(
                success=False,
                error="Parameter 'count' must be an integer"
            )
        
        # Execute tool
        ...
```

### 4. Error Messages

```python
# Good: Specific, actionable error
return ToolExecutionResult(
    success=False,
    error="Failed to create document: Invalid folder_token 'abc123'. Please provide a valid folder token."
)

# Bad: Generic error
return ToolExecutionResult(
    success=False,
    error="Error occurred"
)
```

## Testing

### Unit Tests

```python
import pytest
from unittest.mock import AsyncMock, patch

@pytest.mark.asyncio
async def test_create_document_handler():
    """Test document creation handler"""
    
    # Mock Lark client
    with patch('src.connectors.lark_interactions.doc.LarkDoc') as mock_lark:
        mock_lark.return_value.create_document = AsyncMock(
            return_value={
                "document_id": "doc123",
                "url": "https://lark.com/doc123"
            }
        )
        
        # Execute handler
        handler = CreateLarkDocumentHandler(access_token="test-token")
        result = await handler.execute(
            title="Test Doc",
            content="Test content"
        )
        
        # Assertions
        assert result.success is True
        assert result.result["document_id"] == "doc123"
        assert "url" in result.result
```

### Integration Tests

```python
@pytest.mark.asyncio
async def test_tool_execution_flow():
    """Test complete tool execution flow"""
    
    # Get tool schema
    tool_schema = AVAILABLE_TOOLS["create_lark_document"]
    
    # Get handler
    handler = get_tool_handler(
        "create_lark_document",
        access_token=os.getenv("LARK_ACCESS_TOKEN")
    )
    
    # Execute
    result = await handler.execute(
        title="Integration Test Doc",
        content="This is a test"
    )
    
    # Verify
    assert result.success is True
    assert "document_id" in result.result
```

## Troubleshooting

### Common Issues

**Tool Not Found:**
- Verify tool is registered in `AVAILABLE_TOOLS`
- Check tool name spelling
- Ensure tool is in correct group

**Handler Fails:**
- Check credentials are valid
- Verify API permissions
- Review parameter validation
- Check external API status

**LLM Doesn't Use Tool:**
- Improve tool description
- Add usage examples
- Check if tool is in selected group
- Verify tool parameters are clear

### Debug Logging

```python
import logging

logger = logging.getLogger(__name__)

class MyToolHandler(BaseToolHandler):
    async def execute(self, **kwargs):
        logger.debug(f"Executing tool with params: {kwargs}")
        
        try:
            result = await self._perform_operation(**kwargs)
            logger.info(f"Tool executed successfully: {result}")
            return ToolExecutionResult(success=True, result=result)
        except Exception as e:
            logger.error(f"Tool execution failed: {e}", exc_info=True)
            return ToolExecutionResult(success=False, error=str(e))
```

## Adding New Tools

### Step 1: Define Schema

```python
# In schema.py
AVAILABLE_TOOLS["my_new_tool"] = ToolSchema(
    name="my_new_tool",
    description="Description of what the tool does",
    parameters={
        "type": "object",
        "properties": {
            "param1": {"type": "string", "description": "..."},
            "param2": {"type": "integer", "description": "..."}
        },
        "required": ["param1"]
    },
    group="appropriate_group"
)
```

### Step 2: Implement Handler

```python
# In appropriate folder (lark/, circle/, database/)
class MyNewToolHandler(BaseToolHandler):
    async def execute(self, param1: str, param2: int = None) -> ToolExecutionResult:
        try:
            # Implementation
            result = await self._do_something(param1, param2)
            return ToolExecutionResult(success=True, result=result)
        except Exception as e:
            return ToolExecutionResult(success=False, error=str(e))
```

### Step 3: Register Handler

```python
# In handlers.py
TOOL_HANDLERS["my_new_tool"] = MyNewToolHandler
```

### Step 4: Add to Tool Group

```python
# In schema.py
TOOL_GROUPS["appropriate_group"].append("my_new_tool")
```

### Step 5: Test

```python
@pytest.mark.asyncio
async def test_my_new_tool():
    handler = MyNewToolHandler()
    result = await handler.execute(param1="test")
    assert result.success is True
```
