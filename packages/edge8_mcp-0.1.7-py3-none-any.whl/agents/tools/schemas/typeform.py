from __future__ import annotations

from .base import ToolSchema

# Typeform Tools
typeform_daily_sync_tool = ToolSchema(
    name="typeform_daily_sync",
    description="Run scheduled Typeform daily sync: new forms, updates, and new responses.",
    parameters={},
)

typeform_webhook_handler_tool = ToolSchema(
    name="typeform_webhook_handler",
    description="Handle a Typeform webhook payload for a form_response event and sync to Supabase.",
    parameters={
        "event_data": {"type": "object", "description": "Raw webhook JSON payload from Typeform."},
    },
    required=["event_data"],
)

typeform_data_sync_tool = ToolSchema(
    name="typeform_data_sync",
    description="Manual Typeform data sync helper for forms and responses.",
    parameters={
        "action": {
            "type": "string",
            "enum": ["sync_all_forms", "sync_form", "sync_responses", "sync_new_responses"],
            "description": "Sync operation to run.",
        },
        "form_id": {
            "type": "string",
            "description": "Typeform form ID for targeted sync (required for sync_form and sync_responses).",
        },
        "since": {
            "type": "string",
            "description": "ISO timestamp for incremental responses (used with sync_new_responses).",
        },
    },
    required=["action"],
)

TYPEFORM_TOOLS = [
    typeform_daily_sync_tool,
    typeform_webhook_handler_tool,
    typeform_data_sync_tool,
]

__all__ = [
    "TYPEFORM_TOOLS",
    "typeform_daily_sync_tool",
    "typeform_webhook_handler_tool",
    "typeform_data_sync_tool",
]
