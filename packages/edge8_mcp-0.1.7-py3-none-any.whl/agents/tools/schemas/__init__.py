"""
Tool schemas organized by platform/source group.

This package provides modular tool schema definitions:
- base: Shared ToolSchema class and types
- general: General-purpose tools (search, formatting, storage)
- lark: Lark platform tools (documents, meetings, calendar)
- circle: Circle platform tools (messaging, sync, members)
- typeform: Typeform integration tools (sync, webhooks)
"""

from .base import ToolSchema, ToolList
from .general import GENERAL_TOOLS
from .lark import LARK_TOOLS
from .circle import CIRCLE_TOOLS
from .typeform import TYPEFORM_TOOLS
from .vector import RAG_TOOLS

# Aggregate all tools
AVAILABLE_TOOLS = GENERAL_TOOLS + LARK_TOOLS + CIRCLE_TOOLS + TYPEFORM_TOOLS + RAG_TOOLS

__all__ = [
    "ToolSchema",
    "ToolList",
    "GENERAL_TOOLS",
    "LARK_TOOLS",
    "CIRCLE_TOOLS",
    "TYPEFORM_TOOLS",
    "RAG_TOOLS",
    "AVAILABLE_TOOLS",
]
