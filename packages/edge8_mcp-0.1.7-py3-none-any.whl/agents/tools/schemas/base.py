from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel


class ToolSchema(BaseModel):
    """Unified schema for tool definitions used across tool groups."""

    name: str
    description: str
    parameters: Dict[str, Any]
    required: Optional[List[str]] = None

    def to_openrouter_tool_schema(self) -> Dict[str, Any]:
        required_params = self.required if self.required is not None else list(self.parameters.keys())
        return {
            "name": self.name,
            "description": self.description,
            "parameters": {
                "type": "object",
                "properties": self.parameters,
                "required": required_params,
            },
        }


ToolList = List[ToolSchema]

__all__ = ["ToolSchema", "ToolList"]
