from __future__ import annotations

from datetime import datetime

from .base import ToolSchema


# Circle Chat and Messaging Tools
circle_message_tool = ToolSchema(
    name="circle_message_tool",
    description="Send a markdown message to a Circle chat room as a specific sender.",
    parameters={
        "email": {"type": "string", "description": "Receiver email to send the message to."},
        "chat_room_id": {"type": "string", "description": "UUID of the target chat room."},
        "markdown_message": {"type": "string", "description": "Markdown content to send."},
        "parent_message_id": {
            "type": "integer",
            "description": "Optional parent message ID to reply to (default 0).",
        },
    },
)

# Circle Database/AIO Tools
challenge_submission_tool = ToolSchema(
    name="challenge_submission",
    description="Process a student challenge submission: fetch lesson context, upload files, and persist metadata.",
    parameters={
        "email": {"type": "string", "description": "Student email who submitted the files."},
        "space_name": {"type": "string", "description": "Name of the Circle space containing the mission."},
        "files": {
            "type": "array",
            "description": "List of file URLs for the submission.",
            "items": {"type": "string"},
        },
        "chat_room_id": {
            "type": "string",
            "description": "Optional chat room UUID to locate the space context.",
        },
    },
    required=["email", "space_name", "files"],
)

lesson_html_converter_tool = ToolSchema(
    name="lesson_html_converter",
    description="Convert Circle lesson HTML to markdown, extracting file references and media URLs.",
    parameters={
        "space_id": {"type": "integer", "description": "Space ID of the lesson to convert."},
    },
    required=["space_id"],
)

circle_members_handler_tool = ToolSchema(
    name="circle_members_handler",
    description="Extract Circle member data from Supabase or sync members from Circle into Supabase.",
    parameters={
        "action": {
            "type": "string",
            "enum": ["extract_by_id", "extract_by_email", "sync_members"],
            "description": "Which member operation to perform.",
        },
        "member_id": {
            "type": "integer",
            "description": "Member ID (required for extract_by_id).",
        },
        "email": {
            "type": "string",
            "description": "Member email (required for extract_by_email).",
        },
    },
    required=["action"],
)

# Read-only Database context tools (LLM-callable wrappers around DatabaseToolHandler reads)
# General Circle DB query (wrapping DatabaseToolHandler.execute)
circle_db_query_tool = ToolSchema(
    name="circle_ai_officer_database_query",
    description="""Deterministic database query tool for structured Circle data. Use this when you need exact database lookups using specific identifiers (email, name, resource type) or precise records from the AI Officer Program database.

    This tool is for structured queries: retrieving enrollments, submissions, progress tracking, student data, events, and other database entities by exact field values. It requires specific parameters like email, name, or resource type.

    DO NOT use this for semantic searches, fuzzy matching, or finding content by meaning/concept—use vector search tools instead.

    Resource selection guide — pick the `resource` value matching the user's intent:
    - "series" → courses, programs, series listings
    - "missions" → missions (use query="Mission 01" for specific ones, use series_name to filter by parent series/course)
    - "challenges" → challenges, assignments
    - "briefs" → briefs
    - "students" → student profiles (use email param)
    - "enrollments" → enrollment records (use email for specific student)
    - "submissions" → student submissions (use email for specific student)
    - "events" → events, upcoming events (use timestamp for upcoming)
    - "posts" → community posts
    - "micro_sessions" → micro sessions
    - "workshops" → workshops
    - "mission_progress" → mission completion tracking (use email for specific student)
    - "workshop_progress" → workshop completion tracking (use email for specific student)
    - "micro_sessions_progress" → micro session completion tracking (use email for specific student)
    - "guidelines" → rules, guidelines

    For listing/counting ALL items, set limit=100 and query="".
    To find missions/workshops inside a specific course, use resource="missions" with series_name="<course name>".

    Related keywords: AIO, Generative AI Essentials, Agentic AI Essentials, Business AI Essentials, Posts, Missions, Micro Sessions, Workshops, AI Officer, AI Officer Program, Submissions, Events, Mission Progress, Workshop Progress, Micro Sessions Progress

    Non-related keywords: Leaderships""".strip(),
    parameters={
        "resource": {
            "type": "string",
            "description": "Which database table to query. Must match the entity type: 'series' for courses/programs, 'missions' for missions, 'challenges' for assignments, 'students' for student profiles, 'enrollments' for enrollment records, 'submissions' for student submissions, 'events' for events, 'mission_progress' for mission completion tracking, 'workshop_progress' for workshop completion tracking, 'micro_sessions_progress' for micro session completion tracking.",
            "enum": ["series", "missions", "briefs", "challenges", "students", "enrollments", "submissions", "events", "posts", "micro_sessions", "workshops", "mission_progress", "workshop_progress", "micro_sessions_progress", "guidelines"],
        },
        "limit": {"type": "integer", "description": "Max rows to return. Use 1 for specific lookups, 50-100 for listing/counting. Default 1."},
        "name": {"type": "string", "description": "Name filter (applied with ilike wildcard). Infer from email if provided, never directly use email itself"},
        "query": {"type": "string", "description": "Additional text filter for certain resources (e.g., markdown/body). For Missions, use 'Mission <Mission Number>' as query with <Mission Number> in the format similar to '01', '02', etc."},
        "email": {"type": "string", "description": "User/Student's email"},
        "include_related": {"type": "boolean", "description": "Include related data (e.g., files for submissions, attendees for sessions, briefs/challenges for missions). Default false."},
        "series_name": {"type": "string", "description": "Filter missions/workshops/challenges by parent series/course name. Use when user asks 'missions in <course name>'."},
        "timestamp": {"type": "string", "description": f"Timestamp filter (e.g., '2025-10-15' or '2025-10-15 10:30:00'). Only use for cases: 'events', 'micro_sessions'. For upcoming events, use '{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}'"},
    },
    required=["resource", "limit", "query", "include_related"]
)

# Phase 4 Progress Aggregation Sync Tool (Only student_brief_progress is a sync tool)
circle_student_brief_progress_sync_tool = ToolSchema(
    name="circle_student_brief_progress_sync",
    description="Sync student brief progress from Circle API to core.student_brief_progress table. Tracks individual brief completion per student.",
    parameters={
        "mode": {
            "type": "string",
            "enum": ["full", "incremental"],
            "description": "Sync mode: full sync or incremental since last sync",
            "default": "incremental"
        },
        "last_sync": {
            "type": "string",
            "description": "ISO timestamp of last successful sync (for incremental mode)",
            "default": None
        }
    }
)

# Circle Sync Tools for Phase 5
circle_posts_sync_tool = ToolSchema(
    name="circle_posts_sync",
    description="Sync Circle posts to core.posts table. Fetches published posts with engagement metrics and author information.",
    parameters={
        "mode": {
            "type": "string",
            "enum": ["full", "incremental"],
            "description": "Sync mode: full sync or incremental since last sync",
            "default": "incremental"
        },
        "last_sync": {
            "type": "string",
            "description": "ISO timestamp of last successful sync (for incremental mode)",
            "default": None
        }
    }
)

circle_topics_sync_tool = ToolSchema(
    name="circle_topics_sync",
    description="Sync Circle topics to core.topics table. Fetches content tags with metadata.",
    parameters={
        "mode": {
            "type": "string",
            "enum": ["full", "incremental"],
            "description": "Sync mode: full sync or incremental since last sync",
            "default": "incremental"
        },
        "last_sync": {
            "type": "string",
            "description": "ISO timestamp of last successful sync (for incremental mode)",
            "default": None
        }
    }
)

circle_member_engagement_sync_tool = ToolSchema(
    name="circle_member_engagement_sync",
    description="Aggregate member engagement metrics from posts. Calculates engagement scores based on participation.",
    parameters={
        "mode": {
            "type": "string",
            "enum": ["full", "incremental"],
            "description": "Sync mode: full sync or incremental since last sync",
            "default": "incremental"
        },
        "last_sync": {
            "type": "string",
            "description": "ISO timestamp of last successful sync (for incremental mode)",
            "default": None
        }
    }
)

circle_manual_progress_missions_sync_tool = ToolSchema(
    name="circle_manual_progress_missions_sync",
    description="Sync manual mission progress overrides. Validates admin-driven completion overrides.",
    parameters={
        "mode": {
            "type": "string",
            "enum": ["full", "incremental"],
            "description": "Sync mode: full sync or incremental since last sync",
            "default": "incremental"
        },
        "last_sync": {
            "type": "string",
            "description": "ISO timestamp of last successful sync (for incremental mode)",
            "default": None
        }
    }
)

circle_manual_progress_series_sync_tool = ToolSchema(
    name="circle_manual_progress_series_sync",
    description="Sync manual series progress overrides. Validates admin-driven series completion overrides.",
    parameters={
        "mode": {
            "type": "string",
            "enum": ["full", "incremental"],
            "description": "Sync mode: full sync or incremental since last sync",
            "default": "incremental"
        },
        "last_sync": {
            "type": "string",
            "description": "ISO timestamp of last successful sync (for incremental mode)",
            "default": None
        }
    }
)

CIRCLE_TOOLS = [
    # circle_message_tool,
    circle_db_query_tool,
    # Phase 4 Progress Aggregation Sync Tool (Only student_brief_progress is a sync tool)
    # circle_student_brief_progress_sync_tool,
    # Phase 5 Community Engagement Sync Tools
    # circle_posts_sync_tool,
    # circle_topics_sync_tool,
    # circle_member_engagement_sync_tool,
    # circle_manual_progress_missions_sync_tool,
    # circle_manual_progress_series_sync_tool,
]

__all__ = [
    "CIRCLE_TOOLS",
    "circle_message_tool",
    "circle_db_query_tool",
    # Phase 4 Progress Aggregation Sync Tool (Only student_brief_progress is a sync tool)
    "circle_student_brief_progress_sync_tool",
    # Phase 5 Community Engagement Sync Tools
    "circle_posts_sync_tool",
    "circle_topics_sync_tool",
    "circle_member_engagement_sync_tool",
    "circle_manual_progress_missions_sync_tool",
    "circle_manual_progress_series_sync_tool",
]
