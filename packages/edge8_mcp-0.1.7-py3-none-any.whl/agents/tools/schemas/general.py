from __future__ import annotations

from .base import ToolSchema

# General-purpose tools
web_search_tool = ToolSchema(
    name="custom_search",
    description=(
        "Search the web for information using a search engine. Returns relevant search results including titles, "
        "descriptions, and links. Useful for finding current information, news, articles, or general web content."
    ),
    parameters={
        "query": {
            "type": "string",
            "description": "The search query to look for on the web. Should be specific and well-formed for best results.",
        },
        "num_results": {
            "type": "integer",
            "description": "Number of search results to return (1-20). Defaults to 10 if not specified.",
        },
        "include_text": {
            "type": "array",
            "description": (
                "List of strings that must be present in webpage text of results. Currently, only 1 string is supported, "
                "of up to 5 words. Example: ['large language model', 'AI assistant', 'chatbot']"
            ),
        },
    },
    required=["query"]
)

text_formatting_tool = ToolSchema(
    name="format_text",
    description=(
        "Format and style text content with various formatting options including markdown, HTML, or plain text "
        "transformations. Can handle bullet points, headings, code blocks, emphasis, and other text styling needs."
    ),
    parameters={
        "text": {
            "type": "string",
            "description": "The text content to format. Can be plain text, markdown, or HTML.",
        },
        "format_type": {
            "type": "string",
            "enum": ["markdown", "html", "plain", "bullet_points", "numbered_list"],
            "description": (
                "The target format for the text. Use 'markdown' for markdown formatting, 'html' for HTML tags, "
                "'plain' for simple text, 'bullet_points' to convert to bullet list, 'numbered_list' to convert to "
                "numbered list."
            ),
        },
        "style_options": {
            "type": "object",
            "description": "Additional styling options depending on format type",
            "properties": {
                "heading_level": {
                    "type": "integer",
                    "description": "Heading level for markdown (1-6), ignored for other formats",
                    "minimum": 1,
                    "maximum": 6,
                },
                "bold_text": {
                    "type": "boolean",
                    "description": "Apply bold formatting to the entire text",
                },
                "italic_text": {
                    "type": "boolean",
                    "description": "Apply italic formatting to the entire text",
                },
            },
        },
    },
    required=["text", "format_type", "style_options"]
)

supabase_insert_data_tool = ToolSchema(
    name="supabase_insert_data",
    description="Insert structured data into Supabase with LLM data validation",
    parameters={
        "table_name": {"type": "string", "description": "Target table name"},
        "data": {"type": "object", "description": "Data to insert"},
        "schema": {"type": "string", "description": "Database schema"},
    },
)

inline_url_extractor_tool = ToolSchema(
    name="inline_url_extractor",
    description="Extract URLs from text content using regex pattern matching. Identifies and cleans HTTP/HTTPS URLs from any text input.",
    parameters={
        "text": {"type": "string", "description": "Text content to scan for URLs"},
    },
    required=["text"]
)

url_router_tool = ToolSchema(
    name="url_router",
    description="Route URLs to appropriate processing tools based on URL patterns. Handles Lark minutes URLs and generic web URLs differently.",
    parameters={
        "tool_tag": {"type": "string", "description": "Name of the chosen tool", "enum": ["lark_meeting_to_notes"]},
    },
)

web_scrape_tool = ToolSchema(
    name="web_scrape",
    description=(
        "Scrape webpage content from a given URL. Extracts text content and metadata from web pages for further processing. "
        "NEVER use this tool to look up learning materials, missions, challenges, briefs, series, or any AI Officer Program content. "
        "For those, always use the circle_ai_officer_database_query or vector search tools instead."
    ),
    parameters={
        "tool_tag": {"type": "string", "description": "Name of the chosen tool", "enum": ["lark_meeting_to_notes"]},
    },
)

url_crawler_tool = ToolSchema(
    name="url_crawler",
    description=(
        "Crawl and analyze a public URL based on specific instructions. "
        "Detects if URL is blocked by authentication or bot protection. "
        "If accessible, explores content and provides detailed analysis matching the instructions. "
        "Can interact with chatbot interfaces (up to 5 messages) and detect workflow platforms (n8n, Make.com, Zapier). "
        "Uses remote browser automation (Browserless.io) with automatic fallback to requests-html. "
        "Returns structured report with findings, evidence, match quality, and interaction data. "
        "NEVER use this tool for learning materials, missions, challenges, briefs, series, or any AI Officer Program content. "
        "For those, always use the circle_ai_officer_database_query or vector search tools instead."
    ),
    parameters={
        "url": {
            "type": "string",
            "description": "The target URL to crawl and analyze. Must be a valid HTTP/HTTPS URL.",
        },
        "instructions": {
            "type": "string",
            "description": (
                "Detailed instructions for analyzing the URL content. "
                "Specify what to look for, what to extract, or what criteria to evaluate against. "
                "Examples: "
                "'Check if this page contains pricing information for enterprise plans', "
                "'Analyze the technical documentation and summarize API endpoints', "
                "'Ask the chatbot about their refund policy', "
                "'Verify if this workflow is properly configured'."
            ),
        },
    },
    required=["url", "instructions"]
)

GENERAL_TOOLS = [
    # web_search_tool,
    text_formatting_tool,
    # supabase_insert_data_tool,
    inline_url_extractor_tool,
    url_router_tool,
    web_scrape_tool,
    url_crawler_tool,
]

__all__ = [
    "GENERAL_TOOLS",
    "web_search_tool",
    "text_formatting_tool",
    "supabase_insert_data_tool",
    "inline_url_extractor_tool",
    "url_router_tool",
    "web_scrape_tool",
]
