from __future__ import annotations

from .base import ToolSchema
from utils.time_op import SAMPLING_DESCRIPTORS, COMPLEX_DESCRIPTORS

# Lark Create Document Tools
lark_create_doc_tool = ToolSchema(
    name="lark_create_doc",
    description="Create a collaborative document in Lark with LLM-enhanced formatting",
    parameters={
        "title": {"type": "string", "description": "Document title"},
        "content": {"type": "string", "description": "Document content in markdown"},
    },
)

lark_search_doc_tool = ToolSchema(
    name="lark_search_doc",
    description="Search for a document in Lark by title or content. Returns document details including title, content, and metadata.",
    parameters={
        "search_key": {"type": "string", "description": "Search query for document title or content"},
        "docs_types": {"type": "array", "description": "List of document types to search (e.g., 'file', 'folder')"},
    },
)

# Lark Meetings
lark_meeting_to_notes_tool = ToolSchema(
    name="lark_meeting_to_notes",
    description="Retrieve and process a Lark meeting recording to generate meeting notes. Fetches the latest meeting for the authenticated user, downloads the transcript, uploads it to ThoughtFlow, and generates a summary with key points, action items, and decisions.",
    parameters={
        "tool_tag": {"type": "string", "description": "Name of the chosen tool", "enum": ["lark_meeting_to_notes"]},
    },
)

get_meeting_summary_tool = ToolSchema(
    name="search_existing_meeting_summary",
    description="Search and retrieve existing meeting summaries. Filters meetings stored in the database and returns their summary data including key points, action items, and decisions.",
    parameters={
        "type_query": {"type": "string", "description": "Filter meetings by type/category."},
        "title_query": {"type": "string", "description": "Keyword to search meetings (case-insensitive partial match). This field can carry multiple keywords separated by spaces. Any information can be included here."},
        "date_range": {"type": "string", "description": "Date range to filter meetings (e.g., '2023-01-01 to 2023-12-31')."},
    },
)

lark_meeting_to_document_tool = ToolSchema(
    name="lark_meeting_to_document",
    description="Convert a meeting summary from ThoughtFlow into a formatted Lark document. Creates a new document with the meeting summary content, converts markdown to Lark blocks, and optionally shares it with specified users.",
    parameters={
        "tool_tag": {"type": "string", "description": "Name of the chosen tool", "enum": ["lark_meeting_to_document"]},
    },
)

search_lark_user_tool = ToolSchema(
    name="search_lark_user",
    description="Search for a Lark user by name, email, or employee ID. Returns user details including name, email, and employee ID. Useful for finding user information before sharing documents or adding permissions.",
    parameters={
        "query": {"type": "string", "description": "Search query - can be user name, email, or employee ID"},
    },
)

lark_oauth_tool = ToolSchema(
    name="lark_oauth",
    description="Initiate Lark OAuth authentication flow. Generates and returns the OAuth authorization URL that users should visit to grant access to their Lark account.",
    parameters={},
)

lark_get_auth_session_tool = ToolSchema(
    name="lark_get_auth_session",
    description="Retrieve and validate the Lark OAuth session for a user. Checks if the access token is valid, refreshes it if expired, and returns the current access token. Returns None if no valid session exists.",
    parameters={
        "tool_tag": {"type": "string", "description": "Name of the chosen tool", "enum": ["lark_meeting_to_notes"]},
    },
)

lark_insert_meeting_names_tool = ToolSchema(
    name="lark_insert_meeting_names_for_recurring_report",
    description="Insert or update meeting report settings in the database for recurring summary report. Stores meeting names and their reporting frequency preferences for the authenticated user.",
    parameters={
        "meeting_settings": {
            "type": "array",
            "description": "List of meeting settings to insert. Each setting should contain: name (meeting name) and frequency (reporting frequency like 'once a day', 'once a week', 'once a month', 'once a year', 'never'). Default to 'once a month' if not specified.",
            "items": {
                "type": "object",
                "properties": {
                    "name": {"type": "string", "description": "Meeting name or title"},
                    "frequency": {
                        "type": "string",
                        "description": f"Reporting frequency. Default to '{COMPLEX_DESCRIPTORS[0]}' if not specified. Examples: {', '.join(SAMPLING_DESCRIPTORS[:5])}.",
                        "default": f"{COMPLEX_DESCRIPTORS[0]}",
                    },
                },
            },
        },
    },
)

url_handler_tool = ToolSchema(
    name="lark_url_handler",
    description="Handle Lark URLs. Extracts URLs from text and routes them to the appropriate tool.",
    parameters={
        "text": {"type": "string", "description": "Text containing URLs to extract"},
        "tool_tag": {"type": "string", "description": "Name of the chosen tool", "enum": ["lark_meeting_to_notes"]},
    },
)

# Lark Calendar and Events Tools
lark_get_current_user_calendar_tool = ToolSchema(
    name="lark_get_current_user_calendar",
    description="Retrieve calendars for the current authenticated Lark user. Returns calendar information including calendar IDs and metadata.",
    parameters={
        "tool_tag": {"type": "string", "description": "Name of the chosen tool", "enum": ["lark_meeting_to_notes"]},
    },
)

lark_list_events_tool = ToolSchema(
    name="lark_list_events",
    description="List events from a Lark calendar using keyword query. Returns filtered events that have associated video chat meetings and are not cancelled.",
    parameters={
        "query": {"type": "string", "description": "Keyword to search events (case-insensitive partial match). This field can carry multiple keywords separated by spaces. Any information can be included here."},
        "anchor_time": {"type": "integer", "description": "Must be in seconds since epoch."},
    },
)

lark_search_events_tool = ToolSchema(
    name="lark_search_events",
    description="Search events from a Lark calendar using keyword query. Returns filtered events that have associated video chat meetings and are not cancelled.",
    parameters={
        "query": {"type": "string", "description": "Keyword to search events (case-insensitive partial match). This field can carry multiple keywords separated by spaces. Any information can be included here."},
        "start_time": {"type": "integer", "description": "Must be in seconds since epoch."},
        "end_time": {"type": "integer", "description": "Must be in seconds since epoch."},
    },
)

lark_get_event_tool = ToolSchema(
    name="lark_get_event",
    description="Retrieve a specific event from a Lark calendar using event ID. Returns the event details if found.",
    parameters={
        "event_id": {"type": "string", "description": "Event ID to retrieve"},
        "extracted_keys": {
            "type": "array",
            "description": "List of keys to extract from the event",
            "enum": [
                "event_id",
                "organizer_calendar_id",
                "organizer_id",
                "organizer_name",
                "summary",
                "description",
                "start_time",
                "end_time",
                "vchat",
                "visibility",
                "attendees",
                "vc_url",
                "vc_type",
                "vc_description",
                "vc_permission",
            ],
        },
    },
)

lark_get_minutes_from_meeting_number_tool = ToolSchema(
    name="lark_get_minutes_from_meeting_number",
    description="Retrieve meeting minutes and recordings from Lark using a meeting number. Downloads meeting metadata and stores it in the database.",
    parameters={
        "start_time": {"type": "integer", "description": "Start time on demand. Timestamp in seconds. Default to timestamptz matching 2024-01-01 00:00:00 GMT+7"},
        "end_time": {"type": "integer", "description": "End time on demand. Timestamp in seconds. Default to timestamptz matching current time GMT+7"},
    },
)

lark_generate_summary_from_minutes_tool = ToolSchema(
    name="Lark_generate_summary_from_minutes",
    description="Generate a summary from Lark meeting minutes. Downloads transcript, uploads to ThoughtFlow, and generates AI-powered meeting summary with key points and action items.",
    parameters={
        "tool_tag": {"type": "string", "description": "Name of the chosen tool", "enum": ["lark_meeting_to_notes"]},
    },
)

lark_query_event_to_meeting_notes_tool = ToolSchema(
    name="lark_query_event_to_meeting_notes",
    description="Search an event with keyword query and convert its meetings to meeting notes by finding matching meeting recordings and generating summaries. The input a keyword to search among existing events.",
    parameters={
        "meeting_query": {"type": "string", "description": "Query to search for specific meeting events"},
        "anchor_time": {"type": "integer", "description": "Must be in seconds since epoch."},
    },
)

lark_event_to_meeting_notes_tool = ToolSchema(
    name="lark_event_to_meeting_notes",
    description="Convert an event to meeting notes by finding matching meeting recordings and generating summaries. The input a keyword to search among existing events.",
    parameters={
        "meeting_query": {"type": "string", "description": "Query to search for specific meeting events"},
        "anchor_time": {"type": "integer", "description": "Must be in seconds since epoch."},
    },
)

lark_get_current_user_tool = ToolSchema(
    name="lark_get_current_user",
    description="Get the current authenticated Lark user information along with their Supabase profile mapping.",
    parameters={
        "tool_tag": {"type": "string", "description": "Name of the chosen tool", "enum": ["lark_meeting_to_notes"]},
    },
)

lark_chat_history_tool = ToolSchema(
    name="lark_chat_history",
    description="Get the chat history for a Lark user or group. Returns the chat history for the specified user or group.",
    parameters={
        "query": {"type": "string", "description": "Query to search for in the chat history"},
    },
)

# Grading Tools
lark_grade_assignment_tool = ToolSchema(
    name="lark_grade_assignment",
    description="Grade a student assignment using a dual-agent system (Scorer + Reflector). Extracts file content, searches for rubric/guidelines, runs grading agents, creates grading document, and notifies the student. The file should be uploaded to Lark with filename starting with 'Mission <number>' and the folder name should be the student's name.",
    parameters={
        "file_token": {"type": "string", "description": "Token of the uploaded assignment file in Lark"},
        "folder_token": {"type": "string", "description": "Token of the folder containing the file (folder name = student name)"},
        "uploader_open_id": {"type": "string", "description": "Lark open_id of the uploader who will receive the grading notification"},
    },
)

LARK_TOOLS = [
    lark_create_doc_tool,
    lark_search_doc_tool,
    lark_meeting_to_notes_tool,
    get_meeting_summary_tool,
    lark_meeting_to_document_tool,
    search_lark_user_tool,
    lark_oauth_tool,
    lark_get_auth_session_tool,
    lark_insert_meeting_names_tool,
    url_handler_tool,
    lark_get_current_user_calendar_tool,
    lark_list_events_tool,
    lark_search_events_tool,
    lark_get_event_tool,
    lark_get_minutes_from_meeting_number_tool,
    lark_generate_summary_from_minutes_tool,
    lark_query_event_to_meeting_notes_tool,
    lark_event_to_meeting_notes_tool,
    lark_get_current_user_tool,
    lark_chat_history_tool,
    lark_grade_assignment_tool,
]

__all__ = [
    "LARK_TOOLS",
    "lark_create_doc_tool",
    "lark_search_doc_tool",
    "lark_meeting_to_notes_tool",
    "get_meeting_summary_tool",
    "lark_meeting_to_document_tool",
    "search_lark_user_tool",
    "lark_oauth_tool",
    "lark_get_auth_session_tool",
    "lark_insert_meeting_names_tool",
    "url_handler_tool",
    "lark_get_current_user_calendar_tool",
    "lark_list_events_tool",
    "lark_search_events_tool",
    "lark_get_event_tool",
    "lark_get_minutes_from_meeting_number_tool",
    "lark_generate_summary_from_minutes_tool",
    "lark_query_event_to_meeting_notes_tool",
    "lark_event_to_meeting_notes_tool",
    "lark_get_current_user_tool",
    "lark_chat_history_tool",
    "lark_grade_assignment_tool",
]
