"""
Vector RAG tool schemas
"""

from agents.tools.schemas.base import ToolSchema

# RAG Search Tool
rag_search_tool = ToolSchema(
    name="rag_search",
    description=(
        "Search for relevant documents using semantic vector similarity. "
        "Use this to find information from lessons, posts, messages, or other content."
    ),
    parameters={
        "query": {
            "type": "string",
            "description": "Search query text"
        },
        "match_threshold": {
            "type": "number",
            "description": "Minimum similarity threshold (0-1, default 0.7)",
            "default": 0.7
        },
        "match_count": {
            "type": "integer",
            "description": "Maximum number of results (default 10)",
            "default": 10
        },
        "entity_type": {
            "type": "string",
            "description": "Filter by entity type: lesson, post, message, submission, mission, challenge, etc.",
            "enum": ["lesson", "post", "message", "submission", "mission", "challenge"]
        }
    },
    required=["query"]
)

# RAG Hybrid Search Tool
rag_hybrid_search_tool = ToolSchema(
    name="rag_hybrid_search",
    description=(
        "Advanced search combining semantic vector similarity with full-text search using "
        "Reciprocal Rank Fusion (RRF). Use this tool when deterministic database queries are "
        "insufficient, such as when searching for content based on meaning, concepts, or "
        "contextual relevance rather than exact matches. This is ideal for finding information "
        "across lessons, posts, messages, and submissions when the user's question involves "
        "fuzzy matching, synonyms, or concepts that may not exist as structured fields in the "
        "database. Unlike database tools that require exact field values or structured queries, "
        "this tool understands semantic intent and can surface relevant content even when the "
        "query doesn't match database records directly."
    ),
    parameters={
        "query": {
            "type": "string",
            "description": "Search query text - describe what you're looking for in natural language"
        },
        "match_count": {
            "type": "integer",
            "description": "Number of results to return (default 10). Use 5 for quick answers, 10-15 for comprehensive search, 20+ for exhaustive search",
            "default": 10
        },
        "entity_type": {
            "type": "string",
            "description": "Filter by content type: 'lesson' for course content, 'post' for community posts, 'message' for chat messages, 'submission' for student work, 'mission' for mission content, 'challenge' for challenge content",
            "enum": ["lesson", "post", "message", "submission", "mission", "challenge"]
        }
    },
    required=["query"]
)

# Export
RAG_TOOLS = [rag_hybrid_search_tool]

__all__ = ["RAG_TOOLS", "rag_search_tool", "rag_hybrid_search_tool"]
