from typing import Dict, Any, List
from connectors.search_engine.custom_sdk.exa_api import Exa
from .lark.lark_handlers import *
from .database.aio import DatabaseToolHandler
from .shared import ToolHandler, LLMPdfExtractor
from connectors.supabase_client.db import get_custom_client, Client
from connectors.web_scrapper.scapper import scrape_webpage
from utils.custom_types import DocumentProps
from .schema import get_tools_by_names
from dotenv import load_dotenv
import os
from time import time
 
load_dotenv()

SUPABASE_SERVICE_ROLE_KEY = os.getenv("PUBLIC_SUPABASE_SERVICE_KEY")
SERVER_URL = os.getenv("SERVER_URL")
LOCALHOST_URL = os.getenv("LOCALHOST_URL")
PY_ENV = os.getenv("PY_ENV")
supabase: Client = get_custom_client(key=SUPABASE_SERVICE_ROLE_KEY)


class UrlHandler(ToolHandler):
    """Handler for url tool"""

    async def execute(self, **kwargs) -> { "content": str, "metadata": Dict[str, Any], "error": str }:
        """Execute url tool"""
        text = kwargs.pop("text", "")
        access_token = kwargs.pop("access_token", "")
        try:
            url_detector_tool = InlineUrlExtractor()
            url_router_tool = UrlRouter()
            result = await url_detector_tool.execute(text=text)
            urls = result["metadata"]["urls"]
            url_outputs = []
            for url in urls:
                result = await url_router_tool.execute(url=url, access_token=access_token)
                url_outputs.append(result)
            return {"content": "", "metadata": { "url_outputs": url_outputs }}
        except Exception as e:
            return {"error": f"Failed to check url: {str(e)}"}

class InlineUrlExtractor(ToolHandler):
    """Handler for extracting inline urls from text"""

    async def execute(self, **kwargs) -> { "content": str, "metadata": Dict[str, Any], "error": str }:
        """Execute inline url extraction"""
        text = kwargs.pop("text", "")
        urls = []
        
        try:
            import re
            
            # Simple and accurate regex for http/https URLs
            # Matches http:// or https:// followed by non-whitespace characters
            pattern = r'https?://\S+'
            
            # Find all matches
            urls = re.findall(pattern, text)
            
            # Clean up URLs by removing trailing punctuation
            cleaned_urls = []
            for url in urls:
                # Remove common trailing punctuation
                url = url.rstrip('.,;:!?"\')}>]')
                if url:
                    cleaned_urls.append(url)
            
            urls = cleaned_urls
            
        except Exception as e:
            return {"error": f"Failed to extract URLs: {str(e)}"}
        
        return {"content": f"Found {len(urls)} URLs", "metadata": { "urls": urls }}
    
class UrlRouter(ToolHandler):
    """Handler for checking url"""

    async def execute(self, **kwargs) -> { "content": str, "metadata": Dict[str, Any], "error": str }:
        """Execute url checking"""
        url = kwargs.pop("url", "")
        access_token = kwargs.pop("access_token", "")
        try:
            minutes_to_summary_tool = LarkGenerateSummaryFromMinutes()
            patterns = {
                "lark_minutes": "minutes" in url and "lark" in url,
                "generic": "minutes" not in url and "lark" not in url
            }
            matched_case = [k for k,v in patterns.items() if v][0]
            
            if matched_case == "lark_minutes":
                result = await minutes_to_summary_tool.execute(url=url, access_token=access_token)
                return {"content": result["content"], "metadata": result["metadata"]}
            elif matched_case == "generic":
                web_scrape_tool = WebScrapeHandler()
                result = await web_scrape_tool.execute(url=url)
                return {"content": result["content"], "metadata": result["metadata"]}
            else:
                return {"error": "This is not a valid url"}
        except Exception as e:
            return {"error": f"Failed to check url: {str(e)}"}

class WebScrapeHandler(ToolHandler):
    """Handler for web scrape tool"""

    async def execute(self, **kwargs) -> { "content": str, "metadata": Dict[str, Any], "error": str }:
        """Execute web scrape using SerpApi or similar service"""
        url = kwargs.pop("url", "")
        try:
            result = await scrape_webpage(url)
            return {"content": result.text_content, "metadata": result.metadata}
        except Exception as e:
            return {"error": f"Failed to scrape webpage: {str(e)}"}

class UrlCrawlerHandler(ToolHandler):
    """Handler for URL crawling and analysis with instructions"""
    
    def __init__(self):
        self.agent = None  # Lazy initialization
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """
        Execute URL crawling with instructions
        
        Args:
            url: Target URL to crawl
            instructions: Analysis instructions for the agent
            
        Returns:
            {
                "content": str,  # Main analysis report (markdown formatted)
                "metadata": {
                    "is_public_url": bool,
                    "url": str,
                    "content_type": str,
                    "match_quality": str,
                    "key_findings": List[str],
                    "page_title": str,
                    "status": str,
                    "browser_method": str
                },
                "error": str  # Empty if successful
            }
        """
        url = kwargs.pop("url", "")
        instructions = kwargs.pop("instructions", "")
        
        try:
            # Lazy initialize agent
            if not self.agent:
                from connectors.openrouter.llm import OpenRouterMultimodalLLM
                from agents.subagents.url_crawler_agent import UrlCrawlerAgent
                import os
                
                llm = OpenRouterMultimodalLLM(
                    api_key=os.getenv("OPENROUTER_API_KEY"),
                    model="google/gemini-2.0-flash-lite-001",
                    temperature=0.1
                )
                self.agent = UrlCrawlerAgent(llm)
            
            result = await self.agent.crawl_and_analyze(url, instructions)
            
            # Format response
            if not result.get("is_public_url"):
                return {
                    "content": f"URL is not publicly accessible: {result.get('reason', 'Unknown')}",
                    "metadata": {
                        "is_public_url": False,
                        "url": url,
                        "status": "blocked"
                    },
                    "error": ""
                }
            
            # Format successful analysis as markdown
            analysis = result.get("analysis", {})
            interaction_data = result.get("interaction_data", {})
            
            content = f"""# URL Analysis Report

## Summary
{analysis.get('summary', 'No summary available')}

## Content Type: {result.get('content_type', 'unknown').upper()}
## Match Quality: {analysis.get('match_quality', 'unknown').upper()}

## Key Findings
{chr(10).join(f"- {finding}" for finding in analysis.get('key_findings', []))}

## Evidence
{chr(10).join(f"> {evidence}" for evidence in analysis.get('evidence', []))}
"""
            
            # Add interaction data if present
            if interaction_data:
                if "chatbot_transcript" in interaction_data:
                    content += f"\n## Chatbot Interaction ({interaction_data.get('interaction_count', 0)} messages)\n"
                    for turn in interaction_data.get("chatbot_transcript", []):
                        if isinstance(turn, dict) and "user" in turn:
                            content += f"- **User:** {turn['user']}\n"
                            content += f"- **Assistant:** {turn.get('assistant', 'N/A')}\n\n"
                
                if "workflow_structure" in interaction_data:
                    workflow = interaction_data["workflow_structure"]
                    content += f"\n## Workflow Analysis\n"
                    content += f"- **Platform:** {workflow.get('platform', 'unknown')}\n"
                    content += f"- **Workflow Name:** {workflow.get('workflow_name', 'N/A')}\n"
                    content += f"- **Nodes:** {len(workflow.get('nodes', []))}\n"
                    content += f"- **Valid:** {workflow.get('is_valid', False)}\n"
            
            content += f"\n## Recommendations\n"
            content += chr(10).join(f"- {rec}" for rec in analysis.get('recommendations', []))
            
            return {
                "content": content,
                "metadata": {
                    "is_public_url": True,
                    "url": url,
                    "content_type": result.get("content_type"),
                    "match_quality": analysis.get('match_quality'),
                    "key_findings": analysis.get('key_findings', []),
                    "page_title": result.get('page_info', {}).get('title'),
                    "status": "success",
                    "browser_method": result.get("browser_method")  # Track which method was used
                },
                "error": ""
            }
            
        except Exception as e:
            import traceback
            return {
                "content": "",
                "metadata": {},
                "error": f"Failed to crawl URL: {str(e)}\n{traceback.format_exc()}"
            }

class WebSearchHandler(ToolHandler):
    """Handler for web search tool"""

    async def execute(self, **kwargs) -> { "content": str, "metadata": Dict[str, Any], "error": str }:
        """Execute web search using SerpApi or similar service"""
        query = kwargs.pop("query", "")
        num_results = kwargs.pop("num_results", 10)
        include_text = kwargs.pop("include_text", [])
        
        print("Query: ", query)
        print("Num Results: ", num_results)
        print("Include Text: ", include_text)

        # In a real implementation, this would use the search engine connectors
        # For now, we'll simulate the search results
        try:
            # This is a placeholder - in production you'd use the actual search APIs
            # from the search_engine connectors
            exa_client: Exa = Exa(
              query=query,
              search_kwargs={
                "type": "auto",
                "livecrawl": "fallback",
                "summary": {
                  "query": f"Generate summary of 150 words relevant to {query}. ONLY USE PLAIN TEXT. NEVER MARKDOWN. NEVER USE LISTS, BULLETS, OR NEVER OUTPUT TABLES."
                },
                "as_answer": False,
                "moderation": True,
                "include_text": include_text
              }
            )
            results: List[DocumentProps] = await exa_client.search(int(num_results))
            print("Findings: ", results)

            formatted_results = []
            for result in results:
                highlights = result.metadata.get('highlights', [])
                highlights_text = "\n- ".join(highlights) if highlights else ""
                
                formatted_results.append(
f"""**{result.metadata['title']}**
{result.content}
Highlights: - {highlights_text}
URL: {result.metadata.get('link', result.metadata.get('url', ''))}
"""
                )
            
            sources = [result.metadata.get('link', result.metadata.get('url', '')) for result in results]
            
            return {"content": "\n\n".join(formatted_results), "metadata": {"sources": sources}}
            

        except Exception as e:
            return {"error": f"Error performing web search: {str(e)}"}


class NotionCreatePageHandler(ToolHandler):
    """Handler for Notion page creation"""

    async def execute(self, **kwargs) -> Dict[str, Any]:
        """Execute Notion page creation"""
        # Placeholder implementation
        return {
            "content": "Notion page creation not yet implemented",
            "metadata": {"status": "pending"}
        }


class TextFormattingHandler(ToolHandler):
    """Handler for text formatting tool"""

    async def execute(self, **kwargs) -> { "content": str }:
        """Execute text formatting"""
        text = kwargs.get("text", "")
        from markdown import markdown as md2html
        return {"content": md2html(text)}

from connectors.supabase_client.db import get_custom_client

class SupabaseInsertDataHandler(ToolHandler):
    async def execute(self, **kwargs) -> Dict[str, Any]:
        table_name = kwargs.get("table_name")
        data = kwargs.get("data")
        client = get_custom_client()
        if not isinstance(data, list):
            data = [data]
        try:
            result = await client.table(table_name).insert(data).execute()
            return {"content": f"Successfully inserted data into Supabase table '{table_name}'.", "metadata": result}
        except Exception as e:
            return {"error": f"Failed to insert data into Supabase: {str(e)}"}

from connectors.notion.page_manager import create_page

class NotionCreatePageHandler(ToolHandler):
    async def execute(self, **kwargs) -> Dict[str, Any]:
        parent_page_id = kwargs.get("parent_page_id")
        title = kwargs.get("title")
        content = kwargs.get("content")
        try:
            result = await create_page(parent_page_id, title, content)
            return {"content": f"Successfully created page '{title}' in Notion.", "metadata": result}
        except Exception as e:
            return {"error": f"Failed to create page in Notion: {str(e)}"}

# Tool handler registry
TOOL_HANDLERS: Dict[str, ToolHandler] = {
    "custom_search": WebSearchHandler(),
    "format_text": TextFormattingHandler(),
    "lark_create_doc": LarkCreateDocHandler(),
    "supabase_insert_data": SupabaseInsertDataHandler(),
    "notion_create_page": NotionCreatePageHandler(),
    "lark_meeting_to_notes": LarkMeetingSummaryGenerator(),
    "search_existing_meeting_summary": GetMeetingSummaryHandler(),
    "lark_meeting_to_document": LarkMeetingToDocumentHandler(),
    "search_lark_user": GetLarkUserHandler(),
    "lark_oauth": LarkOAuthHandler(),
    "lark_get_auth_session": LarkGetAuthSessionHandler(),
    "lark_insert_meeting_names": LarkInsertMeetingNamesHandler(),
    "lark_list_events": LarkListEventsHandler(),
    "lark_query_event_to_meeting_notes": LarkQueryEventToMeetingNotes(),
    "lark_event_to_meeting_notes": LarkEventToMeetingNotes(),
    "lark_send_message": LarkSendMessageHandler(),
    "lark_chat_history": LarkChatHistoryHandler(),
    "lark_get_event": LarkGetEventHandler(),
    "lark_search_events": LarkSearchEventsHandler(),
    "lark_new_base": LarkNewBaseTool(),
    "lark_get_base_from_query": LarkGetBaseFromQuery(),
    "lark_new_base_with_data": LarkNewBaseWithDataTool(),
    "lark_insert_table_data": LarkInsertTableData(),
    "lark_new_table_with_data": LarkNewTableWithData(),
    "lark_get_table": LarkGetTable(),
    "lark_fetch_table_data": LarkFetchTableData(),
    "lark_update_table_handler": LarkUpdateTableHandler(),
    "lark_insert_with_existing_check": LarkInsertWithExistingCheck(),
    "lark_base_check_auth_tool": LarkBaseCheckAuthTool(),
    "lark_base_insert_new_session_tool": LarkBaseInsertNewSessionTool(),
    "map_data_to_fields": map_data_to_fields,
    "llm_pdf_extractor": LLMPdfExtractor(),
    "circle_ai_officer_database_query": DatabaseToolHandler(),
    "url_crawler": UrlCrawlerHandler(),
}


async def execute_tool(tool_name: str, **kwargs) -> Dict[str, Any]:
    """
    Execute a tool by name with given parameters

    Args:
        tool_name: Name of the tool to execute
        **kwargs: Parameters to pass to the tool

    Returns:
        Tool execution result as a dictionary
    """
    start_time = time()
    handler = TOOL_HANDLERS.get(tool_name)
    if not handler:
        return {"error": f"Tool '{tool_name}' not found"}

    try:
        tool_result = await handler.execute(**kwargs)
        tool_result["execution_time"] = time() - start_time
        return tool_result
    except Exception as e:
        return {"error": f"Error executing tool '{tool_name}': {str(e)}"}


def get_available_tools_info() -> List[Dict[str, Any]]:
    """Get information about all available tools"""
    tools_info = []
    for tool_name in TOOL_HANDLERS.keys():
        tool_schemas = get_tools_by_names([tool_name])
        if tool_schemas:
            # Since get_tools_by_names returns a list, iterate through it
            for tool_schema in tool_schemas:
                tools_info.append({
                    "name": tool_name,
                    "description": tool_schema.description,
                    "parameters": tool_schema.parameters
                })
    return tools_info


__all__ = ["ToolHandler", "WebSearchHandler", "TextFormattingHandler", "execute_tool", "get_available_tools_info",
           "GoogleDriveCreateDocHandler", "GoogleDriveUploadFileHandler", "LarkCreateDocHandler",
           "SupabaseInsertDataHandler", "AirtableInsertRecordHandler", "NotionCreatePageHandler"]