from typing import Dict, Any, List
from connectors.openrouter.llm import OpenRouterMultimodalLLM, ChatMessage
from utils.data_conversion import encode_base64_by_chunk, EXTENSION_TO_MIME_TYPE
from pathlib import Path


class ToolHandler:
    """Base class for tool handlers"""

    async def execute(self, **kwargs) -> { "content": str, "metadata": Dict[str, Any], "error": str }:
        """Execute the tool with given parameters"""
        raise NotImplementedError


async def call_llm(messages: list[Dict], model: str = "meta-llama/llama-3.1-8b-instruct", **kwargs) -> str:
    """Call the LLM with given messages and model"""
    messages = [ChatMessage(**message) for message in messages]
    llm = OpenRouterMultimodalLLM(model=model)
    response = await llm.achat(messages, **kwargs)
    return response.message.content.strip()


class LLMPdfExtractor(ToolHandler):
    """LLM-based document processing tool"""

    def __init__(self):
        self.llm = OpenRouterMultimodalLLM(model="openai/gpt-5-nano")
      
    async def execute(self, **kwargs) -> { "content": str, "metadata": Dict[str, Any], "error": str }:
        """Execute LLM-based document processing"""
        pdf_bytes = kwargs.get("pdf_bytes")
        file_name = kwargs.get("file_name")
        
        try:
            encoded_pdf = encode_base64_by_chunk(pdf_bytes, "application/pdf")
            
            messages = [
                ChatMessage(role="system", content="""You are a PDF reader. Extract the content of the PDF.
## Instructions:
- Extract all contents from this pdf.
- For tables in pdf, extract and format the table using Markdown table.
- For images in pdf, describe the content of the image and tag the caption by the order of the image in the pdf file.
- Do not include any prefix, suffix or comments."""),
                ChatMessage(role="user", content="Extract all contents from this pdf.", additional_kwargs={"files": [{"name": file_name, "content": encoded_pdf}]})
            ]
            response = (await self.llm.achat(
                messages, 
                plugin=[{
                    "id": "file-parser",
                    "pdf": {
                        "engine": "pdf-text"
                    }
                }]
            )).message.content.strip()
            return {"content": response, "metadata": {}, "error": ""}
        except Exception as e:
            print("Error extracting PDF content: ", str(e))
            return {"content": "", "metadata": {}, "error": str(e)}


class MultimodalFileExtractor(ToolHandler):
    """Multimodal file extractor for PDFs, images, and videos"""

    def __init__(self, model: str = "google/gemini-2.5-flash"):
        self.llm = OpenRouterMultimodalLLM(model=model)
    
    def _get_file_type(self, file_name: str) -> str:
        """Determine file type from extension"""
        ext = Path(file_name).suffix.lower()
        if ext in [".pdf"]:
            return "pdf"
        elif ext in [".jpg", ".jpeg", ".png", ".gif", ".webp", ".svg"]:
            return "image"
        elif ext in [".mp4", ".avi", ".mov", ".mkv", ".webm"]:
            return "video"
        else:
            return "unknown"
    
    def _get_mime_type(self, file_name: str) -> str:
        """Get MIME type from file extension"""
        ext = Path(file_name).suffix.lower()
        return EXTENSION_TO_MIME_TYPE.get(ext, "application/octet-stream")
    
    def _build_multimodal_message(self, files_by_type: Dict[str, List[Dict[str, Any]]]) -> tuple[str, Dict[str, Any]]:
        """
        Build a multimodal message with all file types
        
        Args:
            files_by_type: Dict with keys 'pdf', 'image', 'video' containing file data
            
        Returns:
            Tuple of (text_content, additional_kwargs)
        """
        additional_kwargs = {}
        text_parts = []
        
        # Add PDFs
        if files_by_type.get("pdf"):
            pdf_files = []
            for file_data in files_by_type["pdf"]:
                pdf_files.append({
                    "name": file_data["name"],
                    "content": file_data["encoded"]
                })
                text_parts.append(f"PDF: {file_data['name']}")
            additional_kwargs["files"] = pdf_files
        
        # Add images
        if files_by_type.get("image"):
            image_urls = []
            for file_data in files_by_type["image"]:
                image_urls.append(file_data["encoded"])
                text_parts.append(f"Image: {file_data['name']}")
            additional_kwargs["image_urls"] = image_urls
        
        # Add videos
        if files_by_type.get("video"):
            video_urls = []
            for file_data in files_by_type["video"]:
                video_urls.append(file_data["encoded"])
                text_parts.append(f"Video: {file_data['name']}")
            additional_kwargs["video_urls"] = video_urls
        
        text_content = "Please analyze and extract content from the following files:\n" + "\n".join(text_parts)
        
        return text_content, additional_kwargs
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """
        Execute multimodal file extraction in a single LLM call
        
        Args:
            files: List of dicts with 'name' and 'bytes' keys
            
        Returns:
            Dictionary with extracted content organized by file type
        """
        files = kwargs.get("files", [])
        
        if not files or len(files) == 0:
            return {
                "content": {
                    "pdf": [],
                    "image": [],
                    "video": [],
                    "unsupported": []
                },
                "metadata": {"total_files": 0, "processed_files": 0, "failed_files": 0},
                "error": "No files provided"
            }
        
        # Organize files by type
        files_by_type = {"pdf": [], "image": [], "video": [], "unsupported": []}
        file_metadata = {}
        
        print("📤 Organizing files by type...")
        for file_data in files:
            print("File data:", file_data)
            file_name = file_data.get("name")
            file_uri = file_data.get("data")
            file_type = file_data.get("file_type") or (Path(file_name).suffix if file_name else None)
            print("File name:", file_name)
            print("File type:", file_type)
            
            if not file_name or not file_uri:
                files_by_type["unsupported"].append({
                    "name": file_name or "unknown",
                    "error": "Missing file name or bytes"
                })
                continue

            if file_type not in files_by_type:
                files_by_type["unsupported"].append({
                    "name": file_name,
                    "error": f"Unsupported file type: {file_type}"
                })
                continue

            files_by_type[file_type].append({
                "name": file_name,
                "encoded": file_uri,
                "size_bytes": len(file_uri)
            })
            
            file_metadata[file_name] = {
                "type": file_type,
                "size_bytes": len(file_uri)
            }
            
            print(f"   ✓ {file_type.upper()}: {file_name}")
        
        # If no valid files, return early
        if not any([files_by_type["pdf"], files_by_type["image"], files_by_type["video"]]):
            print("No valid files to process")
            return {
                "content": {
                    "pdf": [],
                    "image": [],
                    "video": [],
                    "unsupported": files_by_type["unsupported"]
                },
                "metadata": {
                    "total_files": len(files),
                    "processed_files": 0,
                    "failed_files": len(files)
                },
                "error": "No valid files to process"
            }
        
        # Build multimodal message
        print("🔄 Building multimodal message...")
        text_content, additional_kwargs = self._build_multimodal_message(files_by_type)
        
        # Call LLM with all files in one message
        print("🤖 Calling LLM for extraction...")
        try:
            messages = [
                ChatMessage(
                    role="system",
                    content="""You are a multimodal content analyzer. Extract and analyze content from PDFs, images, and videos.
                    
## Instructions for PDFs:
- Extract all text content
- Format tables using Markdown
- Describe images in order with captions
- Preserve document structure

## Instructions for Images:
- Provide detailed descriptions of content
- Identify objects, text, people, and elements
- Describe layout, colors, and composition
- Include any captions or labels

## Instructions for Videos:
- Describe key scenes and subjects
- Note video quality and format
- Identify audio elements and text overlays
- Summarize main content and purpose

## Common:
- Do not include any prefix, suffix or comments.

## Output Format:
Organize your response with clear sections for each file type:

### PDFs:
[PDF content here]

### Images:
[Image descriptions here]

### Videos:
[Video analysis here]"""),
                ChatMessage(role="user", content=text_content, additional_kwargs=additional_kwargs)
            ]
            
            # Add PDF plugin if there are PDFs
            plugin = None
            if files_by_type["pdf"]:
                plugin = [{
                    "id": "file-parser",
                    "pdf": {
                        "engine": "pdf-text"
                    }
                }]
            
            response = await self.llm.achat(messages, plugin=plugin) if plugin else await self.llm.achat(messages)
            llm_content = response.message.content.strip()
            
            # print("✅ LLM extraction complete: ", llm_content)
            
            # Parse response and organize by file type
            result_content = self._parse_llm_response(llm_content, files_by_type, file_metadata)
            
            return {
                "content": result_content,
                "metadata": {
                    "total_files": len(files),
                    "processed_files": len(files) - len(files_by_type["unsupported"]),
                    "failed_files": len(files_by_type["unsupported"]),
                    "file_types": {
                        "pdf": len(files_by_type["pdf"]),
                        "image": len(files_by_type["image"]),
                        "video": len(files_by_type["video"])
                    }
                },
                "error": ""
            }
            
        except Exception as e:
            print(f"❌ Error in multimodal extraction: {str(e)}")
            return {
                "content": {
                    "pdf": [],
                    "image": [],
                    "video": [],
                    "unsupported": files_by_type["unsupported"]
                },
                "metadata": {
                    "total_files": len(files),
                    "processed_files": 0,
                    "failed_files": len(files)
                },
                "error": str(e)
            }
    
    def _parse_llm_response(self, llm_content: str, files_by_type: Dict[str, List[Dict]], file_metadata: Dict[str, Any]) -> Dict[str, Any]:
        """
        Parse LLM response and organize content by file type
        
        Args:
            llm_content: Raw LLM response
            files_by_type: Organized files by type
            file_metadata: Metadata about files
            
        Returns:
            Organized content by file type with markdown format
        """
        result = {
            "pdf": [],
            "image": [],
            "video": [],
            "unsupported": []
        }
        
        # Add unsupported files
        for unsupported in files_by_type["unsupported"]:
            result["unsupported"].append({
                "file_name": unsupported["name"],
                "error": unsupported["error"]
            })
        
        # Parse response sections
        sections = {
            "pdf": self._extract_section(llm_content, "PDFs"),
            "image": self._extract_section(llm_content, "Images"),
            "video": self._extract_section(llm_content, "Videos")
        }
        
        # Organize PDF results
        if files_by_type["pdf"]:
            pdf_content = sections["pdf"] or llm_content
            result["pdf"] = [{
                "file_name": f["name"],
                "file_type": "pdf",
                "content": pdf_content,
                "size_bytes": f["size_bytes"],
                "error": ""
            } for f in files_by_type["pdf"]]
        
        # Organize image results
        if files_by_type["image"]:
            image_content = sections["image"] or llm_content
            result["image"] = [{
                "file_name": f["name"],
                "file_type": "image",
                "content": image_content,
                "size_bytes": f["size_bytes"],
                "error": ""
            } for f in files_by_type["image"]]
        
        # Organize video results
        if files_by_type["video"]:
            video_content = sections["video"] or llm_content
            result["video"] = [{
                "file_name": f["name"],
                "file_type": "video",
                "content": video_content,
                "size_bytes": f["size_bytes"],
                "error": ""
            } for f in files_by_type["video"]]
        
        # Convert to markdown format (excluding size_bytes and error from markdown)
        result["markdown"] = self._convert_to_markdown(result)
        
        return result
    
    def _extract_section(self, content: str, section_name: str) -> str:
        """Extract a section from LLM response"""
        import re
        
        # Look for section headers like "### PDFs:" or "## Images:"
        pattern = rf"#+\s*{section_name}.*?:\s*(.*?)(?=#+\s*\w+:|$)"
        match = re.search(pattern, content, re.IGNORECASE | re.DOTALL)
        
        if match:
            return match.group(1).strip()
        return ""
    
    def _convert_to_markdown(self, result: Dict[str, Any]) -> str:
        """
        Convert result dictionary to markdown format
        
        Args:
            result: Result dictionary with pdf, image, video, unsupported sections
            
        Returns:
            Markdown formatted string
        """
        markdown = ""
        
        # PDFs section
        if result.get("pdf"):
            markdown += "## PDF Documents\n\n"
            for pdf_file in result["pdf"]:
                if not pdf_file.get("error"):
                    markdown += f"### {pdf_file['file_name']}\n\n"
                    markdown += f"{pdf_file.get('content', '')}\n\n"
                else:
                    markdown += f"### {pdf_file['file_name']}\n\n"
                    markdown += f"❌ Error: {pdf_file['error']}\n\n"
        
        # Images section
        if result.get("image"):
            markdown += "## Images\n\n"
            for image_file in result["image"]:
                if not image_file.get("error"):
                    markdown += f"### {image_file['file_name']}\n\n"
                    markdown += f"{image_file.get('content', '')}\n\n"
                else:
                    markdown += f"### {image_file['file_name']}\n\n"
                    markdown += f"❌ Error: {image_file['error']}\n\n"
        
        # Videos section
        if result.get("video"):
            markdown += "## Videos\n\n"
            for video_file in result["video"]:
                if not video_file.get("error"):
                    markdown += f"### {video_file['file_name']}\n\n"
                    markdown += f"{video_file.get('content', '')}\n\n"
                else:
                    markdown += f"### {video_file['file_name']}\n\n"
                    markdown += f"❌ Error: {video_file['error']}\n\n"
        
        # Unsupported files section
        if result.get("unsupported"):
            markdown += "## Unsupported Files\n\n"
            for unsupported in result["unsupported"]:
                markdown += f"- **{unsupported['file_name']}**: {unsupported.get('error', 'Unknown error')}\n"
            markdown += "\n"
        
        return markdown.strip()

      
__all__ = ["ToolHandler", "call_llm", "LLMPdfExtractor", "MultimodalFileExtractor"]