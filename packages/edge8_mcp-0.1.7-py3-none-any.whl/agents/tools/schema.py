from typing import List, Dict, Any

# Re-export from schemas package
from agents.tools.schemas import (
    ToolSchema,
    GENERAL_TOOLS,
    LARK_TOOLS,
    TYPEFORM_TOOLS,
    AVAILABLE_TOOLS as SCHEMAS_AVAILABLE_TOOLS,
)

# Platform descriptions
PLATFORMS_DESCRIPTIONS = {
    "GOOGLE_DOCS": "Google Docs for document creation and collaboration",
    "LARK": "Lark collaborative interactions with Lark Doc, Lark Auth, Lark Meetings, Lark User, .etc",
    "GOOGLE_DRIVE": "Google Drive for file storage and management",
    "SUPABASE": "Supabase for structured data storage",
    "AIRTABLE": "Airtable for tabular data and databases",
    "NOTION": "Notion for collaborative workspaces and documents",
}

# Use aggregated AVAILABLE_TOOLS from schemas package
AVAILABLE_TOOLS = SCHEMAS_AVAILABLE_TOOLS

TOOL_GROUP_DEFINITIONS = {
    'general': 'Use this if the user asks to perform an action, search for information, create something, or access external data.',
    'lark_doc': 'Use this if the user is from Lark platform and ask specifically about Lark documents or request execution of some task realted to Lark Doc.',
    'lark_events': 'Use this if the user is from Lark platform and ask specifically about Lark calendar events or request execution of some task realted to Lark Events.',
    'lark_meetings': 'Use this if the user is from Lark platform and ask specifically about Lark meetings or request execution of some task realted to Lark Meetings.',
    'grading_system': 'Use this if the student wants to submit an assignment for a challenge.',
}

# Tools for each group
def get_tools_by_group(group: str) -> List[ToolSchema]:
    """Get tools by group"""
    if group == "general":
        return GENERAL_TOOLS
    if group == "lark_doc":
        return [tool for tool in LARK_TOOLS if tool.name in ["lark_create_doc", "lark_meeting_to_notes", "lark_meeting_to_document"]]
    if group == "lark_base":
        return [tool for tool in LARK_TOOLS if tool.name in ["lark_get_current_user", "lark_get_current_user_calendar", "lark_list_events", "lark_search_events", "lark_get_event", "lark_get_minutes_from_meeting_number", "lark_generate_summary_from_minutes"]]
    if group == "lark_meetings":
        return [
            tool
            for tool in LARK_TOOLS
            if tool.name
            in [
                "lark_meeting_to_notes",
                "lark_meeting_to_document",
                "lark_get_minutes_from_meeting_number",
                "lark_generate_summary_from_minutes",
            ]
        ]
    return []

def get_tools_by_names(names: List[str]) -> List[ToolSchema]:
    """Get tools by names using optimized set-based lookup"""
    if not names:
        return []

    names_set = set(names)
    # Return the actual ToolSchema objects, not their dict representation
    return [tool for tool in AVAILABLE_TOOLS if tool.name in names_set]


# Function to get tool schemas for OpenRouter API
def get_tool_all_schemas() -> List[Dict[str, Any]]:
    """Get all tool schemas in OpenRouter format"""
    return [tool.to_openrouter_tool_schema() for tool in AVAILABLE_TOOLS]

# Function to get tool schemas for OpenRouter API
def get_tool_schemas_by_names(names: List[str]) -> List[Dict[str, Any]]:
    """Get all tool schemas in OpenRouter format"""
    return [tool.to_openrouter_tool_schema() for tool in AVAILABLE_TOOLS if tool.name in names]

__all__ = [
    "TOOL_GROUP_DEFINITIONS",
    "ToolSchema",
    "web_search_tool",
    "text_formatting_tool",
    "AVAILABLE_TOOLS",
    "get_tool_all_schemas",
    "get_tools_by_names",
    "google_drive_create_doc_tool",
    "google_drive_upload_file_tool",
    "lark_create_doc_tool",
    "lark_meeting_to_notes_tool",
    "get_meeting_summary_tool",
    "lark_meeting_to_document_tool",
    "search_lark_user_tool",
    "lark_oauth_tool",
    "lark_get_auth_session_tool",
    "lark_insert_meeting_names_tool",
    "supabase_insert_data_tool",
    "notion_create_page_tool",
    "inline_url_extractor_tool",
    "url_router_tool",
    "web_scrape_tool",
    "lark_get_current_user_calendar_tool",
    "lark_list_events_tool",
    "lark_search_events_tool",
    "lark_get_event_tool",
    "lark_get_minutes_from_meeting_number_tool",
    "lark_generate_summary_from_minutes_tool",
    "lark_get_current_user_tool",
    "lark_query_event_to_meeting_notes_tool",
    "lark_event_to_meeting_notes_tool",
    "lark_chat_history_tool",
    "lark_grade_assignment_tool",
    "circle_message_tool",
    "challenge_submission_tool",
    "lesson_html_converter_tool",
    "circle_members_handler_tool",
    "circle_sync_all_tool",
    "circle_space_groups_sync_tool",
    "circle_spaces_sync_tool",
    "circle_space_group_members_sync_tool",
    # Phase 4 Progress Aggregation Sync Tool (Only student_brief_progress is a sync tool)
    "circle_student_brief_progress_sync_tool",
    # Phase 5 Community Engagement Sync Tools
    "circle_posts_sync_tool",
    "circle_topics_sync_tool",
    "circle_member_engagement_sync_tool",
    "circle_manual_progress_missions_sync_tool",
    "circle_manual_progress_series_sync_tool",
    "typeform_daily_sync_tool",
    "typeform_webhook_handler_tool",
    "typeform_data_sync_tool",
    "get_tools_by_group",
]


