# Subagents Module

## Purpose

The subagents module contains specialized AI agents that work together in a modular orchestration pattern. Each subagent has a specific responsibility in the agent workflow.

## Folder Structure

```
src/agents/subagents/
├── router_agent.py              # RouterAgent - Intent detection & routing
├── tool_agent.py                # ToolAgent - 2-stage tool planning & execution
├── answering_agent.py           # AnsweringAgent - Response generation
├── intent_verification_agent.py # IntentVerificationAgent - Intent validation
└── url_crawler_agent.py         # URLCrawlerAgent - Web scraping
```

## Agent Overview

### 1. RouterAgent

**File:** `router_agent.py`

**Purpose:** Analyzes user input and determines the appropriate routing decision with context awareness

**Responsibilities:**
- Detect intent type (TOOL, CHAT, GRADING)
- Select appropriate tool group (general, circle_aio, lark_doc, etc.)
- Determine if task is FINISHED or needs to CONTINUE
- Hybrid follow-up detection (keyword + semantic)
- Integrate context from providers (AIO, Student, Prefetch)
- Support Redis caching for repeated queries
- Enforce max iteration limits (3 iterations)

**Key Methods:**
```python
async def decide(self, state: AgentState) -> RouterOutput:
    """
    Analyze input and return routing decision
    
    Returns:
        RouterOutput with intent, tools_group, status, reasoning
    """
```

**Decision Types:**
- **TOOL**: User needs tool execution (e.g., "Search for missions")
- **CHAT**: User needs conversational response (e.g., "What is AI?")
- **GRADING**: User submitting assignment for grading (detected via context or keywords)

**Follow-up Detection:**
```python
# Fast path: keyword matching
if state.last_submission and _is_submission_followup(state):
    return RouterOutput(intent=TOOL, tools_group="circle_aio")

# Semantic path: LLM decides if it's a follow-up
```

**Example Output:**
```python
RouterOutput(
    intent=AgentIntent.TOOL,
    tools_group="circle_aio",
    status=AgentStatus.CONTINUE,
    step="Search for mission details",
    reasoning="User asking about mission content"
)
```

### 2. ToolAgent

**File:** `tool_agent.py`

**Purpose:** 2-stage tool planning and execution with prompt caching

**Responsibilities:**
- **Stage 1 (Planning)**: Select relevant tools and generate custom system prompt
- **Stage 2 (Execution)**: Execute tools with optimized context
- Use prompt caching for efficiency
- Handle tool parameter extraction and validation
- Process tool results and errors

**Key Methods:**
```python
async def select_tool(self, state: AgentState) -> Optional[ToolCallData]:
    """
    2-stage tool selection and execution
    
    Stage 1: Plan (select tools + generate system prompt)
    Stage 2: Execute (call tools with custom prompt)
    
    Returns:
        ToolCallData with results or None on failure
    """
```

**Stage 1: Planning**
```python
# LLM generates:
{
    "tool_system_prompt": "You are an AI Officer assistant...",
    "selected_tools": ["search_challenges", "get_student_progress"]
}
```

**Stage 2: Execution**
```python
# LLM executes tools with custom prompt
# Uses prompt caching for tool descriptions and system prompts
```

**Benefits:**
- **Context Efficiency**: Only relevant tools in execution stage
- **Prompt Caching**: Reduces LLM costs for repeated queries
- **Custom Prompts**: Task-specific system prompts optimize performance

### 3. IntentVerificationAgent

**File:** `intent_verification_agent.py`

**Purpose:** Validates and verifies user intent for specific scenarios

**Responsibilities:**
- Verify grading intent when ambiguous
- Confirm user wants to submit assignment
- Validate context-specific intents
- Reduce false positives in intent detection

**Key Methods:**
```python
async def verify_intent(
    self,
    user_input: str,
    suspected_intent: str,
    context: Dict[str, Any]
) -> bool:
    """
    Verify if suspected intent is correct
    
    Returns:
        True if intent confirmed, False otherwise
    """
```

**Use Cases:**
```python
# Verify grading intent
if router_output.intent == GRADING:
    confirmed = await intent_verifier.verify_intent(
        user_input,
        "grading",
        {"files": files, "context_type": context_type}
    )
    if not confirmed:
        # Fall back to CHAT or TOOL
```

**Benefits:**
- **Reduces False Positives**: Confirms ambiguous intents
- **User Confirmation**: Can prompt user for clarification
- **Context-Aware**: Uses conversation history and metadata

### 4. AnsweringAgent

**File:** `answering_agent.py`

**Purpose:** Synthesizes natural language responses with context awareness and role adaptation

**Responsibilities:**
- Generate human-readable responses
- Incorporate tool execution results
- Maintain conversation flow
- Support streaming output
- Adapt role based on platform (e.g., AI Buddy for AIO)
- Integrate context from providers

**Key Methods:**
```python
async def answer(self, state: AgentState) -> str:
    """
    Generate natural language response
    
    Returns:
        Natural language response string
    """

async def answer_stream(self, state: AgentState) -> AsyncGenerator[str, None]:
    """
    Stream response chunks
    
    Yields:
        Response chunks for streaming
    """
```

**Role Adaptation:**
```python
def _get_role(self, state: AgentState) -> str:
    """Determine agent role based on context"""
    if "circle_aio" in state.tool_groups:
        return "You are the AI Buddy for the AI Officer Program..."
    return "You are a helpful AI assistant."
```

**Response Patterns:**
- **With Tool Results**: Synthesize results into natural response
- **Without Tools**: Direct conversational response using context providers
- **Error Handling**: Graceful error messages
- **Context Integration**: Incorporates AIO guidelines, student progress, prefetch data
- **File Content**: Includes uploaded file content in context

## Agent Workflow

### Complete Flow

```
1. User Input + Files
   ↓
2. Update State (add user message)
   ↓
3. Context Providers (inject AIO, Student, Prefetch data)
   ↓
4. RouterAgent.decide()
   → Detects intent: TOOL
   → Selects tools_group: "circle_aio"
   → Status: CONTINUE
   ↓
5. ToolAgent.select_tool()
   → Stage 1: Plan
     - Selects: ["search_challenges", "get_student_progress"]
     - Generates: "You are an AI Officer assistant..."
   → Stage 2: Execute
     - Calls search_challenges(query="Mission 1")
     - Calls get_student_progress(email="student@example.com")
     - Returns results
   ↓
6. Update State (store tool results)
   ↓
7. RouterAgent.decide() (iteration 2)
   → Status: FINISHED
   ↓
8. AnsweringAgent.answer_stream()
   → Integrates context providers
   → Synthesizes: "Based on your progress, you should complete Mission 1..."
   → Streams response chunks
   ↓
9. Return to User
```

### Streaming Flow

```
1. User Input
   ↓
2. RouterAgent.decide()
   → Yield: {"event": "reasoning", "data": "Analyzing request..."}
   ↓
3. ToolAgent.select_tool()
   → Yield: {"event": "reasoning", "data": "Searching for missions..."}
   ↓
4. AnsweringAgent.answer_stream()
   → Yield: {"event": "content", "data": "Based"}
   → Yield: {"event": "content", "data": " on your"}
   → Yield: {"event": "content", "data": " progress..."}
   ↓
5. Save to Session (if auto_save enabled)
```

## Coding Conventions

### Agent Base Class

```python
from abc import ABC, abstractmethod
from typing import Dict, List, Optional
from pydantic import BaseModel

class BaseAgent(ABC):
    """Base class for all agents"""
    
    def __init__(self, llm_client):
        self.llm = llm_client
    
    @abstractmethod
    async def execute(self, **kwargs):
        """Execute agent logic"""
        pass
```

### Router Implementation

```python
from src.agents.systems.shared import AgentIntent, AgentStatus, RouterOutput
from src.agents.context.registry import ContextRegistry

class RouterAgent(BaseAgent):
    def __init__(self, llm_client, chosen_tool_groups, cache_client=None, prompt_logger=None):
        super().__init__(llm_client)
        self.context_registry = ContextRegistry()
        # Register context providers
        self.context_registry.register(AIOGuidelinesProvider(), tool_groups=["circle_aio"])
        self.context_registry.register(StudentContextProvider(cache_client=cache_client))
        self.context_registry.register(PrefetchContextProvider())
    
    async def decide(self, state: AgentState) -> RouterOutput:
        """Route user input with context awareness"""
        
        # Hybrid follow-up detection
        if state.last_submission and self._is_submission_followup(state):
            return RouterOutput(
                intent=AgentIntent.TOOL,
                tools_group="circle_aio",
                status=AgentStatus.CONTINUE,
                reasoning="Follow-up question about submission"
            )
        
        # Get context from providers
        additional_context = await self.context_registry.get_context(state)
        
        # Build prompt with context
        system_prompt = f"""
        You are a Router Agent...
        
        ## Additional Context:
        {additional_context}
        """
        
        # LLM call with structured output
        response = await self.llm.achat(
            messages=[...],
            response_format={"type": "json_schema", ...}
        )
        
        return RouterOutput(**response)
```

### Tool Agent Implementation

```python
class ToolAgent(BaseAgent):
    async def select_tool(self, state: AgentState) -> Optional[ToolCallData]:
        """2-stage tool selection and execution"""
        
        available_tools = state.tool_schemas
        tool_descriptions = [t.to_openrouter_tool_schema() for t in available_tools]
        
        # Stage 1: Planning with cached tool descriptions
        planning_prompt = CENTRAL_PROMPT_MAPPING.get("tool_planning")
        messages_stage1 = [
            ChatMessage(
                role="system",
                content=planning_prompt,
                cache_control={"type": "ephemeral"}  # Cache tool descriptions
            ),
            ChatMessage(role="user", content=state.current_input)
        ]
        
        response_stage1 = await self.client.achat(
            messages_stage1,
            response_format={
                "type": "json_schema",
                "json_schema": {
                    "properties": {
                        "tool_system_prompt": {"type": "string"},
                        "selected_tools": {"type": "array", "items": {"type": "string"}}
                    }
                }
            }
        )
        
        plan_data = json.loads(response_stage1.message.content)
        
        # Stage 2: Execution with cached system prompt
        messages_stage2 = [
            ChatMessage(
                role="system",
                content=plan_data["tool_system_prompt"],
                cache_control={"type": "ephemeral"}  # Cache system prompt
            ),
            ChatMessage(role="user", content=state.current_input)
        ]
        
        _, tool_results = await self.aprocess_with_tools(
            messages_stage2,
            plan_data["selected_tools"],
            **state.tool_inputs
        )
        
        return tool_results
```

### Intent Verification Implementation

```python
class IntentVerificationAgent(BaseAgent):
    async def verify_intent(
        self,
        user_input: str,
        suspected_intent: str,
        context: Dict[str, Any]
    ) -> bool:
        """Verify if suspected intent is correct"""
        
        prompt = f"""
        Verify if the user's intent is '{suspected_intent}'.
        
        User input: {user_input}
        Context: {context}
        
        Return true if intent is confirmed, false otherwise.
        """
        
        response = await self.llm.achat(
            messages=[ChatMessage(role="user", content=prompt)],
            response_format={
                "type": "json_schema",
                "json_schema": {
                    "properties": {
                        "confirmed": {"type": "boolean"},
                        "reasoning": {"type": "string"}
                    }
                }
            }
        )
        
        result = json.loads(response.message.content)
        return result["confirmed"]
```

### Answering Implementation

```python
class AnsweringAgent(BaseAgent):
    async def answer(
        self,
        user_input: str,
        conversation_history: List[Dict],
        tool_results: Optional[List[ToolResult]] = None
    ) -> str:
        """Generate natural language response"""
        
        prompt = self._build_answer_prompt(
            user_input,
            conversation_history,
            tool_results
        )
        
        response = await self.llm.generate(prompt=prompt)
        return response.content
    
    async def answer_stream(
        self,
        user_input: str,
        conversation_history: List[Dict],
        tool_results: Optional[List[ToolResult]] = None
    ) -> AsyncGenerator[str, None]:
        """Stream response chunks"""
        
        prompt = self._build_answer_prompt(
            user_input,
            conversation_history,
            tool_results
        )
        
        async for chunk in self.llm.generate_stream(prompt=prompt):
            yield chunk.content
```

## Design Patterns

### 1. 2-Stage Tool Execution Pattern

**Concept:** Separate planning from execution for efficiency

**Implementation:**
```python
# Stage 1: Planning
plan = await tool_agent.plan(
    user_input=state.current_input,
    available_tools=state.tool_schemas
)
# Returns: {"tool_system_prompt": "...", "selected_tools": [...]}

# Stage 2: Execution
results = await tool_agent.execute(
    system_prompt=plan["tool_system_prompt"],
    selected_tools=plan["selected_tools"],
    user_input=state.current_input
)
```

### 2. Context Provider Pattern

**Concept:** Pluggable context injection before agent calls

**Implementation:**
```python
# Register providers
context_registry = ContextRegistry()
context_registry.register(AIOGuidelinesProvider(), tool_groups=["circle_aio"])
context_registry.register(StudentContextProvider(cache_client=cache))

# Get context before agent call
additional_context = await context_registry.get_context(state)

# Inject into system prompt
system_prompt = f"""
{base_prompt}

## Additional Context:
{additional_context}
"""
```

### 3. Hybrid Detection Pattern

**Concept:** Keyword fast-path + LLM semantic fallback

**Implementation:**
```python
# Fast path: keyword matching
if state.last_submission and self._is_submission_followup(state):
    return RouterOutput(intent=TOOL, tools_group="circle_aio")

# Semantic path: LLM decides
response = await self.llm.achat(...)
return RouterOutput(**response)
```

**Benefits:**
- **Router**: Intent detection and routing
- **Tool Agent**: Tool planning and execution
- **Answering**: Response generation
- **Intent Verifier**: Intent validation

## Best Practices

1. **Keep agents focused**: Each agent should have one clear responsibility
2. **Use structured outputs**: JSON schema for all LLM responses
3. **Implement streaming**: For better user experience
4. **Handle errors gracefully**: Return structured error responses
5. **Use prompt caching**: Cache tool descriptions and system prompts
6. **Register context providers**: Add providers for platform-specific context
7. **Test independently**: Each agent should be testable in isolation
8. **Monitor iteration counts**: Prevent infinite loops with max iterations
9. **Enable Redis caching**: Cache student data and router decisions
10. **Log prompts**: Use prompt logger for debugging

## Testing

### Unit Tests

```python
import pytest
from unittest.mock import AsyncMock

@pytest.mark.asyncio
async def test_router_agent():
    """Test router agent decision making"""
    mock_llm = AsyncMock()
    mock_llm.generate.return_value = RouterDecision(
        intent="TOOL",
        tool_group="lark",
        status="CONTINUE",
        reasoning="User wants to create document"
    )
    
    router = RouterAgent(mock_llm)
    decision = await router.route(
        user_input="Create a document",
        conversation_history=[],
        available_tool_groups=["lark", "circle"]
    )
    
    assert decision.intent == "TOOL"
    assert decision.tool_group == "lark"
```

### Integration Tests

```python
@pytest.mark.asyncio
async def test_agent_workflow():
    """Test complete agent workflow"""
    # Setup
    router = RouterAgent(llm_client)
    planner = PlannerAgent(llm_client)
    answering = AnsweringAgent(llm_client)
    
    # Route
    route_decision = await router.route(
        user_input="Create a document",
        conversation_history=[],
        available_tool_groups=["lark"]
    )
    
    # Plan
    plan_decision = await planner.plan(
        user_input="Create a document",
        tool_group=route_decision.tool_group,
        available_tools=all_tools
    )
    
    # Execute (mocked)
    tool_results = [{"success": True, "doc_id": "123"}]
    
    # Answer
    response = await answering.answer(
        user_input="Create a document",
        conversation_history=[],
        tool_results=tool_results
    )
    
    assert "document" in response.lower()
```

## Performance Considerations

### 1. Caching

```python
from functools import lru_cache

@lru_cache(maxsize=128)
def get_tool_schemas(tool_group: str) -> List[ToolSchema]:
    """Cache tool schemas by group"""
    return [t for t in ALL_TOOLS if t.group == tool_group]
```

### 2. Parallel Execution

```python
import asyncio

# Execute multiple tools in parallel
results = await asyncio.gather(
    execute_tool_1(),
    execute_tool_2(),
    execute_tool_3()
)
```

### 3. Streaming Optimization

```python
async def answer_stream(self, ...):
    """Stream with buffering for efficiency"""
    buffer = []
    async for chunk in self.llm.generate_stream(...):
        buffer.append(chunk)
        if len(buffer) >= 5:  # Buffer 5 chunks
            yield "".join(buffer)
            buffer = []
    
    if buffer:  # Flush remaining
        yield "".join(buffer)
```

## Troubleshooting

### Common Issues

**Router always returns CHAT:**
- Check if tool groups are properly configured
- Verify router prompt includes tool group descriptions
- Review conversation history for context

**Planner selects wrong tools:**
- Improve tool descriptions in schemas
- Add more examples to planner prompt
- Review tool group organization

**Executor fails to execute:**
- Verify tool schemas are correct
- Check tool handler implementations
- Review executor system prompt

**Answering produces poor responses:**
- Improve answering prompt
- Provide more context in conversation history
- Include tool result metadata

### Debug Mode

```python
import logging

logger = logging.getLogger(__name__)

# In agent methods
logger.debug(f"Router decision: {decision}")
logger.info(f"Selected tools: {selected_tools}")
logger.error(f"Execution failed: {error}")
```
