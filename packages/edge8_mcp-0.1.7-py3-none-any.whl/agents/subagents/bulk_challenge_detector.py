from typing import Dict, Any, List
import json

from agents.tools.database.aio import DatabaseToolHandler
from connectors.openrouter.llm import OpenRouterMultimodalLLM, ChatMessage


class BulkChallengeDetector:
    """Detect and segment multi-challenge submissions.

    Two responsibilities:
    1. Fetch all challenges for a mission from the DB (deterministic, no LLM).
    2. Segment submission text+file content into per-challenge slices (LLM).
    """

    def __init__(self, llm: OpenRouterMultimodalLLM) -> None:
        self.client = llm
        self.db_handler = DatabaseToolHandler()

    async def detect_all_challenges_for_mission(
        self,
        primary_challenge: Dict[str, Any],
    ) -> List[Dict[str, Any]]:
        """Return all non-legacy challenges for the same mission as primary_challenge.

        Args:
            primary_challenge: Challenge dict from detect_challenge_from_text_or_files().
                               Must have 'entity_id' (the mission/workshop/etc. DB id).

        Returns:
            List of challenge dicts (id, name, type, status, mission_id).
            Returns [primary_challenge] unchanged if entity_id is missing or
            no DB results are found.
        """
        entity_id = primary_challenge.get("entity_id")
        if not entity_id:
            return [primary_challenge]

        try:
            response = (
                self.db_handler.supabase.table("challenges")
                .select("id, name, type, status, mission_id")
                .eq("mission_id", entity_id)
                .eq("is_legacy", False)
                .execute()
            )
        except Exception as e:
            print(f"⚠️ BulkChallengeDetector: DB query failed: {e}")
            return [primary_challenge]

        if not response.data:
            return [primary_challenge]

        return response.data

    async def segment_submission_content(
        self,
        text_content: str,
        extracted_file_content: str,
        challenges: List[Dict[str, Any]],
    ) -> Dict[str, str]:
        """Segment submission content into per-challenge slices using LLM.

        Args:
            text_content: Student's raw message text.
            extracted_file_content: Markdown content from MultimodalFileExtractor.
            challenges: List of challenge dicts (must have 'name' and 'type').

        Returns:
            Dict mapping challenge_name -> relevant content slice.
            Only challenges with clearly matched content are included.
            Returns empty dict on LLM failure (caller handles fallback).
        """
        combined_content = (
            f"## Student's Message:\n{text_content}\n\n"
            f"## Content from Attachments:\n{extracted_file_content or 'No attachments'}"
        )

        challenge_list = "\n".join(
            f"- {c['name']} (type: {c.get('type', 'unknown')})"
            for c in challenges
        )

        system_prompt = f"""You are a submission content analyzer for an educational platform.

Given a student's submission and a list of challenges, identify which challenges the student is addressing and extract the relevant content for each.

## Available Challenges:
{challenge_list}

## Rules:
1. Only include challenges where the student has clearly provided relevant work.
2. For each matched challenge, extract the specific portion of the submission that addresses it.
3. If a section of the submission does not clearly map to any challenge, skip it.
4. Return valid JSON only. No markdown fences, no commentary.

## Output Format:
{{
    "matched_challenges": [
        {{
            "challenge_name": "<exact challenge name from the list above>",
            "content_slice": "<the portion of the submission relevant to this challenge>",
            "confidence": "high" | "medium"
        }}
    ]
}}

Only include matches with "high" or "medium" confidence."""

        try:
            response = await self.client.achat([
                ChatMessage(
                    role="system",
                    content=system_prompt,
                    cache_control={"type": "ephemeral", "ttl": "1h"},
                ),
                ChatMessage(role="user", content=combined_content),
            ])

            raw = response.message.content.strip()
            result = json.loads(raw)

            segments: Dict[str, str] = {}
            for match in result.get("matched_challenges", []):
                name = match.get("challenge_name", "")
                content = match.get("content_slice", "")
                if name and content:
                    segments[name] = content

            return segments

        except (json.JSONDecodeError, KeyError, Exception) as e:
            print(f"⚠️ BulkChallengeDetector: segmentation failed: {e}")
            return {}
