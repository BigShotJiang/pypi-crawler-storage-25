"""
URL Crawler Agent for analyzing public URLs with instruction-based interaction.

This agent implements a 3-tier fallback strategy:
1. Static scraping (fastest, no cost)
2. Browserless.io HTTP API (remote browser automation)
3. requests-html (fallback when API limits exceeded)

Supports:
- Static content analysis
- Chatbot interaction (up to 5 messages)
- Workflow platform detection (n8n, Make.com, Zapier)
- Authentication/blocking detection
"""

import os
import json
import httpx
from typing import Dict, Any, List, Optional, Literal
from urllib.parse import urlparse

from agents.systems.shared import BaseAgent
from connectors.openrouter.llm import OpenRouterMultimodalLLM, ChatMessage
from connectors.web_scrapper.scapper import scrape_webpage, WebPageInfo


class UrlCrawlerAgent(BaseAgent):
    """Agent for inspecting and crawling public URLs with instruction-based interaction."""
    
    def __init__(self, llm_client: OpenRouterMultimodalLLM, system_prompt: Optional[str] = None):
        super().__init__(llm_client, system_prompt)
        self._browserless_api_key: Optional[str] = os.getenv("BROWSERLESS_API_KEY")
        self._html_session = None
        self._browser_method: Optional[str] = None  # Track which method is active
        self._http_client = httpx.AsyncClient(timeout=60.0)
    
    async def crawl_and_analyze(self, url: str, instructions: str) -> Dict[str, Any]:
        """
        Main entry point with 3-tier fallback strategy.
        
        Args:
            url: Target URL to crawl and analyze
            instructions: Analysis instructions for the agent
            
        Returns:
            Dict with analysis results, metadata, and interaction data
        """
        try:
            # Step 1: Try static scraping first (fastest, no cost)
            try:
                page_info = await scrape_webpage(url)
                
                # Check if blocked
                if self._is_blocked_static(page_info):
                    return {
                        "is_public_url": False,
                        "url": url,
                        "status": "blocked",
                        "reason": "Authentication or bot detection detected",
                        "content_type": "static",
                        "analysis": {},
                        "page_info": {
                            "title": page_info.title,
                            "description": page_info.description,
                            "headings": page_info.headings
                        }
                    }
                
                # Check if interactive content needed
                if not self._needs_interaction(url, page_info):
                    # Static content is sufficient
                    return await self._analyze_static_content(page_info, url, instructions)
            
            except Exception as e:
                print(f"Static scraping failed: {e}, trying browser automation")
            
            # Step 2: Interactive content detected - try Browserless.io
            try:
                self._browser_method = "browserless"
                result = await self._crawl_with_browserless(url, instructions)
                if result:
                    return result
            except Exception as e:
                print(f"Browserless.io failed: {e}, falling back to requests-html")
            
            # Step 3: Fallback to requests-html
            try:
                self._browser_method = "requests-html"
                result = await self._crawl_with_requests_html(url, instructions)
                if result:
                    return result
            except Exception as e:
                print(f"requests-html failed: {e}")
            
            # All methods failed
            return {
                "is_public_url": False,
                "url": url,
                "status": "error",
                "reason": "All crawling methods failed",
                "content_type": "unknown",
                "analysis": {},
                "page_info": {}
            }
        
        finally:
            await self.close()
    
    async def _crawl_with_browserless(self, url: str, instructions: str) -> Optional[Dict[str, Any]]:
        """Crawl using Browserless.io HTTP API."""
        if not self._browserless_api_key:
            raise ValueError("BROWSERLESS_API_KEY not set")
        
        # Get page content
        content_result = await self._call_browserless_api(url, action="content")
        html = content_result.get("html", "")
        
        if not html:
            return None
        
        # Detect content type
        content_type = await self._detect_content_type_from_html(html, url)
        
        # Handle interactive content
        interaction_data = None
        if content_type == "chatbot":
            interaction_data = await self._interact_with_chatbot_via_browserless(url, instructions)
        elif content_type == "workflow":
            interaction_data = await self._analyze_workflow_via_browserless(url)
        
        # Build response
        return await self._build_response_from_html(html, url, content_type, interaction_data, instructions)
    
    async def _crawl_with_requests_html(self, url: str, instructions: str) -> Optional[Dict[str, Any]]:
        """Crawl using requests-html as fallback."""
        html_result = await self._get_html_via_requests_html(url)
        html = html_result.get("html", "")
        
        if not html:
            return None
        
        # Detect content type (limited with requests-html)
        content_type = await self._detect_content_type_from_html(html, url)
        
        # Limited interaction with requests-html (read-only)
        interaction_data = None
        if content_type == "chatbot":
            # Can't interact with requests-html, just extract existing chat
            interaction_data = await self._extract_existing_chat(html)
        elif content_type == "workflow":
            # Can analyze workflow structure from HTML
            interaction_data = await self._analyze_workflow_from_html(html, url)
        
        # Build response
        return await self._build_response_from_html(html, url, content_type, interaction_data, instructions)
    
    async def _call_browserless_api(self, url: str, action: str = "content", **kwargs) -> Dict[str, Any]:
        """Call Browserless.io HTTP API."""
        api_url = f"https://chrome.browserless.io/{action}?token={self._browserless_api_key}"
        
        payload = {
            "url": url,
            "waitFor": kwargs.get("wait_for", 2000),
            "gotoOptions": {"waitUntil": "networkidle2"}
        }
        
        if action == "function":
            # For interactive actions (chatbot, workflow)
            payload["function"] = kwargs.get("function", "")
        
        response = await self._http_client.post(api_url, json=payload)
        response.raise_for_status()
        
        if action == "content":
            return {"html": response.text, "method": "browserless"}
        else:
            return {"data": response.json(), "method": "browserless"}
    
    async def _get_html_via_requests_html(self, url: str) -> Dict[str, Any]:
        """Fallback to requests-html."""
        if self._html_session is None:
            from requests_html import AsyncHTMLSession
            self._html_session = AsyncHTMLSession()
        
        response = await self._html_session.get(url)
        await response.html.arender(timeout=20, sleep=2)
        
        return {"html": response.html.html, "method": "requests-html"}
    
    def _is_blocked_static(self, page_info: WebPageInfo) -> bool:
        """Check if page is blocked based on static content."""
        # Check for minimal content (likely SPA with auth wall)
        if page_info.text_content and len(page_info.text_content) < 200:
            return True
        
        # Check for blocking patterns
        blocking_patterns = [
            "captcha", "cloudflare", "bot detection", "access denied",
            "authentication required", "sign in", "log in", "unauthorized"
        ]
        
        text_lower = page_info.text_content.lower() if page_info.text_content else ""
        title_lower = page_info.title.lower() if page_info.title else ""
        
        return any(pattern in text_lower or pattern in title_lower for pattern in blocking_patterns)
    
    def _needs_interaction(self, url: str, page_info: WebPageInfo) -> bool:
        """Heuristic to detect if URL needs browser automation."""
        interactive_patterns = [
            'chat', 'bot', 'n8n', 'make.com', 'zapier',
            'workflow', 'app.', 'dashboard', 'intercom', 'drift'
        ]
        
        # Check URL
        if any(p in url.lower() for p in interactive_patterns):
            return True
        
        # Check if page has minimal content (likely SPA)
        if page_info.text_content and len(page_info.text_content) < 500:
            return True
        
        return False
    
    async def _detect_content_type_from_html(self, html: str, url: str) -> str:
        """Detect if page contains chatbot or workflow interface."""
        from bs4 import BeautifulSoup
        
        soup = BeautifulSoup(html, 'html.parser')
        
        # Check for chatbot patterns
        chatbot_selectors = [
            'input[placeholder*="message" i]',
            'input[placeholder*="chat" i]',
            'textarea[placeholder*="message" i]',
            '[role="textbox"]',
            '.chat-input',
            '#chat-input'
        ]
        
        for selector in chatbot_selectors:
            if soup.select(selector):
                # Verify send button exists
                send_selectors = ['button[type="submit"]', 'button:has-text("Send")', '[aria-label*="send" i]']
                if any(soup.select(send_sel) for send_sel in send_selectors):
                    return "chatbot"
        
        # Check for workflow patterns
        workflow_patterns = [
            ('n8n', '/workflow/'),
            ('make.com', '/scenario'),
            ('integromat.com', '/scenario'),
            ('zapier.com', '/editor')
        ]
        
        for platform, pattern in workflow_patterns:
            if platform in url.lower() or pattern in url.lower():
                return "workflow"
        
        return "static"
    
    async def _interact_with_chatbot_via_browserless(self, url: str, instructions: str) -> Dict[str, Any]:
        """Handle chatbot interaction via Browserless.io HTTP API."""
        transcript = []
        
        # Generate initial message
        initial_message = await self._generate_chatbot_message(instructions, transcript)
        
        for i in range(5):
            # Create JavaScript function to interact with chatbot
            js_function = f"""
            async () => {{
                // Find input and send button
                const inputSelectors = [
                    'input[placeholder*="message" i]',
                    'textarea[placeholder*="message" i]',
                    '[role="textbox"]'
                ];
                
                let inputElem = null;
                for (const selector of inputSelectors) {{
                    inputElem = document.querySelector(selector);
                    if (inputElem) break;
                }}
                
                if (!inputElem) return {{ error: "Could not find chat input" }};
                
                // Type message
                inputElem.value = "{initial_message if i == 0 else 'follow-up'}";
                inputElem.dispatchEvent(new Event('input', {{ bubbles: true }}));
                
                // Click send button
                const sendButton = document.querySelector('button[type="submit"]') || 
                                  document.querySelector('button:has-text("Send")');
                if (sendButton) sendButton.click();
                
                // Wait for response
                await new Promise(resolve => setTimeout(resolve, 2000));
                
                // Extract messages
                const messageContainers = document.querySelectorAll('[role="log"], .messages, .chat-history');
                const messages = Array.from(messageContainers).map(el => el.innerText);
                
                return {{ messages, turn: {i + 1} }};
            }}
            """
            
            try:
                result = await self._call_browserless_api(url, action="function", function=js_function)
                
                if "error" in result.get("data", {}):
                    break
                
                transcript.append({
                    "turn": i + 1,
                    "user": initial_message if i == 0 else "Follow-up",
                    "assistant": result.get("data", {}).get("messages", [])
                })
                
                # Check if instructions satisfied
                if await self._should_stop_chatbot_interaction(transcript, instructions):
                    break
                    
            except Exception as e:
                print(f"Chatbot interaction failed: {e}")
                break
        
        return {
            "chatbot_transcript": transcript,
            "interaction_count": len(transcript),
            "method": "browserless"
        }
    
    async def _analyze_workflow_via_browserless(self, url: str) -> Dict[str, Any]:
        """Analyze workflow structure via Browserless.io."""
        js_function = """
        async () => {
            // Extract workflow information
            const workflowInfo = {
                platform: 'unknown',
                workflow_name: '',
                nodes: [],
                triggers: [],
                connections: [],
                errors: [],
                warnings: []
            };
            
            // Detect platform
            if (window.location.hostname.includes('n8n')) {
                workflowInfo.platform = 'n8n';
            } else if (window.location.hostname.includes('make.com') || window.location.hostname.includes('integromat.com')) {
                workflowInfo.platform = 'make.com';
            } else if (window.location.hostname.includes('zapier.com')) {
                workflowInfo.platform = 'zapier';
            }
            
            // Extract workflow name
            const nameElement = document.querySelector('h1, .workflow-name, [data-testid="workflow-name"]');
            if (nameElement) workflowInfo.workflow_name = nameElement.innerText.trim();
            
            // Extract nodes (simplified)
            const nodeElements = document.querySelectorAll('.node, .workflow-node, [data-node-id]');
            workflowInfo.nodes = Array.from(nodeElements).map(el => ({
                id: el.getAttribute('data-node-id') || '',
                type: el.getAttribute('data-node-type') || el.className,
                name: el.innerText.trim() || ''
            }));
            
            // Check for errors
            const errorElements = document.querySelectorAll('.error, .alert-error, [data-testid="error"]');
            workflowInfo.errors = Array.from(errorElements).map(el => el.innerText.trim());
            
            return workflowInfo;
        }
        """
        
        try:
            result = await self._call_browserless_api(url, action="function", function=js_function)
            workflow_data = result.get("data", {})
            
            return {
                "workflow_structure": workflow_data,
                "method": "browserless"
            }
        except Exception as e:
            print(f"Workflow analysis failed: {e}")
            return {"workflow_structure": {}, "method": "browserless", "error": str(e)}
    
    async def _extract_existing_chat(self, html: str) -> Dict[str, Any]:
        """Extract existing chat content (read-only)."""
        from bs4 import BeautifulSoup
        
        soup = BeautifulSoup(html, 'html.parser')
        
        # Extract message containers
        message_containers = soup.select('[role="log"], .messages, .chat-history, .conversation')
        
        transcript = []
        for container in message_containers:
            messages = container.get_text(strip=True)
            if messages:
                transcript.append({
                    "turn": len(transcript) + 1,
                    "user": "Existing conversation",
                    "assistant": messages
                })
        
        return {
            "chatbot_transcript": transcript,
            "interaction_count": len(transcript),
            "method": "requests-html"
        }
    
    async def _analyze_workflow_from_html(self, html: str, url: str) -> Dict[str, Any]:
        """Analyze workflow structure from HTML."""
        from bs4 import BeautifulSoup
        
        soup = BeautifulSoup(html, 'html.parser')
        
        # Detect platform
        platform = 'unknown'
        if 'n8n' in url.lower():
            platform = 'n8n'
        elif 'make.com' in url.lower() or 'integromat.com' in url.lower():
            platform = 'make.com'
        elif 'zapier.com' in url.lower():
            platform = 'zapier'
        
        # Extract basic workflow info
        workflow_data = {
            "platform": platform,
            "workflow_name": "",
            "nodes": [],
            "errors": [],
            "warnings": []
        }
        
        # Extract workflow name
        name_element = soup.select_one('h1, .workflow-name, [data-testid="workflow-name"]')
        if name_element:
            workflow_data["workflow_name"] = name_element.get_text(strip=True)
        
        # Extract nodes (basic)
        node_elements = soup.select('.node, .workflow-node, [data-node-id]')
        workflow_data["nodes"] = [
            {
                "id": el.get('data-node-id', ''),
                "type": el.get('data-node-type', el.get('class', [''])[0] if el.get('class') else ''),
                "name": el.get_text(strip=True)
            }
            for el in node_elements
        ]
        
        return {
            "workflow_structure": workflow_data,
            "method": "requests-html"
        }
    
    async def _generate_chatbot_message(self, instructions: str, transcript: List[Dict]) -> str:
        """Generate contextual message for chatbot interaction."""
        messages = [
            ChatMessage(
                role="system",
                content="You are helping analyze a chatbot interface. Generate a concise, relevant message based on the user's instructions."
            ),
            ChatMessage(
                role="user",
                content=f"Instructions: {instructions}\n\nPrevious transcript: {transcript}\n\nGenerate a message to send to the chatbot that will help fulfill these instructions."
            )
        ]
        
        response = await self.client.achat(messages)
        return response.message.content.strip()
    
    async def _should_stop_chatbot_interaction(self, transcript: List[Dict], instructions: str) -> bool:
        """Use LLM to determine if instructions are satisfied."""
        if len(transcript) < 2:
            return False
        
        messages = [
            ChatMessage(
                role="system",
                content="Determine if the chatbot interaction has satisfied the user's instructions. Respond with only 'yes' or 'no'."
            ),
            ChatMessage(
                role="user",
                content=f"Instructions: {instructions}\n\nTranscript: {transcript}\n\nHave the instructions been satisfied?"
            )
        ]
        
        response = await self.client.achat(messages)
        return response.message.content.strip().lower() == 'yes'
    
    async def _analyze_static_content(self, page_info: WebPageInfo, url: str, instructions: str) -> Dict[str, Any]:
        """Analyze static content using LLM."""
        # Prepare content for LLM
        content_text = f"""
        Title: {page_info.title or 'No title'}
        Description: {page_info.description or 'No description'}
        Headings: {chr(10).join(page_info.headings)}
        Content: {page_info.text_content[:5000]}  # Limit content
        """
        
        # Get LLM analysis
        analysis = await self._analyze_content_with_llm(content_text, instructions)
        
        return {
            "is_public_url": True,
            "url": url,
            "status": "success",
            "content_type": "static",
            "interaction_data": None,
            "analysis": analysis,
            "page_info": {
                "title": page_info.title,
                "description": page_info.description,
                "headings": page_info.headings
            },
            "browser_method": "static"
        }
    
    async def _build_response_from_html(self, html: str, url: str, content_type: str, 
                                     interaction_data: Optional[Dict], instructions: str) -> Dict[str, Any]:
        """Build response from HTML content."""
        from bs4 import BeautifulSoup
        
        soup = BeautifulSoup(html, 'html.parser')
        
        # Extract page info
        title_tag = soup.find('title')
        title = title_tag.get_text(strip=True) if title_tag else ""
        
        desc_tag = soup.find('meta', attrs={'name': 'description'})
        description = desc_tag.get('content', '') if desc_tag else ""
        
        # Extract headings
        headings = []
        for h in soup.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6']):
            text = h.get_text(strip=True)
            if text:
                headings.append(text)
        
        # Extract text content
        for script in soup(['script', 'style', 'nav', 'footer', 'header']):
            script.decompose()
        text_content = soup.get_text(separator='\n', strip=True)
        
        # Get LLM analysis
        content_for_analysis = f"""
        Title: {title}
        Description: {description}
        Headings: {chr(10).join(headings[:20])}
        Content: {text_content[:5000]}
        """
        
        analysis = await self._analyze_content_with_llm(content_for_analysis, instructions)
        
        return {
            "is_public_url": True,
            "url": url,
            "status": "success",
            "content_type": content_type,
            "interaction_data": interaction_data,
            "analysis": analysis,
            "page_info": {
                "title": title,
                "description": description,
                "headings": headings[:50]
            },
            "browser_method": self._browser_method
        }
    
    async def _analyze_content_with_llm(self, content: str, instructions: str) -> Dict[str, Any]:
        """Analyze content using LLM with structured output."""
        messages = [
            ChatMessage(
                role="system",
                content="""You are a web content analyzer. Analyze the provided webpage content against user instructions and provide a detailed assessment.

## Your Task:
1. Review the webpage content (title, headings, paragraphs, text)
2. Evaluate how well it matches the user's instructions
3. Provide specific findings with evidence from the page
4. Rate the match quality (high/medium/low/none)

## Output Format:
Return a structured JSON with:
- summary: Brief overview of findings
- match_quality: "high" | "medium" | "low" | "none"
- key_findings: List of specific observations
- evidence: Relevant excerpts from the page
- recommendations: Next steps or additional analysis needed"""
            ),
            ChatMessage(
                role="user",
                content=f"Instructions: {instructions}\n\nContent to analyze:\n{content}"
            )
        ]
        
        response = await self.client.achat(
            messages,
            response_format={
                "type": "json_schema",
                "json_schema": {
                    "name": "ContentAnalysis",
                    "strict": True,
                    "schema": {
                        "type": "object",
                        "properties": {
                            "summary": {"type": "string"},
                            "match_quality": {"type": "string", "enum": ["high", "medium", "low", "none"]},
                            "key_findings": {"type": "array", "items": {"type": "string"}},
                            "evidence": {"type": "array", "items": {"type": "string"}},
                            "recommendations": {"type": "array", "items": {"type": "string"}}
                        },
                        "required": ["summary", "match_quality", "key_findings", "evidence", "recommendations"],
                        "additionalProperties": False
                    }
                }
            },
            plugins=[
                {"id": "response-healing"}
            ],
            provider={
                "require_parameters": True
            }
        )
        
        try:
            return json.loads(response.message.content)
        except json.JSONDecodeError:
            # Fallback if JSON parsing fails
            return {
                "summary": "Analysis completed but parsing failed",
                "match_quality": "medium",
                "key_findings": ["Content was analyzed"],
                "evidence": [response.message.content[:200]],
                "recommendations": ["Review content manually"]
            }
    
    async def close(self):
        """Clean up all resources."""
        await self._http_client.aclose()
        if self._html_session:
            await self._html_session.close()


__all__ = ["UrlCrawlerAgent"]
