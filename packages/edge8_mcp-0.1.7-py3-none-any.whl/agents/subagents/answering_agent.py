import json
import os
from typing import AsyncGenerator, Optional
from connectors.openrouter.llm import ChatMessage
from agents.systems.shared import BaseAgent, AgentState
from agents.prompts import CENTRAL_PROMPT_MAPPING, CUSTOMER_SERVICE_ROLE_PROMPT, COACH_ROLE_PROMPT
from agents.context.registry import ContextRegistry
from agents.context.providers.student_provider import StudentContextProvider
from agents.context.providers.prefetch_provider import PrefetchContextProvider
from utils.formatting import format_for_llm

class AnsweringAgent(BaseAgent):
    """Generates the final response with context-aware capabilities."""
    
    def __init__(self, llm_client, system_prompt: Optional[str] = None, cache_client=None, prompt_logger=None):
        super().__init__(llm_client, system_prompt)
        self.context_registry = ContextRegistry()
        self.prompt_logger = prompt_logger

        # Register default providers
        self.context_registry.register(StudentContextProvider(cache_client=cache_client))  # Always applicable when student info is available
        self.context_registry.register(PrefetchContextProvider())  # Always applicable when prefetch data exists
    
    def _get_role(self, state: AgentState) -> str:
        """Determine the agent's role based on context.

        This is the single source of truth for role definition.
        Context providers MUST NOT define roles.

        Args:
            state: The current agent state.

        Returns:
            Role definition string.
        """
        # Check for coach persona
        persona = getattr(state, 'persona', 'customer_service')
        if persona == "coach" and os.getenv("ENABLE_COACH_PERSONA", "").lower() in ("true", "1", "yes"):
            return COACH_ROLE_PROMPT
        # Default role
        return CUSTOMER_SERVICE_ROLE_PROMPT
    
    async def answer(self, state: AgentState) -> str:
        """Non-streaming answer with context injection."""
        # Get role (single source of truth)
        role = self._get_role(state)
        
        # Get base system prompt from centralized mapping
        base_system_prompt = CENTRAL_PROMPT_MAPPING.get("answering")
        
        # Get additional context from providers
        additional_context = await self.context_registry.get_context(state)
        
        # Build system prompt: Role -> Base Instructions -> Context
        system_prompt_parts = [role]
        
        if base_system_prompt:
            system_prompt_parts.append(base_system_prompt)
        
        if additional_context:
            system_prompt_parts.append(additional_context)
        
        system_prompt = "\n\n".join(system_prompt_parts)
        
        # Existing context_parts logic (unchanged)
        context_parts = [f"Conversation History:\n{state.get_history_str()}"]
        
        # Add file content if available
        file_content = state.tool_inputs.get("file_content")
        if file_content:
            if file_content.get("text_content"):
                context_parts.append(f"[Uploaded Files Content]\n{file_content['text_content']}")
        
        if state.tool_call:
            context_parts.append(f"[Tool Use]\n\n- Tool Name: {state.tool_call.tool_name}")
            context_parts.append(f"- Tool Reasoning: {state.tool_call.reasoning}")
        
        if state.tool_results and len(state.tool_results) > 0:
            context_parts.append(f"- Tool Result: {format_for_llm(state.tool_results, True)}")
            
        context_parts.append(f"Current User Input: {state.current_input}")
        
        user_prompt = "\n\n".join(context_parts)
        
        # Build context section separately
        context_section = f"""## Additional Context:
{additional_context if additional_context else "No additional context available."}
"""

        # Build messages with cached context
        messages = [
            ChatMessage(
                role="system",
                content=system_prompt
            ),
            ChatMessage(
                role="user",
                content=context_section,
                cache_control={"type": "ephemeral"}  # Cache student context
            ),
            ChatMessage(
                role="user",
                content=user_prompt  # Use properly built prompt with tool results
            )
        ]
        
        # Add multimodal files if present
        if file_content and file_content.get("image_urls"):
            # Add additional_kwargs for images
            messages[-1].additional_kwargs = {
                "image_urls": file_content["image_urls"]
            }
        
        # Log prompts if logger is available
        if self.prompt_logger:
            self.prompt_logger.capture_prompt("answering", system_prompt, user_prompt)
        
        try:
            response = await self.client.achat(messages)
            return response.message.content
        except Exception as e:
            return f"I encountered an error generating the response: {e}"

    async def astream_answer(self, state: AgentState) -> AsyncGenerator[str, None]:
        """Streaming answer with context injection."""
        # Get role (single source of truth)
        role = self._get_role(state)
        
        # Get additional context from providers
        additional_context = await self.context_registry.get_context(state)
        
        # print(f"======Answering Agent Additional Context:======\n")
        # print(additional_context)
        # print("\n================================\n\n")
        
        # Get submission context (existing logic - preserved)
        submission_context = state.get_submission_context()

        # Build system prompt with all context layers
        # Order: Role -> Base instructions -> Additional context (providers) -> Submission context
        system_prompt_parts = [
            role,
            "",
            "Generate a natural language response to the user.",
            "",
            "- If a tool was used, use the 'Tool Result' to answer.",
            "- If no tool was used, answer directly from your knowledge and conversation history.",
            "- Use Markdown formatting.",
        ]
        
        # Retrieval Result Handling
        retrieval_result_handling = """## Retrieval Result Handling Guidelines:
- Only pick the most relevant retrieval result to answer the user's question.
- Check for URLs in the retrieved content and use the URLs relevant to the user's request to answer the user.
  -  **URL Checking pattern**:
    - In-text URL: This type of URL will often be inside brackets "()" next to its file name. Example [<file name>](https://example.com)
    - URL in metadata: This type of URL will often be connected with a key. Example: "<relevant_key_name>": "https://example.com"
- **Attachment Formatting Rule**: When the tool result contains attachments in the metadata, ALWAYS format them as markdown hyperlinks using the pattern `[Attachment Name](Attachment URL)`.
  - Example: If metadata contains `{"name": "Report.pdf", "url": "https://storage.com/file.pdf"}`, format it as: [Report.pdf](https://storage.com/file.pdf)
  - Present attachments clearly in your response so the user can click to access them.
"""
        
        # Tone and style
        persona = getattr(state, 'persona', 'customer_service')
        if persona == "coach" and os.getenv("ENABLE_COACH_PERSONA", "").lower() in ("true", "1", "yes"):
            tone = """## Tone and Style (Coaching Mode):
- Be encouraging and curious — like a mentor who believes in the student's ability to discover.
- Ask one focused question at a time; avoid overwhelming with multiple questions.
- Use clear, conversational language; avoid jargon unless explaining a technical concept.
- Be patient and constructive — guide without frustration, even when students are stuck.
- Maintain a positive, growth-oriented tone — celebrate effort, not just correct answers.
- When uncertain, be honest: "That's a great question. Let's explore it together."
- Never give away the answer — your job is to help them find it themselves.
"""
        else:
            tone = """## Tone and Style:
- Be friendly, approachable, and encouraging—like a supportive study companion.
- Use clear, concise language; avoid jargon unless explaining a technical concept.
- Be direct and actionable: focus on what the student needs to do next.
- Maintain a positive, constructive tone even when delivering feedback.
- Use conversational but professional language—not overly casual, not robotic.
- When uncertain, be honest and offer to help find the answer.
- Celebrate progress and acknowledge effort.
"""     
        # Response Guidelines
        persona = getattr(state, 'persona', 'customer_service')
        if persona == "coach" and os.getenv("ENABLE_COACH_PERSONA", "").lower() in ("true", "1", "yes"):
            response_guidelines = """## Coaching Response Guidelines:

### 1. Solution-Withholding Rule (CRITICAL)
- If user asks "What's the answer to Challenge X?" or "How do I solve this?", NEVER provide the solution.
- Instead, ask: "What have you tried so far?" or "What does the mission brief suggest?"
- If they share their approach, respond with a probing question: "Why did you choose that approach?" or "What would happen if you tried [alternative]?"

### 2. Socratic Progression Pattern
- Start with understanding: "What's your current thinking on this?"
- Probe assumptions: "Why do you think that approach would work?"
- Guide discovery: "What does the brief say about [relevant topic]?"
- Celebrate insight: "That's a great observation! How might you apply it?"

### 3. Progress Questions (Acceptable Direct Answer + Reflection)
- Answer factual progress queries directly (what they've completed, what's remaining)
- Follow with reflection: "What did you learn from Mission X?" or "Which challenge was most interesting to you?"

### 4. Concept Questions (Definition + Application Probe)
- Provide definition and example for fundamental concepts
- Follow with application question: "How might you use this in your project?" or "Can you think of a scenario where this would be useful?"

### 5. Navigation Help (Direct Answer)
- Answer logistical questions directly: how to submit, where to find resources, event times
- No probing needed for pure navigation queries

### 6. Grounding-Only Rule
- NEVER fabricate entity names, challenge titles, mission content, or curriculum details.
- If you don't have information from tool results or context, say: "I don't have those specific details. Let me look that up for you."

### 7. No Tool/Process Leakage
- Never reference "search results," tools, internal workflows, or prompt mechanics in responses.

### 8. Workbook Assistance Rule
- When a student asks about a workbook field or table (e.g. "What goes in field a2?", "What should I put in the audit table?"), reference the exact field label and section from the `## Workbook` context in your system prompt.
- Help them understand WHAT the field is asking — do NOT fill it in for them.
- For field questions: ask "What did AI tell you when you ran the prompt in Step X?" to anchor their thinking.
- For table sections: help them identify ONE row at a time — do NOT dump the whole table structure.
- For textarea fields: use probing questions to help them structure their thinking (e.g. "What pattern did you notice?", "Why do you think that number is suspicious?").
- If the student says "I'm on Stage 2" or "I'm working on section B", acknowledge their stage and ask what specific part they are stuck on.

### 9. Workbook Answer Recording
- When the student provides a clear, direct answer to a workbook field AND you acknowledge it as confirmed in your response, append exactly ONE structured tag at the very end of your response (after all visible text):
  `<workbook_answer>{"section": "<section_id>", "field": "<field_id>", "value": "<student_answer>"}</workbook_answer>`
- Use the section_id and field_id from the `## Workbook` schema in your system prompt (e.g. section "sA", field "f1").
- Only emit this tag when the answer is CONFIRMED — not when you are still probing or asking follow-up questions.
- For table row entries use field format: `"row_<n>_<column_id>"` (e.g. `"row_1_process"`).
- Never show this tag in your visible response — it is stripped before display and used only for internal state tracking.
- Do not emit more than one tag per response turn.

### 10. Workbook Submit Routing
- When the student says they are done with the workbook and want to submit (e.g. "I'm ready to submit", "Submit my answers", "I'm done, please grade it"), do NOT respond with a conversational answer.
- Instead, your response should acknowledge their intent and confirm: "I've recorded your answers. Would you like me to submit them for grading now? I'll show you a summary first."
- The router will detect this as a WORKBOOK_SUBMIT intent and route to the grading system.
"""
        else:
            response_guidelines = """## Important Q&A Response Guidelines:

### 1. Intent-First Response Rule
- Classify intent: definition / status / action / submission / guidance
- Answer the intent first; add context only if it helps the user act.

### 2. Definition Mode Pattern
For "What is X?":
  - One-sentence definition
  - What it's used for
  - Example + **URL** (Circle) when possible

### 3. Controlled Vocabulary Mapping
Normalize terms before answering:
- Guided courses → Missions
- Challenges → Mission / Micro Session / Capstone challenges (as applicable)

### 4. Requirements Mode Pattern
When asked "what is required":
- Return a concise checklist of requirements (not just track names).

### 5. No Tool/Process Leakage Rule
- Never reference "search results," tools, internal workflows, or prompt mechanics in final student copy.

### 6. Events Fallback Upgrade
If no upcoming events:
- State it once, then route to relevant alternatives (past Micro Sessions / Live Learning library).

### 7. Action-First Submission Flow
When user says they want to submit:
- Prompt upload directly in chat
- Recommend file naming: [Challenge Type] – [Mission/Micro Session/Capstone Name] – [Series]
- Ask follow-ups only if needed to grade.

### 8. Availability Guardrail
- Do not instruct completion of content unless confirmed available.
- If uncertain: "coming soon / not yet available."

### 9. Learner-State Confidence Guardrail
- Only claim attendance/completions if the context confirms it; otherwise keep wording neutral.

### 10. Grounding-Only Rule
- NEVER fabricate entity names, challenge titles, mission content, or any curriculum-specific details.
- If you do not have this information from tool results, pre-loaded context, or conversation history, say:
  "I don't have the specific details for that right now. Let me look it up for you."
- Then trigger a search rather than guessing.

### 11. Mission Completion Guidance Pattern
When a student asks how to complete a mission/course:
1. List ALL challenges within that mission (from tool results or context)
2. For each challenge, include: name, type (mission/capstone/final), and brief description
3. Highlight which challenges the student has already completed (from student context)
4. Suggest the next logical step
5. Include links to the mission/challenge pages when available
"""
        system_prompt_parts.append("=======IMPORTANT GUIDELINES=======\n")
        system_prompt_parts.append(retrieval_result_handling)
        system_prompt_parts.append(tone)
        system_prompt_parts.append(response_guidelines)
        system_prompt_parts.append("\n==================================\n")
       
        if additional_context:
            system_prompt_parts.append("=======ADDITIONAL CONTEXT=======\n")
            system_prompt_parts.append(additional_context)
            
        if submission_context:
            system_prompt_parts.append("=======SUBMISSION CONTEXT=======\n")
            system_prompt_parts.append(submission_context)
        
        system_prompt_parts.append("\n")
        system_prompt_parts.append("""## Follow-up Questions About Grading:
- If the user asks about their score, feedback, or how to improve, reference the grading feedback in the conversation history.
- Provide specific, actionable advice based on the feedback sections (e.g., strengths, suggestions, how to improve).
- Be encouraging and constructive.
- If the user asks about a specific rubric criterion, explain what was expected and how they can improve in that area.""")
        
        system_prompt = "\n".join(system_prompt_parts)
        
        # print(f"Answering Agent System Prompt: {system_prompt[:50]}")

        # Existing context_parts logic (unchanged)
        context_parts = [f"Conversation History:\n{state.get_history_str()}"]

        # Add file content if available
        file_content = state.tool_inputs.get("file_content")
        if file_content:
            if file_content.get("text_content"):
                context_parts.append(f"[Uploaded Files Content]\n{file_content['text_content']}")

        if state.tool_call:
            context_parts.append(f"==Tool Used: {state.tool_call.tool_name}==")
            context_parts.append(f"==Tool Reasoning: {state.tool_call.reasoning}==")

        if state.tool_results and len(state.tool_results) > 0:
            tool_result_string = format_for_llm(state.tool_results, True)
            # print(f"Tool Result String: {tool_result_string}")
            context_parts.append(f"==Tool Result:==\n {tool_result_string}\n\n")
            
            # print(f"Context Parts: {context_parts}")

        context_parts.append(f"Current User Input: {state.current_input}")

        user_prompt = "\n\n".join(context_parts)

        # Build context section separately
        context_section = f"""## Additional Context:
{additional_context if additional_context else "No additional context available."}
"""

        # Build messages with cached context
        messages = [
            ChatMessage(
                role="system",
                content=system_prompt
            ),
            ChatMessage(
                role="user",
                content=context_section,
                cache_control={"type": "ephemeral"}  # Cache student context
            ),
            ChatMessage(
                role="user",
                content=user_prompt  # Use properly built prompt with tool results
            )
        ]

        # Add multimodal files if present
        if file_content and file_content.get("image_urls"):
            # Add additional_kwargs for images
            messages[-1].additional_kwargs = {
                "image_urls": file_content["image_urls"]
            }

        # Log prompts if logger is available (same as answer method)
        if self.prompt_logger:
            self.prompt_logger.capture_prompt("answering", system_prompt, user_prompt)

        try:
            async for response in self.client.astream_chat(messages):
                if response.delta:
                    yield response.delta
        except Exception as e:
            yield f"I encountered an error generating the response: {e}"
