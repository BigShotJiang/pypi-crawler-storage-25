import asyncio
from typing import Dict, Any, Optional, List
from agents.systems.shared import AgentState, BaseAgent
from agents.tools.database.aio import DatabaseToolHandler
from connectors.openrouter.llm import OpenRouterMultimodalLLM, ChatMessage


class IntentVerificationAgent(BaseAgent):
    """Verify user intent for submission and request clarification if needed"""

    def __init__(self, llm: OpenRouterMultimodalLLM):
        super().__init__(llm)
        self.db_handler = DatabaseToolHandler()

    async def verify_submission_intent(
        self,
        state: AgentState,
        email: Optional[str] = None,
        files: Optional[List[dict]] = None
    ) -> tuple[bool, str, Optional[Dict[str, Any]]]:
        """
        Verify if user intends to submit for grading.

        Returns:
            (is_confirmed, response_message, submission_metadata)
        """
        # Detect challenge from input (supports all entity types)
        detected_challenge = await self.db_handler.detect_challenge_from_text_or_files(
            user_message=state.current_input,
            file_names=[f.get("filename") or f.get('name') or f.get('file_name') for f in files] if files else []
        )

        if not detected_challenge:
            # Challenge unclear - ask for clarification
            question = await self._generate_mission_clarification(state)
            return False, question, None

        # Check if submission content is sufficient
        has_files = len(files) > 0 if files else False
        has_content = len(state.current_input.strip()) > 50

        if not has_files and not has_content:
            return False, "I don't see any files or detailed content. Please provide your submission files or describe your work.", None

        # Confirm intent with user
        confirmation = await self._request_confirmation(state, detected_challenge, has_files)

        # Store pending submission state
        submission_metadata = {
            "challenge": detected_challenge,
            "email": email,
            "files": files,
            "text_content": state.current_input,
            "has_files": has_files,
            "has_content": has_content
        }

        return False, confirmation, submission_metadata

    async def _generate_mission_clarification(self, state: AgentState) -> str:
        """Generate clarification message requesting files and challenge name"""
        
        system_prompt = f"""You are an AI-Officer Program grading submission assistant who helps students with the naming convention for their submission.
The user wants to submit an assignment but didn't specify which challenge.

Ask them to:
1. Upload their submission files (PDF, documents, images, etc.)
2. Provide the challenge name in one of these formats:

   For **Mission Final Challenges**:
   **Mission [Number] - [Series Name]**

   For **Mission Intermediate Challenges**:
   **[Challenge Name] - Mission [Number] - [Series Name]**

   For **Micro Session Challenges**:
   **Micro Session [Number] - [Series/Space Name]**

   For **Workshop Challenges**:
   **Workshop [Number] - [Series Name]**

   For **Capstone Challenges**:
   **Capstone - [Series Name]**

Important:
- Never suggest "Capstone - Agentic AI Essentials".
- If asked about "Business AI Essentials", respond with "Challenges related to Business AI Essentials are not available. Please submit for a different challenge.".

Examples:
- "Mission 1 - Generative AI Essentials" (final challenge of Mission 1)
- "AI Strategy Challenge - Mission 2 - Generative AI Essentials" (intermediate challenge)
- "Micro Session 3 - AI Officer Program"
- "Workshop 2 - AI Officer Program"
- "Capstone - Generative AI Essentials"

Be concise and helpful."""

        response = await self.client.achat([
            ChatMessage(role="system", content=system_prompt, cache_control={"type": "ephemeral", "ttl": "1h"}),
            ChatMessage(role="user", content=state.current_input)
        ])

        return response.message.content.strip()

    async def _request_confirmation(self, state: AgentState, challenge: Dict[str, Any], has_files: bool) -> str:
        """Generate confirmation message with challenge-type-aware description"""
        entity_type = challenge.get("entity_type", "challenge")
        entity_name = challenge.get("entity_name", "unknown")
        challenge_name = challenge.get("challenge_name")
        series_name = challenge.get("series_name")
        
        # Build human-readable challenge description based on entity type
        entity_type_labels = {
            "mission": "Mission",
            "workshop": "Workshop",
            "micro_session": "Micro Session",
            "capstone": "Capstone",
        }
        entity_label = entity_type_labels.get(entity_type, entity_type.replace("_", " ").title())
        
        # Build description parts
        parts: list[str] = []
        if challenge_name:
            parts.append(f"challenge **{challenge_name}**")
            parts.append(f"in {entity_label}: {entity_name}")
        else:
            parts.append(f"**{entity_label}: {entity_name}**")
        if series_name:
            parts.append(f"({series_name})")
        
        description = " ".join(parts)
        content_desc = "files" if has_files else "text content"
        
        return f"""I see you're submitting for {description} with {content_desc}.

Are you ready to proceed with grading? (yes/no)"""

    async def verify_submission_intent_with_bulk(
        self,
        state: AgentState,
        email: Optional[str] = None,
        files: Optional[List[dict]] = None,
        bulk_detector=None,
    ) -> tuple[bool, str, Optional[Dict[str, Any]]]:
        """Like verify_submission_intent but runs bulk challenge detection in parallel
        with the confirmation LLM call, reducing total latency.

        Returns:
            (is_confirmed, response_message, submission_metadata)
            submission_metadata will have 'is_bulk' and 'all_challenges' set if bulk.
        """
        detected_challenge = await self.db_handler.detect_challenge_from_text_or_files(
            user_message=state.current_input,
            file_names=[f.get("filename") or f.get("name") or f.get("file_name") for f in files] if files else [],
        )

        if not detected_challenge:
            question = await self._generate_mission_clarification(state)
            return False, question, None

        has_files = len(files) > 0 if files else False
        has_content = len(state.current_input.strip()) > 50

        if not has_files and not has_content:
            return False, "I don't see any files or detailed content. Please provide your submission files or describe your work.", None

        # Run confirmation LLM call and bulk DB query concurrently
        entity_id = detected_challenge.get("entity_id")
        can_bulk = bool(bulk_detector and entity_id)

        async def _bulk_fetch():
            if not can_bulk:
                return [detected_challenge]
            try:
                return await bulk_detector.detect_all_challenges_for_mission(detected_challenge)
            except Exception as e:
                print(f"⚠️ Parallel bulk detection failed: {e}")
                return [detected_challenge]

        confirmation, all_challenges = await asyncio.gather(
            self._request_confirmation(state, detected_challenge, has_files),
            _bulk_fetch(),
        )

        submission_metadata: Dict[str, Any] = {
            "challenge": detected_challenge,
            "email": email,
            "files": files,
            "text_content": state.current_input,
            "has_files": has_files,
            "has_content": has_content,
        }

        if can_bulk and len(all_challenges) > 1:
            submission_metadata["is_bulk"] = True
            submission_metadata["all_challenges"] = all_challenges

        return False, confirmation, submission_metadata

    async def handle_confirmation_response(
        self,
        state: AgentState,
        response: str,
        pending_metadata: Dict[str, Any]
    ) -> tuple[bool, Optional[Dict[str, Any]]]:
        """
        Handle user's confirmation response.

        Returns:
            (proceed, updated_metadata)
        """
        response_lower = response.lower().strip()

        if response_lower in ["yes", "y", "yeah", "sure", "ok", "proceed"]:
            return True, pending_metadata
        elif response_lower in ["no", "n", "cancel"]:
            return False, None
        else:
            # Ambiguous response - ask again
            return False, None
