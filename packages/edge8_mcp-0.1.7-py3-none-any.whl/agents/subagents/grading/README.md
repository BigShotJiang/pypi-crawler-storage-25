# Grading Subagents

Specialized agents for the AI Officer Program grading system.

## Purpose

These agents handle the core LLM-based grading tasks:
- **Scoring:** Evaluate submissions against rubric criteria
- **Feedback:** Generate personalized, actionable feedback
- **Posting:** Post grading results to Circle community

## Agents

### ScorerAgentV2 (`scorer_agent_v2.py`)

Multimodal-native scoring agent that evaluates student submissions.

**Key Features:**
- Native multimodal input (text + PDFs + images)
- No pre-extraction needed - LLM reads files directly
- Structured markdown output with scores, justifications, strengths, and weaknesses

**Usage:**
```python
from src.agents.subagents.grading import ScorerAgentV2

scorer = ScorerAgentV2(model="google/gemini-2.5-flash")
results = await scorer.score_submission(
    text_content="Student's text submission...",
    rubric_content="Grading rubric...",
    challenge_name="Challenge 1",
    file_attachments=[
        {"name": "report.pdf", "url": "https://...", "mime_type": "application/pdf"}
    ]
)

for result in results:
    print(f"{result.criterion_name}: {result.score}/{result.max_points}")
    print(f"Justification: {result.justification}")
```

**Returns:**
- `List[ScoringResult]` with per-criterion scores, justifications, strengths, weaknesses

---

### UnifiedReflectorV2 (`unified_reflector_v2.py`)

Unified feedback and summary generation agent (single LLM call).

**Key Features:**
- Single LLM call produces both per-criterion feedback AND overall summary
- Multimodal input support (same as ScorerAgentV2)
- Resubmission-aware (compares to prior submission)
- Streaming support for real-time feedback

**Usage:**
```python
from src.agents.subagents.grading import UnifiedReflectorV2

reflector = UnifiedReflectorV2(models=["google/gemini-2.5-flash"])

# Non-streaming
feedback_results, overall_summary = await reflector.generate_feedback_and_summary(
    text_content="Student's submission...",
    rubric_content="Grading rubric...",
    student_name="John Doe",
    challenge_name="Challenge 1",
    file_attachments=[...],
    prior_submission_content="Previous submission...",  # For resubmissions
    prior_score=75.0  # For resubmissions
)

# Streaming
async for event in reflector.generate_feedback_and_summary_streaming(...):
    if event["type"] == "chunk":
        print(event["content"], end="", flush=True)
    elif event["type"] == "complete":
        feedback_results = event["feedback_results"]
        overall_summary = event["overall_summary"]
```

**Returns:**
- `Tuple[List[FeedbackResult], str]` - feedback per criterion + overall summary

---

### SubmissionPostAgent (`submission_post_agent.py`)

Agent for posting grading results to Circle community.

**Key Features:**
- Creates formatted posts with grading results
- Handles Circle API authentication
- Supports both public and private posts

**Usage:**
```python
from src.agents.subagents.grading import SubmissionPostAgent

post_agent = SubmissionPostAgent()
result = await post_agent.post_grading_result(
    student_email="student@example.com",
    challenge_name="Challenge 1",
    grading_report=report,
    space_id=123
)
```

**Returns:**
- `Dict[str, Any]` with post URL and success status

---

## Design Principles

1. **Multimodal-First:** All agents accept native multimodal input (text + files)
2. **Efficiency:** v2 agents reduce LLM calls from 4 → 2
3. **Streaming Support:** Real-time feedback for better UX
4. **Resubmission-Aware:** Agents compare to prior submissions when applicable
5. **Type Safety:** All inputs/outputs use Pydantic models

## Performance Metrics

| Metric | v1 (Legacy) | v2 (Current) | Improvement |
|--------|-------------|--------------|-------------|
| LLM Calls | 4 | 2 | 50% reduction |
| Avg Latency | 18-25s | 12-18s | 6-13s faster |
| Multimodal Support | No | Yes | Native |
| Streaming | No | Yes | Real-time |

## Dependencies

- `src.connectors.openrouter.llm` - LLM client
- `src.agents.systems.grading_system.models` - Pydantic models
- OpenRouter API key (env: `OPENROUTER_API_KEY`)

## Testing

Run grading agent tests:
```bash
pytest tests/grading/ -k "scorer or reflector or v2" -v
```

## Migration from v1

If you're using legacy grading agents:

```python
# OLD (deprecated)
from src.agents.systems.grading_system.legacy.grading_agents import (
    ScorerAgent,
    ReflectorAgent,
    FeedbackAgent,
    OverallSummaryAgent
)

# NEW (recommended)
from src.agents.subagents.grading import (
    ScorerAgentV2,
    UnifiedReflectorV2
)
```

**Key differences:**
- v2 agents accept multimodal input directly (no pre-extraction)
- UnifiedReflectorV2 replaces 3 separate agents (Reflector + Feedback + OverallSummary)
- v2 agents use Pydantic models for type safety

## Related Documentation

- **Grading System Overview:** `src/agents/systems/grading_system/README.md`
- **Integration Guide:** `src/agents/systems/grading_system/docs/INTEGRATION_GUIDE.md`
- **Quickstart:** `src/agents/systems/grading_system/QUICKSTART.md`
