"""
Unified Reflector Agent V2 - Single LLM call for feedback + summary

Key differences from v1:
- Single LLM call produces both per-criterion feedback AND the overall narrative summary
- Accepts multimodal input (same as ScorerAgentV2)
- Returns a tuple: (List[FeedbackResult], str) — feedback + overall_summary
"""

import os
import asyncio
import re
from typing import Dict, Any, List, Optional, AsyncGenerator

from agents.systems.grading_system.models import FeedbackResult
from connectors.openrouter.llm import OpenRouterMultimodalLLM, ChatMessage

OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY", "")
DEFAULT_MODEL_V2 = "google/gemini-2.5-flash"


class UnifiedReflectorV2:
    """
    Unified Reflector Agent V2 - Single LLM call for feedback + summary

    Key differences from v1:
    - Single LLM call produces both per-criterion feedback AND the overall narrative summary
    - Accepts multimodal input (same as ScorerAgentV2)
    - Returns a tuple: (List[FeedbackResult], str) — feedback + overall_summary
    """

    def __init__(self, api_key: str = OPENROUTER_API_KEY, models: list[str] = [DEFAULT_MODEL_V2]):
        self.llm = OpenRouterMultimodalLLM(api_key=api_key, fallback_models=models)
        self.system_prompt = """You are the Reflector persona of the AI Buddy Grader for the AI Officer Program — an executive education platform.

## Your Role
Transform technical scoring into warm, specific, actionable feedback for working professionals. Reference concrete details from submissions. Adapt tone based on performance.

## Anti-Repetition Rules (CRITICAL)
- NEVER use generic phrases like "Great job!", "Well done!" without specific details
- NEVER repeat feedback patterns — vary sentence structure and framing
- If you mention a strength, name the EXACT thing done — not a category

## Tone Adaptation
- Score >= 80%: Celebratory. Highlight standout work. Brief polish suggestions only.
- Score 50-79%: Encouraging. Acknowledge effort, then 2-3 targeted improvements.
- Score < 50%: Supportive. Find positives, be direct about fundamentals, 2-3 concrete first steps."""

    def _extract_section(self, text: str, pattern: str, default: str = "") -> str:
        """Extract a section from markdown text using regex pattern"""
        match = re.search(pattern, text, re.DOTALL)
        if match:
            return match.group(1).strip()
        return default

    async def generate_feedback_and_summary(
        self,
        text_content: str,
        rubric_content: str,
        student_name: str,
        challenge_name: str,
        file_attachments: Optional[List[Dict[str, Any]]] = None,
        prior_submission_content: Optional[str] = None,
        prior_score: Optional[float] = None,
    ) -> tuple[List[FeedbackResult], str]:
        """
        Generate per-criterion feedback AND overall narrative summary in one LLM call.

        Args:
            text_content: Student's submission text
            rubric_content: Grading rubric
            student_name: Student's name
            challenge_name: Challenge/mission name
            file_attachments: Optional list of file attachment dicts
            prior_submission_content: Prior submission text for comparison (resubmissions only)
            prior_score: Prior submission score (resubmissions only)

        Returns:
            Tuple of (feedback_results, overall_summary_text)
        """
        MAX_SUBMISSION_LENGTH = 3000
        capped_submission = text_content[:MAX_SUBMISSION_LENGTH] if len(text_content) > MAX_SUBMISSION_LENGTH else text_content
        
        # Build resubmission context block if applicable
        is_resubmission = prior_score is not None
        resubmission_context = ""
        if is_resubmission:
            capped_prior = prior_submission_content[:500] if prior_submission_content else "Not available"
            resubmission_context = f"""

## RESUBMISSION CONTEXT (CRITICAL)
This is a RESUBMISSION. The student previously submitted this challenge and received {prior_score:.1f}%.

Previous submission (first 500 chars):
{capped_prior}...

### Your Task for Resubmission:
You MUST acknowledge this is a resubmission in your Overall Summary section. When writing the Overall Summary:
1. Open by acknowledging this is a resubmission
2. Compare specific elements from the prior submission vs current submission
3. Highlight what improved and what still needs work
4. Reference actual changes the student made

"""

        # Build unified feedback prompt (both sections in one call)
        feedback_prompt = f"""# FEEDBACK GENERATION TASK

## Student: {student_name}
## Mission: {challenge_name}

## Student Submission:
{capped_submission}
{"The student also submitted file(s) — see attached." if file_attachments else ""}

## Grading Rubric:
{rubric_content}
{resubmission_context}
## Your Task:
You must produce TWO sections in your response:

### SECTION 1: Per-Criterion Feedback
For each rubric criterion, provide feedback in this structure:

## [Criterion Name]

**Your Feedback:**
[2-4 sentences that weave together what worked, what didn't, and what to do next. Write naturally — not as a bulleted checklist.]

**How to Improve:**
- [Specific, actionable suggestion referencing their actual submission]
- [Another specific suggestion — only include if genuinely needed]

**My Encouragement:**
[One sentence — personal and specific to THIS criterion, not generic motivation]

---

### SECTION 2: Overall Summary
After all criteria, write a section starting with:

## Overall Summary

Write a 250-300 word narrative feedback summary addressed to {student_name}.

Rules for Overall Summary:
1. **Open naturally** — greet {student_name} by name and acknowledge the specific mission. Do NOT use generic openers like "Congratulations on completing this assignment!"
2. **Weave, don't list** — Do NOT repeat the per-criterion template. Write a flowing narrative that naturally references the most important points.
3. **Be specific** — Every piece of praise or criticism must reference something concrete from their submission.
4. **Vary your language** — Never start two consecutive sentences with the same word. Never use the same adjective twice.
5. **End with forward momentum** — Close with something that makes them want to tackle the next challenge.

## CRITICAL RULES:
- Reference the student's ACTUAL words, examples, or decisions — not generic categories
- NEVER repeat the same sentence structure across criteria. Vary your openings, transitions, and framing.
- NEVER use "Great job!" / "Well done!" / "Keep it up!" without a specific detail immediately after
- Each criterion's feedback should feel distinct — different length, different structure, different voice
- Keep each criterion's feedback concise (80-120 words)"""

        # Build additional_kwargs for multimodal
        additional_kwargs = {
            'sort': 'latency',
            'max_tokens': 1500,
        }

        if file_attachments:
            files_list = []
            image_urls = []
            for att in file_attachments:
                mime = att.get("mime_type", "")
                if mime.startswith("image/"):
                    image_urls.append(att.get("url") or att.get("data"))
                else:
                    files_list.append({
                        "name": att.get("name", "attachment"),
                        "content": att.get("url") or att.get("data"),
                    })
            if files_list:
                additional_kwargs["files"] = files_list
            if image_urls:
                additional_kwargs["image_urls"] = image_urls

        # Prepare messages
        system_message = ChatMessage(role="system", content=self.system_prompt)
        user_message = ChatMessage(role="user", content=feedback_prompt, additional_kwargs=additional_kwargs if file_attachments else {})
        messages = [system_message, user_message]

        # Call LLM with retry logic
        backoff_counter = 0
        response = ""
        while True:
            try:
                response_obj = await self.llm.achat(messages, **additional_kwargs)
                response = response_obj.message.content
                break
            except Exception as e:
                backoff_counter += 1
                if backoff_counter == 5:
                    print("Failed to get LLM response after 5 attempts:", e)
                    raise e
                await asyncio.sleep(5)

        # Parse the response - split into criteria section and overall summary
        response_text = response.strip().replace("```markdown\n", "").replace("```", "")

        # Split off the Overall Summary section
        overall_split = re.split(r'^## Overall Summary\s*$', response_text, flags=re.MULTILINE)

        if len(overall_split) >= 2:
            criteria_text = overall_split[0].strip()
            overall_summary = overall_split[1].strip()
        else:
            # Fallback: no explicit Overall Summary header found
            criteria_text = response_text
            overall_summary = ""

        # Parse per-criterion feedback from criteria_text
        try:
            feedback_results = []

            # Split by criterion sections
            criterion_sections = re.split(r'^## ', criteria_text, flags=re.MULTILINE)[1:]

            for section in criterion_sections:
                lines = section.split('\n')
                criterion_name = lines[0].strip()

                # Extract feedback components using regex
                student_feedback = self._extract_section(
                    section,
                    r'\*\*Your Feedback:\*\*\s*(.+?)(?=\*\*How to Improve:|---)',
                    ""
                )

                # Extract actionable suggestions (bullet points)
                actionable_suggestions = []
                improve_match = re.search(
                    r'\*\*How to Improve:\*\*(.+?)(?=\*\*My Encouragement:|---)',
                    section,
                    re.DOTALL
                )
                if improve_match:
                    improve_text = improve_match.group(1)
                    actionable_suggestions = [
                        s.strip('- ').strip()
                        for s in improve_text.split('\n')
                        if s.strip().startswith('-')
                    ]

                encouragement = self._extract_section(
                    section,
                    r'\*\*My Encouragement:\*\*\s*(.+?)(?=---|$)',
                    ""
                )

                feedback_results.append(FeedbackResult(
                    criterion_name=criterion_name,
                    score=0.0,  # Will be filled by merge
                    max_points=0.0,
                    student_feedback=student_feedback,
                    encouragement=encouragement,
                    actionable_suggestions=actionable_suggestions
                ))

            return (feedback_results, overall_summary)

        except Exception as e:
            print(f"Error parsing reflector response: {str(e)}")
            print(f"Raw response: {response}")
            return ([], "")

    async def generate_feedback_and_summary_streaming(
        self,
        text_content: str,
        rubric_content: str,
        student_name: str,
        challenge_name: str,
        file_attachments: Optional[List[Dict[str, Any]]] = None,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Streaming version. Yields:
        - {"type": "chunk", "content": str}
        - {"type": "complete", "feedback_results": [...], "overall_summary": str}
        """
        MAX_SUBMISSION_LENGTH = 3000
        capped_submission = text_content[:MAX_SUBMISSION_LENGTH] if len(text_content) > MAX_SUBMISSION_LENGTH else text_content

        # Same prompt as non-streaming version
        feedback_prompt = f"""# FEEDBACK GENERATION TASK

## Student: {student_name}
## Mission: {challenge_name}

## Student Submission:
{capped_submission}
{"The student also submitted file(s) — see attached." if file_attachments else ""}

## Grading Rubric:
{rubric_content}

## Your Task:
You must produce TWO sections in your response:

### SECTION 1: Per-Criterion Feedback
For each rubric criterion, provide feedback in this structure:

## [Criterion Name]

**Your Feedback:**
[2-4 sentences that weave together what worked, what didn't, and what to do next. Write naturally — not as a bulleted checklist.]

**How to Improve:**
- [Specific, actionable suggestion referencing their actual submission]
- [Another specific suggestion — only include if genuinely needed]

**My Encouragement:**
[One sentence — personal and specific to THIS criterion, not generic motivation]

---

### SECTION 2: Overall Summary
After all criteria, write a section starting with:

## Overall Summary

Write a 250-300 word narrative feedback summary addressed to {student_name}.

Rules for Overall Summary:
1. **Open naturally** — greet {student_name} by name and acknowledge the specific mission.
2. **Weave, don't list** — Do NOT repeat the per-criterion template. Write a flowing narrative.
3. **Be specific** — Every piece of praise or criticism must reference something concrete.
4. **Vary your language** — Never start two consecutive sentences with the same word.
5. **End with forward momentum** — Close with something that makes them want to tackle the next challenge.

## CRITICAL RULES:
- Reference the student's ACTUAL words, examples, or decisions — not generic categories
- NEVER repeat the same sentence structure across criteria
- NEVER use "Great job!" / "Well done!" without a specific detail immediately after
- Each criterion's feedback should feel distinct"""

        # Build additional_kwargs for multimodal
        additional_kwargs = {
            'sort': 'latency',
            'max_tokens': 1500,
        }

        if file_attachments:
            files_list = []
            image_urls = []
            for att in file_attachments:
                mime = att.get("mime_type", "")
                if mime.startswith("image/"):
                    image_urls.append(att.get("url") or att.get("data"))
                else:
                    files_list.append({
                        "name": att.get("name", "attachment"),
                        "content": att.get("url") or att.get("data"),
                    })
            if files_list:
                additional_kwargs["files"] = files_list
            if image_urls:
                additional_kwargs["image_urls"] = image_urls

        # Prepare messages
        system_message = ChatMessage(role="system", content=self.system_prompt)
        user_message = ChatMessage(role="user", content=feedback_prompt, additional_kwargs=additional_kwargs if file_attachments else {})
        messages = [system_message, user_message]

        # Stream LLM response
        accumulated_response = ""
        backoff_counter = 0

        while True:
            try:
                stream = self.llm.astream_chat(messages, **additional_kwargs)

                async for chunk in stream:
                    if hasattr(chunk, 'delta') and chunk.delta:
                        content = chunk.delta
                    elif hasattr(chunk, 'message') and chunk.message:
                        content = chunk.message.content
                    else:
                        continue

                    if content:
                        accumulated_response += content
                        yield {"type": "chunk", "content": content}

                break  # Success

            except Exception as e:
                backoff_counter += 1
                if backoff_counter == 5:
                    print(f"Failed to get streaming LLM response after 5 attempts: {e}")
                    raise e
                await asyncio.sleep(5)

        # Parse complete response after streaming ends
        response_text = accumulated_response.strip().replace("```markdown\n", "").replace("```", "")

        # Split off the Overall Summary section
        overall_split = re.split(r'^## Overall Summary\s*$', response_text, flags=re.MULTILINE)

        if len(overall_split) >= 2:
            criteria_text = overall_split[0].strip()
            overall_summary = overall_split[1].strip()
        else:
            criteria_text = response_text
            overall_summary = ""

        # Parse per-criterion feedback
        try:
            feedback_results = []
            criterion_sections = re.split(r'^## ', criteria_text, flags=re.MULTILINE)[1:]

            for section in criterion_sections:
                lines = section.split('\n')
                criterion_name = lines[0].strip()

                student_feedback = self._extract_section(
                    section,
                    r'\*\*Your Feedback:\*\*\s*(.+?)(?=\*\*How to Improve:|---)',
                    ""
                )

                actionable_suggestions = []
                improve_match = re.search(
                    r'\*\*How to Improve:\*\*(.+?)(?=\*\*My Encouragement:|---)',
                    section,
                    re.DOTALL
                )
                if improve_match:
                    improve_text = improve_match.group(1)
                    actionable_suggestions = [
                        s.strip('- ').strip()
                        for s in improve_text.split('\n')
                        if s.strip().startswith('-')
                    ]

                encouragement = self._extract_section(
                    section,
                    r'\*\*My Encouragement:\*\*\s*(.+?)(?=---|$)',
                    ""
                )

                feedback_results.append(FeedbackResult(
                    criterion_name=criterion_name,
                    score=0.0,
                    max_points=0.0,
                    student_feedback=student_feedback,
                    encouragement=encouragement,
                    actionable_suggestions=actionable_suggestions
                ))

            yield {"type": "complete", "feedback_results": feedback_results, "overall_summary": overall_summary}

        except Exception as e:
            print(f"Error parsing streaming feedback response: {str(e)}")
            raise


__all__ = ["UnifiedReflectorV2"]
