"""
Submission Post Writing Agent

Generates structured submission posts for students following the required template format.
The agent transforms raw submission content into a well-formatted post that follows
the organization's submission guidelines.
"""

from typing import Dict, Any, Optional
from connectors.openrouter.llm import OpenRouterMultimodalLLM, ChatMessage


SUBMISSION_POST_TEMPLATE = """## 1. Objective
<What you aimed to achieve in this mission>

## 2. Your Process
<Step-by-step description of how you approached the task>

## 3. Your Output
<What you created or delivered>

## 4. Resources Used
<Share used prompts, GPTs, and links to execution>

## 5. Reflection
<What you learned and insights gained>

## 6. Notes for Reviewers (optional)
<Any additional context or specific areas you'd like feedback on>"""


SUBMISSION_POST_SYSTEM_PROMPT = """You are a Submission Post Writing Agent for the AI Officer Program.

Your task is to transform a student's raw submission content into a well-structured post that follows the required template format.

## Template Structure:

**Title Format:** Mission X | Title Y  
Example: Mission 2 | Prompt Engineering for Operators

**Body Structure:**
1. Objective
2. Your Process
3. Your Output
4. Resources Used (prompts, GPTs, links)
5. Reflection
6. Notes for Reviewers (optional)

## Instructions:

1. **Extract Information**: Analyze the student's raw submission content and extract relevant information for each section.

2. **Structure Content**: Organize the extracted information according to the template structure.

3. **Maintain Voice**: Keep the student's voice and perspective. Write in first person as if the student is speaking.

4. **Fill Gaps Intelligently**: If certain sections are missing from the raw content:
   - For Objective: Infer from the mission context and what they submitted
   - For Process: Extract any methodology or steps mentioned
   - For Output: Describe what they created based on the submission
   - For Resources: Extract any tools, prompts, or links mentioned
   - For Reflection: Extract any learning points or insights mentioned
   - If truly no information is available for a section, write a brief placeholder like "See attached files" or "Described in submission materials"

5. **Format Properly**: Use Markdown formatting with proper headings (##) for each section.

6. **Be Concise**: Keep each section focused and clear. Aim for 2-4 sentences per section unless more detail is warranted.

7. **Professional Tone**: Maintain a professional yet conversational tone appropriate for a learning community.

## Output Format:
- Pure Markdown text
- Start directly with "## 1. Objective"
- No preamble, no meta-commentary
- No code blocks wrapping the output
- No "Here's the formatted post" or similar phrases

## Example Output:

## 1. Objective
My goal was to master prompt engineering techniques by creating effective prompts for various operational scenarios and testing them with different AI models.

## 2. Your Process
I started by reviewing the lesson materials on prompt engineering principles. Then I identified three operational scenarios from my work context. For each scenario, I crafted prompts using the CLEAR framework (Context, Length, Examples, Audience, Role). I tested each prompt with GPT-4 and Claude, comparing outputs and iterating based on results.

## 3. Your Output
I created a comprehensive prompt library with 5 operational prompts, each documented with use case, expected output format, and test results. The prompts cover customer support automation, data analysis requests, and content generation tasks.

## 4. Resources Used
- ChatGPT-4 for initial prompt testing
- Claude 3 Opus for comparative analysis
- Prompt template: "You are a [role]. Your task is to [task]. Context: [context]. Output format: [format]."
- Reference: OpenAI Prompt Engineering Guide

## 5. Reflection
The most valuable insight was understanding how small changes in prompt structure dramatically affect output quality. I learned that being explicit about output format and providing context upfront reduces ambiguity. The iterative testing process helped me develop intuition for what makes prompts effective.

## 6. Notes for Reviewers (optional)
I focused heavily on operational scenarios from my current role. I'd appreciate feedback on whether my prompts are generalizable enough or if they're too specific to my context.
"""


class SubmissionPostAgent:
    """Agent that writes structured submission posts following the required template"""
    
    def __init__(self, model: str = "google/gemini-2.5-flash-lite"):
        """
        Initialize the submission post writing agent
        
        Args:
            model: LLM model to use for post generation
        """
        self.llm = OpenRouterMultimodalLLM(
            model=model,
            temperature=0.3  # Slightly creative but consistent
        )
    
    async def generate_submission_post(
        self,
        mission_name: str,
        challenge_name: str,
        raw_submission_content: str,
        lesson_context: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Generate a structured submission post from raw content
        
        Args:
            mission_name: Name/number of the mission (e.g., "Mission 1", "Mission 2")
            challenge_name: Name of the challenge/assignment
            raw_submission_content: Student's raw submission text
            lesson_context: Optional lesson context to help with objective inference
            
        Returns:
            Dict containing:
                - title: Formatted post title
                - body: Structured post body in Markdown
                - error: Error message if generation failed
        """
        try:
            # Construct the user prompt
            user_prompt = f"""# Mission Information
Mission: {mission_name}
Challenge: {challenge_name}

# Raw Submission Content
{raw_submission_content}
"""
            
            if lesson_context:
                user_prompt += f"\n# Lesson Context (for reference)\n{lesson_context}\n"
            
            user_prompt += "\nGenerate a structured submission post following the template format."
            
            # Build messages
            messages = self.llm.construct_message_list(
                system_prompt=SUBMISSION_POST_SYSTEM_PROMPT,
                user_prompt=user_prompt
            )
            
            # Generate post
            response = await self.llm.achat(messages)
            post_body = response.message.content.strip()
            
            # Clean up any markdown code block wrappers
            post_body = post_body.replace("```markdown", "").replace("```", "").strip()
            
            # Generate title
            post_title = f"{mission_name} | {challenge_name}"
            
            return {
                "title": post_title,
                "body": post_body,
                "error": None
            }
            
        except Exception as e:
            return {
                "title": None,
                "body": None,
                "error": f"Failed to generate submission post: {str(e)}"
            }
    
    async def astream_generate_submission_post(
        self,
        mission_name: str,
        challenge_name: str,
        raw_submission_content: str,
        lesson_context: Optional[str] = None
    ):
        """
        Streaming version of generate_submission_post
        
        Yields:
            Dict with type "chunk" for streaming content or "result" for final output
        """
        try:
            # Construct the user prompt
            user_prompt = f"""# Mission Information
Mission: {mission_name}
Challenge: {challenge_name}

# Raw Submission Content
{raw_submission_content}
"""
            
            if lesson_context:
                user_prompt += f"\n# Lesson Context (for reference)\n{lesson_context}\n"
            
            user_prompt += "\nGenerate a structured submission post following the template format."
            
            # Build messages
            messages = self.llm.construct_message_list(
                system_prompt=SUBMISSION_POST_SYSTEM_PROMPT,
                user_prompt=user_prompt
            )
            
            # Stream post generation
            post_body_chunks = []
            async for chunk in self.llm.astream_chat(messages):
                content = chunk.message.content
                post_body_chunks.append(content)
                yield {
                    "type": "chunk",
                    "content": content
                }
            
            # Combine chunks
            post_body = "".join(post_body_chunks).strip()
            
            # Clean up any markdown code block wrappers
            post_body = post_body.replace("```markdown", "").replace("```", "").strip()
            
            # Generate title
            post_title = f"{mission_name} | {challenge_name}"
            
            yield {
                "type": "result",
                "data": {
                    "title": post_title,
                    "body": post_body,
                    "error": None
                }
            }
            
        except Exception as e:
            yield {
                "type": "error",
                "message": f"Failed to generate submission post: {str(e)}"
            }
