"""
Scorer Agent V2 - Multimodal-native scoring

Key differences from v1:
- Accepts file URLs or file bytes as multimodal attachments directly
- No need for pre-extraction — the LLM reads files natively
- Supports mixed inputs: text + PDFs + images
"""

import os
import asyncio
import re
from typing import Dict, Any, List, Optional

from agents.systems.grading_system.models import ScoringResult
from connectors.openrouter.llm import OpenRouterMultimodalLLM, ChatMessage

OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY", "")
DEFAULT_MODEL_V2 = "google/gemini-2.5-flash"


class ScorerAgentV2:
    """
    Scorer Agent V2 - Multimodal-native scoring

    Key differences from v1:
    - Accepts file URLs or file bytes as multimodal attachments directly
    - No need for pre-extraction — the LLM reads files natively
    - Supports mixed inputs: text + PDFs + images
    """

    def __init__(self, api_key: str = OPENROUTER_API_KEY, model: str = DEFAULT_MODEL_V2):
        self.llm = OpenRouterMultimodalLLM(api_key=api_key, model=model)
        self.system_prompt = """You are an expert educational evaluator. Analyze submissions against rubrics, assign accurate scores with evidence-based justifications, and identify specific strengths/weaknesses. Be fair, consistent, and thorough. Output structured markdown."""

    async def score_submission(
        self,
        text_content: str,
        rubric_content: str,
        challenge_name: str,
        file_attachments: Optional[List[Dict[str, Any]]] = None,
    ) -> List[ScoringResult]:
        """
        Score submission with native multimodal input.

        Args:
            text_content: Student's text message
            rubric_content: Grading rubric
            challenge_name: Challenge/mission name
            file_attachments: List of dicts with:
                - "name": str (filename)
                - "url": str (public URL to file) — OR —
                - "data": str (base64-encoded content)
                - "mime_type": str

        Returns:
            List of ScoringResult objects
        """
        # Cap submission content length (3000 char ~ 750 tokens)
        MAX_SUBMISSION_LENGTH = 3000
        capped_submission = text_content[:MAX_SUBMISSION_LENGTH] if len(text_content) > MAX_SUBMISSION_LENGTH else text_content

        # Build the evaluation prompt
        evaluation_prompt = f"""# GRADING TASK

## Mission: {challenge_name}

## Student Submission:
{capped_submission}
{f"The student also submitted {len(file_attachments)} file(s) — see attached." if file_attachments else ""}

## Grading Rubric:
{rubric_content}

## Your Task:
Evaluate the student submission against each criterion in the rubric. For each criterion, return markdown with this structure:

## [Criterion Name]
**Score:** [score]/[max_points]

**Justification:**
[Detailed explanation of why this score was given, with specific examples]

**Strengths:**
- [Strength 1]
- [Strength 2]

**Weaknesses:**
- [Weakness 1]
- [Weakness 2]

---

Be thorough, fair, and evidence-based in your evaluation."""

        # Build additional_kwargs for multimodal
        additional_kwargs = {
            'sort': 'latency',
            'max_tokens': 1500,
        }

        if file_attachments:
            files_list = []
            image_urls = []
            for att in file_attachments:
                mime = att.get("mime_type", "")
                if mime.startswith("image/"):
                    # Images go as image_urls
                    image_urls.append(att.get("url") or att.get("data"))
                else:
                    # PDFs and other documents go as files
                    files_list.append({
                        "name": att.get("name", "attachment"),
                        "content": att.get("url") or att.get("data"),
                    })
            if files_list:
                additional_kwargs["files"] = files_list
            if image_urls:
                additional_kwargs["image_urls"] = image_urls

        # Prepare messages
        system_message = ChatMessage(role="system", content=self.system_prompt)
        user_message = ChatMessage(role="user", content=evaluation_prompt, additional_kwargs=additional_kwargs if file_attachments else {})
        messages = [system_message, user_message]

        # Call LLM with retry logic
        backoff_counter = 0
        response = ""
        while True:
            try:
                response_obj = await self.llm.achat(messages, **additional_kwargs)
                response = response_obj.message.content
                break
            except Exception as e:
                backoff_counter += 1
                if backoff_counter == 5:
                    print("Failed to get LLM response after 5 attempts:", e)
                    raise e
                await asyncio.sleep(5)

        # Parse the markdown response
        try:
            response_text = response.strip()
            results = []

            # Split by criterion sections (## [Criterion Name])
            criterion_sections = re.split(r'^## ', response_text, flags=re.MULTILINE)[1:]  # Skip first empty split
            print(f"Found {len(criterion_sections)} criterion sections")

            if len(criterion_sections) == 0:
                raise Exception("No criterion sections found in LLM response")

            for section in criterion_sections:
                lines = section.split('\n')
                criterion_name = lines[0].strip()

                # Extract score using regex
                score = 0.0
                max_points = 0.0
                score_match = re.search(r'\*\*Score:\*\*\s*([\d.]+)\s*/\s*([\d.]+)', section)
                if score_match:
                    score = float(score_match.group(1))
                    max_points = float(score_match.group(2))

                # Extract justification
                justification = ""
                just_match = re.search(r'\*\*Justification:\*\*\s*(.+?)(?=\*\*Strengths:|---)', section, re.DOTALL)
                if just_match:
                    justification = just_match.group(1).strip()

                # Extract strengths
                strengths = []
                strengths_match = re.search(r'\*\*Strengths:\*\*(.+?)(?=\*\*Weaknesses:|---)', section, re.DOTALL)
                if strengths_match:
                    strengths_text = strengths_match.group(1)
                    strengths = [s.strip('- ').strip() for s in strengths_text.split('\n') if s.strip().startswith('-')]

                # Extract weaknesses
                weaknesses = []
                weaknesses_match = re.search(r'\*\*Weaknesses:\*\*(.+?)(?=---|$)', section, re.DOTALL)
                if weaknesses_match:
                    weaknesses_text = weaknesses_match.group(1)
                    weaknesses = [w.strip('- ').strip() for w in weaknesses_text.split('\n') if w.strip().startswith('-')]

                results.append(ScoringResult(
                    criterion_name=criterion_name,
                    score=score,
                    max_points=max_points,
                    justification=justification,
                    strengths=strengths,
                    weaknesses=weaknesses
                ))

            return results

        except Exception as e:
            print(f"Error parsing scorer response: {str(e)}")
            print(f"Raw response: {response}")
            return []


__all__ = ["ScorerAgentV2"]
