import json
import os
from connectors.openrouter.llm import ChatMessage
from agents.systems.shared import BaseAgent, AgentState, AgentIntent, AgentStatus, RouterOutput
from connectors.openrouter.llm import OpenRouterMultimodalLLM
from agents.tools.schema import TOOL_GROUP_DEFINITIONS
from agents.context.registry import ContextRegistry
from agents.context.providers.student_provider import StudentContextProvider
from agents.context.providers.prefetch_provider import PrefetchContextProvider
from typing import Optional

class RouterAgent(BaseAgent):
    """Decides whether to use a tool or just chat."""
    
    def __init__(self, llm_client: OpenRouterMultimodalLLM, chosen_tool_groups: Optional[list[str]] = None, cache_client=None, prompt_logger=None):
        super().__init__(llm_client)
        self.chosen_group = "general"
        self.tool_groups = TOOL_GROUP_DEFINITIONS
        self.prompt_logger = prompt_logger
        
        # Initialize context registry
        self.context_registry = ContextRegistry()

        # Register default providers
        self.context_registry.register(StudentContextProvider(cache_client=cache_client))  # Always applicable when student info is available
        self.context_registry.register(PrefetchContextProvider())  # Always applicable when prefetch data exists
        
        print(f"Chosen Tool Groups: {chosen_tool_groups}")
        
        self.chosen_tool_groups_enum = chosen_tool_groups or []
        
        # chosen_tool_groups = ["general", *chosen_tool_groups]
        
        self.chosen_tool_groups = { k:v for k,v in self.tool_groups.items() if k in chosen_tool_groups } if chosen_tool_groups is not None else self.tool_groups
        # Ensure grading_system is always available
        if 'grading_system' not in self.chosen_tool_groups:
            self.chosen_tool_groups['grading_system'] = self.tool_groups['grading_system']
            if 'grading_system' not in self.chosen_tool_groups_enum:
                self.chosen_tool_groups_enum.append('grading_system')
        self.tool_groups_context = "\n".join([f"- '{k}': {v}" for k,v in self.chosen_tool_groups.items()])
        
        print(f"Final tool groups context: {self.tool_groups_context}")
    
    async def decide(self, state: AgentState) -> RouterOutput:
        # Phase 4C: Smart Follow-Up Detection - Check for conversational follow-ups
        if self._is_conversational_followup(state):
            return RouterOutput(
                intent=AgentIntent.CHAT,
                status=AgentStatus.FINISHED,
                step="Conversational follow-up",
                reasoning="Follow-up question based on previous context - answering directly without additional search",
                tools_group="general"
            )
        
        # Hybrid follow-up detection: keyword fast path + LLM semantic path
        if state.last_submission:
            # Fast path: deterministic keyword matching
            is_followup_keyword = self._is_submission_followup(state)
            if is_followup_keyword:
                return RouterOutput(
                    intent=AgentIntent.TOOL,
                    status=AgentStatus.CONTINUE,
                    step="Follow-up submission question",
                    reasoning="Follow-up question about submission - providing enriched suggestions with relevant resources and activities",
                    tools_group="general"
                )
            # Semantic path: let router LLM decide if it's a follow-up
            # The LLM will check conversation context and last_submission

        # Get additional context from providers
        additional_context = await self.context_registry.get_context(state)
        chat_history = state.get_history_str()
        
        # Build coaching mode block if persona is coach
        coaching_mode_block = ""
        persona = getattr(state, 'persona', 'customer_service')
        if persona == "coach" and os.getenv("ENABLE_COACH_PERSONA", "").lower() in ("true", "1", "yes"):
            coaching_mode_block = """
## COACHING MODE (ACTIVE):
**CRITICAL BEHAVIORAL CONSTRAINTS:**
- NEVER route to CHAT+FINISHED for challenge-related questions without tool grounding first
- If user asks about a challenge, mission, or learning concept, ALWAYS route to TOOL with tools_group='general' and status='continue'
- After tool execution, do NOT allow CHAT+FINISHED if the question was about challenge solutions or how-tos
- The coach must have grounding data before responding to any curriculum-related query
- Only route to CHAT+FINISHED for pure factual queries (enrollment status, event times, navigation help)

**COACHING INTENT DETECTION:**
- "What's the answer to Challenge X?" → TOOL + general (retrieve challenge context, not answer)
- "How do I solve this?" → TOOL + general (retrieve mission brief/rubric)
- "What should I think about for Mission X?" → TOOL + general (retrieve mission details)
- "Can you check my work?" → TOOL + general (retrieve rubric for Socratic probing)

**WORKBOOK INTENT DETECTION:**
- "I'm stuck on question 3" / "What does field b7 mean?" → CHAT+FINISHED (workbook context already in pre-loaded challenge data)
- "What should I put in the audit table?" → CHAT+FINISHED (workbook context already in pre-loaded challenge data)
- "I'm on Stage 2 of the final challenge" → CHAT+FINISHED (acknowledge stage, ask what they are stuck on)
- "How do I fill in section A?" → CHAT+FINISHED (use ## Workbook section from pre-loaded context)
- NOTE: Workbook questions do NOT require a tool call — the ## Workbook section is already in the system prompt from the pre-loaded challenge context.

**WORKBOOK SUBMIT DETECTION (highest priority in coach mode):**
- "I'm ready to submit" / "Submit my answers" / "Submit the workbook" / "I'm done, please grade it" / "Please submit my workbook" → TOOL + grading_system
- "I've answered all the questions, submit" / "Done with the workbook" + submission intent → TOOL + grading_system
- NOTE: This OVERRIDES CHAT+FINISHED — when the student is done and wants to submit, ALWAYS route to grading_system, not chat. The grading system will read the accumulated workbook answers from session state.

"""
        
        # Build context section for system prompt
        context_section = f"""
        ## Additional Context:
        {additional_context if additional_context else "No additional context available."}
        """ if additional_context else ""
        
        system_prompt = f"""{coaching_mode_block}You are a Router Agent. Your job is to analyze the user's request and conversation history to decide the next step.

        ## CRITICAL PERFORMANCE RULES:
        - **MAXIMUM 2 TOOL CALLS PER CONVERSATION TURN** - Be decisive and finish quickly
        - **IF YOU HAVE ENOUGH INFORMATION, SET status='finished' IMMEDIATELY**
        - **AVOID WASTEFUL SEARCHES** - Don't search for vague terms that will return nothing
        - **PREFER CONTEXT OVER TOOLS** - If context already has the answer, use it

        ## Strict instructions:
        - **NEW SUBMISSION (HIGHEST PRIORITY)**: If the user has uploaded files (e.g., a PDF, document, or workbook) OR uses submission language (e.g., "submit", "grade", "here is my work", "check my submission", "my workbook"), ALWAYS route to 'tool' with tools_group='grading_system'. This rule overrides ALL other rules including pre-loaded context. Never answer a submission with a conversational response.
        - **FOLLOW-UP QUESTIONS ABOUT SUBMISSION**: If user asks about EXISTING feedback/score/submission (e.g., "How can I improve?", "What did I do wrong?", "Explain my score", "Tell me more about my assessment"), route to 'tool' with tools_group='general' and status='continue'. Use tools to provide enriched suggestions with relevant resources, missions, and activities.
        - **STUDENT PROGRESS QUESTIONS (HIGHEST CONTEXT PRIORITY)**: If the user asks about their own progress, missions completed, certification status, enrollment, what they've done, or what they need to do next — the answer is ALWAYS in the "Student Context" section of Additional Context above. Set status='finished' and intent='chat' immediately. NEVER route to tools for personal progress questions.
        - **GENERAL AIO QUESTIONS**: If user asks about content (missions, series, events) unrelated to their submission, **check your contexts first**. If context has the answer, set status='finished' and intent='chat'. Only route to 'tool' if context is insufficient.
        - **AFTER TOOL EXECUTION**: If tools have been executed and their results are sufficient to answer the user's question, set status='finished' and intent='chat' IMMEDIATELY.
        - **AVOID REPETITIVE TOOL CALLS**: If a tool has already been executed for the same purpose, do NOT execute it again. Set status='finished' instead.
        - **HANDLING MATERIAL REQUESTS**:
            - If user asks for materials (e.g., "I want to submit Mission 1"), route to 'tool' with tools_group='general' and status='continue'.
            - Use tools to provide enriched suggestions with relevant resources, missions, and activities.
        - **PRE-LOADED CONTEXT**: If the conversation history contains a "[Pre-loaded context: ...]" system message, the relevant entity data is already available in your additional context. Prefer answering from this context (status='finished', intent='chat') unless the user explicitly asks for something not covered by the pre-loaded data or wants to perform an action (e.g., submit, grade). **EXCEPTION: if the current message contains uploaded files or submission language, always route to grading_system regardless of pre-loaded context.**

        ## Context:
        Current Iteration: {state.iteration_count}
        {context_section}

        Conversation History:
        {chat_history}

        ## Output Choices for 'intent':
        - 'tool': If the user asks about a specific topic, or to perform an action, search for information, create something, or access external data.
        - 'chat': If the user is just chatting, or the context is already provided and can be answered directly.

        ## Output Choices for 'status':
        - 'finished': If the task is complete and we are ready to send the final response to the user. This should be set when:
          * Tool results are available and sufficient to answer the user's question
          * The user's question has been fully addressed
          * No additional tool calls are needed
        - 'continue': If more actions or tools are needed before the task is complete. Only use this if:
          * No tool results are available yet
          * Tool results are incomplete or insufficient
          * Additional tool calls are required to complete the task

        ## Output Choices for 'tools_group':
        {self.tool_groups_context}
        """
        
        user_prompt = f"""
        Current User Input: {state.current_input}
        
        Decide the intent and status.
        """
        
        # Build messages with cache_control for static prompt
        messages = [
            ChatMessage(
                role="system",
                content=system_prompt,
                cache_control={"type": "ephemeral"}  # Cache the static system prompt
            ),
            ChatMessage(role="user", content=user_prompt)
        ]
        
        # Log prompts if logger is available
        if self.prompt_logger:
            self.prompt_logger.capture_prompt("router", system_prompt, user_prompt)
        
        try:
            response = await self.client.achat(
                messages,
                response_format={
                    "type": "json_schema",
                    "json_schema": {
                        "name": "RouterDecision",
                        "strict": True,
                        "schema": {
                            "type": "object",
                            "properties": {
                                "intent": {
                                    "type": "string",
                                    "enum": ["chat", "tool"],
                                    "description": "The determined intent."
                                },
                                "status": {
                                    "type": "string",
                                    "enum": ["finished", "continue"],
                                    "description": "Whether the task is finished or needs to continue."
                                },
                                "step": {
                                    "type": "string",
                                    "description": "A title (3 to 5 words) summarize the decision."
                                },
                                "reasoning": {
                                    "type": "string",
                                    "description": "The reasoning for the decision. The content must not expose any internal details of the system. Use generic terms and avoid specific tool names or internal system details. Descriptions must be relevant to the user's request and the context provided.""".strip()
                                },
                                "tools_group": {
                                    "type": "string",
                                    "enum": self.chosen_tool_groups_enum,
                                    "description": "The group of tools to be used."
                                },
                            },
                            "required": ["intent", "status", "step", "reasoning", "tools_group"],
                            "additionalProperties": False
                        }
                    }
                },
                plugins=[
                    {"id": "response-healing"}
                ],
                provider={
                    "require_parameters": True,
                    'sort': {
                        'by': 'latency',
                        'partition': 'none',
                    },
                    'preferred_max_latency': {
                        'p50': 1, # Prefer providers with <1 second latency for 50% of requests in last 5 minutes
                        'p90': 2, # Prefer providers with <3 second latency for 90% of requests in last 5 minutes
                        'p99': 3, # Prefer providers with <5 second latency for 99% of requests in last 5 minutes
                    },
                    'preferred_min_throughput': {
                        'p50': 100, # Prefer providers with >100 tokens/sec for 50% of requests in last 5 minutes
                        'p90': 50, # Prefer providers with >50 tokens/sec for 90% of requests in last 5 minutes
                    },
                }
            )
            content = response.message.content
            data = json.loads(content)
            
            intent_str = data.get("intent", "chat").lower()
            status_str = data.get("status", "continue").lower()
            reasoning = data.get("reasoning", "")
            tools_group = data.get("tools_group", "general").lower()
            
            self.chosen_group = tools_group
            
            return RouterOutput(
                intent=AgentIntent(intent_str),
                status=AgentStatus(status_str),
                step=data.get("step", "Routing decision"),
                reasoning=reasoning,
                tools_group=tools_group
            )
            
        except Exception as e:
            print(f"Router Error: {e}")
            # Default fallback
            return RouterOutput(
                intent=AgentIntent.CHAT,
                status=AgentStatus.FINISHED,
                step="Error fallback",
                reasoning=f"Error in routing: {e}",
                tools_group="general"
            )

    def _is_submission_followup(self, state: AgentState) -> bool:
        """Check if current question relates to previous submission"""
        followup_keywords = [
            "score", "feedback", "grade", "submission", "result", 
            "how did i do", "what was my", "improve", "better", 
            "wrong", "explain", "why", "help me", "what should i",
            "how can i", "what can i"
        ]
        input_lower = state.current_input.lower()
        return any(keyword in input_lower for keyword in followup_keywords)

    def _is_conversational_followup(self, state: AgentState) -> bool:
        """Phase 4C: Detect conversational follow-ups that don't need RAG re-search.
        
        Checks for patterns like:
        - "tell me more", "what about", "and then", "next"
        - Follow-ups within 3 turns of having context
        - Referring to "it", "that", "this" when context exists
        """
        if not state.messages or len(state.messages) < 2:
            return False
        
        input_lower = state.current_input.lower()
        
        # Pattern 1: Drilling keywords (asking for more detail without new search)
        drilling_patterns = [
            "tell me more", "what about", "and then", "what else", 
            "how about", "what is", "explain", "why is", "how does"
        ]
        has_drilling_keyword = any(p in input_lower for p in drilling_patterns)
        
        # Pattern 2: Pronoun references when we have context
        # User refers to "it", "that", "this" - implies continuing previous topic
        pronoun_references = ["it", "that", "this", "they", "them"]
        has_pronoun_reference = any(f" {p} " in f" {input_lower} " for p in pronoun_references)
        
        # Pattern 3: Recent context availability (within last 3 turns)
        recent_context_available = False
        if state.tool_results or state.context_prefetch:
            # Check if we had tool results or prefetch in recent messages
            recent_messages = state.messages[-3:] if len(state.messages) >= 3 else state.messages
            for msg in recent_messages:
                if msg.role.value == "tool" or (msg.role.value == "system" and "Pre-loaded context" in msg.content):
                    recent_context_available = True
                    break
        
        # Pattern 4: Short follow-up queries (indicating continuation)
        is_short_query = len(input_lower.split()) <= 5
        
        # Combined logic: Follow-up detected if we have recent context AND (drilling OR pronoun OR short query)
        if recent_context_available and (has_drilling_keyword or has_pronoun_reference or is_short_query):
            return True
        
        return False
