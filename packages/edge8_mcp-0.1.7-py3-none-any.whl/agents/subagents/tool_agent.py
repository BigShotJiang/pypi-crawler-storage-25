import json
from typing import Optional, List
from connectors.openrouter.llm import ChatMessage, OpenRouterMultimodalLLM
from agents.tools.schema import get_tool_schemas_by_names, ToolSchema
from agents.systems.shared import BaseAgent, AgentState, ToolCallData
from agents.prompts import CENTRAL_PROMPT_MAPPING

class ToolAgent(BaseAgent):
    """Selects the tool and generates arguments using a 2-stage process."""
    
    def __init__(self, llm_client: OpenRouterMultimodalLLM, prompt_logger=None):
        super().__init__(llm_client)
        self.prompt_logger = prompt_logger

    async def select_tool(self, state: AgentState) -> Optional[ToolCallData]:
        # --- Stage 1: Tool Planning ---
        # Get available tools from state
        # state.tool_schemas is expected to be a list of ToolSchema objects
        available_tools: List[ToolSchema] = getattr(state, 'tool_schemas', [])
        
        if not available_tools:
            print("No tools available in state.")
            return None

        # Prepare tool descriptions for the planner
        try:
            tool_descriptions = [t.to_openrouter_tool_schema() for t in available_tools]
        except Exception as e:
            print(f"Error preparing tool descriptions: {e}")
            return None
        
        # print("Available tools:", type(tool_descriptions), tool_descriptions)
        
        tool_desc_str = "\n".join([f"- {td['name']}: {td['description']}" for td in tool_descriptions])
        # print("Tool descriptions string:", tool_desc_str)

        planning_system_prompt = CENTRAL_PROMPT_MAPPING.get("tool_planning","").format(tool_descriptions=tool_desc_str)
        
        user_prompt = f"""
        Current User Input: {state.current_input}
        
        Plan the tool usage based on the current request.
        """
        
        # Stage 1: Plan with cached tool descriptions
        messages_stage1 = [
            ChatMessage(
                role="system",
                content=planning_system_prompt,
                cache_control={"type": "ephemeral"}  # Cache tool descriptions
            ),
            ChatMessage(role="user", content=user_prompt)
        ]
        
        # Log prompts if logger is available
        if self.prompt_logger:
            self.prompt_logger.capture_prompt("tool", planning_system_prompt, user_prompt)
        
        try:
            # Stage 1: Plan
            response_stage1 = await self.client.achat(
                messages_stage1,
                response_format={
                    "type": "json_schema",
                    "json_schema": {
                        "name": "ToolPlanning",
                        "strict": True,
                        "schema": {
                            "type": "object",
                            "properties": {
                                "tool_system_prompt": {
                                    "type": "string",
                                    "description": "System prompt for the tool execution agent."
                                },
                                "selected_tools": {
                                    "type": "array",
                                    "items": {"type": "string"},
                                    "description": "List of selected tool names."
                                }
                            },
                            "required": ["tool_system_prompt", "selected_tools"],
                            "additionalProperties": False
                        }
                    }
                },
                plugins=[
                    {"id": "response-healing"}
                ],
                provider={
                    "require_parameters": True,
                    'sort': {
                        'by': 'latency',
                        'partition': 'none',
                    },
                    'preferred_max_latency': {
                        'p50': 1, # Prefer providers with <1 second latency for 50% of requests in last 5 minutes
                        'p90': 2, # Prefer providers with <3 second latency for 90% of requests in last 5 minutes
                        'p99': 3, # Prefer providers with <5 second latency for 99% of requests in last 5 minutes
                    },
                    'preferred_min_throughput': {
                        'p50': 100, # Prefer providers with >100 tokens/sec for 50% of requests in last 5 minutes
                        'p90': 50, # Prefer providers with >50 tokens/sec for 90% of requests in last 5 minutes
                    },
                }
            )
            
            content_stage1 = response_stage1.message.content
            plan_data = json.loads(content_stage1)
            tool_system_prompt = plan_data.get("tool_system_prompt")
            selected_tool_names = plan_data.get("selected_tools", [])
            
            # print("Tools:", selected_tool_names)

            # Stage 2: Execute with cached system prompt
            messages_stage2 = [
                ChatMessage(
                    role="system",
                    content=tool_system_prompt,
                    cache_control={"type": "ephemeral"}  # Cache execution instructions
                ),
                ChatMessage(role="user", content=user_prompt)
            ]
            
            # print("")

            try:
                _, tool_results = await self.aprocess_with_tools(
                    messages_stage2, 
                    selected_tool_names,
                    tool_choice="required",
                    **state.tool_inputs
                )
                
                # print(f"Tool results type: {type(tool_results)}")
                # print(f"Tool results: {tool_results}")
                
            except Exception as e:
                print(f"Error in tool processing: {e}")
                return None

            return tool_results

        except Exception as e:
            print(f"Tool Selection Error: {e}")
            return None
