# Context Provider System
from abc import ABC, abstractmethod
from typing import Optional
from agents.systems.shared import AgentState

class ContextProvider(ABC):
    """Base class for context providers.
    
    Context providers supply domain-specific knowledge, guidelines, and rules
    to the AnsweringAgent. They MUST NOT define the agent's role - role
    definition is handled separately by AnsweringAgent._get_role().
    """
    
    @abstractmethod
    async def get_context(self, state: AgentState) -> str:
        """Retrieve context for the given agent state.
        
        Returns:
            Context string to inject into the system prompt.
            Empty string if no context is available.
        """
        pass
    
    @abstractmethod
    def get_name(self) -> str:
        """Return the provider name for identification."""
        pass
    
    @abstractmethod
    def get_priority(self) -> int:
        """Return priority (lower = higher priority).
        
        Higher priority providers appear first in the context.
        """
        pass
    
    @abstractmethod
    def is_applicable(self, state: AgentState) -> bool:
        """Check if this provider applies to the current state.
        
        Returns:
            True if the provider should be used for this state.
        """
        pass
