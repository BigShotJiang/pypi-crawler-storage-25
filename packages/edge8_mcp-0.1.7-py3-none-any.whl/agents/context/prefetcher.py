"""
Context Prefetcher

Pre-fetches context data for various entity types (challenges, missions, briefs, etc.)
to provide rich context to the LLM before tool invocation.
"""

import asyncio
import csv
import io
import json
import os
from typing import Dict, Any, Optional, List
import httpx
from connectors.supabase_client.createClient import get_custom_client
from agents.tools.shared import LLMPdfExtractor

CHALLENGE_TYPE_MAP = {
    "mission": "intermediate",
    "mission_final": "final",
}

class ContextPrefetcher:
    """Prefetches context data for various entity types"""

    def __init__(self, db):
        """
        Initialize with a DatabaseToolHandler instance.

        Args:
            db: DatabaseToolHandler instance with supabase client
        """
        self.db = db
        # Dedicated client for agents schema — never shared with db.supabase to
        # prevent .schema("agents") from bleeding schema state onto public queries.
        try:
            url = os.getenv("AIO_SUPABASE_URL")
            key = os.getenv("AIO_SUPABASE_SERVICE_ROLE_KEY")
            self._agents_supabase = get_custom_client(url, key, {"schema": "agents"}) if url and key else None
        except Exception:
            self._agents_supabase = None

    async def fetch_cached(
        self,
        context_type: str,
        context_id: str,
        student_id: Optional[int] = None,  # NEW
        cache=None,
    ) -> Optional[Dict[str, Any]]:
        """Fetch context data with optional Redis cache layer.

        Cache key format: prefetch:{context_type}:{context_id}
        TTL: 3600s for static types (challenge, mission, brief, series, workshop), 300s otherwise.
        """
        cache_key = f"prefetch:{context_type}:{context_id}"

        # Check cache
        # if cache:
        #     try:
        #         cached = cache.get(cache_key)
        #         if cached:
        #             print(f"📦 Prefetch cache HIT: {cache_key}")
        #             return json.loads(cached)
        #     except Exception:
        #         pass

        # Fetch fresh
        data = await self.fetch(context_type, context_id, student_id=student_id)

        # Store in cache
        # if data and cache:
        #     try:
        #         static_types = {"challenge", "mission", "brief", "series", "workshop"}
        #         ttl = 3600 if context_type in static_types else 300
        #         cache.setex(cache_key, ttl, json.dumps(data))
        #     except Exception as e:
        #         print(f"⚠️  Prefetch cache store failed: {e}")

        return data

    async def fetch(
        self, 
        context_type: str, 
        context_id: str,
        student_id: Optional[int] = None,  # NEW
    ) -> Optional[Dict[str, Any]]:
        """
        Fetch context data by type and ID.

        Args:
            context_type: Type of context (challenge, mission, brief, series, event, workshop, post)
            context_id: ID of the entity
            student_id: Circle member ID (for fetching prior challenge submissions)

        Returns:
            Dict with type, name, summary, metadata or None on failure
        """
        fetchers = {
            "challenge": lambda cid: self._fetch_challenge(cid, student_id=student_id),
            "mission": self._fetch_mission,
            "brief": self._fetch_brief,
            "series": self._fetch_series,
            "event": self._fetch_event,
            "workshop": self._fetch_workshop,
            "micro_session": self._fetch_event,
            "post": self._fetch_post,
            "key_learnings": self._fetch_key_learnings,
        }

        fetcher = fetchers.get(context_type)
        if not fetcher:
            return None

        try:
            return await fetcher(context_id)
        except Exception as e:
            print(f"⚠️ Error fetching {context_type} with id {context_id}: {e}")
            return None

    async def _fetch_key_learnings(self, key_learning_id: str) -> Optional[Dict[str, Any]]:
        """Fetch key learning by UUID from the key_learnings table"""
        try:
            # Check if key_learning_id is UUID or integer (though migrations use UUID)
            query = self.db.supabase.table("key_learnings").select("*").eq("mission_id", int(key_learning_id)).eq("is_active", True).order("updated_at", desc=True).limit(1)
            resp = query.execute()
            
            if not resp.data:
                return None

            kl = resp.data[0]
            # Use content as summary for immediate return
            content = kl.get("content", "")
            title = kl.get("title", "Key Learning Highlight")

            return {
                "type": "key_learnings",
                "name": title,
                "summary": content,
                "metadata": {
                    "id": kl["id"],
                    "mission_id": kl.get("mission_id"),
                    "short_description": kl.get("short_description"),
                    "is_active": kl.get("is_active"),
                    "version": kl.get("version"),
                    "updated_at": kl.get("updated_at"),
                },
            }
        except Exception as e:
            print(f"⚠️ Error fetching key_learning: {e}")
            return None

    async def _fetch_challenge(
        self, 
        uuid: str, 
        student_id: Optional[int] = None
    ) -> Optional[Dict[str, Any]]:
        """Fetch challenge by UUID"""
        challenge = await self.db.fetch_challenge_by_uuid(uuid)
        if not challenge:
            return None

        body_html = challenge.get("body_html") or challenge.get("markdown", "")
        is_coach = os.getenv("ENABLE_COACH_PERSONA", "").lower() in ("true", "1", "yes")
        max_chars = int(os.getenv("COACH_CHALLENGE_MAX_CHARS", "6000")) if is_coach else 2000
        from markdownify import markdownify as md
        summary = md(str(body_html))[:max_chars]

        # --- Fetch challenge attachments ---
        # Signed URL generation is synchronous and must complete before prompt construction.
        attachments = self._fetch_challenge_attachments_sync(uuid)

        # Content extraction is Coach-only and runs in parallel per file.
        if os.getenv("ENABLE_COACH_PERSONA") == "true" and attachments:
            contents = await asyncio.gather(
                *[self._extract_attachment_content(
                    a["name"], a["url"], a.get("mime_type", "")
                ) for a in attachments],
                return_exceptions=True,
            )
            for att, content in zip(attachments, contents):
                att["content"] = content if isinstance(content, str) else ""

        # --- NEW: Fetch prior submissions (Coach-only) ---
        prior_submissions = []
        if os.getenv("ENABLE_COACH_PERSONA") == "true" and student_id:
            mission_id = challenge.get("mission_id")
            sequence_order = challenge.get("sequence_order")
            if mission_id and sequence_order:
                prior_submissions = await self._fetch_prior_submissions(
                    mission_id, student_id, sequence_order
                )

        return {
            "type": "challenge",
            "name": challenge.get("challenge_name") or challenge.get("name", "Unknown Challenge"),
            "summary": summary,
            "metadata": {
                "id": challenge.get("challenge_id") or challenge.get("id"),
                "challenge_type": challenge.get("challenge_type"),
                "entity_type": challenge.get("entity_type"),
                "entity_name": challenge.get("entity_name"),
                "space_id": challenge.get("space_id"),
                "space_group_id": challenge.get("space_group_id"),
                "series_id": challenge.get("series_id"),
                "series_name": challenge.get("series_name"),
                "event_id": challenge.get("event_id"),
                "mission_id": challenge.get("mission_id"),  # NEW
                "sequence_order": challenge.get("sequence_order"),  # NEW
                "rubric_content": challenge.get("rubric_content", ""),
                "attachments": attachments,
                "prior_submissions": prior_submissions,  # NEW
                "workbook_content": challenge.get("workbook_content"),  # NEW
            },
        }

    def _fetch_challenge_attachments_sync(self, challenge_uuid: str) -> List[Dict[str, Any]]:
        """Synchronously fetch attachments + signed URLs for a challenge.

        Must complete before system prompt construction — URLs are required at turn 0.
        Returns list of dicts with keys: name, url, mime_type, size_bytes.
        """
        try:
            att_resp = (
                self.db.supabase.table("v_challenge_attachments")
                .select("id, name, mime_type, size_bytes")
                .eq("challenge_id", challenge_uuid)
                .execute()
            )
            attachments = att_resp.data or []
            if not attachments:
                return []

            att_names = [a["name"] for a in attachments]
            signed = (
                self.db.supabase
                .storage
                .from_("challenge_attachments")
                .create_signed_urls(att_names, 60 * 60 * 24)
            )
            url_by_name = {
                s.get("path", s.get("name", "")): s.get("signedURL") or s.get("signedUrl", "")
                for s in signed
                if not s.get("error")
            }
            result = []
            for a in attachments:
                signed_url = url_by_name.get(a["name"], "")
                result.append({
                    "name": a["name"].rsplit("/", 1)[-1],
                    "storage_path": a["name"],
                    "url": signed_url,
                    "mime_type": a.get("mime_type", ""),
                    "size_bytes": a.get("size_bytes", 0),
                })
            return result
        except Exception as e:
            print(f"⚠️ Error fetching challenge attachments for {challenge_uuid}: {e}")
            return []

    async def _fetch_prior_submissions(
        self,
        mission_id: int,
        student_id: int,
        current_sequence_order: int,
    ) -> List[Dict[str, Any]]:
        """Fetch prior challenge submissions for the same student in the same mission.
        
        Args:
            mission_id: Mission ID (from challenges.mission_id)
            student_id: Circle member ID
            current_sequence_order: Current challenge's sequence_order
            
        Returns:
            List of dicts with keys: challenge_name, sequence_order, submission (dict or None)
        """
        try:
            # 0. Resolve community_member_id → space_group_members.id(s)
            # challenge_submissions.student_id = space_group_members.id (NOT community_member_id)
            # A member may have multiple SGM rows (one per space/group), so collect all.
            sgm_resp = (
                self.db.supabase.table("space_group_members")
                .select("id")
                .eq("community_member_id", student_id)
                .execute()
            )
            sgm_rows = sgm_resp.data or []
            if not sgm_rows:
                print(f"⚠️  No space_group_members row for community_member_id={student_id}")
                return []
            sgm_ids = [r["id"] for r in sgm_rows]

            # 1. Get prior challenges in this mission (ordered by sequence)
            prior_ch_resp = (
                self.db.supabase.table("challenges")
                .select("id, name, type, sequence_order")
                .eq("mission_id", mission_id)
                .eq("is_legacy", False)
                .lt("sequence_order", current_sequence_order)
                .order("sequence_order")
                .execute()
            )
            prior_challenges = prior_ch_resp.data or []
            
            if not prior_challenges:
                return []
            
            # 2. Fetch latest passing submission for each prior challenge (parallel)
            async def _fetch_submission_for_challenge(ch: Dict[str, Any]) -> Dict[str, Any]:
                sub_resp = (
                    self.db.supabase.table("challenge_submissions")
                    .select("id, grade_status, score, student_input_text, submitted_at")
                    .eq("challenge_uuid", ch["id"])
                    .in_("student_id", sgm_ids)
                    .eq("grade_status", "pass")
                    .order("submitted_at", desc=True)
                    .limit(1)
                    .execute()
                )
                submission = (sub_resp.data or [None])[0]
                return {
                    "challenge_name": ch["name"],
                    "challenge_type": ch["type"],
                    "sequence_order": ch["sequence_order"],
                    "submission": submission,  # None if not yet submitted/passed
                }
            
            results = await asyncio.gather(
                *[_fetch_submission_for_challenge(ch) for ch in prior_challenges],
                return_exceptions=True,
            )
            
            # Filter out exceptions
            return [r for r in results if isinstance(r, dict)]
            
        except Exception as e:
            # Graceful fallback — prior submissions are nice-to-have, not critical
            print(f"⚠️  Could not fetch prior submissions: {e}")
            return []

    async def _extract_attachment_content(self, name: str, url: str, mime: str) -> str:
        """Download and extract readable content from a challenge attachment.

        PDFs  : LLM-extracted summary via LLMPdfExtractor (no length cap).
        CSVs  : Full markdown table + data-analyst-level numeric summary.
        Text  : Decoded as-is.
        Other : Empty — download URL is already provided.
        """
        if not url:
            return ""
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                resp = await client.get(url)
                resp.raise_for_status()
                data = resp.content

            if "pdf" in mime or name.lower().endswith(".pdf"):
                extractor = LLMPdfExtractor()
                extracted = await extractor.execute(pdf_bytes=data, file_name=name)
                return extracted.get("content", "")

            elif "csv" in mime or name.lower().endswith(".csv"):
                return self._parse_csv_analyst_summary(data)

            elif mime.startswith("text/") or name.lower().endswith((".txt", ".md", ".json")):
                return data.decode("utf-8", errors="ignore")

            return ""
        except Exception as e:
            return f"[Content unavailable: {e}]"

    @staticmethod
    def _parse_csv_analyst_summary(data: bytes) -> str:
        """Full CSV → markdown table + data-analyst-level summary. Pure stdlib, no new deps."""
        text = data.decode("utf-8", errors="ignore")
        reader = csv.DictReader(io.StringIO(text))
        rows = list(reader)
        if not rows:
            return "[Empty CSV]"

        headers = list(rows[0].keys())
        row_count = len(rows)

        header_row = "| " + " | ".join(headers) + " |"
        sep_row = "| " + " | ".join(["---"] * len(headers)) + " |"
        body_rows = "\n".join(
            "| " + " | ".join(str(r.get(h, "")) for h in headers) + " |"
            for r in rows
        )
        table = f"{header_row}\n{sep_row}\n{body_rows}"

        numeric_stats = []
        for col in headers:
            vals: List[float] = []
            for r in rows:
                try:
                    vals.append(float(r.get(col, "")))
                except (ValueError, TypeError):
                    pass
            if vals:
                numeric_stats.append(
                    f"- **{col}**: {len(vals)} values, "
                    f"min={min(vals):.2f}, max={max(vals):.2f}, "
                    f"mean={sum(vals) / len(vals):.2f}"
                )

        summary_parts = [
            f"**Rows:** {row_count} | **Columns:** {len(headers)}",
            f"**Columns:** {', '.join(headers)}",
        ]
        if numeric_stats:
            summary_parts.append("**Numeric column stats:**")
            summary_parts.extend(numeric_stats)

        return f"{table}\n\n---\n**Data Summary**\n" + "\n".join(summary_parts)

    async def _fetch_mission(self, space_id: str) -> Optional[Dict[str, Any]]:
        """Fetch mission by space ID — lightweight overview without body content."""
        try:
            space_resp = (
                self.db.supabase.table("spaces")
                .select("id, name, space_group_id")
                .eq("id", int(space_id))
                .limit(1)
                .execute()
            )
            if not space_resp.data:
                return None

            space = space_resp.data[0]

            # Lightweight challenges list — names and types only, no body_html
            challenges_resp = (
                self.db.supabase.table("challenges")
                .select("id, name, type, markdown")
                .eq("mission_id", space["id"])
                .eq("is_legacy", False)
                .limit(20)
                .execute()
            )

            challenges = challenges_resp.data or []

            # Build summary from lesson names (no HTML conversion)
            challenge_lines = []
            for challenge in challenges:
                challenge_type = challenge.get("type", "basic")
                prefix = "📝" if challenge_type == "basic" else "🎯"
                challenge_lines.append(f"- {prefix} {challenge['name']} ({CHALLENGE_TYPE_MAP.get(challenge_type, challenge_type)}) {challenge['markdown'][:100]}...")

            if not challenge_lines:
                return None  # No usable challenge data — force a proper tool search

            summary = "\n".join(challenge_lines)

            # Phase 4B: Attachment-Aware Prefetch - Fetch lesson attachments
            attachments: List[Dict[str, Any]] = []
            try:
                _agents_sb = self._agents_supabase or self.db.supabase.schema('agents')
                attachments_resp = (
                    _agents_sb
                    .table("vector_metadata")
                    .select("metadata->attachments, vector_documents!inner(id, entity_id, entity_type)")
                    .eq("vector_documents.entity_id", int(space_id))
                    .eq("vector_documents.entity_type", "mission")
                    .single()
                    .execute()
                )
                if attachments_resp.data:
                    attachments = attachments_resp.data.get("attachments", [])
            except Exception as e:
                print(f"⚠️ Error fetching attachments: {e}")

            # Resolve series name for richer metadata
            series_name: Optional[str] = None
            space_group_id = space.get("space_group_id")
            if space_group_id:
                sg_resp = (
                    self.db.supabase.schema("public").table("space_groups")
                    .select("id, name")
                    .eq("id", space_group_id)
                    .limit(1)
                    .execute()
                )
                if sg_resp.data:
                    series_name = sg_resp.data[0].get("name")

            return {
                "type": "mission",
                "name": space.get("name", "Unknown Mission"),
                "summary": summary,
                "metadata": {
                    "id": space["id"],
                    "space_group_id": space_group_id,
                    "series_name": series_name,
                    "challenge_count": len(challenges),
                    "attachments": attachments,  # Phase 4B: Include attachment metadata
                    "attachment_count": len(attachments),
                },
            }
        except Exception as e:
            print(f"⚠️ Error fetching mission: {e}")
            return None

    async def _fetch_brief(self, lesson_id: str) -> Optional[Dict[str, Any]]:
        """Fetch brief by lesson ID"""
        try:
            resp = (
                self.db.supabase.table("lessons")
                .select("id, name, type, body_html")
                .eq("id", int(lesson_id))
                .limit(1)
                .execute()
            )
            if not resp.data:
                return None

            lesson = resp.data[0]
            from markdownify import markdownify as md
            summary = md(str(lesson.get("body_html", "")))[:2000]

            return {
                "type": "brief",
                "name": lesson.get("name", "Unknown Brief"),
                "summary": summary,
                "metadata": {"id": lesson["id"], "type": lesson.get("type")},
            }
        except Exception as e:
            print(f"⚠️ Error fetching brief: {e}")
            return None

    async def _fetch_series(self, space_group_id: str) -> Optional[Dict[str, Any]]:
        """Fetch series by space_group ID"""
        try:
            sg_resp = (
                self.db.supabase.table("space_groups")
                .select("id, name")
                .eq("id", int(space_group_id))
                .limit(1)
                .execute()
            )
            if not sg_resp.data:
                return None

            space_group = sg_resp.data[0]

            spaces_resp = (
                self.db.supabase.table("spaces")
                .select("id, name, space_type")
                .eq("space_group_id", space_group["id"])
                .limit(30)
                .execute()
            )

            spaces = spaces_resp.data or []
            space_lines = []
            for s in spaces:
                stype = s.get("space_type", "")
                prefix = {"course": "📚", "event": "📅", "chat": "💬"}.get(stype, "📄")
                space_lines.append(f"- {prefix} {s['name']} ({stype})")

            summary = "\n".join(space_lines)[:2000]
            space_names = [s["name"] for s in spaces]

            return {
                "type": "series",
                "name": space_group.get("name", "Unknown Series"),
                "summary": summary,
                "metadata": {
                    "id": space_group["id"],
                    "space_count": len(spaces),
                    "space_names": space_names,
                },
            }
        except Exception as e:
            print(f"⚠️ Error fetching series: {e}")
            return None

    async def _fetch_event(self, event_id: str) -> Optional[Dict[str, Any]]:
        """Fetch event by ID"""
        try:
            resp = (
                self.db.supabase.table("events")
                .select(
                    "id, name, body, starts_at, ends_at, location_type, virtual_location_url, url"
                )
                .eq("id", int(event_id))
                .limit(1)
                .execute()
            )
            if not resp.data:
                return None

            event = resp.data[0]
            from markdownify import markdownify as md
            summary = md(str(event.get("body", "")))[:2000]

            return {
                "type": "event",
                "name": event.get("name", "Unknown Event"),
                "summary": summary,
                "metadata": {
                    "id": event["id"],
                    "starts_at": event.get("starts_at"),
                    "ends_at": event.get("ends_at"),
                    "location_type": event.get("location_type"),
                    "virtual_location_url": event.get("virtual_location_url"),
                    "url": event.get("url"),
                },
            }
        except Exception as e:
            print(f"⚠️ Error fetching event: {e}")
            return None

    async def _fetch_workshop(self, space_id: str) -> Optional[Dict[str, Any]]:
        """Fetch workshop by space ID (reuses mission fetcher, overrides type)."""
        result = await self._fetch_mission(space_id)
        if result:
            result["type"] = "workshop"
        return result

    async def _fetch_post(self, post_id: str) -> Optional[Dict[str, Any]]:
        """Fetch post by ID"""
        try:
            resp = (
                self.db.supabase.table("posts")
                .select("id, name, body, url, space_name, user_name, published_at")
                .eq("id", int(post_id))
                .limit(1)
                .execute()
            )
            if not resp.data:
                return None

            post = resp.data[0]
            from markdownify import markdownify as md
            summary = md(str(post.get("body", "")))[:2000]

            return {
                "type": "post",
                "name": post.get("name", "Unknown Post"),
                "summary": summary,
                "metadata": {
                    "id": post["id"],
                    "url": post.get("url"),
                    "space_name": post.get("space_name"),
                    "user_name": post.get("user_name"),
                    "published_at": post.get("published_at"),
                },
            }
        except Exception as e:
            print(f"⚠️ Error fetching post: {e}")
            return None

    def format_for_prompt(self, context_type: str, data: Dict[str, Any]) -> str:
        """
        Format context data for injection into LLM system prompt.

        Args:
            context_type: Type of context
            data: Dict with type, name, summary, metadata

        Returns:
            Markdown formatted string
        """
        if not data:
            return ""

        type_label = context_type.title()
        name = data.get("name", "Unknown")
        summary = data.get("summary", "")[:2000]
        metadata = data.get("metadata", {})

        # Build related info from metadata
        related_parts = []
        if "series_name" in metadata:
            related_parts.append(f"Series: {metadata['series_name']}")
        if "space_id" in metadata:
            related_parts.append(f"Space ID: {metadata['space_id']}")
        if "space_group_id" in metadata:
            related_parts.append(f"Series ID: {metadata['space_group_id']}")
        if "event_id" in metadata:
            related_parts.append(f"Event ID: {metadata['event_id']}")

        related = " | ".join(related_parts) if related_parts else ""

        lines = [f"## {type_label}: {name}", "", summary]
        if related:
            lines.append("")
            lines.append(f"Related: {related}")
        
        # Add prior challenge work if present (Coach persona only)
        prior_submissions = metadata.get("prior_submissions", [])
        if prior_submissions and context_type == "challenge":
            lines.append("")
            lines.append("## Prior Challenge Work")
            lines.append("")
            lines.append(
                "This student has completed the following challenges in this mission before this one. "
                "Use their actual submitted work to ground your coaching — reference it specifically, "
                "do not re-explain what they have already done."
            )
            
            max_chars = int(os.getenv("PRIOR_SUBMISSION_MAX_CHARS", "1500"))
            total_challenges = len(prior_submissions) + 1  # +1 for current challenge
            
            for prior in prior_submissions:
                ch_name = prior.get("challenge_name", "Unknown Challenge")
                seq = prior.get("sequence_order", "?")
                sub = prior.get("submission")
                
                lines.append("")
                lines.append(f"### {ch_name} (Challenge {seq} of {total_challenges})")
                lines.append("")
                
                if sub:
                    score = sub.get("score", 0)
                    submitted_at = (sub.get("submitted_at") or "")[:10]  # YYYY-MM-DD
                    lines.append(f"Status: ✅ Passed (score: {score})")
                    lines.append(f"Submitted: {submitted_at}")
                    lines.append("")
                    
                    text = sub.get("student_input_text") or ""
                    if len(text) > max_chars:
                        text = text[:max_chars] + "\n\n[... truncated for brevity ...]"
                    lines.append(f"```\n{text}\n```")
                else:
                    lines.append(
                        "Status: ⚠️  Not yet submitted — student may have skipped or submitted via file."
                    )
                lines.append("")
                lines.append("---")
        
        # Add workbook content if present (Coach persona only, challenge context only)
        workbook_content = metadata.get("workbook_content")
        if workbook_content and context_type == "challenge":
            lines.append("")
            lines.append("## Workbook")
            lines.append("The student must fill the following sections before submitting:")
            for section in workbook_content:
                section_id = section.get("id") or section.get("section_id", "")
                section_label = section.get("label") or section.get("title") or section_id
                section_type = section.get("type", "fields")
                lines.append("")
                lines.append(f"### Section {section_id.upper() if section_id else ''} — {section_label}")
                if section_type == "table":
                    columns = section.get("columns") or []
                    min_rows = section.get("min_rows", 1)
                    col_names = [c.get("label") or c.get("name", "") for c in columns]
                    lines.append(f"Type: Table ({min_rows} rows minimum)")
                    if col_names:
                        lines.append(f"Columns: {', '.join(col_names)}")
                else:
                    fields = section.get("fields") or []
                    for field in fields:
                        field_id = field.get("id") or field.get("key", "")
                        field_label = field.get("label") or field.get("name") or field_id
                        field_type = field.get("type", "text")
                        lines.append(f"- Field {field_id}: \"{field_label}\" ({field_type})")
        
        # Add workbook content if present (Coach persona only, challenge context only)
        workbook_content = metadata.get("workbook_content")
        if workbook_content and context_type == "challenge":
            lines.append("")
            lines.append("## Workbook")
            lines.append("The student must fill the following sections before submitting:")
            for section in workbook_content:
                section_id = section.get("id") or section.get("section_id", "")
                section_label = section.get("label") or section.get("title") or section_id
                section_type = section.get("type", "fields")
                lines.append("")
                lines.append(f"### Section {section_id.upper() if section_id else ''} — {section_label}")
                if section_type == "table":
                    columns = section.get("columns") or []
                    min_rows = section.get("min_rows", 1)
                    col_names = [c.get("label") or c.get("name", "") for c in columns]
                    lines.append(f"Type: Table ({min_rows} rows minimum)")
                    if col_names:
                        lines.append(f"Columns: {', '.join(col_names)}")
                else:
                    fields = section.get("fields") or []
                    for field in fields:
                        field_id = field.get("id") or field.get("key", "")
                        field_label = field.get("label") or field.get("name") or field_id
                        field_type = field.get("type", "text")
                        lines.append(f"- Field {field_id}: \"{field_label}\" ({field_type})")
        
        # Add attachments if present
        attachments = metadata.get("attachments") or []
        if attachments:
            lines.append("")
            if context_type == "challenge":
                lines.append("## Challenge Files")
                is_coach = os.getenv("ENABLE_COACH_PERSONA") == "true"
                if is_coach:
                    lines.append(
                        "These files are provided as part of this challenge. "
                        "Use their content to guide the student Socratically. "
                        "Do NOT reveal answers — help them discover insights themselves."
                    )
                for att in attachments:
                    att_name = att.get("name", "Attachment")
                    url = att.get("url", "")
                    content = att.get("content", "")
                    link = f"[{att_name}]({url})" if url else att_name
                    lines.append(f"")
                    lines.append(f"### {link}")
                    if content:
                        lines.append(content)
                    elif not url:
                        lines.append("_(file unavailable)_")
            else:
                lines.append("### Attachments")
                for att in attachments:
                    att_name = att.get("name", "Attachment")
                    url = att.get("url", "")
                    if url:
                        lines.append(f"- [{att_name}]({url})")
                    else:
                        lines.append(f"- {att_name}")

        return "\n".join(lines)
