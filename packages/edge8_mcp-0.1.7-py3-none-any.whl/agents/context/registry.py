# Context Registry
import asyncio
import logging
from typing import List, Dict
from agents.context.base import ContextProvider
from agents.systems.shared import AgentState

logger = logging.getLogger(__name__)

class ContextRegistry:
    """Registry for context providers.
    
    Manages multiple context providers and aggregates their output
    for injection into the AnsweringAgent's system prompt.
    """
    
    def __init__(self):
        self._providers: List[ContextProvider] = []
        self._tool_group_mapping: Dict[str, List[str]] = {}
    
    def register(self, provider: ContextProvider, tool_groups: List[str] = None):
        """Register a context provider.
        
        Args:
            provider: The context provider to register.
            tool_groups: Optional list of tool groups this provider applies to.
                        Used for filtering by tool_groups in AgentState.
        """
        self._providers.append(provider)
        if tool_groups:
            for group in tool_groups:
                if group not in self._tool_group_mapping:
                    self._tool_group_mapping[group] = []
                self._tool_group_mapping[group].append(provider.get_name())
    
    async def get_context(self, state: AgentState) -> str:
        """Get all applicable context for the current state.
        
        Uses request-scoped caching on AgentState to avoid duplicate DB queries
        when both RouterAgent and AnsweringAgent call this in the same turn.
        
        Args:
            state: The current agent state.
            
        Returns:
            Aggregated context string from all applicable providers,
            sorted by priority (lower priority number = higher priority).
        """
        # Check request-scoped cache (shared between Router and Answering agents)
        if state._context_cache is not None:
            logger.info(f"[CONTEXT CACHE] HIT - Returning cached context ({len(state._context_cache)} chars)")
            print(f"✅ ContextRegistry: CACHE HIT ({len(state._context_cache)} chars)")
            return state._context_cache
        
        logger.info("[CONTEXT CACHE] MISS - Fetching from providers...")
        print("❌ ContextRegistry: CACHE MISS - Fetching from providers...")
        
        # Filter applicable providers
        applicable_providers = [
            p for p in self._providers 
            if p.is_applicable(state)
        ]
        
        logger.debug(f"[CONTEXT CACHE] {len(applicable_providers)} providers applicable: {[p.get_name() for p in applicable_providers]}")
        
        # Sort by priority (lower = higher priority)
        applicable_providers.sort(key=lambda p: p.get_priority())
        
        # Parallel fetch with timeout - each provider max 2 seconds
        async def get_provider_context(provider: ContextProvider) -> tuple[str, int, str]:
            """Wrapper to get context with priority and name"""
            provider_name = provider.get_name()
            try:
                logger.debug(f"[CONTEXT CACHE] Fetching from {provider_name}...")
                start_time = asyncio.get_event_loop().time()
                context = await asyncio.wait_for(provider.get_context(state), timeout=4.0)
                elapsed = asyncio.get_event_loop().time() - start_time
                logger.debug(f"[CONTEXT CACHE] {provider_name} completed in {elapsed:.3f}s")
                return (context, provider.get_priority(), provider_name)
            except asyncio.TimeoutError:
                logger.warning(f"[CONTEXT CACHE] {provider_name} TIMED OUT after 4s")
                print(f"⚠️ Context provider {provider_name} timed out")
                return ("", provider.get_priority(), provider_name)
            except Exception as e:
                logger.error(f"[CONTEXT CACHE] {provider_name} ERROR: {e}")
                print(f"⚠️ Context provider {provider_name} error: {e}")
                return ("", provider.get_priority(), provider_name)
        
        # Execute all providers in parallel
        import time
        fetch_start = time.time()
        tasks = [get_provider_context(p) for p in applicable_providers]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        fetch_elapsed = time.time() - fetch_start
        
        # Build context parts from results (already sorted by priority)
        context_parts = []
        for result in results:
            if isinstance(result, Exception):
                logger.error(f"[CONTEXT CACHE] Provider exception: {result}")
                continue
            context, priority, name = result
            if context:
                context_parts.append(f"## {name}\n{context}")
        
        result = "\n\n".join(context_parts)
        
        # Cache on state for this request (shared between Router + Answering agents)
        state._context_cache = result
        logger.info(f"[CONTEXT CACHE] STORED on state ({len(result)} chars, fetch took {fetch_elapsed:.3f}s)")
        print(f"✅ ContextRegistry: Cached context on state ({len(result)} chars, fetch took {fetch_elapsed:.3f}s)")
        
        return result
    
    def get_providers_for_tool_group(self, tool_group: str) -> List[str]:
        """Get names of providers registered for a specific tool group.
        
        Args:
            tool_group: The tool group to query.
            
        Returns:
            List of provider names registered for this tool group.
        """
        return self._tool_group_mapping.get(tool_group, [])
    
    def clear(self):
        """Clear all registered providers."""
        self._providers.clear()
        self._tool_group_mapping.clear()
