"""Student context provider for personalized AI responses."""

import asyncio
from typing import Any, Optional, Union
from ..base import ContextProvider
from ...systems.shared import AgentState
from ...tools.database.aio.aio import DatabaseToolHandler



class StudentContextProvider(ContextProvider):
    """Provides student-specific context including progress, enrollments, and activity status."""
    
    def __init__(self, cache_client=None):
        """Initialize the student context provider."""
        self.handler = DatabaseToolHandler(cache_client=cache_client)
    
    async def get_context(self, state: AgentState) -> str:
        """Fetch student progress and context.
        
        Args:
            state: Agent state containing student_id or email
            
        Returns:
            Formatted student context string.
            Empty string if student info is unavailable or on error.
        """
        try:
            # Get student identifier from state
            member_id = getattr(state, 'member_id', None)
            email = getattr(state, 'email', None)
            
            if not member_id and not email:
                return ""
            
            context_lines = []
            
            # Fetch student profile, enrollments, and progress in parallel
            student_info, enrollments, progress = await asyncio.gather(
                self._fetch_student_profile(member_id, email),
                self._fetch_enrollments(member_id, email),
                self._fetch_student_progress(member_id, email),
                return_exceptions=True
            )
            
            # Handle exceptions - convert to None if error
            if isinstance(student_info, Exception):
                print(f"Error fetching student profile: {student_info}")
                student_info = None
            if isinstance(enrollments, Exception):
                print(f"Error fetching enrollments: {enrollments}")
                enrollments = []
            if isinstance(progress, Exception):
                print(f"Error fetching student progress: {progress}")
                progress = []
            
            if email is None and student_info:
                email = student_info.get('email')
            if student_info:
                context_lines.append(f"Student: {student_info.get('name', 'Unknown')}")
                if student_info.get('headline'):
                    context_lines.append(f"  Headline: {student_info.get('headline')}")
                if student_info.get("activity_score"):
                    context_lines.append(f"  Activity Score: {self._format_flat_dict(student_info.get('activity_score'))}")
                if student_info.get("gamification_stats"):
                    context_lines.append(f"  Gamification Stats: {self._format_flat_dict(student_info.get('gamification_stats'))}")
            
            if enrollments:
                context_lines.append(f"\nEnrolled in {len(enrollments)} series:")
                for enrollment in enrollments:
                    series_name = enrollment.get('series_name', 'Unknown')
                    access_type = enrollment.get('access_type', 'unknown')
                    enrolled_at = enrollment.get('enrolled_at', '')
                    context_lines.append(f"  - {series_name} ({access_type})")
            
            if progress:
                context_lines.append("\nStudent Progress Summary:\n")
                for prog in progress:
                    series_name = prog.get('series_name', 'Unknown')
                    mission_pct = prog.get('mission_progress_percentage', 0)
                    workshop_pct = prog.get('workshop_completion_percentage', 0)
                    micro_sessions_count = prog.get('micro_sessions_attended_count', 0)
                    
                    context_lines.append(f"\n---")
                    context_lines.append(f"SERIES (PROGRAM/ESSENTIAL/CERTIFICATION-TRACK): {series_name}")
                    context_lines.append(f"Mission Progress:\n{self._format_progress_dict(mission_pct)}")
                    context_lines.append(f"Workshop Progress:\n{self._format_progress_dict(workshop_pct)}")
                    context_lines.append(f"Micro Sessions Attended: {micro_sessions_count}\n\n")
                    
                    # Phase 5B: Next-Step Enrichment - Calculate recommended next step
                    next_step = self._calculate_next_step(prog)
                    if next_step:
                        context_lines.append(f"RECOMMENDED NEXT STEP: {next_step}\n\n")
                    
                    context_lines.append(f"---\n")
            
            # Fetch recent submissions
            # recent_submissions = await self._fetch_recent_submissions(member_id, email)
            # if recent_submissions:
            #     context_lines.append(f"\nRecent Submissions ({len(recent_submissions)}):")
            #     for sub in recent_submissions[:3]:  # Show last 3
            #         mission_name = sub.get('mission_name', 'Unknown')
            #         grade_status = sub.get('grade_status', 'pending')
            #         score = sub.get('score', 'N/A')
            #         context_lines.append(f"  - {mission_name}: {grade_status} (score: {score})")
            
            # print("Student Context: ", "\n".join(context_lines))
            return "\n".join(context_lines) if context_lines else ""
            
        except Exception as e:
            print(f"Error fetching student context: {e}")
            import traceback
            traceback.print_exc()
            return ""
    
    async def _fetch_student_profile(self, member_id: Optional[int], email: Optional[str]) -> Optional[dict]:
        """Fetch student profile by ID or email."""
        try:
            result = await self.handler.execute(
                resource="students",
                limit=1,
                name="",  # Explicitly empty to avoid global name filter
                # query=email if email else None,
                email=email,
                member_id=member_id,
                include_related=False
            )
            data = result.get("metadata", []) if isinstance(result, dict) else []
            return data[0] if data else None
        except Exception:
            return None
    
    async def _fetch_enrollments(self, member_id: Optional[int], email: Optional[str]) -> list:
        """Fetch student enrollments."""
        try:
            result = await self.handler.execute(
                resource="enrollments",
                limit=10,
                name="",  # Explicitly empty to avoid global name filter
                email=email,
                member_id=member_id,
                include_related=False
            )
            data = result.get("metadata", []) if isinstance(result, dict) else []
            return data if isinstance(data, list) else []
        except Exception:
            return []
    
    async def _fetch_student_progress(self, member_id: Optional[int], email: Optional[str]) -> list:
        """Fetch student progress across series."""
        try:
            result = await self.handler.execute(
                resource="student_progress",
                limit=10,
                name="",  # Explicitly empty to avoid global name filter
                email=email,
                member_id=member_id,
                include_related=False
            )
            data = result.get("metadata", []) if isinstance(result, dict) else []
            return data if isinstance(data, list) else []
        except Exception as e:
            print(f"Error fetching student progress: {e}")
            import traceback
            traceback.print_exc()
            return []
    
    async def _fetch_recent_submissions(self, member_id: Optional[int], email: Optional[str]) -> list:
        """Fetch recent submissions."""
        try:
            result = await self.handler.execute(
                resource="submissions",
                limit=5,
                name="",  # Explicitly empty to avoid global name filter
                email=email,
                member_id=member_id,
                include_related=False
            )
            data = result.get("metadata", []) if isinstance(result, dict) else []
            return data if isinstance(data, list) else []
        except Exception:
            return []
    
    @staticmethod
    def _format_progress_dict(data: Union[dict, int, float, None]) -> str:
        """Format a progress dict (mission or workshop) as natural-language list items.
        
        Handles structures like:
            {"Mission Name": {"percentage": 100, ...}, ...}
            {"Workshop Name": {"percentage": 50, "completed": 3, "total": 6}, ...}
            0  (numeric fallback)
        """
        if data is None:
            return "  No data available\n"
        if isinstance(data, (int, float)):
            return f"  Overall: {data}%\n"
        if not isinstance(data, dict) or not data:
            return "  No data available\n"

        lines: list[str] = []
        for details in data.values():
            name = details.get('mission_name', details.get('workshop_name', 'Unknown'))
            pct = details.get('percentage', 0)
            status = "completed" if pct >= 100 else "in progress"
            lines.append(f"  - {name}: {pct}% ({status})")
        return "\n".join(lines) + "\n"

    @staticmethod
    def _format_flat_dict(data: Any) -> str:
        """Format a simple key-value dict as a comma-separated string."""
        if isinstance(data, dict):
            parts = [f"{k}: {v}" for k, v in data.items()]
            return ", ".join(parts)
        return str(data) if data is not None else "N/A"

    def _calculate_next_step(self, progress: dict) -> Optional[str]:
        """Phase 5B: Calculate recommended next step based on student progress.

        Args:
            progress: Student progress dict with mission/workshop percentages

        Returns:
            Recommended next step description or None
        """
        mission_progress = progress.get('mission_progress_percentage', {}) or {}
        micro_session_workshop_status = progress.get('micro_session_progress', {"submitted": False}) or {"submitted": False}
        series_name = progress.get('series_name', '')
        
        # Calculate overall mission percentage from dict of mission objects
        if mission_progress and isinstance(mission_progress, dict):
            total_pct = sum(m.get('percentage', 0) for m in mission_progress.values())
            mission_pct = total_pct / len(mission_progress) if mission_progress else 0
        else:
            mission_pct = 0
        
        # Priority 1: If missions incomplete, recommend next mission
        if mission_pct < 100:
            remaining = 100 - mission_pct
            return f"Continue with remaining missions in {series_name} ({remaining:.0f}% remaining)"
        
        # Priority 2: If workshops incomplete, recommend next workshop
        if micro_session_workshop_status.get("submitted") == False:
            return f"Complete remaining workshops in {series_name}"
        
        # Priority 3: All complete - suggest next series or advanced track
        if mission_pct >= 100 and micro_session_workshop_status.get("submitted") == True:
            return f"Series complete! Consider enrolling in the next series or advanced track"
        
        return None
    
    def get_name(self) -> str:
        """Return provider name."""
        return "==========Student Context=============="
    
    def get_priority(self) -> int:
        """Return provider priority (higher = more important)."""
        return 90  # High priority for student-specific context
    
    _PERSONAL_KEYWORDS = {"my ", "i have", "i am", "my progress", "my mission", "my challenge"}

    def is_applicable(self, state: AgentState) -> bool:
        """Check if student context is applicable — only for personal-data queries."""
        has_identity = bool(getattr(state, 'member_id', None) or getattr(state, 'email', None))
        question = (state.current_input or "").lower()
        is_personal = any(kw in question for kw in self._PERSONAL_KEYWORDS)
        return has_identity and is_personal
