# AIO Context Providers
from agents.context.base import ContextProvider
from agents.systems.shared import AgentState
from agents.systems.constants import STUDENT_PROGRESS_KEYWORDS


class AIOGuidelinesProvider(ContextProvider):
    """Provides relevant AIO guidelines via RAG retrieval.

    Uses hybrid search against the vector store (entity_type='guideline')
    to return only the guidelines most relevant to the user's current question,
    replacing the previous full-table database fetch.
    """

    def get_name(self) -> str:
        return "============AI-Officer Community Guidelines=============="

    def get_priority(self) -> int:
        return 10  # High priority

    def is_applicable(self, state: AgentState) -> bool:
        # Provider disabled: vector store was removed during Circle cleanup
        return False

    async def get_context(self, state: AgentState) -> str:
        """Provider disabled: vector store was removed during Circle cleanup.

        Returns empty string as this provider is no longer functional.
        """
        return ""
