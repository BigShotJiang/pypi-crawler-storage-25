"""Pre-fetched entity context provider."""

from typing import Optional
from ..base import ContextProvider
from ...systems.shared import AgentState


class PrefetchContextProvider(ContextProvider):
    """Provides pre-fetched entity context from context_id lookups.
    
    When the frontend sends context_type + context_id, the ContextPrefetcher
    fetches relevant DB data and stores it in state.context_prefetch.
    This provider formats that data for injection into the LLM system prompt.
    """
    
    def get_name(self) -> str:
        return "============Pre-loaded Entity Context=============="
    
    def get_priority(self) -> int:
        return 5  # Highest priority — appears before student context (90) and guidelines (10)
    
    def is_applicable(self, state: AgentState) -> bool:
        return state.context_prefetch is not None
    
    async def get_context(self, state: AgentState) -> str:
        """Format context_prefetch into readable markdown for the LLM."""
        prefetch = state.context_prefetch
        if not prefetch:
            return ""
        
        context_type = prefetch.get("type", "unknown")
        name = prefetch.get("name", "Unknown")
        summary = prefetch.get("summary", "")
        metadata = prefetch.get("metadata", {})
        
        lines = []
        lines.append(f"The user is currently viewing a **{context_type}**: **{name}**")
        lines.append("")
        
        if summary:
            lines.append("### Content Summary")
            lines.append(summary)
            lines.append("")
        
        # Add relevant metadata
        meta_parts = []
        if metadata.get("series_name"):
            meta_parts.append(f"Series: {metadata['series_name']}")
        if metadata.get("entity_name"):
            meta_parts.append(f"Entity: {metadata['entity_name']}")
        if metadata.get("space_id"):
            meta_parts.append(f"Space ID: {metadata['space_id']}")
        
        if meta_parts:
            lines.append(f"**Context:** {' | '.join(meta_parts)}")
        
        # Add attachments if present
        attachments = metadata.get("attachments") or []
        if attachments:
            lines.append("")
            lines.append("### Attachments")
            for att in attachments:
                name = att.get("name", "Attachment")
                url = att.get("url", "")
                if url:
                    lines.append(f"- [{name}]({url})")
                else:
                    lines.append(f"- {name}")
        
        lines.append("")
        lines.append("Use this pre-loaded context to answer the user's question directly when possible, "
                     "without needing additional tool calls.")
        
        return "\n".join(lines)
