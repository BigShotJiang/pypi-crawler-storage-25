#!/usr/bin/env python3
"""
Shared types and classes to resolve circular imports
"""

from typing import Dict, Any, List, Optional
from pydantic import BaseModel
from enum import Enum
from datetime import datetime

class TaskType(Enum):
    DOCUMENT_CREATION = "document_creation"
    DATA_STORAGE = "data_storage"
    FILE_MANAGEMENT = "file_management"
    MEETING_MANAGEMENT = "meeting_management"
    USER_MANAGEMENT = "user_management"
    URL_ROUTING = "url_routing"
    CALENDAR_MANAGEMENT = "calendar_management"


class Platform(Enum):
    GOOGLE_DRIVE = "google_drive"
    GOOGLE_DOCS = "google_docs"
    LARK = "lark"
    SUPABASE = "supabase"
    NOTION = "notion"


class ToolExecutionResult(BaseModel):
    """Result of tool execution"""
    success: bool
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    metadata: Dict[str, Any] = {}
    execution_time: float = 0.0
    reasoning: str = ""


class RouterDecision(BaseModel):
    """Decision about task routing"""
    task_type: TaskType
    target_platform: Platform
    confidence_score: float
    metadata: Dict[str, Any] = {}
    fallback_platforms: List[Platform] = []
    reasoning: str = ""


class AgentType(Enum):
    ANSWERING_AGENT = "answering_agent"
    TOOL_USE_AGENT = "tool_use_agent"
    BOTH = "both"


class AgentRoutingDecision(BaseModel):
    """Decision about which agent(s) to use"""
    primary_agent: AgentType
    secondary_agent: Optional[AgentType] = None
    execution_order: List[AgentType] = []
    confidence_score: float
    reasoning: str = ""
    requires_tool_execution: bool = False
    requires_answering: bool = True
    metadata: Dict[str, Any] = {}


