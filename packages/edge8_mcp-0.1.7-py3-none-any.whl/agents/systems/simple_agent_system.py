from typing import AsyncGenerator, Optional, List, Dict, Any
import os
import re
import sys
import json
import asyncio
from datetime import datetime
from time import time
from dotenv import load_dotenv

# Add project root to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from agents.systems.file_processor import FileProcessor
from agents.systems.shared import AgentState, MessageRole, AgentIntent, AgentStatus, RouterOutput
from agents.subagents.router_agent import RouterAgent
from agents.subagents.tool_agent import ToolAgent
from agents.subagents.answering_agent import AnsweringAgent
from agents.subagents.intent_verification_agent import IntentVerificationAgent
from agents.systems.grading_event_handler import GradingEventHandler
from agents.systems.tool_executor import ToolExecutor
from agents.tools.preprocessing.entity_resolver import EntityResolver
from agents.tools.database.aio.aio import DatabaseToolHandler
from agents.context.prefetcher import ContextPrefetcher
from agents.systems.response_types import (
    build_content_event,
    build_reasoning_event,
    build_error_event,
    build_metadata_event,
    build_timing_event,
    transform_tool_results,
    MetadataType,
    ChatMetadata,
)
from connectors.supabase_client.createClient import get_custom_client
from agents.systems.session_manager import SessionManager
from agents.systems.constants import (
    MAX_ITERATIONS,
    ENTITY_KEYWORDS,
    ACTION_KEYWORDS,
    GRADING_KEYWORDS,
    STUDENT_PROGRESS_KEYWORDS,
    AIO_KEYWORDS,
    requires_domain_knowledge,
    create_llm_suite,
    init_redis_cache,
)

load_dotenv()

# Cache feature flag at module load time — avoids os.getenv() on every run_stream call.
_COACH_PERSONA_ENABLED: bool = os.getenv("ENABLE_COACH_PERSONA", "").lower() in ("true", "1", "yes")


# --- Orchestrator ---

class AgentSystem:
    def __init__(
        self, 
        tool_groups: List[str] = None, 
        context: List[dict] = None,
        session_id: Optional[str] = None,
        member_id: Optional[int] = None,
        auto_save: bool = True,
        prompt_logger = None,
        student_inputs: Optional[Dict[str, Dict[str, str]]] = None,
        persona: str = "customer_service"  # ← ADD THIS PARAMETER
    ):
        api_key = os.environ.get("OPENROUTER_API_KEY")
        if not api_key:
            raise ValueError("OPENROUTER_API_KEY not found in environment variables")
            
        # Remove OpenRouterMultimodalLLM from imports - now internal to constants.py
        llms = create_llm_suite(api_key)
        self.router_llm = llms["router"]
        self.tool_llm = llms["tool"]
        self.intent_verification_llm = llms["intent"]
        self.writing_llm = llms["writing"]

        self.file_processor = FileProcessor()

        # Initialize Redis cache BEFORE creating agents
        self.cache = init_redis_cache()
        self._cache_ttl = 600  # 10 minutes
        self._cache_warned = False  # Suppress repeated cache error logs
        
        # Store prompt logger
        self.prompt_logger = prompt_logger
        
        # Initialize agents with cache support and prompt logger
        self.router = RouterAgent(self.router_llm, tool_groups, cache_client=self.cache, prompt_logger=prompt_logger)
        self.tool_agent = ToolAgent(self.tool_llm, prompt_logger=prompt_logger)
        self.answering_agent = AnsweringAgent(self.writing_llm, cache_client=self.cache, prompt_logger=prompt_logger)
        self.intent_verifier = IntentVerificationAgent(self.intent_verification_llm)
        self.state = AgentState()
        self.state.tool_groups = tool_groups  # Store tool_groups in state for context providers
        self.state.member_id = member_id  # Store member_id for student context
        self.state.tool_inputs = { "member_id": member_id }
        self.state.student_inputs = student_inputs  # Store student_inputs for grading workflow
        self.state.persona = persona  # Set initial persona (may be overridden by session or detection)
        
        # Session management
        supabase = None
        try:
            url = os.getenv("AIO_SUPABASE_URL")
            key = os.getenv("AIO_SUPABASE_SERVICE_ROLE_KEY")
            if url and key:
                supabase = get_custom_client(url, key, {"schema": "agents"})
        except Exception as e:
            print(f"Warning: Failed to initialize Supabase for session management: {e}")

        self.session_mgr = SessionManager(
            supabase=supabase,
            session_id=session_id,
            member_id=member_id,
            auto_save=auto_save,
        )

        # Expose for components that need direct DB access
        self.supabase = supabase
        self.session_id = session_id
        self.member_id = member_id
        self.auto_save = auto_save
        self.student_inputs = student_inputs

        # Initialize database tool with cache support
        self.database_tool = DatabaseToolHandler(cache_client=self.cache)

        # Initialize ContextPrefetcher for entity context preloading
        self.context_prefetcher = ContextPrefetcher(self.database_tool)

        # Initialize EntityResolver for entity-resolution-driven routing (Phase 2A/2B)
        self.entity_resolver = EntityResolver(self.database_tool)

        # Load session history + session_metadata in ONE DB round-trip.
        self._session_persona_loaded: bool = False
        if session_id and supabase:
            messages, workflow_state, session_metadata = self.session_mgr.load_messages()
            for msg in messages:
                self.state.add_message(MessageRole(msg["role"]), msg["content"])
            if workflow_state:
                self.state.workflow_state = workflow_state
            # Load persisted persona from session_metadata returned by load_messages().
            # No extra DB round-trip needed.
            if persona == "customer_service" and isinstance(session_metadata, dict):
                session_persona = session_metadata.get("persona")
                if session_persona:
                    self.state.persona = session_persona
                    self._session_persona_loaded = True
        elif context:
            for msg in context:
                self.state.add_message(MessageRole(msg["role"]), msg["content"])

        # Initialize GradingEventHandler for workflow state management
        self.grading_handler = GradingEventHandler(
            state=self.state,
            session_mgr=self.session_mgr,
            answering_agent=self.answering_agent,
            intent_verifier=self.intent_verifier,
            auto_save=self.auto_save,
            session_id=self.session_id,
        )

        # Initialize ToolExecutor for entity resolution and tool execution
        self.tool_executor = ToolExecutor(
            entity_resolver=self.entity_resolver,
            database_tool=self.database_tool,
            tool_agent=self.tool_agent,
            context_prefetcher=self.context_prefetcher,
        )

    async def _init_turn(
        self,
        user_input: str,
        email: Optional[str],
        files: Optional[list[dict]],
        context_type: Optional[str],
        context_id: Optional[str],
        iteration_start: float,
    ) -> AsyncGenerator[dict, None]:
        """Initialize a new turn: resolve email, save user message, reset state,
        prefetch context, extract file metadata.
        
        Yields:
            Timing events and reasoning events for prefetch.
        
        Side effects:
            - Sets self.state fields (current_input, email, context_prefetch, etc.)
            - Saves user message to session
            - Creates extraction_task if files present (stored in self._extraction_task)
        
        Sets instance attributes:
            - self._resolved_email: str | None
            - self._extraction_task: asyncio.Task | None
            - self._session_context_type: str | None
        """
        # Update State with User Input
        self.state.current_input = user_input
        self.state.add_message(MessageRole.USER, user_input)
        
        # Resolve email from member_id in parallel with saving the user message
        async def _resolve_email():
            if email is not None or not self.state.member_id or not self.supabase:
                return email
            try:
                member = (
                    self.supabase
                    .schema('public')
                    .table('members')
                    .select('email')
                    .eq("id", self.state.member_id)
                    .execute()
                ).data
                if member and len(member) > 0:
                    return member[0].get('email')
            except Exception:
                pass
            return None

        async def _save_user_message():
            if self.auto_save and self.session_id:
                print("Saving user message to session, session_id: ", self.session_id)
                user_metadata = {"email": email} if email else {}
                await self.session_mgr.save_message_async(
                    role="user",
                    content=user_input,
                    metadata=user_metadata,
                    files=files
                )

        resolved_email, _ = await asyncio.gather(_resolve_email(), _save_user_message())
        self._resolved_email = resolved_email
        yield build_timing_event("email_resolve_and_save", (time() - iteration_start) * 1000)

        # Reset per-turn state
        self.state.intent = None
        self.state.tool_call = None
        self.state.tool_results = None
        self.state.final_response = None
        self.state.error = None
        self.state.iteration_count = 0
        self.state.tool_inputs["email"] = resolved_email
        self.state.email = resolved_email
        self._session_context_type = context_type

        # Pre-fetch context if context_id provided
        prefetch_timing_emitted = False
        prefetch_start = time()
        print("Context ID and Type: ", context_id, context_type)
        if context_type and context_id:
            print("Pre-fetching context...")
            try:
                prefetcher = ContextPrefetcher(self.intent_verifier.db_handler)
                prefetch_data = await prefetcher.fetch_cached(
                    context_type, context_id, student_id=self.member_id, cache=self.cache
                )
                if prefetch_data:
                    self.state.context_prefetch = prefetch_data
                    context_summary = prefetcher.format_for_prompt(context_type, prefetch_data)
                    self.state.add_message(
                        MessageRole.SYSTEM,
                        f"[Pre-loaded context: {context_type}]\n{context_summary}"
                    )
                    yield build_reasoning_event(
                        step="Context Loaded",
                        reasoning=(
                            f"I found pre-loaded context for this {context_type}, so I already have relevant details available. "
                            f"The {context_type} data includes a summary with key information that should help me answer accurately. "
                            f"Since this context was fetched ahead of time, I can skip a full database search and respond more quickly. "
                            f"Let me review what I have and determine if this is sufficient to address the question directly."
                        )
                    )
                    prefetch_timing_emitted = True
            except Exception:
                pass
            finally:
                if prefetch_timing_emitted:
                    yield build_timing_event("context_prefetch", (time() - prefetch_start) * 1000)

        # Add file metadata to state for RouterAgent
        self._extraction_task = None
        if files:
            file_metadata = self.file_processor.extract_metadata(files)
            self.state.tool_inputs["file_metadata"] = file_metadata
            
            metadata_summary = self.file_processor.format_metadata_summary(file_metadata)
            self.state.add_message(
                MessageRole.SYSTEM,
                f"[User uploaded {len(files)} file(s)]\n{metadata_summary}"
            )
            
            # Start file extraction in parallel (non-blocking)
            if self.file_processor.is_question_about_files(user_input, files):
                self._extraction_task = asyncio.create_task(
                    self.file_processor.extract_or_prepare_files(files)
                )

    async def _try_prefetch_shortcut(
        self,
        user_input: str,
        files: Optional[list],
        context_type: Optional[str],
        iteration_start: float,
    ) -> Optional[AsyncGenerator[dict, None]]:
        """Check if prefetch context can answer the question directly.
        
        Returns:
            AsyncGenerator of events if shortcut applies, None otherwise.
        """
        prefetch_summary = (self.state.context_prefetch or {}).get("summary", "")
        if self.state.context_prefetch and prefetch_summary and not files:
            input_lower = user_input.lower()
            is_action_request = any(kw in input_lower for kw in ACTION_KEYWORDS)

            if not is_action_request:
                async def _shortcut_gen():
                    yield build_reasoning_event(
                        step="Answering",
                        reasoning=(
                            f"I already have pre-loaded {context_type} context that looks relevant to this question. "
                            f"The user isn't asking me to perform an action — this is an informational query I can handle directly. "
                            f"I'll use the available context to compose an answer without running additional tool searches. "
                            f"This should give a faster and more focused response since the data is already in front of me."
                        )
                    )
                    async for event in self._stream_answer_and_save(
                        extra_metadata={"prefetch_shortcut": True, "context_type": context_type}
                    ):
                        yield event
                    yield build_timing_event("iteration_complete", (time() - iteration_start) * 1000, {"shortcut": "prefetch"})
                return _shortcut_gen()
        return None

    async def run(self, user_input: str) -> str:
        """Main execution loop (non-streaming wrapper)."""
        full_response = ""
        try:
            async for chunk in self.run_stream(user_input):
                full_response += chunk
            return full_response
        except Exception as e:
            self.state.error = str(e)
            print(f"Error in run: {e}")
            return str(e)

    async def run_stream(
        self,
        user_input: str,
        email: Optional[str] = None,
        files: Optional[list[dict[str, str]]] = None,
        with_post: Optional[bool] = False,
        context_type: Optional[str] = None,
        context_id: Optional[str] = None,
    ) -> AsyncGenerator[dict[str, str], None]:
        """Main execution loop with streaming."""
        iteration_start = time()
        
        # Resolve persona via rule-based detection (context_type+context_id),
        # session shortcut, LLM fallback, or default — in that priority order.
        self.state.persona = await self._resolve_persona(context_type, context_id, user_input)

        # Persist resolved persona to existing session on first turn only.
        # (New sessions get persona written in create_session(). Existing sessions
        #  need an explicit update so future turns can shortcut via session_metadata.)
        if self.session_mgr.session_id and not self._session_persona_loaded:
            self.session_mgr.update_session_metadata({"persona": self.state.persona})
            self._session_persona_loaded = True  # suppress repeat writes on subsequent turns

        print(f"\n{'='*60}")
        print(f"🚀 Starting agent iteration at {datetime.now().strftime('%H:%M:%S.%f')[:-3]}")
        print(f"{'='*60}")
        
        # 1. Initialize turn (email, state, prefetch, files)
        async for event in self._init_turn(user_input, email, files, context_type, context_id, iteration_start):
            print("Init turn event: ", event)
            yield event

        # 2. Prefetch shortcut — skip Router if context answers the question
        shortcut = await self._try_prefetch_shortcut(user_input, files, context_type, iteration_start)
        if shortcut is not None:
            async for event in shortcut:
                print("Shortcut event: ", event)
                yield event
            return

        # 3. Workflow state machine — grading flows
        workflow = await self.grading_handler.dispatch_workflow(user_input, self._resolved_email, files)
        if workflow is not None:
            async for event in workflow:
                yield event
            return

        # 4. Main agent loop
        try:
            while True:
                self.state.iteration_count += 1

                # Hard stop
                if self.state.iteration_count > MAX_ITERATIONS:
                    async for event in self._stream_answer_and_save(extra_metadata={"hard_stop": True, "iterations": self.state.iteration_count}):
                        yield event
                    break

                # General chat fast-path (must check BEFORE pre-warm to avoid blocking)
                if self._is_general_chat(user_input, files) and self.state.iteration_count == 1:
                    yield build_reasoning_event(
                        step="Thinking",
                        reasoning=(
                            f"The user's message doesn't mention any specific entities like missions, challenges, or series. "
                            f"There are no uploaded files and no pre-loaded context to work with either. "
                            f"This looks like a general conversational message, so I can respond directly using my knowledge. "
                            f"I'll skip the entity resolution and tool search steps to give a faster, more natural response."
                        )
                    )
                    async for event in self._stream_answer_and_save(extra_metadata={"general_chat": True}):
                        yield event
                    break

                # Pre-warm context cache so fast-paths below can check it without router.decide()
                # Runs after general chat check to unblock simple conversational queries
                if self.state.iteration_count == 1:
                    await self.router.context_registry.get_context(self.state)

                # Student progress fast-path — skip Router+Tool when context covers the question
                _input_lower_fp = user_input.lower()
                if (
                    self.state.iteration_count == 1
                    and not files
                    and not any(kw in _input_lower_fp for kw in ACTION_KEYWORDS)
                    and any(kw in _input_lower_fp for kw in STUDENT_PROGRESS_KEYWORDS)
                    and self.state._context_cache
                ):
                    yield build_reasoning_event(
                        step="Answering from Context",
                        reasoning=(
                            "The question is about the student's personal progress or certification status. "
                            "This is already covered by the student context loaded at the start of this turn. "
                            "Skipping router and tool calls — answering directly from available context."
                        )
                    )
                    async for event in self._stream_answer_and_save(
                        extra_metadata={"student_progress_shortcut": True}
                    ):
                        yield event
                    break

                # Auto-resolve entity context (Phase 5A)
                async for event in self.tool_executor.auto_resolve_entity(
                    self.state, user_input, self._session_context_type
                ):
                    print("Auto resolve entity event: ", event)
                    yield event

                # Auto-resolve shortcut — skip Router+Tool if entity data already fetched (Phase 9)
                _auto_resolve_summary = (self.state.context_prefetch or {}).get("summary", "")
                if (
                    self.state.context_prefetch
                    and _auto_resolve_summary
                    and self.state.iteration_count == 1
                    and not files
                    and not any(kw in user_input.lower() for kw in ACTION_KEYWORDS)
                ):
                    print("Context prefetch: ", self.state.context_prefetch)
                    yield build_reasoning_event(
                        step="Answering",
                        reasoning=(
                            f"I already resolved the entity and loaded its details from the database. "
                            f"The context has all the information needed to answer this question directly. "
                            f"Skipping additional search steps since the data is already available."
                        )
                    )
                    async for event in self._stream_answer_and_save(
                        extra_metadata={"auto_resolve_shortcut": True}
                    ):
                        yield event
                    break

                # Hard gate: submission language → grading (first iteration only)
                # Covers both file submissions and text-only submissions.
                # Also triggers when context_type="challenge" (user is on a challenge page)
                # to prevent the Router/AnsweringAgent from generating a hallucinated
                # generic feedback response using the prefetched challenge context.
                _input_lower = user_input.lower()
                _has_grading_signal = (
                    any(kw in _input_lower for kw in GRADING_KEYWORDS)
                    or any(kw in _input_lower for kw in ACTION_KEYWORDS)
                )
                # Tighter signal for text-only challenge-context path: require an unambiguous
                # submission verb so informational queries ("how do I upload?", "what's the
                # final assignment?") on challenge pages don't trigger the grading workflow.
                _SUBMISSION_VERBS = {"submit", "grade", "grading", "submission", "resubmit", "turn in", "hand in"}
                _has_submission_verb = any(kw in _input_lower for kw in _SUBMISSION_VERBS)
                _is_challenge_context = self._session_context_type == "challenge"
                if (
                    (files or (_is_challenge_context and _has_submission_verb))
                    and self.state.iteration_count == 1
                    and "grading_system" in self.router.chosen_tool_groups_enum
                    and _has_grading_signal
                ):
                    _gate_reason = (
                        "User uploaded files — routing directly to grading workflow."
                        if files
                        else "Challenge context detected with submission intent — routing directly to grading workflow."
                    )
                    grading_decision = RouterOutput(
                        intent=AgentIntent.TOOL,
                        status=AgentStatus.CONTINUE,
                        step="Processing Submission",
                        reasoning=_gate_reason,
                        tools_group="grading_system",
                    )
                    yield build_timing_event("router_decide", 0)
                    yield build_reasoning_event(step=grading_decision.step, reasoning=grading_decision.reasoning)
                    self.state.intent = grading_decision.intent
                    self.state.status = grading_decision.status
                    async for event in self.grading_handler.handle_grading_intent(grading_decision, user_input, self._resolved_email, files, context_type, context_id, iteration_start):
                        yield event
                    return

                # Router decision
                router_start = time()
                decision = await self.router.decide(self.state)
                # print("Router decision: ", decision)
                for cb_event in self._apply_circuit_breaker(decision, user_input):
                    yield cb_event
                yield build_timing_event("router_decide", (time() - router_start) * 1000)
                yield build_reasoning_event(step=decision.step, reasoning=decision.reasoning)
                self.state.intent = decision.intent
                self.state.status = decision.status

                # Grading intent
                if decision.tools_group == "grading_system":
                    async for event in self.grading_handler.handle_grading_intent(decision, user_input, self._resolved_email, files, context_type, context_id, iteration_start):
                        yield event
                    return  # Grading always terminates the turn

                # FINISHED → answer
                if decision.status == AgentStatus.FINISHED and decision.intent == AgentIntent.CHAT:
                    guard_result, guard_events = self._apply_hallucination_guard(decision, user_input)
                    for ge in guard_events:
                        yield ge
                    if guard_result is None:
                        async for event in self._stream_answer_and_save(extraction_task=self._extraction_task):
                            yield event
                        break
                    else:
                        decision = guard_result  # Redirected to TOOL

                # CONTINUE → tool execution
                if decision.intent == AgentIntent.TOOL:
                    async for event in self.tool_executor.execute_with_resolution(
                        self.state, user_input, self.router.chosen_group
                    ):
                        yield event

        except Exception as e:
            self.state.error = str(e)
            await self.session_mgr.flush_pending()
            yield build_error_event(str(e))

    def get_history(self):
        return self.state.messages
    
    def _infer_best_tool_group(self, user_input: str) -> str:
        """Infer the best tool group based on user input keywords.
        
        Used by circuit breaker when router loops without making progress.
        
        Args:
            user_input: The user's input text

        Returns:
            Tool group name (e.g., 'grading_system', 'general')
        """
        input_lower = user_input.lower()

        # Grading/submission related
        if any(kw in input_lower for kw in GRADING_KEYWORDS):
            return "grading_system"

        # Default to general for everything else
        return "general"

    def _is_general_chat(self, user_input: str, files: Optional[list]) -> bool:
        """Check if this is a general chat (no entity terms, no files, no prefetch)."""
        # Coach persona always needs grounding — never bypass to general chat
        if self.state.persona == "coach" and os.getenv("ENABLE_COACH_PERSONA", "").lower() in ("true", "1", "yes"):
            return False
        
        has_entity_terms = any(kw in user_input.lower() for kw in ENTITY_KEYWORDS)
        return not has_entity_terms and not files and not self.state.context_prefetch

    def _apply_circuit_breaker(self, decision, user_input: str) -> list[dict]:
        """Mutate decision in-place if circuit breaker triggers (iteration >= 2, no results).
        
        Returns:
            List of reasoning events to yield.
        """
        events: list[dict] = []
        if self.state.iteration_count >= 2 and not self.state.tool_results:
            events.append(build_reasoning_event(
                step="Searching",
                reasoning=(
                    f"This is iteration {self.state.iteration_count} and I still don't have any tool results to ground my answer. "
                    f"The router has been going back and forth without producing concrete data from the database or search tools. "
                    f"I need to break this cycle and force a tool search to retrieve actual information before I can respond. "
                    f"Let me intervene and trigger a search to make sure the answer is based on real data."
                )
            ))
            if decision.intent == AgentIntent.CHAT and decision.status == AgentStatus.CONTINUE:
                decision.intent = AgentIntent.TOOL
                decision.tools_group = self._infer_best_tool_group(user_input)
                events.append(build_reasoning_event(
                    step="Searching",
                    reasoning=(
                        f"The router wanted to continue chatting, but without any grounding data that risks an inaccurate response. "
                        f"I'm overriding the router's decision and redirecting to the '{decision.tools_group}' tool group instead. "
                        f"Based on the keywords in the user's message, this tool group is the best match for finding relevant information. "
                        f"Once I have real data from the search, I can provide a well-grounded answer."
                    )
                ))
        return events

    def _apply_hallucination_guard(self, decision, user_input: str) -> tuple[Optional[Any], list[dict]]:
        """Check if domain question needs grounding.
        
        Returns:
            (modified_decision_or_None, list_of_reasoning_events_to_yield)
        """
        requires_grounding, matched_group = requires_domain_knowledge(user_input, self.state.tool_groups)
        _has_grading_intent = (
            any(kw in user_input.lower() for kw in GRADING_KEYWORDS)
            or any(kw in user_input.lower() for kw in ACTION_KEYWORDS)
        )
        # context_prefetch must NOT neutralize the guard when the user has grading intent —
        # prefetched challenge context is not a grading result and cannot substitute for it.
        _context_cache_blocks_guard = self.state._context_cache and not _has_grading_intent
        if requires_grounding and not self.state.tool_results and not self.state.context_prefetch and not _context_cache_blocks_guard:
            decision.intent = AgentIntent.TOOL
            decision.status = AgentStatus.CONTINUE
            decision.tools_group = matched_group or "general"
            self.state.intent = decision.intent
            self.state.status = decision.status
            return decision, [build_reasoning_event(
                step="Searching",
                reasoning=(
                    f"The router marked this as finished, but the question appears to require domain-specific knowledge ({matched_group or 'general'}). "
                    f"I don't have any tool results or pre-loaded context to back up an answer, which means responding now could produce hallucinated content. "
                    f"To prevent that, I'm overriding the router's decision and forcing a tool search in the '{decision.tools_group}' group first. "
                    f"This anti-hallucination guard ensures every domain question is answered with real, verified data from the database."
                )
            )]
        return None, []

    async def create_session(
        self,
        title: Optional[str] = None,
        context_type: Optional[str] = None,
        context_id: Optional[str] = None,
        context_metadata: Optional[Dict[str, Any]] = None,
        session_metadata: Optional[Dict[str, Any]] = None
    ) -> Optional[str]:
        """Create a new session in database and return session_id"""
        if session_metadata is None:
            session_metadata = {
                "router_model": self.router_llm.fallback_models or self.router_llm.model,
                "tool_llm": self.tool_llm.fallback_models or self.tool_llm.model,
                "intent_verification_llm": self.intent_verification_llm.fallback_models or self.intent_verification_llm.model,
                "writing_model": self.writing_llm.model,
            }
        # Option B: persist current persona into session so future turns auto-load it
        session_metadata["persona"] = self.state.persona
        session_id = await self.session_mgr.create_session(
            title, context_type, context_id, context_metadata, session_metadata
        )
        if session_id:
            self.session_id = session_id
            self.session_mgr.session_id = session_id
        return session_id

    async def _resolve_persona(
        self,
        context_type: Optional[str],
        context_id: Optional[str],
        user_input: str,
    ) -> str:
        """Determine persona dynamically per turn.

        Resolution order (highest to lowest priority):
        1. Rule: context_type in ('mission', 'challenge') WITH context_id → 'coach'
        2. Rule: context_type set but not a coaching type → 'customer_service'
        3. Session: persisted session_metadata.persona → use without LLM call
        4. LLM detection: classify from user_input when no context and no session persona
        5. Fallback: keep current state.persona unchanged
        """
        if not _COACH_PERSONA_ENABLED:
            return self.state.persona

        # Rule-based: context_type provided by the client
        if context_type:
            if context_type in ("mission", "challenge") and context_id:
                return "coach"
            return "customer_service"

        # Session shortcut: persona already persisted for this session — skip LLM
        if getattr(self, "_session_persona_loaded", False):
            return self.state.persona

        # LLM fallback: no context_type/context_id and no session persona — detect from message
        try:
            from connectors.openrouter.llm import ChatMessage
            detection_prompt = (
                "Classify the user message as either 'coach' or 'customer_service'.\n"
                "Reply with ONLY the single word 'coach' or 'customer_service'.\n\n"
                "Use 'coach' if the user is:\n"
                "- Asking how to solve a challenge or mission task\n"
                "- Seeking validation or answers for specific challenge questions\n"
                "- Asking for step-by-step help with a learning task\n"
                "- Debugging their submission or asking if their work is correct\n\n"
                "Use 'customer_service' for everything else:\n"
                "- General questions about the program, enrollment, events\n"
                "- Progress tracking, certification, navigation\n"
                "- Greetings or casual conversation\n"
            )
            messages = [
                ChatMessage(role="system", content=detection_prompt),
                ChatMessage(role="user", content=user_input),
            ]
            response = await self.router_llm.achat(messages)
            detected = response.content.strip().lower()
            if detected in ("coach", "customer_service"):
                return detected
        except Exception as e:
            print(f"Warning: persona LLM detection failed: {e}")

        return self.state.persona

    _WORKBOOK_ANSWER_TAG = re.compile(
        r'<workbook_answer>(.*?)</workbook_answer>', re.DOTALL
    )

    def _extract_workbook_answers(self, response_text: str) -> str:
        """Strip <workbook_answer> tags from response and merge answers into state.

        Returns the cleaned response text (tags removed).
        """
        for match in self._WORKBOOK_ANSWER_TAG.finditer(response_text):
            try:
                data = json.loads(match.group(1).strip())
                section = data.get("section", "")
                field = data.get("field", "")
                value = data.get("value", "")
                if section and field and value:
                    if self.state.workbook_answers is None:
                        self.state.workbook_answers = {}
                    self.state.workbook_answers.setdefault(section, {})[field] = value
            except (json.JSONDecodeError, KeyError, AttributeError):
                pass
        return self._WORKBOOK_ANSWER_TAG.sub("", response_text).rstrip()

    async def _stream_answer_and_save(
        self,
        extra_metadata: Optional[Dict[str, Any]] = None,
        extraction_task: Optional[asyncio.Task] = None,
    ) -> AsyncGenerator[dict, None]:
        """Stream answer from AnsweringAgent, save to session, flush pending saves.

        This is the canonical answer path used by all non-grading flows:
        prefetch shortcut, hard stop, general chat, and normal CHAT+FINISHED.

        Args:
            extra_metadata: Additional metadata to merge into assistant message metadata.
            extraction_task: Optional file extraction task to await before answering.

        Yields:
            SSE events: content chunks, timing events, metadata events.

        Side effects:
            - Sets self.state.final_response
            - Adds assistant message to self.state.messages
            - Saves message to session (if auto_save enabled)
            - Flushes pending saves
        """
        # Wait for file extraction if needed
        if extraction_task:
            try:
                file_content = await extraction_task
                self.state.tool_inputs["file_content"] = file_content
            except Exception:
                pass

        # Build metadata from tool results
        final_metadata: ChatMetadata = {"type": MetadataType.TEXT.value}
        if self.state.tool_results:
            final_metadata = transform_tool_results(self.state.tool_results)

        # Stream answer
        # Coach persona: buffer full response to strip <workbook_answer> tags before display.
        # Non-coach: stream live as before.
        is_coach = (
            _COACH_PERSONA_ENABLED
            and getattr(self.state, "persona", "customer_service") == "coach"
        )
        response_content = ""
        ans_start = time()

        if is_coach:
            # Buffer all chunks first, then extract tags, then emit cleaned text
            raw_content = ""
            async for chunk in self.answering_agent.astream_answer(self.state):
                raw_content += chunk
                if ans_start > 0:
                    yield build_timing_event("answering_first_chunk", (time() - ans_start) * 1000)
                    ans_start = 0
            response_content = self._extract_workbook_answers(raw_content)
            yield build_content_event(response_content)
        else:
            async for chunk in self.answering_agent.astream_answer(self.state):
                response_content += chunk
                yield build_content_event(chunk)
                if ans_start > 0:
                    yield build_timing_event("answering_first_chunk", (time() - ans_start) * 1000)
                    ans_start = 0

        # Yield structured metadata if present
        if final_metadata.get("summary") or final_metadata.get("files"):
            yield build_metadata_event(final_metadata)

        # Update state
        self.state.final_response = response_content
        self.state.add_message(MessageRole.ASSISTANT, response_content)

        # Persist
        if self.auto_save and self.session_id:
            print("Saving message to session")
            await self.session_mgr.save_message_async(
                role="assistant",
                content=response_content,
                metadata={"model": self.writing_llm.model, **(extra_metadata or {}), **final_metadata}
            )
        await self.session_mgr.flush_pending()
