"""Shared constants for the agent system.

Centralizes keyword lists, workflow state types, and domain indicators
to eliminate duplication across simple_agent_system.py and extracted modules.
"""

from enum import Enum
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from connectors.openrouter.llm import OpenRouterMultimodalLLM


# --- LLM Factory ---

def create_aio_llm_suite(api_key: str) -> dict[str, "OpenRouterMultimodalLLM"]:
    """Create the LLM client suite for AIO Agent System.

    Uses google/gemini-2.5-flash for all roles with role-specific temperatures.
    """
    from connectors.openrouter.llm import OpenRouterMultimodalLLM

    _model = "google/gemini-2.5-flash"
    return {
        "aio": OpenRouterMultimodalLLM(api_key=api_key, model=_model, temperature=0.2),
        "planner": OpenRouterMultimodalLLM(api_key=api_key, model=_model, temperature=0.1),
        "scorer": OpenRouterMultimodalLLM(api_key=api_key, model=_model, temperature=0.1),
        "reflector": OpenRouterMultimodalLLM(api_key=api_key, model=_model, temperature=0.3),
    }


def create_llm_suite(api_key: str) -> dict[str, "OpenRouterMultimodalLLM"]:
    """Create the standard LLM client suite for the agent system."""
    from connectors.openrouter.llm import OpenRouterMultimodalLLM

    _fast = [
        # "arcee-ai/trinity-large-preview:free",
        # "meta-llama/llama-3.1-8b-instruct",
        "alibaba/tongyi-deepresearch-30b-a3b",
        "meta-llama/llama-3.1-8b-instruct:nitro",
        # "cohere/command-r7b-12-2024",
        # "arcee-ai/trinity-mini:nitro",
        # "prime-intellect/intellect-3",
        # "arcee-ai/trinity-mini",
        "openai/gpt-oss-120b:exacto",
        # "google/gemini-2.5-flash-lite",
        # "google/gemma-3-27b-it",
        # "z-ai/glm-4.7-flash"
    ]
    return {
        "router": OpenRouterMultimodalLLM(api_key=api_key, fallback_models=_fast, temperature=0.1),
        "tool": OpenRouterMultimodalLLM(api_key=api_key, fallback_models=_fast, temperature=0.1),
        "intent": OpenRouterMultimodalLLM(api_key=api_key, fallback_models=_fast, temperature=0.1),
        "writing": OpenRouterMultimodalLLM(api_key=api_key, model="google/gemini-2.5-flash-lite:nitro", temperature=0.2),
    }


# --- Redis Cache Factory ---

def init_redis_cache():
    """Initialize Upstash Redis cache. Returns None if unavailable."""
    try:
        from upstash_redis import Redis
    except ImportError:
        print("⚠️  upstash-redis not installed - caching disabled")
        return None

    import os

    redis_url = os.getenv("UPSTASH_REDIS_URL")
    redis_token = os.getenv("UPSTASH_REDIS_TOKEN")
    if redis_url and redis_token:
        try:
            cache = Redis(url=redis_url, token=redis_token)
            print("✅ Redis cache initialized")
            return cache
        except Exception as e:
            print(f"⚠️  Redis cache initialization failed: {e}")
    else:
        print("⚠️  UPSTASH_REDIS_URL or UPSTASH_REDIS_TOKEN not set - caching disabled")
    return None


# --- Workflow State Types ---
# Used in self.state.workflow_state["type"] comparisons


class WorkflowType(str, Enum):
    """Workflow state machine types for grading flow."""

    MISSION_CONFIRMATION = "mission_confirmation_pending"
    POSTING_CONFIRMATION = "grading_awaiting_posting_confirmation"
    RESUBMISSION = "resubmission_confirmation_pending"
    MISSION_CONFIRMED = "mission_confirmed"

    # Bulk grading
    BULK_MISSION_CONFIRMATION = "bulk_mission_confirmation_pending"
    BULK_POSTING_CONFIRMATION = "bulk_grading_awaiting_posting_confirmation"

    # Coach workbook submission
    WORKBOOK_SUBMIT = "workbook_submit_pending"


# --- Maximum Iterations ---

MAX_ITERATIONS = 3


# --- Domain Knowledge Indicators ---
# Maps tool groups to domain-specific keywords that require grounding data.
# Used by anti-hallucination guard to force tool calls.

DOMAIN_KNOWLEDGE_INDICATORS: dict[str, set[str]] = {
    # Future platforms can add their own domain terms
}


def requires_domain_knowledge(user_input: str, tool_groups: list[str] | None = None) -> tuple[bool, str | None]:
    """Check if user input requires domain-specific knowledge.

    Returns:
        Tuple of (requires_grounding, matched_tool_group)
    """
    input_lower = user_input.lower()
    groups_to_check = tool_groups or []
    for group in groups_to_check:
        for indicator in DOMAIN_KNOWLEDGE_INDICATORS.get(group, set()):
            if indicator in input_lower:
                return True, group
    return False, None


# --- Student Progress Keywords ---
# First-person intent signals that indicate the user is asking about their OWN progress.
# When these are present AND student context is cached, skip the Router LLM entirely.

STUDENT_PROGRESS_KEYWORDS: set[str] = {
    "my progress",
    "my mission",
    "my certification",
    "my enrollment",
    "my program",
    "what have i",
    "what did i",
    "have i completed",
    "have i done",
    "what's next for me",
    "whats next for me",
    "next step",
    "what do i need",
    "my journey",
    "am i enrolled",
    "am i done",
    "how far am i",
    "how many missions",
    "my badge",
}


# --- Entity Keywords ---
# Terms that indicate the user is referencing a specific curriculum entity.
# Used by Phase 5A (auto-resolve) and general chat detection.

ENTITY_KEYWORDS: set[str] = {
    "mission",
    "challenge",
    "series",
    "workshop",
    "program",
    "certification",
    "course",
    "lesson",
}


# --- Action Keywords ---
# Terms that indicate the user wants to perform an action (not just ask a question).
# Used by prefetch shortcut to avoid skipping Router for submission requests.

ACTION_KEYWORDS: set[str] = {
    "submit",
    "grade",
    "grading",
    "submission",
    "resubmit",
    "upload",
    "turn in",
    "hand in",
    "post my",
    "post it",
}


# --- Grading Keywords ---
# Terms that indicate grading/submission intent.
# Used by _infer_best_tool_group circuit breaker.

GRADING_KEYWORDS: set[str] = {
    "submit",
    "grade",
    "submission",
    "assignment",
    "challenge",
    "capstone",
    "final",
}


# --- AIO Content Keywords ---
# Terms that indicate AIO platform content queries.
# Used by _infer_best_tool_group circuit breaker.

AIO_KEYWORDS: set[str] = {
    "mission",
    "series",
    "workshop",
    "micro session",
    "certification",
    "program",
}


# --- Workflow Cancel Keywords ---

CANCEL_KEYWORDS: set[str] = {
    "cancel",
    "stop",
    "nevermind",
    "never mind",
    "forget it",
    "abort",
    "quit",
    "exit",
}


# --- Entity Type to Resource Mapping ---
# Maps EntityResolver entity types to DatabaseToolHandler resource names.

ENTITY_TYPE_TO_RESOURCE: dict[str, str] = {
    "mission": "missions",
    "challenge": "challenges",
    "series": "series",
    "workshop": "workshops",
    "event": "events",
    "brief": "briefs",
}
