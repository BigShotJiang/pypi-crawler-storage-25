"""
AIO Agent System - Simplified single-agent architecture for reduced latency.

Design:
- Single AIO Agent with 2 tools: planner_tool and grading_tool
- No loop - answer with whatever data we have
- Tool execution in parallel via asyncio.gather
- Streaming responses throughout

Flow:
User Input → AIO Agent (decides + calls tools) → Tool Results → AIO Agent generates response
"""

from typing import AsyncGenerator, Optional, List, Dict, Any
import os
import asyncio
import json
from datetime import datetime
from time import time
from dotenv import load_dotenv

from connectors.openrouter.llm import ChatMessage
from agents.tools.handlers import execute_tool
from agents.tools.schema import get_tools_by_group, ToolSchema
from agents.tools.schemas.circle import circle_db_query_tool
from agents.systems.shared import AgentState, MessageRole
from agents.systems.constants import (
    create_aio_llm_suite,
    init_redis_cache,
    DOMAIN_KNOWLEDGE_INDICATORS,
    GRADING_KEYWORDS,
    ACTION_KEYWORDS,
    WorkflowType,
    CANCEL_KEYWORDS,
)
from agents.systems.session_manager import SessionManager
from agents.systems.grading_event_handler import GradingEventHandler
from agents.subagents.intent_verification_agent import IntentVerificationAgent
from agents.tools.database.aio.aio import DatabaseToolHandler
from agents.context.prefetcher import ContextPrefetcher
from agents.context.registry import ContextRegistry
from agents.context.providers.student_provider import StudentContextProvider
from agents.context.providers.prefetch_provider import PrefetchContextProvider
from agents.systems.aio_prompts import (
    get_aio_system_prompt,
    get_planner_system_prompt,
    get_planner_user_prompt,
    get_session_titling_prompt,
)
from agents.systems.response_types import (
    build_content_event,
    build_reasoning_event,
    build_error_event,
    build_metadata_event,
    build_timing_event,
)
from connectors.supabase_client.createClient import get_custom_client
from utils.formatting import format_for_llm

load_dotenv()


class AIOAgentSystem:
    """
    Simplified single-agent system with 2 tools: planner_tool and grading_tool.

    Reduces latency by:
    - Combining Router + Answering into single AIO Agent
    - Executing tools in parallel
    - No loop - answer with whatever data we have
    """

    def __init__(
        self,
        tool_groups: List[str] = None,
        context: List[dict] = None,
        session_id: Optional[str] = None,
        member_id: Optional[int] = None,
        auto_save: bool = True,
    ):
        api_key = os.environ.get("OPENROUTER_API_KEY")
        if not api_key:
            raise ValueError("OPENROUTER_API_KEY not found in environment variables")

        # LLM clients from shared factory
        llms = create_aio_llm_suite(api_key)
        self.aio_llm = llms["aio"]
        self.planner_llm = llms["planner"]
        # Redis cache from shared factory
        self.cache = init_redis_cache()

        # Initialize state
        self.state = AgentState()
        self.state.tool_groups = tool_groups or []
        self.state.member_id = member_id
        self.state.tool_inputs = {"member_id": member_id}

        # Session management
        self.session_id = session_id
        self.member_id = member_id
        self.auto_save = auto_save
        self.supabase = None

        try:
            url = os.getenv("AIO_SUPABASE_URL")
            key = os.getenv("AIO_SUPABASE_SERVICE_ROLE_KEY")
            if url and key:
                self.supabase = get_custom_client(url, key, {"schema": "agents"})
        except Exception as e:
            print(f"Warning: Failed to initialize Supabase: {e}")

        # Initialize database tool handler
        self.database_tool = DatabaseToolHandler(cache_client=self.cache)

        # Initialize context providers
        self.context_registry = ContextRegistry()
        self.context_registry.register(StudentContextProvider(cache_client=self.cache))
        self.context_registry.register(PrefetchContextProvider())

        # Context prefetcher
        self.context_prefetcher = ContextPrefetcher(self.database_tool)

        # Session manager (shared persistence layer used by GradingEventHandler)
        self.session_mgr = SessionManager(
            supabase=self.supabase,
            session_id=session_id,
            member_id=member_id,
            auto_save=auto_save,
        )
        # Register the mid-session title refinement callback
        self.session_mgr._title_callback = self._build_refined_title

        # Intent verifier + grading workflow state machine
        self.intent_verifier = IntentVerificationAgent(self.aio_llm)
        self.grading_handler = GradingEventHandler(
            state=self.state,
            session_mgr=self.session_mgr,
            answering_agent=None,  # AIO uses streaming LLM directly, not a separate answering agent
            intent_verifier=self.intent_verifier,
            auto_save=auto_save,
            session_id=session_id,
        )

        # Load from session or context
        self._session_loaded = False
        if session_id and self.supabase:
            # Deferred to first run_stream call (async context required)
            pass
        elif context:
            for msg in context:
                self.state.add_message(MessageRole(msg["role"]), msg["content"])

    def _get_aio_system_prompt(self, additional_context: str = "") -> str:
        """Build the system prompt for AIO Agent."""
        # Build user identity section
        user_identity_parts = []
        if self.state.email:
            user_identity_parts.append(f"- Student email: {self.state.email}")
        if self.state.member_id:
            user_identity_parts.append(f"- Member ID: {self.state.member_id}")
        user_identity = "\n".join(user_identity_parts) if user_identity_parts else "- No user identity available"

        return get_aio_system_prompt(
            user_identity=user_identity,
            additional_context=additional_context,
        )

    def _get_planner_tool_schema(self) -> Dict[str, Any]:
        """Schema for planner_tool.
        
        Returns the raw function schema dict — the LLM client's
        _prepare_chat_with_tools() will wrap it in {"type": "function", "function": ...}.
        """
        return {
            "name": "planner_tool",
            "description": "Search for information about AIO content (missions, challenges, progress, events, etc.). Returns data from the database. Can be called multiple times in parallel with different questions.",
            "parameters": {
                "type": "object",
                "properties": {
                    "questions": {
                        "type": "array",
                        "description": "List of questions to search for, each with context",
                        "items": {
                            "type": "object",
                            "properties": {
                                "question": {
                                    "type": "string",
                                    "description": "The specific question to answer"
                                },
                                "context": {
                                    "type": "string",
                                    "description": "Additional context about what the user is looking for"
                                }
                            },
                            "required": ["question", "context"]
                        }
                    },
                    "tool_group": {
                        "type": "string",
                        "description": "The tool group to use for searching",
                        "enum": ["general"],
                        "default": "general"
                    }
                },
                "required": ["questions"]
            }
        }

    async def _execute_planner_tool(
        self,
        questions: List[Dict[str, str]],
        tool_group: str = "general"
    ) -> AsyncGenerator[Dict[str, str], None]:
        """
        Execute planner_tool: uses LLM to select tools, then executes them in parallel.

        Yields reasoning events during planning, returns final results.
        """
        yield build_reasoning_event(
            step="Planning",
            reasoning=f"Analyzing {len(questions)} question(s) to determine which tools to use..."
        )

        # Get available tools for this group
        available_tools: List[ToolSchema] = get_tools_by_group(tool_group)
        if not available_tools:
            yield build_reasoning_event(
                step="Planning Error",
                reasoning=f"No tools available for group: {tool_group}"
            )
            return

        # Build tool descriptions for planner
        tool_descriptions = "\n".join([
            f"- {t.name}: {t.description}" for t in available_tools
        ])

        # Build planner prompts (templates live in aio_prompts.py)
        planner_system_prompt = get_planner_system_prompt(
            tool_descriptions=tool_descriptions,
            email=self.state.email,
            member_id=self.state.member_id,
        )

        questions_text = "\n".join([
            f"- Question: {q['question']}\n  Context: {q['context']}"
            for q in questions
        ])

        user_prompt = get_planner_user_prompt(
            questions_text=questions_text,
            email=self.state.email,
            member_id=self.state.member_id,
        )

        messages = [
            ChatMessage(role="system", content=planner_system_prompt),
            ChatMessage(role="user", content=user_prompt)
        ]

        try:
            # Call planner LLM
            planner_start = time()
            response = await self.planner_llm.achat(
                messages,
                response_format={"type": "json_object"}
            )
            planner_time = (time() - planner_start) * 1000

            # Parse tool calls
            content = response.message.content
            try:
                tool_calls = json.loads(content)
                if isinstance(tool_calls, dict) and "tools" in tool_calls:
                    tool_calls = tool_calls["tools"]
                elif not isinstance(tool_calls, list):
                    tool_calls = [tool_calls]
            except json.JSONDecodeError:
                yield build_reasoning_event(
                    step="Planning Error",
                    reasoning="Failed to parse planner response"
                )
                return

            yield build_reasoning_event(
                step="Tools Selected",
                reasoning=f"Selected {len(tool_calls)} tool(s) in {planner_time:.0f}ms: {[tc.get('tool') for tc in tool_calls]}"
            )

            # Execute tools in parallel
            yield build_reasoning_event(
                step="Executing Tools",
                reasoning="Running tools in parallel..."
            )

            exec_start = time()

            async def execute_single_tool(tool_call: Dict) -> Dict[str, Any]:
                tool_name = tool_call.get("tool")
                tool_args = tool_call.get("args", {})
                question = tool_call.get("question", "")

                try:
                    result = await execute_tool(tool_name, **tool_args)
                    return {
                        "tool_name": tool_name,
                        "question": question,
                        "content": result.get("content", ""),
                        "metadata": result.get("metadata", {}),
                        "error": result.get("error")
                    }
                except Exception as e:
                    return {
                        "tool_name": tool_name,
                        "question": question,
                        "error": str(e)
                    }

            # Run all tools in parallel
            results = await asyncio.gather(*[
                execute_single_tool(tc) for tc in tool_calls
            ])

            exec_time = (time() - exec_start) * 1000

            yield build_reasoning_event(
                step="Tools Complete",
                reasoning=f"Executed {len(results)} tool(s) in {exec_time:.0f}ms"
            )

            # Yield results as typed event (consumed by run_stream)
            self.state.tool_results = results
            yield {"_tool_results": results}

        except Exception as e:
            yield build_reasoning_event(
                step="Planner Error",
                reasoning=f"Error in planner: {str(e)}"
            )

    async def run_stream(
        self,
        user_input: str,
        email: Optional[str] = None,
        files: Optional[List[Dict[str, str]]] = None,
        context_type: Optional[str] = None,
        context_id: Optional[str] = None,
        **kwargs
    ) -> AsyncGenerator[Dict[str, str], None]:
        """
        Main execution flow - single AIO Agent call with tools.
        """
        start_time = time()

        # Lazy-load session history (deferred from __init__ to async context)
        if not self._session_loaded and self.session_id and self.supabase:
            await self._load_from_session()
            self._session_loaded = True

        # Update state
        self.state.current_input = user_input

        # Resolve email from member_id if not provided
        if not email and self.member_id and self.supabase:
            try:
                result = self.supabase.schema('public').table('members').select('email').eq("id", self.member_id).execute().data
                if result:
                    email = result[0].get('email')
            except Exception:
                pass

        self.state.email = email
        self.state.add_message(MessageRole.USER, user_input)
        self.state.tool_inputs["email"] = email

        # Save user message via session_mgr (sequence is tracked internally)
        await self.session_mgr.save_message_async(
            role="user",
            content=user_input,
            metadata={"email": email} if email else {},
            files=files
        )

        # --- Workflow state machine: resume in-progress grading flows before anything else ---
        workflow = await self.grading_handler.dispatch_workflow(
            user_input=user_input,
            email=email,
            files=files,
        )
        if workflow is not None:
            async for event in workflow:
                yield event
            return

        # --- Submission hard gate: bypass LLM when submission intent is unambiguous ---
        _input_lower = user_input.lower()
        _SUBMISSION_VERBS = {"submit", "grade", "grading", "submission", "resubmit", "turn in", "hand in"}
        _has_submission_verb = any(kw in _input_lower for kw in _SUBMISSION_VERBS)
        _has_grading_signal = (
            any(kw in _input_lower for kw in GRADING_KEYWORDS)
            or any(kw in _input_lower for kw in ACTION_KEYWORDS)
        )
        _is_challenge_context = context_type == "challenge"
        if (files or (_is_challenge_context and _has_submission_verb)) and _has_grading_signal:
            yield build_reasoning_event(
                step="Processing Submission",
                reasoning=(
                    "Submission detected — routing directly to grading workflow."
                    if files else
                    "Challenge context with submission intent — routing to grading workflow."
                ),
            )
            async for event in self.grading_handler.handle_grading_intent(
                decision=None,
                user_input=user_input,
                email=email,
                files=files,
                context_type=context_type,
                context_id=context_id,
                iteration_start=start_time,
            ):
                yield event
            return

        # Fast-path: check context_type first to bypass all other processing for zero-latency
        if context_type in ["key_learnings"] and context_id:
            fast_path_start = time()
            try:
                prefetch_data = await self.context_prefetcher.fetch_cached(
                    context_type, context_id, cache=self.cache
                )
                if prefetch_data:
                    self.state.context_prefetch = prefetch_data
                    fast_path_time = (time() - fast_path_start) * 1000
                    
                    yield build_reasoning_event(
                        step="Context Loaded",
                        reasoning=f"Loaded {context_type} context (fast-path)"
                    )
                    
                    if context_type == "key_learnings":
                        yield build_timing_event("key_learnings_fast_path", fast_path_time)
                        
                        metadata = prefetch_data.get("metadata", {})
                        yield build_metadata_event({
                            "type": "text",
                            "version": metadata.get("version"),
                            "updated_at": metadata.get("updated_at")
                        })
                        
                    entity_name = prefetch_data.get("name", "Key Learning Highlight")
                    entity_summary = prefetch_data.get("summary", "")
                    if entity_summary:
                        response_text = f"## {entity_name}\n\n{entity_summary}"
                        self.state.add_message(MessageRole.ASSISTANT, response_text)
                        await self.session_mgr.save_message_async(
                            role="assistant",
                            content=response_text,
                            metadata={},
                        )
                        yield build_content_event(response_text)
                        return
            except Exception as e:
                print(f"Fast-path error: {e}")

        # Parallel: fetch context + prefetch at the same time for non-fast-path contexts
        context_tasks = [self.context_registry.get_context(self.state)]
        if context_type and context_id:
            context_tasks.append(self.context_prefetcher.fetch_cached(
                context_type, context_id, cache=self.cache
            ))

        context_results = await asyncio.gather(*context_tasks, return_exceptions=True)

        # Unpack results
        additional_context = context_results[0] if not isinstance(context_results[0], Exception) else ""
        if isinstance(context_results[0], Exception):
            print(f"Context registry error: {context_results[0]}")

        if len(context_results) > 1:
            prefetch_data = context_results[1] if not isinstance(context_results[1], Exception) else None
            if isinstance(context_results[1], Exception):
                print(f"Prefetch error: {context_results[1]}")
            if prefetch_data:
                self.state.context_prefetch = prefetch_data
                yield build_reasoning_event(
                    step="Context Loaded",
                    reasoning=f"Loaded {context_type} context"
                )

        # Build system prompt
        system_prompt = self._get_aio_system_prompt(additional_context)

        # Add file info if present
        file_info = ""
        if files:
            file_info = f"\n\n[User uploaded {len(files)} file(s): {', '.join(f.get('filename', 'file') for f in files)}]"

        # Build messages list with sliding window over conversation history
        # (no embedded history string — use the messages list exclusively)
        messages = [
            ChatMessage(role="system", content=system_prompt),
        ]

        # Add recent conversation history (sliding window of last 10 messages)
        recent_history = self.state.messages[-10:]
        for msg in recent_history[:-1]:  # Exclude the current user message (added below)
            messages.append(ChatMessage(role=msg.role.value, content=msg.content))

        # Add current user message
        user_message = f"{user_input}{file_info}\n\nAnswer the user's question. Use tools if you need to search for information or grade an assignment."
        messages.append(ChatMessage(role="user", content=user_message))

        # Define tools for AIO Agent — DB query only; grading is handled by the pre-LLM gate
        tools = [
            circle_db_query_tool.to_openrouter_tool_schema(),
        ]

        yield build_reasoning_event(
            step="Processing",
            reasoning="Analyzing your question..."
        )

        try:
            # Force tool call when user asks about domain-specific entities
            domain_terms = DOMAIN_KNOWLEDGE_INDICATORS.get("general", set())
            requires_tool = (
                any(kw in user_input.lower() for kw in domain_terms)
                and not self.state.context_prefetch
            )

            # Call AIO Agent with tools
            response = await self.aio_llm.achat(
                messages,
                tools=tools,
                tool_choice="required" if requires_tool else "auto",
            )

            # Debug: log full response
            print(f"[AIO] achat response content: {response.message.content[:200] if response.message.content else 'None'}")
            print(f"[AIO] achat response additional_kwargs: {response.message.additional_kwargs}")

            # Check for tool calls
            tool_calls = response.message.additional_kwargs.get("tool_calls", [])

            if tool_calls:
                # Append the assistant message with tool_calls (required by OpenRouter)
                messages.append(ChatMessage(
                    role="assistant",
                    content=response.message.content or "",
                    additional_kwargs={"tool_calls": tool_calls}
                ))

                # Execute each tool call and append results as role="tool"
                for tool_call in tool_calls:
                    func = tool_call.get("function", {})
                    tool_name = func.get("name")
                    tool_call_id = tool_call.get("id", "")
                    tool_args = json.loads(func.get("arguments", "{}"))

                    tool_result_str = "No results found."

                    if tool_name == "circle_ai_officer_database_query":
                        # Direct DB tool execution — no planner sub-LLM
                        yield build_reasoning_event(
                            step="Querying Database",
                            reasoning=f"Searching {tool_args.get('resource', 'data')}..."
                        )
                        try:
                            result = await execute_tool(tool_name, **tool_args)
                            tool_results = [{"tool_name": tool_name, "content": result.get("content", ""), "metadata": result.get("metadata", {})}]
                            self.state.tool_results = tool_results
                            tool_result_str = format_for_llm(tool_results, True)
                        except Exception as e:
                            print(f"[AIO] Tool execution error: {e}")
                            tool_result_str = f"Error executing query: {str(e)}"

                    # Append tool result as role="tool" message
                    messages.append(ChatMessage(
                        role="tool",
                        content=tool_result_str,
                        additional_kwargs={"tool_call_id": tool_call_id, "name": tool_name}
                    ))

                # Stream final response
                print(f"[AIO] Streaming final response with tool results...")
                chunk_count = 0
                response_content = ""
                async for chunk in self.aio_llm.astream_chat(messages):
                    if chunk.delta:
                        chunk_count += 1
                        response_content += chunk.delta
                        yield build_content_event(chunk.delta)
                print(f"[AIO] Streamed {chunk_count} chunks")

                # If still empty after streaming, provide a fallback response
                if not response_content.strip():
                    print(f"[AIO] Empty response after tool use, using fallback...")
                    response_content = "I found some information but had trouble summarizing it. Could you try asking your question differently?"
                    yield build_content_event(response_content)

                # Save assistant response and add to history
                self.state.add_message(MessageRole.ASSISTANT, response_content)
                await self.session_mgr.save_message_async(
                    role="assistant",
                    content=response_content,
                    metadata={"model": self.aio_llm.model, "used_tools": True},
                )
                await self.session_mgr.flush_pending()

            else:
                # No tool calls - use the response from achat directly
                response_content = response.message.content or ""
                print(f"[AIO] No tool calls, using achat response directly...")
                print(f"[AIO] Response content: {response_content[:200] if response_content else 'None'}...")

                # If no content, something went wrong - make a retry call without tools
                if not response_content.strip():
                    print(f"[AIO] Empty response, retrying without tools...")
                    retry_response = await self.aio_llm.achat(messages)
                    response_content = retry_response.message.content or ""
                    print(f"[AIO] Retry response: {response_content[:200] if response_content else 'Still None'}")

                # If still empty, provide a fallback response
                if not response_content.strip():
                    response_content = "I'm sorry, I don't know how to help with that. Could you try asking your question differently, or let me know what specific information you're looking for?"
                    print(f"[AIO] Using fallback response")

                # Yield content as a single event
                yield build_content_event(response_content)

                # Save assistant response and add to history
                self.state.add_message(MessageRole.ASSISTANT, response_content)
                await self.session_mgr.save_message_async(
                    role="assistant",
                    content=response_content,
                    metadata={"model": self.aio_llm.model, "used_tools": False},
                )
                await self.session_mgr.flush_pending()

            total_time = (time() - start_time) * 1000
            yield build_reasoning_event(
                step="Complete",
                reasoning=f"Response generated in {total_time:.0f}ms"
            )

            # After response is done, check if mid-session title refinement fired
            if self.session_mgr._titling_task:
                print("[AIO] Waiting for titling task to complete...", flush=True)
                try:
                    new_title = await asyncio.wait_for(self.session_mgr._titling_task, timeout=5.0)
                    if new_title:
                        print(f"[AIO] Sending session_updated metadata with title: {new_title}", flush=True)
                        from agents.systems.response_types import MetadataType
                        yield build_metadata_event({
                            "type": MetadataType.SESSION_UPDATED.value,
                            "session_id": self.session_id,
                            "title": new_title
                        })
                except Exception as te:
                    print(f"[AIO] Titling task await failed or timed out: {te}", flush=True)

        except Exception as e:
            yield build_error_event(f"Error: {str(e)}")

    async def create_session(
        self,
        title: str,
        context_type: str = "general",
        context_id: Optional[str] = None
    ) -> Optional[str]:
        """Create a new chat session via SessionManager."""
        session_id = await self.session_mgr.create_session(
            title=title,
            context_type=context_type,
            context_id=context_id,
        )
        if session_id:
            self.session_id = session_id
            self.grading_handler.session_id = session_id
        return session_id

    async def _load_from_session(self):
        """Load conversation history and workflow state from session."""
        if not self.supabase or not self.session_id:
            return
        try:
            messages, workflow_state, _session_metadata = self.session_mgr.load_messages()
            for msg in messages:
                self.state.add_message(MessageRole(msg["role"]), msg["content"])
            if workflow_state:
                self.state.workflow_state = workflow_state
            if messages:
                print(f"[AIO] Loaded {len(messages)} messages from session")
            # session_mgr._sequence is synced inside load_messages()
        except Exception as e:
            print(f"Failed to load session: {e}")

    async def generate_title(self, user_input: str) -> str:
        """Generate an AI title for a new session from the first user message.

        Called from chat.py before create_session().
        """
        try:
            prompt = get_session_titling_prompt(user_input, is_initial=True)
            response = await self.planner_llm.achat([ChatMessage(role="user", content=prompt)])
            new_title = response.message.content.strip().strip('"').strip("'").strip()
            if ":" in new_title and len(new_title.split(":")[0]) < 10:
                new_title = new_title.split(":", 1)[1].strip()
            print(f"[AIO] Initial title: {new_title}", flush=True)
            return new_title if new_title else user_input[:50]
        except Exception as e:
            print(f"[AIO] Initial titling failed: {e}", flush=True)
            return user_input[:50]

    async def _build_refined_title(self) -> str:
        """Build a refined title from recent chat history.

        Registered as session_mgr._title_callback — called automatically
        by SessionManager at sequence 9. SessionManager.update_title() saves it.
        """
        try:
            context = ""
            for msg in self.state.messages[-10:]:
                context += f"{msg.role.value}: {msg.content[:200]}...\n"
            prompt = get_session_titling_prompt(context, is_initial=False)
            response = await self.planner_llm.achat([ChatMessage(role="user", content=prompt)])
            new_title = response.message.content.strip().strip('"').strip("'").strip()
            if ":" in new_title and len(new_title.split(":")[0]) < 10:
                new_title = new_title.split(":", 1)[1].strip()
            print(f"[AIO] Refined title: {new_title}", flush=True)
            return new_title
        except Exception as e:
            print(f"[AIO] Refined titling failed: {e}", flush=True)
            return ""

    def get_history(self) -> List[Dict[str, str]]:
        """Get conversation history."""
        return [
            {"role": msg.role.value, "content": msg.content}
            for msg in self.state.messages
        ]
