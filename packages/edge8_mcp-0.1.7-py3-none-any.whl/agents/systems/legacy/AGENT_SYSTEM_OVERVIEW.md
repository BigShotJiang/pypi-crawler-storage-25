# AgentSystem - Executive Overview

Modular, context-aware orchestrator that routes user requests through specialized agents. Uses a 2-stage Tool Agent (Planning + Execution) for efficient tool selection and execution. Integrates pluggable context providers, Redis caching, and specialized grading workflow. Supports streaming output and session persistence.

## Core Architecture

```mermaid
graph TB
    User["User Input<br/>+ Files"] --> State["Update State<br/>(Add Message)"]
    State --> ContextProviders["Context Providers<br/>(AIO, Student, Prefetch)"]
    ContextProviders --> Router["Router Agent<br/>(Intent Detection)"]
    
    Router -->|TOOL Intent| ToolAgent["Tool Agent<br/>(2-Stage Planning<br/>+ Execution)"]
    Router -->|CHAT Intent| AnsweringAgent["Answering Agent<br/>(Response Generation)"]
    Router -->|GRADING Intent| GradingWorkflow["Grading Workflow<br/>(Scorer + Reflector)"]
    
    ToolAgent --> UpdateState["Update State<br/>(Tool Results)"]
    UpdateState --> CheckStatus{"Status =<br/>FINISHED?"}
    CheckStatus -->|No| Router
    CheckStatus -->|Yes| AnsweringAgent
    
    AnsweringAgent --> StreamResponse["Stream Response<br/>(content events)"]
    GradingWorkflow --> StreamGrading["Stream Grading<br/>(grading_response)"]
    
    StreamResponse --> User
    StreamGrading --> User
    
    Redis[("Redis Cache<br/>(Student Data,<br/>Router Decisions)")] -.->|Cache| Router
    Redis -.->|Cache| AnsweringAgent
    Supabase[("Supabase<br/>(Session<br/>Persistence)")] -.->|Save| State
    
    style Router fill:#87CEEB
    style ToolAgent fill:#87CEEB
    style AnsweringAgent fill:#87CEEB
    style GradingWorkflow fill:#FFD700
    style ContextProviders fill:#98FB98
    style User fill:#90EE90
    style Redis fill:#FFA07A
    style Supabase fill:#DDA0DD
```

## Execution Flow

```mermaid
graph TB
    Start["User Input<br/>+ Email + Files"] --> InitState["Update State<br/>(Add User Message)"]
    InitState --> SaveSession{"Auto-save<br/>enabled?"}
    SaveSession -->|Yes| SaveMsg["Save to Supabase<br/>(agents.chat_sessions)"]
    SaveSession -->|No| Prefetch
    SaveMsg --> Prefetch
    
    Prefetch{"Context<br/>pre-fetch?"} -->|Yes| FetchContext["Fetch Entity Data<br/>(Challenge/Mission/etc)"]
    Prefetch -->|No| Loop
    FetchContext --> Loop
    
    Loop["Loop: Until Finished<br/>(Max 3 iterations)"] --> GetContext["Get Context from<br/>Providers"]
    GetContext --> Router["Router: Decide Intent<br/>(TOOL/CHAT/GRADING)<br/>+ Status"]
    
    Router -->|TOOL + CONTINUE| ToolPath["Tool Agent:<br/>Stage 1: Plan<br/>Stage 2: Execute"]
    Router -->|CHAT + FINISHED| ChatPath["Answering Agent:<br/>Generate Response"]
    Router -->|GRADING| GradingPath["Grading Workflow:<br/>Scorer + Reflector"]
    
    ToolPath --> StoreResults["Store Tool Results<br/>in State"]
    StoreResults --> CheckIter{"Iteration < 3<br/>AND<br/>Status = CONTINUE?"}
    
    CheckIter -->|Yes| Loop
    CheckIter -->|No| ChatPath
    
    ChatPath --> StreamResp["Stream Response<br/>(content events)"]
    GradingPath --> StreamGrade["Stream Grading<br/>(grading_response)"]
    
    StreamResp --> SaveAssistant["Save Assistant<br/>Message"]
    StreamGrade --> SaveAssistant
    SaveAssistant --> End["Return to User"]
    
    style Start fill:#E8F4F8
    style Router fill:#87CEEB
    style ToolPath fill:#87CEEB
    style ChatPath fill:#87CEEB
    style GradingPath fill:#FFD700
    style GetContext fill:#98FB98
    style End fill:#90EE90
```

## Tool Agent 2-Stage Cycle

```mermaid
graph TB
    A["Tool Intent<br/>Detected"] --> B["Get Tool Schemas<br/>(by group from state)"]
    B --> Stage1["Stage 1: Planning"]
    
    Stage1 --> C["LLM Call with<br/>Tool Descriptions<br/>(Cached)"]
    C --> D["Generate:<br/>- Custom System Prompt<br/>- Selected Tool Names"]
    
    D --> Stage2["Stage 2: Execution"]
    Stage2 --> E["LLM Call with<br/>Custom System Prompt<br/>(Cached)"]
    E --> F["LLM Returns<br/>Tool Calls"]
    
    F --> G["Execute Tools<br/>via Handlers"]
    G --> H{"All Tools<br/>Succeeded?"}
    
    H -->|Yes| I["Store Results<br/>in State"]
    H -->|Partial/No| J["Store Results<br/>+ Errors"]
    
    I --> K["Return to Router"]
    J --> K
    
    Cache[("Prompt Cache<br/>(Tool Descriptions,<br/>System Prompts)")] -.->|Cache| C
    Cache -.->|Cache| E
    
    style A fill:#E8F4F8
    style Stage1 fill:#FFE4B5
    style Stage2 fill:#FFE4B5
    style C fill:#87CEEB
    style E fill:#87CEEB
    style K fill:#90EE90
    style Cache fill:#FFA07A
```

## Key Components

### Router Agent (Orchestrator)
- Analyzes user input and conversation history
- Determines intent: TOOL, CHAT, or GRADING
- Decides if task is FINISHED or needs CONTINUE
- Selects appropriate tool group
- Hybrid follow-up detection (keyword + semantic)
- Integrates context from providers (AIO, Student, Prefetch)
- Supports Redis caching for repeated queries
- Enforces max iteration limits for performance

### Tool Agent (2-Stage Executor)
- **Stage 1 (Planning)**: Selects relevant tools and generates custom system prompt
- **Stage 2 (Execution)**: Executes tools with optimized context
- Uses prompt caching for efficiency (tool descriptions + system prompts)
- Handles tool parameter extraction and validation
- Processes tool results and errors

### Context Providers (Pluggable System)
- **AIOGuidelinesProvider**: Injects AIO program guidelines for circle_aio tool group
- **StudentContextProvider**: Adds student progress, enrollments, and submissions
- **PrefetchContextProvider**: Uses pre-loaded entity context (challenges, missions, etc.)
- **ContextRegistry**: Manages provider registration and execution order
- Providers are called before Router and Answering agents

### Answering Agent (Synthesizer)
- Generates natural language responses
- Supports streaming output
- Uses conversation history for context
- Polishes raw executor outputs into human-readable format

### Grading Workflow (Specialized System)
- **Dual-agent architecture**: Scorer (objective evaluation) + Reflector (student-friendly feedback)
- **Prior-check**: Detects duplicate submissions and existing passes
- **Challenge type-aware**: Different grade_status logic for mission vs mission_final
- **Circle integration**: Posts grading results to Circle community
- **Streaming support**: Yields grading events in real-time
- **File processing**: Handles PDF, images, and text submissions

## State Management

**Per-Turn State Reset**
- `intent`: Cleared each turn
- `tool_call`: Cleared each turn
- `tool_results`: Cleared each turn
- `final_response`: Cleared each turn
- `error`: Cleared each turn

**Persistent State**
- `messages`: Conversation history
- `current_input`: Current user input
- `status`: Current execution status

## Streaming Output

Events yielded to client:
- `reasoning`: Router decision and intermediate thoughts
- `content`: Streamed response chunks
- `grading_response`: Grading workflow results

## Configuration

**LLM Models**
- `router_llm`: Fast model for routing (arcee-ai/trinity-mini:nitro)
- `tool_llm`: Fast model for tool selection (arcee-ai/trinity-mini:nitro)
- `intent_verification_llm`: Fast model for intent verification (arcee-ai/trinity-mini:nitro)
- `writing_llm`: Stronger model for response generation (google/gemini-2.5-flash-lite:nitro)

**Tool Groups**
- Configurable at initialization
- Filtered by router decision
- Passed to tool agent for selection

**Context**
- Optional conversation history
- Pre-populated into state on init
- Context providers inject additional data
- Pre-fetch support for entity-specific context
- Redis caching for student data (5 min TTL)

## Error Handling

- Tool execution failures captured and stored
- Errors prevent infinite loops
- Exception messages yielded to client
- State error field tracks failures

## Usage

```python
# Initialize with session management
agent_system = AgentSystem(
    tool_groups=["circle_aio"],
    member_id=123,
    session_id="session_abc",
    auto_save=True,
    prompt_logger=logger
)

# Execute (non-streaming)
response = await agent_system.run("What missions should I complete?")

# Execute (streaming with context pre-fetch)
async for event in agent_system.run_stream(
    user_input="Tell me about Mission 1",
    email="student@example.com",
    files=[{"url": "...", "name": "file.pdf"}],
    context_type="challenge",
    context_id="challenge_uuid_123"
):
    if event["event"] == "content":
        print(event["data"], end="")
    elif event["event"] == "grading_response":
        print(f"Score: {event['data']['score']}")

# Get history
history = agent_system.get_history()
```

## Design Patterns

- **2-Stage Tool Execution**: Planning (tool selection + prompt generation) → Execution (tool calls)
- **Agentic Loop**: Router → Tool Agent → Update State → Router (max 3 iterations)
- **Context Injection**: Pluggable providers inject data before agent calls
- **Prompt Caching**: Tool descriptions and system prompts cached for efficiency
- **Streaming**: Yield events as they occur for real-time feedback
- **State Isolation**: Per-turn reset prevents cross-request contamination
- **Graceful Degradation**: Tool failures don't crash system
- **Modular Agents**: Each agent handles specific responsibility
- **Hybrid Detection**: Keyword fast-path + LLM semantic fallback for follow-ups
- **Session Persistence**: Auto-save messages to Supabase for conversation continuity
- **Redis Caching**: Student data and router decisions cached for performance

## Architecture Benefits

**Performance**
- Redis caching reduces database load (student data cached 5 min)
- Prompt caching reduces LLM costs (tool descriptions + system prompts)
- Max iteration limits prevent infinite loops
- Hybrid follow-up detection (keyword fast-path)

**Context Awareness**
- Pluggable providers inject relevant data automatically
- Pre-fetch support for entity-specific context
- Platform-specific role adaptation (e.g., AI Buddy for AIO)
- Student progress and enrollment tracking

**Modularity**
- Easy to add new context providers
- Tool groups isolate platform-specific tools
- Specialized grading workflow for assignments
- Session persistence for conversation continuity

**Resilience**
- 2-stage tool execution reduces hallucination
- Tool failures captured and reported
- Iteration limits prevent runaway loops
- Graceful degradation on cache/DB failures

**Trade-offs**
- **Latency**: 2-stage tool execution + context providers add overhead
- **Complexity**: More moving parts (cache, DB, providers)
- **Best for**: Educational chatbots, assignment grading, student support
- **Not ideal for**: Simple Q&A, real-time voice chat
