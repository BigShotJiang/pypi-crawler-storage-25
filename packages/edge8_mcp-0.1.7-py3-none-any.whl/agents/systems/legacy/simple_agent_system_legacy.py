from typing import AsyncGenerator, Optional, List, Dict, Any
import os
import sys
import asyncio
import json
from datetime import datetime
from time import time
from dotenv import load_dotenv

# Add project root to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from connectors.openrouter.llm import OpenRouterMultimodalLLM
from agents.tools.shared import LLMPdfExtractor
from agents.tools.handlers import execute_tool
from agents.tools.schema import get_tools_by_group
from agents.systems.shared import AgentState, MessageRole, AgentIntent, AgentStatus
from agents.subagents.router_agent import RouterAgent
from agents.subagents.tool_agent import ToolAgent
from agents.subagents.answering_agent import AnsweringAgent
from agents.subagents.intent_verification_agent import IntentVerificationAgent
from agents.systems.grading_system.optimized_grading_workflow import OptimizedGradingWorkflow as GradingWorkflow  # Optimized workflow for testing
from agents.tools.preprocessing.entity_resolver import EntityResolver, ResolvedQuery
from agents.tools.database.aio.aio import DatabaseToolHandler
from agents.context.prefetcher import ContextPrefetcher
from agents.systems.response_types import (
    build_content_event,
    build_reasoning_event,
    build_error_event,
    build_metadata_event,
    build_timing_event,
    build_timing_metadata,
    transform_grading_response,
    transform_tool_results,
    MetadataType,
    ChatMetadata,
)
from connectors.supabase_client.createClient import get_custom_client
from utils.data_conversion import get_mime_type_from_filename

load_dotenv()

# Try to import upstash-redis for caching
try:
    from upstash_redis import Redis
    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False
    print("⚠️  upstash-redis not installed - caching disabled")

# Maximum iterations before forcing answering flow
MAX_ITERATIONS = 3

# Domain knowledge indicators for anti-hallucination guard
# Maps tool groups to domain-specific keywords that require grounding
DOMAIN_KNOWLEDGE_INDICATORS: dict[str, set[str]] = {
    # Future platforms can add their own domain terms
}

def _requires_domain_knowledge(user_input: str, tool_groups: list[str] | None = None) -> tuple[bool, str | None]:
    """Check if user input requires domain-specific knowledge.

    Args:
        user_input: The user's input text
        tool_groups: List of active tool groups to check against

    Returns:
        Tuple of (requires_grounding, matched_tool_group)
    """
    input_lower = user_input.lower()
    groups_to_check = tool_groups or []

    for group in groups_to_check:
        indicators = DOMAIN_KNOWLEDGE_INDICATORS.get(group, set())
        for indicator in indicators:
            if indicator in input_lower:
                return True, group

    return False, None

# --- Orchestrator ---

class AgentSystem:
    def __init__(
        self, 
        tool_groups: List[str] = None, 
        context: List[dict] = None,
        session_id: Optional[str] = None,
        member_id: Optional[int] = None,
        auto_save: bool = True,
        prompt_logger = None
    ):
        api_key = os.environ.get("OPENROUTER_API_KEY")
        if not api_key:
            raise ValueError("OPENROUTER_API_KEY not found in environment variables")
            
        # Fast models for routing/tool selection with fallbacks for provider resilience.
        # Primary: arcee-ai/trinity-mini:nitro (fast, cheap). Fallbacks triggered on 524/timeout.
        _fast_model_with_fallbacks = [
            "arcee-ai/trinity-mini:nitro",
            "arcee-ai/trinity-mini",         # Same model, any provider (not nitro-locked)
            "google/gemini-2.5-flash-lite",    # Fast, reliable fallback
        ]

        self.router_llm = OpenRouterMultimodalLLM(
            api_key=api_key,
            fallback_models=_fast_model_with_fallbacks,
            temperature=0.1,
        )
        
        self.tool_llm = OpenRouterMultimodalLLM(
            api_key=api_key,
            fallback_models=_fast_model_with_fallbacks,
            temperature=0.1,
        )
        
        self.intent_verification_llm = OpenRouterMultimodalLLM(
            api_key=api_key,
            fallback_models=_fast_model_with_fallbacks,
            temperature=0.1,
        )

        self.writing_llm = OpenRouterMultimodalLLM(
            api_key=api_key,
            model="google/gemini-2.5-flash-lite:nitro",
            temperature=0.2,
        )
        
        self.llm_pdf_extractor = LLMPdfExtractor()
        
        # Initialize Redis cache BEFORE creating agents
        self.cache = None
        self._cache_ttl = 600  # 10 minutes
        if REDIS_AVAILABLE:
            redis_url = os.getenv("UPSTASH_REDIS_URL")
            redis_token = os.getenv("UPSTASH_REDIS_TOKEN")
            if redis_url and redis_token:
                try:
                    self.cache = Redis(url=redis_url, token=redis_token)
                    print("✅ Redis cache initialized")
                except Exception as e:
                    print(f"⚠️  Redis cache initialization failed: {e}")
            else:
                print("⚠️  UPSTASH_REDIS_URL or UPSTASH_REDIS_TOKEN not set - caching disabled")
        
        self._cache_warned = False  # Suppress repeated cache error logs
        
        # Store prompt logger
        self.prompt_logger = prompt_logger
        
        # Initialize agents with cache support and prompt logger
        self.router = RouterAgent(self.router_llm, tool_groups, cache_client=self.cache, prompt_logger=prompt_logger)
        self.tool_agent = ToolAgent(self.tool_llm, prompt_logger=prompt_logger)
        self.answering_agent = AnsweringAgent(self.writing_llm, cache_client=self.cache, prompt_logger=prompt_logger)
        self.intent_verifier = IntentVerificationAgent(self.intent_verification_llm)
        self.state = AgentState()
        self.state.tool_groups = tool_groups  # Store tool_groups in state for context providers
        self.state.member_id = member_id  # Store member_id for student context
        self.state.tool_inputs = { "member_id": member_id }
        
        # Session management
        self.session_id = session_id
        self.member_id = member_id
        self.auto_save = auto_save
        self.supabase = None
        # Initialize Supabase client
        try:
            url = os.getenv("AIO_SUPABASE_URL")
            key = os.getenv("AIO_SUPABASE_SERVICE_ROLE_KEY")
            if url and key:
                self.supabase = get_custom_client(url, key, {"schema": "agents"})
        except Exception as e:
            print(f"Warning: Failed to initialize Supabase for session management: {e}")

        # Batch auto-save tracking
        self._pending_saves = []
        self._save_flush_interval = 2.0  # seconds
        self._last_flush = time()

        # Initialize database tool with cache support
        self.database_tool = DatabaseToolHandler(cache_client=self.cache)
        
        # Initialize ContextPrefetcher for entity context preloading
        self.context_prefetcher = ContextPrefetcher(self.database_tool)
        
        # Initialize EntityResolver for entity-resolution-driven routing (Phase 2A/2B)
        self.entity_resolver = EntityResolver(self.database_tool)

        # Load from session if session_id provided
        if session_id and self.supabase:
            self._load_from_session()
        elif context:
            for msg in context:
                self.state.add_message(MessageRole(msg["role"]), msg["content"])

    async def _get_student_context_cached(self, email: str) -> Dict[str, Any]:
        """Get student context with Redis caching

        Args:
            email: Student email address

        Returns:
            Dict containing student, enrollments, and progress data
        """
        if not self.cache:
            return await self._fetch_student_context(email)

        cache_key = f"student_context:{email}"

        # Try cache first
        try:
            cached = self.cache.get(cache_key)
            if cached:
                print(f"📦 Student context cache HIT: {email}")
                return json.loads(cached)
        except Exception as e:
            print(f"⚠️  Cache read error: {e}")

        # Cache miss - fetch from DB
        print(f"🔍 Student context cache MISS: {email}")
        context = await self._fetch_student_context(email)

        # Cache for 5 minutes (student data changes infrequently)
        try:
            self.cache.setex(cache_key, 300, json.dumps(context))
            print(f"💾 Cached student context: {email}")
        except Exception as e:
            print(f"⚠️  Cache write error: {e}")

        return context

    async def _fetch_student_context(self, email: str) -> Dict[str, Any]:
        """Fetch student data from database

        Args:
            email: Student email address

        Returns:
            Dict containing student, enrollments, and progress data
        """
        try:
            student_data, enrollment_data, progress_data = await asyncio.gather(
                self.database_tool.execute(resource="students", email=email),
                self.database_tool.execute(resource="enrollments", email=email),
                self.database_tool.execute(resource="student_progress", email=email),
            )
            return {
                "student": student_data,
                "enrollments": enrollment_data,
                "progress": progress_data,
                "cached_at": datetime.now().isoformat()
            }
        except Exception as e:
            print(f"❌ Error fetching student context: {e}")
            return {
                "student": None,
                "enrollments": None,
                "progress": None,
                "error": str(e)
            }

    async def run(self, user_input: str) -> str:
        """Main execution loop (non-streaming wrapper)."""
        full_response = ""
        try:
            async for chunk in self.run_stream(user_input):
                full_response += chunk
            return full_response
        except Exception as e:
            self.state.error = str(e)
            print(f"Error in run: {e}")
            return str(e)

    async def run_stream(
        self,
        user_input: str,
        email: Optional[str] = None,
        files: Optional[list[dict[str, str]]] = None,
        with_post: Optional[bool] = False,
        context_type: Optional[str] = None,
        context_id: Optional[str] = None,
    ) -> AsyncGenerator[dict[str, str], None]:
        iteration_start = time()
        print(f"\n{'='*60}")
        print(f"🚀 Starting agent iteration at {datetime.now().strftime('%H:%M:%S.%f')[:-3]}")
        print(f"{'='*60}")
        """Main execution loop with streaming."""
        
        # 1. Update State with User Input
        self.state.current_input = user_input
        self.state.add_message(MessageRole.USER, user_input)
        
        # Resolve email from member_id in parallel with saving the user message
        async def _resolve_email():
            if email is not None or not self.state.member_id or not self.supabase:
                return email
            try:
                member = (
                    self.supabase
                    .schema('public')
                    .table('members')
                    .select('email')
                    .eq("id", self.state.member_id)
                    .execute()
                ).data
                if member and len(member) > 0:
                    return member[0].get('email')
            except Exception:
                pass
            return None

        async def _save_user_message():
            if self.auto_save and self.session_id:
                user_metadata = {"email": email} if email else {}
                await self._save_message_to_session_async(
                    role="user",
                    content=user_input,
                    metadata=user_metadata,
                    files=files
                )

        email, _ = await asyncio.gather(_resolve_email(), _save_user_message())
        yield build_timing_event("email_resolve_and_save", (time() - iteration_start) * 1000)

        # Reset per-turn state
        self.state.intent = None
        self.state.tool_call = None
        self.state.tool_results = None
        self.state.final_response = None
        self.state.error = None
        self.state.iteration_count = 0
        self.state.tool_inputs["email"] = email
        self.state.email = email  # Store email for student context providers
        self._session_context_type = context_type  # Track session context type for Phase 5A

        # STEP 1.5: Pre-fetch context if context_id provided
        prefetch_timing_emitted = False
        if context_type and context_id:
            try:
                prefetcher = ContextPrefetcher(self.intent_verifier.db_handler)
                prefetch_start = time()
                
                # Check Redis cache first
                prefetch_data = None
                cache_key = f"prefetch:{context_type}:{context_id}"
                if self.cache:
                    try:
                        cached = self.cache.get(cache_key)
                        if cached:
                            prefetch_data = json.loads(cached)
                            print(f"📦 Prefetch cache HIT: {cache_key}")
                    except Exception as e:
                        if not self._cache_warned:
                            # print(f"⚠️  Prefetch cache unavailable: {e}")
                            self._cache_warned = True
                
                if prefetch_data is None:
                    prefetch_data = await prefetcher.fetch(context_type, context_id)
                    
                    # Cache the result
                    if prefetch_data and self.cache:
                        try:
                            # Static content: 1 hour, dynamic: 5 min
                            static_types = {"challenge", "mission", "brief", "series", "workshop"}
                            ttl = 3600 if context_type in static_types else 300
                            self.cache.setex(cache_key, ttl, json.dumps(prefetch_data))
                            # print(f"💾 Cached prefetch: {cache_key} (TTL={ttl}s)")
                        except Exception as e:
                            if not self._cache_warned:
                                print(f"⚠️  Prefetch cache unavailable: {e}")
                                self._cache_warned = True
                
                if prefetch_data:
                    self.state.context_prefetch = prefetch_data
                    context_summary = prefetcher.format_for_prompt(context_type, prefetch_data)
                    self.state.add_message(
                        MessageRole.SYSTEM,
                        f"[Pre-loaded context: {context_type}]\n{context_summary}"
                    )
                    prefetch_time = time() - prefetch_start
                    # print(f"⏱️  Context prefetch ({context_type}): {prefetch_time*1000:.1f}ms")
                    yield build_reasoning_event(
                        step="Context Loaded",
                        reasoning=f"Loaded {context_type} context for quick reference."
                    )
                    prefetch_timing_emitted = True
                else:
                    # print(f"⚠️  No prefetch data for {context_type}:{context_id}")
                    pass
            except Exception as e:
                # Non-fatal: if prefetch fails, continue without it
                # print(f"⚠️  Context prefetch failed ({context_type}:{context_id}): {e}")
                pass
            finally:
                # Only emit timing if prefetch was actually attempted
                if prefetch_timing_emitted:
                    yield build_timing_event("context_prefetch", (time() - prefetch_start) * 1000)

        # STEP 2: Add file metadata to state for RouterAgent
        extraction_task = None
        if files:
            file_metadata = self._extract_file_metadata(files)
            self.state.tool_inputs["file_metadata"] = file_metadata
            
            # Add metadata to conversation context (RouterAgent needs to see this)
            metadata_summary = self._format_file_metadata_summary(file_metadata)
            self.state.add_message(
                MessageRole.SYSTEM,
                f"[User uploaded {len(files)} file(s)]\n{metadata_summary}"
            )
            
            # STEP 3: Start file extraction in parallel (non-blocking)
            if self._is_question_about_files(user_input, files):
                extraction_task = asyncio.create_task(
                    self._extract_or_prepare_files(files)
                )

        # STEP 2.5: Deterministic shortcut — skip Router if prefetch answers the question
        # If we have prefetched context and the user is asking an informational question
        # (not a submission/grading action), go straight to AnsweringAgent.
        if self.state.context_prefetch and not files:
            _action_keywords = {
                "submit", "grade", "grading", "submission", "resubmit",
                "upload", "turn in", "hand in", "post my", "post it",
            }
            input_lower = user_input.lower()
            is_action_request = any(kw in input_lower for kw in _action_keywords)

            if not is_action_request:
                # print(f"⚡ Prefetch shortcut: skipping Router (informational question with pre-loaded context)")
                yield build_reasoning_event(
                    step="Direct Answer",
                    reasoning="Answering from pre-loaded context — no additional tools needed."
                )

                # Go straight to answering
                response_content = ""
                ans_start = time()
                async for chunk in self.answering_agent.astream_answer(self.state):
                    response_content += chunk
                    yield build_content_event(chunk)
                    # Emit timing on first chunk only
                    if ans_start > 0:
                        yield build_timing_event("answering_first_chunk", (time() - ans_start) * 1000)
                        ans_start = 0  # Reset to mark as emitted

                yield build_timing_event("iteration_complete", (time() - iteration_start) * 1000, {"shortcut": "prefetch"})

                self.state.final_response = response_content
                self.state.add_message(MessageRole.ASSISTANT, response_content)

                if self.auto_save and self.session_id:
                    assistant_metadata = {
                        "model": self.writing_llm.model,
                        "prefetch_shortcut": True,
                        "context_type": context_type,
                    }
                    await self._save_message_to_session_async(
                        role="assistant",
                        content=response_content,
                        metadata=assistant_metadata
                    )

                # Final flush
                if self._pending_saves:
                    await self._flush_pending_saves()

                # iteration_time = time() - iteration_start
                # print(f"\n{'='*60}")
                # print(f"✅ Iteration complete (prefetch shortcut): {iteration_time*1000:.1f}ms")
                # print(f"{'='*60}\n")
                return

        # print(f"\n--- New Turn: {user_input} ---")

        # Check if we're in a workflow state
        if self.state.workflow_state:
            workflow_type = self.state.workflow_state.get("type")

            # Escape hatch: explicit cancel keywords clear workflow state
            cancel_keywords = {"cancel", "stop", "nevermind", "never mind", "forget it", "abort", "quit", "exit"}
            if user_input.lower().strip() in cancel_keywords:
                cancel_msg = "Workflow cancelled. How can I help you?"
                self.state.workflow_state = None
                self.state.add_message(MessageRole.ASSISTANT, cancel_msg)
                if self.auto_save and self.session_id:
                    await self._save_message_to_session_async(
                        role="assistant",
                        content=cancel_msg,
                        metadata={"type": "workflow_cancelled", "workflow_state": None}
                    )
                yield build_content_event(cancel_msg)
                # Final flush
                if self._pending_saves:
                    await self._flush_pending_saves()
                return

            grading_workflow = GradingWorkflow()
            
            # Flush pending user message before workflow handlers to ensure
            # correct sequence_number ordering (user msg must precede grading results)
            if self._pending_saves:
                await self._flush_pending_saves()

            # Handle mission confirmation workflow
            if workflow_type == "mission_confirmation_pending":
                submission_metadata = self.state.workflow_state.get("submission_metadata")
                stored_circle_urls = self.state.workflow_state.get("circle_file_urls", [])
                effective_circle_urls = circle_file_urls or stored_circle_urls
                
                # Update submission_metadata with latest files/content from this turn
                if submission_metadata:
                    if files:
                        submission_metadata["files"] = files
                        submission_metadata["has_files"] = True
                    if len(user_input.strip()) > 50:
                        submission_metadata["text_content"] = user_input
                        submission_metadata["has_content"] = True

                async for event in self._handle_mission_confirmation_events(
                    grading_workflow=grading_workflow,
                    user_input=user_input,
                    submission_metadata=submission_metadata,
                    circle_file_urls=effective_circle_urls
                ):
                    yield event
                # Final flush before return
                if self._pending_saves:
                    flush_start = time()
                    await self._flush_pending_saves()
                    # print(f"⏱️  Final flush: {(time() - flush_start)*1000:.1f}ms")
                
                iteration_time = time() - iteration_start
                # print(f"\n{'='*60}")
                # print(f"✅ Iteration complete: {iteration_time*1000:.1f}ms")
                # print(f"{'='*60}\n")
                return
            
            # Handle posting confirmation workflow
            elif workflow_type == "grading_awaiting_posting_confirmation":
                grading_data = self.state.workflow_state.get("grading_data")
                stored_circle_urls = self.state.workflow_state.get("circle_file_urls", [])
                effective_circle_urls = circle_file_urls or stored_circle_urls
                async for event in self._handle_posting_confirmation_events(
                    grading_workflow=grading_workflow,
                    user_input=user_input,
                    grading_data=grading_data,
                    circle_file_urls=effective_circle_urls
                ):
                    yield event
                # Final flush before return
                if self._pending_saves:
                    flush_start = time()
                    await self._flush_pending_saves()
                    # print(f"⏱️  Final flush: {(time() - flush_start)*1000:.1f}ms")

                iteration_time = time() - iteration_start
                # print(f"\n{'='*60}")
                # print(f"✅ Iteration complete: {iteration_time*1000:.1f}ms")
                # print(f"{'='*60}\n")
                return

            # Handle resubmission confirmation workflow
            elif workflow_type == "resubmission_confirmation_pending":
                submission_metadata = self.state.workflow_state.get("submission_metadata")
                stored_circle_urls = self.state.workflow_state.get("circle_file_urls", [])
                effective_circle_urls = circle_file_urls or stored_circle_urls
                prior_submission = self.state.workflow_state.get("prior_submission") or {}

                if grading_workflow._is_affirmative(user_input):
                    # User confirmed resubmission — proceed with grading, skip prior-check
                    # print(f"✅ Resubmission confirmed (prior score: {prior_submission.get('score')}%)")
                    self.state.workflow_state = None

                    try:
                        async for event in grading_workflow.astream_process_direct_submission(
                            email=submission_metadata["student_email"],
                            space_name=submission_metadata["space_name"],
                            text_content=submission_metadata.get("text_content", ""),
                            files=submission_metadata.get("files", []),
                            skip_prior_check=True,
                            resolved_challenge_name=submission_metadata.get("challenge_name"),
                            challenge_metadata=submission_metadata.get("challenge_metadata"),
                        ):
                            event_type = event.get("type")

                            if event_type == "status":
                                yield build_reasoning_event(
                                    step=event.get("step", ""),
                                    reasoning=event.get("message", "")
                                )
                            elif event_type == "error":
                                yield build_error_event(event.get("message", "Unknown error"))
                                return
                            elif event_type == "result":
                                grading_data = event.get("data", {})
                                grading_data["circle_file_urls"] = effective_circle_urls
                                grading_event = {
                                    "type": "grading_complete",
                                    "grading_data": grading_data,
                                }
                                # Determine action based on score
                                raw_score = grading_data.get("score", "0")
                                try:
                                    score_val = float(str(raw_score).replace('%', ''))
                                except (ValueError, TypeError):
                                    score_val = 0.0

                                if score_val >= 80:
                                    grading_event["action"] = "request_posting_confirmation"
                                else:
                                    grading_event["action"] = "show_low_score_feedback"
                                    grading_event["message"] = (
                                        f"Your score is {score_val}/100. I recommend reviewing the feedback "
                                        f"and retrying before posting to Circle. Below is your feedback:\n"
                                        f"{grading_data.get('feedback', '')}"
                                    )
                                    grading_event["score"] = score_val

                                async for result_event in self._handle_grading_complete_event(grading_event):
                                    yield result_event
                                break
                    except Exception as e:
                        # print(f"❌ Error in resubmission grading: {e}")
                        self.state.workflow_state = None
                        yield build_error_event(f"Grading failed: {str(e)}")
                else:
                    # User declined resubmission — keep existing result
                    # print(f"❌ Resubmission declined (keeping prior score: {prior_submission.get('score')}%)")
                    self.state.workflow_state = None
                    prior_score = prior_submission.get('score', 'N/A')
                    decline_msg = (
                        f"Keeping your existing result (score: {prior_score}%). "
                        f"Let me know if you need anything else."
                    )
                    self.state.add_message(MessageRole.ASSISTANT, decline_msg)

                    if self.auto_save and self.session_id:
                        await self._save_message_to_session(
                            role="assistant",
                            content=decline_msg,
                            metadata={
                                "type": "resubmit_declined",
                                "prior_submission": prior_submission,
                                "workflow_state": None,
                            }
                        )

                    yield build_content_event(decline_msg)

                # Final flush before return
                if self._pending_saves:
                    flush_start = time()
                    await self._flush_pending_saves()
                    # print(f"⏱️  Final flush: {(time() - flush_start)*1000:.1f}ms")

                iteration_time = time() - iteration_start
                # print(f"\n{'='*60}")
                # print(f"✅ Iteration complete: {iteration_time*1000:.1f}ms")
                # print(f"{'='*60}\n")
                return
        
        try:
            while True:
                # Increment iteration counter
                self.state.iteration_count += 1
                
                # Hard stop: Force answering flow if max iterations reached
                if self.state.iteration_count > MAX_ITERATIONS:
                    # yield build_reasoning_event(
                    #     f"Maximum iterations ({MAX_ITERATIONS}) reached. Forcing final response generation."
                    # )
                    
                    response_content = ""
                    final_metadata: ChatMetadata = {"type": MetadataType.TEXT.value}
                    if self.state.tool_results:
                        final_metadata = transform_tool_results(self.state.tool_results)
                    
                    async for chunk in self.answering_agent.astream_answer(self.state):
                        response_content += chunk
                        yield build_content_event(chunk)
                    
                    if final_metadata.get("summary") or final_metadata.get("files"):
                        yield build_metadata_event(final_metadata)
                    
                    self.state.final_response = response_content
                    self.state.add_message(MessageRole.ASSISTANT, response_content)
                    
                    # Save assistant message to session if enabled
                    if self.auto_save and self.session_id:
                        assistant_metadata = {
                            "model": self.writing_llm.model,
                            "hard_stop": True,
                            "iterations": self.state.iteration_count,
                            **final_metadata
                        }
                        await self._save_message_to_session_async(
                            role="assistant",
                            content=response_content,
                            metadata=assistant_metadata
                        )
                    # Final flush before break
                    if self._pending_saves:
                        await self._flush_pending_saves()
                    break
                
                # Phase 5A: Auto-Resolve Context for General Sessions
                # Skip RAG tool for greetings or general conversation without entity terms
                entity_keywords = ["mission", "challenge", "series", "workshop", "program", "certification", "course", "lesson"]
                has_entity_terms = any(kw in user_input.lower() for kw in entity_keywords)
                is_general_chat = not has_entity_terms and not files and not self.state.context_prefetch
                
                if is_general_chat and self.state.iteration_count == 1:
                    yield build_reasoning_event(
                        step="General Session Detected",
                        reasoning="No entity terms found - using conversation context without RAG search"
                    )
                    # Skip to answering directly
                    response_content = ""
                    ans_start = time()
                    async for chunk in self.answering_agent.astream_answer(self.state):
                        response_content += chunk
                        yield build_content_event(chunk)
                        if ans_start > 0:
                            yield build_timing_event("answering_first_chunk", (time() - ans_start) * 1000)
                            ans_start = 0
                    
                    self.state.final_response = response_content
                    self.state.add_message(MessageRole.ASSISTANT, response_content)
                    
                    if self.auto_save and self.session_id:
                        await self._save_message_to_session_async(
                            role="assistant",
                            content=response_content,
                            metadata={"model": self.writing_llm.model, "general_chat": True}
                        )
                    if self._pending_saves:
                        await self._flush_pending_saves()
                    break
                
                # Phase 5A: Auto-Resolve Entity Context for General Sessions
                # When user mentions a specific entity in a general session (no context_type),
                # auto-detect and prefetch it so the answering agent has grounding data
                if (
                    has_entity_terms
                    and self.state.iteration_count == 1
                    and not self.state.context_prefetch
                    and not getattr(self, '_session_context_type', None)
                ):
                    try:
                        auto_resolved = await self.entity_resolver.resolve(
                            query=user_input,
                            conversation_history=[
                                {"role": msg.role.value, "content": msg.content}
                                for msg in self.state.messages[-5:]
                            ]
                        )
                        if auto_resolved.resolved and auto_resolved.entity_id:
                            yield build_reasoning_event(
                                step="Auto-Prefetch",
                                reasoning=f"General session — auto-detected {auto_resolved.entity_type}: {auto_resolved.entity_name}"
                            )
                            # Prefetch entity context using existing ContextPrefetcher
                            prefetch_data = await self.context_prefetcher.fetch(
                                entity_type=auto_resolved.entity_type,
                                entity_id=str(auto_resolved.entity_id)
                            )
                            if prefetch_data:
                                self.state.context_prefetch = prefetch_data
                                # Store resolved entity for persistence
                                if not self.state.resolved_entities:
                                    self.state.resolved_entities = []
                                self.state.resolved_entities.append({
                                    "type": auto_resolved.entity_type,
                                    "id": auto_resolved.entity_id,
                                    "name": auto_resolved.entity_name,
                                })
                    except Exception as e:
                        print(f"⚠️ Auto-resolve failed (non-fatal): {e}")
                
                # 2. Router Step
                router_start = time()
                decision = await self.router.decide(self.state)
                
                # CIRCUIT BREAKER (Phase 3A): Prevent router looping
                # If iteration >= 2 and no tool results yet, force decisive action
                if self.state.iteration_count >= 2 and not self.state.tool_results:
                    yield build_reasoning_event(
                        step="Circuit Breaker",
                        reasoning=f"Iteration {self.state.iteration_count} without tool results. Forcing decisive action."
                    )
                    if decision.intent == AgentIntent.CHAT and decision.status == AgentStatus.CONTINUE:
                        # Force tool execution with best guess
                        decision.intent = AgentIntent.TOOL
                        decision.tools_group = self._infer_best_tool_group(user_input)
                        yield build_reasoning_event(
                            step="Circuit Breaker Action",
                            reasoning=f"Forcing tool execution with group: {decision.tools_group}"
                        )
                    elif decision.intent == AgentIntent.TOOL and decision.status == AgentStatus.CONTINUE:
                        # Tool intent but still continuing - force finish after this tool
                        pass  # Let it execute the tool once
                
                yield build_timing_event("router_decide", (time() - router_start) * 1000)
                yield build_reasoning_event(
                    step=decision.step,
                    reasoning=f"{decision.reasoning}\n\n"
                )
                
                self.state.intent = decision.intent
                self.state.status = decision.status

                # print(f"Router Decision: {decision.intent}, Status: {decision.status}")
                
                # STEP 4: Cancel extraction if grading intent detected
                if decision.tools_group == "grading_system" and extraction_task and not extraction_task.done():
                    # extraction_task.cancel()
                    # print("Extraction cancelled: grading intent detected")
                    pass
                
                if decision.tools_group == "grading_system":
                    # Check if already confirmed in workflow state
                    workflow_type = self.state.workflow_state.get("type") if self.state.workflow_state else None
                    is_confirmed = False
                    response_message = ""
                    submission_metadata = None
                    
                    if workflow_type == "mission_confirmed":
                        # Already confirmed, skip verification
                        is_confirmed = True
                        submission_metadata = self.state.workflow_state.get("submission_metadata")
                        # print(f"⚡ Intent verification SKIPPED (already confirmed)")
                        yield build_reasoning_event(
                            step="Intent Verification",
                            reasoning="Using previously confirmed mission details..."
                        )
                    elif context_type == "challenge" and context_id:
                        # Pre-resolved challenge from frontend — skip detection entirely
                        # print(f"⚡ Challenge shortcut: context_type=challenge, context_id={context_id}")
                        yield build_reasoning_event(
                            step="Intent Verification",
                            reasoning="Resolving pre-identified challenge..."
                        )
                        detected_challenge = await self.intent_verifier.db_handler.fetch_challenge_by_uuid(context_id)
                        if detected_challenge:
                            has_files = bool(files and len(files) > 0)
                            submission_metadata = {
                                "challenge": detected_challenge,
                                "email": email,
                                "files": files,
                                "text_content": self.state.current_input,
                                "has_files": has_files,
                                "has_content": len(self.state.current_input.strip()) > 50,
                            }
                            # Go to confirmation (same as detection path)
                            confirmation = await self.intent_verifier._request_confirmation(
                                self.state, detected_challenge, has_files
                            )
                            is_confirmed = False
                            response_message = confirmation
                        else:
                            # UUID not found — fall through to normal detection
                            # print(f"⚠️ Challenge UUID {context_id} not found, falling back to detection")
                            is_confirmed, response_message, submission_metadata = await self.intent_verifier.verify_submission_intent(
                                state=self.state,
                                email=email,
                                files=files
                            )
                    else:
                        verification_start = time()
                        yield build_reasoning_event(
                            step="Intent Verification",
                            reasoning="Verifying submission details..."
                        )
                        
                        # Use IntentVerificationAgent to detect mission and request confirmation
                        is_confirmed, response_message, submission_metadata = await self.intent_verifier.verify_submission_intent(
                            state=self.state,
                            email=email,
                            files=files
                        )
                        verification_time = time() - verification_start
                        yield build_timing_event("intent_verification", verification_time * 1000)
                        # print(f"⏱️  Intent verification: {verification_time*1000:.1f}ms")

                    # ── Shared confirmation handling for shortcut + normal paths ──
                    if not is_confirmed:
                        # Need user confirmation or clarification
                        self.state.add_message(MessageRole.ASSISTANT, response_message)
                        
                        # Set workflow state if we have submission metadata (mission detected)
                        if submission_metadata:
                            self.state.workflow_state = {
                                "type": "mission_confirmation_pending",
                                "submission_metadata": submission_metadata,
                                "circle_file_urls": circle_file_urls or []
                            }
                            
                            if self.auto_save:
                                await self._save_message_to_session_async(
                                    role="assistant",
                                    content=response_message,
                                    metadata={
                                        "type": "mission_confirmation_request",
                                        "workflow_state": self.state.workflow_state
                                    }
                                )
                        else:
                            # Mission not detected - just ask for clarification
                            if self.auto_save and self.session_id:
                                await self._save_message_to_session_async(
                                    role="assistant",
                                    content=response_message,
                                    metadata={"type": "mission_clarification_request"}
                                )
                        
                        yield build_content_event(response_message)
                        # Final flush before return
                        if self._pending_saves:
                            flush_start = time()
                            await self._flush_pending_saves()
                            # print(f"⏱️  Final flush: {(time() - flush_start)*1000:.1f}ms")
                        
                        # iteration_time = time() - iteration_start
                        # print(f"\n{'='*60}")
                        # print(f"✅ Iteration complete: {iteration_time*1000:.1f}ms")
                        # print(f"{'='*60}\n")
                        return

                if decision.status == AgentStatus.FINISHED:
                    # If finished, generate response (streaming)
                    if decision.intent == AgentIntent.CHAT:
                        # ANTI-HALLUCINATION GUARD (Phase 1A)
                        # Check if we need grounding for domain-specific questions
                        requires_grounding, matched_group = _requires_domain_knowledge(
                            user_input, self.state.tool_groups
                        )
                        if requires_grounding and not self.state.tool_results and not self.state.context_prefetch:
                            # Force a tool call instead of answering blind
                            yield build_reasoning_event(
                                step="Anti-Hallucination Guard",
                                reasoning=f"Domain question detected ({matched_group}) but no grounding data available. Forcing tool search."
                            )
                            # Switch to tool intent and continue to tool execution (below)
                            decision.intent = AgentIntent.TOOL
                            decision.status = AgentStatus.CONTINUE
                            decision.tools_group = matched_group or "circle_aio"
                            self.state.intent = decision.intent
                            self.state.status = decision.status
                            self.router.chosen_group = decision.tools_group
                            # Note: We don't break here, execution continues to TOOL section below
                        else:
                            # Safe to answer from knowledge/context
                            response_content = ""
                            
                            # STEP 5: Wait for extraction to complete before answering
                            file_content = None
                            if extraction_task:
                                try:
                                    file_content = await extraction_task
                                    self.state.tool_inputs["file_content"] = file_content
                                except Exception as e:
                                    file_content = None
                            
                            # Build metadata from tool results if available
                            final_metadata: ChatMetadata = {"type": MetadataType.TEXT.value}
                            if self.state.tool_results:
                                final_metadata = transform_tool_results(self.state.tool_results)
                            
                            ans_start = time()
                            async for chunk in self.answering_agent.astream_answer(self.state):
                                response_content += chunk
                                yield build_content_event(chunk)
                                # Emit timing on first chunk only
                                if ans_start > 0:
                                    yield build_timing_event("answering_first_chunk", (time() - ans_start) * 1000)
                                    ans_start = 0  # Reset to mark as emitted
                            
                            # Yield final metadata event after streaming completes
                            if final_metadata.get("summary") or final_metadata.get("files"):
                                yield build_metadata_event(final_metadata)
                            
                            self.state.final_response = response_content
                            self.state.add_message(MessageRole.ASSISTANT, response_content)
                            
                            # Save assistant message to session if enabled
                            if self.auto_save and self.session_id:
                                assistant_metadata = {
                                    "model": self.writing_llm.model,
                                    **final_metadata
                                }

                                await self._save_message_to_session_async(
                                    role="assistant",
                                    content=response_content,
                                    metadata=assistant_metadata
                                )
                            # Final flush before break
                            if self._pending_saves:
                                flush_start = time()
                                await self._flush_pending_saves()
                            
                            break

                # If CONTINUE
                if decision.intent == AgentIntent.TOOL:
                    tool_start = time()
                    
                    # ENTITY RESOLUTION (Phase 2B): Pre-process query before tool execution
                    # Resolve shorthand references like "Mission 5" to canonical names
                    resolved_result = await self.entity_resolver.resolve(
                        query=user_input,
                        conversation_history=[
                            {"role": msg.role.value, "content": msg.content}
                            for msg in self.state.messages[-5:]  # Last 5 messages for context
                        ]
                    )
                    
                    if resolved_result.resolved:
                        yield build_reasoning_event(
                            step="Entity Resolution",
                            reasoning=f"Resolved '{resolved_result.original}' → '{resolved_result.resolved_query}' ({resolved_result.entity_type})"
                        )
                        
                        # Store resolved entity in state for future reference
                        if not self.state.resolved_entities:
                            self.state.resolved_entities = []
                        self.state.resolved_entities.append({
                            "type": resolved_result.entity_type,
                            "id": resolved_result.entity_id,
                            "name": resolved_result.entity_name,
                            "original_query": resolved_result.original,
                            "resolved_query": resolved_result.resolved_query,
                        })
                        
                        # DETERMINISTIC ROUTING: Resolved entity → direct DB fetch (bypass ToolAgent)
                        yield build_reasoning_event(
                            step="Direct DB Fetch",
                            reasoning=f"Entity resolved — fetching {resolved_result.entity_type} directly from database (skipping RAG)"
                        )
                        try:
                            db_result = await self.database_tool.execute(
                                resource=self._map_entity_type_to_resource(resolved_result.entity_type),
                                name=resolved_result.entity_name,
                                limit=10,
                                include_related=True,
                            )
                            if db_result and not db_result.get("error"):
                                self.state.tool_results = [db_result]
                            else:
                                # DB fetch failed — fall through to RAG with enriched query
                                yield build_reasoning_event(
                                    step="DB Fetch Fallback",
                                    reasoning="Direct DB fetch returned no results — falling back to RAG search"
                                )
                                if resolved_result.enriched_query:
                                    self.state.current_input = resolved_result.enriched_query
                                self.state.tool_schemas = get_tools_by_group(self.router.chosen_group)
                                self.state.tool_results = await self.tool_agent.select_tool(self.state)
                        except Exception as e:
                            print(f"⚠️ Direct DB fetch error: {e}")
                            # Fall through to RAG on error
                            if resolved_result.enriched_query:
                                self.state.current_input = resolved_result.enriched_query
                            self.state.tool_schemas = get_tools_by_group(self.router.chosen_group)
                            self.state.tool_results = await self.tool_agent.select_tool(self.state)
                    else:
                        # NOT RESOLVED: Use enriched query if available, then ToolAgent + RAG
                        if resolved_result.enriched_query:
                            self.state.current_input = resolved_result.enriched_query
                        self.state.tool_schemas = get_tools_by_group(self.router.chosen_group)
                        self.state.tool_results = await self.tool_agent.select_tool(self.state)
                    
                    yield build_timing_event("tool_execution", (time() - tool_start) * 1000)
                    
                    # Add tool results to message history for router context
                    if self.state.tool_results:
                        tool_results_summary = self.state.format_tool_results_for_history(self.state.tool_results)
                        self.state.add_message(
                            MessageRole.TOOL, 
                            tool_results_summary,
                            name="tool_execution"
                        )
                    
                    # Note: Extraction continues in background, will be waited for in next iteration

                elif decision.intent == AgentIntent.CHAT:
                    # Intermediate chat step (internal thought or multi-step answer)
                    # If status is CONTINUE, we assume it's not the final response to user yet?
                    # Or we yield it? 
                    # "The router agent must now output an additional parameter indicating whether the task is FINISHED"
                    # "If FINISHED --> yield the responses."
                    # So if CONTINUE, we do NOT yield.
                    pass

        except Exception as e:
            self.state.error = str(e)
            # print(f"Error in run_stream: {e}")
            # Final flush before error yield
            if self._pending_saves:
                flush_start = time()
                await self._flush_pending_saves()
                # print(f"⏱️  Final flush: {(time() - flush_start)*1000:.1f}ms")
            
            # iteration_time = time() - iteration_start
            # print(f"\n{'='*60}")
            # print(f"❌ Iteration failed: {iteration_time*1000:.1f}ms")
            # print(f"{'='*60}\n")
            yield build_error_event(str(e))

    def get_history(self):
        return self.state.messages
    
    def _load_from_session(self):
        """Load conversation history and workflow state from database"""
        
        if not self.supabase or not self.session_id:
            # print(f"DEBUG: Skipping _load_from_session - supabase: {self.supabase is not None}, session_id: {self.session_id}")
            return
        
        try:
            # Fetch messages from session
            response = (
                self.supabase.schema("agents").table("chatbot_messages")
                .select("*")
                .eq("session_id", self.session_id)
                .is_("deleted_at", "null")
                .order("sequence_number", desc=False)
                .execute()
            )
            
            if response.data:
                for msg in response.data:
                    self.state.add_message(
                        MessageRole(msg["role"]),
                        msg["content"]
                    )
                
                # Restore workflow state from last assistant message metadata
                last_assistant_msg = None
                for msg in reversed(response.data):
                    if msg["role"] == "assistant":
                        last_assistant_msg = msg
                        break
                
                if last_assistant_msg and last_assistant_msg.get("metadata"):
                    metadata = last_assistant_msg["metadata"]
                    if "workflow_state" in metadata:
                        self.state.workflow_state = metadata["workflow_state"]

            message_count = len(response.data) if response.data else 0
            self.supabase.schema("agents").table("chatbot_sessions").update({
                "message_count": message_count,
                "last_message_at": datetime.utcnow().isoformat(),
                "updated_at": datetime.utcnow().isoformat(),
            }).eq("id", self.session_id).execute()

        except Exception as e:
            print(f"❌ load_messages failed: {e}")

    async def _save_message_to_session(
        self,
        role: str,
        content: str,
        metadata: Dict[str, Any],
        files: Optional[List[Dict[str, Any]]] = None
    ) -> None:
        """Save a single message to the database session.
        
        This is the actual database save operation called by _flush_pending_saves.
        """
        if not self.supabase or not self.session_id:
            return
        
        try:
            # Get current message count to determine sequence number
            count_response = (
                self.supabase
                .schema('agents')
                .table("chatbot_messages")
                .select("sequence_number", count="exact")
                .eq("session_id", self.session_id)
                .is_("deleted_at", "null")
                .execute()
            )
            
            sequence_number = count_response.count or 0
            
            message_data = {
                "session_id": self.session_id,
                "role": role,
                "content": content,
                "sequence_number": sequence_number,
                "metadata": metadata,
            }
            
            # Add files if provided
            if files:
                message_data["files"] = files
            
            # Insert message
            self.supabase.schema('agents').table("chatbot_messages").insert(message_data).execute()
            
            # Update session metadata
            self.supabase.schema('agents').table("chatbot_sessions").update({
                "message_count": sequence_number + 1,
                "last_message_at": datetime.utcnow().isoformat(),
                "updated_at": datetime.utcnow().isoformat(),
            }).eq("id", self.session_id).execute()
            
        except Exception as e:
            print(f"Error saving message to session: {e}")
            pass

    async def _save_message_to_session_async(
        self,
        role: str,
        content: str,
        metadata: Dict[str, Any],
        files: Optional[List[Dict[str, Any]]] = None
    ) -> None:
        """Non-blocking auto-save wrapper using batch append

        Appends save operations to batch for efficient database writes.
        Batch automatically flushes after 2 seconds or on final flush.
        """
        self._append_to_pending_saves(role, content, metadata, files)

    async def _flush_pending_saves(self):
        """Flush accumulated saves to database in batch.

        Executes all pending saves in parallel using asyncio.gather()
        to reduce database round trips.
        """
        if not self._pending_saves:
            return

        batch_size = len(self._pending_saves)
        batch = self._pending_saves.copy()
        self._pending_saves.clear()

        flush_start = time()
        # Execute batch insert in parallel
        await asyncio.gather(*[
            self._save_message_to_session(**save)
            for save in batch
        ], return_exceptions=True)
        flush_time = time() - flush_start

        # print(f"💾 Batch flush: {batch_size} saves in {flush_time*1000:.1f}ms ({flush_time*1000/batch_size:.1f}ms/save)")
        self._last_flush = time()

    def _append_to_pending_saves(
        self,
        role: str,
        content: str,
        metadata: Dict[str, Any],
        files: Optional[List[Dict[str, Any]]] = None
    ) -> None:
        """Append save operation to pending batch"""
        if self.auto_save and self.session_id:
            self._pending_saves.append({
                "role": role,
                "content": content,
                "metadata": metadata,
                "files": files
            })

            # Check if flush needed
            if time() - self._last_flush > self._save_flush_interval:
                asyncio.create_task(self._flush_pending_saves())

    def _serialize_state_for_save(self, state: AgentState) -> Dict[str, Any]:
        """Optimized state serialization for auto-save.

        Only serializes essential data needed for session restoration:
        - Last 5 messages (not full history)
        - Iteration count
        - Current intent and status

        This reduces serialization time by 30-40%.
        """
        return {
            "messages": [
                {"role": msg.role.value, "content": msg.content}
                for msg in state.messages[-5:]  # Only last 5 messages
            ],
            "iteration_count": state.iteration_count,
            "intent": state.intent.value if state.intent else None,
            "status": state.status.value if state.status else None,
        }

    def _is_submission_request(self, state: AgentState) -> bool:
        """Check if current request is a submission"""
        submission_keywords = ["submit", "submission", "assignment", "challenge", "grading"]
        input_lower = state.current_input.lower()
        return any(keyword in input_lower for keyword in submission_keywords)

    def _generate_posting_confirmation(self, grading_data: Dict[str, Any]) -> dict:
        """Generate posting confirmation message"""
        raw_score = grading_data.get("score", 0)
        try:
            score = float(str(raw_score).replace('%', ''))
        except (ValueError, TypeError):
            score = 0.0

        if score < 80:
            message = f"""## Grading Complete

**Score: {score}/100**

Your submission has been graded. Since the score is below 80%, I recommend reviewing the feedback and retrying before posting to Circle.

Would you like to:
- Retry with improvements
- Post anyway (not recommended)

Let me know your preference."""
        else:
            message = f"""## Grading Complete

**Score: {score}/100**

Great work! Your submission has been graded successfully.

Would you like me to post your submission and feedback to Circle? (yes/no)"""

        return build_content_event(message)
    
    async def _extract_mission_from_input(self, user_input: str) -> Optional[str]:
        """Extract mission name/number from user input using database and mission detection utility"""
        try:
            # Query all missions from database
            if not self.supabase:
                print("⚠️ Supabase client not initialized, falling back to regex")
                return self._fallback_mission_extraction(user_input)
            
            # Fetch all spaces (missions) from database
            response = (
                self.supabase
                .schema("public")
                .table("missions")
                .select("id, name")
                # .order("name", desc=False)
                .execute()
            )
            
            if not response.data:
                print("⚠️ No missions found in database, falling back to regex")
                return self._fallback_mission_extraction(user_input)
            
            # Use mission detection utility to match
            mission_name = detect_mission_space(user_input, response.data, with_id=False)
            
            if mission_name:
                print(f"✅ Detected mission: {mission_name}")
                return mission_name
            else:
                print("⚠️ No mission match found, falling back to regex")
                return self._fallback_mission_extraction(user_input)
                
        except Exception as e:
            print(f"⚠️ Error in mission detection: {e}, falling back to regex")
            return self._fallback_mission_extraction(user_input)
    
    def _fallback_mission_extraction(self, user_input: str) -> Optional[str]:
        """Fallback regex-based mission extraction"""
        import re
        
        patterns = [
            r'mission\s+(\d+)',  # Mission 1, Mission 2, etc.
            r'mission\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+){0,2})',  # Mission Advanced AI
        ]
        
        for pattern in patterns:
            mission_match = re.search(pattern, user_input, re.IGNORECASE)
            if mission_match:
                mission_identifier = mission_match.group(1).strip()
                if mission_identifier.isdigit():
                    return f"Mission {mission_identifier}"
                return ' '.join(word.capitalize() for word in mission_identifier.split())
        
        return None

    def _infer_best_tool_group(self, user_input: str) -> str:
        """Infer the best tool group based on user input keywords.
        
        Used by circuit breaker when router loops without making progress.
        
        Args:
            user_input: The user's input text
            
        Returns:
            Tool group name (e.g., 'circle_aio', 'grading_system', 'general')
        """
        input_lower = user_input.lower()
        
        # Grading/submission related
        grading_keywords = ["submit", "grade", "submission", "assignment", "challenge", "capstone", "final"]
        if any(kw in input_lower for kw in grading_keywords):
            return "grading_system"
        
        # AIO content related
        aio_keywords = ["mission", "series", "workshop", "micro session", "certification", "program"]
        if any(kw in input_lower for kw in aio_keywords):
            return "circle_aio"
        
        # Default to general for everything else
        return "circle_aio"  # Default to circle_aio for most queries in this system

    def _map_entity_type_to_resource(self, entity_type: str) -> str:
        """Map entity resolver types to DatabaseToolHandler resource names.
        
        Args:
            entity_type: Entity type from ResolvedQuery (e.g., "mission", "challenge")
            
        Returns:
            Resource name for DatabaseToolHandler.execute()
        """
        mapping = {
            "mission": "missions",
            "challenge": "challenges",
            "series": "series",
            "workshop": "workshops",
            "event": "events",
            "brief": "briefs",
        }
        return mapping.get(entity_type, entity_type)

    async def _handle_mission_confirmation_events(
        self,
        grading_workflow: 'GradingWorkflow',
        user_input: str,
        submission_metadata: Dict[str, Any],
        circle_file_urls: Optional[List[str]]
    ) -> AsyncGenerator[Dict[str, str], None]:
        """Handle events from mission confirmation workflow"""
        async for event in grading_workflow.handle_mission_confirmation_workflow(
            user_input=user_input,
            submission_metadata=submission_metadata,
            circle_file_urls=circle_file_urls
        ):
            event_type = event.get("type")
            
            if event_type == "reasoning":
                yield build_reasoning_event(
                    step=event["step"],
                    reasoning=event["message"]
                )
            elif event_type == "error":
                yield build_error_event(event["message"])
                return
            elif event_type == "resubmit_warning":
                # Prior passed submission found — set resubmission confirmation state
                self.state.workflow_state = {
                    "type": "resubmission_confirmation_pending",
                    "submission_metadata": event.get("submission_metadata"),
                    "circle_file_urls": circle_file_urls or [],
                    "prior_submission": event.get("prior_submission"),
                }
                warning_msg = event.get("message")
                self.state.add_message(MessageRole.ASSISTANT, warning_msg)

                if self.auto_save and self.session_id:
                    await self._save_message_to_session(
                        role="assistant",
                        content=warning_msg,
                        metadata={
                            "type": "resubmit_warning",
                            "prior_submission": event.get("prior_submission"),
                            "workflow_state": self.state.workflow_state,
                        }
                    )

                yield build_content_event(warning_msg)
                return
            elif event_type == "grading_complete":
                # Propagate circle_file_urls into grading_data for workflow state persistence
                grading_data = event.get("grading_data", {})
                grading_data["circle_file_urls"] = circle_file_urls or []
                event["grading_data"] = grading_data
                async for result_event in self._handle_grading_complete_event(event):
                    yield result_event
                return
            elif event_type == "submission_cancelled":
                async for cancel_event in self._handle_submission_cancelled_event(event):
                    yield cancel_event
                return

    async def _handle_grading_complete_event(
        self,
        event: Dict[str, Any]
    ) -> AsyncGenerator[Dict[str, str], None]:
        """Handle grading complete event with high/low score logic"""
        action = event.get("action")
        grading_data = event.get("grading_data")
        
        # Add grading results to in-memory conversation history only.
        # DB persistence is handled by the branch below (low-score or posting confirmation)
        # to avoid duplicate messages in chat history.
        grading_summary = self._format_grading_summary(grading_data)
        self.state.add_message(MessageRole.ASSISTANT, grading_summary)
        self.state.add_submission_result(grading_data)
        
        if action == "request_posting_confirmation":
            # High score - request posting confirmation
            self.state.workflow_state = {
                "type": "grading_awaiting_posting_confirmation",
                "grading_data": grading_data,
                "circle_file_urls": grading_data.get("circle_file_urls", [])
            }
            confirmation_message = self._generate_posting_confirmation(grading_data)
            
            if self.auto_save and self.session_id:
                event_data = confirmation_message.get("data", {})
                if isinstance(event_data, str):
                    import json
                    try:
                        event_data = json.loads(event_data)
                    except:
                        pass
                
                content = event_data.get("content", "") if isinstance(event_data, dict) else str(event_data)
                
                await self._save_message_to_session(
                    role="assistant",
                    content=content,
                    metadata={
                        "type": "grading_confirmation",
                        "workflow_state": self.state.workflow_state,
                        "score": grading_data.get("score")
                    }
                )
            
            yield confirmation_message
        elif action == "show_low_score_feedback":
            # Low score - show feedback
            low_score_message = event.get("message")
            self.state.add_message(MessageRole.ASSISTANT, low_score_message)
            self.state.workflow_state = None
            
            if self.auto_save and self.session_id:
                await self._save_message_to_session(
                    role="assistant",
                    content=low_score_message,
                    metadata={
                        "type": "grading_low_score",
                        "workflow_state": None,
                        "score": event.get("score")
                    }
                )
            
            yield build_content_event(low_score_message)

    async def _handle_submission_cancelled_event(
        self,
        event: Dict[str, Any]
    ) -> AsyncGenerator[Dict[str, str], None]:
        """Handle submission cancelled event"""
        cancel_message = event.get("message")
        self.state.add_message(MessageRole.ASSISTANT, cancel_message)
        self.state.workflow_state = None
        
        if self.auto_save and self.session_id:
            await self._save_message_to_session(
                role="assistant",
                content=cancel_message,
                metadata={"type": "submission_cancelled", "workflow_state": None}
            )
        
        yield build_content_event(cancel_message)

    async def _handle_posting_confirmation_events(
        self,
        grading_workflow: 'GradingWorkflow',
        user_input: str,
        grading_data: Dict[str, Any],
        circle_file_urls: Optional[List[str]]
    ) -> AsyncGenerator[Dict[str, str], None]:
        """Handle events from posting confirmation workflow"""
        async for event in grading_workflow.handle_posting_confirmation_workflow(
            user_input=user_input,
            grading_data=grading_data,
            circle_file_urls=circle_file_urls
        ):
            event_type = event.get("type")
            
            if event_type == "reasoning":
                yield build_reasoning_event(
                    step=event["step"] or "## Posting Confirmation",
                    reasoning=event["message"]
                )
            elif event_type == "posting_complete":
                async for post_event in self._handle_posting_complete_event(event):
                    yield post_event
                return
            elif event_type == "posting_declined":
                async for decline_event in self._handle_posting_declined_event(event):
                    yield decline_event
                return

    async def _handle_posting_complete_event(
        self,
        event: Dict[str, Any]
    ) -> AsyncGenerator[Dict[str, str], None]:
        """Handle posting complete event"""
        post_result = event.get("post_result") or {}
        post_url = post_result.get("url", "")
        post_content = post_result.get("markdown", "")
        
        already_streamed = False
        if post_result.get("error"):
            posting_message = f"❌ Failed to post: {post_result['error']}"
            self.state.add_message(MessageRole.ASSISTANT, posting_message)
        else:
            # Use answering agent to generate brief summary
            prompt = f"""
            Generate a brief confirmation message that the submission has been posted to Circle. 
            Summarize the post content: {post_content}.
            Include the post URL: {post_url}. 
            Keep it concise and professional.
            """
            
            # Temporarily add prompt to state for answering agent
            self.state.add_message(MessageRole.USER, prompt)
            
            posting_message_content = ""
            async for chunk in self.answering_agent.astream_answer(self.state):
                posting_message_content += chunk
                yield build_content_event(chunk)
            
            # Remove the temporary prompt from state
            self.state.messages.pop()
            
            # Use accumulated content or fallback
            posting_message = posting_message_content.strip() or "✅ Successfully posted your submission and feedback to Circle!"
            self.state.add_message(MessageRole.ASSISTANT, posting_message)
            already_streamed = True
        
        # Clear workflow state
        self.state.workflow_state = None
        
        if self.auto_save and self.session_id:
            await self._save_message_to_session(
                role="assistant",
                content=posting_message,
                metadata={
                    "type": "posting_confirmation",
                    "workflow_state": None
                }
            )
        
        if not already_streamed:
            yield build_content_event(posting_message)

    async def _handle_posting_declined_event(
        self,
        event: Dict[str, Any]
    ) -> AsyncGenerator[Dict[str, str], None]:
        """Handle posting declined event"""
        decline_message = event.get("message")
        self.state.add_message(MessageRole.ASSISTANT, decline_message)
        self.state.workflow_state = None
        
        if self.auto_save and self.session_id:
            await self._save_message_to_session(
                role="assistant",
                content=decline_message,
                metadata={
                    "type": "posting_declined",
                    "workflow_state": None
                }
            )
        
        yield build_content_event(decline_message)

    def _format_grading_summary(self, grading_data: Dict[str, Any]) -> str:
        """Format grading results for conversation history"""
        score = grading_data.get("score", 0)
        mission = grading_data.get("mission_name", "Unknown")
        feedback = grading_data.get("feedback", "No feedback provided")
        
        summary = f"""## Assignment Grading Complete

**Mission:** {mission}
**Score:** {score}/100

**Feedback:**
{feedback}
"""
        return summary
    
    async def create_session(
        self,
        title: Optional[str] = None,
        context_type: Optional[str] = None,
        context_id: Optional[str] = None,
        context_metadata: Optional[Dict[str, Any]] = None,
        session_metadata: Optional[Dict[str, Any]] = None
    ) -> Optional[str]:
        """Create a new session in database and return session_id"""
        if not self.supabase or not self.member_id:
            return None
        
        try:
            # Build session_metadata with context tracking
            merged_session_metadata = session_metadata or {
                "router_model": self.router_llm.fallback_models or self.router_llm.model,
                "tool_llm"   : self.tool_llm.fallback_models or self.tool_llm.model,
                "intent_verification_llm" : self.intent_verification_llm.fallback_models or self.intent_verification_llm.model,
                "writing_model": self.writing_llm.model,
            }
            if context_type and context_id:
                merged_session_metadata["context_type"] = context_type
                merged_session_metadata["context_id"] = context_id
            
            session_data = {
                "member_id": self.member_id,
                "title": title,
                "status": "active",
                "context_type": context_type,
                "context_metadata": context_metadata or {},
                "session_metadata": merged_session_metadata,
                "message_count": 0,
            }
            
            response = self.supabase.schema("agents").table("chatbot_sessions").insert(session_data).execute()
            
            if response.data:
                self.session_id = response.data[0]["id"]
                print(f"Created new session: {self.session_id}")
                return self.session_id
        except Exception as e:
            print(f"Error creating session: {e}")
        
        return None

    # --- Multimodal File Processing Helper Methods ---

    def _extract_file_metadata(self, files: List[dict]) -> List[dict]:
        """Extract metadata without loading file content"""
        return [
            {
                "name": f.get("name") or f.get("filename"),
                "type": f.get("type") or f.get("mime_type") or get_mime_type_from_filename(f.get("filename")) or "application/octet-stream",
                "size": int(f.get("size", "0")),
                "url": f.get("url")
            }
            for f in files
        ]

    def _format_file_metadata_summary(self, metadata: List[dict]) -> str:
        """Format file metadata for router context"""
        lines = []
        for m in metadata:
            size_mb = m["size"] / 1_000_000
            lines.append(f"- {m['name']} ({m['type']}, {size_mb:.1f}MB)")
        return "\n".join(lines)

    def _is_question_about_files(self, user_input: str, files: List[dict]) -> bool:
        """Determine if user question is about the uploaded files"""
        # Skip extraction for grading-related inputs (handled by grading workflow)
        grading_keywords = {"submit", "submission", "grade", "grading", "mission", "challenge", "capstone", "workshop"}
        input_lower = user_input.lower()
        if any(kw in input_lower for kw in grading_keywords):
            return False

        user_lower = user_input.lower()
        
        # Keywords indicating file-related questions
        file_keywords = [
            "file", "document", "pdf", "image", "video", "screenshot",
            "attachment", "upload", "this", "it", "what's in", "analyze",
            "review", "check", "look at", "read", "see"
        ]
        
        # Check if any file names are mentioned (support both 'name' and 'filename' keys)
        for f in files:
            file_name = f.get("name") or f.get("filename", "")
            if file_name.lower() in user_lower:
                return True
        
        # Check for file-related keywords
        if any(keyword in user_lower for keyword in file_keywords):
            return True
        
        # If asking about workshops, events, progress, etc. - NOT about files
        non_file_keywords = [
            "workshop", "event", "mission", "series", "program",
            "progress", "upcoming", "schedule", "when", "where"
        ]
        
        if any(keyword in user_lower for keyword in non_file_keywords):
            return False
        
        # Default: if files were just uploaded, assume question is about them
        return True

    async def _download_file(self, url: str) -> bytes:
        """Download file from URL"""
        import httpx
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(url)
            response.raise_for_status()
            return response.content

    async def _extract_or_prepare_files(self, files: List[dict]) -> dict:
        """
        Extract or prepare files for AnsweringAgent based on type.
        Runs asynchronously in parallel with router/tool_use.
        
        Returns:
            dict with 'text_content' and/or 'image_urls' keys
        """
        result = {
            "text_content": None,
            "image_urls": None
        }
        
        # Separate files by type
        doc_files = []  # PDFs, docs → extract text
        image_files = []  # Images → multimodal
        
        for file in files:
            file_type = file.get("type") or file.get("mime_type", "")
            size = file.get("size", 0)
            
            if "pdf" in file_type or "document" in file_type:
                doc_files.append(file)
            elif "image" in file_type and size < 5_000_000:  # <5MB
                image_files.append(file)
            elif "video" in file_type:
                # Videos: add note for user
                file_name = file.get("name") or file.get("filename", "video")
                if not result["text_content"]:
                    result["text_content"] = ""
                result["text_content"] += f"\n[Video: {file_name} - Please describe what you'd like to know]"
        
        # Extract text from documents (async)
        if doc_files:
            try:
                extracted_texts = []
                for doc_file in doc_files:
                    # Use existing LLMPdfExtractor
                    file_type = doc_file.get("type") or doc_file.get("mime_type", "")
                    if "pdf" in file_type:
                        # Download PDF
                        pdf_bytes = await self._download_file(doc_file["url"])
                        # Extract text
                        file_name = doc_file.get("name") or doc_file.get("filename", "document")
                        extracted = await self.llm_pdf_extractor.execute(
                            pdf_bytes=pdf_bytes,
                            file_name=file_name
                        )
                        extracted_texts.append(f"[{file_name}]\n{extracted.get('content', '')}")
                
                result["text_content"] = "\n\n".join(extracted_texts)
            except Exception as e:
                print(f"Text extraction failed: {e}")
                result["text_content"] = f"[Error extracting document content: {e}]"
        
        # Prepare images for multimodal
        if image_files:
            result["image_urls"] = [f["url"] for f in image_files]
        
        return result