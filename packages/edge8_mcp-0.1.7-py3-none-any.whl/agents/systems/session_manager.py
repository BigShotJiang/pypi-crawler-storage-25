from typing import Optional, List, Dict, Any, Callable
from time import time
from datetime import datetime
import asyncio


class SessionManager:
    """Manages chatbot session persistence to Supabase.

    Handles message save/load, batch flushing, session creation, and title updates.
    AgentSystem delegates all DB persistence through this class.

    Design notes:
    - All Supabase calls are synchronous (postgrest-py). They are dispatched
      via asyncio.get_event_loop().run_in_executor() so they do NOT block the
      async event loop while the LLM is streaming.
    - Message sequence is tracked in memory (_sequence) — no DB round-trip needed.
    - Session message_count is updated lazily: only on flush/load, not per-message.
    """

    def __init__(
        self,
        supabase,
        session_id: Optional[str] = None,
        member_id: Optional[int] = None,
        auto_save: bool = True,
        flush_interval: float = 2.0,
    ):
        self.supabase = supabase
        self.session_id = session_id
        self.member_id = member_id
        self.auto_save = auto_save
        self._pending_saves: list[dict] = []
        self._flush_interval = flush_interval
        self._last_flush = time()

        # In-memory sequence counter (avoids DB round-trip on every save)
        self._sequence: int = 0

        # Titling state flags
        self._refined_titling_done: bool = False
        self._titling_task: Optional[asyncio.Task] = None
        self._title_callback: Optional[Callable] = None  # async callable returning str

    # ─── Public API ───────────────────────────────────────────────────────────

    def load_messages(self) -> tuple[list[dict], Optional[dict], Optional[dict]]:
        """Load conversation history and workflow state from database.

        Sets self._sequence to len(messages) so saves continue correctly.

        Returns:
            Tuple of (messages, workflow_state, session_metadata) where:
            - messages: list of {"role": str, "content": str} dicts
            - workflow_state: last assistant message's workflow_state metadata or None
            - session_metadata: raw session_metadata JSONB dict or None
        """
        if not self.supabase or not self.session_id:
            return [], None, None

        messages = []
        workflow_state = None
        session_metadata: Optional[dict] = None

        try:
            response = (
                self.supabase.schema("agents").table("chatbot_messages")
                .select("*")
                .eq("session_id", self.session_id)
                .is_("deleted_at", "null")
                .order("sequence_number", desc=False)
                .execute()
            )

            if response.data:
                for msg in response.data:
                    messages.append({"role": msg["role"], "content": msg["content"]})

                # Restore workflow state from last assistant message
                for msg in reversed(response.data):
                    if msg["role"] == "assistant" and msg.get("metadata"):
                        if "workflow_state" in msg["metadata"]:
                            restored = msg["metadata"]["workflow_state"]
                            # Discard stale POSTING_CONFIRMATION state for non-mission_final challenges.
                            # Non-final challenges never need posting confirmation — stale state here
                            # would cause new submissions to be intercepted as yes/no answers instead
                            # of being graded fresh.
                            if restored and restored.get("type") == "grading_awaiting_posting_confirmation":
                                grading_data = restored.get("grading_data", {})
                                if grading_data.get("challenge_type", "mission") != "mission_final":
                                    restored = None
                            workflow_state = restored
                        break

            # Sync in-memory counter so new saves get the correct sequence number
            self._sequence = len(messages)

            # Update session metadata and retrieve session_metadata
            message_count = len(response.data) if response.data else 0
            session_row = (
                self.supabase.schema("agents").table("chatbot_sessions").update({
                    "message_count": message_count,
                    "last_message_at": datetime.utcnow().isoformat(),
                    "updated_at": datetime.utcnow().isoformat(),
                }).eq("id", self.session_id).execute()
            )
            if session_row.data:
                session_metadata = session_row.data[0].get("session_metadata")

        except Exception as e:
            print(f"❌ SessionManager.load_messages failed: {e}")

        return messages, workflow_state, session_metadata

    async def save_message(
        self,
        role: str,
        content: str,
        metadata: Dict[str, Any],
        files: Optional[List[Dict[str, Any]]] = None
    ) -> None:
        """Save a single message to DB without blocking the event loop.

        Uses run_in_executor to offload the sync Supabase I/O to a thread,
        keeping the async event loop free for streaming.

        Also triggers refined title generation at sequence 9 (10th message).
        """
        if not self.supabase or not self.session_id:
            return

        try:
            sequence_number = self._sequence
            self._sequence += 1

            message_data = {
                "session_id": self.session_id,
                "role": role,
                "content": content,
                "sequence_number": sequence_number,
                "metadata": metadata,
            }
            if files:
                message_data["files"] = files

            # Offload blocking DB I/O to thread pool — keeps event loop free
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(
                None,
                lambda: self.supabase.schema('agents')
                    .table("chatbot_messages")
                    .insert(message_data)
                    .execute()
            )

            print(f"[SessionManager] Saved {role} seq={sequence_number}", flush=True)

            # Mid-session title refinement — fire once at sequence 9
            if sequence_number == 9 and not self._refined_titling_done and self._title_callback:
                print("[SessionManager] TRIGGERED: Mid-session title refinement", flush=True)
                self._titling_task = asyncio.create_task(self._run_title_callback())

        except Exception as e:
            print(f"❌ SessionManager.save_message failed: {e}")

    async def save_message_async(
        self,
        role: str,
        content: str,
        metadata: Dict[str, Any],
        files: Optional[List[Dict[str, Any]]] = None
    ) -> None:
        """Append message to pending batch for deferred write."""
        self._append_to_pending(role, content, metadata, files)

    async def flush_pending(self) -> None:
        """Flush all pending saves and sync session metadata in one go.

        Messages are inserted in parallel (order is guaranteed by sequence_number).
        Session message_count is updated once after all inserts — not per message.
        """
        if not self._pending_saves:
            return

        batch = self._pending_saves.copy()
        self._pending_saves.clear()

        # Assign sequence numbers before going async
        saves_with_seq = []
        for save in batch:
            seq = self._sequence
            self._sequence += 1
            saves_with_seq.append((seq, save))

        # Build all message dicts
        messages_to_insert = []
        for seq, save in saves_with_seq:
            msg = {
                "session_id": self.session_id,
                "role": save["role"],
                "content": save["content"],
                "sequence_number": seq,
                "metadata": save["metadata"],
            }
            if save.get("files"):
                msg["files"] = save["files"]
            messages_to_insert.append(msg)

        loop = asyncio.get_event_loop()

        # Batch insert all messages in one DB call
        await loop.run_in_executor(
            None,
            lambda: self.supabase.schema('agents')
                .table("chatbot_messages")
                .insert(messages_to_insert)
                .execute()
        )

        # Update session metadata once for the whole batch
        await loop.run_in_executor(
            None,
            lambda: self.supabase.schema('agents')
                .table("chatbot_sessions")
                .update({
                    "message_count": self._sequence,
                    "last_message_at": datetime.utcnow().isoformat(),
                    "updated_at": datetime.utcnow().isoformat(),
                })
                .eq("id", self.session_id)
                .execute()
        )

        print(
            f"[SessionManager] Flushed {len(messages_to_insert)} messages "
            f"(seq {saves_with_seq[0][0]}–{saves_with_seq[-1][0]})",
            flush=True
        )
        self._last_flush = time()

        # Mid-session title refinement — check if any saved message crossed seq 9
        if not self._refined_titling_done and self._title_callback:
            for seq, _ in saves_with_seq:
                if seq == 9:
                    print("[SessionManager] TRIGGERED: Mid-session title refinement (flush)", flush=True)
                    self._titling_task = asyncio.create_task(self._run_title_callback())
                    break

    async def update_title(self, new_title: str) -> None:
        """Update the session title in the database."""
        if not self.supabase or not self.session_id or not new_title:
            return
        try:
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(
                None,
                lambda: self.supabase.schema('agents')
                    .table("chatbot_sessions")
                    .update({
                        "title": new_title,
                        "updated_at": datetime.utcnow().isoformat(),
                    })
                    .eq("id", self.session_id)
                    .execute()
            )
            self._refined_titling_done = True
            print(f"[SessionManager] Title updated to: {new_title}", flush=True)
        except Exception as e:
            print(f"[SessionManager] update_title failed: {e}", flush=True)

    async def create_session(
        self,
        title: Optional[str] = None,
        context_type: Optional[str] = None,
        context_id: Optional[str] = None,
        context_metadata: Optional[Dict[str, Any]] = None,
        session_metadata: Optional[Dict[str, Any]] = None,
    ) -> Optional[str]:
        """Create a new session in database. Returns session_id."""
        if not self.supabase or not self.member_id:
            return None

        try:
            merged_session_metadata = session_metadata or {}
            if context_type and context_id:
                merged_session_metadata["context_type"] = context_type
                merged_session_metadata["context_id"] = context_id

            session_data = {
                "member_id": self.member_id,
                "title": title,
                "status": "active",
                "context_type": context_type,
                "context_metadata": context_metadata or {},
                "session_metadata": merged_session_metadata,
                "message_count": 0,
            }

            response = self.supabase.schema('agents').table("chatbot_sessions").insert(session_data).execute()

            if response.data:
                self.session_id = response.data[0]["id"]
                self._sequence = 0
                print(f"Created new session: {self.session_id}")
                return self.session_id
        except Exception as e:
            print(f"Error creating session: {e}")

        return None

    def update_session_metadata(self, updates: Dict[str, Any]) -> None:
        """Merge updates into session_metadata for an existing session.

        Uses a JSONB merge so existing keys not in `updates` are preserved.
        No-op if supabase or session_id is not set.
        """
        if not self.supabase or not self.session_id:
            return
        try:
            row = (
                self.supabase.schema("agents").table("chatbot_sessions")
                .select("session_metadata")
                .eq("id", self.session_id)
                .limit(1)
                .execute()
            )
            current: Dict[str, Any] = {}
            if row.data:
                current = row.data[0].get("session_metadata") or {}
            merged = {**current, **updates}
            self.supabase.schema("agents").table("chatbot_sessions").update({
                "session_metadata": merged,
                "updated_at": datetime.utcnow().isoformat(),
            }).eq("id", self.session_id).execute()
        except Exception as e:
            print(f"Warning: update_session_metadata failed: {e}")

    def load_session_persona(self) -> Optional[str]:
        """Load persona stored in session_metadata.

        Prefer using the session_metadata returned by load_messages() to avoid
        an extra DB round-trip. This method exists as a standalone fallback.
        """
        if not self.supabase or not self.session_id:
            return None
        try:
            response = (
                self.supabase.schema("agents").table("chatbot_sessions")
                .select("session_metadata")
                .eq("id", self.session_id)
                .limit(1)
                .execute()
            )
            if response.data:
                return response.data[0].get("session_metadata", {}).get("persona")
        except Exception as e:
            print(f"Warning: load_session_persona failed: {e}")
        return None

    # ─── Private API ──────────────────────────────────────────────────────────

    async def _run_title_callback(self) -> Optional[str]:
        """Execute the title callback and persist the result."""
        try:
            new_title = await self._title_callback()
            if new_title:
                await self.update_title(new_title)
            return new_title
        except Exception as e:
            print(f"[SessionManager] Title callback failed: {e}", flush=True)
            return None

    def _append_to_pending(
        self,
        role: str,
        content: str,
        metadata: Dict[str, Any],
        files: Optional[List[Dict[str, Any]]] = None
    ) -> None:
        """Append save operation to pending batch."""
        if self.auto_save and self.session_id:
            self._pending_saves.append({
                "role": role,
                "content": content,
                "metadata": metadata,
                "files": files
            })

            if time() - self._last_flush > self._flush_interval:
                asyncio.create_task(self.flush_pending())
