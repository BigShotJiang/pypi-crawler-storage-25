import asyncio
import os
from typing import Any, Dict, List, Optional

import httpx

from utils.data_conversion import (
    convert_to_pdf,
    get_mime_type_from_filename,
    get_file_category,
)


class SubmissionResolver:
    """
    Lean submission resolver for grading pipeline v2.

    Responsibilities:
    1. Resolve space, lesson, challenge, member metadata (batched DB)
    2. Check prior submissions
    3. Create challenge_submission record
    4. Download + upload files in parallel
    5. Fetch rubric (overlapped with file upload)
    6. Return unified resolution dict

    Does NOT:
    - Extract file content (agents read files natively)
    - Resolve challenge_type separately (computed once, passed through)
    """

    def __init__(self):
        from supabase import create_client
        self.supabase_url = os.getenv("AIO_SUPABASE_URL")
        self.supabase_key = os.getenv("AIO_SUPABASE_SERVICE_ROLE_KEY")
        self.supabase = create_client(self.supabase_url, self.supabase_key)
        # B4: Rubric cache keyed by challenge_uuid
        self._rubric_cache: dict[str, str] = {}

    async def resolve_and_register(
        self,
        email: str,
        space_name: str,
        text_content: str,
        files: Optional[List[Dict[str, Any]]] = None,
        skip_prior_check: bool = False,
        resolved_challenge_name: Optional[str] = None,
        challenge_metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Resolve all metadata, create submission, upload files, fetch rubric.

        Returns:
            On success:
            {
                "submission_id": int,
                "student_name": str,
                "challenge_name": str,
                "challenge_id": int | None,
                "challenge_uuid": str | None,
                "challenge_type": str,           # "mission" | "mission_final" | "micro_session"
                "rubric_content": str,
                "file_attachments": [             # Ready for multimodal agents
                    {"name": str, "url": str, "mime_type": str},
                    ...
                ],
                "space_group_id": str,
                "space_id": str,
                "lesson_context": str,
            }

            On prior-submission:
            {
                "needs_resubmit_confirmation": True,
                "prior_submission": {"score": float, ...},
                "challenge_type": str,
                "challenge_name": str,
                "challenge_uuid": str | None,
            }

            On error:
            {"error": str}
        """
        # Edge case: files=None
        if files is None:
            files = []

        # Initialize variables
        space_id: Optional[str] = None
        space_group_id: Optional[str] = None
        challenge_id: Optional[int] = None
        challenge_uuid: Optional[str] = None
        event_id: Optional[int] = None
        challenge_name: str = ""
        challenge_type: str = "mission"
        lesson_context: str = ""
        lesson: Optional[Dict[str, Any]] = None
        rubric_from_challenge: str = ""

        # ── Phase A: Resolve Metadata (Batch DB Queries) ──
        if challenge_metadata and challenge_metadata.get("challenge_uuid"):
            # Challenges-first path: everything resolved from challenges table + challenge_metadata.
            # No lessons table queries — challenge_uuid is the single source of truth.
            challenge_uuid = challenge_metadata["challenge_uuid"]
            challenge_resp = self.supabase.table("challenges") \
                .select("id, name, type, mission_id, rubric_content, body_html") \
                .eq("id", challenge_uuid).limit(1).execute()

            if not challenge_resp.data:
                return {"error": f"Challenge not found: {challenge_uuid}"}

            challenge = challenge_resp.data[0]
            space_id = challenge.get("mission_id") or challenge_metadata.get("space_id")
            challenge_name = resolved_challenge_name or challenge.get("name") or ""
            challenge_type = challenge.get("type", "mission")
            rubric_from_challenge = challenge.get("rubric_content", "")

            # Build lesson_context from challenge body_html (no lessons lookup needed)
            body = challenge.get("body_html") or challenge_metadata.get("body_html") or challenge_metadata.get("markdown") or ""
            import markdownify
            lesson_context = f"{challenge_name}\nDescription:\n {markdownify.markdownify(body)}\n"
            # challenge_id stays None — chat-based grading links via challenge_uuid only

            # Resolve space_group_id from spaces table (needed for member + file upload)
            if space_id:
                space_resp = self.supabase.table("spaces") \
                    .select("id, space_group_id") \
                    .eq("id", space_id).limit(1).execute()
                if space_resp.data:
                    space_group_id = space_resp.data[0].get("space_group_id")

            # Use space_group_id from challenge_metadata as fallback
            if not space_group_id:
                space_group_id = challenge_metadata.get("space_group_id")

            if not space_group_id:
                return {"error": f"Could not resolve space_group_id for challenge {challenge_uuid}"}

            member_result = await self._fetch_member(email, space_group_id)
            if member_result.get("error"):
                return member_result

            student_id = member_result["id"]
            student_name = member_result.get("author_name", "Unknown")

        else:
            # Legacy path: resolve from space_name
            space_resp = self.supabase.table("spaces") \
                .select("id, space_group_id, name") \
                .ilike("name", f"%{space_name}%").limit(1).execute()

            if not space_resp.data:
                return {"error": f"Space not found: {space_name}"}

            space_id = space_resp.data[0]["id"]
            space_group_id = space_resp.data[0].get("space_group_id")

            # Parallel: member + lessons
            member_task = self._fetch_member(email, space_group_id)
            lessons_task = self._fetch_lessons(space_id)
            member_result, lessons_result = await asyncio.gather(member_task, lessons_task)

            if member_result.get("error"):
                return member_result

            if not lessons_result:
                return {"error": f"No lessons found for space {space_id}"}

            student_id = member_result["id"]
            student_name = member_result.get("author_name", "Unknown")

            # Resolve challenge from lessons
            if resolved_challenge_name:
                matched = [l for l in lessons_result if l["name"].strip().lower() == resolved_challenge_name.strip().lower()]
                if not matched:
                    matched = [l for l in lessons_result if resolved_challenge_name.strip().lower() in l["name"].strip().lower()]
                if not matched:
                    matched = [l for l in lessons_result if l["type"] == "final_assignment"]
                if not matched:
                    matched = [lessons_result[0]] if lessons_result else []
            else:
                final_assignment = [l for l in lessons_result if l["type"] == "final_assignment"]
                matched = final_assignment if final_assignment else ([lessons_result[0]] if lessons_result else [])

            if not matched:
                return {"error": f"No lesson found matching '{resolved_challenge_name}' in space {space_id}"}

            lesson = matched[0]
            challenge_id = lesson["id"]
            challenge_name = lesson["name"]
            import markdownify
            lesson_context = f"{lesson['name']}\nDescription:\n {markdownify.markdownify(lesson.get('body_html', ''))}\n"
            challenge_type = lesson.get("type", "mission")

        # ── Phase B: Prior Submission Check ──
        if not skip_prior_check:
            prior = await self._check_prior_submission(
                student_id=student_id,
                challenge_id=challenge_id,
                challenge_uuid=challenge_uuid,
                challenge_type=challenge_type,
                challenge_name=challenge_name,
                student_name=student_name,
                email=email,
                space_id=space_id,
                space_name=space_name,
                space_group_id=space_group_id,
                lesson_context=lesson_context,
            )
            if prior:
                return prior

        # ── Phase C: Create Submission + Upload Files + Fetch Rubric (Parallel) ──
        create_task = self._create_submission(
            student_id=student_id,
            challenge_id=challenge_id,
            challenge_uuid=challenge_uuid,
            space_group_id=space_group_id,
            text_content=text_content,
        )

        upload_task = self._upload_files_parallel(
            files=files,
            space_group_id=space_group_id,
            space_id=space_id or event_id,
            student_id=student_id,
        )

        rubric_task = self._fetch_rubric(
            challenge_id=challenge_id,
            space_id=space_id,
            challenge_uuid=challenge_uuid,
            rubric_from_challenge=rubric_from_challenge,
            lesson_context=lesson_context,
        )

        submission_id, file_attachments, rubric_content = await asyncio.gather(
            create_task, upload_task, rubric_task
        )

        return {
            "submission_id": submission_id,
            "student_name": student_name,
            "challenge_name": challenge_name,
            "challenge_id": challenge_id,
            "challenge_uuid": challenge_uuid,
            "challenge_type": challenge_type,
            "rubric_content": rubric_content,
            "file_attachments": file_attachments,
            "space_group_id": space_group_id,
            "space_id": space_id,
            "lesson_context": lesson_context,
        }

    async def _fetch_member(self, email: str, space_group_id: str) -> Dict[str, Any]:
        """Fetch space_group_member by email."""
        resp = self.supabase.table("space_group_members") \
            .select("id, author_name, author_email") \
            .eq("author_email", email).eq("space_group_id", space_group_id) \
            .limit(1).execute()
        if not resp.data:
            # Fallback: search by email only across all space groups
            resp = self.supabase.table("space_group_members") \
                .select("id, author_name, author_email") \
                .eq("author_email", email) \
                .limit(1).execute()
        if not resp.data:
            return {"error": f"Member not found: {email}"}
        return resp.data[0]

    async def _fetch_lesson_by_name(self, space_id: str, challenge_name: str) -> Optional[Dict]:
        """Fetch a specific lesson by space_id and name (exact match, then ilike fallback)."""
        resp = self.supabase.table("lessons") \
            .select("id, name, type, body_html") \
            .eq("space_id", space_id).eq("name", challenge_name) \
            .limit(1).execute()
        if resp.data:
            return resp.data[0]
        # Fallback: case-insensitive partial match
        resp = self.supabase.table("lessons") \
            .select("id, name, type, body_html") \
            .eq("space_id", space_id).ilike("name", f"%{challenge_name}%") \
            .limit(1).execute()
        return resp.data[0] if resp.data else None

    async def _fetch_lessons(self, space_id: str) -> List[Dict]:
        """Fetch all lessons for a space."""
        resp = self.supabase.table("lessons") \
            .select("id, name, type, body_html") \
            .eq("space_id", space_id).execute()
        return resp.data or []

    async def _check_prior_submission(
        self,
        student_id: int,
        challenge_id: Optional[int],
        challenge_uuid: Optional[str],
        challenge_type: str,
        challenge_name: str,
        student_name: str,
        email: str,
        space_id: Optional[str],
        space_name: str,
        space_group_id: str,
        lesson_context: str,
    ) -> Optional[Dict[str, Any]]:
        """
        Check for prior passed or ungraded submissions.
        Returns dict with needs_resubmit_confirmation if found, else None.

        IMPORTANT: Copy the exact logic from process_submission lines 1449-1557 of aio.py.
        This includes:
        - Query for grade_status='pass'
        - Fallback: query score >= 80
        - Query for ungraded submissions
        """
        # Chat-based grading always links challenge_submissions via challenge_uuid.
        # challenge_id (lessons.id integer) is only used in the standalone grading_workflow.py.
        if challenge_uuid is None:
            return None  # Cannot check prior submission without challenge_uuid

        SELECT_COLS = "id, score, grade_status, status, graded_at, submitted_at, feedback, student_input_text"

        # 3.5a: Check for any PASSED submission by challenge_uuid
        passed_resp = (
            self.supabase.table("challenge_submissions")
            .select(SELECT_COLS)
            .eq("student_id", student_id)
            .eq("challenge_uuid", challenge_uuid)
            .eq("grade_status", "pass")
            .order("graded_at", desc=True)
            .limit(1)
            .execute()
        )
        if not passed_resp.data:
            # Fallback: check by score >= 80 for pre-fix rows without grade_status
            passed_resp = (
                self.supabase.table("challenge_submissions")
                .select(SELECT_COLS)
                .eq("student_id", student_id)
                .eq("challenge_uuid", challenge_uuid)
                .eq("status", "graded")
                .gte("score", 80)
                .order("graded_at", desc=True)
                .limit(1)
                .execute()
            )

        if passed_resp and passed_resp.data:
            existing = passed_resp.data[0]
            score_value = float(existing.get("score") or 0)
            print(f"   ⚠️ Prior passed submission found: score={score_value}, grade_status={existing.get('grade_status')}")

            return {
                "success": True,
                "needs_resubmit_confirmation": True,
                "prior_submission": {
                    "id": existing["id"],
                    "score": score_value,
                    "grade_status": existing.get("grade_status"),
                    "graded_at": existing.get("graded_at"),
                    "status": existing.get("status"),
                    "feedback": existing.get("feedback", ""),
                    "content": existing.get("student_input_text", ""),
                },
                "challenge_type": challenge_type,
                "student_id": student_id,
                "student_name": student_name,
                "student_email": email,
                "space_id": space_id,
                "space_name": space_name,
                "space_group_id": space_group_id,
                "challenge_name": challenge_name,
                "challenge_id": challenge_id,
                "challenge_uuid": challenge_uuid,
                "lesson_context": lesson_context,
            }

        # 3.5b: No passed submission — check for ungraded submission to reuse
        ungraded_resp = (
            self.supabase.table("challenge_submissions")
            .select("id, status, grade_status")
            .eq("student_id", student_id)
            .eq("challenge_uuid", challenge_uuid)
            .order("submitted_at", desc=True)
            .limit(1)
            .execute()
        )
        existing = ungraded_resp.data[0] if ungraded_resp.data else None

        if existing:
            existing_status = existing.get("status")
            existing_grade = existing.get("grade_status")
            if existing_status == "submitted" and existing_grade is None:
                print(f"   ♻️ Reusing ungraded submission: {existing['id']}")
            else:
                print(f"   📝 Prior submission with redo — creating new submission")

        return None

    async def _fetch_existing_challenge_submission(
        self, student_id: int, challenge_uuid: str
    ) -> Optional[Dict]:
        """Fetch existing submission by challenge_uuid for the chat-based flow."""
        resp = (
            self.supabase.table("challenge_submissions")
            .select("id, status, grade_status")
            .eq("student_id", student_id)
            .eq("challenge_uuid", challenge_uuid)
            .order("submitted_at", desc=True)
            .limit(1)
            .execute()
        )
        return resp.data[0] if resp.data else None

    async def _create_submission(
        self, student_id: int, challenge_id: Optional[int],
        challenge_uuid: Optional[str], space_group_id: str,
        text_content: Optional[str] = None,
    ) -> int:
        """Create challenge_submission record, return submission_id.
        
        Chat-based grading always links via challenge_uuid. challenge_id is
        intentionally omitted here — it belongs to the standalone grading_workflow.py only.
        """
        insert_data: Dict[str, Any] = {
            "student_id": student_id,
            "status": "submitted",
        }
        if challenge_uuid is not None:
            insert_data["challenge_uuid"] = challenge_uuid
        if text_content is not None:
            insert_data["student_input_text"] = text_content
        resp = self.supabase.table("challenge_submissions").insert(insert_data).execute()
        return resp.data[0]["id"]

    async def _upload_files_parallel(
        self,
        files: List[Dict[str, Any]],
        space_group_id: str,
        space_id: str,
        student_id: int,
    ) -> List[Dict[str, Any]]:
        """
        Download + upload all files in parallel.
        Returns list of file_attachment dicts: [{name, url, mime_type}]

        This replaces the sequential for-loop in v1 process_submission (lines 1597-1692).
        """
        if not files:
            return []

        semaphore = asyncio.Semaphore(5)
        seen_file_keys: set[tuple[str, str]] = set()
        seen_storage_ids: set[str] = set()

        async def _process_one(file_dict: Dict) -> Optional[Dict]:
            async with semaphore:
                file_url = file_dict.get("url")
                file_name = file_dict.get("file_name", file_url.split("/")[-1].split("?")[0])
                file_key = (file_url or "", file_name or "")

                # Dedup check (thread-safe since we're in async single-thread)
                if file_key in seen_file_keys:
                    print(f"   ⚠ Skipping duplicate file input: {file_name or file_url}")
                    return None
                seen_file_keys.add(file_key)

                # Download
                file_bytes = await self._download_file(file_url)
                if not file_bytes:
                    print(f"   ⚠ Skipping file: {file_url}")
                    return None

                if not file_name:
                    file_name = f"file_{id(file_dict)}"

                # Convert docx/txt to PDF
                if file_name.endswith(".docx") or file_name.endswith(".txt"):
                    file_obj = convert_to_pdf(file_bytes, file_name)
                    file_bytes = file_obj["data"]
                    file_name = file_obj["filename"]

                supabase_url = os.getenv("AIO_SUPABASE_URL", "")
                supabase_storage_bucket = "submission_attachments"
                storage_info = None

                # Skip re-upload if already in Supabase
                if supabase_url in file_url and supabase_storage_bucket in file_url:
                    mime_type = get_mime_type_from_filename(file_name)
                    return {"name": file_name, "url": file_url, "mime_type": mime_type}

                storage_info = await self._upload_to_storage(
                    file_bytes, file_name, space_group_id, space_id, student_id
                )

                if storage_info and storage_info.get("id"):
                    # Dedup storage IDs
                    sid = storage_info.get("id")
                    if sid in seen_storage_ids:
                        return None
                    seen_storage_ids.add(sid)

                    return {
                        "name": file_name,
                        "url": storage_info.get("url", ""),
                        "mime_type": storage_info.get("mime_type", "application/octet-stream"),
                    }
                return None

        results = await asyncio.gather(
            *[_process_one(f) for f in files],
            return_exceptions=True,
        )

        return [r for r in results if isinstance(r, dict)]

    async def _download_file(self, url: str) -> Optional[bytes]:
        """Download file from URL."""
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                resp = await client.get(url, follow_redirects=True)
                resp.raise_for_status()
                return resp.content
        except Exception as e:
            print(f"⚠️ Download failed: {url} — {e}")
            return None

    async def _upload_to_storage(
        self, file_bytes: bytes, file_name: str,
        space_group_id: str, space_id: str, student_id: int,
    ) -> Optional[Dict[str, Any]]:
        """Upload file to Supabase storage.
        
        This method should be mocked in tests. The implementation here
        is for production use only.
        """
        try:
            from connectors.supabase_client.storage import upload_to_storage

            # Build storage path: submission_attachments/{space_group_id}/{space_id}/{student_id}/{file_name}
            formatted_filename = file_name.replace(" - ", "_").replace(" ", "_")
            storage_path = f"submission_attachments/{space_group_id}/{space_id}/{student_id}/{formatted_filename}"
            mime_type = get_mime_type_from_filename(file_name)

            result = upload_to_storage(
                self.supabase,
                mime_type,
                file_bytes,
                "submission_attachments",
                storage_path,
                url_exp=60 * 60 * 24 * 365,
            )

            return {
                "id": result.get("id"),
                "url": result.get("url"),
                "mime_type": mime_type,
            }
        except Exception as e:
            print(f"⚠️ Upload to storage failed: {e}")
            return None

    async def _fetch_rubric(
        self,
        challenge_id: Optional[int],
        space_id: Optional[str],
        challenge_uuid: Optional[str],
        rubric_from_challenge: str,
        lesson_context: str,
    ) -> str:
        """
        Fetch rubric content. Priority:
        1. rubric_from_challenge (already fetched from challenges table)
        2. In-memory cache check (self._rubric_cache by challenge_uuid) — B4
        3. Supabase rubric lookup by challenge_uuid or challenge_id
        4. LLM-generated rubric from lesson_context
        """
        # 1. Direct rubric from challenge table
        if rubric_from_challenge:
            return rubric_from_challenge

        # 2. Cache check (B4)
        if challenge_uuid and challenge_uuid in self._rubric_cache:
            print(f"✅ Rubric cache hit for challenge_uuid: {challenge_uuid}")
            return self._rubric_cache[challenge_uuid]

        # 3. Supabase lookup
        rubric_content = None
        if challenge_uuid:
            response = (
                self.supabase.table("challenges")
                .select("rubric_content")
                .eq("id", challenge_uuid)
                .limit(1)
                .execute()
            )
            if response.data:
                rubric_content = response.data[0].get("rubric_content")
            if rubric_content:
                print(f"✅ Fetched rubric by challenge_uuid: {challenge_uuid}")
                self._rubric_cache[challenge_uuid] = rubric_content
                return rubric_content

        # Fallback: lookup by space_id (mission_id)
        if space_id:
            # Prioritize is_legacy=False challenges
            response = (
                self.supabase.table("challenges")
                .select("rubric_content")
                .eq("mission_id", space_id)
                .eq("is_legacy", False)
                .execute()
            )
            if response.data and len(response.data) > 0:
                rubric_content = response.data[0].get("rubric_content")

            # Fallback to is_legacy=True if no rubric found
            if not rubric_content:
                print(f"⚠️ No non-legacy rubric found for mission {space_id}, falling back to legacy")
                legacy_response = (
                    self.supabase.table("challenges")
                    .select("rubric_content")
                    .eq("mission_id", space_id)
                    .eq("is_legacy", True)
                    .execute()
                )
                if legacy_response.data and len(legacy_response.data) > 0:
                    rubric_content = legacy_response.data[0].get("rubric_content")

        if rubric_content:
            return rubric_content

        # 4. LLM fallback
        print("⚠️ No rubric found in DB, generating from lesson context...")
        from connectors.openrouter.llm import OpenRouterMultimodalLLM
        from agents.prompts import CENTRAL_PROMPT_MAPPING

        try:
            llm = OpenRouterMultimodalLLM(model="google/gemini-2.5-flash-lite")
            messages = llm.construct_message_list(
                system_prompt=CENTRAL_PROMPT_MAPPING.get("rubric_generation"),
                user_prompt=lesson_context,
            )
            response = await llm.achat(
                messages,
                sort="latency",
            )
            response = (
                response.message.content.strip()
                .replace("```markdown", "")
                .replace("```", "")
            )

            if response:
                # Cache the generated rubric
                if challenge_uuid:
                    self._rubric_cache[challenge_uuid] = response
                return response
        except Exception as e:
            print(f"❌ Error generating rubric from lesson context: {e}")

        return ""
