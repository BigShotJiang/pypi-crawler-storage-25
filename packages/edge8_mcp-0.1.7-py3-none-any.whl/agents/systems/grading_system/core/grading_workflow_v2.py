"""
Grading Workflow Orchestrator - Supabase Edition
"""

import os
import asyncio
from typing import Dict, Any, Optional, List, AsyncGenerator, Union
from datetime import datetime
from time import time
import json

from agents.systems.grading_system.models import GradingReport
from agents.systems.grading_system.storage import RubricStore, SubmissionStore
from agents.systems.grading_system.core.grading_pipeline_v2 import GradingPipelineV2
from agents.subagents.grading import SubmissionPostAgent
from agents.tools.shared import MultimodalFileExtractor
from agents.tools.database.aio import ChallengeSubmissionTool
from agents.tools.lark.messages_tools import LarkSearchUserAndSendMessageHandler
from agents.tools.lark.auth_tools import LarkGetAuthSessionHandler
from connectors.lark_interactions.contacts import Users
from dotenv import load_dotenv

load_dotenv()


class OptimizedGradingWorkflow:
    """Optimized grading workflow with parallel file processing using Supabase as the data source"""

    def __init__(self) -> None:
        self.pipeline_v2 = GradingPipelineV2()
        self.submission_post_agent = SubmissionPostAgent(model="openai/gpt-5-nano")
        self.challenge_submission_tool = ChallengeSubmissionTool()
        self.multimodal_extractor = MultimodalFileExtractor()

        supabase_url = os.getenv("AIO_SUPABASE_URL")
        supabase_key = os.getenv("AIO_SUPABASE_SERVICE_ROLE_KEY")
        if not supabase_url or not supabase_key:
            raise ValueError("AIO_SUPABASE_URL and AIO_SUPABASE_SERVICE_ROLE_KEY required")
        from supabase import create_client, Client
        self.supabase: "Client" = create_client(supabase_url, supabase_key)

        # Storage layer (extracted)
        self.rubric_store = RubricStore(self.supabase)
        self.submission_store = SubmissionStore(self.supabase)

    async def process_direct_submission(self, **kwargs) -> Dict[str, Any]:
        """Non-streaming entrypoint. Collects events from astream_process_direct_submission."""
        result = None
        async for event in self.astream_process_direct_submission(**kwargs):
            if event.get("type") == "result":
                result = event.get("data", {})
                result["message"] = event.get("message", "")
            elif event.get("type") == "error":
                return {"error": event.get("message", "Unknown error")}
            elif event.get("type") == "resubmit_warning":
                return {
                    "needs_resubmit_confirmation": True,
                    "prior_submission": event.get("prior_submission"),
                    "message": event.get("message"),
                }
        return result or {"error": "No result produced"}

    async def astream_process_direct_submission(
        self,
        email: str,
        space_name: str,
        text_content: str,
        files: Optional[List[dict]] = None,
        skip_prior_check: bool = False,
        resolved_challenge_name: Optional[str] = None,
        challenge_metadata: Optional[Dict] = None,
        student_inputs: Optional[Dict] = None,
        prior_submission_context: Optional[Dict] = None,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Streaming version of process_direct_submission — delegates to GradingPipelineV2."""
        async for event in self.pipeline_v2.astream_grade(
            email=email, space_name=space_name, text_content=text_content,
            files=files, skip_prior_check=skip_prior_check,
            resolved_challenge_name=resolved_challenge_name,
            challenge_metadata=challenge_metadata,
            student_inputs=student_inputs,
            prior_submission_context=prior_submission_context,
        ):
            yield event

    # =========================================================================
    # Posting / confirmation workflow methods (GradingEventHandler depends on)
    # =========================================================================

    async def grading_with_posting(
        self,
        email: str,
        space_name: str,
        text_content: str,
        files: Optional[List[dict]] = None,
        post_id: Optional[Union[str, int]] = None,
        circle_file_urls: Optional[List[str]] = None,
        challenge_name: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Non-streaming grading (Circle posting removed)."""
        try:
            grading_outputs = await self.process_direct_submission(
                email=email, space_name=space_name, files=files, text_content=text_content,
            )
            return grading_outputs
        except Exception as e:
            return {"error": str(e)}

    async def astream_grading_with_posting(
        self,
        email: str,
        space_name: str,
        text_content: str,
        files: Optional[List[dict]] = None,
        post_id: Optional[Union[str, int]] = None,
        circle_file_urls: Optional[List[str]] = None,
        challenge_name: Optional[str] = None,
        skip_prior_check: bool = False,
        resolved_challenge_name: Optional[str] = None,
        challenge_metadata: Optional[Dict[str, Any]] = None,
        student_inputs: Optional[Dict[str, Dict[str, str]]] = None,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Streaming version of grading (Circle posting removed)."""
        start_time = time()
        deadline = start_time + 180
        grading_outputs = None

        try:
            async for event in self.astream_process_direct_submission(
                email=email, space_name=space_name, text_content=text_content,
                files=files, skip_prior_check=skip_prior_check,
                resolved_challenge_name=resolved_challenge_name,
                challenge_metadata=challenge_metadata,
                student_inputs=student_inputs,
            ):
                if event["type"] == "error":
                    yield event
                    return
                elif event["type"] == "resubmit_warning":
                    yield event
                    return
                elif event["type"] == "result":
                    grading_outputs = event["data"]
                    yield event
                    break
                else:
                    yield event

                if time() > deadline:
                    yield {"type": "error", "message": "Grading timed out after 3 minutes"}
                    return

            if grading_outputs is None:
                yield {"type": "error", "message": "Grading did not produce results"}
                return

            grading_outputs["execution_time"] = time() - start_time
            yield {"type": "result", "data": grading_outputs}

        except Exception as e:
            yield {"type": "error", "message": str(e)}

    @staticmethod
    def _is_affirmative(text: str) -> bool:
        """Check if user response is affirmative."""
        normalized = text.lower().strip().rstrip(".!,")
        affirmatives = {
            "yes", "y", "yeah", "sure", "ok", "okay", "proceed",
            "go", "yep", "yup", "go ahead", "do it", "let's go",
            "please", "post", "share", "submit", "confirm", "approved",
        }
        if normalized in affirmatives:
            return True
        first_word = normalized.split()[0] if normalized else ""
        return first_word in {"yes", "y", "yeah", "sure", "ok", "okay", "yep", "yup"}

    async def handle_mission_confirmation_workflow(
        self,
        user_input: str,
        submission_metadata: Dict[str, Any],
        circle_file_urls: Optional[List[str]] = None,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Handle mission confirmation workflow."""
        if self._is_affirmative(user_input):
            async for event in self._process_grading_after_confirmation(
                submission_metadata=submission_metadata,
                circle_file_urls=circle_file_urls,
            ):
                yield event
        else:
            async for event in self._handle_submission_cancellation():
                yield event

    async def _process_grading_after_confirmation(
        self,
        submission_metadata: Dict[str, Any],
        circle_file_urls: Optional[List[str]] = None,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Process grading after user confirms submission."""
        email = submission_metadata.get("email", "")
        space_name = submission_metadata.get("space_name", "")
        text_content = submission_metadata.get("text_content", "")
        files = submission_metadata.get("files", [])
        resolved_challenge_name = submission_metadata.get("resolved_challenge_name")
        challenge_metadata = submission_metadata.get("challenge_metadata")
        student_inputs = submission_metadata.get("student_inputs")

        grading_data = None
        async for event in self.astream_process_direct_submission(
            email=email, space_name=space_name, text_content=text_content,
            files=files, skip_prior_check=False,
            resolved_challenge_name=resolved_challenge_name,
            challenge_metadata=challenge_metadata,
            student_inputs=student_inputs,
        ):
            if event["type"] == "result":
                grading_data = event["data"]
                break
            yield event

        if not grading_data:
            yield {"type": "error", "message": "Grading failed to complete"}
            return

        challenge_type = grading_data.get("challenge_type", "mission")
        raw_score = grading_data.get("score", "0")
        try:
            score = float(str(raw_score).replace("%", ""))
        except (ValueError, TypeError):
            score = 0.0

        # Only mission_final with score >= 80 gets posting confirmation.
        # Non-final challenges always show feedback directly — never set POSTING_CONFIRMATION state.
        if challenge_type == "mission_final" and score >= 80:
            async for event in self._handle_high_score_result(grading_data=grading_data):
                yield event
        else:
            async for event in self._handle_low_score_result(grading_data=grading_data, score=score):
                yield event

    async def _handle_high_score_result(
        self, grading_data: Dict[str, Any]
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Handle grading result with score >= 80."""
        yield {"type": "grading_complete", "action": "request_posting_confirmation", "grading_data": grading_data}

    async def _handle_low_score_result(
        self, grading_data: Dict[str, Any], score: float
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Handle grading result with score < 80."""
        yield {
            "type": "grading_complete", "action": "show_low_score_feedback",
            "message": grading_data.get("feedback"), "grading_data": grading_data, "score": score,
        }

    async def _handle_submission_cancellation(self) -> AsyncGenerator[Dict[str, Any], None]:
        """Handle user declining submission."""
        yield {"type": "submission_cancelled", "message": "Submission cancelled. Let me know when you're ready to submit."}

    async def handle_posting_confirmation_workflow(
        self,
        user_input: str,
        grading_data: Dict[str, Any],
        circle_file_urls: Optional[List[str]] = None,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Handle posting confirmation workflow."""
        if self._is_affirmative(user_input):
            async for event in self._handle_posting_success(
                grading_data=grading_data, circle_file_urls=circle_file_urls
            ):
                yield event
        else:
            async for event in self._handle_posting_decline():
                yield event

    async def _handle_posting_success(
        self, grading_data: Dict[str, Any], circle_file_urls: Optional[List[str]]
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Handle successful posting to Circle."""
        post_result = await self.post_grading(
            grading_message=grading_data.get("grading_message", ""),
            student_message=grading_data.get("submission_content", ""),
            mission_space_name=grading_data.get("mission_name", ""),
            challenge_name=grading_data.get("challenge_name"),
            student_name=grading_data.get("student_name"),
            student_email=grading_data.get("email"),
            space_group_id=grading_data.get("space_group_id"),
            circle_file_urls=circle_file_urls,
        )
        yield {"type": "posting_complete", "post_result": post_result, "grading_data": grading_data}

    async def _handle_posting_decline(self) -> AsyncGenerator[Dict[str, Any], None]:
        """Handle user declining posting."""
        yield {
            "type": "posting_declined",
            "message": "Your submission has been graded but not posted to Circle. Let me know if you'd like to post it later.",
        }

    # =========================================================================
    # Backward-compatible method wrappers (delegate to storage layer)
    def _resolve_challenge_type(self, submission_id: int) -> str:
        """Backward-compatible wrapper - delegates to submission_store."""
        return self.submission_store._resolve_challenge_type(submission_id)

    async def store_grading_results(
        self, submission_id: int, report: GradingReport, challenge_type: Optional[str] = None
    ) -> bool:
        """Backward-compatible wrapper - delegates to submission_store."""
        return await self.submission_store.store_grading_results(submission_id, report, challenge_type)

    async def update_overall_feedback(self, submission_id: int, overall_feedback: str) -> bool:
        """Backward-compatible wrapper - delegates to submission_store."""
        return await self.submission_store.update_overall_feedback(submission_id, overall_feedback)

    async def fetch_submission_attachments(self, submission_id: int) -> Optional[List[Dict]]:
        """Backward-compatible wrapper - delegates to submission_store."""
        return await self.submission_store.fetch_submission_attachments(submission_id)

    async def _fetch_prior_submission_content(self, submission_id: int) -> Optional[Dict[str, Any]]:
        """Backward-compatible wrapper - delegates to submission_store."""
        return await self.submission_store.fetch_prior_submission_content(submission_id)

    async def fetch_rubric_from_supabase(
        self, lesson_id: Optional[int] = None, space_id: Optional[int] = None, challenge_uuid: Optional[str] = None
    ) -> Optional[str]:
        """Backward-compatible wrapper - delegates to rubric_store."""
        return await self.rubric_store.fetch_rubric(challenge_uuid=challenge_uuid, space_id=space_id)

    async def generate_rubric_from_lesson_context(self, lesson_context: str, lesson_id: int) -> Optional[str]:
        """Backward-compatible wrapper - delegates to rubric_store."""
        return await self.rubric_store.generate_rubric(lesson_context=lesson_context, lesson_id=lesson_id)


__all__ = ["OptimizedGradingWorkflow"]
