"""Lean grading pipeline v2.

3-step flow:
1. resolve_and_register — batched DB + parallel file I/O
2. grade_parallel — scorer + unified reflector in parallel
3. store_results — single DB write
"""

import asyncio
import os
import re
from datetime import datetime
from difflib import SequenceMatcher
from typing import Any, AsyncGenerator, Dict, List, Optional
from time import time

from agents.subagents.grading import (
    ScorerAgentV2,
    UnifiedReflectorV2,
)
from agents.systems.grading_system.models import (
    ScoringResult,
    FeedbackResult,
    GradingReport,
)
from agents.systems.grading_system.core.submission_resolver import SubmissionResolver
from agents.systems.grading_system.formatters import (
    format_resubmission_grading_report,
)


class GradingPipelineV2:
    """Lean grading pipeline v2."""

    def __init__(self):
        from supabase import create_client
        supabase_url = os.getenv("AIO_SUPABASE_URL")
        supabase_key = os.getenv("AIO_SUPABASE_SERVICE_ROLE_KEY")
        self.supabase = create_client(supabase_url, supabase_key)
        self.scorer = ScorerAgentV2()
        self.reflector = UnifiedReflectorV2()
        self.resolver = SubmissionResolver()

    @staticmethod
    def _compile_workbook_inputs(
        student_inputs: Dict[str, Dict[str, str]],
        workbook_content: Optional[List[Dict[str, Any]]] = None,
    ) -> str:
        """Compile structured student_inputs dict into grading-ready markdown.

        Uses workbook_content schema for section/field labels when available.
        Falls back to raw key-value pairs when schema is absent.
        """
        if not student_inputs:
            return ""

        # Build label lookup from schema: section_id -> {field_id -> label}
        section_labels: Dict[str, str] = {}
        field_labels: Dict[str, Dict[str, str]] = {}
        if workbook_content:
            for section in workbook_content:
                sid = section.get("id") or section.get("section_id", "")
                slabel = section.get("label") or section.get("title") or sid
                section_labels[sid] = slabel
                field_labels[sid] = {}
                for field in section.get("fields") or []:
                    fid = field.get("id") or field.get("key", "")
                    flabel = field.get("label") or field.get("name") or fid
                    field_labels[sid][fid] = flabel

        lines = ["## Workbook Submission\n"]
        for section_id, fields in student_inputs.items():
            slabel = section_labels.get(section_id, section_id)
            lines.append(f"### {slabel}")
            for field_id, value in fields.items():
                flabel = (field_labels.get(section_id) or {}).get(field_id, field_id)
                lines.append(f"- {flabel}: {value}")
            lines.append("")

        return "\n".join(lines)

    async def astream_grade(
        self,
        email: str,
        space_name: str,
        text_content: str,
        files: Optional[List[Dict[str, Any]]] = None,
        skip_prior_check: bool = False,
        resolved_challenge_name: Optional[str] = None,
        challenge_metadata: Optional[Dict[str, Any]] = None,
        student_inputs: Optional[Dict[str, Dict[str, str]]] = None,
        prior_submission_context: Optional[Dict[str, Any]] = None,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Streaming async generator that replaces astream_process_direct_submission."""
        flow_start = time()

        # Step 1: Resolve and Register
        yield {"type": "status", "step": "Submission", "message": "Processing your submission..."}

        # If student_inputs are present and text_content is a short conversational phrase,
        # compile the structured answers into grading-ready markdown.
        _CONVERSATIONAL_SUBMIT = {
            "submit", "submit my answers", "ok submit", "done", "i'm done",
            "ready to submit", "i am done", "please submit", "yes", "submit workbook",
        }
        if student_inputs and (
            len(text_content.strip()) < 120
            or text_content.strip().lower() in _CONVERSATIONAL_SUBMIT
        ):
            workbook_schema = (
                (challenge_metadata or {}).get("workbook_content")
                if challenge_metadata
                else None
            )
            compiled = self._compile_workbook_inputs(student_inputs, workbook_schema)
            if compiled:
                text_content = compiled

        resolution = await self.resolver.resolve_and_register(
            email=email,
            space_name=space_name,
            text_content=text_content,
            files=files,
            skip_prior_check=skip_prior_check,
            resolved_challenge_name=resolved_challenge_name,
            challenge_metadata=challenge_metadata,
        )

        if resolution.get("error"):
            yield {"type": "error", "message": resolution["error"]}
            return

        # Handle prior submission check
        # DEBUG: Log resubmission context creation
        print(f"[DEBUG astream_grade] prior_submission_context exists: {prior_submission_context is not None}")
        if prior_submission_context:
            print(f"[DEBUG astream_grade] prior_submission_context.get('feedback') length: {len(str(prior_submission_context.get('feedback', '')))}")
        prior_feedback_val = prior_submission_context.get('feedback', '') if prior_submission_context else None
        print(f"[DEBUG astream_grade] prior_feedback being passed to formatter: {len(str(prior_feedback_val)) if prior_feedback_val else 'None/Empty'}")
        
        # Only create resubmission context if prior_score is provided externally (chatbot resubmission path),
        # use it directly — the caller already has the prior data and confirmed resubmission.
        submission_id = None
        rubric_content = None
        file_attachments = []

        if resolution.get("needs_resubmit_confirmation"):
            prior = resolution["prior_submission"]
            challenge_type = resolution.get("challenge_type", "mission")
            challenge_uuid = resolution.get("challenge_uuid")
            challenge_id = resolution.get("challenge_id")
            space_id = resolution.get("space_id")
            space_group_id = resolution.get("space_group_id", "")

            # Only build from DB result if not already provided by the caller
            # (chatbot resubmission path passes prior_submission_context explicitly)
            if prior_submission_context is None:
                prior_submission_context = {
                    "content": prior.get("content", ""),
                    "score": prior.get("score", 0),
                    "feedback": prior.get("feedback", ""),
                    "submission_id": prior.get("id"),
                }

            # Auto-grading resubmission without confirmation
            submission_id = await self._create_submission_for_resubmission(resolution, text_content)
            if not submission_id:
                yield {"type": "error", "message": "Failed to create submission for resubmission"}
                return

            rubric_content = await self._fetch_rubric_for_resubmission(
                challenge_id=challenge_id,
                space_id=space_id,
                challenge_uuid=challenge_uuid,
                lesson_context=resolution.get("lesson_context", ""),
            )
            file_attachments = []

        # Extract resolution data
        if not submission_id:
            submission_id = resolution.get("submission_id")
            rubric_content = resolution.get("rubric_content")
            file_attachments = resolution.get("file_attachments", [])
            
        if not submission_id:
            yield {"type": "error", "message": "Missing submission_id"}
            return
            
        if not rubric_content:
            yield {"type": "error", "message": "Missing rubric_content"}
            return
            
        student_name = resolution["student_name"]
        challenge_name = resolution["challenge_name"]
        challenge_type = resolution["challenge_type"]
        space_group_id = resolution.get("space_group_id", "")

        yield {
            "type": "status",
            "step": "Submission",
            "message": f"Submission registered. Now grading '{challenge_name}'...",
        }

        # Step 2: Grade in Parallel
        yield {
            "type": "status",
            "step": "Grading",
            "message": f"Scoring and generating feedback for '{challenge_name}'...",
        }

        grade_start = time()

        submission_text = f"""
    **{student_name}'s message:** \n{text_content}\n\n
    **Content from attachments:** \n{"See attached files" if file_attachments else "No attachments submitted"}
    """

        scoring_task = self.scorer.score_submission(
            text_content=submission_text,
            rubric_content=rubric_content,
            challenge_name=challenge_name,
            file_attachments=file_attachments,
        )

        feedback_task = self.reflector.generate_feedback_and_summary(
            text_content=submission_text,
            rubric_content=rubric_content,
            student_name=student_name,
            challenge_name=challenge_name,
            file_attachments=file_attachments,
            prior_submission_content=prior_submission_context.get("content") if prior_submission_context else None,
            prior_score=prior_submission_context.get("score") if prior_submission_context else None,
        )

        try:
            scoring_results, (feedback_results, overall_summary) = await asyncio.gather(
                scoring_task, feedback_task, return_exceptions=False
            )
        except Exception as e:
            yield {"type": "error", "message": f"Grading agents failed: {str(e)}"}
            return

        if not scoring_results or not feedback_results:
            yield {"type": "error", "message": "Grading agents failed to produce results."}
            return

        # Merge scoring + feedback
        merged_feedback = self._merge_scoring_and_feedback(scoring_results, feedback_results)

        total_score = sum(r.score for r in scoring_results)
        max_total_score = sum(r.max_points for r in scoring_results)
        percentage = (total_score / max_total_score * 100) if max_total_score > 0 else 0

        # DEBUG: Log prior_feedback values
        print(f"[DEBUG astream_grade] prior_submission_context exists: {prior_submission_context is not None}")
        if prior_submission_context:
            print(f"[DEBUG astream_grade] prior_submission_context.get('feedback') length: {len(str(prior_submission_context.get('feedback', '')))}")
        prior_feedback_val = prior_submission_context.get('feedback', '') if prior_submission_context else None
        print(f"[DEBUG astream_grade] prior_feedback being passed to formatter: {len(str(prior_feedback_val)) if prior_feedback_val else 'None/Empty'}")
        
        # Generate structured markdown feedback
        structured_feedback = format_resubmission_grading_report(
            student_name=student_name,
            mission_name=space_name,
            challenge_name=challenge_name,
            total_score=percentage,
            feedback_results=[
                {
                    "criterion_name": f.criterion_name,
                    "score": f.score,
                    "max_points": f.max_points,
                    "student_feedback": f.student_feedback,
                    "encouragement": f.encouragement,
                    "actionable_suggestions": f.actionable_suggestions,
                }
                for f in merged_feedback
            ],
            prior_score=prior_submission_context["score"] if prior_submission_context else None,
            prior_feedback=prior_submission_context.get("feedback", "") if prior_submission_context else None,
            series_name="AI Officer Program",
            challenge_type=challenge_type,
        )
        overall_feedback = structured_feedback
        brief_reasoning = structured_feedback[:500] if structured_feedback else ""

        report = GradingReport(
            student_name=student_name,
            mission_name=challenge_name,
            total_score=percentage,
            max_total_score=100,
            scoring_results=scoring_results,
            feedback_results=merged_feedback,
            overall_feedback=overall_feedback,
        )

        yield {
            "type": "status",
            "step": "Grading",
            "message": f"Grading complete — score: {percentage:.1f}%. Saving results...",
        }

        # Store results
        stored = await self._store_results(submission_id, report, challenge_type)

        if not stored:
            yield {"type": "error", "message": "Failed to store grading results."}
            return

        if not prior_submission_context:
            brief_reasoning = overall_summary[:500] if overall_summary else ""
        
        # Build base result data
        result_data = {
            "submission_id": submission_id,
            "student_name": student_name,
            "mission_name": space_name,
            "challenge_name": challenge_name,
            "space_group_id": space_group_id,
            "feedback": overall_feedback,
            "challenge_type": challenge_type,
            "score": percentage,  # Numeric score (0-100) for internal use - display logic handles conditional visibility
            "submission_metadata": {
                "challenge_name": challenge_name,
                "challenge_uuid": resolution.get("challenge_uuid"),
                "challenge_metadata": challenge_metadata,
                "text_content": text_content,
                "files": files,
                "is_resubmission": prior_submission_context is not None,
                "prior_score": prior_submission_context.get("score") if prior_submission_context else None,
            },
        }
        # Component scores are never shown to users - they're embedded in the structured feedback markdown
        
        yield {
            "type": "result",
            "data": result_data,
            "message": brief_reasoning,
        }

    async def _create_submission_for_resubmission(
        self, resolution: Dict[str, Any], text_content: Optional[str] = None
    ) -> Optional[int]:
        """Create submission record for resubmission auto-grading. Retries on transient DB errors (up to 2 retries)."""
        max_retries = 2
        attempt = 0
        
        while attempt <= max_retries:
            try:
                student_id = resolution.get("student_id")
                challenge_uuid = resolution.get("challenge_uuid")
                
                if not student_id or challenge_uuid is None:
                    return None
                    
                insert_data: Dict[str, Any] = {"student_id": student_id, "status": "submitted"}
                if challenge_uuid is not None:
                    if not isinstance(challenge_uuid, str) or len(challenge_uuid) < 3:
                        return None
                    insert_data["challenge_uuid"] = challenge_uuid
                if text_content is not None:
                    insert_data["student_input_text"] = text_content
                
                resp = self.supabase.table("challenge_submissions").insert(insert_data).execute()
                
                if not resp.data or not isinstance(resp.data, list) or len(resp.data) == 0:
                    return None
                    
                submission_id = resp.data[0].get("id")
                return submission_id if submission_id else None
                
            except Exception as e:
                error_msg = str(e).lower()
                attempt += 1
                
                is_retryable = any(p in error_msg for p in ["connection", "timeout", "temporarily", "503", "502"])
                is_fk_violation = "foreign key constraint" in error_msg or "violates foreign key" in error_msg
                
                if is_fk_violation:
                    return None
                if is_retryable and attempt <= max_retries:
                    await asyncio.sleep(0.5 * attempt)
                    continue
                return None
        
        return None

    async def _fetch_rubric_for_resubmission(
        self,
        challenge_id: Optional[int],
        space_id: Optional[str],
        challenge_uuid: Optional[str],
        lesson_context: str,
    ) -> str:
        """Fetch rubric for resubmission auto-grading. Returns empty string on any error."""
        try:
            if challenge_uuid and (not isinstance(challenge_uuid, str) or len(challenge_uuid) < 3):
                challenge_uuid = None
            
            # Try challenges by UUID
            if challenge_uuid:
                try:
                    response = self.supabase.table("challenges").select("rubric_content").eq("id", challenge_uuid).limit(1).execute()
                    if response.data and response.data[0].get("rubric_content"):
                        return response.data[0]["rubric_content"]
                except Exception:
                    pass

            # Try lessons by challenge_id
            if challenge_id and isinstance(challenge_id, int):
                try:
                    response = self.supabase.table("lessons").select("rubric_content").eq("id", challenge_id).limit(1).execute()
                    if response.data and response.data[0].get("rubric_content"):
                        return response.data[0]["rubric_content"]
                except Exception:
                    pass

            # Try challenges by space_id
            if space_id and isinstance(space_id, str):
                try:
                    response = self.supabase.table("challenges").select("rubric_content").eq("mission_id", space_id).eq("is_legacy", False).limit(1).execute()
                    if response.data and response.data[0].get("rubric_content"):
                        return response.data[0]["rubric_content"]
                    legacy_response = self.supabase.table("challenges").select("rubric_content").eq("mission_id", space_id).eq("is_legacy", True).limit(1).execute()
                    if legacy_response.data and legacy_response.data[0].get("rubric_content"):
                        return legacy_response.data[0]["rubric_content"]
                except Exception:
                    pass

            return ""
        except Exception:
            return ""

    def _normalize_criterion_name(self, name: str) -> str:
        """Normalize criterion name for better matching."""
        name = re.sub(r'^\d+[.)\s]+', '', name)
        name = re.sub(r':\s*.*$', '', name)
        name = name.replace('\u2011', '-')
        name = name.replace('\u2013', '-')
        name = name.replace('\u2014', '-')
        return name.strip().lower()

    def _find_best_match(
        self,
        target_name: str,
        candidates: List[ScoringResult],
        threshold: float = 0.6
    ) -> Optional[ScoringResult]:
        """Find best matching criterion using fuzzy string matching."""
        normalized_target = self._normalize_criterion_name(target_name)
        best_match = None
        best_ratio = threshold

        for candidate in candidates:
            normalized_candidate = self._normalize_criterion_name(candidate.criterion_name)
            ratio = SequenceMatcher(None, normalized_target, normalized_candidate).ratio()
            if ratio > best_ratio:
                best_ratio = ratio
                best_match = candidate

        return best_match

    def _merge_scoring_and_feedback(
        self,
        scoring_results: List[ScoringResult],
        feedback_results: List[FeedbackResult]
    ) -> List[FeedbackResult]:
        """Merge scoring data with feedback data using fuzzy matching."""
        merged = []
        used_scoring_indices = set()

        for feedback in feedback_results:
            # Try exact match first
            scoring = next(
                (s for i, s in enumerate(scoring_results)
                 if s.criterion_name.lower() == feedback.criterion_name.lower() and i not in used_scoring_indices),
                None
            )

            # If no exact match, try fuzzy matching
            if not scoring:
                available_scoring = [
                    s for i, s in enumerate(scoring_results)
                    if i not in used_scoring_indices
                ]
                scoring = self._find_best_match(feedback.criterion_name, available_scoring)

            if scoring:
                feedback.score = scoring.score
                feedback.max_points = scoring.max_points
                used_scoring_indices.add(scoring_results.index(scoring))

            merged.append(feedback)

        return merged

    async def _store_results(
        self, submission_id: int, report: GradingReport, challenge_type: str
    ) -> bool:
        """Single DB write."""
        try:
            grading_data = {
                "score": report.total_score,
                "feedback": report.overall_feedback,
                "component_scores": [
                    {
                        "criterion_name": f.criterion_name,
                        "score": f.score,
                        "max_points": f.max_points,
                        "student_feedback": f.student_feedback,
                        "encouragement": f.encouragement,
                        "actionable_suggestions": f.actionable_suggestions,
                    }
                    for f in report.feedback_results
                ],
                "graded_at": report.timestamp.isoformat(),
            }
            grade_status = "pass" if report.total_score >= 80 else "redo" if challenge_type == "mission_final" else "pass"

            self.supabase.table("challenge_submissions").update({
                **grading_data,
                "status": "graded",
                "grade_status": grade_status,
                "graded_at": datetime.utcnow().isoformat(),
            }).eq("id", submission_id).execute()

            return True
        except Exception:
            return False


__all__ = ["GradingPipelineV2"]
