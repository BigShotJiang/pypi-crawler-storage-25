"""
Grading Workflow Orchestrator - Supabase Edition

Coordinates the dual-agent grading system with Supabase integration to:
1. Fetch rubric from Supabase lessons table
2. Fetch student submissions from submission_attachment view
3. Download and extract submission content from storage
4. Run the dual-agent grading process
5. Store grading results back to challenge_submissions table
"""

import os
import sys
import asyncio
import re
from typing import Dict, Any, Optional, List, AsyncGenerator, Union
from datetime import datetime
from time import time
import json

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agents.systems.grading_system.grading_agents import (
    ScorerAgent,
    ReflectorAgent,
    GradingReport,
    ScoringResult,
    FeedbackResult,
)
from agents.subagents.grading import SubmissionPostAgent
from agents.tools.shared import LLMPdfExtractor, MultimodalFileExtractor
from connectors.openrouter.llm import OpenRouterMultimodalLLM, ChatMessage
from agents.prompts import CENTRAL_PROMPT_MAPPING
from agents.tools.database.aio import ChallengeSubmissionTool
from agents.tools.lark.messages_tools import LarkSearchUserAndSendMessageHandler
from agents.tools.lark.auth_tools import LarkGetAuthSessionHandler
from connectors.lark_interactions.contacts import Users, Organizations
from utils.text_processing import text_search
from dotenv import load_dotenv


load_dotenv()


class GradingWorkflow:
    """
    Orchestrates the complete grading workflow using Supabase as the data source
    """

    def __init__(self):
        """Initialize the grading workflow with Supabase client"""
        self.scorer_agent = ScorerAgent(model="openai/gpt-oss-120b")
        self.reflector_agent = ReflectorAgent(models=["openai/gpt-5-mini","openai/gpt-5-nano","openai/gpt-oss-120b"])
        self.submission_post_agent = SubmissionPostAgent(model="openai/gpt-5-nano")
        self.llm_pdf_extractor = LLMPdfExtractor()
        self.multimodal_extractor = MultimodalFileExtractor()
        self.challenge_submission_tool = ChallengeSubmissionTool()

        # Initialize Supabase client
        self.supabase_url = os.getenv("AIO_SUPABASE_URL")
        self.supabase_key = os.getenv("AIO_SUPABASE_SERVICE_ROLE_KEY")

        if not self.supabase_url or not self.supabase_key:
            raise ValueError(
                "AIO_SUPABASE_URL and AIO_SUPABASE_SERVICE_ROLE_KEY environment variables required"
            )

        from supabase import create_client, Client
        self.supabase: Client = create_client(self.supabase_url, self.supabase_key)

    async def generate_rubric_from_lesson_context(
        self, lesson_context: str, lesson_id: int
    ) -> Optional[str]:
        """
        Generate rubric content from lesson context
        """
        try:

            llm = OpenRouterMultimodalLLM(model="google/gemini-2.5-flash-lite")
            messages = llm.construct_message_list(
                system_prompt=CENTRAL_PROMPT_MAPPING.get("rubric_generation"),
                user_prompt=lesson_context,
            )
            response = await llm.achat(
                messages,
                sort="latency",
            )
            response = (
                response.message.content.strip()
                .replace("```markdown", "")
                .replace("```", "")
            )

            if not response:
                print(f"❌ No rubric found for lesson {lesson_id}")
                return None

            rubric_content = response
            # convert content to markdown byte to update to supabase
            # rubric_content = rubric_content.encode("utf-8")

            # update rubric to supabase
            try:
                self.supabase.table("lessons").update(
                    {"rubric_content": rubric_content}
                ).eq("id", lesson_id).execute()
            except Exception as e:
                print(f"❌ Error updating rubric to Supabase: {str(e)}")

            print(f"✅ Fetched rubric from Supabase (lesson_id: {lesson_id})")
            return rubric_content

        except Exception as e:
            print(f"❌ Error fetching rubric from Supabase: {str(e)}")
            return None

    async def fetch_rubric_from_supabase(
        self, lesson_id: int, space_id: Optional[int] = None
    ) -> Optional[str]:
        """
        Fetch rubric content from Supabase lessons table

        Args:
            lesson_id: ID of the lesson (final_assignment)

        Returns:
            HTML body content of the rubric or None
        """
        try:
            # Prioritize is_legacy=False challenges
            response = (
                self.supabase.table("challenges")
                .select("rubric_content")
                .eq("mission_id", space_id)
                .eq("is_legacy", False)
                .execute()
            )

            rubric_content = None
            if response.data and len(response.data) > 0:
                rubric_content = response.data[0].get("rubric_content")

            # Fallback to is_legacy=True if no rubric found
            if not rubric_content:
                print(f"⚠️ No non-legacy rubric found for mission {space_id}, falling back to legacy")
                legacy_response = (
                    self.supabase.table("challenges")
                    .select("rubric_content")
                    .eq("mission_id", space_id)
                    .eq("is_legacy", True)
                    .execute()
                )
                if legacy_response.data and len(legacy_response.data) > 0:
                    rubric_content = legacy_response.data[0].get("rubric_content")

            if not rubric_content:
                print(f"❌ No rubric found for lesson {lesson_id}")
                return None

            print(f"✅ Fetched rubric from Supabase (lesson_id: {lesson_id})")
            return rubric_content

        except Exception as e:
            print(f"❌ Error fetching rubric from Supabase: {str(e)}")
            return None

    async def fetch_submission_attachments(
        self, submission_id: int
    ) -> Optional[List[Dict[str, Any]]]:
        """
        Fetch submission attachments from Supabase submission_attachment view

        Args:
            submission_id: ID of the submission

        Returns:
            List of attachment objects with storage_object_name or None
        """
        try:
            response = (
                self.supabase.table("submission_attachment")
                .select("attachments")
                .eq("id", submission_id)
                .execute()
            )

            if not response.data or len(response.data) == 0:
                print(f"❌ No attachments found for submission {submission_id}")
                return None

            attachments_json = response.data[0].get("attachments")

            if isinstance(attachments_json, str):
                attachments = json.loads(attachments_json)
            else:
                attachments = attachments_json

            print(f"✅ Fetched {len(attachments)} attachment(s) from Supabase")
            return attachments

        except Exception as e:
            print(f"❌ Error fetching submission attachments: {str(e)}")
            return None

    async def download_and_extract_submission_content(
        self, attachments: List[Dict[str, Any]]
    ) -> str:
        """
        Download files from Supabase storage and extract content

        Args:
            attachments: List of attachment objects with storage_object_name

        Returns:
            Combined text content from all attachments
        """
        combined_content = ""

        try:
            for attachment in attachments:
                storage_object_name = attachment.get("storage_object_name")

                if not storage_object_name:
                    print(f"⚠ Attachment missing storage_object_name")
                    continue

                try:
                    # Download file from Supabase storage
                    file_data = self.supabase.storage.from_("submissions").download(
                        storage_object_name
                    )

                    # Extract content based on file type
                    file_name = storage_object_name.split("/")[-1]

                    if file_name.lower().endswith(".pdf"):
                        # Extract PDF content using LLM
                        extracted = await self.llm_pdf_extractor.execute(
                            pdf_bytes=file_data, file_name=file_name
                        )
                        content = extracted.get("content", "")
                    else:
                        # Try to decode as text
                        try:
                            content = file_data.decode("utf-8")
                        except:
                            content = f"[Binary file: {file_name}]"

                    combined_content += f"\n--- {file_name} ---\n{content}\n"
                    print(f"   ✓ Extracted content from {file_name}")

                except Exception as e:
                    print(f"   ⚠ Error downloading {storage_object_name}: {str(e)}")
                    continue

            print(f"✅ Combined content from {len(attachments)} file(s)")
            return combined_content

        except Exception as e:
            print(f"❌ Error extracting submission content: {str(e)}")
            return ""

    async def run_grading(
        self,
        submission_content: str,
        rubric_content: str,
        student_name: str,
        challenge_name: str,
        submission_pdf_bytes: Optional[bytes] = None,
        prior_submission_context: Optional[Dict[str, Any]] = None,
    ) -> GradingReport:
        """
        Run the dual-agent grading process

        Args:
            submission_content: Student's submission text
            rubric_content: Grading rubric
            student_name: Name of the student
            challenge_name: Challenge name
            submission_pdf_bytes: Optional PDF file bytes for direct processing
            prior_submission_context: Optional dict with prior submission data for resubmissions.
                Keys: "content" (str), "score" (float), "feedback" (str), "submission_id" (str)

        Returns:
            Complete GradingReport
        """
        print(f"🎯 Starting grading for {student_name} - Challenge {challenge_name}")

        if submission_pdf_bytes:
            print(f"   📄 Processing PDF file with OCR")

        # Step 1: Scorer Agent evaluates submission
        print("📊 Scorer Agent: Evaluating submission...")
        scoring_results = await self.scorer_agent.score_submission(
            submission_content=submission_content,
            rubric_content=rubric_content,
            mission_name=challenge_name,
            submission_pdf_bytes=submission_pdf_bytes,
        )

        if not scoring_results:
            raise Exception("Scorer Agent failed to generate results")

        # Calculate total score
        print("   Calculating total score...")
        for result in scoring_results:
            print(f"   {result.criterion_name}: {result.score}/{result.max_points}")
        total_score = sum(r.score for r in scoring_results)
        max_total_score = sum(r.max_points for r in scoring_results)
        percentage = (total_score / max_total_score * 100) if max_total_score > 0 else 0

        print(f"   Score: {percentage:.1f}%")

        # Step 2: Reflector Agent generates feedback
        print("💬 Reflector Agent: Generating student feedback...")
        feedback_results = await self.reflector_agent.generate_feedback(
            submission_content=submission_content,
            scoring_results=scoring_results,
            mission_name=challenge_name,
            submission_pdf_bytes=submission_pdf_bytes,
            prior_submission_content=prior_submission_context.get("content") if prior_submission_context else None,
            prior_score=prior_submission_context.get("score") if prior_submission_context else None,
        )

        if not feedback_results:
            raise Exception("Reflector Agent failed to generate feedback")

        # Step 3: Generate overall feedback
        print("📝 Generating overall feedback summary...")
        overall_feedback = await self.reflector_agent.generate_overall_feedback(
            student_name=student_name,
            mission_name=challenge_name,
            total_score=total_score,
            max_score=max_total_score,
            feedback_results=feedback_results,
        )

        # Create grading report
        report = GradingReport(
            student_name=student_name,
            mission_name=challenge_name,
            total_score=percentage,
            max_total_score=100,
            scoring_results=scoring_results,
            feedback_results=feedback_results,
            overall_feedback=overall_feedback,
        )

        print("✅ Grading complete!")
        return report

    def format_grading_report_as_json(self, report: GradingReport) -> Dict[str, Any]:
        """
        Format grading report as JSON for storage

        Args:
            report: GradingReport object

        Returns:
            Dictionary with grading data
        """
        return {
            "score": report.total_score,
            "feedback": report.overall_feedback,
            "component_scores": [
                {
                    "criterion_name": f.criterion_name,
                    "score": f.score,
                    "max_points": f.max_points,
                    "student_feedback": f.student_feedback,
                    "encouragement": f.encouragement,
                    "actionable_suggestions": f.actionable_suggestions,
                }
                for f in report.feedback_results
            ],
            "graded_at": report.timestamp.isoformat(),
        }

    def _resolve_challenge_type(self, submission_id: int) -> str:
        """
        Resolve the challenge type for a submission.

        Preferred path (new): challenge_submissions.challenge_uuid → challenges.type
        Fallback path (legacy): challenge_submissions.challenge_id → lessons → challenges.type

        Returns 'mission_final' if lookup fails (preserves existing behavior).
        """
        try:
            sub = (
                self.supabase.table("challenge_submissions")
                .select("challenge_id, challenge_uuid")
                .eq("id", submission_id)
                .limit(1)
                .execute()
            )
            if not sub.data:
                return "mission_final"

            challenge_uuid = sub.data[0].get("challenge_uuid")
            lesson_id = sub.data[0].get("challenge_id")

            # ── Preferred: direct lookup via challenge_uuid ──
            if challenge_uuid:
                challenge = (
                    self.supabase.table("challenges")
                    .select("type")
                    .eq("id", challenge_uuid)
                    .limit(1)
                    .execute()
                )
                if challenge.data:
                    return challenge.data[0].get("type", "mission_final")

            # ── Fallback: legacy path via lessons ──
            if not lesson_id:
                return "mission_final"

            lesson = (
                self.supabase.table("lessons")
                .select("name, space_id, type")
                .eq("id", lesson_id)
                .limit(1)
                .execute()
            )
            if not lesson.data:
                return "mission_final"

            space_id = lesson.data[0]["space_id"]
            lesson_name = lesson.data[0].get("name", "")
            lesson_type = lesson.data[0].get("type", "")

            # Match the specific challenge by name within this mission
            challenge = (
                self.supabase.table("challenges")
                .select("type")
                .eq("mission_id", space_id)
                .eq("is_legacy", False)
                .eq("name", lesson_name)
                .limit(1)
                .execute()
            )
            if challenge.data:
                return challenge.data[0].get("type", "mission_final")

            # Fallback: if no exact name match, infer from lesson type
            if lesson_type == "final_assignment":
                return "mission_final"
            return "mission"
        except Exception as e:
            print(f"⚠️ Could not resolve challenge type: {e}")
            return "mission_final"

    async def store_grading_results(
        self, submission_id: int, report: GradingReport
    ) -> bool:
        """
        Store grading results back to Supabase challenge_submissions table

        Args:
            submission_id: ID of the submission
            report: GradingReport object

        Returns:
            True if successful, False otherwise
        """
        try:
            grading_data = self.format_grading_report_as_json(report)

            # Resolve challenge type to determine grade_status
            challenge_type = self._resolve_challenge_type(submission_id)
            if challenge_type == "mission_final":
                grade_status = "pass" if report.total_score >= 80 else "redo"
            else:
                # Non-final challenges always pass — we only track submission
                grade_status = "pass"
                print(f"ℹ️ Non-final challenge (type={challenge_type}) — grade_status forced to 'pass'")

            # Update challenge_submissions table
            _response = (
                self.supabase.table("challenge_submissions")
                .update(
                    {
                        **grading_data,
                        "status": "graded",
                        "grade_status": grade_status,
                        "graded_at": datetime.utcnow().isoformat(),
                    }
                )
                .eq("id", submission_id)
                .execute()
            )

            print(f"✅ Stored grading results for submission {submission_id}")
            return True

        except Exception as e:
            print(f"❌ Error storing grading results: {str(e)}")
            return False

    async def send_lark_message_cards(
        self, receiver_emails: List[str], report: GradingReport, student_name: str
    ) -> Dict[str, Any]:
        """
        Send Lark message cards to specified receivers with grading results

        Args:
            receiver_emails: List of receiver email addresses
            report: GradingReport object
            student_name: Name of the student

        Returns:
            Dictionary with send status for each receiver
        """
        results = {"success": True, "receivers": [], "errors": []}

        try:

            access_token_data = await LarkGetAuthSessionHandler().execute(
                email=receiver_emails[0]
            )
            if not access_token_data:
                raise Exception("Access token not found")
            access_token = access_token_data.get("metadata", {}).get("access_token")
            lark_message_handler = LarkSearchUserAndSendMessageHandler()
            users_connector = Users(is_auth=True, access_token=access_token)
            current_user = users_connector.get_current_user()
            user_name = current_user["name"]
            receiver_email = current_user["email"]
            message_content = f"""
**Student:** {student_name}
**Score:** {report.total_score/report.max_total_score*100:.1f}%

**Feedback:**
{report.overall_feedback}
"""
            # Send message card
            for receiver in receiver_emails:
                message_response = await lark_message_handler.execute(
                    user_name=receiver,
                    message_content=message_content,
                    title=f"Challenge Submission Grading Complete: {student_name}",
                    # button_label="View Details",
                    is_card_message=True,
                )

                if message_response.get("error"):
                    results["errors"].append(
                        {
                            "email": receiver_email,
                            "error": message_response.get("error"),
                        }
                    )
                    print(
                        f"   ❌ Failed to send message: {message_response.get('error')}"
                    )
                else:
                    results["receivers"].append(
                        {"email": receiver_email, "name": user_name, "status": "sent"}
                    )
                    print(f"   ✅ Message sent to {user_name}")

                if results["errors"]:
                    print(f"⚠ Completed with {len(results['errors'])} error(s)")
                else:
                    print(
                        f"✅ Successfully sent messages to all {len(results['receivers'])} receiver(s)"
                    )

            return results

        except Exception as e:
            print(f"❌ Error sending Lark message cards: {str(e)}")
            return {"success": False, "receivers": [], "errors": [{"error": str(e)}]}

    async def process_direct_submission(
        self,
        email: str,
        space_name: str,
        text_content: str,
        files: Optional[List[dict[str, Any]]] = None,
        resolved_challenge_name: Optional[str] = None,
        prior_submission_context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Process submission using ChallengeSubmissionTool

        Args:
            email: Student's email
            space_name: Name of the space
            files: List of file URLs
            resolved_challenge_name: Pre-resolved challenge name (matches lesson by name)
            prior_submission_context: Optional dict with prior submission data for resubmissions

        Returns:
            Dictionary with submission and grading results
        """
        try:
            print("🚀 Starting submission processing with ChallengeSubmissionTool...")

            # Step 1: Use ChallengeSubmissionTool to fetch and upload files
            print("\n📤 Processing submission files...")
            print("Mission: ", space_name)
            submission_result = await self.challenge_submission_tool.execute(
                email=email, space_name=space_name, files=files,
                skip_prior_check=True,  # API endpoints have no interactive confirmation flow
                resolved_challenge_name=resolved_challenge_name,
            )

            if not submission_result.get("success"):
                return {
                    "error": submission_result.get(
                        "error", "Failed to process submission"
                    )
                }

            print(f"✅ Submission created: {submission_result['submission_id']}")

            # Extract data from submission result
            submission_id = submission_result["submission_id"]
            student_name = submission_result["student_name"]
            challenge_id = submission_result["challenge_id"]
            challenge_name = submission_result["challenge_name"]
            files_data = submission_result.get("files", [])
            lesson_context = submission_result.get("lesson_context", "")
            mission_id = submission_result.get("space_id", "")

            # Step 2: Extract content from files using MultimodalFileExtractor

            extraction_result = await self.multimodal_extractor.execute(
                files=files_data
            )

            if extraction_result.get("error"):
                print(f"⚠ Warning: {extraction_result['error']}")

            # Get markdown formatted content
            submission_content = (
                extraction_result
                .get("content", {})
                .get("markdown", "")
            )

            if files and len(files) > 0 and not submission_content:
                return {"error": "Could not extract content from submitted files"}

            # processed_files = extraction_result.get("metadata", {}).get("processed_files", 0)
            # print(f"   ✓ Extracted content from {processed_files} file(s)")

            # Step 3: Fetch rubric
            print("\n📚 Fetching rubric from Supabase...")
            rubric_content = await self.fetch_rubric_from_supabase(challenge_id, mission_id)

            if not rubric_content or rubric_content == "" or rubric_content is None:
                rubric_content = await self.generate_rubric_from_lesson_context(
                    lesson_context, challenge_id
                )

            print("✓ Found grading rubric")

            # Step 4: Run grading
            print("\n🎓 Running grading process...")
            submission_content = f"""
            **{student_name}'s message:** \n{text_content}\n\n
            **Content from attachments:** \n{submission_content or "No attachments submitted"}
            """
            report = await self.run_grading(
                submission_content=submission_content,
                rubric_content=rubric_content,
                student_name=student_name,
                challenge_name=challenge_name,
                prior_submission_context=prior_submission_context,
            )

            # Step 5: Store results
            print("\n💾 Storing grading results...")
            stored = await self.store_grading_results(submission_id, report)

            if not stored:
                return {"error": "Failed to store grading results"}

            print("✅ Grading workflow complete!")

            return {
                "message": report.overall_feedback,
                "submission_id": submission_id,
                "student_name": student_name,
                "score": f"{report.total_score:.1f}%",
                "space_group_id": submission_result.get("space_group_id", ""),
                "mission_name": space_name,
                "challenge_name": challenge_name,
            }

        except Exception as e:
            print(f"❌ Error in grading workflow: {str(e)}")
            return {"error": str(e)}
    
    async def astream_process_direct_submission(
        self,
        email: str,
        space_name: str,
        text_content: str,
        files: Optional[List[dict[str, Any]]] = None,
        resolved_challenge_name: Optional[str] = None,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Streaming version of process_direct_submission
        
        Args:
            email: Student's email
            space_name: Name of the space
            text_content: Student's message content
            files: List of file URLs
            resolved_challenge_name: Pre-resolved challenge name (matches lesson by name)
            
        Yields:
            Dict[str, Any]: Status events and final result
        """
        start_time = time()
        
        try:
            file_count = len(files) if files else 0
            yield {"type": "status", "message": (
                f"I'm starting to process the submission for '{resolved_challenge_name or space_name}' from {email}. "
                f"The student has provided {file_count} file(s) along with their text content for this challenge. "
                f"First, I need to validate the submission details and check if this student has any prior submissions on record. "
                f"Let me fetch the challenge metadata and set up everything for the grading pipeline."
            )}
            
            # Step 1: Use ChallengeSubmissionTool to fetch and upload files
            submission_result = await self.challenge_submission_tool.execute(
                email=email, space_name=space_name, files=files,
                skip_prior_check=True,  # API endpoints have no interactive confirmation flow
                resolved_challenge_name=resolved_challenge_name,
            )

            if not submission_result.get("success"):
                yield {"type": "error", "message": submission_result.get("error", "Failed to process submission")}
                return

            # Extract data from submission result
            submission_id = submission_result["submission_id"]
            student_name = submission_result["student_name"]
            challenge_id = submission_result["challenge_id"]
            challenge_name = submission_result["challenge_name"]
            files_data = submission_result.get("files", [])
            lesson_context = submission_result.get("lesson_context", "")
            mission_id = submission_result.get("space_id", "")

            yield {"type": "status", "message": (
                f"The submission for '{challenge_name}' by {student_name} has been registered successfully. "
                f"Now I need to extract the content from the {len(files_data)} uploaded file(s) so I can analyze what was submitted. "
                f"I'll use the multimodal file extractor to read documents, images, and other attachment types. "
                f"This step converts all attachments into a structured text format that the grading agents can evaluate."
            )}
            
            # Step 2: Extract content from files using MultimodalFileExtractor
            extraction_result = await self.multimodal_extractor.execute(
                files=files_data
            )
            
            yield {"type": "status", "message": (
                f"I've finished extracting content from {student_name}'s attachments for '{challenge_name}'. "
                f"The extractor processed all files and converted them into markdown format for analysis. "
                f"Let me check if all the content was extracted properly before moving on to the rubric retrieval. "
                f"Any issues with file formats or corrupted files will be flagged here."
            )}

            if extraction_result.get("error"):
                yield {"type": "status", "message": (
                    f"I ran into an issue while processing some of {student_name}'s attachments: {extraction_result['error']}. "
                    f"This doesn't necessarily mean the grading will fail — I can still work with whatever content was successfully extracted. "
                    f"Some file formats or very large files can occasionally cause partial extraction issues. "
                    f"I'll proceed with the available content and note this in the grading context."
                )}

            # Get markdown formatted content
            submission_content = (
                extraction_result
                .get("content", {})
                .get("markdown", "")
            )

            if files and len(files) > 0 and not submission_content:
                yield {"type": "error", "message": "Could not extract content from submitted files"}
                return

            yield {"type": "status", "message": (
                f"Now I need to load the grading rubric for '{challenge_name}' to evaluate {student_name}'s work against the correct criteria. "
                f"I'll first check if there's an existing rubric stored in the database for this challenge. "
                f"If no rubric is found, I'll generate one based on the lesson context and challenge requirements. "
                f"The rubric defines the scoring categories, point allocations, and expected learning outcomes."
            )}
            
            # Step 3: Fetch rubric
            rubric_content = await self.fetch_rubric_from_supabase(challenge_id, mission_id)

            if not rubric_content or rubric_content == "" or rubric_content is None:
                rubric_content = await self.generate_rubric_from_lesson_context(
                    lesson_context, challenge_id
                )

            if not rubric_content:
                yield {"type": "error", "message": "Failed to fetch or generate rubric"}
                return

            yield {"type": "status", "message": (
                f"I have the rubric ready and {student_name}'s submission content extracted — now it's time to run the actual grading. "
                f"I'm using a dual-agent grading process: one agent scores against each rubric criterion while another generates detailed feedback. "
                f"Both agents work in parallel to speed things up, and their results are merged into a single comprehensive report. "
                f"This typically takes a moment as each criterion is carefully evaluated against the submission for '{challenge_name}'."
            )}
            
            # Step 4: Run grading
            submission_content = f"""
            **{student_name}'s message:** \n{text_content}\n\n
            **Content from attachments:** \n{submission_content or "No attachments submitted"}
            """
            report = await self.run_grading(
                submission_content=submission_content,
                rubric_content=rubric_content,
                student_name=student_name,
                challenge_name=challenge_name,
            )

            yield {"type": "status", "message": (
                f"The grading is complete for {student_name}'s submission on '{challenge_name}'. "
                f"I'm now saving the scores, feedback, and the full grading report to the database for safekeeping. "
                f"This ensures the results are permanently recorded and can be retrieved later for review or appeals. "
                f"Once saved, I'll determine whether to request posting confirmation or show improvement feedback based on the score."
            )}
            
            # Step 5: Store results
            stored = await self.store_grading_results(submission_id, report)

            if not stored:
                yield {"type": "error", "message": "Failed to store grading results"}
                return

            execution_time = time() - start_time
            
            # Final result
            result = {
                "feedback": report.overall_feedback,
                "submission_id": submission_id,
                "student_name": student_name,
                "score": f"{report.total_score:.1f}%",
                "space_group_id": submission_result.get("space_group_id", ""),
                "mission_name": space_name,
                "challenge_name": challenge_name,
                "execution_time": execution_time,
                "component_scores": [
                    {
                        "criterion_name": f.criterion_name,
                        "score": f.score,
                        "max_points": f.max_points,
                        "student_feedback": f.student_feedback,
                        "encouragement": f.encouragement,
                        "actionable_suggestions": f.actionable_suggestions,
                    }
                    for f in report.feedback_results
                ]
            }
            
            component_score_string = "\n".join([
                f"""**{f['criterion_name']}**: {f['score']}/{f['max_points']}
                **Encouragement:** {f['encouragement']}
                **Actionable suggestions:** {f['actionable_suggestions']}
                """
                for f in result["component_scores"]
            ])
            
            brief_reasoning = f"""
            {student_name}'s submission received a score of {report.total_score:.1f}%.
            Component scores:
            {component_score_string}
            """
            
            yield {"type": "result", "data": result, "message": brief_reasoning}

        except Exception as e:
            print(f"❌ Error in streaming grading workflow: {str(e)}")
            yield {"type": "error", "message": str(e)}
        
    async def fetch_posting_space(self, post_id: str) -> list:
        try:
            from agents.tools.database.aio import DatabaseToolHandler

            db_handler = DatabaseToolHandler()
            response = (
                db_handler.supabase.table("posts")
                .select("space_id, space_name")
                .eq("id", post_id)
                .limit(1)
                .execute()
            )
            if response.data:
                post_space_id = response.data[0].get("space_id")
                post_space_name = response.data[0].get("space_name")
                return [post_space_id, post_space_name]
        except Exception as e:
            print(f"⚠️ Could not fetch parent space for post {post_id}: {str(e)}")
            return []
    
    async def grading_with_posting(
        self,
        email: str,
        space_name: str,
        text_content: str,
        files: Optional[List[dict[str, Any]]] = None,
        post_id: Optional[Union[str, int]] = None,
        circle_file_urls: Optional[List[str]] = None,
        challenge_name: Optional[str] = None,
        context_type: Optional[str] = None,
        context_id: Optional[str] = None,
    ):
        """Grade submission (Circle posting removed)."""
        try:
            grading_outputs = await self.process_direct_submission(
                email=email,
                space_name=space_name,
                files=files,
                text_content=text_content,
            )
            return grading_outputs
        except Exception as e:
            print(f"❌ Failed to grade submission: {str(e)}")
    
    async def astream_grading_with_posting(
        self,
        email: str,
        space_name: str,
        text_content: str,
        files: Optional[List[dict[str, Any]]] = None,
        post_id: Optional[Union[str, int]] = None,
        circle_file_urls: Optional[List[str]] = None,
        challenge_name: Optional[str] = None
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Streaming version of grading (Circle posting removed)

        Args:
            email: Student's email
            space_name: Name of the space
            text_content: Student's message content
            files: List of file URLs
            post_id: Optional existing post ID (kept for compatibility, unused)
            circle_file_urls: Optional Circle file URLs (kept for compatibility, unused)
            challenge_name: Optional challenge name

        Yields:
            Dict[str, Any]: Status events and final result
        """
        start_time = time()

        try:
            # Delegate core grading to streaming method
            async for event in self.astream_process_direct_submission(
                email=email,
                space_name=space_name,
                text_content=text_content,
                files=files
            ):
                if event["type"] == "error":
                    yield event
                    return
                elif event["type"] == "result":
                    grading_outputs = event["data"]
                    yield event
                    break
                else:
                    # Forward status events
                    yield event

            execution_time = time() - start_time
            grading_outputs["execution_time"] = execution_time

            yield {"type": "result", "data": grading_outputs}

        except Exception as e:
            print(f"❌ Error in streaming grading: {str(e)}")
            yield {"type": "error", "message": str(e)}
    
    
    async def process_submission(
        self,
        email: str,
        space_name: str,
        chat_room_id: str,
        message_id: int,
        files: Optional[List[dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """
        Process submission using ChallengeSubmissionTool

        Args:
            email: Student's email
            space_name: Name of the space
            files: List of file URLs

        Returns:
            Dictionary with submission and grading results
        """
        try:
            print("🚀 Starting submission processing with ChallengeSubmissionTool...")

            # Step 1: Use ChallengeSubmissionTool to fetch and upload files
            print("\n📤 Processing submission files...")
            submission_result = await self.challenge_submission_tool.execute(
                email=email,
                space_name=space_name,
                chat_room_id=chat_room_id,
                files=files,
            )

            if not submission_result.get("success"):
                return {
                    "error": submission_result.get(
                        "error", "Failed to process submission"
                    )
                }

            print(f"✅ Submission created: {submission_result['submission_id']}")

            # Extract data from submission result
            submission_id = submission_result["submission_id"]
            student_name = submission_result["student_name"]
            challenge_id = submission_result["challenge_id"]
            challenge_name = submission_result["challenge_name"]
            files_data = submission_result.get("files", [])
            lesson_context = submission_result.get("lesson_context", "")

            # Step 2: Extract content from files using MultimodalFileExtractor

            extraction_result = await self.multimodal_extractor.execute(
                files=files_data
            )

            if extraction_result.get("error"):
                print(f"⚠ Warning: {extraction_result['error']}")

            # Get markdown formatted content
            submission_content = extraction_result.get("content", {}).get(
                "markdown", ""
            )

            if not submission_content:
                return {"error": "Could not extract content from submitted files"}

            processed_files = extraction_result.get("metadata", {}).get(
                "processed_files", 0
            )
            # print(f"   ✓ Extracted content from {processed_files} file(s)")

            # Step 3: Fetch rubric
            print("\n📚 Fetching rubric from Supabase...")
            rubric_content = await self.fetch_rubric_from_supabase(challenge_id)

            if not rubric_content or rubric_content == "" or rubric_content is None:
                rubric_content = await self.generate_rubric_from_lesson_context(
                    lesson_context, challenge_id
                )

            print("✓ Found grading rubric")

            # Step 4: Run grading
            print("\n🎓 Running grading process...")
            report = await self.run_grading(
                submission_content=submission_content,
                rubric_content=rubric_content,
                student_name=student_name,
                challenge_name=challenge_name,
            )

            # Step 5: Store results
            print("\n💾 Storing grading results...")
            stored = await self.store_grading_results(submission_id, report)

            if not stored:
                return {"error": "Failed to store grading results"}

            print("✅ Grading workflow complete!")

            # Step 7: Send Lark message cards to specified receivers
            print("\n📬 Sending Lark message cards to receivers...")
            receiver_emails = ["trac.nguyen@edge8.ai"]
            # try:
            #     lark_message_result = await self.send_lark_message_cards(
            #         receiver_emails=receiver_emails,
            #         report=report,
            #         student_name=student_name,
            #     )

            #     if not lark_message_result.get("success"):
            #         return {"error": "Failed to send Lark message cards"}

            # except Exception as e:
            #     print("Error sending Lark message cards: ", str(e))

            return {
                "success": True,
                "submission_id": submission_id,
                "student_name": student_name,
                "student_email": email,
                "space_name": space_name,
                "challenge_id": challenge_id,
                "challenge_name": challenge_name,
                "score": f"{report.total_score}/{report.max_total_score}",
                "percentage": f"{report.total_score:.1f}%",
                "files_processed": len(files_data),
                "chat_room": submission_result.get("chat_room_name"),
                "sent": sent_message,
                # "lark_notifications": lark_message_result,
            }

        except Exception as e:
            print(f"❌ Error in grading workflow: {str(e)}")
            return {"error": str(e)}

    # ============================================================================
    # Workflow Confirmation Handlers
    # ============================================================================

    async def handle_mission_confirmation_workflow(
        self,
        user_input: str,
        submission_metadata: Dict[str, Any],
        circle_file_urls: Optional[List[str]] = None
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Handle mission confirmation workflow.
        
        Args:
            user_input: User's response to confirmation
            submission_metadata: Submission details from workflow state
            circle_file_urls: Optional Circle file URLs
            
        Yields:
            Event dictionaries with type, data, and message
        """
        response_lower = user_input.lower().strip()
        
        if response_lower in ["yes", "y", "yeah", "sure", "ok", "proceed"]:
            # User confirmed - proceed to grading
            challenge_info = submission_metadata.get("challenge", {})
            challenge_name = challenge_info.get("entity_name") or challenge_info.get("series_name") or "the challenge"
            yield {"type": "reasoning", "step": "Grading", "message": (
                f"The user confirmed they want to proceed with grading their submission for '{challenge_name}'. "
                f"I'll now run the full grading pipeline which includes file processing, rubric retrieval, and dual-agent evaluation. "
                f"The submission metadata has already been validated during the confirmation step, so I can skip re-verification. "
                f"Let me kick off the grading workflow and stream progress updates as each stage completes."
            )}
            
            async for event in self._process_grading_after_confirmation(
                submission_metadata=submission_metadata,
                circle_file_urls=circle_file_urls
            ):
                yield event
        else:
            # User declined or unclear response
            async for event in self._handle_submission_cancellation():
                yield event

    async def _process_grading_after_confirmation(
        self,
        submission_metadata: Dict[str, Any],
        circle_file_urls: Optional[List[str]]
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Run grading and handle results based on score."""
        grading_data = None
        
        async for event in self.astream_grading_with_posting(
            email=submission_metadata.get("email"),
            space_name=submission_metadata.get("challenge", {}).get("entity_name") or submission_metadata.get("challenge", {}).get("series_name"),
            files=submission_metadata.get("files"),
            text_content=submission_metadata.get("text_content"),
            circle_file_urls=circle_file_urls
        ):
            if event["type"] == "status":
                yield {"type": "reasoning", "step": "Grading", "message": event["message"]}
            elif event["type"] == "error":
                yield {"type": "error", "message": event["message"]}
                return
            elif event["type"] == "result":
                grading_data = event["data"]
                break
        
        if not grading_data:
            yield {"type": "error", "message": "Grading failed to complete"}
            return
        
        # Check score and route to appropriate handler
        raw_score = grading_data.get("score", "0")
        try:
            score = float(str(raw_score).replace('%', ''))
        except (ValueError, TypeError):
            score = 0.0
        
        if score >= 80:
            async for event in self._handle_high_score_result(
                grading_data=grading_data
            ):
                yield event
        else:
            async for event in self._handle_low_score_result(
                grading_data=grading_data,
                score=score
            ):
                yield event

    async def _handle_high_score_result(
        self,
        grading_data: Dict[str, Any]
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Handle grading result with score >= 80."""
        yield {
            "type": "grading_complete",
            "action": "request_posting_confirmation",
            "grading_data": grading_data
        }

    async def _handle_low_score_result(
        self,
        grading_data: Dict[str, Any],
        score: float
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Handle grading result with score < 80."""
        low_score_message = f"""Your score is {score}/100. I recommend reviewing the feedback and retrying before posting to Circle. Below is your feedback:
        {grading_data.get("feedback")}"""
        
        yield {
            "type": "grading_complete",
            "action": "show_low_score_feedback",
            "message": low_score_message,
            "grading_data": grading_data,
            "score": score
        }

    async def _handle_submission_cancellation(
        self
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Handle user declining submission."""
        cancel_message = "Submission cancelled. Let me know when you're ready to submit."
        
        yield {
            "type": "submission_cancelled",
            "message": cancel_message
        }

    async def handle_posting_confirmation_workflow(
        self,
        user_input: str,
        grading_data: Dict[str, Any],
        circle_file_urls: Optional[List[str]] = None
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Handle posting confirmation workflow.
        
        Args:
            user_input: User's response to posting confirmation
            grading_data: Grading results from workflow state
            circle_file_urls: Optional Circle file URLs
            
        Yields:
            Event dictionaries with type, data, and message
        """
        response_lower = user_input.lower().strip()
        
        if response_lower in ["yes", "y", "post", "share"]:
            challenge_name = grading_data.get("mission_name", grading_data.get("challenge_name", "the challenge"))
            score = grading_data.get("score", "N/A")
            yield {"type": "reasoning", "step": "Posting", "message": (
                f"The user confirmed they want to post their graded submission for '{challenge_name}' (score: {score}) to Circle. "
                f"I'll create a new post in the appropriate Circle space with the student's original work and any attached files. "
                f"After the post is live, I'll add the grading feedback as a comment so everything is in one place. "
                f"This makes the submission and feedback visible to the community and the instructors."
            )}
            
            async for event in self._handle_posting_success(
                grading_data=grading_data,
                circle_file_urls=circle_file_urls
            ):
                yield event
        else:
            async for event in self._handle_posting_decline():
                yield event

    async def _handle_posting_success(
        self,
        grading_data: Dict[str, Any],
        circle_file_urls: Optional[List[str]]
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Handle successful posting to Circle."""
        _ , post_result = await self.post_grading(
            grading_message=grading_data.get("grading_message", ""),
            student_message=grading_data.get("submission_content", ""),
            mission_space_name=grading_data.get("mission_name"),
            challenge_name=grading_data.get("challenge_name"),
            student_name=grading_data.get("student_name"),
            student_email=grading_data.get("email"),
            space_group_id=grading_data.get("space_group_id"),
            circle_file_urls=circle_file_urls
        )
        
        yield {
            "type": "posting_complete",
            "post_result": post_result,
            "grading_data": grading_data
        }

    async def _handle_posting_decline(
        self
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Handle user declining posting."""
        decline_message = "Your submission has been graded but not posted to Circle. Let me know if you'd like to post it later."
        
        yield {
            "type": "posting_declined",
            "message": decline_message
        }


__all__ = ["GradingWorkflow"]
