"""
Structured Markdown Formatter for Resubmission Grading Output

Converts grading results into the organized markdown format specified in:
docs/2026-03-09-ai-buddy-and-grading-feedbacks/grading-system-feedbacks.md

Adds resubmission-specific sections for prior comparison and progress tracking.
"""

from typing import List, Optional, Dict, Any
from dataclasses import dataclass


@dataclass
class FeedbackResult:
    """Represents feedback for a single criterion."""
    criterion_name: str
    score: float
    max_points: float
    student_feedback: str
    encouragement: str
    actionable_suggestions: List[str]


@dataclass
class ResubmissionContext:
    """Context for resubmission comparison."""
    prior_score: float
    current_score: float
    prior_feedback: Optional[str] = None


class ResubmissionMarkdownFormatter:
    """
    Formats grading results into structured markdown for resubmission output.
    
    Structure follows the template in grading-system-feedbacks.md with
    additional resubmission-specific sections.
    """
    
    def __init__(
        self,
        series_name: str = "AI Officer Program",
        mission_name: str = "",
        challenge_name: str = "",
        student_name: str = "",
        challenge_type: str = "mission",
    ):
        self.series_name = series_name
        self.mission_name = mission_name
        self.challenge_name = challenge_name
        self.student_name = student_name
        self.is_final = challenge_type == "mission_final"
    
    def format_grading_report(
        self,
        total_score: float,
        max_score: float = 100.0,
        feedback_results: List[FeedbackResult] = None,
        resubmission_context: Optional[ResubmissionContext] = None,
    ) -> str:
        """
        Format a complete grading report as structured markdown.
        
        Args:
            total_score: The final score (0-100)
            max_score: Maximum possible score (default 100)
            feedback_results: List of per-criterion feedback
            resubmission_context: Prior submission data for comparison
            
        Returns:
            Formatted markdown string
        """
        sections = []
        
        # Header Section
        sections.append(self._format_header(total_score, max_score, resubmission_context))
        
        # DEBUG: Log comparison section gate
        if resubmission_context:
            print(f"[DEBUG format_grading_report] resubmission_context exists, prior_feedback length: {len(str(resubmission_context.prior_feedback or ''))}")
            print(f"[DEBUG format_grading_report] prior_feedback truthy: {bool(resubmission_context.prior_feedback)}")
        
        # Progress Tracking (Resubmission-specific)
        if resubmission_context:
            sections.append(self._format_progress_tracking(resubmission_context))
            # Prior feedback comparison — only if prior feedback text is available
            if resubmission_context.prior_feedback:
                sections.append(self._format_prior_feedback_comparison(
                    resubmission_context, feedback_results
                ))
        
        # What You Did Well
        sections.append(self._format_what_you_did_well(feedback_results))
        
        # Areas for Improvement
        sections.append(self._format_areas_for_improvement(feedback_results))
        
        # Suggested Improvements
        sections.append(self._format_suggested_improvements(feedback_results))
        
        # Resubmission Prompt
        sections.append(self._format_resubmission_prompt(total_score))
        
        return "\n\n".join(sections)
    
    def _format_header(
        self, 
        total_score: float, 
        max_score: float,
        resubmission_context: Optional[ResubmissionContext] = None
    ) -> str:
        """Format the header section. Score shown only for mission_final challenges."""
        acknowledgement = ""
        if resubmission_context:
            acknowledgement = "\n\nThanks for your resubmission. I've reviewed your updated work.\n"

        if self.is_final:
            score_line = f"\n### Score: {total_score:.1f} / {max_score:.1f}\n\n*Based on evaluation against challenge rubric criteria*"
        else:
            score_line = ""

        # Conditionally include Mission field only if mission_name is not empty
        if self.mission_name and self.mission_name.strip():
            mission_line = f"**Mission:** {self.mission_name}  \n"
        else:
            mission_line = ""

        return f"""## Challenge Submission Grading Complete

**{self.series_name}**  
{mission_line}**Challenge:** {self.challenge_name}  
**Student:** {self.student_name}
{acknowledgement}
---
{score_line}"""
    
    def _format_progress_tracking(
        self, context: ResubmissionContext
    ) -> str:
        """Format the resubmission progress tracking section.
        
        For mission_final: shows numeric scores and point delta.
        For non-final: qualitative progress only — no scores exposed.
        """
        if self.is_final:
            score_change = context.current_score - context.prior_score
            if score_change > 0:
                progress_indicator = f"📈 **+{score_change:.1f} points** improvement from prior submission"
                progress_message = "Great progress! Your revisions have strengthened the submission."
            elif score_change < 0:
                progress_indicator = f"📉 **{score_change:.1f} points** change from prior submission"
                progress_message = "Review the feedback carefully—some areas may need additional attention."
            else:
                progress_indicator = "➡️ **No score change** from prior submission"
                progress_message = "Score remains the same. Focus on the specific areas for improvement below."

            return f"""---

### Progress Tracking

**Prior Submission Score:** {context.prior_score:.1f}/100  
**Current Submission Score:** {context.current_score:.1f}/100  
{progress_indicator}

{progress_message}"""
        else:
            # Non-final: qualitative progress only
            score_change = context.current_score - context.prior_score
            if score_change > 0:
                progress_message = "📈 Your revised submission shows clear improvement over your prior attempt."
            elif score_change < 0:
                progress_message = "📝 Some areas need a bit more attention compared to your prior attempt—review the feedback below."
            else:
                progress_message = "➡️ Your submission is at a similar level to your prior attempt. Focus on the improvement areas below."

            return f"""---

### Progress on Resubmission

{progress_message}"""
    
    def _format_prior_feedback_comparison(
        self,
        context: ResubmissionContext,
        feedback_results: Optional[List[FeedbackResult]],
    ) -> str:
        """Compare current results against what was flagged in prior feedback."""
        # Parse criterion names that improved vs still need work
        improved_criteria = []
        still_needs_work = []
        
        if feedback_results:
            for result in feedback_results:
                pct = result.score / result.max_points if result.max_points > 0 else 0
                if pct >= 0.7:
                    improved_criteria.append(result.criterion_name)
                else:
                    still_needs_work.append(result.criterion_name)
        
        # Truncate prior feedback for readability — show enough to be meaningful
        prior_feedback_excerpt = context.prior_feedback.strip()
        if len(prior_feedback_excerpt) > 800:
            prior_feedback_excerpt = prior_feedback_excerpt[:800] + "..."
        
        improved_text = (
            "\n".join(f"- **{c}**" for c in improved_criteria)
            if improved_criteria
            else "- *No criteria reached 70%+ threshold yet*"
        )
        still_needs_work_text = (
            "\n".join(f"- **{c}**" for c in still_needs_work)
            if still_needs_work
            else "- *All criteria are meeting the threshold — great work!*"
        )
        
        return f"""---

### What Improved Since Last Submission

**What has improved** (scoring ≥70% of points):

{improved_text}

### What Is Still Missing

**Still needs work** (scoring <70% of points):

{still_needs_work_text}"""

    def _format_what_you_did_well(
        self, feedback_results: Optional[List[FeedbackResult]]
    ) -> str:
        """Format the 'What You Did Well' section."""
        if not feedback_results:
            return """---

### 1. What You Did Well

*No specific strengths identified in this submission.*"""
        
        strengths = []
        for result in feedback_results:
            # Extract positive elements from feedback and encouragement
            if result.score >= result.max_points * 0.7:  # 70%+ is considered good
                strength_text = result.student_feedback.strip()
                if strength_text:
                    strengths.append(f"- **{result.criterion_name}:** {strength_text}")
        
        if not strengths:
            strengths_text = "*Continue working on the fundamentals across all criteria.*"
        else:
            strengths_text = "\n".join(strengths)
        
        return f"""---

### 1. What You Did Well

{strengths_text}"""
    
    def _format_areas_for_improvement(
        self, feedback_results: Optional[List[FeedbackResult]]
    ) -> str:
        """Format the 'Areas for Improvement' section."""
        if not feedback_results:
            return """---

### 2. Areas for Improvement

*No specific areas identified—continue refining your approach.*"""
        
        areas = []
        for result in feedback_results:
            # Focus on areas with lower scores
            if result.score < result.max_points * 0.7:  # Below 70%
                feedback_text = result.student_feedback.strip()
                if feedback_text:
                    areas.append(f"- **{result.criterion_name}:** {feedback_text}")
        
        if not areas:
            areas_text = "*Strong performance across all criteria—minor polish recommended.*"
        else:
            areas_text = "\n".join(areas)
        
        return f"""---

### 2. Areas for Improvement

{areas_text}"""
    
    def _format_suggested_improvements(
        self, feedback_results: Optional[List[FeedbackResult]]
    ) -> str:
        """Format the 'Suggested Improvements' section with actionable items."""
        if not feedback_results:
            return """---

### 3. Suggested Improvements

- Review the challenge requirements carefully
- Reference the rubric criteria in your submission
- Ensure all required components are addressed"""
        
        suggestions = []
        for result in feedback_results:
            if result.actionable_suggestions:
                for suggestion in result.actionable_suggestions:
                    if suggestion.strip():
                        suggestions.append(f"- **{result.criterion_name}:** {suggestion.strip()}")
        
        if not suggestions:
            suggestions_text = "- Continue building on your current approach"
        else:
            # Deduplicate and limit to top suggestions
            seen = set()
            unique_suggestions = []
            for s in suggestions:
                if s not in seen:
                    seen.add(s)
                    unique_suggestions.append(s)
            suggestions_text = "\n".join(unique_suggestions[:6])  # Max 6 suggestions
        
        return f"""---

### Suggestions for Next Revision

{suggestions_text}"""
    
    def _format_resubmission_prompt(self, total_score: float) -> str:
        """Format the next steps section.
        
        For mission_final: score-based pass/redo language.
        For non-final: completion acknowledgement only — no score thresholds.
        """
        if self.is_final:
            if total_score >= 80:
                prompt_text = (
                    "**Excellent work!** You've achieved a passing score (80%+). "
                    "You may choose to refine further for an even stronger submission, "
                    "or proceed to the next challenge. What would you like to do?"
                )
            elif total_score >= 60:
                prompt_text = (
                    "**You're making good progress.** To reach the passing threshold (80%), "
                    "focus on the specific improvements suggested above. "
                    "Would you like to revise your work and resubmit for a higher score?"
                )
            else:
                prompt_text = (
                    "**Keep working at it.** Review the feedback carefully and address "
                    "the key areas for improvement. Each revision brings you closer to mastery. "
                    "Would you like to revise your work and resubmit?"
                )
        else:
            # Non-final: submission is always recorded as passed — focus on learning
            if not self._has_improvement_areas_from_score(total_score):
                prompt_text = (
                    "**Well done!** You've completed this challenge and addressed all the key criteria. "
                    "Feel free to move on to the next challenge whenever you're ready."
                )
            else:
                prompt_text = (
                    "**Submission recorded.** Review the feedback above to strengthen your understanding "
                    "before moving on. You can resubmit if you'd like to address the improvement areas."
                )

        return f"""---

### Next Steps

{prompt_text}"""

    def _has_improvement_areas_from_score(self, total_score: float) -> bool:
        """Proxy for whether there are meaningful improvement areas, used for non-final prompt."""
        return total_score < 80


def format_resubmission_grading_report(
    student_name: str,
    mission_name: str,
    challenge_name: str,
    total_score: float,
    feedback_results: List[Dict[str, Any]],
    prior_score: Optional[float] = None,
    prior_feedback: Optional[str] = None,
    series_name: str = "AI Officer Program",
    challenge_type: str = "mission",
) -> str:
    """
    Convenience function to format a grading report (first submission or resubmission).
    
    Args:
        student_name: Name of the student
        mission_name: Name of the mission
        challenge_name: Name of the challenge
        total_score: Current score (0-100)
        feedback_results: List of feedback result dicts with keys:
            - criterion_name: str
            - score: float
            - max_points: float
            - student_feedback: str
            - encouragement: str
            - actionable_suggestions: List[str]
        prior_score: Score from previous submission (None for first submission)
        prior_feedback: Full feedback text from prior submission for comparison
        series_name: Program series name
        
    Returns:
        Formatted markdown string
    """
    # Convert dicts to FeedbackResult objects
    feedback_objects = [
        FeedbackResult(
            criterion_name=f.get("criterion_name", "Unknown"),
            score=f.get("score", 0.0),
            max_points=f.get("max_points", 0.0),
            student_feedback=f.get("student_feedback", ""),
            encouragement=f.get("encouragement", ""),
            actionable_suggestions=f.get("actionable_suggestions", []),
        )
        for f in feedback_results
    ]
    
    formatter = ResubmissionMarkdownFormatter(
        series_name=series_name,
        mission_name=mission_name,
        challenge_name=challenge_name,
        student_name=student_name,
        challenge_type=challenge_type,
    )
    
    # DEBUG: Log resubmission context creation
    print(f"[DEBUG format_resubmission_grading_report] prior_score: {prior_score}, prior_feedback type: {type(prior_feedback)}, prior_feedback length: {len(str(prior_feedback or ''))}")
    
    # Only create resubmission context if prior_score is provided
    resubmission_context = None
    if prior_score is not None:
        resubmission_context = ResubmissionContext(
            prior_score=prior_score,
            current_score=total_score,
            prior_feedback=prior_feedback or "",
        )
    
    return formatter.format_grading_report(
        total_score=total_score,
        feedback_results=feedback_objects,
        resubmission_context=resubmission_context,
    )


__all__ = [
    "ResubmissionMarkdownFormatter",
    "FeedbackResult",
    "ResubmissionContext",
    "format_resubmission_grading_report",
]
