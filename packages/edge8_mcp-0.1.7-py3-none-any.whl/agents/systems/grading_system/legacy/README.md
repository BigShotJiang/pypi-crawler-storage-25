# Legacy Grading System

This directory contains deprecated grading system implementations that are maintained for backward compatibility.

## Files

- `grading_agents.py` - Legacy grading agent implementations (v1)
- `grading_workflow.py` - Legacy workflow orchestration (v1)

## Status

⚠️ **DEPRECATED** - These files are maintained for backward compatibility only.

## Migration Path

New code should use the v2 implementations in the `core/` directory:
- Use `core.grading_workflow_v2.GradingWorkflowV2` instead of legacy workflow
- Use `core.grading_pipeline_v2.GradingPipelineV2` for the lean 3-step pipeline

## Removal Timeline

These files will be removed once all production code has migrated to v2 implementations.
