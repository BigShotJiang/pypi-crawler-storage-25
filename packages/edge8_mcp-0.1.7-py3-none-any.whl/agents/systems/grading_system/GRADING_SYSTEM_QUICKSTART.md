# Grading System Quick Start

## Setup

### Dependencies

All dependencies should already be installed:
- `openrouter` for LLM access
- `pydantic` for data models
- Existing Lark connectors

### Environment Variables

Ensure `.env` has:
```bash
OPENROUTER_API_KEY=your_api_key_here
```

### Test the System

```bash
python -m pytest tests/test_pdf_submission_processing.py -v
```

## Basic Usage

### Direct API Call

```python
from src.agents.grading_workflow import GradingWorkflow

orchestrator = GradingWorkflow()

result = await orchestrator.process_assignment(
    file_token="doccnXXXXXXXXXXXXXXXX",
    folder_token="fldcnXXXXXXXXXXXXXXXX",
    uploader_open_id="ou_XXXXXXXXXXXXXXXX"
)

print(f"Grade: {result['score']} ({result['percentage']})")
```

### Via Tool System

```python
from src.agents.tools.handlers import execute_tool

result = await execute_tool(
    "lark_grade_assignment",
    file_token="doccnXXXXXXXXXXXXXXXX",
    folder_token="fldcnXXXXXXXXXXXXXXXX",
    uploader_open_id="ou_XXXXXXXXXXXXXXXX"
)
```

### Natural Language (via Agent)

```python
"Grade the assignment John uploaded for Mission 1"
```

## File Organization

### Required Structure

```
📁 Course Workspace
├── 📁 Mission 1 - [Topic]
│   ├── 📄 Mission 1 - Guidelines (optional)
│   └── 📄 Mission 1 - Rubric (required)
├── 📁 [Student Name]
│   └── 📄 Mission 1.pdf
```

### After Grading

```
📁 Course Workspace
├── 📁 Mission 1 - [Topic]
│   ├── 📄 Mission 1 - Rubric
│   └── 📄 Mission 1 - [Student] - Grading Report (new)
├── 📁 [Student Name]
│   └── 📄 Mission 1.pdf
```

## File Naming Rules

### Valid Submission Names

- `Mission 1.pdf`
- `Mission 2.docx`
- `Mission One.pdf`
- `Mission 1 - Final Draft.pdf`

### Invalid Submission Names

- `Assignment 1.pdf` (must start with "Mission")
- `mission1.pdf` (needs space after "Mission")
- `My Research.pdf` (no mission identifier)

### Rubric Names

- `Mission 1 - Rubric`
- `Mission 2 - Rubric`

### Guidelines Names (Optional)

- `Mission 1 - Guidelines`
- `Mission 2 - Guidelines`

## Troubleshooting

### "Could not extract mission number"

Filename doesn't match pattern. Rename to start with "Mission X".

### "Could not find rubric"

Create document named "Mission X - Rubric" in Lark.

### "Failed to get access token"

User needs to complete Lark OAuth flow.

### "Failed to move document"

Create folder named "Mission X" in Lark.

## Output Format

### Success Response

```json
{
  "success": true,
  "student_name": "John Smith",
  "mission_number": "1",
  "score": "85/100",
  "percentage": "85.0%",
  "document_id": "doccnXXXXXXXXXXXXXXXX",
  "notification_sent": true
}
```

### Error Response

```json
{
  "error": "Could not find rubric for Mission 1"
}
```

## Grading Report

Students receive:
- Overall score and percentage
- Overall feedback summary
- Criterion-by-criterion breakdown
- Specific strengths identified
- Actionable improvement suggestions

## Workflow Steps

1. Extract file metadata and content
2. Identify student name from folder
3. Parse mission number from filename
4. Search for rubric and guidelines
5. Run Scorer Agent (objective evaluation)
6. Run Reflector Agent (friendly feedback)
7. Create formatted grading document
8. Move document to mission folder
9. Send notification to student

## Best Practices

### For Rubrics

- Be specific about criteria
- Include point values
- Describe expectations clearly
- Use measurable standards

### For Guidelines

- Explain assignment objective
- List requirements clearly
- Provide helpful tips
- Set clear expectations

### For Students

- Follow naming conventions
- Upload to correct folder
- Submit complete work
- Check notifications for feedback

## Next Steps

1. Test the system: Run the test suite
2. Create rubrics for your missions
3. Organize student and mission folders
4. Grade assignments
