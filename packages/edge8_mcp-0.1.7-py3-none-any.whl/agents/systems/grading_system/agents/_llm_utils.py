"""
Shared LLM utilities for grading agents.

Contains retry helpers, PDF message builders, and plugin configuration.
"""

import asyncio
from typing import List, Any

from connectors.openrouter.llm import OpenRouterMultimodalLLM, ChatMessage
from utils.data_conversion import encode_base64_by_chunk

# OpenRouter plugin configuration for PDF parsing
PDF_PARSER_PLUGIN = [
    {
        "id": "file-parser",
        "pdf": {
            "engine": "mistral-ocr"
        }
    }
]


async def llm_call_with_retry(
    llm: OpenRouterMultimodalLLM,
    messages: List[ChatMessage],
    max_retries: int = 5,
    **kwargs: Any,
) -> str:
    """Call LLM with exponential-ish backoff. Returns response content string.

    Args:
        llm: The LLM instance to use
        messages: List of chat messages
        max_retries: Maximum number of retry attempts
        **kwargs: Additional kwargs to pass to achat

    Returns:
        Response content string

    Raises:
        RuntimeError: If all retries exhausted
        Exception: The last exception from the LLM call
    """
    for attempt in range(max_retries):
        try:
            response = await llm.achat(messages, **kwargs)
            return response.message.content
        except Exception as e:
            if attempt == max_retries - 1:
                raise
            await asyncio.sleep(5)
    raise RuntimeError("Unreachable")


def build_pdf_user_message(
    prompt: str,
    pdf_bytes: bytes,
    mission_name: str,
) -> ChatMessage:
    """Wrap a prompt + PDF bytes into a ChatMessage with file attachment.

    Args:
        prompt: The text prompt content
        pdf_bytes: Raw PDF bytes
        mission_name: Mission name for the PDF filename

    Returns:
        ChatMessage with attached PDF file
    """
    pdf_data_uri = encode_base64_by_chunk(pdf_bytes, "application/pdf")
    return ChatMessage(
        role="user",
        content=prompt,
        additional_kwargs={
            "files": [{"name": f"mission_{mission_name}_submission.pdf", "content": pdf_data_uri}]
        },
    )
