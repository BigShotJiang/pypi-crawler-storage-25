# Grading System Integration Guide

Grading system is fully integrated with the existing multi-agent architecture.

## Tool Registration

Tool Schema (`src/agents/tools/schema.py`):
```python
lark_grade_assignment_tool = ToolSchema(
    name="lark_grade_assignment",
    description="Grade a student assignment using dual-agent system...",
    parameters={...}
)
```

Tool Handler (`src/agents/tools/handlers.py`):
```python
TOOL_HANDLERS = {
    "lark_grade_assignment": LarkGradeAssignmentHandler()
}
```

## Integration Points

### With MultiTaskAgentSystem

```python
from src.agents.multi_task_agent import MultiTaskAgentSystem

agent = MultiTaskAgentSystem()
response = await agent.process_request(
    "Grade the assignment John uploaded for Mission 1",
    conversation_id="user_123"
)
```

### With ToolUseAgent

```python
from src.agents.systems.tool_use_agent import ToolUseAgent

agent = ToolUseAgent()
response = await agent.process_with_tools(
    user_message="Grade John's Mission 1 submission",
    available_tools=["lark_grade_assignment"]
)
```

### With State-Based Agents

```python
from src.agents.state_based_agents import StateBasedAgent

agent = StateBasedAgent()
# Grading tool is available in the agent's tool set
```

## Parameter Resolution

### Explicit Parameters

```
User: "Grade file doccn123 in folder fldcn456 for user ou_789"
```

Agent extracts:
- `file_token`: "doccn123"
- `folder_token`: "fldcn456"
- `uploader_open_id`: "ou_789"

### Implicit Parameters

```
User: "Grade the assignment I just uploaded"
```

Agent infers from context:
- `file_token`: From recent upload event
- `folder_token`: From user's current folder
- `uploader_open_id`: From authenticated user session

### Mixed Parameters

```
User: "Grade John's Mission 1 assignment"
```

Agent resolves:
- Searches for John's folder → `folder_token`
- Searches for "Mission 1" file → `file_token`
- Uses John's user ID → `uploader_open_id`

## Best Practices

### Parameter Validation

```python
if not all([file_token, folder_token, uploader_open_id]):
    return {"error": "Missing required parameters"}
```

### Error Handling

```python
try:
    result = await execute_tool("lark_grade_assignment", ...)
except Exception as e:
    logger.error(f"Grading failed: {e}")
    return {"error": "Grading failed, please try again"}
```

### User Feedback

```python
await send_message("⏳ Grading in progress...")
result = await execute_tool("lark_grade_assignment", ...)
await send_message(f"✅ Grade: {result['score']}")
```

## Quick Start

### Step 1: Verify Tool Registration

```python
from src.agents.tools.handlers import TOOL_HANDLERS

assert "lark_grade_assignment" in TOOL_HANDLERS
print("✅ Grading tool registered")
```

### Step 2: Test Tool Execution

```python
from src.agents.tools.handlers import execute_tool

result = await execute_tool(
    "lark_grade_assignment",
    file_token="test_token",
    folder_token="test_folder",
    uploader_open_id="test_user"
)
```

### Step 3: Use in Agent

```python
response = await agent.process_request("Grade the assignment")
```

## Summary

- ✅ Tool registered in schema
- ✅ Handler registered in handlers
- ✅ Available to all agents
- ✅ Natural language support
- ✅ Automatic parameter resolution
- ✅ Error handling included
- ✅ Logging integrated
