# Dual-Agent Grading System for Student Assignments

AI-powered grading system using two specialized agents to evaluate student assignments with fairness and encouraging feedback. Integrated with Circle for posting results and includes prior-check logic to prevent duplicate grading.

## Overview

Dual-agent architecture separating objective evaluation from student-friendly feedback:
- **Scorer Agent**: Applies rubrics objectively and assigns scores with justifications
- **Reflector Agent**: Transforms technical evaluations into encouraging, actionable feedback
- **Prior-Check**: Detects existing submissions and prevents duplicate grading
- **Challenge Type-Aware**: Different grade_status logic for mission vs mission_final
- **Circle Integration**: Posts grading results to Circle community

## Architecture

### Core Components

**Grading Agents**
- `ScorerAgent` (`grading_agents.py`): Analyzes submissions, assigns scores, identifies strengths/weaknesses
- `ReflectorAgent` (`grading_agents.py`): Reviews scores, transforms to student-friendly language, generates suggestions
- `OptimizedScorerAgent` (`optimized_grading_agents.py`): Streaming version with improved prompts
- `OptimizedReflectorAgent` (`optimized_grading_agents.py`): Streaming version with better feedback generation

**Workflow Orchestrators**
- `GradingWorkflow` (`grading_workflow.py`): Legacy workflow for API endpoints
- `OptimizedGradingWorkflow` (`optimized_grading_workflow.py`): Chatbot workflow with streaming and prior-check

**Database Tools** (`tools/database/aio/aio.py`)
- `process_submission`: Main submission handler with prior-check logic
- `fetch_challenge_by_uuid`: Get challenge metadata
- `fetch_rubric_from_supabase`: Get grading rubric
- `store_grading_results`: Save results with challenge type-aware grade_status

**Circle Integration** (`tools/circle/`)
- Posts grading results to Circle community
- Includes score, feedback, and suggestions

## Workflow

### Chatbot Flow (OptimizedGradingWorkflow)

1. **Submission Detection**: User says "I want to submit Mission 1" or provides context_type="challenge"
2. **Prior-Check**: Check for existing submissions
   - If grade_status='pass' found, return prior submission message
   - If ungraded submission found, offer to reuse or create new
3. **File Processing**: Extract text from PDF/images using LLM
4. **Rubric Retrieval**: Fetch rubric from database (challenges-first, then body_html)
5. **Dual-Agent Grading**:
   - Scorer: Objective evaluation with scores
   - Reflector: Student-friendly feedback
6. **Store Results**: Save to database with challenge type-aware grade_status
7. **Circle Post** (optional): Post results to Circle community
8. **Stream Response**: Yield grading events to frontend

### API Flow (GradingWorkflow)

1. **Circle Post Trigger**: Grading triggered from Circle post
2. **Extract Submission**: Get post content and attachments
3. **Rubric Retrieval**: Fetch rubric from database
4. **Dual-Agent Grading**: Scorer + Reflector (non-streaming)
5. **Store Results**: Save to database (skip_prior_check=True)
6. **Circle Post**: Post results back to Circle

## Usage

### Via Chatbot (Recommended)

```python
from src.agents.systems.simple_agent_system import AgentSystem

agent = AgentSystem(tool_groups=["circle_aio"], member_id=123)

# Student submits assignment
async for event in agent.run_stream(
    "I want to submit Mission 1",
    email="student@example.com",
    files=[{"url": "https://...", "name": "mission1.pdf"}],
    context_type="challenge",
    context_id="challenge_uuid_123"
):
    if event["event"] == "grading_response":
        print(f"Score: {event['data']['score']}")
        print(f"Feedback: {event['data']['feedback']}")
```

### Via API (Circle Integration)

```python
from src.agents.systems.grading_system.grading_workflow import GradingWorkflow

workflow = GradingWorkflow()
result = await workflow.process_direct_submission(
    student_email="student@example.com",
    challenge_uuid="challenge_uuid_123",
    text_content="My submission text",
    files=[{"url": "https://...", "name": "file.pdf"}],
    with_post=True,  # Post to Circle
    skip_prior_check=True  # Skip prior-check for API
)
```

### Streaming Workflow

```python
from src.agents.systems.grading_system.optimized_grading_workflow import OptimizedGradingWorkflow

workflow = OptimizedGradingWorkflow()

async for event in workflow.astream_process_direct_submission(
    student_email="student@example.com",
    challenge_uuid="challenge_uuid_123",
    text_content="My submission",
    files=[...]
):
    if event["event"] == "grading_complete":
        print(f"Final score: {event['data']['total_score']}")
```

## File Naming Conventions

### Student Submission Files

Format: `Mission <number> [optional description].pdf`
- `Mission 1.pdf`
- `Mission 2 - Final Draft.pdf`
- `Mission One.pdf`

### Folder Structure

- Student folders: Named with student names
- Mission folders: `Mission <number> [optional description]`

### Grading Materials

- Guidelines: `Mission <number> - Guidelines`
- Rubric: `Mission <number> - Rubric`

### Example Structure

```
📁 Course Root
├── 📁 Mission 1 - Introduction
│   ├── 📄 Mission 1 - Guidelines
│   └── 📄 Mission 1 - Rubric
├── 📁 John Smith
│   ├── 📄 Mission 1.pdf (submitted)
│   └── 📄 Mission 1 - John Smith - Grading Report (generated)
```

## Grading Report Format

```markdown
# Grading Report: Mission X

**Student:** [Student Name]
**Date:** [Timestamp]
**Total Score:** X/Y (Z%)

## Overall Feedback

[Warm, comprehensive summary]

## Detailed Evaluation

### [Criterion Name]
**Score:** X/Y

[Student-friendly feedback]

**Suggestions for Improvement:**
- [Actionable suggestion 1]
- [Actionable suggestion 2]
```

## Configuration

### Environment Variables

```bash
# Required
OPENROUTER_API_KEY=your_api_key_here

# Database
AIO_SUPABASE_URL=your_supabase_url
AIO_SUPABASE_SERVICE_ROLE_KEY=your_service_key

# Optional - Circle integration
CIRCLE_API_TOKEN=your_circle_token
```

### Agent Models

**OptimizedGradingWorkflow (Chatbot):**
- Scorer: `google/gemini-2.0-flash-exp:free`
- Reflector: `google/gemini-2.0-flash-exp:free`

**GradingWorkflow (API):**
- Scorer: `openai/gpt-4o-mini`
- Reflector: `openai/gpt-4o-mini`

**Customize:**
```python
workflow = OptimizedGradingWorkflow(
    scorer_model="openai/gpt-4o",
    reflector_model="openai/gpt-4o"
)
```

## Grading Principles

### Scorer Agent

- Evidence-based: All scores backed by specific examples
- Rubric-aligned: Strict adherence to criteria
- Consistent: Same standards across submissions
- Fair: Partial credit where appropriate
- Thorough: Comprehensive analysis
- Streaming: Yields scoring events in real-time

### Reflector Agent

- Encouraging: Positive, growth-oriented tone
- Specific: Concrete examples and suggestions
- Actionable: Clear steps for improvement
- Balanced: Celebrates strengths and addresses weaknesses
- Personal: Tailored to individual performance
- Streaming: Yields feedback events in real-time

### Prior-Check Logic

**Two-Query Approach:**
1. **Check for Pass**: Query for grade_status='pass' (or score >= 80 fallback)
2. **Check for Ungraded**: Query for latest ungraded submission

**Behavior:**
- If passed submission found: Return prior submission message (no re-grading)
- If ungraded submission found: Offer to reuse or create new
- If no submission found: Proceed with new submission

### Challenge Type-Aware Grade Status

**mission_final:**
- `grade_status = "pass" if score >= 80 else "redo"`
- Shows score in prior-check message

**mission (non-final):**
- `grade_status = "pass"` always (we only track submission, not pass/fail)
- Hides score in prior-check message

## Error Handling

- **Missing Files**: Returns error if submission not found (files=None guard added)
- **Missing Rubric**: Cannot proceed without rubric
- **Missing Challenge**: Falls back to body_html if challenge not found
- **Parsing Errors**: Graceful fallback with error messages
- **API Failures**: Retry logic and error reporting
- **File Operations**: Detailed error messages
- **Prior-Check Failures**: Logs warning and proceeds with grading
- **Circle Post Failures**: Logs error but doesn't fail grading

## Extensibility

### Adding New Rubric Criteria

System automatically adapts. Provide:
1. Clear criterion names
2. Maximum points per criterion
3. Detailed descriptions

### Custom Feedback Templates

```python
scorer_agent.system_prompt = """Your custom prompt..."""
reflector_agent.system_prompt = """Your custom prompt..."""
```

### Additional File Operations

```python
class LarkCustomFileHandler(ToolHandler):
    async def execute(self, **kwargs) -> Dict[str, Any]:
        # Custom logic
        pass
```

## Testing

### Manual Testing

```python
python src/agents/grading_workflow.py
```

### Unit Testing

```python
import pytest
from src.agents.systems.grading_system.grading_agents import ScorerAgent

@pytest.mark.asyncio
async def test_scorer_agent():
    scorer = ScorerAgent()
    results = await scorer.score_submission(
        submission_content="Sample submission...",
        rubric_content="Sample rubric...",
        mission_number="1"
    )
    assert len(results) > 0
```

## Data Models

### ScoringResult

```python
{
    "criterion_name": str,
    "score": float,
    "max_points": float,
    "justification": str,
    "strengths": List[str],
    "weaknesses": List[str]
}
```

### FeedbackResult

```python
{
    "criterion_name": str,
    "score": float,
    "max_points": float,
    "student_feedback": str,
    "encouragement": str,
    "actionable_suggestions": List[str]
}
```

### GradingResponse (Streaming)

```python
{
    "event": "grading_complete",
    "data": {
        "submission_id": str,
        "total_score": float,
        "max_score": float,
        "percentage": float,
        "grade_status": str,  # "pass" or "redo"
        "feedback": str,
        "suggestions": List[str],
        "scoring_results": List[ScoringResult],
        "feedback_results": List[FeedbackResult]
    }
}
```

### Prior-Check Response

```python
{
    "has_prior_submission": bool,
    "submission_id": str,
    "score": float,  # Only for mission_final
    "grade_status": str,
    "challenge_type": str,  # "mission" or "mission_final"
    "submitted_at": str
}
```

## Security & Privacy

- Access tokens managed securely via Lark OAuth
- Student data only accessible to authorized users
- Grading documents have appropriate permissions
- No sensitive data logged unnecessarily

## Troubleshooting

### "No rubric found for challenge"

**Cause**: Challenge UUID not found in database or no rubric in body_html
**Fix**: Ensure challenge exists in `challenges` table with rubric in `body_html` field

### "Student not found"

**Cause**: Email not found in `students` table
**Fix**: Ensure student is registered in database

### "Prior-check returns wrong submission"

**Cause**: Multiple submissions with same grade_status
**Fix**: Prior-check now uses two queries (pass first, then ungraded) to handle this

### "Score shown for non-final challenge"

**Cause**: Challenge type not properly detected
**Fix**: Ensure `challenge_type` is returned from prior-check and used in message generation

### "Grading uses wrong challenge"

**Cause**: Fallback to final_assignment when challenge not found
**Fix**: Removed fallback; now uses challenge_metadata.body_html directly

### "Files=None causes crash"

**Cause**: process_submission didn't handle None files
**Fix**: Added `if files is None: files = []` guard

## Key Files

- `optimized_grading_workflow.py` - Chatbot grading workflow (streaming)
- `grading_workflow.py` - API grading workflow (non-streaming)
- `optimized_grading_agents.py` - Streaming scorer and reflector
- `grading_agents.py` - Non-streaming scorer and reflector
- `tools/database/aio/aio.py` - Database operations and prior-check
- `tests/grading/` - Test suite

## References

- [OpenRouter API](https://openrouter.ai/docs)
- [Supabase Documentation](https://supabase.com/docs)
- [Circle API Documentation](https://api.circle.so/)
- Test Reports: `docs/2026-02-09-grading-prior-check-plan/TEST_REPORT.md`
- Bug Fixes: `docs/2026-02-13-challenge-grading-mismatch/ASSESSMENT.md`

## Testing

### Structural Tests

```bash
# Test grading workflow components
pytest tests/grading/test_grade_status_by_challenge_type.py -v
pytest tests/grading/test_challenge_mismatch_fix.py -v
pytest tests/grading/test_context_shortcut.py -v
```

### Interactive Tests

```bash
# Test with real student email
python tests/grading/test_mission06_interactive.py
```

### Test Coverage

- Prior-check logic (pass detection, ungraded detection)
- Challenge type resolution (mission vs mission_final)
- Grade status assignment (pass/redo logic)
- Challenge mismatch prevention
- File processing (PDF, images, text)
- Streaming events
- Circle integration

## Contributing

To add features:
1. Extend `OptimizedGradingWorkflow` for chatbot changes
2. Extend `GradingWorkflow` for API changes
3. Update database tools in `tools/database/aio/aio.py`
4. Add tests in `tests/grading/`
5. Update documentation
6. Run regression tests
