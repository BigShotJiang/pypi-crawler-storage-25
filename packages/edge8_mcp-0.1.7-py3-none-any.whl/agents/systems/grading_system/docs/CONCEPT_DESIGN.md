# Grading Workflow Orchestrator - Concept Design

Automated system that manages the complete lifecycle of student assignment evaluation.

## System Overview

```mermaid
graph TB
    Submission["Student Submission (Chatbot)<br/>(File + Metadata)"] --> DataAcq["Data Acquisition<br/>& Preparation"]
    
    DataAcq --> Rubric["Retrieve Rubric<br/>& Guidelines"]
    DataAcq --> Extract["Extract & Normalize<br/>Content"]
    
    Rubric --> DualAgent["Dual-Agent<br/>Evaluation"]
    Extract --> DualAgent
    
    DualAgent --> Scorer["Scorer Agent<br/>(Objective Evaluation)"]
    DualAgent --> Reflector["Reflector Agent<br/>(Student Feedback)"]
    
    Scorer --> Report["Generate Grading<br/>Report"]
    Reflector --> Report
    
    Report --> Persist["Result Persistence<br/>(Data Store)"]
    
    Persist --> Notify["Circle Post<br/>Notification"]
    
    Notify --> CirclePost["Create Circle Post<br/>(Student Submission)"]
    CirclePost --> CircleComment["Add Comment<br/>(Dave Feedback)"]
    
    CircleComment --> Complete["✅ Complete"]
    
    style Submission fill:#E8F4F8
    style DualAgent fill:#87CEEB
    style Scorer fill:#87CEEB
    style Reflector fill:#87CEEB
    style Persist fill:#FFD700
    style Notify fill:#FFD700
    style Complete fill:#90EE90
```

## Architecture

### Core Components

- **Data Acquisition & Preparation**: Gather submission files, extract content, retrieve rubrics
- **Dual-Agent Evaluation**: Scorer Agent for objective evaluation, Reflector Agent for student-friendly feedback
- **Result Persistence**: Store grading results in data store
- **Multi-Channel Notifications**: Distribute results to students and designated receivers

## Dual-Agent Evaluation Process

```mermaid
graph LR
    Input["Submission Content<br/>+ Rubric"] --> Scorer["Scorer Agent<br/>(Objective)"]
    
    Scorer --> Analysis["Analyze Criteria<br/>Evaluate Evidence<br/>Assign Scores"]
    
    Analysis --> ScoringResult["Scoring Results<br/>(Scores + Justifications)"]
    
    ScoringResult --> Reflector["Reflector Agent<br/>(Student-Centric)"]
    
    Reflector --> Transform["Transform Language<br/>Add Encouragement<br/>Generate Suggestions"]
    
    Transform --> FeedbackResult["Feedback Results<br/>(Student-Friendly)"]
    
    ScoringResult --> Report["Synthesize<br/>Grading Report"]
    FeedbackResult --> Report
    
    style Scorer fill:#87CEEB
    style Reflector fill:#87CEEB
    style Report fill:#FFD700
```

## Dual-Agent Roles

### Scorer Agent (Critical Evaluator)

**Purpose**: Deliver accurate, objective assessment and precise grading

**Responsibilities**
- Analyze submission against rubric criteria
- Evaluate evidence quality and completeness
- Assign precise scores for each criterion
- Provide detailed justifications for scores
- Ensure consistency and fairness across evaluations

**Key Characteristics**
- **Critical**: Rigorous evaluation standards
- **Accurate**: Precise scoring for quality tracking
- **Objective**: Fact-based assessment without bias
- **Justified**: Every score backed by evidence

**Output**
- Criterion-by-criterion scores
- Score justifications
- Overall score calculation
- Quality metrics for tracking

### Reflector Agent (Feedback Provider)

**Purpose**: Transform scores into constructive, motivating student feedback

**Responsibilities**
- Review Scorer's assessment and justifications
- Translate technical scores into student-friendly language
- Add encouragement and growth-oriented messaging
- Generate actionable improvement suggestions
- Control tone to match pedagogical goals

**Key Characteristics**
- **Flexible**: Adaptable tone and messaging style
- **Constructive**: Focuses on growth and improvement
- **Empathetic**: Student-centered perspective
- **Actionable**: Specific suggestions for next steps

**Output**
- Student-friendly feedback summary
- Tone-controlled encouragement
- Specific improvement suggestions
- Growth-oriented messaging

**Tone Control Options**
- Supportive: Emphasize effort and progress
- Challenging: Push for higher standards
- Balanced: Mix encouragement with constructive criticism
- Developmental: Focus on learning pathways

## Process Flow

### Phase 1: Data Acquisition & Preparation

- Extract submission metadata
- Retrieve grading rubric
- Fetch submission files
- Extract and normalize content
- Validate completeness

### Phase 2: Dual-Agent Evaluation

- **Scorer Agent**: Analyze rubric, evaluate submission, assign scores with justifications
- **Reflector Agent**: Review scores, transform to student-friendly language, generate suggestions

### Phase 3: Result Persistence & Circle Post Notification

- Format report as JSON
- Add metadata (timestamp, status)
- Write to data store
- Mark submission as graded
- Create Circle post with student submission (if `with_post` flag enabled)
- Embed submission files (images, videos, PDFs, audio)
- Add feedback comment as Dave with score and overall feedback
- Handle post/comment failures gracefully

## Circle Post Notification Flow

```mermaid
graph TB
    Report["Grading Report<br/>(Complete)"] --> Format["Format as JSON<br/>Add Metadata"]
    
    Format --> Persist["Write to<br/>Data Store"]
    
    Persist --> Success{Storage<br/>Success?}
    
    Success -->|No| Error["Return Error"]
    Success -->|Yes| CheckPost{with_post<br/>Flag?}
    
    CheckPost -->|No| Complete["✅ Complete<br/>(No Circle Post)"]
    CheckPost -->|Yes| PreparePost["Prepare Circle Post<br/>(Student Submission)"]
    
    PreparePost --> EmbedFiles["Embed Files<br/>(Images/Videos/PDFs)"]
    EmbedFiles --> CreatePost["Create Post<br/>(as Student)"]
    
    CreatePost --> PostSuccess{Post<br/>Created?}
    
    PostSuccess -->|No| PostFail["⚠️ Post Creation Failed"]
    PostSuccess -->|Yes| GetPostID["Get Post ID"]
    
    GetPostID --> AddComment["Add Feedback Comment<br/>(as Dave)"]
    AddComment --> CommentSuccess{Comment<br/>Added?}
    
    CommentSuccess -->|No| CommentFail["⚠️ Comment Failed"]
    CommentSuccess -->|Yes| CommentOK["✅ Feedback Posted"]
    
    PostFail --> Complete
    CommentFail --> Complete
    CommentOK --> Complete
    Error --> Complete
    
    style Report fill:#FFD700
    style Persist fill:#FFD700
    style CreatePost fill:#87CEEB
    style AddComment fill:#87CEEB
    style Complete fill:#90EE90
    style Error fill:#FFB6C6
```

## Key Principles

- **Separation of Concerns**: Data, processing, integration, and orchestration layers
- **Dual-Agent Pattern**: Objective evaluation + student-friendly feedback
- **Resilience**: System continues even if some notifications fail
- **Data Normalization**: Multiple file formats converted to unified text
- **Asynchronous Processing**: Non-blocking long-running operations

## Integration Points

### External Systems

- **Data Store**: Stores rubrics, submissions, and grading results
- **Cloud Storage**: Hosts submission files
- **Messaging Platform**: Delivers notifications
- **User Identity Service**: Resolves user identities
- **AI Models**: Scorer and Reflector agents

### Data Contracts

- **Rubric Format**: Structured criteria with point values
- **Submission Format**: Student content in text or file format
- **Grading Report Format**: JSON with scores and feedback
- **Notification Format**: Message cards with score and summary

## Success Criteria

- Data completeness
- Grading quality
- Result persistence
- Notification delivery
- Clear error reporting
