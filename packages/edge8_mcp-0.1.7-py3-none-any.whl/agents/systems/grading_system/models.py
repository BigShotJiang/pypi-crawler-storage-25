"""
Pydantic models for the grading system.

This module contains data models for rubric criteria, scoring results,
feedback results, and complete grading reports.
"""

from typing import List, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field


class RubricCriterion(BaseModel):
    """A single criterion in the grading rubric"""
    name: str
    description: str
    max_points: float
    weight: float = 1.0


class ScoringResult(BaseModel):
    """Result from the Scorer Agent"""
    criterion_name: str
    score: float
    max_points: float
    justification: str
    strengths: List[str] = []
    weaknesses: List[str] = []


class FeedbackResult(BaseModel):
    """Result from the Reflector Agent"""
    criterion_name: str
    score: float
    max_points: float
    student_feedback: str
    encouragement: str
    actionable_suggestions: List[str] = []


class GradingReport(BaseModel):
    """Complete grading report"""
    student_name: str
    mission_name: str
    total_score: float
    max_total_score: float
    scoring_results: List[ScoringResult]
    feedback_results: List[FeedbackResult]
    overall_feedback: str
    timestamp: datetime = Field(default_factory=datetime.now)


def grading_report_to_dict(report: GradingReport) -> Dict[str, Any]:
    """
    Format grading report as JSON for storage.

    Args:
        report: GradingReport object

    Returns:
        Dictionary with grading data
    """
    return {
        "score": report.total_score,
        "feedback": report.overall_feedback,
        "component_scores": [
            {
                "criterion_name": f.criterion_name,
                "score": f.score,
                "max_points": f.max_points,
                "student_feedback": f.student_feedback,
                "encouragement": f.encouragement,
                "actionable_suggestions": f.actionable_suggestions,
            }
            for f in report.feedback_results
        ],
        "graded_at": report.timestamp.isoformat(),
    }
