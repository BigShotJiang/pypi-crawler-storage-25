# Storage Layer

The storage layer handles all database interactions for the grading system.

## Purpose

Provides a clean abstraction over Supabase database operations, separating data access from business logic.

## Modules

### RubricStore (`rubric_store.py`)

Manages rubric retrieval and generation.

**Key Methods:**
- `fetch_or_generate(challenge_uuid, lesson_context, ...)` - Fetch rubric from DB or generate via LLM
- `fetch_rubric_from_supabase(challenge_uuid)` - Direct DB lookup
- `generate_rubric_from_lesson_context(lesson_context, ...)` - LLM-based generation

**Usage:**
```python
from src.agents.systems.grading_system.storage import RubricStore

store = RubricStore()
rubric = await store.fetch_or_generate(
    challenge_uuid="...",
    lesson_context="...",
    challenge_name="..."
)
```

### SubmissionStore (`submission_store.py`)

Manages submission and grading result persistence.

**Key Methods:**
- `store_grading_results(submission_id, report, ...)` - Save grading results to DB
- `update_overall_feedback(submission_id, feedback)` - Update feedback text
- `fetch_prior_submission_content(submission_id)` - Retrieve prior submission for comparison

**Usage:**
```python
from src.agents.systems.grading_system.storage import SubmissionStore

store = SubmissionStore()
await store.store_grading_results(
    submission_id=123,
    report=grading_report,
    challenge_type="mission_final"
)
```

### Rubric Utils (`rubric_utils.py`)

Utility functions for rubric processing.

**Functions:**
- Helper functions for rubric parsing and validation

## Design Principles

1. **Single Responsibility:** Each store handles one domain (rubrics, submissions)
2. **Async-First:** All DB operations are async
3. **Error Handling:** Graceful degradation with logging
4. **No Business Logic:** Pure data access, no grading logic

## Dependencies

- Supabase client (`src.connectors.supabase_client`)
- Pydantic models (`src.agents.systems.grading_system.models`)

## Testing

Run storage layer tests:
```bash
pytest tests/grading/ -k "store or rubric" -v
```
