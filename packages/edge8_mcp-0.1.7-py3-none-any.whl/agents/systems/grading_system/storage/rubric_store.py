"""
Rubric storage layer for fetching and generating rubrics.

This module provides a clean separation between grading orchestration
and rubric persistence/generation logic.
"""
from __future__ import annotations
from typing import Dict, Optional

from connectors.openrouter.llm import OpenRouterMultimodalLLM
from agents.prompts import CENTRAL_PROMPT_MAPPING


class RubricStore:
    """Storage layer for rubric fetch and generation operations."""

    def __init__(self, supabase: Client) -> None:
        """
        Initialize RubricStore with Supabase client.

        Args:
            supabase: Supabase client instance
        """
        self.supabase = supabase
        self._cache: Dict[str, str] = {}

    async def fetch_rubric(
        self,
        challenge_uuid: Optional[str] = None,
        space_id: Optional[int] = None,
        lesson_id: Optional[int] = None,
    ) -> Optional[str]:
        """
        Fetch rubric from Supabase by challenge_uuid (preferred) or space_id (fallback).

        Args:
            challenge_uuid: challenges.id UUID for direct lookup
            space_id: spaces.id (mission_id) for legacy lookup
            lesson_id: ID of the lesson (legacy, for logging only)

        Returns:
            Rubric content string or None
        """
        try:
            rubric_content = None

            # Check cache first (keyed by challenge_uuid)
            if challenge_uuid and challenge_uuid in self._cache:
                print(f"✅ Rubric cache hit for challenge_uuid: {challenge_uuid}")
                return self._cache[challenge_uuid]

            # Preferred: direct lookup by challenge_uuid
            if challenge_uuid:
                response = (
                    self.supabase.table("challenges")
                    .select("rubric_content")
                    .eq("id", challenge_uuid)
                    .limit(1)
                    .execute()
                )
                if response.data:
                    rubric_content = response.data[0].get("rubric_content")
                if rubric_content:
                    print(f"✅ Fetched rubric by challenge_uuid: {challenge_uuid}")
                    # Store in cache for future lookups
                    self._cache[challenge_uuid] = rubric_content
                    return rubric_content

            # Fallback: lookup by space_id (mission_id)
            if space_id:
                # Prioritize is_legacy=False challenges
                response = (
                    self.supabase.table("challenges")
                    .select("rubric_content")
                    .eq("mission_id", space_id)
                    .eq("is_legacy", False)
                    .execute()
                )
                if response.data and len(response.data) > 0:
                    rubric_content = response.data[0].get("rubric_content")

                # Fallback to is_legacy=True if no rubric found
                if not rubric_content:
                    print(f"⚠️ No non-legacy rubric found for mission {space_id}, falling back to legacy")
                    legacy_response = (
                        self.supabase.table("challenges")
                        .select("rubric_content")
                        .eq("mission_id", space_id)
                        .eq("is_legacy", True)
                        .execute()
                    )
                    if legacy_response.data and len(legacy_response.data) > 0:
                        rubric_content = legacy_response.data[0].get("rubric_content")

            if not rubric_content:
                print(f"❌ No rubric found (lesson_id={lesson_id}, space_id={space_id}, challenge_uuid={challenge_uuid})")
                return None

            print(f"✅ Fetched rubric from Supabase (lesson_id: {lesson_id})")
            return rubric_content

        except Exception as e:
            print(f"❌ Error fetching rubric from Supabase: {str(e)}")
            return None

    async def generate_rubric(
        self,
        lesson_context: str,
        lesson_id: Optional[int] = None,
        update_db: bool = True,
    ) -> Optional[str]:
        """
        Generate rubric from lesson context via LLM. Optionally persists to DB.

        Args:
            lesson_context: Lesson context content
            lesson_id: Optional lesson ID for DB update
            update_db: If True, persists generated rubric to Supabase

        Returns:
            Generated rubric content or None
        """
        try:
            llm = OpenRouterMultimodalLLM(model="google/gemini-2.5-flash-lite")
            messages = llm.construct_message_list(
                system_prompt=CENTRAL_PROMPT_MAPPING.get("rubric_generation"),
                user_prompt=lesson_context,
            )
            response = await llm.achat(
                messages,
                sort="latency",
            )
            response = (
                response.message.content.strip()
                .replace("```markdown", "")
                .replace("```", "")
            )

            if not response:
                print(f"❌ No rubric found for lesson {lesson_id}")
                return None

            rubric_content = response

            # Update rubric to supabase if requested
            if update_db and lesson_id is not None:
                try:
                    self.supabase.table("challenges").update(
                        {"rubric_content": rubric_content}
                    ).eq("id", lesson_id).execute()
                    print(f"✅ Updated rubric to Supabase (lesson_id: {lesson_id})")
                except Exception as e:
                    print(f"❌ Error updating rubric to Supabase: {str(e)}")

            print(f"✅ Generated rubric for lesson {lesson_id}")
            return rubric_content

        except Exception as e:
            print(f"❌ Error generating rubric: {str(e)}")
            return None

    async def fetch_or_generate(
        self,
        challenge_uuid: Optional[str] = None,
        space_id: Optional[int] = None,
        lesson_id: Optional[int] = None,
        lesson_context: str = "",
    ) -> Optional[str]:
        """
        Convenience: fetch first, generate if not found.

        Args:
            challenge_uuid: challenges.id UUID for direct lookup
            space_id: spaces.id (mission_id) for legacy lookup
            lesson_id: Optional lesson ID for DB update
            lesson_context: Lesson context for rubric generation

        Returns:
            Rubric content string or None
        """
        rubric = await self.fetch_rubric(
            challenge_uuid=challenge_uuid,
            space_id=space_id,
            lesson_id=lesson_id
        )
        if not rubric and lesson_context:
            rubric = await self.generate_rubric(lesson_context, lesson_id)
        return rubric
