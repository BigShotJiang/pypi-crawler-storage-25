"""
Backward-compatible re-export shim.
Implementation moved to storage.rubric_store.RubricStore.
"""
from agents.systems.grading_system.storage.rubric_store import RubricStore as _RubricStore
from connectors.openrouter.llm import OpenRouterMultimodalLLM
from agents.prompts import CENTRAL_PROMPT_MAPPING


async def generate_rubric_from_content(content: str) -> str:
    """Legacy shim — delegates to RubricStore.generate_rubric() with a temporary client."""
    # RubricStore.generate_rubric() doesn't need supabase for pure generation (update_db=False)
    # Pass None and set update_db=False
    store = _RubricStore(supabase=None)
    return await store.generate_rubric(lesson_context=content, update_db=False) or ""
