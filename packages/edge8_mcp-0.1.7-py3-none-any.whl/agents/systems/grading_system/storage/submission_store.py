"""
Submission storage layer for database read/write operations.

This module provides a clean separation between grading orchestration
and submission persistence logic.
"""
from __future__ import annotations
from typing import Dict, List, Optional, Any
from datetime import datetime

from agents.systems.grading_system.models import GradingReport, grading_report_to_dict


class SubmissionStore:
    """Storage layer for submission database operations."""

    def __init__(self, supabase: Client) -> None:
        """
        Initialize SubmissionStore with Supabase client.

        Args:
            supabase: Supabase client instance
        """
        self.supabase = supabase

    def _resolve_challenge_type(self, submission_id: int) -> str:
        """
        Resolve the challenge type for a submission.

        Preferred path (new): challenge_submissions.challenge_uuid → challenges.type
        Fallback path (legacy): challenge_submissions.challenge_id → lessons → challenges.type

        Returns 'mission_final' if lookup fails (preserves existing behavior).
        """
        try:
            sub = (
                self.supabase.table("challenge_submissions")
                .select("challenge_id, challenge_uuid")
                .eq("id", submission_id)
                .limit(1)
                .execute()
            )
            if not sub.data:
                return "mission_final"

            challenge_uuid = sub.data[0].get("challenge_uuid")
            lesson_id = sub.data[0].get("challenge_id")

            # Preferred: direct lookup via challenge_uuid
            if challenge_uuid:
                challenge = (
                    self.supabase.table("challenges")
                    .select("type")
                    .eq("id", challenge_uuid)
                    .limit(1)
                    .execute()
                )
                if challenge.data:
                    return challenge.data[0].get("type", "mission_final")

            # Fallback: legacy path via lessons
            if not lesson_id:
                return "mission_final"

            lesson = (
                self.supabase.table("lessons")
                .select("name, space_id, type")
                .eq("id", lesson_id)
                .limit(1)
                .execute()
            )
            if not lesson.data:
                return "mission_final"

            space_id = lesson.data[0]["space_id"]
            lesson_name = lesson.data[0].get("name", "")
            lesson_type = lesson.data[0].get("type", "")

            # Match the specific challenge by name within this mission
            challenge = (
                self.supabase.table("challenges")
                .select("type")
                .eq("mission_id", space_id)
                .eq("is_legacy", False)
                .eq("name", lesson_name)
                .limit(1)
                .execute()
            )
            if challenge.data:
                return challenge.data[0].get("type", "mission_final")

            # Fallback: if no exact name match, infer from lesson type
            if lesson_type == "mission_final":
                return "mission_final"
            return "mission"
        except Exception as e:
            print(f"⚠️ Could not resolve challenge type: {e}")
            return "mission_final"

    async def store_grading_results(
        self,
        submission_id: int,
        report: GradingReport,
        challenge_type: Optional[str] = None,
    ) -> bool:
        """
        Store grading results back to Supabase challenge_submissions table.

        Args:
            submission_id: ID of the submission
            report: GradingReport object
            challenge_type: Optional challenge type (mission_final/mission/micro_session).
                           If provided, skips database lookup via _resolve_challenge_type.

        Returns:
            True if successful, False otherwise
        """
        try:
            grading_data = grading_report_to_dict(report)

            # Resolve challenge type to determine grade_status
            if challenge_type is None:
                challenge_type = self._resolve_challenge_type(submission_id)

            if challenge_type == "mission_final":
                grade_status = "pass" if report.total_score >= 80 else "redo"
            else:
                # Non-final challenges always pass — we only track submission
                grade_status = "pass"
                print(f"ℹ️ Non-final challenge (type={challenge_type}) — grade_status forced to 'pass'")

            # Update challenge_submissions table
            _response = (
                self.supabase.table("challenge_submissions")
                .update(
                    {
                        **grading_data,
                        "status": "graded",
                        "grade_status": grade_status,
                        "graded_at": datetime.utcnow().isoformat(),
                    }
                )
                .eq("id", submission_id)
                .execute()
            )

            print(f"✅ Stored grading results for submission {submission_id}")
            return True

        except Exception as e:
            print(f"❌ Error storing grading results: {str(e)}")
            return False

    async def update_overall_feedback(
        self, submission_id: int, overall_feedback: str
    ) -> bool:
        """
        Lightweight DB update to set overall_feedback after generation.

        The feedback column holds a plain string. store_grading_results() writes it as ""
        (report.overall_feedback is empty at fire-and-forget time); this method patches it
        with the final streamed value once the stream completes.
        """
        try:
            self.supabase.table("challenge_submissions") \
                .update({"feedback": overall_feedback}) \
                .eq("id", submission_id) \
                .execute()
            print(f"✅ Patched overall_feedback for submission {submission_id}")
            return True
        except Exception as e:
            print(f"⚠️ Failed to update overall_feedback: {e}")
            return False

    async def fetch_submission_attachments(
        self, submission_id: int
    ) -> Optional[List[Dict[str, Any]]]:
        """
        Fetch submission attachments from Supabase submission_attachment view.

        Args:
            submission_id: ID of the submission

        Returns:
            List of attachment objects with storage_object_name or None
        """
        try:
            response = (
                self.supabase.table("submission_attachment")
                .select("attachments")
                .eq("id", submission_id)
                .execute()
            )

            if not response.data or len(response.data) == 0:
                print(f"❌ No attachments found for submission {submission_id}")
                return None

            attachments_json = response.data[0].get("attachments")

            if isinstance(attachments_json, str):
                import json
                attachments = json.loads(attachments_json)
            else:
                attachments = attachments_json

            print(f"✅ Fetched {len(attachments)} attachment(s) from Supabase")
            return attachments

        except Exception as e:
            print(f"❌ Error fetching submission attachments: {str(e)}")
            return None

    async def fetch_prior_submission_content(
        self, submission_id: int
    ) -> Optional[Dict[str, Any]]:
        """
        Fetch prior submission content for resubmission comparison.

        Args:
            submission_id: ID of the prior submission

        Returns:
            Dict with keys: text_content, score, feedback, created_at
            None if submission not found or error occurs
        """
        try:
            result = self.supabase.table("challenge_submissions") \
                .select("text_content, score, feedback, created_at") \
                .eq("id", submission_id) \
                .single() \
                .execute()

            if result.data:
                return {
                    "text_content": result.data.get("text_content") or "",
                    "score": result.data.get("score", 0.0),
                    "feedback": result.data.get("feedback") or "",
                    "created_at": result.data.get("created_at", "")
                }
            return None
        except Exception as e:
            print(f"⚠️ Failed to fetch prior submission {submission_id}: {e}")
            return None
