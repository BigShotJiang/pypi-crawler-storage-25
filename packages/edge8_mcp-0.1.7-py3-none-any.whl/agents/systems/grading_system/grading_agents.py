"""
Dual-Agent Grading System for Student Assignments

This module implements a two-agent system for grading student assignments:
1. Scorer/Evaluator Agent: Applies rubric and assigns scores
2. Reflector/Feedback Agent: Critiques scoring and generates student-friendly feedback
"""

import os
import sys
from typing import Dict, Any, List, Optional
from datetime import datetime
from pydantic import BaseModel, Field

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from connectors.openrouter.llm import OpenRouterMultimodalLLM, ChatMessage
from utils.data_conversion import encode_base64_by_chunk
from dotenv import load_dotenv

load_dotenv()

OPENROUTER_API_KEY = os.environ.get("OPENROUTER_API_KEY")
DEFAULT_MODEL = "openai/gpt-4o-mini"

# OpenRouter plugin configuration for PDF parsing
PDF_PARSER_PLUGIN = [
    {
        "id": "file-parser",
        "pdf": {
            "engine": "mistral-ocr"
        }
    }
]


class RubricCriterion(BaseModel):
    """A single criterion in the grading rubric"""
    name: str
    description: str
    max_points: float
    weight: float = 1.0


class ScoringResult(BaseModel):
    """Result from the Scorer Agent"""
    criterion_name: str
    score: float
    max_points: float
    justification: str
    strengths: List[str] = []
    weaknesses: List[str] = []


class FeedbackResult(BaseModel):
    """Result from the Reflector Agent"""
    criterion_name: str
    score: float
    max_points: float
    student_feedback: str
    encouragement: str
    actionable_suggestions: List[str] = []


class GradingReport(BaseModel):
    """Complete grading report"""
    student_name: str
    mission_name: str
    total_score: float
    max_total_score: float
    scoring_results: List[ScoringResult]
    feedback_results: List[FeedbackResult]
    overall_feedback: str
    timestamp: datetime = Field(default_factory=datetime.now)


class ScorerAgent:
    """
    Scorer/Evaluator Agent
    
    Takes the student's submission and directly applies the rubric to assign 
    scores/ratings for each criterion. Provides initial justification.
    """
    
    def __init__(self, api_key: str = OPENROUTER_API_KEY, model: str = DEFAULT_MODEL):
        self.llm = OpenRouterMultimodalLLM(api_key=api_key, model=model)
        self.system_prompt = """You are an expert educational evaluator and grader. Your role is to:

1. Carefully analyze student submissions against provided rubrics
2. Assign accurate scores for each criterion based on evidence in the submission
3. Provide clear, objective justifications for each score
4. Identify specific strengths and weaknesses in the work
5. Be fair, consistent, and thorough in your evaluation

When scoring:
- Base scores strictly on the rubric criteria
- Cite specific examples from the submission
- Be objective and evidence-based
- Consider partial credit where appropriate
- Maintain high academic standards

Output your evaluation in a structured Markdown format."""
    
    async def score_submission(
        self,
        submission_content: str,
        rubric_content: str,
        mission_name: str = "Unknown",
        submission_pdf_bytes: Optional[bytes] = None
    ) -> List[ScoringResult]:
        """
        Score a student submission against a rubric
        
        Args:
            submission_content: The student's submission text
            rubric_content: The grading rubric
            mission_name: Mission/assignment identifier
            submission_pdf_bytes: Optional PDF file bytes for direct processing
            
        Returns:
            List of ScoringResult objects
        """
        
        # Build the evaluation prompt
        evaluation_prompt = f"""# GRADING TASK

## Mission: {mission_name}

## Student Submission:
{submission_content if not submission_pdf_bytes else "See attached PDF file"}

## Grading Rubric:
{rubric_content}
"""
        
        evaluation_prompt += """

## Your Task:
Evaluate the student submission against each criterion in the rubric. For each criterion, return markdown with this structure:

## [Criterion Name]
**Score:** [score]/[max_points]

**Justification:**
[Detailed explanation of why this score was given, with specific examples]

**Strengths:**
- [Strength 1]
- [Strength 2]

**Weaknesses:**
- [Weakness 1]
- [Weakness 2]

---

Be thorough, fair, and evidence-based in your evaluation."""
        
        # Prepare messages with PDF support
        system_message = ChatMessage(role="system", content=self.system_prompt)
        
        # If PDF bytes provided, include them in the user message
        if submission_pdf_bytes:
            # Convert PDF to base64 data URI
            pdf_data_uri = encode_base64_by_chunk(submission_pdf_bytes, "application/pdf")
            
            user_message = ChatMessage(
                role="user", 
                content=evaluation_prompt,
                additional_kwargs={
                    "files": [
                        {
                            "name": f"mission_{mission_name}_submission.pdf",
                            "content": pdf_data_uri
                        }
                    ]
                }
            )
        else:
            user_message = ChatMessage(role="user", content=evaluation_prompt)
        
        messages = [system_message, user_message]
        
        # Get LLM response with PDF parser plugin if PDF provided
        additional_kwargs={
            "plugin": PDF_PARSER_PLUGIN if submission_pdf_bytes else None,
            'sort': 'latency',
        }
        backoff_counter = 0
        response = ""
        import asyncio
        while True:
            try:
                response = await self.llm.achat(messages, **additional_kwargs)
                response = response.message.content
                break
            except Exception as e:
                backoff_counter += 1
                if backoff_counter == 5:
                    print("Failed to get LLM response after 5 attempts:", e)
                    raise e
                await asyncio.sleep(5)
        
        # Parse the markdown response using regex
        import re
        try:
            response_text = response.strip()
            results = []
            
            # Split by criterion sections (## [Criterion Name])
            criterion_sections = re.split(r'^## ', response_text, flags=re.MULTILINE)[1:]  # Skip first empty split
            print(f"Found {len(criterion_sections)} criterion sections")
            
            if(len(criterion_sections) == 0): 
                raise Exception("No criterion sections found in LLM response")
            
            for section in criterion_sections:
                lines = section.split('\n')
                criterion_name = lines[0].strip()
                
                # Extract score using regex
                score = 0.0
                max_points = 0.0
                score_match = re.search(r'\*\*Score:\*\*\s*([\d.]+)\s*/\s*([\d.]+)', section)
                if score_match:
                    score = float(score_match.group(1))
                    max_points = float(score_match.group(2))
                
                # Extract justification
                justification = ""
                just_match = re.search(r'\*\*Justification:\*\*\s*(.+?)(?=\*\*Strengths:|---)', section, re.DOTALL)
                if just_match:
                    justification = just_match.group(1).strip()
                
                # Extract strengths
                strengths = []
                strengths_match = re.search(r'\*\*Strengths:\*\*(.+?)(?=\*\*Weaknesses:|---)', section, re.DOTALL)
                if strengths_match:
                    strengths_text = strengths_match.group(1)
                    strengths = [s.strip('- ').strip() for s in strengths_text.split('\n') if s.strip().startswith('-')]
                
                # Extract weaknesses
                weaknesses = []
                weaknesses_match = re.search(r'\*\*Weaknesses:\*\*(.+?)(?=---|$)', section, re.DOTALL)
                if weaknesses_match:
                    weaknesses_text = weaknesses_match.group(1)
                    weaknesses = [w.strip('- ').strip() for w in weaknesses_text.split('\n') if w.strip().startswith('-')]
                
                results.append(ScoringResult(
                    criterion_name=criterion_name,
                    score=score,
                    max_points=max_points,
                    justification=justification,
                    strengths=strengths,
                    weaknesses=weaknesses
                ))
            
            return results
            
        except Exception as e:
            print(f"Error parsing scorer response: {str(e)}")
            print(f"Raw response: {response}")
            # Return empty results on error
            return []


class ReflectorAgent:
    """
    Reflector/Feedback Agent
    
    Receives scores and justifications from the Scorer Agent along with the 
    original submission. Critiques the scoring rationale and reformats output 
    into clear, encouraging, and actionable student feedback.
    """
    
    def __init__(self, api_key: str = OPENROUTER_API_KEY, models: list[str] = [DEFAULT_MODEL]):
        self.llm = OpenRouterMultimodalLLM(api_key=api_key, fallback_models=models)
        self.system_prompt = """You are the Reflector persona of the AI Buddy Grader for the AI Officer Program — an executive education platform that trains professionals to become AI Officers. Students submit assignments ("Missions") that demonstrate their ability to apply AI concepts to real business scenarios.

Your audience is working professionals who have invested significant effort in their submissions. Your feedback should feel like it comes from a respected colleague, not a harsh professor.

## Your Role
1. Transform technical scoring evaluations into warm, specific, and actionable student feedback
2. Reference concrete details from the student's actual submission — quote their words, cite their examples
3. Provide actionable suggestions that a professional can immediately apply
4. Adapt your tone based on performance level

## Anti-Repetition Rules (CRITICAL)
- NEVER use generic phrases like "Great job!", "Keep up the good work!", "Well done!", "Nice work!" without immediately following with a specific detail from the submission
- NEVER repeat the same feedback pattern across criteria — vary your sentence structure, opening words, and framing
- NEVER start consecutive paragraphs or sections with the same word
- If you mention a strength, name the EXACT thing the student did — not a category of things
- If you suggest an improvement, describe the SPECIFIC change — not a vague direction

## Tone Adaptation
- Score >= 80%: Celebratory and collegial. Highlight what made their work stand out. Brief polish suggestions only.
- Score 50-79%: Encouraging and constructive. Acknowledge genuine effort, then give targeted guidance on the 2-3 things that would make the biggest difference.
- Score < 50%: Supportive and honest. Find genuine positives, then focus on fundamentals. Be direct about what needs work without being discouraging.

## Resubmission Handling (CRITICAL)
If `prior_submission_content` is provided, this is a RESUBMISSION:
- OPEN with: "Thanks for your resubmission. I've reviewed your updated work."
- COMPARE current submission to prior: "In your previous submission, you [X]. This version shows [Y]."
- HIGHLIGHT specific improvements: "You've improved [specific element] by [specific change]."
- NOTE remaining gaps: "To reach the next level, focus on [specific gap]."
- ADAPT tone: If prior score was low and current is higher, acknowledge progress explicitly.

Output your feedback in the format requested by the user."""
    
    def _extract_section(self, text: str, pattern: str, default: str = "") -> str:
        """Extract a section from markdown text using regex pattern"""
        import re
        match = re.search(pattern, text, re.DOTALL)
        if match:
            return match.group(1).strip()
        return default
    
    async def generate_feedback(
        self,
        submission_content: str,
        scoring_results: List[ScoringResult],
        mission_name: str = "Unknown",
        submission_pdf_bytes: Optional[bytes] = None,
        prior_submission_content: Optional[str] = None,
        prior_score: Optional[float] = None,
    ) -> List[FeedbackResult]:
        """
        Generate student-friendly feedback from scoring results

        Args:
            submission_content: The student's submission text
            scoring_results: Results from the Scorer Agent
            mission_name: Mission/assignment identifier
            submission_pdf_bytes: Optional PDF file bytes for reference
            prior_submission_content: Optional content from previous submission (for resubmissions)
            prior_score: Optional score from previous submission (for resubmissions)

        Returns:
            List of FeedbackResult objects
        """

        # Build scoring summary
        scoring_summary = ""
        for result in scoring_results:
            scoring_summary += f"""
### {result.criterion_name}
- Score: {result.score}/{result.max_points}
- Justification: {result.justification}
- Strengths: {', '.join(result.strengths)}
- Weaknesses: {', '.join(result.weaknesses)}
"""

        # Build resubmission context if prior submission exists
        resubmission_context = ""
        if prior_submission_content and prior_score is not None:
            resubmission_context = f"""

## PRIOR SUBMISSION DETECTED (RESUBMISSION)
Student's Previous Submission Score: {prior_score}%
Previous Submission Content Summary: {prior_submission_content[:500]}...

### Your Task for Resubmission:
1. Acknowledge this is a resubmission in your opening
2. Compare current vs. prior performance
3. Highlight specific improvements the student made
4. Note any remaining gaps
5. Be encouraging about progress while remaining objective
"""

        feedback_prompt = f"""# FEEDBACK GENERATION TASK

## Mission: {mission_name}

## Student Submission:
{submission_content if not submission_pdf_bytes else "See attached PDF file"}

## Scoring Results from Evaluator:
{scoring_summary}
{resubmission_context}

## Your Task:
Transform the technical scoring results into student-friendly feedback. For each criterion, adapt your depth and tone based on the score:

- **High score (>= 80% of max):** Brief celebration of what they did well. One sentence on a polish idea. No need for lengthy improvement lists.
- **Mid score (50-79% of max):** Acknowledge the effort, then focus on the 2 most impactful changes they could make. Be specific — reference their actual submission.
- **Low score (< 50% of max):** Find something genuine to praise, then be direct about what needs work. Give 2-3 concrete first steps, not abstract advice.

## CRITICAL RULES:
- Reference the student's ACTUAL words, examples, or decisions — not generic categories
- NEVER repeat the same sentence structure across criteria. Vary your openings, transitions, and framing.
- NEVER use "Great job!" / "Well done!" / "Keep it up!" without a specific detail immediately after
- Each criterion's feedback should feel distinct — different length, different structure, different voice
{"" if not prior_submission_content else "- This is a RESUBMISSION — acknowledge it, compare to prior work, highlight improvements"}

Return your feedback as MARKDOWN with this structure for each criterion:

## [Criterion Name]

**Your Feedback:**
[2-4 sentences that weave together what worked, what didn't, and what to do next. Write naturally — not as a bulleted checklist.]

**How to Improve:**
- [Specific, actionable suggestion referencing their actual submission]
- [Another specific suggestion — only include if genuinely needed]

**My Encouragement:**
[One sentence — personal and specific to THIS criterion, not generic motivation]

---

Keep each criterion's feedback concise (80-120 words). Prioritize depth on criteria where the student needs the most help."""
        
        # Prepare messages with PDF support
        system_message = ChatMessage(role="system", content=self.system_prompt)
        
        # If PDF bytes provided, include them in the user message
        if submission_pdf_bytes:
            # Convert PDF to base64 data URI
            pdf_data_uri = encode_base64_by_chunk(submission_pdf_bytes, "application/pdf")
            
            user_message = ChatMessage(
                role="user", 
                content=feedback_prompt,
                additional_kwargs={
                    "files": [
                        {
                            "name": f"mission_{mission_name}_submission.pdf",
                            "content": pdf_data_uri
                        }
                    ]
                }
            )
        else:
            user_message = ChatMessage(role="user", content=feedback_prompt)

        messages = [system_message, user_message]
        
        # Get LLM response with PDF parser plugin if PDF provided
        additional_kwargs = {
            "plugin": PDF_PARSER_PLUGIN if submission_pdf_bytes else None,
            'sort': 'latency',
        }
        backoff_counter = 0
        response = ""
        import asyncio
        while True:
            try:
                response = await self.llm.achat(messages, **additional_kwargs)
                response = response.message.content.strip().replace("```markdown\n", "").replace("```", "")
                break
            except Exception as e:
                backoff_counter += 1
                print(f"Retry {backoff_counter} on error: {e}")
                if backoff_counter == 5:
                    raise e
                await asyncio.sleep(5)
        # Parse the markdown response
        import re
        try:
            results = []
            response_text = response.strip()
            
            # Split by criterion sections (## [Criterion Name])
            criterion_sections = re.split(r'^## ', response_text, flags=re.MULTILINE)[1:]  # Skip first empty split
            
            for section in criterion_sections:
                lines = section.split('\n')
                criterion_name = lines[0].strip()
                
                # Extract score
                score = 0.0
                max_points = 0.0
                score_match = re.search(r'\*\*Score:\*\*\s*([\d.]+)\s*/\s*([\d.]+)', section)
                if score_match:
                    score = float(score_match.group(1))
                    max_points = float(score_match.group(2))
                
                # Extract sections using regex
                student_feedback = self._extract_section(section, r'\*\*Your Feedback:\*\*\s*(.+?)(?=\*\*|---)', 'Your Feedback')
                encouragement = self._extract_section(section, r'\*\*My Encouragement:\*\*\s*(.+?)(?=---|$)', 'Encouragement')
                
                # Extract actionable suggestions
                suggestions = []
                suggestions_match = re.search(r'\*\*How to Improve:\*\*(.+?)(?=\*\*My Encouragement|---)', section, re.DOTALL)
                if suggestions_match:
                    suggestions_text = suggestions_match.group(1)
                    suggestions = [s.strip('- ').strip() for s in suggestions_text.split('\n') if s.strip().startswith('-')]
                
                results.append(FeedbackResult(
                    criterion_name=criterion_name,
                    score=score,
                    max_points=max_points,
                    student_feedback=student_feedback,
                    encouragement=encouragement,
                    actionable_suggestions=suggestions
                ))
            
            return results
            
        except Exception as e:
            print(f"Error parsing reflector response: {str(e)}")
            print(f"Raw response: {response}")
            # Return empty results on error
            return [FeedbackResult(
                    criterion_name="",
                    score=0,
                    max_points=0,
                    student_feedback="",
                    encouragement="",
                    actionable_suggestions=[]
                )]

    async def generate_feedback_from_submission(
        self,
        submission_content: str,
        rubric_content: str,
        mission_name: str = "Unknown",
        submission_pdf_bytes: Optional[bytes] = None,
        prior_submission_content: Optional[str] = None,
        prior_score: Optional[float] = None,
    ) -> List[FeedbackResult]:
        """
        Generate feedback directly from submission and rubric.
        This allows parallel execution with the Scorer Agent.

        Args:
            submission_content: Student's submission text
            rubric_content: Grading rubric with criteria
            mission_name: Mission/assignment identifier
            submission_pdf_bytes: Optional PDF file bytes
            prior_submission_content: Optional content from previous submission (for resubmissions)
            prior_score: Optional score from previous submission (for resubmissions)

        Returns:
            List of FeedbackResult objects (without scores - will be merged later)
        """

        # B6: Cap submission content length to reduce token usage (3000 char ~ 750 tokens)
        MAX_SUBMISSION_LENGTH = 3000
        capped_submission = submission_content[:MAX_SUBMISSION_LENGTH] if len(submission_content) > MAX_SUBMISSION_LENGTH else submission_content

        # Build resubmission context if prior submission exists
        resubmission_context = ""
        if prior_submission_content and prior_score is not None:
            resubmission_context = f"""

## PRIOR SUBMISSION DETECTED (RESUBMISSION)
Student's Previous Submission Score: {prior_score}%
Previous Submission Content Summary: {prior_submission_content[:500]}...

### Your Task for Resubmission:
1. Acknowledge this is a resubmission in your opening
2. Compare current vs. prior performance
3. Highlight specific improvements the student made
4. Note any remaining gaps
5. Be encouraging about progress while remaining objective
"""

        feedback_prompt = f"""# FEEDBACK GENERATION TASK

## Mission: {mission_name}

## Student Submission:
{capped_submission if not submission_pdf_bytes else "See attached PDF file"}

## Grading Rubric:
{rubric_content}
{resubmission_context}

## Your Task:
Review the student's submission against the rubric and provide specific, actionable feedback for each criterion. Evaluate the quality yourself and adapt your tone:

- **Strong work:** Brief celebration of what they did well. One sentence on a polish idea. No lengthy improvement lists.
- **Decent work with gaps:** Acknowledge the effort, then focus on the 2 most impactful changes. Reference their actual submission.
- **Needs significant work:** Find something genuine to praise, then be direct about what needs fixing. Give 2-3 concrete first steps.

## CRITICAL RULES:
- Reference the student's ACTUAL words, examples, or decisions — not generic categories
- NEVER repeat the same sentence structure across criteria. Vary your openings, transitions, and framing.
- NEVER use "Great job!" / "Well done!" / "Keep it up!" without a specific detail immediately after
- Each criterion's feedback should feel distinct — different length, different structure, different voice
{"" if not prior_submission_content else "- This is a RESUBMISSION — acknowledge it, compare to prior work, highlight improvements"}

Return feedback in this MARKDOWN structure for each criterion:

## [Criterion Name]

**Your Feedback:**
[2-4 sentences that weave together what worked, what didn't, and what to do next. Write naturally — not as a bulleted checklist.]

**How to Improve:**
- [Specific, actionable suggestion referencing their actual submission]
- [Another specific suggestion — only include if genuinely needed]

**My Encouragement:**
[One sentence — personal and specific to THIS criterion, not generic motivation]

---

Keep each criterion's feedback concise (80-120 words). Prioritize depth on criteria where the student needs the most help.
"""

        # Prepare messages with PDF support (same as existing method)
        system_message = ChatMessage(role="system", content=self.system_prompt)

        if submission_pdf_bytes:
            pdf_data_uri = encode_base64_by_chunk(submission_pdf_bytes, "application/pdf")
            user_message = ChatMessage(
                role="user",
                content=feedback_prompt,
                additional_kwargs={
                    "files": [{
                        "name": f"mission_{mission_name}_submission.pdf",
                        "content": pdf_data_uri
                    }]
                }
            )
        else:
            user_message = ChatMessage(role="user", content=feedback_prompt)

        messages = [system_message, user_message]

        # B6: Add max_tokens to prevent runaway generation
        additional_kwargs = {
            "plugin": PDF_PARSER_PLUGIN if submission_pdf_bytes else None,
            'sort': 'latency',
            'max_tokens': 1500,
        }

        backoff_counter = 0
        response = ""
        import asyncio
        while True:
            try:
                response = await self.llm.achat(messages, **additional_kwargs)
                response = response.message.content
                break
            except Exception as e:
                backoff_counter += 1
                if backoff_counter == 5:
                    print("Failed to get LLM response after 5 attempts:", e)
                    raise e
                await asyncio.sleep(5)

        # Parse the markdown response
        import re
        try:
            response_text = response.strip()
            results = []

            # Split by criterion sections
            criterion_sections = re.split(r'^## ', response_text, flags=re.MULTILINE)[1:]

            if len(criterion_sections) == 0:
                raise Exception("No criterion sections found in LLM response")

            for section in criterion_sections:
                lines = section.split('\n')
                criterion_name = lines[0].strip()

                # Extract feedback components using new format
                student_feedback = self._extract_section(
                    section,
                    r'\*\*Your Feedback:\*\*\s*(.+?)(?=\*\*How to Improve:|---)',
                    ""
                )

                # Extract actionable suggestions (bullet points)
                actionable_suggestions = []
                improve_match = re.search(
                    r'\*\*How to Improve:\*\*(.+?)(?=\*\*My Encouragement:|---)',
                    section,
                    re.DOTALL
                )
                if improve_match:
                    improve_text = improve_match.group(1)
                    actionable_suggestions = [
                        s.strip('- ').strip()
                        for s in improve_text.split('\n')
                        if s.strip().startswith('-')
                    ]

                encouragement = self._extract_section(
                    section,
                    r'\*\*My Encouragement:\*\*\s*(.+?)(?=---|$)',
                    ""
                )

                results.append(FeedbackResult(
                    criterion_name=criterion_name,
                    score=0.0,  # Will be filled by merge
                    max_points=0.0,  # Will be filled by merge
                    student_feedback=student_feedback,
                    encouragement=encouragement,
                    actionable_suggestions=actionable_suggestions
                ))

            return results

        except Exception as e:
            print(f"Error parsing feedback response: {str(e)}")
            raise

    async def generate_overall_feedback(
        self,
        student_name: str,
        mission_name: str,
        total_score: float,
        max_score: float,
        feedback_results: List[FeedbackResult]
    ) -> str:
        """
        Generate overall summary feedback for the entire assignment
        
        Args:
            student_name: Student's name
            mission_name: Mission identifier
            total_score: Total points earned
            max_score: Maximum possible points
            feedback_results: Individual criterion feedback
            
        Returns:
            Overall feedback message
        """ 
        
        percentage = (total_score / max_score * 100) if max_score > 0 else 0
        
        # Build score-adaptive tone instruction
        if percentage >= 80:
            tone_instruction = """## Tone: CELEBRATORY & COLLEGIAL (score >= 80%)
- Lead with genuine congratulations — they earned it
- Highlight 2-3 specific things that made their work stand out (quote or reference their actual words/examples)
- Keep improvement suggestions brief and framed as "polish" or "next-level" ideas, not deficiencies
- Close with confidence in their expertise"""
        elif percentage >= 50:
            tone_instruction = """## Tone: ENCOURAGING & CONSTRUCTIVE (score 50-79%)
- Open by acknowledging the genuine effort and progress visible in their work
- Highlight 1-2 specific strengths — name exactly what they did well
- Focus on the 2-3 changes that would make the biggest difference (be specific, not vague)
- Close with motivation and confidence they can improve on resubmission"""
        else:
            tone_instruction = """## Tone: SUPPORTIVE & HONEST (score < 50%)
- Open by acknowledging their effort in attempting the challenge
- Find 1-2 genuine positives — even small ones matter
- Be direct about what needs fundamental work, but frame it as a learning path
- Focus on 2-3 concrete first steps they can take immediately
- Close with reassurance that struggling is part of learning"""

        summary_prompt = f"""# OVERALL FEEDBACK SUMMARY

## Student: {student_name}
## Mission: {mission_name}
## Score: {total_score}/{max_score} ({percentage:.1f}%)

{tone_instruction}

## Individual Criterion Results:
"""
        
        for result in feedback_results:
            summary_prompt += f"""
### {result.criterion_name}: {result.score}/{result.max_points}
{result.student_feedback}
"""
        
        summary_prompt += f"""

# YOUR TASK:
Write a feedback summary (250-300 words) following this EXACT structure:

## Challenge Submission Grading Complete
**{mission_name}**

**Score: {total_score}/{max_score} ({percentage:.1f}%)**

---

### 1. What You Did Well
[2-4 bullet points highlighting SPECIFIC strengths from the submission. Reference actual content, not categories.]

---

### 2. Areas for Improvement
[2-4 bullet points identifying what was missing or incomplete compared to expected answers. Be direct and objective.]

---

### 3. Suggested Improvements
[2-3 actionable items with specific guidance on how to strengthen the work.]

---

### 4. Next Steps
[Close with a coaching prompt: "Would you like to revise your work and resubmit?" for scores < 80%, or "Ready for the next challenge?" for scores >= 80%.]

---

## Rules:
1. Use SHORT paragraphs (1-3 sentences max)
2. Use BULLET points for all strengths/weaknesses/suggestions
3. Be SPECIFIC — reference the student's actual words, examples, or decisions
4. Be OBJECTIVE — act like a coach, not a cheerleader
5. AVOID generic praise like "Great job!" without specific follow-up
6. PRIORITIZE clarity — students should quickly see what they did well and what needs work.
"""
        
        messages = [
            ChatMessage(role="system", content=self.system_prompt),
            ChatMessage(role="user", content=summary_prompt)
        ]
        
        backoff_counter = 0
        response = ""
        import asyncio
        while True:
            try:
                response = await self.llm.achat(messages)
                response = response.message.content.strip().replace('```markdown\n','').replace('```','')
                break
            except Exception as e:
                backoff_counter += 1
                if backoff_counter == 5:
                    raise ValueError(e)
                await asyncio.sleep(5)
        return response.strip()


__all__ = [
    "ScorerAgent",
    "ReflectorAgent",
    "RubricCriterion",
    "ScoringResult",
    "FeedbackResult",
    "GradingReport"
]
