# AgentSystem — High-Level Guide

**File:** `src/agents/systems/simple_agent_system.py`  
**Class:** `AgentSystem`  
**Lines:** ~755  
**Last updated:** 2026-02-27 (post Phase 10 refactor)  
**Role:** Central orchestrator for the AI chatbot. Routes user input through intent detection, tool execution, and answer generation via a streaming SSE pipeline.

---

## What It Does

AgentSystem is the **brain** of the chatbot. Every user message enters through `run_stream()`, which decides:

1. Can we answer immediately from pre-loaded context? → **Prefetch Shortcut**
2. Is there an active grading workflow? → **Workflow Dispatch**
3. Otherwise → **Agent Loop** (Route → Tool → Answer)

It produces a stream of **SSE events** (content, reasoning, timing, metadata, error) consumed by the frontend.

---

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                         HTTP Layer                              │
│   router/chatbot/chat.py  ·  router/lark/agents/tool_use.py    │
└──────────────────────────────┬──────────────────────────────────┘
                               │ run_stream(user_input, email, files, ...)
                               ▼
┌─────────────────────────────────────────────────────────────────┐
│                       AgentSystem                               │
│                  simple_agent_system.py (~755 lines)             │
│                                                                 │
│  ┌──────────┐  ┌──────────┐  ┌───────────┐  ┌──────────────┐   │
│  │  Router   │  │   Tool   │  │ Answering │  │   Intent     │   │
│  │  Agent    │  │   Agent  │  │   Agent   │  │  Verifier    │   │
│  └────┬─────┘  └────┬─────┘  └─────┬─────┘  └──────┬───────┘   │
│       │              │              │               │           │
│  Decides intent  Picks tool &   Streams final   Verifies       │
│  (CHAT/TOOL)     executes it    LLM answer      grading intent │
│                                                                 │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │  ToolExecutor (tool_executor.py)                         │   │
│  │  Entity resolution → Direct DB or RAG fallback           │   │
│  └──────────────────────────────────────────────────────────┘   │
└──────────────────────────────────┬──────────────────────────────┘
                                   │
              ┌────────────────────┼────────────────────┐
              ▼                    ▼                    ▼
    ┌─────────────────┐  ┌─────────────────┐  ┌──────────────┐
    │  SessionManager  │  │ GradingEvent    │  │  Database     │
    │  (Supabase)      │  │ Handler         │  │  ToolHandler  │
    └─────────────────┘  └─────────────────┘  └──────────────┘
```

---

## Request Lifecycle

```
User Message
     │
     ▼
 ┌───────────────────┐
 │  1. _init_turn()   │  Resolve email, save message, reset state,
 │                     │  prefetch context (cached), extract file metadata
 └────────┬───────────┘
          │
          ▼
 ┌───────────────────────────┐
 │  2. Prefetch Shortcut?     │──── YES ──→ Stream answer from context → DONE
 │  (context loaded, no action│
 │   keywords, no files)      │
 └────────┬───────────────────┘
          │ NO
          ▼
 ┌───────────────────────────┐
 │  3. Workflow Active?       │──── YES ──→ Dispatch to GradingEventHandler → DONE
 │  (mission confirmation,    │            (confirmation / grading / posting / resub)
 │   posting, resubmission)   │
 └────────┬───────────────────┘
          │ NO
          ▼
 ┌───────────────────────────────────────────────┐
 │  4. Main Agent Loop (max 3 iterations)         │
 │                                                 │
 │   ┌─── General Chat? ──→ Answer directly ─────┐│
 │   │                                            ││
 │   │   Auto-resolve entity (if first iteration) ││
 │   │          │                                  ││
 │   │   Auto-resolve shortcut? (Phase 9)          ││
 │   │   (entity resolved + context loaded          ││
 │   │    + no action keywords → answer directly)   ││
 │   │          │ NO                                ││
 │   │          ▼                                  ││
 │   │   RouterAgent.decide()                      ││
 │   │     │           │           │               ││
 │   │     ▼           ▼           ▼               ││
 │   │   GRADING    FINISHED     TOOL              ││
 │   │     │        + CHAT         │               ││
 │   │     ▼           │           ▼               ││
 │   │  Grading     Halluc.    ToolExecutor         ││
 │   │  Handler     Guard      .execute_with_      ││
 │   │  → DONE        │        resolution()        ││
 │   │              Answer     → loop back          ││
 │   │              → DONE                         ││
 │   └────────────────────────────────────────────┘│
 └─────────────────────────────────────────────────┘
```

---

## Component Map

```
src/agents/systems/
├── simple_agent_system.py   ← THIS FILE (orchestrator, ~755 lines)
├── tool_executor.py         ← ToolExecutor: entity resolution + DB/RAG tool execution
├── shared.py                ← AgentState, MessageRole, AgentIntent, AgentStatus
├── constants.py             ← WorkflowType, keyword sets, LLM/Redis factories
├── response_types.py        ← SSE event builders (build_content_event, etc.)
├── session_manager.py       ← Supabase session persistence
├── grading_event_handler.py ← Grading workflow state machine
├── file_processor.py        ← File metadata extraction, PDF/image processing
└── grading_system/
    └── optimized_grading_workflow.py  ← Grading execution engine

src/agents/subagents/
├── router_agent.py          ← LLM-powered intent classifier
├── tool_agent.py            ← LLM-powered tool selector + executor
├── answering_agent.py       ← LLM-powered response streamer
└── intent_verification_agent.py  ← Grading intent confirmation

src/agents/tools/
├── preprocessing/entity_resolver.py  ← Entity name → DB ID resolution
├── database/aio/aio.py              ← DatabaseToolHandler (Supabase queries)
└── schema.py                         ← Tool definitions by group

src/agents/context/
├── prefetcher.py            ← Pre-loads entity data (with Redis cache layer)
└── registry.py              ← Parallel context provider fetch with timeout
```

---

## Key Concepts

### SSE Event Types

All methods yield `dict` events consumed by the frontend SSE stream:

| Type | Builder | When |
|------|---------|------|
| **content** | `build_content_event()` | LLM answer chunks |
| **reasoning** | `build_reasoning_event()` | Internal decision explanations |
| **timing** | `build_timing_event()` | Performance monitoring |
| **metadata** | `build_metadata_event()` | Structured data (files, scores) |
| **error** | `build_error_event()` | Exception handling |

### Workflow State Machine

Grading uses a multi-turn state machine persisted in `state.workflow_state`:

```
[No State] → MISSION_CONFIRMATION → MISSION_CONFIRMED → Grading
                                                           │
                                              score ≥ 80 ──┤── score < 80 → Feedback
                                                           ▼
                                              POSTING_CONFIRMATION → Post to Circle
                                                           │
                                              Prior exists ─┤
                                                           ▼
                                              RESUBMISSION → Re-grade
```

### Safety Guards

| Guard | Trigger | Action |
|-------|---------|--------|
| **Circuit Breaker** | ≥2 iterations, no tool results | Force TOOL intent |
| **Hallucination Guard** | Domain question + no grounding data | Redirect to tool search |
| **Hard Stop** | >3 iterations | Force answer with available data |
| **Cancel Escape Hatch** | "cancel", "stop", "quit", etc. | Clear workflow state |

---

## External Dependencies

| Dependency | Purpose | Env Var |
|------------|---------|---------|
| **OpenRouter** | LLM inference (routing, tools, answers) | `OPENROUTER_API_KEY` |
| **Supabase** | Session storage, entity DB queries | `AIO_SUPABASE_URL`, `AIO_SUPABASE_SERVICE_ROLE_KEY` |
| **Upstash Redis** | Caching (prefetch, router, answers) | `UPSTASH_REDIS_URL`, `UPSTASH_REDIS_TOKEN` |

---

## Entry Points

| Caller | How | Context |
|--------|-----|---------|
| `router/chatbot/chat.py` | `AgentSystem(tool_groups, session_id, member_id).run_stream(...)` | Main chatbot API |
| `router/lark/agents/tool_use.py` | `AgentSystem(tool_groups=["lark"]).run_stream(...)` | Lark bot integration |
