"""Entity resolution + deterministic DB routing + RAG fallback."""

from typing import AsyncGenerator, Optional, Dict, Any
from time import time

from agents.systems.shared import AgentState, MessageRole
from agents.systems.response_types import build_reasoning_event, build_timing_event
from agents.tools.schema import get_tools_by_group
from agents.tools.preprocessing.entity_resolver import EntityResolver, ResolvedQuery
from agents.tools.database.aio.aio import DatabaseToolHandler
from agents.context.prefetcher import ContextPrefetcher
from agents.subagents.tool_agent import ToolAgent
from agents.systems.constants import ENTITY_KEYWORDS, ENTITY_TYPE_TO_RESOURCE


class ToolExecutor:
    """Handles entity resolution, deterministic DB routing, and RAG fallback.

    Extracted from AgentSystem to separate tool-layer concerns from orchestration.
    """

    def __init__(
        self,
        entity_resolver: EntityResolver,
        database_tool: DatabaseToolHandler,
        tool_agent: ToolAgent,
        context_prefetcher: ContextPrefetcher,
    ):
        self.entity_resolver = entity_resolver
        self.database_tool = database_tool
        self.tool_agent = tool_agent
        self.context_prefetcher = context_prefetcher

    async def execute_with_resolution(
        self,
        state: AgentState,
        user_input: str,
        chosen_group: str,
    ) -> AsyncGenerator[dict, None]:
        """Execute entity resolution + tool call (direct DB or ToolAgent+RAG).

        Handles:
        - Entity resolution (Phase 2B)
        - Deterministic DB routing (GAP-A)
        - Fallback to ToolAgent+RAG

        Yields:
            Reasoning events and timing events.
        """
        tool_start = time()

        # Phase 9: Reuse entity resolution from auto_resolve_entity if available
        if state.resolved_entities:
            last = state.resolved_entities[-1]
            resolved_result = ResolvedQuery(
                original=user_input,
                resolved_query=last.get("name", user_input),
                resolved=True,
                entity_type=last.get("type"),
                entity_id=last.get("id"),
                entity_name=last.get("name"),
                enriched_query=last.get("resolved_query"),
            )
        else:
            resolved_result = await self.entity_resolver.resolve(
                query=user_input,
                conversation_history=[
                    {"role": msg.role.value, "content": msg.content}
                    for msg in state.messages[-5:]
                ]
            )

        if resolved_result.resolved:
            yield build_reasoning_event(
                step="Looking Up",
                reasoning=(
                    f"I identified a specific {resolved_result.entity_type} mentioned in the query: '{resolved_result.entity_name}'. "
                    f"The original question was '{resolved_result.original}' and I resolved it to a known entity in the database. "
                    f"This means I can look up the exact record rather than doing a broad search across all content. "
                    f"Let me save this resolved entity and proceed to fetch the details directly."
                )
            )

            if not state.resolved_entities:
                state.resolved_entities = []
            state.resolved_entities.append({
                "type": resolved_result.entity_type,
                "id": resolved_result.entity_id,
                "name": resolved_result.entity_name,
                "original_query": resolved_result.original,
                "resolved_query": resolved_result.resolved_query,
            })

            yield build_reasoning_event(
                step="Retrieving Details",
                reasoning=(
                    f"Now I'm fetching the full details for {resolved_result.entity_type} '{resolved_result.entity_name}' directly from the database. "
                    f"Since the entity was resolved to a specific record (ID: {resolved_result.entity_id}), I can query it deterministically. "
                    f"This direct lookup approach is more reliable than a general search because it targets the exact resource. "
                    f"I'll include related data like sub-items and metadata to give a comprehensive answer."
                )
            )
            try:
                db_result = await self.database_tool.execute(
                    resource=self.map_entity_type_to_resource(resolved_result.entity_type),
                    name=resolved_result.entity_name,
                    limit=10,
                    include_related=True,
                )
                if db_result and not db_result.get("error"):
                    state.tool_results = [db_result]
                else:
                    yield build_reasoning_event(
                        step="Searching",
                        reasoning=(
                            f"The direct database lookup for {resolved_result.entity_type} '{resolved_result.entity_name}' didn't return usable results. "
                            f"This can happen when the record exists but doesn't have the specific details needed to answer the question. "
                            f"I'm falling back to a broader search using the enriched query to find relevant information from other sources. "
                            f"The tool agent will select the best search strategy based on what the user is asking about."
                        )
                    )
                    if resolved_result.enriched_query:
                        state.current_input = resolved_result.enriched_query
                    state.tool_schemas = get_tools_by_group(chosen_group)
                    state.tool_results = await self.tool_agent.select_tool(state)
            except Exception as e:
                print(f"⚠️ Direct DB fetch error: {e}")
                if resolved_result.enriched_query:
                    state.current_input = resolved_result.enriched_query
                state.tool_schemas = get_tools_by_group(chosen_group)
                state.tool_results = await self.tool_agent.select_tool(state)
        else:
            if resolved_result.enriched_query:
                state.current_input = resolved_result.enriched_query
            state.tool_schemas = get_tools_by_group(chosen_group)
            state.tool_results = await self.tool_agent.select_tool(state)

        yield build_timing_event("tool_execution", (time() - tool_start) * 1000)

        if state.tool_results:
            tool_results_summary = state.format_tool_results_for_history(state.tool_results)
            state.add_message(
                MessageRole.TOOL,
                tool_results_summary,
                name="tool_execution"
            )

    async def auto_resolve_entity(
        self,
        state: AgentState,
        user_input: str,
        session_context_type: Optional[str] = None,
    ) -> AsyncGenerator[dict, None]:
        """Auto-resolve entity context for general sessions with entity terms."""
        has_entity_terms = any(kw in user_input.lower() for kw in ENTITY_KEYWORDS)
        if (
            has_entity_terms
            and state.iteration_count == 1
            and not state.context_prefetch
            and not session_context_type
        ):
            try:
                auto_resolved = await self.entity_resolver.resolve(
                    query=user_input,
                    conversation_history=[
                        {"role": msg.role.value, "content": msg.content}
                        for msg in state.messages[-5:]
                    ]
                )
                if auto_resolved.resolved and auto_resolved.entity_id:
                    yield build_reasoning_event(
                        step="Looking Up",
                        reasoning=(
                            f"I detected entity keywords in the message and resolved them to a specific {auto_resolved.entity_type}: '{auto_resolved.entity_name}'. "
                            f"Even though this session didn't start with a pre-loaded context, I can still fetch the relevant data now. "
                            f"I'm loading the {auto_resolved.entity_type} details so the router and answering agents have accurate information to work with. "
                            f"This auto-resolution step helps ensure I reference real data instead of generating an answer from memory alone."
                        )
                    )
                    prefetch_data = await self.context_prefetcher.fetch(
                        context_type=auto_resolved.entity_type,
                        context_id=str(auto_resolved.entity_id)
                    )
                    if prefetch_data:
                        state.context_prefetch = prefetch_data
                        # Invalidate shared cache — it was built before prefetch data existed.
                        # The answering agent's registry must re-run to include PrefetchContextProvider.
                        state._context_cache = None
                        if not state.resolved_entities:
                            state.resolved_entities = []
                        state.resolved_entities.append({
                            "type": auto_resolved.entity_type,
                            "id": auto_resolved.entity_id,
                            "name": auto_resolved.entity_name,
                            "resolved_query": auto_resolved.enriched_query,
                        })
            except Exception as e:
                print(f"⚠️ Auto-resolve failed (non-fatal): {e}")

    @staticmethod
    def map_entity_type_to_resource(entity_type: str) -> str:
        """Map entity resolver types to DatabaseToolHandler resource names.

        Args:
            entity_type: Entity type from ResolvedQuery (e.g., "mission", "challenge")

        Returns:
            Resource name for DatabaseToolHandler.execute()
        """
        return ENTITY_TYPE_TO_RESOURCE.get(entity_type, entity_type)
