"""Grading workflow event handler for AgentSystem.

Extracts all grading workflow event handlers from AgentSystem into a dedicated
GradingEventHandler class. Manages the multi-step grading flow:
1. Mission confirmation → grading → score check
2. High score → posting confirmation → post to Circle
3. Low score → show feedback
4. Resubmission → confirm → re-grade
"""

from typing import AsyncGenerator, Optional, List, Dict, Any
import asyncio
import json
from time import time

from agents.systems.shared import AgentState, MessageRole
from agents.systems.constants import WorkflowType, CANCEL_KEYWORDS
from agents.systems.grading_system.core import GradingWorkflowV2 as GradingWorkflow
from agents.systems.response_types import (
    build_content_event,
    build_reasoning_event,
    build_error_event,
)


class GradingEventHandler:
    """Handles grading workflow state machine events.

    Manages the multi-step grading flow:
    1. Mission confirmation → grading → score check
    2. High score → posting confirmation → post to Circle
    3. Low score → show feedback
    4. Resubmission → confirm → re-grade

    All methods are async generators that yield SSE events.
    """

    def __init__(
        self,
        state: AgentState,
        session_mgr,
        answering_agent,
        intent_verifier=None,
        auto_save: bool = True,
        session_id: Optional[str] = None,
    ):
        self.state = state
        self.session_mgr = session_mgr
        self.answering_agent = answering_agent
        self.intent_verifier = intent_verifier
        self.auto_save = auto_save
        self.session_id = session_id

    # --- Public Workflow Handlers ---

    async def handle_mission_confirmation(
        self,
        grading_workflow,
        user_input: str,
        submission_metadata: Dict[str, Any],
        circle_file_urls: Optional[List[str]],
    ) -> AsyncGenerator[Dict[str, str], None]:
        """Handle mission confirmation workflow events."""
        async for event in grading_workflow.handle_mission_confirmation_workflow(
            user_input=user_input,
            submission_metadata=submission_metadata,
            circle_file_urls=circle_file_urls
        ):
            event_type = event.get("type")

            if event_type == "reasoning":
                yield build_reasoning_event(
                    step=event["step"],
                    reasoning=event["message"]
                )
            elif event_type == "error":
                error_msg = event["message"]
                self.state.add_message(MessageRole.ASSISTANT, error_msg)
                if self.session_mgr.auto_save and self.session_mgr.session_id:
                    await self.session_mgr.save_message_async(
                        role="assistant",
                        content=error_msg,
                        metadata={"type": "grading_error", "workflow_state": None, "error": error_msg}
                    )
                    await self.session_mgr.flush_pending()
                yield build_error_event(error_msg)
                return
            elif event_type == "resubmit_warning":
                # Prior passed submission found — set resubmission confirmation state
                self.state.workflow_state = {
                    "type": WorkflowType.RESUBMISSION,
                    "submission_metadata": event.get("submission_metadata"),
                    "circle_file_urls": circle_file_urls or [],
                    "prior_submission": event.get("prior_submission"),
                }
                warning_msg = event.get("message")
                self.state.add_message(MessageRole.ASSISTANT, warning_msg)

                if self.session_mgr.auto_save and self.session_mgr.session_id:
                    await self.session_mgr.save_message_async(
                        role="assistant",
                        content=warning_msg,
                        metadata={
                            "type": "resubmit_warning",
                            "prior_submission": event.get("prior_submission"),
                            "workflow_state": self.state.workflow_state,
                        }
                    )
                await self.session_mgr.flush_pending()
                yield build_content_event(warning_msg)
                return
            elif event_type == "grading_complete":
                # Propagate circle_file_urls into grading_data for workflow state persistence
                grading_data = event.get("grading_data", {})
                grading_data["circle_file_urls"] = circle_file_urls or []
                event["grading_data"] = grading_data
                async for result_event in self.handle_grading_complete(event):
                    yield result_event
                return
            elif event_type == "submission_cancelled":
                async for cancel_event in self.handle_submission_cancelled(event):
                    yield cancel_event
                return

    async def handle_posting_confirmation(
        self,
        grading_workflow,
        user_input: str,
        grading_data: Dict[str, Any],
        circle_file_urls: Optional[List[str]],
    ) -> AsyncGenerator[Dict[str, str], None]:
        """Handle posting confirmation workflow events."""
        async for event in grading_workflow.handle_posting_confirmation_workflow(
            user_input=user_input,
            grading_data=grading_data,
            circle_file_urls=circle_file_urls
        ):
            event_type = event.get("type")

            if event_type == "reasoning":
                yield build_reasoning_event(
                    step=event["step"] or "Posting",
                    reasoning=event["message"]
                )
            elif event_type == "posting_complete":
                async for post_event in self.handle_posting_complete(event):
                    yield post_event
                return
            elif event_type == "posting_declined":
                async for decline_event in self.handle_posting_declined(event):
                    yield decline_event
                return

    async def handle_grading_complete(
        self,
        event: Dict[str, Any]
    ) -> AsyncGenerator[Dict[str, str], None]:
        """Handle grading complete with high/low score branching."""
        action = event.get("action")
        grading_data: Dict[Any, Any] = event.get("grading_data")

        grading_summary = grading_data.get("feedback", "No feedback provided")
        self.state.add_message(MessageRole.ASSISTANT, grading_summary)
        self.state.add_submission_result(grading_data)

        if action == "request_posting_confirmation":
            # High score — stream the structured feedback first, then the posting prompt
            feedback_markdown = grading_data.get("feedback", "")
            self.state.workflow_state = {
                "type": WorkflowType.POSTING_CONFIRMATION,
                "grading_data": grading_data,
                "circle_file_urls": grading_data.get("circle_file_urls", [])
            }
            confirmation_message = self.generate_posting_confirmation(grading_data)

            if self.session_mgr.auto_save and self.session_mgr.session_id:
                await self.session_mgr.save_message_async(
                    role="assistant",
                    content=grading_summary,
                    metadata={
                        "type": "grading_confirmation",
                        "workflow_state": self.state.workflow_state,
                        "score": grading_data.get("score"),
                        "grading_data": grading_data,
                    }
                )
            await self.session_mgr.flush_pending()
            if feedback_markdown:
                async for chunk in self._stream_text(feedback_markdown + "\n\n"):
                    yield chunk
            yield confirmation_message
        elif action == "show_low_score_feedback":
            # Low score - show structured feedback as the full message
            low_score_message = event.get("message") or grading_data.get("feedback", "")
            self.state.add_message(MessageRole.ASSISTANT, low_score_message)
            self.state.workflow_state = None

            if self.session_mgr.auto_save and self.session_mgr.session_id:
                await self.session_mgr.save_message_async(
                    role="assistant",
                    content=low_score_message,
                    metadata={
                        "type": "grading_low_score",
                        "workflow_state": None,
                        "score": event.get("score")
                    }
                )
            await self.session_mgr.flush_pending()
            async for chunk in self._stream_text(low_score_message):
                yield chunk

    async def handle_posting_complete(
        self,
        event: Dict[str, Any]
    ) -> AsyncGenerator[Dict[str, str], None]:
        """Handle posting complete (success or error)."""
        post_result = event.get("post_result") or {}
        post_url = post_result.get("url", "")
        post_content = post_result.get("markdown", "")

        already_streamed = False
        if post_result.get("error"):
            posting_message = f"❌ Failed to post: {post_result['error']}"
            self.state.add_message(MessageRole.ASSISTANT, posting_message)
        else:
            # Use answering agent to generate brief summary
            prompt = f"""
            Generate a brief confirmation message that the submission has been posted to Circle.
            Summarize the post content: {post_content}.
            Include the post URL: {post_url}.
            Keep it concise and professional.
            """

            # Temporarily add prompt to state for answering agent
            self.state.add_message(MessageRole.USER, prompt)

            posting_message_content = ""
            async for chunk in self.answering_agent.astream_answer(self.state):
                posting_message_content += chunk
                yield build_content_event(chunk)

            # Remove the temporary prompt from state
            self.state.messages.pop()

            # Use accumulated content or fallback
            posting_message = posting_message_content.strip() or "✅ Successfully posted your submission and feedback to Circle!"
            self.state.add_message(MessageRole.ASSISTANT, posting_message)
            already_streamed = True

        # Clear workflow state
        self.state.workflow_state = None

        if self.session_mgr.auto_save and self.session_mgr.session_id:
            await self.session_mgr.save_message_async(
                role="assistant",
                content=posting_message,
                metadata={
                    "type": "posting_confirmation",
                    "workflow_state": None
                }
            )
        await self.session_mgr.flush_pending()
        if not already_streamed:
            yield build_content_event(posting_message)

    async def handle_posting_declined(
        self,
        event: Dict[str, Any]
    ) -> AsyncGenerator[Dict[str, str], None]:
        """Handle user declining to post."""
        decline_message = event.get("message")
        
        # Extract grading data before clearing workflow_state
        grading_data = None
        if self.state.workflow_state and self.state.workflow_state.get("type") == "grading_awaiting_posting_confirmation":
            grading_data = self.state.workflow_state.get("grading_data")
        
        self.state.add_message(MessageRole.ASSISTANT, decline_message)
        
        # If grading data exists, display it to the user before clearing state
        if grading_data:
            feedback = grading_data.get("feedback", "")
            if feedback:
                # Display the grading feedback
                self.state.add_message(MessageRole.ASSISTANT, feedback)
                
                if self.session_mgr.auto_save and self.session_mgr.session_id:
                    # Save the grading feedback message
                    await self.session_mgr.save_message_async(
                        role="assistant",
                        content=feedback,
                        metadata={
                            "type": "grading_confirmation",
                            "score": grading_data.get("score"),
                            "grading_data": grading_data
                        }
                    )
                
                # Yield the grading feedback as streamed content
                async for chunk in self._stream_text(feedback):
                    yield chunk
        
        # Now clear the workflow state
        self.state.workflow_state = None

        if self.session_mgr.auto_save and self.session_mgr.session_id:
            await self.session_mgr.save_message_async(
                role="assistant",
                content=decline_message,
                metadata={
                    "type": "posting_declined",
                    "workflow_state": None
                }
            )
        await self.session_mgr.flush_pending()
        yield build_content_event(decline_message)

    async def handle_submission_cancelled(
        self,
        event: Dict[str, Any]
    ) -> AsyncGenerator[Dict[str, str], None]:
        """Handle submission cancelled."""
        cancel_message = event.get("message")
        self.state.add_message(MessageRole.ASSISTANT, cancel_message)
        self.state.workflow_state = None

        if self.session_mgr.auto_save and self.session_mgr.session_id:
            await self.session_mgr.save_message_async(
                role="assistant",
                content=cancel_message,
                metadata={"type": "submission_cancelled", "workflow_state": None}
            )
        await self.session_mgr.flush_pending()
        yield build_content_event(cancel_message)

    async def handle_resubmission(
        self,
        grading_workflow,
        user_input: str,
        submission_metadata: Dict[str, Any],
        circle_file_urls: Optional[List[str]],
        prior_submission: Dict[str, Any],
    ) -> AsyncGenerator[Dict[str, str], None]:
        """Handle resubmission confirmation (affirm or decline)."""
        if grading_workflow._is_affirmative(user_input):
            # User confirmed resubmission — proceed with grading, skip prior-check
            self.state.workflow_state = None

            # Get email from submission_metadata with fallback chain
            email = (
                submission_metadata.get("student_email")
                or submission_metadata.get("email")
                or submission_metadata.get("student", {}).get("email")
                or ""
            )

            # Validate email is present
            if not email:
                error_msg = "Cannot process resubmission: student email not found in submission metadata"
                self.state.add_message(MessageRole.ASSISTANT, error_msg)
                if self.session_mgr.auto_save and self.session_mgr.session_id:
                    await self.session_mgr.save_message_async(
                        role="assistant",
                        content=error_msg,
                        metadata={"type": "grading_error", "workflow_state": None, "error": "missing_email"}
                    )
                    await self.session_mgr.flush_pending()
                yield build_error_event(error_msg)
                return

            # Get space_name with fallback
            space_name = (
                submission_metadata.get("space_name")
                or submission_metadata.get("challenge", {}).get("entity_name")
                or submission_metadata.get("challenge", {}).get("series_name")
                or ""
            )

            # Build prior_submission_context so the workflow can apply structured
            # markdown formatting for resubmissions (prior_score triggers the formatter).
            # prior_feedback: prefer submission_metadata (set from resubmit_warning event)
            # over prior_submission dict (which may not have been SELECT'd with feedback).
            prior_feedback_text = (
                submission_metadata.get("prior_feedback")
                or prior_submission.get("feedback", "")
            )
            # DEBUG: Log prior_feedback values
            print(f"[DEBUG handle_resubmission] prior_submission keys: {list(prior_submission.keys())}")
            print(f"[DEBUG handle_resubmission] prior_submission.get('feedback') length: {len(str(prior_submission.get('feedback', '')))}")
            print(f"[DEBUG handle_resubmission] prior_feedback_text length: {len(str(prior_feedback_text))}")
            prior_submission_context_for_grading = {
                "content": prior_submission.get("content", ""),
                "score": float(prior_submission.get("score") or 0),
                "feedback": prior_feedback_text,
                "submission_id": prior_submission.get("id"),
            }
            print(f"[DEBUG handle_resubmission] prior_submission_context_for_grading exists: {prior_submission_context_for_grading is not None}")
            if prior_submission_context_for_grading:
                print(f"[DEBUG handle_resubmission] prior_submission_context_for_grading.get('feedback') length: {len(str(prior_submission_context_for_grading.get('feedback', '')))}")
            print(f"[DEBUG handle_resubmission] prior_feedback being passed: {len(str(prior_submission_context_for_grading.get('feedback', '')) if prior_submission_context_for_grading else 'None')}")

            try:
                async for event in grading_workflow.astream_process_direct_submission(
                    email=email,
                    space_name=space_name or submission_metadata.get("space_name", ""),
                    text_content=submission_metadata.get("text_content", ""),
                    files=submission_metadata.get("files", []),
                    skip_prior_check=True,
                    resolved_challenge_name=submission_metadata.get("challenge_name"),
                    challenge_metadata=submission_metadata.get("challenge_metadata"),
                    student_inputs=submission_metadata.get("student_inputs"),
                    prior_submission_context=prior_submission_context_for_grading,
                ):
                    event_type = event.get("type")

                    if event_type == "status":
                        yield build_reasoning_event(
                            step=event.get("step", ""),
                            reasoning=event.get("message", "")
                        )
                    elif event_type == "feedback_token":
                        # For resubmissions, suppress streaming tokens — structured markdown
                        # will be rendered from the final result.feedback field instead
                        pass
                    elif event_type == "error":
                        error_msg = event.get("message", "Unknown error")
                        self.state.add_message(MessageRole.ASSISTANT, error_msg)
                        if self.session_mgr.auto_save and self.session_mgr.session_id:
                            await self.session_mgr.save_message_async(
                                role="assistant",
                                content=error_msg,
                                metadata={"type": "grading_error", "workflow_state": None, "error": error_msg}
                            )
                            await self.session_mgr.flush_pending()
                        yield build_error_event(error_msg)
                        return
                    elif event_type == "result":
                        grading_data = event.get("data", {})
                        grading_data["circle_file_urls"] = circle_file_urls
                        grading_event = {
                            "type": "grading_complete",
                            "grading_data": grading_data,
                        }
                        
                        challenge_type = grading_data.get("challenge_type", "mission")
                        raw_score = grading_data.get("score", 0)
                        try:
                            score_val = float(str(raw_score).replace('%', ''))
                        except (ValueError, TypeError):
                            score_val = 0.0

                        # Only mission_final uses score-based posting confirmation
                        if challenge_type == "mission_final":
                            if score_val >= 80:
                                grading_event["action"] = "request_posting_confirmation"
                            else:
                                grading_event["action"] = "show_low_score_feedback"
                                grading_event["message"] = grading_data.get('feedback', '')
                                grading_event["score"] = score_val
                        else:
                            # Non-final challenges always show feedback without score-based branching
                            grading_event["action"] = "show_low_score_feedback"
                            grading_event["message"] = grading_data.get('feedback', '')
                            grading_event["score"] = score_val

                        async for result_event in self.handle_grading_complete(grading_event):
                            yield result_event
                        break
            except Exception as e:
                self.state.workflow_state = None
                error_msg = f"Grading failed: {str(e)}"
                self.state.add_message(MessageRole.ASSISTANT, error_msg)
                if self.session_mgr.auto_save and self.session_mgr.session_id:
                    await self.session_mgr.save_message_async(
                        role="assistant",
                        content=error_msg,
                        metadata={"type": "grading_error", "workflow_state": None, "error": str(e)}
                    )
                    await self.session_mgr.flush_pending()
                yield build_error_event(error_msg)
        else:
            # User declined resubmission — keep existing result
            self.state.workflow_state = None
            prior_score = prior_submission.get('score', 'N/A')
            decline_msg = (
                f"Keeping your existing result (score: {prior_score}%). "
                f"Let me know if you need anything else."
            )
            self.state.add_message(MessageRole.ASSISTANT, decline_msg)

            if self.session_mgr.auto_save and self.session_mgr.session_id:
                await self.session_mgr.save_message_async(
                    role="assistant",
                    content=decline_msg,
                    metadata={
                        "type": "resubmit_declined",
                        "prior_submission": prior_submission,
                        "workflow_state": None,
                    }
                )
            await self.session_mgr.flush_pending()
            yield build_content_event(decline_msg)

    # --- Intent Verification Handler ---

    async def handle_grading_intent(
        self,
        decision,
        user_input: str,
        email: Optional[str],
        files: Optional[list],
        context_type: Optional[str],
        context_id: Optional[str],
        circle_file_urls: Optional[list],
        iteration_start: float,
    ) -> AsyncGenerator[dict, None]:
        """Handle grading workflow intent verification and confirmation."""
        import os as _os
        from agents.systems.response_types import build_timing_event

        # Coach workbook submit fast-path: student has accumulated answers and says "submit".
        # Bypass normal intent verification — show answer summary and await confirmation.
        _is_coach = (
            getattr(self.state, "persona", "customer_service") == "coach"
            and _os.getenv("ENABLE_COACH_PERSONA", "").lower() in ("true", "1", "yes")
        )
        _WORKBOOK_SUBMIT_SIGNALS = {
            "submit my answers", "submit the workbook", "submit workbook",
            "ready to submit", "i'm ready to submit", "i am ready to submit",
            "please submit", "done with the workbook", "i'm done", "i am done",
            "submit my workbook", "grade my workbook", "grade my answers",
        }
        _user_lower = user_input.strip().lower()
        _has_workbook_submit_signal = any(sig in _user_lower for sig in _WORKBOOK_SUBMIT_SIGNALS)
        if (
            _is_coach
            and _has_workbook_submit_signal
            and not files
            and not (self.state.workflow_state or {}).get("type")
        ):
            grading_workflow = GradingWorkflow()
            async for event in self.handle_workbook_submit(
                grading_workflow=grading_workflow,
                user_input=user_input,
                email=email,
                context_type=context_type,
                context_id=context_id,
                circle_file_urls=circle_file_urls,
            ):
                yield event
            return

        workflow_type = self.state.workflow_state.get("type") if self.state.workflow_state else None
        is_confirmed = False
        response_message = ""
        submission_metadata = None

        if workflow_type == WorkflowType.MISSION_CONFIRMED:
            is_confirmed = True
            submission_metadata = self.state.workflow_state.get("submission_metadata")
            challenge_name = submission_metadata.get("challenge", {}).get("entity_name", "the challenge") if submission_metadata else "the challenge"
            yield build_reasoning_event(
                step="Preparing Submission",
                reasoning=(
                    f"The user already confirmed their submission details in a previous turn, so I have the metadata ready to go. "
                    f"The confirmed challenge is '{challenge_name}' and the submission data includes their email, files, and text content. "
                    f"I don't need to re-verify the intent since the mission confirmation workflow already validated everything. "
                    f"I'll proceed directly to the grading workflow with these pre-confirmed details."
                )
            )
        elif context_type == "challenge" and context_id:
            yield build_reasoning_event(
                step="Preparing Submission",
                reasoning=(
                    f"The session was opened with a specific challenge context (ID: {context_id}), so I can look up that challenge directly. "
                    f"The challenge is already identified from the page context — no confirmation step needed. "
                    f"I'll fetch the challenge record and proceed straight to grading."
                )
            )
            detected_challenge = await self.intent_verifier.db_handler.fetch_challenge_by_uuid(context_id)
            if detected_challenge:
                has_files = bool(files and len(files) > 0)
                # Build challenge_metadata so _process_grading_after_confirmation uses the
                # challenges-first path (no lessons table queries).
                challenge_metadata = {
                    "challenge_uuid": detected_challenge.get("id") or context_id,
                    "challenge_name": detected_challenge.get("name") or detected_challenge.get("entity_name") or "",
                    "space_id": detected_challenge.get("mission_id") or detected_challenge.get("space_id"),
                    "space_group_id": detected_challenge.get("space_group_id"),
                    "body_html": detected_challenge.get("body_html", ""),
                    "challenge_type": detected_challenge.get("type", "mission"),
                }
                submission_metadata = {
                    "challenge": detected_challenge,
                    "challenge_metadata": challenge_metadata,
                    "email": email,
                    "files": files,
                    "text_content": self.state.current_input,
                    "has_files": has_files,
                    "has_content": len(self.state.current_input.strip()) > 50,
                    "student_inputs": getattr(self.state, 'student_inputs', None),
                }
                # Challenge is unambiguously known from context — skip confirmation
                is_confirmed = True
            else:
                # UUID not found — falling back to detection
                is_confirmed, response_message, submission_metadata = await self.intent_verifier.verify_submission_intent(
                    state=self.state,
                    email=email,
                    files=files
                )
        else:
            verification_start = time()
            yield build_reasoning_event(
                step="Checking Submission",
                reasoning=(
                    f"The user appears to want to submit work for grading, but I don't have a pre-identified challenge context. "
                    f"I need to run the full intent verification flow to determine which challenge they're targeting and validate the submission details. "
                    f"The verifier will analyze the conversation history, any uploaded files, and the user's email to match against known challenges. "
                    f"Once verified, I'll either confirm the details with the user or ask for clarification if something is ambiguous."
                )
            )
            import os
            bulk_enabled = os.getenv("BULK_GRADING_ENABLED", "false").lower() == "true"
            if bulk_enabled:
                from agents.subagents.bulk_challenge_detector import BulkChallengeDetector
                bulk_detector = BulkChallengeDetector(self.intent_verifier.client)
            else:
                bulk_detector = None

            is_confirmed, response_message, submission_metadata = await self.intent_verifier.verify_submission_intent_with_bulk(
                state=self.state,
                email=email,
                files=files,
                bulk_detector=bulk_detector,
            )
            verification_time = time() - verification_start
            yield build_timing_event("intent_verification", verification_time * 1000)

        # Direct grading path: challenge known from context, no confirmation needed
        if is_confirmed and submission_metadata:
            grading_workflow = GradingWorkflow()
            async for event in grading_workflow._process_grading_after_confirmation(
                submission_metadata=submission_metadata,
                circle_file_urls=circle_file_urls,
            ):
                event_type = event.get("type")
                if event_type == "reasoning":
                    yield build_reasoning_event(
                        step=event.get("step", "Grading"),
                        reasoning=event.get("message", "")
                    )
                elif event_type == "feedback_token":
                    yield build_content_event(event.get("delta", ""))
                elif event_type == "error":
                    error_msg = event.get("message", "Unknown error")
                    self.state.add_message(MessageRole.ASSISTANT, error_msg)
                    if self.session_mgr.auto_save and self.session_mgr.session_id:
                        await self.session_mgr.save_message_async(
                            role="assistant",
                            content=error_msg,
                            metadata={"type": "grading_error", "workflow_state": None, "error": error_msg}
                        )
                        await self.session_mgr.flush_pending()
                    yield build_error_event(error_msg)
                    return
                elif event_type == "resubmit_warning":
                    self.state.workflow_state = {
                        "type": WorkflowType.RESUBMISSION,
                        "submission_metadata": event.get("submission_metadata"),
                        "circle_file_urls": circle_file_urls or [],
                        "prior_submission": event.get("prior_submission"),
                    }
                    warning_msg = event.get("message")
                    self.state.add_message(MessageRole.ASSISTANT, warning_msg)
                    if self.session_mgr.auto_save and self.session_mgr.session_id:
                        await self.session_mgr.save_message_async(
                            role="assistant",
                            content=warning_msg,
                            metadata={
                                "type": "resubmit_warning",
                                "prior_submission": event.get("prior_submission"),
                                "workflow_state": self.state.workflow_state,
                            }
                        )
                    await self.session_mgr.flush_pending()
                    yield build_content_event(warning_msg)
                    return
                elif event_type == "grading_complete":
                    grading_data = event.get("grading_data", {})
                    grading_data["circle_file_urls"] = circle_file_urls or []
                    event["grading_data"] = grading_data
                    async for result_event in self.handle_grading_complete(event):
                        yield result_event
                    return
            return

        # Shared confirmation handling (challenge not yet identified — ask user)
        if not is_confirmed:
            self.state.add_message(MessageRole.ASSISTANT, response_message)

            if submission_metadata:
                # Override message if bulk was detected (metadata already has is_bulk + all_challenges)
                if submission_metadata.get("is_bulk"):
                    all_challenges = submission_metadata["all_challenges"]
                    primary_challenge = submission_metadata.get("challenge", {})
                    entity_name = primary_challenge.get("entity_name", "the mission")
                    challenge_names = [c["name"] for c in all_challenges]
                    response_message = (
                        f"I detected that your submission covers "
                        f"**{len(all_challenges)} challenges** in **{entity_name}**:\n\n"
                        + "\n".join(f"- {name}" for name in challenge_names)
                        + "\n\nI'll grade each challenge separately and provide a "
                        f"consolidated summary. Ready to proceed? (yes/no)"
                    )
                    self.state.messages[-1].content = response_message

                # --- Set workflow state (single or bulk) ---
                if submission_metadata.get("is_bulk"):
                    self.state.workflow_state = {
                        "type": WorkflowType.BULK_MISSION_CONFIRMATION,
                        "submission_metadata": submission_metadata,
                        "circle_file_urls": circle_file_urls or [],
                    }
                else:
                    self.state.workflow_state = {
                        "type": WorkflowType.MISSION_CONFIRMATION,
                        "submission_metadata": submission_metadata,
                        "circle_file_urls": circle_file_urls or [],
                    }

                if self.session_mgr.auto_save and self.session_mgr.session_id:
                    await self.session_mgr.save_message_async(
                        role="assistant",
                        content=response_message,
                        metadata={
                            "type": "mission_confirmation_request",
                            "workflow_state": self.state.workflow_state
                        }
                    )
            else:
                if self.session_mgr.auto_save and self.session_mgr.session_id:
                    await self.session_mgr.save_message_async(
                        role="assistant",
                        content=response_message,
                        metadata={"type": "mission_clarification_request"}
                    )

            yield build_content_event(response_message)
            await self.session_mgr.flush_pending()
            return

    async def handle_workbook_submit(
        self,
        grading_workflow,
        user_input: str,
        email: Optional[str],
        context_type: Optional[str],
        context_id: Optional[str],
        circle_file_urls: Optional[List[str]],
    ) -> AsyncGenerator[Dict[str, str], None]:
        """Handle Coach workbook submission — compile accumulated answers and grade.

        Two-step flow:
        1. First call: show answer summary, set WORKBOOK_SUBMIT workflow state.
        2. Second call (confirmation): build submission_metadata, trigger grading.
        """
        workbook_answers = self.state.workbook_answers or {}

        if not workbook_answers:
            msg = (
                "I haven't recorded any confirmed answers yet. "
                "Let's work through the workbook together first — "
                "which section would you like to start with?"
            )
            self.state.add_message(MessageRole.ASSISTANT, msg)
            if self.session_mgr.auto_save and self.session_mgr.session_id:
                await self.session_mgr.save_message_async(
                    role="assistant",
                    content=msg,
                    metadata={"type": "workbook_submit_no_answers"},
                )
            await self.session_mgr.flush_pending()
            yield build_content_event(msg)
            return

        # Build answer summary markdown for student confirmation
        lines = ["## Your Recorded Workbook Answers\n"]
        for section_id, fields in workbook_answers.items():
            lines.append(f"**{section_id}**")
            for field_id, value in fields.items():
                lines.append(f"- {field_id}: {value}")
            lines.append("")
        lines.append("\nShall I submit these answers for grading? (yes/no)")
        summary_msg = "\n".join(lines)

        # Snapshot the answers and build submission_metadata for the grading path
        challenge_metadata = None
        if self.state.context_prefetch:
            meta = self.state.context_prefetch.get("metadata", {})
            workbook_schema = meta.get("workbook_content")
            challenge_metadata = {
                "challenge_uuid": meta.get("challenge_uuid") or (context_id if context_type == "challenge" else None),
                "challenge_name": self.state.context_prefetch.get("name", ""),
                "challenge_type": meta.get("challenge_type", "mission"),
                "space_id": meta.get("space_id"),
                "space_group_id": meta.get("space_group_id"),
                "workbook_content": workbook_schema,
            }

        submission_metadata = {
            "email": email or self.state.email or "",
            "text_content": "",  # compiler in pipeline will populate from student_inputs
            "files": [],
            "student_inputs": dict(workbook_answers),
            "challenge_metadata": challenge_metadata,
            "resolved_challenge_name": (challenge_metadata or {}).get("challenge_name"),
        }

        self.state.workflow_state = {
            "type": WorkflowType.WORKBOOK_SUBMIT,
            "submission_metadata": submission_metadata,
            "circle_file_urls": circle_file_urls or [],
        }

        self.state.add_message(MessageRole.ASSISTANT, summary_msg)
        if self.session_mgr.auto_save and self.session_mgr.session_id:
            await self.session_mgr.save_message_async(
                role="assistant",
                content=summary_msg,
                metadata={
                    "type": "workbook_submit_confirmation_request",
                    "workflow_state": self.state.workflow_state,
                },
            )
        await self.session_mgr.flush_pending()
        yield build_content_event(summary_msg)

    # --- Internal Helpers ---

    async def _stream_text(self, text: str, chunk_size: int = 6) -> AsyncGenerator[Dict[str, str], None]:
        """Fake-stream text in word-group chunks to simulate LLM token streaming."""
        words = text.split(" ")
        i = 0
        while i < len(words):
            chunk = " ".join(words[i:i + chunk_size])
            if i + chunk_size < len(words):
                chunk += " "
            yield build_content_event(chunk)
            await asyncio.sleep(0.01)
            i += chunk_size

    def _is_new_submission_input(self, user_input: str, files: Optional[list]) -> bool:
        """Detect if input looks like a new grading submission rather than a yes/no posting answer.

        A new submission has substantial content (>100 chars) AND contains grading-related
        keywords, OR includes file attachments. Short yes/no responses are posting answers.
        """
        if files:
            return True
        stripped = user_input.strip()
        if len(stripped) < 100:
            return False
        lower = stripped.lower()
        grading_signals = {"submit", "challenge", "section", "assignment", "mission", "grade"}
        return any(kw in lower for kw in grading_signals)

    # --- Formatting Helpers ---

    def generate_posting_confirmation(
        self,
        grading_data: Dict[str, Any]
    ) -> dict:
        """Generate posting confirmation message based on score."""
        raw_score = grading_data.get("score", 0)
        try:
            score = float(str(raw_score).replace('%', ''))
        except (ValueError, TypeError):
            score = 0.0

        if score < 80:
            message = f"""## Grading Complete

**Score: {score}/100**

Your submission has been graded. Since the score is below 80%, I recommend reviewing the feedback and retrying before posting to Circle.

Would you like to:
- Retry with improvements
- Post anyway (not recommended)

Let me know your preference."""
        else:
            message = f"""## Grading Complete

**Score: {score}/100**

Great work! Your submission has been graded successfully.

Would you like me to post your submission and feedback to Circle? (yes/no)"""

        return build_content_event(message)

    async def handle_bulk_mission_confirmation(
        self,
        grading_workflow,
        user_input: str,
        submission_metadata: Dict[str, Any],
        circle_file_urls: Optional[List[str]],
    ) -> AsyncGenerator[Dict[str, str], None]:
        """Handle bulk mission confirmation: extract files once, segment, grade each challenge."""
        if not grading_workflow._is_affirmative(user_input):
            cancel_msg = "Bulk submission cancelled. Let me know when you're ready."
            self.state.add_message(MessageRole.ASSISTANT, cancel_msg)
            self.state.workflow_state = None
            if self.session_mgr.auto_save and self.session_mgr.session_id:
                await self.session_mgr.save_message_async(
                    role="assistant",
                    content=cancel_msg,
                    metadata={"type": "bulk_submission_cancelled", "workflow_state": None},
                )
            await self.session_mgr.flush_pending()
            yield build_content_event(cancel_msg)
            return

        all_challenges = submission_metadata.get("all_challenges", [])
        challenge_info = submission_metadata.get("challenge", {})
        entity_name = challenge_info.get("entity_name", "the mission")

        yield build_reasoning_event(
            step="Bulk Grading",
            reasoning=(
                f"User confirmed bulk submission. Starting grading for "
                f"{len(all_challenges)} challenges in {entity_name}."
            ),
        )

        # Step 1: Extract files once — shared across all challenge grading calls
        files = submission_metadata.get("files") or []
        text_content = submission_metadata.get("text_content", "")
        extracted_content = ""

        if files:
            from utils.data_conversion import get_file_category, get_mime_type_from_filename
            normalized_files = [
                {
                    "name": f.get("name") or f.get("filename") or "",
                    "data": f.get("data") or f.get("url") or "",
                    "file_type": f.get("file_type") or get_file_category(
                        f.get("mime_type") or get_mime_type_from_filename(f.get("filename") or f.get("name") or "")
                    ),
                }
                for f in files
            ]
            extraction_result = await grading_workflow.multimodal_extractor.execute(files=normalized_files)
            extracted_content = (
                extraction_result.get("content", {}).get("markdown", "")
            )

        # Step 2: Segment content per challenge
        from agents.subagents.bulk_challenge_detector import BulkChallengeDetector
        bulk_detector = BulkChallengeDetector(self.intent_verifier.client)
        content_segments = await bulk_detector.segment_submission_content(
            text_content=text_content,
            extracted_file_content=extracted_content,
            challenges=all_challenges,
        )

        if not content_segments:
            # Segmentation failed — fall back to single-challenge grading on primary challenge
            yield build_reasoning_event(
                step="Bulk Grading",
                reasoning=(
                    "Could not segment content per challenge. "
                    "Falling back to single-challenge grading."
                ),
            )
            self.state.workflow_state = None
            async for event in self.handle_mission_confirmation(
                grading_workflow=grading_workflow,
                user_input="yes",
                submission_metadata=submission_metadata,
                circle_file_urls=circle_file_urls,
            ):
                yield event
            return

        matched_names = list(content_segments.keys())
        yield build_reasoning_event(
            step="Bulk Grading",
            reasoning=(
                f"Content segmented for {len(matched_names)} challenge(s): "
                f"{', '.join(matched_names)}. Grading sequentially."
            ),
        )

        # Step 3: Grade each matched challenge sequentially
        all_results: List[Dict[str, Any]] = []

        for i, challenge in enumerate(all_challenges):
            c_name = challenge["name"]

            if c_name not in content_segments:
                all_results.append({
                    "challenge_name": c_name,
                    "status": "skipped",
                    "reason": "No matching content found in submission",
                })
                continue

            yield build_reasoning_event(
                step="Bulk Grading",
                reasoning=f"Grading challenge {i + 1}/{len(all_challenges)}: {c_name}",
            )

            per_challenge_metadata = {
                "challenge_uuid": str(challenge.get("id", "")),
                "challenge_name": c_name,
                "challenge_type": challenge.get("type"),
                "space_id": challenge_info.get("entity_id"),
                "space_group_id": challenge_info.get("space_group_id"),
                "entity_name": entity_name,
                "entity_type": challenge_info.get("entity_type"),
            }

            result_data: Optional[Dict[str, Any]] = None
            error_msg: Optional[str] = None

            try:
                async for event in grading_workflow.astream_process_direct_submission(
                    email=submission_metadata.get("email"),
                    space_name=entity_name,
                    text_content=content_segments[c_name],
                    files=[],
                    resolved_challenge_name=c_name,
                    challenge_metadata=per_challenge_metadata,
                ):
                    etype = event.get("type")
                    if etype == "status":
                        yield build_reasoning_event(
                            step="Bulk Grading",
                            reasoning=event.get("message", ""),
                        )
                    elif etype == "feedback_token":
                        pass  # Bulk grading: tokens accumulated into result; no live stream
                    elif etype == "error":
                        error_msg = event.get("message", "Unknown error")
                        break
                    elif etype == "resubmit_warning":
                        # Already passed — skip silently, record in summary
                        all_results.append({
                            "challenge_name": c_name,
                            "status": "already_passed",
                            "prior_score": event.get("prior_submission", {}).get("score"),
                        })
                        error_msg = "__skip__"
                        break
                    elif etype == "result":
                        result_data = event.get("data", {})
                        break
            except Exception as e:
                error_msg = str(e)

            if error_msg == "__skip__":
                continue
            elif error_msg:
                all_results.append({
                    "challenge_name": c_name,
                    "status": "error",
                    "error": error_msg,
                })
            elif result_data:
                all_results.append({
                    "challenge_name": c_name,
                    "status": "graded",
                    "score": result_data.get("score"),
                    "feedback": result_data.get("feedback"),
                    "submission_id": result_data.get("submission_id"),
                    "student_name": result_data.get("student_name"),
                    "mission_name": result_data.get("mission_name"),
                    "challenge_name_result": result_data.get("challenge_name"),
                    "space_group_id": result_data.get("space_group_id"),
                    "component_scores": result_data.get("component_scores", []),
                })

        # Step 4: Build consolidated summary
        summary = self._format_bulk_summary(all_results, entity_name)
        self.state.add_message(MessageRole.ASSISTANT, summary)
        self.state.add_submission_result({"bulk_results": all_results})

        # Step 5: Route based on scores
        graded = [r for r in all_results if r.get("status") == "graded"]
        all_high = bool(graded) and all(
            float(str(r.get("score", "0")).replace("%", "")) >= 80
            for r in graded
        )

        if all_high:
            posting_msg = (
                summary
                + "\n\nAll graded challenges scored 80% or above. "
                "Would you like me to post the results to Circle? (yes/no)"
            )
            self.state.workflow_state = {
                "type": WorkflowType.BULK_POSTING_CONFIRMATION,
                "grading_data": {
                    "bulk_results": all_results,
                    "entity_name": entity_name,
                },
                "circle_file_urls": circle_file_urls or [],
            }
            if self.session_mgr.auto_save and self.session_mgr.session_id:
                await self.session_mgr.save_message_async(
                    role="assistant",
                    content=posting_msg,
                    metadata={
                        "type": "bulk_grading_confirmation",
                        "workflow_state": self.state.workflow_state,
                    },
                )
            await self.session_mgr.flush_pending()
            yield build_content_event(posting_msg)
        else:
            self.state.workflow_state = None
            if self.session_mgr.auto_save and self.session_mgr.session_id:
                await self.session_mgr.save_message_async(
                    role="assistant",
                    content=summary,
                    metadata={"type": "bulk_grading_complete", "workflow_state": None},
                )
            await self.session_mgr.flush_pending()
            yield build_content_event(summary)

    async def handle_bulk_posting_confirmation(
        self,
        grading_workflow,
        user_input: str,
        grading_data: Dict[str, Any],
        circle_file_urls: Optional[List[str]],
    ) -> AsyncGenerator[Dict[str, str], None]:
        """Handle posting confirmation for bulk grading results."""
        if not grading_workflow._is_affirmative(user_input):
            decline_msg = (
                "Your submissions have been graded but not posted to Circle. "
                "Let me know if you'd like to post them later."
            )
            self.state.add_message(MessageRole.ASSISTANT, decline_msg)
            self.state.workflow_state = None
            if self.session_mgr.auto_save and self.session_mgr.session_id:
                await self.session_mgr.save_message_async(
                    role="assistant",
                    content=decline_msg,
                    metadata={"type": "bulk_posting_declined", "workflow_state": None},
                )
            await self.session_mgr.flush_pending()
            yield build_content_event(decline_msg)
            return

        bulk_results = grading_data.get("bulk_results", [])
        entity_name = grading_data.get("entity_name", "")
        posted_count = 0

        for result in bulk_results:
            if result.get("status") != "graded":
                continue
            try:
                await grading_workflow.post_grading(
                    grading_message=result.get("feedback", ""),
                    mission_space_name=entity_name,
                    challenge_name=result.get("challenge_name"),
                    student_name=result.get("student_name"),
                    student_email=None,
                    space_group_id=result.get("space_group_id"),
                    circle_file_urls=circle_file_urls,
                )
                posted_count += 1
            except Exception as e:
                yield build_reasoning_event(
                    step="Bulk Posting",
                    reasoning=f"Failed to post {result.get('challenge_name')}: {e}",
                )

        self.state.workflow_state = None
        post_msg = (
            f"Posted {posted_count} graded challenge(s) from {entity_name} to Circle."
        )
        self.state.add_message(MessageRole.ASSISTANT, post_msg)
        if self.session_mgr.auto_save and self.session_mgr.session_id:
            await self.session_mgr.save_message_async(
                role="assistant",
                content=post_msg,
                metadata={"type": "bulk_posting_complete", "workflow_state": None},
            )
        await self.session_mgr.flush_pending()
        yield build_content_event(post_msg)

    def _format_bulk_summary(
        self,
        results: List[Dict[str, Any]],
        entity_name: str,
    ) -> str:
        """Format consolidated summary for bulk grading results."""
        lines = [f"## Bulk Grading Complete — {entity_name}\n"]

        for r in results:
            name = r.get("challenge_name", "Unknown")
            status = r.get("status")

            if status == "graded":
                score = r.get("score", "N/A")
                lines.append(f"### {name}\n**Score:** {score}\n")
                for cs in r.get("component_scores", []):
                    lines.append(
                        f"- **{cs.get('criterion_name', '')}**: "
                        f"{cs.get('score', 0)}/{cs.get('max_points', 0)}"
                    )
                lines.append("")
            elif status == "already_passed":
                prior = r.get("prior_score", "N/A")
                lines.append(f"### {name}\n**Already passed** (prior score: {prior}%)\n")
            elif status == "skipped":
                lines.append(
                    f"### {name}\n**Skipped** — {r.get('reason', 'no matching content')}\n"
                )
            elif status == "error":
                lines.append(f"### {name}\n**Error** — {r.get('error', 'unknown')}\n")

        graded = [r for r in results if r.get("status") == "graded"]
        skipped = [r for r in results if r.get("status") in ("skipped", "already_passed")]
        errors = [r for r in results if r.get("status") == "error"]

        lines.append("---")
        lines.append(
            f"**Summary:** {len(graded)} graded, {len(skipped)} skipped, "
            f"{len(errors)} errors"
        )

        if graded:
            scores = [
                float(str(r.get("score", "0")).replace("%", "")) for r in graded
            ]
            avg = sum(scores) / len(scores)
            lines.append(f"**Average Score:** {avg:.1f}%")

        return "\n".join(lines)

    async def dispatch_workflow(
        self,
        user_input: str,
        email: Optional[str],
        files: Optional[list],
        circle_file_urls: Optional[list],
    ) -> Optional[AsyncGenerator[Dict[str, str], None]]:
        """Dispatch to the active grading workflow handler based on workflow_state.type.

        Returns:
            AsyncGenerator of events if a workflow is active, None otherwise.
        """
        if not self.state.workflow_state:
            return None

        workflow_type = self.state.workflow_state.get("type")

        if user_input.lower().strip() in CANCEL_KEYWORDS:
            async def _cancel_gen():
                cancel_msg = "Workflow cancelled. How can I help you?"
                self.state.workflow_state = None
                self.state.add_message(MessageRole.ASSISTANT, cancel_msg)
                if self.auto_save and self.session_id:
                    await self.session_mgr.save_message_async(
                        role="assistant",
                        content=cancel_msg,
                        metadata={"type": "workflow_cancelled", "workflow_state": None}
                    )
                yield build_content_event(cancel_msg)
                await self.session_mgr.flush_pending()
            return _cancel_gen()

        # Guard: if the user sends a new submission while a posting confirmation is pending,
        # treat it as a new grading request — clear the stale state and fall through.
        if workflow_type == WorkflowType.POSTING_CONFIRMATION:
            if self._is_new_submission_input(user_input, files):
                self.state.workflow_state = None
                if self.session_mgr.auto_save and self.session_mgr.session_id:
                    await self.session_mgr.save_message_async(
                        role="assistant",
                        content="",
                        metadata={"type": "workflow_cleared", "workflow_state": None}
                    )
                    await self.session_mgr.flush_pending()
                return None

        grading_workflow = GradingWorkflow()
        await self.session_mgr.flush_pending()

        def _effective_urls(key: str) -> list:
            return circle_file_urls or self.state.workflow_state.get(key, [])

        def _patch_submission(meta: Dict[str, Any]) -> None:
            if meta and files:
                meta["files"] = files
                meta["has_files"] = True
            if meta and len(user_input.strip()) > 50:
                meta["text_content"] = user_input
                meta["has_content"] = True

        if workflow_type == WorkflowType.MISSION_CONFIRMATION:
            submission_metadata = self.state.workflow_state.get("submission_metadata")
            _patch_submission(submission_metadata)

            async def _mission_gen():
                async for event in self.handle_mission_confirmation(
                    grading_workflow=grading_workflow,
                    user_input=user_input,
                    submission_metadata=submission_metadata,
                    circle_file_urls=_effective_urls("circle_file_urls"),
                ):
                    yield event
                await self.session_mgr.flush_pending()
            return _mission_gen()

        elif workflow_type == WorkflowType.POSTING_CONFIRMATION:
            async def _posting_gen():
                async for event in self.handle_posting_confirmation(
                    grading_workflow=grading_workflow,
                    user_input=user_input,
                    grading_data=self.state.workflow_state.get("grading_data"),
                    circle_file_urls=_effective_urls("circle_file_urls"),
                ):
                    yield event
                await self.session_mgr.flush_pending()
            return _posting_gen()

        elif workflow_type == WorkflowType.RESUBMISSION:
            submission_metadata = self.state.workflow_state.get("submission_metadata")

            async def _resub_gen():
                async for event in self.handle_resubmission(
                    grading_workflow=grading_workflow,
                    user_input=user_input,
                    submission_metadata=submission_metadata,
                    circle_file_urls=_effective_urls("circle_file_urls"),
                    prior_submission=self.state.workflow_state.get("prior_submission") or {},
                ):
                    yield event
                await self.session_mgr.flush_pending()
            return _resub_gen()

        elif workflow_type == WorkflowType.BULK_MISSION_CONFIRMATION:
            submission_metadata = self.state.workflow_state.get("submission_metadata")
            _patch_submission(submission_metadata)

            async def _bulk_mission_gen():
                async for event in self.handle_bulk_mission_confirmation(
                    grading_workflow=grading_workflow,
                    user_input=user_input,
                    submission_metadata=submission_metadata,
                    circle_file_urls=_effective_urls("circle_file_urls"),
                ):
                    yield event
                await self.session_mgr.flush_pending()
            return _bulk_mission_gen()

        elif workflow_type == WorkflowType.BULK_POSTING_CONFIRMATION:
            async def _bulk_posting_gen():
                async for event in self.handle_bulk_posting_confirmation(
                    grading_workflow=grading_workflow,
                    user_input=user_input,
                    grading_data=self.state.workflow_state.get("grading_data"),
                    circle_file_urls=_effective_urls("circle_file_urls"),
                ):
                    yield event
                await self.session_mgr.flush_pending()
            return _bulk_posting_gen()

        elif workflow_type == WorkflowType.WORKBOOK_SUBMIT:
            submission_metadata = self.state.workflow_state.get("submission_metadata", {})

            if grading_workflow._is_affirmative(user_input):
                # Capture URLs before clearing workflow_state (closure safety)
                _confirmed_urls = _effective_urls("circle_file_urls")
                # Student confirmed — proceed to grading using accumulated student_inputs
                self.state.workflow_state = None

                async def _workbook_submit_confirmed_gen():
                    async for event in grading_workflow._process_grading_after_confirmation(
                        submission_metadata=submission_metadata,
                        circle_file_urls=_confirmed_urls,
                    ):
                        event_type = event.get("type")
                        if event_type == "reasoning":
                            yield build_reasoning_event(
                                step=event.get("step", "Grading"),
                                reasoning=event.get("message", ""),
                            )
                        elif event_type == "feedback_token":
                            yield build_content_event(event.get("delta", ""))
                        elif event_type == "error":
                            error_msg = event.get("message", "Unknown error")
                            self.state.add_message(MessageRole.ASSISTANT, error_msg)
                            if self.session_mgr.auto_save and self.session_mgr.session_id:
                                await self.session_mgr.save_message_async(
                                    role="assistant",
                                    content=error_msg,
                                    metadata={"type": "grading_error", "workflow_state": None, "error": error_msg},
                                )
                                await self.session_mgr.flush_pending()
                            yield build_error_event(error_msg)
                            return
                        elif event_type == "resubmit_warning":
                            self.state.workflow_state = {
                                "type": WorkflowType.RESUBMISSION,
                                "submission_metadata": event.get("submission_metadata"),
                                "circle_file_urls": _effective_urls("circle_file_urls"),
                                "prior_submission": event.get("prior_submission"),
                            }
                            warning_msg = event.get("message")
                            self.state.add_message(MessageRole.ASSISTANT, warning_msg)
                            if self.session_mgr.auto_save and self.session_mgr.session_id:
                                await self.session_mgr.save_message_async(
                                    role="assistant",
                                    content=warning_msg,
                                    metadata={
                                        "type": "resubmit_warning",
                                        "prior_submission": event.get("prior_submission"),
                                        "workflow_state": self.state.workflow_state,
                                    },
                                )
                            await self.session_mgr.flush_pending()
                            yield build_content_event(warning_msg)
                            return
                        elif event_type == "grading_complete":
                            grading_data = event.get("grading_data", {})
                            grading_data["circle_file_urls"] = _confirmed_urls
                            event["grading_data"] = grading_data
                            async for result_event in self.handle_grading_complete(event):
                                yield result_event
                            return
                    await self.session_mgr.flush_pending()
                return _workbook_submit_confirmed_gen()
            else:
                # Student declined — clear workflow state
                async def _workbook_submit_declined_gen():
                    decline_msg = (
                        "No problem — your recorded answers are still saved in this session. "
                        "Let me know when you're ready to submit or if you'd like to update any answers."
                    )
                    self.state.workflow_state = None
                    self.state.add_message(MessageRole.ASSISTANT, decline_msg)
                    if self.session_mgr.auto_save and self.session_mgr.session_id:
                        await self.session_mgr.save_message_async(
                            role="assistant",
                            content=decline_msg,
                            metadata={"type": "workbook_submit_declined", "workflow_state": None},
                        )
                    await self.session_mgr.flush_pending()
                    yield build_content_event(decline_msg)
                return _workbook_submit_declined_gen()

        return None
