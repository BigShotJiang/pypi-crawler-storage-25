"""
Response types and helpers for AgentSystem streaming responses.

Aligns with the ChatMetadata interface defined in planning/chatbot-interface/types.md:

interface ChatMetadata {
  type?: 'text' | 'grading' | 'score' | 'feedback' | 'teamSummary';
  files?: { filename: string; url: string }[];
  reasoning?: string;
  statusText?: string;
  score?: number;
  maxScore?: number;
  passed?: boolean;
  summary?: string;
  criteria?: { name: string; score: number; maxScore: number; comment: string }[];
  completed?: number;
  inProgress?: number;
  atRisk?: number;
  atRiskNames?: string[];
}
"""

from typing import Any, Dict, List, Optional, TypedDict
from enum import Enum
import base64
import json


def build_timing_event(step: str, elapsed_ms: float, extra: dict = None) -> dict:
    """Build a timing event for production monitoring.
    
    Timing events use event type 'timing' (not 'reasoning') so the frontend
    silently ignores them. They are developer-only metrics, not user-visible.
    
    Args:
        step: Name of the step being timed
        elapsed_ms: Elapsed time in milliseconds
        extra: Additional data to include in the timing metadata
        
    Returns:
        SSE event dict with timing information
    """
    data = {"step": step, "elapsed_ms": round(elapsed_ms, 2), "type": "timing"}
    if extra:
        data.update(extra)
    return {
        "event": "timing",
        "data": json.dumps(data)
    }


def build_timing_metadata(step: str, elapsed_ms: float, extra: dict = None) -> dict:
    """Build a timing metadata event (lightweight, no base64 content).
    
    Args:
        step: Name of the step being timed
        elapsed_ms: Elapsed time in milliseconds
        extra: Additional data to include
        
    Returns:
        SSE metadata event dict with timing information
    """
    data = {"type": "timing", "step": step, "elapsed_ms": round(elapsed_ms, 2)}
    if extra:
        data.update(extra)
    return {
        "event": "metadata",
        "data": json.dumps(data)
    }


class MetadataType(str, Enum):
    TEXT = "text"
    GRADING = "grading"
    SCORE = "score"
    FEEDBACK = "feedback"
    TEAM_SUMMARY = "teamSummary"
    SESSION_UPDATED = "session_updated"


class FileMeta(TypedDict):
    filename: str
    url: str


class CriterionMeta(TypedDict):
    name: str
    score: float
    maxScore: float
    comment: str


class ChatMetadata(TypedDict, total=False):
    type: str
    files: List[FileMeta]
    step: str
    reasoning: str
    statusText: str
    score: float
    maxScore: float
    passed: bool
    summary: str
    criteria: List[CriterionMeta]
    completed: int
    inProgress: int
    atRisk: int
    atRiskNames: List[str]


class StreamEvent(str, Enum):
    CONTENT = "content"
    REASONING = "reasoning"
    METADATA = "metadata"
    ERROR = "error"


def _b64(text: str) -> str:
    """Base64 encode a UTF-8 string."""
    return base64.b64encode(text.encode("utf-8")).decode("utf-8")


def build_event(event: StreamEvent, content: str, metadata: Optional[ChatMetadata] = None) -> Dict[str, str]:
    """
    Build a streaming event payload.
    
    Args:
        event: The event type (content, reasoning, metadata, error)
        content: The text content (will be base64 encoded)
        metadata: Optional ChatMetadata dict
        
    Returns:
        Dict with 'event' and 'data' keys ready for yielding
    """
    payload: Dict[str, Any] = {"content": _b64(content)}
    if metadata:
        payload["metadata"] = metadata
    return {
        "event": event.value,
        "data": json.dumps(payload),
    }


def build_content_event(content: str, metadata: Optional[ChatMetadata] = None) -> Dict[str, str]:
    """Build a content streaming event."""
    return build_event(StreamEvent.CONTENT, content, metadata)


def build_reasoning_event(step: str, reasoning: str) -> Dict[str, str]:
    """Build a reasoning streaming event."""
    return build_event(StreamEvent.REASONING, f"{reasoning}\n\n", metadata=ChatMetadata(step=step))


def build_error_event(error: str) -> Dict[str, str]:
    """Build an error streaming event."""
    return build_event(StreamEvent.ERROR, error)


def build_metadata_event(metadata: ChatMetadata) -> Dict[str, str]:
    """Build a metadata-only streaming event (content empty)."""
    return build_event(StreamEvent.METADATA, "", metadata)


# --- Transformers for specific tool outputs ---

def transform_grading_response(grading_output: Dict[str, Any]) -> ChatMetadata:
    """
    Transform grading workflow output to ChatMetadata.
    
    Expected grading_output keys:
        - message: str (overall feedback)
        - score: str (e.g., "85.0%")
        - student_name: str
        - submission_id: int
        - component_scores: list (from format_grading_report_as_json)
    """
    metadata: ChatMetadata = {"type": MetadataType.GRADING.value}
    
    # Parse score from string like "85.0%"
    score_str = grading_output.get("score", "0%")
    try:
        score_val = float(score_str.replace("%", "").strip())
        metadata["score"] = score_val
        metadata["maxScore"] = 100.0
        metadata["passed"] = score_val >= 60.0
    except (ValueError, AttributeError):
        pass
    
    # Summary from message
    if grading_output.get("message"):
        metadata["summary"] = grading_output["message"]
    
    # Status text
    student_name = grading_output.get("student_name", "Student")
    metadata["statusText"] = f"Grading complete for {student_name}"
    
    # Transform component_scores to criteria format if available
    component_scores = grading_output.get("component_scores", [])
    if component_scores:
        criteria: List[CriterionMeta] = []
        for comp in component_scores:
            criteria.append({
                "name": comp.get("criterion_name", "Unknown"),
                "score": float(comp.get("score", 0)),
                "maxScore": float(comp.get("max_points", 100)),
                "comment": comp.get("student_feedback", ""),
            })
        metadata["criteria"] = criteria
    
    return metadata


def transform_tool_results(tool_results: Optional[List[Dict[str, Any]]]) -> ChatMetadata:
    """
    Transform generic tool results to ChatMetadata.
    
    Handles various tool output formats and extracts relevant metadata.
    """
    metadata: ChatMetadata = {"type": MetadataType.TEXT.value}
    
    if not tool_results:
        return metadata
    
    # Aggregate content and files from all tool results
    files: List[FileMeta] = []
    summaries: List[str] = []
    
    for result in tool_results:
        # Extract files if present
        result_metadata = result.get("metadata", {})
        if isinstance(result_metadata, dict):
            # Check for files in metadata
            result_files = result_metadata.get("files", [])
            for f in result_files:
                if isinstance(f, dict) and "filename" in f and "url" in f:
                    files.append({"filename": f["filename"], "url": f["url"]})
        
        # Extract content summary
        content = result.get("content", "")
        if content and isinstance(content, str):
            # Truncate long content for summary
            summary = content[:500] + "..." if len(content) > 500 else content
            summaries.append(summary)
        
        # Check for error
        error = result.get("error")
        if error:
            metadata["statusText"] = f"Tool error: {error}"
    
    if files:
        metadata["files"] = files
    
    if summaries:
        metadata["summary"] = "\n".join(summaries)
    
    return metadata


def transform_db_query_results(query_results: Optional[List[Dict[str, Any]]]) -> ChatMetadata:
    """
    Transform database query tool results to ChatMetadata.
    
    Handles AIO-specific queries like members, missions, submissions, etc.
    """
    metadata: ChatMetadata = {"type": MetadataType.TEXT.value}
    
    if not query_results:
        return metadata
    
    for result in query_results:
        tool_name = result.get("tool_name", "")
        content = result.get("content", "")
        result_metadata = result.get("metadata", {})
        
        # Handle team/member summary queries
        if "member" in tool_name.lower() or (isinstance(result_metadata, dict) and result_metadata.get("resource") == "members"):
            metadata["type"] = MetadataType.TEAM_SUMMARY.value
            # Try to extract team stats if available
            if isinstance(result_metadata, dict):
                metadata["completed"] = result_metadata.get("completed", 0)
                metadata["inProgress"] = result_metadata.get("in_progress", 0)
                metadata["atRisk"] = result_metadata.get("at_risk", 0)
                metadata["atRiskNames"] = result_metadata.get("at_risk_names", [])
        
        # Set summary from content
        if content:
            metadata["summary"] = content[:1000] if len(content) > 1000 else content
    
    return metadata


__all__ = [
    "MetadataType",
    "FileMeta",
    "CriterionMeta",
    "ChatMetadata",
    "StreamEvent",
    "build_event",
    "build_content_event",
    "build_reasoning_event",
    "build_error_event",
    "build_metadata_event",
    "transform_grading_response",
    "transform_tool_results",
    "transform_db_query_results",
]
