"""File processing utilities for the agent system.

Handles file metadata extraction, content extraction, and type classification.
Used by AgentSystem to process user-uploaded files (PDFs, images, videos)
before routing to the appropriate agent.
"""

import httpx
from typing import Optional, List, Dict, Any

from agents.tools.shared import LLMPdfExtractor
from utils.data_conversion import get_mime_type_from_filename


class FileProcessor:
    """Handles file metadata extraction, content extraction, and type classification.

    Used by AgentSystem to process user-uploaded files (PDFs, images, videos)
    before routing to the appropriate agent.
    """

    def __init__(self, llm_pdf_extractor: Optional[LLMPdfExtractor] = None):
        self.llm_pdf_extractor = llm_pdf_extractor or LLMPdfExtractor()

    def extract_metadata(self, files: List[dict]) -> List[dict]:
        """Extract metadata (name, type, size, url) without loading file content.

        Args:
            files: List of file dicts with keys: name/filename, type/mime_type, size, url

        Returns:
            List of normalized metadata dicts
        """
        return [
            {
                "name": f.get("name") or f.get("filename"),
                "type": f.get("type") or f.get("mime_type") or get_mime_type_from_filename(f.get("filename")) or "application/octet-stream",
                "size": int(f.get("size", "0")),
                "url": f.get("url")
            }
            for f in files
        ]

    def format_metadata_summary(self, metadata: List[dict]) -> str:
        """Format file metadata as a human-readable summary for router context.

        Args:
            metadata: List of metadata dicts from extract_metadata()

        Returns:
            Formatted string like "- report.pdf (application/pdf, 2.1MB)"
        """
        lines = []
        for m in metadata:
            size_mb = m["size"] / 1_000_000
            lines.append(f"- {m['name']} ({m['type']}, {size_mb:.1f}MB)")
        return "\n".join(lines)

    def is_question_about_files(self, user_input: str, files: List[dict]) -> bool:
        """Determine if user's question is about uploaded files vs. course content.

        Checks file-related keywords, file name mentions, and non-file keywords.
        Defaults to True if files were just uploaded and no non-file keywords found.

        Args:
            user_input: The user's input text
            files: List of uploaded file dicts

        Returns:
            True if the question is about the uploaded files
        """
        # Skip extraction for grading-related inputs (handled by grading workflow)
        grading_keywords = {"submit", "submission", "grade", "grading", "mission", "challenge", "capstone", "workshop"}
        input_lower = user_input.lower()
        if any(kw in input_lower for kw in grading_keywords):
            return False

        user_lower = user_input.lower()

        # Keywords indicating file-related questions
        file_keywords = [
            "file", "document", "pdf", "image", "video", "screenshot",
            "attachment", "upload", "this", "it", "what's in", "analyze",
            "review", "check", "look at", "read", "see"
        ]

        # Check if any file names are mentioned (support both 'name' and 'filename' keys)
        for f in files:
            file_name = f.get("name") or f.get("filename", "")
            if file_name.lower() in user_lower:
                return True

        # Check for file-related keywords
        if any(keyword in user_lower for keyword in file_keywords):
            return True

        # If asking about workshops, events, progress, etc. - NOT about files
        non_file_keywords = [
            "workshop", "event", "mission", "series", "program",
            "progress", "upcoming", "schedule", "when", "where"
        ]

        if any(keyword in user_lower for keyword in non_file_keywords):
            return False

        # Default: if files were just uploaded, assume question is about them
        return True

    async def download_file(self, url: str) -> bytes:
        """Download file content from URL.

        Args:
            url: File URL to download

        Returns:
            Raw file bytes
        """
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(url)
            response.raise_for_status()
            return response.content

    async def extract_or_prepare_files(self, files: List[dict]) -> dict:
        """Extract text from documents and prepare images for multimodal input.

        Separates files by type:
        - PDFs/docs → extract text via LLMPdfExtractor
        - Images (<5MB) → collect URLs for multimodal
        - Videos → add descriptive note

        Args:
            files: List of file dicts with url, type/mime_type, name/filename, size

        Returns:
            Dict with 'text_content' (str|None) and 'image_urls' (list|None)
        """
        result = {
            "text_content": None,
            "image_urls": None
        }

        # Separate files by type
        doc_files = []  # PDFs, docs → extract text
        image_files = []  # Images → multimodal

        for file in files:
            file_type = file.get("type") or file.get("mime_type", "")
            size = file.get("size", 0)

            if "pdf" in file_type or "document" in file_type:
                doc_files.append(file)
            elif "image" in file_type and size < 5_000_000:  # <5MB
                image_files.append(file)
            elif "video" in file_type:
                # Videos: add note for user
                file_name = file.get("name") or file.get("filename", "video")
                if not result["text_content"]:
                    result["text_content"] = ""
                result["text_content"] += f"\n[Video: {file_name} - Please describe what you'd like to know]"

        # Extract text from documents (async)
        if doc_files:
            try:
                extracted_texts = []
                for doc_file in doc_files:
                    # Use existing LLMPdfExtractor
                    file_type = doc_file.get("type") or doc_file.get("mime_type", "")
                    if "pdf" in file_type:
                        # Download PDF
                        pdf_bytes = await self.download_file(doc_file["url"])
                        # Extract text
                        file_name = doc_file.get("name") or doc_file.get("filename", "document")
                        extracted = await self.llm_pdf_extractor.execute(
                            pdf_bytes=pdf_bytes,
                            file_name=file_name
                        )
                        extracted_texts.append(f"[{file_name}]\n{extracted.get('content', '')}")

                result["text_content"] = "\n\n".join(extracted_texts)
            except Exception as e:
                print(f"Text extraction failed: {e}")
                result["text_content"] = f"[Error extracting document content: {e}]"

        # Prepare images for multimodal
        if image_files:
            result["image_urls"] = [f["url"] for f in image_files]

        return result
