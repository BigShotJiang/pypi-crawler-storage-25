# AgentSystem — Deep Developer Guide

**File:** `src/agents/systems/simple_agent_system.py`  
**Class:** `AgentSystem`  
**Lines:** ~755  
**Last updated:** 2026-02-27 (post Phase 10 refactor)

---

## Table of Contents

1. [File Structure](#1-file-structure)
2. [Construction & Initialization](#2-construction--initialization)
3. [The Streaming Pipeline — `run_stream()`](#3-the-streaming-pipeline--run_stream)
4. [Domain 1: Turn Initialization](#4-domain-1-turn-initialization--_init_turn)
5. [Domain 2: Prefetch Shortcut](#5-domain-2-prefetch-shortcut--_try_prefetch_shortcut)
6. [Domain 3: Workflow Dispatch](#6-domain-3-workflow-dispatch--_dispatch_workflow)
7. [Domain 4: Entity Resolution & Tool Execution (ToolExecutor)](#7-domain-4-entity-resolution--tool-execution-toolexecutor)
8. [Domain 5: Safety Guards](#8-domain-5-safety-guards)
9. [Domain 6: Answer Streaming](#9-domain-6-answer-streaming--_stream_answer_and_save)
10. [Domain 7: Session Management](#10-domain-7-session-management)
11. [SSE Event Protocol](#11-sse-event-protocol)
12. [State Object Reference](#12-state-object-reference)
13. [Dependency Map](#13-dependency-map)
14. [Testing Strategy](#14-testing-strategy)
15. [Common Modification Scenarios](#15-common-modification-scenarios)

---

## 1. File Structure

### `simple_agent_system.py` (~755 lines)

```
Line Range   Section                          Domain
─────────────────────────────────────────────────────────────
  1–52       Imports + module-level setup      Infrastructure
 55–74       _requires_domain_knowledge()      Hallucination guard helper (free function)
 78–178      __init__()                         Construction (uses factory helpers)
180–304      _init_turn()                       Turn initialization (uses fetch_cached)
306–339      _try_prefetch_shortcut()           Prefetch fast-path
341–438      _dispatch_workflow()               Grading workflow state machine
440–450      run()                              Non-streaming wrapper
452–583      run_stream()                       Main orchestration loop (skeleton)
585–586      get_history()                      Accessor
588–610      _infer_best_tool_group()           Circuit breaker tool selection
612–615      _is_general_chat()                 General chat detection
617–646      _apply_circuit_breaker()           Router loop prevention
648–671      _apply_hallucination_guard()       Domain question grounding check
673–692      create_session()                   Session creation
694–755      _stream_answer_and_save()          Canonical answer + persist path
```

### `tool_executor.py` (~208 lines) — Extracted in Phase 10

```
Line Range   Section                          Domain
─────────────────────────────────────────────────────────────
  1–13       Imports                           Infrastructure
 16–32       ToolExecutor.__init__()            Construction
 34–146      execute_with_resolution()          Entity resolution + DB/RAG tool execution
148–195      auto_resolve_entity()              Auto-prefetch for general sessions
197–208      map_entity_type_to_resource()      Entity type → DB resource mapping
```

### `constants.py` (~186 lines) — Factory helpers added in Phase 10

```
Line Range   Section                          Domain
─────────────────────────────────────────────────────────────
 16–30       create_llm_suite()                 LLM client factory
 35–56       init_redis_cache()                 Redis cache factory
 63–69       WorkflowType                       Enum
 74         MAX_ITERATIONS                     Config
 82–185      Keyword sets + mappings            Constants
```

---

## 2. Construction & Initialization

### Constructor Parameters

| Parameter | Type | Default | Purpose |
|-----------|------|---------|---------|
| `tool_groups` | `List[str]` | `None` | Active tool groups (e.g., `["circle_aio"]`, `["lark"]`) — determines which tools the Router can select |
| `context` | `List[dict]` | `None` | Pre-loaded conversation messages (used when no session_id) |
| `session_id` | `str` | `None` | Existing session UUID — loads history from Supabase |
| `member_id` | `int` | `None` | Platform member ID — used for email resolution and student context |
| `auto_save` | `bool` | `True` | Whether to persist messages to Supabase |
| `prompt_logger` | `Any` | `None` | Optional logger for LLM prompt/response pairs |

### What `__init__` Creates

**4 LLM clients** (created via `create_llm_suite()` factory in `constants.py`):

| Client | Model | Temp | Used By |
|--------|-------|------|---------|
| `router_llm` | arcee-ai/trinity-mini:nitro (+ fallbacks) | 0.1 | RouterAgent — intent classification |
| `tool_llm` | arcee-ai/trinity-mini:nitro (+ fallbacks) | 0.1 | ToolAgent — tool selection |
| `intent_verification_llm` | arcee-ai/trinity-mini:nitro (+ fallbacks) | 0.1 | IntentVerificationAgent — grading confirmation |
| `writing_llm` | google/gemini-2.5-flash-lite:nitro | 0.2 | AnsweringAgent — final response generation |

**4 Sub-agents:**

| Agent | Class | Role |
|-------|-------|------|
| `router` | `RouterAgent` | Classifies intent (CHAT vs TOOL) and selects tool group |
| `tool_agent` | `ToolAgent` | Picks specific tool from group, executes it |
| `answering_agent` | `AnsweringAgent` | Generates streaming LLM response |
| `intent_verifier` | `IntentVerificationAgent` | Validates grading submissions |

**Infrastructure:**

| Component | Class | Role |
|-----------|-------|------|
| `state` | `AgentState` | Mutable conversation state (messages, intent, tool results) |
| `session_mgr` | `SessionManager` | Async Supabase message persistence |
| `grading_handler` | `GradingEventHandler` | Multi-turn grading workflow handlers |
| `database_tool` | `DatabaseToolHandler` | Direct Supabase queries for entity data |
| `entity_resolver` | `EntityResolver` | Resolves entity names to DB IDs |
| `context_prefetcher` | `ContextPrefetcher` | Pre-loads entity data by type+ID (with Redis cache) |
| `tool_executor` | `ToolExecutor` | Entity resolution + DB/RAG tool execution pipeline |
| `file_processor` | `FileProcessor` | File metadata extraction, PDF/image processing |
| `cache` | `Redis` (optional) | Upstash Redis via `init_redis_cache()` factory |

### Session Restoration

If `session_id` is provided, `__init__` loads existing messages and workflow state from Supabase. If `context` is provided instead, those messages are injected directly. This means the agent resumes mid-conversation with full history.

---

## 3. The Streaming Pipeline — `run_stream()`

`run_stream()` is the **main entry point** — a ~130-line async generator that orchestrates the entire turn. It delegates to extracted methods for each phase.

### Signature

```
run_stream(
    user_input: str,
    email: Optional[str] = None,
    files: Optional[list[dict]] = None,
    with_post: Optional[bool] = False,
    circle_file_urls: Optional[list[str]] = None,
    context_type: Optional[str] = None,
    context_id: Optional[str] = None,
) -> AsyncGenerator[dict, None]
```

### Parameters

| Parameter | Purpose |
|-----------|---------|
| `user_input` | The user's message text |
| `email` | User's email (for grading). If `None`, resolved from `member_id` |
| `files` | Uploaded files as `[{"filename": str, "url": str, "content_type": str}]` |
| `with_post` | Whether to auto-post grading results to Circle |
| `circle_file_urls` | Circle CDN URLs for uploaded files |
| `context_type` | Entity type for context injection (e.g., `"challenge"`, `"mission"`) |
| `context_id` | Entity UUID for context injection |

### Execution Order

```
run_stream()
  ├── 1. _init_turn()              → yields timing + reasoning events
  ├── 2. _try_prefetch_shortcut()  → if hit: yields answer → RETURN
  ├── 3. _dispatch_workflow()      → if active: yields workflow events → RETURN
  └── 4. Agent Loop (while True):
        ├── Hard stop check (> MAX_ITERATIONS)
        ├── General chat fast-path
        ├── tool_executor.auto_resolve_entity()   [Phase 5A / Phase 10]
        ├── Auto-resolve shortcut (Phase 9)        → if entity resolved: answer → BREAK
        ├── RouterAgent.decide()
        ├── _apply_circuit_breaker()
        ├── Grading intent → GradingEventHandler → RETURN
        ├── FINISHED + CHAT → _apply_hallucination_guard()
        │   ├── No guard → _stream_answer_and_save() → BREAK
        │   └── Guard triggered → redirect to TOOL
        └── TOOL → tool_executor.execute_with_resolution() → CONTINUE loop
```

**Key invariant:** Every code path ends with either `return`, `break`, or loops back. The generator always yields SSE events and terminates cleanly.

---

## 4. Domain 1: Turn Initialization — `_init_turn()`

**Lines:** 180–304 (~125 lines)  
**Called by:** `run_stream()` — once per turn, always first

### Responsibilities

1. **Add user message to state** — `state.add_message(USER, user_input)`
2. **Resolve email** — If `email=None` and `member_id` exists, queries Supabase `members` table. Runs in parallel with message save.
3. **Save user message** — Async save to session via `SessionManager`
4. **Reset per-turn state** — Clears `intent`, `tool_call`, `tool_results`, `final_response`, `error`, `iteration_count`
5. **Prefetch context** — If `context_type` and `context_id` provided:
   - Delegates to `ContextPrefetcher.fetch_cached()` (Redis cache layer)
   - Inject as SYSTEM message
6. **File metadata extraction** — If files uploaded:
   - Extract metadata (type, size, name)
   - Add SYSTEM message summarizing uploads
   - Optionally start parallel content extraction task

### Side Effects Set

| Attribute | Description |
|-----------|-------------|
| `self._resolved_email` | Resolved email string or None |
| `self._extraction_task` | `asyncio.Task` for file content extraction (or None) |
| `self._session_context_type` | The `context_type` parameter (stored for later checks) |

---

## 5. Domain 2: Prefetch Shortcut — `_try_prefetch_shortcut()`

**Lines:** 306–339 (~34 lines)  
**Called by:** `run_stream()` — after `_init_turn()`, before workflow dispatch

### Logic

If ALL of these conditions are met:
- `state.context_prefetch` has data (context was pre-loaded)
- No files uploaded
- No action keywords detected in input ("submit", "grade", "upload", etc.)

Then: **Skip the entire Router + Tool pipeline.** Answer directly from the pre-loaded context using `_stream_answer_and_save()`.

### Why It Exists

When the frontend passes `context_type=challenge&context_id=UUID`, the context is pre-loaded in `_init_turn()`. If the user asks a simple question like "What is this challenge about?", we don't need the Router to classify intent or the ToolAgent to search — the answer is already in the conversation context.

### Return Pattern

Returns `Optional[AsyncGenerator]`. If shortcut applies, returns a generator. If not, returns `None`. The caller checks for `None` to decide whether to continue.

---

## 6. Domain 3: Workflow Dispatch — `_dispatch_workflow()`

**Lines:** 341–438 (~98 lines)  
**Called by:** `run_stream()` — after prefetch shortcut check

### Purpose

Handles the **grading workflow state machine**. If `state.workflow_state` is set (from a previous turn), this method dispatches to the appropriate `GradingEventHandler` method.

### Workflow Types

| `WorkflowType` | Trigger | Handler |
|-----------------|---------|---------|
| `MISSION_CONFIRMATION` | User confirmed submission details | `grading_handler.handle_mission_confirmation()` |
| `POSTING_CONFIRMATION` | Score ≥ 80, asking to post to Circle | `grading_handler.handle_posting_confirmation()` |
| `RESUBMISSION` | Prior submission exists, asking to re-grade | `grading_handler.handle_resubmission()` |

### Cancel Escape Hatch

If `user_input` matches a cancel keyword ("cancel", "stop", "quit", etc.), the workflow state is cleared and a cancellation message is returned. This prevents users from being stuck in a workflow.

### Metadata Update on Confirmation

When `WorkflowType.MISSION_CONFIRMATION` is active and the user provides new files or substantive text (>50 chars), the `submission_metadata` dict is updated before delegation. This ensures the confirmation handler grades with the latest data.

### `circle_file_urls` Persistence

Circle file URLs are stored in `workflow_state` and restored across turns. The pattern is: `effective_circle_urls = circle_file_urls or stored_circle_urls`. This handles the case where the user uploaded files in turn N but confirms in turn N+1 (where the frontend doesn't re-send the URLs).

---

## 7. Domain 4: Entity Resolution & Tool Execution (ToolExecutor)

**File:** `src/agents/systems/tool_executor.py` (~208 lines)  
**Class:** `ToolExecutor`  
**Extracted in:** Phase 10 (was inline in `simple_agent_system.py`)

This class encapsulates all entity-resolution and tool-execution logic, keeping the orchestrator focused on flow control.

### `execute_with_resolution()` (Lines 34–146, 113 lines)

**Called by:** `run_stream()` main loop when `decision.intent == TOOL`  
**Signature:** `execute_with_resolution(state, user_input, chosen_group) -> AsyncGenerator`

#### Pipeline

```
User query
    │
    ▼
Phase 9 check: state.resolved_entities populated?
    │
    ├── YES → Reuse cached ResolvedQuery (skip LLM call)
    └── NO  → EntityResolver.resolve(query, conversation_history[-5:])
                  │
                  ├── resolved=True, entity_id found
                  │       │
                  │       ▼
                  │   DatabaseToolHandler.execute(resource, name, limit=10, include_related=True)
                  │       │
                  │       ├── result OK → state.tool_results = [db_result]
                  │       └── no result → FALLBACK to ToolAgent + RAG
                  │
                  └── resolved=False
                          │
                          ▼
                      ToolAgent.select_tool(state)  ← RAG search via tool schemas
```

#### Why Two Paths

**Direct DB** (deterministic): When EntityResolver identifies a specific entity (e.g., "Mission 5" → mission ID 5), we fetch it directly. This is faster and more reliable than RAG.

**RAG Fallback**: When the entity can't be resolved (e.g., "how do I submit assignments?"), we fall back to the ToolAgent which uses LLM-guided tool selection and vector search.

### `auto_resolve_entity()` (Lines 148–195, 48 lines)

**Called by:** `run_stream()` main loop, first iteration only  
**Signature:** `auto_resolve_entity(state, user_input, session_context_type) -> AsyncGenerator`

For **general sessions** (no `context_type` provided), this method auto-detects entity references and pre-fetches their context. Example: user sends "Tell me about Mission 5" in a general chat → auto-resolves "Mission 5" → prefetches mission data → enriches the conversation.

Conditions: entity keywords present, first iteration, no existing prefetch, no session context type.

**Phase 9 optimization:** After `auto_resolve_entity()` populates `state.context_prefetch` and `state.resolved_entities`, the **auto-resolve shortcut** in `run_stream()` checks if the data is sufficient to answer directly — skipping Router + Tool entirely.

### `map_entity_type_to_resource()` (Lines 197–208, static method)

Simple lookup: `"mission" → "missions"`, `"challenge" → "challenges"`, etc. Defined in `constants.ENTITY_TYPE_TO_RESOURCE`.

---

## 8. Domain 5: Safety Guards

### Circuit Breaker — `_apply_circuit_breaker()` (Lines 617–646)

**Problem:** RouterAgent might loop, repeatedly choosing CHAT+CONTINUE without making progress.

**Trigger:** `iteration_count >= 2` AND `tool_results` is still empty.

**Action:** Force `intent = TOOL`, select best tool group via `_infer_best_tool_group()` (keyword matching on GRADING_KEYWORDS, AIO_KEYWORDS).

**Returns:** List of reasoning events (yielded by caller).

### Hallucination Guard — `_apply_hallucination_guard()` (Lines 648–671)

**Problem:** AnsweringAgent might fabricate domain-specific answers without grounding data.

**Trigger:** Router says FINISHED+CHAT, but `_requires_domain_knowledge()` detects domain terms AND no `tool_results` AND no `context_prefetch`.

**Action:** Override decision to TOOL+CONTINUE, redirect to tool search for grounding data.

**Returns:** `(modified_decision, reasoning_events)` tuple. If no guard needed, returns `(None, [])`.

### Hard Stop (inline in `run_stream()`)

**Trigger:** `iteration_count > MAX_ITERATIONS` (default: 3).

**Action:** Force answer with whatever data is available.

### General Chat Fast-Path (inline in `run_stream()`)

**Trigger:** No entity keywords, no files, no prefetch, first iteration.

**Action:** Skip Router entirely, answer directly. This avoids unnecessary LLM calls for simple greetings.

---

## 9. Domain 6: Answer Streaming — `_stream_answer_and_save()`

**Lines:** 694–755 (~62 lines)  
**Called by:** All non-grading answer paths (prefetch shortcut, hard stop, general chat, auto-resolve shortcut, normal FINISHED+CHAT)

### What It Does

1. **Await file extraction** — If `extraction_task` was started in `_init_turn()`, await it and inject file content into state
2. **Build metadata** — Transform `tool_results` into `ChatMetadata` for the frontend
3. **Stream answer** — Iterate `answering_agent.astream_answer(state)`, yielding each chunk as a content event. Emit `answering_first_chunk` timing on first chunk
4. **Yield metadata** — If tool results produced structured metadata (files, summaries), yield a metadata event
5. **Update state** — Set `final_response`, add ASSISTANT message to history
6. **Persist** — Save assistant message to Supabase (if `auto_save`)
7. **Flush** — Ensure all pending saves are committed

### Parameters

| Parameter | Default | Purpose |
|-----------|---------|---------|
| `extra_metadata` | `None` | Additional metadata merged into saved message (e.g., `{"general_chat": True}`) |
| `extraction_task` | `None` | File extraction asyncio.Task to await before answering |

---

## 10. Domain 7: Session Management

### `SessionManager` Integration

`self.session_mgr` handles all Supabase persistence:

| Method | When Called |
|--------|------------|
| `save_message_async(role, content, metadata, files)` | After every user/assistant message |
| `flush_pending()` | At end of every turn and after workflow events |
| `load_messages()` | In `__init__` when `session_id` provided |
| `create_session(title, context_type, ...)` | Via `create_session()` public method |

### Async Save Pattern

Messages are saved asynchronously and batched. `flush_pending()` ensures all saves complete before the turn ends. This prevents message loss on errors.

### `create_session()` (Lines 673–692)

Public method to create a new session. Captures model metadata (router model, writing model, etc.) for debugging. Updates `self.session_id` and `self.session_mgr.session_id` after creation.

---

## 11. SSE Event Protocol

All `yield` statements in the pipeline produce dicts with this structure:

```
{
    "event": "<event_type>",
    "data": "<json_string>"
}
```

### Event Types

| Event | Builder | Data Fields | Purpose |
|-------|---------|-------------|---------|
| `message` | `build_content_event(text)` | `content` (base64) | LLM answer token chunks |
| `reasoning` | `build_reasoning_event(step, reasoning)` | `content` (base64), `step`, `reasoning` | Internal decision trace |
| `reasoning` | `build_timing_event(step, ms)` | `content` (base64), `timing` | Performance metrics |
| `metadata` | `build_metadata_event(metadata)` | `type`, `summary`, `files`, `score`, etc. | Structured result data |
| `error` | `build_error_event(message)` | `content` (base64) | Exception information |

### Content Encoding

All `content` fields are **base64-encoded UTF-8** strings. The frontend decodes them for display. This prevents SSE parsing issues with special characters.

---

## 12. State Object Reference

`self.state` is an `AgentState` instance (defined in `shared.py`). Key fields mutated during a turn:

| Field | Type | Set By | Used By |
|-------|------|--------|---------|
| `current_input` | `str` | `_init_turn` | Router, ToolAgent, AnsweringAgent |
| `messages` | `List[AgentMessage]` | Throughout | All agents (conversation history) |
| `intent` | `AgentIntent` | `run_stream` (from Router) | Loop control |
| `status` | `AgentStatus` | `run_stream` (from Router) | Loop control |
| `tool_results` | `List[dict]` | `ToolExecutor.execute_with_resolution` | AnsweringAgent, guards |
| `tool_schemas` | `List[ToolSchema]` | `ToolExecutor.execute_with_resolution` | ToolAgent |
| `context_prefetch` | `dict` | `_init_turn`, `ToolExecutor.auto_resolve_entity` | Shortcut, guards |
| `workflow_state` | `dict` | `_dispatch_workflow`, `GradingEventHandler` | Workflow state machine |
| `iteration_count` | `int` | `run_stream` loop | Guards, auto-resolve |
| `tool_inputs` | `dict` | `_init_turn` | Tool execution params |
| `resolved_entities` | `List[dict]` | `ToolExecutor.execute_with_resolution`, `ToolExecutor.auto_resolve_entity` | Phase 9 reuse cache |
| `email` | `str` | `_init_turn` | Grading, identification |
| `member_id` | `int` | `__init__` | Email resolution, student context |
| `final_response` | `str` | `_stream_answer_and_save` | Post-turn access |
| `error` | `str` | `run_stream` exception handler | Error reporting |

---

## 13. Dependency Map

### Direct Dependencies (imported in this file)

| Module | What | Used For |
|--------|------|----------|
| `src.agents.systems.tool_executor` | `ToolExecutor` | Entity resolution + tool execution (Phase 10) |
| `src.agents.systems.shared` | `AgentState`, `MessageRole`, `AgentIntent`, `AgentStatus` | Core state types |
| `src.agents.systems.constants` | `WorkflowType`, keyword sets, `create_llm_suite`, `init_redis_cache` | Config + factories |
| `src.agents.systems.response_types` | `build_*_event()`, `transform_*()`, `MetadataType`, `ChatMetadata` | SSE event construction |
| `src.agents.systems.session_manager` | `SessionManager` | Supabase persistence |
| `src.agents.systems.grading_event_handler` | `GradingEventHandler` | Grading workflow |
| `src.agents.systems.file_processor` | `FileProcessor` | File metadata & extraction |
| `src.agents.subagents.router_agent` | `RouterAgent` | Intent classification |
| `src.agents.subagents.tool_agent` | `ToolAgent` | Tool selection & execution |
| `src.agents.subagents.answering_agent` | `AnsweringAgent` | Response streaming |
| `src.agents.subagents.intent_verification_agent` | `IntentVerificationAgent` | Grading verification |
| `src.agents.tools.preprocessing.entity_resolver` | `EntityResolver` | Entity name → ID resolution |
| `src.agents.tools.database.aio.aio` | `DatabaseToolHandler` | Direct Supabase queries |
| `src.agents.context.prefetcher` | `ContextPrefetcher` | Entity data pre-loading (with `fetch_cached`) |
| `src.connectors.supabase_client.createClient` | `get_custom_client` | Supabase client init |
| `src.agents.systems.grading_system.optimized_grading_workflow` | `GradingWorkflow` | Grading execution |

**No longer directly imported by `simple_agent_system.py`:**

| Module | Moved To |
|--------|----------|
| `src.connectors.openrouter.llm` (`OpenRouterMultimodalLLM`) | `constants.py` → `create_llm_suite()` |
| `src.agents.tools.schema` (`get_tools_by_group`) | `tool_executor.py` |
| `upstash_redis` (`Redis`) | `constants.py` → `init_redis_cache()` |

### External Services

| Service | Connection | Failure Mode |
|---------|-----------|--------------|
| **OpenRouter API** | Via `OpenRouterMultimodalLLM`, model fallback chain | Falls back through model list, then raises |
| **Supabase** | Via `get_custom_client` (agents schema) | Graceful — session save disabled, queries fail silently |
| **Upstash Redis** | Via `upstash_redis.Redis` | Graceful — cache misses fall through to DB |

---

## 14. Testing Strategy

### Test Locations

| Suite | Path | What It Tests |
|-------|------|---------------|
| Grading | `tests/grading/` | Workflow state machine, source inspection, integration |
| Response Quality | `tests/response_quality/` | Unit behaviors, E2E chat |
| Context | `tests/context/` | Prefetcher, entity resolution |

### Source Inspection Tests

Several tests use `inspect.getsource()` to verify structural invariants:

| Test | Inspects | Verifies |
|------|----------|----------|
| `test_bugfixes.py::TestCircleFileUrlsPersistence` | `GradingEventHandler.handle_grading_intent` | `circle_file_urls` stored in workflow_state |
| `test_bugfixes.py::TestWorkflowEscapeHatch` | `AgentSystem._dispatch_workflow` | `CANCEL_KEYWORDS` and `workflow_state = None` |
| `test_challenge_mismatch_fix.py::TestConfirmationUpdatesMetadata` | `AgentSystem._dispatch_workflow` | Files and text_content updated on confirmation |
| `test_context_shortcut.py` | `run_stream` + `handle_grading_intent` (combined) | Challenge shortcut branch exists |

**Important:** When moving methods between files, update the `inspect.getsource()` targets in these tests.

### Running Tests

```bash
# Full grading suite (most comprehensive)
pytest tests/grading/ -v --timeout=120

# Quick smoke test
python -c "from src.agents.systems.simple_agent_system import AgentSystem; print('OK')"
```

---

## 15. Common Modification Scenarios

### Adding a New Tool Group

1. Define tools in `src/agents/tools/schemas/` 
2. Register group in `src/agents/tools/schema.py` → `AVAILABLE_TOOLS`
3. Add domain indicators to `constants.py` → `DOMAIN_KNOWLEDGE_INDICATORS` (for hallucination guard)
4. Add keywords to `constants.py` → `AIO_KEYWORDS` or create new set (for circuit breaker)
5. Pass group name in `tool_groups` parameter when constructing `AgentSystem`

### Adding a New Workflow Type

1. Add enum value to `constants.py` → `WorkflowType`
2. Add handler method to `grading_event_handler.py` → `GradingEventHandler`
3. Add dispatch branch to `_dispatch_workflow()` in this file
4. Ensure handler sets `state.workflow_state` with the new type for multi-turn flow

### Modifying the Router Decision Flow

The Router decision is processed in `run_stream()` lines 544–578. The decision object has:
- `intent`: `AgentIntent.CHAT` or `AgentIntent.TOOL`
- `status`: `AgentStatus.FINISHED` or `AgentStatus.CONTINUE`
- `tools_group`: Which tool group to use (e.g., `"circle_aio"`, `"grading_system"`)

The processing order is:
1. Circuit breaker (may override intent)
2. Grading check (`tools_group == "grading_system"`)
3. FINISHED + CHAT → hallucination guard → answer
4. TOOL → execute tool → loop

### Adding a New Safety Guard

1. Create a method following the pattern of `_apply_circuit_breaker()` or `_apply_hallucination_guard()`
2. Return events (not yield) — the caller yields them in `run_stream()`
3. Insert call at the appropriate point in the `run_stream()` loop
4. Add test in `tests/grading/test_bugfixes.py` or similar

### Changing the Answer Path

All non-grading answers flow through `_stream_answer_and_save()`. To add behavior to all answers (e.g., logging, post-processing), modify this single method. The five callers are:
- Prefetch shortcut
- Hard stop
- General chat
- Auto-resolve shortcut (Phase 9)
- Normal FINISHED+CHAT

Grading answers are handled separately by `GradingEventHandler`.

### Modifying Entity Resolution or Tool Execution

All entity resolution and tool execution logic lives in `tool_executor.py` → `ToolExecutor`. The orchestrator calls two methods:
- `tool_executor.auto_resolve_entity(state, user_input, session_context_type)` — auto-detect + prefetch
- `tool_executor.execute_with_resolution(state, user_input, chosen_group)` — resolve + DB/RAG

To add a new resolution strategy, modify `ToolExecutor`. Do NOT add tool logic to `simple_agent_system.py`.
