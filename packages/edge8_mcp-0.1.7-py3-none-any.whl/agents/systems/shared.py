import os
import sys
from typing import List, Dict, Any, Optional, Union
from enum import Enum
from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict

# Add project root to path if not already added
sys.path.append(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
)

from connectors.openrouter.llm import (
    OpenRouterMultimodalLLM,
    ChatMessage,
    ToolSelection,
)
from agents.tools.schema import get_tools_by_names, ToolSchema
from agents.tools.handlers import execute_tool
from utils.formatting import format_for_llm
from time import time

# --- Data Models ---


class MessageRole(str, Enum):
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"
    TOOL = "tool"


class AgentMessage(BaseModel):
    role: MessageRole
    content: str
    name: Optional[str] = None
    timestamp: datetime = Field(default_factory=datetime.now)


class AgentIntent(str, Enum):
    CHAT = "chat"
    TOOL = "tool"


class AgentStatus(str, Enum):
    FINISHED = "finished"
    CONTINUE = "continue"


class RouterOutput(BaseModel):
    intent: AgentIntent
    status: AgentStatus
    step: str
    reasoning: str
    tools_group: str


class ToolCallData(BaseModel):
    tool_name: str
    tool_kwargs: Dict[str, Any]
    reasoning: str


class AgentState(BaseModel):
    messages: List[AgentMessage] = Field(default_factory=list)
    current_input: str = ""
    context: Optional[str] = None
    intent: Optional[AgentIntent] = None
    status: Optional[AgentStatus] = None
    tool_inputs: Optional[Dict[str, Any]] = {}
    tool_schemas: Optional[List[ToolSchema]] = None
    tool_call: Optional[ToolCallData] = None
    tool_results: Optional[List[Dict[str, Any]]] = None
    final_response: Optional[str] = None
    error: Optional[str] = None
    iteration_count: int = 0
    workflow_state: Optional[Dict[str, Any]] = None
    last_submission: Optional[Dict[str, Any]] = None
    submission_history: List[Dict[str, Any]] = Field(default_factory=list)
    tool_groups: Optional[List[str]] = None
    member_id: Optional[int] = None
    student_id: Optional[int] = None
    email: Optional[str] = None
    context_prefetch: Optional[Dict[str, Any]] = None
    resolved_entities: List[Dict[str, Any]] = Field(default_factory=list)  # Phase 3C: Entity persistence
    student_inputs: Optional[Dict[str, Dict[str, str]]] = None  # Workbook student responses for grading
    workbook_answers: Optional[Dict[str, Dict[str, str]]] = None  # Session-accumulated workbook answers (Coach path)
    persona: str = "customer_service"  # ← ADD THIS LINE

    # Request-scoped context cache (not serialized) - shared between Router and Answering agents
    _context_cache: Optional[str] = None

    model_config = ConfigDict(underscore_attrs_are_private=True)

    def add_message(self, role: MessageRole, content: str, name: Optional[str] = None):
        self.messages.append(AgentMessage(role=role, content=content, name=name))

    def add_submission_result(self, result: Dict[str, Any]):
        """Track submission result for follow-up questions"""
        self.last_submission = result
        self.submission_history.append(result)

    def get_submission_context(self) -> Optional[str]:
        """Get context about last submission for follow-up questions"""
        if not self.last_submission:
            return None
        return f"""
Previous Submission:
- Mission: {self.last_submission.get('mission_name')}
- Score: {self.last_submission.get('score')}
- Submitted at: {self.last_submission.get('timestamp')}
"""

    def get_history_str(self, limit: int = 10) -> str:
        """Format recent history for LLM context."""
        recent = self.messages[-limit:]
        formatted = []
        for msg in recent:
            prefix = f"[{msg.name}] " if msg.name else ""
            formatted.append(f"{prefix}{msg.role.value.upper()}: {msg.content}")
        return "\n".join(formatted)
    
    def format_tool_results_for_history(self, tool_results: List[Dict[str, Any]]) -> str:
        """Format tool results into a readable string for message history."""
        if not tool_results:
            return "No tool results."

        formatted_results = []
        for result in tool_results:
            tool_name = result.get("tool_name", "unknown")
            error = result.get("error")

            if error:
                formatted_results.append(f"Tool '{tool_name}' failed: {error}")
            else:
                content = result.get("content", "")
                metadata = result.get("metadata", {})

                result_str = f"Tool '{tool_name}' executed successfully."
                if content:
                    content_preview = content[:200] + "..." if len(content) > 200 else content
                    result_str += f"\nResult: {content_preview}"
                if metadata:
                    result_str += f"\nMetadata: {format_for_llm(metadata)}"

                formatted_results.append(result_str)

        return "\n\n".join(formatted_results)


# --- Base Agent ---


class BaseAgent:
    def __init__(
        self, llm_client: OpenRouterMultimodalLLM, system_prompt: Optional[str] = None
    ):
        self.client = llm_client
        self.tool_schemas: Optional[List[ToolSchema]] = None
        self.system_prompt = system_prompt

    async def aprocess_with_tools(
        self,
        messages: List[ChatMessage],
        available_tools: List[str] = None,
        **kwargs,
    ) -> Union[tuple[str, List[Union[str, Dict[str, Any]]]], bool, None]:
        """Async process messages with tool calling support
        
        Args:
            messages: Chat messages to process
            available_tools: List of tool names to use
            **kwargs: Additional arguments including:
                - tool_choice: "auto", "required", "none", or specific tool name
                - access_token: Access token for tools
        """
        access_token = kwargs.pop("access_token", None)
        tool_choice = kwargs.pop("tool_choice", "required")

        if available_tools:
            tools: List[ToolSchema] = get_tools_by_names(available_tools)
        else:
            tools: List[ToolSchema] = self.tool_schemas if self.tool_schemas else []

        # Try with tools first, fall back to regular chat if tools not supported
        if tools:
            try:
                print(f"Using tools: {[t.name for t in tools]}")
                print(f"Current model: {self.client.model}")
                print(f"Tool choice: {tool_choice}")
                response = await self.client.achat(messages, tools=tools, tool_choice=tool_choice)

                tool_calls = response.message.additional_kwargs.get("tool_calls")
                
                print(f"Tool Use Response type: {type(tool_calls)}")
                # print(f"Tool Use Response content: {response.message.content}")

                # Check if model wants to use tools
                tool_calls = self.client.get_tool_calls_from_response(
                    response, access_token=access_token, **kwargs
                )

                if tool_calls:
                    # Execute the tools
                    tool_results = await self.execute_tool_calls(tool_calls)
                    
                    final_response = (
                        response.message.content.strip()
                        if response.message.content
                        else (tool_calls[0].tool_kwargs.get("text", "") if isinstance(tool_calls[0].tool_kwargs, dict) else str(tool_calls[0].tool_kwargs))
                    )
                    
                    # print("Final response:", final_response)
                    # print("Tool results:", tool_results)
                    return final_response, tool_results

                return response.message.content.strip(), None
            except Exception as e:
                # If tools fail (404, etc.), fall back to regular chat
                if "404" in str(e) or "tool" in str(e).lower():
                    print(f"Tools not supported, falling back to regular chat: {e}")
                    response = await self.client.achat(messages)
                    return response.message.content, None
                else:
                    raise
        else:
            # No tools available, use regular chat
            response = await self.client.achat(messages)
            return response.message.content.strip(), None

    async def execute_tool_calls(
        self, tool_calls: List[ToolSelection]
    ) -> List[Dict[str, Any]]:
        """Execute tool calls and return results"""
        results = []
        for tool_call in tool_calls:
            try:
                start_time = time()
                tool_name = tool_call.tool_name
                tool_args = tool_call.tool_kwargs

                result: Dict[str, Any] = await execute_tool(tool_name, **tool_args)

                results.append(
                    {
                        "tool_call_id": tool_call.tool_id,
                        "tool_name": tool_name,
                        "content": result.get("content", ""),
                        "metadata": result.get("metadata", {}),
                        "error": result.get("error", None),
                        "execution_time": time() - start_time,
                    }
                )
                # tool_args = {**tool_args, **result.get("metadata", {})}
            except Exception as e:
                results.append(
                    {
                        "tool_call_id": tool_call.tool_id,
                        "tool_name": tool_call.tool_name,
                        "error": str(e),
                    }
                )
        return results
