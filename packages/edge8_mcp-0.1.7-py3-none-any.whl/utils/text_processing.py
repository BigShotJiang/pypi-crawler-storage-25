from typing import Dict, List, Any
import json
from datetime import datetime
import html


def _extract_inline_content(element) -> List[Dict[str, Any]]:
    """
    Extract inline content with proper mark handling (bold, italic, links, etc).
    Converts HTML inline elements to Circle/TipTap marks format.
    
    Args:
        element: BeautifulSoup element to extract content from
        
    Returns:
        List of content nodes with proper marks
    """
    content = []
    
    for child in element.children:
        if isinstance(child, NavigableString):
            text = str(child).strip()
            if text:
                content.append({
                    "type": "text",
                    "text": text
                })
        else:
            tag_name = child.name
            text = child.get_text().strip()
            
            # Skip empty text nodes only if it's not a void element (like br, img)
            if not text and tag_name not in ['br', 'img', 'hr']:
                continue
            
            # Handle inline formatting tags
            if tag_name == 'strong' or tag_name == 'b':
                content.append({
                    "type": "text",
                    "marks": [{"type": "bold"}],
                    "text": text
                })
            elif tag_name == 'em' or tag_name == 'i':
                content.append({
                    "type": "text",
                    "marks": [{"type": "italic"}],
                    "text": text
                })
            elif tag_name == 'u':
                content.append({
                    "type": "text",
                    "marks": [{"type": "underline"}],
                    "text": text
                })
            elif tag_name in ['del', 's', 'strike']:
                content.append({
                    "type": "text",
                    "marks": [{"type": "strike"}],
                    "text": text
                })
            elif tag_name == 'code':
                content.append({
                    "type": "text",
                    "marks": [{"type": "code"}],
                    "text": text
                })
            elif tag_name == 'a':
                href = child.get('href', '#')
                content.append({
                    "type": "text",
                    "marks": [{
                        "type": "link",
                        "attrs": {
                            "href": href,
                            "target": "_blank"
                        }
                    }],
                    "text": text
                })
            elif tag_name == 'br':
                content.append({"type": "hardBreak"})
            elif tag_name == 'img':
                src = child.get('src', '')
                alt = child.get('alt', '')
                title = child.get('title', None)
                img_node = {
                    "type": "image",
                    "attrs": {
                        "src": src,
                        "alt": alt
                    }
                }
                if title:
                    img_node["attrs"]["title"] = title
                content.append(img_node)
            else:
                # Fallback for unknown inline tags
                content.append({
                    "type": "text",
                    "text": text
                })
    
    return content if content else [{"type": "text", "text": element.get_text().strip()}]


def markdown_to_rich_text(md_text: str) -> Dict:
    import markdown
    from bs4 import BeautifulSoup, NavigableString
    """
    Convert markdown text to a rich_text object compatible with Circle API (TipTap format).
    
    Supports:
    - Paragraphs with inline formatting (bold, italic, underline, code, links)
    - Headings (h1-h6)
    - Lists (ordered and unordered)
    - Blockquotes
    - Code blocks
    - Horizontal rules (dividers)
    - Line breaks
    
    Args:
        md_text: Markdown formatted text
        
    Returns:
        dict: Rich text object with Circle/TipTap compatible structure
    """
    # Use extensions for better markdown support
    html = markdown.markdown(
        md_text,
        # extensions=['fenced_code', 'tables', 'nl2br', 'sane_lists'],
        output_format="html"
    )
    
    # Write HTML to file for debugging
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    debug_file = f"/tmp/markdown_to_html_{timestamp}.html"
    with open(debug_file, 'w') as f:
        f.write(html)
    print(f"HTML output written to: {debug_file}")
    
    # Parse HTML with BeautifulSoup
    soup = BeautifulSoup(html, 'html.parser')
    
    # Build rich text structure compatible with Circle API
    # The structure must be wrapped in a "body" object
    rich_text = {
        "body": {
            "type": "doc",
            "content": []
        }
    }
    
    # Helper to append to the correct content list
    def append_content(node):
        rich_text["body"]["content"].append(node)
    
    # Process each element in the HTML
    for element in soup.children:
        if isinstance(element, NavigableString):
            # Handle text nodes
            text = str(element).strip()
            if text:
                append_content({
                    "type": "paragraph",
                    "content": [{
                        "type": "text",
                        "text": text
                    }]
                })
        else:
            # Handle HTML tags
            tag_name = element.name
            
            if tag_name == 'p':
                content = _extract_inline_content(element)
                append_content({
                    "type": "paragraph",
                    "content": content
                })
            
            elif tag_name in ['h1', 'h2', 'h3', 'h4', 'h5', 'h6']:
                level = int(tag_name[1])
                content = _extract_inline_content(element)
                append_content({
                    "type": "heading",
                    "attrs": {"level": level},
                    "content": content
                })
            
            elif tag_name == 'ul':
                # Collect all list items into a single bulletList
                list_items = []
                for li in element.find_all('li', recursive=False):
                    content = _extract_inline_content(li)
                    list_items.append({
                        "type": "listItem",
                        "content": [{
                            "type": "paragraph",
                            "content": content
                        }]
                    })
                
                append_content({
                    "type": "bulletList",
                    "content": list_items
                })
            
            elif tag_name == 'ol':
                # Collect all list items into a single orderedList
                list_items = []
                for li in element.find_all('li', recursive=False):
                    content = _extract_inline_content(li)
                    list_items.append({
                        "type": "listItem",
                        "content": [{
                            "type": "paragraph",
                            "content": content
                        }]
                    })
                
                append_content({
                    "type": "orderedList",
                    "attrs": {"start": 1},
                    "content": list_items
                })
            
            elif tag_name == 'blockquote':
                content = _extract_inline_content(element)
                append_content({
                    "type": "blockquote",
                    "content": [{
                        "type": "paragraph",
                        "content": content
                    }]
                })
            
            elif tag_name == 'code':
                # Inline code handled by _extract_inline_content
                # This is for standalone code blocks
                code_text = element.get_text()
                append_content({
                    "type": "codeBlock",
                    "attrs": {"language": "text"},
                    "content": [{
                        "type": "text",
                        "text": code_text
                    }]
                })
            
            elif tag_name == 'pre':
                # Code block with potential language detection
                code_text = element.get_text()
                language = "text"
                
                # Try to detect language from class attribute on pre or inner code tag
                classes = element.get('class', [])
                if not classes:
                    code_tag = element.find('code')
                    if code_tag:
                        classes = code_tag.get('class', [])
                
                if classes:
                    for cls in classes:
                        if cls.startswith('language-'):
                            language = cls.replace('language-', '')
                            break
                
                append_content({
                    "type": "codeBlock",
                    "attrs": {"language": language},
                    "content": [{
                        "type": "text",
                        "text": code_text
                    }]
                })
            
            elif tag_name == 'table':
                # Handle tables
                rows = []
                
                # Process thead if exists
                thead = element.find('thead')
                if thead:
                    for tr in thead.find_all('tr', recursive=False):
                        cells = []
                        for th in tr.find_all(['th', 'td'], recursive=False):
                            # Tiptap expects block content inside cells usually
                            # Extract inline content and wrap in paragraph
                            cell_content = _extract_inline_content(th)
                            cells.append({
                                "type": "tableHeader" if th.name == 'th' else "tableCell",
                                "content": [{
                                    "type": "paragraph",
                                    "content": cell_content
                                }]
                            })
                        rows.append({
                            "type": "tableRow",
                            "content": cells
                        })
                
                # Process tbody if exists
                tbody = element.find('tbody')
                if tbody:
                    for tr in tbody.find_all('tr', recursive=False):
                        cells = []
                        for td in tr.find_all(['td', 'th'], recursive=False):
                            cell_content = _extract_inline_content(td)
                            cells.append({
                                "type": "tableCell" if td.name == 'td' else "tableHeader",
                                "content": [{
                                    "type": "paragraph",
                                    "content": cell_content
                                }]
                            })
                        rows.append({
                            "type": "tableRow",
                            "content": cells
                        })
                
                if rows:
                    append_content({
                        "type": "table",
                        "content": rows
                    })

            elif tag_name == 'hr':
                append_content({
                    "type": "horizontalRule"
                })
    # Text converting rich-text back to html to see if the output is working properly
    # debug_rich_text_json = json.dumps(rich_text, ensure_ascii=False, indent=2)
    # print("Rich text output:\n", debug_rich_text_json)
    # debug_html = _rich_text_to_html(rich_text)
    # print("Rich text rendered back to HTML:\n", debug_html)
    return rich_text


def _apply_marks(text_value: str, marks: List[Dict[str, Any]]) -> str:
    rendered = html.escape(text_value)
    for mark in marks:
        mark_type = mark.get("type")
        if mark_type == "bold":
            rendered = f"<strong>{rendered}</strong>"
        elif mark_type == "italic":
            rendered = f"<em>{rendered}</em>"
        elif mark_type == "underline":
            rendered = f"<u>{rendered}</u>"
        elif mark_type == "strike":
            rendered = f"<del>{rendered}</del>"
        elif mark_type == "code":
            rendered = f"<code>{rendered}</code>"
        elif mark_type == "link":
            attrs = mark.get("attrs", {})
            href = html.escape(attrs.get("href", "#"))
            target = attrs.get("target", "_blank")
            rendered = f"<a href=\"{href}\" target=\"{target}\">{rendered}</a>"
    return rendered


def _rich_node_to_html(node: Dict[str, Any]) -> str:
    node_type = node.get("type")
    if node_type == "text":
        return _apply_marks(node.get("text", ""), node.get("marks", []))
    if node_type == "hardBreak":
        return "<br/>"
    if node_type == "paragraph":
        content = "".join(_rich_node_to_html(child) for child in node.get("content", []))
        return f"<p>{content}</p>"
    if node_type == "heading":
        level = node.get("attrs", {}).get("level", 1)
        level = level if 1 <= level <= 6 else 1
        content = "".join(_rich_node_to_html(child) for child in node.get("content", []))
        return f"<h{level}>{content}</h{level}>"
    if node_type == "bulletList":
        items = "".join(_rich_node_to_html(item) for item in node.get("content", []))
        return f"<ul>{items}</ul>"
    if node_type == "orderedList":
        start = node.get("attrs", {}).get("start", 1)
        start_attr = f' start="{start}"' if start and start != 1 else ""
        items = "".join(_rich_node_to_html(item) for item in node.get("content", []))
        return f"<ol{start_attr}>{items}</ol>"
    if node_type == "listItem":
        content = "".join(_rich_node_to_html(child) for child in node.get("content", []))
        return f"<li>{content}</li>"
    if node_type == "blockquote":
        content = "".join(_rich_node_to_html(child) for child in node.get("content", []))
        return f"<blockquote>{content}</blockquote>"
    if node_type == "codeBlock":
        language = node.get("attrs", {}).get("language", "text")
        content = "".join(_rich_node_to_html(child) for child in node.get("content", []))
        return f"<pre><code class=\"language-{html.escape(language)}\">{content}</code></pre>"
    if node_type == "horizontalRule":
        return "<hr/>"
    if node_type == "image":
        attrs = node.get("attrs", {})
        src = html.escape(attrs.get("src", ""))
        alt = html.escape(attrs.get("alt", ""))
        title = attrs.get("title")
        title_attr = f' title="{html.escape(title)}"' if title else ""
        return f"<img src=\"{src}\" alt=\"{alt}\"{title_attr}/>"
    if node_type == "table":
        rows = "".join(_rich_node_to_html(row) for row in node.get("content", []))
        return f"<table><tbody>{rows}</tbody></table>"
    if node_type == "tableRow":
        cells = "".join(_rich_node_to_html(cell) for cell in node.get("content", []))
        return f"<tr>{cells}</tr>"
    if node_type in {"tableCell", "tableHeader"}:
        tag = "th" if node_type == "tableHeader" else "td"
        content = "".join(_rich_node_to_html(child) for child in node.get("content", []))
        return f"<{tag}>{content}</{tag}>"
    return ""


def _rich_text_to_html(rich_text: Dict[str, Any]) -> str:
    body = rich_text.get("body", rich_text)
    if body.get("type") != "doc":
        return ""
    content_nodes = body.get("content", [])
    return "".join(_rich_node_to_html(node) for node in content_nodes)


def text_search(text: str, query: str) -> bool:
    query_tokens = set(query.lower().split())
    summary_tokens = set(text.lower().split())
    return query_tokens.issubset(summary_tokens) or (query_tokens & summary_tokens)


__all__ = ["text_search", "markdown_to_rich_text"]
