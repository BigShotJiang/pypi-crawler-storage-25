import hashlib
import base64
import os
from Crypto.Cipher import AES


class AESCipher(object):
    def __init__(self, key):
        self.bs = AES.block_size
        self.key = hashlib.sha256(AESCipher.str_to_bytes(key)).digest()

    @staticmethod
    def str_to_bytes(data) -> bytes:
        u_type = type(b"".decode("utf8"))
        if isinstance(data, u_type):
            return data.encode("utf8")
        return data

    @staticmethod
    def _pad(s) -> bytes:
        pad_len = AES.block_size - len(s) % AES.block_size
        return s + pad_len * chr(pad_len).encode("utf8")

    @staticmethod
    def _unpad(s) -> bytes:
        return s[: -ord(s[len(s) - 1 :])]

    def encrypt(self, raw) -> bytes:
        raw = AESCipher._pad(AESCipher.str_to_bytes(raw))
        iv = os.urandom(AES.block_size)
        cipher = AES.new(self.key, AES.MODE_CBC, iv)
        return iv + cipher.encrypt(raw)

    def encrypt_string(self, raw) -> str:
        return base64.b64encode(self.encrypt(raw)).decode("utf8")

    def decrypt(self, enc) -> bytes:
        iv = enc[: AES.block_size]
        cipher = AES.new(self.key, AES.MODE_CBC, iv)
        return self._unpad(cipher.decrypt(enc[AES.block_size :]))

    def decrypt_string(self, enc) -> str:
        enc = base64.b64decode(enc.strip())
        return self.decrypt(enc).decode("utf8")
