import base64
from typing import Dict, Union, Optional, List
import io

EXTENSION_TO_MIME_TYPE = {
    ".doc": "application/msword",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".pdf": "application/pdf",
    ".jpeg": "image/jpeg",
    ".jpg": "image/jpeg",
    ".png": "image/png",
    ".webp": "image/webp",
    ".gif": "image/gif",
    ".svg": "image/svg+xml",
    ".txt": "text/plain",
    ".mp4": "video/mp4",
    ".avi": "video/x-msvideo",
    ".mov": "video/quicktime",
    ".mkv": "video/x-matroska",
    ".webm": "video/webm",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
}

def media_data_to_uri(media_data: List[bytes], mime: Optional[str]= None):
    def get_uri(media: bytes):
        base64_string = base64.b64encode(media).decode('utf-8')
        return f"data:{mime or 'image/jpeg'};base64,{base64_string}"
    return [get_uri(media) for media in media_data]


def encode_base64_by_chunk(data: bytes, mime_type: str) -> str:
    """
    Convert bytes to base64 data URI by processing in chunks.
    Equivalent to TypeScript's encodeBase64ByChunk function.
    
    Args:
        data: Bytes to encode
        mime_type: MIME type of the data (e.g., 'application/pdf')
        
    Returns:
        Data URI string with base64 encoded content
    """
    chunk_size = 8192
    chunks = []
    
    # Process bytes in chunks
    for i in range(0, len(data), chunk_size):
        chunk = data[i:min(i + chunk_size, len(data))]
        chunks.append(chunk)
    
    # Concatenate all chunks and encode
    full_data = b''.join(chunks)
    b64 = base64.b64encode(full_data).decode('utf-8')
    
    return f"data:{mime_type};base64,{b64}"

def convert_to_pdf(file_content: bytes, filename: str) -> dict:
    """
    Convert .docx or .txt content to PDF bytes using lightweight libraries.
    """
    from fpdf import FPDF
    from docx import Document
    pdf = FPDF()
    pdf.add_page()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.set_font("Arial", size=12)
    
    text_content = ""
    
    if filename.endswith(".docx"):
        doc = Document(io.BytesIO(file_content))
        full_text = []
        for para in doc.paragraphs:
            full_text.append(para.text)
        text_content = "\n".join(full_text)
        filename = filename.replace(".docx", ".pdf")
        
    elif filename.endswith(".txt"):
        try:
            text_content = file_content.decode('utf-8')
        except UnicodeDecodeError:
            text_content = file_content.decode('latin-1')
        filename = filename.replace(".txt", ".pdf")
            
    else:
        raise ValueError("Unsupported file format for PDF conversion")

    # Add text to PDF
    # FPDF doesn't handle unicode characters well by default with standard fonts.
    # We need to handle potential encoding issues or use a font that supports it.
    # For simplicity and lightweight requirement, we'll try to encode to latin-1 compatible
    # or replace incompatible characters.
    
    # A better approach for unicode support in FPDF is adding a unicode font, 
    # but that might increase bundle size. 
    # We will use a safe encoding strategy here.
    
    for line in text_content.split('\n'):
        # Replace unsupported characters or handle them
        safe_line = line.encode('latin-1', 'replace').decode('latin-1')
        pdf.multi_cell(0, 10, txt=safe_line)
        
    return {"data": pdf.output(dest='S').encode('latin-1'), "type": "pdf", "filename": filename}

async def read_files(file) -> Dict[str, Union[bytes, str]]:  
    print("File name: ", file.filename)  
    print("File type: ", file.content_type)  
    
    if file.filename.endswith((".doc", ".docx")):
        content = await file.read()
        pdf_data = convert_to_pdf(content, file.filename)
        return {"data": pdf_data, "type": "pdf", "filename": pdf_data["filename"]}
        
    elif file.filename.endswith(".txt"):
        # Option to convert TXT to PDF if needed, or keep as text
        # The user asked to convert docx and txt to pdf
        content = await file.read()
        pdf_data = convert_to_pdf(content, file.filename)
        return {"data": pdf_data, "type": "pdf", "filename": pdf_data["filename"]}

    elif file.filename.endswith(".pdf") or file.content_type == "application/pdf":
        return {"data": await file.read(), "type": "pdf", "filename": file.filename}
    elif file.filename.endswith((".jpeg", ".jpg", ".png", ".webp", ".gif", ".svg")) or file.content_type in ["image/jpeg", "image/jpg", "image/png", "image/webp", "image/gif", "image/svg+xml"]:
        return {"data": await file.read(), "type": "image", "filename": file.filename}
    # elif file.filename.endswith(".txt") or file.content_type == "text/plain":
    #     return {"data": (await file.read()).decode("utf-8"), "type": "text"}
    else:
        raise ValueError("Unsupported file type")
    
def get_file_category(mime_type: str) -> str:
        """
        Get file category based on file name
        
        Args:
            mime_type: MIME type of the file
            
        Returns:
            File category
        """
        if mime_type == "application/pdf":
            return "pdf"
        elif mime_type in ["image/jpeg", "image/png", "image/gif"]:
            return "image"
        elif mime_type in ["video/mp4", "video/quicktime"]:
            return "video"
        elif mime_type in ["audio/mpeg", "audio/wav"]:
            return "audio"
        else:
            return None

def get_mime_type_from_filename(filename: str) -> str:
    from pathlib import Path
    ext = Path(filename).suffix
    return EXTENSION_TO_MIME_TYPE.get(ext, "application/octet-stream")

def xlsx_to_markdown(file_data: Union[bytes, str], sheet_name: Optional[str] = None) -> str:
    import pylightxl as xl
    """
    Convert xlsx file to markdown table format for LLM consumption.
    
    Args:
        file_data: Either file bytes or file path string
        sheet_name: Specific sheet name to convert. If None, converts all sheets.
        
    Returns:
        Markdown formatted table(s) from the xlsx file
        
    Raises:
        ValueError: If file_data is invalid or sheet_name not found
    """
    import tempfile
    import os
    
    # Handle bytes input by writing to temp file
    if isinstance(file_data, bytes):
        try:
            # Create temp file with .xlsx extension
            with tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False) as tmp:
                tmp.write(file_data)
                tmp_path = tmp.name
            
            # Read from temp file
            try:
                db = xl.readxl(tmp_path)
            finally:
                # Clean up temp file
                try:
                    os.unlink(tmp_path)
                except Exception:
                    pass  # Ignore cleanup errors
                    
        except Exception as e:
            return f"# XLSX Processing Error\n\nUnable to process XLSX file: {e}"
            
    elif isinstance(file_data, str):
        db = xl.readxl(file_data)
    else:
        raise ValueError("file_data must be bytes or file path string")
    
    if not db.ws_names:
        return "# Empty Excel File\n\nNo sheets found in the workbook."
    
    sheets_to_process = [sheet_name] if sheet_name else db.ws_names
    
    markdown_output = []
    
    for ws_name in sheets_to_process:
        if ws_name not in db.ws_names:
            raise ValueError(f"Sheet '{ws_name}' not found. Available sheets: {', '.join(db.ws_names)}")
        
        ws = db.ws(ws_name)
        
        if not ws.range:
            markdown_output.append(f"## {ws_name}\n\n*Empty sheet*\n")
            continue
        
        rows = ws.range
        if not rows:
            markdown_output.append(f"## {ws_name}\n\n*Empty sheet*\n")
            continue
        
        # Determine column widths for formatting
        num_cols = max(len(row) for row in rows)
        
        # Build markdown table
        markdown_output.append(f"## {ws_name}\n")
        
        # Header row
        header = rows[0] if rows else []
        header_cells = [str(cell) if cell != "" else "" for cell in header]
        markdown_output.append("| " + " | ".join(header_cells) + " |")
        
        # Separator row
        markdown_output.append("| " + " | ".join(["---"] * len(header_cells)) + " |")
        
        # Data rows
        for row in rows[1:]:
            row_cells = [str(cell) if cell != "" else "" for cell in row]
            # Pad row if shorter than header
            while len(row_cells) < len(header_cells):
                row_cells.append("")
            markdown_output.append("| " + " | ".join(row_cells) + " |")
        
        markdown_output.append("")
    
    return "\n".join(markdown_output)