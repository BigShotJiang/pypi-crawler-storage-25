# Typeform TypedDict Guide

## Overview

Type-safe TypedDict definitions for Typeform API forms and responses, extracted from JSON exports and mapped to Python types.

**Location**: `src/utils/custom_types.py`

---

## TypedDict Definitions

### 1. TypeformChoice
**Purpose**: Represents a choice option in multiple_choice, dropdown, or rating fields.

**Fields**:
- `id` (str): Unique choice identifier
- `ref` (str): UUID reference for the choice
- `label` (str): Display text for the choice

**Example**:
```python
choice: TypeformChoice = {
    "id": "MYdwjE4qaI1O",
    "ref": "e1cac13e-fa35-49df-a61a-576fb2b1f576",
    "label": "Mission ONE: Enter the AI Officer"
}
```

**Used In**: `TypeformField.choices`

---

### 2. TypeformContactInfoSubfield
**Purpose**: Represents a subfield within a contact_info field (first_name, last_name, email, phone_number, company).

**Fields**:
- `id` (str): Unique subfield identifier
- `title` (str): Display label (e.g., "First name")
- `ref` (str): UUID reference
- `subfield_key` (str): Key identifier ("first_name", "last_name", "email", "phone_number", "company")
- `type` (str): Field type ("short_text", "email", "phone_number")
- `properties` (dict): Field properties
- `validations` (Optional[dict]): Validation rules

**Example**:
```python
subfield: TypeformContactInfoSubfield = {
    "id": "UPVMa0rU4bxH",
    "title": "First name",
    "ref": "38b54e16-775d-48da-bda1-1b3e73aa1f75",
    "subfield_key": "first_name",
    "type": "short_text",
    "properties": {},
    "validations": {"required": True}
}
```

**Used In**: `TypeformField.fields` (for contact_info type fields)

---

### 3. TypeformFieldValidation
**Purpose**: Validation rules for form fields.

**Fields**:
- `required` (Optional[bool]): Whether field is required
- `max_length` (Optional[int]): Maximum text length
- `min_length` (Optional[int]): Minimum text length
- `max_value` (Optional[int]): Maximum numeric value
- `min_value` (Optional[int]): Minimum numeric value

**Example**:
```python
validation: TypeformFieldValidation = {
    "required": True,
    "max_length": 100
}
```

**Used In**: `TypeformField.validations`

---

### 4. TypeformField
**Purpose**: Represents a single form field/question.

**Fields**:
- `id` (str): Unique field identifier
- `type` (str): Field type (see types below)
- `title` (str): Question text
- `ref` (str): UUID reference
- `properties` (dict): Field-specific properties
- `validations` (Optional[TypeformFieldValidation]): Validation rules
- `choices` (Optional[List[TypeformChoice]]): For multiple_choice, dropdown, rating
- `fields` (Optional[List[TypeformContactInfoSubfield]]): For contact_info type

**Supported Field Types**:
- `short_text` - Single line text
- `long_text` - Multi-line text
- `email` - Email address
- `number` - Numeric value
- `dropdown` - Dropdown selection
- `multiple_choice` - Radio buttons
- `nps` - Net Promoter Score (0-10)
- `opinion_scale` - Rating scale
- `rating` - Star rating
- `yes_no` - Boolean yes/no
- `contact_info` - Contact information (contains subfields)
- `date` - Date picker
- `time` - Time picker
- `phone_number` - Phone number
- `file_upload` - File upload
- `statement` - Display text (no answer)

**Example - Multiple Choice**:
```python
field: TypeformField = {
    "id": "oqEHXnLYg7UN",
    "type": "dropdown",
    "title": "Which mission did you complete?",
    "ref": "0abae965-74b0-43a1-9101-63e512fcdcee",
    "properties": {
        "randomize": False,
        "alphabetical_order": False
    },
    "validations": {"required": True},
    "choices": [
        {
            "id": "MYdwjE4qaI1O",
            "ref": "e1cac13e-fa35-49df-a61a-576fb2b1f576",
            "label": "Mission ONE: Enter the AI Officer"
        }
    ]
}
```

**Example - Contact Info**:
```python
field: TypeformField = {
    "id": "R2XaI6Zl8pKk",
    "type": "contact_info",
    "title": "Contact Information",
    "ref": "01KA7ZPGE7TR49S11R93MR1Z6M",
    "properties": {},
    "fields": [
        {
            "id": "UPVMa0rU4bxH",
            "title": "First name",
            "ref": "38b54e16-775d-48da-bda1-1b3e73aa1f75",
            "subfield_key": "first_name",
            "type": "short_text",
            "properties": {},
            "validations": {"required": True}
        }
    ]
}
```

**Used In**: `TypeformForm.fields`

---

### 5. TypeformForm
**Purpose**: Represents the complete form structure with all fields.

**Fields**:
- `id` (str): Unique form identifier
- `type` (str): Form type ("quiz", "form", "survey")
- `title` (str): Form title
- `created_at` (str): ISO 8601 creation timestamp
- `updated_at` (Optional[str]): ISO 8601 update timestamp
- `last_updated_at` (Optional[str]): ISO 8601 last update timestamp
- `published_at` (Optional[str]): ISO 8601 publication timestamp
- `fields` (List[TypeformField]): All form fields
- `welcome_screens` (Optional[list]): Welcome screen configurations
- `thank_you_screens` (Optional[list]): Thank you screen configurations

**Example**:
```python
form: TypeformForm = {
    "id": "ayztPlg7",
    "type": "quiz",
    "title": "Community Course Mission",
    "created_at": "2025-09-16T23:13:30+00:00",
    "last_updated_at": "2025-11-13T08:00:56+00:00",
    "published_at": "2025-09-16T23:44:47+00:00",
    "fields": [
        # ... list of TypeformField
    ],
    "welcome_screens": [...],
    "thank_you_screens": [...]
}
```

**Used In**: Form data structures, API responses

---

### 6. TypeformAnswerFieldRef
**Purpose**: Reference to the field that an answer corresponds to.

**Fields**:
- `id` (str): Field identifier
- `type` (str): Field type
- `ref` (str): UUID reference

**Example**:
```python
field_ref: TypeformAnswerFieldRef = {
    "id": "oqEHXnLYg7UN",
    "type": "dropdown",
    "ref": "0abae965-74b0-43a1-9101-63e512fcdcee"
}
```

**Used In**: `TypeformAnswer.field`

---

### 7. TypeformAnswer
**Purpose**: Represents a single answer to a form question in a response.

**Fields**:
- `type` (str): Answer type (see types below)
- `field` (TypeformAnswerFieldRef): Reference to the field
- `text` (Optional[str]): For text, email, long_text, phone_number answers
- `email` (Optional[str]): For email type answers
- `number` (Optional[int]): For number, nps, opinion_scale, rating answers
- `choice` (Optional[dict]): For single choice answers: `{"id": str, "label": str, "ref": str}`
- `choices` (Optional[List[dict]]): For multiple choice answers: list of choice objects
- `date` (Optional[str]): For date type answers (format: "YYYY-MM-DD")
- `time` (Optional[str]): For time type answers (format: "HH:MM")
- `boolean` (Optional[bool]): For yes_no type answers
- `file_url` (Optional[str]): For file_upload type answers
- `phone_number` (Optional[str]): For phone_number type answers

**Answer Types**:
- `text` - Text answer
- `email` - Email answer
- `number` - Numeric answer
- `choice` - Single choice selection
- `choices` - Multiple choice selection
- `date` - Date answer
- `time` - Time answer
- `boolean` - Yes/no answer
- `file_url` - File upload URL
- `phone_number` - Phone number answer

**Example - Text Answer**:
```python
answer: TypeformAnswer = {
    "type": "text",
    "field": {
        "id": "WRfcvINoCFnc",
        "type": "long_text",
        "ref": "39fb9901-e872-46e0-ba26-550ea1f803bf"
    },
    "text": "Sample detailed prompts"
}
```

**Example - Number Answer**:
```python
answer: TypeformAnswer = {
    "type": "number",
    "field": {
        "id": "Oj2PQAFf3aAv",
        "type": "nps",
        "ref": "dd9660e6-1a12-4b6e-9672-78aadb7a69eb"
    },
    "number": 10
}
```

**Example - Choice Answer**:
```python
answer: TypeformAnswer = {
    "type": "text",  # Note: dropdown returns as "text"
    "field": {
        "id": "oqEHXnLYg7UN",
        "type": "dropdown",
        "ref": "0abae965-74b0-43a1-9101-63e512fcdcee"
    },
    "text": "Mission FOUR: Prompting Perfect Visuals"
}
```

**Used In**: `TypeformResponse.answers`

---

### 8. TypeformResponse
**Purpose**: Represents a single form response/submission.

**Fields**:
- `response_id` (str): Unique response identifier
- `token` (str): Response token
- `response_type` (str): "completed" or "partial"
- `submitted_at` (str): ISO 8601 submission timestamp
- `landed_at` (Optional[str]): ISO 8601 landing timestamp
- `answers` (List[TypeformAnswer]): All answers in the response
- `metadata` (Optional[dict]): User agent, platform, browser info
- `hidden` (Optional[dict]): Hidden field values
- `calculated` (Optional[dict]): Calculated scores
- `thankyou_screen_ref` (Optional[str]): Thank you screen reference

**Example**:
```python
response: TypeformResponse = {
    "response_id": "qnkb2ezp461cgnydtmqnkb2kswm00be7",
    "token": "qnkb2ezp461cgnydtmqnkb2kswm00be7",
    "response_type": "completed",
    "submitted_at": "2025-11-18T03:14:04Z",
    "landed_at": "2025-11-18T03:13:10Z",
    "answers": [
        # ... list of TypeformAnswer
    ],
    "metadata": {
        "user_agent": "Mozilla/5.0...",
        "platform": "other",
        "browser": "default"
    },
    "hidden": {},
    "calculated": {"score": 0},
    "thankyou_screen_ref": "34bb85ff-ce6e-4737-826a-c90582894c71"
}
```

**Used In**: Response data structures, API responses

---

## Usage Examples

### Example 1: Type-safe form processing

```python
from src.utils.custom_types import TypeformForm, TypeformField

def process_form(form: TypeformForm) -> None:
    """Process a form with type safety."""
    print(f"Form: {form['title']}")
    print(f"Created: {form['created_at']}")
    
    for field in form['fields']:
        print(f"  - {field['title']} ({field['type']})")
        
        # Handle choices
        if field.get('choices'):
            for choice in field['choices']:
                print(f"    * {choice['label']}")
        
        # Handle contact info subfields
        if field.get('fields'):
            for subfield in field['fields']:
                print(f"    * {subfield['title']} ({subfield['subfield_key']})")
```

### Example 2: Type-safe response processing

```python
from src.utils.custom_types import TypeformResponse, TypeformAnswer

def process_response(response: TypeformResponse) -> dict:
    """Extract answer data from response."""
    answer_data = {}
    
    for answer in response['answers']:
        field_id = answer['field']['id']
        answer_type = answer['type']
        
        # Extract value based on type
        if answer_type == 'text':
            value = answer.get('text')
        elif answer_type == 'number':
            value = answer.get('number')
        elif answer_type == 'choice':
            value = answer.get('choice', {}).get('label')
        elif answer_type == 'boolean':
            value = answer.get('boolean')
        else:
            value = answer.get(answer_type)
        
        answer_data[field_id] = value
    
    return answer_data
```

### Example 3: Type-safe field validation

```python
from src.utils.custom_types import TypeformField, TypeformFieldValidation

def validate_field_required(field: TypeformField) -> bool:
    """Check if field is required."""
    validations = field.get('validations')
    if validations:
        return validations.get('required', False)
    return False

def get_field_constraints(field: TypeformField) -> dict:
    """Extract field constraints."""
    validations = field.get('validations', {})
    return {
        'required': validations.get('required'),
        'max_length': validations.get('max_length'),
        'min_length': validations.get('min_length'),
        'max_value': validations.get('max_value'),
        'min_value': validations.get('min_value'),
    }
```

---

## Integration with Connectors

### Using in Typeform Connector

```python
from src.utils.custom_types import TypeformForm, TypeformResponse

class TypeformConnector:
    async def fetch_form(self, form_id: str) -> TypeformForm:
        """Fetch form with type safety."""
        response = await self.request("GET", f"/forms/{form_id}")
        return response  # Type-safe TypeformForm
    
    async def fetch_responses(self, form_id: str) -> List[TypeformResponse]:
        """Fetch responses with type safety."""
        responses = []
        response_data = await self.request("GET", f"/forms/{form_id}/responses")
        
        for item in response_data.get('items', []):
            responses.append(item)  # Type-safe TypeformResponse
        
        return responses
```

---

## Data Mapping Reference

### Form Data Extraction

| Field | Type | Source | Notes |
|-------|------|--------|-------|
| `id` | str | `form.id` | Unique form identifier |
| `type` | str | `form.type` | "quiz", "form", "survey" |
| `title` | str | `form.title` | Form title |
| `created_at` | str | `form.created_at` | ISO 8601 timestamp |
| `updated_at` | Optional[str] | `form.updated_at` | May be None |
| `fields` | List[TypeformField] | `form.fields` | All form questions |

### Field Data Extraction

| Field | Type | Source | Notes |
|-------|------|--------|-------|
| `id` | str | `field.id` | Unique field identifier |
| `type` | str | `field.type` | Field type (see types) |
| `title` | str | `field.title` | Question text |
| `ref` | str | `field.ref` | UUID reference |
| `validations` | Optional[dict] | `field.validations` | Validation rules |
| `choices` | Optional[List] | `field.properties.choices` | For choice fields |
| `fields` | Optional[List] | `field.properties.fields` | For contact_info |

### Response Data Extraction

| Field | Type | Source | Notes |
|-------|------|--------|-------|
| `response_id` | str | `response.response_id` | Unique response ID |
| `response_type` | str | `response.response_type` | "completed", "partial" |
| `submitted_at` | str | `response.submitted_at` | ISO 8601 timestamp |
| `answers` | List[TypeformAnswer] | `response.answers` | All answers |

---

## Type Checking

### Enable Type Checking

```bash
# Using mypy
mypy src/connectors/typeform/ --strict

# Using pyright
pyright src/connectors/typeform/
```

### Example Type Check

```python
from src.utils.custom_types import TypeformForm

def process_form(form: TypeformForm) -> None:
    # Type checker knows form has these fields
    title: str = form['title']  # ✅ OK
    created_at: str = form['created_at']  # ✅ OK
    
    # Type checker catches errors
    invalid: int = form['title']  # ❌ Error: str is not int
    missing: str = form['nonexistent']  # ❌ Error: key doesn't exist
```

---

## Notes

- All TypedDicts use `total=False` where appropriate to allow optional fields
- ISO 8601 timestamps are used throughout (UTC timezone)
- Field types are based on actual Typeform API responses
- Answer types vary based on the field type
- Contact info fields are special and contain subfields
- Validation rules are optional and field-dependent

---

## References

- [Typeform API Documentation](https://www.typeform.com/developers/)
- [TypedDict Documentation](https://docs.python.org/3/library/typing.html#typing.TypedDict)
- [JSON Export Examples](../tests/typeform_exports/)

---

**Last Updated**: 2025-11-29
**Status**: ✅ Production Ready
