import asyncio
import json
import requests
import base64
from typing import Any

USE_TOON_FORMAT = False

def format_for_llm(data: Any, use_toon: bool = None) -> str:
    """Format data for LLM with TOON fallback.

    Args:
        data: Data to format (dict, list, or any JSON-serializable type)
        use_toon: Override global TOON setting. If None, uses USE_TOON_FORMAT.

    Returns:
        Formatted string (TOON or JSON)
    """
    should_use_toon = use_toon if use_toon is not None else USE_TOON_FORMAT

    if should_use_toon:
        try:
            from utils.toon_encoder import encode_toon
            return encode_toon(data)
        except ImportError as e:
            print("Custom TOON encoder not available. Falling back to JSON.")
            print(e)
        except Exception as e:
            print("TOON encoding failed. Falling back to JSON.")
            print(e)

    return json.dumps(data, indent=2)

async def json_format_response(response: dict, response_as_json: bool) -> str:
    await asyncio.sleep(0.5)
    if response_as_json:
        return json.dumps(response ) + "\n\n"

    sse_string = {
        "event": response['event'],
        "data": json.dumps(response['data'])
    }
    return sse_string

async def url_to_base64(url: str) -> str:
    response = requests.get(url)
    image = response.content
    base64_data = base64.b64encode(image).decode('utf-8')
    return f"data:image/jpeg;base64,{base64_data}"


__all__ = ["json_format_response", "url_to_base64", "format_for_llm", "USE_TOON_FORMAT"]
    