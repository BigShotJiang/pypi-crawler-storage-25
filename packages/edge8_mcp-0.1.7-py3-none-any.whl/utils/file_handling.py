import json
import os

def sanitize_filename(file_name: str) -> str:
  """
  Sanitize filename by removing special characters that Supabase storage rejects.
  
  Args:
      file_name: Original filename
      
  Returns:
      Sanitized filename safe for Supabase storage
  """
  sanitized = file_name
  sanitized = sanitized.replace("–", "_")  # en-dash
  sanitized = sanitized.replace("—", "_")  # em-dash
  sanitized = sanitized.replace(" ", "_")  # spaces
  return sanitized

def parse_data_from_json_file(path) -> dict:
  config_path = os.path.dirname(__file__).replace("/utils", "") + path
  with open(config_path, "r") as f:
    return json.load(f)
  

def main():
  button_card = parse_data_from_json_file("/config/lark/button_card.json")
  print("button_card: ", button_card)

if __name__ == "__main__":
  main()
