# Typeform TypedDict - Quick Reference

## TypedDict Hierarchy

```
TypeformForm
├── fields: List[TypeformField]
│   ├── choices: List[TypeformChoice]  (for multiple_choice, dropdown, rating)
│   └── fields: List[TypeformContactInfoSubfield]  (for contact_info)
├── welcome_screens: list
└── thank_you_screens: list

TypeformResponse
└── answers: List[TypeformAnswer]
    └── field: TypeformAnswerFieldRef
```

---

## Core Types

### TypeformForm
```python
from src.utils.custom_types import TypeformForm

form: TypeformForm = {
    "id": "ayztPlg7",
    "type": "quiz",  # "quiz", "form", "survey"
    "title": "Community Course Mission",
    "created_at": "2025-09-16T23:13:30+00:00",
    "updated_at": "2025-11-13T08:00:56+00:00",
    "fields": [...],  # List[TypeformField]
}
```

### TypeformField
```python
from src.utils.custom_types import TypeformField

field: TypeformField = {
    "id": "oqEHXnLYg7UN",
    "type": "dropdown",  # See field types below
    "title": "Which mission?",
    "ref": "0abae965-74b0-43a1-9101-63e512fcdcee",
    "properties": {},
    "validations": {"required": True},
    "choices": [...],  # Optional[List[TypeformChoice]]
}
```

### TypeformResponse
```python
from src.utils.custom_types import TypeformResponse

response: TypeformResponse = {
    "response_id": "qnkb2ezp461cgnydtmqnkb2kswm00be7",
    "token": "qnkb2ezp461cgnydtmqnkb2kswm00be7",
    "response_type": "completed",  # "completed", "partial"
    "submitted_at": "2025-11-18T03:14:04Z",
    "answers": [...],  # List[TypeformAnswer]
}
```

### TypeformAnswer
```python
from src.utils.custom_types import TypeformAnswer

answer: TypeformAnswer = {
    "type": "text",  # See answer types below
    "field": {
        "id": "WRfcvINoCFnc",
        "type": "long_text",
        "ref": "39fb9901-e872-46e0-ba26-550ea1f803bf"
    },
    "text": "Sample response",  # Varies by answer type
}
```

---

## Field Types

| Type | Answer Type | Value Field |
|------|-------------|-------------|
| `short_text` | `text` | `text` |
| `long_text` | `text` | `text` |
| `email` | `email` | `email` or `text` |
| `number` | `number` | `number` |
| `dropdown` | `text` | `text` |
| `multiple_choice` | `text` | `text` |
| `nps` | `number` | `number` |
| `opinion_scale` | `number` | `number` |
| `rating` | `number` | `number` |
| `yes_no` | `boolean` | `boolean` |
| `contact_info` | `text` | `text` (per subfield) |
| `date` | `date` | `date` |
| `time` | `time` | `time` |
| `phone_number` | `phone_number` | `phone_number` or `text` |
| `file_upload` | `file_url` | `file_url` |
| `statement` | N/A | N/A |

---

## Common Patterns

### Extract form title and field count
```python
from src.utils.custom_types import TypeformForm

def get_form_info(form: TypeformForm) -> dict:
    return {
        "title": form["title"],
        "field_count": len(form["fields"]),
        "created": form["created_at"]
    }
```

### Extract answer value
```python
from src.utils.custom_types import TypeformAnswer

def get_answer_value(answer: TypeformAnswer):
    answer_type = answer["type"]
    
    if answer_type == "text":
        return answer.get("text")
    elif answer_type == "number":
        return answer.get("number")
    elif answer_type == "boolean":
        return answer.get("boolean")
    elif answer_type == "choice":
        return answer.get("choice", {}).get("label")
    elif answer_type == "choices":
        return [c.get("label") for c in answer.get("choices", [])]
    else:
        return answer.get(answer_type)
```

### Check if field is required
```python
from src.utils.custom_types import TypeformField

def is_required(field: TypeformField) -> bool:
    validations = field.get("validations", {})
    return validations.get("required", False)
```

### Get field choices
```python
from src.utils.custom_types import TypeformField, TypeformChoice

def get_choices(field: TypeformField) -> list[TypeformChoice]:
    return field.get("choices", [])
```

### Get contact info subfields
```python
from src.utils.custom_types import TypeformField, TypeformContactInfoSubfield

def get_contact_fields(field: TypeformField) -> list[TypeformContactInfoSubfield]:
    return field.get("fields", [])
```

---

## Import Examples

```python
# Import all Typeform types
from src.utils.custom_types import (
    TypeformForm,
    TypeformField,
    TypeformChoice,
    TypeformContactInfoSubfield,
    TypeformFieldValidation,
    TypeformResponse,
    TypeformAnswer,
    TypeformAnswerFieldRef,
)

# Use in function signatures
def process_form(form: TypeformForm) -> None:
    pass

def process_response(response: TypeformResponse) -> dict:
    pass

def extract_field_info(field: TypeformField) -> dict:
    pass
```

---

## Validation Rules

```python
from src.utils.custom_types import TypeformFieldValidation

validation: TypeformFieldValidation = {
    "required": True,
    "max_length": 100,
    "min_length": 5,
    "max_value": 100,
    "min_value": 0,
}
```

---

## Contact Info Subfields

```python
from src.utils.custom_types import TypeformContactInfoSubfield

subfield: TypeformContactInfoSubfield = {
    "id": "UPVMa0rU4bxH",
    "title": "First name",
    "ref": "38b54e16-775d-48da-bda1-1b3e73aa1f75",
    "subfield_key": "first_name",  # "first_name", "last_name", "email", "phone_number", "company"
    "type": "short_text",
    "properties": {},
    "validations": {"required": True}
}
```

---

## Response Metadata

```python
response = {
    "response_id": "...",
    "response_type": "completed",  # "completed", "partial"
    "submitted_at": "2025-11-18T03:14:04Z",
    "landed_at": "2025-11-18T03:13:10Z",
    "metadata": {
        "user_agent": "Mozilla/5.0...",
        "platform": "other",
        "browser": "default",
        "referer": "https://form.typeform.com/",
        "network_id": "e77becee8d"
    },
    "hidden": {},  # Hidden field values
    "calculated": {"score": 0},  # Calculated scores
    "thankyou_screen_ref": "34bb85ff-ce6e-4737-826a-c90582894c71"
}
```

---

## Type Checking

```bash
# Check syntax
python -m py_compile src/utils/custom_types.py

# Type check with mypy
mypy src/utils/custom_types.py --strict

# Type check specific file
mypy src/connectors/typeform/ --strict
```

---

## Location

**File**: `src/utils/custom_types.py`
**Lines**: 487-609
**Status**: ✅ Production Ready

---

## Documentation

- **Full Guide**: `src/utils/TYPEFORM_TYPES_GUIDE.md`
- **JSON Examples**: `tests/typeform_exports/`
- **API Reference**: `planning/typeform_api_implementation_guide.md`

---

**Last Updated**: 2025-11-29
