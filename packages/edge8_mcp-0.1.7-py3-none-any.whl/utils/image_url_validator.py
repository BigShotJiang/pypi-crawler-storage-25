import asyncio
import aiohttp
import time
from typing import List, Dict, Tuple, Optional
from urllib.parse import urlparse
import logging

logger = logging.getLogger(__name__)

class FastImageURLValidator:
    """
    Ultra-fast image URL validator optimized for <10ms per URL validation.
    Uses HEAD requests, connection pooling, and aggressive timeouts.
    """
    
    def __init__(self, 
                 timeout: float = 0.008,  # 8ms timeout
                 max_concurrent: int = 100,
                 connection_limit: int = 100,
                 connection_limit_per_host: int = 30):
        """
        Initialize the validator with aggressive performance settings.
        
        Args:
            timeout: Request timeout in seconds (default 8ms)
            max_concurrent: Maximum concurrent requests
            connection_limit: Total connection pool limit
            connection_limit_per_host: Connections per host limit
        """
        self.timeout = timeout
        self.max_concurrent = max_concurrent
        
        # Create connector with optimized settings
        self.connector = aiohttp.TCPConnector(
            limit=connection_limit,
            limit_per_host=connection_limit_per_host,
            ttl_dns_cache=300,  # DNS cache for 5 minutes
            use_dns_cache=True,
            keepalive_timeout=30,
            enable_cleanup_closed=True,
            force_close=False,  # Keep connections alive
            ssl=False  # Disable SSL verification for speed (use with caution)
        )
        
        # Headers optimized for speed
        self.headers = {
            'User-Agent': 'TravelBuddy-ImageValidator/1.0',
            'Accept': 'image/*',
            'Connection': 'keep-alive',
            'Cache-Control': 'no-cache'
        }
    
    async def check_single_url(self, session: aiohttp.ClientSession, url: str) -> Tuple[str, bool, Optional[str], float]:
        """
        Check a single URL with HEAD request for maximum speed.
        
        Returns:
            Tuple of (url, is_available, error_message, response_time_ms)
        """
        start_time = time.perf_counter()
        
        try:
            # Validate URL format first (fastest check)
            parsed = urlparse(url)
            if not parsed.scheme or not parsed.netloc:
                return url, False, "Invalid URL format", 0.0
            
            # Use HEAD request for fastest response
            async with session.head(
                url,
                timeout=aiohttp.ClientTimeout(total=self.timeout),
                headers=self.headers,
                allow_redirects=True,
                max_redirects=3
            ) as response:
                end_time = time.perf_counter()
                response_time = (end_time - start_time) * 1000  # Convert to ms
                
                # Check if it's a successful response and likely an image
                is_available = (
                    200 <= response.status < 400 and
                    self._is_likely_image_response(response)
                )
                
                error_msg = None if is_available else f"HTTP {response.status}"
                return url, is_available, error_msg, response_time
                
        except asyncio.TimeoutError:
            end_time = time.perf_counter()
            response_time = (end_time - start_time) * 1000
            return url, False, "Timeout", response_time
            
        except Exception as e:
            end_time = time.perf_counter()
            response_time = (end_time - start_time) * 1000
            return url, False, str(e)[:50], response_time
    
    def _is_likely_image_response(self, response: aiohttp.ClientResponse) -> bool:
        """
        Quick check if response is likely an image based on headers.
        """
        content_type = response.headers.get('Content-Type', '').lower()
        
        # Check for image content types
        image_types = ['image/', 'application/octet-stream']
        if any(img_type in content_type for img_type in image_types):
            return True
        
        # Check content length (images are usually > 1KB)
        content_length = response.headers.get('Content-Length')
        if content_length and int(content_length) > 1024:
            return True
            
        return False
    
    async def check_urls_batch(self, urls: List[str]) -> Dict[str, Dict]:
        """
        Check multiple URLs concurrently with optimized batching.
        
        Args:
            urls: List of image URLs to check
            
        Returns:
            Dictionary mapping URL to validation results
        """
        if not urls:
            return {}
        
        # Remove duplicates while preserving order
        unique_urls = list(dict.fromkeys(urls))
        
        # Create semaphore for concurrency control
        semaphore = asyncio.Semaphore(self.max_concurrent)
        
        async def check_with_semaphore(session, url):
            async with semaphore:
                return await self.check_single_url(session, url)
        
        # Create session with optimized settings
        timeout = aiohttp.ClientTimeout(total=self.timeout, connect=self.timeout/2)
        
        async with aiohttp.ClientSession(
            connector=self.connector,
            timeout=timeout,
            headers=self.headers
        ) as session:
            
            # Execute all checks concurrently
            tasks = [check_with_semaphore(session, url) for url in unique_urls]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            # Process results
            validation_results = {}
            total_time = 0
            successful_checks = 0
            
            for i, result in enumerate(results):
                url = unique_urls[i]
                
                if isinstance(result, Exception):
                    validation_results[url] = {
                        'available': False,
                        'error': str(result)[:50],
                        'response_time_ms': 0.0
                    }
                else:
                    _, is_available, error_msg, response_time = result
                    validation_results[url] = {
                        'available': is_available,
                        'error': error_msg,
                        'response_time_ms': response_time
                    }
                    
                    if response_time > 0:
                        total_time += response_time
                        successful_checks += 1
            
            # Add performance stats
            avg_response_time = total_time / successful_checks if successful_checks > 0 else 0
            validation_results['_stats'] = {
                'total_urls': len(unique_urls),
                'available_urls': sum(1 for r in validation_results.values() if isinstance(r, dict) and r.get('available')),
                'average_response_time_ms': round(avg_response_time, 2),
                'max_response_time_ms': max((r.get('response_time_ms', 0) for r in validation_results.values() if isinstance(r, dict)), default=0)
            }
            
            return validation_results
    
    async def get_available_urls(self, urls: List[str]) -> List[str]:
        """
        Get only the available URLs from a list.
        
        Args:
            urls: List of URLs to check
            
        Returns:
            List of available URLs
        """
        results = await self.check_urls_batch(urls)
        return [
            url for url, data in results.items() 
            if isinstance(data, dict) and data.get('available', False)
        ]
    
    async def close(self):
        """Close the connector to clean up resources."""
        if self.connector:
            await self.connector.close()


# Convenience functions for easy usage
async def check_image_urls_fast(urls: List[str], timeout: float = 0.008) -> Dict[str, Dict]:
    """
    Quick function to check multiple image URLs.
    
    Args:
        urls: List of image URLs to check
        timeout: Timeout per request in seconds (default 8ms)
        
    Returns:
        Dictionary with validation results
    """
    validator = FastImageURLValidator(timeout=timeout)
    try:
        return await validator.check_urls_batch(urls)
    finally:
        await validator.close()


async def filter_available_image_urls(urls: List[str], timeout: float = 0.008) -> List[str]:
    """
    Filter a list of URLs to return only available ones.
    
    Args:
        urls: List of image URLs to check
        timeout: Timeout per request in seconds (default 8ms)
        
    Returns:
        List of available URLs
    """
    validator = FastImageURLValidator(timeout=timeout)
    try:
        return await validator.get_available_urls(urls)
    finally:
        await validator.close()


# Example usage and testing
async def test_validator():
    """Test the validator with sample URLs."""
    test_urls = [
        "https://images.unsplash.com/photo-1506905925346-21bda4d32df4",  # Should work
        "https://httpstat.us/200",  # Should work but not an image
        "https://httpstat.us/404",  # Should fail
        "https://nonexistent-domain-12345.com/image.jpg",  # Should fail
        "invalid-url",  # Should fail immediately
    ]
    
    print("Testing FastImageURLValidator...")
    start_time = time.perf_counter()
    
    results = await check_image_urls_fast(test_urls, timeout=0.01)  # 10ms timeout
    
    end_time = time.perf_counter()
    total_time = (end_time - start_time) * 1000
    
    print(f"\nResults (Total time: {total_time:.2f}ms):")
    for url, data in results.items():
        if url == '_stats':
            print(f"\nStats: {data}")
        else:
            status = "✅ Available" if data.get('available') else "❌ Unavailable"
            error = f" ({data.get('error')})" if data.get('error') else ""
            time_ms = data.get('response_time_ms', 0)
            print(f"{status} [{time_ms:.1f}ms]: {url[:60]}...{error}")


if __name__ == "__main__":
    asyncio.run(test_validator())
