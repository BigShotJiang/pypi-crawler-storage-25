from requests import Response
from typing import Any, Union
import json 

def response_data_and_error(response: Response) -> Union[dict, list]:
    parsed_content: Union[dict, list] = response.json()
    if parsed_content.get("code") != 0 or not response.ok:
      return parsed_content or {"error": {"code": parsed_content.get("code", ""), "reason": response.reason}}
    return parsed_content
        
def process_response_contents(response: Response, data_key: Union[str, None] = None, alt: Union[Any, None] = None) -> Union[dict, list]:
    if not response.ok:
      try: 
        error = response.json().get("error", "")
      except Exception as _e:
        error = response.text
        
      raise Exception(f"{response.reason} {json.dumps(error)}")
  
    parsed_content: Union[dict, list] = response.json()
    return parsed_content.get(data_key, alt) if data_key is not None else parsed_content

__all__ = ["response_data_and_error", "process_response_contents"]